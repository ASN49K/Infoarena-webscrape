#include <bits/stdc++.h>

using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
#define fi first
#define se second

#define NMAX 100005
#define MOD 1000000007
#define INF 0x3f3f3f3f

int n, m, x, y, ans, root[NMAX], c;

void read()
{
    in >> n >> m;
}

int getRoot(int x)
{
    if (root[x] == x)
        return x;
    return (root[x] = getRoot(root[x]));
}

void solve()
{
    for (int i = 1; i <= n; i++)
        root[i] = i;
    for (int i = 1; i <= m; i++)
    {
        in >> c >> x >> y;
        x = getRoot(x);
        y = getRoot(y);
        if (c == 1)
            root[y] = x;
        else
        {
            if (x == y)
                out << "DA";
            else
                out << "NU";
            out << '\n';
        }
    }
}

int main()
{
    read();
    solve();
    return 0;
}