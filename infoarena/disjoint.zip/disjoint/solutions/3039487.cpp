#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

string filename = "disjoint";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif


const int NMAX = 1e5;

namespace DSU{
    int parent[NMAX + 1];
    int sz[NMAX + 1];

    void init(int n){
        for(int i = 1; i <= n; i++){
            parent[i] = i;
            sz[i] = 1;
        }
    }

    int Find(int node){
        if(node == parent[node]){
            return node;
        }
        return parent[node] = Find(parent[node]);
    }

    void Join(int a, int b){
        a = Find(a);
        b = Find(b);

        if(sz[a] > sz[b]){
            swap(a, b);
        }

        parent[a] = b;
        sz[b] += sz[a];
    }
}

signed main(){

    int n, q;
    fin >> n >> q;

    DSU::init(n);

    for(int i = 1; i <= q; i++){
        int t;
        fin >> t;

        if(t == 1){
            int a, b;
            fin >> a >> b;
            DSU::Join(a, b);
        }else{
            int a, b;
            fin >> a >> b;
            if(DSU::Find(a) == DSU::Find(b)){
                fout << "DA\n";
            }else{
                fout << "NU\n";
            }
        }
    }
    
    return 0;
}