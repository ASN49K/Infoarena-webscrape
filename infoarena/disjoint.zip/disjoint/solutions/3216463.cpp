#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

//const int nmax = 2e5;
//
//vector<int, pair<int, int>> edge;
//
//int n, m, x, y, c;

struct DSU {
	vector<int> t;

	DSU(const int n = 2e5) {
		t.resize(n + 1);
		for(int i = 1; i <= n; i++)
			t[i] = i;
	}

	int parent(int x) {
		if(x == t[x])
			return x;
		else
			return t[x] = parent(t[x]);
	}

	void join(int x, int y) {
		int tx = parent(x), ty = parent(y);
		t[tx] = t[ty];
	}

	bool sameparent(int x, int y) {
		return (parent(x) == parent(y));
	}
};

//void read() {
//	fin >> n >> m;
//	for(int i = 1; i <= m; i++) {
//		fin >> x >> y >> c;
//		edge.push_back({c, {x, y}});
//	}
//}

DSU dsu(1e5);

int n, q, x, y, cer;

void solve() {
	fin >> n >> q;
	for(int i = 1; i <= q; i++) {
		fin >> cer >> x >> y;
		if(cer == 1) {
			dsu.join(x, y);
		} else if(cer == 2) {
			fout << (dsu.sameparent(x, y) == 1 ? "DA" : "NU") << "\n";
		}
	}
}

int main() {
	solve();
	return 0;
}
