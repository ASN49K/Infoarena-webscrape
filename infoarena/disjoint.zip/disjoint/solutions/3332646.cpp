#include <iostream>

int parent[100001];
void make_set(int a)
{
    parent[a] = a;
}
void find_root(int a)
{
    if(a == parent[a])
        return a;
    return parent[a] = find_root(parent[a]);
}
void unire(int a, int b)
{
    int root_a = find_root(a);
    int root_b = find_root(b);
    if(root_a != root_b)
        parent[root_b] = root_a;
}
int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);

    int n, m;
    std::cin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int op, a, b;
        std::cin >> op >> a >> b;
        if(op == 1){
            ///unirea multimilor in care se afla x cu mult cu elem y
            update()
        }
    }

    return 0;
}
