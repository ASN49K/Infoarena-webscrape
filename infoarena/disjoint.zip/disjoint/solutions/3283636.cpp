#include <bits/stdc++.h>
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");
int const lmax=1e5+7;
int n,m;
int t[lmax],h[lmax];
int root(int n)
{
    if(t[n]==0)
    {
        return n;
    }
    int aux=root(t[n]);
    t[n]=aux;
    return aux;
}
void merger(int n1,int n2)
{
    int r1,r2;
    r1=root(n1);
    r2=root(n2);
    if(r1==r2)return;
    if(h[r1]<h[r2])
    {
        t[r1]=r2;
    }
    else if(h[r1]>h[r2])
    {
        t[r2]=r1;
    }
    else
    {
        h[r2]++;
        t[r1]=r2;
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        h[i]=1;
    }
    for(int i=0;i<m;i++)
    {
        int op,x,y;
        fin>>op>>x>>y;
        if(op==1)
        {
            merger(x,y);
        }
        if(op==2)
        {
            if(root(x)==root(y))
            {
                fout<<"DA\n";
            }
            else fout<<"NU\n";
        }

    }
    fin.close();
    fout.close();
    return 0;
}
