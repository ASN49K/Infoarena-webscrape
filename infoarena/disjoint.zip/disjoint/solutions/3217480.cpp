#include <iostream>
using namespace std;

#define NMAX 100000

int n, m;
int rad[NMAX + 1];

void join(int x, int y) {
    y = rad[y];
    for (int i = 1; i <= n; i++) {
        if (rad[i] == y) {
            rad[i] = rad[x];
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);

    cin >> n >> m;

    for (int i = 1; i <= n; i += 1) {
        rad[i] = i;
    }

    for (int i = 0; i < m; i += 1) {
        int cod, x, y;
        cin >> cod >> x >> y;
        if (cod == 1) {
            join(x, y);
        } else {
            if (rad[x] == rad[y]) {
                cout << "DA\n";
            } else {
                cout << "NU\n";
            }
        }
    }

    return 0;
}