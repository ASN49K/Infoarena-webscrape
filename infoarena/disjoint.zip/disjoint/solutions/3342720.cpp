#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int parent[100001];

int sef(int a) {
    if (a == parent[a]){
        return a;
    } else {
        return parent[a] = sef(parent[a]);
    }
}

void join(int a, int b) {
    int pa = sef(a);
    int pb = sef(b);
    parent[pb] = pa;
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        parent[i] = i;
    }
    for (int i = 1; i <= m; i++) {
        int t, a, b;
        cin >> t >> a >> b;
        if (t == 1) {
            join(a, b);
        } else {
            int s1 = sef(a);
            int s2 = sef(b);
            if (s1 == s2) {
                cout << "DA\n";
            } else {
                cout << "NU\n";
            }
        }
    }
    return 0;
}