#include <bits/stdc++.h>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

struct Dsu{

    vector<int> par;
    vector<int> siz;

    Dsu(int n){
        par.resize(n+1);
        siz.resize(n+1);
        for(int i=1;i<=n;i++)
        {
            par[i]=i;
            siz[i]=1;
        }
    }

    int get_par(int x){
        if(par[x]==x) return x;
        return par[x]=get_par(par[x]);
    }

    bool same_par(int a, int b){
        return get_par(a) == get_par(b);
    }

    bool join(int a, int b){
        a=get_par(a);
        b=get_par(b);
        if(a==b) return 0;

        if(siz[a]<siz[b]) swap(a,b);

        par[b]=a;
        siz[a]+=siz[b];

        return 1;
    }

};

int main()
{
    int n,m;
    f>>n>>m;
    Dsu dsu = Dsu(n);
    int x,a,b;

    for(int i=0;i<m;i++)
    {
        f>>x;
        if(x==1)
        {
            f>>a>>b;
            dsu.join(a,b);
        }
        else
        {
            f>>a>>b;
            if(dsu.same_par(a,b))
            {
                g<<"DA\n";
            }
            else
            {
                g<<"NU\n";
            }
        }
    }
    return 0;
}
