#include <fstream>

using namespace std;

ifstream in ("disjoint.in");
ofstream out ("disjoint.out");

const int max_size = 1e5 + 1;

int t[max_size];

int rad (int x)
{
    if (x == t[x])
    {
        return x;
    }
    return t[x] = rad(t[x]);
}

int main ()
{
    int n, q;
    in >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        t[i] = i;
    }
    while (q--)
    {
        int op, x, y;
        in >> op >> x >> y;
        if (op == 1)
        {
            int rx = rad(x), ry = rad(y);
            t[rx] = ry;
        }
        else
        {
            int rx = rad(x), ry = rad(y);
            if (rx == ry)
            {
                out << "DA";
            }
            else
            {
                out << "NU";
            }
            out << '\n';
        }
    }
    in.close();
    out.close();
    return 0;
}
