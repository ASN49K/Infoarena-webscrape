#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int p[100001];
int gp(int i)
{
    if (i==p[i])return i;
    return p[i]=gp(p[i]);
}
void join(int x, int y)
{
    x=gp(x), y=gp(y);
    p[y]=x;
}
bool joined(int x, int y)
{
    return gp(x)==gp(y);
}
int main()
{
    int n, m;
    fin>>n>>m;
    for (int i=1; i<=n; ++i)p[i]=i;
    while (m--){
        int x, y, c;
        fin>>c>>x>>y;
        if (c==1){
            join(x, y);
        } else {
            fout<<(joined(x, y) ? "DA\n" : "NU\n");
        }
    }
    return 0;
}
