#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 100;
const int MMAX = NMAX * (NMAX - 1) / 2;
int t[NMAX + 5], h[NMAX + 5];

struct muchie
{
	int u, v, c;
	bool scl;
};

muchie mv[MMAX];

bool comp(muchie x, muchie y)
{
	return x.c < y.c;
}

int findr(int u)
{
	while (t[u] != u)
		u = t[u];
	return u;
}

void unire(int u, int v)
{
	int ru, rv;
	ru = findr(u);
	rv = findr(v);
	if (ru != rv)
	{
		if (h[ru] > h[rv])
			t[rv] = ru;
		else if (h[rv] > h[ru])
			t[ru] = rv;
		else
		{
			t[rv] = ru;
			h[ru]++;
		}
	}
}

int main()
{
	int n, m, i, j, c,shows=0;
	fin >> n >> m;
	for (i = 1; i <= m; i++)
	{
		t[i] = i;
	}
	for (i = 1; i <= m; i++)
	{
		fin >> mv[i].c >> mv[i].u >> mv[i].v;
		if (mv[i].c == 1)
			unire(mv[i].u, mv[i].v);
		else
		{
			if (findr(mv[i].u) == findr(mv[i].v))
				fout << "DA" << "\n";
			else
				fout << "NU" << "\n";
		}
	}
	return 0;
}