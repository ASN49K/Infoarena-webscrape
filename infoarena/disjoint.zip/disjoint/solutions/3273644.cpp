#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX=100005;
int n, m, o, x, y;
int parent[NMAX], status[NMAX];

int find_root(int nod){
    if(parent[nod]==nod) return nod;
    return find_root(parent[nod]);
}

void union_sets(int nod1, int nod2){
    nod1=find_root(nod1);
    nod2=find_root(nod2);
    if(nod1==nod2) return;
    if(status[nod1]<status[nod2]){
        swap(nod1,nod2);
    }
    if(status[nod1]==status[nod2])
        status[nod1]++;
    parent[nod2]=nod1;
}

int main(){
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        parent[i]=i;
        status[i]=1;
    }
    for(int i=1;i<=m;i++){
        fin>>o>>x>>y;
        if(o==1){
            union_sets(x,y);
        }
        else{
            if(find_root(x)==find_root(y)){
                fout<<"DA"<<endl;
            }
            else{
                fout<<"NU"<<endl;
            }
        }
    }
    return 0;
}
