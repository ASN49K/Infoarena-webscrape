#include <bits/stdc++.h>

using namespace std;

int lead[100005], depth[100005];

int find(int u){
    if(lead[u] == u) return u;
    return lead[u] = find(lead[u]);
}
void unite(int u, int v){
    u = find(u);
    v = find(v);
    if(u == v) return;
    if(depth[u] < depth[v]) swap(u, v);
    lead[v] = u;
    if(depth[u] == depth[v]) depth[u]++;
}

int main(){
    
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");
    
    int n, m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++){
        lead[i] = i;
        depth[i] = 1;
    }
    for(int i = 1; i <= m; i++){
        int t, x, y;
        cin >> t >> x >> y;
        if(t == 1){
            unite(x, y);
        }
        else{
            x = find(x);
            y = find(y);
            if(x == y)
                cout << "DA\n";
            else
                cout << "NO\n";
        }
    }
    return 0;
}