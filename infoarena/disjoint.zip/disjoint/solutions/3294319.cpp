﻿//ht
// tps://infoarena.ro/problema/disjoint
//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

vector <int> v[100005];
int b[100005];
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n, m, i, c, x, y;

	fin >> n >> m;
		
	for (i = 1; i <= n; ++i)
	{
		b[i] = i;
		v[i].push_back(i);
	}
		
	for (i = 1; i <= m; ++i)
	{
		fin >> c >> x >> y;

		if (v[x].size() < v[y].size())
		{
			swap(x, y);
		}

		if (c == 1)
		{
			for (auto it : v[y])
			{
				b[it] = x;
				v[x].push_back(it);
			}
		}
		else
		{
			if (b[x] == b[y])
				fout << "DA\n";
			else
				fout << "NU\n";
		}
	}
	return 0;
}
