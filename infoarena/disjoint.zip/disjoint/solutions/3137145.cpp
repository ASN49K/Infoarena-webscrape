#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int maxn = 1e5;
int root[maxn + 1];

int findRoot(int x) {
    if (root[x] == 0)
        return x;
    return root[x] = findRoot(root[x]);
}

void uniteRoots(int x, int y) {
    int rx = findRoot(x);
    int ry = findRoot(y);
    root[rx] = ry;
}

int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int op, x, y;
        fin >> op >> x >> y;
        if (op == 1) 
            uniteRoots(x, y);
        else {
            int rx = findRoot(x);
            int ry = findRoot(y);
            if (rx == ry)
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }

    return 0;
}