#include <fstream>
#define NMAX 100003
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout("disjoint.out");

int t[NMAX],n;
///radacina arborelui nu o sa mai aiba tatal 0 ci pe ea insasi t[radacina]=radacina;
void initializare()
{
    fin>>n;
    for(int i=1;i<=n;i++) t[i]=i;
}
int Find(int a)
{
    int x=a;
    /// din ce multime face parte x = radacina arborelui in care e x
    ///radacina arborelui este singura cu proprietatea ca t[i]=i;
    while(t[x]!=x) x=t[x];
    return x; ///returnam radacina
}
void Union(int x, int y)
{
    int rx=Find(x);
    int ry=Find(y);
    if(rx!=ry)
        t[rx]=ry; /// va face parte de acum din arborele lui y
}
int main()
{
    initializare();
    int m,cerinta,a,b;
    fin>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>cerinta>>a>>b;
        if(cerinta==1) Union(a,b);
        else
        {
            if(Find(a)==Find(b)) fout<<"DA";
            else fout<<"NU";
            fout<<'\n';
        }
    }
    return 0;
}
