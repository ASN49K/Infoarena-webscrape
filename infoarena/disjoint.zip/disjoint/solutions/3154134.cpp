#pragma GCC optimize("O2")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

struct DSU {
    int N;
    unordered_map<int, int> parent, sizes;
    void init(int n, int a[]) {
        N = n;
        for(int i = 1; i <= N; i++) {
            parent[a[i]] = a[i];
            sizes[a[i]] = 1;
        }
    }
    int find(int u) {
        if(u == parent[u]) {
            return u;
        }
        parent[u] = find(parent[u]);
        return parent[u];
    }
    void unite(int u, int v) {
        u = find(u);
        v = find(v);
        if(u == v) {
            return;
        }
        if(sizes[v] > sizes[u]) {
            swap(u, v);
        }
        parent[v] = u;
        sizes[u] += sizes[v];
    }
};

int main() {
    DSU thing;
    int N, M;
    cin >> N >> M;
    int op, x, y;
    int v[N + 5];
    for(int i = 1; i <= N; i++) {
        v[i] = i;
    }
    thing.init(N, v);
    for(int i = 1; i <= M; i++) {
        cin >> op >> x >> y;
        switch(op) {
            case 1:{
                thing.unite(x, y);
                break;
            }
            case 2:{
                if(thing.find(x) == thing.find(y)) {
                    cout << "DA" << endl;
                } else {
                    cout << "NU" << endl;
                }
                break;
            }
        }
    }
    return 0;
}