
#include <fstream>

#define NMAX 100020

using namespace std;

ifstream cin ("disjoint.in");
ofstream cout ("disjoint.out");

int TT[NMAX], RG[NMAX];
int N, M;

int find(int x)
{
	int R, y;
	//merg in sus pe arbore pana gasesc un nod care pointeaza catre el insusi
	for (R = x; TT[R] != R; R = TT[R]);
	//aplic compresia drumurilor
	while(TT[x] != x)
	{
		y = TT[x];
		TT[x] = R;
		x = y;
	}
	return R;
}

void unite(int x, int y)
{
	//unesc multimea cu rang mai mic de cea cu rang mai mare
	if (RG[x] > RG[y])
		TT[y] = x;
			else TT[x] = y;
	//in caz ca rangurile erau egale atunci cresc rangul noii multimi cu 1
	if (RG[x] == RG[y]) RG[y]++;
}

int main()
{
	cin>>N>>M;
	int i, x, y, cd;
	//initial fiecare nod pointeaza catre el insusi iar rangul fiecarui arbore este 1
	for (i = 1; i <= N; i++)
	{
		TT[i] = i;
		RG[i] = 1;
	}

	for (i = 1; i <= M; i++)
	{
		cin>>cd>>x>>y;
		if (cd == 2){
			//verific daca radacina arborilor in care se afla x respectiv y este egala
			if (find(x) == find(y)) cout<<"DA";
				else cout<<"NU";
		}
			else //unesc radacinile arborilor corespunzatori multimilor nodurilor x respectiv y
				{
					if (find(x) == find(y))	 {return 0;}
					unite(find(x), find(y));
				}
	}

	return 0;
}
