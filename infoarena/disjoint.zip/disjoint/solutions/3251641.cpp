#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int manager[100005];
int sef_suprem(int x){
    if (manager[x]==x)
        return x;
    return sef_suprem(manager[x]);
}
void unire(int x,int y){
    int sefx=sef_suprem(x);
    int sefy=sef_suprem(y);
    manager[sefy]=sefx;/// toti cei ce il au ca sef suprem pe sefx il vor avea acum pe sefy
}
int main(){
    int n,m,i,cod,x,y;
    fin>>n>>m;
    for (i=1;i<=n;i++)
        manager[i]=i;
    for (i=1;i<=m;i++){
        fin>>cod>>x>>y;
        if (cod==1)
            unire(x,y);
        else if (sef_suprem(x)==sef_suprem(y))
            fout<<"DA"<<'\n';
        else
            fout<<"NU"<<'\n';
    }
    return 0;
}
