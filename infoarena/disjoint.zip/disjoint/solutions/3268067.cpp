#include <iostream>
#include <fstream>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int MAX = 100000;
int n, m, tata[MAX+1];
void initial (int n)
{
    for(int i=0; i<n; ++i)
        tata[i]=i;
}
int findd (int x)
{
   if(tata[x]==x)
        return x;
   return tata[x]=findd(tata[x]);
}
void unio (int x, int y)
{
   int r1=findd(x);
   int r2=findd(y);
   if(r1!=r2)
      tata[r1]=r2;
}
int main()
{
    in>>n>>m;
    initial(n);
    for(int i=0; i<m; ++i)
    {
        int cod, x, y;
        in>>cod>>x>>y;
        if(cod==1)
            unio(x, y);
        else
        {
            if(findd(x)==findd(y))
                out<<"DA"<<'\n';
            else
                out<<"NU"<<'\n';
        }
    }
    return 0;
}
