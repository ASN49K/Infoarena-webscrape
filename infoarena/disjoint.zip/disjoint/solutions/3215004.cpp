#include <fstream>
#include <vector>
#include <queue>
using namespace std;
using pii = pair<int,int>;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
const int nmax = 1e5 + 1;
int t[nmax] , sz[nmax] , n , m , op , a , b;
int root(int x)
{
    if(!t[x]) return x;
    else return t[x] = root(t[x]);
}
void un(int x , int y)
{
    x = root(x);
    y = root(y);
    t[x] = y;
}
signed main()
{
    cin >> n >> m;
    for(int i = 1 ; i <= n ; ++i)
    {
        t[i] = 0;
        sz[i] = 1;
    }
    for(int i = 1 ; i <= m ; ++i)
    {
        cin >> op >> a >> b;
        if(op == 1) un(a,b);
        else if(root(a) == root(b)) cout << "DA" << '\n';
        else cout << "NU" << '\n';
    }
    return 0;
}

