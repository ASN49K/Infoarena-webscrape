#include <bits/stdc++.h>
#define FastIo() ios_base::sync_with_stdio(false), fin.tie(nullptr),fout.tie(nullptr);
#define ll long long 
#define pii pair<int,int>
#define pipii pair<int,pair<int,int>>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

//#define fin cin
//#define fout cout

struct DSU{
    vector<int> t;

    DSU(int _n){
        t.resize(_n+1);
        for(int i = 1;i <= _n;i++)
            t[i]=i;
    }

    int get_root(int x){
        if(t[x] != x) return t[x] = get_root(t[x]);
        return x;
    }
    void join(int x, int y){
        int root_x = get_root(x);
        int root_y = get_root(y);
        t[root_x] = root_y;
    }
    bool same_union(int x, int y){
        return (get_root(x) == get_root(y));
    }
};

int n, m;
int op, x, y;
int main(){
    fin>>n>>m;
    DSU dsu = DSU(n);
    for(int i=1;i<=m;i++){
        fin>>op>>x>>y;
        if(op==1){
            dsu.join(x,y);
        }else{
            if(dsu.same_union(x,y)) fout<<"DA\n";
            else fout<<"NU\n";
        }
    }
}