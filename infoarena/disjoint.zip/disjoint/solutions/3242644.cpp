#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax = 100000;


int t[nmax + 5];

int n,m;

int rad(int nod)
{
    int r = nod;
    while(t[r] > 0) r=t[r];
    while(nod !=r)
    {
        int aux = t[nod];
        t[nod] = r;
        nod = aux;
    }
    return r;
}
void join(int x,int y)
{
    int rx = rad(x),ry=rad(y);
    if(rx==ry) return ;
    if(-t[rx] < -t[ry]) swap(rx,ry);
    t[rx] += t[ry];
    t[ry]=rx;
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++) t[i]=-1;
    for(int i=1; i<=m; i++)
    {
        int tp;
        fin>>tp;
        if(tp==1)
        {
            int a,b;
            fin>>a>>b;
            join(a,b);
        }
        else
        {
            int a,b;
            fin>>a>>b;
            if(rad(a)==rad(b))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';

        }
    }

}
