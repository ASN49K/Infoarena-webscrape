#include <fstream>
using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int const N=100000;
int daddy[N+1], depth[N+1];

int find_root(int nod) {
    if (nod == daddy[nod])
        return nod;
    return daddy[nod]=find_root(daddy[nod]);
}

void unire(int x, int y) {
    if(depth[x]>depth[y])
        daddy[y]=x;
    else if(depth[x]<depth[y])
        daddy[x]=y;
    else {
        daddy[y]=x;
        depth[x]++;
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        daddy[i]=i;

    for(int i=1; i<=m; i++) {
        int cod, x, y;
        cin >> cod >> x >> y;
        if(cod == 1)
            unire(x,y);
        else if(cod == 2) {
            x=find_root(x);
            y=find_root(y);
            if(x==y)
                cout << "DA\n";
            else cout << "NU\n";
        }

    }
    return 0;
}
