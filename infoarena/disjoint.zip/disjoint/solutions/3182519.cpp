#include <bits/stdc++.h>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

int n, k, m[100005], t[100005], rang[100005];

void init (int n)
{
    for (int i=1; i<=n; i++)
        m[i]=t[i]=i;
}

int multime (int nod)
{
    if (t[nod]!=nod)
        t[nod]=multime(t[nod]);
    return t[nod];
}

void reuneste (int i, int j)
{
    i=multime(i);
    j=multime(j);
    if (i==j)
        return;
    if (rang[i]<rang[j])
        t[i]=j;
    else
        t[j]=i;
    if (rang[i]==rang[j])
        rang[i]++;
}

void task1 (int x, int y)
{
    reuneste(x,y);
}

void task2 (int x, int y)
{
    if (multime(x)==multime(y))
        fout << "DA" << '\n';
    else
        fout << "NU" << '\n';
}

void solve ()
{
    int a, x, y;
    fin >> n >> k;
    init(n);
    for (int i=1; i<=k; i++)
    {
        fin >> a >> x >> y;
        if (a==1)
            task1(x,y);
        else
            task2(x,y);
    }
}

int main()
{
    solve();
    return 0;
}
