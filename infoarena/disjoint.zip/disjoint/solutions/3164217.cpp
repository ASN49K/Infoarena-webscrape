#include <fstream>
#include <vector>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n;
struct DSU
{
    vector < int > parent, sizes;

    void init()
    {
        parent.resize(n + 1);
        sizes.resize(n + 1);
        for(int i = 1; i <= n; i++)
        {
            parent[i] = i;
            sizes[i] = 1;
        }
    }

    int find(int u)
    {
        if(u == parent[u])
            return u;
        parent[u] = find(parent[u]);
        return parent[u];
    }

    void unite(int u, int v)
    {
        u = find(u);
        v = find(v);
        if(u == v)
            return;
        if(sizes[v] > sizes[u])
            swap(u, v);
        parent[v] = u;
        sizes[u] += sizes[v];
        sizes[v] = 0;
    }
} dsu;
int main()
{
    int m, ok, a, b;
    cin >> n >> m;
    dsu.init();
    while(m--)
    {
        cin >> ok >> a >> b;
        if(ok == 1) ///unite
            dsu.unite(a, b);
        else
        {
            a = dsu.find(a);
            b = dsu.find(b);
            if(a == b)
                cout << "DA\n";
            else
                cout << "NU\n";
        }
    }
    return 0;
}
