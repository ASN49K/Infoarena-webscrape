#include <bits/stdc++.h>

std :: ifstream in ("disjoint.in");

std :: ofstream out ("disjoint.out");

const int NMAX = 1e5 + 5;

int n;

int m;

int x;

int y;

int cer;

int parent[NMAX];

int h[NMAX];

int getroot(int x)
{
    if(parent[x] == x)
    {
        return x;
    }

    parent[x] = getroot(parent[x]);

    return parent[x];
}

int main()
{

    in >> n >> m;

    for(int i = 1; i <= n; i ++)
    {
        parent[i] = i;

        h[i] = 1;
    }

    for(int i = 1; i <= m; i ++)
    {
        in >> cer >> x >> y;

        x = getroot(x);

        y = getroot(y);

        if(cer == 1)
        {
            if(h[x] < h[y])
            {
                parent[x] = y;
            }
            else if(h[x] > h[y])
            {
                parent[y] = x;
            }
            else
            {
                parent[x] = y;

                h[y] ++;
            }
        }
        else
        {
            if(x == y)
            {
                out << "DA" << '\n';
            }
            else
            {
                out << "NU" << '\n';
            }
        }
    }

    return 0;
}
