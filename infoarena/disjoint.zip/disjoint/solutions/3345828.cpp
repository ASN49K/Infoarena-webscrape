#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,m;

int get_root(int nod, vector<int> &tata)
{
    if(tata[nod] == -1)
        return nod;
    return tata[nod] = get_root(tata[nod], tata);
}
void combine(int x, int y,  vector<int> &tata)
{
    tata[x] = get_root(y, tata);
}
int main()
{
    fin >> n >> m;
    vector<int> tata(n + 1, -1);
    while(m--)
    {
        int query,x,y;
        fin >> query >> x >> y;
        if(query == 1)
        {
            combine(get_root(x, tata), get_root(y, tata), tata);
        }
        else
        {
            if(get_root(x,tata) == get_root(y,tata))
            fout << "DA" << '\n';
            else
                fout << "NU" << '\n';
        }
    }
    return 0;
}
