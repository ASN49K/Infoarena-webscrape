#include <fstream>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int sef[101] ,n ,m ,o,x,y;
int boss(int x)
{
    if(sef[x]==x)
        return x;
    else
        return sef[x]=boss(sef[x]);
}
void unire(int x ,int y)
{
    int sef_x=boss(x);
    int sef_y=boss(y);
    sef[sef_y]=sef_x;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        sef[i]=i;
      for(int i=1;i<=m;i++)
      { cin>>o>>x>>y;
           if(o==1&&boss(x)!=boss(y))
            unire(x,y);
           if(o==2)
            if(boss(x)==boss(y))
                cout<<"Da"<<'\n';
                   else
                 cout<<"Nu"<<'\n';

      }
    return 0;
}
