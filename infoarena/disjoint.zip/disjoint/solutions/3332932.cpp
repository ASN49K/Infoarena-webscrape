// https://infoarena.ro/problema/disjoint - Szücs Patrik - Kevin
#include <fstream>
#include <vector>

#define st first
#define nd second

int main()
{
    int n, m;

    std::ifstream in("disjoint.in");
    std::ofstream out("disjoint.out");
    in >> n >> m;

    //                   size, parent
    std::vector<std::pair<int, int>> set(n);
    for (int i = 0; i < n; i++)
    {
        set[i].st = 1;
        set[i].nd = i;
    }

    while (m--)
    {
        int x, y, t;
        in >> t >> x >> y;
        x--;
        y--;

        if (t == 1)
        {
            while (set[x].nd != x)
                x = set[x].nd;

            while (set[y].nd != y)
                y = set[y].nd;

            if (x != y)
            {
                if (set[x].st < set[y].st)
                    std::swap(x, y);

                set[y].nd = x;
                set[x].st += set[y].st;
            }
        }
        else
        {
            while (set[x].nd != x)
                x = set[x].nd;

            while (set[y].nd != y)
                y = set[y].nd;

            if (set[x].nd == set[y].nd)
                out << "DA\n";
            else
                out << "NU\n";
        }
    }

    return 0;
}