#include <bits/stdc++.h>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int n,m,i,c,x,y,t[100001],v[100001];
vector <int> a[100001];
int rad(int k){
    int x=k,y;
    while(t[k]) k=t[k];
    while(x!=k){
        y=x; x=t[x]; t[y]=k;
    }
    return k;
}
int uni(int k,int p){
    if(v[k]==v[p]) v[k]++;
    if(v[k]>v[p]) t[p]=k;
    else t[k]=p;
}
int main()
{
    f>>n>>m;
    for(i=1;i<=n;++i) v[i]=1,t[i]=0;
    for(i=1;i<=m;++i){
        f>>c>>x>>y;
        if(c==1){
            //a[x].push_back(y); a[y].push_back(x);
            x=rad(x); y=rad(y);
            if(x!=y) uni(x,y);
        }
        else{
            if(rad(x)==rad(y)) g<<"DA\n";
            else g<<"NU\n";
        }
    }
    return 0;
}
