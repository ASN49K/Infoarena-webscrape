#include<fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int rad[100001],card[100001],c,w,z,n,q;
//prima optimizare, se uneste multimea mai mica la multimea mai mare
//se uneste multimea cu radacina in a cu cea care are radacina in b;
void Unire(int a, int b){
    if(card[b]>card[a]){
        swap(a,b);
    }
    rad[b]=a;
    card[a]+=card[b];
}
//gasim radacina unei multimi
int Gasire(int x){
    if(rad[x]==x)
        return x;
    // se reactualizeaza radacina elementelor, o alta optimizare
    rad[x]=Gasire(rad[x]);
    return rad[x];
}
int main()
{
    cin>>n>>q;
    //initializare multimi,fiecare element face parte din propria multime ceea ce duce la cardinal de multime 1
    for(int i=1;i<=n;i++){
        rad[i]=i;
        card[i]=1;
    }
    for(int i=1;i<=q;i++){
        cin>>c>>w>>z;
        if(c==1){
            Unire(w,z);
        }
        else{
            if(Gasire(w)==Gasire(z))
                cout<<"DA";
            else
                cout<<"NU";
            cout<<'\n';
        }
    }
    return 0;
}
