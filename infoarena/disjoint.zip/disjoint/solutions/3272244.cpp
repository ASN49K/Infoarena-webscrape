#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n, m, c, x, y, T[100001], Rang[100001];

int Radacina(int k){
    if(T[k] == 0)
        return k;
    else
        return Radacina(T[k]);
}

void Unire(int k, int p)
{
    int rk = Radacina(k), rp = Radacina(p);
    if(rk != rp)
        T[rk] = rp;
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>c>>x>>y;
        if(c==1)
        {
            Unire(x, y);
        }
        else
        {
            if(Radacina(x)==Radacina(y)) cout<<"DA"<<'\n';
            else cout<<"NU"<<'\n';
        }
    }
    return 0;
}
