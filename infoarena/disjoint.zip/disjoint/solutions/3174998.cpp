#include <bits/stdc++.h>
#define ll long long
#define eb emplace_back
#define pii pair<int, int>
#define tpl tuple<int,int,int>
using namespace std;

const string fn("disjoint");

ifstream in(fn + ".in");
ofstream out(fn + ".out");

#define cin in
#define cout out

const int MAX=2e5;

int n,m,x,y,q,t[MAX+5];
ll sum;
vector<tpl> v;
vector<pii> ans;

int rad(int k)
{
    if(k==t[k]) return k;
    else return t[k]=rad(t[k]);
}

void marea_unire(int a,int b)
{
    if(t[a]<=t[b])
        t[b]=t[a];
    else t[a]=t[b];
}


int main()
{
    cin>>n>>m;

    for(int i=1;i<=n;i++)
        t[i]=i;
    
    while(m--)
    {
        cin>>q>>x>>y;

        if(q==1)
        {
            int r1=rad(x),r2=rad(y);
            if(r1!=r2)
                marea_unire(r1,r2);
        }
        else
        {
            int r1=rad(x),r2=rad(y);
            cout<<(r1!=r2 ? "NU\n" : "DA\n");
        }
    }
    return 0;
}