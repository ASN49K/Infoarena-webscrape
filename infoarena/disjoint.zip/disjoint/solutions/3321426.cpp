#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
#define N 100005
int n, m, R[N];
int main()
{
    fin >> n >> m;
    int op, x, y;
    for(int i = 1; i <= n; i++)
       R[i] = i;
    for(int i = 1; i <= m; i++)
    {
        fin >> op >> x >> y;
        if(op == 2)
            if(R[x] == R[y])
                fout << "DA\n";
            else fout << "NU\n";
        else
        {
            for(int j = 1; j <= n; j++)
                if(R[j] == R[x])
                    R[j] = R[y];
        }
    }
    return 0;
}
