#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int maxsize=1e5+4;
int t[maxsize];

int rad(int x){
    if(t[x]==x) return x;
    return rad(t[x]);
}

int main(){
    int n, m;
    cin>>n>>m;
    for(int i=1; i<=n; i++) t[i]=i;
    while(m--){
        int cod, x, y;
        cin>>cod>>x>>y;
        int rx=rad(x), ry=rad(y);
        if(cod==1)
            t[rx]=ry;
        else{
            if(rx==ry) cout<<"DA\n";
            else cout<<"NU\n";
        }
    }
    return 0;
}
