﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 100006
#define MOD 1999999973
#define INF 2012345678
#define ll long long
using namespace std;
//#define fin cin
//#define fout cout

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m;
int t[nmax];

int FindRoot(int x)
{
	int y, rad;
	rad = x;
	while (t[rad] != 0)
		rad = t[rad];
	
	while (x != rad)
	{
		y = t[x];
		t[x] = rad;
		x = y;
	}
	return rad;
}

void Union(int x, int y)
{
	t[y] = x;
}

int main()
{
	int i, x, y, t;
	fin >> n >> m;
	while (m--)
	{
		fin >> t >> x >> y;
		x = FindRoot(x);
		y = FindRoot(y);
		if (t == 1)
			Union(x, y);
		else
		{
			if (x == y)
				fout << "DA\n";
			else
				fout << "NU\n";
		}
	}
	fin.close();
	fout.close();
	return 0;
}