#include <fstream>


using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n;
short int parent[100001],marimi[100001];
int cnt,Max=-1;


int find(int x)
{
    if(parent[x]==x)
    {
        return x;
    }
    return parent[x]=find(parent[x]);
}

int unite(int a,int b)
{
    a=find(a);
    b=find(b);

   if(marimi[a]>marimi[b])
   {
     swap(a,b);
   }
   if(a!=b)
   {
       marimi[b]+=marimi[a];

       parent[a]=b;

   }
   return 0;

}

int main()
{
    int n,q;
    cin>>n>>q;
    cnt=n;
    for(int i=1;i<=n;i++)
    {
        parent[i]=i;
        marimi[i]=1;
    }
    for(int i=1;i<=q;i++)
    {
        int a,b,x;
        cin>>x>>a>>b;
        if(x==1)
        {
             unite(a,b);
        }
        else
        {
            if(find(a)==find(b))
            {
                cout<<"DA"<<'\n';
            }
            else
            {
                cout<<"NU"<<'\n';
            }
        }

    }





}
