
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int n, m;
int t[100005], r[100005];

void init() {
    for(int i = 1;i <= n;++i) {
        t[i] = i;
        r[i] = 1;
    }
}

void unite(const int& x, const int& y) {
    if(r[x] > r[y]) {
        r[x] += r[y];
        t[y] = x;
        return;
    }
    r[y] += r[x];
    t[x] = y;
}

int query(const int& x) {
    if(t[x] == x) {
        return x;
    }

    return t[x] = query(t[x]);
}

void solve() {
    f>>n>>m;
    init();
    int x, y, z;

    for(int i = 1;i <= m;++i) {
        f>>x>>y>>z;
        if(x == 1) {
            unite(y, z);
            continue;
        }
        if(query(y) == query(z)) {
            g<<"DA\n";
            continue;
        }
        g<<"NU\n";
    }
}

int main() {

    solve();
    return 0;
}