#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int card[100002],rad[100002];

void uunion(int x,int y){
    if(card[x]<card[y])
    swap(x,y);
    rad[y]=x;
    card[x] +=card[y];
}

int ffind(int x){
    if (rad[x]==x)
        return x;
    rad[x]=ffind(rad[x]);
    return rad[x];
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        rad[i]=i;
        card[i]=1;
    }

    for(int i=1;i<=m;i++){
        int c,x,y,find1,find2;
        cin>>c>>x>>y;
        find1=ffind(x);
        find2=ffind(y);
        if(c==1 and find1!=find2)
        uunion(find1,find2);
        else{
            if(find1==find2)
            cout<<"DA\n";
            else
            cout<<"NU\n";
        }
    }
}
