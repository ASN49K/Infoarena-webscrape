#include <bits/stdc++.h>
using namespace std;

void file_in(string name) {
    freopen((name + ".in").c_str(), "r", stdin);
    freopen((name + ".out").c_str(), "w", stdout);
}

const int N = 100100;
vector<int> t(N, 0), h(N, 1);

int radacina(int x) {
    if(t[x] == 0)
        return x;

    return radacina(t[x]);
}

void reuniune(int x, int y) {
    int rx = radacina(x), ry = radacina(y);

    if(h[rx] < h[ry]) {
        t[rx] = ry;
    } else {
        t[ry] = rx;
        if(h[rx] == h[ry]) {
            h[rx]++;
        }
    }

}

bool interogare(int x, int y) {
    return (radacina(x) == radacina(y));
}

int main() {
    file_in("disjoint");

    int n, m;
    cin >> n >> m;

    for(int i = 1; i <= m; i++) {
        int cod, x, y;
        cin >> cod >> x >> y;

        if(cod == 1) {
            reuniune(x, y);
        } else {
            cout << (interogare(x, y) ? "DA\n" : "NU\n");
        }
    }
}