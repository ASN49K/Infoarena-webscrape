#include <fstream>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,m, t[100005], gr[100005], tip,x,y;
int rad(int nod){
    int x=nod;
    while(x!=t[x])
        x=t[x];
    while(nod!=t[nod]){
        int c=t[nod];
        t[nod]=x;
        nod=c;
    }
    return x;
}
void unire(int x, int y){
    if(gr[x]<gr[y]){
        t[x]=y;
    }
    else t[y]=x;
    if(gr[x]==gr[y])
        gr[y]++;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n;i++){
        t[i]=i;
        gr[i]=1;
    }
    while(m--){
        cin>>tip>>x>>y;
        if(tip==1)
            unire(rad(x), rad(y));
        else{
            if(rad(x)==rad(y)) cout<<"DA\n";
                else cout<<"NU\n";
        }
    }
    return 0;
}
