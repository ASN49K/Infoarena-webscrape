#include <fstream>
using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

int sef[100001], n, m, c, x, y;
int bos (int x)
{
    if(sef[x] == x)
			   return x;
		else
			   return sef[x] = bos(sef[x]);
}

void uni(int x, int y)
{
	  int sefx = bos(x);
	  int sefy = bos(y);
	  sef[sefy] = sefx;
}

int main()
{
        fin >> n >> m;
		for(int i = 1; i <= n; i++)
				sef[i] = i;
		for(int i = 1; i <= m; i++){
				fin >> c >> x >> y;
				if (c == 1)
						uni(x, y);
				else{
						if (bos(x) == bos(y))
								fout << "DA" << '\n';
						else
								fout << "NU" << '\n';
		} }
    return 0;
}
