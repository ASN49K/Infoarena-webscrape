#include <bits/stdc++.h>
//#pragma GCC optimize("O3,unroll-loops")
//#pragma GCC target("avx2,bmi,bmi2,popcnt,lzcnt")

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n,m;
vector<int> t(100001,-1);

int getRoot(int node) {
    while (t[node] > 0) {
        node = t[node];
    }
    return node;
}

void connect(int a, int b) {
    const int rootA = getRoot(a);
    const int rootB = getRoot(b);
    if (rootA == rootB) {
        return;
    }
    if (rootA > rootB) {
        t[rootB] += t[rootA];
        t[rootA] = rootB;
    } else {
        t[rootA] += t[rootB];
        t[rootB] = rootA;
    }
}
const string ans[] = {"NU\n","DA\n"};
int main() {
    fin >> n >> m;
    while (m--) {
        int t,a,b;
        fin >> t >> a >> b;
        if (t == 1) {
            connect(a,b);
        } else {
            //fout << ans[getRoot(a) == getRoot(b)];
        }
    }
    return 0;
}
