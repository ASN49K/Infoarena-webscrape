#include <bits/stdc++.h>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int repr[200009], dim[200009];
int get_repr (int x)
{
    if (x==repr[x]) return x;
    repr[x]=get_repr(repr[x]);
    return repr[x];
}
void join (int x, int y)
{
    x=get_repr(x), y=get_repr(y);
    if (x>y) swap (x,y);
    if (x==y) return;
    repr[y]=x;
    dim[x]+=dim[y];
}
signed main ()
{
    int n, m;
    f >> n >> m;

    for (int i=1; i<=n; i++)
        dim[i]=i, repr[i]=i;
    while (m--)
    {
        int op, x, y;
        f >> op >> x >> y;
        if (op==1) join (x, y);
        else
        {
            if (get_repr(x)==get_repr(y)) g << "DA\n";
            else g << "NU\n";
        }
    }
}
