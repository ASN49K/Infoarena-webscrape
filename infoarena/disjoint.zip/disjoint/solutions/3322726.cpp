#include <fstream>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
const int NMax=100000;
int n, m, t[NMax+5];

void op1(int a, int b)
{
    t[a] = b;
}
int Root(int a)
{
    int ca=a;
    while(t[ca]!=ca)
    {
        ca=t[ca];
        if(ca==t[ca])
        {
            return ca;
        }
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        t[i]=i;
    for(int i=1;i<=m;i++)
    {
        int cer, x, y;
        cin>>cer>>x>>y;
        if(cer==1) op1(Root(x),Root(y));
        else if(Root(x)==Root(y)) cout<<"DA"<<'\n';
        else cout<<"NU"<<'\n';

    }
}
