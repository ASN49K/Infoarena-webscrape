#include <bits/stdc++.h>

using namespace std;
int parent[100005];

int find(int x) {
  if (parent[x] != x)
    return find(parent[x]);
  return x;
}

void join(int x, int y) { parent[find(x)] = find(y); }
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  ifstream cin("disjoint.in");
  ofstream cout("disjoint.out");
  int n, m;
  cin >> n >> m;
  for (int i = 1; i <= n; i++)
    parent[i] = i;
  int type, x, y;
  while (m--) {
    cin >> type >> x >> y;
    if (type == 1) {
      join(x, y);
    } else {
      if (find(x) == find(y))
        cout << "DA\n";
      else
        cout << "NU\n";
    }
  }
}