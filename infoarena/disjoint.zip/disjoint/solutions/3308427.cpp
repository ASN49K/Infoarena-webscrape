#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

// comentam putin

int n, m;
int tatici[100001], rep[100001];

// aici initializam, avem cate un arbore
// fiecare arbore are un membru, adica el
// de aceea tatici[i] = i
// rep[i] = 1, memoreaza cate noduri are fiecare arbore in parte
void init() {
    for(int i = 1; i <= n; i++) {
        tatici[i] = i;
        rep[i] = 1;
    }
}

// cautam radacina fiecarui arbore
int cauta(int x) {
    if (tatici[x] != x) {
        tatici[x] = cauta(tatici[x]);
    }
    return tatici[x];
}

// unim radacinile fiecarui arbore
void unire(int x, int y) {
    x = cauta(x);
    y = cauta(y);
    // bagam arborele mic in cel mare
    // aici doar vedem sa nu fie invers
    if(rep[x] < rep[y]) {
        swap(x, y);
    }
    // taticu lu y este amu x
    tatici[y] = x;
    // arborele x are acum + rep[y] noduri
    rep[x] += rep[y];
}

int main()
{
    fin >> n >> m;

    init();

    for(int i = 1; i <= m; i++) {
        int op, x, y;
        fin >> op >> x >> y;
        if(op == 1) {
            unire(x, y);
        } else {
            if(cauta(x) == cauta(y)) fout << "DA" << '\n';
            else fout << "NU" << '\n';
        }
    }
    return 0;
}
