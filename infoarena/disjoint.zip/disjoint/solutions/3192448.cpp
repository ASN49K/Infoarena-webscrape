
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int i, p[100001], cod, x, y, n, m, o;

void Union (int r1, int r2) { // Se reunesc multimile cu radacinile r1 si r2.
    p[r2] = r1;
}

int FindSet (int nod) {
  while (p[nod] != nod)
    nod = p[nod];
  return p[nod];
}

int main () {
  fin >> m >> o;
  for (i = 1; i <= m; i++)
    p[i] = i;
  while (o--) {
    fin >> cod >> x >> y;
    if (cod == 1)
      Union(FindSet(x), FindSet(y));
    else
      if (FindSet(x) == FindSet(y))
        fout << "DA\n";
      else
        fout << "NU\n";
  }
  return 0;
}
