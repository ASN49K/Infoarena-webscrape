#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 100000;
int t[NMAX + 5], h[NMAX + 5];

int findr(int u)
{
    while (t[u] != u)
        u = t[u];
    return u;
}

void unire(int u, int v)
{
    int ru, rv;
    ru = findr(u);
    rv = findr(v);
    if (h[ru] > h[rv])
        t[rv] = ru;
    else
        if (h[rv] > h[ru])
            t[ru] = rv;
        else
        {
            t[rv] = ru;
            h[ru]++;
        }
}

int main()
{
    int n, m, i, x, y, cod;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        t[i] = i;
    }
    for (i = 1; i <= m; i++)
    {
        fin >> cod >> x >> y;
        if (cod == 1)
            unire(x, y);
        else
            if (findr(x) == findr(y))
                fout << "DA" << "\n";
            else
                fout << "NU" << "\n";
    }
    return 0;
}