#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, q, tata[8010], T, x, y;

int Find(int a, int tata[]) {
    int b = a, t;
    while(b != tata[b]) b = tata[b];
    while(a != b) {
        t = tata[a];
        tata[a] = b;
        a = t;
    }
    return a;
}

int Unite(int a, int b, int tata[]) {
    a = Find(a, tata);
    b = Find(b, tata);
    tata[b] = a;
}

int main()
{
    fin >> n >> q;
    for(int i=1; i<=n; i++) tata[i] = i;
    for(int i=1; i<=q; i++) {
        fin >> T >> x >> y;
        if(T == 1 && Find(x, tata) != Find(y, tata)) Unite(x, y, tata);
        else {
            if(Find(x, tata) == Find(y, tata)) fout << "DA" << '\n';
            else fout << "NU" << '\n';
        }
    }

    return 0;
}
