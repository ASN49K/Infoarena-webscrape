#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int sz[100005];
int tata[100005];

int repr(int x)
{
    while(x!=tata[x])
        x=tata[x];
    return x;
}

void update(int a, int b)
{
    int x=repr(a);
    int y=repr(b);
    if(sz[x]<sz[y])
        swap(x,y);
    tata[x]=y;
    sz[y]+=sz[x];
}

string query(int a, int b)
{
    if(repr(a)==repr(b))
        return "DA";
    return "NU";
}




int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        tata[i]=i,sz[i]=1;
    for(int i=0;i<m;i++)
    {
        int a,b,c;
        cin>>a>>b>>c;
        if(a==1)
            update(b,c);
        else
            cout<<query(b,c)<<'\n';
    }
}
