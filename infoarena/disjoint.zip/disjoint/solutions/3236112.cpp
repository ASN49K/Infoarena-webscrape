#include <fstream>
#define NMAX 100000
using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

int tata[NMAX + 1], rang[NMAX + 1];

int Find (int x){
    if (tata[x]){
        int root = Find(tata[x]);
        x = root;
        return root;
    }
    return x;
}

void Union (int x, int y){
    if (rang[x] > rang[y]){
         tata[y] = x;
    }
    else{
        if (rang[x] == rang[y]){
            ++rang[y];
        }
        tata[x] = y;
    }
}

int main() {

    int m;

    in >> m >> m;

    while (m--){
        int cod, x, y;
        in >> cod >> x >> y;

        if (cod == 1){
            Union(Find(x), Find(y));
        }
        else{
            out << (Find(x) == Find(y) ? "DA\n" : "NU\n");
        }
    }

    return 0;
}
