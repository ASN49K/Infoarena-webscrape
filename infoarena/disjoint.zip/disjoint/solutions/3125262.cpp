#include <bits/stdc++.h>
using namespace std;

ifstream f ("disjoint.in");
ofstream g ("disjoint.out");

const int nmax = 1e5 + 3;

int v[nmax], a, b, c, n, k;

int root(int nod)
{
    if (v[nod] == nod)
        return nod;

    v[nod] = root(v[nod]);
    return v[nod];
}

int main()
{
    f >> n >> k;

    for (int i = 1; i <= n; ++i)
        v[i] = i;

    while (k--)
    {
        f >> a >> b >> c;
        if (a == 2)
        {
            if (root(b) == root(c))
                g << "DA\n";
            else
                g << "NU\n";
        }
        else v[root(b)] = root(c);
    }

    return 0;
}
