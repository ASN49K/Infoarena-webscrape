#include <bits/stdc++.h>

using namespace std;
const int N = 100008;

int n, m, parent[N], siz[N], op, x, y;

void make_set(int v);
void union_set(int x, int y);
int find_root(int x);

int main() {
    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        make_set(i);
    for (int i = 1; i <= m; i++) {
        cin >> op >> x >> y;
        if (op == 1)
            union_set(x, y);
        else {
            if (find_root(x) != find_root(y))
                cout << "NU\n";
            else
                cout << "DA\n";
        }
    }
    return 0;
}

void make_set(int v) {
    parent[v] = v;
    siz[v] = 1;
}

int find_root(int x) {
    if (parent[x] == x)
        return x;
    else
        return parent[x] = find_root(parent[x]);
}

void union_set(int x, int y) {
    int a = find_root(x);
    int b = find_root(y);
    if (a != b) {
        if (siz[a] < siz[b])
            swap(a, b);
        parent[b] = a;
        siz[a] += siz[b];
    }
}
