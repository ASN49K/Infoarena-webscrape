#include<iostream>
#include<fstream>
#include<vector>
#include<cmath>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax = 100000;
int n,m;
vector<int> tata(nmax,0);

int main(){
    fin>>n>>m;

    for(int i = 1; i <= m; i++){
        int x,y,z;
        fin>>z>>x>>y;
        if(z == 1){
        int a = min(x,y), b = max(x,y);
        tata[b] = a;
        }
        else{
            int tx = x, ty = y;
            while(tata[tx] != 0)tx = tata[tx];

            while(tata[ty] != 0)ty = tata[ty];

            if(tx == ty)fout<<"DA\n";
            else fout<<"NU\n";
        }

    }
}
