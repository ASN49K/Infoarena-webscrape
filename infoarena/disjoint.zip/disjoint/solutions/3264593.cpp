#include <bits/stdc++.h>
#define nmax 100005
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,m,t[nmax],task,a,b;
int get_root(int x)
{
    while(t[x]!=0)
        x=t[x];
    return x;
}
void join(int x ,int y)
{
    int rx=get_root(x),ry=get_root(y);
    t[rx]=ry;
}
int main()
{
    fin>>n>>m;
    while(m--)
    {
        fin>>task>>a>>b;
        if(task==1)
            join(a,b);
        else
            if(get_root(a)==get_root(b))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
    }
    return 0;
}
