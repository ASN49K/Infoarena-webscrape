#include <bits/stdc++.h>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int N = 100'005;
int t[N], h[N];
int radacina(int nod)
{
    if(t[nod] == 0)
    {
        return nod;
    }
    return t[nod] = radacina(t[nod]);
}
int main(){
      int tip, n, m, x, y;
      in >> n >> m;

      for(int i = 1; i <= m; i++)
      {
        in >> tip >> x >> y;
        int rx = radacina(x), ry = radacina(y);
        if(tip == 1)
        {
            if(h[rx] >= h[ry])
            {
                t[ry] = rx;
                if(h[rx] == h[ry])
                {
                    h[rx]++;
                }
            }
            else
            {
                t[rx] = ry;
            }
        }
        else
        {
            if(rx == ry)
            {
                out << "DA" << "\n";
            }
            else
            {
                out << "NU" << "\n";
            }
        }

      }
      in.close();
      out.close;



    return 0;
}
