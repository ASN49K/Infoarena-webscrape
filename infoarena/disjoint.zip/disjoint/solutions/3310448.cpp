#include<bits/stdc++.h>

using namespace std;

const int NMAX = 1e5 + 5;
int n, m, tata[NMAX], sz[NMAX];
vector<pair<int, int>> v[NMAX];

int getTata(int x)
{
    while(x != tata[x])
        x = tata[x];
    return x;
}

void cerinta1(int a, int b)
{
    if(sz[a] > sz[b])
        swap(a, b);
    
    a = getTata(a);
    b = getTata(b);

    tata[a] = b;
    sz[b]++;
}

string cerinta2(int a, int b)
{
    a = getTata(a);
    b = getTata(b);

    if(a == b)
        return "DA\n";
    return "NU\n";
}

int main()
{
    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);

    cin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        tata[i] = i;
        sz[i] = 1;
    }

    int c, a, b;
    for(int i = 1; i <= m; i++)
    {
        cin >> c >> a >> b;
        if(c == 1)
            cerinta1(a, b);
        else
            cout << cerinta2(a, b);
    }
}