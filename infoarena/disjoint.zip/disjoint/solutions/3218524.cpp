#include <fstream>
#define NMAX 100000
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[NMAX];
int h[NMAX]; ///h[i]=inaltimea arborelui cu radacina i
int cod, a, b, n, m;
void Union(int x, int y)
{
    if(h[x]<h[y])
      {tata[x]=y;}
    else
        if(h[y]<h[x])
        {tata[y]=x;}
    else
    {tata[y]=x;h[y]++;}
}
int Find(int x)
{int r, y;
    ///mai intai aflu radacina arborelui din care face parte x
    r=x;
    while(tata[r]!=r) r=tata[r];
    ///parcurg din nou drumul de la x la r si fac toate nodurile fii ai lui r
    do{
       y=tata[x];
       tata[x]=r;
       x=y;
    }while(tata[x]!=r);
    return r;
}
int main()
{
    fin>>n>>m;
    ///fac niste union si find si afisez
    for(int i=1;i<=n;i++)
    {tata[i]=i;h[i]=1;}
    for(int i=1;i<=m;i++)
    {
        fin>>cod>>a>>b;
        if(cod==1)
        {
            int ra=Find(a);
            int rb=Find(b);
            Union(ra,rb);
        }
        if(cod==2)
        {
            if(Find(a)==Find(b))
                fout<<"DA";
            else fout<<"NU";
            fout<<'\n';
        }
    }
    return 0;
}
