#include <bits/stdc++.h>
using namespace  std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int maxn = 1e5 + 2;
const int maxm = 2e5 + 2;
const int mod = 666013;
#define ll  long long

int t[maxn + 2], rang[maxn + 2];
int n, m;


int get_root(int i){
    if(t[i] == i)
        return i;
    return t[i] = get_root(t[i]);
}
void unite(int i, int j){
    if(rang[i] > rang[j])
        t[j] = i;
    else{
        t[i] = j;
        if(rang[i] == rang[j])
            rang[i]++;
    }
}
void init(){
    for(int i = 1; i <= n; ++i)
        rang[i] = 1, t[i] = i;
}
int main(){
    fin >> n >> m;
    init();
    for(int i = 1; i <= m; ++i){
        int task, x, y;

        fin >> task >> x >> y;
        if(task == 1){
            unite(get_root(x), get_root(y));
        }
        else{
            if(get_root(x) == get_root(y))
                fout << "DA \n";
            else fout << "NU \n";
        }
    }
    return 0;

}
/*


*/