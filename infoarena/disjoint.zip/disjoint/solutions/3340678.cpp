#include <fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
#define cin fin
#define cout fout
const int NMAX=100001;
int N, M, T[NMAX+1], Sz[NMAX+1];
int Find(int x)
{
    if (T[x]==0) return x;
    return T[x]= Find(T[x]);
}
void Union(int rx, int ry)
{
    if (Sz[rx]<Sz[ry])
    {
        T[rx]=ry;
        Sz[ry]+=Sz[rx];
    }
    else
    {
        T[ry]=rx;
        Sz[rx]+=Sz[ry];
    }
}
int main()
{
    int cod, x, y, rx, ry;
    cin>>N>>M;
    for (int i=1; i<=N; ++i)
        Sz[i]=1;
    while (M--)
    {
        cin>>cod>>x>>y;
        rx=Find(x);
        ry=Find(y);
        if (cod==1)
            Union(rx, ry);
        else if (rx==ry) cout<<"DA\n";
        else cout<<"NU\n";
    }
    return 0;
}
