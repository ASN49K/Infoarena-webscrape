#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;
typedef long long ll;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

vector<int>parent;
int n, m;

void make_root(int nod) {
	parent[nod] = nod;
}

int get_root(int nod) {
	if (parent[nod] == nod)
		return nod;
	return parent[nod]=get_root(parent[nod]);
}

void merge(int x, int y) {
	parent[y] = x;
}

signed main()
{
	f >> n >> m;
	parent.resize(n + 1, 0);
	for (int i = 1; i <= n; i++)
		make_root(i);
	while (m--) {
		int cod, x, y;
		f >> cod >> x >> y;
		if (cod == 1) {
			merge(x, y);
		}
		else {

			//cout << "radacinile sunt: " << get_root(x) << " " << get_root(y) << "\n";
			if (get_root(x) == get_root(y))
				g << "DA\n";
			else
				g << "NU\n";
		}
	}

}