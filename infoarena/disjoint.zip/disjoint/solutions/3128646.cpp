#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 100000;
int cardinal[NMAX+5], root[NMAX+5];

int find_root(const int &number)
{
    if (root[number] == number) return number;

    root[number] = find_root(root[number]);
    return root[number];
}

void unite(const int &x, const int &y)
{
    int findx = find_root(x), findy = find_root(y);

    if (findx > findy) swap(findx, findy);

    cardinal[findy] += cardinal[findx];
    root[findy] = findx;
}

int main()
{
    int n, m, x, y;
    short type;
    fin>>n>>m;

    for (int i = 1; i <= n; i++) root[i] = i, cardinal[i] = 1;

    while (m--) {
        fin>>type>>x>>y;
        int findx = find_root(x), findy = find_root(y);

        if (type == 1) {
            if (findx != findy) unite(findx, findy);
        }
        else
            if (findx != findy) fout<<"NU\n";
            else fout<<"DA\n";
    }

    return 0;
}
