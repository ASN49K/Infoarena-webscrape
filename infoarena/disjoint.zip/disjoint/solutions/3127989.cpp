#import<fstream>
int n,m,q[1<<17],t,x,y;std::ifstream i("disjoint.in");std::ofstream o("disjoint.out");int p(int n){while(q[n])n=q[n];return n;}main(){for(i>>n>>m;m--;i>>t>>x>>y,t==1?q[p(y)]=p(x):p(x)==p(y)?0||o<<"DA\n":1&&o<<"NU\n");}
