#include <bits/stdc++.h>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

struct DSU
{
    int n;
    vector <int> par,sz;

    DSU(int _n)
    {
        n=_n;
        par.resize(n+1);
        sz.resize(n+1);
        for(int i=1;i<=n;i++) par[i]=i;
    }

    int gasesc(int nod)
    {
        if(par[nod]==nod) return nod;
        return (par[nod]=gasesc(par[nod]));
    }

    void unesc(int x, int y)
    {
        x=gasesc(x);
        y=gasesc(y);
        if(sz[x]<sz[y]) swap(x,y);
        par[y]=x;
        sz[x]+=sz[y];
    }
};

int main()
{
    int n,m,op,x,y;
    fin>>n>>m;
    DSU yay(n);
    while(m--)
    {
        fin>>op>>x>>y;
        if(op==1) yay.unesc(x,y);
        else
        {
            if(yay.gasesc(x)==yay.gasesc(y)) fout<<"DA";
            else fout<<"NU";
            fout<<endl;
        }
    }
    return 0;
}
