#include <fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n,m,cod,x,y;
int vec[100005];

int search_tata(int nod)
{
    while(vec[nod])
        nod=vec[nod];
    return nod;
}

int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>cod>>x>>y;
        int a=search_tata(x);
        int b=search_tata(y);
        if(cod==1)
        {
            vec[a]=b;
        }
        if(cod==2)
        {
            if(a==b)
                fout<<"DA"<<endl;
            else
                fout<<"NU"<<endl;
        }
    }
}
