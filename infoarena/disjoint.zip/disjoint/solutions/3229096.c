#include <stdio.h>
#include <stdlib.h>

int sef[100000];

int find( int i ) {
  if ( sef[i] == i )
    return i;
  return sef[i] = find( sef[i] );
}

void unite( int i, int j ) {
  int sefi, sefj;
  sefi = find( i );
  sefj = find( j );
  sef[sefj] = sefi;
}

int main()
{
    FILE *fin, *fout;
    fin = fopen( "disjoint.in", "r" );
    fout = fopen( "disjoint.out", "w" );
    int n, m, i, tip, a, b; /// tip este tipul operatiei, iar a si b numerele
    fscanf( fin, "%d%d", &n, &m );
    for ( i = 0; i < n; i++ )
      sef[i] = i;
    for ( i = 0; i < m; i++ ) {
      fscanf( fin, "%d%d%d", &tip, &a, &b );
      if ( tip == 1 )
        unite( a, b );
      else {
        if ( find( a ) == find( b ) )
          fprintf( fout, "DA\n" );
				else
          fprintf( fout, "NU\n" );
      }
    }
    return 0;
    fclose(fin);
    fclose(fout);
}
