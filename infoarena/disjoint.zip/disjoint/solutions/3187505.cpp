#include <fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[100001],Rang[100001],n,m,cod,x,y;
int Radacina(int k)
{
    if(!tata[k])
        return k;
    else {
        int a=Radacina(tata[k]);
        tata[k]=a;
        return a;
    }
}
void Compresie(int x,int y)
{
    int a=Radacina(x),b=Radacina(y);
    if(a!=b)
    {
        if(Rang[a]>Rang[b])
            tata[b]=a;
    else{
        tata[a]=b;
        if(Rang[a]==Rang[b])
            Rang[b]++;
    }
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {fin>>cod>>x>>y;
    if(cod==1)
        Compresie(x,y);
    else
    {
        if(Radacina(x)==Radacina(y))
            fout<<"DA"<<'\n';
        else fout<<"NU"<<'\n';
    }
    }
    return 0;
}
