#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, m, i, op, x, y;
int t[100002];

static inline void uniune(int x, int y) {
    t[x] = y;
}

static inline int tata(int a) {
    if(t[a] == a) return a;
    else return t[a] = tata(t[a]);
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= n; i++) t[i] = i;
    while(m--) {
        fin >> op >> x >> y;
        if(op == 1) uniune(x, y);
        else {
            int tx = tata(x);
            int ty = tata(y);
            if(tx != ty) fout << "NU\n";
            else fout << "DA\n";
        }
    }

    return 0;
}


