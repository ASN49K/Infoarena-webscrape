#include <iostream>
#include <vector>
using namespace std;

vector<int>a(100001, -1);

int find(int x) {
    if(a[x] < 0) return x;
    a[x] = find(a[x]);
    return a[x];
}

void unire(int x, int y) {
    if(x > y) swap(x, y);
    a[x] += a[y];
    a[y] = x;
}

int main() {
    FILE *ptr = fopen("disjoint.in", "r");
    FILE *ptw = fopen("disjoint.out", "w");
    int N, C, X, Y, M;
    fscanf(ptr, "%d%d", &N, &M);
    for(int i = 1; i <= M; i++) {
        fscanf(ptr, "%d%d%d", &C, &X, &Y);
        if(C == 1) {
            unire(find(X), find(Y));
        }
        else {
            if(find(X) == find(Y)) {
                fprintf(ptw, "DA\n");
            }
            else {
                fprintf(ptw, "NU\n");
            }
        }
    }
}