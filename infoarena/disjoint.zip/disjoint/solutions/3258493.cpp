#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int n, m, c, x, y, i;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

vector<int> v[100001];

int main()
{
    f >> n >> m;
    for(i = 0; i <= n; i ++)
        v[i].push_back(i);

    for(i = 1; i <= m; i ++)
    {
        f >> c >> x >> y;
        if(c == 1) v[x] = v[y];
        else
        {
            if(v[x] != v[y]) g << "NU\n";
            else g << "DA\n";
        }
    }
    return 0;
}
