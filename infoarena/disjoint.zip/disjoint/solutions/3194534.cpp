#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n,m;
int t[100003],sz[100003];

int find(int nod){
    while(t[nod]!=nod) nod=t[nod];
    return nod;
}

void unio(int a,int b){
    int va=find(a),vb=find(b);
    if(sz[va]>sz[vb]){
        t[vb]=va;
        sz[va]++;
    }else {
        t[va]=vb;
        sz[vb]++;
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;++i) t[i]=i,sz[i]=1;
    
    for(int i=1;i<=m;++i){
        int a,b,c;
        cin>>c>>a>>b;
        if(c==1)
            unio(a,b);
        else{
            if(find(a)!=find(b)) cout<<"NU\n";
            else cout<<"DA\n";
        }
        
    }
    return 0;
}