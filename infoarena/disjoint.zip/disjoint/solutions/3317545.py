
parent = []
sz = []

def find(v):
    while v != parent[v]:
        v = parent[v]
    return v

def union(x, y):
    x = find(x)
    y = find(y)

    if sz[x] < sz[y]:
        parent[x] = y
        sz[y] += sz[x]
    else:
        parent[y] = x
        sz[x] += sz[y]

def main():
    global parent, sz

    input = open("lab2.in").readline

    n, m = map(int, input().split())
    
    for i in range(n):
        parent.append(i)
        sz.append(1)

    for _ in range(m):
        cmd, a, b = map(int, input().split())
        if cmd == 1:
            union(a - 1, b - 1)
        else:
            if find(a - 1) == find(b - 1):
                print("DA")
            else:
                print("NU")

    

main()