#include <bits/stdc++.h>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

const int nmax=1e5+5;
int t[nmax], h[nmax];

void init (int n)
{
    for (int i=1; i<=n; i++)
    {
        t[i]=i;
        h[i]=1;
    }
}

int getroot (int nod)
{
    if (t[nod]!=nod)
        t[nod]=getroot(t[nod]);
    return t[nod];
}

void unif (int x, int y)
{
    x=getroot(x);
    y=getroot(y);
    if (h[x]<h[y])
        t[x]=y;
    else if (h[x]>h[y])
        t[y]=x;
    else
    {
        t[y]=x;
        h[x]++;
    }
}

int main()
{
    int n, m;
    fin >> n >> m;
    init(n);
    for (int i=1; i<=m; i++)
    {
        int t, x, y;
        fin >> t >> x >> y;
        if (t==1)
            unif(x,y);
        else
        {
            if (getroot(x)==getroot(y))
                fout << "DA" << '\n';
            else
                fout << "NU" << '\n';
        }
    }
    return 0;
}
