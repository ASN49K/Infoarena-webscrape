#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

string nume = "disjoint";

ifstream in(nume + ".in");
ofstream out(nume + ".out");

const int NMAX = 100001;
int par[NMAX];

int find(int x) {
	if (par[x] != x) par[x] = find(par[x]);
	return par[x];
}

void unite(int x, int y) {
	int px = find(x);
	int py = find(y);
	if (px != py) par[x] = py;
}

void unionFind(int x, int y) {
	if (find(x) == find(y)) out << "DA\n";
	else out << "NU\n";
}

int main() {
	int n, m;
	in >> n >> m;
	for (int i = 1; i <= n; i++) par[i] = i;

	int a, b, c;
	while (m--) {
		in >> a >> b >> c;
		if (a == 1) unite(b, c);
		else unionFind(b, c);
	}
	return 0;
}
