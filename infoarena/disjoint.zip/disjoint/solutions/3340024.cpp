#include <bits/stdc++.h>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int parent[100005], sz[100005];
int find_parent(int nod)
{
    if(parent[nod]==nod)
        return nod;
    return find_parent(parent[nod]);
}
void unite(int a, int b)
{
    a=find_parent(a);
    b=find_parent(b);
    if(a==b)
        return;
    if(sz[a]>sz[b])
        swap(a,b);
    parent[a]=b;
    sz[b]+=sz[a];
}
int main()
{
    int n,m,c,a,b;
    cin>>n>>m;
    for(int i=1; i<=n; i++)
        parent[i]=i, sz[i]=1;
    while(m--)
    {
        cin>>c>>a>>b;
        if(c==1)
            unite(a,b);
        else
        {
            a=find_parent(a);
            b=find_parent(b);
            if(a==b)
                cout<<"DA"<<'\n';
            else
                cout<<"NU"<<'\n';
        }
    }
    return 0;
}
