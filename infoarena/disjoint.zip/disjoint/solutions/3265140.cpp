#include <bits/stdc++.h>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int n, m, x, y, par[100001], hmax[100001], t;

int root(int p)
{
    int aux=p;
    while(par[p]!=-1)
    {
        p=par[p];
    }
    while(aux!=p)
    {
        int a=par[aux];
        par[aux]=p;
        aux=a;
    }
    return p;
}

void unite(int p, int q)
{
    p=root(p);
    q=root(q);
    if(p==q)
        return;
    if(hmax[p]>hmax[q])
    {
         par[q]=p;
    }
    else
    {
        if(hmax[p]<hmax[q])
            par[p]=q;
         else
            par[p]=q, hmax[p]++;
     }
}

int main()
{
    f>>n>>m;
    for(int i=1; i<=n; i++)
        par[i]=-1, hmax[i]=0;
    for(int i=1; i<=m; i++)
    {
        f>>t>>x>>y;
        if(t==1)
        {
            unite(x, y);
        }
        else
        {
            if(root(x)==root(y))
                g<<"DA"<<'\n';
            else
                g<<"NU"<<'\n';
        }
    }
    return 0;
}
