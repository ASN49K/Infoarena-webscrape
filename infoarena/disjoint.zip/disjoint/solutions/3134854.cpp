#include <fstream>

using namespace std;

const int N = 1e5;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int t[N], h[N];

void reuniune(int x, int y)
{
    if (h[x] < h[y])
        t[x] = y;
    else
    {
        t[y] = x;
        if (h[x] == h[y])
            h[x]++;
    }
}

int rad(int x)
{
    int r = x, y;
    while (t[r])
        r = t[r];

    while (x != r)
    {
        y = t[x];
        t[x] = r;
        x = y;
    }
    return r;
}

int main()
{
    int n, m, i, op, x, y;

    fin >> n >> m;

    for (i = 1; i<=m; i++)
    {
        fin >> op >> x >> y;

        if (op == 1)
            reuniune(rad(x), rad(y));
        else
        {
            if (rad(x) == rad(y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
