#include <fstream>

using namespace std;
const int NMAX=100000;

int T[NMAX+1];

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int Find(int i)
{
    if(T[i]==0)
        return i;
    return T[i]=Find(T[i]);
}

inline void Union(int cx, int cy)
{
    T[cx]=cy;
}

int main()
{
    int N, M, op, x, y, cx, cy;
    f>>N>>M;
//    for(int i=1; i<=N; i++)
//        Sz[i]=1;
    while(M--)
    {
        f>>op>>x>>y;
        cx=Find(x);
        cy=Find(y);
        if(op==1)
        {
//            if(cx!=cy)
            Union(cx, cy);
        }
        else
        {
            if(cx==cy)
                g<<"DA\n";
            else
                g<<"NU\n";
        }
    }
    f.close();
    g.close();
    return 0;
}
