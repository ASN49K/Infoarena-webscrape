#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int vtati[100001], n, m, x, y, op;

int main()
{
    fin>>n>>m;
    for (int i=1; i<=n; i++)
        vtati[i] = i;
        
    for (int i=1; i<=m; i++){
        fin>>op>>x>>y;
        if (op == 1){
            vtati[y] = x;
        } else {
            while (vtati[x] != x){
                x = vtati[x];
            }
            while (vtati[y] != y){
                y = vtati[y];
            }
            if (x==y){
                fout<<"DA"<<"\n";
            } else  
                fout<<"NU"<<"\n";
        }
    }

    return 0;
}