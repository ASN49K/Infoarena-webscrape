#include <bits/stdc++.h>
using namespace std;

string file = "disjoint";
ifstream fin(file + ".in");
ofstream fout(file + ".out");

int t[100001], n, m;

int root(int x) {

    if (t[x] == x)
        return x;
    return t[x] = root(t[x]);
}

inline void unit(int x, int y) {

    x = root(x);
    y = root(y);

    if (x != y)
        t[x] = y;
}

int main() {

    fin >> n >> m;

    for (int i = 1; i <= n; i++)
        t[i] = i;

    for (int i = 1; i <= m; i++) {

        int type, x, y;
        fin >> type >> x >> y;

        if (type == 1)
            unit(x, y);
        else
            fout << (root(x) == root(y) ? "DA\n" : "NU\n");
    }

    return 0;
}