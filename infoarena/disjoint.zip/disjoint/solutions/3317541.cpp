#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, m;
int t[100001];

int Find(int x) {
    return t[x] ? t[x] = Find(t[x]) : x;
}

inline void Union(int rx, int ry)
{
    t[ry] = rx;
}
int main()
{
    int op, x, y,rx, ry;
    fin >> n >> m;
    while (m--)
    {
        fin >> op >> x >> y;
        rx = Find(x);
        ry = Find(y);
        if (op == 1)
            Union(rx, ry);
        else fout << ((rx == ry)?"DA\n":"NU\n");
    }
    fin.close();
    fout.close();
    return 0;
}
