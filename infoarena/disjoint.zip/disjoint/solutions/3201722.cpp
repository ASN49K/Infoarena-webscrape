#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
struct arb
{
    int rad, h;
};
arb t[100001];
int n, m, op, x, y;
void uneste(int x, int y)
{
    if(t[x].h<t[y].h)
    {
        t[x].rad=t[y].rad;
    }
    else t[y].rad=t[x].rad;
}
int fnd(int x)
{
    if(t[x].rad==x)
    {
        return x;
    }
    return fnd(t[x].rad);
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        t[i].rad=i;
        t[i].h=1;
    }
    for(int i=1; i<=m; i++)
    {
        fin>>op>>x>>y;
        if(op==1)
        {
            uneste(x, y);
        }
        if(op==2)
        {
            if(fnd(x)==fnd(y))
            {
                fout<<"DA";
            }
            else fout<<"NU";
        }
    }
    return 0;
}
