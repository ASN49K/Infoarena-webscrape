#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,m;
int comp[100005];
vector<int> multime[100005];
void merge(int c1,int c2)
{
	while(!multime[c2].empty())
	{
		int x=multime[c2].back();
		multime[c2].pop_back();
		comp[x]=c1;
		multime[c1].emplace_back(x);
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
	fin.tie(0);
	fin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		comp[i]=i;
		multime[i].emplace_back(i);
	}
	while(m--)
	{
		int tip;
		fin>>tip;
		if(tip==2)
		{
			int x,y;
			cin>>x>>y;
			if(comp[x]==comp[y])
				fout<<"DA\n";
			else
				fout<<"NU\n";
		}
		else
		{
			int x,y;
			fin>>x>>y;
			if(comp[x]!=comp[y])
				merge(comp[x],comp[y]);
		}
	}
	return 0;
}
