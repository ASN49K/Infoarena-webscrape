#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int par[100005],sz[100005];
int n,m;
int getroot(int a)
{
	while(par[a]!=a)
		a=par[a];
	return a;
}
void merge(int a,int b)
{
	a=getroot(a);
	b=getroot(b);
	if(sz[a]<sz[b])
		swap(a,b);
	par[b]=a;
	sz[a]+=sz[b];
}
int main()
{
	fin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		par[i]=i;
		sz[i]=1;
	}
	while(m--)
	{
		int tip,a,b;
		fin>>tip>>a>>b;
		if(tip==1)
			merge(a,b);
		else
		{
			a=getroot(a);
			b=getroot(b);
			if(a==b)
				fout<<"DA\n";
			else
				fout<<"NU\n";
		}
	}
	return 0;
}
