#include <bits/stdc++.h>
#define speed ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define cin in
#define cout out
using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

int n, queries;
vector<int> tata;

int calculeazaRadacina(int nod) {
    if (tata[nod] == nod) {
        return nod;
    }
    return (tata[nod] = calculeazaRadacina(tata[nod]));
}

void unesteMultimi(int x, int y) {
    int radacinaX = calculeazaRadacina(x);
    int radacinaY = calculeazaRadacina(y);
    if (radacinaX == radacinaY) {
        return;
    }
    tata[radacinaY] = radacinaX;
}

bool aceeasiMultime(int x, int y) {
    return calculeazaRadacina(x) == calculeazaRadacina(y);
}

void initializeaza() {
    tata = vector<int>(n + 1);
    for (int i = 1; i <= n; ++i) {
        tata[i] = i;
    }
}

void rezolva() {
    cin >> n >> queries;
    initializeaza();

    int operatie, x, y;
    while (queries--) {
        cin >> operatie >> x >> y;
        if (operatie == 1) {
            unesteMultimi(x, y);
        }
        else {
            if (aceeasiMultime(x, y)) {
                cout << "DA\n";
            }
            else {
                cout << "NU\n";
            }
        }
    }
}

int main()
{
    speed

    rezolva();

}
/*
 *Arbori
 *noduri=muchii+1
 *
 */