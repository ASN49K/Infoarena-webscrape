#include <fstream>
using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

const int N=1e5+2;
int n,root[N],rang[N];

int r(int nod)
{
    if(root[nod]==nod)
        return nod;
    root[nod]=r(root[nod]);
    return root[nod];
}
int main()
{
    int m,cod,x,y;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        root[i]=i;
    while(m--)
    {
        cin>>cod>>x>>y;
        if(cod==2)
        {
            if(r(x)==r(y))
                cout<<"DA\n";
            else
                cout<<"NU\n";
        }
        else
        {
            int rx=r(x),ry=r(y);
            if(rang[rx]<rang[ry])
            {
                root[rx]=ry;
            }
            else
            {
                root[ry]=rx;
                rang[rx]++;
            }
        }
    }
    return 0;
}
