#include <bits/stdc++.h>
#define eb emplace_back
#define cin fin
#define cout fout
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

vector<int> t, r;

int unire(int x, int y)
{
if (r[x]>r[y])
    t[y]=x;
else
    {
    if (r[x]<r[y])
        t[x]=y;
    else
        {
        t[y]=x;
        r[x]++;
        }
    }
}

int findu(int x)
{
int temp, rad;
rad=x;

while (t[rad]!=0)
    rad=t[rad];
while (t[x]!=0)
    {
    temp=t[x];
    t[x]=rad;
    x=temp;
    }
return rad;
}

int n, m, x, y, c;

int main()
{
    cin>>n>>m;
    t.resize(n+1);
    r.resize(n+1);

    while (m--)
        {
        cin>>c>>x>>y;

        if (c==1)
            {
            int x1, x2;
            x1=findu(x);
            x2=findu(y);
            if (x1!=x2)
                unire(x, y);
            }
        else
            {
            if (findu(x)!=findu(y))
                cout<<"NU";
            else
                cout<<"DA";
            }
        }
}
