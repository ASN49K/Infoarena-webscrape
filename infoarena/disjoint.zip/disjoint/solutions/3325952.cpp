#include <fstream>

using namespace std;

int kng[100005];
int rang[100005];

void join(int a, int b)
{
    if (rang[a]<=rang[b])
        swap(a, b);
    if (rang[a]==rang[b])
        rang[a]++;
    rang[b]=rang[a];
    kng[b]=a;
    return;
}

int tata(int a)
{
    int nod=a;
    while (kng[nod]!=nod)
    {
        nod=kng[nod];
    }
    while (a!=kng[a]){
        int x= kng[a];
        kng[a]=nod;
        a=x;
    }
    return nod;
}

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int main()
{
    int n, m, a, b, type;
    cin>>n>>m;
    for (int i=1; i<=n; i++)
    {
        kng[i]=i;
        rang[i]=1;
    }

    for (int i=1; i<=m; i++)
    {
        cin>>type>>a>>b;
        if (type==1)
        {
            join(tata(a), tata(b));
        }
        else
        {
            if (tata(a)!=tata(b))
                cout<<"NU"<<'\n';
            else
                cout<<"DA"<<'\n';
        }
    }
}
