#include <iostream>

using namespace std;

int tata[100005];

int getRoot(int node) {
	while (node != tata[node]) {
		node = tata[node];
	}
	return node;
}

void unite(int x, int y) {
	int rootX = getRoot(x);
	int rootY = getRoot(y);

	tata[rootX] = rootY;
}

int main() {
	freopen("disjoint.in", "r", stdin);
	freopen("disjoint.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) {
		tata[i] = i;
	}
	for (int i = 0; i < m; ++i) {
		int op, x, y;
		cin >> op >> x >> y;
		if (op == 1) {
			unite(x, y);
		} else {
			if (getRoot(x) == getRoot(y)) {
				cout << "DA\n";
			} else {
				cout << "NU\n";
			}
		}

	}
	return 0;
}