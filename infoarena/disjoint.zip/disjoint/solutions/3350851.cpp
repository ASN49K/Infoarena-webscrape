#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int parent[100001];
int rang[100001];

int find_set(int x) {
	if(parent[x] != x)
		parent[x] = find_set(parent[x]);

	return parent[x];
}

void union_set(int x, int y) {
	int rx = find_set(x);
	int ry = find_set(y);

	if(rx == ry)
		return;

	if(rang[rx] < rang[ry])
		parent[rx] = ry;
	else if(rang[rx] > rang[ry])
		parent[ry] = rx;
	else {
		parent[ry] = rx;
		++rang[rx];
	}
}

int main()
{
	int n, m;
	fin >> n >> m;

	for(int i = 1; i <= n; ++i) {
		parent[i] = i;
		rang[i] = 0;
	}
	for(int i = 1; i <= m; ++i) {
		int cod, x, y;
		fin >> cod >> x >> y;
		if(cod == 1)
			union_set(x, y);
		else {
			if(find_set(x) == find_set(y))
				fout << "DA\n";
			else
				fout << "NU\n";
		}
	}

	return 0;
}
