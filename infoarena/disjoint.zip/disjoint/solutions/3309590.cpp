#include <bits/stdc++.h>
#define int long long

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

int tata[100005],h[100005];

int Find(int a){
    int x = a;
    while (tata[x]!=x){
        x = tata[x];
    }
    int y = a;
    while (tata[y]!=y){
        int cp = tata[y];
        tata[y] = x;
        y = cp;
    }
    return x;
}

void Unite(int a,int b){
    int x = Find(a);
    int y = Find(b);
    if (h[x]==h[y]){
        h[x]++;
        tata[y] = x;
        return;
    }
    if (h[x]>h[y]) tata[y] = x;
    else if (h[x]<h[y]) tata[x] = y;
}

signed main()
{
    int n,m;
    fin >> n >> m;
    for (int i=1;i<=n;++i){
        tata[i] = i;
        h[i] = 1;
    }
    for (int i=1;i<=m;++i){
        int C,x,y;
        fin >> C >> x >> y;
        if (C==1){
            Unite(x,y);
        }else{
            if (Find(x)==Find(y)) fout << "DA\n";
            else fout << "NU\n";
        }
    }
    return 0;
}
