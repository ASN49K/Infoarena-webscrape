#include <bits/stdc++.h>
#define mod 1000000007

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

vector<int>tata(100005),height(100005);

int parinte(int nod) {
    if (tata[nod] != nod)
        tata[nod] = parinte(tata[nod]); // Path compression
    return tata[nod];
}
void unite(int x, int y){
    int px=parinte(x);
    int py=parinte(y);

    if(height[px]<height[py])
            tata[px]=py;
    else if(height[px]>height[py])
            tata[py]=px;
        else{
            tata[py]=px;
            height[px]+=1;
            }
}

void reset(int n){
    for(int i=1; i<=n; ++i){
        tata[i]=i;
        height[i]=1;
    }
}
int main()
{

    int n,op;
    f>>n>>op;
    reset(n);
    for(int i=1; i<=op; ++i){
        int p,x,y;
        f>>p>>x>>y;
        if(p==1)
            unite(x,y);
        else{
            if(parinte(x)==parinte(y))
                    g<<"DA\n";
            else g<<"NU\n";
        }
    }



    return 0;

}
