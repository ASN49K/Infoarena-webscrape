#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("disjoin.in");
ofstream fout("disjoint.out");

const int maxS=100005;

int parent[maxS];

int main()
{
    int n,m;
    for(int i=1;i<=n;++i)
        parent[i]=i;
    for(int i=1;i<=m;++i)
    {
        int x,y,choice;
        if(choice==1)
        {
            if(parent[x]!=parent[y])
                parent[y]==parent[x];
        }
        else
        {
            if(parent[x]!=parent[y])
                fout<<"NU"<<'\n';
            else
                fout<<"DA"<<'\n';
        }
    }


}