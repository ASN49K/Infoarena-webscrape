#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int k, start[100001], l[2][100001];

void liste(int i, int j)
{
    k++;
    l[0][k]=j;
    l[1][k]=start[i];
    start[i]=k;
    k++;
    l[0][k]=i;
    l[1][k]=start[j];
    start[j]=k;
}

int main()
{
    int n, m, t[100100]={0}, as, ad, z, x, y, strt;
    cin>>n>>m;
    for(int i=1;i<=n;i++) t[i]=i;
    for(int i=1;i<=m;i++)
    {
        cin>>z>>x>>y;
        if(z==1)
        {
            liste(x,y);
            if(t[x]!=t[y])
                as=t[x];
                ad=t[y];
                strt=start[y];
                while(strt!=0)
                {
                    t[l[0][strt]]=ad;
                    strt=l[1][strt];
                }
        }
        else
        {
            if(t[x]==t[y]) cout<<"DA"<<'\n';
            else cout<<"NU"<<'\n';
        }
    }
    return 0;
}
