#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 1e5;
int p[NMAX + 1], sz[NMAX + 1];

int Find(int x)
{
    while (x != p[x])
    {
        x = p[x];
    }
    return x;
}

void Union(int x, int y)
{
    x = Find(x);
    y = Find(y);

    if (sz[x] < sz[y])
    {
        p[x] = y;
        sz[y] += sz[x];
        sz[x] = 0;
    }
    else
    {
        p[y] = x;
        sz[x] += sz[y];
        sz[y] = 0;
    }
}

int main()
{
    int n, m;
    fin >> n >> m;

    for (int i = 1; i <= n; i++)
    {
        p[i] = i;
        sz[i] = 1;
    }

    for (int i = 1; i <= m; i++)
    {
        int op, x, y;
        fin >> op >> x >> y;

        if (op == 1)
        {
            Union(x, y);
        }
        else
        {
            if (Find(x) == Find(y))
                cout << "DA" << " ";
            else
                cout << "NU" << " ";
        }
    }

    return 0;
}