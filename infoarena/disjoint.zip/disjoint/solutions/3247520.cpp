#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n;
int m;
int x, y, c;
struct DSU{
    int N;
    vector<int> parent;
    void init(int n)
    {
        N=n;
        parent.resize(N+1);
        for (int i=1; i<=n; ++i)
        {
            parent[i]=i;
        }
    }
    int find1(int u)
    {
        if (parent[u]==u)
        {
            return u;
        }
        return parent[u]=find1(parent[u]);
    }
    void unite(int u, int v)
    {
        u=parent[u];
        v=parent[v];
        if (u!=v)
        {
            parent[v]=u;
        }
    }
};


int main()
{
    DSU dsu;
    fin>>n>>m;
    dsu.init(n);
    for (int i=1; i<=m; ++i)
    {
        fin>>c;
        if(c==1)
        {
            fin>>x>>y;
            dsu.unite(x, y);
        }
        else if (c==2)
        {
            fin>>x>>y;
            if (dsu.find1(x)==dsu.find1(y))
            {
                fout<<"DA"<<"\n";
            }
            else
            {
                fout<<"NU"<<"\n";
            }
        }
    }

    return 0;
}
