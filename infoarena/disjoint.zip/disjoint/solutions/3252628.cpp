#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 1e5 + 5;

int h[NMAX], t[NMAX];

void UnionSet(int x, int y){
    if(h[x] > h[y]){
        t[y] = x;
    }
    else{
        if(h[y] > h[x]){
            t[x] = y;
        }
        else{
            if(h[x] == h[y]){
                t[y] = x;
                h[x] ++;
            }
        }
    }
}

int FindRoot(int x){
    while(x != t[x]){
        x = t[x];
    }
    return x;
}


void solve(){
    int tip, x, y, m, n;
    fin >> n;
    for(int i = 1; i <= n; ++i){
        t[i] = i;
        h[i] = 1;
    }
    fin >> m;
    for(int i = 1; i <= m; ++i){
        fin >> tip >> x >> y;
        if(tip == 1){
            UnionSet(x, y);
        }
        else{
            if(FindRoot(x) == FindRoot(y)){
                fout << "DA";
            }
            else{
                fout << "NU";
            }
            fout << "\n";
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);

    solve();

    fin.close();
    fout.close();
    return 0;
}
