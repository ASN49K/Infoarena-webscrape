#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int const MAX=100001;
int P[MAX],D[MAX],n,m,c,a,b;
int find_root(int x)
{
    while(P[x]!=x)
    {
        x=P[x];
    }
    return x;
}
void m1918(int x,int y)
{
    int rx,ry;
    rx=find_root(x);
    ry=find_root(y);
    if(D[rx]>D[ry])
    {
        P[ry]=rx;
    }
    else if(D[rx]<D[ry])
    {
        P[rx]=ry;
    }
    else if(D[rx]==D[ry])
    {
        P[ry]=rx;
        D[rx]++;
    }
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        P[i]=i;
        D[i]=1;
    }
    for(int i=1; i<=m; i++)
    {
        cin>>c>>a>>b;
        if(c==1)
        {
            m1918(a,b);
        }
        else if(c==2)
        {
            if(find_root(a)==find_root(b))
            {
                cout<<"DA"<<'\n';
            }
            else
            {
                cout<<"NU"<<'\n';
            }
        }


    }
    return 0;
}
