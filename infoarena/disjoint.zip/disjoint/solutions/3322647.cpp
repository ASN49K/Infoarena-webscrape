#include <iostream>
#include <vector>

using namespace std;

int n, queries;
vector<int> tata;

int calculeazaRadacina(int nod) {
	if (tata[nod] == nod) {
		return nod;
	}
	return (tata[nod] = calculeazaRadacina(tata[nod]));
}

void unesteMultimi(int x, int y) {
	int radacinaX = calculeazaRadacina(x);
	int radacinaY = calculeazaRadacina(y);
	if (radacinaX == radacinaY) {
		return;
	}
	tata[radacinaY] = radacinaX;
}

bool aceeasiMultime(int x, int y) {
	return calculeazaRadacina(x) == calculeazaRadacina(y);
}

void initializeaza() {
	tata = vector<int>(n + 1);
	for (int i = 1; i <= n; ++i) {
		tata[i] = i;
	}
}

void rezolva() {
	cin >> n >> queries;
	initializeaza();
	
	int operatie, x, y;
	while (queries--) {
		cin >> operatie >> x >> y;
		if (operatie == 1) {
			unesteMultimi(x, y);
		}
		else {
			if (aceeasiMultime(x, y)) {
				cout << "DA\n";
			}
			else {
				cout << "NU\n";
			}
		}
	}
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	
	freopen("disjoint.in", "r", stdin);
	freopen("disjoint.out", "w", stdout);
	
	rezolva();
	return 0;
}