#include <fstream>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

#define NMAX 100005

int tata[NMAX], rang[NMAX];

void uneste(int x, int y)
{
    if (rang[x] > rang[y])
        tata[y] = x;
    else
        tata[x] = y;

    if (rang[x] == rang[y])
        rang[y]++;
}

int cauta(int x)
{
    int radacina = x;

    while (tata[radacina] != radacina)
        radacina = tata[radacina];

    while (tata[x] != x)
    {
        int y = tata[x];
        tata[x] = radacina;
        x = y;
    }

    return radacina;
}

int main()
{
    int n, m;
    fin >> n >> m;

    for (int i = 1; i <= n; ++i)
    {
        tata[i] = i;
        rang[i] = 1;
    }

    for (int i = 1; i <= m; ++i)
    {
        int cod, x, y;
        fin >> cod >> x >> y;

        if (cod == 1)
            uneste(x, y);
        else
            if (cauta(x) == cauta(y))
                fout << "DA\n";
            else
                fout << "NU\n";
    }
    return 0;
}
