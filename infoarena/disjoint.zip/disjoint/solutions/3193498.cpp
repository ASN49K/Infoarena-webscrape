#include <bits/stdc++.h>

using namespace std;

const string file_name = "coborare";
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");


const int NMAX = 100000;
const int Mod = 100003;
int T[NMAX];
int rang[NMAX];

int Rad(int k)
{
    if(T[k]!=k)
    {
        int x = Rad(T[k]);
        T[k] = x;
        return x;
    }
    return k;
}

void Union(int rp, int rk)
{
    if(rk!=rp)
    {
        if(rang[rk]>rang[rp])
        {
            T[rp] = rk;
        }
        else
        {
            T[rk]=rp; //rp e tatal lui rk
            if(rang[rk]==rang[rp])
                rang[rp]++; //rangul = gradul tatalui creste cu 1
        }
    }
}

//Dijkstra - bfs pentru cel mai mic drum de la un nod selectat la toate celelalte noduri, adaugam in PQ nodul cu - pt. sortare -> min heap //

int N,M,i,op;


int main()
{
    fin>>N>>M;
    int x,y;
    for(i=1;i<=N;i++)
    {
        T[i] = i;
        rang[i] = 1;
    }
    for(i=1;i<=M;i++)
    {
        fin>>op>>x>>y;
        int repr_x = Rad(x);
        int repr_y = Rad(y);
        if(op==1)
        {
            if(repr_x==repr_y)
                fout<<"DA"<<'\n';
            else fout<<"NU"<<'\n';
        }
        else if(op==2)
        {
            if(repr_x==repr_y)
                Union(repr_x,repr_y);
        }
    }
}
