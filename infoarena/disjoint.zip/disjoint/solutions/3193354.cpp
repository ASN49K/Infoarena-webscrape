#include <bits/stdc++.h>
#include <cstdlib>
#include <ctime>
#define UNI 1
#define CHK 2
using namespace std;
const int nmax=1e5;
struct DSU {
  int n;
  vector<int>f;
  DSU(int sz) {
    n=sz;
    f.resize(sz+1);
    for(int i=1;i<=sz;i++)
      f[i]=i;
  }
  int find(int x){
    if(f[x]==x)
      return x;
    return f[x]=find(f[x]);
  }
  void join(int x,int y) {
    if(x==y)
      return;
    if(rand()%2==1)
      swap(x,y);
    int sx=find(x),sy=find(y);
    if(sx==sy)
      return;
    f[sx]=sy;
  }
};
int main() {
  ifstream cin("disjoint.in");
  ofstream cout("disjoint.out");
  srand(time(NULL));
  int n,q,cer,x,y;
  cin>>n>>q;
  DSU myDsu(n);
  for(int i=1;i<=q;i++){
    cin>>cer>>x>>y;
    if(cer==UNI){
      myDsu.join(x,y);
    } else if(cer==CHK){
      cout<<((myDsu.find(x)==myDsu.find(y))?"DA\n":"NU\n");
    }
  }
  return 0;
}
