#include <fstream>
#include <vector>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int N,M;

struct DSU{

    vector<int> p,s;

    void init(int n)
    {
        p.resize(n+1);
        s.resize(n+1);
        for(int i=1;i<=n;i++)
            p[i]=i,s[i]=1;
    }

    int f(int x)
    {
        if(x==p[x])
            return x;
        return p[x]=f(p[x]);
    }

    void unite(int x,int y)
    {
        x=f(x);
        y=f(y);
        if(x==y)
            return;
        if(s[x]>s[y])
            swap(x,y);
        p[x]=y;
        s[y]+=s[x];
    }

};

int main()
{
    DSU morbius;
    int a,b,c;
    cin>>N>>M;
    morbius.init(N);
    for(int i=1;i<=M;i++)
    {
        cin>>c>>a>>b;
        if(c==1)
        morbius.unite(a,b);
        else
        {
            if(morbius.f(a)==morbius.f(b))
                cout<<"DA";
            else
                cout<<"NU";
            cout<<'\n';
        }
    }
    return 0;
}
