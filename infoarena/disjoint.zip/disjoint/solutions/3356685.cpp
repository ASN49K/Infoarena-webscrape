#include <fstream>
#include <vector>

using namespace std;

int radacina(int x, vector <int> &t) {
    if (t[x] == 0) {
        return x;
    }
    t[x] = radacina(t[x], t); // compactarea drumurilor
    return t[x];
}

void reuniune(int x, int y, vector <int> &t, vector <int> &nr) {
    int rx = radacina(x, t);
    int ry = radacina(y, t);
    if (nr[x] < nr[y]) {
        t[rx] = ry;
        nr[ry] += nr[rx];
    } else {
        t[ry] = rx;
        nr[rx] += nr[ry];
    }
}

bool verif(int x, int y, vector <int> &t) {
    return (radacina(x, t) == radacina(y, t));
}

int main() {
    ifstream in("disjoint.in");
    ofstream out("disjoint.out");
    int n, nr_op;
    in >> n >> nr_op;
    vector <int> t(n + 1, 0);
    vector <int> nr(n + 1, 1);
    for (int i = 0; i < nr_op; i++) {
        int tip, x, y;
        in >> tip >> x >> y;
        if (tip == 1) {
            reuniune(x, y, t, nr);
        } else {
            if (verif(x, y, t)) {
                out << "DA\n";
            } else {
                out << "NU\n";
            }
        }
    }
    in.close();
    out.close();
    return 0;
}