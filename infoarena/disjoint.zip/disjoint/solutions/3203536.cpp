#include <bits/stdc++.h>
using namespace std;
ifstream  in("disjoint.in");
ofstream  out("disjoint.out");
vector <int> parent,size;
int n,m,cod,x,y,i;

int find_set(int v) {
    if (v == parent[v])
        return v;
    return parent[v] = find_set(parent[v]);
}

void make_set(int v) {
    parent[v] = v;
    size[v] = 1;
}

void union_sets(int a, int b) {
    a = find_set(a);
    b = find_set(b);
    if (a != b) {
        if (size[a] < size[b])
            swap(a, b);
        parent[b] = a;
        size[a] += size[b];
    }
}

int main()
{
	in >> n >> m ;
	parent.resize(n+1);
	size.resize(n+1);
	for (i=1;i<=n;i++)
	{
		make_set(i);	
	}
	while (m--)
	{
		in >> cod >> x >> y ;
		if (cod == 1 )
		{
			union_sets(x,y);
		}
		else 
		{
			if (find_set(x)==find_set(y))out << "DA\n";
			else out << "NU\n";
		}
	}
    return 0;
}
