#include <fstream>
#define NMAX 100020

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n, q;
int parent[NMAX];
int rk[NMAX];

int find(int nod);
void unite(int nod1, int nod2);

int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
  cin >> n >> q;
  //initializez parintele fiecarui nod cu el insusi si setez rankul ca fiind 1
  for(int i = 1; i <= n; i++)
  {
    parent[i] = i;
    rk[i] = 1;
  }
  while(q--)
  {
    int tip, nod1, nod2;
    cin >> tip >> nod1 >> nod2;
    if(tip == 1)
    {
      unite(find(nod1), find(nod2));
    }
    if(tip == 2)
    {
      if(find(nod1) == find(nod2))
        cout << "DA\n";
      else cout << "NU\n";
    }
  }
  return 0;
}

int find(int nod)
{
    int ret, compress;
    ret = nod;
    //gasesc cel mai de sus parinte
    while(ret != parent[ret])
      ret = parent[ret];
    //unesc tot restul dintre nod si cel mai de sus parinte direct la parinte
    while(parent[nod] != nod)
    {
      compress = parent[nod];
      parent[nod] = ret;
      nod = compress;
    }
    return ret;
}

void unite(int nod1, int nod2)
{
  //unesc dupa rank a.k.a. multimea cu rank mai mic o lipesc la cea cu rank mai mare
  if(rk[nod1] > rk[nod2])
    parent[nod2] = nod1;
  else parent[nod1] = nod2;
  //daca rankurile erau egale cresc rankul multimii
  if(rk[nod1] == rk[nod2])
    rk[nod2]++;
}
