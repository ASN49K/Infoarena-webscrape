#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m, t[100001];

void Union(int x, int y)
{
    t[y] = x;
}

int Find(int x)
{
    int y;
    if (t[x] == 0)
        return x;
    y = Find(t[x]);
    t[x] = y;
    return y;
}

int main()
{
    int i, cod, x, y;
    fin >> n >> m;
    for (i = 1 ; i <= m ; i++)
    {
        fin >> cod >> x >> y;
        if (cod == 1)
            Union(x, y);
        else
        {
            x = Find(x);
            y = Find(y);
            if (x != y)
                fout << "NU" << "\n";
            else
                fout << "DA" << "\n";
        }
    }
    return 0;
}
