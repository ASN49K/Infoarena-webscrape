#include <iostream>
#include<fstream>
using namespace std;ifstream fin("disjoint.in");ofstream fout("disjoint.out");
int n,m,v[100001],sz[100001],x,y,op,i;
int path(int node){
    if(v[node]==node)return node;
    return v[node]=path(v[node]);
}
void unite(int a,int b){
    x=path(a);
    y=path(b);
    if(x==y)return;
    if(sz[a]>sz[b])swap(a,b);
    v[a]=b;
    sz[b]+=sz[a];
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=n;i++)v[i]=i,sz[i]=1;
    for(i=1;i<=m;i++){
        fin>>op>>x>>y;
        if(op==1)unite(x,y);
        else{
            if(path(x)==path(y))fout<<"YES\n";
            else fout<<"NU\n";
        }
    }
    return 0;
}
