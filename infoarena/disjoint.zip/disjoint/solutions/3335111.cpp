#include <iostream>
#include <vector>
#include <fstream>
#include <bitset>
#include <algorithm>
#include <queue>
using namespace std;

ifstream fin("rmq.in");
ofstream fout("rmq.out");
int t[100005],r[100005];
void Union(int x, int y)
{
    if (r[x]>r[y])
        t[y]=x,r[x]+=r[y];
    else
        t[x]=y,r[y]+=r[x];
}
int find(int x) {
    if (t[x]==0)
        return x;
    int y=find(t[x]);
    t[x]=y;
    return y;
}
int main()
{
    int n,m;
    fin>>n>>m;
    for (int i=1; i<=n; i++)
        r[i]=1;
    for (int i=1; i<=m; i++) {
        int op,x,y;
        fin>>op>>x>>y;
        int val1=find(x);
        int val2=find(y);
        if (op==1) {
            Union(val1,val2);
        }
        else {
            if (val1!=val2)
                fout<<"NU\n";
            else
                fout<<"DA\n";
        }
    }
    return 0;
}
// num=10,/=11,*=12,-=13,+=14,enter=15,.=16,