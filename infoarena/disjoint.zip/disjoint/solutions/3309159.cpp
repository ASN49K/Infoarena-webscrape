#include <bits/stdc++.h>

using namespace std;
int stramos[100005], sz[100005];
int find_parent(int a)
{
    if(stramos[a]==a)
        return a;
    return stramos[a]=find_parent(stramos[a]);
}
void unite(int a, int b)
{
    a=find_parent(a);
    b=find_parent(b);
    if(a==b)
        return;
    if(sz[a]>sz[b])
        swap(a,b);
    stramos[a]=b;
    sz[b]+=sz[a];
}
int main()
{
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n,q;
    cin>>n>>q;
    for(int i=1; i<=n; i++)
        stramos[i]=i, sz[i]=1;
    while(q--)
    {
        int tip, a,b;
        cin>>tip>>a>>b;
        if(tip==1)
            unite(a,b);
        else
        {
            a=find_parent(a);
            b=find_parent(b);
            if(a==b)
                cout<<"DA"<<'\n';
            else
                cout<<"NU"<<'\n';
        }
    }
    return 0;
}
