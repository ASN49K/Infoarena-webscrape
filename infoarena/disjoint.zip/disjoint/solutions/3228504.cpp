#include<fstream>
using namespace std;
ifstream F("disjoint.in");
ofstream G("disjoint.out");
int i,j,k,r[100001];
int main()
{
    for(F>>i>>j;F>>i>>j>>k;) {
        for(;r[j];j=r[j]);
        for(;r[k];k=r[k]);
        if(i<2)
            r[k]=j;
        else
            G<<(j==k?"DA\n":"NU\n");
    }
    return 0;
}
