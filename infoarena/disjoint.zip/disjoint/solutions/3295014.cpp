#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int NMAX = 1e5 + 1;
int parent[NMAX];

int root(int u)
{
    if(u == parent[u])
        return u;
    return (parent[u] = root(parent[u]));
}

void unite(int u, int v)
{
    u = root(u), v = root(v);
    if(u != v)
        parent[u] = v;
}

int main()
{
    int n, m;
    fin >> n >> m;
    iota(parent + 1, parent + n + 1, 1);
    while(m--)
    {
        int op, u, v;
        fin >> op >> u >> v;
        if(op == 1)
            unite(u, v);
        else
            fout << (root(u) == root(v) ? "DA\n" : "NU\n");
    }

    return 0;
}
