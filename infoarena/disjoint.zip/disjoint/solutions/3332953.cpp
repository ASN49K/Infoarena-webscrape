#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n,m;
int t[100001];
int size[100001];
int find(int u)
{
    if(t[u]==u)
        return u;
    return t[u]=find(t[u]);
}

void merge(int u,int v)
{
    u=find(u);
    v=find(v);
    if(u==v)
        return;
    if(size[u]<size[v])
        swap(u,v);
    t[v]=u;
    size[u]+=size[v];

}

int main()
{
    int op,x,y;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        t[i]=i;
    for(int i=1;i<=m;i++)
    {
        fin>>op>>x>>y;
        if(op==1)
            merge(x,y);
        else
        {
            if(find(x)==find(y))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }

    }

    return 0;
}
