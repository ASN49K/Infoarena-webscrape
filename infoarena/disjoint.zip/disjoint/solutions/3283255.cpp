#include <bits/stdc++.h>
using namespace std;
using T = pair<long long, int>;
const long long MOD = 1e9 + 7;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct DSU {
    vector<int> marimi, parinti;

    DSU(int marime) : marimi(marime, 1), parinti(marime) {
        for(int z = 0; z < marime; z++)
        {
            parinti[z] = z;
        }
    }

    int gasire(int nod) {
        return ((parinti[nod]==nod) ? nod : parinti[nod] = gasire(parinti[nod]));
    }

    bool unire(int x, int y) {
        x = gasire(x);
        y = gasire(y);
        if(x==y) return false;
        if(marimi[x] > marimi[y]) swap(x, y);

        marimi[y] += marimi[x];
        parinti[x] = parinti[y];
        return true;
    }
};

void solve()
{
    int n, q; fin >> n >> q;
    DSU dsu(n+1);

    for(int z = 1; z <= q; z++) {
        int t, a, b; fin >> t >> a >> b;
        if(t==1)
        {
            dsu.unire(a, b);
        } else {
            fout << ((dsu.gasire(a)==dsu.gasire(b)) ? "DA" : "NU") << '\n';
        }
    }
}

int main() {

    int tt = 1; //cin >> tt;

    while(tt--)
        solve();

    return 0;
}
/*for(int j = 0; j <= k; j++)
{
    dp[i][j] = dp[i-1][j];

    if(!v[i])
    {
        cout << i << ' ' << j << " : \n";
        for(int k = last; k < i; k++)
        {
            if((j - (i - k - 1)) >= 0) dp[i][j] = min(dp[i][j], dp[k][j - (i - k - 1)] + sum[i] - sum[k]);
        }

        for(int z = 1; z <= k; z++)
        {
            cout << dp[i][z] << ' ';
        }
        cout << endl;
        last = i;
    } else if(last > 0)
    {
        cout << i << ' ' << j << " : \n";
        dp[i][j] = min(dp[i][j], dp[i][j - (i-last)] + sum[i]-sum[last]);
        for(int z = 1; z <= k; z++)
        {
            cout << dp[i][z] << ' ';
        }
        cout << endl;
    }
}
*/
