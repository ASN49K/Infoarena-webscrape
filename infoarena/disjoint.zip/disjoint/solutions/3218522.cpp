#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int MAX = 100000;

int num, contor, par[MAX + 1], marime[MAX + 1],op, var1, var2;

int find_set(int v) {
    if (v == par[v])
        return v;
    return par[v] = find_set(par[v]);
}

void make_set(int v) {
    par[v] = v;
    marime[v] = 1;
}

void union_sets(int a, int b) {
    a = find_set(a);
    b = find_set(b);
    if (a != b) {
        if (marime[a] < marime[b])
            swap(a, b);
        par[b] = a;
        marime[a] += marime[b];
    }
}

int main() {
    fin >> num >> contor;
    for (int i = 1; i <= num; i++)
        make_set(i);
    for (int i = 1; i <= contor; i++) {
        fin >> op >> var1 >> var2;
        if (op == 1)
            union_sets(var1, var2);
        else {
            if (find_set(var1) == find_set(var2))
                fout << "DA";
            else
                fout << "NU";
            fout << '\n';
        }
    }
    return 0;
}
