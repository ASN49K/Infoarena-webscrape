#include <fstream>
#include <vector>
#define nmax 100001
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,m,x,y,tip,t[nmax];
vector<int>v[nmax];
int get_root(int nod){
    if(t[nod]>0)
        return t[nod]=get_root(t[nod]);
    return nod;
}
void join(int x,int y){
    x=get_root(x),y=get_root(y);
    if(x==y)
        return ;
    if(t[x]>t[y])
        swap(x,y);
    t[x]+=t[y];
    t[y]=x;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        t[i]=-1;
    while(m--){
        cin>>tip>>x>>y;
        if(tip==1)
            join(x,y);
        else if(get_root(x)==get_root(y))
            cout<<"DA\n";
        else
            cout<<"NU\n";
    }
    return 0;
}
