#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int dim=1e5+5;
int t[dim],r[dim],n,m;
void uneste(int x, int y){
    if(r[x]<r[y]){
        r[y]+=r[x];
        t[x]=y;
    }
    else{
        r[x]+=r[y];
        t[y]=x;
    }
}
int rad(int nod){
    if(nod==t[nod]){
        return nod;
    }
    else{
        return t[nod]=rad(t[nod]);
    }
}
int main(){
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        r[i]=1,t[i]=i;
    }
    for(int i=1;i<=m;i++){
        int op,x,y;
        fin>>op>>x>>y;
        if(op==1){
            int r1=rad(x),r2=rad(y);
            if(r1!=r2){
                uneste(r1,r2);
            }
        }
        else{
            int r1=rad(x),r2=rad(y);
            if(r1==r2){
                fout<<"DA"<<'\n';
            }
            else{
                fout<<"NU"<<'\n';
            }
        }
    }
    return 0;
}
