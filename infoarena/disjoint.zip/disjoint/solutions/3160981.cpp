#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> pii;
#define fi first 
#define se second
#define pb push_back

ifstream f("disjoint.in");
ofstream g("disjoint.out");

const int N = 1e5+5;

int n, m, root[N];
int getroot(int);

int main()
{  
    f >> n >> m;
    for (int i = 1; i <= n; i++) root[i] = i;
    while (m--){
        int task, a, b; f >> task >> a >> b;
        a = getroot(a); b = getroot(b);
        if (task == 1) root[a] = b;
        else 
            g << (a == b ? "DA\n" : "NU\n");
    }

    return 0;
}

int getroot(int nod){
    if (root[nod] == nod) return nod;
    return (root[nod] = getroot(root[nod]));
}
