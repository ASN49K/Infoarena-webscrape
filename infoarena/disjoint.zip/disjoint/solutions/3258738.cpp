#include <fstream>

using namespace std;
ifstream cin ("disjoint.in");
ofstream cout ("disjoint.out");

const int NMAX = 1e5;

struct DSU{
    int reprezentant[NMAX + 1], size[NMAX + 1];

    //constructor
    DSU(int n){
        for (int i = 1; i <= n; ++i){
            reprezentant[i] = i;
            size[i] = 1;
        }
    }

    int get_rep(int nod){
        if (nod == reprezentant[nod])
            return nod;
        else {
            int reprezentant_nod = get_rep(reprezentant[nod]);
            reprezentant[nod] = reprezentant_nod;
            return reprezentant_nod;
            
            //return reprezentant[nod] = get_rep(reprezentant[nod]);
        }
    }

    int same_component(int a, int b){
        int radacina_a = get_rep(a);
        int radacina_b = get_rep(b);

        return radacina_a == radacina_b;
    }

    void join (int a, int b){
        int radacina_a = get_rep(a);
        int radacina_b = get_rep(b);

        if (size[radacina_a] > size[radacina_b]){
            reprezentant[radacina_b] = radacina_a;
            size[radacina_a] += size[radacina_b];
        }
        else{
            reprezentant[radacina_a] = radacina_b;
            size[radacina_b] += size[radacina_a];
        }
    }
};

int n, m;


void citire_si_afisare(){
    cin >> n >> m;
    DSU dsu(n);
    
    for (int i = 1; i <= m; ++i){
        int t, a, b;
        cin >> t >> a >> b;
        if (t == 1){
            dsu.join(a, b);
        } else {
            if (dsu.same_component(a, b))
                cout << "DA\n";
            else cout << "NU\n";
        }
    }
}

int main(){
    citire_si_afisare();
    return 0;
}