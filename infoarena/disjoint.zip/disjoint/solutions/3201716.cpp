
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
vector<int> A;
vector<int> R;
int n,m;
int type,a,b;
int find(int nod)
{
    if(A[nod]==nod)
       return nod;
    else
     {
        A[nod]=find(A[nod]);
        return A[nod];
     }
}
int main()
{
   cin>>n>>m;
   A.resize(n+1);
   R.resize(n+1);
   for(int i=1;i<=n;i++)
      A[i]=i;
   for(int i=0;i<m;i++)
      {
          cin>>type;
          cin>>a>>b;
          if(type==1)
          {
              int ra=find(a);
              int rb=find(b);
              if(ra!=rb)
                 {
                     if(R[ra]>R[rb])
                            A[rb]=ra;
                     else
                       {
                           A[ra]=rb;
                           if(R[ra]==R[rb])
                               R[rb]++;
                       }
                 }
          }
          else
             {
                int ra=find(a);
                int rb=find(b);
                if(rb==ra)
                   cout<<"DA"<<'\n';
                else
                  cout<<"NU"<<'\n';
             }
      }

    return 0;
}
