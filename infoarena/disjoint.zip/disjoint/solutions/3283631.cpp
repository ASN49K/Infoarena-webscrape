#include <bits/stdc++.h>
#define MOD 666013
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, Q;
int t[100005];

void Union(int x, int y)
{
    t[y] = x;
}
int FindRoot(int x)
{
    int y, rad = x;
    while (t[rad] != 0)
        rad = t[rad];
    while (x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}
int main()
{
    int op, x, y;
    fin >> n >> Q;
    while (Q--)
    {
        fin >> op >> x >> y;
            x = FindRoot(x); y = FindRoot(y);
        if (op == 1) Union(x, y);
        else if (x == y) fout << "DA\n";
        else fout << "NU\n";
    }
    return 0;
}
