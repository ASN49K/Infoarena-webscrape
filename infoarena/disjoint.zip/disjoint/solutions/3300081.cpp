#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,k,x,y,cod;
int tatal[100001];

int comp(int x){
    int y=x;
    while(y!=tatal[y]){
        y=tatal[y];
    }
    int xx=x;
    while(xx!=y){
        int next=tatal[xx];
        tatal[xx]=y;
        xx=next;
    }
    return y;
}

void unire(int x, int y){
    int x1=comp(x);
    int y1=comp(y);
    tatal[x1]=y1;
}

int main()
{
    fin>>n>>k;
    for(int i=1;i<=n;i++){
        tatal[i]=i;
    }
    for(int i=1;i<=k;i++){
        fin>>cod>>x>>y;
        if(cod==1){
            unire(x,y);
        }
        else{
            
            if(comp(x)==comp(y)){
                fout<<"DA";
            }
            else{
                fout<<"NU";
            }
            fout<<'\n';
        }
    }

    return 0;
}