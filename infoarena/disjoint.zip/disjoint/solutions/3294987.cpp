#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m, i, a, b, tip;
int v[100005], card[100005];

int dsu(int nod){
    if(v[nod]==0){
        return nod;
    }
    v[nod]=dsu(v[nod]);

    return v[nod];
}

int main()
{
    fin>>n>>m;

    for(i=1;i<=n;i++){
        card[i]=1;
    }

    for(i=1;i<=m;i++){
        fin>>tip>>a>>b;

        int r1=dsu(a);
        int r2=dsu(b);

        if(tip==1){
            if(card[r1]<card[r2]){
                v[r1]=r2;
                card[r2]+=card[r1];
            }else{
                v[r2]=r1;
                card[r1]+=card[r2];
            }
        }

        if(tip==2){
            if(r1==r2){
                fout<<"DA\n";
            }else{
                fout<<"NU\n";
            }
        }
    }



    return 0;
}
