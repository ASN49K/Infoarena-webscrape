#include <bits/stdc++.h>

using namespace std;
ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");
int t[100005],h[100005],i,n,m,c,r1,r2;
int tata (int r)
{
	int x=r;
	while (x!=t[x])
		x=t[x];
	return x;
}
void unif (int r1,int r2)
{
	r1=tata(r1);
	r2=tata(r2);
	if (h[r1]<h[r2])
		t[r1]=t[r2];
	else
		t[r2]=t[r1];
	if (h[r1]==h[r2]) h[r1]++;
}
int main()
{
	fin>>n>>m;
	for (i=1;i<=n;i++)
		{
			h[i]=1;
			t[i]=i;
		}
	for (i=1;i<=m;i++)
		{
			fin>>c>>r1>>r2;
			if (c==1)
				unif(r1,r2);
			else
				if (tata(r1)==tata(r2))
					fout<<"DA"<<'\n';
				else fout<<"NU"<<'\n';
		}
    return  0;
}
