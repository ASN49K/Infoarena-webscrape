#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100005;

int parent[NMAX];
int sssize[NMAX];

int get_p(int a)
{
    while(parent[a] != a)
        return parent[a] = get_p(parent[a]);
    return parent[a] = a;
}

void join(int a, int b)
{
    a = parent[get_p(a)];
    b = parent[get_p(b)];

    if(sssize[a] > sssize[b])
    {
        parent[b] = a;
        sssize[b] += sssize[a];
        sssize[a] = sssize[b];
    }
    else
    {
        parent[a] = b;
        sssize[a] += sssize[b];
        sssize[b] = sssize[a];
    }
}

int main()
{
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");
    int n, m, cer, a, b;
    cin>>n>>m;

    for(int i=1; i<=n; i++)
        parent[i] = i, sssize[i] = 1;

    for(int i=0; i<m; i++)
    {
        cin>>cer>>a>>b;
        if(cer == 1)
            join(a, b);
        else
        {
            if(parent[get_p(a)] == parent[get_p(b)])
                cout<<"DA";
            else
                cout<<"NU";
            cout<<'\n';
        }
    }

    return 0;
}
