#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int parent[100000];

int sef(int a) {
    if (a == parent[a]){
        return a;
    } else {
        parent[a] = sef(parent[a]);
    }
}

void join(int a, int b) {
    int pa = parent[a];
    int pb = parent[b];
    parent[b] = parent[a];
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        parent[i] = i;
    }
    for (int i = 1; i <= m; i++) {
        int t, a, b;
        cin >> t >> a >> b;
        if (t == 1) {
            join(a, b);
        } else {
            if (sef(a) == sef(b)) {
                cout << "DA\n";
            } else {
                cout << "NU\n";
            }
        }
    }
    return 0;
}