#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int boss[100005];
int card[100005];

int stramos (int nod){
    int superboss = nod ;
    while (superboss != boss [superboss]) {
        superboss = boss [superboss] ;
    }
    while (nod != boss [nod]) {
        int aux = boss [nod] ;
        boss [nod] = superboss ;
        nod = aux ;
    }
    return superboss;
}

void unite (int a, int b){
    a = stramos(a);
    b = stramos(b);
    if (a == b) return;
    if (card[a] >= card[b]){
        boss[b] = a;
        card[a] += card[b];
    }
    else{
        boss[a] = b;
        card[b] += card[a];
    }
}

int main()
{
    int n,m;
    cin>>n>>m;
    for (int i=1; i<=n; i++){
        boss[i]=i;
        card[i]=1;
    }
    for (int i=1; i<=m; i++){
        int x,a,b;
        cin>>x>>a>>b;
        if (x==1){
            unite (a, b);
        }
        if (x==2){
            if (stramos(a) == stramos(b)){
                cout<<"DA"<<'\n';
            }
            else{
                cout<<"NU"<<'\n';
            }
        }
    }
    return 0;
}