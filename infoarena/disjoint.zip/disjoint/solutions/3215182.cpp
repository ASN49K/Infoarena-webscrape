#include <fstream>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

const int NMAX = 1e5;
int father[NMAX + 5], depth[NMAX + 5];
int findrt(int node)
{
    if(father[node] == node)
        return node;

    return node = findrt(father[node]);
}

void Union(int node1, int node2)
{
    int root1 = findrt(node1), root2 = findrt(node2);

    if(root1 == root2)
        return;

    if(depth[root1] == depth[root2])
    {
        depth[root1]++;
        father[root2] = root1;
    }
    if(depth[root1] < depth[root2])
        father[root1] = root2;
    else father[root2] = root1;
}

int main()
{
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= n; i++)
        father[i] = i;

    for(int i = 1; i <= m; i++)
    {
        int op, x, y;
        fin >> op >> x >> y;

        if(op == 1)
            Union(x, y);
        else if(op == 2)
        {
            if(findrt(x) == findrt(y))
                fout << "DA\n";
            else fout << "NU\n";
        }
    }

    fin.close();
    fout.close();
    return 0;
}
