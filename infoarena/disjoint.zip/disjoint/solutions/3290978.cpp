#include <fstream>
#include <vector>

using namespace std;

int radacina(vector <int> &t, int x)
{
    if (t[x] == 0)
    {
        return x;
    }
    t[x] = radacina(t, t[x]);
    return t[x];
}

void reuniune(vector <int> &t, vector <int> &nr, int x, int y)
{
    int rx = radacina(t, x);
    int ry = radacina(t, y);
    if (nr[rx] >= nr[ry])
    {
        t[ry] = rx;
        nr[rx] += nr[ry];
    }
    else
    {
        t[rx] = ry;
        nr[ry] += nr[rx];
    }
}

bool aceeasi_multime(vector <int> &t, int x, int y)
{
    return (radacina(t, x) == radacina(t, y));
}

int main()
{
    ifstream in("disjoint.in");
    ofstream out("disjoint.out");
    int n, q;
    in >> n >> q;
    vector <int> t(n + 1, 0);
    vector <int> nr(n + 1, 1);
    for (int i = 0; i < q; i++)
    {
        int tip, x, y;
        in >> tip >> x >> y;
        if (tip == 1)
        {
            reuniune(t, nr, x, y);
        }
        else
        {
            if (aceeasi_multime(t, x, y))
            {
                out << "DA\n";
            }
            else
            {
                out << "NU\n";
            }
        }
    }
    in.close();
    out.close();
    return 0;
}
