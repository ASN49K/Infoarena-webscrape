#include <fstream>

using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

const int N = 1e5;

int t[N + 1], h[N + 1];

int rad(int x){ // cautam rad lui x
    if(t[x] == 0){
        return x;
    }
    return rad(t[x]);
}

bool verif(int x, int y){
    return (rad(x) == rad(y));
}

void reuniune(int x, int y){
    int rx = rad(x);
    int ry = rad(y);
    if(h[rx] > h[ry]){
        t[rx] = ry;
    }
    else{
        t[ry] = rx;
        if(h[rx] == h[ry]){
            h[rx]++;
        }
    }
}
int main(){
    int n, q;
    in >> n >> q;
    for(int i = 1; i <= n; i++){
        t[i] = 0;
        h[i] = 0;
    }
    for(int i = 1; i <= q; i++){
        int tip, x, y;
        in >> tip >> x >> y;
        if(tip == 1){
            reuniune(x, y);
        }
        if(tip == 2){
            if(verif(x, y)){
                out << "DA\n";
            }
            else{
                out << "NU\n";
            }
        }
    }
    return 0;
}
