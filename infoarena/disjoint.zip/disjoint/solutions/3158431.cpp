#include<bits/stdc++.h>
using namespace std;

    ifstream in("disjoint.in");
    ofstream out("disjoint.out");
    
    
struct DSU{
    
    vector<int>fat;
    vector<int>sz;
    
    DSU(int n){
        fat.resize(n+1);
        sz.resize(n+1);
        
        for(int i = 1; i <= n; i++) {
            fat[i] = i;
            sz[i] = 1;
        }
    }
    
     int get_fat(int x) {
        if(x == fat[x]) return x;
        
        int tata_suprem = get_fat(fat[x]);
        fat[x] = tata_suprem;
        
        return tata_suprem;
        
        // poate fi redus la 
        // return fat[x] = get_fat(fat[x]);
    }
    
    void Join(int x, int y) {
        int rx = get_fat(x);
        int ry = get_fat(y);
        
        if(rx == ry) return;
        
        if(sz[rx] > sz[ry]) swap(rx, ry);
        
        // de aici incolo in cod, mereu am sz[rx] < sz[ry];
        fat[rx] = ry;
        sz[ry] += sz[rx];
        
        return;
    }
    
    void SameSet(int x, int y) {
        if( get_fat(x) == get_fat(y)){
            out<<"DA";
        }
        else out<<"NU";
        out<<"\n";
        return;
    }
    
};
    

int main(){
    int n, m;
    int a, b, c;
    in>>n>>m;
    
    DSU dsu=DSU(n);
    
    for(int i=0;i<m;i++){
        in>>a>>b>>c;
        if(a==1){
            dsu.Join(b,c);
        }
        else dsu.SameSet(b,c);
    }
    
}






