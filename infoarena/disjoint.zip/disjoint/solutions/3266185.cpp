#include <fstream>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");
int v[100005];
int rang[100005];
int n, m;

int rad(int x)
{
    if(v[x] == x)
    {
        return x;
    }
    else
    {
        int r = rad(v[x]);
        v[x] = r;
        return r;
    }
}

void reuniune(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);

    if(rx == ry)
    {
        return;
    }

    if(rang[rx] > rang[ry])
    {
        v[ry] = rx;
        rang[rx] += rang[ry];
    }
    else
    {
        v[rx] = ry;
        rang[ry] += rang[rx];
    }
}

int verif(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);

    if(rx == ry)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}

int main()
{
    f>>n>>m;

    for(int i = 1; i<=n; i++)
    {
        v[i] = i;
    }

    int t, x, y;
    while(m--)
    {
        f>>t>>x>>y;
        if(t == 1)
        {
            reuniune(x, y);
        }
        else
        {
            if(verif(x, y))
            {
                g<<"DA \n";
            }
            else
            {
                g<<"NU \n";
            }
        }
    }
    return 0;
}
