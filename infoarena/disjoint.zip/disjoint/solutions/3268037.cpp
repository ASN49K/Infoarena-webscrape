#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct nod{
    int num;
    int parent;
    int siz;
};

vector<nod> v;

int root(int i)
{
    nod x=v[i];
    while(x.parent!=0)
        x=v[x.parent];
    return x.num;
}

int main()
{
    int n, m;
    fin >> n >> m;
    v.push_back({0,0,0});
    for(int i=1; i<=n; i++)
        v.push_back({i, 0, 1});
    int cod, x, y;
    for(int i=1; i<=m; i++)
    {
        fin >> cod >> x >> y;
        if(cod==1)
        {
            int rx=root(x), ry=root(y);
            if(rx==ry)
                continue;
            if(v[rx].siz>=v[ry].siz)
            {
                v[rx].parent=ry;
                v[rx].siz=max(v[rx].siz,1+v[ry].siz);
            }
            else
            {
                v[ry].parent=rx;
                v[ry].siz+=max(v[ry].siz,1+v[rx].siz);
            }
        }
        else
        {
            if(root(x)==root(y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
