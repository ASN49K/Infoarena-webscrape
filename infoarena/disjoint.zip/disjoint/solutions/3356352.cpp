#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int p[100001];
int n,m,i;
int fynd(int x)
{
    while(x!=p[x])
    {
        x=p[x];
    }
    return p[x];
}
void unite(int x,int y)
{
    int xx=fynd(x);
    int yy=fynd(y);
    p[yy]=p[xx];
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=n;i++)
        p[i]=i;
    for(i=1; i<=m; i++)
    {
        int cer;
        int x,y;
        fin>>cer>>x>>y;
        if(cer==1)
        {
            unite(x,y);
        }
        else
        {
            if(fynd(x)==fynd(y))
                fout<<"DA"<<'\n';
            else fout<<"NU"<<'\n';
        }
    }
    return 0;
}
