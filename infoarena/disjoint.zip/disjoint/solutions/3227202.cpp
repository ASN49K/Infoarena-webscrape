#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

const int maxn = 1e5+5;

int tt[maxn], rg[maxn];
int n, m, i, cod, x, y;

int rad(int x) {
    int r, y;
    for(r = x; tt[r] != r; r = tt[r]);
    while(tt[x] != x) {
        y = tt[x];
        tt[x] = r;
        x = y;
    }
    return r;
}

void unite(int x, int y) {
    tt[x] = y;
//    if(rg[x] > rg[y]) {
//        tt[y] = x;
//    } else {
//        tt[x] = y;
//    }
//    if(rg[x] == rg[y]) { rg[y] ++; }
}

int main()
{
    f >> n >> m;
    for(i = 1; i <= n; i ++) {
        tt[i] = i;
//        rg[i] = 1;
    }
    for(i = 1; i <= m; i ++) {
        f >> cod >> x >> y;
        if(cod == 1) {
            //if(rad(x) == rad(y)) { assert(0); }
            unite(rad(x), rad(y));
        } else {
            if(rad(x) == rad(y)) {
                g << "DA\n";
            } else {
                g << "NU\n";
            }
        }
    }
    //f.close(); g.close();
    return 0;
}