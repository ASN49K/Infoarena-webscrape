#include <fstream>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int MAX = 100005;
int arr[MAX];
vector<int> v[MAX];

void op1(int x, int y,int n) {
    if (arr[x] != arr[y]) {
        if (v[arr[x]].size() < v[arr[y]].size()) {
            swap (x,y);
        }
        int a = arr[y];
        for (auto i: v[a]) {
            v[arr[x]].push_back(i);
            arr[i]=arr[x];
        }
        v[a].clear();
    }
}

void op2(int x, int y,int n) {
    if (arr[y] == arr[x]) {
        fout<<"DA"<<'\n';
    } else {
        fout<<"NU"<<'\n';
    }
}

int main() {
    int n,m;
    fin>>n>>m;
    for (int i = 1; i <= n; i++) {
        arr[i]=i;
        v[i].push_back(i);
    }
    int type,x,y;
    for(int i=0;i<m;i++) {
        fin>>type>>x>>y;
        if (type == 1) {
            op1(x,y,n);
        } else {
            op2(x,y,n);
        }
    }
    return 0;
}
