#include <bits/stdc++.h>

using namespace std;

ifstream f("disjoint.in");
ofstream o("disjoint.out");

int n,m;
int owner[100001];
int sizes[100001];

int findsef(int x){
  if(owner[x]!=x){
    owner[x]=findsef(owner[x]);
    return owner[x];
  }
  else
    return x;
}

void unire(int x,int y){
  int xsef=findsef(x);
  int ysef=findsef(y);
  if(xsef==ysef)
    return;
  if(sizes[xsef]>sizes[ysef]){
    owner[ysef]=xsef;
    sizes[xsef]+=sizes[ysef];
  }
  else if(sizes[xsef]<sizes[ysef]){
    owner[xsef]=ysef;
    sizes[ysef]+=sizes[xsef];
  }
  else{
    owner[ysef]=xsef;
    sizes[xsef]+=sizes[ysef];
  }
}

void afis(int x, int y){
  if(findsef(x)==findsef(y))
    o<<"DA\n";
  else
    o<<"NU\n";
}

int main()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
      owner[i]=i, sizes[i]=1;
    for(int i=1;i<=m;i++){
      int cod, x, y;
      f>>cod>>x>>y;
      if(cod==1){
        unire(x,y);
      }
      else
        afis(x,y);
    }
    return 0;
}
