#include <bits/stdc++.h>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

struct data
{
    int val, tata;
};

data v[100041];
int n, m, task, x, y;

data fnd(int x2)
{
    if (v[x2].tata==x2)
        return v[x2];
    else
    {
        v[x2]=fnd(v[x2].tata);
        return v[x2];
    }
}

void uni(int x, int y)
{
    data ax=fnd(x), ay=fnd(y);
    if (ax.val<ay.val)
    {
        v[ax.tata].tata=ay.tata;
        v[ay.tata].val+=v[ax.tata].val;
    }
    else
    {
        v[ay.tata].tata=ax.tata;
        v[ax.tata].val+=v[ay.tata].val;
    }
}

void read()
{
    fin >> n >> m;
    for (int i=1;i<=n;++i)
    {
        v[i].val=1;
        v[i].tata=i;
    }
    for (int i=0;i<m;++i)
    {
        fin >> task >> x >> y;
      //  cout <<fnd(x).tata << "  " << fnd(y).tata << endl;
        if (task==2)
        {
            if (fnd(x).tata!=fnd(y).tata)
                fout << "NU\n";
            else
                fout << "DA\n";
        }
        else
        {
            uni(x,y);
        }
    }
}

int main()
{
    read();
    return 0;
}
