#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[100001];
int depth[100001];
int afl_tata(int node)
{
    while(tata[node]!=node)
    {
        node=tata[node];
    }
    int x=node;
    while(tata[x]!=x)
    {
        int y=tata[x];
        tata[x]=node;
        x=y;
    }
    return node;
}
void alp(int node1,int node2)
{
    if(depth[node1]<=depth[node2])
    {
        swap(node1,node2);
    }
    if(depth[node1]==depth[node2])
    {
        depth[node1]++;
    }
    depth[node2]=depth[node1];
    tata[node2]=node1;
}
int main()
{
    int n,m,t,a,b;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        tata[i]=i;
        depth[i]=1;
    }
    for(int i=1;i<=m;i++)
    {
        fin>>t>>a>>b;
        if(t==1)
        {
            alp(a,b);
        }
        else
        {
            if(afl_tata(a)==afl_tata(b))
            {
                fout<<"DA\n";
            }
            else fout<<"NU\n";
        }
    }
    return 0;
}
