#include <fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int sef[100001],sef1,sef2;
int sef_suprem(int x){
    if (sef[x]==x)
        return x;
    else
        return sef[x]=sef_suprem(sef[x]);
}

void unire(int x, int y){
    sef1=sef_suprem(x);
    sef2=sef_suprem(y);
    sef[sef1]=sef2;
}

int main()
{
    int n,m,cerinta,x,y;
    fin>>n>>m;
    for (int i=1; i<=m; i++){
        fin>>cerinta>>x>>y;
        if (cerinta==1)
            unire(x,y);
        else
            if (sef_suprem(x)==sef_suprem(y))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
    }
    return 0;
}