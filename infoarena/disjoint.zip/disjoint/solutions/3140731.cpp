/***
*    ███╗   ███╗ ██████╗ ██████╗  █████╗ ██████╗ ██╗██╗   ██╗████████╗██╗   ██╗██████╗  ██████╗ ██████╗ 
*     ████╗ ████║██╔═══██╗██╔══██╗██╔══██╗██╔══██╗██║██║   ██║╚══██╔══╝██║   ██║██╔══██╗██╔═══█ a█╗██╔══██╗
*      ██╔████╔██║██║   ██║██████╔╝███████║██████╔╝██║██║   ██║   ██║   ██║   ██║██║  ██║██║   ██║██████╔╝
*       ██║╚██╔╝██║██║   ██║██╔══██╗██╔══██║██╔══██╗██║██║   ██║   ██║   ██║   ██║██║  ██║██║   ██║██╔══██╗
*        ██║ ╚═╝ ██║╚██████╔╝██║  ██║██x║  ██║██║  ██║██║╚██████╔╝██╗██║   ╚██████╔╝██████╔╝╚██████╔╝██║  ██║
*         ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═╝╚═╝    ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝
*                                                                                                       
*/
#include <algorithm>
#include <bitset>
#include <cstdio> 
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits.h>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector> 

using namespace std;
 
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
 
void debug(vector<int> v)
{
    for(int i = 0;i < v.size();i++) {cout << v[i] << ' ';}
    cout << endl;
}
int firstDigit(int n)
{
    while (n >= 10) n /= 10;
    return n;
}

string decToBin(int decimal, int sz)
{
    string ans;
    int it = 0;
    while(decimal)
    {
        ans.push_back(decimal % 2 + '0');
        decimal /= 2;
    }
    reverse(ans.begin(), ans.end());
    while(ans.size() < sz) ans.insert(ans.begin(), '0');

    return ans;
}

vector<int> card, root;

void add(int x, int y)
{
    //cout << "x: " << x << " y: " << y << " card[x]: " << card[x] << " card[y]: " << card[y]; 
    //cout << endl;
    
    card[x] += card[y];
    root[y] = x;
}

int find(int x)
{
    //cout << "Suntem la " << root[x] << " x: " << x << endl;
    if(root[x] == x) return x;

    
    root[x] = find(root[x]);
    
    return root[x];
}


ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int main()
{
    int n, q; cin >> n >> q;
    //cout << n << " " << q << endl;
    card.resize(n);
    root.resize(n);

    for(int i = 0;i < n;i++)
    {
        card[i] = 1;
        root[i] = i;
    }
    
    //cout << endl;
    //debug(card);
    //debug(root);

    for(int i = 0;i < q;i++)
    {
        int o, a, b; cin >> o >> a >> b;
        a--;
        b--;
        
        if(o == 1) add(a, b);
        else 
        {
            if(find(a) == find(b)) cout << "DA" << endl;
            else cout << "NU" << endl;
        }
        debug(card);
        debug(root);
    }
    //cout << ";)" << endl;
}