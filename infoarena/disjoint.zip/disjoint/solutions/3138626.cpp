#include <iostream>
#include <fstream>
#include <map>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct DSU{

    int N;
    vector<int> parent, sizes;

    void init(int n)
    {
        N = n;
        parent.resize(N+1);
        sizes.resize(N+1);
        for(int i = 0; i < parent.size(); i++)
        {
            parent[i] = i;
            sizes[i] = 1;
        }
    }

    int findi(int x)
    {
        if(x == parent[x])
            return x;

        return (parent[x] = findi(parent[x]));
    }

    void unite(int x, int y)
    {
        x = findi(x);
        y = findi(y);
        if(x == y)
            return;
        if(sizes[y] > sizes[x])
            swap(x, y);
        parent[y] = x;
        sizes[x] += sizes[y];
    }

};

int main()
{
    int n, m;
    fin >> n >> m;
    DSU ds;
    ds.init(n);
    for(int i = 0; i < m; i++)
    {
        int op, x, y;
        fin >> op >> x >> y;
        if(op == 1)
            ds.unite(x, y);
        else
        {
            int cls1 = ds.findi(x);
            int cls2 = ds.findi(y);
            //cout << cls1 << " " << cls2;
            if(cls1 == cls2)
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
