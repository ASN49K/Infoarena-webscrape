#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
vector<int> t;
int tata(int x)
{
    if(t[x]==x)
        return x;
    int aux=tata(t[x]);
    t[x]=aux;
    return aux;
}

int main()
{
    int n,m,i,tx,a,b,c,ty;
    fin>>n>>m;
    t.resize(n+1);
    for(i=1;i<=n;i++)
        t[i]=i;
    for(i=0;i<m;i++)
    {
        fin>>a>>b>>c;
        if(a==2)
        {
            tx=tata(b);
            ty=tata(c);
            if(tx==ty)
            {
                fout<<"DA"<<'\n';
            }
            else
            {
                fout<<"NU"<<'\n';
            }
        }
        else if(a==1)
        {
            t[b]=c;
        }
    }
    return 0;
}
