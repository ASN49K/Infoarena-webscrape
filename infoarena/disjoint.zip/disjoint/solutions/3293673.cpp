#include <fstream>

using namespace std;
ifstream fcin("disjoint.in");
ofstream fout("disjoint.out");
int n,q,p[101001],c,a,b;
inline int locate(int x)
{
    if(p[x]<0) return x;
    return p[x]=locate(p[x]);
}
inline void query(int x, int y, int caz)
{
    int px=locate(x);
    int py=locate(y);
    if(caz==1)
    {
        if(p[px]>p[py])
        {
            p[py]+=p[px];
            p[px]=y;
        }
        else
        {
            p[px]+=p[py];
            p[py]=x;
        }
    }
    if(caz==2)
    {
        if(px==py) fout<<"DA\n";
        else fout<<"NU\n";
    }
}
int main()
{
    fcin>>n>>q;
    for(int i=1; i<=n; i++)
        p[i]=-1;
    while(q--)
    {
        fcin>>c>>a>>b;
        query(a,b,c);
    }
    return 0;
}
