#include <fstream>

using namespace std;

int n, m, p[100005], r;

ifstream in;
ofstream out;

int gp(int x)
{
    if (p[x] == x)
        return x;
    else
    {
        int pr = gp(p[x]);
        p[x] = pr;
        return pr;
    }
}

int main()
{
    in.open("disjoint.in");
    out.open("disjoint.out");
    in >> n >> m;
    for (int i = 0; i < n; i++)
    {
        p[i] = i;
    }
    r = n;
    for (int i = 0; i < m; i++)
    {
        int c, a, b;
        in >> c >> a >> b;
        if (c == 1)
        {
            p[gp(a)] = gp(b);
        }
        else
        {
            if (gp(a) == gp(b))
            {
                out << "DA\n";
            }
            else
            {
                out << "NU\n";
            }
        }
    }
    return 0;
}