#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int Nmax=100005;
int p[Nmax],d[Nmax];
int sef(int x)
{
    if(p[x]==x)
    {
        return x;
    }
    p[x]=sef(p[x]);
    return p[x];
}
int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        p[i]=i;
        d[i]=1;
    }
    int c,x,y;
    for(int i=1;i<=m;i++)
    {
        fin>>c>>x>>y;
        if(c==1)
        {
            int sef1=sef(x);
            int sef2=sef(y);
            if(d[sef2]<=d[sef1])
            {
                p[sef2]=sef1;
                d[sef1]=max(1+d[sef2],d[sef1]);
            }
            else
            {
                p[sef1]=sef2;
                d[sef2]=max(1+d[sef1],d[sef2]);
            }
        }
        if(c==2)
        {
            if(sef(x)==sef(y))
            {
                fout<<"DA"<<'\n';
            }
            else fout<<"NU"<<'\n';
        }
    }
    return 0;
}
