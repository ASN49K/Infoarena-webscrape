#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
struct paduri{
    vector<int>tata;
    vector<int>sizeElem;
    paduri(int n){
        tata.resize(n+1,0);
        sizeElem.resize(n+1,1);
    }
    int root(int a){
        if(tata[a]==0){
            return a;
        }
        tata[a]=root(tata[a]);
        return tata[a];
    }
    bool query(int a,int b){
        return root(a)==root(b);
    }
    void join(int a,int b){
        a=root(a);
        b=root(b);
        if(sizeElem[a]<sizeElem[b]){
            swap(a,b);
        }
        tata[b]=a;
        sizeElem[a]+=sizeElem[b];
    }
};
int main()
{
    int n,m;
    fin>>n>>m;
    paduri p=paduri(n);
    int cer,x,y;
    for(int i=0;i<m;++i){
        fin>>cer>>x>>y;
        if(cer==1){
            p.join(x,y);
        }else{
            bool answr=p.query(x,y);
            fout<<((answr==1)?  "DA":"NU")<<"\n";
        }
    }
    return 0;
}
