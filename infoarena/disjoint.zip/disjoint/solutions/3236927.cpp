#include <bits/stdc++.h>
#define int long long
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int MAX_NUM = 1e5;

int n, m, parent[MAX_NUM], treeRank[MAX_NUM];

int find(int x) {
	int root = x;
	while (parent[root] != root) {
		root = parent[root];
	}
	while (x != root) {
        x = parent[x];
        parent[x] = root;
	}
	return root;
}

void unify(int x, int y) {
	if (treeRank[x] > treeRank[y]) {
		parent[y] = x;
	} else {
        parent[x] = y;
	}
	if (treeRank[x] == treeRank[y]) {
        ++treeRank[y];
	}
}

signed main() {
    fin >> n >> m;
	for (int i = 1; i <= n; ++i) {
		parent[i] = i;
		treeRank[i] = 1;
	}
	for (int i = 0; i < m; ++i) {
        int x, y, cod;
        fin >> cod >> x >> y;
		if (cod == 2){
			if (find(x) == find(y)) {
                fout << "DA\n";
			} else {
                fout << "NU\n";
			}
		} else {
            unify(find(x), find(y));
        }
	}
	return 0;
}
