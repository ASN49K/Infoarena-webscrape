#include <bits/stdc++.h>

using namespace std;
long long dp[5005][5005];///i alergatori, j diferiti
int main()
{
    ifstream cin("100m.in");
    ofstream cout("100.out");

    long long n,suma=0;
    cin>>n;
    dp[1][1]=1;
    for(int i=2;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            dp[i][j]=(dp[i-1][j]*j+dp[i-1][j-1]*j)%666013;
        }
    }
    for(int i=1;i<=n;i++)
        suma=(suma+dp[n][i])%666013;
    cout<<suma;
    return 0;
}
