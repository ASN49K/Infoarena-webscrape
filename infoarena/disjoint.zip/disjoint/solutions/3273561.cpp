#include <bits/stdc++.h>
#include<fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[100002], h[100002];

int getroot(int x)
{
    int root=x;
    while(tata[root]!=root)
        root=tata[root];
    while(x!=tata[x]) //x!=root
    {
        int tx=tata[x];
        tata[x]=root;
        x=tx;
    }
    return root;
}

void unite(int x, int y)
{
    x=getroot(x);
    y=getroot(y);
    if(h[x]<h[y])
        tata[x]=y;
    else if(h[x]==h[y]){
        tata[x]=y;
        h[y]++;}
    else
        tata[y]=x;
}

int main()
{
    int N, M, x, y, op;
    fin>>N>>M;
    for(int i=1;i<=N;i++)
    {
        tata[i]=i;
        h[i]=1;
    }
    for(int i=1; i<=M; i++)
    {
        fin>>op>>x>>y;
        if(op==1)
            unite(x, y);
        else
            if(getroot(x)==getroot(y))
                fout<<"DA"<<"\n";
            else fout<<"NU"<<"\n";
    }


    return 0;
}
