#include <bits/stdc++.h>

using namespace std;

#define cin fin
#define cout fout
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct dsu
{
    vector<int> p, sz;

    dsu(int n)
    {
        p.resize(n + 1);
        sz.resize(n + 1);
        for (int i = 1; i <= n; ++i)
        {
            p[i] = i;
            sz[i] = 1;
        }
    }

    int find_parent(int node) // reprezentantul lui node
    {
        if (p[node] == node)
        {
            return node;
        }
        return find_parent(p[node]);
    }

    void unite(int x, int y)
    {
        x = find_parent(x);
        y = find_parent(y);
        if (x == y)
        {
            return;
        }
        if (sz[x] > sz[y])
        {
            swap(x, y);
        }
        p[x] = y;
        sz[y] += sz[x];
    }
};

int32_t main()
{
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    dsu tree(n);
    while (m--)
    {
        int type;
        int u, v;
        cin >> type >> u >> v;
        if (type == 1)
        {
            tree.unite(u, v);
        }
        else
        {
            u = tree.find_parent(u);
            v = tree.find_parent(v);
            if (u == v)
            {
                cout << "DA\n";
            }
            else
            {
                cout << "NU\n";
            }
        }
    }
}