#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int M,N,cod,x,y;
int T[100005],k;

int determinare(int x)
{
    if(T[x]==0)
        return x;
    else
        return determinare(T[x]);
}

void legare(int x,int y)
{
    int kx = determinare(x);
    int ky = determinare(y);
    if(kx!=ky)
        T[ky]=kx;
}
int main()
{
    fin>>N>>M;
    for(int i=1;i<=M;i++)
    {
        fin>>cod>>x>>y;
        if(cod == 1)
        {
            legare(x,y);
        }
        else
        {
            if(determinare(x) == determinare(y))
                fout<<"DA"<<"\n";
            else
                fout<<"NU"<<"\n";

        }
    }
}
