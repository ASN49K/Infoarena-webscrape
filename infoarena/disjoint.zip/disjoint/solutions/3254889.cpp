#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

int n,m,x,y;
int tat[100005],inalt[100005];

int rad(int nod)
{
    if(nod==tat[nod])
        return nod;
    int rnod=rad(tat[nod]);
    tat[nod]=rad(rnod);
    return rnod;
}

void reuniune()
{
    int rx=rad(x);
    int ry=rad(y);
    if(inalt[rx]>inalt[ry])
    {
        tat[ry]=rx;
    }
    else if(inalt[ry]>inalt[rx])
        tat[rx]=ry;
    else
    {
        tat[ry]=rx;
        inalt[rx]++;
    }
}

int inter()
{
    return(rad(x)==rad(y));
}

int main()
{
    fin>>n>>m;
    int cod,a,b;
    for(int k=1;k<=n;k++)
    {
        tat[k]=k;
        inalt[k]=1;
    }
    for(;m>0;--m)
    {
        fin>>cod>>x>>y;
        if(cod==1)
        {
            reuniune();
        }
        else
        {
            if(inter())
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';

        }
    }

    return 0;
}
