#include <iostream>
#include <fstream>

#define NMAX 100001

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct node{
    int rang;
    node *parent;
};

int n, m;
int cod;
int x, y;
node* v[NMAX];

node *findParent(node *n){
    if (n->parent != nullptr){
        n->parent=findParent(n->parent);
        return n->parent;
    }
    return n;
}

void reunion(node *a, node *b){
    a = findParent(a);
    b = findParent(b);
    if (a!=b){
        if (a->rang > b->rang){
            b->parent=a;
        }
        else if (a->rang < b->rang){
            a->parent=b;
        }
        else{
            a->parent=b;
            b->rang+=1;
        }
    }
}

int main()
{

    fin >> n >> m;
    for (int i=1; i<=n; ++i){
        v[i] = new node;
        v[i]->parent = nullptr;
    }
    for (int i=1; i<=m; ++i){
        fin >> cod >> x >> y;
        if (cod==1){
            reunion(v[x],v[y]);
        }
        else if (cod==2){
            if (findParent(v[x])==findParent(v[y])){
                fout << "DA" << '\n';
            }
            else{
                fout << "NU" << '\n';
            }
        }
    }
    return 0;
}
