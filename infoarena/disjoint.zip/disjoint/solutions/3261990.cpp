#include <bits/stdc++.h>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
#define nMax 100005

int tat[nMax], n;

int rad(int x)
{
    if(tat[x] == 0)
        return x;
    return rad(tat[x]);
}

void Union(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);
    if(rx < ry)
        swap(rx, ry);
    tat[rx] = ry;
}

bool Find(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);
    return rx == ry;
}

int main()
{
    short operatie;
    int x, y;
    int q;
    f >> n >> q;
    while(q--)
    {
        f >> operatie >> x >> y;
        if(operatie == 1)
            Union(x, y);
        else
            if(operatie == 2)
        {
            if(Find(x, y))
                g << "DA\n";
            else
                g << "NU\n";
        }
    }
}
