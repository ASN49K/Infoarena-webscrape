#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[100003],rang[100003];
inline void combina(int a,int b)
{
    if (rang[a]>=rang[b]) tata[b]=a,rang[a]++;
    else tata[a]=b,rang[b]++;
}
inline int findtata(int nod)
{
    int aux=nod;
    while (nod!=tata[nod]) nod=tata[nod];
    while (tata[aux]!=aux)
    {
        int y=tata[aux];
        tata[aux]=nod;
        aux=y;
    }
    return nod;
}
int n,m,op,x,y;
int main()
{
    fin>>n>>m;
    for (int i=1;i<=n;i++)
        tata[i]=i;
    while (m--)
    {
        fin>>op>>x>>y;
        if (op==1) combina(x,y);
        else
        {
            if (findtata(x)==findtata(y))
                fout<<"DA";
            else
                fout<<"NU";
            fout<<'\n';
        }
    }
    return 0;
}
