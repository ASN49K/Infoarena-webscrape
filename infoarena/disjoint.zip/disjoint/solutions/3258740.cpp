#include <bits/stdc++.h>
#include<fstream>
#include<vector>
using namespace std;

ifstream f("disjoint.in");
ofstream of("disjoint.out");


struct DSU
{
    int rep[100],sz[100];

    DSU(int n)
    {
        for(int i=1;i<=n;i++)
        {rep[i]=i;
        sz[i]=1;}
    }




    int get_rep(int nod)
    {
       if(nod==rep[nod])
        return nod;
       else
        return rep[nod]=get_rep(rep[nod]);
    }







    bool same_comp(int a,int b)
    {
        return get_rep(a)==get_rep(b);

    }
    void join(int a,int b)
    {
        int ra=get_rep(a);
        int rb=get_rep(b);


        if(sz[ra]>sz[rb])
        {rep[rb]=ra;
        sz[ra]+=sz[rb];}
        else
           {rep[ra]=rb;
        sz[rb]+=sz[ra];}
    }


};






int main()
{

    int m,n;
    f>>n;
    f>>m;

    DSU dfs(n);
    while(m)
    {
        m--;
        int o,x,y;
        f>>o>>x>>y;
        if(o==1)
        dfs.join(x,y);
        if(o==2)
            if(dfs.same_comp(x,y))
            of<<"DA"<<endl;
        else of<<"NU"<<endl;
    }




    return 0;
}
