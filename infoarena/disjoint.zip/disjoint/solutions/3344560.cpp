// Union find.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int find(int i, vector<int>& parent)
{
    if (parent[i] == i)
        return i;
    return find(parent[i],parent);
}
void unite(int i, int j, vector<int>& parent)
{
    int irep = find(i, parent);
    int jrep = find(j, parent);
    parent[irep] = jrep;
}
int main()
{
    ifstream f("disjoint.in");
    ofstream g("disjoint.out");
    int n, m;
    f >> n >> m;
    vector<int> parent(n + 1);
    for (int i = 1; i <= n; i++)
    {
        parent[i] = i;
    }
    for (int i = 0; i < m; i++)
    {
        int a, b, c;
        f >> a >> b >> c;
        if (a == 2)
        {
            if (find(b, parent) == find(c, parent))
                g << "DA"<<endl;
            else
                g << "NU"<<endl;
        }
        else
        {
            unite(b, c, parent);
        }
    }
}

