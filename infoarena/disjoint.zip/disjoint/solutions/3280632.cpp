#include <fstream>

using namespace std;
const int NMAX = 100001;

int n, m, op, T[NMAX];

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int Find(int i)
{
    if(T[i] == 0) return i;
    return T[i] = Find(T[i]);
}

inline void Union(int rx, int ry)
{
    T[ry] = rx;
}

int main()
{
    int x, y;
    f >> n >> m;
    while(m--)
    {
        f >> op >> x >> y;
        int rx = Find(x),
            ry = Find(y);
        if(op == 1) Union(rx, ry);
        else g << (rx == ry ? "DA\n" : "NU\n");
    }
    f.close();
    g.close();
    return 0;
}
