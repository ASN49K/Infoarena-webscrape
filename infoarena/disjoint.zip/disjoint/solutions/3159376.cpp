#include <iostream>
#include <fstream>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
int tata[100001]

int sef(int x)
{
	if(tata[x] == x) return x;
	return tata[x] = sef(tata[x]);
}

void unire(int x, int y)
{
	int sefx = sef(x);
	int sefy = sef(y);
	tata[sefy] = sefx;
}

int main()
{
	int n,m,i;
	int tip,x,y;
	in>>n>>m;
	for(i=1; i<=m; i++)
	{
		in>>tip>>x>>y;
		if(tip==1)
		{
			unire(x,y);
		}
		if(tip==2)
		{
			if(sef(x) == sef(y))
			{
				out<<"DA\n";
			}
			else
			{
				out<<"NU\n";
			}
		}
	}
	return 0;
}