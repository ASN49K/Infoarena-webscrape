#include <fstream>
#define NMAX 100005
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[NMAX];
int h[NMAX];///inalt arborului cu rad i
int n,m,i,cod,a,b;
void Union(int x,int y);
int Find(int x);
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        tata[i]=i;
        h[i]=1;
    }
    fin>>m;
    for(i=1;i<=m;i++)
    {
        fin>>cod>>a>>b;
        if(cod==1) {if(Find(a)!=Find(b))Union(a,b);}
           else
        {
            if(Find(a)==Find(b))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    ///fac niste union si find si afisari

    return 0;
}
void Union(int x,int y)
{
    if(h[x]<h[y])
        tata[x]=y;
    else
    if(h[y]<h[x])
        tata[y]=x;
    else
        {
            tata[y]=x; ///aici nu conteaza
            h[y]++;
        }
}
int Find(int x)
{
    ///mai intai aflu rad arb din care e x
    int r=x,y;
    while(tata[r]!=r) r=tata[r];
    ///parcurg iar de la x la r si frac toate nodurile fii a lui r

    return tata[x];

}
