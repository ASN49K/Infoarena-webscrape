/// Aceasta sursa este pentru problema
/// https://www.infoarena.ro/problema/disjoint
/// Punctaj: 100
/// Grupa de seniori

#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout("disjoint.out");

int n,m,i,c,x,y;
struct nod
{
    int par;
    int poz;
};
vector<nod>pad;
void init(int n)
{
    pad.resize(n);
    for(i=0;i<n;i++)
    {
        pad[i].par=i;
        pad[i].poz=0;
    }
}
int gaseste(int i)
{
    if(pad[i].par==i)
        return pad[i].par;
    else
        pad[i].par=gaseste(pad[i].par);
}
void uneste(int s1, int s2)
{
    int reps1=gaseste(s1);
    int reps2=gaseste(s2);
    if(pad[s1].poz<pad[s2].poz)
        pad[reps1].par=reps2;
    else if(pad[reps1].poz>pad[reps2].poz)
        pad[reps2].par=reps1;
    else
    {
        pad[reps2].par=reps1;
        pad[reps1].poz++;
    }
}
int main()
{
    fin>>n>>m;
    init(n);
    for(i=0;i<m;i++)
    {
        fin>>c>>x>>y;
        switch(c)
        {
            case 1:
                uneste(x,y);
                break;
            case 2:
                if(gaseste(x)==gaseste(y))
                    fout<<"DA"<<'\n';
                else
                    fout<<"NU"<<'\n';
        }
    }
	return 0;
}
