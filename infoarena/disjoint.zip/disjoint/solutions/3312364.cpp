#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,m,cod,a,b;
int parent[100005],h[100005];
int Find(int x)
{
    if(parent[x]==x)return x;
    return parent[x]=Find(parent[x]);
}

void Union(int x, int y)
{
    x=Find(x);
    y=Find(y);

    if(x==y)return;
    else if(h[x]<h[y])parent[x]=y;
    else if(h[y]<h[x])parent[y]=x;
    else if(h[x]==h[y]){
        h[y]++;
        parent[x]=y;
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        parent[i]=i;
        h[i]=1;
    }
    for(int i=1;i<=m;i++)
    {
        fin>>cod>>a>>b;
        if(cod==1)
            Union(a,b);
        if(cod==2)
        {
            if(Find(a)==Find(b))
                fout<<"DA"<<'\n';
            if(Find(a)!=Find(b)) fout<<"NU"<<'\n';
        }
    }
    return 0;
}
