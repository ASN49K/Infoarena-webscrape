#include <bits/stdc++.h>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
const int N = 100010;
int n,m,o,x,y,T[N];
int main()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
        T[i]=i;
    for(int i=1;i<=m;i++)
    {
        f>>o>>x>>y;
        while(T[x]!=x)x=T[x];
        while(T[y]!=y)y=T[y];
        if(o==1)
            T[x]=y;
        else if(x==y)
            g<<"DA\n";
        else
            g<<"NU\n";
    }
    return 0;
}
