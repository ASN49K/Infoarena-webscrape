#include <fstream>

using namespace std;
ifstream cin ("disjoint.in");
ofstream cout ("disjoint.out");
int tata[100001];
int sef(int x)
{
    if(x==tata[x])
        return x;
    else
        return tata[x]=sef(tata[x]);
}
void unire(int x,int y)
{
    int s1,s2;
    s1=sef(x);
    s2=sef(y);
    tata[s2]=s1;
}
int main()
{
    int n,q,i,cer,x,y;
    cin>>n;
    for(i=1;i<=n;i++)
        tata[i]=i;
    cin>>q;
    for(i=1;i<=q;i++)
    {
        cin>>cer>>x>>y;
        if(cer==1)
           unire(x,y);
        else
            if(sef(x)==sef(y))
                cout<<"DA\n";
            else
                cout<<"NU\n";
    }
    return 0;
}
