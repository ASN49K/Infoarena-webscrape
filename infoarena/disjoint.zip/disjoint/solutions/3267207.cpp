#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out ");
int i,n,m,t[100010],v[100010],c,x,y;

int qu(int k)
{
    if(t[k]==k)
        return k;
    t[k]=qu(t[k]);
    return t[k];
}

void up(int a, int b)
{
    int ta=qu(a);
    int tb=qu(b);
    if(v[ta]<v[tb])
        t[ta]=tb;
    else if(v[ta]>v[tb])
        t[tb]=ta;
    else
    {
        t[ta]=tb;
        v[tb]++;
    }
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    fin>>n>>m;
    for(i=1; i<=n; i++)
        t[i]=i;
    for(i=1; i<=m; i++)
    {
        fin>>c>>x>>y;
        if(c==1)
            up(x,y);
        else
        {
            x=qu(x);
            y=qu(y);
            if(x==y)
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    return 0;
}
