#include <iostream>
#include <fstream>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
void unire(int x, int y);
int sef(int x);

int tata[100001];
int main()
{
    int i, n, m, cod, x, y;
    in >> n >> m;
    for(i = 1; i <= n; i++)
    {
        tata[i] = i;
    }
    for(i = 1; i <= m; i++)
    {
        in >> cod >> x >> y;
        if(cod == 1)
        {
            unire(x, y);
        }
        else
        {
            if(sef(x) == sef(y))
            {
                out << "DA" << endl;
            }
            else
            {
                out << "NU" << endl;
            }
        }
    }
    return 0;
}

void unire(int x, int y)
{
    int sefx = sef(x);
    int sefy = sef(y);
    tata[sefx] = sefy;
}

int sef(int x)
{
    if(tata[x] == x)
    {
        return x;
    }
    else
    {
        return x = sef(tata[x]);
    }
}
