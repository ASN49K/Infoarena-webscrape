#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <bitset>
#include <stack>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

vector<int> G[100005];
int n, t[100005], m, rang[100005];

int Rad(int x)
{
	if (t[x] == 0)
		return x;
	int k = Rad(t[x]);
	t[x] = k;
	return k;
}

void Reu(int p, int r)
{
	if (rang[p] > rang[r])
		t[r] = p;
	else
	{
		t[p] = r;
		if (rang[p] == rang[r])
			rang[r]++;
	}
}

int main()
{
	int i, j, op, x, y;
	fin >> n >> m;
	while (m--)
	{
		fin >> op >> x >> y;
		x = Rad(x);
		y = Rad(y);
		if (op == 1)
		{
			if (x != y) Reu(x, y);
		}
		else
		{
			if (x == y) fout << "DA\n";
			else fout << "NU\n";
		}
	}
	return 0;
}