﻿#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000
#define MOD 1000000007
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int r[100005], t[100005], n, m, op, x, y;
void Union(int x, int y)
{
	if (r[x] > r[y])
		t[y] = x;
	else
	{
		t[x] = y;
		if (r[x] == r[y])
			r[y]++;
	}
}
int Find(int x)
{
	if (t[x] == 0)
		return x;
	int y = Find(t[x]);
	t[x] = y;
	return y;
}
int main()
{
	fin >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		fin >> op >> x >> y;
		if (op == 1)
			Union(x, y);
		else
		{
			int val1 = Find(x);
			int val2 = Find(y);
			if (val1 != val2)
				fout << "NU\n";
			else
				fout << "DA\n";
		}
	}

}
