#include <fstream>
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");
int n,m,i,ch,x,y,q,t[100001],a,b;
int f (int x)
{
    if (x==t[x])
        return x;
    return t[x]=f (t[x]);
}
void join (int x,int y)
{
    a=f (x);
    b=f (y);
    t[a]=b;
}
int main ()
{
    fin>>n>>m;
    for (i=1; i<=n; i++)
        t[i]=i;
    for (q=1; q<=m; q++)
    {
        fin>>ch>>x>>y;
        if (ch==1)
            join (x,y);
        else
        {
            if (f (x)==f (y))
                fout<<"DA\n";
            else
                fout<<"NU\n";
        }
    }
    return 0;
}
