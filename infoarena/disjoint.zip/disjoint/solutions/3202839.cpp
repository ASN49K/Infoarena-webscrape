#include<bits/stdc++.h>
using namespace std;

string numeFisier="disjoint";
ifstream fin(numeFisier+".in"); ofstream fout(numeFisier+".out");
#define cin fin
#define cout fout

#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
//#define int ll


int n, m;
int par[100010];
int sz[100010];

int findPar(int u){
if(par[u]==u){
    return u;
}

par[u]=findPar(par[u]);
return par[u];

}


void join(int u, int v){

u=findPar(u), v=findPar(v);
if(u==v)return;

if(sz[u]>sz[v]){
    par[v]=u;
    sz[u]+=sz[v];
}
else{
    par[u]=v;
    sz[v]+=sz[u];
}


}


int32_t main(){
INIT
cin>>n>>m;
for(int i=1; i<=n; i++){
    par[i]=i;
}

for(int i=1; i<=m; i++){
    int tp, u, v;
    cin>>tp>>u>>v;
    if(tp==1){
        join( findPar(u), findPar(v) );
    }
    if(tp==2){
        cout<<((findPar(u)==findPar(v))?("DA\n"):("NU\n"));
    }
}


return 0;
}
