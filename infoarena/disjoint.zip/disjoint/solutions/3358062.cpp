#include <bits/stdc++.h>
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
using namespace std;
int n,m,p[100005],h[100005];
int find(int nod)
{
    int cop=nod,rez;
    while(nod!=p[nod])
        nod=p[nod];
    rez=nod;
    nod=cop;
    while(nod!=p[nod])
    {
        int c=p[nod];
        p[nod]=rez;
        nod=c;
    }
    return rez;
}
void unite(int a,int b)
{
    if(a==b)
        return;
    if(h[a]<h[b])
        swap(a,b);
    else if(h[a]==h[b])
    {
        h[a]++;
        h[b]++;
    }
    p[b]=a;
}
int main()
{
    fin>>n>>m;
    int c,x,y;
    for(int i=1; i<=n; i++)
    {
        p[i]=i;
        h[i]=1;
    }
    for(int i=1; i<=m; i++)
    {
        fin>>c>>x>>y;
        if(c==1)
            unite(find(x),find(y));
        else
        {
            if(find(x)==find(y))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    return 0;
}
