///circular
#include <bits/stdc++.h>
#define MOD 30011
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int i,j,n,q,c,x,y,t[100010],h[100010];

int qu(int k)
{
    if(k==t[k])
        return k;
    return t[k]=qu(t[k]);
}

void up(int a,int b)
{
    int ta=qu(a);
    int tb=qu(b);
    if(h[ta]>h[tb])
        t[tb]=ta;
    else if(h[ta]<h[tb])
        t[ta]=tb;
    else
    {
        t[ta]=tb;
        h[tb]++;
    }
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n>>q;
    for(i=1; i<=n; i++)
        t[i]=i;
    for(i=1; i<=q; i++)
    {
        fin>>c>>x>>y;
        if(c==1)
            up(x,y);
        else
        {
            if(qu(x)==qu(y))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    return 0;
}
