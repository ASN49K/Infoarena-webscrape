#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int Nmax = 1e5+1;

struct DSU {
	int rep[Nmax], sz[Nmax];
	//constructor
	DSU(int n) {
		for (int i = 1; i <= n; i++) {
			rep[i] = i;
			sz[i] = 1;
		}
	}

	//functia care ne da radacina arborelui nodului "nod"
	int get_rep(int nod) {
		//cu path compression
		if (rep[nod] == nod) {
			return nod;
		}
		else {
			int rnod = get_rep(rep[nod]);
			rep[nod] = rnod;
			return rnod;
			//return rep[nod]=get_rep(rep[nod]);
		}

	}

	//functie prin care verificam daca a si b sunt in aceeasi componenta
	int same_comp(int a, int b) {
		int ra = get_rep(a);
		int rb = get_rep(b);
		if (ra == rb) return 1;
		else return 0;
	}

	//functie care combina a si b
	void join(int a, int b) {
		int ra = get_rep(a);
		int rb = get_rep(b);
		//baga, pe b in a
		if (sz[ra] > sz[rb]) {
			rep[rb] = ra;
			sz[ra] += sz[rb];
		}
		//bagam pe a in b
		else {
			rep[ra] = rb;
			sz[rb] += sz[rb];
		}

	}
};

int main()
{
	long n,m;
	fin >> n >> m;
	DSU dsu(n);
	for (int i = 1; i <= m; i++) {
		long c,x, y;
		fin >> c >> x >> y;
		if (c == 1) {
			dsu.join(x, y);
		}
		else if (c == 2) {
			if (dsu.same_comp(x, y))fout << "DA\n";
			else fout << "NU\n";
		}
	}
	

	return 0;
}
