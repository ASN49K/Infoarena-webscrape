#include <iostream>
#include <fstream>
#include <algorithm>
#include <unordered_map>
#include <vector>
#include <tuple>
#include <queue>
#define inmat lin >= 1 && lin <= n && col >=1 && col <= m

using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

#define cin in
#define cout out


const int N = 1e5+2000;

int n, q;

int rad[N] , rang[N];

void unite(int x, int y)
{
	//unesc multimea cu rang mai mic de cea cu rang mai mare
	if (rang[x] > rang[y])
		rad[y] = x;
	else rad[x] = y;

	//in caz ca rangurile erau egale atunci cresc rangul noii multimi cu 1
	if (rang[x] == rang[y]) rang[y]++;
}

int find(int x)
{
	int R, y;

	//merang in sus pe arbore pana gasesc un nod care pointeaza catre el insusi
	for (R = x; rad[R] != R; R = rad[R]);

	//aplic compresia drumurilor
	for (; rad[x] != x;)
	{
		y = rad[x];
		rad[x] = R;
		x = y;
	}
	return R;
}

int main()
{
	cin >> n >> q;
	for (int i = 1; i <= n; i++)
	{
		rad[i] = i;
		rang[i] = 1;
	}
	for (int i = 1; i <= q; i++)
	{
		int c , x , y;
		cin >> c >> x >> y;
		if (c == 1)
		{
			unite(x, y);
		}
		else
		{
			if (find(x) == find(y))
				cout << "DA";
			else
				cout << "NU";
			cout << '\n';
		}
	}
}