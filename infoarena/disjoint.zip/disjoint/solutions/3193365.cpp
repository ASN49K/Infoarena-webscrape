#include <iostream>
#include <fstream>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int MAX = 100000;
int n, father[MAX+1];

int find(int x);

void init (int n)
{
   int i;
   for(i=0; i<n; ++i)
   {
    father[i]=i;
   }
}

void unite(int x, int y)
{
   int setx, sety;
   setx=find(x);
   sety=find(y);
   if(setx!=sety)
      father[setx]=sety;
}

int find(int x)
   {
      if(father[x]==x)
        return x;
      return father[x] = find(father[x]);
   }

int main()
{
    int m, p, x, y, i;
    in>>n>>m;
    init(n);
    for(int i=0; i<m; ++i)
    {
       in>>p>>x>>y;

       if(p==1)
       {
         unite(x, y);
       }
       else
       {
          if( find(x)== find(y) )
            out<<"DA"<<'\n';
          else
            out<<"NU"<<'\n';
       }
    }
    return 0;
}
