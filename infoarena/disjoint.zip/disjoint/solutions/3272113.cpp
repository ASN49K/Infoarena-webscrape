#include <bits/stdc++.h>

using namespace std;
ifstream in ("disjoint.in");
ofstream out ("disjoint.out");
int t[100008],rang[100021],n,m,o,x,y;
int r(int c)
{
    if(t[c]!=0)
        {
            int k=r(t[c]);
            t[c]=k;
            return k;
        }
        return c;

}
void op1(int x,int y)
{
    int rx=r(x), ry=r(y);
    if(rx>ry)
        t[rx]=ry;
    else
        {
            t[ry]=rx;
            if(rang[x]==rang[y])
                rang[y]++;
        }
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;i++)
    {
        in>>o>>x>>y;
        if(o==1)
            op1(x,y);
        else if(r(x)==r(y))
            out<<"DA\n";
            else
                out<<"NU\n";
    }
    return 0;
}
