#include <iostream>
#include <fstream>
using namespace std;
const int NMAX = 100001;
ifstream f("disjoint.in");
ofstream g("disjoint.out");

int N, M,
       T[NMAX];

int Find(int x)

{
    if(T[x] == 0)
        return x;
    return T[x] = Find(T[x]);
}

inline void Union(int rx, int ry)
{
    T[rx] = ry;
}

int main()
{
    int cod, x, y, rx, ry;
    f >> N >> M;
    while(M--)
    {
        f >> cod >> x >> y;
        rx = Find(x);
        ry = Find(y);
        if(cod == 1)
        {
            Union(rx, ry);
        }
        else
            if(rx == ry)
            g << "DA\n";
        else
            g << "NU\n";
    }
    f.close();
    g.close();
    return 0;
}
