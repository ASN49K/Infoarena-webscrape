#include <unordered_map>

using namespace std;

/* #include <iostream> */
#include <fstream>
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int main() {
    int n, q;
    cin >> n >> q;
    unordered_map<int, int> parents;
    for (int i = 1; i <= n; i++) {
        parents[i] = i;
    }

    for (int _ = 0; _ < q; _++) {
        int t, a, b;
        cin >> t >> a >> b;

        int rootA = a, rootB = b;
        while (parents[rootA] != rootA) {
            rootA = parents[rootA];
        }
        while (parents[rootB] != rootB) {
            rootB = parents[rootB];
        }
        if (t == 1) {
            parents[rootA] = rootB;
        } else {
            cout << (rootA == rootB ? "DA\n" : "NU\n");
        }
    }
    return 0;
}
