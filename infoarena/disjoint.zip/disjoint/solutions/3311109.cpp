#include <fstream>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
// doar un array
int n, m, op, a, b, t[100000];

int root(int x){
    if(t[x] < 0) return x;
    return t[x] = root(t[x]);
}

void un(int x, int y){
    x = root(x) , y = root(y);
    if(x != y){
        if(t[x] < t[y]){
            t[x] += t[y];
            t[y] = x;
        }else{
            t[y] += t[x];
            t[x] = y;
        }
    }
}

signed main()
{
    cin >> n >> m;
    for(int i = 0 ; i < n ; ++i) t[i] = -1;
    for(int i = 0 ; i < m ; ++i){
        cin >> op >> a >> b;
        a-- , b--;
        if(op == 1) un(a,b);
        else if(root(a) == root(b)) cout << "DA\n";
        else cout << "NU\n";
    }
    return 0;
}
