#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 100000

int t[N+1], nr[N+1];

int radacina(int x)
{
    if (t[x] == 0)
    {
        return x;
    }
    t[x] = radacina(t[x]);
    return t[x];
}

void reuniune(int x, int y)
{
    int rx = radacina(x);
    int ry = radacina(y);
    if (rx == ry)
    {
        return;
    }
    if (nr[rx] < nr[ry])
    {
        t[rx] = ry;
        nr[ry] += nr[rx];
    }
    else
    {
        t[ry] = rx;
        nr[rx] += nr[ry];
    }
}

bool verif(int x, int y)
{
    return (radacina(x) == radacina(y));
}

int main()
{
    FILE *in, *out;
    in = fopen("disjoint.in", "r");
    out = fopen("disjoint.out", "w");
    int n, q;
    fscanf(in, "%d%d", &n, &q);
    for (int i = 1; i <= n; i++)
    {
        nr[i] = 1;
    }
    for (int i = 0; i < q; i++)
    {
        int tip, x, y;
        fscanf(in, "%d%d%d", &tip, &x, &y);
        if (tip == 1)
        {
            reuniune(x, y);
        }
        else
        {
            if (verif(x, y))
            {
                fprintf(out, "DA\n");
            }
            else
            {
                fprintf(out, "NU\n");
            }
        }
    }
    fclose(in);
    fclose(out);
    return 0;
}
