#include <fstream>
#define NMAX 100005
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int tata[NMAX];
int h[NMAX];
void Union(int x, int y)
{
 if(h[x]<h[y])
   {
    tata[x]=y;
   }
   else
   if(h[y]<h[x])
     {
      tata[y]=x;
     }
     else
     {
      tata[y]=x;
      h[y]++;
     }
}
int Find(int x)
{
 int r, y;
 r=x;
 while(tata[r]!=r)
       r=tata[r];
 do{
    y=tata[x];
    tata[x]=r;
    x=y;
 }
 while(tata[x]!=r);
 return tata[x];
}
int main()
{
 int n, m, multimex, multimey;
 int x, y, c;
 fin>>n>>m;
 for(int i=1;i<=n;i++)
    {
     tata[i]=i;
     h[i]=1;
    }
 for(int i=1;i<=m;i++)
    {
     fin>>c>>x>>y;
     multimex=Find(x);
     multimey=Find(y);
     if(c==1)
       {
        Union(multimex, multimey);
       }
       else
       {
        if(multimex==multimey)
           fout<<"DA"<<'\n';
           else
           fout<<"NU"<<'\n';
       }
    }
    return 0;
}
