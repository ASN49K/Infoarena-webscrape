#include <bits/stdc++.h>

using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");

int n, m, op, x, y;

int Find(int x, vector<int> &p) {
    int r = x;
    while (r != p[r]) {
        r = p[r];
    }

    while (p[x] != x) {
        int temp = p[x];
        p[x] = r;
        x = temp;
    }

    return r;
}

void Union(int x, int y, vector<int> &p, vector<int> &r) {
    int rx = Find(x, p);
    int ry = Find(y, p);

    if (r[rx] < r[ry]) {
        p[rx] = ry;
    } else {
        p[ry] = rx;
    }

    if (r[rx] == r[ry]) {
        r[ry]++;
    }
}

int main() {
    in >> n >> m;
    vector<int> p(n + 1, 0);
    vector<int> r(n + 1, 1);

    for (int i = 1; i <= n; i++)
        p[i] = i;

    for (int i = 1; i <= m; i++) {
        in >> op >> x >> y;
        if (op == 1) {
            Union(x, y, p, r);
        } else {
            if (Find(x, p) == Find(y, p)) {
                out << "DA\n";
            } else {
                out << "NU\n";
            }
        }
    }
    return 0;
}
