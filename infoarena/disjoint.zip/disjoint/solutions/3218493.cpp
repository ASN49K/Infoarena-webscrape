#include <iostream>
#include<fstream>
#define NMAX 100001
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int tata[NMAX];
int n, m;
int h[NMAX]; ///inaltimea
int op, a, b;


int Find(int x) {
    int r, y;
    ///mai intai aflu radacina arborelui din care face parte x
    r = x;
    while (tata[r] != r) {
        r = tata[r];
    }
    ///parcurg din nou drumul de la x la r si fac toate nodurile fii ai lui r

    do {
        y = tata[x];
        tata[x] = r;
        x = y;
    } while (x != r);

    return r;
}

void Union(int x, int y) {

    if (Find(x) != Find(y)) {
        if (h[x] < h[y]) {
            tata[x] = y;
        } else if (h[y] < h[x]) {
            tata[y] = x;
        } else {
            tata[y] = x, h[y]++;
        }
    }
}


int main()
{
    fin >> n >> m;
    for (int i = 1; i<=n; i++) {
        h[i] = 1, tata[i] = i;
    }

    for (int i = 1; i<=m; i++) {
        fin >> op >> a >> b;
        if (op == 1) {
            Union(a, b);
        } else {
            if (Find(a) == Find(b)) {
                fout << "DA\n";
            } else {
                fout << "NU\n";
            }
        }
    }
    return 0;
}
