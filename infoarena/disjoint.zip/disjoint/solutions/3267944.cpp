#include <fstream>
#include <cstring>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int parent[100002];
int h[100003];
int n,m;
int Find(int x)
{
   if (parent[x]==x) return x;
   else return parent[x]=Find(parent[x]);
}
void Union(int x, int y)
{
    x=Find(x);
    y=Find(y);
    if (x==y) return;
    if (h[x]<h[y])
        parent[x]=y;
    else if (h[x]>h[y])
        parent[y]=x;
    else
    {
        parent[x]=y;
        h[y]+=1;
    }
}
int main()
{
    cin>>n>>m;
    for (int i=1; i<=n; i++)
        parent[i]=i;
    for (int i=1; i<=m; i++)
    {
        int op,x,y;
        cin>>op>>x>>y;
        if (op==1)
            Union(x,y);
        else if (op==2)
        {
            if (Find(x)==Find(y)) cout<<"DA"<<'\n';
            else cout<<"NU"<<'\n';
        }
    }
}
