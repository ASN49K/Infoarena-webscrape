#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
#include <queue>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
vector <int> g[50001];
int n, m, i, x, y,c,r[1000001],a[1000001];
int Find(int x)
{
	int rep;
	if (r[x] != x)
	{
		rep=Find(r[x]);
		r[x] = rep;
	}
	return r[x];
}
void Union(int x, int y)
{
	int rx,ry;
	rx = Find(x);
	ry = Find(y);
	if (a[rx] > a[ry])
		r[ry] = rx;
	else
		if (a[rx] < a[ry])
			r[rx] = ry;
		else
		{
			r[rx] = ry;
			a[rx]++;
		}
}
int main()
{
	cin >> n >> m;
	for (i = 1; i <= n; i++)
	{
		r[i] = i;
		a[i] = 1;
	}
	for (i = 1; i <= m; i++)
	{
		cin >> c >> x >> y;

		if (c == 1)
			Union(x, y);
		if (c == 2)
			if (Find(x) == Find(y))
				cout << "DA\n";
			else
				cout << "NU\n";
	}

}