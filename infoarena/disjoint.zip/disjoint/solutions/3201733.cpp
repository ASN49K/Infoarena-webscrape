#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, m, vt[100005];
int main()
{
    fin>>n>>m;
    for(int i=0;i<m; i++)
    {
        int c, x, y;
        fin>>c>>x>>y;
        if(c==2)
            if(vt[x]==vt[y]&&vt[x]||vt[x]==y||vt[y]==x)
            fout<<"DA"<<'\n';
            else fout<<"NU"<<'\n';
        else{
            vt[y]=x;
            for(int j=y; j!=-1; j=vt[j])
            {
                if(vt[j]==0)
                    {
                        vt[y]=j;
                        for(int k=1; k<=n; k++)
                            if(vt[k]==y)
                            vt[k]=j;
                        break;
                    }
            }
        }
    }
    return 0;
}
