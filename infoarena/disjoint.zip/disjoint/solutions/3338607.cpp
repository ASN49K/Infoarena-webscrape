#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

const int NMAX=10000001;

int n,t[NMAX],m,sz[NMAX];

inline void Union(int cx, int cy)
{
    t[cx]=cy;
}

int Find(int i)
{
    if(t[i]==0)
        return i;
    return t[i]=Find(t[i]);
}

int main()
{
    int m,op,x,y,cx,cy;

    cin>>n>>m;

    while(m--)
    {
        cin>>op>>x>>y;
        cx=Find(x);
        cy=Find(y);
        if(op==1)
        {
            ///if(cx!=cy)
                Union(cx,cy);
        }else
        {
            if(cx==cy)
                cout<<"DA\n";
            else cout<<"NU\n";
        }
    }

    return 0;
}
