#include <fstream>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,m,task,x,y,t[nmax];
int get_root(int x){
    if(t[x]>0)
        return get_root(t[x]);
    return x;
}
void join(int x,int y){
    x=get_root(x),y=get_root(y);
    if(x==y)
        return ;
    if(t[x]>t[y])
        swap(x,y);
    t[x]+=t[y];
    t[y]=x;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        t[i]=-1;
    while(m--){
        cin>>task>>x>>y;
        if(task==1)
            join(x,y);
        else{
            if(get_root(x)==get_root(y))
                cout<<"DA\n";
            else
                cout<<"NU\n";
        }
    }
    return 0;
}
