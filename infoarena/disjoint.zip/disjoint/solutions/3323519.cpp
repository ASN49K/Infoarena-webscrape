#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m;

int par[100001];

int radacina(int u) {
    if(par[u] != u) {
        return radacina(par[u]);
    }

    return u;
}

int main() {
    fin >> n >> m;

    for(int i=1; i<=n; i++)
        par[i] = i;

    int op, x, y;

    while(m--) {
        fin >> op >> x >> y;

        if(op == 1) {
            int radx = radacina(x);
            int rady = radacina(y);

            par[rady] = radx;
        }

        if(op == 2) {
            if(radacina(x) == radacina(y))
                fout << "DA" << ' ';
            else
                fout << "NU" << ' ';
        }
    }

    return 0;
}
