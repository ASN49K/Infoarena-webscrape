#include <fstream>
#include <vector>

using namespace std;


int n,m,tablou[100001];
vector<int>G[100001];
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int main(){
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        tablou[i]=i,G[i].push_back(i);
    while(m--){
        int x,y,t;
        fin>>t>>x>>y;
        if(t==1){
          // if(G[y].size()<G[x].size()){
                /// pun y la x
                while(!G[y].empty()){
                    int top = G[y].back();
                    G[y].pop_back();
                    tablou[top]=x;
                    G[x].push_back(top);
                }
           //}
          /* else{
            /// pun x la y
                while(!G[x].empty()){
                    int top = G[x].back();
                    G[x].pop_back();
                    tablou[top]=y;
                    G[y].push_back(top);
                }
           } */

        }
        else{
            if(tablou[x]==tablou[y])
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }

    return 0;
}
