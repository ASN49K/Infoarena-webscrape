#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int card[100005], rad[10005];
vector<int> ord, adj[100005];
bool hasCycle = false;

void Union(int a, int b)
{
    if(card[a] < card[b])
        swap(a, b);
    card[a] += card[b];
    rad[b] = a;
}

int Find(int x)
{
    if(rad[x] == x)
        return x;
    rad[x] = Find(rad[x]);
    return rad[x];
}

int main()
{
    int n, m, t, x, y, i, task;
    fin >> n >> m;
    for(i = 1; i <= n; i++)
    {
        rad[i] = i;
        card[i] = 1;
    }
    for(i = 1; i <= m; i++)
    {
        fin >> task >> x >> y;
        if(task == 1 && Find(x) != Find(y))
            Union(Find(x), Find(y));
        else
        {
            if(Find(x) == Find(y))
                fout << "DA\n";
            else fout << "NU\n";
        }
    }
    return 0;
}
