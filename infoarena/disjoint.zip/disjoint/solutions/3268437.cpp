#include<bits/stdc++.h>

using namespace std;

const int NMAX = 1e5 + 5;
int n, m, ans[NMAX], s, tata[NMAX], rang[NMAX];

int find_tata(int x)
{
    while(x != tata[x])
        x = tata[x];
    return x;
}

void unite(int a, int b)
{
    int atata = find_tata(a), btata = find_tata(b);
    if(rang[a] < rang[b])
    {
        rang[b] = rang[a] + 1;
        tata[a] = b;
    }
    else
    {
        rang[a] = rang[b] + 1;
        tata[b] = a;
    }
}

void check(int a, int b)
{
    int atata = find_tata(a), btata = find_tata(b);
    if(atata == btata)
        cout << "DA\n";
    else
        cout << "NU\n";
}

int main()
{
    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);
    
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
	{
	    tata[i] = i;
	    rang[i] = 1;
	}
	
	int c, a, b;
	for(int i = 1; i <= m; i++)
	{
	    cin >> c >> a >> b;
	    if(c == 1)
	        unite(a, b);
	    else
	        check(a, b);
	}
}