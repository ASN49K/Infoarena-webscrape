#include <bits/stdc++.h>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int man[100002];

int caut(int u)
{
    if(man[u]==u)
    {
        return u;
    }
    return man[u]=caut(man[u]);
}
void unite(int x,int y)
{
    x=caut(x);
    y=caut(y);
    if(x!=y)
    {
        man[x]=y;
    }
    return;
}
int main()
{
    int n, m, k, a, b;
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        man[i]=i;
    }
    for(int i=0;i<m;i++)
    {
        f>>k>>a>>b;
        if(k==1)
        {
            unite(a, b);
        }
        else
        {
            if(caut(a)==caut(b))
            {
                g<<"DA"<<endl;
            }
            else
            {
                g<<"NU"<<endl;
            }
        }
    }
    return 0;
}
