#include<bits/stdc++.h>
using namespace std;
struct dsu{
vector<int> p,sz;
dsu(int n)
{
    p.resize(n+1);
    sz.resize(n+1);
    for(int i=1;i<=n;i++)
    {
        p[i]=i;
        sz[i]=1;
    }
}

int find_parent(int nod) //reprezentantul lui nod
{
    if(p[nod]==nod)
        return nod;
    return p[nod]=find_parent(p[nod]);
}

int unite(int x, int y)
{
    x=find_parent(x);
     y=find_parent(y);
     if(x==y)
     {
         return 0;
     }
     if(sz[x]>sz[y])
     {
         swap(x,y);
     }
     p[x]=y;
     sz[y]+=sz[x];
}
};
int main()
{
   int n,m,i;
   cin>>n>>m;
   dsu tree(n);
for(i=1;i<=m;i++)
{
    int tip;
    int u,v;
    cin>>tip>>u>>v;
    if(tip==1)
    {
        tree.unite(u,v);
    }
    else if(tip==2)
    {
        u=tree.find_parent(u);
     v=tree.find_parent(v);
     if(u==v)
        cout<<"DA"<<endl;
     else
        cout<<"NU"<<endl;
    }

}

    return 0;
}

