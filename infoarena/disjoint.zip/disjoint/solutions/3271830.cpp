#include <bits/stdc++.h>

using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int n,m,t[100001],h[100001],o,x,y,a,i,r1,r2,c, aux;
int rad(int x){

    int r=x;
    while(t[r]!=r)
        r=t[r];
        while(x!=r){
            aux=t[x];
            t[x]=r;
            x=aux;
        }
    return r;
}
void unif(int r1, int r2){
    if(h[r1]<h[r2]) t[r1]=r2;
            else t[r2]=r1;
            if(h[r1]== h[r2]) h[r1]++;
}
int main()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        t[i]=i;
        h[i]=1;
    }
    for(int i=1;i<=m;i++)
    {
        f>>o>>x>>y;
        r1=rad(x);
        r2=rad(y);
        if(o== 1)
        {
            unif(r1, r2);

        }
        else{
            if(r1==r2)
                g<<"DA"<<endl;
            else g<<"NU"<<endl;
        }
    }

    return 0;
}
