#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 1e5 + 5;

int n, q;
int dad[NMAX];
int sz[NMAX];

int get_dad(int node) {
  if (node == dad[node])
    return node;
  return dad[node] = get_dad(dad[node]);
}

void unite(int x, int y) {
  if (sz[x] < sz[y])
    swap(x, y);
  dad[y] = x;
  sz[x] += sz[y];
  sz[y] = 0;
}

void solve() {
  fin >> n >> q;
  for (int i = 1; i <= n; i++) {
    dad[i] = i;
    sz[i] = 1;
  }
  while (q--) {
    int tip, x, y;
    fin >> tip >> x >> y;
    if (tip == 1)
      unite(x, y);
    else fout << (get_dad(x) == get_dad(y) ? "DA\n" : "NU\n");
  }
}

int main() {
  ios_base :: sync_with_stdio(false);
  cin.tie(nullptr);
  solve();
  return 0;
}
