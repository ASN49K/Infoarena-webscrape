#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int N, M;
struct DSU{
    int n;
    vector <int> parent;
    vector <int> size;
    DSU(int n): n(n), parent(n){
        parent.resize(n + 1);
        size.resize(n + 1, 1);
        for(int i = 0; i < n; i ++){
            parent[i] = i;
        }
    }
    int find(int x){
        if(parent[x] == x) 
            return x;
        return parent[x] = find(parent[x]);
    }
    void unite(int x, int y){
        x = find(x), y = find(y);
        if(x == y) 
            return;
        if(size[x] < size[y])
            swap(x, y);
        size[x] += size[y];
        parent[x] = y;
    }
    bool same(int x, int y){
        return find(x) == find(y);
    }
};

int main(){
    
    fin >> N >> M;
    DSU dsu(N);
    for(int i = 1; i <= M; i ++){
        int Q, a, b;
        fin >> Q >> a >> b;
        
        if(Q == 1){
            dsu.unite(a, b);
        }
        else{
            fout << (dsu.same(a, b) ? "DA" : "NU") << "\n"; 
        }
                
    }

    fin.close();
    fout.close();    
    return 0;
}