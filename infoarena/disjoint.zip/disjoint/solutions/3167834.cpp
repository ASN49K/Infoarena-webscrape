#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int nmax=100000;
int n,m,t[nmax+5],r[nmax+5];
void unite(int x,int y)
{
    if(r[x]<r[y]) 
        t[x]=y;
    if(r[y]<r[x])
        t[y]=x;

   if(r[x]==r[y])
   {
       t[y]=x;
       r[x]++;
   }
}
int root(int x)
{
    while(t[x])
    x=t[x];
    return x;
}
void verif(int x,int y)
{
    if(root(x)==root(y)) fout<<"DA \n";
    else fout<<"NU \n";
}

void citire()
{
    int i,x,y;
    while(m--)
    {
        fin>>i>>x>>y;
        if(i==1) unite(x,y);
        else verif(x,y);
    }
}
int main()
{
    for(int i=1;i<=n;i++)
        {
            r[i]=1;
            t[i]=i;
            
        }
  
    fin>>n>>m;
    citire();
    
    return 0;
}