#include "bits/stdc++.h"
const int SIZE = 100000;
struct DSU{
    int root[SIZE + 5], size[SIZE + 5];
    DSU(int n){
        for(int i = 1; i <= n; i++){
            root[i] = i;
            size[i] = 1;
        }
    }
    int Find(int n){
        if(root[n] != n){
            root[n] = Find(root[n]);
        }
        return root[n];
    }
    void Unite(int a, int b){
        int rootA = Find(a);
        int rootB = Find(b);
        if(size[rootA] < size[rootB]){
            std :: swap(rootA, rootB);
        }
        root[rootB] = rootA;
        size[rootB] += size[rootA];
    }
};

void Solve(){
    int n, q;
    std :: cin >> n >> q;
    DSU dsu(n);
    while(q -- ){
        int op, x, y;
        std :: cin >> op >> x >> y;
        if(op == 1){
            dsu.Unite(x, y);
        }else{
            if(dsu.Find(x) == dsu.Find(y)){
                std :: cout << "DA" << '\n';
            }else{
                std :: cout << "NU" << '\n';
            }
        }
    }
}
signed main(){
    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);
    std :: ios_base :: sync_with_stdio(false);
    std :: cin.tie(0);
    Solve();
    return 0;
}
