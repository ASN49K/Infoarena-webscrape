#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,m,parent[100005],card[100005];
int Find(int x)
{
    if(x==parent[x])
        return x;
    return parent[x]=Find(parent[x]);
}
void Union(int a,int b)
{
    a=Find(a);
    b=Find(b);
    if(a==b)
        return;
    if(card[b]>card[a])
        swap(card[b],card[a]);
    parent[b]=a;
    card[b]+=card[a];
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        parent[i]=i,card[i]=1;
    for(int i=1;i<=m;i++)
    {
        int op,x,y;
        cin>>op>>x>>y;
        if(op==1)
            Union(x,y);
        else
        {
            if(Find(x)!=Find(y))
                cout<<"NU\n";
            else
                cout<<"DA\n";
        }
    }
    return 0;
}
