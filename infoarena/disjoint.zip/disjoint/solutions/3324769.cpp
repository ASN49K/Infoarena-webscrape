#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n,m,o,a,b;
vector<int>t;

int root(int x){
    if(x==t[x]) return x;
    return (t[x]=root(t[x]));
}

int main(){
    fin>>n>>m;
    t.resize(n+1);
    for(int i=1;i<=n;i++)t[i]=i;
    for(int i=0;i<m;i++){
        fin>>o>>a>>b;
        int ra=root(a),rb=root(b);
        if(o==1) t[ra]=rb;
        else{
            if(ra==rb) fout<<"DA\n";
            else fout<<"NU\n";
        }
    }
    return 0;
}
