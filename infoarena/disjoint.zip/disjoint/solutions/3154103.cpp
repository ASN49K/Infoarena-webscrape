#include <fstream>
#include <vector>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");



int n;
struct DSU

{

    vector<int>parent, sizes;
    void init ()
    {
        int i;
        parent.resize (n+2);
        sizes. resize (n+2);
        for (i=1; i <=n; i++)
        {
            parent [i] = i;
            sizes [i] = 1;
        }

    }
    int findd (int u)
    {
        if (u== parent [u])
            return u;

        return parent [u]= findd (parent [u]);
    }
    void unite ( int u, int v)
    {
        u= findd (u);
        v=findd (v);
        if ( u == v)
            return;
        if (sizes[v] > sizes [u])
            swap (u,v);
        parent [v]=u;
        sizes [u]+= sizes [v];
    }

}dsu;

int main()
{
    int m, i, x,t, y;
    cin >>n >> m;
    dsu.init();
    for (i= 1; i <= m; i++)
    {
        {
            cin >> t>> x>> y;
            if (t==1)
                dsu.unite(x,y);
            else
            {
                if(dsu.findd(x) == dsu.findd(y))
                cout << "DA";
                else
                    cout << "NU";
                cout << '\n';
            }
        }
    }

    return 0;
}
