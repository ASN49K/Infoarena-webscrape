#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m, t[100001], tip, x, y, s[100001];

int root(int x)
{
    while(t[x] != 0)
        x = t[x];
    return x;
}

void unite(int x, int y)
{
    int rx = root(x);
    int ry = root(y);
    if(rx != ry)
    {
        if(s[rx] == s[ry])
        {
            t[ry] = rx;
            s[rx]++;
        }
        else if(s[rx] > s[ry])
            t[ry] = rx;
        else t[rx] = ry;
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        fin >> tip >> x >> y;
        if(tip == 1)
        {
            unite(x, y);
        }
        else
        {
            if(root(x) == root(y))
                fout << "DA";
            else fout << "NU";
            fout << '\n';
        }
    }

    return 0;
}
