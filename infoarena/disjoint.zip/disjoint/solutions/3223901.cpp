#include <fstream>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

const int nmax = 100005;
int T[nmax], n, m;

int get_root(int node)
{
    int aux = node;
    while(T[node] > 0)
        node = T[node];

    int root = node;
    node = aux;
    while(node != root)
    {
        aux = T[node];
        T[node] = root;
        node = aux;
    }

    return root;
}

void Join(int x, int y)
{
    int rx = get_root(x);
    int ry = get_root(y);

    if(rx == ry)
        return;

    if(T[rx] <= T[ry]){
        T[rx] += T[ry];
        T[ry] = rx;
    }

    else{
        T[ry] += T[rx];
        T[rx] = ry;
    }

}

int Query(int x, int y)
{
    return get_root(x) == get_root(y);
}

int main()
{
    f >> n >> m;
    for(int i = 1; i <= n; i ++)
        T[i] = -1;

    for(int i = 1; i <= m; i ++)
    {
        int op, x, y;
        f >> op >> x >> y;
        if(op == 1)
            Join(x, y);
        else
            g << (Query(x, y) == 1 ? "DA" : "NU") << '\n';
    }
    return 0;
}
