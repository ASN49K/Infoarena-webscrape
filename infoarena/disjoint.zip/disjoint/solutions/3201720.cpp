#include <vector>
#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
vector<int>T,rang;
int N,M;

int radacina(int x)
{
    if(T[x]==0)
        return x;
    return radacina(T[x]);
}

void unite(int a,int b)
{
    int x=radacina(a),y=radacina(b);
    if(x!=y)
    {
        if(rang[a]<rang[b])
        {
            T[a]=b;
        }
        else
        {
            if(rang[a]==rang[b])
                rang[a]++;
            T[a]=b;
        }
    }
}

int main()
{
    fin>>N>>M;
    T=rang=vector<int>(N+1,0);
    for(int i=0;i<M;i++)
    {
        int x,y,c;fin>>c>>x>>y;
        if(c==1)
        {
            unite(radacina(x),radacina(y));
        }
        else
        {
            if(radacina(x)==radacina(y))
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    return 0;
}
