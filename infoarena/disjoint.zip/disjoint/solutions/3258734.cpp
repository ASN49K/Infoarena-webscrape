#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

const int Nmax=1e5+1;

int n, m;

struct DSU{
    int rep[Nmax], sz[Nmax];

    /// constructor pentru DSU
    DSU(int n){
        for (int i=1; i<=n; i++){
            rep[i]=i;
            sz[i]=1;
        }
    }

    /// functie care ne da radacina arborelui nodului "nod"
    int get_rep(int nod){
        /// cu path compression
        if (nod==rep[nod])
            return nod;
        else{
            // cod lungut
            /*
            int rnod=get_rep(rep[nod]);
            rep[nod]=rnod;
            return rnod;
            */
            return rep[nod]=get_rep(rep[nod]);
        }
    }

    /// functie prin care verificam daca nodurile "a" si "b" sunt in aceasi componenta
    bool same_comp(int a, int b){
        int ra=get_rep(a);
        int rb=get_rep(b);

        if (ra==rb)
            return 1;
        else return 0;
    }

    /// functie care combina multimile nodurilor "a" si "b"
    void join (int a, int b){
        int ra=get_rep(a);
        int rb=get_rep(b);

        /// cu small to large

        /// bagam pe b in a
        if (sz[ra]>sz[rb]){
            rep[rb]=ra;
            sz[ra]+=sz[rb];
        }
        /// bagam pe a in b
        else{
            rep[ra]=rb;
            sz[rb]+=sz[ra];
        }
    }
};

int main()
{
    fin>>n>>m;
    DSU dsu(n);

    int t, a, b;
    for (int i=0; i<m; i++){
        fin>>t>>a>>b;
        if (t==1)
            dsu.join(a, b);
        else{
            if (dsu.same_comp(a, b))
                fout<<"DA\n";
            else fout<<"NU\n";
        }
    }

    return 0;
}
