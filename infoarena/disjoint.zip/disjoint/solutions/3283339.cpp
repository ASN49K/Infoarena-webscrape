#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("disjoint.in");
ofstream gout("disjoint.out");
int gasire(int k,vector<int>&parent)
{
    if(parent[k]==-1)return k;
    else return parent[k]=gasire(parent[k],parent);
}
void unire(int &i,int &j,vector<int>&parent)
{
    int a=gasire(i,parent),b=gasire(j,parent);
    if(a!=b)parent[b]=a;
}
int main()
{
    int n,m,i,j,c;
    fin>>n>>m;
    vector<int>parent(n+1,-1);
    while(m--)
    {
        fin>>c>>i>>j;
        if(c==1)unire(i,j,parent);
        else if(gasire(i,parent)==gasire(j,parent))gout<<"DA\n";
        else gout<<"NU\n";
    }
    return 0;
}
