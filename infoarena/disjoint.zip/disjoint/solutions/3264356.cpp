

#include <iostream>
#include <fstream>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int tata[100001],adancime[100001];
int gasittata(int k)
{
    if(tata[k]!=k)
        tata[k]=gasittata(tata[k]);
    return tata[k];
}
void reuniune(int a,int b)
{
    if(adancime[a]>adancime[b])
    {
        tata[b]=a;
    }else{
        tata[a]=b;
        if(adancime[a]==adancime[b])
            adancime[b]+=1;
    }
}
int main() {
    int n,m,x,y,cod;
    f>>n>>m;
    for (int i = 1; i <= n; i++)
        {
            tata[i] = i;
            adancime[i] = 1;
        }
    for(int i=0;i<m;i++)
    {
        f>>cod>>x>>y;
        if(cod==1)
        {
            if(gasittata(x)!=gasittata(y))
                reuniune(tata[x],tata[y]);
        }else{
            if(gasittata(x)==gasittata(y))
                g<<"DA ";
            else
                g<<"NU ";
        }
        
    }
    return 0;
}
