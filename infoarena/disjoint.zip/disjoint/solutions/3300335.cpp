#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int parinte[100001], n, m;
int radacina(int nod);
void uneste(int x, int y);

int main()
{
    cin>>n>>m;
    for(int i = 1; i <= n; ++i)
        parinte[i] = i;
    for(int i = 1; i <= m; ++i)
    {
        int operatie, x, y;
        cin>>operatie>>x>>y;
        if(operatie == 1)
        {
            uneste(x, y);
        }
        else
        {
            if(radacina(x) == radacina(y))
                cout<<"DA\n";
            else
                cout<<"NU\n";
        }
    }
    return 0;
}

void uneste(int x, int y)
{
    int radx = radacina(x), rady = radacina(y);
    parinte[radx] = rady;
}

int radacina(int nod)
{
    int rad = nod;
    while(parinte[rad] != rad)
        rad = parinte[rad];

    while(parinte[nod] != rad)
    {
        int aux = nod;
        nod = parinte[nod];
        parinte[aux] = rad;
    }
    return rad;
}
