#include <fstream>
#include <vector>

using namespace std;

int radacina(int x, vector <int> &t)
{
    if (t[x] == 0)
    {
        return x;
    }
    return radacina(t[x], t);
}

bool verif(int x, int y, vector <int> &t)
{
    return (radacina(x, t) == radacina(y, t));
}

void reuniune(int x, int y, vector <int> &t, vector <int> &h)
{
    int rx = radacina(x, t);
    int ry = radacina(y, t);
    if (h[rx] < h[ry])
    {
        t[rx] = ry;
    }
    else
    {
        if (h[rx] == h[ry])
        {
            h[rx]++;
        }
        t[ry] = rx;
    }
}

int main()
{
    ifstream in("disjoint.in");
    ofstream out("disjoint.out");
    int n, nr_op;
    in >> n >> nr_op;
    vector <int> t(n + 1, 0);
    vector <int> h(n + 1, 0);
    for (int i = 0; i < nr_op; i++)
    {
        int tip, x, y;
        in >> tip >> x >> y;
        if (tip == 1)
        {
            reuniune(x, y, t, h);
        }
        else
        {
            if (verif(x, y, t))
            {
                out << "DA/n";
            }
            else
            {
                out << "NU/n";
            }
        }
    }
    in.close();
    out.close();
    return 0;
}
