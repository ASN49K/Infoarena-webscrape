#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int c,n,m,x,y,i,j,father[100001];
//root este gasit la tatal suprem si contorul nodurilor din arbore, cu semn negativ pt a fi distins de celelalte father-uri
int findroot(int n)
{
    if(father[n] < 0)
        return n; // inseamna ca el este father. Numai radacina e negativa

    int root = findroot(father[n]);
    //Ma asigur ca pe lantul ala i-am pus pe toti cu aelasi root
    //father[x] = root;

    return root;

}
void uniune(int x,int y)
{
    int r_x = findroot(x);
    int r_y = findroot(y);

   //Nici macar n-are rost sa fac cv, deja sunt in aceeasi comp conexa si au ac radacina
    if(r_x==r_y && (r_x!=-1 || r_y!=-1)) return;

    //Voi lipi arborele mic la cel mare, nu invers
    if(father[r_y]> father[r_x]) swap(r_x, r_y);

    //Il lipesc adc ii dau acelasi tata...
    father[r_x]+= father[r_y];
    father[r_y] = x;

}

int main()
{
    fin>>n>>m;

    for(i=1;i<=n;i++)
        father[i]= -1; //toate-s radacini a unei comp conexe de 1 elem la inceput

    while(m--)
    {
        fin>>c>>x>>y;
        if(c==1)
        {
            uniune(x,y);
        }
        else
        {
            if(findroot(x) == findroot(y))
                {
                    fout<<"DA\n";
                }
            else
            {
                fout<<"NU\n";
            }
        }

    }

    return 0;
}

