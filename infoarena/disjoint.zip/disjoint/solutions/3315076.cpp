#include <fstream>
#include <vector>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

vector<int> parent;
vector<int> sz;

int find_set(int node) {
    if (node == parent[node]) return node;
    parent[node] = find_set(parent[node]); // compresia drumurilor
    return parent[node];
}

void union_sets(int a, int b) {
    int leader_a = find_set(a);
    int leader_b = find_set(b);
    if (leader_a != leader_b) {
        if (sz[leader_a] < sz[leader_b]) {
            swap(leader_a, leader_b);
        } // now leader_a is always the bigger tree
        parent[leader_b] = leader_a;
        sz[leader_a] += sz[leader_b];
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    parent.resize(n + 2);
    sz.resize(n + 2);
    for (int i = 1 ; i <= n ; ++i) {
        parent[i] = i;
        sz[i] = 1;
    }
    for (int i = 1 ; i <= m ; ++i) {
        int cod, x, y;
        cin >> cod >> x >> y;
        if (cod == 1) union_sets(x, y);
        if (cod == 2) {
            bool ok = find_set(x) == find_set(y);
            cout << (ok ? "DA" : "NU") << "\n";
        }
    }
    return 0;
}