#include <iostream>
#include <fstream>

using namespace std;

ifstream in ("disjoint.in");
ofstream out ("disjoint.out");

#define MAX_N 100005

int parent[MAX_N];

int find_rep(int node)
{
    if(parent[node] == 0)
        return node;
    return find_rep(parent[node]);
}

int unite(int x, int y)
{
    parent[find_rep(x)] = find_rep(y);
}

int main()
{
    int n, m, x, y, c;
    in >> n >> m;
    for(int i = 0; i < m; ++i)
    {
        in >> c >> x >> y;
        if(c == 1)
        {
            unite(x, y);
        } else
        {
            if(find_rep(x) == find_rep(y))
            {
                out << "DA" << '\n';
            } else
            {
                out << "NU" << '\n';
            }
        }
    }
    return 0;
}
