#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int t[100002], n, m;
/**
t[i] = 0, daca i este nod radacina
       j, daca j este nodul precedent
         lui i in drumul de la i la rad
*/

/// ret. radacina c.c. din care
/// face parte nodul x - O(log* n)
/// O(log*n) -> O(1)
int FindRoot(int x)
{
    int y, rad = x;
    while (t[rad] != 0)
        rad = t[rad];

    /// comprimarea drumului
    while (x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}

/// Unifica doua componente conexe
/// care au ca radacini pe x si y - O(1)
void Union(int x, int y)
{
    t[y] = x;
}

int main()
{
    int i, x, y, op;
    fin >> n >> m;
    /// O(m x log*n)
    for (i = 1; i <= m; i++)
    {
        fin >> op >> x >> y;
        x = FindRoot(x);
        y = FindRoot(y);
        if (op == 1) Union(x, y);
        else
        {
            if (x == y) fout << "DA\n";
            else fout << "NU\n";
        }
    }
    return 0;
}
