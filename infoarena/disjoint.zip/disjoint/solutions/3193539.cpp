#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int MAX_SIZE = 100000;

void findNode(vector<int> graph[MAX_SIZE + 1], int startNode, int node, bool fr[MAX_SIZE + 1], bool &nodeFound) {
  //  if (graph[startNode].empty() == 0) {
        for (vector<int>::iterator it = graph[startNode].begin(); it < graph[startNode].end(); ++it) {
            if (fr[*it] == 0) {
                fr[*it] = 1;
                if (*it == node) {
                    nodeFound = 1;
                  //  return;
                }
                findNode(graph, *it, node, fr, nodeFound);
                if (nodeFound == 1) {
                 //   return;
                }
            }
        }
   // }
}

int main() {
    int noCrowd, noOperations;
    fin >> noCrowd >> noOperations;
    vector<int> graph[MAX_SIZE + 1];
    for (int i = 1; i <= noOperations; ++i) {
        int opType, startNode, endNode;
        fin >> opType >> startNode >> endNode;
        if (opType == 1) {
            graph[startNode].push_back(endNode);
            graph[endNode].push_back(startNode);
        } else {
            bool fr[MAX_SIZE + 1] = {0}, nodeFound = 0;
            fr[startNode] = 1;
            findNode(graph, startNode, endNode, fr, nodeFound);
            if (nodeFound == 1) {
                fout << "DA\n";
            } else {
                fout << "NU\n";
            }
        }
    }
    return 0;
}
/*

1) Cazul din problema:

4 3
1 4 1
2 4 2
2 4 1
=>
NU
DA

2) Cazul cand toate nodurile formeaza o singura multime:

3 5
1 1 2
1 1 3
2 1 2
2 1 3
2 3 2
=>
DA
DA
DA

3) Cazul cand nu exista nici o operatie de tip 1 si atunci pentru orice operatie de tip 2 raspunsul va fi "NU":

3 3
2 2 1
2 3 1
2 3 2
=>
NU
NU
NU

4) Cazul in care nu exista nici o operatie de tip 2:

2 1
1 1 2
=>
(nimic)

5) Cazul cand inainte de operatiile de tipul 2 avem numai 2 submultimi:

4 6
1 1 2
1 2 3
1 4 5
1 4 6
2 1 4
2 5 6
=>
NU
DA

*/
