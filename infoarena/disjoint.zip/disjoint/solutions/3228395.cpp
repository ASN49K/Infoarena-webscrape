#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax=1e5;

int root[nmax], sz[nmax];

int find_root(int x)
{
    if(root[x]==x)
        return x;
    return find_root(root[x]);
}

void reuneste(int r, int w)
{
    if(sz[r]<sz[w])
        swap(r,w);
    sz[r]+=sz[w];
    root[w]=r;
}

int main()
{
    int n, m;
    fin >> n >> m;
    for(int i=1; i<=n; i++)
    {
        root[i]=i;
        sz[i]=1;
    }
    int op, x, y;
    for(int i=1; i<=m; i++)
    {
        fin >> op >> x >> y;
        if(op==1)
            reuneste(find_root(x), find_root(y));
        else
        {
            if(find_root(x)==find_root(y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
