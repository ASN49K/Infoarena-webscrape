#include <bits/stdc++.h>
using namespace std;

ifstream fin("cartita.in");
ofstream fout("cartita.out");

int sz[100005];

void Union(int a, int b)
{
    if(sz[a] < sz[b])
        swap(a, b);
    sz[a] += sz[b];
    sz[b] = a;
}

int Find(int x)
{
    if(sz[x] < 0)
        return x;
    sz[x] = Find(sz[x]);
    return sz[x];
}

int main()
{
    int n, m, t, x, y, i, task;
    fin >> n >> m;
    for(i = 1; i <= n; i++)
        sz[i] = -1;
    for(i = 1; i <= m; i++)
    {
        fin >> task >> x >> y;
        if(task == 1 && Find(x) != Find(y))
            Union(Find(x), Find(y));
        else
        {
            if(Find(x) == Find(y))
                fout << "DA\n";
            else fout << "NU\n";
        }
    }
    return 0;
}
