#include <iostream>
#include <fstream>
#include <cstring>
#define NMax 1000005
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int t[NMax];
int h[NMax];
int n,m;

int rad(int nod)
{
    int cnod=nod;
    while(t[nod]!=0)
    {
        nod=t[nod];
    }
    while(t[cnod]!=0)
    {
        int aux=t[cnod];
        t[cnod]=nod;
        cnod=aux;
    }
    return nod;
}
void reuniune (int x,int y)
{
    t[y]=x;
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int cod,x,y;
        fin>>cod>>x>>y;
        if(cod==2)
        {
            if(rad(x)==rad(y))
                fout<<"DA"<<"\n";
            else
                fout<<"NU"<<"\n";
        }
        else if(cod==1)
        {
           reuniune(rad(x),rad(y));
        }
    }
    return 0;
}
