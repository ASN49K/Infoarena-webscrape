#include <iostream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

struct Paduri {
	vector<int> tata;

	Paduri(int n) {
		tata.resize(n + 1);
	}

	int rad(int x) {
		if (tata[x] == 0) {
			return x;
		} else {
			tata[x] = rad(tata[x]); 
			return tata[x];
		}
	}

	bool query(int a, int b) {
		return rad(a) == rad(b);
	}

	void join(int a, int b) {
		if (query(a, b)) { return; }
		b = rad(b);
		a = rad(a);
		tata[b] = a;
	}
};

int main() {
	int n, m; cin >> n >> m;
	Paduri disjoin(n);

	for (int i = 0; i < m; i++) {
		int t, x, y; cin >> t >> x >> y;
		if (t == 1) {
			disjoin.join(x, y);
		} else {
			cout << (disjoin.query(x, y) ? "DA\n" : "NU\n");
		}
	}

	return 0;
}