f = open("disjoint.in", "r")
n, m = f.readline().split()

def find(parent, x):
    if parent[x] != x:
        parent[x] = find(parent, parent[x])  # path compression
    return parent[x]


def union(parent, rank, x, y):
    root_x = find(parent, x)
    root_y = find(parent, y)

    if root_x == root_y:
        return

    if rank[root_x] < rank[root_y]:
        parent[root_x] = root_y
    elif rank[root_x] > rank[root_y]:
        parent[root_y] = root_x
    else:
        parent[root_y] = root_x
        rank[root_x] += 1


parent = [i for i in range(int(n) + 1)]
rank = [0] * (int(n) + 1)
print(parent, rank)
output_lines = []

for _ in range(int(m)):
    code, x, y = map(int, f.readline().split())

    if code == 1:
        union(parent, rank, x, y)
    elif code == 2:
        if find(parent, x) == find(parent, y):
            output_lines.append("DA")
        else:
            output_lines.append("NU")


fout = open("disjoint.out", "w")
fout.write("\n".join(output_lines))

