#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int NMAX=1e5;
vector<int> parent(NMAX+5), status(NMAX+5);
int find_set(int nod){
    if(nod==parent[nod]){
        return nod;
    }
    return parent[nod]=find_set(parent[nod]);
}
void union_set(int x, int y){
    int nod1=find_set(x);
    int nod2=find_set(y);
    if(nod1==nod2){
        return;
    }
    if(status[nod1]<status[nod2]){
        swap(nod1,nod2);
    }
    if(status[nod1]==status[nod2]){
        status[nod1]++;
    }
    parent[nod2]=nod1;
}
int main(){
    int n, m;
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        parent[i]=i;
    }
    for(int j=1;j<=m;j++){
        int tip, x, y;
        fin>>tip>>x>>y;
        if(tip==1){
            union_set(x,y);
        }else if(tip==2){
            if(find_set(x)==find_set(y)){
                fout<<"DA"<<'\n';
            }else{
                fout<<"NU"<<'\n';
            }
        }
    }

}
