#include <bits/stdc++.h>

using namespace std;

struct DSU {
    vector<int> p, h;
    DSU(int n) {
        p.resize(n + 1);
        h.resize(n + 1);
        for(int i = 1; i <= n; i++) {
            p[i] = i;
            h[i] = 1;
        }
    }
    int Find(int x) {
        int r = x;
        while(r != p[r]) {
            r = p[r];
        }
        int y = x;
        //compresia de drum
        while(y != r) {
            int t = p[y];
            p[y] = r;
            y = t;
        }
        return r;
    }
    void Union(int x, int y) {
        x = Find(x);
        y = Find(y);
        //reuniune dupa rang
        if(h[x] < h[y]) {
            p[x] = y;
        } else {
            if(h[x] > h[y]) {
                p[y] = x;
            } else {
                p[x] = y;
                h[y]++;
            }
        }
    }
};

int main() {
    ifstream f("disjoint.in");
    ofstream g("disjoint.out");
    int n, m;
    f >> n >> m;
    DSU d(n);
    for(int i = 1; i <= m; i++) {
        int op, x, y;
        f >> op >> x >> y;
        if(op == 1) {
            d.Union(x, y);
        } else {
            if(d.Find(x) == d.Find(y)) {
                g << "DA\n";
            } else {
                g << "NU\n";
            }
        }
    }
    return 0;
}
