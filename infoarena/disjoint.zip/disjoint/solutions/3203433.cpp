
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,q;
vector<int> T,R;
int t,a,b;
int find(int nod)
{
    if(T[nod]==nod)
       return nod;
    else
     {
         T[nod]=find(T[nod]);
         return T[nod];
     }
}
int main()
{
    cin>>n>>q;
    T.resize(n+1);
    R.resize(n+1);
    for(int i=1;i<=n;i++)
      T[i]=i;
    for(int i=0;i<q;i++)
    {
        cin>>t>>a>>b;
        if(t==1)
        {
            int ra=find(a);
            int rb=find(b);
            if(R[ra]>R[rb])
               T[rb]=ra;
            else
              {
                  T[ra]=rb;
                  if(R[rb]==R[ra])
                     R[rb]++;
              }
        }
        else
          {
            int ra=find(a);
            int rb=find(b);
            if(ra==rb)
              cout<<"DA";
            else
             cout<<"NU";
            cout<<'\n';
          }
    }
    return 0;
}
