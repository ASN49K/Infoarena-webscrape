#include <bits/stdc++.h>
using namespace std;
ifstream fin("politics.in");
ofstream fout("politics.out");
int par[1005], sz[1005], op;
unsigned long long s;
int n, m, a, b;
int getpar(int a)
{
    if(par[a] == 0)
    {
        par[a] = a;
        return a;
    }
    while(a!=par[a])
        a=par[a];
    return a;
}
void connect(int a,int b)
{
    a=getpar(a);
    b=getpar(b);
    if(a!=b)
    {
        if(sz[a]<sz[b])
            swap(a,b);
        par[b]=a;
        par[b]=a;
        sz[a]+=sz[b];
    }
}
int main()
{
    fin>>n>>m;
    for(int i = 1; i <= m; i++)
    {
        fin>>op>>a>>b;
        if(op == 1)
        {
            connect(a, b);
        }
        if(op == 2)
        {
            if(getpar(a) == getpar(b))
                fout<<"DA";
            else
                fout<<"NU";
            fout<<'\n';
        }
    }
    return 0;
}
