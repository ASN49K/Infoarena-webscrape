#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x << ": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "disjoint";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int n, m;
int t[100005];

void unionn(int x, int y)
{
    t[y] = x;
}
int find(int x)
{

    return (t[x] == x ? x : t[x] = find(t[x]));
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= n; ++i)
        t[i] = i;
    while (m--)
    {

        int op, x, y;
        fin >> op >> x >> y;
        if (op == 1)
            unionn(find(x), find(y));
        else if (op == 2)
            fout << (find(x) == find(y) ? "DA\n" : "NU\n");
    }
    return 0;
}