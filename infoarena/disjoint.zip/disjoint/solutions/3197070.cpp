#include <bits/stdc++.h>
using namespace std;
int n, m, T[100100];

int find(int t){
    if(T[t] == t){
        return T[t];
    }

    find(T[t]);
}

void unit(int a, int b){
    if(T[a] == a && T[b] == b){
        T[a] = T[b];
    } else if(T[b] == b){
        unit(T[a], b);
        T[a] = T[b];
    } else {
        unit(a, T[b]);
        T[b] = T[a];
    }
}

int main(){
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");
    cin >> n >> m;
    for(int i=1; i<=n; i++){
        T[i] = i;
    }

    int k, a, b;
    for(int i=1; i<=m; i++){
        cin >> k >> a >> b;
        if(k==1 && find(a) != find(b)){
            unit(a, b);
        } else {
            cout << (find(T[a]) == find(T[b]) ? "DA" : "NU") << endl;
        }
    }
}