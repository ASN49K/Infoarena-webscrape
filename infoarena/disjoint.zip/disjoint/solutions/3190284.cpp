#include <bits/stdc++.h>
#define N_MAX 100005

using namespace std;

ifstream fin("disjoint.in");

ofstream fout("disjoint.out");

int tati[N_MAX], nr[N_MAX];
int n, m;

int getroot(int x)
{
    while (tati[x] != 0)
        x = tati[x];
    return x;
}
void join(int x, int y)
{
    x=getroot(x);
    y=getroot(y);
    if (nr[x] < nr[y])
        swap(x, y);
    tati[y] = x;
}
int main()
{
    int op;
    fin >> n >> m;
    for (; m--;)
    {
        int x, y;
        fin >> op >> x >> y;
        if (op == 1)
            join(x, y);
        else
        {
            if (getroot(x) == getroot(y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
}