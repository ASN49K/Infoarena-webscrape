#include <fstream>
#define NMAX 1000001

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int tata[NMAX];
int h[NMAX];//h[i] e h arborelui cu rad i

void unionn(int x, int y);
int findd(int x);
int Find(int x);

int main()
{
    int n,m,c,x,y;
    int i;
    fin>>n>>m;
    for (i=1; i<=n; i++)
        tata[i]=i;
    for(i=1; i<=m; i++)
    {
        fin>>c>>x>>y;
        int r1=findd(x);
        int r2=findd(y);
        if(c==1)
            unionn(r1,r2);
        else
        {
            if(r1==r2) fout<<"DA"<<'\n';
            else fout<<"NU"<<'\n';
        }
    }
    return 0;
}

void unionn( int x, int y)
{
    if(h[x]<h[y])
        tata[x]=y;
    else if(h[x]>h[y])
        tata[y]=x;
    else
        tata[y]=x;
        h[x]++;

}
int findd(int x)
{
    int r,y;
    //mai intai aflu rad arborelui din care face parte x
    r=x;
    while(tata[r]!=r) r=tata[r];
    //parcurg din nou drumul de la x la r si fac toate nod fii a lui r
    do
    {
        y=tata[x];
        tata[x]=r;
        x=y;
    }
    while(tata[x]!=r);
    return r;
}
int Find(int x)
{
    if (tata[x] == 0) return x;
    tata[x]=Find(tata[x]);
    return tata[x];
}
