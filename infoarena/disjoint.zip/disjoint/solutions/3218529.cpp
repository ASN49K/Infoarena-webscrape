#include <fstream>
#define NMAX 1000000
using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,tata[NMAX];
void Union(int x,int y);
int Find(int x);
int h[NMAX];
int main()
{
    cin>>n;
    ///fac niste union si find si afisez

    return 0;
}
void Union(int x, int y)
{
    if(h[x]<h[y])
        tata[x]=y;
    else if(h[y]<h[x])
        tata[y]=x;
    else
        ///h sunt egale
        {tata[y]=x;h[y]++;}
}
int Find(int x)
{
    int r,y;
    ///Mai intai aflu radacina din care face parte x
    r=x;
    while(tata[r]) r=tata[r];
    ///parcurg din nou drumul de la x la r si fac toate nodurile fii lui r
    do
    {
        y=tata[x];
        tata[x]=r;
        x=y;
    }while(tata[x]!=r);
}
