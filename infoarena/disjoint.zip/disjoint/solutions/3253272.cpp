#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

/**
Alg. Union-Find
t[i] = 0, daca i este nod radacina
t[i] = j: j este nodul precedent din drumul de la i la radacina
*/
int t[100002], n, m;

/// unifica radacinile x si y intr-o singura comp conexa
void Union(int x, int y)
{
    t[y] = x;
}

/// afla radacina c.c. din care face parte nodul x
int Find(int x)
{
    int rad , y;
    rad = x;
    while (t[rad] != 0)
        rad = t[rad];
    /// comprimarea drumului
    while(x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}

int main()
{
    int i, x, y, op;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        fin >> op >> x >> y;
        x = Find(x);
        y = Find(y);
        if (op == 1)
        {
            if (x != y) Union(x, y);
        }
        else
        {
            if (x == y) fout << "DA\n";
            else fout << "NU\n";
        }
    }
    return 0;
}
