#include <fstream>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int t[100001];
void Union(int x,int y)
{
    t[y]=x;
}
int Find(int x)
{int rad,y;
    rad=x;
    while(t[rad]!=0)rad=t[rad];
    //comprimam
    while(x!=rad)
    {
        y=t[x];
        t[x]=rad;
        x=y;
    }
    return rad;
}
int main()
{
    int n,m,Q,op,i,x,y;
    f>>n>>Q;
    for(i=1;i<=Q;i++)
    {
        f>>op>>x>>y;
        x=Find(x);
        y=Find(y);
        if(op==1)
        {

            if(x!=y)Union(x,y);
        }
        else if(x==y)g<<"DA"<<'\n';
                    else g<<"NU"<<'\n';
    }
    f.close();
    g.close();
    return 0;
}
