//#include <iostream>
#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");


const int N = 1e5;
int n, m;
int t[N+1], rang[N+1];
// t[rad] = rad


int find(int x)
{
    if (t[x] == x)
        return x;
    t[x] = find(t[x]);
    return t[x];
}

void unite(int x, int y)
{
    int rx = find(x), ry = find(y);
    if (rang[rx] >= rang[ry])
        t[ry] = rx;
    else
        t[rx] = ry;
    
    if (rang[rx] == rang[ry])
        rang[rx]++;
}


int main()
{
    cin >> n >> m;

    for (int i = 1; i <= n; i++)
    {
        t[i] = i;
        rang[i] = 1;
    }

    for (int i = 1; i <= m; i++)
    {
        int cod, x, y;
        cin >> cod >> x >> y;

        if (cod == 1)
            unite(x, y);
        else
        {
            int rx = find(x), ry = find(y);
            if (rx == ry)
                cout << "DA\n";
            else
                cout << "NU\n";
        }
    }

    return 0;
}