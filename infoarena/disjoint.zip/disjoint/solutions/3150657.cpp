#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct DSU
{
    vector<int>father, sz;

    DSU(int n)
    {
        father.resize(n + 1);
        sz.resize(n + 1);

        for(int i = 1; i <= n; ++ i)
        {
            father[i] = i;
            sz[i] = 1;
        }
    }

    int FindFather(int x)
    {
        if(father[x] == x)
            return x;
        return father[x] = FindFather(father[x]);
    }

    void Join(int x, int y)
    {
        int father_x = FindFather(x);
        int father_y = FindFather(y);

        if(sz[father_x] > sz[father_y])
            swap(father_x, father_y);

        father[father_x] = father_y;
        sz[father_y] += sz[father_x];
    }

    bool SameSet(int x, int y)
    {
        return FindFather(x) == FindFather(y);
    }
};

const int NMAX = 1e5+5;
int n, m;
DSU pdm(NMAX);

int main()
{
    ios::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    fin >> n >> m;

    while(m--)
    {
        int op, x, y;

        fin >> op >> x >> y;

        if(op == 1)
        {
            pdm.Join(x, y);
        }
        else
        {
            if(pdm.SameSet(x, y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
