#include <fstream>

using namespace std;

int t[100001];
int r[100001];
int z;

int radacina(int k)
{
    if(t[k] == 0)
    {
        return k;
    }
    else
    {
        z = radacina(t[k]);
        t[k] = z;
        return z;
    }
}

void unire(int p, int u)
{
    int rp = radacina(p);
    int ru = radacina(u);

    if(r[rp] > r[ru])
    {
        t[ru] = rp;
        r[rp] += r[ru];
    }
    else if(r[rp] <= r[ru])
    {
        t[rp] = ru;
        r[ru] += r[rp];
    }
}

int main()
{
    ifstream f("disjoint.in");
    ofstream g("disjoint.out");
    int n, m;

    f>>n>>m;

    for(int i = 1; i<=n ;i++)
    {
        t[i] = 0;
        r[i] = 1;
    }

    int cod, x, y;
    for(int i = 1; i<=m; i++)
    {
        f>>cod>>x>>y;

        if(cod == 2)
        {
            if(radacina(x) == radacina(y))
            {
                g<<"DA"<<endl;
            }
            else
            {
                g<<"NU"<<endl;
            }
        }
        else if(cod == 1)
        {
            unire(x, y);
        }
    }
    return 0;
}
