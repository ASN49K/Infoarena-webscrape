#include <fstream>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int n,m,t[100005],x,y,ce,l[100005];
int radacina(int x)
{
    while(t[x]!=x)
        x=t[x];
    return x;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n; i++)
        t[i]=i,l[i]=1;
    for(int i=1; i<=m; i++)
    {
        cin>>ce>>x>>y;
        if(ce==1)
        {
            x=radacina(x);
            y=radacina(y);
            if(l[x]<=l[y])
            {
                t[x]=y;
                l[y]+=l[x];
            }
            else
            {
                t[y]=x;
                l[x]+=l[y];
            }
        }
        else
        {
            if(radacina(x)==radacina(y))
                cout<<"DA";
            else
                cout<<"NU";
            cout<<'\n';
        }
    }
    return 0;
}
