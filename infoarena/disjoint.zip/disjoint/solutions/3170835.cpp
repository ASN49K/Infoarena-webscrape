#include <bits/stdc++.h>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
const int NMAX=100005;
int n,m,op,x,y,status[NMAX],parent[NMAX];
int findRoot(int node)
{
    if(parent[node]==node)
        return node;
    return parent[node]=findRoot(parent[node]);
}
void unionSets(int node1,int node2)
{
    node1=findRoot(node1);
    node2=findRoot(node2);
    if(node1==node2)
        return;
    if(status[node1]<status[node2])
        swap(node1,node2);
    if(status[node1]==status[node2])
        status[node1]++;
    parent[node2]=node1;
}
int main()
{
    f>>n>>m;
    for(int i=1; i<=n; i++)
        parent[i]=i;
    for(int i=1;i<=m;i++)
    {
        f>>op>>x>>y;
        if(op==1)
            unionSets(x,y);
        else
        {
            if(findRoot(x)==findRoot(y))
                g<<"DA"<<'\n';
            else
                g<<"NU"<<'\n';
        }
    }
    return 0;
}
