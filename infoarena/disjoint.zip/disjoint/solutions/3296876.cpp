#include <bits/stdc++.h>

#define ll long long
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
ll supremus[100002],n,m,op,x,y,sz[100002];
ll fnd(ll x)
{
    if(supremus[x]!=x)
        supremus[x]=fnd(supremus[x]);
    return supremus[x];
}
void unite(int x , int y)
{
    if(sz[x]<sz[y])
    {
        swap(sz[x] , sz[y]);
    }
    sz[x]+=sz[y];
    supremus[y]=x;
}
int main()
{

    fin>>n>>m;
    for(ll i=1;i<=n;i++)
        {supremus[i]=i;
        sz[i]=1;}

    for(ll i=1;i<=m;i++)
    {
        fin>>op>>x>>y;
        if(op==1)
        {if(fnd(x)!=fnd(y))
            unite(fnd(x) , fnd(y));
        }
        if(op==2)if(fnd(x)==fnd(y))fout<<"DA"<<'\n';
                 else fout<<"NU"<<'\n';
    }
    return 0;
}
