#include <fstream>
#include <vector>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
struct padure{
	vector<int> tata;
	padure (int n){
		tata.resize(n+1);
	}
	int rad(int a){
		if(tata[a]==0){
			return a;
		}
		tata[a]=rad(tata[a]);
		return tata[a];
	}
	void r(int a,int b){
		a=rad(a);
		b=rad(b);
		tata[a]=b;
	}
	bool q(int a,int b){
		a=rad(a);
		b=rad(b);
		return rad(a)==rad(b);
	}
};
int main(){
	int n,m;
	fin>>n>>m;
	padure pad(n);
	while(m--){
		int  x,y,cod;
		fin>>cod>>x>>y;
		if(cod==1){
			pad.r(x,y);
		}
		else{
			if(pad.q(x,y)){
				fout<<"DA\n";
			}
			else{
				fout<<"NU\n";
			}
		}
	}
}
