#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m;
int tati[100005];

int tata(int nod)
{
    if (tati[nod] == 0)
    {
        return nod;
    }
    int aux = tata(tati[nod]);
    tati[nod] = aux;
    return aux;
}

void unire(int nod1, int nod2)
{
    int tata1 = tata(nod1);
    int tata2 = tata(nod2);
    tati[tata1] = tata2;
}

int main()
{
    fin >> n >> m;
    int x, y, z;
    for (int i = 0; i < m; i++)
    {
        fin >> x >> y >> z;
        if (x == 1)
        {
            unire(y, z);
        }
        else
        {
            int tata1 = tata(y);
            int tata2 = tata(z);
            if (tata1 == tata2)
            {
                fout << "DA\n";
            }
            else
            {
                fout << "NU\n";
            }
        }
    }
    return 0;
}
