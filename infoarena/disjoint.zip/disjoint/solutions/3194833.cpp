#include <iostream>
#include <fstream>

using namespace std;

const int NMAX = 100001;

int t[NMAX];

int get_root(int nod){
    int aux = nod;
    while(t[nod] > 0){
        nod = t[nod];
    }
    int root = nod;
    nod = aux;
    while(nod != root){
        aux = t[nod];
        t[nod] = root;
        nod = aux;
    }
    return root;
}

void join(int x, int y){
    int root_x = get_root(x);
    int root_y = get_root(y);
    if(root_x == root_y){
        return;
    }
    if(t[root_x] > t[root_y]){
        t[root_x] += t[root_y];
        t[root_y] = root_x;
    }else{
        t[root_y] +=t[root_x];
        t[root_x] = root_y;
    }
}

bool query(int x, int y){
    return get_root(x) == get_root(y);
}

int main()
{
    ifstream fin("disjoint.in");
    ofstream fout("disjoint.out");

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= n; i++){
        t[i] = -1;
    }

    for(int i = 0; i < m; i++){
        int cod, x, y;
        fin >> cod >> x >> y;
        if(cod == 1){
            join(x, y);
        }else{
            bool rez = query(x, y);
            if(rez)
                fout << "DA\n";
            else{
                fout << "NU\n";
            }
        }
    }

    fin.close();
    fout.close();
    return 0;
}
