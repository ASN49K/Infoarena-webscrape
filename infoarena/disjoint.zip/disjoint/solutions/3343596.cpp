#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 1e5 + 2;

int n, m, tata[NMAX], s[NMAX];

int root(int nod)
{
    int root = nod;
    while(tata[root] != root)
    {
        root = tata[root];
    }
    while(tata[nod] != root)
    {
        int temp = tata[nod];
        tata[nod] = root;
        nod = temp;
    }
    return root;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        tata[i] = i;
        s[i] = 1;
    }
    for(int i = 1; i <= m; i++)
    {
        int op, x, y;
        fin >> op >> x >> y;
        if(op == 1)
        {
            if(s[x] <= s[y])
            {
                tata[root(x)] = root(y);
                s[y] += s[x];
            }
            else{
                tata[root(y)] = root(x);
                s[x] += s[y];
            }
        }   
        else if(op == 2)
        {
            fout << (root(x) == root(y) ? "DA" : "NU") << "\n";
        }
    }
    return 0;
}