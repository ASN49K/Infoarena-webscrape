#include <bits/stdc++.h>
#define NN 100005
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout("disjoint.out");

int n, m, t[NN], h[NN];
int op, x, y;

int rad(int x)
{
    while(t[x] != x)
    {
        x = t[x];
    }
    return x;
}

void _union(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);

    if(rx == ry)
        return;

    if(h[rx] > h[ry])
        swap(rx, ry);
    t[rx] = ry;
    if(h[rx] == h[ry])
        h[ry]++;
}

void _find(int x, int y)
{
    if(rad(x) == rad(y))
        fout << "DA";
    else
        fout << "NU";
    fout << '\n';
}

int main()
{
    fin >> n >> m;
    for(int i = 1 ; i <= n ; i++)
        t[i] = i;
    for(int i = 1 ; i <= m ; i++)
    {
        fin >> op >> x >> y;
        if(op == 1)
            _union(x, y);
        else
            _find(x, y);

    }
    return 0;
}
