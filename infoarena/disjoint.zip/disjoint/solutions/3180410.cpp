#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int NMAX = 200001;
int n, m, dad[NMAX], rang[NMAX];

int FindSet(int k){
    if(dad[k] != k){
        int repr = FindSet(dad[k]);
        dad[k] = repr;
        return repr;
    }
    return k;
}

void DoUnion(int x, int y){
    if(rang[x] < rang[y]) dad[x] = y;
    else if(rang[x] > rang[y]) dad[y] = x;
    else dad[y] = x, rang[y]++;
}

int main(){
    fin >> n >> m;
    for(int i = 1; i <= n; i++) dad[i] = i, rang[i] = 1;
    for(int i = 1; i <= m; i++){
        int x, y, cod;
        fin >> cod >> x >> y;
        if(cod == 1){
            DoUnion(x, y);
        }
        else{
            if(FindSet(x) == FindSet(y)) fout << "DA" << '\n';
            else fout << "NU" << '\n';
        }
    }
    return 0;
}