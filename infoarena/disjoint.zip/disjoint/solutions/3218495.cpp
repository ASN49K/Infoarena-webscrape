#include <fstream>
#define NMAX 100002

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int T[NMAX], H[NMAX];

void Union(int x, int y)
{
    if(H[x] > H[y])
        T[y] = x;
    else
    {
        if(H[x] < H[y])
            T[x] = y;
        else
        {
            T[y] = x;
            H[x]++;
        }
    }
}

int Find(int x)
{
    if(T[x] == 0)
        return x;
    T[x] = Find(T[x]);
    return T[x];
}

int n, m;

int main(void)
{
    int i, operatie, x, y, rx, ry;
    fin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> operatie >> x >> y;
        rx = Find(x);
        ry = Find(y);
        if(operatie == 1)
            Union(rx, ry);
        else
        {
            if(rx == ry)
                fout << "DA" << '\n';
            else
                fout << "NU" << '\n';
        }
    }
    return 0;
}
