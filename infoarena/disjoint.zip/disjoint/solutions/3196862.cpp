#include <fstream>
#define NMAX 100000

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int p[NMAX+5], s[NMAX+5];

void make_set(int v)
{
    p[v]=v;
    s[v]=1;
}

int find_set(int v)
{
    if(p[v]==v)
        return v;
    return p[v]=find_set(p[v]);
}

void union_sets(int a, int b)
{
    a=find_set(a);
    b=find_set(b);
    if(a!=b)
    {
        if(s[a]<s[b])
            swap(a, b);
        p[b]=a;
        s[a]+=s[b];
    }
}

int main()
{
    int n, m, t, x, y;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        make_set(i);
    for(int i=1;i<=m;i++)
    {
        cin>>t>>x>>y;
        if(t==1)
            union_sets(x, y);
        else
            cout<<((find_set(x)==find_set(y))?"DA\n":"NU\n");
    }
    return 0;
}
