#include <bits/stdc++.h>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int MAX_SIZE = 1000;

void findNode(vector<int> graph[MAX_SIZE + 1], int startNode, int node, bool fr[MAX_SIZE + 1], bool &nodeFound) {
    for (vector<int>::iterator it = graph[startNode].begin(); it < graph[startNode].end(); ++it) {
        if (fr[*it] == 0) {
            fr[*it] = 1;
            if (*it == node) {
                nodeFound = 1;
                return;
            }
            findNode(graph, *it, node, fr, nodeFound);
            if (nodeFound == 1) {
                return;
            }
        }
    }
}

int main() {
    int noCrowd, noOperations;
    fin >> noCrowd >> noOperations;
    vector<int> graph[MAX_SIZE + 1];
    for (int i = 1; i <= noOperations; ++i) {
        int opType, startNode, endNode;
        fin >> opType >> startNode >> endNode;
        if (opType == 1) {
            graph[startNode].push_back(endNode);
            graph[endNode].push_back(startNode);
        } else {
            bool fr[MAX_SIZE + 1] = {0}, nodeFound = 0;
            fr[startNode] = 1;
            findNode(graph, startNode, endNode, fr, nodeFound);
            if (nodeFound == 1) {
                fout << "DA\n";
            } else {
                fout << "NU\n";
            }
        }
    }
    return 0;
}
