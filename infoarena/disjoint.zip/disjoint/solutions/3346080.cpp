#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");



const int maxS=100005;

int parent[maxS];

int find(int x)
{
    if(parent[x]==x)
        return x;
    return parent[x]=find(parent[x]);
}

void unite(int x, int y)
{
    int bossX=find(x);
    int bossY=find(y);
    if(bossX!=bossY)
    {
        parent[bossY]=bossX;
    }
}

int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=n;++i)
        parent[i]=i;
    for(int i=1;i<=m;++i)
    {
        int x,y,choice;
        fin>>choice>>x>>y;
        if(choice==1)
        {
            unite(x,y);
        }
        else if(choice==2)
        {
            if(find(parent[x])!=find(parent[y]))
                fout<<"NU"<<'\n';
            else
                fout<<"DA"<<'\n';
        }
    }


}