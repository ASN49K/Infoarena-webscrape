#include <bits/stdc++.h>

using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int NMAX = 100001;
int daddy[NMAX], depth[NMAX];
int find_daddy( int node ){
    if( node == daddy[node] )
        return node;
    return daddy[node] = find_daddy(daddy[node]);
}
void unire( int node1, int node2 ){
    node1 = find_daddy( node1 );
    node2 = find_daddy( node2 );
    if( depth[node1] > depth[node2] )
        daddy[node2] = node1;
    else if(depth[node1] < depth[node2])
        daddy[node1] = node2;
    else{
        daddy[node2] = node1;
        depth[node1]++;
    }
}
int main()
{

    int n, m;
    in >> n >> m;
    for( int i = 1; i <= n; i++ ){
        daddy[i] = i;
        depth[i] = 1;
    }
    for( int i = 0; i < m; i++ ){
        int cer, a, b;
        in >> cer >> a >> b;
        if( cer == 2 ){
            int x = find_daddy(a);
            int y = find_daddy(b);
            if( x == y )
                out << "DA\n";
            else
                out << "NU\n";
        }
        else
            unire(a, b);
    }
    return 0;
}
