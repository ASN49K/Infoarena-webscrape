#include <bits/stdc++.h>

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

using namespace std;

struct DSU
{
    vector<int>father;
    vector<int>size;

    DSU(int n)
    {
        father.resize(n + 1);
        size.resize(n + 1);
        
        for(int i = 1; i <= n; ++ i)
        {
            father[i] = i;
            size[i] = 1;
        }
    }

    int get_father(int x)
    {
        if(x == father[x])
            return x;
        
        int tata_unu = get_father(father[x]);
        father[x] = tata_unu;

        return tata_unu;
    }

    void Join(int x, int y)
    {
        int tata_x = get_father(x);
        int tata_y = get_father(y);
        
        if(tata_x == tata_y)
            return;
        
        if(size[tata_x] > size[tata_y])
            swap(tata_x, tata_y);
        
        father[tata_x] = tata_y;
        size[tata_y] += size[tata_x];

        return;
    }

    bool SameSet(int x, int y)
    {
        return get_father(x) == get_father(y);
    }
};

const int NMAX = 1e5+5;
int n, m;
DSU dsu(NMAX);

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    fin >> n >> m;

    while(m--)
    {
        int x, y, op;
        fin >> op >> x >> y;

        if(op == 1)
        {
            dsu.Join(x, y);
        }
        else
        {
            if(dsu.SameSet(x,y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
}