#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, q, tata[100010], rang[100010];

inline int findTata(int nod) {
    while(tata[nod] != nod) nod = tata[nod];
    return nod;
}

inline void unireNoduri(int x, int y) {
    if(rang[x] < rang[y]) tata[x] = y;
    else if(rang[y] < rang[x]) tata[y] = x;
    else tata[x] = y, rang[y]++;
}

signed main()
{
    fin >> n >> q;
    for(int i=1; i<=n; i++) tata[i] = i, rang[i] = 1;
    while(q--) {
        int tip; fin >> tip;
        if(tip == 1) {
            int x, y; fin >> x >> y;
            unireNoduri(x, y);
        }
        else {
            int x, y; fin >> x >> y;
            if(findTata(x) == findTata(y)) fout << "DA\n";
            else fout << "NU\n";
        }
    }

    return 0;
}
