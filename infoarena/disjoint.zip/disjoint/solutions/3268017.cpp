#include <bits/stdc++.h>

using namespace std;

ifstream f ("disjoint.in");
ofstream g ("disjoint.out");

const int NMAX = 1e5;

int tata[NMAX+1], n;

int sef(int x){
    
    if(x == tata[x])
        return x;
        
    return tata[x] = sef(tata[x]);
    
}

void uneste(int x, int y){
    
    tata[sef(x)] = sef(y);
    
}

int main()
{
    
    int q;
    f >> n >> q;
    
    for(int i=1; i<=n; i++)
        tata[i] = i;
        
    for(int i=1; i<=q; i++){
        
        int t, x, y;
        f >> t >> x >> y;
        
        if(t == 1){
            
            uneste(x, y);
            
        }else{
            
            if(sef(x) == sef(y))
                g << "DA" << "\n";
                
            else g << "NU" << "\n";
            
        }
        
        
    }
    
    

    return 0;
}