#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in") ;
ofstream fout("disjoint.out");
const int NMAX=1e5+5 ;
int n,m,op,x,y,t[NMAX],rang[NMAX] ;
int radacina(int x)
{
    if(t[x]==x) return x ;
    else return radacina(t[x]) ;
}
void reuniune(int x,int y)
{
    t[x]=y ;
}
int main()
{
    fin>>n>>m ;
    for(int i=1; i<=n; ++i)  t[i]=i,rang[i]=1 ;
    for(int i=1; i<=m; ++i)
    {
        fin>>op>>x>>y ;
        if(op==1) reuniune(x,y) ;
        else
        {
            if(radacina(x)==radacina(y)) fout<<"DA\n" ;
            else fout<<"NU\n" ;
        }
    }
    return 0 ;
}
