#include <fstream>
#include <vector>
using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

struct DSU
{
    // t[i] = j => daca nodul i este în subarborele lui j,
    // t[i] = -size[i] = daca i este radacina
    vector<int> parent;

    DSU(int n)
    {
        parent.resize(n);
        for (int i = 1; i <= n; i++)
            parent[i] = -1;
    }

    int find(int a)
    {
        while (parent[a] > 0)
            a = parent[a];
        return a;
    }

    void unite(int a, int b)
    {
        a = find(a);
        b = find(b);
        if (a == b)
            return;

        if (parent[a] <= parent[b]) // -a <= -b => a >= b
        {
            parent[a] += parent[b];
            parent[b] = a;
        }
        else
        {
            parent[b] += parent[a];
            parent[a] = b;
        }
    }

    bool query(int a, int b)
    {
        return find(a) == find(b);
    }
};

int main()
{
    int n, q;
    cin >> n >> q;
    DSU dsu(n);

    for (int i = 0; i < q; i++)
    {
        int op, a, b;
        cin >> op >> a >> b;
        if (op == 1 && !dsu.query(a, b))
            dsu.unite(a, b);
        else
            cout << (dsu.query(a, b) ? "DA" : "NU") << "\n";
    }
}
