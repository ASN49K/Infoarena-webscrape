#include <iostream>
#include <fstream>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoinnt.out");
const int Nmax=100001;
int t[Nmax],aux,v[Nmax],h[Nmax],n,m,p,x,y;
int radacina(int x)
{int y;
    y=x;
    while(h[y]!=y)
        y=t[y];
    return y;
}
int uniune(int x , int y)
{int r1 , r2;
  r1=radacina(x);
    r2=radacina(y);
    if(h[r1]>h[r2])
    {
        t[r2]=r1;
     while(y!=t[y])
     {
         aux=y;
         y=t[y];
         t[aux]=r1;
     }
    }
     else
     {
         t[r1]=r2;
         while(x!=t[x])
         {

             aux=x;
             x=t[x];
             t[aux]=r2;
         }
     }
     if(h[r1]==h[r2])
      h[r2]++ ;
    }
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;++i)
    {
        f>>p>>x>>y;
        if(p==1)
            uniune(x,y);
            else
            {
                if(radacina(x)==radacina(y))
                    g<<"DA"<<'\n';
                else
                    g<<"NU"<<'\n';
            }
    }
    return 0;
}
