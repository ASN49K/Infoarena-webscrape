#include <fstream>
#include <vector>
const int NMAX=100005;

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

vector<int> multimi[NMAX];
int from[NMAX];

void combine(int pin1,int pin2)
{
    for(auto i: multimi[pin2])
    {
        from[i]=pin1;
        multimi[pin1].push_back(i);
    }
    multimi[pin2].clear();
}

int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        multimi[i].push_back(i);
        from[i]=i;
    }
    while(m--)
    {
        int tip,x,y;
        cin>>tip>>x>>y;
        if(tip==1)
        {
            combine(from[x],from[y]);
        }
        else
        {
            if(from[x]==from[y]) cout<<"DA"<<endl;
            else cout<<"NU"<<endl;
        }
    }
    return 0;
}
