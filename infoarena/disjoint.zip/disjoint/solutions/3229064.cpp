#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <climits>
#include <stack>

using namespace std;

ifstream fin("a.in"); /// parc.in
ofstream fout("a.out");
queue <int> q;
int n, m, c, x, y, vt[100001], a, b;

int main()
{
    fin>>n>>m;
    for(int i = 1; i<=m; i++)
    {
        fin>>c>>x>>y;
        if(c == 1)
        {
            a = x;
            b = y;
            while(vt[a] != 0)
                a = vt[a];
            while(vt[b] != 0)
                b = vt[b];

            int a1 = x;
            int b1 = y;
            while(vt[a1] != 0)
            {
                int t = vt[a1];
                vt[a1] = a;
                a1 = t;
            }
            while(vt[b1] != 0)
            {
                int t = vt[b1];
                vt[b1] = b;
                b1 = t;
            }
            vt[b] = a;
        }
        else
        {
            a = x;
            b = y;
            while(vt[a] != 0)
                a = vt[a];
            while(vt[b] != 0)
                b = vt[b];

            int a1 = x;
            int b1 = y;
            while(vt[a1] != 0)
            {
                int t = vt[a1];
                vt[a1] = a;
                a1 = t;
            }
            while(vt[b1] != 0)
            {
                int t = vt[b1];
                vt[b1] = b;
                b1 = t;
            }

            if(a == b)
                fout<<"DA"<<endl;
            else fout<<"NU"<<endl;
        }
    }

}
