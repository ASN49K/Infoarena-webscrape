#include <iostream>
#include <fstream>

using namespace std;
const int NMAX = 100020;

int tatal[NMAX], lung_graf[NMAX];
int N, M;

int cherche(int x)
{
	int R, y;

	/// cautam tatal
	for (R = x; tatal[R] != R; R = tatal[R]);

	///pentru a fi mai rapid in viitor
	///ii lipim pe toti de tatal suprem
	while(tatal[x] != x)
	{
		y = tatal[x];
		tatal[x] = R; /// punem tatal pe pozitia buna
		x = y;        /// continuam in sus pe urmatorul fost nod in sus
		x = y;        /// continuam in sus pe urmatorul fost nod in sus
	}
	return R;
}

void unis(int x, int y)
{
	///graful mare devine si mai mare
	/// lipind un graf mai mic la unul mai mare lungimea nu se va modifica
	if (lung_graf[x] > lung_graf[y])
        tatal[y] = x;
    else
        tatal[x] = y;

	/// lipind un graf de adancime n la tatal unui graf de lung n se creaza un graf de adancime n+1

	if (lung_graf[x] == lung_graf[y]) lung_graf[y]++;/// y fiindca aici l am lipit
}

int main()
{
	ifstream f("disjoint.in");
	ofstream g("disjoint.out");
    f>>N>>M;
	int i, x, y, caz;
	///initial fiecare nod are ca tata pe el insusi iar rangul fiecarui arbore este 1
	for (i = 1; i <= N; i++)
	{
		tatal[i] = i;
		lung_graf[i] = 1;
	}

	for (i = 1; i <= M; i++)
	{
		f>>caz>>x>>y;

		if (caz == 2)/// trebuie sa fac o interogare
                    /// verificam tatal
			if (cherche(x) == cherche(y)) g<<"DA\n";
				else g<<"NU\n";
            ///trebuie sa unesc
        else unis(cherche(x), cherche(y));
	}

	return 0;
}
