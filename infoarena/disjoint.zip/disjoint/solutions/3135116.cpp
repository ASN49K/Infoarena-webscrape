/*
 * Lefter Sergiu - 01/06/2023
*/
#include <fstream>

using namespace std;

ifstream in("disjoint.int");
ofstream out("disjoint.out");

const int N = 1e5;

int n, m, t[N + 1], h[N + 1];

int radacina(int x) {
    if (t[x] == 0) {
        return x;
    }
    return radacina(t[x]);
}

void reuniune(int x, int y) {
    int rx = radacina(x);
    int ry = radacina(y);
    if (h[rx] < h[ry]) {
        t[rx] = ry;
    } else {
        t[ry] = rx;
        if (h[rx] == h[ry]) {
            h[rx]++;
        }
    }
}

bool interogare(int x, int y) {
    return (radacina(x) == radacina(y));
}

int main() {
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        int tip, x, y;
        in >> tip >> x >> y;
        if (tip == 1) {
            reuniune(x, y);
        } else {
            if (interogare(x, y)) {
                out << "DA" << '\n';
            } else {
                out << "NU" << '\n';
            }
        }
    }
    return 0;
}