#include <fstream>
#include <vector>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

struct DSU
{
    int N;
    vector<int> parent, sizes;
    void init(int n)
    {
        N=n;
        parent.resize(N+1);
        sizes.resize(N+1);
        for(int i=1; i<=N; i++)
        {
            parent[i]=i;
            sizes[i]=1;
        }
    }

    int Find(int u)
    {
        if(parent[u] == u)
        {
            return u;
        }
        return parent[u]=Find(parent[u]);
    }

    void unite(int u, int v)
    {
        u=Find(u);
        v=Find(v);
        if(u == v)
            return;
        if(sizes[u] < sizes[v])
            swap(u, v);
        parent[v]=u;
        sizes[v]+=sizes[u];
    }
};

int main()
{
    DSU dsu;
    int n, m;
    cin>>n>>m;
    dsu.init(n);
    for(int i=1; i<=m; i++)
    {
        int op, u, v;
        cin>>op>>u>>v;
        if(op == 1)
            dsu.unite(u, v);
        else
        {
            if(dsu.Find(u) == dsu.Find(v))
            {
                cout<<"DA\n";
            }
            else
            {
                cout<<"NU\n";
            }
        }
    }
    return 0;
}
