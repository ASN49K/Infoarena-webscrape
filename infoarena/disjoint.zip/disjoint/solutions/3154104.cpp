#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

int n;
unordered_map <int, int> sef, sizes;

void init();
int findsef(int a);
void unite(int a, int b);

int main()
{
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");

    int m, op, a, b;
    cin >> n >> m;
    init();
    for (int i=0; i<m; i++)
    {
        cin >> op >> a >> b;
        if(op == 1)
        {
            unite(a, b);
        }
        else
        {
            a = findsef(a);
            b = findsef(b);
            if(a == b) cout << "DA" << endl;
            else cout << "NU" << endl;

        }
    }
    return 0;
}


void init()
{
    for(int i=1; i<=n; i++)
    {
        sef[i] = i;
        sizes[i] = 1;
    }
}
int findsef(int a)
{
    if (a == sef[a])
    {
        return a;
    }
    return sef[a] = findsef(sef[a]);
}
void unite(int a, int b)
{
    a = findsef(a);
    b = findsef(b);
    if(a == b) return;
    if(sizes[b] > sizes[a]) swap(a, b);
    sef[b] = a;
    sizes[a] += sizes[b];
}
