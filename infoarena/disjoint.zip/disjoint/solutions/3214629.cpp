#pragma GCC optimize ("03", "Ofast", "unroll-loops")
#include <bits/stdc++.h>

using namespace std;

#define INFILE "disjoint.in"
#define OUTFILE "disjoint.out"

struct DSU {

private:
    int n;
    vector<int> parent, sz;

public:
    DSU() {}
    DSU(int _n) : n(_n) {
        sz.resize(n + 1, 1);
        parent.resize(n + 1);
        for(int node = 1; node <= n; ++node) parent[node] = node;
    }

    int findParent(int node) {
        if(parent[node] == node) return node;
        return findParent(parent[node]);
    }

    void uniteSets(int node1, int node2) {
        node1 = findParent(node1);
        node2 = findParent(node2);
        if(node1 == node2) return;
        if(sz[node1] < sz[node2]) swap(node1, node2);
        parent[node2] = node1;
        sz[node1] += sz[node2];
    }

};

void solve(){

    int nodes, queries;
    cin >> nodes >> queries;

    DSU dsu(nodes);

    for(int i = 0; i < queries; ++i){

        int task, node1, node2; cin >> task >> node1 >> node2;

        if(task == 1) dsu.uniteSets(node1, node2);
        else {
            cout << (dsu.findParent(node1) == dsu.findParent(node2) ? "DA" : "NU") << '\n';
        }

    }


}

int main(){
    ios_base::sync_with_stdio(false);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    cin.tie(0), cout.tie(0);
    solve();
    return 0;
}