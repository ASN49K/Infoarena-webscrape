#include <fstream>
#include <vector>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

#define VI vector<int>

VI sir, aib;
int N, M;

void update(int idx, int val) {
    for (int i = idx; i <= N; i += i & -i) {
        aib[i] += val;
    }
}

int sum(int idx) {
    int suma = 0;
    for (int i = idx; i >= 1; i -= i & -i) {
        suma += aib[i];
    }
    return suma;
}

int cautare(int sum) {
    int pow2 = N;
    for (int pos = 0; pow2 > 0; pow2 >>= 1) {
        if (sum >= aib[pos + pow2]) {
            pos += pow2;
            sum -= aib[pos];
            if (sum <= 0) {
                return pos;
            }
        }
    }
    return -1;
}

int main() {
    fin >> N >> M;
    sir = aib = VI(N + 1, 0);
    for (int i = 1; i <= N; ++i) {
        fin >> sir[i];
        update(i, sir[i]);
    }

    for (int i = 0; i < M; ++i) {
        int op;
        fin >> op;
        if (op < 2) {
            int idx, val;
            fin >> idx >> val;
            if (op == 0) {
                update(idx, val);
            } else {
                fout << sum(val) - sum(idx - 1) << '\n';
            }
        } else {
            int val;
            fin >> val;
            fout << cautare(val) << '\n';
        }
    }
}