#include <bits/stdc++.h>

#define ll long long
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
ll supremus[100002],n,m,op,x,y;
int fnd(int x)
{
    if(supremus[x]!=x)
        supremus[x]=fnd(supremus[x]);
    return supremus[x];
}
int main()
{

    fin>>n>>m;
    for(int i=1;i<=n;i++)
        supremus[i]=i;
    for(int i=1;i<=m;i++)
    {
        fin>>op>>x>>y;
        if(op==1)supremus[x]=supremus[y];
        if(op==2)if( fnd(x)==fnd(y))fout<<"DA"<<'\n';
                 else fout<<"NU"<<'\n';
    }
    return 0;
}
