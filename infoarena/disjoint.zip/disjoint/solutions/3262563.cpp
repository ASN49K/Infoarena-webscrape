#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int NMAX=100000,MMAX=NMAX*(NMAX-1)/2;
int t[NMAX+5];
int h[NMAX+5];
struct muchie
{
    int u,v;
};
muchie mv[MMAX+5];
int findr(int u)
{
    while(t[u]!=u)
        u=t[u];
    return u;
}
bool unire(int u,int v)
{
    int ru,rv;
    ru=findr(u);
    rv=findr(v);
    if(ru!=rv)
    {
        if(h[ru]>h[rv])
            t[rv]=ru;
        else
            if(h[rv]>h[ru])
                t[ru]=rv;
            else
            {
                t[rv]=ru;
                h[ru]++;
            }
        return 1;
    }
    return 0;
}
int main()
{
    int n,m,i,c;
    fin>>n>>m;
    for(i=1;i<=n;i++)
        t[i]=i;
    for(i=1;i<=m;i++)
    {
        fin>>c>>mv[i].u>>mv[i].v;
        if(c==2)
        {
            if(findr(mv[i].u)==findr(mv[i].v))
                fout<<"DA\n";
            else
                fout<<"NU\n";
        }
        else
            unire(mv[i].u,mv[i].v);
    }
    fin.close();
    fout.close();
    return 0;
}
