
#include <fstream>

std::ifstream in("disjoint.in");
std::ofstream out("disjoint.out");

unsigned parent_of[100001];
unsigned __size_of[100001];

unsigned root_of(unsigned node) {
    unsigned root = node;

    while(parent_of[root] != root) {
        root = parent_of[root];
    }

    unsigned aux;
    while(parent_of[node] != root) {
        aux = node;
        node = parent_of[node];
        parent_of[aux] = root;
    }

    return node;
}

inline unsigned* const size_of(unsigned const node) {
    return __size_of + root_of(node);
}

void merge(unsigned a, unsigned b) {
    unsigned *size_of_a = size_of(a), *size_of_b = size_of(b);

    if(size_of_a > size_of_b) {
        parent_of[root_of(b)] = root_of(a);
        return;
    }

    if(size_of_a < size_of_b) {
        parent_of[root_of(a)] = root_of(b);
        return;
    }

    parent_of[root_of(a)] = parent_of[b];
    *size_of_a += 1;
}

int main() {
    unsigned N, ops;
    in >> N >> ops;

    for(unsigned i = 0; i < N; i += 1) {
        parent_of[i] = i;
        __size_of[i] = 1;
    }

    unsigned type, a, b;
    for(unsigned op = 0; op < ops; op += 1) {
        in >> type >> a >> b;

        if (type == 1) {
            merge(a, b);
        }

        if(root_of(a) == root_of(b)) out << "DA\n";
        else out << "NU\n";
    }
}
