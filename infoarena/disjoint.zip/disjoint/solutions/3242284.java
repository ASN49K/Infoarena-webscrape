//package disjoint;

import java.io.*;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Main {
    static final String INPUT_FILE = "disjoint.in";
    static final String OUTPUT_FILE = "disjoint.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static void solve(TokenizedReader reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        int m = reader.nextInt();
        DisjointSets disjointSets = new DisjointSets(n);
        while (m-- > 0) {
            int op = reader.nextInt();
            int a = reader.nextInt();
            int b = reader.nextInt();
            if (op == 1) {
                disjointSets.union(a, b);
            } else if (op == 2) {
                boolean isDisjoint = disjointSets.query(a, b);
                writer.println(isDisjoint ? "NU" : "DA");
                writer.flush();
            }
        }
    }

    public static class DisjointSets {
        public int n;
        public int[] parent;
        public int[] rank;

        public DisjointSets(int n) {
            this.n = n;
            this.parent = new int[n + 1];
            for (int i = 1; i <= n; ++i) {
                parent[i] = i;
            }
            this.rank = new int[n + 1];
            Arrays.fill(rank, 1);
        }

        public boolean query(int a, int b) {
            int p0 = getParent(a);
            int p1 = getParent(b);
            return p0 != p1;
        }

        private int getParent(int a) {
            if (a != parent[a]) {
                parent[a] = getParent(parent[a]);  // Path compression
            }
            return parent[a];
        }

        public void union(int a, int b) {
            int rootA = getParent(a);
            int rootB = getParent(b);

            if (rootA != rootB) {
                // Union by rank
                if (rank[rootA] > rank[rootB]) {
                    parent[rootB] = rootA;  // Attach B's root under A's root
                } else if (rank[rootA] < rank[rootB]) {
                    parent[rootA] = rootB;  // Attach A's root under B's root
                } else {
                    parent[rootB] = rootA;  // Attach B's root under A's root
                    rank[rootA]++;  // Increase rank of new root
                }
            }
        }
    }
}