#include <fstream>
#include <climits>
#include <vector>
//#include <iostream>
#include <algorithm>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int n, m, x, y, tip;
int tt[100005];

int rad(int x) {
    int nod = x;
    while(nod != tt[nod]) {
        nod = tt[nod];
    }
    return nod;
}

void unire(int x, int y) {
    tt[y] = x;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++) {
        tt[i] = i;
    }

    for(int i = 1; i <= m; i ++) {
        cin >> tip >> x >> y;
        if(tip == 1) { // reunim multimile
            unire(rad(x), rad(y));
        } else { // sunt in aceeasi comp. conexa?
            if(rad(x) == rad(y))
                cout << "DA\n";
            else
                cout << "NU\n";
        }
    }

    return 0;
}