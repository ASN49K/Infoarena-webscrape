#include <fstream>
#include <map>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
map<int, int> sz;
map<int, int> root;
int find_root(int x){
    if (root[x] == x)
        return x;
    root[x] = find_root(root[x]);
    return root[x];
}
void join(int r1, int r2){
    if (sz[r1] < sz[r2]){
        swap(r1, r2);
    }
    root[r2] = r1;
    sz[r1] += sz[r2];
}
int main(){
    int n;
    fin >> n;
    for (int i = 1; i <= n; i++){
        int a, b, q;
        fin >> a >> b >> q;
        if (root.count(a) == 0){
            root[a] = a;
            sz[a] = 1;
        }
        if (root.count(b) == 0){
            root[b] = b;
            sz[b] = 1;
        }
        int root_1 = find_root(a);
        int root_2 = find_root(b);
        if (q == 1 && root_1 != root_2){
            join(root_1, root_2);
        } else if (q == 2){
            if (root_1 == root_2)
                fout << "DA" << '\n';
            else
                fout << "NU" << '\n';
        }
    }
    return 0;
}