#include <iostream>
#include <fstream>
using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

const int Nmax = 1e5 + 1;

int n,m;

struct DSU{
   int rep[Nmax], sz[Nmax];

   DSU(int n)
   {
       for(int i=1; i<=n; i++){
        rep[i]=i;
        sz[i]=1;
       }
   }

   int get_rep(int nod){
      if(nod==rep[nod])
       return nod;
      else{
        // int rnod=get_rep(rep[nod]);
        // rep[nod]=rnod;                     //merg ambele variante
        // return rnod;
        return rep[nod]=get_rep(rep[nod]);
      }
   }

   bool same_comp(int a, int b){
       int ra=get_rep(a);
       int rb=get_rep(b);

       if(ra==rb)return 1;
       else return 0;
   }

   void join(int a, int b){
       int ra=get_rep(a);
       int rb=get_rep(b);

       if(sz[ra]>sz[rb]){
         rep[rb]=ra;
         sz[ra]+=sz[rb];
       }

       else{
        rep[ra]=rb;
        sz[rb]+=sz[ra];
       }
   }
};

int main()
{ 
    f>>n>>m;
    DSU dsu(n);

    int t, a, b;
    for (int i=0; i<m; i++){
        f>>t>>a>>b;
        if (t==1)
            dsu.join(a, b);
        else{
            if (dsu.same_comp(a, b))
                g<<"DA\n";
            else g<<"NU\n";
        }
    }
    return 0;
}
