#include <fstream>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

int v[1000001];

int sef(int x)
{
    if(v[x] == x)
        return x;
    else
        return v[x] = sef(v[x]);
}

void legat(int x, int y)
{
    v[sef(y)]=sef(x);
}

int main()
{
    int n, m, x, y, tip;
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        v[i]=i;
    }
    for(int i=1; i<=m; i++)
    {
        cin>>tip>>x>>y;
        if(tip == 1)
        {
            legat(x, y);
        }
        else
        {
            if(sef(x) == sef(y))
            {
                cout<<"DA"<<"\n";
            }
            else
            {
                cout<<"NU"<<"\n";
            }
        }
    }
    return 0;
}
