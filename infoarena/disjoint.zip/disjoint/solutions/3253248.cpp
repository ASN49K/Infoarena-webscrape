#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int t[100005],n,m,root;
void Union(int x,int y)
{
    t[x]=y;
}
int Find(int x)
{
    int root=x;
    while(t[root]!=0)
        root=t[root];
    return root;
}
void Rez()
{
    int Q,x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>Q>>x>>y;
        x=Find(x);
        y=Find(y);
        if(Q==1)
        {

            if(x!=y)Union(x,y);
        }
        else
        {
            if(x==y)fout<<"DA\n";
            else fout<<"NU\n";
        }
    }

}
int main()
{
    Rez();
    return 0;
}
