#include<fstream>
#include<cmath>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax = 100005;
int n,m,tata[nmax];

int find(int nod){
    if(tata[nod] == nod)return nod;

    else {
    int x = find(tata[nod]);
    tata[nod] = x;
    return x;
    }

}

int main(){
    fin>>n>>m;
    for(int i = 1; i <= n; i++)tata[i] = i;
    for(int i = 1; i <= m; i++){
        int x,y,z;
        fin>>z>>x>>y;
        if(z == 1){
        int a = min(x,y), b = max(x,y);
        tata[b] = a;
        }
        else{
            int tx = find(x), ty = find(y);
            tata[x] = tx; tata[y] = ty;

            if(tx == ty)fout<<"DA\n";
            else fout<<"NU\n";
        }

    }
}
