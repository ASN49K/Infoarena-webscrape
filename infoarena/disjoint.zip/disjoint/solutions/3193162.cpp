

#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct query
{
    int cod, x, y;
};

const int NMAX = 100000;
int n, m, dad[NMAX], rang[NMAX];
query q[NMAX];

void read() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> q[i].cod >> q[i].x >> q[i].y;
    }
}

int root(int x) {
    if (dad[x] == 0)
        return x;
    else {
        int repr = root(dad[x]);
        dad[x] = repr;
        return repr;
    }
}

void unite(int x, int y) {
    int repr_x = root(x);
    int repr_y = root(y);
    if (repr_x != repr_y) {
        if (rang[repr_x] > rang[repr_y])
            dad[repr_y] = repr_x;
        else if (rang[repr_x] < rang[repr_y])
            dad[repr_x] = repr_y;
        else {
            dad[repr_y] = repr_x;
            rang[repr_x]++;
        }
    }
}

int find(int x, int y) {
    return(root(x) == root(y));
}

int main()
{
    read();
    for (int i = 1; i <= m; i++) {
        if (q[i].cod == 1)
            unite(q[i].x, q[i].y);
        else {
            if (find(q[i].x, q[i].y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
}