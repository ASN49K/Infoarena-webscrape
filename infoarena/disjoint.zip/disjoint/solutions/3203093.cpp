#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("disjoint.in");
ofstream fout("disjoint.out");


int n,m,rx,ry;
int tata[100005];


int rad(int x)
{
    while(tata[x]>0) x=tata[x];
    return x;
}


void connect(int x,int y)
{
    int rx=rad(x);
    int ry=rad(y);
    if(tata[rx]<tata[ry])
    {
        tata[rx]-=tata[ry];
        tata[ry]=rx;
    }
    else
    {
        tata[ry]-=tata[rx];
        tata[rx]=ry;
    }
}


void solve()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++) tata[i]=-1;
    int x,y,q;
    for(int i=1;i<=m;i++)
    {
        fin>>q>>x>>y;
        if(q==1 && rad(x)!=rad(y)) connect(x,y);
        else
        {
            if(rad(x)==rad(y))fout<<"DA"<<endl;
            else fout<<"NU"<<endl;
        }
    }
}


int main()
{
    solve();
    return 0;
}
