#include <bits/stdc++.h>
using namespace std;
struct Padure_compresie {
	vector<int> padre;
	Padure_compresie(int n) {
		padre.resize(n+1);
	}
	int rad(int a){
		if (padre[a]==0)
			return a;
		padre[a]=rad(padre[a]);
		return padre[a];
	}
	void join(int a,int b) {
		a=rad(a);
		b=rad(b);
		if(a!=b)
			padre[a]=b;
	}
	bool query(int a, int b){
		return rad(a) == rad(b);
	}
};
int main() {
	//ifstream cin("disjoint.in");
	//ofstream cout("disjoint.out");
	int n,m,i,op,a,b;
	cin >> n >> m;
	Padure_compresie disjoint(n);
	for(i=0; i<m; i++){
		cin >> op >> a >> b;
		if (op == 1)
			disjoint.join(a, b);
		else if (disjoint.query(a, b))
			cout << "DA\n";
		else
			cout << "NU\n";
	}
	return 0;
}
