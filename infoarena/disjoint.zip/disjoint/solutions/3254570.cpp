#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int sefi[200001], cost_total;

int sef_suprem(int x) {
    if (sefi[x] == x) {
        return x;
    } else {
        return sefi[x] = sef_suprem(sefi[x]);
    }
}

void unire(int x, int y) {
    int sef1 = sef_suprem(x);
    int sef2 = sef_suprem(y);
    sefi[sef1] = sef2; //nu coteaza fleul in care legi arborii intre ei
}

int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        sefi[i] = i;
    }
    for (int i = 0; i < m; ++i) {
        int c, x, y;
        fin >> c >> x >> y;
        if (c == 1) {
            unire(x, y);
        } else {
            if (sef_suprem(x) == sef_suprem(y)) {
                fout << "DA\n";
            } else {
                fout << "NU\n";
            }
        }
    }
    
    return 0;
}