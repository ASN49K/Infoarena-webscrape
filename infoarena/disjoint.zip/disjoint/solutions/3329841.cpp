#include <bits/stdc++.h>

using namespace std;

int parent[100005],p;

int getParent(int nod)
{
    if(nod!= parent[nod])
    {
        getParent(parent[nod]);
        parent[nod]=p;
    }
    else
    {
        p=nod;
    }
    return p;
}
void cerinta1(int x, int y)
{
    parent[getParent(x)]= getParent(y);
}
string cerinta2(int x, int y)
{
    int parentX,parentY;
    parentX=getParent(x);
    parentY= getParent(y);
    return ((parentX == parentY) ? "DA\n" : "NU\n");
}
int main()
{
    ifstream cin("disjoint.in");
    ofstream cout("disjoint.out");
    int N,M,c,x,y;
    cin>>N>>M;
    for(int i=1;i<=N;i++)
    {
        parent[i]=i;
    }
    while(M--)
    {
        cin>>c>>x>>y;
        if(c==1)
        {
            cerinta1(x,y);
        }
        else
        {
            cout<<cerinta2(x,y);
        }
    }
    return 0;
}
