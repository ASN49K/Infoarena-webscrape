#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int NMAX = 1e5 + 1;
int n, m, parent[NMAX];

int Find(int nod)
{
    if(parent[nod] < 0)
        return nod;
    return (parent[nod] = Find(parent[nod]));
}

void Unire(int op, int x, int y)
{
    int r1 = Find(x), r2 = Find(y);
    if(r1 != r2)
    {
        if(op == 1)
        {
            ///numere negative, deci cel mai mic are marimea mai mare
            if(parent[r1] < parent[r2])
            {
                parent[r1] += parent[r2];
                parent[r2] = r1;
            }
            else
            {
                parent[r2] += parent[r1];
                parent[r1] = r2;
            }
        }
        else
            fout << "NU\n";
    }
    else
    {
        if(op == 2)
            fout << "DA\n";
    }
}

int main()
{
    fin >> n >> m;
    memset(parent, -1, sizeof(parent));
    while(m--)
    {
        int op, x, y;
        fin >> op >> x >> y;
        Unire(op, x, y);
    }

    return 0;
}
