#include <stdio.h>
#include <vector>
#include <algorithm>

struct DSU {
  std::vector<int> dsu;
  DSU( int n ): dsu(n, -1) {}
  int find( int u ){
    if( dsu[u] < 0 ) return u;
    return dsu[u] = find( dsu[u] );
  }

  bool unite( int a, int b ) {
    a = find( a ); b = find( b );
    if( a == b ) return false;

    if( -dsu[a] > -dsu[b] ){
      dsu[a] += dsu[b];
      dsu[b] = a;
    }else{
      dsu[b] += dsu[a];
      dsu[a] = b;
    }
    return true;
  }
};

int main() {
  FILE *fin = fopen( "disjoint.in", "r" );
  FILE *fout = fopen( "disjoint.out", "w" );

  int n, m;
  fscanf( fin, "%d%d", &n, &m );
  DSU zile(n);

  for( int i = 0; i < m; i++ ){
    int task, x, y;
    fscanf( fin, "%d%d%d", &task, &x, &y );
    x--; y--;

    if( task == 1 ) zile.unite( x, y );
    else fputs( zile.find(x) == zile.find(y) ? "DA\n" : "NU\n", fout );
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
