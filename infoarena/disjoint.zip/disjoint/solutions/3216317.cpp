#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

struct DSU {
    vector<int> fat;
    vector<int> sz;

    DSU(int n) {
        fat.resize(n + 1);
        sz.resize(n + 1);

        for(int i = 1; i <= n; i++) {
            fat[i] = i;
            sz[i] = 1;
        }
    }

    int get_fat(int x) {
        if(x == fat[x]) return x;
        return fat[x] = get_fat(fat[x]);
    }

    void join(int x, int y) {
        int rx = get_fat(x);
        int ry = get_fat(y);

        if(rx == ry) return;

        if(sz[rx] > sz[ry]) swap(rx, ry);

        fat[rx] = ry;
        sz[ry] += sz[rx];

        return;
    }

    bool same_set(int x, int y) {
        return get_fat(x) == get_fat(y);
    }
};

int main()
{
    int n,m; fin>>n>>m;
    DSU dsu = DSU(n);
    for(int i=1; i<=m; i++)
    {
        int op,x,y; fin>>op>>x>>y;
        if(op == 1)
        {
            dsu.join(x,y);
        }
        else
        {
            bool same_set = dsu.same_set(x,y);
            if(same_set) fout<<"DA\n";
            else fout<<"NU\n";
        }
    }
    return 0;
}
