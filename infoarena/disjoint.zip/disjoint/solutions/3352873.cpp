﻿#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 1;

int t[N];
int n, m, op, x, y;

int rad(int nod) {
	if (t[nod] == nod) return nod;

	return t[nod] = rad(t[nod]);
}

int main() {
	freopen("disjoint.in", "r", stdin);
	freopen("disjoint.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);

	cin >> n >> m;

	for (int i = 1; i <= n; ++i) t[i] = i;

	while (m--) {
		cin >> op >> x >> y;

		int rx = rad(x), ry = rad(y);

		if (op == 1) {
			t[y] = rx;
		}
		else {
			if (rx == ry) cout << "DA\n"; else cout << "NU\n";
		}
	}

	return 0;
}
