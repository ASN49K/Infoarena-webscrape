#include <bits/stdc++.h>
const int NMAX = 1e5;
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");
int parent[NMAX + 5], n, q;
int root (int u){
    if (parent[u] == u)
        return u;
    return parent[u] = root(parent[u]);
}
void unite(int x, int y){
    int root1 = root(x);
    int root2 = root(y);
    if (root1 == root2) return;
    parent[root1] = root2;
}
int main(){
    fin >> n >> q;
    for (int i = 1; i <= n; ++i)
        parent[i] = i;
    for (int i = 1, type, x, y; i <= q; ++i){
        fin >> type >> x >> y;
        if (type == 1)
            unite(x, y);
        else
            fout << (root(x) == root(y) ? "DA" : "NU") << "\n";
    }
    return 0;
}
