#include <fstream>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;
int v[100001];
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
struct DSU
{
    int N;
    map<int,int> parent,sizes;
    void init(int n,int a[])
    {
        N=n;
        for(int i=1;i<=n;i++)
        {
            parent[a[i]]=a[i];
            sizes[a[i]]=1;
        }
    }
    int findd(int u)
    {
        if(u==parent[u])
            return u;
        return parent[u]= findd(parent[u]);
    }
    void unite(int u, int v)
    {
        u=findd(u);
        v=findd(v);
        if(u==v)
            return;
        if(sizes[v]>sizes[u])
            swap(v,u);
        parent[u]=v;
        sizes[u]+=sizes[v];
    }
};
int main()
{

    DSU dsu;
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        v[i]=i;
    dsu.init(n,v);
    int q,a,b;
    for(int i=0;i<m;i++)
    {
        cin>>q>>a>>b;
        if(q==1)
            dsu.unite(a,b);
        else
        {
            if(dsu.findd(a)==dsu.findd(b))
                cout<<"DA"<<'\n';
            else
                cout<<"NU"<<'\n';
        }
    }
    return 0;
}
