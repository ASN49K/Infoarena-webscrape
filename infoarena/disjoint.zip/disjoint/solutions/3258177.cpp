#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax = 1e5;

int root[nmax + 1], n, m;

void init()
{
    for(int i = 1; i <= n; i++)
        root[i] = -1;
}

void uni(int a, int b)
{
    if(-root[a] > -root[b])
        swap(a, b);
    root[a] += root[b];
    root[b] = a;
}

int findd(int a)
{
    if(root[a] < 0)
        return a;
    root[a] = findd(root[a]);
    return root[a];
}

void update()
{
    int a, b;
    fin >> a >> b;
    a = findd(a);
    b = findd(b);
    uni(a, b);
}

void query()
{
    int a, b;
    fin >> a >> b;
    a = findd(a);
    b = findd(b);
    if(a == b)
        fout << "DA\n";
    else
        fout << "NU\n";
}

void solveOp()
{
    int op;
    fin >> op;
    if(op == 1)
        update();
    else
        query();
}

int main()
{
    fin >> n >> m;
    init();
    while(m--)
        solveOp();


    return 0;
}
