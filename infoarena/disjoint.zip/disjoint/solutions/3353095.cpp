#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int nmax = 100000;

int n,m;

int t[nmax + 5];

int rad(int x)
{
    int r = x;
    while (t[r] > 0)    r = t[r];
    while(x != r) {
        int aux = t[x];
        t[x] = r;
        x = aux;
    }
    return r;
}

void join(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);
    if (rx == ry)   return;
    if (-t[rx] < -t[ry]) swap(rx, ry);
    t[rx] += t[ry];
    t[ry] = rx;
}


int main()
{
    fin>>n>>m;
    for (int i = 1; i <= n; i++) t[i] = -1;
    for (int i = 1; i <= m; i++) {
        int x, y, t;
        fin>>t>>x>>y;
        if (t == 1) join(x,y);
        else {fout<<(rad(x) == rad(y) ? "DA" : "NU")<<'\n';}
    }

}
