/// DSU cu reuniune CU rang

#include <fstream>

using namespace std;

ifstream in ("disjoint.in");
ofstream out ("disjoint.out");

const int max_size = 1e5 + 1;

int t[max_size], rang[max_size];

int rad (int x)
{
    if (t[x] == x)
    {
        return x;
    }
    return t[x] = rad(t[x]);
}

void uniune (int x, int y)
{
    if (rang[x] > rang[y])
    {
        t[y] = x;
    }
    if (rang[y] > rang[x])
    {
        t[x] = y;
    }
    if (rang[y] == rang[x])
    {
        t[y] = x;
        rang[x]++;
    }
}

int main ()
{
    int n, q;
    in >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        t[i] = i;
        rang[i] = 1;
    }
    while (q--)
    {
        int op, x, y;
        in >> op >> x >> y;
        int rx = rad(x), ry = rad(y);
        if (op == 1)
        {
            if (rx == ry)
            {
                continue;
            }
            uniune(rx, ry);
        }
        else
        {
            if (rx == ry)
            {
                out << "DA" << '\n';
            }
            else
            {
                out << "NU" << '\n';
            }
        }
    }
    in.close();
    out.close();
    return 0;
}
