#include <bits/stdc++.h>
using namespace std;
ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");
int t[1001],n,m;
void Union (int x,int y)
{
    t[x]=y;
}
int Find (int x)
{
    int rad,y;
    rad=x;
    while (t[rad]>0)
        rad=t[rad];
    while (rad!=x)
    {
        y=t[x];
        t[x]=rad;
        x=y;
    }
    return rad;
}

int main()
{int x,y,o,t1,t2;
    fin>>n>>m;
    for (int i=1;i<=m;i++)
    {
        fin>>o>>x>>y;
        if (o==1)Union(x,y);
        else
        {
            t1=Find(x);
            t2=Find(y);
            if (t1==t2)
                fout<<"da"<<'\n';
            else
                fout<<"nu"<<'\n';
        }
    }
fin.close();
fout.close();
    return 0;
}
