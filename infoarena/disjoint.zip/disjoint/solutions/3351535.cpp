#include<bits/stdc++.h>
using namespace std;

const int NMAX = 1e5 + 5;
int n, m, parent[NMAX], sz[NMAX];

void cer1(int a, int b);
bool cer2(int x, int y);

int find(int x) {
    while(x != parent[x])
        x = parent[x];
    return x;
}

int main() {
    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);

    int c, a, b;
    cin >> n >> m;

    for(int i = 1; i <= n; i++) {
        parent[i] = i;
        sz[i] = 1;
    }

    for(int i = 1; i <= m; i++) {
        cin >> c >> a >> b;
        if(c == 1)
            cer1(a, b);
        if(c == 2) {
            bool ok = cer2(a, b);
            if(ok == false) 
                cout << "NU\n";
            else
                cout << "DA\n";
        }
    }
}

void cer1(int a, int b) {
    int x = find(a), y = find(b);
    if(sz[x] > sz[y]) {
        sz[x]++;
        parent[y] = x; 
    }
    else {
        sz[y]++;
        parent[x] = y;
    }
}

bool cer2(int x, int y) {
    x = find(x), y = find(y);
    return x == y;
}

