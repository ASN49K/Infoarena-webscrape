#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

#define cin fin
#define cout fout


int n,m,x,y;
int repr[100001],dim[100001];

int get_repr(int x) {
	if (repr[x] == x)
		return x;
	repr[x]=get_repr(repr[x]);
	return repr[x];
}


int op1(int x, int y)
{
    int a = get_repr(x);
    int b = get_repr(y);
    if (dim[a] > dim[b])
    {
        repr[b] = a;
        dim[a]+=dim[b];
    }
    else{
        repr[a] = b;
        dim[b]+=dim[a];
    }
}

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        dim[i] = 1;
        repr[i] = i;
    }
    int op,x,y;
    for (int i = 1 ; i <= m; i++)
    {
        cin >> op >> x >> y;
        if (op == 1)
        {
            op1(x,y);
        }
        else{
            if (get_repr(x) == get_repr(y)) cout << "DA" << '\n';
            else cout << "NU" << '\n';
        }
    }

}
