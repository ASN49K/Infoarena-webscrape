#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, m, i, op, x, y;
int t[100002];

static inline int tata(int a) {
    if(t[a] < 0) return a;
    else return t[a] = tata(t[a]);
}

static inline void uniune(int x, int y) {
    x = tata(x);
    y = tata(y);

    t[x] += t[y];
	t[y] = x;
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= n; i++) t[i] = -1;
    while(m--) {
        fin >> op >> x >> y;
        if(op == 1) uniune(x, y);
        else {
            int tx = tata(x);
            int ty = tata(y);
            if(tx != ty) fout << "NU\n";
            else fout << "DA\n";
        }
    }

    return 0;
}


