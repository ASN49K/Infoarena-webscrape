#pragma GCC optimize("O3")
#pragma GCC optimize("fast-math")
#pragma GCC optimize("unroll-loops")
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define nl nullptr
#define inf 0x3f3f3f3f
#define fi first
#define se second
#define pii pair<int, int>
#define mod 666013
#define dim 100055
#define dimdoi 105



using namespace std;



ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int tata[dim];
int findu(int x)
{
    if(x == tata[x]) return x;
    return tata[x] = findu(tata[x]);
}
void reunion(int x, int y)
{
    int r1 = findu(x);
    int r2 = findu(y);
    if(r1 != r2)
        tata[r2] = r1;
}
int n, m;

int main()
{
    fin >>  n >> m;
    for(int i = 1; i <= n; ++i)
        tata[i] = i;
    while(m--)
    {
        int op, x, y;
        fin >> op >> x>> y;
        if(op == 1)
            reunion(x, y);
        else
            if(findu(x) != findu(y))
             fout << "NU" << '\n';
           else fout << "DA" << '\n';
    }
    return 0;
}
