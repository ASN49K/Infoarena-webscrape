#include <fstream>
#include <vector>

using namespace std;

ifstream cin("disjoint.in");
ofstream cout("disjoint.out");

struct DSU
{
    int N;
    vector<int> parent, sizes;
    void init(int n)
    {
        N=n;
        parent.resize(n+1);
        sizes.resize(n+1);
        for(int i=1; i<=n; i++)
        {
            parent[i]=i;
            sizes[i]=1;
        }
    }
    
    int find(int u)
    {
        if(parent[u] == u)
        {
            return u;
        }
        parent[u]=find(u);
        return parent[u];
    }
    
    void unite(int u, int v)
    {
        u=find(u);
        v=find(v);
        if(u == v)
            return;
        if(sizes[u] < sizes[v])
            swap(u, v);
        parent[v]=u;
        sizes[v]+=sizes[u];
    }
};

int main()
{
    DSU dsu;
    int n, m;
    cin>>n>>m;
    dsu.init(n);
    for(int i=1; i<=m; i++)
    {
        int op, u, v;
        cin>>op>>u>>v;
        if(op == 1)
            dsu.unite(u, v);
        else
        {
            if(dsu.find(u) == dsu.find(v))
            {
                cout<<"DA\n";
            }
            else
            {
                cout<<"NU\n";
            }
        }
    }
    return 0;
}
