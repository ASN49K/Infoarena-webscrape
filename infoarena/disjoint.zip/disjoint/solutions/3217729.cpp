#include <fstream>

using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

#define NMAX 100008

int n,q,a,b,type,i,j;

struct dsu
{
    int father[NMAX];
    int set_find(int a)
    {
        if (father[a]==a)
        {
            return a;
        }
        return father[a]=set_find(father[a]);
    }
    void set_unite(int a, int b)
    {
        int pa=set_find(a),pb=set_find(b);
        if (pa!=pb)
        {
            father[pb]=pa;
        }
    }
}arb;

int main()
{
    fin>>n>>q;
    for (i=1; i<=n; i++)
    {
        arb.father[i]=i;
    }
    for (i=1; i<=q; i++)
    {
        fin>>type>>a>>b;
        if (type==1)
        {
            arb.set_unite(a,b);
        }
        else
        {
            if (arb.set_find(a)==arb.set_find(b))
            {
                fout<<"DA\n";
            }
            else
            {
                fout<<"NU\n";
            }
        }
    }
    return 0;
}
