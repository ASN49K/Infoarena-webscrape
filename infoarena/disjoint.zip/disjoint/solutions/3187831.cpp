#include <bits/stdc++.h>
#define DIM 100001

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int father[DIM];

int n, i, Q, task, x, y;

int get_root(int node){

    if(father[node] == node)

        return node;

    int x = get_root(father[node]);

    father[node] = x;

    return x;

}

void Merge(int x, int y){

    father[x] = y;

}

int main(){

    fin >> n >> Q;

    for(i=1;i<=n;i++)

        father[i] = i;

    while(Q--){

        fin >> task >> x >> y;

        if(task == 1){

            if(get_root(x) != get_root(y))

                Merge(get_root(x), get_root(y));

        }

        else

            fout << ((get_root(x) == get_root(y)) ? "DA\n" : "NU\n");


    }

}
