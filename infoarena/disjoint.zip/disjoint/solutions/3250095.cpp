#include <iostream>
#include <fstream>
#define Nmax 100000
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int TT[Nmax + 5];
int Find(int nod)
{
    if(TT[nod]==nod)
        return nod;
    else
        return Find(TT[nod]);
}
void unire(int x , int y)
{
    TT[y]=x;
}
int main()
{
    int n,m,x,y,op,a,b;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        TT[i]=i;
    }
    for(int i=1;i<=m;i++)
    {
        fin>>op>>x>>y;
        a=Find(x);
        b=Find(y);
        if(op == 1)
        {
            unire(a,b);
        }
        else
        {
            if(a==b)
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }
    return 0;
}
