#include <iostream>
#include <fstream>
using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int MAX = 100000;
int n, v[MAX+1];

void init (int n)
{
   int i;
   for(i=0; i<n; ++i)
   {
     v[i]=i;
   }
}

void unite(int x, int y)
{
   int i;
   for(i=0; i<n; ++i)
   {
      if(v[i]==v[x])
        v[i]=v[y];
   }
}
int find(int x)
   {
     return v[x];
   }

int main()
{
    int m, p, x, y, i;
    in>>n>>m;
    init(n);
    for(int i=0; i<m; ++i)
    {
       in>>p>>x>>y;

       if(p==1)
       {
         unite(x, y);
       }
       else
       {
          if( find(x)== find(y) )
            out<<"DA"<<'\n';
          else
            out<<"NU"<<'\n';
       }
    }
    return 0;
}
