using namespace std;
#include<iostream>
#include<fstream>
#include<vector>

#define NMAX 100005

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m;
int t[NMAX]/*tatal*/, h[NMAX]; ///inaltimea
int o, x, y;

int rad(int x) {
    while (t[x] != x) {
        x = t[x];
    }
    return x;
}

void _union(int x, int y) {
    int rx = rad(x);
    int ry = rad(y);
    
    if (rx == ry) return;
    
    if (h[rx] > h[ry]) {
        swap(rx, ry);
    }
    
    t[rx] = ry;
    
    if (h[rx] == h[ry]) {
        h[ry]++;
    }
}

bool _find(int x, int y) {
    int rx = rad(x);
    int ry = rad(y);
    
   ///unim toate nodurile cu tatal pe care l-am ales == compresie
    while (t[x] != x) {
        int p = t[x];
        t[x] = rx;
        x = p;
    }
    
    while (t[y] != y) {
        int p = t[y];
        t[y] = ry;
        y = p;
    }
    
    return rx == ry;
}

int main() {
    
    fin >> n >> m;
    
    for (int i = 1; i<=n; i++) {
        t[i] = i;
        h[i] = 1;
    }

    for (int i = 1; i<=m; i++) {
        fin >> o >> x >> y;
        if (o == 1) {
            _union(x, y);
        } else {
            if(_find(x, y)) {
                fout << "DA \n";
            } else {
                fout << "NU \n";
            }
        }
    }
    return 0;
}
