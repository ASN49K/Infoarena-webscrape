#include<fstream>
using namespace std;
ifstream F("disjoint.in");
ofstream G("disjoint.out");
int x,y,p[100001],c;
int main()
{
    for(F>>x>>c;F>>c>>x>>y;) {
        for(;p[x];x=p[x]);
        for(;p[y];y=p[y]);
        if(c<2)
            p[y]=x;
        else
            G<<(x==y?"DA\n":"NU\n");
    }
    return 0;
}
