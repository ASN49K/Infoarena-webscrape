#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <set>
using namespace std;
int n, m, cod, x, y;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
vector<pair<int,int>>G;
int t[100005], h[100005];
void funion(int r1, int r2){
    if(h[r1]>h[r2])
        t[r2]=r1;
    else{
        t[r1]=r2;
        if(h[r1]==h[r2])
            h[r2]++;
    }
}
int finding(int y){
    if(t[y]!=y)
        t[y]=finding(t[y]);
    return t[y];
}
void kruskal(){
    int nrm=0;
    for(int i=1;i<=n; i++){
        t[i]=i, h[i]=1;
    }
    for(auto muchie:G){
        int x=muchie.first, y=muchie.second;
        int tx=finding(x), ty=finding(y);
        if(tx==ty)
            continue;
        funion(tx, ty);
        nrm++;
        if(nrm==n-1)
            break;
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>cod>>x>>y;
        if(cod==1)
        {
            G.push_back({x, y});
        }
        else
        {
            kruskal();
            if(finding(x)==finding(y))
                fout<<"DA\n";
            else
                fout<<"NU\n";
        }
    }
    return 0;
}
