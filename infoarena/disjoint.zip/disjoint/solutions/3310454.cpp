#include<bits/stdc++.h>

using namespace std;

const int NMAX = 1e5 + 5;
int n, m, tata[NMAX], sz[NMAX];

int getTata(int x)
{
    while(x != tata[x])
        x = tata[x];
    return x;
}

void cerinta1(int a, int b)
{
    if(sz[a] > sz[b])
        swap(a, b);
    
    while(a != tata[a])
        a = tata[a];
    while(b != tata[b])
        b = tata[b];

    tata[a] = b;
    sz[b]++;
}

void cerinta2(int a, int b)
{
    while(a != tata[a])
        a = tata[a];
    while(b != tata[b])
        b = tata[b];

    if(tata[a] == tata[b])
        cout << "DA";
    else
        cout << "NU";
    cout << "\n";
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);

    cin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        tata[i] = i;
        sz[i] = 1;
    }

    int c, a, b;
    for(int i = 1; i <= m; i++)
    {
        cin >> c >> a >> b;
        if(c == 1)
            cerinta1(a, b);
        else
            cerinta2(a, b);
    }
}