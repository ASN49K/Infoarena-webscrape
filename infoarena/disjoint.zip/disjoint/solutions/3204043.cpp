#include <fstream>

using namespace std;
ifstream in("disjoint.in");
ofstream out("disjoint.out");
const int nmax = 100001;
int rang[nmax], tata[nmax];
void union1(int reprez1, int reprez2)
{
    if(rang[reprez1] == rang[reprez2])
    {
        tata[reprez1] = reprez2;
        rang[reprez2]++;
    }
    else if(rang[reprez1] < rang[reprez2])
        tata[reprez1] = reprez2;
    else if(rang[reprez1] > rang[reprez2])
        tata[reprez2] = reprez1;
}
int find1(int node)
{
    int reprez = node;
    while(tata[reprez] != reprez)
        reprez = tata[reprez];
    while(tata[node] != node)///cat timp node nu e radacina leg fiecare nod de reprezentanbtul multimii
    {
        int aux = tata[node];
        tata[node] = reprez;
        node = aux;
    }
    return reprez;
}
int main()
{
    int n,m;
    in>>n>>m;
    for(int i = 1; i <= n; i++)
    {
        tata[i] = i;
        rang[i] = 1;
    }
    for(int i = 1; i <= m; i++)
    {
        int op,x,y;
        in>>op>>x>>y;
        if(op == 1)
        {
            union1(find1(x),find1(y));

        }
        if(op == 2)
            if(find1(x) == find1(y))
                out<<"DA"<<'\n';
            else
                out<<"NU"<<'\n';
    }
    return 0;
}
