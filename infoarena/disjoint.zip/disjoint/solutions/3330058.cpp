#include <bits/stdc++.h>

std::ifstream fin("disjoint.in");
std::ofstream fout("disjoint.out");

int find_R(int node) {
    int R, x, y;

    // Cautam radacina
    for(R = node;
        radacina[R] != R;
        R = radacina[R])

    // Compresia drumului
    for(x = node, y = radacina[x];
        radacina[x] != x;
        radacina[x] = R, x = y)

    return R;
}

void unite(int node_A, node_B) {
    if(rang[node_A] > rang[node_B]) {
        radacina[node_B] = radacina[node_A];
        rang[node_A] += rang[node_B];
    }
    else {
        radacina[node_A] = radacina[node_B];
        rang[node_B] += rang[node_A];
    }
}

int main() {
    int n, m;
    fin >> n >> m;

    std::vector<int> radacina(n + 1), rang(n + 1);

    for(int i = 1; i <= n; ++i) {
        radacina[i] = i;
        rang[i] = 1;
    }

    while(m--) {
        int op, x, y;
        fin >> op >> x >> y;

        if(op == 1) {
            unite(x, y);
        }
        else {
            if(find_R(x) == find_R(y))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }

    return 0;
}
