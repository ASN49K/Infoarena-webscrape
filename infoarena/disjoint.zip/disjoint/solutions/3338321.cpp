#include <iostream>
#include <fstream>
using namespace std;
const int NMAX=100001;
int n,m,T[NMAX],Sz[NMAX];
ifstream f("disjoint.in");
ofstream g("disjoint.out");
///infoarena
int Find(int x)
{
    if(T[x]==0)
        return x;
    return T[x]=Find(T[x]);
}
void Union(int rx, int ry)
{
    if(Sz[rx]<Sz[ry])
    {
        T[rx]=ry;
        Sz[ry]+=Sz[rx];
    }
    else
    {
        T[ry]=rx;
        Sz[rx]+=Sz[ry];
    }
}
int main()
{
    int cod,x,y,rx,ry;
    f>>n>>m;
    for(int i=1;i<=n;i++)
        Sz[i]=1;
    while(m--)
    {
        f>>cod>>x>>y;
        rx=Find(x);
        ry=Find(y);
        if(cod==1)
            Union(rx,ry);
        else
            if(rx==ry)
            g<<"DA\n";
        else g<<"NU\n";
    }
    f.close();
    g.close();
    return 0;
}
