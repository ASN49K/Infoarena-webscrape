#include <fstream>
using namespace std;

ifstream fin ("disjoint.in");
ofstream fout ("disjoint.out");

int t[100001], n, m;

int radacina(int k)
{
	if (t[k] == 0)
		return k;
	return radacina(t[k]);
}

void reuniune(int k, int h)
{
	int r1 = radacina(k);
	int r2 = radacina(h);
	if (r1 != r2)		//k si h sunt submultimi diferite
		t[r2] = r1;
}

int main()
{
	int i, j, k, tip, r1, r2;
	fin >> n >> m;
	for (k = 1; k <= m; k++)
	{
		fin >> tip >> i >> j;
		if (tip == 1)
		{
			//reuniune
			reuniune(i, j);
		}
		else
		{
			r1 = radacina(i);
			r2 = radacina(j);
			if (r1 == r2)
				fout << "DA" << endl;
			else
				fout << "NU" << endl;
		}
	}
	return 0;
}
