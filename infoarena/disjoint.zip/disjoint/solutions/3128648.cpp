#include <bits/stdc++.h>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int rad[100005], card[100005];

int Find(int x)
{
    if(rad[x] == x)
        return x;
    rad[x]=Find(rad[x]);
    return rad[x];
}

void Union(int a, int b)
{
    if(card[a] < card[b])
        swap(a, b);
    card[a]+=card[b];
    rad[b]=rad[a];
}

int main()
{
    int n, m;
    fin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        rad[i]=i;
        card[i]=1;
    }
    for(int i=1; i<=m; i++)
    {
        int cod, x, y;
        fin>>cod>>x>>y;
        if(cod == 1)
        {
            if(Find(x) != Find(y))
                Union(x, y);
        }
        else
        {
            if(Find(x) == Find(y))
            {
                fout<<"DA\n";
            }
            else
                fout<<"NU\n";
        }
    }
    return 0;
}
