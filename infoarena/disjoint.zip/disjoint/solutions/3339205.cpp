#include <bits/stdc++.h>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
struct dsu
{
    vector<int> p;
    vector<int> sz;
    int n;
    dsu(int n)
    {
        this->n=n;
        p.resize(n+5);
        sz.resize(n+5);
        for(int i=1;i<=n;i++)
        {
            p[i]=i;
        }
    }
    int find_tata(int x)
    {
        if(x==p[x]) return x;
        p[x]=find_tata(p[x]);
        return p[x];
    }
    void unite(int x,int y)
    {
        int p1=find_tata(x);
        int p2=find_tata(y);
        if(sz[p1]<sz[p2])
        {
            swap(p1,p2);
        }
        p[p2]=p1;
        sz[p1]+=sz[p2];
    }
};
int main()
{
    int n,m;
    fin>>n>>m;
    dsu DSU(n);
    for(int i=1;i<=m;i++)
    {
        int tip,a,b;
        fin>>tip>>a>>b;
        if(tip==1)
        {
            DSU.unite(a,b);
        }
        else
        {
            int p1=DSU.find_tata(a);
            int p2=DSU.find_tata(b);
            if(p1==p2)
            {
                fout<<"DA\n";
            }
            else
            {
                fout<<"NU\n";
            }
        }
    }
    return 0;
}
