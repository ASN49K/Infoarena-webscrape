#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 100003;
int id[NMAX], sz[NMAX];

int query(int x) {
    if (x == id[x])
        return x;
    id[x] = query(id[x]);
    return id[x];
}

void unire(int a, int b) {
    a = query(a);
    b = query(b);

    if (a == b) {
        return;
    }

    if (sz[a] < sz[b])
        swap(a, b);

    sz[a] += sz[b];
    id[b] = a;
}

int main() {

    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; i++) {
        id[i] = i;
        sz[i] = 1;
    }

    while (m--) {
        int c, a, b;
        fin >> c >> a >> b;

        if (c == 1) {
            unire(a, b);
        } else {
            if (query(a) == query(b)) {
                fout << "DA\n";
            } else {
                fout << "NU\n";
            }
        }
    }

    return 0;
}
