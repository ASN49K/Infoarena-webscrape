#include <bits/stdc++.h>

using namespace std;

int card[100001];
int root[100001];

void unite(int x, int y)
{
    if (card[x]>card[y])
        swap(x,y);
    root[x]=root[y];
    card[y]+=card[x];
}

int searchset(int x)
{
    if (root[x]==x)
        return x;
    searchset(root[x]);
}

int main()
{
    ifstream fin("disjoint.in");
    ofstream fout("disjoint.out");
    int n,m,i,type,a,b;
    fin >> n >> m;
    for (i=1;i<=n;i++)
    {
        card[i]=1;
        root[i]=i;
    }
    for (i=1;i<=m;i++)
    {
        fin >> type >> a >> b;
        if (type==1)
        {
            unite(a,b);
        }
        else
        {
            if (searchset(a)==searchset(b))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
