#include <iostream>
#include <fstream>
#include <algorithm>
#include <unordered_map>
#include <vector>
#include <tuple>
#include <queue>
#define inmat lin >= 1 && lin <= n && col >=1 && col <= m

using namespace std;

ifstream in("disjoint.in");
ofstream out("disjoint.out");

#define cin in
#define cout out

const int N = 1e5 + 2000;

int n, q;

int rad[N], rang[N];

void UNIRE(int x, int y)
{
	if (rang[y] < rang[x])
	{
		rad[y] = x;
	}
	else
		rad[x] = y;
	if (rang[x] == rang[y]) // rang[y] >= rang[x] deci y este mult invingatoare
		rang[y]++;
}

int find(int x)
{
	int radacina = x;
	while (radacina != rad[radacina])
	{
		radacina = rad[radacina];
	}
	int radacina2 = x;
	while (radacina2 != rad[radacina2])
	{
		radacina2 = rad[radacina2];
		rad[radacina2] = radacina;
	}
	return radacina;
}

int main()
{
	cin >> n >> q;
	for (int i = 1; i <= n; i++)
	{
		rad[i] = i;
		rang[i] = 1;
	}
	int c, x, y;
	for (int i = 1; i <= q; i++)
	{
		cin >> c >> x >> y;
		if (c == 2)
		{
			if (find(x) == find(y))
				cout << "DA\n";
			else
				cout << "NU\n";
		}
		else
		{
			if (find(x) == find(y)) { fprintf(stderr, "%d ", i); return 0; }
			UNIRE(x, y);
		}
	}
}