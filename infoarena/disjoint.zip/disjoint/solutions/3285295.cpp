#include <bits/stdc++.h>
#define mod 1000000007

using namespace std;

ifstream f("disjoint.in");

ofstream g("disjoint.out");


int parinte(int nod,vector<int>tata){
    while(nod!=tata[nod])
        nod=tata[nod];
    return nod;
}

int main()
{

    int n,op;
    f>>n>>op;
    vector<int>tata(n+1);
    for(int i=1; i<=n; ++i)
        tata[i]=i;
    for(int i=1; i<=op; ++i){
        int t,x,y;
        f>>t>>x>>y;
        int px=parinte(x,tata);
        int py=parinte(y,tata);
        if(t==1)
            tata[px]=py;
        else if(px==py)
            g<<"DA\n";
            else g<<"NU\n";
    }

    return 0;

}
