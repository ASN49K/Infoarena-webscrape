#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

vector <int> l[101];
int n,m;
int tata[101];

void init0(){
    for(int i=1;i<=n;i++)
        tata[i]=-1;
}
int find(int node){
    for(int i=1;i<=n;i++)
        if(tata[i]==node)
            return find(i);
    return node;
}

int main() {
    fin>>n>>m;
    int x,y,z;
    for(int i=1;i<=m;i++){
        fin>>x>>y>>z;
        if(x==1){
            tata[y]=z;
        }
        else{
            if(find(y)==find(z))
                fout<<"DA";
            else
                fout<<"NU";
            fout<<endl;
        }
    }
    return 0;
}
