#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m, tata[100001], h[100001];

int radacina(int x) {
    if (tata[x] == 0)
        return x;
    else {
        int tmp = radacina(tata[x]);
        tata[x] = tmp;
        return tmp;
    }
}

void unire(int x, int y) {
    int rx = radacina(x), ry = radacina(y);
    if (rx != ry) {
        if (h[rx] > h[ry])
            tata[ry] = rx;
        else {
            tata[rx] = ry;
            if (h[rx] == h[ry])
                h[ry]++;
        }
    }
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int t, a, b;
        fin >> t >> a >> b;
        if (t == 1)
            unire(a, b);
        else {
            if (radacina(a) == radacina(b))
                fout << "DA\n";
            else
                fout << "NU\n";
        }
    }
    return 0;
}
