#include <fstream>
#include <vector>

using namespace std;
ifstream cin("disjoint.in");
ofstream cout("disjoint.out");
int parent[100001];

int fin(int u){
    if(parent[u] == u){
        return u;
    }
    return fin(parent[u]);
}
void unite(int u, int v){
    u = fin(u);
    v = fin(v);
    if(u != v){
        parent[u] = v;
    }
    return;
}
int main()
{
    int n, m, fel, a, b;
    cin >> n >> m;
    for(int i = 1; i <= n; i++){
        parent[i] = i;
    }
    for(int i = 0; i < m; i++){
        cin >> fel >> a >> b;
        if(fel == 1){
            unite(a, b);
        }else{
            if(fin(a) == fin(b)){
                cout << "DA\n";
            }else{
                cout << "NU\n";
            }
        }
    }
    return 0;
}
