#include <fstream>
using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int t[100005];
int inalt[100005];
int n, m;
int x, y, op;

int radacina(int x) {
    if (t[x]==0) return x;
    else return radacina(t[x]);
}

void reuniune(int x, int y) {
    int rad_x = radacina(x);
    int rad_y = radacina(y);
    if (inalt[rad_x] > inalt[rad_y]) t[rad_y] = rad_x;
    else if (inalt[rad_y] > inalt[rad_x]) t[rad_x] = rad_y;
    else {
        t[rad_y] = rad_x;
        inalt[rad_x]++;
    }
}

void verificare(int x, int y) {
    if (radacina(x) == radacina(y)) g << "DA\n";
    else g << "NU\n";
}

int main()
{
    f >> n >> m;
    for (int i=1;i<=m;i++) {
        f >> op >> x >> y;
        if (op==1) {
            reuniune(x, y);
        }
        else verificare(x, y);
    }
    return 0;
}
