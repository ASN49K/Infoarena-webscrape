#include <iostream>
#include <fstream>

using namespace std;
struct nod
{
    int papi;
    int churo;
}v[100005];
void build (int n)
{
    for (int i=1; i<=n; i++)
    {
        v[i].papi=i;
        v[i].churo=1;
    }
    return;
}
int query(int x)
{
    int daddy=x, check;
    while (daddy!=v[daddy].papi)
        daddy=v[daddy].papi;
    while (x!=v[x].papi)
    {
        check=x;
        x=v[x].papi;
        v[check].papi=daddy;
    }
    return daddy;
}
int kiss_marry_kill(int x, int y)
{
    if (v[x].churo<v[y].churo)
        swap(x, y);
    v[y].papi=x;
    if (v[y].churo==v[x].churo)
    {v[y].churo++;}
}
int main()
{
    ifstream cin ("disjoint.in");
    ofstream cout ("disjoint.out");
    int n, m, gender, a, b;
    cin>>n>>m;
    build (n);
    for (int i=1; i<=m; i++)
    {
        cin>>gender>>a>>b;
        if (gender==1)
        {
            kiss_marry_kill(a, b);
        }
        else
        {
            if (query(a)==query(b))
                cout<<"DA"<<'\n';
            else
                cout<<"NU"<<'\n';
        }
    }
}
