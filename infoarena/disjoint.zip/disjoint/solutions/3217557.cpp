#include <iostream>
using namespace std;

#define NMAX 100000

int n, m;
int t[NMAX + 1];

int rad(int x) {
    while (t[x] != 0) {
        x = t[x];
    }
    return x;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("disjoint.in", "r", stdin);
    freopen("disjoint.out", "w", stdout);

    cin >> n >> m;

    for (int i = 0; i < m; i += 1) {
        int cod, x, y;
        cin >> cod >> x >> y;
        if (cod == 1) {
            t[rad(y)] = rad(x);
        } else {
            cout << (rad(x) == rad(y) ? "DA" : "NU") << '\n';
        }
    }

    return 0;
}