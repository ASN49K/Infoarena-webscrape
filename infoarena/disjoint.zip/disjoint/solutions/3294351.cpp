﻿//https://infoarena.ro/problema/disjoint
//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES
#include <iostream>
#include <fstream>
#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <climits>
//#include <iomanip>
using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int a[100005];
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n, m, i, c, x, y;

	fin >> n >> m;
	for(i = 1; i <= m; ++i)
	{
		fin >> c >> x >> y;

		if (c == 1)
		{
			int xx = x, yy = y;
			int cxx = x, cyy = y;

			while (a[xx])
			{
				xx = a[xx];
			}

			while (a[cxx])
			{
				int aux = a[cxx];
				a[cxx] = xx;
				cxx = aux;
			}

			while (a[yy])
			{
				yy = a[yy];
			}

			while (a[cyy])
			{
				int aux = a[cyy];
				a[cyy] = yy;
				cyy = aux;
			}

			a[xx] = yy;
		}
		else
		{
			int xx = x, yy = y;
			int cxx = x, cyy = y;

			while (a[xx])
			{
				xx = a[xx];
			}

			while (a[cxx])
			{
				int aux = a[cxx];
				a[cxx] = xx;
				cxx = aux;
			}

			while (a[yy])
			{
				yy = a[yy];
			}

			while (a[cyy])
			{
				int aux = a[cyy];
				a[cyy] = yy;
				cyy = aux;
			}

			if (xx == yy)
				fout << "DA\n";
			else
				fout << "NU\n";
		}
	}


	return 0;
}