#include <fstream>

using namespace std;
int card[100005];
int tata[100005];
ifstream cin ("disjoint.in");
ofstream cout ("disjoint.out");
int gaseste(int a)
{
   if (tata[a]==a)
    return a;
   tata[a]=gaseste(tata[a]);
   return tata[a];
}
void uniune(int a, int b)
{
    if (a==b)
        return;
    if (card[a]<card[b])
        swap(a, b);
    card[a]+=card[b];
    tata[b]=a;
    return;
}
int main()
{
    int n, q, gender, a, b;
    cin>>n>>q;
    for (int i=1; i<=n; i++)
    {
        card[i]=1;
        tata[i]=i;
    }
    for (int i=0; i<q; i++)
    {
        cin>>gender>>a>>b;
        if (gender==1)
        {
            uniune(gaseste(a), gaseste(b));
        }
        else
        {
            if (gaseste(a)==gaseste(b))
                cout<<"DA";
            else
                cout<<"NU";
        }
    }
}
