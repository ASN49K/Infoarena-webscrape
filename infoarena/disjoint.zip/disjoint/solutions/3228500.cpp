#include<fstream>
using namespace std;
ifstream F("disjoint.in");
ofstream G("disjoint.out");
#define Z 2048
int n,m,r[100001],i,j,k,p=Z;
char s[Z];
inline char A()
{
    if(p==Z)
        F.read(s,Z),p=0;
    return s[p++];
}
int B()
{
    char c;
    int n=0;
    for(c=A();isdigit(c);n=n*10+c-48,c=A());
    return n;
}
int main()
{
    for(n=B(),m=B();m--;) {
        for(i=B(),j=B(),k=B();r[j];j=r[j]);
        for(;r[k];k=r[k]);
        if(i<2)
            r[k]=j;
        else
            G<<(j==k?"DA\n":"NU\n");
    }
    return 0;
}
