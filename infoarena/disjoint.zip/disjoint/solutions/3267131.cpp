#include <fstream>

using namespace std;

const int nmax = 1e5;

struct dsu {
    dsu(int n) {
        for(int i=1; i<=n; i++) {
            parent[i] = i;
            h[i] = 0;
        }
    }

    int find(int x) {
        if(parent[x] == x)
            return x;
        return parent[x] == find(parent[x]);
    }

    void union_(int x, int y) {
        x = find(x);
        y = find(y);

        if(x == y) return;

        if(h[x] < h[y]) parent[x] = y;
        else if(h[x] > h[y]) parent[y] = x;
        else {
            parent[x] = y;
            h[y]++;
        }
    }

    int parent[nmax+1], h[nmax+1];
};

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, q, x, y, op;

int main() {
    fin >> n >> q;

    dsu sets(n);
    while(q--) {
        fin >> op >> x >> y;

        if(op == 1) {
            sets.union_(x, y);
        } else {
            if(sets.find(x) == sets.find(y)) {
                fout << "DA\n";
            } else fout << "NU\n";
        }
    }
    return 0;
}
