#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

#define nmax 100005
int tata[nmax];
int rang[nmax];

int radacina(int nod){
    if(nod == tata[nod]){
        return nod;
    }

    return tata[nod] = radacina(tata[nod]);
}

int uneste(int x, int y){
    if(rang[x] < rang[y]){
        tata[x] = y;
    }
    else{
        tata[y] = x;
        if(rang[x] == rang[y])
            rang[y]++;
    }
}

int main()
{
    int n, m, cod;
    fin >> n >> m;
    for(int i = 0; i < n; i++){
        tata[i] = i;
        rang[i] = 1;
    }

    while(m--){
        int x, y;
        fin >> cod >> x >> y;
        if(cod == 1){
            uneste(x, y);
        }
        else{
            if(radacina(x) == radacina(y))
                fout << "DA" << '\n';
            else
                fout << "NU" << '\n';
        }
    }


    return 0;
}
