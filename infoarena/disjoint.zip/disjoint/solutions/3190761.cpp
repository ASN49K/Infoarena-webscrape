#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n,m,c,x,y,root[100005],size[100005];
int getroot(int x)
{
    while(root[x]!=0)
        x=root[x];
    return x;
}
void task(int x,int y)
{
    int rootx=getroot(x),rooty=getroot(y);
    if(size[rootx]<size[rooty])
        swap(rootx,rooty);
    root[rooty]=rootx;
    size[rootx]+=size[rooty];
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        size[i]=1;
    for(int i=1; i<=m; i++)
    {
        fin>>c>>x>>y;
        if(c==1)
            task(x,y);
        else if(getroot(x)==getroot(y))
            fout<<"DA"<<'\n';
        else
            fout<<"NU"<<'\n';
    }
    return 0;
}
