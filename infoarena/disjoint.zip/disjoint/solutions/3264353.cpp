#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

int n, m;
vector<int> a, b;

void reun(int x, int y)
{
    while(a[x]!=x)
        x=a[x];
    while(a[y]!=y)
        y=a[y];

    if(b[x]<b[y])
        swap(x,y);
    a[y]=x;
    b[x]+=b[y];
    b[y]=0;
}

void afis(int x, int y)
{
    while(a[x]!=x)
        x=a[x];
    while(a[y]!=y)
        y=a[y];
    if(x==y) fout<<"DA\n";
    else fout<<"NU\n";
}

int main()
{
    fin>>n>>m;

    for(int i=0; i<=n; i++)
        a.push_back(i);
    b.resize(a.size(),1);

    for(int k=1; k<=m; k++){
        int c, x, y;
        fin>>c>>x>>y;
        if(c==1)
            reun(x,y);
        else if(c==2)
            afis(x,y);
    }
}
