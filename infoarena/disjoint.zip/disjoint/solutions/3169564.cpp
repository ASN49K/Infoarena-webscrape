#include <bits/stdc++.h>


using namespace std;

int n;
int number;

int v[501];
bool ans[501];
bool solve(int index,int nr_open){
    if(index==n+1){
        if(nr_open==0)
            return true;
        return false;
    }else{
        if(nr_open<v[index]){
            int val1=solve(index+1,nr_open+v[index]);
            if(val1){
                ans[index]=true;
                return true;
            }
            return false;
        }else{
            bool val1=solve(index+1,nr_open-v[index]);
            bool val2=solve(index+1,nr_open+v[index]);
            if(val1){
                ans[index]=false;
                return true;
            }
            if(val2){
                ans[index]=true;
                return true;
            }
            return false;
        }
    }
}
int main()
{
    scanf("%d",&n);
    bool ok=true;

    for(int i=1;i<=n;i++)
        scanf("%d",&v[i]);


    char ch;

    if(solve(1,0)){
        for(int i=1;i<=n;i++){
            if(ans[i]==false)
                ch=')';
            else
                ch='(';
            for(int j=1;j<=v[i];j++)
                printf("%c",ch);
        }
    }
    else{
        printf("-1");
    }



    return 0;
}
