#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

#define NMAX 100000

int parent[NMAX + 1];

int findsef(int x){
    if (parent[x] != x){
        return findsef(parent[x]);
    }
    return x;
}

void unite(int x, int y){
    parent[findsef(y)] = findsef(x);
}

char same(int x, int y){
    return findsef(x) == findsef(y);
}

void init(int N){
    for (int i = 1; i <= N; i++){
        parent[i] = i;
    }
}

int main()
{
    int N, M;
    fin >> N >> M;
    init(N);
    for (int i = 1; i <= M; i++){
        int tip, x, y;
        fin >> tip >> x >> y;
        if (tip == 1){
            unite(x, y);
        }
        else{
            int rez = same(x, y);
            if (rez == 1){
                fout << "DA\n";
            }
            else{
                fout << "NU\n";
            }
        }
    }
    return 0;
}
