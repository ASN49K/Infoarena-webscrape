//
//  main.cpp
//  Paduri de multimi disjuncte
//
//  Created by Andrada Minca on 22.03.2025.
//

#include <fstream>
using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
const int MAX = 100005;
int padre[MAX];

void Union(int x, int y)
{
    padre[y]=x;
}

int FindRoot(int x)
{
    int rad=x;
    while (padre[rad]!=0)
        rad=padre[rad];

    while (x!=rad)
    {
        int y=padre[x];
        padre[x]=rad;
        x=y;
    }
    return rad;
}

int main()
{
    int n,m;
    fin>>n>>m;

    for (int i=1;i<=m;i++)
    {
        int c,x,y;
        fin>>c>>x>>y;
        x=FindRoot(x);
        y=FindRoot(y);
        if (c==1)
        {
            if (x!=y)
                Union(x,y);
        }
        else
        {
            if(x==y)
                fout<<"DA"<<'\n';
            else
                fout<<"NU"<<'\n';
        }
    }

    return 0;
}
