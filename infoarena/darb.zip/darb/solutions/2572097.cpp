#include <fstream>
#include <vector>
#define Nmax 100001
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n,dif,max1,nod;
vector <int> G[Nmax];
void DFS(int x,int str,int fina)
{
    if (fina>max1)
    {
        max1=fina;
        nod=x;
    }
    for (auto i:G[x])
    {
        if (i!=str){
            DFS(i,x,++fina);
            fina--;
        }
    }
}
int main()
{
    int i,a,b;
    fin>>n;
    for (i=1;i<=n;i++)
    {
        fin>>a>>b;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    DFS(1,0,0);
    max1=0;
    DFS(nod,0,0);
    fout<<max1+1;
    return 0;
}
