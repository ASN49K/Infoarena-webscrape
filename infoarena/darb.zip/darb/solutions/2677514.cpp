#include <fstream>
#include <vector>

using namespace std;
ifstream f ("darb.in");
ofstream g ("darb.out");
int const N = 1e5 + 1;
int v [2 * N] , vf [2 * N] , nxt [2 * N] , sz;
int nod , hmax;
bool viz [N];
void add (int x  ,int y){
    vf [++ sz] = y;
    nxt [sz] = v [x];
    v [x] = sz;
}
void DF (int node , int h){
    viz [node] = true;
    if (h > hmax)
        hmax = h , nod = node;
    for(int i = v [node] ; i ; i = nxt [i]){
        int y = vf [i];
        if (! viz [y])
            DF (y , h + 1);
    }
}
int main()
{
    int n;
    f >> n;
    for(int i = 1 ; i <= n ; ++ i){
        int a , b;
        f >> a >> b;
        add (a , b);
        add (b , a);
    }
    DF (1 , 0);
    for(int i = 1 ; i <= n ; ++ i)
        viz [i] = false;
    DF (nod , 1);
    g << hmax;
    return 0;
}
