#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n, maxi, nod;
bool viz[100005];
vector<int> G[100005];
void Dfs(int x, int h)
{
    viz[x] = 1;
    for(int e : G[x])
        if(viz[e] == 0)
            Dfs(e, h + 1);
    if(maxi < h)
    {
        maxi = h;
        nod = x;
    }
}

int main()
{
    int i, j;
    fin >> n;
    for(int ind = 1;ind < n;ind++)
    {
        fin >> i >> j;
        G[i].push_back(j);
        G[j].push_back(i);
    }
    Dfs(1, 0);
    for(i = 1;i <= n;i++)
        viz[i] = 0;
    Dfs(nod, 0);
    fout << maxi + 1 << "\n";
    fout.close();
    return 0;
}
