

#include <fstream>
#include <vector>
#include <stack>
#include <queue>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
int n;
int a, b;
vector<vector<int>> A;
vector<bool> fr;
int maxi, last;
void dfs(int nod,int l)
{
	if (l > maxi)
	{
		maxi = l;
		last = nod;
	}
	for (int i = 0; i < A[nod].size(); i++)
	{
		int vecin = A[nod][i];
		if (!fr[vecin])
		{
			fr[vecin] = 1;
			dfs(vecin, l + 1);
		}
	}
}
int main()
{
	cin >> n;
	A.resize(n + 1);
	fr.resize(n + 1);
	for (int i = 0; i < n - 1; i++)
	{
		cin >> a >> b;
		A[a].push_back(b);
		A[b].push_back(a);
	}
	fr[1] = 1;
	dfs(1, 1);
	fr.resize(0);
	fr.resize(n + 1);
	maxi = 0;
	fr[last] = 1;
	dfs(last,1);
	cout << maxi;
	return 0;
}



