#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

int nodes;
vector <int> graph[100005];
int viz[100005];

int dfs (int x){
    viz[x] = true;

    int ans = 0;
    for (auto idx:graph[x])
        if (viz[idx] == false)
            ans = max(ans, dfs(idx));
    
    return ans + 1;
}

int main (){
    int x, y;

    in >> nodes;
    for (int i=1; i<nodes; ++i){
        in >> x >> y;

        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    int best1 = 0, best2 = 0;
    viz[1] = true;
    for (auto idx:graph[1]){
        int current = dfs(idx);

        if (current > best1){
            best2 = best1;
            best1 = current;
        }
        else if (current > best2 && current <= best1){
            best2 = current;
        }
    }

    out << best1 + best2 + 1;


    return 0;
}