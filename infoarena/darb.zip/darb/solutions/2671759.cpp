#include <bits/stdc++.h>

using namespace std;
vector <int> G[100001];
int n,last,maxi=-1;
bitset <100001> H;
ifstream f("darb.in");
ofstream g("darb.out");

void DFS(int node,int level=1)
{
    H[node]=1;
    if(level>maxi) maxi=level,last=node;
    for(auto it:G[node])
        if(H[it]==0) DFS(it,level+1);
}

int main()
{
    f>>n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    DFS(1);
    H=0;
    DFS(last);

    g<<maxi;

}
