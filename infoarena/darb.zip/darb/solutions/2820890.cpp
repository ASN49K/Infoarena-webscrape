#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
int n, a, b;
vector<int> v[200001];
int use[200001];
void reset()
{
    for (int i = 1; i <= n; i++)
    {
        use[i] = 0;
    }
}
int ans, aux;
void dfs(int x, int d)
{
    use[x] = 1;
    if (d > ans)
    {
        ans = d;
        aux = x;
    }
    for (auto i : v[x]) 
    {
        if (!use[i])
            dfs(i, d + 1);
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin >> n;
    for (int i = 1; i < n; i++)
    {
        cin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    dfs(1, 0);
    reset();
    dfs(aux, 1);
    cout << ans;
    return 0;
}