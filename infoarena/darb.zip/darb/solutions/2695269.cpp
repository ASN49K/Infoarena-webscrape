#include <bits/stdc++.h>
using namespace std;

vector <vector <int>> edges;
bitset <100100> vazut;
int ultimul = 0, maxim = 0;

void parcurge(int i, int lg) {
    vazut[i] = !vazut[0];
    if (lg > maxim) {
        maxim = lg;
        ultimul = i;
    }
    for (int j = 0; j < edges[i].size(); j++)
        if (vazut[edges[i][j]] == vazut[0])
            parcurge(edges[i][j], lg + 1);
}

int main() {
    freopen("darb.in", "r", stdin);
    freopen("darb.out", "w", stdout);
    int n, i, x, y;
    cin >> n;
    edges = vector <vector <int>> (n + 1);

    for (i = 1; i < n; i++) {
        cin >> x >> y;
        edges[x].push_back(y);
        edges[y].push_back(x);
    }
    parcurge(1, 1);
    vazut[0] = 1;
    parcurge(ultimul, 1);
    cout << maxim << '\n';
    return 0;
}
