#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define TITLE "darb"

ifstream f (TITLE".in");
ofstream g (TITLE".out");

int n;

int bfs1(int StartNode,vector<vector<int>> &Graph,vector<int> Distances)
{
    Distances[StartNode]=1;
    queue<int> Q;
    int CurrentNode;
    for(Q.emplace(StartNode); !Q.empty(); Q.pop())
    {
        CurrentNode=Q.front();
        for(auto it : Graph[CurrentNode])
        if(Distances[it]==0)
        {
            Distances[it]=true;
            Q.emplace(it);
        }
    }
    return CurrentNode;
}

int bfs2(int StartNode,vector<vector<int>> &Graph,vector<int> &Distances)
{
    Distances[StartNode]=1;
    queue<int> Q;
    int CurrentNode;
    for(Q.emplace(StartNode); !Q.empty(); Q.pop())
    {
        CurrentNode=Q.front();
        for(auto it : Graph[CurrentNode])
        if(Distances[it]==0)
        {
            Distances[it]=Distances[CurrentNode]+1;
            Q.emplace(it);
        }
    }
    return CurrentNode;
}

int main()
{
    f>>n;
    vector<vector<int>> Graph(n+1);
    for(int a,b; f>>a>>b; Graph[a].emplace_back(b), Graph[b].emplace_back(a));
    vector<int> Distances(n+1,0);
    g<<Distances[bfs2(bfs1(1,Graph,Distances),Graph,Distances)];
    return 0;
}
