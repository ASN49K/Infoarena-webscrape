#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("darb.in");
ofstream fout ("darb.out");
int max1[100001],max2[100001],dp[100001];
int n,i,x,y;
vector <int> v[100001];
void dfs (int nod,int t)
{
    int ok=0;
    for (int i=0; i<v[nod].size (); i++)
    {
        int vecin=v[nod][i];
        if (vecin!=t)
        {
            ok++;
            dfs (vecin,nod);
            if (max1[vecin]+1>=max1[nod])
            {
                max2[nod]=max1[nod];
                max1[nod]=max1[vecin]+1;
            }
            else if (max1[vecin]+1>max2[nod])
                max2[nod]=max1[vecin]+1;
            dp[nod]=max (dp[nod],dp[vecin]);
        }
    }
    if (ok==0)
    {
        max1[nod]=1;
        dp[nod]=1;
    }
    else if (ok==1)
        dp[nod]=max (dp[nod],max1[nod]);
    else
        dp[nod]=max (dp[nod],max1[nod]+max2[nod]-1);
}
int main ()
{
    ///dp[i]=lg. diam. pt subarb. lui i
    ///dp[i]=max (dp[vecin],lanturi maxime din nodul i)
    fin>>n;
    for (i=1; i<=n; i++)
    {
        fin>>x>>y;
        v[x].push_back (y);
        v[y].push_back (x);
    }
    dfs (1,0);
    fout<<dp[1];
    return 0;
}
