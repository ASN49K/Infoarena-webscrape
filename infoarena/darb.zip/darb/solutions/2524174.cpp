#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int N = 1e5 + 2;

vector <int> L[N];
int d[N], n;
bitset <N> viz;

void Read ()
{
    int x, y;
    fin >> n;
    for (int i = 1; i < n; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
}

void Dist_Reset ()
{
    for (int i = 1; i <= n; i++)
        d[i] = 1e9;
}

void DFS (int k)
{
    viz[k] = 1;
    for (auto i : L[k])
        if (!viz[i])
        {
            d[i] = 1 + d[k];
            DFS(i);
        }
}

void Solve ()
{
    Dist_Reset();
    d[1] = 0;
    DFS(1);
    int nodmax = 1, i;
    for (i = 2; i <= n; i++)
        if (d[i] > d[nodmax])
            nodmax = i;
    Dist_Reset();
    viz.reset();
    d[nodmax] = 0;
    DFS(nodmax);
    int diameter = -1;
    for (i = 1; i <= n; i++)
        if (d[i] > diameter)
            diameter = d[i];
    fout << 1 + diameter << "\n";
}

int main()
{
    Read();
    Solve();
    return 0;
}
