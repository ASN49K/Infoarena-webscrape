#include <fstream>
#include <vector>
#include <climits>

using namespace std;

const int Nmax = 100005;

vector<int> L[Nmax];
int diam[Nmax], lant[Nmax];

void dfs(int node, int father) {
    for(int son : L[node]) {
        if(son != father) {
            dfs(son, node);
        }
    }
    int max1 = -INT_MAX, max2 = -INT_MAX;
    for(int son : L[node]) {
        if(son != father) {
            lant[node] = max(lant[node], lant[son] + 1);
            if(lant[son] > max1) {
                max2 = max1;
                max1 = lant[son];
            }
            else if(lant[son] > max2) {
                max2 = lant[son];
            }
        }
    }
    diam[node] = max(max1, 0) + max(max2, 0) + 1;
}

int main() {
    int n;
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    fin >> n;
    for(int i = 1; i < n; i++) {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1, 0);
    fout << diam[1] << "\n";
    return 0;
}