#include <fstream>
#include <vector>
#define NMAX 100009
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n,maxim,maxnod;
void dfs(int x,int val);
void dfs1(int x,int val);
vector <int> g[NMAX];
bool uz[NMAX];
int main()
{
    fin>>n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1,1);
    dfs1(maxnod,1);
    fout<<maxim;
    return 0;
}
void dfs(int x,int val)
{
    uz[x]=1;
    if(maxim<val)
    {
        maxim=val;
        maxnod=x;
    }
    for(int i=0;i<g[x].size();i++)
    {
        if(!uz[g[x][i]])
        {
            uz[g[x][i]]=1;
            dfs(g[x][i],val+1);
        }
    }
}
void dfs1(int x,int val)
{
    uz[x]=0;
    if(maxim<val)
    {
        maxim=val;
        maxnod=x;
    }
    for(int i=0;i<g[x].size();i++)
    {
        if(uz[g[x][i]])
        {
            uz[g[x][i]]=0;
            dfs1(g[x][i],val+1);
        }
    }
}
