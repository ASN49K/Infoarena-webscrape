#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int nmax = 100005;
int n, maxim = 0;
bool viz[nmax];
vector <int> G[nmax];

void dfs(int nod, int lungime){
    viz[nod] = true;
    maxim = max(maxim, lungime);
    for (auto vecin : G[nod]){
        if (viz[vecin] == false){
            dfs(vecin, lungime + 1);
        }
    }
}

int main(){
    fin >> n;
    for (int i = 0; i < n; ++i){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for (int i = 1; i <= n; ++i){
        dfs(i, 1);
        for (int j = 1; j <= n; ++j){
            viz[j] = false;
        }
    }
    fout << maxim;
    fin.close();
    fout.close();
    return 0;
}
