#include<bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, maxim, last, x, y;
vector<int> G[100005];

void dfs(int start, int niv = 1, int root = -1){
    if(niv > maxim){
        maxim = niv;
        last = start;
    }
    for(int x : G[start])
        if(x != root)
            dfs(x, niv + 1, start);
}

int main(){
    fin >> n;

    for(int i = 1; i < n; ++i){
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    dfs(1);

    maxim = 0;

    dfs(last);

    fout << maxim;
}
