#include <bits/stdc++.h>
using namespace std;

int n;
vector<int> edges[100100];
int ans = 0, lowest_point, visited[100100];

ifstream fin("darb.in");
ofstream fout(:"darb.out");

void dfs(int x, int parcurgeri) {
    if (parcurgeri > ans) {
        ans = parcurgeri;
        lowest_point = x;
    }
    if (visited[x] == false) {
        visited[x] = true;
        for (int i = 0; i < edges[x].size(); ++i) {
            dfs(edges[x][i], parcurgeri + 1);
        }
    }
}

int main() {
    fin.tie(0);
    ios::sync_with_stdio(0);
    fin >> n;
    for (int i = 1; i <= n - 1; ++i) {
        int x, y;
        fin >> x >> y;
        edges[x].push_back(y);
        edges[y].push_back(x);
    }
    dfs(1, 0);
    ans = 0;
    for (int i = 1; i <= n - 1; ++i) {
        visited[i] = false;
    }
    dfs(lowest_point, 0);
    fout << ans + 1;
    return 0;
}