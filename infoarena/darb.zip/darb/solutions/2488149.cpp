#include <iostream>
#include <set>
#include <fstream>
#include <cstring>
#include <queue>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

set <int> v[100004];
int n;
int uz[100004];
int step;
queue <int> q;

int bfs(int nod){
    q.push(nod);
    uz[nod] = 1;
    step = 1;
    while(!q.empty())
    {
        step++;
        nod = q.front();
        q.pop();
        for(auto i:v[nod])
            if(!uz[i])
            {
                uz[i]=step;
                q.push(i);
            }
    }
    return nod;
}

int main()
{
    int a, b;
    fin>>n;
    for(int i =1; i<n ;i++)
    {
        fin>>a>>b;
        v[a].insert(b);
        v[b].insert(a);
    }
    int k = bfs(1);
    memset(uz, 0, sizeof(uz));
    k = bfs(k);
    fout<<uz[k]-1;

}
