#include <fstream>
#include <vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector <int> v[100005];
int nmax, maxim=-1,viz[100005],a,N;
void dfs(int nod,int d,int tata)
{
   if(d>maxim)
   {
       maxim=d;
       nmax=nod;
   }

   for(int i=0;i<v[nod].size();i++)
   {
       a=v[nod][i];
       if(a!=tata)
        dfs(a,d+1,nod);
   }
}
int main()
{
    int x,y;
    fin>>N;
    for(int i=1;i<N;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1,1,0);
    maxim=-1;
    dfs(nmax,1,0);
    fout<<maxim;
    fin.close();
    fout.close();
    return 0;
}
