#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
const int NMAX = 100005;

int N, dist[NMAX];

vector<int> v[NMAX];

ifstream f("darb.in");
ofstream g("darb.out");

void citire()
{
    int x, y;
    f >> N;
    while(f >> x >> y)
    {
        v[x].push_back(y);
        v[y].push_back(x);
    }
}

int bfs(int nod)
{
    int crt, u;
    queue<int> Q;
    for(int i = 1; i <= N; i++)
        dist[i] = -1;
    dist[nod] = 0;
    Q.push(nod);
    while(!Q.empty())
    {
        crt = Q.front();
        Q.pop();
        u = crt;
        for(const int vec : v[crt])
        {
            if(dist[vec] == -1)
            {
                dist[vec] = dist[crt] + 1;
                Q.push(vec);
            }
        }
    }
    return u;
}

int main()
{
    citire();
    int a, x , y;
    a = 1;
    x = bfs(a);
    y = bfs(x);
    g << dist[y] + 1 << '\n';
    f.close();
    g.close();
    return 0;
}
