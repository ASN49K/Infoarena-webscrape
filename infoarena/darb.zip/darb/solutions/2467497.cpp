#include <fstream>
#include <vector>
#include <cstring>
#define DIM 100005

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n,i,x,y,maxim,last,d[DIM];
bool v[DIM];
vector<int> L[DIM];

void dfs(int nod, int tata)
{
    v[nod] = true; d[nod] = d[tata]+1;
    if (d[nod] > maxim)
    {
        maxim = d[nod];
        last = nod;
    }
    for (int i=0; i<L[nod].size(); i++)
    {
        int vecin = L[nod][i];
        if (!v[vecin])
            dfs(vecin, nod);
    }
}

int main()
{
    fin >> n;
    for (i=1; i<=n; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1, 0); maxim = 0;
    memset(d, 0, n); memset(v, 0, n);
    dfs(last, 0);
    fout << maxim;
    return 0;
}
