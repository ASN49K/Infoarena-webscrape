#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");
int i,j,n,d1[100010],d2[100010],max1,max2,nod,x,y;
vector <int> v[100010];
void dfc1(int k)
{
    for(auto it : v[k])
    {
        if(d1[it]==0)
        {
            d1[it]=d1[k]+1;
            if(d1[it]>max1)
            {
                max1=d1[it];
                nod=it;
            }
            dfc1(it);
        }
    }
}

void dfc2(int k)
{
    for(auto it : v[k])
    {
        if(d2[it]==0)
        {
            d2[it]=d2[k]+1;
            max2=max(max2,d2[it]);
            dfc2(it);
        }
    }
}
int main()
{
    fin>>n;
    for(i=1; i<n; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    d1[1]=1;
    dfc1(1);
    d2[nod]=1;
    dfc2(nod);
    fout<<max2;
    return 0;
}
