#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
const int NMAX = 100001;

int n, dist[NMAX], last, diam;
vector<int> G[NMAX];

ifstream f("darb.in");
ofstream g("darb.out");

void citire()
{
    f >> n;
    for(int i = 1; i <= n; i++)
    {
        int x, y;
        f >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}

void bfs(int nod)
{
    memset(dist, 0, sizeof(dist));
    queue<int> Q;
    dist[nod] = 1;
    Q.push(nod);
    //
    while(!Q.empty())
    {
        nod = Q.front();
        Q.pop();
        //
        for(int & nex : G[nod])
            if(!dist[nex])
            {
                dist[nex] = diam = dist[nod] + 1;
                last = nex;
                Q.push(nex);
            }
    }
}

int main()
{
    citire();
    bfs(1);
    bfs(last);
    g << diam;
    f.close();
    g.close();
    return 0;
}
