#include <bits/stdc++.h>
using namespace std;

const int NMAX = 100005;
vector <int> graf[NMAX];
int n, m, last, drum, bestDrum = 0;
queue <int> coada;
bool fr[NMAX];

void bfs(int i){

    coada.push(i);
    fr[i] = true;

    while(coada.empty() == false){
        int nod = coada.front();
        coada.pop();

        for(size_t i = 0; i < graf[nod].size(); ++i){

            if(fr[graf[nod][i]] == false){
                fr[graf[nod][i]] = true;
                coada.push(graf[nod][i]);
            }

        }
        last = nod;
    }
}

void dfs(int nod) {
    ++drum;
    bestDrum = max(drum, bestDrum);

    fr[nod] = true;
    for(size_t i = 0; i < graf[nod].size(); ++i)
        if(fr[graf[nod][i]] == false)
            dfs(graf[nod][i]);

    --drum;
}

int main() {
    //ifstream fin("date.in");
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    fin >> n;

    for(int i = 1; i <= n; ++i){
        int a, b;
        fin >> a >> b;
        graf[a].push_back(b);
        graf[b].push_back(a);
    }
    bfs(1);

    for(int i = 0; i < NMAX; ++i)
        fr[i] = false;

    dfs(last);

    fout << bestDrum;

    return 0;
}
