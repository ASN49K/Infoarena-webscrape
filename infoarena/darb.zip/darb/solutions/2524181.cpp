#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector <int> h[100005];
int viz[100005], d[100005];
int n, m;
void Dfs(int k)
{
    viz[k] = 1;
    for(auto i : h[k])
        if(!viz[i])
        {
            viz[i] = 1;
            d[i] = d[k] + 1;
            Dfs(i);
        }
}
void Read()
{
    int i,x,y;
    fin >> n;
    for(i = 1 ; i <= n - 1; i ++)
    {
        fin >> x >> y;
        h[x].push_back(y);
        h[y].push_back(x);
    }
}
int main()
{
    int nod, M, i;
    Read();
    Dfs(1);
    M = 0;
        for(i = 1 ; i <= n ; i++ )
    {
        viz[i] = 0;
        if(d[i] > M)
        {
            M = d[i];
            nod = i;
        }
        d[i] = 0;
    }
    Dfs(nod);
    M = 0;
    for(i = 1; i <= n ; i ++)
        if(d[i] > M)  M = d[i];
        fout << M + 1;
fin.close();
fout.close();
        return 0;
}
