#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <queue>
#include <algorithm>
#define inmat lin >= 1 && lin <= n && col >= 1 && col <= n

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

const int N = 1e5+1;

int n;

vector<vector<int>> v(N,vector<int>());
queue <int> Q;
unordered_map <int, int> lung;


void bfs()
{
	int nod , maxi = -1 , capat = 0;
	Q.push(1);
	lung[1] = 1;
	while (!Q.empty())
	{
		nod = Q.front();
		Q.pop();
		if (lung[nod] > maxi)
		{
			maxi = lung[nod];
			capat = nod;
		}
		for (auto i : v[nod])
		{
			if (lung[i] == 0) {
				lung[i] = lung[nod] + 1;
				Q.push(i);
			}
		}
	}
	Q.push(capat);
	for (int i = 1; i <= n; i++)
		lung[i] = 0;
	lung[capat] = 1;
	while (!Q.empty())
	{
		nod = Q.front();
		Q.pop();
		if (lung[nod] > maxi)
		{
			maxi = lung[nod];
			capat = nod;
		}
		for (auto i : v[nod])
		{
			if (lung[i] == 0) {
				lung[i] = lung[nod] + 1;
				Q.push(i);
			}
		}
	}
	out << maxi;
}

int main()
{
	in >> n;
	int l1, l2;
	for (int i = 1; i <= n; i++) {
		in >> l1 >> l2;
		v[l1].push_back(l2);
		v[l2].push_back(l1);
	}
	bfs();
}