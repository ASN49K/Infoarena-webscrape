#include <bits/stdc++.h>

using namespace std;


const int MAX_N = 1e5;

vector <int> gr[1 + MAX_N];

int max_depth[1 + MAX_N];

int ans;

void upd_ans (int &a, int b) {
    if (a < b)
        a = b;
}
void dfs_depth (int node, int par) {
    max_depth[node] = 0;
    for (int son : gr[node])
        if (son != par) {
            dfs_depth (son, node);
            upd_ans (ans, max_depth[node] + max_depth[son] + 1);
            upd_ans (max_depth[node], max_depth[son] + 1);
        }
}

int main() {
    freopen ("darb.in", "r", stdin);
    freopen ("darb.out", "w", stdout);
    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);
    int n;
    cin >> n;
    for (int i = 2; i <= n; i++) {
        int x, y;
        cin >> x >> y;
        gr[x].push_back (y);
        gr[y].push_back (x);
    }
    ans = 0;
    dfs_depth (1, -1);
    cout << ans + 1 << "\n";
    return 0;
}
