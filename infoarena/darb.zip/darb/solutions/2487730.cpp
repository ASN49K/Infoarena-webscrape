#include <bits/stdc++.h>
#define NMAX 100001
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector<int> adiac[NMAX];
deque<int> NU;
int resultingNode,maxi=0;
bool visited[NMAX];
void DFS(int node,int dist){

    visited[node]=1;
    if(dist>maxi){
        maxi=dist;
        resultingNode=node;
    }
    for(int i=0;i<adiac[node].size();i++){
        if(visited[adiac[node][i]]==0)
            DFS(adiac[node][i],dist+1);
    }
}
int main()
{
    int n,m,i,x,y;
    fin>>n>>m;
    for(i=1;i<=n;i++){
        fin>>x>>y;
        adiac[x].push_back(y);
        adiac[y].push_back(x);
    }
    DFS(1,0);
    maxi=0;
    memset(visited,0,sizeof(visited));
    DFS(resultingNode,0);
    fout<<maxi+1;
    return 0;
}
