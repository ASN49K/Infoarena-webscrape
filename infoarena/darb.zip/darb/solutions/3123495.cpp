#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int maxn = 1e5;
vector<int> adj[maxn + 1];
bool visited[maxn + 1];

int dfs(int node, int &last) {
    last = node;
    int ans = 0;
    for (int child: adj[node])
        if (!visited[child]) {
            visited[child] = true;
            ans = max(ans, dfs(child, last));
        }
    return ans + 1;
}

int main() {
    int n;
    fin >> n;
    for (int i = 1; i < n; i++) {
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    int last, aux;
    int a = dfs(1, last);
    int b = dfs(last, aux);
    fout << a + b << '\n';

    return 0;
}