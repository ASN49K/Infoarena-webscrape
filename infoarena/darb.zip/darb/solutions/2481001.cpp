#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fi ("darb.in");
ofstream fo ("darb.out");
vector<int> vecini[1000005];
int raspuns[100005],lant[100005],n;
void dfs(int nod_curent, int parinte)
{
    int max1=0, max2=0;
    lant[nod_curent]=1;
    raspuns[nod_curent]=1;
    for(int i=0;i<vecini[nod_curent].size();i++)
    {
        int nod_urmator=vecini[nod_curent][i];
        if(nod_urmator!=parinte)
        {
            dfs(nod_urmator,nod_curent);
            lant[nod_curent]=max(lant[nod_curent],lant[nod_urmator]+1);
            raspuns[nod_curent]=max(raspuns[nod_curent],raspuns[nod_urmator]);
            if(lant[nod_urmator]>max1)
            {
                max2=max1;
                max1=lant[nod_urmator];
            }
            else
            {
                if(lant[nod_urmator]>max2)
                    max2=lant[nod_urmator];
            }
        }
    }
    raspuns[nod_curent]=max(raspuns[nod_curent],max1+max2+1);
}
int main()
{
    fi>>n;
    for(int i=1;i<n;i++)
    {
        int a,b;
        fi>>a>>b;
        vecini[a].push_back(b);
        vecini[b].push_back(a);
    }
    dfs(1,-1);
    fo<<raspuns[1];
    fi.close();
    fo.close();
    return 0;
}
