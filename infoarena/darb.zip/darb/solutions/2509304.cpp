#include <fstream>

using namespace std;
ifstream fin ("darb.in");
ofstream fout ("darb.out");

int hm[10005][10005], viz[100005], n, m, vf, x, y, i, u, s, of[100005], t, ta;
void dfs(int k, int tata);

int main()
{
    fin>>n;
    while (fin>>x>>y)
    {

        hm[x][y]=hm[y][x]=1;
        s=x;
        ta=y;
    }
    viz[s]=1;
    dfs(s, ta);
    for (i=1; i<=n; i++)
    {
        viz[i]=0;
        of[i]=0;
    }
    viz[u]=1;
    of[t]=1;
    dfs(u, t);
    fout<<of[u]<<'\n';

    return 0;
}
void dfs (int k, int tata)
{
    int i;
    u=k;
    t=tata;
    of[k]=of[tata]+1;
    for (i=1; i<=n; i++)
        if ((hm[i][k]==1) && (viz[i]==0))
        {
            viz[i]=1;
            dfs(i, k);
        }
}
