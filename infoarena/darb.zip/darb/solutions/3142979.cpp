#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, ultim, diametru, dist[100001];
vector<int> gf[100001];

void BFS(int x) {
    for (int i = 1; i <= n; i++)
        dist[i] = 0;
    queue<int> q;
    dist[x] = 1;
    q.push(x);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (int i : gf[nod])
            if (!dist[i]) {
                dist[i] = dist[nod] + 1;
                q.push(i);
            }
    }
    for (int i = 1; i <= n; i++)
        if (diametru < dist[i])
            diametru = dist[i], ultim = i;
}

int main()
{
    fin >> n;
    for (int i = 1; i <= n - 1; i++) {
        int x, y;
        fin >> x >> y;
        gf[x].push_back(y);
        gf[y].push_back(x);
    }
    BFS(1);
    BFS(ultim);
    fout << diametru;
    return 0;
}
