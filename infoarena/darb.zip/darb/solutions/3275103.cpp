#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
const int NMAX=100000;
vector<int>L[NMAX+10];
int n,x,y,viz[NMAX+10],maxim,nodulet;

void BFS(int nod) {
    queue<int>Q;
    Q.push(nod);
    viz[nod]=1;
    while(!Q.empty()) {
        int k=Q.front();
        Q.pop();
        for(const auto &p:L[k]) {
            if(viz[p]==0) {
                Q.push(p);
                viz[p]=1+viz[k];
            }
        }
    }
}


int main() {
    f>>n;
    while(f>>x>>y) {
        L[x].push_back(y);
        L[y].push_back(x);
    }
    BFS(1);
    for(int i=1; i<=n; i++) {
        if(viz[i]>maxim) {
            maxim=viz[i];
            nodulet=i;
        }
        viz[i]=0;
    }
    BFS(nodulet);
    for(int i=1; i<=n; i++) {
        maxim=max(maxim,viz[i]);
    }
    g<<maxim;
    f.close();
    g.close();
    return 0;
}
