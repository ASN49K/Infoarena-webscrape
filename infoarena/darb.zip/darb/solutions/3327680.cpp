#include<bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n;
vector<int> G[100001];
int ultim, dist[100001];

void bfs(int nod) {
    queue<int> Q;
    Q.push(nod);
    dist[nod] = 1;

    while (!Q.empty()) {
        int Nod = Q.front();
        ultim = Nod;
        Q.pop();
        for (auto vecin: G[Nod]) {
            if (!dist[vecin]) {
                dist[vecin] = dist[Nod] + 1;
                Q.push(vecin);
            }
        }
    }
}

int main()
{
    fin >> n;
    for (int i = 1; i<n; i++) {
        int x,y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    bfs(1);
    for (int i = 1; i<=n; i++) dist[i] = 0;
    bfs(ultim);
    int maxim = 0;
    for (int i = 1; i<=n; i++) {
        maxim = max(maxim, dist[i]);
    }
    fout << maxim;

    return 0;
}
