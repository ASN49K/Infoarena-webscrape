#include<bits/stdc++.h>
using namespace std;
#define pb push_back

ifstream fin("darb.in"); ofstream fout("darb.out");



int n, m, v;
vector<vector<int> > g;



void dfs(int s, int p){
if(p+1>m){v=s; m=p+1;}
for(auto i=g[s].begin(); i!=g[s].end(); i++){
    
    dfs(*i, p+1);

}

}






int main(){
fin>>n;

g.resize(n+5);


int n1, n2;

for(int i=1; i<n; i++){
fin>>n1>>n2;
g[n1].pb(n2);
}



dfs(1, 1);
dfs(v, 1);
fout<<m<<"\n";

    return 0;
} 