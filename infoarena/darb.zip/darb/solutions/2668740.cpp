#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int max_up = 1e5 + 5;

vector <int> g[max_up];
vector <bool> visited(max_up, false);
vector <int> lvl(max_up);

void dfs(int u)
{
    visited[u] = true;
    for(auto v : g[u]){
        if(!visited[v]) {
            lvl[v] = lvl[u] + 1;
            dfs(v);
        }
    }
}

int main()
{
    int n; fin >> n;
    for(int i = 1; i < n; ++i){
        int u, v; fin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    lvl[1] = 1;
    dfs(1);
    int maxim = 0, max_i = 0;
    for(int i = 1; i <= n; i++){
        if(maxim < lvl[i]){
            maxim = lvl[i];
            max_i = i;
        }
        lvl[i] = 0;
        visited[i] = false;
    }
    lvl[max_i] = 1;
    dfs(max_i);
    maxim = 0;
    for(int i = 1; i <= n; i++)
        maxim = max(maxim, lvl[i]);
    fout << maxim ;

    return 0;
}
