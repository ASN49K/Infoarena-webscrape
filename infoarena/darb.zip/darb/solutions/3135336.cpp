#include<bits/stdc++.h>
#define mare 1e9
#define mod 1000000007
#define bit(x,i)(((x)>>(i))&1)
#define FAST ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
/*
211 D
long long int T,n,m,k,x,y,i,j,c,aux,maxx,minn,contor,suma,poz;
vector<int> G[200005];
bool viz[200005];
void dfs1(int k)
{
    for(int l=0;l<G[k].size();l++)
    {
        if(!viz[G[k][l]])
        {
            viz[G[k][l]]=1;
            c++;
            if(G[k][l]==n)
            {
                if(c<minn)
                    minn=c;
            }
            dfs1(G[k][l]);
            c--;
            viz[G[k][l]]=0;
        }
    }
}
void dfs2(int k)
{
    for(int l=0;l<G[k].size();l++)
    {
        if(!viz[G[k][l]])
        {
            viz[G[k][l]]=1;
            c++;
            if(G[k][l]==n)
            {
                if(c==minn)
                    contor++;
            }
            dfs2(G[k][l]);
            viz[G[k][l]]=0;
            c--;
        }
    }
}
int main()
{
    FAST
    cin>>n>>m;
    minn=200005;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    c=0;
    dfs1(1);
    c=0;
    dfs2(1);
    cout<<contor;
    return 0;
}*/
long long int T,n,m,ok,x,y,i,j,c,aux,start,maxx,minn;
long long int st,dr,mij,contor,suma,poz;
long long int viz[100005],metro[100005];
vector<int> G[100005];
/*void dfs2(long long int nod)
{
    for(int l=0;l<G[nod].size();l++)
    {
        if(!viz[G[nod][l].first])
        {
            c=c+G[nod][l].second;
            viz[G[nod][l].first]=1;
            if(c<minn && metro[G[nod][l].first])
                minn=c;
            int auxx=c;
            cout<<"intram in "<<G[nod][l].first<<" cu "<<auxx<<"\n";
            dfs2(G[nod][l].first);
            cout<<"revenim in "<<G[nod][l].first<<" cu "<<auxx<<"\n";

            viz[G[nod][l].first]=0;
            c=auxx-G[nod][l].second;
        }
    }
}*/
void dfs(long long int k)
{
    for(int l=0;l<G[k].size();l++)
    {
        if(!viz[G[k][l]])
        {
            c++;
            viz[G[k][l]]=1;
            if(G[G[k][l]].size()==1)
            {
                if(c>maxx)
                {
                    maxx=c;
                    poz=G[k][l];
                }
            }
            dfs(G[k][l]);
            c--;
        }
    }
}
void dfs1(long long int k)
{
    for(int l=0;l<G[k].size();l++)
    {
        if(!viz[G[k][l]])
        {
            c++;
            viz[G[k][l]]=1;
            if(G[G[k][l]].size()==1)
            {
                if(c>maxx)
                {
                    maxx=c;
                    poz=G[k][l];
                }
            }
            dfs1(G[k][l]);
            c--;
        }
    }
}
int main()
{
    fin>>n;
    for(i=1;i<n;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    c=1;
    maxx=-1000000000*n;
    dfs(1);
    c=1;
    maxx=-1000000000*n;
    dfs1(poz);
    fout<<maxx;
    return 0;
}
