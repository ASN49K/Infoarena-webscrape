#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("darb.in");
ofstream cout("darb.out");

const int MAX = 1e5 + 1;

int n , x , y ;

vector <int> g[MAX];

bool viz[MAX];

queue <int> q;

int level[MAX];

int last = 0;

int main(){

    cin >> n;

    for(int i = 1 ; i < n ; i++){

        cin >> x >> y;

        g[x].push_back(y);
        g[y].push_back(x);
    }

    q.push(1);

    while(!q.empty()){

        x = q.front();

        viz[x] = 1;

        last = x;

        q.pop();

        for(auto it : g[x]){

            if(!viz[it]) q.push(it);
        }
    }

    q.push(last);

    level[last] = 1;

    while(!q.empty()){

        x = q.front();
        q.pop();

        last = x;

        for(auto it : g[x]){

            if(!level[it]){

                level[it] = level[x] + 1;

                q.push(it);
            }
        }
    }

    cout << level[last];

    return 0;
}
