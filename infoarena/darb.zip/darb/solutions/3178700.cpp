#include <fstream>
#include <vector>
#include <cstring>
#define sz 100000
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");


int n;

bool viz[sz + 5];
vector <int> v[sz+5];


int lmax;
int nodmax;
int lv;

void dfs1(int nod)
{
    lv++;
    if(lv > lmax)
        lmax=lv,nodmax=nod;
    viz[nod]=true;
    for(auto& i : v[nod])
        if(!viz[i])
            dfs1(i);
    lv--;
}
void dfs(int nod)
{
    lv++;
    if(lv >lmax)
        lmax=lv;
    viz[nod]=true;
    for(auto& i : v[nod])
        if(!viz[i])
            dfs(i);
    lv--;
}


int main()
{
    fin>>n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs1(1);
    memset(viz,0,sizeof(viz));
    dfs(nodmax);
    fout<<lmax;
}

