#include<fstream>
#include<vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n,m,a,b,i,j,nr,k,fiu,t,minim;
vector<int>L[16005];
int sol[16005],D[16005],v[16005],maxim[16005];
void dfs(int nod){
    sol[nod]=1;
    D[nod]=1;
    for(int i=0;i<L[nod].size();i++){
        int fiu=L[nod][i];
        if(sol[fiu]==0){
            dfs(fiu);
            if(1+D[fiu]>=D[nod]){
                D[nod]=1+D[fiu];
                maxim[nod]=fiu;
            }
        }
    }
}
int main(){
    fin>>n;
    for(i=1;i<n;i++){
        fin>>a>>b;
        L[a].push_back(b);
        L[b].push_back(a);
    }
    dfs(5);
    int t=1;
    while(maxim[t]!=0){
        t=maxim[t];
    }
    for(i=1;i<=n;i++){
        sol[i]=0;
        D[i]=0;
        maxim[i]=0;
    }
    dfs(t);
    int q=t;
    int k=1;
    while(maxim[q]!=0){
        q=maxim[q];
        k++;
    }
    fout<<k;
    return 0;
}
