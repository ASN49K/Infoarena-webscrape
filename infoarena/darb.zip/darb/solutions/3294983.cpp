#include <bits/stdc++.h>

using namespace std;

ifstream f ("darb.in");
ofstream g ("darb.out");

const int nmax = 100000;
vector <int> vecini[nmax + 5];
int d[nmax + 5];

void calcul(int nod, int parinte)
{
    int i;
    for(i = 0; i < vecini[nod].size(); ++i)
    {
        int newnod = vecini[nod][i];
        if(newnod != parinte)
        {
            d[newnod] = 1 + d[nod];
            calcul(newnod, nod);
        }
    }
}

bool comp(int a, int b)
{
    return a > b;
}

int main()
{
    int n, i, x, y;
    f >> n;
    for(i = 1; i < n; ++i)
    {
        f >> x >> y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
    d[1] = 0;
    calcul(1, 0);
    int maxim = 0, curent = 1;
    for(i = 2; i <=n; ++i)
    {
        if(d[i] > maxim)
        {
            curent = i;
            maxim = d[i];
        }
    }
    d[curent] = 0;
    calcul(curent, 0);
    maxim = 0;
    for(i = 1; i <= n; ++i)
    {
        if(d[i] > maxim)
            maxim = d[i];
    }
    g << maxim + 1;
    return 0;
}
