#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int NMAX = 1e5 + 5;
vector<int> g[NMAX];
int d[NMAX];

void dfs(int curr, int prv) {
    for (auto nod : g[curr]) {
        if (nod != prv) {
            d[nod] = d[curr] + 1;
            dfs(nod, curr);
        }
    }
}

int main() {

    int n;
    fin >> n;
    for (int i = 1; i <= n - 1; i++) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    dfs(1, 0);
    int nod = 0;
    for (int i = 1; i <= n; i++) {
        if (d[nod] < d[i])
            nod = i;
    }

    memset(d, 0, sizeof(d));
    dfs(nod, 0);

    nod = 0;
    for (int i = 1; i <= n; i++) {
        if (d[nod] < d[i])
            nod = i;
    }

    fout << d[nod] + 1;

    return 0;
}
