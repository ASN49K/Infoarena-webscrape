#include <bits/stdc++.h>

using namespace std;

vector <int> fii[100002];
int n,rasp,dist[100002],ma;

void dfs(int nod, int par)
{
    for(auto it:fii[nod])//for(int i = 0; i < fii[nod].size();++i) it e echivalent la fii[nod][i]
    {
        if(it!=par)
        {
            dist[it]=dist[nod]+1;
            dfs(it,nod);
        }
    }
    if(dist[nod] > ma)
    {
        ma = dist[nod];
        rasp = nod;
    }
}

int main()
{

    FILE* si=fopen("darb.in","r");
    FILE* so=fopen("darb.out","w");

    fscanf(si,"%d",&n);
    for(int i=1; i<n; i++)
    {
        int a,b;
        fscanf(si,"%d%d",&a,&b);
        fii[a].push_back(b);
        fii[b].push_back(a);
    }
    dfs(1,0);
    ma = 0;
    for(int i=1; i<=n; i++)
    {
        dist[i] = 0;
    }
    dfs(rasp,0);
    fprintf(so,"%d",ma+1);

    fclose(si);
    fclose(so);

    return 0;
}
