#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const string filename = "darb";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

const int maxN = 100005;
int n, depth[maxN], capat;
vector <int> G[maxN];

void dfs(int nod, int tata = 0)
{
    depth[nod] = depth[tata] + 1;
    if(depth[nod] > depth[capat])
        capat = nod;
    for(int vecin : G[nod])
        if(vecin != tata)
            dfs(vecin, nod);
}

int main()
{
    fin >> n;
    for(int x, y, i = 1; i < n; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    dfs(1);
    dfs(capat);
    fout << depth[capat];
    return 0;
}
