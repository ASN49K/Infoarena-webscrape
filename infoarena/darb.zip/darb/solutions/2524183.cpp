#include <fstream>
#include <vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int viz[100005], n, m;
vector < int > h[100005];

void DFS(int k)
{
    for(auto i : h[k])
        if(!viz[i])
        {
            viz[i] = 1 + viz[k];
            DFS(i);
        }
}

int main()
{
    int M = 0, p, x, y;
    fin >> n;
    while(fin >> x >> y)
    {
        h[x].push_back(y);
        h[y].push_back(x);
    }
    fin.close();
    viz[1] = 0;
    DFS(1);
    for(int i = 1; i <= n; i++)
    {
        if(viz[i] > M)
        {
            p = i;
            M = viz[i];
        }
    }
    for(int i = 1; i <= n; i++)
        viz[i] = 0;
    viz[p] = 0;
    DFS(p);
    M = 0;
    for(int i = 1; i <= n; i++)
        M = max(viz[i], M);
    fout << 1 + M << "\n";
    fout.close();
    return 0;
}
