#include<iostream>
#include<fstream>
#include<vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector <int> V[10000];
int viz[10000],n,mx,d;
void DFS(int no, int di)
{
    if(di>d)
        d=di;
    viz[no]=1;
    for(unsigned int i=0;i<V[no].size();i++)
    {
        if(viz[V[no][i]]==0)
            DFS(V[no][i],di+1);
    }
    viz[no]=0;
}
int main()
{
    fin>>n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        fin>>x>>y;
        x--;
        y--;
        V[x].push_back(y);
        V[y].push_back(x);
    }
    for(int i=0;i<n;i++)
        DFS(i,0);
    fout<<d+1;
}
