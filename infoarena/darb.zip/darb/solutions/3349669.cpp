#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");
const int NMAX = 100000;

vector <int> A[NMAX + 5];
int dist[NMAX + 5];
int n;

void calc(int nod, int tata)
{
    int i;
    for(i = 0; i < A[nod].size(); i++)
    {
        int newn = A[nod][i];
        if(newn != tata)
        {
            dist[newn] = 1 + dist[nod];
            calc(newn, nod);
        }
    }
}

int main()
{
    int x, y, maxi, crt;
    f >> n;
    for(int i = 1; i < n; i++)
    {
        f >> x >> y;
        A[x].push_back(y);
        A[y].push_back(x);
    }
    dist[1] = 0;
    calc(1, 0);
    //
    for(int i = 2; i <= n; i++)
    {
        if(dist[i] > maxi)
        {
            crt = i;
            maxi = dist[i];
        }
    }
    dist[crt] = 0;
    calc(crt, 0);
    maxi = 0;
    for(int i = 1; i <= n; i++)
    {
        if(dist[i] > maxi)
            maxi = dist[i];
    }
    g << maxi + 1;
    f.close();
    g.close();
    return 0;
}
