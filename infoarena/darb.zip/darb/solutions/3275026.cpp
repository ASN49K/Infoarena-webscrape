#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
#define cin fin
ofstream fout("darb.out");
#define cout fout
int n,m,a[101][101],c[101],viz[101],p,u,M,b[101][101],kc,k;

void BFS(int pr){
    u=1;p=1;c[p]=pr; viz[pr]=1;b[pr][pr]=0;
    while(p<=u){
        int x=c[p++];
        for(int i=1;i<=n;i++){
            if(a[x][i]&&!viz[i]){
                c[++u]=i;
                viz[i]=1;
                b[pr][i]=b[pr][x]+1;

            }
        }
}
}

int main()
{
    cin>>n;
    int x,y;
    while(cin>>x>>y){
        a[x][y]=a[y][x]=1;
    }

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            viz[j]=0;
            b[i][j]=9999;
        }
        BFS(i);

    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            if(b[i][j]!=9999&&b[i][j]>M) M=b[i][j];
    }
    cout<<M+1;
    return 0;
}
