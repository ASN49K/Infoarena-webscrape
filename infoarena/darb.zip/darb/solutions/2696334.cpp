#include <bits/stdc++.h>

using namespace std;
ifstream f("darb.in");
ofstream o("darb.out");

int N,last,sol,n,cost[100010];;
vector<int> a[100010];
queue<int> que;



void bfs(int p)
{
    memset(cost, 0, sizeof(cost));
    que.push(p);
    cost[p] = 1;


    while(!que.empty())
    {
        int x = que.front();
        for(auto i : a[x])
        {
            if(!cost[i])
            {
                que.push(i);
                cost[i] = cost[x] + 1;
                sol = cost[i];
                last = i;

            }
        }
        que.pop();
    }
}


int main()
{
    //doua bfs uri
    f>>n;
    int x,y;
    for(int i=1;i<=n;i++)
    {
        f>>x>>y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    bfs(1);
    bfs(last);
    o<<sol<<"\n";
    return 0;
}
