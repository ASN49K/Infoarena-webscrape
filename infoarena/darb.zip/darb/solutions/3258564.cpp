#include <bits/stdc++.h>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

int p, q, r, n, x, y, viz[101], k, dis[101], ma=-9999, mx, ma2=-9999, mx2;
vector <int> v[101];

void dfs(int cr)
{
    viz[cr]=1;
    for(int i:v[cr])
    {
        if(!viz[i])
        {
            dis[i]=dis[cr]+1;
            dfs(i);
        }
    }
}

int main()
{
    f>>n;
    for(int i=1; i<n; i++)
    {
        f>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dis[1]=1;
    dfs(1);
    for(int i=1; i<=n; i++)
        if(dis[i]>ma)
        {
            ma=dis[i];
            mx=i;
        }
    for(int i=1; i<=n; i++)
        dis[i]=0;
    dis[mx]=1;
    dfs(mx);
    for(int i=1; i<=n; i++)
    {
        if(dis[i]>ma2)
        {
            ma2=dis[i];
        }
    }
    g<<ma+ma2;
    return 0;
}
