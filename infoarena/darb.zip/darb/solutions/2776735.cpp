#include <bits/stdc++.h>
#define MAXN 100001
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector<int> g[MAXN];
int dist[MAXN];
void bfs(int i){
   queue<int> q;
   q.push(i);
   int copy=i;
   while(!q.empty()){
       i=q.front();
       for(int j=0; j<g[i].size(); j++){
          if(dist[g[i][j]]==0){
            dist[g[i][j]]=dist[i]+1;
            q.push(g[i][j]);
          }
       }
       q.pop();
   }
   dist[copy]=0;
}
int main()
{
    int n, hi=0, newTarget; fin>>n;
    for(int i=1; i<n; i++){
       int x, y; fin>>x>>y;
       g[x].push_back(y);
       g[y].push_back(x);
    }
    bfs(1);
    for(int i=1; i<=n; i++){
        if(dist[i]>hi){
           hi=dist[i];
           newTarget=i;
        }
    }
    memset(dist, 0, sizeof(dist));
    bfs(newTarget);
    hi=0;
    for(int i=1; i<=n; i++){
        if(dist[i]>hi){
           hi=dist[i];
        }
    }
    fout<<hi+1;
    return 0;
}
