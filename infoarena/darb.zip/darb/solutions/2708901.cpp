#include <iostream>
#include <vector>
using namespace std;
/*ifstream in("darb.in");
ofstream out("darb.out");*/
int const N=100001;
int viz[N], sf, inc, coada[N], x, y, n, maxim, imax1, imax2;
vector <int> lista[N];
int d[N];
void bfs(int nod)
{
    int i;
    viz[nod]=1;
    sf=inc=1;
    coada[inc]=nod;
    d[nod]=1;
    while(inc<=sf)
    {
        for(i=0; i<lista[coada[inc]].size(); i++)
        {
            if(viz[lista[coada[inc]][i]]==0)
            {
                sf++;
                coada[sf]=lista[coada[inc]][i];
                viz[lista[coada[inc]][i]]=1;
                d[coada[sf]]=d[coada[inc]]+1;
            }
        }
        inc++;
    }
}

int main()
{
    int i;
    cin>>n;
    for(i=1; i<=n-1; i++)
    {
        cin>>x>>y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }
    bfs(1);
    for(i=1; i<=n; i++)
        if(d[i]>maxim)
        {
            maxim=d[i];
            imax1=i;
        }
    for(i=1; i<=n; i++)
        viz[i]=0;
    bfs(imax1);
    maxim=0;
    for(i=1; i<=n; i++)
        if(d[i]>maxim)
        {
            maxim=d[i];
            imax2=i;
        }
    cout<<maxim;
    return 0;
}
