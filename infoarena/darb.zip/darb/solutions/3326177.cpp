#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int N = 100001;

vector<int> g[N];
int vizitat[N];
int sol;

int dp[N];

void dfs(int nod){
    vizitat[nod] = 1;
    vector<int> fii;
    dp[nod] = 1;
    for (int x : g[nod])
    {
        if(!vizitat[x]){
            dfs(x);
            dp[nod] = max(dp[nod], dp[x] + 1);
            fii.push_back(dp[x]);
        }
    }

    sort(fii.begin(), fii.end(), greater<int>());

    sol = max(sol, dp[nod]);

    if(fii.size() > 1){
        sol = max(sol, fii[0]+fii[1] + 1);
    }
}

int main (){
    int n;
    fin >> n;

    for (int i = 1; i <= n-1; i++){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    dfs(1);

    fout << sol;
}
