#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int NMAX=1e5+5;

vector<int>v[NMAX];
queue<int>q;
queue<int>q2;
bool viz[NMAX];
int dist[NMAX];

int maxi;
bool farest;
int leaf;

void dfs(int p,int tata)
{
    bool ok=true;
    for(auto i:v[p])
    {
        if(i!=tata)
        {
            ok=false;
            dfs(i,p);
        }
    }
    q2.push(p);
}

void bfs(int p)
{
    dist[p]=1;
    maxi=1;
    viz[p]=true;
    q.push(p);
    while(!q.empty())
    {
        int p=q.front();
        q.pop();
        for(auto i:v[p])
        {
            if(!viz[i])
            {
                viz[i]=true;
                dist[i]=dist[p]+1;
                maxi=max(maxi,dist[i]);
                q.push(i);
            }
        }
    }
}

int main()
{
    int n,m,i,j;
    fin>>n;
    for(i=1;i<n;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1,0);
    leaf=q2.front();
    bfs(leaf);
    fout<<maxi;
    return 0;
}
