#include <iostream>
#include <vector>
using namespace std;
const int NMAX = 1e5 + 5;
vector<int> adj[NMAX];
int ma, newnod;
bool vis[NMAX];
void dfs(int nod, int lung)
{
	vis[nod] = 1;
	for(auto &it : adj[nod])
	{
		if(!vis[it]) dfs(it, lung + 1);
	}
	if(lung > ma) 
	{
		ma = lung;
		newnod = nod;
	}
}

int main()
{
	(void)! freopen("darb.in", "r", stdin);
	(void)! freopen("darb.out", "w", stdout);
	int n, x, y; cin >> n;
	for(int i = 1; i < n; ++ i)
	{
		cin >> x >> y;
		adj[x].push_back(y), adj[y].push_back(x);	
	}
	dfs(1, 1);
	for(int i = 1; i <= n; ++i) vis[i] = 0;
	dfs(newnod, 1);
	cout << ma;
	return 0;
}
