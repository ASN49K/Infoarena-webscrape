#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("darb.in");
ofstream fout ("darb.out");
int maxc,poz,i,n,y,x,pozi,viz[100001];
vector <int> v[100001];
void dfs (int nod,int niv)
{
    viz[nod]=1;
    if (niv>maxc)
    {
        maxc=niv;
        poz=nod;
    }
    for (int i=0; i<v[nod].size (); i++)
    {
        int vecin=v[nod][i];
        if (viz[vecin]==0)
            dfs (vecin,niv+1);
    }
}
int main()
{
    fin>>n;
    for (i=1; i<n; i++)
    {
        fin>>x>>y;
        v[x].push_back (y);
        v[y].push_back (x);
    }
    dfs (1,1);
    pozi=poz;
    poz=maxc=0;
    for (i=1; i<=n; i++)
        viz[i]=0;
    dfs (pozi,1);
    fout<<maxc;
    return 0;
}
