#include <fstream>
#include <vector>
#include <cstring>
#include <stdlib.h> /* srand, rand */
#include <time.h>   /* time */
#define MAX_NODES 100000
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int> tree[MAX_NODES + 1];
int distances[MAX_NODES + 1], visited[MAX_NODES + 1], diameter, last_node;

void compute_distance(int current) {
    last_node = current;
    visited[current] = 1;
    for (int &adjacent_node : tree[current]) {
        if (!visited[adjacent_node]) {
            distances[adjacent_node] = distances[current] + 1;
            if (distances[adjacent_node] > diameter) {
                diameter = distances[adjacent_node];
            }
            compute_distance(adjacent_node);
        }
    }
}

int main() {
    srand(time(NULL)); /* initialize random seed: */
    int nr_nodes, node_a, node_b;
    fin >> nr_nodes;
    for (int i = 0; i < nr_nodes; ++i) {
        fin >> node_a >> node_b;
        tree[node_a].push_back(node_b);
        tree[node_b].push_back(node_a);
    }
    int start_node = rand() % nr_nodes;
    compute_distance(start_node);
    memset(distances, 0, sizeof(distances));
    memset(visited, 0, sizeof(visited));
    diameter = 0;
    compute_distance(last_node);
    fout << diameter + 1;
    return 0;
}