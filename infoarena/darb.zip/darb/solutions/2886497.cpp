#include <fstream>
#include <vector>

using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
vector<int>adj[200005];
int biggest[200005];
int maxim=0;
void dfs(int curr,int par)
{
    int i,k,second=0;
    for(i=0; i<adj[curr].size(); i++)
    {
        k=adj[curr][i];
        if(k!=par)
        {
            dfs(k,curr);
            if(biggest[k]+1>=biggest[curr])
            {
                second=biggest[curr];
                biggest[curr]=biggest[k]+1;
            }
            else if(biggest[k]+1>second)
            {
                second=biggest[k]+1;
            }
        }
    }
    maxim=max(maxim,biggest[curr]+second-1);
    if(adj[curr].size()==1 && curr!=1)
    {
        biggest[curr]=1;
    }
    return;
}
int main()
{
    int n,i,j,a,b;
    cin>>n;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    for(i=1; i<n; i++)
    {
        cin>>a>>b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    dfs(1,0);
    maxim=max(maxim,biggest[1]);
    cout<<maxim;
    return 0;
}
