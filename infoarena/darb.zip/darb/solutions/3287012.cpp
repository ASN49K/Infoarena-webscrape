#include <bits/stdc++.h>
using namespace std;

const int MAX = 100005;
int target, maxim, visited[MAX];
vector<int> graph[MAX];

void dfs(int node, int dist)
{
    visited[node] = 1;
    for (int next : graph[node])
        if (!visited[next])
            dfs(next, dist+1);

    if (dist > maxim)
    {
        maxim = dist;
        target = node;
    }
}

int main()
{
    ifstream cin("darb.in");
    ofstream cout("darb.out");
    int n;
    cin >> n;
    for (int i = 1; i < n; ++i)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    dfs(1, 1);

    for (int i = 1; i <= n; ++i)
        visited[i] = 0;

    maxim = 0;
    dfs(target, 1);
    cout << maxim;

    return 0;
}
