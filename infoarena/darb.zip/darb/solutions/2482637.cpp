#include <bits/stdc++.h>
using namespace std;
ifstream in("darb.in");
ofstream out("darb.out");
const int N=1e5+2;
int n,i,x,y,m,pos,maxx;
int f[N],d[N];
vector<int>G[N];
void DFS(int x)
{
    f[x]=1;
    for(i=0; i<G[x].size(); i++)
        if(f[G[x][i]]==0)
        {
            d[G[x][i]]=d[x]+1;
            if(d[G[x][i]]>maxx) maxx=d[G[x][i]],pos=G[x][i];
            DFS(G[x][i]);
        }
}

int main()
{
    in>>n;
    for(i=1; i<n; i++)
    {
        in>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    DFS(1);
    maxx=0;
    memset(f,0,sizeof(f));
    memset(d,0,sizeof(d));
    DFS(pos);
    out<<maxx+1;
}
