#include<bits/stdc++.h>
using namespace std;
ifstream F("darb.in");
ofstream G("darb.out");
#define Z 2048
int n,p=Z,i,j,m,t,r,q;
vector<int> a[100001];
bitset<100001> c;
char s[Z];
inline char A()
{
    if(p==Z)
        F.read(s,Z),p=0;
    return s[p++];
}
int B()
{
    char c;
    for(c=A();!isdigit(c);c=A());
    int n=0;
    for(;isdigit(c);n=n*10+c-48,c=A());
    return n;
}
void C(int i,int l)
{
    if(c[i]=t,l>r)
        r=l,q=i;
    for(int j:a[i])
        if(c[j]!=t)
            C(j,l+1);
}
int main()
{
    for(n=B(),m=n-1;m--;i=B(),j=B(),a[i].push_back(j),a[j].push_back(i));
    return t=1,C(1,1),t=0,C(q,1),G<<r,0;
}
