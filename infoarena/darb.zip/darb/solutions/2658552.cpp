#include <bits/stdc++.h>

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");


vector<int> graf[100005];
bool viz[100005];
int ct[100005];
int maxim,ans;
queue<int> q;

void bfs(int s)
{
	memset(ct,0,100005);
	memset(viz,0,100005);
	q.push(s);
	ct[s]=1;
	viz[s]=1;
	while(!q.empty())
	{
		int front=q.front();
		for(auto x:graf[front])
		{
			if(viz[x]==0)
			{
				ct[x]=ct[front]+1;
				q.push(x);
				ans=ct[x];
				maxim=x;
				viz[x]=1;
			}
		}
		q.pop();
	}
}


int main()
{
	int n;
	in>>n;
	for(int i=1;i<=n;i++)
	{
		int x,y;
		in>>x>>y;
		graf[x].push_back(y);
		graf[y].push_back(x);
	}
	bfs(1);
	bfs(maxim);
	out<<ans;
	return 0;
}
