#include <fstream>
#include <vector>
#include <queue>
#define NMAX 100002
using namespace std;
ifstream  fin("darb.in");
ofstream fout("darb.out");
int N,poz,vmax;
vector<int> graph[NMAX];

void citire()
{
    int a,b;
    fin>>N;

    for(int i=1; i<=N-1; i++)
    {
        fin>>a>>b;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
}

void BFS(int start)
{
    vector<int> cost(NMAX,-1);
    queue<int> q;

    cost[start]=0;
    q.push(start);

    while(!q.empty())
    {
        int nod=q.front();
        q.pop();

        for(int i=0; i<graph[nod].size(); i++)
        {
            if(cost[graph[nod][i]]==-1)
            {
                cost[graph[nod][i]]=cost[nod]+1;
                if(cost[nod]+1>vmax)
                {
                    vmax=cost[graph[nod][i]];
                    poz=graph[nod][i];
                }
                q.push(graph[nod][i]);
            }
        }
    }
}

int main()
{
    citire();

    vmax=poz=0;
    BFS(1);

    vmax=0;
    BFS(poz);

    fout<< vmax+1 << "\n";

    return 0;
}
