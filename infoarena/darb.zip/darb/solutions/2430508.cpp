#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector <int> v[1000001];
queue <int> Q;
bool viz[1000001];
int dist[1000001],n,x,y,last,lg;
void bfs(int k)
{
    int element;
    Q.push(k);
    viz[k]=1;
    dist[k]=1;
    while(!Q.empty())
    {
        element = Q.front();
        Q.pop();
        for(int i=0; i<v[element].size(); ++i)
            if(viz[v[element][i]]==0)
            {
                Q.push(v[element][i]);
                viz[v[element][i]]=1;
                dist[v[element][i]] = dist[element] + 1;
                lg=dist[v[element][i]];
                last=v[element][i];
            }
    }
    memset(dist, 0, sizeof(dist));
    memset(viz, 0, sizeof(viz));
}
int main()
{
    fin>>n;
    while(fin>>x>>y)
    {
        v[x].push_back(y);
        v[y].push_back(x);
    }
    bfs(1);
    bfs(last);
    fout<<lg;
    return 0;
}
