#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream in ("darb.in");
ofstream out ("darb.out");
vector <int> v[100001];
bool viz[100001];
int last_node;
int first_max = 0, node = 0;
int max_d;
void dfs (int nod, int depth)
{
    if (depth > first_max)
        first_max = depth, node = nod;
    for (auto vecin:v[nod])
        if (!viz[vecin])
        {
            viz[vecin] = 1;
            dfs(vecin, depth + 1);
        }
}
void dfs1(int nod, int depth)
{
    max_d = max (max_d, depth);
    for (auto vecin:v[nod])
        if (!viz[vecin])
        {
            viz[vecin] = 1;
            dfs1(vecin, depth + 1);
        }
}
main ()
{
    int n;
    cin >> n;
    for (int i = 1;i<n;++i)
    {
        int a, b;
        cin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    dfs(1, 1);
    for (int i = 1;i<=n;++i)
        viz[i] = 0;
    dfs1(node, 1);
    cout << max_d;
    return 0;
}
