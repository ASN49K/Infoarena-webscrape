#include <bits/stdc++.h>
#define dmax 100000
using namespace std;
int n,un;
vector<vector<int>>g;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector<int>d;
queue<int>q;
void read()
{
    int x,y;
    fin>>n;
    g=vector<vector<int>>(n+1);
    d=vector<int>(n+1);
    for(int i=1; i<=n-1; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
}
void bfs(int nod)
{
    q.push(nod),d[nod]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(auto v:g[nod])
        if(!d[v])
            d[v]=d[nod]+1,q.push(v),un=v;
    }
}
int main()
{
    read();
    bfs(1);
    for(int i=1;i<=n;i++)
        d[i]=0;
    bfs(un);
    int mx=0;
    for(int i=1;i<=n;i++)
        if(d[i]>mx)
            mx=d[i];
    fout<<mx;
}
