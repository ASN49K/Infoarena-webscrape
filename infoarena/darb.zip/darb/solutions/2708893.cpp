#include <fstream>
#include <vector>

using namespace std;
ifstream cin( "darb.in" );
ofstream cout( "darb.out" );
const int N = 100001;
vector <int> lista[N + 1];
int viz[N], coada[N], n;
int L[N];
void bfs(int x){
    int st, dr, i, dist;
    viz[x] = 1;
    st = dr = 1;
    coada[st] = x;
    L[x] = 1;
    while(st <= dr){
        dist = L[coada[st]];
        for(int i = 0; i < lista[coada[st]].size(); i++){
            if(viz[lista[coada[st]][i]] == 0){
                dr++;
                coada[dr] = lista[coada[st]][i];
                viz[lista[coada[st]][i]] = 1;
                L[lista[coada[st]][i]] = dist + 1;
            }
        }
        st++;
    }
}
int main(){
    int nod1, nod2, maxim, frunza;
    cin >> n;
    for(int i = 1; i <= n - 1; i++){
        cin >> nod1 >> nod2;
        lista[nod1].push_back(nod2);
        lista[nod2].push_back(nod1);
    }
    bfs(1);
    maxim = 0;
    frunza = 1;
    for(int i = 1; i <= n; i++){
        if(L[i] > maxim){
            maxim = L[i];
            frunza = i;
        }
        viz[i] = L[i] = 0;
    }
    bfs(frunza);
    maxim = 0;
    for(int i = 1; i <= n; i++){
        if(L[i] > maxim)
            maxim = L[i];
    }
    cout << maxim;
    return 0;
}
