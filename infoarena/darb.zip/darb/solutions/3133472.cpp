#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
const int NMAX=100001;
int N,diam,ult;
bool viz[NMAX];
vector <int> lista[NMAX];
void citire()
{
    int x,y;
    f>>N;
    for(int i=1;i<N;i++)
    {
        f>>x>>y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }
}
void DFS(int x,int niv)
{
    if(niv>diam)
    {
        diam=niv;
        ult=x;
    }
    viz[x]=1;
    for(auto &it:lista[x])
        if(viz[it]==0)
            DFS(it,niv+1);
}
int main()
{
    citire();
    DFS(1,1);
    for(int i=1;i<=N;i++)
        viz[i]=0;
    DFS(ult,1);
    g<<diam;///diametrul exprimat in numar de muchii
    f.close();
    g.close();
    return 0;
}
