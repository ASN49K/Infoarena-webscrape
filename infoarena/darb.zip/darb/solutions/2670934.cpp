#include <iostream>
#include <fstream>
#include <vector>
 
using namespace std;

#define NMAX 1001
 
ifstream f("darb.in");
ofstream g("darb.out");
 
int n, m, dist[NMAX], viz[NMAX];
vector<int> h[NMAX];
 
void DFS(int nod)
{
    viz[nod] = 1;
    for (auto i : h[nod])
        if (viz[i] == 0)
        {
            dist[i] = dist[nod] + 1;
            DFS(i);
        }
}
 
int main()
{
    int i, maxi, nodm, y, x;
    f >> n;
    while(f >> x >> y)
    {
        h[x].push_back(y);
        h[y].push_back(x);
    }
    
    DFS(1);
    
     maxi = dist[1];
     nodm = 1;
     
    for (i = 2; i <= n; i++)
        if (dist[i] > maxi)
           {
              maxi = dist[i];
               nodm = i;
           }
           
    for (i = 1; i <= n; i++)
        dist[i] = viz[i] = 0;
        
    dist[nodm] = 1;
    DFS(nodm);
    maxi = -1;
    
    for (i = 1; i <= n; i++)
        if (dist[i] > maxi)
            maxi = dist[i];
            
    g << maxi;
    
    return 0;
}