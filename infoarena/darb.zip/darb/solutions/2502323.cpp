#include <bits/stdc++.h>

#define NMAX 100001

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, a, b, maxim = -1, nmax;

set<int> m[NMAX];

void DFS(int nod, int dist, int tata) {
    if (dist > maxim) {
        maxim = dist;
        nmax = nod;
    }
    for (auto it = m[nod].begin(); it != m[nod].end();++it)
        if (*it != tata)
            DFS(*it, dist + 1,nod);
}

int main() {
    int i;
    fin >> n;
    for (i = 1; i <= n - 1; i++) {
        fin >> a >> b;
        m[a].insert(b);
        m[b].insert(a);
    }
    DFS(1, 1,0);
    maxim = -1;
    DFS(nmax, 1,0);
    fout << maxim;
    return 0;
}
