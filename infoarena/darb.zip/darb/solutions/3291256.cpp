#include <bits/stdc++.h>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

int n,k,x,y,rez,nivel[100200];
vector <int> edges[100200];

void dfs(int x)
{
    if(nivel[x]>nivel[rez])
        rez=x;
    for(auto y:edges[x])
        if(nivel[y]==0)
            nivel[y]=nivel[x]+1, dfs(y);
}

int32_t main()
{
    f>>n;
    for(int i=1; i<n; i++)
        f>>x>>y, edges[x].push_back(y), edges[y].push_back(x);
    nivel[1]=1, dfs(1);
    memset(nivel,0,sizeof(nivel));
    nivel[rez]=1, dfs(rez);
    g<<nivel[rez];
    return 0;
}
