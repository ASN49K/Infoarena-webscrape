#include <bits/stdc++.h>

using namespace std;

int last, n, ans;

int prez[300010];

vector <int> v[300010];
queue <int> q;

int main()
{
    ifstream fin ("darb.in");
    ofstream fout ("darb.out");

    fin >> n;
    for(int i=1; i<n; i++)
    {
        int x, y; fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    q.push(1);
    prez[1] = 1;

    while(!q.empty())
    {
        int nod = q.front(); q.pop();
        last = nod;
        for(auto it : v[nod])
            if(!prez[it])
            {
                q.push(it);
                prez[it] = 1;
            }
    }

    for(int i=1; i<=n; i++) prez[i] = 0;

    q.push(last);
    prez[last] = 1;

    while(!q.empty())
    {
        int nod = q.front(); q.pop();
        for(auto it : v[nod])
            if(!prez[it])
            {
                q.push(it);
                prez[it] = prez[nod] + 1;
            }
    }

    for(int i=1; i<=n; i++)
        ans = max(ans, prez[i]);

    fout << (ans-1);
    return 0;
}
