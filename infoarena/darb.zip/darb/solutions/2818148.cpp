#include <bits/stdc++.h>

using namespace std;

ifstream fin( "darb.in" );
ofstream fout( "darb.out" );

class graph {
private:
    static const int INF = 2000'000'000;
    int N;                                          /// number of nodes
    int t = 0;                                      /// auxiliary variable, for different needs
    vector< vector<int> > ad;
    vector< vector<int> > reverseAd;
    vector< vector<int> > cost;
    vector<int> dist;
    vector<int> low;
    vector<int> aux;                                /// auxiliary vector, for different needs
    vector<pair<int,int> > criticalEdges;
    int conexComponents;                             /// requires DFSTraversal to set the value
    vector< vector<int> > adMat;
    void Dfs( int node ) {
        aux.push_back( node );
        dist[node] = 1;

        for( int i = 0; i < ad[node].size(); ++i ) {
            int w = ad[node][i];

            if( dist[w] == 0 )
                Dfs( w );
        }
    }
    void Dfs2( int node, int parent, vector<vector<int> > &_solution ) {
        dist[node] = low[node] = ++t;
        aux.push_back( node );

        for( int i = 0; i < ad[node].size(); ++i ) {
           int w = ad[node][i];

           if( w == parent ) continue;

           if( dist[w] > 0 ) low[node] = min( low[node], dist[w] );
           else {
              Dfs2( w, node, _solution );
              low[node] = min( low[node], low[w] );

              if( low[w] >= dist[node] ) {
                 if( low[w] > dist[node] )
                 criticalEdges.push_back( { w, node } );

                 vector <int> tmp;

                 while( aux.back() != w ) {
                    tmp.push_back( aux.back() );
                    aux.pop_back();
                 }
                 tmp.push_back( aux.back() );
                 aux.pop_back();

                 tmp.push_back( node );
                 _solution.push_back( tmp );
              }
           }
        }
    }
    void Dfs3( int node ) {
        dist[node] = 1;

        for( int i = 0; i < ad[node].size(); ++i ) {
            int w = ad[node][i];

            if( dist[w] == 0 )
                Dfs3( w );
        }

        aux.push_back( node );
    }
    void Dfs4( int node, vector<int> &v ) {
        dist[node] = 1;
        v.push_back( node );

        for( int i = 0; i < reverseAd[node].size(); ++i ) {
            int w = reverseAd[node][i];

            if( dist[w] == 0 )
                Dfs4( w, v );
        }
    }
public:
    graph( int n ) {
        N = n;
        ad.resize( n + 1 );
        cost.resize( n + 1 );
        dist.resize( n + 1 );
        low.resize( n + 1 );
        reverseAd.resize( n + 1 );

        vector <int> tmp(n + 1);
        for( int i = 0; i <= n; i++ )
            adMat.push_back( tmp );
    }
    void changeN( int n ) {
        N = n;
        ad.resize( n + 1 );
        cost.resize( n + 1 );
        dist.resize( n + 1 );
        low.resize( n + 1 );
        reverseAd.resize( n + 1 );

        vector <int> tmp(n + 1);
        for( int i = 0; i <= n; i++ )
            adMat.push_back( tmp );
    }
    int getN() { return N; }
    void addEdge( int x, int y, bool directed = false, int c = 0 ) {
        ad[x].push_back(y);
        cost[x].push_back(c);

        reverseAd[y].push_back(x);

        if( !directed ) {
            ad[y].push_back(x);
            cost[y].push_back(c);
            reverseAd[x].push_back(y);
        }

        adMat[x][y] = c;
        if( !directed ) adMat[y][x] = c;
    }
    void setAdMat( vector<vector<int> > mat ) {
        adMat = mat;
    }
    vector <int> DfsTraversal() {
        aux.clear();
        conexComponents = 0;

        for( int i = 1; i <= N; ++i )
            dist[i] = 0;

        for( int i = 1; i <= N; i++ )
            if( dist[i] == 0 ) {
                Dfs( i );
                ++conexComponents;
            }

        return aux;
    }
    void bfsTraversal( int source ) {
        queue<int> Q;

        for( int i = 0; i <= N; i++ )
            dist[i] = 0;

        dist[source] = 1;
        Q.push( source );

        while( !Q.empty() ) {
            int u = Q.front();
            Q.pop();

            for( int i = 0; i < ad[u].size(); ++i ) {
                int w = ad[u][i];

                if( dist[w] == 0 ) {
                    dist[w] = dist[u] + 1;
                    Q.push( w );
                }
            }
        }
    }
    int graphDiameter() {
        bfsTraversal( 1 );

        int maxDist = -1, maxNode;

        for( int i = 1; i <= N; ++i )
            if( dist[i] > maxDist ) {
                maxDist = dist[i];
                maxNode = i;
            }

        bfsTraversal( maxNode );

        maxDist = -1;
        for( int i = 1; i <= N; ++i )
            maxDist = max( maxDist, dist[i] );

        return maxDist;
    }
    vector<int>getTopologicalSort() {
        aux.clear();
        for( int i = 1; i <= N; i++ )
            dist[i] = 0;

        for( int i = 1; i <= N; i++ )
            if( dist[i] == 0 )
                Dfs3( i );

        return aux;
    }
    vector<vector<int> > getStronglyConnectedComponents() {
        vector<vector<int> > sol;
        vector<int> topologicalSort = getTopologicalSort();

        for( int i = 0; i <= N; i++ )
            dist[i] = 0;


        for( int i = topologicalSort.size() - 1; i >= 0; --i ) {
            int node = topologicalSort[i];

            if( dist[node] ) continue;

            vector<int> tmp;

            Dfs4( node, tmp );

            sol.push_back( tmp );
        }

        return sol;
    }
    vector<vector<int> > getBiconnectedComponents() {
        vector<vector<int> > sol;

        for( int i = 1; i <= N; ++i )
            if( dist[i] == 0 )
                Dfs2( i, 0, sol );

        return sol;
    }
    int getConexComponents() {                      /// requires DFS to be called first
        return conexComponents;
    }
    vector <int> getDistances() {                   /// requires BFS to be called first
        return dist;
    }
    vector <pair<int,int> > getCriticalEdges() {    /// requires getBiconnectedComps to be called first
        return criticalEdges;
    }
    static bool HavelHakimiUtillity( vector<int> degree ) {
        while( !degree.empty() ) {
            sort( degree.begin(), degree.end() );

            if( degree.back() < 0 )
                return false;

            if( degree.back() > degree.size() - 1 )
                return false;

            for( int i = 1; i <= degree.back(); ++i )
                degree[degree.size() - i - 1]--;

            degree.pop_back();
        }

        return true;
    }
    vector <vector<int> > royFloyd() {
        vector< vector<int> > dist;

        for( int i = 0; i <= N; ++i ) {
            vector<int> tmp;
            tmp.resize( N + 1 );

            dist.push_back( tmp );
        }

        for( int i = 1; i <= N; ++i )
            for( int j = 1; j <= N; ++j )
                dist[i][j] = INF;

        for( int i = 1; i <= N; ++i )
            for( int j = 1; j <= N; ++j )
                if( adMat[i][j] ) dist[i][j] = adMat[i][j];

        for( int k = 1; k <= N; ++k )
            for( int i = 1; i <= N; ++i )
                for( int j = 1; j <= N; ++j )
                    if( i != j )
                        if( dist[i][k] < INF && dist[k][j] < INF && dist[i][j] > dist[i][k] + dist[k][j] )
                            dist[i][j] = dist[i][k] + dist[k][j];

        return dist;
    }
};


int main()
{
    int n, x, y;

    fin >> n;

    graph G(n);

    for( int i = 1; i <= n; ++i ) {
        fin >> x >> y;

        G.addEdge( x, y );
    }


    fout << G.graphDiameter();


    return 0;
}
