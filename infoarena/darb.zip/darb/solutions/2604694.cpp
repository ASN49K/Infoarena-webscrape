#include <fstream>
#include <queue>
#include <bitset>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
const int lim=1e5+3;
vector<int> vec[lim];
int depth[lim];
queue<int> q,pq;
bitset<lim> ok,viz;
int main()
{
    int n,a,b;
    cin>>n;
    for(int i=1;i<n;++i)
    {
        cin>>a>>b;
        vec[a].push_back(b);
        vec[b].push_back(a);
    }
    q.push(1);
    ok[1]=1;
    int last;
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        last=x;
        for(auto y:vec[x])
        if(!ok[y]) ok[y]=1,q.push(y);
    }
    pq.push(last);
    viz[last]=1;
    int urm;
    while(!pq.empty())
    {
        int x=pq.front();
        pq.pop();
        urm=depth[x];
        for(auto y:vec[x])
        if(!viz[y]) viz[y]=1,pq.push(y),depth[y]=depth[x]+1;
    }
    cout<<urm+1<<endl;
    return 0;
}
