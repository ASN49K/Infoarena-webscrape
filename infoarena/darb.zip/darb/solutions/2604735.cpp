#include <iostream>
#include <fstream>
#include <vector>
#include <deque>

using namespace std;

vector<int> parents;
vector<vector<int>> childs;
vector<bool> viz;

int maxcount = -9999;

int bfs(){
    deque<int> states;
    states.push_back(1);
    int ln = -1;
    while(!states.empty()){
        int cs = states.size();
        for(int i=0;i<cs;i++){
            for(auto ss: childs[states.front()])
                states.emplace_back(ss);
            ln = states.front();
            states.pop_front();
        }
    }
    return ln;
}

void dfs(int cn,int count = 0){
    viz[cn] = true;
    if(parents[cn]!=0 && count>maxcount)
        maxcount = count;
    for(auto c: childs[cn])
        if(!viz[c])
            dfs(c, count+1);
    if(parents[cn]!=0 && !viz[parents[cn]])
         dfs(parents[cn], count+1);
}

int main() {
    int n, x, y;

    ifstream fin("darb.in");
    ofstream fout("darb.out");

    fin>>n;

    childs.resize(n+1);
    parents.resize(n+1);
    viz.resize(n+1);
    while(--n){
        fin>>x>>y;
        childs[x].push_back(y);
        parents[y] = x;
    }
    int ln = bfs();
    dfs(ln);
    fout<<maxcount+1;
    return 0;
}
