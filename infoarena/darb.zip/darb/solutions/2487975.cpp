#include <iostream>
#include <fstream>
#include <vector>
#define NMAX 100000

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

vector<int> v[NMAX],viz;
int m,s=0;

void dfs(int k,int nr=1)
{
    viz[k]=1;
    if(nr>s)
        m=k,s=nr;
    for(auto x:v[k])
        if(!viz[x])
    {
        viz[x]=1;
        dfs(x,nr+1);
    }
}

int main()
{
    int n;
    f>>n;
    for(int i=1;i<n;++i)
    {
        viz.push_back(0);
        int x,y;
        f>>x>>y;
        v[x-1].push_back(y-1);
        v[y-1].push_back(x-1);
    }
    viz.push_back(0);
    dfs(0);
    s=0;
    for(int i=0;i<n;++i)
        viz[i]=0;
    dfs(m);
    g<<s;
    return 0;
}
