#include<bits/stdc++.h>
using namespace std;
ifstream F("darb.in");
ofstream G("darb.out");
vector<int> a[100001];
int i,j,t,e,s;
bitset<100001> c;
void A(int i,int d)
{
    if(d>e)
        e=d,s=i;
    c[i]=t;
    for(int j:a[i])
        if(c[j]!=t)
            A(j,d+1);
}
int main()
{
    for(F>>i;F>>i>>j;a[i].push_back(j),a[j].push_back(i));
    return t=1,A(1,0),t=0,A(s,1),G<<e,0;
}
