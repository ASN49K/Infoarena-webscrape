#include <fstream>
#include <vector>
#include <bitset>
#include <cstring>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
const int N = 1e5+105;
int n,i,x,y,maxx,nod,dist[N];
vector <int> v[N];
bitset <N> f;
void dfs(int x)
{
    f[x]=1;
    for (auto i:v[x])
    {
        if (!f[i])
        {
            dist[i]=dist[x]+1;
            if (dist[i]>maxx)
            {
                nod=i;
                maxx=dist[i];
            }
            dfs(i);
        }
    }
}
int main()
{
    cin>>n;
    for (i=1; i<=n; ++i)
    {
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dist[1]=1;
    dfs(1);
    f.reset();
    memset(dist,0,sizeof dist);
    maxx=0;
    dist[nod]=1;
    dfs(nod);
    cout<<maxx;
}

