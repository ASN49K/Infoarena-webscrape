#include<iostream>
#include<fstream>
#include<vector>
#include<queue>
using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

int n;
vector<int> children[100001];
int viz[100001];
int rez_1,max1;

void BFS()
{
    int cnt = 0;
    queue<int> q;
    q.push(1);
    viz[1] = true;
    while(!q.empty())
    {
        int node = q.front();
        for(int i=0;i<children[node].size();i++)
        {
            if(viz[children[node][i]] == false)
            {
                q.push(children[node][i]);
                viz[children[node][i]] = true;
            }
        }
        cnt++;
        if(cnt == n)
            rez_1 = q.front();
        q.pop();
    }
}

void DFS(int node, int cnt1)
{
    if(cnt1>max1)
    {
        max1 = cnt1;
    }
    for(int i=0;i<children[node].size();i++)
    {
        if(viz[children[node][i]] == false)
        {
            viz[children[node][i]] = true;
            DFS(children[node][i],cnt1+1);
        }
    }
}

int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
        int x,y;
        f>>x>>y;
        children[x].push_back(y);
        children[y].push_back(x);
    }
    BFS();
    for(int i=1;i<=n;i++)
        viz[i] = 0;
    DFS(rez_1,0);
    g<<max1+1;
}