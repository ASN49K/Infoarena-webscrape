#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in ("darb.in");
ofstream out ("darb.out");

vector<int> mu[100005];
queue<int> q;
int vis[100005];
int dist[100005];

int bfs(int start, int nr)
{
    int aux;

    q.push(start);
    vis[start] = nr;
    dist[start]=1;

    while(!q.empty())
    {
        aux = q.front();

        //out<<aux<<" : ";

        for(int i = 0; i < mu[aux].size(); i++)
        {
            //out<<mu[aux][i]<<" , ";
            if(vis[mu[aux][i]] == nr-1)
            {
                q.push(mu[aux][i]);
                vis[mu[aux][i]] = nr;
                dist[mu[aux][i]] = dist[aux] + 1;
            }
        }
        //out<<'\n';
        q.pop();

    }
    if(nr == 1)
        return aux;
    else
        out<<dist[aux];
    return 0;
}

void c_a(int m, bool a)
{
    for(int j = 1 ; j < m; j++)
    {
        if(a)
        {
            out << j <<" : ";
            for (int i = 0; i < mu[j].size(); i++)
                out << mu[j][i] << " ";
            out << '\n';
        }
        else
        {
            int x, y;
            in >> x >> y;
            mu[x].push_back(y);
            mu[y].push_back(x);
        }
    }
}

int main()
{
    int n, m, i, x;

    in >>m;

    c_a(m, 0);
    //c_a(m, 1);
    //return 0;

    int ndmax = bfs(1, 1);
    bfs(ndmax, 2);

    return 0;
}
