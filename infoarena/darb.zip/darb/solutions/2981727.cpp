#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int const N=1e6+5;
int dist1[N],rez1=-1;
int dist2[N],rez2=-1;
vector<int>G[N];
void dfs1(int node,int dist)
{
    int sz=G[node].size();
    dist1[node]=dist;
    if(rez1<0 || dist>dist1[rez1])
        rez1=node;
    for(int i=0;i<sz;i++)
        if(!dist1[G[node][i]])
            dfs1(G[node][i],dist+1);
}
void dfs2(int node,int dist)
{
    int sz=G[node].size();
    dist2[node]=dist;
        if(rez2<0 || dist>dist2[rez2])
        rez2=node;
    for(int i=0;i<sz;i++)
        if(!dist2[G[node][i]])
            dfs2(G[node][i],dist+1);
}
int main()
{
    int n,m;
    fin>>n>>m;
    int x,y;
    while(fin>>x>>y)
    {
        G[x].push_back(y);
        G[y].push_back(x);
    }
    dfs1(1,1);
    dfs2(rez1,1);
    fout<<dist2[rez2];
}