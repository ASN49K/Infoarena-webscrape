#include <bits/stdc++.h>
using namespace std;
ifstream in("darb.in");
ofstream out("darb.out");
vector<int> v[100001];
pair<int, int> dfs1(int nod, int adancime, int tata)
{
    if (v[nod].size() == 1 && tata != 0)
        return {nod, adancime};
    else
    {
        pair<int, int> max_ad = {0, 0};

        for (auto vecin : v[nod])
        {
            if (vecin == tata)
                continue;
            pair<int, int> ans = dfs1(vecin, adancime + 1, nod);
            if (ans.second > max_ad.second)
                max_ad = ans;
        }
        return max_ad;
    }
}
void solve()
{
    int n;
    in >> n;
    for (int i = 1; i < n; ++i)
    {
        int a, b;
        in >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    pair<int, int> nod_final = dfs1(1, 1, 0);
    pair<int, int> anss = dfs1(nod_final.first, 1, 0);
    out << anss.second << '\n';
}

int main()
{
    int t = 1;
    //cin >> t;
    while (t--)
        solve();
}