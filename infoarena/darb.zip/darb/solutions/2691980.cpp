#include <iostream>
#include <queue>
#include <vector>
#include <list>
#include <fstream>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");

queue <int> q;
vector <int> viz(100002,0);
list <int> ad[100002];

int bfs()
{

    int nod;
    while(!q.empty())
    {
        nod = q.front();
        for(auto &node: ad[nod])
        {
            if(viz[node] == 0)
            {
                viz[node] = viz[nod] + 1;
                q.push(node);
            }

        }
        q.pop();
    }
    return nod;

}
int main()
{
    int n;
    fin>>n;
    for(int i = 1; i < n; i ++)
    {
        int a,b;
        fin>>a>>b;
        ad[a].push_back(b);
        ad[b].push_back(a);
    }
    int s = 1;
    viz[s] = 1;
    q.push(s);
    int nod = bfs();
    fill(viz.begin(),viz.end(),0);
    viz[nod] = 1;
    q.push(nod);
    int endnode = bfs();
    fout<<viz[endnode];
    return 0;
}
