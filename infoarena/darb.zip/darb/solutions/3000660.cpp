#include<bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int NMAX= 100005;
int N;
int lvlmax, last;
vector<int>ad[NMAX];
bool vis[NMAX];

void DFS(int Nod, int nivel){
    vis[Nod] = true;
    if(nivel > lvlmax){
        lvlmax = nivel;
        last = Nod;
    }
    for(int i=0;i<ad[Nod].size();i++){
        int v=ad[Nod][i];
        if(!vis[v])
            DFS(v, nivel+1);
    }
}
void Reset(){
    for(int i=1;i<=N;i++)
        vis[i]=false;
}

int main(){
    int x, y;
    fin>>N;
    for(int i=1;i<N;i++){
        fin>>x>>y;
        ad[x].push_back(y);
        ad[y].push_back(x);
    }
    DFS(1,0);
    Reset();
    DFS(last, 0);
    fout<<lvlmax + 1;
    return 0;
}
