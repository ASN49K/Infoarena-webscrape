#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int N = 100041;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n;
vector<int> gra[N];
void read(){
	fin >> n;
	for(int i = 0; i < n; ++i){
		int a, b;
		fin >> a >> b;
		gra[a].push_back(b);
		gra[b].push_back(a);
	}
}

int ans=0;
bool vi[N];
int parkour(int a=1){
	vi[a] = true;
	int r = 1;
	for(auto b : gra[a]){
		if(!vi[b]){
			int v = parkour(b)+1;
			if(v >= r){
				if(r != 1){
					ans = max(ans, r+v);
				}
				r = v;
			}
		}
	}
	return r;
}

int main(){
	// ios_base::sync_with_stdio(false);
	read();
	parkour();
	fout << ans-1;
	return 0;
}