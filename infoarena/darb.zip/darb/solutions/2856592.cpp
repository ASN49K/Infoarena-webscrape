#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int N;
const int NMAX = 100002;
set <int> t[NMAX];
int lmax = 0, nodmax;
bool v1[NMAX], v2[NMAX];
int dfs(int a, int l, bool v[])
{
    v[a] = 1;
    if(l > lmax)
    {
        lmax = l;
        nodmax = a;
    }
    for(auto i : t[a])
    {
        if(!v[i])
            return dfs(i, l + 1, v);
    }
    return l;
}
int main()
{
    ios_base::sync_with_stdio(false);
    int x, y;
    fin>>N;
    for(int i = 0; i < N; i++)
    {
        fin>>x>>y;
        t[x].insert(y);
        t[y].insert(x);
    }
    dfs(1, 1, v1);
    fout<<dfs(nodmax, 1, v2);
    return 0;
}
