#include <bits/stdc++.h>
using namespace std;
ifstream fcin("darb.in");
ofstream fcout("darb.out");
typedef long long ll;

const int N = 1e5 + 5;
vector<vector<int>> v(N);
int n, a, b, d[N], maxx, nodmax;
bool vizitat[N];

void DFS(int nod)
{
    vizitat[nod] = 1;
    for (int e : v[nod])
        if (!vizitat[e])
        {
            d[e] = d[nod] + 1;
            DFS(e);
        }
}

int main()
{
    fcin >> n;
    for (int i = 1; i < n; i++)
    {
        fcin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    DFS(1);
    for (int i = 1; i <= n; i++)
        if (d[i] > maxx)
        {
            maxx = d[i];
            nodmax = i;
        }
    for (int i = 1; i <= n; i++)
        vizitat[i] = d[i] = 0;
    DFS(nodmax);
    maxx = 0;
    for (int i = 1; i <= n; i++)
        maxx = max(maxx, d[i]);
    fcout << maxx + 1;
    fcout.close();
    fcin.close();
    return 0;
}
