#include <bits/stdc++.h>

using namespace std;

ifstream f ("darb.in");
ofstream g ("darb.out");

const int nmax = 1e5 + 3;

int n, a, b, far, mare;
vector <int> v[nmax];

void solve(int nod, int ant, int lvl)
{
    if (lvl > mare)
    {
        mare = lvl;
        far = nod;
    }

    for (int i = 0; i < v[nod].size(); ++i)
    {
        if (v[nod][i] != ant)
            solve(v[nod][i], nod, lvl + 1);
    }
}

int main()
{
    f >> n;
    for (int i = 1; i < n; ++i)
    {
        f >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    solve(1, 0, 1);
    solve(far, 0 , 1);

    g << mare << '\n';

    return 0;
}
