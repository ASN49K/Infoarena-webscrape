#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

vector <int> edges[NMAX + 1];
int dist[NMAX + 1];

void dfs( int node, int p = 0 ) {
    for ( auto vec : edges[node] ) {
        if ( vec != p ) {
            dist[vec] = dist[node] + 1;
            dfs( vec, node );
        }
    }
}
int main() {
    ifstream fin( "darb.in" );
    ofstream fout( "darb.out" );
    int n;
    fin >> n;
    for ( int i = 1, a, b; i < n; i ++ ) {
        fin >> a >> b;
        edges[a].push_back( b ) ;
        edges[b].push_back( a );
    }

    dfs( 1 );
    int furthest = 1;
    for ( int i = 2; i <= n; i ++ ) {
        if ( dist[i] > dist[furthest] ) {
            furthest = i;
        }
    }
    dfs( furthest );
    for ( int i = 1; i <= n; i ++ ) {
        if ( dist[i] > dist[furthest] ) {
            furthest = i;
        }
    }
    fout << dist[furthest] << '\n';
    return 0;
}