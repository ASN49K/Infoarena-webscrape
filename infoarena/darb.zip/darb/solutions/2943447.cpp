#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#define MAX 100002
using namespace std;
int n,x,y,dist[MAX],vf[MAX],maxi,dest;
vector<int> v[MAX];

ifstream fin("darb.in");
ofstream fout("darb.out");

void dfs(int nod){
    vf[nod] = 1;
    for(auto vecin: v[nod]){
        if(vf[vecin] == 0){
            dist[vecin] = 1+dist[nod];
            if(dist[vecin] > maxi){
                maxi = dist[vecin];
                dest = vecin;
            }
            dfs(vecin);
        }
    }
}

int main()
{
    fin >> n;
    for(int i = 1; i < n; i++){
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1);
    memset(dist, 0, sizeof(dist));
    memset(vf, 0, sizeof(vf));
    dfs(dest);
    fout << maxi+1 << "\n";
    return 0;
}
