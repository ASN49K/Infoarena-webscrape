#include <bits/stdc++.h>

using namespace std;
ifstream in("darb.in");
ofstream out("darb.out");
int n,d[100005],x,y,m,sol;
vector<int> v[100005];
void dfs(int nod,int t)
{
    for(auto it:v[nod])
        if(it!=t)
    {
         d[it]=d[nod]+1;
         dfs(it,nod);
    }
}
int main()
{
    in>>n;
    for(int i=1;i<=n-1;i++)
    {
        in>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    dfs(1,0);

    m=1;
    for(int i=2;i<=n;i++)
    {
        if(d[i]>d[m]) m=i;
        d[i]=0;
    }
    d[1]=0;
    dfs(m,0);

    for(int i=1;i<=n;i++) if(d[i]>sol) sol=d[i];

    out<<sol+1;
    return 0;
}
