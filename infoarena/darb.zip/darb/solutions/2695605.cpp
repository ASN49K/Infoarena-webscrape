#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream f ("darb.in");
ofstream g ("darb.out");
int d_in[100005], d_out[100005];

vector<int> v[100005];
queue<int> q;
vector<int> viz(100005);

void bfs()
{
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        for(int i=0; i<v[x].size(); i++)
        {
            if(viz[v[x][i]]==-1)
            {
                q.push(v[x][i]);
                viz[v[x][i]]=viz[x]+1;
            }
        }
    }
}

int main()
{
    int n, s;
    f>>n;
    for(int i=1; i<=n-1; i++)
    {
        int x, y;
        f>>x>>y;
        v[x].push_back(y);
        d_in[y]++;
        d_out[x]++;
    }
    for(int i=1; i<=n; i++)
    {
        if(d_in[i]==0) s=i;
    }
    fill(viz.begin(), viz.end(), -1);
    viz[s]=0;
    q.push(s);
    bfs();
    int max1=0, max2=0;
    for(int i=1; i<=n; i++)
    {
        if(d_out[i]==0)
        {
            if(max2<viz[i])
            {
                max1=max2;
                max2=viz[i];
            }
            else if (max1<viz[i])
            {
                max1=viz[i];
            }
        }
    }
    g<<max1+max2+1;
    return 0;
}
