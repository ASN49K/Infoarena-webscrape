#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>
#include <cmath>
#include <queue>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");

const int LMAX = 100005;
vector<int> L[LMAX];
int hmax[LMAX], sol;
//cel mai mare diametru al subarborelui care incepe in nod este fie suma celor mai inalti fii + 1(si nodul) sau cmm diam al unui dintre fii(nu iau nodul)

void dfs(int node, int father) {
    int max1 = 0, max2 = 0;
    for (int son : L[node]) {
        if (son != father) {
            dfs(son, node);
            if (hmax[son] > max1) {
                max2 = max1;
                max1 = hmax[son];
            }
            else if (hmax[son] > max2) {
                max2 = hmax[son];
            }
        }
    }
    sol = max(sol, max1 + max2 + 1);
    hmax[node] = max1 + 1;
}

int main() {
    int n, i, x, y;
    fin>>n;
    for (i = 1; i < n; i++) {
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1, 0);
    fout<<sol;



    fin.close();
    fout.close();
    return 0;
}
