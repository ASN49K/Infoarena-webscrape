#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");

int n, NvlMax, PozNvl, viz[10001], i, vecin, x, y;
vector <int> muchii[10001];

void DFS (int nod, int nvl)
{
    viz[nvl] = 1;
    if ( nvl > NvlMax )
        {
            NvlMax = nvl;
            PozNvl = nod;
        }

    for ( i = 0; i < muchii[nod].size(); i++)
        {
            vecin = muchii[nod][i];
            if ( !viz[vecin] )
                DFS( vecin, nvl + 1 );
        }
}

void citire()
{
    f >> n;
    for ( i = 1; i <= n; i++)
        {f >> x >> y;
         muchii[x].push_back(y);
         muchii[y].push_back(x);
        }
}


int main()
{
    citire();
    DFS(1,0);
    for ( i = 1; i<=n; i++ )
        viz[i] = 0;
    DFS( PozNvl, 0);
    g << NvlMax + 1;

    return 0;
}
