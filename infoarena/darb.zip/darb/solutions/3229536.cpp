#pragma GCC optimize("O3")
#pragma GCC optimize("fast-math")
#pragma GCC optimize("unroll-loops")
#include<bits/stdc++.h>
using namespace std;
const int dim = 1e5+ 5;
vector<int>noduri[dim];
int x, y, stiva[dim], maxi, poz;
ifstream fin("darb.in");
ofstream fout("darb.out");
void dfs(int nod, int tata)
{

    if(stiva[nod] > maxi)
    {
        maxi = stiva[nod];
        poz = nod;
    }
    for(auto it: noduri[nod])
    {
        if(it != tata)
        {
            stiva[it] = stiva[nod] + 1;
            dfs(it, nod);
        }
    }

}
int n;
int32_t main(int argc, char * argv[])
{
    fin >> n;
    for(int i = 1; i < n; ++i)
    {
        fin >> x >> y;
        noduri[x].push_back(y);
        noduri[y].push_back(x);
    }
    stiva[1] = 1;
    dfs(1, 0);
    stiva[poz] = 1;
    dfs(poz, 0);
    fout << maxi;
    return 0;
}
