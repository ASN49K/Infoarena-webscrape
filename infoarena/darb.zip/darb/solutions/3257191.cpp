#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define eb emplace_back
#define pii pair<int, int>
#define tpl tuple<int, int, int>
#define quad tuple<int, int, int, int>
#define OO LLONG_MAX / 2
#define oo INT_MAX / 2
using namespace std;

const string fn("darb");

ifstream in(fn + ".in");
ofstream out(fn + ".out");

#define cin in
#define cout out

const int MAX = 1e5;

int n, niv[MAX + 5], mx;
vector<int> g[MAX + 5];

void dfs(int node)
{
    for (auto x : g[node])
        if (niv[x] == 0)
        {
            niv[x] = niv[node] + 1;
            dfs(x);
            if (niv[mx] < niv[x])
                mx = x;
        }
}

void solve()
{
    cin >> n;

    for (int i = 1, x, y; i < n; i++)
    {
        cin >> x >> y;
        g[x].eb(y);
        g[y].eb(x);
    }
    niv[1] = 1;
    dfs(1);
    memset(niv, 0, sizeof(niv));
    niv[mx] = 1;
    dfs(mx);
    cout << niv[mx];
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int q = 1;

    // cin>>q;

    while (q--)
        solve();
    exit(0);
}