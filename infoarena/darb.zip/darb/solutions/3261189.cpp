#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n , viz[100005] , dist[100005];
vector<int> L[100005];

void DFS(int k)
{
    viz[k] = 1;
    for(int i : L[k])
        if(viz[i] == 0)
        {
            dist[i] = 1 + dist[k];
            DFS(i);
        }
}

int main()
{
    int i , j , k;
    fin >> n;
    for(k = 1;k < n;k++)
    {
        fin >> i >> j;
        L[i].push_back(j);
        L[j].push_back(i);
    }
    DFS(1);
    k = 1;
    for(i = 1;i <= n;i++)
        if(dist[i] > dist[k]) k = i;
    for(i = 1;i <= n;i++)
        viz[i] = dist[i] = 0;
    DFS(k);
    k = 1;
    for(i = 1;i <= n;i++)
        if(dist[i] > dist[k]) k = i;
    fout << dist[k] + 1;
    return 0;
}
