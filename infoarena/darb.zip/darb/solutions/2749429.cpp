#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f ("darb.in");
ofstream g ("darb.out");
int n,ultimul;
int pasi[100001];
queue<int>q;
vector<int>adiacenta[100001];
void bfs(int start)
{
    for(int i = 1;i<=100000;i++)
        pasi[i] = 0;
    q.push(start);
    pasi[start] = 1;
    while(!q.empty())
    {
        int curent = q.front();
        ultimul = curent;
        q.pop();
        for(auto x:adiacenta[curent])
        {
            if(pasi[x] == 0)
            {
                pasi[x] = pasi[curent]+1;
                q.push(x);
            }
        }
    }

}
int main()
{
    f >> n;
    for(int i = 1;i<=n;i++)
    {
        int x,y;
        f >> x >> y;
        adiacenta[x].push_back(y);
        adiacenta[y].push_back(x);
    }
    // gasim cel mai indepartat nod de orice punct
    bfs(1);
    // facem cale pana la cel mai indepartat de cel mai indepartat de mai sus
    bfs(ultimul);
    g << pasi[ultimul];

}
