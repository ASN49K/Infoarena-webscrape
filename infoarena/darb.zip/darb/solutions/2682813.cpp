#include<bits/stdc++.h> //:3
using namespace std;
typedef long long LL;
#define all(a) (a).begin(), (a).end()
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define pi pair<LL, LL>
#define sz(x) (int)((x).size())
//#define int long long
#define cin in
#define cout out

ifstream in("darb.in");
ofstream out("darb.out");

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

const int inf = 2e9;
const LL mod = 1e9 + 7;
const int N = 2e6 + 11;
const LL INF64 = 3e18 + 1;
const double eps = 1e-14;
const double PI = acos(-1);

int n, ans;
vector<int> v[N];

int dfs(int nod, int p){

    vector<int> vec;
    for(auto it : v[nod]){
        if(it == p)continue;
        vec.pb(1 + dfs(it, nod));
    }

    int mx1 = 0, mx2 = 0;
    for(auto it : vec){
        if(it > mx1){
            mx2 = mx1;
            mx1 = it;
        }else
        if(it > mx2){
            mx2 = it;
        }
    }

    if(sz(vec) >= 2)ans = max(ans, mx1 + mx2 + 1);
    if(sz(vec))ans = max(ans, mx1 + 1);

    return (sz(vec) ? mx1 : 0);
}

void solve(){

    cin >> n;

    ans = 0;

    for(int i = 1; i < n; i++){
        v[i].clear();
    }

    for(int i = 1, x, y; i < n; i++){
        cin >> x >> y;
        v[x].pb(y);
        v[y].pb(x);
    }

    int x = dfs(1, 0);

    cout << ans << '\n';
}

int32_t main(){
ios_base :: sync_with_stdio(0); cin.tie(0); cout.tie(0);

    //cout << setprecision(6) << fixed;

    int T = 1;
    //cin >> T;
    while(T--){
        solve();
    }
}
