#include <bits/stdc++.h>

using namespace std;

#define pb push_back

ifstream fin("darb.in");
ofstream fout("darb.out");

int n;
queue <int> c;
vector <int> a[100005];
int d,l;

void bfs(int x)
{
    int y[100005],v[100005];
    memset(y,0,100004);
    memset(v,0,100004);
    c.push(x);
    v[x]=1;
    y[x]=1;
    while(!c.empty())
    {
        int nod=c.front();
        for(int i=0;i<a[nod].size();i++)
            if(v[a[nod][i]]==0)
            {
                v[a[nod][i]]=1;
                y[a[nod][i]]=y[nod]+1;
                c.push(a[nod][i]);
                l=a[nod][i];
                d=y[a[nod][i]];
            }
        c.pop();
    }
}
int main()
{

    fin >> n;

    for(int i=1;i<=n-1;i++)
    {
        int x,y;
        fin >> x >> y;
        a[x].pb(y);
        a[y].pb(x);
    }

    bfs(1);
    bfs(l);
    fout << d;

    return 0;

}
