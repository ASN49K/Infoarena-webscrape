#include <fstream>
#include <vector>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
vector <int> g[100001];
int vf[100001],t;
struct ura
{
    int pas,nod;
}v[100001];
void bfs(int nod)
{
    int i,j;
    v[1].nod=nod;
    vf[nod]=1;
    for(i=1,j=1;i<=j;i++)
    {
        for(size_t k=0;k<g[v[i].nod].size();k++)
        {
            if(vf[g[v[i].nod][k]]==0)
            {
                vf[g[v[i].nod][k]]=1;
                v[++j].nod=g[v[i].nod][k];
                v[j].pas=v[i].pas+1;
            }
        }
    }
}
int main()
{
    int n,i,x,y;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    bfs(1);
    for(i=1;i<=n;i++)
        vf[i]=0;
    bfs(v[n].nod);
    cout<<v[n].pas+1;
    return 0;
}
