#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string.h>
 
#define MAX_N 1000001
 
using namespace std;
int n, m, i, x, y, viz[MAX_N];
ifstream f("darb.in");
ofstream g("darb.out");
 
void addEdge(vector<int> adj[], int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
}
vector<int> adj[MAX_N];
 
int G[MAX_N];
 
 
int nivMax = 0;
int poz = 0;
void DFS(int nod, int nivel){
    viz[nod] = 1;
    if (nivel > nivMax){
        nivMax = nivel;
        poz = nod;
    }
    //g << nod << " ";
    for (int i=0; i<G[nod]; i++)
        if (viz[adj[nod][i]] == 0)
            DFS(adj[nod][i], nivel+1);
}

citire(){
    f >> n;
    for (i=1; i<n; i++){
        f >> x >> y;
        addEdge(adj,x,y);
    }
}

int main()
{
    citire();
 
    for (i = 1; i <= n; i++)
		G[i] = adj[i].size();
 
    DFS(1,1);
 
    for (i=1; i<=n; i++)
        viz[i] = 0;
    DFS(poz,1);
    g << nivMax;
    return 0;
}