#include <bits/stdc++.h>

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

int n,a[109][109],c[109],dist[109];

void citire()
{
    int i,j;
    in>>n;
    while (in>>i>>j) a[i][j]=a[j][i]=1;
}

void dfs(int nod,int d)
{
    c[nod]=1;
    dist[nod]=d;
    for (int i=1;i<=n;i++)
    {
        if (c[i]==0 && a[nod][i]==1) dfs(i,d+1);
    }
}

int main()
{
    int maxi=0,nod;
    citire();
    dfs(1,0);
    for (int i=1;i<=n;i++)
    {
        if (dist[i]>maxi)
        {
            maxi=dist[i];
            nod=i;
        }
    }
    memset(c,0,sizeof c);
    dfs(nod,0);
    maxi=0;
    for (int i=1;i<=n;i++)
    {
        if (dist[i]>maxi) maxi=dist[i];
    }
    out<<maxi+1;
    return 0;
}
