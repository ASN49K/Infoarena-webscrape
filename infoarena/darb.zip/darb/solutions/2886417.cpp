#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;
vector <int> e[NMAX + 5];
bool viz[NMAX + 5];
int node,mx = 0;

void dfs(int nod, int cnt) {
    viz[nod] = 1;
    if (cnt > mx) {
        mx = cnt;
        node = nod;
    }
    for (int i = 0;i < e[nod].size();i++) {
        if (!viz[e[nod][i]])
            dfs(e[nod][i], cnt + 1);
    }
}
int main()
{
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    int n,a,b;
    fin >> n;
    for (int i = 0;i < n - 1;i++) {
        fin >> a >> b;
        e[a].push_back(b);
        e[b].push_back(a);
    }
    dfs(1, 1);
    memset(viz, 0, sizeof(viz));
    dfs(node, 1);
    fout << mx;
    return 0;
}
