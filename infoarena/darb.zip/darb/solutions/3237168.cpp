#include <bits/stdc++.h>

std::ifstream f("darb.in");
std::ofstream g("darb.out");

void dfs1(int nod, int& start, int& ct, int& maxim);
bool viz[100001];
std::vector<int> v[100001];
int main(){
    int n, start = 1, ct = 0, maxim = -1, aux; 
    f>>n;
    for(int i = 0, x, y; i < n - 1; ++i)
        f>>x>>y, v[x].push_back(y), v[y].push_back(x);
    dfs1(1, start, ct, maxim);
    ct = 0, maxim = -1;
    std::fill_n(viz + 1, n + 1, 0);
    dfs1(start, aux, ct, maxim);
    g<<aux<<'\n';
    return 0;
}
void dfs1(int nod, int& start, int& ct, int& maxim){
    viz[nod] = 1; ++ct;
    for(auto i : v[nod])
        if(!viz[i])
            dfs1(i, start, ct, maxim);
    if(ct > maxim)
        maxim = ct, start = nod;
    --ct;
}