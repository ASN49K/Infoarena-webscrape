#include <bits/stdc++.h>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

vector <int> G[100001];

int d[100001];
int N, x, y;

pair <int, int> bfs(int s){

	queue <int> q;
	for(int i = 1;i <= N;i++)
		d[i] = 0;

	d[s] = 1;
	q.push(s);

	while(!q.empty()){
		int v = q.front();
		q.pop();

		for(int to : G[v])
			if(!d[to]){
				d[to] = d[v] + 1;
				q.push(to);
			}
	}

	pair <int, int> ans;
	for(int i = 1;i <= N;i++)
		if(d[i] > ans.first)
			ans.first = d[i], ans.second = i;

	return ans;
}

int main(){
	f >> N;
	for(int i = 1;i < N;i++){
		f >> x >> y;
		G[x].emplace_back(y);
		G[y].emplace_back(x);
	}

	g << bfs(bfs(1).second).first;
}