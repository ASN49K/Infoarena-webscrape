#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

void Reset();

const int VMAX = 100005;

int n, x, y, nivel_maxim = 0, poz_nivel_max;
vector < int > graf[VMAX];
bitset < VMAX > viz;

void DFS(int nod, int nivel)
{
    viz[nod] = 1;
    if (nivel > nivel_maxim)
        nivel_maxim = nivel, poz_nivel_max = nod;
    for (unsigned int i = 0; i < graf[nod].size(); ++i)
        if (!viz[graf[nod][i]]) DFS(graf[nod][i], nivel + 1);
}

int main()
{
    fin >> n;
    for (int i = 1; i < n; ++i)
    {
        fin >> x >> y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    DFS(1, 1);
    Reset();
    DFS(poz_nivel_max, 1);
    fout << nivel_maxim;
}

void Reset()
{
    for (int i = 1; i <= n; ++i)    viz[i] = 0;
}
