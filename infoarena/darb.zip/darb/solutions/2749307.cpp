#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
int n,a,b,maxd;
vector <vector<int>> v(100001);
int viz[100001];
void dfs (int poz,int dis)
{
    if (maxd<dis)
        maxd=dis;
        viz[poz]=1;
    for (int i=0; i<v[poz].size(); i++)
    {
        if (viz[v[poz][i]]==0)
        {
            dfs(v[poz][i],dis+1);

        }
    }
    viz[poz]=0;
}
int main()
{
    f>>n;
    for (int i=1; i<=n; i++)
    {
        f>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    /*for (int i=1; i<=n; i++)
    {
        for (int j=0; j<v[i].size(); j++)
        cout<<v[i][j]<<' ';
        cout<<'\n';
    }*/
    for (int i=1; i<=n; i++)
    {
        dfs(i,0);
    }
    g<<maxd+1;
    return 0;
}
