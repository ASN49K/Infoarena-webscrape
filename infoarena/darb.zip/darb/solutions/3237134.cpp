#include <iostream>
#include <fstream>
#include <set>
#include <queue>
#include <vector>
using namespace std;
ifstream fin ("darb.in");
ofstream fout ("darb.in");

vector <vector<int>> graf;
vector<int> linie,timp;
queue <int> q;


void bfs(int nod)
{
    for(int i=1;i<timp.size();i++)
        timp[i]=0;
    q.push(nod);
    timp[nod]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(int i=0;i<graf[nod].size();i++)
        {
            if(timp[graf[nod][i]]==0)
            {
                timp[graf[nod][i]]=timp[nod]+1;
                q.push(graf[nod][i]);
            }
        }
    }
}


int main()
{
    ios_base::sync_with_stdio(false);
    int n,m,i,j,k,x,maxim=-1,nod_max;
    fin>>n;
    for(i=0;i<=2*n;i++)
    {
        graf.push_back(linie);
        timp.push_back(0);
    }
    for(i=0;i<n;i++)
    {
        fin>>j>>k;
        graf[j].push_back(k);
        graf[k].push_back(j);
    }
    bfs(1);
    for(i=1;i<=n;i++)
    {
        if(maxim<timp[i])
        {
            maxim=timp[i];
            nod_max=i;
        }
    }
    bfs(nod_max);
    for(i=0;i<n;i++)
    {
        if(maxim<timp[i])
        {
            maxim=timp[i];
            nod_max=i;
        }
    }
    fout<<maxim<<'\n';


    return 0;
}
