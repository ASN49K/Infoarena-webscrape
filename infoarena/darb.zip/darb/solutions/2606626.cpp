#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

//https://infoarena.ro/problema/darb

vector <int> v[1000001];
queue <int> q;
int n;
int ok[1000001];

int main()
{
    int i, x, y, na, nd;
    fin >> n;
    for (i = 1; i<n; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    ok[1] = 1;
    q.push(1);
    while (q.empty() == 0)
    {
        na = q.front();
        q.pop();
        for (i = 0; i<v[na].size(); i++)
            if (ok[v[na][i]] == 0)
            {
                ok[v[na][i]] = ok[na] + 1;
                nd = v[na][i];
                q.push(v[na][i]);
            }
    }
    for (i = 1; i<=n; i++)
        ok[i] = 0;
    //am primul varf
    ok[nd] = 1;
    q.push(nd);
    while (q.empty() == 0)
    {
        na = q.front();
        q.pop();
        for (i = 0; i<v[na].size(); i++)
            if (ok[v[na][i]] == 0)
            {
                ok[v[na][i]] = 1 + ok[na];
                q.push(v[na][i]);
            }
    }
    int rasp = 0;
    for (i = 1; i<=n; i++)
        rasp = max(rasp, ok[i]);
    fout << rasp;
    return 0;
}
