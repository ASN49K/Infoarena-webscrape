#include <fstream>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

int n, m, nod;
bool A[101][101], viz1[101], viz2[101];
int lg[101];
int nfin, maxx;

void citire()
{
    int x, y;
    f >> n;
    m = n - 1;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        A[x][y] = A[y][x] = 1;
    }
}

void DFS(int nod, bool viz[], int crt)
{
    if(crt > maxx)
    {
        nfin = nod;
        maxx = crt;
    }
    viz[nod] = 1;
    for(int j = 1; j <= n; j++)
        if(A[nod][j] == 1 && viz[j] == 0)
            DFS(j, viz, crt + 1);
}

int main()
{
    citire();
    DFS(1, viz1, 0);
    maxx = 0;
    DFS(nfin, viz2, 0);
    g << maxx + 1;
    return 0;
}
