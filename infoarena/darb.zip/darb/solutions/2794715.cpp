#include <stdio.h>
#include <array>

#define MAXN 1000000

std::array<int, MAXN> v;


int main () {
	int n = MAXN;
	int i;
	volatile int x;

	for (auto val: v) {
		for (int i = 0; i != 1000; ++ i)
			x = i;
	}

	return 0;
}
