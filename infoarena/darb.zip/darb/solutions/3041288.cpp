#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>

///#include <tryhardmode>
///#include <GOMDODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int NMAX=1e5+5;

vector<int>v[NMAX];
bool viz[NMAX];
long long dist[NMAX];
long long maxim=1;
int leaf;

void bfs(int p)
{
    queue<int>q;
    dist[p]=1;
    viz[p]=true;
    q.push(p);
    while(!q.empty())
    {
        int p=q.front();
        q.pop();
        for(auto i:v[p])
        {
            if(!viz[i])
            {
                leaf=i;
                viz[i]=true;
                dist[i]=dist[p]+1;
                maxim=max(maxim,dist[i]);
                q.push(i);
            }
        }
    }
}

int main()
{
    int n,i;
    cin>>n;
    for(i=1;i<n;i++)
    {
        int x,y;
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    bfs(1);
    for(i=1;i<=n;i++)
        viz[i]=false;
    bfs(leaf);
    cout<<maxim;
    return 0;
}
