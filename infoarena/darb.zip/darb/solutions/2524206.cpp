#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int> v[100005];
int a[100005];
int viz[100005];
int best, bestpoz;
int n;

void DFS(int k)
{
    viz[k] = 1;
    for (auto i : v[k])
        if (viz[i] == 0)
    {
        a[i] = a[k] + 1;
        DFS(i);
    }
}
int Maxim()
{
    int maxim = 1;
    for(int i = 1; i <= n; i++)
        if(a[maxim] < a[i])
            maxim = i;
    return maxim;
}

int main()
{
    int x, y;
    fin >> n;
    for(int i = 1; i < n; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    a[1] = 0;
    DFS(1);
    x = Maxim();
    a[x] = 0;
    for(int i = 1; i <= n; i++)
        viz[i] = 0;
    DFS(x);
    fout << a[Maxim()] + 1;

    return 0;
}
