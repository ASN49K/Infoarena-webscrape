#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

using namespace std;
ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int MAXN=1000005;
int n, x, y;
vector<int> g[MAXN];
queue<int>q;
int viz[MAXN], frunza;

void bfs(int start_node)
{
    memset(viz, 0, MAXN);
    q.push(start_node);
    viz[start_node]=1;
    while(!q.empty())
    {
        int crt_node=q.front();
        frunza=crt_node;
        q.pop();
        for(auto &v: g[crt_node])
            if(viz[v]==0){
                viz[v]=viz[crt_node]+1;
                q.push(v);
            }
    }
}
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    bfs(1);
    bfs(frunza);
    fout<<viz[frunza];
    return 0;
}
