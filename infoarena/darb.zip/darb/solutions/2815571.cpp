#include <bits/stdc++.h>

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

#define maxi 100005

vector <int> LA[maxi];
int drum[maxi];
int nodmax ;
int dmax ;

void dfs_darb(int nod)
{

   for(int i = 0; i < LA[nod].size() ;i++)
   {
       if(drum[LA[nod][i]] == 0)
       {
           drum[LA[nod][i]] = drum[nod] + 1;
           if(drum[LA[nod][i]] >= dmax)
           {
               dmax = drum[LA[nod][i]];
               nodmax = LA[nod][i];
           }
           dfs_darb(LA[nod][i]);
       }
   }
}

int main()
{

    int n;
    in>>n;
    for(int i = 1 ; i < n ; i++)
    {
        int a,b;
        LA[a].push_back(b);
        LA[b].push_back(a);
    }
    //cout<<11;
    drum[1] = 1;
    dfs_darb(1);

    dmax = 0;
    memset(drum ,0 , sizeof(drum));


    drum[nodmax] =1;
    dfs_darb(nodmax);

    out<<dmax;
    return 0;
}
