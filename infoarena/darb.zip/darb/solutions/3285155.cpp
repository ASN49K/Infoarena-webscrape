#include <bits/stdc++.h>
using namespace std;

///aproapeperm
ifstream fin("darb.in");
ofstream fout("darb.out");

int n;
int d[100005];
bitset<100005> viz;
vector<int> L[100005];

void DFS(int k)
{
    viz[k] = 1;
    for (int i : L[k])
        if (viz[i] == 0)
        {
            d[i] = d[k] + 1;
            DFS(i);
        }
}

int main()
{
    int i, j, k, Max;
    fin >> n;
    for (k = 1; k < n; k++)
    {
        fin >> i >> j;
        L[i].push_back(j);
        L[j].push_back(i);
    }
    DFS(1);
    Max = -1;
    for (i = 1; i <= n; i++)
        if (d[i] > Max)
        {
            Max = d[i];
            k = i;
        }

    viz.reset();
    d[k] = 1;
    DFS(k);
    Max = -1;
    for (i = 1; i <= n; i++)
        if (d[i] > Max)
            Max = i;
    fout << Max << "\n";
    return 0;
}
