#include <fstream>
#include <vector>
using namespace std;
vector<int> L[100010];
int n,x,y,maxim;
void dfs(int crt, int t, int d){
    if (d>maxim){
        maxim=d;
        x=crt;
    }
    for (int i=0;i<L[crt].size();i++){
        int vecin=L[crt][i];
        if (vecin!=t){
            dfs(vecin,crt,d+1);
        }
    }
}
int main () {
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    fin>>n;
    for (int i=1;i<n;i++){
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1,0,1);
    maxim=0;
    dfs(x,0,1);
    fout<<maxim;
    return 0;
}
