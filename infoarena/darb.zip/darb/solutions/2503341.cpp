#include <fstream>
#include <vector>
#define dim 100000
using namespace std;
vector<int> a[dim];
int f[dim];
int d[dim];
int i,n,Max,sol,x,y;

void stergere (int a[],int n) {
    for (int i=1;i<=n;i++) a[i]=0;
}

void dfs (int nod,int nivel) {
    f[nod]=1;
    if (nivel>Max) {
        Max=nivel;
        sol=nod;
    }
    for (int i=0;i<a[nod].size();i++) {
        int vecin=a[nod][i];
        if (f[vecin]==0) {
            dfs(vecin,nivel+1);
        }
    }
}

int main() {
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>x>>y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    dfs(1,1);
    stergere(f,n);
    dfs(sol,1);
    fout<<Max;
    return 0;
}
