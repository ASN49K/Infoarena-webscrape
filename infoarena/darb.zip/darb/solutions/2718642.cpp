#include <bits/stdc++.h>

using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
vector<int>v[100005];
int viz[100005],caz,rez,y,n,i,a,b;
void dfs(int x,int l)
{
    viz[x]=caz;
    if(l>rez)rez=l,y=x;
    for(int i=0; i<v[x].size(); i++)if(viz[v[x][i]]!=caz)dfs(v[x][i],l+1);

}
int main()
{
    f>>n;
    for(i=1; i<=n; i++)
    {
        f>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    caz=1;
    dfs(1,1);
    caz=2;
    dfs(y,1);
g<<rez;
}

