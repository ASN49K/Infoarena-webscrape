#include <bits/stdc++.h>
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
const int NMAX=100005;
int n,x,y,last,diametru,viz[NMAX],contor[NMAX];
vector<int>v[NMAX];
queue<int>q;
void bfs(int x)
{
    memset(contor,0,NMAX);
    memset(viz,0,NMAX);
    q.push(x);
    contor[x]=1;
    viz[x]=1;
    while(!q.empty())
    {
        x=q.front();
        q.pop();
        for(int i=0;i<v[x].size();i++)
            if(viz[v[x][i]]==0)
        {
            q.push(v[x][i]);
            contor[v[x][i]]=contor[x]+1;
            viz[v[x][i]]=1;
            diametru=contor[v[x][i]];
            last=v[x][i];
        }
    }
}
int main()
{
    f>>n;
    for(int i=1;i<n;i++)
    {
        f>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    bfs(1);
    bfs(last);
    g<<diametru;
    return 0;
}
