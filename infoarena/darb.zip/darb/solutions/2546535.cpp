#include <fstream>
#include <vector>
#define NM 100003
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
int pas,max1,n,i,x,y;
int fr[NM];
vector < int > a[NM];
void dfs(int nod,int lg){
  fr[nod]=pas;
  if(lg>max1){
    max1=lg; x=nod;
  }
  for(i=0;i<a[nod].size();i++){
    y=a[nod][i];
    if(fr[y]!=pas) dfs(y,lg+1);
  }
}
int main()
{
    f>>n;
    for(i=1;i<=n;i++){
        f>>x>>y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    pas=1; max1=0;
    dfs(1,1);
    pas=2; max1=0;
    dfs(x,1);
    g<<max1<<'\n';
    return 0;
}
