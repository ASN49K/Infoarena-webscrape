#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");
vector <int> v[100009];
int sol[100009], n;
void bfs (int nod)
{
    queue <int> q;
    for (int i=1; i<=n; i++)
        sol[i]=1e9;
    sol[nod]=1;
    q.push(nod);
    while (!q.empty())
    {
        int x=q.front();
        q.pop();
        for (int i=0; i<v[x].size(); i++)
        {
            int y=v[x][i];
            if (sol[x]+1<sol[y])
            {
                sol[y]=sol[x]+1;
                q.push(y);
            }
        }
    }
}
signed main ()
{
    f >> n;
    for (int i=1; i<=n; i++)
    {
        int x, y;
        f >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    bfs (1);
    int maxim=0, dmax=0;
    for (int i=1; i<=n; i++)
    {
        if (sol[i]>maxim)
        {
            maxim=sol[i];
            dmax=i;
        }
    }
    bfs (dmax);
    int ans=0;
    for (int i=1; i<=n; i++)
        ans=max(ans, sol[i]);
    g << ans;
}
