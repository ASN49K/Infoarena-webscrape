#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
const int N=1e5+1;
vector<int> v[N];
int vc[N];
void dfs(int nod)
{
    for(auto nod2:v[nod])
        if(!vc[nod2]){
            vc[nod2]=vc[nod]+1;
            dfs(nod2);
        }
}
int main()
{
    int n,i,x,y,maxi=0;
    fin>>n;
    for(i=1;i<n;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    vc[1]=1;
    dfs(1);
    for(i=1;i<=n;i++)
    {
        if(vc[i]>maxi)
        {
            maxi=vc[i];
            x=i;
        }
        vc[i]=0;
    }
    maxi=0;
    vc[x]=1;
    dfs(x);
    for(i=1;i<=n;i++)
        maxi=max(maxi,vc[i]);
    fout<<maxi;
    return 0;
}
