#include <bits/stdc++.h>

using namespace std;

vector<int> adj[100005];
int n, viz[100005], last, cnt[100005], solution = -1;

ifstream in("darb.in");
ofstream out("darb.out");

queue<int> q;


void bfs(int start) {
    memset(cnt, 0, 100001);
    memset(viz, 0, 100001);
    cnt[start] = 1;

    q.push(start);
    viz[start] = 1;
    while(!q.empty()) {
        int node = q.front();
        q.pop();

        if (cnt[node] > solution) {
            solution = cnt[node];
            last = node;
        }

        for (auto neigh : adj[node]) {
            if (viz[neigh] == 0) {
                q.push(neigh);
                viz[neigh] = 1;
                cnt[neigh] = cnt[node] + 1;
            }
        }
    }

}

int main() {
    in >> n;
    for (int i = 1, x, y; i <= n - 1; i++) {
        in >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    bfs(1);
    bfs(last);
    out << solution;

}
