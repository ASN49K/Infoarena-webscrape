#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int NMAX=1000001;

ifstream f("darb.in");
ofstream g("darb.out");

int n,dist[NMAX],ult;
bool viz[NMAX];
vector<int> lista[NMAX];
queue<int> coada;

void citire()
{
    int x,y;
    f>>n;
    for(int i=1;i<n;i++)
    {
        f>>x>>y;
        lista[x].push_back(y);
        lista[y].push_back(x);

    }
}

void bfs(int x)
{
    viz[x]=1;
    dist[x]=1;
    coada.push(x);
    while(!coada.empty())
    {
        int crt=coada.front();
        for(auto &it:lista[crt])
        {
            if(viz[it]==0)
            {
                coada.push(it);
                dist[it]=dist[crt]+1;
                viz[it]=1;
                ult=it;
            }
        }
        coada.pop();
    }
}

int main()
{

    citire();
    bfs(1);
    for(int i=1;i<=n;i++)
        viz[i]=0;
    bfs(ult);
    g<<dist[ult];
    f.close();
    g.close();

    return 0;
}
