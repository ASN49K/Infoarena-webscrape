#include <bits/stdc++.h>
using namespace std;
ifstream in ("darb.in");
ofstream out ("darb.out");
vector <int> v[100001];
bool viz[100001];
int last_node;
int first_max = 0, node = 0;
int max_d;
void dfs (int nod, int depth)
{
    viz[nod] = true;
    if (depth > first_max)
        first_max = depth, node = nod;
    for (auto vecin:v[nod])
        if (!viz[vecin])
            dfs(vecin, depth + 1);
}
void dfs1(int nod, int depth)
{
    viz[nod] = true;
    max_d = max (max_d, depth);
    for (auto vecin:v[nod])
        if (!viz[vecin])
            dfs1(vecin, depth + 1);
}
main ()
{
    int n;
    in >> n;
    for (int i = 1;i<n;++i)
    {
        int a, b;
        in >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    dfs(1, 1);
    for (int i = 1;i<=n;++i)
        viz[i] = 0;
    dfs1(node, 1);
    out << max_d;
    return 0;
}
