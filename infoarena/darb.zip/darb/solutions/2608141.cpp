#include <bits/stdc++.h>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

const int N = 100001;

vector <int> v[N];
bool viz[N];
int n, maxx, frunza;

void dfs(int nod, int lg)
{
    viz[nod] = 1;
    if(lg > maxx)
    {
        maxx = lg;
        frunza = nod;
    }
    for(int i = 0; i < v[nod].size(); ++ i)
    {
        int l = v[nod][i];
        if(!viz[l])
             dfs(l, lg + 1);
    }
}
int main()
{
    f >> n;
    for(int i = 1; i < n; ++ i)
    {
        int x, y;
        f >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1, 1);
    maxx = 0;
    memset(viz, 0, sizeof(viz));
    dfs(frunza, 1);
    g << maxx;
    return 0;
}
