#include <iostream>
#include <stdio.h>
using namespace std;
FILE *f,*g;
struct graph
{
    int node,next;
}v[200002];
int start[100002],been[100002];
int n,var;
void read()
{
    int k=0,x,y;
    fscanf(f,"%d",&n);
    for(int i=1; i<n; i++)
    {
        fscanf(f,"%d %d",&x,&y);
        v[++k].node=y;
        v[k].next=start[x];
        start[x]=k;
        v[++k].node=x;
        v[k].next=start[y];
        start[y]=k;
    }
}
void dfs(int nod, int lg)
{
    been[nod]=lg;
    var=nod;
    for(int i=start[nod]; i; i=v[i].next)
        if(!been[v[i].node])
            dfs(v[i].node,lg+1);
}
void solve()
{   int maxi=0;
    dfs(1,1);
    for(int i=1; i<=n; i++)
    {
        if(been[i]>maxi)
            maxi=been[i],var=i;
        been[i]=0;
    }
    dfs(var,1);
    fprintf(g,"%d",been[var]);
}
int main()
{
    f=fopen("darb.in","r");
    g=fopen("darb.out","w");
    read();
    solve();
   // write();
    fclose(f);
    fclose(g);
    return 0;
}
