#include <iostream>
#include <fstream>
#include<bits/stdc++.h>
using namespace std;

#define NMAX 500

ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int> ma[NMAX];
int viz[NMAX];
int n;

void citire()
{
   fin>>n;
   for(int i=1;i<=n-1;i++)
   {
      int x,y;
      fin>>x>>y;
      ma[x].push_back(y);
      ma[y].push_back(x);
   }
}

void BFS(int i)
{
   queue<int> q;
   q.push(i);
   viz[i] = 1;

   while(!q.empty())
   {
      int nod = q.front();
      q.pop();
      for(int i=0;i<ma[nod].size();i++)
      {
         if(!viz[ma[nod][i]])
         {
            viz[ma[nod][i]] = viz[nod] + 1;
            q.push(ma[nod][i]);
         }
      }

   }

}

int main()
{
   citire();

   BFS(1);
   int imax=1,max = viz[1];
   for(int i = 2;i<=n;i++)
   {
      if(viz[i] > max)
      {
         max = viz[i];
         imax = i;
      }
   }
   for(int i=1;i<=n;i++)
      viz[i] = 0;

   BFS(imax);
   max = viz[1];
   for(int i = 2;i<=n;i++)
      if(max < viz[i])
      {
         max = viz[i];
      }

   fout<<max;

   return 0;
}
