#include <bits/stdc++.h>
#pragma GCC optimize("O3")

#define nozerous(x) (x & -x)
#define MOD 666013
#define M_PI           3.14159265358979323846
#define EPS 0.0001
using namespace std;

const int INF = (1 << 30), NMAX(100005);
using VI  = vector<int>;
using VVI = vector<VI>;
using VB  = vector<bool>;
using Point = array<int, 2>;
using ll = long long;

void BUNA(const string& task = "")
{
    if (!task.empty())
        freopen((task + ".in").c_str(), "r", stdin),
                freopen((task + ".out").c_str(), "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
}
void PA()
{
    exit(0);
};
VI G[NMAX];
int maxx, wh;
void DFS(int nod, int tata, int nrD)
{
    bool ok = 0;
    for(auto it: G[nod])
        if(it != tata)
        {
            DFS(it, nod, nrD + 1);
            ok = 1;
        }
    if(!ok && nrD > maxx)
    {
        maxx = nrD;
        wh = nod;
    }
}

void DFS2(int nod, int tata, int nrD){
    for(auto it: G[nod])
        if(it != tata)
            DFS2(it, nod, nrD + 1);
    maxx = max(maxx, nrD);
}

int main()
{
    BUNA("darb");
    int n;
    cin >> n;

    for(int i = 1; i < n; ++i)
    {
        int x, y;
        cin >> x >> y;

        G[x].push_back(y);
        G[y].push_back(x);
    }

    DFS(1, 0, 1);
    DFS2(wh, 0, 1);

    cout << maxx << '\n';
    PA();
}
