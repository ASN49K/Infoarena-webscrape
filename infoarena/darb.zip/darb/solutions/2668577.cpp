#include<iostream>
#include<fstream>
#include<vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

//#define fin cin

int node;
vector<vector<int>> legs;
vector<int> viz;
int md;

void dfs(int n, int d){
	if(d>md){
		md=d;
		node=n;
	}
	if(legs[n].size()==2){
		if(viz[legs[n][0]]==0){
			dfs(legs[n][0],d+1);
		}
		else{
			dfs(legs[n][1],d+1);
		}
	}
}

int main(){
	int n,x,y;
	fin>>n;
	legs.resize(n+1);
	for(int i=0;i<n-1;++i){
		fin>>x>>y;
		legs[x].push_back(y);
		legs[y].push_back(x);
	}
	dfs(1,1);
	md=1;
	dfs(node,1);
	fout<<md<<"\n";
	fin.close();
	fout.close();
	return 0;
}