#include<iostream>
#include<fstream>
#include<vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

//#define fin cin

int node;
vector<vector<int>> legs;
vector<int> viz;
int md;

void dfs(int n, int d){
	//cout<<n<<" "<<d<<"\n";
	if(d>md){
		md=d;
		node=n;
	}
	for(int i=0;i<legs[n].size();++i){
		if(viz[legs[n][i]]==0){
			viz[legs[n][i]]=1;
			dfs(legs[n][i],d+1);
		}
	}
}

int main(){
	int n,x,y;
	fin>>n;
	legs.resize(n+1);
	viz.resize(n+1);
	for(int i=0;i<n-1;++i){
		fin>>x>>y;
		legs[x].push_back(y);
		legs[y].push_back(x);
	}
	dfs(1,1);
	md=1;
	viz.clear();
	viz.resize(n+1);
	dfs(node,1);
	fout<<md<<"\n";
	fin.close();
	fout.close();
	return 0;
}