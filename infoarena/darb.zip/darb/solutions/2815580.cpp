#include<bits/stdc++.h>

using namespace std;


ifstream in ("darb.in");
ofstream out ("darb.out");

#define maxi 100001

vector<int> LA[maxi];

int drum[maxi];
int dmax, nodmax;



void DFS_Darb(int curr)
{

    for(int i = 0; i < LA[curr].size(); i++)
    {
        if(!drum[LA[curr][i]])
        {
            drum[LA[curr][i]]=drum[curr] + 1;
            if(drum[LA[curr][i]] >= dmax)
            {
                dmax=drum[LA[curr][i]];
                nodmax = LA[curr][i];
            }
            DFS_Darb(LA[curr][i]);
        }
    }
}

int main()
{
    int n;
    in>>n;

    for(int i=1; i<=n-1; i++)
    {
        int a,b;
        in>>a>>b;
        LA[a].push_back(b);
        LA[b].push_back(a);
    }
    drum[1]=1;
    DFS_Darb(1);

    dmax = 0;
    memset(drum,0,sizeof(drum));

    drum[nodmax] = 1;
    DFS_Darb(nodmax);

    out <<dmax;
    return 0;

}

