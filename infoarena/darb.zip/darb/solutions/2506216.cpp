#include <fstream>
#include <vector>
#include <cstring>


using namespace std;

vector <int> g[1005];
int viz[1005],mx,nod;

ifstream cin("darb.in");
ofstream cout("darb.out");

void dfs(int x,int h)
{
    if(h>mx)
    {
        nod=x;
        mx=h;
    }
    viz[x]=1;
    for(int i=0;i<g[x].size();++i)
    {
        int y=g[x][i];
        if(viz[y]==0)
            dfs(y,h+1);
    }
}

int main()
{
    int n,a,b;
    cin>>n;
    for(int i=1;i<n;i++)
    {
        cin>>a>>b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs(1,0);
    memset(viz,0,sizeof(viz));
    dfs(nod,0);
    cout<<mx;
    return 0;
}
