#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream in ("darb.in");
ofstream out ("darb.out");
vector <int> v[100001];
bool viz[100001];
int last_node;
int max_d;
void dfs (int nod)
{
    last_node = nod;
    for (auto it:v[nod])
        if (!viz[it])
        {
            viz[it] = 1;
            dfs(it);
        }
}
void dfs1(int nod, int depth)
{
    max_d = max (max_d, depth);
    for (auto vecin:v[nod])
        if (!viz[vecin])
        {
            viz[vecin] = 1;
            dfs1(vecin, depth + 1);
        }
}
main ()
{
    int n;
    in >> n;
    for (int i = 1;i<n;++i)
    {
        int a, b;
        in >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    dfs(1);
    for (int i = 1;i<=n;++i)
        viz[i] = 0;
    dfs1(last_node, 1);
    out << max_d;
    return 0;
}
