#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n,d;
vector<int> L[100005];
int dp[100005];

void dfs(int nod, int tata)
{
    int max1 = 0, max2 = 0;
    for(auto it: L[nod])
    {
        if(it != tata)
        {
            dfs(it, nod);
            if(max1 < dp[it])
                max2 = max1, max1 = dp[it];
            else if(max2 < dp[it])
                max2 = dp[it];
        }
        dp[nod] = max1 + 1;
        d = max(d, max1 + max2 + 1);
    }
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        int x, y;
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1, 0);
    fout<<d;
    return 0;
}
