#include <fstream>
#include <vector>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
int d[100005],i,n,mx,mx_nod,x,y;
bool viz[100005];
vector<int> v[100005];
void dfs(int nod)
{
    viz[nod]=1;
    for(auto x:v[nod])
    {
        if(!viz[x])
        {
            d[x]=d[nod]+1;
            if(d[x]>mx) {mx=d[x];mx_nod=x;}
            dfs(x);
        }
    }
}
int main()
{
    cin>>n;
    for(i=1;i<=n-1;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1);
    for(i=1;i<=n;i++)
    {
        viz[i]=0;
        d[i]=1;
    }
    dfs(mx_nod);
    cout<<mx;
    return 0;
}
