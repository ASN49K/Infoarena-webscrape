#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#define NMAX 100000

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, ans, viz[NMAX+10];
vector <int> nod[NMAX+10];
queue <int> Q;

int bfs(int x)
{	ans = 0;
	for(int i=1; i<=n; i++)
		viz[i] = 0;
	viz[x] = 1;
	Q.push(x);
	while(!Q.empty())
		{	int a = Q.front();
			Q.pop();
			for(auto u : nod[a])
				if(!viz[u])
					{	ans = max(ans, viz[a] + 1);
						viz[u] = viz[a] + 1;
						Q.push(u);
					}
			if(Q.empty())
				return a;
		}
}

int main()
{
	fin >> n;
	for(int i=1; i<n; i++)
		{	int nod1, nod2;
			fin >> nod1 >> nod2;
			nod[nod1].push_back(nod2);
			nod[nod2].push_back(nod1);
		}
	int x = bfs(1);
	x = bfs(x);
	fout << ans << '\n';
	return 0;
}