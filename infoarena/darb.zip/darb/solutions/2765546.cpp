#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");
#define cin fin
#define cout fout

#define N 100005
int n, x, y, marcat[N];
vector<int> a[N];

void dfs(int x, int precedent)
{
    marcat[x] = marcat[precedent]+1;
    for(int i = 0 ; i < a[x].size() ; i++)
    {
        if(a[x][i] != precedent)
        {
            dfs(a[x][i],x);
        }
    }
}

int main()
{
    cin >> n ;
    for(int i = 1 ; i < n ; i++)
    {
        cin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    dfs(1,0);
    y = 0;
    for(int i = 1 ; i <= n ; i++)
    {
        if(marcat[i] > y)y = marcat[i] , x = i;
        marcat[i] = 0;
    }
    dfs(x,0);
    y = 0;
    for(int i = 1 ; i <= n ; i++)
    {
        y = max(marcat[i],y);
    }
    cout << y;
    return 0;
}
