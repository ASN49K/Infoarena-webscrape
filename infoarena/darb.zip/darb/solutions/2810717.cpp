#include<bits/stdc++.h>

using namespace std;

ifstream fin ("darb.in");
ofstream fout ("darb.out");


vector<int> lista_adiacenta[100005];
int vizitat[100005];
int dist_max, nod_departe;

void DFS(int curr)
{
    for(int i = 0; i < lista_adiacenta[curr].size(); i++)
    {
        if(vizitat[lista_adiacenta[curr][i]] == 0)
        {
            vizitat[lista_adiacenta[curr][i]]=vizitat[curr];
            vizitat[lista_adiacenta[curr][i]]++;
            if(vizitat[lista_adiacenta[curr][i]] > dist_max)
            {
                nod_departe = lista_adiacenta[curr][i];
                dist_max=vizitat[lista_adiacenta[curr][i]];
            }
            DFS(lista_adiacenta[curr][i]);
        }
    }
}

int main()
{
    int n;
    fin>>n;
    for(int i=1; i<=n-1; i++)
    {
        int a,b;
        fin>>a>>b;
        lista_adiacenta[a].push_back(b);
        lista_adiacenta[b].push_back(a);
    }
    vizitat[1]=1;
    DFS(1);
    dist_max = 0;
    memset(vizitat,0,sizeof(vizitat));
    vizitat[nod_departe] = 1;
    DFS(nod_departe);
    fout <<dist_max;
    return 0;
}
