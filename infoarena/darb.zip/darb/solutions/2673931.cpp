#include <bits/stdc++.h>

using namespace std;

// struct node {
//   int key;
//   node *left, *right;
//   node(int key) {
//     this->key = key;
//     left = right = NULL;
//   }
// }

//node* root;//arbore binar, mai intai!

int bfs(int nod, int n, vector<int> p) {
  queue<int> nods;
  vector<int> dist(n+1, 0);
  vector<bool> used(n+1, 0);
  used[nod] = true;
  nods.push(nod);
  while(!nods.empty()) {
    int nodActual = nods.front();
    nods.pop();
    for(int i=1; i<=n; i++) {
      if(p[i] == nodActual and used[i] != true) {
        nods.push(i);
        used[i] = true;
        dist[i] = dist[p[i]] + 1;
      }
    }
    if(p[nodActual] != 0 and used[p[nodActual]]!=true) {
      nods.push(p[nodActual]);
      used[p[nodActual]] = true;
      dist[p[nodActual]] = dist[nodActual] + 1;
    }
  }

  int maxim = 0;
  for(int i=1; i<=n; i++)
    maxim = max(maxim, dist[i]);
  // cout << "Pornind de la " << nod << "avem urmatorele distante" << "\n";
  // for(int i=1; i<=n; i++)
  //   cout << i << " " << dist[i] << "\n";
  dist.clear();
  used.clear();
  return maxim;
}

int main() {
  freopen("darb.in", "r", stdin);
  freopen("darb.out", "w", stdout);
  int n;
  cin >> n;
  vector<int> p(n+1);
  for(int i=1; i<=n; i++) {
    int copil, parinte;
    cin >> parinte >> copil;
    p[copil] = parinte;
  }
  int maxim = 0;
  for(int i=1; i<=n; i++) {
    maxim = max(maxim, bfs(i, n, p));
  }
  cout << maxim + 1;

  return 0;
}
