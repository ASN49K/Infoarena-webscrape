#include <bits/stdc++.h>
#define rpd ios_base :: sync_with_stdio(0); cin.tie(0);
#define ll long long
#define int ll
#define fs first
#define sc second
#define pb push_back
#define NMAX 100000+5
#define mod int(1e9)+7
using namespace std;

ifstream in("darb.in");
ofstream out("darb.in");

int nnod;
vector<int>G[NMAX];
vector<int>dist(NMAX);
queue<int>q;

int bfs(int nod)
{

    q.push(nod);
    dist[nod]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(int i=0;i<G[nod].size();i++)
        {
            if(dist[G[nod][i]]==0){dist[G[nod][i]]=dist[nod]+1;q.push(G[nod][i]);nnod=G[nod][i];}
        }
    }
}


main()
{
    rpd;
    ll n;
    in>>n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        in>>x>>y;
        G[x].pb(y);
        G[y].pb(x);
    }
    bfs(1);
    for(int i=1;i<=n;i++)dist[i]=0;
    int maxi=0;
    bfs(nnod);
    for(int i=1;i<=n;i++)
        if(dist[i]>maxi)maxi=dist[i];
    out<<maxi;
    return 0;
}
