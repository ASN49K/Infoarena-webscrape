#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
const int nmax=1e5;
int n, a[nmax], nod, dm;
vector<int> g[nmax];
queue<int> q;
void bfs(int k) {
        q.push(k);
        dm=a[k];
        a[k]=1;
        while(!q.empty()) {
                int k=q.front();
                q.pop();
                for(auto i:g[k])
                        if(!a[i]) {
                                q.push(i);
                                a[i]=a[k]+1;
                                nod=i;
                                dm=max(dm, a[i]);
                        }
        }
}
int main() {
        cin>>n;
        int x, y;
        for(int i=1; i<n; i++) {
                cin>>x>>y;
                g[x].push_back(y);
                g[y].push_back(x);
        }
        bfs(1);
        for(int i=1; i<=n; i++)
                a[i]=0;
        bfs(nod);
        cout<<dm;
        return 0;
}
