#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream in("darb.in");
ofstream out("darb.out");

vector<int> v[100001];

int n,viz1[100001],viz2[100001],c[100001];
int bfs(int nod, int viz[])
{
  int pr=1, ul=1;
  c[ul]=nod; viz[nod]=1;
  int maxim=1;
  while(pr<=ul)
  {
    int x=c[pr];
    pr++;
    int lg=v[x].size();
    for(int i=0; i<lg; i++)
    {
      int vec = v[x][i];
      if(!viz[vec])
      {
        viz[vec]=viz[x]+1;
        if(viz[vec]>maxim)maxim=viz[vec];
        c[++ul]=vec;
      }
    }
  }
  return maxim;
}

int main(){  
   
    int x,y;
     in>>n;
     for(int i=1; i<n; i++)
     {
       in>>x>>y;
       v[x].push_back(y);
       v[y].push_back(x);
     }
     int d1=bfs(1,viz1);
     for(int i=1; i<=n; i++)
        if(viz1[i]==d1)x=i;
     
     out<<bfs(x,viz2);
     
     return 0;
}