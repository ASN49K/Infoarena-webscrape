#include <bits/stdc++.h>

const char* inputFile = "darb.in";
const char* outputFile = "darb.out";

unsigned N, dest;

#define NMAX 100000
std::vector<unsigned> adj[NMAX], dist;
std::vector<bool> viz;
#undef NMAX

void dfs(unsigned src)
{
    for(unsigned i = 0; i < adj[src].size(); ++i)
    {
        unsigned curr = adj[src][i];
        if(!viz[curr])
        {
            dist[curr] = dist[src] + 1;
            if(dist[curr] > dist[dest])
                dest = curr;
            viz[curr] = true;
            dfs(curr);
        }
    }
}

int main(void)
{
    FILE* pf = fopen(inputFile, "r");
    fscanf(pf, "%u", &N);
    #define pb push_back
    for(unsigned i = 1; i + 1 <= N; ++i)
    {
        unsigned u, v;
        fscanf(pf, "%u%u", &u, &v);
        adj[u].pb(v), adj[v].pb(u);
    }
    #undef pb
    fclose(pf);
    viz.resize(N + 1);
    viz[1] = true;
    dist.resize(N + 1);
    dest = dist[1] = 1;
    dfs(1);
    viz.assign(N + 1, false);
    viz[dest] = true;
    dist[dest] = 1;
    dfs(dest);
    pf = fopen(outputFile, "w");
    fprintf(pf, "%u", dist[dest]);
    fclose(pf);
    return 0;
}
