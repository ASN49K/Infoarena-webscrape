#include <fstream>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
struct nod
{
    int info;
    nod *urm;
};
nod *p,*v[100005];
int n,i,j,q[100005],viz[100005],maxi,poz;
void citire(int i,int j)
{
    nod *q;
    q=new nod;
    q->info=j;
    q->urm=v[i];
    v[i]=q;
}
void BFS(int start)
{
    int x,st=1,dr=1;
    q[st]=start;
    viz[start]=1;
    while (st<=dr)
    {
        x=q[st++];
        p=v[x];
        while (p!=NULL)
        {
            if (viz[p->info]==0)
            {
                q[++dr]=p->info;
                viz[p->info]=viz[x]+1;
            }
            p=p->urm;
        }
    }

}
int main()
{
    fin>>n;
    while (fin>>i>>j)
    {
        citire(i,j);
        citire(j,i);
    }
    BFS(1);
    maxi=0;
    poz=0;
    for (i=1;i<=n;i++)
    {
        if (viz[i]>maxi)
            maxi=viz[i],poz=i;
        viz[i]=0;
    }
    BFS(poz);
    maxi=0;
    poz=0;
    for (i=1;i<=n;i++)
    {
        if (viz[i]>maxi)
            maxi=viz[i],poz=i;
        viz[i]=0;
    }
    fout<<maxi;
    return 0;
}
