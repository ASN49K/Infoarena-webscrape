#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n,x,y,ant,use[100010];
vector <int> v[100010];
void dfs(int nod, int niv)
{
    if(niv>ant)
    {
        ant=niv;
        x=nod;
    }
    use[nod]=1;
    for(auto it : v[nod])
        if(!use[it])
            dfs(it,niv+1);
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1,1);
    memset(use,0,sizeof(use));
    ant=0;
    dfs(x,1);
    fout<<ant;
    return 0;
}
