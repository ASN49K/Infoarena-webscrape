#include <fstream>
#include <vector>
using namespace std;
ifstream cin("darb.in");
ofstream cout("darb.out");
vector <int> lista[100001];
int coada[100005],viz[100005];
int m,num;
void bfs(int np)
{
	int inc,sf,tata,i;
	inc=sf=1;
	coada[1]=np;
	viz[np]=1;
	while(inc<=sf)
	{
		tata=coada[inc];
		for(i=0;i<lista[tata].size();i++)
		if(viz[lista[tata][i]]==0)
		{
			sf++;
			coada[sf]=lista[tata][i];
			viz[lista[tata][i]]=viz[tata]+1;
			if(viz[lista[tata][i]]>m)
			{
				m=viz[lista[tata][i]];
				num=lista[tata][i];
			}
		}
		inc++;
	}
}
int main()
{
	int n,i,n1,n2;
	cin>>n;
	for(i=1;i<n;i++)
	{
		cin>>n1>>n2;
		lista[n1].push_back(n2);
		lista[n2].push_back(n1);
	}
	bfs(1);
	for(i=1;i<=n;i++)
	viz[i]=0;
	bfs(num);
	cout<<m;
    return 0;
}
