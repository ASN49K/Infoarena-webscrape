#include <fstream>
#include <vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector<int> vec[100005];
int rez[10005],n,lant[10005];

void dfs(int nodcrt,int parinte)
{
    int max1=0,max2=0;
    lant[nodcrt]=1;
    rez[nodcrt]=1;
    for(int i=0; i<vec[nodcrt].size(); i++)
    {
        int nodurm=vec[nodcrt][i];
        if(nodurm!=parinte)
        {
            dfs(nodurm,nodcrt);
            lant[nodcrt]=max(lant[nodcrt],lant[nodurm]+1);
            rez[nodcrt]=max(rez[nodcrt],rez[nodurm]);
            if(lant[nodurm]>max1)
            {
                max2=max1;
                max1=lant[nodurm];
            }
            else if(max2<lant[nodurm]) max2=lant[nodurm];
        }
    }
    rez[nodcrt]=max(rez[nodcrt],max1+max2+1);
}
int main()
{
    int a,b;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>a>>b;
        vec[a].push_back(b);
        vec[b].push_back(a);
    }
    dfs(1,-1);
    fout<<rez[1];
    fin.close();
    fout.close();
    return 0;
}
