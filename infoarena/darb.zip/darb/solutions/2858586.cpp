	
#include <iostream>
#include <vector>
#include <fstream>
 
using namespace std;
 
ifstream be("darb.in");
ofstream ki("darb.out");
int dmaxi, di, n;

vector<vector<int> > graf(100001);
 
void maxiszamolas(int *a)
{
    dmaxi = 0;
    di = 0;
    for(int i=0;i<n;i++)
    {
        if(a[i]>dmaxi)
        {
            dmaxi = a[i];
            di = i;
        }
    }
}
void breathfirst(int kcs)
{
    int ut[n+1];
    bool jart[n+1]={0};
    int d[n+1]={0};
    kcs--;
    int utolso=0,elso = 0;
    jart[kcs]=true;
    ut[elso]=kcs;

    while(elso<=utolso)
    {
        for(int i=0;i<graf[ut[elso]].size();i++)
        {
            if(!jart[graf[ut[elso]][i]])
            {
                ut[++utolso]=graf[ut[elso]][i];
                jart[graf[ut[elso]][i]] = true;
                d[graf[ut[elso]][i]] = d[ut[elso]]+1;
            }
        }
        elso++;
    }
    maxiszamolas(d);
}
int main()
{
    be>>n;
    int a,b;
    while(be>>a>>b)
    {
      graf[a-1].push_back(b-1);
      graf[b-1].push_back(a-1);
    }
    //outGraf(graf);
    breathfirst(1);
    breathfirst(di+1);
    ki<<dmaxi+1<<endl;
}