#include <bits/stdc++.h>
using namespace std;

vector <int> graph[200005];
int n, m, visited[200005], dist[200005];

void dfs(int currNode, int &maxi) {
    visited[currNode] = 1;
    for(int i = 0; i < graph[currNode].size(); ++i) {
        int neighbor_index = graph[currNode][i];
        if(!visited[neighbor_index]) {
            dist[neighbor_index] = dist[currNode] + 1;
            maxi = max(dist[neighbor_index], maxi);
            dfs(neighbor_index, maxi);
        }
    }
}

int main() {
    freopen("darb.in", "r", stdin);
    freopen("darb.out", "w", stdout);

    scanf("%d", &n);
    for(int i = 0; i < n - 1; ++i) {
        int x, y;
        scanf("%d%d", &x, &y);
        graph[x - 1].push_back(y - 1);
        graph[y - 1].push_back(x - 1);
    }

    int maxi = -1;
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; j++) {
            visited[j] = 0;
            dist[j] = 0;
        }
        if(graph[i].size()) {
            dist[i] = 1;
            dfs(i, maxi);
        }
    }

    printf("%d", maxi);
    return 0;
}