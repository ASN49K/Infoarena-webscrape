#include <fstream>
#include <vector>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n, m, i, x, y, viz[200005], nr, maxim, nodmax;
vector <int> v[200005];
void dfs(int nod, int adc)
{
    viz[nod]=adc;
    for(auto i:v[nod])
        if(viz[i]==0)
            dfs(i, adc+1);
}
void nodm(int &nodmax, int &distmax)
{
    for(int i=1; i<=n; i++)
   {
      if(maxim<viz[i])
      {
          maxim=viz[i];
          nodmax=i;
      }
      viz[i]=0;
   }
}
int main()
{
   fin>>n;
   for(i=1; i<n; i++)
   {
       fin>>x>>y;
       v[x].push_back(y);
       v[y].push_back(x);
   }
   dfs(1, 1);
   nodm(nodmax, maxim);
   dfs(nodmax, 1);
   nodm(nodmax, maxim);
   fout<<maxim<<" ";
    return 0;
}
