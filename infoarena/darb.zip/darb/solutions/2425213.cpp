#include <fstream>
//#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string>
#include <queue>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
const int inf=1e9;
int N,M,i,j,a,b,ultim,viz[100001],maxi=-1,nod_max;
vector <int> G[100001];
int BFS_1(int nod)
{
    queue<int> Q;
    Q.push(nod);
    while(!Q.empty())
    {
        int x;
        x=Q.front();
        Q.pop();
        for(i=0;i<G[x].size();i++)
        {
            if(viz[G[x][i]]==0)
            {
                viz[G[x][i]]=viz[x]+1;
                if(viz[G[x][i]]>maxi)
                {
                   maxi=viz[G[x][i]];
                   nod_max=G[x][i];
                }
                Q.push(G[x][i]);
            }
        }
        ultim=x;
    }
    return ultim;
}
int main()
{
    int t;
    fin>>M;
    for(i=1;i<=M;i++)
    {
        fin>>a>>b;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    t=BFS_1(1);
    for(i=0;i<100000;i++){viz[i]=0;}
    ultim=BFS_1(t);
    fout<<nod_max;
    return 0;
}
