#include <bits/stdc++.h>
using namespace std;

/**
Arbori
Def: arborele este un graf conex si fara cicluri
Un arbore cu n noduri are exact n-1 muchii

*/
vector<int> h[100001];
int n;
bitset<100001> viz;
int d[100001]; /// d[i] = distanta de la nodul de start
   /// la nodul i

void DFS(int k)
{
    viz[k] = 1;
    for (int i : h[k])
        if (viz[i] == 0)
        {
            d[i] = 1 + d[k];
            DFS(i);
        }
}

int Diametru()
{
    int i, p;
    d[1] = 1;
    DFS(1);
    /// determin nodul p care are d[p]=maxim
    p = 1;
    for (i = 2; i <= n; i++)
        if (d[i] > d[p]) p = i;
    viz.reset(); /// viz[i]=0, i=1..n
    d[p] = 1;
    DFS(p);
    p = 1;
    for (i = 2; i <= n; i++)
        if (d[i] > d[p]) p = i;
    return d[p];
}

int main()
{
    int i, j, k;
    ifstream fin("darb.in");
    ofstream fout("darb.out");
    fin >> n;
    for (k = 1; k < n; k++)
    {
        fin >> i >> j;
        h[i].push_back(j);
        h[j].push_back(i);
    }
    fout << Diametru() << "\n";
    fout.close();
    return 0;
}
