#include <fstream>
#include <vector>
#include <queue>
#include <time.h>

inline int next_int() {
	int n = 0;
	char c = getchar_unlocked();
	
	while (!('0' <= c && c <= '9')) {
		c = getchar_unlocked();
	}
	
	while ('0' <= c && c <= '9') {
		n = n * 10 + c - '0';
		c = getchar_unlocked();
	
	}

	return n;
}

inline void bfs(const int src, const int n, int &last_node, int &diametru, std::vector<int> distance, std::vector<int> *adj) {
	std::vector<bool> visited(n, false);
	std::queue<int> Q;
	Q.push(src);
	visited[src] = true;

	while (!Q.empty()) {
		int index = Q.front();
		Q.pop();

		for (auto it = adj[index].begin() ; it != adj[index].end() ; ++it) {
			if (!visited[*it]) {
				distance[*it] = distance[index] + 1;
				Q.push(*it);
				visited[*it] = true;
				last_node = *it;
				diametru = distance[*it];
			}
		}
	}
}

int main() {
	// std::ifstream cin("darb.in");
	// std::ofstream cout("darb.out");
	// std::ios::sync_with_stdio(false);
	freopen("darb.in", "r", stdin);
	freopen("darb.out", "w", stdout);
	srand((unsigned)time(NULL));
	int n, last_node, src, dest, diametru;
	n = next_int();
	std::vector<int> adj[n];
	std::vector<int> distance(n, 0);

	for (int i = 0 ; i < n - 1 ; ++i) {
		//cin >> src >> dest;
		src = next_int();
		dest = next_int();
		adj[src - 1].push_back(dest - 1);
		adj[dest - 1].push_back(src - 1);
	}

	int node = rand() % (n - 1);
	bfs(node, n, last_node, diametru, distance, adj);
	bfs(last_node, n, last_node, diametru, distance, adj);

	//cout << diametru  + 1 << '\n';
	printf("%d\n", diametru + 1);
	return 0;
}