#include <iostream>
#include <fstream>
#include <vector>
#define lim 100005

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

int n, dmax, marked[lim];
vector <int> v[lim];


void read()
{
    in>>n;
    for(int i=1; i<n; ++i)
    {
        int x, y;
        in>>x>>y;
        v[y].push_back(x);
        v[x].push_back(y);
    }
}

void dfs(int x, int d)
{
    if(d>dmax)
        dmax=d;
    marked[x]=1;
    for(int i=0; i<v[x].size(); ++i)
    {
        if(marked[v[x][i]]==0)
            dfs(v[x][i], d+1);
    }
    marked[x]=0;
}

int main()
{
    read();
    for(int i=1; i<=n; ++i)
    {
        dfs(i, 1);
    }
    out<<dmax<<" ";
    return 0;
}
