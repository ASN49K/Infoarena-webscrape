#include <bits/stdc++.h>
#define pb push_back

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

void debug_out() { cerr << '\n'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"

typedef pair<int,int> pii;
typedef long long int ll;
typedef long double ld;

const int DMAX = 1e5+10;

vector <int> vec;
vector <int> arb[DMAX];

int V[DMAX];

int n;
int nodul,ans;

void dfs(int node,int tata,int val);

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t,i,j;
    int x,y;

    fin>>n;
    for(i=1;i<n;i++){
        fin>>x>>y;
        arb[x].pb(y);
        arb[y].pb(x);
    }
    dfs(1,0,1);
    dfs(nodul,0,1);
    fout<<ans<<'\n';
    return 0;
}
void dfs(int node,int tata,int val){
    if(val > ans){
        ans=val;
        nodul=node;
    }
    for(auto& it:arb[node])
        if(it != tata)
            dfs(it,node,val+1);
}
