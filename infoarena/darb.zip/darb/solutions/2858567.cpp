#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

int csucsok,elek,leghoszabb;
vector<int > szm[500];
//faradt vagyok holnap modifikalom de ez a gyorsmodszer


void kiir(int *d )
{
    for(int i=1;i<=csucsok;i++)
    {
        cout<<d[i]<<" ";
    }
    cout<<endl;

}
void beolvas()
{
    in>>csucsok;
    elek=csucsok-1;
    int a,b;
    while(in>>a>>b)
    {

        szm[a].push_back(b);
        szm[b].push_back(a);
    }
}
int dmax(int *d)
{

    int maxi=0;
    int maxi_index=0;
        for(int i=1;i<=csucsok;i++)
        {
            if(d[i]>maxi)
            {
                maxi=d[i];
                maxi_index=i;
            }
        }
        leghoszabb=maxi;
        return maxi_index;

}

void szelessegi1(int csucs,bool volte)
{
    int sor[csucsok+1]={0};
    int d[csucsok+1]={0};
    int jart[csucsok+1]={0};
    int os [csucsok+1]={0};
    int elso=0,utolso=0;

jart[csucs]=1;
d[csucs]=0;
os[csucs]=0;
sor[elso]=csucs;
while(elso<=utolso){
    for(int i=0;i<szm[sor[elso]].size();i++)
    {
            if(!jart[szm[sor[elso]][i]])
            {
                sor[++utolso]=szm[sor[elso]][i];
                d[szm[sor[elso]][i]]=d[sor[elso]]+1;
                jart[szm[sor[elso]][i]]=true;
            }
    }
    elso++;
}
kiir(d);
if(volte)
{
    szelessegi1(dmax(d),0);
}
else dmax(d);

}

int main()
{
beolvas();
szelessegi1(1,1);
 cout<<"a leghoszabb ut: "<<leghoszabb;
out<<leghoszabb+1;

    return 0;
}
