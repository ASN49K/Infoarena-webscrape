#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin  ("darb.in");
ofstream fout ("darb.out");

vector <int> v[100005];
int n, ii, jj, maxx;
bool ok[100005];

void dfs(int nod, int len){
     if(len > maxx)
          maxx=len;

     ok[nod]=1;
     for(int i=0; i<v[nod].size(); i++)
          if(ok[v[nod][i]] == 0)
               dfs(v[nod][i], len+1);

     ok[nod]=0;
}

int main (){
     fin>>n;
     for(int i=1; i<n; i++){
          fin>>ii>>jj;
          v[ii].push_back(jj);
          v[jj].push_back(ii);
     }

     for(int i=1; i<=n; i++)
          dfs(i, 1);

     fout<<maxx;
     return 0;
}
