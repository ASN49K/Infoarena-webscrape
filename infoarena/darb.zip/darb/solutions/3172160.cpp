#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


ifstream fin("darb.in");
ofstream fout("darb.out");


int n;
long long dp[100005],sol;
bool viz[100005];
vector <int> g[100005];


void dfs(int nod,int tata)
{
    viz[nod]=1;
    dp[nod]=1;
    int s=g[nod].size();
    for(int i=0;i<s;i++)
    {
        int nnod=g[nod][i];
        if(!viz[nnod])
        {
            dfs(nnod,nod);
        }
        if(nnod!=tata)dp[nod]=max(dp[nod],dp[nnod]+1);
    }
    ///if(nod==3)cout<<dp[3]<<" "<<dp[1]<<" "<<dp[6];
}


void solve()
{
    fin>>n;
    int x,y;
    for(int i=1;i<n;i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=n;i++) dfs(i,i);
    for(int i=1;i<=n;i++)
    {
        ///cout<<dp[i]<<" ";
        sol=max(sol,dp[i]);
    }
    fout<<sol-1<<"\n";
}


int main()
{
    solve();
    return 0;
}
