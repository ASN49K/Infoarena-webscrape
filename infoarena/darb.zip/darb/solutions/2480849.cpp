#include <fstream>
#include <vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
vector<int> vecini[100005];

int raspuns[100005];
int lant[1000005];
int n;

void dfs(int nod_curent, int parinte)
{ 
    /// dfs cu nodul curent va fi apelat o singura data pentru ca fii lui il au ca parinte
    int maxi1 = 0, maxi2 = 0;   
    for(int i = 0; i < vecini[nod_curent].size(); i++)
    {
        int nod_urmator = vecini[nod_curent][i];
        if(nod_urmator != parinte) /// nu apelam dfs in parinte
        {
            dfs(nod_urmator, nod_curent);
            lant[nod_curent] = max(lant[nod_curent], lant[nod_urmator] + 1);
            raspuns[nod_curent] = max(raspuns[nod_curent], raspuns[nod_urmator]);
            if(raspuns[nod_urmator] > maxi1)
            {
                maxi2 = maxi1;
                maxi1 = raspuns[nod_urmator];
            }
            else if(raspuns[nod_urmator] > maxi2)
            {
                maxi2 = raspuns[nod_urmator];
            }
        }
    }
    raspuns[nod_curent] = max(lant[nod_curent], maxi1 + maxi2 + 1);
}

int main()
{
    fin >> n;
    for(int i = 1; i < n; i++)
    {
        int a,b;
        fin >> a >> b;
        vecini[a].push_back(b);
        vecini[b].push_back(a);
    }

    dfs(1, -1);
    fout << raspuns[1];

    return 0;
}
