#include <fstream>
#include <vector>
#include <queue>
#define pb push_back
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int NMAX=1e5+5;
int n;
vector<vector<int>>adj;
int nod;
int d;
void bfs(int start)
{
    int mx=-1;
    vector<int>distanta(NMAX,0);
    queue<int>q;
    distanta[start]=1;
    q.push(start);
    while(!q.empty())
    {
        int ind=q.front();
        q.pop();
        for(int i:adj[ind])
        {
            if(!distanta[i])
            {
                distanta[i]=distanta[ind]+1;
                if(distanta[i]>mx)
                {
                    mx=distanta[i];
                    d=mx;
                    nod=i;
                }
                q.push(i);
            }
        }
    }

}
int main()
{
    adj=vector<vector<int>>(NMAX);
    fin>>n;
    int a,b;
    while(fin>>a>>b)
    {
        adj[a].pb(b);
        adj[b].pb(a);
    }
    bfs(1);
    bfs(nod);
    fout<<d;
}