#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

#define NMAX 100005
int n, s;
vector<int> tree[NMAX];
queue<int> q;
int dmin[NMAX];

void read()
{
    cin>>n;
    int n1, n2;
    for(int i=0; i<n-1; i++)
    {
        cin>>n1>>n2;
        tree[n1].push_back(n2);
        tree[n2].push_back(n1);
    }
}

void newnode()
{
    int node=q.front();
    q.pop();
    for(auto &node2:tree[node])
        if(!dmin[node2])
    {
        dmin[node2]=dmin[node]+1;
        q.push(node2);
    }
}

void finds()
{
    s=1;
    dmin[s]=1;
    q.push(s);
    while(!q.empty())
    {
        newnode();
    }
    for(int i=1; i<=n; i++)
    {
        if(dmin[i]>dmin[s])
            s=i;
        dmin[i]=0;
    }

}

void findotheredge()
{
    q.push(s);
    dmin[s]=1;
    while(!q.empty())
        newnode();
    for(int i=1; i<=n; i++)
        if(dmin[i]>dmin[s])
            s=i;
}

int main()
{
    read();
    finds();
    findotheredge();
    cout<<dmin[s];
    return 0;
}
