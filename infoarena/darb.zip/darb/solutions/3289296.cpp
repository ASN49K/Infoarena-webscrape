#include <bits/stdc++.h>

using namespace std;

ifstream fin ( "darb.in" );
ofstream fout ( "darb.out" );

#define cin fin
#define cout fout
#define PB push_back

const int Nmax = 1e5 + 1;

vector<int> adj[Nmax];
int dist[Nmax];

void dfs( int nod, int parinte ) {
  dist[nod] = dist[parinte] + 1;
  for( int i = 0; i < adj[nod].size(); i ++ ) {
    int u = adj[nod][i];
    if( u != parinte )
      dfs( u, nod );
  }
}

int main()
{
    int n, i, u, v, nod, dist_max;

    cin >> n;
    for( i = 0; i < n - 1; i ++ ) {
      cin >> u >> v;
      adj[u].PB( v );
      adj[v].PB( u );
    }

    dist[0] = -1;
    dfs( 1, 0 );

    dist_max = 0;
    nod = 1;
    for( i = 2; i <= n; i ++ )
      if( dist[i] > dist_max ) {
        dist_max = dist[i];
        nod = i;
      }

    dfs( nod, 0 );

    dist_max = 0;
    for( i = 1; i <= n; i ++ )
      if( dist[i] > dist_max )
        dist_max = dist[i];

    cout << dist_max + 1 << '\n';
    return 0;
}
