#include <bits/stdc++.h>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
const int NMAX=1e5;
vector<int> mat[NMAX+5];
vector<int> dist(NMAX+5, 0);
int ans=0, last;
void bfs(int nod){
    queue<int> q;
    q.push(nod);
    dist[nod]=1;
    while(!q.empty()){
        nod=q.front();
        q.pop();
        for(auto it:mat[nod]){
            if(dist[it]==0){
                dist[it]=dist[nod]+1;
                q.push(it);
                if(ans<dist[it]){
                    ans=dist[it];
                    last=it;
                }
            }
        }
    }

}
int main(){
    int n;
    fin>>n;
    for(int i=1;i<n;i++){
        int x, y;
        fin>>x>>y;
        mat[x].push_back(y);
        mat[y].push_back(x);
    }
    bfs(1);
    dist.clear();
    dist.resize(NMAX+5);
    bfs(last);
    fout<<ans;

}
