#include <bits/stdc++.h>

using namespace std;
vector<int> graf[100005];
int dist_rad[100005],rad;
ifstream fin("darb.in");
ofstream fout("darb.out");
void dfs(int nod,int parinte)
{
    dist_rad[nod]=dist_rad[parinte]+1;
    for(auto a:graf[nod])
    {
        if(a!=parinte)
        {
            dfs(a,nod);
        }
    }
}
int main()
{
    int n,ans=0,nod1,nod2,maxim=0,i;
    fin>>n;
    for( i=1;i<=n;++i)
    {
        fin>>nod1>>nod2;
        graf[nod1].push_back(nod2);
        graf[nod2].push_back(nod1);
    }
    dist_rad[0]=0;
    rad=1;
    dfs(1,0);
    for(i=1;i<=n;++i)
    {
        if(dist_rad[i]>maxim)
        {
            maxim=dist_rad[i];
            rad=i;
            dist_rad[i]=0;
        }
    }
    dfs(rad,0);
    maxim=0;
    for(i=1;i<=n;++i)
    {
        if(dist_rad[i]>maxim)
            maxim=dist_rad[i];
    }
    fout<<maxim;
    return 0;
}
