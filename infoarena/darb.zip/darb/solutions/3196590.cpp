#include    <cstdio>
#include    <vector>
#include    <fstream>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
#define MAX_N 100000
int N;
vector< int > V[MAX_N];
bool vizitat[MAX_N];
int raspuns;
void Read()
{
    fin >> N;
    for(int i = 1; i < N; i++)
    {
        int x, y;
        fin >> x >> y;
        --x, --y;
        V[x].push_back(y);
        V[y].push_back(x);
    }
}
void DFS(int Nod, int Distanta)
{
    if(Distanta > raspuns)
        raspuns = Distanta;
    vizitat[Nod] = true;
    for(unsigned int i = 0; i < V[Nod].size(); i++)
    {
        if(!vizitat[V[Nod][i]])
            DFS(V[Nod][i], Distanta + 1);
    }
    vizitat[Nod] = false;
}
int main()
{
    Read();
    for(int i = 0; i < N; i++)
        DFS(i, 0);
    fout << raspuns + 1;
}
