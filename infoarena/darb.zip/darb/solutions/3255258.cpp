#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int> noduri[100001];
int n, ultim_nod, ultim_dist;
bool vizitat[100001];

void dfs(int nod, int dist){
    vizitat[nod] = true;
    ultim_nod = nod;
    ultim_dist = dist;
    for (auto vecin: noduri[nod]){
        if (!vizitat[vecin])
            dfs(vecin, dist+1);
    }

    vizitat[nod] = false;
}

int main()
{
    fin>>n;
    for (int i=0; i<n-1; i++){
        int x,y;
        fin>>x>>y;
        noduri[x].push_back(y);
        noduri[y].push_back(x);
    }
    dfs(1,0);
    dfs(ultim_nod, ultim_dist);
    fout<<ultim_dist;
	return 0;
}



