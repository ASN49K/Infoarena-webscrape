#include    <iostream>
#include    <fstream>
#include    <vector>
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
const int NLIM = 100005;
int N;
int nivelMaxim, pozitieNivel;
vector  < int > Muchii[NLIM];
bool vizitat[NLIM];
void DFS(int Nod, int nivel)
{
    vizitat[Nod] = true;
    if(nivel > nivelMaxim)
    {
        nivelMaxim = nivel;
        pozitieNivel = Nod;
    }
    for(unsigned int i = 0; i < Muchii[Nod].size(); i++)
    {
        int Vecin = Muchii[Nod][i];
        if(!vizitat[Vecin])
            DFS(Vecin, nivel + 1);
    }
}
void Reset()
{
    for(int i = 1; i <= N; i++)
        vizitat[i] = false;
}
void Read()
{
    int x, y;
    fin >> N;
    for(int i = 1; i < N; i++)
    {
        fin >> x >> y;
        Muchii[x].push_back(y);
        Muchii[y].push_back(x);
    }
    DFS(1,0);
    Reset();
    DFS(pozitieNivel, 0);
    fout << nivelMaxim + 1;
}
int main() {
    Read();
    return 0;
}