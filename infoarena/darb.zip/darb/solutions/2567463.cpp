#include <bits/stdc++.h>

#define MAXN    100005

int N;
std::vector <int> ADC[MAXN];
inline void addEdge(int u, int v) {
    ADC[u].push_back(v);
    ADC[v].push_back(u);
}

int max, best;
void _DFS(int vertex, int parent = 0, int lvl = 0) {
    if (lvl > max) max = lvl, best = vertex;
    for (auto &it:ADC[vertex]) {
        if (it == parent) continue;
        _DFS(it, vertex, lvl+1);
    }
}
void DFS(int vertex = 1) {
    max = 0;
    _DFS(vertex);
}

#define FILENAME    std::string("darb")
std::ifstream input (FILENAME+".in");
std::ofstream output(FILENAME+".out");

int32_t main()
{
    input >> N;
    for (int i=1, u, v; i<N; ++i)
        input >> u >> v, addEdge(u, v);
    DFS();
    DFS(best);
    output << max+1 << '\n';

    return 0;
}
