#include <bits/stdc++.h>

using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

const int DIM = 1e5 + 7;

vector <int> l[DIM];

int viz[DIM];

void dfs(int x)
{

   for(int i = 0; i < l[x].size(); i++)
   {

       if(viz[l[x][i]] == 0)
       {
           viz[l[x][i]] = viz[x] + 1;
           dfs(l[x][i]);
       }
   }
}

int main()
{
    int n;
    in >> n;

    for(int i = 1; i <= n - 1; i++)
    {
     int x, y;

     cin >> x >> y;

     l[x].push_back(y);
     l[y].push_back(x);

    }

    viz[1] = 1;
    dfs(1);

    int nod = 0;
    int dist = 0;

    for(int i = 1; i <= n; i++)
    {
        if(viz[i] > dist)
        {
            dist = viz[i];
            nod = i;
        }
    }


    for(int i = 1; i <= n; i++)
        viz[i] = 0;
        viz[nod] = 1;
    dfs(nod);
    dist = 0;


    for(int i = 1; i <= n;  i++)
    {
        if(viz[i] > dist)
        {
            dist = viz[i];
        }
    }
    out << dist;
    return 0;
}
