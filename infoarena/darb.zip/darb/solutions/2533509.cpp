#include <bits/stdc++.h>

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

vector <int> v[100001];

int viz[100001], n, l, lmax=0, maxnod1;

void dfs(int nod, int k)
{
    viz[nod]=k;
    for(auto j : v[nod])
        if(viz[j]!=k)
        {
            l++;
            if(l>lmax)
            {
                lmax=l;
                maxnod1=j;
            }
            dfs(j, k);
        }
    l--;
}

int main(){
    int i, x, y;

    f>>n;
    for(i=1; i<n; i++)
    {
        f>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    dfs(1, 1);
    lmax=0;
    l=1;
    dfs(maxnod1, 2);

    g<<lmax;
}
