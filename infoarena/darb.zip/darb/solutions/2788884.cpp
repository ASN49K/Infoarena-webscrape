#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#include <ctype.h>
#define VMAX 100001

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector <int> adj[VMAX];
int d[VMAX];
int V, x, y;

int readInt () {

    int nr = 0, ch;
    while ( !isdigit ( ch = fin.get() ) );
    do {
        nr = nr * 10 + ch - '0';
    } while ( isdigit ( ch = fin.get() ) );

    return nr;
}

void furthestNode(int starting_point)
{
    int u, last = starting_point;
    queue <int> q;
    for (int i = 1; i <= V; ++i) d[i] = 0;
    q.push(starting_point);
    d[starting_point] = 1;

    while (!q.empty())
    {
        u = q.front(), q.pop();
        for (int w:adj[u])
            if (d[w] == 0)
            {
                d[w] = d[u] + 1;
                q.push(w);
            }
    }
}

int main()
{
    fin >> V;

    for (int i = 0; i < V - 1; ++i)
    {
        x = readInt();
        y = readInt();
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    furthestNode(1);

    int maximum = -1, index;

    for (int i = 1; i <= V; ++i)
        if (maximum < d[i]) maximum = d[i], index = i;

    furthestNode(index);

    maximum = -1;
    for (int i = 1; i <= V; ++i)
        if (maximum < d[i]) maximum = d[i];

    fout << maximum;
    fin.close();
    fout.close();
    return 0;
}
