#include <bits/stdc++.h>
#define ll unsigned long long

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n;
vector<int>G[100001];
int f[100001],nodmax = 0,lvlmax = 0,f2[100001],nodmax2 = 0, lvlmax2 = 0;
void dfs(int nod, int lvl){
    if(lvl > lvlmax)
        lvlmax = lvl, nodmax = nod;
    f[nod]=1;
    for(auto x : G[nod]){
        if(f[x] == 0){
            dfs(x,lvl+1);
        }
    }
}
void dfs2(int nod, int lvl){
    if(lvl > lvlmax2)
        lvlmax2 = lvl, nodmax2 = nod;
    f2[nod]=1;
    for(auto x : G[nod]){
        if(f2[x] == 0){
            dfs2(x,lvl+1);
        }
    }
}
int main(){
   fin>>n;
   for(int i = 1; i <= n-1; i++){
    int x,y ; fin>>x>>y;
    G[x].push_back(y);
    G[y].push_back(x);
   }
   dfs(1,0); // din nodul 1, 0 este nivelul
    // fac un now dfs din nodmax
   dfs2(nodmax,0);
   fout<<lvlmax2+1;
   return 0;
}
