//#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

const int Max=100005;
int n,nodm; int Maxx;
vector <int >v[Max],vt[Max]; int dist[Max];
queue <int>q;
void dfs(int nod,int cost=0)
{
    for(int j=0;j<v[nod].size();j++)
    {
        int vecin=v[nod][j];
        dfs(vecin,cost+1);
    }
    if(cost>Maxx)
    {
          Maxx=cost;
          nodm=nod;
    }

}
void bfs(int nod)
{
    dist[nod]=1;
    q.push(nod);
    while(!q.empty())
    {
        int nodd=q.front(); q.pop();
        for(int j=0;j<vt[nodd].size();j++)
        {
            int vecin=vt[nodd][j];
            if(!dist[vecin])
            {
                dist[vecin]=dist[nodd]+1;
                if(dist[vecin]>Maxx)
                    Maxx=dist[vecin];
                q.push(vecin);
            }
        }
    }
}
void citire()
{
    in>>n;
    for(int i=1;i<=n-1;i++)
    {
        int x,y; in>>x>>y;

        v[x].push_back(y);
        vt[x].push_back(y);
        vt[y].push_back(x);

    }
}
int main()
{
    citire();
    dfs(1);
     Maxx=0;
    bfs(nodm);
    out<<Maxx;
    return 0;
}
