#include <bits/stdc++.h>
using namespace std;

ifstream fin ("darb.in");
ofstream fout("darb.out");

const int dim=100009;

vector<int>v[dim];

int nod,maxim=0,dist[dim];

void dfs(int x,int tata){
    dist[x]=dist[tata]+1;
    for(int y:v[x]){
        if(y!=tata){
            dfs(y,x);
        }
    }
    if(dist[x]>maxim){
        maxim=dist[x];
        nod=x;
    }
}

signed main(){
    int n;
        fin>>n;
    for(int i=1;i<n;i++){
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1,0);
    dfs(nod,0);
        fout<<maxim;
}
