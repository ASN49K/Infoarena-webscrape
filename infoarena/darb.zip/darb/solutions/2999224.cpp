#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n;
vector<int> G[100005];

int dist1[100005], dist2[100005];

int nodmax, distmax;

void citire() {
    fin>>n;
    int x, y;
    for (int i=1; i<n; i++) {
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}

void dfs1(int node, int tata, int dist[]) {
    dist[node]=dist[tata]+1;
    if (dist[node]>distmax) {
        nodmax=node;
        distmax=dist[node];
    }
    for (int i=0; i<G[node].size(); i++)
        if (G[node][i]!=tata)
            dfs1(G[node][i], node, dist);
}

void dfs2(int node, int tata, int dist[]) {
    dist[node]=dist[tata]+1;
    if (dist[node]>distmax)
        distmax=dist[node];
    for (int i=0; i<G[node].size(); i++)
        if (G[node][i]!=tata)
            dfs2(G[node][i], node, dist);
}

int main() {
    citire();
    dfs1(1, 0, dist1);
    dfs2(nodmax, 0, dist2);
    fout<<distmax;
    return 0;
}