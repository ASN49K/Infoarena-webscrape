#include <iostream>
#include <queue>
#include <unordered_set>
#include <fstream>
using namespace std;
const int NMAX=100010;
ifstream f("darb.in");
ofstream g("darb.out");
int n,x,y,maxim=-1,dis[NMAX],no,viz[NMAX];
unordered_set<int>L[NMAX];

void BFS(int nod) {
    queue<int>Q;
    Q.push(nod);
    viz[nod]=1;
    while(!Q.empty()) {
        int k=Q.front();
        Q.pop();
        for(const auto& e:L[k]) {
            if(viz[e]==0) {
                viz[e]=1;
                dis[e]=dis[k]+1;
                Q.push(e);
            }
        }
    }
}

int main() {
    f>>n;
    while(f>>x>>y) {
        L[x].insert(y);
        L[y].insert(x);
    }
    BFS(1);
    for(int i=1; i<=n; i++) {
        if(dis[i]>maxim) {
            maxim=dis[i];
            no=i;
        }
    }
    for(int i=1; i<=n; i++) {
        dis[i]=0;
        viz[i]=0;
    }
    BFS(no);
    for(int i=1; i<=n; i++) {
        if(maxim<dis[i]) {
            maxim=dis[i];
        }
    }
    g<<maxim+1;
    f.close();
    g.close();
    return 0;
}
