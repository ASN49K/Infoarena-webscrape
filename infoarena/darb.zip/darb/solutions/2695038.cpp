#include <bits/stdc++.h>
using namespace std;

struct Nod {
    vector <int> neigh;
    bool vizit = 0;
};

int parcurge(int i, vector <Nod> &edges) {
    int maxim = 0;
    edges[i].vizit = 0;
    for (int j = 0; j < (int)edges[i].neigh.size(); j++)
        if (edges[edges[i].neigh[j]].vizit)
            maxim = max(maxim, parcurge(edges[i].neigh[j], edges));
    return maxim + 1;
}

int main() {
    freopen("darb.in", "r", stdin);
    freopen("darb.out", "w", stdout);
    int n, i, x, y;
    cin >> n;
    vector <Nod> edges(n + 1);

    for (i = 1; i < n; i++) {
        cin >> x >> y;
        edges[x].neigh.push_back(y);
        edges[y].neigh.push_back(x);
    }

    queue <int> parcurse;
    parcurse.push(1);
    int ultim = 1;
    vector <int> *next;
    while (!parcurse.empty()) {
        ultim = parcurse.front();
        next = &edges[ultim].neigh;
        for (i = 0; i < (int)next->size(); i++) {
            if (!edges[(*next)[i]].vizit)
                parcurse.push((*next)[i]);
            edges[(*next)[i]].vizit = 1;
        }
        parcurse.pop();
    }
    cout << parcurge(ultim, edges);
    return 0;
}
