#include <bits/stdc++.h>
 
using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

const int NMAX = 1e5;
vector<int> G[NMAX + 1];
int dist[NMAX + 1];

int main() {
    int n;
    f >> n;
    for(int i = 1; i <= n - 1; i++) {
        int x, y;
        f >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    queue<int> q;
    dist[1] = 1;
    q.push(1);
    while(!q.empty()) {
        int node = q.front();
        q.pop();
        for(auto vecin : G[node]) {
            if(!dist[vecin]) {
                dist[vecin] = dist[node] + 1;
                q.push(vecin);
            }
        }
    }
    int nmx = 0, mx = 0;
    for(int i = 1; i <= n; i++) {
        if(dist[i] > mx) {
            mx = dist[i];
            nmx = i;
        }
        dist[i] = 0;
    }
    dist[nmx] = 1;
    q.push(nmx);
    while(!q.empty()) {
        int node = q.front();
        q.pop();
        for(auto vecin : G[node]) {
            if(!dist[vecin]) {
                dist[vecin] = dist[node] + 1;
                q.push(vecin);
            }
        }
    }
    mx = 0;
    for(int i = 1; i <= n; i++) {
        if(dist[i] > mx) {
            mx = dist[i];
        }
    }
    g << mx;
    return 0;
}