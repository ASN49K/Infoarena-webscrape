#include <bits/stdc++.h>

using namespace std;

ifstream f ("darb.in");
ofstream g ("darb.out");

int n;
vector <int> a[100005];
int primdist[100005];
int distmax[100005];
int viz[100005];

void DFS(int nod , int parinte , int v[])
{
    v[nod]=v[parinte]+1;
    viz[nod]=1;
    for(int x=0;x<a[nod].size();++x)
    {
        int urm=a[nod][x];
        if(viz[urm]==0)
        {
            DFS(urm , nod , v);
        }
    }
}
int main()
{
    f>>n;
    for(int i=1;i<=n;++i)
    {
        int x , y;
        f>>x>>y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    DFS(1 ,0, primdist);
    int maxim=0;
    int imax;
    for(int i=1;i<n;++i)
    {
        if(maxim<primdist[i])
        {
            maxim=primdist[i];
            imax=i;
        }
    }
    for(int i=1;i<=n;++i)
        viz[i]=0;


    DFS(imax , 0 ,distmax);
    maxim=0;
    for(int i=1;i<=n;++i)
    {
        if(maxim<distmax[i])
        {
            maxim=distmax[i];
            imax=i;
        }
    }
    g<<maxim;
    return 0;
}
