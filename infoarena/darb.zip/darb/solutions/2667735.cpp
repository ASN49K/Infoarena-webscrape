#include <bits/stdc++.h>
#include <fstream>
using namespace std;

#define pb push_back
#define ll long long
const int NMax = 1e+6 + 100;
fstream fin("darb.in",ios::in),fout("darb.out",ios::out);
vector<int> adj[NMax];
bool viz[NMax]; ll dmax=INT_MIN,node=-1;
void dfs(int k,int dist)
{
    if(dist>dmax) dmax = dist,node=k;
    viz[k]=true;
    for(auto it=adj[k].begin();it!=adj[k].end();++it)
        if(!viz[*it])
            dfs(*it,dist+1);
}
int main()
{
    int n,m,i,j,c=0;
    fin>>n;
    m=n-1;
    while(m--)
    {
        fin>>i>>j;
        adj[i].pb(j),
        adj[j].pb(i);
    }
    dfs(1,0);
    memset(viz,0,sizeof viz);
    dfs(node,0);
    fout<<dmax+1<<'\n';
}
