#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin ("darb.in");
ofstream cout ("darb.out");
int n,ultim;
int v[100003];
queue<int>Q;
vector<int>G[100003];
void bfs(int nod)
{
    int i;
    for(i=1;i<=n;i++)
        v[i]=0;
    v[nod]=1;
    Q.push(nod);
    while(!Q.empty())
    {
        int x=Q.front();
        ultim=x;
        Q.pop();
        for(auto i:G[x])
            if(v[i]==0)
        {
            v[i]=v[x]+1;
            Q.push(i);
        }
    }
}
int main()
{int i;
    cin >> n;
    for( i = 1;i<=n;i++)
    {
        int x,y;
        cin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    bfs(1);
    bfs(ultim);
    cout << v[ultim];

}
