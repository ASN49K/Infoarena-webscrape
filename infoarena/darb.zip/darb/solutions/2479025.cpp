#include <iostream>
#include <fstream>
#include <vector>
#define lim 100005
using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

int n, mmax, parcurs[lim];
vector<int> v[lim];


void read()
{
    in>>n;
    int x, y;
    for(int i=1; i<=n; ++i)
    {
        in>>x>>y;
        v[y].push_back(x);
        v[x].push_back(y);
    }
}

void diametru(int poz, int lung)
{
    int max1=0, max2=0;
    parcurs[poz]=1;
    for(int i=0; i<v[poz].size(); ++i)
    {
        if(parcurs[v[poz][i]]==0)
        {
            diametru(v[poz][i], lung+1);
            if(lung>max1)
            {
                max2=max1;
                max1=lung;
            }
            else if(lung>max2)
            {
                max2=lung;
            }

        }
    }
    if(max1+max2+1>mmax)
        mmax=max1+max2+1;
}

int main()
{
    read();
    diametru(1, 1);
    out<<mmax+1;
    return 0;
}
