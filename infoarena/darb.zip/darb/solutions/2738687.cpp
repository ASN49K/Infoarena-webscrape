#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, mx1, mx2;
vector<int> g[100005];

void dfs(int x, int t, int depth) {
    if(depth > mx1) {
        mx2 = mx1;
        mx1 = depth;
    } else if(depth > mx2) {
        mx2 = depth;
    }
    for(auto next: g[x])
        if(next != t)
            dfs(next, x, depth+1);
}

int main() {
    fin >> n;
    for(int i = 1; i < n; i++) {
        int a, b;
        fin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs(1, 0, 0);
    fout << mx1+mx2+1 << '\n';
}
