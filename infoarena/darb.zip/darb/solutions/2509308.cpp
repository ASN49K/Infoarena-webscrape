#include <bits/stdc++.h>
#define NMAX 100009
using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int>g[NMAX];
int n,last;
int uz[NMAX];
queue <int> Q;
void citire();
void bfs(int k);
int main()
{citire();
 bfs(1);
 for(int i=0;i<NMAX;i++)uz[i]=0;
 //fout<<last<<" ";
 bfs(last);


  fout<<uz[last];
    return 0;
}
void citire()
{int i,x,y;
 fin>>n;
 for(i=1;i<=n-1;i++)
    {
     fin>>x>>y;
     g[x].push_back(y);
     g[y].push_back(x);
    }
}
void bfs(int k)
{int el;
 Q.push(k);
 uz[k]=1;
 while(!Q.empty())
     {
     el=Q.front();

     for(int i=0;i<g[el].size();i++)
         if(!uz[g[el][i]])
            {uz[g[el][i]]=uz[el]+1;
             last=g[el][i];
             Q.push(g[el][i]);
            }
    Q.pop();
    }
}
