#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <string.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int NMAX = 100000;

vector<int>Mat_adi[NMAX+1];
queue <int>Coada;
int distanta[NMAX+1];

int last;

void citire(){
    int nr_noduri;
    int a,b;
    fin>>nr_noduri;
    for(int i=1;i<=nr_noduri;i++){
        fin>>a>>b;
        Mat_adi[a].push_back(b);
        Mat_adi[b].push_back(a);
    }
}

void BFS(int start){
    memset(distanta,0,NMAX);
    int nod,dist;
    distanta[nod] = 1;
    Coada.push(start);
    while(Coada.empty()==false){
        nod = Coada.front();
        Coada.pop();
        dist = distanta[nod] + 1;
        last = nod;
        for(auto copil:Mat_adi[nod]){
            if(!distanta[copil]){
                distanta[copil] = dist;
                Coada.push(copil);
            }
        }
    }
}

int main(){
    citire();
    BFS(1);
    BFS(last);
    fout<<distanta[last];
    return 0;
}
