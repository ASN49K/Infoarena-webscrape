#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;
ifstream fin("darb.in");
ofstream gout("darb.out");
void dfs(int nod,vector<int>&d,vector<bool>&viz,vector<vector<int>>&g)
{
    viz[nod]=1;
    for(auto i:g[nod])if(!viz[i])
        {
            d[i]=d[nod]+1;
            dfs(i,d,viz,g);
        }
}
int main()
{
    int n,i,j;
    fin>>n;
    vector<vector<int>>g(n+1,vector<int>(0));
    while(fin>>i>>j)
    {
        g[i].push_back(j);
        g[j].push_back(i);
    }
    vector<int>d(n+1,0);
    vector<bool>viz(n+1,0);
    ///dfs1
    dfs(1,d,viz,g);
    int a=1,b=1;
    for(i=2; i<=n; ++i)if(d[a]<d[i])a=i;
    d.assign(n+1,0);
    viz.assign(n+1,0);
    dfs(a,d,viz,g);
    for(i=2; i<=n; ++i)if(d[b]<d[i])b=i;
    gout<<d[b]+1;///diametrul este a->b.
    return 0;
}
