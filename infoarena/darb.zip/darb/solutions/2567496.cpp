#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n,a,b,nodmax;
int vizitat[100002];
vector<int> vecini[100002];
queue<int> q;

void bfs(int start)
{
    q.push(start);
    vizitat[start]=1;
    while(!q.empty())
    {
        int pos=q.front();
        q.pop();
        int marime=vecini[pos].size();
        for(int i=0; i<marime; i++)
        {
            int pi=vecini[pos][i];
            cout<<pi<<" ";
            if(vizitat[pi]==0)
            {
                vizitat[pi]=vizitat[pos]+1;
                nodmax=pi;
                q.push(pi);
            }
        }
    }
}

int main()
{
    fin>>n;
    for(int i=0; i<n-1;i++)
    {
        fin>>a>>b;
        vecini[a].push_back(b);
        vecini[b].push_back(a);
    }
    bfs(1);
    memset(vizitat,0,sizeof vizitat);
    cout<<"\n"<<nodmax<<"\n";
    bfs(nodmax);
    fout<<vizitat[nodmax];
    return 0;
}
