#include <fstream>
#include <vector>
#include <deque>
#include <cstring>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int viz[100005], n, dist[100005], a, b, i, node, maxx, temp;
vector <int> gr[100005];
deque<int> q;

void bfs(int node, int& maxx, int& maxx_node) {
    viz[node] = 1;
    q.push_back(node);
    while(!q.empty()) {
        int x = q.front();
        for (auto it : gr[x])
            if (!viz[it]) {
                viz[it] = 1;
                dist[it] = dist[x] + 1;
                if (dist[it] > maxx) {
                    maxx = dist[it];
                    maxx_node = it;
                }
                q.push_back(it);
            }
        q.pop_front();
    }
}

int main() {
    fin >> n;
    for (i = 1; i <= n - 1; i++) {
        fin >> a >> b;
        gr[a].push_back(b);
        gr[b].push_back(a);
    }

    bfs(1, maxx, node);

    memset(viz, 0, sizeof(viz));
    memset(dist, 0, sizeof(dist));
    maxx = 0;

    bfs(node, maxx, temp);

    fout << maxx + 1;

    return 0;
}