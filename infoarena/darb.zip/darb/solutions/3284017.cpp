#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n, x, y, i, dist[100005], maxim;
vector <int> v[100005];
bool viz[100005];
void dfs(int nod)
{
    viz[nod]=1;
    for(auto i: v[nod])
        if(viz[i]==0)
        {
            dist[i]=dist[nod]+1;
            dfs(i);
        }
}
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dist[1]=1;
    dfs(1);
    int nod=0;
    for(i=1; i<=n; i++)
        if(maxim<dist[i])
        {
            maxim=dist[i];
            nod=i;
        }
    maxim=0;
    for(i=1; i<=n; i++)
        dist[i]=viz[i]=0;
    dist[nod]=1;
    dfs(nod);
    for(i=1; i<=n; i++)
        if(maxim<dist[i])
          maxim=dist[i];
    fout<<maxim;
    return 0;
}
