#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>
using namespace std;

int dim,last_element;

void bfs(const vector<vector<int> >&adj,int n,int start)
{
    vector<int>tav(n+1,-1);
    queue<int>q;
    q.push(start);
    tav[start]=1;
    while(!q.empty()){
        int v=q.front();
        q.pop();
        for(int sz:adj[v])
        {
            if(tav[sz]==-1)
            {
                tav[sz]=tav[v]+1;
                dim=tav[sz];
                last_element=sz;
                q.push(sz);
            }
        }

    }
}
int main()
{
    ifstream be("darb.in");
    ofstream ki("darb.out");
    int n;
    be>>n;
    vector<vector<int> >adj(n+1);
    for(int i=1;i<=n;i++)
    {
        int x,y;
        be>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    bfs(adj,n,1);
    bfs(adj,n,last_element);
    cout<<dim<<endl;
    return 0;
}
