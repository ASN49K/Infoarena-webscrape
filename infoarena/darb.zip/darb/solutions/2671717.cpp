#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
#define max 1000001
ifstream in("darb.in");
ofstream out("darb.out");

vector<int> nod[max];
queue<int> c;
int n,v[max],viz[max],y,sol;

void bfs(int x){
    memset(v,0,max);
    memset(viz,0,max);
    c.push(x);
    v[x]=1;
    viz[x]=1;
    int i;
    while(  !c.empty()  ){
        int aux =   c.front();
        for(    i=0;    i<nod[aux].size()   ;   i++){
            if( viz[    nod[aux][i] ]    ==  0){
                c.push( nod[aux][i] );
                v[  nod[aux][i] ]   =   v[aux]  +   1;
                viz[    nod[aux][i] ]   =   1;
                sol =   v[  nod[aux][i] ];
                y   =   nod[aux][i];
            }
        }
        i--;
        c.pop();
    }
}

void read()
{
    in>>n;
    for(int i=0,a,b;    i<n-1;  i++){
        in>>a>>b;
        nod[a].push_back(b);
        nod[b].push_back(a);
    }
}

int main()
{
    read();
    bfs(1);
    bfs(y);
    out<<sol;
    out.close();
    out.close();
    return 0;
}