#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

using namespace std;

typedef pair<int,int> ii;

ifstream fin("darb.in");
ofstream fout("darb.out");

const int NMAX = 100005;
vector<int>G[NMAX];
int viz[NMAX];
int n;

int find_start(int nod)
{
    int last;
    viz[nod] = 1;
    queue<int>q;
    q.push(nod);
    while(!q.empty())
    {
        int fr = q.front();
        q.pop();
        for(auto x : G[fr])
            if(!viz[x])
            {
                viz[x] = 1;
                last = x;
                q.push(x);
            }
    }

    return last;
}

void bfs(int nod)
{
    int maxim = 0;
    viz[nod] = 1;
    queue<ii>q;
    q.push(ii(nod,0));
    while(!q.empty())
    {
        int u = q.front().first,d=q.front().second;
        q.pop();
        for(auto x : G[u])
        {
            if(!viz[x])
            {
                viz[x] = d+1;
                maxim = max(maxim,viz[x]);
                q.push(ii(x,d+1));
            }
        }
    }

    fout << maxim+1 << '\n';
}

int main()
{
    int i,x,y,source;
    fin >> n;
    for(i=1;i<n;++i)
    {
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    source = find_start(1);
    memset(viz,0,sizeof(viz));
    bfs(source);
    return 0;
}
