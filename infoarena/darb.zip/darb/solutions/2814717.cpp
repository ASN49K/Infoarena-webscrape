// doua parcurgeri DFS: prima dintr-un nod oarecare, a doua din nodul in care am ajuns => complexitate O(N)
// cea mai îndepărtată frunză din prima parcurgere reprezintă cea mai îndepărtată frunza de radacina, fiind un capăt al lanţului,
// celălalt capăt va fi ultimul nod în care ajungem in a doua parcurgere, adica cea mai îndepărtată frunza de acel nod
#include <iostream>
#include <fstream>
#include <vector>
#define Nmax 100001
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

int n, viz[Nmax], dMax, nMax; // n noduri, arbore => n-1 muchii
vector<int> la[Nmax]; // lista de adiacenta

// fol dfs pt a calc dist dintre noduri
int dfs(int x, int d)
{
    if (d > dMax){
        // cout << "dMax = " << d << "; nMax = " << x << endl;
        dMax = d;
        nMax = x;
    }
    // else cout << "nu a intrat in if\n";

    viz[x]=1;
    for (auto y: la[x])
        if (!viz[y]) {
            // cout << "dfs(" << y << "," << d+1 << ")\n";
            dfs(y, d + 1); // pe fiecare nivel al arborelui, distanta fata de 'radacina' creste cu 1 (este indicele nivelului)
        }
}

int diametru()
{
    dfs(1, 0); // pornim dintr-un nod oarecare (devine radacina => nivel 0 adica distanta fata de el insusi e 0)
    for(int i = 1; i <= n; i++) // deviz toate nodurile
        viz[i] = 0;
    dMax = 0;
    dfs(nMax, 0);
    return dMax+1; // pt ca am plecat cu distanta de la 0
}

int main()
{
    int x, y;
    fin >> n;
    for (int i=1; i<=n; i++) {
        fin >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }
    fout << diametru();
    return 0;
}
