#include <fstream>
#include <vector>
#define N 100002
#define INF 2000000000
#include <deque>
#include <bitset>

using namespace std;
ifstream f("darb.in");
ofstream g("darb.out");

vector <int> graph[N];
int last, dr[N];
deque <int> q;
bitset <N> viz;

void bf(int nod)
{
    q.push_back(nod);
    dr[nod] = 1;
    viz[nod] = 1;
    while (!q.empty())
    {
        nod = q.front();
        q.pop_front();
        for (int i = 0;i < graph[nod].size();++i)
        {
            int vee = graph[nod][i];
            if (!viz[vee])
            {
                viz[vee] = 1;
                last = vee;
                q.push_back(vee);
                dr[vee] = dr[nod] + 1;
            }
        }
    }
}
int main()
{
    int n, x, y;
    f >> n;
    for (int i = 1;i < n;++i)
        f >> x >> y, graph[x].push_back(y), graph[y].push_back(x);
    bf(1);
    viz.reset();
    bf(last);
    g << dr[last] << '\n';
    f.close();
    g.close();
    return 0;
}