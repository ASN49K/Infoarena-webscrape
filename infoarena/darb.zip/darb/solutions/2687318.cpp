#include <bits/stdc++.h>
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("darb.in" , "r" , stdin) , freopen("darb.out" , "w" , stdout)
#define pb push_back

using namespace std;

const int N = 1e5 + 10;

int n , x , y;
vector < int > g[N];

int maxi;

int dfs(int v , int p , int h)
{
    if(h > maxi)
        maxi = h , x = v;

    for(auto i : g[v])
        if(i != p)
            dfs(i , v , h + 1);
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n;

    for(int i = 1 ; i < n ; i++)
    {
        cin >> x >> y;
        g[x].pb(y);
        g[y].pb(x);
    }

    maxi = 0 , dfs(1 , -1 , 1);
    maxi = 0 , dfs(x , -1 , 1);

    cout << maxi;

    return 0;
}
