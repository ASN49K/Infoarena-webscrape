#include <fstream>
#include <vector>
#include <cstring>
#define MAX_NODES 100001
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector<int> tree[MAX_NODES];
int distances[MAX_NODES], visited[MAX_NODES];

void compute_distance(int current) {
    visited[current] = 1;
    for (int &adjacent_node : tree[current]) {
        if (!visited[adjacent_node]) {
            distances[adjacent_node] = distances[current] + 1;
            compute_distance(adjacent_node);
        }
    }
}

int findDiameter(int nr_nodes) {
    int diameter = 0;
    for (int i = 1; i <= nr_nodes; ++i) {
        compute_distance(i);
        for (int j = 1; j <= nr_nodes; ++j) {
            if (distances[j] > diameter) {
                diameter = distances[j];
            }
        }
        memset(distances, 0, sizeof(distances));
        memset(visited, 0, sizeof(distances));
    }
    return diameter + 1;
}

int main() {
    int nr_nodes, node_a, node_b;
    fin >> nr_nodes;
    for (int i = 0; i < nr_nodes; ++i) {
        fin >> node_a >> node_b;
        tree[node_a].push_back(node_b);
        tree[node_b].push_back(node_a);
    }
    fout << findDiameter(nr_nodes);
    return 0;
}