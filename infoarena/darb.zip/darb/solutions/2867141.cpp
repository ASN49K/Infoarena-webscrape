#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair<ll, ll>
#define sz(x) (int)((x).size())
#define all(a) (a).begin(), (a).end()

/*const ll maxn = 1e5;
int f[maxn],nf[maxn],inv[maxn];
const int M=998244353;
void init(){
    inv[1]=1; for (int i=2;i<maxn;i++) inv[i]=M-1ll*(M/i)*inv[M%i]%M;
    f[0]=nf[0]=1; for (int i=1;i<maxn;i++) f[i]=1ll*f[i-1]*i%M,nf[i]=1ll*nf[i-1]*inv[i]%M;
}
int C(int x,int y){return 1ll*f[x]*nf[y]%M*nf[x-y]%M;} */

const ll mod = 1e9+7;
ll n, k, m, mi, ma;
ll d;
const ll N = 1e5 + 5;
vector<ll> a[N];

ll dfs(ll x, ll p){
	vector<ll> b;
	b.pb(0); b.pb(0);
	for(int i = 0; i<a[x].size(); i++){
		if(a[x][i] == p) continue;
		ll r = dfs(a[x][i], x);
		b.pb(r);
	}
	sort(all(b));
	reverse(all(b));
	d = max(d, b[0] + 1 + b[1]);
	return b[0] + 1;
}




void solve(){
	
	ifstream cin("darb.in");
	ofstream cout("darb.out");
	
	d = 0;
	cin >> n;
	for(int i = 0; i<n - 1; i++){
		ll x, y;
		cin >> x >> y;
		x--; y--;
		a[x].pb(y);
		a[y].pb(x);
	}

	ll r = dfs(0, -1);
	cout << d << "\n";
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);

	//init();
	
	int t=1;
	//cin >> t;
	while(t--) solve();
	
	return 0;
}

