#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100005;

ifstream fin("darb.in");
ofstream fout("darb.out");

int N, x, y, last, lgmax;
vector < int > Ad[NMAX];

void DFS( int nod, int parent, int lg )
{
    if( lg > lgmax ) { lgmax = lg; last = nod; }
    for( int i = 0; i < Ad[nod].size(); ++i )
    {
        int w = Ad[nod][i];
        if( w != parent )
            DFS( w, nod, lg+1);
    }
}
void Solve()
{
    fin >> N;

    for( int i = 1; i < N; ++i )
    {
        fin >> x >> y;
        Ad[x].push_back( y );
        Ad[y].push_back( x );
    }
    DFS( 1, 0, 1 );
    DFS( last, 0, 1 );

    fout << lgmax << '\n';
}
int main()
{
    Solve();
    return 0;
}
