#include <bits/stdc++.h>
#include <fstream>
#include <queue>
#include <vector>

std::ifstream fin("graf.in");
std::ofstream fout("graf.out");

int main()
{
    int n, m, x, y;
    fin >> n >> m >> x >> y;
    std::vector<std::vector<int>> nums(n + 1);
    std::vector<int> viz(n + 1, 100000);
    std::vector<int> viz1(n + 1, 100000);
    std::vector<int> frec(n + 1, 0);
    std::vector<int> order;
    for(int i = 1; i <= m; i++)
    {
        int j, jj;
        fin >> j >> jj;
        nums[j].push_back(jj);
        nums[jj].push_back(j);
    }

    std::queue<int> q;
    q.push(x);
    viz[x] = 0;
    while(!q.empty())
    {
        int b = q.front();
        q.pop();
        for(int x : nums[b])
        {
            if(viz[x] == 100000) q.push(x);
            viz[x] = std::min(viz[x], viz[b] + 1);
        }
    }
    q.push(y);
    viz1[y] = 0; 
    while(!q.empty())
    {
        int b = q.front();
        q.pop();
        for(int x : nums[b])
        {
            if(viz1[x] == 100000) q.push(x);
            viz1[x] = std::min(viz1[x], viz1[b] + 1);
        }
    }

    for(int i = 1; i <= n; i++)
    {
        if(viz[i] + viz1[i] == viz[y])
        {
            frec[viz[i]]++;
        }
    }
    for(int i = 1; i <= n; i++)
    {
        if(frec[viz[i]] == 1)
        {
            order.push_back(i);
        }
    }
    fout << order.size();
    for(int x : order) fout << x << ' ';

}
