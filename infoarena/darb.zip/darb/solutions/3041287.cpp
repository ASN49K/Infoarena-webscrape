#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>

///#include <tryhardmode>
///#include <GOMDODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("darb.in");
ofstream fout ("darb.out");

const int NMAX=1e5+5;

stack<int>stiva;
vector<int>v[NMAX];
bool viz[NMAX];
long long dist[NMAX];

void dfs(int p)
{
    viz[p]=true;
    for(auto i:v[p])
    {
        if(!viz[i])
            dfs(i);
    }
    stiva.push(p);
}

int bfs(int p)
{
    long long maxim=1;
    queue<int>q;
    dist[p]=1;
    viz[p]=true;
    q.push(p);
    while(!q.empty())
    {
        int p=q.front();
        q.pop();
        for(auto i:v[p])
        {
            if(!viz[i])
            {
                viz[i]=true;
                dist[i]=dist[p]+1;
                maxim=max(maxim,dist[i]);
                q.push(i);
            }
        }
    }
    return maxim;
}

int main()
{
    int n,i;
    cin>>n;
    for(i=1;i<n;i++)
    {
        int x,y;
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1);
    for(i=1;i<=n;i++)
        viz[i]=false;
    cout<<bfs(stiva.top());
    return 0;
}
