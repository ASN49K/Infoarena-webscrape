#include <bits/stdc++.h>

using namespace std;

int A[101][101], viz[100001];
int N, D[100001], M;
queue <int> Q;

ifstream fin("darb.in");
ofstream fout("darb.out");

void BFS(int K)
{
    int i, Elem;
    viz[K] = 1;
    D[K] = 1;
    while(!Q.empty())
    {
        K = Q.front();
        Q.pop();
        for(i = 1 ; i <= N ; ++i)
        {
            if(A[K][i] == 1 && !viz[i])
            {
                Q.push(i);
                viz[i] = 1;
                D[i] = 1 + D[K];
            }
        }
    }
}

int main()
{
    int i, Elem;
    fin >> N;
    for(i = 1 ; i <= N - 1 ; ++i)
    {
        int x, y;
        fin >> x >> y;
        A[x][y] = A[y][x] = 1;
    }
    Q.push(1);
    BFS(1);
    int Max = 0;
    for(i = 1 ; i <= N ; ++i)
    {
        if(D[i] > Max)
        {
            Max = D[i];
            Elem = i;
        }
    }
    for(i = 1 ; i <= N ; ++i)
        viz[i] = 0;

    Q.push(Elem);
    BFS(Elem);
    for(i = 1 ; i <= N ; ++i)
        if(D[i] > Max) Max = D[i];
    fout << Max;
    return 0;
}
