#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n, a, b, viz[100010], lg, k;
vector <int> v[100010];
queue <int> q;
void bfs(int &nod)
{
    for(int i=1;i<=n;++i) viz[i]=0;
    q.push(nod);
    viz[nod]=1;
    lg=0;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(int i=0;i<v[nod].size();++i)
        {
            if(viz[v[nod][i]]==0)
            {
                q.push(v[nod][i]);
                viz[v[nod][i]]=viz[nod]+1;
                if(viz[v[nod][i]]>lg)
                    lg=viz[v[nod][i]];

            }
        }
    }
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;++i)
    {
        fin>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    k=1;
    bfs(k);
    bfs(k);
    fout<<lg;
    return 0;
}
