#include<bits/stdc++.h>
using namespace std;
ifstream F("darb.in");
int n,m,x,y,t,s,i;
bool z[100001];
vector<int> v[100001];
void D(int x,int l)
{
    if(l>s)
        s=l,y=x;
    int j,k=v[x].size();
    for(z[x]=t,j=0;j<k;++j)
        if(z[v[x][j]]!=t)
            D(v[x][j],l+1);
}
int main()
{
    for(F>>n,i=1;i<n;F>>x>>y,v[x].push_back(y),v[y].push_back(x),++i);
    return t=1,D(1,1),t=0,D(y,1),ofstream("darb.out")<<s,0;
}
