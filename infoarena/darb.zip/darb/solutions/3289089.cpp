#include <bits/stdc++.h>
#define DIM 1000001

using namespace std;

ifstream fin("darb.in");

ofstream fout("darb.out");

int dp[DIM];

vector <int> G[DIM];

int n, i, x, y, ret;

void dfs(int node, int COSTINEL){

    dp[node] = dp[COSTINEL] + 1;

    if(dp[node] > dp[ret])

        ret = node;

    for(auto k : G[node])

        if(k != COSTINEL)

            dfs(k, node);

}

int main(){

    fin >> n;

    for(i=2;i<=n;i++){

        fin >> x >> y;

        G[x].push_back(y);

        G[y].push_back(x);

    }

    dfs(1, 0);

    fill(dp + 1, dp + n + 1, 0);

    dfs(ret, 0);

    fout << dp[ret] << "\n";

}
