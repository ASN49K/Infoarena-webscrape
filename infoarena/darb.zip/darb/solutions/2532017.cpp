#include <iostream>
#include <fstream>
#include <vector>
#define lim 100005
using namespace std;

ifstream in("darb.in");
ofstream out("darb.out");

vector<int> v[lim];
int lung, poz, parcurs[lim], n;
void read()
{
    in>>n;
    int x, y;
    for(int i=1; i<n; ++i)
    {
        in>>x>>y;
        v[y].push_back(x);
        v[x].push_back(y);
    }
}

void dfs(int i, int nivel)
{
    parcurs[i]=1;
    if(nivel>lung)
    {
        lung=nivel;
        poz=i;
    }
    for(int j=0; j<v[i].size(); ++j)
    {
        if(parcurs[v[i][j]]==0)
        {
            dfs(v[i][j], nivel+1);
        }
    }
}

void reset()
{
    for(int i=1; i<=n; ++i)
        parcurs[i]=0;
}

int main()
{
    read();
    dfs(1, 0);
    reset();
    dfs(poz, 0);
    out<<lung+1;
    return 0;
}
