#include <iostream>
#include <fstream>
#include <queue>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

struct diam
{
    int nod, dist;
};

queue<diam>q;
int n,x,y,maxi;
bool viz[100001];
vector<int>a[100001];


int bfs(int nod)
{
    q.push({nod,1});
    while(!q.empty())
    {
        diam crt=q.front();
        viz[crt.nod]=1;
        q.pop();
        for(const auto i:a[crt.nod])
            if(!viz[i])
                q.push({i,crt.dist+1});
        maxi=max(maxi,crt.dist);
        x=crt.nod;
    }
}

int main()
{
    cin>>n;
    for(int i=1; i<n; i++)
    {
        cin>>x>>y;
        a[x].push_back(y);
        a[y].push_back(x);
    }

    bfs(1);
    for(int i=1; i<=n; i++)
        viz[i]=0;
    bfs(x);

    cout<<maxi;

    return 0;
}
