#include <bits/stdc++.h>

using namespace std;
ifstream fin("darb.in");
ofstream fout("darb.out");
int n,x,y,a,b,s,i,max1,smax,m,min1=INT_MAX,l;
vector<int> v[100010];
int f[100010];
queue<int> q;
void solve(int t){
    q.push(t);
    for(int i=1;i<=n;i++) f[i]=0;
    f[t]=1;
    while(!q.empty()){
        int x=q.front();
        q.pop();
        for(int it:v[x])
            if(f[it]==0){
                q.push(it),f[it]=f[x]+1;
                if(f[it]>max1) max1=f[it],smax=it;
            }
    }
}
int main()
{
    fin>>n;
    while(fin>>a>>b){
        v[a].push_back(b);
        v[b].push_back(a);
    }
    solve(1);
    // fout<<endl;
    solve(smax);
    fout<<max1;
    return 0;
}