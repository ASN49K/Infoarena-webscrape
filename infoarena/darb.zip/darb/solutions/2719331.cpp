#include <bits/stdc++.h>
using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

vector <int> v[100005];

int ans, root, dist;

void dfs(int node, int dad)
{
    dist++;

    if(dist > ans)
        root = node, ans = dist;

    for(int i = 0; i < (int)v[node].size(); i++)
        if(v[node][i] != dad)
            dfs(v[node][i], node);

    dist--;
}

int main()
{
    int N;

    fin >> N;

    for(int i = 1; i <= N - 1; i++)
    {
        int x, y;

        fin >> x >> y;

        v[x].push_back(y);
        v[y].push_back(x);
    }

    dfs(1, 0);

    ans = 0;

    dfs(root, 0);

    fout << ans << '\n';

    return 0;
}
