#include<fstream>
#include<vector>
#define N 100001
using namespace std;
ifstream F("darb.in");
ofstream G("darb.out");
vector<int> g[N];
int i,n,c[N],l,d,o[5*N],p,u;
void B(int t)
{
	int i,k,y;
    for(i=1;i<=n;++i)
        c[i]=0;
    for(o[u++]=t,c[t]=1;p<u;++p)
    	for(k=o[p],y=g[k].size(),i=0;i<y;++i)
    		if(!c[g[k][i]])
        		l=g[k][i],o[u++]=l,c[l]=c[k]+1,d=c[l];
}
int main()
{
    F>>n;
    for(i=0;i<n-1;++i)
        F>>l>>d,g[l].push_back(d),g[d].push_back(l);
    B(1),B(l),G<<d;
    return 0;
}
