#include <bits/stdc++.h>

using namespace std;

ifstream in;
ofstream out;

vector<vector<int>> edge;
vector<int> visited;

int n, max1, far;

void create()
{
	in >> n;
	edge.resize(n + 1);
	visited.resize(n + 1);
	for (int i = 1; i < n; i++)
	{
		int x, y;
		in >> x >> y;
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
}

void DFS(int start)
{
	if (visited[start] > max1)
	{
		max1 = visited[start];
		far = start;
	}
	for (int i = 0; i < edge[start].size(); i++)
		if (!visited[edge[start][i]])
		{
			visited[edge[start][i]] = visited[start] + 1;
			DFS(edge[start][i]);
		}
}

int main()
{
	in.open("darb.in");
	out.open("darb.out");

	create();
	visited[1] = 1;
	DFS(1);
	visited.assign(n+1,0);
	visited[far] = 1;
	DFS(far);
	out << max1;

}