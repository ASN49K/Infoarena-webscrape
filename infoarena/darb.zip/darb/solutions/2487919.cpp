#include <iostream>
#include <fstream>
#include <vector>
#define NMAX 100000

using namespace std;

ifstream f("darb.in");
ofstream g("darb.out");

vector<int> v[NMAX],viz;
int m1=0,m2=0;

void dfs(int k,int nr=1)
{
    viz[k]=1;
    for(auto x:v[k])
        if(!viz[x])
    {
        viz[x]=1;
        dfs(x,nr+1);
        if(nr>m1)
            m2=m1,m1=nr;
        else if(nr>m2)
            m2=nr;
    }
}

int main()
{
    int n;
    f>>n;
    for(int i=1;i<n;++i)
    {
        viz.push_back(0);
        int x,y;
        f>>x>>y;
        v[x-1].push_back(y-1);
        v[y-1].push_back(x-1);
    }
    viz.push_back(0);
    dfs(1);
    g<<m1+m2-1;
    return 0;
}
