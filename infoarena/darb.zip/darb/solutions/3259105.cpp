#include <bits/stdc++.h>

using namespace std;

ifstream fin("darb.in");
ofstream fout("darb.out");

#define INF (long long)10e16
#define NMAX 100000
#define VMAX 1000000

vector<int> adj[NMAX+1];
int n;
int dist[NMAX+1];
void dfs(int x,int p)
{
    for(int i : adj[x])
    {
        if(i != p)
        {
            dist[i] = dist[x] + 1;
            dfs(i,x);
        }
    }
}
int main()
{
    fin >> n;
    for(int i=1;i<n;i++)
    {
        int x,y;
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    dfs(1,0);
    int mx=0;
    for(int i=1;i<=n;i++)
    {
        if(dist[i] > dist[mx])
        {
            mx = i;
        }
    }
    dist[mx]=0;
    dfs(mx,0);
    mx=0;
    for(int i=1;i<=n;i++)
    {
        if(dist[i] > dist[mx])
        {
            mx=i;
        }
    }
    fout << dist[mx]+1;
}
