#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")

using namespace std;

vector<int> nodes[50001];
int grad[50001];
queue<int> q;

int main()
{
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");
    ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    int n,m,i,j,u,v,fr;
    fin >> n >> m;
    for (j=1;j<=m;j++)
    {
         fin >> u >> v;
         nodes[u].push_back(v);
         grad[v]++;
    }
    for (j=1;j<=n;j++)
    {
         if (grad[j]==0)
             q.push(j);
    }
    while (!q.empty())
    {
         fr=q.front();
         for (j=0;j<nodes[fr].size();j++)
         {
              grad[nodes[fr][j]]--;
              if (grad[nodes[fr][j]]==0)
                  q.push(nodes[fr][j]);
         }
         fout << fr << " ";
         q.pop();
    }
    return 0;
}
