#include <fstream>
#include <queue>
#include <vector>
#define eb emplace_back
using namespace std;
ifstream cin("topsort.in");
ofstream cout("topsort.out");
int n,m,grad[100005];
vector<int> G[100005];
void sort_topologica(vector<int> G[100005])
{
    queue<int> Q;
    vector<int> ans;
    for(int i=1;i<=n;i++)
        if(grad[i]==0)
            Q.push(i),ans.eb(i);
    while(!Q.empty())
    {
        int nod=Q.front();
        Q.pop();
        for(auto x:G[nod])
        {
            grad[x]--;
            if(grad[x]==0)
            {
                ans.eb(x);
                Q.push(x);
            }
        }
    }
    for(int i=0;i<ans.size();i++)
        cout<<ans[i]<<" ";
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int u,v;
        cin>>u>>v;
        G[u].eb(v);
        grad[v]++;
    }
    sort_topologica(G);
    return 0;
}
