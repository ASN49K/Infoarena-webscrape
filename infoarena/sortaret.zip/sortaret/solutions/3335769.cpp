#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int nmax = 10005;
int n, m;
vector< int > adj[nmax + 1];

void citire() {
    fin >> n >> m;
    for(int i = 1; i<= m; i ++) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }
}

int viz[nmax + 1];
vector<int> sol;

void dfs(int u) {
    viz[u] = 1;
    for(auto &v : adj[u]) {
        if (viz[v] == 0) {
            dfs(v);
        }
    }
    sol.push_back(u);
}

int main() {
    citire();
    for (int i = 1; i <= n; i++) {
        if (viz[i] == 0) {
            dfs(i);
        }
    }    
    for(int i = n - 1; i >= 0; i --) {
        fout << sol[i] << ' ';
    }
    exit(0);
}