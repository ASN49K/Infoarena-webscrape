#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector<int> v[50005];
int viz[50005],x,y,n,m,i;
void dfs(int k)
{
    viz[k]=1;
    for(int i=0;i<v[k].size();i++)
        if(!viz[v[k][i]])
            dfs(v[k][i]);
    g<<k<<" ";
}
int main()
{
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        v[y].push_back(x);
    }
    for(i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    return 0;
}
