#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int n, m;
vector<int> g[50005];
queue<int> q;
int gr[50005];
int rez[50005], top;

void citire()
{
    cin >> n >> m;
    int x, y;
    for (int i = 1; i <= m; i++)
    {
        cin >> x >> y;
        g[x].push_back(y);
        gr[y] = gr[y] + 1;
    }
}

void sortare()
{
    for (int i = 1; i <= n; i++)
        if (gr[i] == 0)
            q.push(i);

    while (q.empty() == false)
    {
        int nod = q.front();
        q.pop();
        rez[++top] = nod;
        for (auto i : g[nod])
        {
            gr[i]--;
            if (gr[i] == 0)
                q.push(i);
        }
    }
}

int main()
{
    citire();
    sortare();

    for (int i = 1; i <= top; i++)
        cout << rez[i] << ' ';

    return 0;
}