#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout ("sortaret.out");

int N,M,X,Y;

vector<vector<int>>a;
vector<int>top;
vector<bool>viz;

void dfs(int nod)
{ 
   viz[nod]=1;

   for(int i=1;i<=N;i++)
      if(a[nod][i]==1 && viz[i]==0)dfs(i);
    
   top.push_back(nod);   
}

int main()
{
    fin>>N>>M;
    
    a.resize(N + 1, vector<int>(N + 1, 0));
    viz.resize(N+1);

    for(int i=0;i<=M;i++)
    {
        int x,y;
        fin>>x>>y;
        a[x][y]=1;
    }

    for(int i=1;i<=N;i++)
    {
        if(!viz[i])dfs(i);
    }

    reverse(top.begin(),top.end());

    for(int i=0;i<N;i++)cout<<top[i]<<" ";
    
    fin.close();
    fout.close();
    return 0;
}