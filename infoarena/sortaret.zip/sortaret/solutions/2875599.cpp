#include <bits/stdc++.h>
#include <chrono>

using namespace std;
const int NR = 1e5 + 10;

vector<int> in_degree[NR];
vector<int> out_degree[NR];
int n, m;
bool alreadyChecked[NR];

vector<int> que;
vector<int> sortTop;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
vector<int> zero(NR, 0);

signed main() {
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; ++i) {
        in >> x >> y;
        out_degree[x].emplace_back(y);
        in_degree[y].emplace_back(x);
        zero[y]++;
    }
    for (int i = 1; i <= n; ++i) {
        if (!zero[i]) {
            que.emplace_back(i);
        }
    }
    while (!que.empty()) {
        int nod = que.back();
        que.pop_back();
        if (alreadyChecked[nod]) {
            continue;
        }
        alreadyChecked[nod] = true;
        if (!in_degree[nod].empty()) {
            cout << "oh no\n";
            exit(0);
        }
        sortTop.emplace_back(nod);
        for (auto it : out_degree[nod]) {
            zero[it]--;
            if (!zero[it] && !alreadyChecked[nod]) {
                que.emplace_back(it);
            }
        }
    }
    for (auto it : sortTop) {
        out << it << ' ';
    }
    return 0;
}