#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int NMAX = 50005;


bool viz[NMAX];
vector<int>G[NMAX];
vector<int>sol;
int n, m;


void read()
{
	fin >> n >> m;
	while (m--)
	{
		int a, b;
		fin >> a >> b;
		G[a].push_back(b);
	}
}

void dfs(int u)
{
	viz[u] = true;
	for (int v : G[u])
		if (!viz[v])
			dfs(v);
	sol.push_back(u);
}

void solve()
{
	for (int i = 1; i <= n; i++)
		if (!viz[i])
			dfs(i);
	reverse(sol.begin(), sol.end());
	for (int elem : sol)
		fout << elem << ' ';
}

int main()
{
	read();
	solve();
	return 0;
}
