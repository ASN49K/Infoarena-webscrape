#include <bits/stdc++.h>

using namespace std;

const int maxN = 100005, inf = 1e9;
int n, m;
vector <int> G[maxN];
bool viz[maxN];
vector <int> sortare;

void dfs(int nod) {
    viz[nod] = 1;
    for (int vecin : G[nod]) {
        if (!viz[vecin]) {
            dfs(vecin);
        }
    }
    sortare.push_back(nod);
}
    


int main() {
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
#endif
    cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        G[x].push_back(y);
    }

    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            dfs(i);
        }
    }
    reverse(sortare.begin(), sortare.end());

    for (int x : sortare) {
        cout << x << ' ';
    }

    return 0;
}