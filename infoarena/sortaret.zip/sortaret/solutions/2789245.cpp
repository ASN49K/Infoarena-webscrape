#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

const int inf = 1e9;
const int maxN = 5e4 + 5;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector <int> g[maxN];
vector <int> ans;
bool check[maxN];

void dfs(int node) {
    check[node] = true;
    for(auto v : g[node])
        if(check[v] == false)
            dfs(v);
    ans.push_back(node);
}

int main() {

    int n, m; fin >> n >> m;
    for(int i = 1; i <= m; ++i) {
        int u, v; fin >> u >> v;
        g[u].push_back(v);
    }

    for(int i = 1; i <= n; ++i)
        if(check[i] == false)
            dfs(i);

    for(vector <int> ::reverse_iterator it = ans.rbegin(); it != ans.rend(); ++it)
        fout << *it << " ";

    return 0;
}
