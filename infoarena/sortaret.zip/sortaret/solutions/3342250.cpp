#include <bits/stdc++.h>
using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");

int main()
{
    int n,m,i,j,x,y;
    in>>n>>m;
    vector<vector<int>> lista(n+1);
    vector<int> grad(n+1);
    for(i=1;i<=m;i++){
        in>>x>>y;
        lista[x].push_back(y);
        grad[y]++;
    }
    queue<int> q;
    for(i=1;i<=n;i++){
        if(grad[i]==0)
            q.push(i);
    }
    while(!q.empty()){
        int nod=q.front();
        q.pop();
        out<<nod<<" ";
        for(auto vecin : lista[nod]){
            grad[vecin]--;
            if(grad[vecin]==0)
                q.push(vecin);
        }
    }

    return 0;
}
