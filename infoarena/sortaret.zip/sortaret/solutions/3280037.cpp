#include <fstream>
#include <vector>
#include <bitset>
#include <algorithm>

using namespace std;
const int NMAX = 50001;

int n, m;
vector<int> G[NMAX], ord;
bitset<NMAX> viz;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

void citire()
{
	int x, y;
	f >> n >> m;
	while(m--)
	{
		f >> x >> y;
		G[x].push_back(y);
	}
}

void dfs(int nod)
{
	viz[nod] = 1;
	for(const auto nex : G[nod])
		if(!viz[nex])
			dfs(nex);
	ord.push_back(nod);
}

int main()
{
	citire();
	for(int i = 1; i <= n; i++)
		if(!viz[i])
			dfs(i);
	//
	reverse(ord.begin(), ord.end());
	for(const auto &x : ord)
		g << x << ' ';
	f.close();
	g.close();
	return 0;
}
