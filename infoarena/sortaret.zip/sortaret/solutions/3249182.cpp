#include <bits/stdc++.h>
using namespace std;

const int MAX_NUM = 50005;

int n, m;
stack<int> s;
bitset<MAX_NUM> used;
vector<int> graph[MAX_NUM];

void dfs(int current) {
    for (int node : graph[current]) {
        if (!used[node]) {
            dfs(node);
        }
    }
    used[current] = true;
    s.push(current);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("soeraret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        graph[a].push_back(b);
    }
    for (int i = 1; i <= n; ++i) {
        if (!used[i]) {
            dfs(i);
        }
    }
    while (!s.empty()) {
        cout << s.top() << " ";
        s.pop();
    }
    return 0;
}
