#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int NMAX = 10e5;
int n, m, viz[NMAX],deg[NMAX];
vector<int> G[NMAX];
queue<int> Q;
queue<int> sorted;

//GRAF ORIENTAT

void SortTop()
{
  
  while(!Q.empty())
  {
    int nod=Q.front();
    sorted.push(nod);
    
    //cout<<nod<<" ";
    Q.pop();
    for(int v:G[nod])
    {
      deg[v]--;
      if(deg[v]==0)
      {
        Q.push(v);
      }

    }
  }

}
int main() {

  f>>n>>m;
  for(int i=0;i<m;++i)
  {
    int x,y;
    f>>x>>y;
    G[x].push_back(y);
    deg[y]++;
  }

  for(int i=1;i<=n;++i)
  {
    if(deg[i]==0)
    {
      Q.push(i);
    }
  }

  SortTop();

  while(!sorted.empty())
  {
    int nod=sorted.front();
    g<<nod<<" ";
    sorted.pop();
  }

  return 0;
}
