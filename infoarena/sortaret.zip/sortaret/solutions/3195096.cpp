#include <fstream>
#include <stack>
#include <vector>
#include <deque>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

vector<deque<int>> G;
stack<int> st;
vector<int> vzt_dfs;

void dfs(int nod) {
    vzt_dfs[nod] = true;
    for (auto it : G[nod])
        if (vzt_dfs[it] == false)
            dfs(it);
    st.push(nod);
}

int main() {
    int n, m;
    in >> n >> m;
    G.resize(n+1);
    vzt_dfs.resize(n+1);
    bool vazut[n+1];
    for (int i = 0; i < n; i++)
        vazut[i] = 0;
    for (int i = 0; i < m; i++) {
        int a, b;
        in >> a >> b;
        G[a].push_back(b);
        vazut[b] = 1;
    }
    for (int i = 1; i <= n; i++) {
        if (vazut[i] == false)
            dfs(i);
    }
    while (!st.empty())
    {
        out << st.top() << '\n';
        st.pop();
    }
}