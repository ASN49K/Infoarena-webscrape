#include <bits/stdc++.h>
#define nmax 50005
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n;
int viz[nmax], c[nmax], len;
vector<int> L[nmax];

void Citire()
{
    int x, y, i, m;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
    }
}

void DFS(int k)
{
    viz[k] = 1;
    for (int i : L[k])
        if (!viz[i]) DFS(i);
    c[++len] = k;
}

/// O(n + m)
void Parcurgere()
{
    for (int k = 1; k <= n; k++)
        if (!viz[k])
            DFS(k);
    for (int i = n; i >= 1; i--)
        fout << c[i] << " ";
}

int main()
{
    Citire();
    Parcurgere();
    fout.close();
    return 0;
}
