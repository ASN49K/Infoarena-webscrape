#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

#define pii pair <int, int>

string filename = "sortaret";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 5e4;

vector <int> adj[NMAX + 1];

bool viz[NMAX + 1];

vector <int> aux;
void dfs(int node){
    viz[node] = true;

    for(int vec : adj[node]){
        if(!viz[vec]){
            dfs(vec);
        }
    }

    aux.push_back(node);
}

int main(){

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        adj[a].push_back(b);
    }

    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            dfs(i);
        }
    }

    reverse(aux.begin(), aux.end());

    for(int node : aux){
        fout << node << ' ';
    }
    fout << '\n';

    return 0;
}
