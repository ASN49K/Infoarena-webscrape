#include <fstream>
#include <vector>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int N, M;
vector<int> g[50005], v, x;

void citire()
{
    v.resize(50005);
    fin >> N >> M;
    int i, j;
    for (int k = 0; k < M; k++)
    {
        fin >> i >> j;
        g[i].push_back(j);
    }
}

void dfs(int nod)
{
    v[nod] = 1;
    for (auto i : g[nod])
    {
        if (!v[i])
        {
            dfs(i);
        }
    }
    x.push_back(nod);
}

int main()
{
    citire();
    for (int i = 1; i <= N; i++)
    {
        if (!v[i])
            dfs(i);
    }

    for (int i = x.size() - 1; i >= 0; i--)
    {
        fout << x[i] << ' ';
    }

    return 0;
}