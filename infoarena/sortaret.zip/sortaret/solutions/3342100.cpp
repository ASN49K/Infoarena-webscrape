#include <bits/stdc++.h>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int lim=5e4+10;
int n,m,i,gr[lim];
vector <int> v[lim],st;
queue <int> q;
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        gr[y]++;
    }
    for(i=1;i<=n;i++)
    {
        if(gr[i]==0){st.push_back(i);q.push(i);}
    }
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto x:v[nod])
        {
            gr[x]--;
            if(gr[x]==0){st.push_back(x);q.push(x);}
        }
    }
    for(auto x:st)
        fout<<x<<" ";
    return 0;
}
