#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
queue<int>q;
vector<int>gradInt;
vector<vector<int>>gr;
void BFS(){
    int nod_curent;
    while(!q.empty()){
        nod_curent=q.front();
        q.pop();
        for(int i=0;i<gr[nod_curent].size();i++){
            gradInt[gr[nod_curent][i]]--;
            if(gradInt[gr[nod_curent][i]]==0){
                cout<<gr[nod_curent][i]<<" ";
                q.push(gr[nod_curent][i]);
            }
        }
    }
    }
int main(){
    int n,m,nod1,nod2;
    cin>>n>>m;
    gr.resize(n+1);
    gradInt.resize(n+1);
    for(int i=1;i<=m;i++){
        cin>>nod1>>nod2;
        gr[nod1].push_back(nod2);
        gradInt[nod2]++;
    }
    for(int i=1;i<=n;i++){
        if(gradInt[i]==0){
            cout<<i<<" ";
            q.push(i);
        }
    }
    BFS();
    gr.clear();
    gradInt.clear();
}