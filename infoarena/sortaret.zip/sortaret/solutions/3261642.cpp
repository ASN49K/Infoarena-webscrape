#include <fstream>
#include <vector>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n,m,a,b,cnt,v[50005],f[50005];
vector<int>G[50005];
void dfs(int acc)
{
    f[acc]=1;
    for(auto e:G[acc])
        if(f[e]==0)
            dfs(e);
    v[++cnt]=acc;
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        G[a].push_back(b);
    }
    for(int i=1;i<=n;i++)
        if(f[i]==0)
            dfs(i);
    for(int i=cnt;i>=1;i--)
        fout<<v[i]<<' ';
    return 0;
}
