#include <fstream>
#include <vector>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
vector<int>sol;
vector<int>g[50005];
bool vis[50005];
void dfs(int nod)
{
    cout << nod << '\n';
    if(vis[nod] == 1)
        return;
    vis[nod] = 1;
    for(auto it: g[nod])
        dfs(it);
    sol.push_back(nod);
}
int main()
{
    int n, m, x, y, i;
    cin >> n >> m;
    for(i = 1; i <= m; i ++)
    {
        cin >> x >> y;
        g[y].push_back(x);
    }
    for(i = 1; i <= n; i ++)
        dfs(i);
    for(auto it: sol)
        cout << it << " ";
    return 0;
}
