#include <fstream>
#include <queue>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int n, m, s;
int x,y;

vector<int> bfs(vector<vector<int>> &lista, int start){
    vector<int> result(n+1, -1);
    vector<bool> viz(n+1, 0);
    queue <pair<int, int>> q;
    q.push({start,0});
    viz[start]=1;
    while(!q.empty())
    {
        auto p = q.front();
        q.pop();
        int node = p.first;
        int dist = p.second;
        result[node] = dist;
        for(int i=0; i<lista[node].size(); i++)
        {
            int vecin = lista[node][i];
            if(viz[vecin]==0)
            {
                viz[node] = 1;
                q.push({vecin, dist+1});
            }
        }
    }
    return result;
}

void dfs(vector<vector<int>> &lista, int start, vector<bool> &viz){
    viz[start] = 1;
    for(int i=0; i<lista[start].size(); i++)
    {
        if(!viz[lista[start][i]])
            dfs(lista, lista[start][i], viz);
    }
}

int dfs_wrapper(vector<vector<int>> &lista){
    int comp_conexe = 0;
    vector<bool> viz(n+1, 0);
    for(int i=1; i<=n; i++){
        if(!viz[i]){
            comp_conexe++;
            dfs(lista, i, viz);
        }
    }
    return comp_conexe;
}

vector<int> kahn(vector<vector<int>>& list, vector<int>& grade_in) {
    vector<int> toposort;
    stack<int> s;

    for (int i = 1; i < grade_in.size(); i++) {
        if (grade_in[i] == 0) {
            s.push(i);
        }
    }

    while (!s.empty()) {
        int current = s.top();
        s.pop();
        toposort.push_back(current);
        stack<int> aux;

        for (int node : list[current]) {
            grade_in[node]--;
            if (grade_in[node] == 0) {
                aux.push(node);
            }
        }

        while (!aux.empty()) {
            s.push(aux.top());
            aux.pop();
        }

    }
    return toposort;
}

int main() {
    cin>>n>>m;
    vector<int> v;
    vector<vector<int>> lista(n+1,v);
    vector<int> grade_in(n + 1);
    for(int i=0; i<m; i++)
    {
        cin>>x>>y;
        lista[x].push_back(y);
        grade_in[y]++; //toposort
        //lista[y].push_back(x); //graf neorientat
    }
    for(int i=1; i<n; i++)
        sort(lista[i].begin(), lista[i].end());
    /*vector<int> result = bfs(lista, s);
    for(int i=1; i<result.size(); i++)
        cout<<result[i]<<' ';*/
    //cout<<dfs_wrapper(lista);
    
    vector<int> toposort = kahn(lista, grade_in);

        for (int& node : toposort) {
            cout << node << " ";
        }
    return 0;
}
