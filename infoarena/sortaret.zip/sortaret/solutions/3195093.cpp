#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int MAXN = 50000;
vector<int> G[MAXN + 1];
int N, M;
bool viz[MAXN + 1];
vector<int> sol;

void dfs(int nod) {
    viz[nod] = 1;
    for(const auto& x : G[nod]) {
        if(!viz[x])
            dfs(x);
    }
    sol.push_back(nod);
}

int main() {

    fin >> N >> M;
    int a, b;
    while(M--) {
        fin >> a >> b;
        G[a].push_back(b);
    }
    for(int i = 1; i <= N; ++i) {
        if(!viz[i])
            dfs(i);
    }
    reverse(sol.begin(), sol.end());
    for(const auto& x : sol)
        fout << x << ' ';
    return 0;
}