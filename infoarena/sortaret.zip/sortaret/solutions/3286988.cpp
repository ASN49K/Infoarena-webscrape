#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int MAX = 50005;
vector<int> graph[MAX];
set<int> s;
int degree[MAX];

void topSort()
{
    while (!s.empty())
    {
        int node = *s.begin();
        s.erase(node);
        fout << node << " ";
        for (int next : graph[node])
        {
            --degree[next];
            if (degree[next] == 0)
                s.insert(next);
        }
    }
}

int main()
{
    int n, m;
    fin >> n >> m;

    for (int i = 1; i <= m; ++i)
    {
        int x, y;
        fin >> x >> y;
        graph[x].push_back(y);
        ++degree[y];
    }

    for (int i = 1; i <= n; ++i)
        if (degree[i] == 0)
            s.insert(i);

    topSort();

    return 0;
}
