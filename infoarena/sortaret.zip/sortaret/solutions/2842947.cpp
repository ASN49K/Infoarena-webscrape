#include <iostream>
#include <fstream>
#include <vector>
#define MAX 50010

using namespace std;

int N, M, GradEX[MAX], Q[MAX];
vector<int> Grad[MAX];

ofstream out("sortaret.out");
ifstream in("sortaret.in");


void ANS()
{

    for(int i = 1; i <= N; i++)
        if(GradEX[i] == 0)
            Q[++Q[0]] = i;



    for(int i = 1; i <= N; i++)
    {
        int x = Q[i];
        for(auto elem : Grad[x])
        {

            GradEX[elem]--;
            if(GradEX[elem] == 0)
                Q[++Q[0]] = elem;

        }

    }

}

int main()
{
    int a, b;

    in>>N>>M;
    for(int i = 1; i <= M; i++)
    {
        in>>a>>b;
        Grad[a].push_back(b);
        GradEX[b]++;
    }
    ANS();
    for(int i = 1; i <= N; i++)
        out<<Q[i]<<" ";


    return 0;

}
