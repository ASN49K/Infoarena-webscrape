#include <bits/stdc++.h>
int main() {

    freopen("sortaret.in","r",stdin);
    freopen("sortaret.out","w",stdout);

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>>muchii(n + 1);
    std::vector<int>dependente(n + 1, 0);
    for(int i = 1; i <= m; i++)
    {
        int a, b;
        std::cin >> a >> b;
        muchii[a].push_back(b);
        dependente[b]++;
    }
    std::vector<int>sortat;
    std::queue<int>q;
    for(int i = 1; i <= n; i++)
    {
        if(dependente[i] == 0){
            q.push(i);
        }
    }
    while(!q.empty())
    {
        int curr = q.front();
        q.pop();
        sortat.push_back(curr);
        for(auto vecini : muchii[curr])
        {
            dependente[vecini]--;
            if(dependente[vecini] == 0)
                q.push(vecini);
        }
    }
    for(auto nod : sortat)
        std::cout << nod << ' ';
    return 0;
}
