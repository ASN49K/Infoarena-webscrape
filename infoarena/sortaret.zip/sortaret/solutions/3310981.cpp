#include <fstream>
#include <vector>
#include <algorithm>
#define nmax 50001
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int n,m,x,y;
bool viz[nmax];
vector<int>v[nmax],s;
void dfs(int nod){
    viz[nod]=1;
    for(auto i:v[nod])
        if(!viz[i])
            dfs(i);
    s.push_back(nod);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    reverse(s.begin(),s.end());
    for(auto i:s)
        cout<<i<<" ";
    return 0;
}
