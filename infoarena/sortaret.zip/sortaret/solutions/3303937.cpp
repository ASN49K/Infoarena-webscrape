#include <bits/stdc++.h>

using namespace std;

vector<int> adj[50005];
int ans[50005], poz, viz[50005];

void dfs(int x){
    viz[x] = 1;
    for(auto i : adj[x]){
        if(!viz[i]) dfs(i);
    }
    ans[poz--] = x;
}

int main(){
    
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    
    int n, m;
    cin >> n >> m;
    poz = n;
    for(int i = 1; i <= m; i++){
        int a, b;
        cin >> a >> b;
        adj[a].push_back(b);
    }
    for(int i = 1; i <= n; i++){
        if(!viz[i]) dfs(i);
    }
    for(int i = 1; i <= n; i++){
        cout << ans[i] << " ";
    }
    return 0;
}