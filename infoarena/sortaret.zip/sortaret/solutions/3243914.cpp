#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int nmax = 50005;
int n, m, fr[nmax];
vector<int> v[nmax], s;
queue<int> Q;

void sortop()
{
    while(!Q.empty())
    {
        int k = Q.front(); Q.pop();
        s.push_back(k);

        for(auto x : v[k])
        {
            fr[x] --;
            if(!fr[x])
                Q.push(x);
        }
    }
}

int main()
{
    f >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int x, y; f >> x >> y;
        v[x].push_back(y);
        fr[y] ++;
    }

    for(int i = 1; i <= n; i ++)
        if(!fr[i])
            Q.push(i);

    sortop();

    for(int i = 0; i < n; i ++)
        g << s[i] << " ";
    return 0;
}
