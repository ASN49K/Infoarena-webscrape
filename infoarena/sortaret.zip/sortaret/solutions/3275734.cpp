#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector <int> v[50005];
int n,m,i,viz[50005],x,y;
void dfs(int s)
{viz[s]=1;
for(int i:v[s])
    {if(!viz[i])
        dfs(i);
    }
g<<s<<" ";
}
int main()
{f>>n>>m;
for(i=1;i<=m;i++)
    {f>>x>>y;
    v[x].push_back(y);
    }
for(i=1;i<=n;i++)   
    {if(!viz[i])
        dfs(i);

    }
}