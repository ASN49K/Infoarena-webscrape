#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");
const int Nmax=50000;

int n, m, gr[Nmax];
vector <int> ad[Nmax];
queue <int> q;
int main()
{
    fin>>n>>m;
    int a, b;
    for (int i=0; i<m; i++){
        fin>>a>>b;
        a--; b--;
        gr[b]++;
        ad[a].push_back(b);
    }
    for (int i=0; i<n; i++)
        if (gr[i]==0)
            q.push(i);
    while (!q.empty()){
        fout<<q.front()+1<<' ';
        for (int i=0; i<ad[q.front()].size(); i++){
            gr[ad[q.front()][i]]--;
            if (gr[ad[q.front()][i]]==0)
                q.push(ad[q.front()][i]);
        }
        q.pop();
    }
    return 0;
}
