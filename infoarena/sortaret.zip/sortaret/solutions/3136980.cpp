#include <fstream>
#include <vector>
#include <list>

using namespace std;
vector<int> v[50001];
bool vizitati[50001];
list<int> lista;

void f(int n) {
    vizitati[n] = true;
    for (unsigned i = 0; i < v[n].size(); i++) {
        if (!vizitati[v[n][i]]) {
            f(v[n][i]);
        }
    }
    lista.push_front(n);
}

int main() {
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int a, b;
        fin >> a >> b;
        v[a].push_back(b);
    }
    for (int i = 1; i <= n; i++) {
        if (!vizitati[i]) {
            f(i);
        }
    }
    for (int i: lista) {
        fout << i << " ";
    }

    fin.close();
    fout.close();
    return 0;
}
