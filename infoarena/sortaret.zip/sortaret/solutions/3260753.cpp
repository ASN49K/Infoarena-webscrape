#include <fstream>
#include <vector>
#include <unordered_set>

#define NMAX 50005

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n, m;
vector<int> edges[NMAX];
bool visited[NMAX];

void dfs(int node) {
    visited[node] = 1;
    g << node << " ";
    for (auto child : edges[node]) {
        if (!visited[child])
            dfs(child);
    }
}

int main() {
    f >> n >> m;
    
    unordered_set<int> s;
    for (int i = 0; i < n; i++) {
        s.insert(i);
    }

    for (int i = 0; i < m; i++) {
        int x, y;
        f >> x >> y;
        edges[x].push_back(y);
        if (s.find(y) != s.end()) s.erase(y);
    }

    while (!s.empty()) {
        int start = *s.begin();
        s.erase(s.begin());
        dfs(start);
    }

    return 0;
}