#include <bits/stdc++.h>

using namespace std;
const int NMAX  = 1e5 + 10;
vector<int>g[NMAX];
queue<int>q;
int grad[NMAX];
int n,m;
signed main()
{
    cin>>n>>m; int x,y;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        grad[y]++;
        g[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
    {
        if(grad[i] == 0)
            q.push(i);
    }
    int nod;
    while(!q.empty())
    {
        nod = q.front();
        for(auto i : g[nod])
        {
            grad[i]--;
            if(grad[i] == 0)
            {
                q.push(i);
            }
        }
        cout<<nod<<' ';
        q.pop();
    }
}
