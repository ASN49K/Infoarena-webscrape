#include <array>
#include <cstdint>
#include <forward_list>
#include <fstream>
#include <vector>


using u32 = uint32_t;

constexpr size_t MAX_NODES = 50000;


std::forward_list<size_t> result;

std::array<std::vector<size_t>, MAX_NODES> edges;


std::array<bool, MAX_NODES> viz;
void dfs (size_t node) {
    viz[node] = true;

    for (auto to: edges[node])
        if (!viz[to])
            dfs(to);

    result.emplace_front(node);
}

int main () {
    std::ifstream in("sortaret.in");
    std::ofstream out("sortaret.out");

    size_t nodeCount, edgeCount;
    in >> nodeCount >> edgeCount;

    for (size_t i = 0; i != edgeCount; ++ i) {
        size_t x, y;
        in >> x >> y;
        -- x, -- y;

        edges[x].emplace_back(y);
    }

    for (size_t i = 0; i != nodeCount; ++ i)
        if (!viz[i])
            dfs(i);

    for (auto val: result)
        out << val + 1 << ' ';
}
