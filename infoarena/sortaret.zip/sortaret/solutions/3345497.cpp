#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int maxn = 50005;

vector<int> g[maxn];
int grad[maxn];

int main() {
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");

    int n, m;
    in >> n >> m;

    for (int i = 1; i <= m; ++i) {
        int x, y;
        in >> x >> y;
        g[x].push_back(y);
        ++grad[y];
    }

    queue<int> q;

    for (int i = 1; i <= n; ++i)
        if (grad[i] == 0)
            q.push(i);

    vector<int> sol;

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        sol.push_back(nod);

        for (int j = 0; j < g[nod].size(); ++j) {
            int vecin = g[nod][j];
            --grad[vecin];
            if (grad[vecin] == 0)
                q.push(vecin);
        }
    }

    for (int i = 0; i < sol.size(); ++i)
        out << sol[i] << " ";

    return 0;
}
