#include <fstream>
#include <vector>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int N, M;
vector<int> g[50000], v;

void citire()
{
    v.resize(50000);
    fin >> N >> M;
    int i, j;
    for (int k = 0; k < M; k++)
    {
        fin >> i >> j;
        g[i].push_back(j);
    }
}

void dfs(int nod)
{
    v[nod] = 1;
    fout << nod << ' ';
    for (int i : g[nod])
    {
        if (!v[i])
        {
            dfs(i);
        }
    }
}

int main()
{
    citire();
    dfs(1);

    return 0;
}