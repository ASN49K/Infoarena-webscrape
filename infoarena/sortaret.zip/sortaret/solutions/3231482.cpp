#include <fstream>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int matrix[10001][10001], used[100];
int n,m;

void read() {
  fin >> n >> m;
  for (int i = 1; i <= m; i++) {
    int x,y;
    fin >> x >> y;
    matrix[x][y] = 1;
  }
}

void dfs(int node) {
  fout << node << " ";
  used[node] = 1;
  for (int i = 1; i <= n; i++)
    if (matrix[node][i] && !used[i])
      dfs(i);
}

int main() {
  read();
  for (int node = 1; node <= n; node++)
    if (!used[node])
      dfs(node);
  return 0;
}
