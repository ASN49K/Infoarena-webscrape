#include<bits/stdc++.h>
using namespace std;

const int N = 50005;
int n, taken, deg[N];
vector<int> prov[N], sol;

ifstream in ("sortaret.in");
ofstream out("sortaret.out");
// auto& in = cin;
// auto& out = cout;

void read()
{
	int m, x, y;
	in>>n>>m;
	for(int i=0;i<m;i++)
	{
		in>>x>>y;
		prov[x].push_back(y);
		deg[y]++;
	}
}
void visit(int p)
{
	for(auto el=prov[p].begin(); el!=prov[p].end(); ++el)
		if(--deg[*el] == 0)
			sol.push_back(*el);
	// prov[p].clear();

}
void show()
{
	for(int i=0;i<sol.size();i++)
		out<<sol[i]<<' ';
	out<<endl;
}
int main(){
	read();
	
	for(int i=1;i<=n;i++)
		if(deg[i]==0)
			sol.push_back(i);
		
	while(taken<sol.size())
		visit(sol[taken++]);
	
	show();
	
	return 0;
}
