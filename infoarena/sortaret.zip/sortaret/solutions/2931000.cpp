#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("sortaret.in");
ofstream fout ("sortaret.out");

const int MAX_N = 50005;
const int MAX_M = 100005;
int n, m;
int out[MAX_N];
vector <int> in[MAX_N];
queue <int> stp;

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin>>n>>m;
    for(int i=1; i<=m; i++){
        int u, v;
        fin>>u>>v;
        in[u].emplace_back(v);
        out[v]++;
    }

    for(int i=1; i<=n; i++)
        if(!out[i])
            stp.push(i);

    while(!stp.empty()){
        int nod = stp.front();
        stp.pop();
        fout<<nod<<" ";
        for(auto parent : in[nod]){
            out[parent]--;
            if(!out[parent])
                stp.push(parent);
        }
    }
    return 0;
}
