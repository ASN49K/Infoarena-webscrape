#include <bits/stdc++.h>
#include <fstream>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int> L[100001];
vector<int> viz(100001, 0), grad(100001, 0);
queue<int> q;

void dfs(int node)
{
    viz[node] = 1;

    for(auto v: L[node])
    {
        if(viz[v] == 0)
        {
            q.push(v);
            dfs(v);
        }
        
    }
}

int main()
{
    int n, m;

    fin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        fin >> x >> y;

        L[x].push_back(y);
        grad[y] ++;
    }

    for(int i = 1; i <= n; i ++)
    {
        if(grad[i] == 0)
            q.push(i);
    }

    while(!q.empty())
    {
        int node = q.front();
        fout << node << ' ';
        q.pop();

        dfs(node);
    }

    return 0;
}