#include<fstream>
#include<vector>
#include<bitset>
#include<stack>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
vector<unsigned short> a[50001];
bitset<50001> b;
stack<unsigned short> c;
void A(int i)
{
    b[i]=1;
    for(int j:a[i])
        if(!b[j])
            A(j);
    c.push(i);
}
int main()
{
    unsigned short n;
    int m;
    for(cin>>n>>m;m--;) {
        unsigned short i,j;
        cin>>i>>j,a[i].push_back(j);
    }
    for(A(1);!c.empty();cout<<c.top()<<' ',c.pop());
    return 0;
}
