#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int n, m, vizitat[50001], v[50000], nr;
vector<int> vecini[50001];

void Citire()
{
    ifstream f("sortaret.in");

    int nod1, nod2;

    f >> n >> m;

    for(int i = 0; i < m; i++)
    {
        f >> nod1 >> nod2;
        vecini[nod1].push_back(nod2);
    }
}

void DFS(int varf)
{
    vizitat[varf] = 1;

    for(int i = 0; i < vecini[varf].size(); i++)
        if(!vizitat[vecini[varf][i]])
            DFS(vecini[varf][i]);
    v[nr++] = varf;
}

void Afisare()
{
    ofstream g("sortaret.out");
    for(int i = nr - 1; i >= 0; i--)
        g << v[i] << ' ';
}

void SortareTopologica()
{
    for(int i = 1; i <= n; i++)
        if(!vizitat[i])
            DFS(i);
}

int main()
{
    Citire();
    SortareTopologica();
    Afisare();

    return 0;
}
