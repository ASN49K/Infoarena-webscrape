#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
int n, m;
int intrari[50001];
queue<int>q;
vector <int> adiacenta[50001];
int main()
{
	f >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		int nr1, nr2;
		f >> nr1 >> nr2;
		adiacenta[nr1].push_back(nr2);
		intrari[nr2]++;
	}
	for (int i = 1; i <= n; i++)
	{
		if (intrari[i] == 0)
		{
			q.push(i);
			g << i << " ";
		}
	}
	while (!q.empty())
	{
		int curent = q.front();
		q.pop();

		for (auto x : adiacenta[curent])
		{
			q.push(x);
			g << x << " ";	
		}
	}
}