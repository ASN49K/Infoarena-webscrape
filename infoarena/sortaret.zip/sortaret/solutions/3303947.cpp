#include <fstream>
#include <stack>
#include <vector>


using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
void dfs(int nod);
const int marian = 2e9+7;

int n, m;
bool vizitat[50001];
stack<int> s;
vector<int> vecini[50001];


int main()
{
    cin>>n>>m;
    for(int i = 1; i <= m; ++i)
    {
        int x, y;
        cin>>x>>y;
        vecini[x].push_back(y);
    }
    for(int i = 1; i <= n; ++i)
    {
        if(!vizitat[i])
            dfs(i);
    }

    while(!s.empty())
    {
        cout<<s.top()<<" ";
        s.pop();
    }


    return 0;
}



void dfs(int nod)
{
    vizitat[nod] = true;
    for(auto i : vecini[nod])
    {
        if(!vizitat[i])
        {
            dfs(i);
        }
    }
    s.push(nod);
}





