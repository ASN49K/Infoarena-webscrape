#include <fstream>
#include <vector>
#define NMAX 50000

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, nr;
int sol[NMAX], v[NMAX];
vector<int> G[NMAX];
void citire();
void sortaret();
void afisare();

int main()
{
    citire();
    sortaret();
    afisare();
    return 0;
}
void citire()
{
    int i, m, x, y, j;
    fin>>n>>m;
    for (i=0; i<m; i++)
    {
        fin>>x>>y;
        for (j=0; j<G[x].size() && G[x][j]!=y; j++);
        if (j==G[x].size())
        {
            G[x].push_back(y);
            v[y]++;
        }
    }
}
void sortaret()
{
    int i, j;
    while (nr<n)
    {
        for (i=1; i<=n && v[i]!=0; i++);
        if (v[i]==0)
        {
            sol[++nr]=i;
            v[i]=-1;
            for (j=0; j<G[i].size(); j++)
                v[G[i][j]]--;
        }
    }
}
void afisare()
{
    int i;
    for (i=1; i<=n; i++)
        fout<<sol[i]<<" ";
}
