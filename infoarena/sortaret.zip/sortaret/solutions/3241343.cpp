#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int NMAX = 50001;

vector<vector<int>>G(NMAX);
bool viz[NMAX];
int sol[NMAX], nr;

void dfs(int x)
{
    viz[x] = 1;
    for(auto y : G[x])
        if(viz[y] == 0)
            dfs(y);
    sol[++nr] = x;

}

int main()
{

    int n, m, x, y;
    f >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
    }
    for(int i = 1; i <= n; i++)
        if(viz[i] == 0)
            dfs(i);
    for(int i = nr; i > 0; i--)
        g << sol[i] << ' ';
    return 0;
}
