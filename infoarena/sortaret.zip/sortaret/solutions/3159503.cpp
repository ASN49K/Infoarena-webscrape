#include <bits/stdc++.h>

using namespace std;
vector<int>v[50000];
int ans[50005];
bool vizitat[50005];
int cnt=0;
void dfs(int a)
{
    vizitat[a]=1;
    for (auto it:v[a])
    {
        if (!vizitat[it])
            dfs(it);
    }
    ans[++cnt]=a;
}
int main()
{
    ifstream cin ("sortaret.in");
    ofstream cout ("sortaret.out");
    int n, m, a, b;
    cin>>n>>m;
    for (int i=1; i<=m; i++)
    {
        cin>>a>>b;
        v[a].push_back(b);
    }
    for (int i=1; i<=n; i++)
    {
        if (!vizitat[i])
        {
            dfs(i);
        }
    }
    for (int i=n; i>=1; i--)
    {
        cout<<ans[i]<<" ";
    }
}
