#include <iostream>
#include <queue>
#include <fstream>
#include<vector>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");
int n,m,x,y;
vector<int> d(n+1,0);
vector<vector<int>> lista(n+1);
int main()
{
    f>>n>>m;
    for(int i=0; i<m; i++)
    {
        f>>x>>y;
        d[y]++;
        lista[x].push_back(y);
    }
    queue<int> coada;
    for(int i=1; i<=n; i++)
        if(d[i]==0)
            coada.push(i);
    while(!coada.empty())
    {
        int i = coada.front();
        g<<i<<" ";
        coada.pop();
        for(auto vec:lista[i])
        {
            d[vec]--;
            if(d[vec]==0)
                coada.push(vec);
        }
    }
}
