#include <bits/stdc++.h>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

const int N=5e4+5,M=1e5+5;
struct lista
{
    vector <int> v;
}la[M];
vector <int> sol;
bool parcurs[N];

bool Done(int n)
{
    for(int i=1;i<=n;i++)
        if(!parcurs[i]) return 0;
    return 1;
}

bool Visit(int nod)
{
    if(parcurs[nod]) return 0;
    parcurs[nod]=1;

    for(int i=0;i<la[nod].v.size();i++)
        {
            if(!Visit(la[nod].v[i])) return 0;
        }
    sol.push_back(nod);
    return 1;
}

void TopSort(int n)
{
    do
    {
        for(int i=1;i<=n;i++)
            if(!parcurs[i]) Visit(i);
    }while(!Done(n));
}

int main()
{
    int n,m;
    in>>n>>m;

    for(int i=1;i<=m;i++)
    {
        int x,y;
        in>>x>>y;
        la[x].v.push_back(y);
    }
    TopSort(n);

    for(int i=sol.size()-1;i>=0;i--)
        out<<sol[i]<<' ';
    return 0;
}
