#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, viz[50005], st[50005], top;
vector <int> h[50005];

void DFS(int k)
{
    viz[k] = 1;
    for (int w : h[k])
        if (viz[w] == 0) DFS(w);
    st[++top] = k;
}

void SortTop()
{
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0) DFS(i);
}

void Afisare()
{
    for (int i = n; i > 0; i--)
        fout << st[i] << " ";
    fout << "\n";
    fout.close();
}

int main()
{

    int x, y;
    fin >> n >> m;
    while (m--)
    {
        fin >> x >> y;
        h[x].push_back(y);
    }
    SortTop();
    Afisare();
    fin.close();

    return 0;
}
