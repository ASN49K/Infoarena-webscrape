#include <iostream>
#include <algorithm>

using namespace std;
void solve()
{
    int v[51], v2[51], ok = 0,n,k;
    cin >> n >> k;
    for(int i = 1; i<=n; i++) cin >> v[i];
    for(int i = 1; i<=n; i++) cin >> v2[i];
    sort(v + 1, v + n + 1);
    sort(v2 + 1, v2 + n + 1);
    for(int i = 1; i<=n; i++)
    {
        if(v[i] + v[n-i + 1] > k) ok = 1;
    }
    cout <<(ok == 1 ? "No" : "Yes") << '\n';
}
int main()
{
    int t;
    cin >> t;
    while(t--) solve();
    return 0;
}
