#include <bits/stdc++.h>

using namespace std;

vector <int> graph[100005];
bool visited[100005];
vector <int> topoSort;


void dfs(int node) {
    visited[node] = true;
    for (auto x : graph[node]) {
        if (!visited[x]) {
            dfs(x);
        }
    }
    topoSort.push_back(node);
}

int main()
{
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
    }
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i);
        }
    }
    reverse(topoSort.begin(), topoSort.end());
    for (auto x : topoSort) {
        cout << x << " ";
    }
    return 0;
}