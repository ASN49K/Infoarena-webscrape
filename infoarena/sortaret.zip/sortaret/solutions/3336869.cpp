#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int N, M, a, b, grad[50005];
vector<int> G[50005];
vector <int> sort_top;
queue<int>q;
int main()
{
    fin >> N >> M;
    for(int i = 1; i <= M; i++)
    {
        fin >> a >> b;
        G[a].push_back(b);
        grad[b]++;
    }
    for(int i = 1; i <= N; i++)
        if(grad[i] == 0)
            q.push(i);
    while(q.size())
    {
        int acc = q.front();
        q.pop();
        sort_top.push_back(acc);
        for(auto e : G[acc])
        {
            grad[e]--;
            if(grad[e] == 0)
                q.push(e);
        }
    }
    for(auto e : sort_top)
        fout << e << ' ';
    return 0;
}
