#include <iostream>
#include <queue>
#include <vector>
using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

const int N=50005;
int n,m,di[N];
vector <int> g[N];

void citire()
{
    cin>>n>>m;
    int x,y;
    for(int i=0; i<m; i++)
    {
        cin>>x>>y;
        di[y]++;
        g[x].push_back(y);
    }
}
void bfs()
{
    queue <int>q;
    for(int i=1;i<=n;i++)
        if(di[i]==0)
          q.push(i);
    while(!q.empty())
    {
        int x=q.front();
        for(auto i:g[x])
        {
            if(di[i])
                di[i]--;
            if (di[i]==0)
                q.push(i);
        }
        cout<<x<<' ';
        q.pop();
    }
}
int main()
{
    citire();
    bfs();
    return 0;
}
