#include<fstream>
#include<iostream>
#include<vector>
using namespace std;

#define fileIn "sortaret.in"
#define fileOut "sortaret.out"
#define nul nullptr

#define MAX_N 100000
#define MAX_M 400000

int n, m, in[MAX_N + 1], fin[MAX_N + 1], k;
bool viz[MAX_N + 1];

struct arce {
	int x, y;
}v[MAX_N + 1];

void citire() {
	ifstream fin(fileIn);
	fin >> n >> m;
	for (int i = 1; i <= m; i++)
		fin >> v[i].x >> v[i].y;
	fin.close();
}

void vizitat(int x) {
	viz[x] = 1;
	for (int i = 1; i <= m; i++)
		if (v[i].x == x && !viz[v[i].y]) vizitat(v[i].y);
	fin[++k] = x;
}

void afisare() {
	ofstream fout(fileOut);
	for (int i = n; i > 0; i--) fout << fin[i] << ' ';
	fout.close();
}

int main() {
	citire();
	for (int i = 1; i <= n; i++)
		if(!viz[i]) vizitat(i);
	afisare();
	return 0;
}