#include <bits/stdc++.h>
using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
const int lim=5e4+5;
vector<int> vec[lim];
stack<int> st;
bool ok[lim];
int n,m,x,y;
void df(int nod)
{
    ok[nod]=true;
    for(int x:vec[nod])
    if(!ok[x]) df(x);
    st.push(nod);
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;++i)
        in>>x>>y,
        vec[x].push_back(y);
    for(int i=1;i<=n;++i)
    if(!ok[i]) df(i);
    while(!st.empty())
        out<<st.top()<<' ',
        st.pop();
    out<<'\n';
    return 0;
}
