#include <bits/stdc++.h>

int main() {
#ifndef LOCAL
  freopen("sortaret.in", "r", stdin);
  freopen("sortaret.out", "w", stdout);
#endif
  int N;
  int M;
  std::cin >> N >> M;
  std::vector<int> D(N);
  std::vector<std::vector<int>> G(N);
  for (; M--;) {
    int u;
    int v;
    std::cin >> u >> v;
    --u;
    --v;
    G[u].push_back(v);
    ++D[v];
  }
  std::queue<int> Q;
  for (int u = 0; u < N; ++u) {
    if (!D[u]) {
      Q.push(u);
    }
  }
  for (; !Q.empty();) {
    int const u = Q.front();
    Q.pop();
    std::cout << u + 1 << " ";
    for (int const v : G[u]) {
      if (!(--D[v])) {
        Q.push(v);
      }
    }
  }
  return 0;
}