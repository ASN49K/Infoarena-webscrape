///Sortare topologica
#include <bits/stdc++.h>

using namespace std;

ifstream f("soratret.in");
ofstream g("soratret.out");

int n, m, grad[100001];
vector <int> vecini[100001];

void sortTopo()
{
    queue <int> q;

    for (int i=1;i<=n;i++)
        if (grad[i] == 0)
            q.push(i);

    while (!q.empty())
    {
        int i = q.front();
        g<<i<<" ";
        q.pop();

        for (auto j : vecini[i])
        {
            grad[j]--;
            if (grad[j] == 0)
                q.push(j);
        }
    }
}

int main()
{
    f>>n>>m;
    for (int i=1;i<=m;i++)
    {
        int x, y;
        f>>x>>y;
        vecini[x].push_back(y);
        grad[y]++;
    }
    sortTopo();
}
