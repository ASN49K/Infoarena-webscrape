#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int NMAX = 100005;

vector <int> g[NMAX];
vector <int> topo;
queue <int> q;
int inDegree[NMAX];

void sortare_topologica(){
    while(!q.empty()){
        int t = q.front();
        q.pop();
        topo.push_back(t);
        for(auto i:g[t]){
            if(inDegree[i] > 0)
            inDegree[i] --;
            if(inDegree[i] == 0){
                q.push(i);
            }
        }
    }
}

void solve(){
    int n, m;
    fin >> n >> m;
    for(int i = 1; i <= n; ++i){
        inDegree[i] = 0;
    }
    for(int i = 1; i <= m; ++i){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        inDegree[y] ++;
    }
    for(int i = 1; i <= n; ++i){
        if(inDegree[i] == 0){
            q.push(i);
        }
    }
    sortare_topologica();
    for(int i = 0; i < n; ++i){
        fout << topo[i] << " ";
    }
}

int main()
{
    solve();
    return 0;
}
