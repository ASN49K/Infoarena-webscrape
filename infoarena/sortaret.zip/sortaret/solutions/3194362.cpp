#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int> G[50000];
queue<int> Q;
int n, m;
vector<int> gradint(50000, 0);

void citire() {
    fin >> n >> m;
    int a, b;
    for (int i = 0; i < m; i++) {
        fin >> a >> b;
        G[a].push_back(b);
        gradint[b]++;
    }
}

void stopo() {
    for (int i = 1; i <= n; i++) {
        if (gradint[i] == 0) {
            Q.push(i);
        }
    }

    while (!Q.empty()) {
        int vf = Q.front();
        Q.pop();
        fout << vf << ' ';

        for (int i = 0; i < G[vf].size(); i++) {
            int vecin = G[vf][i];
            gradint[vecin]--;
            if (gradint[vecin] == 0) {
                Q.push(vecin);
            }
        }
    }
}

int main() {
    citire();
    stopo();

    return 0;
}
