#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int MaxN = 50005;
vector<int>g[MaxN];
int n, m, viz[MaxN], st[MaxN], top;

void Dfs(int nod){
    viz[nod] = 1;
    for(auto i : g[nod])
        if(!viz[i])
            Dfs(i);
    st[++top] = nod;
}

void SorTop(){
    for(int i = 1; i <= n; i++)
        if(!viz[i])
            Dfs(i);
    for(int i = n; i >= 1; i--)
        fout << st[i] << " ";
}

int main()
{
    int x, y;
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        fin >> x >> y;
        g[x].push_back(y);
//        g[y].push_back(x);
    }
    SorTop();
    return 0;
}
