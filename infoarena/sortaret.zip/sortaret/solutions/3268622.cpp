#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector <int > G[50001];
int n,m,x,y,vis[50001];
void dfs(int x)
{ vis[x]=1;
for(int i : G[x])
{
    if(!vis[i])
        dfs[i];
}
cout<<x<<" ";
}
int main()
{cin>>n>>m;
for(int i=1;i<=m;++i)
{
    cin>>x>>y;
    G[y].push_back(x);
}
for(int i=1;i<=n;++i)
{
    if(!vis[i])
        dfs(i);
}
    return 0;
}
