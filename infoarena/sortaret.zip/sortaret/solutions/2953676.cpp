#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int NMAX = 50005;
const int MMAX = 100005;

int n, m;
vector <int> G[NMAX];
stack <int> st;
int viz[NMAX];

void read(){
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
}

void DFS(int nod){
    viz[nod] = 1;
    for(auto nbr: G[nod]){
        if(!viz[nbr]){
           DFS(nbr);
        }
    }
    st.push(nod);
}

int main()
{
    read();
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            DFS(i);
        }
    }
    while(!st.empty()){
        fout << st.top() << " ";
        st.pop();
    }
    return 0;
}
