#include<bits/stdc++.h>
using namespace std;
#define MAX_NODES (int)5e4
#define MAX_EDGES (int)1e5
vector<int>adj[MAX_NODES+1];
int in_deg[MAX_NODES+1];
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int main() {
    int num_nodes,num_edges;
    fin>>num_nodes>>num_edges;
    while(num_edges--) {
        int u,v;
        fin>>u>>v;
        adj[u].push_back(v);
        in_deg[v]++;
    }
    vector<int>ts;
    queue<int>q;
    for(int i=1; i<=num_nodes; i++) {
        if(!in_deg[i]) {
            q.push(i);
        }
    }
    while(!q.empty()) {
        int u=q.front();
        q.pop();
        ts.push_back(u);
        for(auto v:adj[u]) {
            in_deg[v]--;
            if(!in_deg[v]) {
                q.push(v);
            }
        }
    }
    for(int i=0; i<ts.size(); i++) {
        fout<<ts[i]<<' ';
    }
    return 0;
}
