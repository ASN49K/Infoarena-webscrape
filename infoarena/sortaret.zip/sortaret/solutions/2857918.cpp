#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;

struct node
{
    vector<int> vecini;
    int nrVecini;
    bool vizitat;
}v[100001];

void citire()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int a, b;
        fin >> a >> b;
        v[a].vecini.push_back(b);
        v[b].vecini.push_back(a);
    }
}

void dfs(int inceput)
{
    stack<pair<int,int>> st;
    st.push({inceput,0});
    v[inceput].vizitat = true;
    fout << inceput << ' ';

    while(!st.empty())
    {
        auto &t = st.top();
        int nod = t.first;
        int i = t.second;

        if(i < v[nod].vecini.size())
        {
            int x = v[nod].vecini[i];
            t.second = i+1;

            if(!v[x].vizitat)
            {
                fout << x << ' ';
                v[x].vizitat = true;
                st.push({x,0});
            }
        }
        else
            st.pop();
    }
}

void afisare()
{
    for(int i = 1; i <= n; i++)
        if( !v[i].vizitat )
            dfs(i);
}

int main()
{
    citire();
    afisare();

    return 0;
}
