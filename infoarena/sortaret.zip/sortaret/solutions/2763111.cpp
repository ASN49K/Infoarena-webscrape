#include <bits/stdc++.h>
#include <list>
#include <ext/pb_ds/assoc_container.hpp>
#define FOR(i , n) for(int i = 0 ; i < (n) ; i++)
#define N 201
#define apare printf("apare");
#define endl "\n"
using namespace __gnu_pbds;
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int , int> pii;
const int inf = 1e6;
const int nax = 50001;
set<int>adj[nax];
vector<bool> visited(nax , false);
vector<int> topologic;

void dfs(int node){
    if(visited[node]) return;
    topologic.push_back(node);
    visited[node] = true;
    for(auto it : adj[node]){
        dfs(it);
    }
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    freopen("sortaret.in" , "r" , stdin);
    freopen("sortaret.out" , "w" , stdout);
    int nodes , m;
    cin >> nodes >> m;
    int buffer1 , buffer2;
    FOR(i , m){
        cin >> buffer1 >> buffer2;
        adj[buffer1].insert(buffer2);
        adj[buffer2].insert(buffer1);
    }
    for(int i = 1 ; i <= nodes ; i++){
        if(!visited[i])
            dfs(i);
    }
    for(auto it : topologic){
        cout << it << " ";
    }
    cout << endl;
    return 0;
}