#include <bits/stdc++.h>

using namespace std;

ifstream fin("topsort.in");
ofstream fout("topsort.out");

vector <int> Graf[50001];
stack <int> Stiva;
bool vizitat[50001];

void TopSort(int Nod)
{
    vizitat[Nod] = true;
    for(int i = 0; i < Graf[Nod].size(); i++)
    {
        int Vecin = Graf[Nod][i];
        if(!vizitat[Vecin])
        {
            //fout << Vecin << " ";
            TopSort(Vecin);
            Stiva.push(Vecin);
        }
    }
}

int main()
{
    int n, m, a, b;
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        fin >> a >> b;
        Graf[a].push_back(b);
    }
    for(int i = 1; i <= n; i++)
    {
        if(!vizitat[i])
        {
            TopSort(i);
            Stiva.push(i);
        }
    }
    for(int i = 1; i <= n; i++)
    {
        fout << Stiva.top() << " ";
        Stiva.pop();
    }
    return 0;
}
