#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, x, y;
bool viz[50001], nst[50001];
vector<vector<int>> a(50001);
vector<int> rez;

void dfs(int x) {
    if (viz[x]) {
        return;
    }
    viz[x] = 1;

    for (int i : a[x]) {
        dfs(i);
    }

    rez.push_back(x);
}

int main() {
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        a[x].push_back(y);
        nst[y] = 1;
    }
    for (int i = 1; i <= n; i++) {
        sort(a[i].begin(), a[i].end());
        a[i].erase(unique(a[i].begin(), a[i].end()), a[i].end());
    }

    for (int st = 1; st <= n; st++) {
        if (!nst[st]) {
            dfs(st);
        }
    }

    for (int i = rez.size() - 1; i >= 0; i--) {
        fout << rez[i] << " ";
    }
}
