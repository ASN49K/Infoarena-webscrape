#include <cstdio>

#include <vector>

#include <stack>

#define NMAX 50000



using namespace std;



int freq[NMAX+5];

vector <int> v[NMAX+5];

stack <int> st;



void dp(int x)

{

    vector<int>::iterator i;

    for(i = v[x].begin(); i < v[x].end(); i++)

    {

        if(freq[*i]==0)

        {

            freq[*i]=1;

            dp(*i);

        }

    }

    st.push(x);

}



int main()

{

    freopen("sortaret.in","r",stdin);

    freopen("sortaret.out","w",stdout);

    int n,m,x,y,i;

    scanf("%d%d",&n,&m);

    for(i=1;i<=m;i++)

    {

        scanf("%d%d",&x,&y);

        v[x].push_back(y);

    }

    for(i=1;i<=n;i++)

    {

        if(freq[i]==0)

        {

            dp(i);

        }

    }

    while(!st.empty())

    {

        printf("%d ",st.top());

        st.pop();

    }

    return 0;

}

