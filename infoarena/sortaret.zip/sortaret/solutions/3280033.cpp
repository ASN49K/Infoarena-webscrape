#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector<int>L[50010],Post;
bitset<50010>viz;
int n,m,x,y;

void DFS(int nod) {
    viz[nod]=1;
    for(const auto&q:L[nod]) {
        if(viz[q]==0) {
            DFS(q);
        }
    }
    Post.push_back(nod);
}

int main() {
    f>>n>>m;
    while(m--) {
        f>>x>>y;
        L[x].push_back(y);
    }
    for(int i=1; i<=n; i++) {
        if(viz[i]==0) {
            DFS(i);
        }
    }

    for(int i=Post.size()-1; i>=0; i--) {
        g<<Post[i]<<' ';
    }
    f.close();
    g.close();
    return 0;
}
