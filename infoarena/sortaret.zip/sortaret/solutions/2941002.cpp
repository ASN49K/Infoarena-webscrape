#include<fstream>
#include<iostream>
#include<climits>
#include<algorithm>
#include<cstring>
#include<cmath>
#include <vector>
#include <queue>

#define MAX 50000
#define INF 1005

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

//ifstream f("in.in");
//ofstream g("out.out");

vector <int> l[MAX+5];
int n,m,x,y;
int k=0,sol[MAX+5];
bool viz[MAX+5];

void dfs(int nod){
    viz[nod] = 1;
    for(int i=0;i<l[nod].size();i++){
        int vecin  = l[nod][i];
        if(viz[vecin] == 0){
            dfs(vecin);
        }
    }
    k++;
    sol[k] = nod;
}

int main(){

    f>>n>>m;

    for(int i=1;i<=m;i++){
        f>>x>>y;
        l[x].push_back(y);
    }

    for(int i=1;i<=n;i++){
        if(viz[i] == 0){
            dfs(i);
        }
    }

    for(int i=k;i>=1;i--){
        g<<sol[i]<<" ";
    }

    f.close();
    g.close();
    return 0;
}
