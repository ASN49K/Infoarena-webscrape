﻿#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
const int N = 5e4 + 5; // nr maxim de noduri
vector<int> a[N];      // Lista de ad pentru graf
int parent[N];         
int viz[N];          
int n, m, x, y;
int in[N];
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    f >> n >> m;
    for (int i = 1;i <= m;i++)
    {
        f >> x >> y;
        a[x].push_back(y);
        in[y]++;
    }
    queue<int>q;
    for (int i = 1;i <= n;i++)
        if (in[i] == 0)
            q.push(i);
    while (!q.empty())
    {
        int nod = q.front();
        q.pop();
        g << nod << " ";
        for (auto x : a[nod])
        {
            in[x]--;
            if(in[x]==0)
				q.push(x);
        }
    }
    return 0;
}
