#include <bits/stdc++.h>
using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");
#define cin f
#define cout g

vector<vector<int>> adj;
vector<bool> vis;
stack<int> ans;

void dfs(int node) {
	vis[node] = 1;

	for (int x : adj[node])
		if (!vis[x])
			dfs(x);

	ans.push(node);
}

int main() {
	int n, m;
	cin >> n >> m;

	adj.resize(n+1);
	vis.resize(n+1, 0);

	for (int i = 0; i < m; i++) {
		int u, v;
		cin >> u >> v;
		adj[u].push_back(v);
	}

	for (int i = 1; i <= n; i++)
		if (!vis[i])
			dfs(i);

	while (!ans.empty()) {
		cout << ans.top() << " ";
		ans.pop();
	}

	return 0;
}