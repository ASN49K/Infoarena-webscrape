#include <bits/stdc++.h>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
#define fi first
#define se second

#define NMAX 100005
#define MOD 1999999973
#define INF 0x3f3f3f3f

int n, m;
int incoming[NMAX];
vector<vector<int>> graf(NMAX);
vector<int> top;

void read()
{
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; i++)
        in >> x >> y, graf[x].push_back(y), incoming[y]++;
}

void BFS()
{
    queue<int> Q;
    for (int i = 1; i <= n; i++)
        if (!incoming[i])
            Q.push(i); // nu vine niciun nod deci se pot aseza la inceputul sortarii topologice

    while (!Q.empty())
    {
        int node = Q.front();
        Q.pop();
        top.push_back(node);

        for (auto e : graf[node])
        {
            incoming[e]--;
            if (!incoming[e])
                // nu mai vine niciun nod in e deci il pot pune in coada ca in consecinta sa il pun in sortarea topologica, e dupa orice nod de la care vine
                Q.push(e);
        }
    }
}

void solve()
{
    BFS();
    for (auto e : top)
        out << e << ' ';
}

int main()
{
    read();
    solve();
    return 0;
}