#include<fstream>
#include<vector>
using namespace std;
ifstream F("sortaret.in");
ofstream G("sortaret.out");
#define N 50001
vector<int> g[N];
int n,m,i,j,k,v[N],u[N];
void D(int i)
{
    int j,l;
    for(v[i]=1,l=g[i].size(),j=0;j<l;++j)
        if(!v[g[i][j]])
            D(g[i][j]);
    u[++k]=i;
}
int main()
{
	F>>n>>m;
    while(m--)
        F>>i>>j,g[i].push_back(j);
    for(i=1;i<=n;++i)
        if(!v[i])
        	D(i);
    for(i=n;i;--i)
    	G<<u[i]<<" ";
    return 0;
}
