#include <fstream>
#include <vector>
#include <queue>

#define vecVec std::vector<std::vector<int>>
#define vec std::vector<int>

int main()
{
    int n, m;
    std::ifstream in("sortaret.in");
    in >> n >> m;

    vecVec graf(n + 1);
    vec ing(n++ + 1); // azert van n++ mert kesobb novelnem kellene

    while (m--)
    {
        int x, y;
        in >> x >> y;

        graf[x].push_back(y);
        ing[y]++;
    }
    in.close();

    std::ofstream out("sortaret.out");
    std::queue<int> q;
    while (--n)
    {
        if (ing[n] == 0)
            q.push(n);
    }

    while (!q.empty())
    {
        int cur = q.front();
        q.pop();

        out << cur << ' ';

        for (auto elem : graf[cur])
        {
            // ing[elem]--;
            if (!--ing[elem])
            {
                q.push(elem);
            }
        }
    }

    return 0;
}