#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
#define MAXN 50010
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector<int> G[MAXN];
int v[MAXN], viz[MAXN], n, m, x, y, k;

void dfs(int nod) {
    viz[nod] = 1;
    for (auto it:G[nod]) {
        if (!viz[it]) {
            dfs(it);
        }
    }
    v[++k] = nod;
}

int main() {
  f >> n >> m;
  while (m--) {
    f >> x >> y;
    G[x].push_back(y);
  }

  for (int i = 1; i <= n; ++i) {
    if (!viz[i]) {
        dfs(i);
    }
  }

  for (int i = n; i >= 1; --i)
    g << v[i] << ' ';
  return 0;
}
