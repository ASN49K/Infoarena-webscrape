#include <bits/stdc++.h>
using namespace std;

ifstream fi("sortaret.in");
ofstream fo("sortaret.out");

queue<int> q;

bool vizi[50001];

bool start[50001];
vector<int> sol;
int n, m;

int contor;

vector<vector<int>> adi;

void citire() {
    fi >> n >> m;
    for(int i = 0; i <= n; i++) {
        start[i] = true;
    }
    int a, b;
    for(int i = 0; i <= n; i++) {
        adi.push_back({});
    }
    for(int i = 1; i <= m; i++) {
        fi >> a >> b;
        adi[a].push_back(b);
        start[b] = false;
    }
}

void bfs(int nstart) {
    q.push(nstart);
    
    vizi[nstart] = true;

    while(!q.empty()) {
        int crt = q.front();
        q.pop();
        sol.insert(sol.begin() + contor, crt);
        contor++;
        for(int i = 0; i < adi[crt].size(); i++) {
            int nod = adi[crt][i];
            if(!vizi[nod]) {
                vizi[nod] = true;
                q.push(nod);
            }
        }
    }
}

int main() {
    citire();
    for(int i = 1; i <= n; i++) {
        vizi[i] = false;
    }
    //pornim bfs din toate nodurile care au grad intern 0
    for(int i = 1; i <= n; i++) {
        if(start[i] == true) {
            contor = 0;
            bfs(i);
        }
    }
   
    //afisarea solutiei
    for(auto u : sol) {
        fo << u << " ";
    }
    return 0;
}
