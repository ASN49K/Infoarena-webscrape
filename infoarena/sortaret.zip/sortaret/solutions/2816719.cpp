#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int maxN = 50005;
int grad[maxN], n, m;
queue <int> q;
vector <int> urm[maxN], v;

void citire()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int a, b;
        fin >> a >> b;
        urm[a].push_back(b);
        grad[b]++;
    }
}

void solve()
{
    for(int i = 1; i <= m; i++)
        if(grad[i] == 0)
            q.push(i);
    while(!q.empty())
    {
        int curr = q.front();
        q.pop();
        v.push_back(curr);
        for(auto vecin : urm[curr])
        {
            grad[vecin]--;
            if(grad[vecin] == 0)
                q.push(vecin);
        }
    }
}

void afis()
{
    for(int i = 0; i < n; i++)
        fout << v[i] << ' ';
    fout << '\n';
}

int main()
{
    citire();
    solve();
    afis();
    return 0;
}
