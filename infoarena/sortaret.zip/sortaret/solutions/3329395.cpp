#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define INF 2e9

std::ifstream f("sortaret.in");
std::ofstream g("sortaret.out");

std::vector<int> v[50001];
int n, m, d[50001];
int main(){
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    f >> n >> m;
    for(int i = 1, x, y; i <= m; ++i)
        f >> x >> y, d[y] ++,
        v[x].push_back(y);
    
    std::queue<int> q;
    for(int i = 1; i <= n; ++i)
        if(d[i] == 0)
            -- d[i], q.push(i);
    for(; !q.empty(); q.pop()){
        int p = q.front();
        g << p << ' ';
        for(auto i : v[p])
            if(d[i] == 1)
                d[i] = 0, q.push(i);
    }
    return 0;   
}