#include <fstream>
#include <queue>
#include <set>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int n, m, x, y;
vector<vector<int>> graf;
vector <int> grad;
set<int> s;
void sorttop()
{
    int nod;
    for(int i=1; i<=n; i++)
        if(grad[i] == 0)
            s.insert(i);
    while(s.size())
    {
        nod = *(s.begin());
        s.erase(nod);
        cout << nod << " ";
        for(auto i:graf[nod])
        {
            grad[i]--;
            if(grad[i] == 0)
                s.insert(i);
        }
    }
}
int main()
{
    cin >> n >> m;
    grad.resize(n+1);
    graf.assign(n+1, vector<int>());
    while(m--)
    {
        cin >> x >> y;
        graf[x].push_back(y);
        grad[y]++;
    }
    sorttop();
    return 0;
}
