#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <stack>
using namespace std;
ifstream fin("sortare.in");
ofstream fout("sortare.out");
vector<set<int>> graf;
vector<bool> vizitat;
stack<int> st;
void dfs(int nod) {
	vizitat[nod] = true;
	for (auto vecin : graf[nod]) {
		if (!vizitat[vecin]) {
			dfs(vecin);
		}
	}
	st.push(nod);
}
int main() {
	int n, m;
	fin >> n >> m;
	graf.resize(n + 1);
	vizitat.resize(n + 1, 0);
	for (int i = 0; i < m; i++) {
		int x, y;
		fin >> x >> y;
		graf[x].insert(y);
	}
	for (int i = 1; i <= n; i++) {
		if (!vizitat[i]) {
			dfs(i);
		}
	}
	while (!st.empty()) {
		fout << st.top() << " ";
		st.pop();
	}
	fin.close();
	fout.close();
	return 0;
}