#include <iostream>
#include <vector>
#include <fstream>
#include <set>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector <vector <int>> graf;
int n, m;
bool fr[50005];

void dfs(int nod);
void input();

int main()
{
    input();

    for(int i = 1; i <= n; i ++)
        if(!fr[i])
            dfs(i);

    return 0;
}

void input()
{
    pair <int, int> con;
    fin >> n >> m;

    graf.resize(n + 1);

    for(int i = 1; i <= m; i ++)
    {
        fin >> con.first >> con.second;
        graf[con.first].push_back(con.second);
    }
}

void dfs(int nod)
{
    if(fr[nod])
        return;
    fr[nod] = 1;
    fout << nod << ' ';
    for(int i = 0; i < graf[nod].size(); i ++)
        dfs(graf[nod][i]);
}
