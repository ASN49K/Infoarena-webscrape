#include <iostream>
#include<fstream>
#include<vector>
#include<stack>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<vector<int>> g;
vector<short> status;//0 - nevizitat; 1 - temporar; 2 - permanrnt

void citire(int& n, int& m)
{
    fin >> n >> m;
    g.resize(n+1);
    status.resize(n+1, 0);
    for(int i = 0; i < m; ++i)
    {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
    }
}

stack<int> q;
void sort_t(int nod)
{
    if(status[nod] == 2)
        return;
    status[nod] = 1;
    for(int& v : g[nod])
    {
        sort_t(v);
    }
    status[nod] = 2;
    q.push(nod);
}

int main()
{
    int n, m;
    citire(n, m);
    for(int i = 1; i <= n; ++i)
    {
        if(status[i] == 0){
            sort_t(i);
        }
    }
    while(!q.empty())
    {
        fout << q.top() << ' ';
        q.pop();
    }
    return 0;
}
