#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int Nmax=50005;
vector<int> v[Nmax];
int f[Nmax],viz[Nmax];
vector<int> sol;
void dfs(int a)
{
    for(int i=0;i<v[a].size();i++)
    {
        if(viz[v[a][i]]==0)
        {
            viz[v[a][i]]++;
            dfs(v[a][i]);
        }
    }
    sol.push_back(a);
    return;
}
int main()
{
    int n,m,x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        f[y]++;
    }
    int start=1;
    for(int i=1;i<=n;i++)
    {
        if(f[i]==0)
        {
            start=i;
            break;
        }
    }
    dfs(start);
    for(int i=n-1;i>=0;i--)
    {
        fout<<sol[i]<<' ';
    }
    return 0;
}
