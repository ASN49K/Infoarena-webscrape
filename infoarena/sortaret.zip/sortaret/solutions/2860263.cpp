#include <iostream>
#include <list>
#include <fstream>
#include <vector>

using namespace std;
list<int> szomszedsagi_lista[50001];
list<int> tomb;
int jart[50001];
ifstream f("sortaret.in");
ofstream g("sortaret.out");
void topologikus_rendezes(int csucs)
{
    jart[csucs]=true;
    for (int i : szomszedsagi_lista[csucs])
{
        if(jart[i]!=true)
    {
            topologikus_rendezes(i);
    }
    }
    tomb.push_front(csucs);
}
int main()
{
    int n,m;
    f>>n;
    f>>m;
    for (int i=0; i<m; i++)
    {
    int a,b;
        f>>a;
        f>>b;
    szomszedsagi_lista[a].push_back(b);
    }
    for (int i=1; i<=n; i++)
{
        if(jart[i]!=true)
        topologikus_rendezes(i);
}
    for (int i : tomb)
    {
        g<<i<<" ";
    }
    g.close();
    f.close();
    return 0;
}
