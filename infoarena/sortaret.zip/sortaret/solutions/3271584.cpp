#include <bits/stdc++.h>

#define NMAX 50000

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector<int> G[NMAX + 1];
vector<int> sol;
bool viz[NMAX + 1];

void DFS(int node){
    viz[node] = 1;
    for(int i = 0; i < G[node].size(); i++){
        int vec = G[node][i];

        if(!viz[vec]){
            DFS(vec);
        }
    }

    sol.push_back(node);
}

int main()
{
    int N, M;
    fin >> N >> M;

    for(int i = 1; i <= M; i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }

    for(int i = 1; i <= N; i++){
        if(!viz[i]){
            DFS(i);
        }
    }

    for(int i = sol.size() - 1; i >= 0; i--){
        fout << sol[i] << ' ';
    }
    fout << "\n";

    return 0;
}
