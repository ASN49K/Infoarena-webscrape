//#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
//ifstream cin("topsort.in");
//ofstream cout("topsort.out");
vector <int>L;
vector<int>G[100005];
int n,m;
int viz[100005];
void dfs(int nod)
{
    viz[nod] = 1;
    for(auto i : G[nod])
        if(!viz[i]) viz[i]=1,dfs(i);
    L.push_back(nod);
}
int main()
{
    int a, b;
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        G[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
        {
            viz[i]=1;
            dfs(i);
        }
    for(int i=L.size()-1;i>=0;i--)
        cout<<L[i]<<" ";

    return 0;
}
