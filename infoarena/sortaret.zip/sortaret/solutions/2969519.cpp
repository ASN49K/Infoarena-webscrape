#include <bits/stdc++.h>
#define N 100005
using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector<int> g[N];
int n, m;
int in[N];
vector<int> sorted;
queue<int> q;

void afis(){
    for(int i = 1; i <= n; ++i){
        cout << i << ' ';
        for(auto nod : g[i]){
            cout << nod << " ";
        }
        cout << '\n';
    }
}

void SortTop(){
    for(int i = 1; i <= n; ++i)
        if(!in[i])
            q.push(i);
    while(!q.empty()){
        int i = q.front();
        sorted.push_back(i);
        q.pop();
        for(auto nod : g[i]){
            in[nod]--;
            if(in[nod] == 0)
                q.push(nod);
        }
    }
}

int main() {

    fin >> n >> m;
    for(int i = 0; i < m; ++i){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        ++in[y];
    }
    SortTop();
    for(auto nod : sorted){
        fout << nod << " ";
    }

    return 0;
}
