#include<bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n, m, cnt;
vector<int> g[50005];
bool viz[50005];
int top[50005];
void DFS(int nod)
{
	viz[nod] = 1;
	for (auto i : g[nod])
		if (!viz[i])
			DFS(i);
	top[++cnt] = nod;
}
int main()
{
	fin >> n >> m;
	for (int i = 1; i <= m; ++i)
	{
		int x, y;
		fin >> x >> y;
		g[x].push_back(y);
	}
	for (int i = 1; i <= n; ++i)
		if (!viz[i])
			DFS(i);
	for (int i = cnt; i >= 1; --i)
		fout << top[i] << " ";
}
