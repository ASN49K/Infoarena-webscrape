#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int NMAX = 50000;

int N, M;
vector<int>G[NMAX + 1], L;
queue<int>Q;
int gr[NMAX + 1];

void citire()
{
    int x, y;
    f >> N >> M;
    for(int i = 1; i <= M; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
        gr[y]++;
    }
}

void sortaret()
{
    for(int i = 1; i <= N; i++)
        if(gr[i] == 0)
            Q.push(i);
    while(!Q.empty())
    {
        int x = Q.front();
        Q.pop();
        L.push_back(x);
        for(const auto &y : G[x])
        {
            gr[y]--;
            if(gr[y] == 0)
                Q.push(y);
        }
    }
}

int main()
{
    citire();
    sortaret();
    for(const auto &x : L)
        g << x << ' ';
    f.close();
    g.close();
    return 0;
}
