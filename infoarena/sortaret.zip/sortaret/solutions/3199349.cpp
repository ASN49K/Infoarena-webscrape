#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

const int nmax=2e5+7;
vector<vector<int>>adj(nmax);
vector <int>ans;
queue <int>q;
int indegree[nmax];
int n,m;
int ok=1;
void Topological_Sort()
{
    for(int i=1; i<=n; i++)
        if(indegree[i]==0)
            q.push(i);
    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        for(int next:adj[node])
        {
            indegree[next]--;
            if(indegree[next]==0)
                q.push(next);
        }
        ans.push_back(node);
    }
}

int main()
{
    int i;
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        int a,b;
        cin>>a>>b;
        adj[a].push_back(b);
        indegree[b]++;
    }
    Topological_Sort();
    if(ans.size()<n)
        cout<<"IMPOSSIBLE";
    else
        for(int next:ans)
            cout<<next<<" ";
    return 0;
}
