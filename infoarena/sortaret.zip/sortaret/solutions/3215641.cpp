#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int DIM = 50010;

int n, m, x, y;
vector<int> l[DIM], nodes;
bool visited[DIM];

void dfs(int node) {
    visited[node] = true;
    for (auto adjNode : l[node])
        if (!visited[adjNode])
            dfs(adjNode);
    nodes.push_back(node);
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        l[x].push_back(y);
    }

    for (int node = 1; node <= n; node++)
        if (!visited[node])
            dfs(node);

    reverse(nodes.begin(), nodes.end());
    for (auto node : nodes)
        fout << node << ' ';

    return 0;
}