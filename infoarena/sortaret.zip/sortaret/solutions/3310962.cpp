#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<deque<int>> I(50001);
vector<bool> T(50001, 0);
queue<int> Q;
int n, m;

void citire()
{
    fin>>n>>m;
    int x, y, i;
    for(i=0; i<m; i++){
        fin>>x>>y;
        I[y].push_back(x);
    }
}

void parc(int i)
{
    cout<<i<<" ";
    while(!I[i].empty()){
        cout<<"DA";
        int k = I[i].front();
        I[i].pop_front();
        if(T[k]==0) parc(k);
    }
    T[i] = 1;
    Q.push(i);
}

int main()
{
    citire();
    for(int i=1; i<=n; i++)
        if(T[i]==0) parc(i);
    while(!Q.empty()){
        fout<<Q.front()<<" ";
        Q.pop();
    }
}
