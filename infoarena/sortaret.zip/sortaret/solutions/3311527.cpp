#include <bits/stdc++.h>

std::ifstream in("sortaret.in");
std::ofstream out("sortaret.out");

int main() {
    int n, m;
    in >> n >> m;
    
    std::vector<int> deg(n + 1, 0);
    std::vector<std::vector<int>> adj(n + 1, std::vector<int>());
    
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        deg[y]++; 

        adj[x].push_back(y);
    }

    std::queue<int> q;

    for (int i = 1; i <= n; i++)
        if (deg[i] == 0) {
            q.push(i);
        }
    
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        out << node << " ";

        for (auto it : adj[node]) {
            deg[it]--;
            if (deg[it] == 0) {
                q.push(it);
            }
        }
    }
}