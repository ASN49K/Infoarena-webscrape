#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

int n, m, x, y, grad[50000];
vector<int> ad[50000];
queue<int> q;

int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++){
        fin>>x>>y;
        ad[x].push_back(y);
        grad[y]++;
    }
    for(int i=1; i<=n; i++){
        //cout<<grad[i]<<" ";
        if(grad[i]==0)
            q.push(i);
    }
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        fout<<nod<<" ";
        for(auto &vecin: ad[nod])
        {
            grad[vecin]--;
            if(grad[vecin]==0)
                q.push(vecin);
        }
    }
    return 0;
}
