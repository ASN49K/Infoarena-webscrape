#include <fstream>
#include <vector>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int i, j, n, m, k, x, y;
vector <int> valid, s;
vector <vector <int>> g;
void dfs (int vf)
{
    valid[vf] = 1;
    s[++k] = vf;
    for (int i = 0; i < g[vf].size(); i++)
        if (valid[g[vf][i]] == 0)
            dfs(g[vf][i]);
}
int main()
{
    fin >> n >> m; g.resize(n+1); valid.resize(n+1); s.resize(n+1);
    for (i = 1; i <= m; i++)
    {
        fin >> x >> y;
        g[x].push_back(y);
    }
    for (i = 1; i <= n; i++)
    {
        if (valid[i] == 0)
            dfs(i);
    }
    for (i = 1; i <= n; i++)
        fout << s[i] << " ";
    return 0;
}
