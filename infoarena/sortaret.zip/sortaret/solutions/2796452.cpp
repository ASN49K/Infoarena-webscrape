#include <bits/stdc++.h>

using namespace std;
vector<int> v[50005];
int s[50005],w,n,m,grad[50005],viz[50005];
void sorttop(int q)
{
    int i;
    viz[q]=1;

    for(i=0;i<v[q].size();i++)
    {
        int t=v[q][i];
        if(viz[t]==0)
        {
            sorttop(t);

        }

    }
    w++;
    s[w]=q;
}
int main()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");
    in>>n>>m;
    int i;
    int x,y;
    for(i=1;i<=m;i++)
    {
        in>>x>>y;
        v[x].push_back(y);
        grad[y]++;
    }
    for(i=1;i<=n;i++)
    {
        if(grad[i]==0 && viz[i]==0)
        {
            sorttop(i);
        }
    }
    //cout<<w<<'\n';
    for(i=w;i>0;i--)
    {
        out<<s[i]<<' ';
    }
}

