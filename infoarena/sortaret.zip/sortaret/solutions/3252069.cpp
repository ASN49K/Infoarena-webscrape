#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int nmax=50005;
int n,m,x,y;

bitset<nmax> vas;
vector<int> sol;
vector<vector<int>> graf;

void dfs(int nod){
    vas[nod]=1;
    for(int i:graf[nod]){
        if(!vas[i]){
            dfs(i);
        }
    }
    sol.emplace_back(nod);


}



int main()
{
    fin>>n>>m;
    graf.assign(n,vector<int>());
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        x--;
        y--;
        graf[x].push_back(y);
    }
    for(int i=0;i<n;i++){
        if(!vas[i]){
            dfs(i);
        }
    }
    reverse(sol.begin(),sol.end());
    for(int i=0;i<n;i++){
            fout<<sol[i]+1<<' ';
    }
    return 0;
}
