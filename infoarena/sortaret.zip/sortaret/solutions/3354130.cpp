// https://www.infoarena.ro/problema/sortaret - Szücs Patrik - Kevin
#include <fstream>
#include <vector>
#include <queue>

#define vec std::vector<int>
#define mtrx std::vector<vec>

int main()
{
    int n, m;

    std::ifstream in("sortaret.in");
    in >> n >> m;

    mtrx graf(n + 1);
    vec indeg(n + 1);
    while (m--)
    {
        int x, y;
        in >> x >> y;

        graf[x].push_back(y);
        indeg[y]++;
    }
    in.close();

    std::ofstream out("sortaret.out");

    std::queue<int> q;
    while (n)
        if (!indeg[n--])
            q.push(n);

    while (!q.empty())
    {
        out << q.front() << ' ';

        for (auto i : graf[q.front()])
            if (!--indeg[i])
                q.push(i);
    }

    return 0;
}