#include <fstream>
#include <stack>
#include <vector>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");
const int N = 5e4;
bool visited[N + 1];
int n_vf , n_muc;
vector<int> v[2 * N + 1];
stack<int> s;
void dfs(int x){
    visited[x] = true;
    for(int y = 0 ; y < v[x].size() ; y++){
        int val = v[x][y];
        if(!visited[val]){
            dfs(val);
        }
    }
    s.push(x);
}

int main(){
    in >> n_vf >> n_muc;
    for(int i = 1 ; i <= n_muc ; i++){
        int x , y;
        in >> x >> y;
        v[x].push_back(y);
    }
    for(int i = 1 ; i <= n_vf ; i++){
        if(!visited[i]){
            dfs(i);
        }
    }
    while(!s.empty()){
        out << s.top() << ' ';
        s.pop();
    }
}


