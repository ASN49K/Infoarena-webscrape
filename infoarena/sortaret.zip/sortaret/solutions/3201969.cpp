#include <bits/stdc++.h>

using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
vector <int> sortaret;
vector <vector <int> > g, inv;
int grade[50005];
void topo( int nod ){
    sortaret.push_back(nod);
    grade[nod] = -1;
    for( auto vec : g[nod] ){
        grade[vec]--;
        if( !grade[vec] )
            topo( vec );
    }
}
int main()
{
    int n, m;
    in >> n >> m;
    g.resize(n+1);
    inv.resize(n+1);
    for( int i = 0; i < m; i++ ){
        int a, b;
        in >> a >> b;
        g[a].push_back(b);
        inv[b].push_back(a);
        grade[b]++;
    }
    for( int i = 1; i <= n; i++ )
        if( !grade[i] )
            topo(i);
        
    
    for( auto x : sortaret )
        out << x << " ";
    return 0;
}
