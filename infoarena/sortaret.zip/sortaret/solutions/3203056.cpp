#include <bits/stdc++.h>
#define MAXN 50000

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, extdeg[MAXN];
vector<vector<int>> graph;
vector<int> sorted;

int main() {
    fin >> n >> m;
    graph = vector<vector<int>>(n, vector<int>());
    for (int i = 0; i < m; i++) {
        int from, to;
        fin >> from >> to;
        from--, to--;
        graph[from].push_back(to);
        extdeg[to]++;
    }

    for (int i = 0; i < n; i++)
        if (!extdeg[i])
            sorted.push_back(i);
    for (int i = 0; i < n; i++) {
        if (i >= sorted.size())
            return 1;
        int current = sorted[i];
        for (auto neighbour: graph[current]) {
           extdeg[neighbour]--;
           if (!extdeg[neighbour])
               sorted.push_back(neighbour);
        }
    }

    for (auto& node : sorted)
        fout << node + 1 << ' ';
    return 0;
}
