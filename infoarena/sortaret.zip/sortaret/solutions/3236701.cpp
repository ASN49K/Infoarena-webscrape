
#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int n,m;
int a,b;
vector<vector<int>> A;
vector<bool> fr;
stack<int> S;
void dfs(int nod)
{
    for(int i=0;i<A[nod].size();i++)
    {
        int vecin=A[nod][i];
        if(!fr[vecin])
        {
            fr[vecin]=1;
            dfs(vecin);
        }
    }
    S.push(nod);
}
int main()
{
    cin>>n>>m;
    A.resize(n+1);
    fr.resize(n+1);
    for(int i=0;i<m;i++)
    {
        cin>>a>>b;
        A[a].push_back(b);
    }
    for(int i=1;i<=n;i++)
       if(!fr[i])
       {
           fr[i]=1;
           dfs(i);
       }
    while(!S.empty())
    {
        cout<<S.top()<<" ";
        S.pop();
    }
    return 0;
}
