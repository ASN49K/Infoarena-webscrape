#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, cnt_time;
vector<vector<int>> adj_list;
vector<int> in_degree, in_time, out_time, visited;
stack<int> ans;

void read()
{
    fin>>n>>m;
    adj_list.reserve(n+1);
    in_degree.reserve(n+1);
    in_time.reserve(n+1);
    out_time.reserve(n+1);
    visited.reserve(n+1);

    for(int i=0; i<m; i++)
    {
        int x, y;
        fin>>x>>y;

        adj_list[x].push_back(y);
        in_degree[y]++;
    }
}

void dfs(int x)
{
    visited[x] = 1;
    in_time[x] = ++cnt_time;
    for(auto &vec: adj_list[x])
    {
        if(!visited[vec])
            dfs(vec);
    }
    out_time[x] = ++cnt_time;
    ans.push(x);
}

void traversal()
{
    for(int i=1; i<=n; i++)
    {
        if(!visited[i])
            dfs(i);
    }
}


int main()
{       
    read();
    traversal();
    while(!ans.empty())
    {
        fout<<ans.top()<<' ';
        ans.pop();
    }
    return 0;
}