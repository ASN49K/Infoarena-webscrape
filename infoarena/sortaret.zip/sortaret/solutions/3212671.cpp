#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<int> L[50005];
bitset<50005> v;
int st[50005], l;
int n, m;

void DFS(int k)
{
    v[k] = 1;
    for(auto w : L[k])
        if(!v[w]) DFS(w);
    st[++l] = k;
}

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i, x, y;
    fin >> n >> m;
    for(i=1;i<=m;i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    DFS(1);
    for(i=n;i>=1;i--)
        fout << st[i] << " ";
    fin.close();
    fout.close();
    return 0;
}
