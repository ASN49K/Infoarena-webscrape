#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector <int> l[50005];
queue <int> q;
int deg[50005];
bool viz[50005];
int N, M;
int main()
{
    int x, y;
    fin >> N >> M;
    for(int i=1;i<=M;i++)
    {
        fin >> x >> y;
        l[x].push_back(y);
        deg[y]++;
    }
    for(int i=1;i<=N;i++)
    {
        if(deg[i]==0)
        {
            q.push(i);
            fout << i << " ";
        }
    }
    while(!q.empty())
    {
        int aux=q.front();
        q.pop();
        viz[aux]=1;
        for(auto &p: l[aux])
        {
            if(viz[p]==0)
            {
                viz[p]=1;
                fout << p << " ";
                q.push(p);
            }
        }
    }
}

