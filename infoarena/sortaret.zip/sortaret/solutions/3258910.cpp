#include <fstream>
#include <vector>
#include <unordered_set>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int noNodes, noEdges;
vector<unordered_set<int>> graph(50005);
vector<int> inDegree(50005, 0);
vector<int> path;


void citire() {

    fin >> noNodes >> noEdges;

    while(noEdges--) {
        int firstNode, secondNode;
        fin >> firstNode >> secondNode;
        inDegree[secondNode]++;
        graph[firstNode].insert(secondNode);
    }

}

void sortare() {

    queue<int> Q;

    for(int i=1; i<=noNodes; i++)
        if(inDegree[i] == 0)
            Q.push(i);
    
    while(!Q.empty()) {
        int currentNode = Q.front();
        path.push_back(currentNode);
        Q.pop();

        for(auto neighbor : graph[currentNode]) {
            inDegree[neighbor]--;
            if(inDegree[neighbor] == 0)
                Q.push(neighbor);
        }

    }

}

void afisare() {
    for(auto element : path)
        fout << element << ' ';
}

int main() {

    citire();

    sortare();

    afisare();

    fin.close();
    fout.close();

    return 0;
}