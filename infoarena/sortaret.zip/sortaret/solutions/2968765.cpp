#include <bits/stdc++.h>

using namespace std;
#define nmax 50100

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n,m,gr[nmax],q[nmax];
vector<int> v[nmax];
// deg[x] = gradul exterior al nodului x
// folosesc o coada Q in care introduc pe rand nodurile care au gradul exterior zero
// complexitate O(N+M)

void citire()
{
    fin>>n>>m;
    int a,b;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        v[a].push_back(b);
        gr[b]++;
    }
   // for(int i=1;i<=n;i++)
   //     fout<<gr[i]<<" ";
  //  fout<<"\n";
}

int nr;
void rezolvare()
{
    int x;
    for(int i=1;i<=n;i++)
        if(gr[i]==0)
            q[++nr]=i;
    for(int i=1;i<=nr;i++)
    {
        for(auto j:v[q[i]])
        {
            gr[j]--;
            if(gr[j]==0) q[++nr]=j;
        }
    }
}

void afis()
{
    for(int i=1;i<=n;i++)
        fout<<q[i]<<" ";
}

int main()
{
    citire();
    rezolvare();
    afis();
    return 0;
}
