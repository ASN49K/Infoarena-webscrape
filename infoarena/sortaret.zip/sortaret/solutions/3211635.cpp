#include <bits/stdc++.h>

#define ll long long

//#define fin cin
//#define fout cout

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector <int> g[50005];

bool vizited[50005];

stack <int> st;

void dfs (int nod)
{
    vizited[nod]=1;
    for (int vecin : g[nod]) {
        if (!vizited[vecin]) {
            dfs(vecin);
        }
    }
    st.push(nod);
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n, m, x, y; fin>>n>>m;
    for (int i=1; i<=m; i++) {
        fin>>x>>y;
        g[x].push_back(y);
    }
    for (int i=1; i<=n; i++) {
        if (!vizited[i]) {
            dfs(i);
        }
    }
    while (!st.empty()) {
        fout<<st.top()<<' ';
        st.pop();
    }
    return 0;
}