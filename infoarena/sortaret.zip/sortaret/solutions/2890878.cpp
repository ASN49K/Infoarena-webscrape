#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;
vector <int> graph[50005];
bool visited[50005];

void DFS(int node)
{
    fout << node << ' ';
    visited[node] = true;
    for (int currNode : graph[node])
    {
        if (visited[currNode])
        {
            continue;
        }
        DFS(currNode);
    }
}

int main()
{
    fin >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int a, b;
        fin >> a >> b;

        graph[a].push_back(b);
    }

    for (int i = 1; i <= n; i++)
    {
        if (visited[i])
        {
            continue;
        }
        DFS(i);
    }
    
    fout << '\n';
}