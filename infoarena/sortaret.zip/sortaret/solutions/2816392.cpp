#include <fstream>
#include <vector>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int d[50001],n,m,i,sol[50001],k,x,y;
vector <int> v[50001];
void dfs(int nod)
{
    int i;
    d[nod]=1;
    for(i=0;i<v[nod].size();i++)if(!d[v[nod][i]]) dfs(v[nod][i]);
    sol[++k]=nod;
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(i=1;i<=n;i++)if(!d[i]) dfs(i);
    for(i=k;i>=1;i--)fout<<sol[i]<<" ";
    return 0;
}
