#include <fstream>
#define dim 10005
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int a[2][100005], start[dim], grad[dim], c[dim], n, m;
void sortare();
int main()
{
    int i, x;
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        fin >> x >> a[0][i];
        a[1][i] = start[x];
        start[x] = i;
        grad[a[0][i]]++;
    }
    sortare();
    for(i = 1; i <= n; i++)
        fout << c[i] << " ";
    return 0;
}
void sortare()
{
    int i, ps = 1, pi = 0, x;
    for(i = 1; i <= n; i++)
        if(grad[i] == 0)
            c[++pi] = i;
    while(ps <= pi) {
        x = start[c[ps]];
        while (x) {
            grad[a[0][x]]--;
            if(grad[a[0][x]] == 0)
                c[++pi] = a[0][x];
            x = a[1][x];
        }
        ps++;
    }
}
