#include <fstream>
#include <vector>
#include <queue>

#define NMAX 100002

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

int n, m;

vector<vector<int>>graf;
int grad[NMAX];
queue <int> q;

int main()
{
    int i, x, y;
    fin>>n>>m;
    graf.resize(n + 2);
    for(i = 1; i <= m; i++)
    {
         fin>>x>>y;
         graf[x].push_back(y);
         grad[y]++;
    }
    for(i = 1; i <= n; i++)
       if(grad[i] == 0)
       {
          fout<<i<<' ';
          grad[i] = -1;
          q.push(i);
       }
    while(!q.empty())
    {
         //voi scadea gradul intern al tuturor nodurilor care au o conexiune din nodul q.front la ele
         for(i = 0; i < graf[q.front()].size(); i++)
            {
                //gradul intern al acelui vecin scade cu 1
                if(grad[graf[q.front()][i]] == 1)
                {
                    fout<<graf[q.front()][i]<<' ';
                    grad[graf[q.front()][i]] = -1;
                    q.push(graf[q.front()][i]);
                }
                else
                grad[graf[q.front()][i]]--;
            }
         q.pop();
    }
    return 0;
}
