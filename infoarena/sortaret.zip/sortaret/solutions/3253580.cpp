#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int di[50005],n,m,x,y,nod,i;
vector<int>v[50005];
queue<int>q;
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        di[y]++;
    }
    for(i=1;i<=n;i++)
        if(di[i]==0)
            q.push(i);
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        fout<<nod<<" ";
        for( auto vecin:v[nod])
        {
            di[vecin]--;
            if(di[vecin]==0)
                q.push(vecin);
        }
    }
}
