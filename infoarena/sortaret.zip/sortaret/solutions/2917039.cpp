#include <fstream>
#include <queue>
#include <vector>

std::ifstream in("sortaret.in");
std::ofstream out("sortaret.out");

int n, m;
std::vector<int> vecini[50000];
bool start[50000];
bool verificat[50000];

int main() {
    in >> n >> m;

    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        vecini[x].push_back(y);
        start[y] = 1;
    }

    std::queue<int> q;
    for (int i = 1; i <= n; i++)
        if (!start[i]) q.push(i);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        verificat[nod] = true;
        out << nod << ' ';

        for (int fiu : vecini[nod])
            if (!verificat[fiu]) q.push(fiu);
    }
}