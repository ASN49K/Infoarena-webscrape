#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
//#define int ll


ifstream fin("sortaret.in"); ofstream fout("sortaret.out");
#define cin fin
#define cout fout



int n, m;

vector<int> g[50010];

int in[50010], vin[50010];

vector<int> topSort;

void dfs(int s){
if(in[s]==vin[s]){
    topSort.pb(s);
}
for(int u:g[s]){
    vin[u]++;
    if(vin[u]==in[u]){dfs(u);}
}

}


int32_t main(){
INIT
cin>>n>>m;

for(int i=0; i<m; i++){
    int u, v; cin>>u>>v;
    g[u].pb(v);
    in[v]++;
}

for(int i=1; i<=n; i++){
    if(in[i]==0){
        dfs(i);
    }
}

for(int i=0; i<topSort.size(); i++){
    cout<<topSort[i]<<" ";
}

return 0;
}
