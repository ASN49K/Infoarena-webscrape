#include <cstdio>
#include <vector>
#include <deque>

using namespace std;
FILE* f, * g;

vector <int> nod[50002];
bool viz[50002];
int nr = 0, n;
deque <int> coada;

void euler(int no)
{
    int vecin;
    viz[no] = 1;
    while (nod[no].size())
    {
        vecin = nod[no].back();
        nod[no].pop_back();
        if (!viz[vecin])
            euler(vecin);
    }
    coada.push_back(no);

}
int main()
{
    f = fopen("sortaret.in", "r");
    g = fopen("sortaret.out", "w");
    int m, x, y;
    fscanf(f, "%d %d", &n, &m);
    for (int i = 1;i <= m;++i)
    {
        fscanf(f, "%d %d", &x, &y);
        nod[x].push_back(y);
    }

    for (int i = 1;i <= n;++i)
        if (!viz[i])
            euler(i);
    while (!coada.empty())
    {
        x = coada.back();
        coada.pop_back();
        fprintf(g, "%d ", x);
    }
    fclose(f);
    fclose(g);
    return 0;
}