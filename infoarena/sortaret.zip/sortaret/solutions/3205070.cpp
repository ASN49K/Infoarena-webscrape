#include <fstream>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, matrix[100][100], used[100];

void read() {
  fin >> n >> m;
  int i,j;
  for (int x = 1; x <= m; x++) {
    fin >> i >> j;
    matrix[i][j] = 1;
  }
}

void dfs(int node) {
  fout << node << " ";
  used[node] = 1;
  for (int i = 1; i <= n; i++)
    if (matrix[node][i] == 1 && !used[i])
      dfs(i);
}

int main() {
  read();
  dfs(1);
  return 0;
}
