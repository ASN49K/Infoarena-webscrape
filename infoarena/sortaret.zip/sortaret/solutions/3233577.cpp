#include <fstream>
#include <vector>
using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

int viz[50001];
int n;
vector<int>rasp;
vector<int> v[50001];

void tsort(int nod){
    viz[nod]=1;
    int i;
    for(i=0;i<v[nod].size();i++){
        if(viz[i])
            tsort(v[nod][i]);
    }rasp.push_back(nod);
}

void top_sort(){
    int i;
    for(i=1;i<=n;i++){
        if(viz[i]==0){
            tsort(i);
        }
    }
}

int main()
{
    int m,a,b,i;
    cin>>n>>m;
    for(i=1;i<=n;i++){
        cin>>a>>b;
        v[a].push_back(b);
    }
    top_sort();
    for(i=0;i<rasp.size();i++){
        cout<<rasp[i]<<" ";
    }
    return 0;
}
