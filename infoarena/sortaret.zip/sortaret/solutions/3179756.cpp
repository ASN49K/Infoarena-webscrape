#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int nmax = 50005;
vector<int> G[nmax];
stack<int>sol;
int n,m;
int viz[nmax];

void bfs(int tatic)
{
    viz[tatic] = 1;
    for(auto nbr : G[tatic])
    {
        if(!viz[nbr])
        {
            bfs(nbr);
        }
    }
    sol.push(tatic);
}
int main()
{
    f >> n >> m;
    for(int i = 1;i<=m;i++)
    {
        int x,y;
        f >> x >> y;
        G[x].push_back(y);
    }
    for(int i = 1;i<=n;i++)
    {
        if(!viz[i])
        {
            bfs(i);
        }
    }
    while(!sol.empty())
    {
        g << sol.top() << ' ';
        sol.pop();
    }
    return 0;
}
