#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

unsigned int i,j,n,m,Use[10],k,tsort[10];

vector <unsigned int> v[10];

void citire()
{
    f>>n>>m;
    while(m--)
        {f>>i>>j;
        v[i].push_back(j);}

}

void sortare_topologica(unsigned int nod)
{
    Use[nod]=1;
    for(i=0;i<v[i].size();i++)
    {
        int vecin=v[nod][i];
        if(Use[vecin]!=1)
            sortare_topologica(vecin);
    }
    tsort[++k]=nod;
}

int main()
{
    citire();
    for(i=1;i<=n;i++)
        if(!Use[i])
            sortare_topologica(i);
    for(i=1;i<=n;i++)
        g<<tsort[i]<<" ";
}
