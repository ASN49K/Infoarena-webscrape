#include <fstream>
#include <queue>

using namespace std;
int f[50005];
vector <int> g[50005], fa[50005];
vector <int> q;

void dfs(int i)
{
	f[i]=1;
	for(auto vec : g[i])
	{
		if(f[i]!=1)
			dfs(vec);
	}
	q.push_back(i);
}
int main()
{
		ifstream cin("sortaret.in");
		ofstream cout("sortaret.out");

    int n, m, a, b;
    cin>>n>>m;

		for(int i=0;i<m;i++)
		{
			cin>>a>>b;
			g[a].push_back(b);
		}

		for(int i=1;i<=n;i++)
		{
			if(fa[i].size()==0)
			{
				dfs(i);
				break;
			}
		}

    while(!q.empty())
		{
			cout<<q.back()<<" ";
			q.pop_back();
		}

    return 0;
}
