#include <fstream>
#include <vector>

using namespace std;

vector<int> G[500001];
int sortop[50001],cnt, viz[50001];

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

void dfs(int x) {

    viz[x] = 1;
    for ( auto y: G[x]) {
        if(!viz[y]) 
            dfs(y);
    }
    sortop[++cnt] = x;
}


int main() {
    int n,m;
    fin >> n;
    for (int i = 1,x,y; i <= m; ++i) {
        fin >> x >> y;
        G[x].push_back(y);
    }
    for ( int i = 1; i <= n; ++i)
        if(!viz[i])
            dfs(i);
    for ( int i = cnt; i >= 1; --i) 
        fout << sortop[i] << " ";
}