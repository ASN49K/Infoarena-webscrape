#include <fstream>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

struct Node{
  int data;
  struct Node *next;
};

int n, m;
struct Node *List[100];
int used[100];

void read_graph() {
  fin >> n >> m;;
  int i, j;
  for (int x = 1; x <= m; x++) {
    fin >> i >> j;
    struct Node *c = new Node;
    c -> data = j;
    c -> next = List[i];
    List[i] = c;
  }
}

void dfs(int node) {
  fout << node << " ";
  used[node] = 1;
  struct Node *c = List[node];
  while (c) {
    if (!used[c->data]) {
      dfs(c->data);
    }
    c = c -> next;
  }
}

int main() {
  read_graph();
  dfs(1);
  return 0;
}
