#include <fstream>
#include <vector>
#define nmax 50001
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int tops[nmax],n,m,x,y,k;
bool viz[nmax];
vector<int>v[nmax];
void dfs(int nod){
    viz[nod]=1;
    for(auto i:v[nod])
        if(!viz[i])
            dfs(i);
    tops[++k]=nod;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    dfs(1);
    for(int i=n;i>0;i--)
        cout<<tops[i]<<" ";
    return 0;
}
