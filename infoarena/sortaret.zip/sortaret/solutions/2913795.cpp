#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
///Kahn's Algorithm for Topological Sorting
ifstream fi("sortaret.in");
ofstream fo("sortaret.out");
int m_ExtD[50005];
queue <int> SOL,S;
vector <int>V[50005];
void KahnP(int N)
{
    while(!S.empty())
    {
        int vertex=S.front();
        S.pop();
        SOL.push(vertex);
        for(int i=0;i<V[vertex].size();i++)
        {
            int vecin=V[vertex][i];
            if(m_ExtD[vecin])
                m_ExtD[vecin]--;
            if(!m_ExtD[vecin])
                S.push(vecin);
        }
    }
}
int main()
{
    int N,M;
    fi>>N>>M;
    for(int i=1;i<=M;i++)
    {
        int x,y;
        cin>>x>>y;
        V[x].push_back(y);
        m_ExtD[y]++;
    }
    for(int i=1;i<=N;i++)
        if(m_ExtD[i]==0)
            S.push(i);
    KahnP(N);
    while(!SOL.empty())
    {
        fo<<SOL.front()<<" ";
        SOL.pop();
    }
    return 0;
}
