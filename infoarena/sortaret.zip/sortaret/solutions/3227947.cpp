#include <bits/stdc++.h>

using namespace std;

class Task {
public:
    void solve() {
        read_input();
        print_output(topsort());
    }

private:
    static const int NMAX = (int)1e5 + 5;

    int n, m, source;
    vector<int> adj[NMAX];

    void read_input() {
        ifstream fin("sortaret.in");
        fin >> n >> m;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y;
            adj[x].push_back(y);
        }
        fin.close();
    }

    vector<int> topsort() {
        vector<int> visited(n + 1, 0);
        vector<int> topsort;

        for (int node = 1; node <= n; ++node) {
            if (!visited[node]) {
                dfs(node, visited, topsort);
            }
        }

        reverse(topsort.begin(), topsort.end());
        return topsort;
    }

    void dfs(int node, vector<int> &visited, vector<int> &topsort) {
        visited[node] = 1;

        for (auto &neighbor : adj[node]) {
            if (!visited[neighbor]) {
                dfs(neighbor, visited, topsort);
            }
        }

        topsort.push_back(node);
    }

    void print_output(vector<int> topsort) {
        ofstream fout("sortaret.out");
        for (auto &node : topsort) {
            fout << node << ' ';
        }
        fout.close();
    }
};

int main() {
    auto* task = new (nothrow) Task();
    if (!task) {
        cerr << "Error\n";
        return -1;
    }
    task->solve();
    delete task;
    return 0;
}
