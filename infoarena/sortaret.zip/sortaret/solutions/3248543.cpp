#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

map<int, map<int, bool> > mp;
bool b[50001];
int n, m;
void g(int i)
{
    fout<<i<<" ";
    if (m==n){
        exit(0);
    }
    b[i]=1;
    for (int j=i+1; j<=n; j++){
        m++;
        if (!b[j] && mp[i][j])g(j);
        m--;
    }
}
int main()
{
    fin>>n>>m;
    for (int i=0; i<m; i++){
        int x, y;
        fin>>x>>y;
        mp[x][y]=1;
    }
    m=0;
    for (int i=1; i<=n; i++){
        m++;
        if (!b[i])g(i);
        m--;
    }
    return 0;
}
