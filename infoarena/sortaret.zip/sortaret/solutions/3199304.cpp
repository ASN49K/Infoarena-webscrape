#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<int> G[50002];
stack<int> s;
bitset<50002> viz;

void dfs(int nod){
    viz[nod] = 1;
    for(int i=0; i<G[nod].size(); i++){
        int vecin = G[nod][i];
        if(viz[vecin] == 0){
            dfs(vecin);
        }
    }
    s.push(nod);
}

int main()
{
    int n, m;
    fin >> n >> m;
    for(int x, y, i=1; i<=m; i++){
        fin >> x >> y;
        G[x].push_back(y);
    }
    for(int i=1; i<=n; i++){
        if(viz[i] == 0){
            dfs(i);
        }
    }
    while(!s.empty()){
        fout << s.top() << ' ';
        s.pop();
    }
    return 0;
}
