#include <bits/stdc++.h>
#define MAXN 50001
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");

vector<int> G[MAXN];
bool viz[MAXN];
int n,m,k,v[MAXN];

void dfs(int nod)
{
    viz[nod]=1;
    for(int i=0;i<G[nod].size();i++)
        if(!viz[G[nod][i]]) dfs(G[nod][i]);
    v[++k]=nod;
}
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i]) dfs(i);
    for(int i=n;i>=1;i--)
        g<<v[i]<<" ";
    return 0;
}
