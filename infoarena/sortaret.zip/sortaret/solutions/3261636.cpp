#include <fstream>
#include <queue>
#include <vector>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector <int> d[50001];
queue <int> q;
int n,m,x,y,z,g[50001];
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        d[x].push_back(y);
        g[y]++;
    }
    for(int i=1; i<=n; i++)
        if(!g[i])
            q.push(i);
    while(!q.empty())
    {
        x=q.front();
        fout<<x<<' ';
        for(auto it=d[x].begin(); it!=d[x].end(); it++)
        {
            g[*it]--;
            if(!g[*it])
                    q.push(*it);
        }
            q.pop();
    }
    return 0;
}
