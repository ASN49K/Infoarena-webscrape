#include<cstdio>
#include<vector>
using namespace std;
const int N=50001;
int m,i,a,b,u[N],k,n,t,l;
bool v[N];
char p[2000000];
vector<int> g[N];
inline int A()
{
  	int s=0;
  	for(;p[t]<48;++t);
  	for(;p[t]>47;++t)
  		s=s*10+p[t]-48;
  	return s;
}
inline void S(int x)
{
    int i,d=x>9999?5:x>999?4:x>99?3:x>9?2:1;
    for(i=d-1;i>=0;x/=10,--i)
        p[l+i]=x%10+48;
    p[l+d]=32,l+=d+1;
}
inline void D(int i)
{
    int j,k=g[i].size();
    for(v[i]=1,j=0;j<k;++j)
        if(!v[g[i][j]])
            D(g[i][j]);
    u[++k]=i;
}
int main()
{
	freopen("sortaret.in","r",stdin),freopen("sortaret.out","w",stdout),fread(p,1,L,stdin),n=A(),m=A();
    while(m--)
        a=A(),b=A(),g[a].push_back(b);
    for(i=1;i<=n;++i)
        if(!v[i])
        	D(i);
    for(i=n;i;--i)
        S(u[i]);
    fwrite(p,1,l,stdout);
    return 0;
}
