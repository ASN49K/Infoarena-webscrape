#include <bits/stdc++.h>

using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
const int N = 50010;
vector<int> v[N];
int n,m,gr[N];
queue<int> q;
int main()
{
    f>>n>>m;
    for(;m;m--)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(y);
        gr[y]++;
    }
    for(int i=1;i<=n;i++)
        if(gr[i]==0)
            q.push(i);
    while(q.size())
    {
        int nod=q.front();q.pop();
        g<<nod<<' ';
        for(auto vec:v[nod])
        {
            gr[vec]--;
            if(gr[vec]==0)
                q.push(vec);
        }
    }
    return 0;
}
