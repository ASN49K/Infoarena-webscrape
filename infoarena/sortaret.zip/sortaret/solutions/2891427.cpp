#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, x, y;
int g[50005];
vector <int> v[50005];
queue <int> q;

int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++){
        fin >> x >> y;
        v[x].push_back(y);
        g[y]++;
    }
    for(int i=1; i<=n; i++)
        if(g[i] == 0)
            q.push(i);
    while(!q.empty()){
        int i = q.front();
        fout << i << ' ';
        q.pop();
        for(int j=0; j<v[i].size(); j++){
            g[v[i][j]]--;
            if(g[v[i][j]] == 0)
                q.push(v[i][j]);
        }
    }
    return 0;
}
