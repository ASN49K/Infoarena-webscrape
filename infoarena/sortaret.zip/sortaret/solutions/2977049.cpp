#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, x, y, grad[50001], vf, vfnou, i;
vector<int> l[50001];
queue<int> q;

int main()
{
    fin >> n >> m;
    for(i=1; i<=m; i++)
    {
        fin >> x >> y;
        l[x].push_back(y);
        grad[y]++;
    }
    for(i=1; i<=n; i++)
        if(!grad[i])
            q.push(i);
    while(!q.empty())
    {
        vf=q.front();
        q.pop();
        fout << vf <<' ';
        for(i=0; i<l[vf].size(); i++)
        {
            vfnou=l[vf][i];
            grad[vfnou]--;
            if(grad[vfnou]==0)
                q.push(vfnou);
        }
    }
    fout.close();
    return 0;
}
