#include <bits/stdc++.h>
using namespace std;
int main() {
    ifstream fin("sortaret.in");
    ofstream fout("sortratet.out");
    int n, m, x, y;
    queue<int> Coada;
    fin>>n>>m;
    vector<vector<int>> grad_extern(n+1), grad_intern(n+1);
    vector<int> sortare;
    for (int i=0;i<m;i++) {
        fin>>x>>y;
        grad_extern[x].push_back(y);
        grad_intern[y].push_back(x);
    }
    for (int i=1; i<=n; i++) {
        if (grad_intern[i].size() == 0) {
            Coada.push(i);
        }
    }
    while (Coada.size() != 0) {
        int v=Coada.front();
        sortare.push_back(v);
        Coada.pop();
        for (int u : grad_extern[v]) {
            grad_intern[u].erase(find(grad_intern[u].begin(), grad_intern[u].end(), v));
            if (grad_intern[u].size() == 0) {
                Coada.push(u);
            }
        }
    }
    for (int i=0; i< sortare.size(); i++) {
        fout<<sortare[i]<<" ";
    }
    return 0;
}