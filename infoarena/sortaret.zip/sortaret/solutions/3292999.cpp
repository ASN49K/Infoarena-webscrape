#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
vector<int>g[50001];
int gi[50001];
queue<int>q;
int main() {
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++) {
        int x,y;
        cin >> x >> y;
        g[x].push_back(y);
        gi[y]++;
    }
    for(int i=1;i<=n;i++)
        if(!gi[i])
            q.push(i);
    int p=0;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        cout << nod << ' ';
        for(auto x:g[nod])
        {
            gi[x]--;
            if(!gi[x])
                q.push(x);
        }
    }
    return 0;
}