#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, x, y, aux;
int G_int[50001];
vector <int>V[50001];
queue <int> q;

int main()
{
    fin>>n>>m;
    for(int i=0; i<m; i++)
    {
        fin>>x>>y;
        G_int[y]++;
        V[x].push_back(y);
    }
    for(int i=1; i<=n; i++)
    {
        if(G_int[i]==0)
        {
            q.push(i);
        }
    }
    while(!q.empty())
    {
        aux=q.front();
        q.pop();
        fout<<aux<<' ';
        for(auto i: V[aux])
        {
            G_int[i]--;
            if(G_int[i]==0)
            {
                q.push(i);
            }
        }
    }

    fin.close();
    fout.close();
    return 0;
}
