#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out"):
void sortareTopologica(vector<vector<int>>& G, vector<int>& rez) {
    int N = G.size();
    vector<int> grad(N, 0);

    for (int i = 0; i < N; ++i) {
        for (int vecin : G[i]) {
            grad[vecin]++;
        }
    }

    queue<int> zerograd;

    for (int i = 0; i < N; ++i) {
        if (grad[i] == 0) {
            zerograd.push(i);
        }
    }

    while (!zerograd.empty()) {
        int nod = zerograd.front();
        zerograd.pop();
        rez.push_back(nod);

        for (int vecin : G[nod]) {
            grad[vecin]--;
            if (grad[vecin] == 0) {
                zerograd.push(vecin);
            }
        }
    }
}

int main() {
    int N, M;
    fin >> N >> M;

    vector<vector<int>> G(N);

    for (int i = 0; i < M; ++i) {
        int X, Y;
        fin >> X >> Y;
        G[X].push_back(Y);
    }

    vector<int> rez;
    sortareTopologica(G, rez);

    for (int i = 0; i < N; i++) {
    fout << rez[i] << " ";
}

    return 0;
}
