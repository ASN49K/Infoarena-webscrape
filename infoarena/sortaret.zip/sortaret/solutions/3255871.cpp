#include<fstream>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int a[5000][5000],d[50000],c[50000];
int n,i,j,m,x,y,u,p;
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        a[x][y]=1;
        d[y]++;
    }
    u=1; p=1;
    for(i=1;i<=n;i++)
      if(d[i]==0)
      {
          c[u]=i;
          u++;
      }
    while(p<=u)
    {
        x=c[p];
        for(i=1;i<=n;i++)
            if(a[x][i]==1)
            {
                d[i]--;
                if(d[i]==0)
                {
                    c[u]=i;
                    u++;
                }
            }
        p++;
     }
    for(i=1;i<=n;i++)
        fout<<c[i]<<" ";
     return 0;
}
