#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

#define nmax 50005

int n, m;
vector <int> Graph[nmax];
bool visited[nmax];
vector <int> topologic_sort;

void dfs(int node){
    visited[node] = true;

    for(auto it : Graph[node]){
        if(visited[it] == 0){
            dfs(it);
        }
    }
    topologic_sort.push_back(node);
}

int main()
{
    fin >> n >> m;

    while (m--){
        int x, y;
        fin >> x >> y;

        Graph[x].push_back(y);
    }

    dfs(1);

    reverse(topologic_sort.begin(), topologic_sort.end());

    for(auto it : topologic_sort){
        fout << it << " ";
    }

    return 0;
}
