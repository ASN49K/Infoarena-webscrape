#include <fstream>
#include <stack>
#include <vector>
#include <bitset>
#include <algorithm>

using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

int n, m;
vector<vector<int>> graf;
bitset<50001> viz;
vector<int> sol;

void dfs(int node) {
    viz[node] = 1;
    for (int nei : graf[node]) {
        if (viz[nei] == 0) dfs(nei);
    }
    sol.push_back(node);
}

int main() {
    cin >> n >> m;
    graf.resize(n + 2);
    for (int i = 1 ; i <= m ; ++i) {
        int src, dest;
        cin >> src >> dest;
        graf[src].push_back(dest);
    }
    for (int i = 1 ; i <= n ; ++i) {
        if (viz[i] == 0) dfs(i);
    }
    reverse(sol.begin(), sol.end());
    for (int node : sol) {
        cout << node << " ";
    }
    return 0;
}