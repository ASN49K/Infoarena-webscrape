program sortaret;

{$MODE objfpc}{$H+}{$J-}
uses Sysutils;

const
  C_IN_FNAME = 'sortaret.in';
  C_OUT_FNAME = 'sortaret.out';
  C_MAXSIZE = 50000;
type
  TPtrNode = ^TNode;
  TNode = record
    A: longint;
    Next: TPtrNode;
  end;
var
  fin, fout: text;
  A, ul: array[1..C_MAXSIZE] of TPtrNode;
  next: TPtrNode;
  nr: array[1..C_MAXSIZE] of longint;
  i, N, M, x, y: longint;
  ok: boolean;
begin
  AssignFile(fin, C_IN_FNAME); Reset(fin);
  Readln(fin, N, M);
  for i := 1 to N do
  begin
    A[i] := nil;
    Nr[i] := 0;
  end {for};

  for i := 1 to M do
  begin
    Readln(fin, x, y);
    Inc(Nr[y]);
    if A[x] = nil then begin
      new(A[x]);
      A[x]^.a := y;
      A[x]^.Next := nil;
      ul[x] := A[x];
    end
    else begin
      New(next);
      next^.a := y;
      next^.Next := nil;
      ul[x]^.Next := next;
      ul[x] := next;
    end {if};
  end {for};
  Close(fin);

  AssignFile(fout, C_OUT_FNAME); Rewrite(fout);
  repeat
    for i := 1 to N do begin
      if Nr[i] = 0 then begin
        Nr[i] := -1;

        while A[i] <> nil do begin
          Dec(Nr[A[i]^.a]);
          A[i] := A[i]^.Next;
        end {while};

        Write(fout, i, ' ');
        ok := false;
      end {if};
    end {for};
  until ok = false;

  Write(fout, LineEnding);
  Close(fout);

end.
