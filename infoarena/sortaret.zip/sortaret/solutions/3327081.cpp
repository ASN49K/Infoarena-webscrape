#include<bits/stdc++.h>
using namespace std;
ifstream f("soratret.in");
ofstream g("sortaret.out");
vector <int>L[200];
int n=0,st[200];
int vz[200];
int in=0;
int grdint[200];
void dfs(int k)
{  vz[k]=1;
    for(int i=0;i<L[k].size();i++)
    if(vz[L[k][i]]==0) dfs(L[k][i]);
    st[++in]=k;
}
void sorttop()
{
    for(int i=1;i<=n;i++)
        if(vz[i]==0)
        dfs(i);
}
void citire()
{
    int x,y;
    while(f>>x>>y)
    { if(x>n)
    n=x;
    if(y>n)
        n=y;
        L[x].push_back(y);
        grdint[y]++;
    }
}
int main()
{

    citire();
    sorttop();
    for(int i=1;i<=in;i++)
        g<<st[i]<<" ";
        g<<'\n';
    return 0;

}
