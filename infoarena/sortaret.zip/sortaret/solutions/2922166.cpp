#include <bits/stdc++.h>

using namespace std;
const int NMAX = 100;

int mat[NMAX + 5][NMAX + 5];
int main()
{
    int n;

    cin >> n;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            cin >> mat[i][j];

    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if(i != j && mat[i][k] && mat[k][j])
                    if(!mat[i][j])
                        mat[i][j] = mat[i][k] + mat[k][j];
                    else
                        mat[i][j] = min(mat[i][j], mat[i][k] + mat[k][j]);

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++)
            cout << mat[i][j] << " ";

        cout << '\n';
    }

    return 0;
}
