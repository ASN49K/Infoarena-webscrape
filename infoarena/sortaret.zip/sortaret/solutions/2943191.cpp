#include <fstream>
#include <vector>
using namespace std;
const int NMAX = 50003;
vector <int> g[NMAX];
vector <int> sol;
bool viz[NMAX];
void dfs(int nod)
{
    viz[nod] = 1;
    for (int u : g[nod])
        if (!viz[u])
        {
            dfs(u);
        }
    sol.push_back(nod);
}
int main()
{
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    int i, n, m;
    cin >> n >> m;
    while (m--)
    {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
    }
    for (i = 1; i <= n; i++)
        if (!viz[i])
            dfs(i);
    for (i = sol.size() - 1; i > -1; i--)
        cout << sol[i] << " ";
}
