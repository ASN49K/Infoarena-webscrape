#include <bits/stdc++.h>
#define NMAX 100001

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n, m, u, v;
vector<vector<int>> G(NMAX);
vector<int> ord;
vector<bool> viz(NMAX);

void dfs(int nod)
{
	viz[nod] = 1;
	for (auto vecin : G[nod])
		if (!viz[vecin])
			dfs(vecin);
	ord.push_back(nod);
}

int main()
{
	f >> n >> m;
	while (m--)
	{
		f >> u >> v;
		G[u].push_back(v);
	}
	f.close();

	for (int i = 1; i <= n; i++)
		if (!viz[i])
			dfs(i);
	reverse(ord.begin(), ord.end());
	for (auto it : ord)
		g << it << ' ';
	g << "\n";

	g.close();
    return 0;
}
