#include <bits/stdc++.h>

using namespace std;

vector <int> graph[100005];
int degree[100005];

vector <int> generateTopoSort(int n) {
    vector <int> topoSort;
    queue <int> q;

    for (int i = 1; i <= n; ++i) {
        if (!degree[i]) {
            q.push(i);
        }
    }

    while (!q.empty()) {
        int node = q.front();
        q.pop();
        topoSort.push_back(node);

        for (auto x : graph[node]) {
            degree[x]--;
            if (!degree[x]) {
                q.push(x);
            }
        }
    }

    return topoSort;
}

int main()
{
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        degree[y] += 1;
    }
    vector <int> topoSort = generateTopoSort(n);
    for (auto x : topoSort) {
        cout << x << " ";
    }
    return 0;
}