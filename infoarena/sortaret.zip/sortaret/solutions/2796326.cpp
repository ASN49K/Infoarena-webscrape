#include <bits/stdc++.h>
using namespace std;
int d[50000];int v[50000];
queue<int>ord;
int N,M,a,b,i,j;
unordered_map<int, int>m;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
void showq(queue<int> gq)
{
    queue<int> c= gq;
    while (!c.empty()) {
        g<<c.front()<<' ';
        c.pop();
    }

}
int main()
{


    f>>N>>M;
    for(i=1;i<=M;++i)
    {
        f>>a>>b;
        if(m.find(b)== m.end())
         {m.insert(make_pair(b,a)); v[b]=50000;}
        else
        {m.insert(make_pair(b+v[b],a)); v[b]=v[b]+50000;}
        ++d[b];
    }
for (auto x : m)
      cout << x.first << " " << x.second << endl;

     for(i=1;i<=N;++i)
    {
        if(d[i]==0)
        { ord.push(i);
         for(j=1;j<=N;++j)
        while(v[b])
          {if(m[j]==i || m[j+v[b]]==i)
           {--d[j];
            if(d[j]==0)
           { ord.push(j);
            d[j]=-1;}
           }
        } v[b]=v[b]-50000;
        }
    }
    showq(ord);
    return 0;
}
