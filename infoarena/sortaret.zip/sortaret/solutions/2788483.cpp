#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

std::ifstream in("sortaret.in");
std::ofstream out("sortaret.out");

const int N=50000;

std::vector<int> v[N+1];
std::stack<int> stacc;

bool visited[N+1];

int n, m;

void Dfs(int i)
{
    visited[i]=1;

    for(int copil : v[i])
    {
        if(!visited[copil])
        {
            Dfs(copil);
        }
    }

    stacc.push(i);
}

int main()
{
    int x, y;

    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y;
        v[x].push_back(y);
    }

    for(int i=1; i<=n; i++)
    {
        if(!visited[i])
        {
            Dfs(i);
        }
    }

    while(!stacc.empty())
    {
        out<<stacc.top()<<" ";
        stacc.pop();
    }
}
