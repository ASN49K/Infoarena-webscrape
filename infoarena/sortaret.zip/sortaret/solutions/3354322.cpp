#include <vector>
#include <queue>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");

    int n, m;
    fin >> n >> m;

    vector<vector<int>> graf(n+1);
    vector<int> indeg(n+1, 0);

    queue<int> q;

    for (int i = 0; i < m; i++) {
        int a, b;
        fin >> a >> b;
        indeg[b]++;
        graf[a].push_back(b);
    }

    for (int i = 1; i <= n; i++) {
        if (indeg[i] == 0) 
            q.push(i);
    }

    vector<int> order;

    while(!q.empty()) {
        int node = q.front();
        q.pop();
        order.push_back(node);

        for (int vecin : graf[node]) {
            indeg[vecin]--;

            if (indeg[vecin] == 0) {
                q.push(vecin);
            }
        }
    }

    for (int i = 0 ; i < order.size(); i++) {
        fout << order[i] << " ";
    }

    return 0;
}