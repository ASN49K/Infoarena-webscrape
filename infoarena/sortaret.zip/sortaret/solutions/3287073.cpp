#include <fstream>
#include<vector>
#include<stack>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int> graf[50001];
int v[50001];
void dfs(int i){
  v[i]=1;
  for(int nod: graf[i]){
    if(v[nod]==0){
      v[nod]=1;
      dfs(nod);
    }
  }
  fout<<i<<" ";
}
int main(){
  int n, m, x, y;
  fin>>n>>m;
  for(int i=1; i<=m; i++){
    fin>>x>>y;
    graf[x].push_back(y);
  }
  for(int i=1; i<=n; i++){
    if(v[i]==0){
      dfs(i);
    }
  }
    return 0;
}
