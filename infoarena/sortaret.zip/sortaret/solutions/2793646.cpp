#include <bits/stdc++.h>
using namespace std;
vector <int> l[100005];
vector <int> sortop;
bool viz[100005];
int n,m;
ifstream in("sortaret.in");
ofstream out("sortaret.out");

void dfs(int s)
{
    viz[s]=1;
    for(auto el:l[s])
    {
        if(viz[el]==0)
        {
            dfs(el);
        }
    }
    sortop.push_back(s);
}

int main()
{
    in>>n>>m;
    int x,y,i;
    for(int i=0;i<m;i++)
    {
        in>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }

    for(int i=1; i<=n; i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
        }
    }
    reverse(sortop.begin(),sortop.end());
    for(int i:sortop)
    {
        out<<i<<" ";
    }

    return 0;
}
