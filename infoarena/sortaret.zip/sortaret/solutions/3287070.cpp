#include <fstream>
#include<vector>
#include<stack>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int> graf[50001];
int v[50001];
stack<int> s;
void dfs(int i){
  v[i]=1;
  s.push(i);
  int stop=s.top();
  s.pop();
  for(int nod: graf[stop]){
    if(v[nod]==0){
      v[nod]=1;
      s.push(nod);
      fout<<nod<<" ";
    }
  }
}
int main(){
  int n, m, x, y;
  fin>>n>>m;
  for(int i=1; i<=m; i++){
    fin>>x>>y;
    graf[x].push_back(y);
  }
  for(int i=1; i<=n; i++){
    if(v[i]==0){
      fout<<i<<" ";
      dfs(i);
    }
  }
    return 0;
}
