#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bitset>

using namespace std;

int n,m;

vector<vector<int>> g;
bitset<50005>viz;
vector<int> v;
queue<int> q;

void dfs(int nod)
{
    viz[nod]=1;
    for(auto el:g[nod])
    {
        if(!viz[el])dfs(el);
    }
    q.push(nod);
}

int main()
{
    ifstream fin("sortaret.in");
    fin>>n>>m;
    g.resize(n+1);
    int i,j,x,y;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
    }
    fin.close();
    for(i=1; i<=n; i++)
        if(!viz[i])dfs(i);
    while(!q.empty()){
        v.push_back(q.front());
        q.pop();
    }

    ofstream fout("sortaret.out");
    for(vector<int>::reverse_iterator it=v.rbegin();it!=v.rend();it++)
        fout<<(*it)<<' ';
    fout.close();
    return 0;
}
