#include <iostream>
#include <fstream>
#include <list>
#include <vector>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

list<int> graf[50000];
vector<int> eredmeny;
bool jart[50000];

void topologikusRendezes(int csucs){
    jart[csucs] = true;
    for(int i : graf[csucs]){
        if(!jart[i]){
            topologikusRendezes(i);
        }
    }
    eredmeny.push_back(csucs);
}

int n,m;

int main()
{
    fin>>n>>m;
    for(int i=0;i<m;i++){
        int x,y;
        fin>>x>>y;
        graf[x].push_back(y);
    }
    for(int i = 1;i<=n;i++){
        if(!jart[i]){
            topologikusRendezes(i);
        }
    }
    for(int i = n-1;i>=0;i--){
        fout<<eredmeny[i]<<' ';
    }
    fout.close();
    fin.close();
    return 0;
}
