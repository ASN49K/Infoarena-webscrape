#include <bits/stdc++.h>
#define oo 1000000007
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n, m, k, viz[100005], a[100005];
vector<int> G[100005];
void DFS(int x)
{
    viz[x] = 1;
    for(auto e : G[x])
        if(!viz[e]) DFS(e);
    a[++k] = x;
}
void SortTop()
{
    for(int i = 1; i <= n; i++)
        if(!viz[i]) DFS(i);
    for(int i = n; i >= 1; i--)
        fout << a[i] << " ";
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i,j;
    fin >> n >> m;
    while(m--)
    {
        fin >> i >> j;
        G[i].push_back(j);
    }
    SortTop();
    return 0;
}
