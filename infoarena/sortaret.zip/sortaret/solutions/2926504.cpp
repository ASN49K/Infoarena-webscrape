#include <iostream>
#include <fstream>
#include <unordered_map>
#include <queue>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int main(){
    queue<int>coada;
    unordered_map<int,vector<int>>adj_list;
    unordered_map<int,int>grade_interne;
    int n,m;
    int x,y;
    fin>>n>>m;

    for(int i = 0; i < m; i++){
        fin>>x>>y;
        adj_list[x].push_back(y);
        if(!grade_interne[y])
            grade_interne[y] = 1;
        else
            grade_interne[y]++;
    }

   for(auto it: grade_interne){
       if(!it.second)
           coada.push(it.second);
   }
   while(!coada.empty())
   {
      int cap = coada.front();
      fout<<coada.front()<<" ";
      coada.pop();
      for(auto vecin: adj_list[cap])
      {
          grade_interne[vecin]--;
            if(!grade_interne[vecin])
                coada.push(vecin);
      }
   }
    return 0;
}
