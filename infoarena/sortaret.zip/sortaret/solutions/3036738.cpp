#include <bits/stdc++.h>
#define pb push_back
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
typedef long long ll;
typedef pair<int, int> pi;
int t, T;

int elapsed_time = 0;

void DFS(int node, vector<vector<int>>& edges, vector<int>& visited, vector<int>& finish) {
    elapsed_time = elapsed_time + 1;
    visited[node] = 1;
    for(int neigh : edges[node]) {
        if (!visited[neigh]) {
            DFS(neigh, edges, visited, finish);
        }
    }
    elapsed_time = elapsed_time + 1;
    finish[node] = elapsed_time;
    visited[node] = 2;

}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    f >> n >> m;
    vector<vector<int>> V(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b;
        f >> a >> b;
        V[a].push_back(b);
    }

    vector<int> visited(n + 1, 0), finish(n + 1, 0);
    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            DFS(i, V, visited, finish);
        }
    }

    vector<pi> ans;
    for (int i = 1; i <= n; i++) {
        ans.push_back({ i, finish[i] });
    }

    sort(ans.begin(), ans.end(), [](pi& X, pi& Y) {
        return X.second >= Y.second;
        });

    for (pi& el : ans) {
        g << el.first << ' ';
    }

    return 0;
}
