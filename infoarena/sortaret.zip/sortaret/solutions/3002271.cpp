#include <fstream>
#include <vector>
using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

const int MAX = 5e4 + 1;

vector <int> g[MAX];

int topo[MAX] , in , n , m , x , y;

bool viz[MAX];

void dfs( int x ){

    viz[x] = 1;

    for(auto it : g[x]){

        if(!viz[it]){

            dfs(it);
        }
    }

    topo[in--] = x;
}

int main(){

    cin >> n >> m;

    in = n;

    while(m--){

        cin >> x >> y;

        g[x].push_back(y);
    }

    for(int i = 1 ; i <= n ; i++){

        if(!viz[i]) dfs(i);
    }

    for(int i = 1 ; i <= n ; i++){

        cout << topo[i] << ' ';
    }

    return 0;
}
