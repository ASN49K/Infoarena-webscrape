#include <bits/stdc++.h>
using namespace std;

ifstream fin ("sortaret.in");
ofstream fout("sortaret.out");

const int dim=50009;

vector<int>v[dim];
stack<int>stiva;

int n,m;
bool vizitat[dim];

void dfs(int x){
    vizitat[x]=1;
    for(int y:v[x]){
        if(!vizitat[y]){
            dfs(y);
        }
    }
    stiva.push(x);
}

signed main(){
        fin>>n>>m;
    for(int i=1;i<=m;i++){
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++){
        if(!vizitat[i]){
            dfs(i);
        }
    }
    while(!stiva.empty()){
        fout<<stiva.top()<<' ';
        stiva.pop();
    }
}
