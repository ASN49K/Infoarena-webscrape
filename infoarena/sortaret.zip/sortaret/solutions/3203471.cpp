#include <iostream>
#include <fstream>
#include <vector>
#define MAX 50005
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n,m;
vector <int> G[MAX];
int stocare[MAX];
bool viz[MAX];
int pas;
void citire()
{
    fin>>n>>m;
    int x,y;
    for(int i=0;i<m;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
}
void dfs(int nod)
{
    viz[nod]=1;
    for(size_t i=0;i<G[nod].size();i++)
    {
        if(!viz[G[nod][i]])
        {
            dfs(G[nod][i]);
        }
    }
    stocare[pas++]=nod;
}
void topsort()
{
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            dfs(i);
        }
    }
}
void afisare()
{
    for(int i=n-1;i>=0;i--)
    {
        fout<<stocare[i]<<" ";
    }
}
int main()
{
    citire();
    topsort();
    afisare();
    return 0;
}
