#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include <algorithm>
#define int short int

using namespace std;

string filename = "alpin";

ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

const int NMAX = 1024;
const int AMAX = 16384;
vector<pair<int,int>> g[NMAX + 1][NMAX + 1];
vector<pair<int,int>> pos[AMAX + 1];
int a[NMAX + 5][NMAX + 5];
int rez[NMAX + 5][NMAX + 5];
int n;

bool in_bound(int i,int j)
{
    if(i>=1 and i<=n and j>=1 and j<=n)
        return true;
    return false;
}

int dlin[] = {1, 0, -1, 0};
int dcol[] = {0, -1, 0, 1};

signed main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            fin>>a[i][j];
            pos[a[i][j]].push_back(make_pair(i,j));
        }
    }
    int i2,j2;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            for(int k=0;k<=3;k++)
            {
                i2 = i + dlin[k];
                j2 = j + dcol[k];
                if(!in_bound(i2,j2))
                    continue;
                if(a[i2][j2]>a[i][j])
                {
                    g[i2][j2].push_back(make_pair(i,j));
                }
                else if(a[i][j]!=a[i2][j2])
                {
                    g[i][j].push_back(make_pair(i2,j2));
                }
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            rez[i][j]=1;
    }
    int ans = 0;
    int ia = 0, ja = 0;
    int i,j;
    for(int a=1;a<=AMAX;a++)
    {
        for(auto it : pos[a])
        {
            i=it.first;
            j=it.second;
            int maxx = 0;
            for(auto it2 : g[i][j])
            {
                maxx = max(maxx, rez[it2.first][it2.second]);
            }
            rez[i][j] += maxx;
            if(ans < rez[i][j])
            {
                ans = rez[i][j];
                ia = i;
                ja = j;
            }
        }

    }
    fout<<ans<<'\n';
    i = ia;
    j = ja;
    vector<pair<int,int>> sol;
    while(1)
    {
        sol.push_back(make_pair(i,j));
        if(rez[i][j]==1)
            break;
        for(auto it : g[i][j])
        {
            if(rez[it.first][it.second]==rez[i][j]-1)
            {
                i=it.first;
                j=it.second;
                break;
            }
        }
    }
    reverse(sol.begin(),sol.end());
    for(auto it : sol)
    {
        fout<<it.first<<' '<<it.second<<'\n';
    }
    return 0;
}
