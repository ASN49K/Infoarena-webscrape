#include <bits/stdc++.h>
using namespace std;
const int NMAX = 5e4+2;
int n,m,vis[NMAX];
vector<int> v[NMAX],dfsOrder;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

void dfs(int nod){
  vis[nod] = true;
  for(int fiu: v[nod]){
    if(vis[fiu] == 0){
      dfs(fiu);
    }
  }
  dfsOrder.push_back(nod);
}

int main() {
  fin >> n >> m;
  for(int i = 1; i <= m; i++){
    int x, y;
    fin >> x >> y;
    v[x].push_back(y);
  }
  for(int i = 1; i <= n; i++){
    if(!vis[i]){
      dfs(i);
    }
  }
  reverse(dfsOrder.begin(), dfsOrder.end());
  for(int it: dfsOrder){
    fout << it << " ";
  }
  return 0;
}
