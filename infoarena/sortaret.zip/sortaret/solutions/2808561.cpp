#include <fstream>
#include <stack>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int INF = 500000, NMAX = 50005;
vector < vector <int> > v;
vector < int > viz, f;
stack <int> st;
void dfs(int node)
{
    viz[node] = 1;
    for(int i = 0; i < v[node].size(); i++)
    {
        if(!viz[v[node][i]])
            dfs(v[node][i]);
    }
    st.push(node + 1);
}
int main()
{
    int n, m, i, a, b;
    fin >> n >> m;
    viz.resize(n);
    f.resize(n);
    v.resize(n);
    for(i = 1; i <= m; i++)
    {
        fin >> a >> b;
        a--;
        b--;
        f[b] = 1;
        v[a].push_back(b);
    }
    for(i = 0; i < n; i++)
    {
        if(!viz[i])
            dfs(i);
    }
    while(!st.empty())
    {
        fout << st.top() << ' ';
        st.pop();
    }
    return 0;
}
