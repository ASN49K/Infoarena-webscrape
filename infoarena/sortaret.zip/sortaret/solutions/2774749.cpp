#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int N, M;
vector<vector<int>>G;
vector<int>ans;
vector<bool>viz;
void dfs(int nod) {
    viz[nod] = 1;
    for(auto it: G[nod]) {
        if(!viz[it]) {
            dfs(it);
        }
    }
    ans.push_back(nod);
}
int main() {
    fin >> N >> M;
    G = vector<vector<int>>(N + 1);
    viz = vector<bool>(N + 1);
    for(int i = 1; i <= M; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
    for(int i = 1; i <= N; i++) {
        dfs(i);
    }
    for(auto it = ans.rbegin(); it != ans.rend(); it++) {
        fout << *it << " ";
    }
    fout << '\n';
    return 0;
}
