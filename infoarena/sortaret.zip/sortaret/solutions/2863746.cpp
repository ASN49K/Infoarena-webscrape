#include <bits/stdc++.h>
#define cal 105
using namespace std;
ifstream fin (".in");
int n, m, x, y, cnt;;
vector <int> g[cal], gt[cal];
vector <bool> v;
vector <int> s;
void dfs(int x)
{
    v[x]=true;
    for(auto h : g[x])
    {
        if(v[h]==0)
        {
            dfs(h);
        }
    }
    s.push_back(x);
}
void dfst(int x)
{
    v[x]=1;
    for(auto h : gt[x])
    {
        if(!v[h])
        {
            dfst(h);
        }
    }
}
int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> x >> y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    v=vector <bool> (n+1, false);
    for(int i=1; i<=n; i++)
    {
        if(v[i]==0)
        {
            dfs(i);
        }
    }
    v=vector <bool> (n+1, false);
    reverse(s.begin(), s.end());
    for(auto h : s)
    {
        cout << h << " ";
    }
    return 0;
}
