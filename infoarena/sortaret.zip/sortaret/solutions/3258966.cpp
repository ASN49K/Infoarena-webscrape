#include <bits/stdc++.h>
using namespace std;

#if LOCAL == false
    ifstream fin("a.in");
    ofstream fout("a.out");
#else
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");
#endif

const int MAXN = 5e4 + 2;

vector<int> adj[MAXN];
vector<int> sortTop;
bool viz[MAXN];
int n, m;

void dfs(int nod) {
    viz[nod] = true;
    for(auto nxt : adj[nod])
        if(!viz[nxt])
            dfs(nxt);
    sortTop.emplace_back(nod);
}

int main()
{
    fin >> n >> m;
    
    int x, y;
    for(int i = 0; i < m; i++) {
        fin >> x >> y;
        adj[x].emplace_back(y);
    }

    for(int i = 1; i <= n; i++)
        if(!viz[i])
            dfs(i);

    reverse(sortTop.begin(), sortTop.end());

    for(auto x : sortTop)
        fout << x << ' ';
    fout << '\n';
    return 0;
}
