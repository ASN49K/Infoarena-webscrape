#include <fstream>
#include <vector>
#include <stack>

using namespace std;

const int N = 5e4;

vector <int> a[N+1];
stack <int> stiva;
bool viz[N+1];

void dfs(int x)
{
    viz[x] = true;
    for (auto y: a[x])
    {
        if (!viz[y])
        {
            dfs(y);
        }
    }
    stiva.push(x);
}

int main()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
    }
    in.close();
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            dfs(i);
        }
    }
    while (!stiva.empty())
    {
        out << stiva.top() << " ";
        stiva.pop();
    }
    out.close();
    return 0;
}
