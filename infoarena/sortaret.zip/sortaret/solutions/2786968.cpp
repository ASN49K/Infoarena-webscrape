#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");


int n, m;
vector<int>v[50005], rez;
bitset<1500000>viz;

void dfs(int nod)
{
  //  g << nod << " ";
    viz[nod] = 1;

    for(int i = 0; i < v[nod].size();i++)
    {
        if(!viz[v[nod][i]])
        {
            dfs(v[nod][i]);
        }
    }

    rez.push_back(nod);
}

int main()
{
    f >> n >> m;

    for(int i = 1; i <= m; i++)
    {
        int x, y;

        f >> x >> y;

        v[x].push_back(y);
    }


    for(int i = 1; i <= n; i++)
    {
        if(!viz[i])
            dfs(i);
    }


    for(int j = rez.size() - 1; j >= 0;j--)
        g << rez[j] << " ";

}

