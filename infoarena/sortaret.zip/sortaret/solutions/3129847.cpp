#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, st[50005], p, fr[50005];
vector<int>adj[50005];

void Dfs(int nod){
    fr[nod] = 1;
    for(auto i : adj[nod])
        if(!fr[i])
            Dfs(i);
    st[++p] = nod;
}

void SortTop(){
    for(int i = 1; i <= n; i++)
        if(!fr[i])
            Dfs(i);
    for(int i = p; i >= 1; i--)
        fout << st[i] << " ";
}

int main()
{
    int x, y;
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        fin >> x >> y;
        adj[x].push_back(y);
    }
    SortTop();

    return 0;
}
