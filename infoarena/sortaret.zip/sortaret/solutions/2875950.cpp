#include <bits/stdc++.h>
#include <chrono>

using namespace std;
const int NR = 1e5 + 10;

set<int> in_degree[NR];
set<int> out_degree[NR];
int n, m;
bool alreadyChecked[NR];

struct cmp {
    bool inline operator()(const pair<int, int> i, const pair<int, int> j) {
        return i.second > j.second;
    }
};

priority_queue<pair<int, int>, vector<pair<int, int>>, cmp> pq;


vector<int> sortTop;
//ifstream in(R"(C:\Users\andre\OneDrive\Desktop\PACE2022\newGA\cmake-build-debug\output.txt)");
ifstream in("sortaret.in");
ofstream out("sortaret.out");
vector<pair<int, int>> edges;
vector<int> posInTopSort(NR, 0);

signed main() {
    ios::sync_with_stdio(false);
    in.tie(nullptr);
    int x, y;
    in >> n >> m;
    vector<int> sinks;
    for (int i = 1; i <= m; ++i) {
        in >> x >> y;
        edges.emplace_back(x, y);
        out_degree[x].insert(y);
        in_degree[y].insert(x);
    }
    for (int i = 1; i <= n; ++i) {
        pq.push(make_pair(i, in_degree[i].size()));
        if (out_degree[i].empty()) {
            sinks.emplace_back(i);
        }
    }
    cout << n << ' ' << m << '\n';

    while (!sinks.empty()) {
        auto node = sinks.back();
        sinks.pop_back();
        if (alreadyChecked[node]) {
            continue;
        }
        alreadyChecked[node] = true;
        sortTop.push_back(node);
        for (auto it : in_degree[node]) {
            out_degree[it].erase(node);
            if (out_degree[it].empty()) {
                sinks.emplace_back(it);
            }
        }
    }


    /*
    for (auto it : edges) {
        if (posInTopSort[it.second] <= posInTopSort[it.first]) {
            cout << "NO\n";
            return 0;
        }
    }
     */
    for (int i = sortTop.size() - 1; i >= 0; --i) {
        out << sortTop[i] << ' ';
    }
    return 0;
}