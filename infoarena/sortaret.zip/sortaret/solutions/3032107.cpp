#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<vector<int>> l(50001);
deque<int> dq;
int n,m;
int vis[50001]={0};

void dfs(int x){
    vis[x] = 1;
    for (const auto &item: l[x]) {
        if(vis[item]==0){
            dfs(item);
        }

    }
    dq.push_back(x);




}



int main(){
    fin>>n>>m;

    for(int i =0; i<m;++i){
        int x,y;
        fin>>x>>y;
        l[x].push_back(y);
    }
    for (int i=1;i<=n;++i) {
        if(vis[i] == 0){
            dfs(i);
        }
    }

    for (const auto &item: dq) {
        fout<<item<<" ";
    }
}