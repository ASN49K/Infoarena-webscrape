#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n,m,x,y,vizitat[50020];
vector <int> edges[50020];
stack <int> st;

void dfs(int x)
{
    vizitat[x]=1;
    for(auto y:edges[x])
        if(vizitat[y]==0)
            dfs(y);
    st.push(x);
}

int32_t main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
        f>>x>>y, edges[x].push_back(y);
    for(int i=1; i<=n; i++)
        if(vizitat[i]==0)
            dfs(i);
    while(!st.empty())
        g<<st.top()<<' ', st.pop();
    return 0;
}
