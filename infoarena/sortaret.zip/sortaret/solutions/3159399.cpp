#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, st[50005], top;
vector <int> a[50005];
bitset <50005> viz;

void Dfs(int x)
{
    viz[x] = 1;
    for (int w : a[x])
        if (viz[w] == 0)
            Dfs(w);
    st[++top] = x;
}

int main()
{
    int i, j, x, y;
    fin >> n >> m;
    for (i = 1; i <= n; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
    }

    for (i = 1; i <= n; i++)
        if (viz[i] == 0)
            Dfs(i);

    for (i = n; i >= 1; i--)
        fout << st[i] << " ";

    return 0;
}
