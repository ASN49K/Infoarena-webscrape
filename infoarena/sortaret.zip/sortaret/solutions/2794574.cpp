#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <deque>
#include <stack>
using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");


class Graf {
    vector<list<int>> noduri;
    void dfs(int nod, vector<bool> &vizitate) {
        vizitate[nod] = true;
        for(auto i: noduri[nod])
            if(!vizitate[i])
                dfs(i, vizitate);
    }
    void bfs(int start, vector<int> &costuri, vector<bool> &vizitate,deque<int> &coada) {
        coada.push_back(start);
        vizitate[start] = true;
        costuri[start] = 0;
        while(coada.empty() != 1) {
            int k = coada.front();
            for(auto i: noduri[k])
                if(!vizitate[i]) {
                    costuri[i] += (costuri[k] + 1);
                    vizitate[i] = true;
                    coada.push_back(i);
                }
            coada.pop_front();
        }
    }
    void dfsTopo(int nod, vector<bool> &vizitate, stack<int> &rezultat) {
        vizitate[nod] = true;
        for(auto i: noduri[nod])
            if(!vizitate[i])
                dfsTopo(i, vizitate, rezultat);
        rezultat.push(nod);
    }
public:
    Graf(vector<list<int>> _noduri) : noduri(_noduri) {}
    friend ostream& operator<< (ostream& os, Graf graf) {
        os << graf.noduri.size() << " nodes\n";
        for(int i = 0; i < graf.noduri.size(); i++) {
            os << "node " << i << ": ";
            for(int j: graf.noduri[i])
                os << j << " ";
            os << "\n";
        }
        return os;
    }
    int nrConexe() {
        vector<bool> vizitate(noduri.size());
        int nr = 0;
        for(int i = 0; i < noduri.size(); i++)
            if(!vizitate[i]) {
                nr++;
                dfs(i, vizitate);
            }
        return nr;
    }
    void costuriBFS(int nod) {
        vector<int> costuri(noduri.size());
        deque<int> coada;
        vector<bool> vizitate(noduri.size());
        bfs(nod, costuri, vizitate, coada);
        for (int i = 0; i < noduri.size(); i++) {
            if(vizitate[i])
                out << costuri[i] << " ";
            else out << -1 << " ";
        }
    }
    void sortareTopologica(){
        vector<bool> vizitate(noduri.size());
        stack<int> rezultat;
        int nr = 0;
        for(int i = 0; i < noduri.size(); i++)
            if(!vizitate[i])
                dfsTopo(i, vizitate, rezultat);
        while(rezultat.empty() != 1){
            out << rezultat.top() + 1 << " ";
            rezultat.pop();
        }
    }
};

int main() {
    int noduri, muchii, start;
    in >> noduri >> muchii;
//    in >> start; //doar ptr bfs
    vector<list<int>> aux(noduri);
    for(int i = 0; i < muchii; i++) {
        int x1, x2;
        in >> x1 >> x2;
        aux[x1 - 1].push_back(x2 - 1);
//      aux[x2 - 1].push_back(x1 - 1);  // daca e neorientat
    }
    Graf graf(aux);
//    out << graf.nrConexe(); //ptr DFS
//    graf.costuriBFS(start - 1); //ptr BFS
    graf.sortareTopologica();
    return 0;
}