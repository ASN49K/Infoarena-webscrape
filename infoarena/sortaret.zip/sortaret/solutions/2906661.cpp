#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
vector<vector<int> > V(102);
queue<int> Q;
int Grad[102], n, m;
void TSort(){
    for(int i=1; i<=n; i++){
        if(!Grad[i])
            Q.push(i);
    }
    while(!Q.empty()){
        int nod = Q.front();
        cout << nod << ' ';
        for(vector<int>::iterator it = V[nod].begin(); it != V[nod].end(); it ++){
            Grad[*it] --;
            if(Grad[*it] == 0){
                Q.push(*it);
            }
        }
        Q.pop();
    }
}
int main()
{
    cin >> n >> m;
    for(int i=1; i<=m; i++){
        int x1, x2;
        cin >> x1 >> x2;
        V[x1].push_back(x2);
        Grad[x2] ++;
    }
    TSort();

    return 0;
}
