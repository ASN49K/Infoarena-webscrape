#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, viz[50003], v[50003], len;
vector <int> g[100003];

void DFStf(int x)
{
    viz[x] = 1;
    for (int i : g[x])
        if (viz[i] == 0) DFStf(i);
    v[++len] = x;
}

void SortTop()
{
    int i;
    for (i = 1; i <= n; i++)
        if (viz[i] == 0) DFStf(i);
    for (i = n; i >= 1; i--)
        fout << v[i] << " ";
}

void Citire()
{
    int i, j, p;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        g[i].push_back(j);
    }
}

int main()
{
    Citire();
    SortTop();
    return 0;
}

