#include <iostream>
#include <fstream>
#include <vector>

std::ifstream in("sortaret.in");
std::ofstream out("sortaret.out");

int n, m;
std::vector<int> adj[50001];
std::vector<int> sol;
bool vis[50001];

void dfs(int start)
{
    vis[start] = 1;
    for(auto it = adj[start].begin();it != adj[start].end();it++)
    {
        if(!vis[*it])
            dfs(*it);
    }
    sol.insert(sol.begin(), start);
}

int main()
{
    in>>n>>m;
    int x, y;
    for(int i = 1;i <= m;i++)
    {
        in>>x>>y;
        adj[x].push_back(y);
    }
    for(int i = 1;i <= n;i++)
        if(!vis[i])
            dfs(i);
    for(const auto& it : sol)
    {
        out<<it<<' ';
    }
    return 0;
}