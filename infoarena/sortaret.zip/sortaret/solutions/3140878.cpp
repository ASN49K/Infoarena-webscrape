#include <bits/stdc++.h>
#define N_MAX 50005
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<int> l[N_MAX];
int n, m;

bool viz[N_MAX];
void dfs(int nod)
{
    viz[nod] = true;
    
    for (int i = 0; i < l[nod].size(); i++)
    {
        int vecin = l[nod][i];
        if (!viz[vecin])
            dfs(vecin);
    }
    fout<<nod<<" ";
}
int main()
{
    fin >> n >> m;
    for (; m--;)
    {
        int x, y;
        fin >> x >> y;
        l[x].push_back(y);
    }
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
            dfs(i);
    }
}