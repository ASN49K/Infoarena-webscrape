#include <bits/stdc++.h>

using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
set<int>v[300000];
int n,m,x,y,i;
int viz[300001];
stack<int>sol;
void dfs(int x){
    viz[x]=1;
    for(auto k:v[x]){
        if(viz[k]==0) dfs(k);
    }
    sol.push(x);
}
int main()
{
    in>>n>>m;
    for(i=1;i<=m;i++){
        in>>x>>y;
        v[x].insert(y);
    }
    for(i=1;i<=n;i++){
        if(viz[i]==0){
            dfs(i);
        }
    }
    while(!sol.empty()){
         out<<sol.top()<<" ";
         sol.pop();
    }
    return 0;
}
