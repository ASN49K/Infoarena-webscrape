#include<bits/stdc++.h>
#define nlim 50005
#define pb push_back

using namespace std;

ifstream f("sortare.in");
ofstream g("sortare.out");
int n,m,viz[nlim],deg[nlim];

vector<int>mat[nlim];
inline void solve()
{

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(deg[j]==0 && !viz[j])
            {
                viz[j]=1,g<<j<<" ";
                for(unsigned int k=0; k<mat[j].g(); k++)
                {
                    deg[ mat[j][k] ]--;
                }
            }
        }
    }
}
inline void cetire()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b;
        f>>a>>b;
        mat[a].pb(b);
        deg[b]++;
    }
}
int main()
{
    cetire();
    solve();

}

