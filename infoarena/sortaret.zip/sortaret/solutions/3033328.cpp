#include <fstream>
#include <stack>

using namespace std;

const int N = 5e4;
const int M = 1e5;

struct vecin
{
    int vf, urm;
};

vecin v[M+1];
int lst[N+1], nr;
bool viz[N+1];

stack <int> stiva;

void adauga(int x, int y)
{
    nr++;
    v[nr].vf = y;
    v[nr].urm = lst[x];
    lst[x] = nr;
}

void dfs(int x)
{
    viz[x] = true;
    for (int p = lst[x]; p != 0; p = v[p].urm)
    {
        int y = v[p].vf;
        if (!viz[y])
        {
            dfs(y);
        }
    }
    stiva.push(x);
}

int main()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        adauga(x, y);
    }
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            dfs(i);
        }
    }
    while (!stiva.empty())
    {
        out << stiva.top() << " ";
        stiva.pop();
    }
    in.close();
    out.close();
    return 0;
}
