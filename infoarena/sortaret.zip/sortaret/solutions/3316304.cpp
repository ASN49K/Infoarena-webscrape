#include <fstream>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <set>
using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
int v,m;
vector<set<int>>g;
vector<bool>vizitat;
void dfs(int nodstart){
    out<<nodstart<<" ";
    vizitat[nodstart]=true;
    for(const int& vecin:g[nodstart]){
        if(vizitat[vecin]==0){
            dfs(vecin);
        }
    }
}
int main()
{
    int a,b,mini;
    in>>v>>m;
    g=vector<set<int>>(v+1);
    vizitat=vector<bool>(v+1,0);
    for(int i=0;i<m;i++){
        in>>a>>b;
        g[a].insert(b);
    }
    for(int i=1;i<v;i++){
        if(vizitat[i]==0){
            dfs(i);
        }
    }
    return 0;
}
