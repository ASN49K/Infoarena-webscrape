#include <fstream>
#include <iostream>
#include <vector>
#include <stack>

using namespace std;

void dfs(int x, vector <bool> &viz, vector <vector <int>> &l_s, stack <int> &s) {
    viz[x] = true;
    for (auto y: l_s[x]) {
        if (!viz[y]) {
            dfs(y, viz, l_s, s);
        }
    }
    s.push(x);
}

int main() {
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");
    int n, m;
    in >> n >> m;
    vector <vector<int>> l_s(n + 1);
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        l_s[x].push_back(y);
    }
    in.close();
    stack <int> s;
    vector <bool> viz(n + 1, false);
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            dfs(i, viz, l_s, s);
        }
    }
    while (!s.empty()) {
        int x = s.top();
        s.pop();
        out << x << " ";
    }
    out << "\n";
    out.close();
    return 0;
}
