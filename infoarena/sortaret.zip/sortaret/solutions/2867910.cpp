#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n,m,i,a,b,mark[50005];
vector <int> v[50005];
vector <int> sol;

void DFS(int nod){
    for(int i=0;i<v[nod].size();i++){
        int vecin = v[nod][i];
        if(!mark[vecin]){
            mark[vecin] = 1;
            DFS(vecin);
        }
    }
    sol.push_back(nod);
}


int main()
{
fin>>n>>m;
for(i=1;i<=m;i++){
    fin>>a>>b;
    v[a].push_back(b);
}
for(i=1;i<=n;i++){
    if(!mark[i]){
        mark[i] = 1;
        DFS(i);
    }
}
n = sol.size() - 1;
for(i=n;i>=0;i--){
    fout << sol[i] << " ";
}
    return 0;
}
