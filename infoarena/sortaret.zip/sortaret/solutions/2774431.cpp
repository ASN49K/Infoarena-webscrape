#include<cstdio>
#include<vector>
using namespace std;
#define N 50001
vector<int> g[N];
int n,m,i,j,k,v[N],u[N];
void D(int i)
{
    int j,l;
    for(v[i]=1,l=(int)g[i].size(),j=0;j<l;++j)
        if(!v[g[i][j]])
            D(g[i][j]);
    u[++k]=i;
}
int main()
{
	freopen("sortaret.in","r",stdin),freopen("sortaret.out","w",stdout),scanf("%d%d",&n,&m);
    while(m--)
        scanf("%d%d",&i,&j),g[i].push_back(j);
    for(i=1;i<=n;++i)
        if(!v[i])
        	D(i);
    for(i=n;i;--i)
    	printf("%d ",u[i]);
    return 0;
}
