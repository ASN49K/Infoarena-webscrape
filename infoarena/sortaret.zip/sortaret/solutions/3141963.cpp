#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <functional>
#include <bitset>
#include <map>
#include <queue>
using namespace std;
template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
template<typename A> ostream& operator<<(ostream &os, vector<A>&a) { for(auto &c:a)os<<c<<' '; return os;}
template<typename A> istream& operator>>(istream &os, vector<A>&a) { for(auto &c:a)os>>c; return os;}
template<typename A,size_t N> istream& operator>>(istream &os, array<A,N>&a) { for(auto &c:a)os>>c; return os;}
#define bug(a) cerr << "(" << #a << ": " << a << ")\n";
#define all(x) x.begin(),x.end()
#define pb push_back
#define PQ priority_queue
#define pii pair<int,int>
using i64= int64_t;
using i16= int16_t;
using u64= uint64_t;
using u32= uint32_t;
using i32= int32_t;
const i32 inf=1e9;
const i64 INF=1e18;
const int mod=1e9+7;
bitset<50000>viz;
ifstream cin("sortaret.in");
ofstream cout("sortaret.in");
void solve()
{
    int n,m;
    cin>>n>>m;
    vector<vector<int>>g(n);
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        g[x-1].pb(--y);
        viz[y]=1;
    }
    queue<int>q;
    for(int i=0;i<n;i++)
    {
        if(!viz[i])
        {
            q.push(i);
        }
    }
    while(q.size())
    {
        int then=q.front();
        q.pop();
        cout<<then+1<<' ';
        for(auto &c:g[then])
        {
            if(viz[c])
            {
                viz[c]=0;
                q.push(c);
            }
        }
    }
}
main()
{
    /*ios::sync_with_stdio(false);
    cin.tie(0);*/
    int tt=1;
    //cin>>tt;
    while(tt--)solve();
}

