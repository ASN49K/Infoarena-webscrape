#include <fstream>

using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

int n, m, c[1000000], k, x, y, start[1000000], t[3][1000000], fr[1000000], man, st=1, dr=0;

void liste(int i, int j)
{
    k++;
    t[0][k]=j;
    t[1][k]=start[i];
    start[i]=k;
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        liste(x, y);
        fr[y]++;
    }

    for(int i=1;i<=n;i++)
        if(fr[i]==0)
            c[++dr]=i;

    while(st<=dr)
    {
        x=c[st];
        if(fr[x]==0)
        {
            cout<<x<<' ';
            fr[x]=-1;
            man=start[x];
            while(man)
            {
                if(fr[t[0][man]]!=0)
                {
                    fr[t[0][man]]--;
                    if(fr[t[0][man]]==0) c[++dr]=t[0][man];
                }
                man=t[1][man];
            }
        }
        else c[++dr]=x;
        st++;
    }
    return 0;
}
