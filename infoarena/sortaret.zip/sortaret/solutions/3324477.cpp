#include <bits/stdc++.h>
using namespace std;
int n,m,a,b;
const int maxn=1e5+5;
vector<int> adj[maxn];
vector<int> topo;
int indg[maxn];
void topor(){
    queue<int> q;
    for(int i=1;i<=n;i++){
        if (indg[i]==0) q.push(i);
    }
    while(!q.empty()) {
        int u=q.front();
        q.pop();
        topo.push_back(u);
        for (auto elem:adj[u]) {
            indg[elem]--;
            if (indg[elem]==0) q.push(elem);
        }
    }
}
int main()
{
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int l,r;
        cin>>l>>r;
        adj[l].push_back(r);
        indg[r]++;
    }
    topor();
    for (auto elem:topo)cout<<elem<<" ";
    return 0;
}