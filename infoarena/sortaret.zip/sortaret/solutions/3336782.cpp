#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, grad[50005];
vector<int> vec[50005];
queue<int> q;
int main(){

    fin>>n>>m;
    for(int i=1; i<=m; i++){
        int x, y;
        fin>>x>>y;
        vec[x].push_back(y);
        grad[y]++;
    }

    while(q.size()!=n)
        for(int i=1; i<=n; i++)
            if(grad[i] == 0){
                q.push(i);
                for(int j : vec[i])
                    grad[j] -= 1;   
            }

    while(!q.empty()){
        fout<<q.front()<<' ';
        q.pop();
    }
    return 0;
}