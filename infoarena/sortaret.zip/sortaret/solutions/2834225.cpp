#include <fstream>
#include <vector>
using namespace std;

static int_fast32_t Nodes, Edges;
static int_fast32_t BeenThere[50001], InsideGrade[50001];
vector < int_fast32_t > Edge[50001], ans;

inline static void DFS(int_fast32_t node){
    BeenThere[node] = true;
    for(auto Neighbour: Edge[node])
        if( ! BeenThere[Neighbour])
            DFS(Neighbour);
    ans.push_back(node);
}

int main(){

    string name("sortaret");
    ifstream cin(name + ".in");
    ofstream cout(name + ".out");
    cin >> Nodes >> Edges;
    register int i;
    int_fast32_t node1, node2;
    for(i = 1; i <= Edges; ++i){
        cin >> node1 >> node2;
        Edge[node1].push_back(node2);
        ++InsideGrade[node2];
    }
    for(i = 1; i <= Nodes; ++i)
        if( ! InsideGrade[i])
            DFS(i);
    for(vector < int_fast32_t > :: reverse_iterator it = ans.rbegin(); it != ans.rend(); ++it)
        cout << *it << ' ';

    return 0;
}