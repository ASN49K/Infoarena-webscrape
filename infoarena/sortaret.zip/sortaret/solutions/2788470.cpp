#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

std::ifstream in("sortaret.in");
std::ofstream out("sortaret.out");

const int N=50000;

std::vector<int> v[N+1], rez;
std::stack<int> stacc;

bool visited[N+1];

int n, m;

void Dfs(int i)
{
    visited[i]=1;

    for(int copil : v[i])
    {
        if(visited[copil]==0)
        {
            Dfs(copil);
        }
    }

    rez.push_back(i);
    stacc.push(i);
}

int main()
{
    int x, y;

    in>>n>>m;
    for(int i=1; i<=n; i++)
    {
        in>>x>>y;
        v[x].push_back(y);
    }

    for(int i=1; i<=n; i++)
    {
        if(visited[i]==0)
        {
            Dfs(i);
        }
    }

    for(int i=rez.size()-1; i>=0; i--)
    {
        out<<rez[i]<<" ";
    }
}
