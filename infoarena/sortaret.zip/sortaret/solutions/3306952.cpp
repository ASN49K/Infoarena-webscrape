#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<int> a[50005];
vector<int> ans;
bool b[50005];

void dfs(int x) {
    if(b[x])
        return;
    b[x] = true;
    for(auto i : a[x]) {
        dfs(i);
    }
    ans.push_back(x);
}

int main() {
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m; cin >> n >> m;
    for(int i = 1; i <= m; i ++) {
        int x, y; cin >> x >> y;
        a[x].push_back(y);
    }
    for(int i = 1; i <= n; i ++) {
        dfs(i);
    }
    reverse(ans.begin(), ans.end());
    for(auto i : ans) {
        cout << i << ' ';
    }
}