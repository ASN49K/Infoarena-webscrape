#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int nmax = 5e4+10;
int n,m;
vector<vector<int>> mat(nmax);
vector<int> visited(nmax),noduri;
void read_input(){
	fin >> n >> m;
	int nod_1,nod_2;
	for(int i = 1; i <=m; i++){
		fin >> nod_1 >> nod_2;
		mat[nod_1].push_back(nod_2);
	}
};
void dfs(int nod){
	visited[nod] = 1;
	for(auto nod_aux : mat[nod]){
	    if(!visited[nod_aux]){
	        visited[nod_aux] = 1;
			dfs(nod_aux);
		}
	};
	noduri.push_back(nod);
}
int main(){
	read_input();
	for(int i = 1; i <=n;i++){
		if(!visited[i]){
			dfs(i);
		}
	};
	reverse(noduri.begin(),noduri.end());
	for(auto x : noduri){fout << x << " ";};
	return 0;
}
