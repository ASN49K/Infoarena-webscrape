/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <fstream>
#include <vector>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int>g[100000];
int n,  viz[100001],m;
int sorttop[100001],cnt;

void dfs(int x) {
    viz[x] = 1;
    for(auto y : g[x]) {
        if(!viz[y])
            dfs(y);
    }
    sorttop[++cnt]= x;
 }

int main()
{
    fin >> n>>m;
    for(int i = 1,x,y; i <= m; ++i) {
        fin >> x >> y;
        g[x].push_back(y);
    }
     for ( int i = 1; i <= n; ++i)
        if(!viz[i])
            dfs(i);
    for(int i = cnt; i>=1; --i)
        fout << sorttop[i] << " ";
        
    return 0;
}
