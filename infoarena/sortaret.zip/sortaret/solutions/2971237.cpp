#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>

#define NMAX 50005

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

queue<int> q;

int n, m;
int x, y;
vector<int> l[NMAX];
vector<int> rez;
bool f[NMAX];
int i;

void dfs(int);

int main()
{
    fin >>n>>m;
    for (i = 1; i <= m; ++i)
    {
        fin >>x>>y;
        l[x].push_back(y);
    }

    for (i = 1; i <= n; ++i)
        if (!f[i]) dfs(i);

    reverse(rez.begin(), rez.end());

    for (i = 0; i < rez.size(); ++i)
        fout <<rez[i]<<' ';
    fout <<'\n';
    fout.close();
    return 0;
}

void dfs(int vf)
{
    int i;
    int vfnou;

    f[vf] = 1;
    for (i = 0; i < l[vf].size(); ++i)
    {
        vfnou = l[vf][i];
        if (!f[vfnou]) dfs(vfnou);
    }

    rez.push_back(vf);
}
