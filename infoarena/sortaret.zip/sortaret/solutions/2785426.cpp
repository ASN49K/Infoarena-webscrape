#include <fstream>
#include <vector>
using namespace std;
int n,m;
const int N=50001;
ifstream Gigi ("sortaret.in");
ofstream Marcel ("sortaret.out");
struct nod
{
    int k=0;
    vector <int> vec;
};
nod v[N];
vector <int> sol;
vector <int> descos;
void scoate (int p)
{
    for (int i=1;i<=n;i++){
        for (int j=0;j<v[i].k;j++){
            if (v[i].vec[j]==p){
                v[i].vec.erase(v[i].vec.begin()+j);
                v[i].k--;
                j--;
            }
        }
    }
}
int main()
{
    Gigi>>n>>m;
    int x,y,i;
    for (i=0;i<m;i++){
        Gigi>>x>>y;
        v[y].k++;
        v[y].vec.push_back(x);
    }
    bool b=1;
    while (b){
        b=0;
        for (i=1;i<=n;i++){
            if (v[i].k==0){
                b=1;
                v[i].k=-1;
                descos.push_back(i);
            }
        }
        while(!descos.empty()){
            sol.push_back(descos.back());
            scoate(descos.back());
            descos.pop_back();
        }
    }
    for (i=0;i<sol.size();i++){
        Marcel<<sol[i]<<" ";
    }
    return 0;
}
