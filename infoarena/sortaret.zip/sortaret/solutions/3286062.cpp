#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int NMAX = 1e5;
vector<int> G[NMAX + 1];
vector<int> topsort;
int vis[NMAX + 1];

void dfs(int node) {
    vis[node] = 1;
    for(auto next : G[node]) {
        if(!vis[next]) {
            dfs(next);
        }
    }
    topsort.push_back(node);
}


int main() {
    int n, m;
    f >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        f >> x >> y;
        G[x].push_back(y);
    }
    for(int i = 1; i <= n; i++) {
        if(!vis[i]) {
            dfs(i);
        }
    }
    for(int i = topsort.size() - 1; i >= 0; i--) {
        g << topsort[i] << ' ';
    }
    return 0;
}