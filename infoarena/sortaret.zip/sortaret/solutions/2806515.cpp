#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <bits/stdc++.h>

using namespace std;


class Graf {
    int nrNoduri, nrMuchii;
    vector<vector<int>> vecini;

    void afis_lista_ad();
    vector<int> BFS(const int Start);
    vector<int> DFS(const int Start);
    vector<int> distante_BFS(const int Start);
    void parcurgere_DFS(int nod_curent, vector<int>& sol, vector<bool>& viz);
    vector<int> sortare_topologica(vector<int> grad_intern);

public:
    void problema_BFS();
    void problema_DFS();
    void problema_sortaret();
};

void Graf::afis_lista_ad()
{
    for(int i=1; i<=nrNoduri; i++)
    {
        cout<< i <<": ";
        int l = vecini[i].size();
        for(int j=0; j<l; j++)
        {
            cout<< vecini[i][j] <<' ';
        }
        cout<<"\n";
    }
}

vector<int> Graf::distante_BFS(const int Start)
{
    queue<int> coada;
    vector<int> inaltime;
    vector<bool> vizitat;
    inaltime.resize(nrNoduri+1);
    vizitat.resize(nrNoduri+1);
    for(int i=0; i<=nrNoduri; i++) {
        inaltime[i] = 0;
        vizitat[i] = false;
    }

    coada.push(Start);
    vizitat[Start] = true;

    while(!coada.empty()) {
        int nod_curent = coada.front();
        coada.pop();
        for(int i=0; i< int(vecini[nod_curent].size()); i++) {
            int x = vecini[nod_curent][i];
            if(!vizitat[x]) {
                vizitat[x] = true;
                coada.push(x);
                inaltime[x] = inaltime[nod_curent] + 1;
            }
        }
    }
    for(int i=1; i<=nrNoduri; i++) {
        if(inaltime[i] == 0 && i != Start)
            inaltime[i] = -1;
    }
    return inaltime;
}

vector<int> Graf::BFS(const int Start)
{
    vector<int>sol;
    queue<int> coada;
    vector<bool> vizitat;
    vizitat.resize(nrNoduri+1);
    for(int i=0; i<=nrNoduri; i++) {
        vizitat[i] = false;
    }

    coada.push(Start);
    vizitat[Start] = true;

    while(!coada.empty()) {
        int nod_curent = coada.front();
        coada.pop();
        sol.push_back(nod_curent);
        for(int i=0; i< int(vecini[nod_curent].size()); i++) {
            int x = vecini[nod_curent][i];
            if(!vizitat[x]) {
                vizitat[x] = true;
                coada.push(x);
            }
        }
    }
    return sol;
}

void Graf::problema_BFS()
{
    ifstream in("bfs.in");
    ofstream out("bfs.out");

    int Start;
    in>>nrNoduri>>nrMuchii>>Start;

    vecini.resize(nrNoduri+1);
    for(int i=0; i<nrMuchii; i++)
    {
        int x,y;
        in>>x>>y;
        vecini[x].push_back(y);
    }
    vector<int> distante = distante_BFS(Start);
    for(int i=1; i<=nrNoduri; i++) {
        out << distante[i]<< ' ';
    }

    in.close();
    out.close();
}

void Graf::parcurgere_DFS(int nod_curent, vector<int>& sol, vector<bool>& viz)
{
    viz[nod_curent] = true;
    sol.push_back(nod_curent);
    for(int i=0; i<int(vecini[nod_curent].size()); i++) {
        int nod = vecini[nod_curent][i];
        if(!viz[nod]) {
            parcurgere_DFS(nod, sol , viz);
        }
    }
}

vector<int> Graf::DFS(const int Start)
{
    vector<int> sol;
    vector<bool> viz;
    viz.resize(nrNoduri+1);
    for(int i=0; i<=nrNoduri; i++) {
        viz[i] = false;
    }
    int nod_curent = Start;
    parcurgere_DFS(nod_curent, sol, viz);
    return sol;
}

void Graf::problema_DFS()
{
    ifstream in("dfs.in");
    ofstream out("dfs.out");

    in>>nrNoduri>>nrMuchii;
    vecini.resize(nrNoduri+1);

    for(int i=0; i<nrMuchii; i++){
        int x,y;
        in>>x>>y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }

    vector<int> nr_comp_conexa;
    nr_comp_conexa.resize(nrNoduri+1);
    for(int i=1; i<=nrNoduri; i++) {
        nr_comp_conexa[i] = 0;
    }

    int k=0;
    for(int i=1; i<=nrNoduri; i++){
        if(nr_comp_conexa[i] == 0) {
            ++k;
            vector<int> noduri = DFS(i);
            for(int j=0; j<int(noduri.size()); j++) {
                nr_comp_conexa[noduri[j]] = k;
            }
        }
    }
    out<<k;
    in.close();
    out.close();
}

vector<int> Graf::sortare_topologica(vector<int> grad_intern)
{
    vector<int> sol;
    int contor = 0;
    while(contor < nrNoduri) {
        for(int nod = 1; nod <= nrNoduri; nod++) {
            if(grad_intern[nod] == 0) {
                contor++;
                sol.push_back(nod);
                for(int i=0; i<int(vecini[nod].size()); i++){
                    grad_intern[vecini[nod][i]]--;
                }
                grad_intern[nod]--;
            }
        }
    }
    return sol;
}

void Graf::problema_sortaret()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");

    in>>nrNoduri>>nrMuchii;
    vecini.resize(nrNoduri+1);
    vector<int> grad_intern;
    grad_intern.resize(nrNoduri+1);
    for(int i=0; i<nrNoduri; i++){
        grad_intern[i]=0;
    }
    for(int i=0; i<nrMuchii; i++){
        int x,y;
        in>>x>>y;
        vecini[x].push_back(y);
        grad_intern[y]++;
    }

    vector<int> sol = sortare_topologica(grad_intern);
    for(int i=0; i<nrNoduri; i++){
        cout<<sol[i]<<' ';
    }
    in.close();
    out.close();
}


/*bool Graf::Havel_Hakimi()
{
    in>>nrNoduri;
    int grad[nrNoduri+1], suma=0;
    for(int i=0; i<nrNoduri; i++)
    {
        in >> grad[i];
        suma += grad[i];
        if(grad[i] > (nrNoduri - 1))
        {
            out<<"NU";
            return false;
        }
    }
    if(suma % 2 == 1)
    {
        out <<"NU";
        return false;
    }
    sort(grad, grad+nrNoduri, greater<int>());
    while(grad[0] != 0)
    {
        for(int i=0; i<nrNoduri; i++)
        {
            out<<grad[i]<<' ' ;
        }
        out<<"\n";
        for(int i=1; i<=grad[0]; i++)
        {
            grad[i]--;
            if(grad[i] < 0)
            {
                out<<"NU";
                return false;
            }
        }
        grad[0] = 0;
        sort(grad, grad+nrNoduri, greater<int>());
    }
    out<<"DA";
    return true;
}


void Graf::tarjan(int nod)
{
    int l = vecini[nod].size();
    for(int i=0; i<l; i++)
    {
        int vec = vecini[nod][i];
        if(!vizitat[vec])
        {
            stiva.push(vec);
            pe_stiva[vec] = true;
            vizitat[vec] = true;
            tarjan(vec);
            if(pe_stiva[nod])
                lowlink[nod] = min(lowlink[nod], lowlink[vec]);
        }
    }
    if(lowlink[nod] = nod)
    {
        nrCTC++;
        while(lowlink[stiva.top()] == nod)
        {
            pe_stiva[stiva.top()] = false;
            stiva.pop();
        }
    }
}

void Graf::problema_CTC()
{
    in >> nrNoduri >> nrMuchii;
    vecini.resize(nrNoduri+1);
    lowlink.resize(nrNoduri+1);
    pe_stiva.resize(nrNoduri+1);
    vizitat.resize(nrNoduri+1);
    nrCTC = 0;

    for(int i=0; i<nrMuchii; i++)
    {
        int x,y;
        in>>x>>y;
        vecini[x].push_back(y);
    }

    for(int i=1; i<=nrNoduri+1; i++)
    {
        vizitat[i] = false;
        pe_stiva[i] = false;
        lowlink[i] = i;
    }
    for(int nod=1; nod<=nrNoduri; nod++)
    {
        if(!vizitat[nod])
        {
            stiva.push(nod);
            pe_stiva[nod] = true;
            vizitat[nod] = true;
            tarjan(nod);
        }
    }
    cout << nrCTC;
}*/

int main()
{
    Graf G;
    //G.problema_BFS();
    //G.problema_DFS();
    G.problema_sortaret();
    return 0;
}
