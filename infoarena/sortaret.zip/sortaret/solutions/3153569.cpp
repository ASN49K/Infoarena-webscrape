#include <bits/stdc++.h>

using namespace std;

const int nmax = 1e5 + 1;

int f[nmax];
vector<vector<int>> adj;

int main() {
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    int n, m;
    cin >> n >> m;
    adj.resize(n + 1);
    for(int i = 1; i <= m; i ++) {
        int a, b;
        cin >> a >> b;
        adj[a].push_back(b);
        f[b] ++;
    }
    queue<int> q;
    for(int i = 1; i <= n; i ++) {
        if(!f[i]) {
            q.push(i);
        }
    }
    while(!q.empty()) {
        int i = q.front();
        q.pop();
        for(auto it : adj[i]) {
            f[it] --;
            if(f[it] == 0) {
                q.push(it);
            }
        }
        cout << i << " ";
    }
    return 0;
}
