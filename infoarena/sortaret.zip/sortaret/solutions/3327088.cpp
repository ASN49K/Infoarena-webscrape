#include<bits/stdc++.h>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector <int>L[100001];
int n,m,st[100001];
int vz[100001];
int in=0;
int grdint[100001];
void dfs(int k)
{  vz[k]=1;
    for(int i=0;i<L[k].size();i++)
    if(vz[L[k][i]]==0) dfs(L[k][i]);
    st[++in]=k;
}
void sorttop()
{
    for(int i=1;i<=n;i++)
        if(vz[i]==0)
        dfs(i);
}
void citire()
{
    int x,y;
    for(int i=1;i<=m;i++)
    {f>>x>>y;
        L[x].push_back(y);
        grdint[y]++;
    }
     for (int i=1 ; i<=n ; i++)
  {
    sort(L[i].begin(),L[i].end());
        for (int j=1 ; j < L[i].size() ; j++)
        if(L[i][j-1]==L[i][j]){L[i].erase(L[i].begin()+j);j--;}
  }
}
int main()
{
 f>>n>>m;
    citire();
    sorttop();
    for(int i=n;i>0;i--)
        g<<st[i]<<" ";
        g<<'\n';
    return 0;

}
