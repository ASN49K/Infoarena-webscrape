#include <bits/stdc++.h>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

const int nmax=5e4+5;
int n,m,in_node[nmax];

vector <int> gr[nmax];
vector <int> s;

void sort_topo()
{
    queue <int> q;
    for (int i=1; i<=n; i++ )
        if ( in_node[i] == 0 )
            q.push(i);

    while ( !q.empty() )
    {
        int x=q.front(); q.pop();
        s.push_back(x);

        for (int vec:gr[x] )
        {
            in_node[vec]--;
            if ( in_node[vec] == 0 )
                q.push(vec);
        }
    }
}

signed main()
{
    f >> n >> m;
    for (int i=1; i<=m; i++ )
    {
        int x,y; f >> x >> y;
        gr[x].push_back(y);

        in_node[y]++;
    }

    sort_topo();

    for (int x:s )
        g << x << " ";
    return 0;
}
