#include <bits/stdc++.h>

using namespace std;

///SOL CU BFS

int n,m;
vector<int>graph[50005];
int degree[50005];
vector<int>sortare;
void bfs()
{
    queue<int>q;
    for(int i=1; i<=n; i++)
        if(!degree[i])
            q.push(i);
    while(!q.empty())
    {
        int nod=q.front();
        sortare.push_back(nod);
        q.pop();
        for(auto x: graph[nod])
        {
            degree[x]--;
            if(!degree[x])
                q.push(x);
        }
    }
}
int main()
{
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b;
        cin>>a>>b;
        graph[a].push_back(b);
        degree[b]++;
    }
    bfs();
    if(sortare.size()<n) ///e ciclu
    {
        cout<<"Ciclu!";
        return 0;
    }
    for(auto x: sortare)
        cout<<x<<" ";
    return 0;
}
