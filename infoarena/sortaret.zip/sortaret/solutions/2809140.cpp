#include<bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<vector>
#include<queue>
#include<bitset>
#include<stack>
#include<algorithm>
using namespace std;
///ifstream f("dfs.in");ofstream g ("dfs.out");
///ifstream f("bfs.in");ofstream g("bfs.out");
///ifstream f("biconex.in");ofstream g("biconex.out");
///ifstream f("ctc.in");ofstream g("ctc.out");
ifstream f("sortaret.in");ofstream g("sortaret.out");
///ifstream f("muchie.in");ofstream g("muchie.out");
    int verif[100001],low[100001],cost[100001],parent1[100001],rnk[100001];
    vector<int> distanta{vector<int>(100001, -1)};
    queue <int> coada;
    stack<int>stiva;
    vector <int> havel;
    vector<int> q[100001],w[100001],result[100001],parent[200001];
    vector <int> muchii[100001], componente[100001];
    pair <int, int> P[200001];

    struct Muchie{
    int x, y, cost;
}v[200001];
class graf{
private:
    int n, m, k, x, y,nods,counter=0, cont=0,Cost;


public:
    graf(){}
    graf (int n, int m)  ///constructor graf dfs / biconexe / muchie critica
    {
        this-> n = n;
        this-> m = m;

        for(int i=1; i<=m; i++){
            f>>x>>y;
            muchii[x].push_back(y);
            muchii[y].push_back(x);
        }
    }
    void dfsRez(){    /// rezolvare problema dfs
        for (int i=1;i<=n;i++){
            if (verif[i]!=true){
                counter++;
                dfs(i);
            }
        }
        g<<counter;
        }
    void dfs(int nod){    /// dfs simplu
        verif[nod]=true;
        for (int i=0; i<muchii[nod].size(); i++){
            int vecin = muchii[nod][i];
            if(verif[vecin]!=true)
                dfs(vecin);
        }
    }
    graf(int n, int m, int nods){ /// constructor graf bfs
        this-> n = n;
        this-> m = m;
        this->nods=nods;
        for(int i=1;i<=m;i++){
            f>>x>>y;
            muchii[x].push_back(y);
        }
    }
    void citireCTC(int n, int m){ ///citire CTC
        this-> n = n;
        this-> m = m;
        for(int i=1; i<=m;i++) {
        int x,y;
        f>>x>>y;
        q[x].push_back(y);
        w[y].push_back(x);
        }
    }
    void citireHavel(int n){  ///citire havel
        for (int i=0;i<n;i++){
                cin>>x;
                havel.push_back(x);
        }
    }
    void citireTOPSORT(int n, int m){  ///citire TOPSORT
        this-> n = n;
        this-> m = m;
        for (int i=1;i<=m;i++){
            int x,y;
            f>>x>>y;
            muchii[x].push_back(y);
        }
    }
    void bfs(){ ///bfs simplu
        int nod, vecin;
        while(!coada.empty())
        {
            nod=coada.front();
            coada.pop();
            for (int i= 0;i<muchii[nod].size();i++)
            {
                vecin = muchii[nod][i];
                if(distanta[vecin]==-1)
                {
                    coada.push(vecin);
                    distanta[vecin]=distanta[nod]+1;
                }
            }
        }
    }
    void bfsRez(){ /// rezolvare problema bfs
        distanta[nods]=0;
        coada.push(nods);
        bfs();
        for (int i=1;i<=n;i++){
            g<<distanta[i] <<" ";
        }

    }
    void biconexe(int nod,int parent){ ///biconexe
verif[nod]=true;
low[nod]=cost[nod]=cost[parent]+1;
stiva.push(nod);
for (int i=0;i<muchii[nod].size();i++){
    if (muchii[nod][i] != parent){
        if (verif[muchii[nod][i]])
            low[nod]=min(low[nod],cost[muchii[nod][i]]);
        else{
            biconexe(muchii[nod][i],nod);
            low[nod]=min(low[nod],low[muchii[nod][i]]);
            if (low[muchii[nod][i]]>=cost[nod]){
                cont++;
                while (stiva.top()!=muchii[nod][i]){componente[cont].push_back(stiva.top());stiva.pop();}
                componente[cont].push_back(muchii[nod][i]);stiva.pop();componente[cont].push_back(nod);
            }
        }
    }
}
}
    void biconexeRez(){ ///biconexe rezolvare
    for (int i=1;i<=n;i++)
        if (verif[i]==0)
            biconexe(i,0);
    g<<cont<<'\n';
    for (int i=1;i<=cont;i++){
        for (int j=componente[i].size()-1;j>=0;j--)
            g<< componente[i][j]<<" ";
        g<<'\n';
    }
}
    void dq(int nod){  ///ctc
    verif[nod]=1;
    for(int i=0; i<q[nod].size();i++){
        int vecin=q[nod][i];
        if(verif[vecin]==false)
            dq(vecin);
    }
    stiva.push(nod);
}
    void dw(int nod){  ///ctc
    verif[nod]=2;
    result[cont].push_back(nod);
    for(int i=0;i<w[nod].size();i++){
        int vecin=w[nod][i];
        if(verif[vecin]==1)
            dw(vecin);
    }
}
    void ctcRez(){ ///ctc
for(int i=1; i<=n; i++)
    if(!verif[i])
        dq(i);

while(!stiva.empty()){
    int nod = stiva.top();
    if(verif[nod] == 1){
        cont++;
        dw(nod);
    }
    stiva.pop();
}
g<<cont<<'\n';
for(int i=1; i<=cont;i++){
    for(int j=0; j < result[i].size(); j++)
        g<<result[i][j]<<' ';
    g<<'\n';
}
}
    void topsort(int nod){  ///topsort
    verif[nod]=true;
    for(int i=0;i<muchii[nod].size();i++){
        int vecin = muchii[nod][i];
            if (!verif[vecin])
                topsort(vecin);
   }
    stiva.push(nod);
}
    void topsortREZ(){ ///topsort
for(int i=1;i<=n;i++){
    if(!verif[i])
        topsort(i);
}
while(!stiva.empty()){
    g<<stiva.top()<<" ";
    stiva.pop();
}

}
    int checkHavel(){ /// havel check

    while (true){

        sort(havel.begin(), havel.end(), greater<>());

        if(havel[0]==0){
            cout<<"da";return 0;}
        int aux = havel[0];
        havel.erase(havel.begin() + 0);

        if (aux> havel.size()){
            cout<<"nu"; return 0;}

        for (int i= 0; i<aux;i++){
            havel[i]-=1;
        }
        for(auto i:havel)
            if(i <0)
                {
                    cout<<"nu";return 0;
                }
    }
}
void critica(int nod,int parent){ ///https://leetcode.com/problems/critical-connections-in-a-network/
parent1[nod]=parent;
verif[nod]=true;
low[nod]=cost[nod]=cost[parent]+1;
for (int i=0;i<muchii[nod].size();i++){
    if (muchii[nod][i] != parent){
        if (verif[muchii[nod][i]])
            low[nod]=min(low[nod],cost[muchii[nod][i]]);
        else{
            critica(muchii[nod][i],nod);
            low[nod]=min(low[nod],low[muchii[nod][i]]);
        }
    }
}
}

void CriticaREZ() ///https://leetcode.com/problems/critical-connections-in-a-network/
{
    for (int i=1;i<=n;i++)
        if (verif[i]==0)
            critica(i,0);
    int x=low[1];
    for(int i=2; i<=n;i++){
        if(low[i]>low[parent1[i]]){
                //cout<<i<<" "<<parent1[i];
            g<<parent1[i]<<" "<<i<<'\n';cont++;}
    }
}

int finder(int nod){  ///apm
    while (parent1[nod]!=nod)
        nod=parent1[nod];
    return nod;
}
void Unire(int x, int y){  ///apm
    if(rnk[x]<rnk[y])
        parent1[x]=y;
    if(rnk[x]>rnk[y])
        parent1[y]=x;
    if(rnk[x]==rnk[y]){
        parent1[x] = y;
        rnk[y]+=1;
    }
}
void APM(){   ///apm
    for(int i=1;i<=m;i++){
        int parentx=finder(v[i].x),parenty=finder(v[i].y);
        if(parentx!=parenty){
            Unire(parentx,parenty);
            k++;
            P[k].first=v[i].x;P[k].second=v[i].y;
            Cost+=v[i].cost;
        }
    }
}
bool comparator(Muchie a,Muchie b){  ///apm
    return a.cost<b.cost;
}
/*void APMRez(int n,int m){  ///apm
    this->m=m;
    this->n=n;
    for(int i=1;i<=m;i++)
        f>>v[i].x>>v[i].y>>v[i].cost;
sort(v+1,v+m+1,comparator);
    for(int i=1;i<=n;i++) {
        parent1[i]=i;
        rnk[i]=0;
    }
    APM();
    g<<Cost<<"\n";
    g<<n-1<<"\n";
    for(int i=1;i<=k;i++)
        g<<P[i].first<<" "<<P[i].second<<"\n";

    }*/
virtual ~graf(){}
};
int main()
{
    ///int n,m;f>>n>>m;graf g1(n,m);g1.dfsRez();     ///dfs 100p
    ///int n,m,nods; f>>n>>m>>nods; graf g1(n,m,nods); g1.bfsRez(); ///bfs 100p
    ///int n,m;f>>n>>m;graf g1(n,m);g1.biconexeRez(); ///biconexe 100p
    ///int n,m;f>>n>>m;graf g1;g1.citireCTC(n,m);g1.ctcRez(); /// Componente tare conexe 100p
    int n,m;f>>n>>m;graf g1; g1.citireTOPSORT(n,m);g1.topsortREZ(); ///Sortare Topologica 100p
    ///int n;cin>>n; graf g1; g1.citireHavel(n);g1.checkHavel(); ///Havel Hakimi
    ///int n,m;f>>n>>m; graf g1(n,m);g1.CriticaREZ();///https://leetcode.com/problems/critical-connections-in-a-network/
                ///In varianta mea trebuie introduse numarul de noduri si numarul de muchii la inceput.
    return 0;
}
