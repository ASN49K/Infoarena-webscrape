#include <fstream>
#include<vector>
#include<queue>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int degree[50005];
vector<int>priority[100005];
vector<int>order;
queue<int>q;
void make_it_topologica_order(int nod)
{
    while(!q.empty())
    {
        int CurrentNode=q.front();
        order.push_back(CurrentNode);
        q.pop();
        for(auto x:priority[CurrentNode])
        {
            degree[x]--;
            if(degree[x]==0)
            {
                q.push(x);
            }
        }


    }
}
int main()
{
    int n,m;
    fin>>n>>m;

        for(int j=1; j<=m; j++)
        {
            int x,y;
            fin>>x>>y;
            priority[x].push_back(y);
            degree[y]++;

        }
    int p=0;
    for(int i=1; i<=n; i++)
    {
        if(degree[i]==0)
        {
            p=i;
            q.push(i);
        }
    }
    make_it_topologica_order(p);
    for(auto x:order)
    {
        fout<<x<<" ";
    }
    return 0;
}
