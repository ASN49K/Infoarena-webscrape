#include <bits/stdc++.h>

#define vi vector<int>
#define pb push_back
#define mp make_pair
#define non(x) (x < n) ? x + n : x - n

using namespace std;

ifstream in("andrei.in");
ofstream out("andrei.out");

const int maxN = 200000;

int n, m;

vi g[maxN], r[maxN];

vi st;

bitset<maxN> used, comp;

void dfs(int u) {
  used[u] = 1;
  for (int &v : g[u]) {
    if (used[v] == 0) {
      dfs(v);
    }
  }
  st.pb(u);
}

void dfs2(int u) {
  used[u] = used[non(u)] = 0;
  comp[u] = 1;
  for (int &v : r[u]) {
    if (used[v] == 1) {
      dfs2(v);
    }
  }
}

void add(int u, int v) {
  int nu = non(u), nv = non(v);
  g[nv].pb(u);
  r[u].pb(nv);
  g[nu].pb(v);
  r[v].pb(nu);
}

int main() {
  in >> n >> m;
  for (int i = 0; i < m; i++) {
    int u, v, z;
    in >> u >> v >> z;
    u--; v--;
    if (z == 1) {
      add(non(u), non(v));
    } else if (z == 0) {
      add(u, v);
    } else {
      add(non(u), v);
      add(u, non(v));
    }
  }
  for (int i = 0; i < 2 * n; i++) {
    if (used[i] == 0) {
  //    dfs(i);
    }
  }
  reverse(st.begin(), st.end());
  for (int &u : st) {
    if (used[u] == 1 && used[non(u)] == 1) {
  //    dfs2(u);
    }
  }
  for (int i = 0; i < n; i++) {
    out << comp[i] << " ";
  }
  return 0;
}
