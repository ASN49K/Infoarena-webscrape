#include <bits/stdc++.h>

#define ll long long

using namespace std;

const int NMAX = 5e4 + 10;
int n, m;
vector<int> adj[NMAX];

bool viz[NMAX];
void top_sort(int nod, vector<int> &_v) {
    viz[nod] = true;
    for (auto u: adj[nod])
        if (!viz[u]) top_sort(u, _v);
    _v.push_back(nod);
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);

    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    vector<int> ans;
    top_sort(1, ans);
    reverse(ans.begin(), ans.end());
    for (auto x: ans)
        cout << x << ' ';
}