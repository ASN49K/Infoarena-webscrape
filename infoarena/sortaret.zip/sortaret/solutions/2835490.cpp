#include <bits/stdc++.h>

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

int const nMax = 5*1e4+5;

int n, m, i, j, x, y ;

vector <int> a[nMax];
vector <int> ans;
vector <int> deg(nMax);

queue <int> Q;

int main()
{
    fin >> n >> m;
    for(i = 1; i <=m; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
        deg[y]++;
    }

    for(i = 1; i <= n; i++)
        if(deg[i] == 0) Q.push(i);

    while(!Q.empty())
    {
        int X = Q.front();
        ans.push_back(X);
        Q.pop();
        for(i = 0; i < a[X].size(); i++)
        {
            int Y = a[X][i];
            deg[Y]--;
            if(deg[Y] == 0)
                Q.push(Y);
        }
    }
    for(i = 0; i < ans.size(); i++)
    {
        fout << ans[i] << " ";
    }
    return 0;
}
