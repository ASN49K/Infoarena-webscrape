#include <fstream>
#include <queue>
#include <vector>
#define INF 2000000001
using namespace std;
ifstream f("kanye");
ofstream g("skete");
vector <pair<int,int> > v[100011];
queue <int> q;
bool inqueue[100011];
int n,m,i,j,x,y,z,k,dist[100011],niter[100011],p;
int main()
{
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>z;
        v[x].push_back(make_pair(y,z));
    }
    for(i=1;i<=n;i++)
    {
        dist[i]=INF;
        niter[i]=1;
    }
    dist[1]=0;
    q.push(1);
    while(q.empty()==false)
    {
        k=q.front();
        q.pop();
        inqueue[k]=0;
        g<<v[k].size()<<'\n';
        for(i=0;i<v[k].size();i++)
            if(dist[v[k][i].first]>dist[k]+v[k][i].second)
            {
                dist[v[k][i].first]=dist[k]+v[k][i].second;
                if(inqueue[v[k][i].first]==0)
                {
                p=0;
                if(v[k][i].first<k)
                    p++;
                if(niter[k]+p<n)
                {
                    q.push(v[k][i].first);
                    niter[v[k][i].first]=niter[k]+p;
                    inqueue[v[k][i].first]=1;
                }
                }
            }
    }
    for(i=1;i<=n;i++)
        for(j=0;j<v[i].size();j++)
            if(dist[v[i][j].first]>dist[i]+v[i][j].second)
    {
        g<<"Ciclu negativ!";
        return 0;
    }
    for(i=2;i<=n;i++)
        g<<dist[i]<<" ";
    return 0;
}
