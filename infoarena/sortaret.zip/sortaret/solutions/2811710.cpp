#include <cstdio>
#include <iostream>
#include <vector>

#define NMAX 50005

using namespace std;

int n, m, spre[NMAX], pozAns;
vector<int> adj[NMAX], ans;

inline void vizitare(const int NOD) {
    for(const auto &el : adj[NOD]) {
        --spre[el];
        if(!spre[el]) ans.push_back(el);
    }
}

int main()
{
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
    scanf("%d%d", &n, &m);
    while(m--) {
        int x, y;
        scanf("%d%d", &x, &y);
        adj[x].push_back(y);
        spre[y]++;
    }
    for(int i = 1; i <= n; ++i)
        if(!spre[i]) ans.push_back(i);
    while(pozAns < ans.size()) {
        vizitare(ans[pozAns]);
        pozAns++;
    }
    for(const auto &el : ans) printf("%d ", el);
    return 0;
}
