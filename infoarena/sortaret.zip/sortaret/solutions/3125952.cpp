#include <iostream>
#include <vector>
#include <stack>

#define NMAX 200000

using namespace std;

void dfs(int visited[NMAX], int n, int node, vector<int> adj[NMAX], stack<int> &st) {
    
    visited[node] = 1;
    for (int i = 0; i < adj[node].size(); ++i) {
        if (visited[adj[node][i]] != 1) {
            dfs(visited, n, adj[node][i], adj, st);
        }
    }
    //cout << "am ajuns aici " << node << "\n";
    st.push(node);
}

int
main() {
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);
    int n, m;
    cin >> n >> m;
    vector<int> adj[n + 1];
    int nod1, nod2;
    for (int i = 0; i < m; ++i) {
        cin >> nod1 >> nod2;
        adj[nod1].push_back(nod2);
    }
    int visited[n + 1];
    for (int i = 1; i <= n; ++i) {
        visited[i] = 0;
    }
    stack<int> st;
    for (int i = 1; i <= n; ++i) {
        if (visited[i] == 0) {
            dfs(visited, n, i, adj, st);
        }
    }
    while (!st.empty()) {
        cout << st.top() << " ";
        st.pop();
    }
    return 0;
}