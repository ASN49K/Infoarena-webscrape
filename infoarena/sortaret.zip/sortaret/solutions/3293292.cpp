#include <bits/stdc++.h>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int grad[50001];
vector<int>v[50001];
queue<int>q;
int main()
{
    int n,m,st,dr;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>st>>dr;
        grad[dr]++;
        v[st].push_back(dr);
    }
    for(int i=1;i<=n;i++)
        if(!grad[i])
            q.push(i);
    int top;
    while(!q.empty())
    {
        top=q.front();
        q.pop();
        fout<<top<<' ';
        for(int i=0;i<v[top].size();i++)
        {
            grad[v[top][i]]--;
            if(!grad[v[top][i]])
                q.push(v[top][i]);
        }
    }
    return 0;
}
