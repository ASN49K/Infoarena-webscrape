#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;
FILE *fin, *fout;

#define NMAX 500


vector<int> graph[NMAX + 5];
bool viz[NMAX + 5];

int ind;

vector<int> v;

void dfs(int node)
{
    viz[node] = 1;

    for(int j = 0; j < graph[node].size(); j++)
        if(viz[graph[node][j]] == 0)
            dfs(graph[node][j]);

    v.push_back(node);
}

int main()
{
    fin = fopen("dfs.in", "r");
    fout = fopen("dfs.out", "w");

    int n, m;
    fscanf(fin, "%d%d", &n, &m);

    int i, x, y, j;
    for(i = 1; i <= m; i++)
    {
        fscanf(fin, "%d%d", &x, &y);

        graph[x].push_back(y);
    }

    /*for(i = 1; i <= n; i++)
        if(viz[i] == 0)
        {
            dfs(i);
        }
*/
    /*reverse(v.begin(), v.end());

    for(auto it : v)
        fprintf(fout, "%d ", it);

    fprintf(fout, "\n");*/

    fclose(fin);
    fclose(fout);
    return 0;
}
