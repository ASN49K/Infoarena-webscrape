#include <fstream>
#include <vector>
#include <stack>
#define MAXN 50000
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<int> g[MAXN + 1];
stack<int> vertices;
int visited_vertices[MAXN + 1];

void sortTopological(int currentVertex) {
    for (int &neighbour : g[currentVertex]) {
        if (!visited_vertices[neighbour]) {
            visited_vertices[neighbour] = 1;
            sortTopological(neighbour);
        }   
    }
    vertices.push(currentVertex);
}

int main() {
    int n, m, nodeA, nodeB;
    fin >> n >> m;
    for (int i = 0; i < m; ++i) {
        fin >> nodeA >> nodeB;
        g[nodeA].push_back(nodeB);
    }
    sortTopological(1);
    while (!vertices.empty()) {
        fout << vertices.top() << " ";
        vertices.pop();
    }
    return 0;
}