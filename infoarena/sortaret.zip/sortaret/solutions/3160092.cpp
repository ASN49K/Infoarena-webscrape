/**
 * Author: Andu Scheusan (not_andu)
 * Created: 22.10.2023 21:25:11
*/

#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "sortaret.in"
#define OUTFILE "sortaret.out"

#define all(x) (x).begin(), (x).end()
#define MP make_pair
#define F first
#define S second

typedef long long ll;

const int VMAX = 50000;

int n, m;
vector<int> adj[VMAX];
bool viz[VMAX];
vector<int> ans;

void dfs(int node){

    viz[node] = true;

    for(int to : adj[node]){
        if(!viz[to]){
            dfs(to);
        }
    }

    ans.push_back(node);

}

void solve(){

    cin >> n >> m;

    for(int i = 0; i < m; ++i){
        int node1, node2; cin >> node1 >> node2;
        adj[node1].push_back(node2);
    }

    for(int i = 1; i <= n; ++i){
        if(!viz[i]){
            dfs(i);
        }
    }

    for(int i = ans.size() - 1; i >= 0; --i){
        cout << ans[i] << " ";
    }

}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}