// !!! NEM HELYES< CSAK KIINDULO PONT VOLT !!!
#include <fstream>
#include <vector>

#define vecVec std::vector<std::vector<int>>
#define vecB std::vector<bool>

std::ofstream out("sortaret.out");

void dfs(vecVec &graf, vecB &visited, int s)
{
    out << s << ' ';
    visited[s] = true;
    for (auto elem : graf[s])
    {
        if (!visited[elem])
        {
            dfs(graf, visited, elem);
        }
    }
}

int main()
{
    int n, m;
    std::ifstream in("sortaret.in");
    in >> n >> m;

    vecVec graf(n + 1);
    while (m--)
    {
        int x, y;
        in >> x >> y;

        graf[x].push_back(y);
    }
    in.close();

    vecB visited(n + 1);
    dfs(graf, visited, 1);

    return 0;
}