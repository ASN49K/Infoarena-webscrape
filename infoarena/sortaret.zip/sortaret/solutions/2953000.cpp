#include <iostream>
#include <fstream>
#include <algorithm>
#include <queue>
#include <cstring>
#include <vector>
#include <map>
#include <cstdio>
#include <list>
//#include <bits/stdc++.h>
#include <stack>
#define fastio std :: ios_base :: sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
#define minim(a, b) ((a < b) ? a : b)
#define NMax 2000005
using namespace std;

int n, m, x, y;
std::vector <int> g[50010];
std::list <int> :: iterator it;
list <int> lista;
int viz[50010];

void dfs(int nod)
{
    viz[nod] = 1;
    for(auto it: g[nod])
        if(!viz[it])
            dfs(it);
    lista.push_front(nod);
}

int main(void)
{
    //header ->
    {
        fastio
        ios_base::sync_with_stdio(false);
        cin.tie(NULL);
        freopen("sortaret.in", "r", stdin);
        freopen("sortaret.out", "w", stdout);
    }

    //input ->
    {
        cin >> n >> m;
        for(int i = 1; i <= m; i++)
        {
            cin >> x >> y;
            g[x].push_back(y);
        }
    }

    //start of the program ->
    {
        for(int i = 1; i <= n; i++)
            if(!viz[i])
                dfs(i);
    }

    //output ->
    {
        for(it = lista.begin(); it != lista.end(); it++)
            cout << *it << ' ';
    }
    exit(0);
}
