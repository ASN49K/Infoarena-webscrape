#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<int> v[50002];
bool ok;
int grad[50002];
vector<int> ordine;
queue<int> coada;

void sortare()
{
    while (!coada.empty())
    {
        auto temp=coada.front();
        coada.pop();
        ordine.push_back(temp);
        for (auto y:v[temp])
        {
            grad[y]--;
            if (grad[y]==0)
            {
                coada.push(y);
            }
        }
    }
}

int main()
{
    int n,m,x,y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        grad[y]++;
        v[x].push_back(y);
    }
    for (int i = 1; i <= n; i++)
    {
        if (grad[i] == 0)
        {
            coada.push(i);
        }
    }
    sortare();
    for (auto e:ordine) fout << e << " ";
}
