#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n, m, i, j, gri[50005], x, y;
vector <int> v[50005];
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        gri[y]++;
    }
    queue <int> q;
    for(i=1; i<=n; i++)
        if(gri[i]==0)
            q.push(i);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        fout<<x<<" ";
        for(auto i: v[x])
        {
            gri[i]--;
            if(gri[i]==0)
                q.push(i);
        }
    }
    return 0;
}
