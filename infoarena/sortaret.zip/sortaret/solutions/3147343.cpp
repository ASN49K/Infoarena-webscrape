#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long 
#define ld long double
#define pii pair<int, int>
#define pll pair<ll, ll>
#define pb push_back
#define eb emplace_back

using namespace std;

signed main()
{
    #ifndef TEST 
        freopen("sortaret.in", "r", stdin);
        freopen("sortaret.out", "w", stdout);
    #endif
    ios_base :: sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    vector<vector<int>> g(n + 1);
    while (m--)
    {
        int u, v;
        cin >> u >> v;
        g[u].pb(v);
    }
    vector<int> topsort;
    vector<bool> visited(n + 1, false);
    function<void(int)> dfs = [&](int u)
    {
        topsort.pb(u);
        visited[u] = true;
        for (auto v : g[u])
        {
            if (!visited[v])
            {
                dfs(v);
            }
        }
    };
    for (int i = 1; i <= n; i++)
    {
        if (!visited[i])
        {
            dfs(i);
        }
    }
    for (auto it : topsort)
    {
        cout << it << ' ';
    }
    return 0;
}