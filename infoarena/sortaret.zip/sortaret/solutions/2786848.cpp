#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
vector<vector<int>> adj;
vector<int> nrp;
queue<int> q;
int a,b;
int main() {
    int n,m;
    in>>n>>m;
    adj.resize(n+1);
    nrp.resize(n+1,0);
    for(int i=1;i<=m;i++)
    {
        in>>a>>b;
        adj[a].push_back(b);
        nrp[b]++;
    }
    for(int i=1;i<=n;i++)
    {
        if(nrp[i]==0)
            q.push(i);
    }
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        out<<x<<" ";
        for(auto y:adj[x])
        {
            nrp[y]--;
            if(nrp[y]==0)
                q.push(y);
        }
    }
    return 0;
}