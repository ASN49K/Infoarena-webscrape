#include<iostream>
#include<fstream>
#include<vector>
#define NMAX 50005
using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n,m;
bool viz[NMAX];
vector<int> v[NMAX],collected;

void citire()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(y);
    }
}

void dfs(int node)
{
    viz[node] = true;
    for(int i=0;i<v[node].size();i++)
    {
        if(viz[v[node][i]] == false)
        {
            dfs(v[node][i]);
        }
    }
    collected.push_back(node);
}

void solve()
{
    for(int i=1;i<=n;i++)
    {
        if(viz[i] == 0)
        {
            dfs(i);
        }
    }
    for(int i=collected.size()-1;i>=0;i--)
        g<<collected[i]<<" ";
}

int main()
{
    citire();
    solve();
    dfs(1);
}