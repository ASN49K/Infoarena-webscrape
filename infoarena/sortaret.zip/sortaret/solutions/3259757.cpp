#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

int n , m, x, y, ind, drum[50003], viz[50003];

vector<int>a[50003];

void dfs(int nod)
{
    viz[nod] = 1;
    for(int i = 0; i < a[nod].size(); i++)
    {
        if(viz[a[nod][i]] == 0)
            dfs(a[nod][i]);
    }
    ind++;
    drum[ind] = nod;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
    }
    dfs(1); 
    for(int i = ind; i >= 1; i--)
        fout << drum[i] << " ";
    return 0;
}
