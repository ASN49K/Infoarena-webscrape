#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
#define NMAX 50005
int n, m, k, grd[NMAX];
int q[NMAX];
vector<int> G[NMAX];
int main()
{
    fin >> n >> m;
    for (int i=1;i<=n;i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        grd[y] ++;
    }

    for (int i=1;i<=n;i++){
        if (grd[i] == 0){
            k ++;
            q[k] = i;
        }
    }

    int p = 1, u = k;
    while(p <= u){
        int x = q[p];
        for (auto it : G[x]){
            grd[it] --;
            if (grd[it] == 0){
                u ++;
                q[++k] = it;
            }
        }
        p ++;
    }

    for (int i=1;i<=k;i++){
        fout << q[i] << ' ';
    }

    return 0;
}
