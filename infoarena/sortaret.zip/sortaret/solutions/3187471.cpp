#include <iostream>
#include <queue>
#include <fstream>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int main() { 

    int numar_noduri;
    int numar_arce;
    fin >> numar_noduri >> numar_arce;

    int noduri_grad_interne[numar_arce];
    int noduri_grad_externe[numar_arce];
    int grad_intern[numar_noduri];
    queue<int> coada_grad_zero;

    for (int i = 1; i <= numar_noduri; i++) {
        grad_intern[i] = 0;
    }

    for (int i = 1; i <= numar_arce; i++) {
        fin >> noduri_grad_externe[i];
        fin >> noduri_grad_interne[i];
        grad_intern[noduri_grad_interne[i]]++;
    }

    fin.close();

    for (int i = 1; i <= numar_noduri; i++) {
        if (grad_intern[i] == 0 ) 
            coada_grad_zero.push(i);   
    }

    while(!coada_grad_zero.empty()) {

        int nod_curent = coada_grad_zero.front();
        fout << nod_curent << " ";
        coada_grad_zero.pop();

        grad_intern[nod_curent] = -1;

        for (int i = 1; i <= numar_arce; i++) {
            if (noduri_grad_externe[i] == nod_curent) {
                grad_intern[noduri_grad_interne[i]]--;
            
                if (grad_intern[noduri_grad_interne[i]] == 0) 
                    coada_grad_zero.push(noduri_grad_interne[i]);
            }
        }        
    }

    fout << endl;

    fout.close();
    return 0;
}

