#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n,m;
const int nmax=50003;
vector<int> adj[nmax];
int grad[nmax];
vector<int> toposort;

inline void sortare_topologica()
{
    queue<int> q;
    for(int i=1; i<=n; i++)
    {
        if(grad[i] == 0) q.push(i);
    }
    //cerr<<q.size();
    while(!q.empty())
    {
        int i = q.front();
        q.pop();
        //cerr<<i<<" ";
        toposort.push_back(i);
        for(auto pi : adj[i])
        {
            grad[pi] --;
            if(grad[pi] == 0)
            {
                q.push(pi);
            }
        }
    }
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b;
        fin>>a>>b;
        adj[a].push_back(b);
        grad[b]++;
    }
    sortare_topologica();
    for(int i=0; i<n; i++) fout<<toposort[i]<<" ";
    return 0;
}
