#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <cstdlib>
#include <algorithm>
#include <map>
#define VMAX 50000
#define WHITE 0
#define GRAY 1
#define BLACK 2
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int V, E, x, y, timp;
vector <int> adj[VMAX];
int f[VMAX];
char color[VMAX];
vector < pair <int, int> > F(VMAX);
int contor;

void DFS_visit(int u)
{
    timp = timp + 1;
    color[u] = GRAY;
    for (auto w:adj[u])
        if (color[w] == WHITE) DFS_visit(w);
    timp = timp + 1;
    color[u] = BLACK;
    F[u] = make_pair(u, timp);
}

void DFS()
{
    timp = 0;
    contor = 0;
    for (int i = 0; i < V; ++i)
        if (color[i] == WHITE) DFS_visit(i);
}

int partitie(int v[], int st, int dr)
{
    int pivot = v[st + rand() % (dr - st + 1)];
    int i = st - 1, j = dr + 1, aux;

    while (1)
    {
        do
            i++;
        while (v[i] > pivot);
        do
            j--;
        while (v[j] < pivot);
        if (i >= j)
            return j;
        aux = v[i], v[i] = v[j], v[j] = aux;
    }
}

void qsort(int v[], int st, int dr)
{
    if (st < dr)
    {
        int pivot = partitie(v, st, dr);
        qsort(v, st, pivot);
        qsort(v, pivot + 1, dr);
    }
}

bool compare(pair <int, int> a, pair <int, int> b)
{
    return a.second > b.second;
}
int main()
{
    fin >> V >> E;

    for (int i = 0; i < E; ++i)
    {
        fin >> x >> y;
        x--, y--;
        adj[x].push_back(y);
    }

    DFS();

    sort(F.begin(), F.end(), compare);

    for (int i = 0; i < V; ++i)
        fout << F[i].first + 1 << " ";

    fin.close();
    fout.close();
    return 0;
}

