#include <bits/stdc++.h>

#define INF ((int)1e9)
#define NMAX ((int)5e4)

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

struct node_info {
    int t_st, t_fn;
    int node;
};

int n, m;
vector<int> a[NMAX + 1];
list<int> topo_sort;
bool vis[NMAX + 1];

void toposort(int node) {
    vis[node] = true;
    for (auto it = a[node].begin(); it != a[node].end(); ++it) {
        int next_node = *it;
        if (!vis[next_node]) {
            toposort(next_node);
        }
    }

    topo_sort.push_front(node);
}

int main(void) {
    fin >> n >> m;
    for (int i = 0; i < n; ++i) {
        int src, dest;
        fin >> src >> dest;
        a[src].push_back(dest);
    }

    fin.close();
    
    for (int i = 1; i <= n; ++i) {
        if (!vis[i]) {
            toposort(i);
        }
    }

    for (auto it = topo_sort.begin(); it != topo_sort.end(); ++it) {
        fout << *it << " ";
    }

    return 0;
}
