#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n,m,x,y;

vector<int> visited;
vector<vector<int>> adj;
vector<int> rez;

void dfs(int nod){
    visited[nod] = 1;
    for(auto& neigh: adj[nod]){
        if(visited[nod] == 0)
            dfs(nod);
    }
    rez.push_back(nod);
}

int main(){

    f >> n >> m;
    adj.resize(n+1);
    visited.assign(n+1,0);

    for(int i=1; i<=m; i++){
        f >> x >> y;
        adj[x].push_back(y);
    }
    
    for(int i=1; i<=n; i++){
        if(visited[i] == 0){
            dfs(i);
        }
    }
    for(auto& v: rez){
        g << v << " ";
    }

    return 0;
}