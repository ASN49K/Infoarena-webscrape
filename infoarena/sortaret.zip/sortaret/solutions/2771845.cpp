#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>

using uint = unsigned int;

uint viziteaza(bool *matriceAdiacenta, uint numarNoduri,
               std::vector<bool> &vizitat, std::vector<uint> &ordine,
               uint index, uint nod) {
  if (vizitat[nod] == true)
    return index;
  vizitat[nod] = true;

  for (size_t vecin = 0; vecin < numarNoduri; vecin++) {
    if (matriceAdiacenta[nod * numarNoduri + vecin] != false && !vizitat[vecin])
      index = viziteaza(matriceAdiacenta, numarNoduri, vizitat, ordine, index,
                        vecin);
  }

  ordine[index--] = nod;

  return index;
}

std::vector<uint> sortareTopologica(bool *matriceAdiacenta, uint numarNoduri) {
  std::vector<bool> vizitat(numarNoduri, false);
  std::vector<uint> ordine(numarNoduri, 0);
  uint index = numarNoduri - 1;

  for (size_t nod = 0; nod < numarNoduri; nod++) {
    if (!vizitat[nod])
      index =
          viziteaza(matriceAdiacenta, numarNoduri, vizitat, ordine, index, nod);
  }
  return ordine;
}

int main() {
  std::ifstream inFile;
  inFile.open("sortaret.in", std::ios::in);
  if (inFile.is_open()) {
    uint numarNoduri, numarMuchii;
    inFile >> numarNoduri >> numarMuchii;

    bool *matriceAdiacenta = new bool[numarNoduri * numarNoduri];

    for (uint i = 0; i < numarNoduri; i++) {
      for (uint j = 0; j < numarNoduri; j++) {
        matriceAdiacenta[i * numarNoduri + j] = false;
      }
    }
    for (uint muchie = 0; muchie < numarMuchii; muchie++) {
      uint x, y;
      inFile >> x >> y;
      matriceAdiacenta[(x - 1) * numarNoduri + y - 1] = true;
    }
    std::ofstream outFile;
    outFile.open("sortaret.out", std::ios::out);
    if (outFile.is_open()) {
      std::vector<uint> ordine =
          sortareTopologica(matriceAdiacenta, numarNoduri);
      for (auto elem : ordine)
        outFile << elem + 1 << " ";
      outFile << "\n";
      outFile.close();
    } else {
      std::cerr << "Nu s-a putut scrie in fisier!" << std::endl;
    }
    delete[] matriceAdiacenta;
    
  } else {
    std::cerr << "Nu am putut deschide fisierul!" << std::endl;
  }
  inFile.close();
  return 0;
}