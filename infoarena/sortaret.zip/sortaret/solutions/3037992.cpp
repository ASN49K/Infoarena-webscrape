#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int main()
{
  int n, m;
  fin >> n >> m;

  vector<vector<int>> graph(n + 1);

  for (int i = 1; i <= m; i++)
  {
    int x, y;
    fin >> x >> y;
    graph[x].push_back(y);
  }

  vector<int> vis(n + 1, 0), res;
  function<void(int)> dfs = [&](int node)
  {
    vis[node] = true;

    for (int next : graph[node])
      if (!vis[next])
        dfs(next);

    res.push_back(node);
  };

  for (int i = 1; i <= n; i++)
    if (!vis[i])
      dfs(i);

  reverse(res.begin(), res.end());
  for (int x : res)
    fout << x << " ";

  return 0;
}