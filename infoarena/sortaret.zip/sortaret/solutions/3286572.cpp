#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#define vt vector
#define pb push_back
#define sz(x) (int)(x).size()
#define all(x) (x).begin(), (x).end()

#define fr first 
#define sc second

using namespace std;

string filename = "sortaret";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

////////////////////////////////////////////////////////////

const int NMAX = 5e4;

vt <int> adj[NMAX + 1];

bool viz[NMAX + 1];

vt <int> topo;
void dfs(int node){
    viz[node] = 1;
    for(int vec : adj[node]){
        if(!viz[vec]){
            dfs(vec);
        }
    }
    topo.pb(node);
}

void solve(){
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        adj[a].pb(b);
    }

    //cout << "??\n";

    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            dfs(i);
        }
    }

    reverse(all(topo));
    for(int x : topo){
        fout << x << ' ';
    }
    fout << '\n';
}

int main(){

    int T;
    //fin >> T;

    T = 1;

    while(T--){
        solve();
    }

    return 0;
}