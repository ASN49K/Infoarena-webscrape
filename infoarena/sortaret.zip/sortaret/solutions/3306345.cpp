#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <iomanip>

using namespace std;

#define ll long long

int n, e;
unordered_map<int, vector<int>> deps;
// Global variables

void ReadData() {
    cin >> n >> e;
    int source, drain = 0;
    for(int i = 0; i < e; i ++){
        cin >> source >> drain;
        deps[source].push_back(drain);
    }

}

vector<int> findRoot(){
    set<int> parents;
    set<int> childs;
    for(const auto& val: deps){
        parents.insert(val.first);
        for(int x: val.second)
            childs.insert(x);
    }
    vector<int> currParents;

    for(int x: parents){
        if(childs.find(x) == childs.end()){
            currParents.push_back(x);
        }       
    }
    return currParents;
}

void Solve() {
    vector<int> parents = findRoot();
    while (!parents.empty()){
       int x = parents[0];
       cout << x << " ";
       for(int val: deps[x]){
        if(deps.find(val) == deps.end())
            cout << val << " ";
       }
       deps.erase(x);
       parents = findRoot();
    } 
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);

    int t = 1;
    // cin >> t; // Uncomment for multiple test cases
    while (t--) {
        ReadData();
        Solve();   
    }
    return 0;
}