#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

queue < int > coada;
vector < int > muchii[100001];
bool vizitat[100001];

void DFS(int nod) {
    vizitat[nod] = 1;
    coada.push(nod);
    for(int i = 0; i < muchii[nod].size(); ++i) {
        int vecin = muchii[nod][i];
        if (vizitat[vecin] == 0) {
            DFS(vecin);
        }
    }
}

void TS(int n) {
    for (int i = 1; i <= n; ++i) {
        if (vizitat[i] == 0) {
            DFS(i);
        }
    }
}


int main()
{
    int n, m, nodStart;
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        fin >> x >> y;
        muchii[x].push_back(y);
    }
    TS(n);
    while(coada.size() > 0) {
        fout << coada.front() << " ";
        coada.pop();
    }

    return 0;
}
