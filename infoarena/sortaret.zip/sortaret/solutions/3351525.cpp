#include<bits/stdc++.h>
using namespace std;

const int NMAX = 5e4 + 5;
int n, m;
vector<int> v[NMAX], ans;
bool viz[NMAX];

void dfs(int node);

int main() {
    freopen("sortaret.in", "r", stdin);
    freopen("sortaret.out", "w", stdout);

    cin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int a, b;
        cin >> a >> b;
        v[a].push_back(b);
    }

    for(int i = 1; i <= n; i++) {
        if(viz[i] == 0) {
            dfs(i);
        }
    }

    for(int i = ans.size() - 1; i >= 0; i--) 
        cout << ans[i] << " ";
}

void dfs(int node) {
    viz[node] = 1;
    for(auto u : v[node]) {
        if(viz[u] == 0) {
            dfs(u);
        }
    }

    ans.push_back(node);
}
