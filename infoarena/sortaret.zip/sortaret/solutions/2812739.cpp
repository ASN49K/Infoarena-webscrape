#include<fstream>
#include<vector>
#include<stack>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int n,m,i,u,v;
vector<int> adj[50004];
stack<int> s;
bool ver[50004];
void dfs(int x)
{
    ver[x]=1;
    for(int i=0;i<adj[x].size();i++)
    {
        int a=adj[x][i];
        if(ver[a]==0)
            dfs(a);
    }
    s.push(x);
}
void sortare()
{
    for(i=1;i<=n;i++)
    {
        if(ver[i]==0)
            dfs(i);
    }
    while(!s.empty())
    {
        fout<<s.top()<<" ";
        s.pop();
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>u>>v;
        adj[u].push_back(v);
    }
    sortare();
    return 0;
}

