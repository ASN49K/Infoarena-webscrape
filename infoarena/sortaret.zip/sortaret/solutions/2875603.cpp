#include <bits/stdc++.h>
#include <chrono>

using namespace std;
const int NR = 1e5 + 10;

set<int> in_degree[NR];
set<int> out_degree[NR];
int n, m;
bool alreadyChecked[NR];

struct cmp {
    bool inline operator()(const int i, const int j) {
        return in_degree[i].size() > in_degree[j].size();
    }
};

priority_queue<int, vector<int>, cmp> pq;
vector<int> sortTop;
ifstream in("sortaret.in");
ofstream out("sortaret.out");

signed main() {
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; ++i) {
        in >> x >> y;
        out_degree[x].insert(y);
        in_degree[y].insert(x);
    }
    for (int i = 1; i <= n; ++i) {
        pq.push(i);
    }
    while (!pq.empty()) {
        int nod = pq.top();
        pq.pop();
        if (alreadyChecked[nod]) {
            continue;
        }
        if (in_degree[nod].empty()) {
            continue;
        }
        alreadyChecked[nod] = true;
        sortTop.emplace_back(nod);
        for (auto it : out_degree[nod]) {
            in_degree[it].erase(nod);
            if (in_degree[it].empty()) {
                pq.push(it);
            }
        }
    }
    for (auto it : sortTop) {
        out << it << ' ';
    }
    return 0;
}