#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
queue <int> q;
vector <int> g[50005];
int gr[50005];
int main()
{
    int n,m,i,j;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        gr[y]++;
    }
    for(i=1;i<=n;i++)
        if(gr[i]==0)
        q.push(i);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        cout<<x<<' ';
        for(auto next:g[x])
        {
            gr[next]--;
            if(!gr[next])
                q.push(next);
        }
    }
    return 0;
}
