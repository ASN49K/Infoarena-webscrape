#include <bits/stdc++.h>
using namespace std;
/*
 https://infoarena.ro/problema/sortaret
*/
const int N=50005;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;
vector<int> g[N];

vector<int> st;


void dfs(int x){
    static bool v[N]={0};
    if(v[x]!=0) return ;
    v[x]=1;
    for(int y:g[x]){
        dfs(y);
    }
    st.push_back(x);
}

int main(){
    fin>>n>>m;
    for(int i=1;i<=m;++i){
        int x,y;
        fin>>x>>y;
        g[x].push_back(y);
    }
    for(int i=1;i<=n;++i){
        dfs(i);
    }
    for(int i=st.size()-1; i>=0; --i){
        fout<<st[i]<<" ";
    }
}
