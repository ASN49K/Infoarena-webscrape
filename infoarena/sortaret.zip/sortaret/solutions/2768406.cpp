#include<bits/stdc++.h>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector<int>a[100002];
bool viz[100002];
int sol[50001],k;

void dfs(int x)
{
    viz[x]=1;
    for(auto y:a[x])
    if(viz[y]==0)
        dfs(y);
    sol[++k]=x;
}

int main()
{
    int n,m,i,x,y;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x].push_back(y);
    }
    for (i=1;i<=n;i++) if (viz[i]==0) dfs(i);
    for (i=k;i>=1;i--) g<<sol[i]<<' ';
    return 0;
}
