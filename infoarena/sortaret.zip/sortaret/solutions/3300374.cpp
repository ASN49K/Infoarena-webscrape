#include <bits/stdc++.h>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
queue<int>q;
vector<int>v[50002];
int n,m,x,y,fr[50002];
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        fr[y]++;
    }
    for(int i=1;i<=n;i++)
        if(fr[i]==0){q.push(i);fout<<i<<' ';}

    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        for( auto next:v[node])
        {
            fr[next]--;
            if(fr[next]==0){q.push(next);fout<<next<<' ';}
        }

    }
    return 0;
}
