#include <bits/stdc++.h>
#define pb push_back
#define FILES freopen("sortaret.in","r",stdin);\
              freopen("sortaret.out","w",stdout);
#define MAX 50000
#define fastio ios_base::sync_with_stdio(NULL),cin.tie(NULL),cout.tie(NULL);
using namespace std;
int n,m,a,b,grad[MAX+5];
vector<int>v[MAX+5];
queue<int>q;
int main()
{
    fastio
    FILES
    cin >> n >> m;
    for(int i = 1;i <= m; ++i)
    {
        cin >> a >> b;
        v[a].pb(b),grad[b]++;
    }
    for(int i = 1;i <= n; ++i)
        if(!grad[i]) q.push(i);
    while(!q.empty())
    {
        int x = q.front();
        q.pop();
        cout << x << ' ';
        for(auto i : v[x])
        {
            grad[i]--;
            if(!grad[i]) q.push(i);
        }
    }
}
