#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
vector <int > G[50005];
int n,m,x,y,vis[50005];
void dfs(int k)
{ vis[k]=1;
for(int i : G[k])
{
    if(!vis[i])
        dfs(i);
}
g<<k<<" ";
}
int main()
{f>>n>>m;
for(int i=1;i<=m;++i)
{
f>>x>>y;
    G[y].push_back(x);
}
for(int i=1;i<=n;++i)
{
    if(!vis[i])
        dfs(i);
}
    return 0;
}
