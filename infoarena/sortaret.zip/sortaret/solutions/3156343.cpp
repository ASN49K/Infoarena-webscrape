#include <fstream>
#include <set>

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n,m,viz[50001],nr,ans[50001];
set<int, greater<int>> a[50001];

void dfs(int nod)
{
    int i;
    viz[nod]=1;
    for(set<int>::iterator it=a[nod].begin(); it!=a[nod].end(); it++)
    {
     if(viz[*it]==0)
     {
      dfs(*it);
     }
    }
    nr++;
    ans[nr]=nod;

}

int main()
{
    int i,x,y;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
     f>>x>>y;
     a[x].insert(y);
    }
    nr=0;
    for(i=n;i>=1;i--)
    {
     if(viz[i]==0)
     {
      dfs(i);
     }
    }
    for(i=n;i>=1;i--)
    {
     g<<ans[i]<<" ";
    }
    return 0;
}
