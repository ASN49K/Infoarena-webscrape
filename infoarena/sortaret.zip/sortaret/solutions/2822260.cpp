#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <algorithm>
using namespace std;

class graph{

    int n, m, sum;
    const int INF= (1<<30);
    vector < vector < int > > G, reverseG;
    stack < int > s;

    struct muchie
    {
        int left, right, cost;
    };

    struct comp
    {
        inline bool operator() (const muchie& a, const muchie& b)
        {
            return a.cost < b.cost;
        }
    };

public:

    graph(int n, int m);

    int get_n()
    {
        return n;
    }

    void readGraph(vector < vector < int > > Ad);

    void dfs(int node, vector < int > &vis);
    int connectedComponents();
    vector < int > minimumDistance(int source);

    void dfsSccDirect(int node, vector < int > &vis, stack < int > &scc);
    void dfsSccReverse(int node, vector < int > &vis2, vector < vector < int > > &sol, int ct);
    vector < vector < int > > scc();
    void dfsTopo(int node, vector < int > &vis);
    vector < int > topologicalSort();

    void dfsBiconnected(int node, int dad, vector < int > low, vector < int > level, vector < int > &vis, vector < vector < int > > &sol, int ct);
    vector < vector < int > > biconnectedComponents();
    void dfsCriticalConnections(int node, int dad, vector < int > low, vector < int > level, vector < int > &vis, vector < vector < int > > &sol, int ct);
    vector<vector<int>> criticalConnections(int nr, vector<vector<int>>& connections);

    int find(int val, vector < int > mult);
    void unionDisjoint(int a, int b, vector < int > mult, vector < int > sz);
    vector < int > disjoint(vector < vector < int > > input);

    int apm(vector < muchie > apmList, vector < pair < int, int > > &solApm);

    bool hakimi(vector < int > grades);

    vector < int > dijkstra(vector < vector < pair < int, int > > > G);

    vector < int > bellmanFord(vector < vector < pair < int, int > > > G);

    vector < vector < int > > royFloyd(vector < vector < int > > inputMatrix);

    int bfsFlow(vector < int > &parent, vector < vector < int > > &rez, vector < vector < int > > &adj);

    int maxFlow(vector < vector < pair < int, int > > > G);

    int bfsDiam(int first, int &last, vector < vector < int > > G);
    int diam(vector < vector < int > > G);

    void euler(int node, vector < vector < pair < int, int > > > e, vector < int > f, vector < int > &sol);
    vector < int > solveEuler(vector < vector < pair < int, int > > > e);

    int hamilton(vector < vector < pair < int, int > > > Ad);

    vector < pair < int, int > > cuplaj(vector < vector < int > > G);
    int dfsCuplaj(int node, vector < vector < int > > G, vector<int> &vis, vector<int> &left, vector<int> &right);

};

graph :: graph(int n, int m)
{
    this->n = n;
    this->m = m;
}

int graph :: connectedComponents()
{
    int x, y, ct = 0;
    vector < int > vis;

    vis.resize(n + 1, false);

    for(int i = 1; i <= n; ++i)
        if(vis[i] == 0)
        {
            ++ct;
            dfs(i, vis);
        }

    return ct;
}

void graph :: dfs(int node, vector < int > &vis)
{
    vis[node] = 1;

    for(int i = 0; i < G[node].size(); ++i)
    {
        int nnode = G[node][i];

        if(vis[nnode] == 0)
            dfs(nnode, vis);
    }
}

vector < int > graph :: minimumDistance(int source)
{
    vector < int > nodes;
    queue < int > bfsQueue;

    nodes.resize(n + 1, -1);

    bfsQueue.push(source);
    nodes[source] = 0;

    while(!bfsQueue.empty())
    {
        int node = bfsQueue.front();
        bfsQueue.pop();

        for(int i = 0; i < G[node].size(); ++i)
        {
            int nnode = G[node][i];
            if(nodes[nnode] == -1)
            {
                nodes[nnode] = nodes[node] + 1;
                bfsQueue.push(nnode);
            }
        }
    }

    return nodes;
}

void graph :: dfsBiconnected(int node, int dad, vector < int > low, vector < int > level, vector < int > &vis, vector < vector < int > > &sol, int ct)
{
    vis[node] = 1;
    level[node] = level[dad] + 1;
    low[node] = level[node];
    stack < int > biconnected;

    for(int i = 0; i < G[node].size(); ++i)
    {
        int nnode = G[node][i];

        if(nnode != dad)
        {
            if(vis[nnode] == 1)
            {
                if(level[nnode] < low[node])
                    low[node] = level[nnode];
            }
            else
            {
                biconnected.push(nnode);

                dfsBiconnected(nnode, node, low, level, vis, sol, ct);

                if(low[nnode] < low[node])
                    low[node] = low[nnode];

                if(level[node] <= low[nnode])
                {
                    ++ct;

                    biconnected.push(node);

                    while(!biconnected.empty() && biconnected.top() != nnode)
                    {
                        sol[ct - 1].push_back(biconnected.top());
                        biconnected.pop();
                    }

                    if(!biconnected.empty())
                    {
                        sol[ct - 1].push_back(biconnected.top());
                        biconnected.pop();
                    }
                }
            }
        }
    }
}

vector < vector < int > > graph :: biconnectedComponents()
{
    int x, y, ct;

    vector < vector < int > > sol;
    vector < int > level, low, vis;

    G.resize(n + 1);
    sol.resize(n + 1);
    level.resize(n + 1, 0);
    low.resize(n + 1, 0);
    vis.resize(n + 1, false);

    ct = 0;

    dfsBiconnected(1, 0, low, level, vis, sol, ct);

    return sol;
}

void graph :: dfsSccDirect(int node, vector < int > &vis, stack < int > &scc)
{
    vis[node] = 1;

    for(int i = 0; i < G[node].size(); ++i)
    {
        int nnode = G[node][i];

        if(vis[nnode] == 0)
            dfsSccDirect(nnode, vis, scc);
    }

    scc.push(node);
}

void graph :: dfsSccReverse(int node, vector < int > &vis2, vector < vector < int > > &sol, int ct)
{
    vis2[node] = 1;
    sol[ct - 1].push_back(node);

    for(int i = 0; i < reverseG[node].size(); ++i)
    {
        int nnode = reverseG[node][i];

        if(vis2[nnode] == 0)
            dfsSccReverse(nnode, vis2, sol, ct);
    }
}


vector < vector < int > > graph :: scc()
{
    int x, y, ct;
    vector < vector < int > > sol;
    vector < int > vis, vis2;
    stack < int > scc;

    reverseG.resize(n + 1);
    sol.resize(n + 1);
    vis.resize(n + 1, false);
    vis2.resize(n + 1, false);

    for(int i = 1; i <= n; ++i)
        for(int j = 0; j < G[i].size(); ++j)
            reverseG[G[i][j]].push_back(i);

    for(int i = 1; i <= n; ++i)
        if(vis[i] == 0)
            dfsSccDirect(i, vis, scc);

    ct = 0;

    while(!scc.empty())
    {
        int node = scc.top();
        scc.pop();

        if(vis2[node] == 0)
        {
            ++ct;
            dfsSccReverse(node, vis2, sol, ct);
        }
    }

    return sol;
}

void graph :: dfsTopo(int node, vector < int > &vis)
{
    vis[node] = 1;

    for(int i = 0; i < G[node].size(); ++i)
    {
        int nnode = G[node][i];

        if(vis[nnode] == 0)
            dfsTopo(nnode, vis);
    }

    s.push(node);
}


vector < int > graph :: topologicalSort()
{
    int x, y;
    vector < int > vis;
    stack < int > topo;
    vector < int > sol;

    vis.resize(n + 1, false);

    for(int i = 1; i <= n; ++i)
        if(vis[i] == 0)
            dfsTopo(i, vis);

    while(!s.empty())
    {
        int node = s.top();
        s.pop();

        sol.push_back(node);
    }

    return sol;
}

void graph :: dfsCriticalConnections(int node, int dad, vector < int > low, vector < int > level, vector < int > &vis, vector < vector < int > > &sol, int ct)
{
    vis[node] = 1;
    if(dad == -1) level[node] = 1;
    else level[node] = level[dad] + 1;
    low[node] = level[node];

    for(int i = 0; i < G[node].size(); ++i)
    {
        int nnode = G[node][i];

        if(nnode != dad)
        {
            if(vis[nnode] == 1)
            {
                if(level[nnode] < low[node])
                    low[node] = level[nnode];
            }
            else
            {
                dfsCriticalConnections(nnode, node, low, level, vis, sol, ct);

                if(low[nnode] < low[node])
                    low[node] = low[nnode];

                if(level[node] < low[nnode])
                {
                    ++ct;
                    sol.push_back({node, nnode});
                }
            }
        }
    }
}

vector<vector<int>> graph :: criticalConnections(int nr, vector<vector<int>>& connections)
{
    int ct;
    n = nr;
    ct = 0;

    vector < vector < int > > G, sol;
    vector < int > level, low, vis;

    G.resize(n + 1);
    level.resize(n + 1, 0);
    low.resize(n + 1, 0);
    vis.resize(n + 1, false);

    for(int i = 0; i < connections.size(); ++i)
    {
        int x = connections[i][0];
        int y = connections[i][1];
        G[x].push_back(y);
        G[y].push_back(x);
    }

    dfsCriticalConnections(0, -1, low, level, vis, sol, ct);

    return sol;
}

int graph :: find(int val, vector < int > mult)
{
    int root = val, aux;

    while(mult[root] != root)
        root = mult[root];

    while(mult[val] != root)
    {
        aux = mult[val];
        mult[val] = root;
        val = aux;
    }
    return root;
}

void graph :: unionDisjoint(int a, int b, vector < int > mult, vector < int > sz)
{
    int rootA, rootB;

    rootA = find(a, mult);
    rootB = find(b, mult);

    if(sz[rootA] < sz[rootB])
    {
        sz[rootB] += sz[rootA];
        mult[rootA] = rootB;
    }
    else
    {
        sz[rootA] += sz[rootB];
        mult[rootB] = rootA;
    }
}

vector < int > graph :: disjoint(vector < vector < int > > input)
{
    int task, x, y;
    vector < int > mult, sz, sol;

    mult.resize(n + 1, 0);
    sz.resize(n + 1, 1);

    for(int i = 1; i <= n; ++i)
        mult[i] = i;

    for(int i = 0; i < m; ++i)
    {
        task = input[i][0];
        x = input[i][1];
        y = input[i][2];

        if(task == 1)
        {
            unionDisjoint(x, y, mult, sz);
        }
        else
        {
            int root1 = find(x, mult);
            int root2 = find(y, mult);

            if(root1 == root2) sol.push_back(1);
            else sol.push_back(0);
        }
    }

    return sol;
}

int graph :: apm(vector < muchie > apmList, vector < pair < int, int > > &solApm)
{
    int m;
    vector < int > mult, sz;

    mult.resize(n + 1, 0);
    sz.resize(n + 1, 1);
    apmList.resize(m + 1);

    for(int i = 1; i <= n; ++i)
        mult[i] = i;

    sort(apmList.begin(), apmList.end() - 1, comp());

    sum = 0;

    for(int i = 0; i < m; ++i)
    {
        int a = apmList[i].left;
        int b = apmList[i].right;

        int rootA = find(a, mult);
        int rootB = find(b, mult);

        if(rootA != rootB)
        {
            unionDisjoint(a, b, mult, sz);
            solApm.push_back(make_pair(a, b));
            sum += apmList[i].cost;
        }
    }

    return sum;
}

vector < int > graph :: dijkstra(vector < vector < pair < int, int > > > G)
{
    int m, x, y, c, node, nnode;

    vector < int > vis, dist;
    stack < pair < int, int > > s;

    G.resize(n + 1);
    dist.resize(n + 1, INF);
    vis.resize(n + 1, 0);

    dist[1] = 0;
    s.push({0, 1});

    while(!s.empty())
    {
        node = s.top().second;
        c = s.top().first;
        s.pop();

        if(vis[node] == 1) continue;
        else vis[node] = 1;

        for(int i = 0; i < G[node].size(); ++i)
        {
            nnode = G[node][i].first;

            if(dist[nnode] > G[node][i].second + c)
            {
                dist[nnode] = G[node][i].second + c;
                s.push({dist[nnode], nnode});
            }
        }
    }

    for(int i = 2; i <= n; ++i)
        if(dist[i] == INF) dist[i] = 0;

    return dist;
}

vector < int > graph :: bellmanFord(vector < vector < pair < int, int > > > G)
{
    int x, y, c, source, dest;

    vector < int > dist, vis, nr;
    queue < int > q;

    G.resize(n + 1);
    dist.resize(n + 1, INF);
    vis.resize(n + 1, 0);
    nr.resize(n + 1, 0);

    dist[1] = 0;
    q.push(1);
    vis[1] = 1;

    while(!q.empty())
    {
        source = q.front();
        q.pop();
        vis[source] = 0;
        nr[source]++;

        if(nr[source] == n)
        {
            dist.clear();
            dist.push_back(-1);
            return dist;
        }

        for(int i = 0; i < G[source].size(); ++i)
        {
            dest = G[source][i].first;
            c = G[source][i].second;

            if(dist[source] + c < dist[dest])
            {
                dist[dest] = dist[source] + c;

                if(vis[dest] == 0)
                {
                    vis[dest] = 1;
                    q.push(dest);
                }
            }
        }

    }

    return dist;
}

vector < vector < int > > graph :: royFloyd(vector < vector < int > > inputMatrix)
{
    vector < vector < int > > matrix;

    matrix.resize(n + 1);

    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            matrix[i].push_back(INF);

        matrix[i][i] = 0;
    }

    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
        {
            if(inputMatrix[i][j]) matrix[i][j] = inputMatrix[i][j];
        }

    for(int k = 1; k <= n; ++k)
        for(int i = 1; i <= n; ++i)
            for(int j = 1; j <= n; ++j)
                if((1LL * matrix[i][k] + 1LL * matrix[k][j]) < matrix[i][j])
                    matrix[i][j] = matrix[i][k] + matrix[k][j];

    return matrix;
}

bool graph :: hakimi(vector < int > grades)
{
    int x;

    for(int i = 0; i < n; ++i)
        sum += grades[x];

    if(sum % 2 == 1)
        return 0;

    for(int i = 0; i < n; ++i)
        if(grades[i] > n - 1)
            return 0;

    sort(grades.begin(), grades.end(), greater <int> ());

    while(grades[0])
    {
        for(int i = 1; i <= grades[0]; ++i)
        {
            --grades[i];

            if(grades[i] < 0)
                return 0;
        }

        grades[0] = 0;
        sort(grades.begin(), grades.end(), greater <int> ());
    }

    return 1;
}

int graph :: bfsDiam(int first, int &last, vector < vector < int > > G)
{
    int diam;
    queue < int > bfs;
    vector < int > counter, vis;
    counter.resize(n + 1, 0);
    vis.resize(n + 1, 0);
    bfs.push(first);
    vis[first] = 1;
    counter[first] = 1;

    while(!bfs.empty())
    {
        int node = bfs.front();
        bfs.pop();

        for(int i = 0; i < G[node].size(); ++i)
        {
            int nnode = G[node][i];

            if(vis[nnode] == 0)
            {
                vis[nnode] = 1;
                counter[nnode] = counter[node] + 1;
                bfs.push(nnode);
                diam = counter[nnode];
                last = nnode;
            }
        }
    }

    return diam;
}

int graph :: diam(vector < vector < int > > G)
{
    int x, y, last, llast;

    int val = bfsDiam(1, last, G);
    int diam = bfsDiam(last, llast, G);

    return diam;
}

int graph :: bfsFlow(vector < int > &parent, vector < vector < int > > &rez, vector < vector < int > > &adj)
{
    queue < int > bfs;
    parent.assign(n + 1, -1);

    bfs.push(1);
    parent[1] = 0;

    while(!bfs.empty())
    {
        int node = bfs.front();
        bfs.pop();

        for(int i = 0; i < adj[node].size(); ++i)
        {
            int nnode = adj[node][i];

            if(parent[nnode] == -1 && rez[node][nnode])
            {
                parent[nnode] = node;
                bfs.push(nnode);
            }
        }
    }

    return parent[n];
}

int graph :: maxFlow(vector < vector < pair < int, int > > > G)
{
    int x, y, c, flow = 0;

    vector < int > parent;
    vector < vector < int > > rez;
    vector < vector < int > > adj;

    G.resize(n + 1);
    rez.resize(n + 1);
    adj.resize(n + 1);

    for(int i = 1; i <= n; ++i)
        rez[i].resize(n + 1, 0);

    for(int i = 1; i <= n; ++i)
        for(int j = 0; j < G[i].size(); ++j)
        {
            int node = G[i][j].first;
            rez[i][node] = G[i][j].second;
        }

    for(int i = 1; i <= n; ++i)
        for(int j = 0; j < G[i].size(); ++j)
        {
            int node = G[i][j].first;

            adj[i].push_back(node);
            adj[node].push_back(i);
        }

    while(bfsFlow(parent, rez, adj) != -1)
    {
        for(int i = 0; i < adj[n].size(); ++i)
        {
            int nnode = adj[n][i];

            if(nnode != -1)
            {
                int node = nnode;
                int ant;
                int newFlow = rez[node][n];

                while(node != 1)
                {
                    ant = parent[node];
                    newFlow = min(newFlow, rez[ant][node]);
                    node = ant;
                }

                node = nnode;
                rez[node][n] -= newFlow;
                rez[n][node] += newFlow;

                while(node != 1)
                {
                    ant = parent[node];
                    rez[ant][node] -= newFlow;
                    rez[node][ant] += newFlow;
                    node = ant;
                }

                flow += newFlow;
            }
        }
    }

    return flow;
}

void graph :: euler(int node, vector < vector < pair < int, int > > > e, vector < int > f, vector < int > &sol)
{
    while(e[node].size())
    {
        int nnode = e[node].back().first;
        int nr = e[node].back().second;
        e[node].pop_back();

        if(f[nr] == 0)
        {
            f[nr] = 1;
            euler(nnode, e, f, sol);
        }
    }

    sol.push_back(node);
}

vector < int > graph :: solveEuler(vector < vector < pair < int, int > > > e)
{
    int x, y;

    vector < int > sol, f;

    f.resize(m + 5, 0);
    e.resize(n + 1);

    for(int i = 1; i <= n; ++i)
        if(e[i].size() % 2 == 1)
        {
            sol.push_back(-1);
            return sol;
        }

    euler(1, e, f, sol);

    sol.pop_back();

    return sol;
}

int graph :: hamilton(vector < vector < pair < int, int > > > Ad)
{
    int x, y, c, sol = INF;

    int aux = (1 << n);
    int cost[aux][n];

    for(int i = 0; i < aux; ++i)
        for(int j = 0; j < n; ++j)
            cost[i][j] = INF;

    cost[1][0] = 0;

    for(int i = 0; i < aux; ++i)
        for(int j = 0; j < n; ++j)
            if((i & (1 << j)))
                for(int k = 0; k < Ad[j].size(); ++k)
                    if(i & (1 << Ad[j][k].first))
                        cost[i][j] = min(cost[i][j], cost[i ^ (1 << j)][Ad[j][k].first] + Ad[j][k].second);

    for(int i = 0; i < Ad[0].size(); ++i)
        sol = min(sol, cost[aux - 1][Ad[0][i].first] + Ad[0][i].second);

    return sol;
}

int graph :: dfsCuplaj(int node, vector < vector < int > > G, vector<int> &vis, vector<int> &left, vector<int> &right)
{
    if(vis[node] == 1) return 0;

    vis[node] = 1;

    for(int i = 0; i < G[node].size(); ++i)
        if (!right[G[node][i]] || dfsCuplaj(right[G[node][i]], G, vis, left, right))
        {
            right[G[node][i]] = node;
            left[node] = G[node][i];
            return 1;
        }

    return 0;
}

vector < pair < int, int > > graph :: cuplaj(vector < vector < int > > G)
{
    int e, x, y;
    vector < pair < int, int > > sol;
    vector < int > vis;

    G.resize(n + 1);
    vis.resize(n + 1, 0);
    vector < int > left(10001, 0), right(10001, 0);

    bool ok = 1;

    while(ok == 1)
    {
        ok = 0;
        for(int i = 0; i <= n; ++i)
            vis[i] = 0;

        for(int i = 1; i <= n; ++i)
            if(left[i] == 0 && dfsCuplaj(i, G, vis, left, right) == 1)
                ok = 1;
    }

    for (int i = 1; i <= n; ++i)
        if (left[i] != 0)
            sol.push_back(make_pair(i, left[i]));

    return sol;
}

void graph :: readGraph(vector < vector < int > > Ad)
{
    G.resize(n + 1);

    for(int i = 1; i <= n; ++i)
        for(int j = 0; j < Ad[i].size(); ++j)
            G[i].push_back(Ad[i][j]);
}

//Use this structure for apm input

/*struct muchie
{
    int left, right, cost;
};*/


int main()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");

    int n, m, x, y, source;

    in >> n >> m;

    graph G(n, m);

    vector < vector < int > > Ad;

    Ad.resize(n + 1);

    for(int i = 1; i <= m; ++i)
    {
        in >> x >> y;
        Ad[x].push_back(y);
        Ad[y].push_back(x);
    }

    G.readGraph(Ad);

    vector < int > sol = G.topologicalSort();

    for(int i = 0; i < sol.size(); ++i)
        out << sol[i] << " ";

    return 0;
}
