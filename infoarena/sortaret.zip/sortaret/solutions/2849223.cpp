#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");
int n,i,j,gi[100005],st,dr,depus,m,x,y,nod,capat;
int coada[100005],rez[100005],cate[100005];
vector <int> liste[100005];
void solve()
{
    st=1,dr=0;
    for(int i=1;i<=n;i++)
    {
        if(gi[i]==0)
        {
            dr++;
            coada[dr]=i;
        }
    }
    for(int i=1;i<=n;i++)
    {
        nod=coada[i];
        for(int j=0;j<=cate[nod]-1;j++)
        {
            capat=liste[nod][j];
            gi[capat]--;
            if(gi[capat]==0)
            {
                dr++;
                coada[dr]=capat;
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        liste[x].push_back(y);
        cate[x]++;
        gi[y]++;
    }
    solve();
    for(i=1;i<=n;i++)
    {
        fout<<coada[i]<<' ';
    }
    return 0;
}
