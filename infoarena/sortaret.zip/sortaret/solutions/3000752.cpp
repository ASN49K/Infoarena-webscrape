#include <fstream>
#define dim 10005
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
int a[2][100005], start[dim], grad[dim], c[dim], viz[dim], n, m, pi;
void df(int nod);
int main()
{
    int i, x;
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        fin >> x >> a[0][i];
        a[1][i] = start[x];
        start[x] = i;
        grad[a[0][i]]++;
    }
    for (i = 1; i <= n; i++)
        if (viz[i] == 0)
            df(i);
    for(i = n; i >= 1; i--)
        fout << c[i] << " ";
    return 0;
}
void df(int nod)
{
    int x;
    viz[nod] = 1;
    x = start[nod];
    while (x) {
        if (viz[a[0][x]] == 0)
            df(a[0][x]);
        x = a[1][x];
    }
    c[++pi] = nod;
}
