#include<bits/stdc++.h>
using namespace std;
FILE *f = fopen("sortaret.in","r");
FILE *g = fopen("sortaret.out","w");
const int NMAX = 101;
vector<int>G[NMAX];
int N,M;
bitset<NMAX>viz;
stack<int>stiva;
void Read()
{
    fscanf(f,"%d%d",&N,&M);
    for(int i=1;i<=M;i++)
    {
        int x,y;fscanf(f,"%d%d",&x,&y);
        G[x].push_back(y);
        G[y].push_back(x);
    }
}
void Dfs(int nodCurent)
{
    viz[nodCurent]=true;
    for(auto nodVecin:G[nodCurent])
        if(!viz[nodVecin])Dfs(nodVecin);
    stiva.push(nodCurent);
}
void Solve()
{
    for(int i=1;i<=N;i++)
        if(!viz[i])Dfs(i);
    while(!stiva.empty())
    {
        fprintf(g,"%d ",stiva.top());
        stiva.pop();
    }
}
int main()
{
    Read();
    Solve();

    return 0;
}
