#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <bitset>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

const int NMAX = 5e5 + 1;

vector<int> g[NMAX];
vector<int> deg;
stack<int> st;

int main()
{
    int n, m;
    fin >> n >> m;
    deg.resize(n + 1, 0);
    int x, y;
    for (int i = 0; i < m; ++i)
    {
        fin >> x >> y;
        g[x].push_back(y);
        ++deg[y];
    }
    queue<int> q;

    for (int i = 1; i <= n; ++i)
    {
        if (deg[i] == 0)
        {
            q.push(i);
            while (!q.empty())
            {
                int crt = q.front();
                deg[crt] = -1;
                q.pop();
                fout << crt << " ";
                for (int &y : g[crt])
                {
                    --deg[y];
                    if (deg[y] == 0)
                        q.push(y);
                }
            }
        }
    }

    return 0;
}