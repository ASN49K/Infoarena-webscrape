#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>

#define gmax 50010
using namespace std;
ifstream f ("sortaret.in");
ofstream g ("sortaret.out");

vector <int> G[gmax];
bitset <gmax> viz;
vector <int> ordonat;
int N,M;

void dfs(int nod)
{
    if(viz[nod])
        return;

    viz[nod] = true;
    for(int i = 0; i<G[nod].size(); i++)
        dfs(G[nod][i]);
    //cout<< viz[nod];

    ordonat.push_back(nod);
}

void read()
{
    f>>N>>M;
    for(int i = 1; i<=M; i++)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
    }
}

int main()
{
    read();

    for(int i = 1; i<=N; i++)
        dfs(i);

//    for(auto i = ordonat.rbegin(); i!=ordonat.rend(); ++i)
//        g<<*i<<' ';
    for(auto i = ordonat.rbegin(); i!=ordonat.rend(); ++i)
        g<<*i<<' ';
    return 0;
}
