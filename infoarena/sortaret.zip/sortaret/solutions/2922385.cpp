#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m, top[50005], k;
vector <int> a[50005];
bitset<50005> viz;
void Dfs(int x)
{
    viz[x] = 1;
    for (auto w: a[x])
        Dfs(w);
    top[++k] = x;
}
int main()
{
    int i, j;
    fin >> n >> m;
    while (m--)
    {
        fin >> i >> j;
        a[i].push_back(j);
    }

    for (i = 1; i <= n; i++)
    if (viz[i] == 0)
        Dfs(i);

    for (i = n; i >= 1; i--)
        fout << top[i] << " ";

    return 0;
}
