using namespace std;
#include<iostream>
#include<fstream>
#include<vector>
#include<queue>

#define NMAX 50005

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;
vector<int> G[NMAX];
int grad[NMAX];
queue<int> Q;

int main() {
    
    fin >> n >> m;
    for (int i = 1; i<=m; i++) {
        int a, b;
        fin >> a >> b;
        G[a].push_back(b);
        grad[b]++;
    }
    
    for (int x = 1; x<=n; x++) {
        if (grad[x] == 0) {
            Q.push(x);
        }
    }
    
    while(!Q.empty()) {
        int x = Q.front();
        Q.pop();
        fout << x << " ";
        for (auto it = G[x].begin(); it != G[x].end(); it++) {
            grad[*it]--;
            if (grad[*it] == 0) {
                Q.push(*it);
            }
        }
    }
    
    return 0;
}
