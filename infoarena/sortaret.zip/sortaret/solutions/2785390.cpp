#include <bits/stdc++.h>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int gi[50005];
int main(){

    int nr_noduri = -1;
    vector<int> adj[50005];
    int x, y, N, M;

   fin >> N >> M;
   for(int i = 1; i <= M; ++i){
        fin >> x >> y;
        adj[x].push_back(y);
        ++gi[y];
    }


    for(int i = 1; i <= N; ++i)
    {
        cout << i << ": ";
        for(int j = 0; j < adj[i].size(); ++j)
            cout << adj[i][j] << " ";
        cout << '\n';
    }
    queue<int> q;

    for(int i = 1; i <= N; ++i)
    {
        if(gi[i] == 0)
            q.push(i);
    }

    vector<int> sortaret;
    while(!(q.empty())){
        int f = q.front();
        q.pop();
        sortaret.push_back(f);
        for(int i = 0; i < adj[f].size(); ++i)
        {   int vecin = adj[f][i];
            --gi[vecin];
            if(gi[vecin] == 0)
                q.push(vecin);
        }
    }

    for(int i = 0; i < sortaret.size(); ++i)
        fout << sortaret[i] << " ";
    return 0;
}

