#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <bitset>
#include <queue>

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

struct Nod
{
    int ind;
    set<int> edges;
    Nod(int x){ind = x;}
    Nod(){};
};

vector<Nod> a;
int n, m;

int hs[50004];
queue<int> fatherless;
vector<int> result;

void kahn()
{
    for(int i = 1; i <= n; i++)
        if(!hs[i]) fatherless.push(i);

    while(!fatherless.empty())
    {
        int crt = fatherless.front();
        fatherless.pop();
        //cout << crt << " - crt" << "\n";
        result.push_back(crt);
        for(auto& it : a[crt].edges)
        {
            hs[it]--;
            if(!hs[it]) fatherless.push(it);
        }
    }
}

int main()
{
    a.push_back(Nod(0));
    fin >> n >> m;
    for(int i = 1; i <= n; i++) a.push_back(Nod(i));
    for(int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        hs[y]++;
        a[x].edges.insert(y);
    }

    kahn();
    for(auto& it: result)
        fout << it << " ";
    return 0;
}
