#include <bits/stdc++.h>
using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

InParser in("sortaret.in");
ofstream out("sortaret.out");

vector <int> v[50001];

int grad[50001];
int coada[50001], dr;

int main()
{
    int n, m, x, y;
    in >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        in >> x >> y;
        v[x].push_back(y);
        grad[y]++;
    }
    for(int i = 1; i <= n; i++)
        if(!grad[i])
            coada[++dr] = i;
    for(int i = 1; i <= n; i++)
        for(auto it:v[x])
        {
            grad[it]--;
            if(grad[it] == 0)
                coada[++dr] = it;
        }
    for(int i = 1; i <= n; i++)
        out << coada[i] << " ";
    return 0;
}
