#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <bitset>
#include <deque>


using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");


#define VERTECES 50001
vector<int> graph[VERTECES];
deque<int> deq;
bool viz[VERTECES];

void topo(int node) {
	viz[node] = 1;
	while (graph[node].size() > 0) {
		int neigh = graph[node].back();
		graph[node].pop_back();
		if (!viz[neigh]) {
			topo(neigh);
		}
	}
	deq.push_back(node);
}

int main()
{
	int vertices, edges;
	f >> vertices >> edges;
	int x, y;
	for (int i = 1; i <= edges; ++i) {
		f >> x >> y;
		graph[x].push_back(y);
	}
	for (int i = 1; i <= vertices; ++i) {
		if (!viz[i]) {
			topo(i);
		}
	}
	while (!deq.empty()) {
		g << deq.back() << " ";
		deq.pop_back();
	}

	f.close();
	g.close();
	return 0;
}