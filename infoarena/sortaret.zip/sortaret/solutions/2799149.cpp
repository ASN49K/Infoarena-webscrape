#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
class Graf
{
    private:
        int Noduri, Muchii;
        vector <vector<int>> ListaAdiacenta;

    public:
        Graf(){}
        Graf( int Noduri, int Munchii, vector <vector<int>> ListaAdiacenta)

        {
            this->Noduri = Noduri;
            this->Muchii = Muchii;
            this->ListaAdiacenta= ListaAdiacenta;

        }

        ~Graf()
        {
            this->Noduri = 0;
            this->Muchii = 0;
            this->ListaAdiacenta.clear();
        }

        void SetNoduri(int n)
        {
            Noduri = n;
        }

        int GetNoduri()
        {
            return Noduri;
        }

        void SetMuchii(int m)
        {
            Muchii = m;
        }

        int GetMuchii()
        {
            return Muchii;
        }

        void codBFS(int s);
        void codDFS(int nod, bool vizitat[]);
        void ComponenteConexe();
        void CodSortareTopo(int grad_intern[]);

};

void Graf::codBFS(int s)
{
    queue <int> coada;
    int distanta[Noduri+1] = {0};
    bool vizitat[Noduri+1] = {false};
    vizitat[s] = true;
    coada.push(s);
    while(coada.size()!= 0)
    {
        for (int nod : ListaAdiacenta[coada.front()])
        {
            if(vizitat[nod]==false)
            {
                vizitat[nod]=true;
                distanta[nod]=distanta[coada.front()]+1;
                coada.push(nod);
            }
        }
        coada.pop();
    }
    for(int i= 1; i <= Noduri; i++)
        if(s!=i && distanta[i]==0)
            g<<-1<<' ';
        else
            g<<distanta[i]<<' ';
}


void Bfs()
{
    int n, m, x, y, s;
    f>>n>>m>>s;
    vector <vector<int>> ListaAdiacenta(n+1);
    for(int i= 0; i < m; i++)
    {
        f>>x>>y;
        ListaAdiacenta[x].push_back(y);
    }
    Graf G(n, m, ListaAdiacenta);
    G.codBFS(s);

}
void Graf::codDFS(int nod, bool vizitat[])
{
    vizitat[nod]=true;
    for(int i : ListaAdiacenta[nod])
        {
            if(vizitat[i]==false)
                codDFS(i, vizitat);
        }
}

void Graf::ComponenteConexe()
{
    bool vizitat[Noduri+1] = {false};
    int nr = 0;
    for(int i=1; i<=Noduri; i++)
        if(vizitat[i]==false)
    {
        nr++;
        codDFS(i, vizitat);
    }
    g<<nr;
}
void Dfs()
{
    int n, m, x, y;
    cin>>n>>m;
    vector <vector<int>> ListaAdiacenta(n+1);
    for(int i=0; i < m; i++)
    {
        f>>x>>y;
        ListaAdiacenta[x].push_back(y);
        ListaAdiacenta[y].push_back(x);
    }
    Graf G(n, m, ListaAdiacenta);
    G.ComponenteConexe();
}

void Graf::CodSortareTopo(int grad_intern[])
{
    queue <int> coada;
    vector <int> afisare;
    for(int i=1; i<Noduri; i++)
        if(grad_intern[i]==0)
            coada.push(i);
    while(coada.size()!=0)
    {
        int nod = coada.front();
        afisare.push_back(nod);
        coada.pop();
        for (int i : ListaAdiacenta[nod])
        {
            grad_intern[i]--;
            if(grad_intern[i]==0)
                afisare.push_back(i);
        }
    }
    for(int i=1; i <= afisare.size(); i++)
        g<<afisare[i]<<' ';
}
void SortareTopologica()
{
    int n, m, x, y;
    cin>>n>>m;
    int grad_intern[50001];
    vector <vector<int>> ListaAdiacenta(n+1);
    for(int i=0; i < m; i++)
    {
        f>>x>>y;
        ListaAdiacenta[x].push_back(y);
        grad_intern[y]++;
    }
    Graf G(n, m, ListaAdiacenta);
    G.CodSortareTopo(grad_intern);
}
int main()
{

    SortareTopologica();
    f.close();
    g.close();
    return 0;
}
