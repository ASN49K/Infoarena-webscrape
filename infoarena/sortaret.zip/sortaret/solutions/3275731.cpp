#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
int viz[5005],n,m,i,x,y;
vector <int> v[50005];
void dfs(int s)
{for(int i:v[s])
    if(!viz[i])
        dfs(i);
g<<s<<" ";
}
int main()
{f>>n>>m;
for(i=1;i<=m;i++)
    {f>>x>>y;
    v[y].push_back(x);
    }
for(i=1;i<=n;i++)
    if(!viz[i])dfs(i);
}