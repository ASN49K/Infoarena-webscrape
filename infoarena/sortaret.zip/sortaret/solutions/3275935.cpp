#include <iostream>
#include <fstream>
#include <queue>
#include <bitset>
#include <vector>
#include <algorithm>

#define maxSize 100001

using namespace std;

vector<vector<int>> readAdjacencyList(ifstream &fin, int nodes, int edges, bool isDirected = false) {
    vector<vector<int>> adjList(nodes + 1);
    for (int i = 0; i < edges; i++) {
        int x, y;
        fin >> x >> y;
        adjList[x].push_back(y);
        if (!isDirected) {
            adjList[y].push_back(x);
        }
    }
    return adjList;
}

void depthFirstSearch(const vector<vector<int>>& adjList, int node, bitset<maxSize>& marked, vector<int>& topOrd) {
    marked[node] = true;

    for (auto neighbor : adjList[node]) {
        if (!marked[neighbor]) {
            depthFirstSearch(adjList, neighbor, marked, topOrd);
        }
    }
    topOrd.push_back(node);
}

vector<int> dfsTopologicalSort(const vector<vector<int>>& adjList) {
    bitset<maxSize> marked;
    vector<int> topOrd;

    for (int i = 1; i < adjList.size(); i++) {
        if(!marked[i]) {
            depthFirstSearch(adjList, i, marked, topOrd);
        }
    }

    reverse(topOrd.begin(), topOrd.end());
    return topOrd;
}

int main() {
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");

    int nodes, edges;
    fin >> nodes >> edges;

    auto adjList = readAdjacencyList(fin, nodes, edges, true);
    auto topSort = dfsTopologicalSort(adjList);

    for (auto elem : topSort) {
        fout << elem << " ";
    }
    fout << endl;

    fin.close();
    fout.close();

    return 0;
}
