#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

vector <int> edges[NMAX + 1];

int viz[NMAX + 1];
vector <int> sortaret;

void dfs( int node ) {
    viz[node] = true;
    for ( auto vec : edges[node] ) {
        if ( !viz[vec] ) {
            dfs( vec );
        }
    }
    sortaret.push_back( node );
}
int main() {
    ifstream fin( "sortaret.in" );
    ofstream fout( "sortaret.out" );
    int n, m;
    fin >> n >> m;
    for ( int i = 0, a, b; i < n; i ++ ) {
        fin >> a >> b;
        edges[a].push_back( b );
    }
    for ( int i = 1; i <= n; i ++ ) {
        if ( !viz[i] ) {
            dfs( i );
        }
    }
    reverse( sortaret.begin(), sortaret.end() );
    for ( auto x : sortaret ) {
        fout << x << ' ';
    }
    return 0;
}