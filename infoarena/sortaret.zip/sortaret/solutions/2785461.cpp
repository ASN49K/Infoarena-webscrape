#include <fstream>
#include <vector>
using namespace std;
int n,m;
const int N=50001;
ifstream Gigi ("sortaret.in");
ofstream Marcel ("sortaret.out");
struct nod
{
    int k=0;
    vector <int> vec;
};
vector <nod> v;
vector <int> descos;
void scoate (int p)
{
    for (int i=0;i<v[p].vec.size();i++){
        v[v[p].vec[i]].k--;
    }
}
int main()
{
    Gigi>>n>>m;
    nod temp;
    int x,y,i;
    temp.k=-1;
    v.push_back(temp);
    temp.k=0;
    for (i=1;i<=n;i++){
        v.push_back(temp);
    }
    for (i=0;i<m;i++){
        Gigi>>x>>y;
        v[y].k++;
        v[x].vec.push_back(y);
    }
    bool b=1;
    while (b){
        b=0;
        for (i=1;i<v.size();i++){
            if (v[i].k==0){
                b=1;
                v[i].k=-1;
                descos.push_back(i);
            }
        }
        while(!descos.empty()){
            Marcel<<descos.back()<<" ";
            scoate(descos.back());
            descos.pop_back();
        }
    }
    return 0;
}
