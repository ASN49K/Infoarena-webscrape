#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <queue>

using namespace std;

vector <int> graph[100005];
int n, x, y, nr, i, m, s, degree[100005], auxi;
queue <int> q;
vector <int> topo;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

void bfs () {
    for ( i = 1; i <= n; i++ ) {
        if ( degree[i] == 0 ) {
            q.push ( i );
        }
    }
    while ( !q.empty() ) {
        auxi = q.front();
        q.pop();
        topo.push_back ( auxi );
        fout << auxi << ' ';
        for ( auto j: graph[auxi] ) {
            degree[j]--;
            if ( degree[j] == 0 ) {
                q.push ( j );
            }
        }
    }
}

int main() 
{
    
    fin >> n >> m;

    for ( i = 1; i <= m; i++ ) {
        fin >> x >> y;
        graph[x].push_back(y);
        degree[y]++;
    }

    bfs();
    
    return 0;
}