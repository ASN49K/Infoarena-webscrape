#include <cstdio>
#include <cmath>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <bitset>
#include <map>
#include <cstring>
#include <algorithm>

#define NMAX 50003
using namespace std;

FILE* fin, * fout;

int n,m,niv;
int topo[NMAX];
vector<int>graf[NMAX];
bool viz[NMAX];

void dfs(int nod)
{
	viz[nod] = true;
	for (int i = 0; i < graf[nod].size(); i++)
	{
		int nd = graf[nod][i];
		if (!viz[nd])
		{
			dfs(nd);
		}
	}
	topo[++niv] = nod;
}

int main()
{
	fin = fopen("sortaret.in", "r");
	fout = fopen("sortaret.out", "w");
	
	fscanf(fin, "%d %d", &n, &m);
	for (int i = 1; i <= m; i++)
	{
		int x, y;
		fscanf(fin, "%d %d", &x, &y);
		graf[y].push_back(x);
	}

	for (int i = 1; i <= n; i++)
	{
		if (!viz[i])
		{
			dfs(i);
		}
	}
	for (int i = 1; i <= n; i++)
	{
		fprintf(fout, "%d ", topo[i]);
	}
	return 0;
}