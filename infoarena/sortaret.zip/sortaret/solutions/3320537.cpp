#include <bits/stdc++.h>

int n, m;
std::ifstream fin("sortaret.in");
std::ofstream fout("sortaret.out");

std::vector<std::vector<int>> a;
std::vector<bool> visited;
std::vector<int> b;

void BFS(int start) {
    std::queue<int> q;
    q.push(start);
    b.push_back(start);

    while(!q.empty()) {
        for(int p : a[q.front()]) {
            if(visited[p])
                return
    
            b.push_back(p);
            q.push(p);
            visited[p] = true;
        }

        q.pop();
    }
}

int main() {
    fin >> n >> m;

    a.resize(n + 1);
    visited.resize(n + 1);

    for(int i = 0; i < n; ++i) {
        int x, y;
        fin >> x >> y;
        a[x].push_back(y);
        visited[y] = true;
    }
    
    for(int i = 1; i <= n; ++i) {
        if(visited[i] == false) {
            BFS(i);
        }
    }

    for(int x : b)
        fout << x << ' ';
    return 0;
}