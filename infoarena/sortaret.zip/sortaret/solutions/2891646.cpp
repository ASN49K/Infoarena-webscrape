#include <bits/stdc++.h>
#define NMAX 50005

using namespace std;

vector <int> adj[NMAX];
int grade[NMAX];

int main()
{
	freopen("sortaret.in", "r", stdin);
	freopen("sortaret.out", "w", stdout);

	int n, m;
	cin >> n >> m;
	for (int i = 1, x, y; i <= m; ++i) {
		cin >> x >> y;
		adj[x].push_back(y);
		++grade[y];
	}

	queue <int> q;
	for (int i = 1; i <= n; ++i)
		if (grade[i] == 0)
			q.push(i);

	while (!q.empty()) {
		int u = q.front();
		cout << u << ' ';
		q.pop();
		for (int v : adj[u]) {
			--grade[v];
			if (grade[v] == 0)
				q.push(v);
		}
	}
	return 0;
}
