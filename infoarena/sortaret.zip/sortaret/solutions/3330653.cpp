#include <fstream>
#include <vector>

using namespace std;

ifstream be("sortaret.in");
ofstream ki("sortaret.out");

int main()
{
    int n, m;
    be >> n >> m;

    vector<vector<char>> g(n + 1, vector<char>(n + 1));

    for(int i = 0; i < m; i++)
    {
        int x, y;
        be >> x >> y;

        g[y][x] = 1;
    }

    vector<int> ans;

    while((int)ans.size() != n)
    {
        for(int i = 1; i <= n; i++)
        {
            bool b = true;

            for(int j = 1; j <= n; j++)
            {
                if(g[i][j] != 0)
                {
                    b = false;
                    break;
                }
            }

            if(b)
            {
                ans.push_back(i);

                for(int k = 1; k <= n; k++)
                {
                    if(g[k][i] != -1) g[k][i] = 0;
                }

                g[i][1] = -1;
            }
        }
    }

    for(int i : ans)
    {
        ki << i << " ";
    }

    return 0;
}