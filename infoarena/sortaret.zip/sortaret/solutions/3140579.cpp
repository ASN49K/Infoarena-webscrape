#include<bits/stdc++.h>
#define mod 1000000007
#define inf 0x3f3f3f3f
#define int long long
#define bit(x,i)(((x)>>(i))&1)
#define FAST ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
//typedef long long ll;
//const long long int mare=1LL*1000000000000000000;
const int nmax=5e4+5;
int T,n,m,k,i,j,t;
int suma,maxx,numar,ans,minn,poz,contor,st,dr;
int v[nmax][20],deg[nmax],viz[nmax];
int dp[nmax][20];
vector<int> G[nmax];
queue<int> q;
void bfs()
{
    while(!q.empty())
    {
        j=q.front();
        q.pop();
        for(i=0;i<G[j].size();i++)
        {
            deg[G[j][i]]--;
            if(deg[G[j][i]]==0)
                q.push(G[j][i]);
        }
        fout<<j<<" ";
    }
}
signed main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>st>>dr;
        G[st].push_back(dr);
        deg[dr]++;
    }
    for(i=1;i<=n;i++)
    {
        if(deg[i]==0)
            q.push(i);
    }
    bfs();
    return 0;
}