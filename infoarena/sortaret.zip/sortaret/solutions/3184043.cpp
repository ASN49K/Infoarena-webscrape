#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("sortaret.in");
ofstream cout("sortaret.out");
int n,m,x,y,v[50002],nr,d[50002];
bool viz[50002];
vector<int>l[50002];
void dfs(int nod)
{
    viz[nod]=1;
    v[++nr]=nod;
    for(int i=0; i<l[nod].size(); i++)
    {
        int vecin=l[nod][i];
        if(viz[vecin]==0)
            dfs(vecin);
    }
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        cin>>x>>y;
        l[x].push_back(y);
        d[y]++;
    }
    for(int i=1; i<=n; i++)
        if(d[i]==0)
            dfs(i);

    for(int i=1; i<=n ; i++)
        cout<<v[i]<<" ";

    return 0;
}
