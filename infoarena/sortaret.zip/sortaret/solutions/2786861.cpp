#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

const int N=5e4+1;

int nrp[N];
vector<int> a[N],sort_top;
bool viz[N];

void dfs(int x)
{
    viz[x]=true;
    for(auto y: a[x])
    {
        if(!viz[y])
        {
            dfs(y);
        }
    }
    sort_top.push_back(x);
}

int main()
{
    int n,m;
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        in>>x>>y;
        nrp[y]++;
        a[x].push_back(y);
    }
    for(int i=1; i<=n; i++)
    {
        if(!nrp[i]) dfs(i);
    }
    for(int i=0; i<n; i++)
    {
        out<<sort_top[i]<<" ";
    }
    return 0;
}
