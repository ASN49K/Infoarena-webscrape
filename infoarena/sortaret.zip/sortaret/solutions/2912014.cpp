#include <fstream>
#include <vector>
#include <list>
#include <set>
#define dim 50005

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

vector<vector<int>> g;
set<int> q;

int n, m, x, y, gInt[dim];

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL), fout.tie(NULL);

    fin>>n>>m;

    g=vector<vector<int>>(n+1);

    while(m--)
    {
        fin>>x>>y;
        g[x].push_back(y);
        gInt[y]++;
    }

    for(int i=1; i<=n; i++)
        if(!gInt[i])
        q.insert(i);

    while(!q.empty())
    {
        int k=*(q.begin());
        q.erase(k);
        fout<<k<<' ';
        for(auto i: g[k])
        {
            gInt[i]--;
            if(!gInt[i])
                q.insert(i);
        }
    }


    return 0;
}
