#include <fstream>
#include <vector>
#include <set>
using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector < vector <int> > g;
set <int> s;
vector <int> di;
int n, m;

void citire()
{
    fin>>n>>m;
    g = vector < vector <int> > (n+2);
    di = vector <int> (n+2);
    int x, y;
    for (int i=1; i<=n; ++i)
    {
        fin>>x>>y;
        g[x].push_back(y);
        di[y]++;
    }
}

void top_sort()
{
    for (int i=1; i<=n; ++i)
        if (di[i]==0) s.insert(i);
    for (int i=1; i<=n; ++i)
    {
        int x=*s.begin();
        s.erase(*s.begin());
        fout<<x<<' ';
        for (auto y:g[x])
        {
            di[y]--;
            if (di[y]==0) s.insert(y);
        }
        g[x].clear();
    }
}

int main()
{
    citire();
    top_sort();
    return 0;
}