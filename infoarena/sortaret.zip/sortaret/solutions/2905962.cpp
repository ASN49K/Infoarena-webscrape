#include <vector>
#include <fstream>
#include <queue>
#include <iostream>
using namespace std;
const int N = 50000;
vector <int> a[N + 1];
queue<int>q;
int nrp[N];
int n;
ifstream in("sortaret.in");
ofstream out("sortaret.out");
int check(int x) {
    for (auto y : a[x]) {
        nrp[y]--;
        if (nrp[y] == 0) {
            q.push(y);
            return y;
        }
    }
    return -1;
}
int main()
{
    int m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int y, x;
        in >> x >> y;
        a[x].push_back(y);
        nrp[y]++;
    }
    for (int i = 1; i <= n; i++) {
        if (nrp[i] == 0) {
            q.push(i);
        }
    }
    while (!q.empty()) {
        int x = q.front();
        out << x << " ";
        q.pop();
        for (auto y : a[x]) {
            nrp[y]--;
            if (nrp[y] == 0) {
                q.push(y);
            }
        }
    }
    in.close();
    out.close();
    return 0;
}