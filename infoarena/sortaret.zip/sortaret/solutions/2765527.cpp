#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;
vector<int> g[300300];
int v[300300], cnt;
bool vizitat[300300];

void dfs(int nod)
{
    vizitat[nod] = true;
    for(int i = 0; i < g[nod].size(); i++)
    {
        if(!vizitat[g[nod][i]])
            dfs(g[nod][i]);
    }
    v[++cnt] = nod;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int u, v;
        fin >> u >> v;
        if(u != v)
        {
            g[u].push_back(v);
        }
    }
    for(int i = 1; i <= n; i ++)
    {
        if(!vizitat[i])
        {
            dfs(i);
        }
    }
    reverse(v + 1, v + cnt + 1);
    for(int i = 1; i <= cnt; i ++)
    {
        fout << v[i] << ' ';
    }
    fout << '\n';
    return 0;
}
