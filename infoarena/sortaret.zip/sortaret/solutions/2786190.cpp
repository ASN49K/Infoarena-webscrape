#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
/*const long long mod = 998244353;
long long fct[200005],invfct[200005],inv[200005];
long long put2[200005];
long long lgput (long long a, long long exp)
{
    long long rz=1;
    while(exp)
        if(exp&1)
            exp^=1,rz=rz*1LL*a%mod;
        else
            exp>>=1,a=a*1LL*a%mod;
    return rz;
}
long long cmb (long long n, long long k)
{
    if(n<k || k<0 || n<0)
        return 0;
    return fct[n]*1LL*invfct[k]%mod*1LL*invfct[n-k]%mod;
}
void init ()
{
    inv[1]=fct[0]=fct[1]=invfct[0]=invfct[1]=put2[0]=1,put2[1]=2;
    for(long long i=2;i<=200000;++i)
        put2[i]=put2[i-1]*2LL%mod,inv[i]=(mod-mod/i)*1LL*inv[mod%i]%mod,fct[i]=i*1LL*fct[i-1]%mod,invfct[i]=inv[i]*1LL*invfct[i-1]%mod;
}
long long v[200005];*/
vector<int> v[50005];
queue<int> q;
int nrp[500005];
void solve()
{
    int n,m;
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(y);
        nrp[y]++;
    }
    for(int i=1;i<=n;i++)
    {
        if(!nrp[i])
           q.push(i);
    }
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        g<<x<<" ";
        for(auto y:v[x])
        {
            nrp[y]--;
            if(!nrp[y])
               q.push(y);
        }
    }
}
int main()
{
   // ios_base::sync_with_stdio(false);
   // f.tie(NULL);
    //int t;
   // f>>t;
   // while(t--)
        solve();
    return 0;
}
