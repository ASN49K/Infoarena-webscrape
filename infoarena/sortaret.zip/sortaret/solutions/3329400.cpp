#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");


vector<int>V[50001];
queue<int>q;

int n,m;
int sortop[50001],nr;
int g[50001];


int main()
{
    int x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        V[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!g[i])
            q.push(i);
    while(!q.empty())
    {
        x=q.front();
        sortop[++nr]=x;
        for(int i=0;i<V[x].size();i++)
        {
            y=V[x][i];
            g[y]--;
            if(!g[y])
                q.push(y);

        }
        q.pop();

    }
    for(int i=1;i<=nr;i++)
        fout<<sortop[i]<<' ';
    return 0;
}
