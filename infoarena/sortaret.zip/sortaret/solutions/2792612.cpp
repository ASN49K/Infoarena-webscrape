#include<iostream>
#include<fstream>
#include<queue>
#include<vector>
#include<list>
#include<stack>

using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");

class Graf{

    private:
        int noduri, muchii;
        list <int> *adiacenta;
        vector<int> cost_vizita;
        stack <int> stiva_topo;
public:
    Graf(); //constructor neparametrizat
    Graf(int nr_noduri, int nr_muchii); //constructor parametrizat - in functie de nr de noduri si muchii
    ~Graf(); //destructorul

    void Muchie(int tata, int fiu); //adaug o muchie in graful curent orientat
    void BFS(int sursa);
    void DFS(int sursa);
    void ComponenteConexe();
    void SortareTopologica(int sursa);
    void Sortare();
};
Graf::Graf() //constructor neparametrizat - valori implicite = 0
{
    this->noduri = 0;
    this->muchii = 0;
}
Graf::Graf(int nr_noduri, int nr_muchii) //constructor parametrizat - in functie de nr de noduri si muchii
{
    this->noduri = nr_noduri; //initializez dimensiunile grafului cu cele citite din fisier
    this->muchii = nr_muchii;
    adiacenta = new list<int>[nr_noduri];
    cost_vizita.resize(nr_noduri, -1); //definesc un vector unde contorizez pe parcursul BFS-ului ce noduri au fost vizitate si care e distanta catre nodul parinte, initializarea se face cu valoarea -1
}
Graf::~Graf() //destructorul
{ 
    this->noduri = 0;
    this->muchii = 0;
    delete [] adiacenta;
    cost_vizita.clear(); //eliberez spatiul alocat vectorului unde contorizez nodurile vizitate
}
void Graf::Muchie(int tata, int fiu) 
{
    adiacenta[tata - 1].push_back(fiu - 1); //adaug pe linia tata - 1, ca ultim element al vetorului, nodul cu care se invecineaza (fiu - 1) - le adaug -1 pentru ca eu lucrez cu vectori care incep de la 0
}
void Graf::BFS(int sursa)
{
    queue<int> vecini; //coada in care aduag pe rand nodurile pe care le voi parcurge in BFS
    cost_vizita[sursa - 1] = 0; //costul de vizita al nodului sursa e 0
    vecini.push(sursa - 1); //adaug nodul sursa in coada BFS
    while (!vecini.empty()) { //cat timp am noduri accesibile din radacina
        int nod_curent = vecini.front(); //iau nodul din fata cozii si adaug la finalul cozii toti vecinii cu care acesta are conexiuni
        vecini.pop();
        for (auto& nod_vecin : adiacenta[nod_curent]) //iau din lista de adiacenta nodurile vecine
        {
            if (cost_vizita[nod_vecin] == -1) { //verific ca nodul sa nu fi fost deja vizitat
                cost_vizita[nod_vecin] = cost_vizita[nod_curent] + 1; //daca nodul nu a fost vizitat, ii calculez costul de vizita
                vecini.push(nod_vecin);                               //si il adaug in coada pentru BFS
            }
        }
    }
    for (size_t i = 0; i < cost_vizita.size(); i++) //afisez costul pentru fiecare nod
        g << cost_vizita[i]<< " ";
}
void Graf::DFS(int sursa)
{
    cost_vizita[sursa] = 1; //marchez nodul sursa ca fiind vizitat
    for (auto& nod_vecin : adiacenta[sursa]) //verific in vecinii acestuia care nu au fost vizitati si apelez pentru fiecare in parte DFS
        if (cost_vizita[nod_vecin] == -1)
        {
            cost_vizita[nod_vecin] = 1; //actualizez starea nodului -> actualizat
            DFS(nod_vecin);
        }
 }
void Graf::ComponenteConexe()
{
    int nr_conexe = 0;
    for (size_t i = 0; i < cost_vizita.size(); i++) //din graful initial, verific nodurile care nu au fost vizitate si apelez DFS pentru fiecare in parte
        if (cost_vizita[i] == -1)
        {
            DFS(i); // fiecare apel independet de DFS imi semnaleaza existenta unei componente conexe
            nr_conexe++;
        }
    g << nr_conexe;
}
void Graf::SortareTopologica(int sursa)
{
    cost_vizita[sursa] = 1; // pornesc dintr-un varf sursa, iar dupa principiul DFS, voi realiza pentru fiecare nod gasit in adancime sortarea
    for (auto& nod_vecin : adiacenta[sursa])
        if (cost_vizita[nod_vecin] == -1)
        {
            SortareTopologica(nod_vecin);
            stiva_topo.push(sursa); //cand nodul curent a ramas fara vecini accesibili, acesta este aduagat in stiva de sortare
        }
}
void Graf::Sortare()
{
    for (size_t i = 0; i < cost_vizita.size(); i++) //din graful initial, verific nodurile care nu au fost vizitate si apelez Sortarea Topologica pentru fiecare in parte
        if (cost_vizita[i] == -1)
            SortareTopologica(i);
    while (!stiva_topo.empty())
    {
        g << stiva_topo.top()+1<<" "; //adaug 1 pt ca am scazut din fiecare numar 1
        stiva_topo.pop();
    }
}
int main() {
    int N, M, S, x, y;
    f >> N >> M;
 /* Graf exbfs(N, M); //initializez graful
    for (int i = 0; i < M; i++)
    {
        f >> x >> y;
        exbfs.Muchie(x, y);
    }
    exbfs.BFS(S); */
 /*   Graf exdfs(N, M); //initializez graful
    for (int i = 0; i < M; i++)
    {
        f >> x >> y;
        exdfs.Muchie(x, y);
        exdfs.Muchie(y, x);
    }
    exdfs.ComponenteConexe(); */
    Graf exsortt(N, M); //initializez graful
    for (int i = 0; i < M; i++)
    {
        f >> x >> y;
        exsortt.Muchie(x, y);
    }
    exsortt.Sortare();
    return 0;
}