#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n, m;
vector<int> g[100001];
vector<int> viz(0);
stack<int> sol;

void dfs(int nod) {
viz[nod]=1;

for(auto x: g[nod]) {
    if(viz[x]==0)
        dfs(x);
}
sol.push(nod);
}

int main()
{
    fin>>n>>m;
    for(int i=0; i<m; i++) {
        int x, y;
        fin>>x>>y;
        g[x].push_back(y);
    }
    viz.resize(n+1);

    for(int i=1; i<=n; i++) {
            if(viz[i]==0) {
                dfs(i);
            }

    }
    while(!sol.empty()) {
        fout<<sol.top()<<" ";
        sol.pop();
    }
    return 0;
}
