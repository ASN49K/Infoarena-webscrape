/*
https://infoarena.ro/problema/sortaret
*/
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

void dfs(int x, vector <vector <int>> &l_s,
         vector <bool> &viz, stack <int> &s)
{
    viz[x] = true;
    for (auto y: l_s[x])
    {
        if (!viz[y])
        {
            dfs(y, l_s, viz, s);
        }
    }
    s.push(x);
}

int main()
{
    ifstream in("sortaret.in");
    ofstream out("sortaret.out");
    int n, m;
    in >> n >> m;
    vector <vector <int>> l_s(n + 1);
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        l_s[x].push_back(y);
    }
    in.close();
    vector <bool> viz(n + 1, false);
    stack <int> s;
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            dfs(i, l_s, viz, s);
        }
    }
    while (!s.empty())
    {
        out << s.top() << " ";
        s.pop();
    }
    out << "\n";
    out.close();
    return 0;
}
