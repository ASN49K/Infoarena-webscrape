#include <iostream>
#include <fstream>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

int nodes, edges;
int used[50005];

int main (){
    int x, y;

    in >> nodes >> edges;
    for (int i=1; i<=edges; ++i){
        in >> x >> y;
        if (used[x] == 0){
            used[x] = 1;
            out << x << ' ';
        }
        if (used[y] == 0){
            used[y] = 1;
            out << y << ' ';
        }
    }
    return 0;
}