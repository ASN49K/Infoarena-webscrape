#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

// spatiu de declarare
int n, m;              //noduri, muchii
vector <int> v[50006]; // lista de adiacenta
bool viz[50006];       // vector de vizitari

void dfs (int nod) {
    fout << nod << " ";
    viz[nod] = true;
    for (auto vec : v[nod]) {
        if (!viz[vec]) {
            dfs (vec);
        }
    }
}
int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int a, b;
        fin >> a >> b;
        v[a].push_back(b);
    }
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            dfs (i);
        }
    }
    return 0;
}