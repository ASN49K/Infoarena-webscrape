#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int main() { 
    int numar_noduri;
    int numar_arce;
    // cout << "HEY"<<endl;
    fin >> numar_noduri >> numar_arce;

    int noduri_grad_interne[numar_arce];
    int noduri_grad_externe[numar_arce];
    int grad_intern[numar_noduri];

     for (int i = 1; i <= numar_noduri; i++) {
        grad_intern[i] = 0;
    }

    for (int i = 1; i <= numar_arce; i++) {
        fin >> noduri_grad_externe[i];
        fin >> noduri_grad_interne[i];
        grad_intern[noduri_grad_interne[i]]++;
    }
    fin.close();
    int count = 0;

    while(count != numar_noduri) {
        for (int i = 1; i <= numar_noduri; i++) {
            if (grad_intern[i] == 0) {
                fout << i << " ";
                count++;
                grad_intern[i] = -1;
                for (int j = 1; j <= numar_arce; j++) {
                    if (noduri_grad_externe[j] == i) {
                        grad_intern[noduri_grad_interne[j]]--;
                    }
                }
                break;
            }
        }
    }
    cout << endl;

    fout.close();
    return 0;
}
