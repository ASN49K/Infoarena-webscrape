#include <fstream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cstdlib>
#include <string>
#include <deque>

using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

int main()
{
    int n,m;
    cin>>n>>m;
    vector<vector<int> >adj(n+1);
    vector<int>roots(n+1,0);
    deque<int>q;
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        adj[x].push_back(y);
        roots[y]++;
    }
    for(int i=1;i<=n;i++)
    {
        if(roots[i]==0)
        {
            q.push_back(i);
        }
    }
    while(!q.empty())
    {
        int a=q.front();
        cout<<a<<" ";
        q.pop_front();
        for(auto it:adj[a])
        {
            roots[it]--;
            if(roots[it]==0)
            {
                q.push_back(it);
            }
        }
    }

    return 0;
}
