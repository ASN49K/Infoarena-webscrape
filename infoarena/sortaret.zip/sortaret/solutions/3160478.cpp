#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

//ifstream fin("./date.txt");
ifstream fin("sortaret.in");
ofstream fout("sortatret.out");

int n, m,d[50001];
vector <int> v[50001],sol;

void read()
{
	fin >> n >> m;
	for (int i = 0; i < m; ++i)
	{
		int x, y;
		fin >> x >> y;
		v[x].push_back(y);
	}
}

void dfs(int node)
{
	d[node] = 1;
	for (int i = 0; i < v[node].size(); ++i)
	{
		int vecin = v[node][i];
		if (!d[vecin])
		{
			sol.push_back(vecin);
			dfs(vecin);
		}
	}
}

int main()
{
	read();
	for (int i = 1; i <= n; ++i)
	{
		if (!d[i])
		{
			sol.push_back(i);
			dfs(i);
		}
	}
	for (int i = 0; i < sol.size(); ++i)
		fout << sol[i] << " ";
}
