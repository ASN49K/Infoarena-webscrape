#include <fstream>
#include <deque>
#include <vector>

using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

int n,m;

struct adat
{
    bool lat,nemkezd;
    vector <int> sz;
};

vector <adat> x;

deque <int> y;
void mely(int a)
{
    x[a].lat=1;
    for(auto e:x[a].sz)
    {
        if(!x[e].lat)
        {
            mely(e);
        }
    }
    y.push_front(a);
}
int i,a,b;
bool nem;
int main()
{
    cin>>n>>m;
    x.resize(n+1);
    for(i=1;i<=m;++i)
    {
        cin>>a>>b;
        nem=0;
        x[b].nemkezd=1;
        for(auto e:x[a].sz)
        {
            if(e==b)
            {
                nem=1;
                //break;
            }
        }
        if(!nem) x[a].sz.push_back(b);
    }

    for(i=1;i<=n;++i)
    {
        if(!x[i].nemkezd)
        {
            mely(i);
            break;
        }
    }

    for(auto e:y)
    {
        cout<<e<<" ";
    }

}
