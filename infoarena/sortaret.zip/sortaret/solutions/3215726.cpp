#include <fstream>

#include <vector>
using namespace std;
int n,m,grad[100001],f[100001];
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
vector<int>G[100001];
void dfs(int nod){
    fout<<nod<<" ";
    f[nod]=1;
    for(auto x : G[nod])
        if(f[x]==0)
            dfs(x);
}
int main(){
    fin>>n>>m;
    while(m--){
        int x,y; fin>>x>>y;
        G[x].push_back(y);
        grad[y]++;
    }
    for(int i=1;i<=n;i++)
        if(grad[i]==0)
            dfs(i);

    return 0;
}
