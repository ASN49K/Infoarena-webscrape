#include <bits/stdc++.h>
#define nmax 50002
using namespace std;
ifstream f("sortaret.in");
ofstream g("sortaret.out");
int n,m,d[nmax];
vector <int> L[nmax];
queue <int> Q;
int main()
{   f>>n>>m;
    for(int a,b; m; m--)
        {f>>a>>b; L[a].push_back(b); d[b]++; }
    for(int i=1; i<=n; i++)
        if(d[i]==0)
        {   Q.push(i);
            g<<i<<' ';
        }
    while(!Q.empty())
    {   int x=Q.front();
        for(int j=0; j<L[x].size(); j++)
        {   d[L[x][j]]--;
            if(d[L[x][j]]==0) { Q.push(L[x][j]); g<<L[x][j]<<' ';}
        }
        Q.pop();
    }
    g.close();
    f.close();
    return 0;
}
