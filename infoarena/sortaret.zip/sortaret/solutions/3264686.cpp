#include <bits/stdc++.h>
//#pragma GCC optimize("O3,unroll-loops")
//#pragma GCC target("avx2,bmi,bmi2,popcnt,lzcnt")


using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int nmax = 50001;
int n,m;
array<set<int>,nmax> g;
int v[nmax];
int main() {
    queue<int> q;
    fin >> n >> m;
    while (m--) {
        int a,b;
        fin >> a >> b;
        g[a].insert(b);
        v[b]++;
    }
    for (int i = 1; i <= n; i++) {
        if (!v[i])
            q.push(i);
    }

    while (!q.empty()) {
        const auto x = q.front();
        q.pop();
        for (const int y : g[x]) {
            v[y]--;
            if (!v[y])
                q.push(y);
        }
        fout << x << ' ';
    }

    return 0;
}
