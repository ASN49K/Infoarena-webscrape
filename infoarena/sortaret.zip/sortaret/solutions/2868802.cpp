#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("sortaret.in");
ofstream cout ("sortaret.out");
int n,m,i,k,g[50004],a,b;
vector<int>G[50004];
queue<int>Q;
int main()
{
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b;
        G[a].push_back(b);
        g[b]++;
    }
    for(i=1;i<=n;i++)
    {
        if(g[i]==0)
            Q.push(i);
    }
    while(!Q.empty())
    {
        k=Q.front();
        cout<<k<<" ";
        Q.pop();
        for(auto i:G[k])
        {
            g[i]--;
            if(g[i]==0)
            {
                Q.push(i);
            }
        }
    }
    return 0;
}
