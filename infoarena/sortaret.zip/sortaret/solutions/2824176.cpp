#include <bits/stdc++.h>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sorataret.out");

typedef long long ll;
const int nmax = 50005;

int n, m;
int d[nmax];
vector <int> v[nmax], ans;

void read(){
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
        d[y]++;
    }
}

void dfs(int x){
    ans.push_back(x);

    for(int i = 0; i < v[x].size(); i++){
        int y = v[x][i];
        d[y]--;
        if(d[y] == 0)
            dfs(y);
    }
}

void solve(){
    int start = 0;

    for(int i = 1; i <= n; i++)
        if(d[i] == 0){
            start = i;
            break;
        }

    dfs(start);
}

void print(){
    for(auto it : ans)
        fout << it << " ";
}

int main()
{
    read();
    solve();
    print();

    return 0;
}
