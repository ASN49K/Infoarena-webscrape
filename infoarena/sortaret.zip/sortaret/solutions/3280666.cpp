#include <bits/stdc++.h>

using namespace std;

ifstream fin ("sortaret.in");
ofstream fout ("sortaret.out");

vector <int> g[50005];
stack <int> st;
bool visited[50005];

void dfs (int nod) {
    visited[nod]=1;
    for (int vecin : g[nod]) {
        dfs(vecin);
    }
    st.push(nod);
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n, m, x, y; fin>>n>>m;
    for (int i=1; i<=m; i++) {
        fin>>x>>y;
        g[x].push_back(y);
    }
    for (int i=1; i<=n; i++) {
        if (!visited[i]) {
            dfs(i);
        }
    }
    while (!st.empty()) {
        fout<<st.top()<<' ';
        st.pop();
    }
    return 0;
}