#include <bits/stdc++.h>
#define NMAX 50005

using namespace std;

ifstream f("sortaret.in");
ofstream g("sortaret.out");

int n, m;
bitset <NMAX> v;
vector <int> edges[NMAX];

void dfs(int nod)
{
    v[nod] = 1;
    g << nod << " ";
    for(auto k : edges[nod])
        if(!v[k])
            dfs(k);
}

int main()
{
    f >> n >> m;

    for(int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;
        edges[x].push_back(y);
    }

    for(int i = 1; i <= n; i++)
        if(!v[i])
            dfs(i);
    return 0;
}
