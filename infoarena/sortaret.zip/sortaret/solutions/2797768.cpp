#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <queue>
using namespace std;
#define MaxN 50100
ifstream f("sortaret.in");
ofstream g("sortaret.out");

vector<int> la[MaxN];
int n,m,x,y;
queue<int> coada;

void topologic(vector <int>& deg)
{

    for(int i=1;i<=n;i++)
        if(!deg[i]) coada.push(i);
    while(!coada.empty())
    {
        for(auto j:la[coada.front()])
        {
            deg[j]--;
            if(!deg[j]) coada.push(j);
        }
        g<<coada.front()<<" ";
        coada.pop();
    }
}

int main()
{
     f>>n>>m;
     vector<int> deg(n+1,0);
     for(int i=0;i<m;i++)
     {
      f>>x>>y;
      la[x].push_back(y);
       deg[y]++;
     // cout<<y<<":"<<deg[y]<<endl;
     }
     f.close();

     topologic(deg);

     g.close();
     return 0;
}

