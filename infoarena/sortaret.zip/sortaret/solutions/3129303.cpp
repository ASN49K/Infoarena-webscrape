#include <fstream>
#include <vector>
#define ll long long

using namespace std;

ifstream cin("sortaret.in");
ofstream cout("sortaret.out");

const int NMAX = 50000;
int n, m;
vector<int> G[NMAX + 1];
int sorted[NMAX + 1], ind,a[1001][1001];
bool viz[NMAX + 1];

void DFS(int k)
{
    viz[k] = 1;
    for(int x=1;x<=n;x++)
        if(!viz[x])
            DFS(x);

    sorted[++ind] = k;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        a[x][y]=1;
    }

    for(int i = 1; i <= n; i++)
        if(!viz[i])
            DFS(i);

    for(int i = ind; i >= 1; i--)
        cout << sorted[i] << ' ';

    return 0;
}
