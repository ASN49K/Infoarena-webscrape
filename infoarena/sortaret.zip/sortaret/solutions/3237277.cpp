#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

ifstream cin ("sortaret.in");
ofstream cout ("sortaret.out");

long long int t,n,i,j,d,k,m,x,y,ans[50005],fr[50005],dp[10][100],start,capat,len,sum,ok,l,r,mini,c,nr,maxi;
const int MOD=1e9+7;
char v[505][505];
char s[200005];
vector<int>nod[1000001];
queue<int>q;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        nod[x].push_back(y);
        fr[y]++;
    }
    for(i=1;i<=n;i++)
    {
        if(fr[i]==0)
        {
            q.push(i);
            ans[++nr]=i;
        }
    }
    while(!q.empty())
    {
        k=q.front();
        for(i=0;i<nod[k].size();i++)
        {
            fr[nod[k][i]]--;
            if(fr[nod[k][i]]==0)
            {
                ans[++nr]=nod[k][i];
                q.push(nod[k][i]);
            }
        }
        q.pop();
    }
    for(i=1;i<=nr;i++)
        cout<<ans[i]<<' ';
    return 0;
}
