#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

int main()
{
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");

    int n, m;
    fin >> n >> m;

    vector<vector<int>> adj(n+1);
    vector<int> gr(n+1, 0);

    for (int i = 0; i < m; i++) {
        int a, b;
        fin >> a >> b;
        adj[a].push_back(b);
        gr[b]++;
    }

    queue<int> akt;
    for (int i = 1; i <= n; i++)
        if (gr[i] == 0)
            akt.push(i);

    while (!akt.empty()) {
        int v = akt.front();
        akt.pop();

        fout << v << " ";

        for (int sz : adj[v]) {
            --gr[sz];
            if (gr[sz] == 0)
                akt.push(sz);
        }
    }

    fout << endl;
    return 0;
}

