#include <bits/stdc++.h>

int n, m;
std::ifstream fin("sortaret.in");
std::ofstream fout("sortaret.out");

std::vector<std::vector<int>> adj;
std::vector<bool> visited;
std::vector<int> result;

void DFS(int node) {
    visited[node] = true;
    
    for(int neighbor : adj[node]) {
        if(!visited[neighbor]) {
            DFS(neighbor);
        }
    }
    
    result.push_back(node);
}

int main() {
    fin >> n >> m;
    
    adj.resize(n + 1);
    visited.resize(n + 1, false);
    
    for(int i = 0; i < m; ++i) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }
    
    for(int i = 1; i <= n; ++i) {
        if(!visited[i]) {
            DFS(i);
        }
    }
    
    std::reverse(result.begin(), result.end());
    
    for(int x : result)
        fout << x << ' ';
    
    return 0;
}