#include <bits/stdc++.h>
using namespace std;

ifstream fin("polihroniade.in");
ofstream fout("polihroniade.out");

vector<int> h[50002];
int viz[50002], n, m, top;
int st[50002];
set<int> M;
/// d[i] = gradul interior al lui i

void Citire()
{
    int x, y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        h[x].push_back(y);
    }
}

void DFS(int k)
{
    viz[k] = 1;
    for (auto e : h[k])
        if (viz[e] == 0) DFS(e);
    st[++top] = k;
}

void Iterare()
{
    int i;
    for (i = 1; i <= n; i++)
        if (viz[i] == 0) DFS(i);
}

void SortareTop()
{
    Iterare();
    for (int i = n; i > 0; i--)
        fout << st[i] << ' ';
}

int main()
{
    Citire();
    SortareTop();
    return 0;
}
