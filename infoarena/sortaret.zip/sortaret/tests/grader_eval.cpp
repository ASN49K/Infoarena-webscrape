#include <stdio.h>
#include <stdlib.h>

#define FIN "sortaret.in"
#define FOUT "sortaret.out"
#define FOK "sortaret.ok"
#define NMAX 50005

void error(char msg[], int p)
{
	fprintf(stderr, msg);
	printf("%d", p);
	exit(0);
}

int N, M;
int poz[NMAX];
int Q[100010][3], ind, cnt[NMAX];

int main(void)
{
    int i;
    FILE *f;

    f = fopen(FIN, "r");
    if (!f) error("Nu am putut deschide fisierul de intrare", 0);
    
    if ( fscanf(f, "%d %d", &N, &M ) != 2 )
        error("Eroare in fisierul de intrare", 0);
                
    if  (N < 1 || N > 50000 || M < 1 || M > 100000 )
        error("Fisierul de intrare nu respecta restrictiile", 0);

    int A, B;

    for (i = 0; i < M; i++)
    {
        if (fscanf(f, "%d %d", &A, &B) != 2)
            error("Eroare in fisierul de intrare", 0);
        
        if ( A < 1 || A > N  || B < 1 || B > N || A == B)
            error("Fisierul de intrare nu respecta restrictiile", 0);    

        Q[++ind][0] = A;
        Q[ind][1] = B;
    }

    f = fopen(FOUT, "r");
    if (!f) error("Fisier de iesire inexistent", 0);
    
    for ( i = 1; i <= N; ++i )
    {
        if ( fscanf( f, "%d", &A ) != 1 ) 
           error("Prea putine noduri afisate", 0); // nu afiseaza N numere in sortare
        if ( A < 1 || A > N )
           error("Indicele unui nod nu se afla intre 1 si N", 0);
           // are numere care nu se incadreaza in limite

        poz[A] = i;//notez pozitia lui in sirul concurentului
        cnt[A]++;
        if(cnt[A] > 1) error("Un nod apare de mai multe ori", 0);
    }        
    bool ok = true;
    for ( i = 1; i <= ind; ++i )
    {
        if ( poz[Q[i][0]] > poz[Q[i][1]] ) 
        {
             ok = false;
             break;
        }
    }
    if ( ok == true ) error("OK", 10);
    else error("Raspuns gresit", 0);

    return 0;
}

