#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <set>
#include <vector>

#define FIN "ciclueuler.in"
#define FOUT "ciclueuler.out"
#define FOK "ciclueuler.ok"

using namespace std;

multiset< pair<int, int> > S;

int N, M, ok;
vector< int > out;

void result(char msg[], int p) {
    fprintf( stderr, msg );
    fprintf( stdout, "%d", p );
    exit( 0 );
}

int main() {
    int i, v, w;
    multiset< pair< int, int > >:: iterator p;
    char msg[256];
    FILE *f;

    f = fopen( FIN, "r" );
    if( !f )
        result( "Fisier de intrare lipsa!", 0 );

    if( fscanf( f, "%d %d", &N, &M ) != 2 )
        result( "Fisier de intrare corupt!", 0 );
    if( N < 1 || N > 100000 || M < 1 || M > 500000 )
        result( "Fisier de intrare corupt!", 0 );
    for( i = 1; i <= M; i++ ) {
        if( fscanf( f, "%d %d", &v, &w ) != 2 )
            result( "Fisier de intrare corupt!", 0 );
        if( v < 1 || v > N || w < 1 || w > N )
            result( "Fisier de intrare corupt!", 0 );
        if( v > w )
            swap( v, w );
        S.insert( make_pair( v, w ) );
    }

    f = fopen( FOK, "r" );
    if( !f )
        result( "Fisier ok lipsa!", 0 );
    if( fscanf( f, "%d", &ok ) != 1 )
        result( "Fisier ok corupt!", 0 );
    if( ok != -1 && ok != 1 )
        result( "Fisier ok corupt!", 0 );

    f = fopen( FOUT, "r" );
    if( !f )
        result( "Fisier de iesire lipsa!", 0 );

    if( fscanf( f, "%d", &v ) != 1 )
        result( "Fisier de iesire corupt!", 0 );
    if( ok == -1 ) {
        if( v == -1 )
            result( "Raspuns corect!", 10 );
        else
            result( "Raspuns gresit!", 0 );
    }

    if( v == -1 )
        result( "Raspuns gresit!", 0 );
    if( v < 1 || v > N )
        result( "Fisier de iesire corupt!", 0 );

    out.push_back( v );
    for( i = 2; i <= M; i++ ) {
        if( fscanf( f, "%d", &w ) != 1 )
            result( "Fisier de iesire corupt!", 0 );
        if( w < 1 || w > N )
            result( "Fisier de iesire corupt!", 0 );
        out.push_back( w );
    }
    out.push_back( out[0] );

    for( i = 1; i <= M; i++ ) {
        v = out[i-1], w = out[i];
        if( v > w )
            swap( v, w );
        p = S.find( make_pair( v, w ) );
        if( p == S.end() )
            result( "Folosesti muchii care nu apartin grafului!", 0 );
        else
            S.erase( p );
    }
    result( "Raspuns corect!", 10 );

    return 0;
}
