#include <fstream>
#include <vector>
#define NMAX 100001
#define MMAX 500001
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m,x,y,vf,cnt,g[NMAX],poz[NMAX],st[MMAX],viz[MMAX],sol[MMAX];
struct muchie {
    int x,y;
};
vector<muchie> l[NMAX];
int main() {
    fin>>n>>m;
    for (int i=1;i<=m;i++) {
        fin>>x>>y;
        l[x].push_back({y,i});
        l[y].push_back({x,i});
        g[x]++;
        g[y]++;
    }
    for (int i=1;i<=n;i++)
        if (g[i]%2!=0) {
            fout<<-1;
            return 0;
        }
    vf=1;
    st[1]=1;
    while (vf!=0) {
        int nod=st[vf];
        if (g[nod]==0) {
            vf--;
            sol[++cnt]=nod;
            continue;
        }
        for (int j=poz[nod];j<l[nod].size();j++)
            if (viz[l[nod][j].y]==0) {
                st[++vf]=l[nod][j].x;
                g[nod]--;
                g[l[nod][j].x]--;
                viz[l[nod][j].y]=1;
                poz[nod]=j+1;
                break;
            }
    }
    for (int i=1;i<cnt;i++)
        fout<<sol[i]<<" ";
    return 0;
}
