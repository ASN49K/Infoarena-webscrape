#include <fstream>
#include <vector>
#define NMAX 100005
#define MMAX 500005
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m;
vector <int> G[NMAX];
struct muchie{int x,y,uz;};
muchie M[MMAX];
vector <int>C;
void citire();
bool grade_pare();
void euler(int x);
int main()
{int i;
    citire();
    if(!grade_pare()) fout<<-1<<'\n';
        else

    {euler(1);
    if(C.size()!=m+1) fout<<-1<<'\n';
        else
       for(i=0;i<C.size()-1;i++) fout<<C[i]<<' ';
    }
    return 0;
}
void citire()
{int i,x,y;
    fin>>n>>m;
    for(i=1;i<=m;i++)
        {
        fin>>x>>y;
        M[i].x=x;
        M[i].y=y;
        G[x].push_back(i);
        G[y].push_back(i);
        }
}
bool grade_pare()
{int i;
    for(i=1;i<=n;i++)
        if(G[i].size()%2) return 0;
    return 1;
}
void euler(int x)
{int nr,y,i;
    ///pargurg lista de adiacenta a lui x de la coada la cap
    while(!G[x].empty())
        {
        nr=G[x].back();
        G[x].pop_back();
        if(M[nr].uz==0)
            {
            M[nr].uz=1;
            if(M[nr].x==x) y=M[nr].y;
                else y=M[nr].x;
            euler(y);
            }
        }
    C.push_back(x);
}
