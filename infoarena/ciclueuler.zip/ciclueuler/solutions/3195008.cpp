#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#define N 100003
#define M 500003
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

vector< vector <pair<int, int> > > L(N);

int ciclu[M],n,m,k;
bool sel[M];

void euler(int x)
{ int y,i;
  pair<int, int> a;
  while(L[x].size())
  {
     a=L[x].back();
     L[x].pop_back();
     y=a.first; i=a.second;
     if(!sel[i])
     {
       sel[i]=true;
       euler(y);
     }
  }
  ciclu[++k]=x;
}

int main()
{
   int i,x,y;
   f>>n>>m;
   for (i=1; i<=m; i++)
   {
     f>>x>>y;
     L[x].push_back(make_pair(y,i));
     L[y].push_back(make_pair(x,i));
   }
   int eul=1;
   for (i=1; i<=n; i++)
   {
       if(L[i].size()%2!=0) eul=0;
   }
   if(eul==0) g<<"-1";
   else
   {
     euler(1);
     for (i=1; i<k; i++) g<<ciclu[i]<<" ";
   }
    return 0;
}
