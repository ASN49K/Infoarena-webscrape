#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in ("ciclueuler.in");
ofstream out ("ciclueuler.out");

const int max_size = 1e5 + 1, max_mc = 5e5 + 1;

int viz[max_mc];
stack <int> stiva;
vector <pair <int, int>> mc[max_size];

int main ()
{
    int n, m;
    in >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        mc[x].push_back({y, i});
        mc[y].push_back({x, i});
    }
    for (int i = 1; i <= n; i++)
    {
        if (mc[i].size() % 2 == 1)
        {
            out << -1;
            return 0;
        }
    }
    stiva.push(1);
    for (int i = 1; i <= m; i++)
    {
        int nod = stiva.top();
        while (!mc[nod].empty())
        {
            int urm = mc[nod].back().first, idx = mc[nod].back().second;
            mc[nod].pop_back();
            if (viz[idx] == 1)
            {
                continue;
            }
            viz[idx] = 1;
            nod = urm;
            stiva.push(nod);
        }
        stiva.pop();
        out << nod << " ";
    }
    in.close();
    out.close();
    return 0;
}
