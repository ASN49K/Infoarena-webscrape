#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, i, j, x, y, k, ans[100005];
bool viz[100005];
vector <pair<int, int>> v[100005];
stack <int> st;
void ciclu_euler(int nod)
{
    st.push(nod);
    while(!st.empty())
    {
        x=st.top();
        if(v[x].size()==0)
        {
            ans[++k]=x;
            st.pop();
        }
        else
        {
            while(!v[x].empty() && viz[v[x].back().second]==1)
                v[x].pop_back();
            if(!v[x].empty())
            {
                viz[v[x].back().second]=1;
                st.push(v[x].back().first);
                v[x].pop_back();
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back({y, i});
        v[y].push_back({x, i});
    }
    for(i=1; i<=n; i++)
        if(v[i].size()%2)
    {
        fout<<-1;
        return 0;
    }
    ciclu_euler(1);
    for(i=1; i<k; i++)
        fout<<ans[i]<<" ";
    return 0;
}
