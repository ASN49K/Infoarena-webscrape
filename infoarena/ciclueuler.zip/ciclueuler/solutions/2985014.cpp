#include <iostream>
#include <fstream>
#include <stack>
#include <vector>

using namespace std;

int n, m, L[200005], k;
vector <int> V[100001];
stack <int> S;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

void citire()
{
    in >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        V[x].push_back(y);
        V[y].push_back(x);
    }
}

void afisare(int v[], int n)
{
    for(int i = 1; i < n; i++)
        out << v[i] << " ";
}

void stiva()
{
    S.push(1);
    while(!S.empty())
    {
        int nod = S.top();
        if(!V[nod].empty())
        {
            int x = V[nod][0];
            V[nod].erase(V[nod].begin());
            for(int i = 0; i < V[x].size(); i++)
            if(V[x][i] == nod)
            {
                V[x].erase(V[x].begin() + i);
                break;
            }
            S.push(x);
        }
        else
        {
            S.pop();
            L[++k] = nod;
        }
    }
}

bool verif()
{
    for(int i = 1; i <= n; i++)
        if(V[i].size() == 0 || V[i].size() % 2 == 1)
        return false;
    return true;
}

int main()
{
    citire();
    if(verif() == false)
        out << -1;
    else
    {
        stiva();
        afisare(L, k);
    }
    in.close();
    out.close();
    return 0;
}
