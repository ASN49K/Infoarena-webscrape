#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

vector<pair<int, int> > vec[100005];
vector<int> sol;
int viz[500005], grade[100005];

void euler(int nod){
    for(pair<int, int> v : vec[nod]){
        int muchie = v.second;
        if(!viz[muchie]){
            viz[muchie] = 1;
            euler(v.first);
        }
    }
    sol.push_back(nod);
}

int main(){
    int n, m;
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        fin>>x>>y;
        vec[x].push_back(make_pair(y, i));
        vec[y].push_back(make_pair(x, i));
        grade[x]++;
        grade[y]++;
    }
    
    for(int i=1; i<=n; i++)
        if(grade[i]%2 == 1)
        {
            fout<<-1;
            return 0;
        }
    
    euler(1);

    for(int i : sol)
        fout<<i<<' ';

    return 0;
}