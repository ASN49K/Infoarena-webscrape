#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
string __fname = "ciclueuler"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define sz(x)(int) x.size()
#define pb(x) push_back(x)
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define ss cout << " "
#define nn cout << "\n"
#define ct(x) cout << (x)
#define cts(x) cout << (x) << " "
#define ctn(x) cout << (x) << "\n"
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
#define rt return
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
const double pi = 3.14159265359;
const int64 mod = 1000000007;
const int64 hash_p = 101;
const int64 hash_inv = 940594066;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
pii edge[500001];
vector <int> v[100001];
vector <bool> used(500001);
 
void solve(int id){
 
    rt;
}
 

void euler (int x) {
    cts(x);
    while (!v[x].empty()) {
        int i = v[x].back();
        v[x].pop_back();
        if (used[i]) continue;
        int next = (edge[i].first != x ? edge[i].first : edge[i].second);
        used[i] = 1;
        euler(next);
    }
}
 
 
int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); ct(fixed); ct(setprecision(10)); 
    int n,m;
    cin >> n >> m;
    for (int i = 0; i < m; i++){
        int x,y;
        cin >> x >> y;
        v[x].pb(i);
        v[y].pb(i);
        edge[i] = {x,y};
    }
    for (int i = 1; i <= n; i++){
        if (sz(v[i]) % 2 == 1) {
            ctn("-1");
            rt 0;
        }
    }
    euler(1);
    rt 0;
}