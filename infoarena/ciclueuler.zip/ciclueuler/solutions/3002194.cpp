#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct muchie {
    int nod, typ;
    bool operator < (const muchie &ceva) const {
        if(ceva.typ == typ) {
            return ceva.nod < nod;
        }
        return ceva.typ > typ;
    }
};

int N, M;

bool vizi[100001];

vector<int> adi[100001];
multiset<int> inainte[100001];
multiset<int> inapoi[100001];

void dfs(int nod, int vechi) {
    //cout << "sunt in  " << nod << "\n";
    vizi[nod] = true;
    for(auto it : adi[nod]) {
        if(!vizi[it]) {

            inainte[nod].insert(it);
            inainte[it].insert(nod);

            dfs(it, nod);
        }
        else if(it != vechi) {
            cout << "inserez cu prioritate 0: " << nod << " " << it << "\n";
            inapoi[nod].insert(it);
            
            if(it != nod) {
                inapoi[it].insert(nod);
            }
            
        }
    }
}

void euler(int nod) {
    
    //fout << "are lungimea " << adi2[nod].size() << "\n";
    // for(auto it : adi2[nod]) {
    //     fout << "spre " << (it.nod) << "cu prioritate " << it.typ << ", ";
    // }
    // fout << "\n";
    if(inainte[nod].size() == 0 && inapoi[nod].size() == 0) {
        //fout << "S-a goliit\n";
        return;
    }
    fout << nod << " ";
    int nou;
    if(inapoi[nod].size() == 0) {
        nou = *inainte[nod].begin();
        inainte[nod].erase(nou);
        inainte[nou].erase(nod);
    }
    else {
        nou = *inapoi[nod].begin();
        inapoi[nod].erase(nou);
        if(nou != nod) {
            inapoi[nou].erase(nod);
        }
    }
    euler(nou);





    // auto it = adi2[nod].begin();
    // //mergem in acest nod, dar stergem si muchia
    // int nou = it->nod;
    // int tp = it->typ;
    // muchie y;
    // y.nod = nou;
    // y.typ = tp;
    // adi2[nod].erase(y);
    // if(nou != nod) {
    //     y.nod = nod;
    //     adi2[nou].erase(y);
    // }
        

    // euler(nou);
}

int main() {
    fin >> N >> M;
    int a, b, start;
    for(int i = 1; i <= M; i++) {
        fin >> a >> b;
        adi[a].push_back(b);
        if(a != b)
            adi[b].push_back(a);
    }
    start = 1;
    dfs(start, -1);
    for(int i = 1; i <= N; i++) {
        adi[i].clear();
    }
    euler(start);
    return 0;
}
