#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

//int g[100000][100000] = {0};
int v[100001] = {0};
int n, m, con = 0;

vector<int> g[500001];
vector<int> e;
ofstream out("ciclueuler.out");

void dfs(int i)
{
    out << i << ' ';
    int j = g[i].size()-1; // length of adjancency list for i
    
    if (j >= 0) {
        int next = g[i][j];
        g[i].pop_back();
        for (int k = 0; k < g[next].size(); ++k)
            if (g[next][k] == i)
                g[next].erase(g[next].begin() + k);
        
        dfs(next);
    }

}

int main()
{
    ifstream in("ciclueuler.in");
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; ++i)
    {
        in >> x >> y;
        g[x].push_back(y);
        if (y != x)
            g[y].push_back(x);
    }
    for (int i = 1; i <= n; ++i)
    {
        cout << i << ": ";
        for (int j = 0; j < g[i].size(); ++j)
            cout << g[i][j] << " ";
        cout << '\n';
    }
    dfs(1);
    //cout << "new graph:\n";
    //for (int i = 1; i <= n; ++i)
    //{
        //cout << i << ": ";
        //for (int j = 0; j < g[i].size(); ++j)
        //    cout << g[i][j] << " ";
        //cout << g[i].size() << "\n";
    //}
    out << con;
    in.close();
    out.close();
    return 0;
}