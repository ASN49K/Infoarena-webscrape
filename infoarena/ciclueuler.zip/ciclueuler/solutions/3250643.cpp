#include <bits/stdc++.h>

using namespace std;
int k=0,v[100001],sol[500001],t;
bool  vc[500001];
vector <pair<int,int>> g[100001];
void dfs(int nod)
{
    while(v[nod]<g[nod].size())
    {
        if(!vc[g[nod][v[nod]].second])
        {
            vc[g[nod][v[nod]].second]=true;
            dfs(g[nod][v[nod]++].first);
        }
        else
            v[nod]++;
    }
    sol[++t]=nod;
    k--;
}
int main()
{
    freopen("ciclueuler.in","r",stdin);
    freopen("ciclueuler.out","w",stdout);
    ios :: sync_with_stdio(false);
    cin.tie(0);
    int n,m,x,y,i;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        g[x].push_back(make_pair(y,i));
        g[y].push_back(make_pair(x,i));
    }
    bool ok=true;
    for(i=1;i<=n&&ok;i++)
        if(g[i].size()%2)
            ok=false;
    if(!ok)
        cout<<-1;
    else
    {
        dfs(1);
        for(i=1;i<t;i++)
            cout<<sol[i]<<" ";
    }
    return 0;
}
