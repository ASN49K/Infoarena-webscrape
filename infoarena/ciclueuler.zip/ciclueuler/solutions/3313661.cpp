#include <fstream>
#include <vector>
#include <bitset>

using namespace std;
const int MMAX = 5e5;
const int NMAX = 2e5;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

pair <int, int> edge[MMAX + 2];
vector <vector <pair <int, int>>>v; ///first = nod, second = id

int used[NMAX + 2]; ///primul vecin nefolosit din lista de adj
bitset <MMAX + 2> viz; ///muchiile
vector <int> ans;
void dfs(int start) {
    while(used[start] < v[start].size()) {
        int nod = v[start][used[start]].first;
        int id = v[start][used[start]].second;
        used[start]++;
        if(!viz[id]) {
            viz[id] = 1;
            dfs(nod);
        }
    }
    ans.push_back(start);
}
int main() {
    int n, m;
    cin >> n >> m;
    v.resize(n + 1);
    for(int i = 1; i <= m; i++) {
        cin >> edge[i].first >> edge[i].second;
        v[edge[i].first].push_back({edge[i].second, i});
        v[edge[i].second].push_back({edge[i].first, i});
    }
    for(int i = 1; i <= n; i++) {
        if(v[i].size() % 2) {
            cout << "-1";
            return 0;
        }
    }
    dfs(1);
    ans.pop_back();
    for(auto x : ans)
        cout << x << " ";
    return 0;
}