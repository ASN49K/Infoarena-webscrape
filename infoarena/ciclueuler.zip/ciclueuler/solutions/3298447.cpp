#include <iostream>
#include <fstream>
#include <vector>
#define pb push_back
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int MAXN=1e5,MAXM=5e5;
int n,i,m,nod1,nod2,degree[MAXN+5],nr;
vector <pair<int,int>> muchii[MAXN+5];
vector <int> ans;
bool vizmuchie[MAXM+5],viz[MAXN+5];

void dfs(int nod)
{
    viz[nod]=1;
    nr++;

    for (auto x: muchii[nod])
    {
        nod2=x.first;

        if (!viz[nod2])
            dfs(nod2);
    }
}

void Euler(int nod)
{
    while (!muchii[nod].empty())
    {
        pair <int,int> x=muchii[nod].back();
        muchii[nod].pop_back();
        int nod2=x.first,ind=x.second;

        if (!vizmuchie[ind])
        {
            vizmuchie[ind]=1;
            Euler(nod2);
        }


    }


    ans.pb(nod);
}

int main()
{
    fin>>n>>m;

    while (m)
    {
        fin>>nod1>>nod2;
        muchii[nod1].pb({nod2,m});
        muchii[nod2].pb({nod1,m});
        degree[nod1]++;
        degree[nod2]++;

        m--;
    }

    for (i=1; i<=n; i++)
        if (degree[i]%2==1)
            {
                fout<<-1;
                return 0;
            }

    dfs(1);

    if (nr!=n)
    {
        fout<<-1;
        return 0;
    }

    Euler(1);

    for (auto x: ans)
        fout<<x<<" ";

    return 0;
}
