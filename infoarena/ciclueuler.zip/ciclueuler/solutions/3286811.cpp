#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

#include <iomanip>

#define vt vector
#define pb push_back
#define sz(x) (int)(x).size()
#define all(x) (x).begin(), (x).end()
#define pii pair <int, int>

#define fr first 
#define sc second

using namespace std;

string filename = "ciclueuler";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

////////////////////////////////////////////////////////////

const int NMAX = 5e5;

pii edges[NMAX + 1];
vt <int> adj[NMAX + 1];
bool viz[NMAX + 1];

void solve(){
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        edges[i] = {a, b};
        adj[a].pb(i);
        adj[b].pb(i);
    }

    for(int i = 1; i <= n; i++){
        if(sz(adj[i]) & 1){
            fout << -1 << '\n';
            return;
        }
    }

    vt <int> oiler;

    stack <int> S;
    S.push(1);

    while(!S.empty()){
        int node = S.top();

        if(sz(adj[node]) > 0){
            int vec = adj[node].back();
            adj[node].pop_back();

            if(!viz[vec]){
                viz[vec] = 1;
                int other = (node ^ edges[vec].fr ^ edges[vec].sc);
                S.push(other);
            }
        }else{
            S.pop();
            oiler.pb(node);
        }
    }

    oiler.pop_back();

    for(int x : oiler){
        fout << x << ' ';
    }
    fout << '\n';
}

int main(){

    int T;
    //fin >> T;

    T = 1;

    while(T--){
        solve();
    }

    return 0;
}