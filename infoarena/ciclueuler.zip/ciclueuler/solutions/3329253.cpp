#include <bits/stdc++.h>
using namespace std;

const int M_MAX = 500001;
const int N_MAX = 100001;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int X[M_MAX], Y[M_MAX];
bool viz[M_MAX];
vector<int> G[N_MAX];

void euler(int nod) {
    for(auto x : G[nod]) {
        if(viz[x] == 0) {
            viz[x] = 1;
            euler(X[x] + Y[x] - nod);
        }
    }
    fout << nod << ' ';
}

int main() {
    int N, M;
    fin >> N >> M;

    for(int i = 1;i <= M; ++i)
    {
        fin >> X[i] >> Y[i];
        G[X[i]].push_back(i);
        G[Y[i]].push_back(i);
    }

    for(int i = 1; i <= N; ++i)
        if((int)G[i].size() % 2 == 1)
        {
            fout << -1;
            return 0;
        }

    euler(1);
    return 0;
}
