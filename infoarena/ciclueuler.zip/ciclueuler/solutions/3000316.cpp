#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

#define nmax 100005

vector <pair <int, int>> a[nmax];
vector <int> rez;
stack <int> st;

bool q[500005];
int nodcurent,vecin,c,k1,k2,i,n,m,ok;

void euler()
{
    while(st.empty()==0)
    {
        nodcurent=st.top();

        if(a[nodcurent].size()>0)
        {
            vecin=a[nodcurent].back().first;
            c=a[nodcurent].back().second;
            a[nodcurent].pop_back();

            if(q[c]==0)
            {
                q[c]=1;
                st.push(vecin);
            }

        }
        else
        {
            rez.push_back(nodcurent);
            st.pop();
        }

    }
}

int main()
{
    f>>n>>m;

    for(i=1;i<=m;i++)
    {
        f>>k1>>k2;
        a[k1].push_back(make_pair (k2,i));
        a[k2].push_back(make_pair (k1,i));
    }

    for(i=1;i<=n;i++)
    {
        if(a[i].size()%2!=0)
            ok=1;
    }
    if(ok==1)
    {
        g<<-1;
    }
    else
    {
        st.push(1);
        euler();
    }
    for(i=0;i<rez.size()-1;i++)
    {
        g<<rez[i]<<" ";
    }


    return 0;
}
