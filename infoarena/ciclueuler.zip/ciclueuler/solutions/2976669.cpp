#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int N=100005,M=500005;
int n,m,grad[N];
vector<int>v[N];
int from[M],to[M];
bool usededge[M];

void citire()
{
    fin>>n>>m;
    int x,y;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(i);
        v[y].push_back(i);
        from[i]=x;
        to[i]=y;
    }
}



void rezolvare()
{
    vector<int>ans;
    vector<int>stk;
    for(int i=1;i<=n;i++){
        int cnt=v[i].size();
        if(cnt%2!=0)
            {
                fout<<-1;
                return ;
            }
    }
    stk.push_back(1);
    while(!stk.empty())
    {
        int node=stk.back();
        if(!v[node].empty())
        {
            int e=v[node].back();
            v[node].pop_back();
            if(!usededge[e])
            {
                usededge[e]=true;
                int k= from[e] ^ to[e] ^ node;
                stk.push_back(k);
            }
        }
            else
            {
                stk.pop_back();
                ans.push_back(node);
            }
    }
   for(int i=0;i<ans.size()-1;i++)
        fout<<ans[i]<<" ";
}

int main()
{
    citire();
    rezolvare();
    return 0;
}
