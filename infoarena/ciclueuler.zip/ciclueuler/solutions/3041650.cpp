#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
int n,m;
const int N=1e5+5;
bool viz[5*N];
struct pct
{
    int x,y;
};
vector<pct>a[N];
vector<int>sol;
stack<int>st;
int main()
{
    f>>n>>m;
    int x,y,start;
    for(int i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x].push_back({y,i});
        a[y].push_back({x,i});
        start=x;
    }
    for(int i=1;i<=n;i++)
        if(a[i].size()%2)
        {
            g<<-1;
            return 0;
        }
    st.push(start);
    while(!st.empty())
    {
        int nod=st.top();
        while(!a[nod].empty())
        {
            pct X=a[nod].back();
            a[nod].pop_back();
            if(!viz[X.y])
            {
                viz[X.y]=true;
                st.push(X.x);
                nod=X.x;
            }
        }
        st.pop();
        sol.push_back(nod);
    }
    sol.pop_back();
    for(auto x: sol)
        g<<x<<" ";
    return 0;
}
