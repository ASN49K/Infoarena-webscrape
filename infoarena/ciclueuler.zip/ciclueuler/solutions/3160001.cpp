#include <fstream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int start=1,i,n,m,rsp[500001],nr,noduriramas[100001];

struct nodus
{
    int nod,poz;
    bool viz;
};

vector<nodus> graf_muchii[100001];

void eulerian(int nodincep)
{
    stack<int>sk;
    sk.push(nodincep);

    while(!sk.empty())
    {

        int nod=sk.top();

        for(auto &vecin:graf_muchii[nod])
        {
            if(!vecin.viz)
            {

                vecin.viz=1;
                graf_muchii[vecin.nod][vecin.poz].viz=1;
                noduriramas[vecin.nod]--;
                noduriramas[graf_muchii[vecin.nod][vecin.poz].nod]--;

                sk.push(vecin.nod);
                break;
            }
        }
        if(noduriramas[sk.top()]==0)
        {nr++;
        rsp[nr]=sk.top();
        sk.pop();
        }
    }
}

bool prea_mult_impar()
{

    for(i=1; i<=n; i++)
    {
        if(graf_muchii[i].size()%2==1)
        {
            return 0;
        }
        noduriramas[i]=graf_muchii[i].size();
    }

    return 1;

}
bool conex()
{
    bool viz[100001]= {0};
    int nodviz=1;
    queue<int> que;
    que.push(1);
    viz[1]=1;

    while(!que.empty())
    {
        int nod=que.front();
        que.pop();

        for(auto vecin:graf_muchii[nod])
        {

            if(!viz[vecin.nod])
            {
                nodviz++;
                viz[vecin.nod]=1;
                que.push(vecin.nod);
            }

        }


    }
    return nodviz==n;
}

int main()
{
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        nodus crt;
        int x,y;
        cin>>x>>y;

        crt.nod=y;
        crt.poz=graf_muchii[y].size();

        if(x==y)
            crt.poz++;

        graf_muchii[x].push_back(crt);

        crt.nod=x;
        crt.poz=graf_muchii[x].size()-1;

        graf_muchii[y].push_back(crt);

    }

    if(!conex())
    {
        cout<<-1;
        return 0;
    }
    if(!prea_mult_impar())
    {
        cout<<-1;
        return 0;
    }
    eulerian(1);
    for(i=1;i<nr;i++)
        cout<<rsp[i]<<" ";

    return 0;
}
