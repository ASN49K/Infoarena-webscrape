#include <fstream>
#include <vector>
#define MAXN 100000
#define MAXM 500000
using namespace std;
ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");
int deg[MAXN + 10], usedEdge[MAXM + 10];
vector <pair <int, int>> graph[MAXN + 10];
void euler(int node)
{
    while (!graph[node].empty())
    {
        int next = graph[node].back().first;
        int edge = graph[node].back().second;
        graph[node].pop_back();
        if (usedEdge[edge] == 0)
        {
            usedEdge[edge] = 1;
            euler(next);
        }
    }
    cout << node << ' ';
}
int main()
{
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back({y, i});
        graph[y].push_back({x, i});
        deg[x]++;
        deg[y]++;
    }
    int ok = 1;
    for (int i = 1; i <= n && ok == 1; i++)
        if (deg[i] % 2 == 1)
            ok = 0;
    if (ok == 0)
        cout << -1;
    else
        euler(1);
    return 0;
}
