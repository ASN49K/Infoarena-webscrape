#include <fstream>
#include<vector>


using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector<vector<pair<int,int>>> graph;
vector<bool> indice;
vector<int> grade;
vector<int> ciclu;

int n, m;

void euler(int node)
{
    while(graph[node].size())
    {
        auto w = graph[node].back();
        graph[node].pop_back();
        if(!indice[w.second])
        {
            indice[w.second] = 1;
            euler(w.first);
        }
    }
    /*
    varianta 80pt
    for( auto w : graph[node])
    {
        if(!indice[w.second])
        {   indice[w.second] = 1;
            euler(w.first);
        }
    }
    */
    ciclu.push_back(node);
}

int main()
{
    fin >> n >> m;
    graph.resize(n+1);
    indice.resize(m+1, 0);
    grade.resize(n+1, 0);
    while(m)
    {
        int x, y;
        fin >> x >> y;
        grade[x]++;
        grade[y]++;
        graph[x].push_back({y, m});
        graph[y].push_back({x, m});
        m--;
    }
    for(int i = 0; i < grade.size(); i++)
        if(grade[i]%2)
        {
            fout << "-1";
            fout.close();
            return 0;
        }
    euler(1);
    if(ciclu.size() >= m)
    {
        for(int i = 0; i < ciclu.size() - 1; i++)
            fout << ciclu[i] << " ";
    }
    else
        fout << "-1";
    fout.close();
    return 0;
}
