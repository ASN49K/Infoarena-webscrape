#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 1e5;

int n, m;
vector<int> adj[NMAX + 1];

struct Edge {
	int u, v;
	bool visited;

	int other(int node) {
		return u ^ v ^ node;
	}
};

vector<Edge> edges;
vector<int> cycle;

void addEdge(int u, int v) {
	int m = edges.size();
	edges.push_back({u, v, 0});
	adj[u].push_back(m);
	adj[v].push_back(m);
}

void euler(int u) {
	while(adj[u].size() > 0) {
		int it = adj[u].back();
		adj[u].pop_back();

		int v = edges[it].other(u);

		if(edges[it].visited == 0) {
			edges[it].visited = 1;
			euler(v);
		}
	}

	cycle.push_back(u);
}

int main() {
	ios_base :: sync_with_stdio(false);

	fin >> n >> m;

	for(int i = 0; i < m; i++) {
		int u, v;
		fin >> u >> v;

		addEdge(u, v);
	}
	
	int start = 1;
	for(int i = 1; i <= n; i++) {
		if(adj[i].size() > 0) {
			start = i;
			if((adj[i].size() & 1) != 0) {
				fout << "-1\n";

				fin.close();
				fout.close();
				return 0;
			}
		}
	}

	euler(start);

	reverse(cycle.begin(), cycle.end());
	cycle.pop_back();

	if((int) cycle.size() < m) {
		fout << "-1\n";
		
		fin.close();
		fout.close();
		return 0;
	}

	for(const int &it: cycle) {
		fout << it << " ";
	}
	fout << '\n';

	fin.close();
	fout.close();
	return 0;
}