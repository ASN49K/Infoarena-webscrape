#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
multiset <int> G[100002];
vector <int> c;
void euler(int nod){
    while(!G[nod].empty()){
        auto it = G[nod].end();
        --it;
        int new_nod = *it;
        G[nod].erase(it);
        G[new_nod].erase(G[new_nod].find(nod));
        c.push_back(nod);
        nod = new_nod;
    }
}
int main()
{
    int n,m,i,u,v;
    fin >> n >> m;
    for(i = 1; i <= m; i++){
        fin >> u >> v;
        G[u].insert(v);
        G[v].insert(u);
    }
    euler(1);
    for(i = 1; i <= n; i++){
        if(!G[i].empty()){
            fout << 1;
            return 0;
        }
    }
    for(auto x : c) fout << x << " ";
    return 0;
}
