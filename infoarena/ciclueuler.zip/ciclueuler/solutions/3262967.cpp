#include <iostream>
#include <vector>
#include <utility>
#include <bitset>

constexpr const int mMax = 5e5;
constexpr const int nMax = 1e5;

void DFS(std::vector<std::vector<std::pair<int, int>>>& graph, std::bitset<nMax>& vis, int node) {
    vis[node] = true;
    for (auto& neighbour : graph[node]) {
        if (vis[neighbour.first] == false) {
            DFS(graph, vis, neighbour.first);
        }
    }
}

std::vector<int> sol;

void euler(std::vector<std::vector<std::pair<int, int>>>& graph, std::bitset<mMax>& visEdges, int node) {
    while (graph[node].size() > 0) {
        int neighbour = graph[node].back().first;
        int edgeID = graph[node].back().second;
        graph[node].pop_back();

        if (visEdges[edgeID] == false) {
            visEdges[edgeID] = true;
            euler(graph, visEdges, neighbour);
        }
    }
    sol.push_back(node);
}

int main() {
    std::ifstream fin("ciclueuler.in");
    std::ofstream fout("ciclueuler.out");

    int n, m; std::cin >> n >> m;
    std::vector<int> degree(n, 0);
    std::vector<std::vector<std::pair<int, int>>> graph(n);
    for (int i = 0; i < m; i += 1) {
        int u, v; std::cin >> u >> v; u -= 1, v -= 1;
        graph[u].emplace_back(std::make_pair(v, i));
        graph[v].emplace_back(std::make_pair(u, i));
        degree[u] += 1, degree[v] += 1;
    }

    std::bitset<nMax> vis;
    DFS(graph, vis, 0);

    bool hasCycle = true;
    for (int i = 0; i < n; i += 1) {
        if (vis[i] == false || degree[i] % 2 == 1) {
           hasCycle = false;
        }
    }

    if (hasCycle == false) {
        std::cout << -1;
    } else {
        std::bitset<mMax> visEdges;
        euler(graph, visEdges, 0);

        sol.pop_back();
        for (auto& it : sol) {
            std::cout << it + 1 << ' ';
        }
    }

    fin.close(), fout.close();
    degree.clear(), graph.clear(), sol.clear();
    return 0;
}
