#include <bits/stdc++.h>
#define VMAX 500005
#define INF 1e10
using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");


bool index_[VMAX];
vector<int> ordine;

vector<pair<int,int>> graf[VMAX];

void dfs(int nod)
{
    for(int i=graf[nod].size()-1;i>=0; i--)
    {
        while(graf[nod].size() && index_[graf[nod][i].second])
        {
            graf[nod].pop_back();
            i--;
        }

        if(i<0)
            break;

        index_[graf[nod][i].second]=1;
        graf[nod].pop_back();
        dfs(graf[nod][i].first);

        i=graf[nod].size()-1;

    }
    ordine.push_back(nod);
}

signed main()
{
    ios_base::sync_with_stdio(0);
    int n,m,i,j,k,t,nr,minim,maxim,suma,st,dr,mij;

    fin>>n>>m;

    for(i=0;i<m;i++)
    {
        fin>>j>>k;
        graf[j].push_back({k,i});
        graf[k].push_back({j,i});
    }


    for(i=1;i<=n;i++)
        if(graf[i].size()%2)
            break;

    if(i<=n)
        fout<<"-1\n";
    else
    {
        dfs(1);
        for(auto it:ordine)
            fout<<it<<' ';
        fout<<'\n';
    }
















    return 0;
}
