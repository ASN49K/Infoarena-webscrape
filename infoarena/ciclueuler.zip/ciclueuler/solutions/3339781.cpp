#include <fstream>
#include <vector>
#define NMAX 100002
#define MMAX 500002
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n;
bool sters[MMAX];
struct muchie{int x,nr;};
vector<muchie> G[MMAX];
vector<int> C;

void euler(int x)
{
    muchie m;
    while(!G[x].empty())
        {
         m=G[x].back();
         G[x].pop_back();
         if(!sters[m.nr])
            {
             sters[m.nr]=1;
             euler(m.x);
            }
        }
    C.push_back(x);
}

int main()
{
    int i,nrmuchii,x,y;
    muchie m;
    fin>>n>>nrmuchii;
    for(i=1; i<=nrmuchii; i++)
        {
         fin>>x>>y;
         G[x].push_back({y,i});
         G[y].push_back({x,i});
        }
    for(i=1; i<=n; i++)
        if(G[x].size()%2)
            {
             fout<<-1<<'\n';
             return 0;
            }
    for(x=1; x<=n; x++)
        if(G[x].size())
            {
             euler(x);
             break;
            }
    if(C.size()!=nrmuchii+1)
        {
         fout<<-1<<'\n';
         return 0;
        }
    for(i=0; i<C.size()-1; i++)
        fout<<C[i]<<' ';
    return 0;
}
