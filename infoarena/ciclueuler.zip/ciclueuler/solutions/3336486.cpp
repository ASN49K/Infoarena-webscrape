#include <bits/stdc++.h>
using namespace std;
//Soltan Cristian
#define ll long long
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define pb push_back
#define st first
#define nd second
#define sz(x) (ll)x.size()
#define rall(x) x.rbegin(), x.rend()

const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};

const int mxa = 5 * 1e5 + 1;
string __fname = "ciclueuler";  
ifstream in(__fname + ".in"); 
ofstream out (__fname + ".out"); 
#define cin in 
#define cout out

pair<int, int> edge[mxa];
bool used[mxa];

void solve(){
  int n, m;
  cin >> n >> m;
  vector<vector<int>> adj(n + 1);
  for(int i = 0; i < m; i ++){
    int a, b;
    cin >> a >> b;
    adj[a].pb(i);
    adj[b].pb(i);
    edge[i] = {a, b};
  }
  for(int i = 1; i < n + 1; i++){
    if(sz(adj[i]) % 2 != 0){
      cout << -1 << '\n';
      return;
    }
  }
  stack<int> s;
  vector<int> ans;
  s.push(1);
  while(!s.empty()){
    int x = s.top();
    if(sz(adj[x]) == 0){
      ans.pb(x);
      s.pop();
    }
    else{
      int y = adj[x].back();
      adj[x].pop_back();
      if(used[y]) continue;
      if(x == edge[y].st) s.push(edge[y].nd);
      else s.push(edge[y].st);
      used[x] = true;
    }
  }
  ans.pop_back();
  for(auto i: ans){
      cout << i << ' ';
  }
  cout << '\n';
}
 
 
int main()
{   
    ios_base::sync_with_stdio(0); cin.tie(0); cout << fixed  << (setprecision(6)); 
    // int t;
    // cin >> t;
    // while(t--)
        solve();
    return 0;
}