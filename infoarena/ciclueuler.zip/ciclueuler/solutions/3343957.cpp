#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
#define MOD 1000000007
int viz[500005];
int n, m, i, j, x, y, C,l, p, q,a, w, b, mx = -2e9, mn = 2e9, nr, comp, val, k, c, z;
vector<pair<int,int>> adj[100005];
vector<int> ciclu;

void dfs(int nod)
{
    while(!adj[nod].empty())
    {
        auto top = adj[nod].back();
        adj[nod].pop_back();
        int p = top.first;
        int q = top.second;
        if(viz[q]) continue;
        viz[q] = 1;
        dfs(p);
    }
    ciclu.push_back(nod);
}

int main()
{
    fin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> x >> y;
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
    }
    dfs(1);
    //reverse(ciclu.begin(), ciclu.end());
    if(ciclu.size() == m + 1)
    {

    ciclu.pop_back();
    for(int x : ciclu)
        fout << x << " ";
    }
    else fout << -1;
    return 0;
}

