#include <bits/stdc++.h>
#define t 2e9
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, a[500001], b[500001], d[100002], poz[100005];
int sol[100002], len;
vector<int>L[100001];
bitset<500001>viz;
void Euler(int k)
{
    while (poz[k] < L[k].size())
    {
        int i = L[k][poz[k]];
        poz[k]++;
        if(viz[i] == 0)
        {
            viz[i] = 1;
            if(k == a[i])Euler(b[i]);
            else Euler(a[i]);
        }

    }
    sol[++len] = k;
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i;
    fin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> a[i] >> b[i];
        L[a[i]].push_back(i);
        L[b[i]].push_back(i);
        d[a[i]]++;
        d[b[i]]++;
    }
    for (i = 1; i <= n; i++)
		if (d[i] % 2 == 1)
		{
			fout << "-1\n";
			return 0;
		}
    Euler(a[1]);
    for(i = 1; i < len; i++)
        fout << sol[i] << " ";
    return 0;
}
