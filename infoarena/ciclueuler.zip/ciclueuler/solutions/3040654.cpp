#include <fstream>
#include <queue>
#include <vector>
#include <stack>

using namespace std;

ifstream in ("ciclueuler.in");
ofstream out ("ciclueuler.out");

const int max_size = 1e5 + 1;

vector <pair <int, int>> mc[max_size];
vector <int> ans;
int uz[5 * max_size];
stack <int> stiva;

int main ()
{
    int n, m;
    in >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        mc[x].push_back({y, i});
        mc[y].push_back({x, i});
    }
    for (int i = 1; i <= n; i++)
    {
        if (mc[i].size() % 2 == 1)
        {
            out << -1;
            return 0;
        }
    }
    stiva.push(1);
    for (int i = 1; i <= m; i++)
    {
        int nod = stiva.top();
        while (!mc[nod].empty())
        {
            pair <int, int> urm = mc[nod].back();
            mc[nod].pop_back();
            if (uz[urm.second])
            {
                continue;
            }
            uz[urm.second] = 1;
            nod = urm.first;
            stiva.push(nod);
        }
        ans.push_back(nod);
        stiva.pop();
    }
    for (auto f : ans)
    {
        out << f << " ";
    }
    in.close();
    out.close();
    return 0;
}
