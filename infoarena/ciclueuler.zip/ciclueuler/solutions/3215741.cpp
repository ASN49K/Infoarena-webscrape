#include <bits/stdc++.h>
using namespace std;
using pii = pair<int, int>;
#define pb push_back
#define fi first 
#define se second

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int N = 1e5+3;
const int M = 5e5+3;

int n;
bitset<M> u;
queue<int> r;
vector<pii> e;
vector<vector<int>> ad;

void read(), check(), euler();

int main()
{
    read();
    check();
    euler();
    r.pop();
    while (!r.empty()) { fout << r.front() << ' '; r.pop(); }

    return 0;
}

void read(){
    int m; fin >> n >> m;
    ad.resize(n+3);
    for (int i = 0; i < m; i++){
        int a, b; fin >> a >> b;
        ad[a].pb(i); ad[b].pb(i);
        e.pb({a, b});
    }
}
void check(){
    for (int i = 1; i <= n; i++)
        if (ad[i].size() % 2) {fout << -1; exit(0);}
}
void euler(){
    stack<int> stk; stk.push(1);
    while (!stk.empty()){
        int nod = stk.top();
        if (ad[nod].size()){
            int m = ad[nod].back(); ad[nod].pop_back();
            if (u[m]) continue; u[m] = 1;
            stk.push(e[m].fi == nod ? e[m].se : e[m].fi);
        }
        else {
            stk.pop();
            r.push(nod);
        }
    }

}

//12:13