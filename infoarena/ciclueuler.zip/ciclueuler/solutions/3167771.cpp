#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, x, y, a, b, v[1005][1005], q[1005], nr;

void euler (int x) {
    for (int i=1; i<=n; i++) {
        if (v[x][i]) {
            v[x][i]=0;
            v[i][x]=0;
            euler(i);
        }
    }
    q[++nr]=x;
}

int main() {
    fin >> n >> m;
    for (int i=1; i<=m; i++) {
        fin >> x >> y;
        v[x][y]=v[y][x]=1;
    }
    euler(1);
    if (nr)
        for (int i=nr; i>=1; i--)
            fout << q[i] << " ";
    else
        fout << -1;
    return 0;
}
