#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, x, y, a, b, v[1005][1005], st[1005], k;

void euler (int x) {
    for (int i=1; i<=n; i++) {
        if (v[x][i]) {
            v[x][i]--;
            v[i][x]--;
            euler(i);
        }
    }
    st[++k]=x;
}

int main() {
    fin >> n >> m;
    for (int i=1; i<=m; i++) {
        fin >> x >> y;
        v[x][y]++;
        v[y][x]++;
    }
    euler(1);
    while (k>1) {
        fout << st[k] << " ";
        k--;
    }
    return 0;
}
