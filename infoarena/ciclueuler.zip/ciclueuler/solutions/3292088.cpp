#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector <int> L[100005];
int e[500005], nr[100005], d[100005], len, n;
pair<int, int> muchii[500005];
bitset <500005> v;

void DFS(int k)
{
    while (nr[k] < L[k].size())
    {
        int i = L[k][nr[k]];
        nr[k]++;
        if (!v[i])
        {
            v[i] = 1;
            DFS(muchii[i].first + muchii[i].second - k);
        }
    }
    e[++len] = k;
}

int main()
{
    int i, j, k, m;
    bool g = true;
    fin >> n >> m;
    for (k = 1; k <= m; k++)
    {
        fin >> i >> j;
        L[i].push_back(k);
        L[j].push_back(k);
        d[i]++;
        d[j]++;
        muchii[k] = {i, j};
    }

    for (i = 1; i <= n && g == true; i++)
        if (d[i] % 2 == 1)
            g = false;

    if (g == false)
    {
        fout << "-1\n";
        return 0;
    }
    DFS(1);
    for (i = 1; i <= len; i++)
        fout << e[i] << " ";
    return 0;
}
