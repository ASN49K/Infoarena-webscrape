#include<bits/stdc++.h>
#define nmax 100002
#define mmax 500002
#define pi pair<int,int>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m,grad[nmax],viz[nmax],nrc,sol[nmax],ind,check_edge[mmax];
vector<pi>l[nmax];
void dfs(int pas)
{
    viz[pas]=nrc;
    for(auto i:l[pas])
        if(viz[i.first]==0)
            dfs(i.first);
}
bool check_if_possible()
{
    if(nrc>=2)
        return 0;
    for(int i=1; i<=n; i++)
        if((grad[i]&1)==1)
            return 0;
    return 1;
}
void Euler(int pas)
{
    while(!l[pas].empty())
    {
        int node=l[pas].back().first;
        int edge_number=l[pas].back().second;
        l[pas].pop_back();
        if(check_edge[edge_number]==0)
        {
            check_edge[edge_number]=1;
            Euler(node);
        }
    }
    sol[++ind]=pas;
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        fin>>x>>y;
        grad[x]++;
        grad[y]++;
        l[x].push_back(make_pair(y,i));
        l[y].push_back({x,i});
    }
    for(int i=1; i<=n; i++)
        if(viz[i]==0)
        {
            nrc++;
            dfs(i);
        }
    bool ok=check_if_possible();
    if(ok==0)
    {
        fout<<-1;
        return 0;
    }
    Euler(1);
    for(int i=1; i<ind; i++)
        fout<<sol[i]<<' ';
    return 0;
}
