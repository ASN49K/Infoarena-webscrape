#include <fstream>
#include <vector>
#include <stack>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, i, x, y, gr[100005], ans[100005], k, it, viz[100005];
vector <pair<int, int>> v[100005];
stack <int> st;
void eulerian_cycle(int nod)
{
    int nodv;
    st.push(nod);
    while(!st.empty())
    {
        nodv=st.top();
        if(v[nodv].size()==0)
        {
            ans[++k]=nodv;
            st.pop();
        }
        else
        {
            while(!v[nodv].empty() && viz[v[nodv].back().second]!=0)
                v[nodv].pop_back();
            if(!v[nodv].empty())
            {
                viz[v[nodv].back().second]=1;
                st.push(v[nodv].back().first);
                v[nodv].pop_back();
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(make_pair(y, i));
        v[y].push_back(make_pair(x, i));
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            fout<<-1;
            return 0;
        }
    }
    eulerian_cycle(1);
    for(i=1; i<k; i++)
        fout<<ans[i]<<" ";

    return 0;
}
