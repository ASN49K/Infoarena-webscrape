#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;

//int g[100000][100000] = {0};
int v[100001] = {0};
int n, m, con = 0;

vector<int> g[500001];
vector<int> adsize;

bool isConnected(int n) {
    vector<bool> visited(n + 1, false);
    int start = -1;
    for (int i = 1; i <= n; ++i) {
        if (!g[i].empty()) {
            start = i;
            break;
        }
    }
    if (start == -1) return true; // No edges

    queue<int> q;
    q.push(start);
    visited[start] = true;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : g[u]) {
            if (!visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (!g[i].empty() && !visited[i]) return false;
    }
    return true;
}

void dfs(int i, ofstream &out)
{
    out << i << ' ';
    int j = g[i].size()-1; // length of adjancency list for i
    
    if (j >= 0) {
        int next = g[i][j];
        g[i].pop_back();
        for (int k = 0; k < g[next].size(); ++k)
            if (g[next][k] == i)
                g[next].erase(g[next].begin() + k);
        
        dfs(next, out);
    }

}

int main()
{
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    int x, y;
    in >> n >> m;
    adsize.resize(n + 1, 0);
    for (int i = 1; i <= m; ++i)
    {
        in >> x >> y;
        g[x].push_back(y);
        ++adsize[x];
        ++adsize[y];
        if (y != x)
            g[y].push_back(x);
    }
    for (int i = 1; i <= n; ++i)
    {
        cout << i << ": ";
        for (int j = 0; j < g[i].size(); ++j)
            cout << g[i][j] << " ";
        cout << '\n';
    }
    int ok = 1;
    
    bool hasEulerian = true;
    for (int i = 1; i <= n; ++i) {
        if (adsize[i] % 2 != 0) {
            hasEulerian = false;
            break;
        }
    }

    int start = -1;
    for (int i = 1; i <= n; ++i) {
        if (adsize[i] > 0) {
            start = i;
            break;
        }
    }

    if (hasEulerian && start != -1 && isConnected(n)) {
        dfs(start, out);
    } else {
        out << -1;
    }


    in.close();
    out.close();
    return 0;
}