#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <queue>
#include <stack>
#define MAXN 100005
#define MAXM 500005
using namespace std;
FILE *fin,*fout;

struct XY{
  int x,y;
};

vector <XY> g[MAXN];
stack <int> q;
int ne[MAXN];
bool poz[MAXM];

void AddEdge(XY a,int i){
  g[a.x].push_back({a.y,i});
  g[a.y].push_back({a.x,i});
  ne[a.x]++;
  ne[a.y]++;
}

void Euler(int x){
  int c;
  XY neigh;

  c=ne[x]/2;
  q.push(x);
  while(!q.empty()){
    x=q.top();
    if(ne[x]!=0){
      neigh=g[x].back();
      g[x].pop_back();

      if(poz[neigh.y]==false){
        q.push(neigh.x);
        poz[neigh.y]=true;
        ne[x]--;
        ne[neigh.x]--;
      }
    }else{
      if(x==1){
        if(c>0){
          fprintf(fout,"%d ",x);
        }
        c--;
      }else{
        fprintf(fout,"%d ",x);
      }
      q.pop();
    }
  }
}


int main(){
  int n,m,s,i;
  XY a;
  fin=fopen("ciclueuler.in","r");
  fout=fopen("ciclueuler.out","w");
  fscanf(fin,"%d%d",&n,&m);

  for(i=0;i<m;i++){
    fscanf(fin,"%d%d",&a.x,&a.y);
    AddEdge(a,i);
  }
  s=1;
  for(i=0;i<n;i++){
    if(ne[i]%2==1){
      s=0;
    }
  }
  if(s==0){
    fprintf(fout,"-1\n");
  }else{
    Euler(1);
  }

  fclose(fin);
  fclose(fout);
  return 0;
}
