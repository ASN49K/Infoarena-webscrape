#include <fstream>
#include<bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX=1e5;
set<int>graph[NMAX+5];
vector<int>cycle;
void hierholzer(int nod)
{
    while(!graph[nod].empty())
    {
        int x=*graph[nod].begin();
        graph[nod].erase(graph[nod].begin());
        graph[x].erase(graph[x].find(nod));
        hierholzer(x);
    }
    cycle.push_back(nod);
}
int main()
{
    int n,m;
    fin>>n>>m;
    while(m--)
    {int x,y;
        fin>>x>>y;
        graph[x].insert(y);
        graph[y].insert(x);

    }
    for(int i=1;i<=n;i++)
    {
        if(graph[i].size()%2==1){fout<<-1;return 0;}
    }
    hierholzer(1);
    reverse(cycle.begin(),cycle.end());

    for(int i=0;i<cycle.size()-1;i++)
    {
        fout<<cycle[i]<<" ";
    }
    return 0;
}
