#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n;
vector<int> g[100001];
int A[500002], B[500002], m; /// muchiile
bitset<500002> viz;
int e[500005], len; /// aici retin ciclul eulerian
int d[500005];
int I[100001]; /// I[i] un

void Citire()
{
    int i, j, p;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        A[p] = i; B[p] = j;
        d[i]++; d[j]++;
        g[i].push_back(p);
        g[j].push_back(p);
    }#include <bits/stdc++.h>
using namespace std;

ifstream fin("sumtri.in");
ofstream fout("sumtri.out");

int n;
vector<int> g[100001];
int A[500002], B[500002], m; /// muchiile
bitset<500002> viz;
int e[500005], len; /// aici retin ciclul eulerian
int d[500005];
int I[100001]; /// I[i] = unde am ramas cu un indicele in
               ///  lista de incidenta pentru noul i

void Citire()
{
    int i, j, p;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        A[p] = i; B[p] = j;
        d[i]++; d[j]++;
        g[i].push_back(p);
        g[j].push_back(p);
    }
}

bool EsteEulerian()
{
    for (int i = 1; i <= n; i++)
        if (d[i] % 2 == 1) return false;
    return true;
}

void Euler(int k)
{
    while (I[k] < g[k].size())
    {
        int i = g[k][I[k]];
        I[k]++;
        if (viz[i] == 0)
        {
            viz[i] = 1; /// A[i], B[i]
            Euler(A[i] + B[i] - k);
        }
    }
    e[++len] = k;
}

void Afis()
{
    for (int i = 1; i < len; i++)
        fout << e[i] << " ";
}

int main()
{
    Citire();
    if (!EsteEulerian()) fout << "-1\n";
    else
    {
        Euler(1);
        Afis();
    }
    return 0;
}
}

bool EsteEulerian()
{
    for (int i = 1; i <= n; i++)
        if (d[i] % 2 == 1) return false;
    return true;
}

void Euler(int k)
{
    for (int i : g[k])
        if (viz[i] == 0)
        {
            viz[i] = 1; /// A[i], B[i]
            Euler(A[i] + B[i] - k);
        }
    e[++len] = k;
}

void Afis()
{
    for (int i = 1; i < len; i++)
        fout << e[i] << " ";
}

int main()
{
    Citire();
    if (!EsteEulerian()) fout << "-1\n";
    else
    {
        Euler(1);
        Afis();
    }
    return 0;
}
