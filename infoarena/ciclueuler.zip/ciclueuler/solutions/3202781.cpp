#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100002
#define MMAX 500002
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
struct varf
{
    int x, nr;
};
/// x este vf adiacent, iar nr este nr muchiei corespunzatoare
vector <varf> G[NMAX];
vector <int> sol;
int n, m;
bool uz[MMAX];
int d[NMAX];
stack <int> S;
void citire();
int grade_pare();
void euler(int start);
int main()
{
    int start, eulerian, i;
    citire();
    if(!(start=grade_pare()))
        fout<<-1<<'\n';
    else
    {
        euler(start);
        eulerian=1;
        for(i=1; i<=m; i++)
            if(!uz[i]) eulerian=0;
        /*if(!eulerian)
        {
            fout.close();
            fout.open("ciclueuler.out");
            fout<<-1<<'\n';
        }
        */
        if(!eulerian) fout<<-1<<'\n';
        else
          for(i=0; i<sol.size()-1; i++)
              fout<<sol[i]<<' ';
    }
    fout.close();
    return 0;
}
void citire()
{
    int i, x, y;
    varf vf;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        ///y intra in lista de adiacenta a lui x
        vf.x=y;
        vf.nr=i;
        G[x].push_back(vf);
        vf.x=x;
        vf.nr=i;
        G[y].push_back(vf);
        d[x]++;
        d[y]++;
    }
}
int grade_pare()
{
    // returneaza 0, daca nu toate gradele sunt pare
    int i, start;
    for(i=1; i<=n; i++)
    {
        if(d[i]%2) return 0;
        if(d[i]) return start=i;
    }
    return start;
}
/*void euler(int start)
{
    varf vfad;
    int vf;
    S.push(start);
    while(!S.empty())
    {
        vf=S.top();

        // aleg un vf adiacent cu vf
        if(!G[vf].empty())
        {

                vfad=G[vf][G[vf].size()-1];
                if(!uz[vfad.nr]) //muchie neutilizata
                {
                    fout<<' '<<vfad.x;
                    uz[vfad.nr]=1;
                    S.push(vfad.x);
                }
              G[vf].pop_back();

        }
        else
        {
          fout<<' '<<vf; S.pop();
        }

    }

}*/
void euler(int start)
{
    int i;
    varf vfad;
    for(i=G[start].size()-1; i>=0; i--)
    {
        vfad=G[start][i];
        if(!uz[vfad.nr])
        {
            uz[vfad.nr]=1;
            euler(vfad.x);
        }
        G[start].pop_back();
    }
    sol.push_back(start);
}
