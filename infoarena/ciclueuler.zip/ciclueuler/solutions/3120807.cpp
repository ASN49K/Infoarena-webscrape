#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}

void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    freopen((Name + ".in").c_str(), "r", stdin);
    freopen((Name + ".out").c_str(), "w", stdout);
}

void solve() {
    /* standard algorithm */
    int n, m; re(n, m);
    vt <vt <int>> adj(n);
    vt <int> path, marked(n), in(m), out(m);
    stack <int> st;
    for (int i = 0; i < m; ++i) {
        int u, v; re(u, v);
        --u, --v;
        adj[u].emb(i);
        adj[v].emb(i);
        in[i] = u;
        out[i] = v;
    }

    /* verify if we have an eulerian path/cycle */
    int nr_odd = 0;
    for (int i = 0; i < n; i++)
        nr_odd += (len(adj[i]) % 2);

    if (!(nr_odd == 0 or nr_odd == 2)) {
        wr(-1);
        return;
    }

    st.emplace(0);
    while (len(st)) {
        int u = st.top();
        if (len(adj[u]) == 0) {
            marked[u] = 1;
            path.emb(u);
            st.pop();
            continue;
        } 
        
        int e = adj[u].back();
        adj[u].pop_back();

        int aux = in[e] ^ out[e] ^ u;
        if (!marked[e]) {
            marked[e] = 1;
            st.emplace(aux);
        }
    }

    path.pop_back();
    for (int u : path) {
        wr(u + 1, ' ');
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("ciclueuler");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}