#include <stdio.h>
#include <vector>

#define MAXN 100000
#define MAXM 500000

struct Edge {
  int v, idx;
};
std::vector<Edge> g[MAXN];
int stiva[MAXM + 1];
char viz[MAXM];

struct DSU {
  int sef[MAXN];
  
  void init(int n) {
    int i;
    
    for(i = 0; i < n; i++) {
      sef[i] = i;
    }
  }
  
  int find(int i) {
    if(i == sef[i]) {
      return i;
    }
    return sef[i] = find(sef[i]);
  }
  
  inline void join(int u, int v) {
    sef[find(v)] = find(u);
  }
} dsu;

int main() {
  int n, m, i, u, v, sp, val, j;
  
  #ifndef LOCAL
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
  #endif
  
  scanf("%d%d", &n, &m);
  dsu.init(n);
  for(i = 0; i < m; i++) {
    scanf("%d%d", &u, &v);
    g[--u].push_back((struct Edge){.v = --v, .idx = i});
    g[v].push_back((struct Edge){.v = u, .idx = i});
    dsu.join(u, v);
  }
  
  val = dsu.find(0);
  i = 1;
  while(i < n && dsu.find(i) == val) {
    i++;
  }
  
  j = 0;
  while(j < n && g[j].size() % 2 == 0) {
    j++;
  }
  
  if(i == n && j == n) {
    sp = 1;
    while(sp > 0) {
      u = stiva[sp - 1];
      if(g[u].empty()) {
        sp--;
        if(sp > 0) {
          printf("%d ", u + 1);
        }
      } else {
        v = g[u].back().v;
        i = g[u].back().idx;
        g[u].pop_back();
        if(viz[i] == 0) {
          stiva[sp++] = v;
          viz[i] = 1;
        }
      }
    }
    fputc('\n', stdout);
  } else {
    printf("-1\n");
  }
  
  return 0;
}