#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector<int>v[100005],ans;
stack<int>s;
bool fol[500005];
int from[500005],to[500005],n,m,i,nou,x,y,node;
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(i);
        v[y].push_back(i);
        from[i]=x;
        to[i]=y;
    }
    for(i=1;i<=n;i++)
        if(v[i].size()%2==1)
        {
            fout<<-1;
            return 0;
        }
    s.push(1);
    while(!s.empty())
    {
        node=s.top();
        if(!v[node].empty())
        {
            nou=v[node].back();
            v[node].pop_back();
            if(!fol[nou])
            {
                fol[nou]=true;
                if(from[nou]==node)
                    s.push(to[nou]);
                else
                    s.push(from[nou]);
            }
        }
        else
        {
            s.pop();
            ans.push_back(node);
        }
    }
    for(i=0;i<ans.size()-1;i++)
        fout<<ans[i]<<" ";
    return 0;
}
