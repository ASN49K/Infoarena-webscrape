#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX = 1e5 + 1, MMAX = 5e5 + 1;
struct edge{int nod, id;};
vector<edge> edges[NMAX];
vector<int> ans;
int n, m, rem[MMAX], poz[NMAX], not_used;

void euler(int nod)
{
    while(poz[nod] < edges[nod].size())
    {
        if(!rem[edges[nod][poz[nod]].id])
        {
            rem[edges[nod][poz[nod]].id] = 1;
            not_used--;
            euler(edges[nod][poz[nod]].nod);
        }
        poz[nod]++;
    }
    ans.push_back(nod);
}

signed main()
{
    fin >> n >> m;
    not_used = m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        edges[x].push_back({y, i});
        edges[y].push_back({x, i});
    }
    for(int i = 1; i <= n; i++)
    {
        if(edges[i].size() % 2 == 1)
        {
            fout << -1;
            return 0;
        }
    }
    euler(1);
    if(not_used != 0)
        fout << -1;
    else
    {
        for(int nod : ans)
            fout << nod << " ";
    }

    return 0;
}
