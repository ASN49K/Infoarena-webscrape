#include <bits/stdc++.h>
using namespace std;

const int NMAX = 100005;
const int MMAX = 500005;

struct Edge
{
    int to, id;
};

vector<Edge> v[NMAX];
int n, m, k;
bitset<MMAX + 1> vap;
int last_ind[NMAX + 1];
int ans[MMAX + 5];
int rang[NMAX + 1];

void read()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int st, dr;
        cin >> st >> dr;
        v[st].push_back({dr, i});
        v[dr].push_back({st, i});
        rang[st]++;
        rang[dr]++;
    }
}

void dfs(int start)
{
    stack<int> st;
    st.push(start);

    while (!st.empty())
    {
        int nod = st.top();
        bool found = false;

        while (last_ind[nod] < v[nod].size())
        {
            Edge curr = v[nod][last_ind[nod]++];
            if (!vap[curr.id])
            {
                vap[curr.id] = 1;
                st.push(curr.to);
                found = true;
                break;
            }
        }
        if (!found)
        {
            ans[++k] = nod;
            st.pop();
        }
    }
}

void solve()
{
    for (int i = 1; i <= n; i++)
    {
        if (rang[i] % 2 != 0)
        {
            cout << -1;
            return;
        }
    }

    dfs(1);
    if (k != m + 1)
    {
        cout << -1;
    }
    else
    {
        for (int i = 1; i <= m; i++)
            cout << ans[i] << ' ';
    }
}

int main()
{
     freopen("ciclueuler.in","r",stdin);
     freopen("ciclueuler.out","w",stdout);
    read();
    solve();
    return 0;
}
