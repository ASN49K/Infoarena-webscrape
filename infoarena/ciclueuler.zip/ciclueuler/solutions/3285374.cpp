#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
using namespace std;
ifstream fin("euler.in");
ofstream gout("euler.out");
struct muchie
{
    int nod,nrm;
};
bitset<500001>elim(0);
void euler(int x, vector<vector<muchie>>&v,vector<int>&ciclu)
{
    muchie mm;
    while(!v[x].empty())
    {
        mm=v[x].back();
        v[x].pop_back();
        if(!elim[mm.nrm])
        {
            elim[mm.nrm]=1;
            euler(mm.nod,v,ciclu);
        }
    }
    ciclu.push_back(x);
}
int main()
{
    int n,m,i,j,x,y;
    fin>>n>>m;
    vector<vector<muchie>>v(n+1,vector<muchie>(0));
    for(i=1; i<=m; ++i)
    {
        fin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(i=1; i<=n; ++i)if(v[i].size()%2)
        {
            gout<<-1;
            return 0;
        }
    vector<int>ciclu;
    euler(1,v,ciclu);
    for(i=ciclu.size()-1; i; --i)gout<<ciclu[i]<<' ';
    return 0;
}
