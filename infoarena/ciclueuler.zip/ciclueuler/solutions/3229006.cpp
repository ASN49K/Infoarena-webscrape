#include <bits/stdc++.h>
#define L 100005
#define LL 500005
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector <pair <int, int>> G[L];
int vis[LL];
vector <int> ans;

bool is_euler(int n, int m){
  bool ok = true;

  for (int i = 1; i <= n; i++)
    if (G[i].size() % 2 == 1)
      ok = false;

  return ok;
}

void generate_euler_cycle(int n, int m, int node){
  while (!G[node].empty()){
    auto edge = G[node].back();
    G[node].pop_back();
    if (!vis[edge.second]){
      vis[edge.second] = true;
      generate_euler_cycle(n, m, edge.first);
    }
  }
  ans.push_back(node);
}

void euler(int n, int m){
  if (!is_euler(n, m))
    ans.push_back(-1);
  else{
    generate_euler_cycle(n, m, 1);
    ans.pop_back();
    //reverse(ans.begin(), ans.end());
  }
}

int main(){
  int n, m;
  fin >> n >> m;

  for (int i = 1; i <= m; i++){
    int a, b;
    fin >> a >> b;
    G[a].push_back({b, i});
    G[b].push_back({a, i});
  }

  euler(n, m);

  for (int i = 0; i < (int)ans.size(); i++)
    fout << ans[i] << " ";
  fout << "\n";
  return 0;
}
