#include <bits/stdc++.h>
using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

int n, x, y, nr, m;
vector<int> G[100005];
stack<int> Q;

void delete_edges(int x, int it)
{
    vector<int>::iterator i;
    i = find(G[x].begin(), G[x].end(), it);
    G[x].erase(i);

    G[it].pop_back();
}

void eulerian(int x)
{
    while (!G[x].empty())
    {
        int val = G[x].back();
        delete_edges(val, x);
        eulerian(val);
    }
    Q.push(x);
}

int main()
{
    f >> n;
    f >> m;
    for(int i = 1; i <= m; ++i)
    {
        f >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    for(int i = 1; i <= n; ++i)
    {
        if(G[i].size() & 2 == 1)
        {
            g << "-1";
            return 0;
        }
    }

    for(int i = 1; i <= n; ++i)
    {
        sort(G[i].begin(), G[i].end());
        reverse(G[i].begin(), G[i].end());
    }

    eulerian(1);

    while(Q.size() >= 2)
    {
        g << Q.top() << ' ';
        Q.pop();
    }
    return 0;
}
