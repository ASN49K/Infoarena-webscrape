#include <fstream>
#include <vector>
#include <stack>
#include <iostream>
#include <string>
#include <bitset>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector <pair <int, int> > L[100005];
bitset <500005> viz;
int n, m;

void Read()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back({ y, i });
        L[y].push_back({ x, i });
    }
}

void EulCycle(int start)
{
    stack<int> st;
    st.push(start);
    vector <int> sol;
    while (!st.empty())
    {
        int curr = st.top();
        if (L[curr].empty())
        {
            sol.push_back(curr);
            st.pop();
        }
        else {
            pair<int, int> next = L[curr].back();
            L[curr].pop_back();
            if (!viz[next.second])
            {
                viz[next.second] = 1;
                st.push(next.first);
            }
        }
    }
    for (int i = 0; i < sol.size() - 1; i++)
        fout << sol[i] << " ";
}

void Solve()
{
    for (int i = 1; i <= n; i++)
        if (L[i].size() % 2 == 1)
        {
            fout << "-1\n";
            return;
        }
    EulCycle(1);

}

int main()
{
    Read();
    Solve();
    return 0;
}