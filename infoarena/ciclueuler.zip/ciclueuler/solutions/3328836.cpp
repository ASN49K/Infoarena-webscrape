#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 1e5+1, MMAX = 5e5+1;
int n, m, ok=1;
bitset <MMAX> uz;
vector <pair <int,int>> g[NMAX];
vector <int> ans;

void dfs(int nod){
    for(auto vec : g[nod])
        if(!uz[vec.second]){
            uz[vec.second]=1;
            dfs(vec.first);
        }
    ans.push_back(nod);
}

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        int x, y;
        fin>>x>>y;
        g[x].push_back({y,i});
        g[y].push_back({x,i});
    }

    for(int i=1;i<=n&&ok;i++){
        if(g[i].size()%2)
            ok=0;
    }
    if(ok){
        dfs(1);
        int len = ans.size()-1;
        for(int i=0;i<len;i++){
            fout << ans[i]<<' ';
        }
    }
    else{
        fout<<-1;
    }
    return 0;
}
