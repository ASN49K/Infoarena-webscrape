#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 500005;
int viz[NMAX];
int grad[NMAX / 5];
int n, m;
vector < pair < int, int > > G[NMAX];

void read(){
    fin >> n >> m;
    for(int i = 0; i < m; i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back({y, i});
        G[y].push_back({x, i});
        grad[x]++;
        grad[y]++;
    }
}

stack < int > st;
void euler(int nod){
    for(pair < int, int > much: G[nod]){
        int nbr = much.first;
        int i = much.second;
        if(!viz[i]){
            viz[i] = 1;
            euler(nbr);
        }
    }
    st.push(nod);
}

int main()
{
    read();
    for(int i = 1; i <= n; i++){
        if(grad[i] % 2 != 0){
            fout << -1;
            return 0;
        }
    }
    euler(1);
    while(!st.empty()){
        fout << st.top() << " ";
        st.pop();
    }
    return 0;
}
