#include <fstream>
#include <vector>
#include <bitset>

using namespace std;
const int NMAX = 100001,
          MMAX = 500001;

struct muchie
{
    int nod, ///nod
        nrm; ///numarul muchiei

    muchie(int xx = 0, int nn = 0) : nod(xx), nrm(nn) {}
};

int n, m;

vector<muchie> G[NMAX];
vector<int> L;
bitset<MMAX> elim;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

void citire()
{
    int x, y;
    f >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(muchie(y, i));
        G[y].push_back(muchie(x, i));
    }
}

void euler(int x)
{
    muchie mm;
    while(!G[x].empty() && elim[G[x].back().nrm])
        G[x].pop_back();
    if (!G[x].empty())
    {
        mm = G[x].back();
        G[x].pop_back();
        elim[mm.nrm] = 1;
        euler(mm.nod);
    }
    L.push_back(x);
    return;
}

int main()
{
    bool ok = 1;
    citire();
    for(int i = 1; i <= n && ok; i++)
    {
        if(G[i].size() & 1)
            ok = 0;
    }
    if(ok)
    {
        euler(1);
        for(int i = L.size() - 1; i >= 1; i--)
            g << L[i] << ' ';
    }
    else
        g << "-1\n";
    f.close();
    g.close();
    return 0;
}
