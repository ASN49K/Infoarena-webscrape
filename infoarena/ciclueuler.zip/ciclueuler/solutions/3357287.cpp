/*
https://infoarena.ro/problema/ciclueuler
*/
#include <fstream>
#include <vector>

using namespace std;

struct muchie
{
    int x, y;
    int celalalt_vf(int vf)
    {
        return (x + y - vf);
    }
};

int n, m;
vector <muchie> lst_m;
vector <vector <int>> lst_a;
vector <bool> folosit;
vector <int> poz;
vector <int> ciclu;

bool toate_gr_pare()
{
    for (int i = 1; i <= n; i++)
    {
        if (lst_a[i].size() % 2 != 0)
        {
            return false;
        }
    }
    return true;
}

int primul_vf()
{
    for (int i = 1; i <= n; i++)
    {
        if (lst_a[i].size() != 0)
        {
            return i;
        }
    }
    return 0;
}

void euler(int x)
{
    while (poz[x] < (int)lst_a[x].size())
    {
        int p = lst_a[x][poz[x]++];
        if (!folosit[p])
        {
            folosit[p] = true;
            int y = lst_m[p].celalalt_vf(x);
            euler(y);
        }
    }
    ciclu.push_back(x);
}

int main()
{
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    in >> n >> m;
    lst_m.resize(m);
    lst_a.resize(n + 1);
    for (int i = 0; i < m; i++)
    {
        in >> lst_m[i].x >> lst_m[i].y;
        lst_a[lst_m[i].x].push_back(i);
        lst_a[lst_m[i].y].push_back(i);
    }
    in.close();
    if (toate_gr_pare())
    {
        poz.resize(n + 1, 0);
        folosit.resize(m, false);
        euler(primul_vf());
        if ((int)ciclu.size() == m + 1)
        {
            for (auto x: vector <int>(ciclu.begin(), ciclu.end() - 1))
            {
                out << x << " ";
            }
            out << "\n";
        }
        else
        {
            out << "-1\n";
        }
    }
    else
    {
        out << "-1\n";
    }
    out.close();
    return 0;
}
