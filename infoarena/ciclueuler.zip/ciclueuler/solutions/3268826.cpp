#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <climits>
#include <sstream>
#include <set>
using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m;

vector<set<int>> la;
vector<int> grade;

void Read()
{
    f >> n >> m;

    la.resize(n + 1);
    grade.resize(n + 1, 0);

    // Read the adjacency list from input
    for (int i = 1; i <= m; ++i)
    {
        int x, y;
        f >> x >> y;
        la[x].insert(y);
        la[y].insert(x);
        grade[x]++;
        grade[y]++;
    }
    for (int i = 1; i <= n; i++)
        if (grade[i] % 2 != 0)
        {
            cout << -1;
            exit(0);
        }
}

int main()
{
    Read();
    int x = 1, vi = 1;
    do
    {
        g << vi << " ";
        if (!la[vi].empty())
        {
            int vecin = *la[vi].begin();
            la[vi].erase(vecin);
            la[vecin].erase(vi);
            vi = vecin;
        }

    } while (x != vi);

    return 0;
}