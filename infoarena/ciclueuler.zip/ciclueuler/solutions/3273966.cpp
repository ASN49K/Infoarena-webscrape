#include <fstream>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m, t[4][1000000], start[101], eu[101], viz[100001], e;
int st[5001],varf;

void citire()
{
    int x, y, k=0;
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y;
        k++;
        t[0][k]=x;
        t[1][k]=start[y];
        start[y]=k;
        t[3][k]=k+1;
        k++;
        t[0][k]=y;
        t[1][k]=start[x];
        start[x]=k;
        t[3][k]=k-1;
    }
}

void dfs()
{
    int man;
    varf=1;
    st[varf]=1;
    while(varf!=0)
    {
        e++;
        eu[e]=st[varf];
        viz[st[varf]]=0;
        man=start[st[varf]];
        varf--;
        while(man)
        {
            if(t[2][man]==0&&viz[t[0][man]]==0)
            {
                viz[t[0][man]]=1;
                varf++;
                st[varf]=t[0][man];
                t[2][man]=1;
                t[2][t[3][man]]=1;
            }
            man=t[1][man];
        }
    }
}

void afisare()
{
    for(int i=1; i<=e; i++)
        out<<eu[i]<<" ";
    out<<"1";
}

int main()
{
    citire();
    dfs();
    afisare();
    return 0;
}
