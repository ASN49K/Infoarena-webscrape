#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");
int viz[100001], vizm[500001], sol[500001], grad[100001], z;
vector<pair<int, int> > v[100001];
void dfs(int nod)
{
    viz[nod] = 1;
    for(int i = 0; i<v[nod].size();i++)
    {
        int vecin = v[nod][i].first;
        if(!viz[vecin])
        {
            dfs(vecin);
        }
    }
}
void euler(int nod)
{
    for(int i = 0; i < v[nod].size(); i++)
    {
    int vecin = v[nod][i].first;
    int vecinM = v[nod][i].second;
    if(!vizm[vecinM])
    {
        vizm[vecinM] = 1;
        euler(vecin);

    }
    }sol[++z] = nod;
}
int main()
{
    int n, m;
    fin >> n >> m;
    for(int i = 1; i<=m; i++)
    {
        int a,b;
        fin >> a >> b;
        grad[a]++;
        grad[b]++;
        v[a].push_back({b,i});
        v[b].push_back({a,i});
    }
    dfs(1);
    int ok = 0;
    for(int i = 1; i<=n; i++)
    {
        if(grad[i] % 2 == 1 || !viz[i]) ok = 1;
    }
    if(ok == 1)
        fcout << - 1;
    else
    {
        euler(1);
        for(int i = 1; i<z; i++)
        {
            fout << sol[i] << ' ';
        }
    }
    return 0;
}
