/*
 * Lefter Sergiu - 20/04/2023
*/
#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

const int N = 1e5;
const int M = 5e5;

struct muchie {
    int x, y;
}e[M+1];
bitset<M+1> sterse;
vector<int> a[N+1], ce;
int n, m, prim[M+1];

bool pare() { //toate gradele pare
    for (int i = 1; i <= n; i++) {
        if (a[i].size() % 2 != 0) {
            return false;
        }
    }
    return true;
}

int celalalt_vf(muchie f, int x) {
    return (f.x + f.y - x);
}

void euler(int x) {
    while (prim[x] < (int) a[x].size()) {
        int i_e_c = a[x][prim[x]++];
        muchie e_c = e[i_e_c];
        int y = celalalt_vf(e_c, x);
        if (!sterse[i_e_c]) {
            sterse[i_e_c] = 1;
            euler(y);
        }
    }
    ce.push_back(x);
}

int main() {
    in >> n >> m;
    for (int i = 0; i < m; ++i) {
        in >> e[i].x >> e[i].y;
        a[e[i].x].push_back(i);
        a[e[i].y].push_back(i);
    }
    if (!pare()) {
        out << -1;
    }
    else {
        euler(1);
        if ((int)ce.size() != m + 1) {
            out << -1;
        }
        else {
            for (int i = 0; i < (int)ce.size() - 1; ++i) {
                out << ce[i] << " ";
            }
        }
    }
    in.close();
    out.close();
    return 0;
}