#include <fstream>
#include <vector>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
const int N=1e5+5,M=5e5+5;
bool used[M];
int grad[N],n,m;
vector<pair<int,int>>adj[N];
vector<int>path;

void dfs(int nod)
{
    while(!adj[nod].empty())
    {
        int next=adj[nod].back().first;
        int tip=adj[nod].back().second;
        adj[nod].pop_back();
        if(used[tip]==true)
        {
            continue;
        }
        used[tip]=true;
        dfs(next);
    }
    path.push_back(nod);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        cin>>a>>b;
        adj[a].push_back({b,i});
        adj[b].push_back({a,i});
        grad[a]++;
        grad[b]++;
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        cnt+=(grad[i]%2);
    }
    if(cnt!=0)
    {
        cout<<-1<<'\n';
        return 0;
    }
    dfs(1);
    for(auto u:path)
        cout<<u<<" ";
    return 0;
}
