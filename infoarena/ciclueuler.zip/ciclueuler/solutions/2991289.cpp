#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
const int NMAX=100005;

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector< pair< int, int> > v[NMAX];
vector <int> ans;
bool f[5*NMAX];
int n, m;

void dfs(int);

int main()
{
    int i, a, b, nr;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back(make_pair(b, i));
        v[b].push_back(make_pair(a, i));
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            fout<<-1<<'\n';
            return 0;
        }
    }
    dfs(1);
    for(i=0; i<int(ans.size())-1; i++) fout<<ans[i]<<' ';
    return 0;
}

void dfs(int nod)
{
    for(auto i:v[nod])
    {
        if(f[i.second]==false)
        {
            f[i.second]=true;
            dfs(i.first);
        }
    }
    ans.push_back(nod);
}
