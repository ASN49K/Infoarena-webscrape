#include <bits/stdc++.h>

using namespace std;

const int N = 100'001;
vector <pair <int, int >> g[N];
vector <int> ans;
bool verif[N];

//void dfs(int node)
//{
//    verif[node] = 1;
//    for(auto next : g[node])
//    {
//        if(!verif[next.first])
//            dfs(next.first);
//    }
//}

int main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    int n, m;
    cin >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int a, b;
        cin >> a >> b;
        g[a].push_back({b, i});
        g[b].push_back({a, i});
    }
    //dfs(1);
    for(int i = 1; i <= n; i++)
    {
        if(g[i].size() % 2  /*!verif[i]*/) // daca un nod are gr imapar sau e izolat
        {
            cout << "-1";
            return 0;
        }
    }
    stack <int> ciclu;
    ciclu.push(1);
    for(int i = 1; i <= m; i ++)
    {
        int aux = ciclu.top();
        while(g[aux].size())
        {
            pair <int, int> next = g[aux].back();
            g[aux].pop_back();
            if(verif[next.second])
                continue;
            verif[next.second] = 1;
            aux  = next.first;
            ciclu.push(next.first);
        }
        ans.push_back(aux);
        ciclu.pop();
    }
    for(vector <int>::iterator it = ans.begin(); it < ans.end(); it ++)
    {
        cout << *it << " ";
    }
    return 0;
}
