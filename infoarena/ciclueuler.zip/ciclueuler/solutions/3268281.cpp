#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 100000;
const int MMAX = 500000;

int n, m, x, y;
vector < pair<int,int> > v[NMAX+1];
int trecut[MMAX+1];
vector <int> st;
int ans[NMAX+1],cnt;

int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
        fin >> x >> y, v[x].push_back( {y,i} ), v[y].push_back( {x,i} );
    for(int i=1; i<=n; i++)
        if(v[i].size() % 2)
        {
            fout << -1;
            return 0;
        }
    st.push_back(1);
    while(!st.empty())
    {
        bool gol = 1;
        int nod = st.back();
        for(auto a : v[nod])
        {
            if(!trecut[a.second])
            {
                st.push_back(a.first);
                trecut[a.second] = 1;
                gol = 0;
                break;
            }
        }
        if(gol)
            st.pop_back(), ans[++cnt] = nod;
    }
    for(int i=cnt; i>1; i--)
        fout << ans[i] << ' ';
    return 0;
}
