#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

const int NMAX = 1e5;
const int MMAX = 5e5;

struct muchie{
    int x, y;
};

muchie e[MMAX + 1];
bitset <MMAX + 1> sters;
vector <int> v[NMAX + 1];
vector <int> ciclu;
int ultim[NMAX + 1];

int celalalt(muchie m, int x){
    return (m.x + m.y - x);
}

void euler(int x){

    while(ultim[x] < v[x].size()){

        int ind = v[x][ultim[x]++];

        if(sters[ind] == 0){

            int y = celalalt(e[ind], x);
            sters[ind] = 1;
            euler(y);

        }

    }

    ciclu.push_back(x);

}

int main(){

    int n = 0, m = 0;
    cin >> n >> m;

    for(int i = 0; i < m; i++){

        cin >> e[i].x >> e[i].y;

        v[e[i].x].push_back(i);
        v[e[i].y].push_back(i);

    }

    euler(e[0].x);

    if(ciclu.size() != m + 1){

        cout << -1;
        return 0;

    }

    for(int i = 0; i < ciclu.size() - 1; i++)
        cout << ciclu[i] << " ";

    return 0;
}
