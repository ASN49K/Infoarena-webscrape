#include <fstream>
#include <stack>
#include <vector>

#define N 100000
#define M 500000

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m;
vector <int> v[N + 1], r;
int from[M + 1], to[M + 1];
stack <int> st;
bool viz[M + 1];

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        from[i] = x;
        to[i] = y;
        v[x].push_back(i);
        v[y].push_back(i);
    }
    for(int i = 1; i <= n; i++){
        if(v[i].size() % 2 == 1){
            fout << -1;
            return 0;
        }
    }
    st.push(1);
    while(!st.empty()){
        int nc = st.top();
        if(v[nc].size()){
            int mc = v[nc].back();
            v[nc].pop_back();
            if(!viz[mc]){
                viz[mc] = true;
                int nv = nc ^ from[mc] ^ to[mc];
                st.push(nv);
            }
        }
        else{
            r.push_back(nc);
            st.pop();
        }
    }
    r.pop_back();
    for(int j = 0; j < r.size(); j++)
        fout << r[j] << ' ';
    return 0;
}
