#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
struct Edge
{
    int nod1;
    int nod2;
};
vector<Edge>edges;
vector<vector<int>>G;
vector<int>euler;
bool ok=1;
bool del[1000001];
int get_nxt(int nod)
{
    while(!G[nod].empty() && del[G[nod].back()])
    {
        G[nod].pop_back();
    }
    if(G[nod].empty())
    {
        return 0;
    }
    int edge_idx=G[nod].back();
    del[edge_idx]=true;
    Edge edge=edges[edge_idx];
    return edge.nod1+edge.nod2-nod;
}
void find_euler(int nod)
{
    while(int nxt=get_nxt(nod))
    {
        find_euler(nxt);
    }
    euler.push_back(nod);
}
int n,m;
int nod1,nod2;
int main()
{
    Edge current_edge;
    fin>>n>>m;
    G.resize(n+1);
    
    for(int i=1;i<=m;i++)
    {
        fin>>current_edge.nod1>>current_edge.nod2;
        edges.push_back(current_edge);
        G[current_edge.nod1].push_back(edges.size()-1);
        G[current_edge.nod2].push_back(edges.size()-1);
    }
    find_euler(1);
    for(int i=1;i<n;i++)
    {
        if((G[i].size())%2!=0)
        {
            ok=0;
            break;
        }
    }
    if(ok==0)
    fout<<-1;
    else
    {
        for(int i=0;i<euler.size()-1;i++)
        {
            fout<<euler[i]<<" ";
        }
    }
}
