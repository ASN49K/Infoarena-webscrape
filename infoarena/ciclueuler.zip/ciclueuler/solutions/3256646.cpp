#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n, m, x, y;
vector<vector<pair<int, int>>> edges;
vector<int> viz, used, ans;
void dfs(int node)
{
    used[node] = 1;
    for(auto next:edges[node])
        if(!used[next.first])
            dfs(next.first);
}
bool iseuler()
{
    dfs(1);
    for(int i=1; i<=n; i++)
        if(!used[i])
            return 0;
    for(int i=1; i<=n; i++)
        if(edges[i].size() % 2)
            return 0;
    return 1;
}
void dfseuler(int node)
{
    while(!edges[node].empty())
    {
        auto edge = edges[node].back();
        if(viz[edge.second])
        {
            edges[node].pop_back();
            continue;
        }
        edges[node].pop_back();
        viz[edge.second] = 1;
        dfseuler(edge.first);
    }
    ans.push_back(node);
}
int main()
{
    cin >> n >> m;
    viz.resize(m+1);
    used.resize(n+1);
    edges.assign(n+1, vector<pair<int, int>>());
    for(int i=1; i<=m; i++)
    {
        cin >> x >> y;
        edges[x].push_back({y, i});
        edges[y].push_back({x, i});
    }
    if(iseuler())
    {
        dfseuler(1);
        reverse(ans.begin(), ans.end());
        for(auto i:ans)
            cout << i << " ";
    }
    else
        cout << "-1";
    return 0;
}
