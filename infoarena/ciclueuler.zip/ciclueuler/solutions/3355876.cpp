#include <fstream>
#include <vector>

using namespace std;

struct muchie {
    int x, y;
    int celalalt(int vf) {
        return (x + y - vf);
    }
};

vector <muchie> vm;
vector <vector <int>> a;
vector <bool> mfol;
vector <int> ciclu_e;
vector <int> poz_lst;

bool toate_gradele_pare() {
    int n = (int)a.size() - 1;
    for (int i = 1; i <= n; i++) {
        if (a[i].size() % 2 != 0) {
            return false;
        }
    }
    return true;
}

int primul_varf_neizolat() {
    int n = (int)a.size() - 1;
    for (int i = 1; i <= n; i++) {
        if (a[i].size() != 0) {
            return i;
        }
    }
    return 0;
}

void euler(int x) {
    // for (int i = poz_lst[x]; i < a[x].size(); i++) {
    while (poz_lst[x] < (int)a[x].size()) {
        int p = a[x][poz_lst[x]++];
        if (!mfol[p]) {
            mfol[p] = true;
            int y = vm[p].celalalt(x);
            euler(y);
        }
    }
    ciclu_e.push_back(x);
}

int main() {
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    int n, m;
    in >> n >> m;
    vm.resize(m);
    a.resize(n + 1);
    poz_lst.resize(n + 1, 0);
    mfol.resize(m, false);
    for  (int i = 0; i < m; i++) {
        in >> vm[i].x >> vm[i].y;
        a[vm[i].x].push_back(i);
        a[vm[i].y].push_back(i);
    }
    in.close();
    bool exista = false;
    if (toate_gradele_pare()) {
        int x_0 = primul_varf_neizolat();
        if (x_0 != 0) {
            euler(x_0);
            if ((int)ciclu_e.size() == m + 1) {
                for (auto x : vector <int> (ciclu_e.begin(), ciclu_e.end() - 1)) {
                    out << x << " ";
                }
                /*
                for (int i = 0; i < (int)ciclu_e.size() - 1; i++) {
                    out << ciclu_e[i] << " ";
                }
                */
                out << "\n";
                exista = true;
            }
        }
    }
    if (!exista) {
        out << "-1\n";
    }
    out.close();
    return 0;
}