#include <bits/stdc++.h>

#define int long long
#define pii pair<int, int>
#define fs first
#define sd second

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m;
vector<int> g[100005], eulerpath;
bool used[500005];
pii e[500005];

void dfs(int node) {
    for(auto nxt : g[node]) {
        if(used[nxt] == 0) {
            used[nxt] = 1;
            if(node == e[nxt].fs) dfs(e[nxt].sd);
            else dfs(e[nxt].fs);
        }
    }
    eulerpath.push_back(node);
}

signed main() {
    in >> n >> m;
    for(int i = 1; i <= m; i++) {
        int u, v; in >> u >> v;
        g[u].push_back(i);
        g[v].push_back(i);
        e[i] = {u, v};
    }
    for(int i = 1; i <= n; i++) {
        if(g[i].size() % 2 == 1) {
            out << -1 << '\n';
            return 0;
        }
    }
    dfs(1);
    for(auto elem : eulerpath) {
        out << elem << ' ';
    }
    out << '\n';
    return 0;
}
