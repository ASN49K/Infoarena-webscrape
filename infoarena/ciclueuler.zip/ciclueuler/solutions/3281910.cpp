#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

vector<int> adj[100005];
vector<int> eulerianPath;

void findEulerianCycle(int u) {
    while (!adj[u].empty()) {
        int v = adj[u].back();
        adj[u].pop_back();
        auto it = find(adj[v].begin(), adj[v].end(), u);
        if (it != adj[v].end()) adj[v].erase(it); // Elimină muchia și din invers
        findEulerianCycle(v);
    }
    eulerianPath.push_back(u);
}

int main() {
    int n, m, u, v;
    cin >> n >> m;
    adj.resize(n);

    vector<int> degree(n, 0);

    for (int i = 0; i < m; i++) {
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
        degree[u]++;
        degree[v]++;
    }

    // Verificare dacă toate nodurile au grad par
    for (int i = 0; i < n; i++) {
        if (degree[i] % 2 != 0) {
            cout << "Graful nu are ciclu eulerian!" << endl;
            return 0;
        }
    }

    // Găsirea ciclului Eulerian
    findEulerianCycle(0);

    // Afișare rezultat
    for (int node : eulerianPath) {
        cout << node << " ";
    }
    cout << endl;

    return 0;
}
