#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
#define cin fin
#define cout fout
int n,m,fr[500005],x,y,app[100005],grad[500005];
vector<pair<int,int>> g[100005];
vector<int> rez;
void dfs(int n)
{
    app[n]++;
    while(!g[n].empty())
    {
        if(fr[g[n].back().second])
        {
            g[n].pop_back();
            continue;
        }
        fr[g[n].back().second]=1;
        int urm=g[n].back().first;
        g[n].pop_back();
        dfs(urm);
    }
    rez.push_back(n);
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        cin>>x>>y;
        g[x].push_back({y,i});
        g[y].push_back({x,i});
        grad[x]++;
        grad[y]++;
    }
    for(int i=1;i<=n;i++)
        if(grad[i]%2)
        {
            cout<<-1;
            return 0;
        }

    dfs(1);
    for(int i=1; i<=n; i++)
        if(!app[i] && grad[i])
        {
            cout<<-1;
            return 0;
        }
    rez.pop_back();
    for(int i=0;i<rez.size();i++)
        cout<<rez[i]<<' ';
    return 0;
}
