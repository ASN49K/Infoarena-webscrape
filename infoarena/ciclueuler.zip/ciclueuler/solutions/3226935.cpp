#include <algorithm>
#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <map>
#include <set>

#include <iomanip>
#include <cassert>

#include <random>
#include <chrono>

// #pragma GCC optimize("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

using ull = unsigned long long;
//using ll = long long;

//#define int __int128
//#define int ll
#define pii pair <int, int>
#define all(a) (a).begin(), (a).end()
#define fr first
#define sc second
#define pb push_back
#define lb lower_bound
#define ub upper_bound

#define vt vector
#define FOR(a, b) for(int i = (a); i <= (b); i++)
#define FORr(a, b) for(int i = (a); i >= (b); i--)
#define sz(x) (int)(x).size()

#define YES cout << "YES\n"
#define NO cout << "NO\n"

using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int rangerng(int l, int r){
    return uniform_int_distribution<>(l, r)(rng);
}

string filename = "input";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

////////////////////////////////////////////////////////////////////////////////////

const int NMAX = 1e5;
const int MMAX = 5e5;


pii edge[MMAX + 1];
vt <int> adj[NMAX + 1];

bool viz[MMAX + 1];

void solve(){
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        edge[i] = {a, b};
        adj[a].pb(i);
        adj[b].pb(i);
    }

    for(int i = 1; i <= n; i++){
        if(sz(adj[i]) % 2 == 1){
            fout << -1 << '\n';
            return;
        }
    }

    stack <int> S;
    S.push(1);

    vt <int> ans;

    while(!S.empty()){
        int node = S.top();

        if(sz(adj[node]) > 0){
            int vec = adj[node].back();
            adj[node].pop_back();

            if(!viz[vec]){
                viz[vec] = 1;
                int other = (node ^ edge[vec].fr ^ edge[vec].sc);
                S.push(other);
            }
        }else{
            ans.pb(node);
            S.pop();
        }
    }

    ans.pop_back();
    for(int x : ans){
        fout << x << ' ';
    }
    fout << '\n';
}   


signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int T;
    //cin >> T;

    T = 1;

    while(T--){
        solve();
    }

    return 0;
}

/*
*/
