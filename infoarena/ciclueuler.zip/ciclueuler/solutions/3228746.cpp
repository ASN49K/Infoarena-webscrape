#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int nmax = 1e5+10;
int n,m;
vector<vector<pair<int,int>>> mat(nmax);
vector<int> ans,visited(5*nmax);
void read_input(){
	fin >> n >> m;
	int nod_1,nod_2;
	for(int i = 1; i <=m; i++){
		fin >> nod_1 >> nod_2;
		mat[nod_1].push_back(make_pair(nod_2,i));
		mat[nod_2].push_back(make_pair(nod_1,i));
	}
};
void dfs(int nod){
	while(mat[nod].size() != 0){
		int nod_aux = mat[nod].back().first;
		int muchie = mat[nod].back().second;
		mat[nod].pop_back();
		if(!visited[muchie]){
			visited[muchie] = 1;
			dfs(nod_aux);
		}
	};
	ans.push_back(nod);
}
int check(){
	int ok = 1;
	for(int i = 1; i <=n; i++){
		if(mat[i].size() % 2 == 1){
			ok = 0;break;
		}
	};
	return ok;
}
int main(){
	read_input();
	if(!check()){
		fout << -1;
	}else{
		dfs(1);
	};
	for(auto x : ans){fout << x << " ";}
	return 0;
}

