#include <bits/stdc++.h>
std::ifstream cin("ciclueuler.in");
std::ofstream cout("ciclueuler.out");
std::unordered_map<int,int>a[100010];
std::unordered_map<int,int>::iterator it;
int n,m,t[100010],nr,x,y;
bool gr[100010];
int tata(int nod)
{
    if(t[nod]==nod) return nod;
    return t[nod]=tata(t[nod]);
}
void calculeaza(int nod)
{
    int b;
    std::stack<int>route;
    route.push(nod);
    while(!a[route.top()].empty())
    {
        b=route.top();
        it=a[b].begin();
        --a[(*it).first][b];
        route.push((*it).first);
        a[b][(*it).first]--;
        if(a[(*it).first][b]==0)
        {
            a[(*it).first].erase(b);
            a[b].erase((*it).first);
        }
    }
    b=route.top();
    route.pop();
    while(!route.empty())
    {
        b=route.top();
        if(!a[b].empty())
        {
            cout<<b<<' ';
            calculeaza(route.top());
        }
        else
            cout<<b<<' ';
        route.pop();
    }
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;++i)
        t[i]=i;
    for(int i=1;i<=m;++i)
    {
        cin>>x>>y;
        gr[x]=!gr[x];
        if(gr[x]==true)
            ++nr;
        else
            --nr;;
        gr[y]=!gr[y];
        if(gr[y]==true)
            ++nr;
        else
            --nr;
        ++a[x][y];
        ++a[y][x];
        t[tata(x)]=tata(y);
    }
    if(nr>0)
    {
        cout<<-1;
        return 0;
    }
    for(int i=1;i<n;++i)
    {
        if(tata(i)!=tata(i+1))
        {
            cout<<-1;
            return 0;
        }
    }
    calculeaza(1);
    return 0;
}
