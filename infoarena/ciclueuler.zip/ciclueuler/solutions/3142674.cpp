#include <fstream>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, i, x, y, r[500002];
int a[100002][100002];
bool ok;

static inline void afis() {
    ok = true;
    for(int i = 1; i <= m; i++) fout << r[i] << " ";
}

static inline void Ciclu(int x, int k) {
    for(int i = 1; i <= n; i++) {
        if(ok) break;
        if(a[x][i]) {
            r[k] = i;
            a[x][i]--;
            a[i][x]--;
            if(k == m + 1) afis();
            else Ciclu(i, k + 1);
            a[x][i]++;
            a[i][x]++;
        }
    }
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        fin >> x >> y;
        a[x][y]++;
        a[y][x]++;
    }
    for(i = 1; i <= n; i++) {
        r[1] = i;
        Ciclu(i, 2);
    }

    return 0;
}
