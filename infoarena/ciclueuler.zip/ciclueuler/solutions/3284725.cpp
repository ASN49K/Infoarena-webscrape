#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n , a[10005][10005] , e[500005] , len;

void Citire()
{
    int x , y;
    fin >> n;
    while(fin >> x >> y)
    {
        a[x][y] = 1;
        a[y][x] = 1;
    }
}

void Euler(int k)
{
    for(int i = 1;i <= n;i++)
        if(a[k][i] == 1)
        {
            a[k][i] = 0;
            a[i][k] = 0;
            Euler(i);
        }
    e[++len] = k;
}

int main()
{
    Citire();
    Euler(1);
    fout << len << "\n";
    for(int i = 1;i <= len;i++)
        fout << e[i] << " ";
    return 0;
}
