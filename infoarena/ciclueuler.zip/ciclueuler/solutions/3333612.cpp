#include <bits/stdc++.h>
using namespace std;
vector <pair<int, int>> M;
vector<int> v[100005];
int n, m, x, y, used[500005], ct, o;
int main()
{
    ifstream f("ciclueuler.in");
    ofstream g("ciclueuler.out");

    f >> n >> m;
    for(int i = 1; i <= m; i ++)
        f >> x >> y, v[x].push_back(M.size()), v[y].push_back(M.size()), M.push_back({x, y}), o -= v[y].size() == 1, o -= v[x].size() == 1;
    if(o)
    {
        g << -1;
        return 0;
    }
    deque <int> q, rez;
    q.push_back(1);

    while(!q.empty())
    {
        int k = q.back();
        if(v[k].size())
        {
            if(!used[v[k].back()])
            {
                ct ++;
                used[v[k].back()] = 1;
                int nod = M[v[k].back()].second;
                if(nod == k)
                    nod = M[v[k].back()].first;

                q.push_back(nod);
            }
            v[k].pop_back();
        }
        else
        {
            q.pop_back();
            rez.push_back(k);
        }
    }
    if(ct == m)
    {
        while(!rez.empty())
            g << rez.front() << " ", rez.pop_front();
    }
    else g << -1;


    return 0;
}
