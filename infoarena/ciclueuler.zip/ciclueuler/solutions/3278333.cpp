#include <bits/stdc++.h>

#define pii pair<int, int>
#define fs first
#define sd second

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m;
vector<int> g[100005], eulerpath;
bool used[500005];
pii e[500005];
int pos[100005];

void dfs(int node) {
    int ind = pos[node];
    while(ind < g[node].size()) {
        pos[node]++;
        // g[node].pop_back();
        int nxt = g[node][ind];
        if(used[nxt] == 0) {
            used[nxt] = 1;
            if(node == e[nxt].fs) dfs(e[nxt].sd);
            else dfs(e[nxt].fs);
        }
        ind = pos[node];
    }
    eulerpath.push_back(node);
}

signed main() {
    in >> n >> m;
    for(int i = 1; i <= m; i++) {
        int u, v; in >> u >> v;
        g[u].push_back(i);
        g[v].push_back(i);
        e[i] = {u, v};
    }
    for(int i = 1; i <= n; i++) {
        if(g[i].size() % 2 == 1) {
            out << -1 << '\n';
            return 0;
        }
    }
    dfs(1);
    for(auto elem : eulerpath) {
        out << elem << ' ';
    }
    out << '\n';
    return 0;
}
