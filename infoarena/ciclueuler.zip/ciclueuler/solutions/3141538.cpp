#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX = 100005, MMAX = 500005;
int n, m;
vector <int> G[NMAX];
bool hasEdge[MMAX];
int from[MMAX], to[MMAX];
int main() {
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(i);
        G[y].push_back(i);
        from[i] = x;
        to[i] = y;
    }
    for(int i=1;i<=n;i++)
        if ((int)(G[i].size()) % 2 == 1)
        {
            fout << "-1\n";
            return 0;
        }

    vector <int> ans;
    vector <int> stk;
    stk.push_back(1);
    while (!stk.empty()) {
        int nod = stk.back();
        if (!G[nod].empty()) {
            int e = G[nod].back();
            G[nod].pop_back();
            if (!hasEdge[e]) {
                hasEdge[e] = true;
                int vecin = from[e] ^ to[e] ^ nod;
                stk.push_back(vecin);
            }
        }
        else {
            stk.pop_back();
            ans.push_back(nod);
        }
    }

    for (int i = 0; i < (int)(ans.size()) - 1; i++)
        fout << ans[i] << " ";
    fout << endl;
    return 0;
}