/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector<vector<int>> graf;
vector<pair<int, int>> dict;
vector<int> idx, sz;
vector<bool> viz;
queue<int> cycle; int k;

void eulerCycle(int vf) {
    while (idx[vf] < sz[vf]) {
        int val = graf[vf][idx[vf]];
        if (!viz[val]) {
            viz[val] = true;
            if (dict[val].first == vf) { eulerCycle(dict[val].second); }
            else { eulerCycle(dict[val].first); }
        }
        idx[vf]++;
    }
    k++;
    cycle.push(vf+1);
}

int main() {
    int n, m, l = 0; fin >> n >> m;
    graf.resize(n); sz.assign(n, 0);
    
    for (int i = 0; i < m; i++) {
        int x, y; fin >> x >> y; x--; y--;
        graf[x].push_back(l); sz[x]++;
        graf[y].push_back(l); sz[y]++;
        dict.push_back({x, y}); l++; 
    }

    bool flag = false;
    for (int i = 0; i < n && !flag; i++) {
        if (sz[i] % 2 != 0) {
            fout << -1; flag = true;
        }
    }
    
    if (!flag) {
        viz.assign(m, false); idx.assign(n, 0);
        eulerCycle(0);
        
        while (k > 1) {
            fout << cycle.front() << ' '; cycle.pop(); k--;
        }
    }    

    fin.close(); fout.close(); return 0;
}