#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

struct Edge {
    int to;
    int id;
};

vector<vector<Edge>> adj;
vector<int> degree;
vector<bool> vis;

int main() {
    int n, m;
    cin >> n >> m;

    adj.resize(n + 1);
    degree.assign(n + 1, 0);
    vis.assign(m, false);

    for(int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        adj[a].push_back({b, i});
        adj[b].push_back({a, i});

        degree[a]++;
        degree[b]++;
    }

    int start_node = 1;
    for(int i = 1; i <= n; i++) {
        if (degree[i] > 0) {
            start_node = i;
            break;
        }
    }
    for(int i = 1; i <= n; i++) {
        if(degree[i] % 2 != 0) {
            cout << -1;
            return 0;
        }
    }

    vector<int> ans;
    stack<int> s;
    s.push(start_node);
    vector<int> ptr(n + 1, 0);

    while(!s.empty()) {
        int node = s.top();

        if(ptr[node] < adj[node].size()) {
            Edge e = adj[node][ptr[node]];
            ptr[node]++;

            if(!vis[e.id]) {
                vis[e.id] = true;
                s.push(e.to);
            }
        } else {
            ans.push_back(node);
            s.pop();
        }
    }

    if(ans.size() != m + 1) {
        cout << -1;
    } else {
        for(int i = 0; i < ans.size() - 1; i++) {
            cout << ans[i] << " ";
        }
    }
    return 0;
}
