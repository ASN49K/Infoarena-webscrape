#include <iostream>
#include <fstream>
#include <vector>


std::ifstream fin("ciclueulerin");
std::ofstream fout("ciclueuler.out");


class Graph {
    int V;
    int M;
    std::vector<std::vector<std::pair<int, int>>>adj;
    std::vector<int>degree;
    std::vector<int>vizEdge;
    std::vector<int>result;
public:
    Graph(int n, int m) {
        V = n;
        M = m;
        adj.resize(V+1);
        degree.resize(V+1, 0);
        vizEdge.resize(m+1);
    }

    void addEdge(int x, int y, int i) {
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
        degree[x]++;
        degree[y]++;
    }

    void dfs(int s) {
        while(!adj[s].empty()) {
            std::pair<int, int> edge = adj[s].back();
            adj[s].pop_back();

            int v = edge.first;
            int id = edge.second;

            if(vizEdge[id]) {
                continue;
            }

            vizEdge[id] = true;
            dfs(v);
        }
        result.push_back(s);
    }

    void verify() {
        bool flag = true;
        for(int i=1;i<=V;++i) {
            if(degree[i] % 2 != 0) {
                flag = false;
            }
        }

        if(!flag) fout<<-1;
        else {
            int start_node = 1;   // gasim un nod de start cu grad mai mare decat 0
            for(int i=1;i<=V;++i) {
                if(degree[i] > 0) {
                    start_node = i;
                    break;
                }
            }

            dfs(start_node);

            if(result.size() != M+1) fout<<-1;
            else {
                for(int i=0;i<result.size()-1;++i) {
                    fout<<result[i]<< " ";
                }
            }
        }
    }
};



int main(void) {
    int n, m, x, y;

    fin >> n >> m;
    Graph g(n, m);

    for(int i=1;i<=m;++i) {
        fin >> x >> y;
        g.addEdge(x, y, i);
    }

    g.verify();
    return 0;
}