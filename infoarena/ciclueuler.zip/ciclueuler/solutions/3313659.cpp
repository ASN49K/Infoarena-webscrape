#pragma GCC optimize ("Ofast, unroll-loops")
#include <fstream>
#include <vector>
#include <bitset>

using namespace std;
const int NMAX = 5e5;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

pair <int, int> edge[NMAX + 2];
vector <vector <pair <int, int>>>v; ///first = nod, second = id

bitset <NMAX + 2> viz; ///muchiile
vector <int> ans;
void dfs(int start) {
    for(auto x : v[start]) {
        if(!viz[x.second]) {
            viz[x.second] = 1;
            dfs(x.first);
        }
    }
    ans.push_back(start);
}
int main() {
    int n, m;
    cin >> n >> m;
    v.resize(n + 1);
    for(int i = 1; i <= m; i++) {
        cin >> edge[i].first >> edge[i].second;
        v[edge[i].first].push_back({edge[i].second, i});
        v[edge[i].second].push_back({edge[i].first, i});
    }
    for(int i = 1; i <= n; i++) {
        if(v[i].size() % 2) {
            cout << "-1";
            return 0;
        }
    }
    dfs(n / 2);
    ans.pop_back();
    for(auto x : ans)
        cout << x << " ";
    return 0;
}