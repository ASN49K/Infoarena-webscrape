///EULER(recursiv)

#include<fstream>
#include<vector>
#include<bitset>
using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

const int N=1e5;
const int M=5e5;

struct muchie
{
    int x;
    int y;
};

muchie e[M];
bitset <M> sterse;
int n, m, prim[N+1];

vector<int> a[N+1];
vector<int> ce;

bool grade_pare()
{
        for(int i=1; i<=n; i++)
        {
            if(a[i].size()%2!=0)
                return false;
        }
        return true;
}

int celalalt_vf(muchie e, int x)
{
        return (e.x + e.y - x);
}

void euler(int x)
{
    while(prim[x] < (int) a[x].size())
    {
        int i_e_c = a[x][prim[x]++]; ///indicele muchiei curente
        muchie e_c = e[i_e_c]; ///muchia curenta
        int y = celalalt_vf(e_c, x);
        if(!sterse[i_e_c])
        {
            sterse[i_e_c]=1;
            euler(y);
        }
    }
    ce.push_back(x);
}

int main()
{
    cin >> n >> m;
    for(int i=0; i<m; i++)
    {
        cin >> e[i].x >> e[i].y;
        a[e[i].x].push_back(i);
        a[e[i].y].push_back(i);
    }

    if(!grade_pare())
    {
        cout << -1;
        return 0;
    }
    euler(1);

    if((int)ce.size() != m+1)
    {
        cout << -1;
        return 0;
    }
    for(int i=0; i < (int) ce.size()-1; i++)
    {
        cout << ce[i] << " ";
    }
    return 0;
}
