#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct muchie{
    int start, end;
};

int grad[100001];

muchie muchii[100001];

vector<int> adj[100001];

vector<int> ciclu;

bool viz[100001];
void ciclu_euler(int start){
    if(grad[start]!=0){
        for(auto edge : adj[start]){
            if(viz[edge]) continue;

            viz[edge]=true;

            int next=(muchii[edge].end==start) ? muchii[edge].start : muchii[edge].end;

            grad[start]--; grad[next]--;

            ciclu_euler(next);
        }
    }

    ciclu.push_back(start);
}

int main(){
    ifstream fin("ciclueuler.in");
    ofstream fout("ciclueuler.out");

    int n, m; fin>>n>>m;

    for(int i=0; i<m; i++){
        int x, y; fin>>x>>y;

        muchii[i]={x, y};

        adj[x].push_back(i);
        adj[y].push_back(i);

        grad[x]++;
        grad[y]++;
    }

    for(int i=1; i<=n; i++){
        if(grad[i]%2==1){
            fout<<-1;
            return 0;
        }
    }

    ciclu_euler(1);

    for(int i=0; i<m; i++){
        fout<<ciclu[i]<<" ";
    }

    return 0;
}

