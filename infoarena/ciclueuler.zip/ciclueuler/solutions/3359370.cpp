#include <bits/stdc++.h>
using namespace std;

int main() {
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
    cin.tie(0); cout.tie(0);
	ios_base::sync_with_stdio(false);

    int N, M;
    cin >> N >> M;
    vector<vector<pair<int, int>>>G(N + 3);
    vector<int>v(M);
    for(int i = 0; i < M; i++) {
        int x, y; cin >> x >> y;
        G[x].push_back({y, i}); 
        G[y].push_back({x, i});
    }

    bool ok = 1;

    for(int i = 1; i <= N; i++) {
        ok &= (G[i].size() % 2 == 0);
    }
    if(ok == 0) cout << -1;
    else {
        vector<int>ans;
        auto dfs = [&] (int nod, auto self) -> void{
            // cerr << nod << ' ';
            for(auto [ne, idx] : G[nod]) {
                if(v[idx] == 0) {
                    v[idx] = 1;
                    self(ne, self);
                }
            }
            ans.push_back(nod);
        };
        dfs(1, dfs);
        for(int i = 0; i < M; i++) {
            ok &= v[i];
        }
        if(ok == 0) {
            cout << -1;
            return 0;
        }
        ans.pop_back();
        for(auto i : ans) cout << i << ' ';
    }

}
