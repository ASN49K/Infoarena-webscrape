#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
typedef pair<int,int> pii;
int n,m;
struct date
{
    int nod,id;
};
int used[100005];
bool f[500005];
vector <date> vec[100005];
vector <int> ciclu;
void euler(int nod)
{
    while(vec[nod].size()>0)
    {
        date nei=vec[nod].back();
        vec[nod].pop_back();
        if(f[nei.id]==0)
        {
            f[nei.id]=1;
            euler(nei.nod);
        }
    }
    ciclu.push_back(nod);
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        vec[x].push_back({y,i});
        vec[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(vec[i].size()%2==1)
    {
        fout<<"-1";
        return 0;
    }
    euler(1);
    ciclu.pop_back();
    for(auto x:ciclu)
        fout<<x<<' ';
    return 0;
}
