#include <fstream>
#include <vector>
#include <stack>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct Vecin {
    int muchie, fiu;
};

using VV    = vector<Vecin>;
using Iter  = VV::iterator;
using VIter = vector<Iter>;
using VVV   = vector<VV>;
using VB    = vector<bool>;
using VI    = vector<int>;

VVV G;
VI L;
VB v;
int n, m;

void CitesteDate();
bool EsteEulerian();
void GasesteCiclu(int x);
void ScrieCiclu();

int main()
{
    CitesteDate();
    if(!EsteEulerian())
    {
        fout << -1;
        return 0;
    }

    GasesteCiclu(1);
    ScrieCiclu();
    return 0;
}

void GasesteCiclu(int x)
{
    VIter ptr(n + 1);
    for(int x = 1; x <= n; ++x)
        ptr[x] = G[x].begin();

    stack<int> stk;
    stk.push(x);
    while(!stk.empty())
    {
        x = stk.top();
        if(G[x].end() == ptr[x])
        {
            stk.pop();
            L.push_back(x);
        }
        else
        {
            auto[e, y] = *ptr[x]++;
            if(v[e]) continue;

            v[e] = true;
            stk.push(y);
        }
    }
}

void ScrieCiclu()
{
    for(int x : L)
        fout << x << ' ';
}


bool EsteEulerian()
{
    for(int x = 1; x <= n; ++x)
        if(G[x].size() & 1)
            return false;
    return true;
}

void CitesteDate()
{
    fin >> n >> m;
    v = VB(m + 1);
    G = VVV(n + 1);

    for(int x, y, i = 1; i <= m; ++i)
    {
        fin >> x >> y;
        G[x].emplace_back(i, y);
        G[y].emplace_back(i, x);
    }
}
