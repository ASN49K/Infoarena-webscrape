#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
#define nmax  100005
vector<pair<int,int> >g[nmax];
int grd[nmax];
int n,m,x,y,nr,rez[nmax];
void euler(int x)
{
    for(int i=0; i<g[x].size(); i++)
    {
        int y=g[x][i].first;
        if(y)
        {
            g[y][g[x][i].second]= {0,0};
            g[x][i]= {0,0};
            euler(y);
        }
    }
    rez[++nr]=x;
}
int main()
{
    fin>>n>>m;
    int i;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        g[x].push_back({y,g[y].size()});
        if(x!=y) g[y].push_back({x,g[x].size()-1});
        grd[x]++;
        grd[y]++;
    }
    for(i=1; i<=n; i++)
    {
        if(grd[i]%2)
        {
            fout<<-1;
            return 0;
        }

    }

    euler(1);
        for(i=1; i<=nr; i++)fout<<rez[i]<<" ";

    return 0;
}
