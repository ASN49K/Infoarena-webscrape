#include <fstream>
#include <bitset>
#include <vector>
#include <stack>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector <pair<int,int>> G[100010];
int D[100010];

bitset<100010> b;
bitset<500010> f;
stack<int> st;

void dfs(int node) {
    b[node] = 1;

    for (auto it : G[node]) {
        if (b[it.first] == 0) {
            dfs(it.first);
        }
    }
}

int main() {
    int n, m;
    fin >> n >> m;
    
    for (int i=1; i <= m; ++i) {
        int x, y;
        fin >> x >> y;

        G[x].push_back( make_pair(y, i) );
        G[y].push_back( make_pair(x, i) );

        D[x]++;
        D[y]++;
    }

    int source = -1;
    for (int i = 1; i <= n; ++i) {
        if (D[i] != 0) {
            source = i;
            dfs(i);
            break;
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (D[i] % 2 == 1 || (D[i] !=0 && b[i] == 0 )) {
            fout << -1;
            return 0;
        }
    }

    bool isFirst = true;

    st.push(source);
    while (!st.empty()) {
        int node = st.top();

        if (D[node] == 0) {
            if (!isFirst)
                fout << node <<" ";
            isFirst = false;

            st.pop();
            continue;
        }

        while (f[G[node].back().second] == 1)
            G[node].pop_back();

        int vecin = G[node].back().first;
        D[vecin]--;
        D[node]--;
        f[G[node].back().second] = 1;
        G[node].pop_back();

        st.push(vecin);
    }

    return 0;
}