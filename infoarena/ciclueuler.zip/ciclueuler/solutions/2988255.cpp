#include<bits/stdc++.h>
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n,m,nr[100005],viz[100005],ans[100005],k;
vector< pair<int,int> >v[100005];
stack<int>s;

signed main()
{
    int i,x,y,ok,l;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    ok=0;
    for(i=1;i<=n;i++)
    {
        if(v[i].size()%2==1)
        {
            ok=1;
            break;
        }
    }
    if(ok==1)
        g<<-1;
    else
    {
        s.push(1);
        while(!s.empty())
        {
            int nod=s.top();
            l=v[nod].size();
            if(nr[nod]<l)
            {
                if(viz[v[nod][nr[nod]].second]==0)
                    viz[v[nod][nr[nod]].second]=1,s.push(v[nod][nr[nod]].first);
                nr[nod]++;
            }
            else
            {
                ans[++k]=nod;
                s.pop();
            }
        }
        for(i=k;i>1;i--)
            g<<ans[i]<<" ";
    }
    return 0;
}
