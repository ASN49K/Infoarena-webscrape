#include <bits/stdc++.h>
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
struct elem
{
    int nod, idx;
};
vector <elem> v[100009];
int viz[500009], grad[100009];
vector <int> ans;
int n, m;
void dfs0 (int nod)
{
    viz[nod]=1;
    for (auto y:v[nod])
    {
        if (!viz[y.nod])
            dfs0(y.nod);
    }
}
void dfs (int nod)
{
    while (v[nod].size()>0)
    {
        elem x=v[nod].back();
        v[nod].pop_back();
        //cout << v[nod].back().nod<< ' ';
        if (!viz[x.idx])
        {
            //cout << v[nod].back().idx<< ' ';
            viz[x.idx]=1;
            dfs (x.nod);
        }
    }
    ans.push_back(nod);
}
signed main ()
{
    f >> n >> m;
    int idx=0;
    while (m--)
    {
        int x, y;
        f >> x >> y;
        v[x].push_back({y, ++idx});
        v[y].push_back({x, idx});
        grad[x]++, grad[y]++;
    }
    //cout << idx<< ' ';
    dfs0 (1);
    for (int i=1; i<=n; i++)
        if (!viz[i] || grad[i]%2)
        {
            g<<-1;
            exit(0);
        }
    for (int i=1; i<=n+m; i++)
        viz[i]=0;
    dfs (1);
    for (auto y:ans)
        g << y << ' ';
}
