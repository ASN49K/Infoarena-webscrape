#include <fstream>

#include <utility>
#define x first
#define y second

#include <vector>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

typedef pair <int, int> pii;
const int nmax = 1e5, kkmax = 5e5;
int n, kk, xx, yy;

vector <pii> muchii[nmax + 2];
int usededges[kkmax + 2];

vector <int> euleredges;

void dfscheckeuler(int node){

    euleredges.push_back(node);

    for(int it = muchii[node].size() - 1; it >= 0; it--){
        it = min(it, int(muchii[node].size()) - 1); if(it < 0){ return; }

        if(usededges[muchii[node][it].y]){ continue; }

        muchii[node].pop_back();

        usededges[muchii[node][it].y] = 1;

        dfscheckeuler(muchii[node][it].x);
    }
    return;
}

int main(){

    in>>n>>kk;
    for(int it = 1; it <= kk; it++){
        in>>xx>>yy;
        muchii[xx].push_back(make_pair(yy, it));
        muchii[yy].push_back(make_pair(xx, it));
    }

    dfscheckeuler(1);

    if(euleredges.back() != 1 || euleredges.size() != kk + 1){
        out<<"-1\n"; return 0; ///failed - no eulerian cycle
    }

    euleredges.pop_back();

    for(auto f : euleredges)
        out<<f<<" ";

    return 0;
}
