#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <stack>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
stack<int> s;
#define NMAX 100005
vector<int> g[NMAX];
map<pair<int, int>, int> mp;
vector<int> sol;
void euler(int n)
{
    s.push(1);
    while (!s.empty())
    {
        s.pop();
        for (auto i : g[n])
        {

            if (mp[{n, i}] > 0)
            {
                cout << i << " " << n << '\n';

                mp[{n, i}]--;
                mp[{i, n}]--;
                euler(i);
            }
        }
        sol.push_back(n);
    }

    // fout << n << " ";
}
int main()
{
    int n, m;
    fin >> n >> m;
    while (m--)
    {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
        mp[{x, y}]++;
        mp[{y, x}]++;
    }
    bool isEuleralian = true;
    for (int i = 1; i <= n; i++)
    {
        if (g[i].size() % 2)
        {
            isEuleralian = false;
        }
    }
    if (!isEuleralian)
    {
        fout << -1;
        return 0;
    }
    euler(1);
    sol.pop_back();
    for (auto i : sol)
    {
        fout << i << " ";
    }
    return 0;
}