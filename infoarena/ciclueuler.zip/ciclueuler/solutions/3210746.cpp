#include <fstream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m,x,y,i;
bool ok,viz[500002];
vector <int> SOL;
vector <pair<int,int>> L[100002];
void euler(int nod)
{
    while(L[nod].size())
    {
        int vecin=L[nod].back().first;
        int j=L[nod].back().second;
        L[nod].pop_back();
        if(!viz[j])
        {
            viz[j]=1;
            euler(vecin);
        }
    }

    SOL.push_back(nod);
}
int main()
{
    fin>>n;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        L[x].push_back({y,i});
        L[y].push_back({x,i});
    }
    for(i=1;i<=n;i++)
        if((L[i].size()&1))
        {
            fout<<-1<<"\n";
            return 0;
        }

    euler(1);
    //fout<<SOL.size()<<"\n";
    for(int i=0;i<SOL.size()-1;i++)
        fout<<SOL[i]<<" ";
    return 0;
}
