#include <bits/stdc++.h>

using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

const int NMAX = 1e5;
const int MMAX = 5e5;

struct muchie{
  
  int id, to;
    
};

vector<muchie> adj[NMAX+1];

int n, m;

bool deleted[MMAX+1];

int rez[MMAX+1];

int nextEdge(int nod){
    
    while(!adj[nod].empty() and deleted[adj[nod].back().id])
        adj[nod].pop_back();
        
    if(adj[nod].empty())
        return -1;
    
    deleted[adj[nod].back().id] = true;
    
    return adj[nod].back().to;
    
}

int cnt;

void euler(int nod){
    
    for(auto edge : adj[nod]){
        
        int vecin = nextEdge(nod);
        
        if(vecin != -1)
            euler(vecin);
        
    }
    
    cnt ++;
    rez[cnt] = nod;
    
}

int main()
{
    
    f >> n >> m;
    
    for(int i=1; i<=m; i++){
        
        int x, y;
        f >> x >> y;
        
        adj[x].push_back({i, y});
        adj[y].push_back({i, x});
        
    }
    
    euler(1);
    
    if(cnt != m + 1){
        
        g << -1;
        return 0;
        
    }
    
    for(int i=1; i<cnt; i++)
        g << rez[i] << " ";
        

    return 0;
}