/// Eulerian cycle/path
/// O(E)

#include <bits/stdc++.h>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

using ll = long long;
using pii = pair<int, int>;

const int NMAX = 1e5 + 5;
const int INF = 0x3f3f3f3f;

int n, m;
vector<pii> edges(NMAX * 5);
vector<vector<int>> graph(NMAX);
vector<int> path;
bool used[NMAX * 5];

void read()
{
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; i++)
        in >> x >> y, graph[x].push_back(i), graph[y].push_back(i), edges[i] = {x, y};
    // edges[e].first -> nodul de unde vine prin edge, edges[e].second -> nodul to unde ajunge prin in edge
}

void EulerPath()
{
    vector<int> st; // stack
    st.push_back(1);
    while (!st.empty())
    {
        int node = st.back();
        if (graph[node].empty()) // nu mai are muchii
        {
            path.push_back(node);
            st.pop_back();
        }
        else
        {
            int e = graph[node].back();
            graph[node].pop_back();
            if (!used[e]) // nu am folosit munchia curenta din care face parte node
            {
                used[e] = true;
                int to = edges[e].first ^ edges[e].second ^ node;
                st.push_back(to);
            }
        }
    }
}

void solve()
{
    for (int i = 1; i <= n; ++i) {
        if (graph[i].size()%2!=0) { //grad impar
            out << "-1\n";
            return;
        }
    }

    EulerPath();
    for (auto node = path.begin(); node<=path.end()-2; node++)
        out << *node << ' ';
}

int main()
{
    read();
    solve();

    return 0;
}