#include<bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int N, M;
vector<int>muchie;
vector<int>u;
vector<int>v;
vector<vector<int> >Ad;
vector<int>pos;
vector<int>cycle;

bool allDegreesEven() {
    for (int i=1;i<=N;i++)
        if (Ad[i].size() % 2 != 0)
            return false;
    return true;
}

void dfs(int nod) {
    while (pos[nod] < Ad[nod].size()) {
        int current_edge = Ad[nod][pos[nod]++];
        if (!muchie[current_edge]) {
            muchie[current_edge] = true;
            dfs(u[current_edge] + v[current_edge] - nod);
        }
    }
    cycle.push_back(nod);
}

int main() {
    fin>>N>>M;
    muchie.assign(M+1, 0);
    u.assign(M+1, 0);
    v.assign(M+1, 0);
    pos.assign(N+1, 0);
    Ad.resize(N+1);
    for (int i = 1; i <= M; i++) {
        fin>>u[i]>>v[i];
        Ad[u[i]].push_back(i);
        Ad[v[i]].push_back(i);
    }
    if (allDegreesEven()) {
        dfs(1);

        for (int i=cycle.size()-1;i>0;i--)
            fout<<cycle[i]<<" ";
    }
    else {
        fout<<-1;
    }



    return 0;
}