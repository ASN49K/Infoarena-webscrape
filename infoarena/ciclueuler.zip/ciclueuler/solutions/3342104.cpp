#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int lim=5e5+10;
int i,n,m,dg[lim];
bool viz[lim];
vector <int> v[lim],e;
vector <pair<int,int>> edge[lim];
void dfs(int k)
{
    viz[k]=1;
    for(auto x:v[k])
        if(viz[x]==0)dfs(x);
}
bool iseuler()
{
    dfs(1);
    for(i=1;i<=n;i++)
    {
        if(viz[i]==0)return 0;
        if(dg[i]%2==1)return 0;
    }
    return 1;
}
void euler(int k)
{
    while(!edge[k].empty())
    {
        auto x=edge[k].back();
        edge[k].pop_back();

        int nod=x.first;
        int ind=x.second;
        if(viz[ind]==0)
        {
            viz[ind]=1;
            euler(nod);
        }
    }
    e.push_back(k);
}
void resetviz()
{
    for(int i=1;i<=m;i++)
        viz[i]=0;
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
        edge[x].push_back({y,i});
        edge[y].push_back({x,i});
        dg[x]++;dg[y]++;
    }
    if(!iseuler()){fout<<"-1";return 0;}
    resetviz();
    euler(1);
    for(auto x:e)
        fout<<x<<" ";
    return 0;
}
