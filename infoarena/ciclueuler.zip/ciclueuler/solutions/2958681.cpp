#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueulerian.in");
ofstream fout("ciclueulerian.out");

int n, m, i, nr1, nr2, aici, cuc;
multiset <int>::iterator vecin;

int main()
{
    fin >> n >> m;
    multiset <int> adjL[n+1];
    for (i = 0; i < m; ++i){
        fin >> nr1 >> nr2;
        adjL[nr1].insert(nr2);
        adjL[nr2].insert(nr1);
    }

    vector <int> ciclu;
    ciclu.reserve(2*m+1);
    stack <int> recurs;
    recurs.push(1);
    int nrmuch = 0;
    while (!recurs.empty()){
        aici = recurs.top();
        if (!adjL[aici].empty()){
            ++nrmuch;
            vecin = adjL[aici].begin();
            cuc  = *vecin;
            adjL[aici].erase(vecin);
            adjL[cuc].erase(adjL[cuc].find(aici));
            recurs.push(cuc);
            continue;
        }
        ciclu.push_back(aici);
        recurs.pop();
    }
    if (nrmuch != m){
        fout << -1;
        return 0;
    }
    for (i = ciclu.size()-1; i >= 1; --i){
        fout << ciclu[i] << ' ';
    }
    return 0;
}
