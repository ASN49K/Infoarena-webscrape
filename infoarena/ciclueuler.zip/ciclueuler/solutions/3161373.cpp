#include <fstream>
#include <vector>
#include <stack>

#define pb push_back

using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
const int N = 1e5 + 5, M = 5e5 + 5;

struct muchie {
    int nxt, cnt;
};
struct elm {
    int nod, ramas;
};

int n, m, grad[N];
bool luat[M];
vector<int> ciclu;
vector<muchie> g[N];
stack<elm> stk;

int main()
{
    in >> n >> m;
    for(int i=1; i<=m; i++) {
        int x, y;
        in >> x >> y;
        grad[x]++;
        if(x != y)
            grad[y]++;
        g[x].pb({y, i});
        g[y].pb({x, i});
    }

    for(int i=1; i<=n; i++)
        if(g[i].size() % 2) {
            out << -1;
            return 0;
        }

    stk.push({1, -1});
    while(!stk.empty()) {
        int nod = stk.top().nod;
        int ramas = stk.top().ramas;
        if(grad[nod]) {
            for(int i=ramas+1; i<g[nod].size(); i++) {
                muchie mc = g[nod][i];
                if(!luat[mc.cnt]) {
                    stk.top().ramas = i;
                    stk.push({mc.nxt, -1});
                    grad[nod]--;
                    if(mc.nxt != nod)
                        grad[mc.nxt]--;
                    luat[mc.cnt] = 1;
                    break;
                }
            }
        }
        else {
            stk.pop();
            ciclu.pb(nod);
        }
    }

    for(int i=0; i<ciclu.size()-1; i++)
        out << ciclu[i] << ' ';
    return 0;
}
