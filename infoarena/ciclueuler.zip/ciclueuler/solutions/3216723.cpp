#include<iostream>
#include<vector>
#include<functional>

using namespace std;
const int NMAX = 1e5 , MMAX = 5e5;
bool viz[MMAX+1];
vector< pair<int , int> > adj[NMAX+1];
int n, m;

bool eulerian ()
{
    vector<bool> visited(n+1 , 0);
    int nodesVisited = 0;
    function<void(int)> dfs = [&](int nod) -> void {
        visited[nod] = 1;
        nodesVisited++;
        for (auto &edge : adj[nod])
        {
            int to = edge.first;
            if (!visited[to]) dfs(to);
        }
    };

    bool ret = 1;
    for (int i = 1; i <= n; i++)
    {
        if (adj[i].size() % 2 != 0) ret = 0;
    }

    dfs(1);
    ret |= (nodesVisited == n);
    return ret;
}

vector<int> eulercycle;
void findEulerCycle (int nod)
{
    for (auto &edge : adj[nod])
    {
        int to = edge.first , ind = edge.second;
        cout << to << ' ' << ind << '\n';
        if (!viz[ind])
        {
            viz[ind] = 1;
            findEulerCycle(to);
        }
    }
    eulercycle.push_back(nod);
}

int main ()
{
    freopen("ciclueuler.in" , "r" , stdin);
    freopen("ciclueuler.out" , "w" , stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y; cin >> x >> y;
        adj[x].push_back({y,i});
        adj[y].push_back({x,i});
    }

    if (eulerian())
    {
        findEulerCycle(1);
        eulercycle.pop_back();
        for (auto &nod : eulercycle)
        {
            cout << nod << ' ';
        }
        cout << '\n';
    }
    else cout << "-1\n";

}