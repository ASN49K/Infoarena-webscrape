/*
  ____   ___  _     ___ ____    _
 / ___| / _ \| |   |_ _/ ___|  / \
 \___ \| | | | |    | | |     / _ \
  ___) | |_| | |___ | | |___ / ___ \
 |____/ \___/|_____|___\____/_/   \_\

*/
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long int
#define pii pair<int,int>

const int NMAX = 2e5+9;

const int MOD = 1e9+7;

const int MMAX = 5e5+9;

int binpow(int n, int k)
{
    if (k==0)
    {
        return 1;
    }
    int x=binpow(n,k/2)%MOD;
    if (k%2==0)
    {
        return x*x%MOD;
    }
    else
    {
        return x*x%MOD*n%MOD;
    }
}

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

#define cin fin
#define cout fout

map<pair<int,int>,int>mep;

int n,i,j,m,a,b;

int from[MMAX],to[MMAX];

vector<int>g[NMAX];

vector<int>stiva;

bool taken[MMAX];

void dfs (int node)
{
    while (!g[node].empty())
    {
        int it = g[node].back();
        g[node].pop_back();
        if (!taken[it])
        {
            taken[it]=1;
            int too;
            if (from[it]==node)
            {
                too=to[it];
            }
            if (to[it]==node)
            {
                too=from[it];
            }
            dfs (too);
        }
    }
    cout<<node<<' ';
}

void run_case ()
{
    cin>>n>>m;
    for (i=1; i<=m; i++)
    {
        cin>>a>>b;
        g[a].pb (i),g[b].pb (i);
        from[i]=a,to[i]=b;
    }
    for (i=1; i<=n; i++)
    {
        if (g[i].size()%2==1)
        {
            cout<<-1;
            return ;
        }
    }
    dfs(1);
}

signed main ()
{
    ios_base::sync_with_stdio(0);
    cin.tie(NULL),cout.tie ();
    int teste;
    teste=1;
    while (teste--)
    {
        run_case();
    }
}
