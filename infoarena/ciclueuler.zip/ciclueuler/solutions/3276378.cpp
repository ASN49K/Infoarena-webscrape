#include <fstream>
#include <vector>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,x,y;
bool viz[nmax*5];
vector<pair<int,int>>v[nmax];
vector<int>sol;
void euler(int nod){
    while(!v[nod].empty()){
        pair<int,int> i=v[nod].back();
        v[nod].pop_back();
        if(!viz[i.second]){
            viz[i.second]=1;
            euler(i.first);
        }
    }
    sol.push_back(nod);
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(v[i].size()%2!=0){
            cout<<-1;
            return 0;
        }
    for(int i=1;i<=n;i++)
        if(v[i].size()!=0){
            euler(i);
            break;
        }
    if(sol.size()!=m+1){
        cout<<-1;
        return 0;
    }
    sol.pop_back();
    for(auto i:sol)
        cout<<i<<" ";
    return 0;
}
