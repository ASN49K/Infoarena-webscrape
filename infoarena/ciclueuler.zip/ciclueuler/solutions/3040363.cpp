#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX=100001, MMAX=500001;

stack<int> ciclu;
vector<int> adj[NMAX], stk;
int n, m, mc[MMAX][2], used[MMAX];

int main(){
    fin >> n >> m;
    for(int i=1; i<=m; i++){
        int x, y;
        fin >> x >> y;
        adj[x].push_back(i);
        adj[y].push_back(i);
        mc[i][0]=x; mc[i][1]=y;
    }
    for(int i=1; i<=n; i++){
        if(adj[i].size()%2){
            fout << -1;
            return 0;
        }
    }
    stk.push_back(1);
    while(!stk.empty()){
        int s = stk.back();
        if(!adj[s].empty()){
            int e = adj[s].back(); adj[s].pop_back();
            //cout << s << ' ' << mc[e][0] << '\n';
            if(!used[e]){
                used[e]=true;
                stk.push_back(mc[e][0]^s^mc[e][1]);
            }
        }else{
            stk.pop_back();
            ciclu.push(s);
        }
    }
    while(ciclu.size()!=1){
        fout << ciclu.top() << ' '; ciclu.pop();
    }
}