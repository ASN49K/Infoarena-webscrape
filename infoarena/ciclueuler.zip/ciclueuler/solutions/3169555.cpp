#include <iostream>
#include <fstream>
#include <stack>
#include <vector>

using namespace std;
int grad[100005], n, m;
int ciclu[500005], cnt;
vector<int>G[100005];
stack<int>stiva;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct abc
{
    int x;
    int y;
    bool f;
} v[500005];

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        grad[x]++;
        grad[y]++;
        v[i].x = x;
        v[i].y = y;
        G[x].push_back(i);
        G[y].push_back(i);
    }
    for(int i = 1; i <= n; i++)
    {
        if(grad[i] % 2 == 1)
        {
            fout << -1;
            return 0;
        }
    }
    stiva.push(1);
    while(!stiva.empty())
    {
        int nod = stiva.top();
        int ok = 0;
        while(G[nod].size())
        {
            int muchie = G[nod].back();
            G[nod].pop_back();
            if(v[muchie].f == 0)
            {
                v[muchie].f = 1;
                ok=1;
                int x = v[muchie].x;
                int y = v[muchie].y;
                if(x != nod)
                    stiva.push(x);
                else
                    stiva.push(y);
                break;
            }
        }
        if(ok == 0)
        {
            ciclu[++cnt] = nod;
            stiva.pop();
        }
    }

    if(cnt != m+1)
    {
        fout << -1;
        return 0;
    }

    for(int i = 1; i < cnt; i++)
        fout << ciclu[i] << " ";

    return 0;
}
