#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

const int N_MAX = 100005;
const int M_MAX = 500005;

int n, m;
int deg[N_MAX];

vector < pair <int, int> > adj[N_MAX];
vector <int> path;
vector <bool> used(M_MAX, false);

void Read()
{
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;
        adj[x].push_back(make_pair(y, i));
        adj[y].push_back(make_pair(x, i));
        deg[x]++, deg[y]++;
    }
}

bool HasCycle()
{
    for (int i = 1; i <= n; i++)
    {
        if (deg[i] % 2 == 1)
        {
            return false;
        }
    }
    return true;
}

void Euler(int startNode)
{
    stack <int> s;
    s.push(startNode);

    while (s.empty() == false)
    {
        int node = s.top();

        if (deg[node] != 0)
        {
            while (adj[node].empty() == false)
            {
                int neighbour = adj[node].back().first;
                int id = adj[node].back().second;
                adj[node].pop_back();

                if (used[id] == false)
                {
                    used[id] = true;
                    deg[node]--, deg[neighbour]--;
                    s.push(neighbour);

                    break;
                }
            }
        }
        else
        {
            path.push_back(node);
            s.pop();
        }
    }
}

void Print()
{
    for (unsigned int i = 0; i < path.size() - 1; i++)
    {
        g << path[i] << " ";
    }
}

int main()
{
    Read();

    if (HasCycle() == true)
    {
        Euler(1);

        if (path.size() < m + 1)
        {
            g << "-1";
            return 0;
        }

        Print();

        return 0;
    }

    g << "-1";

    return 0;
}
