#include <fstream>

#include <utility>
#define x first
#define y second

#include <vector>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

typedef pair <int, int> pii;
const int nmax = 1e5, kkmax = 5e5;
int n, kk, xx, yy;

vector <pii> muchii[nmax + 2];
int usededges[kkmax + 2];

vector <int> euleredges;

void dfscheckeuler(int node){

    euleredges.push_back(node);

    for(int it = muchii[node].size() - 1; it >= 0; it--){
        it = min(it, int(muchii[node].size()) - 1); if(it < 0){ return; }

        pii edge = muchii[node][it]; muchii[node].pop_back();

        if(usededges[edge.y]){ continue; }

        usededges[edge.y] = 1;

        dfscheckeuler(edge.x);
    }
    return;
}

int check(){
    int okkk = 0;
    for(int i = 1; i <= n; i++){
        okkk |= (muchii[i].size() & 1);
    }
    return okkk;
}

int main(){

    in>>n>>kk;
    for(int it = 1; it <= kk; it++){
        in>>xx>>yy;
        muchii[xx].push_back(make_pair(yy, it));
        muchii[yy].push_back(make_pair(xx, it));
    }

    if(check()){ out<<"-1\n"; return 0; }

    dfscheckeuler(1);
    euleredges.pop_back();

    for(auto f : euleredges)
        out<<f<<" ";

    return 0;
}
