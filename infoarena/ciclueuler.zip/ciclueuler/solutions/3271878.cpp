#include <fstream>
#include <iostream>
#include <vector>
#include <bitset>
#include <stack>
using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

const int NMAX = 100000,
          MMAX = 500000;

int n, m;

struct muchie {
    int nod, nrm;

    muchie(int xx = 0, int nn = 0) : nod(xx), nrm(nn) {}
};

vector<muchie> G[NMAX+1];
vector<int> L;
bitset <MMAX> elim;
stack <int> S;

void citire() {
    int x, y;
    f >> n >> m;
    for (int i=1; i<=m; i++) {
        f >> x >> y;
        G[x].push_back(muchie(y, i));
        G[y].push_back(muchie(x, i));
    }
}

void euler() {
    int x;
    muchie mm;
    S.push(1);
    while(!S.empty()) {
        x = S.top();
        if (!G[x].empty()) {
            mm = G[x].back();
            G[x].pop_back();
            if (!elim[mm.nrm]) {
                elim[mm.nrm] = 1;
                S.push(mm.nod);
            }
        } else {
            L.push_back(x);
            S.pop();
        }
    }
}

int main()
{
    bool ok = 1;
    citire();
    for (int i=1; i<=n && ok; i++)
        if (G[i].size() & 1)
            ok = 0;
    if (ok) {
        euler();
        for (int i = L.size()-1; i>=1; i--)
            g << L[i] << ' ';
    } else
        g << "-1\n";
    f.close();
    g.close();
    return 0;
}
