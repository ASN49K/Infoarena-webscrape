#include <bits/stdc++.h>
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
const int NMAX = 100005, MMAX = 500005;
int n, m;
bitset<NMAX> used;
bitset<MMAX> usedEdge;
vector<int> eulerian_cycle, graph[NMAX];
struct Edge
{
    int from, to;
} edges[MMAX];
void dfs(int node)
{
    used[node] = 1;
    for (int edge_idx : graph[node])
    {
        int next = edges[edge_idx].from ^ edges[edge_idx].to ^ node;
        if (!used[next])
            dfs(next);
    }
}
bool is_eulerian()
{
    /// check for connectivity
    dfs(1);
    for (int i = 1; i <= n; i++)
        if (!used[i])
            return 0;

    /// check for even degrees
    for (int i = 1; i <= n; i++)
        if (graph[i].size() % 2)
            return 0;
    return 1;
}
void dfs_euler(int node)
{
    stack<int> s;
    s.push(node);
    while (!s.empty())
    {
        node = s.top();
        while (graph[node].size())
        {
            int edge_idx = graph[node].back();
            graph[node].pop_back();
            if (!usedEdge[edge_idx])
            {
                usedEdge[edge_idx] = 1;
                s.push(edges[edge_idx].from ^ edges[edge_idx].to ^ node);
            }
        }
        s.pop();
        eulerian_cycle.push_back(node);
    }
}
int main()
{
    f >> n >> m;
    for (int i = 1, x, y; i <= m; i++)
    {
        f >> x >> y;
        graph[x].push_back(i);
        graph[y].push_back(i);
        edges[i].from = x;
        edges[i].to = y;
    }
    if (is_eulerian())
    {
        dfs_euler(1);
        for (int i = 0; i < (int)eulerian_cycle.size() - 1; i++)
            g << eulerian_cycle[i] << ' ';
    }
    else
        g << -1;
    return 0;
}