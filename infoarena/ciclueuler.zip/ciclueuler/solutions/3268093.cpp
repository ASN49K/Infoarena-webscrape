#include <fstream>
#include <vector>
#define NMAX 100100
#define MMAX 500100

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n,m;

struct muchie
{
    int x;
    int nr;
};
vector<muchie> G[NMAX];
vector<int> C;
int sters[MMAX];
void euler(int v);

int main()
{
    int i,x,y;

    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        G[x].push_back({y,i});
        G[y].push_back({x,i});
    }

    for(i=1; i<=n; i++)
        if(G[i].size()%2==1 || G[i].size()==0)
        {
            fout<<-1;
            return 0;
        }

    euler(1);

    if(C.size()-1!=m)
    {
        fout<<-1;
        return 0;
    }

    for(i=0; i<C.size()-1; i++)
        fout<<C[i]<<' ';

    return 0;
}

void euler(int v)
{
    int w,i;

    for(i=0; i<G[v].size(); i++)
        if(sters[G[v][i].nr]==0)
        {
            w=G[v][i].x;
            sters[G[v][i].nr]=1;
            euler(w);
        }
    C.push_back(v);
}
