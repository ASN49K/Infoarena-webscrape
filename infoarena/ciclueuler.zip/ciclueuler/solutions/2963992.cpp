#include <fstream>
#include <vector>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int DIM1 = 100001;
const int DIM2 = 500001;
struct muchie {
    int nd, mc;
};
vector<muchie> v[DIM1];
int n, m, x, y;
int poz[DIM1], deg[DIM1];
int st[DIM2], top = 0;
int sol[DIM2], solCnt = 0;
bool vis[DIM2];

int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        v[x].push_back({ y, i });
        v[y].push_back({ x, i });
        deg[x]++, deg[y]++;
    }

    for (int i = 1; i <= n; i++) {
        if (deg[i] % 2 != 0) {
            fout << -1;
            return 0;
        }
    }

    st[++top] = 1;
    while (top > 0) {
        int node = st[top];
        if (deg[node] == 0) {
            top--;
            sol[++solCnt] = node;
        } else {
            for (int j = poz[node]; j < v[node].size(); j++) {
                if (!vis[v[node][j].mc]) {
                    vis[v[node][j].mc] = true;
                    st[++top] = v[node][j].nd;
                    deg[node]--, deg[v[node][j].nd]--;
                    poz[node] = j + 1;
                    break;
                }
            }
        }
    }

    for (int i = 1; i <= solCnt; i++)
        fout << sol[i] << ' ';

    return 0;
}
