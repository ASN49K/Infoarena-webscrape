#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

map<pair<int, int>, int> muchii_sterse;

void sterge_muchie(int u, int v) {
    pair<int,int> muchie = make_pair(min(u, v), max(u, v));
    // if (muchii_sterse.find(muchie) == muchii_sterse.end()) {
    //     muchii_sterse[muchie] = 1;
    // } else {
    //     muchii_sterse[muchie]++;
    // }
    muchii_sterse[muchie]--;
}

bool este_muchie_stearsa(int u, int v) {
    pair<int,int> muchie = make_pair(min(u, v), max(u, v));
    return muchii_sterse[muchie] == 0;
}

vector<int> gaseste_ciclu_eulerian(int nod_start, vector<vector<int>>& lista_vecini) {
    vector<int> ciclu;
    stack<int> stiva;

    stiva.push(nod_start);

    while (!stiva.empty()) {
        int nod = stiva.top();
        if (!lista_vecini[nod].empty()) {
            int vecin = lista_vecini[nod].back();
            lista_vecini[nod].pop_back();

            auto it = find(lista_vecini[vecin].begin(), lista_vecini[vecin].end(), nod);
            if (it != lista_vecini[vecin].end()) {
                lista_vecini[vecin].erase(it);
            }

            if (!este_muchie_stearsa(nod, vecin)) {
                sterge_muchie(nod, vecin);
                stiva.push(vecin);
            }
        } else {
            ciclu.push_back(nod);
            stiva.pop();
        }
    }

    return ciclu;
}


int main() {
    int numar_noduri, numar_muchii;
    fin >> numar_noduri >> numar_muchii;
    vector<vector<int>> lista_vecini(numar_noduri + 1);

    for (int i = 0; i < numar_muchii; i++) {
        int nod1, nod2;
        fin >> nod1 >> nod2;
        lista_vecini[nod1].push_back(nod2);
        lista_vecini[nod2].push_back(nod1);
        auto muchie = make_pair(min(nod1, nod2), max(nod1, nod2));
    if (muchii_sterse.find(muchie) == muchii_sterse.end()) {
        muchii_sterse[muchie] = 1;
    } else {
        muchii_sterse[muchie]++;
    }
    }

    for (int i = 1; i <= numar_noduri; i++) {
        if (lista_vecini[i].size() % 2 == 1) {
            fout << "-1" << endl;
            return 0;
        }
    }

    vector<int> ciclu_eulerian = gaseste_ciclu_eulerian(1, lista_vecini);

    for (int i = 0; i < ciclu_eulerian.size() - 1; i++) {
        fout << ciclu_eulerian[i] << " ";
    }

    return 0;
}

