#include <bits/stdc++.h>

using namespace std;
const int N = 5e5 + 5;
struct edge { int u, v; } e[N];
int adj(int u, int id) { return e[id].u ^ e[id].v ^ u; }
bool vis[N];
int st[N], grad[N];
vector <int> g[N];
vector <int> tour;
void dfs(int u) {
    tour.push_back(u);
    while(!g[u].empty() && vis[g[u].back()]) g[u].pop_back();
    if(g[u].empty()) return;
    int id = g[u].back();
    int v = adj(u, id);
    vis[id] = true;
    return dfs(v);
}

int main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    int n, m;
    cin >> n >> m;
    for(int i = 0, u, v; i < m; i++) {
        cin >> u >> v;
        e[i] = {u, v};
        g[u].push_back(i);
        g[v].push_back(i);
        grad[u]++; grad[v]++;
    }
    for(int i = 1; i <= n; i++)
        if(grad[i] % 2 == 1) {
            cout << "-1";
            return 0;
        }
    dfs(1);
    if(tour.size() != m + 1 || tour[0] != tour[m])
        cout << "-1";
    else {
        reverse(tour.begin(), tour.end());
        tour.pop_back();
        for(int x : tour)
            cout << x << " ";
    }
    return 0;
}
