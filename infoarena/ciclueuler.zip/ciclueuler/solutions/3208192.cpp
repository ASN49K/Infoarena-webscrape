#include <bits/stdc++.h>
#define DIM 100001

using namespace std;

ifstream fin("ciclueuler.in");

ofstream fout("ciclueuler.out");

struct elem{

    int x, ok;

};

stack <int> stk;

vector < elem > G[DIM];

int n, m, x, y, idx;

void Euler(int node){

    for(int i=0;i<G[node].size();i++){

        int next = G[node][i].x;

        int ok = G[node][i].ok;

        if(!ok)

            continue;

        G[node][i].ok = 0;

        for(int j=0;j<G[next].size();j++)

            if(G[next][j].x == node && G[next][j].ok){

                G[next][j].ok = 0;

                break;

            }

        Euler(next);

    }

    stk.push(node);

}

int main(){

    fin >> n >> m;

    while(m--){

        fin >> x >> y;

        G[x].push_back({y, 1});

        G[y].push_back({x, 1});

    }

    Euler(1);

    while(stk.size() > 1){

        fout << stk.top() << " ";

        stk.pop();

    }

}
