#include <bits/stdc++.h>

using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
int n, m, x, y;
vector<pair<int, int>> adj[100005];
bool used[500005];
vector<int> ans;
int main()
{
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y;
        adj[x].push_back({i, y});
        adj[y].push_back({i, x});
    }

    for (int i = 1; i <= n; i++)
        if (adj[i].size() % 2 == 1) {
            out << -1 << '\n';
            return 0;
        }

    stack<int> st;
    st.push(1);
    while (!st.empty()) {
        int nod = st.top();
        if (!adj[nod].empty()) {
            pair<int, int> ngh = adj[nod].back();
            adj[nod].pop_back();
            if (!used[ngh.first]) {
                used[ngh.first] = 1;
                st.push(ngh.second);
            }
        } else {
            st.pop();
            ans.push_back(nod);
        }
    }

    for (int i = 0; i < ans.size() - 1; i++)
        out << ans[i] << " ";
    return 0;
}
