#include <vector>
#include <fstream>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
void buildVisit(int node, vector<int> &visit, vector<vector<pair<int, int>>> &graph)
{
    visit[node] = 1;
    for(auto it = graph[node].begin(); it != graph[node].end(); it++)
    {
        if(visit[it->first])
            continue;
        else
            buildVisit(it->first, visit, graph);
    }
}
void buildEuler(int node, vector<int> &ce, vector<int> &ve, vector<int> &cycle, vector<vector<pair<int, int>>> &graph)
{
    while(ce[node] < graph[node].size())
    {
        if(ve[graph[node][ce[node]].second])
        {
            ce[node]++;
        }
        else
        {
            ve[graph[node][ce[node]].second] = 1;
            ce[node]++;
            buildEuler(graph[node][ce[node] - 1].first, ce, ve, cycle, graph);
        }
    }
    cycle.push_back(node);
}
int main()
{
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> graph(n+1);
    vector<int> visit(n+1, 0);
    vector<int> ce(m+1, 0);
    vector<int> ve(m+1, 0);
    vector<int> cycle;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back({y, i});
        graph[y].push_back({x, i});
    }
    for(int i = 1; i <= n; i++)
    {
        if((graph[i].size() & 1))
        {
            cout << -1;
            return 0;
        }
    }
    int cmpCnt = 0;
    for(int i = 1; i <= n; i++)
    {
        if(visit[i])
            continue;
        cmpCnt += 1;
        buildVisit(i, visit, graph);
    }
    if(cmpCnt > 1)
    {
        cout << -1;
        return 0;
    }
    buildEuler(1, ce, ve, cycle, graph);
    for(auto it = cycle.begin(); it != cycle.end() - 1; it++)
    {
        cout << (*it) << " ";
    }
}