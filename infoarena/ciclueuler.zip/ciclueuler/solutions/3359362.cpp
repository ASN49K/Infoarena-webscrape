#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
typedef pair<int,int> pii;
int n,m;
vector<pii> muchii[100005];
vector<int> sol;
int viz[500005];
bool use[100005];
void dfs(int nod)
{
	use[nod]=1;
	while(!muchii[nod].empty())
	{
		if(viz[muchii[nod].back().second])
		{
			muchii[nod].pop_back();
			continue;
		}
		viz[muchii[nod].back().second]=1;
		int urm = muchii[nod].back().first;
		muchii[nod].pop_back();
		dfs(urm);
	}
	sol.push_back(nod);
}
int main()
{
	fin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int a,b;
		fin>>a>>b;
		muchii[a].push_back({b,i});
		muchii[b].push_back({a,i});
	}
	for(int i=1;i<=n;i++)
		if((int)muchii[i].size() % 2 == 1)
		{
			fout<<-1;
			return 0;
		}
	dfs(1);
	for(int i=1;i<=n;i++)
		if(!use[i])
		{
			fout<<-1;
			return 0;
		}
	sol.pop_back();
	for(int i:sol)
		fout<<i<<' ';
	return 0;
}
