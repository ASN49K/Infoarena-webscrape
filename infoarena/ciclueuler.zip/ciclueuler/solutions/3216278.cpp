#include <fstream>
#include <vector>
#include <stack>
#define s second
#define f first
const int NMAX=5e5+5;

using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

vector <pair<int, int>> v[NMAX];
stack <int> s;
int n, m;
bool f[NMAX];

void dfs(int);

int main()
{
    int i, a, b;
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b;
        v[a].push_back({b, i});
        v[b].push_back({a, i});
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            cout<<"-1\n";
            return 0;
        }
    }
    dfs(1);
    return 0;
}

void dfs(int nd)
{
    pair <int, int> nod;
    s.push(nd);
    while(!s.empty())
    {
        if(v[s.top()].size())
        {
            nod=v[s.top()].back(); v[s.top()].pop_back();
            if(!f[nod.s])
            {
                f[nod.s]=true;
                s.push(nod.f);
            }
        }
        else
        {
            if(s.size()>1) cout<<s.top()<<' ';
            s.pop();
        }
    }
}
