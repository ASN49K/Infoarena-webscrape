#include <stdio.h>
#include <stdbool.h>

#define N 100000
#define M 500000
#define NIL (-1)

struct aux_muchie {
    int x, y;
};

typedef struct aux_muchie muchie;

struct aux_lst_inl {
    int poz_m, poz_urm;
};

typedef struct aux_lst_inl lst_inl;

lst_inl v_lst[2*M];
int poz_ini_lst[N+1], grad[N+1], n, m, n_lst;
bool mfol[M];
muchie vm[M];
int ciclu_e[M+1], n_c_e;

bool toate_gradele_pare() {
    for (int i = 1; i <= n; i++) {
        if (grad[i] % 2 != 0) {
            return false;
        }
    }
    return true;
}

int primul_varf_neizolat() {
    for (int i = 1; i <= n; i++) {
        if (grad[i] != 0) {
            return i;
        }
    }
    return 0;
}

int celalalt_varf(int x, muchie e) {
    return (e.x + e.y - x);
}

void euler(int x) {
    while (poz_ini_lst[x] != NIL) {
        int p = v_lst[poz_ini_lst[x]].poz_m;
        poz_ini_lst[x] = v_lst[poz_ini_lst[x]].poz_urm;
        if (!mfol[p]) {
            mfol[p] = true;
            int y = celalalt_varf(x, vm[p]);
            euler(y);
        }
    }
    ciclu_e[n_c_e++] = x;
}

void init_liste() {
    for (int i = 1; i <= n; i++) {
        poz_ini_lst[i] = NIL;
    }
}

void adauga_lst(int x, int p) {
    v_lst[n_lst].poz_m = p;
    v_lst[n_lst].poz_urm = poz_ini_lst[x];
    poz_ini_lst[x] = n_lst++;
    grad[x]++;
}

int main() {
    FILE *in = fopen("ciclueuler.in", "r");
    FILE *out = fopen("ciclueuler.out", "w");
    fscanf(in, "%d%d", &n, &m);
    init_liste();
    for  (int i = 0; i < m; i++) {
        fscanf(in, "%d%d", &vm[i].x, &vm[i].y);
        adauga_lst(vm[i].x, i);
        adauga_lst(vm[i].y,i);
    }
    fclose(in);
    bool exista = false;
    if (toate_gradele_pare()) {
        int x_0 = primul_varf_neizolat();
        if (x_0 != 0) {
            euler(x_0);
            if (n_c_e == m + 1) {
                for (int i = 0; i < n_c_e - 1; i++) {
                    fprintf(out, "%d ", ciclu_e[i]);
                }
                fprintf(out, "\n");
                exista = true;
            }
        }
    }
    if (!exista) {
        fprintf(out, "-1\n");
    }
    fclose(out);
    return 0;
}
