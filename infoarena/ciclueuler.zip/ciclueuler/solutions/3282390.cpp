#include <fstream>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
#include <cassert>
#include <set>
#include <unordered_map>
#include <stack>
#define ll long long

using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

const int NMAX = 1e5;
const int MMAX = 5e5;

int n, m, ind;
vector<pair<int, int>> g[NMAX + 1];
int euler_cycle[MMAX + 1];
bool visited[MMAX + 1];

void DFS(int node) {
    while(!g[node].empty()) {
        auto [next_node, edge_id] = g[node].back();
        g[node].pop_back();
        if(!visited[edge_id]) {
            visited[edge_id] = 1;
            DFS(next_node);
        }
    }
    euler_cycle[++ind] = node;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int a, b;
        cin >> a >> b;
        g[a].emplace_back(b, i);
        g[b].emplace_back(a, i);
    }

    for(int i = 1; i <= n; i++) {
        if(g[i].size() % 2 == 1) {
            cout << -1;
            return 0;
        }
    }

    DFS(1);
    if(ind != m + 1) {
        cout << -1;
        return 0;
    }

    for(int i = 1; i <= ind - 1; i++) {
        cout << euler_cycle[i] << ' ';
    }

    return 0;
}
