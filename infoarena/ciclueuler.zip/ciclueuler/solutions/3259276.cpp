#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

const int MAX = 100005;
//vector<vector<int>> graf;
struct edge{
    int a,b;
};
vector<int> g[MAX+1], res[MAX+1];
edge vec[MAX+1];
bool deleted[MAX+1];
int cnt;

int getnextedge(int node)
{
    while( g[node].size() && deleted[g[node].back()] )
    {
        g[node].pop_back();
    }
    int edge_id = g[node].empty();
    if( edge_id )
        return -1;
    deleted[g[node].back()] = true;
    return vec[edge_id].a+vec[edge_id].b-node;
}

void euler(int node)
{
    while(int val=getnextedge(node))
    {
        euler(val);
    }
    res.push_back(node);
    ++cnt;
    res[cnt]=node;
}
int main()
{
    int n,m;
    cin>>n>>m;
    vis.resize(n+1);
    graf.resize(n+1);
    for(int i=0; i<m; ++i)
    {
        int x,y;
        cin>>x>>y;
        v[x].push_back(i);
        v[y].push_back(i);
       // graf[x].push_back(y);
       // graf[y].push_back(x);
    }
    euler(1);
   // for(int i=0; i<v.size(); ++i)
     //   cout<<v[i]<<" ";
    return 0;
}
