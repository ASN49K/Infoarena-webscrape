#include <stdio.h>
#include <vector>

FILE* fin;
FILE* fout;

const int MAX_N = 100'000;
const int MAX_M = 500'000;

struct Edge {
  int u, v;
};

int m;
int cnt;
int deg[MAX_N];
Edge edges[MAX_M];
bool active[MAX_M];
std::vector<int> adj[MAX_N];

void dfs(int u) {
  while(!adj[u].empty()) {
    int id = adj[u].back();
    adj[u].pop_back();
    if(active[id]) {
      active[id] = false;
      int v = (edges[id].u == u) ? edges[id].v : edges[id].u;
      dfs(v);
    }
  }
  if(cnt < m) {
    fprintf(fout, "%d ", u + 1);
    cnt++;
  }
}

int main() {
  fin = fopen("ciclueuler.in", "r");
  fout = fopen("ciclueuler.out", "w");

  int n;
  fscanf(fin, "%d%d", &n, &m);

  for(int i = 0; i < m; i++) {
    int u, v;
    fscanf(fin, "%d%d", &u, &v);
    u--;
    v--;
    deg[u]++;
    deg[v]++;
    edges[i] = {u, v};
    active[i] = true;
    adj[u].push_back(i);
    adj[v].push_back(i);
  }

  for(int i = 0; i < n; i++) {
    if(deg[i] % 2 > 0) {
      fprintf(fout, "-1\n");
      return 0;
    }
  }

  cnt = 0;
  dfs(0);
  fputc('\n', fout);

  fclose(fin);
  fclose(fout);

  return 0;
}
