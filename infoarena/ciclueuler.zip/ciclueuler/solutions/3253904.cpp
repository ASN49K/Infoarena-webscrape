#include<fstream>
#include<vector>
#include<algorithm>
#include<stack>
using namespace std;
vector <int> lista[100005];
stack <int> st;
  ifstream cin ("ciclueuler.in");
  ofstream cout("ciclueuler.out");
void euler(int nod)
{
  int fiu;
  while(lista[nod].size()!=0)
  {
    st.push(nod);
    fiu=lista[nod].back();
    lista[nod].pop_back();
    vector<int>::iterator it;
    it=find(lista[fiu].begin(),lista[fiu].end(),nod);
    lista[fiu].erase(it);
    nod=fiu;
  }
}

int main()
{
  int nod, n1, n2, n, m, ok=1, k;
    cin>>n>>m;
  for(int i=1;i<=m;i++)
  {
    cin>>n1>>n2;
    lista[n1].push_back(n2);
    lista[n2].push_back(n1);
  }
  for(int i=1;i<=n&&ok==1;i++)
    if(lista[i].size()%2==1)
      ok=0;

  if(ok==0)
    cout<<"-1";
  else
  {
    nod=1;
    int pp=1;
    while(!st.empty()||pp==1)
    {
      pp=0;
      cout<<nod<<" ";
      euler(nod);
      nod=st.top();
      st.pop();
    }
  }
  return 0;
}
