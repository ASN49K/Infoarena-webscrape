#include <iostream>
#include <vector>

using namespace std;

const int nmax = 100005;
const int mmax = 5000005;
vector<int>rez;
bool frecventa[mmax];//tinem evidenta pentru muchiile vizitate sau nu 
int last_edge[nmax];//ultima muchie vizitata pentru a nu lua aceeasi muchie de 100 de ori 

struct Edge{
    int node;
    int indx;
};
vector<Edge>adj[nmax];
void euler(int startNode){
    while (last_edge[startNode]<adj[startNode].size()){
            Edge e = adj[startNode][last_edge[startNode]];
            last_edge[startNode]++;
            if(frecventa[e.indx]){
                continue;
            }
            frecventa[e.indx] = true;
            euler(e.node);

    }
    rez.push_back(startNode);
}

int main(){
    int n,m,i,j,u,v;
    cin>>n>>m;
    vector<int>degree(n+1,0);
    for (i = 0; i<m; i++){
        cin>>u>>v;
        adj[u].push_back({v,i});
        adj[v].push_back({u,i});
        degree[u]++;
        degree[v]++;
    }
    for (i = 1; i<=n; i++)
        if (degree[i]%2!=0)
        {cout<<-1;
        return 0;}

    euler(1);

    if (rez.size()!=m+1){
        cout<<-1;
    }else{
        for (i=0; i<m; i++)
        cout<<rez[i]<<" ";
    }
    return 0;

}