#include <fstream>
#include <vector>
#include <stack>
#define mmax 500001
#define nmax 100001
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,x,y,start;
bool fr[mmax];
vector<pair<int,int>>v[nmax];
vector<int>sol;
void ciclu(int nod){
    while(!v[nod].empty()){
        int k=v[nod].back().first,m=v[nod].back().second;
        v[nod].pop_back();
        if(!fr[m]){
            fr[m]=1;
            ciclu(k);
        }
    }
    sol.push_back(nod);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(v[i].size()%2!=0){
            cout<<-1;
            return 0;
        }
    for(int i=1;i<=n;i++)
        if(v[i].size()!=0){
            ciclu(i);
            break;
        }
    if(sol.size()!=m+1){
        cout<<-1;
        return 0;
    }
    sol.pop_back();
    for(auto i:sol)
        cout<<i<<" ";
    return 0;
}
