#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int Nmax=1e5+5;
bitset<Nmax> viz;
bitset<5*Nmax> muchi;
vector<pair<int,int>> v[Nmax];
void conex(int nod)
{
    for(pair<int,int> u:v[nod])
    {
        if(!viz[u.first])
        {
            viz[u.first]=1;
            conex(u.first);
        }
    }
}
vector<int> ciclu;
void hierholzer(int nod)
{
    while(!v[nod].empty())
    {
        if(muchi[v[nod].back().second])
        {
            v[nod].pop_back();
            continue;
        }
        int next=v[nod].back().first;
        muchi[v[nod].back().second]=1;
        v[nod].pop_back();
        hierholzer(next);
        ciclu.push_back(nod);
    }
    ///ciclu.push_back(nod);
}
int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    bool ok=1;
    conex(1);
    for(int i=1;i<=n;i++)
    {
        if(!viz[i] || int(v[i].size())%2!=0) ok=0;
    }
    if(!ok)
    {
        fout<<-1<<'\n';
        return 0;
    }
    stack<int> st;
    st.push(1);
    hierholzer(1);
    for(int u:ciclu) fout<<u<<' ';
    return 0;
    while(!st.empty())
    {
        int nod=st.top();
        while(!v[nod].empty() && muchi[v[nod].back().second]) v[nod].pop_back();
        if(v[nod].empty())
        {
            if(!st.empty()) ciclu.push_back(st.top());
            st.pop();
        }
        else
        {
            int u=v[nod].back().first;
            muchi[v[nod].back().second]=1;
            st.push(u);
        }
    }
    for(int u:ciclu) fout<<u<<' ';
    return 0;
}
