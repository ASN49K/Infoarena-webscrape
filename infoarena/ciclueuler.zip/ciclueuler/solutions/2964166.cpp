#include <fstream>
#include <vector>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct muchie{
    int nd, mc;
};

vector <muchie> l[100001];
int grad[100001], st[500001], poz[100001], sol[500001], viz[500001];

int main()
{
    int n, m, i, nod, x, y;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        l[x].push_back({y, i});
        l[y].push_back({x, i});
        grad[x]++;
        grad[y]++;
    }
    int top=1, nr=0;
    st[top]=1;
    for(i=1;i<=n;i++)
    {
        if(grad[i]%2==1)
        {
            fout<<-1;
            return 0;
        }
    }
    while(top)
    {
        nod=st[top];
        if(grad[nod]==0)
        {
            nr++;
            sol[nr]=nod;
            top--;
        }
        else
        {
            for(i=poz[nod];i<l[nod].size();i++)
            {
                if(viz[l[nod][i].mc]==0)
                {
                    top++;
                    st[top]=l[nod][i].nd;
                    grad[nod]--;
                    grad[l[nod][i].nd]--;
                    viz[l[nod][i].mc]=1;
                    poz[nod]=i;
                    break;
                }
            }
        }
    }
    if(nr-1!=m)
    {
        fout<<-1;
        return 0;
    }
    else
    {
        for(i=nr;i>=2;i--)
        {
            fout<<sol[i]<<" ";
        }
    }
    return 0;
}
