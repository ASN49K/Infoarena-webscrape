#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

const int kN = 1e5 + 5;

vector<pair<int, int>>g[kN];
int n, m, v[5 * kN];
bool used[5 * kN];

void dfs (int nod){
   while (!g[nod].empty()){
      auto k = g[nod].back();
      g[nod].pop_back();
      if (!used[k.second]){
         used[k.second] = true;
         dfs(k.first);
      }
   }
   v[++v[0]] = nod;
}

int main(){
   ios_base::sync_with_stdio(false);

   fin >> n >> m;
   for (int i = 1; i <= m; i++){
      int x, y; fin >> x >> y;
      g[x].push_back(make_pair(y, i));
      g[y].push_back(make_pair(x, i));
   }
   for (int i = 1; i <= n; i++){
      if ((int)g[i].size() % 2 == 1){
         fout << -1;
         return 0;
      }
   }
   dfs(1);
   --v[0];
   for (int i = 1; i <= v[0]; i++){
      fout << v[i] << " ";
   }
}
