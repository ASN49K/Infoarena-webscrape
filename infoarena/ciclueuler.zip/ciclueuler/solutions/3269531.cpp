#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m, x[500001], y[500001];

bitset <500001> viz;

vector <int> ans, a[100001], q;

inline void euler(int nod)
{
    q.push_back(nod);

    while (!q.empty()) {
        nod = q.back();

        if (!a[nod].empty()) {
            int nodd = a[nod].back();

            a[nod].pop_back();

            if (!viz[nodd]) {
                viz[nodd] = 1;
                q.push_back(x[nodd] + y[nodd] - nod);
            }
        }
        else {
            ans.push_back(nod);
            q.pop_back();
        }
    }
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= m; ++i) {
        f >> x[i] >> y[i];

        a[x[i]].push_back(i);
        a[y[i]].push_back(i);
    }

    for (int i = 1; i <= n; ++i) {
        if (a[i].size() & 1) {
            g << -1;
            return 0;
        }
    }

    euler(1);

    for (int i = 0; i < (int) ans.size() - 1; ++i) {
        g << ans[i] << ' ';
    }

    return 0;
}
