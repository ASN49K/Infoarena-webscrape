//clueless individual
#include <fstream>
#include <algorithm>
#include <stack>
#include <vector>
#define ll long long
using namespace std;

const int MMAX = 5e5;
const int NMAX = 1e5;

bool viz[MMAX + 1];
bool vv[NMAX + 1];

vector <pair <int, int> > g[NMAX + 1];

int cnt;

void dfs(int nod)
{
    cnt++;
    vv[nod] = 1;
    for (pair <int, int> x : g[nod])
        if (!vv[x.first])
            dfs(x.first);
}

vector <int> sol;

void euler(int nod)
{
    for (pair <int, int> x : g[nod])
        if (!viz[x.second])
        {
            viz[x.second] = 1;
            euler(x.first);
        }
    sol.push_back(nod);
}


stack <int> st;

signed main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    int i, n, m;
    cin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        g[a].push_back({b, i});
        g[b].push_back({a, i});
    }
    bool ok = 1;
    for (i = 1; ok and i <= n; i++)
        if (g[i].size() % 2 == 1)
        {
            ok = 0;
        }
    dfs(1);

    if (cnt != n or !ok)
    {
        cout << -1;
    }
    else
    {
        st.push(1);
        while (!st.empty())
        {
            int f = st.top();
            if (!g[f].empty())
            {
                bool ok = 0;
                while (!g[f].empty() and !ok)
                {
                    pair <int, int> x = g[f].back();
                    if (!viz[x.second])
                    {
                        viz[x.second] = 1;
                        st.push(x.first);
                        ok = 1;
                    }
                    g[f].pop_back();
                }
            }
            else
            {
                sol.push_back(st.top());
                st.pop();
            }
        }
        reverse(sol.begin(), sol.end());
        sol.pop_back();
        for (int x : sol)
            cout << x << " ";
    }
}
