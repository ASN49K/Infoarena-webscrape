#include <fstream>
#include <iostream>
#include <climits>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");


struct edge{
    int x, y, i;
};

int n, m, x, y;
vector<edge> ad[500005];
int explored[500005];
vector<int> ciclu;

void euler(int node) {
    while(ad[node].size()) {
        edge vec = ad[node].back(); // un vecin
        ad[node].pop_back(); // sterge muchia (node, vec)

        if(explored[vec.i] == 0) {
            explored[vec.i] = 1;
            euler(vec.y);
        }
    }
    ciclu.push_back(node);
}


int main() {
    fin >> n >> m;
    for(int i = 1; i <= m; i ++) {
        fin >> x >> y;
        ad[x].push_back({x, y, i});
        ad[y].push_back({y, x, i});
    }
    for(int i = 1; i <= n; i++) 
        if(ad[i].size() % 2 == 1)
        {
            fout << -1 <<'\n';
            return 0;
        }

    euler(1);
    ciclu.pop_back();
    for(auto i : ciclu)
        fout << i << " ";
    return 0;
}