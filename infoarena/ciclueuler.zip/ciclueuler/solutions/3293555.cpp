#include<bits/stdc++.h>
using namespace std;
ifstream in("stramosi.in");
ofstream out("stramosi.out");
int a[20][250001],n,q,p[300000],x,y;
int main()
{
    p[1]=0;
for(int i=2;i<300000;i++)p[i]=p[i/2]+1;
in>>n>>q;
for(int i=1;i<=n;i++)
in>>a[0][i];
for(int i=1;i<=19;i++)
for(int j=1;j<=n;j++)
a[i][j]=a[i-1][a[i-1][j]];


for(int i=0;i<q;i++)
{in>>x>>y;

   while(y)
   {//out<<p[y]<<" ";
       x=a[p[y]][x];
   y=y-(1<<p[y]);
  
       }
      
       out<<x<<'\n';
       
    
}
}