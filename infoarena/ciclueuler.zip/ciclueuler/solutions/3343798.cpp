#include <fstream>
#include <vector>
#define x first
#define id second
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,x,y;
bool viz[5*nmax];
vector<pair<int,int>>v[nmax];
vector<int>sol;
void dfs(int nod,int mch){
    viz[mch]=1;
    while(!v[nod].empty()){
        int x=v[nod].back().x,id=v[nod].back().id;
        v[nod].pop_back();
        if(viz[id])
            continue;
        viz[id]=1;
        dfs(x,id);
    }
    sol.push_back(nod);
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(v[i].size()%2!=0){
            cout<<-1;
            return 0;
        }
    for(int i=1;i<=n;i++)
        if(v[i].size()!=0)
            dfs(i,0);
    sol.pop_back();
    if(sol.size()!=m){
        cout<<-1;
        return 0;
    }
    for(auto i:sol)
        cout<<i<<" ";
    return 0;
}
