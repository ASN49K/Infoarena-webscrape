#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m, X[500001], Y[500001], e[500001], len, viz[500001];
vector <int> L[100001];

void Euler(int k)
{
    for (int i : L[k])
        if (viz[i] == 0)
    {
        viz[i] = 1;
        Euler(X[i] + Y[i] - k);
    }
    e[++len] = k;
}

int main()
{
    int i, x, y;
    fin >> n >> m;
    for (i = 1 ; i <= m ; i++)
    {
        fin >> x >> y;
        X[i] = x; Y[i] = y;
        L[x].push_back(i);
        L[y].push_back(i);
    }
    Euler(1);
    for (i = 1 ; i < len ; i++)
        fout << e[i] << " ";
    return 0;
}
