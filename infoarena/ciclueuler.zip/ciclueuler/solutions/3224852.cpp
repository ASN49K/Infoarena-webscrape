#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
int n, m;
vector<int> v[100005];
vector<int> ans;

int find(int x, int y)
{
    for(int i = 0; i<v[x].size(); i++)
    {
        if(v[x][i] == y)
        {
            return i;
        }
    }
}

int main()
{
    in>>n>>m;

    int x, y;
    for(int i = 1; i<=m; i++)
    {
        in>>x>>y;

        v[x].push_back(y);
        v[y].push_back(x);
    }

    for(int i = 1; i<=n; i++)
    {
        if(v[i].size() % 2 == 1)
        {
            out<<-1;
            return 0;
        }
    }

    stack<int> s;
    int nd, nxt;

    s.push(1);

    while(!s.empty())
    {
        nd = s.top();

        if(!v[nd].empty())
        {
            nxt = *v[nd].begin();

            s.push(nxt);

            v[nd].erase(v[nd].begin() + find(nd, nxt));
            v[nxt].erase(v[nxt].begin() + find(nxt, nd));

            continue;
        }

        ans.push_back(nd);
        s.pop();
    }

    for(int i = 0; i<ans.size() - 1; i++)
    {
        out<<ans[i]<<" ";
    }

    return 0;
}
