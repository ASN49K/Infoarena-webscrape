#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
struct muchie {
    int x, y, idx;
};
int n, m, x, y, i;
vector<muchie> a[100002];
bitset<500002> fr;
stack<int> r;

static inline void euler(int nod) {
    for(auto it : a[nod]) {
        if(!fr[it.idx]) {
            fr[it.idx] = true;
            euler(it.y);
        }
    }
    r.push(nod);
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        fin >> x >> y;
        a[x].push_back({x, y, i});
        a[y].push_back({y, x, i});
    }
    euler(1);
    while(r.size() > 1) {
        fout << r.top() << " ";
        r.pop();
    }

    return 0;
}
