#include <fstream>
#include <vector>
#define NMAX 100001
#define MMAX 500001
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n;
bool sters[MMAX];
struct muchie {int x, nr;};
vector<muchie> G[NMAX];
vector<int> C;

void euler(int x)
{muchie m;
 while (!G[x].empty())
       {
        m=G[x].back();
        G[x].pop_back();
        if (!sters[m.nr])
            {
            sters[m.nr]=1;
            euler(m.x);
            }
       }
 C.push_back(x);
}
int main()
{int i, nrmuchii, x, y;
 muchie m;
 fin>>n>>nrmuchii;
 for (i=1; i<=nrmuchii; i++)
      {
        fin>>x>>y;
        m.x=y; m.nr=i;
        G[x].push_back(m);
        m.x=x;
        G[y].push_back(m);
       }
 for (x=1; x<=n; x++)
     if (G[x].size()%2)
         {
           fout<<-1<<'\n';
           return 0;
         }
 for (x=1; x<=n; x++)
        if (G[x].size())
            {
             euler(x);
             break;
            }
 if (C.size()!=nrmuchii+1)
    {
        fout<<-1<<'\n';
        return 0;
    }

 for (i=0; i<C.size()-1; i++)
      fout<<C[i]<<' ';
 fout<<'\n';
 return 0;
}
