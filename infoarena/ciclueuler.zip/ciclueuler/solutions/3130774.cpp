
#include <fstream>
#define NMAX 100020

using namespace std;

ifstream cin ("bile.in");
ofstream cout ("bile.out");

int TT[NMAX], RG[NMAX];
int n, m;

struct
{
    int lin,col;
} v[250*250+1];

int mat[251][251];
int sol[250*250+1];


int lindir[]= {1,-1,0,0};
int coldir[]= {0,0,1,-1};

int viz[250*250+1];

int find(int x)
{
    int R, y,cnt=0;
    //merg in sus pe arbore pana gasesc un nod care pointeaza catre el insusi
    for (R = x; TT[R] != R; R = TT[R]);
    //aplic compresia drumurilor
    while(TT[x] != x)
    {
        y = TT[x];
        TT[x] = R;
        x = y;
    }
    return R;
}

void unite(int x, int y)
{
    int R;
    if (RG[x] > RG[y])
    {
        TT[y] = x;
        R=x;
    }
    else
    {
        TT[x] = y;
        R=y;
    }
    if (RG[x] == RG[y])
    {
        R=y;
    }
    RG[R]=RG[x]+RG[y];
}

int main()
{
    cin>>n;
    for (int i = n*n; i>=1; i--)
    {
        cin>>v[i].lin>>v[i].col;
    }
    for (int i=1; i<=n*n; i++)
    {
        TT[i] = i;
        RG[i] = 1;
    }
    ///unite(find(7),find(8));
    ///cout<<max(RG[find(7)],RG[find(8)]);
    int maxi=0;
    mat[v[1].lin][v[1].col]=1;
    int cnt=0;
    for (int i = 2; i < n*n; i++)
    {

        mat[v[i].lin][v[i].col]=1;
        for(int k=0; k<4; k++)
        {
            int in=v[i].lin+lindir[k];
            int jn=v[i].col+coldir[k];
            if(mat[in][jn]!=0 && in>=1 && in<=n && jn>=1 && jn<=n)
            {
                int val1=n*(v[i].lin-1)+v[i].col;
                int val2=n*(in-1)+jn;
                ///cout<<val1<<' '<<val2<<endl;
                if(find(val1)!=find(val2))
                {
                    unite(find(val1),find(val2));
                    ///cout<<max(RG[find(val1)],RG[find(val2)])<<endl;
                }
                if(maxi<max(RG[find(val1)],RG[find(val2)]))
                        maxi=max(RG[find(val1)],RG[find(val2)]);
            }
            if(maxi<1)
                maxi=1;
        }
        sol[++cnt]=maxi;
    }
    for(int i=cnt;i>=1;i--)
        cout<<sol[i]<<'\n';
    cout<<1<<'\n'<<0;
    return 0;
}
