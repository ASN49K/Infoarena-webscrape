#include <fstream>
#include <bitset>
#include <vector>
#include <stack>

using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

const int NMAX = 1e5;
const int MMAX = 5e5;

struct muchie{
    int x, y;
};

muchie e[MMAX + 1];
bitset <MMAX + 1> sters;
vector <int> v[NMAX + 1];
vector <int> ciclu;
int ultim[NMAX + 1];
stack <int> stiva;

int celalalt(muchie m, int x){
    return (m.x + m.y - x);
}

void euler(){

    while(!stiva.empty()){

        int x = stiva.top();
        int ind = -1;

        while(ultim[x] < v[x].size() && ind == -1){

            if(sters[v[x][ultim[x]]] == 0)
                ind = v[x][ultim[x]];

            ultim[x]++;

        }

        if(ind != -1){

            int y = celalalt(e[ind], x);
            sters[ind] = 1;
            stiva.push(y);

        }else
            ciclu.push_back(x), stiva.pop();

    }

}

int main(){

    int n = 0, m = 0;
    cin >> n >> m;

    for(int i = 0; i < m; i++){

        cin >> e[i].x >> e[i].y;

        v[e[i].x].push_back(i);
        v[e[i].y].push_back(i);

    }

    stiva.push(e[0].x);
    euler();

    if(ciclu.size() != m + 1){

        cout << -1;
        return 0;

    }

    for(int i = 0; i < ciclu.size() - 1; i++)
        cout << ciclu[i] << " ";

    return 0;
}
