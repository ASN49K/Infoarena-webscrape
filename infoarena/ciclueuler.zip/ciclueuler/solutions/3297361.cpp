#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;
const int MMAX = 5e5;

vector <pair<int, int>> edges[NMAX + 1];
int viz[MMAX + 1];

vector <int> order;

void dfs( int node ) {
    cout << node << endl;
    while ( !edges[node].empty() ) {
        auto e = edges[node].back();
        edges[node].pop_back();
        if ( !viz[e.second] ) {
            viz[e.second] = true;
            dfs( e.first );
        }
    }
    order.push_back( node );
}
int main() {
    ifstream fin( "ciclueuler.in" );
    ofstream fout( "ciclueuler.out" );
    int n, m, cnt = 0;
    fin >> n >> m;
    for ( int i = 1, a, b; i <= m; i ++ ) {
        fin >> a >> b;
        edges[a].push_back( {b, i} );
        edges[b].push_back( {a, i} );
    }
    for ( int i = 1; i <= n; i ++ ) {
        if ( edges[i].size() % 2 == 1 ) cnt ++;
    }
    if ( cnt > 0 ) {
        fout << "-1\n";
    } else {
        dfs( 1 );
        order.pop_back();
        for ( auto x : order ) fout << x << ' ';
        fout << '\n';
    }
    return 0;
}