#include <algorithm>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 100005, MMAX = 500005;
vector<int> g[NMAX], ans;
bool used[MMAX];
int from[MMAX], to[MMAX], n, m;
stack<int> s;

int main() {
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        fin >> from[i] >> to[i];
        g[from[i]].push_back(i), g[to[i]].push_back(i);
    }

    for(int i = 1; i <= n; i++)
        if(g[i].size() % 2 == 1){
            fout << -1;
            return 0;
        }

    s.push(1);
    while (!s.empty())
    {
        int k = s.top();
        if(!g[k].empty()){
            int e = g[k].back();
            g[k].pop_back();
            if(!used[e]){
                used[e] = 1;
                int To = from[e] ^ to[e] ^ k;
                s.push(To);
            }
        }
        else s.pop(), ans.push_back(k);
    }
    ans.pop_back();
    for(int i : ans) fout << i << ' ';
}