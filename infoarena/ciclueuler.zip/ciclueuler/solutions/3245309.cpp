#include <bits/stdc++.h>
#define NMAX 100004
#define MMAX 500004
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
//ifstream f("euler.in");
//ofstream g("euler.out");
int n,m,i,n1,n2;
vector<pair<int,int>>ADJ[NMAX];
vector<int>ans;
bool used [MMAX];
void dfs (int node){
    while(!ADJ[node].empty()){
        pair<int,int> aux=ADJ[node].back();
        ADJ[node].pop_back();
        if (used[aux.second]==false){
            used[aux.second]=true;
            dfs(aux.first);


        }
    }
    ans.push_back(node);
}
int main()
{   f>>n>>m;
    for (i=1;i<=m;i++){
        f>>n1>>n2;
        ADJ[n1].push_back({n2,i});
        ADJ[n2].push_back({n1,i});//cout<<1;

    }
        dfs(1);

    for (i=1;i<=n;i++){
        if (ADJ[i].size()%2!=0){
            g<<-1<<'\n';
            return 0;
        }
    }
    for (i=1;i<=n;i++)if (used[i]==false){
            g<<-1;
            return 0;
        }
    ans.pop_back();
    for (auto &it:ans)g<<it<<' ';
    g<<'\n';
    return 0;

}
