#include <bits/stdc++.h>

using namespace std;

vector<size_t> euler(vector<vector<size_t>>& G) {
  vector<size_t> cycle;
  stack<size_t> depth;
  depth.push(0);
  for (; depth.size();) {
    size_t const u = depth.top();
    for (; G[u].size();) {
      size_t const v = G[u].back();
      G[u].pop_back();
      if (u != v) {
        if (auto i = find(G[v].begin(), G[v].end(), u); i != G[v].end()) {
          G[v].erase(i);
        }
      }
      depth.push(v);
    }
    cycle.push_back(u);
    depth.pop();
  }
  reverse(cycle.begin(), cycle.end());
  return cycle;
}

int main() {
#ifndef LOCAL
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
  freopen("ciclueuler.in", "r", stdin);
  freopen("ciclueuler.out", "w", stdout);
#endif
  size_t N;
  size_t M;
  cin >> N >> M;
  vector<vector<size_t>> G(N);
  for (size_t i = 0; i < M; ++i) {
    size_t u;
    size_t v;
    cin >> u >> v;
    --u;
    --v;
    G[u].push_back(v);
    G[v].push_back(u);
  }
  if (auto const cycle = euler(G); cycle.size() != M) {
    cout << "-1";
  } else {
    for (size_t i = 0; i < cycle.size(); ++i) {
      if (i > 0) {
        cout << " ";
      }
      cout << (cycle[i] + 1);
    }
  }
  cout << "\n";
  return 0;
}