#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n,m,x,y;
vector<vector<pair<int,int>>> adj;
vector<int> grade;
vector<int> isUsed;
vector<int> rez;

int main(){
    f >> n >> m;
    adj.resize(n+1, vector<pair<int,int>>());
    grade.resize(n+1, 0);
    isUsed.resize(m+1, 0);
    for(int i=1; i<=m; i++){
        f >> x >> y;
        adj[x].push_back({y,i});
        adj[y].push_back({x,i});

        grade[x]++;
        grade[y]++;
    }
    for(int i=1; i<=n; i++){
        if(grade[i] %2 == 1){
            g << -1;
            return 0;
        }
    }

    stack<int> st;
    st.push(1);
    while(!st.empty()){
        int nod = st.top();

        while(!adj[nod].empty() && isUsed[adj[nod].back().second] == 1){
            adj[nod].pop_back();
        }

        if(!adj[nod].empty()){
            auto [vecin, idxMuchie] = adj[nod].back();
            isUsed[idxMuchie] = 1;

            st.push(vecin);
            adj[nod].pop_back();
        }
        else{
            rez.push_back(nod);
            st.pop();
        }
    }
    for(int i=rez.size()-1; i>=0; i--){
        g << rez[i] << " ";
    }


    return 0;
}