#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

struct nod {
    int nod, muchie;
};
vector<nod> G[100001];
stack<int> s;
stack<nod> stiva;
int n, m, viz[500001];

int are_ciclueuler ()
{
    for (int i = 0; i < n; i++)
    {
        if (G[i].size() % 2 == 1) return 0;
    }
    return 1;
}
void euler()
{
    stiva.push({1, 0});
    while (!stiva.empty())
    {
        nod v = stiva.top();
        if (!G[v.nod].empty())
        {
            nod w = G[v.nod].back();
            G[v.nod].pop_back();

            if (!viz[w.muchie])
            {
                viz[w.muchie] = 1;
                stiva.push(w);
            }
        }
        else
        {
            stiva.pop();
            s.push(v.nod);
        }
    }
}

int main()
{
    fin >> n >> m;
    for (int i = 0; i < m ; i++)
    {
        int u, v;
        fin >> u >> v;
        G[u].push_back({v, i});
        G[v].push_back({u, i});
    }
    if (!are_ciclueuler())
    {
        fout << -1;
        return 0;
    }
    euler();
    s.pop();
    while(!s.empty())
    {
        fout << s.top() << " ";
        s.pop();
    }
    return 0;
}
