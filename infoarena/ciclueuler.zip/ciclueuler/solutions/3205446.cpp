#include <bits/stdc++.h>
using namespace std;
int n, m;
map<int, int> N[100100];
int R[100100],A[100100],rs;

void parc(int nod){
    for(auto it : N[nod]){
        if(it.second){
            int pana = it.first;
            N[nod][pana]--;
            N[pana][nod]--;
            parc(pana);
        }
    }
    R[++rs] = nod;
}

int main(){
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    cin >> n >> m;

    int d, p;
    for(int i=1; i<=m; i++){
        cin >> d >> p;
        N[d][p]++;
        N[p][d]++;
        A[d]++;
        A[p]++;
    }

    bool exista = 1;
    for(int i=1; i<=n; i++){
        if(A[i] % 2!= 0){
            exista = 0;
        }
    }

    if(exista){
        parc(1);
        rs--;
        for(int i=1; i<=rs; i++){
            cout << R[i] << ' ';
        }
    } else {
        cout << -1 << endl;
    }
}