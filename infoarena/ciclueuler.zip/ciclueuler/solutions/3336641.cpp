#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m;
vector<vector<int>> adj_list;
vector<int> in_degree, visited;
vector<int> cycle;

void read()
{
    fin >> n >> m;
    adj_list.assign(n + 1, {});
    in_degree.assign(n + 1, 0);
    visited.assign(n + 1, 0);

    for (int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        adj_list[x].push_back(y);
        adj_list[y].push_back(x);
        in_degree[x]++;
        in_degree[y]++;
    }
}

void dfs(int x)
{
    visited[x] = 1;
    for (int nxt : adj_list[x])
        if (!visited[nxt])
            dfs(nxt);
}

bool verif()
{
    // find a node with in_degree > 0
    int start = -1;
    for (int i = 1; i <= n; i++)
        if (in_degree[i] > 0)
            start = i;

    if (start == -1)
        return true;

    // check connectivity
    dfs(start);
    for (int i = 1; i <= n; i++)
        if (in_degree[i] > 0 && !visited[i])
            return false;

    for (int i = 1; i <= n; i++)
        if (in_degree[i] % 2 == 1)
            return false;

    return true;
}

void euler(int x)
{
    while (!adj_list[x].empty())
    {
        int y = adj_list[x].back();
        adj_list[x].pop_back();

        // remove edge
        auto it = find(adj_list[y].begin(), adj_list[y].end(), x);
        adj_list[y].erase(it);

        euler(y);
    }
    cycle.push_back(x);
}

int main()
{
    read();

    if (!verif())
    {
        fout << -1;
        return 0;
    }

    int start = 1;
    for (int i = 1; i <= n; i++)
        if (in_degree[i] > 0)
        {
            start = i;
            break;
        }

    euler(start);

    for (int i = 0 ; i < cycle.size()-1; i++)
        fout << cycle[i] << " ";

    return 0;
}
