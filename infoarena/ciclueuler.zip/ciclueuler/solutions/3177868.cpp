﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 205
#define MOD 666013 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int st[nmax], dr[nmax], q[nmax];
unsigned int poz[nmax];
/// poz[i] - pozitia unde am ramas in lista de adiacenta L[i]
int N, M, K;
bool viz[nmax];
vector <int> L[nmax];

inline void Citire()
{
    fin >> N >> M;
    for (int i = 1; i <= M; i++)
    {
        fin >> st[i] >> dr[i];
        L[st[i]].push_back(i);
        L[dr[i]].push_back(i);
    }
}
inline bool Toate_Pare()
{
    for (int i = 1; i <= N; i++)
        if (L[i].size() % 2 == 1) return false;
    return true;
}

inline void DFS(int nod)
{
    while (poz[nod] < L[nod].size())
    {
        int k = L[nod][poz[nod]++];
        if (!viz[k])
        {
            viz[k] = true;
            DFS(st[k] + dr[k] - nod);
        }
    }
    q[++K] = nod;
}

inline void Euler()
{
    if (!Toate_Pare()) fout << "-1\n";
    else
    {
        DFS(1);
        for (int i = 1; i < K; i++)
            fout << q[i] << " ";
        fout << "\n";
    }
}

int main()
{
    Citire();
    fin.close();
    Euler();
    fout.close();
    return 0;
}