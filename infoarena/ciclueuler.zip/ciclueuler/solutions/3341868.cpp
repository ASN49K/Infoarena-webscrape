#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX = 1e5 + 1;
int n, m, used = 0, ptr[NMAX];
bool viz[5 * NMAX];
vector<pair<int, int>> adj[NMAX];
vector<int> ciclu;

bool grad_impar()
{
    bool check = false;
    for(int node = 1; node <= n; node++)
        check |= (adj[node].size() & 1);
    return check;
}

void dfs(int node)
{
    while(ptr[node] < adj[node].size())
    {
        auto [next, id] = adj[node][ptr[node]++];
        if(viz[id])
            continue;
        viz[id] = true, used++;
        dfs(next);
    }
    ciclu.push_back(node);
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int u, v;
        fin >> u >> v;
        adj[u].emplace_back(v, i);
        adj[v].emplace_back(u, i);
    }
    if(grad_impar())
    {
        fout << -1;
        return 0;
    }
    dfs(1);
    if(used == m)
    {
        ciclu.pop_back();
        for(int node : ciclu)
            fout << node << " ";
    }
    else
        fout << -1;

    fin.close();
    fout.close();
    return 0;
}
