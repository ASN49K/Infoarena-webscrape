#include <fstream>
#include <vector>
#include <unordered_map>
#include <map>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n,m,x,y;
map<int,int> degree;
map<int,int> used;


int main(){
    f >> n >> m;
    vector<vector<pair<int,int>>> adj(n+1);
    for(int i=0; i<m; i++){
        f >> x >> y;
        degree[x]++;
        degree[y]++;

        adj[x].push_back(make_pair(y,i));
        adj[y].push_back(make_pair(x,i));
    }

    for(int i=1; i<=n; i++){
        if(degree[i] % 2 == 1){
            g << -1;
            break;
        }
    }

    stack<int> st;
    vector<int> path;
    st.push(1);

    while(!st.empty()){
        int nod = st.top();

        while(!adj[nod].empty() && used[adj[nod].back().second] == 1){
            adj[nod].pop_back();
        }

        if(!adj[nod].empty()){
            auto& [v, idxEdge] = adj[nod].back();
            used[idxEdge] = 1;

            st.push(v);
        }
        else{
            path.push_back(nod);
            st.pop();
        }
    }
    int n = path.size(),aux;
    for(int i=0; i<n/2; i++){
        aux = path[i];
        path[i] = path[n-i-1];
        path[n-i-1] = aux;
    }
    for(auto& el: path){
        g << el << " ";
    }


    return 0;
}