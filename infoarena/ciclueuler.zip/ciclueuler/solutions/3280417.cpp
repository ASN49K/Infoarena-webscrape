#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");
queue<int> q;
bool f[5000001];
struct muchie{
	int capat,nr;
};
vector<muchie>lista[100001];
int cat[5000001];
void dfs(int x)
{
	while(!lista[x].empty())
	{
		muchie y=lista[x].back();
		lista[x].pop_back();
		if(f[y.nr]==0)
		{
			f[y.nr]=1;
			dfs(y.capat);
		}
	}
	q.push(x);
}
int n,m;
int main()
{
		cin>>n>>m;
		int x,y;
		for(int i=1;i<=n;i++)
		{
				cin>>x>>y;
				muchie m1,m2;
				cat[x]++;
				cat[y]++;
				m1.capat=x;
				m2.capat=y;
				m1.nr=i;
				m2.nr=i;
				lista[x].push_back(m2);
				lista[y].push_back(m1);
		}
		int pp=1;
		for(int i=1;i<=m;i++)
			if(cat[i]%2!=0)
				pp=0;
		if(pp==0)
			cout<<"-1";
		else
		{
			dfs(1);
			while(!q.empty())
			{
				cout<<q.front()<<" ";
				q.pop();
			}
		}
    return 0;
}
