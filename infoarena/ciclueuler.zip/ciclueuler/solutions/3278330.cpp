#include <bits/stdc++.h>

// #define int long long
#define pii pair<int, int>
#define fs first
#define sd second

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m;
vector<int> g[100005], eulerpath;
bool used[500005];
pii e[500005];

void dfs(int node) {
    for(int ind = g[node].size() - 1; ind >= 0; ind--) {
        int nxt = g[node][ind];
        g[node].pop_back();
        if(used[nxt] == 0) {
            used[nxt] = 1;
            if(node == e[nxt].fs) dfs(e[nxt].sd);
            else dfs(e[nxt].fs);
        }
    }
    eulerpath.push_back(node);
}

signed main() {
    in >> n >> m;
    for(int i = 1; i <= m; i++) {
        int u, v; in >> u >> v;
        e[i] = {u, v};
    }
    sort(e + 1, e + m + 1);
    for(int i = 1; i <= m; i++) {
        if(1 || e[i].fs != e[i].sd) {
            g[e[i].fs].push_back(i);
            g[e[i].sd].push_back(i);
        }
    }
    for(int i = 1; i <= n; i++) {
        if(g[i].size() % 2 == 1) {
            out << -1 << '\n';
            return 0;
        }
    }
    dfs(1);
    for(auto elem : eulerpath) {
        out << elem << ' ';
    }
    out << '\n';
    return 0;
}
