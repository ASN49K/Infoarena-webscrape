#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <stack>
#define NMAX 100005
#define MMAX 500005

using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

struct ok
{
    int vecin, poz;
};

vector <ok> adj[NMAX];
bool viz[MMAX];
stack <int> cycle;
stack <int> finalCycle;

int main()
{
    int n, m, i, j, a, b;
    in >> n >> m;
    for (i = 1; i <= m; ++i)
    {
        in >> a >> b;
        adj[a].push_back({b, i});
        adj[b].push_back({a, i});
    }

    bool eulerian = true;
    for (i = 1; i <= n; ++i)
    {
        if (adj[i].size() % 2 == 1)
        {
            eulerian = false;
            break;
        }
    }

    if (eulerian == false)
        out << "-1";
    else
    {
        cycle.push(1);
        while (!cycle.empty())
        {
            int node = cycle.top();
            //out << node << '\n';

            if (adj[node].size())
            {
                int vecin = adj[node].back().vecin;
                int poz = adj[node].back().poz;

                adj[node].pop_back();
                if (viz[poz] == 0)
                {
                    viz[poz] = 1;
                    cycle.push(vecin);
                }
            }
            else
            {
                finalCycle.push(node);
                cycle.pop();
            }
        }

        while (finalCycle.size() > 1)
        {
            out << finalCycle.top() << " ";
            finalCycle.pop();
        }
    }
    return 0;
}
