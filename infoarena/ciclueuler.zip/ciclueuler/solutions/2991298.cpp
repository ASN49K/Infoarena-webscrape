#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
const int NMAX=100005;

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector< pair< int, int> > v[NMAX];
int ans[5*NMAX];
bool f[5*NMAX];
int n, m, cnt;

void dfs(int);

int main()
{
    int i, a, b;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back(make_pair(b, i));
        v[b].push_back(make_pair(a, i));
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            fout<<-1<<'\n';
            return 0;
        }
    }
    dfs(1);
    for(i=1; i<cnt; i++) fout<<ans[i]<<' ';
    return 0;
}

void dfs(int nod)
{
    pair <int, int> i;
    while(v[nod].size())
    {
        i=v[nod].back(); v[nod].pop_back();
        if(f[i.second]==false)
        {
            f[i.second]=true;
            dfs(i.first);
        }
    }
    ans[++cnt]=nod;
}
