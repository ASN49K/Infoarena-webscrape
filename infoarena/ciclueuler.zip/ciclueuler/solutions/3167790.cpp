#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, x, y, v[1005][1005];
stack <int> st;

void euler (int x) {
    for (int i=1; i<=n; i++) {
        if (v[x][i]) {
            v[x][i]--;
            v[i][x]--;
            euler(i);
        }
    }
    st.push(x);
}

int main() {
    fin >> n >> m;
    for (int i=1; i<=m; i++) {
        fin >> x >> y;
        v[x][y]++;
        v[y][x]++;
    }
    euler(1);
    if (st.size()==0)
        fout << -1;
    else
        while (st.size()>1) {
            fout << st.top() << " ";
            st.pop();
        }
    return 0;
}
