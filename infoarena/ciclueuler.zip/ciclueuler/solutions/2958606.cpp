#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct muchie
{
    int nod, muchie;
};

const int NMAX = 1e5+5;
int n, m, viz[5*NMAX];
vector<muchie>g[NMAX];
vector<int>ans;

inline void dfs(int start)
{
    stack<int>st;
    st.push(start);
    while(!st.empty())
    {
        int node = st.top();
        st.pop();
        if(!g[node].size())
        {
            ans.push_back(node);
        }
        else
        {
            int new_node = g[node].back().nod;
            int new_muchie = g[node].back().muchie;

            g[node].pop_back();
            st.push(node);

            if(!viz[new_muchie])
            {
                viz[new_muchie] = 1;
                st.push(new_node);
            }
        }
    }
}

inline void solve()
{
    for(int i = 1; i <= n; ++ i)
    {
        if(g[i].size()%2==1)
        {
            fout << -1;
            return;
        }
    }
    dfs(1);
    ans.pop_back();
    for(auto x : ans)
        fout << x << ' ';
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; ++ i)
    {
        int node1, node2;
        fin >> node1 >> node2;
        g[node1].push_back({node2,i});
        g[node2].push_back({node1,i});
    }
    solve();
}
