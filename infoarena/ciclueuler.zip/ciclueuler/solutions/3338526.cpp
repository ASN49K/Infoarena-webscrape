#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, x, y, k, i;
vector <pair<int, int>> v[100005];
vector <int> ans;
bool viz[500005];
void ciclu_euler()
{
    stack <int> st;
    st.push(1);
    while(!st.empty())
    {
        x=st.top();
        if(v[x].size()==0)
        {
            ans.push_back(x);
            st.pop();
        }
        else
        {
            while(v[x].size() && viz[v[x].back().second]==1)
                v[x].pop_back();
            if(v[x].size())
            {
                st.push(v[x].back().first);
                viz[v[x].back().second]=1;
                v[x].pop_back();
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back({y, i});
        v[y].push_back({x, i});
    }
    for(i=1; i<=n; i++)
        if(v[i].size()%2==1)
        {
            fout<<-1;
            return 0;
        }
    ciclu_euler();
    for(i=0; i<ans.size()-1; i++)
        fout<<ans[i]<<" ";

    return 0;
}
