#include <iostream>
#include <vector>
#include <algorithm>
#include <cassert>

using ll = long long;
#define debug(x) #x << " = " << x << '\n';

const int NMAX = 1e5;

std::vector<int> g[NMAX];
std::vector<std::pair<int, int>> e;
std::vector<int> answer;
std::vector<bool> vis;

void euler(int u) {
  while (!g[u].empty()) {
    int id = g[u].back();
    g[u].pop_back();
    if (!vis[id]) {
      vis[id] = true;
      euler(u ^ e[id].first ^ e[id].second);
    }
  }
  answer.push_back(u);
}

int main() {
  #ifdef LOCAL
    freopen("input.txt", "r", stdin);
  #else
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
  #endif
  
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(0);

  int n, m;
  std::cin >> n >> m;

  std::vector<int> deg(n, 0);
  vis.resize(m, false);

  for (int i = 0; i < m; i++) {
    int u, v;
    std::cin >> u >> v;
    u--, v--;
    g[u].push_back(i);
    g[v].push_back(i);
    e.push_back({u, v});
    deg[u]++;
    deg[v]++;
  }

  for (int i = 0; i < n; i++) {
    if (deg[i] & 1) {
      std::cout << -1;
      return 0;
    }
  }

  euler(0);
  answer.pop_back();
  if ((int) answer.size() != m) {
    std::cout << -1;
  } else {
    for (const auto &x : answer) {
      std::cout << x + 1 << ' ';
    }
  }

  return 0;
}