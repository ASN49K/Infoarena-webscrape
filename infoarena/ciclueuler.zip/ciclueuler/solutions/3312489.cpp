#include<bits/stdc++.h>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
vector<vector<pair<int,int>>>muchii(100001);
vector<bool>folosit(500001,0);
vector<int>solutie;
void dfs(int x)
{while(muchii[x].size())
{auto [fiu,index]=muchii[x].back();
if(!folosit[index])
{muchii[x].pop_back();
    continue;
}
else
{folosit[index]=1;
dfs(fiu);

}

}
    solutie.push_back(x);
}
int main()
{int n,m;
    cin>>n>>m;
for(int i=1;i<=n;i++)
{int x,y;
cin>>x>>y;
muchii[x].push_back({y,i});
muchii[y].push_back({x,i});

}
    for(int i=1;i<=m;i++)
        if(muchii[i].size()%2)
    {cout<<-1;
    return 0;

    }
    dfs(1);
    for(auto x:solutie)
        cout<<x<<" ";
}
