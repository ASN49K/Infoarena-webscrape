#include <fstream>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <cstring>
using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

int n, m;
vector<pair<int,int>> adj[100005];
bool viz[500005];
vector<int> ans;

void dfs(int nod){
    while(!adj[nod].empty()){
        int vec=adj[nod].back().first;
        int idxMuchie=adj[nod].back().second;
        adj[nod].pop_back();
        if(viz[idxMuchie]){
            continue;
        }
        viz[idxMuchie]=1;
        dfs(vec);
    }
    ans.push_back(nod);
}

int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int x, y;
        cin>>x>>y;
        adj[x].emplace_back(y, i);
        adj[y].emplace_back(x, i);
    }
    for(int i=1;i<=n;i++){
        if(adj[i].size()%2==1){
            cout<<-1;
            return 0;
        }
    }
    dfs(1);
    ans.pop_back();
    for(auto it:ans){
        cout<<it<<" ";
    }
}
