#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
struct abc
{
    int x;int y;bool f;
}v[500005];
vector<int>G[500005];
stack<int>stiva;
int n,m,grad[100001],cnt,ciclu[500001];
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        in>>x>>y;
        grad[x]++;
        grad[y]++;
        v[i].x=x;
         v[i].y=y;
         G[x].push_back(i);
          G[y].push_back(i);
    }
          for(int i=1;i<=n;i++)
            if(grad[i]%2==1)
          {
              out<<-1;
              return 0;
          }
    stiva.push(1);
    while(!stiva.empty())
    {
        int nod=stiva.top();
        int ok=0;
        while(G[nod].size())
        {
            int muchie=G[nod].back();
            G[nod].pop_back();
            if(v[muchie].f==0)
            {
                v[muchie].f=1;
                int x=v[muchie].x;
                int y=v[muchie].y;
                if(x!=nod)
                    stiva.push(x);
                else
                    stiva.push(y);
                ok=1;
                break;
            }
        }
        if(ok==0)
            ciclu[++cnt]=nod,stiva.pop();
    }
    if(cnt!=m+1)
    {
        out<<-1;
        return 0;
    }
    for(int i=1;i<cnt;i++)
      out<<ciclu[i]<< " ";
    return 0;
}
