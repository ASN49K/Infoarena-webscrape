#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>


using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

stack<int> s;
vector<int> x[100101];
int afis[500110];

bool ver(int n)
{
    for (int i = 1; i <= n; ++i)
    {
        if (x[i].size() % 2 == 1)
            return 0;
    }
    return 1;
}

int main()
{
    int n, m, z = 0, a, b, nod, nod_nou, i;
    f >> n >> m;
    for (i = 1; i <= m; ++i)
    {
        f >> a >> b;
        x[a].push_back(b);
        x[b].push_back(a);
    }
    if (ver(n) == 1)
    {
        s.push(1);
        while (!s.empty())
        {
            nod = s.top();
            if (!x[nod].empty())
            {
                nod_nou = x[nod].front();
                s.push(nod_nou);
                vector<int>::iterator it;
                it = find(x[nod].begin(), x[nod].end(), nod_nou);
                x[nod].erase(it);
                it = find(x[nod_nou].begin(), x[nod_nou].end(), nod);
                x[nod_nou].erase(it);
            }
            else
            {
                afis[++z] = s.top();
                s.pop();
            }
        }
        for (i = z; i >= 2; --i)
            g << afis[i] << " ";
    }
    else
        g << -1;
    return 0;
}
