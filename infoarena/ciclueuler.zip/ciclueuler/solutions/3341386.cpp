#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define pb push_back

const int NMAX = 1e5 + 5;
const int MMAX = 5e5 + 5;

vector <int> g[NMAX];
vector <int> sol;

int f[MMAX], s[MMAX];
bool used[MMAX];

stack <int> st;

int main() {
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    ios::sync_with_stdio(false), cin.tie(0);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        g[x].pb(i), g[y].pb(i);
        f[i] = y;
        s[i] = x;
    }
    for (int i = 1; i <= n; i++)
        if (g[i].size() % 2 != 0) {
        cout << -1;
        return 0;
    }

    st.push(1);
    while (!st.empty()) {
        int node = st.top();
        while (!g[node].empty()) {
            int aux = g[node].back();
            g[node].pop_back();
            if (!used[aux]) {
                int u = f[aux], v = s[aux];
                used[aux] = true;
                int NOD = u ^ v ^ node;
                st.push(NOD);
            }
        }
        st.pop();
        sol.pb(node);
    }
    if (sol.size() != m + 1) cout << -1;
    else for (int i = 0; i < sol.size() - 1; i++) cout << sol[i] << " ";
    return 0;
}
