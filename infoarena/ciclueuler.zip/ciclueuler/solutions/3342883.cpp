#include <fstream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,viz_noduri[100005],d[100005],viz_muchie[500005],sol[500005],k;
queue<int>q;
vector<pair<int,int>>l[100005];
void dfs(int nod)
{
    viz_noduri[nod]=1;
    for(int i=0;i<l[nod].size();i++)
    {
        int vecin=l[nod][i].first;
        if(viz_noduri[vecin]==0)
            dfs(vecin);
    }
}
void euler(int nod)
{
    while(!l[nod].empty())
    {
        int vecin=l[nod].back().first;
        int muchie=l[nod].back().second;
        l[nod].pop_back();
        if(viz_muchie[muchie]==0)
        {
            viz_muchie[muchie]=1;
            euler(vecin);
        }
    }
    sol[++k]=nod;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        l[x].push_back({y,i});
        l[y].push_back({x,i});
        d[x]++;
        d[y]++;
    }
    dfs(1);
    for(int i=1;i<=n;i++)
        if(viz_noduri[i]==0 || d[i]%2!=0)
    {
        cout<<-1;
        return 0;
    }
    euler(1);
    for(int i=1;i<=k-1;i++)
        cout<<sol[i]<<" ";
    return 0;
}
