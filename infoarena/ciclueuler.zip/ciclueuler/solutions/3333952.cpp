/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector<vector<int>> graf;
vector<pair<int, int>> dict;
vector<bool> viz; vector<int> idx;
queue<int> cycle; int k;

void eulerCycle(int vf) {
    for (int l = idx[vf]; l < graf[vf].size(); l++) {
        idx[vf]++;
        if (!viz[l]) {
            viz[l] = true;
            if (dict[l].first == vf) { eulerCycle(dict[l].second); }
            else { eulerCycle(dict[l].first); }
        }
    }
    k++;
    cycle.push(vf+1);
}

int main() {
    int n, m, l = 0; fin >> n >> m;
    graf.resize(n);
    
    for (int i = 0; i < m; i++) {
        int x, y; fin >> x >> y; x--; y--;
        graf[x].push_back(l);
        graf[y].push_back(l);
        dict.push_back({x, y}); l++; 
    }

    for (int i = 0; i < n; i++) {
        if (graf[i].size() % 2 != 0) {
            fout << -1; return 0;
        }
    }

    viz.assign(m, false); idx.assign(n, 0);
    eulerCycle(0);
    
    while (k > 1) {
        fout << cycle.front() << ' '; cycle.pop(); k--;
    }

    return 0;
}