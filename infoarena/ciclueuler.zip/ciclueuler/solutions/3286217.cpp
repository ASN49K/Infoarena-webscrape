#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("ctc.in");
ofstream cout("ciclueuler.out");

struct muchie
{
    int y,i;
};

int n,m;
queue <int>q;
vector <muchie>lista[100001];
int viz[500001],f[100001];

void dfs(int nod)
{
    while(!lista[nod].empty())
    {
        muchie aux=lista[nod].back();
        lista[nod].pop_back();
        if(viz[aux.i]==0)
            {
                viz[aux.i]=1;
                dfs(aux.y);
            }
    }
    q.push(nod);
}

int main()
{
    int x,y,ok=0;
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        f[x]++;
        f[y]++;
        lista[x].push_back({y,i});
        lista[y].push_back({x,i});
    }
    
    for(int i=1;i<=n and ok==0;i++)
        ok+=(f[i]%2);
    if(ok!=0)
        cout<<-1;
    else
    {
        dfs(1);
        while(!q.empty())
        {
            cout<<q.front()<<" ";
            q.pop();
        }
    }
    
    return 0;
}