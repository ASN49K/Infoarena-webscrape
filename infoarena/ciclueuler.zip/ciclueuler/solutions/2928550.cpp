#include <cstdio>
#include <vector>

using namespace std;
FILE *fin, *fout;

int n, m;

struct edges
{
    int start, dest;
};

const int NMAX = 100000;
const int MMAX = 500000;

vector <edges> e;
vector <int> g[MMAX + 5];

bool viz[NMAX + 5];

int findNext(int node)
{
    while(g[node].size() and viz[g[node].back()])
        g[node].pop_back();

    if(g[node].size())
    {
        int edge = g[node].back();
        viz[edge] = 1;
        g[node].pop_back();

        return e[edge].dest + e[edge].start - node;
    }

    return 0;
}

vector <int> euler;

void ciclu_euler(int node)
{
    while(int next_node = findNext(node))
        ciclu_euler(next_node);

    euler.push_back(node);
}

int main()
{
    fin = fopen("ciclueuler.in", "r");
    fout = fopen("ciclueuler.out", "w");

    fscanf(fin, "%d%d", &n, &m);

    e.resize(m + 5);

    for(int i = 1; i <= m; i++)
    {
        edges edge;

        int u, v;
        fscanf(fin, "%d%d", &u, &v);

        g[u].push_back(i);
        g[v].push_back(i);


        edge.start = u;
        edge.dest = v;

        e[i] = edge;
    }

    ciclu_euler(1);

    for(int i = 0; i < euler.size() - 1; i++)
    {
        fprintf(fout, "%d ", euler[i]);
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
