#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m;
int d[100005], st[500005], dr[500005], sol[500005], cnt;
vector<int> a[100005];
bitset<500005> viz;

void DFS(int x)
{
    while (a[x].size())
    {
        int i = a[x].back();
        a[x].pop_back();
        if (viz[i] == 0)
        {
            viz[i] = 1;
            DFS(st[i] + dr[i] - x);
        }
    }
    sol[++cnt] = x;
}

int main()
{
    int x, y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        st[i] = x;
        dr[i] = y;
        d[x]++;
        d[y]++;
        a[x].push_back(i);
        a[y].push_back(i);
    }
    for (int i = 1; i <= n; i++)
        if (d[i] % 2 == 1)
        {
            fout << "-1\n";
            fin.close();
            fout.close();
            return 0;
        }
    DFS(1);
    for(int i = 1; i <= cnt; i++)
        fout << sol[i] << " ";
    fout << "\n";
    fin.close();
    fout.close();
    return 0;
}
