#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100002
#define MMAX 500002

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct varf {int x, nr;};
//x este varful adiacent, nr este numarul muchiei corespunzatoare
int n, m;
vector<varf> G[NMAX];
bool uz[MMAX];
//uz[i]=1 daca muchia cu numarul de ordine i a fost utilizata pe ciclu
int d[NMAX];
stack<int> S;
void citire();
int grade_pare();
void euler(int start);
int main()
{int start, eulerian, i;
 citire();
 if (!(start=grade_pare()))
    fout<<-1<<'\n';
    else
    {
     euler(start);
     eulerian=1;
     for (i=1; i<=m; i++)
        if (!uz[i]) eulerian=0;
     if (!eulerian)
        {fout.close();
         fout.open("ciclueeuler.out");
         fout<<-1<<'\n';
        }
    }
 fout.close();
 return 0;
}

void citire()
{varf vf;
 int i, x, y;
 fin>>n>>m;
 for (i=1; i<=m; i++)
     {fin>>x>>y;
      //y intra in lista de adiacenta a lui x
      vf.x=y; vf.nr=i;
      G[x].push_back(vf);
      //x intra in lista de adiacenta a lui y
      vf.x=x; vf.nr=i;
      G[y].push_back(vf);
      d[x]++; d[y]++;
    }
}

int grade_pare()
//returneaza 0 daca nu toate gradele sunt pare
//daca gradele sunt toate pare returneaza indicele unui varf care nu este izolat
{int i, start;
 for (i=1; i<=n; i++)
      {if (d[i]%2) return 0;
       if (d[i]) start=i;}
 return start;
}

void euler(int start)
{varf vfad;
int vf;
 S.push(start);
 while (!S.empty())
       {
        vf=S.top();
        //aleg un varf adiacent cu vf
        if (!G[vf].empty())
           {
            vfad=G[vf][G[vf].size()-1];
            if (!uz[vfad.nr]) //muchie neutilizata
               {
                uz[vfad.nr]=1;
                S.push(vfad.x);
                }
            G[vf].pop_back();
           }
           else
           {fout<<' '<<vf; S.pop();}
       }
}
