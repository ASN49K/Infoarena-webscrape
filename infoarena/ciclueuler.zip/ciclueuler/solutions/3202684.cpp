#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <queue>
#include <stack>
#define pp pair<int, int>
#define NMax 100005
#define MMax 500005

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m;
vector<pp> v[NMax];
bitset<NMax> f;
int d[NMax];
vector<int> sol;
void read()
{
    in >> n >> m;
    int x, y;
    for (int i = 1; i <= m; i++)
    {
        in >> x >> y;
        v[x].push_back({y, i});
        v[y].push_back({x, i});
        ++d[x];
        ++d[y];
    }
}

void euler(int nr)
{
    while (!v[nr].empty())
    {
        pp x = v[nr].back();
        v[nr].pop_back();

        if (!f[x.second])
        {
            f[x.second] = 1;
            euler(x.first);
        }
    }
    sol.push_back(nr);
}

int main()
{

    read();
    for (int i = 1; i <= n; i++)
    {
        if (d[i] % 2)
        {
            out << "-1\n";
            return 0;
        }
    }

    euler(1);
    sol.pop_back();
    for (auto i : sol)
    {
        out << i << " ";
    }
}