#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int N=1e5+1,M=5e5+1;
struct elem
{
    int nod,i;
};
int n,m,i,j,x,y;
vector<elem> edge[N];
vector<int> sol;
bool f[M];
void read()
{
    fin>>n>>m;
    for(i=1;i<=m;++i)
    {
        fin>>x>>y;
        edge[x].push_back({y,i});
        edge[y].push_back({x,i});
    }
}
void eul(int x)
{
    for(auto e:edge[x])
    {
        if(f[e.i]) continue;
        f[e.i]=1;
        eul(e.nod);
    }
    sol.push_back(x);
}
void print()
{
    sol.pop_back();
    for(auto x:sol)
        fout<<x<<' ';
}
int main()
{
    read();
    for(i=1;i<=n;++i)
    {
        if(edge[i].size()%2)
        {
            fout<<-1;
            return 0;
        }
    }

    eul(1);
    print();
    return 0;
}
