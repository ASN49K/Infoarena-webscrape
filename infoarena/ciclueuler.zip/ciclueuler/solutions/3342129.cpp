#include <bits/stdc++.h>
using namespace std;

const int NMAX = 1e5;
const int MMAX = 5e5;

struct edge{
    int to,id;
};
vector<edge>v[NMAX+1];
int n,m,k;
int rang[NMAX+1];
int last_ind[NMAX+1];
bitset<MMAX+1>vap;
int ans[MMAX+1];
void read()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int st,dr;
        cin >> st >> dr;
        v[st].push_back({dr,i});
        v[dr].push_back({st,i});
        rang[st]++;
        rang[dr]++;
    }
}

void dfs(int start)
{
    stack<int>st;
    st.push(start);

    while(!st.empty())
    {
        int nod = st.top();
        int found = 0;

        while(last_ind[nod] < v[nod].size())
        {
            edge curr = v[nod][last_ind[nod]++];

            if(vap[curr.id] == 0)
            {
                vap[curr.id] = 1;
                st.push(curr.to);
                found = 1;
                break;
            }
        }
        if(found == 0)///daca n-am gasit alta muchie ma intorc
        {
            ans[++k] = nod;
            st.pop();
        }
    }
}

void solve()
{
    for(int i = 1; i <= n; i++)
        if(rang[i] % 2 == 1)
        {
            cout << -1;
            return;
        }
    dfs(1);
    if(k != m+1)
    {
        cout << -1;
        return;
    }

    for(int i = 1; i <= k; i++)
        cout << ans[i] << ' ';
}

int main()
{
    freopen("ciclueuler.in","r",stdin);
    freopen("ciclueuler.out","w",stdout);
    read();
    solve();
    return 0;
}
