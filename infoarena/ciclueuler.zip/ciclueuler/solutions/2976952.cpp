#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector <pair<int,int>> lista[100005];
int viz[500005];
int lant[550000];
int n,p,m;
struct pereche{
    int x,y,rang,vis;
};
int nr;
void citire(){
    int x,y;
    fin>>m>>n;
    for(int i=1;i<=n;i++){
        fin>>x>>y;
        lista[x].push_back({y,i});
        lista[y].push_back({x,i});
    }
}
int k;
stack<int> S;
void Euler() {
    S.push(1);
    while (!S.empty()) {
        int x=S.top();
        if (!lista[x].empty()) {
            int y=lista[x].back().first;
            int ind=lista[x].back().second;
            lista[x].pop_back();
            if (!viz[ind]) {
                viz[ind]=1;
                S.push(y);
            }
        } else {
            S.pop();
            lant[++p]=x;
        }
    }
}
int main()
{
    citire();
    Euler();
    if((p-1)%2!=0){
        fout<<-1;
        return 0;
    }
    for(int i=1;i<p;i++)
        fout<<lant[i]<<" ";
    return 0;
}
