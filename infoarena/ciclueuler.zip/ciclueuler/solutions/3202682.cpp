#include <bits/stdc++.h>
#define NMAX 100000
#define MMAX 500000
using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");
struct varf {
    int x,ind;
};
vector< vector<varf> > adj;
int n,m;
bool used[MMAX+5];
int grad[NMAX+5];
vector<int> sol;
void euler(int x) {
    while (!adj[x].empty()) {
        auto p=adj[x].back();
        adj[x].pop_back();

        if (!used[p.ind]) {
            used[p.ind]=1;
            euler(p.x);
        }
    }
    sol.push_back(x);
}
int main()
{
    fin>>n>>m;
    adj.resize(n+1);
    for (int i=1; i<=m; i++) {
        int x,y;
        fin>>x>>y;
        adj[x].push_back({y,i});
        adj[y].push_back({x,i});

        grad[x]++; grad[y]++;
    }

    for (int i=1; i<=n; i++) {
        if (grad[i]%2) {
            fout<<-1<<'\n';
            return 0;
        }
    }

    euler(1);
    sol.pop_back();

    for (auto i : sol) fout<<i<<' ';
    fout<<'\n';
    return 0;
}
