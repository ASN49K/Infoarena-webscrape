#include <bits/stdc++.h>
#define NN 100005
using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, a, b;
bool ok = false;
vector <int> v[NN], w[NN];
stack <int> s;

void euler(int nod)
{
    for(int i = 1 ; i <= n ; i++)
    {
        int aux = v[nod][i];
        if(v[nod][i] != 0)
        {
            v[nod][i]--;
            v[i][nod]--;
            euler(i);
        }
    }
    s.push(nod);
}

void resetv()
{
     for(int i = 1 ; i <= n ; i++)
    {
        v[i] = w[i];
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1 ; i <= n ; i++)
    {
        for(int j = 1 ; j <= n + 1 ; j++)
        {
            v[i].push_back(0);
            w[i].push_back(0);
        }
    }
    for(int i = 1 ; i <= m ; i++)
    {
        fin >> a >> b;
        v[a][b]++;
        v[b][a]++;
        w[a][b]++;
        w[b][a]++;
    }
    for(int i = 1 ; i <= n ; i++)
    {
        euler(1);
        int ss = s.size();
        if(ss == m + 1)
        {
            ok = true;
            break;
        }
        else
        {
            while(!s.empty())
                s.pop();
            resetv();
        }
    }
    if(!ok)
        fout << -1;
    else
    {
        while(s.size() > 1)
        {
            fout << s.top() << " ";
            s.pop();
        }
    }
    return 0;
}
