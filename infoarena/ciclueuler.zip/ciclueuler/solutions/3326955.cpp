#include <bits/stdc++.h>

using namespace std;
vector<pair<int,int>>graf[100005];
bool viz[100005];
int grad[100005];
int muchitrecute[100005];
bool muchiviz[100005];
vector<int>ans;
void build(int nod)
{
    while(muchitrecute[nod]<graf[nod].size())
    {
        pair<int,int>tmp=graf[nod][muchitrecute[nod]];
        muchitrecute[nod]++;
        if(muchiviz[tmp.second]==0)
        {
            muchiviz[tmp.second]=1;
            build(tmp.first);

        }
    }
    ans.push_back(nod);
}
void dfs(int x)
{
    viz[x]=1;
    for(auto var:graf[x])
    {
        if(viz[var.first]==0)
        {
            dfs(var.first);
        }
    }
}
int main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
  int n,m,x,y;
  cin>>n>>m;
  for(int i=1;i<=m;i++)
  {
      cin>>x>>y;
      graf[x].push_back({y, i});
      graf[y].push_back({x, i});
      grad[x]++;
      grad[y]++;
  }
  dfs(1);
  bool nasol=0;
  for(int i=1;i<=n;i++)
  {
      if(viz[i]==0||grad[i]%2==1)
      {
          nasol=1;
          break;
      }
  }
  if(nasol==0)
  {
      build(1);
      ans.pop_back();
      for(auto var:ans)
        cout<<var<<" ";
  }
  else
    cout<<-nasol;
    return 0;
}
