#include "bits/stdc++.h"
#include <type_traits>
using namespace std;

#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#pragma GCC optimization("unroll-loops")

// ============ Macros starts here ============
int recur_depth = 0;
#ifdef DEBUG
#define dbg(x) {++recur_depth; auto x_=x; --recur_depth; cerr<<string(recur_depth, '\t')<<"\e[91m"<<__func__<<":"<<__LINE__<<"\t"<<#x<<" = "<<x_<<"\e[39m"<<endl;}
#else
#define dbg(x)
#endif // DEBUG
template<typename Ostream, typename Cont>
typename enable_if<is_same<Ostream, ostream>::value, Ostream&>::type operator<<(Ostream& os, const Cont& v) {
    os << "[";
    for (auto& x : v) { os << x << ", "; }
    return os << "]";
}
template<typename Ostream, typename ...Ts>
Ostream& operator<<(Ostream& os, const pair<Ts...>& p) {
    return os << "{" << p.first << ", " << p.second << "}";
}

#define readFast                      \
    ios_base::sync_with_stdio(false); \
    cin.tie(0);                       \
    cout.tie(0);
#ifdef LOCAL
#define read() ifstream fin("date.in.txt")
#else
#define read() readFast
#endif // LOCAL
// ============ Macros ends here ============

#define fin cin
#define ll long long
#define sz(x) (int)(x).size()
#define all(v) v.begin(), v.end()
#define output(x) (((int)(x) && cout << "YES\n") || cout << "NO\n")
#define LSB(x) (x & (-x))
#define test cout << "WORKS\n";

const int N = 1e5 + 15;
const int MOD = 1e9 + 7; // 998244353

const int INF = 1e9;
int t, n, m;

vector<int> graf[N];
vector<unordered_multiset<int>> used;
// multiset<pair<int, int>> used;
vector<int> ans;

void dfs(int node) {
    for (int to : graf[node]) {
        if (used[node].find(to) != used[node].end()) {
            used[node].erase(used[node].find(to));
            used[to].erase(used[to].find(node));
            dfs(to);
        }
    }
    ans.push_back(node);
}


int main() {
    read();
    ifstream fin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    fin >> n >> m;

    used.resize(n + 1, unordered_multiset<int>());
    for (int i = 0; i < m; ++i) {
        int a, b;
        fin >> a >> b;
        graf[a].push_back(b);
        graf[b].push_back(a);
        used[a].insert(b);
        used[b].insert(a);
    }
    dfs(1);
    ans.pop_back();
    for (int x : ans) {
        cout << x << " ";
    }


    return 0;
} /*stuff you should look for !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   * test the solution with the given example
   * int overflow, array bounds, matrix bounds
   * special cases (n=1?)
   * do smth instead of nothing and stay organized
   * WRITE STUFF DOWN
   * DON'T GET STUCK ON ONE APPROACH
~Benq~*/

