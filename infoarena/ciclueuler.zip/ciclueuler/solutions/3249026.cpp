#include <fstream>
#include <vector>

using namespace std;

vector<vector<pair<int, int>>> graph;
vector<int> grad, visN, visM, sol;

void dfs (int node) {
    visN[node] = 1;
    for(auto next : graph[node]) {
        if(!visN[next.first]) {
            dfs(next.first);
        }
    }
}

void euler (int node) {
    while (graph[node].size() > 0) {
        int next = graph[node].back().first;
        int next_edge = graph[node].back().second;
        graph[node].pop_back();
        if (!visM[next_edge]) {
            visM[next_edge] = 1;
            euler(next);
        }
    }
    sol.push_back(node);
}



int main() {
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    
    int n, m;
    cin >> n >> m;
    
    graph.resize(n+1);
    grad.resize(n+1);
    visN.resize(n+1);
    visM.resize(m+1);
    
    for (int i = 1; i <= m; i++) {
        int a, b;
        cin >> a >> b;
        grad[a]++;
        grad[b]++;
        graph[a].push_back({b, i});
        graph[b].push_back({a, i});
    }
    dfs(1);
    
    // daca exista un nod nevizitat sau gradul lui e impar, nu avem ciclu eulerian
    int ok = 1;
    for (int i = 1; i <= n; i++) {
        if (visN[i] == 0 || grad[i] % 2 == 1) {
            ok = 0;
        }
    }
    if(ok == 0) {
        cout << -1 << '\n';
    } else {
        euler(1);
        sol.pop_back();
        for(auto node : sol) {
            cout << node << " ";
        }
    }
    return 0;
}
