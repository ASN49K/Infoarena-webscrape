#include <bits/stdc++.h>
#define ll long long
#define ii pair<int, int>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector<int> get_eulerian_cycle(int n, int m, int start, vector<vector<pair<int, int>>> graph) {
    for (int i = 1; i <= n; ++i) {
        if (graph[i].size() % 2 == 1) {
            return {-1};
        }
    }
    
    vector<int> cycle;
    vector<bool> seen(m + 1);
    
    stack<int> nodes;
    nodes.push(start);

    while (!nodes.empty()) {
        int node = nodes.top();

        if (!graph[node].empty()) {
            int dest = graph[node].back().first;
            int num = graph[node].back().second;
            graph[node].pop_back();

            if (!seen[num]) {
                seen[num] = true;
                nodes.push(dest);
            }
        } else {
            nodes.pop();
            cycle.push_back(node);
        }
    }

    cycle.pop_back();
    return cycle;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    fin >> n >> m;
    vector<vector<pair<int, int>>> graph(n + 1);
    for (int i = 1; i <= m; ++i) {
        int a, b;
        fin >> a >> b;
        graph[a].push_back({b, i});
        graph[b].push_back({a, i});
    }
    
    vector<int> cycle = get_eulerian_cycle(n, m, 1, graph);

    for (int x : cycle) {
        fout << x << ' ';
    }
    fout << '\n';
    return 0;
}
