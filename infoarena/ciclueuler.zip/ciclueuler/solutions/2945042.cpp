#include <bits/stdc++.h>
#define mmax 500005
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int st[mmax], dr[mmax], m; /// retinem muchiile
int viz[mmax], d[100002]; /// d[i] = gradul lui i
vector <int> L[100002];
/// L[i] retine indicii muchiilor incidente cu nodul i
int sol[mmax], len, n;
int ind[100002];
/// ind[i] = indicele muchiei unde
/// am ramas in DFS

void Citire()
{
    int i, j;
    fin >> n >> m;
    for (int k = 1; k <= m; k++)
    {
        fin >> i >> j;
        st[k] = i;
        dr[k] = j;
        d[i]++;
        d[j]++;
        L[i].push_back(k);
        L[j].push_back(k);
    }
}

int ToatePare()
{
    for (int i = 1; i <= n; i++)
        if (d[i] % 2 == 1) return 0;
    return 1;
}

void DFS(int k)
{
    while (ind[k] < L[k].size())
    {
        int i = L[k][ind[k]];
        ind[k]++;
        if (viz[i] == 0)
        {
            viz[i] = 1;
            DFS(st[i] + dr[i] - k);
        }
    }
    sol[++len] = k;
}

void Afisare()
{
    for (int i = 1; i < len; i++)
        fout << sol[i] << " ";
    fout << "\n";
}

int main()
{
    Citire();
    if (ToatePare() == 0) fout << "-1\n";
    else
    {
        DFS(1);
        Afisare();
    }
    fout.close();
    return 0;
}
