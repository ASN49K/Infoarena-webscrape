#include<fstream>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;

ifstream cin("euler.in");
ofstream cout("euler.out");

const int NMAX = 2e5 + 1;

vector<pair<int,int>> vecini[NMAX];

int grad[NMAX];

bool folosit[3 * NMAX];

bool u;

void euler(int nod)
{
    for(auto it : vecini[nod])
        {
            if(folosit[it.second])
                continue;

            folosit[it.second] = 1;
            euler(it.first);
        }

    if(nod == 1)
        {
            if(!u)
                {
                    cout << 1 << " ";
                    u = true;
                }
        }

    else cout << nod << " ";
}

int main()
{

     int n,m = 0,a,b;
     cin >> n >> m;
     while(m--)
        {
            cin >> a >> b;
            vecini[a].push_back({b,m});
            vecini[b].push_back({a,m});
            grad[a]++,grad[b]++;
        }

    bool ok = true;
    for(int i = 1; i <= n ; i++) if(grad[i] & 1) ok = false;
    if(!ok) cout << -1;
    else euler(1);

}
