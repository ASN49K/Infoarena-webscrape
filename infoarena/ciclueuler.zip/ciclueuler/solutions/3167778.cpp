#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, x, y, a, b, v[1005][1005], q[1005], nr;

void euler (int x) {
    for (int i=1; i<=n; i++) {
        if (v[x][i]) {
            v[x][i]--;
            v[i][x]--;
            euler(i);
        }
    }
    q[++nr]=x;
}

int main() {
    fin >> n >> m;
    for (int i=1; i<=m; i++) {
        fin >> x >> y;
        v[x][y]++;
        v[y][x]++;
    }
    euler(1);
    if (nr%2==1)
        fout << -1;
    else
        for (int i=nr; i>1; i--)
            fout << q[i] << " ";
    return 0;
}
