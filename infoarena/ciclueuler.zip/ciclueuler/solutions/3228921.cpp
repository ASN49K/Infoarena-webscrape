// Author: Tanasescu Andrei-Rares
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <queue>
#include <stack>
#include <deque>
#include <iomanip>
#include <vector>
#include <cassert>

#pragma GCC optimize("O3")

#define fi first
#define se second
#define pb push_back
#define pf push_front

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

const ll Nmax=1e5+5, Mmax=5e5+5, inf=1e9+5;

int n, m;
int crtv=-1, crtdel;
vector<int> ad[Nmax];
struct edge{
    int total;
    int vis, del;
};
map<pii, edge> mp;
int v[Mmax];

void dfs(int nod){
    v[++crtv]=nod;
    if (crtv==m)
        return;

    for (auto it:ad[nod]){
        int nod1=min(nod, it), nod2=max(nod, it);
        int total=mp[{nod1, nod2}].total;
        int vis=mp[{nod1, nod2}].vis;
        int del=mp[{nod1, nod2}].del;
        if (vis+del!=total || del!=0 && crtdel+crtv==m){
            if (vis+del==total){
                crtdel--;
                mp[{nod1, nod2}].del--;
            }
            mp[{nod1, nod2}].vis++;
            dfs(it);
            if (crtv==m)
                return;
            mp[{nod1, nod2}].del++;
            crtdel++;
        }
    }
    crtv--;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    fin>>n>>m;
    int a, b;
    for (int i=0; i<m; i++){
        fin>>a>>b;
        a--; b--;
        ad[a].pb(b);
        ad[b].pb(a);
        mp[{min(a, b), max(a, b)}].total++;
    }

    bool ok=1;
    for (int i=0; i<n; i++){
        int gr=ad[i].size();
        if (gr%2==1)
            ok=0;
    }
    if (!ok)
        fout<<-1;
    dfs(0);
    if (crtv==m)
        for (int i=0; i<m; i++)
            fout<<v[i]+1<<' ';
    else fout<<0;

    return 0;
}