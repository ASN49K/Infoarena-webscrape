// #include <iostream>
#include <fstream>
#include <vector>

#define pb push_back

using namespace std;

const int kNMax = 1e5;
const int kMMax = 5e5;

vector<vector<pair<int,int>>> g;
vector<bool> a;
vector<int> ans;

void dfs(int nod){
	for (int i=0;i<g[nod].size();i++) {
		if (a[g[nod][i].second]) {
			swap(g[nod][i],g[nod].back());
			g[nod].pop_back();
			i--;
			continue;
		}
		a[g[nod][i].second]=1;
		dfs(g[nod][i].first);
	}
	ans.pb(nod);
}

bool euler(int n){
	for (int i=1;i<=n;i++)
		if (g[i].size()%2!=0)
			return 0;
	dfs(1);
	return 1;
}

int main(){
	ifstream cin("ciclueuler.in");
	ofstream cout("ciclueuler.out");

	int n,m,x,y;
	cin >> n >> m;

	g.resize(n + 1);
	a.resize(m + 1);

	for (int i=1;i<=m;i++) {
		cin>>x>>y;
		g[x].pb({y,i});
		g[y].pb({x,i});
	}

	if (euler(n)) {
		for (int i=0;i<ans.size()-1;i++)
			cout<<ans[i]<<" ";
		cout << "\n";
	}
	else 
		cout<<-1;
	return 0;
}