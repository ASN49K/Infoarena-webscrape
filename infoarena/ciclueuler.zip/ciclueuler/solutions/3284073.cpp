#include <fstream>
#include <vector>
#include <queue>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <set>
#include <cstring>

using namespace std;

ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");

const int MOD=1e9+7;
int t,n,m,x,ans,mini=1e9,k,s,vis[100005],u,v;

vector<pair<int,int>>g[100005];
vector<int>ciclu;

void euler(int nod)
{
    while(!g[nod].empty())
    {
        int curr=g[nod].back().first;
        int pos=g[nod].back().second;
        g[nod].pop_back();
        if(vis[pos]==0)
        {
            vis[pos]=1;
            euler(curr);
        }
    }
    ciclu.push_back(nod);
}


int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>u>>v;
        g[u].push_back({v,i});
        g[v].push_back({u,i});
    }
    for(int i=1;i<=n;i++)
        if(g[i].size()%2==1)
        {
            cout<<-1;
            return 0;
        }

    euler(1);
    ciclu.pop_back();

    for(auto x:ciclu)
        cout<<x<<' ';
    return 0;

}
