//#pragma GCC optimize("O4, Ofast, unroll-loops")
#include <bits/stdc++.h>
using namespace std;

const int nm=1e5+5;

int f[nm];
bool ver[nm];
queue<int> lant;
pair<int, int> e[5*nm];
vector<vector<int>> g;

void dfs(int nod)
{
    while(!g[nod].empty())
    {
        int y=g[nod].back();
        g[nod].pop_back();
        if(ver[y]==0)
        {
            ver[y]=1;
            dfs(e[y].first+e[y].second-nod);
        }
    }
    lant.push(nod);
}

int main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    int n, m, a, b, ok=0, pz=0;
    cin>>n>>m;
    g.resize(n+1);
    for(int i=1; i<=m; i++)
    {
        cin>>a>>b;
        e[++pz]={a, b};
        g[a].push_back(pz);
        g[b].push_back(pz);
        f[a]++;
        f[b]++;
    }
    for(int i=1; i<=n; i++)
    {
        if(f[i]%2==1)
            ok++;
    }
    if(ok>0)
        cout<<-1;
    else
        dfs(1);

    while(lant.size()>1)
    {
        cout<<lant.front()<<" ";
        lant.pop();
    }

    return 0;
}
