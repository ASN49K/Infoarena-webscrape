#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int nMax=1e5+5;

int n, m, euler[nMax+nMax], k;
vector<pair<int, int>> g[nMax];
bool v[nMax];

void dfs(int k)
{
    v[k]=1;
    for(auto& i: g[k])
        if(!v[i.first])
        dfs(i.first);
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);

    fin>>n>>m;
    int x, y;
    for(int i=0; i<m; i++)
    {
        fin>>x>>y;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
    }

    fin.close();

    dfs(1);

    for(int i=1; i<=n; i++)
        if(!v[i])
    {
        fout<<-1;
        return 0;
    }

    for(int i=1; i<=m; i++)
        v[i]=0;

    for(int i=1; i<=n; i++)
        if(g[i].size()%2)
    {
        fout<<-1;
        return 0;
    }

    stack<int> s;

    s.push(1);

    for(int i=1; i<=m; i++)
    {
        int nod=s.top();

        while(!g[nod].empty())
        {
            pair<int, int> aux=g[nod].back();

            g[nod].pop_back();

            if(v[aux.second]==1)
                continue;

            v[aux.second]=1;
            nod=aux.first;
            s.push(nod);
        }
        euler[++k]=nod;
        s.pop();
    }

    for(int i=1; i<=k; i++)
        fout<<euler[i]<<' ';

    fin.close();
    fout.close();

    return 0;
}
