#include <bits/stdc++.h>

using namespace std;
vector<vector<pair<int, int>>> adj(100005);
int mu[100005];
bool viz[100005];
bool viz2[100005];
vector<int> res;
void dfs(int nod) {
  viz[nod] = 1;
  for (auto e : adj[nod]) {
    if (!viz[e.first])
      dfs(e.first);
  }
}
void euler(int nod) {
  while (adj[nod].size() > 0) {
    int ne = adj[nod].back().first;
    int need = adj[nod].back().second;
    adj[nod].pop_back();
    if (!viz2[need]) {
      viz2[need] = 1;
      euler(ne);
    }
  }
  res.push_back(nod);
}
int main() {
  ifstream cin("ciclueuler.in");
  ofstream cout("ciclueuler.out");
  int n, m;
  cin >> n >> m;
  int x, y;
  for (int i = 1; i <= m; i++) {
    cin >> x >> y;
    adj[x].push_back({y, i});
    adj[y].push_back({x, i});
    mu[x]++;
    mu[y]++;
  }
  dfs(1);
  bool yes = true;
  for (int i = 1; i <= n; i++) {
    if (!viz[i] || mu[i] % 2 == 1)
      yes = false;
  }
  if (yes == false)
    cout << -1;
  else {
    euler(1);
    res.pop_back();
    for (auto e : res)
      cout << e << " ";
  }
}