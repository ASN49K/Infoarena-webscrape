#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#include <stack>
#define NMAX 100005
#define MMAX 500005

using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

struct ok{
    int vecin, poz;
};

vector <ok> adj[NMAX];
bool viz[MMAX];
stack <int> cycle;
stack <int> finalCycle;

int main()
{
    int n, m, i, j, a, b;
    in >> n >> m;
    for (i = 1; i <= m; ++i)
    {
        in >> a >> b;
        adj[a].push_back({b, i});
        adj[b].push_back({a, i});
    }

    bool eulerian = true;
    for (i = 1; i <= n; ++i)
    {
        if (adj[i].size() % 2 == 1)
        {
            eulerian = false;
            break;
        }
    }

    if (eulerian == false)
        out << "-1";
    else
    {
        cycle.push(1);
        while (!cycle.empty())
        {
            int node = cycle.top();

            int found = false;
            for (i = 0; i < adj[node].size(); ++i)
            {
                int vecin = adj[node][i].vecin;
                int poz = adj[node][i].poz;
                if (viz[poz] == 0)
                {
                    viz[poz] = 1;
                    cycle.push(vecin);
                    found = true;
                    break;
                }
            }

            if (found == false)
            {
                finalCycle.push(node);
                cycle.pop();
            }
        }

        do
        {
            out << finalCycle.top() << " ";
            finalCycle.pop();
        }while (finalCycle.top() != 1);
    }
    return 0;
}
