#include <bits/stdc++.h>
using namespace std;
int const lmax=1e5+7;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");
int n,m,d[lmax];
bool viz[lmax];
bool euler=true;
int sol[lmax],isol;
struct muchie {
    int node;
    int ind;
};
vector <muchie> G[lmax];
void bfs(int start_node)
{
    queue <int> q;
    viz[start_node]=true;
    q.push(start_node);
    while(q.empty()==false)
    {
        int node=q.front();
        q.pop();
        for(auto vec:G[node])
        {
            if(viz[vec.node]==false)
            {
                viz[vec.node]=true;
                q.push(vec.node);
            }
        }
    }
}
void verif()
{
    bfs(1);
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==false or d[i]%2==1)
        {
            euler=false;
            return;
        }
    }
    return;
}
stack <int> S;
bool sters[lmax*5];
int main()
{
    fin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int a,b;
        fin>>a>>b;
        G[a].push_back({b,i});
        G[b].push_back({a,i});
        d[a]++;
        d[b]++;

    }
    verif();
    if(euler==false)
    {
        fout<<-1;
    }
    S.push(1);
    while(S.empty()==false)
    {
        int node=S.top();
        if(d[node]==0)
        {
            sol[isol++]=node;
            S.pop();
        }
        else
        {
            ///alegem muchia conectata cu node si o stergem, pentru a face asta eficient eliminat ultima din lista in O(1)
            muchie vec=G[node].back();
            G[node].pop_back();
            if(sters[vec.ind]==true)continue;
            sters[vec.ind]=true;
            d[vec.node]--;
            d[node]--;
            S.push(vec.node);
        }
    }
    for(int i=0;i<isol-1;i++)
    {
        fout<<sol[i]<<" ";
    }
    fin.close();
    fout.close();
    return 0;
}
