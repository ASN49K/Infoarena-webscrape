#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>

#include <iomanip>

using namespace std;

string filename = "ciclueuler";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 1e5;
const int EMAX = 5e5;

vector <int> adj[NMAX + 1];

struct Edge{
    int u, v;
}edges[EMAX + 1];

bool viz[EMAX + 1];

vector <int> ans;

void euler(int node){
    for(int vec : adj[node]){
        if(!viz[vec]){
            viz[vec] = true;
            int To = edges[vec].u ^ edges[vec].v ^ node;
            euler(To);
        }
    }
    ans.push_back(node);
}

signed main(){

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        adj[a].push_back(i);
        adj[b].push_back(i);
        edges[i] = {a, b};
    }

    euler(1);    
    
    ans.pop_back();

    for(int x : ans){
        fout << x << ' ';
    }
    fout << '\n';

    return 0;
}