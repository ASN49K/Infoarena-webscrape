#include <fstream>
#include <vector>

using namespace std;

struct muchie
{
    int x, y;
};

vector <muchie> e;
vector <bool> folosit;
vector <unsigned int> poz_liste;
vector <vector <int>> a;
vector <int> euler;

int celalalt_varf(muchie m, int x)
{
    return (m.x + m.y - x);
}

void dfs_euler(int x)
{
    while (poz_liste[x] < a[x].size())
    {
        int p = a[x][poz_liste[x]];
        if (!folosit[p])
        {
            int y = celalalt_varf(e[p], x);
            folosit[p] = true;
            dfs_euler(y);
        }
        poz_liste[x]++;
    }
    euler.push_back(x);
}

bool toate_gradele_pare(int n)
{
    for (int i = 1; i <= n; i++)
    {
        if (a[i].size() % 2 != 0)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    int n, m;
    in >> n >> m;
    e.resize(m);
    folosit.resize(m);
    poz_liste.resize(n + 1, 0);
    a.resize(n + 1);
    for (int i = 0; i < m; i++)
    {
        in >> e[i].x >> e[i].y;
        a[e[i].x].push_back(i);
        a[e[i].y].push_back(i);
    }
    for (int i = 1; i <= n; i++)
    {
        if (a[i].size() > 0)
        {
            dfs_euler(i);
            break;
        }
    }
    if (toate_gradele_pare(n) && (int)euler.size() == m + 1 && euler[0] == euler[m])
    {
        for (int i = 0; i < m; i++)
        {
            out << euler[i] << " ";
        }
        out << "\n";
    }
    else
    {
        out << "-1\n";
    }
    in.close();
    out.close();
    return 0;
}
