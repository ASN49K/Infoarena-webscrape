#include <bits/stdc++.h>


using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX=1e5,MMAX=5e5;
int n,i,m,deg[NMAX+5],node1,node2;
bool viz[NMAX+5];
vector <pair<int,int>> adj[NMAX+5];
vector <int> ans;

void Euler(int node)
{

    while (!adj[node].empty())
    {
        pair <int,int> edge=adj[node].back();
        adj[node].pop_back();

        int node2=edge.first,idx=edge.second;

        if (!viz[idx])
        {
            viz[idx]=1;
            Euler(node2);
        }
    }

    ans.push_back(node);
}


int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr); fout.tie(nullptr);

    fin>>n>>m;
    for (i=1; i<=m; i++)
    {
        fin>>node1>>node2;
        deg[node1]++;
        deg[node2]++;
        adj[node1].push_back({node2,i});
        adj[node2].push_back({node1,i});
    }

    for (i=1; i<=n; i++)
    {
        if (deg[i]%2==1)
        {
            fout<<-1;
            return 0;
        }
    }

    Euler(1);

    for (int i=0; i<ans.size()-1; i++)
        fout<<ans[i]<<" ";

    return 0;
}
