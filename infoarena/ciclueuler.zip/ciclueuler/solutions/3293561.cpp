#include<bits/stdc++.h>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");


int main()
{
vector<int>raspuns;
int n,m,x,y;

in>>n>>m;
vector<vector<int>>muchii(n+1,vector<int>());
int from[m+1],to[m+1];
vector<bool>parcurs(m+1,0);
for(int i=1;i<=m;i++)
{in>>x>>y;
   from[i]=x;
   to[i]=y;
   muchii[x].push_back(i);
   muchii[y].push_back(i);
}
for(int i=1;i<=n;i++)
{if(muchii[i].size()%2)
{out<<-1;
return 0;
}
}
stack<int>lista;
lista.push(1);
while(!lista.empty())
{int nod=lista.top();
if(!muchii[nod].empty())
{int muchie=muchii[nod].back();

if(!parcurs[muchie])
{parcurs[muchie]=1;

 int other;
 if(to[muchie]==nod)
 other=from[muchie];
 else
 other=to[muchie];
 lista.push(other);
}
else
muchii[nod].pop_back();
}
else
{raspuns.push_back(nod);
    lista.pop();
}}
int marime=raspuns.size()-2;

for(int i=0;i<=marime;i++)
out<<raspuns[i]<<" ";



}
