#include <bits/stdc++.h>

using namespace std;

#define oo 0x3f3f3f3f

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m;
vector<pair<int, int>> graph[100005];
bool viz[500005];

void read() {
  f>>n>>m;
  int x, y;
  for(int i = 1;i <= m;++i) {
    f>>x>>y;
    graph[x].push_back(make_pair(y, i));
    graph[y].push_back(make_pair(x, i));
  }
}

void solve() {
  for(int i = 1;i <= n;++i) {
    if(graph[i].size() % 2) {
      g<<-1;
      return;
    }
  }

  vector<int> result;
  stack<int> s;
  s.push(1);
  
  while(!s.empty()) {
    int top = s.top();

    if(graph[top].size()) {
      auto back = graph[top].back(); 
      graph[top].pop_back();
      if(!viz[back.second]) {
        s.push(back.first);
      }
      viz[back.second] = true;
    } else {
      s.pop();
      result.push_back(top);
    }
  }
  for(const auto& node : result) {
    g<<node<<" ";
  }
}

int main() {
  read();
  solve();

  return 0;
}
