#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m, st[500005], dr[500005], viz[500005], poz[100005];
vector<int>edg[100005];
vector<int>ans;

bool Posibil() {
    for (int i = 1; i <= n; i++)
        if (edg[i].size() % 2 == 1)
            return 0;
    return 1;
}

void Euler(int nod) {
    int k = 1;
    while (poz[nod] < edg[nod].size()) {
        k = edg[nod][poz[nod]];///prima muchie nevizitata din multimea lui nod
        poz[nod]++;
        if (!viz[k]) {
            viz[k] = 1;
            if (st[k] == nod)
                Euler(dr[k]);
            else
                Euler(st[k]);
            ///Euler(st[k]+dr[k] - nod);

        }
    }
    ans.push_back(nod);
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> st[i] >> dr[i];
        edg[st[i]].push_back(i);
        edg[dr[i]].push_back(i);
    }
    if (!Posibil())
        fout << "-1\n";
    else {
        Euler(1);
        for (int i = ans.size() - 1; i > 0; i--)
            fout << ans[i] << " ";
    }


    return 0;
}
