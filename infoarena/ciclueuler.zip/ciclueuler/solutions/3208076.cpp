#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m;
vector<pair<int,int>>G[100001];
int viz[500001];
int viz2[100001];
int grad[100001];
bool once = 0;
bool da;

stack<int>st_dfs;
stack<int>st_ciclu;

void euler_bun(int start)
{
	st_dfs.push(start);
	while (!st_dfs.empty())
	{
		int varf = st_dfs.top();
		viz2[varf] = 1;
		if (G[varf].size() > 0)
		{
			pair<int, int>it = G[varf].back();
			G[varf].pop_back();

			if (!viz[it.second])
			{
				viz[it.second] = 1;
				st_dfs.push(it.first);
			}
		}
		else {
			st_dfs.pop();
			st_ciclu.push(varf);
		}
	}
}
void citire()
{
	f >> n >> m;
	int x, y;
	for (int i = 1; i <= m; i++)
	{
		f >> x >> y;
		G[x].push_back({ y,i });
		G[y].push_back({ x ,i});
		grad[x]++;
		grad[y]++;
	}
}

void afis()
{
	if (!st_ciclu.empty())
	{
		int elem = st_ciclu.top();
		st_ciclu.pop();
		afis();
		g << elem << ' ';
	}
}
int main()
{
	citire();
	for (int i = 1; i <= n; i++)
	{
		if (grad[i] != 0 && !once)
		{
			euler_bun(i);
			once = 1;
		}
		else if (grad[i] != 0 && once && !viz2[i])
		{
			da = 1;
		}
	}
	if (da)
	{
		g << -1;
	}
	else {
		afis();
	}
}