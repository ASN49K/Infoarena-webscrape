#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector<vector<pair<int, int>>> la;
vector<int> viz, ciclu;

void euler (int v) {
    while (la[v].size() > 0) {
        int w = la[v].back().first;
        int idx = la[v].back().second;
        la[v].pop_back();

        if (viz[idx] == 0) {
            viz[idx] = 1;
            euler(w);
        }
    }

    ciclu.push_back(v);
}

int main() {
    int N, M;
    fin >> N >> M;

    la.resize(N + 1);
    viz.assign(M, 0);

    for (int i = 0; i < M; i++) {
        int x, y;
        fin >> x >> y;
        
        la[x].push_back({y, i});
        la[y].push_back({x, i});
    }

    euler(1);

    ciclu.pop_back();
    for (auto& n : ciclu) {
        fout << n << ' ';
    }
    return 0;
}