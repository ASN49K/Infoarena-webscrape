#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <deque>
#include <algorithm>
using namespace std;

#define in fin
#define out fout
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

typedef pair<int, int> pii;

const int MAXN = 1e5;
const int MAXM = 5e5;

int n, m, x, y;
int grad[MAXN+1];
bool viz[MAXM+1];
vector<pii> graf[MAXN+1];
stack<int> stiva;
deque<int> ciclu;

void euler() {
    stiva.push(1);

    while (!stiva.empty()) {
        int nod = stiva.top();

        if (graf[nod].size()) {
            int e = graf[nod].back().first;
            int m_idx = graf[nod].back().second;
            graf[nod].pop_back();

            if (!viz[m_idx]) {
                viz[m_idx] = true;
                stiva.push(e);
            }
        }

        else {
            ciclu.push_back(nod);
            stiva.pop();
        }

    }
}

int main() {
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y;
        graf[x].push_back({y, i});
        graf[y].push_back({x, i});

        grad[x]++, grad[y]++;
    }

    for (int i = 1; i <= n; i++) {
        if (grad[i] % 2 == 1) {
            out << "-1";
            return 0;
        }
    }

    euler();

    ciclu.pop_back();
    while (!ciclu.empty()) {
        out << ciclu.front() << ' ';
        ciclu.pop_front();
    }

    return 0;
}

/*
#include <fstream>
#include <stack>
#include <vector>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

#define NMAX 100000
#define NRM 500000
typedef  pair<int, int> PII;

int n, m;
bool sel[NRM + 1];      //ce muchii vizitez;
vector<PII> G[NRM + 1];
vector<int> ans;

//ca sa admita un ciclu eulerian graful trebuie sa aiba toate nodurile cu grad par;
static inline bool IsEuler() {
  int ok = 1;
  for(int i = 1; i <= n; i++)
    if(G[i].size() % 2 == 1)
      ok = 0;
  return ok;
}

int main() {
  fin >> n >> m;
  for(int i = 1; i <= m; i++) {
    int x, y;

    fin >> x >> y;
    G[x].push_back({y, i}); //unde merg si a cata muchie e;
    G[y].push_back({x, i});
  }

  if(!IsEuler())
    fout << -1;
  else {
    stack<int> ST;
    ST.push(1);
    while(!ST.empty()) {
      int nod = ST.top();
      if(G[nod].size()) {             //daca mai am vecini;
        int x = G[nod].back().first;  //vecinul;
        int muchie = G[nod].back().second;  //ce muchie parcurg;
        G[nod].pop_back();

        if(!sel[muchie]) {
          sel[muchie] = 1;  //marchez muchia;
          ST.push(x);       //retin nodul in stiva;
        }
      }else {
        ST.pop();           //elimin nodul cand nu mai are vecini nevizitati;
        ans.push_back(nod);
      }
    }
    ans.pop_back();
    for(auto e : ans)
      fout << e << " ";
  }

  return 0;
}
*/
