#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100002
#define MMAX 500002
using namespace std;
ifstream  fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int N,M;
stack<int>stiva;
vector<int> ans,f(MMAX);
vector<pair<int,int>>graph[NMAX];

void citire()
{
    fin>>N>>M;

    int u,v;
    for(int i=1; i<=M; i++)
    {
        fin>>u>>v;
        graph[u].push_back({v,i});
        graph[v].push_back({u,i});
    }
}

void euler(int start)
{
    stiva.push(start);

    while(!stiva.empty())
    {
        int nod=stiva.top();
        while(!graph[nod].empty())
        {
            auto &dublet=graph[nod].back();
            graph[nod].pop_back();

            int next_nod=dublet.first;
            int muchie=dublet.second;

            if(!f[muchie])
            {
                f[muchie]=1;
                stiva.push(next_nod);
            }
            else
            {
                continue;
            }
        }
        ans.push_back(nod);
        stiva.pop();
    }
}

int main()
{
    citire();

    for(int i=1; i<=N; i++)
    {
        if(graph[i].size()%2==1)
        {
            fout<< -1 << "\n";
            return 0;
        }
    }

    euler(1);

    for(int i=0; i<ans.size()-1; i++)
    {
        fout<< ans[i] << " ";
    }
    fout<< "\n";

    return 0;
}
