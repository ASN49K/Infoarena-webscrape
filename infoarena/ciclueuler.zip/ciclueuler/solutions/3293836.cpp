#include <bits/stdc++.h>
using namespace std;

//aemi
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");


int n, m;
int X[500005], Y[500005], poz[100005], viz[500005];
vector<int> L[100005];
vector<int> euler;

void Euler(int k)
{
    while (poz[k] < L[k].size())
    {
        int i = L[k][poz[k]++];
        if (viz[i] == 0)
        {
            viz[i] = 1;
            Euler(X[i] + Y[i] - k);
        }
    }
    euler.push_back(k);
}

int main()
{
    int i, j;
    fin >> n >> m;
    for (int p = 1; p <= m; p++)
    {
        fin >> i >> j;
        X[p] = i; Y[p] = j;
        L[i].push_back(p);
        L[j].push_back(p);

    }
    Euler(1);
    euler.pop_back();
    for (int i : euler)
        fout << i << " ";
    return 0;
}
