#include <bits/stdc++.h>
#define pii pair<int, int>
#define ff first
#define ss second
#define vi vector<int>
#define vvi vector<vi>
#define vpi vector<pii>
#define vvpi vector<vpi>
#define pb push_back
#define eb emplace_back

//#define int long long
using namespace std;
const string TASK("ciclueuler");
ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");
#define cin fin
#define cout fout

const int N = 500009;

int n, m;
bool viz[N];
vvpi G(N);
vi ans;


void Dfs(int x)
{
    while(!G[x].empty())
    {
        int v = G[x].back().ff, i = G[x].back().ss;
        G[x].pop_back();

        if(!viz[i])
        {
            viz[i] = true;
            Dfs(v);
        }
    }
    ans.pb(x);
}


signed main()
{
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    cin >> n >> m;

    int x, y;
    for(int i = 1; i <= m; ++i)
    {
        cin >> x >> y;
        G[x].eb(y, i);
        G[y].eb(x, i);
    }

    bool ok = true;
    for(int i = 1; i <= n; ++i)
        if(G[i].size() % 2 == 1)
            ok = false;

    if(!ok)
    {
        cout << "-1\n";
        return 0;
    }

    Dfs(1);

    for(auto i : ans)cout << i << ' ';
    return 0;
}
