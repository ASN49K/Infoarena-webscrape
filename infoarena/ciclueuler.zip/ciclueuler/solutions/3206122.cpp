#include <bits/stdc++.h>
using namespace std;


ifstream fin("euler.in");
ofstream fout("euler.out");

const int NMAX = 1e5;

int n,m;
vector < pair < int , int > > G[NMAX + 1];
int viz[5 * NMAX];
stack < int > s;
int cnt;

void dfs_muchii(int nod){
    for(auto nbr: G[nod]){
        int muchie_curenta = nbr.second;
        int nodc = nbr.first;
        if(!viz[muchie_curenta]){
            viz[muchie_curenta] = 1;
            dfs_muchii(nodc);
        }
    }
    s.push(nod);
    cnt++;
}

int main(){

    fin >> n >> m;  
    for(int i = 1;i<=m;++i){
        int x,y;
        cin >> x >> y;
        G[x].push_back({y,i});
        G[y].push_back({x,i});
    }
    dfs_muchii(1);
    while(!s.empty()){
        fout << s.top() << ' ';
        s.pop();
    }
    return 0;
}