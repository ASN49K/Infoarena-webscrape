#include <bits/stdc++.h>
using namespace std;

/**
Alg. lui Householder
Construim listele de adiacenta L in care
L[i] = indicii muchiilor care au pe i
       ca extremitate
A B viz
1 2
1 3
2 2
2 3
3 4
3 4

L[1] = 1,2
L[2] = 1,3,4
*/

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n;
int e[500005], p; /// aici retinem ciclul
vector<int> L[100002];
int A[500005], B[500005], m;
int viz[500005];
int d[100002];

void Citire()
{
    int i, j;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        fin >> A[i] >> B[i];
        d[A[i]]++; d[B[i]]++;
        L[A[i]].push_back(i);
        L[B[i]].push_back(i);
    }
}

void DFS(int k)
{
    for (int i : L[k])
        if (viz[i] == 0)
        {
            /// muchia este A[i],B[i]
            viz[i] = 1;
            DFS(A[i] + B[i] - k);
        }
    e[++p] = k;
}

void Afisare()
{
    for (int i = 1; i < p; i++)
        fout << e[i] << " ";
    fout << "\n";
}

int ToatePare()
{
    for (int i = 1; i <= n; i++)
        if (d[i] % 2 == 1) return 0;
    return 1;
}

int main()
{
    Citire();
    if (ToatePare())
    {
        DFS(1);
        Afisare();
    }
    else fout << "-1\n";
    fin.close();
    fout.close();
    return 0;
}
