#include <fstream>
#include<bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX=1e5;
stack<int>st;
vector<int>cycle;
vector<pair<int,int>>graph[NMAX+5];
vector<bool>used;
void hierholzer(int nod)
{
    st.push(nod);
    while(!st.empty())
    {
        int CurrentNod=st.top();
        while(!graph[CurrentNod].empty() && used[graph[CurrentNod].back().second]) graph[CurrentNod].pop_back();
        if(graph[CurrentNod].empty())
        {
            st.pop();
            cycle.push_back(CurrentNod);
        }
        else
        {
            auto x=graph[CurrentNod].back();
            st.push(x.first);
            used[x.second]=true;
            graph[CurrentNod].pop_back();
        }
    }
}
int main()
{
    int n,m;
    fin>>n>>m;
    used.resize(m+1,false);
    for(int i=0; i<m; i++)
    {
        int x,y;
        fin>>x>>y;
        graph[x].push_back({y,i});
        graph[y].push_back({x,i});
    }
    for(int i=1; i<=n; i++) if(graph[i].size()%2==1)
        {
            fout<<-1;
            return 0;
        }
    hierholzer(1);
    reverse(cycle.begin(),cycle.end());
    for(int i=0; i<cycle.size()-1; i++) fout<<cycle[i]<<" ";
    return 0;
}
