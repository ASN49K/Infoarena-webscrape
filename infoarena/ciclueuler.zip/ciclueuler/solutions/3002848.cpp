#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n,m;
int mat[20][20],grad[20];
stack <int> S;

void euler()
{
    if(!S.empty())
    {
        int nod=S.top();
        if(grad[nod]==0)
        {
            g<<nod<<" ";
            S.pop();
        }
        else
        {
            for(int j=1;j<=n;j++)
            {
                if(mat[nod][j]>0)
                {
                    mat[nod][j]--;
                    mat[j][nod]--;
                    grad[nod]--;
                    grad[j]--;
                    S.push(j);
                    euler();
                }
            }
            if(grad[nod]==0)
                g<<nod<<" ";
        }
    }
}

int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        grad[x]++;
        grad[y]++;
        mat[x][y]++;
        mat[y][x]++;
    }
    S.push(1);
    int s=0;
    for(int i=1;i<=n;i++)
    {
        if(grad[i]%2==1)
            s=1;
    }
    if(s==1)
        g<<-1;
    else
        euler();
    return 0;
}
