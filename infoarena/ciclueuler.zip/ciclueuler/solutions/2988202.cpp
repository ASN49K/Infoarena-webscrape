#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
string file = "ciclueuler";
ifstream cin(file + ".in");
ofstream cout(file + ".out");
const int N = 1e5, M = 5e5;
struct muchie {
	int x, y;
};
muchie e[M + 1];

bitset <M + 1> sters;

vector <int> a[N + 1], ciclul;

int ultimul[N + 1];

int celalalt(muchie m, int x)
{
	return (m.x + m.y - x);
}
void euler(int x)
{
	while (ultimul[x] < a[x].size()) // parcurgem muchiile lui x de unde am ramas
	{
		int ind = a[x][ultimul[x]];
		if (!sters[ind])
		{
			int y = celalalt(e[ind], x);
			sters[ind] = 1;
			euler(y);
		}
		ultimul[x]++;
	}
	ciclul.push_back(x);
}
int main()
{
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		cin >> e[i].x >> e[i].y;
		a[e[i].x].push_back(i);
		a[e[i].y].push_back(i);
	}
	for (int i = 1; i <= n; i++)
	{
		if (a[i].size() % 2)
		{
			cout << -1;
			return 0;
		}
	}
	euler(e[0].x);
	for (int x : ciclul)
	{
		cout << x << ' ';
	}
}