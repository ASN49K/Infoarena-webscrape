#include <bits/stdc++.h>

using namespace std;

const int N=1e5+5, M=5e5+5;

vector<pair<int, int>> adj[N];
vector<int> path;

int cnt, ptr[N], degree[N];

bool used[M], vis[N];

void dfs(int i){
    vis[i]=true;
    cnt++;
    for (auto [x, idx]: adj[i]){
        if (!vis[x]){
            dfs(x);
        }
    }
}

void getpath(int i){
    while (ptr[i]<(int)adj[i].size()){
        auto [x, idx]=adj[i][ptr[i]];
        ptr[i]++;
        if (!used[idx]){
            used[idx]=true;
            getpath(x);
        }
    }
    path.push_back(i);
}

int main()
{
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    path.reserve(M);
    int n,m;cin>>n>>m;
    for (int i=0;i<m;i++){
        int u,v;cin>>u>>v;
        adj[u].push_back({v, i});
        adj[v].push_back({u, i});
        degree[u]++;
        degree[v]++;
    }
    dfs(1);
    int cnt0=0;
    for (int i=1;i<=n;i++){
        if (degree[i]%2){
            cout<<-1;
            return 0;
        }
        if (degree[i]==0){
            cnt0++;
        }
    }
    if (cnt!=n-cnt0){
        cout<<-1;
        return 0;
    }
    getpath(1);
    for (auto x: path){
        cout<<x<<' ';
    }
    return 0;
}
