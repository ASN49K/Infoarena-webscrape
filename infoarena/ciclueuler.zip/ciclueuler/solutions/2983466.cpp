#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n;
vector<int> ans;
bool v[205][205];

void citire()
{
    f>>n;
    int x,y;
    while(f>>x>>y)
    {
        v[x][y] = true;
        v[y][x] = true;
    }
}

void euler(int nod)
{
    for(int i=1;i<=n;i++)
    {
        if(v[nod][i] == 1 || v[i][nod] == 1)
        {
            v[nod][i] = 0;
            v[i][nod] = 0;
            euler(i);
        }
    }
    ans.push_back(nod);
}

int main()
{
    citire();
    euler(1);
    g<<ans.size()<<"\n";
    for(int i=0;i<ans.size();i++)
        g<<ans[i]<<" ";
}