#include <bits/stdc++.h>
using namespace std;
/**
CicluEuler - infoarena
adj[i] retine adiacentii nodului i
L[i] retine indicii muchiilor
    incidente cu i
d[i] = gradul nodului i
in sol retinem ciclul eulerian

adj este pentru verificarea conexitatii
grafului, L este pentru det. ciclului
eulerian
*/
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int A[500002], B[500002], m; /// muchiile
vector <int> L[100002];
vector <int> adj[100002];
bitset<500002> viz;
int sol[500005], len;
int d[100002], n;

void Citire()
{
    int i;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        fin >> A[i] >> B[i];
        L[A[i]].push_back(i);
        L[B[i]].push_back(i);
        adj[A[i]].push_back(B[i]);
        adj[B[i]].push_back(A[i]);
        d[A[i]]++;
        d[B[i]]++;
    }
}

void DFS(int k)
{
    viz[k] = 1;
    for (int i : adj[k])
        if (viz[i] == 0)
            DFS(i);
}

int EsteEulerian()
{
    int i;
    /// verific daca gradele nodurilor
    /// sunt toate pare
    for (i = 1; i <= n; i++)
        if (d[i] % 2 == 1) return 0;
    /// caut un nod d[i]>0
    for (i = 1; d[i] == 0; i++)
        ;
    DFS(i);
    /// caut daca cumva exista un nod
    /// neizolat nevizitat
    for (i = 1; i <= n; i++)
        if (viz[i]==0 && d[i]>0)
            return 0;
    return 1;
}

void DFS_Euler(int k)
{
    for (int i : L[k])
        if (viz[i] == 0)
        ///muchia (A[i],B[i]) este nevizitata
    {
        viz[i] = 1;
        DFS_Euler(A[i]+B[i]-k);
    }
    sol[++len] = k;
}

int main()
{
    int i;
    Citire();
    if (EsteEulerian() == 0)
    {
        fout << "-1\n";
        fout.close();
        return 0;
    }
    viz.reset();
    for (i = 1; d[i] == 0; i++)
        ;
    DFS_Euler(i);
    for (i = 1; i < len; i++)
        fout << sol[i] << " ";
    return 0;
}
