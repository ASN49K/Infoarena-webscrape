#pragma GCC optimize("O3", "Ofast", "unroll-loops")
#include <bits/stdc++.h>

using namespace std;

const int NMAX=1e5;

struct myvector
{
    int v[5*NMAX+5];
    int sz;

    myvector()
    {
        sz=0;
    }
    void add(int numar)
    {
        v[sz++]=numar;
    }
    void pop()
    {
        --sz;
    }
    int last()
    {
        return v[sz-1];
    }
};
myvector ans, st;

int n, m, grad[NMAX+1];
unordered_multiset<int> s[NMAX+1];
///available edges

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);

    cin>>n>>m;
    for(int i=1, x, y; i<=m; i++)
    {
        cin>>x>>y;
        s[x].insert(y);
        s[y].insert(x);

        ++grad[x];
        ++grad[y];
    }

    for(int i=1; i<=n; i++)
        if(grad[i]%2==1)
        {
            cout<<-1;
            return 0;
        }
    st.add(1);
    int nod;
    while(st.sz!=0)
    {
        nod=st.last();

        if(s[nod].empty())
        {
            ans.add(nod);
            st.pop();
        }
        else
        {
            int to=*(s[nod].begin());
            s[nod].erase(s[nod].find(to));
            s[to].erase(s[to].find(nod));
            st.add(to);
        }
    }

    int szans=ans.sz;
    for(int i=0; i<szans-1; i++)
        cout<<ans.v[i]<<' ';
    return 0;
}
