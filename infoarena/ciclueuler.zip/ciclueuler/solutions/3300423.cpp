#include <bits/stdc++.h>

using namespace std;

multiset <int> s[100055];

int a[500555];

int in=0;



void bk(int k)
{
    while(s[k].size())
    {
        int v=*s[k].begin();
        s[k].erase(s[k].find(v));
        s[v].erase(s[v].find(k));
        bk(v);
    }
    ++in;
    a[in]=k;
}

int main()
{
    ifstream cin("ciclueuler.in");
    ofstream cout("ciclueuler.out");
    int n,m,x,y;
    cin>>n>>m;
    for(int i=1;i<=m;++i)
    {
        cin>>x>>y;
        s[x].insert(y);
        s[y].insert(x);
    }
        bool ok=true;
        for(int i=1;i<=n;++i)
    {
        if(s[i].size()%2!=0)
        {
            ok=false;
        }
    }
    if(ok==false)
    {
        cout<<-1;
    }
    else
    {
            bk(1);
                for(int i=1;i<=n;++i)
    {
        if(s[i].size()!=0)
        {
            ok=false;
        }
    }
    if(ok==false)
    {
        cout<<-1;
    }
    else
    {


        for(int i=m;i>=1;--i)
        {
            cout<<a[i]<<" ";
        }
    }
    }
    return 0;
}
