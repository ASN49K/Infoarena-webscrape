#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100001
#define MMAX 500001
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m,x,y;
struct muchie {
    int x,y;
    bool viz;
}v[MMAX];
vector<int> c,l[NMAX];
stack<int> st;
int main() {
    fin>>n>>m;
    for (int i=1;i<=m;i++) {
        fin>>x>>y;
        v[i]={x,y,0};
        l[x].push_back(i);
        l[y].push_back(i);
    }
    for (int i=1;i<=n;i++)
        if (l[i].size()%2!=0) {
            fout<<-1;
            return 0;
        }
    st.push(1);
    while (!st.empty()) {
        int nod=st.top();
        bool ok=0;
        while (!l[nod].empty()) {
            int mc=l[nod].back();
            l[nod].pop_back();
            if (v[mc].viz==0) {
                int vec=v[mc].x;
                if (vec==nod)
                    vec=v[mc].y;
                st.push(vec);
                v[mc].viz=1;
                ok=1;
                break;
            }
        }
        if (ok==0) {
            c.push_back(nod);
            st.pop();
        }
    }
    if (c.size()-1!=m)
        fout<<-1;
    else
        for (int i=0;i<c.size()-1;i++)
            fout<<c[i]<<" ";
    return 0;
}
