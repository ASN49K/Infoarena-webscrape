#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>


using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
int fr[5000001];
stack<int> s;
vector<int> x[100101];
vector<int>afis;

bool ver(int n)
{
    for (int i = 1; i <= n; ++i)
    {
        if (fr[i] % 2 == 1)
            return 0;
    }
    return 1;
}

int main()
{
    int n, m, z = 0, a, b, nod, nod_nou, i;
    f >> n >> m;
    for (i = 1; i <= m; ++i)
    {
        f >> a >> b;
        x[a].push_back(b);
        x[b].push_back(a);
        fr[a]++;
        fr[b]++;
    }
    if (ver(n) == 1)
    {
        s.push(1);
        while (!s.empty())
        {
            nod = s.top();
           if (!x[nod].empty())
            {
                nod_nou = x[nod].back();
                s.push(nod_nou);
                x[nod].pop_back();

                x[nod_nou].erase(find(x[nod_nou].begin(), x[nod_nou].end(), nod));
            }
            else
            {
                afis.push_back(s.top());
                s.pop();
            }
        }
        for(int i=0;i<afis.size()-1;i++)
            g << afis[i]<< " ";
    }
    else
        g << -1;
    return 0;
}
