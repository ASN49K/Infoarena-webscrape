#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
typedef long long ll;
int n,m;
vector <int> v[100005];
vector <int> ciclu;
map <pair<int,int>,int> f;
void euler(int nod)
{
    for(auto x:v[nod])
    if(f[{nod,x}])
    {
        f[{nod,x}]--;
        f[{x,nod}]--;
        euler(x);
    }
    ciclu.push_back(nod);
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        f[{x,y}]++;
        v[y].push_back(x);
        f[{y,x}]++;
    }
    euler(1);
    for(int i=0;i<ciclu.size()-1;i++)
        fout<<ciclu[i]<<' ';
    return 0;
}
