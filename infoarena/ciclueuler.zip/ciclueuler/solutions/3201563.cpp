#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
typedef long long ll;
int n,m;
struct date
{
    int x,id;
};
int used[100005];
bool f[500005];
vector <date> v[100005];
vector <int> ciclu;
void euler(int nod)
{
    while(v[nod].size()>0)
        {
            date vec=v[nod].back();
            v[nod].pop_back();
        if(f[vec.id]==0)
        {
            f[vec.id]=1;
            used[nod]++;
            used[vec.x]++;
            euler(vec.x);
        }
        }
    ciclu.push_back(nod);
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(v[i].size()%2==1)
    {
        fout<<"-1";
        return 0;
    }
    euler(1);
    for(int i=0;i<ciclu.size()-1;i++)
        fout<<ciclu[i]<<' ';
    return 0;
}
