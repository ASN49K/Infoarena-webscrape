#include <bits/stdc++.h>

using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

#define int long long

const int NMAX = 6e5 + 5;

int n, m;

vector <pair<int, int>> v[NMAX];

bitset <NMAX> visited;

vector <int> path;

void dfs1(int nod)
{
    visited[nod] = true;

    for(auto & i : v[nod])
    {
        if(visited[i.first]) continue;

        dfs1(i.first);
    }
}

inline bool check()
{
    dfs1(1);

    for(int i = 1; i <= n; i ++)
    {
        if(visited[i] == false)
        {
            return false;
        }
    }

    visited &= 0;

    for(int i = 1; i <= n; i ++)
    {
        if(v[i].size() % 2)
        {
            return false;
        }
    }

    return true;
}

void dfs(int nod)
{
    while(!v[nod].empty())
    {
        int x = v[nod].back().first;
        int y = v[nod].back().second;

        v[nod].pop_back();

        if(visited[y]) continue;

        visited[y] = true;

        dfs(x);
    }

    path.push_back(nod);
}

int32_t main()
{

    //ios_base :: sync_with_stdio(false);
    //cin.tie(0);

    f >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        f >> x >> y;

        v[x].push_back({y, i});
        v[y].push_back({x, i});
    }

    if(check() == false)
    {
        g << -1;

        return 0;
    }

    dfs(1);

    path.pop_back();

    for(int i = 1; i <= m; i ++)
    {
        if(visited[i] == false)
        {
            g << -1;
            return 0;
        }
    }

    for(auto & i : path)
    {
        g << i << " ";
    }

    return 0;
}
