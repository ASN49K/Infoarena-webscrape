#include <bits/stdc++.h>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int u,v,n,m,nr,G[1005][1005],Q[500005];

void euler (int x)
{
    for (int i=1; i<=n; i++ )
        if ( G[x][i] )
        {
            G[x][i]=0;
            G[i][x]=0;
            euler(i);
        }
    Q[++nr]=x;
}

int main()
{
    f >> n >> m;
    for (int i=1; i<=m; i++ )
    {
        f >> u >> v;
        G[u][v]=1;
        G[v][u]=1;
    }
    euler(1);
    if ( nr==0 )
        g << -1;
    else for (int i=nr; i>=1; i-- )
        g << Q[i] << " ";
    return 0;
}
