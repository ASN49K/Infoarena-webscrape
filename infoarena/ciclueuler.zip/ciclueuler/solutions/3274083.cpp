#include <fstream>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

int n, m, t[4][1000000], start[101], eu[101], e;
int st[5001],varf;

void citire()
{
    int x, y, k=0;
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y;
        k++;
        t[0][k]=x;
        t[1][k]=start[y];
        start[y]=k;
        t[3][k]=k+1;
        k++;
        t[0][k]=y;
        t[1][k]=start[x];
        start[x]=k;
        t[3][k]=k-1;
    }
}

void dfs()
{
    int man, ok=0;
    varf=1;
    st[varf]=1;
    while(varf!=0)
    {
        int ok=0;
        man=start[st[varf]];
        while(man)
        {
            if(t[2][man]==0)
            {
                start[st[varf]]=t[1][man];
                st[++varf]=t[0][man];
                t[2][man]=1;
                t[2][t[3][man]]=1;
                ok=1;
                break;
            }
            man=t[1][man];
        }
        if(ok==0)
        {
            if(varf>1)
                eu[++e]=st[varf];
            varf--;
        }

    }
}

void afisare()
{
    for(int i=1; i<=e; i++)
        out<<eu[i]<<" ";
}

int main()
{
    citire();
    dfs();
    afisare();
    return 0;
}
