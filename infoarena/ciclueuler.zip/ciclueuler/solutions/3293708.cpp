#include <fstream>
#include <stack>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");

const int N = 1e5;
int f[N + 1];

bool viz[N + 1];

vector <pair <int, int> > g[N + 1];

vector <int> sol;

int n, m, x, y;

stack <int> s;

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; ++i)
    {
        cin >> x >> y;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
        f[x]++;
        f[y]++;
    }
    for (int i = 1; i <= n; ++i)
        if (f[i] & 1)
        {
            cout << "-1\n";
            return 0;
        }
    s.push(1);
    while (!s.empty())
    {
        int x = s.top();
        if (!g[x].empty())
        {
            pair <int, int> nod = g[x].back();
            g[x].pop_back();
            if (!viz[nod.second])
                viz[nod.second] = 1, s.push(nod.first);
        }
        else
            sol.push_back(x), s.pop();
    }
    reverse (sol.begin(), sol.end());
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
