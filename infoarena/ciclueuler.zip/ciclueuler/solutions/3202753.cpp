#include <fstream>
#include <stack>
#include<vector>
#define NMAX 100002
#define MMAX 500002
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
struct varf
{
    int x,nr;
}; //x -vf adiacent ; nr-nr muchiei corespunzatoare
vector<varf>G[NMAX];
int n,m,d[NMAX];
bool uz[MMAX]; //1-utilizata pe ciclu
stack<int>S;
bool eulerian;
void citire();
int grade_pare();
void euler(int start);
int main()
{
    int i;
    citire();
    int start=grade_pare();
    if(!start)
        fout<<-1;
    else
    {
        euler(start);
        eulerian=1;
        for(i=1; i<=m && eulerian; i++)
            if(!uz[i]) eulerian=0;
        if(!eulerian)
        {
            fout.close();
            fout.open("ciclueuler.out");
            fout<<-1;
        }
    }
    return 0;
}
void citire()
{
    int i,x,y;
    varf vf;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        //y intra in lista de adi a lui x
        vf.x=y;
        vf.nr=i;
        G[x].push_back(vf);
        //x intra in lista de adi a lui y
        vf.x=x;
        vf.nr=i;
        G[y].push_back(vf);
        d[x]++;
        d[y]++;
    }
}
int grade_pare()
{
    int i,start;
    //returneaza 0 daca nu toate gr sunt pare
    //daca toate sunt pare returneaza indicele unui vf care nu e izolat
    for(i=1; i<=n; i++)
    {
        if(d[i]%2) return 0;
        if(d[i]) start=i;
    }
    return start;
}
void euler(int start)
{
    varf vfad; int vf;
    S.push(start);
    //fout<<start<<' ';
    while(!S.empty())
    {
        vf=S.top();
        //aleg un vf adiacent cu vf
        if(!G[vf].empty())
        {
            vfad=G[vf][G[vf].size()-1];
            if(!uz[vfad.nr])//muchie neutlizata
            {
                uz[vfad.nr]=1;
                S.push(vfad.x);
            }
            G[vf].pop_back();
        }
        else{fout<<vf<<' '; S.pop();}
    }
}

