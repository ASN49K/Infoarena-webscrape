#include <bits/stdc++.h>

using namespace std;

bitset <500001> edges;
vector <pair <int, int>> graph[100001];
vector <int> euler;
int grad[100001];

void dfs (int node) {
    while (graph[node].size()) {
        if (edges[graph[node].back().second]) {
            graph[node].pop_back();
            continue;
        }
        edges[graph[node].back().second] = 1;
        dfs (graph[node].back().first);
    }
    euler.push_back(node);
}

int main() {
    ifstream fin ("ciclueuler.in");
    ofstream fout ("ciclueuler.out");

    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        fin >> x >> y;
        graph[x].push_back({y, i});
        graph[y].push_back({x, i});
        grad[x] ^= 1;
        grad[y] ^= 1;
    }
    for (int i =1 ; i <= n; ++i) {
        if (grad[i]) {
            fout << -1;
            return 0;
        }
    }
    dfs (1);
    euler.pop_back();
    if (euler.size() != m) {
        cout << -1;
        return 0;
    }
    for (auto x : euler) {
        fout << x << ' ';
    }
}