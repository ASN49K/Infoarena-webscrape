#include <fstream>
#include <vector>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m;
struct muchie{
     int nod,ind;
};
int fr[500001];
vector<muchie> g[100001];
int st[500001];
vector<int> sol;
void euler(int nod){
   while(g[nod].size()>0){
       muchie vec=g[nod].back();
       g[nod].pop_back();
       if (fr[vec.ind]==0)
       {
           fr[vec.ind]=1;
           euler(vec.nod);
       }
   }
   sol.push_back(nod);
}
int main()
{
  fin>>n>>m;
  int x,y;
  for(int i=1;i<=m;i++){
      fin>>x>>y;
      g[x].push_back({y,i});
      g[y].push_back({x,i});
  }
int nr=0;
for(int i=1;i<=n;i++)
    if(g[i].size()%2!=0)
         {
             fout<<-1;
             return 0;
         }
euler(1);
  /*int k=1;
  st[k]=1;
  while(k>0){
      int nod=st[k];
      if(g[nod].size()>0){
            int ok=0;
        while(g[nod].size()>0) {
          muchie x=g[nod].back();
          g[nod].pop_back();
          if(fr[x.ind]==0)
          {
               ok=1;
              fr[x.ind]=1;
              st[++k]=x.nod;
              break;
          }
        }
         if(ok==0){
            sol.push_back(nod);
            k--;
         }

      }
      else{
            sol.push_back(nod);
          k--;
      }
  }*/
  if(sol.size()-1!=m){
    fout<<-1;
    return 0;
  }
  for(int i=0;i<sol.size()-1;i++)
       fout<<sol[i]<<" ";
    return 0;
}
