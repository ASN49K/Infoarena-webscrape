#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#define SZ(x) ((int) (x).size())
using namespace std;

const int MAX_NODES = 100005, MAX_EDGES = 500005;


vector<int> graph[MAX_NODES];


bool visitedEdge[MAX_EDGES];
int edgeStart[MAX_EDGES], edgeEnd[MAX_EDGES];

int main() {
    ifstream fin("ciclueuler.in");
    ofstream fout("ciclueuler.out");

    int numNodes, numEdges;
    fin >> numNodes >> numEdges;

   
    for (int i = 0; i < numEdges; ++i) {
        int node1, node2;
        fin >> node1 >> node2;


        graph[node1].push_back(i);
        graph[node2].push_back(i);

       
        edgeStart[i] = node1;
        edgeEnd[i] = node2;
    }

   
    for (int i = 1; i <= numNodes; ++i) {
        if (SZ(graph[i]) & 1) {
            fout << "-1\n";  
            return 0;
        }
    }

    vector<int> eulerianCycle;

    vector<int> nodeStack;
    nodeStack.push_back(1);  

    while (!nodeStack.empty()) {
        int currentNode = nodeStack.back();

        if (!graph[currentNode].empty()) {
           
            int edgeIdx = graph[currentNode].back();
            graph[currentNode].pop_back();

        
            if (!visitedEdge[edgeIdx]) {
                visitedEdge[edgeIdx] = true;

           
                int nextNode = (edgeStart[edgeIdx] == currentNode) ? edgeEnd[edgeIdx] : edgeStart[edgeIdx];

               
                nodeStack.push_back(nextNode);
            }
        } else {
            nodeStack.pop_back();

           
            eulerianCycle.push_back(currentNode);
        }
    }

   
    for (int i = 0; i < SZ(eulerianCycle) - 1; ++i) {
        fout << eulerianCycle[i] << ' ';
    }
    fout << '\n';  


    return 0;
}
