#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100001
#define MMAX 500001
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n,m,x,y,g[NMAX],p[NMAX];
bool viz[MMAX];
vector<pair<int,int>> l[NMAX];
stack<int> st;
vector<int> sol;
int main() {
    fin>>n>>m;
    for (int i=1;i<=m;i++) {
        fin>>x>>y;
        l[x].push_back({y,i});
        l[y].push_back({x,i});
        g[x]++;
        g[y]++;
    }
    for (int i=1;i<=n;i++)
        if (g[i]%2!=0) {
            fout<<-1;
            return 0;
        }
    st.push(1);
    while (!st.empty()) {
        int nod=st.top();
        if (g[nod]==0) {
            st.pop();
            sol.push_back(nod);
            continue;
        }
        for (int i=p[nod];i<l[nod].size();i++) {
            int vec=l[nod][i].first;
            int mch=l[nod][i].second;
            if (viz[mch]==0) {
                st.push(vec);
                viz[mch]=1;
                g[nod]--;
                g[vec]--;
                p[nod]=i+1;
                break;
            }
        }
    }
    for (int i=0;i<sol.size()-1;i++)
        fout<<sol[i]<<" ";
    return 0;
}
