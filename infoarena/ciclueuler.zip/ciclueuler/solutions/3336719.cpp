#include <bits/stdc++.h>

using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
const int nmax = 1e5+5;

vector<pair<int, int>> adj[nmax];
vector<int> ans;
int deg[nmax];
bool used_edge[500005]; 
int ptr[nmax]; 

int n, m;

bool toate_gradele_pare(int n) {
    for(int i = 1; i <= n; i++) {
        if(deg[i] % 2 != 0)
            return false;
    }
    return true;
}

void euler(int nod) {
   
    while(ptr[nod] < adj[nod].size()) {
        int i = ptr[nod];
        ptr[nod]++; 
        
        int vecin = adj[nod][i].first;
        int id_muchie = adj[nod][i].second;

        if(!used_edge[id_muchie]) {
            used_edge[id_muchie] = true; 
            euler(vecin);
        }
    }
    ans.push_back(nod);
}

int main() {
   
   f>> n >> m;
    
    for(int i = 0; i < m; i++) {
        int x, y;
     f>> x >> y;
        
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
        
        deg[x]++;
        deg[y]++;
    }

    
    if(!toate_gradele_pare(n)) {
        g<< -1;
        return 0;
    }

    euler(1);

   
        
    

    for(int i=0;i<ans.size()-1;i++)
    g<<ans[i]<<' ';
 

    return 0;
}