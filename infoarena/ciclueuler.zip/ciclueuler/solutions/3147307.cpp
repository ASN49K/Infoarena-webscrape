#include <stdio.h>

#include <vector>

const int MAXN = 1e5;
const int MAXM = 5e5;

std::vector<int> edges[MAXN];

int node_sum[MAXM];
bool viz[MAXM];

int ncyc;
int cycle[1 + MAXM];

void dfs( int u ){
  for( int e : edges[u] )
    if( !viz[e] ){
      viz[e] = true;
      dfs( node_sum[e] - u );
    }

  cycle[ncyc++] = u;
}

int main(){
  FILE *fin  = fopen( "ciclueuler.in",  "r" );
  FILE *fout = fopen( "ciclueuler.out", "w" );

  int n, m, i, a, b, parity_check;

  fscanf( fin, "%d%d", &n, &m );
  for( i = 0 ; i < m ; i++ ){
    fscanf( fin, "%d%d", &a, &b );
    a--;
    b--;

    node_sum[i] = a + b;
    edges[a].push_back( i );
    edges[b].push_back( i );
  }

  parity_check = true;
  for( i = 0 ; i < n ; i++ )
    if( ((int)edges[i].size()) & 1 )
      parity_check = false;

  if( !parity_check ){
    fputs( "-1\n", fout );
    fclose( fin );
    fclose( fout );
    return 0;
  }

  ncyc = 0;
  dfs( 0 );

  for( i = 1 ; i < ncyc ; i++ )
    fprintf( fout, "%d ", 1 + cycle[i] );
  fputc( '\n', fout );

  fclose( fin );
  fclose( fout );
  return 0;
}
