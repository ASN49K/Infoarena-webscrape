#include <fstream>
#include <vector>
#include <bitset>
#include <stack>

using namespace std;

const int N = 1e5;
const int M = 5e5;

struct muchie
{
    int x, y;
};

muchie e[M];
bitset <M> sters;
vector <int> a[N+1];
vector <int> ciclul;
stack <int> stiva;
int ultimul[N+1];

int celalalt(muchie m, int x)
{
    return (m.x + m.y - x);
}

void euler()
{
    stiva.push(e[0].x);
    while (!stiva.empty())
    {
        int x = stiva.top();
        int ind = -1;
        while (ultimul[x] < (int)a[x].size() && ind == - 1)
        {
            if (!sters[a[x][ultimul[x]]])
            {
                ind = a[x][ultimul[x]];
            }
            ultimul[x]++;
        }
        if (ind != -1)
        {
            int y = celalalt(e[ind], x);
            sters[ind] = 1;
            stiva.push(y);
        }
        else
        {
            stiva.pop();
            ciclul.push_back(x);
        }
    }
}

int main()
{
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        in >> e[i].x >> e[i].y;
        a[e[i].x].push_back(i);
        a[e[i].y].push_back(i);
    }
    euler();
    if (ciclul.size() != m + 1 || ciclul[0] != ciclul[ciclul.size()-1])
    {
        out << -1;
    }
    else
    {
        for (int i = 0; i < (int)ciclul.size() - 1; i++)
        {
            out << ciclul[i] << " ";
        }
    }
    in.close();
    out.close();
    return 0;
}
