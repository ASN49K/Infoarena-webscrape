#include<bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

const int NMAX = 1e5 + 5, INF = 1e9 + 7, MMAX = 5e5 + 5;
int n, m, sz[NMAX];
bool viz[MMAX];
vector<int> sol;
vector<pair<int, int>> v[NMAX];

void dfs(int node)
{
    int u, muchie_nr;
    while(!v[node].empty())
    {
        u = v[node].back().first, muchie_nr = v[node].back().second;

        v[node].pop_back();
        if(!viz[muchie_nr])
        {
            viz[muchie_nr] = true;
            dfs(u);
        }
    }

    sol.push_back(node);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);

    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        v[a].push_back({b, i});
        v[b].push_back({a, i});
        sz[a]++;sz[b]++;
    }

    bool ok = true;
    for(int i = 1; i <= m; i++)
    {
        if(sz[i] % 2)
        {
            ok = false;
            break;
        }
    }

    if(!ok)
    {
        cout << "-1";
        return 0;
    }

    dfs(1);

    for(int i = 0; i < sol.size() - 1; i++)
        cout << sol[i] << " ";
}