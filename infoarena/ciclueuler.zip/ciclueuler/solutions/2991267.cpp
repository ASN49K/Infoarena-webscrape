#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
const int NMAX=100005;

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

vector <int> v[NMAX], ans;
unordered_map< int, int> f;
int n, m;

void dfs(int);

int main()
{
    int i, a, b, nr;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        if(a>b) swap(a, b);
        nr=a*n+b;
        f[nr]++;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            fout<<-1<<'\n';
            return 0;
        }
    }
    dfs(1);
    reverse(ans.begin(), ans.end());
    for(i=0; i<int(ans.size())-1; i++) fout<<ans[i]<<' ';
    return 0;
}

void dfs(int nod)
{
    int a, b, nr;
    for(auto i:v[nod])
    {
        a=nod; b=i;
        if(a>b) swap(a, b);
        nr=a*n+b;
        if(f[nr])
        {
            f[nr]--;
            dfs(i);
        }
    }
    ans.push_back(nod);
}
