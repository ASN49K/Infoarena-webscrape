#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;
struct str {
    int nod, muc;
};
vector<str> L[100010];
int grad[100010];
int poz[100010];
int st[500010];
int sol[500010];
bool viz[500010];
int n, m, x, y, vf, nr;

int main() {
    ifstream fin("ciclueuler.in");
    ofstream fout("ciclueuler.out");
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        L[x].push_back({y, i});
        L[y].push_back({x, i});
        grad[x]++;
        grad[y]++;
    }
    for (int i = 1; i <= n; i++) {
        if (grad[i] % 2 != 0) {
            fout << -1;
            return 0;
        }
    }
    st[++vf] = 1;
    while (vf > 0) {
        int crt = st[vf];
        if (grad[crt] == 0) {
            vf--;
            sol[++nr] = crt;
            continue;
        }
        for (int i = poz[crt]; i < L[crt].size(); i++) {
            str vec = L[crt][i];
            if (!viz[vec.muc]) {
                st[++vf] = vec.nod;
                grad[crt]--;
                grad[vec.nod]--;
                viz[vec.muc] = true;
                poz[crt] = i + 1;
                break;
            }
        }
    }
    for (int i = 1; i <= nr; i++) {
        fout << sol[i] << " ";
    }
    return 0;
}