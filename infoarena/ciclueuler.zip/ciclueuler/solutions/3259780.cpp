#include <fstream>
#include <stack>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");

const int M = 5e5;

const int N = 1e5;
bool f[N + 1];

bool viz[M + 1];

vector <pair <int, int> > g[N + 1];

vector <int> rez;

stack <int> s;

int n, m, x, y;

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; ++i)
    {
        cin >> x >> y;
        f[x] ^= 1;
        f[y] ^= 1;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
    }
    for (int i = 1; i <= n; ++i)
        if (f[i])
        {
            cout << "-1\n";
            return 0;
        }
    s.push(1);
    while (!s.empty())
    {
        int x = s.top();
        if (!g[x].empty())
        {
            int node = g[x].back().first;
            int muchie = g[x].back().second;
            g[x].pop_back();
            if (!viz[muchie])
                viz[muchie] = 1, s.push(node);
        }
        else
            rez.push_back(x), s.pop();
    }
    reverse (rez.begin(), rez.end());
    for (auto it : rez)
        cout << it <<  ' ';
    return 0;

}
