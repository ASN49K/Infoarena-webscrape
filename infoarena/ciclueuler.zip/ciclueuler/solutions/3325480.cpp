#include <fstream>
#include <vector>
#include <bitset>

#define NMAX 100002
#define MMAX 500002
using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m;
int nxt, nr;

vector<vector<pair<int, int>>> graf;
bitset<MMAX>muchie; //muchie[i] = 1 daca a fost vizitat si 0 altfel
int unde[NMAX]; //unde[i];  unde am ramas cu verificarea muchiilor nodului i

void citire();
void Euler(int nod);

int main()
{
    citire();
    Euler(1);
    return 0;
}

void Euler(int nod)
{
 int i;
 for(i = unde[nod]; i < graf[nod].size(); i++)
    {
     nxt = graf[nod][i].first;
     nr = graf[nod][i].second;
     if(!muchie[nr]) //daca nu am mai fost pe aceasta muchie
     {
        unde[nod] = i + 1;
        muchie[nr] = 1;
        Euler(nxt);
     }
    }
 fout<<nod<<' ';
}

void citire()
{
 int i, x, y;
 fin>>n>>m;
 graf.resize(n + 2);
 for(i = 1; i <= m; i++)
 {
     fin>>x>>y;
     graf[x].push_back({y, i});
     graf[y].push_back({x, i});
 }
}
