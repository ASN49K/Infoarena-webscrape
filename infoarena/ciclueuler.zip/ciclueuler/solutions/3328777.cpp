#include <bits/stdc++.h>

using namespace std;

const int NMAX=1e5;
int n, m;
vector<int> g[NMAX+1], ans;
map<pair<int, int>, int> ramase;
int grad[NMAX+1];

inline void dfs(int nod)
{
    for(int to:g[nod])
    {
        ramase[{nod, to}]--;
        ramase[{to, nod}]--;
        if(ramase[{nod, to}]<0)continue;
        dfs(to);
    }
    ans.push_back(nod);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
        ++grad[x], ++grad[y];

        ++ramase[{x, y}];
        ++ramase[{y, x}];
    }
    for(int i=1; i<=n; i++)
        if(grad[i]%2==1)
        {
            cout<<-1;
            return 0;
        }
    dfs(1);
    for(auto &x:ans)cout<<x<<' ';
    return 0;
}
