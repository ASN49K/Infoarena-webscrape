#include <bits/stdc++.h>

std :: ifstream in ("ciclueuler.in");

std :: ofstream out ("ciclueuler.out");

const int NMAX = 1e5 + 5;

int n;

int m;

int x;

int y;

int cnt;

std :: vector <std :: pair <int, int>> v[NMAX];

std :: bitset <NMAX> visited;

std :: vector <int> path;

void dfs(int nod)
{
    while(!v[nod].empty())
    {
        x = v[nod].back().first;

        y = v[nod].back().second;

        v[nod].pop_back();

        if(visited[y] == false)
        {
            visited[y] = true;

            dfs(x);
        }
    }

    path.push_back(nod);
}

int main()
{

    in >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        in >> x >> y;

        v[x].push_back(std :: make_pair(y, ++cnt));

        v[y].push_back(std :: make_pair(x, cnt));
    }

    dfs(1);

    path.pop_back();

    for(int i : path)
    {
        out << i << " ";
    }

    return 0;
}
