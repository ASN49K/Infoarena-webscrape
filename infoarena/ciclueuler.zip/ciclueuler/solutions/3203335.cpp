#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 666013;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int nmax = 1e5;
multiset<int> g[nmax + 5];

void add(int u, int v) {
    g[u].insert(v);
    g[v].insert(u);
}

void remove(int u, int v) {
    g[u].erase(g[u].find(v));
    g[v].erase(g[v].find(u));
}

int n, m;
vector<int> path;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int u, v;
        fin >> u >> v;
        add(u, v);
    }
    path.reserve(m);
    stack<int> st;
    st.push(1);
    while (st.size()) {
        int u = st.top();
        if (g[u].empty()) {
            fout << u << sp;
            st.pop();
        }
        else {
            int v = *g[u].begin();
            remove(u, v);
            st.push(v);
        }
    }
}