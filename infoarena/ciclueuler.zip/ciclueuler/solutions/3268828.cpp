#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <climits>
#include <sstream>
#include <set>
#include <algorithm>
using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m;

vector<vector<int>> la;
vector<int> grade;

void Read()
{
    f >> n >> m;

    la.resize(n + 1);
    grade.resize(n + 1, 0);

    // Read the adjacency list from input
    for (int i = 1; i <= m; ++i)
    {
        int x, y;
        f >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
        grade[x]++;
        grade[y]++;
    }
    for (int i = 1; i <= n; i++)
        if (grade[i] % 2 != 0)
        {
            g << -1;
            exit(0);
        }
}
bool are_all_empty(const std::vector<std::vector<int>> &la)
{
    // Find the first vector that is not empty
    auto it = std::find_if(la.begin(), la.end(), [](const std::vector<int> &v)
                           {
                               return !v.empty(); // Check if the vector is not empty
                           });

    // If we find such a vector, return false (not all vectors are empty)
    return it == la.end(); // If no non-empty vector is found, return true (all are empty)
}

void fuziune_cicluri(vector<int> &c, vector<int> &c_prim)
{
    if (c.empty())
    {
        c.insert(c.begin(), c_prim.begin(), c_prim.end());
        return;
    }

    auto it = find(c.begin(), c.end(), c_prim[0]);
    if (it != c.end())
        c.insert(it, c_prim.begin(), c_prim.end() - 1);
}

int main()
{
    Read();
    int x = 1, vi = 1;
    vector<int> c, c_prim;
    int remaining_edges = m;
    while (remaining_edges > 0)
    {
        for (int i = 1; i <= n; i++)
            if (!la[i].empty())
            {
                x = vi = i;
                c_prim.clear();
                break;
            }

        do
        {
            // g << vi << " ";
            c_prim.push_back(vi);

            if (!la[vi].empty())
            {
                int vecin = *la[vi].begin();

                la[vi].erase(find(la[vi].begin(), la[vi].end(), vecin));

                la[vecin].erase(find(la[vecin].begin(), la[vecin].end(), vi));
                remaining_edges--;

                vi = vecin;
            }

        } while (x != vi);
        c_prim.push_back(x);
        fuziune_cicluri(c, c_prim);
    }
    for (auto &i : c)
    {
        g << i << " ";
    }

    return 0;
}