#include <bits/stdc++.h>

using namespace std;

vector <pair <int, int>> graph[100005];
int currentEdge[100005]; // o sa imi spuna care este urmatoarea muchie de parcurs pentru un nod
int grad[100005];
bool visited[100005];
bool visitedEdges[100005];
vector <int> cycle;

void buildVisited(int node) {
    visited[node] = 1;
    for (auto x : graph[node]) {
        if (visited[x.first]) continue;
        buildVisited(x.first);
    }
}
//            |
// 1: 4 5 3 4 6 7 2 5 7 3
// 1 3 - 1
// 1 4 - 2
// 2 5 - 3
// 1 6 - 4
void buildEulerCycle(int node) {
    while (currentEdge[node] < graph[node].size()) {
        // Daca muchia actuala a fost vizitata deja intr-o parcurgere anterioara
        // Trec la urmatoare muchie
        if (visitedEdges[graph[node][currentEdge[node]].second]) {
            currentEdge[node] += 1;
        } else {
            // vizitam muchia actuala
            visitedEdges[graph[node][currentEdge[node]].second] = true;
            int neighbour = graph[node][currentEdge[node]].first;
            currentEdge[node] += 1;
            buildEulerCycle(neighbour);
        }
    }
    cycle.push_back(node);
}

int main()
{
    ifstream fin ("ciclueuler.in");
    ofstream fout ("ciclueuler.out");
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        fin >> x >> y;
        graph[x].push_back({y, i});
        graph[y].push_back({x, i});
    }
    for (int i = 1; i <= n; ++i) {
        if (graph[i].size() % 2) {
            fout << -1;
            return 0;
        }
    }
    int compCount = 0;
    for (int i = 1; i <= n; ++i) {
        if (visited[i]) continue;
        compCount += 1;
        buildVisited(i);
    }
    if (compCount > 1) {
        fout << -1;
        return 0;
    }
    buildEulerCycle(1);
    // ca sa elimin ultima insertie dam un pop back
    cycle.pop_back();
    for (auto x : cycle) {
        fout << x << ' ';
    }
    return 0;
}