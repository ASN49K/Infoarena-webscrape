#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

long long n, m;
vector<vector<pair<int,int>>> adj;
vector<int> visited, grad, visM, sol;
//verific sa fie fiecare nod visitat si sa nu aiba grad impar
void dfs(int nod)
{
    if(visited[nod]) return;
    visited[nod] = true;
    for(auto [neigh, i] : adj[nod])
    {
        dfs(neigh);
    }
}

void euler(int nod)
{
    while(adj[nod].size() > 0)
    {
        int next = adj[nod].back().first;
        int next_edge = adj[nod].back().second;
        adj[nod].pop_back();
        if(!visM[next_edge])
        {
            visM[next_edge] = true;
            euler(next);
        }
    }
    sol.push_back(nod);
}

void solve()
{
    int i;
    fin >> n >> m;
    adj.resize(n+1);
    visited.resize(n+1, false);
    grad.resize(n+1);
    visM.resize(m+1, false);

    for(i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        grad[x]++;
        grad[y]++;
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
    }
    dfs(1);
    for(i = 1; i <= n; i++)
        if(!visited[i] || grad[i] % 2 == 1)
        {
            fout << "-1";
            return;
        }
    euler(1);
    sol.pop_back();
    for(int a : sol)
        fout << a << " ";
    return;
}

int main()
{

    long long t;
    solve();

    return 0;
}
