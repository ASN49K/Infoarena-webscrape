#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100015
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector<pair<int, int>> V[NMAX];

bool isEulerian(vector<pair<int, int>> V[NMAX], int n){
    for (int i = 1; i <= n; i++){
        if(V[i].size() % 2 != 0)
            return false;
    }
    return true;
}
bool usedEdge[NMAX*5];
vector<int> eulerianCyclePath(vector<pair<int, int>> V[NMAX], int n){
    vector<int> ans;
    stack<int> stack;
    stack.push(1);
    while(!stack.empty()){
        int node = stack.top();
        while(!V[node].empty() && usedEdge[V[node].back().second]){
            V[node].pop_back();
        }
        if(V[node].empty()){
            ans.push_back(node);
            stack.pop();
        }
        else{
            stack.push(V[node].back().first);
            usedEdge[V[node].back().second] = true;
        }
    }
    return ans;
}
int main(){
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= m; i++){
        int u, v;
        fin >> u >> v;
        V[u].push_back({v, i});
        V[v].push_back({u, i});
    }
    if(!isEulerian(V, n)) {
        fout << "Nu este eulerian";
        return 0;
    }
    vector<int> ans = eulerianCyclePath(V, n);
    for(int i = 0; i < ans.size()-1; i++){
        fout << ans[i] << ' ';
    }
    return 0;
}