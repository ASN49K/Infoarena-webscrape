#include <vector>
#include <iostream>
#include <utility>
#include <functional>
#include <fstream>
using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");

struct edge{
    edge(int a, int b){
        v = a;
        id = b;
    }
    int v;
    int id;
};

int main() {
    int n, m; 
    in >> n >> m;
    int cnt_activ = 0;
    int cnt_deg_imp = 0;
    vector<bool> visited(m, 0);
    vector<bool> active(n, 0);
    vector<vector<edge>> g(n);
    vector<int> deg(n, 0);
    vector<int> p(n, -1);
    vector<int> dim(n, 1);
    function<int(int)> find = [&](int x) {
        if (p[x] == -1)
            return x;
        return p[x] = find(p[x]);
    };
    auto unite = [&](int x, int y) {
        int px = find(x);
        int py = find(y);
        if (dim[px] > dim[py])
            swap(px, py);
        if (px == py)
            return;
        p[px] = py;
        dim[py] = dim[px]+dim[py];  
    }; 

    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        x--; y--;
        if (!active[x]) {
            active[x] = true;
            cnt_activ++;
        }
        if (!active[y]) {
            active[y] = true;
            cnt_activ++;
        }
        g[x].push_back(edge(y, i));
        deg[x]++;
        g[y].push_back(edge(x, i));
        deg[y]++;
        unite(x, y);
        if (deg[x]%2 == 0) 
            cnt_deg_imp--;
        else 
            cnt_deg_imp++;
        
        if (deg[y]%2 == 0) 
            cnt_deg_imp--;
        else 
            cnt_deg_imp++;
    }
    if (cnt_deg_imp != 0 && cnt_deg_imp != 2) {
        //cout << "Imposibil. Nr de noduri cu grad impar inacceptabil";
        out << -1;
        return 0;
    }
    for (int i = 0; i < n; i++) {
        if (active[i]) {
            if (dim[find(i)] != cnt_activ) {
                // cout << "Imposibil. Graful nu e conex";
                out << -1;
                return 0;
            }
            break;
        }
    }
    int start_node = -1;
    if (cnt_deg_imp == 2) {
        for (int i = 0; i < n; i++) {
            if (deg[i] % 2 != 0) {
                start_node = i;
                break;
            }
        }
    }
    else {
        for (int i = 0; i < n; i++) {
            if (active[i]) {
                start_node = i;
                break;
            }
        }
    }
    if (start_node == -1) {
        // cout << "Graful nu are muchii";
        out << -1;
        return 0;
    }
    vector<int> ptr(n, 0);
    vector<int> rez;
    function<void(int)> dfs = [&](int u) {
        for (int &i = ptr[u]; i < g[u].size(); i++) {
            auto& e = g[u][i]; 
            if (visited[e.id])
                continue;
            visited[e.id] = true;
            dfs(e.v);
        }
        rez.push_back(u);
    };
    dfs(start_node);
    for (int i = rez.size() - 1; i >=0; i--)
        out << rez[i]+1 << " ";
}