#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m;

vector <int> ans;

vector <pair <int, int> > a[100001];

bitset <500001> viz;

inline void euler(int nod)
{
    for (auto it : a[nod]) {
        if (!viz[it.second]) {
            viz[it.second] = 1;
            euler(it.first);
        }
    }

    ans.push_back(nod);
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= m; ++i) {
        int x, y;

        f >> x >> y;

        a[x].push_back({y, i});
        a[y].push_back({x, i});
    }

    euler(1);

    for (int i = 0; i < (int) ans.size() - 1; ++i) {
        g << ans[i] << ' ';
    }

    return 0;
}
