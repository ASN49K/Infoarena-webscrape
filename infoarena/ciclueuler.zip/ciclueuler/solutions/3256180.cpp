#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
struct Muchie {
    int y, idx;
};
int n, m, i, imp, p;
vector<Muchie> g[100002];
vector<int> r;
bool fr[500002];

static inline void Dfs(int nod) {
    while(!g[nod].empty()) {
        int urm = g[nod].back().y;
        int idx = g[nod].back().idx;

        g[nod].pop_back();

        if(!fr[idx]) {
            fr[idx] = true;
            Dfs(urm);
        }
    }

    r.push_back(nod);
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
    }

    p = 1;
    for(i = 1; i <= n; i++) {
        if(g[i].size() % 2 == 1) {
            imp++;
            p = i;
        }
    }

    if(imp != 0 && imp != 2) {
        fout << "-1";
        return 0;
    }

    Dfs(p);
    for(int i = 0; i < r.size() - 1; i++) fout << r[i] << " ";

    return 0;
}
