#include<bits/stdc++.h>
using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int dim = 100002;
int n, m, grad[dim];
bool viz[dim * 5];
struct elem
{
    int nod, ind;
};
vector<elem>a[dim];

void dfs (int x)
{
    while (!a[x].empty())
    {
        elem y = a[x].back();
        if (!viz[y.ind]) ///daca muchia nu a fost stearsa
        {
            ///continui parcurgerea cu back-ul din y
            int urm = y.nod;
            fout << urm << ' ';
            viz[y.ind] = 1;
            a[x].pop_back();
            dfs (urm);
        }
        else    a[x].pop_back();
    }

}

int main ()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        grad[x] ++, grad[y]++;
        a[x].push_back({y,i});
        a[y].push_back({x,i});
    }
    ///cum verific ca este conex?
    for (int i = 1; i <= n; i++)
        if (grad[i]%2==1)
    {
        fout << -1;
        return 0;
    }

    //fout << 1 << ' ';
    dfs(1);
}

