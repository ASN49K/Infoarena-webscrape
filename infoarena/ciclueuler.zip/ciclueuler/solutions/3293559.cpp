#include<bits/stdc++.h>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");


int main()
{
vector<int>raspuns;
int n,m,x,y;

in>>n>>m;
vector<stack<int>>muchii(n+1,stack<int>());
int from[m+1],to[m+1];
vector<bool>parcurs(m+1,0);
for(int i=1;i<=m;i++)
{in>>x>>y;
   from[i]=x;
   to[i]=y;
   muchii[x].push(i);
   muchii[y].push(i);
}
stack<int>lista;
lista.push(1);
while(!lista.empty())
{int nod=lista.top();
if(!muchii[nod].empty())
{int muchie=muchii[nod].top();

if(!parcurs[muchie])
{parcurs[muchie]=1;

 int other;
 if(to[muchie]==nod)
 other=from[muchie];
 else
 other=to[muchie];
 lista.push(other);
}
else
muchii[nod].pop();
}
else
{raspuns.push_back(nod);
    lista.pop();
}}
int marime=raspuns.size()-2;
for(int i=0;i<=marime;i++)
out<<raspuns[i]<<" ";



}
