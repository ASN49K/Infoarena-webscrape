#include <bits/stdc++.h>
using namespace std;

#define pb push_back

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

const int N = 1e5 + 1;

int n, m, u[5 * N];
vector<int> G[N], s, r;
vector<pair<int, int>> muchii;

void read(), check(), euler();

int main()
{
    read();
    check();
    euler();
    for (int i = 0; i < r.size() - 1; i++) g << r[i] << ' ';

    return 0;
}

void read(){
    f >> n >> m;
    int a, b;
    muchii.pb({0, 0});
    for (int i = 1; i <= m; i++){
        f >> a >> b;
        G[a].pb(i); G[b].pb(i);
        muchii.pb({a, b});
    }
}
void check(){
    for (int i = 1; i <= n; i++)
        if (G[i].size() % 2){
            g << -1; exit(0);
        }
}
void euler(){
    s.pb(1);
    while (!s.empty()){
        int nod = s.back();
        if (!G[nod].empty()){
            int x = G[nod].back(); G[nod].pop_back();
            if (!u[x]){
                u[x] = 1;
                int y = (nod == muchii[x].first ? muchii[x].second : muchii[x].first);
                s.pb(y);
            }
        }
        else{s.pop_back(); r.pb(nod);}
    }
}


/*
euler (nod v)
      cat timp (v are vecini)
          w = un vecin aleator al lui v
          sterge_muchie (v, w)
          euler (w)
      sfarsit cat timp
      adauga v la ciclu
*/
