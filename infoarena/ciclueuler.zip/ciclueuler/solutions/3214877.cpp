#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
///concurs
///restmare

int a[500005], b[500005];
int d[100005];
int sol[500005], poz[100005], top;
bitset<500005> v;
vector<int> L[100005];
int n, m;

bool Verif()
{
    int i;
    for(i=1; i<=n; i++)
        if(d[i] % 2 != 0) return false;
    return true;
}

void DFS(int k)
{
    while(poz[k] < L[k].size())
    {
        int i = L[k][poz[k]];
        poz[k]++;
        if(v[i] == 0)
        {
            v[i] = 1;
            DFS(a[i] + b[i] - k);
        }
    }
    sol[++top] = k;
}

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i;
    fin >> n >> m;
    for(i=1;i<=m;i++)
    {
        fin >> a[i] >> b[i];
        d[a[i]]++;
        d[b[i]]++;
        L[a[i]].push_back(i);
        L[b[i]].push_back(i);
    }
    if(Verif() == false)
    {
        fout << "-1";
        return 0;
    }
    for(i=1;i<=n && d[i] == 0;i++)
        ;
    DFS(i);
    for(i=1;i<top;i++)
        fout << sol[i] << " ";
    fin.close();
    fout.close();
    return 0;
}
