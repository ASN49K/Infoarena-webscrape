#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
const int maxn = 500005;
vector <pair <int, int> > v[maxn];
bitset <maxn> viz;
vector <int> sol;

void dfs(int nod)
{
    while(!v[nod].empty())
    {
        pair <int, int> act = v[nod].back();
        v[nod].pop_back();
        if(!viz[act.second])
        {
            viz[act.second] = 1;
            dfs(act.first);
        }
    }
    sol.push_back(nod);
}

int main()
{
    int n, m;
    in >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        v[x].push_back(make_pair(y, i));
        v[y].push_back(make_pair(x, i));
    }
    for(int i = 1; i <= n; i++)
    {
        if(v[i].size() % 2 == 1)
        {
            out << -1 << "\n";
            return 0;
        }
    }
    dfs(1);
    for(auto it : sol)
        out << it << " ";
    out << "\n";
    return 0;
}
