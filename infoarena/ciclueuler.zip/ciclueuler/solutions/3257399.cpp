#include <fstream>
#include <vector>
using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

int curent[100001];
int viz[100001];
int vizn[500001];
vector<pair<int,int>> v[100001];
vector<int> rasp;

void dfs_comp(int nod){
    int i;
    viz[nod]=1;
    for(i=0;i<v[nod].size();i++){
        if(!viz[v[nod][i].first]){
            dfs_comp(v[nod][i].first);
        }
    }
}

void dfs_euler(int nod){
    while(curent[nod]<v[nod].size()){
        if(!vizn[v[nod][curent[nod]].second]){
            vizn[v[nod][curent[nod]].second]=1;
            dfs_euler(v[nod][curent[nod]].first);
        }
        curent[nod]++;
    }
    rasp.push_back(nod);
}

int main()
{
    int n,m,i,j,a,b,cnt=0;
    cin>>n>>m;
    for(i=1;i<=m;i++){
        cin>>a>>b;
        v[a].push_back({b,i});
        v[b].push_back({a,i});
    }
    for(i=1;i<=n;i++){
        if(v[i].size()%2){
            cout<<"-1";return 0;
        }
    }
    for(i=1;i<=n;i++){
        if(!viz[i]){
            if(v[i].size()) cnt++;
            dfs_comp(i);
        }
    }
    if(cnt>1){
        cout<<"-1";return 0;
    }
    dfs_euler(1);
    for(i=0;i<rasp.size()-1;i++){
        cout<<rasp[i]<<" ";
    }
    return 0;
}
