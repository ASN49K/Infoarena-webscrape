#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
#define cin in
#define cout out

using namespace std;

ifstream in("hamilton.in");
ofstream out("hamilton.out");

const int NMAX = 1e5 + 5;
vector < pair < int, int > > g[NMAX];
vector < int > ans;
int n, m, i, viz[500005], deg[NMAX];

void euler(int nod) {
    stack < int > st;
    st.push(nod);
    while(!st.empty()) {
        int node = st.top();
        if(!g[node].empty()) {
            auto curr = g[node].back();
            g[node].pop_back();
            if(viz[curr.second]) continue;
            viz[curr.second] = 1;
            st.push(curr.first);
        }
        else {
            ans.push_back(node);
            st.pop();
        }
    }
}

int main()
{
    cin >> n >> m;
    for(i = 1; i <= m; ++i) {
        int a, b;
        cin >> a >> b;
        deg[a]++;
        deg[b]++;
        g[a].push_back({b,i});
        g[b].push_back({a,i});
    }
    for(i = 1; i <= n; ++i)
    if(deg[i] & 1){
        cout << -1;
        return 0;
    }
    euler(1);
    for(int i = 0; i < ans.size()-1; ++i)
        cout << ans[i] << ' ';


    return 0;
}
