#include <bits/stdc++.h>
using namespace std;

#define f first
#define s second
#define pii pair<int,int>
#define pb push_back

vector<vector<int>> adj;
struct fedge{
    int a,b;
};
vector<bool> vis;
vector<fedge> ed;

int cnt;

void dfs(int n){
    while(!adj[n].empty()){
        if(vis[adj[n].back()]){
            adj[n].pop_back();
            continue;
        }
        vis[adj[n].back()]=true;
        int next=ed[adj[n].back()].a;
        if(next==n){
            next=ed[adj[n].back()].b;
        }
        dfs(next);
    }
    cnt--;
    if(cnt<0)return;
    cout<<n+1<<" ";
}

int main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    freopen("ciclueuler.in","r",stdin);
    freopen("ciclueuler.out","w",stdout);
    int N,M;cin>>N>>M;
    adj.resize(N,vector<int>(0));
    vis.resize(M);
    ed.resize(M);
    for(int i=0;i<M;i++){
        cin>>ed[i].a>>ed[i].b;
        ed[i].a--;ed[i].b--;
        adj[ed[i].a].pb(i);
        adj[ed[i].b].pb(i);
        vis[i]=false;
    }
    for(int i=0;i<N;i++){
        if(adj[i].size()%2!=0){
            cout<<-1;
            return 0;
        }
    }
    cnt=M;
    for(int i=0;i<N;i++){
        if(adj[i].size()>0){
            dfs(i);
            return 0;
        }
    }
}