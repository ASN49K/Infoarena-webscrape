#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

map<pair<int, int>, int> muchii_sterse;

void sterge_muchie(int u, int v) {
    pair<int,int> muchie = make_pair(min(u, v), max(u, v));
    auto it = muchii_sterse.find(muchie);
    if (it != muchii_sterse.end() && it->second > 0) {
        it->second--;
    }
}

bool este_muchie_stearsa(int u, int v) {
    pair<int,int> muchie = make_pair(min(u, v), max(u, v));
    auto it = muchii_sterse.find(muchie);
    return it->second == 0;
}

vector<int> gaseste_ciclu_eulerian(int nod_start, vector<vector<int>>& lista_vecini) {
    vector<int> ciclu;
    stack<int> stiva;

    stiva.push(nod_start);

    while (!stiva.empty()) {
        int nod = stiva.top();

        while (!lista_vecini[nod].empty() && este_muchie_stearsa(nod, lista_vecini[nod].back())) {
            lista_vecini[nod].pop_back();
        }

        if (!lista_vecini[nod].empty()) {
            int vecin = lista_vecini[nod].back();
            lista_vecini[nod].pop_back();
            sterge_muchie(nod, vecin);
            stiva.push(vecin);
        } else {
            ciclu.push_back(nod);
            stiva.pop();
        }
    }

    return ciclu;
}

int main() {
    int numar_noduri, numar_muchii;
    cin >> numar_noduri >> numar_muchii;
    vector<vector<int>> lista_vecini(numar_noduri + 1);

    for (int i = 0; i < numar_muchii; i++) {
        int nod1, nod2;
        cin >> nod1 >> nod2;
        lista_vecini[nod1].push_back(nod2);
        lista_vecini[nod2].push_back(nod1);
        pair<int,int> muchie = make_pair(min(nod1, nod2), max(nod1, nod2));
        muchii_sterse[muchie]++;
    }

    for (int i = 1; i <= numar_noduri; i++) {
        if (lista_vecini[i].size() % 2 == 1) {
            cout << "-1" << endl;
            return 0;
        }
    }

    vector<int> ciclu_eulerian = gaseste_ciclu_eulerian(1, lista_vecini);

    for (int i = 0; i < ciclu_eulerian.size() - 1; i++) {
        cout << ciclu_eulerian[i] << " ";
    }

    return 0;
}
