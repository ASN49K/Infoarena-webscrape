#include <iostream>
#include <vector>
#define pii pair<int, int>

using namespace std;

const int NMAX = 1e5 + 5;
const char nl = '\n';

vector<pii> graph[NMAX]; // (neigh, index edge) pentru a putea identifica unic fiecare muchie
int visited[NMAX];
vector<int> cycle;

bool check_degrees(int n) {
    for(int i = 1; i <= n; ++i) {
        if(graph[i].size() % 2 != 0) {
            return false;
        }
    }
    return true;
}
void euler(int node) {
    while(!graph[node].empty()) {
        int neigh = graph[node].back().first;
        int index = graph[node].back().second;
        graph[node].pop_back();

        if(!visited[index]) {
            visited[index] = 1;
            euler(neigh);
        }

    }
    cycle.push_back(node);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);

    int n, m;
    cin >> n >> m;

    for(int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;

        graph[u].push_back({v, i});
        graph[v].push_back({u, i});
    }

    if(check_degrees(n)) {
        euler(1);

        if(cycle.size() != m + 1) { // verif daca e conex
            cout << -1 << nl;
        } else {
            for(int i = cycle.size() - 1; i > 0; --i) {
                cout << cycle[i] << ' ';
            }
        }
    } else {
        cout << -1 << nl;
    }
    return 0;
}