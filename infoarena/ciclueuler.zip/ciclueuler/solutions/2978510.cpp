#include <iostream>
#include <fstream>
#include <algorithm>
#include <queue>
#include <cstring>
#include <vector>
#include <climits>
#include <bitset>
#include <cmath>
#include <climits>
#include <stack>
#include <stdlib.h>
#include <queue>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

vector<int> x[100001];
int afis[500001];

void ciclu_eulerian(int nod, int n, int& z)
{

    int nod_nou;
    while (!x[nod].empty())
    {
        nod_nou = x[nod].front();
        vector<int>::iterator it;
        it = find(x[nod].begin(), x[nod].end(), nod_nou);
        x[nod].erase(it);
        it = find(x[nod_nou].begin(), x[nod_nou].end(), nod);
        x[nod_nou].erase(it);
        ciclu_eulerian(nod_nou, n, z);
        afis[++z] = nod;
    }
}

int main()
{
    int n, m, z = 0;
    f >> n >>m;
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        f >> a >> b;
        x[a].push_back(b);
        x[b].push_back(a);
    }
    ciclu_eulerian(1, n, z);
    for (int i = z; i >= 1; i--)
        g << afis[i] << " ";
    return 0;
}
