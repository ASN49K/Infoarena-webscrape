#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

const int nmax = 100005;
int n, m, fr[5 * nmax];
vector< pair<int, int> > v[nmax];
stack<int> St;

void ciceu(int nod)
{
    for(auto x : v[nod])
        if(!fr[x.second])
            fr[x.second] = 1, ciceu(x.first);

    St.push(nod);
}

int main()
{
    f >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int x, y; f >> x >> y;
        v[x].push_back(make_pair(y, i));

        if(x != y)
            v[y].push_back(make_pair(x, i));
    }

    ciceu(1);

    int ok = 1;
    for(int i = 1; i <= m; i ++)
        ok *= fr[i];

    if(!ok){
        g << -1;
        return 0;
    }

    while(St.size() > 1){
        g << St.top() << " ";
        St.pop();
    }
    return 0;
}
