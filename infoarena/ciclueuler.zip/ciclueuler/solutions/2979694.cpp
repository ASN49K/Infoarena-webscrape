#include <bits/stdc++.h>

#define MAX 100000
#define EMAX 500000

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

int n, m, a, b, imp, st;
vector <pair<int,int>> graph[MAX + 5];
stack<int> s;
vector<int> ans;
bool check[EMAX + 5];

void dfs(int node)
{
    s.push(node);
    for(auto i : graph[node])
    {
        if(!check[i.second])
        {
            check[i.second] = 1;
            dfs(i.first);
        }
    }

    ans.push_back(s.top());
    s.pop();
}

signed main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; ++i)
    {
        fin >> a >> b;
        graph[a].push_back({b, i});
        graph[b].push_back({a, i});
    }

    st = 1;
    for(int i = 1; i <= n; ++i)
    {
        if(graph[i].size() % 2)
            imp++, st = i;
    }

    if(imp)
    {
        fout << -1;
        exit(0);
    }

    dfs(st);
    reverse(ans.begin(), ans.end());
    ans.pop_back();
    for(auto i : ans)
        fout << i << ' ';
}
