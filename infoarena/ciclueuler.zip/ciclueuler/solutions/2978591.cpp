#include <iostream>
#include <fstream>
#include <algorithm>
#include <queue>
#include <cstring>
#include <vector>
#include <climits>
#include <bitset>
#include <cmath>
#include <climits>
#include <stack>
#include <stdlib.h>
#include <queue>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

stack<int> s;
vector<int> x[100001];
int afis[500010];

bool ver(int n)
{
    int par_imp;
    for (int i = 1; i <= n; i++)
    {
        if (x[i].size() % 2 == 1)
            return 0;
    }
    return 1;
}

int main()
{
    int n, m, z = 0;
    bool ok;
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        f >> a >> b;
        x[a].push_back(b);
        x[b].push_back(a);
    }
    int nod = 1, nod_nou;
    ok = ver(n);
    if (ok == 1)
    {
        s.push(1);
        while (!s.empty())
        {
            nod = s.top();
            if (!x[nod].empty())
            {
                nod_nou = x[nod].front();
                s.push(nod_nou);
                vector<int>::iterator it;
                it = find(x[nod].begin(), x[nod].end(), nod_nou);
                x[nod].erase(it);
                it = find(x[nod_nou].begin(), x[nod_nou].end(), nod);
                x[nod_nou].erase(it);
            }
            else
            {
                afis[++z] = s.top();
                s.pop();
            }
        }
        for (int i = z; i >= 2; i--)
            g << afis[i] << " ";
    }
    else
        g << -1;
    return 0;
}
