#include <bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops")
#pragma GCC target("sse,avx,fma,avx2,bmi,bmi2,lzcnt,popcnt")

using namespace std;

void solve() {
	int n, m;
	cin >> n >> m;

  vector<int> self_edges(n, 0);
	vector<multiset<int>> adj(n);
	for (int i = 0, u, v; i < m; ++i) {
		cin >> u >> v;
    --u, --v;
    if (u == v) {
      ++self_edges[u];
      continue;
    }
    adj[u].insert(v);
    adj[v].insert(u);
  }

  vector<bool> vis(n, false);
  function<void(int)> dfs = [&](int u) {
    vis[u] = true;
    for (int v : adj[u])
      if (!vis[v])
        dfs(v);
  };

  int start_node = -1;
  bool did_dfs = false;
  for (int i = 0; i < n; ++i) {
    if (adj[i].size() & 1) {
      cout << "-1\n";
      return;
    }

    if (adj[i].size() + self_edges[i] == 0 || vis[i]) {
      continue;
    }
    
    if (did_dfs) {
      cout << "-1\n";
      return;
    }

    dfs(i);
    did_dfs = true;
    start_node = i;
  }

  vector<int> ans;
  ans.reserve(m);
  function<void(int)> print_tour = [&](int u) {
    while (!adj[u].empty()) {
      int v = *adj[u].begin();
      adj[u].erase(adj[u].begin());
      adj[v].erase(adj[v].find(u));
      print_tour(v);
    }
    while(self_edges[u]-- > 0)
      ans.push_back(u);
    
    ans.push_back(u);
  };

  print_tour(start_node);
  ans.pop_back();
  for (auto x : ans)
    cout << x + 1 << ' ';
  cout << '\n';
}

int main() {

	#ifndef ONLINE_JUDGE
    freopen("ciclueuler.in", "r", stdin);
    freopen("ciclueuler.out", "w", stdout);
	#endif

	int t = 1;
	// cin >> t;

	while (t--)
		solve();
	return 0;
}
