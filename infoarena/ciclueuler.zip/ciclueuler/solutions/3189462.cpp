#include <bits/stdc++.h>
#define SIZE 100005
using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n,m,from[5*SIZE],to[5*SIZE];

vector<int>a[SIZE];
vector<int>sol;
stack<int>st;
bool vz[5*SIZE];

int main()
{
    int i,x,y;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x].push_back(i);
        a[y].push_back(i);
        from[i]=x;
        to[i]=y;
    }
    for(i=1;i<=n;i++)
        if(a[i].size() & 1)
    {
        g<<-1;
        return 0;
    }
    st.push(1);
    while(!st.empty())
    {
        int nod=st.top();
        if(!a[nod].empty())
        {
            int e=a[nod].back();
            a[nod].pop_back();
            if(!vz[e])
            {
                vz[e]=true;
                if(to[e]!=nod)st.push(to[e]);
                else st.push(from[e]);
            }
        }
        else
        {
            st.pop();
            sol.push_back(nod);
        }

    }

    for(i=0;i<sol.size()-1;i++)g<<sol[i]<<' ';
    return 0;

}
