#include <bits/stdc++.h>

using namespace std;

int main() {
    ifstream in("ciclueuler.in");
    ofstream out("ciclueuler.out");
    int n, m;
    in >> n >> m;
    vector<list<int>> graf(n + 1);
    vector<bool> vizitat(n+1);
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    
    for (int i = 1; i <= n; i++)
        if(graf[i].empty() || graf[i].size() % 2) {
            out << -1;
            return 0;
        }

    stack<int> noduri;

    noduri.push(1);

    while(!noduri.empty()) {
        auto nod = noduri.top();
        while(!graf[nod].empty()) {
            int vec = graf[nod].back();
            graf[nod].pop_back();
            graf[vec].erase(ranges::find(graf[vec], nod));
            noduri.push(vec);
            nod = vec;
        }
        if (noduri.size() > 1)
            out << noduri.top() << ' ';
        noduri.pop();
    }
}