#include <fstream>
#include <vector>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

struct edge
{
    int x, y;
};

int n, m;
edge edges[500005];
vector<int> G[100005], ans;
bool used[100005];

int findNext(int x)
{
    while (!G[x].empty() && used[G[x].back()])
        G[x].pop_back();
    if (G[x].empty())
        return 0;
    int y = G[x].back();
    used[y] = true;
    G[x].pop_back();
    return (edges[y].x + edges[y].y - x);
}

void euler(int node)
{
    while (int nxt = findNext(node))
        euler(nxt);
    ans.push_back(node);
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        edge edge_i;
        fin >> edge_i.x >> edge_i.y;
        edges[i] = edge_i;
        G[edge_i.x].push_back(i);
        G[edge_i.y].push_back(i);
    }
    euler(1);
    for (int i = 0; i < ans.size() - 1; i++)
        fout << ans[i] << " ";
    return 0;
}