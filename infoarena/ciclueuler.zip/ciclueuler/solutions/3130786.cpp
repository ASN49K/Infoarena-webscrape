#include <fstream>
#include <math.h>
#include <vector>

using namespace std;

const int MAX=1e6+1;

ifstream cin ("ciclueuler.in");
ofstream cout ("ciclueuler.out");
int n,m;

vector <int> gr[MAX];
int sol[MAX];
int cnt=0;
int ok=1;
int viz[MAX];

int nrelim=0;


void euler(int nod)
{
    for(int i=0; i<gr[nod].size(); i++)
    {
        int fiu=gr[nod][i];
        if(fiu!=0)
        {
            nrelim++;
            gr[nod][i]=0;
            int j=0;
            while(gr[fiu][j]!=nod)
            {
                j++;
            }
            gr[fiu][j]=0;
            euler(fiu);
        }
    }
    sol[++cnt]=nod;
}
int main()
{
    cin>>n>>m;
    int verif=0;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        cin>>x>>y;
        viz[x]++;
        viz[y]++;
        gr[x].push_back(y);
        gr[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(viz[i]!=0){
            euler(i);
            break;
        }
    }
    if(nrelim!=m)
        cout<<-1;
    else{
        for(int i=1; i<cnt; i++)
        {
            cout<<sol[i]<<' ';
        }
    }
}
