#include <fstream>
using namespace std;
ifstream cin("lanterna.in");
ofstream cout("lanterna.out");
int a,b,c,st,dr,nr;
bool fr[1001][1001];
struct coada{
    int a,b,t,op;
}q[1000001];
void rec(int p){
    if(p==1){
        cout<<nr<<'\n';
        return ;
    }
    nr++;
    rec(q[p].t);
    if(q[p].op==1)
        cout<<"R A\n";
    else if(q[p].op==2)
        cout<<"R B\n";
    else if(q[p].op==3)
        cout<<"A C\n";
    else if(q[p].op==4)
        cout<<"B C\n";
    else if(q[p].op==5)
        cout<<"B A\n";
    else
        cout<<"A B\n";
}
int main()
{
    cin>>a>>b>>c;
    fr[0][0]=1;
    q[1]={0,0,0,0};
    st=dr=1;
    while(st<=dr){
        int ca=q[st].a,cb=q[st].b;
        if(ca==c||cb==c){
            rec(st);
            return 0;
        }
        if(!fr[a][cb]){
            fr[a][cb]=1;
            q[++dr]={a,cb,st,1};
        }
        if(!fr[ca][b]){
            fr[ca][b]=1;
            q[++dr]={ca,b,st,2};
        }
        if(!fr[0][cb]){
            fr[0][cb]=1;
            q[++dr]={0,cb,st,3};
        }
        if(!fr[ca][0]){
            fr[ca][0]=1;
            q[++dr]={ca,0,st,4};
        }
        int lv=ca+cb,cv=0;
        if(lv>a)
            cv=lv-a,lv=a;
        if(!fr[lv][cv]){
            fr[lv][cv]=1;
            q[++dr]={lv,cv,st,5};
        }
        lv=0,cv=ca+cb;
        if(cv>b)
            lv=cv-b,cv=b;
        if(!fr[lv][cv]){
            fr[lv][cv]=1;
            q[++dr]={lv,cv,st,6};
        }
        st++;
    }
    return 0;
}
