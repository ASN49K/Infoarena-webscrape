#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m;
vector<pair<int, int>>adj[100005];
vector<bool>visited(500001);
vector<int>ans;
void euler(int v)
{
    while(!adj[v].empty())
    {
        auto pr = adj[v].back();
        adj[v].pop_back();

        int vec = pr.first;
        int muc = pr.second;

        if(!visited[muc])
        {
            visited[muc] = true;
            euler(vec);
        }

    }ans.push_back(v);
}
int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
    }

    for(int i = 1; i <= n; i++)
    {
        if(adj[i].size() % 2 != 0)
            {fout << -1; return 0;}

    }

    euler(1);

    if(ans.size()!= m+1)
        fout << -1 ;
    else
    for(int i = 0; i < m; i++)
        fout << ans[i] << " ";
    return 0;
}
