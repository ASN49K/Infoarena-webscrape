/*
Se da un graf, se cere sa se determine un ciclu care sa parcurga fiecare muchie
exact o data
*/

#include <fstream>
#include <utility>
#include <vector>

using namespace std;

const int nmax = 2e5;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m, u, v, comp, current_edge[nmax + 1];
vector<pair<int, int>> g[nmax + 1];
bool visited[nmax + 1], visited_edges[nmax + 1];
vector<int> cycle;

void dfs(int node) {
  visited[node] = true;

  for (auto nxt : g[node]) {
    if (visited[nxt.first])
      continue;
    dfs(nxt.first);
  }
}

void build_euler_cycle(int node) {
  while (current_edge[node] < g[node].size()) {
    // daca muchia actuala a fost vizitata deja intr-o parcurgere
    // anterioara trec la urmatoarea muchie
    if (visited_edges[g[node][current_edge[node]].second]) {
      current_edge[node]++;
    } else {
      visited_edges[g[node][current_edge[node]].second] = true;
      int neighbour = g[node][current_edge[node]].first;
      current_edge[node]++;
      build_euler_cycle(neighbour);
    }
  }

  cycle.push_back(node);
}

int main() {
  fin >> n >> m;
  for (int i = 1; i <= m; i++) {
    fin >> u >> v;
    g[u].push_back({});
    g[v].push_back({});
  }

  // 1. toate nodurile trebuie sa aiba gradul par
  for (int i = 1; i <= n; i++) {
    if (g[i].size() % 2 == 1) {
      fout << -1;
      return 0;
    }
  }

  // 2. graful trebuie sa fie conex
  for (int i = 1; i <= n; i++) {
    if (visited[i])
      continue;

    dfs(i);

    comp++;
    if (comp > 1) {
      fout << -1;
      return 0;
    }
  }

  // 3. finally trecem la construirea ciclului eulerian
  build_euler_cycle(1);

  for (auto x : cycle)
    fout << x << ' ';

  return 0;
}