#include <fstream>
#include <vector>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,i,d[100005],nr,x,y;
bool viz[100005],viz2[100005];
vector<pair<int,int>> v[500005];
vector<int> sol;
void dfs(int nod)
{
    viz[nod]=1;
    nr++;
    for(auto x:v[nod])
        if(viz[x.first]==0) dfs(x.first);
}
void euler(int nod)
{
    while(!v[nod].empty())
    {
        auto [nod2,ind]=v[nod].back();
        v[nod].pop_back();
        if(viz2[ind]==0)
        {
            viz2[ind]=1;
            euler(nod2);
        }
    }
    sol.push_back(nod);
}
int main()
{
    cin>>n>>m;
    for(i=1;i<=n;i++)
    {
        cin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
        d[y]++;
        d[x]++;
    }
    for(i=1;i<=n;i++)
    {
        if(d[i]%2==1)
        {
            cout<<-1;
            return 0;
        }
    }
    dfs(1);
    if(nr!=n)
    {
        cout<<-1;
        return 0;
    }
    euler(1);
    for(auto x:sol) cout<<x<<' ';
    return 0;
}
