#include <fstream>
#include <vector>
#define s second
#define f first
const int NMAX=500005;

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

void dfs(int);

vector <pair<int, int>> v[NMAX];
vector <int> ans;
int n, m;
bool f[NMAX];

int main()
{
    int i, a, b;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back({b, i});
        v[b].push_back({a, i});
    }
    for(i=1; i<=n; i++)
    {
        if(v[i].size()%2)
        {
            fout<<-1<<'\n';
            return 0;
        }
    }
    dfs(1);
    ans.pop_back();
    for(auto i:ans) fout<<i<<' ';
    fout<<'\n';
    return 0;
}

void dfs(int nod)
{
    pair <int, int> p;
    while(v[nod].size())
    {
        p=v[nod].back(); v[nod].pop_back();
        if(!f[p.s])
        {
            f[p.s]=true;
            dfs(p.f);
        }
    }
    ans.push_back(nod);
}
