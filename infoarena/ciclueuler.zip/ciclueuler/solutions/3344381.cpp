#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 1e5 + 5;
const int MMAX = 5e5 + 5;

int n, m;
vector<pair<int, int>> g[NMAX];
vector<int> q;
bool used[MMAX];
int grad[NMAX];

void euler(int node) {
  q.push_back(node);
  while (!g[node].empty()) {
    pair<int, int> p = g[node].back();
    g[node].pop_back();
    if (!used[p.second]) {
      used[p.second] = true;
      euler(p.first);
    }
  }

}

void solve() {
  fin >> n >> m;
  for (int i = 1; i <= m; i++) {
    int u, v;
    fin >> u >> v;
    grad[u]++;
    grad[v]++;
    g[u].push_back(make_pair(v, i));
    g[v].push_back(make_pair(u, i));
  }
  for (int i = 1; i <= n; i++)
    if (grad[i] & 1) {
      fout << -1 << '\n';
      return;
    }
  euler(1);
  for (int i = 0; i < q.size() - 1; i++)
    fout << q[i] << ' ';
  fout << '\n';
}

int main() {
  ios_base :: sync_with_stdio(false);
  cin.tie(nullptr);
  solve();
  return 0;
}
