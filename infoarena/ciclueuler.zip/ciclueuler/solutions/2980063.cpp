#include <iostream>
#include <fstream>
using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
int start[100001],t[2][1000005],fr[100001],n,m,k,stiva[1000005];

void citire()
{
    f>>n>>m;
    int i,j;
    for(int o=1;o<=m;o++)
    {
        f>>i>>j;
        fr[i]++;
         fr[j]++;
        k++;
        t[0][k]=j;
        t[1][k]=start[i];
        start[i]=k;
        k++;
            t[0][k]=i;
            t[1][k]=start[j];
            start[j]=k;




    }
}

void stergere(int x,int y)
{
    int p=start[x];
    while(p)
    {
        if(t[0][p]==y)
        {
           t[0][p]=-1;
           return;
        }
        p=t[1][p];
    }
}
void rezolvare()
{
    for(int i=1;i<=n;i++)
        if(fr[i]%2==1||fr[i]==0)
        {
             g<<"-1";
             return;
        }

    int vf=1,ok,x,p;
    stiva[vf]=1;
    while(vf>0)
    {
        ok=0;
        p=start[stiva[vf]];
        x=stiva[vf];
        while(p)
        {
            if(t[0][p]!=-1)
            {
                start[stiva[vf]]=t[1][p];
                stiva[++vf]=t[0][p];
                stergere(t[0][p],x);
                t[0][p]=-1;
                ok=1;
                break;
            }
            p=t[1][p];
        }
        if(ok==0)
        {
            if(vf>1)
            g<<stiva[vf]<<" ";
            vf--;
        }
    }
}


int main()
{
   citire();
   rezolvare();

    return 0;
}
