#include <iostream>
#include <fstream>
#include <vector>

int main() {
    std::ifstream input("ciclueuler.in");
    std::ofstream output("ciclueuler.out");

    int n, m;
    input >> n >> m;

    std::vector<std::vector<int>> graph(n + 1);

    for (int i = 0; i < m; ++i) {
        int x, y;
        input >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    bool has_cycle = true;
    for (int i = 1; i <= n; ++i) {
        if (graph[i].size() % 2 == 1) has_cycle = false;
    }

    if (!has_cycle) output << -1;
    else {

    }
    return 0;
}
