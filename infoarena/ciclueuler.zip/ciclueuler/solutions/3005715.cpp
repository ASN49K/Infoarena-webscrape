#include <bits/stdc++.h>
#define NMAX 100008
#define MMAX 500008

using namespace std;
ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

struct Muchie
{
    int x, y, viz;
}L[MMAX];

int n, m;
vector <int> G[NMAX], sol;

void euler(int start);

int main()
{
    int x, y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        G[x].push_back(i);
        G[y].push_back(i);
        L[i] = {x, y, 0};
    }
    int i;
    for (i = 1; i <= n; i++)
        if (G[i].size() % 2)
            break;
    if (i <= n)
    {
        fout << -1;
        exit(0);
    }
    euler(1);
    return 0;
}

void euler(int start)
{
    stack <int> S;
    S.push(start);
    while (!S.empty())
    {
        int nod = S.top();
        if (G[nod].empty())
        {
            sol.push_back(nod);
            S.pop();
        }
        else
        {
            int m = G[nod].back();
            G[nod].pop_back();
            if (L[m].viz == 0)
            {
                L[m].viz = 1;
                if (L[m].x == nod)
                    S.push(L[m].y);
                else
                    S.push(L[m].x);
            }
        }
    }

    for (int i = 0; i < sol.size()-1; i++)
        fout << sol[i] << ' ';
}
