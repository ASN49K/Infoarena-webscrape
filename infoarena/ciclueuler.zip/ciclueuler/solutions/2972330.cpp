//#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
vector <pair<int,int> > v[100005];
int viz[500005];
int ordine[100005],deg[100005],f[100005];
int contor=0,co;
void ciclu(int nod){
    if(f[nod]==0){
        f[nod]=1;
        co++;
    }
    while(v[nod].empty()==false){
        auto u=v[nod].back();
        v[nod].pop_back();
        if(viz[u.second]==false){
            viz[u.second]=1;
            ciclu(u.first);
        }
    }
    ordine[++contor]=nod;
}
int main() {
    int n,m;
    cin>>n>>m;
    int a,b;
    for(int i=1;i<=m;i++){
        cin>>a>>b;
        v[a].push_back(make_pair(b,i));
        v[b].push_back(make_pair(a,i));
        deg[a]++;
        deg[b]++;
    }
    for(int i=1;i<=n;i++){
        if(deg[i]%2==1){
            cout<<-1;
            return 0;
        }
    }
    ciclu(1);
    if(co!=n){
        cout<<-1;
        return 0;
    }
    for(int i=1;i<contor;i++){
        cout<<ordine[i]<<" ";
    }
    return 0;
}
