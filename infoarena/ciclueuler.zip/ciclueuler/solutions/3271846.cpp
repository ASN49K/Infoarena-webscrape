#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 100000,
          MMAX = 500000;
int n, m;

struct muchie
{
    int nod,nrm;
    muchie(int xx=0, int nn=0):nod(xx),nrm(nn) {}
};

vector<muchie> G[NMAX+1];
vector<int> l;
bitset<MMAX> elim;

void citire()
{
    int x, y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        G[x].push_back(muchie(y,i));
        G[y].push_back(muchie(x,i));
    }
}

void euler(int x)
{
    muchie mm;
    while(!G[x].empty())
    {

        mm=G[x].back();
        G[x].pop_back();
        if(elim[mm.nrm]==0)
        {
            elim[mm.nrm]=1;
            euler(mm.nod);
        }
    }
    l.push_back(x);
}

bool verif()
{
    for (int i=1; i<=n; i++)
        if(G[i].size()%2!=0)
            return 0;
    return 1;
}

int main()
{
    bool ok=1;
    citire();
    for(int i=1; i<=n&&ok; i++)
    {
        if(G[i].size() & 1) ok=0;
    }
    if(ok==0)
        fout<<"-1";
    else
    {
        euler(1);
        for(int i=l.size()-1; i>=1; i--)
            fout<<l[i]<<' ';
    }

    fin.close();
    fout.close();
    return 0;
}
