#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

ifstream in("ciclueuler.in");
ofstream out("ciclueuler.out");
int n, m;
vector<int> v[100005];
vector<int> ans;

int main()
{
    in>>n>>m;

    int x, y;
    for(int i = 1; i<=m; i++)
    {
        in>>x>>y;

        v[x].push_back(y);
        v[y].push_back(x);
    }


    stack<int> s;
    int nd, nxt;

    s.push(1);

    while(!s.empty())
    {
        nd = s.top();

        if(!v[nd].empty())
        {
            nxt = *v[nd].begin();

            s.push(nxt);

            v[nd].erase(find(v[nd].begin(), v[nd].end(), nxt));
            v[nxt].erase(find(v[nxt].begin(), v[nxt].end(), nd));

            continue;
        }

        ans.push_back(nd);
        s.pop();
    }

    for(int i = 0; i<ans.size() - 1; i++)
    {
        out<<ans[i]<<" ";
    }

    return 0;
}
