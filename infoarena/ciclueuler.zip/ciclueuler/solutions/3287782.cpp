#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciclueuler.in");
ofstream fout ("ciclueuler.out");

const int nmax=5e5+5;

vector <pair<int,int>> g[nmax];
vector <int> sol;
int n, m, grad[nmax], curr[nmax];
bool fr[nmax], viz[nmax];

void ciclu (int node)
{
    while (curr[node]<grad[node])
    {
        pair <int,int> k=g[node][curr[node]];
        curr[node]++;
        if (!viz[k.second])
        {
            viz[k.second]=1;
            ciclu(k.first);
        }
    }
    sol.push_back(node);
}

void dfs (int node)
{
    fr[node]=true;
    for (auto it:g[node])
    {
        if (!fr[it.first])
            dfs(it.first);
    }
}

int main()
{
    fin >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x, y;
        fin >> x >> y;
        g[x].push_back({y,i});
        g[y].push_back({x,i});
        grad[x]++;
        grad[y]++;
    }
    dfs(1);
    for (int i=1; i<=n; i++)
    {
        if (!fr[i] || grad[i]%2==1)
        {
            fout << -1;
            return 0;
        }
    }
    ciclu(1);
    sol.pop_back();
    for (auto it:sol)
        fout << it << " ";
    return 0;
}
