#include <fstream>
#include <vector>
#include <stack>
using namespace std;

ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");

const int MAX = 1e5 + 1;

struct muchie{

    int y , i;

};

vector <muchie> g[MAX];

int n , x , y , m , last[MAX];

bool marcat[MAX] , b[MAX*5];

vector <int> ans;

void read(){

    cin >> n >> m;

    while(m){

        cin >> x >> y;

        g[x].push_back({y,m});
        g[y].push_back({x,m});

        m--;
    }
}

void dfs( int x ){

    marcat[x] = 1;

    for(auto it : g[x]){

        if(!marcat[it.y]) dfs(it.y);
    }
}

int check(){

    int to_be_remembered;

    for(int i = 1 ; i <= n ; i++){

        if(g[i].size()){

            dfs(i);

            to_be_remembered = i;

            break;
        }
    }

    for(int i = 1 ; i <= n ; i++){

        int x = g[i].size();

        if(x%2){

            cout << -1;

            exit(0);
        }

        if(!x) continue;

        if(!marcat[i]){

            cout << -1;

            exit(0);
        }
    }

    return to_be_remembered;
}

void euler( int x ){

    int sz = g[x].size();

    for(int i = last[x] ; i < sz ; i++){

        muchie it = g[x][i];

        last[x]++;

        if(!b[it.i]){

            b[it.i] = 1;

            euler(it.y);
        }
    }

    ans.push_back(x);
}

void afis(){

    ans.pop_back();

    for(auto it : ans){

        cout << it << ' ';
    }

}

int main()
{

    read();
    euler(check());
    afis();

    return 0;
}
