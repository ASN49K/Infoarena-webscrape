#include <cstdio>
#include <cmath>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <bitset>
#include <map>
#include <cstring>
#include <algorithm>

#define NMAX 10003

using namespace std;

FILE* fin, * fout;

int n, m, k;
int grad[NMAX];
int start[NMAX];
bool viz[NMAX];
stack<int>stiv;


struct muchie {
	int nod, ind;
};
vector<muchie>graf[NMAX];
int main()
{
	fin = fopen("ciclueuler.in", "r");
	fout = fopen("ciclueuler.out", "w");
	
	fscanf(fin, "%d %d", &n, &m);
	for (int i = 1; i <= m; i++)
	{
		int x, y;
		fscanf(fin, "%d %d", &x, &y);
		graf[x].push_back({ y,i });
		graf[y].push_back({ x, i});

		grad[x]++;
		grad[y]++;
	}

	stiv.push(1);
	while (!stiv.empty())
	{
		int nodSus = stiv.top();
		if (grad[nodSus] == 0)
		{
			fprintf(fout, "%d ", nodSus);
			stiv.pop();
			continue;
		}
		for (int i = start[nodSus]; i < graf[nodSus].size(); i++)
		{
			int nd = graf[nodSus][i].nod;
			int indMuchie = graf[nodSus][i].ind;
			start[nodSus] = i;
			if (grad[nd] > 0 && !viz[indMuchie])
			{
				grad[nd]--;
				grad[nodSus]--;
				stiv.push(nd);
				viz[indMuchie] = true;

				break;
			}
		}
	}
	return 0;
}