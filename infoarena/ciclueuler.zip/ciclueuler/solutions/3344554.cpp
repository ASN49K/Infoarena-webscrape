#include <fstream>
#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector<pair<int,int>> L[100005];
bool viz[500005];
int main() {
    int n,m;
    fin>>n>>m;
    for (int i=1; i<=m; i++) {
        int x,y;
        fin>>x>>y;
        L[x].push_back({y,i});
        L[y].push_back({x,i});
    }
    stack<int> st;
    vector<int> sol;
    st.push(1);
    while (!st.empty()) {
        int curr=st.top();
        if (L[curr].empty()) {
            sol.push_back(curr);
            st.pop();
        }
        else{
            pair<int,int> next=L[curr].back();
            L[curr].pop_back();
            if (!viz[next.second]) {
                viz[next.second]=1;
                st.push(next.first);
            }
        }
    }
    for (auto it:sol)
        fout<<it<<' ';
    return 0;
}
// 2 0 3 -1 7 -4
