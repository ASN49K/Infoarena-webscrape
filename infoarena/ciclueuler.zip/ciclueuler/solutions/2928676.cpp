#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");

int n, m, i, x, y, ok;
pair<int, int> e[500100];
bool erem[500100];
vector<int> adj[100100];
stack<int> stk, cycle;
bool viz[100100];

void dfs(int node)
{
    viz[node] = true;
    for (vector<int>::iterator it = adj[node].begin(); it != adj[node].end(); advance(it, 1))
    {
        int neighbour = (*it);
        if (e[neighbour].first == node)
            neighbour = e[neighbour].second;
        else
            neighbour = e[neighbour].first;
        if (!viz[neighbour])
            dfs(neighbour);
    }
}

void iterdfs()
{
    while (!stk.empty()) {
        int node = stk.top();
        while (!adj[node].empty() && erem[adj[node].back()])
            adj[node].pop_back();
        if (adj[node].size()) {
            int neighbour = adj[node].back();
            erem[neighbour] = true;
            if (e[neighbour].first == node)
                neighbour = e[neighbour].second;
            else
                neighbour = e[neighbour].first;
            stk.push(neighbour);
        }
        else {
            stk.pop();
            cycle.push(node);
        }
    }
}

int main()
{
    f >> n >> m;
    for (i = 1; i <= m; i++) {
        f >> e[i].first >> e[i].second;
        adj[e[i].first].push_back(i);
        adj[e[i].second].push_back(i);
    }
    ok = 1;
    for (i = 1; i <= n; i++) {
        if (adj[i].size() % 2 == 1) {
            ok = 0;
            i = n+1;
        }
    }
    if (!ok) {
        g << -1;
    }
    else {
        for (i = 1; i <= n; i++) {
            if (adj[i].size()) {
                dfs(i);
                i = n+1;
            }
        }
        for (i = 1; i <= n; i++) {
            if (adj[i].size() && !viz[i]) {
                ok = 0;
                i = n+1;
            }
        }
        if (!ok)
            g << -1;
        else {
            for (i = 1; i <= n; i++) {
                if (adj[i].size()) {
                    stk.push(i);
                    iterdfs();
                }
            }
            while (cycle.size() > 1) {
                g << cycle.top() << ' ';
                cycle.pop();
            }
        }
    }
    f.close();
    g.close();
    return 0;
}
