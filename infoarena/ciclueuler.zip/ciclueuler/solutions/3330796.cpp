#include <bits/stdc++.h>
#include <fstream>

using namespace std;

const int NMAX = 100'000;
const int MMAX = 500'000;

int N, M;

vector<pair<int, int>> G[NMAX + 1]; 
// in graf avem lista de adiancenta + muchia asociata

ofstream g("ciclueuler.out");

void ReadInput() { 
    ifstream f("ciclueuler.in");
    f >> N >> M;
    for (int i = 1; i <= M; i++) {
        int u, v;
        f >> u >> v;
        G[u].push_back({v, i});
        G[v].push_back({u, i});
    }
    f.close();
}

bool visited[MMAX + 1];
vector<int> ciclu_eulerian;

void FleuryAlgorithm(int nod) {
    while (G[nod].size() > 0) {
        auto [vecin, ind_muchie] = G[nod].back();
        G[nod].pop_back();
        if (visited[ind_muchie] == true)
            continue;
        visited[ind_muchie] = true;
        FleuryAlgorithm(vecin);
        ciclu_eulerian.push_back(vecin);
    }
}

void SolveCicluEulerian() {
    for (int i = 1; i <= M; i++)
        visited[i] = false;
    ciclu_eulerian.clear();

    FleuryAlgorithm(1);

    // verificam daca avem o singura compoenta conexa
    bool single_connected_component = true;
    for (int i = 1; i <= M; i++)
        if (visited[i] == false)
            single_connected_component = false;
    
    if (single_connected_component == false)    
        g << -1 << '\n';
    else {
        reverse(ciclu_eulerian.begin(), ciclu_eulerian.end());
        for (int nod : ciclu_eulerian)
            g << nod << ' ';
    }
}

// Teorema Leonhard Euler: Graf eulerian -> conex, grade pare pentru noduri
int main() {
    ReadInput();

    // Verificare grade pare graf input
    bool grade_pare = true;
    for (int nod = 1; nod <= N; nod++)
        if (G[nod].size() % 2 == 1)
            grade_pare = false;
    
    if (grade_pare == false) {
        g << -1 << '\n';
    }
    else {
        SolveCicluEulerian();
    }
    return 0;
}