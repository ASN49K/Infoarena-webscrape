#include <bits/stdc++.h>

using namespace std;

ifstream f ("ciclueuler.in");
ofstream g ("ciclueuler.out");

const int NMAX = 1e5;
const int MMAX = 5e5;

struct muchie{
  
  int a, b;
    
};

vector<int> adj[NMAX+1];

int n, m;

muchie v[MMAX+1];

bool deleted[MMAX+1];

int rez[MMAX+1];

int nextEdge(int nod){
    
    while(!adj[nod].empty() and deleted[adj[nod].back()])
        adj[nod].pop_back();
        
    if(adj[nod].empty())
        return 0;
    
    deleted[adj[nod].back()] = true;
    
    return v[adj[nod].back()].a + v[adj[nod].back()].b - nod;
    
}

int cnt;

void euler(int nod){
    
    while(int vec = nextEdge(nod))
        euler(vec);
    
    cnt ++;
    rez[cnt] = nod;
    
}

int main()
{
    
    f >> n >> m;
    
    for(int i=1; i<=m; i++){
        
        int x, y;
        f >> x >> y;
        
        adj[x].push_back(i);
        adj[y].push_back(i);
        
        v[i] = {x, y};
        
    }
    
    int nod = 0;
    for(int i=1; i<=n; i++)
        if(adj[i].size() % 2 == 0)
            nod = i;
    
    euler(nod);
    
    if(cnt != m + 1){
        
        g << -1;
        return 0;
        
    }
    
    for(int i=1; i<cnt; i++)
        g << rez[i] << " ";
        

    return 0;
}