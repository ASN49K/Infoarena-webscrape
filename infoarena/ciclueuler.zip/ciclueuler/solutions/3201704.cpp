#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
typedef pair<int,int> pii;
int n,m;
vector<int> sol;
bool use[500005];
int ind[500005];
vector<pii> muchii[500005];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back({b,i});
        muchii[b].push_back({a,i});
    }
    for(int i=1;i<=n;i++)
        if(muchii[i].size()%2==1)
        {
            fout<<-1;
            return 0;
        }
    stack<int> stiva;
    stiva.push(1);
    while(!stiva.empty())
    {
        int nod=stiva.top();
        int nxt=0;
        while(ind[nod]<muchii[nod].size())
        {
            if(use[muchii[nod][ind[nod]].second])
                ind[nod]++;
            else
            {
                nxt=muchii[nod][ind[nod]].first;
                use[muchii[nod][ind[nod]].second]=1;
                break;
            }
        }
        if(nxt!=0)
        {
            stiva.push(nxt);
            continue;
        }
        sol.push_back(nod);
        stiva.pop();
    }
    sol.pop_back();
    for(int i:sol)
        fout<<i<<' ';
    return 0;
}
