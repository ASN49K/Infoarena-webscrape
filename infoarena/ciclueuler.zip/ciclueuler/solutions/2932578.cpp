
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector<vector<int>> G(100002,vector<int >(100002));
int n, m, k, v;
int x, y;
int p, q;
vector<int> euler;


void dfs(int k) {
   
    for (int i = 1; i <= n;i++) {
        if ( G[i][k]==1) {
            G[k][i] = G[i][k] = 0;
            dfs(i);

        }
    }
    euler.push_back(k) ;
}


int main()
{
    //freopen("bfs.in", "r", stdin);
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        G[x][y] = G[y][x] = 1;
    }

    dfs(1);
    if (euler.size()<m) {
        fout << -1;
    }
    for (auto i : euler) {
        fout << i << ' ';
    }
}
