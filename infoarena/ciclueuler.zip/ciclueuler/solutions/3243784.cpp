#include <bits/stdc++.h>

using namespace std;
ifstream f("ciclueuler.in");
ofstream g("ciclueuler.out");
deque<int>q, ans;
vector<pair<int,int> > v[100005];
bool use[100005];
void euler()
{
    int x,y;
    q.push_back(1);
    while(!q.empty())
    {
        x=q.back();
        while(v[x].empty()==false && use[v[x].back().first]!=0)
            v[x].pop_back();

        if(v[x].size()==0)
        {
            q.pop_back();
            ans.push_back(x);
        }
        else
        {
            use[v[x].back().first]=1;
            q.push_back(v[x].back().second);
            v[x].pop_back();
        }
    }

}
int n,m, x, y;
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;++i)
    {
        f>>x>>y;
        v[x].push_back({i,y});
        v[y].push_back({i,x});
    }

    for(int i=1;i<=n;++i)
        if(v[i].size()%2==1)
        {
            g<<"-1";
            return 0;
        }

    euler();
    ans.pop_back();
    while(!ans.empty())
    {
        g<<ans.front()<<" ";
        ans.pop_front();
    }


    return 0;
}
