#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int lim=1e5+10;
vector <int> cycle;
vector <pair<int,int>> adj[lim];
int t[lim],dg[lim];
bool viz[lim];
int i,n,m;
int root(int x)
{
    if(x==t[x])return x;
    else return t[x]=root(t[x]);
}
void unite(int x,int y)
{
    int rx=root(x);
    int ry=root(y);
    if(rx==ry)return;
    if(rx>ry)swap(rx,ry);
    t[ry]=rx;
}

bool e_euler()
{
    int comp=t[1];
    for(i=2;i<=n;i++)
        if(t[i]!=comp)return 0;
    for(i=1;i<=n;i++)
        if(dg[i]%2==1)return 0;
    return 1;
}

void euler(int k)
{
    while(!adj[k].empty())
    {
        pair<int,int> e=adj[k].back();
        adj[k].pop_back();
        int x=e.first,p=e.second;

        if(viz[p]==0)
        {
            viz[p]=1;
            euler(x);
        }
    }
    cycle.push_back(k);

}
int main()
{
    fin>>n>>m;
    for(i=1;i<=n;i++)
        t[i]=i;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        unite(x,y);
        dg[x]++;
        dg[y]++;
        adj[x].push_back({y,i});
        adj[y].push_back({x,i});
    }
    if(e_euler()==0){fout<<"-1";return 0;}
    euler(1);
    cycle.pop_back();
    for(auto x:cycle)
        fout<<x<<' ';
    return 0;
}
