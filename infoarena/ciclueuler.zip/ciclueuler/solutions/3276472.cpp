#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
vector<pair<int,int>> v[100100];
deque<int>ans;
int use[500100];
void euler(int node)
{
    deque<int>q;
    q.clear();
    q.push_back(node);
    int x;
    while(!q.empty())
    {
        x=q.back();
        while(!v[x].empty() && use[v[x].back().first]==1)
            v[x].pop_back();

        if(v[x].empty())
        {
            q.pop_back();
            ans.push_back(x);
        }
        else
        {
            use[v[x].back().first]=1;
            q.push_back(v[x].back().second);
        }
    }
}
int n, m, x, y;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>x>>y;
        v[x].push_back({i,y});
        v[y].push_back({i,x});
    }

    for(int i=1;i<=n;++i)
        if(v[x].size()%2==1)
        {
            cout<<-1;
            return 0;
        }

    euler(1);
    for(auto i:ans)
        fout<<i<<" ";

    return 0;
}
