#include <fstream>
#include<bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
const int NMAX=1e5;
stack<int>st;
vector<int>cycle;
vector<int>graph[NMAX+5];
void hierholzer(int nod)
{
    st.push(nod);
    while(!st.empty())
    {
        int CurrentNod=st.top();
        if(!graph[CurrentNod].empty())
        {
            int x=graph[CurrentNod].back();

            graph[CurrentNod].pop_back();
            for(int i=0; i<graph[x].size(); i++)
            {
                if(graph[x][i]==CurrentNod)
                {
                    swap(graph[x][i],graph[x].back());
                    graph[x].pop_back();
                    break;
                }
            }
            st.push(x);
        }
        else
        {
            st.pop();
            cycle.push_back(CurrentNod);
        }
    }


}
int main()
{
    int n,m;
    fin>>n>>m;
    while(m--)
    {
        int x,y;
        fin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);

    }
    for(int i=1; i<=n; i++)
    {
        if(graph[i].size()%2==1)
        {
            fout<<-1;
            return 0;
        }
    }
    hierholzer(1);
    reverse(cycle.begin(),cycle.end());

    for(int i=0; i<cycle.size()-1; i++)
    {
        fout<<cycle[i]<<" ";
    }
    return 0;
}
