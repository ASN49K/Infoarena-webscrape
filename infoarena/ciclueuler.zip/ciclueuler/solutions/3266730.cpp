#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");
int n, m, x, y, grad[100005], viz[100005], k, nrc, nr1, viz_muchie[500005], sol[500005];
vector<pair<int, int>>l[100005];

void dfs(int k)
{
    viz[k]=nrc;
    for(int i=0; i<l[k].size(); i++)
    {
        if(viz[l[k][i].first]==0)
            dfs(l[k][i].first);
    }
}

void euler(int k)
{
    while(!l[k].empty())
    {
        int vecin=l[k].back().first;
        int muchie=l[k].back().second;
        l[k].pop_back();
        if(viz_muchie[muchie]==0)
        {
            viz_muchie[muchie]=1;
            euler(vecin);
        }
    }
    sol[++nr1]=k;
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        l[x].push_back({y, i});
        l[y].push_back({x, i});
        grad[x]++;
        grad[y]++;

    }
    nrc=1;
    dfs(1);
    for(int i=1; i<=n; i++)
        if(viz[i]==0 || grad[i]%2!=0)
        {
            cout<<-1;
            return 0;
        }
    euler(1);
    for(int i=1; i<=nr1-1; i++)
    {
        fout<<sol[i]<<" ";
    }

    return 0;
}
