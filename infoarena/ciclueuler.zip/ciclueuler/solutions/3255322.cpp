#include <fstream>
#include <vector>
#include <stack>
#define mmax 500001
#define nmax 100001
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
int n,m,x,y,start;
bool fr[mmax];
vector<pair<int,int>>v[nmax];
vector<int>sol;
stack<int>s;
void solve(){
    s.push(start);
    while(!s.empty()){
        int nod=s.top(),k=v[nod].size();
        if(v[nod].empty()){
            sol.push_back(nod);
            s.pop();
        }
        for(int i=k-1;i>=0;i--)
            if(fr[v[nod][i].second])
                v[nod].pop_back();
            else{
                s.push(v[nod][i].first);
                fr[v[nod][i].second]=1;
                v[nod].pop_back();
                break;
            }
    }
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
    }
    for(int i=1;i<=n;i++)
        if(v[i].size()!=0){
            start=i;
            break;
        }
    solve();
    if(sol.size()!=m+1){
        cout<<-1;
        return 0;
    }
    sol.pop_back();
    for(auto i:sol)
        cout<<i<<" ";
    return 0;
}
