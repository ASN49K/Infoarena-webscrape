#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

const int NMAX = 100000;

int n, m;
int x, y;
int D[NMAX+1];
int trecut[NMAX+1];
vector < pair<int,int> > v[NMAX+1];
vector <int> myStack;
vector <int> ans;

int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> x >> y;
        v[x].push_back(make_pair(y,i));
        v[y].push_back(make_pair(x,i));
        D[x]++;
        D[y]++;
    }
    for(int i=1; i<=n; i++)
        if(D[i]%2){fout << -1; return 0;}
    myStack.push_back(1);
    while(!myStack.empty())
    {
        int gol = 0;
        int nod = myStack.back();
        if(!v[nod].empty())
        {
            auto bck = v[nod].back();
            if(!trecut[bck.second])
            {
                trecut[bck.second] = 1;
                myStack.push_back(bck.first);
            }
            v[nod].pop_back();
        }
        else
            gol = 1;
        if(!myStack.empty() && gol)
            myStack.pop_back(), ans.push_back(nod);
    }
    ans.pop_back();
    if(ans.size() != m){fout << -1; return 0;}
    for(auto a : ans)
        fout << a << ' ';
    return 0;
}