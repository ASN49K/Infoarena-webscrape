#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
} f("apm.in");

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
} ;

ofstream g("apm.out");

int n, m, cost;

vector <int> sz, parinte;

vector <pair <int, int> > ans;

struct graf
{
    int x, y, cost;
} a[200005];

bool comp(graf &a, graf &b)
{
    return a.cost < b.cost;
}

int find(int x)
{
    if (parinte[x] != x) {
        return parinte[x] = find(parinte[x]);
    }

    return parinte[x];
}

void Union(int x, int y)
{
    int a = find(x), b = find(y);

    if (a != b) {
        if (sz[a] < sz[b]) {
            swap (a, b);
        }

        sz[a] += sz[b];
        parinte[b] = a;
    }
}

int main()
{
    f >> n >> m;

    sz.resize(n + 1), parinte.resize(n + 1);

    for (int i = 1; i <= m; ++i) {
        f >> a[i].x >> a[i].y >> a[i].cost;
    }

    for (int i = 1; i <= n; ++i) {
        parinte[i] = i;
        sz[i] = 1;
    }

    sort(a + 1, a + m + 1, comp);

    for (int i = 1; i <= m; ++i) {
        if (find(a[i].x) != find(a[i].y)) {
            cost += a[i].cost;
            ans.push_back({a[i].x, a[i].y});
            Union(a[i].x, a[i].y);
        }
    }

    g << cost << '\n' << ans.size() << '\n';

    for (auto [a, b] : ans) {
        g << a << ' ' << b << '\n';
    }

    return 0;
}
