#include <fstream>
#include <queue>
#define NMAX 200002
#define MMAX 400002
using namespace std;
ifstream fin ("apm.in");
ofstream fout("apm.out");
int n, m;
int tata[NMAX]; //h[x]=parintele lui x
int h[NMAX]; //h[x] inaltimea arborelui cu radacina x
int costmin;
struct muchie {int x, y, c;
               friend bool operator < (muchie a, muchie b);
              };
priority_queue<muchie> H;
muchie apm[NMAX];

bool operator < (muchie a, muchie b)
{
 return a.c > b.c;
}

int Find (int x);
void Union(int x, int y);
void citire();
void kruskal();
void afisare();
int main()
{
 citire();
 kruskal();
 afisare();
 return 0;
}


int Find (int x)
{int rx, y;
 //determin radacina arborelui
 rx=x;
 while (tata[rx]) rx=tata[rx];
   //rx este radacina arborelui
 //compresez drumul de la x la rx;
 //fiecare nod de pe acest drum devine fiu al lui rx
 while(tata[x] && tata[x]!=rx)
      {y=tata[x];
       tata[x]=rx;
       x=y;
      }
 return rx;
}


void Union(int x, int y)
{//reuneste arborele in care se afla x cu arborele in care se afla y
 int rx, ry;
 rx=Find(x); ry=Find(y);
 if(h[rx]<h[ry])
    //rx devine fiul lui ry
    tata[rx]=ry;
    else
        if(h[ry]<h[rx]) //invers
           tata[ry]=rx;
        else //egalitate
          {tata[ry]=rx;
           h[rx]++;
          }
}


void citire()
{int i;
 muchie aux;
 fin>>n>>m;
 for(i=0; i<m; i++)
    {fin>>aux.x>>aux.y>>aux.c;
     H.push(aux);
    }
}

void kruskal()
{int rx, ry, nrsel;
 muchie aux;
 nrsel=0;
 while(nrsel<n-1)
      {aux=H.top(); H.pop();
       rx=Find(aux.x); ry=Find(aux.y);
       if(rx!=ry)
         {costmin+=aux.c;
          apm[++nrsel]=aux;
          Union(rx, ry);
         }
      }
}

void afisare()
{int i;
 fout<<costmin<<'\n'<<n-1<<'\n';
 for(i=1; i<n; i++)
     fout<<apm[i].x<<' '<<apm[i].y<<'\n';
}



