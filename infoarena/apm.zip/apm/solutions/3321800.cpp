#include <bits/stdc++.h>

using namespace std;
struct muchie {
    int x,y,cost;
};
int p[200001], H[200001],N,M;
long long cost_total;
vector<muchie> muchii;
vector<pair<int, int>> muchii_finale;

int Find(int x) {
    if (x==p[x]) {
        return x;
    }
    return p[x]=Find(p[x]);
}
void Union(int x,int y)
{
    x=Find(x);
    y=Find(y);
    if(x!=y) {
        if(H[x]<H[y])
            p[x]=y;
        else
            if(H[y]<H[x])
                p[y]=x;
            else
                p[x]=y, H[y]++;
    }
}
bool compara(const muchie& a, const muchie& b) {
    return a.cost<b.cost;
}
ifstream f("apm.in");
ofstream g("apm.out");
int main()
{
    f>>N>>M;
    for(int i=0;i<M;i++)
    {
        int x,y,c;
        f>>x>>y>>c;
        muchii.push_back({x,y,c});
    }
    for(int i=1;i<=N;i++)
    {
        p[i]=i;
        H[i]=1;
    }
    sort(muchii.begin(),muchii.end(),compara);
    for(muchie& mc : muchii) {
        if(Find(mc.x)!=Find(mc.y)) {
            cost_total+=mc.cost;
            muchii_finale.push_back({mc.y, mc.x});
            Union(mc.x,mc.y);
        }
        if(muchii_finale.size()==N-1)
            break;
    }
    g<<cost_total<<"\n";
    g<<muchii_finale.size()<<"\n";
    for(pair<int, int>& mc : muchii_finale) {
        g<<mc.first<<" "<<mc.second<<"\n";
    }
    f.close();
    g.close();
    return 0;
}
