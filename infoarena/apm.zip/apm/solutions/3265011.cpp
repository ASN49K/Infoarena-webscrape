#include <fstream>
#include <queue>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;
ifstream cin("apm.in");
ofstream cout("apm.out");
struct numar
{
    int x,y,c;
}v[400005],apm[200005];
int n,m,t[200005],l[200005],k,sol;
int cmp(numar a,numar b)
{
    return a.c<b.c;
}
int radacina(int x)
{
    while(t[x]!=x)
        x=t[x];
    return x;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n; i++)
        t[i]=i,l[i]=1;
    for(int i=1;i<=m;i++)
        cin>>v[i].x>>v[i].y>>v[i].c;
    sort(v+1,v+m+1,cmp);
    for(int i=1;i<=m;i++)
    {
        int rx=radacina(v[i].x);
        int ry=radacina(v[i].y);
        if(rx!=ry)
        {
            sol+=v[i].c;
            apm[++k]={v[i].x,v[i].y,v[i].c};
            if(l[rx]<=l[ry])
            {
                l[ry]+=l[rx];
                t[rx]=ry;
            }
            else
            {
                l[rx]+=l[ry];
                t[ry]=rx;
            }
        }
    }
    cout<<sol<<'\n'<<k<<'\n';
    for(int i=1;i<=k;i++)
        cout<<apm[i].x<<" "<<apm[i].y<<'\n';
    return 0;
}
