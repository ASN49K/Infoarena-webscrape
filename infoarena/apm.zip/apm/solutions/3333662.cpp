#include <bits/stdc++.h>

using namespace std;

ifstream f("apm.in");
ofstream g("apm.out");
const int nmax=1e5+5;
struct muchie
{
    int x,y,c;

} v[120005];
vector <muchie> afis;
vector < int > arb[nmax];
int m,n,whr[nmax];
int Cost;
bool mrg ( int n1, int n2)
{
    if(whr[n1]==whr[n2])
        return false;

    if(arb[n1].size()<arb[n2].size())
        swap(n1,n2);
    //cout<<n1<<' '<<n2;

    int des =whr[n1];
    int sour=whr[n2];
    for(auto el : arb[sour])
    {
        arb[des].push_back (el);
        whr[el]=des;


    }

    return true;


}
bool cmp (muchie a,muchie b)
{

    return a.c<b.c;
}


int main()
{
    f>>n>>m;
    int p;
    for(int i=1; i<=m; i++)
    {

            f>>v[i].x>>v[i].y>>v[i].c;
    }
    for(int i=1; i<=n; i++)
    {
        whr[i]=i;
        arb[i]= {i};
    }
    int n1,n2;
    sort(v+1,v+m+1,cmp);

    for(int i=1; i<=m; i++)
    {
        n1=v[i].x;
        n2=v[i].y;
        if(mrg(n1,n2))
        {
            Cost+=v[i].c;
            afis.push_back(v[i]);

        }

    }

g<<Cost<<'\n';
g<<afis.size()<<'\n';
    for(auto it : afis)
    {
        g<<it.x<<' '<<it.y<<'\n';
    }
    return 0;
}