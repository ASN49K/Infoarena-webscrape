#include <bits/stdc++.h>
using namespace std;
ifstream f("apm.in");
ofstream g("apm.out");
int m,n,i,i,j,parent[200003],zs[200003];
struct {
    int u;
    int v;
}e[400002];

int main()
{   f>>n>>m;

    return 0;
}
