#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
const int NMAX = 200001,INF = 1<<20;

struct muchie
{
    int y,w;
    muchie(int yy=0,int ww=0): y(yy), w(ww){}

    bool operator <(const muchie &m)const
    {
        return w>m.w;
    }
};

int N,M, COST;
int T[NMAX], D[NMAX];

priority_queue<muchie> Q;
vector<muchie> G[NMAX];

bool viz[NMAX];

void citire()
{
    ifstream f("apm.in");
    f>>N>>M;
    int x,y, cost;
    for(int i=1; i<=M; i++)
    {
        f>>x>>y>>cost;
        G[x].push_back(muchie(y,cost));
        G[y].push_back(muchie(x,cost));
    }
    f.close();
}

void Prim()
{
    for(int i=2;i<=N;i++)
        D[i]=INF;
    Q.push(muchie(1,0));
    while(!Q.empty())
    {
        int x=Q.top().y;
        Q.pop();
        if(viz[x])continue;
        viz[x]=1;
        COST+=D[x];
        for(auto &m: G[x])
            if(m.w<D[m.y]&&!viz[m.y])
        {
            T[m.y]=x;
            D[m.y]=m.w;
            Q.push(m);
        }
    }
}
void afisare()
{
    ofstream g("apm.out");
    g<<COST<<'\n';
    for(int i=1;i<=N;i++)
        g<<T[i]<<' ';
    g.close();
}
int main()
{
    citire();
    Prim();
    afisare();
    return 0;
}
