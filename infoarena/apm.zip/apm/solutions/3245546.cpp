#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n,m,tata[200001],cnt,sol;
struct muchie{
    bool ok;
    int x,y,cost;
}v[400001];
int cmp(muchie a, muchie b){
    return a.cost<b.cost;
}
int radacina(int x){
    while(tata[x]>0)
        x=tata[x];
    return x;
}
void unif(int x,int y){
    if(tata[x]<tata[y]){
        tata[x]+=tata[y];
        tata[y]=x;
    }else{
        tata[y]+=tata[x];
        tata[x]=y;
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
        fin>>v[i].x>>v[i].y>>v[i].cost;

    sort(v+1,v+m+1,cmp);

    for(int i=1;i<=n;i++)
        tata[i]=-1;

    for(int i=1;i<=m && cnt<n-1;i++){
        int rx = radacina(v[i].x);
        int ry = radacina(v[i].y);
        if(rx!=ry){
            cnt++;
            sol+=v[i].cost;
            unif(rx,ry);
            v[i].ok=1;
        }
    }
    fout<<sol<<"\n"<<n-1<<"\n";
    for(int i=1;i<=m;i++)
        if(v[i].ok==1)
            fout<<v[i].x<<" "<<v[i].y<<"\n";
    return 0;
}
