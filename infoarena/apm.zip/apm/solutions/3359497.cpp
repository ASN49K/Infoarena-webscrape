#include <fstream>
#include <vector>
#include <queue>
#include <climits>
#include <bitset>

using namespace std;

ifstream cin("apm.in");
ofstream cout("apm.out");

int n, m;
vector<vector<pair<int, int>>> graf;
bitset<(int)(2e5 + 2)> viz;
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
vector<int> parent, dist;
int total_cost = 0;

void prim() {
    dist[1] = 0;
    pq.push({0, 1});
    while (!pq.empty()) {
        auto [current_min_dist, current_min_node] = pq.top();
        pq.pop();
        if (!viz[current_min_node]) {
            for (auto [neighbor_node, neighbor_dist] : graf[current_min_node]) {
                if (!viz[neighbor_node] && neighbor_dist < dist[neighbor_node]) {
                    dist[neighbor_node] = neighbor_dist;
                    pq.push({dist[neighbor_node], neighbor_node});
                    parent[neighbor_node] = current_min_node;
                }
            }
            viz[current_min_node] = 1;
            total_cost += current_min_dist;
        }
    }
}

int main() {
    cin >> n >> m;
    graf.resize(n + 2);
    parent.assign(n + 2, 0);
    dist.assign(n + 2, INT_MAX);
    for (int i = 0 ; i < m ; ++i) {
        int src, dest, cost;
        cin >> src >> dest >> cost;
        graf[src].push_back({dest, cost});
        graf[dest].push_back({src, cost});
    }
    prim();
    cout << total_cost << "\n" << n - 1 << "\n";
    for (int i = 2 ; i <= n ; ++i) {
        cout << parent[i] << " " << i << "\n";
    }
    return 0;
}