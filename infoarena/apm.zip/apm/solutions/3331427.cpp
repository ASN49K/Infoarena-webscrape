#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

ifstream be("apm.in");
ofstream ki("apm.out");

int main()
{
    int n, m;
    be >> n >> m;

    vector<vector<pair<int, int>>> e(n + 1);
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;

    for(int i = 0; i < m; i++)
    {
        int x, y, c;
        be >> x >> y >> c;

        e[x].push_back({y, c});
        e[y].push_back({x, c});
    }

    vector<char> vis(n + 1);
    vector<int> best(n + 1, INT_MAX);
    vector<int> parent(n + 1, -1);

    best[1] = 0;
    pq.push({0, 1});

    int sum = 0;

    vector<pair<int,int>> ans;

    while(!pq.empty())
    {
        int c = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if(vis[u]) continue;

        vis[u] = 1;
        sum += c;

        if(u != 1)
        {
            ans.push_back({parent[u], u});
        }

        for(pair<int, int> j : e[u])
        {
            int v = j.first;
            int w = j.second;

            if(!vis[v] && w < best[v])
            {
                best[v] = w;
                parent[v] = u;

                pq.push({w, v});
            }
        }
    }
        
    ki << sum << "\n" << ans.size() << "\n";

    for(pair<int, int> i : ans)
    {
        ki << i.first << " " << i.second << "\n";
    }

    return 0;
}