#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
struct nod
{
    int nod, cost;
} p;
struct comparecost
{
    bool operator()(const nod& a, const nod& b)
    {
        return a.cost>b.cost;
    }
};
priority_queue<nod, vector<nod>, comparecost> h;
int n, m, i, j, x, y, cost;
vector <nod> v[200005];
bool viz[200005];
int dist[200005], tata[200005];
int sum;
void apm()
{
    h.push({1, 0});
    while(!h.empty())
    {
        p=h.top();
        h.pop();
        viz[p.nod]=1;
        for(vector <nod>::iterator it=v[p.nod].begin(); it!=v[p.nod].end(); it++)
        {
            if(dist[it->nod]>it->cost && viz[it->nod]==0)
            {
                if(dist[it->nod]!=2e9)
                    sum-=dist[it->nod];
                sum+=it->cost;
                dist[it->nod]=it->cost;
                tata[it->nod]=p.nod;
                h.push({it->nod, dist[it->nod]});
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>cost;
        v[x].push_back({y, cost});
        v[y].push_back({x, cost});
    }
    for(i=2; i<=n; i++)
        dist[i]=2e9;
    apm();
    fout<<sum<<'\n';
    fout<<n-1<<'\n';
    for(i=2; i<=n; i++)
        fout<<i<<" "<<tata[i]<<'\n';
    return 0;
}
