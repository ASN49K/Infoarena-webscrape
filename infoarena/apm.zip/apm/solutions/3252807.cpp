#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int NMAX = 1e5;
const int INF = 1e9;
int d[NMAX + 1];
vector<pair<int, int>> G[NMAX + 1];
int vis[NMAX + 1];
int p[NMAX + 1];

int main()
{
    ifstream f("apm.in");
    ofstream g("apm.out");
    int n, m;
    f >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y, c;
        f >> x >> y >> c;
        G[x].push_back({y, c});
        G[y].push_back({x, c});
    }
    for(int i = 1; i <= n; i++) {
        d[i] = INF;
    }
    d[1] = 0;
    int sum = 0;
    set<pair<int, int>> s;
    s.insert({0, 1});
    while(!s.empty()) {
        auto x = s.begin();
        s.erase(x);
        int cost = (*x).first;
        int node = (*x).second;
        if(vis[node]) {
            continue;
        }
        sum += cost;
        vis[node] = 1;
        for(auto it : G[node]) {
            if(d[it.first] > it.second && !vis[it.first]) {
                //s.erase({d[it.first], it.first});
                d[it.first] = it.second;
                s.insert({d[it.first], it.first});
                p[it.first] = node;
            }
        }

    }
    /*for(int i = 1; i <= n; i++) {
        int minim = INF;
        int node = 0;
        for(int j = 1; j <= n; j++) {
            if(d[j] < minim && !vis[j]) {
                minim = d[j];
                node = j;
            }
        }
        vis[node] = 1;
        sum += minim;
        for(auto it : G[node]) {
            if(d[it.first] > it.second && !vis[it.first]) {
                d[it.first] = it.second;
                p[it.first] = node;
            }
        }
    }*/
    g << sum << '\n';
    g << n - 1 << '\n';
    for(int i = 2; i <= n; i++) {
        g << i << ' ' << p[i] << '\n';
    }
    return 0;
}
