#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <climits>

using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");


vector<pair<int,int>> L [200001];
priority_queue<pair<int,int>> pq;
int viz[200001],p[200001], d[200001];

int main()
{
    int n,m,sol=0;
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        int x,y,c;
        fin>>x>>y>>c;
        L[y].push_back({x,c});
        L[x].push_back({y,c});
    }

    for(int i=1;i<=n;i++){
        d[i]=INT_MAX;
    }
    d[1]=0;
    vector<pair<int,int>> M;
    pq.push({-d[1],1});
    while(pq.size() > 0)
    {
        int cost = pq.top().first;
        int nod = pq.top().second;
        pq.pop();

        if(viz[nod] != 1)
        {
            viz[nod] = 1;
            sol += cost;
            if(nod != 1)M.push_back({nod, p[nod]});
            for(auto m: L[nod])
            {
                if(d[m.first] > m.second)
                {
                    d[m.first] = m.second;
                    pq.push({-d[m.first], m.first});
                    p[m.first] = nod;
                }
            }
        }
    }

    fout<<(-1)*sol<<"\n";
    fout<<M.size()<<"\n";

     for (int i = 0; i < M.size(); i++) {
        fout << M[i].first << " " << M[i].second << "\n";
    }
    fout.close();
}
