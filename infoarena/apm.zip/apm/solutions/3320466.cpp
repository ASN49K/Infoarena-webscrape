#include <iostream>
#include <fstream>
#include <tuple>
#include <vector>
#include <algorithm>
using namespace std;
ifstream f("apm.in");
ofstream g("apm.out");
int n,m,i,x,cost_total,nr,y,c,p[200001],h[200001];
vector<tuple<int, int, int>> muchii;
vector<int> v[200001];
int findd(int x)
{
    while(x!=p[x])
        x=p[x];
    return x;
}
int main()
{
    f>>n>>m;
     for(i=1;i<=n;++i)
    {
        p[i]=i;
        h[i]=1;
    }
    for(i=1;i<=m;++i)
    {
       f>>x>>y>>c;
        muchii.push_back(make_tuple(c,x,y));
    }
    sort(muchii.begin(),muchii.end());
    for(i=0;i<m;++i)
    {
        int nod1=get<1>(muchii[i]);
        int nod2=get<2>(muchii[i]);
        int cost=get<0>(muchii[i]);
        int r1=findd(nod1);
        int r2=findd(nod2);
        if(r1!=r2)
        {
        if(h[r1]>h[r2])
         p[r2]=r1;
        else
            if(h[r1]<h[r2])
                p[r1]=r2;
            else
            {
                    p[r2]=r1;
                    h[r1]++;
            }
             ++nr;
            v[nr].push_back(nod1);
            v[nr].push_back(nod2);
            cost_total+=cost;
        }

    }
   g<<cost_total<<endl;
   g<<nr<<endl;
    for(i=1;i<=nr;++i)
       g<<v[i][0]<<' '<<v[i][1]<<endl;

    return 0;
}
