#include <fstream>
#include <algorithm>
#define nmax (int)(2e5+1)
using namespace std;
ifstream cin("apm.in");
ofstream cout("apm.out");
int n,m,t[nmax],cost,nr;
bool in[nmax*2];
struct muchie{
    int x,y,c;
}v[nmax*2];
int get_root(int x){
    if(t[x]>0)
        return t[x]=get_root(t[x]);
    return x;
}
bool join(int x,int y){
    x=get_root(x),y=get_root(y);
    if(x==y)
        return 0;
    if(t[x]>t[y])
        swap(x,y);
    t[x]+=t[y];
    t[y]=x;
    return 1;
}
bool cmp(const muchie& a,const muchie& b){
    return a.c<b.c;
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        t[i]=-1;
    for(int i=1;i<=m;i++)
        cin>>v[i].x>>v[i].y>>v[i].c;
    sort(v+1,v+m+1,cmp);
    for(int i=1;i<=m;i++)
        if(join(v[i].x,v[i].y)){
            cost+=v[i].c;
            in[i]=1;
            nr++;
        }
    cout<<cost<<'\n'<<nr<<'\n';
    for(int i=1;i<=m;i++)
        if(in[i])
            cout<<v[i].x<<" "<<v[i].y<<'\n';
    return 0;
}
