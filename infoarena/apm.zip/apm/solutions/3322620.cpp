#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

vector<pair<int, int>> prim(vector<vector<pair<int,int>>> &la, int N, int &costTotal) {
    priority_queue<pair<int,int>, vector<pair<int, int>>, greater<pair<int,int>>> pq;
    vector<int> d(N+1, 1e9);
    vector<int> tata(N+1, 0);
    vector<int> viz(N+1, 0);

    d[1] = 0;
    pq.push({d[1], 1});

    while(!pq.empty()) {
        pair<int, int> p = pq.top();
        pq.pop();

        if (viz[p.second] == 1)
            continue;
        viz[p.second] = 1;

        for (auto& nod : la[p.second]) {
            int vf = nod.first;
            int cost = nod.second;
            if (d[vf] > cost && viz[vf] == 0) {
                tata[vf] = p.second;
                d[vf] = cost;
                pq.push({d[vf], vf});

            }
        }
     }


    vector<pair<int, int>> apcm;
    costTotal = 0;
    for (int i = 1; i <= N; i++) {
        if (tata[i] != 0) {
            apcm.push_back({i, tata[i]});
            costTotal += d[i];
        }
    }
    return apcm;
}
int main() {
    int N, M;
    fin >> N >> M;
    vector<vector<pair<int,int>>> la(N+1);

    for (int i = 0; i < M; i++) {
        int x, y, cost;
        fin >> x >> y >> cost;
        la[x].push_back({y, cost});
        la[y].push_back({x, cost});
    }

    int costTotal = 0;
    vector<pair<int, int>> apcm = prim(la, N, costTotal);
    
    fout << costTotal << endl;
    fout << apcm.size() << endl;
    for (auto& m : apcm) {
        fout << m.first << " " << m.second << endl;
    }

    fin.close();
    fout.close();
    return 0;
}