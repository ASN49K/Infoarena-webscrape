#include <bits/stdc++.h>

using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

int n, m, x, y, c, sol = 0;

const int nmax = 400000;
vector< pair<int, int> > adj[nmax + 1];
vector<int> d, vis, p;
priority_queue< pair<int, int> > pq;

int main() {
    fin >> n >> m;
    for(int i = 1; i <= m; i ++){
        fin >> x >> y >> c;

        adj[x].push_back({y, c});
        adj[y].push_back({x, c});
    }

    d.resize(n + 1);
    vis.resize(n + 1);
    p.resize(n + 1);
    for(int i = 1; i <= n; i ++) {
        d[i] = INT_MAX;
        vis[i] = 0;
        p[i] = 0;
    }
    d[1] = 0;

    pq.push({-d[1], 1});

    while(!pq.empty()){
        int nod = pq.top().second;
        pq.pop();
        if(vis[nod] == 1){
            continue;
        }
        vis[nod] = 1;
        sol += d[nod];

        for(auto &vecin : adj[nod]) {
            x = vecin.first, c = vecin.second;
            if(!vis[x] && d[x] > c) {
                d[x] = c;
                pq.push({-d[x], x});
                p[x] = nod;
            }
        }
    }

    fout << sol << '\n' << n - 1 << '\n';
    for(int i = 2; i <= n; i ++) {
        fout << i << ' ' << p[i] << '\n'; 
    }

    return 0;
}