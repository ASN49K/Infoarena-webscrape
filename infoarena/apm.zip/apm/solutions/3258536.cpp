///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 1000000007
using namespace std;
ifstream fin("circular.in");
ofstream fout("circular.out");
struct ceva
{
    int x,y,d;
} v[6000];
int i,j,n,m,t[110],a,b,s;
bool cmp(ceva a,ceva b)
{
    return a.d<b.d;
}
queue <int> q;
int adop(int a)
{
    int b=a,x;
    while(a!=t[a])
        a=t[a];
    while(b!=t[a])
    {
        x=t[b];
        t[b]=a;
        b=x;
    }
    return t[a];
}
void up(int a,int b)
{
    int ta=adop(a);
    int tb=adop(b);
    t[ta]=tb;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n>>m;
    for(i=1; i<=n; i++)
        t[i]=i;
    for(i=1; i<=m; i++)
        fin>>v[i].x>>v[i].y>>v[i].d;
    sort(v+1,v+1+m,cmp);
    for(i=1; i<=m; i++)
    {
        a=v[i].x;
        b=v[i].y;
        if(adop(a)!=adop(b))
        {
            up(a,b);
            s+=v[i].d;
            q.push(i);
        }
    }
    fout<<s<<'\n'<<q.size()<<'\n';
    while(!q.empty())
    {
        fout<<v[q.front()].y<<" "<<v[q.front()].x<<'\n';
        q.pop();
    }
    return 0;
}
