#include <fstream>
#include <queue>
using namespace std;
ifstream cin("apm.in");
ofstream cout("apm.out");
const int INF = 0x3F3F3F3F;
int n, m, x, y, z;
long long s;
vector<vector<pair<int, int>>> graf;
vector<int> viz, d, parent;
vector<pair<int, int>> ans;
void prim(int node)
{
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    d[node] = 0;
    q.push({0, node});
    while(!q.empty())
    {
        node = q.top().second;
        q.pop();
        if(!viz[node])
        {
            s += d[node];
            if(parent[node])
                ans.push_back({node, parent[node]});
            for(auto next:graf[node])
                if(next.second < d[next.first])
                {
                    d[next.first] = next.second;
                    parent[next.first] = node;
                    q.push({d[next.first], next.first});
                }
            viz[node] = 1;
        }

    }
}
int main()
{
    cin >> n >> m;
    graf.assign(n+1, vector<pair<int, int>>());
    viz.resize(n+1);
    d.resize(n+1, INF);
    parent.resize(n+1);
    while(m--)
    {
        cin >> x >> y >> z;
        graf[x].push_back({y, z});
        graf[y].push_back({x, z});
    }
    prim(1);
    cout << s << '\n';
    cout << ans.size() << '\n';
    for(auto i:ans)
        cout << i.first << " " << i.second << '\n';
    return 0;
}
