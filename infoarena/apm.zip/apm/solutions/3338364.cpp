#include <fstream>
#include <iostream>
#include <vector>
#include <utility>
#include <queue>
#include <functional>
#define ll long long
using namespace std;
ifstream fin("apm.in");
ofstream gout("apm.out");
struct muchie
{
    int x,y,d;
    muchie(int xx=0,int yy=0,int dd=0)
    {
        d=dd;
        x=xx;
        y=yy;
    }
    bool operator<(const muchie &a)const
    {
        return a.d<d;
    }
};
int gaseste(int &x,vector<int>&t)
{
    if(!t[x])return x;
    return t[x]=gaseste(t[x],t);
}
void unire(int &a,int &b,vector<int>&t)
{
    int x=gaseste(a,t),y=gaseste(b,t);
    if(x!=y)t[x]=y;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    gout.tie(0);
    int n,m,x,y,d;
    fin>>n>>m;
    priority_queue<muchie>q,ans;
    muchie a;
    vector<int>t(n+1,0);
    while(m--)
    {
        fin>>x>>y>>d;
        q.push(muchie(x,y,d));
    }
    d=0;
    while(!q.empty())
    {
        a=q.top();
        q.pop();
        if(gaseste(a.x,t)!=gaseste(a.y,t))
        {
            unire(a.x,a.y,t);
            d+=a.d;
            ans.push(a);
        }
    }
    gout<<d<<'\n'<<ans.size()<<'\n';
    while(!ans.empty())
    {
        gout<<ans.top().x<<' '<<ans.top().y<<'\n';
        ans.pop();
    }
    return 0;
}
