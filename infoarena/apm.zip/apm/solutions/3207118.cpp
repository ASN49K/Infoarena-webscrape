#include <bits/stdc++.h>

using namespace std;

ifstream f("apm.in");
ofstream g("apm.out");

int r[200005],t[200005];

struct muchie
{
    int x,y,cost,marcat;
};

muchie a[400005];

int radacina(int x)
{
    int root,x1,aux;
    x1=x;
    while(t[x]!=x)
    {
        x=t[x];
    }
    root=x;
    x=x1;
    while(t[x]!=x)
    {
        aux=x;
        x=t[x];
        t[aux]=root;
    }
    return root;
}

void join(int x,int y)
{
    x=radacina(x);
    y=radacina(y);
    if(r[x]>=r[y])
    {
        t[y]=t[x];
        r[x]++;
    }
    else
    {
        t[x]=t[y];
        r[y]++;
    }
}

bool compar(muchie x,muchie y)
{
    return(x.cost<=y.cost);
}

int main()
{int n,m,i,j,nrm=0,x,y,s=0;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>a[i].x>>a[i].y>>a[i].cost;
    }
    sort(a+1,a+m+1,compar);
    for(i=1;i<=n;i++)
    {
        t[i]=i;
        r[i]=1;
    }
    for(i=1;i<=m;i++)
    {
        if(nrm==n-1)
        {
            break;
        }
        x=a[i].x; y=a[i].y;
        x=radacina(x); y=radacina(y);
        if(x!=y)
        {
            a[i].marcat=1;
            nrm++;
            s=s+a[i].cost;
            join(x,y);
        }
    }
    g<<s<<'\n';
    for(i=1;i<=m;i++)
    {
        if(a[i].marcat)
        {
            g<<a[i].x<<" "<<a[i].y<<'\n';
        }
    }
    return 0;
}
