#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("apm.in");
ofstream cout("apm.out");
const int Nmax = 200005;
const int Mmax = 400005;
int n, m, s;
vector<int> parents, rang;
vector<pair<int, int>> ans;
struct muchie
{
    int x, y, c;
}v[Mmax];
bool cmp(muchie x, muchie y)
{
    return x.c < y.c;
}
int findroot(int node)
{
    if(node == parents[node])
        return node;
    parents[node] = findroot(parents[node]);
    return parents[node];
}
void unionset(int node1, int node2)
{
    node1 = findroot(node1);
    node2 = findroot(node2);
    if(node1 == node2)
        return;
    if(rang[node1] < rang[node2])
        swap(node1, node2);
    if(rang[node1] == rang[node2])
        rang[node1]++;
    parents[node2] = node1;
}
int main()
{
    cin >> n >> m;
    parents.resize(n+1);
    rang.resize(n+1);
    for(int i=1; i<=n; i++)
    {
        parents[i] = i;
        rang[i] = 1;
    }
    for(int i=1; i<=m; i++)
        cin >> v[i].x >> v[i].y >> v[i].c;
    sort(v+1, v+m+1, cmp);
    for(int i=1; i<=m; i++)
        if(findroot(v[i].x) != findroot(v[i].y))
        {
            s += v[i].c;
            ans.push_back({v[i].x, v[i].y});
            unionset(v[i].x, v[i].y);
        }
    cout << s << '\n' << n-1 << '\n';
    for(auto i:ans)
        cout << i.first << " " << i.second << '\n';
    return 0;
}
