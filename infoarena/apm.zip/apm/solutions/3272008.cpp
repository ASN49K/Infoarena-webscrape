#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ull unsigned ll
#define vec vector
#define flist forward_list
#define um unordered_map
#define us unordered_set
#define prioq priority_queue
#define all(x) x.begin(), x.end()
#define pb push_back
#define pf push_front
#define fi first
#define se second
#define ld long double
#define pll pair<ll, ll>
#define tll tuple<ll, ll, ll>
#define ass assign
#define fun function

#define LL_MAX LLONG_MAX
#define LL_MIN LLONG_MIN
#define ULL_MAX ULLONG_MAX
#define LD_MAX LDBL_MAX
#define LD_MIN LDBL_MIN

#define nl '\n'

#define vv(type, name, n, ...) vector<vector<type>> name(n, vector<type>(__VA_ARGS__))
#define vvv(type, name, n, m, ...)                                                                                     \
    vector<vector<vector<type>>> name(n, vector<vector<type>>(m, vector<type>(__VA_ARGS__)))

// https://trap.jp/post/1224/
#define rep1(n) for(ll i=0; i<(ll)(n); ++i)
#define rep2(i,n) for(ll i=0; i<(ll)(n); ++i)
#define rep3(i,a,b) for(ll i=(ll)(a); i<(ll)(b); ++i)
#define rep4(i,a,b,c) for(ll i=(ll)(a); i<(ll)(b); i+=(c))
#define cut4(a,b,c,d,e,...) e
#define rep(...) cut4(__VA_ARGS__,rep4,rep3,rep2,rep1)(__VA_ARGS__)
#define rep1e(n) for(ll i=1; i<=(ll)(n); ++i)
#define rep2e(i,n) for(ll i=1; i<=(ll)(n); ++i)
#define rep3e(i,a,b) for(ll i=(ll)(a); i<=(ll)(b); ++i)
#define rep4e(i,a,b,c) for(ll i=(ll)(a); i<=(ll)(b); i+=(c))
#define repe(...) cut4(__VA_ARGS__,rep4e,rep3e,rep2e,rep1e)(__VA_ARGS__)
#define per1(n) for(ll i=((ll)n)-1; i>=0; --i)
#define per2(i,n) for(ll i=((ll)n)-1; i>=0; --i)
#define per3(i,a,b) for(ll i=((ll)a)-1; i>=(ll)(b); --i)
#define per4(i,a,b,c) for(ll i=((ll)a)-1; i>=(ll)(b); i-=(c))
#define per(...) cut4(__VA_ARGS__,per4,per3,per2,per1)(__VA_ARGS__)
#define per1e(n) for(ll i=((ll)n); i>=1; --i)
#define per2e(i,n) for(ll i=((ll)n); i>=1; --i)
#define per3e(i,a,b) for(ll i=((ll)a); i>=(ll)(b); --i)
#define per4e(i,a,b,c) for(ll i=((ll)a); i>=(ll)(b); i-=(c))
#define pere(...) cut4(__VA_ARGS__,per4e,per3e,per2e,per1e)(__VA_ARGS__)
#define rep_subset(i,s) for(ll i=(s); i>=0; i=(i==0?-1:(i-1)&(s)))
// #define forit(v) for (auto it = v.begin(); it != v.end(); it++)
// #define forit2(it, v) for (auto it = v.begin(); it != v.end(); it++)
// #define forrit(v) for (auto it = v.rbegin(); it != v.rend(); it++)
// #define forrit2(it, v) for (auto it = v.rbegin(); it != v.rend(); it++)

// #ifdef i_am_noob
#define bug(...) cerr << "#" << __LINE__ << ' ' << #__VA_ARGS__ << "- ", _do(__VA_ARGS__)
template<typename T> void _do(vector<vector<T>> x){cerr << "\n"; for(auto i: x) {for(auto j : i) {cerr << j << ' ';} cerr << "\n";}}
template<typename T> void _do(vector<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(unordered_set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(T && x) {cerr << x << endl;}
template<typename T, typename ...S> void _do(T && x, S&&...y) {cerr << x << ", "; _do(y...);}
// #else
// #define bug(...) 777771449
// #endif

const ll MOD = 1e9 + 7;
const ll INF = (1ll << 59);

const string FILENAME = "apm";
ifstream fin(FILENAME + ".in");
ofstream fout(FILENAME + ".out");

#define cin fin
#define cout fout

class Dsu
{
public:

	vec<ll> parent, size;
	
	void build(ll n)
	{
		parent.ass(n,-1);
		size.ass(n,1);
	}	
	ll find(ll a)
	{
		if(parent[a] == -1) return a;
		return parent[a] = find(parent[a]);
	}
	void unite(ll a, ll b)
	{
		a = find(a), b= find(b);
		if(a == b) return;
		if(size[a]<size[b])swap(a,b);
		size[a]+=size[b];
		parent[b]=a;
	}
};

class Graph
{
public:

	ll n, m;
	vec<flist<pll>> adj;
	
	void read();
};

void prim(Graph *g, ll start, vec<tll>&sel)
{
	sel.reserve(g->n-1);
	vec<bool> vis(g->n,0);
	vec<ll> dist(g->n,INF);
	prioq<tll,vec<tll>,greater<tll>>nn;
	nn.push({-INF,start,0});
	dist[start]=-INF;
	while(!nn.empty())
	{
		ll u,v,d;
		tie(d,u,v)=nn.top();nn.pop();
		if(dist[u]<d)continue;
		if(u!=start)sel.pb({u,v,d});
		vis[u]=1;
		for(auto v:g->adj[u])if(!vis[v.fi]&&dist[v.fi]>v.se)
		{
			dist[v.fi]=v.se;
			nn.push({v.se,v.fi,u});
		}
	}
}

int main()
{
	Graph g;
	g.read();
	
    return 0;
}

void Graph::read()
{
	cin >> n >> m;
	adj.resize(n);
	rep(m)
	{
		ll a,b,c;
		cin >> a >> b >> c;
		a--, b--;
		adj[a].pf({b,c});
		adj[b].pf({a,c});
	}
	
	vec<tll> sel;
	prim(this, 0, sel);
	
	ll sum = 0;
	for(auto& e : sel)
	{
		sum += get<2>(e);
	}
	
	cout << sum << nl << sel.size() << nl;
	for(auto& e : sel) cout << get<0>(e)+1 << ' ' << get<1>(e)+1 << nl;
}