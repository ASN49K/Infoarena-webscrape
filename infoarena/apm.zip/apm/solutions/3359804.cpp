#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n, m, i, j, x, y, c, dist[200005], ans, parent[200005], sze[200005];
int find_set(int nod)
{
    if(parent[nod]==nod)
        return nod;
    return parent[nod]=find_set(parent[nod]);
}
void union_set(int a, int b)
{
    a=find_set(a);
    b=find_set(b);
    if(a!=b)
    {
        if(sze[a]>sze[b])
            swap(a, b);
        parent[b]=a;
        sze[a]+=sze[b];
    }
}
set <tuple<int, int, int>> s;
set <pair<int, int>> s2;
int main()
{
    fin>>n>>m;
    for(i=1; i<=n; i++)
    {
        parent[i]=i;
        sze[i]=1;
    }
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>c;
        s.insert(make_tuple(c, x, y));
    }
    for(auto i: s)
    {
        int c=get<0>(i);
        int x=get<1>(i);
        int y=get<2>(i);
        if(find_set(x)!=find_set(y))
        {
            s2.insert({x, y});
            union_set(x, y);
            ans+=c;
        }
    }
    fout<<ans<<" "<<n-1<<'\n';
    for(auto i: s2)
        fout<<i.first<<" "<<i.second<<'\n';
    return 0;
}
