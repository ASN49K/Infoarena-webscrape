#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin ("apm.in");
ofstream fout("apm.out");

int n,m;
struct vec
{
    int x;
    int y;
    int cost;
    bool ok;
}v[400001];
int tata[200001];
int cnt;
bool cmp(vec a, vec b)
{
    return a.cost<b.cost;
}
int root(int x)
{
    while(tata[x]>0)
        x=tata[x];
    return x;
}
void unif(int x, int y)
{
    if(tata[x]<tata[y])
    {
        tata[x]+=tata[y];
        tata[y]=x;
    }
    else
    {
        tata[y]+=tata[x];
        tata[x]=y;
    }
}
int sol;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
        fin>>v[i].x>>v[i].y>>v[i].cost;
    sort(v+1,v+m+1,cmp);
    for(int i=1;i<=n;i++)
        tata[i]=-1;
    cnt=0;
    for(int i=1;i<=m && cnt<n-1;i++)
    {
        int rx=root(v[i].x);
        int ry=root(v[i].y);
        if(rx!=ry)
        {
            cnt++;
            sol+=v[i].cost;
            unif(rx,ry);
            v[i].ok=1;
        }
    }
    fout<<sol<<'\n'<<cnt<<'\n';
    for(int i=1;i<=m;i++)
        if(v[i].ok)
            fout<<v[i].y<<" "<<v[i].x<<'\n';
    return 0;
}
