/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <queue>
#include <vector>
#include <fstream>
using namespace std;
ifstream cin("apm.in");
ofstream cout("apm.out");
int n,m,x,y,c,nr=0;

int main()
{
    cin>>n>>m;
    vector<pair<int,int>> adj[n+1];
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y>>c;
        adj[x].push_back({y,c});
        adj[y].push_back({x,c});
    }
    priority_queue<
    pair<int,int>,
    vector<pair<int,int>>,
    greater<pair<int,int>>>pq;
    
    int dist[n+1];
    bool exista[n+1];
    dist[1] = 0;
    pq.push({0,1});
    int costtotal = 0;
    for(int i = 1; i <= n; i++) {
        dist[i] = 1e9;
        exista[i] = false;
    }
    int parinte[n+1];
    while(!pq.empty())
    {
        int cost = pq.top().first;
        int nod = pq.top().second;
        pq.pop();
        if(exista[nod])
        {
            continue;
        }
        exista[nod] = true;
        costtotal += cost;
        nr++;
        for(auto vecini:adj[nod])
        {
            int vecin = vecini.first;
            int c = vecini.second;

            if(!exista[vecin] && c < dist[vecin]) {
                dist[vecin] = c;
                parinte[vecin] = nod;
                pq.push({c, vecin});
            }
        }
    }
    cout<<costtotal<<endl;
    cout<<nr-1<<endl;
    for(int i=2;i<=n;i++)
    {
        cout<<parinte[i]<<" "<<i<<endl;
    }
    return 0;
}