﻿#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000000
#define MOD 123457
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");
int n, m,t[200001],r[200001],costmin;
struct  muchie
{
    int x,y,c;
    bool operator <(const muchie m)const
    {
        return c < m.c;
    }
}a[400001];
vector<pair<int,int>>rez;
int find(int x)
{
    if (t[x] == 0)
        return x;
    int y = find(t[x]);
    t[x] = y;
    return y;
}
void Union(int x, int y)
{
    if (t[x] > t[y])
        t[y] = x;
    else
    {
        t[x] = y;
        if (r[x] == r[y])
            r[y]++;
    }
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> a[i].x >> a[i].y >> a[i].c;
    }
    sort(a + 1, a + m + 1);
    for (int i = 1; i <= m; i++)
    {
        int x = find(a[i].x);
        int y = find(a[i].y);
        if (x != y)
        {
            rez.push_back({ a[i].x,a[i].y });
            costmin += a[i].c;
            Union(x, y);
        }
    }
    fout << costmin<<"\n";
    fout << rez.size() << "\n";
    for (int i = 0; i < rez.size(); i++)
    {
        fout << rez[i].first << " " << rez[i].second << "\n";
    }

}