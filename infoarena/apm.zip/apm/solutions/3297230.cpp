#include <bits/stdc++.h>
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

struct muchie
{
    int x, y, cost, ales;
    bool operator<(const muchie A) const
    {
        return cost < A.cost;
    }
};
muchie a[400002];
int m, n, t[200002], costMin;

void Union(int x, int y)
{
    t[y] = x;
}

int Find(int x)
{
    int y, rad;
    rad = x;
    while (t[rad] != 0)
        rad = t[rad];
    while (x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}

void Citire()
{
    int i;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
        fin >> a[i].x >> a[i].y >> a[i].cost;
}
/// O(m log m + m log *n)
void Kruskal()
{
    int x, y;
    sort(a + 1, a + m + 1);
    for (int i = 1; i <= m; i++)
    {
        x = Find(a[i].x);
        y = Find(a[i].y);
        if (x != y)
        {
            Union(x, y);
            costMin += a[i].cost;
            a[i].ales = 1;
        }
    }

    fout << costMin << "\n" << (n - 1) << "\n";
    for (int i = 1; i <= m; i++)
        if (a[i].ales == 1)
            fout << a[i].x << " " << a[i].y << "\n";
}

int main()
{
    Citire();
    Kruskal();

    return 0;
}
