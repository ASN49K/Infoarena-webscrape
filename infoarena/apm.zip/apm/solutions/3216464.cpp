#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")

using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

const int nmax = 2e5;

struct DSU {
	vector<int> t;

	DSU(const int n = nmax) {
		t.resize(n + 1);
		for(int i = 1; i <= n; i++)
			t[i] = i;
	}

	int parent(int x) {
		if(x == t[x])
			return x;
		else
			return t[x] = parent(t[x]);
	}

	void join(int x, int y) {
		int tx = parent(x), ty = parent(y);
		t[tx] = t[ty];
	}

	bool sameparent(int x, int y) {
		return (parent(x) == parent(y));
	}
};

vector<pair<int, pair<int, int>>> edge, sol;
DSU dsu;

int n, m, x, y, c, S = 0, E = 0;

void read() {
	fin >> n >> m;
	for(int i = 0; i < m; i++) {
		fin >> x >> y >> c;
		edge.push_back({c, {x, y}});
	}
}

void make_apm() {
	for(int i = 0; i < m; i++) {
		x = edge[i].second.first;
		y = edge[i].second.second;
		c = edge[i].first;
		if(dsu.sameparent(x, y))
			continue;
		else {
			dsu.join(x, y);
			S += c;
			E++;
			sol.push_back(edge[i]);
		}
	}
}

void print() {
	fout << S << "\n" << E << "\n";
	for(auto putza : sol)
		fout << putza.second.first << " " << putza.second.second << "\n";
}

int main() {
	read();
	sort(edge.begin(), edge.end());
	make_apm();
	print();
	return 0;
}
