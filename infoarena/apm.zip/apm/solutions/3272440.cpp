#include <bits/stdc++.h>
using namespace std;
const string fisier_name="apm";
ifstream fin (fisier_name+".in");
ofstream fout (fisier_name+".out");
int const lmax=200007;
int const mmax=400007;
struct muchie{
int x,y,cost;
};
muchie lista_muchii[mmax];
struct aux{
int node,cost;
};
vector<aux>G[lmax];
bool cmp(muchie m1,muchie m2)
{
    return m1.cost<m2.cost;
}
int n,m;
int t[lmax];
int root(int node)
{
    if(t[node]==0)
    {
        return node;
    }
    int father=root(t[node]);
    t[node]=father;
    return father;
}
void merger(int n1, int n2)
{
    int r1=root(n1);
    int r2=root(n2);
    if(r1!=r2)
    {
        t[r1]=r2;
    }
}
int cost_final=0;
int index_=0;
muchie rez[lmax];
int main()
{
    fin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        G[a].push_back({b,c});
        G[b].push_back({a,c});
        lista_muchii[i].x=a;
        lista_muchii[i].y=b;
        lista_muchii[i].cost=c;
    }
    sort(lista_muchii,lista_muchii+m,cmp);
    /*for(int i=0;i<m;i++)
    {
        cout<<lista_muchii[i].x<<" "<<lista_muchii[i].y<<" "<<lista_muchii[i].cost<<"\n";
    }*/
    for(int i=0;i<m;i++)
    {
        if(root(lista_muchii[i].x)!=root(lista_muchii[i].y))
        {
            merger(lista_muchii[i].x,lista_muchii[i].y);
            rez[index_].x=lista_muchii[i].x;
            rez[index_].y=lista_muchii[i].y;
            cost_final+=lista_muchii[i].cost;
            ///nu conteaza la afisare costul

            index_++;
        }
    }
    fout<<cost_final<<"\n"<<n-1<<"\n";
    for(int i=0;i<index_;i++)
    {
        fout<<rez[i].x<<" "<<rez[i].y<<"\n";
    }
    return 0;
}
