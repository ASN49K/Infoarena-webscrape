#include <bits/stdc++.h>
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

struct Muchie
{
    int x, y, cost, ales;
    bool operator<(const Muchie A) const
    {
        return cost < A.cost;
    }
};
Muchie a[400001];
int t[200002], n, m;
void Union(int x, int y)
{
    t[y] = x;
}

int Find(int x)
{
    int y, rad = x;
    while (t[rad] != 0)
        rad = t[rad];
    while (x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}

void Citire()
{
    int i;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
        fin >> a[i].x >> a[i].y >> a[i].cost;
}

void Kruskal()
{
    int i, x, y, costmin = 0;
    sort(a + 1, a + m + 1);
    for (i = 1; i <= m; i++)
    {
        x = Find(a[i].x);
        y = Find(a[i].y);
        if (x != y)
        {
            Union(x, y);
            costmin += a[i].cost;
            a[i].ales = 1;
        }
    }
    fout << costmin << "\n" << (n - 1) << "\n";
    for (i = 1; i <= m; i++)
        if (a[i].ales == 1)
            fout << a[i].x << " " << a[i].y << "\n";
}

int main()
{
    Citire();
    Kruskal();
    return 0;
}
