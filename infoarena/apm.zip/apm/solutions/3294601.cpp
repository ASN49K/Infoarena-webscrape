#include <bits/stdc++.h>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
const int NMAX = 2e5 + 1, INF = 2e9;
int n, m, ans = 0, mincost[NMAX], parent[NMAX];
bool vis[NMAX];
vector<pair<int, int>> vec[NMAX], tree;

void prim()
{
    for(int i = 1; i <= n; i++)
        mincost[i] = INF, parent[i] = -1;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, 1});
    mincost[1] = 0;
    while(!pq.empty())
    {
        auto [cost, u] = pq.top(); pq.pop();
        if(vis[u])
            continue;
        vis[u] = true;
        ans += cost;
        if(parent[u] != -1)
            tree.push_back({parent[u], u});
        for(auto [v, c] : vec[u])
        {
            if(!vis[v] && c < mincost[v])
            {
                mincost[v] = c;
                parent[v] = u;
                pq.push({mincost[v], v});
            }
        }
    }
}

int main()
{
    fin >> n >> m;
    while(m--)
    {
        int u, v, cost;
        fin >> u >> v >> cost;
        vec[u].push_back({v, cost});
        vec[v].push_back({u, cost});
    }
    prim();
    fout << ans << "\n" << tree.size() << "\n";
    for(auto edge : tree)
        fout << edge.first << " " << edge.second << "\n";

    return 0;
}
