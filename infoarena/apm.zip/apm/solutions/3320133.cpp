#include <bits/stdc++.h>
#include <fstream>
#include <queue>
#include <algorithm>
using namespace std;

//kruskal

ifstream fin("apm.in");
ofstream fout("apm.out");

int find(int nod, vector<int>& p)
{
    while(nod != p[nod])
        nod = p[nod];

    return nod;
}

void uNion(int comp1, int comp2, vector<int>& p, vector<int>& h)
{
    comp1 = find(comp1, p);
    comp2 = find(comp2, p);

    if(h[comp1] < h[comp2]) 
        p[comp1] = comp2;
    else 
        if(h[comp1] > h[comp2])
            p[comp2] = comp1;
        else 
            {
                p[comp1] = comp2;
                h[comp2] ++;
            }
}

void kruskal()
{
    struct Trio{int x, y, z;};

    vector<Trio> muchii;

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y, c;

        fin >> x >> y >> c;
        muchii.push_back({x, y, c});
    }

    sort(muchii.begin(), muchii.end(), [] (const Trio& a, const Trio& b) {
	return a.z < b.z;
	});

    vector<int> p(n + 1);

    for(int i = 1; i <= n; i ++)
        p[i] = i;

    vector<int> h(n + 1, 1);

    int sol = 0;
    vector<pair<int, int>> muchii_sol;

    for(auto elem: muchii)
    {
        if(find(elem.x, p) != find(elem.y, p))
        {
            sol += elem.z;
            muchii_sol.push_back({elem.x, elem.y});
            uNion(elem.x, elem.y, p, h);
        }
    }

    fout << sol << '\n' << muchii_sol.size() << '\n';

    for(auto m: muchii_sol)
    {
        fout << m.first << ' ' << m.second << '\n';
    }

}

int main()
{
    kruskal();
    return 0;
}