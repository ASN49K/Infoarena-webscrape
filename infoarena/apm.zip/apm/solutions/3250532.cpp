#include <fstream>
#include <queue>
#include <vector>
#define NMAX 200020

using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

struct Muchie
{
    int x,y;
    double cost;
    friend bool operator >(const Muchie&, const Muchie&);
};

bool operator >(const Muchie& m1, const Muchie& m2)
{
    return m1.cost>m2.cost;
}

int n;
int tata[NMAX], h[NMAX];
double costminim;
priority_queue<Muchie,vector<Muchie>, greater<Muchie> > H;
vector<Muchie> APM;

void citire();
void afisare();
void Union(int x, int y);
int Find(int x);

int main()
{
    int rx,ry,i;
    Muchie m;

    citire();

    while(APM.size()<n-1)
    {
        m=H.top(); H.pop();
        rx=Find(m.x); ry=Find(m.y);
        if(rx!=ry)
        {
            Union(rx,ry);
            APM.push_back(m);
            costminim+=m.cost;
        }
    }

    afisare();

    return 0;
}

void citire()
{
    int i,nrm,x,y;
    double cost;

    fin>>n>>nrm;
    for(i=1; i<=nrm; i++)
    {
        fin>>x>>y>>cost;
        H.push({x,y,cost});
    }
}

void afisare()
{
    int i;
    fout<<costminim<<'\n'<<n-1<<'\n';
    for(i=0; i<n-1; i++)
        fout<<APM[i].x<<' '<<APM[i].y<<'\n';
}

void Union(int x, int y)
{
    if(h[x]>h[y])
        tata[y]=x;
    else if(h[y]>h[x])
        tata[x]=y;
    else
    {
        tata[y]=x;
        h[x]++;
    }
}

int Find(int x)
{
    int rad,aux;

    rad=x;
    while(tata[rad]) rad=tata[rad];

    while(tata[x] && tata[x]!=rad)
    {
        aux=tata[x];
        tata[x]=rad;
        x=aux;
    }

    return rad;
}
