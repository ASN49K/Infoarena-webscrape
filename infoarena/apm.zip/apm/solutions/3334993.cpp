#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

#define INF 1e9

using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

vector<pair<int, int>> prim(int s, vector<vector<pair<int, int>>> &la, int N, int &costTotal) {
    vector<int> d(N + 1, INF), tata(N + 1, 0), viz(N + 1, 0);

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    d[s] = 0;
    pq.push({d[s], s});

    while (!pq.empty()) {
        pair<int, int> crt = pq.top();
        pq.pop();

        if (viz[crt.second] == 1) {
            continue;
        }
        viz[crt.second] = 1;

        for (auto& vecin : la[crt.second]) {
            int cost = vecin.first;
            int nod = vecin.second;

            if (viz[nod] == 0 && cost < d[nod]) {
                d[nod] = cost;
                tata[nod] = crt.second;
                pq.push({d[nod], nod});
            }
        }
    }

    vector<pair<int, int>> apcm;
    costTotal = 0;
    for (int i = 1; i <= N; i++) {
        if (tata[i] != 0) {
            apcm.push_back({i, tata[i]});
            costTotal += d[i];
        }
    }

    return apcm;
}

int main() {
    int N, M;
    fin >> N >> M;

    vector<vector<pair<int, int>>> la(N + 1);
    for (int i = 0; i < M; i++) {
        int x, y, w;
        fin >> x >> y >> w;

        la[x].push_back({w,y});
        la[y].push_back({w, x});
    }

    int costTotal = 0;
    vector<pair<int, int>> apcm = prim(1, la, N, costTotal);

    fout << costTotal << endl;
    fout << apcm.size() << endl;
    for (auto& m : apcm) {
        fout << m.first << ' ' << m.second << endl;
    }
    return 0;
}