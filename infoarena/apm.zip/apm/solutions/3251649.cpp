#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
struct apm{
    int nod1,nod2,cost;
};
apm v[400005],sol[200005];
int n,m,i,s,j;
int manager[200005];
bool cmp(apm a, apm b){
    return (a.cost < b.cost);
}
int sef_suprem(int x){
    if (manager[x]==x)
        return x;
    else {
        return sef_suprem(manager[x]);
        manager[x]=sef_suprem(manager[x]);
    }
}
void unire(int x,int y){
    int sefx=sef_suprem(x);
    int sefy=sef_suprem(y);
    manager[sefy]=sefx;
}
int main(){
    fin>>n>>m;
    for (i=1;i<=m;i++)
        fin>>v[i].nod1>>v[i].nod2>>v[i].cost;
    sort(v+1,v+m+1,cmp);
    for (i=1;i<=n;i++)
        manager[i]=i;
    j=0;
    for (i=1;i<=m;i++){
        if (sef_suprem(v[i].nod1)!=sef_suprem(v[i].nod2)){
            unire(v[i].nod1,v[i].nod2);
            s+=v[i].cost;
            sol[++j]=v[i];
        }
    }
    fout<<s<<'\n'<<j<<'\n';
    for (i=1;i<=j;i++)
        fout<<sol[i].nod1<<' '<<sol[i].nod2<<'\n';
    return 0;
}
