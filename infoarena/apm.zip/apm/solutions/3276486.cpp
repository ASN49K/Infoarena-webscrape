#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n, m, i, j, x1, y, c, sum, parent[200005], sze[200005];
bool viz[200005];
struct nod
{
    int cost, x, y;
};
vector <nod> v;
vector <pair<int, int>> ans;
bool cmp(nod a, nod b)
{
    return a.cost<b.cost;
}
int find_set(int nod)
{
    if(nod==parent[nod])
        return nod;
    return parent[nod]=find_set(parent[nod]);
}
void union_set(int a, int b)
{
    a=find_set(a);
    b=find_set(b);
    if(a!=b)
    {
        if(sze[a]<sze[b])
            swap(a, b);
        parent[b]=a;
        sze[a]+=sze[b];
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=n; i++)
    {
        sze[i]=1;
        parent[i]=i;
    }
    for(i=1; i<=m; i++)
    {
        fin>>x1>>y>>c;
        v.push_back({c, x1, y});
    }
    sort(v.begin(), v.end(), cmp);
    for(auto i: v)
    {
        if(find_set(i.x)!=find_set(i.y))
        {
            union_set(i.x, i.y);
            sum+=i.cost;
            ans.push_back({i.x, i.y});
        }
    }
    fout<<sum<<'\n'<<n-1<<'\n';
    for(auto i: ans)
        fout<<i.first<<" "<<i.second<<'\n';
    return 0;
}
