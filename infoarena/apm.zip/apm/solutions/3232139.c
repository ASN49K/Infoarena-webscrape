#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 200000
#define M 400000
#define INF 1000000123

typedef struct
{
    int vf, cost, urm;
} nod;

nod v[2*M+1];
int nr, n, m, nh, h[N+1], d[N+1], poz[N+1], lst[N+1], pred[N+1];
bool in_apm[N+1];

void adauga_muchie(int x, int y, int c)
{
    ++nr;
    v[nr].vf = y;
    v[nr].cost = c;
    v[nr].urm = lst[x];
    lst[x] = nr;
}

void schimba(int h[], int poz[], int p1, int p2)
{
    int aux = h[p1];
    h[p1] = h[p2];
    h[p2] = aux;
    poz[h[p1]] = p1;
    poz[h[p2]] = p2;
}

void urca(int h[], int v[], int poz[], int p)
{
    while (p > 1 && v[h[p]] < v[h[p/2]])
    {
        schimba(h, poz, p, p / 2);
        p /= 2;
    }
}

void coboara(int h[], int v[], int poz[], int nh, int p)
{
    int fs = 2 * p, fd = 2 * p + 1, pmin = p;
    if (fs <= nh && v[h[fs]] < v[h[pmin]])
    {
        pmin = fs;
    }
    if (fd <= nh && v[h[fd]] < v[h[pmin]])
    {
        pmin = fd;
    }
    if (pmin != p)
    {
        schimba(h, poz, pmin, p);
        coboara(h, v, poz, nh, pmin);
    }
}

void adauga(int h[], int v[], int poz[], int *pnh, int val)
{
    (*pnh)++;
    h[*pnh] = val;
    poz[h[*pnh]] = *pnh;
    urca(h, v, poz, *pnh);
}

void sterge(int h[], int v[], int poz[], int *pnh, int p)
{
    h[p] = h[*pnh];
    poz[h[p]] = p;
    (*pnh)--;
    if (*pnh < p)
    {
        return;
    }
    urca(h, v, poz, p);
    coboara(h, v, poz, *pnh, p);
}

int prim(int x0)
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = INF;
        adauga(h, d, poz, &nh, i);
    }
    d[x0] = 0;
    urca(h, d, poz, poz[x0]);
    int cost = 0;
    while (nh > 0 && d[h[1]] < INF)
    {
        int x = h[1];///x = varful cu distanta minima fata de apm construit pana acum
        cost += d[x];
        in_apm[x] = true;
        sterge(h, d, poz, &nh, 1);
        for (int p = lst[x]; p != 0; p = v[p].urm)
        {
            int y = v[p].vf, c = v[p].cost;
            if (!in_apm[y] && c < d[y])
            {
                d[y] = c;
                pred[y] = x;
                urca(h, d, poz, poz[y]);
            }
        }
    }
    return cost;
}

int main()
{
    FILE *in, *out;
    in = fopen("apm.in", "r");
    out = fopen("apm.out", "w");
    fscanf(in, "%d%d", &n, &m);
    for (int i = 0; i < m; i++)
    {
        int x, y, c;
        fscanf(in, "%d%d%d", &x, &y, &c);
        adauga_muchie(x, y, c);
        adauga_muchie(y, x, c);
    }
    fprintf(out, "%d\n%d\n", prim(1), n - 1);
    for (int i = 2; i <= n; i++)
    {
        fprintf(out, "%d %d\n", pred[i], i);
    }
    fclose(in);
    fclose(out);
    return 0;
}
