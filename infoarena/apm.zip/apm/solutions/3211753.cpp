#include <vector>
#include <queue>
#include <iostream>
#include <algorithm>
#include <sstream>
using namespace std;
//ifstream cin("bellmanford.in");
//ofstream cout("bellmanford.out");
#define INF (1000001)
template<typename T> string tos(T x){
    ostringstream os;
    os<<x;
    return os.str();
}
int n,m;
struct muchie{
    int x,y,c;
    muchie(int x_,int y_,int c_):x(x_),y(y_),c(c_){}
    bool operator < (const muchie&other)const{
        return c<other.c;
    }
    string tostring(){
        string s;
        s=tos(x)+ ' '+ tos(y)+ '\n';
        return s;
    }
};
struct padure{
    int n;
    vector<int>r;
    padure(int n_):n(n_){
        r.resize(n+1);
        for(int i=1;i<=n;i++){
            r[i]=i;
        }
    }
    int rad(int x){
        if(r[x]==x){
            return x;
        }
        else{
            return rad(r[x]);
        }
    }
    void uniune(int x,int y){
        int rx=rad(x);
        int ry=rad(y);
        if(rx==ry)return;
       r[rx]=ry;
    }
};
vector<muchie>vm;
void kruskal(){
    padure p(n);
    int k=n-1,i=0,ct=0;
    vector<muchie>apm;
    while(k){
        while(p.rad(vm[i].x)==p.rad(vm[i].y))
            i++;
        k--;
        for(int j=1;j<=n;j++){
            cout<<p.rad(j)<<" ";
        }
        cout<<endl;
        ct+=vm[i].c;
        apm.push_back(vm[i]);
        p.uniune(vm[i].x,vm[i].y);
    }
    cout<<ct<<'\n';
    for(int i=0;i<n-1;i++){
        cout<<apm[i].tostring();
    }

}
int main()
{
    cin>>n>>m;
    int x,y,z;
    for(int i=1;i<=m;i++){
        cin>>x>>y>>z;
        vm.push_back(muchie(x,y,z));
    }
    sort(vm.begin(),vm.end());
    kruskal();
    return 0;
}
