#include <fstream>
#include <functional>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n,m,x,y,c,used[200005],cost_final;
vector< pair<int,int> >G[200005];
vector<pair<int,int>>ans;
struct elem{
    int first,second,third;

    bool operator<(const elem& other)const{
        return first >other.first;
    }
};
priority_queue<elem>q;

int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        G[x].push_back(make_pair(y,c));
        G[y].push_back(make_pair(x,c));
    }
    //adaugam nodul 1
    used[1]=1;
    for(auto e:G[1])
    {
        if(used[e.first]==0)
        {
            q.push({e.second,1,e.first});
        }
    }
    while(q.size())
    {
        elem acc=q.top();
        q.pop();
        if(used[acc.third]==0)
        {
            ans.push_back(make_pair(acc.second,acc.third));
            cost_final+=acc.first;
            used[acc.third]=1;
            for(auto e:G[acc.third])
            {
                if(used[e.first]==0)
                {
                    q.push({e.second,acc.third,e.first});
                }
            }
        }
    }
    fout<<cost_final<<'\n';
    fout<<ans.size()<<'\n';
    for(auto e:ans)
        fout<<e.first<<' '<<e.second<<'\n';
    return 0;
}
