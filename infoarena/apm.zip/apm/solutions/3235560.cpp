#include <fstream>
#include <vector>

using namespace std;

const int N = 2e5;
const int INF = 1015;

struct muchie
{
    int varf, cost;
};

int nh, n, d[N+1], h[N], poz[N+1], pred[N+1];
bool in_apm[N+1];
vector <muchie> a[N+1];

int tata(int p)
{
    return ((p - 1) / 2);
}

int fiu_s(int p)
{
    return (2 * p + 1);
}

int fiu_d(int p)
{
    return (2 * p + 2);
}

void schimba(int p1, int p2)
{
    swap(h[p1], h[p2]);
    poz[h[p1]] = p1;
    poz[h[p2]] = p2;
}

void urca(int p)
{
    while (p > 0 && d[h[p]] < d[h[tata(p)]])
    {
        schimba(p, tata(p));
        p = tata(p);
    }
}

void adauga(int pv)
{
    h[nh++] = pv;
    poz[pv] = nh - 1;
    urca(nh - 1);
}

void coboara(int p)
{
    int fs = fiu_s(p), fd = fiu_d(p), optim = p;
    if (fs < nh && d[h[fs]] < d[h[optim]])
    {
        optim = fs;
    }
    if (fd < nh && d[h[fd]] < d[h[optim]])
    {
        optim = fd;
    }
    if (optim != p)
    {
        schimba(p, optim);
        coboara(optim);
    }
}

void sterge(int ph)
{
    if (ph == nh - 1)
    {
        nh--;
        return;
    }
    schimba(ph, nh - 1);
    nh--;
    urca(ph);
    coboara(ph);
}

int prim()
{
    ///initializam d
    d[1] = 0;
    pred[1] = 0;
    adauga(1);
    in_apm[1] = false;
    for (int i = 2; i <= n; i++)
    {
        d[i] = INF;
        pred[i] = 0;
        adauga(i);
        in_apm[i] = false;
    }
    int cost_total = 0;
    while (nh > 0)
    {
        int x = h[0];
        sterge(poz[x]);
        in_apm[x] = true;
        cost_total += d[x];
        for (auto e: a[x])
        {
            int y = e.varf;
            int c = e.cost;
            if (!in_apm[y] && c < d[y])
            {
                d[y] = c;
                pred[y] = x;
                urca(poz[y]);
            }
        }
    }
    return cost_total;
}

int main()
{
    ifstream in("apm.in");
    ofstream out("apm.out");
    int m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y, c;
        in >> x >> y >> c;
        a[x].push_back((muchie){y, c});
        a[y].push_back((muchie){x, c});
    }
    out << prim() << "\n" << n - 1 << "\n";
    for (int i = 2; i <= n; i++)
    {
        out << i << " " << pred[i] << "\n";
    }
    in.close();
    out.close();
    return 0;
}
