#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

const int nmax = 200000;

int n,m;

struct mch
{
    int x;
    int y;
    int c;
    bool operator <(const mch& b) const
    {
        return c<b.c;
    }
};

mch v[nmax*2 + 5];
int t[nmax + 5];
vector <pair<int,int>> sol;

int rad(int nod)
{
    int r = nod;
    while(t[r]>0) r=t[r];
    while(nod!=r){
        int aux = t[nod];
        t[nod] = r;
        nod = aux;
    }
    return nod;
}
bool join(int x,int y)
{
    int rx=rad(x),ry=rad(y);
    if(rx==ry) return false;
    if(-t[rx]<-t[ry])
        swap(rx,ry);
    t[rx]+=t[ry];t[ry]=rx;
    return true;
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y,c;
        fin>>x>>y>>c;
        v[i]={x,y,c};
    }
    sort(v+1,v+m+1);
    int ss=0;
    for(int i=1;i<=m;i++)
    {
        if(join(v[i].x,v[i].y)){
            ss+=v[i].c;
            sol.push_back({v[i].x,v[i].y});
        }
    }
    fout<<ss<<'\n';
    fout<<sol.size()<<'\n';
    for(auto& i : sol)
    {
        fout<<i.first<<' '<<i.second<<'\n';
    }
}

