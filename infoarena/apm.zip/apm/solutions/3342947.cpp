#include <fstream>
#include <queue>
#define NMAX 200002

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

struct muchie
{
    int x,y,c;
    friend bool operator < (muchie a, muchie b);
};
muchie apm[NMAX];

bool operator < (muchie a, muchie b)
{
    return a.c > b.c;
}

int n,m;
int costminim;

int tata[NMAX];
int h[NMAX]; //inaltimea arborelui cu radacina x

priority_queue <muchie> H;

int Find(int x);
int Union(int x, int y);

void citire();
void kruskal();
void afisare();

int main()
{
    citire();
    kruskal();
    afisare();

    return 0;
}


void citire()
{
    int i;
    muchie aux;

    fin>>n>>m;
    for(i=0; i<m; i++)
    {
        fin>>aux.x>>aux.y>>aux.c;
        H.push(aux);
    }
}


void kruskal()
{
    muchie aux;
    int rx,ry;
    int nrsel;

    nrsel=0;

    while(nrsel<n-1)
    {
        aux=H.top();
        H.pop();
        rx=Find(aux.x);
        ry=Find(aux.y);
        if(rx!=ry)
        {
            costminim+=aux.c;
            apm[++nrsel]=aux;
            Union(rx,ry);
        }
    }
}


void afisare()
{
    int i;

    fout<<costminim<<'\n'<<n-1<<'\n';
    for(i=1; i<n; i++)
        fout<<apm[i].x<<' '<<apm[i].y<<'\n';

}


int Find(int x)
{
    //determin radacinea arborelui

    int rx;
    int y;

    rx=x;
    while(tata[rx])
        rx=tata[rx];

    //rx este radacina arborelui
    //compresez drumul de la x la rx;
    //fiecare nod de pe acest drum devine fiu al lui rx

    while(tata[x] && tata[rx]!=rx)
    {
        y=tata[x];
        tata[x]=x;
        x=y;
    }

    return rx;
}


int Union(int x, int y)
{
    //reuneste arborele in care se afla x cu arborele in care se afla y

    int rx,ry;

    rx=Find(x);
    ry=Find(y);

    if(h[rx]<h[ry])
        //rx devine fiul lui ry
        tata[rx]=ry;
    else
        if(h[ry]<h[rx]) //ry devine fiul lui rx
            tata[ry]=rx;
        else //egalitate
        {
            tata[ry]=rx;
            h[rx]++;
        }
}
