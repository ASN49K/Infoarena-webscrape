#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("apm.in" , "r" , stdin) , freopen("apm.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 2e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , m;
vector < pii > G[N];
pq < pii , vector < pii > , greater < pii > > q;
int cmin[N] , parent[N];
bool marked[N];

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

	int i;

    cin >> n >> m;

    for(i = 1 ; i <= m ; i++)
    {
        int x , y , c;
        cin >> x >> y >> c;
        G[x].pb({y , c});
        G[y].pb({x , c});
    }

    for(i = 1 ; i <= n ; i++)
        cmin[i] = INT_MAX;

    cmin[1] = INT_MIN;
    q.push({INT_MIN , 1});
    int cst = 0;
    vector < pii > ans;

    while(q.size())
    {
        int node = q.top().second;

        marked[node] = 1;
        q.pop();

        for(auto to : G[node])
            if(cmin[to.first] > to.second && marked[to.first] == 0)
            {
                cmin[to.first] = to.second;
                parent[to.first] = node;
                q.push({cmin[to.first] , to.first});
            }
    }

    for(i = 2 ; i <= n ; i++)
    {
        cst += cmin[i];
        ans.push_back({i , parent[i]});
    }

    cout << cst << '\n';
    cout << n - 1 << '\n';
    for(auto e : ans) cout << e.first << ' ' << e.second << '\n';

    return 0;
}
