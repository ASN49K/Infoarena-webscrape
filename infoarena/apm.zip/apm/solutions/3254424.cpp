#include <bits/stdc++.h>

using namespace std;

struct Edge {
    int x, y, c;
};

bool cmp(Edge a, Edge b) {
    return a.c < b.c;
}

struct DSU {
    vector<int> h, p;
    DSU(int n) {
        h.resize(n + 1);
        p.resize(n + 1);
        for(int i = 1; i <= n; i++) {
            h[i] = 1;
            p[i] = i;
        }
    }
    int Find(int x) {
        int r = x;
        while(r != p[r]) {
            r = p[r];
        }
        int y = x;
        //compresia drumurilor
        while(y != r) {
            int t = p[y];
            p[y] = r;
            y = t;
        }
        return r;
    }
    void Union(int x, int y) {
        x = Find(x);
        y = Find(y);
        if(h[x] < h[y]) {
            p[x] = y;
        } else {
            if(h[x] > h[y]) {
                p[y] = x;
            } else {
                p[x] = y;
                h[y]++;
            }
        }
    }
};

int main() {
    int n, m;
    ifstream f("apm.in");
    ofstream g("apm.out");
    f >> n >> m;
    vector<Edge> edges;
    for(int i = 1; i <= m; i++) {
        int x, y, c;
        f >> x >> y >> c;
        edges.push_back({x, y, c});
    }
    sort(edges.begin(), edges.end(), cmp);
    int apm = 0;
    vector<Edge> sol;
    DSU d(n);
    for(auto it : edges) {
        if(d.Find(it.x) != d.Find(it.y)) {
            apm += it.c;
            sol.push_back(it);
            d.Union(it.x, it.y);
        }
    }
    g << apm << '\n';
    g << n - 1 << '\n';
    for(auto it : sol) {
        g << it.x << ' ' << it.y << '\n';
    }
    return 0;
}
