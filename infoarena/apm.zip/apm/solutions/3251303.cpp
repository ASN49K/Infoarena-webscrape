#include <fstream>
#include <algorithm>
using namespace std;
ifstream in("apm.in");
ofstream out("apm.out");
const int MMAX = 4e5;
int sef[200000];
struct ura{
    int a, b, cost;
}v[NMAX];
bool cmp(ura a, ura b){
    if(a.cost < b.cost){
        return true;
    }
    return false;
}
int main(){
    int noduri, muchii;
    for(int i = 0;i<n;i++){
	in>>v[i].a>>v[i].b>>v[i].cost;
    }
    sort(v, v+ n, cmp);
    for(int i = 0;i<n;i++){
	if(sef_suprem(v[i].a) == sef(v[[i - 1].a)){
	}
    }
    return 0;
}
