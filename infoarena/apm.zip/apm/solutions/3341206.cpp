#include <bits/stdc++.h>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
const int NMAX = 2e5 + 1, INF = 1e9;
int n, m, parent[NMAX], min_cost[NMAX];
bool in_mst[NMAX];
vector<pair<int, int>> adj[NMAX], mst;

int Prim()
{
    int sum = 0;
    in_mst[1] = true;
    fill(min_cost + 2, min_cost + n + 1, INF);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    for(auto [next, cost] : adj[1])
    {
        parent[next] = 1;
        min_cost[next] = min(min_cost[next], cost);
        pq.push({min_cost[next], next});
    }
    while(!pq.empty())
    {
        auto [cost, node] = pq.top(); pq.pop();
        if(in_mst[node])
            continue;
        in_mst[node] = true;
        sum += cost;
        mst.emplace_back(parent[node], node);
        for(auto [next, new_cost] : adj[node])
        {
            if(in_mst[next])
                continue;
            if(new_cost < min_cost[next])
            {
                min_cost[next] = new_cost;
                parent[next] = node;
                pq.push({min_cost[next], next});
            }
        }
    }
    return sum;
}

int main()
{
    fin >> n >> m;
    while(m--)
    {
        int u, v, cost;
        fin >> u >> v >> cost;
        adj[u].emplace_back(v, cost);
        adj[v].emplace_back(u, cost);
    }
    fout << Prim() << "\n" << mst.size() << "\n";
    for(auto [u, v] : mst)
        fout << u << " " << v << "\n";

    fin.close();
    fout.close();
    return 0;
}
