#include <bits/stdc++.h>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n,m,rad[200005],f[400005],cnt,cost_total,h[200005];


struct cv
{
    int x,y,cost;
}muchie[400005];

bool comp(cv a, cv b){
return a.cost<b.cost;
}

int Find(int k)
{
    if(rad[k]==k)return k;
    else Find(rad[k]);
}

void Union(int a,int b)
{
    a=Find(a);
    b=Find(b);
    if(Find(a)==Find(b))
        return;
    if(h[a]<h[b])
        rad[a]=b;
    if(h[a]>h[b])
        rad[b]=a;
    else{
        rad[a]=b;
        h[b]++;
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
        fin>>muchie[i].x>>muchie[i].y>>muchie[i].cost;
    for(int i=1;i<=n;i++)
        rad[i]=i,h[i]=1;
    sort(muchie+1, muchie+m+1, comp);
    //for(int i=1;i<=m;i++)
//fout<<muchie[i].x<<' '<<muchie[i].y<<' '<<muchie[i].cost<<'\n';
    for(int i=1;i<=m;i++)
    {
        if(Find(muchie[i].x)!=Find(muchie[i].y))
        {
            Union(muchie[i].x,muchie[i].y);
            f[i]=1;
            cnt++;
            cost_total+=muchie[i].cost;
        }
    }
    fout<<cost_total<<'\n'<<cnt<<'\n';
    for(int i=1;i<=m;i++)
    {
        if(f[i])
            fout<<muchie[i].x<<' '<<muchie[i].y<<'\n';
    }
    return 0;
}
