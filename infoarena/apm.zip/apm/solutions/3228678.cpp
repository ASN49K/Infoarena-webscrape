#include <fstream>
#include <vector>
using namespace std;
ifstream cin("prim.in");
ofstream cout("prim.out");
vector <pair<int,int>> v[101];
int g[101],a[101],b[101];
const int inf=1e9;
int main()
{
    int n,m,i,x,y,z,j;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y>>z;
        v[x].push_back(make_pair(y,z));
        v[y].push_back(make_pair(x,z));
    }
    for(i=1;i<=n;i++)
        a[i]=inf;
    for(auto x : v[1])
    {
        a[x.first]=x.second;
        b[x.first]=1;
    }
    int mini,ind,rez=0;
    for(i=2;i<=n;i++)
    {
        mini=inf;
        for(j=2;j<=n;j++)
        {
            if(g[j]==0&&a[j]<mini)
            {
                mini=a[j];
                ind=j;
            }
        }
        g[ind]=b[ind];
        rez+=a[ind];
        for(auto x : v[ind])
        {
            if(a[x.first]>x.second)
            {
                a[x.first]=x.second;
                b[x.first]=ind;
            }
        }
    }
    cout<<rez<<'\n';
    for(i=1;i<=n;i++)
        cout<<g[i]<<" ";
    return 0;
}
