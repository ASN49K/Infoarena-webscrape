#include <bits/stdc++.h>

using namespace std;

#define cin fin
#define cout fout
ifstream fin("apm.in");
ofstream fout("apm.out");

struct dsu
{
    vector<int> p, sz;

    dsu(int n)
    {
        p.resize(n + 1);
        sz.resize(n + 1);
        for (int i = 1; i <= n; ++i)
        {
            p[i] = i;
            sz[i] = 1;
        }
    }

    int find_parent(int node) // reprezentantul lui node
    {
        if (p[node] == node)
        {
            return node;
        }
        return p[node] = find_parent(p[node]);
    }

    void unite(int x, int y)
    {
        x = find_parent(x);
        y = find_parent(y);
        if (x == y)
        {
            return;
        }
        if (sz[x] > sz[y])
        {
            // swap(x, y);
        }
        p[x] = y;
        sz[y] += sz[x];
    }
};

int32_t main()
{
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<tuple<int, int, int>> edg(m);
    for (auto &[cost, u, v] : edg)
    {
        cin >> u >> v >> cost;
    }
    sort(edg.begin(), edg.end());

    dsu tree(n); // graf gol

    int ans = 0;
    vector<pair<int, int>> rep;
    for (auto [cost, u, v] : edg)
    {
        if (tree.find_parent(u) == tree.find_parent(v))
        {
            continue;
        }
        rep.push_back({u, v});
        ans += cost;
        tree.unite(u, v);
    }
    cout << ans << '\n';
    for (auto [u, v] : rep)
    {
        cout << u << ' ' << v << '\n';
    }
}