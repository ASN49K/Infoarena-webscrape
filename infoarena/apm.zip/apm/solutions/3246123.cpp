#include <bits/stdc++.h>

using namespace std;
ifstream in("apm.in");
ofstream out("apm.out");

int n, m, op, x, y, c;


void prim(vector<vector<pair<int, int>>> &adj, int &sum, vector<pair<int, int>> &ans) {
    priority_queue<pair<int ,int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    q.push({0, 1});

    vector<bool> added(n + 1, false);
    vector<int> minEdge(n + 1, 1e9);
    vector<int> minNode(n + 1, -1);


    while (!q.empty()) {
        int cost = q.top().first;
        int node = q.top().second;
        q.pop();

        if (added[node]) {
            continue;
        }

        if (minNode[node] != -1) {
            ans.push_back({node, minNode[node]});
        }


        added[node] = true;
        sum += cost;

        for (auto it : adj[node]) {
            if (!added[it.first] && it.second < minEdge[it.first]) {
                minNode[it.first] = node;
                minEdge[it.first] = it.second;
                q.push({it.second, it.first});
            }
        }
    }
}
int main() {
    in >> n >> m;

    vector<vector<pair<int, int>>> adj(n + 1, vector<pair<int, int>>());
    for (int i = 1; i <= m; i++) {
        in >> x >> y >> c;
        adj[x].push_back({y, c});
        adj[y].push_back({x, c});
    }

    int sum = 0;
    vector<pair<int, int>> ans;

    prim(adj, sum, ans);

    out << sum << '\n';
    out << ans.size() << '\n';
    for (auto it : ans) {
        out << it.first << " " << it.second << '\n';
    }

    return 0;
}
