#include <fstream>
#include <vector>
#define NMAX 200002
#define INF (1<<30)
using namespace std;
ifstream  fin("apm.in");
ofstream fout("apm.out");
int N,M,S,nr,viz[NMAX];
vector <int>cost(NMAX,INF),tata(NMAX);
vector<vector<pair<int,int>>> A(NMAX);

struct solutie
{
    int x,y;
}sol[NMAX];

void citire()
{
    int x,y,c;
    fin>>N>>M;

    for(int i=1; i<=M; i++)
    {
        fin>>x>>y>>c;
        A[x].push_back({y,c});
        A[y].push_back({x,c});
    }
}

int main()
{
    citire();

    nr=0;
    cost[1]=0;
    for(int i=1; i<=N; i++)
    {
        int vmin,nod;
        nod=0;
        vmin=INF;

        for(int j=1; j<=N; j++)
        {
            if(!viz[j] && cost[j]<vmin)
            {
                vmin=cost[j];
                nod=j;
            }
        }

        if(nod)
        {
            S+=cost[nod];
            viz[nod]=1;

            if(tata[nod]!=0)
            {
                nr++;
                sol[nr].x=tata[nod];
                sol[nr].y=nod;
            }

            for(int j=0; j<A[nod].size(); j++)
            {
                if(!viz[A[nod][j].first] && cost[A[nod][j].first]>A[nod][j].second)
                {
                    cost[A[nod][j].first]=A[nod][j].second;
                    tata[A[nod][j].first]=nod;
                }
            }
        }
        else
        {
            break;
        }
    }

    fout<< S << "\n";
    fout<< nr << "\n";
    for(int i=1; i<=nr; i++)
    {
        fout<< sol[i].x << " " << sol[i].y << "\n";
    }

    return 0;
}
