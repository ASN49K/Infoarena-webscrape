#include <fstream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

int n, m;
vector<vector<pair<int, int>>> adj;

pair<int,int> get_minim(vector<int> &d, vector<int> &viz){
    pair<int,int> p={1e9,0}; //perechea eticheta minima, varf
    for(int v=1;v<=n;v++) //luam pe rand toate varfurile
        if (viz[v]==0)
            if (d[v]>p.first){
                p.first=d[v];
                p.second=v;
            }

    return p;
    }

void Prim(int s, vector<pair<int, int>> &apcm,  int&cost){
    vector<int> d(n+1, 1e9), tata(n+1, 0), viz(n+1, 0);
    d[s] = 0;
    for(int i=0;i<n;i++){

		pair<int,int> p  =get_minim(d,viz); //nodul cu eticheta minima nevizitat
        viz[p.second] = 1;

        for(auto &nod : adj[p.second]){
            int vf = nod.first;
            int cost = nod.second;
            if(d[vf] > cost && !viz[vf]){
                tata[vf] = p.second;

                d[vf] = cost;

            }
        }
    }
    for(int i=1; i<=n; ++i){
        if(tata[i] != 0){
            apcm.push_back({i, tata[i]});
            cost += d[i];
        }
    }
}
int main(){
    fin>>n>>m;
    adj.resize(n+1);
    while(m--){
        int x, y, cost;
        fin>>x>>y>>cost;
        adj[x].push_back({y, cost});
        adj[y].push_back({x, cost});
    }
    vector<pair<int, int>> apcm;

    int cost = 0;
    Prim(1,apcm,cost);

    fout<<cost<<'\n';
    fout<<apcm.size()<<'\n';
    for(auto &e : apcm){
        fout<<e.first<<" "<<e.second<<'\n';
    }
    fout.close();
    return 0;
}
