#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n, m, i, j, x1, y, c, dist[200005], parent[200005], ans;
bool viz[200005];
struct nodd
{
    int nod, cost;
} x;
struct cmp
{
    bool operator()(const nodd&a, const nodd&b)
    {
        return a.cost>b.cost;
    }
};
vector <nodd> v[200005];
priority_queue <nodd, vector <nodd>, cmp> q;
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x1>>y>>c;
        v[x1].push_back({y, c});
        v[y].push_back({x1, c});
    }
    for(i=1; i<=n; i++)
        dist[i]=1e9;
    dist[1]=0;
    q.push({1, 0});
    while(!q.empty())
    {
        x=q.top();
        q.pop();
        viz[x.nod]=1;
        for(auto i: v[x.nod])
            if(dist[i.nod]>i.cost && viz[i.nod]==0)
            {
                if(dist[i.nod]!=1e9)
                    ans-=dist[i.nod];
                dist[i.nod]=i.cost;
                ans+=i.cost;
                q.push({i.nod, dist[i.nod]});
                parent[i.nod]=x.nod;
            }
    }
    fout<<ans<<'\n'<<n-1<<'\n';
    for(i=2; i<=n; i++)
        fout<<i<<" "<<parent[i]<<'\n';
    return 0;
}
