#include <fstream>
#include <algorithm>
#include <climits>
#include <vector>

using namespace std;

ifstream fin ("apm.in");
ofstream fout("apm.out");

struct vec
{
    int x,cost;
};
vector<vec>g[200001];
int n,m,minim,vc,p;
int cost[200001];
bool viz[200001];
int tata[200001];
int x,y,c,sol;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        g[x].push_back({y,c});
        g[y].push_back({x,c});
    }
    for(int i=2;i<=n;i++)
        cost[i]=INT_MAX;
    for(int i=1;i<=n;i++)
    {
        minim=INT_MAX;
        p=0;
        for(int j=1;j<=n;j++)
            if(viz[j]==0 && cost[j]<minim)
            {
                minim=cost[j];
                p=j;
            }
        viz[p]=1;
        sol+=cost[p];
        for(int j=0;j<g[p].size();j++)
        {
            vc=g[p][j].x;
            int ct=g[p][j].cost;
            if(cost[vc]>ct)
            {
                cost[vc]=ct;
                tata[vc]=p;
            }
        }
    }
    fout<<sol<<'\n'<<n-1<<'\n';
    for(int i=2;i<=n;i++)
        fout<<i<<" "<<tata[i]<<'\n';
    return 0;
}
