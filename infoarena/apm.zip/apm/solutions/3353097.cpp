#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

const int nmax = 200000;

int n,m;

struct mch{
    int x;
    int y;
    int c;
    bool operator < (const mch& b) const {
        return c < b.c;
    }
};

int t[nmax + 5];

vector <mch> sol;
vector <mch> v;

int rad(int x) {
    if (t[x] > 0) return rad(t[x]);
    return x;
}
bool join(int x, int y)
{
    int rx = rad(x);
    int ry = rad(y);
    if (rx == ry)
        return false;
    if (-t[rx] < -t[ry]) swap(rx, ry);
    t[rx] += t[ry];
    t[ry] = rx;
    return true;
}


int main(){
    fin>>n>>m;
    for (int i = 1; i <= n; i++) t[i] = -1;
    for (int i = 1; i <= m; i++) {
        mch x;
        fin>>x.x>>x.y>>x.c;
        v.push_back(x);
    }
    sort(v.begin(), v.end());
    int sol_val = 0;
    for (auto &i : v)
        if (join(i.x, i.y))
            sol_val += i.c, sol.push_back(i);
    fout<<sol_val<<'\n';
    fout<<sol.size()<<'\n';
    for(auto &i : sol)  fout<<i.x<<' '<<i.y<<'\n';
}
