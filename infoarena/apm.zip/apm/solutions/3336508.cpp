#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <cstring>

using namespace std;

struct Muchie{
    int x,y,c;
};

vector <Muchie> M;
int tata[100001];
vector<int> h;

bool compareMuchii(const Muchie a, const Muchie b){
    return a.c>b.c;
}

int Find(int x){
    while(x!=tata[x]){
        x=tata[x];
    }
    return x;
}

void Union(int x, int y){
    int p1=Find(x);
    int p2=Find(y);

    if(h[p1]>h[p2]){
        tata[p2]=p1;
    }
    else if(h[p2]>h[p1]){
        tata[p1]=p2;
    }
    else{
        tata[p1]=p2;
        h[p2]++;
    }

}

vector<pair<int,int>> apcm;

int main(){
    ifstream cin("apm.in");
    ofstream cout("apm.out");
    int n,m;

    cin>>m;
    for(int i=0; i<m; i++){
        int x,y,c;
        cin>>x>>y>>c;
        M.push_back({x,y,c});
    }

    sort(M.begin(), M.end(), compareMuchii);

    for(int i=1; i<=n; i++){
        tata[i]=i;
    }

    int cost=0;

    for(auto lat: M){
        int x=lat.x;
        int y=lat.y;
        if(Find(x)!=Find(y)){
            apcm.push_back({x,y});
            Union(x,y);
            cost+=lat.c;
            if(apcm.size()==n-1){
                break;
            }
        }
    }

    cout<<cost<<'\n';
    cout<<apcm.size()<<'\n';
    for(auto m: apcm)
    {
        cout << m.first << ' ' << m.second << '\n';
    }


}