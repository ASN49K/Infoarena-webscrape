#include <algorithm>
#include <fstream>
#include <vector>
#include <array>
using namespace std;

const int NMAX = 200000 + 2;

int parent[NMAX];
int weight[NMAX];
int n;

void init_dsu() {
    for(int i = 0; i <= n; i++) {
        parent[i] = i;
        weight[i] = 1;
    }
}

/*int root(int i) {
    while(i != parent[i]) {
        parent[i] = parent[parent[i]];
        i = parent[i];
    }
    return i;
}*/

int root(int i) {
    if(parent[i] == parent[parent[i]])
        return parent[i];
    parent[i] = root(parent[i]);
    return parent[i];
}

bool check(int a, int b) {
    return (root(a) == root(b));
}

void unite(int a, int b) {
    const int root_a = root(a);
    const int root_b = root(b);

    if(weight[root_a] > weight[root_b]) {
        weight[root_a] += weight[root_b];
        parent[root_b] = root_a;
    } else {
        weight[root_b] += weight[root_a];
        parent[root_a] = root_b;
    }
}

int main() {
    ifstream in("apm.in");
    ofstream out("apm.out");
    in >> n;
    int v;
    in >> v;
    init_dsu();

    vector<array<int, 3>> graph_verts;
    graph_verts.resize(v);

    for(int i = 0; i < v; i++) {
        in >> graph_verts[i][1] >> graph_verts[i][2];
        in >> graph_verts[i][0];
    }

    sort(graph_verts.begin(), graph_verts.end());

    int tree_cost = 0;
    vector<array<int, 2>> tree_verts;

    for(const auto l : graph_verts) {
        const int v1 = l[1];
        const int v2 = l[2];
        if(check(v1, v2))
            continue;
        unite(v1, v2);
        tree_cost += l[0];
        tree_verts.push_back({v1, v2});
    }

    out << tree_cost << '\n' << tree_verts.size() << '\n';

    for(const auto l : tree_verts) {
        out << l[1] << ' ' << l[0] << '\n';
    }
}
