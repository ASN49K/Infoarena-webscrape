#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

class InParser
{
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch()
    {
        ++sp;
        if(sp == 4096)
        {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char* nume)
    {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser& operator >> (int &n)
    {
        char c;
        while(!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if(c == '-')
        {
            n = 0;
            sgn = -1;
        }
        else
        {
            n = c - '0';
        }
        while(isdigit(c = read_ch()))
        {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }

    InParser& operator >> (long long &n)
    {
        char c;
        n = 0;
        while(!isdigit(c = read_ch()) && c != '-');
        long long sgn = 1;
        if(c == '-')
        {
            n = 0;
            sgn = -1;
        }
        else
        {
            n = c - '0';
        }
        while(isdigit(c = read_ch()))
        {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }
} fin("apm.in");

class OutParser
{
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch)
    {
        if(sp == 50000)
        {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        }
        else
        {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name)
    {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser()
    {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32)
    {
        if(vu32 < 0)
        {
            write_ch('-');
            vu32 = -vu32;
        }
        if(vu32 <= 9)
        {
            write_ch(vu32 + '0');
        }
        else
        {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64)
    {
        if(vu64 <= 9)
        {
            write_ch(vu64 + '0');
        }
        else
        {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch)
    {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch)
    {
        while(*ch)
        {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
} fout("apm.out");

const int NMAX = 2e5 + 1;

struct muchie
{
    int i, j, c;
};

int n, m, CC[NMAX], sol;
vector<muchie> M;
vector<int> vsol;

void citire()
{
    int i, j, c;
    fin >> n >> m;
    for(int k = 1; k <= m; ++k)
    {
        fin >> i >> j >> c;
        M.push_back({i, j, c});
    }
}

inline bool cmp(const muchie& a, const muchie& b)
{
    return a.c < b.c;
}

int Find(int x)
{
    if(!CC[x]) return x;
    return CC[x] = Find(CC[x]);
}

void solutie()
{
    sort(M.begin(), M.end(), cmp);
    for(int i = 0, nrm = 0; i < m; ++i)
    {
        int cx = Find(M[i].i), cy = Find(M[i].j);
        if(cx != cy)
        {
            sol += M[i].c;
            vsol.push_back(i);
            CC[cx] = cy;
            if(++nrm == n - 1) return;
        }
    }
}

void afisare()
{
    fout << sol << '\n' << n - 1 << '\n';
    for(const auto& x : vsol)
        fout << M[x].i << ' ' << M[x].j << '\n';
}

int main()
{
    citire();
    solutie();
    afisare();
    return 0;
}
