#include <fstream>
#include <queue>
#define MMAX 400002
#define NMAX 200002
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

struct muchie{
    int x, y, c;
    friend bool operator < (muchie a, muchie b);
};

int n,m;
int tata[NMAX];
int h[NMAX]; //h[x]=intaltimea arborelui cu inaltimea x
muchie apm[NMAX];
int costmin;
priority_queue<muchie> H;

bool operator < (muchie a, muchie b){
    return a.c > b.c;

}

int Find(int x);
void Union(int x, int y);
void citire();
void kruskal();
void afisare();

int main()
{
    citire();
    kruskal();
    afisare();
    return 0;
}
void citire(){
    int i,x,y,c;
    muchie aux;
    fin>>n>>m;
    for(i=0;i<m;i++)
    {
        fin>>aux.x>>aux.y>>aux.c;
        H.push(aux);
    }
}
void kruskal(){
    int rx,ry,nrsel;
    muchie aux;
    nrsel=0;
    while(nrsel<n-1)
    {
        aux=H.top(); H.pop();
        rx=Find(aux.x); ry=Find(aux.y);
        if(rx!=ry)
        {
            costmin+=aux.c;
            apm[++nrsel]=aux;
            Union(rx,ry);
        }
    }
}
int Find(int x){
    int y,rx;
    //determin radacina arborelui
    rx=x;
    while(tata[rx])
        rx=tata[rx];
    //rx este radacina arborelui
    //compresez drumul de la x la rx;
    //fiecare nod de pe acest drum devine fiu al lui rx
    while(tata[x] && tata[x]!=rx)
    {
        y=tata[x];
        tata[x]=rx;
        x=y;
    }
    return rx;
}
void Union(int x, int y){
    int rx,ry;
    //reuneste arborele in care se afla x cu arborele in care se afla y
    rx=Find(x); ry=Find(y);
    if(h[rx]<h[ry]) //rx devine fiul lui ry
        tata[rx]=ry;
    else
    if(h[ry]<h[rx]) //ry devine fiul lui rx
        tata[ry]=rx;
    else //egalitate
    {
        tata[ry]=rx;
        h[rx]++;
    }
}
void afisare(){
    int i;
    fout<<costmin<<'\n'<<n-1<<'\n';
    for(i=1;i<n;i++)
        fout<<apm[i].x<<' '<<apm[i].y<<'\n';
}
