#include <bits/stdc++.h>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

int n, m, k, t[200001];
pair<int, int> e[400001];

struct muchii
{
    int x, y, c;
}a[400001];

bool Comp(muchii A, muchii B)
{
    return A.c < B.c;
}

int Find(int x)
{
    int y;
    if (t[x] == 0)
        return x;
    y = Find(t[x]);
    t[x] = y;
    return y;
}

void Union(int x, int y)
{
    t[y] = x;
}

int main()
{
    int i, x, y, c, cost = 0;
    fin >> n >> m;
    for (i = 1 ; i <= m ; i++)
        fin >> a[i].x >> a[i].y >> a[i].c;
    sort(a + 1, a + m + 1, Comp);
    k = 0;
    for (i = 1 ; i <= m && k <= n - 1 ; i++)
    {
        x = Find(a[i].x);
        y = Find(a[i].y);
        if (x != y)
        {
            Union(x, y);
            ++k;
            e[i] = {a[i].x, a[i].y};
            cost += a[i].c;
        }
    }
    fout << cost << "\n" << n - 1 << "\n";
    for (i = 1 ; i <= n - 1 ; i++)
        fout << e[i].first << " " << e[i].second << "\n";
    return 0;
}
