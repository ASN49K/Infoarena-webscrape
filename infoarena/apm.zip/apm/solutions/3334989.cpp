#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#define INF 1e9

using namespace std;



ifstream fin("files/apm.in");
ofstream fout("files/apm.out");


pair<int, int> getMinimum(vector<int> &d, vector<int> &viz, int N) {
    pair<int, int> minimium = {INF, 0};

    for (int i = 1; i <= N; i++) {
        if (viz[i] == 0) {
            if (d[i] < minimium.first) {
                minimium = {d[i], i};
            }
        }
    }
    return minimium;
}

vector<pair<int, int>> prim(int s, vector<vector<pair<int, int>>> &la, int N, int &costTotal) {
    vector<int> d(N + 1, INF);
    vector<int> tata(N + 1, 0), viz(N + 1, 0);

    d[s] = 0;

    for (int i = 1; i <= N; i++) {
        pair<int, int> crt = getMinimum(d, viz, N);
        viz[crt.second] = 1;

        for (auto& vecin : la[crt.second]) {
            int cost = vecin.first;
            int nod = vecin.second;

            if (viz[nod] == 0 && cost < d[nod]) {
                d[nod] = cost;
                tata[nod] = crt.second;
            }
        }
    }

    vector<pair<int, int>> apcm;
    costTotal = 0;
    for (int i = 1; i <= N; i++) {
        if (tata[i] != 0) {
            apcm.push_back({i, tata[i]});
            costTotal += d[i];
        }
    }

    return apcm;
}

int main() {

    int N, M;
    fin >> N >> M;

    vector<vector<pair<int, int>>> la(N + 1);

    for (int i = 0; i < M; i++) {
        int x, y, w;
        fin >> x >> y >> w;

        la[x].push_back({w, y});
        la[y].push_back({w, x});
    }

    int costTotal = 0;
    vector<pair<int, int>> apcm = prim(1, la, N, costTotal);
    
    fout << costTotal << endl;
    fout << apcm.size() << endl;
    for (auto& m : apcm) {
        fout << m.first << ' ' << m.second << endl;
    }

    return 0;
}