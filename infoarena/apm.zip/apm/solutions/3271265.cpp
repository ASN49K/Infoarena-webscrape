#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int INF = 1 << 29;

ifstream input("apm.in");
ofstream output("apm.out");

int main()
{
    int n, m;
    input >> n >> m;

    vector<vector<pair<int, int>>> adj(n+1);

    for(int i = 0; i < m; i++){
        int a, b, c;
        input >> a >> b >> c;
        adj[a].push_back({b, c});
        adj[b].push_back({a, c});
    }

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    vector<int> key(n+1, INF);
    vector<int> parent(n+1);
    vector<bool> inMST(n+1, false);

    key[1] = 0;
    parent[1] = 0;
    pq.push({key[1], 1});

    while(!pq.empty()){
        pair<int, int> curr = pq.top();
        pq.pop();
        int currNode = curr.second;
        int currKey = curr.first;
        inMST[currNode] = true;

        for(int i = 0; i < adj[currNode].size(); i++){
            if(inMST[adj[currNode][i].first] == false && key[adj[currNode][i].first] > adj[currNode][i].second){
                key[adj[currNode][i].first] = adj[currNode][i].second;
                pq.push({key[adj[currNode][i].first], adj[currNode][i].first});
                parent[adj[currNode][i].first] = currNode;
            }
        }
    }
    int cost = 0;
    for(int i = 1; i <= n; i++){
        cost += key[i];
    }
    output << cost << endl;
    for(int i = 1; i <= n; i++){
        output << parent[i] << " ";
    }
    return 0;
}
