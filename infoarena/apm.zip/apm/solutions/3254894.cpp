#include <fstream>
#include <vector>
#include <stdlib.h>
#include <algorithm>


using namespace std;

ifstream fin ("apm.in");
ofstream fout ("apm.out");

int n,m;
const int NMAX=200003;

int tata[NMAX+2];

struct muchie{
    int x,y,cost;
};

muchie Graf[NMAX+1];
vector<pair<int,int>> rez;
bool cmp(muchie a, muchie b)
{
    return a.cost < b.cost;
}

int main(){
    fin >> n >> m;
    for(int i=1;i<=m;i++){
        fin >> Graf[i].x >> Graf[i].y  >> Graf[i].cost;
    } 
    sort(Graf+1,Graf+1+m,cmp);
    for(int i=1;i<=n;i++)
    tata[i]=i;
    int S=0;
    for(int i=1;i<=m;i++)
    {
        if(tata[Graf[i].x] != tata[Graf[i].y])
        {
            S+=Graf[i].cost;
            int rx=tata[Graf[i].x],ry=tata[Graf[i].y];
            rez.push_back({Graf[i].y,Graf[i].x});
            for(int j=1;j<=n;j++)
            {
                if(tata[j]==ry)
                tata[j]=rx;
            }
        }
    }
    fout<<S<<'\n';
    fout<<rez.size()<<'\n';
    for(auto i: rez)
    {
        fout << i.first << " " << i.second << '\n';
    }
    return 0;
}