#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream f ("apm.in");
ofstream g ("apm.out");

const int NMAX = 200000,
          MMAX = 400000;

struct muchie {
    int i, j, c;
};

int n, m, cost;
muchie M[MMAX + 1];
int CC[NMAX+1], nrM[MMAX+1], nm;

void citire() {
    f >> n >> m;
    for(int k=1; k<=m; k++)
        f >> M[k].i >> M[k].j >> M[k].c;
}

void afis() {
    g << cost << '\n';
    g << nm << '\n';
    for (int i=1; i<=nm; i++) {
        int k = nrM[i];
        g << M[k].i << ' ' << M[k].j << '\n';
    }
}

bool comp(const muchie &a, const muchie &b) {
    return a.c < b.c;
}

int Find(int i) {
    if(CC[i] == 0) return i;
    return CC[i] = Find(CC[i]);
}

void Kruskal() {
    sort(M+1, M+m+1, comp);

    for (int i=1; i<=m; i++) {
        int ci = Find(M[i].i),
            cj = Find(M[i].j);
        if (ci != cj) {
            cost += M[i].c;
            CC[ci] = cj;
            nrM[++nm] = i;
            if (nm == n-1) break;
        }
    }
}

int main()
{
    citire();
    Kruskal();
    afis();
    f.close();
    g.close();
    return 0;
}
