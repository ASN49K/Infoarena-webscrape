#include <bits/stdc++.h>
using namespace std;

const int MAX = 1e5;
int p[MAX + 1], sz[MAX + 1];

int Find(int x) {
    while (x != p[x]) x = p[x];
    return x;
}

bool Union(int x, int y) {
    x = Find(x);
    y = Find(y);
    if(x == y) return false;
    if (sz[x] < sz[y]) {
        p[x] = p[y];
        sz[y] += sz[x];
        sz[x] = 0;
    } else {
        p[y] = x;
        sz[x] += sz[y];
        sz[y] = 0;
    }
    return true;
}

struct e { int u, v, w; };

int main() {
    int n, m;
    cin >> n >> m;

    vector<e> v(m);

    for(auto& x : v) {
        cin >> x.u >> x.v >> x.w;
    }

    for (int i = 1; i <= n; i++) {
        p[i] = i;
        sz[i] = 1;
    }

    std::sort(v.begin(), v.end(), [](const e& a, const e& b){return a.w < b.w;});

    long long cost = 0;
    vector<pair<int,int>> used;

        for(const auto& x: v){
        if(Union(x.u, x.v)){
            cost += x.w;
            used.emplace_back(x.u, x.v);
            if((int)used.size() == n-1) break;
        }
    }

    cout << cost << "\n" << used.size() << "\n";
    for(auto [u,v]: used) cout << v << ' ' << u << "\n";

    return 0;
}