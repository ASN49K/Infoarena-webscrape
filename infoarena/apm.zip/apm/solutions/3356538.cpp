#include <bits/stdc++.h>
#define int long long
using namespace std;

const int nm=2e5+5;

vector<vector<int>> v;
map<pair<int, int>, int> mp;
int ver[nm], p[nm];
int viz[nm];

signed main()
{
    ifstream cin("apm.in");
    ofstream cout("apm.out");
    int n, m, a, b, c, cnt=0;
    cin>>n>>m;
    v.resize(n+5);
    for(int i=1; i<=m; i++)
    {
        cin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        mp[{a, b}]=c;
        mp[{b, a}]=c;
    }
    priority_queue<pair<int, int>> pq;
    for(int i=2; i<=n; i++)
        ver[i]=1e9;
    ver[1]=0;
    pq.push({0, 1});
    while(!pq.empty())
    {
        int y=pq.top().second;
        pq.pop();
        if(viz[y]==1)
            continue;
        viz[y]=1;
        for(auto it:v[y])
        {
            if(viz[it]==0 && ver[it]>mp[{it, y}])
            {
                p[it]=y;
                ver[it]=mp[{it, y}];
                pq.push({-mp[{it, y}], it});
            }
        }
    }
    for(int i=2; i<=n; i++)
        cnt+=ver[i];
    cout<<cnt<<'\n';
    cout<<n-1<<'\n';
    for(int i=2; i<=n; i++)
        cout<<i<<" "<<p[i]<<'\n';
    return 0;
}
