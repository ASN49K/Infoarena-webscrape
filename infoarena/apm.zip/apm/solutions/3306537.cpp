#include <bits/stdc++.h>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
const int NMAX=2e5;
vector<int> parent(NMAX+5), status(NMAX+5);

struct drum{
    int x, y, cost;
};
vector<drum> muchii;
bool sortare(drum a, drum b){
    return a.cost<b.cost;
}
int find_set(int nod){
    if(nod==parent[nod]){
        return nod;
    }
    return parent[nod]=find_set(parent[nod]);
}
void union_set(int nod1, int nod2){
    nod1=find_set(nod1);
    nod2=find_set(nod2);
    if(nod1!=nod2){
        if(status[nod2]>status[nod1]){
            swap(nod1,nod2);
        }
        parent[nod2]=nod1;
        status[nod1]+=status[nod2];
    }
}
int main(){
    int n, m;
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        drum aux;
        fin>>aux.x>>aux.y>>aux.cost;
        muchii.push_back(aux);
    }
    sort(muchii.begin(),muchii.end(),sortare);
    int ans=0;
    for(int i=1;i<=n;i++){
        parent[i]=i;
        status[i]=1;
    }
    vector<drum> answer;
    for(int i=0;i<m;i++){
        if(find_set(muchii[i].x)!=find_set(muchii[i].y)){
            union_set(muchii[i].x,muchii[i].y);
            ans+=muchii[i].cost;
            answer.push_back(muchii[i]);
        }
    }
    fout<<ans<<'\n'<<answer.size()<<'\n';
    for(auto it:answer){
        fout<<it.x<<' '<<it.y<<'\n';
    }
}
