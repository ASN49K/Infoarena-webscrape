#include <bits/stdc++.h>
using namespace std;

ifstream fin("apm.in");
ofstream fout("apm.out");

struct muchie
{
    int x, y, c, ales;
    bool operator< (muchie m) const
    {
        return c < m.c;
    }
} a[200003];
int n, m, t[200003], costTotal;

void Union(int x, int y)
{
    t[y] = x;
}

int Find(int x)
{
    int y, rad = x;
    while (t[rad] != 0)
        rad = t[rad];
    while (x != rad)
    {
        y = t[x];
        t[x] = rad;
        x = y;
    }
    return rad;
}
void Citire()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
        fin >> a[i].x >> a[i].y >> a[i].c;
}

void Kruskal()
{
    int i, nrc = n, x, y;
    sort(a + 1, a + m + 1);
    for(i = 1; i <= m && nrc > 1; i++)
    {
        x = Find(a[i].x);
        y = Find(a[i].y);
        if (x != y)
        {
            Union(x, y);
            nrc--;
            costTotal += a[i].c;
            a[i].ales = 1;
        }
    }
}

void Afis()
{
    int i, cnt = 0;
    fout << costTotal << "\n";
    for (i = 1; i <= m; i++)
        if (a[i].ales == 1) cnt++;
    fout << cnt << "\n";
    for (i = 1; i <= m; i++)
        if (a[i].ales == 1)
            fout << a[i].x << " " << a[i].y << "\n";
}

int main()
{
    Citire();
    Kruskal();
    Afis();
    return 0;
}

//0, 1, 3-5, 7-18, 21, 22, 24-27, 29, 30, 34-36, 42, 44, 45, 47, 48, 51, 54, 56-58
