#include <bits/stdc++.h>
using namespace std;

struct muchie {int a,b,c;};
const int nmax=200005,mmax=400005;
muchie muchii[mmax];
int tata[nmax],rangul[nmax],sol_a[nmax],sol_b[nmax],n,m;
ifstream fin("apm.in");
ofstream fout("apm.out");
int radacina(int x){
    if(tata[x]==x)return x;
    tata[x]=radacina(tata[x]);
    return tata[x];
}

void unire(int x,int y){
    x=radacina(x);
    y=radacina(y);
    if(x==y)return;
    if(rangul[x]<rangul[y])tata[x]=y;
    else if(rangul[y]<rangul[x])tata[y]=x;
    else{tata[y]=x;rangul[x]++;}
}

int main()
{

    fin>>n>>m;
    for(int i=1;i<=m;i++)fin>>muchii[i].a>>muchii[i].b>>muchii[i].c;
    for(int i=1;i<m;i++)
        for(int j=i+1;j<=m;j++)
            if(muchii[i].c>muchii[j].c){
                muchie aux=muchii[i];
                muchii[i]=muchii[j];
                muchii[j]=aux;
            }
    for(int i=1;i<=n;i++){tata[i]=i;rangul[i]=0;}
    long long cost=0;
    int nr=0;
    for(int i=1;i<=m&&nr<n-1;i++){
        int x=muchii[i].a,y=muchii[i].b,c=muchii[i].c;
        if(radacina(x)!=radacina(y)){
            unire(x,y);
            cost+=c;
            nr++;
            sol_a[nr]=x;
            sol_b[nr]=y;
        }
    }
    fout<<cost<<'\n'<<nr<<'\n';
    for(int i=1;i<=nr;i++)fout<<sol_a[i]<<' '<<sol_b[i]<<'\n';

    return 0;
}
