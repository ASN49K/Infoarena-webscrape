#include <fstream>
#include <algorithm>
using namespace std;
const int NMAX = 100;

struct muchie
{
    int i, j, c;
};
int n, m, cost;
muchie M[4951];
int CC[NMAX + 1];
int NrM[NMAX];
int nm;
ifstream f("apm.in");
ofstream g("apm.out");

void citire() {
    f >> n >> m;
    for (int k = 1; k <= m; k++)
        f >> M[k].i >> M[k].j >> M[k].c;

}

void afis() {
    g << cost << '\n';
    g<<nm<<'\n';
    for (int i = 1; i <= nm; i++)
    {
        int k=NrM[i];
        g<<M[k].i<<' '<< M[k].j << '\n';
    }
}
bool comp(const muchie &a, const muchie &b)
{
    return a.c < b.c;
}

int Find(int i)
{
    if (CC[i] == 0)
        return i;
    return CC[i] = Find(CC[i]);
}

void Kruskal()
{
    sort(M + 1, M + m + 1, comp);
    for (int i = 1; i <= m; i++)
    {
        int ci = Find(M[i].i);
        int cj = Find(M[i].j);

        if (ci != cj) {
            cost += M[i].c;
            CC[ci] = cj;
            NrM[++nm] = i;

            if (nm == n - 1) break;
        }
    }
}

int main()
{
    citire();
    Kruskal();
    afis();
    return 0;
}
