#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");

int const INF=1e9;
int n, m, i, a, b, c;
int tata[200005], dist[200005], vaz[200005];
vector<pair<int, int>> ad[200005];
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;

int main()
{
    fin>>n>>m;

    for(i=1;i<=m;i++){
        fin>>a>>b>>c;
        ad[a].push_back({b, c});
        ad[b].push_back({a, c});
    }

    for(i=2;i<=n;i++){
        dist[i]=INF;
    }

    q.push({0, 1});
    while(!q.empty()){
        int nod=q.top().second;
        int c=q.top().first;

        q.pop();

        if(c>dist[nod]){
            continue;
        }

        vaz[nod]=1;

        for(i=0;i<ad[nod].size();i++){
            int vecin=ad[nod][i].first;
            int cost=ad[nod][i].second;
            if(cost<dist[vecin] && !vaz[vecin]){
                dist[vecin]=cost;
                q.push({cost, vecin});
                tata[vecin]=nod;
            }
        }
    }

    int sum=0;
    for(i=1;i<=n;i++){
        sum+=dist[i];
    }

    fout<<sum<<'\n';
    fout<<n-1<<'\n';
    for(i=2;i<=n;i++){
        fout<<i<<" "<<tata[i]<<"\n";
    }


    return 0;
}
