#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
int n, m, i, j, x1, y, c, parent[200005], sze[200005], rez;
set <tuple<int, int, int>> s;
vector <pair<int, int>> ans;
int find_set(int nod)
{
    if(parent[nod]==nod)
        return nod;
    return parent[nod]=find_set(parent[nod]);
}
void union_set(int a, int b)
{
    a=find_set(a);
    b=find_set(b);
    if(a!=b)
    {
        if(sze[a]<sze[b])
            swap(a, b);
        sze[a]+=sze[b];
        parent[b]=a;
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=n; i++)
    {
        parent[i]=i;
        sze[i]=1;
    }
    for(i=1; i<=m; i++)
    {
        fin>>x1>>y>>c;
        s.insert(make_tuple(c, x1, y));
    }
    for(auto i: s)
    {
        int c=get<0>(i);
        int x=get<1>(i);
        int y=get<2>(i);
        if(find_set(x)!=find_set(y))
        {
            union_set(x, y);
            rez+=c;
            ans.push_back({x, y});
        }
    }
    fout<<rez<<" "<<n-1<<'\n';
    for(auto i: ans)
        fout<<i.first<<" "<<i.second<<'\n';
    return 0;
}
