#include <fstream>
#include <queue>
#define NMAX 200002
#define MMAX 400002
using namespace std;
ifstream fin("apm.in");
ofstream fout("apm.out");
struct muchie
    {
        int x,y,c;
        friend bool operator < (muchie a,muchie b);
    };
int n,m;
int tata[NMAX],h[NMAX];
muchie apm[MMAX];
int costmin;

bool operator < (muchie a,muchie b)
{
    return a.c > b.c;
}
int Find(int x);
void Union(int x,int y);
void citire();
void kruskal();
void afisare();
priority_queue<muchie> H;

int main()
{
    citire();
    kruskal();
    afisare();
    return 0;
}

int Find(int x)
{
    int y,rx;
    //determin radacina arborelui
    rx=x;
    while(tata[rx]) rx=tata[rx];
    //rx este radacina arborelui
    //compresez drumul de la x la rx, fiecare nod de pe acest drum devine fiu al lui rx
    while(tata[x] && tata[x]!=rx)
    {
        y=tata[x];
        tata[x]=rx;
        x=y;
    }
    return rx;
}
void Union(int x,int y)
{
    int rx,ry;
    //reuneste arborele in care se afla x cu arborele in care se afla y
    rx=Find(x); ry=Find(y);
    if(h[rx]<h[ry]) tata[rx]=ry;
    else if(h[ry]<h[rx]) tata[ry]=rx;
    else
    {
        tata[ry]=rx;
        h[rx]++;
    }
}
void citire()
{
    int i,x,y,c;
    muchie aux;
    fin>>n>>m;
    for(i=0;i<m;i++)
    {
        fin>>aux.x>>aux.y>>aux.c;
        H.push(aux);
    }
}
void kruskal()
{
    int rx,ry,nrsel;
    muchie aux;
    nrsel=0;
    while(nrsel<n-1)
        {
            aux=H.top(); H.pop();
            rx=Find(aux.x); ry=Find(aux.y);
            if(rx!=ry)
            {
                costmin+=aux.c;
                apm[++nrsel]=aux;
                Union(rx,ry);
            }
        }
}
void afisare()
{
    int i;
    fout<<costmin<<'\n';
    for(i=1;i<n;i++)
        fout<<apm[i].x<<' '<<apm[i].y<<'\n';
}
