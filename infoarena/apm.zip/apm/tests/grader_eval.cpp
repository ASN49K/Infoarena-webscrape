#include <stdio.h>
#include <algorithm>
#include <vector>

using namespace std;

#define NMax 400005
#define PII pair< pair<int, int>, int >
#define x first.first
#define y first.second
#define z second
#define pb push_back
#define mp make_pair

int N, M, Cost, Edges, C2, E2, cnt, lg;
int uz[NMax];
vector<int> G[NMax];
PII E[NMax];

void result(char msg[], int p)
{
    fprintf(stderr, msg);
    printf("%d", p);
    exit(0);
}

inline bool smaller(PII a, PII b)
{ return a.x < b.x || (a.x == b.x && a.y < b.y); }

int find(int u, int v)
{
    int i, poz = 0;
    PII pair = mp( mp(u, v), 0 );
    
    for (i = lg; i; i >>= 1)
        if (poz + i <= M && smaller(E[poz+i], pair))
            poz += i;
    if (poz < M && E[poz+1].x == u && E[poz+1].y == v)
        return poz+1;
    return 0;        
}

void df(int nod)
{
    int i, sz, xx;
    
	uz[nod] = 1;
	for (i = 0, sz = G[nod].size(); i < sz; ++i)
	   if (!uz[xx = G[nod][i]])
	       df(xx);
}

int main()
{
	FILE *f;
	int i, j, u, v;

	f = fopen("apm.in", "r");
	if (!f) result("Fisier de intrare lipsa!", 0);
    if (fscanf(f, "%d %d", &N, &M) != 2) result("Fisier de intrare corupt!", 0);
    for (i = 1; i <= M; ++i)
    {
        if (fscanf(f, "%d %d %d", &E[i].x, &E[i].y, &E[i].z) != 3)
            result("Fisier de intrare corupt!", 0);
        if (E[i].x > E[i].y)
            j = E[i].x, E[i].x = E[i].y, E[i].y = j;
    }
	fclose(f);
	
	f = fopen("apm.ok", "r");
	if (!f) result("Fisier ok lipsa!", 0);	
	if (fscanf(f, "%d\n%d", &Cost, &Edges) != 2) result("Fisier ok corupt!", 0);
	fclose(f);
	
	f = fopen("apm.out", "r");
	if (!f) result("Fisier de iesire lipsa!", 0);
	if (fscanf(f, "%d\n", &C2) != 1) result("Prima linie in format incorect!", 0);
	if (Cost != C2) result("Cost incorect", 0);	
	if (fscanf(f, "%d\n", &E2) != 1) result("A doua linie in format incorect!", 0);
	if (Edges != E2) result("Numar de muchii incorect", 0);

    sort(E+1, E+M+1);
    for (lg = 1; lg < M; lg <<= 1);
	for (i = 1; i <= Edges; ++i)
	{        
		if (fscanf(f, "%d %d\n", &u, &v) != 2) 
            result("Solutia nu e afisata in format corect!", 0);            
        if (u < 1 || v < 1 || u > N || v > N)
            result("Solutia nu e afisata in format corect!", 0);            
        if (u > v)
            j = u, u = v, v = j;
        j = find(u, v);
        if (!j) result("Muchia nu se gaseste in graful initial", 0);
        cnt += E[j].z;
		G[u].pb(v); G[v].pb(u);
	}
	
	df(1);	
	for(i = 1; i <= N; ++i)
		if (!uz[i])
		   result("Subgraful selectat nu e arbore", 0);
		   
    if (cnt != Cost)
        result("Arborele selectat nu are costul minim", 0);

	result("Corect", 10);
		
	return 0;	
}
