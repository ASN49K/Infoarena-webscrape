#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");
int a[2000005];

int ciur(int n)
{
    for(int i=2;i*i<=n;i++)
    {
        if(!a[i])
        for(int j=i*i;j<=n;j+=i)
        {
            a[j]=1;
        }
    }
    int nr=0;
    for(int i=2;i<=n;i++)
        if(!a[i])
        nr++;
    return nr;
}

int main()
{
    int n;
    fin>>n;
    fout<<ciur(n);
    return 0;
}
