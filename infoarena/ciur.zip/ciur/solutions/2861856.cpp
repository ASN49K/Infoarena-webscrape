#pragma region
#include <bits/stdc++.h>
using namespace std;
#define ll long long
// Fisiere
ifstream fin("ciur.in");
ofstream fout("ciur.out");

const ll N = 2'000'005;
bool ciur[N];
#pragma endregion



void solve() {
    ll n; fin >> n;

    ciur[0] = ciur[1] = true;
    int cnt = 0;
    for (ll i = 2; i <= n; i++) {
        if (i <= n && ciur[i] == false)
            ++cnt;
        for (ll j = 2; i * j <= n; j++)
            ciur[i * j] = true;
    }

    fout << cnt;
}

int main() {
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    int t = 1;  //cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}