#include <fstream>
#include <bitset>
using namespace std;
ifstream fcin("ciur.in");
ofstream fout("ciur.out");
int n,a,b,nr;
bitset <2001000> c;
int main()
{
    fcin>>n;
    for(int i=2; i<=n; i++)
    {
        if(c[i]==0)
        {
            nr++;
            for(int j=i*i; j<=n; j+=i)
                c[j]=1;
        }
    }
    fout<<nr;
    return 0;
}
