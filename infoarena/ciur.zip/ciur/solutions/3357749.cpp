#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream in("ggboi.in");
    ofstream out("ggboi.out");
    
    int n;
    in >> n;
    
    long long sum = 0;
    for (int i = 0; i < n; i++) {
        int x;
        in >> x;
        sum += x;
    }
    
    out << sum << '\n';
    
    in.close();
    out.close();
    return 0;
}