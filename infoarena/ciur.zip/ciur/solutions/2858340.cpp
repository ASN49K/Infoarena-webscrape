#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
bool a[2000001];
int main()
{
    int n,counter=0;
    fin>>n;
    for(int i=2;i<=n;i++)
    {
        if(a[i]==0)
        {
           for(int j=i+i;j<=n;j=j+i)
           {
                a[j]=1;
           }
            counter++;
        }
    }
    fout<<counter;
    return 0;
}
