#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool erat[2000005];

int main()
{
    int n;
    fin>>n;
    for(int div=2;div*div<=n;div++){
        if(erat[div]==1){
            continue;
        }
        for(int mult=2*div;mult<=n;mult+=div){
            erat[mult]=1;
        }
    }
    int prim=0;
    for(int i=2;i<=n;i++){
        if(erat[i]==0)
            prim++;
    }


    fout<<prim;

    return 0;
}
