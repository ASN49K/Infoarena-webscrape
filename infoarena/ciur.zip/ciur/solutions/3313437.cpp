#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bitset<2000001> ciur;
void Ciur()
{
    ciur[0]=ciur[1]=1;
    for(int i=4; i<=2000000; i+=2)
    {
        ciur[i]=1;
    }
    for(int i=3; i*i<=2000000; i+=2)
    {
        if(ciur[i]==0)
            for(int j=i*i; j <=2000000; j+=2*i)
                ciur[j]=1;
    }
}

int main()
{
    int n, cnt, a;
    fin >> n;
    Ciur();
    for(int i=1; i<=n; i++)
    {
        //cin >> a;
        if(ciur[i]==0)
            cnt++;
    }
    fout << cnt;
    return 0;
}
