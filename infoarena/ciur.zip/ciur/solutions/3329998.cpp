#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

const int NMAX=2000001;
bool v[NMAX];
int nr;

void ciur(int n)
{
    int i,j;
    v[0]=v[1]=1;
    for(i=4; i<=n; i+=2)
        v[i]=1;
    for(i=3; i*i<=n; i+=2)
    {
        if(v[i]==0)
        {
            for(j=i*i; j<=n; j+=i)
                v[j]=1;
        }
    }
    for(int i=1; i<=n; i++){
        if(v[i]==0)
            nr++;
    }
}

int main()
{
    int n;
    f>>n;
    ciur(n);
    g<<nr;
    return 0;
}
