#include <bits/stdc++.h>
using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

#define NMAX 2000005
int N, c[NMAX];

int main()
{
    f >> N;
    int k = N;
    c[0] = c[1] = 1;
    for(int i=2;i*i<=N;++i)
        if(c[i] == 0)
            for(int j=2;i*j<=N;++j)
            {
                c[i*j] = 1;
                k--;
            }
    g << k;
}
