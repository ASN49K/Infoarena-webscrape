#include <bits/stdc++.h>

using namespace std;
int n,nr,v[2000005];
ifstream f("ciur.in");
ofstream g("ciur.out");

int main()
{f>>n;

    for(int i=2;i<=n;i++)
       if(v[i]==0)
       {for(int j=i;j<=n;j+=i)
        v[j]=1;
        nr++;
       }
       g<<nr;

    return 0;
}
