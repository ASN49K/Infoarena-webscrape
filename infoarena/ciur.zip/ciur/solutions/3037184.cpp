#include <bits/stdc++.h>
using namespace std;

bitset<2000005> ciur;
int main(void){
    ofstream cout("ciur.out");
    ifstream cin("ciur.in");
    int n,ans = 0;
    cin >> n;
    for(int i = 2;i<=n;i++){if(ciur[i] == 0){ans++; for(int j = 2;j*i<=n;j++)ciur[i * j] = 1;}}
    cout << ans;
}
