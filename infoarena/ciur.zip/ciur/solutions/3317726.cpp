#include <fstream>
using namespace std;

const int VMAX = 2e6;
bool c[VMAX + 1];

int main() {
    ifstream in("ciur.in");
    ofstream out("ciur.out");

    int n;
    in >> n;
    for (int i = 2; i * i <= n; i++) {
        if(!c[i]) {
            for (int m = i * i; m <= n; m += i) {
                c[m] = true;
            }
        }
    }

    int nr_prime = 0;
    for (int i = 2; i <= n; i++) {
        if (!c[i]) {
            nr_prime++;
        }
    }
    out << nr_prime << "\n";

    in.close(); out.close();
    return 0;
}
