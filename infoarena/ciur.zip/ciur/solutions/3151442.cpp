#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <deque>
#include <iomanip>
#include <vector>

#pragma GCC optimize("O3")
#define fi first
#define se second
#define pb push_back
#define pf push_front

using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
typedef long long ll;
const ll Nmax=2e6+5, inf=1e9+5;
using pll=pair<ll, ll>;

int n;
bool ciur[Nmax];
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    fin>>n;
    for (int i=2; i*i<=n; i++)
        if (!ciur[i])
            for (int j=i*i; j+=i; j<=n; j++)
                ciur[j]=1;
    int sol=0;
    for (int i=2; i<=n; i++)
        if (!ciur[i])
            crt++;
    fout<<crt;
    return 0;
}
