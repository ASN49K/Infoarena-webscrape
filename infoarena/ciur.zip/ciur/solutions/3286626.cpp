#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int N=2000000;
bitset<N+1>ciur;
void Ciur()
{
    ciur[0]=ciur[1]=1;
    for(int i=4; i<=N; i+=2)
        ciur[i]=1;
    for(int i=3; i*i<=N; i+=2)
        if(ciur[i]==0)
            for(int j=i*i; j<=N; j+=2*i)
                ciur[j]=1;
}
int main()
{
    Ciur();
    int n, cnt=0;
    fin >> n;
    for(int i=2; i<=n; i++)
        if(ciur[i]==0)
            cnt++;
    fout << cnt;
    return 0;
}
