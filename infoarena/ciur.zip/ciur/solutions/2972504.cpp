#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int prim[10000];

int main()
{
    int n,c=0;
    fin >> n;
    for (int i=2;i<=n;i++)
        prim[i]=1;
    for (int i=2;i<=n;i++)
    {
        if (prim[i]==1)
        {
            c++;
            for (int j=i+i;j<=n;j+=i)
            {
                prim[j]=0;
            }
        }
    }
    fout << c;
    return 0;
}
