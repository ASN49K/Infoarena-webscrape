#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n, v[2000001], nr;
int main()
{
    fin>>n;
    v[0]=1;
    v[1]=1;
    for(int i=2; i<=2000000; i++)
    {
        if(v[i]==0)
        {
            for(int j=i+i; j<=2000000; j+=i)
            {
                v[j]=1;
            }
            nr++;
        }
        if(i==n)
        {
            fout<<nr;
            return 0;
        }
    }
    return 0;
}
