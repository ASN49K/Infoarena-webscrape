#include <bits/stdc++.h>

#define MAX 2000000
#pragma GCC optimize("O3")

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

vector <bool> ciur(MAX + 5);

int n, ans = 1;

int main()
{
    fin >> n;
    ciur[0] = ciur[1] = 1;
    for(int i = 4; i <= n; i += 2)
        ciur[i] = 1;
    for(int i = 3; i <= n; i += 6)
        ciur[i] = 1;
    if(n >= 3)
        ans++;
    for(int i = 5;i <= n; i += 6)
    {
        if(!ciur[i])
        {
            ans++;
            for(int j = i + i + i;j <= n; j += i << 1)
                ciur[j] = 1;
        }
        if(!ciur[i + 2] && i + 2 <= n)
        {
            ans++;
            for(int j = i + i + i + 6; j <= n; j += (i + 2) << 1)
                ciur[j] = 1;
        }
    }
    fout << ans;
}
