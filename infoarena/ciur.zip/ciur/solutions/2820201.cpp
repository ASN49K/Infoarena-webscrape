#include<bits/stdc++.h>
using namespace std;
int ciur(int n)
{
    int gasit=0;
    if(n%2==0)
        return 0;
    for(int i=3;i*i<=n && !gasit;i+=2)
    {
        if(n%i==0)
            gasit=1;
    }
    if(gasit)
        return 0;
    else
        return 1;
}
int main()
{
    ifstream f("citire.in");
    ofstream g("citire.out");
    int N,c=2;
    f>>N;
    for(int i=5;i<=N;i+=2)
    {
        if(ciur(i))
            c++;
    }
    g<<c;






}
