#include <bits/stdc++.h>
#define oo 2000000001
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n, cnt, d[200003];

void Eratostene(int n)
{
    int i, j;
    for (i = 2; i <= n; i++)
    {
        d[i] += 2;
        if (d[i] == 2)
            for (j = 2 * i; j <= n; j += i)
                d[j]++;
    }
}

int main()
{
    fin >> n;
    Eratostene(n);
    for (int i = 2; i <= n; i++)
        if (d[i] == 2) cnt++;
    fout << cnt << "\n";
    return 0;
}
//0 1 3 4 5 7 8 9 10 11 12 13 14 15 16 17 18 21 22 24 25 26 27 29 30 34 35 36 42 44 45 47 48 51 54 56 57 58
