#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int v[2000005];
int n, sol;

void nr_prime(int n)
{
    for(int d = 2 ;  d * d <= n ; d++)
    {

        for(int m = d * 2 ; m <= n ; m += d)
        {
            v[m] = 1;
        }
    }
}

int main()
{
    fin >> n;
    nr_prime(n);

    for (int i =  1 ; i  <= n ; i++)
    {
        v[1] = 1;
        if(v[i] == 0)
        {
            sol++;
        }
    }
    fout << sol;
    return 0;
}
