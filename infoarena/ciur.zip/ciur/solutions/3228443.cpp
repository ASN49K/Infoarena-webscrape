#include<bits/stdc++.h>
using namespace std;
ifstream F("ciur.in");
ofstream G("ciur.out");
int n,i,j;
bitset<2000001> a;
int main()
{
    for(F>>n,i=3;i*i<=n;i+=2)
        if(!a[i])
            for(j=i*i;j<=n;a[j]=1,j+=2*i);
    return G<<(n+1)/2-a.count(),0;
}
