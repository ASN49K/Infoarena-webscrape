#include <fstream>

using namespace std;
bool ciur[2000005];

int main() {
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");
    ciur[0] = 1;
    ciur[1] = 1;
    for (int i = 0; i * i <= 2000000; i++) {
        if (ciur[i] == 0) {
            for (int j = i * i; j <= 2000000; j = j + i) {
                ciur[j] = 1;
            }
        }
    }
    int n, a, cnt = 0;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> a;
        if (ciur[a] == 0) {
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}

