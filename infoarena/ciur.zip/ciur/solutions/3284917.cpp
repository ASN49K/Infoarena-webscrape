#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,x,y,i,r,Ciur[2000001],j,cnt;
int main()
{
    fin>>n;
    Ciur[0]=Ciur[1]=1;
    for(i=1; i<=n; i++)
    {
        if(Ciur[i]==0)
        {
            for(j=i; j<=n; j+=i)
            {

                Ciur[i*j]=1;
            }
        }

    }
    for(i=1; i<=n; i++)
    {
        if(Ciur[i]==1)
        {
            cnt++;
        }
    }
    fout<<cnt;
    return 0;
}
