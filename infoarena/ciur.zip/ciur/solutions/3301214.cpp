#include <fstream>
using namespace std;
#define DN 2000024

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool v[DN];

int main() {
  int n, nrprime = 0;
  fin >> n;
  for (int i = 2; i <= n; i++) {
    v[i] = 1;
  }
  for (int i = 2; i <= n; i++) {
    if (v[i]) {
      nrprime++;
      for (int j = i + i; j <= n; j += i)
        v[j] = 0;
    }
  }

  fout << nrprime;
  return 0;
}

// https://infoarena.ro/problema/ciur