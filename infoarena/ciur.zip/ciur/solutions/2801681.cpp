#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>

#define ll long long
#define nmax 2000005

using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
bitset < nmax > is_prime;
vector < long long > prime_nr;
ll nr_of_primes=0;
ll n;



void ciur()
{
    for ( ll i=2; i<=n; i++ ){
        if ( is_prime[i]==0 ){
            for ( ll j=i*i; j<=n; j+=i )
                is_prime[j]=1;
        }
        prime_nr.push_back(i);
        nr_of_primes++;
}
}

int main()
{
    f>>n;
    ciur();
    g<<nr_of_primes;

    return 0;
}
