#include <bits/stdc++.h>

using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

int n,m,i,j,k,ap[2000010];
bitset <2000010> ciur;

int main()
{
    ap[0]=ap[1]=0;
    for(i=2; i<=2000000; i++)
    {
        if(ciur[i]==0)
        {
            k++;
            for(j=2; i*j<=2000000; j++)
            {
                ciur[i*j]=1;
            }
        }
        ap[i]=k;
    }
    f>>n;
    g<<ap[n];
    return 0;
}
