#include <iostream>

using namespace std;
FILE *f=fopen("ciur.in","r");
FILE *g=fopen("ciur.out","w");
int n;
bool p[2000005];
inline int ciur(){
int ans=1;
for(int i=4;i<=n;i+=2)p[i]=1;
for(int i=3;i<=n;i+=2)
    if(p[i]==0){
        ++ans;
        for(int j=2*i;j<=n;j+=i)
            p[j]=1;
    }
return ans;
}
int main()
{
    fscanf(f,"%d ",&n);
    fprintf(g,"%d ",ciur());
}
