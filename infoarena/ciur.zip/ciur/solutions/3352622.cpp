#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int main() 
{
    int N;
    fin >> N;

    bool prim[2000001];

    for (int i = 0; i <= N; i++)
        prim[i] = true;

    prim[0] = prim[1] = false;

    for (int i = 2; i * i <= N; i++) 
    {
        if (prim[i]) 
        {
            for (int j = i * i; j <= N; j += i)
                prim[j] = false;
        }
    }

    int cnt = 0;
    for (int i = 2; i <= N; i++) 
    {
        if (prim[i])
            cnt++;
    }
    cout <<"hello";
    fout << cnt;
}