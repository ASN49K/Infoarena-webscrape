#include <iostream>
#include <fstream>
using namespace std;

ifstream f("bac.txt");
//ofstream g("bleach.out");

void sortarev(long long A[], long long L)
{
    long long i,j,aux;
    for(i = 0; i <= L - 1; i++)
    {
        for(j = i + 1; j <= L; j++)
        {
            if(A[i] > A[j])
            {
                aux = A[i];
                A[i] = A[j];
                A[j] = aux;
            }
        }
    }
}

int main()
{
    long long N,V[1001],pin,s;
    int K,i,j;
    f>>N>>K;

    for(i = 0; i <= K ; i++)
      f>>V[i];
    sortarev(V,K);

    pin=1;
    s=pin;
    for(i = K + 1 ; i < N ; i++){

        if(V[0]<=s)
          s+=V[0];
        if(V[0]>s){
          pin=pin+(V[0]-s);
          s=s+V[0]+(V[0]-s);
        }

        for(j = 0 ; j < K - 1 ; j++){
          V[j]=V[j+1];
        }
        f>>V[K];
        sortarev(V,K);

    }

    for(i=0;i<=K;i++){
      if(V[i]<=s)
        s+=V[0];
      if(V[i]>=s){
        pin=pin+(V[i]-s);
        s=s+V[i]+(V[i]-s);
      }
    }
    cout<<pin;
    return 0;
}
