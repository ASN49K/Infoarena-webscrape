#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int v[2000005];

int main() {
    int n, nr = 0;
    fin >> n;
    v[0] = v[1] = 1;
    for (int i = 2; i <= n; i++)
        if (!v[i]) {
            nr++;
            for (int j = i + i; j <= n; j += i)
                v[j] = 1;
        }
    fout << nr;
    return 0;
}
