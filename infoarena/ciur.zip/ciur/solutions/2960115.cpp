#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n, contor = 0, adv = 0, sir[4050];
    fin >> n;
    for(int i = 0; i <= n; ++i) {
        sir[i] = i;
    }
    for(int i = 2; i <= n; ++i) {
     //   cout << sir[i] << endl;
        if(sir[i] != - 1) {
                contor++;
            for(int j = i + 1; j <= n; ++j) {
                if(sir[j] % sir[i] == 0) {
                    sir[j] = -1;
                }
            }
        }
    }
    fout << contor;
    return 0;
}
