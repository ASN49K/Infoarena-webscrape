#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <time.h>

#pragma GCC optimize("Ofast")

#define is_set(x)  (bitmap[x>>6] & r[(x>>1) & 0x1f])
#define set_bit(x) (bitmap[x>>6] |= r[(x>>1) & 0x1f])

//#define is_set(x)  (bitmap[x>>6] & (1 << ((x>>1) & 0x1f)) )
//#define set_bit(x) (bitmap[x>>6] |= (1 << ((x>>1) & 0x1f)) )

#define is_set_tmp(x)  (bitmap[tmp2 = (x>>6)] & (tmp = (r[(x>>1) & 0x1f])))
#define set_bit_tmp(x) (bitmap[tmp2] |= tmp)
 
int i, j, N, nr = 0, tmp, tmp2; //, double_i;
unsigned int bitmap[31250];
unsigned int r[32];

//struct timespec start, stop;

int main()
{ 
	freopen( "ciur.in", "r", stdin );
	freopen( "ciur.out", "w", stdout);  
    scanf("%d",&N);

    //clock_gettime( CLOCK_REALTIME, &start);
    r[0] = 1;
    for (i = 1; i < 32; i++) {
    	r[i] = (r[i-1]<<1);
	}

    /*for (i = 3; (j = i*i) <= N; i += 2) {
    	int do_work = ((!is_set(i) && set_bit(j)) ? 1 : 0);
        	
        if (!do_work) {
        	continue;
		}
		nr += do_work;
        j += (double_i = (i<<1));

        while (1) {
            if (j > N) {
                break;
            }
            nr += ((!is_set(j) && set_bit(j)) ? 1 : 0);
            //if (j >= N - 1)
            //    break;
            j += double_i;
		}
    }*/
    
    for (i = 3; i*i <= N; i+=2) {
    	if (!is_set(i)) {
    		for (j = i*i; j <= N; j+=(i<<1)) {
    			//nr += (!is_set(j) && set_bit(j)) ? 1 : 0;
    			if (!is_set_tmp(j)) {
    				set_bit_tmp(j);
    				nr++;
				}
			}
		}
	}
    //clock_gettime( CLOCK_REALTIME, &stop);
    //printf( "%d seconds %d nanoseconds\n", stop.tv_sec - start.tv_sec, stop.tv_nsec - start.tv_nsec);
 
    printf("%d\n", (N+1)/2 - nr);
    return 0;
}
