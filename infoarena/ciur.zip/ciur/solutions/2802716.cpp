#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int v[50000001];

int main() {
    int n;
    fin >> n;
    int primeNr = 0;
    if (n >= 2) {
        primeNr = 1;
    }
    for (int i = 3; i <= n; i += 2) {
        if (v[i] != -1) {
            ++primeNr;
            for (long long j = i; i * j <= n; j += 2) {
                v[i * j] = -1;
            }
        }
    }
    fout << primeNr;
}
