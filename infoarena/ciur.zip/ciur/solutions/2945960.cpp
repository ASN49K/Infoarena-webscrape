#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_VALUE = 2000000;

int frequency[MAX_VALUE + 1];

void primeLessEqualNumber(int n, int &primeCounter) {
    for (int divisor = 2; divisor * divisor <= n; ++divisor) {
        if (frequency[divisor] == 0) {
            for (int number = 2; number * divisor <= n; ++number) {
                if (frequency[divisor * number] == 0) {
                    frequency[divisor * number] = 1;
                    --primeCounter;
                }
            }
        }
    }
}

int main() {
    int n;
    fin >> n;
    int primeCounter = n - 1;
    primeLessEqualNumber(n, primeCounter);
    fout << primeCounter;
    return 0;
}
/*
 2
 =>
 1
 
 3
 =>
 2
 
 4
 =>
 2
 
 5
 =>
 3
 
 10
 =>
 4
 
 11
 =>
 5
 */
