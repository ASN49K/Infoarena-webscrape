#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

vector<bool> isPrime(2e6 + 5, 1);
vector<int> primeNumbers(3e5);
int primeNumbersSize = 0;

void generatePrimeNumbers();

int main(){
    generatePrimeNumbers();

    long long number;

    fin >> number;

    long long left = 0, right = primeNumbersSize - 1, middle, indexFound = right;

    while(left <= right){
        middle = (left + right) / 2;

        if(number < primeNumbers[middle]){
            indexFound = middle;
            right = middle - 1;
        }else{
            left = middle + 1;
        }
    }

    fout << indexFound;

    return 0;
}

void generatePrimeNumbers(){
    primeNumbers[primeNumbersSize] = 2;
    primeNumbersSize++;

    for(long long i = 3; i <= 2e6; i += 2){
        if(isPrime[i]){
            primeNumbers[primeNumbersSize] = i;
            primeNumbersSize++;

            if(i <= 2e3){
                for(long long j = i * i; j <= 2e6; j += 2 * i){
                    isPrime[j] = false;
                }
            }
        }
    }
}