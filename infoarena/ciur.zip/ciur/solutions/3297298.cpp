#include <stdio.h>
#include <vector>

int main() {
  FILE *fin = fopen( "ciur.in", "r" );
  FILE *fout = fopen( "ciur.out", "w" );

  int n;
  fscanf( fin, "%d", &n );
  std::vector<bool> ciur(n + 1, false);
  for( int d = 2; d * d <= n; d++ )
    if( !ciur[d] )
      for( int i = d * d; i <= n; i += d )
        ciur[i] = true;

  int np = 0;
  for( int i = 2; i <= n; i++ )
    np += !ciur[i];

  fprintf( fout, "%d\n", np );

  fclose( fin );
  fclose( fout );
  return 0;
}
