#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

string cuv;

int ciur[2000001];

int main()
{
    long long int N,cnt=0;
    cin>>N;

    for(int div=2;div*div<=N;div++)
        if(ciur[div]==0)
        {
            for(int mult=2*div;mult<=N;mult+=div)
                ciur[mult]=1;
            cnt++;
        }
     cout<<cnt*2;
}
