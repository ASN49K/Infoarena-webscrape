#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
void Sieve_of_Erathosthene(int n){
bool prime[n+1];
memset(prime,true,sizeof(prime));
for(int p=2;p*p<=n;p++){
    if(prime[p]==true){
        for(int i=p*p;i<=n;i+=p){
            prime[i]=false;
        }
    }
}
int cont=0;
for(int i=2;i<=n;i++){
    if(prime[i]==true){
           cont++;
    }

}
fout<<cont;
}
int main()
{
   int n;
   fin>>n;
   Sieve_of_Erathosthene(n);
    return 0;
}
