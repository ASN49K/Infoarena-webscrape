#include <bits/stdc++.h>

using namespace std;
ifstream fin("fact.in");
ofstream fout("fact.out");
int main()
{int n, cont=0;
    fin>>n;
    int v[n+1];
    v[0]=1;
    v[1]=1;
    for(int i=1; i<=n; i++)
        v[i]=0;
    for(int i=2; i*i<=n; i++)
    {
        if(!v[i])
            for(int j=2; j<=n/i; j++)
                v[i*j]=1;
    }
    for(int i=2; i<=n; i++)
        if(!v[i])
            cont++;
    fout<<cont;
    return 0;
}
