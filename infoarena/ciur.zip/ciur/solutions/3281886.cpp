#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
bool a[2000005];
int i,n;
vector <int> v;
int main()
{
    f>>n;
    for(i=0; i<=2000004; i++) a[i]=false;
    for(i=2; i<=n; i++){
        if(a[i]==false){
            a[i]=true;
            v.push_back(i);
            for(int j=i+i; j<=n; j+=i) a[j]=true;
        }
    }
    g<<v.size();
    return 0;
}
