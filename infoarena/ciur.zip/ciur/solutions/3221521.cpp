#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool v[2000001];

int main() {
    int n,numar=0;
    fin>>n;
    v[0]=1;
    v[1]=1;
    for (int i=2; i<=n; i++) {
        if (v[i] == 0) {
            for (int j = 2; j * i <= n; j++) {
                v[j * i] = 1;
            }
        }
        if (v[i] == 0)
            numar++;
    }
    fout<<numar;

    return 0;
}
