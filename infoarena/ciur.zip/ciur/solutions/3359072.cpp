#include<iostream>
#include<fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n;
    fin>>n;

    bool v[1000001]= {0};

    for(int i=2; i*i<=n; i++)
    {
        if(!v[i])
        {
            for(int j=i*i; j<=n; j+=i)
            {
                v[j]=1;
            }
        }
    }

    int c=0;
    for(int i=2; i<=n; i++)
    {
        if(!v[i])c++;
    }

    fout<<c;
    return 0;
}


