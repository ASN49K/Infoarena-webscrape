#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
#define Nmax 200000
int N[Nmax];
int main(){
    int n;
    fin>>n;
    N[0]=1;
    int prim=0;
    N[1]=1;
    for(int i=2; i<=sqrt(n); i++){
        if(N[1]==0){
            for(int j=2; j<=n/i; j++){
                N[i*j]=1;
            }
        }
    }
    for(int i=2; i<=n/2; i++){
        if(N[i]==0){
            prim=prim+1;
            for(int j=2*i; j<=n;j+= i){
                N[j]=0;
            }
        }
    }
    fout<<prim;
    return 0;
}
