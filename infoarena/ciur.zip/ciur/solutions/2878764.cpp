#include <bits/stdc++.h>
using namespace std;

int solve(int n) {
    vector<bool> v(n);
    fill(v.begin() + 2, v.end(), true);

    for (int i = 2; i < sqrt(n); i++) {
        if (v[i] == true) {
            for (int j = i * i; j < n; j += i) {
                v[j] = false;
            }
        }
    }

    int res = 0;
    for (int i = 0; i < n; i++) {
        if (v[i] == true) {
            //cout << res << '\n';
            res++;
        }
    }
    return res;
}

int main() {
    ifstream in("ciur.in");
    ofstream out("ciur.out");
    int n;
    in >> n;


    long long res = solve(n);
    cout << res << '\n';
    out << res;

    in.close();
    out.close();
    return 0;
}
