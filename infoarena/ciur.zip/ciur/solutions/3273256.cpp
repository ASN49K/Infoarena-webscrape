#include <fstream>

using namespace std;

int n, v[2000001], fr[20000001];

ifstream cin ("ciur.in");
ofstream cout ("ciur.out");

int main() {
    cin >> n;
    v[1] = 1;
    for (int i = 2; i * i <= n; ++i) {
        if (v[i] == 0) {
            for (int j = 2; j <= n / i; ++j) {
                v[i * j] = 1;
            }
        }
    }
    for (int i = 1; i <= n; ++i) {
         ++fr[v[i]];
    }
    cout << fr[0];
    return 0;
}
