#include <iostream>
#include<fstream>
ifstream("ciur.in");
ofstream("ciur.out");

using namespace std;

int main()
{
    int x,ciur=1;
    fin>>x;
   {
    for(int i=1;i<=x;i++) ciur[i]=1;
    if(ciur[i]==0)
        for(int j=1;j*i<=x;j++) ciur[i*j]=1;
        for(int i=1;i<=x;i++)
            if(ciur[i]==0) ciur++;}


    fout<<"ciur";
    fout<<endl;
    return 0;
}
