#include <iostream>
#include <fstream>
#define ll long long
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n,a[2000001];
void ciur()
{
    int k=0;
    for(int i=2;i<=2000001;i++)
    {
        if(a[i]==0)
        {
            for(int j=2*i;j<=2000001;j+=i)
            {
                a[j]=1;
            }
            a[i]=++k;
        }
        a[i]=k;
    }
}
int main()
{
    fin>>n;
    ciur();
    fout<<a[n];
}
