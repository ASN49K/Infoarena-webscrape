#include <bits/stdc++.h>

using namespace std;

ifstream fin( "ciur.in" );
ofstream fout( "ciur.out" );

const int DIM = 2e6 + 1;

bool ciur[DIM];

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0);
  int n, cnt = 0;

  fin >> n;
  for ( int d = 2; d * d <= n; ++d ) {
	if ( !ciur[d] ) {
	  for ( int i = d * d; i <= n; i += d ) {
		ciur[i] = 1;
	  }
	}
  }
  for ( int i = 2; i <= n; ++i ) cnt += ciur[i] ^ 1;
  fout << cnt;
  fin.close();
  fout.close();
  return 0;
}
