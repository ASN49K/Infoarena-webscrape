#include <iostream>
#include <cstring>

using namespace std;

bool ciur[2000001];

int main()
{
    int i, n, cnt = 0;
    cin >> n;
    for (i = 2; i <= n; i++)
        for (int j = i * 2; j <= n; j += i)
            ciur[j] = 1;
    for (i = 2; i <= n; i++)
    {
        if (!ciur[i])
        {
            // cout << i << ' ';
            cnt++;
        }
    }
    cout << cnt;
}