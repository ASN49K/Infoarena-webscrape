#include <fstream>
#include <bitset>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
bitset <1000001> ciur;
int n,k=1;
void ciuruire()
{
    int i,j;
    for(i=3;i*i<=n;i+=2)
        if(ciur[(i>>1)]==0)
            for(j=i*i;j<=n;j+=(i<<1))
                ciur[(j>>1)]=1;
    for(i=1;(i<<1)+1<=n;i++)
        if(ciur[i]==0)
            k++;
}
int main()
{
    cin>>n;
    ciuruire();
    cout<<k;
    return 0;
}
