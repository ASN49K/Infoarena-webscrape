#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
  int n, res = 0;
  fin >> n;

  bitset<2000010> vis(false);
  for (int i = 2; i <= n; i++)
    if (vis[i] == false)
    {
      vis[i] = true;
      res++;
      for (long long j = (long long)i * i; j <= n; j += i)
        vis[j] = true;
    }

  fout << res;
  return 0;
}