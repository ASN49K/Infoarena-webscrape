﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 2000006
#define MOD 9901 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset <nmax> p;

void Ciur(int n)
{
	p[0] = p[1] = 1; // marcam cu 1 elementele NEprime
	for (int i = 4; i <= n; i += 2)
		p[i] = 1;
	for (int i = 3; i * i <= n; i += 2)
		if (!p[i]) // daca se crede prim
			for (int j = i * i; j <= n; j += 2 * i)
				p[j] = 1;
}

int main()
{
	int i, n, cnt;
	fin >> n;
	Ciur(n);
	cnt = 0;
	for (i = 1; i <= n; i++)
		if (!p[i])
			++cnt;
	fout << cnt << "\n";
	fin.close();
	fout.close();
	return 0;
}