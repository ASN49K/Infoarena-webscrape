#include <iostream>
#include <fstream>

#define MAX_SIZE 2000001

bool sieve[MAX_SIZE] = {false};

int main() {
    std::ifstream input("ciur.in");
    std::ofstream output("ciur.out");

    int n;
    input >> n;

    sieve[0] = sieve[1] = true;
    int cnt = 0;
    for (int i = 2; i <= n; ++i) {
        if (!sieve[i]) {
            cnt++;
            for (int j = 2; j * i <= n; ++j) {
                sieve[i * j] = true;
            }
        }
    }

    output << cnt;

    return 0;
}
