#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000005> v;
void Ciur(int n)
{
  int i, j;
  v[0] = v[1] = true;
  for(i = 4; i <= n; i += 2)
    v[i] = true;
  for(i = 3; i * i <= n; i += 2)
    if(!v[i])
      for(j = i * i; j <= n; j += 2 * i)
        v[j] = true;
}

int main()
{
  int n, cnt = 0;
  fin >> n;
  Ciur(n);
  if(n >= 2) cnt++;
  for(int i = 3; i <= n; i += 2)
    if(!v[i]) cnt++;
  fout << cnt;
}