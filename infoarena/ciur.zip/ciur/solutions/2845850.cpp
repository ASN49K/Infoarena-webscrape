#include <iostream>
#include <fstream>
#include <bitset>

using namespace std;
 
#ifdef LOCAL
ifstream f("input.txt");
#define g cout
#else
ifstream f("ciur.in");
ofstream g("ciur.out");
#endif

const int mxN = 2e6+5;

int n;
bool b[mxN];

int ciur(int n) {
	int ans = 0;
	for (int i = 2; i <= n; i++)
		if (!b[i]) {
			ans++;
			for (int j = i*2; j <= n; j += i)
				b[j] = 1;
		}
	return ans;
}

int main() {
	f >> n;
	g << ciur(n);
	return 0;
}

