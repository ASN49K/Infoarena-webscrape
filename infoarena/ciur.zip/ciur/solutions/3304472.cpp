#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

fstream fin("ciur.in");
ofstream fout("ciur.out");

vector<int> ciur;

int main() {
  int n, cnt = 0;

  fin >> n;
  ciur.resize(n + 1, 1);

  for (int i = 2; i <= n; i++) {
    if (ciur[i]) {
      ++cnt;
      for (int j = i * i; j <= n; j += i)
        ciur[j] = 0;
    }
  }

  fout << cnt << '\n';
}
