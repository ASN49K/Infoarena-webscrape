#include <fstream>

using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int n,i,j,nr;
bool ciur[2000004];
int main()
{
    cin>>n;
    ciur[1]=1;
    ciur[0]=1;
    for(i=2; i*i<=n; i++)
        if(ciur[i]==0)
        {
            nr++;
            for(j=i+i;j<=n;j=j+i)
                ciur[j]=1;

            }
   cout<<nr;

    return 0;
}
