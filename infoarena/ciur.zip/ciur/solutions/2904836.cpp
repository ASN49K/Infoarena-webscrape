#include <cstdio>
#include <vector>
#include <bitset>

using namespace std;
FILE *fin, *fout;

#define NMAX 2000000

bitset<NMAX + 5> v;
int cnt;

int main()
{
    fin = fopen("ciur.in", "r");
    fout = fopen("ciur.out", "w");

    int n;
    fscanf(fin, "%d", &n);


    //fprintf(fout , "%lld" , v.capacity());

    v.flip(0);
    v.set(1 , 1);

    int i , j;
    for(i = 4; i <= NMAX; i += 2)
        v.set(i , 1);

    for(i = 3; i * i <= NMAX; i += 2)
        if(v[i] == 0)
            for(j = 2 * i; j <= NMAX; j += i)
                v.set(j , 1);

    for(i = 1; i <= n; i++)
        if(v[i] == 0)
        cnt++;

    /*fprintf(fout , "\n");
    for(i = 1; i <= 50; i++)
        if(v[i] == 0)
        fprintf(fout , "%d " , i);

    fprintf(fout , "\n");*/
    fprintf(fout , "%d" , cnt);

    //fprintf(fout , " %lld" , v.capacity());*/
    fclose(fin);
    fclose(fout);
    return 0;
}
