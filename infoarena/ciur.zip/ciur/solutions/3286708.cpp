#include<fstream>

using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int v[2000001],elem[2000001],N;
void eratostene(){
    for(int i=2;i<=N;i++){
        if(v[i]==0)
            elem[i]=elem[i-1]+1;
        else
            elem[i]=elem[i-1];
        for(int j=2*i;j<=N && !v[i];j+=i){
            v[j]=1;
        }
    }
}
int main()
{
    cin>>N;
    eratostene();
    cout<<elem[N];
    return 0;
}
