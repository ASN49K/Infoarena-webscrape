#include <iostream>
#include <fstream>
using namespace std;
int main(){
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    unsigned int N,x,contor=0;
    bool ciur[2000005];
    fin>>N;
    ciur[0]=ciur[1]=1;
    for(int i=2;i<=N;i++){
        ciur[i]=0;
    }
    for(int i=2;i*i<=N;i++){
        if(ciur[i]==0){
            for(int j=i*i;j<=N;j+=i){
                ciur[j]=1;
            }
        }
    }
    for(int i=0;i<=N;++i){
        if(ciur[i]==0){
            contor++;
        }
    }
    fout<<contor;
    fin.close();
    fout.close();
    return 0;
}
