#include <iostream>
#include<fstream>

using namespace std;

ifstream f("ciur.in");
ofstream fout("ciur.out");

bool v[2000001];

int nr_prime(int n)
{
    for(int i = 2; i <= n; ++i){

        if(v[i] == 0)
            for(int j = 2*i; j <= n; j+=i){

                if(j%i == 0)
                    v[j] = 1;
            }
    }
    unsigned c = 0;
    for(int i = 2; i <= n; ++i)
            if(v[i] == 0)
                c++;
    return c;
}
int main()
{
    int n;
    f >> n;
    fout << nr_prime(n);
    return 0;
}
