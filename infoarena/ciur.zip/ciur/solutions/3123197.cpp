//#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

const int N = 2e6 +5;
vector <int> erat;

int main()
{
    int cnt = 0;
    int n;
    cin >> n;
    erat.resize(n);
    for(int i = 2; i * i <= n; i++)
    {
        if(erat[i])
        {
            continue;
        }
        for(int j = 2 * i; j <= n; j += i)
        {
            erat[j] = 1;
        }
    }
    for(int i = 1; i <= erat.size(); i++)
    {
        if(erat[i] == true)
        {
            cnt++;
        }
    }
    cout << cnt - 1;
    return 0;
}