#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int NMAX = 2e6;
bool not_prime[NMAX+5];

int main()
{
    ios_base :: sync_with_stdio(false);
    fin.tie(nullptr), fout.tie(nullptr);

    int n, cnt = 0;
    fin>>n;
    not_prime[0] = not_prime[1] = true;

    for (int i = 2; i*i <= n; i++)
        if (!not_prime[i])
            for (int j = i*i; j <= n; j += i)
                not_prime[j] = true;

    for (int i = 1; i <= n; i++)
        if (!not_prime[i]) cnt++;

    fout<<cnt;
    return 0;
}