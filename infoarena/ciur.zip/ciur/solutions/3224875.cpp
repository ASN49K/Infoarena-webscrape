#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int ciur[2000005];

int main()
{
    int n, cnt=0;
    fin >> n;
    ciur[0]=ciur[1]=1;
    for(int i=2; i*i<=n; i++) {
        if(ciur[i]==0) {
            for(int j=2; i*j<=n; j++) {
                ciur[i*j]=1;
            }
        }
    }
    for(int i=2; i<=n; i++) {
        if(ciur[i]==0) {
            cnt++;
        }
    }
    fout << cnt;
    return 0;
}
