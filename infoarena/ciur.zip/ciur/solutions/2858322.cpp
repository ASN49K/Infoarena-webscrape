#include <fstream>
using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");
bool v[2000001];
int main()
{
    int n, p=0, i, j;
    in>>n;
    for(i=2; i*i<=n; i++)
        if(v[i]==0)
            for(j=i; j*i<=n; j++)
                v[i*j]=1;
    for(i=2; i<=n; i++)
        if(v[i]==0)
            p++;
    out<<p;
    return 0;
}
