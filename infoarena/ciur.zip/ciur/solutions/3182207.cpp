#include <fstream>
#include <bitset>

using namespace std;

bitset<10000001>v;

ifstream cin("ciur.in");
ofstream cout("ciur.out");
int main()

{
   int p=10000001, i, j, n,m=0;
   v[0]=1; v[1]=1;
   for(i=2;i<=p/2;++i)
if(v[i]==0)
{
 for(j=i+i;j<=p;j+=i)
  v[j]=1;
}
   cin >> n;
   for (i=1; i<=n; ++i)
       { if (v[i]==0)
          {
            m++;
          }
       }
       cout<<m;
   return 0;

}
