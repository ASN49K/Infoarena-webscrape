#include <bits/stdc++.h>
using namespace std;
 
 
bool ciur[2000000];
int main(void){
    ofstream cout("ciur.out");
    ifstream cin("ciur.in");
    int n,cnt = 0;
    cin >> n;
    for(int i = 2;i<=n;i++){
        if(ciur[i] == 0){
            cnt++;
            for(int j = 1;j*i<=n;j++){
                ciur[i*j] = 1;
            } 
        }
    }
    cout << cnt << endl;
}