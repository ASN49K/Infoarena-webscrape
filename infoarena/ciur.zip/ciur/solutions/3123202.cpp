//#include <iostream>
#include <fstream>
#include <bitset>
using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

const int N = 2e6 +5;
bitset <N> erat;

int main()
{
    erat[1] = 1;
    int n;
    cin >> n;
    for(int i = 2; i * i <= n; i++)
    {
        if(erat[i])
        {
            continue;
        }
        for(int j = 2 * i; j <= n; j += i)
        {
            erat[j] = 1;
        }
    }
    cout << n - erat.count();
    return 0;
}