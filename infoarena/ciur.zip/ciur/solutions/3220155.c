#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *q,*w;
    int i,n,j,cnt=0;
    char v[2000001];
    q=fopen ("ciur.in","r");
    w=fopen ("ciur.out","w");
    fscanf (q,"%d",&n);
    for (i=2;i<=n;i++){
        v[i]=0;
    }
    for (i=3;i<=n;i=i+2){
        for (j=i;j*i<=n;j=j+2){
            v[j*i]=1;
        }
    }
    for (i=3;i<=n;i=i+2){
        if (v[i]==0){
            cnt++;
        }
    }
    fprintf (w,"%d",cnt+1);
    return 0;
}
