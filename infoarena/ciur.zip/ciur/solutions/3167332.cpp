/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool v[2000002];
int cnt,n;
int main()
{
    fin>>n;
    v[0]=1;
    v[1]=1;
    for(int i=2;i<=n;i++)
    {
        if(v[i]==0)
        {
            cnt++;
            for(int j=2;j<=n/i;j++)
            {
                v[i*j]=1;
            }
        }
    }
    fout<<cnt;
    fin.close();
    fout.close();
    return 0;
}
