#include <iostream>
#include <fstream>
#include <bitset>

using namespace std;

bitset<2000001> ciur;

void Creeaza_Ciur(int n)
{
    ciur[0] = ciur[1] = 1;
    for (int i = 4; i <= n; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i <= n; i += 2)
        if (ciur[i] == 0)
            for (int j = i * i; j <= n; j += 2 * i)
                ciur[j] = 1;
}

int main() {
    ifstream fin ("ciur.in");
    ofstream fout ("ciur.out");
    int n, cnt = 1;
    fin >> n;
    Creeaza_Ciur(n);
    for (int i = 3; i <= n; i += 2)
        if (ciur[i] == 0)
            cnt++;
    fout << cnt;
    return 0;
}
