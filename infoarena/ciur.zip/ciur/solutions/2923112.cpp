#include <fstream>

using namespace std;
bool A[2000005];

int main()
{
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");
    int n;
    cin>>n;
    A[0] = 1;
    A[1] = 1;
    for (int i = 2; i * i <= n; i++)
    {
        if(A[i] == 0)
        {
            for (int j = 2; j <= n / i; j++)
                A[i*j] = 1;
        }
    }
    int cnt = 0;
    for (int i = 0; i < n; i++)
    {
        if (A[i] == 0)
            cnt++;
    }
    cout<<cnt;
    cin.close();
    cout.close();
    return 0;
}