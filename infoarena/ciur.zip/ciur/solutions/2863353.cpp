#include <bits/stdc++.h>
using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

#define NMAX 2000005
int N, c[NMAX];

int main()
{
    f >> N;
    c[0] = c[1] = 1;
    int k=0;
    for(int i=2;i<=N;++i)
    {
        if(c[i] == 0)
        {
            ++k;
            for(int j=2;i*j<=N;++j)
            {
                c[i*j] = 1;
            }
        }
    }
    g << k;
}
