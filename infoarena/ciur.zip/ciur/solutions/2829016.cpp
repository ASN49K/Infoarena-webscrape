#include <iostream>
#include <fstream>
using namespace std;
bool ciur[2000000];
int main()
{
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    long long n,cnt=0;
    fin>>n;
    int ciur[n+1];
    ciur[0]=ciur[1]=1;
    for(int i=2;i<=n;i++)
    {
        if(ciur[i]!=1)
        {
            ciur[i]=0; cnt++;
            for(int j=2;j*i<=n;j++)
            ciur[j*i]=1;
        }
    }
    fout<<cnt;
    return 0;
}
