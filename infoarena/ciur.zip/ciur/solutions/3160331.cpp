#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000003> ciur;

int main() {

    int n;
    fin >> n;

    int res = 0;
    for (int i = 2; i <= n; i++) {
        if (!ciur[i]) {
            res++;
            for (int j = i * i; j <= n; j += i)
                ciur[j] = true;
        }
    }

    fout << res;

    return 0;
}
