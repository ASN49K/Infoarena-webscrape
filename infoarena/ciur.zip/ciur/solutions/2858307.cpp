#include <iostream>
#include <fstream>
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
bool v[2000001];
int main()
{
    int i=0,cnt=0,n;
    in>>n;
    for(i=2;i*i<=n;i++)
    {
        for(int j=2;j*i<=n;j++)
        {
            v[i*j]=1;
        }
    }
    for(i=2;i<=n;i++)
    {
        if(v[i]==0)
            cnt++;
    }
    out<<cnt;
    return 0;
}
