#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int countPrimes(int n) {
    bool *isPrime = new bool[n + 1];
    fill(isPrime, isPrime + n + 1, true);
    for (int i = 2; i * i <= n; ++i) {
        if (isPrime[i]) {
            for (int j = i * i; j <= n; j += i) {
                isPrime[j] = false;
            }
        }
    }
    int count = 0;
    for (int i = 2; i <= n; ++i) {
        if (isPrime[i]) {
            ++count;
        }
    }
    delete[] isPrime;
    return count;
}

int main() {
    int n;
    fin >> n;
    fout << countPrimes(n);
    return 0;
}
