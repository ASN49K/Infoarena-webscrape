#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int ciur[2000500];
int main()
{   int n;
    fin>>n;
    ciur[1]=1;
    for(int div=2; div*div<=n; div++)
        if(ciur[div]==0){
            for(int i=2; i*div<=n; i++)
                ciur[i*div]=1;
        }

    int cnt=0;
    for(int i=1; i<=n; i++)
        if(ciur[i]==0)
            cnt++;
    fout<<cnt;

    return 0;
}
