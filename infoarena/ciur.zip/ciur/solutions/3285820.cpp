#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n, x, y, r, cnt=0;
bool ciur[2000001];
int main()
{
    fin>>n;
    for(int i=2 ; i<=n ; i++)
        if(!ciur[i])
            for(int j=2 ; j*i<=n ; j++)
                ciur[j*i]=1;
    for(int i=2 ; i<=n ; i++)
    {
      if(ciur[i]==0)
            cnt++;
    }
    fout<<cnt;
    return 0;
}
