#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int nmax = 1e6;

bool v[2*nmax+5];

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    int n; fin >> n;
    v[0] = v[1] = true;
    int nr = 0;
    for(int i = 1; i <= n; i++) {
        if(!v[i]) {
            nr++;
            for(int j = 2; j * i <= n; j++) {
                v[i * j] = true;
            }
        }
    }
    fout << nr;
    return 0;
}