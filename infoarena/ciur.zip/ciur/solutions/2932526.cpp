#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("ciur.in");
ofstream fout("ciur.out");

int a[2000000];

int main() {
    int n;
    fin >> n;
    for (int i = 2; i * i <= n; ++i) {
        int ok = 0;
        if (i % 2 == 0 && i != 2 || i % 3 == 0 && i != 3) {
            ++ok;
        }
        if (ok == 0) {
            for (int j = i; j * i <= n; ++j) {
                a[i * j] = 1;
            }
        }
    }
    int counter = 0;
    for (int i = 2; i <= n; ++i) {
        if (a[i] == 0) {
            ++counter;
        }
    }
    fout << counter;
    return 0;
}
