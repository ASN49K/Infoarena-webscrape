#include <iostream>
#include <fstream>

using namespace std;

#define N_MAX 2000000

int main()
{
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");

    int nr, i, j, cnt = 0;
    fin >> nr;

    char a[2000000]={0};

    for(i = 2; i <= nr; i++)
    {
        if(a[i] == 0)
        {
            j = 2;
            while(i*j <= nr)
            {
                a[i*j] = 1;
                j++;
            }
        }
        else
        {
            continue;
        }

    }

    for(i = 2; i <= nr; i++)
    {
        if(a[i] == 0)
        {
            cnt++;
        }
    }

    fout << cnt;
}
