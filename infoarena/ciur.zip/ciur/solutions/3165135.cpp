#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int ciur[2000009];
int main(){
    int nr, rasp=0;
    fin>>nr;
    for(int i=2;i*i<=nr;i++){
        for(int m=2*i; m<=nr; m+=i){
            ciur[m]=1;
        }
    }
    for(int i=2;i<=nr;i++){
        if(ciur[i]==0)
            rasp++;
        fout<<ciur[i]<<' ';
    }
    fout<<'\n'<<rasp;
    return 0;
}
