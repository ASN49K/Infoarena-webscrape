#include <fstream>
#define DN 2000024
using namespace std;

int n, cnt;
char prim[DN];

int main()
{
    ifstream f("ciur.in");
    ofstream g("ciur.out");
    f>>n;
    for(int i=2;i<=n;++i)
        prim[i]=1;
    for(int i=2;i<=n;++i) {
        if(prim[i]) {
            ++cnt;
        for(int j=i+i;j<=n;j+=i)
            prim[j]=0;
        }
    }
    g<<cnt;
    return 0;
}
