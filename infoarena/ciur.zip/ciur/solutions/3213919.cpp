#include <fstream>
using namespace std;
bool isprime[2000001];
int main()
{
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    int n,c=0;
    fin>>n;
    for(int j=0;j<=n;++j){
        isprime[j]=1;
    }
    isprime[0]=0;
    isprime[1]=0;
    for(int i=2;i<=n;++i){
        for(int j=2*i;j<=n;j+=i){
            isprime[j]=0;
        }
    }

    for(int j=2;j<=n;++j){
        if(isprime[j]==1){
            c++;
        }
    }
    fout<<c;
    return 0;
}
