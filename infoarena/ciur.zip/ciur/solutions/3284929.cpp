#include<bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n , cnt = 0 ;
bool Ciur[2000001];

int main()
{
    fin >> n;
    Ciur[1] = 1;
    for(int i = 2 ; i <= n ; i++)
        if(Ciur[i] == 0)
            for(int j = 2 ; i * j <= n ; j++)
                Ciur[j * i] = 1;

    for(int i = 1 ; i <= n ; i++)
        if(Ciur[i] == 0)
            cnt++;


    fout << cnt;
    return 0;
}
