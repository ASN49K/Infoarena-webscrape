#include <iostream>
#include <fstream>
#define N_MAX 2000005
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
bool v[N_MAX];
int nr = 1, n;
int main()
{
    in >> n;
    for (int i = 3; i * i <= n; i += 2) {
        if (!v[i]) {
            for (int j = i * i; j <= n; j += i) {
                v[j] = true;
            }
        }
    }
    for (int i = 3; i <= n; i += 2) {
        if(!v[i])
        nr++;
    }
    out << nr;
    return 0;
}