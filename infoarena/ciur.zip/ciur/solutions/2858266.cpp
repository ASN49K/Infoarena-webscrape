#include <iostream>
#include <fstream>

using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");

long long n, prim=0, ciur[2000001]={0}, i, j, cif;

int main()
{
    in>>n;
    for(i=2; i<=n; i++)
    {
        if(ciur[i]==0) prim++;
        j=i*i;
        cif=i+1;
        while(j<=n)
        {
            ciur[j]=1;
            j=i*cif;
            cif++;
        }
    }
    out<<prim;
    return 0;
}
