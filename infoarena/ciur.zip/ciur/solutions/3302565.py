class Solution:
    def __init__(self, N):
        self.N = N
        self.v = [1 for _ in range(N+1)]
        self.__counter = 0

    def eratosthenes(self):
        self.v[0] = self.v[1] = 0
        for x in range(2, int(self.N**0.5)+1):
           if self.v[x] == 1:
                for j in range(x*x, self.N + 1, x):
                    self.v[j] = 0
        for x in range(2, self.N+1):
            if self.v[x] == 1:
                self.__counter+=1
    
    @property
    def counter(self):
        return self.__counter
    

with open("ciur.in", "r") as f:
    number = int(f.readline())
    s = Solution(number)
    s.eratosthenes()
    print(s.counter)