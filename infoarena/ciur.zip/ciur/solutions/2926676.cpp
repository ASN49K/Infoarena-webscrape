#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");
int v[2000001];

int main() {
    int n;
    fin >> n;
    for (int index = 2; index * index <= n; ++index) {
        int ok = 0;
        if (index % 2 == 0 && index != 2 || index % 3 == 0 && index != 3) {
            ++ok;
        }
        if (ok == 0) {
            for (int i = index; i * index <= n; ++i) {
                v[i * index] = 1;
            }
        }

    }
    int counter = 0;
    for (int index = 2; index <= n; ++index) {
        if (v[index] == 0) {
            ++counter;
        }
    }
    fout << counter;
}
