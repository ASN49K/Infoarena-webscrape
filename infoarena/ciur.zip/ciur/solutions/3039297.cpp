#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000010> vis(false);
int main()
{
  int n, res = 1;
  fin >> n;

    int i = 3;
  for (i; i * i <= n; i += 2)
    if (!vis[i])
    {
      vis[i] = true;
      res++;
      for (int j = i * 2; j <= n; j += i)
        vis[j] = true;
    }

  for (i; i <= n; i += 2)
    if (!vis[i])
      res++;

  fout << res;
  return 0;
}