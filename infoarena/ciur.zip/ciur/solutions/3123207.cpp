#include <iostream>
#include <fstream>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
int erath[2000005];
int main()
{
    int n;
    f>>n;
    for(int i=1;i<=n;i++)
    {
        erath[i]=i;
    }
    for(int div=2;div*div<=n;div++)
    {
        if(erath[div]==true)
        {
            continue;
        }

        for(int mul=div+2;mul<=n;mul+=div)
        {
            erath[mul]=1;
        }
    }

    int cnt=0;
    for(int i=2;i<=n;i++)
    {
        if(erath[i]!=1)
        {
            cnt++;
        }
    }

    g<<cnt;
    return 0;
}

