#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("ciur.in");
ofstream fout ("ciur.out");

const int MAX_N = 2e6;
int n, sol;

bitset <MAX_N + 5> freq;
void mark(int step){
    for(int i=step*step; i<=MAX_N; i+=step)
        freq[i] = true;
}

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr), fout.tie(nullptr);

    freq[0] = freq[1] = true;
    mark(2), mark(3);
    for(int i=5; i<=MAX_N/i; i+=6){
        if(!freq[ i ]) mark( i );
        if(!freq[i+2]) mark(i+2);
    }

    fin>>n;
    sol = 0;
    for(int i=1; i<=n; i++)
        sol += (!freq[i]);
    fout<<sol;
    return 0;
}
