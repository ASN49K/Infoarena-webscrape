#include <fstream>
using namespace std;
using pii = pair<int,int>;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
const int nmax = 2e6 + 1;
bool sieve[nmax];
int n;
signed main()
{
    cin >> n;
    int cnt = 0;
    for(int i = 2 ; i <= n ; ++i)
    {
        if(!sieve[i])
        {
            cnt++;
            for(int j = i+i ; j <= n ; j += i)
            {
                sieve[j] = 1;
            }
        }
    }
    cout << cnt << '\n';
    return 0;
}
