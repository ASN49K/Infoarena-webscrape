#include <fstream>
#include <deque>
#define long long LL
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");

int main(){
	deque<LL> sieve = {2};
	int n,i,j;
	for(f>>n,i=3;i<=n;i+=2) sieve.push_back(i);
	f.close();
	for(i=1;i<sieve.size()-1;++i){
		for(j=i;j<sieve.size();++j) sieve.erase(sieve[i]*sieve[j]);
	}
	g<<sieve.size()<<'\n';
	g.close();
}