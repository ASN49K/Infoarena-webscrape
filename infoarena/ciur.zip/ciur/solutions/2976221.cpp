#include<bits/stdc++.h>

using namespace std;

//ifstream f("file.in");
ifstream f("ciur.in");
ofstream g("ciur.out");
int n, ciur[2000005], cnt;

int main(){

    f>>n;

    for(int i=2; i<=n; i++)
        ciur[i] = 1;
    for(int i=2; i<=n; i++){
        if(ciur[i]) {
            cnt++;
            for(int j=i+i; j<=n; j+=i)
                ciur[j] = 0;
        }
    }

    g<<cnt;

    return 0;

}