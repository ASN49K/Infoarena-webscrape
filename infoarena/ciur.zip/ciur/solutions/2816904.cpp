#include<stdio.h>

int i, j, nr, sol[1005], n;
char a[2000005];
inline int min(int a, int b){
	if (a < b)
		return a;
	return b;
}
int main()
{
	freopen("ciur.in", "rt", stdin);
	freopen("ciur.out", "wt", stdout);

	scanf("%d", &n);

	for (i = 2; i*i <= n; i ++)
		if (!a[i])
			for (j = 2*i; j <= n; j += i)
				a[j] = 1;

	for (i = n; i > 1; i --)
		if (!a[i])
			nr ++;

	printf("%d\n", nr);

	return 0;
}
