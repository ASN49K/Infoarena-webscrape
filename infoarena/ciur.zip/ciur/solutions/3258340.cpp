#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

const int maxs = 2e6 + 1;

bool ciur[maxs];

void ciuru (){
    ciur[0] = 1;
    ciur[1] = 1;
    for (int i = 2; i <= maxs; i++){
        if (ciur[i] == 1){
            continue;
        }
        if (ciur[i] == 0){
            for (int k = 2 * i; k <= maxs; k += i){
                ciur[k] = 1;
            }
        }
    }
}

int main ()
{
    ciuru();
    int n, cnt = 0;
    fin >> n;
    for (int i = 1; i <= n; i++){
        if (ciur[i] == 1){
            cnt++;
        }
    }
    fout << cnt;
}
