#include <bits/stdc++.h>
#define DIM 2000010
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

char prim[DIM];
int n, cnt;

int main() {
    fin >> n;
    for(int i = 2; i <=n; i++) {
        prim[i] = 1;
    }

    for(int i = 2; i <= n; i++) {
        if(prim[i] == 1) {
            ++cnt;
            for(int j = i + i; j <= n; j += i) {
                prim[j] = 0;
            }
        }
    }

    fout << cnt;
}
