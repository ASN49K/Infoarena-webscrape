#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <time.h>
 
#pragma GCC optimize("Ofast")
 
//#define is_set(x)  (~a[x>>3] && (a[x>>3] & r[x & 0x7]))
//#define is_set(x)  (a[x>>3] & r[x & 0x7])
#define is_set(x)  ( a[x>>3] & (1 << (x & 0x7)) )
#define set_bit(x) ( a[x>>3] |= (1 << (x & 0x7)) )
 
char r[8] = {0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80};
int i, j, N, nr = 0, square_i, double_i;
char a[250001];

int main()
{
    //struct timespec start, stop;
    
    //FILE *in=fopen("ciur.in","r");
    //FILE *out=fopen("ciur.out","w"); 
	freopen( "ciur.in", "r", stdin );
	freopen( "ciur.out", "w", stdout );  
    scanf("%d",&N);
 
    //clock_gettime( CLOCK_REALTIME, &start);
    for (i = 3; (square_i = i*i) <= N; i += 2) {
        if (!is_set(i)) {
        	set_bit(sq);
            nr++;
            for (j = sq + (double_i = (i<<1)); j <= N; j += double_i) {
                if (!is_set(j)) {
                	set_bit(j);
                	nr++;
				}
            }
        }                                    
    }
    /*clock_gettime( CLOCK_REALTIME, &stop);
    printf( "%d seconds %d nanoseconds\n", stop.tv_sec - start.tv_sec, stop.tv_nsec - start.tv_nsec);
    getchar();*/
 
    printf("%d\n", (N+1)/2 - nr);
    //fclose(in);
    //fclose(out);
    
    return 0;
}
