#include<bits/stdc++.h>
using namespace std;
ifstream F("ciur.in");
ofstream G("ciur.out");
bitset<2000001> b;
int i,j,n;
int main()
{
    for(F>>n,i=3;i*i<=n;i+=2)
        if(!b[i])
            for(j=i*i;j<=n;b[j]=1,j+=2*i);
    return G<<(n+1)/2-b.count(),0;
}
