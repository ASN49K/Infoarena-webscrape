#include <bits/stdc++.h>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
const int N = 2000001;
int n,sol;
bitset<N> p;
int main()
{
    f>>n;
    sol=1;
    int i;
    for(i=3; i*i<=n; i+=2)
        if(p[i]==0)
        {
            sol++;
            for(int j=i*i; j<=n; j+=i)
                p[j]=1;
        }
    for( ;i<=n;i+=2)
        if(p[i]==0)
            sol++;
    g<<sol<<'\n';
    return 0;
}
