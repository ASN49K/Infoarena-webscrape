#include <bits/stdc++.h>
using namespace std;

///aemi
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int N;
bitset<2000005> ciur;

void Ciur()
{
    ciur[1] = 1;
    for (int i = 4; i <= N; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i <= N; i += 2)
        if (ciur[i] == 0)
            for (int j = i * i; j <= N; j += 2 * i)
                ciur[i] = 1;
}

int main()
{
    fin >> N;
    Ciur();
    fout << N - ciur.count();
    return 0;
}
