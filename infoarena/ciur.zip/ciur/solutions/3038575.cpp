#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n, cnt=0;
bitset <2500010>ciur;

int main()
{
    fin>>n;
    for(int i=2; i*i<=n; i++) {
        if(ciur[i]==0) {
            cnt++;
            if(i*i<=n)
                for(int j=i*i; j<=n; j+=i) ciur[j]=1;
        }
    }
    for(int i=2; i<=n; i++)
        if(ciur[i]==0) cnt++;
    fout<<cnt;

    return 0;
}
