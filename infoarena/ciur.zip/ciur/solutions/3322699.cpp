#include <fstream>
#include <iostream>
#include <bitset>
#include <vector>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
#define cin fin
#define cout fout
const int NMAX=1000;
bitset<NMAX+1> v;
vector<int> prim;
void ciur(int n)
{
    int i, j;
    v[0]=v[1]=1;
    for (i=4; i<=n; i+=2)
        v[i]=1;
    for (i=3; i*i<=n; i+=2)
        if (v[i]==0)
        for (j=i*i; j<=n; j+=2*i)
        v[j]=1;
    prim.push_back(2);
    for (i=3; i<=n; i+=2)
        if (v[i]==0)
        prim.push_back(i);
}
bool verif(int n)
{
    if (n<=NMAX) return v[n]==0;
    for (int i=0; i<prim.size() && prim[i]*prim[i]<=n; i++)
        if (n%prim[i]==0)
        return 0;
    return 1;
}
int main()
{
    int n, x, cnt=0;
    ciur(NMAX);
    cin>>n;
    while (n--)
    {
        if (verif(n)) cnt++;
    }
    cout<<cnt;
    return 0;
}
