#include <bits/stdc++.h>

using namespace std;

pair<vector<int>, vector<int>> getLp(int n) {
	vector<int> lp(n + 1, 0), primes;
	for (int i = 2; i <= n; i++) {
		if (!lp[i]) {
			lp[i] = i;
			primes.push_back(i);
		}
		for (int j = 0; j < (int) primes.size() && primes[j] <= lp[i] && i * primes[j] <= n; j++) {
			lp[i * primes[j]] = primes[j];
		}
	}
	return {lp, primes};
}

int main() {
#ifdef INFOARENA
	freopen ("ciur.in", "r", stdin);
	freopen ("ciur.out", "w", stdout);
#endif

	int n;
	cin >> n;
	cout << (int) getLp(n).second.size() << "\n";
	return 0;
}