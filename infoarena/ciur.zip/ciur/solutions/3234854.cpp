#include <fstream>
using namespace std;
ifstream fin("eratostene.in");
ofstream fout("eratostene.out");
bool v[1000001];
int i,j,n,a[1000001],maxi=0,k=0;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>a[i];
        if(a[i]>maxi)
            maxi=a[i];
    }
    for(i=1;i<=maxi;i++)
        v[i]=0;
    v[1]=1;
    for(i=2;i*i<=maxi;i++)
        if(v[i]==0)
            for(j=i*i;j<=maxi;j=j+i)
                v[j]=1;
    for(i=1;i<=n;i++)
        if(v[a[i]]==0)
            k++;
    fout<<k;
    return 0;
}