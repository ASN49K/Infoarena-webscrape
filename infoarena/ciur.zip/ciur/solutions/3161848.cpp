#include <iostream>
int pr(int a, int b) {
    if (b==0) {return 1;}
    if (b%2==1) {return a*pr(a,b-1);}
    return pr(a,b/2)*pr(a,b/2);
}
int prim(int p, int c=2) {
    double fuzzybool = 0.5;
    for (int i=c; i<2*c;i++ )
    {
        if ( pr(i,p-1)%p==0 ) {fuzzybool+=0.1;} else {fuzzybool-=0.1;}
    }
    if (fuzzybool>=0.5) {return 1;} else {return 0;}
}
int main()
{
    int n;
    std::cin >> n;
    int c=1;
    for (int i=3;i<=n;i+=2)
    {
        if (prim(i)) {c++;}
    }
    std::cout << c;
    return 0;
}
