#include <bits/stdc++.h>
using namespace std;
 
#define N 2000001
 
ifstream f("ciur.in");
ofstream g("ciur.out");
 
int n, cnt;
bool v[N];

int main() {
    f >> n;
    int root = sqrt(n);
    // presupunem ca toate numerele sunt prime
    memset(v, 1, n);
 
    for (int i = 2; i <= root; cnt+=v[i], i++)
        // cum gasim un multiplu de k, il marcam neprim
        for (int k = i + i; k <= n; v[k] = 0, k+=i);
    // adunam celelalte numere prime
    for (int i = root + 1; i <= n; cnt += v[i], i++);

    g << cnt << "\n";
    return 0;
}