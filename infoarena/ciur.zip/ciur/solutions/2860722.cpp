#include <bits/stdc++.h>
#include <fstream>
#define MAX 2000005
#define pb push_back
using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

int n,v[MAX];

/*void cit(){
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>a[i][j];
}
*/
void ciur(){
    for(int i=2;i<=n;i++)
        v[i]=1;
    for(int i=2;i<=n;i++)
        for(int j=i+i;j<=n;j+=i)
            if(v[i])
                v[j]=0;

}
//void afis(){
//    for(int i=n;i>=1;i--)
//        g<<sol[i]<<' ';
//}

int main()
{
    f>>n;
    ciur();
    int k=0;
    for(int i=2;i<=n;i++)
        if(v[i])
            k++;
    g<<k;
    return 0;
}
