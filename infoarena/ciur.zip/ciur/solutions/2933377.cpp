#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main() {
    int n;
    fin >> n;
    long long a[n + 1];
    for (int i = 2; i <= n; ++i) {
        a[i] = 1;
    }
    for (int i = 2; i * i <= n; ++i) {
        int ok = 0;
        if (i % 2 == 0 && i != 2 || i % 3 == 0 && i != 3) {
            ++ok;
        }
        if (ok == 0) {
            for (int j = i; j * i <= n; ++j) {
                a[i * j] = 0;
            }
        }
    }
    int counter = 0;
    for (int i = 2; i <= n; ++i) {
        counter += a[i];
    }
    fout << counter;
    return 0;
}
