#include <bits/stdc++.h>
using namespace std;
#define l 2000005
ifstream in("ciur.in");
ofstream out("ciur.out");
char sieve[l];
int cnt, n;

void ciur(){
    sieve[0]=1;
    sieve[1]=1;
    for (int i=2; i*i<=n; ++i)
        if (sieve[i] == 0)
            for (int j=2; j<=n/i; ++j)
                sieve[i*j]=1;
}
void numara(){

    for (int i=1;i<=n;++i)
        if (sieve[i] == 0)
            cnt++;
}

int main()
{
    in>>n;
    ciur();
    numara();
    out<<cnt;
}