#include <iostream>
using namespace std;
//#define ll long long
bool ciur[2000005];

int main() {
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);

    int n; scanf("%d", &n);

    ciur[0] = ciur[1] = 1;
    int cnt = 0;
    for (int i = 2; i <= n; i++) {
        if (ciur[i] == 0) {
            ++cnt;
            for (int j = i + i; j <= n; j += i)
                ciur[j] = 1;
        }
    }

    printf("%d", cnt);
    return 0;
}