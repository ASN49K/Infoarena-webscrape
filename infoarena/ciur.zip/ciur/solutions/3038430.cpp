
#include <fstream>
#include <bitset>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
bitset<2000001> ciur;
int n;
int nr=0;
void eratostene()
{
    ciur[0]=1;
    ciur[1]=1;
    nr++;
    for(int i=3;i<=n;i=i+2)
        if(ciur[i]==0)
        {
           for(int j=i+i;j<=n;j=j+i)
             ciur[j]=1;
        nr++;
        }
}
int main()
{
    cin>>n;
    eratostene();
    cout<<nr;
    return 0;
}
