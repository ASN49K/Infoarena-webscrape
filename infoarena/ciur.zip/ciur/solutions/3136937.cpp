#include <bits/stdc++.h>
#define optim ios_base::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr)
#define ll long long
#define ull unsigned long long
#define ld long double
#define pb push_back
#define let auto
#define popcount __builtin_popcount
#define ctzll __builtin_ctzll
#define clzll __builtin_clzll

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int sze = 2'000'005;
bool ciur[sze + 1];
int n;
let main()->int
{
    fin >> n;
    int cnt = 0;
    for (int i = 2; i <= n; ++i)
    {
        if (!ciur[i])
        {
            cnt++;
            for(int j = i+i;j<=n;j+=i) ciur[j] = 1;
        }
    }
    fout<<cnt;
    return 0;
}