#include <fstream>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

const int NMAX = 2 * (1e6);
int ciur[NMAX + 5];

void Ciur()
{
    ciur[1] = 1;
    for(int i = 2; i * i <= NMAX; i++)
        for(int j = 2 * i; j <= NMAX; j += i)
            ciur[j] = 1;
}

int main()
{
    int n;
    fin >> n;

    Ciur();

    int cnt = 0;

    for(int i = 1; i <= n; i++)
        if(ciur[i] == 0)
        cnt++;

    fout << cnt;

    fin.close();
    fout.close();
    return 0;
}
