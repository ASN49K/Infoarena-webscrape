#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,cnt=0;
bool prim[2000001];
int main(){
    fin>>n;
    for(int i=2;i<=n;i++){
        if(prim[i]==0){
            cnt++;
            for(int j=2;j<=n/i;j++)
                prim[i*j]=1;
        }
    }
    fout<<cnt;
    return 0;
}
