#include <iostream>
int prim(int n) {
    for (int i=2;i*i<=n;i++)
    {
        if (n%i==0) {return 0;}
    }
    return 1;
}
int main()
{
    int n;
    std::cin >> n;
    int c=1;
    for (int i=3;i<=n;i+=2)
    {
        if (prim(i)) {c++;}
    }
    std::cout << c;
    return 0;
}
