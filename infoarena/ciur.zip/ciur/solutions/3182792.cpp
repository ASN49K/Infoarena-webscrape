#include <iostream>
#include <fstream>
using namespace std;

int main(){
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    int n;
    fin >> n;
    int term[1000] = {0};
    int nr_prime = 0;

    for (int i = 2; i <= n; i++){
        if (term[i] == 0){
            nr_prime++;
            for (int j = 2 * i; j <= n; j = j + i) {
                term[j] = 1;
            }
        }
    }
    fout << nr_prime;
}