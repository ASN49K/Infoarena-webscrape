use std::io::{BufWriter, Write};
use std::fs::{File,self};

fn main() -> std::io::Result<()>{
    let n = fs::read_to_string("ciur.in")?.parse::<usize>().unwrap();
    let mut writer = BufWriter::new(File::create("ciur.out")?);
    let mut freq : Vec <i32> = vec![0; n+1];
    freq[1] = 1;
    freq[0] = 1;
    for i in 2..n {
        if i*i > n {
            break;
        }
        if freq[i] == 1 {
            continue;
        }
        let mut j = i*i;
        while j <= n {
            freq[j] = 1;
            j += i;
        }
    }
    write!(writer,"{}",freq.iter().filter(|&&x| x == 0).count())?;
    Ok(())
}
