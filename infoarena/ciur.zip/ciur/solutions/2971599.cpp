#include<bits/stdc++.h>
using namespace std;
int main(){
 	freopen("ciur.in","r",stdin);
	freopen("ciur.out","w",stdout);
	int n;
	cin>>n;
	bool ciur[n]={};
	int rs=0;
	ciur[0]=ciur[1]=true;
	for(int i=2;i<=n;i++){
	 if(ciur[i]==false){
		rs++;
		for(int j=i*2;j<=n;j+=i)
		ciur[j]=true;
	}
}
cout<<rs;

	return 0;
}
