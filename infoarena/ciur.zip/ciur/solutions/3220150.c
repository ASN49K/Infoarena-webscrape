#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *a,*b;
    int v[200000],i,n,j,cnt=0;
    a=fopen("ciur.in","r");
    b=fopen("ciur.out","w");
    fscanf(a,"%d", &n);
    for(i=3;i<=n;i=i+2){
        for(j=i;j*i<=n;j=j+2){
            v[j*i]=1;
        }
    }
     for(i=3;i<=n;i=i+2){
        v[i]==0;
        cnt++;
    }
    fprintf(b,"%d",cnt);
  return 0;


}
