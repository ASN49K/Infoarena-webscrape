#include <fstream>

using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int n,i,j,nr;
bool ciur[2000004];
int main()
{
    cin>>n;
    ciur[1]=1;
    ciur[0]=1;
    for(i=2; i<=2000000; i++)
        if(ciur[i]==0)
        {
            if(i<=n)
                nr++;
            else
                break;
            for(j=i;j*i<=2000000;j++)
                ciur[i*j]=1;
            }
   cout<<nr;

    return 0;
}
