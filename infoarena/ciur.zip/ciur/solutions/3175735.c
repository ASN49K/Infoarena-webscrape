#include <stdio.h>
#include <stdbool.h>

#define MAXN 2000000

bool ciur[MAXN+1];
int sml[MAXN+1];
int prime = 0;

int main(){
  for(int i=2; i*i<=MAXN; i++){
    sml[i] = prime;
    if(!ciur[i]){
      prime++;
      for(int d=i*i; d<=MAXN; d+=i)
        ciur[d]=true;
    }
  }
  int n;
  FILE *fin, *fout;
  fin = fopen("ciur.in", "r");
  fscanf(fin, "%d", &n);
  fclose(fin);

  fout = fopen("ciur.out", "w");
  fprintf(fout, "%d\n", sml[n]);
  fclose(fout);
  return 0;
}
