#include <iostream>
int main()
{
    int n,c=0;
    bool C[2000002]={false};
    std::fill(std::begin(C), std::end(C), 0);
    std::cin >> n;
    for (int i=2;i<=n;i++)
    {
        if (C[i]==false) {
            c++;
            for (int j=1;j*i<=n;j++)
            {
                C[j*i]=true;
            }
        }
    }
    std::cout << c;
    return 0;
}
