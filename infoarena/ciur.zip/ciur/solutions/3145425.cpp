#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000005> fr;
int n, nr;

int main()
{
    int i, j;
    fin >> n;
    fr[0] = fr[1] = 1;
    for(i=2; i*i<=n; i++)
        if(fr[i] == 0)
            for(j=2; j*i<=n; j++)
                fr[j * i] = 1;
    for(i=1; i<=n; i++)
        if(fr[i] == 0) nr++;
    fout << nr;
    fin.close();
    fout.close();
    return 0;
}
