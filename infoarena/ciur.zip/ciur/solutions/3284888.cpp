#include <bits/stdc++.h>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int DIM = 2e6;
bitset <DIM + 3> ciur;

inline void prelucru() {
    ciur[0] = ciur[1] = 1;
    for(int i=2; i*i<=DIM; i++)
        if(!ciur[i])
            for(int j=i*i; j<=DIM; j+=i) ciur[j] = 1;
}

int main()
{
    prelucru();
    int n; fin >> n;
    int cnt = 0;
    for(int i=2; i<=n; i++) cnt += !ciur[i];
    fout << cnt;

    return 0;
}
