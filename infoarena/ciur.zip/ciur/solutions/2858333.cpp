#include <fstream>

using namespace std;
ifstream in ("ciur.in");
ofstream out ("ciur.out");
bool v[2000001];
int main()
{
    int n,i,ct=0;
    in>>n;
    for(i=2; i*i<=n; i++)
    {
        if(v[i]==0)
        {
            for(int j=i*2; j<=n; j=j+i)
                v[j]=1;
        }
    }
    for(i=2;i<=n;i++)
        if(v[i]==0)
    {
        ct++;
    }
         out<<ct;
    return 0;
}
