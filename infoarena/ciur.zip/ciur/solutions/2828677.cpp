#include <iostream>
#include <fstream>

using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

int main()
{
    int n, nr = 0;
    in >> n;
    in.close();
    const int Nmax = 2000000;
    bool ciur[Nmax+1];
    for(int i = 0; i <= n; i++)
    {
        ciur[i]=true;
    }
    ciur[0] = ciur[1] = false ;
    for(int i= 2; i * i <= n; i++)
    {
        if(ciur[i] == true)
        {
            for(int j = i * i; j <= n; j+= i)
            {
                ciur[j] = false;
            }
        }
    }
    for(int i = 1; i <= n; i++)
    {
        if(ciur[i]== true)
        {
            nr++;
        }
    }
    out << nr << "\n";
    out.close();

    return 0;
}
