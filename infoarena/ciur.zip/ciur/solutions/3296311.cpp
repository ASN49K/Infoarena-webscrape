#include <bits/stdc++.h>
#define pb push_back
//#define int long long
using namespace std;
const int N=2e6+5;
bool ciur[N];
signed main()
{
    ifstream cin("ciur.in");ofstream cout("ciur.out");
    int n;
    cin>>n;
    int cnt=0;
    for(int i=2;i<=n;++i)
    {
        if(ciur[i]) continue;
        ++cnt;
        for(int j=i*2;j<=n;j+=i) ciur[j]=1;
    }
    cout<<cnt;
}
