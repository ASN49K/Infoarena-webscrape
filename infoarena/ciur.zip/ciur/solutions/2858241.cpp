#include <iostream>

using namespace std;

bool v[2000001];
int main()
{
    int n,cont=0,i,j;
    cin>>n;
    for(i=2;i<=n;i++)
    {
        if(v[i]==0)
        {
            for(j=i+i;j<=n;j+=i)
            {
                v[j]=1;
            }
            cont++;
        }
    }
    cout<<cont;
    return 0;
}
