#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int erath[2000005];
int main()
{   int n;
    fin>>n;
    for(int i=2; i<=n; i++)
        erath[i]=i;

    for(int div=2; div*div<=n; div++){
        if(erath[div]==true){
            continue;
        }
        for(int nr=2+div; nr<=n; nr+=div){
            erath[nr]=1;
        }
    }

    int cnt=0;
    for(int i=2; i<=n; i++)
        if(erath[i]!=1)
            cnt++;
    fout<<cnt;

    return 0;
}
