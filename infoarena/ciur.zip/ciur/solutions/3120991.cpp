#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_LENGTH = 2000000;
int v[MAX_LENGTH + 1];

int main() {
    int n;
    fin >> n;
    int primeNumbersCnt = 0;
    for (int i = 2; i <= n; ++i) {
        if (v[i] == 0) {
            for (int divisor = 2; i * divisor <= n; ++divisor) {
                v[i * divisor] = 1;
            }
            ++primeNumbersCnt;
        }
    }
    fout << primeNumbersCnt;
    return 0;
}
