#include <iostream>

using namespace std;

int main()
{
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
    int n;
    cin>>n;
    bool ciur[n+1];
    int puse=2;///0 si 1
    for(auto &i:ciur)
        i=0;
    for(int i=2; i*i<=n; i++)
        if(ciur[i]==0)
            for(int j=i*i; j<=n; j+=i)
            {
                if(ciur[j]==0)
                    ++puse, ciur[j]=1;
            }
    cout<<n+1-puse;///incep de la 0
    return 0;
}
