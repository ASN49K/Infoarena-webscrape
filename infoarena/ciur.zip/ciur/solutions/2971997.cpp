#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

short N, ciur[2000001];


int main()
{
    fin >> N;

    ciur[1] = 1;
    // build la ciur
    for(int i = 2; i * i <= N; i++) {
        if(ciur[i] == 0) {
            int c = i, new_c = i;
            while(new_c <= N) {
                new_c += c;
                ciur[new_c] = 1;
            }
        }
    }

    int cnt = 0;
    for(int i = 1; i <= N; i++) {
        if(ciur[i] == 0) {
            cnt++;
        }
    }
    fout << cnt;

    return 0;
}
