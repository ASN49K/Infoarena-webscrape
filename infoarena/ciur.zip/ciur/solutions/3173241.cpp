#include <fstream>
using namespace std;
ifstream cin ("ciur.in");
ofstream cout ("ciur.out");
bool ciur[2000001];
int main()
{
    int n,ctr=0;
    cin>>n;
    for(int i=2;i<=n;i++)
    {
        if(ciur[i]==0)
        {
            ctr++;
            for(int j=i;j<=n;j+=i)
                    ciur[j]=1;
        }
    }
    cout<<ctr;
    return 0;
}
