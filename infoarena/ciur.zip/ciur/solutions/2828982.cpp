#include <iostream>
#include<fstream>
ifstream("ciur.in");
ofstream("ciur.out");

using namespace std;

int main()
{
    int x,ciur[1001],i,j;
    fin>>x;
   {
    for(i=1;i<=x;i++) ciur[i]=1;
    if(ciur[i]==0)
        for(j=1;j<=x;j++) ciur[j]=1;
        for(i=1;i<=x;i++)
            if(ciur[i]==0) ciur++;
    }


    fout<<"ciur";
    fout<<endl;
    return 0;
}
