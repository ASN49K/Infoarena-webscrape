#include <bits/stdc++.h>

using namespace std;
int n,nr=1;
ifstream f("ciur.in");
ofstream g("ciur.out");
bool v[2000005];
int main()
{f>>n;
int i,j;
    for (i = 1; ((i * i) << 1) + (i << 1) <= n; i++) {
      if (v[i] == 0) {
        for (j = ((i * i) << 1) + (i << 1); (j << 1) + 1 <= n; j += (i << 1) + 1) {
          v[j] = 1;
        }
      }
    }
    for (i=1; 2 * i + 1 <= n; ++i)
        if (v[i] == 0) nr++;
    g<<nr;
    return 0;
}
