#include<bits/stdc++.h>
#define nmax 2000005

using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");

int ciur[nmax];
int main()
{
    int n,cnt=0;//nr prime
    f>>n;
    ciur[0]=ciur[1]=1;
    for(int i=2;i<=n;i++)
    {
        if(ciur[i]==0) //nu i prim
            cnt++;
        for(int j=i*2;j<=n;j+=i)
            ciur[j]=1;//multipli lui i out
    }
    g<<cnt;
}
