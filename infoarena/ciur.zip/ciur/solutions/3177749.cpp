#include <bits/stdc++.h>


using namespace std;

ifstream fin("ciur.in");

ofstream fout("ciur.out");

char v[2000002];

int main()
{
    int n, x=0;
    fin >> n;
    for(int i=1; i<=n;i++) {
        v[i]=0; // toate sunt 0
    }
    v[0]=1;
    v[1]=1; // 1 1 0 0! 0 0 1 0 0 0 0 .....
    for(int i=2;i<=n;i++) { // ex v[3], i = 3
        if(v[i]==0) // adevarat
        {
            x++; //x = 2
            for(int j=2*i;j<=n;j+=i) { //j = 6, <= n. j+=i, j = 6 + 3 = 9
                v[j]=1; // v[6] = 1
            }
        }
    }
    fout << x;
    return 0;
}
