#include <bits/stdc++.h>

using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
char  ciur[5000001];
int main()
{
 int n,cnt=0;
 fin>>n;
  for (int i=2; i<=n; i++)
    ciur[i]=1;
 for (int i=2; i<=n; i++)
 {
     if (ciur[i])
     {
         cnt++;
         for (int j=i*i; j<=n; j+=i)
            ciur[j]=0;
     }
 }
fout<<cnt;
    return 0;
}
