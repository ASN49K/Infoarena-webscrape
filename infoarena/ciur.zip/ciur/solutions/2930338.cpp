#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n, nr = 0;
bool v[2000005];
int main()
{
    fin >> n;
    v[0]=1;
    v[1]=1;
    for(int i=2; i*i<=n; i++)
        if(v[i]==0)
        {
            for(int j=2; j<=n/i; j++)
                v[i*j] = 1;
        }
    for(int i=1;i<=n;i++)
        if(v[i]==0) nr ++;
    fout << nr;
}
