#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream gout("ciur.out");
bool w[2000001];
int main()
{
    int n,i,j,c;
    fin>>n;
    c=0;
    w[0]=1;
    w[1]=1;
    for(i=2;i*i<=n;++i)
    {
        if(w[i]==0)
        {
            for(j=2;j<=n/i;++j)
            {
                w[i*j]=1;
            }
        }
    }
    for(i=2;i<=n;++i)
    {
        if(w[i]==0)
        {
            c++;
        }
    }
    gout<<c;
}
