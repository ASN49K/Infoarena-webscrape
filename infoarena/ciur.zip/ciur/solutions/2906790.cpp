#include<iostream>
#include<fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int v[2000005];

int main()
{
    int n, cnt = 0;
    fin >> n;

    for(int i = 2; i <= n; ++i)
        v[i] = 1;

    for(int i = 2; i * i <= n; i++)
    {
        if(v[i])
        {
            cnt++;
            for(int j = i * i; j <= n; j += i)
                v[j] = 0;
        }
    }

    fout << cnt;

    return 0;
}