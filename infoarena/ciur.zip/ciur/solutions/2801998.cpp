#include <iostream>
#include <bitset>
#include <vector>
#include <fstream>


#define nmax 2000005
#define inf 2100000000

using namespace std;

ifstream f("ciur.in");
ofstream o("ciur.out");

bitset <nmax> is_prime;
vector < int > prime_nr;

long long nr_of_primes=0;
long long n;

void ciur ()
{
 for(long long i=2;i<=n;i++){
    if (is_prime[i]==0){
        for(long long j=i*i;j<=n;j+=i){
            is_prime[j]=1;
        }
        prime_nr.push_back(i);
        nr_of_primes++;
    }
 }
}

int main()
{
    f>>n;
    ciur();
    o<<nr_of_primes;




    return 0;
}
