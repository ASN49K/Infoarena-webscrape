#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x <<": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "ciur";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int n;
 vector<int> v(2000005);
int main(){

    fin >> n;
   
    for (int i = 4; i <= n; i += 2)
        v[i] = 1;
    for (int i = 3; i * i <= n; i += 2)
        if(!v[i])
            for (int j = i * i; j <= n; j += i + i)
                v[j] = 1;
    int nas = 0;
    for (int i = 2; i <= n; ++i)
        if(v[i] == 0)
            nas++;
    fout << nas << " ";
    return 0;
}