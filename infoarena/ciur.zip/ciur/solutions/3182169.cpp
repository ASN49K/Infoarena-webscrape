#include <bits/stdc++.h>

#include <fstream>

using namespace std;

const int N=1000001;
bitset <N> c;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int main()
{
    int n,nr=0;
    cin>>n;
    c[0]=1;
    c[1]=1;
    for (int i=4 ; i<=n ; i=i+2)
    {
       c[i]=1;
    }
    for (int i=3 ; i<=n ; i=i+2)
    {
        if (c[i]==0)
        {
            for (int j=2*i ; j<=n ; j=j+i)
            {
                c[j]=1;
            }
        }
    }
    for (int i=1 ; i<=n ; i++)
    {
        if (c[i]==0)
        {
            nr++;
        }
    }
    cout<<nr;
    return 0;
}
