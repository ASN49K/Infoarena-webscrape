#include<fstream>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");

bool v[2000002];
int k=0,val;

void ciur(int x)
{
    int i,j;
    for(i=2;i*i<=x;i++)
    {
        if(v[i]==0)
        {
            for(j=i*i;j<=x;j+=i)
                v[j]=1;
        }
    }
    for(i=2;i<=x;i++)
    {
        if(v[i]==0)
            k++;
    }
}

int main()
{
    int x;
    f>>x;
    ciur(x);
    g<<k;
    return 0;
}
