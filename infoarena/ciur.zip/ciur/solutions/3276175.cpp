#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int NMAX = 2e6 + 5;
bitset<NMAX> ciur;

void build()
{
    ciur[0] = ciur[1] = 1;
    for(int i = 2; i < NMAX; i++)
    {
        if(ciur[i] == 0)
        {
            for(int j = 2; i * j < NMAX; j++)
                ciur[i * j] = 1;
        }
    }
}

signed main()
{
    int n;
    fin >> n;
    build();
    int cnt = 0;
    for(int i = 1; i <= n; i++)
        cnt += !ciur[i];
    fout << cnt;

    return 0;
}
