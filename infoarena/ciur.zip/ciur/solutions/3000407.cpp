#include <fstream>
#include <cstring>

using namespace std;

#define INFILE "ciur.in"
#define OUTFILE "ciur.out"
#define NRMAX 2000001

ifstream fin (INFILE);
ofstream fout (OUTFILE);

bool ciur[NRMAX];
int n;

void init(int numar){

    int cnt = numar - 1;

    for(int i = 2; i <= numar; ++i){
        ciur[i] = true;
    }

    ciur[0] = false, ciur[1] = false;

    for(int i = 2; i <= numar; ++i){
        for(int j = 2; i * j <= numar; ++j){
            if(ciur[i * j] == true){
                --cnt;
                // fout << i * j << " ";
            }
            ciur[i * j] = false;
        }
    }

    fout << '\n';

    fout << cnt << '\n';
}

void solve(){

    fin >> n;

    init(n);

}

int main(){
    solve();
    return 0;
}