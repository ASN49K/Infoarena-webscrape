#include <cstdio>
#include <vector>

using namespace std;
FILE *fin, *fout;

vector <int> v;

#define NMAX 2000000

int cnt;

int main()
{
    fin = fopen("ciur.in", "r");
    fout = fopen("ciur.out", "w");

    int n;
    fscanf(fin, "%d", &n);

    v.reserve(NMAX + 1);

    v[0] = v[1] = 1;
    int i , j;
    for(i = 4; i <= NMAX; i += 2)
        v[i] = 1;

    for(i = 3; i * i <= NMAX; i += i)
        if(v[i] == 0)
            for(j = i * i; j <= NMAX; j = j + 2 * i)
                v[j] = 1;

    for(i = 1; i <= n; i++)
        if(v[i] == 0)
        cnt++;

    fprintf(fout , "%d" , cnt);

    fclose(fin);
    fclose(fout);
    return 0;
}
