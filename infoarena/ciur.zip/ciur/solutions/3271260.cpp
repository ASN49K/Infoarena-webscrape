#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool composite[2000001] = {};

int main()
{
    int N;
    fin >> N;
    for(int i = 2; i <= N; i++){
        if(composite[i]){
            continue;
        }
        for(int mult = 2; i*mult <= N; mult++){
            composite[mult*i] = true;
        }
    }
    int db = 0;
    for(int i = 2; i <= N; i++){
        if(!composite[i]){
            db++;
        }
    }
    fout << db;
    return 0;
}
