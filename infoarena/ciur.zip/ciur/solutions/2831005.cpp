#include <iostream>
#include <fstream>
using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

bool e[2000001];

int main(){

    int n;
    f>>n;
    int cnt=0;
    e[0]=e[1]=1;
    for(int i=2;i*i<=n;++i)
        if(e[i]==0)
            for(int j=2;i*j<=n;++j)
                 e[i*j]=1;
    
    for(int i=1;i<=n;++i)
        if(e[i]==0)
            cnt++;
    
    g<<cnt;
}