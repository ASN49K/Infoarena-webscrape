#include <bits/stdc++.h>

using namespace std;

ifstream f ("ciur.in");
ofstream g ("ciur.out");

const int NMAX = 2000000;
int not_prim[NMAX + 5];

void eratostene(int n)
{
    not_prim[1] = 1;
    not_prim[0] = 1;
    int i, j;
    for(i = 2; i <= n; i = i + 2)
    {
        not_prim[i] = 1;
    }
    for(i = 3; i <= n; i = i + 2)
    {
        if(!not_prim[i])
        {
            for(j = 3*i; j <= n; j = j + 2*i)
                not_prim[j] = 1;
        }
    }
}

int main()
{
    int x, i;
    f >> x;
    int cnt = 1;
    eratostene(x);
    for(i = 3; i <= x; i = i + 2)
    {
        if(!not_prim[i])
            ++cnt;
    }
    g << cnt;
    return 0;
}
