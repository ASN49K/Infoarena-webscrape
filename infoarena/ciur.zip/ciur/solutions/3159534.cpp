#include <iostream>
#include <fstream>

using namespace std;
int t[2000001];

int main()
{
    int n, db=0;
    ifstream f("ciur.in");
    ofstream g("ciur.out");
    f>>n;
    for (int i=1; i<=n; i++)
    {
        t[i]=i;
    }
    for (int i=2; i<=n; i++)
    {
        if(t[i]!=0)
        {
            for (int j=2; j*i<=n; j++)
            {
                t[j*i]=0;
            }
            db++;
        }
    }
    g<<db;
    f.close();
    g.close();
    return 0;
}