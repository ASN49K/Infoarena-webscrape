#include <bits/stdc++.h>
using namespace std;
string np = "ciur";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

int n, rez;
bool ciur[10000003];

int main()
{
    f >> n;

    ciur[1] = ciur[0] = 1;
    for (int i = 2; i <= n / 2; i++)
        ciur[i * 2] = 1;
    for (int i = 3; i <= n; i++)
        if (!ciur[i])
            for (int j = 2; j <= n / i; j++)
                ciur[i * j] = 1;

    for (int i = 1; i <= n; i++)
        if (!ciur[i])
            rez++;
    g << rez;

    return 0;
}