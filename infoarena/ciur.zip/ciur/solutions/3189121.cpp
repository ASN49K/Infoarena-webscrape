#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("granita.in");
ofstream fout("granita.out");

int n,a[16000],b[16000],i,j,k=0;
int main() {
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i]>>b[i];
        for(int j=1;i<=n;j++)
        { i=j;
            while(i<n){
                if(a[j]<a[i] and b[i]<b[j]) k++;
                i++;
            }
            
        }
            fout<<k;
        return 0;
    }
