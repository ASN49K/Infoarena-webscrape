#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
const int NMAX = 2e6;
bool ciur[NMAX + 1];///vectorul va fi initializat cu 0-uri
void precalc()
{
    for (int i = 4; i <= NMAX; i += 2)
    {
        ciur[i] = 1;
    }
    for (int i = 3; i * i <= NMAX; i += 2)
    {
        if (ciur[i] == 0)
        {
            /// i = 11 -> 22, 33, 44, 55 ...
            for (int j = i * i; j <= NMAX; j += i)
            {
                ciur[j] = 1;///marchez pe j ca fiind numar compus
            }
        }
    }
}

int main()
{
    precalc();
    int N, s = 0;
    f >> N;
    for (int i = 2; i <= N; i++)
    {
        if (ciur[i] == 0)
            s++;
    }
    g << s;
    return 0;
}
