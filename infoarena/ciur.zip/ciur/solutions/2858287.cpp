#include <iostream>
#include <fstream>

using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");

int n, prim=0, i, j, cif;
bool ciur[2000002];

int main()
{
    in>>n;
    for(i=2; i<=n; i++)
    {
        if(ciur[i]==0)
        {
            prim++;
            /*j=i*i;
            cif=i+1;
            while(j<=n)
            {
                ciur[j]=1;
                j=i*cif;
                cif++;
            }*/
            for(j=i+i; j<=n; j=j+i)
                ciur[j]=1;
        }
    }
    out<<prim;
    return 0;
}
