#include <iostream>
#include <fstream>
#define int long long
using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

const int maxN = 2e6 + 5;

int prime[maxN];

signed main()
{
    int n; fin >> n;

    prime[0] = prime[1] = 1;
    for(int i = 2; i * i <= n; ++i)
        if(prime[i] == 0)
            for(int j = i * i; j <= n; j += i)
                prime[j] = 1;

    int cnt = 0;
    for(int i = 1; i <= n; ++i)
        if(prime[i] == 0)
            cnt++;

    fout << cnt;

    return 0;
}
