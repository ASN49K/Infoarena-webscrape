#include<iostream>
#include<fstream>
#define FIN "ciur.in"
#define fout "ciur.out"
using namespace std;
ifstream fin(FIN);
ofstream fout(FOUT);

int erastosnene(int n) {
	bool arr[n+1];
	int size = n - 1;
	
	for(int i=2; i<=n; i++)
		arr[i] = true;
	int i=2;
	
	while( i * i <= n ) {
		if( arr[i]==1 ) {
			int j = 2;
			while(i*j <= n) {
				if( arr[i*j] == 1 ) 
					size--;
				arr[i*j] = 0;
				j++;
			}
		}
		i++;
	}
	return size;
}
int main()
{
	int n;
	fin >> n;
	fout << erastosnene(n);
}