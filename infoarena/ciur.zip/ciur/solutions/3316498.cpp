#include <bits/stdc++.h>
using namespace std;

// !!!
string PREFIX = "ciur";


int main()
{
  ifstream cin(PREFIX + ".in");
  ofstream cout(PREFIX + ".out");

  int n;
  cin >> n;
  vector<bool>is_prime(n + 1, 1);
  vector<int>primes;
  int cnt = 0;

  auto mark = [&] (int x) {
    for (int p : primes) {
      for (int j = 1; j * p <= n/x; j++)
         is_prime[j * p * x] = 0;
    }
  };

  primes.push_back(2);
  mark(2);

  for (int i = 3; i <= n; i += 2) {
    if (is_prime[i]) {
      cnt++;
      primes.push_back(i);
      mark(i);
    }
  }

  cout << cnt << '\n';


}