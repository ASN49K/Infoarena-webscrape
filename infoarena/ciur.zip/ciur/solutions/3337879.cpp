#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout ("ciur.out");
int main()
{
    int n;
    fin>>n;
    int ciur[n]={0};
    ciur[0]=ciur[1]=1;
    for(int i=4;i<=n;i=i+2)
        ciur[i]=1;
    for(int i=3;i*i<=n;i+=2)
        if(ciur[i]==0)
    {for(int j=i*i;j<n;j=j+2*i)
    ciur[j]=1;

    }
    for(int i=0;i<n;i++)
    if(ciur[i]==0)
        fout<<i<<' ';
    return 0;
}
