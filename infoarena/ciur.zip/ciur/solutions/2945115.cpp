#include<iostream>
#include<fstream>
#include <stdlib.h> 
using namespace std;

long ciurul(long n)
{	long ciur[2000001];
	long count=0;
	for(long i = 2; i <= n; i++)
		ciur[i]==0;
	for(long i = 2; i <= n; i++) {
        if(ciur[i] == 0) { 
            for(int j = 2 * i; j <= n; j =j + i) {
                ciur[j] = 1;
            }
        }
    }
    for(long i = 2; i <= n; i++)
    	if(ciur[i]==0)
    		count++;
    return count;
}

int main()
{	long n;
		ifstream fin("ciur.in");
	ofstream fout("ciur.out");
	fin>>n;
	fout<<ciurul(n);
}
