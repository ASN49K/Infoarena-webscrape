#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream  fout("ciur.out");
bool v[2000001];
int main()
{
    long long unsigned n, cnt = 0;

    fin >> n;

    if(n == 2)
        fout << 1;

    for(int i = 4 ; i <= n; i=i+2)
    {
        v[i] = true;
    }

    for(int i = 3; i <= n; i=i + 2)
    {
        if(v[i] == false)
            for(int j = i * i; j <= n; j = j + 2 * i)
                v[j] = true;
    }

    for(int i = 2; i <= n; i++)
    {
        if(v[i] == false)
        {
            cnt++;
        }

    }

    fout << cnt;



}
