//#include <iostream>
#include <vector>
#include <string.h>
#include <fstream>

using namespace std;

vector <int> primes;

ifstream cin ("ciur.in");
ofstream cout("ciur.out");

void check_primes(int n){
    vector <bool> pr(2000000);
    for(int i = 2; i < n; ++i){
        if(pr[i] == 0){
            for(int j = i+i; j <= n; j += i)
                pr[j] = 1;
            primes.push_back(i);
        }
    }
}

int main(){
    int n;
    cin >> n;
    check_primes(n);
    cout << primes.size();
    return 0;
}