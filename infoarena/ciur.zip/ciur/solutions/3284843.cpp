#include <iostream>
#include <fstream>
using namespace std;
ifstream fcin("ciur.in");
ofstream fcout("ciur.out");
int n, i, j, nr;
bool a[2000001];
int main()
{
    fcin>>n;
    a[0]=a[1]=1;
    for(i=2; i<=n; i++)
    {
        if(a[i]==0)
        {
            nr++;
            for(j=2; j*i<=n; j++)
                a[i*j]=1;
        }
    }
    fcout<<nr;
    return 0;
}
