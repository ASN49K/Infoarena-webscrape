#include <fstream>
using namespace std;
const int MAX = 2e6 + 5;
 
bool comp[MAX];
 
int main(){
	ifstream fin;
	ofstream fout;
	fin.open("ciur.in");
	fout.open("ciur.out"); 
	int n, p;
	fin >> n;
	p = 2;
	while(p*p <= n){
		for(int i = 2*p; i<=n; i = i + p){
			comp[i] = true;
		}
		++p;
		while(comp[p])
			++p;
	}
	int ans = 0;
	for(int i = 2; i<=n; ++i)
		if(!comp[i])
			++ans;
	fout << ans;
 
}