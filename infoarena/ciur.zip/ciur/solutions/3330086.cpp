#include <iostream>
#include <fstream>
#include <bitset>

using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

bitset <10001> v; //vector de biti


void ciur(int n)
{
    int i, j;
    v[0]=v[1]=1;
    for(i = 4 ; i<=n ; i+=2)
        v[i]=1;
    for(i=3 ; i*i<=n ; i+=2)
        if(v[i] == 0)
        {
            for(j=i*i ; j<=n ; j+=i)
                v[j]=1;
        }
}

int main()
{
    int n , c=0;
    f>>n;
    ciur(n);
    for(int i=2 ; i<=n ; i++)
        if (v[i] == 0)
            c++;
    g<<c;

    f.close();
    g.close();
    return 0;
}
