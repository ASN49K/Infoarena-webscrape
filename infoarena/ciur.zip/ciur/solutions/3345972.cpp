// #include <iostream>
#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int ans;
int ciur[2000001]; 
long long n;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    for(int i = 2; i <= n; i++) 
        if(ciur[i] == 0)  
            for(int j = 2 * i; j <= n; j += i) 
                ciur[j] = 1;


    for(int i = 2; i <= n; i++) 
        if(ciur[i] == 0) 
            ans++;
        

    cout << ans;
    return 0;
}
