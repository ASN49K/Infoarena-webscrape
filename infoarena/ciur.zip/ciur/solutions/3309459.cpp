#include <fstream>

using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

bool v[2000001];

int main()
{
    int n,i,j,cnt=0;
    in>>n;
    v[0]=1;
    v[1]=1;
    for(i=2; i*i<=n; i++)
    {
        if(v[i]==0)
        {
            for(j=2;i*j<=n;j++)
            {
                v[i*j]=1;
            }
        }
    }
    for(i=1; i<=n; i++)
    {
        if(v[i]==0)
            cnt++;
    }
    out<<cnt;
    return 0;
}
