#include "bits/stdc++.h"
using namespace std;
 
#define ll long long
 
#define       forn(i,n)              for(int i=0;i<n;i++)
#define          all(v)              v.begin(), v.end()
#define         rall(v)              v.rbegin(),v.rend()
 
#define            pb                push_back
#define          sz(a)               (int)a.size()

void solve() {
    int n;
    cin >> n;
    int ans = 0;
    vector<bool> prime(n + 1, true);

    for(int i = 2;i <= n; ++i) {
        if(prime[i]) {
            ++ans;
            for(ll j = 1LL * i * i; j <= n; j += i) {
               prime[j] = false;
            }
        }
    }
    cout << ans << "\n";
} 
 
int32_t main() {
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t = 1;
    //cin >> t;
    while(t--) {
        solve();
    }
}