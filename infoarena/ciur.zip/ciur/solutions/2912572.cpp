#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n, contor = 1;
    fin >> n;

    vector < bool > isPrime(n + 1, true);

    for(int i = 3; i <= n; i += 2)
    {
        if(isPrime[i] == true)
        {
            contor++;
            if(1LL * i * i <= n)
                for(int j = i * i; j <= n; j += i * 2)
                {
                    isPrime[j] = false;
                }
        }
    }

    fout << contor;

    return 0;
}
