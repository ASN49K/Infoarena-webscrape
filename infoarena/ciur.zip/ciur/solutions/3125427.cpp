#include <bits/stdc++.h>

#define all(x) (x).begin(), (x).end()
using namespace std;
using ll = long long;

const int NMAX = 2e6 + 10, mod = 1e9 + 7;
int n, cnt;
bool prime[NMAX + 10];

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);

    cin >> n;
    for (int i = 2; i <= n; i++)
        prime[i] = true;
    for (int i = 2; i <= n; i++)
        if (prime[i]) {
            cnt++;
            for (int j = i  + i; j <= n; j += i)
                prime[j] = false;
        }
    cout << cnt;
}