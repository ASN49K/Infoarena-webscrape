#include <iostream>
#include <fstream>

int main(){	
	int utolsoSzam, primSzamok = 0, primSzita[2000000] = {};
	
	std::ifstream bem("ciur.in");
       	bem >> utolsoSzam;
	bem.close();

	for(int i = 2; i < utolsoSzam; i++){

		if(primSzita[i] == 0){

			for(int j = 2; i * j < utolsoSzam; j++){

				primSzita[i * j] = 1;
			}
		}
	}


	for(int i = 2; i < utolsoSzam; i++){

		if(primSzita[i] == 0){
			primSzamok++;
		}

	}

	std::ofstream kim("ciur.out");

	kim << primSzamok;

	kim.close();

	delete[] primSzita;

	return 0;
}
