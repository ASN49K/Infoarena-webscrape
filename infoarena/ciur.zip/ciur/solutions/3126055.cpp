#include <bits/stdc++.h>
#define NMAX 2000005
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bitset <NMAX> c;
int ciur(int n){
    int i,j,k = 1;
    c[1] = c[0] = 1;
    for(i = 2; i <= n; i += 2){
        c[i] = 1;
    }
    for(i = 3; i * i<= n; i += 2){
        if(!c[i]){
            for(j = i * i; j <= n; j += 2 * i){
                c[j] = 1;
            }
        }
    }
    for(i = 3; i <= n; i += 2){
        if(!c[i]) k++;
    }
    return k;
}

int main()
{
    int n;
    fin >> n;
    fout << ciur(n);
    return 0;
}
