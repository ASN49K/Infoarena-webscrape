#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int i, j, n, m, nr;
bool f[2000002];
int main(){
    cin>>n;
    f[0]=f[1]=1;
    for(i=2;i<=n;i++){
        if(f[i]==0){
            nr++;
            for(j=i+i;j<=n;j+=i)
                f[j]=1;
        }
    }
    cout<<nr;




}
