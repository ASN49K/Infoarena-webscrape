#include <fstream>
#include <vector>
using namespace std;

#define ll long long

ifstream fin("ciur.in");
ofstream fout("ciur.out");

ll ciur(ll n){
  ll nr = 0;
  vector <bool> prim(n+1, false);
  prim[1] = true;
  for(ll i = 2; i <= n; ++i){
    if(!prim[i]) {
      ++nr;
      for(ll j = i; j <= n; j+=i)
        prim[j] = true;
    }
  }
  return nr;
}

int main(){
  ll n;

  fin >> n;
  fout << ciur(n);

  return 0;
}