#include <stdio.h>
#include <stdlib.h>

char ciur[2000002];

int main()
{
    FILE *fin, *fout;
    int n, i, d, x, nrprime=0;

    fin = fopen("ciur.in", "r");
    fout = fopen("ciur.out", "w");

    fscanf(fin, "%d", &n);

    for(i=2; i<n; i++)
    {
        if(ciur[i]==0)
        {
            nrprime++;
            for(d=i+i; d<n; d+=i)
                ciur[d] = 1;
        }
    }


    fprintf(fout, "%d", nrprime);
    //for(i=0; i<n; i++)
        //fprintf(fout, "%d\n", ciur[i]);

    fclose(fin);
    fclose(fout);
    return 0;
}
