#include<iostream>
#include <fstream>

using namespace std;
bool t[2000005];
int main()
{
    int N,i,S=0,j;
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    fin>>N;

    for(i=2;i*i<=N;i++)
    {
        for(j=2*i;j<=N;j=j+i)
        {
            t[j]=true;




        }

    }
    for(i=2;i<=N;i++)
    {
        if(t[i]==false)
        {
            S++;
        }
    }
    cout<<S;
    return 0;
}
