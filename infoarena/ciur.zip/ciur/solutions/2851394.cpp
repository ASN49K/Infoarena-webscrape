#include <bits/stdc++.h>

using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

const int N=2e6+5;
bool c[N];

void ciur(int n)
{
    c[1]=1;

    for(int i=2;i*i<=n;i++)
        if(!c[i])
    {
        for(int j=2;i*j<=n;j++)
            c[i*j]=1;
    }
}

int main()
{
    long n,sol=0;
    in>>n;

    ciur(n);
    for(int i=2;i<=n;i++)
        if(!c[i]) sol++;
    out<<sol;

    return 0;
}
