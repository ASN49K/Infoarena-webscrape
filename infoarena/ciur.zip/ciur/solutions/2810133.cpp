﻿#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
bool v[2000001] = {0};
int n;
int main() {
	cin >> n;
	v[0] = v[1] = 1;
	int cate = 0;
	for (int i = 2; i * i <= n; ++i) {
		if (v[i] == 0) {
			for (int k = 2; k <= n / i; ++k)
				v[i * k] = 1;
		}
	}

	for (int i = 2; i <= n; ++i)
		if (v[i] == 0)
			cate++;
	cout << cate;

	return 0;
}