#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*int a;*/
    FILE *r,*w;
    int n;
    r = fopen("ciur.in", "r");
    w = fopen("ciur.out", "w");

    fscanf(r, "%d", &n);

    int i=3, is_prim,cnt=1,d;
    fscanf(r,"%d",&n);
    while (i<=n){
        is_prim=1;
        d=2;
        while(d*d<=i){
            if(i%d==0){
                is_prim=0;
                d=i;
            }
            d++;
        }
        if(is_prim){
            cnt=cnt+1;
        }
        i=i+2;
    }
    fprintf(w, "%d", cnt);
}
