#include <iostream>
#include <fstream>
using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");

int n,k;
char v[2000005];

int main()
{
    f>>n;
    for(int i=2;i<=n;i++)
        v[i]=1;
    for(int i=2;i<=n;i++)
        if(v[i]){
            k++;
            for(int j=i+i;j<=n;j+=i)
                v[j]=0;
        }
    g<<k;
    return 0;
}
