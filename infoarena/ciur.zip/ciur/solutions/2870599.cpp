#include <fstream>
#include <bitset>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout("ciur.out");

const int NMAX = 2e6;

int n, s = 1;
bitset<NMAX> ciur;

void Ciur_Eratosthenes() {
    ciur[0] = ciur[1] = 1;

    for (int i = 4; i <= n; i += 2)
        ciur[i] = 1;

    for (int i = 3; i <= n; i += 2)
        if (!ciur[i]) {
            s++;
            for (int j = i + i; j <= n; j += i)
                ciur[j] = 1;
        }
}

int main() {
    fin >> n;
    Ciur_Eratosthenes();
    fout << s;
    return 0;
}
