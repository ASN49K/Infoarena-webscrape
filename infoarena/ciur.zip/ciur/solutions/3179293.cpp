#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,cnt;
bool v[1500];
void ciur()
{
    v[0]=1,v[1]=1;
    for(int i=2;i*i<=n;i++)
        if(v[i]==0)
        for(int j=2;j<=n/i;j++)
                v[i*j]=1;
}
int main()
{
    fin>>n;
    ciur();
    for(int i=2;i<=n;i++)
        if(v[i]==0)
            cnt++;
    fout<<cnt;
    return 0;
}
