#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bool erath[2000005];

int main()
{
    int n;
    int cnt = 0;
    fin >> n;

    for(int div = 2;div*div<=n;div++){
        if(erath[div]==1){
            continue;
        }
        for(int multiplu = 2*div;multiplu<=n;multiplu+=div){
            erath[multiplu]=1;
        }

    }

    for(int i = 2;i<=n;i++){
            if(erath[i]==0){
                cnt++;
            }
        }

    fout << cnt;
    return 0;
}
