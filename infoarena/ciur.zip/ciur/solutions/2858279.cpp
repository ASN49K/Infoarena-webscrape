#include <fstream>
#include <iostream>
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
bool ciur[2000001];
int main()
{
    int n, cntPrim=0;
    in >> n;
    for (int i = 2; i * i <= n; i++)
    {
        if (ciur[i] == 0)
        {
            for (int j = i; j <= n / i; j++)
            {
                ciur[i * j] = 1;
            }
        }
    }
    for (int i = 2; i <= n; i++)
    {
        if (ciur[i] == 0)
        {
            cntPrim++;
        }
    }
    out << cntPrim;
}
