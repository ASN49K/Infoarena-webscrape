#include <fstream>

using namespace std;

const int NMAX = 2e6;

int s[NMAX + 1];
constexpr int sieve() {
    for (int i = 2; i * i <= NMAX; i++) {
        if (s[i]) continue;
        for (int j = i * i; j <= NMAX; j += i) s[j] = 1;
    }
    for (int i = 2; i <= NMAX; i++) s[i] += s[i - 1];

    return 0;
}

const int _ = sieve();

int main() {
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");

    int n; cin >> n;
    cout << s[n] << '\n';

    return 0;
}