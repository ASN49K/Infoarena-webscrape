#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

int n,nr;

void eratostene(int n)
{
	vector<bool> prim(n + 1, true);
	prim[0] = prim[1] = false;
	for (int i = 2; i * i <= n; i++)
	{
		if (prim[i])
		{
			for (int j = i * i; j <= n; j += i)
			{
				prim[j] = false;
			}
		}
	}
	for (int i = 2; i <= n; i++)
	{
		if (prim[i])
		{
			nr++;
		}
	}
}

int main()
{
	cin >> n;
	eratostene(n);
	cout<< nr;
    return 0;
}
