#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("ciur.in","r",stdin);
	freopen("ciur.out","w",stdout);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	int n;
	cin>>n;
	bool a[n]={};
	a[0]=a[1]=true;
	int rs=0;
	for(int i=2;i<=n;i++){
		if(a[i]==false){
		rs++;
		for(int j=i*2;j<=n;j+=i)
		a[j]=true;
	    }
	}
	cout<<rs;
	return 0;
}

