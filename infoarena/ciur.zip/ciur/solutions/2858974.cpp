#include <fstream>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int n, ans;
bool prim[2000005];

int main()
{
    fin>>n;
    for(int i=2; i<=n; i++)
        prim[i]=1;
    for(int i=2; i<=n; i++)
        if(prim[i])
    {
        ans++;
        for(int j=2*i; j<=n; j+=i)
            prim[j]=0;
    }
    fout<<ans;
    return 0;
}
