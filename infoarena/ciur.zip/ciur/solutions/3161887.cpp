#include <iostream>
int main()
{
    int n,c=0;
    bool C[2000002];
    std::fill(std::begin(C), std::end(C), 0);
    std::cin >> n;
    for (int i=2;i<=n;i++)
    {
        if (C[i]==0) {
            c++;
            for (int j=1;j*i<=n;j++)
            {
                C[j*i]=1;
            }
        }
    }
    std::cout << c;
    return 0;
}
