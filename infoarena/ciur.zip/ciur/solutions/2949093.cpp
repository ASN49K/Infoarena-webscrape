#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_VALUE = 2000000;

int frequency[MAX_VALUE + 1];

void primesLessEqualNumber(int n, int &primeCounter) {
    for (int divisor = 2; divisor * divisor <= n; ++divisor) {
        if (frequency[divisor] == 0) {
            for (int number = 2; number * divisor <= n; ++number) {
                if (frequency[divisor * number] == 0) {
                    frequency[divisor * number] = 1;
                    --primeCounter;
                }
            }
        }
    }
}

int main() {
    int n;
    fin >> n;
    int primeCounter = n - 1;
    primesLessEqualNumber(n, primeCounter);
    fout << primeCounter;
    return 0;
}
