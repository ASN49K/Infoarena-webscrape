#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

short not_prime[2000001];

int main() {
    int n;
    fin >> n;
    for (int i = 2; i * i <= n; ++i) {
        if (not_prime[i] == 0) {
            for (int j = i * i; j <= n; j += i) {
                not_prime[j] = 1;
            }
        }
    }
    int prime_nr = 0;
    for (int i = 2; i <= n; ++i) {
        if (not_prime[i] == 0) {
            ++prime_nr;
        }
    }
    fout << prime_nr;
    return 0;
}
