import java.io.*;
import java.util.Scanner;

public class Main {

  public static void main(String[] args) throws IOException {

    try (Scanner scanner = new Scanner(new FileInputStream("ciur.in"));
         PrintWriter pw = new PrintWriter(new FileOutputStream("ciur.out"))) {
      int N = scanner.nextInt();

      byte[] prime = new byte[N+1];

      int nr = 0;

      for (int i = 2; i <= N; i++) {
        if (prime[i] == 0) {
          nr++;
          for (int j = i + i ; j <= N; j += i) {
            prime[j] = 1;
          }
        }
      }

      pw.println(nr);
    }
  }
}
