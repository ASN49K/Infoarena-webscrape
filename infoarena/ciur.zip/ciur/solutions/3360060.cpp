#include <bits/stdc++.h>

using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");
const int N = 2000001;
int n,i,cnt;
short int p[N];
int main()
{
    f>>n;
    /// 2 este singurul numar prim
    /// deci daca il iau pe 2 separat
    /// in rest ma intereseaza doar numere impare
    cnt=1;
    for(i=3;i*i<=n;i+=2)
        if(p[i]==0)
        {
            cnt++;
            for(int j=i*i;j<=n;j+=i)
                p[j]=1;
        }
    for(;i<=n;i+=2)
        if(p[i]==0)
            cnt++;
    g<<cnt<<'\n';
    return 0;
}
