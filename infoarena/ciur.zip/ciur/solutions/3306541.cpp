#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <iomanip>

using namespace std;

#define ll long long

// Global variables
int n;
vector<bool> used;

void ReadData() {
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        used.push_back(false);
    }
    used.push_back(false);
    used[1] = true;  
}

void Solve() {
    int result = 0;
    for (int i = 1; i <= n; i++){
        if (!used[i]){
            result++;
            used[i]=true;
        }

        int val = i;
        while (val <= n){
            if(!used[val])
                used[val] = true;
            val+=val;   
        }   
    }
    
    cout << result << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);

    int t = 1;
    // cin >> t; // Uncomment for multiple test cases
    while (t--) {
        ReadData();
        Solve();   
    }
    return 0;
}