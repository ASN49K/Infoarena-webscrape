#include <iostream>
#include <fstream>

bool isPrime(int n){
	if(n < 2) return false;
	for(int i = 2; i*i <= n; i++){ 
		if(n%i == 0) return false;
	}
	return true;
}

int main(){
	std::ifstream bem("ciur.in");
	std::ofstream kim("ciur.out");

	int n, primek = 0;
	bem >> n;
	bem.close();
	for(int i = 1;i <= n; i++){
		if(isPrime(i)){
			primek++;
		}
	}
	kim<<primek;
	kim.close();
}
