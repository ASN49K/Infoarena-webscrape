

#include <iostream>
#include<fstream>
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
char v[2000000];

int main()
{   long long n, i, j, cnt=0;
    in>>n;
    for(i=0; i<=n; i++){
        v[0]='1';
        v[1]='1';
        v[i]='0';
    }
    int d=2;
    while(d*d<=n){
        if(v[d]=='0'){
            for(j=2; j<=n; j++)
                v[d*j]='1';
        }
        d++;
    }
    for(i=0; i<=n; i++){
        if(v[i]=='0')
            cnt++;
    }
    out<<cnt;
   
    return 0;
}