#include <iostream>
#include <fstream>

using namespace std;

#define N_MAX 2000000

int main()
{
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");

    int nr, i, j, cnt = 0;
    char a[N_MAX] = {0};
    fin >> nr;

    for(i = 2; i <= nr; i++)
    {
        //nemarcat, punem 1 peste toti multipli
        if(a[i] == 0)
        {
            for(j = 2; j < nr; j++)
            {
                a[i*j] = 1;
            }
        }
        else
        {
            continue;
        }
    }

    for(i = 2; i <= nr; i++)
    {
        if(a[i] == 0)
        {
            cnt++;
        }
    }
    fout << cnt;
}
