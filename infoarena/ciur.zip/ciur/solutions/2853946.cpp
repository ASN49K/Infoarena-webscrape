#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n;
bitset<2000003> c;

void Ciur(int n)
{
	int i, j, cnt = 0;
	c[0] = c[1] = 1;
	for (i = 4; i <= n; i += 2)
		c[i] = 1;
	for (i = 3; i * i <= n; i++)
		if (!c[i])
			for (j = 2 * i; j <= n; j += i)
				c[j] = 1;
	for (i = 2; i <= n; i++)
		if (!c[i]) cnt++;
	fout << cnt << "\n";
}

int main()
{
	fin >> n;
	Ciur(n);
}

