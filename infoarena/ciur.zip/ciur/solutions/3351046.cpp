// https://infoarena.ro/problema/ciur

#include<fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

short prim[2000001]; // prim[i] = 0 daca i este prim, prim[i] = 1 daca i nu este prim

int main() {
	int n, nrPrime = 0;
	fin >> n;

	prim[1] = 1; // 1 nu e nr prim

	for(int i = 2; i * i <= n; i++) {
		if(prim[i] == 0) {
			// e prim, deci marcat ca nefiind primi toti multiplii lui
			for(int j = 2; i * j <= n; j++) {
				prim[i * j] = 1;
			}
		}
	}

	for(int i = 2; i <= n; i++) {
		if(prim[i] == 0) {
			nrPrime++;
		}
	}

	fout << nrPrime << endl;

	fin.close();
	fout.close();

	return 0;
}
