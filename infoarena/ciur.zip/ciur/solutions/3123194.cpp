#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int main(){
    int n, nrprime = 0;
    bool prime[2000001] = {0};
    cin >> n;
    for (int i = 2; i * i <= n; i++){
        if (prime[i] == 1) {
           continue;
        }
        for (int j = 2 * i; j <= n; j+= i) {
            prime[j] = 1;
        }
    }
    for (int i = 1; i <= n; i++){
        if (prime[i] == 0)
            nrprime++;
    }
    cout << nrprime;
    return 0;
}