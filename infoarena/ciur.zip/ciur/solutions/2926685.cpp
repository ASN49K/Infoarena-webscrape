#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int ciur[2000001]; //Căutăm numerele prime până la 1000

int main() {
    int n;
    cin >> n;
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) { //Am găsit un număr nemarcat (prim)
            //Marcăm multiplii lui i
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }
    int counter = 0;
    //Afișăm pe ecran toate numerele prime găsite
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            ++counter;
        }
    }
    cout << counter;
    return 0;
}
