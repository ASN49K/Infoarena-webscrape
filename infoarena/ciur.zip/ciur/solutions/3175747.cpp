#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000000> b;
int n, s=1, i, j;

void ciur()
{
    for(i=3; i <= n; i += 2)
    {
        if(!b[i])
        {
            s++;
            for(j=i; j <= n; j += i) b[j] = 1;
        }
    }
}

int main()
{
    fin >> n;
    ciur();
    fout << s;

    return 0;
}
