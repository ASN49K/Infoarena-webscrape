#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

bool c[2000001];

int main()
{
    int i, n, j, nr = 0;

    in >> n;

    c[0] = 1;
    c[1] = 1;
    for(i = 2; i <= sqrt(n); i++) {
        if(c[i] == 0) {
            // eliminam multiplii lui i
            for(j = i*i; j <= n; j = j + i) {
                c[j] = 1;
            }
        }
    }

    for (i = 2; i <= n; i++) {
        if (c[i] == 0) {
            nr++;
        }
    }

    out << nr << "\n";

    return 0;
}
