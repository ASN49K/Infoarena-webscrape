#include <iostream>
#include <fstream>

using namespace std;

int main()
{

    ifstream in("ciur.in");
    ofstream out("ciur.out");

    int n;
    in >> n;

    bool prim[n + 1];
    for (int i = 2; i * i <= n; i++)
    {
        if (prim[i] == 0)
        {
            for (int j = 2 * i; j <= n; j += i)
            {
                prim[j] = 1;
            }
        }
    }

    int ossz = 0;

    for (int i = 2; i <= n; i++)
    {
        if (prim[i] == 0)
        {

            ossz++;
        }
    }

    out << ossz;

    return 0;
}
