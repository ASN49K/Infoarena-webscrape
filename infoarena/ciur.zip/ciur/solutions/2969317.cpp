#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");


int ciur(int n)
{
    int nr=0;
    char a[2000005];
    for(int i=2;i<=n;i++)
        a[i]=1;
    for(int i=2;i<=n;i++)
    {
        if(a[i]){
            nr++;
        for(int j=i+i;j<=n;j+=i)
            a[j]=0;
        }
    }
    return nr;
}

int main()
{
    int n;
    fin>>n;
    fout<<ciur(n);
    return 0;
}
