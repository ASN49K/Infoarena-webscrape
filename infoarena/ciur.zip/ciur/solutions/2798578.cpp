#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>

using namespace std;
#define nmax INT_MAX
ifstream fin("ciur.in");
ofstream out("ciur.out");
int N,k=0;
bitset <nmax>is_prime;
vector <int>prime_nr;

void ciur(){

for(int i=2;i<=N;i++){

    if(is_prime[i]==0){
    for(int j=i*i;j<=N;i++){

     is_prime[j]=1;


    }
    prime_nr.push_back(i);
    k++;
  }
}


}

int main()
{


    fin>>N;

   ciur();
   out<<k;


}
