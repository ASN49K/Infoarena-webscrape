#include <iostream>
#include <fstream>
#include <bitset>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_LENGTH = 200000;
bitset<MAX_LENGTH + 1> primeNumsIndex;

int main() {
    int n, primeNumsCnt = 0;
    fin >> n;
    for (int i = 2; i <= n; ++i) {
        if (primeNumsIndex[i] == 0) {
            ++primeNumsCnt;
            for (int d = 2; i * d <= n; ++d) {
                primeNumsIndex[i * d] = 1;
            }
        }
    }
    fout << primeNumsCnt;
    return 0;
}
