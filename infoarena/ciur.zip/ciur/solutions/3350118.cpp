#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool ciur[2000005];
int main()
{
    int n, ct=0, i;
    fin>>n;
    ciur[0]=1;
    ciur[1]=1;
    for(i=2; i*i<=n; i++)
        if(ciur[i]==0)
            for(int j=i*i; j<=n; j+=i)
                ciur[j]=1;
    for(i=2; i<=n; i++)
        if(ciur[i]==0)
        ct++;
    fout<<ct;
    return 0;
}
