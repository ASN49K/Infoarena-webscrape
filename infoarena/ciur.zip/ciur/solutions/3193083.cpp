#include <iostream>
#include <fstream>

using namespace std;
int prim[2000000];

int main()
{

    ifstream in("ciur.in");
    ofstream out("ciur.out");

    int n;
    in >> n;

    fill(prim, prim + 2000000, 1);

    for (int i = 2; i * i <= n; i++)
    {
        if (prim[i] == 1)
        {
            for (int j = 2 * i; j <= n; j += i)
            {
                prim[j]++;
            }
        }
    }

    int ossz = 0;

    for (int i = 2; i <= n; i++)
    {
        if (prim[i] == 1)
        {

            ossz++;
        }
    }

    out << ossz;

    return 0;
}
