#include<bits/stdc++.h>
using namespace std;

#define MAX 2000000

ifstream fin("ciur.in");
ofstream fout("ciur.out");

void ciur(int n){
   bool prime[MAX];
    long long int nr=0;
    for(int i=2;i<=n;i++) prime[i]=true;
    for(int i=2;i*i<=n;i++)
        if(prime[i]==true)
            for(int j=i*i;j<=n;j+=i) prime[j]=false;
    for(int i=2;i<=n;i++) if(prime[i]==true) nr++;
    fout<<nr;
}

int main(){
    int n;
    fin>>n;
    ciur(n);
    return 0;
}
