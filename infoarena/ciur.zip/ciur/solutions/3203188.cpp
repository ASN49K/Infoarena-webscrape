// #include <iostream>

#include <fstream>
#include <bitset>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

bitset<2000001>v;

void ciur(int n)
{
	int nr = 0;
	v[0] = v[1] = 1;
	for (int i = 4; i <= n; i += 2)
		v[i] = 1;
	for(int i=3;i*i<=n;i+=2)
		if (!v[i])
			for (int j = i * i; j <= n; j += 2 * i)
				v[i] = 1;

	for (int i = 2; i <= n; i++)
		if (!v[i])
			nr++;
	cout << nr;
}
int main()
{
	int n;
	cin >> n;
	ciur(n);
	return 0;
}