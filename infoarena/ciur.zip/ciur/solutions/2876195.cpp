#include <bits/stdc++.h>

using namespace std;

ifstream in ("ciur.in");
ofstream out ("ciur.out");

int n,N;
bitset<2000001>c;

int main()
{
    in>>n;
    for (int i=2; i*i<=n; i++){
        if (c[i]==0){
            for (int j=i*i; j<=n; j+=i){
                c[j]=1;
            }
        }
    }
    for (int i=2; i<=n; i++){
        if (c[i]==0) N++;
    }
    out<<N;
}
