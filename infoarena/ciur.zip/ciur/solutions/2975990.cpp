#include <bits/stdc++.h>
#define max 2000005

using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

char a[max];

void ciur(){
    a[0] = a[1] = 0;
    for (int i = 2; i <= 1400;i++)
    {
        if (a[i] == 0)
        {
            for (int j = 2;j * i <= 2000000;j++)
            {
                a[j * i] = 1;
            }
        }
    }
}

int main() {
    ciur();
    int n;
    int count = 0;
    in >> n;
    for(int i = 2;i <= n;i++){
        if(a[i] == 0) count ++;
    }
    out << count;
    return 0;
}
