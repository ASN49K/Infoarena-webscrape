#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int IsPrime [1700002];

void Ciur(){
    for (int i=2;i<=1700000;++i){
        IsPrime[i] = 1;
    }
    for (int i=2;i<=1700000;++i){
        if (IsPrime[i]==1){
            for (int j=2*i;j<=1700000;j+=i){
                IsPrime[j] = 0;
            }
        }
    }
}

int main()
{
    Ciur();
    int n;
    fin >> n;
    int Raspuns = 0;
    for (int i=2;i<=n;++i){
        if (IsPrime[i]==1){
            Raspuns += 1;
        }
    }
    fout << Raspuns;
    return 0;
}
