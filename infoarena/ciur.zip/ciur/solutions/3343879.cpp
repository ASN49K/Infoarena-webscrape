/// patratele
#include <bits/stdc++.h>
using namespace std;

#define Nmax 2000010
#define pb push_back

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int i,s[Nmax],v[Nmax],n,j;

int main()
{
  // ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  fin>>n;
  for(i=2;i<=n;i++)
    {
      s[i]=s[i-1];
      if(v[i]==0)
        {
          s[i]++;
          for(j=2*i;j<=n;j+=i)
            v[j]=1;
        }
    }
  fout<<s[n];
  return 0;
}
