#include <iostream>
#include <bitset>

using namespace std;

const int MAXN=2e6+5;

bitset<MAXN> ciur;

void getciur(){
    ciur[0]=ciur[1]=true;
    for (int i=2*2;i<MAXN;i+=2){
        ciur[i]=true;
    }
    for (int i=3;i*i<MAXN;i+=2){
        if (ciur[i]==false){
            for (int j=i*i;j<MAXN;j+=2*i){
                ciur[j]=true;
            }
        }
    }
}

int main()
{
    getciur();
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
    int n;
    cin>>n;
    int ans=0;
    for (int i=0;i<=n;i++){
        if (ciur[i]==false) ans++;
    }
    cout<<ans;
    return 0;
}
