#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout("ciur.out");
const int N=2000000;
bool ciur[N+1];
int cnt=0;
int implciur(int n){
    int j,d;
    for(d=2;d*d<=n;d++){
        if(ciur[d]==0){
            for(j=d*d;j<=n;j+=d){
                if(ciur[j]!=1)
                    cnt--;
                ciur[j]=1;

            }
        }
    }
    cnt--;//pentru 1
    return cnt;
}
int main()
{
    int n;
    fin>>n;
    cnt=n;
    fout<<implciur(n);
    return 0;
}
