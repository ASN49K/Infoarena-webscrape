#include <fstream>
#include <iostream>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
int v[200001];
int main()
{
    int n,i,j,i2,nr=0;
f>>n;
    for(int i=3; i<=n; i+=2){
        if(v[i>>4]&(1<<((i>>1)&7))) continue;
        ++nr;

        for(j=i+(i2=i+i); j<=n; j+=i2)
            v[j>>4]|=1<<((j>>1)&7);
    }

    g<<nr+1;


}
