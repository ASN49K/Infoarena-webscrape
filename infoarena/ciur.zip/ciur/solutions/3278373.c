#include<stdio.h>

int p[1000001];

int prim(int x)
{
    int i,j,nr=0;
    for(i = 2; i <= x; i++){
        if(p[i] == 0){
            nr++;
            for(j = i * i; j <= x; j = j + i){
                p[j] = 1;
            }
        }
    }
    return nr;
}
int main(){
    FILE* in = fopen("ciur.in","r");
    FILE* out = fopen("ciur.out","w");
    
    int n;

    fscanf(in,"%d",&n);

    fprintf(out,"%d",prim(n));

    fclose(in);
    fclose(out);
    return 0;
}