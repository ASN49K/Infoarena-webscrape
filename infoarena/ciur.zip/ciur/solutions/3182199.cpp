#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream ain ("ciur.in");
ofstream aout ("ciur.out");

bool c[2000005];

int main()
{
    int n;
    ain>>n;
    c[0]=1;
    c[1]=1;
    for(int i=2;i<=n+5;i++)
    {
        if(c[i]==0)
        {
            for(int j=i+i;j<=n+5;j+=i)
            {
                c[j]=1;
            }
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(c[i]==0)
        {
            cnt++;
        }
    }
    aout<<cnt;
    return 0;
}
