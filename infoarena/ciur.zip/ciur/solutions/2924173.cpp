#include<iostream>
#include<fstream>
using namespace std;
int main()
{
  ifstream f("ciur.in");
  ofstream g("ciur.out");
  int n;
  bool v[2000004];
  f>>n;
  for(int i=2;i<=n;i++)
        v[i]=true;
  for(int i=2;i<=n;i++)
    if(v[i]==true)
  {
   for(int j=2;j*i<=n;j++)
        v[j*i]=false;
  }
  int s=0;
  for(int i=1;i<=n;i++)
    if(v[i])
    s++;
    g<<s;
}
