#include <fstream>
#include <cmath>
using namespace std;
ifstream in ("ciur.in");
ofstream out ("ciur.out");
bool v[2000001];
int main()
{
    int n,k=0;
    in>>n;
    for(int i=2;i*i<=n;i++)
    {
        if(v[i]==0)
        {
            for(int j=i;j*i<=n;j++)
            {
                v[j*i]=1;
            }
        }
    }
    for(int i=2;i<=n;i++)
    {
        if(v[i]==0)
        {
            k++;
        }
    }
    out<<k;
//    k=n-1;
//    for(int i=2; i<=n; i++)
//    {
//        v[i]=i;
//    }
//    int g=sqrt(n);
//    for(int i=2; i<=g; i++)
//    {
//        for(int j=2*i; j<=n; j++)
//        {
//            if(v[j]!=0 && v[i]!=0 && j%i==0)
//            {
//                v[j]=0;
//                k=k-1;
//            }
//        }
//    }

    out<<k;
    return 0;
}
