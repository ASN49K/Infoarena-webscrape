#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

#define cin fin
#define cout fout

int n,k;
bool v[200000005];

int main()
{
   cin>>n;
   for(int i=3;i<=n;i+=2)
   {
     if(v[i]==0)
     {
         k++;
         for(int j=i*i;j<=n;j=j+i) v[j]=1;

     }
   }
   if(n>1) cout<<k+1;
   else cout<<0;
   return 0;
}

