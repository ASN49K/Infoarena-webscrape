#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

std::ifstream fin("ciur.in");
std::ofstream fout("ciur.out");

int main() {
	int n{ 0 };
	int nr{ 1 };

	fin >> n;

	vector<bool> check_if_visited(n + 1, false);

	for (int i = 2; i <= n; i++)
	{
		if (!check_if_visited[i])
		{
			for (int j = 2; j * i <= n; j++)
			{
				check_if_visited[j * i] = true;
			}
			nr++;
		}
	}

	fout << nr;

	return 0;
}