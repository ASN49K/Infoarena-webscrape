#include <iostream>
#include <fstream>
using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");
int main()
{
    int a,i,cnt=0;
    for(i=1;i<=10000000;i++)
    {
        if(i%2==0)
        {
           cnt++;
        }
    }
    out<<cnt;
    return 0;
}
