#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;

int ciur[2000001];

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n;
    fin >> n;
    int rasp=0;
    for(int i=2;i<=n;i++){
        if(ciur[i]==0){
            rasp++;
            for(int j=i;j<=n;j+=i)
                ciur[j]=1;
        }
    }
    fout << rasp;
}
