#include <fstream>

using namespace std;

int n, v[100001];

ifstream cin ("ciur.in");
ofstream cout ("ciur.out");

int main() {
    cin >> n;
    v[1] = 1;
    for (int i = 2; i * i <= n; ++i) {
        if (v[i] == 0) {
            for (int j = 2; j <= n / i; ++j) {
                v[i * j] = 1;
            }
        }
    }
    int cnt = 0;
    for (int i = 1; i <= n; ++i) {
        if (v[i] == 0) {
            ++cnt;
        }
    }
    cout << cnt;
    return 0;
}
