#include <iostream>
int pr(int a, int b) {
    if (b==0) {return 1;}
    if (b%2==1) {return a*pr(a,b-1);}
    return pr(a,b/2)*pr(a,b/2);
}

bool primf(int p, int c=25) {
    float fuzzybool = 0.5;
    for (int i=2; i*i*i*i<c;i++ )
    {
        if ( pr(i,p-1)%p==1 ) {fuzzybool+=0.1;} else {fuzzybool-=0.1;}
    }
    if (fuzzybool>=0.5) {return 1;} else {return 0;}
}
int main()
{
    int n,c=0;
    std::cin >> n;
    bool C[2000000]{1};
    for (int i=0;i<=n;i+=2)
    {
        if (C[i]==1) {
            if (primf(i+2)) {
                c++;
                for (int j=1;j*(i+2)<=n;j++)
                {
                    C[j*(i+2)]=0;
                }
            }
        }
    }
    /*int c=1;
    for (int i=3;i<=n;i+=2)
    {
        if (primf(i)) {c++;}
    }*/
    std::cout << c;
    return 0;
}
