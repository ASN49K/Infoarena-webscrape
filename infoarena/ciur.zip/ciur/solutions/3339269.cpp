#include <iostream>
#include <fstream>
#define FIN "ciur.in"
#define FOUT "ciur.out"

using namespace std;

typedef unsigned long ulong;


int Eratosthenes(ulong n) {

    ulong i, j, size = n - 1;


    bool arr[ n - 1 ];

    for(i = 2; i < n + 1; ++i) arr[i] = true;

    i = 2; //incepem cu 2 prim

//marcam ca neprime toti multiplii lui 2
//

    while(i * i <= n) {

    	 if( arr[ i ] == true) {

    	 	j = 2;

    	 	while( i * j <= n ) {

    	 		int multiply = i * j;

    	 		if( arr[ multiply ] == 1 ) size--;

    	 		arr[ multiply ] = false;

    	 		j++;
    	 	}
    	 }

    	 	i++;
    	 
    }  

    return size;  
}

int main(int argc, char const *argv[])
{
	
	ifstream fin(FIN);

	ofstream fout(FOUT);

	ulong n;

	fin>>n;

    fout<<Eratosthenes( n );   

	return 0;
}

//n = 10
//2 3 4 5 6 7 8 9 10 --> 4 numere prime