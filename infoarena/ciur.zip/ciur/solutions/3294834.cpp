#include<fstream>
#include<map>
using namespace std ;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
char fr[20000005];
int main(){

    int n , cnt = 0  ; 
      cin>>n;
       for(int i = 2 ; i <= n ; i ++ )
           fr[i] = 1 ; 
       
           for(int i = 2 ; i <= n ; i ++ ){
               if(fr[i] == 1 ){
                   cnt ++ ; 
                     for(int j =  2 * i ; j <= n ; j +=i )
                       fr[j] = 0 ;
               }
           }
             cout<<cnt;







    return 0 ; 
}