#include <bits/stdc++.h>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
const int N = 2000001;
int n,sol;
char p[N];
int main()
{
    f>>n;
    for(int i=2; i<=n; i++)
        if(p[i]==0)
        {
            sol++;
            for(int j=i; j<=n; j+=i)
                p[j]=1;
        }
    g<<sol<<'\n';
    return 0;
}
