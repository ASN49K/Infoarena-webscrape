#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n;
    fin>>n;
    bool ciur[2000000]={0};
    int cnt=0;
    for(int i=2;i*i<=n;i++)
    {
        if(ciur[i]==false)
            for(int j=2;j<=n/i;j++)
                ciur[j*i]=true;

    }
    for(int i=2;i<=n;i++)
        if(ciur[i]==false)
            cnt++;
    fout<<cnt;
    return 0;
}
