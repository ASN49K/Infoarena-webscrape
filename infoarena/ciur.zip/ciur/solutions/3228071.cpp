#include <fstream>
#include <bitset>
using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

bitset <2000001> ciur;

int main()
{
    int n;
    in >> n;
    for(int i = 4; i <= n; i += 2)
        ciur[i] = 1;
    for(int i = 3; i * i <= n; i += 2)
        if(ciur[i] == 0)
            for(int j = i * i; j <= n; j += 2 * i)
                ciur[j] = 1;
    int cnt = 1;///pentru i = 2
    for(int i = 3; i <= n; i += 2)
        if(ciur[i] == 0)
            cnt++;
    out << cnt;
    return 0;
}