#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main() {

    int n;
    fin >> n;
    int r = n, d = 2;
    while(n > 1) {
        if (n % d == 0) {
            r = r / d * (d - 1);
            while(n%d==0) {
                n /= d;
            }
        }
        d++;
        if (d * d > n) {
            d = n;
        }
    }
    fout << r;
}