#include <iostream>

using namespace std;

int main()
{
    int a,i,cnt=0;
    for(i=1;i<=10000000;i++)
    {
        if(i%2==0)
        {
           cnt++;
        }
    }

    return 0;
}
