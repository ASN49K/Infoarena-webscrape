#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,cnt;
bool v[2000001];
void ciur()
{
    v[0]=1,v[1]=1;
    for(int i=2;i*i<=1500;i++)
        if(v[i]==0)
        for(int j=2;i*j<=2000000;j++)
                v[i*j]=1;
}
int main()
{
    fin>>n;
    ciur();
    for(int i=2;i<=n;i++)
        if(v[i]==0)
            cnt++;
    fout<<cnt;
    return 0;
}
