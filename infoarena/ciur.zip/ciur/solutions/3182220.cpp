#include <fstream>
#define NMAX 2000000
using namespace std;
int c[NMAX], v[1500];
int  ciur(int n){
  c[0] = c[1] = 1;
  int cate = 0;
  for(int i = 2 ; i <= n;i++){
    if(!c[i]){
        cate++;
      for(int j = i *i;j <=n;j+=i){
        c[j] = 1;
      }
    }
  }
  return cate;
}
int main(){
    int m, cate;
    unsigned int n;
    ifstream cin("ciur.in");
    cin>>n;
    cin.close();
    ofstream cout("ciur.out");
    cout<<ciur(n)<<"\n";
    cout.close();
    return 0;
}
