#include <fstream>

using namespace std;
ifstream in ("ciur.in");
ofstream out ("ciur.out");
int ciur[2000000];
int main()
{
    int n,i,g=0,cp;
    in>>n;
    for(i=2;i<=n;i++)
    {
        if(ciur[i]==0)
        {
            g++;
            cp=i;
            for(cp;cp<=n;cp+=i)
                ciur[cp]=1;
        }
    }

    out<<g;
    return 0;
}
