#include <fstream>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

int v[2000001];

void chur(int n)
{
    int r=0;
    for(int i=2;i<=n;i++)
        if(v[i]==0)
        {
            r++;
            for(int j=1;i*j<=n;j++)
                v[i*j]=1;
        }
    cout<<r;
}

int main()
{
    int n,m;
    cin>>n;
    chur(n);
    return 0;
}
