#include <iostream>
#include <set>

using namespace std;

//set<int> s;
int main(){

    s.insert(67);
    s.insert(69);

    int q;
    cin>>q;

    for (int i = 1; i<=q; i++){

        int a;
        cin>>a;

        auto it = s.find(a);

        if (it!=s.end()){
            cout<<distance(s.begin(), it);
        }
        else cout<<"NO";
        cout<<'\n';

    }

    return 0;
}
