#include <fstream>
#include <vector>

using namespace std;

// Declaram vectorul in afara main-ului (pe heap/global) pentru a evita depasirea stivei
// Folosim vector<bool> deoarece este optimizat pentru spatiu (aloca 1 bit per element)
vector<bool> este_prim;

int main() {
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");

    int n;
    fin >> n;

    // Redimensionam vectorul pentru a putea accesa indexul n
    este_prim.assign(n + 1, true);
    
    este_prim[0] = false;
    este_prim[1] = false;

    // Aplicam Ciurul lui Eratostene
    for (int i = 2; i * i <= n; ++i) {
        if (este_prim[i]) {
            // Marcam multiplii lui i ca fiind compusi
            // Incepem de la i * i deoarece multiplii mai mici au fost deja marcati
            for (int j = i * i; j <= n; j += i) {
                este_prim[j] = false;
            }
        }
    }

    // Numaram cate numere au ramas marcate ca fiind prime
    int numere_prime = 0;
    for (int i = 2; i <= n; ++i) {
        if (este_prim[i]) {
            numere_prime++;
        }
    }

    fout << numere_prime << "\n";

    return 0;
}
