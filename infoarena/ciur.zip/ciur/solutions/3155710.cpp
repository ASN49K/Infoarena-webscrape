#include <bits/stdc++.h>

#define N_MAX 2000000000

using namespace std;

ifstream fin("ciur.in");

ofstream fout("ciur.out");

bool prim[N_MAX + 1];

int n;
int cnt;

int main()
{
    fin >> n;
    for (int i = 2; i <= n; i++)
    {
        if (!prim[i])
        {
            cnt++;
            for (int j = i + i; j <= n; j += i)
                prim[j] = true;
        }
    }
    fout<<cnt;
}