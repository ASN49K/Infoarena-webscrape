#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int v[2000000];

int eratostene(int n)
{
    int cnt = 0;
    for(int i = 2; i<=n; i++)
    {
        for(int j = i+i; j<=n; j+=i)
        {
            if(!v[j])cnt++;
            v[j] = 1;
        }
    }
    return n-cnt-1;
}

int main()
{
    int n; fin>>n;
    fout<<eratostene(n);
    return 0;
}
