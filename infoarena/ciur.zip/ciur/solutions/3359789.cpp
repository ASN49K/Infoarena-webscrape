#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n, i, j, ciur[2000005], ans;
int main()
{
    fin>>n;
    ciur[0]=ciur[1]=1;
    for(i=2; i<=n; i++)
        if(ciur[i]==0)
    {
        ans++;
        for(j=2*i; j<=n; j+=i)
                    ciur[j]=1;
    }
    fout<<ans;
    return 0;
}
