#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n,a[2000005],k=0;
void ciur()
{
    for(int i=2;i<=2000000;i++)
    {
        if(a[i]==0)
        {
            for(int j=2*i;j<=2000000;j+=i)
            {
                a[j]=1;
            }
            a[i]=++k;
        }
        a[i]=k;
    }
}
int main()
{
    fin>>n;
    ciur();
    fout<<a[n];
}
