#include <stdio.h>
char ciur[2000001];
int main()
{
    FILE *in, *out;
    in = fopen("ciur.in","r");
    out = fopen("ciur.out","w");
    int n, i, s=0, j;
    fscanf(in, "%d", &n);
    for(i = 1; i <= n; i++)
    {
        ciur[i] = 1;
    }
    for(i=2; i * i <= n; i++)
    {
        if(ciur[i] == 1)
        {
            for(j = i * i; j <=n; j = j + i)
            {
                ciur[j] = 0;
            }
        }
    }
    for(i=2; i <= n; i++)
    {
        if(ciur[i]==1)
        s++;
    }
    fprintf(out, "%d", s);

    return 0;
}
