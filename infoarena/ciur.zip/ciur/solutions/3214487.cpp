#include <fstream>
#include <queue>
#include <iostream>
#include <bitset>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int N = 2e6;
bitset<N> ciur;
void create()
{
    ciur[0] = ciur[1] = 1;
    for (int i = 4; i <= N; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i <= N; i += 2)
        if (!ciur[i])
            for (int j = i * i; j <= N; j += 2 * i)
                ciur[j] = 1;
}
int main()
{
    create();
    int n;
    fin >> n;
    int cnt = 0;
    for (int i = 1; i <= n; i++)
    {
        if (ciur[i] == 0)
            cnt++;
    }
    fout << cnt;
    return 0;
}
