#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int ciur[2000000];
int main()
{
    int n;
    cin >> n;
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }
    int nr=0;
        for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            nr++;
        }

}
cout << nr;
}
