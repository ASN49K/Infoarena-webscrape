#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int MAX_SIZE = 2000000;
long long ciur[MAX_SIZE + 1];

int main() {
  long long n;
  fin >> n;
  for(int i = 2; i <= n; i++) {
    if(ciur[i] == 0) {
      for(int j = 2 * i; j <= n; j += i) {
        ciur[j] = 1;
      }
    }
  }
  int counter = 0;
  for(int i = 2; i <= n; i++) {
    if(ciur[i] == 0) {
      ++counter;
    }
  }
  fout << counter;
  return 0;
}
