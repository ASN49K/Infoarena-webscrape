#include <fstream>

using namespace std;

ifstream f("ciur.in");
ofstream g("ciur.out");
char ciur[2000002]={0};
int main()
{
	int numerePrime = 0,d=2,n;


	f >> n;
while(d*d<=n)
{

    for(int i=2; i*d<=n; i++)
        ciur[d*i]=1;
    d++;


    while(ciur[d]==1)
        d++;

}
for(int i=2 ;i<=n; i++)
{
    if(ciur[i]==0)
    numerePrime++;
}
g<<numerePrime;
	return 0;

}



