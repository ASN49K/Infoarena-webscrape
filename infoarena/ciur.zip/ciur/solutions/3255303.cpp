#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

const int max_size = 2e2 + 20;

vector <int> prime;
bool ciur [max_size];

void ciuru ()
{
    ciur[0] = 1;
    ciur[1] = 1;
    for (int i = 2; i <= max_size; i++){
        if (ciur[i] == 1){
            continue;
        }
        for (int k = 2 * i; k <= max_size; k += i){
            ciur[k] = 1;
        }
        if (ciur[i] == 0){
            prime.push_back(i);
        }
    }
}

int main()
{
    ciuru();
    int N, n = 0, cnt = 0;
    in >> N;
    while (n < N){
        if (n == prime[cnt]){
            cnt++;
        }
        n++;
    }
    out << cnt;
    return 0;
}
