#include <fstream>
#include <vector>

using namespace std;

//ifstream be("be.txt");
//ofstream ki("ki.txt");

ifstream be("ciur.in");
ofstream ki("ciur.out");

int main()
{

    int n; 
    be >> n;

    int size = n;
    vector<bool> szita(size + 1, 1);

    szita[0] = szita[1] = 0;

    for(int i = 2; i <= size; i++)
    {
        if(szita[i])
        {
            for(int j = 2; j * i <= size; j++)
            {
                szita[j * i] = 0;
            }
        }
    }

    int ans = 0;

    for(int i = 2; i <= n; i++)
    {
        if(szita[i])
        {
            ans++;
        }
    }

    ki << ans;

    return 0;
}