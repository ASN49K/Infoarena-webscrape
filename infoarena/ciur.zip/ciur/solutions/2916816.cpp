#include <stdio.h>
using namespace std;
int ciur[2000005];
int main()
{
    int n;
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);

    scanf("%d", &n);
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }
    int nr=0;
        for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            nr++;
        }

}
printf("%d\n",nr);
}
