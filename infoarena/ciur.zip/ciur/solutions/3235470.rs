use std::{fs::File, io::BufWriter};
use std::io::prelude::*;
fn pow(base: u64, exponent: u64, modulo: u64) -> u64 {
    let mut val = 1;
    let mut sq = base;
    let mut exponent = exponent;
    while exponent > 0 {
        if (exponent & 1) == 1 {
            val = (val * sq) % modulo;
        }
        exponent >>= 1;
        sq = (sq * sq) % modulo;
    }
    val
}
fn miller_rabin_test(a: u64, d: u64, s: u64, n: u64) -> bool {
    let val = pow(a, d, n);
    if (val == 1) || (val == (n - 1)) {
        return true;
    }
    for r in 1..s {
        if pow(a, d << r, n) == (n - 1) {
            return true;
        }
    }
    false
}
fn is_prime(num: u64) -> bool {
    if num <= 1 {
        return false;
    }
    if (num == 3) || (num == 5) {
        return true;
    }
    let s = (num - 1).trailing_zeros() as u64;
    let d = (num - 1) >> s;
    if !miller_rabin_test(2, d, s, num) {
        return false;
    }
    if !miller_rabin_test(3, d, s, num) {
        return false;
    }
    if !miller_rabin_test(5, d, s, num) {
        return false;
    }
    true
}
fn main() {
    let mut writer = BufWriter::new(File::create("ciur.out").unwrap());
    let n = std::fs::read_to_string("ciur.in").unwrap().trim().parse::<u64>().unwrap();
    let mut cnt = 0;
    if n >= 2 {
        cnt = 1;
        for i in (3..=n).step_by(2) {
            if is_prime(i) {
                cnt += 1;
            }
        }
    }
    write!(writer, "{cnt}").expect("could not write to file");
}
