#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n;
int fr[2000002];
bitset<2000002> C;

int Ciur(int N)
{
    int cnt = 1;
    C[1] = 1;
    for (int i = 4; i <= N; i += 2)
        C[i] = 1;
    for (int i = 3; i * i <= N; i += 2)
        if (C[i] == 0)
            for (int j = i * i; j <= N; j += 2 * i)
                C[j] = 1;
    for (int i = 3; i <= N; i += 2)
        if (C[i] == 0) cnt++;
    return cnt;
}

int main()
{
    fin >> n;
    fout << Ciur(n)<< "\n";
    fin.close();
    fout.close();
    return 0;
}
