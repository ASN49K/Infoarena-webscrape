#include <fstream>

using namespace std;

const int NMAX = 2e6;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bool ciur[NMAX];
int n,c;
int main()
{

    fin >> n;

    for(int i=2;i<=n;i++)
        ciur[i]= 0;

    ciur[2]=0;

    for(int i=2;i<=n;++i)
    {if(ciur[i]==0)
            c++;
    for (int j=2;i*j<=n;j++)
        ciur[i*j]=1;}


    fout<<c;

    return 0;
}






