#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[200001], i, j, n, cnt=0;
    FILE *r, *w;
    r=fopen("ciur.in", "r");
    w=fopen("ciur.out", "w");
    fscanf(r,"%d", &n);
    for(i=2; i<=n; i++){
        v[i]=0;
    }
    for(i=2; i<=n; i++){
        for(j=2; j*i<=n; j++){
        v[j*i]=1;
        }
    }
    for(i=2; i<=n; i++){
        if(v[i]==0){
            cnt++;
        }

    }
    fprintf(w, "%d", cnt);


    return 0;
}
