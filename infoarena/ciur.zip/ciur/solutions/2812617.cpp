#include <fstream>

using namespace std;

ifstream cin ("ciur.in");
ofstream cout ("ciur.out");

bool v[2000001] = {0};
int main ()
{
  int n, k = 0;
  cin >> n;
  v[0] = v[1] = 1;
  for (int i = 2; i * i <= n; ++i){
    if (v[i] == 0){
        for (int j = 2;j <= n/i;++j)
            v[i*j] = 1;
    }
  }
  for (int i = 2;i <=n;++i)
    if (v[i] == 0)
            ++k;
  cout << k;

  return 0;
}
