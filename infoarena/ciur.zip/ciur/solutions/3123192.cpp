#include <iostream>

using namespace std;
int eratostene[2000001];
int main()
{
    int n,nr=0;
    cin>>n;
    for(int div=2;div*div<=n;div++)
    {
        if(eratostene[div]==1)
        {
            continue;
        }
        for(int mult=div*2;mult<=n;mult+=div)
        {
            eratostene[mult]=1;
        }
    }
    for(int i=2;i<=n;i++)
    {
        if(eratostene[i]==0)
            nr++;
    }
    cout<<nr;
}
