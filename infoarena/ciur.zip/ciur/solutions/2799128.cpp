#include <fstream>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include<bitset>
#include <map>
#include <cstring>
#include<algorithm>
#define MOD 1234567
using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int n;
int ciur[2000003];



int main()
{
    fin>>n;
    if(n<2)
    {
        fout<<0;
    }
    int val=0;
    for(int i=2; i<=n; i++)
    {
        if(ciur[i]==0)
        {
            val++;
            int j=2;
            while(i*j<=n)
            {
                ciur[i*j]=1;
                j++;
            }
        }
    }
    fout<<val;
    return 0;

}
