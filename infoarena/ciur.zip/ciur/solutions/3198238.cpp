#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main () {
  int n; fin >> n;
  bool arr[n + 1];
  int size = n-1;

  // Presupunem prin absurd ca toate elementele sunt prime
  for (int i = 2; i < n + 1; ++i) arr[i] = true;

  // Eliminam elementele care se dovedesc a nu fi prime
  // O(sqrt(n) * m)
  int i = 2;
  while (i * i <= n) {
    if (arr[i] == true) {
      int j = 2;
      while (i * j <= n) {
        int multiply = i *j;
        if (arr[multiply]) {
          size--;
          arr[multiply] = false;
        }
        j++;
      }
    }
    i++;
  }

  // for (int i = 1; i < n + 1; i++)
  //   if (arr[i])
  //     fout << i << " ";

  // Le numaram pe cele ramase
  // i = 2; int k = 0;
  // while (i < n) {
  //   if (arr[i])
  //     k++;
  //   i++;
  // }
  fout << size;
  return 0;
}
