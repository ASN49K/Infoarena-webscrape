#include <iostream>
using namespace std;
bool v[20000001];
int main()
{
    int n,j,i,x=0;
    cin>>n;
    for(i=2;i*i<=n;i++)
    {
        if(v[i]==0)
        for(j=i*2;j<=n;j=j+i)
        {
            v[j]=1;
        }
    }
        for(i=2;i<=n;i++)
        if(v[i]==0)
        x++;
    cout<<x;
return 0;
}
