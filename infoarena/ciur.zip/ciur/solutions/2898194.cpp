#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_SIZE = 2000000000;
int markPrimeNumbers[MAX_SIZE + 1];

int main() {
    int n;
    fin >> n;
    int primeNo = 0;
    for (int i = 2; i <= n; i += 2) {
        if (markPrimeNumbers[i] != -1) {
            ++primeNo;
            for (long long j = i; j <= n; j += i) {
                markPrimeNumbers[i * j] = -1;
            }
        }
    }
    fout << primeNo;
    return 0;
}
