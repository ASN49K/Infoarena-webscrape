#include<fstream>
#include<bits/stdc++.h>
using namespace std;
long long int v[100000]={};
int main(){
    ifstream in("fact.in");
    ofstream out("fact.out");
    long long int c=0,n;
    in>>n;
    v[1]=1;
    for(long long int i=2;i<=n;i++){
        if(v[i]==0){
            c++;
            for(long long int j=2*i;j<=n;j+=i){
                v[j]=1;
            }
        }
    }
    out<<c;
}
