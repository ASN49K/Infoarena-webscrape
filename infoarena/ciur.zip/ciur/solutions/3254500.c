#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N, x = 3, nr =1, d,cnt=1;
    FILE *r, *w;
    r=fopen("ciur.in", "r");
    w=fopen("ciur.out", "w");

    fscanf(r, "%d", &N);
    while(x<=N){
        nr=1;
        d=2;
        while(d*d<=x){
            if(x%d==0){
                nr=0;
                d=x;
            }
            d++;
        }
        x=x+2;
        if(nr){
            cnt++;
        }
    }

    fprintf(w, "%d", cnt);

    return 0;
}
