#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool t[2000005];

int main()
{
    int n,counter=0,i,j;
    fin>>n;
    for(i=2;i*i<=n;i++)
    {
        if(t[i]==0)
        {
            for(j=2;j<=n/i;j++)
            {
                t[i*j]=1;
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        if(t[i]==0)
            counter++;
    }
    fout<<counter;
    return 0;
}
