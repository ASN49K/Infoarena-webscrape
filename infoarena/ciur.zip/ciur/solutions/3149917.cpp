#include <fstream>

using namespace std;

const int NMAX = 2e6;

int s[NMAX / 2 + 1];
constexpr int sieve() {
    for (int i = 3; i * i <= NMAX; i += 2) {
        if (s[i / 2]) continue;
        for (int j = i * i; j <= NMAX; j += 2 * i) s[j / 2] = 1;
    }
    for (int i = 3; i <= NMAX; i += 2) s[i / 2] += s[i / 2 - 1];

    return 0;
}

const int _ = sieve();

int main() {
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");

    int n; cin >> n;
    if (n == 2) cout << 1 << '\n';
    else cout << n - n / 2 - s[(n + 1) / 2] << '\n'; // to fix

    return 0;
}