#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int V[2000000];
int main()
{
    int N,c=0;
    fin>>N;
    for(int d=2;d*d<=N;d++)
    {
        if(V[d]==0)
        {
            for(int j=d+d;j<=N;j+=d)
            {
                V[j]=1;
            }
        }
    }
    for(int d=2;d<=N;d++)
    {
        if(V[d]==0)
        {
            c++;
        }
    }
    fout<<c;
    return 0;
}
