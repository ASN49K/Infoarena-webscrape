#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int nMax=2e6+1;

int n, v[nMax], cnt;

int main()
{
    fin>>n;
    fin.close();

    v[0]=1;//0 nu este prim
    v[1]=1;//1 nu este prim
    for(int i=2; i*i<=n; i++)
        if(v[i]==0)
        for(int j=2; j<=n/i; j++)
        v[i*j]=1;

    for(int i=1; i<=n; i++)
        if(!v[i])
        cnt++;

    fout<<cnt;

    fout.close();
    return 0;
}
