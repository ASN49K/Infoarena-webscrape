#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
int v[10];
int main()
{
    int n,cnt=0;
    fin>>n;
    for (int i =2 ; i*i <= n ; i ++)
    {
        if(v[i]==0)
            for(int j = 2 ; j<= n/i; j++)
            {
                v[i*j]=1;
            }
    }
    for (int i = 2 ; i<= n; i++)
    {
        if (v[i]==0)
            cnt++;
    }
    cout<<cnt;
    return 0;
}
