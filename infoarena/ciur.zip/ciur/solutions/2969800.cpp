#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second
 
void solve(){
    int n;
    cin >> n;
    bool a[n+1];
    for(int i = 2; i <= n; i++)
        a[i] = 1;
    for(int i = 2; i * i <= n; i++){
        if(a[i]){
            for(int j = i * i; j <= n; j += i)
                a[j] = 0;
        }
    }
    int ans = 0;
    for(int i = 2; i <= n; i++)
        ans += a[i];
    cout << ans << '\n';
}  
 
int main(){
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}