#include <fstream>
#define MAX 2000002
using namespace std;
int n,ans;
bool ciur[MAX];

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    fin >> n;
    ciur[0] = ciur[1] = 1;
    for(int i = 2; i <= n; i++){
        if(ciur[i] == 0){
            ans++;
            for(int j = i+i; j <= n; j += i){
                ciur[j] = 1;
            }
        }
    }
    fout << ans << "\n";
    return 0;
}
