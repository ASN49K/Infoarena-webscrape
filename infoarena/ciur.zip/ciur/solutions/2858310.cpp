#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
int main()
{
    int n,counter=0;
    fin>>n;
    int a[n];
    for(int i=0;i<n;i++)
    {
        a[i]=0;
    }
    for(int i=2;i*i<=n;i++)
    {
        if(a[i-1]==0)
        {
           for(int j=2;j<=n;j++)
           {
                if(j%i==0 && j!=i)
                {
                    a[j-1]=1;
                }
           }
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(a[i]==0)
        {
            counter++;
        }
    }
    cout<<counter;
    return 0;
}
