#include <fstream>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
int n,cnt;
char prim[2000005];
int main(void)
{
    int i,j;
    f>>n;
    for (i=2;i<=n;++i)
        prim[i] = 1;
    for (i=2;i<=n;++i)
        if (prim[i])
        {
            ++cnt;
            for (j=i+i;j<=n; j+=i)
                prim[j] = 0;
        }
    g<<cnt;
    return 0;
}
