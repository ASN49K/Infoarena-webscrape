#include <fstream>

using namespace std;
const int Nmax=2000001;
bool ciur[Nmax];
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int main()
{
    int n;
    fin>>n;
    int cnt=n-1;
    for(int i=2; i*i<=n; i++)
    {
        if(ciur[i]==0)
        {
                for(int j=i*i; j<=n; j+=i)
                {
                    if(ciur[j]==0)
                    {
                        cnt--;
                    }
                    ciur[j]=1;
                }
        }
    }
    fout<<cnt;
    return 0;
}
