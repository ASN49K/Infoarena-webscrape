#include <bits/stdc++.h>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset<2000005> C;
int n,sol;

int main()
{
    int i,j;
    fin >> n;
    C[1]=1;
    sol=1;
    for(i=4;i<=n;i+=2) C[i]=1;
    for(i=3;i<=n;i+=2){
        if(C[i]==0){
            sol++;
            for(j=i*i;j<=n;j+=2*i){
                C[j]=1;
            }
        }
    }
    fout << sol;
    return 0;
}
