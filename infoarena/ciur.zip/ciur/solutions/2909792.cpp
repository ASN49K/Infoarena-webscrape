#include <bits/stdc++.h>
#define N 2000005
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
  int n, ciur[N]={0}, cnt=0;
  fin>>n;


  for(int i=2; i<=n; i++)
    if(ciur[i]==0)
    {
      ++cnt;
      for(int j=i*2; j<=n+1; j=j+i)
        ciur[j]=1;
    }
  fout<<cnt;

  return 0;
}
