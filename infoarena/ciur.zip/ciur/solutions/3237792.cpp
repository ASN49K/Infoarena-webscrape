#include <bits/stdc++.h>
using namespace std;

int dfs(int n){
    int ans = 0;
    int dp[n+1];
    memset(dp,1,sizeof(dp));
    for(int i = 2;i<=n;i++){
        if(dp[i]) {
            ans++;
            for(int j = 2*i;j<=n;j+=i) dp[j] = 0;
        }
    }
    return ans;
}

int main() {
   freopen("ciur.in","r",stdin);
    freopen("ciur.out","w",stdout);
    int n;
    cin >> n;
    cout << dfs(n);

    return 0;
}
