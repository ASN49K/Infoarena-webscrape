#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int IsPrime [1500];
vector <int> v;

void Ciur(){
    IsPrime[0] = 0;
    IsPrime[1] = 0;
    for (int i=2;i<=1500;++i){
        IsPrime[i] = 1;
    }
    for (int i=2;i<=1500;++i){
        if (IsPrime[i]==1){
            for (int j=2*i;j<=1500;j+=i){
                IsPrime[j] = 0;
            }
        }
    }
    for (int i=2;i<1500;++i){
        if (IsPrime[i]==1){
            v.push_back(i);
        }
    }
}

int IP(int n){
    int i = 0;
    int c = 1;
    while (v[i]<n){
        if (n%v[i]==0 and n!=v[i]){
            c = 0;
            break;
        }
        i += 1;
    }
    return c;
}

int main()
{
    Ciur();
    int n;
    fin >> n;
    int Raspuns = 0;
    for (int i=2;i<=n;++i){
        Raspuns += IP(i);
    }
    fout << Raspuns;
    return 0;
}
