#include <bits/stdc++.h>

#pragma optimize GCC ("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

const int NMAX=2e6+5;

bool prime[NMAX];
int kon;

void sieve(int n)
{
    int i,j;
    prime[1]=true;
    for(i=2;i<=n;i++)
    {
        if(!prime[i])
        {
            kon++;
            for(j=2*i;j<=n;j+=i)
                prime[j]=true;
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    int n,i,j;
    fin>>n;
    sieve(n);
    fout<<kon;
    fin.close();
    fout.close();
    return 0;
}
