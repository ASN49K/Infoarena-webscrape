#include <fstream>
#include <vector>

using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
int n, i, j, nr;

int main() {
    f >> n;
    vector<bool> sieve(n + 1, true);
    sieve[0] = sieve[1] = false;
    for (i = 4; i <= n; i += 2) sieve[i] = false;
    for (i = 3; i <= n; i += 2) {
        for (j = i; j * i <= n; j += 2) sieve[j * i] = false;
    }
    for (i = 2; i <= n; ++i)
        if (sieve[i]) ++nr;
    g << nr;
    return 0;
}
