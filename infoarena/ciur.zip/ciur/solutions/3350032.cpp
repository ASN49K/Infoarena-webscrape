#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int prime[200005];
int main(){
    int n, cnt =0;
    fin >> n;
    for(int i = 2; i <=n; i++){
        if(prime[i] == 0){
            cnt++;
            for(int j = 2*i; j<=n; j+=i) prime[j] = 1;
        }
    }
    fout << cnt;

    return 0;
}