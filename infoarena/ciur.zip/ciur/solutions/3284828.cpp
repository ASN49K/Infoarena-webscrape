#include <iostream>
#include <fstream>

using namespace std;
ifstream fcin("ciur.in");
ofstream fout("ciur.out");

int n, v[2000005], ctr;

int main()
{
    fcin>>n;
    v[0]=1;
    v[1]=1;
    for(int i=2; i<=n; i++)
    {
        if (v[i]==0)
        {
            ctr++;
            for(int j=i+i; j<=n; j+=i)
                v[j]=1;
        }
    }
    fout<<ctr;
}
