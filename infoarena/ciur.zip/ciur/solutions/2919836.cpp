#include<fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");
int n,cnt,v[2000002];
int main()
{
    cin>>n;
    v[1]=v[0]=1;
    for(int i=3; i<=n; i++)
    {
        if(i%2==0)
            v[i]=1;
        if(v[i]==0)
        {
            cnt++;
            for(int j=3; j*i<=n; j+=2)
                v[i*j]=1;
        }
    }
    cout<<cnt+1;
}
