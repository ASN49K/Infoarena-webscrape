#include <iostream>
#include <fstream>
#include <cmath>
#define N 2000000
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool c[2000005];
int ct, n;

void ciur()
{
	c[1] = 1;
	for (int i = 4; i <= N; i += 2)
		c[i] = 1;
	for (int i = 3; i * i <= N; i += 2)
		if (c[i] == 0)
			for (int j = i * i; j <= N; j += 2 * i)
				c[j] = 1;
}

int main()
{
	ciur();
	fin >> n;
	for (int i = 1; i <= n; i++)
		if (c[i] == 0) ct++;
	fout << ct;
	return 0;
}