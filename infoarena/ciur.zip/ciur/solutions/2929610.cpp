#include <iostream>
#include <fstream>

using namespace std;

const int maxn = 2000001;
bool ciur[maxn];

void eratostene() {
    ciur[0] = ciur[1] = 1;
    for (int i = 2; i * i < maxn; i++)
        if (!ciur[i])
            for (int j = i * i; j < maxn; j += i)
                ciur[j] = true;
}

int main() {
    eratostene();
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    int n;
    fin >> n;
    int nrprim = 0;
    for (int i = 2; i <= n; i++)
        nrprim += !ciur[i];
    fout << nrprim;

    return 0;
}