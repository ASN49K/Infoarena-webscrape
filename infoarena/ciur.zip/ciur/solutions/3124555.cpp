#include <iostream>

using namespace std;

bool erath[1000];

int main()
{
    int n;
    int cnt = 0;
    cin >> n;

    for(int div = 2;div*div<=n;div++){
        if(erath[div]==1){
            continue;
        }
        for(int multiplu = 2*div;multiplu<=n;multiplu+=div){
            erath[multiplu]=1;
        }

    }

    for(int i = 2;i<=n;i++){
            if(erath[i]==0){
                cnt++;
            }
        }

    cout << cnt;
    return 0;
}
