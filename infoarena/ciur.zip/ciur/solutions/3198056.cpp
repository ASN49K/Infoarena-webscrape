#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

const int MAX_SIZE = 2000000;

int eratosthenses(int n) {
	bool A[MAX_SIZE];
	int result = 0;
	for (int i = 2; i <= n; i++) {
		A[i] = true;
	}
	for (int i = 2; i <= sqrt(n); i++){
		if (A[i] == true) {
			for (int j = i + i; j <= n; j += i) {
				A[j] = false;
			}
		}
	}
	for (int i = 2; i <= n; i++) {
		if (A[i] == true)
			result++;
	}
	return result;
}

int main() {
	ifstream fin("ciur.in");
	ofstream fout("ciur.out");

	int n;
	fin >> n;

	fout << eratosthenses(n);
}