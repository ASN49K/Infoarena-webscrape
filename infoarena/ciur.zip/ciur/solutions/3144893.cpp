#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,rs=1;
char A[2000001];
int main(){
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");
    cin >> n;

    for(int i=3; i<=n; i+=2){
        int k;
        if(A[i] == 0){
            k=i;
            rs++;
            while(k+i <= n){
                k += i;
                A[k] = 1;
            }
        }
    }
    cout << rs;
}