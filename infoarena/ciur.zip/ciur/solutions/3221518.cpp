#include <fstream>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

int c[2000001];

int main()
{
    int n, i, j, cnt;
    cin >> n;
    cnt = n - 1;
    c[1] = 1;
    c[0] = 1;
    
    for (i = 2; i <= n; i++)
    {
        if (c[i] == 0)
        {
            for (j = 2; i * j <= n; c[i * j] = 1, j++)
            {
                if (c[i * j] == 0)
                    cnt--;
            }
        }
    }
    
    cout << cnt;
}