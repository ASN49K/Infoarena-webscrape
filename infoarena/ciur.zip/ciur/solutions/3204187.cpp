#include <iostream>
using namespace std;

int v[2000001];

void ciur (int n) {
    for (int i = 2; i <= n; ++i) {
        if (v[i] == 0){
            int j = 2;
            while (i * j <= n) {
                v[i * j] = 1;
                ++j;
            }
        }
    }
}


int main() {
    int n;
    cin >> n;
    ciur(n);
    int s = 0;
    for(int i = 2; i <= n; ++i) {
        if (v[i] == 0) {
            ++s;
        }
    }
    cout << s;
    return 0;
}
