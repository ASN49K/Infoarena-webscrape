#include <fstream>

using namespace std;

int n;
bool v[2000005];

ifstream cin ("ciur.in");
ofstream cout ("ciur.out");

int main() {
    cin >> n;
    v[1] = true;
    int cnt = 1;
    for (int i = 3; i <= n; i += 2) {
        if (v[i] == 0) {
            ++cnt;
            for (int j = i * i; j <= n; j += 2 * i) {
                v[j] = true;
            }
        }
    }
    cout << cnt;
    return 0;
}
