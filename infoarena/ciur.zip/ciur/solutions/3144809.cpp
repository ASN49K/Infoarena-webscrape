#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,rs, A[3000000];
int main(){
    cin >> n;
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");

    for(int k=2; k<=sqrt(n); k++){
        for(int i=2; i<=n; i++){
            if(A[i] == 0 && i%k == 0 && i!=k){
                A[i] = 1;
                // cout << i << ' ' << k << endl;
            }
        }
    }

    for(int i=2; i<=n; i++){
        if(A[i] == 0){
            rs++;
        }
    }

    cout << rs;
}