#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

string cuv;

int main()
{
    long long int N;
    cin>>N;

    if(N==1)
        cout<<0;
    else if(N==2||N==3||N==5||N==7)
        cout<<1;
    else if(N>=10)
    {
        int cnt=0;
        for(int d=2;d<=N;d++)
        {
            int eprim=1;
            for(int i=2;i*i<=d&&eprim==1;i++)
                if(d%i==0)
                eprim=0;
            if(eprim==1)
                cnt++;
        }
        cout<<cnt;
    }

}
