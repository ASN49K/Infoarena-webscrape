#include <fstream>
#include <iostream>

using namespace std;

int N, s, primes[2000001];
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main(){

    fin >> N;

    for(int i = 2; i <= N; ++i){
        primes[i] = 1;
    }

    primes[0] = 0;
    primes[1] = 0;

    for(int i = 2; i <= N; ++i){
        if(primes[i]){
            for(int j = 2; j * i <= N; ++j){
                primes[j * i] = 0;
            }
            s++;
        }
    }

    fout << s << "\n";

    return 0;
}