#include <iostream>
#include <fstream>
#define MAX 2000005
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,nr;
int ciur[MAX];
void eratostene()
{
    ciur[0]=1;
    ciur[1]=1;
    for(int i=4;i<MAX;i=i+2)
    {
        ciur[i]=1;
    }
    for(int i=3;i*i<MAX;i=i+2)
    {
        if(!ciur[i])
        {
            for(int j=i*i;j<MAX;j=j+(2*i))
            {
                ciur[j]=1;
            }
        }
    }
}
int main()
{
    fin>>n;
    eratostene();
    for(int i=2;i<=n;i++)
    {
        if(ciur[i]==0)
        {
            nr++;
        }

    }
    fout<<nr;
    return 0;
}
