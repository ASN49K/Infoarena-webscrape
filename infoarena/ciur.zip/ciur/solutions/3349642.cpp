#include <fstream>

int main()
{
   std::ifstream i("ciur.in");
   std::ofstream o("ciur.out");
   int n, s = 0;
   i >> n;
   n++;
   bool p[200001]={};
   for (int j = 2; j < n; j++)
      if (!p[j])
         for (int k = 2; j * k < n; k++)
            p[j * k] = 1;
   for (int j = 2; j < n; j++)
      if (!p[j])
         s++;
   o << s;
}