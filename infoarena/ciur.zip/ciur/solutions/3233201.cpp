#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream infile("ciur.in");
    ofstream outfile("ciur.out");

    if (!infile || !outfile) {
        cerr << "Error opening file" << endl;
        return 1;
    }

    int N;
    infile >> N;

    vector<bool> is_prime(N + 1, true);
    is_prime[0] = is_prime[1] = false;  // 0 and 1 are not prime numbers

    for (int i = 2; i * i <= N; ++i) {
        if (is_prime[i]) {
            for (int j = i * i; j <= N; j += i) {
                is_prime[j] = false;
            }
        }
    }

    int prime_count = 0;
    for (int i = 2; i <= N; ++i) {
        if (is_prime[i]) {
            prime_count++;
        }
    }

    outfile << prime_count << endl;

    infile.close();
    outfile.close();

    return 0;
}
