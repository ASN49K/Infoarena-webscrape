#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int MAX_SIZE = 20000000;
char markPrimeNumbers[MAX_SIZE + 1];

int main() {
    int n;
    fin >> n;
    int primeNo = 0;
    for (int i = 1; i <= n; i += 2) {
        if (markPrimeNumbers[i] != -1 && n != 1) {
            ++primeNo;
            for (long long j = i; i * j <= n && i != 1; j += 2) {
                markPrimeNumbers[i * j] = -1;
            }
        }
    }
    fout << primeNo;
    return 0;
}

