#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

#include "bits/stdc++.h"

using namespace std;

using ld = long double;
using ll = long long;
using ull = unsigned long long;

#if defined(ONPC)
#include "bits/debug.h"
#endif

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int mxN = 2e6 + 1;
bitset<mxN> prim;

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int N;
    fin >> N;
	
	int ans = 0;
	for (int i = 2; i <= N; ++i) {
		if (!prim[i]) {
			++ans;
			for (int j = i + i; j <= N; j += i) {
				prim[j] = true;
			}
		}
		
	}
    fout << ans << "\n";
}
