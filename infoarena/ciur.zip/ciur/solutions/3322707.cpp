#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
#define cin in
#define cout out
bool x[2000001];
int main()
{
    int n;
    cin>>n;
    x[0]=x[1]=0;
    for (int i=2; i<=sqrt(n); ++i)
    {
        if (x[i]==0)
        {
            for (int j=2; j*i<=n; ++j)
            {
                x[i*j]=1;
            }
        }
    }
    int  nr=0, a;
    for (int i=1; i<=n; ++i)
    {
        if (x[i]==0) nr++;
    }
    cout<<nr-1;
    return 0;
}
