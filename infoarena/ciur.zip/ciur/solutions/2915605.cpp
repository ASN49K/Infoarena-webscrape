#include <fstream>
#define N_max 2000001
using namespace std;
ifstream cin ("ciur.in");
ofstream cout ("ciur.out");
int cnt;
bool ciur[N_max];
void Eratostene()
{
    ciur[0]=ciur[1]=true;
    for(int i=4; i<=N_max; i+=2) ciur[i]=true;
    for(int i=3; i*i<=N_max; i+=2)
        if(!ciur[i])
            for(int j=i*i; j<=N_max; j+=2*i) ciur[j]=true;
}
int main()
{
    Eratostene();
    int n;
    cin>>n;
    for(int i=2; i<=n; ++i)
        cnt+=(ciur[i]==false);
    cout<<cnt;
}
