#include <stdio.h>
#include <stdlib.h>

int ciur[2000005];

int main() {
    int n;
    scanf("%d", &n);
    for(int i = 4; i <= n; i += 2)
        ciur[i] = 1;
    for(int i = 3; i * i < n; i += 2)
        for(int j = i * i; j <= n; j += 2 * i)
            ciur[j] = 1;
    int cnt = 1;
    for(int i = 3; i <= n; i += 2)
        if(ciur[i] == 0)
            cnt++;
    printf("%d\n", cnt);
    return 0;
}
