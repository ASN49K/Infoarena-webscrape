#include <bits/stdc++.h>

using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
int ciur[2000001];
int main()
{
 int n,cnt=0;
 fin>>n;
 for (int i=2; i<=n; i++)
 {
     if (ciur[i]==0)
     {
         cnt++;
         for (int j=i*i; j<=n; j+=i)
            ciur[j]++;
     }
 }
fout<<cnt;
    return 0;
}
