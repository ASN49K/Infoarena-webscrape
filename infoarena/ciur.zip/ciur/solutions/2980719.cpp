#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n;
bool v[2000005];

int cnt;

void Ciur()
{

    for(unsigned long long int i = 2; i <= n ; i++)
    {
        if(v[i] == 1)continue;
        else
            {
                cnt++;
                for(unsigned long long int j = i*i ; j<=n ; j+=i)
                    {
                        v[j] = 1;
                    }
            }

    }
}

int main()
{
    cin >> n;
    Ciur();
    cout << cnt;
    return 0;
}
