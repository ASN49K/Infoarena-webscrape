#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int j,i,k=0, a[2000001];
int main() {
    int n;
    fin>>n;
    for(i=2;i*i<=sqrt(n);i++)
    {
        if(a[i]==0)
        {
            
            for(j=i*i;j<n;j+=i)
            {
                
                a[j]=1;
            }
            
        }
        
    }
    
    for(i=2;i<=n;i++){
        if(a[i]==0) k++;}
    fout<<k<<endl;
    return 0;
}
