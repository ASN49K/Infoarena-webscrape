#include <bits/stdc++.h>
char ciur[250002];
int main() {
    int n;
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
    scanf("%d", &n);
    ciur[0] = 3;
    for(int i = 4; i <= n; i += 2)
        ciur[i >> 3] |= (1 << (i & 7));
    for(int i = 3; i * i <= n; i += 2)
        if((ciur[i >> 3] & (1 << (i & 7))) == 0)
            for(int j = i * i; j <= n; j += 2 * i)
                ciur[j >> 3] |= (1 << (j & 7));
    int sol = 0;
    for(int i = 2; i <= n; i++)
        sol += ((ciur[i >> 3] & (1 << (i & 7))) == 0);
    printf("%d\n", sol);

    return 0;
}
