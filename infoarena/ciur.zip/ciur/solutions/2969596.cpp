#include <bits/stdc++.h>
using namespace std;

#define ll long long
int main(){
	std::freopen("ciur.in" , "r", stdin);
	std::freopen("ciur.out" , "w", stdout);
	ll size;
	cin >> size;
    bool ciur[size] = {};
	ciur[0] = ciur[1] = true;
	ll rs = 0;

	for(ll i = 2 ; i < size; i++){
		if(ciur[i] == false){
			rs++;
			for(ll j = i * 2; j < size; j+= i){
				ciur[j] = true;
			}
		}
	}
	cout << rs;
	return 0;
	
}
