#include <fstream>


using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool erath[2000005];
int main()
{
    erath[0]=1; erath[1]=1;
    int n,nr=0;
    fin>>n;
    for(int div=2; div*div<=n; div++){
        if(erath[div]==1){
            continue;
        }
        for(int mul=2*div; mul<=n; mul+=div){
            erath[mul]=1;
        }
    }

    for(int i=1; i<=n; i++){
        if(erath[i]==0){
            nr++;
        }

    }
    fout<<nr;

    return 0;
}
