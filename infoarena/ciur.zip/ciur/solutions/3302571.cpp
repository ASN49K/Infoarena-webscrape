#include <iostream>
#include <bitset>
#include <fstream>
#include <math.h>

std::ifstream in{"ciur.in"};
std::ofstream out{"ciur.out"};

int N;

void eratosthones(int N)
{
    std::bitset<2000001> bit;
    bit[0] = bit[1] = 1;
    for(int i = 2; i*i<=N; i++)
    {
        if(bit[i] == 0)
        for(int j = i*i; j<=N; j+=i)
        {
            bit[j] = 1;
        }
    }
    out << N + 1 - bit.count();
}

int main()
{
    in >> N;
    eratosthones(N);
}