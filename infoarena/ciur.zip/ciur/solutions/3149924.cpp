#include <fstream>

using namespace std;

const int NMAX = 2e6;

int s[NMAX / 2 + 1];
constexpr int sieve() {
    for (int i = 3; i * i <= NMAX; i += 2) {
        if (s[i / 2]) continue;
        for (int j = i * i; j <= NMAX; j += 2 * i) s[j / 2] = 1;
    }
    for (int i = 3; i <= NMAX / 2; i += 2) s[i] += s[i - 1];

    const int _ = 0;
    return _;
}

const int _ = sieve();

int main() {
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");

    int n; cin >> n;
    if (n == 2) cout << 1 << '\n';
    else {
        int odd_not_primes = s[(n - 1) / 2] + 1;
        int even_not_primes = n / 2 - 1;
        cout << n - odd_not_primes - even_not_primes << '\n';
    }

    return 0;
}