#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    bool t[20000001];
    for (int i=0; i<n-1;i++) t[i]=1;
    for(int i=2;i<=n;i++){
        if(t[i-2]){
            for(int j=2;j<=sqrt(i);j++){
                 if(i%j==0){
                    t[i-2]=0;
                    break;
                 }
            }
            if(t[i-2]){
                for(int j=2*i-2;j<n-1;j+=i){
                    t[j]=0;
                }
            }
        }
    }
    for(int i=0;i<n-1;i++){
        if(t[i]){
            cout << i+2 << " ";
        }
    }
    return 0;
}
