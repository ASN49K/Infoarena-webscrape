#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
char ciur[2000005];
int main()
{
    int n,nr=0;
    fin >> n;
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            nr++;
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }


fout << nr;
}

