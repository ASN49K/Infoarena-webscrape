#include<iostream>
#include<fstream>
#include<math.h>
using namespace std;

int ciur[2000001];

long ciurul(long n)
{
	long count=0;
	for(long i = 2; i <= n; i++) {
        if(ciur[i] == 0) { 
        	count++;
            for(long j = 2 * i; j <= n; j =j + i) {
                ciur[j] = 1;
            }
        }
    }

    return count;
}

int main()
{	long n;
	ifstream fin("ciur.in");
	ofstream fout("ciur.out");
	fin>>n;
	fout<<ciurul(n);
	return 0;
}
