#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <time.h>

#pragma GCC optimize("O3")

#define is_set(x)  (bitmap[x>>6] & r[(x>>1) & 0x1f])
#define set_bit(x) (bitmap[x>>6] |= r[(x>>1) & 0x1f])

//#define is_set(x)  (bitmap[x>>6] & (1 << ((x>>1) & 0x1f)) )
//#define set_bit(x) (bitmap[x>>6] |= (1 << ((x>>1) & 0x1f)) )
 
int i, j, N, nr = 0, double_i;
unsigned int bitmap[31250];
unsigned int r[32];

struct timespec start, stop;

int main()
{ 
	freopen( "ciur.in", "r", stdin );
	freopen( "ciur.out", "w", stdout);  
    scanf("%d",&N);

    //clock_gettime( CLOCK_REALTIME, &start);
    r[0] = 1;
    for (i = 1; i < 32; i++) {
    	r[i] = (r[i-1]<<1);
	}

    for (i = 3; (j = i*i) <= N; i += 2) {
    	int do_work = ((!is_set(i) && set_bit(j)) ? 1 : 0);
        	
        if (!do_work) {
        	continue;
		}
		nr += do_work;
        j += (double_i = (i<<1));

        while (1) {
            if (j > N) {
                break;
            }
            nr += ((!is_set(j) && set_bit(j)) ? 1 : 0);
            j += double_i;
		}
    }
    //clock_gettime( CLOCK_REALTIME, &stop);
    //printf( "%d seconds %d nanoseconds\n", stop.tv_sec - start.tv_sec, stop.tv_nsec - start.tv_nsec);
 
    printf("%d\n", (N+1)/2 - nr);
    return 0;
}
