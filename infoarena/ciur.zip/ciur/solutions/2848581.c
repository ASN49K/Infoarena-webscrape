#include <stdio.h>
#include <stdlib.h>
//#include <unistd.h>
//#include <time.h>
 
#pragma GCC optimize("Ofast")
 
#define is_set(x)  (~a[x>>3] && (a[x>>3] & r[x & 0x7]))
#define set_bit(x) (a[x>>3] |= r[x & 0x7])
 
char r[8] = {0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80};
 
int main()
{
    int i, j, N, nr = 0;
    char a[250001] = {0};
    
    //struct timespec start, stop;
    
    //FILE *in=fopen("ciur.in","r");
    //FILE *out=fopen("ciur.out","w"); 
	freopen( "ciur.in", "r", stdin );
	freopen( "ciur.out", "w", stdout );  
    scanf("%d",&N);
 
    //clock_gettime( CLOCK_REALTIME, &start);
    for (i = 3; i*i <= N; i += 2) {
        if (!is_set(i)) {    
            for (j = i*i; j <= N; j += 2*i) {
                if (!is_set(j)) {
                	set_bit(j);
                	nr++;
				}
            }
        }                                    
    }
    /*clock_gettime( CLOCK_REALTIME, &stop);
    printf( "%d seconds %d nanoseconds\n", stop.tv_sec - start.tv_sec, stop.tv_nsec - start.tv_nsec);
    getchar();*/
 
    fprintf(out,"%d\n", (N+1)/2 - nr);
    fclose(in);
    fclose(out);
    
    return 0;
}
