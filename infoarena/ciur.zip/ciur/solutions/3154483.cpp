#include <iostream>
#include <fstream>

using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
bool a[2000000];

int main()
{
    int n;
    int t=0;
    f>>n;
    a[0]=1;
    a[1]=1;
    for (int i = 2; i < n; i++)
    {
        if(a[i] == 0)
        {
            t++;

            for(int j = i + i; j < n; j=j + i)
            {
                a[j] = 1;
            }
        }
    }
    g<<t;
    return 0;
}
