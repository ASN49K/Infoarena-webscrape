#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");
int ciur[2000000]; //Căutăm numerele prime până la 1000

int main()
{
    int suma = 0, n;
    fin >> n;
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) { //Am găsit un număr nemarcat (prim)
            //Marcăm multiplii lui i
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }

    //Afișăm pe ecran toate numerele prime găsite
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            suma++;
        }
    }
    fout << suma;
    return 0;
}
