#include <bits/stdc++.h>
using namespace std;
#define mx_size 2000000

int N,i,j;
bool A[mx_size+1];
vector <int> B;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool prim(int A)
{
    int nrd=0;
    for (int q=1;q<=sqrt(A);q++)
    {
        if (A%q==0) nrd+=2;
    }
    return nrd==2;
}

int main()
{
    fin >> N ;
    B.push_back(2);
    for (i=2;i<=N;i+=2)
    {
        A[i]=true;
    }
    for (i=3;i<=N;i++)
    {
        if (A[i]==false && prim(i)==true)
        {
            B.push_back(i);
            for (j=i;j<=N;j+=i)
            {
                A[i]=true;
            }
        }
    }
    fout << B.size()<<"\n";
    for (i=0;i<B.size();i++)
    {
        fout<<B[i]<<" ";
    }
    fout<<"\n";
    return 0;
}