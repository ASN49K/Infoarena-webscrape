#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int v[2000001];

void ciur (int n) {
    for (int i = 2; i <= n; ++i) {
        if (v[i] == 0){
            int j = 2;
            while (i * j <= n) {
                v[i * j] = 1;
                ++j;
            }
        }
    }
}


int main() {
    int n;
    fin >> n;
    ciur(n);
    int s = 0;
    for(int i = 2; i <= n; ++i) {
        if (v[i] == 0) {
            ++s;
        }
    }
    fout << s;
    return 0;
}
