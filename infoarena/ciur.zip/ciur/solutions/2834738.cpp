#include <fstream>

using namespace std;

const int NMAX = 2e6;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bool ciur[NMAX+1];
int n,c;
int main()
{

    fin >> n;

    for (int i = 2; i <= n; ++i)
            ciur[i] = true;

    for (int i = 2; i * i <= n; ++i)
            if (ciur[i])
                  for (int j = 2; i * j <= n; ++j)
                        ciur[i * j] = false;
    for(int i = 1; i <= n; ++i)
            if(ciur[i] == true)
                  c++;

    fout<<c;

    return 0;
}






