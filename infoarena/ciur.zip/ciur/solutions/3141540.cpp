#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bool IsPrime [2000002];
vector <int> v;

void Ciur(){
    IsPrime[0] = 0;
    IsPrime[1] = 0;
    for (int i=2;i<=2000000;++i){
        IsPrime[i] = 1;
    }
    for (int i=2;i<=2000000;++i){
        if (IsPrime[i]==1){
            for (int j=2*i;j<=2000000;j+=i){
                IsPrime[j] = 0;
            }
        }
    }
}

int main()
{
    Ciur();
    int n;
    fin >> n;
    int Raspuns = 0;
    for (int i=2;i<=n;++i){
        if (IsPrime[i]==1){
            Raspuns += 1;
        }
    }
    fout << Raspuns;
    return 0;
}
