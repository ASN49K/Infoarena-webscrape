#include <bits/stdc++.h>
using namespace std;
ifstream f("ciur.in");
ofstream g("ciur.out");
const int NMAX=2000002;
bool p[NMAX];
void ciur(int N)
{
    for(int i=2; i<=N; i++)
        if(p[i]==0)///daca i este prim(nu a fost marcat pana acum
    {
        for(int j=2*i;j<=N;j+=i)
             p[j]=1;
    }

    }
int main()
{
    int N;
    f>>N;
    ciur(N);
    int nrp=0;
    for(int i=2; i<=N; i++)
        if(p[i]==0)
            nrp++;
    g<<nrp;
    return 0;
}
