#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n, cnt;
char prim[2000005];

int main(void)
{
    fin>>n;
    for (int i = 2; i <=n; ++i)
        prim[i] = 1;
    for (int i = 2; i <= N; ++i)
        if (prim[i])
        {
            ++cnt;
            for (int j = i+i; j <= n; j += i)
                prim[j] = 0;
        }
    fout<<cnt;
    return 0;
}


