#include <fstream>
#include <cmath>
using namespace std;
ifstream in ("ciur.in");
ofstream out ("ciur.out");
int v[2000000];
int main()
{
    int n,k;
    in>>n;
     k=n-1;
    for(int i=2;i<=n;i++)
    {
        v[i]=i;
    }
    int g=sqrt(n);
    for(int i=2;i<=g;i++)
    {
        for(int j=2*i;j<=n;j++)
        {
            if(v[j]!=0 && v[i]!=0 && j%i==0)
            {
                v[j]=0;
                k=k-1;
            }
        }
    }

    out<<k;
    return 0;
}
