use std::io::{BufWriter, Write};
use std::fs::{File,self};

fn main() -> std::io::Result<()>{
    let n = fs::read_to_string("ciur.in")?.trim().parse::<usize>().unwrap();
    let mut writer = BufWriter::new(File::create("ciur.out")?);
    let mut freq : Vec <bool> = vec![false; n+1];
    freq[1] = true;
    freq[0] = true;
    for i in 2..n {
        if i*i > n {
            break;
        }
        if freq[i] {
            continue;
        }
        let mut j = i*i;
        while j <= n {
            freq[j] = true;
            j += i;
        }
    }
    write!(writer,"{}",freq.iter().filter(|&&x| !x ).count())?;
    Ok(())
}
