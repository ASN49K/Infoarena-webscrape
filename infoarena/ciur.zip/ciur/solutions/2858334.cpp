#i#include <fstream>
using namespace std;
ifstream in("ciur.in");
ofstream out("ciur.out");
bool v[20000001];
int main()
{
    int n,j,i,x=0;
    in>>n;
    for(i=2;i*i<=n;i++)
    {
        if(v[i]==0)
        for(j=i;j*i<=n;j++)
        {
            v[j*i]=1;
        }
    }
        for(i=2;i<=n;i++)
        if(v[i]==0)
        x++;
    out<<x;
return 0;
}
