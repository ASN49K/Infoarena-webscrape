#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n,i,j,cnt;
bool c[(int)2e6+10];

void ciur()
{
    c[0]=1;c[1]=1;

    for(i=2;2*i<=n;i++)
        if(c[i]==0)
            for(j=2*i;j<=n;j+=i)
                c[j]=1;
}
signed main()
{
    fin>>n;
    ciur();
    for(i=1;i<=n;i++)
        if(c[i]==0)cnt++;
    fout<<cnt;
    return 0;
}
