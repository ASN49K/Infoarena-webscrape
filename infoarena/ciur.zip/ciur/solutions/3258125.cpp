#include <fstream>
#include <bitset>

using namespace std;

const int NMAX = 2e6;

int main()
{
    ifstream in("ciur.in");
    ofstream out("ciur.out");
    bitset <NMAX+1> c;
    int n;
    in >> n;
    for (int d = 2; d * d <= n; d++)
    {
        if (!c[d])///d nu a fost marcat, deci este prim
        {
            for (int m = d * d; m <= n; m += d)
            {
                c[m] = 1;
            }
        }
    }
    int nr = 0;
    for (int i = 2; i <= n; i++)
    {
        if (!c[i])
        {
            nr++;
        }
    }
    out << nr;
    in.close();
    out.close();
    return 0;
}
