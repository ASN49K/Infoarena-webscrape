#include <fstream>
using namespace std;
ifstream cin("ciur.in");
ofstream cout("ciur.out");

int nr, n, ciur[1001];

int main()
{
    cin>>n;
    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            for(int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }

    for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) {
            nr++;
        }
    }

    cout<<nr;
    cin.close();
    cout.close();
    return 0;
}
