#include <bits/stdc++.h>

using namespace std;

ifstream f ("ciur.in");
ofstream g ("ciur.out");

const int nmax = 2e7 + 3;

int n, sol = 1;
bool v[nmax];

int main()
{
    f >> n;

    for (int i = 3; i <= 5; i += 2)
    {
        if (v[i])
            continue;
        ++sol;

        if (1ll * i * i > n)
            continue;

        for (int j = i * i; j <= n; j += i)
            v[j] = 1;
    }

    g << sol;

    return 0;
}
