#include <iostream>
#include <fstream>
#include <bitset>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset <2000005> ciur;

void Eratostene(int n)
{
    ciur[0] = 1;
    ciur[1] = 1;
    for(int i = 2; i <= n; i++)
        if(ciur[i] == 0)
        {
            for(int j = 2 * i; j <= n; j += i)
                ciur[j] = 1;
        }
}

int main()
{
    int n, nr = 0;
    fin >> n;
    Eratostene(n);
    for(int i = 1; i <= n; i++)
        if(ciur[i] == 0)
            nr++;
    fout << nr;
    return 0;
}
