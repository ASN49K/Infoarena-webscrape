#include <iostream>

using namespace std;
const int N=2000000+2;
bool v[N];
int main()
{
    freopen ("ciur.in", "r", stdin);
    freopen ("ciur.out", "w", stdout);

    int n,p=0;
    cin>>n;
    v[2] = 1;

    for (int i=3;i<=n;i+=2)
    {
        v[i] = 1;
    }

    for (int i=3;i<=n;i+=2)
    {
        if (v[i] == 1)
        {
            for (int j=3*i;j<=n;j+=2*i)
            {
                v[j] = 0;
            }
        }
    }
    for (int i=2;i<=n;i++)
    {
       if (v[i] == 1)
       {
           p++;
       }
    }
    cout<<p;
}
