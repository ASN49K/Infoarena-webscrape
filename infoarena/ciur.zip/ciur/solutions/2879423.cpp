#include <fstream>
using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

int n, v[2000001], sol;

int main() {
  for (int i = 2; i * i <= 2000000; ++i)
    if (v[i] == 0)
      for (int j = i * i; j <= 2000000; j += i)
        v[j] = 1;
        
  cin >> n;
  for (int i = 2; i <= n; ++i)
    if (v[i] == 0)
      ++sol;
        
  cout << sol;
        
  cin.close();
  cout.close();
  return 0;
}
