#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool prim[2000002];
int n, ct = 0;
int main()
{
    fin >> n;
    for(int i = 2; i <= n; i++)
    {
        if(prim[i] == 0)
        {
            ct++;
            for(int j = 2 * i; j <= n; j += i)
                prim[j] = 1;
        }
    }
    fout << ct;
    return 0;
}
