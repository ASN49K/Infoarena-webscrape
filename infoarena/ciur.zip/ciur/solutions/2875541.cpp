#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int number;
bool v[2000001];

int ciur (int number) {
    int number_prim = 0;
    for (int i = 2; i <= number; ++i) {
        if (v[i] == 0) {
            ++number_prim;
            for (int j = i * i; j <= number; j += i) {
                v[j] = 1;
            }
        }
    }
    return number_prim;
}

int main() {
    cin >> number;
    cout << ciur(number);
    return 0;
}