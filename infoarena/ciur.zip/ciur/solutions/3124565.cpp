#include <iostream>
#include <fstream>
#include <cmath>
#include <stdbool.h>

using namespace std;

const int N = 2e6;
ifstream in("ciur.in");
ofstream out("ciur.out");

bool ciur[N];
int main()
{
    int n , cnt=0;
    in >> n;
    ciur[0] = true;
    ciur[1] = true;
    for(int div = 2; div <= sqrt(n) ; div++)
    {
        if(ciur[div])
        {
            continue;
        }
        for(int mul = 2 * div  ; mul <= n ; mul += div)
        {
            ciur[mul] = true;
        }
    }
    for(int i = 1 ; i <= n ; i++)
    {
        if(!ciur[i])
        {
            cnt++;
        }
    }
    out << cnt;
    return 0;
}
