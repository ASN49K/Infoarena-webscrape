#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

string cuv;

int ciur[200001];

int main()
{
    long long int N,cnt=0;
    cin>>N;

    ciur[1]=1;

    for(int div=2;div*div<=N;div++)
        if(ciur[div]==0)
        {
            for(int mult=2*div;mult<=N;mult+=div)
                ciur[mult]=1;
        }
     for(int i=2;i<=N;i++)
        if(!ciur[i])
            cnt++;
     cout<<cnt;
}
