#include <fstream>
#include <bitset>

using namespace std;

const int VMAX = 2e6;

int main()
{
    ifstream in("ciur.in");
    ofstream out("ciur.out");
    bitset <VMAX+1> c;
    for (int d = 2; d * d <= VMAX; d++)
    {
        if (!c[d])
        {
            for (int multiplu = d * d; multiplu <= VMAX; multiplu += d)
            {
                c[multiplu] = 1;
            }
        }
    }
    int n, nrp = 0;
    in >> n;
    for (int i = 2; i <= n; i++)
    {
        if (!c[i])
        {
            nrp++;
        }
    }
    out << nrp << "\n";
    in.close();
    out.close();
    return 0;
}
