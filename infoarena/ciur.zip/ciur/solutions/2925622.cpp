#include<bits/stdc++.h>
using namespace std;
int n,i,j;
bitset<2000001> p;
int main()
{
    for(ifstream("ciur.in")>>n,i=3;i*i<=n;i+=2)
        if(!p[i])
            for(j=i*i;j<=n;p[j]=1,j+=2*i);
    return ofstream("ciur.out")<<(n+1)/2-p.count(),0;
}
