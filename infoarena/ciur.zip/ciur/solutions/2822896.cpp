#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n;
bool prime[2000001];

int kPrime(int n, bool prime[])
{
    int k = 0;
    for(int i = 2; i <= n; i++)
        prime[i] = 1;
    for(int i = 2; i <= n; i++)
        if(prime[i])
        {
            k++;
            for(int j = 2*i; j <= n; j += i)
                prime[j] = 0;
        }
    return k;
}

int main()
{
    fin >> n;
    fout << kPrime(n, prime);

    return 0;
}
