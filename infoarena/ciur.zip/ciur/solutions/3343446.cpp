#include <bits/stdc++.h>
using namespace std;
# define ll long long


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");

    int n;
    cin>>n;
    vector<bool> isPrime(n+1,1);

    for(int i = 2; i*i <= n; i++){
        if(isPrime[i]){
            for(int j = i*i; j <= n; j+=i){
                isPrime[j] = 0;
            }
        }
    }
    int ans = 0;
    for(int i = 2; i < n; i++){
        if(isPrime[i]){
            ans++;
        }
    }

    cout<<ans;








    return 0;
}
