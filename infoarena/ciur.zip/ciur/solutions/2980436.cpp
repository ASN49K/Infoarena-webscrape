#include <bits/stdc++.h>

#define MAX 2000000

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bitset <MAX + 5> ciur;

int n, ans = 1;

int main()
{
    fin >> n;
    ciur[0] = ciur[1] = 1;
    for(int i = 4; i <= n; i += 2)
        ciur[i] = 1;
    for(int i = 3;i <= n; i += 2)
    {
        if(!ciur[i])
        {
            ans++;
            for(int j = i + i + i;j <= n; j += i << 1)
                ciur[j] = 1;
        }
    }
    fout << ans;
}
