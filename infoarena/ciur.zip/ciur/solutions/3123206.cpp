#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool erath[2000009];


int main()
{
    int n,rasp=0;
    fin>>n;

    for(int div=2;div*div<=n;div++){
        if(erath[div]==true){
            continue;
        }
        for(int mul=2*div;mul<=n;mul+=div){
            erath[mul]=1;
        }
    }
    for(int i=2;i<=n;i++)
        if(erath[i]!=1)
            rasp++;

    fout<<rasp;
    return 0;
}
