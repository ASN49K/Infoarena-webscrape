#include <iostream>
#include <cstring>

using namespace std;

bool prime[50000005];

int getPrimes(int n) {
  int cnt = 0;
  memset(prime, true, sizeof(prime));
  
  for(int i = 2; i * i <= n; ++i) {
      if(prime[i]) {
          for(int j = i * i; j <= n; j += i) prime[j] = false;
      }
  }
  
  for(int i = 2; i <= n; ++i)
    if(prime[i]) cnt++;
    
  return cnt;
}

int main() {
    int n;
    cin >> n;
    
    cout << getPrimes(n);
}