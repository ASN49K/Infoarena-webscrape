#include <bits/stdc++.h>
#define NMAX 2000005

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bitset <NMAX> ciur;

void solve(int n)
{
    ciur[0] = ciur[1] = 1;
    for (int i = 2; i * i <= n; ++i)
        if (ciur[i] == 0)
            for (int j = i * i; j <= n; j += i)
                ciur[j] = 1;

    int cnt = 0;
    for (int i = 2; i <= n; ++i)
        if (ciur[i] == 0)
            ++cnt;

    fout << cnt << '\n';
}

int main()
{
    int n;
    fin >> n;
    solve(n);
    return 0;
}
