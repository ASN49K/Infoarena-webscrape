/*
       0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17
ciur = 1 1 0 0 1 0 1 0 1 1  1  0  1  0  1  1  1  0

ciur[i] = 0 daca i este prim / 1 daca i nu e prim 

*/

#include <iostream>
#include <fstream>

using namespace std;

vector<bool> compute_ciur(int n) {
	vector<bool> ciur(n + 1);
	ciur[0] = ciur[1] = true;

	for (int i = 2; i <= n; i++) {
		if (ciur[i] == false) {
			for (int j = i * 2; j <= n; j += i) {
				ciur[j] = true;
			}
		}
	}

	/*
	n = 100000
	pt j fixat, cate i-uri il marcheaza?
	j = 30, de cate ori facem ciur[30] = true?
		
	i = 2:
		j = 4, 6, 8, 10, 12, ..., 50, 52, ...

	*/

	// O(N * log(log(N)))

	return ciur;
}

int main() {
	ifstream cin("ciur.in");
	ofstream cout("ciur.out");

	int n; cin >> n;
	vector<bool> ciur = compute_ciur(n);

	int cnt = 0;
	for (int i = 0; i <= n; i++) {
		cnt += (ciur[i] == false);
		// cout << i << " " << ciur[i] << "\n";
	}

	cout << cnt << "\n";
	return 0;
}
