#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

int IsPrime [1505];
vector <int> v;

void Ciur(){
    IsPrime[0] = 0;
    IsPrime[1] = 0;
    for (int i=2;i<=1500;++i){
        IsPrime[i] = 1;
    }
    for (int i=2;i<=1500;++i){
        for (int j=2*i;j<=1500;j+=i){
            IsPrime[j] = 0;
        }
    }
    for (int i=2;i<1500;++i){
        if (IsPrime[i]==1){
            v.push_back(i);
        }
    }
}

int main()
{
    Ciur();
    int n;
    fin >> n;
    int i = 0;
    while(v[i]<=n){
        i += 1;
    }
    fout << i;
    return 0;
}
