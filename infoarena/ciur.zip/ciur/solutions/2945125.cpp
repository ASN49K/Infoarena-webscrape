#include<iostream>
#include<fstream>
#include<math.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
bool ciur[2000001];

long ciurul(long n)
{	long i,j,count=0;
	for(i = 2; i <= n; i++) {
        if(ciur[i] == 0) { 
        	count++;
            for(j = 2 * i; j <= n; j =j + i) {
                ciur[j] = 1;
            }
        }
    }
    return count;
}

int main()
{	long n;
	fin>>n;
	fout<<ciurul(n);
	return 0;
}
