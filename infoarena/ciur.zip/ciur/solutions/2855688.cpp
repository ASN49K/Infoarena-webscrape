#include <fstream>
#include <iostream>
#define N 2000000
#define M 150000
using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

bool c[N+5];
int d[M], m;

void ciur()
{
    c[2]=1;
    for (int i=3; i<=N; i+=2) c[i]=1;
    for (int i=3; i*i<=N; i+=2)
        if (c[i]==1)
            for (int j=i*i; j<=N; j+=2*i) c[j]=0;
    d[++m]=2;
    for (int i=3; i<=N; i+=2)
        if (c[i]) d[++m]=i;
}

int main()
{
    ciur();
    int n;
    fin>>n;
    int st=1, dr=m, mij;
    while (st<=dr)
    {
        mij=(st+dr)/2;
        if (d[mij]==n) {fout<<mij; return 0;}
        else if (n<d[mij]) dr=mij-1;
             else st=mij+1;
    }
    fout<<dr;
    return 0;
}
