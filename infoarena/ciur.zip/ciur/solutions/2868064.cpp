﻿
#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ciur.in");
ofstream o("ciur.out");

int main()
{
    int ciur[2000005] = {0},k=0,n; 

    f >> n;
    for (int i = 2; i <= n; i++) {
        if (ciur[i] == 0) { 
            
            for (int j = 2 * i; j <= n; j += i) {
                ciur[j] = 1;
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        if (ciur[i] == 0) {
            k++;
        }
    }
    o << k;
    return 0;


}
