#include <fstream>

using namespace std;

ifstream cin("ciur.in");
ofstream cout("ciur.out");

const int m = 2e6+5;

int v[m];

int main() {
    int n;
    cin >> n;
    v[0] = 1;
    v[1] = 1;
    int cnt = 0;
    for (int i = 2; i <= n; ++i) {
        if (v[i] == 0) for (int j = i+i; j <= n; j += i)
            v[j] = 1;
        if (v[i] == 0)
            ++cnt;
    }
    cout << cnt;

    return 0;
}