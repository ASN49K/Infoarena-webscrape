#include <bits/stdc++.h>

using namespace std;

const int max_size = 2e6 + 20;

bool ciur[max_size];
int ans;

void ciuru (int n)
{
    ciur[0] = 1;
    ciur[1] = 1;
    for (int i = 2; i <= n; i++)
    {
        if (ciur[i] == 1)
        {
            continue;
        }
        ans++;
        for (int j = 2 * i; j <= n; j += i)
        {
            ciur[j] = 1;
        }
    }
}

void solve ()
{
    int n;
    cin >> n;
    ciuru(n);
    cout << ans;
    cout << '\n';
}

signed main ()
{
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("ciur.in", "r", stdin);
    freopen("ciur.out", "w", stdout);
#endif // LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long tt;
    //cin >> tt;
    tt = 1;
    while (tt--)
    {
        solve();
    }
    return 0;
}
