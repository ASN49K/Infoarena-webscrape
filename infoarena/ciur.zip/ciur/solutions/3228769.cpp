#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool isNotPrime[2000001];

void buildSieve(int n) {
    isNotPrime[0] = isNotPrime[1] = true;
    for (int i = 4; i <= n; i += 2) {
        isNotPrime[i] = true;
    }
    for (int i = 3; i * i <= n; i += 2) {
        if (!isNotPrime[i]) {
            for (int j = i + i; j <= n; j += i) {
                isNotPrime[j] = true;
            }
        }
    }
}

int main() {
    int n;
    fin >> n;

    buildSieve(n);

    int cnt = 0;
    for (int i = 2; i <= n; ++i) {
        if (!isNotPrime[i]) {
            ++cnt;
        }
    }
    fout << cnt;
    return 0;
}