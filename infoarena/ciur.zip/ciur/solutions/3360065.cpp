#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n, nrprime;

int main()
{
    fin>>n;
    bool v[n+1];
    for(int i=1; i<=n; i++)
        v[i]=0;
    v[1]=1;
    for(int i=2; i*i<=n; i++)
        if(v[i]==0)
            for(int j=i*i; j<=n; j+=i)
                v[j]=1;
    for(int i=2; i<=n; i++)
        if(v[i]==0)
        nrprime++;
    fout<<nrprime;
    fin.close();
    fout.close();
    return 0;
}
