#include<stdio.h>
#include<algorithm>
using namespace std;

FILE*fin, *fout;

int n;
bool prim[2'000'000];

int main() {
    fin = fopen("ciur.in", "r");
    fout = fopen("ciur.out", "w");
    fscanf(fin, "%d", &n);
    int cnt = 0;
    fill(prim+2, prim+2000000, true);
    for(int i = 2; i <= n; ++i) {
        if(prim[i]){
            ++cnt;
            for(int j = 2*i; j <= n; j+=i)
                prim[j] = false;
        }
    }
    fprintf(fout, "%d", cnt);
}