#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int cnt_sieve(int n)
{
    bool is_prime[n / 2 + 1];
    fill(is_prime, is_prime + n / 2 + 1, true);
    is_prime[0] = false;
    for (int i = 3; i <= n; i += 2)
    {
        int bit_idx = i / 2;
        if (is_prime[bit_idx])
        {
            for (int j = 3; j * i <= n; j += 2)
            {
                int mult_bit_idx = (i * j) / 2;
                is_prime[mult_bit_idx] = false;
            }
        }
    }
    int cnt = 0;
    for (int i = 1; i <= n; i += 2){
        cnt += is_prime[i / 2];
    }
    return cnt + 1; // add 2
}

int main()
{
    int n;
    fin >> n;
    fout << cnt_sieve(n);
    return 0;
}