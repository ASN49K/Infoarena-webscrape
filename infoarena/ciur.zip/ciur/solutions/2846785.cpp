#include <iostream>
#include<fstream>
#include<vector>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
vector<bool> isThere;
int main()
{
    int n;
    fin>>n;
    isThere = vector<bool> (n + 1);
    int totNumbers = n - 1;
    for(int j = 4; j <= n; j += 2)
        if(isThere[j] == false)
        {
            isThere[j] = true;
            --totNumbers;
        }
    for(int i = 3; i <= n; i += 2)
    {
        if(isThere[i] == false)
        {
            for(int j = i + i; j <= n; j += i)
            {
                if(isThere[j] == false)
                {
                    isThere[j] = true;
                    --totNumbers;

                }
            }
        }
    }
    fout<<totNumbers;
    return 0;
}
