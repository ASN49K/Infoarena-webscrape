#include <iostream>
#include <fstream>

using namespace std;

ifstream in("ciur.in");
ofstream out("ciur.out");

bool v[2000000];
long long copac;

int main()
{
	long long n;
	in >> n;
	for (int i = 2; i*i <= n; i++)
	{
		if(!v[i]){
			for (int j = 2 * i; j <= n; j += i)
			{
				v[j] = 1;
			}
		}
			
	}
	for (int i = 2; i <= n; i++)
	{
		if (!v[i])
		{
			copac++;
		}
	}
	out << copac;
	return 0;
}
