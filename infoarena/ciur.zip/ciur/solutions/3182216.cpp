#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout("ciur.out");
const int N=2000000;
bool ciur[N+1];
int cnt=0;
void implciur(int n){
    int j,d;
    for(d=2;d*d<=n;d++){
        if(ciur[d]==0){
            for(j=d*d;j<=n;j+=d){
                ciur[j]=1;
            }
        }
    }
}
int main()
{
    int n;
    fin>>n;
    cnt=0;
    implciur(n);
    for(int i=2;i<=n;i++)
        if(ciur[i]==0)
            cnt++;
    fout<<cnt;
    return 0;
}
