#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
int n,i,v[2000000],h,j;
int main()
{
    fin>>n;
    for(i=2;i<=n/2;i++)
        for(j=2;i*j<=n;j++)
            v[i*j]=1;
    for(i=2;i<=n;i++)
        if(v[i]==0)
            h++;
    fout<<h;
    return 0;
}
