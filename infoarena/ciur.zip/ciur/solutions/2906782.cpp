#include<iostream>
#include<fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n, cnt = 0;
    fin >> n;
    int v[n];

    for(int i = 2; i <= n; i++)
        for(int j = i * i; j <= n; j += i)
            v[j] = 1;

    for(int i = 2; i <= n; ++i)
        if(v[i] == 0)
            cnt++;

    fout << cnt;

    return 0;
}