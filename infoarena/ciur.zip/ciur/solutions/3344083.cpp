#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int VMAX = 2e6;
int p[VMAX+1];

void ciuruletz_smecher()
{

    for (int i = 2; i*i<=VMAX; i++)
    {
        if(!p[i])
            for (int j = i*i; j<=VMAX; j+=i)
            {
                p[j] = 1;
            }
    }

    for (int i = 2; i<=VMAX; i++){
        p[i]=p[i-1]+!p[i];
    }
}

int main(){
    int n;
    fin>>n;
    ciuruletz_smecher();
    fout<<p[n];
}

