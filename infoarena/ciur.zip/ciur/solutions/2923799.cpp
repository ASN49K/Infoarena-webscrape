#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
int n,i,j,cnt;
bool ciur[2000010];
int main()
{
    fin>>n;
    ciur[2]=1;
    cnt=1;
    for(i=3;i<=n;i+=2)
        if(ciur[i]==0)
        {
            for(j=2;j*i<=n;j++)
                ciur[j*i]=1;
            cnt++;
        }
    fout<<cnt;
    return 0;
}
