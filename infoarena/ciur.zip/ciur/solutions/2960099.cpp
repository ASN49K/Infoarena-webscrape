#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n, contor = 0, adv = 0;
    fin >> n;
    for(int i = n; i > 1; --i) {
        for(int j = 2; j < i; ++j) {
            if(i % j == 0) {
                adv++;
            }
        }
        if(adv == 0) {
            contor++;
        }
        else {
            adv = 0;
        }
    }
    fout << contor;
    return 0;
}
