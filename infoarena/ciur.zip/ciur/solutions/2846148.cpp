#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");
const int MOD=1999999973;
const int NMAX=2e6;
bitset<NMAX+5>toate;
void ciur(){
    toate[0]=toate[1]=0;
    for(int i=2;i<=NMAX;i++)toate[i]=1;
    for(int i=2;i*i<=NMAX;i++){
        if(toate[i])
            for(int j=1ll*i*i;j<=NMAX;j+=i)
                toate[j]=0;
    }
}
int main(){
    ciur();
    int n,cnt(0);
    fin >> n;
    for(int i=1;i<=n;i++){
        if(toate[i])cnt++;
    }
    fout<<cnt;
    return 0;
}
