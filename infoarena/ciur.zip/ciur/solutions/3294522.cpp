#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    int n;
    fin >> n;
    int *v = (int*)calloc(n+1, sizeof(int));
    int cnt = 0;
    for(int i = 2; i <= n; i++)
    {
        if(v[i] == 0)
        {
            cnt++;
            for(int j = i; i * j <= n; j++)
            {
                v[i * j] = 1;
            }
        }
    }
    fout << cnt;
    fin.close();
    fout.close();
    return 0;
}
