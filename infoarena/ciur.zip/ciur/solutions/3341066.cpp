#include <fstream>

#define NMAX (1U << 21)

int sieve[NMAX];

int main()
{
    int n;
    int cnt = 0;
    std::ifstream fin("ciur.in");
    std::ofstream fout("ciur.out");

    fin >> n;

    for (int i = 2; i <= n; ++i)
        sieve[i] = 1;
    
    for (int i = 2; i <= n; ++i)
        if (sieve[i]) {
            for (int j = i + i; j <= n; j += i)
                sieve[j] = 0;

            ++cnt;
        }

    fout << cnt << '\n';

    fin.close();
    fout.close();

    return 0;
}
