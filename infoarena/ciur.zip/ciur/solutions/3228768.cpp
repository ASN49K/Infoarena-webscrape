#include <fstream>

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

bool prim(int x) {
    if (x < 2) {
        return false;
    }
    if (x == 2) {
        return true;
    }
    if (x % 2 == 0) {
        return false;
    }

    for (int divisor = 3; divisor * divisor <= x; divisor += 2) {
        if (x % divisor == 0) {
            return false;
        }
    }
    return true;
}

int main() {
    int n;
    fin >> n;

    int cnt = 0;
    for (int i = 2; i <= n; ++i) {
        if (prim(i)) {
            ++cnt;
        }
    }
    fout << cnt;
    return 0;
}