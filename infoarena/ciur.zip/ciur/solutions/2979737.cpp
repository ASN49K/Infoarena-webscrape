#include<bits/stdc++.h>
using namespace std;
int main()
{
    ifstream fin;
    fin.open("ciur.in");
    ofstream fout;
    fout.open("ciur.out");
    long long n;
    fin >> n;
    short int arr[n+20];
    for(int i = 1; i <= n; i++)
    {
        arr[i] = 0;
    }
    arr[0] = 1;
    arr[1] = 1;
    for(long long i = 2; i < (n+1)/2; i++)
    {
        if(arr[i] == 0)
        {
            long long current = i*2;
            while(current <= n)
            {
                arr[current] = 1;
                current+=i;
            }
        }
    }
    int out = 0;
    for(long long i = 2; i <= n; i++)
    {
        if(arr[i] == 0)
        {
            out++;
        }
    }
    fout << out;
}
