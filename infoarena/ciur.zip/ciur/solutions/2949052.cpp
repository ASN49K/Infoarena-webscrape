#include <bits/stdc++.h>

using namespace std;

const int NMAX = 2000005;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int N;
int rasp;
bool ciur[NMAX];
int main()
{
    fin >> N;

    ciur[1] = 1;
    long long patrat;
    for (int i = 2 ; i * i <= NMAX ; ++ i)
    {
        if (ciur[i] == 0) // prim
        {
            for (int j = i * i ; j <= NMAX ; j += i)
            {
                ciur[j] = 1; // nu e prim
            }
        }
    }

    for (int i = 1 ; i <= N ; ++ i)
    {
        if (ciur[i] == 0) rasp ++;
    }
    fout << rasp;
    return 0;
}
