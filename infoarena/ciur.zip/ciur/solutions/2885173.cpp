#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

#define DIM 2000000

int n;
bool ciur[DIM + 1];

//0 = prim
//1 = neprim;
static inline void Eratostene(int n) {
  ciur[0] = ciur[1] = 1;
  for(int i = 4; i <= n; i += 2)
    ciur[i] = 1;    //numerele pare nu sunt prime;

  for(int i = 3; i * i <= n; i += 2)
    if(!ciur[i])  //daca e prim ii marchez toti multiplii;
      for(int j = i * i; j <= n; j += i)
        ciur[j] = 1;
}

int main() {
  fin >> n;

  Eratostene(n);

  int nrprime = 0;
  for(int i = 2; i <= n; i++)
    nrprime += (ciur[i] == 0);
  fout << nrprime;

  return 0;
}