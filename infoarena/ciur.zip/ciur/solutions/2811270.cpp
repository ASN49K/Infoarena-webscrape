#include <iostream>
#include <fstream>
using namespace std;

int number_of_prime_numbers(int n) {
    int counter = 0, primality_of_numbers[2000001];
    for (int i = 2; i * i <= n; i++) {
        if (primality_of_numbers[i] == 0) {
            ++counter;
            for (int j = 2; j * i <= n; j++) {
                ++primality_of_numbers[j * i];
            }
        }
    }
    return counter;
}

int main() {
    ifstream fin("ciur.in");
    ofstream fout("ciur.out");
    int n;
    fin >> n;
    fout << number_of_prime_numbers(n);
    return 0;
}
