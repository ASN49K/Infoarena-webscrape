#include <iostream>
#include <fstream>

#define int long long

using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

const int NMAX = 2e6;

int c, ciur[NMAX * 2];

signed main()
{
    int n;
    fin >> n;

    ciur[0] = 1;
    ciur[1] = 1;

    for(int i = 2; i <= n; i++)
        for(int j = 2; i * j <= n; j++)
            ciur[i * j] = 1;

    for(int i = 1; i <= n; i++)
        if(ciur[i] == 0)
            c++;

    fout << c;

    return 0;
}
