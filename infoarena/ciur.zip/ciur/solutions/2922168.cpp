#include <fstream>

using namespace std;

int main()
{
    ifstream cin("ciur.in");
    ofstream cout("ciur.out");


    int n;
    cin>>n;
    if (n < 2 || n > 2000000)
        return 1;
    int A[n + 1];

    A[2] = 2;

    for (int i = 2, lim = n + 1; i < lim; i++)
    {
        for (int j = i + 1; j < lim; j++)
        {
            if (j % i == 0)
            {
                A[j] = -1;
            }
            else if (A[j] != -1)
            {
                A[j] = j;
            }
        }
    }

    int cnt = 0;

    for (int i = 2, lim = n + 1; i < lim; i++)
    {
        if (A[i] != -1)
            cnt++;
    }
    cout<<cnt;

    cin.close();
    cout.close();

    return 0;
}