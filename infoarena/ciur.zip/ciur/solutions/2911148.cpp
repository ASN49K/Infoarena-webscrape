#include <bits/stdc++.h>
using namespace std;
#define mx_size 2000000
int N,i,j,k;
bool A[mx_size+1];
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int main()
{
    fin >> N ;
    for (i=2;i<=N;i+=2)
    {
        A[i]=true;
    }
    for (i=2;i<=N;i++)
    {
        if (A[i]==true){
            for (j=i*i;j<=N;j+=i)
            {
                k++;
                A[i]=false;
            }
        }
    }
    fout << k<<"\n";
    return 0;
	
}