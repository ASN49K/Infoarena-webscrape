#include <bits/stdc++.h>
using namespace std;
ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n, prim[2000001];

void Ciur(int nr)
{
    int i, j;
    for (i = 1 ; i <= nr ; i++)
        prim[i] = 1;
    prim[0] = prim[1] = 0;
    for (i = 2 ; i * i <= nr ; i++)
        if (prim[i] == 1)
            for (j = i * i ; j <= nr ; j += i)
                prim[j] = 0;
}

int main()
{
    int i, cnt = 0;
    fin >> n;
    Ciur(n);
    for (i = 1 ; i <= n ; i++)
        if (prim[i] == 1)
            ++cnt;
    fout << cnt;
    return 0;
}
