#include <fstream>

using namespace std;
ifstream in("kfib.in");
ofstream out("kfib.out");
int i, j, n;
int a[2][2] =
    {
        0, 1,
        1, 1
    };
int fib[2][2] = {0, 1};
const int MOD = 1e9+7;
void inmultire(int a[2][2], int b[2][2], int size_a, int size_b, int size_common)
{
    int rez[2][2] =
    {
        0, 0,
        0, 0
    };
    for (int i = 0; i < size_a; i++)
        for (int j = 0; j < size_b; j++)
            for (int k = 0; k < size_common; k++)
                rez[i][j] = (rez[i][j] + a[i][k] * b[k][j]) % MOD;
    a[0][0] = rez[0][0];
    a[0][1] = rez[0][1];
    a[1][0] = rez[1][0];
    a[1][1] = rez[1][1];
}
void logpow(int p)
{
    int rez[2][2] =
    {
        1, 0,
        0, 1
    };
    while(p)
    {
        if (p%2)
            inmultire(rez, a, 2, 2, 2);
        p /= 2;
        inmultire(a, a, 2, 2, 2);
    }
    a[0][0] = rez[0][0];
    a[0][1] = rez[0][1];
    a[1][0] = rez[1][0];
    a[1][1] = rez[1][1];
}
int main()
{   in >> n;
    logpow(n);
    inmultire(fib, a, 1, 2, 2);
    out << fib[0][0];
    return 0;
}
