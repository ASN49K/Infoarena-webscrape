#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int main()
{
    const int MOD = 666013;
    int a = 1, b = 1, c, k;
    fin>>k;

    if (k == 0) fout<<a;
    else if (k == 1) fout<<b;
    else {
        for (int i = 2; i <= k; i++) c = (a+b)%MOD, a = b, b = c;

        fout<<a;
    }

    return 0;
}