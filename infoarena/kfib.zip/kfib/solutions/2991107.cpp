#include <fstream>

using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

long long a[2][2]= {{0,1},{0,0}};
long long c[2][2]= {{0,1},{1,1}};
long long sol[2][2]= {{1,0},{0,1}};
void inmultire(long long a[2][2],long long b[2][2])
{
    long long c[2][2];
    int i,j,k;
    for(i=0; i<2; i++)
        for(j=0; j<2; j++)
        {
            c[i][j]=0;
            for(k=0; k<2; k++)c[i][j]+=a[i][k]*b[k][j];
            c[i][j]=c[i][j]%666013;
        }
    for(i=0; i<2; i++)
        for(j=0; j<2; j++)a[i][j]=c[i][j];
}
void putere(long long sol[2][2],int k)
{
    while(k)
    {
        if(k%2==1)
        {
            inmultire(sol,c);
            k--;
        }
        else
        {
            inmultire(c,c);
            k=k/2;
        }
    }
}

int main()
{
    int n;
    f>>n;
    putere(sol,n);
    inmultire(a,sol);
    g<<a[0][0];
    return 0;
}
