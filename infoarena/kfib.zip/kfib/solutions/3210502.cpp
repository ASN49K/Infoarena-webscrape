#include <fstream>
auto g("kfib.out",std::ios::out),f("kfib.in");int k,x,y=1;main(){for(f>>k;k--%1332028;x=y-x,y%=666013)y+=x;g<<x;}