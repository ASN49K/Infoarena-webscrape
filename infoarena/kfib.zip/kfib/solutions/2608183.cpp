#include <iostream>
#include <fstream>

using namespace std;

ifstream  in("kfib.in");
ofstream out("kfib.out");

const int N = 2;

void mat_mul(int p[N][N], int a[N][N], int b[N][N]) {
    int aux[N][N];

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            aux[i][j] = 0;
            for (int k = 0; k < N; k++) {
                aux[i][j] += a[i][k] * b[k][j];
            }
        }
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            p[i][j] = aux[i][j];
        }
    }
}

int main() {
    int n;
    in >> n;
    

    int p[N][N] = {{1, 1}, {1, 0}};
    int a[N][N] = {{1, 0}, {0, 1}};

    if (!n) a[0][0] = 0;

    n--;

    while (n != 0) {
        if (n % 2 != 0) {
            mat_mul(a, a, p);
        }

        mat_mul(p, p, p);
        n /= 2;
    }

    out << a[0][0];

    return 0;
}