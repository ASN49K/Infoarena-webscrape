#include <bits/stdc++.h>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int n;
int m = 666013;

int fib(int n)
{
    if(n == 1)
        return 1;
    if(n == 0)
        return 0;
    if(n >= 2)return (fib(n-1)+fib(n-2))%666013;
}

int main()
{
    fin >> n;
    n%=1332028;
    fout << fib(n);
    return 0;
}