#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
const int nMax=2e5+5,MOD=1e9+7;

ll t,n,m,k,x,y,z,a,b,c,d,cnt,ans,rez,sum,poz;
ll v[nMax],mat[3][3],mat1[3][3],mat2[3][3],matr[3][3];
bool ok;
char ch;
string s;
map<int,int>mp;
void fastPow(ll p)
{
    matr[1][1]=1;
    matr[2][2]=1;
    while(p)
    {
        mat2[1][1]=mat2[1][2]=mat2[2][1]=mat2[2][2]=0;
        if(p%2)
        {
            p--;
            for(int i=1; i<=2; ++i)
                for(int j=1; j<=2; ++j)
                    for(int q=1; q<=2; ++q)
                        mat2[i][j]+=(mat[i][q]*matr[q][j])%MOD;
            matr[1][1]=mat2[1][1]%MOD;
            matr[1][2]=mat2[1][2]%MOD;
            matr[2][1]=mat2[2][1]%MOD;
            matr[2][2]=mat2[2][2]%MOD;
        }
        else
        {
            p/=2;
            for(int i=1; i<=2; ++i)
                for(int j=1; j<=2; ++j)
                    for(int q=1; q<=2; ++q)
                        mat2[i][j]+=(mat[i][q]*mat[q][j])%MOD;
            mat[1][1]=mat2[1][1]%MOD;
            mat[1][2]=mat2[1][2]%MOD;
            mat[2][1]=mat2[2][1]%MOD;
            mat[2][2]=mat2[2][2]%MOD;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    fin>>n;
    if(n==0)
    {
        fout<<0;
        exit(0);
    }
    mat[1][1]=0;
    mat[1][2]=1;
    mat[2][1]=1;
    mat[2][2]=1;
    fastPow(n);
    fout<<(0*matr[1][1]+1*matr[1][2]);
}
