#include <fstream>

using namespace std;

const int MOD = 666013;
const int NT = 2;

int f[NT][NT] = {{1, 1},{1, 0}};

void produs(int p[NT][NT], int a[NT][NT], int b[NT][NT])
{
    int aux[NT][NT];
    for (int i = 0 ; i < NT; i++)
    {
        for (int k = 0; k < NT; k++)
        {
            aux[i][k] = 0;
            for (int j = 0; j < NT; j++)
            {
                aux[i][k] = (aux[i][k] + (long long)a[i][j]*b[j][k] % MOD) % MOD;
            }
        }
    }
    for (int i = 0; i < NT; i++)
    {
        for (int k = 0; k < NT; k++)
        {
            p[i][k] = aux[i][k];
        }
    }
}

void putere(int p[NT][NT], int n)
{
    while (n != 0)
    {
        if (n % 2 != 0)
        {
            produs(p, p, f);
        }
        produs(f, f, f);
        n /= 2;
    }
}

int main()
{
    ifstream in("kfib.in");
    ofstream out("kfib.out");
    int n;
    in >> n;
    int p[NT][NT] = {{1, 0}, {0, 1}};
    putere(p, n - 1);
    out << p[0][0];
    in.close();
    out.close();
    return 0;
}
