#include <bits/stdc++.h>
#define mod 666013
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
long long mul[2][2], a[2][2], b[2][2];
void inm(long long a[2][2], long long b[2][2])
{
    mul[0][0] = mul[0][1] = mul[1][0] = mul[1][1] = 0;
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 2; k++)
            {
                mul[i][j] = (mul[i][j] + (a[i][k] * b[k][j]) % mod) % mod;
            }
        }
    }
}
void logput(int p)
{
    if (p == 1)
    {
        a[0][0] = 0, a[0][1] = 1, a[1][0] = 1, a[1][1] = 1;
    }
    else
    {
        logput(p / 2);
        inm(a, a);
        a[0][0] = mul[0][0], a[0][1] = mul[0][1], a[1][0] = mul[1][0], a[1][1] = mul[1][1];
        if (p % 2 == 1)
        {
            inm(a, b);
            a[0][0] = mul[0][0], a[0][1] = mul[0][1], a[1][0] = mul[1][0], a[1][1] = mul[1][1];
        }
    }
}

int main()
{
    int n;
    f >> n;
    b[0][0] = 0, b[1][1] = 1, b[0][1] = 1, b[1][0] = 1;
    logput(n + 1);
    g << mul[0][0];
}
