#include <fstream>
#include <cstring>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#define int long long
#define pb push_back
#define zeros(x) ((x^(x-1))&x)
#define dbg(x) cerr<<#x": "<<x<<"\n"
#define dbg_p(x) cerr<<#x": "<<x.first<<","<<x.second<<"\n"
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"
using namespace std;
ifstream cin ("kfib.in");
ofstream cout ("kfib.out");
const int mod = 666013;
void inmultire(int a[2][2],int b[2][2])
{
    int rasp[2][2] = {0};
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            for(int k=0;k<2;k++)
                rasp[i][j] = (rasp[i][j] + (a[i][k]*b[k][j])%mod)%mod;
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            a[i][j] = rasp[i][j];
}
void putere(int rasp[2][2],int a[2][2],int b)
{
    while(b)
    {
        if(b&1)
            inmultire(rasp,a);
        inmultire(a,a);
        b = b/2;
    }
}
void solve()
{
    int n;
    cin >> n;
    if(n<=1)
    {
        cout << n;
        return;
    }
    int M[2][2] = {{1,0},{0,0}};
    int Z[2][2] = {{1,1},{1,0}};
    int R[2][2] = {{1,0},{0,1}};
    putere(R,Z,n-1);
    inmultire(M,R);
    cout << M[0][0];
}
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int t = 1;
    //cin >> t;
    while (t)
    {
        t--;
        solve();
    }
    return 0;
}
