#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("kfib.in");
ofstream fout ("kfib.out");

const int MOD=666013;

int mat[2][2];
int aux[2][2];
int aux2[2][2];
int fib[2][2];

void inmultire(int a[2][2],int b[2][2])
{
    int x,i,j;
    aux2[0][0]=0;
    aux2[0][1]=0;
    aux2[1][0]=0;
    aux2[1][1]=0;
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
        {
            for(x=0;x<2;x++)
                aux2[i][j]=(aux2[i][j]+1LL*a[i][x]*b[x][j])%MOD;
        }
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            aux[i][j]=aux2[i][j];
}

void lgput(int b)
{
    if(b==0)
        return ;
    else
    {
        if(b%2==0)
        {
            lgput(b/2);
            inmultire(aux,aux);
        }
        else
        {
            lgput(b/2);
            inmultire(aux,aux);
            inmultire(mat,aux);
        }
    }
}

int main()
{
    int n,i,j,k;
    fin>>k;
    k--;
    aux[0][0]=1;
    aux[0][1]=0;
    aux[1][0]=0;
    aux[1][1]=1;
    mat[0][0]=0;
    mat[0][1]=1;
    mat[1][0]=1;
    mat[1][1]=1;
    fib[0][0]=0;
    fib[0][1]=1;
    lgput(k);
    inmultire(fib,aux);
    fout<<aux[0][1]<<"\n";
    return 0;
}
