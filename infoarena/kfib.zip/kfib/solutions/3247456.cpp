#include <iostream>
#include <fstream>
using namespace std;

ifstream f ("kfib.in");
ofstream g ("kfib.out");

const int MOD = 666013;

int A[2][2] = {{1, 1}, {1, 0}};
int I[2][2] = {{1, 0}, {0, 1}};

void multmat(int A[][2], int B[][2]) {
    long long C[2][2];
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++) {
            C[i][j] = 0;
            for(int k=0; k<2; k++)
                C[i][j] += 1LL * A[i][k] * B[k][j];
        }
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            A[i][j] = C[i][j] % MOD;
}

void puteremat(int p) {
    while(p != 0) {
        if (p%2 == 0) {
            multmat(A, A);
            p /= 2;
        } else {
            multmat(I, A);
            p--;
        }
    }
}

int main()
{
    int k;
    f >> k;
    if (k <= 1)
        g << k;
    else {
        puteremat(k-1);
        g << I[0][0];
    }
    f.close();
    g.close();
    return 0;
}
