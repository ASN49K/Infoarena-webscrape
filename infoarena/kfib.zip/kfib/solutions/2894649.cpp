//
// Purposefully built to learn C++ template metaprogramming
// Inspired by
// https://en.wikipedia.org/wiki/Template_metaprogramming#Static_Table_Generation
//
#include <array>
#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;

// Highest size for which the compiler does not ask for a custom template
// recursion depth
constexpr int MaxSize = 1023;
constexpr int mod = 666013;

template <int Index = 0, int Previous = 0, int Current = 1, int... D>
struct Helper
    : Helper<Index + 1, Current, (Previous + Current) % mod, D..., Current> {};

template <int Previous, int Current, int... D>
struct Helper<MaxSize, Previous, Current, D...> {
  static constexpr array<int, MaxSize> table = {D...};
};

constexpr array<int, MaxSize> fibonacci = Helper<>::table;

int main() {
  ifstream f("kfib.in");
  ofstream g("kfib.out");
  int n;
  f >> n;
  cout << (n - 1) % (2 * mod + 2);
  g << fibonacci[(n - 1) % (2 * mod + 2)];
  return 0;
}