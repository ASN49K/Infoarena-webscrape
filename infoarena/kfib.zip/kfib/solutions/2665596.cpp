#include <fstream>
#define MOD 666013
using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

struct matrix
{
    long long mat[4][4];

    void initBase()
    {
        mat[0][0] = 0;
        mat[0][1] = 1;
        mat[1][0] = 1;
        mat[1][1] = 1;
    }

    void initI()
    {
        mat[0][0] = 1;
        mat[0][1] = 0;
        mat[1][0] = 0;
        mat[1][1] = 1;
    }
};

matrix inmultire(matrix a, matrix b)
{
    matrix c;
    for(int i = 0; i<2; i++)
    {
        for(int j = 0; j<2; j++)
        {
            c.mat[i][j] = 0;
            for(int k = 0; k<2; k++)
            {
                c.mat[i][j] = (c.mat[i][j] + a.mat[i][k] * b.mat[k][j]) % MOD;
            }
        }
    }
    return c;
}

matrix ridPutLog(matrix m, int put)
{
    matrix rez;
    rez.initI();
    while(put)
    {
        if((put & 1) == 1)
        {
            rez = inmultire(rez, m);
        }
        m = inmultire(m, m);
        put /= 2;
    }
    return rez;
}

int main()
{
    int n;
    f>>n;
    matrix m;
    m.initBase();
    m = ridPutLog(m, n-1);
    g<<(m.mat[0][0] + m.mat[1][0]) % MOD;
    return 0;
}
