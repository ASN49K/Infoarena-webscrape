#include <fstream>
#include <vector>
#include <algorithm>
#include <map>
#include <string>
using namespace std;
ifstream fin ("kfib.in");
ofstream fout("kfib.out");
const long long MOD=666013;
int n;
void copiere(long long a[2][2],long long b[2][2])
{
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            a[i][j]=b[i][j];
}
void inmultire(long long a[2][2],long long b[2][2],long long c[2][2])
{
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
        {
            c[i][j]=0;
            for(int k=0;k<2;k++)
            {
                c[i][j]+=(a[i][k]*b[k][j]);
                c[i][j]%=MOD;
            }
        }
}
int main()
{
    fin>>n;
    if(n<3)
    {
        fout<<1;
        return 0;
    }
    n-=2;
    long long a[2][2]={ {1,1},
                        {1,0} };

    long long p[2][2]={ {1,0},
                        {0,1} };
    long long b[2][2];
    while(n)
    {
        if(n&1)
        {
            inmultire(p,a,b);
            copiere(p,b);
        }
        inmultire(a,a,b);
        copiere(a,b);
        n/=2;
    }
    fout<<(p[0][0]+p[1][0])%MOD;
    return 0;
}
