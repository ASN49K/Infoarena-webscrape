#include <bits/stdc++.h>
using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

const int mod = 666013;

int main() {
    int k;
    f >> k;
    if(k == 0)
        g << 0;
    else if(k == 1)
        g << 1;
    else { 
        int ans = 0, a = 0, b = 1;
        for(int i = 2; i <= k; i++) {
            ans = (a + b) % mod;
            a = b;
            b = ans;
        }
        g << ans;
    }

    return 0;
}