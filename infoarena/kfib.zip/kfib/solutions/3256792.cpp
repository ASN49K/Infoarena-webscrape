#include <iostream>
#include <fstream>
#define ll long long
#define MOD 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

ll m[2][2]={{0,1},{1,1}};
ll fib[2][2]={{0,1},{0,0}};
ll n;
ll sol[2][2]={{1,0},{0,1}};

void Multiply(ll x[2][2],ll y[2][2])
{
    ll rez[2][2]={0};
    for(int i=0; i < 2 ;i++)
    {
        for(int j=0; j < 2;j++)
        {
            for(int k=0 ; k<2 ;k++)
            {
                rez[i][j]=(rez[i][j]+ (1LL * x[i][k] * y[k][j])%MOD)%MOD;
            }
        }
    }
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
            x[i][j]=rez[i][j];
    }
}

void pow(ll rez[2][2],int p)
{
    while(p)
    {
        if(p%2)
        {
            Multiply(rez,m);
        }
        Multiply(m,m);
        p/=2;
    }
}

int main()
{
    fin>>n;
    pow(sol,n-1);
    Multiply(fib,sol);
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
            cout<<sol[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl;
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
            cout<<fib[i][j]<<" ";
        cout<<endl;
    }
    fout<<fib[0][1];
    return 0;
}
