#include <fstream>
#define MOD 666013
using namespace std;
ifstream cin("kfib.in");
ofstream cout("kfib.out");
void inmultire(long long a[][3],long long b[][3],long long c[][3])
{
    int j,i,t;
    for(i=1;i<=2;i++)
        for(j=1;j<=2;j++)
    {
        c[i][j]=0;
        for(t=1;t<=2;t++)
            c[i][j]=(c[i][j]+a[i][t]*b[t][j])%MOD;
    }
    for(i=1;i<=2;i++)
        for(j=1;j<=2;j++)
           a[i][j]=c[i][j];
}
long long p[3][3]={{0,0,0},{0,1,0},{0,0,1}},a[3][3]={{0,0,0},{0,0,1},{0,1,1}},c[3][3];
int main()
{
    int k;
    cin>>k;
    k--;
    while(k>0)
    {
        if(k%2!=0)
            inmultire(p,a,c);
        k=k/2;
        inmultire(a,a,c);
    }
    cout<<p[2][2];
    return 0;
}
