#include <bits/stdc++.h>
#define MOD 666013
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
void copiere (int a[3][3],int b[3][3])
{
    int i,j;
    for (i=1;i<=2;i++)
    {
        for (j=1;j<=2;j++)
        {
            a[i][j]=b[i][j];
        }
    }
}
void inmultire (int a[3][3],int b[3][3],int c[3][3])
{
    int i,j,k;
    for (i=1;i<=2;i++)
    {
        for (j=1;j<=2;j++)
        {
            for (k=1;k<=2;k++)
            {
                c[i][j]=(1LL*a[i][k]*b[k][j]+c[i][j])%MOD;
            }
        }
    }
}
void lgput (int a[3][3],int putere)
{
    int i;
    int b[3][3],aux[3][3];
    copiere(b,a);
    a[1][1]=a[2][2]=1;
    for (i=0;(1<<i)<=putere;i++)
    {
        if ((putere&(1<<i))!=0)
        {
            memset(aux,0,sizeof(aux));
            inmultire(a,b,aux);
            copiere(a,aux);
        }
        memset(aux,0,sizeof(aux));
        inmultire(b,b,aux);
        copiere(b,aux);
    }
}
int n,mat[3][3];
int main()
{
    f>>n;
    mat[1][1]=0;
    mat[1][2]=mat[2][1]=mat[2][2]=1;
    lgput(mat,n-1);
    g<<mat[1][1];
    return 0;
}
