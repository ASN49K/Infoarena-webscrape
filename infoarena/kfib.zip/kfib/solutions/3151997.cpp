#include <fstream>
#define MOD 666013
using namespace std;
ifstream cin("kfib.in");
ofstream cout("kfib.out");
int rez[3][3],b[3][3],aux[3][3];
void prod(int a[3][3], int b[3][3])
{
    int i,j,k;
    for(i=1;i<=2;i++)
        for(j=1;j<=2;j++)
            for(k=1;k<=2;k++)
                aux[i][j]=(1LL*aux[i][j]+1LL*a[i][k]*b[k][j])%MOD;
    for(i=1;i<=2;i++)
        for(j=1;j<=2;j++)
        {
            a[i][j]=aux[i][j];
            aux[i][j]=0;
        }
}
int main()
{
    int n;
    cin>>n;
    if(n==0)
        cout<<0;
    else
    {
        n--;
        b[1][2]=1;
        b[2][1]=1;
        b[2][2]=1;
        rez[1][1]=1;
        rez[2][2]=1;
        while(n>0)
        {
            if(n%2==0)
            {
                n/=2;
                prod(b,b);
            }
            else
            {
                n--;
                prod(rez,b);
            }
        }
        cout<<rez[2][2];
    }
    return 0;
}
