#include <fstream>

using namespace std;

const int MOD = 666013;

void produs(int p[2][2], int a[2][2])///matricea p devine p * a
{
    int aux[2][2];
    aux[0][0] = ((long long)p[0][0] * a[0][0] + (long long)p[0][1] * a[1][0]) % MOD;
    aux[0][1] = ((long long)p[0][0] * a[0][1] + (long long)p[0][1] * a[1][1]) % MOD;
    aux[1][0] = ((long long)p[1][0] * a[0][0] + (long long)p[1][1] * a[1][0]) % MOD;
    aux[1][1] = ((long long)p[1][0] * a[0][1] + (long long)p[1][1] * a[1][1]) % MOD;
    p[0][0] = aux[0][0];
    p[0][1] = aux[0][1];
    p[1][0] = aux[1][0];
    p[1][1] = aux[1][1];
}

void putere(int p[2][2], int a[2][2], int n)
{
    ///initializam p cu matricea unitate
    p[0][0] = p[1][1] = 1;
    p[0][1] = p[1][0] = 0;
    while (n != 0)
    {
        int cifb = n % 2;
        if (cifb != 0)
        {
            produs(p, a);
        }
        produs(a, a);
        n /= 2;
    }
}

int main()
{
    ifstream in("kfib.in");
    ofstream out("kfib.out");
    int n;
    in >> n;
    int a[2][2] = {{1, 1}, {1, 0}}, p[2][2];
    putere(p, a, n - 1);
    out << p[0][0];
    in.close();
    out.close();
    return 0;
}
