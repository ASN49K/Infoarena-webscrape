#include <iostream>
#include <fstream>
#define MAX 1000000 
#define MOD 666013

// Recursivity with Memoization 

int mem[MAX];

int Fibonnaci(int n)
{
    if(n == 1 || n == 2)
        return 1; 
    if(mem[n] != 0)
    {
        return mem[n];
    }
    int curr = Fibonnaci(n-1) + Fibonnaci(n-2);
    mem[n] = curr;
    return curr;
}

int main()
{
    std::ifstream in{"kfib.in"};
    std::ofstream out{"kfib.out"};
    int n;
    in >> n;
    out << Fibonnaci(n);
}