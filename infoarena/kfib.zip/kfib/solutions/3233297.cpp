#include <iostream>
#include <vector>

const int MOD = 666013;

// Function to multiply two 2x2 matrices
std::vector<std::vector<long long>> multiply(const std::vector<std::vector<long long>> &a, const std::vector<std::vector<long long>> &b) {
    std::vector<std::vector<long long>> result(2, std::vector<long long>(2));
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            result[i][j] = 0;
            for (int k = 0; k < 2; ++k) {
                result[i][j] = (result[i][j] + a[i][k] * b[k][j]) % MOD;
            }
        }
    }
    return result;
}

// Function to perform matrix exponentiation
std::vector<std::vector<long long>> matrix_power(std::vector<std::vector<long long>> base, long long exp) {
    std::vector<std::vector<long long>> result = {{1, 0}, {0, 1}};
    while (exp > 0) {
        if (exp % 2 == 1) {
            result = multiply(result, base);
        }
        base = multiply(base, base);
        exp /= 2;
    }
    return result;
}

// Function to calculate the K-th Fibonacci number modulo 666013
long long fibonacci_mod(long long k) {
    if (k == 0) return 0;
    if (k == 1) return 1;

    std::vector<std::vector<long long>> F = {{1, 1}, {1, 0}};
    std::vector<std::vector<long long>> result = matrix_power(F, k - 1);

    return result[0][0];
}

int main() {
    long long k;
    std::cin >> k;

    std::cout << fibonacci_mod(k) << std::endl;

    return 0;
}
