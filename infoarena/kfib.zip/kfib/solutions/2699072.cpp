#include<iostream>
#include<fstream>
using namespace std;
ifstream in("kfib.in");
ofstream out("kfib.out");
int k,f0=0,f1=1,f2,i;
int main()
{in>>k;
if(k==0) out<<0;
    else if(k==1) out<<1;
    else {for(i=2;i<=k;i++)
              {f2=(f0+f1)%666013;
              f0=f1,f1=f2;}
         out<<f1;}
return 0;
}
