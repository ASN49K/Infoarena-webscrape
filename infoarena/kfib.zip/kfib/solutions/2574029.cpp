#include <bits/stdc++.h>
#define mod 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int a[3][3], b[3][3], res[3][3];
int aux[3][3];
int n;

inline void inmult(int a[][3], int b[][3], int c[][3])
{
    for (int i = 1; i <= 2; i++)
        for (int j = 1; j <= 2; j++)
            for (int k = 1; k <= 2; k++)
                c[i][j] = (c[i][j] + 1ll*a[i][k]*b[k][j]) % mod;
}

inline void put()
{
    int p = n;
    while (p)
    {
        if (p % 2 == 1)
        {
            //res *= a
            memset(aux, 0, sizeof(aux));
            inmult(res, a, aux);
            memcpy(res, aux, sizeof(aux));
        }
        //a = a*a
        memset(aux, 0, sizeof(aux));
        inmult(a, a, aux);
        memcpy(a, aux, sizeof(a));
        p /= 2;
    }
}

inline void solve()
{
    a[1][2] = a[2][1] = a[2][2] = 1;
    res[1][1] = res[2][2] = 1;
    put();
    fout << res[2][1];
}

int main()
{
    fin >> n;
    solve();
    return 0;
}
