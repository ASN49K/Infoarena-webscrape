#include <iostream>
#include <fstream>
using namespace std;
const int MOD = 666013;
ifstream f("kfib.in");
ofstream g("kfib.out");
int A[2][2] = {{1, 1}, {1, 0}};
int I[2][2] = {{1, 0}, {0, 1}};

void multmat(int a[][2], int b[][2])
{
    long long c[2][2];
    int i, j, k;
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
        {
            c[i][j] = 0;
            for(k = 0; k < 2; k++)
                c[i][j] += 1LL * a[i][k] * b[k][j];
        }
    for(i = 0; i < 2; i++)
        for(j = 0; j < 2; j++)
            a[i][j] = c[i][j] % MOD;
}
void puteremat(int p)
{
    while(p > 0)
        if(p % 2 == 0)
        {
            multmat(A, A);
        }
        else
        {
            multmat(I, A);
            p--;
        }
}

int main()
{
    int k;
    f>>k;
    if(k<=1)
        g<<k;
    else {
        puteremat(k-1);
        g<<I[0][0];
    }
    f.close();
    g.close();
    return 0;
}
