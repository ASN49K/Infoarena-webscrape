#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
int main()
{
    int ai = 1, aj = 2, bi = 2, bj = 2;
    int a[ai][aj] = {0, 1};
    int b[bi][bj] = {{0, 1}, {1, 1}};
    int d[bj];
    int n;
    fin >> n;
    for (int p = 0; p < n; p++)
    {

        for (int k = 0; k < ai; k++)
        {
            for (int j = 0; j < bj; j++)
            {
                int s = 0;
                for (int i = 0; i < aj; i++)
                {

                    s += a[k][i] * b[i][j];
                }
                d[j] = s % 666013;
                // cout << s << " ";
            }
            for (int j = 0; j < bj; j++)
            {
                a[k][j] = d[j];
            }
            // cout << '\n';
        }
    }
    fout << a[0][0];

    return 0;
}