#include <fstream>
using namespace std;
const int MOD=666013;

int X,Y,Z,A,B,C;

ifstream f("iepuri.in");
ofstream g("iepuri.out");

void mul(int A[][3],int B[][3]) {
    long long C[3][3];
    int i,j,k;
    for(i=0; i<3; ++i) {
        for(j=0; j<3; ++j) {
            C[i][j]=0;
            for(k=0; k<3; ++k) {
                C[i][j]+=(long long)A[i][k]*B[k][j];
            }
        }
    }
    for(i=0; i<3; ++i) {
        for(j=0; j<3; ++j) {
            A[i][j]=C[i][j]%MOD;
        }
    }
}

int putere(int n) {
    int M[3][3]= {
        {A,1,0},
        {B,0,1},
        {C,0,0}
    };
    int V[3][3]= {
        {Z,Y,X},
        {0,0,0},
        {0,0,0}
    };
    while(n>0) {
        if(n&1==1) {
            mul(V,M);
        }
        mul(M,M);
        n/=2;
    }
    return V[0][0];
}

int main() {
    int T,N;
    f>>T;
    while(T--) {
        f>>X>>Y>>Z
         >>A>>B>>C
         >>N;
        g<<putere(N-2)<<'\n';
    }
    f.close();
    g.close();
    return 0;
}
