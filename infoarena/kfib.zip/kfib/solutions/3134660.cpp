#include <cstdio>
#include <cstring>
#define mod 666013

using namespace std;

int N, i;
int MAT[3][3], SOL[3][3];

inline void mult(int A[][3], int B[][3], int C[][3]) {
    int i, j, k;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2; j++)
            for (k = 0; k < 2; k++)
                C[i][j] = (C[i][j] + 1LL * A[i][k] * B[k][j]) % mod;

}

inline void lg_power(int P, int M[][3]) {
    int C[3][3], AUX[3][3], i;

    memcpy(C, MAT, sizeof(MAT));
    M[0][0] = M[1][1] = 1;

    while(P>0){
        if (P%2==1) {
            memset(AUX, 0, sizeof(AUX));
            mult(M, C, AUX);
            memcpy(M, AUX, sizeof(AUX));
        }

        memset(AUX, 0, sizeof(AUX));
        mult(C, C, AUX);
        memcpy(C, AUX, sizeof(C));
        P/=2;
    }
}

int main() {
    freopen("kfib.in", "r", stdin);
    freopen("kfib.out", "w", stdout);

    scanf("%d", &N);

    MAT[0][0] = 0; MAT[0][1] = 1; MAT[1][0] = 1; MAT[1][1] = 1;

    lg_power(N - 1, SOL);

    printf("%d\n", SOL[1][1]);

    return 0;
}