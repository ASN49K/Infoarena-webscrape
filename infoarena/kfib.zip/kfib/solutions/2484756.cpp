#include <iostream>
#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");


const unsigned int MOD = 1999999973;


long long put0(int a, int p)
{
    long long val=1, x=a% MOD;
    while(p>0)
        if(p%2==0)
        {
            x=x*x%MOD;
            p/=2;
        }
        else
        {
            val=val*x % MOD;
            p--;
        }
    return val;
}




int main()
{
    int n,p;
    //cout<<"n, p ?";
    f>>n>>p;
    g<<put0(n, p);
    return 0;
}
