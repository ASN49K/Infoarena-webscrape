#import<fstream>
std::fstream f("kfib.in"),g("kfib.out",std::_S_out);int x,y=1,z,k;main(){for(f>>k;k--%1332028;x=y,y=z)z=(x+y)%666013;g<<x;}