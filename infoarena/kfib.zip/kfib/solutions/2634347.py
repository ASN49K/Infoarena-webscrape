MOD = 666013

def multiply(A, B, C):
    for i in range(2):
        for j in range(2):
            for k in range(2):
                C[i][j] = (C[i][j] + A[i][k] * B[k][j]) % MOD

n = int(input()) - 1
C = [[0, 1, 0], [1, 1, 0], [0, 0, 0]]
M = [[1, 0, 0], [0, 1, 0], [0, 0, 0]]

i = 0
while (1 << i) <= n:
    if n & (1 << i):
        AUX = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        multiply(M, C, AUX)
        M = AUX
    
    AUX = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    multiply(C, C, AUX)
    C = AUX

    i += 1

print(M[1][1])