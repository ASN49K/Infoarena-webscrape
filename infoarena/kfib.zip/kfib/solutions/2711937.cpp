#include <bits/stdc++.h>
using namespace std;

pair <int, int> fib(int n) {
    if (!n) return {0, 1};
    auto p = fib(n >> 1);
    int c = p.first * (2 * p.second - p.first),
        d = p.first * p.first + p.second * p.second;

    if (n & 1)
        return {d, c + d};
    return {c, d};
}

int main() {
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");

    int n;
    fin >> n;

    auto ans = fib(n + 1);
    fout << ans.first;

    return 0;
}