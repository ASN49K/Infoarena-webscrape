#include <cstdio>
#include <cstring>
const int MOD = 666013;
int n, i;
int v[3][3], rez[3][3];

inline void mult(int a[][3], int b[][3], int c[][3]) {
	int i, j, k;
	for (i = 0; i < 2; i++)
		for (j = 0; j < 2; j++)
			for (k = 0; k < 2; k++)
				c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % MOD;

}

inline void lgput(int power, int m[][3]) {
	int cpy[3][3], aux[3][3], i;
	memcpy(cpy, v, sizeof(v));
	m[0][0] = m[1][1] = 1;

	for (i = 0; (1 << i) <= power; i++) {
		if (power & (1 << i)) {
			memset(aux, 0, sizeof(aux));
			mult(m, cpy, aux);
			memcpy(m, aux, sizeof(aux));
		}
		memset(aux, 0, sizeof(aux));
		mult(cpy, cpy, aux);
		memcpy(cpy, aux, sizeof(cpy));
	}
}

int main() {
	freopen("kfib.in", "r", stdin);
	freopen("kfib.out", "w", stdout);
	scanf("%d", &n);
	v[0][0] = 0;
	v[0][1] = 1;
	v[1][0] = 1;
  v[1][1] = 1;
	lgput(n - 1, rez);

	printf("%d\n", rez[1][1]);

	return 0;
}
