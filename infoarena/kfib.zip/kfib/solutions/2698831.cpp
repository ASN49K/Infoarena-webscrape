#include <bits/stdc++.h>
#define MOD 666013
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
long long a[2][2]= {{0,1},{0,0}};
long long c[2][2]= {{0,1},{1,1}};
long long sol[2][2]= {{1,0},{0,1}};
int n;
void mtpy(long long x[2][2],long long y[2][2])// matrix multiplication
{
    long long c[2][2];
    int i,j,k;
    for(i=0; i<=1; i++)
    {
        for(j=0; j<=1; j++)
        {
            c[i][j]=0;
            for(k=0; k<=1; k++)
                c[i][j]+=x[i][k]*y[k][j];
            c[i][j]=c[i][j]%MOD;
        }
    }

    for(i=0; i<=1; i++)
        for(j=0; j<=1; j++) x[i][j]=c[i][j];
}
void pow(long long sol[2][2],int k)// raises matrix to the k-th power
{
    while(k)
    {
        if(k%2==1)
        {
            mtpy(sol,c);
            k--;
        }
        else
        {
            mtpy(c,c);
            k/=2;
        }
    }
}
int main()
{
    f>>n;
    pow(sol,n);
    mtpy(a,sol);
    g<<a[0][0];
    return 0;
}
