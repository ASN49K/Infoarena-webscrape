#include <fstream>

using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

#define MOD 666013

int k;
long long a[2][2] = {{0, 1},
                     {1, 1}};

void inmultire_matrici(long long mat1[2][2], long long mat2[2][2], int ind1, int ind2, int ind3, long long rez[2][2]) {
    for (int i = 0; i < ind1; ++i)
        for (int j = 0; j < ind3; ++j)
            rez[i][j] = 0;
    for (int i = 0; i < ind1; ++i)
        for (int j = 0; j < ind3; ++j)
            for (int ind = 0; ind < ind2; ++ind)
                rez[i][j] = (rez[i][j] + mat1[i][ind] * mat2[ind][j]) % MOD;
}

void copiere(long long mat1[2][2], long long mat2[2][2], int lin, int col) {
    for (int i = 0; i < lin; ++i)
        for (int j = 0; j < col; ++j)
            mat1[i][j] = mat2[i][j];
}

void power(long long mat[2][2], int p, long long rez[2][2]) {
    long long aux[2][2];
    rez[0][0] = rez[1][1] = 1;
    rez[0][1] = rez[1][0] = 0;
    for (; p; p >>= 1) {
        if (p & 1) {
            inmultire_matrici(rez, mat, 2, 2, 2, aux);
            copiere(rez, aux, 2, 2);
        }
        inmultire_matrici(mat, mat, 2, 2, 2, aux);
        copiere(mat, aux, 2, 2);
    }
}

int main() {
    f >> k;
    long long putere[2][2];
    power(a, k - 1, putere);
    long long mat[2][2] = {{0, 1}};
    long long rez[2][2];
    inmultire_matrici(mat, putere, 1, 2, 2, rez);
    g << rez[0][1];
    return 0;
}
