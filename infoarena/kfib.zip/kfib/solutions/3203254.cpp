#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");

    int k;
    fin >> k;

    int f1 = 1, f0 = 0;
    int term = 0;

    for (int i = 2; i <= k; ++i) {
        term = f0 + f1;
        f0 = f1;
        f1 = term;
    }

    fout << term;

    return 0;
}

