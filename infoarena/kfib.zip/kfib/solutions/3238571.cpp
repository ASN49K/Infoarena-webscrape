#include <bits/stdc++.h>

using namespace std;

#define INFILE "fact.in"
#define OUTFILE "fact.out"

typedef long long ll;

const ll LOW_LIMIT = 1;
const ll HIGH_LIMIT = 1e18;

ll getNumberOfDigits(ll number){
    ll ans = 0;
    while(number){
        ans += number / 5;
        number /= 5;
    }
    return ans;
}

void solve(){

    ll p; cin >> p;

    ll left = LOW_LIMIT;
    ll right = HIGH_LIMIT;

    while(left < right){
        ll middle = (left + right) >> 1;
        if(getNumberOfDigits(middle) < p) left = middle + 1;
        else right = middle;
    }

    cout << (getNumberOfDigits(left) == p ? left : -1) << '\n';

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}