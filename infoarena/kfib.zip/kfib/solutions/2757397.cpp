#include <bits/stdc++.h>
#define MOD 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int a[2][2], p[2][2], n, b[2][2];

///c = a * b
void ProdusMatrix(int a[2][2], int b[2][2], int c[2][2])
{
    int i, j, k;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2; j++)
        {
            c[i][j] = 0;
            for (k = 0; k < 2; k++)
                c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % MOD;
        }
}

void Copie(int a[2][2], int b[2][2])
{
    int i, j;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2; j++)
            a[i][j] = b[i][j];
}

void LogP(int n)
{
    p[0][0] = p[1][1] = 1;
    p[0][1] = p[1][0] = 0;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            ProdusMatrix(p, a, b);
            Copie(p, b);
        }
        n /= 2;
        ProdusMatrix(a, a, b);
        Copie(a, b);
    }
}

int main()
{

    fin >> n;
    a[0][0] = 0;
    a[0][1] = a[1][0] = a[1][1] = 1;
    LogP(n - 2);
    int sol = (p[0][1] + p[1][1]) % MOD;
    fout << sol << "\n";
    fout.close();
    return 0;
}
