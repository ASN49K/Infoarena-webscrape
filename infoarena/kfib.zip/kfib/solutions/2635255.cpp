#include <iostream>
#include <fstream>
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
int n,x1=0,x2=1,rez;
int main()
{
    f>>n;
    rez=x1+x2;
    for (int i=3; i<=n; i++)
    {
        x1=x2;
        x2=rez;
        rez=(x1+x2)%666013;
    }
    g<<rez;
    return 0;
}
