#include <fstream>

using namespace std;

ifstream in("kfib.in");
ofstream out("kfib.out");

const int MOD=666013;

void produs(long long p[2][2], long long a[2][2], long long b[2][2])
{
    int aux[2][2];
    for(int i=0; i<2; i++)
    {
        for(int j=0; j<2; j++)
        {
            aux[i][j]=0;
            for(int k=0; k<2; k++)
            {
                aux[i][j]+=((a[i][k]%MOD)*(b[k][j]%MOD))%MOD;
                aux[i][j]%=MOD;
            }
        }
    }
    for(int i=0; i<2; i++)
    {
        for(int j=0; j<2; j++)
        {
            p[i][j]=aux[i][j];
        }
    }
}

long long f[2][2],a[2][2];

int main()
{
    int k;
    in>>k;
    a[0][0]=1;
    a[0][1]=1;
    a[1][0]=1;
    a[1][1]=0;
    f[0][0]=1;
    f[1][1]=1;
    while(k!=0)
    {
        if(k%2!=0)
        {
            produs(f, f, a);
        }
        produs(a, a, a);
        k/=2;
    }
    out<<f[1][0];
    return 0;
}
