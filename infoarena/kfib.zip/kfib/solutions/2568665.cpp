#include <bits/stdc++.h>
#define pb push_back

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

void debug_out() { cerr << '\n'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"

typedef pair<int,int> pii;
typedef long long int ll;
typedef long double ld;

const int DMAX = 1e5+10;
const int MOD = 666013;

struct matrix{
    int mat[2][2];
};

inline matrix operator*(matrix x,matrix y){
    matrix rez;
    int i,j,k;
    for(i=0;i<2;i++)
        for(j=0;j<2;j++){
            rez.mat[i][j]=0;
            for(k=0;k<2;k++)
                rez.mat[i][j]=(rez.mat[i][j]+1LL*x.mat[i][k]*y.mat[k][j]%MOD)%MOD;
        }
    return rez;
}

matrix null,init;

int n;

void constr();
matrix explog(matrix x,int n);

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t,i,j;

    fin>>n;
    if(n == 0){
        fout<<"0\n";
        return 0;
    }
    if(n == 1 || n == 2){
        fout<<"1\n";
        return 0;
    }
    constr();
    matrix rez=explog(init,n-2);
    int ans=0;
    for(i=0;i<2;i++)
        ans=(ans+rez.mat[i][0])%MOD;
    fout<<ans<<'\n';

    return 0;
}
void constr(){
    int i;
    for(i=0;i<2;i++){
        null.mat[i][i]=1;
        init.mat[i][0]=1;
    }
    init.mat[0][1]=1;
}
matrix explog(matrix x,int n){
    if(!n)
        return null;
    if(n & 1)
        return x*explog(x*x,n/2);
    return explog(x*x,n/2);
}
