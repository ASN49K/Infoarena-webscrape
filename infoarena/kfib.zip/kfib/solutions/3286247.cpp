#include <bits/stdc++.h>
#define P 666013
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int a[1500003], n, k;
bool pr;

int main()
{
    a[1] = a[2] = 1;
    a[3] = 2;
    n = 3;
    pr = false;
    while (pr == 0)
    {
        n++;
        a[n] = a[n - 1] + a[n - 2];
        if (a[n] >= P) a[n] -= P;
        if (a[n] == 1 && a[n - 1] == 0) pr = true;
    }
    n--;
    fin >> k;
    k %= n;
    fout << a[k] << "\n";
    return 0;
}

//0, 1, 3-5, 7-18, 21, 22, 24-27, 29, 30, 34-36, 42, 44, 45, 47, 48, 51, 54, 56-58
