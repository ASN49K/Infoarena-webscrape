#include <fstream>
using namespace std;
ifstream f("kfib.in"); ofstream g("kfib.out");
int k,F[1000005];
int main()
{   f>>k;
    F[1]=1;
	for(int i=2;i<=k; i++) F[i]=(F[i-1]+F[i-2])%666013;
    g<<F[k]; g.close(); f.close(); return 0;
}
