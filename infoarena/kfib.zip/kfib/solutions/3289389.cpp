#include <bits/stdc++.h>

#pragma GCC optimize ("O3")
#pragma GCC optimize ("inline,unroll-loops,fast-math")
#pragma GCC target ("avx2,bmi,bmi2,lzcnt,popcnt")

using namespace std;

class inParser {
private:
        FILE *fin; char *buff; int id;
        char readCh( ) {
                ++id;
                if (id == 4096) { id = 0; fread(buff, sizeof(char), 4096, fin); }
                return buff[id];
        }
public:
        inParser (const char *name) {
                fin = fopen(name, "r");
                buff = new char[4096]( );
                id = 4095;
        }

        inParser& operator >> (int &num) {
                char ch;
                while (!isdigit(ch = readCh( )));
                num = ch - '0';
                while (isdigit(ch = readCh( )))
                        num = num * 10 + ch - '0';
                return *this;
        }
};

const string fileName = "kfib";
inParser in ((fileName + ".in").c_str( ));
ofstream out (fileName + ".out");

const int maxsze = 102;
const int inf = 0x3f3f3f3f;
const int modulo = 666013;

class mat {
public:
        int sze; unsigned long long data[maxsze][maxsze];
        friend mat operator * (mat, mat);
        friend mat operator ^ (mat, int);
};

mat operator * (mat a, mat b) {
        mat ans; ans.sze = a.sze;
        for (int i = 0; i < ans.sze; ++i)
                for (int j = 0; j < ans.sze; ++j) {
                        ans.data[i][j] = 0;
                        for (int k = 0; k < ans.sze; ++k)
                                        ans.data[i][j] = (ans.data[i][j] + a.data[i][k] * b.data[k][j]) % modulo;
                }

        return ans;
}

mat operator ^ (mat a, int exp) {
        mat ans; ans.sze = a.sze;
        for (int i = 0; i < ans.sze; ++i) {
                for (int j = 0; j < ans.sze; ++j)
                        ans.data[i][j] = 0;
                ans.data[i][i] = 1;
        }

        while ( exp )
                if (exp % 2 == 0) { a = a * a; exp /= 2; }
                else { ans = ans * a; -- exp; }
        return ans;
}

int main( ) {
        int n; in >> n;
        mat A = {
                .sze = 2,
                .data = {
                        {0 , 1},
                        {1 , 1}
                }
        };

        A = A ^ n;
        out << A.data[0][1] << '\n';
        return 0;
}
