#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

const int MOD = 666013;

void prod(int p[2][2], int a[2][2], int b[2][2]){
    int aux[2][2];
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++){
            aux[i][j] = 0;
            for(int k=0; k<2; k++)
                aux[i][j] = (1LL * aux[i][j] + 1LL * a[i][k] * b[k][j]) % MOD;
        }
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            p[i][j] = aux[i][j];
}

int rez[2][2] = {{1, 0}, {0, 1}};
int fib[2][2] = {{1, 1}, {1, 0}};

void power(int n){
    while(n){
        if(n%2)
            prod(rez, rez, fib);
        prod(fib, fib, fib);
        n /= 2;
    }
}

int main()
{
    int k;
    fin >> k;
    power(k - 1);
    fout << rez[0][0] << "\n";
    return 0;
}
