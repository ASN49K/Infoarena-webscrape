#include <fstream>
#define MOD 666013
std::ifstream fin("kfib.in");
std::ofstream fout("kfib.out");
class matrix{
    public:
    long long int container[2][2];
    matrix(){
        container[0][0] = 0,
        container[0][1] = 1,
        container[1][0] = 1,
        container[1][1] = 1;
    }
    matrix operator* (const matrix& obj1){
        matrix res;
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                res.container[i][j] = 0;
                for(int z=0; z<2; z++){
                    res.container[i][j] += (container[i][z] * obj1.container[z][j]) % MOD;
                    res.container[i][j] %= MOD;
                }
            }
        }
        return res;
    }
    friend std::ostream& operator <<(std::ostream& fout, const matrix& obj){
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                fout << obj.container[i][j] << " ";
            }
            fout << "\n";
        }
        return fout;
    }
};
matrix power(matrix& A , int n){
    matrix res = A;
    while(n){
        if(n%2 == 1){
            res = res * A;
        }
        A = A * A;
        n /= 2;
    }
    return res;
}
int main(){
    long long int k;
    fin >> k;
    matrix mat;
    matrix res_mat = power(mat, k-1);
    fout << res_mat.container[1][0];
}