#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
ifstream cin("kfib.in");
ofstream cout("kfib.out");
long long v[2][2] = { 0,1,1,1 },i,j,n,a[2][2]= { 0,1,1,1 };
void pmat(int nr)
{
	int k;
	while (nr)
	{
		if (nr % 2 == 1) // v=v*a
		{
			long long c[2][2] = { 0,0,0,0 };
			for (i = 0; i < 2; i++) 
				for (j = 0; j < 2; j++)
					for (k = 0; k < 2; k++)
						c[i][j] += v[i][k] * a[k][j] % 666013;
				memcpy(v, c, sizeof(c));
		}

		long long c[2][2] = { 0,0,0,0 };  //a=a*a
		for (i = 0; i < 2; i++) 
			for (j = 0; j < 2; j++)
				for (k = 0; k < 2; k++)
					c[i][j] += a[i][k] * a[k][j] % 666013;
		memcpy(a, c, sizeof(c));
		nr /= 2;
	}
}
int main()
{
	cin >> n;
	pmat(n-2);
	cout << v[1][1] % 666013;
}