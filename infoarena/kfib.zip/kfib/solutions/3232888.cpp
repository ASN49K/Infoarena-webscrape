#include <bits/stdc++.h>
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

long divizor;
int c[2][2], a[2][2], b[2][2];

void produs(int x[][2], int y[][2], int rez[][2])
{
    int aux[2][2];
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            aux[i][j] = 0;
            for(int k = 0; k < 2; k++)
            {
                aux[i][j] += x[i][k] * y[k][j];
                aux[i][j] = aux[i][j] % divizor;
            }
        }
    }
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            rez[i][j] = aux[i][j];
        }
    }
}

void a_Power(int p, int final[][2])
{
    if(p == 1)
    {
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < 2; j++)
            {
                final[i][j] = a[i][j];
            }
        }
        return;
    }
    int aux[2][2];
    if(p % 2 == 0)
    {
        a_Power(p/2, aux);
        produs(aux, aux, final);
    }
    else
    {
        a_Power(p-1, aux);
        produs(aux, a, final);
    }
}

int main()
{
    int n;
    fin >> n;
    divizor = 666013;
    a[0][0] = 0;
    a[0][1] = 1;
    a[1][0] = 1;
    a[1][1] = 1;
    
    a_Power(n-1, c);
    
    fout << c[1][1];

    return 0;
}