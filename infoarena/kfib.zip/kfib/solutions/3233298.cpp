#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MOD = 666013;

// Function to multiply two 2x2 matrices
vector<vector<long long>> multiply(const vector<vector<long long>> &a, const vector<vector<long long>> &b) {
    vector<vector<long long>> result(2, vector<long long>(2));
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            result[i][j] = 0;
            for (int k = 0; k < 2; ++k) {
                result[i][j] = (result[i][j] + a[i][k] * b[k][j]) % MOD;
            }
        }
    }
    return result;
}

// Function to perform matrix exponentiation
vector<vector<long long>> matrix_power(vector<vector<long long>> base, long long exp) {
    vector<vector<long long>> result = {{1, 0}, {0, 1}};
    while (exp > 0) {
        if (exp % 2 == 1) {
            result = multiply(result, base);
        }
        base = multiply(base, base);
        exp /= 2;
    }
    return result;
}

// Function to calculate the K-th Fibonacci number modulo 666013
long long fibonacci_mod(long long k) {
    if (k == 0) return 0;
    if (k == 1) return 1;

    vector<vector<long long>> F = {{1, 1}, {1, 0}};
    vector<vector<long long>> result = matrix_power(F, k - 1);

    return result[0][0];
}

int main() {
    ifstream infile("kfib.in");
    ofstream outfile("kfib.out");

    long long k;
    infile >> k;

    long long result = fibonacci_mod(k);
    outfile << result << endl;

    infile.close();
    outfile.close();

    return 0;
}
