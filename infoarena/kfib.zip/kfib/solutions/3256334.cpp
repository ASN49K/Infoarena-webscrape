#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp> 
#define ll long long
#define ull unsigned long long
#define ld long double
#define chad char
#define mod 666'013
#define dim 100005
#define lim 1000000
#define BASE 31
#define NMAX 21'005
#define FOR(i,a,b) for(int i=(a); i<=(b); i++)
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 
#define pii pair<int,int>
#define pb push_back
#define mp make_pair
#define nr_biti __builtin_popcount
using namespace __gnu_pbds; 
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int t=1;
int n;

ll f[2][2];
ll b[2][2];
ll aux[2][2];

void mul(ll a[2][2],ll b[2][2],ll c[2][2])
{
    for(int i=0; i<2; i++)
    {
        for(int j=0; j<2; j++)
        {
            c[i][j]=0;
            for(int z=0; z<2; z++)
                c[i][j]=(c[i][j]+(a[i][z]*b[z][j])%mod)%mod;
        }
    }
}

void pw(int exponent)
{
    f[0][0]=f[1][0]=f[0][1]=1LL;
    b[0][0]=1;

    while(exponent)
    {
        if(exponent&1)
        {
            mul(f,b,aux);
            for(int i=0; i<2; i++)
                for(int j=0; j<2; j++)
                    b[i][j]=aux[i][j];
        }
        exponent/=2;
        mul(f,f,aux);
        for(int i=0; i<2; i++)
            for(int j=0; j<2; j++)
                f[i][j]=aux[i][j];
    }
}

void solve()
{
    fin >> n;

    if(n==0)
        fout << 0;
    else 
    {
        pw(n-1);
        fout << b[0][0];
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    //cin >> t;
    while(t--)
        solve();

    return 0;
}