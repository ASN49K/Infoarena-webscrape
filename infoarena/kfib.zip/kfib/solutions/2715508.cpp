#include <bits/stdc++.h>

using namespace std;

const int MOD = 666013;
int f[2][2], a[2][2];

void produs(int p[2][2], int x[2][2], int y[2][2]) {
    int aux[2][2];
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++) {
            aux[i][j] = 0;
            for (int k = 0; k < 2; k++)
                aux[i][j] = ((long long)aux[i][j] + (long long)x[i][k] * y[k][j]) % MOD;
        }
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            p[i][j] = aux[i][j];
}

void lgput(int n) {
    while (n != 0) {
        if (n % 2 != 0)
            produs(f, f, a);
        produs(a, a, a);
        n /= 2;
    }
}

int main() {

    freopen ("kfib.in", "r", stdin);
    freopen ("kfib.out", "w", stdout);

    int n;

    scanf ("%d", &n);
    a[0][0] = a[0][1] = a[1][0] = 1;
    f[0][0] = f[1][1] = 1;
    lgput(n);
    printf ("%d", f[0][1]);


    return 0;
}
