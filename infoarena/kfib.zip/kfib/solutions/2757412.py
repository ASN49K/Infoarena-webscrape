#Fibonaci
a=0
b=1
n=int(input())
for i in range(1,n):
	c=(a+b)%666013
	a=b%666013
	b=c%666013
print(c);
