#include<fstream>
#include<iostream>
#include<climits>
#include<algorithm>
#include<cstring>
#include<cmath>
#include <vector>
#include <queue>
#include <iomanip>
#include <bitset>
#include <deque>

#define MOD 666013

using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

//ifstream f("in.in");
//ofstream g("out.out");

long long a,b,c,p;

void produs(long long prod[2][2],long long a[2][2],long long b[2][2]){
    for(int i=0;i<=1;i++){
        for(int j=0;j<=1;j++){
            prod[i][j] = 0;
            for(int k=0;k<=1;k++){
                prod[i][j] = (prod[i][j] + a[i][k] * b[k][j])%MOD;
            }
        }
    }
}

void egal(long long x[2][2],long long a[2][2]){
    for(int i=0;i<=1;i++){
        for(int j=0;j<=1;j++){
            x[i][j] = a[i][j];
        }
    }
}

int main(){

    f>>b;

    if(b==0){
        g<<0;
        return 0;
    }

    if(b<=2){
        g<<1;
        return 0;
    }

    b-=2;

    long long x[2][2] = {
        {0,0},
        {0,0}
    };

    long long a[2][2] = {
        {1,1},
        {1,0}
    };

    long long p[2][2] = {
        {1,0},
        {0,1}
    };

    while(b!=0){
        if(b%2==1){
            produs(x,a,p);
            egal(p,x);
        }
        produs(x,a,a);
        egal(a,x);
        b/=2;
    }

    long long start[2][2] = {
        {1,0},
        {1,0}
    };

    produs(x,p,start);

    /*for(int i=0;i<=1;i++){
        for(int j=0;j<=1;j++){
            cout<<x[i][j]<<" ";
        }
        cout<<"\n";
    }*/

    g<<x[0][0];

    f.close();
    g.close();
    return 0;
}
