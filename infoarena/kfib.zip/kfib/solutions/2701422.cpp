#include <iostream>
#include <math.h>
#include <fstream>
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
int main()
{
    double gr = (1 + sqrt(5))/2;
    unsigned long long n,x;
    f>>n;
    x=((pow(gr, n) - pow(1 - gr, n))/sqrt(5));
    x=x%666013;
    g<<x;
    return 0;
}
