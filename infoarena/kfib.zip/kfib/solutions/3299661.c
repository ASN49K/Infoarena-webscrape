#include <stdio.h>
#include <stdlib.h>

void inmultire(long long a[2][2], long long b[2][2],long long mod) {
    long long c[2][2];
    c[0][0] = (a[0][0]*b[0][0] + a[0][1]*b[1][0]) % mod;
    c[0][1] = (a[0][0]*b[0][1] + a[0][1]*b[1][1]) % mod;
    c[1][0] = (a[1][0]*b[0][0] + a[1][1]*b[1][0]) % mod;
    c[1][1] = (a[1][0]*b[0][1] + a[1][1]*b[1][1]) % mod;

    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            a[i][j] = c[i][j];
}

void ridicare_rapida(long long mat[2][2], long long k,long long mod) {
    long long rezultat[2][2] = {{1, 0}, {0, 1}};
    long long baza[2][2] = {
        {mat[0][0], mat[0][1]},
        {mat[1][0], mat[1][1]}
    };

    while(k > 0) {
        if(k % 2 == 1)
            inmultire(rezultat, baza, mod);
        inmultire(baza, baza,mod);
        k /= 2;
    }

    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            mat[i][j] = rezultat[i][j];
}

int main()
{
    FILE *fin, *fout;
    fin = fopen("kfib.in","r");
    fout = fopen("kfib.out","w");
    long long k;
    long long mod = 666013;
    long long Z[2][2] = {{0,1},{1,1}};
    fscanf(fin,"%lld",&k);
    if(k==0)
        fprintf(fout,"%d",0);
    else
    {
        if(k == 2 || k == 1)
            fprintf(fout,"%d",1);
        else
            ridicare_rapida(Z,k,mod);
    }
    fprintf(fout,"%lld",Z[0][1]);
    fclose(fin);
    fclose(fout);
}