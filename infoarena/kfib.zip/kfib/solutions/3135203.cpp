#include <iostream>
#include <fstream>
#define MOD_NUMBER 666013
std::ifstream fin("kfib.in");
std::ofstream fout("kfib.out");



int main(){
    long long int Z[2][2] = {0,1,1,1},M1[2] = {0,1};
    long long int k;
    fin >> k;
    for(long long int i = 1; i < k - 1; i++){
        Z[0][0] = Z[0][1] % MOD_NUMBER;
        Z[0][1] = Z[1][1] % MOD_NUMBER;
        Z[1][0] = Z[1][1] % MOD_NUMBER;
        Z[1][1] = Z[0][0] % MOD_NUMBER + Z[0][1] % MOD_NUMBER;
    }
    fout << Z[1][1] % MOD_NUMBER;
    return 0;
}
