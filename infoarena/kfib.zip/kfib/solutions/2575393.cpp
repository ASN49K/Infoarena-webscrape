#include <iostream>
#include <fstream>
#define MOD 666013
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

long long r[2][2]={{1,1},{1,0}},m[2][2]={{1,1},{1,0}};
int k;

void matrixmul(long long a[2][2],long long b[2][2],long long (&mult)[2][2]) {
    long long c[2][2];
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++) {
            c[i][j]=0;
            for(int k=0; k<2; k++)
                c[i][j]=(c[i][j]+a[i][k]*b[k][j]%MOD)%MOD;
        }
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            mult[i][j]=c[i][j];
}
void matrixpow(int p) {
    while(p) {
        if(p%2)
            matrixmul(r,m,r);
        matrixmul(m,m,m);
        p/=2;
    }
}

int main()
{
    fin>>k;
    matrixpow(k);
    fout<<r[1][1];
    return 0;
}
