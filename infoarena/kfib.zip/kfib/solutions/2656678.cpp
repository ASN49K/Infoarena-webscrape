#include <bits/stdc++.h>
#define pb push_back
#define ll long long
using namespace std;
//const int MOD=100003;
ifstream f("kfib.in");
ofstream g("kfib.out");
const int mod= 666013;
int n,sol[3][3];
void copiere(int a[3][3],int b[3][3])
{
    for(int i=1;i<=2;i++)
    {
        for(int j=1;j<=2;j++)
        {
            a[i][j]=b[i][j];
        }
    }
}
void multmat(int a[3][3],int b[3][3],int c[3][3])
{
    for(int i=1;i<=2;i++)
    {
        for(int j=1;j<=2;j++)
        {
            for(int k=1;k<=2;k++)
            {
                c[i][j]=1LL*(c[i][j]+1LL*a[i][k]*b[k][j])%mod;
            }
        }
    }
}
void exponentiere(int a[3][3],int putere)
{
    int b[3][3],aux[3][3];
    copiere(b,a);
    a[1][1]=a[2][2]=1;///element neutru
    while(putere)
    {
        if(putere%2==1)
        {
            memset(aux,0,sizeof(aux));
            multmat(a,b,aux);
            copiere(a,aux);
        }
        memset(aux,0,sizeof(aux));
        multmat(b,b,aux);
        copiere(b,aux);
        putere/=2;
    }
}
int main()
{

    f>>n;
    sol[1][1]=0;
    sol[1][2]=sol[2][1]=sol[2][2]=1;
    exponentiere(sol,n-1);
    g<<sol[1][1];


}










