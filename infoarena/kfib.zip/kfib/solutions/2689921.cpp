#include<fstream>	
#include<bits/stdc++.h>


using namespace std;
const int mod=666013;

ifstream fin ("kfib.in");
ofstream fout ("kfib.out");


int fibonaacci(long long k){
    if (k == 0)
        return 0;

    int f0 = 0, f1 = 1, f2;
    while (k > 0){
        f2 = (f1 + f0) % mod;
        f0 = f1;
        f1 = f2;
    }
    return f1;
}

int main(){

    long long n;
    fin >> n;

    fout << (fibonaacci(n));

    return 0;
}