#include <bits/stdc++.h>
using namespace std;

pair <int, int> fib(int n) {
    if (!n) return {0, 1};
    auto p = fib(n >> 1);
    int c = p.first * (2 * p.second - p.first),
        d = p.first * p.first + p.second * p.second;

    return (n & 1) ? {d, c + d} : {c, d};
}

int main() {
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");

    int n;
    fin >> n;

    fout << fib(n).first;
    return 0;
}