#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");
    int x = 0, y = 1, z, k;
    fin >> k;
    while (k-- % 1332028)
        z = (x + y) % 666013, x = y, y = z;
    fout << x << endl;
    fin.close();
    fout.close();
}


