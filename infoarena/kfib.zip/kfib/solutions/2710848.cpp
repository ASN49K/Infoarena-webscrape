#include <fstream>
#include <cstring>

using namespace std;

ifstream cin("kfib.in");
ofstream cout("kfib.out");

const int mod = 666013;

int mt[3][3], sol[3][3];

void init(){
    mt[0][0] = 0, mt[0][1] = 1;
    mt[1][0] = 1, mt[1][1] = 1;

    sol[0][0] = sol[0][1] = 1;
    sol[1][0] = sol[1][1] = 0;
}

void mult(int a[][3], int b[][3]){
    int s[3][3];
    memset(s, 0, sizeof(s));

    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int k = 0; k < 2; k++)
                s[i][j] = (s[i][j] + 1LL * a[i][k] * b[k][j]) % mod;

    memcpy(a, s, sizeof(s));
}

void solve(int p){
    while(p){
        if(p & 1)
            mult(sol, mt);
        p >>= 1;
        mult(mt, mt);
    }
}

int main()
{
    int n;
    cin >> n;

    init();
    solve(n - 1);
    cout << sol[0][0];

    return 0;
}
