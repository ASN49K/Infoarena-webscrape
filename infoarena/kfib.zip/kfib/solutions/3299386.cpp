#include <fstream>
#include <vector>

using namespace std;

const int N = 2;
const int MOD = 666013;

void produs(vector <vector <int>> &a, vector <vector <int>> &b)
{
    vector <vector <int>> p(N);
    for (int i = 0; i < N; i++)
    {
        p[i].resize(N, 0);
    }
    for (int i = 0; i < N; i++)
    {
        for (int k = 0; k < N; k++)
        {
            for (int j = 0; j < N; j++)
            {
                p[i][k] += (long long)a[i][j] * b[j][k] % MOD;
                if (p[i][k] >= MOD)
                {
                    p[i][k] -= MOD;
                }
            }
        }
    }
    a = p;
}

void putere(vector <vector <int>> &a, int n)
{
    vector <vector <int>> p(N);
    for (int i = 0; i < N; i++)
    {
        p[i].resize(N, 0);
        p[i][i] = 1;
    }
    while (n != 0)
    {
        if (n % 2 != 0)
        {
            produs(p, a);
        }
        produs(a, a);
        n /= 2;
    }
    a = p;
}

int main()
{
    ifstream in("kfib.in");
    ofstream out("kfib.out");
    int n;
    in >> n;
    n--;
    vector <vector <int>> a(N);
    a[0] = {1, 1};
    a[1] = {1, 0};
    putere(a, n - 1);
    out << (a[0][0] + a[0][1]) % MOD << "\n";
    in.close();
    out.close();
    return 0;
}
