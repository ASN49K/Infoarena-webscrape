#include <bits/stdc++.h>
#define MOD 666013
using namespace std;
ifstream fin ("kfib.in");
ofstream fout("kfib.out");
long long sol[2][2],Z[2][2];
int k;
void inmultire_matrici(long long a[2][2], long long b[2][2]){
    long long aux[2][2];
    for(int i=0;i<=1;i++)
    for(int j=0;j<=1;j++){
        aux[i][j]=0;
        for(int k=0;k<=1;k++){
            aux[i][j]+=a[i][k]*b[k][j];
            aux[i][j]%=MOD;
        }
    }
    for(int i=0;i<=1;i++)
    for(int j=0;j<=1;j++)
        a[i][j]=aux[i][j];
}
int main(){
    fin>>k;
    if(k<=2){
        fout<<1;
        return 0;
    }
    k-=2;
    Z[0][0]=Z[0][1]=Z[1][0]=1;
    sol[0][0]=sol[1][1]=1;
    while(k){
        if(k&1)
            inmultire_matrici(sol,Z);
        inmultire_matrici(Z,Z);
        k>>=1;
    }
    fout<<(sol[0][0]+sol[0][1])%MOD;

    return 0;
}
