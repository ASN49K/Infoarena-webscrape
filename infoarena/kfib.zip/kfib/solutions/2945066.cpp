#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
void fib(int k, int &a, int b)
{
    while(k)
    {
        a=(a+b);
        b=(a-b);
        a=a%666013;
        b=b%666013;
        k--;
    }
}
int main()
{
    int k,a=0,b=1;
    fin>>k;
    fib(k,a,b);
    fout<<a;
}
