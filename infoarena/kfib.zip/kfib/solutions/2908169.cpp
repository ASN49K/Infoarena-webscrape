/*
    Programmer : Alexandru Olteanu
*/
#include<bits/stdc++.h>
using namespace std;
// GCC Optimizations
// #pragma GCC optimize("Ofast");
// #pragma GCC target("fma,sse,sse2,sse3,ssse3,sse4,popcnt")
// #pragma GCC target("abm,mmx,avx,avx2,tune=native")
// #pragma GCC optimize(3)
// #pragma GCC optimize("inline")
// #pragma GCC optimize("-fgcse")
// #pragma GCC optimize("-fgcse-lm")
// #pragma GCC optimize("-fipa-sra")
// #pragma GCC optimize("-ftree-pre")
// #pragma GCC optimize("-ftree-vrp")
// #pragma GCC optimize("-fpeephole2")
// #pragma GCC optimize("-ffast-math")
// #pragma GCC optimize("-fsched-spec")
// #pragma GCC optimize("unroll-loops")
// Useful
mt19937 rng((unsigned int) chrono::steady_clock::now().time_since_epoch().count());
#define FastEverything  ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define HighPrecision cout<<fixed<<setprecision(17);
typedef long long ll;
typedef pair<int,int> pii;
ll const mod=1000000007LL;
ll const mod2 = 100000000LL;
ll const md=998244353LL;
ll mypowr(ll a,ll b, ll mod1) {ll res=1;if(b<0)b=0;a%=mod1; assert(b>=0);
for(;b;b>>=1){if(b&1)res=res*a%mod1;a=a*a%mod1;}return res;}
ll mypow(ll a,ll b) {ll res=1;if(b<0)b=0;assert(b>=0);
for(;b;b>>=1){if(b&1)res=res*a;a=a*a;}return res;}
#define pb push_back
#define fi first
#define se second
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(), x.rend()
 
ifstream in("kfib.in");
ofstream out("kfib.out");
#define cin in
#define cout out


/*
    Template created by Alexandru Olteanu
*/

vector<vector<long long> > mul(vector<vector<long long> > a, vector<vector<long long> > b, long long mod)
{
	vector<vector<long long> > res;
	res = a;
	for (int i = 0; i < res.size(); i++)
	{
		for (int j = 0; j < res.size(); j++)
		{
			res[i][j] = 0;
		}
	}
	for (int k = 0; k < res.size(); k++)
	{
		for (int i = 0; i < res.size(); i++)
		{
			for (int j = 0; j < res.size(); j++)
			{
				res[i][j] = (res[i][j] + a[i][k] * b[k][j]) % mod;
			}
		}
	}
	return res;
}

vector<vector<long long> > matrix_power(vector<vector<long long> > a, long long b, long long mod)
{
	if (b == 1)
		return a;
	if (b == 0)
	{
		for (int i = 0; i < a.size(); i++)
		{
			for (int j = 0; j < a.size(); j++)
			{
				a[i][j] = (i == j);
			}
		}
		return a;
	}
 
	if (b % 2)
		return mul(a, matrix_power(a, b - 1, mod), mod);
	return matrix_power(mul(a, a, mod), b / 2, mod);
}

vector<vector<ll>> v(2, vector<ll>(2));

int main()
{
    FastEverything
    HighPrecision
 
    int test = 1;
    // cin >> test;
    for (int tt = 1; tt <= test; ++tt) { 
       int n;
       cin >> n;
       v[0][1] = v[1][0] = v[1][1] = 1;
       v = matrix_power(v, n - 1, 666013);
       cout << v[1][1] << '\n';
    }
 
    return 0;
}