#include <fstream>

using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");

/**
int f(int n) {
    int con = 0;

    for (int i = 1; i <= n; i++) {
        con += i;
    }
    return con;
}

int f_rec(int n) {
    cout << n << endl;
    if (n == 0)  ///REGULA: Prima data, conditia de oprire
        return 0;

    return n + f_rec(n - 1);///Ce se intampla cu nr curent + apelul recursiv
}*/
const int mod = 666013;
int v[20000000];

int fib_n(int n) {
    if (n <= 2)
        return 1;
    if (n < 20000000 && v[n] != 0)
        return v[n];

    v[n] = (fib_n(n - 1) + fib_n(n - 2)) % mod;
    return v[n];
}


int main() {
    int n, con = 0;

    fin >> n;
    fout << fib_n(n) << '\n';

    fin.close();
    fout.close();

    return 0;
}

