#include <fstream>

using namespace std;

const int M = 666013;
const int N = 2;

void kffb(int p[N][N], int a[N][N])
{
    int aux[N][N];
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            ///calculez aux[i][j] = produs scalar intre linia i din p si coloana j din a
            aux[i][j] = 0;
            for (int k = 0; k < N; k++)
            {
                aux[i][j] += (long long)p[i][k] * a[k][j] % M;
                aux[i][j] %= M;
            }
        }
    }
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            p[i][j] = aux[i][j];
        }
    }
}

int fibo(int n)
{
    int a[2][2] = {{1, 1}, {1, 0}};
    int p[2][2] = {{1, 0}, {0, 1}};
    n--;
    while (n != 0)
    {
        int cifb = n % 2;
        if (cifb != 0)
        {
            kffb(p, a);///p *= a pentru matrice
        }
        kffb(a, a);
        n /= 2;
    }
    return p[0][0];
}

int main()
{
    ifstream in("kfib.in");
    ofstream out("kfib.out");
    int k;
    in >> k;
    out << fibo(k);
    in.close();
    out.close();
    return 0;
}
