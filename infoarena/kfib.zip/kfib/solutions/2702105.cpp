#include <iostream>
#include <fstream>
using namespace std;

ifstream in("kfib.in");
ofstream out("kfib.out");
int main()
{
long long f1,f2,f,k,ct;
in>>k;
f1=0;
f2=1;
if(k==0) out<<0;
if(k==1) out<<1;
else{
ct=2;
while(ct<=k){
f=f1+f2;
f1=f2;
f2=f;
++ct;
}
out<<f;
}
    return 0;
}
