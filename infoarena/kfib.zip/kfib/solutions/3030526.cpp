// hatz hatz hatz.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <fstream>

using namespace std;
#define mod 666013
ifstream cin("kfib.in");
ofstream cout("kfib.out");
int n;
void inmultmat(int a[][2], int b[][2])
{
    int aux[2][2] = {
       {0, 0},
       {0, 0}
    };
    for (int i = 0; i < 2; i++)
    {
        for(int j=0; j < 2; j++)
            for (int k = 0; k < 2; k++)
            {
                aux[i][j]= (aux[i][j] + 1ll * a[i][k] * b[k][j]) % mod;
            }
    }
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            a[i][j] = aux[i][j];
}
int putere(long long n)
{
    int m[2][2] = {
       {0, 1},
       {1, 1}
    };
    int z[2][2] = {
           {0, 1},
           {1, 1}
    };
    n -= 2;
    while (n)
    {
         if (n%2 == 1)
         inmultmat(z, m);
         n /= 2;
         inmultmat(m, m);
    }
    return z[1][1];
}
int main()
{
    cin >> n;
    cout << putere(n);
    return 0;
}