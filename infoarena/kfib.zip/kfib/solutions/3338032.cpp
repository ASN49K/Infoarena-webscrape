#include <bits/stdc++.h>
#define MOD 666013
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");
int a[2][2], p[2][2], b[2][2];

/// c = a * b
void Produs(int c[2][2], int a[2][2], int b[2][2])
{
    int i, j, k;
    /// a[i][j] = a[i][0]*b[0][j] + a[i][1]+b[1][j] + ...
    ///       + a[i][n-1]*b[n-1][j]
    for (i = 0; i <= 1; i++)
        for (j = 0; j <= 1; j++)
        {
            c[i][j] = 0;
            for (k = 0; k <= 1; k++)
                c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % MOD;
        }
}

void Copie(int a[2][2], int b[2][2])
{
    a[0][0] = b[0][0];
    a[0][1] = b[0][1];
    a[1][0] = b[1][0];
    a[1][1] = b[1][1];
}

/// matricea A^n
void ExpoLog(int n)
{
    p[0][0] = p[1][1] = 1;
    p[0][1] = p[1][0] = 0;
    a[0][0] = 0;
    a[0][1] = a[1][0] = a[1][1] = 1;

    while (n > 0)
    {
        if (n % 2 == 1)
        {
            ///p = p * a % MOD;
            Produs(b, p, a);
            Copie(p, b);
        }
        n /= 2;
        ///a = a * a % MOD;
        Produs(b, a, a);
        Copie(a, b);
    }
}

int main()
{
    int k;
    fin >> k;
    if (k == 0) fout << "0\n";
    else if (k <= 2) fout << "1\n";
    else
    {
        ExpoLog(k - 1);
        fout << p[1][1] << "\n";
    }
    return 0;
}
