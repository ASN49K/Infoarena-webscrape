#include <bits/stdc++.h>
#define mod 666013

using namespace std;

ifstream fin ("kfib.in");
ofstream fout ("kfib.out");

const int DIM = 5;

long long pwr[DIM][DIM], sol[DIM][DIM], aux[DIM][DIM];

void mult(long long a[DIM][DIM], long long b[DIM][DIM], long long c[DIM][DIM])
{
    for(int i = 1; i <= 2; ++i) {
        for(int j = 1; j <= 2; ++j) {
            for(int k = 1; k <= 2; ++k) {
                c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % mod;
            }
        }
    }
}
void exp(long long b)
{
    pwr[1][1] = 0, pwr[1][2] = 1, pwr[2][1] = 1, pwr[2][2] = 1;
    sol[1][1] = 1, sol[2][2] = 1;
    while(b > 0) {
        if(b & 1) {
            memset(aux, 0, sizeof(aux));
            mult(sol, pwr, aux);
            memcpy(sol, aux, sizeof(aux));
        }
        memset(aux, 0, sizeof(aux));
        mult(pwr, pwr, aux);
        memcpy(pwr, aux, sizeof(aux));
        b >>= 1;
    }
}

int main()
{
    long long n;

    fin >> n;
    exp(n - 1);
    fout << (sol[2][2] + mod) % mod;
    return 0;
}
