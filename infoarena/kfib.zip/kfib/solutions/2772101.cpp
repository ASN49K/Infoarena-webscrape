#include<bits/stdc++.h>
using namespace std;
ifstream fin("carnati.in");
ofstream fout("carnati.out");
int t[1501],spart[1501],pmax;
int main()
{
    int n,c,x;
    fin>>n>>c;
    for(int i=1;i<=n;i++)
    {
        fin>>x>>t[x];
    }
    for(int i=1;i<=n;i++)
        spart[i]=spart[i-1]+t[i];
    for(int i=1;i<=n;i++)
        for(int j=i;j<=n;j++)
            if(pmax<spart[j]-spart[i-1]-c*(j-i+1))
                pmax=spart[j]-spart[i-1]-c*(j-i+1);
    fout<<pmax;
}
