#include <bits/stdc++.h>
using namespace std;

#define MOD 666013
typedef long long ll;

ifstream in("kfib.in");
ofstream out("kfib.out");

int main()
{
    int k, cnt = 1;
    in >> k;
    ll j = 1;
    for(ll i = 0; cnt < k; j+=(i%MOD), i = (j-i)%MOD, cnt++);
    out << j%MOD;


    return 0;
}
