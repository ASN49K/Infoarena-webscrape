#include <fstream>
#include <vector>
using namespace std;

vector<vector<int>> matrix_multiplication(vector<vector<int>> a, vector<vector<int>> b) {
    vector<vector<int>> mul(2, vector<int>(2, 0));
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++) {
                mul[i][j] += (1LL * a[i][k] * b[k][j]);
                mul[i][j] %= 666013;
            }
        }
    }
    return mul;
}
vector<vector<int>> matrix_to_pow(vector<vector<int>> m, int pow) {
    if (pow == 1) {
        return m;
    }
    vector<vector<int>> half_pow = matrix_to_pow(m, pow/2);
    if (pow % 2 == 1) {
        return matrix_multiplication(half_pow, matrix_multiplication(half_pow, m));
    } else {
        return matrix_multiplication(half_pow, half_pow);
    }
}
int main() {
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");
    int k;
    fin >> k;
    vector<vector<int>> f;
    vector<int> row1; row1.push_back(0); row1.push_back(1); f.push_back(row1);
    vector<int> row2; row2.push_back(1); row2.push_back(1); f.push_back(row2);
    vector<vector<int>> result = matrix_to_pow(f, k - 1);
    
    int fib_k = (result[0][0] * 1 + result[0][1] * 1) % 666013;
    fout << fib_k;
    
    
}