#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) (a).begin(), (a).end()
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define rc(s) return cout<<s,0
#define pi pair <int, int>
#define sz(x) (int)((x).size())
#define int long long

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

const ll inf = 2e9;
const ll mod = 666013;
const int N = 1 + 11;
const int NMAX = 1e4 + 11;
const ll INF64 = 3e18 + 1;
const double eps = 1e-14;
const double PI = acos(-1);

ifstream in("kfib.in");
ofstream out("kfib.out");

int n, a[N][N], ans[N][N], b[N][N];



void mult1(){

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            for(int k = 0; k < 2; k++){
                b[i][j] += ans[i][k]*a[k][j];
                b[i][j] %= mod;
            }
        }
    }

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            ans[i][j] = b[i][j];
            b[i][j] = 0;
        }
    }

}

void mult2(){

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            for(int k = 0; k < 2; k++){
                b[i][j] += a[i][k]*a[k][j];
                b[i][j] %= mod;
            }
        }
    }

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            a[i][j] = b[i][j];
            b[i][j] = 0;
        }
    }

}
void poww(int p){

    while(p){

        if(p % 2)mult1();
        mult2();
        p /= 2;

    }
}

int32_t main(){
ios_base :: sync_with_stdio(0); cin.tie(); cout.tie();

    //cout << setprecision(20) << fixed;

    in >> n;

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            ans[i][j] = (i == j ? 1 : 0);
            a[i][j] = (i == 0 && j == 0 ? 0 : 1);
        }
    }

    poww(n - 2);

    out << ans[0][1] + ans[1][1];
}
