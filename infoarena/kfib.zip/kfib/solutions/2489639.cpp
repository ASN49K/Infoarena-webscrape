#include <bits/stdc++.h>

using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
struct matrice{long long int m[2][2];};
int n;
matrice im;
matrice inmultire(matrice a,matrice b);
matrice pow(matrice a,long long int n);
int main()
{
    fin>>n;
    matrice m1;
    m1.m[1][1]=0;
    m1.m[1][0]=m1.m[0][1]=m1.m[0][0]=1;
    im.m[0][0]=im.m[1][1]=1;
    im.m[1][0]=im.m[0][1]=0;
    if(n<=1)
        return 1;
    else
    {
        matrice r;
        r.m[0][1]=r.m[1][1]=0;
        r.m[0][0]=r.m[1][0]=1;
        m1=pow(m1,n-2);
        matrice ans=inmultire(m1,r);
        fout<<ans.m[0][0];
    }
    return 0;
}
matrice inmultire(matrice a,matrice b)
{
    int i,j,k;
    matrice rezultat;
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            rezultat.m[i][j]=0;
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            for(k=0;k<2;k++)
                rezultat.m[i][j]=(rezultat.m[i][j]+a.m[i][k]*b.m[k][j]%666013)%666013;
    return rezultat;

}
matrice pow(matrice a,long long int n)
{
    if(n==0)
        return im;
    if(n%2!=0)
        return inmultire(a,pow(inmultire(a,a),(n-1)/2));
    return pow(inmultire(a,a),n/2);

}
