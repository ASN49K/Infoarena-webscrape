#include <bits/stdc++.h>
#define mod 666013

using namespace std;

ifstream fin ("kfib.in");
ofstream fout ("kfib.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

long long pwr[3][3], sol[3][3], aux[3][3];

void mult(long long a[3][3], long long b[3][3], long long c[3][3])
{
    for(int i = 1; i <= 2; ++i) {
        for(int j = 1; j <= 2; ++j) {
            for(int k = 1; k <= 2; ++k) {
                c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % mod;
            }
        }
    }
}

void exp(long long b)
{
    pwr[1][1] = 0, pwr[1][2] = 1;
    pwr[2][1] = 1, pwr[2][2] = 1;
    sol[1][1] = 1, sol[2][2] = 1;
    while(b) {
        if(b & 1) {
            memset(aux, 0, sizeof(aux));
            mult(sol, pwr, aux);
            memcpy(sol, aux, sizeof(aux));
        }
        memset(aux, 0, sizeof(aux));
        mult(pwr, pwr, aux);
        memcpy(pwr, aux, sizeof(aux));
        b >>= 1;
    }
}

int main()
{
    usain_bolt();

    long long n;

    fin >> n;
    exp(n - 1);
    fout << (sol[2][2] + mod) % mod;
    return 0;
}
