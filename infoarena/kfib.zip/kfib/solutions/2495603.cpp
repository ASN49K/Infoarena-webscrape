#include <fstream>
#include <vector>
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
long long n,mat[100][5][5],i,j,m,mod=666013;
void prod(long long a[5][5],long long b[5][5],long long c[5][5])
{
    int i,j,k;
    for(i=1; i<=2; i++)
        for(j=1; j<=2; j++)
            for(k=1; k<=2; k++)
                c[i][j]=(c[i][j]+a[i][k]*b[k][j])%mod;
}
void exp(int n,int k)
{
    if(n>1)
    {
        if(n%2==1)
        {
            exp(n-1,k+1);
            prod(mat[m],mat[k+1],mat[k]);
        }
        else
        {
            exp(n/2,k+1);
            prod(mat[k+1],mat[k+1],mat[k]);
        }
    }
    else
    {
        mat[k][1][2]=mat[k][2][1]=mat[k][2][2]=1;
        m=k;
    }
}
int main()
{
    f>>n;
    if(n==0||n==1)
        g<<1;
    else {
    exp(n-2,1);
    g<<(mat[1][1][2]+mat[1][2][2])%mod;
    }
    return 0;
}
