#include <iostream>
#include <fstream>
#define LL long long
#define MOD 666013
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");

typedef long long mat[4];
void mul(mat a, mat x){
    mat s;
    s[0]=a[0]*x[0]+a[1]*x[2];
    s[1]=a[0]*x[1]+a[1]*x[3];
    s[2]=a[2]*x[0]+a[3]*x[2];
    s[3]=a[2]*x[1]+a[3]*x[3];
    a[0]=s[0]%MOD;
    a[1]=s[1]%MOD;
    a[2]=s[2]%MOD;
    a[3]=s[3]%MOD;
}

int main(){
    int n;
    mat a={1,0,0,1};
    mat x={0,1,1,1};
    fin>>n; n--;
    while(n){
        if(n%2) mul(a,x);
        mul(x,x);
        n/=2;
    }
    fout<<a[3];
    return 0;
}
