#include <fstream>
#include <vector>
#include <iostream>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

typedef vector < vector < int > > Mat;

const int len = 2;
const int mod = 666013;

int n;
Mat aux, r;

void Resize(Mat &a)
{
    a.resize(len);

    for (int i = 0; i < len; i++)
        a[i].resize(len);

}

Mat Inmultire(Mat a, Mat b)
{
    Mat c;

    Resize(c);

    for (int i = 0; i < len; i++)
    {
        for (int j = 0; j < len; j++)
        {
            for (int k = 0; k < len; k++)
            {
                c[i][j] += (1LL * a[i][k] * b[k][j]) % mod;
            }
        }
    }

    return c;
}

int main()
{
    fin >> n;
    n--;

    Resize(aux);
    Resize(r);

    aux[0][0] = aux[1][1] = 1;
    r[0][1] = r[1][0] = r[1][1] = 1;

    while (n > 1)
    {
        if (n % 2)
        {
            aux = Inmultire(aux, r);
        }

        r = Inmultire(r, r);

        n /= 2;
    }

    r = Inmultire(aux, r);

    fout << r[1][1] % mod;

    fin.close();
    fout.close();
    return 0;
}