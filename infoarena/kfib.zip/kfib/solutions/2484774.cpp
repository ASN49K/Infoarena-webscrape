#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");


const int MOD=666013;

int A[2][2]= {{1, 1},{1, 0}};
int I[2][2]= {{1, 0},{0, 1}};

void multmat(int a[][2], int b[][2])
{
    int c[2][2];
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            c[i][j]=0;
            for(int k=0; k<2; k++)
                c[i][j]=(c[i][j]+1LL * a[i][k]*b[k][j])%MOD;
        }
    memcpy(a, c, sizeof(c));
}

void puteremat(int p)
{
    while(p>0)
        if(p%2==0)
        {
            multmat(A, A);
            p/=2;
        }

        else
        {
            multmat(I,A);
            p--;
        }
}




int main()
{
    int k;
    f>>k;
    if(k<=1)
        g<<k;
    else
    {
        puteremat(k-1);
        g<<I[0][0];
    }
    return 0;
}
