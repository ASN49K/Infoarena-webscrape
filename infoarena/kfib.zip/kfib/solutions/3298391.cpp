/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");


int main() {
    long long Z_curr[2][2], Z_prev[2][2];
    int M1[1][2], Z1[2][2] = {{0, 1},{1, 1}};
    M1[0][0] = 0;
    M1[0][1] = 1;
    long long k;
    fin>>k;

    Z_prev[0][0] = Z1[0][0];
    Z_prev[0][1] = Z1[0][1];
    Z_prev[1][0] = Z1[1][0];
    Z_prev[1][1] = Z1[1][1];
    
    while(k>2){
        Z_curr[0][0] = (Z_prev[0][0] % 666013) * Z1[0][0] + (Z_prev[0][1] % 666013) * Z1[1][0];
        Z_curr[0][1] = (Z_prev[0][0] % 666013) * Z1[0][1] + (Z_prev[0][1] % 666013) * Z1[1][1];
        Z_curr[1][0] = (Z_prev[1][0] % 666013) * Z1[0][0] + (Z_prev[1][1] % 666013) * Z1[1][0];
        Z_curr[1][1] = (Z_prev[1][0] % 666013) * Z1[0][1] + (Z_prev[1][1] % 666013) * Z1[1][1];
        
        Z_prev[0][0] = Z_curr[0][0];
        Z_prev[0][1] = Z_curr[0][1];
        Z_prev[1][0] = Z_curr[1][0];
        Z_prev[1][1] = Z_curr[1][1];
        
        k--;
    }
    
    long long rez = M1[0][0] * (Z_curr[0][1] % 666013) + M1[0][1] * (Z_curr[1][1] % 666013);
    fout<<(rez % 666013);
    

	return 0;
}
