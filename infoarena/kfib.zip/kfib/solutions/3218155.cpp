#include <bits/stdc++.h>

#define MOD 666013

using namespace std;

//ifstream f("in.in");
//ofstream g("out.out");

ifstream f("kfib.in");
ofstream g("kfib.out");

int t;
int n;

int p[2][2];
int a[2][2];
int b[2][2];

void inmultire(int rez[2][2],int a[2][2],int b[2][2]){

    for(int i=0;i<=1;i++){
        for(int j=0;j<=1;j++){
            rez[i][j] = 0;
            for(int k=0;k<=1;k++){
                rez[i][j] = (1ll*rez[i][j] + 1ll*a[i][k]*b[k][j])%MOD;
            }
        }
    }
}

void copiere(int rez[2][2],int a[2][2]){
    for(int i=0;i<=1;i++){
        for(int j=0;j<=1;j++){
            rez[i][j] = a[i][j];
        }
    }
}

signed main()
{

    f>>n;

    int p[2][2] = {
        {1,1},
        {1,0}
    };

    int a[2][2] = {
        {1,0},
        {0,1}
    };

    n-=2;

    while(n!=0){
        if(n&1){
            inmultire(b,p,a);
            copiere(a,b);
        }
        n/=2;

        inmultire(b,p,p);
        copiere(p,b);
    }

    g<<(a[0][0]+a[1][0])%MOD;

    return 0;
}
