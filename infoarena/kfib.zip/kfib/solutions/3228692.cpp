#import<fstream>
std::fstream f("kfib.in"),g("kfib.out",std::_S_out);int x,y=1,k;main(){for(f>>k;k--%1332028;x=y-x,y%=666013)y+=x;g<<x;}