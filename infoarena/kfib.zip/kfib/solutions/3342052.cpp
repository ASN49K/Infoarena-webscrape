#include <iostream>

#define MOD 666013U

int main()
{
    int n;
    int t[2][2] = {{0, 1}, {1, 1}}, t_pow_n[2][2] = {{1, 0}, {0, 1}}, tmp[2][2];

    freopen("kfib.in", "r", stdin);
    freopen("kfib.out", "w", stdout);

    std::cin >> n;

    if (n == 0) {
        std::cout << 0 << '\n';

        return 0;
    }

    if (n == 1 || n == 2) {
        std::cout << 1 << '\n';

        return 0;
    }

    --n;

    while (n) {
        if (n & 1) {
            tmp[0][0] = (1LL * t[0][0] * t_pow_n[0][0] + 1LL * t[0][1] * t_pow_n[1][0]) % MOD;
            tmp[0][1] = (1LL * t[0][0] * t_pow_n[0][1] + 1LL * t[0][1] * t_pow_n[1][1]) % MOD;
            tmp[1][0] = (1LL * t[1][0] * t_pow_n[0][0] + 1LL * t[1][1] * t_pow_n[1][0]) % MOD;
            tmp[1][1] = (1LL * t[1][0] * t_pow_n[0][1] + 1LL * t[1][1] * t_pow_n[1][1]) % MOD;

            for (int i = 0; i < 2; ++i)
                for (int j = 0; j < 2; ++j)
                    t_pow_n[i][j] = tmp[i][j];
        }

        tmp[0][0] = (1LL * t[0][0] * t[0][0] + 1LL * t[0][1] * t[1][0]) % MOD;
        tmp[0][1] = (1LL * t[0][0] * t[0][1] + 1LL * t[0][1] * t[1][1]) % MOD;
        tmp[1][0] = (1LL * t[1][0] * t[0][0] + 1LL * t[1][1] * t[1][0]) % MOD;
        tmp[1][1] = (1LL * t[1][0] * t[0][1] + 1LL * t[1][1] * t[1][1]) % MOD;

        for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 2; ++j)
                t[i][j] = tmp[i][j];

        n >>= 1;
    }

    std::cout << t_pow_n[1][1] << '\n';

    return 0;
}
