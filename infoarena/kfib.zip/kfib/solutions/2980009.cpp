#include <fstream>
#include <cmath>
using namespace std;

ifstream cin("kfib.in");
ofstream cout("kfib.out");

int main()
{
    double n;
    cin>>n;
    double c=sqrt(5);
    cout<<int(( pow(((1+c)/2), n) - pow(((1-c)/2), n))/c)%666013;
    return 0;
}
