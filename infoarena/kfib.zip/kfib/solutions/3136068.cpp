#include <iostream>
#include <fstream>

#define MOD 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

void inmultireMatrice(long long a[][2], long long b[][2]) {
    long long c[2][2];
    c[0][0] = (a[0][0] * b[0][0] + a[0][1] * b[1][0]) % MOD;
    c[0][1] = (a[0][0] * b[0][1] + a[0][1] * b[1][1]) % MOD;
    c[1][0] = (a[1][0] * b[0][0] + a[1][1] * b[1][0]) % MOD;
    c[1][1] = (a[1][0] * b[0][1] + a[1][1] * b[1][1]) % MOD;

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            a[i][j] = c[i][j];
        }
    }
}

int main() {
    int n;
    fin >> n;

    long long a[2][2] = {{1, 1}, {1, 0}};
    long long b[2][2] = {{1, 1}, {1, 0}};

    n -= 2;

    while (n > 0) {
        if (n & 1) {
            inmultireMatrice(b, a);
        }
        n /= 2;
        inmultireMatrice(a, a);
    }

    fout << b[0][0] << "\n";

    return 0;
}
