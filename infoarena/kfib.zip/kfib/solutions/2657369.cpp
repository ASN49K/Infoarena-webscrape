#include<iostream>
#include<fstream>
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
const int64_t MOD = 666013;
struct matrix
{
    int64_t a[2][2];
    matrix()
    {
        for(int i=0;i<2;i++)
            for(int j=0;j<2;j++)
                a[i][j]=0;
    }
    matrix(int a00,int a01,int a10,int a11)
    {
        a[0][0]=a00;
        a[0][1]=a01;
        a[1][0]=a10;
        a[1][1]=a11;
    }
};
matrix operator*(matrix A,matrix B)
{
    matrix R;
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            for(int k=0;k<2;k++)
                R.a[i][j]=(R.a[i][j]+A.a[i][k]*B.a[k][j])%MOD;
    return R;
}
matrix operator^(matrix A,int n)
{
    if(n==0)
        return matrix(1,0,0,1);
    matrix R=A^(n/2);
    R=R*R;
    if(n%2==1)R=R*A;
    return R;
}
int main()
{
    int n;
    f>>n;
    g<<(matrix(1,1,1,0)^n).a[0][1];
    return 0;
}
