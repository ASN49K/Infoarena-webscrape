#include <fstream>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int k, MOD = 666013, M[2][2], R[2][2], Q[2][2];

void inm(int A[2][2], int B[2][2], int C[2][2])
{
    for(int i = 0; i < 2; i++)
        for(int j = 0 ; j < 2; j++)
            Q[i][j] = 0;
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            for(int k = 0; k < 2; k++)
            {
                C[i][j] += (1LL * A[i][k] * B[k][j]) % MOD;
            }
        }
    }
}

int main()
{
    fin >> k;
    M[0][0] = 1;
    M[0][1] = 1;
    M[1][0] = 1;
    R[0][0] = 1;
    R[1][1] = 1;
    k -= 2;
    while(k > 1)
    {
        if(k % 2 == 0)
        {
            inm(M, M, Q);
            for(int i = 0; i < 2; i++)
                for(int j = 0; j < 2; j++)
                    M[i][j] = Q[i][j];

            k /= 2;
        }
        else
        {
            inm(R, M, Q);
            for(int i = 0; i < 2; i++)
                for(int j = 0; j < 2; j++)
                    R[i][j] = Q[i][j];
            k--;
        }
    }
    inm(M, R, Q);
    fout << (Q[0][0] + Q[0][1]) % MOD;

    return 0;
}
