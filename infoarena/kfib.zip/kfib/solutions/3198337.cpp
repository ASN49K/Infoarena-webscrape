#include <fstream>
using namespace std;

ifstream fin ("kfib.in");
ofstream fout ("kfib.out");

int Sol[3][3], M[3][3];

const int MOD = 666013;

void Multiply (int A[][3], int B[][3])
{
    long long C[3][3];

    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < 2; k++)
            {

                C[i][j] = (C[i][j] + 1LL * A[i][k] * B[k][j]) % MOD;
            }

        }

    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            A[i][j] = C[i][j];
}

int main()
{

    int k;
    fin >> k;
    Sol[0][1] = 1;
    M[0][1] = M[1][1] = M[1][0] = 1;
    while (k)
    {
        if (k % 2 == 1)
            Multiply(Sol, M);
        Multiply(M,M);
        k = k / 2;
    }

    fout << Sol[0][0] << '\n';

    fin.close();
    fout.close();

    return 0;
}
