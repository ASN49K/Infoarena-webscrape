#include <stdio.h>
#include <stdlib.h>

long long adunare(long long mat[2][2], long long mod)
{
    long long aux[2][2] = {{0,0},{0,0}};
    aux[0][1] = (mat[0][0]) % mod;
    aux[1][0] = (mat[0][0]) % mod;
    aux[1][1] = (mat[0][1]) % mod;
    aux[0][0] = (aux[0][1] + aux[1][1]) % mod;
    mat[0][0] = aux[0][0];
    mat[0][1] = aux[0][1];
    mat[1][0] = aux[1][0];
    mat[1][1] = aux[1][1];
}

long long ridicare(long long mat[2][2],long long mod, long long k)
{
    for(long long i=3;i<=k;i++)
    {
        adunare(mat,mod);
    }
}

int main()
{
    FILE *fin, *fout;
    fin = fopen("kfib.in","r");
    fout = fopen("kfib.out","w");
    long long k;
    long long mod = 666013;
    long long Z[2][2] = {{2,1},{1,1}};
    fscanf(fin,"%lld",&k);
    if(k==0)
        fprintf(fout,"%d",0);
    else
    {
        if(k == 2 || k == 1)
            fprintf(fout,"%d",1);
        else
            ridicare(Z,mod,k);
    }
    fprintf(fout,"%d",Z[0][1]);
    fclose(fin);
    fclose(fout);
}