#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
const int MOD=666013;
void prod(int a[2][2],int b[2][2])
{
    int c[2][2];
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            c[i][j]=0;
        }
    }
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            for(int k=0;k<2;k++)
            {
                c[i][j]=static_cast<int>((c[i][j]+1LL*a[i][k]*b[k][j])%MOD);
            }
        }
    }
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            a[i][j]=c[i][j];
        }
    }
}
int solve(int k)
{
    int ans[2][2];
    ans[0][0]=ans[1][1]=1;
    ans[0][1]=ans[1][0]=0;
    int base[2][2];
    base[0][0]=0;
    base[1][0]=base[0][1]=base[1][1]=1;
    while(k)
    {
        if(k%2==1)
        {
            prod(ans,base);
        }
        prod(base,base);
        k/=2;
    }
    return ans[1][0];
}
signed main()
{
    int k;
    fin>>k;
    fout<<solve(k);
    return 0;
}
