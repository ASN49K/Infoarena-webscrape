#include <fstream>
#define mod 666013

using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

int k;
int a,b,c;

int main()
{
    f>>k;
    k%=mod*2+2;
    a=b=c=1;
    for (int i=3;i<=k;i++)
    {
        c=(a+b)%mod;
        a=b;
        b=c;
    }
    g<<c;
    return 0;
}
