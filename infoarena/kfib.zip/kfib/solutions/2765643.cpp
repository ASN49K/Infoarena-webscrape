#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
string __fname = "kfib"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define sz(x)(int) x.size()
#define pb(x) push_back(x)
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define ss cout << " "
#define nn cout << "\n"
#define ct(x) cout << (x)
#define cts(x) cout << (x) << " "
#define ctn(x) cout << (x) << "\n"
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
#define rt return
#define mat(name,x,n,m) vector <vector <x> > name (m, vector <x> (m));
#define _mat(x) vector <vector <x> >
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
const int64 mod = 666013;
const double pi = 3.14159265359;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
int64 fib[2][2] = {
    {1, 1},
    {0, 0}
};
int64 mul[2][2] = {
    {0, 1},
    {1, 1}
};
int64 fib2[2][2] = {
    {0, 1},
    {1, 1}
};

void solve(int id){

    rt;
}

void mult (int64 a[2][2], int64 b[2][2]) {
    	
    int64 x = a[0][0] * b[0][0] + a[0][1] * b[1][0];
    int64 y = a[0][0] * b[0][1] + a[0][1] * b[1][1];
    int64 z = a[1][0] * b[0][0] + a[1][1] * b[1][0];
    int64 w = a[1][0] * b[0][1] + a[1][1] * b[1][1];
    a[0][0] = x % mod;
    a[0][1] = y % mod;
    a[1][0] = z % mod;
    a[1][1] = w % mod;
}

void pw (int64 a[2][2], int k) {
    if (k <= 1) return;
    pw(a, k / 2);
    mult(a, a);
    if (k % 2 == 1) {
        mult(a, mul);
    }
}

int main(){
    ios_base::sync_with_stdio(0);cin.tie(0); ct(fixed); ct(setprecision(10)); 
    int k;
    cin >> k;
    if (k == 0) {
        ctn(0);
        return 0;
    }
    pw(fib2, k-1);
    mult(fib, fib2);
    ctn(fib[0][0]);
    rt 0;
}