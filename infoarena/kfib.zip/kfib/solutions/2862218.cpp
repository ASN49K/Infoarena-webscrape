#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int a[2][2], p[2][2], b[2][2], n;

void inmultire(int a[2][2], int b[2][2], int c[2][2])
{
    int i, j, k;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2; j++)
    {
        c[i][j] = 0;
        for (k = 0; k < 2; k++)
            c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % 666013;
    }
}

void lgput(int n)
{
    p[0][0] = p[1][1] = 1;
    p[0][1] = p[1][0] = 0;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            inmultire(p, a, b);
            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 2; j++)
                    a[i][j] = b[i][j];
        }
        n /= 2;
        inmultire(a, a, b);
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                a[i][j] = b[i][j];
    }
}

int main()
{
    fin >> n;
    a[0][0] = 0; a[0][1] = 1; a[1][0] = 1; a[1][1] = 1;
    lgput(n - 2);
    int sol = (p[0][1] + p[1][1]) % 666013;
    fout << sol << "\n";
    return 0;
}
