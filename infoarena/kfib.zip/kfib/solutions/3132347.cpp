#include <cstdio>
#include <cstring>
#define mod 666013

using namespace std;

int num;
int init[3][3], sol[3][3];

inline void mult(int arr[][3], int B[][3], int temp[][3]) {
    int i, j, k;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2; j++)
            for (k = 0; k < 2; k++)
                temp[i][j] = (temp[i][j] + 1LL * arr[i][k] * B[k][j]) % mod;

}

inline void lg_power(int num, int arr[][3]) {
    int coef[3][3], temp[3][3], i;

    memcpy(coef, init, sizeof(init));
    arr[0][0] = arr[1][1] = 1;

    for (i = 0; (1 << i) <= num; i++) {
        if (num & (1 << i)) {
            memset(temp, 0, sizeof(temp));
            mult(arr, coef, temp);
            memcpy(arr, temp, sizeof(temp));
        }

        memset(temp, 0, sizeof(temp));
        mult(coef, coef, temp);
        memcpy(coef, temp, sizeof(coef));
    }
}

int main() {
    freopen("kfib.in", "r", stdin);
    freopen("kfib.out", "w", stdout);

    scanf("%d", &num);

    init[0][0] = 0; init[0][1] = 1; init[1][0] = 1; init[1][1] = 1;

    lg_power(num - 1, sol);

    printf("%d\n", sol[1][1]);

    return 0;
}