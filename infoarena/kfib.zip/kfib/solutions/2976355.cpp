#include <fstream>
#define mod 666013
#define ll 1LL

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

void produs(int a[][3], int b[][3], int sol[][3])
{
    sol[0][0]=(ll*a[0][0]*b[0][0] + ll*a[0][1]*b[1][0])%mod;
    sol[0][1]=(ll*a[0][0]*b[0][1] + ll*a[0][1]*b[1][1])%mod;
    sol[1][0]=(ll*a[1][0]*b[0][0] + ll*a[1][1]*b[1][0])%mod;
    sol[1][1]=(ll*a[1][0]*b[0][1] + ll*a[1][1]*b[1][1])%mod;
}

void atribuire(int a[][3], int b[][3])
{
    for(int i=0; i<3; i++)
        for(int j=0; j<3; j++)
        a[i][j]=b[i][j];
}

void putere(int n, int unit[][3], int init[][3], int sol[][3])
{
    while(n>0)
    {
        if(n&1)
        {
            produs(unit, init, sol);
            atribuire(unit, sol);
        }

        produs(init, init, sol);
        atribuire(init, sol);

        n/=2;
    }
}

int k;

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);

    fin>>k;

    fin.close();

    int unit[3][3], init[3][3], sol[3][3];

    unit[0][0]=1, unit[0][1]=0, unit[1][0]=0, unit[1][1]=1;
    init[0][0]=1, init[0][1]=1, init[1][0]=1, init[1][1]=0;

    putere(k, unit, init, sol);

    fout<<unit[0][1];

    fout.close();

    return 0;
}
