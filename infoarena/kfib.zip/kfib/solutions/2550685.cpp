#include <stdio.h>
#define MOD 666013
long long m[2][2]={{0,1},{1,1}},r[2][2]={{0,1},{1,1}};

void multiply_matrix(long long a[2][2], long long b[2][2], long long (&dest)[2][2]){
  long long c[2][2];
  for(int i=0; i<2; i++)
    for(int j=0; j<2; j++){
      c[i][j]=0;
      for(int k=0; k<2; k++)
        c[i][j]=(c[i][j]+a[i][k]*b[k][j]%MOD)%MOD;
    }
  for(int i=0; i<2; i++)
    for(int j=0; j<2; j++)
      dest[i][j]=c[i][j];
}

void fast_exp(int pow){
  while(pow){
    if(pow%2)
      multiply_matrix(r,m,r);
    multiply_matrix(m,m,m);
    pow/=2;
  }
}

int main(){
  FILE *fin=fopen("kfib.in","r");
  FILE *fout=fopen("kfib.out","w");
  int n;

  fscanf(fin,"%d",&n);
  fast_exp(n-2);
  fprintf(fout,"%lld\n",r[1][1]);
  fclose(fin);
  fclose(fout);
  return 0;
}
