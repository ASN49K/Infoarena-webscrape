#include <stdio.h>
#define MOD 666013

int M[2][2] = {{0, 1}, {1, 1}}; //baza
int P[2][2] = {{1, 1}, {1, 1}}; //puterea intermediara
int rez[2][2]; //rezultatul inmultirii
int F[1][2] = {{0, 1}};


void mul( int A[2][2], int B[2][2], int n, int m, int l ) { //n x m, m x l
  int i, j, k;
  
  for ( i = 0; i < 2; ++i ) {
    for ( j = 0; j < 2; ++j ) {
	  rez[i][j] = 0; 
	}
  }
  for ( i = 0; i < n; ++i ) {
    for ( j = 0; j < l; ++j ) {
	  for ( k = 0; k < m; ++k ) {
		rez[i][j] = (rez[i][j] + 1LL * A[i][k] * B[k][j]) % MOD;
	  }
	}
  }
}
void moveAtoB( int A[2][2], int B[2][2], int n, int m ) {
  int i, j;

  for ( i = 0; i < n; ++i ) {
	for ( j = 0; j < m; ++j ) {
	  B[i][j] = A[i][j];
	}
  }
}
void quickExp( int n ) {
  while ( n > 0 ) {
    if ( n % 2 == 1 ) {
      mul( P, M, 2, 2, 2 );
      moveAtoB( rez, P, 2, 2 );
    }	    
	mul( M, M, 2, 2, 2 );
	moveAtoB( rez, M, 2, 2 );
    n /= 2;
  }
}

int main() {
  FILE *fin = fopen( "kfib.in", "r" );
  FILE *fout = fopen( "kfib.out", "w" ); 
  int n, i, j;
    
  fscanf( fin, "%d", &n );
  quickExp( n - 1 );
  mul( F, P, 1, 2, 2 );
  for ( i = 0; i < 2; ++i ) {
	for ( j = 0; j < 2; ++j ) {
      printf( "%d ", P[i][j] );
	}
	printf( "\n" );
  }
  fprintf( fout, "%d", rez[0][0] );
  fclose( fin );
  fclose( fout );
  return 0;
}
