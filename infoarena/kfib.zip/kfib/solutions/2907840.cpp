#include <bits/stdc++.h>
#define MOD 666013
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int n;
int ans[2][2],a[2][2];


void Inm(int ans[2][2], int a[2][2])
{
    long long c[2][2];
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++){
            c[i][j] = 0;
            for(int k = 0; k < 2; k++)
                c[i][j] += 1LL * ans[i][k] * a[k][j];
        }
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            ans[i][j] = c[i][j] % MOD;
}

void LogPut(int k)
{
    while(k > 0)
    {
        if((k & 1)) Inm(ans, a);
        k >>= 1;
        Inm(a, a);
    }
}

int main()
{
    fin >> n;

    a[0][0] = 0;
    a[0][1] = a[1][0] = a[1][1] = 1;
    ans[0][0] = ans[0][1] = 1; ans[1][0] = ans[1][1] = 0;
    LogPut(n - 1);
    fout << ans[0][0] << "\n";
    fin.close();
    fout.close();
    return 0;
}
