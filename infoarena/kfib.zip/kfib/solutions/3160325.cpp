#include <fstream>
#include <iostream>
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
const int MOD = 666013, P = 1332028;

int Fibonacci(int n) {
    if(n == 0) return 0;
    int f0 = 0, f1 = 1, f2;
    for(int i = 2; i <= n; i++) {
        f2 = (f0 + f1) % MOD;
        f0 = f1;
        f1 = f2;
    }
    return f1;
}

int main() {
    int k;
    f >> k;
    g << Fibonacci(k % P);
    f.close();
    g.close();
}