#include<fstream>
using namespace std;
int main()
{
	fstream in("kfib.in",ios::in),out("kfib.out",ios::out);
    int x=0,y=1,z,k;
    in>>k;
    while(k--%1332028)z=(x+y)%666013,x=y,y=z;
    out<<x<<endl;
}
