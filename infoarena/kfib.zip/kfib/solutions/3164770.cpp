#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");

int fib(int n)
{
    int a = 0, c, i;
    long long b=1;
    if (n == 0)
        return a;
    for (i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

int main()
{
    int n; fin>>n; fout<<fib(n-1);
    return 0;
}
