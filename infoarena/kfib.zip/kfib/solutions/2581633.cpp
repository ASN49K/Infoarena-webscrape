#include <bits/stdc++.h>

using namespace std;

int MOD = 666013;

void mulMatrix(int A[2][2], int B[2][2]) {
    int C[2][2];
    for (int i = 0; i < 2; ++i) {
        for (int  j = 0; j < 2; ++j) {
            C[i][j] = 0;
            for (int k = 0; k < 2; ++k) {
                C[i][j] = (int) ((C[i][j] + 1LL * A[i][k] * B[k][j]) % MOD);
            }
        }
    }
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            A[i][j] = C[i][j];
        }
    }
}

void fastExp(int A[2][2], int k) {
    int result[2][2] = {{1, 0}, {0, 1}};
    while (k) {
        if (k % 2 == 1) {
            mulMatrix(result, A);
        }
        mulMatrix(A, A);
        k /= 2;
    }
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            A[i][j] = result[i][j];
        }
    }
}

int main()
{
    ifstream fin ("kfib.in");
    ofstream fout ("kfib.out");
    int A[2][2] = {{0, 1}, {1, 1}};
    int k;
    fin >> k;
    fastExp(A, k);
    fout << A[1][0];
    return 0;
}
