#include <iostream>

using namespace std;

#define MOD 666013

struct Mat {
    int mat[2][2];
};

const Mat nullMat = {
    {
        {1, 0},
        {0, 1}
    }
};

const Mat initMat = {
    {
        {1, 1},
        {1, 0}
    }
};

Mat prod(Mat a, Mat b) {
    Mat ret;
    ret.mat[0][0] = (1LL * a.mat[0][0] * b.mat[0][0] + 1LL * a.mat[0][1] * b.mat[1][0]) % MOD;
    ret.mat[0][1] = (1LL * a.mat[0][0] * b.mat[0][1] + 1LL * a.mat[0][1] * b.mat[1][1]) % MOD;
    ret.mat[1][0] = (1LL * a.mat[1][0] * b.mat[0][0] + 1LL * a.mat[1][1] * b.mat[1][0]) % MOD;
    ret.mat[1][1] = (1LL * a.mat[1][0] * b.mat[0][1] + 1LL * a.mat[1][1] * b.mat[1][1]) % MOD;
    return ret;
}

Mat pwr(Mat mat, int n) {
    if (!n)
        return nullMat;
    if (n % 2)
        return prod(mat, pwr(prod(mat, mat), n / 2));
    return pwr(prod(mat, mat), n / 2);
}

int main() {
    int n;
    cin >> n;

    cout << pwr(initMat, n).mat[0][1];

    return 0;
}
