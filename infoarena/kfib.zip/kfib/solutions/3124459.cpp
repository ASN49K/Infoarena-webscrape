#include <fstream>
#define mod 666013

using namespace std;

ifstream fin ("kfib.in");
ofstream fout("kfib.out");

int k;
long long fibonacciRec(int k)
{
    if(k<=2)
        return 1;
    else
        return fibonacciRec(k-1)%mod+fibonacciRec(k-2)%mod;
}
int main()
{
    fin>>k;
    fout<<fibonacciRec(k);
    return 0;
}
