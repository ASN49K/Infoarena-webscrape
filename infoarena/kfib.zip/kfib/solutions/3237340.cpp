#include <bits/stdc++.h>

using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
int a=1,b=1,c,k;
int main()
{
    fin>>k;
    for (int i=3;i<=k;i++)
    {
        c=(a+b)%666013;
        a=b;
        b=c;
    }
    fout<<c;
    return 0;
}
