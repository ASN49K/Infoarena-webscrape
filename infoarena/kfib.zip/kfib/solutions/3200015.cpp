#include <bits/stdc++.h>
#define P 666013

using namespace std;

int a[1500001], n, k;

int main()
{
    bool gata;
    a[1] = a[2] = 1;
    a[3] = 2;
    n = 3;
    gata = false;
    while (!gata)
    {
        n++;
        a[n] = a[n - 1] + a[n - 2];
        if (a[n] >= P) a[n] -= P;
        if (a[n] == 1 && a[n - 1] == 0) gata = true;
    }
    n--;
    ifstream fin("kfib.in");
    ofstream fout("kfib.out");
    fin >> k;
    k %= n;
    fout << a[k] << "\n";
    fout.close();
    fin.close();
    return 0;
}
