#include <iostream>
#include <fstream>
#define MOD 666013
using namespace std;

int main(void)
{
    std::ios::sync_with_stdio(false);
    ifstream in("kfib.in");
    ofstream out("kfib.out");
    int k;

    in >> k;
    int a = 0, b = 1, c;

    if (k < 1) {
        out << k;
        return 0;
    }

    k -= 1;

    while (k > 0) {
        c = b;
        b = ((1LL * a % MOD) + (1LL * b % MOD)) % MOD;
        a = c;
        k--;
    }

    out << b << "\n";

    return 0;
}