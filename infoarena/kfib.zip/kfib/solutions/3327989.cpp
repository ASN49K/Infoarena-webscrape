#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long int n,d[505],dp[505][505]= {0};
void drum(int i,int j)
{
    int k=dp[i][j];
    fout<<k<<" ";
    if(i+k-1>k)
        drum(i+k-1,k);
}
int main()
{
    fin>>n;
    n=n+1;
    for(int i=1; i<=n; i++)
    {
        fin>>d[i];
    }

    for(int i=1,j=2; j-i!=n-1; i++,j++)
    {
        dp[i][j]=dp[i][i]+dp[i+1][j]+d[i]*d[j+1]*d[i+1];
        dp[j][i]=i;
        for(int k=i+1; k<=j-1; k++)
        {
            if(dp[i][k]+dp[k+1][j]+d[i]*d[j+1]*d[k+1]<dp[i][j])
            {
                dp[i][j]=dp[i][k]+dp[k+1][j]+d[i]*d[j+1]*d[k+1];
                dp[j][i]=k;
            }
        }

        if(j==n-1)
        {
            j=j-i+1;
            i=0;
        }
    }
    for(int i=1; i<=n-1; i++)
    {
        for(int j=1; j<=n-1; j++)
        {
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
    fout<<dp[1][n-1];
    fout<<endl;
    drum(n-1,1);
    return 0;
}
