#include <fstream>
#define mod 666013
using namespace std;
ifstream cin("kfib.in");
ofstream cout("kfib.out");

int n;
long long p[2][2]={{1,0},{0,1}},a[2][2]={{1,1},{1,0}},b[2][2]={{1,0},{1,0}},aux[2][2];
void inmultire(long long a[2][2],long long b[2][2],long long c[2][2])
{
    for(int i=0;i<=1;i++)
    {
        for(int j=0;j<=1;j++)
        {
            c[i][j]=0;
            for(int k=0;k<=1;k++)
            {
                c[i][j]+=a[i][k]*b[k][j];
                c[i][j]%=mod;
            }
        }
    }
}
void copie(long long a[2][2],long long b[2][2])
{
    for(int i=0;i<=1;i++)
        for(int j=0;j<=1;j++)
        a[i][j]=b[i][j];
}
int main()
{
    cin>>n;
    if(n<=2)
    {
        cout<<1;
        return 0;
    }
    n-=2;
    while(n!=0)
    {
        if(n%2==1)
        {
            inmultire(p,a,aux);
            copie(p,aux);
        }
        inmultire(a,a,aux);
        copie(a,aux);
        n/=2;
    }

    inmultire(p,b,aux);
    cout<<(aux[0][0])%mod;
    return 0;
}
