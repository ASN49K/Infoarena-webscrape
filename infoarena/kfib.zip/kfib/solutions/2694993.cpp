#include <fstream>
using namespace std;
const int MOD =   666013,
            p = 1332028;///Perioada modulo MOD
ifstream f("kfib.in");
ofstream g("kfib.out");
int Fibonacci(int n)
{
    if(n==0) return 0;
    int f0=0,f1=1,f2;
    for(int i=2;i<=n;i++)
    {
        f2=(f0+f1)%MOD;
        f0=f1;
        f1=f2;
    }
    return f1;
}
int main()
{
    int k;
    f>>k;
    g<<Fibonacci(k%p);
    return 0;
}
/**
Teorema (D.D.Wall, 1960)
=======================
Şirul lui Fibonacci este periodic modulo N.
(N natural, nu neapărat prim)
*/
