#include <fstream>
#include <iostream>
#include <vector>

#define MOD 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

vector<vector<unsigned long long>> inmultire(vector<vector<unsigned long long>> a, vector<vector<unsigned long long>> b) {

    vector<vector<unsigned long long>> result;

    int Na, Ma, Nb, Mb;


    Na = a.size(); Ma = a[0].size();
    Nb = b.size(); Mb = b[0].size();

    if (Ma != Nb) {
        return result;
    }

    vector<unsigned long long> v;

    for (int i = 0; i < Na; ++i) {
        v.clear();
        for (int j = 0; j < Mb; ++j) {
            int sum = 0;
            for (int k = 0; k < Ma; ++k) {
                sum += (a[i][k] * b[k][j]) % MOD;
                sum = sum % MOD;
            }
            v.push_back(sum);
        }
        result.push_back(v);
    }

    return result;

}

vector<vector<unsigned long long>> rid_putere(vector<vector<unsigned long long>> a, int k) {
    vector<vector<unsigned long long> > result = {{1, 0},
                                   {0, 1}};
    while (k) {

        if (k % 2 == 1) {
            result = inmultire(result, a);
            k--;
        }
        else {
            a = inmultire(a, a);
            k /= 2;
        }
    }
    return result;
}

int main()
{

    int K;
    fin >> K;

    vector<vector<unsigned long long> > a = {{1, 1}};

    vector<vector<unsigned long long> > b = {{0, 1},
                              {1, 1}};

    vector<vector<unsigned long long> > c = rid_putere(b, K - 1);

    vector<vector<unsigned long long> > d = inmultire(a, c);

    fout << d[0][0];

    return 0;
}
