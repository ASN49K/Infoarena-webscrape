#include <stdio.h>

int main() {
    FILE *fin, *fout;

    int n, nrPer, d, e;

    fin = fopen( "perechi.in", "r" );
    fscanf( fin, "%d", &n );
    fclose( fin );

    nrPer = 1;
    d = 2;
    while ( d * d <= n ) {
        e = 0;
        while ( n % d == 0 ) {
            n /= d;
            e++;
        }
        nrPer *= 2 * e + 1;
        d++;
    }

    if ( n > 1 )
        nrPer *= 3;

    fout = fopen( "perechi.out", "w" );
    fprintf( fout, "%d", nrPer / 2 + 1 );
    fclose( fout );

    return 0;
}
