#include <fstream>
using namespace std;

ifstream cin("kfib.in");
ofstream cout("kfib.out");
int n,a,b,i,c;
int main()
{
    cin>>n;
    a=b=1;
    for(i=3;i<=n;i++)
    {
        c=(a+b)%666013;
        a=b%666013;
        b=c%666013;
    }
    cout<<c;
    return 0;
}
