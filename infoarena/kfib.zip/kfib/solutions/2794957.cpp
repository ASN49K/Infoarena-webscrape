#include <iostream>
#include <fstream>
#define KMAX 1000000000
#define MOD 666013

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int n;

struct matrix
{
    long long a[2][2];
    matrix(int x = 1, int y = 0, int z = 0, int t = 1) {a[0][0] = x, a[0][1] = y, a[1][0] = z, a[1][1] = t;}
};

matrix multiply(matrix A, matrix B)
{
    matrix C;

    for (int i = 0; i < 2; ++i)
        for (int j = 0; j < 2; ++j)
        C.a[i][j] = (A.a[i][0] * B.a[0][j] + A.a[i][1] * B.a[1][j]) % MOD;

    return C;
}
matrix fastPow(matrix A, int n)
{
    matrix result = matrix();

    while (n) {
        if (n & 1) result = multiply(result, A);
        A = multiply(A, A);
        n >>= 1;
    }

    return result;
}

int main()
{
    fin >> n;
    matrix A = matrix(0, 1, 1, 1);
    fout << fastPow(A, n - 1).a[1][1] << '\n';

    fin.close();
    fout.close();
    return 0;
}
