#include <bits/stdc++.h>

using namespace std;
const int MOD = 666013, P=1332028;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

/*long long perioada(int n)
{
    int f1=0, f2=1, f3;
    long long per=0;
    do
    {
        f3=(f1+f2)%n;
        f1=f2;
        f2=f3;
        per++;
    }
    while(f1!=0 || f2!=1);
    return per;
}*/

int Fibonacci(int n)
{
    if(n==0) return 0;
    int f0=0 f1=1, f2;
    for(int i=2; i<=n; i++)
    {
        f2=(f0+f1)%MOD;
        f0=f1;
        f1=f2;
    }
    return f1;
}

int main()
{
    int k;
    fin>>k;
    fout<<Fibonacci(k%p);
    return 0;
}
