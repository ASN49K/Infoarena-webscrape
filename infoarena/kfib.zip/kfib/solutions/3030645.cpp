// ridicare la put matrice.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#define MOD 666013
using namespace std;
int a[3][3], r[3][3];

void multiply(int a[][3], int b[][3])
{//a*b=a
    int rez[3][3] = { 0 };
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                rez[i][j] = (rez[i][j] + (a[i][k] * b[k][j])%MOD)%MOD;

    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            a[i][j] = rez[i][j];
}

void lg(int a[][3], int k)
{

    while (k)
    {
        if (k % 2 == 0)
        {
            multiply(a, a);
            k /= 2;
        }
        else
        {
            multiply(r, a);
            k--;
        }
    }
}

int main()
{
    r[0][0] = 1; r[0][1] = 0; r[1][0] = 0; r[1][1] = 1;
    a[0][0] = 0; a[0][1] = a[1][1] = a[1][0] = 1;

    int k;
    cin >> k;
    lg(a, k);
    cout << r[1][0]%MOD;

}

