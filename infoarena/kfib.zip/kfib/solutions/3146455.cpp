#include <bits/stdc++.h>
#define ll long long 
#define ull unsigned long long 
#define ld long double 
#define pii pair<int, int>
#define pll pair<ll, ll>
#define pb push_back
#define eb emplace_back

using namespace std;

const int mod = 666013;

struct Matrix {
    int values[2][2];
    
    Matrix() {
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                values[i][j] = 0;
    }
};

Matrix operator *(Matrix &a, Matrix &b) {
    Matrix ans;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                ans.values[i][j] += 1ll * a.values[i][k] * b.values[k][j] % mod;
    return ans;
}

Matrix lgpow(Matrix base, int exponent) {
    Matrix result;
    result.values[0][0] = result.values[1][1] = 1;
    while (exponent) {
        if (exponent % 2)
            result = result * base;
        base = base * base;
        exponent /= 2;
    }
    return result;
}

signed main() {
    #ifndef TEST 
        freopen("kfib.in", "r", stdin);
        freopen("kfib.out", "w", stdout);
    #endif
    ios_base :: sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    
    int n;
    cin >> n;
    Matrix recurrence;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++) {
            if (i == 0 && j == 0)
                continue;
            recurrence.values[i][j] = 1;
        }
    recurrence = lgpow(recurrence, n);
    cout << recurrence.values[1][0];
    return 0;
}