#include <fstream>
#define perioada 1332028
#define mod 666013
using namespace std;

ifstream cin ("kfib.in");
ofstream cout ("kfib.out");

int main ()
{
    int numar;
    cin >> numar;

    numar %= perioada;
    if (!numar)
        numar = perioada;

    int termen_1 = 1 , termen_2 = 1 , termen_3 = 1;
    for (int indice = 3 ; indice <= numar ; indice++)
    {
        termen_3 = (termen_1 + termen_2) % mod;
        termen_1 = termen_2 , termen_2 = termen_3;
    }

    cout << termen_2;
    cout.close(); cin.close();
    return 0;
}