#include <fstream>

using namespace std;
ifstream cin("kfib.in");
ofstream cout("kfib.out");
#define mod 666013;
long long int fibo(int n) {
    if(n == 1 || n == 2) { 
        return 1;
    }
    return fibo(n - 1) + fibo(n - 2);
}
int main(){
    long long int n;
    cin >> n;
    cout << fibo(n)%mod;
    return 0;
}
