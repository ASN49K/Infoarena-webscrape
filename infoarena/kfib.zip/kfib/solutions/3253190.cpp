#include <bits/stdc++.h>

using namespace std;

ifstream in("iepuri.in");
ofstream out("iepuri.out");

const int MOD=666013;
int x, y, z, a, b, c, n;
int ans[4][4];

void inmultire(int m[4][4], int m2[4][4])
{
  int aux[4][4]={0};
  for(int i=1; i<=3; i++)
  {
    for(int j=1; j<=3; j++)
    {
      for(int k=1; k<=3; k++)
      {
        aux[i][j]=(aux[i][j]+1ll*m[i][k]*m2[k][j]%MOD)%MOD;
      }
    }
  }
  for(int i=1; i<=3; i++)
  {
    for(int j=1; j<=3; j++)
    {
      ans[i][j]=aux[i][j];
    }
  }
}

void exp_rapida(int x, int mat[4][4])
{
  for(int i=1; i<=3; i++)
  {
    for(int j=1; j<=3; j++)
    {
      ans[i][j]=(i==j);
    }
  }
  while(x)
  {
    if(x%2)
    {
      inmultire(ans, mat);
      x--;
    }
    inmultire(ans, ans);
    x/=2;
  }
}

void solve_test()
{
  in>>x>>y>>z>>a>>b>>c>>n;
  int mat[4][4]=
  {
    {0},
    {0, 0, 1, 0},
    {0, 0, 0, 1},
    {0, c, b, a}
  };

  for(int i=1; i<=3; i++)
  {
    for(int j=1; j<=3; j++)
    {
      ans[i][j]=mat[i][j];
    }
  }

  if(n==3)
  {
    out<<(1LL*a*z%MOD+1LL*b*y%MOD+1LL*c*x%MOD)%MOD<<'\n';
    return;
  }
  exp_rapida(n-2, mat);

  out<<(1LL*ans[3][1]*x%MOD+1LL*ans[3][2]*y%MOD+1LL*ans[3][3]*z%MOD)%MOD<<'\n';
}

int main()
{
    int t;
    in>>t;
    while(t--)
    {
      solve_test();
    }
    return 0;
}
