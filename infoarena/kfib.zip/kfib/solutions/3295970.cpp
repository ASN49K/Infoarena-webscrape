#include <fstream>
using namespace std;

#define MOD 666013;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

int fibonacci_dp(int k) {
    if (k == 0) return 0;
    if (k == 1) return 1;

    int dp_prev2 = 0;
    int dp_prev1 = 1;
    int current = 0;

    for (int i = 2; i <= k; ++i) {
        current = (dp_prev1 + dp_prev2) % MOD;
        dp_prev2 = dp_prev1;
        dp_prev1 = current;
    }

    return current;
}

int main() {
    int k;
    fin >> k;
    fout << fibonacci_dp(k);
    return 0;
}
