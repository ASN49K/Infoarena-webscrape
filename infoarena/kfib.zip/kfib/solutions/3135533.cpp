#include <bits/stdc++.h>

#define MOD 666013
#define ll long long

ll fib(int n) {
    double phi = (1 + sqrt(5)) / 2.0;
    return int(round(pow(phi, n)/sqrt(5))) % MOD;
}

int main() {
    ll n;
    freopen("kfib.in","r",stdin);
    freopen("kfib.out","w",stdout);

    scanf("%lld", &n);
    printf("%lld", fib(n));

}