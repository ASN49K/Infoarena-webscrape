#include <bits/stdc++.h>
#define MOD 666013
using namespace std;


ifstream fin ("kfib.in");
ofstream fout ("kfib.out");

int n;

int Z[5][5], ans[5][5], p;

void Calc (int a[][5], int b[][5]) {
    int c[5][5];
    memset(c, 0, sizeof(c));
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                c[i][j] = (c[i][j] + 1LL * a[i][k] * b[k][j]) % MOD;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            a[i][j] = c[i][j];
}


void LgPow(int a[][5], int p) {
    Z[0][0] = 0;
    Z[0][1] = Z[1][0] = Z[1][1] = 1;
    a[0][0] = a[1][1] = 1;
    for (int i = 0; (1 << i) <= p; i++) {
        if (p & (1 << i))
                Calc(a, Z);
        Calc(Z,Z);
    }
}

int main()
{
    fin >> n;
    LgPow(ans, n - 1);
    fout << ans[1][1] << "\n";
    return 0;
}
