#include <bits/stdc++.h>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

const int mod = 666013;
int k, mat[2][2] = {{0, 1}, {1, 1}}, fib[2] = {0, 1};

void inmultesteMatrice2D(int a[2][2], int b[2][2]){
    int temp[2][2] = {0};
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++){
            int sum = 0;
            for(int k = 0; k < 2; k++) sum = (sum + (1LL * a[i][k] * b[k][j])) % mod;
            temp[i][j] = sum;
        }
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            a[i][j] = temp[i][j];
}

void inmultesteMatrice(int a[2], int b[2][2]){
    int temp[2] = {0};
    for(int j = 0; j < 2; j++){
        int sum = 0;
        for(int k = 0; k < 2; k++) sum = (sum + (1LL * a[k] * b[k][j])) % mod;
        temp[j] = sum;
    }
    for(int i = 0; i < 2; i++)
        a[i] = temp[i];
}

void putere(int a[2][2], int n){
    int p[2][2] = {{0, 1}, {1, 1}};
    while(n)
    {
        if(n & 1) inmultesteMatrice2D(p, a);
        inmultesteMatrice2D(a, a);
        n /= 2;
    }
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            a[i][j] = p[i][j];
}

int main(){
    fin >> k;
    putere(mat, k - 2);
    inmultesteMatrice(fib, mat);
    fout << fib[1];
    return 0;
}