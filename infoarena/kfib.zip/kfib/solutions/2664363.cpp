#include <bits/stdc++.h>
#define MOD 666013
using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
long long int rez[4][4],a[4][4],n,c[4][4];
int main()
{
    f>>n;
    if(n==1||n==2)
    {
        g<<1;
        return 0;
    }
    rez[1][1]=rez[2][2]=a[1][2]=a[2][1]=a[2][2]=1;
    while(n)
    {
        if(n&1)
        {
            for(int i=1; i<=2; i++)
                for(int j=1; j<=2; j++)
                    for(int k=1; k<=2; k++)
                        c[i][j]=(c[i][j]+rez[i][k]*a[k][j])%MOD;
            for(int i=1; i<=2; i++)
                for(int j=1; j<=2; j++)
                    rez[i][j]=c[i][j],c[i][j]=0;
        }
        for(int i=1; i<=2; i++)
            for(int j=1; j<=2; j++)
                for(int k=1; k<=2; k++)
                    c[i][j]=(c[i][j]+a[i][k]*a[k][j])%MOD;
        for(int i=1; i<=2; i++)
            for(int j=1; j<=2; j++)
                a[i][j]=c[i][j],c[i][j]=0;
        n>>=1;
    }
    g<<rez[1][2];
    return 0;
}
