#include <fstream>

using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

const int MOD = 666013;

struct Matrix{
    int a[2][2];
    Matrix operator*(const Matrix &other){
        Matrix result;
        for(int i = 0; i < 2; ++i){
            for(int j = 0; j < 2; ++j){
                result.a[i][j] = 0;
                for(int k = 0; k < 2; ++k){
                    result.a[i][j] = (result.a[i][j] + 1LL * a[i][k] * other.a[k][j]) % MOD;
                }
            }
        }
        return result;
    }
    Matrix operator=(const Matrix &other){
        for(int i = 0; i < 2; ++i){
            for(int j = 0; j < 2; ++j){
                a[i][j] = other.a[i][j];
            }
        }
        return *this;
    }
};

Matrix pow(Matrix base, int exp){
    Matrix p = {1, 0, 0, 1}; //matricea identitate
    Matrix a = base;
    for(int i = 1; i <= exp; (i <<= 1)){
        if(exp & i){
            p = p * a;
        }
        a = a * a;
    }
    return p;
}


inline void solve(){
    int n;
    fin >> n;
    Matrix init = {0, 1, 1, 1}, ret, frt;
    ret =  pow(init, n);
    init = {0, 1, 0, 0};
    frt = init * ret;
    fout << ret.a[0][1];
}

int main()
{
    solve();
    return 0;
}
