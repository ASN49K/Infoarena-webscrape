#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("kfib.in");
ofstream fout("kfib.out");

const int mod=666013;
int n, f[2][2], a[2][2];

void produs(int p[2][2], int a[2][2], int b[2][2])
{
    int aux[2][2];
    for(int i=0; i<2; i++)
    {
        for(int j=0; j<2; j++)
        {
            aux[i][j]=0;
            for(int k=0; k<2; k++)
                aux[i][j]+=(a[i][k]*b[k][j])%mod;
        }
    }
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        p[i][j]=aux[i][j];
}

int main()
{
    in>>n;
    f[0][0]=1;
    f[1][1]=1;
    a[0][0]=1;
    a[0][1]=1;
    a[1][0]=1;
    a[1][1]=0;
    while(n!=0)
    {
        if(n%2!=0)
        {
            produs(f,f,a);
        }
        produs(a,a,a);
        n=n/2;
    }
    out<<f[1][0];
    return 0;
}
