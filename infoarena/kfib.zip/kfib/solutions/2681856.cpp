#include <iostream>
using namespace std;

int a[2][2];
int rez[2][2];
int p[2][2];
ifstream fin("kfib.in");
ofstream fout("kfib.out");
void Inm(int p[2][2], int a[2][2])
{
    int c[2][2], i, j, k;
    /// c[i][j] = suma( p[i][k]*a[k][j]), k=0..1
    for (i = 0; i <= 1; i++)
        for (j = 0; j <= 1; j++)
        {
            c[i][j] = (1LL*p[i][0]*a[0][j] + 1LL*p[i][1]*a[1][j])%666013;
        }
    for (i = 0; i <= 1; i++)
        for (j = 0; j <= 1; j++)
            p[i][j] = c[i][j];
}

void LogP(int n)
{

    p[0][0] = p[1][1] = 1;
    p[0][1] = p[1][0] = 0;
    while (n > 0)
    {
        if (n % 2 == 1) Inm(p, a);
        n /= 2;
        Inm(a, a);
    }
}


int main()
{
    int n, ans;
    a[0][1] = a[1][0] = a[1][1] = 1;
    fin >> n;
    LogP(n - 2);
    ans = (p[0][1] + p[1][1]) % 666013;
    fout << ans;
    return 0;
}
