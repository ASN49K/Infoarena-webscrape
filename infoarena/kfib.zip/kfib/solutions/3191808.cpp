#include <iostream>
#include <fstream>

using namespace std;
ifstream f("kfib.in");
ofstream g("kfib.out");
const int MOD=666013;
int A[2][2]={{1,1},{1,0}};
int I[2][2]={{1,0},{0,1}};
void mulmat(int a[][2],int b[][2])
{
    long long c[2][2];
    int i,j,p;
    for(i = 1; i < 2; i++)
        for(j = 1; j < 2; j++)
        {
            c[i][j] = 0;
            for(p = 1; p < 2; p++)
                c[i][j] += 1LL * a[i][p] * b[p][j];
        }
    for(int i = 1; i < 2; i++)
        for(int j = 1; j < 2; j++)
            a[i][j] = c[i][j]%MOD;
}
void puteremat(int p)
{
    while(p > 0)
    {
        if(p % 2 == 0)
        {
            mulmat(A, A);
            p /= 2;
        }
        else
        {
            mulmat(I, A);
            p--;
        }
    }
}
int main()
{
    int k;
    f>>k;
    if (k<=1){
        g<<k;
    }
    else {
        puteremat(k-1);
        g<<I[0][0];
    }
    f.close();
    g.close();
    return 0;
}
