#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
ll n, mod=666013;
ll fib(ll n)
{
    if(n==1)
        return 1;
    if(n==2)
        return 1;
    return ((fib(n-1)+fib(n-2))%mod);
}

int main()
{

    fin>>n;
    fout<<fib(n);
    return 0;
}
