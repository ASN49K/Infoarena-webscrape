#include <iostream>
#include <fstream>

#define MOD 666013
using namespace std;

ifstream f("kfib.in");
ofstream g("kfib.out");

int n, m[3][3];

void copiaza(int a[][3], int b[][3]) {
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            a[i][j] = b[i][j];
}

void inmulteste(int a[][3], int b[][3], int rez[][3]) {
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++){
                rez[i][j] = ((rez[i][j]%MOD) + (1ll*(a[i][k] % MOD) * (b[k][j] % MOD)) % MOD)%MOD;
            }
        }
    }
}

void afisare(int a[][3]) {
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++)
            cout << a[i][j] << " ";
        cout << endl;
    }
}

void rezolvare() {
    if (n < 2)
        if (n == 0) {
            cout << 0;
            return;
        }else{
            cout << 1;
            return;
        }
    m[0][0] = 0;
    m[0][1] = 1;
    m[1][0] = 1;
    m[1][1] = 1;
    int r[3][3];
    r[0][0] = 1;
    r[0][1] = 0;
    r[1][0] = 0;
    r[1][1] = 1;
    while (n) {
        if (n % 2 == 1) {
            int aux_r[3][3] = {0};
            inmulteste(m, r, aux_r);
            copiaza(r, aux_r);
        }

        int aux_m[3][3] = {0};
        inmulteste(m, m, aux_m);
        copiaza(m, aux_m);
        n = n / 2;
    }

    g<<r[1][1]%MOD;
}

int main() {
    f >> n;
    n--;
    rezolvare();
    return 0;
}
