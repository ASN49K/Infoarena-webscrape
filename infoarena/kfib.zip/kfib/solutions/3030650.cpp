// ridicare la put matrice.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <fstream>
#include <iostream>
#define ll long long
#define MOD 666013
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");

ll a[3][3], r[3][3];

void multiply(ll a[][3], ll b[][3])
{//a*b=a
    ll rez[3][3] = { 0 };
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                rez[i][j] = (rez[i][j] + (a[i][k]*1LL * b[k][j])%MOD)%MOD;

    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            a[i][j] = rez[i][j]%MOD;
}

void lg(ll a[][3], ll k)
{

    while (k)
    {
        if (k % 2 == 0)
        {
            multiply(a, a);
            k /= 2;
        }
        else
        {
            multiply(r, a);
            k--;
        }
    }
}

int main()
{
    r[0][0] = 1; r[0][1] = 0; r[1][0] = 0; r[1][1] = 1;
    a[0][0] = 0; a[0][1] = a[1][1] = a[1][0] = 1;

    ll k;
    fin >> k;
    lg(a, k);
    fout << r[1][0]%MOD;

}

