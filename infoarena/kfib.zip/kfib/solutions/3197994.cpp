#import<fstream>
std::ifstream f("kfib.in");std::ofstream g("kfib.out");int x,y=1,z,k;main(){for(f>>k;k--%1332028;z=(x+y)%666013,x=y,y=z);g<<x;}