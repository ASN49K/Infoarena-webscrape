#include <fstream>
using namespace std;
ifstream fin("kfib.in");
ofstream fout("kfib.out");
int fib(long long k)
{
    if (k==0)
        return 0;
    if (k==1)
        return 1;
    if (k==2)
        return 1;
    if (k>=3)
    {
        return (fib(k-1)+fib(k-2))%660634;
    }
}
int main()
{
    long long k;
    fin>>k;
    fout<<fib(k)<<endl;
    return 0;
}
