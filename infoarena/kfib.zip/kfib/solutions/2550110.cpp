#include <iostream>
#include <cstring>
using namespace std;
char a[256];
int L,s;
int main()
{
    cin>>L;
    cin.get();
    cin.getline(a,256);
    char *p=strtok(a," ");
    while (p)
    {
        if(s+strlen(p)<L)
        {
            s=s+strlen(p);
            cout<<p<<" ";
            s++;
        }
        else if (s+strlen(p)>=L)
        {
            cout<<endl<<p<<" ";
            s=0;
            s=strlen(p)+1;
        }
        p=strtok(NULL," ");
    }
    return 0;
}
