#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
 
bitset<1000001> e;
vector<int> a;
int n;
 
const int MOD = 9973;
 
ifstream f("ssnd.in");
ofstream g("ssnd.out");
 
void Ciur() {   
    int i, j;
    e[0] = e[1] = 1;
    for (i = 2; i * i <= 1000000; i++)
        if (e[i] == 0)
            for (j = 2; j * i <= 1000000; j++)
                e[i * j] = 1;
    for (i = 2; i <= 1000000; i++) 
        if (!e[i])
            a.emplace_back(i);
}
 
long long exp(long long a, long long b) {
    long long P = 1;
    while (b) {
        if (b % 2 != 0)
            P = P * a;
        a = a * a;
        b /= 2;
    } 
    return P;
}
 
void solve() {
    long long x, d, p, nrdiv = 1;
    long long sumadiv = 1;
    f >> x;
    d = 0;
    while (x > 1) {
        p = 0;
        while (x % a[d] == 0) {
            x /= a[d];
            p++;
        }
        nrdiv *= (p + 1);
        sumadiv *= ((1LL * exp(a[d], p + 1) - 1) / (a[d] - 1));
        d++;
        if (a[d] * a[d] > x && x != 1) {
            nrdiv *= 2;
            sumadiv *= ((1LL * exp(x, 2) - 1) / (x - 1));
            break;
        }
    }
    g << nrdiv << ' ' << (sumadiv % MOD) << '\n';
}
 
int main() {
    int t;
    Ciur();
    ios::sync_with_stdio(0);
    f >> t;
    while (t--)
        solve();
    f.close();
    g.close();
    return 0;
}