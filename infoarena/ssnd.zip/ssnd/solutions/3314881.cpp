#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
constexpr ll MOD = 9973, NMAX = 1e6+5;

bitset<NMAX> ePrim;
vector<int> primePanaLaMilion(1);
void eratostene()
{
    for(int i = 2; i <= NMAX; ++i)
        ePrim[i] = true;
    ePrim[0] = ePrim[1] = false;
    for(int i = 2; i * i <= NMAX; ++i) {
        if(ePrim[i]) {
            for(int j = i * i; j <= NMAX; j += i) {
                ePrim[j] = false;
            }
        }
    }
    for(int i = 2; i <= NMAX; ++i)
        if(ePrim[i])
            primePanaLaMilion.push_back(i);
}

ll lgput(ll a, ll n)
{
    a %= MOD;
    n %= MOD;
    ll p = 1;
    for(; n; n >>= 1) {
        if(n & 1)
            p = p * a % MOD;
        a = a * a % MOD;
    }
    return p;
}

ll invMod(ll x)
{
    return lgput(x, MOD-2);
}

void solve()
{
    ll n;
    cin >> n;
    ll nr = 1, sum = 1;
    for(int i = 1; i < primePanaLaMilion.size() && n > 1; ++i) {
        ll d = primePanaLaMilion[i], p = 0;
        while(n % d == 0) {
            ++p;
            n /= d;
        }
        if(p) {
            nr *= p+1;
            sum = sum * ((lgput(d, p+1) - 1) % MOD / ((d-1) % MOD)) % MOD;
        }
    }
    cout << nr << ' ' << sum << '\n';
}

signed main()
{
#ifndef LOCAL
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
#endif

    eratostene();

    int t;
    cin >> t;
    while(t--)
        solve();

    return 0;
}