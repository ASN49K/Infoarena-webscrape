#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

#define work cout<<"da";
#define ll long long
#define ull unsigned long long
const ull MAX = 1e6;

bool ciur[1000005];
int prime[5000000],ind=0;
void gen_ciur(){
    ciur[1] = ciur[0] = 1;
    prime[ind++] = 1;
    for(int i=2;i*i<=MAX;++i)
        if(ciur[i]==0)
            for(int j=2;i*j<=MAX;++j)
                ciur[i*j]=1;
    for(int i=2;i<=MAX;++i)
        if(ciur[i]==0)prime[ind++]=i;
}
int pw(int n,int p){
    int r=1;
    while(p){
        if(p%2==1)r=(1LL*r*n) % 9973;
        n = (1LL*n*n) % 9973;
        p = p / 2;
    }
    return r;
}
map<int,int> fr;
void solve(int x){
    fr.clear();
    for(int i=1;prime[i]*prime[i]<=x;++i){
        while(x%prime[i] == 0){
            x/=prime[i];fr[prime[i]]++;
        }
    }
    if(x>1)fr[x]++;

    int nr_divizori=1;
    ull p1=0,p2=0,suma_div=1;
    for(auto x:fr){
        nr_divizori *= (x.second+1);
        p1 = pw(x.first,x.second+1) - 1;
        p2 = x.first - 1;
        if (p1 < p2)p1 += 9973;
        suma_div = (suma_div * ((p1 * pw(p2, 9971)) % 9973)) % 9973;
     ///suma_div = (suma_div *             ((p1/p2) % 9973)) % 9973;
    }
    fout << nr_divizori << ' ' << suma_div << '\n';

}
int main()
{
    gen_ciur();
    int n,x;fin>>n;
    for(int f=0;f<n;++f){
        fin>>x;solve(x);
    }
    return 0;
}
