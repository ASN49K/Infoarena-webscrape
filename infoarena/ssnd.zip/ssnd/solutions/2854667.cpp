#include <iostream>
#include <vector>

using namespace std;

using ll = long long;
const ll mod=9973;

int power(ll x, ll p){
    if(p==0) return 1;
    if(p&1){
        int nr=power(x,p/2);
        return (((nr*nr)%mod)*x)%mod;
    }
    else{
        ll nr=power(x,p/2);
        return (nr*nr)%mod;
    }
}

vector<int> prim;
const int maxx=1e6+5;
bool ciur[maxx];

void ciurr(){
    for(int i=2; i<=maxx; i++){
        if(ciur[i]) continue;
        prim.emplace_back(i);
        int p=i+i;
        while(p<=maxx){
            ciur[p]=true;
            p+=i;
        }
    }
}

void solve()
{
    int n; cin>>n;

    int it=0;
    ll sum=1,div=1;
    while((ll)prim[it]*prim[it]<=n){
        ll nr=0;
        while(n%prim[it]==0){
            n/=prim[it];
            nr++;
        }
        int p1 = (power(prim[it], nr+1) - 1) % mod;
        int p2 = power(prim[it]-1, mod-2) % mod;
        sum = ((((long long)sum * p1) % mod) * p2) % mod;
        div*=nr+1;
        it++;
    }
    if(n>1){
        sum = ((ll)sum*(n+1)) % mod;
        div*=2;
    }
    cout<<div<<" "<<sum<<"\n";
}

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    ciurr();
    for(int tt=1; tt<=t; tt++){
        solve();
    }
    return 0;
}