#include <stdio.h>

#define MAX_D 1000000
#define MAX_PRIME 90000
#define MOD 9973

char ciur[MAX_D + 1];
int prime[MAX_PRIME];

int main() {
    FILE *fin, *fout;
    int t, nrPrime, nrDiv, sumaDiv, d, exp, i, j;
    int a, p;

    for ( i = 2; i * i <= MAX_D; i++ ) {
        if ( ciur[i] == 0 ) {
            for ( j = i * i; j <= MAX_D; j += i )
                ciur[j] = 1;
        }
    }
    nrPrime = 0;
    for ( i = 2; i <= MAX_D; i++ ) {
        if ( ciur[i] == 0 ) {
            prime[nrPrime] = i;
            nrPrime++;
        }
    }

    fin = fopen( "ssnd.in", "r" );
    fout = fopen( "ssnd.out", "w" );

    fscanf( fin, "%d", &t );
    for ( i = 0; i < t; i++ ) {
        fscanf( fin, "%lld", &a );
        d = 0;
        nrDiv = 1;
        sumaDiv = 1;
        while ( a > 1 && (long long)prime[d] * prime[d] <= a ) {
            exp = 0;
            p = 1;
            while ( a % prime[d] == 0 ) {
                a /= prime[d];
                p *= prime[d];
                exp++;
            }
            if ( exp > 0 ) {
                nrDiv *= exp + 1;
                p *= prime[d];
                sumaDiv = ((long long)sumaDiv * (p - 1) / (prime[d] - 1)) % MOD;
            }
            d++;
        }
        if ( a > 1 ) {
            nrDiv *= 2;
            sumaDiv = ((long long)sumaDiv * (a + 1)) % MOD;
        }
        fprintf( fout, "%d %d\n", nrDiv, sumaDiv );
    }

    fclose( fin );
    fclose( fout );

    return 0;
}
