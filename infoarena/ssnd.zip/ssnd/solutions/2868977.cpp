#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

ifstream cin ("ssnd.in");
ofstream cout ("ssnd.out");

int n;
long long x;
const int MAX = 1e6;
const int MOD = 9973;
vector <int> p;

void ciur ()
{
    bitset <MAX + 1> c;
    for (int i = 2; i * i <= MAX; ++i)
        if (!c[i])
            for (int j = i * i; j <= MAX; j += i)
                c[j] = 1;
    for (int i = 2; i <= MAX; ++i)
        if (!c[i])
            p.push_back(i);
}
long long nr = 1;
int ssnd(long long n)
{
    int i = 0, sum = 1;
    while (i != p.size() - 1 && p[i] * p[i] <= n)
    {
        if (!(n % p[i]))
        {
            long long e = 1, s = 1, s1 = 1;
            while (!(n % p[i]))
            {
                e++;
                s *= p[i];
                s1 += s;
                n /= p[i];

            }
            nr *= e;
            sum *= s1;
            sum %= MOD;

        }
        ++i;
    }
    if (n > 1)
    {
        nr *= 2;
        sum *= (1 + n);
        sum %= MOD;
    }
    return sum;
}

int main()
{
    cin >> n;
    ciur();
    while (n--)
    {
        cin >> x;
        int y = ssnd (x);
        cout << nr << ' ' << y << '\n';
        nr = 1;
    }
}
