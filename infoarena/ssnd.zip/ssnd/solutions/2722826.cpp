#include <fstream>
#include <iostream>
#define P2 16384
#define MOD 9973
#define N 1000000
#define NP 499502

using namespace std;

ifstream fin( "ssnd.in" );
ofstream fout( "ssnd.out" );

char ciur[N + 1];
int prime[NP + 2];
int np = 1;

void ciurMake( long long n ) {
    for ( int i = 4; i <= n; i += 2 ) {
        ciur[i] = 1;
    }
    for ( int i = 3; i * i <= n; i += 2 ) {
        if ( !ciur[i] ) {
            for ( int d = i * i; d <= n; d += i ) {
                ciur[d] = 1;
            }
        }
    }
}

void primeMake( int n ) {
    prime[np ++] = 2;
    for ( int i = 3; i <= n; i += 2 ) {
        if ( !ciur[i] ) {
            prime[np ++] = i;
        }
    }
}

long long putAB( int a, int b ) {
    long long ans = 1, ca = a;
    while ( b ) {
        if ( b % 2 == 1 )
            ans *= ca;
        ca *= ca;
        b /= 2;
    }
    return ans;
}

int sumSiNr( long long n ) {
    int put, nr = 1, poz = 1;
    int sum = 1;
    while ( 1LL * prime[poz] * prime[poz] <= n ) {
        put = 0;
        while ( n % prime[poz] == 0 ) {
            put ++;
            n /= prime[poz];
        }
        nr *= ( put + 1 );
        sum *= ( ( putAB( prime[poz], put + 1 ) - 1 ) / ( prime[poz] - 1 ) ) % MOD;
        poz ++;
    }
    if ( n > 1 ) {
        nr *= 2;
        sum *= ( ( n * n - 1 ) / ( n - 1 ) ) % MOD;
    }
    return nr * P2 + sum % MOD;
}

int main() {
    ciurMake( N );
    primeMake( N );
    prime[NP + 1] = N;
    int n, ans;
    long long nr;
    fin >> n;
    for ( int i = 1; i <= n; i ++ ) {
        fin >> nr;
        ans = sumSiNr( nr );
        fout << ans / P2 << " " << ans % P2 << "\n";
    }
    return 0;
}