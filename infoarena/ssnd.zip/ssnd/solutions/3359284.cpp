#include <bits/stdc++.h>
using namespace std;
int k=0,maxim;
bool fol[10000001];
void ciur()
{
	long long  i,j;
	for(i=1;i*i<=maxim;i++)fol[i]=1;
	for(i=2;i*i<=maxim;i++)
		if(fol[i])
		{
			for(j=i+i;j*j<=maxim;j+=i)
				fol[j]=0;
		}
}
int main()
{
	ifstream f("ssnd.in");
	ofstream g("ssnd.out");
	long long n[15],i,nr=0,l,p=0,nn=0,suma=0,put,j;
	f>>nn;
	for(i=1;i<=nn;i++)
	{
		f>>n[i];
		if(maxim<n[nn]) maxim=n[nn];
	}
	ciur();
	for(l=1;l<=nn;l++)
	{
		nr=1;
		p=0;
		suma=1;
		for(i=2;i<=n[l];i++)
		{
			p=0;
			if(n[l]%i==0 && fol[i]==1)
			while(n[l]%i==0)
			{
				n[l]=n[l]/i;
				p++;
			}
			nr=nr*(p+1);
			put=1;
			for(j=1;j<=p+1;j++) put=put*i;  suma=suma*((put-1)/(i-1));
		}
		if(n[l]>1)g<<2<<' '<<(n[l]+1)%9973<<'\n';
		else g<<nr<<' '<<suma%9973<<'\n';
	}
	f.close();
	g.close();
	return 0;
}
