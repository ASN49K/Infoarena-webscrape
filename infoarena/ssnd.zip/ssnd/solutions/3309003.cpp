#include <iostream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int NRMAX=10000;
bitset<NRMAX+5>is_prime;
void ciur(){
is_prime.set();
  is_prime[0]=is_prime[1]=0;
  for(int i=4;i<=NRMAX;i=i+2){
        is_prime[i]=0;
    
  }
  for(int i=3;i*i<=NRMAX;i=i+2){
    for(int j=i*i;j<=NRMAX;j=j+i){
      is_prime[j]=0;
    }
    
  }
  
}

int nrdiv(int n){
  int ans=1;
for(int i=2;i*i<=n;i++){
 if(is_prime[i]==1 && n%i==0){
   int ct=0;
   while(n%i==0){
   n=n/i;
     ct++;
     
   }
   ans=ans*(1+ct);
   
 }
  
}

  if(n>1){
    ans=ans*2;
  }
  return ans;
  
}

int expo(int a,int b,int mod){
  if(b==0){
    return 1;
  }
  int ans=1;
  if(b%2==0){
    ans=expo(a,b/2,mod)%mod;
    return ((ans%mod)*(ans%mod))%mod;
  }
  else{
    ans=expo(a,b/2,mod);
    return ((ans%mod)*(ans%mod)*a)%mod;
  }
}




int invers(int a, int mod){
return expo(a,mod-2,mod);

  
}



int const MOD=9973;
int sdiv(int n){
 int p=1;
  for(int i=2;i*i<=n;i++){
    if(is_prime[i]==1 && n%i==0){
      int cnt=0;
      while(n%i==0){
        n=n/i;
        cnt++;
      }
      p=p*(((expo(i,cnt+1,MOD)-1)%MOD)*invers(i-1,MOD))%MOD;
    }
    
  }

if(n>1){
 p=((p*(n*n-1)%MOD)*invers(n-1,MOD))%MOD;
  
}
return p%MOD;
  
}
int main(){
  ciur ();
int n,a;
  fin>>n;
  for(int i=1;i<=n;i++){
    fin>>a;
  fout<<nrdiv(a)<<" "<<sdiv(a)<<endl;
  }




}