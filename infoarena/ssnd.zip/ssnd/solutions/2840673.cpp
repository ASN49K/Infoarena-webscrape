#include <bits/stdc++.h>
#define int long long
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int dim=1e6+9,mod=9973;

vector<int>prime;
bool ciur[dim];
void Eratosthenes(int MAX){
    ciur[0]=ciur[1]=1;
    for(int i=4;i<=MAX;i+=2){
        ciur[i]=1;
    }
    for(int i=3;i*i<=MAX;i+=2){
        for(int j=i*i;j<=MAX;j+=i){
            ciur[j]=1;
        }
    }
    for(int i=2;i<=MAX;i++){
        if(!ciur[i]){
            prime.push_back(i);
        }
    }
}

int lgput(int base,int put){
    if(put==0){
        return 1;
    }
    int p=lgput(base,put/2);
    p=(p*p)%mod;
    if(put%2==1){
        p=(p*base)%mod;
    }
    return p;
}

void solve(){
    int n,ans=1,nr_div=1;
    fin>>n;
    for(int x:prime){
        if(x*x>n){
            break;
        }
        int d=0;
        while(n%x==0){
            n/=x;
            d++;
        }
        if(d){
            nr_div*=(d+1);
            ans*=(lgput(x,d+1)-1);
            ans%=mod;
            ans*=lgput(x-1,mod-2);
            ans%=mod;
        }
    }
    fout<<nr_div<<' '<<ans;
}

signed main(){
    Eratosthenes(1e6);
    int t=1;
        fin>>t;
    while(t--){
        solve();
        fout<<'\n';
    }
}
