#include <bits/stdc++.h>
#include <fstream>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
struct custom_hash {static uint64_t splitmix64(uint64_t x) {x += 0x9e3779b97f4a7c15;x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;x = (x ^ (x >> 27)) * 0x94d049bb133111eb;return x ^ (x >> 31);}size_t operator()(uint64_t x) const {static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();return splitmix64(x + FIXED_RANDOM);}};
string __fname = "ssnd"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define int64 long long
#define uint64 unsigned long long
#define x first
#define y second
#define pb push_back
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
template<class T>T ceildiv(T a, T b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
const double pi = 3.14159265359;
const double eps = 1e-6;
const int64 hash_inv = 940594066;
const int64 hash_p = 101;
const int64 mod = 9973;
const int maxn = 1e6 + 1;
bitset <maxn> sieve;
vector <int> primes;

int64 pw (int64 a, int64 b) {
    if (!b) return 1;
    int64 h = pw (a, b / 2);
    return (b % 2 ? h * h % mod * a % mod: h * h % mod);
}

int64 inv (int64 a) {
    return pw(a, mod - 2);
}

void solve(int id){
    int64 n;
    cin >> n;
    int64 rs1 = 1, rs2 = 1;
    for (int64 i: primes){
        if (i * i > n) break;
        int p = 0;
        while (n % i == 0) {
            p++;
            n/=i;
        }
        rs1 = rs1 * (pw(i, p + 1) - 1) % mod * inv(i - 1) % mod;
        rs2 = rs2 * (p + 1) % mod;
    }
    if (n != 1) {
        rs1 = rs1 * (pw(n, 2) - 1) % mod * inv(n - 1) % mod;
        rs2 = rs2 * 2 % mod;
    }
    cout << rs2 << " " << rs1 << "\n";
    return;
}


int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); cout << fixed; cout << setprecision(10); 
    for (int i = 2; i < maxn; i++){
        if (!sieve[i]) {
            primes.push_back(i);
            for (int j = i * 2; j < maxn; j+=i) {
                sieve[j] = 1;
            }
        }
    }
    qr;
    return 0;
}