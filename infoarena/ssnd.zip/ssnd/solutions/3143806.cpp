#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const long long mod = 9973;
long long t, n, i, p, a, s, nr, d, e;

int main() {
    fin >> t;
    while(t--) {
        fin >> n;
        d = 2;
        nr = s = 1;
        while(d * d <= n && n > 1) {
            if(n % d == 0){
                e = 0;
                p = 1;
                while(n % d == 0) {
                    e++;
                    p *= d;
                    n /= d;
                }
                nr *= (e + 1);
                s  *= (p * d - 1) / (d - 1);
		nr %= mod;
		s %= mod;
            }
            d++;
        }
        if(n > 1) {
            nr *= 2;
            s  *= (n * n - 1) / (n - 1);
	    nr %= mod;
	    s %= mod;
        }
        fout << nr << " " << s << "\n";
    }

    return 0;
}
