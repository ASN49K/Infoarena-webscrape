#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int mod = 9973;

int t, nr;
long long n;
int d[1000001], viz[1000001];

void ciur() {
    for (int i = 2; i <= 1000001; i++)
        if (!viz[i]) {
            d[++nr] = i;
            for (int j = 2 * i; j <= 1000001; j += i)
                viz[j] = 1;
        }
}

int putere(int a, int n) {
    if (n == 0)
        return 1;
    int rez = putere(a, n / 2);
    if (n % 2 == 0)
        return rez * rez % mod;
    else
        return rez * rez % mod * a % mod;
}

int main()
{
    ciur();
    fin >> t;
    for (int j = 1; j <= t; j++) {
        fin >> n;
        int c = 1, s = 1;
        for (int i = 1; i <= nr && 1ll * d[i] * d[i] <= n; i++)
            if (!(n % d[i])) {
                int p = 0;
                while (!(n % d[i]))
                    n /= d[i], p++;
                c *= (p + 1);
                int p1 = (putere(d[i], p + 1) - 1) % mod;
                int p2 = (putere(d[i] - 1, mod - 2)) % mod;
                s = (((s * p1) % mod) * p2) % mod;
            }
        if (n > 1)
            c *= 2, s = 1ll * s * (n + 1) % mod;
        fout << c << " " << s << "\n";
    }
    return 0;
}
