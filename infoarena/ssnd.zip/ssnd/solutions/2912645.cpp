#include<fstream>
using namespace std;
ifstream F("dicsi.in");
ofstream G("dicsi.out");
int p[100005],i,j,n,m,k,e;
int main()
{
    for(F>>n,p[1]=1,i=2;i<=n;++i) {
        for(j=2,p[i]=1,k=i;j*j<=k;++j) {
            for(e=0;k%j==0;k/=j,++e);
            if(e)
                p[i]*=(e+1);
        }
        if(k!=1)
            p[i]*=2;
    }
    for(i=1;i<=n;++i)
        m=max(m,p[i]);
    for(G<<m<<'\n',i=1;i<=n;++i)
        G<<p[i]<<' ';
    return 0;
}
