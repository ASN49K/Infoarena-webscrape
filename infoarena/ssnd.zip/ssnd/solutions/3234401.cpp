#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const long long MOD = 9973;

long long power(long long a, long long b) {
    if (b == 0) {
        return 1;
    }
    if (b == 1) {
        return a % MOD;
    }

    long long p = power(a, b / 2);
    if (b % 2 == 1) {
        return (((a * p) % MOD) * p) % MOD;
    }
    else {
        return ((p % MOD) * (p % MOD)) % MOD;
    }
}

int main() {
    long long n;
    int queries;
    fin >> queries;
    while (queries--) {
        fin >> n;

        long long divizor = 2;
        int exponent;
        long long nrDivizori = 1;
        long long sumaDivizori = 1;
        while (n > 1) {
            exponent = 0;
            while (n % divizor == 0) {
                ++exponent;
                n /= divizor;
            }

            if (exponent > 0) {
                nrDivizori *= exponent + 1;
                sumaDivizori = (sumaDivizori * (power(divizor, exponent + 1) - 1 + MOD)) % MOD;
                sumaDivizori = (sumaDivizori * power(divizor - 1, MOD - 2)) % MOD;
            }

            if (divizor == 2) {
                ++divizor;
            }
            else {
                divizor += 2;
            }

            if (divizor * divizor > n) {
                divizor = n;
            }
        }

        fout << nrDivizori << ' ' << sumaDivizori << '\n';
    }
    
    return 0;
}
