#include <fstream>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

ifstream be("ssnd.in");
ofstream ki("ssnd.out");
int MOD=9973;
void szita(int n,vector<bool>&a)
{
    a[1]=false;
    for(int i=2;i<=n/2;i++)
    {
        for(int j=2;i*j<=n/2;j++)
            a[i*j]=false;
    }

}

long long x=1;

long long  hatvany( long long n,long long p)
{


    if(p!=0){
            x=hatvany(n,p/2);
    if(p%2==0){

        return (x*x);
    }
    else{
            return ((x*x)*n) ;}}

    else return x;

}

int main()
{
    int m;
    long long n;
    be>>m;
    for(int i=0;i<m;i++){
        be>>n;
        int db=1,db1=1;
        vector<bool>a(n+1,true);
        szita(n,a);
        int k=n;
        int j=0;
            for(int i=2;i<=k/2;++i){int j=0;
                if(a[i]==true && n%i==0)
                {
                    while(n%i==0)
                    {
                        j++;
                        n=n/i;
                    }
                db=(db*(j+1))%MOD;
                db1=(db1*(((hatvany(i,j+1)-1)%MOD/(i-1))))%MOD;
                x=1;
            }
            }
        if(db==1){db++;db1=n+1;}
        ki<<db<<" "<<db1<<endl;
    }

    return 0;
}
