#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int mod = 9973;
long long t, n;

static inline void Calc() {
    long long nrd = 1, sum = 1;
    fin >> n;
    long long d = 2;
    while(d * d <= n) {
        long long e = 0;
        long long p = d;
        while(n % d == 0) {
            e++;
            p *= d;
            n /= d;
        }

        if(e) {
            sum *= (p - 1) / (d - 1);
            nrd *= e + 1;
        	
	    sum %= mod;
	    nrd %= mod;
	}

        d++;
    }
    if(n > 1) {
        sum *= (n * n - 1) / (n - 1);
        nrd *= 1 + 1;

	sum %= mod;
	nrd %= mod;
    }

    fout << nrd << " " << sum << "\n";
}

int main() {
    fin >> t;
    while(t--) Calc();

    return 0;
}
