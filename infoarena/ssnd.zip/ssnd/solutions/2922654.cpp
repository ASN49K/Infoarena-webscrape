#include <bits/stdc++.h>
#define int long long
#define pb push_back
using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

const int NM = 1e6 + 5;
const int mod = 9973;

bitset<NM>c;
vector<int>primes;

void precalc(){
  primes.pb(2);
  for (int i = 4; i < NM; i += 2){
    c[i] = true;
  }
  for (int i = 3; i * i < NM; i += 2){
    if (c[i] == 0){
      for (int j = 2; j * i < NM; j++){
        c[i * j] = true;
      }
    }
  }
  for (int i = 3; i < NM; i += 2){
    if (c[i] == false){
      primes.pb(i);
    }
  }
}

void solve (int x){
  int nrDiv = 1, sumDiv = 1, z = 0;
  while (x > 1){
    int p = primes[z], cnt = 0;
    while (x % primes[z] == 0){
      p = (p * primes[z]) % mod;
      cnt += 1;
      x = x / primes[z];
    }
    if (cnt > 0){
      sumDiv = sumDiv * ((p - 1) / (primes[z] - 1));
      sumDiv %= mod;
      nrDiv = nrDiv * (cnt + 1);
      nrDiv %= mod;
    }
    z += 1;
    if (primes[z] * primes[z] > x && x > 1){
      nrDiv = (nrDiv * 2) % mod;
      sumDiv = (sumDiv * ((x * x - 1) / (x - 1))) % mod;
      break;
    }
  }
  fout << nrDiv % mod << " " << sumDiv % mod << '\n';
}

signed main(){
  ios_base::sync_with_stdio(false);
  precalc();
  int t; fin >> t;
  while (t--){
    int x; fin >> x;
    solve(x);
  }
}
