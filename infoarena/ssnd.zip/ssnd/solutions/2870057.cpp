#include <iostream>
#include <fstream>
#include <bitset>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MAX=1e6;
const int MOD=9973;
#define ll long long
ll t,n,cnt,prim[MAX];
bitset < MAX > v;

int main()
{
    v[0]=v[1]=1;
    for(ll i=2;i<MAX;i++)
        if(!v[i])
        {
            prim[++cnt]=i;
            for(ll j=i*i;j<MAX;j+=i)
                v[j]=1;
        }
    fin >> t;
    while(t--)
    {
        fin >> n;
        int nrdiv=1,sumdiv=1;
        for(int i=1,d=2;d*d<=n;d=prim[++i])
            if(n%d==0)
            {
                ll k=0,nn=n;
                while(n%d==0)
                    n/=d, k++;
                nrdiv*=k+1;
                sumdiv=sumdiv*(nn/n*d-1)/(d-1)%MOD;
            }
        if(v[n]==0)
        {
            nrdiv*=2;
            sumdiv=sumdiv*(n*n-1)/(n-1)%MOD;
        }
        fout << nrdiv << " " << sumdiv << '\n';
    }
    return 0;
}
