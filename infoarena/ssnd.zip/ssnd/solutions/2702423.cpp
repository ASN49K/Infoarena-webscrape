#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
 
bitset<1000005> e;
vector<int> a;
int n;
 
const int MOD = 9973;
 
ifstream f("ssnd.in");
ofstream g("ssnd.out");
 
void Ciur() {
    int i, j;   
    e[1] = e[0] = 1;
    for(i = 2; i < 1000000; ++i) 
		if(e[i] == 0) {
			a.emplace_back(i);
			for(j = i+i; j < 1000000; j += i) {
				e[j] = 1;
			}
		}
}
 
long long exp(long long a, long long b) {
    long long P = 1;
    while (b) {
        if (b % 2 != 0)
            P = P * a;
        a = a * a;
        b /= 2;
    } 
    return P;
}
 
void solve() {
    long long x, d, p, nrdiv = 1;
    long long sumadiv = 1;
    f >> x;
    d = 0;
    while (x > 1) {
        p = 0;
        while (x % a[d] == 0) {
            x /= a[d];
            p++;
        }
        nrdiv *= (p + 1);
        sumadiv *= ((1LL * exp(a[d], p + 1) - 1) / (a[d] - 1));
        d++;
        if (a[d] * a[d] * 1LL > x && x != 1) {
            nrdiv *= 2;
            sumadiv *= ((1LL * exp(x, 2) - 1) / (x - 1));
            break;
        }
    }
    g << nrdiv << ' ' << (sumadiv % MOD) << '\n';
}
 
int main() {
    ios::sync_with_stdio(0);
    int t;
    Ciur();
    f >> t;
    while (t--)
        solve();
    f.close();
    g.close();
    return 0;
}