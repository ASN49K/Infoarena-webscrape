#include <bits/stdc++.h>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
bitset <1100000> a;
int v[100003],n,p,x;
int main()
{
    a[0]=a[1]=1;
    for (int i=2; i<=1000000; i++)
    {
        if (a[i]==0)
        {
            v[++p]=i;
            for (int j=2*i; j<=1000000; j+=i)
                a[j]=1;
        }
    }
    fin>>n;
    for (int i=1;i<=n;i++)
    {
        fin>>x;
        int d=1;
        int sd=1;
        int nrd=1;
        while (v[d]*v[d]<=x)
        {
            int e=0,p=v[d];
            while (x%v[d]==0)
            {
                e++;
                p*=v[d];
                x/=v[d];
            }
            if (e>0)
            {
                sd*=(p-1)/(v[d]-1);
                nrd=nrd*(e+1);
            }
            d++;
        }
        if (x>1)
        {
            nrd=nrd*2;
            sd*=(x*x-1)/(x-1);
        }
        fout<<nrd<<" "<<sd<<'\n';
    }
    return 0;
}
