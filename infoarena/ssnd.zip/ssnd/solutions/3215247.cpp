#include <iostream>

using namespace std;

int logarizare(int put, int exp)
{
    int prod=1;
    if(exp%2==1)
        prod*=put;
    while(exp/2>0)
    {
        put=put*put%9973;
        exp/=2;
    }
    prod*=put;
    return prod;
}

int divizori(int a, int cer)
{
    int d=2,exp=0,suma=1,prod=1;

    if(a%d==0)
    {
        while(a%d==0)
        {
            a/=d;
            exp++;
        }
        prod*=(exp+1);
        //cout<<suma<<" "<<d<<" "<<exp+1<<" "<<logarizare(d, exp+1)-1<<'\n';
        suma*=(logarizare(d, exp+1)-1)/(d-1);

    }

    d=3;
    while(a!=1)
    {
        if(a%d==0)
        {
            exp=0;
            while(a%d==0)
            {
                a/=d;
                exp++;
            }
            prod=prod*(exp+1)%9973;

            suma=suma*((logarizare(d, exp+1)-1)/(d-1))%9973;
            //cout<<suma<<" "<<d<<'\n';
        }
        d+=2;
    }


    if(cer==1)
        return prod;
    return suma%9973;
}

int main()
{
    int n,a;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>a;
        cout<<divizori(a, 1)<<" "<<divizori(a, 2)<<'\n';
    }


    return 0;
}
