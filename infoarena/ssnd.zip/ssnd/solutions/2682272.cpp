#include <bits/stdc++.h>
#define Mod 9973
#define nrm 1000005
using namespace std;


ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bitset<nrm> b;
vector<long long>prime;
void ciur()
{
    prime.push_back(2);
    for (long long i = 4; i < nrm; i += 2)
        b[i] = 1;
    for (long long i = 3; i  < nrm; i += 2)
        if (b[i] == 0)
        {
            prime.push_back(i);
            for (long long j = i *i; j < nrm; j += i)
                b[j] = 1;
        }
}

long long LogP(long long a, long long n)
{
    int p;
    for (p = 1; n > 0; n /= 2)
    {
        if (n % 2 == 1)
            p = 1LL * p * a % Mod;
        a = a * a % Mod;
    }
    return p;
}
void Descompunere(long long n)
{
    long long p, e, nrDiv = 1, sumaDiv = 1;
    for (long long i = 0; i < prime.size() && prime[i] * prime[i] <= n; i++) {
        p = prime[i];
        if (n % p == 0)
        {
            e = 0;
            while (n % p == 0)
            {
                e++;
                n /= p;
            }
            nrDiv *= (e + 1);
            sumaDiv = 1LL * sumaDiv * (LogP(p, e + 1) - 1 + Mod) * LogP(p - 1, 9971) % Mod;
        }
        
    }
    if (n > 1)
    {
        nrDiv *= 2;
        sumaDiv = 1LL * sumaDiv * (n * n - 1 + Mod) * LogP(n - 1, 9971) % Mod;
    }
    fout << nrDiv << " " << sumaDiv << "\n";
}

int main()
{
    long long n;
    int T;
    ciur();
    fin >> T;
    while (T--)
    {
        fin >> n;
        Descompunere(n);
    }
    fin.close();
    fout.close();
    return 0;
}