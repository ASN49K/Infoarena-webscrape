#include <bits/stdc++.h>
using namespace std;
#define MAX 1000000
#define MOD 9973
bitset<1000001> ciur;
int prime[100001], k = 0;

int ridica(int a, int b){
    int ans = 1;
    while(b){
        if(b % 2 == 1){
            ans *= a;
        }
        a *= a;
        b /= 2;
    }
    return ans;
}

pair<int,int> ssnd(int x){
    int suma = 1, nr_div = 1;
    int index = 1;
    while(x > 1 && index <= k && prime[index] * prime[index] <= x){
        int p = 0;
        while(x % prime[index] == 0){
            x/=prime[index];
            p++;
        }
        if(p){
            nr_div = nr_div * (p+1);
            int p1 = (ridica (prime[index], p+1) - 1) % MOD;
            int p2 = ridica(prime[index]-1, MOD-2) % MOD;
            suma = (((suma * p1) % MOD) * p2) % MOD;
        }
        index++;
    }
    if(x > 1){
        nr_div *= 2;
        suma = (1LL*suma*(x+1) % MOD);
    }
    return {nr_div,suma};
}

int main(void){
    ofstream cout("ssnd.out");
    ifstream cin("ssnd.in");
    for(int i = 2;i<=MAX;++i){
        if(ciur[i] == 0){
            prime[++k] = i;
            for(int j = 2; j * i <= MAX;j++){
                ciur[i * j] = 1;
            }
        }
    }
    //cout << ridica(2,3);
   // for(int i = 1;i<=k;i++)cout << prime[i] << ' ';
    int n;
    cin >>n;
    for(int i = 1;i<=n;i++){
       int x;
        cin >> x;
        pair<int,int> ans = ssnd(x);
        cout << ans.first << ' ' << ans.second << '\n';

    }
}
