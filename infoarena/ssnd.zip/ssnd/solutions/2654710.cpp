#include <iostream>
#include <fstream>

using namespace std;
int MOD = 9973;
bool isPrime[1000005];
int prime[1000005];

int main()
{
    ifstream fin ("ssnd.in");
    ofstream fout ("ssnd.out");
    int m = 1000000, numberPrimes = 0;

    isPrime[0] = isPrime[1] = 1;
    for (int i = 2; i <= m; ++i) {
        if (isPrime[i] == 0) {
            numberPrimes += 1;
            prime[numberPrimes] = i;
            for (int j = 2 * i; j <= m; j += i) {
                isPrime[j] = 1;
            }
        }
    }

    int t;
    fin >> t;

    for (int k = 1; k <= t; ++k) {
        long long sum = 1, cardinal = 1;
        int n;
        fin >> n;

        for (int i = 1; i <= numberPrimes && 1LL * prime[i] * prime[i] <= n; ++i) {
            long long product = 1;
            int power = 0;
            while (n % prime[i] == 0) {
                   n = n / prime[i];
                   product *= prime[i];
                   power += 1;
            }
            cardinal *= (1 + power);
            sum *= ((product * prime[i] - 1) / (prime[i] - 1));
        }
        if (n > 1) {
            cardinal *= 2;
            sum *= (n + 1);
        }
        fout << cardinal % MOD << " " << sum % MOD;
        fout << "\n";
    }
    return 0;
}
