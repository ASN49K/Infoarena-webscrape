#include <bits/stdc++.h>
#define mod 9973

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

/**
n=f1^e1 * f2^e2 * ... * fp^ep
nrdiv(n)=(e1+1)*(e2+1)*...*(ep+1)
sumdiv(n)=(f1^(e1+1)-1)/(f1-1)*.....*(fp^(ep+1)-1)/(fp-1)
*/

int t;
long long n;
bitset <1000050> b;
int prim[80000],k;

void Ciur(int n)
{
    int i,j;
    for(i=3;i<=n;i+=2) b[i]=1;
    for(i=3;i*i<=n;i+=2)
        if(b[i]==1)
            for(j=i*i;j<=n;j+=2*i)
                b[j]=0;
    prim[++k]=2;
    for(i=3;i<=n;i+=2) if(b[i]==1) prim[++k]=i;
}

int Exp(int a,int n)
{
    int p=1;
    while(n)
    {
        if(n%2==1) p=p*a%mod;
        a=a*a%mod;
        n/=2;
    }
    return p;
}

void Desc(long long n)
{
    int f,e,i,nrdiv;
    long long sdiv;
    nrdiv=sdiv=1;
    for(i=1;prim[i]*prim[i]<=n;i++)
    {
        f=prim[i];
        e=0;
        while(n%f==0)
        {
            n/=f;
            e++;
        }
        if(e>0)
        {
            nrdiv=nrdiv*(e+1);
            sdiv=sdiv*(Exp(f,e+1)-1+mod)%mod;
            sdiv=sdiv*(Exp(f-1,mod-2))%mod;
        }
    }
    if(n>1)
    {
        nrdiv=nrdiv*2;
        sdiv=sdiv*(Exp(n,2)-1+mod)%mod;
        sdiv=sdiv*(Exp(n-1,mod-2))%mod;
    }
    fout<<nrdiv<<" "<<sdiv<<'\n';
}

int main()
{
    Ciur(1000049);
    int i;
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>n;
        Desc(n);
    }
    return 0;
}
