#include <fstream>
#include <iostream>
using namespace std;
int t,k;
long long n;
bool ciur[1000002];
long long prime[80000];

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

long long putere(long long a, long long b){
    long long ans = 1;
    for(int i = 1; i <= b; i++){
        ans *= a;
    }
    return ans;
}

void calcul(long long n){
    int nrdiv = 1;
    long long suma = 1;
    int i = 1;
    while(i <= k && prime[i]*prime[i] <= n){
        int p = 0;
        if(n%prime[i] == 0){
            p = 0;
            long long d = prime[i];
            while(n%prime[i] == 0){
                n /= prime[i];
                p++;
            }
            /// d ^ p
            nrdiv *= (p+1);
            suma *= (putere(d, p+1)-1)/(d-1);
            suma %= 9973;
        }
        i++;
    }
    if(n > 1){
        /// n ^ 1
        nrdiv *= 2;
        suma *= (putere(n, 2)-1)/(n-1);
        suma %= 9973;
    }
    fout << nrdiv << " " << suma << "\n";
}

int main()
{
    for(int i = 3; i <= 1000; i += 2){
        if(ciur[i] == 0){
            for(int j = i+i; j < 1000000; j+=i){
                ciur[j] = 1;
            }
        }
    }
    k = 1;
    prime[1] = 2;
    for(int i = 3; i <= 1000000; i += 2){
        if(ciur[i] == 0){
            prime[++k] = i;
        }
    }


    fin >> t;
    for(int i = 1; i <= t; i++){
        fin >> n;
        calcul(n);
    }
    return 0;
}
