#include <fstream>
using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

int number = 9973;
long long max_val = 10000000000005;

int main() {
    int t, x, nr_div, sum_div;
    f>>t;
    for(int i = 1; i<=t; i++){
        f>>x;
        nr_div = 0;
        sum_div = 0;
        for(int d = 2; d*d<=x; d++){
            if(x%d==0) {
                nr_div++;
                sum_div = (sum_div + d) % number;
                if(d != x/d){
                    nr_div++;
                    sum_div = (sum_div + x/d) % number;
                }
            }
        }
        g<<nr_div+2<<" "<<(sum_div+1+x)%number<<"\n";
    }
    return 0;
}
