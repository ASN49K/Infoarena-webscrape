#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int numar=9973;
long long int n, x, v[1000010], k=0, suma, nrdiv, aux;
bool ciur[1000010];

int main()
{
    fin>>n;
    ciur[0]=ciur[1]=1;
    for(int i=2; i<=1000000; i++) {
        if(ciur[i]==0){
            v[++k]=i;
            if(i<=1000)
                for(int j=i*i; j<=1000000; j+=i) ciur[j]=1;
        }
    }
    for(int i=1; i<=n; i++) {
        fin>>x;
        nrdiv=1, suma=1;
        for(int i=1; i<=k && v[i]*v[i]<=x; i++) {
            aux=0;
            while(x%v[i]==0) x/=v[i], aux++;
            nrdiv=nrdiv*(aux+1);
            int ceva=1;
            for(int j=1; j<=aux+1; j++) ceva*=v[i];
            suma=suma*(((ceva-1)/(v[i]-1))%numar)%numar;
        }
        if(x!=1) {
            nrdiv*=2;
            suma=suma*(((x*x-1)/(x-1))%numar)%numar;
        }
        fout<<nrdiv<<" "<<suma<<'\n';
    }

    return 0;
}
