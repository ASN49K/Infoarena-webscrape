#include<bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

const int NMAX = 1e6 + 5, MOD = 9973;
bool ciur[NMAX];
vector<int> primes;

void build_ciur()
{
    for(int i = 2; i <= NMAX - 5; i++)
    {
        if(!ciur[i])
        {
            primes.push_back(i);
            for(int j = i * 2; j <= NMAX - 5; j += i)
                ciur[j] = true;
        }
    }
}

int ridput(int a, int b)
{
    long long ans = 1;
    while(b)
    {
        if(b % 2)
            ans *= a;
        
        a *= a;
        a %= MOD;
        ans %= MOD;
        b = b >> 1;
    }

    return ans;
}

void query()
{
    long long n;
    cin >> n;
    long long sd = 1, nd = 1;
    for(int i = 0; i < primes.size() && 1LL * primes[i] * primes[i] <= n; i++)
    {
        if(n % primes[i])
            continue;
        int cnt = 0;
        while(n % primes[i] == 0)
        {
            n /= primes[i];
            cnt++;
        }

        nd *= (cnt + 1);
        
        int aux1 = (ridput(primes[i], cnt + 1) - 1) % MOD;
        int aux2 = ridput(primes[i] - 1, MOD - 2) % MOD;
        sd = (sd * aux1) % MOD;
        sd = (sd * aux2) % MOD;
    }

    if(n > 1)
    {
        nd *= 2;
        sd = (1LL * sd * (n + 1)) % MOD;
    }

    cout << nd << " " << sd;
}

int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    build_ciur();
    int t;
    cin >> t;
    
    while(t--)
    {
        query();
        cout << "\n";
    }
}