#include <fstream>
using namespace std;
int t;
long long n;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

void calcul(long long n){
    long long suma = 1+n;
    int nrdiv = 1;
    for(long long d = 2; d*d <= n; d++){
        if(n%d == 0){
            suma += d;
            suma %= 9973;
            nrdiv++;
            if(d != n/d){
                suma += n/d;
                suma %= 9973;
                nrdiv++;
            }
        }
    }
    fout << nrdiv << " " << suma << "\n";
}

int main()
{
    fin >> t;
    for(int i = 1; i <= t; i++){
        fin >> n;
        calcul(n);
    }
    return 0;
}
