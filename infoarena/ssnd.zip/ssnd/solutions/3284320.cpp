#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
///restmare
///darb

bool fr[1000005];
long long t, n;
vector<long long> v;

long long Putere(long long x, long long e)
{
    long long a = 1;
    while(e != 0)
    {
        if(e % 2 == 1) a = (a * x) % 9973;
        x = (x * x) % 9973;
        e /= 2;
    }
    return a;
}

void Descompunere(long long t)
{
    long long d, p, divizori, suma, ind;
    ind = 0;
    d = v[ind];
    divizori = suma = 1;
    while(t > 1)
    {
        p = 0;
        while(t % d == 0)
        {
            p++;
            t /= d;
        }
        divizori = divizori * (p + 1);
        suma = (suma * (((Putere(d, p + 1) - 1) / (d - 1)) % 9973)) % 9973;
        d = v[++ind];
        if(d * d > n && n > 1) d = n;
    }
    fout << divizori << " " << suma << "\n";
}

int main()
{
    long long i, j;
    fr[0] = fr[1] = true;
    for(i=2; i*i<=1000000; i++)
        if(fr[i*i] == false)
            for(j=2; j*i<=1000000; j++)
                fr[i*j] = true;
    for(i=1;i<=1000000;i++)
        if(fr[i] == false) v.push_back(i);
    fin >> t;
    for(i=1;i<=t;i++)
        {
            fin >> n;
            Descompunere(n);
        }
    fin.close();
    fout.close();
    return 0;
}
