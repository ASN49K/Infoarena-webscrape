#include <fstream>
#define VMAX 1000000
#define MOD 9973
using namespace std;
ifstream  fin("ssnd.in");
ofstream fout("ssnd.out");
int t,nrp,prime[VMAX+1],ciur[VMAX+1];
long long n,nr,s;

void pre_calculare()
{
    nrp=0;
    ciur[0]=ciur[1]=1;

    for(int i=2; i<=VMAX; i++)
    {
        if(!ciur[i])
        {
            prime[++nrp]=i;
            for(int j=2; j<=VMAX/i; j++)
            {
                prime[i*j]=1;
            }
        }
    }
}

int main()
{
    pre_calculare();

    fin>>t;

    for(int q=1; q<=t; q++)
    {
        fin>>n;

        long long i,e,d,x;
        i=nr=s=1;
        d=2;

        while(n>1)
        {
            e=0;
            x=n;
            while(n%d==0)
            {
                n=n/d;
                e++;
            }

            if(e)
            {
                x=x/n;
                nr=nr*(e+1);
                s=s*(x*d-1)/(d-1);
            }

            d=prime[++i];
            if(d*d>n && n>1)
            {
                d=n;
            }
        }

        fout<< nr << " " << s%MOD << "\n";
    }

    return 0;
}
