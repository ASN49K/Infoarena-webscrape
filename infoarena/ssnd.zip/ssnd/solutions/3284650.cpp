#include <bits/stdc++.h>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

const int MAX_VAL = 1'000'000;
const int MOD = 9973;

bitset<MAX_VAL + 1> ciur;
vector<int> p;
long long n, t;

void init()
{
    ciur[0] = ciur[1] = 1;
    for (int i = 4; i <= MAX_VAL; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i <= MAX_VAL; i += 2)
        if (!ciur[i])
            for (int j = i * i; j <= MAX_VAL; j += (i << 1))
                ciur[j] = 1;
    p.push_back(2);
    for (int i = 3; i <= MAX_VAL; i += 2)
        if (!ciur[i])
            p.push_back(i);
}

int pwr(int a, int n)
{
    int res = 1;
    a %= MOD;
    while (n)
    {
        if (n & 1)
            res = (1LL * res * a) % MOD;
        a = ((1LL * a % MOD) * a) % MOD;
        n >>= 1;
    }
    return res;
}

void solve()
{
    f >> n;
    long long nrDiv = 1, sumDiv = 1;
    for (int i = 0; p[i] * p[i] <= n && i < p.size(); i++)
        if (!(n % p[i]))
        {
            int e = 0;
            while (!(n % p[i]))
            {
                e++;
                n /= p[i];
            }
            nrDiv = 1LL * nrDiv * (1 + e);
            int p1 = (pwr(p[i], 1 + e) - 1) % MOD;
            int p2 = (pwr(p[i] - 1, MOD - 2)) % MOD;
            sumDiv = (((1LL * sumDiv * p1) % MOD) * p2) % MOD;
        }
    if (n > 1)
    {
        nrDiv <<= 1;
        sumDiv = 1LL * sumDiv * (n + 1) % MOD;
    }
    g << nrDiv << " " << sumDiv << "\n";
}

int main()
{
    init();
    
    f >> t;
    while (t--)
        solve();
    
    f.close();
    g.close();
    return 0;
}
