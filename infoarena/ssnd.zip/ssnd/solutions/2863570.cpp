#include <bits/stdc++.h>

using namespace std;

ifstream fin  ("fractii.in");
ofstream fout ("fractii.out");

const int MOD = 9973;
const int LIM = 1e6;
bitset <LIM+5> ciur;
int p, prim[80000], expo;

void mark(int prim){
    for(int i=prim*prim; i<=LIM; i+=prim)
        ciur[i] = true;
}

long long n, dcnt, dsum;

long long lgput(int a, int b){
    long long answer = 1;
    while(b != 0){
        if(b&1)
            answer *= a;
        a *= a;
        b >>= 1;
    }
    return answer;
}

signed main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    ciur[0] = ciur[1] = true;
    mark(2);
    mark(3);
    for(int i=5; i<=LIM/i; i+=6){
        if(!ciur[i]) mark(i);
        if(!ciur[i+2]) mark(i+2);
    }
    prim[++p] = 2;
    prim[++p] = 3;
    for(int i=5; i<=LIM; i+=6){
        if(!ciur[i]) prim[++p] = i;
        if(!ciur[i+2] && i+2<=LIM) prim[++p] = i+2;
    }

    int teste;
    fin>>teste;
    while(teste--){
        fin>>n;
        dcnt = dsum = 1;

        for(int i=1; i<=p; i++){
            if(prim[i]*prim[i] > n) break;
            if(n % prim[i] != 0) continue;

            expo = 0;
            while(n % prim[i] == 0){
                expo++;
                n /= prim[i];
            }

            dcnt *= (expo+1);
            dsum = (long long)dsum * ((lgput(prim[i], expo+1) - 1) / (prim[i] - 1)) % MOD;
        }
        if(n > 1){
            dcnt *= 2;
            dsum = (long long)dsum * ((n*n-1) / (n-1)) % MOD;
        }
        fout<<dcnt<<" "<<dsum<<"\n";
    }
    return 0;
}

