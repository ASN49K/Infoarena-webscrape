#include <bits/stdc++.h>
#define MOD 9973
using namespace std;

/**
n = 2^3 * 5^4 * 7^1

nrd(n) = (3+1)*(4+1)*(1+1)

*/
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
bitset<1000051> b;
int prime[80000], m;

void Ciur(int n)
{
    int i, j;
    for (i = 3; i * i <= n; i += 2)
        if (b[i] == 0)
            for (j = i * i; j <= n; j += 2*i)
                b[j] = 1;
    m = 1;
    prime[1] = 2;
    for (i = 3; i <= n; i += 2)
        if (b[i] == 0) prime[++m] = i;
}

/// a^n % MOD
int QuickExpo(int a, int n)
{
    int p = 1;
    while (n > 0)
    {
        if (n % 2 == 1) p = (1LL * p * a) % MOD;
        n /= 2;
        a = 1LL * a * a % MOD;
    }
    return p;
}

void DESC(long long n)
{
    int sd = 1, nrd = 1, i, f, e, x;
    for (i = 1; 1LL * prime[i] * prime[i] <= n; i++)
    {
        f = prime[i];
        e = 0;
        while (n % f == 0)
        {
            e++;
            n /= f;
        }
        if (e > 0)
        {
            nrd = nrd * (e + 1);
            x = QuickExpo(f, e + 1) - 1;
            if (x < 0) x += MOD;

            x = x * QuickExpo(f - 1, MOD-2) % MOD;
            sd = sd * x % MOD;
        }
    }
    if (n > 1)
    {
        nrd = nrd * 2;
        x = QuickExpo(n, 2) - 1;
        if (x < 0) x += MOD;

        x = x * QuickExpo(n - 1, MOD-2) % MOD;
        sd = sd * x % MOD;
    }
    fout << nrd << " " << sd << "\n";
}

int main()
{
    Ciur(1000049);
    int n;
    long long x;
    fin >> n;
    while (n--)
    {
        fin >> x;
        DESC(x);
    }
    fout.close();
    return 0;
}
