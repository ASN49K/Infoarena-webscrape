#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int l=1e6,lim=1e6+10;
const int mod=9973;

int Q,x,c[lim],nrdiv,i,sumdiv;

vector <int> primes;
int exprap(int a,int b)
{
    if(b==0)return 1;
    if(b%2==1)return a*exprap(a,b-1)%mod;
    int c=exprap(a,b/2)%mod;
    return c*c%mod;
}
void precalc()
{
    c[0]=1;
    c[1]=1;
    int i,j;
    for (i=2;2*i<=l;i++)
        if(c[i]==0)
            for(j=2;j*i<=l;j++)
                c[i*j]=1;
    for (i=2;i<=l;i++)
        if(c[i]==0)primes.push_back(i);
}
signed main()
{
    precalc();
    fin>>Q;
    while(Q--)
    {
        fin>>x;
        nrdiv=1;
        sumdiv=1;
        for (auto k:primes)
        {
            if(k*k>x)break;
            int p=0;
            while(x%k==0)
            {
                x/=k;
                p++;
            }
            if(p>0)
            {
                nrdiv*=(p+1);
                sumdiv=sumdiv*((exprap(k,p+1)-1+mod)%mod)%mod*exprap(k-1,mod-2)%mod;
            }
        }
        if(x!=1)
        {
            nrdiv*=2;
            sumdiv=sumdiv*((exprap(x,2)-1+mod)%mod)%mod*exprap(x-1,mod-2)%mod;
        }
        fout<<nrdiv<< " "<<sumdiv<<'\n';
    }
    return 0;
}
