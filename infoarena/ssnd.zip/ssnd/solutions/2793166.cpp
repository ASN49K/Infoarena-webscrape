/* [A][M][C][B][N] / [K][R][I][P][6][8] */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const char sp = ' ', nl = '\n';
const int MOD = 9001;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int Nmax = 1e6;
bitset<Nmax + 1> eratostene;
vector<int> primes;
void init() {
    for (int i = 2; i <= Nmax; ++i) {
        eratostene[i] = 1;
    }
    for (int i = 2; i <= Nmax; ++i) {
        if (eratostene[i]) {
            primes.push_back(i);
            for (long long j = 1ll * i * i; j <= Nmax; j += i)
                eratostene[j] = 0;
        }
    }
}

long long spf(long long n) {
    for (int p : primes)
        if (n % p == 0)
            return p;
    return n;
}

void solve() {
    long long n, num(1), sum(1);
    fin >> n;
    while (n > 1) {
        long long p = spf(n);
        int N(1), S(p);
        while (n % p == 0) {
            n /= p;
            S *= p;
            N++;
        }
        num *= N;
        sum *= (S - 1) / (p - 1);
    }
    fout << num << sp << sum << nl;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    init();
    int t;
    fin >> t;
    while (t--)
        solve();
}