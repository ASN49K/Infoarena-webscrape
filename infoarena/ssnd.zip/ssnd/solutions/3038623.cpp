
#include <fstream>
#include <bitset>
#include <vector>
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
bitset<1000001> ciur;
vector<int> prime;
void eratostene()
{
   prime.push_back(2);
   for(int i=3;i<=1000000;i=i+2)
       if(ciur[i]==0)
       {
           prime.push_back(i);
           for(int j=i+i;j<=1000000;j=j+i)
              ciur[j]=1;
       }
}
int t;
const int M=9973;
long long n;
long long putere(long long a,long long b)
{
    if(b==0)
      return 1;
    long long p=putere(a,b/2);
    p=(p*p*1LL)%M;
    if(b%2==1)
       return (p*a*1LL)%M;
    else
       return p;
}
void solve(long long n)
{
    long long nr=1;
    long long suma=1;
    for(int i=0;i<prime.size() && prime[i]*prime[i]<=n;i++)
    {
        int l=0;
        ///cout<<suma<<" ";
        while(n%prime[i]==0)
          {
              l++;
              n=n/prime[i];
          }
        if(l)
        {
          nr=(nr*(l+1)*1LL)%M;
          suma=(suma*((putere(prime[i],l+1)-1)%M*putere(prime[i]-1,M-2)*1LL)%M*1LL)%M;
        }
    }
    if(n>1)
    {
      nr=(nr*2*1LL)%M;
      suma=(suma*((n*n*1LL)%M-1)*putere(n-1,M-2)*1LL)%M;
      if(n==9973)
         suma=suma+9973;
    }
    cout<<nr<<" "<<suma<<'\n';
}
int main()
{
    eratostene();
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>n;
        solve(n);
    }
    return 0;
}
