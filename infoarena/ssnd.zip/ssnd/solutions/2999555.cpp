#include <fstream>
#include <vector>
#define ll long long
#define mod 9973
using namespace std;
ifstream f("ssnd.in");
ofstream g("ssnd.out");
ll t,n;
const int N=1e6+5;
bool a[N];
vector<ll>b;
ll exp(ll x,ll put)
{
    ll y=1;
    while(put)
    {
        if(put%2)
        {
            y*=x;
            y%=mod;
        }
        put/=2;
        x=(x*x)%mod;
    }
    return y;
}
int main()
{
    f>>t;
    for(int i=2;i*i<=1e6;i++)
        if(a[i]==0)
            for(int j=i*i;j<=1e6;j+=i)
                a[j]=true;
    for(int i=2;i<=1e6;i++)
        if(!a[i])
            b.push_back(i);
    while(t--)
    {
        f>>n;
        ll nr=1;
        ll s=1;
        for(auto x : b)
        {
            ll p=x;
            ll nr1=0;
            while(n%x==0)
            {
                p=(p*x)%mod;
                n/=x;
                nr1++;
            }
            nr*=(nr1+1);
            if(nr1)
            {
                p--;
                if(p<0)
                    p+=mod;
                p=(p*(exp(x-1,mod-2)))%mod;
                s=(s*p)%mod;
            }
            if(x*x>n)
                break;
        }
        if(n!=1)
        {
            nr*=2;
            ll p=(n*n)%mod;
            p--;
            if(p<0)
                    p+=mod;
            p=(p*(exp(n-1,mod-2)))%mod;
            s=(s*p)%mod;
        }
        g<<nr<<" "<<s<<'\n';
    }
    return 0;
}
