#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

const int MOD = 9973;
const int NMAX = 1e6;

bool sieve[1 + NMAX];
std::vector<int> primes;

inline void sieve_of_eratosthenes() {
  primes.push_back(2);

  for (int i = 3; i * i <= NMAX; ++i) {
    if (!sieve[i]) {
      primes.push_back(i);
      for (int j = i * i; j <= NMAX; j += 2 * i)
        sieve[j] = true;
    }
  }
}

int main() {
  std::ifstream in("ssnd.in");
  std::ofstream out("ssnd.out");

  sieve_of_eratosthenes();

  int n, a;
  int exp, num, sum;
  in >> n;
  while (in >> a) {
    num = sum = 1;

    for (int div_ind = 0; div_ind < (int)primes.size() && a != 1; ++div_ind) {
      exp = 0;
      while (a % primes[div_ind] == 0) {
        a /= primes[div_ind];
        ++ exp;
      }

      num = (num * (exp + 1)) % MOD;
      sum = (sum * ((int)pow(primes[div_ind], exp + 1) - 1) / (primes[div_ind] - 1)) % MOD;
    }

    if (a != 1) {
      exp = 1;
      num = (num * (exp + 1)) % MOD;
      sum = (sum * ((int)pow(a, exp + 1) - 1) / (a - 1)) % MOD;
    }

    out << num << ' ' << sum << '\n';
  }
  return 0;
}