#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int main(){
    long long n, c = 0, s = 0;
fin >> n;
for (long long i=1; i*i<=n;i++) {
    if (n%i ==0) {
         c++;
        s+=i;
       if (i*i!=n) {
            c++;
            s+=n/i;
        }
    }
}

fout << c << ' ' << s;

   fin.close();
   fout.close();


    return 0;
}
