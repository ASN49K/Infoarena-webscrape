#include <iostream>
#include <cmath>
using namespace std;

const int MOD = 9973;

long long ridicare_la_putere(long long x, int n) {
	if (n == 0)
		return 1;
	if (n % 2 == 0)
		return ridicare_la_putere(x * x % MOD, n / 2) % MOD;
	return x * ridicare_la_putere(x * x % MOD, (n - 1) / 2) % MOD;
}

void invers_modular(long long a, long long b, long long& x, long long& y) {
	if (!b) {
		x = 1;
		y = 0;
	} else {
		long long x0, y0;
		invers_modular(b, a % b, x0, y0);
		x = y0;
		y = x0 - y0 * a / b;
	}
}

int main() {
	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);

	int t;
	long long n;
	long long d;
	long long suma;
	
	cin >> t;

	while (t --) {
		cin >> n;

		d = 1;
		suma = 1;
		int nr;

		for (long long i = 2;i * i <= n;i ++) {
			if (n % i == 0) {
				nr = 0;

				while (n % i == 0) {
					n /= i;
					nr ++;
				}

				long long inv, alt;

				invers_modular(i - 1, MOD, inv, alt);

				inv %= MOD;

				if (inv < 0)
					inv += MOD;

				suma = suma * (((ridicare_la_putere(i, nr + 1) - 1) * inv)) % MOD;
				d *= (nr + 1);
			}
		}

		if (n != 1) {
			d *= 2;
			suma = (suma * (n + 1)) % MOD;
		}

		cout << d << ' ' << suma <<  '\n';
	}

	return 0;
}