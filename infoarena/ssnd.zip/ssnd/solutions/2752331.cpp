
#include <fstream>

using namespace std;

int main()
{
    ifstream fin("ssnd.in");
    ofstream fout("ssnd.out");
    int n,cnt=0;
    long long d=1,s=0,a;
    fin >> n;
    for(int i=0; i<n; i++)
    {
        fin >> a;
        cnt=0;
        d=1;
        s=0;
        while(d * d <= a)
        {
            if(a % d == 0)
            {
                s = s + d;
                s = s % 9973;
                cnt++;

                if(d * d < a)
                {
                    s = s + a/d;
                    s = s % 9973;
                    cnt++;
                }
            }
            d++;
        }
        fout << cnt << " " << s << '\n';
    }
    return 0;
}
