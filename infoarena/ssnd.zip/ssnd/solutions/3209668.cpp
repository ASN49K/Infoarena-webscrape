#include <fstream>
#include <vector>

using namespace std;

typedef long long ll;

const int MOD = 9973;
const int Nmax = 1000000;

bool ciur[Nmax + 5];
vector<int> prime;

void init_ciur(){
    ciur[0] = ciur[1] = 1;
    for(ll i = 2; i * i <= Nmax; i++){
        if(!ciur[i]){
            for(ll j = i * i; j <= Nmax; j += i){
                ciur[j] = 1;
            }
        }
    }
}

void aflare_prime(){
    for(int i = 2; i <= Nmax; i++){
        if(!ciur[i]){
            prime.push_back(i);
        }
    }
}

ll lgput(ll baza, ll exp){
    ll sol = 1;

    while(exp){
        if(exp & 1){
            sol = (sol * baza) % MOD;
        }

        baza = (baza * baza) % MOD;
        exp >>= 1;
    }

    return sol;
}

ll inv_mod(ll nr, ll mod){
    return lgput(nr, mod - 2);
}

int main(){
    int t;
    ll nr, sum_div, nr_div, div, exp;

    ifstream fin("ssnd.in");
    ofstream fout("ssnd.out");

    fin >> t;

    init_ciur();
    aflare_prime();

    for(int i = 1; i <= t; i++){
        fin >> nr;

        sum_div = 1;
        nr_div = 1;
        for(unsigned poz = 0; poz < prime.size() && prime[poz] * prime[poz] <= nr; poz++){
            div = prime[poz];

            if(nr % div == 0){
                exp = 0;
                while(nr % div == 0){
                    exp++;
                    nr /= div;
                }

                nr_div = (nr_div * (exp + 1)) % MOD;
                sum_div = ((sum_div * (lgput(div, exp + 1) - 1)) % MOD * inv_mod(div - 1, MOD)) % MOD;
            }
        }

        if(nr > 1){
            nr_div = (nr_div * 2) % MOD;
            sum_div = ((sum_div * (lgput(nr, 2) - 1)) % MOD * inv_mod(nr - 1, MOD)) % MOD;
        }

        fout << nr_div << " " << sum_div << '\n';
    }

    return 0;
}
