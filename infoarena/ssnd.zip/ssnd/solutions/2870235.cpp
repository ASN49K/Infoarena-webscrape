#include <iostream>
#import<vector>
#import<bitset>
#import<cmath>
using namespace std;
const int N=1e6,mod=9973,VMAX=1e6;
vector<int>v={2,3};
int X=(int)sqrt(N)+1;
void ciur()
{
    bitset<N+10>c;
    for(int i=3*3;i<=N;i+=6)
    {
        c[i]=1;
    }
    for(int i=5;i*i<=N;i+=4)
    {
        for(int j=i*i;j<=N;j+=2*i)
        {
            c[i]=1;
        }
        i+=2;
        for(int j=i*i;j<=N;j+=2*i)
        {
            c[i]=1;
        }
    }
    for(int i=5;i<=N;i+=4)
    {
        if(!c[i])
        {
            v.push_back(i);
        }
        i+=2;
        if(!c[i])
        {
            v.push_back(i);
        }
    }
}
main()
{
    ciur();
    freopen("ssnd.in","r",stdin);
    freopen("ssnd.out","w",stdout);
    int tt;
    cin>>tt;
    while(tt--)
    {
        long long n;
        cin>>n;
        int nr=1;
        long long s=1;
        for(vector<int>::iterator it=v.begin();it!=v.end() && (*it)*(*it)*1LL<=n && n!=1;it++)
        {
            int cnt=0,x=(*it);
            long long a=1,sum=1;
            while(n%(1LL*x)==0)
            {
                n/=(1LL*x);
                cnt++;
                a*=1LL*x;
                sum+=a;
            }
            nr*=(cnt+1);
            s*=sum;
            s%=mod;
        }
        if(n!=1)
        {
            nr*=2;
            s*=(n+1);
        }
        cout<<nr<<' '<<s%mod<<'\n';
    }
}
