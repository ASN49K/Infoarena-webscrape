#include <fstream>
#include <vector>
#include <bitset>
#define pb push_back
#define endl '\n'
#define int long long 
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int NMAX=1e7+5;
const int MOD=9973;
vector<int>primes;
bitset<NMAX>ciur;
int mx=1;
int ridicare(int a,int b)
{
    int p=1;
    while(b)
    {
        if(b%2==1)
        p=(p%MOD * a%MOD)%MOD;
        a=(a%MOD*a%MOD)%MOD;
        b/=2;
    }
    return p;
}
void eratostene()
{
    primes.pb(2);
    ciur[0]=1;ciur[1]=1;
    for(int i=4;i<NMAX;i+=2)
    {
        ciur[i]=1;
    }
    for(int i=3;i*i<NMAX;i+=2)
    {
        if(!ciur[i])
        {
            primes.pb(i);
            mx++;
            for(int j=i*i;j<=NMAX;j+=i*2)
            {
                ciur[j]=1;
            }
        }
    }
}
signed main()
{
    int t;
    eratostene();
    fin>>t;
    while(t--)
    {
        int n,n_vechi;
        fin>>n;
        n_vechi=n;
        int cnt=0;
        int d=1;
        int s=1;
        if(!ciur[n])
        {
            fout<<"2"<<" "<<n+1<<endl;
            continue;
        }
        while(n>1 && cnt<=mx)
        {
            int p=primes[cnt];
            int cati=0;
            if(n%p==0){
            while(n%p==0)
            {
                cati++;
                n/=p;
            }
            cati++;
            d=(d%MOD * (cati)%MOD)%MOD;
            s=(s%MOD*( (ridicare(p,cati)%MOD -1 )%MOD * ridicare(p-1,MOD-2)%MOD )%MOD)%MOD;
        }
        cnt++;
        if(cnt>mx)
        break;
        if(primes[cnt]*primes[cnt]>n && n>1)
        {
            cati=2;
            p=n;
            d=(d%MOD * (cati)%MOD)%MOD;
            s=(s%MOD*( (ridicare(p,cati)%MOD -1 )%MOD * ridicare(p-1,MOD-2)%MOD )%MOD)%MOD;
            break;
        }
        }
        if(n>1 && n_vechi==n)
        {
            fout<<"2"<< " "<<(n+1)%MOD<<endl; 
            continue;
        }
        fout<<d<<" "<<s<<endl;
    }
}