#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");
int ciur[1000005];
int p[1000005];
long long t, n;
int k = 0;

void build_ciur()
{
    ciur[0] = 1;
    ciur[1] = 1;

    for(int i = 2; i*i<=1000000; i++)
    {
        if(ciur[i] == 0)
        {
            k++;
            p[k] = i;
            for(int j = 2; i*j<=1000000; j++)
            {
                ciur[i*j] = 1;
            }
        }
    }
}

inline int pow(int x, int p) {
	int rez = 1;
	x %= 9973;

	for(; p; p >>= 1) {
		if(p & 1) {
			rez *= x;
			rez %= 9973;
		}

		x *= x;
		x %= 9973;
	}

	return rez;
}

void solve()
{
    f>>n;

    int put;
    int nd = 1;
    int sd = 1;
    for(int i = 1; i<=k && 1LL * p[i] * p[i] <=n; i++)
    {
        if(n % p[i] > 0)
        {
            continue;
        }

        put = 0;
        while(n % p[i] == 0)
        {
            n /= p[i];
            put++;
        }

        nd *= (put+1);

        int p1 = (pow(p[i], put+1) - 1) % 9973;
		int p2 = pow(p[i]-1, 9973-2) % 9973;

		sd = (((sd * p1) % 9973) * p2) % 9973;
    }

    if(n > 1)
    {
        nd *= 2;
        sd = (1LL*sd*(n+1) % 9973);
    }

    g<<nd<<" "<<sd<<'\n';
}

int main()
{
    build_ciur();
    f>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
