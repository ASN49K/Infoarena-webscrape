#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void div(long x)
    {
        int d = 1;
        int rad = sqrt(x);
        int k = 0;

        while(d<=x)
            {
                if(x%d==0)
                    {
                        k++;
                        int s = s+d;
                    }
                d++;
            }
        g<<k<<" "<<s<<endl;
    }

int main()
{
    int n,i,x;
    f>>n;

    for(i=1;i<=n;i++)
            f>>x[i];

    for(i=1;i<=n;i++)
        div(x[i]);

    return 0;
}
