//ssnd
#include <bits/stdc++.h>
using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

int v[78500];
int main()
{
    long long i,j,k=1;
    bitset <1000010> bit;
    //1 compus 0 prim
    bit[0]=bit[1]=1;

    for(i=2;i<=1000000;i++)
    {
        if(bit[i]==0)
        {
            v[k]=i;
            k++;
            for(j=i*i;j<=1000000;j=j+i)
            {
               bit[j]=1;
            }
        }
    }
    //return 0;
    //cout<<v[1]<<" "<<v[2]<<" ";
    int t,e,d;
    long long n,sd,nd;
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>n;
        sd=1;
        nd=1;
        //cout<<n<<"\n";
        for(j=1;v[j]*v[j]<=n;j++)
        {
            d=v[j];
            e=0;
            while(n%d==0)
            {
                e++;
                n=n/d;
            }
            if(e>0)
            {
                int nrsd=((pow(d,e+1)-1)/(d-1));
                sd=(sd*nrsd)%9973;
                nd=nd*(e+1);
            }
            //cout<<d<<" "<<e<<" "<<j<<"\n";
            //cout<<((pow(d,e+1)-1)/(d-1))<<"\n";
        }
        if(n>1)
        {
            sd=(sd*((n*n-1)/(n-1)))%9973;
            nd=nd*2;
        }
        fout<<nd<<" "<<sd<<"\n";

    }

    return 0;
}
