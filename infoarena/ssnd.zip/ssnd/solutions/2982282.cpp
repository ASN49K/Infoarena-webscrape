#include <bits/stdc++.h>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

long long n,m,i,j,a,e,d,s,p,maxim;
bitset <1000010> b;
vector <int> prime;

int exponentiere(int a,int b)
{
    if(a==0)
        return 0;
    if(b==0)
        return 1;
    int x;
    if(b%2==0)
    {
        x=exponentiere(a,b/2);
        x=(x*x)%9973;
    }
    else
    {
        x=a;
        x=(x*exponentiere(a,b-1))%9973;
    }
    return x;
}

int main()
{
    for(i=2; i<=1000000; i++)
    {
        if(b[i]==0)
        {
            prime.push_back(i);
            for(j=2; i*j<=1000000; j++)
            {
                b[i*j]=1;
            }
        }
    }
    f>>n;
    for(i=1; i<=n; i++)
    {
        f>>a;
        m=1;
        d=2;
        p=1;
        s=1;
        while(a>1)
        {
            e=0;
            while(a%d==0)
            {
                e++;
                a/=d;
            }
            if(e)
            {
                e++;
                p=p*(e);
                s=(s*exponentiere(d,e)/(d-1))%9973;
            }
            if(d*d>a)
            {
                d=a;
            }
            else
            {
                d=prime[++m];
            }
        }
        g<<p<<' '<<s<<'\n';
    }
    return 0;
}
