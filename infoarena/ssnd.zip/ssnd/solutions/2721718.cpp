#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bool ciur[2000003];
long long prime[1000003];
long long nr;
long long x,n;

void erat()
{
    ciur[1]=1;
    ciur[0]=1;
    for(long long i=2; i<1000003; i++)
    {
        if(ciur[i]==0)
        {
            prime[nr++]=i;
            for(long long j=i*i; j<1000003; j+=i)
            {
                ciur[j]=1;
            }
        }
    }
}

int main()
{
    fin>>n;
    erat();
    while(n--)
    {
        long long nr=1;
        long long sum=1;
        fin>>x;
        long long copie=x;
        for(int i=0; prime[i]*prime[i]<=copie; i++)
        {
            int exponent=0;
            while(x%prime[i]==0)
            {
                exponent++;
                x/=prime[i];
            }
            nr=nr*(exponent+1);
            sum=sum*(pow(prime[i],exponent+1)-1)/(prime[i]-1);
            sum%=9973;
        }
        if(x==copie)
        {
            fout<<2<<" "<<(x+1)%9973;
        }
        else fout<<nr<<" "<<sum%9973<<"\n";
    }
    return 0;
}
