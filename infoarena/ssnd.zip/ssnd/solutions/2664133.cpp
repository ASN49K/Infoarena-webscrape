#include <fstream>

using namespace std;

#define MAX 1000003
#define MOD 9973

bool er[MAX];
int primes[MAX];
long long sum;
int primesno, num;


inline void erathostenes() {
    primesno = 1;
    primes[1] = 2;
	for(int i=3;i<MAX; i +=2)
		if (! er[i]) {
			++primesno;
			primes[primesno] = i;

			for(int j=i + i; j<MAX; j+= i)
				er[i] = true;
		}
}


inline int pow(int x, int p) {
	int res = 1;
	while(p) {
		if (p & 1) {
			res *= x;
			res %= MOD;
		}

		x *= x;
		x %= MOD;
		p >>= 1;
	}
	return res;
}


inline void solve(long long x) {
	sum = num = 1;
	int divno = 0;

	for(int i=1; 1LL*primes[i]*primes[i] <=x && i <= primesno; ++i)
		if (x % primes[i] == 0) {
			divno = 0;
			while(x % primes[i] == 0) {
				x /= primes[i];
				++divno;
			}

			num *= divno + 1;
			sum = sum * (pow(primes[i], divno + 1) - 1) * pow(primes[i] - 1, MOD - 2) % MOD;
		}

	if (x > 1) {
		num <<= 1;
		sum = sum * (x + 1) % MOD;
	}
}


int main() {
	ifstream fin ("ssnd.in");
	ofstream fout("ssnd.out");

	int n;
	long long x;
	fin >> n;

	erathostenes();
	for(int i=1; i<=n; ++i) {
		fin >> x;
		solve(x);
		fout << num << " " << sum << "\n";
	}

	return 0;
}
