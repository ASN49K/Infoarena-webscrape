#include <bits/stdc++.h>
#define DAU ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define PLEC return 0;

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
#define cin fin
#define cout fout

#define N 1000001
#define mod 9973
#define asa pair < int , int >
long long f[N], p[N/2], prime, n, x;

void ciur()
{
    const int k = 1000000;
    f[1] = 1;
    for(int i = 2 ; i*i <= k ; i++)
    {
        if(f[i] == 0)
        {
            for(int j = 2*i ; j <= k ; j += i)f[j] = 1;
        }
    }
    for(int i = 1 ; i <= k ; i++)
    {
        if(f[i] == 0)
        {
            p[++prime] = i;
        }
    }
}
long long putere(int a, int b)
{
    int prod = 1;
    for(int i = 1 ; i <= b ; i++)
    {
        prod *= a;
    }
    return prod;
}
asa facem(long long x)
{
    long long nr = 1;
    long long suma = 1;
    int i = 1;
    while(x != 1)
    {
        int d = 0;
        while(x%p[i] == 0)
        {
            x /= p[i];
            d++;
        }
        nr *= d+1;
        suma *= (putere(p[i],d+1)-1)/(p[i]-1);
        suma %= mod;
        i++;
    }
    return {nr,suma};
}

int main()
{
    ciur();
    cin >> n;
    for(int i = 1 ; i <= n ; i++)
    {
        cin >> x;
        asa m = facem(x);
        cout << m.first << " " << m.second << '\n';
    }
    PLEC
}
