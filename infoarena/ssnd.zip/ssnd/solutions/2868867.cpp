#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
using ll = long long;
const int NMAX = 100003, MOD = 9973;
bool c[NMAX];
vector <int> nrp;

void ciur()
{
    nrp.push_back(2);
    for (int i = 3; i * i <= NMAX; i += 2)
        if (!c[i])
            for (int j = i * i; j <= NMAX; j += (i << 1))
                c[j] = 1;
    for (int i = 3; i <= NMAX; i += 2)
        if (!c[i])
            nrp.push_back(i);
}
ll pwr(int a, int b)
{
    ll ans = 1;
    while (b)
    {
        if (b & 1)
            ans *= a;
        a *= a;
        b >>= 1;
    }
    return ans;
}
void desc(int n, int &nr, int &sum)
{
    nr = 1, sum = 1;
    for (int i = 0; i < nrp.size() and nrp[i] * nrp[i] <= n; i++)
        if (n % nrp[i] == 0)
        {
            int aux = 0, s = 1, p = 1;
            while (n % nrp[i] == 0)
            {
                p *= nrp[i];
                s += p;
                n /= nrp[i];
                aux++;
            }
            sum *= s;
            nr *= aux + 1;
        }
    if (n > 1)
    {
        nr <<= 1;
        sum *= (n * n - 1) / (n - 1);
        sum %= MOD;
    }
}
int main()
{
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
    ciur();
    int t;
    cin >> t;
    while (t--)
    {
        int n, nr, sm;
        cin >> n;
        desc(n, nr, sm);
        cout << nr << " " << sm << "\n";
    }
}
