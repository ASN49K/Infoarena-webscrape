//ALEXANDRU MICLEA
 
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <assert.h>
 
using namespace std;
using ll = long long;
 
#include <fstream>
//ifstream cin("input.in"); ofstream cout("output.out");
ifstream cin("ssnd.in"); ofstream cout("ssnd.out");
 
//VARIABLES

const ll maxn = 1e6 + 5;
int ciur[maxn];
vector <int> prime;

//FUNCTIONS

ll lgput (ll n, ll p){
    ll ans = 1;

    while (p){
        if (p % 2){
            ans *= n;
        }
        n *= n;
        p /= 2;
    }
    return ans;
}

//MAIN
 
int main() {

    for (int i = 2; i <= maxn; i++){
        if (!ciur[i]){
            prime.push_back(i);
            for (int j = i + i; j <= maxn; j += i){
                ciur[j] = 1;
            }
        }
    }

    //for (auto& x : prime) cout << x;

    int t; cin >> t;
    while (t--){
        ll nr = 1, sum = 1;
        ll n, cn; cin >> n;
        cn = n;
        vector <int> put(n + 1);

        for (int x : prime){
            while (n % x == 0){
                put[x]++;
                n /= x;
            }
        }

        for (int i = 2; i <= cn; i++){
            if (put[i]){
                nr *= (put[i] + 1);
                sum *= (lgput(i, put[i] + 1) - 1) / (i - 1);
            }
        }

        cout << nr << ' ' << sum << '\n';
    }
    
    return 0;
}