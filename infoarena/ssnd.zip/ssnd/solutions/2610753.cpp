#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int NMAX = 1000005;
const int MOD = 9973;
int primes[NMAX], c;
bool ciur[NMAX / 2];
long long sum_div, nr_div, d, power, val;

void init()
{
	for (int i = 2; i * i < NMAX; i++)
		if (!ciur[i])
		{
			primes[++c] = i;
			for (int j = i * i; j < NMAX; j += i)
				ciur[j] = 1;
		}
}

void divizori(long long numar)
{
	nr_div = sum_div = 1;
	int j = 1;
	d = primes[j];
	while (numar > 1 && 1LL * d * d <= numar)
	{
		power = 0; long long pr = 1;
		while (!(numar % d))
		{
			numar /= d;
			power++;
			pr *= d;
		}
		if (power)
		{
			nr_div *= (power + 1);
			sum_div = (1LL * sum_div * (pr * d - 1)) / (d - 1);
		}
		j++;
		d = primes[j];
	}
	if (numar != 1)
    {
        nr_div *= 2;
        sum_div = sum_div * (numar + 1);
    }
	fout << nr_div << ' ' << sum_div % MOD << '\n';
}

int main()
{
	int nr; fin >> nr;
	init();
	for (int i = 0; i < nr; i++)
	{
		fin >> val;
		divizori(val);
	}
	return 0;
}
