#include <bits/stdc++.h>
#define int long long

using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

const int nmax=1e6;
const int mod=9973;

int k, prime[nmax];
bool ciur[nmax+5];

void eratostene ()
{
    ciur[0]=ciur[1]=true;
    for (int i=2; i*i<=nmax; i++)
    {
        if (!ciur[i])
        {
            for (int j=i*i; j<=nmax; j+=i)
                ciur[j]=true;
        }
    }
    for (int i=2; i<=nmax; i++)
    {
        if (!ciur[i])
            prime[++k]=i;
    }

}

int prod (int a, int b)
{
    return (a*1LL*b)%mod;
}

int lgput (int a, int b)
{
    int p=1;
    a%=mod;
    while (b)
    {
        if (b%2==1)
            p=prod(p,a);
        a=prod(a,a);
        b/=2;
    }
    return p;
}

int inv (int n)
{
    return lgput(n,mod-2);
}

void desc (int n)
{
    int cnt=1, sum=1;
    for (int i=1; prime[i]*prime[i]<=n; i++)
    {
        int d=prime[i];
        int exp=0;
        while (n%d==0)
        {
            exp++;
            n/=d;
        }
        if (exp)
        {
            cnt*=(exp+1);
            int p=(lgput(d,exp+1)-1)%mod;
            sum=prod(prod(sum,p),inv(d-1));
        }
    }
    if (n>1)
    {
        cnt*=2;
        sum=prod(sum,(n+1));
    }
    fout << cnt << " " << sum << '\n';
}

signed main()
{
    eratostene();
    int t;
    fin >> t;
    for (int i=1; i<=t; i++)
    {
        int n;
        fin >> n;
        desc(n);
    }
    return 0;
}
