#include <bits/stdc++.h>

using namespace std;

auto first_divisor_until(size_t limit)
{
    vector<bool> is_prime(limit + 1, true);
    is_prime[0] = false;
    is_prime[1] = false;

    vector<int> first_divisor(limit + 1, 1);

    for (size_t i = 0; i <= limit; ++i)
        if (is_prime[i]) {
            first_divisor[i] = i;

            for (size_t j = i * i; j <= limit; j += i)
                if (is_prime[j]) {
                    is_prime[j] = false;
                    first_divisor[j] = i;
                }
        }

    return first_divisor;
}

auto solve(const vector<int>& first_divisor, long x)
{
    const auto Mod = 9973;

    auto exp = [] (int a, int b) {
        if (b == 0)
            return 1;
        if (a == 0)
            return 0;

        int res = 1;

        while (b) {
            if (b & 0x1) {
                res = (1l * res * a) % Mod;
                --b;
            }

            a = (1l * a * a) % Mod;
            b /= 2;
        }

        return res;
    };

    auto inv = [&] (int x) {
        return exp(x, Mod - 2);
    };

    auto num_div = 1l;
    auto sum_div = 1l;

    while (x != 1) {
        auto p = first_divisor[x];
        auto cnt = 0;

        do {
            x /= p;
            ++cnt;
        } while (x % p == 0);

        num_div *= (cnt + 1);

        sum_div *= 1l * ((exp(p, cnt + 1) - 1 + Mod) % Mod) * inv(p - 1) % Mod;
        sum_div %= Mod;
    }

    return make_pair(num_div, sum_div);
}

int main()
{
    const auto MaxVal = static_cast<size_t>(1e6);
    auto first_divisor = first_divisor_until(MaxVal);

    ifstream in{"ssnd.in"};
    ofstream out{"ssnd.out"};

    int nt;
    in >> nt;

    while (nt--) {
        long x;
        in >> x;
        auto [num_div, sum_div] = solve(first_divisor, x);
        out << num_div << ' ' << sum_div << '\n';
    }

    return 0;
}

