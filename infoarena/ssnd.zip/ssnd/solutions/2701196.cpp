//#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ifstream cin ("ssnd.in");
ofstream cout("ssnd.out");

int ciur[1000105],t,i,expo,x;
int prime[100105],nrprime;
long long sumdiv=1,nrdiv=1,n;

int main()
{
    int j;
    cin>>t;
    ciur[1]=1;
    for( i=2;i<=1000000;i++)
    {
        if(ciur[i]==0)
        {
            prime[++nrprime]=i;
            for( j=i+i;j<=1000000;j=j+i)
                ciur[j]=1;
        }
    }
    //for(i=1;i<=100;i++)
        //cout<<ciur[i]<<' ';
    for(i=1;i<=t;i++)
    {
        cin>>n;
        for(x=1;prime[x]*prime[x]<=n;x++)
        {
            j=prime[x];
            //cout<<ciur[j]<<' '<<n<<' '<<j;
            if(n%j==0)
            {
                while(n%j==0)
                {

                    expo++;
                    n=n/j;
                }
                nrdiv=nrdiv*(expo+1);
                sumdiv=sumdiv*((pow(j,(expo+1))-1)/(j-1));
                expo=0;
            }
        }
        if(n!=1)
        {
            nrdiv=nrdiv*2;
            sumdiv=sumdiv*((n*n-1)/(n-1));
        }
        cout<<nrdiv<<' '<<sumdiv%9973<<'\n';
        nrdiv=1; sumdiv=1;
    }

    return 0;
}
