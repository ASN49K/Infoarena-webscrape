#include <bits/stdc++.h>
#define ll long long 
#define MOD 9973

using namespace std;

ifstream in("ssnd.in");
ofstream out("ssnd.out");

int t; 
ll n;

ll fast_pow(ll n, ll p) {
    ll ans = 1;
    int lim = 64 - __builtin_clzll(p);

    for (int i = 0; i <= lim; i++) {
        if (p & (1ll << i)) {
            ans = (ans * n) % MOD; 
        }

        n = (n * n) % MOD;
    }

    return ans; 
}

ll inverse(ll n) {
    return fast_pow(n, MOD - 2);
}

vector<int> gen_primes() {
    bitset<1000005> marked;
    vector<int> primes; 
    int limit = 1000000;

    for (int i = 2; i <= limit; i++) {
        if (!marked[i]) {
            primes.push_back(i);

            for (int j = i + i; j <= limit; j += i) {
                marked[j] = 1;
            }
        }
    }

    return primes;
}

vector<pair<ll, int> > decompose(ll n, vector<int> &primes) {
    vector<pair<ll, int> > ans;
    
    for (auto i : primes) {
        if (i * i > n) {
            break;
        }

        if (n % i) {
            continue;
        }

        int count = 0;
        while (n % i == 0) {
            count++;
            n /= i;
        }

        ans.push_back({i, count});
    }

    if (n > 1) {
        ans.push_back({n, 1});
    }

    return ans;
}

void solve(vector<int> &primes) {
    in >> n;

    ll div_sum = 1, div_count = 1;
    auto decomp = decompose(n, primes);

    for (auto it : decomp) {
        ll div = it.first, div_pow = it.second;

        div_count = div_count * (div_pow + 1) % MOD;

        div_sum = (div_sum * (fast_pow(div, div_pow + 1) - 1)) % MOD;
        div_sum = (div_sum * inverse(div - 1)) % MOD;
    }

    out << div_count << ' ' << div_sum << '\n';
}

int main() {
    auto primes = gen_primes();

    in >> t;
    while (t--) {
        solve(primes);
    }

    return 0;
}