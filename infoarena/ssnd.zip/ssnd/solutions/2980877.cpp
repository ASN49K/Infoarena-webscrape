#include <bits/stdc++.h>

using namespace std;
ifstream in  ("ssnd.in");
ofstream out("ssnd.out");

#define maxN 1000000
#define MOD 9973

vector <bool> ciur(maxN+1);

vector <int> prime;

void calc(long long x){
    int nrdiv=1;
    long long sum=1;

    int d=0;
    while(d<prime.size() && prime[d]*prime[d]<=x){
        if(x%prime[d]==0){
            int put=0;
            long long pow=prime[d];
            while(x%prime[d]==0){
                put++;
                pow*=prime[d];
                x/=prime[d];
            }
            nrdiv*=(put+1);
            sum=sum*(pow-1)/(prime[d]-1);
            sum%=MOD;
        }
        d++;
    }
    if(x>1){
        nrdiv*=2;
        sum=sum*(x*x-1)/(x-1);
        sum%=MOD;
    }
    out<<nrdiv<<" "<<sum<<'\n';
}

int main(){
    ciur[0]=ciur[1]=1;
    for(int i=2;i*i<=maxN;i++){
        if(ciur[i]==0){
            for(int j=i*i;j<=maxN;j+=i){
                ciur[j]=1;
            }
        }
    }
    for(int i=2;i<=maxN;i++){
        if(ciur[i]==0){
            prime.push_back(i);
        }
    }
    int n;
    in>>n;
    for(int i=1; i<=n; i++){
        long long x;
        in>>x;
        calc(x);
    }
}
