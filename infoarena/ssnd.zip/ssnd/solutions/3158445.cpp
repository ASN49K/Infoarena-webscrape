#include <cstdio>

const int MOD = 9973;

int T;
long long N;

int main()
{
	freopen("ssnd.in","rt",stdin);
	freopen("ssnd.out","wt",stdout);

	scanf("%d\n", &T);
	while(T--)
	{
		scanf ("%lld\n", &N);
		int nr = 0, s = 0;

		for(long long i = 1; i <= N; ++i)
			if(N % i == 0)
				++nr,
				s += i,
				s %= MOD;

		printf("%d %d\n",nr, s);
	}
