#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

class InP {
	FILE *fin;
	char *buff;
	int sp;

public:
	InP(const char *p) {
		fin = fopen(p, "r");
		buff = new char[4096]();
		sp = 4095;
	}
	~InP() {
		fclose(fin);
	}
	char read_ch() {
		sp++;
		if (sp == 4096) {
			fread(buff, 1, 4096, fin);
			sp = 0;
		}
		return buff[sp];
	}

	InP &operator >>(int &n) {
		char c;
		int sgn = 1;
		while (!isdigit(c = read_ch()) && c != '-');
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else n = c - '0';
		while (isdigit(c = read_ch()))
			n = n * 10 + c - '0';
		n = n * sgn;
		return *this;
	}

	InP &operator >>(ll &n) {
		char c;
		int sgn = 1;
		while (!isdigit(c = read_ch()) && c != '-');
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else n = c - '0';
		while (isdigit(c = read_ch()))
			n = n * 10LL + c - '0';
		n = n * sgn;
		return *this;
	}

	InP &operator >> (char &n) {
		n = read_ch();
		while ((n = read_ch()) != '\n' && n != ' ');
		return *this;
	}

};

class OuP {
	FILE *fout;
	char *buff;
	int sp;

public:

	OuP(const char *p) {
		fout = fopen(p, "w");
		buff = new char[50000];
		sp = 0;
	}
	~OuP() {
		fwrite(buff, 1, sp, fout);
		fclose(fout);
	}
	void write_ch(char c) {
		if (sp == 50000) {
			fwrite(buff, 1, sp, fout);
			sp = 0;
		}
		buff[sp++] = c;
	}

	OuP &operator <<(int n) {
		if (n <= 9)
			write_ch(n + '0');
		else {
			*(this) << (n / 10);
			write_ch(n % 10 + '0');
		}
		return *this;
	}

	OuP &operator <<(ll n) {
		if (n <= 9)
			write_ch(n + '0');
		else {
			*(this) << (n / 10);
			write_ch(n % 10 + '0');
		}
		return *this;
	}

	OuP &operator <<(char c) {
		write_ch(c);
		return *this;
	}

	OuP &operator <<(const char *c) {
		while (*c) {
			write_ch(*c);
			c++;
		}
		return *this;
	}

};

// InP fin("file.in");
// OuP fout("file.out");

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int mod = 9973;

int t;

const int prmx = 1e6;
bitset<1000005> isprime;
vector<int> primes;
void compPrime() {

	isprime[1] = isprime[0] = 1;
	for (int i = 4; i <= prmx; i += 2)
		isprime[i] = 1;
	for (int i = 3; i * i <= prmx; i += 2)
		if (!isprime[i])
			for (int j = i * i; j <= prmx; j += i + i)
				isprime[j] = 1;
	isprime.flip();
	for (int i = 2; i <= prmx; i++)
		if (isprime[i])
			primes.pb(i);
}

ll expp(ll a, ll n) {
	ll p = 1;
	while (n) {
		if (n & 1)
			p = p * a % mod;
		a = a * a % mod;
		n >>= 1;
	}
	return p;
}

ll inv(ll x) {
	return expp(x, mod - 2);
}


void desc(ll n) {

	ll ans1, ans2;
	ans1 = ans2 = 1;

	for (int i = 0; primes[i] * primes[i] <= n  && n > 1; i++) {
		if (n % primes[i] == 0) {
			ll e = 0;
			while (n % primes[i] == 0)
				n /= primes[i], e++;
			ans1 = (ans1 * 1LL * (e + 1)) % mod;
			ans2 = ans2 * 1LL * (expp(primes[i], e + 1) - 1) * inv(primes[i] - 1) % mod;
		}
	}

	if (n > 1) {
		ans1 = (ans1 * 2) % mod;
		ans2 = ans2 * 1LL * (expp(n, 2) - 1) * inv(n - 1) % mod;
	}

	fout << ans1 << ' ' << ans2 << '\n';

}


int main() {

	fin >> t;
	compPrime();
	while (t--) {
		ll x;
		fin >> x;
		desc(x);
	}

	fin.close();
	fout.close();
	return 0;
}