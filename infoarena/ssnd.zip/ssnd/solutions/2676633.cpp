#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int T,x,nr,v[1000001],p[1000001];
void ciur(int n)
{
    int i=2;
        if(!p[i])
        {
            nr++;v[nr]=i;
            for(int j=i+i;j<=n;j+=i)
                p[j]=1;
        }
    for(i=3;i<=n;i+=2)
    {
        if(!p[i])
        {
            nr++;v[nr]=i;
            for(int j=i+i;j<=n;j+=i)
                p[j]=1;
        }
    }
}
int main()
{
    ciur(1000001);
    fin>>T;
    for(;T;--T)
    {
        fin>>x;
        int cx=x,curent=1;
        int nrdiv=1,suma=1;

        while(cx>1)
        {
            int putere=0,p=v[curent];
            curent++;
            if(p)
           {while(cx%p==0)
            {
             putere++;
             cx/=p;
            }

            nrdiv*=(putere+1);

            int p2=pow(p,putere+1);

            if(p-1)
            suma=(suma*((p2-1)/(p-1)));
            suma=suma%9973;}
        }fout << nrdiv<<' '<<suma << '\n';
    }
    return 0;
}
