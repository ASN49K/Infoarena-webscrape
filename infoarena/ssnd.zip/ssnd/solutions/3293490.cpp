#include <bits/stdc++.h>

using namespace std;
ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");
vector<int>v;
bitset<1000001>np;
void ciur()
{
    for(int i=2;i<=1000000;i++)
    {
        if(!np[i])
        {
            v.push_back(i);
            for(int j=i;1ll*i*j<=1000000;j++)
                np[j*i]=1;
        }
    }
}
const int mod=9973;
int power(int base,int power)
{
    int r=1;
    while(power)
    {
        if(power%2)
        {
            r*=base;
            r%=mod;
        }
        base*=base;
        base%=mod;
        power/=2;
    }
    return r;
}
void solve()
{
    int x;
    fin>>x;
    long long s=1,nr=1;
    int pos=0;
    while(pos<v.size() && v[pos]*v[pos]<=x)
    {
        int exp=0;
        while(x%v[pos]==0)
        {
            x/=v[pos];
            exp++;
        }
        if(exp)
        {
            nr*=(exp+1);
            s*=(power(v[pos],exp+1)-1+mod)%mod*power((v[pos]-1+mod)%mod,mod-2)%mod;
            s%=mod;
        }
        pos++;
    }
    if(x!=1)
    {
        nr*=2;
        s*=(x+1);
        s%=mod;
    }
    fout<<nr<<' '<<s<<'\n';
}
int main()
{
    int tc;
    ciur();
    fin>>tc;
    while(tc--)
        solve();
    return 0;
}
