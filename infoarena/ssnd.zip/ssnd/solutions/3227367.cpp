#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

bool ciur[1000001];
void seteaza()
{
    ciur[0] = true; ciur[1] = true;
    for(int i = 2; i*i <= 1000000; i++)
        if(ciur[i] == false)
            for(int j = 2; j*i <= 1000000; j++)
                ciur[i*j] = true;
}

int putere(int x, int y)
{
    int p = 1;
    while(y)
    {
        if(y % 2)
            p *= x%9973;
        x *= x%9973;
        y /= 2;
    }
    return p;
}

void ssnd(int n)
{
    int d = 2, nrdiv = 1, sumdiv = 1;
    if(ciur[n])
    {
        for(int i = 2; i*i <= n; i++)
        if(!ciur[i] && n % i == 0)
            {
                int p = 0, cn = n;
                while(cn % i == 0)
                {
                    p++;
                    cn /= i;
                }
                nrdiv *= (p + 1);
                sumdiv *= ((putere(i, p + 1)%9973 - 1)/(i - 1))%9973;
            }
    }
    else
    {
        nrdiv = 2;
        sumdiv = 1 + n;
    }
    g << nrdiv << ' ' << sumdiv << '\n';
}

int main()
{
    int t;
    f >> t;
    seteaza();
    while(t)
    {
        int n;
        f >> n;
        ssnd(n);
        t--;
    }
    return 0;
}
