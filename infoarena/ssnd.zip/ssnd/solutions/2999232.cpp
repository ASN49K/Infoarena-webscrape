#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int sz=1e6+2;
const int mod=9973;
int prim[80000], k=0, v[sz];
void ciur()
{
    int i, j;
    v[0]=v[1]=1;
    v[2]=0;
    for(i=4; i<=sz; i+=2) v[i]=1;
    for(i=3; i<=sz; i+=2)
    {
        if(!v[i])
        {
            for(j=2*i; j<=sz; j+=i)
            {
                v[j]=1;
            }
        }
    }
    for(i=2; i<=sz; i++)
    {
        if(!v[i]) prim[k ++]=i;
    }
}

void snr(long long x)
{
    int nr=1, i, d, p;
    long long s=0;
    for(i=0; prim[i]*prim[i]<x; ++i){
        if(x%prim[i]==0) s+=prim[i]+x/prim[i];
    }
    if(prim[i]*prim[i]==x) s+=prim[i];
    for(i=0; x!=1; i++){
        d=prim[i];
        p=0;
        if(d*d>x) d=x;
        while(x%d==0){
            ++p;
            x/=d;
        }
        nr*=(++p);
    }
    cout<<nr<<' '<<s%mod<<'\n';
}
int n;
long long x;
int main()
{
    ciur();
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>x;
        snr(x);
    }
    return 0;
}
