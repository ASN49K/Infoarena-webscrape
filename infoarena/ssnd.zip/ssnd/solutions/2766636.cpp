#include <iostream>
#include <fstream>
#include <bitset>
#define LIM 1000000

using namespace std;

ifstream fin  ("ssnd.in");
ofstream fout ("ssnd.out");

bitset<1000005> f;
int prime, p[80005];
int t, e, cnt, y, suma;
long long x;

int main (){
    f[0] = f[1] = 1;
    for(int i=4; i<=LIM; i+=2)
        f[i]=1;
    for(int i=3; i<=LIM/i; i+=2)
        if(f[i] == 0)
            for(int j=i*i; j<=LIM; j+=i)
                f[j]=1;

    p[++prime]=2;
    for(int i=3; i<=LIM; i+=2)
        if(f[i] == 0)
            p[++prime]=i;

    fin>>t;
    while(t--){
        fin>>x;

        cnt = 1;
        suma = 1;
        for(int i=1; p[i]<=x/p[i]; i++){
            e=0;
            y=1;
            while(x%p[i] == 0){
                e++;
                y *= p[i];
                y %= 9973;
                x/=p[i];
            }
            cnt *= (e+1);
            suma *= ((y * p[i] - 1) / (p[i] - 1)) % 9973;
            suma %= 9973;
        }

        if(x != 1){
            cnt *= 2;
            suma *= ((x * x - 1)/(x - 1));
            suma %= 9973;
        }

        fout<<cnt<<" "<<suma<<"\n";
    }

    return 0;
}
