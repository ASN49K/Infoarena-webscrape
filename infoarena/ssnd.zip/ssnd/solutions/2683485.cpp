#include <fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int s,i,k,nr;
long long n,x[1001];
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>x[i];
    for(i=1;i<=n;i++) {
        nr=0;
        s=0;
        for(k=1;k<=x[i]/k;k++)
            if(x[i]%k==0) {
                nr+=2;
                s=s+k+(x[i]/k);
                if(k==x[i]/k) {
                    nr--;
                    s=s-k;
                }
            }
        fout<<nr<<" "<<s;
        fout<<endl;
    }
    return 0;
}
