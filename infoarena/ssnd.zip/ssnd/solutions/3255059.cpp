#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void divizori(long x){
         int putere=1;
         int div=1;
         int nr_div =0;
         int v[1000];
         int s = 0;
    {
    while(div<=x){
         if(x%div == 0){
           v[div]=putere;
           putere++;
         }
       s+=div;
       div++;
    }
    nr_div = 1;
    for(int i=1;i<=x;i++)
     if(v[i]!=0){
        nr_div *= i+1;
    }
        g<<nr_div<<" "<<s%9973<<endl;
    }
}

int main()
{
    int t,i,x[1000];
    f>>t;

    for(i=1;i<=t;i++)
            f>>x[i];

    for(i=1;i<=t;i++)
        divizori(x[i]);

    return 0;
}

