#include<bits/stdc++.h>

using namespace std;

const int NMAX = 1000005;
const int MOD = 9973;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

long long n;
int t, k, w[NMAX],prime[NMAX];


void ciur()
{
    prime[0]=prime[1]=1;
    for(int i=2; i*i<=NMAX; i++)
        if(prime[i]==0)
        {
            w[++k]=i;
            for(int j=i+i; j<=NMAX; j+=i)
                prime[j]=1;
        }
}

int lgput(int base,int exp)
{
    int aux=base,ans=1;
    for(int i=1; i<=exp; i*=2)
    {
        if(i&exp)
            ans=(ans*aux)%MOD;
        aux=(aux*aux)%MOD;
    }
    return ans;
}


void solve()
{
    fin >> n;

    int	nd = 1, sd = 1;

    for(int i = 1; i <= k && 1LL * w[i] * w[i] <= n; i++)
    {
        if(n % w[i]) continue;
        int e = 0;

        while(n % w[i] == 0)
        {
            n /= w[i];
            e++;
        }

        nd *= (e+1);

        int p1 = (lgput(w[i], e+1) - 1) % MOD;
        int p2 = lgput(w[i]-1, MOD-2) % MOD;

        sd = (((sd * p1) % MOD) * p2) % MOD;
    }

    if(n > 1)
    {
        nd *= 2;
        sd = (1LL*sd*(n+1) % MOD);
    }

    fout << nd << " " << sd << "\n";
}

int main()
{
    ciur();
    fin>>t;
    while(t--)
    {
        solve();
    }
}
