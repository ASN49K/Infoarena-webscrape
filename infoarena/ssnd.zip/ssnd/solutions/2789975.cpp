
#include <fstream>
#include <cmath>
#include <iostream>
#include <vector>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
#define MAX 1000013
#define PRIME 9973

int countDivisors(vector<pair<int, int>> decomp)
{
    int cnt = 1;
    for (pair<int, int> p : decomp)
    {
        cnt *= (p.second + 1);
    }
    return cnt;
}

long long divisorsSum(vector<pair<int, int>> decomp)
{
    long long prod = 1;
    for (pair<int, int> p : decomp)
    {
        prod *= ((powl(p.first, p.second + 1) - 1) / (p.first - 1));
        prod %= PRIME;
    }
    return prod;
}

int main()
{
    int t, n;
    fin >> t;
    bool isPrime[MAX];
    fill(isPrime, isPrime + MAX + 1, true);
    for (int i = 2; i <= MAX; ++i)
    {
        if (isPrime[i])
        {
            for (int j = 2; j * i <= n; ++j)
            {
                isPrime[j * i] = false;
            }
        }
    }
    while (t-- > 0)
    {
        fin >> n;
        vector<pair<int, int>> decomp;
        int init = n;
        int lim = sqrt(init);
        for (int i = 2; i <= lim; ++i)
        {
            if (isPrime[i] && n % i == 0)
            {
                int exp = 0;
                while (n % i == 0)
                {
                    n /= i;
                    ++exp;
                }
                decomp.push_back({i, exp});
            }
        }
        if (decomp.empty())
        {
            decomp.push_back({init, 1});
        }
        fout << countDivisors(decomp) << " " << divisorsSum(decomp) << "\n";
    }
    return 0;
}
