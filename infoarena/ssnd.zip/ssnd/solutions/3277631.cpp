#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int mod=9973;
bitset <1000009> nonprim;
vector<int> prime;
void eratostene()
{
    for(int i=2;i<=1000008;i++)
    {
        if(!nonprim[i])
        {
            prime.push_back(i);
            for(int j=i;1ll*i*j<=1000008;j++)
                nonprim[i*j]=1;
        }
    }
}
inline int power(int base,int power)
{
    int res=1;
    base%=mod;
    while(power)
    {
        if(power%2)
        {
            res*=base;
            res%=mod;
        }
        base*=base;
        base%=mod;
        power/=2;
    }
    return res;
}
int invers(int n)
{
    return power(n,mod-2);
}
void tcase()
{
    long long n,nr=1,sum=1;
    fin>>n;
    int pos=0;
    while(prime[pos]*prime[pos]<=n && pos<prime.size())
    {
        int exp=0;
        while(n%prime[pos]==0)
        {
            n/=prime[pos];
            exp++;
        }
        nr*=(exp+1);
        if(exp)
            sum=sum*(power(prime[pos],exp+1)-1)%mod*invers(prime[pos]-1)%mod;
        pos++;
    }
    if(n!=1)
    {
        nr*=2;
        sum=(1ll*(n+1)*sum)%mod;
    }
    fout<<nr<<' '<<sum<<'\n';
}
int main()
{
    int tc;
    eratostene();
    fin>>tc;
    while(tc--)
        tcase();
    return 0;
}
