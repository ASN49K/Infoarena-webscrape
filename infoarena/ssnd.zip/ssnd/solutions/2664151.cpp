#include <fstream>

#include <bitset>

using namespace std;

#define MAX 1000003
#define MOD 9973

bool er[MAX];

int primes[MAX];
int primesno;

ifstream fin ("ssnd.in");
ofstream fout("ssnd.out");


void erathostenes() {
    primesno = 1;
    primes[1] = 2;
	for(int i=3;i<MAX; i +=2)
		if (er[i] == 0) {
			++primesno;
			primes[primesno] = i;

			for(int j=i + i; j<MAX; j+= i)
				er[j] = 1;
		}
}


inline int pow(int x, int p) {
	int res = 1;
	for(; p; p >>= 1) {
		if (p & 1) {
			res *= x;
			res %= MOD;
		}

		x *= x;
		x %= MOD;
	}
	return res;

}

int main() {
	int n;
	long long x, sum;
	int num, divno;
	fin >> n;
	erathostenes();

	for(; n>0; --n) {
		fin >> x;
		sum = 1;
        num = 1;
        divno = 0;

        for(int i=1; i <= primesno && 1LL * primes[i] * primes[i] <= x; ++i)
            if (x % primes[i] == 0) {
                divno = 0;
                while(x % primes[i] == 0) {
                    x /= primes[i];
                    ++divno;
                }

                num *= divno + 1;
                sum = sum * (pow(primes[i], divno + 1) - 1) % MOD;
                sum = sum * pow(primes[i] - 1, MOD - 2) % MOD;
            }

        if (x > 1) {
            num <<= 1;
            sum = sum * (x + 1) % MOD;
        }
        fout << num << " " << sum << "\n";
	}

	return 0;
}
