#include <fstream>
#include <vector>
#include <bitset>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int NMAX = 1e6 + 1;
const int MOD = 9973;

vector<int> primes;
bitset<NMAX> ciur;
int mx = 0;

long long ridicare(long long a, long long b)
{
    long long p = 1;
    a %= MOD;
    while (b)
    {
        if (b & 1) p = (p * a) % MOD;
        a = (a * a) % MOD;
        b >>= 1;
    }
    return p;
}

void eratostene()
{
    primes.push_back(2);
    ciur[0] = ciur[1] = 1;
    for (int i = 4; i < NMAX; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i < NMAX; i += 2)
    {
        if (!ciur[i])
            for (int j = i * i; j < NMAX; j += i * 2)
                ciur[j] = 1;
    }
    for (int i = 3; i < NMAX; i += 2)
        if (!ciur[i])
            primes.push_back(i);

    mx = primes.size();
}

int main()
{
    ios::sync_with_stdio(false);
    fin.tie(nullptr);

    eratostene();
    int t; fin >> t;

    while (t--)
    {
        long long n; fin >> n;
        long long n_vechi = n;
        int cnt = 0;
        long long d = 1;
        long long s = 1;

        if (!ciur[n])
        {
            fout << 2 << " " << (n + 1) % MOD << "\n";
            continue;
        }

        while (n > 1 && cnt < mx)
        {
            int p = primes[cnt];
            int cati = 0;
            if (n % p == 0)
            {
                while (n % p == 0)
                {
                    cati++;
                    n /= p;
                }
                cati++;
                d = (d * cati) % MOD;
                long long part = (ridicare(p, cati) - 1 + MOD) % MOD;
                long long inv = ridicare(p - 1, MOD - 2);
                s = (s * (part * inv % MOD)) % MOD;
            }
            if (cnt + 1 >= mx || (long long)primes[cnt + 1] * primes[cnt + 1] > n)
            {
                if (n > 1)
                {
                    cati = 2;
                    int p = n;
                    d = (d * cati) % MOD;
                    long long part = (ridicare(p, cati) - 1 + MOD) % MOD;
                    long long inv = ridicare(p - 1, MOD - 2);
                    s = (s * (part * inv % MOD)) % MOD;
                    n = 1;
                }
                break;
            }
            cnt++;
        }
        if (n > 1 && n_vechi == n)
        {
            fout << 2 << " " << (n + 1) % MOD << "\n";
            continue;
        }
        fout << d << " " << s << "\n";
    }
}
