#include <iostream>
#import<vector>
#import<bitset>
#import<cmath>
using namespace std;
#define int long long
const int N=1e6,mod=9973,VMAX=9973;
vector<int>v;
void ciur()
{
    bitset<N+10>c;
    v.push_back(2);
    v.push_back(3);
    for(int i=3*3;i<=N;i+=6)
    {
        c[i]=1;
    }
    for(int i=5;i*i<=N;i+=4)
    {
        if(!c[i])
        {
            for(int j=i*i;j<=N;j+=2*i)
            {
                c[i]=1;
            }
        }
        i+=2;
        if(!c[i])
        {
            for(int j=i*i;j<=N;j+=2*i)
            {
                c[i]=1;
            }
        }
    }
    for(int i=5;i<=N;i+=4)
    {
        if(!c[i])
        {
            v.push_back(i);
        }
        i+=2;
        if(!c[i])
        {
            v.push_back(i);
        }
    }
}
void ciurul()
{
    bitset <1+VMAX> c;
    for (int i = 2; i * i <= VMAX; i++)
    {
        if (!c[i])
        {
            for (int multiplu = i * i; multiplu <= VMAX; multiplu += i)
            {
                c[multiplu] = 1;
            }
        }
    }
    for (int i = 2; i <= VMAX; i++)
    {
        if (!c[i])
        {
            v.push_back(i);
        }
    }
}
main()
{
    ciur();
    freopen("ssnd.in","r",stdin);
    freopen("ssnd.out","w",stdout);
    int tt;
    cin>>tt;
    while(tt--)
    {
        long long n;
        cin>>n;
        int nr=1;
        long long s=1;
        for(int i=0;i<v.size() && n!=1 && 1LL*v[i]*v[i]<=n;i++)
        {
            if(n%v[i]==0)
            {
                int cnt=0;
                long long a=1,sum=1;
                while(n%(1LL*v[i])==0)
                {
                    n/=v[i];
                    cnt++;
                    a*=v[i];
                    sum+=a;
                }
                nr*=(cnt+1);
                s*=sum;
                s%=mod;
            }
        }
        if(n!=1)
        {
            nr*=2;
            s*=(n+1);
        }
        cout<<nr%mod<<' '<<s%mod<<'\n';
    }
}
