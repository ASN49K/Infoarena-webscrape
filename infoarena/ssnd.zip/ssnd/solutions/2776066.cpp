#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ciur.in");
ofstream fout ("ciur.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

const int N = 2e6 + 5;

vector < bool > prime(N, true);

int Ciur(int n)
{
    int ans = 0;
    for(int i = 2; i <= n; ++i) {
        if(prime[i] == true) {
            ++ans;
            for(int j = i + i; j <= n; j += i) {
                prime[j] = false;
            }
        }
    }
    return ans;
}

int main()
{
    usain_bolt();

    int n;

    fin >> n;
    fout << Ciur(n);
    return 0;
}
