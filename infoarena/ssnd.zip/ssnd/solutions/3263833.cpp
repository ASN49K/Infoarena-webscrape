
#include<fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int M=9973,dim=1000000;
int u[dim+3],prim[dim/3],nrprime;

void Ciur(){
int i,j;
for(i=3;i*i<=dim;i=i+2)
    if(u[i]==0)
        for(j=i*i;j<=dim;j=j+2*i)
            u[j]=1;


prim[++nrprime]=2;
for(i=3;i<=dim;i+=2)
    if(u[i]==0)
    prim[++nrprime]=i;
}




int Invers_Modular(int a){
int n=M-2,i,aa=a,rez=1;
for(i=n;i>=1;i=i/2){
    if(i%2==1)
        rez=(1ll*rez*aa)%M;
    aa=(1ll*aa*aa)%M;
}
return rez;
}

int main(){
    Ciur();
//for(int i=1;i<=100;i++)
//fout<<prim[i]<<" ";
long long int q,n,exp,d,prod,nrdiv,sumdiv,y,x,i;
fin>>q;
while(q--){
    fin>>n;
    sumdiv=1;
    nrdiv=1;
    for(i=1;prim[i]*prim[i]<=n;i++){
        d=prim[i];
        //fout<<d<<" ";
        if(n%d==0){
            exp=0;
            prod=d;
            while(n%d==0){
                exp++;
                prod=(prod*d) %M;
                n=n/d;
            }
            //fout<<d<<" "<<exp<<endl;
        nrdiv=(nrdiv*(exp+1))%M;
        prod--;

        if(prod<0)
            prod+=M;

        y=Invers_Modular(d-1);
        prod=(prod*y)%M;
        sumdiv=(sumdiv*prod)%M;
        }

    }
    if(n>1){
        nrdiv=(nrdiv*2)%M;
        x=(n*n-1)%M;
        y=Invers_Modular(n-1);
        x=(x*y)%M;
        sumdiv=(sumdiv*x)%M;
    }
     //fout<<endl;
    fout<<nrdiv<<" "<<sumdiv<<'\n';
}
}


