#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
#define int long long
int Mod=9973;
long long n,x;
bitset<1000003> a;
vector<int> prim;
signed main()
{
    fin>>n;
    for (int i=2;i<=1000000;i++)
    {
        if (a[i]==0)
        {
            prim.push_back(i);
            for (int j=2*i;j<=1000000;j+=i)
                a[j]=1;
        }
    }
    while (n--)
    {
        fin>>x;
        int nrd=1,sd=1;
        int d=0;
        while (d<prim.size() && prim[d]*prim[d]<=x)
        {
            int e=0;
            int aux=prim[d];
            int p=aux;
            while (x%aux==0) x/=aux,p*=aux,e++;
            nrd=nrd*(e+1);
            nrd%=Mod;
            sd=sd*(p-1)/(aux-1);
            sd%=Mod;
            d++;
        }
        if (x>1) nrd*=2,nrd%=Mod,sd*=x+1,sd%=Mod;
        fout<<nrd<<" "<<sd<<'\n';
    }
    return 0;
}
