#include <fstream>
#include <vector>
#include <cmath>


using namespace std;

const int MAX_N = 1e6, mod = 9973;

vector<int> ciur(){

    vector<int> res;
    vector<bool> prime(MAX_N + 1, true);

    res.push_back(2);
    for(int nr = 3; nr <= MAX_N; nr += 2){
        if(prime[nr]){
            res.push_back(nr);
            if((long long) nr * nr <= MAX_N)
            for(int i = nr * nr; i <= MAX_N; i += nr)
                prime[i] = false;
        }
    }
    return res;
}


int main()
{
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
         
    vector<int> prime = ciur();

    int T;
    long long N;
    cin >> T;

    for(; T > 0; --T){
        cin >> N;
        int cnt = 1, sum = 1, exp, div;
        for(int i = 0; i < prime.size() && prime[i] <= (int)sqrt(N) && N != 1; ++i){

            exp = 0, div = prime[i];
            while(N % prime[i] == 0){
                ++exp;
                div *= prime[i];
                N /= prime[i];
            }
            if(exp != 0){
                cnt *= (exp + 1);
                sum = sum * ((div - 1) / (prime[i] - 1) % mod) % mod;
            }
        }
        if(N != 1){
            cnt *= 2;
            sum = sum * (((long long)N * N - 1) / (N - 1) % mod) % mod;
        }
        cout << cnt << " " << sum << "\n";
    }
    
    cin.close();
    cout.close();

    return 0;
}