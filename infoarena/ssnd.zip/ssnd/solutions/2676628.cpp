#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
long long T,x,nr,v[10000001],p[10000001];
void ciur(long long n)
{
    for(long long i=2;i<=n;++i)
    {
        if(!p[i])
        {
            nr++;v[nr]=i;
            for(long long j=i+i;j<=n;j+=i)
                p[j]=1;
        }
    }
}
int main()
{
    ciur(1000001);
    fin>>T;
    for(;T;--T)
    {
        fin>>x;
        long long cx=x,curent=1;
        long long nrdiv=1,suma=1;

        while(cx>1)
        {
            long long putere=0,p=v[curent];

            while(cx%p==0)
            {
             putere++;
             cx/=p;
            }
            curent++;

            nrdiv*=(putere+1);

            long long p2=pow(p,putere+1);


            suma=(suma*((p2-1)/(p-1)));
            suma=suma%9973;
        }fout << nrdiv<<' '<<suma << '\n';
    }
    return 0;
}
