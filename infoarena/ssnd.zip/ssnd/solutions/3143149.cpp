#include <iostream>
#include <fstream>
#define mod 9973
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bool c[1000005];
long long v[100005];
long long nr[10005] , nrmax , cnt , t , ndiv , sdiv , pwr , b;

long long lgput(long long n , long long p){
    if(p == 0){
        return 1;
    }
    else if(p == 1){
        return n;
    }
    long long x=lgput(n , p/2);
    if(p%2 == 0){
        return x*x;
    }
    else{
        return n*x*x;
    }
}

int main()
{
    fin>>t;
    for(long long i=1 ; i<=t ; i++){
        fin>>nr[i];
        if(nr[i] > nrmax)
            nrmax=nr[i];
    }
    c[0]=c[1]=1;
    for(long long i=2 ; i <=1000000 ; i++){
        if(c[i] == 0){
            for(long long j=i*i ; j <= 1000000 ; j+=i)
                c[j]=1;
        }
    }
    for(long long i=2 ; i<1000000 ; i++){
        if(c[i] == 0){
            ++cnt;
            v[cnt]=i;
            cout << i << endl;

        }
    }
    for(long long i=1 ; i<=t ; i++){
        ndiv=1;
        sdiv=1;
        for(long long j=1 ; j <= cnt && v[j]<=nr[i] ; j++){
            pwr=0;
//            cout << nr[i] << ' ' << v[j] << endl;
            if(nr[i]%v[j] == 0){
                while(nr[i]%v[j] == 0){
                    nr[i]/=v[j];
                    pwr++;
                }
            }
            int c=pwr+1;
            ndiv*=c;
            if(pwr > 0){
                b=v[j];
                pwr++;
                long long d=lgput(b , pwr);
                d--;
                d=d/(b-1);
                sdiv=sdiv*d%mod;
            }
        }
        if (nr[i] > 1) {
            b = nr[i];
            pwr = 1;
            ndiv *= 2;
            pwr++;
            long long d=lgput(b , pwr);
            d--;
            d=d/(b-1);
            sdiv=sdiv*d%mod;
        }
//        cout << "ttt" << endl;
        fout<<ndiv<<' '<<sdiv<<'\n';
    }
    return 0;
}