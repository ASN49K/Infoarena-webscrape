#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
///restmare
///darb

bool fr[1000055];
long long t, n;
vector<long long> v;

long long Putere(long long x, long long e)
{
    long long a = 1;
    while(e != 0)
    {
        if(e % 2 == 1) a = (a * x) % 9973;
        x = (x * x) % 9973;
        e /= 2;
    }
    return a;
}

void Descompunere(long long t)
{
    long long d, p, divizori, suma;
    divizori = suma = 1;
    for(long long i = 0;i < v.size() && v[i] * v[i] <= t;i++)
    {
        d = v[i];
        p = 0;
        while(t % d == 0)
        {
            p++;
            t /= d;
        }
        divizori = divizori * (p + 1);
        long long p1 = (Putere(d, p + 1) - 1) % 9973;
        long long p2 = Putere(d - 1, 9971) % 9973;
        suma = (((suma * p1) % 9973) * p2) % 9973;
    }
    if(t > 1)
    {
        divizori = divizori * 2;
        suma = (suma * (t + 1)) % 9973;
    }
    fout << divizori << " " << suma << "\n";
}

int main()
{
    long long i, j;
    fr[0] = fr[1] = true;
    for(i=2; i*i<=1000000; i++)
        if(fr[i] == false)
            for(j=i*i; j<=1000000; j+=i)
                fr[j] = true;
    for(i=2; i<=1000000; i++)
        if(fr[i] == false) v.push_back(i);
    fin >> t;
    for(i=1; i<=t; i++)
    {
        fin >> n;
        Descompunere(n);
    }
    fin.close();
    fout.close();
    return 0;
}
