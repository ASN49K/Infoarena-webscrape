#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MX = 1e6+5, mod = 9973;
int prime[MX], k;
bool s[MX];

ll pw(ll a, int b) {
    ll rez = 1;
    for (; b; b >>= 1) {
        if (b&1)
            rez = rez*a;
        a = a*a;
    }
    return rez;
}

void sieve() {
    for (int i = 2; i < MX; i++)
        if (!s[i]) {
            prime[k++] = i;
            for (int j = i+i; j < MX; j++)
                s[j] = 1;
        }
}

void ssnd(ll n) {
    int nrDiv = 1, sumDiv = 1;

    for (int i = 0; i < k && 1LL*prime[i]*prime[i] <= n; i++) {
        int p = prime[i];
        if (n % p) continue;
        int exp = 0;

        while (n % p == 0) {
            n /= p;
            exp++;
        }

        nrDiv *= (exp+1);
        sumDiv = sumDiv*((pw(p, exp+1)-1)/(p-1)%mod)%mod;
    }
    
    if (n > 1) {
        nrDiv *= 2;
        sumDiv = 1LL*sumDiv*(n+1)%mod;
    }
    
    fout << nrDiv << " " << sumDiv << "\n";
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    sieve();

    int t; fin >> t;
    while (t--) {
        ll n; fin >> n;
        ssnd(n);
    }

    return 0;
}

