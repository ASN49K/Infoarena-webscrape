#include <bits/stdc++.h>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

long long prim[100000],p,ciur[100000],n,t;
int main()
{
    prim[++p]=2;
    for(int i=3; i<=99997; i=i+2)
    {
        if(ciur[i]==0)
        {
            prim[++p]=i;
            for(int j=i*2; j<=99997; j=j+i)
                ciur[j]=1;
        }
    }
    f>>t;
    for(int i=1; i<=t; i++)
    {
        f>>n;
        int j=1,nrdv=1,s=1,m=n;
        while(prim[j]*prim[j]<=m)
        {
            int k=0;
            while(n%prim[j]==0)
            {
                n=n/prim[j];
                k++;
            }
            //g<<prim[j]<<" "<<tear<<" ";
            if(k>0)
            {
                k++;
                nrdv=nrdv*k;
                int tear=pow(prim[j],k);
                s=(s*((tear-1)/(prim[j]-1)))%9973;
            }
            j++;
        }
        if(n>1)
            nrdv=nrdv*2,s=(s*((n*n-1)/(n-1)))%9973;
        g<<nrdv<<" "<<s<<'\n';
    }
    return 0;
}
