#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int mod = 9973;

int t;
long long n, nr, sum;

void Read(){
    fin >> n;
    nr = sum = 1;
}

long long LgPow(long long x, int p){
    long long aux = x, ans = 1;
    while (p){
        if (p % 2)
            ans = ans * aux % mod;
        aux = aux * aux % mod;
        p /= 2;
    }
    return ans;
}

void Divisors(long long x){
    for (int i = 2; i <= x; i++){
        int p = 0;
        while (!(x % i)){
            p++;
            x /= i;
        }
        nr = nr * (p + 1) % mod;
        sum = sum * (LgPow(i, p + 1) - 1) * LgPow(i - 1, mod - 2) % mod;
    }
}

void Print(){
    fout << nr << ' ' << sum << '\n';
}

int main(){
    fin >> t;
    while (t--){
        Read();
        Divisors(n);
        Print();
    }
    return 0;
}
