#include <stdio.h>
#include <vector>

const int MAXP = 1e6;
using ll = long long;

int main() {
  FILE *fin = fopen( "ssnd.in", "r" );
  FILE *fout = fopen( "ssnd.out", "w" );

  std::vector<bool> ciur(MAXP + 1, false);
  for( int d = 2; d * d <= MAXP; d++ )
    if( !ciur[d] )
      for( int i = d * d; i <= MAXP; i += d )
        ciur[i] = true;

  std::vector<int> primes;
  for( int i = 2; i <= MAXP; i++ )
    if( !ciur[i] )
      primes.push_back( i );

  int q;
  for( fscanf( fin, "%d", &q ); q--; ){
    ll n;
    fscanf( fin, "%lld", &n );

    ll nrdiv = 1, sdiv = 1;
    for( int d : primes ){
      if( d * (ll)d > n ) break;
      if( n % d == 0 ){
        int exp = 0;
        ll spowd = 1, powd = 1;
        while( n % d == 0 ){
          n /= d;

          exp++;
          powd *= d;
          spowd += powd;
        }

        nrdiv *= (exp + 1);
        sdiv *= spowd;
        nrdiv %= 9973;
        sdiv %= 9973;
      }
    }

    if( n > 1 ){
      nrdiv *= 2;
      sdiv *= (1 + n);
      nrdiv %= 9973;
      sdiv %= 9973;
    }

    fprintf( fout, "%lld %lld\n", nrdiv % 9973, sdiv % 9973 );
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
