#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream in("ssnd.in");
ofstream out("ssnd.out");
unordered_map<int,int> d;
vector<int> v;
vector<bool> ciur(1000000);

void cuir(){
    v.push_back(2);

    for(int i=3;i<1000000;i+=2){
        if(!ciur[i]){
            v.push_back(i);
            for(unsigned ll j=i*i;j<1000000;j+=i*2){
                ciur[j]=1;
            }
        }
    }
}

void div(ll n){
    for(auto i:v){
        if(i>n)break;
        while(n%i==0){
            n/=i;
            d[i]++;
        }
    }
}

ll pwr(ll n,ll p){
    ll rez=1;
    while(p){
        if(p&1)rez*=n;
        n*=n;
        p=p>>1;
    }
    return rez;
}

int main(){
    cuir();

    int t;
    in>>t;
    for(int i=0;i<t;i++){
        ll nr;
        in>>nr;
        d.clear();
        div(nr);
        ll nr_div=1,suma=1;
        for(auto j:d){
            nr_div*=(j.second+1);
            suma*=(pwr(j.first,j.second+1)-1)/(j.first-1);
            suma%=9973;
        }
        out<<nr_div<<" "<<suma<<"\n";
    }
}
