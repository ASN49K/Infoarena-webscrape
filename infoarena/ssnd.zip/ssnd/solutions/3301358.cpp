#include <bits/stdc++.h>
#define MOD 9973
using namespace std;
ifstream in("ssnd.in");
ofstream out("ssnd.out");
bool ciur[100005];
long long primes[100005];
int main()
{
    int st=0;
    ciur[0]=ciur[1]=1;
    for(int i=2;i*i<=100005;i++){
        if(ciur[i]==0){
            for(int d=i*i;d<=100005;d+=i)
                ciur[d]=1;
        }
    }
    for(int i=2;i<=100005;i++){
        if(ciur[i]==0)
            primes[++st]=i;
    }
    int n,nr,div;
    unsigned long long sum;
    in>>n;
    for(int i=1;i<=n;i++){
        sum=1,div=1;
        in>>nr;
        for(int i=1;primes[i] * primes[i]<=nr;i++){
            if(nr%primes[i]==0){
                long long put=0,divelem=1;
                while(nr%primes[i]==0){
                    put++;
                    divelem*=primes[i];
                    nr/=primes[i];
                }
                div*=(put+1);
                sum=sum*(divelem*primes[i]-1) / (primes[i]-1) % MOD;
            }
        }
        if(nr>1){
            div*=2;
            sum=sum*(nr+1) % MOD;
        }
        out<<div<<" "<<sum<<'\n';
    }
    return 0;
}
