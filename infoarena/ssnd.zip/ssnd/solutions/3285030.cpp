#include <iostream>
#include <fstream>
using namespace std;
ifstream fcin("ssnd.in");
ofstream fcout("ssnd.out");
int n, i, x, d, nr, s;
int main()
{
    fcin>>n;
    for(i=1; i<=n; i++)
    {
        fcin>>x;
        nr=0;
        s=0;
        for(d=1; d*d<=x; d++)
            if(x%d==0)
            {
                nr=nr+2;
                s=s+d+x/d;
            }
        if(d*d==x)
        {
            nr++;
            s=s+d;
        }
        fcout<<nr<<" "<<s<<endl;
    }
    return 0;
}
