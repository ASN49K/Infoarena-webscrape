#include <iostream>
#include <fstream>
#include <vector>
#define MOD 9973
std::ifstream fin ("ssnd.in");
std::ofstream fout ("ssnd.out");
unsigned long long pr(long long a, long long b) {
    long long thing = 1;
    while (b>0){
        if (b&1) {thing=thing*a;}
        a=a*a;
        b >>=1;
    }
    return thing;
}

unsigned short expo(long long a, int p) {
    unsigned short c=0;
    while (a%p==0) {
        a/=p;c++;
    }
    return c;
}

bool SoE[1000001];
std::vector<unsigned int> primeList;

void genList(){
    primeList.push_back(2);
    for (int i=2;(i<<1)<=1000000;i++)
    {
        SoE[i<<1]=1;
    }
    for (int i=3;i<=1000000;i+=2)
    {
        if (!SoE[i]) {
            primeList.push_back(i);
            for (int j=(i<<1);j<=1000000;j+=i)
            {
                SoE[j]=1;
            }
        }
    }
}

int main(){
    genList();
    unsigned short t;
    fin >> t;
    for (int i=0;i<t;i++)
    {
        unsigned long long n;
        fin >> n;
        unsigned long long countDracula=1,sigma=1;
        for (int j=0;primeList[j]<=n;j++)
        {
            if (n%primeList[j]==0) {
                short e=expo(n, primeList[j]);
                countDracula*=(e+1);
                sigma*=(pr(primeList[j], e+1)-1)/(primeList[j]-1);
                sigma%=MOD;
                while (n%primeList[j]==0) {n/=primeList[j];}
            }
        }
        if (n>1000000) {
            countDracula*=2;
            sigma*=(n+1)%MOD;
        }
        fout << countDracula << " " << sigma << std::endl;
    }
    return 0;
}
