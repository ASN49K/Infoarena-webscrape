#include <fstream>
#include <cmath>
using namespace std;
ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");
long long n,i,k,d,w,j,nr,x,p,s,v[500001];
bool ciur[1000001];
int main()
{
    fin>>n;
    ciur[1]=1;
    for (i=2; i<=1000000; i++)
    {
        if (ciur[i]==0)
        {
            v[++k]=i;
            for (j=i+i; j<=1000000; j=j+i)
                ciur[j]=1;
        }
    }
    for (i=1; i<=n; i++)
    {
        fin>>x;
        s=1;
        p=1;
        for (d=1; d<=k&&v[d]*v[d]<=x; d++)
        {
            nr=0;
            while (x%v[d]==0)
            {
                nr++;
                x=x/v[d];
            }
            s=s*(nr+1);
            w=1;
            for (j=1; j<=nr+1; j++)
                w=w*v[d];
            p=p*((w-1)/(v[d]-1))%9973;
        }
        if (x!=1)
        {
            s=s*2;
            p=p*((x*x-1)/(x-1))%9973;
        }
        fout<<s<<" "<<p<<"\n";
    }
    return 0;
}
