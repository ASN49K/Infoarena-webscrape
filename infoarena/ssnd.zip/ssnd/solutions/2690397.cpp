#include <bits/stdc++.h>
 
using namespace std;
 
ifstream f("ssnd.in");
ofstream g("ssnd.out");

const int MOD = 9973;

bitset <1000001> prime;
vector <long long> v;
int t;
long long x;

void sieve(){

    v.reserve(78499);
    for(int i = 3;i * i <= 1000000;i += 2)
        if(!prime[i]){
            for(int j = i * i;j <= 1000000; j += 2 * i)
                prime[j] = 1;
        }

    v.emplace_back(2);
    for(int i = 3;i <= 1000000;i += 2)
        if(!prime[i]) v.emplace_back(i);
}

long long BinPow(long long a, int b){

    long long res = 1;
    while(b > 0){
        if(b & 1)
            res *= a;
        a *= a;
        b >>= 1;
    }
    return res;
}

void sum_nr_div(long long x){
    int i = 0, N = 78498;
    long long sd = 1, nrd = 1, sumdiv = 1;

    while(v[i] * v[i] <= x && i < N){

        int fm = 0;
        while(x % v[i] == 0){
            fm++;
            x /= v[i];
        }

        if(fm) {
            nrd *= (fm + 1);
            nrd %= MOD;
            long long p = BinPow(v[i], fm + 1);
            sumdiv *= (p - 1) / (v[i] - 1);
            sumdiv %= MOD;
        }
        i++;
    }

    if(x != 1) nrd *= 2, sumdiv *= (x * x - 1) / (x - 1);

    g << nrd % MOD << " " << sumdiv % MOD << "\n";
}

int main(){

    sieve();
    f >> t;
    while(t--){
        f >> x;
        sum_nr_div(x);
    }
}
  