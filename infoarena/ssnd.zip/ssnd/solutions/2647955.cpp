#include <fstream>

using namespace std;
const int k=1000005;
long long x,y,nr,s,z,p,u[100000];
int i,j,t,n;
bool v[k];
int main()
{
   ifstream f("ssnd.in");
   ofstream g("ssnd.out");
  for(i=2;i*i<k;i++)
  if(!v[i])
  for(j=i*i;j<k;j+=i)
  v[j]=1;
  for(i=2;i<k;i++)
  if(!v[i])
  u[++t]=i;

f>>n;
    for(i=1;i<=n;i=i+1)
    {
        f>>x;s=1;nr=1;
        for(j=1;u[j]*u[j]<=x;j++)
        {
            if(x%u[j]==0)
            {
                p=0;y=1;
                while(x%u[j]==0)
                {
                    p++;
                    x=x/u[j];
                }
                nr=nr*(p+1);
                p++;z=u[j];
                while(p)
                {
                    if(p%2==1)
                    {
                        p--;
                        y*=z;
                    }
                    z*=z;
                    p/=2;
                }
                y--;
                s*=y;
                s/=(u[j]-1);
                s%=9973;
            }
        }
        if(x!=1)
        {
            nr=nr*2;
            s*=(x+1);
            s%=9973;
        }
        g<<nr<<' '<<s<<'\n';
    }

    return 0;
}
