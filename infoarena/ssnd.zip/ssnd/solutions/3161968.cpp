/***
author: Morariu Tudor
*/


#include <algorithm>
#include <bitset>
#include <cstdio> 
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits.h>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector> 
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")


using namespace std;
 
#define fast_cin() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define endl '\n'
 
void debug(vector<int> v)
{
    for(int i = 0;i < (int)v.size();i++) {cout << v[i] << ' ';}
    cout << endl;
}
void debug(vector<long long int> v)
{
    for(int i = 0;i < (int)v.size();i++) {cout << v[i] << ' ';}
    cout << endl;
}
void debug(vector<string> v)
{
    for(int i = 0;i < (int)v.size();i++) {cout << v[i] << ' ';}
    cout << endl;
}

int firstDigit(int n)
{
    while (n >= 10) n /= 10;
    return n;
}

string decToBase(int decimal, int sz, int b)
{
    string ans;
    while(decimal)
    {
        ans.push_back(decimal % b + '0');
        decimal /= b;
    }
    reverse(ans.begin(), ans.end());
    while((int)ans.size() < sz) ans.insert(ans.begin(), '0');

    return ans;
}

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bool c[1000001];
vector<int> prms;

void sive()
{
    c[0] = 1;
    c[1] = 1;

    for(int i = 2;i < 1001;i++)
    {
        if(c[i] == 0)
        {
            for(int j = 2;j <= 1000001 / i;j++)
            {
                c[i * j] = 1;
            }
        }
    }

    for(int i = 0;i <= 1000000;i++)
    {
        if(c[i] == 0) prms.push_back(i);
    }
}

int main()
{
    sive();
    int t; fin >> t;
    //prms.insert(prms.begin(), 1);
    while(t--)
    {
        long long int n; fin >> n;
        long long int nn = n;

        long long int smd, nrd;
        smd = 0;
        nrd = 0;

        /*

        for(int i = 0;prms[i] <= sqrt(nn) and i < prms.size();i++)
        {
            long long pr = prms[i];
            long long e = 0;
            //cout << pr << ": ";
            long long inv = n / pr;
            //if(n % pr != 0) inv = -1;

            while(n % pr == 0)
            {
              //  cout << "--> " << pr << endl;
                n /= pr;
                e++;
            }

            
            smd *= ((long long)pow(pr, e + 1) - 1) / (pr - 1);
            nrd *= (e + 1);
        }

        if(n > 1) 
        {
            //cout << "n > 1: " << n << endl; 
            smd *= (n * n - 1) / (n - 1);
            nrd *= 2;
        }
        */

        for(long long int i = 1;i <= sqrt(n);i++)
        {
            if(n % i == 0)
            {
                nrd++;
                smd += i;
                smd %= 9973;
                long long int els = n / i;

                cout << "Add: " << i << endl;

                if(els != i and n % els == 0)
                {
                    nrd++;
                    smd += els;
                    smd %= 9973;

                    cout << "Add: " << els << endl;
                    //n /= els;
                }

                //n /= i;

            }
        }

        fout << nrd  << " " << smd  << endl; //1
    }
	return 0;
}


