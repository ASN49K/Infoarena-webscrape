/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
#define Max 1000000
#define mod 9973
#include <bitset>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bitset <Max+1> ciur;
long long int n,t;
long long int expo(long long int a,long long int b)
{
    long long rez=1;
    while(b)
    {
        if(b%2==1)
            rez=a*rez%mod;
        a=a*a%mod;
        b/=2;
    }
    return rez;
}
void ciure()
{
    ciur[0]=1;
    ciur[1]=1;
    for(int j=4;j<=Max;j+=2)
        ciur[j]=1;
    for(int i=3;i<=Max;i+=2)
    {
        for(int j=i+i;j<=Max;j+=i)
            ciur[j]=1;
    }
}
int main()
{

    fin>>t;
    ciure();
    for(int i=1;i<=t;i++)
    {
        fin>>n;
        long long int nr=1;
        long long int sum=1;
    int d=2;
    while(n>1)
    {
        int p=0;
        while(n%d==0)
        {
            n/=d;
            p++;
        }
        if(p)
        {
            nr=nr*(p+1);
            sum=(sum*((expo(d,p+1)-1+mod)%mod))%mod*(expo(d-1,mod-2))%mod;
        }
        if(n>1 && d*d>n)
            d=n;
        else
        do{
            d++;
        }while(ciur[d]==1);
    }
    fout<<nr<<" "<<sum<<"\n";
    }
    return 0;
}
