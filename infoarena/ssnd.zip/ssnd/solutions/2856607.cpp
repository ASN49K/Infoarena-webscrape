#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int n,x,ciur[1000100],div[100000],k;

int putere(int nr,int put)
{
     long long p=1;
    while(put)
    {
        p*=nr;
        put--;
    }
    return p;
}

void prim()
{
    ciur[0]=ciur[1]=1;
    k=1;
    div[1]=2;
    for(int i=3;i<=1000000;i+=2)
        if(ciur[i]==0)
        {
            div[++k]=i;
            for(int j=2*i;j<=1000000;j=j+i)
                ciur[j]=1;
        }
}

void divizori(int nr)
{
    int p=1;
    long long suma=1;
    for(int d=1;div[d]*div[d]<=nr;d++)
    {
        if(nr%div[d]==0)
        {
            int e=1;
            while(nr%div[d]==0)
            {
                e++;
                nr/=div[d];
            }
            p*=e;
            suma=1LL*suma%9973*(putere(div[d],e)-1)/(div[d]-1)%9973;
        }
    }
    if(nr!=1)
    {
        p*=2;
        suma=suma%9973*(((nr*nr)-1)/(nr-1))%9973;
    }
    fout<<p<<" "<<suma<<"\n";
}



int main()
{
    prim();
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>x;
        divizori(x);
    }
}
