//ALEXANDRU MICLEA
 
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <assert.h>
 
using namespace std;
using ll = long long;
 
#include <fstream>
//ifstream cin("input.in"); ofstream cout("output.out");
ifstream cin("ssnd.in"); ofstream cout("ssnd.out");
 
//VARIABLES
 
const ll maxn = 1e6 + 15;
const ll MOD = 9973;
bool ciur[maxn+100];
vector <ll> prime;
 
//FUNCTIONS
 
ll lgput (ll n, ll p){
    ll ans = 1;
 
    while (p){
        if (p % 2){
            ans *= n;
        }
        n *= n;
        p /= 2;
    }
    return ans;
}
 
//MAIN
 
int main() {
    ios::sync_with_stdio(false);
    
    ciur[1] = 1;
    for (ll i = 2; i <= maxn; i++){
        if (ciur[i] == 0){
            prime.push_back(i);
            for (ll j = i + i; j <= maxn; j += i){
                ciur[j] = 1;
            }
        }
    }
 
 
    ll t; cin >> t;
    while (t--){
        ll n; cin >> n;
        ll nr = 1, sum = 1;
        
        for (auto& x : prime){
            if (x * x > n) break;

            if (n % x == 0){
                int cont = 0;
                while (n % x == 0){
                    cont++;
                    n /= x;
                }
                sum *= (lgput(x,cont + 1) - 1) / (x - 1);
                sum %= MOD;
                nr *= (cont + 1);
            }
        }
 
        if (n != 1){
            sum *= (lgput(n,2) - 1) / (n - 1);
            sum %= MOD;
            nr *= 2;
        }
 
 
        cout << nr << ' ' << sum << '\n';
    }
    
    return 0;
}