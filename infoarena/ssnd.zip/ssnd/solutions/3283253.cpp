#include <fstream>
#include <bitset>
#define int unsigned long long
using namespace std;
ifstream fcin("ssnd.in");
ofstream fout("ssnd.out");
int n,a,b,nr,x;
bitset <3001000> c;
const int mod=9973;
inline int log_pow(int baza, int exp)
{
    int rez=1;
    for(int i=0; i<=30; i++)
    {
        if(((1<<i) & exp))
            rez=(1LL*rez*baza)%mod;
        baza=(1LL*baza*baza)%mod;
    }
    return rez;
}
signed main()
{
    fcin>>n;
    while(n--)
    {
        fcin>>x;
        int nr=1, s=1;
        for(int d=2; d*d<=x; d++)
        {
            int e=0;
            while(x%d==0) e++, x=x/d;
            if(e) nr=nr*(e+1), s=s*(log_pow(d,e+1)-1)%mod*log_pow(d-1, mod-2)%mod;
        }
        if(x>1) nr=nr*2, s=s*(log_pow(x,2)-1)%mod*log_pow(x-1, mod-2)%mod;
        fout<<nr<<" "<<s<<'\n';
    }
    return 0;
}
