#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

void sumanumar(int n){
    int s=0,db=0;
    for(int i=1;i<=n;i++){
        if(n%i==0){
            db++;
            s+=i;
        }
    }
    fout<<db<<" "<<s<<endl;
}
int main()
{
    int t,n;
    fin>>t;
    for(int i=1;i<=t;i++){
        fin>>n;
        sumanumar(n);
    }
    return 0;
}