#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long i,j,k,p[99999],t,o=9973,u,l,n,m,w,z;
bool r[1000001];
int main()
{
    for(p[k++]=2,i=3;i*i<=1e6;++i)
        if(!r[i])
            for(p[k++]=i,r[i]=1,j=i*i;j<=1e6;r[j]=1,j+=2*i);
    for(F>>t;t--;G<<u<<' '<<z%o<<'\n') {
        for(F>>n,m=n,u=z=1,i=0;i<k&&m&&p[i]*p[i]<=m;++i)
            if(m%p[i]==0) {
                for(l=1,w=p[i];m%p[i]==0;m/=p[i],w*=p[i],++l);
                u*=l,z*=((w-1)/(p[i]-1))%o;
            }
        if(m>1)
            u*=2,z*=(m+1)%o;
    }
    return 0;
}
