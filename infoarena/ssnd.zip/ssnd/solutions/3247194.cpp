#include <fstream>
#include <vector>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

const long long mod = 9973;
long long n, x, nrd, sumd;
vector<long long> prim;
bool ciur[1000005];

long long expo(long long a, long long b)
{
    long long sol = 1;
    while(b)
        if(b % 2 == 0)
            b /= 2, a = (1LL * a * a) % mod;
        else
            b --, sol = (1LL * a * sol) % mod;

    return sol;
}

long long InvMod(long long x){
    return expo(x, mod - 2);
}

void solv(long long x)
{
    nrd = sumd = 1;
    long long d = prim[0], ind = 0;
    while(x > 1)
    {
        long long p = 0, k = d;
        while(x % d == 0)
            x /= d, p ++, k *= d;

        nrd = (1LL * nrd * (p + 1)) % mod;
        sumd = (1LL * sumd * (1LL * ((k - 1) % mod) * InvMod(d - 1)) % mod) % mod;

        d = prim[++ ind];
        if(1LL * d * d > x)
            d = x;
    }

    g << nrd << " " << sumd << '\n';
}

int main()
{
    for(int i = 2; i * i <= 1000000; i ++)
        if(!ciur[i]){
            prim.push_back(i);
            for(int j = 2 * i; j <= 1000000; j += i)
                ciur[j] = true;
        }

    f >> n;
    for(long long i = 1; i <= n; i ++)
    {
        f >> x;
        solv(x);
    }
    return 0;
}
