#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const int MAX = 1e6 + 15;

bool ciur[MAX + 100];
vector<int> elemciur;
vector<pair<long long, int>> fact;

void CIUR() {
    ciur[1] = 1;
    for (int i = 2; i <= MAX; i++) {
        if (ciur[i] == 0) {
            elemciur.push_back(i);
            for (int j = i * 2; j <= MAX; j += i) {
                ciur[j] = 1;
            }
        }
    }
}

int main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    CIUR();
    int t;
    cin >> t;
    while (t--) {
        fact.clear();
        long long n;
        cin >> n;
        for (auto x : elemciur) {
            if (x * x > n) {
                break;
            }
            if (n % x == 0) {
                fact.push_back(make_pair(x, 0));
            }
            while (n % x == 0) {
                fact.back().second++;
                n /= x;
            }
        }
        if (n != 1) {
            fact.push_back(make_pair(n, 1));
        }
        long long nrdiv = 1;
        long long sumadiv = 1;
        for (auto x : fact) {
            nrdiv *= x.second + 1;
            sumadiv *= (pow(x.first, x.second + 1) - 1) / (x.first - 1);
        }
        cout << nrdiv << " " << sumadiv << '\n';
    }
    return 0;
}