#include <iostream>
#include <fstream>
#include <bitset>
#include <cmath>
#define LIM 1000000

using namespace std;

ifstream fin  ("ssnd.in");
ofstream fout ("ssnd.out");

bitset<1000005> f;
int prime, p[80005];
int t, e, cnt;
long long x, y, suma;

int main (){
    f[0] = f[1] = 1;
    for(int i=4; i<=LIM; i+=2)
        f[i]=1;
    for(int i=3; i<=LIM/i; i+=2)
        if(f[i] == 0)
            for(int j=i*i; j<=LIM; j+=i)
                f[j]=1;

    p[++prime]=2;
    for(int i=3; i<=LIM; i+=2)
        if(f[i] == 0)
            p[++prime]=i;

    fin>>t;
    while(t--){
        fin>>x;

        cnt = 1;
        suma = 1;
        for(int i=1; i<=prime && p[i] <= x/p[i]; i++){
            e=0;
            while(x%p[i] == 0){
                e++;
                x/=p[i];
            }
            cnt = cnt * (e+1);

            y=pow(p[i], e);
            suma = 1LL * suma * (1LL * (1LL * y * p[i] - 1) / (p[i] - 1)) % 9973;
        }

        if(x != 1){
            cnt*=2;
            suma = 1LL * suma * ((1LL * x * x - 1) / (x - 1)) % 9973;
        }

        fout<<cnt<<" "<<suma<<"\n";
    }

    return 0;
}
