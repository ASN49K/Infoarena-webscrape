#include <iostream>
#include <cmath>
#define int long long
using namespace std;

//ifstream cin ("ssnd.in");
//ofstream cout ("ssnd.out");

bool ciur[1000000];
int v[100000];

void f_ciur() {
    for (int i=2; i*i<=1000000; i++) {
        if (ciur[i]) {
            for (int j=i*i; j<=1000000; j=j+i) {
                ciur[j]=0;
            }
        }
    }
}

int f (int a, int b) {
    int c=1;
    while (b>1) {
        if (b%2==0) {
            b=b/2;
            a=a*a;
        } else {
            c=c*a;
            b=(b-1)/2;
            a=a*a;
        }
    }
    return a*c;
}

int32_t main() {
    int n,t,poz=1;
    ciur[0]=ciur[1]=0;
    for (int i=2; i<=1000000; i++) {
        ciur[i]=1;
    }
    f_ciur();
    for (int i=1; i<=1000000; i++) {
        if (ciur[i]) {
            v[poz]=i;
            poz++;
        }
    }
    cin>>t;
    for (int i=1; i<=t; i++) {
        cin>>n;
        int sum=1,nr=1,cnt=0,j=1;
        while (n>1) {
            while (n%v[j]==0) {
                n=n/v[j];
                cnt++;
            }
            if (cnt!=0) {
                sum=sum*(f(v[j],cnt+1)-1)/(v[j]-1)%9973;
                nr=nr*(cnt+1);
                cnt=0;
            }
            if (n<=1000000) {
                if (ciur[n]) {
                    sum=sum*(f(n,2)-1)/(n-1)%9973;
                    nr=nr*2;
                    n=1;
                }
            }
            j++;
        }
        if (nr==1) cout<<2<<" "<<(n+1)%9973<<'\n';
        else cout<<nr<<" "<<sum<<'\n';
    }
}