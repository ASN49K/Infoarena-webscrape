#include <bits/stdc++.h>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const long long Mod=9973;
#define l long long
vector<int> v;
int w[1000100];
//int d[1000100];
int n,m,s;
int num=0;
long long M;
void Euclid(l a,l b, l &x, l &y){
    if(b==0){
        x=1;
        y=1;
    }
    else{
        l x1,y1;
        Euclid(b,a%b,x1,y1);
        x=y1;
        y=x1-(a/b)*y1;
    }
}
l calc(l a,l b){
    l x,y;
    Euclid(b,Mod,x,y);
    while(x<0)
        x+=Mod;
    return 1ll*(a*x)%Mod;
}
void Calc(l x){
    int a=1,d=0;
    l b=1;
    while(v[d]<=x){
        int p=v[d],k=1;
        if(x%v[d]==0){
        while(x%v[d]==0){
            p*=v[d];
            k++;
            x=1ll*x/v[d];
        }
        a*=(k);
        b=1ll*b*(p-1);
        b=calc(b,(v[d]-1));
        }
        d++;
    }
    if(x>1){
        a*=2;
        b=1ll*b*(x*x-1);
        b=calc(b,(x-1));
    }
    fout<<a<<' '<<b<<'\n';
}
void Eratos(){
    for(int i=2; i<=1000; i++){
        for(int j=2; i*j<=1000000; j++){
            w[i*j]=1;
        }
    }
    for(int i=2; i<=1000000; i++){
        if(!w[i])
            v.push_back(i);
    }
}

int main(){
    l a,b;
    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    Eratos();
    fin>>n;
    for(int i=1; i<=n; i++){
        fin>>a;
        Calc(a);
    }

    return 0;
}
