#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MX = 1e6+5, mod = 9973;
vector<ll> prime;
bool s[MX];

ll pw(ll a, int b) {
    return b?(pw(a*a, b>>1)*(b&1?a:1)):1;
}

void sieve() {
    for (int i = 2; i <= MX; i++)
        if (!s[i]) {
            prime.push_back(i);
            for (ll j = i+i; j <= MX; j += i)
                s[j] = 1;
        }
}

void ssnd(ll n) {
    int nrDiv = 1; 
    ll sumDiv = 1;
    
    for (int i = 0; prime[i]*prime[i] <= n; i++) {
        
        ll p = prime[i];
        int exp = 0;
        
        while (n%p == 0) {
            n /= p; 
            exp++;
        }
        
        nrDiv *= (exp+1);
        sumDiv *= (pw(p, exp+1)-1)/(p-1);
        sumDiv %= mod;
    }

    if (n > 1) {
        nrDiv *= 2;
        sumDiv *= (n+1);
        sumDiv %= mod;
    }

    fout << nrDiv << " " << sumDiv << "\n";
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    sieve();

    int t; fin >> t;
    while (t--) {
        ll n; fin >> n;
        ssnd(n);
    }

    return 0;
}

