#include <bits/stdc++.h>
#define NMAX 1000005
#define MOD 9973

using namespace std;

vector <int> primes;
int lp[NMAX];

int logpow(long long n, int p) {
	int ans = 1;
	n %= MOD;
	while (p) {
		if (p & 1)
			ans = (1LL * ans * 1LL * n) % MOD, --p;
		else
			n = (1LL * n * 1LL * n) % MOD, p >>= 1;
	}

	return ans;
}

inline int invmod(long long n) {
	return logpow(n, MOD - 2);
}

void make_sieve(int n) {
	for (int i = 2; i <= n; ++i) {

		if (lp[i] == 0)
			primes.push_back(i), lp[i] = i;

		for (int j = 0; j < (int)primes.size() && i * primes[j] <= n; ++j) {
			lp[i * primes[j]] = primes[j];

			if (i % primes[j] == 0)
				break;
		}
	}
}

void solve() {
	long long n;
	cin >> n;

	vector <pair<long long, int>> decomp;
	for (int i = 0; i < (int)primes.size() && primes[i] * 1LL *  primes[i] <= n; ++i) {
		if (n % primes[i] == 0) {
			int cnt = 0;
			while (n % primes[i] == 0)
				n /= primes[i], ++cnt;
			decomp.push_back({primes[i], cnt});
		}
	}

	if (n != 1)
		decomp.push_back({n, 1});

	long long cntdiv = 1, sumdiv = 1;
	for (auto p : decomp) {
		cntdiv *= (1LL * p.second + 1);
		sumdiv = (1LL * sumdiv * 1LL * (logpow(p.first, p.second + 1) - 1)) % MOD;
		sumdiv = (1LL * sumdiv * 1LL * invmod(p.first - 1)) % MOD;
	}

	cout << cntdiv << ' ' << sumdiv << '\n';
}
 
int main() {
 
	make_sieve(1000002);

	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);

	int t = 1;
	cin >> t;
 
 	while (t--)
 		solve();

	return 0;
}
