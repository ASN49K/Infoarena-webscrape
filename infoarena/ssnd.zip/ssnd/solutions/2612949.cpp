#include <cstdio>
#include <cmath>
using namespace std;

const int MOD = 9973;

int main() {
	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);

	int t;
	int n;

	scanf("%d", &t);

	while (t --) {
		scanf("%d", &n);

		int suma = 0;
		int numarDiv = 0;

		
		int SQRT = sqrt(n);

		for (int i = 1;i <= SQRT;i ++) {
			if (n % i == 0) {
				suma = (suma + i) % MOD;
				suma = (suma + n / i) % MOD;
				numarDiv += 2;
			}
		}

		if (SQRT == sqrt(n)) {
			suma = (suma - SQRT) % MOD;
			numarDiv --;
		}


		printf("%d %d\n", numarDiv, suma);
	}

	return 0;
}