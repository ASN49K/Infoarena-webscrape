// Mihai Priboi

#include <bits/stdc++.h>

#define MAXD 1000000
#define MOD 9973

int ciur[MAXD + 1];

int main() {
  FILE *fin, *fout;
  int n, t, i, d, k, div, sum_div, sum, p, x, diviz;

  for( d = 2; d * d <= MAXD; d++ )
    if( ciur[d] == 0 )
      for( i = d * d; i <= MAXD; i += d )
        ciur[i] = 1;

  k = 0;
  for( i = 2; i <= MAXD; i++ )
    if( ciur[i] == 0 )
      ciur[k++] = i;

  fin = fopen( "ssnd.in", "r" );
  fout = fopen( "ssnd.out", "w" );

  fscanf( fin, "%d", &t );
  for( k = 0; k < t; k++ ) {
    fscanf( fin, "%d", &n );

    d = 0;
    diviz = ciur[d];
    sum_div = 1;
    div = 1;
    while( diviz * diviz <= n ) {
      p = 0;
      x = diviz;
      sum = 1;
      while( n % diviz == 0 ) {
        p++;
        sum += x;
        x *= diviz;
        n /= diviz;
      }
      sum_div *= sum;
      sum_div %= MOD;
      div *= p + 1;
      d++;
      diviz = ciur[d];
    }
    if( n > 1 ) {
      sum_div *= n + 1;
      sum_div %= MOD;
      div *= 2;
    }

    fprintf( fout, "%d %d\n", div, sum_div );
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
