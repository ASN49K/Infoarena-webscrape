#include <fstream>
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int d=2;
        int nr=1;
        int sum=1;
        while(n>1){
            int e=0;
            int pw=d;
            while(n%d==0){
                n/=d;
                e++;
                pw*=d;
            }
            nr*=(e+1);
            sum*=(pw-1)/(d-1);
            if(d==2) d++;
            else d+=2;
            if(d*d>n&&n>1){
                nr*=2;
                sum*=(n*n-1)/(n-1);
                n=1;
            }
        }
        cout<<nr<<" "<<sum<<'\n';
    }
    return 0;
}
