#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

const int MOD = 9973;
const int VMAX = 1e6;

vector <int> p;

void ciurul()
{
    bitset <1+VMAX> c;
    for (int i = 2; i * i <= VMAX; i++)
    {
        if (!c[i])
        {
            for (int multiplu = i * i; multiplu <= VMAX; multiplu += i)
            {
                c[multiplu] = 1;
            }
        }
    }
    for (int i = 2; i <= VMAX; i++)
    {
        if (!c[i])
        {
            p.push_back(i);
        }
    }
}

void suma_nr(long long n, long long &nr, long long &s)
{
    nr = s = 1;
    unsigned int i = 0;
    while (i < p.size() && p[i] * p[i] <= n)
    {
        if (n % p[i] == 0)
        {
            int e = 1;
            long long sum = 1, pc = 1;
            while (n % p[i] == 0)
            {
                e++;
                pc *= p[i];
                sum += pc;
                n /= p[i];
            }
            nr *= e;
            s *= sum;
            s %= MOD;
        }
        i++;
    }
    if (n != 1)
    {
        nr *= 2;
        s *= (n + 1);
        s %= MOD;
    }
    nr %= MOD;
}

int main()
{
    ifstream in("ssnd.in");
    ofstream out("ssnd.out");
    ciurul();
    int t;
    in >> t;
    for (int i = 0; i < t; i++)
    {
        long long n, s, nr;
        in >> n;
        suma_nr(n, nr, s);
        out << nr << " " << s << "\n";
    }
    in.close();
    out.close();
    return 0;
}
