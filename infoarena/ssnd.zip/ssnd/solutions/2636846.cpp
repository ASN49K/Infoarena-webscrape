#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int t;
long long n, nr_div, sum;
const int MOD = 9973;

long long putere(long long a, long long b) {
    long long rez = a;
    while (--b)
        rez *= a;
    return rez;
}

void descompune(){
    int div = 2;
    nr_div = 1, sum = 1;
    while (n > 1) {
        int p = 0;
        while (n % div == 0) {
            n /= div;
            ++p;
        }
        if (p > 0) {
            nr_div = nr_div * (p + 1) % MOD;
            sum *= (putere(div, p + 1) - 1) / (div - 1) % MOD;
        }
        if (div == 2)
            --div;
        div += 2;
    }
    fout << nr_div << " " << sum << "\n";
    return;
}

int main() {
    fin >> t;
    while (t--) {
        fin >> n;
        descompune();
    }
    return 0;
}
