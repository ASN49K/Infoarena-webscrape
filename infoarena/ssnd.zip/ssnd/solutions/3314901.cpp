#include <cstdio>
#include <utility>
#include <iostream>
#include <cmath>
#include<vector>
using namespace std;

const int MOD = 9973;
const int NMAX = 1000000;
const bool PRIM = 0;
const bool COMPUS = 1;

bool Sieve[NMAX + 10];
vector<int> primes;

long long RidicareLaPutere(int baza, int exponent) {
    long long rez = 1;

    while (exponent != 0) {
        if (exponent % 2 != 0) {
            rez = rez * (baza % MOD);
        }
        baza = baza * (baza % MOD);
        exponent /= 2;

    }
    return rez;

}

void ComputeSieve() {
    for (int i = 2; i * i <= NMAX; i++) {
        if (Sieve[i] == PRIM) {
            primes.push_back(i);
            for (int j = i * i; j <= NMAX; j += i) {
                Sieve[j] = COMPUS;
            }
        }
    }
    Sieve[1] = COMPUS;

    for (int i = 1; i <= NMAX; i++) {
        if (Sieve[i] == PRIM) {
            primes.push_back(i);
        }
    }


}

pair<int,long long> nrsumdiv(unsigned long long n) {
    int nrdiv;
    long long sumdiv;
    nrdiv = sumdiv = 1;

    int i = 0, putere;

    while (n != 1) {
        int d = primes[i];
        putere = 0;
        while (n % d == 0) {
            putere++;
                n /= d;
        }
        sumdiv = sumdiv * (((RidicareLaPutere(d, (putere + 1)) - 1) / (long long)(d - 1))) % MOD;
        nrdiv *= (putere + 1);

        i++;

    }
    return {nrdiv, sumdiv};
}

int main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);


    int t;
    unsigned long long n;

    scanf("%d", &t);

    ComputeSieve();

    //printf("%d\n", RidicareLaPutere(100,15));
    for (; t > 0; --t) {
        scanf("%lld", &n);
        pair<int,long long> res = nrsumdiv(n);
        printf("%d %lld\n", res.first, res.second);
    }
    return 0;
}