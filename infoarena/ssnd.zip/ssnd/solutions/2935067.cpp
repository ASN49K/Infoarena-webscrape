#include <bits/stdc++.h>
using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

int mod=9973;

int main()
{
    int n;
    fin>>n;
    int a;
    for (int t=1; t<=n; t++)
    {
        fin>>a;
        int s=0;
        int k=0;
        for (int i=1; i<=a; i++)
        {
            if (a%i==0)
            {
                s=(s+i)%mod;
                k++;
            }
        }
        fout<<k<<" "<<s<<'\n';
    }

    return 0;
}
