#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int prim_max = 1000000;
const int MOD = 9973;

vector<bool> eprim(prim_max + 1, true);
vector<int> prime;

void ciur() {
    eprim[0] = eprim[1] = false;
    for (int i = 2; i * i <= prim_max; ++i) {
        if (eprim[i]) {
            for (int j = i * i; j <= prim_max; j += i) {
                eprim[j] = false;
            }
        }
    }
    for (int i = 2; i <= prim_max; ++i) {
        if (eprim[i]) {
            prime.push_back(i);
        }
    }
}

void solve() {
    long long n;
    fin >> n;

    long long num_divisors = 1;
    long long sum_divisors = 1;

    long long temp = n;

    for (int p : prime) {
        if (1LL * p * p > temp) {
            break;
        }

        if (temp % p == 0) {
            int exponent = 0;
            long long current_p_pow = 1;
            long long current_sum = 1;

            while (temp % p == 0) {
                exponent++;
                current_p_pow = (current_p_pow * p) % MOD;
                current_sum = (current_sum + current_p_pow) % MOD;
                temp /= p;
            }

            num_divisors *= (exponent + 1);
            sum_divisors = (sum_divisors * current_sum) % MOD;
        }
    }

    if (temp > 1) {
        num_divisors *= 2;
        sum_divisors = (sum_divisors * ((1 + temp) % MOD)) % MOD;
    }

    fout << num_divisors << " " << sum_divisors << "\n";
}

int main() {

    ciur();

    int t;
    if (fin >> t) {
        while (t--) {
            solve();
        }
    }

    return 0;
}
