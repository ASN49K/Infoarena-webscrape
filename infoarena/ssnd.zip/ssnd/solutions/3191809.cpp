#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int main()
{
    long long int i, n;
    fin >> n;
    for (i = 0; i < n; i++)
    {
        long long int m, j, num = 1, sum = 1;
        fin >> m;
        for (j = 2; j * j <= m; j++)
        {
            long long int pwr = j, e = 1;
            while (m % j == 0)
            {
                pwr *= j;
                e++;
                m /= j;
            }
            sum *= (pwr - 1) / (j - 1);
            num *= e;
        }
        if (m > 1)
            sum *= (m * m - 1) / (m - 1);
        if (m > 1)
            num *= 2;
        //cout << num << " " << sum << '\n';
        fout << num << " " << sum << '\n';

    }
}