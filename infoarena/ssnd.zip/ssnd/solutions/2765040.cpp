#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <cstring>
#include <chrono>
#include <cassert>
#include <bitset>
#include <stack>
#include <queue>

#pragma GCC optimize("Ofast")
#pragma GCC optimize("Ofast,unroll-loops")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define x first
#define y second
#define ld long double
#define ll long long
#define ull unsigned long long
#define us unsigned short
#define lsb(x) ((x) & (-(x)))
#define pii pair <int, int>

using namespace std;

ifstream in ("ssnd.in");
ofstream out ("ssnd.out");

const int MOD = 9973;
const int N = (int)1e6;

int T;

ll n;

bitset <N + 5> ciur;
vector <int> primes;

void precalc() {
  for(int i = 2; i * i <= N; i++) {
    if(!ciur[i]) {
      for(int j = i * i; j <= N; j += i)
        ciur[j] = 1;
    }
  }

  for(int i = 2; i <= N; i++) {
    if(!ciur[i])
      primes.push_back(i);
  }
}

void solve() {
  in >> n;

  int ndiv = 1, sdiv = 1;

  for(int i = 0; i < (int)primes.size() && 1LL * primes[i] * primes[i] <= n; i++) {
    int e = 0;
    ll put = 1;

    while(n % primes[i] == 0) {
      n /= primes[i];
      e++;
      put *= primes[i];
    }

    ndiv *= e + 1;
    sdiv = 1LL * sdiv * ((put * primes[i] - 1) / (primes[i] - 1)) % MOD;
  }

  if(n > 1) {
    ndiv *= 2;
    sdiv = 1LL * sdiv * (n + 1) % MOD; /// (n ^ 2 - 1) / (n - 1)
  }

  out << ndiv << " " << sdiv << "\n";
}

int main() {
  /*ios_base :: sync_with_stdio(false);
  cin.tie(0); cout.tie(0);*/
  in >> T;

  precalc();

  //cout << primes.size() << "\n";

  for(; T; T--) {
    solve();
  }
  return 0;
}
