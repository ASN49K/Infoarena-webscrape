#include <bits/stdc++.h>

using namespace std;

#define i64 int64_t

constexpr int MOD = 9973;

int main() {
#ifndef LOCAL
  freopen("ssnd.in", "r", stdin);
  freopen("ssnd.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int T;
  cin >> T;
  for (; T--;) {
    i64 N;
    cin >> N;
    int c{0};
    int s{0};
    int i{0};
    for (++i; (i64)i * i < N; ++i) {
      if (N % i == 0) {
        c += 2;
        s = (s + i + N / i) % MOD;
      }
    }
    if ((i64)i * i == N) {
      c += 1;
      s = (s + i) % MOD;
    }
    cout << c << " " << s << "\n";
  }
  return 0;
}
