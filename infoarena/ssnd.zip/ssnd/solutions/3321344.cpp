#include <bits/stdc++.h>

#define MOD 9973
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

long long power(long long a, int b)
{
    if(b==0)return 1;

    long long x=power(a, b/2)%MOD;

    if(b%2==0)return (x*x)%MOD;
    return ((x*x)%MOD*a)%MOD;
}

int v[1000005];
long long t,n,ans,ans2,nr,imp,it,i,j,x;
bool ciur[1000005];
signed main()
{
    ciur[0]=1;
    ciur[1]=1;
    for( i=1; i<=1000000; i++)
        if(ciur[i]==0)
        {
            v[it++]=i;
            for( j=i+i; j<=1000000; j+=i)
                ciur[j]=1;
        }

    fin>>t;
    for(int h=1; h<=t; h++)
    {
        fin>>n;
        x=0;
        imp=v[x];
        ans=1;
        ans2=1;
        while(n>1)
        {
            nr=0;
            while(n%imp==0)
            {
                n/=imp;
                nr++;
            }
            ans=ans*(nr+1);
            //ans2=ans2*((((power(imp, nr+1)-1)+MOD)%MOD*power(imp-1, MOD-2))%MOD)%MOD;

            imp=v[++x];
            if(imp*imp>n || imp==0 || it==x)imp=n;
        }
        fout<<ans<<' '<<ans2<<'\n';
    }
    return 0;
}
