#include <iostream>
#include <fstream>
#include <utility>
#include <cmath>

using namespace std ;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

unsigned long long int n, t, s;

unsigned long long int cnt, sum;

bool v[1000010];

int p[80010];

void Ciur(int nr)
{
    for(unsigned long long int i = 3; i*i <= nr; i+=2)
        if(v[i] == true)continue;
        else
            {
                for(unsigned long long int j = i*i ; j<= nr; j+=i)
                   v[j]=1;
            }
    p[1] = 2;
    cnt = 2;
    for(int  i = 3; i*i <= nr ; i+=2)if(!v[i])p[cnt] = i,cnt++;


}

void Solve(int nr)
{
    cnt = 1 ; sum =  1;
    for(int i = 1; p[i] != 0; i++)
    {
        unsigned long long int currCnt = 1;unsigned long long int currSum = 1; unsigned long long int powerCurrPrime = 1;
        unsigned long long int value = nr;
        if( p[i] * p[i] > nr)break;
        else
            {
                while(nr % p[i] == 0)
                {
                    nr /= p[i];
                    value /= p[i];
                    currCnt++;
                    powerCurrPrime = (powerCurrPrime * p[i])%9973;
                    currSum  = (currSum + powerCurrPrime) % 9973;


                }
                cnt = (cnt*currCnt)%9973;
                sum = (sum * currSum) % 9973;


            }


    }
    if( nr > 1){
                    cnt *=2;
                    sum = (sum *(1+nr))%9973;
                }

    fout << cnt % 9973 << ' ' << sum << '\n';
}


int main()
{
    fin >> t;

    Ciur(1000000);
    for(int i = 1; i <= t; i++)
        {fin>>n;Solve(n);}

    return 0;
}
