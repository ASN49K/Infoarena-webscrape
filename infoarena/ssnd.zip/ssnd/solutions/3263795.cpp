
#include<fstream>
#define int long long
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int32_t main(){
int q,n,exp,d,prod,nrdiv,sumdiv;
fin>>q;
while(q--){
    fin>>n;
    sumdiv=1;
    nrdiv=1;
    for(d=2;d*d<=n;d++){
        if(n%d==0){
            exp=0;
            prod=d;
            while(n%d==0){
                exp++;
                n/=d;
                prod*=d;
            }
            //fout<<d<<" "<<exp<<endl;
        nrdiv=nrdiv*(exp+1);
        sumdiv=sumdiv*((prod-1)/(d-1));
        }

    }
    if(n>1){
        nrdiv=nrdiv*2;
        sumdiv=sumdiv*(n*n-1)/(n-1);
    }
     //fout<<endl;
    fout<<nrdiv<<" "<<sumdiv<<'\n';
}
}



/*
#include<fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int main(){
int q,n,exp,d,prod,nrdiv,sumdiv;
fin>>q;
while(q--){
    fin>>n;
    sumdiv=1;
    nrdiv=1;
    while(n>1){

            exp=0;
            prod=1;
            while(n%d==0){
                exp++;
                n/=d;
                prod*=d;
            }
            if(exp){
             prod*=d;
             nrdiv=nrdiv*(exp+1);
             sumdiv=sumdiv*((prod-1)/(d-1));
            }
            d++;
            //if(d*d>n)
             //   d=n;
    }

    fout<<nrdiv<<" "<<sumdiv<<'\n';
}
}
*/
