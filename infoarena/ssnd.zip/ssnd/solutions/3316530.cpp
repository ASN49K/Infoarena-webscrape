#include <bits/stdc++.h>

using namespace std;
#define int long long
#define ll long long
#define xx first
#define yy second
#define all (x) begin(x), end(x)
#define MOD 9973
using pii = pair <int, int>;
using tii = tuple <int, int, int>;


#define cin fin
#define cout fout

ifstream cin ("ssnd.in");
ofstream cout ("ssnd.out");


int n;
constexpr int NMAX = (int) 1e6;
bool ciur[NMAX + 1];
vector <int> v;
int k;

inline void eratostene()
{
    ciur[0] = ciur[1] = 1;
    for (int i = 2; i * i <= NMAX; ++ i)
    {
        if (!ciur[i])
            for (int j = i * i; j <= NMAX; j += i)
                ciur[j] = 1;
    }
    for (int i = 2; i <= NMAX; ++ i)
    {
        if (!ciur[i])
           v.push_back(i);
    }
}

inline int lgput(int a, int b)
{
    int p = 1;
    while (b)
    {
        if (b & 1)
        {
            p *= a;
        }
        a *= a;
        b >>= 1;
    }
    return p;
}

inline void solutie (int x)
{
    int idx = 0;
    int p = 1, suma = 1;
    while (idx < v.size() && v[idx] * v[idx] <= x)
    {
        int trala = v[idx];
        int sigma = 0;
        while (x % trala == 0)
        {
            sigma ++;
            x /= trala;
        }
        if (sigma)
        {
            p *= (sigma + 1);
            suma *= ((lgput(trala, (sigma + 1)) - 1) / (trala - 1));
            suma %= MOD;
        }
        idx ++;
    }
     if (x != 1)
        {
            int d = x, sigma = 1;
            if (sigma){
            p *= (sigma + 1);
            suma *= ((lgput(d, (sigma + 1)) - 1) / (d - 1));
            suma %= MOD;
            }
        }
    cout << p << ' ' << suma << '\n';
}
signed main(void)
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin >> n;
     eratostene();
    for (int i = 1; i <= n; ++ i)
    {
        int val;
        cin >> val;
        solutie(val);
    }
    return 0;
}
