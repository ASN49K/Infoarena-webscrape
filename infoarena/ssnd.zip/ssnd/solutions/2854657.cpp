#include <iostream>
#include <vector>

using namespace std;

using ll = long long;
const ll mod=9973;

ll power(ll x, ll p){
    if(p==0) return 1;
    if(p&1){
        ll nr=power(x,p/2);
        return (((nr*nr)%mod)*x)%mod;
    }
    else{
        ll nr=power(x,p/2);
        return (nr*nr)%mod;
    }
}

void solve()
{
    int n; cin>>n;
    ll maxx=0;
    ll a[n];
    for(int i=0; i<n; i++){
        cin>>a[i];
        maxx=max(maxx,a[i]);
    }
    ll m=1e6+5;
    bool ciur[m];
    vector<ll> prim;  
    for(ll i=2; i*i<=m; i++){
        if(ciur[i]) continue;
        prim.emplace_back(i);
        ll p=i+i;
        while(p<=m){
            ciur[p]=true;
            p+=i;
        }
    }
    for(int i=0; i<n; i++){
        int it=0;
        ll sum=1, div=1;
        while(prim[it]*prim[it]<=a[i]){
            ll nr=0;
            while(a[i]%prim[it]==0 && a[i]>1){
                a[i]/=prim[it];
                nr++;
            }
            int p1 = (power(prim[it], nr+1) - 1) % mod;
            int p2 = power(prim[it]-1, mod-2) % mod;
            sum = (((sum * p1) % mod) * p2) % mod;
            div*=nr+1;
            it++;
        }
        if(a[i]>1){
            sum = (sum*(a[i]+1)) % mod;
            div*=2;
        }
        sum%=mod;
        cout<<div<<" "<<sum<<"\n";
    }
}

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    solve();
    return 0;
}