#include <bits/stdc++.h>
using namespace std;

bool ciur[100000005];
const int MOD = 9973;

int exp(int a, int k)
{
    int p = 1;
    while (k > 0)
    {
        if (k % 2 == 1)
        {
            p *= a;
            p %= MOD;
        }
        a *= a;
        a %= MOD;
        k /= 2;
    }
    return p;
}

int logaritm(int b, int v)
{
    int l = 0, r = 50;
    while (r - l > 1)
    {
        int mid = (l + r) / 2;
        int put = exp(b, mid);
        if (put <= v && v % put == 0)
            l = mid;
        else
            r = mid;
    }
    return l;
}


int inv_mod(int a)
{
    return exp(a, MOD - 2);
}

int main() 
{
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
    vector<int> prim;
    for (int i = 2; i * i <= 100000; i ++)
    {
        if (ciur[i] == false)
        {
            prim.push_back(i);
            for (int j = i * i; j <= 100000; j += i)
            {
                ciur[j] = true;
            }
        }
    }
    int q; cin >> q;
    while (q --)
    {
        int a; cin >> a;
        int ans1 = 1, ans2 = 1;
        for (int i = 0; prim[i] <= a; i ++)
        {
            int l;
            if (a % prim[i] == 0)
            {
                l = logaritm(prim[i], a);
                ans1 *= (l + 1);
                ans1 %= MOD;
                ans2 *= (exp(prim[i], l + 1) - 1) * inv_mod(prim[i] - 1);
                ans2 %= MOD;
                //cout << prim[i] << ' ' << l << '\n';
            }
        }
        cout << ans1 << ' ' << ans2 << '\n';
    }
}
