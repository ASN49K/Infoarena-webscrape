#include <bits/stdc++.h>

using namespace std;

using ll = long long;
const int INF=1e9+7;
const ll INFF=1e18+7;
#define nl '\n'
void __print(int x) { cout << x; }
void __print(long x) { cout << x; }
void __print(long long x) { cout << x; }
void __print(unsigned x) { cout << x; }
void __print(unsigned long x) { cout << x; }
void __print(unsigned long long x) { cout << x; }
void __print(float x) { cout << x; }
void __print(double x) { cout << x; }
void __print(long double x) { cout << x; }
void __print(char x) { cout << '\'' << x << '\''; }
void __print(const char* x) { cout << '\"' << x << '\"'; }
void __print(const string& x) { cout << '\"' << x << '\"'; }
void __print(bool x) { cout << (x ? "true" : "false"); }
template<typename T, typename V>
void __print(const pair<T, V>& x) { cout << '{'; __print(x.first); cout << ','; __print(x.second); cout << '}'; }
template<typename T>
void __print(const T& x) { int f = 0; cout << '{'; for (auto& i : x) cout << (f++ ? "," : ""), __print(i); cout << "}"; }
void _print() { cout << "]\n"; }
template <typename T, typename... V>
void _print(T t, V... v) { __print(t); if (sizeof...(v)) cout << ", "; _print(v...); }
#ifndef ONLINE_JUDGE
#define debug(x...) cout << "[" << #x << "] = ["; _print(x)
#else
#define debug(x...)
#endif

void solve()
{
    int n; cin>>n;
    ll maxx=0;
    vector<ll> a(n);
    for(int i=0; i<n; i++){
        cin>>a[i];
        maxx=max(maxx,a[i]);
    }
    ll m=sqrt(maxx)*2;
    vector<bool> ciur(m+m);
    vector<ll> prim;  
    for(int i=2; i<=m; i++){
        if(ciur[i]) continue;
        prim.emplace_back(i);
        ll p=i+i;
        while(p<=m){
            ciur[p]=true;
            p+=i;
        }
    }
    prim.emplace_back(INF);
    for(int i=0; i<n; i++){
        ll sum=a[i]+1;
        ll nr=2,it=0;
        while(prim[it]*prim[it]<=a[i]){
            if(a[i]%prim[it]==0){
                sum+=prim[it];
                sum+=a[i]/prim[it];
                sum%=9973;
                nr+=2;
            }
            it++;
        }
        sum%=9973;
        cout<<nr<<" "<<sum<<nl;
    }
}

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    // int t;
    // cin >> t;
    for(int tt=1; tt<=t; tt++){
        // cout<<"#Case "<<t<<nl;
        solve();
    }
    return 0;
}