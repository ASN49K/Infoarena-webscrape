#include <bits/stdc++.h>
using namespace std;

template <typename T> ostream& operator<<(ostream &os, const vector<T> &v) { os << '{'; string sep; for (const auto &x : v) os << sep << x, sep = ", "; return os << '}'; }
template <typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
using i64 = long long int;

const i64 INF = INT_MAX, MOD = 9973;
const double EPS = 1e-9, PI = acos(-1);
const int dx[] = {0, 0, 0, -1, 1, -1, 1, 1, -1};
const int dy[] = {0, -1, 1, 0, 0, -1, 1, -1, 1};

vector<i64> generate_primes(int max_num) {
  vector<i64> primes;
  vector<bool> sieve(max_num + 1, true);
  sieve[0] = sieve[1] = false;
  for (i64 p = 2; p <= max_num; p++) {
    if (not sieve[p]) continue;
    primes.push_back(p);
    for (i64 d = p * 2; d <= max_num; d += p)
      sieve[d] = false;
  }

  return primes;
}

i64 fast_exponentiation(i64 x, i64 n) {
  if (n == 0) return 1;
  if (n == 1) return x % MOD;
  if (n & 1)
    return ((x % MOD) * fast_exponentiation((x * x) % MOD, (n - 1) / 2)) % MOD;
  return fast_exponentiation((x * x) % MOD, n / 2) % MOD;
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
  /// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
  
  ifstream cin("ssnd.in");
  ofstream cout("ssnd.out");

  vector<i64> primes = generate_primes(1e6 + 5);

  int tests; cin >> tests;
  while (tests--) {
    i64 n; cin >> n;

    i64 sum = 1, divs = 1;
    for (auto prime: primes) {
      i64 power = 0;
      if (prime * prime > n) break;
      if (n % prime != 0) continue;

      while (n % prime == 0) {
        ++power;
        n /= prime;
      }

      divs *= (power + 1);
      i64 d1 = (fast_exponentiation(prime, power + 1) - 1) % MOD;
      i64 mod_inv_numitor = fast_exponentiation(prime - 1, MOD - 2) % MOD;
      sum  = (((sum * d1) % MOD) * mod_inv_numitor) % MOD;
    }

    if (n > 1) {
      divs *= 2;
      sum = (sum * ((n + 1) % MOD)) % MOD;
    }

    cout << divs << " " << sum << "\n";
  }
  
  return 0;
}

