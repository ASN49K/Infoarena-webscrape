#include <iostream>
#include <vector>

using namespace std;
using ll = long long;

const int maxN = 1000000, mod = 9973;
bool c[maxN + 1];
vector <int> primes;

int lgput(int x, int p) {
    if (p == 0) {
        return 1;
    }
    int k = lgput(x, p/2);
    int aux = (1LL * k * k) % mod;
    if (p % 2 == 1) {
        aux = (1LL * aux * x) % mod;
    }
    return aux;
}

void ciur() {
    for (int i = 2; i <= maxN; i++) {
        if (c[i]) {
            continue;
        }
        primes.push_back(i);
        for (int j = 2 * i; j <= maxN; j += i) {
            c[j] = 1;
        }
    }
}

void addFactor(int x, int exp, ll &nrdiv, ll &sum) {
    nrdiv *= (exp + 1);
    int add = 1LL * (lgput(x, exp + 1) - 1) * lgput(x - 1, mod - 2) % mod;
    sum = (sum * add) % mod;
}

void solve() {
    ll n, nrdiv = 1, sum = 1;
    cin >> n;
    for (int i = 0; i < (int) primes.size(); i++) {
        int x = primes[i];
        if (1LL * x * x > n) {
            break;
        }
        if (n % x != 0) {
            continue;
        }
        int exp = 0;
        while (n % x == 0) {
            n /= x;
            exp++;
        }
        addFactor(x, exp, nrdiv, sum);
    }
    if (n != 1) {
        addFactor(n, 1, nrdiv, sum);
    }
    cout << nrdiv << ' ' << sum << '\n';
}

int main() {
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
#endif // LOCAL
    ciur();
    int nrt;
    cin >> nrt;
    while (nrt--) {
        solve();
    }
    return 0;
}
