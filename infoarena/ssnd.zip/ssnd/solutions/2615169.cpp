#include <bits/stdc++.h>
#define DAU  ios_base::sync_with_stdio(false); fin.tie(0); fout.tie(0);
#define PLEC fin.close(); fout.close(); return 0;
using namespace std;
const string problem("ssnd");
ifstream fin(problem + ".in");
ofstream fout(problem + ".out");
typedef long long i64;
const int N(1e6 + 1e4), MOD(9973);
bool ciur[N + 5];
vector<int> prime;
void Ciur() {
    prime.emplace_back(2);
    for (int i = 3; i <= N; i += 2)
        if (!ciur[i]) {
            prime.emplace_back(i);
            if (i <= N / i)
                for (int j = i * i; j <= N; j += i + i)
                    ciur[j] = 1;
        }
}
inline i64 Powlog(i64 a, int b) {
    i64 res(1);
    while (b) {
        if (b & 1)
            res = (res * a) % MOD;
        a = (a * a) % MOD;
        b >>= 1;
    }
    return res;
}
int q, ind, putere, nrd, sumd;
i64 x, d;
int main() {
    DAU
    Ciur();
    fin >> q;
    while (q--) {
        fin >> x;
        ind = 0;
        nrd = sumd = 1;
        while (x != 1) {
            d = prime[ind++];
            if (d * d > x)
                d = x;
            putere = 1;
            while (x % d == 0)
                x /= d, ++putere;
            nrd *= putere;
            sumd = (sumd * ((Powlog(d, putere) - 1) / (d - 1))) % MOD;
        }
        fout << nrd << ' ' << sumd << '\n';
    }
    PLEC
}
