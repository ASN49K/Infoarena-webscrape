import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(new FileInputStream("ssnd.in"));
        PrintWriter writer = new PrintWriter(new FileOutputStream("ssnd.out"));

        int t = scanner.nextInt();
        int n;

        for (int i = 0; i < t; i++) {
            n = scanner.nextInt();
            int count = 0;
            int sum = 0;
            for (int j = 1; j <= (int) Math.sqrt(n); j++) {
                if (n % j == 0) {
                    count += 2;
                    sum += j+(n/j);
                    if (j*j==n) {count--;sum-=j;}
                }
            }
            writer.printf("%d %d %n",count,sum%9973);
        }

        writer.close();
        scanner.close();
    }
}

