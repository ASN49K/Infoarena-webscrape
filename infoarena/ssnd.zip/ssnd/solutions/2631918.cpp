#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
bool ciur[1000000];
long long int v[1000000];
int main()
{ int n,cnt=0,cnt2=0,cnt3=0,nt=0;
fin>>n;
for(int i=2;i<1000000;i++)
{
    if(ciur[i]==0)
    {nt++;
    v[nt]=i;
        for(int j=i+i;j<1000000;j=j+i)
        ciur[j]=1;
    }
}
long long x,p=1,s=1,c,d,ok=0,nd=0,cnd=0;
for(int i=1;i<=n;i++)
{s=1;
d=1;
nd=1;
cnd=0;
    fin>>x;
    c=x;
    while(x>1 && v[d]*v[d]<=x)
    {p=1;
    ok=0;
    if(x%v[d]==0)
    ok=1;
    cnd=0;
        while(x%v[d]==0)
        {
            x=x/v[d];
            p=p*v[d];
            cnd++;
        }
        if(ok==1)
        {
            s=s*(((p*v[d])-1)/(v[d]-1));
            nd=nd*(cnd+1);
        }
        d++;
    }
    if(x>1)
    {
        s=s*(((x*x)-1)/(x-1));
        nd=nd*2;
    }
    fout<<nd<<" "<<s<<'\n';
}
    return 0;
}
