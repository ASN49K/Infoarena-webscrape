 #include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

#define ll unsigned long long
#define nmax 6000001
#define mod 9973

short t;
ll x,primes[6000123],p,ans1,ans2;
bitset<6000123>ciur;

void cheers()
{
    for(int i=2;i<=nmax;i++)
        if(!ciur[i])
            {
                primes[++p]=i;
                for(int j=2*i;j<=nmax;j+=i)
                    ciur[j]=1;
            }
}

ll exp(ll baza, ll exp){
    ll rez = 1;
    while(exp){
        if(exp & 1) rez *= baza;
        baza *= baza;
        exp >>= 1;
    }
    return rez;
}

void compute()
{
    ll x2=x;
    ans1=ans2=1;
    for(int d=1;primes[d]*primes[d]<=x;d++)
    {
        int cnt=1;

        while(x%primes[d]==0)
            x/=primes[d],cnt++;

        if(cnt==1)
            continue;

        ans1*=cnt;
        ans2=ans2*((exp(primes[d],cnt)-1)/(primes[d]-1));
    }
    if(x>1)
        ans1*=2,ans2*=(x+1);

    ans1%=mod;
  //  ans2%=mod;
}


int main()
{
    cheers();
    fin>>t;
    while(t--)
    {
        fin>>x;
        compute();
        fout<<ans1<<' '<<ans2<<'\n';
    }
    return 0;
}
