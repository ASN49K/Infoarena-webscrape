#include <bits/stdc++.h>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

long long int n,x,nrd,sd;

int put(int a,int n)
{
    int p=1;
    while(n)
    {
        if(n%2==1)
            p=p*a;
        a=a*a;
        n/=2;
    }
    return p;
}
int main()
{
    f>>n;
    for(;n>0;n--)
    {
        f>>x;
        nrd=1;
        sd=1;
        long long int p,d=2;
        while(x>1)
        {
            p=0;
            while(x%d==0)
            {
                p++;
                x=x/d;
            }

            if(p>0)
                {
                    nrd*=(p+1);
                    sd=sd*((put(d,p+1)-1)/(d-1));
                }

            d++;
            if(x>1 && d*d>x)
                d=x;
        }
        g<<nrd<<" "<<sd%9973<<"\n";
    }

}
