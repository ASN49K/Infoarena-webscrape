#include <fstream>
	
#include <vector>
	
#include <cmath>
	
 
	
 
	
using namespace std;
	
 
	
const long long MAX_N = 1e6, mod = 9973;
	
 
	
vector<long long> ciur(){
	
 
	
    vector<long long> res;
	
    vector<bool> prime(MAX_N + 1, true);
	
 
	
    res.push_back(2);
	
    for(int nr = 3; nr <= MAX_N; nr += 2){
	
        if(prime[nr]){
	
            res.push_back(nr);
	
            if((long long) nr * nr <= MAX_N)
	
            for(int i = nr * nr; i <= MAX_N; i += nr)
	
                prime[i] = false;
	
        }
	
    }
	
    return res;
	
}
	

long long pow(long long x, long long p){
    
    if(p == 0)
        return 1;
    else if(p % 2)
        return (x * (pow(x, p - 1) % mod)) % mod;
    else
        return (pow(x, p / 2) % mod) * (pow(x, p / 2) % mod) % mod;
}
	
 
	
int main()
	
{
	
    ifstream cin("ssnd.in");
	
    ofstream cout("ssnd.out");
	
         
	
    vector<long long> prime = ciur();
	
 
	
    int T;
	
    long long N;
	
    cin >> T;
	
 
	
    for(; T > 0; --T){
	
        cin >> N;
	
       long long cnt = 1, sum = 1, exp, div, p;
	
        for(long long i = 0; i < prime.size() && prime[i] <= (long long)sqrt(N) && N != 1; ++i){
	
 
	
            exp = 0, div = prime[i] % mod;
	
            while(N % prime[i] == 0){
	
                ++exp;
	
                div = (div * prime[i]) % mod;
	
                N /= prime[i];
	
            }
	
            if(exp != 0){
	
                cnt *= (exp + 1);
                p = pow(prime[i] - 1, mod - 2);
                sum = sum * ((long long)(div - 1) * p % mod) % mod;
	
            }
	
        }
	
        if(N != 1){
            cnt *= 2;
            sum = ((long long)sum * (N + 1) % mod);
	
        }
	
        cout << cnt << " " << sum << "\n";
	
    }
	
    
	
    cin.close();
	
    cout.close();
	
 
	
    return 0;
	
}