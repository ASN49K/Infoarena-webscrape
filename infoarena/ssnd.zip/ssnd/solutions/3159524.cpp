#include <fstream>

using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

void ssnd(){
    int n;
    cin>>n;
    int nrd = 1, sum = 1, d = 2;
    while(d * d <= n){
        if(n%d == 0){
            int exp = 1;
            int p = 0;
            while(n % d == 0){
                p++;
                exp *= d;
                if(exp > 9973) exp %= 9973;
                n /= d;
            }
            nrd *= (p+1) % 9973;
            sum *= ((exp*d - 1)/(d-1)) % 9973;
        }
        d++;
    }
    if(n != 1){
        nrd *= 2;
        sum *= (n*n - 1)/(n-1) % 9973;
    }
    cout << nrd << ' ' << sum << '\n';
}
int main()
{
    int t;
    cin>>t;
    for ( ; t; --t){
        ssnd();
    }
}

