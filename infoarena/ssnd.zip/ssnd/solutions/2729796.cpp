#include<fstream>
#include<iostream>
#define MOD 9973
using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

int t;
unsigned long long n;

int pow(int x, int y)
{
	int p = 1;
	while (y)
	{
		if (y % 2 == 1)
			p = p * x;
		x = x * x;
		y /= 2;
	}
	return p;
}

void ssnd(unsigned long long a)
{
	unsigned int cont = 1;
	unsigned int sumaD = 1;

	while (a % 2 == 0)
	{
		cont++;
		a /= 2;
		sumaD = sumaD + pow(2, cont - 1);
	}
	
	
	for (int d = 3; d <= a; d += 2)
	{
		int p = 1; int o = 1;
		while (a % d == 0)
		{
			p++;
			a /= d;
			o = o+ pow(d, p - 1);
		}
		cont *= p;
		sumaD = sumaD * o;
	}

	if (a > 1)
	{
		cont *= 2;
	}
	g <<cont<<" "<< sumaD%MOD << "\n";
}

int main()
{
	f >> t;
	while (t)
	{
		f >> n;
		ssnd(n);
		t--;
	} 

	g.close();
	return 0;
}