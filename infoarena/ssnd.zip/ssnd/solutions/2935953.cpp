#include <bits/stdc++.h>
using namespace std;

#define DIVMAX 1'000'000
#define MOD 9973

typedef long long ll;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

vector<int> primes;

void sieve(int n) {
	vector<bool> is_prime(n + 1, 1);

	for (int i = 2; i <= n; ++i)
		if (is_prime[i]) {
			primes.push_back(i);
			for (int j = 2 * i; j <= n; j += i)
				is_prime[j] = false;
		}
}

ll pw(ll b, ll e) {
	ll ans = 1LL;
	while (e) {
		if (e & 1)
			ans = (ans * b) % MOD;
		b = (b * b) % MOD;
		e >>= 1;
	}
	return ans;
}

ll inv(ll x) {
	return pw(x, MOD - 2);
}

void solve() {
	ll n;
	fin >> n;

	ll nd = 1, sum = 1;
	for (ll p : primes)
		if (n % p == 0) {
			ll d = 1;
			while (n % p == 0) {
				++d;
				n /= p;
			}
			nd = (nd * d) % MOD;
			sum = (sum * (pw(p, d) - 1)) % MOD;
			sum = (sum * inv(p - 1)) % MOD;
		}

	if (n != 1LL) {
		nd = (nd * 2) % MOD;
		sum = (sum * (pw(n, 2) - 1)) % MOD;
		sum = (sum * inv(n - 1)) % MOD;
	}

	fout << nd << ' ' << sum << '\n';
}

int main() {
	int t;
	fin >> t;

	sieve(DIVMAX);

	while (t--)
		solve();
}
