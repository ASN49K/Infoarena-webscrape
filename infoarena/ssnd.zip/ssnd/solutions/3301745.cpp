#include <fstream>
#include <cmath>

using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

void f(long long n)
{
    long long r=0,s=0;
    for(long long i=1;i*i<=n;i++)
        if(n%i==0)
        {
            if(i*i==n)
            {
                r++;
                s=(s+i)%9973;
            }
            else
            {
                r+=2;
                s=(s+i+n/i)%9973;
            }
        }
    cout<<r<<' '<<s<<'\n';
}

int main()
{
    long long n,m;
    cin>>n;
    while(n--)
    {
        cin>>m;
        f(m);
    }
    return 0;
}
