#include <bits/stdc++.h>
using namespace std;

const int MOD = 9973;

ifstream f ("ssnd.in");
ofstream g ("ssnd.out");


int powlg (int n, int p) {
    int val = 1;
    while (p) {
        if (p & 1)
            val = val * n % MOD;
        n = n * n % MOD;
        p >>= 1;
    }
}

inline int inv_mod (int a) {
    return powlg(a, MOD-2);
}


void sdiv(long long n, int &nr, int &sum) {
    int p = 0;
    sum = nr = 1;
    if (n % 2 == 0) {
        do {
            p++;
            n /= 2;
        }
        while(n % 2 == 0);
        nr = nr * p % MOD;
        sum = (powlg(2,p)-1) % MOD;
    }
    for (int d = 3; 1LL * d * d <= n; d+= 2) {
        if (n % d == 0) {
            p = 0;
            do {
                p++;
                n /= d;
            }
            while (n % d == 0);
            nr = nr * p % MOD;
            sum = 1LL * sum * (powlg(d,p) - 1 + MOD) * inv_mod(d-1) % MOD;
        }
    }
    if (n > 1) {
        nr = nr * 2 % MOD;
        sum = 1LL * sum * (n+1) % MOD;
    }
}
int main()
{
    int t, nr, sum;
    long long n;
    f >> t;
    while (t--) {
        f >> n;
        sdiv(n,nr,sum);
        g << nr % MOD << ' ' << sum << '\n';
    }
    f.close();
    g.close();
    return 0;
}
