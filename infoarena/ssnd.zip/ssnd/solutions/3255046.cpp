#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void div(long x)
    {
        int d = 1;
        int k = 0;
        int s =0;

        while(d<=x)
            {
                if(x%d==0)
                    {
                        k++;
                        s = s+d;
                    }
                d++;
            }
        g<<k<<" "<<s%9973<<endl;
    }

int main()
{
    int t,i,x[1000];
    f>>t;

    for(i=1;i<=t;i++)
            f>>x[i];

    for(i=1;i<=t;i++)
        div(x[i]);

    return 0;
}
