#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long n,a,b,d,i,j,k,m=1e6;
int c[78498],l=9973,t;
bool p[1000000];
int main()
{
    for(c[k++]=2,i=3;i<m;i+=2)
        if(!p[i])
            for(c[k++]=i,j=i*i;j<m;p[j]=1,j+=2*i);
    for(F>>t;t--;n>1?a<<=1,b*=(n+1):0,G<<a<<' '<<b%l<<'\n')
        for(F>>n,a=b=1,i=0;c[i]*c[i]<=n;d?a*=(d+1),b*=((j-1)/(c[i]-1)):0,++i)
            for(d=0,j=c[i];n%c[i]==0;++d,j*=c[i],n/=c[i]);
    return 0;
}
