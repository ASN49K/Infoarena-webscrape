#include <fstream>
#include <vector>
#define MAX 1000000
#define MOD 9973
using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

int t;
bool viz[MAX+10];
vector <long long> prime;

void sieve(){
  viz[0] = viz[1] = 1;
  for(int i=2; i<=MAX; i++)
    if(!viz[i]){
      prime.push_back(i);
      for(int j=i+i; j<=MAX; j+=i)
        viz[j] = 1;
    }
}

long long lgput(long long a, long long n){
  if(!n)
    return 1;
  if(n % 2 == 0)
    return lgput(a*a % MOD, n/2);
  return a * lgput(a*a % MOD, n/2) % MOD;
}

int main(){
  sieve();
  f >> t;
  while(t--){
    long long a, sum=1, ex=1;
      f >> a;
      for(int i=0; i<prime.size(); i++){
        if(prime[i] * prime[i] > a)
          break;
        if(a % prime[i] == 0){
          pair <long long, long long> prim = make_pair(prime[i], 0);
          while(a % prime[i] == 0){
            prim.second++;
            a /= prime[i];
          }
          ex = ex * (prim.second + 1);
          long long val2 = lgput(prim.first-1, MOD-2);
          long long val1 = (lgput(prim.first, prim.second+1) - 1 + MOD) % MOD;
          sum = sum * val1 * val2 % MOD;
        }
      }
      if(a > 1){
        ex = ex * 2;
        long long val2 = lgput(a-1, MOD-2);
        long long val1 = (lgput(a, 2) - 1 + MOD) % MOD;
        sum = sum * val1 * val2 % MOD;
      }
      g << ex << ' ' << sum << '\n';
  }
  return 0;
}
