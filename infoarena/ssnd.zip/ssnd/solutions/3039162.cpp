#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");
int ciur[1000005];
int prime[1000005];
int k = 0;
int MOD = 9973;

void build_ciur()
{
    ciur[0] = ciur[1] = 1;

    for(int i = 2; i<=1000000; i++)
    {
        if(ciur[i] == 0)
        {
            k++;
            prime[k] = i;

            for(int j = i+i; j<=1000000; j+= i)
            {
                ciur[j] = 1;
            }
        }
    }
}

void gcd(int a, int b, long long *x, long long *y)
{
    if(b == 0)
    {
        *x = 1;
        *y = 0;
    }
    else
    {
        long long x0, y0;
        gcd(b, a%b, &x0, &y0);
        *x = y0;
        *y = x0 - (a/b) * y0;
    }
}

void solve()
{
    long long n;
    f>>n;

    long long nd = 1;
    long long sd = 1;
    long putere = 1;
    long long put = 0;
    long long j, y, inv = 0;

    for(int i = 1; i<=k && i*i<=n; i++)
    {
        if(n % prime[i] != 0)
        {
            continue;
        }

        put = 0;
        putere = 1;
        while(n % prime[i] == 0)
        {
            put++;
            n /= prime[i];
            putere = (putere * prime[i]) % MOD;
        }

        nd *= (put+1);

        putere = (putere * prime[i]) % MOD;
        putere = (putere - 1) % MOD;
        if(putere < 0)
        {
            putere += MOD;
        }

        j = prime[i]-1;
        gcd(j, MOD, &inv, &y);

        sd *= ((1LL * putere * inv) % MOD);
    }
    if(n > 1)
    {
        nd *= 2;
        sd = (1LL*sd*(n+1) % MOD);
    }

    g<<nd<<" "<<sd<<'\n';

}

int main()
{
    int t;
    f>>t;

    build_ciur();


    while(t--)
    {
        solve();
    }
    return 0;
}
