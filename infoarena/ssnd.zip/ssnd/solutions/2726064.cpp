#include <fstream>
using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
int main(){
int n;
cin>>n;
for(int i=1;i<=n;i++){
  int x;
  cin>>x;int s=0;int x2=x;
  for(int i=1;i*i<=x;i++){
    if(x%i==0){
      s+=i;
      if(i*i<x){
        s+=x/i;
      }
    }
  }
  int k=1;
  int d=2;
  while(x2>1){
    int exp=0;
    while(x2%d==0){
      x2/=d,exp++;
    }
    if(exp){
      k*=(exp+1);
    }
    d++;
  }
  cout<<k<<" "<<s<<"\n";

}
  return 0;
}
