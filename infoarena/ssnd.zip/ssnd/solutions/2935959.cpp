#include <bits/stdc++.h>
#define NMAX 1000005
#define MOD 9973

using namespace std;

vector <long long> primes;
long long lp[NMAX];

long long logpow(long long n, long long p) {
	long long ans = 1;
	n %= MOD;
	while (p) {
		if (p & 1)
			ans = (1LL * ans * n) % MOD;
		n = (1LL * n * n) % MOD;
		p >>= 1;
	}

	return ans;
}

long long invmod(long long n) {
	return logpow(n, MOD - 2);
}

void make_sieve() {
	for (long long i = 2; i < NMAX; ++i) {

		if (lp[i] == 0)
			primes.push_back(i), lp[i] = i;

		for (long long j = 0; j < (long long)primes.size() && i * primes[j] < NMAX; ++j) {
			lp[i * primes[j]] = primes[j];

			if (i % primes[j] == 0)
				break;
		}
	}
}

void solve() {
	long long n;
	cin >> n;

	vector <pair<long long, long long>> decomp;
	for (long long i = 0; i < (long long)primes.size() && 1LL * primes[i] * 1LL *  primes[i] <= n; ++i) {
		if (n % primes[i] == 0) {
			long long cnt = 0;
			while (n % primes[i] == 0)
				n /= primes[i], ++cnt;
			decomp.push_back({primes[i], cnt});
		}
	}

	if (n != 1)
		decomp.push_back({n, 1});

	long long cntdiv = 1, sumdiv = 1;
	for (auto p : decomp) {
		cntdiv *= (p.second + 1);
		sumdiv = (sumdiv * (logpow(p.first, p.second + 1) - 1) + MOD) % MOD;
		sumdiv = (sumdiv * invmod(p.first - 1) + MOD) % MOD;
	}

	cout << cntdiv << ' ' << sumdiv << '\n';
}
 
int main() {
 
	make_sieve();

	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);

	int t;
	cin >> t;
 
 	while (t--)
 		solve();

	return 0;
}
