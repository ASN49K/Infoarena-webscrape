#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

const int MOD = 9973;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

long long ridicareputere(long long nr, long long exp)
{
      long long r = 1;
      while(exp)
      {
            if(exp % 2 == 1)
                  r = r * nr;
            nr = nr * nr;
            exp = exp / 2;
      }

      return r;
}

long long nr_div(long long n)
{
      long long d = 2, exp = 0, nrd = 1;
      while(n != 1)
      {
            exp = 0;
            while(n % d == 0)
            {
                  exp++;
                  n = n / d;
            }

            if(exp)
                  nrd *= exp + 1;
            
            if(d == 2)
                  d++;
            else  
                  d += 2;

            if (d * d > n)
			d = n;
      }

      return 1LL * nrd % MOD;
}

long long sum_div(long long n)
{
      int exp = 0, sum_div = 1, d = 2;

      while(n != 1)
      {
            exp = 0;
            while(n % d == 0)
            {
                  exp++;
                  n = n / d;
            }

            if(exp)
                  sum_div *= 1LL * ((ridicareputere(d, exp + 1) - 1) / (d - 1)) % MOD; 
            
            if(d == 2)
                  d++;
            else
                  d += 2;
            
            if(d * d > n)
                  d = n;
      }

      return 1LL * sum_div % MOD;
}

int main()
{
      long long n, a;
      fin >> n;
      for(int i = 1; i <= n; ++i)   
            {
                  fin >> a;
                  fout << nr_div(a) << " " << sum_div(a) << '\n';
            }
      return 0;
}