#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

#define ll long long
const int MAX=1e6;
const int MOD=9973;
ll t,n,cnt;
int v[MAX],prim[MAX];

ll pow(ll n, ll p)
{
    ll rez=1;
    n%=MOD;
    while(p)
    {
        if(p&1)
            rez=(rez*n)%MOD;
        n=(n*n)%MOD;
        p>>=1;
    }
    return rez;
}

int main()
{
    v[0]=v[1]=1;
    for(int i=2;i<MAX;i++)
        if(!v[i])
        {
            prim[++cnt]=i;
            for(int j=i+i;j<MAX;j+=i)
                v[j]=1;
        }
    fin >> t;
    while(t--)
    {
        fin >> n;
        ll nrdiv=1,sumdiv=1;
        for(ll i=1,d=2;d*d<=n;d=prim[++i])
            if(n%d==0)
            {
                ll k=0;
                while(n%d==0)
                    n/=d, k++;
                nrdiv*=k+1;
                ll f1=(pow(d,k+1)-1)%MOD;
                ll f2=pow(d-1,MOD-2)%MOD;
                sumdiv=(((sumdiv*f1)%MOD)*f2)%MOD;
            }
        if(v[n]==0)
        {
            nrdiv*=2;
            sumdiv=(1LL*sumdiv*(n+1))%MOD;
        }
        fout << nrdiv << " " << sumdiv << '\n';
    }
    return 0;
}
