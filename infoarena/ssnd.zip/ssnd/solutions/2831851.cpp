#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int nr_div(int n)
{
      int d = 2, exp = 0, nrd = 1;
      while(n != 1)
      {
            exp = 0;
            while(n % d == 0)
            {
                  exp++;
                  n = n / d;
            }

            if(exp)
                  nrd *= exp + 1;
            
            if(d == 2)
                  d++;
            else  
                  d += 2;

            if (d * d > n)
			d = n;
      }

      return nrd;
}

int sum_div(int n)
{
      int exp = 0, sum_div = 1, d = 2;

      while(n != 1)
      {
            exp = 0;
            while(n % d == 0)
            {
                  exp++;
                  n = n / d;
            }

            if(exp)
                  sum_div *= (pow(d, exp + 1) - 1) / (d - 1);
            
            if(d == 2)
                  d++;
            else
                  d += 2;
            
            if(d * d > n)
                  d = n;
      }

      return sum_div;
}

int main()
{
      int n, a;
      fin >> n;
      for(int i = 1; i <= n; ++i)   
            {
                  fin >> a;
                  fout << nr_div(a) << " " << sum_div(a) << '\n';
            }
      return 0;
}