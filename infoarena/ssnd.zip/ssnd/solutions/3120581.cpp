#include<bits/stdc++.h>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long n,a,b,d;
int c[78498],t,i,j,k,l=9973,m=1e6;
bool p[1000000];
int main()
{
    for(i=3;i*i<m;i+=2)
        if(!p[i])
            for(j=i*i;j<m;p[j]=1,j+=2*i);
    for(c[k++]=2,i=3;i<m;i+=2)
        if(!p[i])
            c[k++]=i;
    for(F>>t;t--;n>1?a<<=1,b*=(n+1):0,G<<a<<' '<<b%l<<'\n')
        for(F>>n,a=b=1,i=0;c[i]*c[i]<=n;d?a*=(d+1),b*=((ceil(pow(c[i],d+1))-1)/(c[i]-1)):0,++i)
            for(d=0;n%c[i]==0;++d,n/=c[i]);
    return 0;
}
