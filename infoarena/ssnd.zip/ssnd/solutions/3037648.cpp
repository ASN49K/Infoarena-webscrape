#include <bits/stdc++.h>
#define int unsigned long long
using namespace std;
const int VMAX = 1e6+2;
const int MOD = 9973;
bool ciur[VMAX];
int t,n;
vector<int> prime;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int lgput(int n, int a){
    if(a == 0){
        return 1;
    }else{
        if(a%2 == 0){
            int val = lgput(n, a/2);
            return (val*val)%MOD;
        }else{
            return (n*lgput(n, a-1))%MOD;
        }
    }
}

signed main()
{
    ciur[0] = ciur[1] = 1;
    for(int i = 2; i < VMAX; i++){
        if(ciur[i] == 0){
            prime.push_back(i);
            for(int j = 2*i; j < VMAX; j += i){
                ciur[j] = 1;
            }
        }
    }
    fin >> t;
    while(t--){
        fin >> n;
        int ind = 0;
        int nrd = 1, sd = 1;
        while(ind < prime.size() && n > 1 && prime[ind]*prime[ind] < n){
            if(n%prime[ind] == 0){
                int d = 0;
                while(n%prime[ind] == 0){
                    d++;
                    n /= prime[ind];
                }
                nrd *= (d+1);
                sd = (sd*(lgput(prime[ind], d+1)-1))%MOD;
                sd = (sd*lgput(prime[ind]-1, MOD-2))%MOD;
            }
            ind++;
        }
        if(n > 1){
            nrd *= 2;
            sd = (sd*(n+1))%MOD;
        }
        fout << nrd << " " << sd << "\n";
    }
    return 0;
}
