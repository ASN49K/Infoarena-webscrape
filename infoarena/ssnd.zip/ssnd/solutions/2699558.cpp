#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void rez()
{
    int t;
    f>>t;
    for (int i=1;i<=t;i++)
    {
        int n;
        f>>n;
        int suma=1,cont=1;
        int d;
        for(d=2;d*d<n;d++)
            if (n%d==0) {cont++;suma+=d+(n/d);}
        if (d*d==n) {cont++;suma+=d;}
        if (n!=1) {suma+=n;cont++;}
        g<<cont<<" "<<(suma%9973)<<endl;
    }
}

int main()
{
    rez();
    return 0;
}
