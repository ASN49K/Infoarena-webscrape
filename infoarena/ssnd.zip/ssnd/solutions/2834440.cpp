#include <bits/stdc++.h>
#define LL long long
#define SQRT 1000000
#define MOD 9973

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int prime[SQRT + 2];

void generare()
{
    bitset<SQRT + 1> ciur;
    ciur[0] = 1;
    ciur[1] = 1;
    prime[0] = 0;
    for (int i = 2; i <= SQRT; i++)
	if (!ciur[i])
	{
	    prime[++prime[0]] = i;
	    for (int j = i * 2; j <= SQRT; j += i)
		ciur[j] = 1;
	}
}

void solutie(LL n)
{
    int nrDiv = 1;
    LL sumDiv = 1;
    for (int i = 1; i <= prime[0] && prime[i] * prime[i] <= n; i++)
    {
	int p = 0;
	LL pwr = prime[i];
	while (n % prime[i] == 0)
	{
	    p++;
	    pwr *= prime[i];
	    n /= prime[i];
	}

	nrDiv *= p + 1;
	sumDiv = sumDiv * ((pwr - 1) / (prime[i] - 1)) % MOD;
    }

    if (n > 1)
    {
	nrDiv *= 2;
	sumDiv = sumDiv * ((n * n - 1) / (n - 1)) % MOD;
    }

    fout << nrDiv << ' ' << sumDiv << '\n';
}

int main()
{
    int t; 
    generare();
    fin >> t;
    for (int i = 0; i < t; i++)
    {
	LL x;
	fin >> x;
	solutie(x);
    }
    return 0;
}
