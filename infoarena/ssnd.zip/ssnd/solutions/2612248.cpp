#include <iostream>

using namespace std;

const int MOD = 9973;

int sumaDivizorilor(int n) {
	int suma = 0;
	for (int i = 1;i <= n;i ++)
		if (n % i == 0)
			suma = (suma + i) % MOD;
	return suma;
}

int numarulDivizorilor(int n) {
	int numarDiv = 0;
	for (int i = 1;i <= n;i ++)
		if (n % i == 0)
			numarDiv ++;
	return numarDiv;
}

int main() {
	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);
	int t;
	int n;

	scanf("%d", &t);

	while (t --) {
		scanf("%d", &n);

		printf("%d %d\n", numarulDivizorilor(n), sumaDivizorilor(n));
	}

	return 0;
}