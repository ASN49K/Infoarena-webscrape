#include<fstream>
#define M 9973
using namespace std;
ifstream f("ssnd.in");
ofstream g("ssnd.out");
long long i,x,t,r,e,m,n;
int v[500000];
bool a[1000000];
void C()
{
    int i,j;
    for(v[1]=2,i=3;i<1000;i=i+2)
        if(!a[i])
            for(j=i*i;j<1000000;j=j+i)
                a[j]=1;
    for(r=1,i=3;i<1000000;i=i+2)
        if(!a[i])
            v[++r]=i;
}
int main()
{
    f>>n,C();
    while(n--) {
        f>>x,m=r=1;
        for(i=1;v[i]*v[i]<=x;++i)
            if(x%v[i]==0) {
                e=1,t=v[i];
                while(x%v[i]==0)
                    t*=v[i],x/=v[i],++e;
                r*=e,m*=((t-1)/(v[i]-1))%M;
            }
        if(x!=1)
            r*=2,m*=(x*x-1)/(x-1)%M;
        g<<r<<' '<<m%M<<'\n';
    }
    return 0;
}
