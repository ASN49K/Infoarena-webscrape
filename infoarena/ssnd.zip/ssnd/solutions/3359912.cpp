#include <fstream>
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
bool e[1000005];
int p[1000005];
int k=0;
int mod=9973;
void ciur(){
    e[0]=e[1]=1;
    for(int i=2;i<=1000000;i++){
        if(e[i]==0){
            p[++k]=i;
            for(int j=i;j<=1000000;j+=i){
                e[j]=1;
            }
        }
    }
}
int main()
{
    ciur();
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int d=1;
        int nr=1;
        int sum=1;
        while(n>1){
            int e=0;
            int pw=p[d];
            while(n%p[d]==0){
                n/=p[d];
                e++;
                pw*=p[d];
            }
            nr*=(e+1);
            sum=(sum*(pw-1)/(p[d]-1))%mod;
            d++;
            if(p[d]*p[d]>n&&n>1){
                nr*=2;
                sum=(sum*(n*n-1)/(n-1))%mod;
                n=1;
            }
        }
        cout<<nr<<" "<<sum<<'\n';
    }
    return 0;
}
