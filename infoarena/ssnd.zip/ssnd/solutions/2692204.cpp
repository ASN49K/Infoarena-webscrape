#include <fstream>

using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

long long n;
int t, p[80001], k, nrd, sd;
const int mod = 9973, N = 1000000;
bool v[N + 1];

void ciur () {
  for (int i = 2; i <= N; i++)
    if (not v[i]) {
      p[++k] = i;
      for (int j = 2 * i; j <= N; j += i)
        v[j] = true;
    }
}

int lgput (int a, int b) {
  int r = 1;
  a %= mod;
  while (b) {
    if (b % 2 == 1)
      r = (r * a) % mod;
    a = (a * a) % mod;
    b /= 2;
  }
  return r;
}

int main()
{
  ciur ();
  fin >> t;
  for (int tt = 1; tt <= t; tt++) {
    fin >> n;
    nrd = 1; sd = 1;
    for (int i = 1; i <= k and 1LL * p[i] * p[i] <= n; i++) {
      if (n % p[i])
        continue;
      int e = 0;
      while (n % p[i] == 0) {
        n /= p[i];
        e++;
      }
      nrd *= (e + 1);
      int de = lgput (p[i], e + 1) - 1;
      int im = lgput (p[i] - 1, mod - 2);
      sd = (((de * im) % mod) * sd) % mod;
    }
    if (n > 1) {
      nrd *= 2;
      sd = 1LL * sd * (n + 1) % mod;
    }
    fout << nrd << ' ' << sd << '\n';
  }
  return 0;
}
