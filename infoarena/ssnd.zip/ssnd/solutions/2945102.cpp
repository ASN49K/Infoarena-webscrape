#include<iostream>
#include<fstream>
#include<math.h>
using namespace std;

int ciur[1000000];

void ciurul(int n)
{
	for(int i = 2; i <= n; i++)
		ciur[i]=0;
	for(int i = 2; i <= n; i++) {
        if(ciur[i] == 0) { 
            for(int j = 2 * i; j <= n; j =j + i) {
                ciur[j] = 1;
            }
        }
    }
}

int main()
{	long int n,i,suma,count,t;
	ifstream fin("ssnd.in");
	ofstream fout("ssnd.out");
	fin>>t;
	while(t>0)
	
	{
	suma=0;
	count=2;
	t--;
	fin>>n;
	ciurul(sqrt(n));
if(ciur[n]==0)
	fout<<count<<' '<<n+1<<endl;
else
	{for(i = 2; i <= n/2; i++)
		if(n%i==0)
			{count++;
			suma=suma+i;}
	suma=suma+n+1;
	fout<<count<<' '<<suma<<endl;}
	
	}

}
