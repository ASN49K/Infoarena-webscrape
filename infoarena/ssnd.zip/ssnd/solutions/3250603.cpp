#include<bits/stdc++.h>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long n=1e6,c,d,e,f;
int a[78498],i,j,k,t,m=9973;
bitset<1000001> b;
int main()
{
    for(i=3;i*i<n;i+=2)
        if(!b[i])
            for(j=i*i;j<n;b[j]=1,j+=2*i);
    for(a[k++]=2,i=3;i<n;i+=2)
        if(!b[i])
            a[k++]=i;
    for(F>>t;t--;G<<c<<' '<<d<<'\n') {
        for(F>>n,c=d=1,i=0;i<k&&1LL*a[i]*a[i]<=n;++i)
            if(n%a[i]<1) {
                for(e=2,f=a[i]*a[i],n/=a[i];n%a[i]<1;f*=a[i],++e,n/=a[i]);
                c*=e,d=d*(f-1)/(a[i]-1)%m;
            }
        if(n>1)
            c<<=1,d=d*(n+1)%m;
    }
    return 0;
}
