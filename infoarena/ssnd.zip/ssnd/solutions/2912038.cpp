#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
#define M 9973
long long i,x,t,r,e,m,n;
int v[500000],k,j;
bool a[1000000];
int main()
{
    for(k=3;k<1e3;k+=2)
        if(!a[k])
            for(j=k*k;j<1e6;j+=2*k)
                a[j]=1;
    for(v[++r]=2,k=3;k<1e6;k+=2)
        if(!a[k])
            v[++r]=k;
    for(F>>n;n--;G<<r<<' '<<m%M<<'\n') {
        for(F>>x,m=r=i=1;v[i]*v[i]<=x;++i)
            if(x%v[i]==0) {
                for(e=1,t=v[i];x%v[i]==0;t*=v[i],x/=v[i],++e);
                r*=e,m*=((t-1)/(v[i]-1))%M;
            }
        if(x!=1)
            r*=2,m*=(x+1)%M;
    }
    return 0;
}
