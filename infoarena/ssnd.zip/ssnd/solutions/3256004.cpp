#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void divizori(long x){
         int putere=0;
         int div=1;
         int nr_div =1;
         int v[1000];
         int s = 0;
         int radical = sqrt(x);
    {
    
    for(div = 2; div <= radical; div++){
        putere = 0;
        while(x%div==0){
            putere++;
            x=x/div;
        }
        if(putere>0){
            nr_div *= (putere+1);
        }
    }

    nr_div = 1;
    for(int i=1;i<=radical;i++)
     if(v[i]!=0){
        nr_div *= v[i]+1;
    }
        g<<nr_div<<" "<<s%9973<<endl;
    }
}

int main()
{
    int t,i,x[1000];
    f>>t;

    for(i=1;i<=t;i++)
            f>>x[i];

    for(i=1;i<=t;i++)
        divizori(x[i]);

    return 0;
}

