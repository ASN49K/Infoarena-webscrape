#include <fstream>

using namespace std;
ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");
int main()
{
    int i,v[1001],t,n,s,m,j;
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>v[i];
        n=v[i];
        m=1;
        s=n;
        for(j=1;j<=n/2;j++)
        {
            if(n%j==0) {m=m+1;
                        s=s+j;}
        }
        fout<<m<<" "<<s<<'\n';
    }
    return 0;
}
