#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>
#include <cmath>
#define MOD 9973
#define f first
#define s second
#define ll long long
#define DIM 1000000

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int t;
bitset <DIM+10> ciur;
vector <ll> prime;

void precalc()
{	for(int i=2; i<=DIM; i++)
		if(!ciur[i])
			{	prime.push_back(i);
				for(int j=2*i; j<=DIM; j+=i)
					ciur[j] = 1;
			}
}

ll lgput(ll a, ll n)
{	if(!n) return 1;
	if(n % 2 == 0) return lgput(a*a % MOD, n/2);
	return a * lgput(a*a % MOD, n/2) % MOD;
}

int main()
{
	precalc();
	fin >> t;
	while(t--)
		{	ll n, x, sq, ans1 = 1, ans2 = 1, val1 = 1, val2 = 1;
			fin >> n;
			x = n;
			sq = sqrt(n);
			for(int i=0; prime[i]<=sq && x > 1; i++)
				if(x % prime[i] == 0)
					{	ll val = prime[i], cnt = 0;
						while(x % prime[i] == 0)
							{	cnt++;
								x /= prime[i];	
							}
						ans1 = ans1 * (cnt + 1) % MOD;
						val1 = val1 * (lgput(val, cnt + 1) - 1) % MOD;
						val2 = val2 * (val - 1) % MOD;
					}
			if(x > 1)
				{	ans1 = ans1 * 2 % MOD;
					val1 = val1 * (lgput(x, 2) - 1) % MOD;
					val2 = val2 * (x - 1) % MOD;
				}	
			ans2 = val1 * lgput((ll)val2, MOD-2) % MOD;
			fout << ans1 << ' ' << ans2 << '\n';
		}
	return 0;
}