#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int Mod=9973;
bool v[1000001];
long long prim[100001],n,a,nd=1,sd=1;
long long exp(long long a, long long b)
{
    a%=Mod;
    long long rez=1;
    for(int i=0;(1<<i)<=b;i++)
    {
        if(((1<<i)&b)>0)
            rez=(rez*a)%Mod;
        a=(a*a)%Mod;
    }
    return rez;
}
int main()
{
    int k=0;
    for(int i=2;i<=1000000;i++)
    {
        if(v[i]==0)
        {
            k++;
            prim[k]=i;
            for(int j=2;j*i<=1000000;j++)
                v[i*j]=1;
        }
    }
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> a;
        int q=1;
        nd=1;
        sd=1;
        while(prim[q]*prim[q]<=a)
        {
            if(a%prim[q]==0)
            {
                int e=0;
                while(a%prim[q]==0)
                {
                    a/=prim[q];
                    e++;
                }
                nd*=(e+1);
                long long p1=exp(prim[q],e+1)-1;
                long long p2=exp(prim[q]-1,Mod-2);
                sd*=(p1*p2)%Mod;
            }
            q++;
        }
        if(a>1)
        {
            nd*=2;
            sd=(sd*(a+1))%Mod;
        }
        fout << nd%Mod << " " << sd%Mod << "\n";
    }
    return 0;
}
