#include <iostream>
#include <fstream>
using namespace std;
ifstream in("ssnd.in");
ofstream out("ssnd.out");
int MOD = 9973;
int lg_put(int a, int b) {
    int rez = 1;
    while(b > 0) {
        if(b % 2 == 1) {
            rez = 1LL * rez * a % MOD;
        }
        a = 1LL * a * a % MOD;
        b /= 2;
    }
    return rez;
}

int main(){
    long long t,n;
    in >> t;
    for(int i = 0 ; i < t; i++){
        in >> n;
        long long d = 2,e = 0,card = 1, s=1;
        while(d*d <=n){
            while(n%d==0){
                n/=d;
                e++;
            }
            if(e>0){
                e+=1;
                card=card*e%MOD;
                s= s*(lg_put(d,e)-1+MOD)%MOD*lg_put(d-1,MOD-2)%MOD; ///T. FERMATT
                e=0;    
            }
            if(d==2)
                d++;
            else d+=2;
        }
        if(n>1){
            d=n;
            e=1;
            e+=1;
            card=card*e%MOD;
            s= s*(lg_put(d,e)-1+MOD)%MOD*lg_put(d-1,MOD-2)%MOD;
        }
        out << card <<" " << s<<'\n';
    }
}