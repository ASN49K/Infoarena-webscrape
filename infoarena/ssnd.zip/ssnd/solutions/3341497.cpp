#include <iostream>

#define NMAX 1000005
#define MOD 9973

int log_pow(int base, int exp)
{
    int unit = base, prod = 1;

    if (exp == 0)
        return 1;

    if (exp == 1)
        return base;

    for (int e = 1; e <= exp && e != 0; e <<= 1) {
        if (exp & e)
            prod = (prod * unit) % MOD;

        unit = (unit * unit) % MOD;
    }

    return prod;
}

int main()
{
    int n;
    long long a;
    int cnt, sum;
    bool sieve[NMAX];

    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    for (int i = 1; i < NMAX; ++i)
        sieve[i] = true;

    sieve[1] = false;

    for (int i = 2; i < NMAX; ++i)
        if (sieve[i])
            for (int j = i + i; j < NMAX; j += i)
                sieve[j] = false;

    std::cin >> n;

    for (int i = 0; i < n; ++i) {
        std::cin >> a;

        cnt = 1;
        sum = 1;

        for (int d = 2, exp; 1LL * d * d <= a; ++d) {
            if (!sieve[d])
                continue;

            if (a % d)
                continue;

            exp = 0;

            while (a % d == 0) {
                a /= d;
                
                ++exp;
            }

            cnt = (cnt * (exp + 1)) % MOD;
            sum = ((1LL * sum * ((log_pow(d, exp + 1) - 1 + MOD) % MOD)) % MOD * log_pow(d - 1, MOD - 2) % MOD) * MOD;
        }

        if (a > 1) {
            cnt = (cnt * 2) % MOD;
            sum = (1LL * sum * (a + 1)) % MOD;
        }

        std::cout << cnt << ' ' << sum << '\n';
    }

    return 0;
}
