#include <iostream>
#include <fstream>
#include <vector>
#define MOD 9973
#define NMAX 1000000 // 10^6 * 10^6 = 10^12

using namespace std;
using ll = long long;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bool ciur[NMAX + 1];
vector <int> primes;
vector <int> desc;

void nrPrime()
{
    ciur[1] = 1;

    for (int i = 4; i <= NMAX; i += 2) ciur[i] = 1;

    for (int d = 3; d * d <= NMAX; d += 2)
        if (!ciur[d])
            for (int i = d * d; i <= NMAX; i += d)
                ciur[i] = 1;

    for (int i = 2; i <= NMAX; ++i)
        if (!ciur[i]) primes.push_back(i);
}

int fastPow(int a, int n)
{
    int result = 1;
    while (n) {
        if (n & 1) result = (1LL * result * a) % MOD;
        a = (1LL * a * a) % MOD;
        n >>= 1;
    }
    return result;
}

void descompunere(ll x)
{
    ll nrDiv = 1;
    int sumaDiv = 1;
    int i = 0, exponent;

    while (1LL * primes[i] * primes[i] <= x) {
        exponent = 0;
        while (x % primes[i] == 0) {
            ++exponent;
            x /= primes[i];
        }
        if (exponent) {
            nrDiv *= (1 + exponent);
            int p1 = (fastPow(primes[i], exponent + 1) - 1) % MOD;
            int p2 = fastPow(primes[i] - 1, MOD - 2);
            sumaDiv = (1LL * sumaDiv * p1 * p2) % MOD;
        }
        ++i;
    }

    if (x > 1) {
        nrDiv *= 2;
        sumaDiv = (1LL * sumaDiv * (1 + x)) % MOD;
    }

    fout << nrDiv << " " << sumaDiv << '\n';
}
int main()
{
    int t;
    ll x;

    nrPrime();

    fin >> t;

    while (t--) {
        fin >> x;
        descompunere(x);
    }
}
