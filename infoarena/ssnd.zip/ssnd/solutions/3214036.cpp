#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

#define ll long long
#define ull unsigned long long
const ull MAX = 1e6;

bool ciur[MAX];
int prime[5000000],ind=0;
void gen_ciur(){
    ciur[1] = ciur[0] = 1;
    prime[ind++] = 1;
    for(int i=2;i*i<=MAX;++i)
        if(ciur[i]==0)
            for(int j=2;i*j<=MAX;++j)
                ciur[i*j]=1;
    for(int i=2;i<=MAX;++i)
        if(ciur[i]==0)prime[ind++]=i;
}
int ans=0,sum=0;
void solve(int x){
    ans=0;sum=0;
    for(int i=0;prime[i]*prime[i]<=x;++i){
        if(x%prime[i]==0){
            ans+=2;
            sum += prime[i];
            sum += x/prime[i];
        }
        if(prime[i]*prime[i]==x){
            sum -= prime[i];
            ans--;
        }
    }
    fout << ans << ' ' << sum << '\n';
}
int main()
{
    gen_ciur();
    int n,x;fin>>n;
    for(int i=0;i<n;++i){
        fin>>x;
        solve(x);
    }
    return 0;
}
