#include <iostream>
using namespace std;
int nrDiv(int &a)
{
  int s = a + 1, nr = 2;
  for (int i = 2; i * i <= a; i++)
    if (a % i == 0)
    {
      s += i, nr++;
      if (i * i < a)
        s += a / i, nr++;
    }
  a = s;
  return nr;
}
int main()
{
  int n, x;
  cin >> n;
  for (int i = 1; i <= n; i++)
  {
    cin >> x;
    cout << nrDiv(x) << ' ' << x << endl;
  }
  return 0;
}