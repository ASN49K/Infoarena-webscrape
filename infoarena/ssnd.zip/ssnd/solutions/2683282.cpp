#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define MOD 1000000007

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef double ld;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MAXSQRT = 1000010;
bool isComposite[MAXSQRT];
int primes[MAXSQRT];
int k;

void eratosthenes() {
    for (int i = 2; i <= 1000000; i++) {
        if (!isComposite[i]) {
            primes[k++] = i;      
            for (int j = 2 * i; j <= 1000000; j += i) {
                isComposite[j] = 1;
            }
        }
    }
}



int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    eratosthenes();

    int t;
    fin >> t;
    while (t--) {
        long long n;
        fin >> n;

        long long prod_nr_div = 1, prod_suma_div = 1;
        for (int i = 0; i < k; i++) {
            if (n % primes[i] == 0) {
                int power = 0;
                long long primeToPower = primes[i];
                while (n % primes[i] == 0) {
                    power++;
                    primeToPower *= primes[i];
                    n /= primes[i];
                }
                prod_nr_div *= (power + 1);
                prod_suma_div *= (primeToPower - 1) / (primes[i] - 1);
            }
        }

        fout << prod_nr_div << " " << prod_suma_div << "\n";
    }       
    
    return 0;
}