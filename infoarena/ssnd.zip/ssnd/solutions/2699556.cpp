#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

void rez()
{
    int n;
    f>>n;
    for (int i=1;i<=n;i++)
    {
        int x;
        f>>x;
        int suma=1,cont=1;
        int d;
        for(d=2;d*d<x;d++)
            if (x%d==0) {cont++;suma+=d;}
        if (d*d==x) {cont++;suma+=d;}
        if (x!=1) {suma+=x;cont++;}
        g<<cont<<" "<<(suma%9973)<<endl;
    }
}

int main()
{
    rez();
    return 0;
}
