#include <bits/stdc++.h>
#define LL long long
#define SQR 1000000
#define MOD 9973

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int powlog(int n, int k) {
    int p = 1;
    while (k) {
        if (k % 2)
            p = p * n % MOD;
        n = n * n % MOD;
        k /= 2;
    }
    return p % MOD;
}

vector<int> prime;
void generare() {
    bitset<SQR + 1> ciur;
    ciur[0] = ciur[1] = 1;
    for (int i = 4; i <= SQR; i += 2)
        ciur[i] = 1;
    for (int i = 3; i * i <= SQR; i += 2)
        if (!ciur[i])
            for (int j = i * i; j <= SQR; j += 2 * i)
                ciur[j] = 1;
    prime.push_back(2);
    for (int i = 3; i <= SQR; i += 2)
        if (!ciur[i])
            prime.push_back(i);
}

void rezolvare() {
    LL x, nrDiv = 1, sumDiv = 1;
    fin >> x;
    for (auto &prim: prime) {
        if (prim * prim > x)
            break;
        if (x % prim == 0) {
            int p = 0;
            while (x % prim == 0)
                p++, x /= prim;
            nrDiv *= (p + 1);
            sumDiv = sumDiv * (powlog(prim, p + 1) - 1) / (prim - 1) % MOD;
        }
    }
    if (x > 1)
        nrDiv *= 2, sumDiv = sumDiv * (x * x % MOD - 1) / (x - 1) % MOD;
    fout << nrDiv << ' ' << sumDiv << '\n';
}

int main() {
    generare();
    int n;
    fin >> n;
    for (int i = 0; i < n; i++)
        rezolvare();
    return 0;
}
