#include <fstream>
using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
int n,b,i,c,prime[1000001],k,j,nr,nrd,s,e,x;
bool a[1000001];
int main()
{
    a[1]=a[0]=1;
    for(i=2;i*i<=1000000;i++)
    {
        if(!a[i])
        {
            prime[++k]=i;
            for(j=2;j*i<=1000000;j++)
                a[i*j]=1;
        }
    }
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>x;
        j=1;
        nrd=1;
        s=1;
        while(prime[j]*prime[j]<=x)
        {
            nr=1;
            e=0;
            while(x%prime[j]==0)
            {
                nr*=prime[j];
                e++;
                x/=prime[j];
            }
            if(e)
            {
                nrd=nrd*(e+1);
                s=s*((nr*prime[j]-1)/(prime[j]-1));
            }
            j++;
        }
        if(x>1)
        {
            nrd*=2;
            s*=(x*x-1)/(x-1);
        }
        cout<<nrd<<' '<<s<<'\n';
    }
    return 0;
}
