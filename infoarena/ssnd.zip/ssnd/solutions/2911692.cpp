#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int MOD=9973;
long long powlg(long long n,int p)
{
    long long val=1;
    while (p)
    {
        if (p&1)
            val=val*n%MOD;
        n=n*n%MOD;
        p>>=1;
    }
    return val;
}

inline int inv_mod(int a)
{
    return powlg(a,MOD-2);
}
void sdiv(long long n,int &nr,long long &sum)
{
    int d,p=1;
    sum=nr=1;
    if (!(n&1))
    {
        do
        {
            p++;
            n>>=1;
        }
        while (!(n&1));
        nr=nr*p%MOD;
        sum=sum*(powlg(2,p)-1)%MOD;

    }
    for(d=3;1LL*d*d<=n; d+=2)
    {
        if (n%d==0)
        {

        p=1;
        do
        {
            p++;
            n/=d;
        }
        while(n%d==0);

            nr=nr*p%MOD;
            sum=sum*(powlg(d,p)-1)*inv_mod(d-1)%MOD;
        }
    }
    if (n>1)
    {
        nr=nr*2%MOD;
        sum=sum*(n+1)%MOD;
    }
}
int main()
{
    int t,nr,i;
    long long n,sum;
    fin>>t;
    while(t--)
    {
        fin>>n;
        sdiv(n,nr,sum);
        fout<<nr<<' '<<sum<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
