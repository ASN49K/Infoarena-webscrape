#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#define mod 9973

const int prim_max = 1001000;

using namespace std;
ifstream f("ssnd.in");
ofstream o("ssnd.out");

long long d[30], put[30];
int m, t;
long long n, sum, nr_div;
int ciur[prim_max];
vector <int> p;

int main()
{
    p.push_back(2);
    for (int i = 3; i < prim_max; i += 2){
        if (ciur[i] == 0){
            p.push_back(i);
            if (1LL * i * i <= prim_max){
                for (int j = i*i; j < prim_max; j += 2*i){
                    ciur[j] = 1;
                }
            }
        }
    }
    f >> t;
    for (int i = 0; i < t; i++){
        f >> n;
        m = 0;
        for (int j = 0; n != 1 && p.size() > j; j++){
            if (n % p[j] == 0){
                n = n / p[j];
                d[++m] = p[j];
                put[m] = 1;
                while(n % p[j] == 0){
                    put[m]++;
                    n = n/p[j];
                }
            } else {
                if (1LL * p[j] * p[j] > n){
                    d[++m] = n;
                    put[m] = 1;
                    n = 1;
                }
            }
        }
        sum = 1;
        for (int j = 1; j <= m; j++){

            long long term = d[j];
            for (int k = 1; k <= put[j]; k++)
                term *= d[j];

            sum = sum * (term - 1)/(d[j] - 1);
        }
        nr_div = 1;
        for (int j = 1; j <= m; j++){
            nr_div *= (put[j] + 1);
        }
        o << nr_div << " " << sum % mod << endl;
    }
    return 0;
}
