	
#include <algorithm>
#include <fstream>
#include <queue>
#define MOD 9973
using namespace std;
 
ifstream cin( "ssnd.in" );
ofstream cout( "ssnd.out" );
 
int val[ 78500 ];
 
void eratostene(  ) {
	bool *ciur = new bool[ 1000002 ]();
	{
		for( int i = 2; i * i <= 1000000; i++ )
			if( !ciur[ i ] )
				for( int j = i * i; j <= 1000000; j += i )
					ciur[ j ] = 1;
	}
 
	{
		val[ 0 ] = 2;
		int pp = 1;
		for( int i = 3; i <= 1000000; i += 2 )
			if( !ciur[ i ] )
				val[ pp++ ] = i;
	}
	
	delete[] ciur;
}
 
int main()
{
	int q;
	long long x;
 
	{eratostene();}
 
	cin >> q;
	while( q-- ) {
		cin >> x;
		int kk = 1;
		long long rez = 1;
		for( int i = 0; ( long long )val[ i ] * val[ i ] <= x; i++ )
			if( x % val[ i ] == 0 ) {
				int p = 0;
				long long b = val[ i ];
				while( x % val[ i ] == 0 ) {
					x /= val[ i ], p++;
					b *= val[ i ];
				}
	 
				{
					--b;
					kk *= ( p + 1 );
					b /= ( val[ i ] - 1 );
					b %= MOD;
					rez = ( rez * b ) % MOD;
				}
			}
 
		if( x > 1 ) {
			kk <<= 1;
			long long b = x * x;
			{
				--b;
				b /= ( x - 1 );
				b %= MOD;
				rez = ( rez * b ) % MOD;
			}
		}
 
		cout << kk << ' ' << rez << '\n';
	}
 	return 0;
}