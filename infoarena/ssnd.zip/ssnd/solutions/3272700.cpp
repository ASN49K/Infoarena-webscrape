#include <bits/stdc++.h>
using namespace std;
ifstream f("ssnd.in");
ofstream g("ssnd.out");
int n,t;
bool ci[1000001];
int prime[40001],k;
#define MOD 9973
void ciur()
{   ci[1]=ci[0]=1;
    for(int i=2;i*i<=1e6;i++)
        if(!ci[i])
            for(int j=2;i*j<=100000;j++) ci[i*j]=1;
    for(int i=2;i<=100000;i++)
        if(!ci[i]) prime[++k]=i;
}
int putere(int a, int n)
{   int p=1;
    for(int k=1;k<=n;k<<=1)
    {   if(n&k) p=p*a%MOD;
        a=a*a%MOD;
    }
    return p;
}
int nrdiv,sum;
void rezolvare(int n)
{   nrdiv=1;
    sum=1;
    int d=1;
    while(n>1)
    {   int put=0;
        while(n%prime[d]==0)
        {   put++;
            n/=prime[d];
        }
        if(put!=0)
        {   nrdiv=nrdiv*(put+1)%MOD;
            sum=sum*(putere(prime[d],put+1)-1+MOD)%MOD*putere(prime[d]-1,MOD-2)%MOD;
        }
        d++;
    }
}
int main()
{   ciur();
    f>>t;
    while(t--)
    {   f>>n;
        rezolvare(n);
        cout<<"a";
        g<<nrdiv<<" "<<sum<<'\n';
    }
    return 0;
}
