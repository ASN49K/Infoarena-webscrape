#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int main()
{
    int t;
    fin >> t;
    while(t--)
    {
        long long int n;
        fin >> n;
        int s = n + 1 ;
        int nrdiv = 2;
        for(long long int i = 2; i <= n / 2; i++)
        {
            if(n % i == 0)
            {
                s += i;
                nrdiv++;
                s %= 9973;
            }
        }
        fout << nrdiv << " " << s << "\n";
    }
    return 0;
}
