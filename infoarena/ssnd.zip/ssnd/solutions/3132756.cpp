#include <fstream>
#define int long long
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
long long poww(int a,int b)
{
    int nr=1;

    while(b>0)
    {
        if(b%2)
            nr*=a;
        a*=a;
        b/=2;
    }
    return nr;
}
int ciur[150005];
int nrp[150000];
signed main()
{

   for(int i=2;i*i<=150000;i++)
    if(ciur[i]==0)
    for(int j=i*i;j<=150000;j+=i)
        ciur[j]=1;
    int k=0;
    for(int i=2;i<=150000;i++)
        if(ciur[i]==0)
        nrp[++k]=i;
    long long n,nr;
   cin>>n;
   for(int i=1;i<=n;i++)
   {
       cin>>nr;
       int d=2;
       int k=1;
       int ss=1;
       int s=1;

       while(d*d<=nr)
       {
           int cnt=1;
           while(nr%d==0)
           {
               cnt++;
               nr/=d;
           }
           if(cnt>1)
           {
               ss*=cnt;
               s*=(poww(d,cnt)-1)/(d-1);
               s%=9973;

           }
           d=nrp[++k];
       }
       if(nr>1)
       {
           ss*=2;
               s*=(poww(nr,2)-1)/(nr-1);
               s%=9973;
       }
       cout<<ss<<" "<<s<<'\n';
   }

    return 0;
}
