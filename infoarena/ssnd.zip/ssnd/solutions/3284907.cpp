#include <fstream>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int n,i,q,d,nrd,e,s=0,aux;
int main()
{
    fin>>q;
    for(i=1;i<=q;i++)
    {
        fin>>n;
        aux=n;
        nrd=1;
        d=2;
        while(d*d<=n)
        {
            e=0;
            while(n%d==0)
            {
                e++;
                n=n/d;
            }
            if(e>0)
            {
                nrd=nrd*(e+1);
            }
            d++;
        }
        if(n>1)
        {
            nrd=nrd*2;
        }
        s=0;
        for(d=1;d*d<aux;d++)
        {
            if(aux%d==0)
            {
                s=s+d+aux/d;
            }
        }
        if(d*d==aux)
        {
            s=s+d;
        }
        fout<<nrd<<" "<<s<<endl;
    }
    return 0;
}
