#include <fstream>
#include <bitset>
#define MOD 9973
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
bitset <500001> ciur;
int p[79001],k=1;
void ciuruire()
{
    int i,j;
    p[1]=2;
    for(i=3;i*i<=1e6;i+=2)
        if(ciur[i>>1]==0)
            for(j=i*i;j<=1e6;j+=(i<<1))
                ciur[j>>1]=1;
    for(i=3;i<=1e6;i+=2)
        if(ciur[i>>1]==0)
            p[++k]=i;
}
int main()
{
    ciuruire();
    int t,i,j,nr,sum,rez;
    long long n,nr2;
    cin>>t;
    for(i=1;i<=t;i++)
    {
        cin>>n;
        sum=1;
        rez=1;
        for(j=1;p[j]*p[j]<=n;j++)
        {
            if(n%p[j]==0)
            {
                nr=0;
                nr2=p[j];
                while(n%p[j]==0)
                {
                    n/=p[j];
                    nr2*=p[j];
                    nr++;
                }
                sum=1LL*sum*(nr2-1)/(p[j]-1)%MOD;
                rez=rez*(nr+1);
            }
        }
        if(n>1)
        {
            rez<<=1;
            sum=1ll*sum*(n+1)%MOD;
        }
        cout<<rez<<" "<<sum<<'\n';
    }
    return 0;
}
