#include <bits/stdc++.h>
using namespace std;
string np = "ssnd";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

int n, len;
const int mod = 9973;
bool ciur[1000003];
vector<int> v(1000003);

int fastpow(int a, int b)
{
    a %= mod, b %= mod;
    long long rez = 1;
    while (b)
    {
        if (b % 2 == 1)
            rez = (1LL * rez * a) % mod;
        a = (1LL * a * a) % mod;
        b /= 2;
    }
    return rez;
}
void solve(int n)
{
    int nrdiv = 1, sumadiv = 1;
    for (int i = 1; i <= len and 1LL * v[i] * v[i] <= n; i++)
    {
        if (n % v[i])
            continue;
        int c = 0;
        while (n % v[i] == 0)
            n /= v[i], c++;
        nrdiv *= (c + 1);
        int p1 = (fastpow(v[i], c + 1) - 1) % mod;
        int p2 = fastpow(v[i] - 1, mod - 2) % mod;
        sumadiv = sumadiv * p1 % mod * p2 % mod;
    }
    if (n > 1)
        nrdiv *= 2, sumadiv = (1LL * sumadiv * (n + 1) % mod);
    g << nrdiv << " " << sumadiv << '\n';
}
int main()
{
    for (int i = 2; i < 1000005; i++)
        if (!ciur[i])
        {
            v[++len] = i;
            for (int j = i + i; j < 1000005; j += i)
                ciur[j] = 1;
        }

    int t;
    f >> t;
    while (t--)
        f >> n, solve(n);

    return 0;
}
