#include <iostream>
#include <vector>
#include <cmath>
#define int long long
using namespace std;

int ciur[1000005];
vector<int> prime;

void makeciur() {
    for(int i = 2; i * i <= 1000000; i ++) {
        if(ciur[i])
            continue;
        prime.push_back(i);
        for(int j = i * i; j <= 1000000; j += i) {
            ciur[j] = 1;
        }
    }
}

signed main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
    makeciur();
    int t; cin >> t;
    while(t --) {
        long long n; cin >> n;
        long long nrdiv = 1, sumdiv = 1;
        for(auto i : prime) {
            if(1ll * i * i > n)
                break;
            long long e = 0, sum = 1, putere = 1;
            while(n % i == 0) {
                e ++;
                n /= i;
                putere *= i;
                sum += putere;
            }
            nrdiv *= (e + 1);
            sumdiv *= sum;
            // nrdiv %= 9973;
            // sumdiv %= 9973;
        }
        if(n > 1) {
            nrdiv *= 2;
            sumdiv *= (1 + n);
            // nrdiv %= 9973;
            // sumdiv %= 9973;
        }
        cout << nrdiv % 9973 << ' ' << sumdiv % 9973 <<  '\n';
    }
}