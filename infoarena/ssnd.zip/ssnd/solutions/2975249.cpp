#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MAXV = 1e6;
const int MOD = 9973;

ifstream fin( "ssnd.in" );
ofstream fout( "ssnd.out" );

bool ciur[MAXV+1];
int prime[MAXV+1];
int k;

int lgput( int n, int put ) {
  int rez = 1;
  while( put ) {
    if( put % 2 == 1 )
      rez = rez * n % MOD;
    n = n * n % MOD;
    put /= 2;
  }
  return rez;
}

int invMod( int a ) {
  return lgput( a, MOD - 2 );
}
signed main() {
  int t, i, j, n, sum, nr, exp;
  for( i = 2; i <= MAXV; i++ )
    ciur[i] = true;
  for( i = 2; i * i <= MAXV; i++ ) {
    if( ciur[i] ) {
      for( j = i * i; j <= MAXV; j += i )
        ciur[j] = false;
    }
  }
  k = 0;
  for( i = 2; i <= MAXV; i++ ) {
    if( ciur[i] )
      prime[k++] = i;
  }
  fin >> t;
  while( t-- ) {
    fin >> n;
    nr = 1;
    sum = 1;
    for( i = 0; i < k && prime[i] * prime[i] <= n; i++ ) {
      if( n % prime[i] == 0 ) {
        exp = 0;
        while( n % prime[i] == 0 ) {
          exp++;
          n /= prime[i];
        }
        sum = sum * ( ( lgput( prime[i], exp + 1 ) - 1 + MOD ) % MOD ) % MOD * invMod( prime[i] - 1 ) % MOD;
        nr = nr * ( exp + 1 ) % MOD;
      }
    }
    if( n > 1 ) {
      nr = nr * 2 % MOD;
      sum = sum * ( ( lgput( n, 2 ) - 1 + MOD ) % MOD ) % MOD * invMod( n - 1 ) % MOD;
    }
    fout << nr << " " << sum << "\n";
  }
  return 0;
}
