#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>

#include <iomanip>

#define int long long

using namespace std;

string filename = "ssnd";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int MOD = 9973;

void solve(){
    int n;
    fin >> n;

    int div = 2, ans1 = 1, ans2 = 1;
    while(div * div <= n){
        if(n % div == 0){
            int e = 0, tmp = 1, aux = div;
            while(n % div == 0){
                e++;
                n /= div;

                tmp += aux;
                aux *= div;
            }
            ans1 *= (e + 1);
            (ans2 *= tmp) %= MOD;
        }
        div++;
    }

    if(n > 1){
        ans1 *= 2;
        (ans2 *= (1 + n)) %= MOD;
    }

    fout << ans1 << ' ' << ans2 << '\n';
}

signed main(){

    int T;
    fin >> T;

    while(T--){
        solve();
    }

    return 0;
}