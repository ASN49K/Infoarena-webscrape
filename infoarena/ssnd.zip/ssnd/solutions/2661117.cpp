#include <fstream>

using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
const int nmax=1e6, ct=9973;
int prime[80000],nr=1;
bool ciur[nmax+5];
void eciur()
{
    int ind=1;
    prime[ind]=2;
    for(int i=3; i<=nmax; i+=2)
        if(!ciur[i])
        {
            prime[++ind]=i;
            for(int j=3*i; j<=nmax; j+=i)
                ciur[j]=1;
        }
}
int put(int a, int b)
{
    if(b==0)
        return 1;
    else if(b%2!=0)
        return a*put(a,b-1)%ct;
    int p=put(a,b/2)%ct;
    return p*p%ct;
}
void ans(long long x)
{
    int ind=1, nr=1, s=1;
    long long d=prime[ind];
    while(x>1 and d*d<=x)
    {
        int e=0;
        while(x%d==0)
            e++, x/=d;
        if(e)
            nr*=e+1, s=s*(put(d,e+1)-1)%ct*put((d-1),ct-2)%ct;
        d=prime[++ind];
    }
    if(x!=1)
        nr*=2, s*=(x+1)%ct;
    cout<<nr<<" "<<s<<'\n';
}
int main()
{
    eciur();
    int t;
    long long x;
    cin>>t;
    for(int i=1; i<=t; i++)
        cin>>x, ans(x);
}
