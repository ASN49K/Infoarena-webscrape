#include <iostream>
#include <fstream>
#include <cmath>

int main() {
  std::ifstream in("ssnd.in");
  std::ofstream out("ssnd.out");
  int64_t n, a;
  int64_t div, exp, num, sum;

  in >> n;
  while (in >> a) {
    div = num = sum = 1;

    while (a != 1) {
      ++ div;
      exp = 0;
      if (div * div > a)
        div = a;
      while (a % div == 0) {
        a /= div;
        ++ exp;
      }
      num *= exp + 1;
      sum *= ((int64_t)pow(div, exp + 1) - 1) / (div - 1);
      if (div > 2)
        ++ div;
    }

    out << num << ' ' << sum << '\n';
  }
  return 0;
}
