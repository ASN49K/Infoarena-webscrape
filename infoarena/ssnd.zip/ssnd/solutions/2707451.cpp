#include <fstream>
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
int n,i,j,a[1001],nrd[1001],s[1001],x,poz;
int main()
{
    cin>>n;
    for(i=1;i<=n;i++) cin>>a[i];
    poz=1;
    for(i=2;i<=n;i++) if(a[poz]<a[i]) poz=i;
    x=a[poz];
    for(i=1;i<=x;i++)
    {
            for(j=1;j*i<=x;j++)
                nrd[i*j]++,s[i*j]=(s[i*j]+i)%9973;
    }
    for(i=1;i<=n;i++) cout<<nrd[a[i]]<<' '<<s[a[i]]%9973<<'\n';
    return 0;

}
