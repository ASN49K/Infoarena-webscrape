#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

const int MOD = 9973;
const int VMAX = 1e6;

bitset <VMAX+1> c;
vector <int> prime;
int inv[MOD];

void ciur()
{
    for (int i = 2; i * i <= VMAX; i++)
    {
        if (!c[i])
        {
            for (int j = i * i; j <= VMAX; j += i)
            {
                c[j] = 1;
            }
        }
    }
    for (int i = 2; i <= VMAX; i++)
    {
        if (!c[i])
        {
            prime.push_back(i);
        }
    }
}

int putere(int a, int n)
{
    int p = 1;
    while (n != 0)
    {
        if (n % 2 != 0)
        {
            p = (p * a) % MOD;
        }
        a = (a * a) % MOD;
        n /= 2;
    }
    return p;
}

void invers_mod()
{
    for (int i = 1; i < MOD; i++)
    {
        inv[i] = putere(i, MOD - 2);
    }
}

int main()
{
    ifstream in("ssnd.in");
    ofstream out("ssnd.out");
    ciur();
    invers_mod();
    int t;
    in >> t;
    for (int j = 0; j < t; j++)
    {
        long long n, nrd = 1, sumd = 1;
        in >> n;
        int i = 0;
        while (i < prime.size() && (long long)prime[i] * prime[i] <= n)
        {
            if (n % prime[i] == 0)
            {
                int p = 0;
                while (n % prime[i] == 0)
                {
                    p++;
                    n /= prime[i];
                }
                nrd *= (p + 1);
                sumd *= (putere(prime[i], p + 1) + MOD - 1);
                int numitor = (prime[i] - 1) % MOD;
                if (numitor < 0)
                {
                    numitor += MOD;
                }
                sumd *= inv[numitor];
                sumd %= MOD;
            }
            i++;
        }
        if (n != 1)
        {
            nrd *= 2;
            sumd *= (n + 1);
            sumd %= MOD;
        }
        out << nrd << " " << sumd << "\n";
    }
    return 0;
}
