#include <cstdio>
#include <utility>
#include <iostream>
#include <cmath>
#include<vector>
using namespace std;

const int MOD = 9973;
const int NMAX = 1000000;
const bool PRIM = 0;
const bool COMPUS = 1;

bool Sieve[NMAX + 10];
vector<int> primes;

void ComputeSieve() {
    for (int i = 2; i * i <= NMAX; i++) {
        if (Sieve[i] == PRIM) {
            primes.push_back(i);
            for (int j = i * i; j <= NMAX; j += i) {
                Sieve[j] = COMPUS;
            }
        }
    }
    Sieve[1] = COMPUS;


}

pair<int,int> nrsumdiv(unsigned long long n) {
    int nrdiv, sumdiv;
    nrdiv = sumdiv = 1;

    int i = 0, putere;

    while (n != 1) {
        int d = primes[i];
        putere = 0;
        while (n % d == 0) {
            putere++;
                n /= d;
        }
        sumdiv = (int)(sumdiv * (((pow(d, (putere + 1) % MOD) - 1) / (d - 1)))) % MOD;
        nrdiv *= (putere + 1);

        if (d * d >= n) {
            d = d * d;
        }

        i++;

    }
    return {nrdiv, sumdiv};
}

int main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);


    int t;
    unsigned long long n;

    scanf("%d", &t);

    ComputeSieve();

    for (; t > 0; --t) {
        scanf("%lld", &n);
        pair<int,int> res = nrsumdiv(n);
        printf("%d %d\n", res.first, res.second);
    }
    return 0;
}