#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int k, prime[100001];
int t, mod = 9973;

void generareCiur(int & k, int prime[])
{
    bool vf[100001]={0};
    prime[1] = 2;
    k = 1;
    for(int i = 3; i <= 100001; i+=2)
        if(!vf[i])
        {
            prime[++k] = i;
            for(int j = 2*i; j <= 100001; j += i)
                vf[j] = 1;
        }
}

long long putere(int baza, int exp)
{
    long long p = 1;
    while(exp)
    {
        if(exp%2 == 0)
            baza *= baza;
        else
        {
            p *= baza;
            baza *= baza;
        }
        exp /= 2;
    }
    return p;
}

void descompunereInFactori(int k, long long nr, long long & nrDiv, long long & sumDiv, int prime[])
{
    nrDiv = sumDiv = 1;
    int i = 1;
    while(nr > 1 && i<=k)
    {
        int p = 0;
        long long put = 1;
        while(nr%prime[i] == 0)
        {
            nr /= prime[i];
            p++;
        }
        if(p)
        {
            put = putere(prime[i],p+1);
            //fout << prime[i] << ' ' << p << ' ';
            //fout << "put: " << put << '\n';
            nrDiv *= (p+1);
            sumDiv = (sumDiv * ((put - 1) / (prime[i]-1)) )%mod;
        }
        i++;
    }
    if(nr > 1)
    {
        nrDiv *= 2;
        sumDiv = (sumDiv*((nr*nr-1)/(nr-1))) % mod;
    }
}

int main()
{
    generareCiur(k, prime);

    fin >> t;
    for(int i = 1; i <= t; i++)
    {
        long long nr, sumDiv, nrDiv;
        fin >> nr;
        descompunereInFactori(k, nr, nrDiv, sumDiv, prime);
        fout << nrDiv << ' ' << sumDiv << '\n';
    }
    return 0;
}
