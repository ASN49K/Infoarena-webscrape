#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

const int MAXP = 1e6 + 5;
bool comp[MAXP];
vector<int> primes;

pair<long long, long long> sigma_tau(long long b){
	long long sigma = 1;
	long long tau = 1;
	long long q;
	long long b_old;
	int exp;
	for(auto p : primes){
		if(p*p > b)
			break;

		if(b%p == 0){
			exp = 0;
			q = 1;
			while(b % p == 0){
				b = b / p;
				q = q * p;
				++exp;
			}
			tau = tau * (1 + exp);
			sigma = sigma * ((q*p - 1) / (p - 1));
			sigma = sigma % 9973;
		}
	}

	if(b != 1){
		tau = tau * (1LL + 1);
		sigma = sigma * (b + 1);
	}
	sigma = sigma % 9973;

	pair<long long, long long> ans = {sigma, tau};
	return ans;
}

void erathostenes(){
	int p = 2;
	while(p*p <= MAXP){
		for(int i = 2*p; i <= MAXP; i = i + p){
			comp[i] = true;
		}
		++p;
		while(comp[p])
			++p;
	}

	for(int i = 2; i <= MAXP; ++i){
		if(!comp[i])
			primes.push_back(i);
	}
}






int main(){
	ifstream fin;
	ofstream fout;
	fin.open("ssnd.in");
	fout.open("ssnd.out"); 
	long long n, a;

	fin >> n;
	erathostenes();
	pair <long long, long long> st;
	for(int i=1; i<=n; ++i){
		fin >> a;
		st = sigma_tau(a);
		fout << st.second << " " << st.first;
		fout << "\n";
	}
}