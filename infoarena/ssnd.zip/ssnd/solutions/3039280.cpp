#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const ll NMAX = 1000001;
const ll INF = (1LL << 60);
const ll nrbits = 17;
const ll MOD = 9973;

bool ciur[NMAX];
int primes[NMAX];
int cc = 0;
int pp[NMAX];

int lgput(int n, int p) {
    int r = 1;
    if(p == MOD - 2 && pp[n] != 0)
        return pp[n];
    while(p) {
        if(p % 2) {
            r *= n;
            r %= MOD;
        }
        n *= n;
        n %= MOD;
        p /= 2;
    }
    return pp[n] = r;
}

int main() {
//#ifdef HOME
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
//#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ciur[1] = 1;
    for(int i = 2; i * i < NMAX; i++) {
        if(ciur[i]) continue;
        for(int j = i * i; j < NMAX; j += i)
            ciur[j] = 1;
    }
    for(int i = 2; i < NMAX; i++) {
        if(!ciur[i]) {
            primes[++cc] = i;
        }
    }
    int n, i;
    cin >> n;
    for(i = 1; i <= n; i++) {
        ll x;
        cin >> x;
        int nr = 1;
        int sum = 1;
        int d = 1;
        while(d <= cc && 1LL * primes[d] * primes[d] <= x) {
            int p = 0;
            while(x % primes[d] == 0) {
                p++;
                x /= primes[d];
            }
            if(p > 0) {
                nr *= (p + 1);
                nr %= MOD;
                sum *= (lgput(primes[d], p + 1) - 1 + MOD) % MOD;
                sum %= MOD;
                sum *= lgput(primes[d] - 1, MOD - 2);
                sum %= MOD;
            }
            d++;
        }
        if(x > 1) {
            int p = 1;
            nr *= 2;
            nr %= MOD;
            sum *= (lgput(x % MOD, p + 1) - 1 + MOD) % MOD;
            sum %= MOD;
            sum *= lgput((x - 1) % MOD, MOD - 2);
            sum %= MOD;
        }
        cout << nr << " " << sum << "\n";
    }
}
