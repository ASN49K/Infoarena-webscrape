//#include <iostream>
#include <fstream>
#include <cmath>
#include <bitset>
using namespace std;

ifstream cin ("ssnd.in");
ofstream cout("ssnd.out");

bitset <1000105> ciur;
int t,expo,x;
int prime[1000105],nrprime;
long long sumdiv=1,nrdiv=1,n;

int lgput(int x,int p)
{
    if(p==1)
        return x;
    if(p&1) // daca p e impar
    {
        int xa=lgput(x,p/2);
        xa=xa*xa*x;
        return xa;
    }
    else // p este par
    {
        int xa=lgput(x,p/2);
        return (xa*xa);
    }
}

int main()
{
    cin>>t;
    ciur[1]=1;
    for(int i=2;i<=1000000;i++)
    {
        if(ciur[i]==0)
        {
            nrprime++;
            prime[nrprime]=i;
            for(int j=i+i;j<=1000000;j=j+i)
                ciur[j]=1;
        }
    }
    //for(i=1;i<=100;i++)
        //cout<<ciur[i]<<' ';
    for(int i=1;i<=t;i++)
    {
        cin>>n;
        for(x=1;1LL*prime[x]*prime[x]<=n;x++)
        {
            int j=prime[x];
            //cout<<ciur[j]<<' '<<n<<' '<<j;
            if(n%j==0)
            {
                while(n%j==0)
                {

                    expo++;
                    n=n/j;
                }
                nrdiv=nrdiv*(expo+1);
                sumdiv=sumdiv*((lgput(j,(expo+1))-1)/(j-1));
                expo=0;
            }
        }
        if(n!=1)
        {
            nrdiv=nrdiv*2;
           sumdiv=sumdiv*((n*n-1)/(n-1));
        }
        cout<<nrdiv<<' '<<sumdiv%9973<<'\n';
        nrdiv=1; sumdiv=1;
    }

    return 0;
}
