#include <cstdio>
#include <utility>
#include <iostream>
using namespace std;
#define MOD 9973


pair<int,int> nrsumdiv(unsigned long long n) {
    int nrdiv, sumdiv;
    nrdiv = sumdiv = 1;

    int d = 2, putere;

    while (n != 1) {
        putere = 0;
        while (n % d == 0) {
            putere++;
            n /= d;
        }
        sumdiv = sumdiv * (((pow(d, (putere + 1) % MOD) - 1) / (d - 1)));
        nrdiv *= (putere + 1);
        d++;
    }
    return {nrdiv, sumdiv};
}

int main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);


    int t;
    unsigned long long n;

    scanf("%d", &t);

    for (; t > 0; --t) {
        scanf("%lld", &n);
        pair<int,int> res = nrsumdiv(n);
        printf("%d %d\n", res.first, res.second);
    }
    return 0;
}