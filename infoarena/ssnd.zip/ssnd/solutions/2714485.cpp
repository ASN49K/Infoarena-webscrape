#include <fstream>
#define mod 9973
#define ull unsigned long long
using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

void Afiseaza(ull n)
{
    ull d = 2, p, nr_div = 1, sum_div = 1, tmp;
    while(n > 1)
    {
        p = 0, tmp = 1;
        while(n % d == 0)
        {
            p++;
            tmp = tmp * d;
            n /= d;
        }
        if (p)
        {
            sum_div = sum_div * ((tmp * d - 1)/(d - 1));
            nr_div *= p + 1;
        }
        d++;

        if(n > 1 && d*d > n) d = n;
    }
    cout << nr_div << " " << sum_div % mod << endl;
}

int main()
{
    ull t, n;
    cin >> t;
    for (ull i = 1; i <= t; i++)
        {cin >> n; Afiseaza(n);}
    return 0;
}
