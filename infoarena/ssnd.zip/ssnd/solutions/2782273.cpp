#include <fstream>
#include <cmath>
using namespace std;
ifstream fin ("ssnd.in");
ofstream fout("ssnd.out");
long long i,j,x,t,P,s,S,p,PRIME[100001],k,b;
short int V[1000001];
int main()
{
    V[0]=1;
    V[1]=1;
    for(i=1;i<=1000000;i++)
    {
        if(V[i]==0)
        {
            PRIME[++k]=i;
            for(j=i+i;j<=1000000;j=j+i)
                V[j]=1;
        }
    }
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>x;
        P=1;
        S=1;
        for(j=1;PRIME[j]*PRIME[j]<=x;j++)
        {
            b=PRIME[j];
            if(x%b==0)
            {
                s=0;
                p=1;
                while(x%b==0)
                {
                    x=x/b;
                    p=p*b;
                    s++;
                }
                P=P*(s+1);
                S=S*((p*b-1)/(b-1))%9973;
                if(x==1)
                    break;
            }

        }
        if(x!=1)
        {
            P=P*2;
            S=S*(x*x-1)/(x-1)%9973;
        }
        fout<<P<<" "<<S<<"\n";

    }
    return 0;
}
