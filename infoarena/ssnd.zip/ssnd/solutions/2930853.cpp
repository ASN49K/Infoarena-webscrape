#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<climits>
#include<iomanip>
#include<cstring>
#include<bitset>

#define MAX 1000000
#define MOD 9973

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

//ifstream f("in.in");
//ofstream g("out.out");

int n,t,ind;
int p;
int p2;
bool ok;

int put = 1;
int sum = 1;

bool tmpCiur[MAX+5];
int ciur[78500];
int ciurk=0;

void buildCiur(){

    for(int i=2;i<=MAX;i++){
        if(tmpCiur[i] == 0){

            ciurk++;
            ciur[ciurk] = i;

            for(int j=2;i*j<=MAX;j++){
                tmpCiur[i*j] = 1;
            }
        }
    }

    /*cout<<ciurk<<'\n';
    for(int i=1;i<=ciurk;i++){
        cout<<i<<": "<<ciur[i]<<'\n';
    }*/
}

int exponentiere(int x,int p){

    //cout<<"#";

    if(p==0){
        return 1;
    }

    if(p==1){
        return x;
    }

    if(p%2==0){

        int tmp = exponentiere(x,p/2);

        return (tmp*tmp)%MOD;

    }

    if(p%2==1){

        int tmp = exponentiere(x,p-1);

        return (tmp * x)%MOD;

    }

}

int main(){

    buildCiur();

    f>>t;

    for(int i=1;i<=t;i++){
        f>>n;

        ind = 1;

        put = 1;
        sum = 1;

        while(n > 1){

            p=0;
            p2=1;
            ok=0;
            while(n%ciur[ind]==0){

                ok=1;
                n/=ciur[ind];

                p++;
                p2*=ciur[ind];
            }

            if(ok==1){
                put = (put * (p+1))%MOD;

                p2 = ((p2%MOD) * ciur[ind] - 1)%MOD;
                sum = (sum * (p2 * exponentiere(ciur[ind]-1,MOD-2))%MOD )%MOD;
            }


            ind++;
        }

        g<<put<<" "<<sum<<'\n';
    }


    f.close();
    g.close();
    return 0;
}
