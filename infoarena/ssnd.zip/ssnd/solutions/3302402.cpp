#include <fstream>
#include <math.h>

using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

int const mod=9973;
long long suma;
int numarul_de_divizori;

void ssnd(long long n)
{
    int d=2,exp,sum=1,nrdiv=1,put=1;
    while(n>1)
    {
        exp=0;
        while(n%d==0)
        {
            n=n/d;
            exp++;
        }
        nrdiv=nrdiv*(exp+1);
        put=(pow(d,exp+1)-1)/(d-1);
        sum=(sum*put)%mod;
        d++;
    }
    /**if(n>1)
    {
        sum=sum*(pow(n,2)-1)/(d-1);
        nrdiv=nrdiv*2;
    }**/
    sum=sum%mod;
    suma=sum;
    numarul_de_divizori=nrdiv;
}

int main()
{
    int T,i,j;
    long long n;
    cin>>T;
    for(i=1;i<=T;i++)
    {
        cin>>n;
        ssnd(n);
        cout<<numarul_de_divizori<<" "<<suma<<endl;
    }
    /**c[0]=1;
    c[1]=1;
    for(i=2;i<=1000000;i++)
    {
        if(c[i]==0)
        {
            for(j=2;i*j<=1000000;j++)
                c[i*j]=1;
        }
    }
    j=0;
    for(i=1;i<=1000000;i++)
    {

        if(c[i]==0)
        {
            j++;
            prime[j]=i;
        }
    }**/
    return 0;
}
