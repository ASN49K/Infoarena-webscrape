#include <bits/stdc++.h>
#define int long long
#define pii pair<long long,long long>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

int n,x;
const int mod=9973;
pii y;
bitset <1000200> ciur;
vector <int> prime;

int power(int a,int b)
{
    int rez=1;
    while(b)
    {
        if(b&1)
            rez=rez*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return rez;
}

int ec(int d,int e){
    return (power(d,e+1)-1+mod)*power(d-1,mod-2)%mod;
}

pii calc(int x){
    int nr=1,suma=1;
    auto p=prime.begin();
    while(p!=prime.end() and x!=1)
    {
        int d=*p, e=0;
        while(x%d==0)
            x/=d, e++;
        if(e)
            nr=nr*(e+1)%mod, suma=suma*ec(d,e)%mod;
        if(d*d>x and x>1)
            nr*=2, suma=suma*ec(x,1)%mod, x=1;
        p++;
    }
    return {nr,suma};
}

int32_t main()
{
    f>>n;
    for(int i=2; i<=1000; i++)
        if(ciur[i]==0)
        {
            prime.push_back(i);
            for(int j=i+i; j<=1000000; j+=i)
                ciur[j]=1;
        }
    for(int i=1001; i<=1000000; i++)
        if(ciur[i]==0)
            prime.push_back(i);
    for(int i=1; i<=n; i++)
        f>>x, y=calc(x), g<<y.first<<' '<<y.second<<'\n';
    return 0;
}
