#include <iostream>

using namespace std;
const int NMAX = 1000001, MOD = 9973;

long long n;
int prim[NMAX], nr, t;
bool viz[NMAX];

void ciur(int n)
{
    prim[++nr] = 2;
    for(int i = 4; i <= n; i += 2)
        viz[i] = 1;
    for(int i = 3; i * i <= n; i += 2)
        if(viz[i] == 0)
            for(int j = i * i; j <= n; j += i)
                viz[j] = 1;
    for(int i = 3; i <= n; i++)
        if(viz[i] == 0)
            prim[++nr] = i;
}

int main()
{
    cin >> t;
    ciur(NMAX);
    while(t--)
    {
        cin >> n;
        int sumdiv = 1, nrdiv = 1;
        while(n)
            for(int i = 1; prim[i]*prim[i] <= n; i++)
                if(n % prim[i] == 0)
                {
                    nrdiv++;
                    sumdiv = (sumdiv + prim[i]) % MOD;
                    do
                    {
                        n /= prim[i];
                    }
                    while(n % prim[i] == 0);
                }
    }
    return 0;
}
