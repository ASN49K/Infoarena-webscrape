#include <fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int s_div(int x)
{
    int sd=1;
    int d=2;
    while (d*d<=x)
    {
        int e=0;
        int p=d;
        while (x%d==0)
        {
            e++;
            p=p*d;
            x/=d;
        }
        if (e>0)
            sd=sd*(p-1)/(d-1);
        d++;
    }
    if (x>1) sd=sd*(x+1);
    return sd;
}
int nr_div(int x)
{
    int d=2;
    int nrd=1;
    while (d*d<=x)
    {
        int e=0;
        while (x%d==0)
        {
            e++;
            x/=d;
        }
        if (e>0) nrd=nrd*(e+1);
        d++;
    }
    if (x>1) nrd=nrd*2;
    return nrd;
}

int n,x;
int main()
{
    fin>>n;
    for (int i=1;i<=n;i++)
    {
        fin>>x;
        fout<<nr_div(x)<<" "<<s_div(x)<<'\n';
    }
    return 0;
}
