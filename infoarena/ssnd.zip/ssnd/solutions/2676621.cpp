#include <bits/stdc++.h>

using namespace std;
#define MAX 1e12

long long  prime[1000001];
long long mod,suma,numar;
void ciur()
{
    long long i,j,nr;

    prime[1]=2;
    prime[2]=3;
    prime[3]=5;
    nr=3;
    i=7;
    while(i*i<MAX)
    {
        j=1;
        while(j<=nr&&prime[j]*prime[j]<=i &&i%prime[j])j++;
        if(j>nr||prime[j]*prime[j]>i)
        {
            prime[++nr]=i;
        }
        i+=2;
    }
}
void rez(long long x)
{
    long long p;
    mod=1;
    suma=1;
    for(long long i=1; prime[i]<=x; i++)
    {
        if(x%prime[i]==0)
        {
            p=0;
            numar=prime[i];
            while(x%prime[i]==0)
            {
                x=x/prime[i];
                numar*=prime[i];
                p++;
            }
            mod*=(p+1);
            suma*=(numar-1)/(prime[i]-1);
            suma%=9973;

        }
    }

    printf("%lld %lld",mod,suma);
    printf("\n");
}
int main()
{
    ciur();
    long long n,a;
    freopen("ssnd.in","r",stdin);
    freopen("ssnd.out","w",stdout);

    scanf("%lld",&n);

    for(; n; n--)
    {
        scanf("%lld",&a);
        rez(a);

    }
    return 0;
}
