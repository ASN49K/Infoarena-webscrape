#include <bits/stdc++.h>

using namespace std;

ifstream f("euro2.in");
ofstream g("euro2.out");

int n,i,j,k=-1,maxim,k1[10002];
float x[10002],v[10002];

int main()
{
    f>>n;
    for(i=1; i<=n; i++)
    {
        f>>x[i];
        if(x[i]>v[k])
        {
            v[++k]=x[i];
        }
        else
        {
            auto p=lower_bound(v,v+k,x[i]);
            v[p-v]=x[i];
        }
        k1[i]=k+1;
//        for(j=0; j<=k; j++)
//        {
//            cout<<v[j]<<' ';
//        }
//        cout<<'\n';
    }
    k=-1;
    for(i=n; i>=1; i--)
    {
//        for(j=0; j<=k; j++)
//        {
//            cout<<v[j]<<' ';
//        }
//        cout<<'\n';
        maxim=max(maxim,k+k1[i]+1);
        if(x[i]>v[k])
        {
            v[++k]=x[i];
        }
        else
        {
            auto p=lower_bound(v,v+k,x[i]);
            v[p-v]=x[i];
        }
//        cout<<k1[i]<<' '<<k<<'\n';
    }
    g<<maxim-1;
    return 0;
}
