#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define MOD 9973

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef double ld;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MAXSQRT = 1000010;
bool isComposite[MAXSQRT];
int primes[MAXSQRT];
int k;

void eratosthenes() {
    for (int i = 2; i <= 1000000; i++) {
        if (!isComposite[i]) {
            primes[k++] = i;      
            for (int j = 2 * i; j <= 1000000; j += i) {
                isComposite[j] = 1;
            }
        }
    }
}


long long logpower(int x, int p) {
    long long res = 1;
    x %= MOD;
    while (p) {
        if (p & 1) {
            res = (res * x) % MOD;
        }

        x = (x * x) % MOD;
        p >>= 1;
    }

    return res % MOD;
}


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    eratosthenes();

    int t;
    fin >> t;
    while (t--) {
        long long n;
        fin >> n;

        long long sum = 1, number = 1;
        for (int i = 0; i < k; i++) {
            if (n % primes[i]) {
                continue;
            }

            int power = 0;

            while (n % primes[i] == 0) {
                power++;
                n /= primes[i];
            }

            number *= (power + 1);
            
            long long p1 = logpower(primes[i], power + 1) - 1;
            long long p2 = logpower(primes[i] - 1, MOD - 2);
            sum = (((sum * p1) % MOD) * p2) % MOD;
        }
        fout << number << " " << sum << "\n";
    }       
    
    return 0;
}