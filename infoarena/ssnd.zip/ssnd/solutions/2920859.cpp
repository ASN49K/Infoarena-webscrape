#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream in("ssnd.in");
ofstream out("ssnd.out");
const int NMAX=1000001;
bool ciur[NMAX];
int prim[80000];
int k;
void calcul(long long x)
{
    int nr_div=1;
    long long suma=1;
    int i=1;

    while(i<=k && prim[i]*prim[i]<=x)
    {
        int nr=0;

        if(x%prim[i]==0)
        {
            nr=0;

            long long d=prim[i];
            while(x%prim[i]==0)
            {
                x/=prim[i];
                nr++;
            }

            nr_div*=(nr+1);
            suma*=((pow(d,nr+1)-1)/(d-1));
            suma=suma%9973;
        }
                i++;
    }
    if(x>1)
    {
        nr_div*=2;
        suma*=(pow(x,2)-1)/(x-1);
        suma=suma%9973;
    }
    out<<nr_div<<" "<<suma<<'\n';

}
int main()
{
    ciur[0]=ciur[1]=1;
    for(int i=3; i<=1000; i+=2)
    {
        if(ciur[i]==0)
        {
            for(int j=2*i; j<=1000000; j=j+i)
                ciur[j]=1;

        }
    }

    k=1;
    prim[1]=2;
    for(int i=3; i<=1000000; i+=2)
        if(ciur[i]==0)
        {
            prim[++k]=i;
        }

    int t;
    long long n;
    in>>t;
    for(int i=1; i<=t; i++)
    {
        in>>n;
        calcul(n);
    }

    return 0;
}
