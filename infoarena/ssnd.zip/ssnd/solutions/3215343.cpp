#include <iostream>
#include <fstream>
#define int long long
using namespace std;

int suma,prod;

int logarizare(int put, int exp)
{
    int prod2=1;
    if(exp%2==1)
        prod2*=put%9973, exp--;
    while(exp/2>0)
    {
        put=(put*put)%9973;
        exp/=2;
    }
    prod2=(prod2*put)%9973;
    return prod2;
}

void divizori(int a)
{
    int d=2,exp=0;
    suma=1;
    prod=1;

    if(a%d==0)
    {
        int prod2=1; exp=0;
        while(a%d==0)
        {
            prod2=prod2*d%9973;
            a/=d;
            exp++;
        }
        prod*=(exp+1)%9973;
        //cout<<suma<<" "<<d<<" "<<exp+1<<" "<<((prod2*d+9973-1)%9973)<<" "<<logarizare(d-1, 9971)%9973<<'\n';
        suma=(suma* ((prod2*d+9973-1)%9973) * logarizare(d-1, 9973-2) %9973) %9973;
    }

    d=3;
    while(a!=1)
    {
        if(a%d==0)
        {
            int prod2=1; exp=0;
            while(a%d==0)
            {
                prod2=prod2*d%9973;
                a/=d;
                exp++;
            }
            prod*=(exp+1)%9973;
            //cout<<suma<<" "<<d<<" "<<exp+1<<" "<<((prod2*d+9973-1)%9973)<<" "<<logarizare(d-1, 9971)%9973<<'\n';
            suma=(suma* ((prod2*d+9973-1)%9973) * logarizare(d-1, 9973-2) %9973) %9973;
        }
        d+=2;
    }
}

int32_t main()
{
    ifstream cin("ssnd.in");
    ofstream cout("ssnd.out");
    int n,a;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>a;
        divizori(a);
        cout<<prod<<" "<<suma<<'\n';
    }

    int prod3=1;
    for(int i=1; i<=9971; i++)
        prod3=prod3*2%9973;

    cout<<prod3<<" "<<logarizare(2, 9971);


    return 0;
}
