#include <bits/stdc++.h>

using namespace std;

int euclid(int a,int b, int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
       int x0,y0;
        int dd=euclid(b,a%b,x0,y0);
        x=y0;
        y=x0-a/b*y0;
        return dd;

    }


}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    int n,a,b,x,jj,y,cc;
    scanf("%d",&n);

    for(; n; --n)
    {
        scanf("%d%d%d",&a,&b,&cc);
        int j=euclid(a,b,x,y);
              if(cc%j)
        {
            printf("0 0");

        }
        else
        {

            printf("%d %d",x*(cc/j),y*(cc/j));
            printf("\n");
        }
    }
    return 0;
}
