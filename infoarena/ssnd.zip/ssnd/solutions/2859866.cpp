#include<bits/stdc++.h>
#define nmax 1000005
#define mod 9973
#define ll long long

using namespace std;

FILE *in = fopen("ssnd.in","r");
FILE *out = fopen("ssnd.out","w");
ll n;

int nrprim(int n)
{
    if(n>2 && n%2==0)
        return 0; //nu e prim
    for(int i=3; i*i<=n; i+=2)
        if(n%i==0)
            return 0;
    return 1;

}
void solve()
{

    fscanf(in,"%d",&n);

    int sum,ans,d=2;
    sum=ans=1;

    if(n!=1)
        sum=(1LL*(sum+n))%mod,ans++;
    if(nrprim(n)==0)
    {
        for(d=2; d*d<=n; d++)
        {
            if(n%d==0)
            {
                ans++;
                sum=(1LL*(sum+d))%mod;
                if(d*d<n)
                {
                    ans++;
                    sum=(1LL*(sum+n/d))%mod;
                }
            }
        }
    }

    fprintf(out,"%d %d\n",ans,sum);

}
int main()
{
    int t;
    fscanf(in,"%d",&t);

    for(int i=0; i<t; i++)
        solve();
}

