#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long n,m=1e6,j,f,i;
int c[78498],l,e,k;
bool p[1000001];
int main()
{
    for(c[k++]=2,i=3;i<=m;i+=2)
        if(!p[i])
            for(c[k++]=i,j=i*i;j<=m;p[j]=1,j+=2*i);
    for(F>>n;F>>n;n>1?e*=2,f*=(n+1):0,G<<e<<' '<<f%9973<<'\n')
        for(e=f=1,i=0;c[i]*c[i]<=n;l?e*=(l+1),f*=(j-1)/(c[i]-1):0,++i)
            for(j=c[i],l=0;n%c[i]==0;n/=c[i],j*=c[i],++l);
    return 0;
}
