#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int MOD=9973;
long long powlg(long long n,int p)
{
    long long val=1;
    while (p)
    {
        if (p&1)
            val*=n;
        n*=n;
        p>>=1;
    }
    return val%MOD;
}
void div(long long n,int &nr,int &sum)
{
    int d,p=1;
    sum=nr=1;
    while (!(n&1))
    {
        p++;
        n>>=1;
    }
    if(p>1)
    {
        nr*=p;
        sum=(powlg(2,p)-1);
        sum%=MOD;
    }
    for(d=3; d*d<=n; d+=2)
    {
        p=1;
        while(n%d==0)
        {
            p++;
            n/=d;
        }
        if(p>1)
        {
            nr*=p;
            sum*=(powlg(d,p)-1)/(d-1);
            sum%=MOD;
        }
    }
    if (n>1)
    {
        nr*=2;
        sum*=(n*n-1)/(n-1);
        sum%=MOD;
    }
}
int main()
{
    int t,sum,nr,i;
    long long n;
    fin>>t;
    for(i=1; i<=t; i++)
    {
        fin>>n;
        div(n,nr,sum);
        fout<<nr<<' '<<sum<<'\n';
    }
    return 0;
}
