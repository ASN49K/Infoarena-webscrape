#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int mod=9973;
bool ciur[2000003];
long long prime[1000007];
long long nr;
long long x,n;

void erat()
{
    ciur[1]=1;
    ciur[0]=1;
    for(long long i=2; i<1000003; i++)
    {
        if(ciur[i]==0)
        {
            prime[nr++]=i;
            for(long long j=i*i; j<1000003; j+=i)
            {
                ciur[j]=1;
            }
        }
    }
}

int main()
{
    fin>>n;
    erat();
    long long sum =1, nrdiv=1, div=prime[0], i=0;
    while(n--)
    {
        fin>>x;
        while(x>1)
        {
            long long exponent=0, put=div;
            while(x%div==0)
            {
                exponent++;
                x/=div;
                put*=div;
            }
            if(exponent)
            {
                nrdiv*=exponent+1;
                sum*=(put-1)/(div-1);
                sum%=mod;
            }
            div=prime[++i];
            if(x>1 && div*div>x) div=x;
        }
        fout<<nrdiv<<" "<<sum%mod<< "\n";
    }
    return 0;
}
