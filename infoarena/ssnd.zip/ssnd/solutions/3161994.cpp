#include <iostream>
#include <fstream>
std::ifstream fin ("ssnd.in");
std::ofstream fout ("ssnd.out");

int main()
{
    unsigned short t;
    fin >> t;

    for (int i=0;i<t;i++)
    {
        unsigned long long n;
        fin >> n;
        bool C[n]{};
        for (unsigned long long i=2;i<n;i++)
        {
            if (C[i]==false) {
                for (unsigned long long j=2*i;j<=n;j+=i)
                {
                    C[j]=true;
                }
            }
        }
        int c=2;
        unsigned long long s=(n+1)%9973;
        for (unsigned long long j=2;j*j<=n;j++)
        {
            if (C[j]==false && n%j==0 ){
                c+=1+(j*j!=n);
                s=(s+j+(j*j!=n)*n/j)%9973;
            }
        }
        fout << c << " " << s << std::endl;
    }
    return 0;
}
