
#include <fstream>
#include <cmath>
#include <iostream>
#include <vector>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
#define MAX 1000001
#define PRIME 9973
#define ll long long

ll powe(ll n, ll k)
{
    if (k == 0)
    {
        return 1;
    }
    if (k % 2 == 0)
    {
        return powe((n * n), k >> 1);
    }
    else
    {
        return (n * powe(n, --k));
    }
}

int countDivisors(vector<pair<ll, int>> decomp)
{
    int cnt = 1;
    for (pair<ll, int> p : decomp)
    {
        cnt *= (p.second + 1);
    }
    return cnt;
}

ll divisorsSum(vector<pair<ll, int>> decomp)
{
    ll prod = 1;
    for (pair<ll, int> p : decomp)
    {
        prod *= ((powe(p.first, p.second + 1) - 1) / (p.first - 1));
        prod %= PRIME;
    }
    return prod;
}

int main()
{
    ll t, n;
    fin >> t;
    bool isPrime[MAX];
    fill(isPrime, isPrime + MAX, true);
    for (int i = 2; i < MAX; ++i)
    {
        if (isPrime[i])
        {
            for (int j = 2; j * i <= MAX; ++j)
            {
                isPrime[j * i] = false;
            }
        }
    }
    while (t-- > 0)
    {
        fin >> n;
        vector<pair<ll, int>> decomp;
        ll init = n;
        ll lim = sqrt(n);
        for (int i = 2; i <= lim && n > 1; ++i)
        {
            if (init % i == 0)
            {
                if (isPrime[i])
                {
                    ll k = i;
                    int exp = 0;
                    while (n % k == 0)
                    {
                        n /= k;
                        ++exp;
                    }
                    decomp.push_back({k, exp});
                }
                if (init / i <= MAX && isPrime[init / i])
                {
                    ll k = init / i;
                    int exp = 0;
                    while (n % k == 0)
                    {
                        n /= k;
                        ++exp;
                    }
                    decomp.push_back({k, exp});
                }
            }
        }
        if (decomp.empty())
        {
            decomp.push_back({init, 1});
        }
        fout << countDivisors(decomp) << " " << divisorsSum(decomp) << "\n";
    }
    return 0;
}
