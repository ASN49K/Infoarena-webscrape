#include <bits/stdc++.h>
#define MAXN 1000
#define MOD 9973

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

void rezolvare(int n) {
    int nrDiv = 1, sumDiv = 1;
    if (n % 2 == 0) {
        int p = 0;
        while (n % 2 == 0)
            p++, n /= 2;
        nrDiv *= p + 1, sumDiv *= ((long long)pow(2, p + 1) % MOD - 1);
    }
    for (int d = 3; d * d <= n; d += 2)
        if (n % d == 0) {
            int p = 0;
            while (n % d == 0)
                p++, n /= d;
            nrDiv *= p + 1, sumDiv *= ((long long)pow(d, p + 1) % MOD - 1) / (d - 1);
        }
    if (n > 1)
        nrDiv *= 2, sumDiv *= (n * n % MOD - 1) / (n - 1);
    fout << nrDiv << ' ' << sumDiv << '\n';
}

int main() {
    int t;
    for (fin >> t; t; t--) {
        int x;
        fin >> x;
        rezolvare(x);
    }
    return 0;
}