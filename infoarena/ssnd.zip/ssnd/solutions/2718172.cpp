#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int n;
    vector<int> v;

    cin >> n;
    for (int i = 0; i < n; i++)
    {
        int x;
        cin >> x;
        v.push_back(x);
    }

    int cand = v[0], vot = 0;
    for (auto x : v)
    {
        if (x == cand)
            vot++;
        else
            vot--;
        if (vot == 0) cand = x, vot = 1;
    }

    if (vot > 0)
    {
        vot = 0;
        for (auto x : v)
            if (x == cand) vot++;
    }

    if (vot > n / 2) cout << "DA " << cand;
    else cout << "NU";

    return 0;
}
