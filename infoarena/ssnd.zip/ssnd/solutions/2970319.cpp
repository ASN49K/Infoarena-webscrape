#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

bitset <1000001> is_prime;
int primes[1000001];
int k = 0;
int mod = 9973;

void sieve(){
    for(int i = 2; i * i <= 1e6; i++){
        if(!is_prime[i]){
            for(int j = i * i; j <= 1e6; j += i)
                is_prime[j] = 1;
        }
    }
    for(int i = 2; i <= 1e6; i++){
        if(!is_prime[i])
            primes[k++] = i;
    }
}

ll binpow(ll a, ll b){
    ll res = 1;
    a %= mod;
    while(b > 0){
        if(b & 1){
            res = res * a;
        }
        a = a * a;
        b /= 2;
    }
    return res;
}
 
void solve(){
    ll n;
    cin >> n;
    ll cnt_div = 1, sum_div = 1;
    //cout << k << ' ';
    for(int i = 0; i < k && 1LL * primes[i] * primes[i] <= n; i++){
        //cout << primes[i] << ' ';
        if(n % primes[i])
            continue;
        //cout << primes[i] << ' ';
        int cnt = 0;
        while(n % primes[i] == 0){
            n /= primes[i];
            cnt++;
        }
        cnt_div *= (cnt+1);
        sum_div *= (binpow(primes[i], cnt+1)-1)/(primes[i]-1);
        sum_div %= mod;
    }
    if(n != 1){
        cnt_div *= 2;
        sum_div *= (n+1);
        sum_div %= mod;
        //cout << n << '\n';
    }
    cout << cnt_div << ' ' << sum_div << '\n';
}  
 
int main(){
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    sieve();
    cin >> t;
    while(t--){
        solve();
    }
}