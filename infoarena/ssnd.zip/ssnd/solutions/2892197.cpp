#include <bits/stdc++.h>

using namespace std;

const string fisier = "ssnd";

ifstream fin (fisier + ".in");
ofstream fout (fisier + ".out");

const int N_MAX = 1e6 + 5;
const int mod = 9973;

bitset<N_MAX>c;
vector<int>primes;

void precalc(){
  for (int i=4; i<N_MAX; i+=2){
    c[i] = true;
  }
  for (int i=3; i*i<N_MAX; i+=2){
    if (c[i] == 0){
      for (int j=2; j*i<N_MAX; j++){
        c[i * j] = true;
      }
    }
  }
  primes.emplace_back(2);
  for (int i=3; i<N_MAX; i+=2){
    if (c[i] == false){
      primes.emplace_back(i);
    }
  }
}

void test_case() {
  long long x;
  fin >> x;
  long long sum = 1 , nr_div = 1 , d = 0;
  while (x > 1){
   long long p = 0 , s = primes[d];
   while (x % primes[d] == 0){
    p += 1;
    x = x / primes[d];
    s *= primes[d];
   }
   if (p > 0){
    nr_div *= (p + 1);
    nr_div %= mod;
    sum *= ((s - 1) / (primes[d] - 1));
    sum %= mod;
   }
   d += 1;
   if (primes[d] * primes[d] > x && x > 1){
      nr_div = (nr_div * 2) % mod;
      sum = (sum * ((x * x - 1) / (x - 1))) % mod;
      break;
   }
  }
  fout << nr_div << " " << sum << '\n';
}

int main(){
  ios_base::sync_with_stdio(false);
  int tests; fin >> tests;
  precalc();
  for (int tc=0; tc<tests; ++tc) {
    test_case();
  }
}
