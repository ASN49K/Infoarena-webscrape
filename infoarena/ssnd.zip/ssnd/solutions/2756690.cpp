
#include <fstream>

using namespace std;
ifstream cin ("disjoint.in");
ofstream cout ("disjoint.out");
int main() {
    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);
    int n,cnt=0;
    long long d=1,s=0,a;
    cin >> n;
    for(int i=0; i<n; i++) {
        cin >> a;
        cnt=0;
        d=1;
        s=0;
        while(d * d <= a) {
            if(a % d == 0) {
                s = s + d;
                s = s % 9973;
                cnt++;
                if(d * d < a) {
                    s = s + a/d;
                    s = s % 9973;
                    cnt++;
                }
            }
            d++;
        }
        cout<<cnt<<" "<<s<<'\n';
    }
    return 0;
}
