#include <fstream>

using namespace std;

ifstream cin ( "ssnd.in" );
ofstream cout ( "ssnd.out" );

int nrprime[10000];
bool ciur[1000005];

int main() {
  int i, poz, t, pozz_div, p;
  long long d, n, nrdiv, sum, divmax;
  poz = 0;
  for ( i = 2; i < 1000000; i++ ) {
    if ( ciur[i] == 0 ) {
      nrprime[poz++] = i;
      for ( d = (long long)i * i; d < 1000000; d += i )
        ciur[d] = 1;
    }
  }
  cin >> t;
  for ( i = 1; i <= t; i++ ) {
    nrdiv = 1;
    sum = 1;
    cin >> n;
    pozz_div = 0;
    while ( pozz_div < poz && (long long)nrprime[pozz_div] * nrprime[pozz_div] <= n ) {
      d = nrprime[pozz_div];
      p = 0;
      divmax = 1;
      while ( n % d == 0 ) {
        divmax *= d;
        n /= d;
        p++;
      }
      nrdiv = ( nrdiv * ( ( p + 1 ) % 9973 ) ) % 9973;
      sum = sum * ( ( ( divmax * d - 1 ) / ( d - 1 ) ) % 9973 ) % 9973;
      pozz_div++;
    }
    if ( n > 1 ) {
      nrdiv = ( nrdiv * 2 ) % 9773;
      sum = sum * ( ( n * n - 1 ) / ( n - 1 ) % 9973 ) % 9973;
    }
    if ( nrdiv == 1 ) {
      cout << nrdiv << " " << ( n + 1 ) % 9973;
    } else {
      cout << nrdiv << " " << sum;
    }
    cout << "\n";
  }
  return 0;
}
