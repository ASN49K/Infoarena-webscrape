#include <iostream>
#include <vector>
#define MAX 1
using namespace std;
vector<string> sol;

int main()
{
    for(int i = 1; i <= MAX; i++){
        sol.push_back("f");
    }
    return 0;
}
