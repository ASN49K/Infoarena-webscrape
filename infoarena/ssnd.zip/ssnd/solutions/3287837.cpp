#include <iostream>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

const int NMAX=1000000, MOD=9973;

long long v[NMAX+1], p[78500], nrp,nrdiv,sumadiv;

void ciur(int n)
{
    int i,j;
    for(i=3;i*i<=n;i+=2)
    {
        if(v[i]==0)
        {
            for(j=i*i;j<=n;j+=2*i)
                v[j]=1;
        }
    }

    p[1]=2;
    nrp=1;
    for(i=3;i<=n;i+=2)
    {
        if(v[i]==0) p[++nrp]=i;
    }
}

long long exp(long long a, long long b)//a^b
{
    long long val=1;
    while(b)
    {
        if(b%2==1)
        {
            val*=a;
        }
        b/=2;
        a*=a;
    }
    return val;
}

void desc( long long x)
{
    long long i,ex;
    for(i=1;i<=nrp && p[i]*p[i]<=x;i++)
    {
        if(x%p[i]==0)
        {
            ex=0;
            do
            {
                ex++;
                x/=p[i];
            }while(x%p[i]==0);
            nrdiv*=(ex+1);
            sumadiv*= (exp(p[i],ex+1)-1)/(p[i]-1);
            nrdiv%=MOD;
            sumadiv%=MOD;
        }
    }
    if(x>1)
    {
        nrdiv*=2;
        sumadiv*=(x+1);
    }
}

int main()
{
    long long n,i,x;
    ciur(NMAX);
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>x;
        sumadiv=1;
        nrdiv=1;
        desc(x);
        g<<nrdiv%MOD<<' '<<sumadiv%MOD<<'\n';
    }

    f.close();
    g.close();
    return 0;
}
