#define MOD 9973
#define CIUR 1000000

#include <fstream>
#include <bitset>
#include <vector>
#include <utility>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int XlaN(int x, int n);

int InversModular(int a);

void Rezolva(int n);

bitset<CIUR + 1> nonprim;
vector<int> nrprime;

int main()
{
	nonprim[0] = nonprim[1] = true;
	
	for (int i = 1; (i * i) <= CIUR; ++i)
	{
		if (!nonprim[i])
		{
			nrprime.push_back(i);
			
			for (int j = 2; (i * j) <= CIUR; ++j)
			{
				nonprim[i * j] = true;
			}
		}
	}
	
	int t, n;
	
	fin >> t;
	
	for (int i = 1; i <= t; ++i)
	{
		fin >> n;
		
		Rezolva(n);
	}
	
	fin.close();
	fout.close();
	return 0;
}

int XlaN(int x, int n)
{
	if (n == 0)
	{
		return 1;
	}
	
	int P = XlaN(x, n / 2);
	P = (P * P) % MOD;
	
	if ((n % 2) == 0)
	{
		return P;
	}
	else
	{
		return (x * P) % MOD;
	}
}

int InversModular(int a)
{
	return XlaN(a, MOD - 2);
}

int NR, NUMA, NUMI;

void F(int& n, int nrprim)
{
	int exp = 0;
		
	while ((n % nrprim) == 0)
	{
		++exp;
		n /= nrprim;
	}
	
	NR = (NR * (exp + 1)) % MOD;
	
	if (exp > 0)
	{
		int aux = XlaN(nrprim, exp + 1) - 1;
		
		if (aux < 0)
		{
			aux += MOD;
		}
		
		NUMA = (NUMA * aux) % MOD;
		NUMI = (NUMI * (nrprim - 1)) % MOD;
	}
}

void Rezolva(int n)
{
	NR = 1;
	NUMA = 1;
	NUMI = 1;
	
	for (const auto& nrprim : nrprime)
	{
		F(n, nrprim);
	}
	
	if (n != 1)
	{
		F(n, n);
	}
	
	fout << NR << ' ' << ((NUMA * InversModular(NUMI)) % MOD) << '\n';
}
