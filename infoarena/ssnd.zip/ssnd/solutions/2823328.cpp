#include <fstream>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

bool prime[100001];
int t, mod = 9973;

void generareCiur(bool prime[])
{
    prime[2] = 1;
    for(int i = 3; i <= 100001; i+=2)
        prime[i] = 1;
    for(int i = 3; i <= 100001; i+=2)
        if(prime[i])
            for(int j = 2*i; j <= 100001; j += i)
                prime[j] = 0;
}

void descompunereInFactori(long long nr, long long & nrDiv, long long & sumDiv, bool prime[])
{
    nrDiv = sumDiv = 1;
    int d = 2;
    while(nr > 1 && d<100001)
    {
        int p = 0;
        long long put = 1;
        while(nr%d == 0)
        {
            nr /= d;
            put = (put*d) % mod;
            p++;
        }
        if(p)
        {
            nrDiv *= (p+1);
            sumDiv = (sumDiv * ((put*d - 1) / (d-1)) )%mod;
        }
        do
        {
            d++;
        }while(!prime[d] && d*d<=100001);
    }
    if(nr > 1)
    {
        fout << "ok";
        nrDiv *= 2;
        sumDiv = (sumDiv*((nr*nr-1)/(nr-1))) % mod;
    }
}

int main()
{
    generareCiur(prime);
    fin >> t;
    for(int i = 1; i <= t; i++)
    {
        long long nr, sumDiv, nrDiv;
        fin >> nr;
        descompunereInFactori(nr, nrDiv, sumDiv, prime);
        fout << nrDiv << ' ' << sumDiv << '\n';
    }
    return 0;
}
