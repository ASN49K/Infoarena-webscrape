#include <fstream>
#include <bitset>
#include <vector>
#define mod 9973
using namespace std;

ifstream cin ("ssnd.in");
ofstream cout ("ssnd.out");

bitset <500000> verif_prim;
vector <int> prime;

void Ciurul_lui_Eratostene ()
{
    prime.push_back(2);
    for (int indice_1 = 3 ; indice_1 < 100000 ; indice_1 += 2)
        if (!verif_prim[(indice_1 - 1) / 2])
        {
            prime.push_back(indice_1);
            for (int indice_2 = 3 * indice_1 ; indice_2 < 100000 ; indice_2 += 2 * indice_1)
                verif_prim[(indice_2 - 1) / 2] = 1;
        }
}

int main ()
{
    Ciurul_lui_Eratostene ();

    long long lungime , numar;
    cin >> lungime;

    for (int indice = 1 ; indice <= lungime ; indice++)
    {
        cin >> numar;

        long long divizori = 1 , suma = 1 , indice_prime = 0;
        while ((unsigned)indice_prime < prime.size() && 1LL * prime[indice_prime] * prime[indice_prime] <= numar)
        {
            int exponent = 0 , rezultat = prime[indice_prime] % mod;
            while (numar % prime[indice_prime] == 0)
            {
                numar /= prime[indice_prime];
                rezultat = (rezultat * prime[indice_prime]) % mod;
                exponent++;
            }

            divizori = divizori * (exponent + 1) % mod;
            suma = (suma * ((rezultat - 1) / (prime[indice_prime] - 1))) % mod;

            indice_prime++;
        }

        if (numar > 1)
        {
            divizori = 2 * divizori % mod;
            suma = (suma * (numar * numar - 1) / (numar - 1)) % mod;
        }

        cout << divizori << ' ' << suma << '\n';
    }

    cout.close(); cin.close();
    return 0;
}