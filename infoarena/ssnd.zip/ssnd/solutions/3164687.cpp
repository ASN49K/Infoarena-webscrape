#include <iostream>
#include <fstream>
#include <vector>
#define MOD 9973
/*Divizorii unui număr natural n reprezintă mulţimea de numere naturale, mai mici sau egale cu n,
cu proprietatea că divid pe n. Să se determine pentru t numere naturale cardinalul acestei mulţimi
şi restul împărţirii sumei elementelor mulţimii la 9973.*/

std::ifstream fin ("ssnd.in"); //input file
std::ofstream fout ("ssnd.out"); //output file
unsigned long long pr(long long a, long long b) { //functie de exponentiere
    long long thing = 1;
    while (b>0){
        if (b&1) {thing=thing*a;}
        a=a*a;
        b >>=1;
    }
    return thing;
}

unsigned short expo(long long a, int p) { //gaseste puterea unui numar prim din descompunerea in factori (practic logaritm cu baza p de a)
    unsigned short c=0;
    while (a%p==0) {
        a/=p;c++;
    }
    return c;
}

bool SoE[1000001];
std::vector<int> primeList;
void test(){
    for (int i=0;i<=100;i++)
    {
        std::cout << "Test nr " << i << " " << primeList[i] << std::endl;
    }
}
void genList(){
    primeList.push_back(2);
    for (int i=2;(i<<1)<=1000000;i++)
    {
        SoE[i<<1]=1;
    }
    for (int i=3;i<=1000000;i+=2)
    {
        if (!SoE[i]) {
            primeList.push_back(i);
            for (int j=(i<<1);j<=1000000;j+=i)
            {
                SoE[j]=1;
            }
        }
    }
}

int main(){
    genList();
    unsigned short t;
    fin >> t; //get number of iterations
    for (int i=0;i<t;i++)
    {
        unsigned long long n; //initialize current number
        fin >> n; //read current number from file
        unsigned long long countDracula=1,sigma=1; //initialize number of divisors and sum of divisors
        //if (n%2==0) {countDracula*=( expo(n, 2) +1 );sigma*= ( pr(2, expo(n, 2)+1)-1 )%MOD; while(n%2==0){n/=2;} }
        /*for (unsigned long long j=3;j<=n;j+=2)
        {
            if (!SoE[j] && n%j==0) {
                countDracula*=(expo(n, j)+1); //add divisors implied by the prime factor to The Count
                sigma*=( ( pr(j, expo(n, j)+1)-1)/(j-1) ); //sum divisors implied by the prime factor
                sigma%=MOD;
                while (n%j==0){n/=j;} //remove prime factor from number
            }
        }*/
        for (int j=0;primeList[j]<=n;j++)
        {
            if (n%primeList[j]==0) {
                short e=expo(n, primeList[j]);
                countDracula*=(e+1);
                sigma*=(pr(primeList[j], e+1)-1)/(primeList[j]-1);
                sigma%=MOD;
                while (n%primeList[j]==0) {n/=primeList[j];}
            }
        }
        if (n>1000000) { //cazul in care n e prim si mai mare decat 10**6
            countDracula*=2;
            sigma*=(n+1)%MOD;
        }
        fout << countDracula << " " << sigma << std::endl; //write number of divisors and sum of divisors mod 9973 of currrent number
    }
    return 0;
}
