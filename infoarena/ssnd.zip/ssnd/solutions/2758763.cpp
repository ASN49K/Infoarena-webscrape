#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main(){

    long long t, n;
    cin >> t;
    for(int i = 1; i <= t; ++i){
        cin >> n;
        long long cnt = 1, s = 1;
        for(int d = 2; d * d <= n; ++d){
            long long pow = d, p = 1;
            while(n % d == 0)
                n /= d, pow *= d, p++;
            cnt *= p;
            s *= (pow - 1) / (d - 1);
        }
        if(n > 1)
            s *= (n * n - 1) / (n - 1), cnt *= 2;
        cout << cnt << ' ' << s << '\n';
    }

    return 0;
}

/// lowerbound upperbound
/// interclasare in STL
/*
    IMPARTIREA LUI N LA 2 ->  n >> 1

    IMPARTIREA LUI N LA (2 ^ k) ->  n >> k

    INMULTIREA LUI N CU 2 ->  n << 1

    INMULTIREA LUI N CU (2 ^ k) ->  n << k

    RIDICAREA LUI 2 LA PUTEREA N -> 1 << n

    VERIICARE N ESTE NUMAR PAR ->  n % 2 == 0 -> n & 1 == 0   SAU   n % 2 == 1 -> n & 1 == 1

    VERIFICARE N ESTE PUTERE A LUI 2 -> n & (n - 1) == 0 -> n == 2 ^ k   SAU   n & (n - 1) == 1 -> n != 2 ^ k

    CEA MAI MARE PUTERE A LUI 2 CARE ESTE DIVIZOR PT N -> n & -n

    SETAREA BITULUI K IN 1 -> n = n | (1 << k)

    SETAREA BITULUI K IN 0 -> n = n & ~(1 << k)

    INTERSCHIMBAREA A DOUA VALORI -> a = a ^ b
                                     b = a ^ b
                                     a = a ^ b
    a xor a = 0
    a xor 0 = a
    Ne vom folosi de aceasta proprietate si vom calcula
    v[1] ^ 1 ^ v[2] ^ 2 ^ .. v[n - 1] ^ (n - 1) ^ n
    care este valoarea numarului lipsa
*/
