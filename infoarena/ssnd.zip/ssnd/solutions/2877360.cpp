#include <iostream>
#include <bitset>
#include <vector>
#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

const int NMAX = 1e6 + 10;

const int MOD = 9973;

bitset <NMAX> v;

vector<int> Prime;

void ciur(int n)
{
    Prime.push_back(2);
    v[0] = 1;
    for(int i = 3; i <= n; i += 2)
        if(v[i] == 0)
        {
            Prime.push_back(i);
            for(int j = i * 2; j <= n; j += i)
                v[j] = 1;
        }
}

int powlg(int x, int n)
{
    int val = 1;
    while(n > 0)
    {
        if(n & 1)
            val = 1LL * val * x % MOD;
        x = 1LL * x * x % MOD;
        n >>= 1;
    }
    return val;
}

int inversMod(int x)
{
    return powlg(x, MOD - 2) % MOD;
}


int main()
{
    ciur(NMAX);
    int T;
    f >> T;
    while(T--)
    {
        long long ans = 1, nrDiv = 1;
        int n;
        f >> n;
        for(int i : Prime)
            if(i * i > n)break;
            else if(n % i)continue;
            else
            {
                int p = 0;
                while(n % i == 0)
                {
                    n /= i;
                    ++p;
                }

                nrDiv *= p + 1;

                long long x = powlg(i, p + 1) - 1;
                x *= inversMod(i - 1);
                ans = 1LL * ans * x % MOD;
            }
        if(n > 1)
        {
            nrDiv *= 2;

            long long x = powlg(n, 2) - 1;
            x *= inversMod(n - 1);
            ans = 1LL * ans * x % MOD;
        }
        g << nrDiv << ' ' << ans << '\n';
    }
    return 0;
}
