#include <iostream>

#define MOD 9973

long long log_pow(long long base, long long exp)
{
    long long unit = base, prod = 1;

    if (exp == 0)
        return 1;

    if (exp == 1)
        return base;

    for (int e = 1; e <= exp && e != 0; e <<= 1) {
        if (exp & e)
            prod = (prod * unit) % MOD;

        unit = (unit * unit) % MOD;
    }

    return prod;
}

int main()
{
    int n;
    long long a;
    long long cnt, sum;

    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    std::cin >> n;

    for (int i = 0; i < n; ++i) {
        std::cin >> a;

        cnt = 1;
        sum = 1;

        for (long long d = 2, exp; d <= a; ++d) {
            exp = 0;

            while (a % d == 0) {
                a /= d;
                
                ++exp;
            }

            if (exp > 0) {
                cnt = (cnt * (exp + 1)) % MOD;
                sum = (sum * ((log_pow(d, exp + 1) - 1) / (d - 1))) % MOD;
            }
        }

        std::cout << cnt << ' ' << sum << '\n';
    }

    return 0;
}
