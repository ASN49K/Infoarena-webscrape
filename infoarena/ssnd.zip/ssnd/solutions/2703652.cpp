#include <fstream>
#include <bitset>
#include <vector>
#include <cmath>
#define nmax (int) 1e6
#define MOD 9973
using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

int n, x;
bitset <nmax + 1> sieve;
vector <int> v;

void ciur(){
    sieve[1] = sieve[0] = true;
    for(int i = 4; i <= nmax; i += 2){
        sieve[i] = true;
    }
    for(int i = 3; i * i <= nmax; i += 2){
        if(!sieve[i]){
            for(int j = i * i; j <= nmax; j += 2 * i){
                sieve[i] = true;
            }
        }
    }
    v.push_back(2);
    for(int i = 3; i <= nmax; i += 2){
        if(!sieve[i]){
            v.push_back(i);
        }
    }
}

long long sumdiv(long long n){
    ciur();
    long long sum = 1, i = 0;
    while(n > 1){
        int p = 0;
        while(n % v[i] == 0){
            n /= v[i];
            p++;
        }
        if(p){
            sum *= (pow(v[i], p + 1) - 1) / (v[i] - 1);
            sum %= MOD;
        }
        i++;
        if(n > 1 && v[i] * v[i] > n){
            return (sum * (n + 1)) % MOD;
        }
    }
    return sum;
}

long long nrdiv(long long n){
    ciur();
    long long cnt = 1, i = 0;
    while(n > 1){
        int p = 0;
        while(n % v[i] == 0){
            n /= v[i];
            p++;
        }
        if(p){
            cnt *= (p + 1) % MOD;
        }
        i++;
        if(n > 1 && v[i] * v[i] > n){
            return (cnt * 2) % MOD;
        }
    }
    return cnt;
}

int main(){
    cin >> n;
    for(int i = 1; i <= n; ++i){
        cin >> x;
        cout << nrdiv(x) << " " << sumdiv(x) << "\n";
    }
    return 0;
}
