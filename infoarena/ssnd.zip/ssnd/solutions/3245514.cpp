#include <fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int LMAX=1000000;
long long t,n,prime[80001],nrdiv,sumdiv,cop,exp;
bool E[LMAX+1];
int main()
{
    for (int i=2;i*i<=LMAX;i++)
    {
        if (E[i]==0)
        {
            for (int j=i*i; j<=LMAX; j+=i)
            {
                E[j]=1;
            }
        }
    }
    for (int i=2;i<=LMAX; i++)
    {
        if (E[i]==0)
        {
            n++;
            prime[n]=i;
        }
    }
    fin>>t;
    for (int i=1;i<=t;i++)
    {
        fin>>n;
        int j=1;
        nrdiv=1;
        sumdiv=1;
        while (prime[j]*prime[j]<=n)
        {
            cop=n;
            exp=0;
            while (n%prime[j]==0)
            {
                exp++;
                n/=prime[j];
            }
            nrdiv=nrdiv*(exp+1);
            sumdiv*=cop/n;
            sumdiv*=prime[j];
            sumdiv--;
            sumdiv/=(prime[j]-1);
            sumdiv%=9973;
            j++;
        }
        if (n!=1)
        {
            nrdiv*=2;
            sumdiv*=(n*n-1)/(n-1)%9973;
        }
        fout<<nrdiv<<" "<<sumdiv<<endl;
    }
    return 0;
}
