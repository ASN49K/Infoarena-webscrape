#include <fstream>
#include <bitset>
using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
long long i, j, n, m, t, cnt, divi, suma, divizori, d, nr;
bitset<1000002> f;
long long v[1000002];
long long f1(long long nr, long long p){
    if(p==0)
        return 1;
    if(p%2){
        long long n=f1(nr, p/2);
        return n*n*nr;
    }
    else{
        long long n=f1(nr, p/2);
        return n*n;
    }
}
int main() {
    cin>>t;
    for(i=2;i<=1000000;i++){
    if(f[i]==0){
        v[++cnt]=i;
        for(j=i+i;j<=1000000;j+=i)
            f[j]=1;
    }
   }
    while(t--){
        cin>>n;
        d=1;
        divi=v[d];
        suma=divizori=1;
        while(n!=1){
            if(n%divi==0){
                nr=0;
                while(n%divi==0)
                    n/=divi, nr++;
                divizori=divizori*(nr+1);
                suma=(suma*((f1(divi, nr+1)-1)/(divi-1)%9973))%9973;
            }
            d++;
            divi=v[d];
            if(d>cnt || divi*divi>n)
                divi=n;
        }
        cout<<divizori<<" "<<suma<<"\n";
    }

}
