#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream f("ssm.in");
ofstream g("ssm.out");

int main()
{
    int n,i,x,suma=0,sumamax=INT_MIN,finalmax, start, startmax ;
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>x;
        if(suma>=0)
        {
            suma+=x;
        }
        else
        {
            suma=x;
            start=i;
        }

        if(suma>sumamax)
        {
            sumamax=suma;
            startmax=start;
            finalmax=i;
        }

    }

    g<<sumamax<<' '<<startmax<<' '<<finalmax;

    f.close();
    g.close();
    return 0;
}
