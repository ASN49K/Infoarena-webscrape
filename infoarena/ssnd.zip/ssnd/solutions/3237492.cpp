#include<bits/stdc++.h>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long n,m=1e6,j,f,i;
int c[78498],l,e,k;
bitset<1000000> p;
int main()
{
    for(c[k++]=2,i=3;i<m;i+=2)
        if(!p[i])
            for(c[k++]=i,j=i*i;j<m;p[j]=1,j+=2*i);
    for(F>>n;F>>n;G<<e<<' '<<f%9973<<'\n') {
        for(e=f=1,i=0;c[i]*c[i]<=n;++i)
            if(n%c[i]<1) {
                for(j=c[i]*c[i],n/=c[i],l=1;n%c[i]<1;n/=c[i],j*=c[i],++l);
                e*=l,f*=(j-1)/(c[i]-1);
            }
        if(n>1)
            e<<=1,f*=n+1;
    }
    return 0;
}
