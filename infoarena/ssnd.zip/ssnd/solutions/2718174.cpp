#include <bits/stdc++.h>
#define ll long long
#define mod 9973
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

void Rezolva(ll n)
{
    ll s = 1, nr = 1, d = 2;
    while(n > 1)
    {
        ll p = 0, tmp = d;
        while(n % d == 0)
        {
            ++p;
            n /= d;
            tmp *= d;
        }
        if (p)
        {
            nr *= p + 1;
            s *= (tmp - 1)/ (d - 1);
            s %= mod;
        }
        ++d;
        if (n > 1 && d*d > n) d = n;
    }
    fout << nr << " " << s % mod << '\n';
}

int main()
{
    ll t, n;

    fin >> t;
    for (ll i = 1; i <= t; i++)
    {
        fin >> n;
        Rezolva(n);
    }

    fin.close();
    fout.close();
    return 0;
}
