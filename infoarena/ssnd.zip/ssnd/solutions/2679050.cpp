#include <bits/stdc++.h>

using namespace std;
#define MOD 9973

long long  putere[60],di[60],pd[60];
long long  mod,suma,numar;
long long ciur(long long n)
{
    long long i,numar,put,nr=0;
    numar=1;

    put=0;
    while(n%2==0)
    {
        n=n/2;
        numar=numar*2;
        put++;
    }
    if(put)
    {
        di[++nr]=2;
        numar*=2;
        putere[nr]=put%MOD;
        pd[nr]=numar%MOD;
    }
    for(i=3; i<=n; i+=2)
    {
        numar=1;

        put=0;
        while(n%i==0)
        {
            n=n/i;
            numar=numar*i;
            put++;
        }
        if(put)
        {
            di[++nr]=i;
            numar*=i;
            putere[nr]=put;
            pd[nr]=numar;
        }
    }
    return nr;
}
void rez(long long x)
{
    long long p,i;
    mod=1;
    suma=1;
    long long nr= ciur(x);
    for(i=1; i<=nr; i++)
    {
        suma*=(pd[i]-1);        suma/=(di[i]-1);

        suma%=MOD;
        mod*=(putere[i]+1);
        mod%=MOD;
    }

    printf("%lld %lld",mod%MOD,suma%MOD);
    printf("\n");
}
int main()
{
    long long n,a;
    freopen("ssnd.in","r",stdin);
    freopen("ssnd.out","w",stdout);

    scanf("%lld",&n);

    for(; n; n--)
    {
        scanf("%lld",&a);
        rez(a);

    }
    return 0;
}
