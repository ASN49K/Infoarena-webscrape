#include <fstream>
#include <vector>
#define ll long long

using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

const int VALMAX = 1e6;
const int MOD = 9973;
int t;
char c[VALMAX + 1];
vector<ll> prime;

int ProductMOD(int a, int b)
{
    return ((a % MOD) * (b % MOD)) % MOD;
}

int Power(int a, int b)
{
    int rez = 1;
    while(b)
    {
        if(b % 2 == 1)
            rez = (rez * a) % MOD;
        a = (a * a) % MOD;
        b /= 2;
    }
    return rez;
}

void Eratostene()
{
    c[0] = c[1] = 1;
    for(int i = 2; i * i <= VALMAX; i++)
        if(!c[i])
            for(int j = 2; i * j <= VALMAX; j++)
                c[i * j] = 1;
    
    for(int i = 2; i <= VALMAX; i++)
        if(!c[i])
            prime.push_back(i);
}

void test_case()
{
    ll n;
    cin >> n;

    int ind = 0;
    ll d = prime[ind];
    ll nrdiv = 1;
    ll sumdiv = 1;
    while(n > 1)
    {
        int p = 0;
        while(n % d == 0)
            n /= d, p++;

        if(p)
        {
            nrdiv *= (p + 1);
            sumdiv = ProductMOD(sumdiv, ProductMOD(Power(d, p + 1) - 1 + MOD, Power(d - 1, MOD - 2)));
        }

        d = prime[++ind];
        if(d * d > n)
            d = n;
    }

    cout << nrdiv << ' ' << sumdiv << '\n';
}

int main()
{
    Eratostene();

    cin >> t;
    while(t--)
        test_case();

    return 0;
}