#include <bits/stdc++.h>
#define MOD 9973
 
using namespace std;
 
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
 
long long int putere(long long int a, int n) {
    long long int res = 1LL;
    while(n > 0) {
        if(n % 2 == 1) {
            res = (res * a) % MOD;
        }
        a = (a * a) % MOD;
        n /= 2;
    }
    return res;
}
 
int t, K, P[1000005];
long long int n;
bitset<1000005> v;
	
void ciur() {
    for(int i = 2; i < 1000005; i++) {
        if(!v[i]) {
            P[++K] = i;
            for(int j = i + i; j < 1000005; j += i) {
                v[j] = true;
            }
        }
    }
}
 
int main() {
    ciur();
    fin >> t;
    while(t > 0) {
        fin >> n;
        long long int ans1 = 1LL, ans2 = 1LL;
        for(int i = 1; i <= K && 1LL * P[i] * P[i] <= n; i++) {
            if(n % P[i]) {
                continue;
            }
            int p = 0;
            while(n % P[i] == 0) {
                n /= P[i];
                p++;
            }
            ans1 *= (p + 1);
            long long int p1 = (putere(1LL * P[i], p + 1) - 1) % MOD;
            long long int p2 = putere(1LL * P[i] - 1, MOD - 2) % MOD;
            ans2 = (((ans2 * p1) % MOD) * p2) % MOD;
        }
        if(n > 1) {
            ans1 *= 2LL;
            ans2 = (1LL * ans2 * (n + 1) % MOD);
        }
        fout << ans1 <<  " " << ans2 << "\n";
        t--;
    }
    fin.close();
    return 0;
}