#include <bits/stdc++.h>
#define MOD 9973
#define NMAX (int)1e6 + 5
using namespace std;

bitset<NMAX> a;
vector<int> v;

int main()
{
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
    int t;
    cin >> t;
    v.push_back(1);
    for (int i = 2; i < NMAX; i++)
    {
        if (!a[i])
        {
            v.push_back(i);
            for (int j = i + i; j < NMAX; j += i)
                a[j] = 1;
        }
    }
    for (; t; t--)
    {
        int n, nr = 0, s = 0;
        cin >> n;

        for (auto it = v.begin(); (*it) * (*it) <= n; it++)
        {
            if( (*it) * (*it) == n){
                nr++;
                s = (s + *it) % MOD;
                break;
            }
            if(n % (*it) == 0)
            {
                nr+=2;
                s = (s + *it + n/(*it)) % MOD;
            }

        }
        cout<<nr<<' '<<s<<'\n';
    }
    return 0;
}