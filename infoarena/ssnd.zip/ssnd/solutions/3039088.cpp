#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int main()
{
    long long n;
    int t;
    fin>>t;
    for(int i=1;i<=t;++i)
    {
        fin>>n;
        long long nr_div=1, s_div=1;
        long long d=2;
        while(n>1)
        {
            int e=0;
            while(n%d==0)
            {
                ++e;
                n/=d;
            }
            if(e)
            {
                nr_div*=(e+1);
                s_div*=(pow(d, e+1)-1)/(d-1);
            }
            ++d;
            if(n>1 && d*d>n)
                d=n;
        }
        fout<<nr_div<<' '<<s_div<<'\n';
    }
    return 0;
}
