#include <fstream>
#include <algorithm>
#include <bitset>
#define mil 1000000
#define MOD 9973
using namespace std;
using ll = long long;

const string name("ssnd");
ifstream cin(name + ".in");
ofstream cout(name + ".out");

bitset<mil + 5> E;
unsigned int prime[80001], ind;

void ciur(){
    for(int i = 2; i * i <= mil; ++i)
        for(int j = 2; i * j <= mil; ++j)
            E[i * j] = 1;
    prime[++ind] = 2;
    for(int i = 3; i < mil; i += 2)
        if(!E[i])
            prime[++ind] = i;
}

ll put(ll baza, ll putere){
    if(!putere)
        return 1;
    if(putere % 2)
        return put(baza, putere / 2) * put(baza, putere / 2) * baza;
    return put(baza, putere / 2) * put(baza, putere / 2);
}

void rez(ll x){
    ll sum = 1, poz = 1, nrdiv = 1;
    while(x > 1){
        ll p = 0;
        while(x % prime[poz] == 0)
            x /= prime[poz], p++;
        if(p){
            ll nr = put(prime[poz], p + 1);
            sum = (sum * (nr - 1) / (prime[poz] - 1)) % MOD;
            nrdiv *= (p + 1);
        }
        ++poz;
        if(1LL * prime[poz] * prime[poz] > x)
            break;
    }
    if(x > 1){
        nrdiv *= 2;
        sum = 1LL * sum * (x + 1) % MOD;
    }

    cout << nrdiv << ' ' << sum % MOD << '\n';
}

int main(){

    ciur();
    int n;
    cin >> n;
    for(int i = 1; i <= n; ++i){
        ll x;
        cin >> x;
        rez(x);
    }

    return 0;
}
