#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int n,i,j,x,nr,d,s,p,prim[100005],k;
char ciur[1000005];
int main()
{
    fin >>n;
    ciur[0]=1;
    ciur[1]=0;
    for (i=2;i*i<=1000000;i++)
    {
        if (ciur[i]==0)
        {
            k++;
            prim[k]=i;
            for (d=i*i;d<=1000000;d=d+i)
            {
                ciur[d]=1;
            }
        }
    }
    for (i=1;i<=n;i++)
    {
        fin >>x;
        k=1;
        d=prim[k];
        nr=1;
        s=1;
        while(x!=1)
        {
            p=0;
            while (x%d==0)
            {
                p++;
                x=x/d;
            }
            nr=nr*(p+1);
            s=s*(pow(d,p+1)-1)/(d-1);
            s=s%9973;
            k++;
            d=prim[k];
        }
       fout <<nr<<" "<<s%9973<<'\n';
    }
    return 0;
}
