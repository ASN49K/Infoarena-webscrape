#include <iostream>
#include <vector>
#include <fstream>
#define MAX 1000002
#define MOD 9973
using namespace std;
int q;
long long n;
bool c[MAX];
vector<int> prime;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

long long lgput(long long n, long long a){
    if(a == 0){
        return 1;
    }
    if(a%2 == 0){
        long long val = lgput(n, a/2);
        return val*val;
    }else{
        return n*lgput(n, a-1);
    }
}

void solve(){
    fin >> n;
    int i = 0;
    int div = 1, sum = 1;
    while(prime[i]*prime[i] <= n && i < prime.size()){
        if(n%prime[i] == 0){
            int p = 0;
            while(n%prime[i] == 0){
                n /= prime[i];
                p++;
            }
            div *= (p+1);
            sum *= (lgput(prime[i], p+1)-1)/(prime[i]-1);
            sum %= MOD;
        }
        i++;
    }
    if(n > 1){
        div *= 2;
        sum *= (lgput(n, 2)-1)/(n-1);
        sum %= MOD;
    }
    fout << div << " " << sum << "\n";
}

int main()
{
    c[0] = c[1] = 1;
    prime.push_back(2);
    for(int i = 3; i <= 1000; i += 2){
        if(c[i] == 0){
            prime.push_back(i);
            for(int j = i+i; j < MAX; j += i){
                c[j] = 1;
            }
        }
    }
    for(int i = 1003; i < MAX; i += 2){
        if(c[i] == 0){
            prime.push_back(i);
        }
    }
    fin >> q;
    while(q--){
        solve();
    }
    return 0;
}
