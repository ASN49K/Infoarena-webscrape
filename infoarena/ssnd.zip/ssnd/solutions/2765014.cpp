#include <bits/stdc++.h>

using namespace std;

int main()
{
    ifstream fin("ssnd.in");
    ofstream fout("ssnd.out");

    int t;
    long long n;
    fin>>t;

    vector<bool> prim(1000001, true);
    vector<long long> prime;


    for(long long i = 2; i <= 1000000; i++) {
        if (prim[i] == true) {
            prime.push_back(i);
            for(long long j = i*i; j <= 100000; j += i)
                prim[j] = false;
        }
    }

    for (int k = 1; k <= t; k++) {
        long long number = 1, sum = 1, d = 0;

        fin>>n;

        while (n > 1 && prime[d] * prime[d] <= n) {
            long long exp = 0;
            long long p = 1;

            while (n % prime[d] == 0) {
                n /= prime[d];
                p *= prime[d];
                exp++;
            }

            if (exp > 0) {
                number *= exp + 1;
                p *= prime[d];
                sum = sum * (p - 1) / (prime[d] - 1) % 9973;
            }

            d++;
        }

        if (n != 1) {
            number *= 2;
            sum = (sum * (n + 1)) % 9973;
        }

        fout<<number<<' '<<sum<<'\n';
    }

    return 0;
}