#include <iostream>
#include <bits/stdc++.h>
#define VMAX 1000005
#define INF 100000000
#define int long long int
using namespace std;
ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

const int mod = 9973;
//int numere[VMAX];
vector<int> prime;
vector<pair<int,int>> divi;
bool ciur[VMAX];
int rasp;

int bkt(int indic, int rez)
{
    if(indic==divi.size())
        return rez%mod;
    else
    {
        int nr=0,pow_;
        for(int i=0,pow_=1;i<=divi[indic].second;i++,pow_=(pow_*divi[indic].first)%mod)
        {
            nr=(nr+bkt(indic+1,(rez*pow_)%mod))%mod;
        }
        return nr;
    }
}

signed main()
{
    int n,m,i,j,k,t,q,nr,p,suma,maxim,aparitii,candidat,st,dr,mij,i_max,j_max;
    for(i=2;i<VMAX;i++)
    {
        if(ciur[i]==0)
        {
            prime.push_back(i);
            for(j=2;j*i<VMAX;j++)
                ciur[i*j]=1;
        }
    }
    prime.push_back(INF);


    fin>>t;
    while(t--)
    {
        fin>>n;
        for(i=0;prime[i]*prime[i]<=n;i++)
        {
            if(n%prime[i]==0)
            {
                divi.push_back({prime[i],0});
                do{
                    n/=prime[i];
                    divi.back().second++;
                }
                while(n%prime[i]==0);
            }
        }
        if(n!=1)
            divi.push_back({n,1});
        nr=1;
        for(i=0;i<divi.size();i++)
            nr=nr*(divi[i].second+1);
        fout<<nr<<'\n';
        fout<<bkt(0,1)<<'\n';
        divi.clear();
    }




    return 0;
}
