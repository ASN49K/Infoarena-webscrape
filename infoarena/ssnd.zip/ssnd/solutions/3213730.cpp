#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

const int MOD = 9973;

int NrDiv(int n)
{
    int i, cnt = 0;
    for(i = 1; i * i < n; i++)
        if(n % i == 0) cnt += 2;
    if(i * i == n) cnt++;
    return cnt;
}

int Sum(int n)
{
    int i, sum = 0;
    for(i = 1; i * i < n; i++)
        if(n % i == 0)
        {
            sum += i;
            sum %= MOD;
            sum += n / i;
            sum %= MOD;
        }
    if(i * i == n)
        sum += i;
    return sum % MOD;
}

int main()
{
  int n, t;
  fin >> t;
  while(t--)
  {
      fin >> n;
      fout << NrDiv(n) << " " << Sum(n) << "\n";
  }
  return 0;
}
