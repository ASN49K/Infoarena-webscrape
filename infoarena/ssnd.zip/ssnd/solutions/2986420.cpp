#include <fstream>

using namespace std;
const int MOD = 9973;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int factDiv(int d, int p)
{
    long long s = 1;
    while(p--)
    {
        s = s * d + 1;
    }
    return s % MOD;
}

void sdiv(long long n, int &nr, long long &sum)
{
    int p = 0;
    sum = nr = 1;
    if(n % 2 == 0)
    {
        do
        {
            p++;
            n /= 2;
        }
        while(n % 2 == 0);
        nr = nr * (p + 1);
        sum = factDiv(2, p);
    }
    //
    for(int d = 3; 1LL * d * d <= n; d += 2)
    {
        if(n % d == 0)
        {
            p = 0;
            do
            {
                p++;
                n /= d;
            }
            while(n % d == 0);
            nr = nr * (p + 1);
            sum = sum * factDiv(d, p) % MOD;
        }
    }
    if(n > 1)
    {
        nr = nr * 2;
        sum = sum * (n + 1) % MOD;
    }
}

int main()
{
    int t, nr;
    long long n, sum;
    fin >> t;
    while(t--)
    {
        fin >> n;
        sdiv(n, nr, sum);
        fout << nr % MOD << ' ' << sum << '\n';
    }
    fin.close();
    fout.close();
    return 0;
}
