#include <bits/stdc++.h>
#define mod 9973

using namespace std;

ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

const int N = 1e6 + 5;

bool comp[N];
int prime[N];

void Ciur()
{
    prime[++prime[0]] = 2;
    for(long long i = 3; i < N; i += 2) {
        if(comp[i] == false) {
            prime[++prime[0]] = i;
            for(int j = i + i; j < N; j += i) {
                comp[j] = true;
            }
        }
    }
}
long long lgput(long long a, long long b)
{
    long long ans = 1;
    while(b > 0) {
        if(b & 1) {
            ans = (ans * a);
        }
        a = (a * a);
        b >>= 1;
    }
    return ans;
}

int main()
{
    usain_bolt();

    int n;

    Ciur();

    fin >> n;
    for(int i = 1; i <= n; ++i) {
        long long x;

        fin >> x;
        long long divs = 1;
        long long sol = 1;
        for(int j = 1; prime[j] * prime[j] <= x; ++j) {
            long long d = prime[j];
            if(x % d == 0) {
                long long e = 0;
                while(x % d == 0) {
                    x /= d;
                    ++e;
                }
                long long ans = ((lgput(d, e + 1) - 1) / (d - 1));
                sol = (sol * ans) % mod;
                divs *= (e + 1);
            }
        }
        if(x > 1) {
            divs *= 2LL;
            long long ans = (lgput(x, 2LL) - 1) / (x - 1);
            sol = (sol * ans) % mod;
        }
        fout << divs << " " << sol << "\n";
    }
    return 0;
}
