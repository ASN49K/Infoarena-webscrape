#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
#define ll long long
#define mod 9973
#define NMAX 1000006
bool c[1000005];
long long v[1000005];
void ciur()
{
    int x;
    c[1]=c[0]=1;
    for(int i = 2 ; i * i <= NMAX ; ++i)
        for(int j = 2 ; i * j <= NMAX ; ++j)
            c[i*j]=1;
}
void Rezolva(ll n)
{
    ll s = 1, nr = 1, d = v[0], ind = 0;
    while(n > 1)
    {
        ll p = 0, tmp = d;

        while(n % d == 0)
        {
            ++p;
            n /= d;
            tmp *= d;
        }
        if (p)
        {
            nr *= p + 1;
            s *= (tmp - 1)/ (d - 1);
            s %= mod;
        }

        d = v[++ind];
        if (n > 1 && d*d > n) d = n;
    }
    fout << nr << " " << s % mod << '\n';
}
int main()
{
    ll n,x;
    fin>>n;
    ciur();
    for(ll i=1;i<=n;i++)
    {
        fin>>x;
        Rezolva(x);
    }
    return 0;
}
