#include <bits/stdc++.h>
using namespace std;
fstream f("ssnd.in", ios::in), g("ssnd.out", ios::out);
bool v[1000001];
vector<int> primes;
typedef long long ll;
#define MOD 9973
ll fastexp(ll base, ll exp)
{
    ll ans = 1;
    for (ll k = 1; k <= exp; k <<= 1)
    {
        if (k & exp)
            ans = ans * base % MOD;
        base = base * base % MOD;
    }
    return ans;
}
int main()
{
    int q;
    f >> q;
    v[0] = v[1] = 1;
    for (int i = 1; i <= 1000; i++)
        if (!v[i])
            for (int j = i * i; j <= 1000000; j += i)
                v[j] = 1;
    for (int i = 1; i <= 1000000; i++)
        if (!v[i])
        primes.push_back(i);
    while (q--)
    {
        ll x, ans = 1, wer = 1;
        f >> x;
        int d = 0;
        while (x != 1)
        {
            ll p, cur, e = 0;
            p = cur = primes[d];
            if (p * p > x)
            {
                ans = ans * 2 % MOD;
                cur = (x * x % MOD + MOD - 1) % MOD;
                wer = wer * cur % MOD * fastexp(x - 1, MOD - 2) % MOD;
                break;
            }
            while (x % p == 0)
            {
                x /= p;
                cur = cur * p % MOD;
                e++;
            }
            ans = ans * (e + 1) % MOD;
            cur = (cur + MOD - 1) % MOD;
            wer = wer * cur % MOD * fastexp(p - 1, MOD - 2) % MOD;
            d++;
        }
        g << ans << ' ' << wer << '\n';
    }
}
