#include <bits/stdc++.h>
using namespace std;

ifstream f ("ssnd.in");
ofstream g ("ssnd.out");

vector <int> nrPrime;
typedef unsigned long long ULL;

void eratostene()
{
    const int NMAX = 1000001;
    bitset<NMAX/2> erat;
    erat.flip();

    for(int i = 3; i*i < NMAX; i+=2)
        if(erat[i/2])
        {
            for(int j=i*i;j<NMAX;j+=2*i)
                erat[j/2] = 0;
        }

    nrPrime.push_back(2);
    for(int i=3;i<NMAX;i+=2)
        if(erat[i/2] == 1)nrPrime.push_back(i);
}

void divNrSuma(ULL n,int &nr,ULL &sum)
{
    nr = 1;
    sum = 1;
    ULL sumCur,factorCur,p;

    for(int i : nrPrime)
    {
        if(n == 1)break;
        if(n % i == 0)
        {
            sumCur = factorCur = 1;
            p = 0;
            while(n % i == 0)
            {
                p++;
                n /= i;
                factorCur *= 1LL*i;
                sumCur += factorCur;
            }
            nr *= p+1;
            sum *= sumCur;
        }
    }
}

void sol(ULL n)
{
    ULL sum;
    int nr;
    divNrSuma(n,nr,sum);

    g << nr << ' ' << sum << '\n';
}

int main()
{
    eratostene();
    ULL n,x;
    f >> n;
    for(ULL i=1;i<=n;++i)
    {
        f >> x;
        sol(x);
    }
}
