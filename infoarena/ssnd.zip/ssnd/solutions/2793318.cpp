#include <fstream>

using namespace std;
ifstream cin("ssnd.in");
ofstream cout("ssnd.out");
int c[1000001],d[1000001];
long long n,i,f,p,p1,j,x,nr,s,nr1;
int main()
{
    c[1]=1;
    c[0]=1;
    for(i=2;i<=1000000;i++)
        if(c[i]==0)
        {nr++;d[nr]=i;
            for(j=i*i;j<=1000000;j+=i) c[j]=1;
        }
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>x;nr=1;s=1;
        f=1;
        while(d[f]*d[f]<=x)
        {
            p=0;p1=1;
            while(x%d[f]==0)
            {
                p++;
                x/=d[f];
                p1*=d[f];
            }
            if(p!=0)
            {
                nr*=(p+1);
                s*=(((p1*d[f]-1)/(d[f]-1)))%9973;
            }
            f++;
        }
        if(x>1) {nr*=2;s*=(((x*x-1)/(x-1)))%9973;}
        cout<<nr<<' '<<s%9973<<'\n';
    }
    return 0;
}
