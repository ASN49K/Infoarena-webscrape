#include <fstream>
#define M 9973
using namespace std;
ifstream f("ssnd.in");
ofstream g("ssnd.out");
long long fastexp(long long x,long long n)
{
    long long p=1;
    while(n)
    {
        if(n%2==1)
            p=p*x%M;
        x=x*x%M;
        n=n/2;
    }
    return p;
}
long long d[100001];
void ciur()
{
    bool c[1000011];
    d[1]=2;
    int np=1;
    for(int i=3;i<=999999;i=i+2)
        if(c[i]==0)
        {
            np++;
            d[np]=i;
            for(int j=i+i;j<=999999;j=j+i)
                c[j]=1;
        }
}
long long x,s,p,nr;
int n,i,k;
int main()
{
    ciur();
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>x;
        k=1;
        s=p=1;
        while(x>1)
        {
            nr=0;
            while(x%d[k]==0)
            {
                x=x/d[k];
                nr++;
            }
            if(nr>0)
            {
            p=p*(nr+1);
            s=s*((fastexp(d[k],nr+1)-1)/fastexp(d[k]-1,M-2))%M;
            }
            k++;
            if(d[k]*d[k]>x && x>1)
            {
                p=p*2;
                s=s*(x+1)%M;
                x=1;
            }
        }
        g<<p<<" "<<s<<'\n';
    }
    return 0;
}
