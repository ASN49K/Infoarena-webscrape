
#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int n, i, j, nr, mod = 9973;

void divizori(int x){
    int putere, divi=2, nrdiv=1, sumdiv=1;
    while(x!=1){
        putere=0;
        while(x%divi == 0){
            putere++;
            x /= divi;
        }
        nrdiv = nrdiv * (putere+1);
        sumdiv = (int)(sumdiv * ((((int)(pow(divi, putere+1)) % mod) - 1) / (divi - 1))) % mod;
        
        divi++;
    }
    fout<<nrdiv<<" "<<sumdiv<<endl;
}

int main()
{
    fin>>n;
    
    vector<bool> ciur(n+1);
    
    for(i=1;i<=n;++i){
        fin>>nr;
        
        divizori(nr);
    }

    return 0;
}