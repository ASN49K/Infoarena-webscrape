#include <bits/stdc++.h>
#define ll long long 
#define MOD 9973
 
using namespace std;
 
ifstream in("ssnd.in");
ofstream out("ssnd.out");
 
int t; 
ll n;
 
ll fast_pow(ll n, ll p) {
    ll ans = 1;
    int lim = 64 - __builtin_clzll(p);
 
    for (int i = 0; i <= lim; i++) {
        if (p & (1ll << i)) {
            ans = (ans * n) % MOD; 
        }
 
        n = (n * n) % MOD;
    }
 
    return ans; 
}
 
ll inverse(ll n) {
    return fast_pow(n, MOD - 2);
}

template<typename T> 
vector<T> gen_primes(int limit) {
    bitset<1000005> marked; // change accordingly
    vector<T> primes; 
 
    for (int i = 2; i <= limit; i++) {
        if (!marked[i]) {
            primes.push_back(i);
 
            for (int j = i + i; j <= limit; j += i) {
                marked[j] = 1;
            }
        }
    }
 
    return primes;
}

template<typename T, typename U> 
vector<pair<T, int> > decompose(T n, const vector<U> &primes) {
    vector<pair<T, int> > ans;
    
    for (auto i : primes) {
        if (1ll * i * i > n) {
            break;
        }
 
        if (n % i) {
            continue;
        }
 
        int count = 0;
        while (n % i == 0) {
            count++;
            n /= i;
        }
 
        ans.push_back({i, count});
    }
 
    if (n > 1) {
        ans.push_back({n, 1ll});
    }
 
    return ans;
}

template<typename T>
void factorize(const vector<pair<T, int> > &decomposition, vector<T> &factors, T factor, int pos) {
    if (pos == (int) decomposition.size()) {
        factors.push_back(factor);
        return;
    }
 
    for (int i = 0; i <= decomposition[pos].second; i++) {
        factorize(decomposition, factors, factor, pos + 1);
        factor *= decomposition[pos].first;
    }
}
 
void solve(const vector<int> &primes) {
    in >> n;
 
    ll div_sum = 1, div_count = 1;
    auto decomp = decompose<ll, int>(n, primes);
 
    for (auto it : decomp) {
        ll div = it.first, div_pow = it.second;
        div = div % MOD; 
 
        div_count = div_count * (div_pow + 1) % MOD;
 
        div_sum = (div_sum * (fast_pow(div, div_pow + 1) - 1)) % MOD;
        div_sum = (div_sum * inverse(div - 1)) % MOD;
    }
 
    out << div_count << ' ' << div_sum << '\n';
}
 
int main() {
    auto primes = gen_primes<int>(1000000);
 
    in >> t;
    while (t--) {
        solve(primes);
    }
 
    return 0;
}