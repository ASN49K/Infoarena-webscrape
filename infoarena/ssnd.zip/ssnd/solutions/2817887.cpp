#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e6,MOD = 9973;
bool f[NMAX + 5];
vector <int> primes;
long long ans;

void ciur() {
    f[0] = f[1] = 1;
    for (int i = 4;i <= NMAX;i += 2)
        f[i] = 1;
    primes.push_back(2);
    for (int i = 3;i <= NMAX;i += 2) {
        if (!f[i]) {
            primes.push_back(i);
            for (int j = 3 * i;j <= NMAX;j += 2 * i)
                f[j] = 1;
        }
    }
}
long long put(long long base, int exp) {
    ans = 1;
    while (exp) {
        if (exp % 2)
            ans = ans * base % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return ans;
}
long long invmod(long long x) {
    return put(x, MOD - 2);
}
int main()
{
    ifstream fin("ssnd.in");
    ofstream fout("ssnd.out");
    long long t,n,m,ind,cnt,nrdiv,sdiv;
    ciur();
    m = primes.size();
    fin >> t;
    while (t--) {
        fin >> n;
        ind = 0;
        nrdiv = 1;
        sdiv = 1;
        cnt = 0;
        while (primes[ind] * primes[ind] <= n) {
            while (n % primes[ind] == 0) {
                cnt++;
                n /= primes[ind];
            }
            nrdiv = nrdiv * (cnt + 1) % MOD;
            if (cnt)
                sdiv = sdiv * (put(primes[ind], cnt + 1) - 1) % MOD * invmod(primes[ind] - 1) % MOD;
            cnt = 0;
            ind++;
        }
        if (n != 1) {
            nrdiv = nrdiv * 2 % MOD;
            sdiv = sdiv * (put(n, 2) - 1) % MOD * invmod(n - 1) % MOD;
        }
        fout << nrdiv << " " << sdiv << '\n';
    }
    return 0;
}
