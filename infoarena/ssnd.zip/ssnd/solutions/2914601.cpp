#include <fstream>
#define MOD 9973
using namespace std;
ifstream cin ("ssnd.in");
ofstream cout ("ssnd.out");
int NrDiv(long long n)
{
    int d=2,p,r=1;
    while(n>1)
    {
        p=0;
        while(!(n%d))n/=d,p++;
        r*=(p+1);
        ++d;
        if(d*d>n) d=n;
    }
    return r;
}
int SumDiv(long long n)
{
    int d=2,p,r=1;
    while(n>1)
    {
        p=d;
        while(!(n%d)) n/=d,p*=d;
        r*=(p-1)/(d-1);
        ++d;
        if(d*d>n) d=n;
    }
    return r;
}
int main()
{
     int n;
     long long x;
     cin>>n;
     while(n--){

        cin>>x;
        cout<<NrDiv(x)<<" "<<SumDiv(x)%MOD<<'\n';
     }
}
