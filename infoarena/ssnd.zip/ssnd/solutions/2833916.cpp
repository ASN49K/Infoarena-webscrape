#include<bits/stdc++.h>
#define all(v) v.begin(), v.end()
#define lsb(x) ((x) & (-x))
#define hmap unordered_map
#define var auto &
#define hset unordered_set
#define pq priority_queue
#define exists(x, v) (v.find(x) != v.end())
#define inrange(x, a, b) (x >= a && x <= b)
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long int ull;
typedef pair<int, int> p32;
typedef pair<ll, ll> p64;
typedef pair<double, double> pdd;
typedef pair<ull, ull> p64_u;
typedef vector<int> v32;
typedef vector<ll> v64;
typedef vector<double> v64_d;
typedef vector<ull> v64_u;
typedef vector<p32> vp32;
typedef vector<p64> vp64;
typedef vector<p64_u> vp64_u;
typedef vector<pdd> vpdd;
typedef vector<string> vstr;
typedef vector<vector<int>>  vv32;
typedef vector<v64> vv64;
#define sim template < class c
#define ris return * this
#define dor > debug & operator <<
#define eni(x) sim > typename \
  enable_if<sizeof dud<c>(0) x 1, debug&>::type operator<<(c i) {

/*sim > struct rge { c b, e; };
sim > rge<c> range(c i, c j) { return rge<c>{i, j}; }
sim > auto dud(c* x) -> decltype(cerr << *x, 0);
sim > char dud(...);*/

#define sim template < class c
#define ris return * this
#define dor > debug & operator <<
#define eni(x) sim > typename \
  enable_if<sizeof dud<c>(0) x 1, debug&>::type operator<<(c i) {
sim > struct rge { c b, e; };
sim > rge<c> range(c i, c j) { return rge<c>{i, j}; }
sim > auto dud(c* x) -> decltype(cerr << *x, 0);
sim > char dud(...);
struct debug {
#ifdef HOME
    ~debug() { cerr << endl; }
    eni(!= ) cerr << boolalpha << i; ris;
}
eni(== ) ris << range(begin(i), end(i));
}
sim, class b dor(pair < b, c > d) {
    ris << "(" << d.first << ", " << d.second << ")";
}
sim dor(rge<c> d) {
    *this << "[";
    for (auto it = d.b; it != d.e; ++it)
        *this << ", " + 2 * (it == d.b) << *it;
    ris << "]";
}
#else
    sim dor(const c&) { ris; }
#endif
};
#define imie(...) " [" << #__VA_ARGS__ ": " << (__VA_ARGS__) << "] "
const ll mod = 9973;
vector<ll> prime;

const ll maxciur=1e6+5;
bitset<maxciur> c;
void ciur() {
    int i, j, nr = 1;
    for (i = 1; ((i * i) << 1) + (i << 1) <= maxciur; i += 1) {
        if (c[i] == 0) {
            for (j = ((i * i) << 1) + (i << 1); (j << 1) + 1 <= maxciur; j += (i << 1) + 1) {
                c[j] = 1;
            }
        }
    }
    prime.push_back(2);
    for (i = 1; 2 * i + 1 <= maxciur; ++i)
        if (c[i] == 0) prime.push_back(2 * i + 1);
}



template <typename T>
T mbpow(T a, T n, T m)
{
  T p = 1;
  while (n)
  {
    if (n & 1)
      p = (p % m * a % m) % m;
    a = (a % m * a % m) % m;
    n >>= 1;
  }
  return p;
}
int fermat(int x, int m)
{
    return mbpow(x, m - 2, m);
}


int main()
{
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int t; cin >> t;
    ciur();
    while (t--)
    {
        ll x;
        ll nrd = 1;
        ll sd = 1;
        cin >> x;
        ll i = 0;
        debug() << imie(prime[0]) imie(prime[1]);
        while (x > 1)
        {
            ll cnt = 0;
            while (x % prime[i] == 0)
                x /= prime[i], cnt++;
            if (cnt)
            {
                nrd = nrd * (cnt + 1) % mod;
                sd *= (mbpow(prime[i], cnt + 1,mod)-1) * fermat(prime[i] - 1,mod) % mod;
            }
            i++;

        }
        cout << nrd << " " << sd << '\n';

    }

    return 0;
}


