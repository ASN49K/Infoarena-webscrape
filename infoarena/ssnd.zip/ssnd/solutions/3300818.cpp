#include <fstream>
#include <bitset>
#include <vector>
#include <cmath>

using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

const int CIURMAX = 1000000;
const int MOD = 9973;

bitset<CIURMAX + 1> prim;
vector<int> prime;

void ciur() {
    prim.set();
    prim[0] = prim[1] = 0;
    prime.push_back(2);
    for (int i = 4 ; i <= CIURMAX ; i += 2) {
        prim[i] = 0;
    }
    for (int i = 3 ; i * i <= CIURMAX ; i += 2) {
        if (prim[i]) {
            prime.push_back(i);
            for (int j = i * i ; j <= CIURMAX ; j += i) {
                prim[j] = 0;
            }
        }
    }
}

long long nr_div, suma_div;

void descompunere(long long n) {
    long long d = 0, p = 0;
    nr_div = 1;
    suma_div = 1;
    while (d < (int)prime.size() && 1LL * prime[d] * prime[d] <= n) {
        while (n % prime[d] == 0) {
            n /= prime[d];
            p++;
        }
        if (p) {
            nr_div = nr_div * (p + 1);
            suma_div = (suma_div * ((int)((pow(prime[d], p + 1) - 1) / (prime[d] - 1)) % MOD)) % MOD;
        }
        p = 0;
        d++;
    }
    if (n > 1) {
        nr_div = nr_div * 2;
        suma_div = (suma_div * ((int)((pow(n, 2) - 1) / (n - 1)) % MOD)) % MOD;
    }
}

int main() {
    ciur();
    int t;
    cin >> t;
    while (t--) {
        long long n;
        cin >> n;
        descompunere(n);
        cout << nr_div << " " << suma_div << "\n";
    }
    return 0;
}
