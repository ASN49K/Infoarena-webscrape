#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

const int RAD = 1e6;
const int MOD = 9973;

vector <int> prime, inv(MOD);

int putere(int a, int n)
{
    int p = 1;
    while (n != 0)
    {
        if (n % 2 != 0)
        {
            p = p * a % MOD;
        }
        a = a * a % MOD;
        n /= 2;
    }
    return p;
}

int invers(int a)
{
    return putere(a, MOD - 2);
}

void precalcul()
{
    ///ciurul
    bitset <1+RAD> c;
    for (int i = 2; i * i <= RAD; i++)
    {
        if (!c[i])
        {
            for (int mult = i * i; mult <= RAD; mult += i)
            {
                c[mult] = 1;
            }
        }
    }
    for (int i = 2; i <= RAD; i++)
    {
        if (!c[i])
        {
            prime.push_back(i);
        }
    }
    for (int i = 1; i < MOD; i++)
    {
        inv[i] = invers(i);
    }
}

void ssnd(long long n, long long &nrd, int &sd)
{
    nrd = sd = 1;
    int i = 0;
    while (i < (int)prime.size() && (long long)prime[i] * prime[i] <= n)
    {
        if (n % prime[i] == 0)
        {
            long long p = 1;
            int e = 0;
            while (n % prime[i] == 0)
            {
                e++;
                p = p * prime[i] % MOD;
                n /= prime[i];
            }
            p = p * prime[i] % MOD;
            nrd *= (e + 1);
            sd = sd * (p + MOD - 1) % MOD * inv[(prime[i] + MOD - 1) % MOD] % MOD;
        }
        i++;
    }
    if (n != 1)
    {
        nrd *= 2;
        sd = sd * ((n + 1) % MOD) % MOD;
    }
}

int main()
{
    precalcul();
    ifstream in("ssnd.in");
    ofstream out("ssnd.out");
    int t;
    in >> t;
    for (int i = 0; i < t; i++)
    {
        long long n;
        in >> n;
        long long nrd;
        int sd;
        ssnd(n, nrd, sd);
        out << nrd << " " << sd << "\n";
    }
    in.close();
    out.close();
    return 0;
}
