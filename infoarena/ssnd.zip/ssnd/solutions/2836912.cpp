#include <algorithm>
#include <fstream>
#include <queue>
#define MOD 9973
using namespace std;
 
ifstream cin( "ssnd.in" );
ofstream cout( "ssnd.out" );

int val[ 78500 ];

static inline long long mod( const long long& a ) {
	return ( a <= MOD ? a % MOD : a );
}

void eratostene(  ) {
	bool *ciur = new bool[ 500002 ]();
	{
		int I;
		for( int i = 3; i * i <= 1000000; i += 2 )
			if( !ciur[ i >> 1 ] ) {
				I = 2 * i;
				for( int j = i * i; j <= 1000000; j += I )
					ciur[ j >> 1 ] = 1;
			}
	}

	{
		val[ 0 ] = 2;
		int pp = 1;
		for( int i = 3; i <= 1000000; i += 2 )
			if( !ciur[ i >> 1 ] )
				val[ pp++ ] = i;
		//printf( "%d\n", pp );
	}

	delete[] ciur;
}

int main()
{
	int q;
	long long x;

	{eratostene();}

	cin >> q;
	int kk, p;
	long long b, rez;
	while( q-- ) {
		cin >> x;
		kk = 1;
		rez = 1;
		for( int i = 0; ( long long )val[ i ] * val[ i ] <= x; i++ )
			if( x % val[ i ] == 0 )	{
				p = 0;
				b = val[ i ];
				while( x % val[ i ] == 0 ) {
					x /= val[ i ], p++;
					b *= val[ i ];
				}

				{
					--b;
					kk *= ( p + 1 );
					b /= ( val[ i ] - 1 );
					rez *= mod( b );
					rez = mod( rez );
				}
			}

		if( x > 1 ) {
			kk <<= 1;
			b = x * x;
			{
				--b;
				b /= ( x - 1 );
				rez *= mod( b );
				rez = mod( rez );
			}
		}

		cout << kk << ' ' << rez << '\n';
	}
 	return 0;
}