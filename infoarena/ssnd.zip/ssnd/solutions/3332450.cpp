#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const int NMAX=100001,VMAX=1000001;
bool prime[VMAX];
int nr_prime[NMAX];
int contor_prime=0;
const int mod=997;
///nr prime -> 0 si nr compuse le notam cu 1
void ciur(int n)
{
    for(int i=2;i*i<=n;i++)
    {
        if(prime[i]==0)
        {
            for(int j=i*i;j<=n;j+=i)
            {
                prime[j]=1;
            }
        }
    }
    ///am calculat toate numerele prime
    for(int i=2;i<=n;i++)
    {
        if(prime[i]==0)
        {
            nr_prime[++contor_prime]=i;
        }
    }
}
int main()
{
    ciur(VMAX-1);
    int t;
    fin>>t;
    while(t--)
    {
        long long n;
        fin>>n;
        long long sum_div=1;
        long long nr_div=1;
        for(int i=1;1LL*nr_prime[i]*nr_prime[i]<=n;i++)
        {
            if(n%nr_prime[i]==0)
            {
                int exp=0;
                long long pk=1;
                while(n%nr_prime[i]==0)
                {
                    n/=nr_prime[i];
                    exp++;
                    pk*=nr_prime[i];
                }
                ///pk=nr_prime[i]^k
                nr_div*=(exp+1);
                sum_div=sum_div*(pk*nr_prime[i]-1)/(nr_prime[i]-1)%mod;
            }
        }
        if(n>1)
        {
            ///mai exista un factor prim
            nr_div*=2;
            sum_div=sum_div*(n+1)%mod;
        }
        fout<<nr_div<<" "<<sum_div<<endl;
    }
}
