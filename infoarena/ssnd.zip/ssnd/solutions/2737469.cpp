#include <bits/stdc++.h>
#define MOD 9973
#define NMAX (int)1e6 + 5
#define ull unsigned long long
using namespace std;

bitset<NMAX> a;
vector<int> v;

int main()
{
	freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);
    int t;
    cin >> t;
    v.push_back(1);
    for (int i = 2; i < NMAX; i++)
    {
        if (!a[i])
        {
            v.push_back(i);
            for (int j = i + i; j < NMAX; j += i)
                a[j] = 1;
        }
    }
    for (; t; t--)
    {
        ull n, nr = 0, s = 0;
        cin >> n;

        for (auto it = v.begin(); 1LL * (*it) * (*it) <= n; it++)
        {
            if( 1LL * (*it) * (*it) == n){
                nr++;
                s =  (1LL *(s + *it) ) % MOD;
                break;
            }
            if(n % (*it) == 0)
            {
                nr+=2;
                s = ( 1LL *(s + *it + n/(*it))) % MOD;
            }

        }
        cout<<nr<<' '<<s<<'\n';
    }
    return 0;
}