#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int t, a[1000005], prim[1000005], ind;
unsigned long long n;

unsigned long long putere(int n, int p)
{
    if(p == 0)
        return 1;
    else
    {
        if(p % 2 == 0)
            return putere((n * n) % 9973, p / 2) % 9973;
        else
            return n * putere((n * n) % 9973, (p - 1) / 2) % 9973;
    }
}

int main()
{
    fin >> t;
    for(int i = 2; i * i <= 1000000; ++i)
        for(int j = 2; j <= 1000000 / i; ++j)
            a[i * j] = 1;
    for(int i = 2; i <= 1000000; ++i)
        if(a[i] == 0)
            prim[++ind] = i;
    while(t)
    {
        fin >> n;
        if(a[n] == 0)
            fout << 2 << ' ' << 1 + n << '\n';
        else
        {
            int cnt = 1, i = 1;
            unsigned long long s = 1;
            while(n > 1)
            {
                int p = 0;
                if(n % prim[i] == 0)
                {
                    while(n % prim[i] == 0)
                        n /= prim[i], p++;
                    cnt *= (p + 1);
                    if(p)
                        s *= ((putere(prim[i], p + 1) - 1) / (prim[i] - 1)) % 9973;
                }
                i++;
            }
                fout << cnt << ' ' << s % 9973 << '\n';
        }
        t--;
    }
    return 0;
}
