#include <iostream>
#include <fstream>
using namespace std;
#define sau ||

int a[1000];

int main(void){
    int n, x, suma, card;
    ofstream cout("ssnd.out");
    ifstream cin("ssnd.in");
    cin >> n;
    for(int i =0;i<n;i++){
        cin >> x;
        suma = 1+x;
        card = 2;
        int j;
        for(j = 2; j*j < x; j++){
            if(x % j == 0){
                ++card;
                suma += j;
                if(j != x/j){
                  card++;
                  suma += x/j;
                }
            }
        }
        cout << card << " " << suma << endl;
    }
}
