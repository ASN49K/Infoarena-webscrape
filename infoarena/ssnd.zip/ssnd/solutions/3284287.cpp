#include <fstream>

using namespace std;
const int MOD = 9973;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int powlg(int n, int p)
{
    int val = 1, x = n % MOD;
    while(p)
    {
        if(p & 1)
            val = val * x % MOD;
        x = x * x % MOD;
        p >>= 1;
    }
    return val;
}

inline int inv_mod(int a)
{
    return powlg(a, MOD - 2);
}

void sdiv(long long n, int &nr, int &sum)
{
    int p = 1;
    sum = nr = 1;
    if(n % 2 == 0)
    {
        do
        {
            p++;
            n /= 2;
        }
        while(n % 2 == 0);
        nr = p;
        sum = powlg(2, p) - 1;
    }
    //
    for(int d = 3; 1LL * d * d <= n; d += 2)
    {
        if(n % d == 0)
        {
            p = 1;
            do
            {
                p++;
                n /= d;
            }
            while(n % d == 0);
            nr = nr * p % MOD;
            sum = 1LL * sum * (powlg(d, p) - 1) % MOD * inv_mod(d - 1) % MOD;
        }
    }
    if(n > 1)
    {
        nr = nr * 2 % MOD;
        sum = 1LL * sum * (n + 1) % MOD;
    }
}

int main()
{
    int t, nr, sum;
    long long n;
    fin >> t;
    while(t--)
    {
        fin >> n;
        sdiv(n, nr, sum);
        fout << nr << ' ' << sum << '\n';
    }
    return 0;
}
