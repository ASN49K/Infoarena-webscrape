#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
int t;
long long n, nr_div, sum;
const int MOD = 9973;

void descompune(){
    int div = 2;
    nr_div = 1, sum = 1;
    while (n > 1) {
        int p = 0;
        while (n % div == 0) {
            n /= div;
            ++p;
        }
        if (p > 0) {
            nr_div = nr_div * (p + 1) % MOD;
            sum *= pow(div, p + 1) / (div - 1);
        }
        if (div == 2)
            --div;
        div += 2;
    }
    return;
}

int main() {
    fin >> t;
    while (t--) {
        fin >> n;
        descompune();
        fout << nr_div << " " << sum << "\n";
    }
    return 0;
}
