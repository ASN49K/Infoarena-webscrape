#include <bits/stdc++.h>

using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

#define INF 10000000
#define MOD 9973
int n;
#define MAX 100000
vector<int> fprime;
vector<int> prime(100005, 0);


void ciur() {

    fprime.push_back(-1);

    for (int i = 2; i < MAX; i++) {
        if (prime[i]==0) {
            fprime.push_back(i);
           
            for (int j = i+i; j  < MAX; j += i) {
                prime[j] = 1;
            }
        }
    }

}






void solve() {
    int k = 0;

    int a;
    fin >> a;

    int div = 1;
   // cout << fprime[div] << ' ';
    vector<pair<int, int>> divi(10000);
    while (a > 1) {
        int exp=0;
        while (a % fprime[div] == 0) {
            a /= fprime[div];
            exp++;
        }
        if (exp != 0) {
            divi[++k] = { fprime[div],exp };

        }
        div++;

    }

    int nr_div = 1;
    int suma_div= 1;

    for(int i=1;i<=k;i++){
       // cout << divi[i].first << ' ' << divi[i].second << '\n';
        nr_div =( nr_div%MOD* (divi[i].second + 1)%MOD)%MOD; 
        int aux = (pow(divi[i].first, divi[i].second + 1) - 1) / (divi[i].first - 1);
        suma_div = (suma_div%MOD * aux%MOD)%MOD;

    }

    fout << nr_div << ' ' << suma_div<<'\n';
}





int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    ciur();
    
    /*for (auto i : fprime) {
        cout << i << ' ';
    }*/

    int T;
    fin >> T;
    while (T--) {
        solve();
    }

   // solve();


    fin.close();
    fout.close();

}
