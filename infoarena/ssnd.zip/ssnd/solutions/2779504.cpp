#include <iostream>
#include <fstream>

using namespace std;

ifstream in("ssnd.in");
ofstream out("ssnd.out");

int z, d, sum, x, nr;

int divNrSum(int n)
{
    sum = 0;
    nr = 0;
    for(d = 1; d * d <= n; d++)
    {
        if(n % d == 0)
        {
            sum += d, nr ++;

            if(d * d < n)
                sum += n / d, nr ++;
        }
    }
    out<<nr<<" "<<sum<<endl;;
}

int main()
{
    int v[1001];
    in >> z;


    for(int i = 1; i<=z; i++)
        in >> v[i];

    for(int i = 1; i<=z; i++)
        divNrSum(v[i]);


    return 0;
}
