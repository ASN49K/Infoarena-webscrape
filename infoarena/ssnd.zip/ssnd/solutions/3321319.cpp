#include <bits/stdc++.h>

#define MOD 9973
using namespace std;
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int power(int a , int b)
{
    if(b==0)return 1;

    int x=power(a , b/2)%MOD;

    if(b%2==0)return (x*x)%MOD;
    return ((x*x)%MOD*a)%MOD;
}

vector<int> v;
int t,n,ciur[1000005],ans,ans2;
int main()
{
    ciur[0]=1;
    ciur[1]=1;
    for(int i=1;i<=1000000;i++)
        if(ciur[i]==0)
    {
        v.push_back(i);
        for(int j=i+i;j<=1000000;j++)
            ciur[j]=1;
    }

    fin>>t;
    for(int h=1;h<=t;h++)
    {
        fin>>n;

        int it=0;
        int imp=v[it];
        ans=1;
        ans2=1;
        while(n!=1)
        {
            int nr=0;
            while(n%imp==0)
                {n/=imp;nr++;}
            ans*=(nr+1);
            ans2*= (((power(imp , nr+1)-1)*power(imp-1 , MOD-2)))%MOD;

            imp=v[++it];
            if(imp*imp>n)imp=n;
        }
        fout<<ans<<' '<<ans2<<'\n';
    }
    return 0;
}
