#pragma GCC optimize("O2, unroll-loops")
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ull unsigned long long
#define ld long double
#define vi vector<int>
#define vll vector<ll>
#define vs vector<string>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define vvi vector<vector<int>>
#define vvll vector<vector<ll>>

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define FOR(i, a, b) for(int i = (a); i < (b); i ++)
#define RFOR(i, a, b) for(int i = (a); i > (b); i --)

const int MOD = 9973;

void fastIO(char input[50], char output[50])
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    if(input != "std") {
        freopen(input, "r", stdin);
    }
    if(output != "std") {
        freopen(output, "w", stdout);
    }
}

int main()
{
    // fastIO("std", "std");
    fastIO("ssnd.in", "ssnd.out");
    
    int t;
    cin >> t;
    
    FOR(i, 0, t) {
        ll n;
        cin >> n;
        int cnt = 0, sum = 0;
        int rad = floor(sqrt(n)) + 1;
        FOR(j, 1, rad) {
            if(n % j == 0) {
                ++cnt;
                sum = (sum + j) % MOD;
                if(j != n/j) {
                    ++cnt;
                    sum = (sum + n/j) % MOD;
                }
            }
        }
        cout << cnt << ' ' << sum << '\n';
    }
    
    
    return 0;
}
