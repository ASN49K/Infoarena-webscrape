/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream f("ssnd.in");
    ofstream g("ssnd.out");
    int t,nr;
    long long int n,s,i;
    
    f>>t;
   while(f>>n){s=0;nr=0;
       for(i=1;i<=n;++i){
           if(n%i==0){
               nr++; s=s+i;
           }
       }
       g<<nr<<" "<<s<<endl;
   }
    f.close();
    g.close();
}
