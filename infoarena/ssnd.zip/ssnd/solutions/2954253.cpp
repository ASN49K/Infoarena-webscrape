#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
long long u,n,z,o=9973,t,k,i,j;
int p[78498];
bool r[1000000];
int main()
{
    for(p[k++]=2,i=3;i<1e6;i+=2)
        if(!r[i])
            for(p[k++]=i,j=i*i;j<1e6;r[j]=1,j+=2*i);
    for(F>>t;t--;G<<u<<' '<<z%o<<'\n') {
        for(F>>n,u=z=1,i=0;p[i]*p[i]<=n;++i)
            if(n%p[i]==0) {
                for(k=1,j=p[i];n%p[i]==0;n/=p[i],j*=p[i],++k);
                u*=k,z*=((j-1)/(p[i]-1))%o;
            }
        if(n>1)
            u*=2,z*=(n+1)%o;
    }
    return 0;
}
