/// patratele
#include <bits/stdc++.h>
using namespace std;

#define MOD 9973

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int i, t, v[1000006], j, n, q[1000010], vf, d, f[1000010];
long long ras,nrdiv;

long long rid(long long x, int put)
{
  long long ras = 1;
  while (put)
  {
    if (put % 2 == 1)
      ras = x * ras % MOD;
    x = x * x % MOD;
    put /= 2;
  }
  return ras;
}

int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  fin >> t;
  for (i = 2; i <= 1e6; i += 2)
    v[i] = 1;
  q[++vf] = 2;
  for (i = 3; i <= 1e6 + 1; i += 2)
  {
    if (v[i] == 0)
    {
      q[++vf] = i;
      for (j = i * 2; j <= 1e6 + 1; j += i)
        v[j] = 1;
    }
  }
  while (t--)
  {
    fin >> n;
    nrdiv=1;
    ras=1;
    d = 1;
    while (n>1 && d<=vf)
    {
      while (n % q[d] == 0)
      {
        f[d]++;
        n = n/q[d];
      }
      d++;
    }
    if(n!=1)
      {
        ras+=n;
        nrdiv*=2;
      }
    for (i = 1; i <= vf; i++)
    {
      if (f[i])
      {
        nrdiv *= f[i] + 1;
        ras = ((rid(q[i], f[i] + 1) - 1 + MOD)%MOD) * rid(q[i] - 1, MOD - 2)%MOD*ras%MOD;
      }
    }
    fout << nrdiv<<" "<<ras<<'\n';
    nrdiv=0;
    memset(f, 0, sizeof(f));
  }
  return 0;
}
