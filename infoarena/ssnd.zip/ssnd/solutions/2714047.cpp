///#include <iostream>
#include <fstream>
#include <deque>
const long long SIZEN = 1e12+10,
                MOD = 9973;

using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

typedef long long ll;

int prime[80000], primeSize;

bool isPrim(int n)
{
    if(n<2) return 0;
    if(n==2) return 1;
    for(int i=0; prime[i]*prime[i]<=n; i++)
        if(n%prime[i]==0)
            return 0;
    return 1;
}

void prep()
{
    prime[primeSize++]=2;
    for(ll i=3; 1LL*prime[primeSize-1]*prime[primeSize-1]<=SIZEN; i+=2)
        if(isPrim(i)) prime[primeSize++]=i;
}

int poww(int a, int b)
{
    if(!b) return 1;
    if(b==1) return a%MOD;
    ll x = poww(a, b/2);
    if(b%2) return (((x*x)%MOD)*a)%MOD;
    return (x*x)%MOD;
}

int inv(int a) {return poww(a, MOD-2);}

void getDiv(ll n, ll &nr, ll &sum)
{
    ll p1, p2;
    sum=1, nr=1;
    for(int d=0; prime[d]*prime[d]<=n; d++)
    {
        for(p1=0, p2=1; n%prime[d]==0; n/=prime[d])
            p1++, p2*=prime[d]%MOD;
        p2=(p2*prime[d]-1)%MOD;
        if(p1)
            nr=(nr*(p1+1))%MOD,
            sum*=(p2*inv(prime[d]-1))%MOD;
    }
    if(n>1)
        nr=(nr*2)%MOD, sum=(sum*(n*n-1)%MOD*inv(n-1))%MOD;
}

int main()
{
    prep();
    ll t, n, nr, sum;
    cin>>t;
    while(t--)
    {
        cin>>n;
        getDiv(n, nr, sum);
        cout<<nr<<' '<<sum<<'\n';
    }
    return 0;
}
