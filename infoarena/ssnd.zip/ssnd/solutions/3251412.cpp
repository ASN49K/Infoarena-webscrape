#include <fstream>
///numarul si suma divizorilor
using namespace std;


long long euler(long long n)
{
    long long cn = n;
    long long i;
    for(i = 2; i * i <= n; ++i)
    {
        if (n % i == 0)
        {
            while(n % i == 0)n /= i;
            cn = (cn / i) * (i - 1);
        }
    }
    if (n != 1) cn= cn/ n * (n - 1);
    return cn;
}


long long exp_rapida(long long a,long long b,long long M)
{
    long long  nr = a;
    long long putere = 1;
    for(long long p = 1; p <= b; p <<= 1)
    {
        if (p & b) putere= (putere * nr) % M;
        nr = (nr * nr) % M;
    }
    return putere;
}

long long invers_modular(long long A,long long N)
{
    long long exp = euler(N) - 1;
    return exp_rapida(A,exp,N);
}

long long nr_div_sum_div(long long n,long long &nr_div,long long &suma_div,long long M)
{
    nr_div=1;
    suma_div=1;
    long long i,exp;
    for(i = 2; i*i <= n; ++i)
    {
        if (n % i == 0)
        {
            exp=0;
            while(n % i == 0)
            {
                n /= i;
                exp++;
            }
            nr_div*=(exp+1);
            suma_div*=((exp_rapida(i,exp+1,M)-1)%M*invers_modular(i-1,M))%M;
        }


    }
    if(n>1){
         nr_div*=2;
            suma_div*=((exp_rapida(n,2,M)-1)%M*invers_modular(n-1,M))%M;
    }

}
ifstream fin("ssnd.in");
ofstream fout("ssnd.out");
const long long M=9973;
int main()
{
    int t,n;
    long long nr,s;
    fin>>t;
    for(int i=1; i<=t; i++)
    {
        fin>>n;
        nr_div_sum_div(n,nr,s,M);
        fout<<nr<<" "<<s<<endl;
    }


    return 0;
}

