#include <cstdio>
#include <cmath>
using namespace std;

const int MOD = 9973;

// void invers_modular(long long a, int b, int& inv, int& alt) {
// 	if (!b) {
// 		inv = 1;
// 		alt = 0;
// 	} else {
// 		int x0, y0;
// 		invers_modular(b, a % b, x0, y0);
// 		inv = y0;
// 		alt = x0 - a / b * y0;
// 	}
// }

int main() {
	freopen("ssnd.in", "r", stdin);
	freopen("ssnd.out", "w", stdout);

	int t;
	int n;

	scanf("%d", &t);

	while (t --) {
		scanf("%d", &n);

		long long suma = 0;
		int numarDiv = 0;

		int SQRT = sqrt(n);

		for (int i = 1;i <= SQRT;i ++) {
			if (n % i == 0) {
				suma = (suma + i) % MOD;
				// int tempImp, temp;

				// invers_modular(i, MOD, tempImp, temp);

				// while (tempImp < 0)
				// 	tempImp += MOD;

				// suma = (suma + n % MOD * tempImp) % MOD; 

				suma = (suma + n / i) % MOD;

				numarDiv += 2;
			}
		}

		if(SQRT == sqrt(n)) {
			suma = suma - SQRT;

			while (suma < 0)
				suma += MOD;

			numarDiv --;
		}


		printf("%d %d\n", numarDiv, suma);
	}

	return 0;
}