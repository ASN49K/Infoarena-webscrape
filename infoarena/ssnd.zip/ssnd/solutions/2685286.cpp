#include <bits/stdc++.h>
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("ssnd.in" , "r" , stdin) , freopen("ssnd.out" , "w" , stdout)
#define ll long long

namespace FastRead
{
    char buff[5000];ll lg = 0 , p = 0;
    char nc()
    {
        if(lg == p){lg = fread(buff , 1 , 5000 , stdin);p = 0;if(!lg) return EOF;}
        return buff[p++];
    }
    template<class T>void read(T&x)
    {
        T sgn = 1; char c;while(!isdigit(c = nc()))if(c == '-')sgn = -1;
        x = c - '0';while(isdigit(c = nc()))x = x * 10 + c - '0';x *= sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e6;
const ll M = 9973;

ll x;
bitset < N / 2 + 10> ciur;
int pr[N];

int Pw(int n , int p)
{
    n %= M;
    int ans = 1;

    for( ; p ; p >>= 1 , n = 1ll * n * n % M)
        if(p & 1)
            ans = 1ll * ans * n % M;

    return ans;
}

void prec()
{
    int i , j;

    for(i = 1 ; ((i * i) << 1) + (i << 1) <= N ; i++)
        if(!ciur[i])
            for(j = ((i * i) << 1) + (i << 1) ; (j << 1) + 1 <= N ; j += (i << 1) + 1)
                ciur[j] = 1;

    pr[++pr[0]] = 2;

    for(i = 1 ; (i << 1) + 1 <= N ; i++)
        if(ciur[i] == 0)
            pr[++pr[0]] = (i << 1) + 1;
}

void solve(ll x)
{
    int e , i;
    int card = 1;
    int sum = 1;

    for(i = 1 ; i <= pr[0] && pr[i] <= x ; i++)
        if(x % pr[i] == 0)
        {
           e = 0;

            while(x % pr[i] == 0)
                ++e , x /= pr[i];

            card *= e + 1;
            sum = 1ll * sum * (Pw(pr[i] , e + 1) - 1) % M * Pw(pr[i] - 1 , M - 2) % M;
        }

    if(x > 1)
        card *= 2 , sum = 1ll * sum * Pw(x , 2) % M * Pw((x - 1) , M - 2) % M;

    cout << card << ' ' << sum << '\n';
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    prec();

    int q;// cin >> q;
    read(q);
    while(q--)
    {
     //   cin >> x;
        read(x);
        solve(x);
    }

    return 0;
}
