
#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

unsigned long long nr;
int i, j, n, mod = 9973;
vector<bool> ciur;

void divizori(unsigned long long int x){
    int putere, divi=2, nrdiv=1, sumdiv=1;
    while(x!=1){
        putere=0;
        while(x%divi == 0){
            putere++;
            x /= divi;
        }
        nrdiv = nrdiv * (putere+1);
        sumdiv = (int)(sumdiv * (((pow(divi, (putere + 1) % mod) - 1) / (divi - 1)))) % mod;
        
        divi++;
    }
    fout<<nrdiv<<" "<<sumdiv<<endl;
}

void ciurul(){
    unsigned long long x = 100001;
    
    ciur[1] = 1;
    
    for(i=4; i <= x; i+=2){
        ciur[i] = 1;
    }
    
    for(i=3; i*i <= x; i+=2){
        if(ciur[i] == 0){
            for(j = i*i; j <= x; j = j + 2*i){
                ciur[j] = 1;
            }
        }
    }
}


int main()
{
    fin>>n;
    ciur.reserve(100001);
    
    ciurul();
    
    for(i=1;i<=n;++i){
        fin>>nr;
        
        if(ciur[nr] == 0){
            //cout<<nr<<endl;
            fout<<2<<" "<< (nr+1)%mod <<endl;
        }else{
            divizori(nr);
        }
    }


    return 0;
}