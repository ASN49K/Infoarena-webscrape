#include <bits/stdc++.h>
#define ll long long

using namespace std;
ifstream fin ("ssnd.in");
ofstream fout ("ssnd.out");
const ll MOD = 9973;
bool ciur[1000005];
vector <ll> prime;
void eratostene() {
    ciur[0]=ciur[1]=1;
    for (int i=2; i*i<=1000000; i++) {
        if (ciur[i]==0) {
            for (int j=i*i; j<=1000000; j+=i) {
                ciur[j]=1;
            }
        }
    }
    for (int i=2; i<=1000000; i++) {
        if (ciur[i]==0) {
            prime.push_back(i);
        }
    }
}
ll putere(ll a, ll b)
{
    ll p =1;
    while (b!=0) {
        if (b%2==1) {
            p*=a;
            //p%=MOD;
        }
        a*=a; //a%=MOD;
        // ASTEA 2 STRICA TOTUL!!! Fiind ca are loc o impartire
        b/=2;
    }
    return p;
}
void solve (ll x) //ll...
{
    int ind = 0;
    ll p=1, s=1;
    while (ind<prime.size()&&prime[ind]*prime[ind]<=x) {
        int d = prime[ind];
        int power = 0;
        while (x%d==0) {
            power++;
            x/=d;
        }
        if (power!=0) {
            p*=(power+1);
            s*=((putere(d, power+1)-1)/(d-1));
            s%=MOD;
        }
        ind++;
    }
    if (x!=1) {
        int d = x, power=1;
        if (power!=0) {
            p*=(power+1);
            s*=((putere(d, power+1)-1)/(d-1));
            s%=MOD;
        }
    }
    fout<<p<<' '<<s<<'\n';
}
int main()
{
    int n; fin>>n;
    eratostene();
    for (int i=1; i<=n; i++) {
        ll x; fin>>x; //ll...
        solve(x);
    }
    return 0;
}
