#include <bits/stdc++.h>

using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

int x[100001];

int main()
{
    long long int v[100001],t,n,i,j,s,d,c;
    fin>>t;
    for(i=2;i<=sqrt(100001);i++)
    {
        for(j=2;i*j<=n;j++)
        {
            x[i*j]=1;
        }
    }
    j=1;
    for(i=1;i<=100001;i++)
    {
        if(x[i]==0)
        {
            v[j]=i;
            j++;
        }
    }
    for(i=1;i<=t;i++)
    {
        s=1;
        c=1;
        fin>>n;
        for(j=2;j<=n;j++)
        {
            if(n%v[j]==0)
            {
                d=0;
                while(n!=0&&n%v[j]==0)
                {
                    n=n/v[j];
                    d++;
                }
                c=c*(d+1);
                s=s*(pow(v[j],d+1)-1)/(v[j]-1);
            }
        }
        fout<<c<<" "<<s%9973<<endl;
    }
    return 0;
}