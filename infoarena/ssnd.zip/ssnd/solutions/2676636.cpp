#include <bits/stdc++.h>
using namespace std;
#define MOD 9973
#define N 1000000
int t, ex, p1,p2;
long long sumdiv, n, nrdiv;
int nprime, prime[100000];
bitset<N> l;
int putere(int a,int b)
{
    int p = 1;
    while(b > 0){
        if (b&1) {
            p = p * a;
            p %= MOD;
        }
        a = a * a;
        a %= MOD;
        b >>= 1;
    }
    return p;
}
void ciur()
{
    for (int i=2;i<N;i++){
        if (l[i] == 0){
            prime[++nprime] = i;
            for (int j=i+i;j<N;j+=i){
                l[j] = true;
            }
        }
    }
}
int main() {
    freopen("ssnd.in", "r", stdin);
    freopen("ssnd.out", "w", stdout);

    scanf("%d", &t);
    ciur();
    for ( ;t;--t){
        scanf("%lld", &n);
        nrdiv = 1;
        sumdiv = 1;
        for (int i=1;1LL*prime[i]*prime[i]<=n && i<=nprime;i++){
            if (n%prime[i] == 0){
                ex = 0;
                while(n%prime[i]==0){
                    ex ++;
                    n /= prime[i];
                }
                nrdiv *= (ex + 1);
                p1 = (putere(prime[i], ex+1)-1)%MOD;
                p2 = putere(prime[i]-1,MOD-2)%MOD;
                sumdiv = (((sumdiv*p1)%MOD)*p2)%MOD;
            }
        }
        if (n > 1){
            nrdiv *= 2;
            sumdiv = (1LL * sumdiv * (n+1)) % MOD;
        }
        printf("%lld %lld\n", nrdiv, sumdiv);
    }
    return 0;
}
