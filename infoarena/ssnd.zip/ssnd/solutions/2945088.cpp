#include<iostream>
#include<fstream>
#include<math.h>
using namespace std;

long int ciur[1000000]={0};

void ciurul(int n)
{	
	for(int i = 2; i <= sqrt(n); i++) {
        if(ciur[i] == 0) { //Am gasit un numar nemarcat (prim)
            //Marcam multiplii lui i
            for(int j = 2 * i; j <= sqrt(n); j += i) {
                ciur[j] = 1;
            }
        }
    }
}

int main()
{	long int n,i,suma=0,count=2;
	ifstream fin("ssnd.in");
	ofstream fout("ssnd.out");
fin>>n;
ciurul(n);
if(ciur[n]==0)
		fout<<count<<' '<<n+1;
else
	{for(int i = 2; i <= n/2; i++)
		if(n%i==0)
			{count++;
			suma=suma+i;}
	suma=suma+n+1;
	fout<<count<<' '<<suma;}
}
