#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int mod = 9973;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");


ll pau(ll a, ll b){
    if(b == 0)
        return 1;
    if(b == 1)
        return a;
    if(b%2 == 0)
        return (pau(a,b/2) % mod) * (pau(a,b/2) % mod) % mod;
    return ((pau(a,b/2) % mod) * (pau(a,b/2) % mod) % mod) * (a % mod) % mod;
}

void solve(){
    ll n;
    fin >> n;

    ll nrdiv = 1, sumdiv = 1;

    ll d = 2;
    while(n>1){
        int exp = 0;

        while(n%d == 0){
            n/=d;
            exp++;
        }

        nrdiv *= exp + 1;
        sumdiv = (sumdiv % mod)*((pau(d, exp + 1) - 1)%mod) % mod;
        sumdiv = (sumdiv * pau(d - 1, mod - 2)) % mod;

        if(d == 2)
            d++;
        else
            d+=2;

        if(d * d > n)
            d = n;
    }

    fout << nrdiv << " " << sumdiv << '\n';
}

int main(){
    int t; fin >> t;

    while(t--)
        solve();

    return 0;
}
