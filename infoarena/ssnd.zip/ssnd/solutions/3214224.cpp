#include <fstream>
#define mod 9973
using namespace std;

ifstream cin("ssnd.in");
ofstream cout("ssnd.out");

long long put(long long a, long long b) {
    long long r = 1;
    while (b != 0) {
        if (b % 2 == 1)
            r *= a;
        a *= a;
        b >>= 1;
    }
    return r;
}

int main() {
    int n, a;
    cin >> n;

    for (int i = 1; i <= n; ++i) {
        cin >> a;
        long long sum = 1;
        long long nrdiv = 1;
        int d = 2, p = 0;
        while (a > 1) {
            p = 0;
            while (a % d == 0) {
                ++p;
                a /= d;
            }
            
            nrdiv *= p+1;
            sum *= (put(d, p+1) - 1) / (d - 1);
            ++d;
            if (a > 1 && d * d > a)
                d = a;
        }
        cout << nrdiv % mod << ' ' << sum % mod << '\n';
    }

    return 0;
}