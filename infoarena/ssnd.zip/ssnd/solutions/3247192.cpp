#include <fstream>

using namespace std;

ifstream f("ssnd.in");
ofstream g("ssnd.out");

const int mod = 9973;
int n, x, nrd, sumd;

int expo(int a, int b)
{
    int sol = 1;
    while(b)
        if(b % 2 == 0)
            b /= 2, a = (1LL * a * a) % mod;
        else
            b --, sol = (1LL * a * sol) % mod;

    return sol;
}

int InvMod(int x){
    return expo(x, mod - 2);
}

void solv(int x)
{
    nrd = sumd = 1;
    int d = 2;
    while(x > 1)
    {
        int p = 0, k = d;
        while(x % d == 0)
            x /= d, p ++, k *= d;

        nrd = (1LL * nrd * (p + 1)) % mod;
        sumd = (1LL * sumd * (1LL * ((k - 1) % mod) * InvMod(d - 1)) % mod) % mod;

        d ++;
        if(d * d > x)
            d = x;
    }

    g << nrd << " " << sumd << '\n';
}

int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++)
    {
        f >> x;
        solv(x);
    }
    return 0;
}
