#include <iostream>
#include <cmath>
using namespace std;

int v[3];

void nrdiv(int a){
    int d=2, exp=0, nrdivi=1, put, sum=1;
    while(a > 1) {
        if(a % d == 0) {
            exp = 0;
            while(a % d == 0) {
                exp++;
                a/=d;
            }
        }
        //cout<<" "<<d<<" "<<exp<<endl;
        nrdivi*=(exp+1);
        put=(pow(d,exp+1)-1)/(d-1);
        sum*=put;
        d++;
        if (d > 2){
            d++;
        }
        if (a > 1 && d*d > a){
            d=a;
            //cout<<"a "<<a<<" a"<<endl;
        }
    }
    v[2]=nrdivi;
    v[1]=sum;
}

int main(){
    int n, x;
    cin>>n;
    for (int i=1; i<=n; i++){
        cin>>x;
        nrdiv(x);
        cout<<v[2]<<" "<<v[1];
    }

    return 0;
}