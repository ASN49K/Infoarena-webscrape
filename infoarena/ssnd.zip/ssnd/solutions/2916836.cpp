#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("ssnd.in");
ofstream fout ("ssnd.out");

const int MAX_Q = 1005;
int qcnt;

const int MOD = 9973;
long long n, e, dcnt, dsum;

const int LIM = 1e6;
bitset <LIM + 5> freq;
int prim, p[100000];
void mark(int step){
    for(int i=step*step; i<=LIM; i+=step)
        freq[i] = true;
}

int lgput(int a, int b){
    int answer = 1;
    a %= MOD;
    while(b){
        if(b&1)
            answer = (long long)answer * a % MOD;
        a = (long long)a * a % MOD;
        b >>= 1;
    }
    return answer;
}

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr), fout.tie(nullptr);

    freq[0] = freq[1] = true;
    mark(2), mark(3);
    for(int i=5; i<=LIM/i; i+=6){
        if(!freq[ i ]) mark( i );
        if(!freq[i+2]) mark(i+2);
    }

    p[++prim] = 2, p[++prim] = 3;
    for(int i=5; i<=LIM; i+=6){
        if(!freq[ i ]) p[++prim] = i;
        if(!freq[i+2]) p[++prim] = i+2;
    }

    fin>>qcnt;
    while(qcnt--){
        fin>>n;

        dcnt = dsum = 1;
        for(int i=1; i<=prim && p[i]<=n/p[i]; i++)
            if(n % p[i] == 0){
                e = 0;
                while(n % p[i] == 0){
                    e++;
                    n /= p[i];
                }

                dcnt = (long long)dcnt * (e+1) % MOD;
                dsum = (long long)dsum * (lgput(p[i], e+1) - 1) % MOD;
                dsum = (long long)dsum * lgput((p[i] - 1), (MOD-2)) % MOD;
            }
        if(n > 1){
            dcnt = (long long)dcnt * 2 % MOD;
            dsum = (long long)dsum * ((n*n-1) / (n-1)) % MOD;
        }

        fout<<dcnt<<" "<<dsum<<"\n";
    }
    return 0;
}
