//ALEXANDRU MICLEA
 
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <assert.h>
 
using namespace std;
using ll = long long;
 
#include <fstream>
//ifstream cin("input.in"); ofstream cout("output.out");
ifstream cin("ssnd.in"); ofstream cout("ssnd.out");
 
//VARIABLES
 
const ll maxn = 1e6 + 5;
const int MOD = 9973;
int ciur[maxn];
vector <int> prime;
 
//FUNCTIONS
 


//MAIN
 
int main() {
 
    for (int i = 2; i <= maxn; i++){
        if (!ciur[i]){
            prime.push_back(i);
            for (int j = i + i; j <= maxn; j += i){
                ciur[j] = 1;
            }
        }
    }
 
 
    int t; cin >> t;
    while (t--){
        ll nr = 1, sum = 1;
        ll n, cn; cin >> n;
        
        for (auto& x : prime){
            if (x * x > n) break;
            if (n % x) continue;

            int cont = 1;
            int value = x;
            while (n % x == 0){
                cont++;
                value *= x;
                n /= x;
            }
            sum *= (value - 1) / (x - 1);
            sum %= MOD;
            nr *= cont;
        }

        if (n > 1){
            sum *= (n * n - 1) / (n - 1);
            sum %= MOD;
            nr *= 2;
        }

 
        cout << nr << ' ' << sum << '\n';
    }
    
    return 0;
}