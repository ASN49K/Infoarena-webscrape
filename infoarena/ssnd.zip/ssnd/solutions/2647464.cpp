#include <bits/stdc++.h>

using namespace std;

ifstream in("ssnd.in");
ofstream out("ssnd.out");

int MOD=9973;
int ciur[1000001],prime[1000001],k=0;

int lgput(int number,int power)
{
	int ans=1;
	while(power)
	{
		if(power%2!=0)
		{
			power--;
			ans=(ans*number)%MOD;
		}
		else
		{
			number=(number*number)%MOD;
			power/=2;
		}
	}
	return ans;
}


int main()
{
	for(int i=2;i<=1000001;i++)
	{
		if(ciur[i]==0)
		{
			ciur[i]=1;
			for(int j=i+i;j<=1000001;j+=i)
			{
				ciur[j]=1;
			}
			prime[++k]=i;
		}
	}

	int t;
	in>>t;
	while(t--)
	{
		int n;
		in>>n;
		int ans1=1,ans2=1;
		int n1=n;
		for(int i=1;i<=k&&prime[i]*prime[i]<=n1;i++)
		{
			if(n1%prime[i]==0)
			{
				int power=0;
				while(n1%prime[i]==0)
				{
					power++;
					n1/=prime[i];
				}
				ans1=ans1*(power+1);
				int a=lgput(prime[i],power+1)-1;
				a=a%MOD;
				int b=lgput(prime[i]-1,MOD-2);
				b=b%MOD;
				ans2=(((ans2*a)%MOD)*b)%MOD;

			}
		}
		if(n1>1)
		{
			ans1*=2;
			ans2=ans2*(n1+1);
			ans2%=MOD;
		}
		out<<ans1<<" "<<ans2<<"\n";
		
	}
	return 0;
}
