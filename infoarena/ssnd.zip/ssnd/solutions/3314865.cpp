
#include <bits/stdc++.h>
using namespace std;

ifstream fin("ssnd.in");
ofstream fout("ssnd.out");

unsigned long int nr;
int i, j, n, mod = 9973;

void divizori(unsigned long long int x){
    int putere, divi=2, nrdiv=1, sumdiv=1;
    while(x!=1){
        putere=0;
        while(x%divi == 0){
            putere++;
            x /= divi;
        }
        nrdiv = nrdiv * (putere+1);
        sumdiv = (int)(sumdiv * (((pow(divi, (putere + 1) % mod) - 1) / (divi - 1)))) % mod;
        
        divi++;
    }
    fout<<nrdiv<<" "<<sumdiv<<endl;
}

int main()
{
    fin>>n;
    
    for(i=1;i<=n;++i){
        fin>>nr;
        
        divizori(nr);
    }

    return 0;
}