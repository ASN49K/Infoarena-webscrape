#include <iostream>
//#include <math.h>
#include <fstream>

using namespace std;
ifstream f("ssnd.in");
ofstream o("ssnd.out");

//int ciur[100003];

int main()
{
    /*for (int i = 2; i < 100000; i++){
        if (ciur[i] == 0){
            for (int j = i + i; j < 100000; j = j + i){
                ciur[j] = 1;
            }
        }
    }*/

    int t, n, sum, aux, nr_div;
    float sq;
    f >> t;

    for (int i = 0; i < t; i++){
        f >> n;
        sum = n;
        nr_div = 2;
        //sq = sqrt(n);
        for (int j = 2; j <= n / 2; j++){
            if (n % j == 0){
                nr_div++;
                sum += j;
            }
        }
        o << nr_div << " " << sum + 1 << endl;
    }
    return 0;
}
