#include<fstream>
using namespace std;
ifstream F("ssnd.in");
ofstream G("ssnd.out");
const int N=1000001,M=9973;
long long n;
int t,k,p[80000],i,j,w,z,r,x,y;
char v[N];
int P(int x,int p)
{
	int r=1;
	for(x%=M;p;p>>=1,x=(x*x)%M)
		if(p&1)
			r=(x*r)%M;
	return r;
}
int main()
{
	for(i=2;i<N;++i)
		if(!v[i])
			for(j=2*i;j<N;j+=i)
				v[j]=1;
    for(i=2;i<N;++i)
        if(!v[i])
            p[++k]=i;
	for(F>>t;t;--t) {
        for(F>>n,w=z=i=1;i<=k&&1LL*p[i]*p[i]<=n;++i) {
            if(n%p[i])
                continue;
            for(r=0;n%p[i]==0;n/=p[i],++r);
            w*=(r+1),x=(P(p[i],r+1)-1)%M,y=P(p[i]-1,M-2)%M,z=(((z*x)%M)*y)%M;
        }
        if(n>1)
            w*=2,z=(1LL*z*(n+1)%M);
        G<<w<<" "<<z<<"\n";
    }
    return 0;
}
