#include <fstream>
#include <vector>
#include <iostream>

using namespace std;

ifstream fin("grader_test13.in");
ofstream fout("huffman.out");

vector <long long> simboluri;
vector <pair<int, long long>> rez;
vector <pair <int, int>> fii;

int nrSimboluri, i, j, k, poz1;
long long sum, nr1, nr2;

void parcurgere(int radacina, int nrbiti, long long sumB10)
{
    if (radacina < nrSimboluri)
    {
        rez[radacina].first = nrbiti;
        rez[radacina].second = sumB10;
        return;
    }
    parcurgere(fii[radacina].first, nrbiti+1, sumB10 * 2);
    parcurgere(fii[radacina].second, nrbiti+1, sumB10 * 2 + 1);
}


int main()
{

    fin >> nrSimboluri;
    pair <int, int> nul(0, 0);
    simboluri.assign(nrSimboluri * 2, 0);
    rez.assign(nrSimboluri, nul);
    fii.assign(nrSimboluri * 2, nul);
    for (i = 0; i < nrSimboluri; i++)
        fin >> simboluri[i];
    simboluri[nrSimboluri] = simboluri[0] + simboluri[1];
    fii[nrSimboluri] = make_pair(0, 1);
    k = 0;
    j = 1;i = 2;
    while (i < nrSimboluri)
    {
        if (simboluri[i] <= simboluri[nrSimboluri+k])
        {
            nr1 = simboluri[i];
            poz1 = i;
            i++;
        }
        else
        {
            nr1 = simboluri[nrSimboluri+k];
            poz1 = nrSimboluri+ k;
            k++;
        }
        if ((simboluri[i] <= simboluri[nrSimboluri + k] && i < nrSimboluri) || k == j)
        {
            nr2 = simboluri[i];
            simboluri[nrSimboluri+j] = nr1+nr2;
            fii[nrSimboluri+j] = make_pair(poz1, i);
            i++;
        }
        else
        {
            nr2 = simboluri[nrSimboluri+k];
            simboluri[nrSimboluri+j] = nr1+nr2;
            fii[nrSimboluri+j] = make_pair(poz1, nrSimboluri+k);
            k++;
        }
        j++;
    }
    while (j < nrSimboluri-1)
    {
        nr1 = simboluri[nrSimboluri+k];
        nr2 = simboluri[nrSimboluri+k+1];
        simboluri[nrSimboluri+j]= nr1+nr2;
        fii[nrSimboluri+j] = make_pair(nrSimboluri+k, nrSimboluri+k+1);
        k+=2; j++;
    }


    for (i = nrSimboluri; i <= nrSimboluri * 2-1; i++)
        sum = sum + simboluri[i];
        //    fout << fii[i].first << ' ' << fii[i].second << '\n';

    parcurgere (nrSimboluri*2-2, 0, 0);
    fout << sum << '\n';
    for (i = 0; i < nrSimboluri; i++)
        fout << rez[i].first << ' ' << rez[i].second << '\n';
    return 0;
}
