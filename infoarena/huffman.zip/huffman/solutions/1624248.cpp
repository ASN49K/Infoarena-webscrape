#include <fstream>
#include <deque>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
const int nmax=10001;
int k;
long long sol=0;
struct nod
{
    int z;
    int st,dr,tata;
}arb[nmax];
deque<int> Q,H;
int unite(int a,int b)
{
    arb[a].tata=arb[b].tata=k;
    arb[k].z=arb[a].z+arb[b].z;
    sol+=arb[k].z;
    arb[k].st=a;
    arb[k].dr=b;
    return k;
}
void dfs(nod *p)
{
    return ;
}
int main()
{
    int n,i,a,b,step1,step2,step,tot;
    int j;
    fin>>n;
    k=n+1;
    for(i=1;i<=n;++i)
    {
        fin>>j;
        arb[i].z=j;
        Q.push_back(i);
    }
    sol=0;
    while(1)
    {
        step1=0;step2=0;
        if(Q.size()) step1=Q.front();
        if(H.size()) step2=H.front();
        if(step1==0)  {a=step2;H.pop_front();}
        else if(step2==0) {a=step1;Q.pop_front();}
        else if(arb[step1].z<=arb[step2].z) {a=step1;Q.pop_front();}
        else {a=step2;H.pop_front();}
        step1=0;step2=0;
        if(Q.size()) step1=Q.front();
        if(H.size()) step2=H.front();
        if(step1==0)  {b=step2;H.pop_front();}
        else if(step2==0) {b=step1;Q.pop_front();}
        else if(arb[step1].z<=arb[step2].z) {b=step1;Q.pop_front();}
        else {b=step2;H.pop_front();}
        H.push_back(unite(a,b));k++;
        if(Q.size()+H.size()<=1) break;
    }
    fout<<sol<<"\n";
    for(i=1;i<=n;i++)
    {
        sol=0;tot=0;a=i;
        step=1;
        while(arb[a].tata!=0)
        {
            if(a==arb[arb[a].tata].dr) sol=sol+step;
            step*=2;
            tot++;
            a=arb[a].tata;
        }
        fout<<tot<<" "<<sol<<"\n";
    }
}
