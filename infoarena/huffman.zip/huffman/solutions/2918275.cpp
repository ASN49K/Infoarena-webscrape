#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct Pair {
  int node;
  long long val;
  bool operator < (Pair o) const {
    if(val != o.val) {
      return val < o.val;
    } else {
      return node < o.node;
    }
  }
};

int const NMAX = 1000000;
int n;
int f[1 + NMAX];
long long ans[1 + NMAX];
long long len[1 + NMAX];
int le[1 + NMAX], ri[1 + NMAX];

void dfs(int from, long long code, long long dist) {
  //cout << from << ": " << le[from] << " " << ri[from] << " " << code << "\n";
  if(from <= n) {
    ans[from] = code;
    len[from] = dist;
  } else {
    dfs(le[from], 2*code, dist+1);
    dfs(ri[from], 2*code+1, dist+1);
  }
}

int main() {
  fin >> n;
  set<Pair> s;
  for(int i = 1; i <= n; i++) {
    fin >> f[i];
    s.insert({i, f[i]});
  }
  int index = n+1;
  for(int i = 1; i <= n-1; i++) {
    Pair p1 = *s.begin();
    s.erase(s.begin());
    Pair p2 = *s.begin();
    s.erase(s.begin());
    le[index] = p1.node;
    ri[index] = p2.node;
    s.insert({index, p1.val + p2.val});
    //cout << p1.node << " " << p2.node << " " << index << "\n";
    index++;
  }
  int root = (*s.begin()).node;
  dfs(root, 0, 0);
  for(int i = 1; i <= n; i++) {
    fout << len[i] << " " << ans[i] << "\n";
  }
}
