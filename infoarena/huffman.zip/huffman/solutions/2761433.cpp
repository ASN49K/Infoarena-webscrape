#include <cstdio>
#include <iostream>
#include <cassert>
#include <queue>

using namespace std;

typedef long long ll;

const int N = (int) 2e6 + 7;
int n, k1[N], k2[N], len[N], par[N], e[N];
ll num[N];
priority_queue<pair<ll, int>> pq;

signed main() {
  freopen ("huffman.in", "r", stdin);
  //freopen ("huffman.out", "w", stdout);

  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    int x;
    scanf("%d", &x);
    pq.push({-x, i});
  }
  int y = n;
  ll sol = 0;
  while ((int) pq.size() > 1) {
    auto it1 = pq.top(); pq.pop();
    auto it2 = pq.top(); pq.pop();
    par[it1.second] = par[it2.second] = ++y;
    e[it1.second] = 1;
    pq.push({it1.first + it2.first, y});
    sol -= (it1.first + it2.first);
  }
  printf("%lld\n", sol);
  for (int i = y - 1; i >= 1; i--) {
    len[i] = 1 + len[par[i]];
    num[i] = num[par[i]] + e[i] * (1LL << len[par[i]]);
  }
  for (int i = 1; i <= n; i++) {
    printf("%d %lld\n", len[i], num[i]);
  }
  return 0;
}
