#include <fstream>
#define valoare first
#define stanga second.first
#define dreapta second.second
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
long long cod[5000010],niv[5000010],cont;
int i,j,n,ult;
pair<long long  ,pair<int,int> >caractere[5000010];
void dfs(long long  nod ,long long nivel,long long binar){
    if(caractere[nod].stanga!=0){
        dfs(caractere[nod].stanga, nivel+1, binar*2);
        dfs(caractere[nod].dreapta,  nivel+1,binar*2+1);
        return;
    }
    niv[nod]=nivel;
    cod[nod]=binar;


}





int main(){
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>caractere[i].first;
        caractere[n+i].valoare=1LL * 1000000000 * 1000000000;
    }
    ult=n;
    i=1;
    j=n+1;
    while(ult<2*n-1){
        if(caractere[i].valoare<=caractere[j].valoare && caractere[i+1].valoare<=caractere[j].valoare && i<=n && i+1<=n){
            ult++;
            caractere[ult].valoare=caractere[i].valoare+caractere[i+1].valoare;
            caractere[ult].stanga=i;
            caractere[ult].dreapta=i+1;

            i+=2;

        }
        else{
            if( j+1<=2*n-1 && ( ( caractere[j+1].valoare<=caractere[i].valoare && caractere[j].valoare<caractere[i].valoare ) || i>n ) ){
                ult++;
                caractere[ult].stanga=j;
                caractere[ult].dreapta=j+1;
                caractere[ult].valoare=caractere[j].valoare+caractere[j+1].valoare;

                j+=2;
            }
            else{
               if( (caractere[i].valoare<=caractere[j].valoare && i<=n && ( (i+1<=n && caractere[i+1].valoare>caractere[j].valoare) || (i+1>n) )) || (i<=n && caractere[i].valoare>caractere[j].valoare && ( (j+1<2*n && caractere[j+1].valoare>caractere[i].valoare ) || ( j+1>=2*n ) ) ) ){
                    ult++;
                    caractere[ult].stanga=i;
                    caractere[ult].dreapta=j;

                    caractere[ult].valoare=caractere[i].valoare+caractere[j].valoare;
                    i++,j++;
                }
            }


        }
       cont+=caractere[ult].valoare;

    }
    fout<<cont<<"\n";
    dfs(ult,0,0);

    for(i=1;i<=n;i++){
        fout<<niv[i]<<" "<<cod[i]<<"\n";
    }



}
