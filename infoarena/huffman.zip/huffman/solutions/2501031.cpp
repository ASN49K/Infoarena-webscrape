#include <fstream>
#define valoare first
#define stanga second.first
#define dreapta second.second
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
long long n,vizitat[5000010],ult,i,k,minim,aux,cod[5000010],niv[5000010],cont;
pair<long long  ,pair<long long,long long> >caractere[5000010];
void dfs(long long  nod ,long long nivel,long long binar){
    if(caractere[nod].stanga!=0){
        dfs(caractere[nod].stanga, nivel+1, binar*2);
        dfs(caractere[nod].dreapta,  nivel+1,binar*2+1);
        return;
    }
    niv[nod]=nivel;
    cod[nod]=binar;


}





int main(){
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>caractere[i].first;
    }
    ult=n;
    for(k=n-1;k;k--){
        ++ult;
        for(i=1;i<=2;i++){
            aux=0;
            minim=1LL * 1000000000 * 1000000000;
            for(int j=1;j<ult;j++){
                if(caractere[j].valoare<minim && !vizitat[j]){

                    aux=j;
                    minim=caractere[j].valoare;
                }
            }
            vizitat[aux]=1;
            if(i==1){
                caractere[ult].stanga=aux;
                caractere[ult].valoare+=caractere[aux].valoare;
            }
            else{
                if(i==2){
                    caractere[ult].dreapta=aux;
                    caractere[ult].valoare+=caractere[aux].valoare;
                }
            }

        }
        cont+=caractere[ult].valoare;
    }

    dfs(ult,0,0);
    fout<<cont<<"\n";
    for(int i=1;i<=n;i++){
        fout<<niv[i]<<" "<<cod[i]<<"\n";
    }



}
