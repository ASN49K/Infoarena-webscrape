#include<iostream>
#include<deque>
#include<algorithm>
#include<fstream>
#include<vector>
using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

struct node{
	node*left;
	node*right;
	long long cost;
	int symbol;

	node(long long c,int s):left(nullptr),right(nullptr),cost(c),symbol(s){

	}
};


const int mx=1e6+100;

int n,freq[mx],length[mx];
long long ans[mx];

deque<node*> leaf,inter;

void read(){
	in>>n;

	for(int i=1;i<=n;i++){
		in>>freq[i];
		leaf.push_back(new node(freq[i],i));
	}
}

node*get_minimal(){
	node*ans;

	if(leaf.size()==0){
		ans=inter.front();
		inter.pop_front();

	}	
	else if(inter.size()==0){
		ans=leaf.front();
		leaf.pop_front();
	}
	else{
		if(inter.front()->cost<leaf.front()->cost){
			ans=inter.front();
			inter.pop_front();
		}
		else{
			ans=leaf.front();
			leaf.pop_front();
		}
	}
	return ans;
}

void dfs(node*here,long long b,int depth){
	if(here->symbol!=0){
		ans[here->symbol]=b;
		length[here->symbol]=depth;
		return;
	}
	
	dfs(here->left,b<<1,depth+1);
	dfs(here->right,(b<<1)+1,depth+1);
}

void solve(){

	while(leaf.size()+inter.size()>1){
					
		node*a=get_minimal();
		node*b=get_minimal();

		node*c=new node(a->cost+b->cost,0);
		c->left=a;
		c->right=b;

		inter.push_back(c);
	}
	dfs(inter.front(),0,0);
	
	long long total=0;

	for(int i=1;i<=n;i++){
		total+=length[i]*(long long )freq[i];
	}

	out<<total<<endl;
	for(int i=1;i<=n;i++){
		out<<length[i]<<" "<<ans[i]<<'\n';
	}
}

int main(){
	read();
	solve();

	return 0;
}
