#include <fstream>
#define valoare first
#define stanga second.first
#define dreapta second.second
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
long long n,vp[5000010],ult,i,j,cod[5000010],niv[5000010],cont,c;
pair<long long  ,pair<long long,long long> >caractere[5000010];
void dfs(long long  nod ,long long nivel,long long binar){
    if(caractere[nod].stanga!=0){
        dfs(caractere[nod].stanga, nivel+1, binar*2);
        dfs(caractere[nod].dreapta,  nivel+1,binar*2+1);
        return;
    }
    niv[nod]=nivel;
    cod[nod]=binar;


}





int main(){
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>caractere[i].first;
        vp[i]=1LL * 1000000000 * 1000000000;
    }
    ult=n;
    i=j=1;
    while(ult<2*n-1){
        if(caractere[i].valoare<=vp[j] && caractere[i+1].valoare<=vp[j] && i<=n && i+1<=n){
            c++;
            vp[c]=caractere[i].valoare+caractere[i+1].valoare;
            ult++;
            caractere[ult].stanga=i;
            caractere[ult].dreapta=i+1;


            i+=2;

        }
        else{
            if( j+1<=2*n-1 && ( ( vp[j+1]<=caractere[i].valoare && vp[j]<caractere[i].valoare ) || i>n ) ){
                ult++;
                caractere[ult].stanga=j+n;
                caractere[ult].dreapta=j+n+1;
                c++;
                vp[c]=vp[j]+vp[j+1];

                j+=2;
            }
            else{
               if( (caractere[i].valoare<=vp[j] && i<=n && ( (i+1<=n && caractere[i+1].valoare>vp[j]) || (i+1>n) )) || (i<=n && caractere[i].valoare>vp[j] && ( (j+1<2*n && vp[j+1]>caractere[i].valoare ) || ( j+1>=2*n ) ) ) ){
                    ult++;
                    caractere[ult].stanga=i;
                    caractere[ult].dreapta=j+n;
                    c++;
                    vp[c]=caractere[i].valoare+vp[j];
                    i++,j++;
                }
            }


        }
       caractere[ult].valoare=vp[c];
       cont+=caractere[ult].valoare;

    }
    fout<<cont<<"\n";
    dfs(ult,0,0);

    for(int i=1;i<=n;i++){
        fout<<niv[i]<<" "<<cod[i]<<"\n";
    }



}
