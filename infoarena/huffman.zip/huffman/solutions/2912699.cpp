#include <bits/stdc++.h>

typedef long long ll;
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");
const int NMAX=1000005;

///in cazul in care costurile nodurilor sunt date in ordine crescatoare, se pot
///tine doua cozi, continand nodurile initiale, respectiv nodurile interne
int N, q[2][NMAX], len[NMAX], cod[NMAX], l[2], r[2], sol, ind;
struct{
    int val, f[2];
}nod[2*NMAX];

void dfs(int poz, int value, int niv){
    if(nod[poz].f[0] and nod[poz].f[1]){
        dfs(nod[poz].f[0],value*2,niv+1);
        dfs(nod[poz].f[1],value*2+1,niv+1);
        return;
    }
    len[poz]=niv;
    cod[poz]=value;
}

void solve(){
    int p, mn;
    ind=N;
    l[0]=l[1]=1;
    r[0]=N;
    r[1]=0;
    while(l[0]+l[1]<=r[0]+r[1]){
        ind++;
        for(int k=0;k<2;k++){
            p=0;
            mn=INT_MAX;
            for(int i=0;i<2;i++){
                if(nod[q[i][l[i]]].val<mn and l[i]<=r[i]){
                    p=i;
                    mn=nod[q[i][l[i]]].val;
                }
            }
            nod[ind].f[k]=q[p][l[p]];
            nod[ind].val+=mn;
            l[p]++;
        }
        sol+=nod[ind].val;
        q[1][++r[1]]=ind;
    }
}

int main()
{
    fin>>N;
    for(int i=1;i<=N;i++){
        fin>>nod[i].val;
        q[0][i]=i;
    }

    solve();

    fout<<sol<<'\n';
    dfs(ind,0,0);

    for(int i=1;i<=N;i++)
        fout<<len[i]<<' '<<cod[i]<<'\n';

    fin.close();
    fout.close();
    return 0;
}
