#include <bits/stdc++.h>

using namespace std;

typedef long long int lli;

const int MAXN = 1e6;

struct Node{
	lli v, code;
	int f[2], lvl;

	Node(lli v = 0) {
		this->v = v;
		f[0] = -1;
		f[1] = -1;
		code = 0;
		lvl = 0;
	}
};


int n;
vector<Node> nodes;
queue<pair<lli, int> > q[2];
int sol;

void dfs(int k, lli code, int lvl) {
	nodes[k].code = code;
	nodes[k].lvl = lvl;

	for (int i = 0; i < 2; ++ i) {
		if (nodes[k].f[i] != -1)
			dfs(nodes[k].f[i], code * 2 + i, lvl + 1);
	}
}


int main() {
	freopen("huffman.in", "r", stdin);
	freopen("huffman.out", "w", stdout);

	cin >> n;

	for (int i = 0; i < n; ++ i) {
		int v;
		cin >> v;
		nodes.push_back(Node(v));
		q[0].push({v, i});
	}

	while (!q[0].empty() || q[1].size() > 1) {
		pair<lli, int> minn[2];

		for (int i = 0; i < 2; ++ i) {
			if (q[0].empty()) {
				minn[i] = q[1].front();
				q[1].pop();
			} else if (q[1].empty()) {
				minn[i] = q[0].front();
				q[0].pop();
			} else {
				minn[i] = q[0].front().first <= q[1].front().first ? q[0].front() : q[1].front();
				if (q[0].front().first <= q[1].front().first)
					q[0].pop();
				else
					q[1].pop();
			}
		}

		nodes.push_back(Node(minn[0].first + minn[1].first));
		q[1].push({minn[0].first + minn[1].first, nodes.size() - 1});

		sol += nodes.back().v;

		for (int i = 0; i < 2; ++ i)
			nodes.back().f[i] = minn[i].second;
	}

	dfs(nodes.size() - 1, 0, 0);

	cout << sol << '\n';

	for (int i = 0; i < n; ++ i)
		cout << nodes[i].lvl << ' ' << nodes[i].code << '\n';
	cout << '\n';

	// for (int i = 0; i < nodes.size(); ++ i)
	// 	cout << i << ' ' << nodes[i].v << ' ' << nodes[i].f[0] << ' ' << nodes[i].f[1] << '\n';

	return 0;
}