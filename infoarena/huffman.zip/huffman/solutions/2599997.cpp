#include<cstdio>

#define DN 1000005

#define INF 100000000000005

using namespace std;

int n,q[2][DN],k,l[2],r[2],poz,lg[DN];

long long mi,cod[DN],sol;

struct sdf

{

    long long v;

    int f[2];

}nod[2*DN];

void ve()

{

    k=n;

    r[0]=n;

    l[0]=l[1]=1;

    while(l[0]+l[1]<=r[0]+r[1])

    {

        k++;

        for(int i=0;i<2;i++)

        {

            mi=INF;

            for(int j=0;j<2;j++)

                if(l[j]<=r[j]&&nod[q[j][l[j]]].v<=mi)

                {

                    mi=nod[q[j][l[j]]].v;

                    poz=j;

                }

            nod[k].f[i]=q[poz][l[poz]];

            nod[k].v+=mi;

            l[poz]++;

        }

        r[1]++;

        q[1][r[1]]=k;

        sol+=nod[k].v;

    }

}

void dfs(int a,int nivel,long long val)

{

    if(nod[a].f[0])

    {

        dfs(nod[a].f[0],nivel+1,val*2);

        dfs(nod[a].f[1],nivel+1,val*2+1);

        return;

    }

    lg[a]=nivel;

    cod[a]=val;

}

int main()

{

    freopen("huffman.in","r",stdin);

    freopen("huffman.out","w",stdout);

    scanf("%d",&n);

    for(int i=1;i<=n;i++)

    {

        scanf("%d",&nod[i].v);

        q[0][i]=i;

    }

    ve();

    dfs(k,0,0);

    printf("%lld\n",sol);

    for(int i=1;i<=n;i++)

        printf("%d %lld\n",lg[i],cod[i]);

}
