#include <stdio.h>
#include <queue>
#include <limits>

using namespace std;

typedef long T;

const T NMAX = 1000005;
const T WMAX = numeric_limits<T>::max();

T N;

T q[2][NMAX];
T  l[2], r[2]; // capete cozi
T  lev[NMAX];
T code[NMAX];

struct nod {
   T val;
   T child[2];
};

nod nodes[NMAX*2];

void dfs(T poz_nod, T level, T cod) {
   if (nodes[poz_nod].child[0]) {
      dfs(nodes[poz_nod].child[0], level+1, cod*2);
      dfs(nodes[poz_nod].child[1], level+1, cod*2+1);
      return;
   }
   lev[poz_nod] = level;
   code[poz_nod] = cod;
}

T huffman() {
   int k = N;
   l[0] = l[1] = 1;
   r[1] = 0;
   r[0] = N;

   T sol = 0;
   while (l[0] < r[0] || l[1] < r[1]) {
      ++k;

      for (int i = 0; i < 2; ++i) {
         T mnod_val = WMAX;
         int q_ix = -1;

         for (int j = 0; j < 2; ++j) {
            if (l[j] <= r[j] && nodes[q[j][l[j]]].val < mnod_val) {
               mnod_val = nodes[q[j][l[j]]].val;
               q_ix = j;
            }
         }

         nodes[k].child[i] = q[q_ix][l[q_ix]];
         nodes[k].val += mnod_val;
         l[q_ix] += 1;
      }
      q[1][++r[1]] = k;
      sol += nodes[k].val;
   }
   dfs(k,0,0);
   return sol;
}

int main() {
   freopen("huffman.in", "r", stdin);
   freopen("huffman.out", "w", stdout);

   scanf("%ld", &N);

   for (T i = 1; i <= N; ++i) {
      scanf("%ld", &nodes[i].val);
      q[0][i] = i;
   }

   T sol = huffman();
   printf("%ld\n", sol);

   for (int i = 1; i <= N; ++i) {
      printf("%ld %ld\n", lev[i], code[i]);
   }


   fclose(stdin);
   fclose(stdout);
}
