#include <fstream>
#include <queue>

using namespace std;

struct node
{
	long long val;
	int parent;
	node(long long v = 0, int p = 0) :val(v), parent(p) {};
};
vector<node*> symbol_q;
pair<int, long long> getCode(node* nod)
{
	int lung = 0;
	long long cod = 0;
	int pow = 1;
	while (nod->parent !=0)
	{
		++lung;
		if (nod->parent < 0 )
			cod += pow;
		pow *= 2;
		nod = symbol_q[abs(nod->parent)];

	}
	return make_pair(lung, cod);
}

int main()
{
	ifstream in("huffman.in");
	ofstream out("huffman.out");
	int nodes;
	long long freq;
	long long lg = 0;
	queue<node*> internal_q;

	in >> nodes;
	for (int i = 0; i < nodes; ++i)
	{
		in >> freq;
		symbol_q.push_back(new node(freq));
	}
	int pos = 0;
	while (pos < nodes || internal_q.size() > 1)
	{
		node* min1, * min2;
		if (pos == nodes)
		{
			min1 = internal_q.front();
			internal_q.pop();
			min2 = internal_q.front();
			internal_q.pop();
			lg += min1->val + min2->val;
		}
		else if (internal_q.empty())
		{
			min1 = symbol_q[pos];
			++pos;
			min2 = symbol_q[pos];
			++pos;
		}
		else
		{
			if (symbol_q[pos]->val <= internal_q.front()->val)
			{
				min1 = symbol_q[pos];
				++pos;
			}
			else
			{
				min1 = internal_q.front();
				internal_q.pop();
				lg += min1->val;
			}
			if (pos < nodes && !internal_q.empty())
			{
				if (pos < nodes && symbol_q[pos]->val <= internal_q.front()->val)
				{
					min2 = symbol_q[pos];
					++pos;
				}
				else
				{
					min2 = internal_q.front();
					internal_q.pop();
					lg += min2->val;
				}
			}
			else
			{
				if (pos == nodes)
				{
					min2 = internal_q.front();
					internal_q.pop();
					lg += min2->val;
				}
				else
				{
					min2 = symbol_q[pos];
					++pos;
				}
			}

		}

		internal_q.push(new node(min1->val + min2->val));
		symbol_q.push_back(internal_q.back());
		min1->parent = symbol_q.size() - 1;
		min2->parent = -1*(symbol_q.size() - 1);

	}
	lg += internal_q.front()->val;
	in.close();
	out << lg << "\n";
	for (int i=0; i<nodes; ++i)
	{
		auto res = getCode(symbol_q[i]);
		out << res.first << " " << res.second << "\n";
	}
}