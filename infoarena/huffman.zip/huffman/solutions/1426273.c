#include <stdio.h>
#define INF 2000000000000000000LL
#define MAXN 1000000
int a[MAXN], b[MAXN], l[MAXN], v[MAXN];
long long q[MAXN], c[MAXN];
void df(int p, long long cod, int lg){
    if(p<0){
        c[-p-1]=cod;
        l[-p-1]=lg;
        return ;
    }
    df(a[p], 2LL*cod, lg+1);
    df(b[p], 2LL*cod+1LL, lg+1);
}
int main(){
    int n, st, dr, i;
    long long sum, sol1, sol2, sol3;
    FILE *fin, *fout;
    fin=fopen("huffman.in", "r");
    fout=fopen("huffman.out", "w");
    fscanf(fin, "%d", &n);
    for(i=0; i<n; i++){
        fscanf(fin, "%d", &v[i]);
    }
    st=dr=0;
    a[dr]=-1;
    b[dr]=-2;
    q[dr++]=v[0]+v[1];
    sum=v[0]+v[1];
    i=2;
    while((i<n)||(st+1<dr)){
        if(i+1<n){
            sol1=v[i]+v[i+1];
        }else{
            sol1=INF;
        }
        if(i<n){
            sol2=v[i]+q[st];
        }else{
            sol2=INF;
        }
        if(st+1<dr){
            sol3=q[st]+q[st+1];
        }else{
            sol3=INF;
        }
        if((sol1<=sol2)&&(sol1<=sol3)){
            a[dr]=-i-1;
            b[dr]=-i-2;
            q[dr++]=v[i]+v[i+1];
            i+=2;
        }else if((sol2<=sol1)&&(sol2<=sol3)){
            a[dr]=-i-1;
            b[dr]=st;
            q[dr++]=v[i]+q[st];
            i++;
            st++;
        }else{
            a[dr]=st;
            b[dr]=st+1;
            q[dr++]=q[st]+q[st+1];
            st+=2;
        }
        sum+=q[dr-1];
    }
    df(st, 0, 0);
    fprintf(fout, "%lld\n", sum);
    for(i=0; i<n; i++){
        fprintf(fout, "%d %lld\n", l[i], c[i]);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
