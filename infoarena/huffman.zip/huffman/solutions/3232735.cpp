#include <fstream>
#include <queue>

using namespace std;

#define MAXN 1000100

typedef pair<long long, int> tp;

struct nod{
    long long v;
    int fs, fd;
} nod[2 * MAXN];

int n, i, k, a[MAXN];
long long b[MAXN], lt;
int l[MAXN];
pair<long long, int> p;
priority_queue<tp> q;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

void Build_Tree(){
    k = n;
    while(q.size() > 1){
        ++k;
        p = q.top();
        q.pop();
        nod[k].v = -p.first;
        nod[k].fs = p.second;
        p = q.top();
        q.pop();
        nod[k].v += -p.first;
        nod[k].fd = p.second;
        q.push({-nod[k].v, k});
        lt += nod[k].v;
    }
}

void Walk_Tree(int poz, long long cod , int nivel){
    if(nod[poz].fs){
        Walk_Tree(nod[poz].fs, cod * 2, nivel + 1);
        Walk_Tree(nod[poz].fd, cod * 2 + 1, nivel + 1);
    }else{
        l[poz] = nivel;
        b[poz] = cod;
    }
}

int main(){
    fin >> n;
    for(i = 1; i <= n; ++i){
        fin >> nod[i].v;
        q.push({-nod[i].v, i});
    }
    Build_Tree();
    Walk_Tree(k, 0, 0);
    fout << lt << '\n';
    for(i = 1; i <= n; ++i)
        fout << l[i] << ' ' << b[i] << '\n';
}
