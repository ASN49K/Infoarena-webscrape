#include <stdio.h>
#include <algorithm>
#include <limits.h>

#define INF 1LL * 1000000000 * 1000000000
#define nMax 1000005
using namespace std;
int n, k;
int l[2], r[2], q[2][nMax];
long length[2*nMax];
long long code[2*nMax], Sol;
struct coduri
{
    long long v;
    int f[2];
}nod[2*nMax];
void read()
{
    scanf("%d", &n);

    for(int i=1;i<=n;i++)
    {
        scanf("%d", &nod[i].v);
        q[0][i]=i;
    }
}
void dfs(int node, long long cod, long len)
{
    if(nod[node].f[0])
    {
        dfs(nod[node].f[0], cod*2, len+1);
        dfs(nod[node].f[1], cod*2+1, len+1);
    }

    code[node]=cod;
    length[node]=len;
}
void solve()
{
    l[0]=l[1]=1;
    r[0]=k=n;

    while(l[0]+l[1]<=r[0]+r[1])
    {
        k++;
        for(int i=0;i<2;i++)
        {
            int poz=0;
            long long Min=INF;

            for(int j=0;j<2;j++)
            {
                if(nod[q[j][l[j]]].v<Min && l[j]<=r[j])
                {
                    poz=j;
                    Min=nod[q[j][l[j]]].v;
                }
            }
            nod[k].v+=Min;
            nod[k].f[i]=q[poz][l[poz]];
            l[poz]++;
        }

        Sol+=nod[k].v;
        q[1][++r[1]]=k;
    }

    dfs(k, 0, 0);
}
void write()
{
    printf("%lld\n", Sol);

    for(int i=1;i<=n;i++)
        printf("%d %lld\n", length[i], code[i]);
}
int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);

    read();
    solve();
    write();
    return 0;
}
