#include <fstream>

const long long inf = 1LL*1000000000*100000000;
const long long NMAX = 1000100;

using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

struct noduri
{
    long long v;
    long long f[2];
};

noduri nod[2*NMAX];

long long N;
long long sol,b[NMAX],lg[NMAX],l[2],r[2],q[2][NMAX];

void dfs(int poz, int cod, int nivel)
{
    if (nod[poz].f[0])
    {
        dfs(nod[poz].f[0], cod*2, nivel+1);
        dfs(nod[poz].f[1], cod*2 + 1, nivel+1);
        return;
    }

    lg[poz] = nivel;
    b[poz] = cod;
}

void solve()
{
    long long m = inf;
    long long p = 0;
    long long k = N;
    l[0]=l[1]=1;
    r[0]=N;

    while(l[0] + l[1] <= r[0] + r[1])
    {
        k++;
        for (int i = 0; i < 2; ++i)
        {
            m = inf;
            p = 0;
            for (int j = 0; j < 2; ++j)
            {
                if (nod[q[j][l[j]]].v < m && l[j]<=r[j])
                {
                    m = nod[q[j][l[j]]].v;
                    p = j;
                }
            }
            nod[k].f[i] = q[p][l[p]];
            nod[k].v += nod[q[p][l[p]]].v;
            l[p]++;
        }
        sol += nod[k].v;
        q[1][++r[1]] = k;
    }

    dfs(k,0,0);
}

int main()
{
    f >> N;
    for (int i = 1; i <= N; ++i)
    {
        f >> nod[i].v;
        q[0][i] = i;
    }

    solve();

    g << sol << '\n';

    for (int i = 1; i <= N; ++i)
    {
        g << lg[i] << " " << b[i] << '\n';
    }

    f.close();
    g.close();
    return 0;
}
