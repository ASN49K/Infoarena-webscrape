#include <bits/stdc++.h>
#define PII pair<int,int>
#define PLI pair<long long,int>
#define LL long long
#define Val first
#define Poz second

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

int n;
LL val[2000001];
PII decInit[1000001];
PLI decComp[1000001];
int vf,st1=1,dr1,st2=1,dr2;
PII fii[1000001];
int tata[2000001];
LL cod,sum;
int lung;

PLI atrib()
{
    if(st2>dr2)
        return decInit[st1++];
    else if(st1>dr1)
        return decComp[st2++];
    else if(decInit[st1].Val<decComp[st2].Val)
        return decInit[st1++];
    else
        return decComp[st2++];
}

void getCod(int poz,int pozAnt,int place)
{
    if(tata[poz])
        getCod(tata[poz],poz,place);

    if(fii[poz].first==pozAnt)
        cod=cod*2;
    else
        cod=cod*2+1;

    lung++;
}

int main()
{
    in>>n;
    vf=n;

    for(int i=1;i<=n;i++)
    {
        in>>val[i];
        decInit[++dr1]={val[i],i};
    }

    PLI nod1,nod2;
    while(st1<=dr1 || st2<=dr2)
    {
        nod1=atrib();
        nod2=atrib();

        val[++vf]=nod1.Val+nod2.Val;
        fii[vf]={nod1.Poz,nod2.Poz};
        tata[nod1.Poz]=vf;
        tata[nod2.Poz]=vf;

        if(st1<=dr1 || st2<=dr2)
            decComp[++dr2]={val[vf],vf};
    }

    LL sum=0;
    for(int i=n+1;i<=vf;i++)
        sum+=val[i];

    out<<sum<<'\n';

    for(int i=1;i<=n;i++)
    {
        cod=0;lung=0;
        getCod(tata[i],i,i);

        out<<lung<<' '<<cod<<'\n';
    }

    return 0;
}
