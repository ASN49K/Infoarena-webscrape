#include <fstream>
#include <queue>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

const int N=2e6+1;

int st[N],dr[N],nr,nivel[N];
long long val[N],cod[N];
//vector<int> q1,q2;//[N+1],q2[N+1];
queue<int> q1,q2;

int selectie()
{
    int mini;
    if(q1.empty())
    {
        mini=q2.front();
        q2.pop();
        return mini;
    }
    if(q2.empty())
    {
        mini=q1.front();
        q1.pop();
        return mini;
    }
    if(val[q1.front()]<=val[q2.front()])
    {
        mini=q1.front();
        q1.pop();
    }
    else
    {
        mini=q2.front();
        q2.pop();
    }
    return mini;
}

void adauga(int x, int y)
{
    val[++nr]=val[x]+val[y];
    q2.push(nr);
    st[nr]=x;
    dr[nr]=y;
}

long long rsd(int x)
{
    long long sum=0;
    if(st[x]!=0)
    {
        cod[st[x]]=cod[x]*2;
        nivel[st[x]]=1+nivel[x];
        cod[dr[x]]=cod[x]*2+1;
        nivel[dr[x]]=1+nivel[x];
        sum+=val[x]+rsd(st[x])+rsd(dr[x]);
    }
    return sum;
}

int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>val[i];
        q1.push(i);
    }
    nr=n;
    while(q1.size()+q2.size()>1)
    {
        int x=selectie();
        int y=selectie();
        adauga(x, y);
    }
    out<<rsd(nr)<<"\n"; ///radacina stanga dreapta
    for(int i=1; i<=n; i++)
    {
        out<<nivel[i]<<" "<<cod[i]<<"\n";
    }
    in.close();
    out.close();
    return 0;
}
