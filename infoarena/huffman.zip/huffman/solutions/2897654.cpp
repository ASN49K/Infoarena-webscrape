#include <bits/stdc++.h>

using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");
struct {
    int st, dr, nivel;
    long long valoare;
}arbore[2000001];
int n;
long long rasp;
void dfs(int nod, int nivel, int valoare) {
    if(nod <= n) {
        arbore[nod].nivel = nivel;
        arbore[nod].valoare = valoare;
        return;
    }
    dfs(arbore[nod].st, nivel + 1, valoare * 2);
    dfs(arbore[nod].dr, nivel + 1, valoare * 2 + 1);
}
int main()
{
    f >> n;
    for(int i = 1; i <= n; ++i)
        f >> arbore[i].valoare;
    int in = 1;
    int sf = n;
    int in2 = n + 1;
    int sf2 = n;
    while(in <= sf || in2 < sf2)
    {
        int st, dr;
        if(in <= sf && in2 <= sf2) {
            if(arbore[in].valoare <= arbore[in2].valoare) {
                st = in;
                in++;
            }
            else {
                st = in2;
                in2++;
            }
        }
        else if(in <= sf) {
            st = in;
            in++;
        }
        else {
            st = in2;
            in2++;
        }
        if(in <= sf && in2 <= sf2) {
            if(arbore[in].valoare <= arbore[in2].valoare) {
                dr = in;
                in++;
            }
            else {
                dr = in2;
                in2++;
            }
        }
        else if(in <= sf) {
            dr = in;
            in++;
        }
        else {
            dr = in2;
            in2++;
        }
        sf2++;
        arbore[sf2].st = st;
        arbore[sf2].dr = dr;
        arbore[sf2].valoare = arbore[st].valoare + arbore[dr].valoare;
        rasp += arbore[sf2].valoare;
    }
    dfs(sf2, 0, 0);
    g << rasp << '\n';
    for(int i = 1; i <= n; ++i) {
        g << arbore[i].nivel << " " << arbore[i].valoare << '\n';
    }
    return 0;
}
