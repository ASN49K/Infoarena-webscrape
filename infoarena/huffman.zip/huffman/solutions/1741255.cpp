#include <iostream>
#include <fstream>
#include <algorithm>
#include <math.h>
#define MAX_HEAP_SIZE 1000001

using namespace std;
ifstream in;
ofstream out;
struct nod{
    unsigned long long int lu;
    unsigned long long int st;
    unsigned long long int dr;
};
nod coada1[2*MAX_HEAP_SIZE];
unsigned long long int n, pos[2*MAX_HEAP_SIZE], nr, c=1, T, lg[MAX_HEAP_SIZE], b[MAX_HEAP_SIZE];

int defeu (int k, long long cod, int nivel)
{
    if(coada1[k].st && coada1[k].dr)
    {
            defeu(coada1[k].st, cod*2, nivel+1);
            defeu(coada1[k].dr, cod*2+1, nivel+1);
    }
    else
    {
    lg[k]=nivel;
    b[k]=cod;
    }
}
int main()
{
    int st1=1, dr1=1, st2=0, dr2=0;
    in.open ("huffman.in");
    out.open ("huffman.out");
    in>>n;
    st2=n+1;dr2=n+1;
    for(int i=n;i<2*n;++i)
        coada1[i].lu=2e16;
    for(dr1 = 1;dr1<=n;++dr1)
    {
        in>>coada1[dr1].lu;
        pos[dr1]=c;
        ++c;
    }
    ///amu algoritmu propriu-zis
    nod r, k;
    int s, j;
    for(int i=n+1;i<2*n;++i)
    {
        ///luam doua cele mai scurte siruri
        if(coada1[st1].lu<coada1[st2].lu && st1 <=n)
        {
            r=coada1[st1];
            s=pos[st1];
            ++st1;
        }
        else
        {
            r=coada1[st2];
            s=pos[st2];
            ++st2;
        }
        if(coada1[st1].lu<coada1[st2].lu && st1 <=n)
        {
            k=coada1[st1];
            j=pos[st1];
            ++st1;
        }
        else
        {
            k=coada1[st2];
            j=pos[st2];
            ++st2;
        }
        coada1[dr2].st=s;
        coada1[dr2].dr=j;
        coada1[dr2].lu=r.lu+k.lu;
        T+=coada1[dr2].lu;
        pos[dr2]=c;
        ++dr2;
        ++c;
    }
    /*for(int i=1;i<2*n;++i)
        cout<<pos[i]<<" ";
        cout<<endl;
    for(int i =1;i<2*n;++i)
        cout<<coada1[i].st<<" "<<coada1[i].lu<<" "<<coada1[i].dr<<"\n";*/
    out<<T<<"\n";
    defeu(2*n-1, 0, 0);
    for(int i=1;i<=n;++i)
        out<<lg[i]<<" "<<b[i]<<"\n";
    in.close();
    out.close();
    return 0;
}
