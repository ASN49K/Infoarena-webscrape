#include <fstream>
#define nmax 1000002
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct muchie {
    long long st, dr, val;
}sir2[3 * nmax];

long long s;
long long sir1[nmax];
long long n, k = 0, l = 1, c = 1;

struct mem{
    long long bit, val;
}sir[nmax];

void dfs(int nod, long long b)
{
    if(nod <= n)
    {
        sir[nod].bit = b;
    }
    else
    {
        dfs(sir2[nod].dr, b+1);
        dfs(sir2[nod].st, b+1);
    }
}

void dfs2(int nod, int b)
{
    if(nod <= n)
    {
        sir[nod].val += (1<<b);
    }
    else
    {
        dfs2(sir2[nod].dr, b + 1);
        dfs2(sir2[nod].st, b + 1);
    }
}

int main()
{
    fin>>n;
    for(int i = 1; i <= n; i++)
        fin>>sir1[i];
    for(int i = 1; i < n; i++)
    {
        if((sir1[l + 1] <= sir2[c].val || c > k) && l + 1 <= n)
        {
            sir2[++k].val = sir1[l++];
            sir2[k].val += sir1[l++];
            sir2[k].st = l - 2;
            sir2[k].dr = l - 1;
            continue;
        }
        if((sir2[c + 1].val <= sir1[l] || l > n) && c + 1 <= k)
        {
            sir2[++k].val = sir2[c++].val;
            sir2[k].val += sir2[c++].val;
            sir2[k].st = n + c - 2;
            sir2[k].dr = n + c - 1;
            continue;
        }
        sir2[++k].val = sir2[c++].val;
        sir2[k].val += sir1[l++];
        if(sir1[l - 1] > sir2[c - 1].val)
        {
            sir2[k].dr = n + c - 1;
            sir2[k].st = l - 1;
        }
        else
        {
            sir2[k].dr = l - 1;
            sir2[k].st = n + c - 1;
        }
    }
    for(int i = 1; i <= k ; i++)
    {
        sir2[n + i] = sir2[i];
    }
    for(int i = n + 1; i <= n + k; i++)
    {
        dfs2(sir2[i].dr, 0);
    }
    long long sum = 0;
    dfs(n+k, 0);
    for(int i = 1; i <= k; i++)
        sum += sir2[i].val;
    fout<<sum<<"\n";
    for(int i = 1; i <= n; i++)
    {
        fout<<sir[i].bit<<" "<<sir[i].val<<"\n";
    }
    return 0;
}
