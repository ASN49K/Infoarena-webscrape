#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>

using namespace std;

struct Node {
    int weight, left_child, right_child, level;
    long long code;
} heap[2000100];

int n, lim, p1, p2, u1, u2;
int c[2000100];
long long w[2000100], b[2000100], lg;
int a[1000100];
int niv[2000100];
int wb[2000100][2];

bool compare(Node a, Node b) {
    return a.weight > b.weight;
}

void dfs(int nod, int nivel, long long bb) {
    niv[nod] = nivel;
    b[nod] = bb;
    if (wb[nod][1]) {
        dfs(wb[nod][1], nivel+1, bb<<1);
        dfs(wb[nod][0], nivel+1, (bb<<1)|1);
    }
}

int main() {
    ifstream fin("huffman.in");
    ofstream fout("huffman.out");

    fin >> n;
    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
    }

    lim = 2*n-1;
    p1 = 1;
    u1 = n;
    p2 = 1;
    u2 = 0;
    while (p1 <= u1 || p2 <= u2) {
        if (p1 <= u1 && (a[p1+1] <= w[c[p2]] || p2 > u2)) {
            w[++lim] = a[p1] + a[p1+1];
            lg += w[lim];
            wb[lim][0] = p1;
            wb[lim][1] = p1+1;
            c[++u2] = lim;
            a[p1+1] = lim;
            p1 += 2;
        }
        else if (p2 <= u2 && (p1 > u1 || w[c[p2+1]] <= a[p1])) {
            w[++lim] = w[c[p2]] + w[c[p2+1]];
            lg += w[lim];
            wb[lim][0] = c[p2];
            wb[lim][1] = c[p2+1];
            c[++u2] = lim;
            p2 += 2;
        }
        else if (p1 <= u1 && (p2 > u2 || a[p1] <= w[c[p2]])) {
            w[++lim] = a[p1];
            lg += w[lim];
            wb[lim][0] = p1;
            wb[lim][1] = c[p2];
            c[++u2] = lim;
            p1++;
            p2++;
        }
    }

    dfs(lim, 0, 0);
    lg -= w[lim];
    fout << lg << endl;
    for (int i = 1; i <= n; i++) {
        fout << niv[wb[i][0]] << " " << b[wb[i][0]] << endl;
    }

    fin.close();
    fout.close();

    return 0;
}
