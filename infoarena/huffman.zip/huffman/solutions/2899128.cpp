#include <bits/stdc++.h>
#define ll long long
#define Nmax 2000005
#define fr first
#define sc second
#define pii pair<int, int>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

int n, ap[Nmax], q[2][Nmax], st[2], dr[2], m[Nmax][2], lg[Nmax];
ll sum, cod[Nmax];

int extrage()
{
    int u;
    if((st[0]<=dr[0]) && (st[1]<=dr[1]))
    {
        if(ap[q[0][st[0]]] < ap[q[1][st[1]]])
        {
            u=q[0][st[0]];
            st[0]++;
        }
        else
        {
            u=q[1][st[1]];
            st[1]++;
        }
    }
    else if(st[0]<=dr[0])
    {
        u=q[0][st[0]];
        st[0]++;
    }
    else
    {
        u=q[1][st[1]];
        st[1]++;
    }
    return u;
}

void dfs(int x)
{
    if(x<=n)
        return;

    for(int i=0;i<2;i++)
    {
        lg[m[x][i]]=lg[x]+1;
        cod[m[x][i]]=cod[x]*2+i;
        dfs(m[x][i]);
    }
}

int main()
{
    fin >> n;
    st[0]=st[1]=1;
    for(int i=1;i<=n;i++)
    {
        fin >> ap[i];
        q[0][++dr[0]]=i;
    }

    for(int nod=n+1;nod<2*n;nod++)
    {
        int u1=extrage();
        int u2=extrage();

        ap[nod]=ap[u1]+ap[u2];
        m[nod][0]=u1;
        m[nod][1]=u2;
        q[1][++dr[1]]=nod;
    }
    dfs(2*n-1);
    for(int i=1;i<=n;i++)
        sum=sum+(ll)lg[i]*ap[i];
    fout << sum << '\n';
    for(int i=1;i<=n;i++)
        fout << lg[i] << ' ' << cod[i] << '\n';
    return 0;
}
