#include <bits/stdc++.h>

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

#define llg long long
#define int_pair std::pair <llg, int>

class HuffmanCoding {
public:
    std::vector <int> lg;
    std::vector <llg> bits;
    HuffmanCoding(const std::vector <int>& frequencies) {
        lg.resize(frequencies.size()), bits.resize(frequencies.size());
        buildTree(frequencies);
        DFS(tree.size()-1);
    }

private:
    void buildTree(const std::vector <int>& frequencies) {
        tree.resize(frequencies.size());
        std::queue <int> queue1, queue2;
        for (int i=0; i<tree.size(); ++i)
            tree[i].rang = frequencies[i], queue1.push(i);

        int min[2];
        while (queue1.size() + queue2.size() >= 2) {
            for (int i=0; i<2; ++i) {
                if (queue1.empty()) min[i] = queue2.front(), queue2.pop();
                else if (queue2.empty()) min[i] = queue1.front(), queue1.pop();
                else if (tree[queue1.front()].rang < tree[queue2.front()].rang) min[i] = queue1.front(), queue1.pop();
                else min[i] = queue2.front(), queue2.pop();
            }   tree.push_back(node(tree[min[0]].rang + tree[min[1]].rang, min[0], min[1]));
            queue2.push(tree.size()-1);
        }
    }

    void DFS(int vertex, llg encoding = 0, int lvl = 0) {
        if (tree[vertex].son[0] == -1 && tree[vertex].son[1] == -1)
            {lg[vertex] = lvl; bits[vertex] = encoding; return;}

        for (int i=0; i<2; ++i)
            if (tree[vertex].son[i] != -1)
                DFS(tree[vertex].son[i], 2*encoding + i, lvl+1);
    }
protected:
    struct node {
        node(llg rang = 0, int son0 = -1, int son1 = -1) : rang(rang) {son[0] = son0; son[1] = son1;}
        llg rang; int son[2];
    };
public:
    std::vector <node> tree;
};

const int MAXN = 1e6 + 5;
const llg INF  = 1e18;

int N;
std::vector <int> freq;

std::ifstream input ("huffman.in");
OutParser     output("huffman.out");

void readInput() {
    input >> N;
    freq.resize(N);
    for (auto &it:freq)
        input >> it;
}

void solveInput() {
    HuffmanCoding huffman(freq);

    llg sum = 0;
    for (int i=0; i<huffman.tree.size(); ++i)
        sum += huffman.tree[i].rang;
    for (auto &it:freq)
        sum -= it;
    output << sum << '\n';

    for (int i=0; i<N; ++i)
        output << huffman.lg[i] << ' ' << huffman.bits[i] << '\n';
}

int main()
{
    readInput();
    solveInput();

    return 0;
}
