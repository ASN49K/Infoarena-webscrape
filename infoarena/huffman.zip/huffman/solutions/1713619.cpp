#include<cstdio>
#define MAXN 1000010
#define INF 1000000000000000000LL
using namespace std;
struct node{
    long long value;
    int sons[2];
};
node nodes[2*MAXN];
long long Queue[2][MAXN],base10[2*MAXN];
int left[2],right[2],length[2*MAXN];
void DFS(int position,long long code,int level){
    if(nodes[position].sons[0]!=0){
        DFS(nodes[position].sons[0],2*code,level+1);
        DFS(nodes[position].sons[1],2*code+1,level+1);
    }
    length[position]=level;
    base10[position]=code;
}
int main(){
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    int n,i,j,current,which;
    long long best,answer=0;
    scanf("%d",&n);
    current=n;
    for(i=1;i<=n;i++){
        scanf("%lld",&nodes[i].value);
        Queue[0][i]=i;
    }
    left[0]=left[1]=1;
    right[0]=n;
    while(left[0]+left[1]<=right[0]+right[1]){
        current++;
        for(i=0;i<2;i++){
            which=0;
            best=INF;
            for(j=0;j<2;j++)
                if(nodes[Queue[j][left[j]]].value<best&&left[j]<=right[j]){
                    best=nodes[Queue[j][left[j]]].value;
                    which=j;
                }
            nodes[current].sons[i]=Queue[which][left[which]];
            nodes[current].value+=nodes[Queue[which][left[which]]].value;
            left[which]++;
        }
        answer+=nodes[current].value;
        right[1]++;
        Queue[1][right[1]]=current;
    }
    DFS(current,0,0);
    printf("%lld\n",answer);
    for(i=1;i<=n;i++)
        printf("%lld %lld\n",length[i],base10[i]);
    return 0;
}
