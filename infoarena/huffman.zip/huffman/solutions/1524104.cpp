#include <bits/stdc++.h>

using namespace std;

ifstream f("huffman.in");
ofstream g("huffman.out");

struct node{
    node *ls;
    node *rs;
    int inf;
    long long poz = 0;
};

int n, v;
priority_queue< pair<long long, node *> > q;

pair<int, long long> b[1000005];
int fg[1000005];

void dfs(node *start, long long p, int niv) {
    if(start->poz) {
        b[start->poz].first = niv;
        b[start->poz].second = p;
        fg[start->poz] = start->inf;
        return ;
    }

    dfs(start->ls, p * 2, niv + 1);
    dfs(start->rs, p * 2 + 1, niv + 1);
}

int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++) {
        node *p = new node;
        p->poz = i;
        f >> p->inf;
        q.push(make_pair(-p->inf, p));
    }

    while(q.size() > 1) {
        node *fst = q.top().second; q.pop();
        node *snd = q.top().second; q.pop();

        node *aux = new node;
        aux->ls = fst; aux->rs = snd;
        aux->inf = fst->inf + snd->inf;
        q.push(make_pair(-aux->inf, aux));
    }

    node *start = q.top().second;
    dfs(start, 0, 0);

    long long s = 0;
    for(int i = 1; i <= n; i ++) {
        s += b[i].first * fg[i];
    }
    g << s << "\n";
    for(int i = 1; i <= n; i ++) {
        g << b[i].first << " " << b[i].second << "\n";
    }
    return 0;
}
