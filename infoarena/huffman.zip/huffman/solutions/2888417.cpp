#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct nod {
    int frecventa;
    nod *dreapta;
    nod *stanga;
};

queue<nod *> initial, intern;
vector<vector<long long>> rezultat(1000000);
int nrElemente;

nod *furnizare() {
    nod *val;
    if (initial.empty()) {
        val = intern.front();
        intern.pop();
        return val;
    } else if (intern.empty()) {
        val = initial.front();

        initial.pop();
        return val;
    } else if (initial.front()->frecventa < intern.front()->frecventa) {
        val = initial.front();
        initial.pop();
        return val;
    } else {
        val = intern.front();
        intern.pop();
        return val;
    }
}

///fac recursiv cu &nivel si dupa fac nivel + 1, trebuie sa vad la reprezentarea binara cum fac

void configurare(nod *&curent, long long reprezentare, long long nivel) {
    if (curent->dreapta != NULL) {
        configurare(curent->stanga, reprezentare << 1, nivel + 1);
    }
    if (curent->stanga != NULL) {
        configurare(curent->dreapta, (reprezentare << 1) | 1, nivel + 1);
    }
    if (curent->stanga == NULL)
        rezultat[nivel].push_back(reprezentare);
}

int main() {
    long long index, suma = 0;
    int valoare, nivel, reprezentare = 0;
    fin >> nrElemente;
    for (index = 0; index < nrElemente; index += 1) {
        fin >> valoare;
        nod *nod1 = new nod;
        nod1->stanga = NULL;
        nod1->dreapta = NULL;
        nod1->frecventa = valoare;
        initial.push(nod1);
    }
    nivel = 0;
    while (initial.size() > 1 or intern.size() > 1) {
        nrElemente += 1;
        nod *nodParinte = new nod;
        nodParinte->dreapta = furnizare();
        nodParinte->stanga = furnizare();
        nodParinte->frecventa = nodParinte->dreapta->frecventa + nodParinte->stanga->frecventa;
        intern.push(nodParinte);
        suma += nodParinte->frecventa;
    }
    fout << suma << "\n";
    configurare(intern.front(), reprezentare, nivel);
    for (index = rezultat.size() - 1; index >= 1; index -= 1) {
        for (int i = 0; i < rezultat[index].size(); i += 1) {
            fout << index << " " << rezultat[index][i] << "\n";
        }
    }
    return 0;
}