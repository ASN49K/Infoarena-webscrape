#include <iostream>
#include <vector>
#include <stack>
#include <queue>
#include <fstream>

#define nMax 1000003

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");


int lg[nMax];
unsigned long long cod[nMax];

class huffman{
public:
    int lf, rg;
    unsigned long long data;
    huffman() : lf(0), rg(0), data(0) {}
    huffman(unsigned long long _data) : lf(0), rg(0), data(_data) {}
    huffman(int _lf, int _rg, unsigned long long _data) : lf(_lf), rg(_rg), data(_data) {}
    void comb(int _lf, int _rg);
}v[2 * nMax];

void huffman :: comb(int _lf, int _rg){
    data = v[_lf].data + v[_rg].data;
    lf = _lf;
    rg = _rg;
    return;
}

void dfs(int poz, int deep, unsigned long long code){
    if(!v[poz].lf){
        lg[poz] = deep;
        cod[poz] = code;
        return;
    }
    dfs(v[poz].lf, deep + 1, code * 2);
    dfs(v[poz].rg, deep + 1, code * 2 + 1);
    return;
}

int main(){
    int n, lf, rg, sum = 0;
    fin>>n;
    for(int i = 1; i <= n; i ++){
        fin>>v[i].data;
    }
    v[n + 1].comb(1, 2);
    int m = 1, i = 3, j = 1;
    while(m < n){
        if(i <= n &&  v[i].data <= v[n + j].data){
            lf = i;
            ++ i ;
        }
        else{
            lf = n + j;
            ++ j;
        }
        if(i > n || j > m){
            if(j > m){
                rg = i;
                ++ i ;
            }
            else{
                rg = n + j;
                ++ j;
            }
        }
        else{
            if(v[i].data <= v[n + j].data){
                rg = i;
                ++ i ;
            }
            else{
                rg = n + j;
                ++ j;
            }
        }
        v[n + m + 1].comb(lf, rg);
        ++ m;
    }
    dfs(2 * n - 1, 0, 0);
    for(int i = n + 1; i < 2 * n; i ++){
        sum += v[i].data;
    }
    fout<<sum<<"\n";
    for(int i = 1; i <= n; i ++){
        fout<<lg[i]<<" "<<cod[i]<<"\n";
    }
	return 0;
}
