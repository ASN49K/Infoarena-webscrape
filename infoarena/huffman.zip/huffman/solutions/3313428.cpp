#include <fstream>
using namespace std;

ifstream cin("huffman.in");
ofstream cout("huffman.out");

#define int long long

int q1[1000001];
int fiu[1000001][2];
int v[1000001];
int lin[1000001];
int col[1000001];
int q2[1000001];
int nr,q1s,q2s,q1d,q2d,aux;

void gas(int &a){
    if(q1s>q1d){
        a=q2[q2s];q2s++;
    }else if(q2s>q2d){
        a=q1[q1s];q1s++;
    }else if(v[q1[q1s]]<v[q2[q2s]]){
        a=q1[q1s];q1s++;
    }else{
        a=q2[q2s];q2s++;
    }
}

void dfs(int nod,int l,int c){
    if(fiu[nod][0]){
        dfs(fiu[nod][0],l+1,2*c);
        dfs(fiu[nod][1],l+1,2*c+1);
    }else{
        lin[nod]=l;col[nod]=c;
        aux+=l*v[nod];
    }
}

signed main()
{
    int n,a,b,i;
    q1s=q2s=1;
    cin>>n;nr=n;
    nr=n;
	while(q1d<n){
		q1d++;
		q1[q1d]=q1d;
		cin>>v[q1d];
	}
	while(q1d+q2d-q1s-q2s>=0){
		gas(a);gas(b);
		q2d++;nr++;
		q2[q2d]=nr;
		v[nr]=v[a]+v[b];
		fiu[nr][0]=a;fiu[nr][1]=b;
	}
	dfs(nr,0,0);
	cout<<aux<<"\n";
	for(i=1;i<=n;i++){
        cout<<lin[i]<<" "<<col[i]<<"\n";
	}
    return 0;
}
