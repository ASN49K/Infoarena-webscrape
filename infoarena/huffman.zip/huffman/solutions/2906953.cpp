#include <bits/stdc++.h>
using namespace std;

ifstream fin ("huffman.in");
ofstream fout ("huffman.out");

struct {
    int st, dr, nivel;
    long long valoare;
}arbore[2000001];

int n;
long long rasp;


void dfs(int nod, int nivel, long long valoare) {
    if (nod <= n) {
        arbore[nod].nivel = nivel;
        arbore[nod].valoare = valoare;
        return;
    }
    dfs(arbore[nod].st, nivel + 1, valoare * 2);
    dfs(arbore[nod].dr, nivel + 1, valoare * 2 + 1);
}


int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
        fin >> arbore[i].valoare;
    fin.close();

    int start1 = 1, end1 = n;
    int start2 = n + 1, end2 = n;
    while (start1 <= end1 || start2 < end2)
    {
        int st, dr;
        if (start1 <= end1 && start2 <= end2) {
            if (arbore[start1].valoare <= arbore[start2].valoare) {
                st = start1;
                start1++;
            }
            else {
                st = start2;
                start2++;
            }
        }
        else if (start1 <= end1) {
            st = start1;
            start1++;
        }
        else {
            st = start2;
            start2++;
        }
        if (start1 <= end1 && start2 <= end2) {
            if (arbore[start1].valoare <= arbore[start2].valoare) {
                dr = start1;
                start1++;
            }
            else {
                dr = start2;
                start2++;
            }
        }
        else if (start1 <= end1) {
            dr = start1;
            start1++;
        }
        else {
            dr = start2;
            start2++;
        }

        end2++;
        arbore[end2].st = st;
        arbore[end2].dr = dr;
        arbore[end2].valoare = arbore[st].valoare + arbore[dr].valoare;
        rasp += arbore[end2].valoare;
    }
    dfs(end2, 0, 1);

    fout << rasp << '\n';
    for (int i = 1; i <= n; ++i) {
        fout << arbore[i].nivel << " " << arbore[i].valoare << '\n';
    }
    fout.close();

    return 0;
}