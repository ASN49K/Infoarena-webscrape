#include <fstream>
#include <vector>
#include <set>

using namespace std;

#define int long long

struct node
{
    int st, dr, sum;
};

ifstream in("huffman.in");
ofstream out("huffman.out");
int n, cnt;
node v[2000005];
multiset<pair<int, int>> s;

signed main()
{
    in>>n;

    int x;
    for(int i = 1; i<=n; i++)
    {
        in>>x;

        s.insert({x, i});
    }

    cnt = n;
    while(s.size() >= 2)
    {
        pair<int, int> a = (*s.begin());
        s.erase(s.begin());

        pair<int, int> b = (*s.begin());
        s.erase(s.begin());

        cnt++;
        v[cnt].st = a.second;
        v[cnt].dr = b.second;
        v[cnt].sum = a.first + b.first;

        s.insert({v[cnt].sum, cnt});
    }

    return 0;
}
