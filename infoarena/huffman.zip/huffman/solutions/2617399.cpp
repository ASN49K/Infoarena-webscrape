#include <fstream>

using namespace std;

const int N = 1e6;

ifstream in("huffman.in");
ofstream out("huffman.out");

int nr, n, st[2 * N], dr[2 * N], p, u, q[2 * N], lg[N * 2];
long long codul[N], val[2 * N];

void reunesc(int x, int y)
{
    ++nr;
    val[nr] = val[x] + val[y];
    st[nr] = x;
    dr[nr] = y;
    q[++u] = nr;
}

void preordine(int x)
{
    //out << x << " ";
    if (st[x] != 0)
    {
        codul[st[x]] = codul[x] * 2;
        lg[st[x]] = 1 + lg[x];
        preordine(st[x]);
    }
    if (dr[x] != 0)
    {
        codul[dr[x]] = codul[x] * 2 + 1;
        lg[dr[x]] = 1 + lg[x];
        preordine(dr[x]);
    }
}

int main()
{
    in >> n;
    for (int i = 1; i <= n; i++)
    {
        in >> val[i];
    }
    u = -1;
    nr = n;
    int i = 3;
    reunesc(1, 2);
    while (i <= n || p < u)
    {
        if (i <= n && val[i] <= val[q[p]])
        {
            if (i < n && val[i + 1] <= val[q[p]])
            {
                reunesc(i, i + 1);
                i += 2;
            }
            else
            {
                reunesc(i++, q[p++]);
            }
        }
        else
        {
            if (i <= n && (p == u || val[i] <= val[q[p + 1]]))
            {
                reunesc(q[p++], i++);
            }
            else
            {
                reunesc(q[p], q[p + 1]);
                p += 2;
            }
        }
    }
    //codul[nr] = 1;
    preordine(nr);
    long long sum = 0;
    for (int i = n + 1; i <= nr; i++)
    {
        sum += val[i];
    }
    out << sum << "\n";
    for (int i = 1; i <= n; i++)
    {
        out << lg[i] << " " << codul[i] << "\n";
    }
    out.close();
    return 0;
}