#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
using namespace std;
int n,lg;
int fromBinaryToDecimal(vector<int>binary)
{
    int rez=0,p=0;
    for(int i=binary.size()-1;i>=0;i--,p++)
    {
        rez+=(binary[i]<<p);
    }
    return rez;
}
pair<int,int> sol[1000002];
class arboreBinar
{
private:

public:
    arboreBinar* left;
    arboreBinar* right;
    int frequency;
    int idx;
    vector<int>binaryNR;

    arboreBinar(int freq,arboreBinar*lChild,arboreBinar*rChild,int inIndex)
    {
        this->frequency=freq;
        this->idx=inIndex;

        this->left=lChild;
        this->right=rChild;
    }
    void printCodifiedObjects(arboreBinar*node,int niv)
    {
        if(node->left==NULL&&node->right==NULL)
        {
            sol[node->idx]=make_pair(niv,fromBinaryToDecimal(binaryNR));
            return;
        }

        if(node->left!=NULL)
        {
            binaryNR.push_back(0);
            printCodifiedObjects(node->left,niv+1);
            binaryNR.pop_back();
        }

        if(node->right!=NULL)
        {
            binaryNR.push_back(1);
            printCodifiedObjects(node->right,niv+1);
            binaryNR.pop_back();
        }
    }
};
priority_queue <pair<int,arboreBinar*> > valFreq;
void citire()
{
    scanf("%d",&n);
    int aux;
    for(int i=0; i<n; i++)
    {
        scanf("%d",&aux);
        valFreq.push(make_pair(-aux,new arboreBinar(aux,NULL,NULL,i+1)));
    }
}
arboreBinar*root;
void buildArb()
{
    while(valFreq.size()>1)
    {
        arboreBinar*left=valFreq.top().second;
        valFreq.pop();

        arboreBinar*right=valFreq.top().second;
        valFreq.pop();


        root=new arboreBinar(left->frequency+right->frequency,left,right,0);
        lg+=root->frequency;
        valFreq.push(make_pair(-root->frequency,root));
    }
}

int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    citire();
    buildArb();
    vector<int>a;
    a.push_back(1);
    a.push_back(1);
    a.push_back(1);
    printf("%d\n",lg);
    root->printCodifiedObjects(root,0);
    for(int i=1;i<=n;i++)
    {
        printf("%d %d\n",sol[i].first,sol[i].second);
    }
    return 0;
}
