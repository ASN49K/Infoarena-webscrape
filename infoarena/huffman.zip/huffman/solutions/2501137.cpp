#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

long long code[1000010], sol, st[2000010], dr[2000010], niv[1000010];
long long s1, s2, s3;
int n, i, j, aux, f[2000010];

void dfs(long long nod, long long nivel, long long cod){
    if(st[nod]){
        dfs(st[nod], nivel+1, 1LL*cod*2);
    }
    if(dr[nod]){
        dfs(dr[nod], nivel+1, 1LL*cod*2+1);
    }
    if(nod>=1 && nod<=n){
        niv[nod]=nivel;
        code[nod]=cod;
        sol+=1LL*niv[nod]*f[nod];
    }
}


int main(){
    fin>>n;
    for(i=1; i<=n; i++){
        fin>>f[i];
        f[n+i]=1LL*1000000010;
    }
    i=1;
    j=n+1;
    aux=n;
    while(aux<2*n+1){
        /// la fiecare pas luam suma celor mai mici 2 numere
        if(i+1>n){
            s1=1LL*1000000010;
        }else{
            s1=f[i]+f[i+1];
        }
        if(j>aux || i>n){
            s2=1LL*1000000010;
        }else{
            s2=f[i]+f[j];
        }
        if(j+1>aux){
            s3=1LL*1000000010;
        }else{
            s3=f[j]+f[j+1];
        }

        if(s1<=s2 && s1<=s3){
            aux++;
            st[aux]=i;
            dr[aux]=i+1;
            f[aux]=s1;
            i+=2;
        }else{
            if(s2<=s1 && s2<=s3){
                aux++;
                st[aux]=i;
                dr[aux]=j;
                f[aux]=s2;
                i++;
                j++;
            }else{
                /// s3 este cea mai mica
                aux++;
                st[aux]=j;
                dr[aux]=j+1;
                f[aux]=s3;
                j+=2;
            }
        }
    }
    dfs(2*n-1, 0, 0);
    fout<<(long long)sol<<"\n";
    for(i=1; i<=n; i++){
        fout<<niv[i]<<" "<<code[i]<<"\n";
    }
}
