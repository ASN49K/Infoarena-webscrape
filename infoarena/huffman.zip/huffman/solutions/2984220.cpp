#include <bits/stdc++.h>
using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

queue <int> q1, q2;
long long v[2000001];
int st[2000001], dr[2000001];

int best()
{
    int x;
    if(!q1.size())
    {
        x = q2.front();
        q2.pop();
    }
    else if(!q2.size())
    {
        x = q1.front();
        q1.pop();
    }
    else if(v[q1.front()] < v[q2.front()])
    {
        x = q1.front();
        q1.pop();
    }
    else
    {
        x = q2.front();
        q2.pop();
    }
    return x;
}

long long val[2000001];
int len[2000001];

void dfs(int nod)
{
    if(st[nod])
    {
        val[st[nod]] = val[nod] * 2;
        len[st[nod]] = len[nod] + 1;
        dfs(st[nod]);
    }
    if(dr[nod])
    {
        val[dr[nod]] = val[nod] * 2 + 1;
        len[dr[nod]] = len[nod] + 1;
        dfs(dr[nod]);
    }
}

int main()
{
    int n;
    in >> n;
    for(int i = 1; i <= n; i++)
    {
        in >> v[i];
        q1.push(i);
    }
    while(q1.size() + q2.size() > 1)
    {
        int p1, p2;
        p1 = best();
        p2 = best();
        v[++n] = v[p1] + v[p2];
        st[n] = p1;
        dr[n] = p2;
        q2.push(n);
    }
    dfs(n);
    long long rez = 0;
    for(int i = (n + 1) / 2 + 1; i <= n; i++)
        rez += v[i];
    out << rez << '\n';
    for(int i = 1; i <= (n + 1) / 2; i++)
        out << len[i] << " " << val[i] << '\n';
    return 0;
}
