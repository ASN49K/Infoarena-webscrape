#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#define NMAX 1000001

using namespace std;

struct node {
    int index = -1, fq = 0;
    node* left = nullptr, * right = nullptr;
    bool operator()(node* x,node* y) {
        return x->fq > y->fq;
    }
};

int freq[NMAX] = { 0 }, n;
pair<int, int> res[NMAX];

node* newNode(node* x, node* y) {
    node* e = new node();
    e->left = x;
    e->right = y;
    e->fq = x->fq + y->fq;

    return e;
}

node* Huffman() {
    priority_queue<node*, vector<node*>, node> pq;
    for (int i = 0;i < n;++i) {
        node* e = new node();
        e->index = i;
        e->fq = freq[i];
        pq.push(e);
    }
    while (pq.size() > 1) {
        node* x = pq.top();
        pq.pop();
        node* y = pq.top();
        pq.pop();
        node* e = newNode(x, y);
        pq.push(e);
    }

    return pq.top();
}

void dfs(node* root,int len,int val) {
    if (root->index != -1) {
        res[root->index] = { len,val };
        return;
    }
    dfs(root->left, len + 1, (val << 1) | 0);
    dfs(root->right, len + 1, (val << 1) | 1);
}

void erase(node* root) {
    if (root == nullptr) return;
    erase(root->left);
    erase(root->right);
    delete root;
}

int main() {
    
    ifstream fin("huffman.in");
    ofstream fout("huffman.out");

    fin >> n;
    for (int i = 0;i < n;++i)
        fin >> freq[i];

    node* root = Huffman();
    dfs(root, 0, 0);

    int lg = 0;
    for (int i = 0;i < n;++i)
        lg += freq[i] * res[i].first;

    fout << lg << '\n';

    for (int i = 0;i < n;++i)
        fout << res[i].first << ' ' << res[i].second << '\n';

    erase(root);

    return 0;
}