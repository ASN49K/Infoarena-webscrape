#include <bits/stdc++.h>

using namespace std;


long long v[2000005];

typedef bool (*comp)(int,int);
bool compare(int a, int b)
{
   return (v[a]>=v[b]);
}

std::priority_queue<int,std::vector<int>, comp> pq(compare);

int n,nr;
long long s;

int mu[2000005][2];

long long rez[1000005];

int lung[1000005];

void dfs(int ind_nod,long long cod,int l){
    if(ind_nod<=n){
        rez[ind_nod]=cod;
        lung[ind_nod]=l;
        return;
    }
    dfs(mu[ind_nod][0],cod<<1,l+1);
    dfs(mu[ind_nod][1],(cod<<1)|1,l+1);
}

int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&v[i]);
        pq.push(i);
    }
    nr=n;
    while(pq.size()>1){
        int a,b;
        a=pq.top();
        pq.pop();
        b=pq.top();
        pq.pop();
        int c;
        nr++;
        c=nr;
        v[c]=v[a]+v[b];
        pq.push(c);
        mu[nr][0]=a;
        mu[nr][1]=b;
        s+=v[c];
    }
    dfs(nr,0,0);
    printf("%d\n",s);
    for(int i=1;i<=n;i++)
        printf("%d %lld\n",lung[i],rez[i]);
    return 0;
}
