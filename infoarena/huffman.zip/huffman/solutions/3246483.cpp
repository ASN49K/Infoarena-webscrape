#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

struct node
{
    i64 cost;
    int parent;
    i64 path;
    int path_size;

    bool is_right;
};
vector<node>nodes;
i64 sol;

queue<int>q[2];
int get_min_erase()
{
    int rez=0;
    if(q[0].empty())
    {
        rez=q[1].front();
        q[1].pop();
    }
    else if(q[1].empty())
    {
        rez=q[0].front();
        q[0].pop();
    }
    else if(nodes[q[0].front()].cost < nodes[q[1].front()].cost)
    {
        rez=q[0].front();
        q[0].pop();
    }
    else
    {
        rez=q[1].front();
        q[1].pop();
    }
    return rez;
}
int main()
{
    ifstream cin("huffman.in");
    ofstream cout("huffman.out");
    int n;
    cin>>n;
    nodes.reserve(2*n-1);
    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;
        nodes.push_back({x,-1,-1,-1});
        q[0].push(i);
    }
    for(int i=1;i<n;i++)
    {
        int x=get_min_erase();
        int y=get_min_erase();
        int z=(int)nodes.size();
        //nodes[x].parent=z;
        //nodes[y].parent=z;
        //nodes[x].is_right=true;
        //nodes[y].is_right=false;
        q[1].push(z);
        nodes.push_back({nodes[x].cost+nodes[y].cost,-1,0,0});
    }
    assert(nodes.size()==nodes.capacity());

    for(int i=2*n-3;i>=0;i--)
    {
        int t=nodes[i].parent;
        int parte=nodes[i].is_right;
        nodes[i].path=nodes[t].path<<1|parte;
        nodes[i].path_size=nodes[t].path_size+1;
        if(i<n)
        {
            sol+=1LL*nodes[i].path_size*nodes[i].cost;
        }
    }
    cout<<sol<<'\n';
    for(int i=0;i<n;i++)
    {
        cout<<nodes[i].path_size<<' '<<nodes[i].path<<'\n';
    }
    return 0;
}
