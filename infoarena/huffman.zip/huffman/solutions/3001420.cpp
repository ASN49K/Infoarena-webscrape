#include <bits/stdc++.h>

using namespace std;
ifstream in("huffman.in");
ofstream out("huffman.out");

long long n;

struct node {
    node* left;
    node* right;
    long long val;
    long long freq;
    node(node* _left, node *_right, long long _val, long long _freq) 
        : left(_left), 
        right(_right), 
        val(_val), 
        freq(_freq) {}

    ~node() {
        if (left) delete[] left;
        left = nullptr;

        if (right) delete[] right;
        right = nullptr;
    }
};

queue<node*> q[2];
long long lgmin;
pair<long long, long long> ans[1000005];

void dfs(node *nod, long long curr, long long dist) {

    if (nod->val != 0) {
        ans[nod->val] = make_pair(dist, curr);
        lgmin += dist * nod->freq;
        return;
    }

    dfs(nod->left, curr * 2, dist + 1);
    dfs(nod->right, curr * 2 + 1, dist + 1);
}

node* getMin() {
    node* unu;
    node* doi;

    if (q[0].empty()) {
        doi = q[1].front();
        q[1].pop();
        return doi;
    }  

    if (q[1].empty()) {
        unu = q[0].front();
        q[0].pop();
        return unu;
    } 

    unu = q[0].front();
    doi = q[1].front();
    if (unu->freq < doi->freq) {
        q[0].pop();
        return unu;
    } else {
        q[1].pop();
        return doi;
    }
}

int main() {
    in>>n;
    long long x;
    for (int i = 1; i <= n; i++) {
        in>>x;
        q[0].push(new node(nullptr, nullptr, i, x));
    }

    while (!q[0].empty() || q[1].size() != 1) {
        node* unu = getMin();
        node *doi = getMin();

        q[1].push(new node(unu, doi, 0LL, unu->freq + doi->freq));
    }

    dfs(q[1].front(), 0, 0);

    out<<lgmin<<'\n';
    for (int i = 1; i <= n; i++) {
        out<<ans[i].first<<" "<<ans[i].second<<'\n';
    }    
    
}