#include <bits/stdc++.h>

using namespace std;
typedef long long Int;
ifstream f("huffman.in");
ofstream g("huffman.out");
int n,i,top,lo,hi;
Int sol;
int main()
{
    f>>n;
    vector<Int> a(2*n+2,0);
    vector<int> st(2*n+2,0),dr(2*n+2,0),L(2*n+2,0),H(2*n+2,0);
    for(i=1; i<=n; i++)
        f>>a[i];
    a[n+1]=a[1]+a[2];
    st[n+1]=1;
    dr[n+1]=2;
    top=n+1;sol+=a[top];
    lo=3;
    hi=top;
    while(lo<n)
    {
        if(a[lo+1]<=a[hi])
        {
            top++;
            st[top]=lo;
            dr[top]=lo+1;
            a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
            lo+=2;
        }
        else if(hi<top&&a[hi+1]<=a[lo])
        {
            top++;
            st[top]=hi;
            dr[top]=hi+1;
            hi+=2;
            a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
        }
        else
        {
            top++;
            st[top]=lo;
            dr[top]=hi;
            a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
            lo++;
            hi++;
        }
    }
    while(lo==n)
    {
        if(hi<top&&a[hi+1]<=a[lo])
        {
            top++;
            st[top]=hi;
            dr[top]=hi+1;
            hi+=2;
            a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
        }
        else
        {
            top++;
            st[top]=lo;
            dr[top]=hi;
            a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
            lo++;
            hi++;
        }
    }
    while(hi<top)
    {
        top++;
        st[top]=hi;
        dr[top]=hi+1;
        hi+=2;
        a[top]=a[st[top]]+a[dr[top]];sol+=a[top];
    }
    g<<sol<<'\n';
    for(;top>n;top--)
    {
        L[st[top]]=L[dr[top]]=L[top]+1;
        H[st[top]]=2*H[top];
        H[dr[top]]=2*H[top]+1;
    }
    for(i=1; i<=n; i++)
        g<<L[i]<<' '<<H[i]<<'\n';
    return 0;
}
