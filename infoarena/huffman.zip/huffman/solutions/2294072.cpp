#include <bits/stdc++.h>
#define Nmax 1000005
#define type pair <ll,int>
#define value first
#define node second
#define ll long long

using namespace std;

ifstream f("huffman.in");
ofstream g("huffman.out");

ll v[Nmax];
int no[Nmax];
int ls[2*Nmax];
int rs[2*Nmax];
int N;
queue <type> q_intern;
queue <type> q_leaves;
ll ans;

inline bool cmp()
{
    if(q_leaves.empty()) return true;
    if(q_intern.empty()) return false;
    return q_intern.front()<q_leaves.front();
}

void DFS(int node, ll bit, int nr)
{
    if(!ls[node] and !rs[node])
    {
        v[node]=bit;
        no[node]=nr;
    }
    else
    {
        DFS(ls[node],bit<<1,nr+1);
        DFS(rs[node],(bit<<1)+1,nr+1);
    }
}

int main()
{
    f>>N;
    for(int i=1,x;i<=N;i++)
    {
        f>>x;
        q_leaves.push({1LL*x,i});
    }

    int curr_cnt=N;
    type new_node,node1,node2;

    while(q_intern.size()+q_leaves.size()!=1)
    {
        if(cmp())
        {
            node1=q_intern.front();
            q_intern.pop();
        }
        else
        {
            node1=q_leaves.front();
            q_leaves.pop();
        }

        if(cmp())
        {
            node2=q_intern.front();
            q_intern.pop();
        }
        else
        {
            node2=q_leaves.front();
            q_leaves.pop();
        }

        new_node={node1.value+node2.value,++curr_cnt};
        q_intern.push(new_node);
        ans+=new_node.value;
        ls[curr_cnt]=node1.node;
        rs[curr_cnt]=node2.node;
    }
    g<<ans<<'\n';

    DFS(curr_cnt,0,0);

    for(int i=1;i<=N;i++)
        g<<no[i]<<' '<<v[i]<<'\n';

    return 0;
}
