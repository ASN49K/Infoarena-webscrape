#include <iostream>
#include <fstream>
using namespace std;
ifstream si("huffman.in");
ofstream so("huffman.out");
#define maxn 1000005
#define inf 1LL*1000000000*1000000000
long long b[maxn], sol;
int lg[maxn], l[2], r[2];
int n, q[2][maxn], k;
struct nod {
	long long val;
	int f[2];
}nod[2*maxn];

void huffman(long nodul, long long cod, int nivel) {
	if(nod[nodul].f[0]) {
		huffman(nod[nodul].f[0], cod*2, nivel+1);
		huffman(nod[nodul].f[1], cod*2+1, nivel+1);
		return;
	}
	lg[nodul]=nivel;
	b[nodul]=cod;
}
void solve() {
	int p;
	long long m;
	k=n;
	l[0]=l[1]=1;
	r[0]=n;
	while(l[0]+l[1]<=r[0]+r[1]) {
		++k;
		for(int i=0; i<2; i++) {
			m=inf, p=0;
			for(int j=0; j<2; j++)
				if(nod[q[j][l[j]]].val<m&&l[j]<=r[j]) {
                    m=nod[q[j][l[j]]].val;
                    p=j;
                }
			nod[k].val+=m;
			nod[k].f[i]=q[p][l[p]++];
		}
		sol+=nod[k].val;
		q[1][++r[1]]=k;
	}
	huffman(k,0,0);
}
int main() {
	si>>n;
	for(int i=1; i<=n; i++){
		si>>nod[i].val;
		q[0][i]=i;
	}
	solve();
	so<<sol<<'\n';
	for(int i=1; i<=n; i++)
		so<<lg[i]<<' '<<b[i]<<'\n';
	return 0;
}
