#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
#define MAX 1000010
using namespace std;

long long f[2*MAX];
int tree[2*MAX];
int leftc[2*MAX];
int rightc[2*MAX];
int d[MAX];
long long c[MAX];
long long sum = 0;

queue<int> pq, pq2;

void compute_code(int node, int depth, long long code){
	if(!leftc[node]){
		d[node] = depth;
		c[node] = code;
		sum += depth * f[node];
	}
	else{
		compute_code(leftc[node], depth + 1, 2*code);
		compute_code(rightc[node], depth + 1, 2*code + 1);
	}

}

int qpop(){
	int ans;
	if(!pq.empty() && !pq2.empty()){
		if(f[pq.front()] < f[pq2.front()]){
			ans = pq.front();
			pq.pop();
		}
		else{
			ans = pq2.front();
			pq2.pop();
		}
	}
	else if(pq.empty()){
			ans = pq2.front();
			pq2.pop();
	}
	else{
			ans = pq.front();
			pq.pop();
	}

	return ans;
}

int main(){
	ifstream fin;
	ofstream fout;
	fin.open("huffman.in");
	fout.open("huffman.out"); 
	int m, n, q, a, b, i, j;

	fin >> n;
	for(int i=1; i <= n; ++i){
		fin >> f[i];
		pq.push(i);
	}

	int new_node;
	new_node = n;
	for(int idx = 1; idx <= n - 1; ++idx){
		i = qpop();
		j = qpop();
		++new_node;
		tree[i] = tree[j] = new_node;
		f[new_node] = f[i] + f[j];
		leftc[new_node] = i;
		rightc[new_node] = j;
		pq2.push(new_node);

	}
	int root = pq2.front();
	compute_code(root, 0, 0);
	fout << sum << "\n";
	for(register int i = 1; i<=n; ++i){
		fout << d[i] << " " << c[i] << " " << "\n";
	}

}