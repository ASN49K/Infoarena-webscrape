#include <iostream>
#include <stdio.h>
#include <vector>
#include <stack>
#include <queue>
#include <fstream>

#define nMax 1000003
#define bSize 2200005

#define MIN(a, b) (v[a].data < v[b].data ? (a ++): (b ++))
#define MINIM(a, b) ((a) < (b) ? (a): (b))

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");


int lg[nMax];
unsigned long long cod[nMax];
char buffer[bSize];

class huffman{
public:
    int lf, rg;
    unsigned long long data;
    huffman() : lf(0), rg(0), data(0) {}
    huffman(unsigned long long _data) : lf(0), rg(0), data(_data) {}
    huffman(int _lf, int _rg, unsigned long long _data) : lf(_lf), rg(_rg), data(_data) {}
    void comb(int _lf, int _rg);
}v[2 * nMax];

void huffman :: comb(int _lf, int _rg){
    data = v[_lf].data + v[_rg].data;
    lf = _lf;
    rg = _rg;
    return;
}

void dfs(int poz, int deep, unsigned long long code){
    if(!v[poz].lf){
        lg[poz] = deep;
        cod[poz] = code;
        return;
    }
    dfs(v[poz].lf, deep + 1, code * 2);
    dfs(v[poz].rg, deep + 1, code * 2 + 1);
    return;
}

int main(){
    int n, lf, rg;
    unsigned long long sum = 0;
    fin>>n;
    for(int i = 1; i <= n; i ++){
        fin>>v[i].data;
    }
    v[n + 1].comb(1, 2);
    int m = n + 1, i = 3, j = n + 1;
    lf = MIN(i, j);
    while(i <= n){
        if(j > m){
            rg = i;
            i ++;
        }
        else{
            rg = MIN(i, j);
        }
        v[++ m].comb(lf, rg);
        if(i > m){
            lf = j;
            j ++;
        }
        else{
            lf = MIN(i, j);
        }
    }
    for(++ m ; m < 2 * n; m ++, j += 2){
        v[m].comb(j,j + 1);
    }
    dfs(2 * n - 1, 0, 0);
    for(int i = n + 1; i < 2 * n; i ++){
        sum += v[i].data;
    }
    fout<<sum<<"\n";
    for(int i = 1; i <= n; i ++){
        fout<<lg[i]<<" "<<cod[i]<<"\n";
    }
	return 0;
}
