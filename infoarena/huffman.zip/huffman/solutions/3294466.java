//package huffman;

import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "huffman.in";
    static final String OUTPUT_FILE = "huffman.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        private long nextLong() {
            return Long.parseLong(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static class HuffmanTree {
        private Node root = null;

        public class Node {
            long frequency;
            Node left;
            Node right;

            Node(long frequency) {
                this.frequency = frequency;
            }

            public Node(Node left, Node right) {
                this.left = left;
                this.right = right;
                this.frequency = 0L;
                if (left != null) {
                    this.frequency += left.frequency;
                }
                if (right != null) {
                    this.frequency += right.frequency;
                }
            }
        }

        public HuffmanTree(long[] freq) {
            Queue<Node> heap = new PriorityQueue<>(Comparator.comparingLong(n0 -> n0.frequency));
            for (long f : freq) {
                Node node = new Node(f);
                heap.add(node);
            }

            while (!heap.isEmpty()) {
                Node left = heap.poll();
                if (heap.isEmpty()) {
                    root = left;
                    break;
                }
                Node right = heap.poll();
                Node merged = new Node(left, right);
                heap.add(merged);
            }
        }

        private long encode(List<String> container, Node node, String mask) {
            if (node.left == null && node.right == null) {
                container.add(mask);
                return mask.length() * node.frequency;
            }
            return encode(container, node.left, mask + "0") +
                    encode(container, node.right, mask + "1");
        }

        public long encode(PrintWriter writer) {
            List<String> container = new ArrayList<>();
            long lg = encode(container, root, "");
            writer.println(lg);
            for (String mask : container) {
                writer.println(mask.length() + " " + binaryToLong(mask));
            }
            return 0;
        }

        public long binaryToLong(String mask) {
            long l = 0L;
            for (int i = mask.length() - 1; i >= 0; --i) {
                l = (l << 1) | mask.charAt(i) - '0';
            }
            return l;
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static void solve(TokenizedReader reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        long[] freq = new long[n];
        for (int i = 0; i < n; ++i) {
            freq[i] = reader.nextLong();
        }
        HuffmanTree tree = new HuffmanTree(freq);
        tree.encode(writer);
    }
}