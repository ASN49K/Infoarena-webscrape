#include <bits/stdc++.h>

using namespace std;
ifstream in("huffman.in");
ofstream out("huffman.out");

int n;
long long v[2000005];
int l[2000005], r[2000005];
queue<int> q[2];
long long lgmin;
pair<long long, long long> ans[1000005];

void dfs(int nod, long long curr, long long dist) {

    if (l[nod] == 0 && r[nod] == 0) {
        ans[nod] = make_pair(dist, curr);
        lgmin += 1LL * dist * v[nod];
        return;
    }

    dfs(l[nod], curr * 2, dist + 1);
    dfs(r[nod], curr * 2 + 1, dist + 1);
}

int getMin() {
    int unu;
    int doi;

    if (q[0].empty()) {
        doi = q[1].front();
        q[1].pop();
        return doi;
    }

    if (q[1].empty()) {
        unu = q[0].front();
        q[0].pop();
        return unu;
    }

    unu = q[0].front();
    doi = q[1].front();
    if (v[unu] < v[doi]) {
        q[0].pop();
        return unu;
    } else {
        q[1].pop();
        return doi;
    }
}

int main() {
    in>>n;

    for (int i = 1; i <= n; i++) {
        in>>v[i];
        q[0].push(i);
    }

    while (!q[0].empty() || q[1].size() != 1) {
        int unu = getMin();
        int doi = getMin();
        v[++n] = v[unu] + v[doi];
        q[1].push(n);
        l[n] = unu;
        r[n] = doi;
    }

    dfs(q[1].front(), 0, 0);

    out<<lgmin<<'\n';
    for (int i = 1; i <= (n + 1) / 2; i++) {
        out<<ans[i].first<<" "<<ans[i].second<<'\n';
    }

}
