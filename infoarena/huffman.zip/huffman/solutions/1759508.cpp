#include<fstream>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
int n,l[2],r[2],i,q[2][1000001];
long long b[1000001],lg[1000001],sol,Min,inf=1000000000000000;
struct nod{
    long long v;
    int f[2];
}arb[2000002];
void dfs(int poz,long long cod,long long nivel){
      if (arb[poz].f[0]){
        dfs(arb[poz].f[0],cod*2,nivel+1);
        dfs(arb[poz].f[1],cod*2+1,nivel+1);
        return;
      }
      lg[poz]=nivel;
      b[poz]=cod;
}
void rezolva(){
     int p,i,j,k;
     k=n;
     l[0]=l[1]=1;
     r[0]=n;
     while(l[0]+l[1]<=r[0]+r[1]){
        k++;
        for (j=0;j<2;j++){
            p=0;
            Min=inf;
            for (i=0;i<2;i++)
              if (Min>arb[q[i][l[i]]].v && l[i]<=r[i]){
                     Min=arb[q[i][l[i]]].v;
                     p=i;
              }
             arb[k].f[j]=q[p][l[p]];
             arb[k].v+=arb[q[p][l[p]]].v;
             l[p]++;
        }
        sol+=arb[k].v;
        r[1]++;
        q[1][r[1]]=k;
     }
     dfs(k,0,0);
}
int main(){
    fin>>n;
    for (i=1;i<=n;i++){
        fin>>arb[i].v;
        q[0][i]=i;
    }
    fin.close();
    rezolva();
    fout<<sol<<'\n';
    for (i=1;i<=n;i++)
        fout<<lg[i]<<" "<<b[i]<<'\n';
    fout.close();
    return 0;
}
