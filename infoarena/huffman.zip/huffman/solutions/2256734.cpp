#include<iostream>
#include<fstream>
#include<queue>
  
using namespace std;
  
#define maxn 1000100
#define inf 1LL * 1000000000 * 1000000000
  
  
long dr[2*maxn],st[2*maxn];
long long value[2*maxn],lG;
queue <int> q1,q2;
int n;
long long b10[maxn];
long lg[maxn]; 
  
  
long m(){
    long long value1=inf,value2=inf;
    long sol;
    if(q1.size()>0)
        value1=value[ q1.front()];
    if(q2.size()>0)
        value2=value[q2.front()];
    if(value1<value2){
        sol=q1.front();
		q1.pop();
        return sol;
    }  
	sol=q2.front(); 
    q2.pop();
    return sol;
}
  
  
long buildTree(){
    ifstream in("huffman.in");
    int i,k;
    long long x; 
    in>>n; 
      
    for(i=1;i<=n;i++) {
        in>>x;
        value[i]=x;
        q1.push(i); 
    }  
    in.close();
      
    k=n;
    while(q1.size()>0 || q2.size()>1){  
       k++; 
       long l=m();
       long r=m();
       lG+=value[l]+value[r];
       value[k]=value[l]+value[r]; dr[k]=r; st[k]=l;
       q2.push(k);  
    }
    return q2.back(); 
}
  
  
void readTree(long poz, long long cod, long nivel){
    if(st[poz]!=0){
        readTree(st[poz],cod*2,nivel+1);
        readTree(dr[poz],cod*2+1,nivel+1);
        return;     
    }    
    lg[poz]=nivel;
    b10[poz]=cod;
}
  
  
int main(){
	FILE *out=fopen("huffman.out","w");
    readTree(buildTree(),0,0);
	fprintf(out,"%lld\n",lG);  
    for(int i=1;i<=n;i++) 
       fprintf(out,"%d lld",lg[i],b10[i]); 
	fclose(out);  
    return 0;
}
