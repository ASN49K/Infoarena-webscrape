#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
 
#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple
 
#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()
 
using namespace std;
using namespace __gnu_pbds;
 
using ll = long long;
using ld = long double;
using ull = unsigned long long;
 
template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);
 
template <class T> 
void re(T& x) {
    cin >> x;
}
 
template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}
 
template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}
 
template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}
 
template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);
 
template <class T> 
void wr(T x) {
    cout << x;
}
 
template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}
 
template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}
 
template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}
 
template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}
 
void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}
 
void set_scientific() {
    cout << scientific;
}
 
inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}
 
const ll inf = 2e18;
 
struct node {
    ll val;
    int idx;
    node *left, *right;
 
    node(ll _val = -1, ll _idx = -1): val(_val), idx(_idx), 
        left(nullptr), right(nullptr) {
    }
} *root;
 
struct answer {
    ll len, bin;
    int idx;
 
    bool operator < (const answer& e) const {
        return idx < e.idx;
    }
};
 
queue <node*> q1, q2;
 
vt <answer> aq;
 
node* get_min() {
    node* n_q1 = (len(q1)? q1.front() : new node(inf));
    node* n_q2 = (len(q2)? q2.front() : new node(inf));
 
    if (n_q1-> val < n_q2-> val) {
        q1.pop();
        return n_q1;
    }
 
    q2.pop();
    return n_q2;
}
 
void dfs(node* curr, ll depth, ll val) {
    if (curr-> idx != -1) {
        aq.pub({depth, val, curr-> idx});
    }
 
    if (curr-> left != nullptr) {
        dfs(curr-> left, depth + 1, val * 2);
    }
 
    if (curr-> right != nullptr)
        dfs(curr-> right, depth + 1, val * 2 + 1);
}
 
void solve() {
    /* Huffman coding (merge 2 mins 'till you got one element) */
    int n; re(n);
 
    /* Start with as many leaves as there are symbols. */
    /* Enqueue all leaf nodes into the first queue (in increasing order) */
    for (int i = 0; i < n; ++i) {
        int val; re(val);
        q1.em(new node(val, i));
    }
 
    /* While there is more than one node in the queues */
    ll res = 0;
    while (len(q1) + len(q2) > 1) {
        /* Dequeue the two nodes with the lowest weight by examining the fronts of both queues. */
        node* mn1 = get_min();
        node* mn2 = get_min();
        /* Create a new internal node with the two just-removed nodes as children */
        node* tmp = new node();
        tmp-> val = mn1-> val + mn2-> val;
        tmp-> left = mn1;
        tmp-> right = mn2;
        res += tmp->val;
        /* Enqueue the new node into the rear of the second queue. */
        q2.emplace(tmp);
    }
 
    root = q2.front();
    q2.pop();
 
    dfs(root, 0, 0);
    sort(all(aq));
    wr(res, '\n');
    for (int i = 0; i < n; ++i)
        wr(aq[i].len, ' ', aq[i].bin, '\n');
}
 
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
 
    Open("huffman");
 
    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}