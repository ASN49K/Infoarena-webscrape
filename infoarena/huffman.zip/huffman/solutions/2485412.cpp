#include <fstream>
#include <deque>
#define DIM 1000005

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

int n,i,x,lung[DIM];
long long cod[DIM];
pair<int, int> L[2*DIM];
deque< pair<long long, int> > c1,c2;

void dfs(int nod, long long c, int l)
{
    if (L[nod].first == 0)
        return;
    int fiu1 = L[nod].first; int fiu2 = L[nod].second;
    if (fiu1 <= n)
    {
        lung[fiu1] = l+1;
        cod[fiu1] = (c<<1);
    }
    if (fiu2 <= n)
    {
        lung[fiu2] = l+1;
        cod[fiu2] = (c<<1)+1;
    }
    dfs(fiu1, (c<<1), l+1); dfs(fiu2, (c<<1)+1, l+1);
}

int main()
{
    fin >> n;
    for (i=1; i<=n; i++)
    {
        fin >> x;
        c1.push_back(make_pair(x, i));
    }
    long long sol = 0;
    for (i=1; i<n; i++)
    {
        pair<long long, int> minim1, minim2;
        if (!c2.size())
        {
            minim1 = c1.front();
            c1.pop_front();
        }
        else
            if (!c1.size())
            {
                minim1 = c2.front();
                c2.pop_front();
            }
            else
                if (c1.front() <= c2.front())
                {
                    minim1 = c1.front();
                    c1.pop_front();
                }
                else
                {
                    minim1 = c2.front();
                    c2.pop_front();
                }
        if (!c2.size())
        {
            minim2 = c1.front();
            c1.pop_front();
        }
        else
            if (!c1.size())
            {
                minim2 = c2.front();
                c2.pop_front();
            }
            else
                if (c1.front().first <= c2.front().first)
                {
                    minim2 = c1.front();
                    c1.pop_front();
                }
                else
                {
                    minim2 = c2.front();
                    c2.pop_front();
                }
        long long val = minim1.first+minim2.first;
        L[i+n] = make_pair(minim1.second, minim2.second);
        c2.push_back(make_pair(val, i+n));
        sol += val;
    }
    fout << sol << "\n";
    dfs(2*n-1, 0, 0);
    for (i=1; i<=n; i++)
        fout << lung[i] << " " << cod[i] << "\n";
    return 0;
}
