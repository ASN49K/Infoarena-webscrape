#include <fstream>
using namespace std;
ifstream cin("huffman.in");
ofstream cout("huffman.out");

long long n,i,l,r,idx,cx,cy;
long long f[1000010],faux[1000010],fr[1000010];
long long solv[1000010];

int soll[1000010];
struct nod
{
  int idx;
  nod *l;
  nod *r;
}*a[1000010], *x,*y, *aux[1000010],*p, *root;

void dfs(nod *root, long long l, long long v)
{
    if(root->l==NULL && root->r==NULL)
    {
        soll[root->idx]=l;
        solv[root->idx]=v;
    }
    else
    {
        if(root->l!=NULL) dfs(root->l, l+1, (long long)2*v);
        if(root->r!=NULL) dfs(root->r, l+1, (long long)2*v+(long long)1);
    }
}

int main()
{
    cin>>n;
    for(i=1;i<=n;++i)
       {
         cin>>f[i];
         fr[i]=f[i];
       }

    f[n+1]=(long long)1000000000*(long long)1000000000;

    for(i=1;i<=n;++i)
    {
        a[i]=new nod;
        a[i]->l=NULL;
        a[i]->r=NULL;
        a[i]->idx=i;
    }

    l=1; r=0;
    idx=1;

    while(n-idx+1+r-l+1>1)
    {
        if(l<=r && faux[l]<f[idx])
        {
            --idx;
            f[idx]=faux[l];
            a[idx]=aux[l];
            ++l;
        }

        x=a[idx];
        cx=f[idx];
        ++idx;

        if(l<=r && faux[l]<f[idx])
        {
            --idx;
            f[idx]=faux[l];
            a[idx]=aux[l];
            ++l;
        }

        y=a[idx];
        cy=f[idx];
        ++idx;

        p=new nod;
        p->l=x;
        p->r=y;

        ++r;
        faux[r]=cx+cy;
        aux[r]=p;


        root=p;

    }

    dfs(root,0,0);

    long long suma=0;
    for(i=1;i<=n;++i)
        suma+=fr[i]*soll[i];

    cout<<suma<<"\n";

    for(i=1;i<=n;++i)
        cout<<soll[i]<<" "<<solv[i]<<"\n";
    return 0;
}
