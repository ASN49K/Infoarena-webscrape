#include<bits/stdc++.h>
using namespace std;
const int N=1000005;
long long sz[2*N];
struct Trie{
  int id;
  Trie (){
    this->child[0]=NULL;
    this->child[1]=NULL;
    id=0;
  }
  Trie* child[2];
};
queue<Trie*> q1;
queue<Trie*> q2;
Trie* root=NULL;
int idg=0;
Trie* getmin(){
  if(q1.empty()){
    Trie* ans=q2.front();
    q2.pop();
    return ans;
  }
  if(q2.empty()){
    Trie* ans=q1.front();
    q1.pop();
    return ans;
  }
  if(sz[q1.front()->id]<=sz[q2.front()->id]){
    Trie* ans=q1.front();
    q1.pop();
    return ans;
  }
  Trie* ans=q2.front();
  q2.pop();
  return ans;
}


long long cod[N];
int len[N];
long long ans=0;
void dfs(Trie *node,long long code,int ln){
  if(node->child[0]==NULL){
    cod[node->id]=code;
    len[node->id]=ln;
    ans+=1LL*ln*sz[node->id];
    return;
  }
  dfs(node->child[0],code*2LL,ln+1);
  dfs(node->child[1],code*2LL+1,ln+1);
}
int main()
{
  freopen("huffman.in","r",stdin);
  freopen("huffman.out","w",stdout);
  int n;
  cin>>n;
  for(int i=1;i<=n;i++){
    int v;
    cin>>v;
    Trie* nou = new Trie();
    nou->id=++idg;
    sz[nou->id]=v;
    q1.push(nou);
  }
  while(q1.size() +q2.size()>1){
    Trie* min1=getmin();
    Trie* min2=getmin();
    Trie* nou = new Trie();
    nou->child[0]=min1;
    nou->child[1]=min2;
    nou->id=++idg;
    sz[nou->id]=sz[min1->id]+sz[min2->id];
    q2.push(nou);
  }
  root=q2.front();
  dfs(root,0,0);
  cout<<ans<<"\n";
  for(int i=1;i<=n;i++){
    cout<<len[i]<<" "<<cod[i]<<"\n";
  }
  return 0;
}
