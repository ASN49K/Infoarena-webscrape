
#include <iostream>
#include <fstream>
#include <deque>
using namespace std;

ifstream  in("huffman.in");
ofstream  out("huffman.out");

const int NMAX=1e6+5;

deque<int>q1,q2;


struct nod{
    int f[2];
    long long val;
}graf[2*NMAX];


int n,lc[2*NMAX];
long long b10[2*NMAX];

void dfs(int node,long long cod, int nivel){
    b10[node]=cod;
    lc[node]=nivel;
    if(graf[node].f[0]){
        dfs(graf[node].f[0],cod<<1,nivel+1);
        dfs(graf[node].f[1],cod<<1|1,nivel+1);
    }
}
int main() {
    in>>n;
    for(int i=1;i<=n;i++){
        in>>graf[i].val;
        q1.push_back(i);
    }
    int k=n,s1=n,s2=0;
    long long sol=0;
    while(s1 +s2>=2){
        k++;
        for(int i=0;i<2;i++){
            long long ales;
            if(s2==0 ||  (s1>0 && graf[q1.front()].val<graf[q2.front()].val)){
                ales=q1.front();
                q1.pop_front();
                s1--;
            }
            else{
                ales=q2.front();
                q2.pop_front();
                s2--;
            }
            graf[k].val+=graf[ales].val;
            graf[k].f[i]=ales;

        }
        sol+=graf[k].val;
        q2.push_back(k);
        s2++;
    }
    dfs(k,0,0);
    out<<sol<<"\n";
    for(int i=1;i<=n;i++){
        out<<lc[i]<<" "<<b10[i]<<"\n";
    }
    return 0;
}