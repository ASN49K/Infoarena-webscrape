#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct Pair {
  int node;
  long long val;
  bool operator < (Pair o) const {
    if(val != o.val) {
      return val > o.val;
    } else {
      return node > o.node;
    }
  }
};

int const NMAX = 1000000;
int n;
int f[1 + NMAX];
long long ans[1 + NMAX];
long long len[1 + NMAX];
int le[1 + NMAX], ri[1 + NMAX];
long long sum;

void dfs(int from, long long code, int dist) {
  //cout << from << ": " << le[from] << " " << ri[from] << " " << code << "\n";
  if(from <= n) {
    ans[from] = code;
    len[from] = dist;
    sum += dist * f[from];
  } else {
    dfs(le[from], 2*code, dist+1);
    dfs(ri[from], 2*code+1, dist+1);
  }
}

int main() {
  ios_base::sync_with_stdio(false);
  fin.tie(NULL);

  fin >> n;
  priority_queue<Pair> q;
  for(int i = 1; i <= n; i++) {
    fin >> f[i];
    q.push({i, f[i]});
  }
  int index = n;
  for(int i = 1; i <= n-1; i++) {
    index++;
    Pair p1 = q.top(); q.pop();
    Pair p2 = q.top(); q.pop();
    le[index] = p1.node;
    ri[index] = p2.node;
    q.push({index, p1.val + p2.val});
    //cout << p1.node << " " << p2.node << " " << index << "\n";
  }
  int root = q.top().node;
  dfs(root, 0, 0);
  fout << sum << "\n";
  for(int i = 1; i <= n; i++) {
    fout << len[i] << " " << ans[i] << "\n";
  }
}
