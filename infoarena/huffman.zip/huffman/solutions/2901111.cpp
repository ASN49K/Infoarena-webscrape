#include <fstream>
#include <queue>

using namespace std;

ifstream fin( "huffman.in" );
ofstream fout( "huffman.out" );

const int MAXN = 1e6 + 1;
const long long INF = 1e18 + 1;

int size;
int lson[2 * MAXN];
int rson[2 * MAXN];
long long data[2 * MAXN];

queue<int> init, sums;

inline int get() {
  int x;

  if ( init.size() == 0 ) {
    x = sums.front();
	sums.pop();
    return x;
  }
  if ( sums.size() == 0 ) {
    x = init.front();
	init.pop();
    return x;
  }
  if ( data[init.front()] > data[sums.front()] ) {
	x = sums.front();
	sums.pop();
  } else {
	x = init.front();
	init.pop();
  }
  return x;
}

inline void addNode() {
  int x = get();
  int y = get();

  data[size] = data[x] + data[y];
  lson[size] = x;
  rson[size] = y;
  sums.push( size );
  ++size;
}

long long code[MAXN];
int len[MAXN];

long long acode;
int dep;

long long solve( int node ) {
  if ( !lson[node] ) {
    code[node] = acode;
    len[node] = dep;
	return 0;
  }

  ++dep;
  acode *= 2;
  long long a = solve( lson[node] );

  ++acode;
  long long b = solve( rson[node] );

  --dep;
  acode = (acode - 1) / 2;

  return data[node] + a + b;
}

int main() {
  int n;
  long long f;

  fin >> n;
  for ( int i = 1; i <= n; ++i ) {
	fin >> f;
	data[i] = f;
	init.push( i );
  }
  size = n + 1;
  while ( init.size() + sums.size() > 1 ) {
	addNode();
  }
  dep = acode = 0;
  fout << solve( get() ) << "\n";
  for ( int i = 1; i <= n; ++i ) {
    fout << len[i] << " " << code[i] << "\n";
  }
  fin.close();
  fout.close();
  return 0;
}
