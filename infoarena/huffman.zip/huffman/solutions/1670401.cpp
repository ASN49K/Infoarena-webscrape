#include <fstream>
#define upi {k++;v[k]=v[i]+v[i+1];t[i]=t[i+1]=k;s[0][k]=i;s[1][k]=i+1;i+=2;sol1+=v[k];}
#define upj {k++;v[k]=v[j]+v[j+1];t[j]=t[j+1]=k;s[0][k]=j;s[1][k]=j+1;j+=2;sol1+=v[k];}
#define upd {k++;v[k]=v[i]+v[j];t[i]=t[j]=k;s[0][k]=i;s[1][k]=j;i++;j++;sol1+=v[k];}
#define N 2000010
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

int v[N],t[N],s[2][N],n,i,j,k,sol1;
void afiseaza(long long,int,int);
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i];
    k=n;i=1;upi;j=n+1;
    for(;;)
    {
        if(i<n&&j<k)
        {
            if(v[i]+v[i+1]<v[i]+v[j]&&v[i]+v[i+1]<v[j]+v[j+1])upi else
            if(v[j]+v[j+1]<v[i]+v[j]&&v[j]+v[j+1]<v[i]+v[i+1])upj else
            upd
            continue;
        }
        if(i<n&&j==k)
        {
            if(v[i]+v[i+1]<v[i]+v[j])upi else
            upd
            continue;
        }
        if(j<k&&i==n)
        {
            if(v[j]+v[j+1]<v[i]+v[j])upj else
            upd
            continue;
        }
        if(j<k){upj continue;}
        if(i<n){upi continue;}
        if(i==n&&j==k){upd continue;}
        break;


    }
    g<<sol1<<'\n';
    afiseaza(0,0,2*n-1);
    return 0;
}
void afiseaza(long long cod,int lg,int poz)
{
    if(poz<=n)
    {
        g<<lg<<' '<<cod<<'\n';
        return;
    }
    afiseaza(2*cod,lg+1,s[0][poz]);
    afiseaza(2*cod+1,lg+1,s[1][poz]);
}
