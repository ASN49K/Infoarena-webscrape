#include <iostream>
#include<fstream>
#include<deque>
using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");
int nodes;

struct path_info
{
    long long formed;
};

path_info paths[1000000];//how we get to the huffman node


struct node
{
public:
    const int cost;
    const int index;
    node*left;
    node*right;

    node(int co,int id):cost(co),index(id)
    {
        left=nullptr;
        right=nullptr;
    }
    node(node*l,node*r):cost(l->cost+r->cost),index(0)
    {
        left=l;
        right=r;
    }

};
node*huffman_root;
deque<node*> original_nodes;
deque<node*>intermediate_nodes;

void read()
{
    in>>nodes;
    int aux;
    for(int i=0; i<nodes; i++)
    {
        in>>aux;
        node*newnode=new node(aux,i);
        original_nodes.push_back(newnode);
    }

}




void prt_hff()
{
    cout<<"original nodes"<<endl;
    for(int i=0; i<original_nodes.size(); i++)
        cout<<original_nodes[i]->cost<<" ";
    cout<<endl<<"intermediate nodes"<<endl;
    for(int i=0; i<intermediate_nodes.size(); i++)
        cout<<intermediate_nodes[i]->cost<<" ";
    cout<<endl;
}


node*get_min()
{
    if(original_nodes.size()==0)
    {
        node*to_return=intermediate_nodes[0];
        intermediate_nodes.pop_front();
        return to_return;
    }
    if(intermediate_nodes.size()==0)
    {
        node*to_return=original_nodes[0];
        original_nodes.pop_front();
        return to_return;
    }
    if(intermediate_nodes[0]->cost<original_nodes[0]->cost)
    {
        node*to_return=intermediate_nodes[0];
        intermediate_nodes.pop_front();
        return to_return;
    }
    else
    {
        node*to_return=original_nodes[0];
        original_nodes.pop_front();
        return to_return;
    }

}

void create_huffman()
{

    while(original_nodes.size() || intermediate_nodes.size()>1)
    {

        node*a=get_min();
        node*b=get_min();
        node*newnode=new node(a,b);
        intermediate_nodes.push_back(newnode);


    }
    huffman_root=intermediate_nodes[0];

    // prt_hff();
}

long long sum=0;
void set_nodes(node*root,long long formed,int pth)
{
    if(root->left==nullptr && root->right==nullptr)
    {
        sum+=pth*root->cost;
        paths[root->index].formed=formed;
        //paths[root->index].path_length=pth;
    }
    else
    {
        if(root->left)
        {
            set_nodes(root->left,formed<<1,pth+1);
        }
        if(root->right)
        {
            set_nodes(root->right,(formed<<1)+1,pth+1);
        }

    }

}


void prt_result()
{
    out<<sum<<'\n';
    for(int i=0; i<nodes; i++)
    {
       // out<<paths[i].path_length<<" "<<paths[i].formed<<'\n';
    }



}


int main()
{
    read();
    create_huffman();
    set_nodes(huffman_root,0,0);
    cout<<"total len "<<sum<<endl;
    prt_result();
    return 0;
}
