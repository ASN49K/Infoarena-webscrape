#include<bits/stdc++.h>
using namespace std;

const int maxN=(1e6)+5;


deque<pair<int,int> > q,q2;
//vector<pair<int,pair<int,long long> > > sol;
pair<int,long long> sol[maxN];


bool cmp(pair<int,pair<int,int> > a,pair<int,pair<int,int> > b)
{
    return a.second.second<b.second.second;
}

int g[maxN][2],n;

int frecv[maxN];

long long ans=0;

void dfs(int node,int len,long long code)
{
    if(node<=n)
    {
        sol[node]=make_pair(len,code);
        ans=ans+1LL*frecv[node]*len;

        return;
    }
    dfs(g[node-n][0],len+1,code*2LL);
    dfs(g[node-n][1],len+1,code*2LL+1LL);

}

char buff[100005];
const int dim=(1e5);
int pos=0;

void read(int &nr)
{
    nr=0;
    while(!isdigit(buff[pos]))
    {
        pos++;
        if(pos==dim)
        {
            pos=0;
            fread(buff,1,dim,stdin);
        }
    }

    while(isdigit(buff[pos]))
    {
        nr=nr*10+buff[pos]-'0';
        pos++;
        if(pos==dim)
        {
            pos=0;
            fread(buff,1,dim,stdin);
        }
    }
}
int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);


    fread(buff,1,dim,stdin);

    read(n);


    for(int i=1;i<=n;i++)
    {
        int x;
        //scanf("%d",&x);
        read(x);

        frecv[i]=x;
        q.push_back(make_pair(i,x));
    }


    int currentNode=n;

    while(1)
    {
        vector<pair<int,pair<int,int> >> vect; //for the current Minimum

        int cnt=0;

        while(!q.empty() && cnt<2)
        {
            vect.push_back(make_pair(1,q.front()));
            q.pop_front();
            cnt++;
        }

        cnt=0;


        while(!q2.empty() && cnt<2)
        {
            vect.push_back(make_pair(2,q2.front()));
            q2.pop_front();
            cnt++;
        }

        reverse(vect.begin(),vect.end());

        for(auto it:vect)
            if(it.first==1) q.push_front(it.second);
            else q2.push_front(it.second);

        reverse(vect.begin(),vect.end());

        if((int)vect.size()<2)
            break;

        stable_sort(vect.begin(),vect.end(),cmp);



        pair<int,pair<int,int> > pr1=vect[0];
        pair<int,pair<int,int> > pr2=vect[1];


        if(pr1.first==1) q.pop_front();
        else q2.pop_front();
        if(pr2.first==1) q.pop_front();
        else q2.pop_front();

        currentNode++;

        g[currentNode-n][0]=pr1.second.first;
        g[currentNode-n][1]=pr2.second.first;

        q2.push_back(make_pair(currentNode,pr1.second.second+pr2.second.second));

    }

    //printf("%d\n",g[11].size());

    //return 0;
    dfs(currentNode,0,0);

    //   sort(sol.begin(),sol.end());

    printf("%lld\n",ans);


    for(int i=1;i<=n;i++)
    {
        printf("%d %lld\n",sol[i].first,sol[i].second);
    }
    return 0;
}