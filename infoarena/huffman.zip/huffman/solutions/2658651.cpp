#include <bits/stdc++.h>

using namespace std;
ifstream in("huffman.in");
ofstream out("huffman.out");

struct nod{
    long long ind,v;
}t[1000005];

typedef bool (*comp)(nod,nod);
bool compare(nod a, nod b)
{
   return (a.v>=b.v);
}

std::priority_queue<nod,std::vector<nod>, comp> pq(compare);

int n,nr;
long long s;

int mu[2000005][2];

long long rez[1000005];

int lung[1000005];

void dfs(int ind_nod,long long cod,int l){
    if(ind_nod<=n){
        rez[ind_nod]=cod;
        lung[ind_nod]=l;
        return;
    }
    dfs(mu[ind_nod][0],cod<<1,l+1);
    dfs(mu[ind_nod][1],(cod<<1)|1,l+1);
}

int main()
{
    in>>n;
    for(int i=1;i<=n;i++){
        in>>t[i].v;
        t[i].ind=i;
        pq.push(t[i]);
    }
    nr=n;
    while(pq.size()>1){
        nod a,b;
        a=pq.top();
        pq.pop();
        b=pq.top();
        pq.pop();
        nod c;
        nr++;
        c.ind=nr;
        c.v=a.v+b.v;
        pq.push(c);
        mu[nr][0]=a.ind;
        mu[nr][1]=b.ind;
        s+=c.v;
    }
    dfs(nr,0,0);
    out<<s<<"\n";
    for(int i=1;i<=n;i++)
        out<<lung[i]<<" "<<rez[i]<<"\n";
    return 0;
}
