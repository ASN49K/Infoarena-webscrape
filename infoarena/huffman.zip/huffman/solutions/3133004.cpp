#include <bits/stdc++.h>
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("Ofast")
using namespace std;
#define INF 1000001

ifstream f("huffman.in");
ofstream g("huffman.out");

long long s;
int n;

queue <int> q1,q2;

struct elem
{
    int st,dr,nod;
    long long val;
}v[2000005];

long long extract()
{long long top;
    if (q2.empty())
    {
        top=q1.front();
        q1.pop();
        //cout<<top;
    }
    else if (q1.empty())
    {
        top=q2.front();
        q2.pop();
    }
    else if (v[q1.front()].val<=v[q2.front()].val)
    {
        top=q1.front();
        q1.pop();
    }
    else
    {
        top=q2.front();
        q2.pop();
    }
    return top;
}

void dfs(int aux, int niv, long long cod)
{
    if (aux<=n)
    {
        v[aux].val=cod;
        v[aux].nod=niv;
        return;
    }
    dfs(v[aux].st,niv+1,2*cod); //stanga, adaugam un bit 0
    dfs(v[aux].dr,niv+1,2*cod+1); //dreapta, adaugam un bit 1
}

int main()
{int i,j,aux,x,y;
    f>>n;
    for (i=1;i<=n;i++)
    {
        f>>v[i].val;
        v[i].nod=i;
        q1.push(i);
    }
    aux=n;
    while (q1.size()+q2.size()>1) //creeaza noile noduri
    {

        x=extract();
        y=extract();
        aux++;
        v[aux].val=v[x].val+v[y].val;
        v[aux].nod=aux;
        v[aux].st=x;
        v[aux].dr=y;
        q2.push(n);
        s+=v[aux].val;
    }
    g<<s<<'\n';
    //parcurgem prin dfs arborele huffman pt a determina nivelul
    dfs(aux,0,0);
    for (i=1;i<=n;i++)
        g<<v[i].nod<<' '<<v[i].val<<'\n';
}
