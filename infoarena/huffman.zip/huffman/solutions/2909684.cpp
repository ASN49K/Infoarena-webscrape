#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <algorithm>
#include <map>
#include <climits>
std::ifstream f("huffman.in");
std::ofstream o("huffman.out");
#define ll long long int
class node {
public:

	int value, left, right;
	node(int v, int l, int r) {
		value = v;
		left = l;
		right = r;
	}
};

std::queue<int>initial, after;
std::vector<node>nodes;
int nr;
std::vector<int>lengths;
std::vector<ll>codes;


long long int dfs(int root, int depth, long long int code) {

	node n = nodes[root];
	if (n.left == -1)
	{
		lengths[root] = depth;
		codes[root] = code;
		return (ll)depth * n.value;
	}
	else
	{
		return dfs(n.left, depth + 1, code << 1) + dfs(n.right, depth + 1, (code << 1) + 1);
	}
}


int get() {
	int b;
	if (initial.size() == 0)
	{
		b = after.front();
		after.pop();
	}
	else if (after.size() == 0) {
		b = initial.front();
		initial.pop();
	}
	else if (nodes[after.front()].value < nodes[initial.front()].value) {
		b = after.front();
		after.pop();
	}
	else {
		b = initial.front();
		initial.pop();
	}
	return b;
}


int main()
{
	f >> nr;
	lengths.resize(nr);
	codes.resize(nr);
	for (size_t i = 0; i < nr; i++)
	{
		int a;
		f >> a;
		nodes.push_back(node{ a,-1,-1 });
		initial.push(i);
	}

	while (initial.size() > 0 || after.size() > 1)
	{
		int n1 = get();
		int n2 = get();

		node n3{ nodes[n1].value + nodes[n2].value,n1,n2 };
		nodes.push_back(n3);
		after.push(nodes.size() - 1);
	}

	int root = after.front();

	long long int t = dfs(root, 0, 0);
	o << t << "\n";

	for (size_t i = 0; i < nr; i++)
	{
		o << lengths[i] << " " << codes[i] << "\n";
	}

}