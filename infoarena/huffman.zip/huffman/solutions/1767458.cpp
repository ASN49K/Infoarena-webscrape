#include <fstream>

using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

const int Nmax = 1000005;
const long long oo = 1LL*(1<<30);
int n, q[2][Nmax], l[2], r[2], nr, level[Nmax], a, b;
long long sol, Conf[Nmax];
struct graf
{
    int fii[2];
    long long fred;
}G[2*Nmax];

void Read()
{
    f>>n;
    for(int i = 1; i <= n; i++)
    {
        f>>G[i].fred;
        q[0][i] = i;
    }
}

void Select(int &x)
{
    if(G[q[0][l[0]]].fred < G[q[1][l[1]]].fred) x = q[0][l[0]++];
    else x = q[1][l[1]++];
}
void Solve()
{
    G[0].fred = oo*oo;
    l[0] = l[1] = 1;
    r[1] = 0;
    r[0] = n;
    nr = n;
    while(l[0] <= r[0] || l[1] < r[1])
    {
        Select(a);
        Select(b);
        nr++;
        G[nr].fii[0] = a;
        G[nr].fii[1] = b;
        G[nr].fred = G[a].fred + G[b].fred;
        sol += G[nr].fred;
        q[1][++r[1]] = nr;
    }
}

void DFS(int i, long long c, int niv)
{
    if(G[i].fii[0])
    {
        DFS(G[i].fii[0], (c<<1), niv+1);
        DFS(G[i].fii[1], (c<<1)+1, niv+1);
        return;
    }
    Conf[i] = c;
    level[i] = niv;
}

void Print()
{
    g<<sol<<'\n';
    for(int i = 1; i <= n; i++)
    {
        g<<level[i]<<' '<<Conf[i]<<'\n';
    }
}

int main()
{
    Read();
    Solve();
    DFS(nr,0,0);
    Print();
    return 0;
}
