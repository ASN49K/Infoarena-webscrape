#include <cstdio>
#include <algorithm>
#include <stack>
#include <vector>

using namespace std;

vector <int> g[2000010];
int cost = 0, lvl[1000010], nr[1000010], v[2000010], uer[2000010];
int n;

int st[2000010];

inline void dfs (int nod, int lev, int cif)
{
    if (!g[nod].size ())
    {
        lvl[uer[nod]] = lev;
        nr[uer[nod]] = cif;
        return;
    }

    for (int i = 0; i < 2; ++i)
        dfs (g[nod][i], lev + 1, cif * 2 + i);

}

int main ()
{
    freopen ("huffman.in", "r", stdin);
    freopen ("huffman.out", "w", stdout);

    scanf ("%d", &n);

    int k = 0;
    for (int i = 1; i <= n; ++i)
    {
        int x;
        scanf ("%d", &x);

        v[++k] = x;
        uer[k] = i;
        st[++st[0]] = k;

        for (; st[0] > 1;)
        {
            int a = st[st[0]];
            int b = st[st[0] - 1];

            if (v[a] >= v[b])
            {
                g[++k].push_back (a);
                g[k].push_back (b);

                --st[0];
                st[st[0]] = k;
                v[k] = v[a] + v[b];
            }

            else break;
        }
    }

    printf ("%d\n", v[k]);
    dfs (k, 0, 0);

    for (int i = 1; i <= n; ++i)
        printf ("%d %d\n", lvl[i], nr[i]);

    return 0;
}
