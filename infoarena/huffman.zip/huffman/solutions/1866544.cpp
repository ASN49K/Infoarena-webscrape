#include <cstdio>
#include <algorithm>
#include <stack>
#include <vector>

using namespace std;

vector <int> g[2000010];
int cost = 0, lvl[1000010], nr[1000010], v[2000010], uer[2000010];
int n;

int st[1000010], unit[2000010];

inline void dfs (int nod, int lev, int cif)
{
    if (!g[nod].size ())
    {
        cost += lev * v[nod];

        lvl[uer[nod]] = lev;
        nr[uer[nod]] = cif;
        return;
    }

    for (int i = 0; i < 2; ++i)
        dfs (g[nod][i], lev + 1, cif * 2 + i);

}

int main ()
{
    freopen ("huffman.in", "r", stdin);
    freopen ("huffman.out", "w", stdout);

    scanf ("%d", &n);

    int k = 0;
    for (int i = 1; i <= n; ++i)
    {
        int x;
        scanf ("%d", &x);

        v[++k] = x;
        uer[k] = i;
        st[++st[0]] = k;
    }

    if (n == 1)
    {
        printf ("%d\n1 0\n", v[1]);
        return 0;
    }

    int p = 1, q = 1;

    for (; st[0] > p || unit[0] > q || (st[0] >= p && unit[0] >= q);)
    {
        int aa = st[p];
        int bb = st[p + 1];
        int cc = unit[q];
        int dd = unit[q + 1];

        int a, b, poz = 0, mi = 2000000000;
        if (st[0] > p)
        {
            if (mi > v[aa] + v[bb]) mi = v[aa] + v[bb], poz = 1, a = aa, b = bb;
        }

        if (st[0] >= p && unit[0] >= q)
        {
            if (mi > v[aa] + v[cc]) mi = v[aa] + v[cc], poz = 2, a = aa, b = cc;
        }

        if (unit[0] > q)
        {
            if (mi > v[cc] + v[dd]) mi = v[cc] + v[dd], poz = 3, a = cc, b = dd;
        }


        g[++k].push_back (a);
        g[k].push_back (b);

        if (poz == 1) p += 2;
        if (poz == 2) ++p, ++q;
        if (poz == 3) q += 2;

        unit[++unit[0]] = k;
        v[k] = mi;
    }

    dfs (k, 0, 0);
    printf ("%d\n", cost);

    for (int i = 1; i <= n; ++i)
        printf ("%d %d\n", lvl[i], nr[i]);

    return 0;
}
