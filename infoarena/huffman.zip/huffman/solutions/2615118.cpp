#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream cin("huffman.in");
ofstream cout("huffman.out");

const int NMAX = 1e6;
const int LGMAX = 8;

int N, K;
int nodeWei[NMAX + 2];

struct node
{
    int index;
    long long wei;

    bool operator < (const node other) const
    {
        return wei > other.wei;
    }
};
priority_queue < node > pq;

int lenChar[NMAX + 2];
long long valChar[NMAX + 2];

vector < pair <int, bool> > g[LGMAX * NMAX];

void dfs(int node, int h, long long valTo)
{
    if(node <= N)
    {
        lenChar[node] = h;
        valChar[node] = valTo;
        return;
    }

    for(auto it : g[node])
        dfs(it.first, h + 1, (valTo << 1) + it.second);
}

int main()
{
    cin >> N;
    K = N;

    for(int i = 1; i <= N; i++)
    {
        cin >> nodeWei[i];
        pq.push({i, nodeWei[i]});
    }

    if(N == 1)
    {
        cout << nodeWei[1] << "\n1 0\n";
        return 0;
    }

    while(pq.size() > 1)
    {
        node f = pq.top();
        pq.pop();
        node s = pq.top();
        pq.pop();

        K++;
        g[K].push_back({f.index, 0});
        g[K].push_back({s.index, 1});

        long long sumWei = f.wei + s.wei;
        pq.push({K, sumWei});
    }

    dfs(K, 0, 0);

    long long totalSz = 0;
    for(int i = 1; i <= N; i++)
        totalSz = totalSz + 1LL * nodeWei[i] * lenChar[i];

    cout << totalSz << '\n';
    for(int i = 1; i <= N; i++)
        cout << lenChar[i] << ' ' << valChar[i] << '\n';

    return 0;
}
