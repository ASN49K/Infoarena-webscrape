#include <fstream>
#include <queue>
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");
queue <long long> q,p;
long long v[2000005];
long long ok=1,nrnoduri,a,b,n,x1,x2;
long long tata[2000005], decarefiu[2000005],lung[2000005],cod[200005];
int main()

{
    fin>>n;
    nrnoduri=n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        q.push(i);
    }
    while(ok){
        if(q.empty()|| p.empty()){
            if(q.empty())
            {
                a = p.front();
                p.pop();
                if(p.empty())
                {
                    ok=0;
                    continue;
                }
                b=p.front();
                p.pop();
            }
            else
            {
                a=q.front();
                q.pop();
                if(q.empty())
                {
                    ok=0;
                    continue;
                }
                b=q.front();
                q.pop();
            }
        }
        else{
            x1=q.front();
            x2=p.front();
            if(v[x1]<v[x2]){
                a=x1;
                q.pop();
                if(q.empty())
                {
                    b=x2;
                    p.pop();
                }
                else
                {
                    x1=q.front();
                    if(v[x1]<v[x2])
                    {
                        b = x1;
                        q.pop();
                    }
                    else
                    {
                        b=x2;
                        p.pop();
                    }
                }
            }
            else
            {
                a=x2;
                p.pop();
                if(p.empty())
                {
                    b=x1;
                    q.pop();
                }
                else
                {
                    x2=p.front();
                    if(v[x1]<v[x2])
                    {
                        b = x1;
                        q.pop();
                    }
                    else
                    {
                        b=x2;
                        p.pop();
                    }
                }
            }
        }
        ++ nrnoduri;
        tata[a]=nrnoduri;
        decarefiu[a]=0;
        decarefiu[b]=1;
        tata[b]=nrnoduri;
        v[nrnoduri] = v[a]+v[b];
        p.push(nrnoduri);
    }
    a=0;
    for(int k=n+1;k<=nrnoduri;k++){
        a+=v[k];
    }
    fout<<a<<'\n';
    for(int i=1;i<=n;i++){
        a=i;
        b=0;
        while(tata[a]!=0)
        {
            lung[i]++;
            cod[lung[i]]=decarefiu[a];
            a=tata[a];
        }
        a=0;
        for(int j=lung[i];j>=1;--j)
            a=a*2+cod[j];
        fout<<lung[i]<<" "<<a<<'\n';
    }
    return 0;
}
