#include <fstream>
#include <queue>

using namespace std;

ifstream cin ("huffman.in");
ofstream cout ("huffman.out");

class cmp{
public:
    bool operator() (pair<long long , int> a , pair<long long , int> b){
        return a.first > b.first;
    }
};

pair<int , int> node[2000100];
pair<int , long long> ans[1000100];

priority_queue <pair<long long , int> , vector<pair<long long , int>> , cmp> Q;

void dfs(int nod , int lv , long long val){

    if (node[nod].first == 0){
        ans[nod].first = lv;
        ans[nod].second = val;
        return;
    }

    dfs(node[nod].first , lv + 1 , (val << 1LL));
    dfs(node[nod].second , lv + 1 , (val << 1LL) + 1);

}

int main() {

    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin>>n;

    for (int i=1; i<=n; i++){
        int nr;
        cin>>nr;
        Q.push({nr , i});
    }

    long long cont = 0;
    int nod = n;

    while (Q.size() > 1){
        pair<long long , int> st , dr;
        st.first = Q.top().first;
        st.second = Q.top().second;
        Q.pop();
        dr.first = Q.top().first;
        dr.second = Q.top().second;
        Q.pop();

        nod++;

        node[nod].first = st.second;
        node[nod].second = dr.second;

        Q.push({st.first + dr.first , nod});
        cont += st.first + dr.first;
    }

    cout<<cont<<'\n';

    //dfs(nod , 0 , 0);

    for (int i=1; i<=n; i++){
        cout<<ans[i].first<<" "<<ans[i].second<<'\n';
    }

    return 0;
}