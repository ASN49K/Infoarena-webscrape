#include<cstdio>
#include<iostream>
#include<deque>
using namespace std;
const long long valmax=1LL*1000000*100000000;
const int nmax=1000000;
long long v[nmax+5];
int n,f0[nmax*2+5],f1[nmax*2+5];
bool be[nmax*2+5];
struct sp
{
    long long x;
    int p;
};
deque<sp> dq;
void dfs(int p,long long co)
{
    if(p>n)
}
int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    int i,j,dr,m,st,tp,l=0,p1,p2;
    long long m1,m2;
    sp tm;
    cin>>n;
    v[n+1]=-1;
    for(i=1; i<=n; i++)
        cin>>v[i];
    st=1;
    l=n;
    while(st<=n || dq.size()>1)
    {
        m1=m2=valmax;
        if(dq.size()>0)
        {
            if(dq.front().x<v[st])
            {
                m1=dq.front().x;
                p1=dq.front().p;
                dq.pop_front();
            }
        }
        if(m1==valmax)
        {
            m1=v[st];
            p1=st;
            st++;
        }
        if(dq.size()>0)
        {
            if(dq.front().x<v[st])
            {
                m2=dq.front().x;
                p2=dq.front().p;
                dq.pop_front();
            }
        }
        if(m2==valmax)
        {
            m2=v[st];
            p2=st;
            st++;
        }
        l++;
    tm.x=m1+m2;
    tm.p=l;
    f0[l]=p1;
    f1[l]=p2;
    dq.push_back(tm);
    }
    dfs(dq.front().p,0);
    return 0;
}
