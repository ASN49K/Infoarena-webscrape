#include <bits/stdc++.h>
#define DIM 1000010
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
int n,i,j,k,m,t,niv,l[DIM],cod;
long long cost,c[DIM],v[DIM],w[DIM];
pair<long long, pair<int,int> > L[2*DIM];
void dfs(int nod,long long cod) {
    niv++;
    if (nod>n)
        cost+=L[nod].first;
    else
        c[nod]=cod, l[nod]=niv;
    if (L[nod].first>0) {
        dfs(L[nod].second.first,(cod<<1));
        dfs(L[nod].second.second,(cod<<1)+1);
    }
    niv--;
}
int main() {
    memset(v,1,sizeof(v));
    memset(w,1,sizeof(w));
    fin>>n;
    for (i=1;i<=n;i++)
        fin>>v[i];
    i=1, j=1, k=n, t=2*n-1;
    while (k<t) {
        //alegem doua elemente din v[]
        if (v[i+1]<=w[j]) {
            L[++k]={v[i]+v[i+1],{i,i+1}};
            w[++m]=v[i]+v[i+1];
            i+=2;
        }
        //alegem doua elemente din w[]
        else if (w[j+1]<=v[i]) {
            L[++k]={w[j]+w[j+1],{n+j,n+j+1}};
            w[++m]=w[j]+w[j+1];
            j+=2;
        }
        //alegem un element din v[] si unul din w[]
        else {
            L[++k]={v[i]+w[j],{i,n+j}};
            w[++m]=v[i]+w[j];
            i++, j++;
        }
    }
    niv=-1;
    dfs(2*n-1,0);
    fout<<cost<<"\n";
    for (i=1;i<=n;i++)
        fout<<l[i]<<" "<<c[i]<<"\n";
    return 0;
}
