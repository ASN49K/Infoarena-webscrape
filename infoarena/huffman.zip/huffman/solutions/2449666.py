#!/usr/bin/env python3

import sys
from collections import deque

sys.stdout = open('huffman.out' ,'w')

with open('huffman.in', 'r') as f:
    NumNodes = N = int(f.readline())
    s, fr, t, chld = 0, deque([(int(f.readline()), i) for i in range(N)]), deque(), [None] * N

    def pop():
        if not fr and not t:
            return None
        if fr and t:
            if fr < t:
                return fr.popleft()
            else:
                return t.popleft()
        return fr.popleft() if fr else t.popleft()

    while fr or t:
        m1 = pop()
        m2 = pop()

        if m2 is None:
            s += m1[0]
            break

        t.append((m1[0] + m2[0], NumNodes))
        chld.append((m1[1], m2[1]))
        NumNodes += 1
        s += t[0][0]

    print(s)

    code, stk, vis, path = [None] * NumNodes, [NumNodes - 1], [False] * NumNodes, []
    vis[NumNodes - 1] = True
    while stk:
        crt = stk[-1]
        if chld[crt] is None:
            code[crt] = len(path), int(''.join(path), base=2)
        else:
            for i, chl in enumerate(chld[crt]):
                if not vis[chl]:
                    stk.append(chl)
                    path.append(str(i))
                    vis[chl] = True
                    break
        if stk[-1] == crt:
            stk.pop()
            if path: path.pop()

    for i in range(N):
        print(code[i][0], code[i][1])
