#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

const int kN = 1e5;
const long long kInf = 1e18;

int n;
long long len;

struct Node {
	long long val;
	int node, l, r;
	Node() {}
	Node(long long val, int node, int l, int r): val(val), node(node), l(l), r(r) {}
};
vector<Node> v;
queue<int> q[2];

int get_min() {
	int a = 0, b = 0;
	if(!q[0].empty()) {
		a = q[0].front();
	}
	if(!q[1].empty()) {
		b = q[1].front();
	}
	if(v[a].val < v[b].val) {
		q[0].pop();
		return a;
	} else {
		q[1].pop();
		return b;
	}
}

void dfs(int node, int d, long long cod) {
	if(node <= n) {
		v[node].val = cod;
		v[node].node = d;
	} else {
		dfs(v[node].l, d + 1, 2 * cod);
		dfs(v[node].r, d + 1, 2 * cod + 1);
	}
}

int main() {
	fin >> n;
	v.emplace_back(kInf, 0, 0, 0);
	for(int i = 1; i <= n; i++) {
		long long val;
		fin >> val;
		v.emplace_back(val, i, 0, 0);
		q[0].push(i);
	}
	while(q[0].size() + q[1].size() > 1) {
		int a, b;
		a = get_min();
		b = get_min();
		v.emplace_back(v[a].val + v[b].val, v.size(), a, b);
		q[1].push(v.size() - 1);
		len += v.back().val;
	}
	dfs(v.size(), 0, 0);
	fout << len << '\n';
	for(int i = 1; i <= n; i++) {
		fout << v[i].node << " " << v[i].val << '\n';
	}
	return 0;
}