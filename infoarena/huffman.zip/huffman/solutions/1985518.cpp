﻿#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <map>
#include <string>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <algorithm> 
#include <ctime>

#define MaxN 500005
#define INF 2140000000

using namespace std;

FILE *IN,*OUT;

int N,v[MaxN],len=0,L=0,R=-1;
pair<int,long long>Q[MaxN];
int main()
{
	IN=fopen("huffman.in","r");
	OUT=fopen("huffman.out","w");

	fscanf(IN,"%d",&N);
	for(int i=1;i<=N;i++)
		fscanf(IN,"%d",&v[i]);
    if(N==1)
	{
		fprintf(OUT,"%d\n",v[1]);
		return 0;
	}
	sort(v+1,v+1+N);
	int pos=1;
	while(len+N-pos+1>1)
	{
		int type=0,Min=INF,cost;
		if(N-pos+1>1)
			Min=v[pos]+v[pos+1],type=1;
		if(N-pos+1>0&&len>0&&Min>v[pos]+Q[L].first)
			Min=v[pos]+Q[L].first,type=2;
		if(len>1&&Min>Q[L].first+Q[L+1].first)
			Min=Q[L].first+Q[(L+1)%MaxN].first,type=3;
		if(type==1)
			cost=Min,pos+=2;
		else if(type==2)
			cost=Q[L].first+Q[L].second+v[pos],pos++,len--,L++;
		else cost=Q[L].first+Q[(L+1)%MaxN].first+Q[L].second+Q[(L+1)%MaxN].second,L+=2,len-=2;
		R++,len++;
		if(L>=MaxN)
			L-=MaxN;
		if(R==MaxN)
			R=0;
		Q[R]=make_pair(Min,cost);
	}
	fprintf(OUT,"%d\n",Q[R].second);
	return 0;
}