#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MAXN = 1e6;
const long long INF = 1e18;

ifstream fin( "huffman.in" );
ofstream fout( "huffman.out" );

queue < pair <int, int> > q1;
queue < pair <int, int> > q2;


struct Node {
  int val;
  int leftChild;
  int rightChild;
  bool existing;
};
int nrNodes;

Node nodes[2*MAXN+2];

int ans = 0;
pair <int, int> rez[MAXN+1];

void dfs( int node, int level, int nr ) {
  if( nodes[node].existing == false )
    ans += nodes[node].val;
  else
    rez[node] = { level - 1, nr };
  if( nodes[node].leftChild )
    dfs( nodes[node].leftChild, level + 1, 2 * nr );
  if( nodes[node].rightChild )
    dfs( nodes[node].rightChild, level + 1, 2 * nr + 1 );
}
signed main() {
  int n, i, sum, a, b, index1, index2;
  fin >> n;
  for( i = 1; i <= n; i++ ) {
    fin >> nodes[i].val;
    q1.push( { nodes[i].val, i } );
    nodes[i].existing = true;
  }
  nrNodes = n + 1;
  while( q1.size() + q2.size() > 1 ) {
    /*sum = q.front().first;
    a = q.front().second;
    q.pop();
    sum += q.front().first;
    b = q.front().second;
    q.pop();
    q.push( { sum, nrNodes } );
    nodes[nrNodes++] = { sum, a, b, false }; */
    sum = 0;
    if( !q1.empty() )
      a = q1.front().first;
    else a = INF;
    if( !q2.empty() )
      b = q2.front().first;
    else b = INF;
    if( a < b ) {
      index1 = q1.front().second;
      q1.pop();
      sum += a;
    }
    else {
      index1 = q2.front().second;
      q2.pop();
      sum += b;
    }

    if( !q1.empty() )
      a = q1.front().first;
    else a = INF;
    if( !q2.empty() )
      b = q2.front().first;
    else b = INF;
    if( a < b ) {
      index2 = q1.front().second;
      q1.pop();
      sum += a;
    }
    else {
      index2 = q2.front().second;
      q2.pop();
      sum += b;
    }

    q2.push( { sum, nrNodes } );
    nodes[nrNodes++] = { sum, index1, index2, false };
  }
  nrNodes--;
  dfs( nrNodes, 1, 0 );
  fout << ans << "\n";
  for( i = 1; i <= n; i++ )
    fout << rez[i].first << " " << rez[i].second << "\n";
  return 0;
}
