#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <fstream>
#include <bitset>
using namespace std;

struct Node {
    char symbol;
    int frequency;
    Node* left;
    Node* right;

    Node(char symbol, int frequency) {
        this->symbol = symbol;
        this->frequency = frequency;
        left = nullptr;
        right = nullptr;
    }
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        return a->frequency > b->frequency;
    }
};

void generateHuffmanCodes(Node* root, string codePrefix, unordered_map<char, string>& huffmanCodes) {
    if (root->left == nullptr && root->right == nullptr) {
        huffmanCodes[root->symbol] = codePrefix;
        return;
    }

    generateHuffmanCodes(root->left, codePrefix + "0", huffmanCodes);
    generateHuffmanCodes(root->right, codePrefix + "1", huffmanCodes);
}

int main() {
    ifstream inputFile("huffman.in");
    ofstream outputFile("huffman.out");

    int n;
    inputFile >> n;

    vector<int> frequencies(n);
    for (int i = 0; i < n; i++) {
        inputFile >> frequencies[i];
    }

    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (int i = 0; i < n; i++) {
        char symbol = 'a' + i;
        Node* node = new Node(symbol, frequencies[i]);
        pq.push(node);
    }

    while (pq.size() > 1) {
        Node* leftChild = pq.top();
        pq.pop();

        Node* rightChild = pq.top();
        pq.pop();

        int totalFrequency = leftChild->frequency + rightChild->frequency;
        Node* internalNode = new Node('\0', totalFrequency);
        internalNode->left = leftChild;
        internalNode->right = rightChild;

        pq.push(internalNode);
    }

    Node* root = pq.top();
    unordered_map<char, string> huffmanCodes;
    generateHuffmanCodes(root, "", huffmanCodes);

    // Calculate the minimum length
    long long minLength = 0;
    for (int i = 0; i < n; i++) {
        char symbol = 'a' + i;
        int frequency = frequencies[i];
        minLength += frequency * huffmanCodes[symbol].length();
    }

    outputFile << minLength << "\n";
    for (int i = 0; i < n; i++) {
        char symbol = 'a' + i;
        int codeLength = huffmanCodes[symbol].length();
        long long codeValue = bitset<64>(huffmanCodes[symbol]).to_ullong();
        outputFile << codeLength << " " << codeValue << "\n";
    }

    inputFile.close();
    outputFile.close();

    return 0;
}