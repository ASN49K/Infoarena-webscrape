#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define dbg(x) cerr << #x << " " << x << "\n"

const int N = 1e6;
ll ans[1 + N * 2];
int length[1 + N * 2];
ll freq[1 + N * 2];
int r[1 + N * 2], l[1 + N * 2];

int go (int node, int val, int h) {
    if (l[node] == 0 && r[node] == 0) {
        ans[node] = val;
        length[node] = h;
        return 0;
    }
    return freq[node] + go (l[node], val * 2, h + 1) + go (r[node], val * 2 + 1, h + 1);
}

queue <int> qL, qC;

int getMin () {
    int x;
    if (qL.size () == 0 || (qC.size () && freq[qL.front ()] > freq[qC.front ()]))
        x = qC.front (), qC.pop ();
    else
        x = qL.front (), qL.pop ();
    return x;
}

int main() {
    freopen ("huffman.in", "r", stdin);
    freopen ("huffman.out", "w", stdout);

    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);

    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> freq[i];
        qL.push (i);
    }

    int nr = n;
    while (qL.size () + qC.size () > 1) {
        int x = getMin (), y = getMin ();
        freq[++nr] = freq[x] + freq[y];
        l[nr] = x, r[nr] = y;
        qC.push (nr);
    }

    cout << go (nr, 0, 0) << "\n";
    for (int i = 1; i <= n; i++)
        cout << length[i] << " " << ans[i] << " "  << "\n";

    return 0;
}
