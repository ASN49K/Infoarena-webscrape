#include <bits/stdc++.h>
#define N -1
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");
const int NMAX = 1e6+100;

struct nod
{
    int left, right;
    int ad, poz;
    long long val, dec;
    nod(long long _val=-1, int _left = N, int _right = N, int _poz = -1)
    {
        val = _val;
        left = _left;
        right = _right;
        poz = _poz;
    }

}w[2*NMAX];
int root;
int n;
long long sum;

///pun 0 pe stanga si 1 pe dreapta
void dfs(int nod, int ad, long long val)
{
    if(nod > 0)
    {
        w[nod].dec = val;
        w[nod].ad = ad;
        dfs(w[nod].left, ad+1, val<<1);
        dfs(w[nod].right, ad+1, (val+1)<<1);
    }
}

void huffman()
{
    w[n+1].val = LONG_LONG_MAX;
    //nod x[NMAX];
    int stop, i = 1, j;
    stop = n+1;
    j = n+2;

    ///cat timp am cel putin 2 elemente in una dintre cele doua cozi
    while(i < n || j < stop)
    {
        int first, second;
        if(j <= stop && w[j].val < w[i].val)
            first = j, ++j;
        else first = i, ++i;

        if(j <= stop && w[j].val < w[i].val)
            second = j, ++j;
        else second = i, ++i;

        w[++stop] = nod(w[first].val+w[second].val, first, second);
        sum += w[stop].val;
    }

    ///cazul in care am un singur element si nu formez a doua coada
    if(i == n)
        root = n;
    else root = stop;///ultimul nod ramas, adica radacina

    dfs(root, 0ll, 0ll);
}
int main()
{
    int i;
    long long val;
    fin >> n;
    for(i = 1; i <= n; ++i)
    {
        fin >> val;
        w[i] = nod(val, N, N, i);
    }

    huffman();
    fout << sum << '\n';
    for(i = 1; i <= n; ++i)
        fout << w[i].ad << ' ' << w[i].dec << '\n';

    return 0;
}
