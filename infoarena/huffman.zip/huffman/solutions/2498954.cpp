#include<fstream>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
long long n,m,i,j,k,lungime;
int nivel[2000001];
long long v1[1000001], coduri[2000001], v2[1000001];
pair<int,int> huffman[2000001];

void dfs(int nod,long long cod,int niv){
    nivel[nod]=niv;
    coduri[nod]=cod;

    if(huffman[nod].first!=0){
        for(int i=0;i<2;i++){
           if(i==0){
                int vecin=huffman[nod].first;
                dfs(vecin,(cod<<1),niv+1);
                if(huffman[vecin].first==0)
                    lungime+=nivel[vecin]*v1[vecin];
           }
           else{
                int vecin=huffman[nod].second;
                dfs(vecin,(cod<<1)+1,niv+1);
                if(huffman[vecin].first==0)
                    lungime+=nivel[vecin]*v1[vecin];
           }
        }
    }
    return;
}

int main(){
    fin>>n;m=n;
    for(i=1;i<=n;i++){
        fin>>v1[i];v2[i]=100000001;
    }

    i=j=1;

    while(m<2*n-1){
        if(v1[i]<=v2[j] && v1[i+1]<=v2[j] && i<=n && i+1<=n){

            v2[++k]=v1[i]+v1[i+1];
            huffman[++m]= make_pair(i,i+1);

            i+=2;

        }
        else{
            if( j+1<=2*n-1 && ( ( v2[j+1]<=v1[i] && v2[j]<v1[i] ) || i>n ) ){
                huffman[++m]=make_pair(j+n,j+n+1);
                v2[++k]=v2[j]+v2[j+1];

                j+=2;
            }

            if( (v1[i]<=v2[j] && i<=n && ( (i+1<=n && v1[i+1]>v2[j]) || (i+1>n) )) || (i<=n && v1[i]>v2[j] && ( (j+1<2*n && v2[j+1]>v1[i] ) || ( j+1>=2*n ) ) ) ){
                huffman[++m]=make_pair(i,j+n);
                v2[++k]=v1[i]+v2[j];
                i++,j++;
            }

        }
    }

    dfs(2*n-1, 0, 0);

    fout<<lungime<<"\n";

    for(i=1;i<=n;i++)
        fout<<nivel[i]<<" "<<coduri[i]<<"\n";
    return 0;
}
