#include <cstdio>
#include <iostream>
#include <cassert>
#include <queue>

using namespace std;

typedef long long ll;

const int N = (int) 2e6 + 7;
int n, k1[N], k2[N], len[N], par[N], e[N], num[N];
queue<pair<ll, int>> q1;
queue<pair<ll, int>> q2;

pair<ll, int> emin() {
  if (q1.empty()) {auto it = q2.front(); q2.pop(); return it;}
  if (q2.empty()) {auto it = q1.front(); q1.pop(); return it;}
  if (q1.front().first > q2.front().first) {auto it = q2.front(); q2.pop(); return it;}
  {auto it = q1.front(); q1.pop(); return it;}
}

signed main() {
  freopen ("huffman.in", "r", stdin);
  freopen ("huffman.out", "w", stdout);

  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    int x;
    scanf("%d", &x);
    q1.push({x, i});
  }
  int y = n;
  ll sol = 0;
  while ((int) q1.size() + (int) q2.size() > 1) {
    auto it1 = emin();
    auto it2 = emin();
    par[it1.second] = par[it2.second] = ++y;
    e[it1.second] = 1;
    q2.push({it1.first + it2.first, y});
    sol += (it1.first + it2.first);
  }
  printf("%d\n", sol);
  for (int i = y - 1; i >= 1; i--) {
    len[i] = 1 + len[par[i]];
    num[i] = 2 * num[par[i]] + e[i];
  }
  for (int i = 1; i <= n; i++) {
    printf("%d %d\n", len[i], num[i]);
  }
  return 0;
}

