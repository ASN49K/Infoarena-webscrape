//
//  main.cpp
//  coduri hoofman
//
//  Created by Eusebiu Rares on 29/05/2020.
//  Copyright © 2020 Eusebiu Rares. All rights reserved.
//

#include <iostream>
#include "fstream"
#include "queue"

const int MV = 2e6 ;

std::fstream in ("huffman.in", std::ios::in) ;
std::fstream out ("huffman.out", std::ios::out) ;

template <typename T, typename F>
class Node {
	public :
	T left ;
	F right ;
	Node() {
		left = right = 0 ;
	}
	Node(T _left, F _right) {
		left = _left ;
		right = _right ;
	}
	bool operator == (const Node &aux) {
		return (left == aux.left and right == aux.right) ;
	}
};

long long id[MV + 100] ;
std::queue<int> firstQueue, secondQueue ;
int nodes ;
Node<int, int> arb[MV + 100] ;
Node<int, long long> code[MV + 100] ;

int small() {
	if (firstQueue.empty()) {
		int candidateA = secondQueue.front() ;
		secondQueue.pop() ;
		return candidateA ;
	}
	if (secondQueue.empty()) {
		int candidateA = firstQueue.front() ;
		firstQueue.pop() ;
		return candidateA ;
	}
	int candidateA = firstQueue.front() ;
	int candidateB = secondQueue.front() ;
	if (id[candidateA] <= id[candidateB]) {
		firstQueue.pop() ;
		return candidateA ;
	} else {
		secondQueue.pop() ;
		return candidateB ;
	}
}

void addNode(int x, int y) {
	id[++ nodes] = id[x] + id[y] ;
	secondQueue.push(nodes) ;
	arb[nodes] = Node<int, int>(x, y) ;
//	std::cout << nodes << "  " << x << ' ' << y << '\n' ;
}

void createArb() {
	while (firstQueue.size() + secondQueue.size() >= 2) {
		int smallest = small() ;
		int help = small() ;
//		std::cout << smallest << "   " << help << "    " << nodes + 1 << '\n' ;
		addNode(smallest, help) ;
	}
}

void dfs(int node) {
	if (node <= 0) {
		return ;
	}
	code[arb[node].left].left = code[node].left + 1 ;
	code[arb[node].right].left = code[node].left + 1 ;
	code[arb[node].left].right = code[node].right << 1 ;
	code[arb[node].right].right = (code[node].right << 1) + 1 ;
//	std::cout << arb[node].left << "  " << code[arb[node].left].left << "  " << code[arb[node].left].right << '\n' ;
	dfs(arb[node].left) ;
	dfs(arb[node].right) ;
}

int main(int argc, const char * argv[]) {
	int codes ; in >> codes ;
	for (int i = 1 ; i <= codes ; ++ i) {
		in >> id[i] ;
		firstQueue.push(i) ;
	}
	nodes = codes ;
	createArb() ;
	dfs(nodes) ;
//	for (int i = nodes ; i >= 1 ; -- i) {
//		std::cout << i << "  -> " << code[i].left << "  " << code[i].right << '\n' ;
//	}
	long long lg(0) ;
	for (int i = nodes ; i > codes ; -- i) {
		lg += id[i] ;
	}
	out << lg << '\n' ;
	for (int i = 1 ; i <= codes ; ++ i) {
		out << code[i].left << ' ' << code[i].right << '\n' ;
	}
}
