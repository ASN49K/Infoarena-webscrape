#include <iostream>
#include <fstream>
#include <deque>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

int l[2000005], r[2000005], d[2000005], v[2000005], repr[2000005];
deque <int> init, inter;

int get_min(deque <int>&init, deque <int>& inter)
{
    int temp;
    if(init.empty())
    {
        temp = inter.front();
        inter.pop_front();
    }
    else if(inter.empty())
    {
        temp = init.front();
        init.pop_front();
    }
    else
    {
        if(v[inter.front()] < v[init.front()])
        {
            temp = inter.front();
            inter.pop_front();
        }
        else
        {
            temp = init.front();
            init.pop_front();
        }
    }
    return temp;
}

void DFS(int nod, long long b2, int lg)
{
    if(l[nod] == 0 && r[nod] == 0)
    {
        repr[nod] = b2;
        d[nod] = lg;
    }
    else
    {
        DFS(l[nod], b2<<1, lg+1);
        DFS(r[nod], (b2<<1)+1, lg+1);
    }
}

int main()
{
    int n;
    fin>>n;
    for(int i = 1; i <= n; i++)
    {
        fin>>v[i];
        init.push_back(i);
    }
    int k = n+1;
    while(init.size() + inter.size() != 1)
    {
        int x = get_min(init, inter);
        int y = get_min(init, inter);
        l[k] = x;
        r[k] = y;
        v[k] = v[x] + v[y];
        inter.push_back(k);
        k++;
    }
    DFS(inter.front(), 0, 0);
    long long lg_total = 0;
    for(int i = 1; i<= n; i++)
        lg_total += v[i] * d[i];
    fout<<lg_total<<"\n";
    for(int i = 1; i <= n; i++)
        fout<<d[i]<<' '<<repr[i]<<'\n';
    return 0;
}
