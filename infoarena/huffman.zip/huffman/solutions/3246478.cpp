#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

struct node
{
    i64 cost;
    int lchild,rchild;
    i64 path;
    int path_size;
};
i64 sol;
vector<node>nodes;

queue<int>q[2];
int get_min_erase()
{
    int rez=0;
    if(q[0].empty())
    {
        rez=q[1].front();
        q[1].pop();
    }
    else if(q[1].empty())
    {
        rez=q[0].front();
        q[0].pop();
    }
    else if(nodes[q[0].front()].cost < nodes[q[1].front()].cost)
    {
        rez=q[0].front();
        q[0].pop();
    }
    else
    {
        rez=q[1].front();
        q[1].pop();
    }
    return rez;
}

void dfs(int nod,i64 path,int path_size)
{
    nodes[nod].path=path;
    nodes[nod].path_size=path_size;
    if(nodes[nod].lchild==-1)
    {
        //sol++;
        sol+=nodes[nod].path_size*nodes[nod].cost;
        return;
    }
    dfs(nodes[nod].lchild,path<<1,path_size+1);
    dfs(nodes[nod].rchild,path<<1|1,path_size+1);
}
int main()
{
    ifstream cin("huffman.in");
    ofstream cout("huffman.out");
    int n;
    cin>>n;
    nodes.reserve(2*n-1);
    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;
        nodes.push_back({x,-1,-1,-1,-1});
        q[0].push(i);
    }
    for(int i=1;i<n;i++)
    {
        int x=get_min_erase();
        int y=get_min_erase();
        q[1].push((int)nodes.size());
        nodes.push_back({nodes[x].cost+nodes[y].cost,x,y,-1,-1});
    }
    dfs(2*n-2,0,0);
    cout<<sol<<'\n';
    for(int i=0;i<n;i++)
    {
        cout<<nodes[i].path_size<<' '<<nodes[i].path<<'\n';
    }
    return 0;
}
