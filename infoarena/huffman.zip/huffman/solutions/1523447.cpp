#include <fstream>
#define Int long long
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

struct nod
{
    Int inf,cod;
    nod *F[2];
    nod(){cod=0,inf=0;F[0]=F[1]=0;}
    nod(int _inf){cod=0,inf=_inf;F[0]=F[1]=0;}
    nod(nod *F0,nod *F1){cod=0,inf=F0->inf+F1->inf;F[0]=F0;F[1]=F1;}
};
Int n,i,j,k,fr,oo=1000000010,sol;
nod *N[2000005],*N0,*N1;
void parcurgere(nod*,Int,Int);
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>fr;
        N[i]=new nod(fr);
        N[i+n]=new nod(oo);
    }
    N[n+1]=new nod(N[1],N[2]);
    for(i=n+2,j=3,k=n+1;i<=2*n-1;i++)
    {
        if(j<=n&&N[j]->inf<=N[k]->inf)
                N0=N[j++];
            else
                N0=N[k++];
        if(j<=n&&N[j]->inf<=N[k]->inf)
                N1=N[j++];
            else
                N1=N[k++];
        N[i]=new nod(N0,N1);
    }
    for(i=n+1;i<=2*n-1;i++)
        sol+=N[i]->inf;
    g<<sol<<'\n';
    parcurgere(N[2*n-1],0,0);
    for(i=1;i<=n;i++)
        g<<N[i]->inf<<' '<<N[i]->cod<<'\n';
    return 0;
}
void parcurgere(nod *Nod,Int Lg,Int Cod)
{
    if(Nod->F[0]==NULL)
    {
        Nod->inf=Lg;
        Nod->cod=Cod;
        return;
    }
    parcurgere(Nod->F[0],Lg+1,2*Cod);
    parcurgere(Nod->F[1],Lg+1,2*Cod+1);
}
