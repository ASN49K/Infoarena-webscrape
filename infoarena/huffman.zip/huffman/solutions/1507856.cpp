#include <cstdio>
#include <deque>

#define LL long long
#define INF 2000000000000000007LL
#define NMAX 1000007
#define mp make_pair
#define pb push_back

using namespace std;
int n, m, L[NMAX], tmp1, tmp2;
deque <int> A, B;
LL P[2*NMAX], t, C[NMAX];
pair<int, int> S[2*NMAX];

int get()
{
    int a, b;
    if(A.empty()) a = 0;
    else a = A.front();
    if(B.empty()) b = 0;
    else b = B.front();
    if(P[a] < P[b])
    {
        A.pop_front();
        return a;
    }
    B.pop_front();
    return b;
}

void dfs(int x, int len, LL val)
{
    if(x <= n)
    {
        C[x] = val;
        L[x] = len;
        t += P[x] * 1LL * len;
        return ;
    }
    dfs(S[x].first, len + 1, 2*val);
    dfs(S[x].second, len + 1, 2*val +1);
}

int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    scanf("%d", &n);
    P[0] = INF;
    for(int i = 1; i<= n; ++i)
    {
        scanf("%d", &P[i]);
        A.pb(i);
    }
    m = n;
    for(int i = 1; i<= n-1; ++i)
    {
        tmp1 = get();
        tmp2 = get();
        ++m;
        S[m] =mp(tmp1, tmp2);
        P[m] = P[tmp1] + P[tmp2];
        B.pb(m);
    }
    dfs(m, 0, 0);
    printf("%lld\n", t);
    for(int i = 1; i<= n; ++i)
    {
        printf("%d %lld\n", L[i], C[i]);
    }
    return 0;
}
