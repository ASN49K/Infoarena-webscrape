#include <iostream>
#include <fstream>
using namespace std;

#define inf 1LL * 1000000000 * 1000000000

struct nod{
    long long v;
    long f[2];
} nod[2*1000001];

long n, k, p, l[2], r[2];
long q[2][1000001], lg[1000001];
long long b[10000001], m, sol;

void df(long poz, long long cod, long nivel)
{
    if(nod[poz].f[0])
    {
        df(nod[poz].f[0], cod*2, nivel+1);
        df(nod[poz].f[1], cod*2+1, nivel+1);
        return;
    }
    lg[poz] = nivel;
    b[poz] = cod;
}

void ans(){
    k = n;
    l[0] = l[1] = 1;
    r[0] = n;
    while(l[0] + l[1] <= r[0] + r[1])
    {
        ++k;
        for(int j = 0; j < 2; ++j)
        {
            p = 0;
            m = inf;
            for(int i = 0; i < 2; ++i){
                if(nod[q[i][l[i]]].v < m && l[i] <= r[i]){
                    p = i;
                    m = nod[q[i][l[i]]].v;
                }
            }
            nod[k].f[j] = q[p][l[p]];
            nod[k].v += nod[q[p][l[p]]].v;
            l[p]++;
        }
        sol += nod[k].v;
        q[1][++r[1]] = k;
    }
    df(k, 0, 0);
}

int main()
{
    ifstream fin ("huffman.in");
    ofstream fout("huffman.out");
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> nod[i].v;
        q[0][i] = i;
    }
    ans();
    fout << sol << "\n";
    for(int i = 1; i <= n; ++i)
        fout << lg[i] << " " << b[i] << "\n";
    return 0;
}
