#include <bits/stdc++.h>

using namespace std;

const int MAXN = 2000005;

#define st first
#define dr second

long long v[MAXN];
queue<int> init, intern;
pair<int, int> graf[MAXN];
pair<int, long long> ans[MAXN];

long long getmin(){
    int ret = 0;
    if(!init.empty() && (intern.empty() || v[init.front()] <= v[intern.front()])){
        ret = init.front();
        init.pop();
        return ret;
    }
    ret = intern.front();
    intern.pop();
    return ret;
}

void dfs(int nod, int nrcif, long long cod){
    ans[nod].st = nrcif;
    ans[nod].dr = cod;
    if(graf[nod].st > 0) dfs(graf[nod].st, nrcif + 1, 2 * cod);
    if(graf[nod].dr > 0) dfs(graf[nod].dr, nrcif + 1, 2 * cod + 1);
}

int main()
{
    ifstream fin("huffman.in");
    ofstream fout("huffman.out");
    int n, root;
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> v[i];
        init.push(i);
    }
    root = n;
    long long lg = 0;
    while((int)init.size() + (int)intern.size() > 1){
        long long x = getmin(), y = getmin();
        v[++root] = v[x] + v[y];
        graf[root].st = x;
        graf[root].dr = y;
        lg += v[x] + v[y];
        intern.push(root);
    }
    dfs(root, 0, 0);
    fout << lg << "\n";
    for(int i = 1; i <= n; ++i) fout << ans[i].st << " " << ans[i].dr << "\n";
    return 0;
}
