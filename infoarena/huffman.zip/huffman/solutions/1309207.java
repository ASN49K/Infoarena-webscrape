//package huffman;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
	static final int maxn = 500010;
	static Nod[] nod = new Nod[2*maxn];
	static int n, i, j, k, p, l[] = new int[2], r[] = new int[2];
	static int m, sol;
	static int q[][] = new int[2][maxn];
	static int lg[] = new int[maxn];
	static int b[] = new int[maxn]; 
	
	static void df(int poz, int cod, int nivel){
	    if(nod[poz].f[0] != 0){
	        df(nod[poz].f[0], cod*2, nivel+1);
	        df(nod[poz].f[1], cod*2+1, nivel+1);
	        return;
	    }
	    lg[poz]=nivel;
	    b[poz]=cod;
	}
	
	static void solve()
	{
	    k=n;
	    l[0]=l[1]=1;
	    r[0]=n;
	    while(l[0]+l[1]<=r[0]+r[1])
	    {
	        ++k;
	        for(j=0; j<2; j++)
	        {
	            p=0;
	            m=Integer.MAX_VALUE;
	            for(i=0; i<2; i++)
	            {
	                if(nod[q[i][l[i]]].v<m && l[i]<=r[i])
	                {
	                    p=i;
	                    m=nod[q[i][l[i]]].v;
	                }
	            }
	            nod[k].f[j]=q[p][l[p]];
	            nod[k].v+=nod[q[p][l[p]]].v;
	            l[p]++;
	        }
	        sol+=nod[k].v;
	        q[1][++r[1]]=k;
	    }
	    df(k, 0, 0);
	} 
	public static void main(String args[]) throws FileNotFoundException{
		
		Scanner scanner = new Scanner(new FileReader("huffman.in"));
		n = scanner.nextInt();
		for(int i = 0; i<2*maxn;i++)
			nod[i] = new Nod();
		nod[0] = new Nod(0);
		for(int i = 1; i<= n ;i++){
			nod[i] = new Nod(scanner.nextInt());
			q[0][i]=i;
		}
		scanner.close();
		solve();
	    PrintWriter g = new PrintWriter("huffman.out");
	    g.printf("%d\n", sol);
	    for(i=1; i<=n; i++)
	    {
	        g.printf("%d %d\n", lg[i], b[i]);
	    }
	    g.close();
	}
}
class Nod{
	int v;
	int f[];

	public Nod(){
		v = 0;
		f = new int[2];
	}
	public Nod(int v) {
		this.v = v;
		this.f = new int[2];
	}
	
}
