#include<queue>
#include<cstdio>

using namespace std;

int n,m;
long long sol;
queue<int> q1,q2;

struct coduri
{
    int l;
    long long c;
}s[1000010];

struct nod
{
    long long fr;
    int f1,f2;
}v[2000010];


void citire()
{
   freopen("huffman.in","r",stdin);
   scanf("%d",&n);
    m=n;
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&v[i].fr);
        q1.push(i);
    }
}

void huffman()
{
    int nod[2];
    while(!q1.empty() || q2.size()>1)
    {
        for(int i=0;i<=1;i++)
        {
            if(!q1.empty() && !q2.empty())
            {
                if(v[q1.front()].fr<v[q2.front()].fr)
                {
                    nod[i]=q1.front();
                    q1.pop();
                }
                else
                {
                    nod[i]=q2.front();
                    q2.pop();
                }
            }
            else
            if(!q1.empty())
            {
                nod[i]=q1.front();
                q1.pop();
            }
            else
            {
                nod[i]=q2.front();
                q2.pop();
            }
        }
        v[++n].fr=v[nod[0]].fr+v[nod[1]].fr;
        v[n].f1=nod[0];
        v[n].f2=nod[1];
        q2.push(n);
    }
}


void dfs(int ind,long long cod, int lg)
{
    if(v[ind].f1!=0)
    {
        sol=sol+v[ind].fr;
        dfs(v[ind].f1,(cod<<1),lg+1);
        dfs(v[ind].f2,(cod<<1)+1,lg+1);
    }
    else
    {
        s[ind].l=lg;
        s[ind].c=cod;
    }
}

int main()
{
    citire();
    huffman();
    dfs(n,0,0);
    freopen("huffman.out","w",stdout);
    printf("%lld\n",sol);
    for(int i=1;i<=m;i++)
    {
        printf("%d %lld\n",s[i].l,s[i].c);
    }
    return 0;
}
