#include <bits/stdc++.h>
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");
#define cin f
#define cout g
const int Max = 1e6 + 1;

int n, k;
long long sum, noduri[2 * Max];
pair < int, int > pointeri[Max];
pair < int, long long >ans[Max];

void parcurgere(int i, int bits, long long zec)
{
	if(i <= n)
	{
		ans[i].first = bits,
		ans[i].second = zec;
		return;
	}
	parcurgere(pointeri[i - n].first, bits + 1, zec * 2);
	parcurgere(pointeri[i - n].second, bits + 1, zec * 2 + 1);
	sum += noduri[i];
}

int main()
{
	cin >> n;
	for(int i = 1; i <= n; i ++)
		cin >> noduri[i];
	if(n == 1)
	{
		cout<<noduri[1]<<'\n';
		cout<<1<<" "<<0<<'\n';
		return 0;
	}
	k ++;
	noduri[n + k] = noduri[1] + noduri[2];
	pointeri[k].first = 1, pointeri[k].second = 2;
	int i, j;
	i = 3, j = n + 1;
	while(i <= n)
	{
		int x, y, p1, p2;
		if(noduri[i] <= noduri[j])
			x = noduri[i], p1 = i, i ++;
		else
			x = noduri[j], p1 = j, j ++;
		if(noduri[i] <= noduri[j])
			y = noduri[i], p2 = i, i ++;
		else
			y = noduri[j], p2 = j, j ++;
		k ++;
		noduri[n + k] = x + y;
		pointeri[k].first = p1, pointeri[k].second = p2;
	}
	while(j < n + k)
	{
		k ++;
		noduri[n + k] = noduri[j] + noduri[j + 1];
		pointeri[k].first = j, pointeri[k].second = j + 1;
		j += 2;
	}
	parcurgere(n + k, 0, 0);
	cout<<sum<<'\n';
	for(int i = 1; i <= n; i ++)
		cout<<ans[i].first<<" "<<ans[i].second<<'\n';
	return 0;
}