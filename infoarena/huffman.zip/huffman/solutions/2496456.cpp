#include <fstream>
#include <climits>
#include <vector>
#define INF 1000000000000000001LL
#define DIM 1000009
#define f in
#define g out
 
using namespace std;
ifstream in ( "huffman.in" );
ofstream out( "huffman.out" );
long long v[2*DIM], cod[DIM], lungime[DIM];
long long n, i, j, m, k, total, t;
pair < int, int > L[2*DIM];
 
void dfs ( long long nod, long long niv, long long nr ){
    g<<nod<<" "<<niv<<" "<<nr<<" "<<L[nod].first<<" "<<L[nod].second<<endl;
    if ( nod <= n ){
        lungime[nod] = niv;
        cod[nod] = nr;
        total += niv*v[nod];
        return;
    }
    dfs ( L[nod].first, niv+1, (nr<<1) );
    dfs ( L[nod].second, niv+1, (nr<<1) + 1 );
}
 
 
int main() {
    f>>n;
    for ( i=1; i <= n; i++ )
        f>>v[i];
    t = 2*n-1;
    for ( i=n+1; i <= t+5; i++ )
        v[i] = INF;
    i = 1; j = n+1; k = n;
    while ( k < t ){
        if ( v[i+1] <= v[j] ){
            v[++k] = v[i]+v[i+1];
            L[k] = make_pair( i, i+1 );
            i += 2;
            continue;
        }
        if ( v[j+1] <= v[i] ){
            v[++k] = v[j]+v[j+1];
            v[j] = v[j+1] = INF;
            L[k] = make_pair( j, j+1 );
            j += 2;
            continue;
        }
        v[++k] = v[i] + v[j];
        v[j] = INF;
        L[k] = make_pair( i, j );
        i++; j++;
    }
    
    dfs ( t, 0, 0 );
    g<<total<<"\n";
    for ( i=1; i <= n; i++ )
        g<<lungime[i]<<" "<<cod[i]<<"\n";
    return 0;
}
 