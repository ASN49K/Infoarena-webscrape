#include<cstdio>
#include<queue>

const int NMAX = 1000002;
using namespace std;

struct node
{
    int parent;
    bool bit;
} nodes[NMAX * 4 + 1];

int N;
queue<int> Q;

int len[NMAX];
unsigned long long code[NMAX];
unsigned long long vals[4 * NMAX + 1];
int queue_front;
unsigned long long ans_sum;
int pop_min ()
{
    int ans;
    if (queue_front == N)
    {
        ans = Q.front();
        Q.pop();
        return ans;
    }
    if (Q.empty())
    {
        return queue_front++;
    }
    int qf = Q.front();
    if (vals[queue_front] <= vals[qf])
    {
        return queue_front++;
    }
    else
    {
        Q.pop();
        return qf;
    }
}

int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    int val;

    scanf("%d", &N);
    for (int i = 0; i < N; ++i)
    {
        scanf("%d", vals + i);
    }
    int node_count = N;
    while(N - queue_front + Q.size() > 1)
    {
        int first = pop_min();
        int second = pop_min();

        ans_sum += vals[node_count] = vals[first] + vals[second];

        nodes[second].bit = 1;
        nodes[first].parent = nodes[second].parent = node_count;

        Q.push(node_count++);
    }

    for (int i = node_count - 2; i >= 0; --i)
    {
        code[i] = (code[nodes[i].parent] << 1) + nodes[i].bit;
        len[i] = len[nodes[i].parent] + 1;
    }

    printf("%llu\n", ans_sum);
    for (int i = 0; i < N; ++i) {
        printf("%d %llu\n", len[i], code[i]);
    }

}
