#include <fstream>
#include <climits>
#define nmax 1000002
#define uss unsigned long long
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct muchie {
    int dr, st;
    uss val;
}sir2[2 * nmax];

uss s;
uss sir1[nmax];
int n, k = 0, l = 1, c = 1;

uss sum = 0;

int main()
{
    fin>>n;
    c = n + 1;
    k = n;
    for(int i = 1; i <= n; ++i)
        fin>>sir1[i];
    for(int i = 1; i < n; ++i)
    {
        if((sir1[l] < sir2[c].val || c > k) && l <= n)
        {
            sir2[++k].val = sir1[l];
            sir2[l].st = k;
            l++;
        }
        else
        {
            sir2[++k].val = sir2[c].val;
            sir2[c].st = k;
            c++;
        }
        if((sir1[l] < sir2[c].val || c > k - 1) && l <= n)
        {
            sir2[k].val += sir1[l];
            sir2[l].dr = k;
            l++;
        }
        else
        {
            sir2[k].val += sir2[c].val;
            sir2[c].dr = k;
            c++;
        }
        sum += sir2[k].val;
    }
    fout<<sum<<"\n";
    for(int i = 1; i <= n; ++i)
    {
        int nod = i;
        long long s = 1;
        uss a = 0;
        int l = 0;
        while(nod != k)
        {
            l++;
            if(sir2[nod].dr)
            {
                a +=s;
                nod = sir2[nod].dr;
            }
            else
                nod = sir2[nod].st;
            s*=2;
        }
        fout<<l<<" "<<a<<"\n";
    }
    return 0;
}
