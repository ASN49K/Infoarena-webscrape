#include <fstream>
#include <vector>
#include <queue>
#include <cassert>

using namespace std;

const int NMAX = 1000000;

long long sol[1 + NMAX];
int lung[1 + NMAX];

struct Nod
{
    long long frecv;
    int id;

    int fiuSt;
    int fiuDr;

    Nod() = default;

    Nod(long long frecv, int id) :
        frecv(frecv), id(id) {};
};

vector<Nod> noduri;

queue<int> q1;
queue<int> q2;

int nextNod()
{
    int poz;

    if (q1.empty())
    {
        poz = q2.front();
        q2.pop();
        return poz;
    }
    else if (q2.empty())
    {
        poz = q1.front();
        q1.pop();
        return poz;
    }
    else
    {
        if (noduri[q1.front()].frecv <= noduri[q2.front()].frecv)
        {
            poz = q1.front();
            q1.pop();
            return poz;
        }
        else
        {
            poz = q2.front();
            q2.pop();
            return poz;
        }
    }
}

long long dfs(int poz, int h, long long val)
{
    if (noduri[poz].id != -1)
    {
        sol[noduri[poz].id]  = val;
        lung[noduri[poz].id] = h;
        return 0;
    }

    long long suma = 0;

    //suma += dfs(noduri[poz].fiuSt, h + 1, val);
    //suma += dfs(noduri[poz].fiuDr, h + 1, val |= (1ll << h));

    return suma + noduri[poz].frecv;
}

int main()
{
    ifstream in("huffmann.in");
    ofstream out("huffmann.out");

    int n;
    in >> n;

    for (int i = 1; i <= n; i++)
    {
        int v;
        in >> v;

        noduri.emplace_back(v, i);
        q1.push(noduri.size() - 1);
    }

    while (q1.size() + q2.size() >= 2)
    {
        int poz1 = nextNod();
        int poz2 = nextNod();

        noduri.emplace_back(noduri[poz1].frecv + noduri[poz2].frecv, -1);
        noduri.back().fiuSt = poz1;
        noduri.back().fiuDr = poz2;

        q2.push(noduri.size() - 1);
    }

    int radacina = nextNod();

    assert(0 <= radacina && radacina < noduri.size());

    out << dfs(radacina, 0, 0) << '\n';

    for (int i = 1; i <= n; i++)
        out << lung[i] << ' ' << sol[i] << '\n';

    return 0;
}
