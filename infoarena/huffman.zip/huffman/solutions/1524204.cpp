#include <bits/stdc++.h>

using namespace std;

long long a[2000005];
int ls[2000005];
int rs[2000005];

int n, v;
pair<int, long long> b[1000005];

void dfs(int poz, long long p, int niv) {
    if(!ls[poz]) {
        b[poz].first = niv;
        b[poz].second = p;
        return ;
    }
    dfs(ls[poz], p * 2, niv + 1);
    dfs(rs[poz], p * 2 + 1, niv + 1);
}

vector< pair<long long, int> > q, r;
int pozQ, pozR;

int main()
{
    FILE *f = fopen("huffman.in", "r");
    FILE *g = fopen("huffman.out", "w");
    fscanf(f, "%d", &n);
    for(int i = 1; i <= n; i ++) {
        fscanf(f, "%lld", &a[i]);
        q.push_back(make_pair(-a[i], i));
    }

    int m = n, lim = 2 * n - 1;
    while(m < lim) {
        int fst, snd;
        if(pozQ < q.size()) {
            if(pozR < r.size()) {
                if(r[pozR].first > q[pozQ].first)
                    fst = r[pozR].second, pozR ++;
                else fst = q[pozQ].second, pozQ ++;
            }
            else {
                fst = q[pozQ].second;
                pozQ ++;
            }
        }
        else {
            fst = r[pozR].second; pozR ++;
        }

        if(pozQ < q.size()) {
            if(pozR < r.size()) {
                if(r[pozR].first > q[pozQ].first)
                    snd = r[pozR].second, pozR ++;
                else snd = q[pozQ].second, pozQ ++;
            }
            else {
                snd = q[pozQ].second;
                pozQ ++;
            }
        }
        else {
            snd = r[pozR].second; pozR ++;
        }

        m ++;
        a[m] = a[fst] + a[snd];
        ls[m] = fst; rs[m] = snd;
        r.push_back(make_pair(-a[m], m));
    }

    int start = m;
    dfs(start, 0, 0);

    long long s = 0;
    for(int i = 1; i <= n; i ++) {
        s += b[i].first * a[i];
    }
    fprintf(g, "%lld\n", s);
    for(int i = 1; i <= n; i ++) {
        fprintf(g, "%d %lld\n", b[i].first, b[i].second);
    }
    return 0;
}
