#include <iostream>
#include <fstream>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

const int NMAX = 1000000;
const int INF = 1LL * 1e18;

struct Tree {
  long long v;
  int son[2];
};

int n, res;
int q[2][1 + NMAX];
int len[1 + NMAX];
int no[1 + NMAX];
Tree arb[1 + 2 * NMAX];

void dfs(int pos, long long code, int level) {
  if(arb[pos].son[0] != 0) {
    dfs(arb[pos].son[0], code * 2, level + 1);
    dfs(arb[pos].son[1], code * 2 + 1, level + 1);
  }

  len[pos] = level;
  no[pos] = code;
}

void solve() {
  int l[2] = {1, 1};
  int r[2] = {n, 0};
  int x = n;

  while(l[0] + l[1] <= r[0] + r[1]) {
    x++;
    for(int i = 0; i <= 1; i++) {
      int p = 0;
      long long sz = INF;
      for(int j = 0; j <= 1; j++) {
        if(arb[q[j][l[j]]].v < sz && l[j] <= r[j]) {
          p = j;
          sz = arb[q[j][l[j]]].v;
        }
      }
      arb[x].son[i] = q[p][l[p]];
      arb[x].v += arb[q[p][l[p]]].v;
      l[p]++;
    }
    res += arb[x].v;
    q[1][++r[1]] = x;
  }
  dfs(x, 0, 0);
}

int main()
{
  in >> n;
  for(int i = 1; i <= n; i++) {
    in >> arb[i].v;
    q[0][i] = i;
  }

  solve();

  out << res << '\n';
  for(int i = 1; i <= n; i++) {
    out << len[i] << ' ' << no[i] << '\n';
  }

  in.close();
  out.close();
  return 0;
}
