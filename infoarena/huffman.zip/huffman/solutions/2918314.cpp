#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

int const NMAX = 1000000;
int n;
long long f[1 + 2*NMAX];
long long ans[1 + NMAX];
long long len[1 + NMAX];
int le[1 + NMAX], ri[1 + NMAX];
long long sum;
queue<int> q[2];

void dfs(int from, long long code, int dist) {
  //cout << from << ": " << le[from] << " " << ri[from] << " " << code << "\n";
  if(from <= n) {
    ans[from] = code;
    len[from] = dist;
    sum += dist * f[from];
  } else {
    dfs(le[from], 2*code, dist+1);
    dfs(ri[from], 2*code+1, dist+1);
  }
}

int qpop() {
  int ret;
  if(!q[0].empty() && !q[1].empty()) {
    int n1 = q[0].front(), n2 = q[1].front();
    if(f[n1] < f[n2]) {
      ret = n1;
      q[0].pop();
    } else {
      ret = n2;
      q[1].pop();
    }
  } else if(q[0].empty()) {
    ret = q[1].front();
    q[1].pop();
  } else {
    ret = q[0].front();
    q[0].pop();
  }
  return ret;
}

int main() {
  /*ios_base::sync_with_stdio(false);
  fin.tie(NULL);*/

  fin >> n;
  for(int i = 1; i <= n; i++) {
    fin >> f[i];
    q[0].push(i);
  }
  int index = n;
  for(int i = 1; i <= n-1; i++) {
    index++;
    int p1 = qpop();
    int p2 = qpop();
    le[index] = p1;
    ri[index] = p2;
    f[index] = f[p1] + f[p2];
    q[1].push(index);
    //cout << p1.node << " " << p2.node << " " << index << "\n";
  }
  int root = q[1].front();
  dfs(root, 0, 0);
  fout << sum << "\n";
  for(int i = 1; i <= n; i++) {
    fout << len[i] << " " << ans[i] << "\n";
  }
}
