#include <iostream>
#include <cstdio>
using namespace std;

struct nod
{
    long long val;
    int poz;
    nod *l;
    nod *r;
};


long long w[1011111];
int poz[1011111];
long long v[2000001];
int tata[2000001];
int n;


int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    int  i, s, f, sw = 0, fw = 0, ord, p1, p2, h;
    int x = 1;
    long long su = 0;
    x = x<<30;
    scanf("%d", &n);
    ord = n;
    s = n;
    f = 2*n;
    for(i = n; i < 2*n; i++)
        scanf("%lld", &v[i]);

        while(s < f)
        {
            ord--;
            if(sw != fw && w[sw] < v[s])
            {
               v[ord] = w[sw];
               tata[poz[sw]] = ord;
               sw++;
            }
            else
            {
                v[ord] = v[s];
                tata[s] = ord;
                s++;
            }

             if(s == f ||sw != fw && w[sw] < v[s])
            {
               v[ord] += w[sw];
               tata[poz[sw]] = x + ord;
               sw++;
            }
            else
            {
                v[ord] += v[s];
                tata[s] = x + ord;
                s++;
            }

            poz[fw] = ord;
            w[fw] = v[ord];
            su += w[fw];
            fw++;
        }

        while(sw + 2 <= fw)
        {
            ord--;
            v[ord] = w[sw] + w[sw + 1];
            tata[poz[sw]] = ord;
            tata[poz[sw + 1]] = x + ord;
            w[fw] = v[ord];
            poz[fw] = ord;
            su += w[fw];
            sw +=   2;
            fw++;
        }
        tata[1] = 0;
        printf("%lld\n", su);
        long long val;
        for(i = n; i < 2*n; i++)
            {
                s = i;
                h = 0;
                val = 0;
                while(tata[s] != 0 )
                {

                    if(tata[s] > x)
                    {
                        s = tata[s] ^ x;//sau xor
                        //long long aux = (long long)1<<h;
                        val += (long long)1<<h;

                    }
                     else s = tata[s];
                     h++;
                }
                printf("%d %lld\n", h, val);
            }


    return 0;
}
