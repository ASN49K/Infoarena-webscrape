#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

long long code[1000010], sol;
int n, i, j, aux, f[2000010], st[1000010], dr[1000010], niv[1000010];

void dfs(int nod, int nivel, long long cod){
    niv[nod]=nivel;
    code[nod]=cod;
    if(st[nod]){
        dfs(st[nod], nivel+1, cod*2);
    }
    if(dr[nod]){
        dfs(dr[nod], nivel+1, cod*2+1);
    }
}


int main(){
    fin>>n;
    for(i=1; i<=n; i++){
        fin>>f[i];
        f[n+i]=100000010;
    }
    i=1;
    j=n+1;

    for(aux=n+1; aux<2*n; aux++){
        /// la fiecare pas luam suma celor mai mici 2 numere si o punem in arbore
        long long s1=f[i]+f[i+1];
        long long s2=f[i]+f[j];
        long long s3=f[j]+f[j+1];
        if(i+1>n){
            s1=100000010;
        }
        if(j+1>2*n){
            s3=100000010;
        }
        if(j>2*n || i>n){
            s2=100000010;
        }
        if(s1<=s2 && s1<=s3){
            st[aux]=i;
            dr[aux]=i+1;
            f[aux]=s1;
            i+=2;
        }else{
            if(s2<=s1 && s2<=s3){
                st[aux]=i;
                dr[aux]=j;
                f[aux]=s2;
                i++;
                j++;
            }else{
                /// s3 este cea mai mica
                st[aux]=j;
                dr[aux]=j+1;
                f[aux]=s3;
                j+=2;
            }
        }
    }
    dfs(2*n-1, 0, 0);
    for(aux=1; aux<=n; aux++){
        sol+=niv[aux]*f[aux];
    }
    fout<<sol<<"\n";
    for(i=1; i<=n; i++){
        fout<<niv[i]<<" "<<code[i]<<"\n";
    }
}
