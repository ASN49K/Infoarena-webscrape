#include <cstdio>
#include <deque>
using namespace std;
const int NMAX = 1.e6;

struct node{
    int weight, index;
    node *left, *right;
    node(){
        weight = 0;
        left = NULL;
        right = NULL;
    } 
};

deque <node*> dql, dqi;
long long v[NMAX + 5];
int lgc[NMAX + 5];
long long lg;

node* get_node(){
    if(dql.empty()){
        node *ti = dqi.front();
        dqi.pop_front();
        return ti;
    }
    if(dqi.empty()){
        node *tl = dql.front();
        dql.pop_front();
        return tl;
    }
    node *tl = dql.front();
    node *ti = dqi.front();
    if(tl->weight <= ti->weight){
        dql.pop_front();
        return tl;
    }
    else{
        dqi.pop_front();
        return ti;
    }
}


void dfs(node *nod, long long val, int lvl){   
    if(nod->index == 0){
        lg += nod->weight;
        dfs(nod->left, val << 1, lvl + 1);
        dfs(nod->right, (val << 1)^1, lvl + 1);
    }
    else{
        v[nod->index] = val;
        lgc[nod->index] = lvl;
    }
}

int main(){
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    int n, i, w;
    node *left_node, *right_node, *root;
    scanf("%d", &n);
    for(i = 1; i <= n; i ++){
        scanf("%d", &w);
        node *leaf = new node;
        leaf->weight = w;
        leaf->index = i;
        dql.push_back(leaf);
    }
    while(dql.size() + dqi.size() >= 2){
        left_node = get_node();
        right_node = get_node();
        node *internal = new node;
        internal->weight = left_node->weight + right_node->weight;
        internal->left = left_node;
        internal->right = right_node;
        dqi.push_back(internal);
        if(dql.size() + dqi.size() == 1)
            root = internal;
    }
    dfs(root, 0, 0);
    printf("%lld\n", lg);
    for(i = 1; i <= n; i ++)
        printf("%d %lld\n", lgc[i], v[i]);
    return 0;
}