#include <fstream>
#include <queue>

using namespace std;

ifstream cin ("huffman.in");
ofstream cout ("huffman.out");

pair<int , int> node[2000100];
long long val[2000100];
pair<int , long long> ans[1000100];

queue <int> q;
queue <int> Q;

void give_val(int &a ){
    if (q.empty()){
        a = Q.front();
        Q.pop();
    }
    else if (Q.empty()){
        a = q.front();
        q.pop();
    }
    else if (val[q.front()] < val[Q.front()]){
        a = q.front();
        q.pop();
    }
    else {
        a = Q.front();
        Q.pop();
    }
}

void dfs(int nod , int lv , long long val){

    if (node[nod].first == 0){
        ans[nod].first = lv;
        ans[nod].second = val;
        return;
    }

    dfs(node[nod].first , lv + 1 , (val << 1LL));
    dfs(node[nod].second , lv + 1 , (val << 1LL) + 1LL);

}

int main() {

    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin>>n;

    for (int i=1; i<=n; i++){
        cin>>val[i];
        q.push(i);
    }

    long long cont = 0;
    int nod = n;

    while (q.size() + Q.size() > 1){

        int st , dr;

        give_val(st);
        give_val(dr);

        nod ++;
        cont += val[st] + val[dr];

        Q.push(nod);
        val[nod] = val[st] + val[dr];
        node[nod].first = st;
        node[nod].second = dr;
    }

    cout<<cont<<'\n';

    dfs(nod , 0 , 0);

    for (int i=1; i<=n; i++){
        cout<<ans[i].first<<" "<<ans[i].second<<'\n';
    }

    return 0;
}