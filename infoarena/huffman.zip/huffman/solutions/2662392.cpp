#include <cstdio>
#include <vector>
#include <queue>

#define MAXN 1000003

using namespace std;

struct node {
	int son1, son2;
	long long value;
};

int n;

node nodes[2 * MAXN];
long levels[MAXN];
long long codes[MAXN];

queue <int> q1;
queue <int> q2;


void get_levels(int node, long long code, long level) {
	if (nodes[node].son1)
		get_levels(nodes[node].son1, code * 2, level + 1);

	if (nodes[node].son2)
		get_levels(nodes[node].son2, code * 2 + 1, level + 1);

	levels[node] = level;
	codes[node] = code;
}




int main() {
	freopen("huffman.in", "r", stdin);
	freopen("huffman.out", "w", stdout);

	scanf("%d", &n);

	for(int i=1; i<=n; ++i) {
		scanf("%lld", &nodes[i].value);
		q1.push(i);
	}

	int nodesno = n;
	long long sol = 0;

	while (q1.size() || q2.size() > 1) {
		int son1 = 0, son2  = 0;

		if (q1.size() && q2.size()) {
			if (nodes[q1.front()].value < nodes[q2.front()].value) {
                son1 = q1.front();
                q1.pop();
			} else {
                son1 = q2.front();
                q2.pop();
			}

			if (nodes[q1.front()].value < nodes[q2.front()].value) {
                son2 = q1.front();
                q1.pop();
			} else {
                son2 = q2.front();
                q2.pop();
			}
		} else
			if (q1.size()) {
				son1 = q1.front();
				q1.pop();

				if (q1.size()) {
					son2 = q1.front();
					q1.pop();
				}
			} else {
				son1 = q2.front();
				q2.pop();

				if (q2.size()) {
					son2 = q2.front();
					q2.pop();
				}
			}

        if (son1 && son2) {
            ++nodesno;

            nodes[nodesno].son1 = son1;
            nodes[nodesno].son2 = son2;
            nodes[nodesno].value = nodes[son1].value + nodes[son2].value;

            sol += nodes[nodesno].value;
            q2.push(nodesno);
        }
	}

	get_levels(nodesno, 0, 0);

	printf("%lld\n", sol);
	for(int i=1; i<=n; ++i)
		printf("%ld %lld\n", levels[i], codes[i]);

	return 0;
}
