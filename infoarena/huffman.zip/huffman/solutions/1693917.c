#include <stdio.h>
#include <stdlib.h>
#define MAX 2000003
struct nod{
    long long val;
    int fs, fd;
} arb[MAX];
int n, nou, q[MAX/2], p = 1, u, id = 1,  lev = -1, st[100];
long long ans[MAX/2];
int level[MAX/2];
long long s;
void rsd(int nod)
{
    lev++;
    if(arb[nod].fs==0){
        int i;
        long long p2 = 1;
        for(i=lev-1; i>=0; i--)
        {
            ans[nod] = ans[nod] + st[i]*p2;
            p2 = p2 * 2;
        }
        level[nod] = lev;
        //printf("%d %lld\n",lev, ans);
    }
    else
    {
        st[lev] = 0;
        rsd(arb[nod].fs);
        st[lev] = 1;
        rsd(arb[nod].fd);
    }
    lev--;
}
int main()
{
    int i, id1, id2;
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    scanf("%d", &n);
    for(i=1; i<=n; i++)
        scanf("%lld", &arb[i].val);
    nou = n;
    while(id<=n || p<u){
        if(id<=n && (p>u || arb[id].val<=arb[ q[p] ].val))
        {
            id1 = id;
            id++;
        }
        else{
            id1 = q[p];
            p++;
        }
        if(id<=n && (p>u || arb[id].val<=arb[ q[p] ].val))
        {
            id2 = id;
            id++;
        }
        else{
            id2 = q[p];
            p++;
        }
        nou++;
        arb[nou].val = arb[id1].val + arb[id2].val;
        arb[nou].fs = id1;
        arb[nou].fd = id2;
        s += arb[nou].val;
        u++;
        q[u] = nou;
    }
    printf("%lld\n", s);
    rsd(nou);
    for(i=1; i<=n; i++)
        printf("%d %lld\n", level[i], ans[i]);
    return 0;
}
