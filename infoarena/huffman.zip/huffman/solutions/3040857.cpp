#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

ifstream fin ("huffman.in");
ofstream fout ("huffman.out");

const int NMAX=2e6+5;
const int INF=2e9;

queue<int>q1;
queue<int>q2;

int n;

struct elem{
    int node;
    int st;
    int dr;
    long long value;
}v[NMAX];

long long solve()
{
    long long p;
    if(q1.empty())
    {
        p=q2.front();
        q2.pop();
    }
    else if(q2.empty())
    {
        p=q1.front();
        q1.pop();
    }
    else if(v[q1.front()].value<v[q2.front()].value)
    {
        p=q1.front();
        q1.pop();
    }
    else
    {
        p=q2.front();
        q2.pop();
    }
    return p;
}

void dfs(long long p,long long value,long long lvl)
{
    if(p<=n)
    {
        v[p].value=value;
        v[p].node=lvl;
        return ;
    }
    dfs(v[p].st,2*value,lvl+1);
    dfs(v[p].dr,2*value+1,lvl+1);
}

signed main()
{
    int i,j;
    long long kon;
    long long total=0;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i].value;
        v[i].node=i;
        q1.push(i);
    }
    kon=n;
    while(q1.size()+q2.size()>1)
    {
        int p1=solve();
        int p2=solve();
        kon++;
        v[kon].value=v[p1].value+v[p2].value;
        v[kon].node=kon;
        v[kon].st=p1;
        v[kon].dr=p2;
        q2.push(kon);
        total+=v[kon].value;
    }
    dfs(kon,0,0);
    fout<<total<<"\n";
    for(i=1;i<=n;i++)
        fout<<v[i].node<<" "<<v[i].value<<"\n";
    return 0;
}
