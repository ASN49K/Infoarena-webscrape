#include <cstdio>
#include <vector>
#include <algorithm>
#define NMAX 1000100
using namespace std;

struct node
{
    int f[2];
    long long v;
}nod[NMAX];

vector<pair<long long, int> > v;
pair<long long, int> per;
long long b[NMAX],sol;
int n,i,lg[NMAX],k;

void dfs(int poz,long long cod,int niv)
{
    if(nod[poz].f[0] != 0)
    {
        dfs(nod[poz].f[0],cod*2,niv+1);
        dfs(nod[poz].f[1],cod*2+1,niv+1);
        return;
    }
    lg[poz]=niv;
    b[poz]=cod;
    sol+=1ll*lg[poz]*nod[poz].v;
}

void solve()
{
    k=n;
    make_heap(v.begin(),v.end());
    while(v.size() > 1)
    {
        ++k;
        for(i=0; i<2; i++)
        {
            per=(*v.begin());
            pop_heap(v.begin(), v.end());
            v.pop_back();
            nod[k].f[i]=per.second;
            nod[k].v+=(-per.first);
        }
        v.push_back(make_pair(-nod[k].v, k));
        push_heap(v.begin(), v.end());
    }
    dfs(k, 0, 0);
}
int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;++i)
    {
        scanf("%lld",&nod[i].v);
        v.push_back(make_pair(-(1ll*nod[i].v),i));
    }
    solve();
    printf("%lld\n",sol);
    for(i=1;i<=n;++i)
        printf("%d %lld\n",lg[i],b[i]);
    return 0;
}
