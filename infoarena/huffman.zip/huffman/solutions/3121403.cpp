#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#pragma GCC optimize("Ofast")

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}

void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

struct node {
    ll val, bin;
    int len, left, right;
} root[2000010];

queue <int> q1, q2;

const int inf = 2000005;

int get_min() {
    int i_q1 = (len(q1)? q1.front() : inf);
    int i_q2 = (len(q2)? q2.front() : inf);

    if (i_q1 == inf and i_q2 == inf) {
        wr("lmao");
        exit(0);
    }
    
    if (root[i_q1].val < root[i_q2].val) {
        q1.pop();
        return i_q1;
    }

    q2.pop();
    return i_q2;
}

    
void dfs(int idx, int depth, ll val) {
    if (root[idx].left == root[idx].right and
        root[idx].left == -1) {
        root[idx].len = depth;
        root[idx].bin = val;
    }
 
    if (root[idx].left != -1) {
        dfs(root[idx].left, depth + 1, val * 2);
    }
 
    if (root[idx].right != -1)
        dfs(root[idx].right, depth + 1, val * 2 + 1);
}

void solve() {
    /* Huffman coding (merge 2 mins 'till you get one element) */
    root[inf].val = LLONG_MAX;

    /* Start with as many leaves as there are symbols. */
    /* Enqueue all leaf nodes into the first queue (in increasing order) */
    int n; re(n);
    for (int i = 0; i < n; ++i) {
        re(root[i].val);
        root[i].left = root[i].right = -1;
        q1.em(i);
    }

    /* While there is more than one node in the queues */
    ll res = 0; int k = n;
    while (len(q1) + len(q2) > 1) {
        /* Dequeue the two nodes with the lowest weight by examining the fronts of both queues. */
        int mn1 = get_min();
        int mn2 = get_min();
        /* Create a new internal node with the two just-removed nodes as children */
        root[k].val = root[mn1].val + root[mn2].val;
        root[k].left = mn1;
        root[k].right = mn2;
        res += root[k].val;
        /* Enqueue the new node into the rear of the second queue. */
        q2.emplace(k);
        ++k;
    }

    int root_idx = q2.front();
    q2.pop();

    dfs(root_idx, 0, 0);
    wr(res, '\n');
    for (int i = 0; i < n; ++i)
        wr(root[i].len, ' ', root[i].bin, '\n');
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("huffman");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}