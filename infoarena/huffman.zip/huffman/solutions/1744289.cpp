using namespace std;
#include <fstream>
#define Maxn 1000200
#define inf 1LL * 100000000 * 100000000


FILE *f=fopen("huffman.in","r");
ofstream g ("huffman.out");

struct nodd
{
    int v;
    int f[2];
};
nodd nod[2*Maxn];

int n,q[2][Maxn],r[2],l[2],lg[Maxn];
long long b[Maxn],sol=0;

void df(int poz, long long cod, int nivel)
{
    if(nod[poz].f[0])
    {
        df(nod[poz].f[0],2*cod,nivel+1);
        df(nod[poz].f[1],2*cod+1,nivel+1);
        return;
    }
    lg[poz]=nivel;
    b[poz]=cod;


}


void solve()
{
    int k=n,i,j,p;
    long long min;
    l[0]=l[1]=1;
    r[0]=n;

    while(l[0]+l[1]<=r[0]+r[1])
    {
        k++;
        for(j=0; j<2; j++)
        {
            min=inf;
            p=0;
            for(i=0; i<2; i++)
            {
                if(nod[q[i][l[i]]].v<min && l[i]<=r[i])
                {
                    min=nod[q[i][l[i]]].v;
                    p=i;
                }
            }
            nod[k].v+=min;
            nod[k].f[j]=q[p][l[p]];
            l[p]++;

        }

        q[1][++r[1]]=k;
        sol+=nod[k].v;
    }

    df(k,0,0);
}

int main()
{
    int i;
    fscanf(f,"%d",&n);

    for(i=1; i<=n; i++)
    {
        fscanf(f,"%d",&nod[i].v);
        q[0][i]=i;
    }

    solve();

    g<<sol<<'\n';

    for(i=1; i<=n; i++)
    g<<lg[i]<<" "<<b[i]<<'\n';




    return 0;
}
