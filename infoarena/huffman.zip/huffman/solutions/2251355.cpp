#include <fstream>
#include <queue>

std::ifstream f("huffman.in");
std::ofstream g("huffman.out");

struct Node { long long val; long long leftPos, rightPos;};

Node nodes[2000001];
long long unsigned len[1000001];
long long unsigned code[1000001];

long long getNodePosWithMinValue(Node nodes[], std::queue<long long>& initial, std::queue<long long>& internal)
{
    long long pos = -1;
    if(initial.empty())
    {
        pos = internal.front();
        internal.pop();
    }
    else if(internal.empty())
    {
        pos = initial.front();
        initial.pop();
    }
    else
    {
        long long initialFront = initial.front();
        long long internalFront = internal.front();
        if(nodes[initialFront].val < nodes[internalFront].val)
        {
            pos = initialFront;
            initial.pop();
        }
        else
        {
            pos = internalFront;
            internal.pop();
        }
    }

    return pos;
}

long long Huffman(Node nodes[], long long n, std::queue<long long> initial)
{
    std::queue<long long> internal;

    while( ( initial.size() + internal.size() ) > 1)
    {

        long long leftPos = getNodePosWithMinValue(nodes, initial, internal);
        long long rightPos = getNodePosWithMinValue(nodes, initial, internal);

        nodes[++n].val = nodes[leftPos].val + nodes[rightPos].val;
        nodes[n].leftPos = leftPos;
        nodes[n].rightPos = rightPos;

        internal.push(n);
    }

    return internal.front();
}

void DepthFirst(Node nodes[], long long pos, long long int val = 0, long long length = 0)
{
    if (nodes[pos].leftPos != -1)
    {
        DepthFirst(nodes, nodes[pos].leftPos, val * 2, length + 1);
    }

    if (nodes[pos].rightPos != -1)
    {
        DepthFirst(nodes, nodes[pos].rightPos, val * 2 + 1, length + 1);
    }

    if (nodes[pos].rightPos == -1 && nodes[pos].leftPos == -1)
    {
        len[pos] = length;
        code[pos] = val;
    }
}

int main()
{
    long long n;
    f >> n;

    std::queue<long long> initial;

    for(long long i = 0; i < n; ++i)
    {
        f >> nodes[i].val;
        nodes[i].leftPos = -1;
        nodes[i].rightPos = -1;

        initial.push(i);
    }

    long long root = Huffman(nodes, n, initial);
    DepthFirst(nodes, root);

    long long unsigned lg = 0;
    for (long long i = 0; i < n; ++i)
    {
        lg += len[i] * nodes[i].val;
    }

    g << lg << '\n';

    for (long long i = 0; i < n; ++i)
    {
        g << len[i] << ' ' << code[i] << '\n';
    }

    f.close();
    g.close();

    return 0;
}
