#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>

#define NMAX 1000005

using namespace std;

typedef struct {
    int bsize;
    long long number;
}Code;

typedef struct {
    int left, right;
}Tree;

inline void dfs(int node, Code **code, Tree *tree, int codification, int level){

    (*code)[node].bsize = level;
    (*code)[node].number = codification;

    if (tree[node].left != 0)
        dfs(tree[node].left, code, tree, 2 * codification, level + 1);

    if (tree[node].right != 0)
        dfs(tree[node].right, code, tree, 2 * codification + 1, level + 1);

    return;
}

int main()
{
    ifstream f("huffman.in");
    ofstream g("huffman.out");

    int n;

    f >> n;
    int *q1;
    long long *q2;
    q1 = (int*) malloc(sizeof(int) * (n + 1));
    q2 = (long long*) malloc(sizeof(long long) * 4 * (n + 1));

    for (int i = 1; i <= n; i++)
        f >> q1[i];

    int index = n;
    Tree *tree;
    tree = (Tree *) calloc(4 * n, sizeof(Tree));

    long long min1, min2;
    int ind1 = 1, ind2 = 1, lenght2 = 0;

    while (ind1 != n || ind2 != lenght2){

        if (ind2 > lenght2){
            tree[n + lenght2 + 1].left = ind1;
            min1 = q1[ind1++];
        }
        else
            if (q1[ind1] <= q2[ind2] && ind1 <= n){
                tree[n + lenght2 + 1].left = ind1;
                min1 = q1[ind1++];
            }
            else {
                tree[n + lenght2 + 1].left = ind2 + n;
                min1 = q2[ind2++];
            }

        if (ind1 > n){
            tree[n + lenght2 + 1].right = ind2 + n;
            min2 = q2[ind2++];
        }
        else
            if (q1[ind1] <= q2[ind2] || ind2 > lenght2){
                tree[n + lenght2 + 1].right = ind1;
                min2 = q1[ind1++];
            }
            else {
                tree[n + lenght2 + 1].right = ind2 + n;
                min2 = q2[ind2++];
            }

        q2[++lenght2] = min1 + min2;
    }

    Code *code;
    code = (Code *) calloc(index + 1, sizeof(Code));
    dfs(n + lenght2, &code, tree, 0, 0);

    long long total_lenght = 0;
    for (int i = 1; i <= n; i++)
        total_lenght += 1LL * code[i].bsize * q1[i];

    g << total_lenght << '\n';
    for (int i = 1; i <= n; i++)
        g << code[i].bsize << " " << code[i].number << '\n';

    f.close();
    g.close();

    return 0;
}
