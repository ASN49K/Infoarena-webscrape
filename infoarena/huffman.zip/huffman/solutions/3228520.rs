#![allow(non_snake_case)]
use std::{fs::File, io::{BufRead, BufReader, BufWriter}};
use std::io::Write;

#[derive(Debug)]
enum HuffmanPayload {
    Leaf {
        chr: usize
    },
    Internal {
        children: Box<[usize; 2]>
    }
}
#[derive(Debug)]
struct HuffmanNode {
    prio: u64,
    payload: HuffmanPayload
}

type HuffmanTree = Vec<HuffmanNode>;

#[derive(Debug, Clone)]
struct Encoding {
    val: u64,
    num_bits: u8,
}

impl HuffmanNode {
    fn new_leaf(prio: u64, chr: usize) -> Self {
        HuffmanNode { prio, payload: HuffmanPayload::Leaf { chr } }
    }
    fn new_inner(tree: &HuffmanTree, left: usize, right: usize) -> Self {
        let prio = tree[left].prio + tree[right].prio;
        HuffmanNode { prio , payload: HuffmanPayload::Internal {children: Box::new([left, right]) } }
    }
    fn create_encoding_impl(tree: &HuffmanTree, node: &Self, existing_encodings: &mut Vec<Encoding>, current_encoding: Encoding) {
        match &node.payload{
            HuffmanPayload::Leaf { chr } => {
                existing_encodings[*chr as usize] = current_encoding;
            },
            HuffmanPayload::Internal { children} => {
                let left = children[0];
                let right = children[1];
                let left_encoding = Encoding {
                    val: current_encoding.val * 2,
                    num_bits: current_encoding.num_bits + 1,
                };
                let right_encoding = Encoding {
                    val: current_encoding.val * 2 + 1,
                    num_bits: current_encoding.num_bits + 1,
                };
                Self::create_encoding_impl(tree, &tree[left], existing_encodings, left_encoding);
                Self::create_encoding_impl(tree, &tree[right], existing_encodings, right_encoding);
            },
        }
    }
    fn create_encoding(&self, tree: &HuffmanTree, N: usize) -> Vec<Encoding> {
        let mut encodings = vec![Encoding{ val: 0, num_bits: 0 };N];
        let zero_encoding = Encoding{ val: 0, num_bits: 0 };
        Self::create_encoding_impl(tree, self, &mut encodings, zero_encoding);
        encodings
    }
}

fn create_huffman_tree(mut tree: HuffmanTree) -> (HuffmanTree, u64) {
    let mut queue1_head = 0usize;
    let queue1_tail = tree.len();
    let mut queue2_head = tree.len();

    let mut total_num_bits = 0u64;
    while queue1_head < queue1_tail || queue2_head < (tree.len() - 1) {
        let left = if queue1_head >= queue1_tail {
            queue2_head += 1;
            queue2_head - 1
        } else if queue2_head >= tree.len() {
            queue1_head += 1;
            queue1_head - 1
        } else if tree[queue1_head].prio < tree[queue2_head].prio {
            queue1_head += 1;
            queue1_head - 1
        } else {
            queue2_head += 1;
            queue2_head - 1
        };

        let right = if queue1_head >= queue1_tail {
            queue2_head += 1;
            queue2_head - 1
        } else if queue2_head >= tree.len() {
            queue1_head += 1;
            queue1_head - 1
        } else if tree[queue1_head].prio < tree[queue2_head].prio {
            queue1_head += 1;
            queue1_head - 1
        } else {
            queue2_head += 1;
            queue2_head - 1
        };

        let new_node = HuffmanNode::new_inner(&tree, left, right);
        total_num_bits += new_node.prio;
        tree.push(new_node);
        
    }
    (tree, total_num_bits)

}

fn main() {
    let input_file: File = File::open("huffman.in").unwrap();
    let mut input_file: BufReader<File> = BufReader::new(input_file);
    let mut N = String::new();
    let _ = input_file.read_line(&mut N).unwrap();
    let N = N.trim().parse::<usize>().unwrap();
    let tree: HuffmanTree = input_file.lines().enumerate().map(|(idx,line)| {
        let vi = line.unwrap().trim().parse::<u64>().unwrap();
        HuffmanNode::new_leaf(vi, idx)
    }).collect();
    let (tree, total_num_bits) = create_huffman_tree(tree);
    let root = tree.last().unwrap();
    let encodings = root.create_encoding(&tree, N);
    let mut output_file = BufWriter::new(File::create("huffman.out").unwrap());
    let _ = writeln!(output_file, "{total_num_bits}").unwrap();
    for encoding in encodings {
        let _ = writeln!(output_file, "{} {}", encoding.num_bits, encoding.val);
    }
}
