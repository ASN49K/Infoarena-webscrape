#include <bits/stdc++.h>
#define ll long long
#define ld long double

using namespace std;

const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const int N = 1e6 + 1;

ifstream fin ("huffman.in");
ofstream fout ("huffman.out");

int n, x, nod;
pair<long long, int> q1[N], q2[N];
int son1[2 * N], son2[2 * N];
ll val[2 * N], ans;
ll sol[N];
int len[N];

void dfs (int nr, ll val, int depth = 0) {
  if (nr <= n) {
    sol[nr] = val;
    len[nr] = depth;
    return;
  }
  dfs(son1[nr], val * 2, depth + 1);
  dfs(son2[nr], val * 2 + 1, depth + 1);
}

int main()
{
  //ios_base::sync_with_stdio(false);
  //fin.tie(0); fout.tie(0);
  fin >> n;
  int l1 = 1, r1 = 0;
  int l2 = 1, r2 = 0;
  for (int i = 1; i <= n; i++) {
    fin >> x;
    val[i] = x;
    q1[++r1] = {x, i};
  }
  nod = n;
  for (int i = 1; i < n; i++) {
    vector<pair<long long, int> >lol;
    while (lol.size() < 2) {
      if (l2 > r2) {
        lol.push_back(q1[l1]);
        l1++;
      }
      else if (l1 > r1) {
        lol.push_back(q2[l2]);
        l2++;
      }
      else if (q1[l1] < q2[l2]) {
        lol.push_back(q1[l1]);
        l1++;
      }
      else {
        lol.push_back(q2[l2]);
        l2++;
      }
    }
    nod++;
    son1[nod] = lol[0].second;
    son2[nod] = lol[1].second;
    val[nod] = lol[0].first + lol[1].first;
    ans += val[nod];
    q2[++r2] = {val[nod], nod};
  }
  fout << ans << "\n"; 
  dfs(nod, 0);
  for (int i = 1; i <= n; i++)
    fout << len[i] << " " << sol[i] << "\n";
  return 0;
}
