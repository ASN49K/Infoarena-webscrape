#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <queue>

#define NMAX 1000005

using namespace std;

typedef struct {
    int bsize;
    long long number;
}Code;

typedef struct {
    int left, right;
}Tree;

inline void dfs(int node, Code **code, Tree *tree, int codification, int level){

    (*code)[node].bsize = level;
    (*code)[node].number = codification;

    if (tree[node].left != 0)
        dfs(tree[node].left, code, tree, 2 * codification, level + 1);

    if (tree[node].right != 0)
        dfs(tree[node].right, code, tree, 2 * codification + 1, level + 1);

    return;
}

int main()
{
    ifstream f("huffman.in");
    ofstream g("huffman.out");

    int n;
    priority_queue <pair <long long, int > > Q;

    f >> n;
    int *ap;
    ap = (int*) malloc(sizeof(int) * (n + 1));
    for (int i = 1; i <= n; i++){
        f >> ap[i];
        Q.push(make_pair(-ap[i], i));
    }

    int index = n;
    Tree *tree;
    tree = (Tree *) malloc(sizeof(Tree) * 4 * n);
    while (Q.size() != 1){

        long long app1 = Q.top().first;
        int ind1 = Q.top().second;
        Q.pop();

        long long app2 = Q.top().first;
        int ind2 = Q.top().second;
        Q.pop();

        index++;
        tree[index].left = ind1;
        tree[index].right = ind2;
        Q.push(make_pair(app1 + app2, index));
    }

    int root = Q.top().second;
    Q.pop();

    Code *code;
    code = (Code *) calloc(index + 1, sizeof(Code));
    dfs(root, &code, tree, 0, 0);

    int total_lenght = 0;
    for (int i = 1; i <= n; i++)
        total_lenght += code[i].bsize * ap[i];

    g << total_lenght << '\n';
    for (int i = 1; i <= n; i++)
        g << code[i].bsize << " " << code[i].number << '\n';

    f.close();
    g.close();

    return 0;
}
