#include <iostream>
#include <fstream>
#include <queue>
struct nod
{
  long long c;
  int l[2];
};

int counttt[1005000];
long b[1005000];
nod v[2005000];
std::ifstream fin("huffman.in");
std::ofstream fout("huffman.out");
int n;
int countt;
std::queue<int> q1;
std::queue<int> q2;
long long sum;
void get(std::queue<int> & q, int & v1)
{
  v1= q.front();
  q.pop();
}
inline void travel(int n1)
{
  for(int i=0;i<2;i++)
    if(v[n1].l[i]!=-1)
    {
      b[v[n1].l[i]]=(b[n1]<<1)+i;
      counttt[v[n1].l[i]]=counttt[n1]+1;
      travel(v[n1].l[i]);
    }
}

int main()
{
  fin>>n;
  for(int i=0;i<n;i++)
  {
    int j;
    fin>>j;
    v[i]={j,{-1,-1}};
    q1.push(i);
  }
  countt=n;
  while(!q1.empty() || q2.size()>1)
  {
    int v1[2];
    for(int i=0;i<2;i++)
    {
      if(q1.empty()|| (!q2.empty() && v[q1.front()].c>v[q2.front()].c))
        get(q2,v1[i]);
      else
        get(q1,v1[i]);
    }
    long long v0c=v[v1[0]].c;
    long long v1c=v[v1[1]].c;
    v[countt]={v0c+v1c,{v1[0],v1[1]}};
    q2.push(countt);
    sum+=v0c+v1c;
    countt++;
  }
  travel(countt-1);
  fout<<sum<<"\n";
  for(int i=0;i<n;i++)
    fout<<counttt[i]<<" "<<b[i]<<"\n";
}
