#include <iostream>
#include <cstdio>
#include <queue>

#define mp make_pair

using namespace std;

const int NMax = 2000005;
int n, n_init, dist[NMax];
long long sum = 0;

struct Parent_Bit
{
    int dad, bit;
} v[NMax];

struct Node
{
    int val, frecv;
} nod[NMax];

queue < Node > Q1, Q2;

Node minim()
{
    if(Q1.empty())
    {
        Node rez = Q2.front();
        Q2.pop();
        return rez;
    }

    if(Q2.empty())
    {
        Node rez = Q1.front();
        Q1.pop();
        return rez;
    }

    if(Q2.front().frecv < Q1.front().frecv)
    {
        Node rez = Q2.front();
        Q2.pop();
        return rez;
    }

    else
    {
        Node rez = Q1.front();
        Q1.pop();
        return rez;
    }
}

void Read()
{
    scanf("%d", &n);
    n_init = n;

    for(int i=1; i<=n; ++i)
    {
        int x;

        scanf("%d", &x);

        Node nod;

        nod.val = i;
        nod.frecv = x;

        Q1.push(nod);
    }
}

void Solve()
{
    while(Q1.size() + Q2.size() > 1)
    {
        Node nod1 = minim();
        Node nod2 = minim();

        v[nod1.val].dad = v[nod2.val].dad = ++n;
        v[nod1.val].bit = 0;
        v[nod2.val].bit = 1;

        Node nodc;
        nodc.val = n;
        nodc.frecv = nod1.frecv + nod2.frecv;
        Q2.push(nodc);
        sum += nodc.frecv;
    }
}

void Print()
{
    n = n_init;
    printf("%lld\n", sum);

    for(int i = n-1; i >=1 ; --i)
    {
        v[i].bit |= (v[v[i].dad].bit << 1);
        dist[i] = dist[v[i].dad] + 1;
    }

    for(int i=1; i<=n; ++i)
        printf("%d %d\n", dist[i], v[i].bit);
}

int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);

    Read();
    Solve();
    Print();
    return 0;
}
