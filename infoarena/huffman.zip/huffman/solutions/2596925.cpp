#include <bits/stdc++.h>

using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
typedef long long ll;

ll n, l, total;
ll nums[2000005], pow2[62];
pair<ll, ll> sons[2000005], sol[1000005];
queue<ll> que, inside;

void dfs(ll now, ll code, ll add);
ll getmin();

int main()
{

    fin >> n;
    l = n;

    for(ll i = 1; i <= n; ++i){
        fin >> nums[i];
        que.push(i);
    }

    for(ll i = 1; i < n; ++i){
        ll m1 = getmin(), m2 = getmin();

        total += (nums[m1] + nums[m2]);
        sons[++l] = {m1, m2};
        nums[l] = {nums[m1] + nums[m2]};
        inside.push(l);
    }

    dfs(l, 0, 0);

    fout << total << "\n";

    for(ll i = 1; i <= n; ++i){
        fout << sol[i].first << " " << sol[i].second << "\n";
    }

    return 0;
}

ll getmin(){
    ll ret;

    if(inside.empty()) {
        ret = que.front();
        que.pop();
    }
    else if(que.empty()) {
        ret = inside.front();
        inside.pop();
    }
    else{
        if(nums[que.front()] <= nums[inside.front()]){
            ret = que.front();
            que.pop();
        }
        else{
            ret = inside.front();
            inside.pop();
        }
    }

    return ret;
}

void dfs(ll now, ll code, ll add){
    if(!sons[now].first){
        sol[now] = {add, code};
        return;
    }

    dfs(sons[now].first, code * 2, add + 1);
    dfs(sons[now].second, code * 2 + 1, add + 1);
}
