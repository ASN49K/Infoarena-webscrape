#include <cstdio>
#include <queue>

using namespace std;

int left[2000102], right[2000102];
int v[2000102];
pair<int, long long> sol[1000100];
queue<int> q;
long long p2[64];
int n;

long long level = 0;
long long code = 0;
long long lg = 0;

void dfs(int node)
{
    if (node <= n)
    {
        sol[node].first = level;
        sol[node].second = code;
        lg += v[node] * level;
        return;
    }
    level++;
    dfs(left[node]);
    code += p2[level-1];
    dfs(right[node]);
    level--;
    code -= p2[level];
}

int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);

    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d", &v[i]);

    p2[0] = 1;
    for (int i = 1; i <= 60; i++)
        p2[i] = p2[i-1] * 2;

    int k = 1;
    int i1, i2;
    int counter = n;
    while (1)
    {
        if (!q.empty())
        {
            if (v[q.front()] < v[k] || k > n)
            {
                i1 = q.front();
                q.pop();
            }
            else
                i1 = k++;
        }
        else
            i1 = k++;

        if (!q.empty())
        {
            if (v[q.front()] < v[k] || k > n)
            {
                i2 = q.front();
                q.pop();
            }
            else
                i2 = k++;
        }
        else
        {
            if (k > n)
                break;
            else
                i2 = k++;
        }

        left[++counter] = i1;
        right[counter] = i2;
        v[counter] = v[i1] + v[i2];
        q.push(counter);
    }

    dfs(counter);

    printf("%I64d\n", lg);
    for (int i = 1; i <= n; i++)
        printf("%d %I64d\n", sol[i].first, sol[i].second);

    return 0;
}
