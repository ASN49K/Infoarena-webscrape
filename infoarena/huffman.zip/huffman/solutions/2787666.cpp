#include<iostream>
#include<deque>
#include<fstream>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

const int mx=2e6+100;

int n,l[mx],r[mx],d[mx];
long long ans[mx],c[mx];

deque<int> v,inter;

void read(){
	in>>n;

	for(int i=1;i<=n;i++){
		in>>c[i];
		v.push_back(i);
	}
}

int get_minimal(){
	int to_return;

	if(v.empty()){
		to_return=inter.front();
		inter.pop_front();
	}
	else if(inter.empty()){
		to_return=v.front();
		v.pop_front();
	}
	else{
		if(c[inter.front()]<c[v.front()]){
			to_return=inter.front();
			inter.pop_front();
		}
		else{
			to_return=v.front();
			v.pop_front();
		}
	}
	return to_return;
}

void dfs(int node,long long repr,int depth){
	if(l[node]==0 && r[node]==0){
		ans[node]=repr;
		d[node]=depth;
	}		
	else{
		dfs(l[node],repr<<1,depth+1);
		dfs(r[node],(repr<<1)+1,depth+1);
	}
}

void solve(){
	int cnt=n+1;	
	while(v.size()+inter.size()!=1){

		int a=get_minimal();
		int b=get_minimal();

		l[cnt]=a;
		r[cnt]=b;
		c[cnt]=c[a]+c[b];
		inter.push_back(cnt);

		cnt++;
	}

	int now=inter.front();
	dfs(now,0,0);

	long long total=0;
	for(int i=1;i<=n;i++){
		total+=c[i]*d[i];
	}

	out<<total<<'\n';
	for(int i=1;i<=n;i++){
		out<<d[i]<<" "<<ans[i]<<'\n';
	}
}

int main(){
	read();
	solve();
	return 0;
}
