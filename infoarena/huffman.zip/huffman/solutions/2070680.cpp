#include <cstdio>
#include <queue>
#include <cmath>
 
using namespace std;
 
struct node {
   
  node (int val, bool is) {
    for (auto &x : next_node) {
      x = NULL;
    }
    this -> val = val;
    this -> is_leaf = is;
  }
 
  bool is_leaf;
  long long val;
  node* next_node[2];
};
 
void get_cur(queue < node* > &in_q, queue < node* > &sec_q, node* &cur_n) {
 
  if (in_q.size() and sec_q.size()) {
    if (in_q.front() -> val <= sec_q.front() -> val) {
      cur_n = in_q.front();
      in_q.pop();
    }
    else {
      cur_n = sec_q.front();
      sec_q.pop();
    }
  }
  else if (in_q.size()) {
    cur_n = in_q.front();
    in_q.pop();
  }
  else {
    cur_n = sec_q.front();
    sec_q.pop();
  }  
}

void Print(long long cur_code, int cur_len, node* cur_node) {
 
  if (cur_node -> is_leaf) {
    printf("%d %lld\n", cur_len, cur_code);
    return;
  }
 
  Print(cur_code << 1, cur_len + 1, cur_node -> next_node[0]);
  Print(cur_code << 1 | 1, cur_len + 1, cur_node -> next_node[1]);
}
 
int main(int argc, char const *argv[]) {
   
  freopen("huffman.in", "r", stdin);
  freopen("huffman.out", "w", stdout);

  int n;  
  scanf("%d", &n);
 
  node* cur = NULL;
  node* cur_left = NULL;
  node* cur_right = NULL;
  queue < node* > in_q;
  queue < node* > sec_q;
 
  for (int i = 1; i <= n; i ++) {
     
    int val;
    scanf("%d ", &val);
    in_q.push(new node(1ll * val, true));
  }
 
  long long sum = 0;
  while (in_q.size() + sec_q.size() > 1) {
 
    get_cur(in_q, sec_q, cur_left);
    get_cur(in_q, sec_q, cur_right);
 
    cur = new node(cur_left -> val + cur_right -> val, false);
    cur -> next_node[0] = cur_left;
    cur -> next_node[1] = cur_right;
    sec_q.push(cur);
    sum += cur -> val;
  }
 
  printf("%lld\n", sum);
  Print(0, 0, cur);
}