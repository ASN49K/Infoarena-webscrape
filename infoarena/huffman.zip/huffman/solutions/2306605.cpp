#include<cstdio>
const int N=1000001;
long long q[N];
int n,i,j,k,s[N],d[N],r[N],p[N];
char t[9];
void A(int k,long long a,int b)
{
    k>n?A(s[k-n],2*a,b+1),A(d[k-n],2*a+1,b+1):p[k]=b,q[k]=a;
}
int main()
{
    freopen("huffman.in","r",stdin),freopen("huffman.out","w",stdout),fgets(t,9,stdin);
    for(j=0;t[j]!='\n';j++)
        n=n*10+(t[j]-'0');
    for(i=1;i<=n;i++)
	{
        fgets(t,9,stdin),q[i]=1000001;
        for(j=0;t[j]!='\n';j++)
            r[i]=r[i]*10+(t[j]-'0');
    }
    for(k=j=i=1;i<n;q[0]+=q[i++])
    	if(k<n&&r[k+1]<=q[j])
        	q[i]=r[k]+r[k+1],s[i]=k++,d[i]=k++;
    	else if(q[j+1]<=r[k]||k==n+1)
        	q[i]=q[j]+q[j+1],s[i]=n+j++,d[i]=n+j++;
    	else
        	q[i]=r[k]+q[j],s[i]=k++,d[i]=n+j++;
    printf("%lld\n",q[0]),A(2*n-1,0,0);
    for(i=1;i<=n;i++)
        printf("%d %lld\n",p[i],q[i]);
}
