#include <fstream>
#include <queue>
#define nMax 2000050
typedef long long ll;

using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

ll fr[nMax], ln[nMax], b10[nMax], G[nMax][2];
queue<int> Q[3];

int Min()
{
    int x;
    if(Q[1].empty())
    {
        x = Q[2].front();
        Q[2].pop();
        return x;
    }
    if(Q[2].empty())
    {
        x = Q[1].front();
        Q[1].pop();
        return x;
    }
    if(fr[Q[1].front()] <= fr[Q[2].front()])
    {
        x = Q[1].front();
        Q[1].pop();
        return x;
    }
    x = Q[2].front();
    Q[2].pop();
    return x;
}

void dfs(int nod, ll val, int len)
{
    if(G[nod][0]==0)
    {
        ln[nod] = len;
		b10[nod] = val;
        return;
    }
    dfs(G[nod][0], val<<1LL, len+1);
    dfs(G[nod][1], (val<<1LL)+1, len+1);
}

int main()
{
    int n;
	fin >> n;
    for(int i=1; i<=n; i++)
	{
        fin >> fr[i];
		Q[1].push(i);
	}
	int nr=n;
	ll lg=0;
    while((Q[1].size()+Q[2].size())!=1)
    {
        int len=Min();
		int r=Min();
        Q[2].push(++nr);
        fr[nr]=fr[len]+fr[r];
        lg+=fr[nr];
        G[nr][0]=len;
        G[nr][1]=r;
    }
    dfs(nr, 0, 0);
    fout << lg << '\n';
    for(int i=1; i<=n; i++)
        fout << ln[i] << " " << b10[i] << '\n';
    return 0;
}
