#include <fstream>
#include<vector>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct lol{
     int copilmic;
     int copilmare;
    long long int val;
};

int adancimea[1000002];
long long codu[1000002];
vector <lol> G;

void bfs(int nod, int adancime,long long int cod);

int main()
{
    long long int n,fr2s,i,lungime=0,y,k,j,maimic,indicemic,maimare,indicemare,el1,el2,radacina;
    fin>>n;
    lol x;
    for(i=0; i<n;i++)
        {
            fin>>y;
            x.val=y;
            x.copilmic=-1;
            x.copilmare=-1;
            G.push_back(x);
        }
    j=0;
    k=n;
    fr2s=n;
    while(j<n || k<fr2s)
    {
        el1=-1,el2=-1;
        if(j<n) el1=G[j].val;
        if(k<fr2s) el2=G[k].val;
        if(el1!=-1 && (el1<=el2 || el2==-1)){
            maimic=el1;
            indicemic=j;
            j++;
        }
        else if(el2!=-1 && (el1>el2 || el1==-1)){
            maimic=el2;
            indicemic=k;
            k++;
        }

        el1=-1,el2=-1;
        if(j<n) el1=G[j].val;
        if(k<fr2s) el2=G[k].val;
         if(el1!=-1 && (el1<=el2 || el2==-1)){
            maimare=el1;
            indicemare=j;
            j++;
        }
        else if(el2!=-1 && (el1>el2 || el1==-1)){
            maimare=el2;
            indicemare=k;
            k++;
        }
        if(el1==-1 && el2==-1) {
                radacina=indicemic;
                break;
        }
        lol nod_nou;
        nod_nou.val=maimic+maimare;
        nod_nou.copilmic=indicemic;
        nod_nou.copilmare=indicemare;
        fr2s++;
        G.push_back(nod_nou);
        lungime+=nod_nou.val;
    }
    fout<<lungime<<'\n';
    bfs(radacina,0,0);
    for(i=0;i<n;i++)
        fout<<adancimea[i]<<" "<<codu[i]<<'\n';
    return 0;
}

void bfs(int nod,  int adancime,long long int cod){
    if(G[nod].copilmic==-1) //nod final
        {
            adancimea[nod]=adancime;
            codu[nod]=cod;
            return;
        }

        bfs(G[nod].copilmare, adancime+1, cod*2+1);
        bfs(G[nod].copilmic, adancime+1, cod*2);

}
