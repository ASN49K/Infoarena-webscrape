#include <fstream>
#include <queue>

using namespace std;

struct nod{
    long long x;
    int f[2];
}nod[2000005];

int n;
long long sol, lg[1000005], cd[1000005];
queue<int> q1, q2;

void dfs(int poz, int cod, int level)
{
    if(nod[poz].f[0]){
        dfs(nod[poz].f[0], cod*2, level+1);
        dfs(nod[poz].f[1], cod*2+1, level+1);
    }else{
        lg[poz] = level;
        cd[poz] = cod;
    }
}

int main()
{
    ifstream fin ("huffman.in");
    ofstream fout ("huffman.out");
    fin >> n;
    for (int i = 1; i <= n; ++i){
        fin >> nod[i].x;
        q1.push(i);
    }
    int k = n;
    while(q1.size() + q2.size() > 1){
        ++k;
        if(!q2.size()){
            nod[k].f[0] = q1.front();
            nod[k].x += nod[q1.front()].x;
            q1.pop();
            nod[k].f[1] = q1.front();
            nod[k].x += nod[q1.front()].x;
            q1.pop();
        }
        else if (!q1.size()){
            nod[k].f[0] = q2.front();
            nod[k].x += nod[q2.front()].x;
            q2.pop();
            nod[k].f[1] = q2.front();
            nod[k].x += nod[q2.front()].x;
            q2.pop();
        }else{
            if(nod[q1.front()].x < nod[q2.front()].x){
                nod[k].f[0] = q1.front();
                nod[k].x += nod[q1.front()].x;
                q1.pop();
            }else{
                nod[k].f[0] = q2.front();
                nod[k].x += nod[q2.front()].x;
                q2.pop();
            }
            bool ye = false;
            if(q1.size() > 0)
                nod[k].f[1] = q1.front();
            if(q1.size() == 0 || nod[q2.front()].x < nod[q1.front()].x)
                nod[k].f[1] = q2.front(),
                ye = true;
            if(!ye){
                nod[k].x += nod[q1.front()].x;
                q1.pop();
            }else{
                nod[k].x += nod[q2.front()].x;
                q2.pop();
            }
        }
        sol += nod[k].x;
        q2.push(k);
    }
    dfs(k, 0, 0);
    fout << sol << "\n";
    for (int i = 1; i <= n; ++i)
        fout << lg[i] << " " << cd[i] << "\n";
    fin.close();
    fout.close();
    return 0;
}
