#include <cstdio>
#define tip long long
#define N 1000010
using namespace std;
tip n,i,val[2*N],fiu_st[N],fiu_dr[N],LG[N],VL[N],top1,top2,front1,front2,poz1,poz2,sol,lg,bit,vl,x;
inline tip select()
{
    if(top1<front1)
    {
        top1=top2;
        front1=front2;
        front2=top1+1;
    }
    if(top2<front2)
        return front1++;
    return val[front1]<=val[front2]?front1++:front2++;
}
void DF(tip nod,tip lg,tip vl)
{
    if(fiu_st[nod])
    {
        DF(fiu_st[nod],lg+1,vl*2);
        DF(fiu_dr[nod],lg+1,vl*2+1);
    }
    else
    {
        LG[nod]=lg;
        VL[nod]=vl;
    }
}
int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    scanf("%lld",&n);
    for(i=1;i<=n;i++)
        scanf("%lld",&val[i]);
    top1=top2=n;
    front1=1;
    front2=top2+1;
    for(i=n+1;i<2*n;i++)
    {
        poz1=select();
        poz2=select();
        x=++top2;
        fiu_st[x]=poz1;
        fiu_dr[x]=poz2;
        val[top2]=val[poz1]+val[poz2];
        sol+=val[top2];
    }
    printf("%lld\n",sol);
    DF(i-1,0,0);
    for(i=1;i<=n;i++)
        printf("%lld %lld\n",LG[i],VL[i]);
    return 0;
}
