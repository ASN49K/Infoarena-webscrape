#include <fstream>
#define nmax 1000002
#define uss unsigned long long
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct muchie {
    int dr, st;
    uss val;
}sir2[2 * nmax];

uss s;
uss sir1[nmax];
int n, k = 0, l = 1, c = 1;

struct mem{
    int bit;
    uss val;
}sir[nmax];

uss sum = 0;

int main()
{
    fin>>n;
    c = n + 1;
    k = n;
    for(int i = 1; i <= n; ++i)
        fin>>sir1[i];
    for(int i = 1; i < n; ++i)
    {
        if((sir1[l + 1] <= sir2[c].val || c > k) && l + 1 <= n)
        {
            sir2[++k].val = sir1[l++];
            sir2[k].val += sir1[l++];
            sir2[l - 2].st = k;
            sir2[l - 1].dr = k;
            sum += sir2[k].val;
            continue;
        }
        if((sir2[c + 1].val <= sir1[l] || l > n) && c + 1 <= k)
        {
            sir2[++k].val = sir2[c++].val;
            sir2[k].val += sir2[c++].val;
            sir2[c - 2].st = k;
            sir2[c - 1].dr = k;
            sum += sir2[k].val;
            continue;
        }
        sir2[++k].val = sir2[c++].val;
        sir2[k].val += sir1[l++];
        sum += sir2[k].val;
        sir2[c - 1].st = k;
        sir2[l - 1].dr = k;
    }
    for(int i = 1; i <= n; ++i)
    {
        int nod = i;
        long long s = 1;
        int l = 0;
        while(nod != k)
        {
            sir[i].bit++;
            if(sir2[nod].dr)
            {
                sir[i].val +=s;
                nod = sir2[nod].dr;
            }
            else
                nod = sir2[nod].st;
            s*=2;
        }
    }
    fout<<sum<<"\n";
    for(int i = 1; i <= n; ++i)
    {
        fout<<sir[i].bit<<" "<<sir[i].val<<"\n";
    }
    return 0;
}
