#include <fstream>

#define INF 1LL*1000000009*1000000009
#define nMax 1000009
using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct noduri
{
    int cpt;
    int f[2];
}node[2*nMax];
int q[2][2*nMax], l[2], r[2], k, n;
long long code[2*nMax], lg[2*nMax], Sol;
void read()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>node[i].cpt;
        q[0][i]=i;
    }
}
void dfs(long long  poz, long long cod, long long lev)
{
    if(node[poz].f[0])
    {
        dfs(node[poz].f[0], cod*2, lev+1);
        dfs(node[poz].f[1], cod*2+1, lev+1);
        return;
    }
    lg[poz]=lev;
    code[poz]=cod;
}
void solve()
{
    k=n;
    l[0]=l[1]=1;
    r[0]=n;
    while(l[0]+l[1]<=r[0]+r[1])
    {
        k++;

        for(int j=0;j<2;j++)
        {
            int poz=0;
            long long Min=INF;
            for(int i=0;i<2;i++)
            {
                if(node[q[i][l[i]]].cpt<Min && l[i]<=r[i])
                {
                    poz=i;
                    Min=node[q[i][l[i]]].cpt;
                }
            }
            node[k].f[j]=q[poz][l[poz]];
            node[k].cpt+=Min;
            l[poz]++;
        }
        Sol+=node[k].cpt;
        q[1][++r[1]]=k;
    }

    dfs(k, 0, 0);
}
void write()
{
    fout<<Sol<<'\n';

    for(int i=1;i<=n;i++)
        fout<<lg[i]<<" "<<code[i]<<'\n';
}
int main()
{
    read();
    solve();
    write();
    return 0;
}
