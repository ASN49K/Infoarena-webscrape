#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e6;

int father[2 * NMAX + 1];
int value[2 * NMAX + 1];
int v[NMAX + 1];

int x[2 * NMAX + 1];
int siz[NMAX + 1];
int j;

void b( int i ) {
    if ( i == j || siz[i] > 0 )
        return;
    b( father[i] );
    x[i] = 2 * x[father[i]] + value[i];
    siz[i] = siz[father[i]] + 1;
}
queue <pair<long long, int>> q[2];

pair<long long, int> minim() {
    pair<int, int> a;
    if ( q[0].size() == 0 ) {
        a = q[1].front();
        q[1].pop();
    } else if ( q[1].size() == 0 ) {
        a = q[0].front();
        q[0].pop();
    } else {
        if ( q[0].front().first < q[1].front().first ) {
            a = q[0].front();
            q[0].pop();
        } else {
            a = q[1].front();
            q[1].pop();
        }
    }
    return a;
}
int main() {
    ifstream fin( "huffman.in" );
    ofstream fout( "huffman.out" );
    int n, i, a;
    fin >> n;
    for ( i = 0; i < n; i ++ ) {
        fin >> v[i];
        q[0].push( { v[i], i } );
    }
    j = n;
    i = 0;
    while ( q[0].size() + q[1].size() > 1 ) {
        while ( q[i].size() > 0 ) {
            pair<long long, int> a = minim();
            pair<long long, int> b = minim();
            father[a.second] = father[b.second] = j;
            value[a.second] = 0, value[b.second] = 1;
            q[!i].push( {a.first + b.first, j} );
            j ++;
        }
        i = !i;
    }
    j --;
    long long lg = 0;
    vector <pair<long long, long long>> ans;
    for ( i = 0; i < n; i ++ ) {
        b(i);
        ans.push_back( {siz[i], x[i]} );
        lg += 1LL * siz[i] * v[i];
    }
    fout << lg << '\n';
    for ( auto it : ans ) {
        fout << it.first << ' ' << it.second << '\n';
    }
    return 0;
}
