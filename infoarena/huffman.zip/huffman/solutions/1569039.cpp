#include <cstdio>
#define nmax 1000005
#define inf 0x3f3f3f3f

using namespace std;

long N,fh[nmax],q[2][nmax],l[2],r[2],k,p,i,j;
long long b[nmax],m,sol = 0;
struct nod{
   long long val;
   long fii[2];
}H[2 * nmax];

void df(long poz,long long cod,long nivel){

   if(H[poz].fii[0]){
      df(H[poz].fii[0],cod*2,nivel+1);
      df(H[poz].fii[1],cod*2+1,nivel+1);
      return;
   }

   fh[poz] = nivel;
   b[poz] = cod;
}

void Losung(){
  k = N;
  l[0] = l[1] = 1;
  r[0] = N;

  while(l[0]+l[1]<=r[0]+r[1]){
    ++k;
    for(i = 0;i < 2;++i){
      p = 0;
      m = inf;
      for(j = 0;j < 2;++j)
        if(H[q[j][l[j]]].val < m && l[j]<=r[j])
          {
            p = j;
            m = H[q[j][l[j]]].val;
          }
      H[k].fii[i] = q[p][l[p]];
      H[k].val += H[q[p][l[p]]].val;
      ++l[p];
    }
    sol += H[k].val;
    q[1][++r[1]] = k;
  }
  df(k,0,0);
}

int main(){
  freopen("huffman.in","r",stdin);
  freopen("huffman.out","w",stdout);

  scanf("%d ",&N);
  for(i = 1;i <= N;++i){
     scanf("%d ",&H[i].val);
     q[0][i] = i;
  }
  Losung();
  printf("%lld\n",sol);
  for(i = 1;i <= N;++i)printf("%d %lld\n",fh[i],b[i]);
  return 0;
}
