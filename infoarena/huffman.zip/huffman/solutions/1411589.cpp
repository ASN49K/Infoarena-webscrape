#include <bits/stdc++.h>
#define ll long long
#define N 2000005
using namespace std;
ll a[N], fs[N], fd[N], poz1, poz2, n, i, top1, top2, front1, front2, sol, Lg[N], Cod[N];
ll select()
{
    if(top1 < front1)
    {
        top1 = top2;
        front1 = front2;
        front2 = top2 + 1;
    }
    if(top2 < front2)
        return front1++;
    return a[front1] <= a[front2] ? front1++ : front2++;
}
void df(ll nod, ll lg, ll cod)
{
    if(fs[nod])
    {
        df(fs[nod], lg + 1, 2 * cod);
        df(fd[nod], lg + 1, 2 * cod + 1);
    }
    else
    {
        Lg[nod] = lg;
        Cod[nod] = cod;
    }
}
int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    scanf("%lld", &n);
    for(i = 1; i <= n; i++)
        scanf("%lld", &a[i]);
    top1 = top2 = n;
    front1 = 1;
    front2 = top2 + 1;
    for(i = n + 1; i < 2 * n; i++)
    {
        poz1 = select();
        poz2 = select();
        a[++top2] = a[poz1] + a[poz2];
        fs[top2] = poz1;
        fd[top2] = poz2;
        sol += a[top2];
    }
    printf("%lld\n", sol);
    df(i - 1, 0, 0);
    for(i = 1; i <= n; i++)
        printf("%lld %lld\n", Lg[i], Cod[i]);
    return 0;
}
