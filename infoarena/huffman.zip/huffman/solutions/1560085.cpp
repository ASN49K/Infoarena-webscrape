# include <fstream>
# include <algorithm>
# include <cstring>
# define inf 1LL<<60
# define NR 1000005
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");
struct elem {
    long long val;
    long long fiu[2];
}nod[2*NR+5];
struct folosite {
    long long nr;
    long long ind;
}used[NR];
struct solutie {
    long long nr;
    int l;
}sol[NR];

int i,j,n,m,x,y,nrsol,ci,cs,copil,V,VV,o;
int a[NR];
long long minn;
void solve () {
    ci=1; cs=0; VV=1;
    used[ci].nr=inf;

    for (o=n+1; o<=2*n-1; ++o) {
        for (j=0; j<2; ++j) {
            if ((a[VV] < used[ci].nr || (ci>cs)) && VV<=n)
                 minn=a[VV], copil=VV, VV++;
            else minn=used[ci].nr, copil=used[ci].ind, ci++;

            nod[o].fiu[j]=copil;
            nod[o].val+=minn;
        }
        ++cs;
        used[cs].nr=nod[o].val; used[cs].ind=o;
    }
}
void make_numere (long long V, long long nr, int l) {
    if (nod[V].fiu[0]) {
        make_numere (nod[V].fiu[0], nr*2, l+1);
        make_numere (nod[V].fiu[1], nr*2+1, l+1);
    }
    else {
        sol[V].l=l; sol[V].nr=nr;
    }
}
int main ()
{
    f>>n;
    for (i=1; i<=n; ++i) {
        f>>a[i];
        nod[i].val=a[i];
    }
    solve ();
    make_numere (2*n-1, 0, 0);

    g<<nod[2*n-1].val<<"\n";
    for (i=1; i<=n; ++i)
        g<<sol[i].l<<" "<<sol[i].nr<<"\n";

    return 0;
}
