#include <bits/stdc++.h>

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct Nod
{
    long long info;
    long long fr;
    Nod *left, *right;
    Nod(const long long& info, const long long& fr, Nod *left, Nod *right) : info(info), fr(fr), left(left), right(right) {};
};
class cmp_node
{
public:
    inline bool operator() (const Nod* a, const Nod* b)
    {
        return a->fr > b->fr;
    }
};
long long n, i, fr, lg_txt;
priority_queue<Nod*, vector<Nod*>, cmp_node> q;
vector<pair<int, int>> coded;

Nod* Huffman()
{
    for(i = 1; i < n; i++)
    {
        Nod *x = q.top(); q.pop();
        Nod *y = q.top(); q.pop();
        Nod *z = new Nod(0, x->fr + y->fr, x, y);
        q.push(z);
    }
    return q.top();
}

inline void get_solution(const Nod* node, const long long& code, const long long& depth)
{
    if(node == NULL) return;
    if(node->left == NULL && node->right == NULL) coded[node->info] = {depth, code};
    else lg_txt += node->fr;
    get_solution(node->left, code * 2, depth + 1);
    get_solution(node->right, code * 2 + 1, depth + 1);
}

int main()
{
    fin >> n;
    coded.resize(n + 1);
    for(i = 1; i <= n; i++)
    {
        fin >> fr;
        Nod *x = new Nod(i, fr, NULL, NULL);
        q.push(x);
    }
    Nod *tree = Huffman();
    ostringstream output;
    get_solution(tree, 0, 0);
    coded.erase(coded.begin());
    fout<<lg_txt<<"\n";
    for(const auto& it : coded)
        fout<<it.first<<" "<<it.second<<"\n";
    return 0;
}
