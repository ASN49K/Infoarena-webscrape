#include<fstream>
using namespace std;

int k,n,i,a[1000100],lim,p1,p2,u1,u2,c[1000100],j,niv[2000100],wb[2000100][2];
long long w[2000100],b[2000100],lg;


void dfs(int nod, int nivel, long long bb)
{
    niv[nod]=nivel;
    b[nod]=bb;
    if(wb[nod][1])
    {
        dfs(wb[nod][1],nivel+1,bb<<1);
        dfs(wb[nod][0],nivel+1,(bb<<1)+1);
    }
}

int main()
{
    ifstream f("huffman.in");
    ofstream g("huffman.out");
    f>>n;
    for(i=1;i<=n;i++)
        f>>a[i];
    k=0;
    lim=2*n-1;
    p1=1;
    u1=n;
    p2=1;
    u2=0;
    while(k<lim)
    {
        if(a[p1+1] && (a[p1+1]<=w[c[p2]] || p2>u2))
        {
            w[++k]=a[p1];
            lg+=w[k];
            w[++k]=a[p1+1];
            lg+=w[k];
            w[++k]=a[p1]+a[p1+1];
            lg+=w[k];
            c[++u2]=k;
            a[p1+1]=wb[k][0]=k-1;
            a[p1]=wb[k][1]=k-2;
            p1+=2;
        }
        else
            if(w[c[p2+1]] && (w[c[p2+1]]<=a[p1] || p1>u1))
            {
                w[++k]=w[c[p2]]+w[c[p2+1]];
                lg+=w[k];
                c[++u2]=k;
                wb[k][0]=c[p2+1];
                wb[k][1]=c[p2];
                p2+=2;
            }
            else
                if(p1<=u1 && p2<=u2 && w[c[p2]]<=a[p1] && (a[p1]<=w[c[p2+1]] || p2==u2))
                {
                    w[++k]=a[p1];
                    lg+=w[k];
                    w[++k]=a[p1]+w[c[p2]];
                    lg+=w[k];
                    c[++u2]=k;
                    a[p1]=wb[k][0]=k-1;
                    wb[k][1]=c[p2];
                    p1++;
                    p2++;
                }
                else
                    if(p1<=u1 && p2<=u2 && a[p1]<=w[c[p2]] && (w[c[p2]]<=a[p1+1] || p1==u1))
                    {
                        w[++k]=a[p1];
                        lg+=w[k];
                        w[++k]=a[p1]+w[c[p2]];
                        lg+=w[k];
                        c[++u2]=k;
                        wb[k][0]=c[p2];
                        a[p1]=wb[k][1]=k-1;
                        p1++;
                        p2++;
                    }
    }
    dfs(lim,0,0);
    lg-=w[lim];
    g<<lg<<'\n';
    for(i=1;i<=n;i++)
        g<<niv[a[i]]<<' '<<b[a[i]]<<'\n';
    return 0;
}
