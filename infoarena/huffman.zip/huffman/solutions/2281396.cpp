#include <cstdio>
#include <queue>

using namespace std;

long long n, nrNod;
bool ok = 1;

long long fiust[2000001], fiudr[2000001], aparitii[2000001];
long long len[1000001], ans[1000001], x1, x2, sum;

void dfs(long long nod, long long val, long long l)
{
    if(nod <= n)
    {
        len[nod] = l;
        ans[nod] = val;
        return;
    }
    dfs(fiust[nod], (val << 1), l+1);
    dfs(fiudr[nod], (val << 1) + 1, l+1);
}

class Compare
{
public:
    bool operator() (long long l, long long r)
    {
        return aparitii[l] > aparitii[r];
    }
};

priority_queue <long long, vector<long long>, Compare> pq;

int main()
{
    freopen("huffman.in", "r", stdin);
    freopen("huffman.out", "w", stdout);
    scanf("%d", &n);
    nrNod = n;
    for(long long i = 1; i <= n; i++)
    {
        scanf("%d", &aparitii[i]);
        pq.push(i);
    }
    while(ok)
    {
        x1 = pq.top();
        pq.pop();
        if(pq.empty())
            ok = 0;
        else
        {
            x2 = pq.top();
            pq.pop();
            nrNod++;
            fiust[nrNod] = x1;
            fiudr[nrNod] = x2;
            aparitii[nrNod] = aparitii[x1]+aparitii[x2];
            pq.push(nrNod);
        }
    }
    dfs(nrNod, 0, 0);
    for(long long i = 1; i <= n; i++)
        sum += aparitii[i] * len[i];
    printf("%lld\n", sum);
    for(long long i = 1; i <= n; i++)
        printf("%lld %lld\n", len[i], ans[i]);
    return 0;
}
