#include <fstream>
#include <queue>

using namespace std;

ifstream fin( "huffman.in" );
ofstream fout( "huffman.out" );

const int MAXN = 1e6 + 1;
const long long INF = 1e18 + 1;

struct huffnode {
  huffnode( huffnode *left = NULL, huffnode *right = NULL, long long val = INF, int lf = -1 ):
	  		left( left ), right( right ), val( val ), lf( lf ) {}
  huffnode *left, *right;
  long long val;
  int lf;
};

huffnode *root;

queue<huffnode*> init, sums;

huffnode* get() {
  huffnode *x;

  if ( init.size() == 0 ) {
    x = sums.front();
	sums.pop();
    return x;
  } 
  if ( sums.size() == 0 ) {
    x = init.front();
	init.pop();
    return x;
  }  
  if ( init.front() -> val > sums.front() -> val ) {
	x = sums.front();
	sums.pop();
  } else {
	x = init.front();
	init.pop();
  }
  return x;
}

void addNode() {
  huffnode *x, *y;
  
  x = get();
  y = get();

  root = new huffnode( x, y, x -> val + y -> val, -1 );
  sums.push( root );
}

long long code[MAXN];
int len[MAXN];

long long acode;
int dep;

long long solve( huffnode *node ) {
  if ( node -> lf != -1 ) {
    code[node -> lf] = acode;
    len[node -> lf] = dep;
	return 0;
  }

  ++dep;
  acode *= 2;
  long long a = solve( node -> left );
  
  ++acode;
  long long b = solve( node -> right );
  
  --dep;
  acode = (acode - 1) / 2;

  return node -> val + a + b;
}

int main() {
  int n;
  long long f;

  fin >> n;

  for ( int i = 1; i <= n; ++i ) {
	fin >> f;
    init.push( new huffnode( NULL, NULL, f, i ) );
  }
  
  while ( init.size() + sums.size() > 1 ) {
	addNode();
  }

  dep = acode = 0;
  fout << solve( root ) << "\n";
  for ( int i = 1; i <= n; ++i ) {
    fout << len[i] << " " << code[i] << "\n";
  }
  fin.close();
  fout.close();
  return 0;
}
