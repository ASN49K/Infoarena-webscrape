#include <iostream>
#include <fstream>
#include <queue>

#define val first
#define nod second

#define lf first
#define rg second

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

const int NMAX = 1000001;

int N;
int V[NMAX];

priority_queue < pair < long long, long long >, vector < pair < long long, long long > >, greater < pair < long long, long long > >  > H;
priority_queue < pair < long long, long long > > sol;
long long lg;

pair < long long, long long > left_son, right_son;
long long node;

pair < long long, long long > tree[2*NMAX];

void Read()
{
    fin >> N;

    for( int i = 1; i <= N; ++i ){
        fin >> V[i];
        H.push( { V[i], i } );
        tree[i].lf = tree[i].rg = -1;
    }
}

void DFS( int nod, int lev, long long val )
{
    if( tree[nod].lf != -1 )
        DFS( tree[nod].lf, lev+1, val );

    if( tree[nod].rg != -1 ){

        val = ( val ^ ( 1LL << lev ) );
        DFS( tree[nod].rg, lev+1, val);
    }
    if( tree[nod].lf == -1 && tree[nod].rg == -1 ){
        lg += 1LL * lev * V[nod];
        sol.push( { lev, val } );
    }
}
void Solve()
{
    node = N+1;

    while( H.size() > 1 )
    {
        left_son = H.top();
        H.pop();
        right_son = H.top();
        H.pop();

        tree[node].lf = left_son.nod;
        tree[node].rg = right_son.nod;

        H.push( { left_son.val + right_son.val , node } );

        cout << left_son.val + right_son.val << ' ' << node << ' ' << tree[node].lf << ' ' << tree[node].rg << '\n';

        node++;
    }

    DFS( node-1, 0, 0 );

    fout << lg << '\n';

    while( !sol.empty() )
    {
        fout << sol.top().first << ' ' << sol.top().second << '\n';
        sol.pop();
    }
}
int main()
{
    Read();
    Solve();
    return 0;
}
