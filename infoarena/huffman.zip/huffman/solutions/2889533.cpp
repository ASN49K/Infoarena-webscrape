#include <iostream>
#include <fstream>
using namespace std;

#define NMax 1000100
#define inf 1LL * 1000000000 * 1000000000

struct nod
{
    long long v;
    long f[2];
} nod[2*NMax];

long long n, k, p, l[2], r[2];
long long q[2][NMax], lung[NMax];
long long b[NMax], m, s;

void df(long poz, long long cod, long nivel)
{
    if(nod[poz].f[0])
    {
        df(nod[poz].f[0], cod*2, nivel+1);
        df(nod[poz].f[1], cod*2+1, nivel+1);
        return;
    }
    lung[poz] = nivel;
    b[poz] = cod;
}

void sol()
{
    k = n;
    l[0] = l[1] = 1;
    r[0] = n;
    while(l[0] + l[1] <= r[0] + r[1])
    {
        ++k;
        for(int j=0; j<2; j++)
        {
            p = 0;
            m = inf;
            for(int i=0; i<2; i++)
            {
                if(nod[q[i][l[i]]].v < m && l[i] <= r[i])
                {
                    p = i;
                    m = nod[q[i][l[i]]].v;
                }
            }
            nod[k].f[j] = q[p][l[p]];
            nod[k].v += nod[q[p][l[p]]].v;
            l[p]++;
        }
        s += nod[k].v;
        q[1][++r[1]] = k;
    }
    df(k, 0, 0);
}

int main()
{
    ifstream in("huffman.in");
    ofstream out("huffman.out");

    in>>n;

    for(int i=1; i<=n; i++)
    {
        in>>nod[i].v;
        q[0][i] = i;
    }
    sol();
    out<<s<<"\n";
    for(int i=1; i<=n; i++)
    {
        out<<lung[i]<<" "<<b[i]<<"\n";
    }
    return 0;
}
