#include <iostream>
#include <queue>
#include <fstream>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

int n, tree[2][2000001], current, v[1000001];
unsigned long long lg = 0, sol[2][1000001];
priority_queue<pair<unsigned long long, unsigned long long>, vector<pair<unsigned long long, unsigned long long>>, greater<pair<unsigned long long, unsigned long long>>> heap;

int main()
{
    in >> n;
    current = n + 1;
    for(unsigned long long i = 1; i <= n; ++i)
    {
        in >> tree[0][i];
        heap.push({tree[0][i], i});
        v[i] = tree[0][i];
    }
    unsigned long long sum, poz1, poz2;
    while(heap.size() > 1)
    {
        sum = 0;
        sum += heap.top().first;
        poz1 = heap.top().second;
        heap.pop();
        sum += heap.top().first;
        poz2 = heap.top().second;
        heap.pop();
        heap.push({sum, current});
        tree[0][poz1] = 0;
        tree[1][poz1] = current;
        tree[0][poz2] = 1;
        tree[1][poz2] = current;
        tree[0][current] = -1;
        current++;
    }
//    for(int i = 1; i <= 2*n - 1; i++)
//    {
//        out << i << " " << tree[0][i] << " " << tree[1][i] << '\n';
//    }
    for(int i = 1; i <= n; ++i)
    {
        sol[0][i] = 1;
        int node = i;
        unsigned long long doi = 1;
        while(tree[0][node] != -1)
        {
            sol[0][i]++;
            sol[1][i] += doi * tree[0][node];
            node = tree[1][node];
            doi >> 1;
        }
        sol[0][i]--;
        lg += sol[0][i] * v[i];
    }
    out << lg << '\n';
    for(int i = 1; i <= n; ++i)
    {
        out << sol[0][i] << " " << sol[1][i] << '\n';
    }
    return 0;
}
