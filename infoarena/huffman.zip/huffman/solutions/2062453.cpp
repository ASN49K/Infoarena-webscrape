#include <fstream>
#include <queue>

using namespace std;

//ifstream cin ("huffman.in");
ofstream cout ("huffman.out");

pair<int , int> node[2000100];
long long val[2000100];
pair<int , long long> ans[1000100];

queue <int> q;
queue <int> Q;

class InParser {
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch() {
        ++sp;
        if (sp == 4096) {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char* nume) {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser& operator >> (int &n) {
        char c;
        while (!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }

    InParser& operator >> (long long &n) {
        char c;
        n = 0;
        while (!isdigit(c = read_ch()) && c != '-');
        long long sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }
};

void give_val(int &a ){
    if (q.empty()){
        a = Q.front();
        Q.pop();
    }
    else if (Q.empty()){
        a = q.front();
        q.pop();
    }
    else if (val[q.front()] < val[Q.front()]){
        a = q.front();
        q.pop();
    }
    else {
        a = Q.front();
        Q.pop();
    }
}

void dfs(int nod , int lv , long long val){

    if (node[nod].first == 0){
        ans[nod].first = lv;
        ans[nod].second = val;
        return;
    }

    dfs(node[nod].first , lv + 1 , (val << 1LL));
    dfs(node[nod].second , lv + 1 , (val << 1LL) + 1LL);

}

int main() {

    ios::sync_with_stdio(false);
    cout.tie(NULL);

    InParser fin("huffman.in");

    int n;
    fin>>n;

    for (int i=1; i<=n; i++){
        int a;
        fin>>a;
        val[i] = (long long) a;
        q.push(i);
    }

    long long cont = 0;
    int nod = n;

    while (q.size() + Q.size() > 1){

        int st , dr;

        give_val(st);
        give_val(dr);

        nod ++;
        cont += val[st] + val[dr];

        Q.push(nod);
        val[nod] = val[st] + val[dr];
        node[nod].first = st;
        node[nod].second = dr;
    }

    cout<<cont<<'\n';

    dfs(nod , 0 , 0);

    for (int i=1; i<=n; i++){
        cout<<ans[i].first<<" "<<ans[i].second<<'\n';
    }

    return 0;
}