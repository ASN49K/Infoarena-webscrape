#include <bits/stdc++.h>
using namespace std;
long long s;
struct data
{
    long long nr, len;
}auxi;
struct cmp2
{
    bool operator()(data a, data b)
    {
        return a.len < b.len;
    }
};
priority_queue <data, vector<data>, cmp2> Q2;
struct Nod
{
    long long nr_ord;  //numarul de ordine (primul/al doilea/ al n-lea elem)
    long long fr;      // frecv
    Nod* left;
    Nod* right;
};
struct cmp
{
    bool operator()(Nod* a, Nod* b)
    {
        return a -> fr > b -> fr;
    }
};
long long get_nr(string alfa)
{
    long long ans = 0;
    for(auto it : alfa)
    {
        if(it == '0') ans = ans * 2;
        if(it == '1') ans = ans * 2 + 1;
    }
    return ans;
}
void span(Nod *& node, string & a)
{
    if(node -> nr_ord != 0)
    {
        s = s + a.size() * node -> fr;
        auxi.len = a.size();
        auxi.nr = get_nr(a);
        Q2.push(auxi);
    }
    if(node -> right != NULL)
    {
        a = a + "1";
        span(node -> right, a);
        a.pop_back();
    }
    if(node -> left != NULL)
    {
        a = a + "0";
        span(node -> left, a);
        a.pop_back();
    }
}
priority_queue <Nod*, vector <Nod*>, cmp> Q;
long long i, n, x;
Nod *root, *aux, *aux1, *aux2;
string a;
int main()
{
    ifstream f("huffman.in");
    ofstream g("huffman.out");
    f >> n;
    for(i = 1; i <= n; i ++)
    {
        f >> x;
        aux = new Nod;
        aux -> left = NULL;
        aux -> right = NULL;
        aux -> fr = x;
        aux -> nr_ord = i;
        Q.push(aux);
    }
    while(!Q.empty())
    {
        aux = Q.top();
        Q.pop();
        if(Q.empty())break;
        aux1 = Q.top();
        Q.pop();
        root = new Nod;
        root -> nr_ord = 0;
        root -> fr = aux -> fr + aux1 -> fr;
        root -> left = aux;
        root -> right = aux1;
        Q.push(root);
    }
    root = aux;
    span(root, a);
    g << s << "\n";
    while(!Q2.empty())
    {
        auxi = Q2.top();
        Q2.pop();
        g << auxi.len << " " << auxi.nr << "\n";
    }
    return 0;
}
