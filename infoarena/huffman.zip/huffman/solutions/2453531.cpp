#include <bits/stdc++.h>
#define MAX 1000005
#define inf 1LL * 1000000000 * 1000000000
#define pt(i, n) for(int i = 0; i < n; i++)

using namespace std;

ifstream fin("huffman.in");
ofstream fout("huffman.out");

struct st
{
    long long val;
    int f[2];
}nod[2 * MAX];

int n;
int l[2];
int r[2];
int q[2][MAX];
int k, p;
long long ans;
int niv[MAX];
long long cd[MAX];

void solve()
{
    l[0] = l[1] = 1;
    r[0] = n;
    k = n;
    while (l[0] + l[1] <= r[0] + r[1])
    {
        ++k;
        pt(j, 2)
        {
            long long maxim = inf;
            p = 0;
            pt(i, 2)
            {
                if (nod[q[i][l[i]]].val < maxim && l[i] <= r[i])
                {
                    maxim = nod[q[i][l[i]]].val;
                    p = i;
                }
            }
            nod[k].f[j] = q[p][l[p]];
            nod[k].val += nod[q[p][l[p]]].val;
            l[p]++;
        }
        ans += nod[k].val;
        q[1][++r[1]] = k;
    }
}

void dfs(int ind, long long cod, int nivel)
{
    if (nod[ind].f[0])
    {
        dfs(nod[ind].f[0], 2 * cod, nivel + 1);
        dfs(nod[ind].f[1], 2 * cod + 1, nivel + 1);
        return;
    }
    niv[ind] = nivel;
    cd[ind] = cod;
}

int main()
{
    fin >> n;
    pt(i, n)
    {
        fin >> nod[i + 1].val;
        q[0][i + 1] = i + 1;
    }
    solve();
    fout << ans << "\n";
    dfs(k, 0, 0);
    pt(i, n)
        fout << niv[i + 1] << " " << cd[i + 1] << "\n";
    return 0;
}

