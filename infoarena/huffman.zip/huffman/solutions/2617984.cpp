#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1000005;

#define val first
#define nod second

int v[MAXN];
pair<int, long long> cod[MAXN];
queue<pair<long long, int>> init, intern;
vector<int> graf[2 * MAXN];

void dfs(int crt, int cif){
    int bit = 0;
    for(auto x: graf[crt]){
        cod[x].first = cif + 1;
        cod[x].second = (cod[crt].second << 1) + bit;
        dfs(x, cif + 1);
        bit = 1 - bit;
    }
}

int main()
{
    ifstream fin("huffman.in");
    ofstream fout("huffman.out");
    int n, pos = 0;
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> v[i];
        init.push({v[i], ++pos});
    }
    long long lg = 0;
    while(!init.empty() || intern.size() != 1){
        pair<long long, int> x = {1e9, 0}, y = {1e9, 0};
        if(!init.empty()) x = init.front();
        if(!intern.empty() && x.val > intern.front().val) x = intern.front();
        if(x.val == init.front().val) init.pop();
        else{
            lg += intern.front().val;
            intern.pop();
        }
        if(!init.empty()) y = init.front();
        if(!intern.empty() && y.val > intern.front().val) y = intern.front();
        if(y.val == init.front().val) init.pop();
        else{
            lg += intern.front().val;
            intern.pop();
        }
        intern.push({x.val + y.val, ++pos});
        graf[pos].push_back(x.nod); graf[pos].push_back(y.nod);
    }
    fout << lg + intern.front().val << "\n";
    dfs(pos, 0);
    for(int i = 1; i <= n; ++i) fout << cod[i].first << " " << cod[i].second << "\n";
    return 0;
}
