#include <iostream>
#include <fstream>

using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");
const int N = 2000010;
int n,t,x,y,b,i,h[N],L[N];
void get_best(int);
long long v[N],lg;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i];
    t=n+1;
    v[n+1]=v[1]+v[2];
    lg+=v[t];
    h[1]=2*t;h[2]=2*t+1;
    x=3;y=n+1;
    t++;
    for(;t<2*n;)
    {
        get_best(0);
        get_best(1);
        lg+=v[t++];
    }
    for(i=2*n-2;i>=1;i--)
    {
        t=h[i]/2;b=h[i]%2;
        h[i]=h[t]+(b<<L[t]);
        L[i]=L[t]+1;
    }
    g<<lg<<'\n';
    for(i=1;i<=n;i++)
        g<<L[i]<<' '<<h[i]<<'\n';
    return 0;
}
void get_best(int poz)
{
    poz=2*t+poz;
    if(x>n)
        {v[t]+=v[y];h[y++]=poz;}
    else
        if(y==t)
            {v[t]+=v[x];h[x++]=poz;}
            else
                if(v[x]<=v[y])
                    {v[t]+=v[x];h[x++]=poz;}
            else
                {v[t]+=v[y];h[y++]=poz;}
}
