#include <bits/stdc++.h>
using namespace std;
ifstream fin ("huffman.in");
ofstream fout ("huffman.out");
#define MAX_N 1000003
struct nod{
    long bonk;
    long shrek [2];
}nod [2 * MAX_N];
int l [2], r [2], v [MAX_N];
long N, n, poz, ans, mn;
long  qq [2][MAX_N], lg [MAX_N];
void dfs (long poz, long cod, long niv){
    if (nod [poz].shrek [0]){
        dfs (nod [poz].shrek [0], cod * 2, niv + 1);
        dfs (nod [poz].shrek [1], cod * 2 + 1, niv + 1);
        return ;
    }
    lg [poz] = niv, v [poz] = cod;
}
int main (){
    fin >> N;
    for (int i = 1; i <= N; i ++){
        fin >> nod [i].bonk;
        qq [0][i] = i;
    }
    n = N; r [0] = N;
    l [0] = l [1] = 1;
    while (l [0] + l [1] <= r [0] + r [1]){
        n ++;
        for (int j = 0; j < 2; j ++){
            poz = 0;
            mn = LONG_MAX;
            for (int i = 0; i < 2; i ++){
                if (nod [qq [i][l [i]]].bonk < mn && l [i] <= r [i]){
                    poz = i;
                    mn = nod [qq [i][l [i]]].bonk;
                }
            }
            nod [n].shrek [j] = qq [poz][l [poz]];
            nod [n].bonk += nod [qq [poz][l [poz]]].bonk;
            l [poz] ++;
        }
        ans += nod [n].bonk;
        qq [1][++ r [1]] = n;
    }
    dfs (n, 0, 0);
    fout << ans << '\n';
    for (int i = 1; i <= N; i ++)
        fout << lg [i] << " " << v [i] << '\n';
    return 0;
}
