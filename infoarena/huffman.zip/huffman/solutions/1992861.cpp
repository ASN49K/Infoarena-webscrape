#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
int tata[300010],nr;
long long sum=0,bit[300010],d[300010];
struct nod {
    int n;
    long long c;
    nod(int a, long long b)
    {
        n = a;
        c = b;
    }
    nod(){}
    const bool operator<(const nod &n) const
    {
        return c < n.c;
    }
};
struct coada
{
    nod Q[300010];
    int r=1,q=1;
    void pop()
    {
        r++;
    }
    bool empty()
    {
        return r>=q;
    }
    nod front()
    {
        return Q[r];
    }
    void push(const nod &val)
    {
        Q[q++] = val;
    }
    int size()
    {
         return q-r;
    }
}Q1,Q2;
nod mini()
{
    nod rez;
    if(Q1.empty())
    {
        rez=Q2.front();
        Q2.pop();
        return rez;
    }
        if(Q2.empty())
    {
        rez=Q1.front();
        Q1.pop();
        return rez;
    }
        if(Q1.front()<Q2.front())
        {
            rez=Q1.front();
            Q1.pop();
            return rez;
        }
    rez=Q2.front();
    Q2.pop();
    return rez;
}
void citire()
{
    int x;
    scanf("%d",&nr);
    for(int i=1;i<=nr;i++)
      {
          scanf("%d",&x);
          Q1.push(nod(i,x));
      }
    while(Q1.size()+Q2.size()>1)
    {
        nod min1=mini();
        nod min2=mini();
        tata[min1.n]=tata[min2.n]=++nr;
        bit[min1.n]=0;
        bit[min2.n]=1;
        Q2.push(nod(nr,min1.c+min2.c));
        sum+=min1.c+min2.c;
    }
    for(int i=nr-1;i>=1;i--)
    {
        bit[i]|=(bit[tata[i]]<<1);
        d[i]=d[tata[i]]+1;
    }
    printf("%lld\n",sum);
    for(int i=1;i<=nr-1;i++)
    {
        printf("%lld %lld\n",d[i],bit[i]);
    }
}

int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    citire();
  //  cout << "Hello world!" << endl;
    return 0;
}
