#include<fstream>
#include<cstdio>

using namespace std;

const int NMAX=2e6+5,buffsize=(1<<13);
FILE* fn;
long long Size[NMAX],code[NMAX];
int p[NMAX],len[NMAX];
char buff[buffsize+5];
int bpos=buffsize;
int read(){
    if(bpos==buffsize) fread(buff,1,buffsize,fn),bpos=0;
    int n=0;
    while(buff[bpos]>='0'){
        n=(n<<1)+(n<<3)+(buff[bpos++]^48);
        if(bpos==buffsize) fread(buff,1,buffsize,fn),bpos=0;
    }
    ++bpos;
    return n;
}
int main()
{
    fn=fopen("huffman.in","r");
    int n=read();
    int queue1l=0,queue1r=0,queue2l,queue2r;
    while(queue1r<n){
        Size[queue1r++]=read();
    }
    queue2l=queue2r=queue1r;
    long long total_len=0;
    for(int iter=0;iter<n-1;++iter){
        int min1,min2;

        if(queue2l!=queue2r && (queue1l==queue1r || Size[queue2l]<=Size[queue1l]))
            min1=queue2l++;
        else min1=queue1l++;

        if(queue2l!=queue2r && (queue1l==queue1r || Size[queue2l]<=Size[queue1l]))
            min2=queue2l++;
        else min2=queue1l++;

        code[min2]=1;
        total_len+=(Size[queue2r]=Size[min1]+Size[min2]);
        p[min1]=p[min2]=queue2r++;
    }
    len[queue2l]=0;
    for(int i=queue2l-1;i>=0;--i){
        len[i]=len[p[i]]+1;
        code[i]|=(code[p[i]]<<1);
    }
    fn=fopen("huffman.out","w");
    fprintf(fn,"%lld\n",total_len);
    for(int i=0;i<n;i++)
        fprintf(fn,"%d %lld\n",len[i],code[i]);
    return 0;
}

