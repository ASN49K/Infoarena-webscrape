#include<fstream>
using namespace std;
#define NMAX 1000005
ifstream fin("huffman.in");
ofstream fout("huffman.out");
struct nod
{
    long long cod;
    int lung;
    int f[2];
} V[NMAX<<2];
int n,k,p,u,A[NMAX],B[NMAX];
long long lg;
void bfs(int x, long long cod, int lung)
{
    if (!x) return ;
    V[x].cod=cod, V[x].lung=lung;
    bfs(V[x].f[0],cod*2,lung+1);
    bfs(V[x].f[1],cod*2+1,lung+1);
}
int main()
{
    int i;
    fin>>n;
    for (i=1;i<=n;++i)
        fin>>A[i];
    k=1, p=1, u=0;
    while (k<=n)
    {
        if (p<=u)
        {
            if (k<n)
            {
                if (B[p]>=A[k+1])
                {
                    B[++u]=A[k]+A[k+1];
                    V[u+n].f[0]=k, V[u+n].f[1]=k+1;
                    ++++k;
                }
                else
                {
                    if (p<u && B[p+1]<A[k])
                    {
                        B[++u]=B[p]+B[p+1];
                        V[u+n].f[0]=p+n, V[u+n].f[1]=p+n+1;
                        ++++p;
                    }
                    else
                    {
                        B[++u]=A[k]+B[p];
                        V[u+n].f[0]=k, V[u+n].f[1]=p+n;
                        ++k, ++p;
                    }
                }
            }
            else
            {
                if (p<u && B[p+1]<A[k])
                {
                    B[++u]=B[p]+B[p+1];
                    V[u+n].f[0]=p+n, V[u+n].f[1]=p+n+1;
                    ++++p;
                }
                else
                {
                    B[++u]=A[k]+B[p];
                    V[u+n].f[0]=k, V[u+n].f[1]=p+n;
                    ++k, ++p;
                }
            }
        }
        else
        {
            B[++u]=A[k]+A[k+1];
            V[u+n].f[0]=k, V[u+n].f[1]=k+1;
            ++++k;
        }
        lg+=B[u];
    }
    while (p<u)
    {
        B[++u]=B[p]+B[p+1];
        V[u+n].f[0]=p+n, V[u+n].f[1]=p+n+1;
        ++++p;
        lg+=B[u];
    }
    bfs(2*n-1,0,0);
    fout<<lg<<"\n";
    for (i=1;i<=n;++i)
        fout<<V[i].lung<<" "<<V[i].cod<<"\n";
    return 0;
}
