#include <stdio.h>
#include <stdlib.h>

#define BIAS  5
#define TRUE  1
#define FALSE 0

#define MAX_LENGTH 1000005

typedef char               byte;
typedef unsigned long long LLU;

typedef struct 
{
    int  parent;
    byte isLeft;
} Node;

typedef struct
{
    int   indexInTree;
    LLU   occurences;
} QueueNode;

Node       tree[MAX_LENGTH];

QueueNode  pureQueue[2 * MAX_LENGTH];
int leftPureQueue = 0;
int rightPureQueue = 0;

QueueNode mergedQueue[2 * MAX_LENGTH];
int leftMergedQueue = 0;
int rightMergedQueue = 0;

void AddElementToQueue(QueueNode* queue, int* right, QueueNode element)
{
    queue[(*right)++] = element;
}

QueueNode PopQueue(QueueNode* queue, int* left)
{
    return queue[(*left)++];
}

byte IsQueueEmpty(int* left, int* right)
{
    if(*left == *right)
        return TRUE;
    return FALSE;
}

LLU Huffman(Node* tree, 
            QueueNode* pureQueue,
            QueueNode* mergedQueue,
            int* leftPureQueue,
            int* rightPureQueue,
            int* leftMergedQueue,
            int* rightMergedQueue,
            int n)
{
    LLU result = 0;
    int i;
    int indexToAdd = n;
    byte stop = FALSE;

    while(!stop)
    {
        if(IsQueueEmpty(leftPureQueue, rightPureQueue) && !IsQueueEmpty(leftMergedQueue, rightMergedQueue))
        {
            if(*leftMergedQueue == (*rightMergedQueue) - 1)
            {
                stop = TRUE;
                continue;
            }
        }

        QueueNode* chosenQueueNodes[] = {NULL, NULL, NULL, NULL};
        
        if(*leftPureQueue < (*rightPureQueue))
            chosenQueueNodes[0] = &pureQueue[*leftPureQueue];
        if(*leftPureQueue < (*rightPureQueue) - 1)
            chosenQueueNodes[1] = &pureQueue[*leftPureQueue + 1];

        if(*leftMergedQueue < (*rightMergedQueue))
            chosenQueueNodes[2] = &mergedQueue[*leftMergedQueue];
        if(*leftMergedQueue < (*rightMergedQueue) - 1)
            chosenQueueNodes[3] = &mergedQueue[*leftMergedQueue + 1];
        
        int smallestIndex = -1;
        int secondSmallest = -1;

        for(i = 0; i < 4; i++)
        {
            if(chosenQueueNodes[i] != NULL)
            {
                byte isSmallest = FALSE;

                if(smallestIndex == -1)
                {
                    isSmallest = TRUE;
                }
                else
                {
                    if(chosenQueueNodes[smallestIndex]->occurences > chosenQueueNodes[i]->occurences)
                    {
                        isSmallest = TRUE;
                    }
                }

                if(isSmallest)
                {
                    smallestIndex = i;
                }
            }
        }

        for(int i = 0; i < 4; i++)
        {
            if(i != smallestIndex)
            {
                if(chosenQueueNodes[i] != NULL)
                {
                    byte isSmallest = FALSE;
                    if(secondSmallest == -1)
                    {
                        isSmallest = TRUE;
                    }
                    else
                    {
                        if(chosenQueueNodes[secondSmallest]->occurences > chosenQueueNodes[i]->occurences)
                        {
                            isSmallest = TRUE;
                        }
                    }
                    
                    if(isSmallest)
                    {
                        secondSmallest = i;
                    }
                }
            }
        }

        if(secondSmallest != -1 && smallestIndex != -1 && secondSmallest != smallestIndex)
        {
            QueueNode* child1 = chosenQueueNodes[smallestIndex];
            QueueNode* child2 = chosenQueueNodes[secondSmallest];

            tree[child1->indexInTree].parent = indexToAdd;
            tree[child1->indexInTree].isLeft = TRUE;

            tree[child2->indexInTree].parent = indexToAdd;
            tree[child2->indexInTree].isLeft = FALSE;

            tree[indexToAdd].parent = indexToAdd;
            
            QueueNode queueNode;
            queueNode.indexInTree = indexToAdd;
            queueNode.occurences = child1->occurences + child2->occurences;

            result += queueNode.occurences;

            AddElementToQueue(mergedQueue, rightMergedQueue, queueNode);

            indexToAdd++;

            if(smallestIndex <= 1)
                PopQueue(pureQueue, leftPureQueue);
            else
                PopQueue(mergedQueue, leftMergedQueue);
            
            if(secondSmallest <= 1)
                PopQueue(pureQueue, leftPureQueue);
            else
                PopQueue(mergedQueue, leftMergedQueue);
        }
    }

    return result;
}

void ShowCharacter(FILE* fout, Node* tree, int indexInTree, int level, LLU number)
{
    if(tree[indexInTree].parent == indexInTree)
    {
        fprintf(fout, "%d %llu\n", level, number);
    }
    else
    {
        ShowCharacter(fout, tree, tree[indexInTree].parent, level + 1, number + ((LLU)tree[indexInTree].isLeft << (LLU)level));
    }
    
}

int main(void)
{
    int        i;
    int        n;

    FILE* fin = fopen("huffman.in", "r");
    FILE* fout = fopen("huffman.out", "w");

    printf("ALOCARE\n");

    fscanf(fin, "%d", &n);

    for(i = 0; i < n; i++)
    {
        tree[i].parent = i;
        tree[i].isLeft = FALSE;

        QueueNode queueNode;
        queueNode.indexInTree = i;
        fscanf(fin, "%llu", &queueNode.occurences);

        AddElementToQueue(pureQueue, &rightPureQueue, queueNode);
    }

    printf("AICI DUREAZA CEL MAI MULT?\n");

    fprintf(fout, "%llu\n", Huffman(tree, pureQueue, mergedQueue, &leftPureQueue, &rightPureQueue, &leftMergedQueue, &rightMergedQueue, n));

    printf("APROAPE\n");

    for(int i = 0; i < n; i++)
    {
        ShowCharacter(fout, tree, i, 0, 0LL);
    }

    printf("GATA\n");

    fclose(fin);
    fclose(fout);

    return 0;
}