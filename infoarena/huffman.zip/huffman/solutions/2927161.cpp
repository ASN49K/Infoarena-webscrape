#include <fstream>
#include <queue>
#include <vector>
#define nmax 1000005

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

struct nod
{
    int sum, fiu1, fiu2;
};

long long rasp;

int v[nmax];
int mini[3];
int ans[nmax];
long long anslength[nmax];

nod varb[3*nmax];
queue<int> q;

int n, length, ind;

nod aux;

void f(int poz, int cod, int lcod)
{
    if(varb[poz].fiu1 == 0)
    {
       anslength[poz] = lcod;
       ans[poz] = cod;
       return;
    }
    f(varb[poz].fiu1, cod*2, lcod+1);
    f(varb[poz].fiu2, cod*2+1, lcod+1);
}

int main()
{
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>v[i];
        varb[i].sum = v[i];
        varb[i].fiu1 = 0;
        varb[i].fiu2 = 0;
        length ++;
    }
    ind = 1;
    while(q.size()>1 || ind<=n)
    {
       for(int i=0; i<2; i++)
       {
           if(ind <= n && ((int)q.empty() == 1 || varb[ind].sum <= varb[(int)q.front()].sum))
           {
               mini[i] = ind;
               ind++;
               continue;
           }
           if((int)q.empty() == 0 && (ind > n || varb[ind].sum >= varb[(int)q.front()].sum))
           {
               mini[i] = (int)q.front();
               q.pop();
           }
       }
       varb[length+1].sum = varb[mini[0]].sum + varb[mini[1]].sum;
       varb[length+1].fiu1 = mini[0];
       varb[length+1].fiu2 = mini[1];
       q.push(length+1);
       length++;
    }
    /*for(int i=1; i<=2*n; i++)
    {
        out<<varb[i].sum<<" ";
    }*/
    f(length,0,0);
    for(int i=1; i<=n; i++)
    {
        rasp+= v[i]*anslength[i];
    }
    out<<rasp<<"\n";
    for(int i=1; i<=n; i++)
    {
        out<<anslength[i]<<" "<<ans[i]<<"\n";
    }
    return 0;
}
