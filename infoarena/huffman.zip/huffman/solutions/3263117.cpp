#include <fstream>
#include <deque>
#define dim 1000000
using namespace std;
ifstream fin ("huffman.in");
ofstream fout ("huffman.out");
struct element
{
    long long val;
    int nod;
};
int n,k,v[dim+1],lg[dim+1],nod[2*dim+1][2];
long long sol,val[dim+1];
struct op
{
    deque <element> d1,d2;
    int nr ()
    {
        return d1.size ()+d2.size ();
    }
    void init ()
    {
        for (int i=1; i<=n; i++)
            d1.push_back ({v[i],i});
    }
    void add (element x)
    {
        d2.push_back (x);
    }
    element get ()
    {
        if (!d1.empty ()&&!d2.empty ())
        {
            if (d1.front ().val<d2.front ().val)
            {
                element val=d1.front ();
                d1.pop_front ();
                return val;
            }
            else
            {
                element val=d2.front ();
                d2.pop_front ();
                return val;
            }
        }
        else if (!d1.empty ())
        {
            element val=d1.front ();
            d1.pop_front ();
            return val;
        }
        else
        {
            element val=d2.front ();
            d2.pop_front ();
            return val;
        }
    }
};
op str;
void dfs (int pos,int nrc,long long nrs)
{
    if (nod[pos][0]!=-1)
    {
        dfs (nod[pos][0],nrc+1,(nrs<<1));
        dfs (nod[pos][1],nrc+1,(nrs<<1)+1);
    }
    else
    {
        lg[pos]=nrc;
        val[pos]=nrs;
    }
}
int main()
{
    fin>>n;
    for (int i=1; i<=n; i++)
    {
        fin>>v[i];
        nod[i][0]=nod[i][1]=-1;
    }
    k=n;
    if (n==1)
    {
        fout<<v[1]<<"\n1 0";
        return 0;
    }
    str.init ();
    while (str.nr ()>1)
    {
        element a=str.get ();
        element b=str.get ();
        sol+=a.val+b.val;
        k++;
        nod[k][0]=a.nod;
        nod[k][1]=b.nod;
        str.add ({a.val+b.val,k});
    }
    fout<<sol<<"\n";
    dfs (k,0,0);
    for (int i=1; i<=n; i++)
        fout<<lg[i]<<" "<<val[i]<<"\n";
    return 0;
}
