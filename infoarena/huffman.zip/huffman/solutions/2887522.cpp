#include <iostream>
#include <fstream>
#include <deque>
using namespace std;

ifstream  in("huffman.in");
ofstream  out("huffman.out");

const int NMAX=1e6+5;

deque<int>q1,q2;


struct nod{
    int f[2];
    long long val;
}graf[2*NMAX];


int n;
long long lc[NMAX],b10[NMAX];

void dfs(int node,long long cod, int nivel){
    b10[node]=cod;
    lc[node]=nivel;
    if(graf[node].f[0]){
        dfs(graf[node].f[0],cod<<1,nivel+1);
        dfs(graf[node].f[1],cod<<1|1,nivel+1);
    }
}
int main() {
    in>>n;
    for(int i=1;i<=n;i++){
        in>>graf[i].val;
        q1.push_back(i);
    }
    int k=n;
    long long sol=0;
    while(q1.size() +q2.size()>=2){
        k++;
        for(int i=0;i<2;i++){
            long long min=1e18+2,ales;
            if(q2.empty() ||  (!q1.empty() && graf[q1.front()].val<graf[q2.front()].val)){
                ales=q1.front();
                min=graf[ales].val;
                q1.pop_front();
            }
            else{
                ales=q2.front();
                min=graf[ales].val;
                q2.pop_front();
            }
            graf[k].val+=graf[ales].val;
            graf[k].f[i]=ales;

        }
        sol+=graf[k].val;
        q2.push_back(k);
    }
    dfs(k,0,0);
    out<<sol<<"\n";
    for(int i=1;i<=n;i++){
        out<<lc[i]<<" "<<b10[i]<<"\n";
    }
    return 0;
}