#include <bits/stdc++.h>
#define Nmax 1000100
#define LL long long
#define INF 1LL * 1000000000 * 1000000000
FILE *fin = freopen("huffman.in", "r", stdin);
FILE *fout = freopen("huffman.out", "w", stdout);

using namespace std;
int n, l[2], r[2], q[2][Nmax], lg[Nmax], k;
LL sol, b[2 * Nmax];
struct vertex
{
    LL v;
    long f[2];
}node[Nmax];
void read()
{
    scanf("%d", &n);
    for(int i = 1; i <= n; ++ i)
    {
        scanf("%lld", &node[i].v);
        q[0][i] = i;
    }
}
void Code(long pos, LL code, long lvl)
{
    if(node[pos].f[0])
    {
        Code(node[pos].f[0], 2 * code, lvl + 1);
        Code(node[pos].f[1], 2 * code + 1, lvl + 1);
        return;
    }
    lg[pos] = lvl;
    b[pos] = code;
}
void solve()
{
    int p;
    k = n;
    LL m;
    l[0] = l[1] = 1;
    r[0] = n;
    while(l[0] + l[1] <= r[0] + r[1])
    {
        ++ k;
        for(int j = 0; j < 2; ++ j)
        {
            p = 0;
            m = INF;
            for(int i = 0; i < 2; ++ i)
            {
                if(node[q[i][l[i]]].v < m && l[i] <= r[i])
                {
                    p = i;
                    m = node[q[i][l[i]]].v;
                }
            }
            node[k].f[j] = q[p][l[p]];
            node[k].v += node[q[p][l[p]]].v;
            ++ l[p];
        }
        sol += node[k].v;
        q[1][++ r[1]] = k;
    }
    Code(k, 0, 0);
}
void write()
{
    printf("%lld\n", sol);
    for(int i = 1; i <= n; ++ i)
        printf("%d %lld\n", lg[i], b[i]);
}
int main()
{
    read();
    solve();
    write();
    return 0;
}
