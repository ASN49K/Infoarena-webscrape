#include <fstream>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
const int nmax=1000001;
int k;
long long sol,tot;
struct nod
{
    long long z;
    int st,dr,lvl;
    char s[50];
}arb[3*nmax];
queue<int> Q,H;
int unite(int a,int b)
{
    arb[k].z=arb[a].z+arb[b].z;
    sol+=arb[k].z;
    arb[k].st=a;
    arb[k].dr=b;
    return k;
}
void dfs(int nod,int niv)
{
    if(arb[nod].st!=0)
    {
        memcpy(arb[arb[nod].st].s,arb[nod].s,sizeof(arb[nod].s));
        arb[arb[nod].st].s[niv]=0;
        dfs(arb[nod].st,niv+1);
    }
     if(arb[nod].dr!=0)
    {
        memcpy(arb[arb[nod].dr].s,arb[nod].s,sizeof(arb[nod].s));
        arb[arb[nod].dr].s[niv]=1;
        dfs(arb[nod].dr,niv+1);
    }
    if(arb[nod].st==arb[nod].dr&&arb[nod].st==0) arb[nod].lvl=niv;
}
int main()
{
    int n,i,a,b,step1,step2;
    int j;
    fin>>n;
    k=n+1;
    for(i=1;i<=n;++i)
    {
        fin>>j;
        arb[i].z=j;
        Q.push(i);
    }
    sol=0;
    while(1)
    {
        step1=0;step2=0;
        if(Q.size()) step1=Q.front();
        if(H.size()) step2=H.front();
        if(step1==0)  {a=step2;H.pop();}
        else if(step2==0) {a=step1;Q.pop();}
        else if(arb[step1].z<=arb[step2].z) {a=step1;Q.pop();}
        else {a=step2;H.pop();}
        step1=0;step2=0;
        if(Q.size()) step1=Q.front();
        if(H.size()) step2=H.front();
        if(step1==0)  {b=step2;H.pop();}
        else if(step2==0) {b=step1;Q.pop();}
        else if(arb[step1].z<=arb[step2].z) {b=step1;Q.pop();}
        else {b=step2;H.pop();}
        H.push(unite(a,b));k++;
        if(Q.size()+H.size()<=1) break;
    }
    fout<<sol<<"\n";
    dfs(H.front(),0);
    for(i=1;i<=n;i++)
    {
        sol=0;tot=1;
        for(j=arb[i].lvl-1;j>=0;j--)
        {
            if(arb[i].s[j]==1) sol+=tot;
            tot*=2;
        }
        fout<<arb[i].lvl<<" "<<sol<<"\n";
    }
}
