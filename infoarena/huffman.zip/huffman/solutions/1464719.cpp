#include<fstream>
using namespace std;
#define NMAX 1000005
ifstream fin("huffman.in");
ofstream fout("huffman.out");
struct nod
{
    long long cod;
    int lung;
    int f[2];
} V[NMAX<<1];
int k,p,u;
long long A[NMAX<<1];
long long n,lg;
char BUFF[NMAX<<4],*q=BUFF;
void read(long long &nr)
{
    nr=0;
    while ('0'<=*q && *q<='9')
        nr=nr*10+*q-'0', ++q;
    while (!('0'<=*q && *q<='9'))
        ++q;
}
void bfs(int x, long long cod, int lung)
{
    V[x].cod=cod, V[x].lung=lung;
    if (V[x].f[0])
    {
        bfs(V[x].f[0],cod<<1,lung+1);
        bfs(V[x].f[1],(cod<<1)+1,lung+1);
    }
}
int main()
{
    int i;
    fin.get(BUFF,NMAX<<4,0);
    read(n);
    for (i=1;i<=n;++i)
        read(A[i]);
    k=1, p=n+1, u=n;
    while (k<=n)
    {
        if (p<=u)
        {
            if (k<n)
            {
                if (A[p]>=A[k+1])
                {
                    A[++u]=A[k]+A[k+1];
                    V[u].f[0]=k, V[u].f[1]=k+1;
                    ++++k;
                }
                else
                {
                    if (p<u && A[p+1]<=A[k])
                    {
                        A[++u]=A[p]+A[p+1];
                        V[u].f[0]=p, V[u].f[1]=p+1;
                        ++++p;
                    }
                    else
                    {
                        A[++u]=A[k]+A[p];
                        V[u].f[0]=k, V[u].f[1]=p;
                        ++k, ++p;
                    }
                }
            }
            else
            {
                if (p<u && A[p+1]<=A[k])
                {
                    A[++u]=A[p]+A[p+1];
                    V[u].f[0]=p, V[u].f[1]=p+1;
                    ++++p;
                }
                else
                {
                    A[++u]=A[k]+A[p];
                    V[u].f[0]=k, V[u].f[1]=p;
                    ++k, ++p;
                }
            }
        }
        else
        {
            A[++u]=A[k]+A[k+1];
            V[u].f[0]=k, V[u].f[1]=k+1;
            ++++k;
        }
        lg+=A[u];
    }
    while (p<u)
    {
        A[++u]=A[p]+A[p+1];
        V[u].f[0]=p, V[u].f[1]=p+1;
        ++++p;
        lg+=A[u];
    }
    bfs(2*n-1,0,0);
    fout<<lg<<"\n";
    for (i=1;i<=n;++i)
        fout<<V[i].lung<<" "<<V[i].cod<<"\n";
    return 0;
}
