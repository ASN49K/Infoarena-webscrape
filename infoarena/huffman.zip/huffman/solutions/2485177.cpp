#include<fstream>
#include<queue>
using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");
queue<int> Q,q;
struct huff{long long cod;long long w;int nr;int st;int dr;} v[2000001];
int n,i,x,a,b,k;
long long sol;
int next_el()
{
    int a=-1,b=-1,ca=0,cb=0;
    if(!Q.empty()) b=Q.front();
    if(!q.empty()) a=q.front();
    if(a==-1) cb=1;
    else if(b==-1) ca=1;
    else if(v[a].w>v[b].w) cb=1; else ca=1;
    if(ca==1)
    {
        q.pop();
        return a;
    }
    Q.pop();
    return b;
}
void solve(int nod,int nivel)
{
    v[nod].nr=nivel;
    long long aux=v[nod].cod;
    if(v[nod].st!=0)
    {
        sol+=v[nod].w;
        v[v[nod].st].cod=aux*2,v[v[nod].dr].cod=aux*2+1;
        solve(v[nod].st,nivel+1);
        solve(v[nod].dr,nivel+1);
    }
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>x;
        v[i].w=x;
        q.push(i);
    }
    for(k=n+1;;k++)
    {
        a=next_el();b=next_el();
        Q.push(k);
        v[k].w=v[a].w+v[b].w;
        v[k].st=a;v[k].dr=b;
        if(q.empty()&&Q.size()==1) break;
    }
    solve(k,0);
    fout<<sol<<"\n";
    for(i=1;i<=k;i++) fout<<v[i].nr<<" "<<v[i].cod<<"\n";
    return 0;
}

