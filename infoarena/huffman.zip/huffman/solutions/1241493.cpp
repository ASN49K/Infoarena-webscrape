#include <cstdio>
#define tip long long
#define N 2000010
using namespace std;
tip n,i,val[N],tata[N],top1,top2,front1,front2,poz1,poz2,sol,lg,bit,vl;
void run(tip nod)
{
    if(!nod)return;
    lg++;
    vl=((tata[nod]&1)<<bit)+vl;
    bit++;
    run(tata[nod]>>1);
}
inline tip select()
{
    if(top1<front1)
    {
        top1=top2;
        front1=front2;
        front2=top1+1;
    }
    if(top2<front2)
        return front1++;
    return val[front1]<=val[front2]?front1++:front2++;
}
int main()
{
    freopen("huffman.in","r",stdin);
    freopen("huffman.out","w",stdout);
    scanf("%lld",&n);
    for(i=1;i<=n;i++)
        scanf("%d",&val[i]);
    top1=top2=n;
    front1=1;
    front2=top2+1;
    for(i=n+1;i<2*n;i++)
    {
        poz1=select();
        poz2=select();
        tata[poz1]=(++top2)<<1;
        tata[poz2]=(top2<<1)+1;
        val[top2]=val[poz1]+val[poz2];
        sol+=val[top2];
    }
    printf("%lld\n",sol);
    for(i=1;i<=n;i++)
    {
        vl=bit=0;
        lg=-1;
        run(i);
        printf("%lld %lld\n",lg,vl);
    }
    return 0;
}
