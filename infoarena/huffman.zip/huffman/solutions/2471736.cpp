#include <iostream>
#include <queue>
#include <map>
#include <cstring>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

struct nod
{
    int frecventa;
    int index;
    nod *left,*right;
    nod()
    {
        left = NULL;
        right = NULL;
    }
}*HuffRoot;

struct cmp
{
    bool operator()(nod* l,nod* r)
    {
        if ((*l).frecventa == (*r).frecventa)
        {
            return (*l).index < (*r).index;
        }
        return ((*l).frecventa > (*r).frecventa);
    }
};


int n;
map <int,int> frec;
map <int ,string> HUFFMAN;
long long int s;
priority_queue <nod* ,vector<nod*> , cmp> pq;

nod* CreateNod(int val,int frec,nod*st,nod*dr)
{
    nod* n = new nod();
    n->index = val;
    n->frecventa = frec;
    n->left = st;
    n->right = dr;
    return n;
}

long long int sum = 0;
void codare(nod *start,string s)
{
    if (start == NULL)
    {
        return ;
    }
    if (start->left == NULL && start->right == NULL)
    {
        sum += frec[start->index] * s.size();
        HUFFMAN[start->index] = s;
    }
    codare(start->left,s + "0");
    codare(start->right,s + "1");
}

int bin_to_dec(string s)
{
    int nr = 0;
    for (int i=0; i<s.size(); i++)
    {
        if (s[i] == '1')
        {
            nr += 1<<i;
        }
    }
    return nr;
}

int main()
{
    in >> n;
    for (int i=1; i<=n; i++)
    {
        in >> frec[i];
    }
    for (int i=1; i<=n; i++)
    {
        pq.push(CreateNod(i,frec[i],NULL,NULL));
    }
    while (pq.size() != 1)
    {
        nod *st = pq.top();
        pq.pop();
        nod *dr = pq.top();
        pq.pop();
        s = st->frecventa + dr->frecventa;
        pq.push(CreateNod(0,s,st,dr));
    }
    nod* start = pq.top();
    codare(start,"");
    out << sum << "\n";
    for (int i=1; i<=n; i++)
    {
        out << HUFFMAN[i].size() << " " << bin_to_dec(HUFFMAN[i]) << "\n";
    }
    return 0;
}
