#include <fstream>
#define upi {k++;v[k]=v[i]+v[i+1];s[0][k]=i;s[1][k]=i+1;i+=2;sol1+=v[k];}
#define upj {k++;v[k]=v[j]+v[j+1];s[0][k]=j;s[1][k]=j+1;j+=2;sol1+=v[k];}
#define upd {k++;v[k]=v[i]+v[j];s[0][k]=i;s[1][k]=j;i++;j++;sol1+=v[k];}
#define N 2000010
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

int s[2][N],n,i,j,k,sol1;
long long v[N],cod[N],doila[30];
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i];
    k=n;i=1;upi;j=n+1;
    for(;k<=2*n-1;)
    {
        if(i<n)
        {
            if(j<k)
            {
                if(v[i]+v[i+1]<=v[i]+v[j]&&v[i]+v[i+1]<=v[j]+v[j+1])upi else
                if(v[j]+v[j+1]<=v[i]+v[j]&&v[j]+v[j+1]<=v[i]+v[i+1])upj else
                upd
            }
            else
            if(j==k)
            {
                if(v[i]+v[i+1]<=v[i]+v[j])upi else
                upd
            }
            else
            upi
        }
        else
        if(i==n)
        {
            if(j<k)
            {
                if(v[j]+v[j+1]<=v[i]+v[j])upj else
                upd
            }
            else
            upd
        }
        else
            upj
    }
    g<<sol1<<'\n';
    v[2*n-1]=0;
    for(i=2*n-1;i>n;i--)
    {
        v[s[0][i]]=v[i]+1;
        cod[s[0][i]]=2*cod[i];
        v[s[1][i]]=v[i]+1;
        cod[s[1][i]]=2*cod[i]+1;
    }
    for(i=1;i<=n;i++)
        g<<v[i]<<' '<<cod[i]<<'\n';

    return 0;
}
