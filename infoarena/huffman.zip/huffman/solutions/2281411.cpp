#include <fstream>
#include <queue>

using namespace std;

ifstream in("huffman.in");
ofstream out("huffman.out");

int n, nrNod;
bool ok = 1;

int fiust[2000001], fiudr[2000001];
long long aparitii[2000001];
long long ans[1000001], sum;
int len[1000001], x1, x2;

void dfs(int nod, long long val, int l)
{
    if(nod <= n)
    {
        len[nod] = l;
        ans[nod] = val;
        return;
    }
    dfs(fiust[nod], (val << 1), l+1);
    dfs(fiudr[nod], (val << 1) + 1, l+1);
}

class Compare
{
public:
    bool operator() (int l, int r)
    {
        return aparitii[l] > aparitii[r];
    }
};

priority_queue <int, vector<int>, Compare> pq;

int main()
{
    in >> n;
    nrNod = n;
    for(int i = 1; i <= n; i++)
    {
        in >> aparitii[i];
        pq.push(i);
    }
    while(ok)
    {
        x1 = pq.top();
        pq.pop();
        if(pq.empty())
            ok = 0;
        else
        {
            x2 = pq.top();
            pq.pop();
            nrNod++;
            fiust[nrNod] = x1;
            fiudr[nrNod] = x2;
            aparitii[nrNod] = aparitii[x1]+aparitii[x2];
            pq.push(nrNod);
        }
    }
    dfs(nrNod, 0, 0);
    for(int i = 1; i <= n; i++)
        sum += aparitii[i] * len[i];
    out << sum << '\n';
    for(int i = 1; i <= n; i++)
        out << len[i] << ' ' << ans[i] << '\n';
    return 0;
}
