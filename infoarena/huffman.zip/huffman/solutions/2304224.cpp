#include <fstream>
#include <queue>

using namespace std;

#define MAXN 1000100

typedef pair<long long, int> tp;

struct nod {
  long long v;
  int fs, fd;
} nod[2*MAXN];

int n, i, k, a[MAXN];
long long b[MAXN], lt;
int l[MAXN];
pair<long long, int> p;
priority_queue<tp> q;

void build_tree() {
  k = n;
  while (q.size() >= 2) {
    ++k;
    p = q.top(); nod[k].fs = p.second; nod[k].v += (-p.first);
    q.pop();
    p = q.top(); nod[k].fd = p.second; nod[k].v += (-p.first);
    q.pop();
    lt += nod[k].v;
    q.push(make_pair(-nod[k].v, k));
  }
}

void walk_tree (int poz, long long cod, int nivel) {
  if(nod[poz].fs) {
    walk_tree(nod[poz].fs, cod * 2, nivel + 1);
    walk_tree(nod[poz].fd, cod * 2 + 1, nivel + 1);
  }
  else {
    l[poz] = nivel; b[poz] = cod;
  }
}

int main() {
  ifstream fi("huffman.in");
  ofstream fo("huffman.out");
  fi >> n;
  for(i = 1; i <= n; i++) {
    fi >> nod[i].v;
    q.push(make_pair(-(nod[i].v), i));
  }
  build_tree();
  walk_tree(k, 0, 0);
  fo << lt << '\n';
  for(i = 1; i <= n; i++)
    fo << l[i] << ' ' << b[i] << '\n';
  return 0;
}
