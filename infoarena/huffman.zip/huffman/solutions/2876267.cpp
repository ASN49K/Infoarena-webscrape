#include <fstream>
#include <queue>
#include <vector>
#define INF 1000000000000000001
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");
struct nod
{
    long long val;
    int ind;
    int fiu[2];
}a[2000010];
long long sol,va[1000011];
int lv[1000011];
void huff(int t,int lvl,long long cod)
{
    if(a[t].ind!=0)
    {
        lv[a[t].ind]=lvl;
        va[a[t].ind]=cod;
        return;
    }
    sol=sol+a[t].val;
    huff(a[t].fiu[0],lvl+1,cod*2);
    huff(a[t].fiu[1],lvl+1,cod*2+1);
}
queue <int> q0,q1;
int n,i,p,k,z;
long long x,m;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>x;
        a[i]={x,i,-1,-1};
        q0.push(i);
    }
    k=n;
    while(q1.size()>1 || q0.size()>1)
    {
        k++;
        a[k]={0,0,-1,-1};
        for(i=0;i<2;i++)
        {
            m=INF;
            p=1;
            if(q0.empty()==false && a[q0.front()].val<m)
            {
                m=a[q0.front()].val;
                p=0;
            }
            if(q1.empty()==false && a[q1.front()].val<m)
            {
                m=a[q1.front()].val;
                p=1;
            }
            if(p==0)
            {
                z=q0.front();
                q0.pop();
            }
            else
            {
                z=q1.front();
                q1.pop();
            }
            a[k].val=a[k].val+a[z].val;
            a[k].fiu[i]=z;
        }
        q1.push(k);
    }
    z=q1.front();
    q1.pop();
    huff(z,0,0);
    g<<sol<<'\n';
    for(i=1;i<=n;i++)
        g<<lv[i]<<" "<<va[i]<<'\n';
    return 0;
}
