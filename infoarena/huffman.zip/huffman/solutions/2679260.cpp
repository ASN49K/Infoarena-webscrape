#include <fstream>
#include <queue>
#include <vector>
#include <utility>
#include <stack>


using namespace std;
ifstream fin("huffman.in");
ofstream fout("huffman.out");

const int NMAX =  1000003;

struct Node{
    int st_index, dr_index;
    long long val;
};
queue<int>q1;
queue<int>q2;
Node nodes[3 * NMAX];
//vector<Node>nodes;


pair<int, int> take_nodes()
{
   int n1, n2;
   int t =2;
   vector<int>b;
   while(t--){

    if(!q1.empty() && !q2.empty())
    {
        int indx1 = q1.front();
        int indx2 = q2.front();
       if(nodes[indx1].val >= nodes[indx2].val)
       {
         // n1 = nodes[indx2];
          q2.pop();
          b.push_back(indx2);
       }
       else{
         // n1 = nodes[indx1];
          q1.pop();
          b.push_back(indx1);
       }
       continue;
    }
    if(q1.empty())
    {
       // n1 = nodes[q2.front()];
        n1 = q2.front();
        q2.pop();
        b.push_back(n1);
        continue;
    }
    if(q2.empty())
    {
        //n1 = nodes[q1.front()];
        n1 = q1.front();
        q1.pop();
        b.push_back(n1);
        continue;
    }

   }
   n1 = b[0];
   n2 = b[1];
   return make_pair(n1, n2);

}

long long sols =0;
int  huffman(int k)
{
  while(q1.size() + q2.size()!= 1)
  {
     // Node n1;
     // Node n2;
      int n1, n2;
      pair <int, int> pi = take_nodes();
      n1 = pi.first;
      n2 = pi.second;
      Node n3;
      n3.dr_index = n1;
      n3.st_index = n2;
     // n3.index = k;

      n3.val = nodes[n1].val + nodes[n2].val;
      sols = sols + n3.val;
      //nodes.push_back(n3);
      nodes[k] = n3;
      q2.push(k);
      k++;

  }
  return k;
}


vector<pair<int, long long> >sol;

void dfs(int index, long long depth, int x, int k)
{
   if(index < k)
   {
      sol[index].first = depth;
      sol[index].second = x;
      return;
   }
   else{

     dfs(nodes[index].st_index, depth + 1, ((x<<1)|0), k);
     dfs(nodes[index].dr_index, depth + 1, ((x<<1)|1), k);
   }
}

int main()
{
    int n, i, k, x;
    Node aux;
    aux.dr_index = -1;
    aux.st_index = -1;
    fin>>n;
    k = 0;
    for(i=0;i<n;i++)
    {
        fin>>x;
        //aux.index = k;
        k++;
        aux.val = x;
        //nodes.push_back(aux);
        nodes[i] = aux;
        q1.push(i);
        sol.push_back(make_pair(0, 0));
    }
    int ck = k;
    k = huffman(k);
    long long sum = 0;
    //for(i = ck; i < k; i++)
      //  sum = sum + nodes[i].val;

    dfs(k-1, 0, 0, ck);
    fout<<sols<<"\n";
    for(i =0; i < sol.size(); i++)
    {
       fout<<sol[i].first <<" "<<sol[i].second<<"\n";
    }


    return 0;
}
