#include <iostream>
#include <stdio.h>
#include <queue>

using namespace std;

const int NMAX = 1000005;
const int NRMAX = 2000010;
long long val[NRMAX], rez[NRMAX];
int st[NRMAX], dr[NRMAX], rezh[NRMAX];
int nr;
queue <int> q1;
queue <int> q2;

int minim() {
    int m;
    if (q1.empty()) {
        m = q2.front();
        q2.pop();
        return m;
    }
    if (q2.empty()) {
        m = q1.front();
        q1.pop();
        return m;
    }
    if (val[q1.front()] <= val[q2.front()]) {
        m = q1.front();
        q1.pop();
        return m;
    }
    m = q2.front();
    q2.pop();
    return m;
}

void adauga(int x, int y) {
    val[++nr] = val[x] + val[y];
    st[nr] = x;
    dr[nr] = y;
    q2.push(nr);
}

long long sum(int nod) {
    if (st[nod] + dr[nod] == 0)
        return 0;
    /*long long x = val[nod];
    if (st[nod] == 0)
        return x + sum(dr[nod]);
    if (dr[nod] == 0)
        return x + sum(st[nod]);*/
    return val[nod] + sum(st[nod]) + sum(dr[nod]);
}

void config(int nod, long long val, int h) {
    if (st[nod] + dr[nod] == 0) {
        rezh[nod] = h;
        rez[nod] = val;
    }
    else {
        /*long long val2;
        if (st[nod]) {
            val2 = val * 2;
            config(st[nod], val2, h + 1);
        }
        if (dr[nod]) {
            val2 = val * 2 + 1;
            config(dr[nod], val2, h + 1);
        }*/
        config(st[nod], val * 2, h + 1);
        config(dr[nod], val * 2 + 1, h + 1);
    }
}

int main() {

    freopen ("huffman.in", "r", stdin);
    freopen ("huffman.out", "w", stdout);

    int n, i, x, y;

    scanf ("%d", &n);
    for (i = 1; i <= n; i++) {
        scanf ("%d", &nr);
        val[i] = nr;
        q1.push(i);
    }

    nr = n;
    while (q1.size() + q2.size() > 1) {
        x = minim();
        y = minim();
        adauga(x, y);
    }

    printf ("%lld\n", sum(nr));

    config(nr, 0, 0);

    for (i = 1; i <= n; i++)
        printf ("%d %lld\n", rezh[i], rez[i]);


    return 0;
}
