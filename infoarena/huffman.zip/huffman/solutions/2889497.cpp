#include <bits/stdc++.h>

using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

int n, nr, m[2000005][2], lg[1000005];
long long v[2000005], s, rezultat[1000005];
queue<int> it, itn;

long long gmin()
{
    int rt=0;
    if(!it.empty() and (itn.empty() or v[it.front()]<=v[itn.front()]))
    {
        rt=it.front();
        it.pop();
        return rt;
    }
    rt=itn.front();
    itn.pop();
    return rt;
}

void dfs(int in_nod, long long cod, int l )
{
    if(in_nod<=n)
    {
        rezultat[in_nod]=cod;
        lg[in_nod]=l;
        return;
    }
    dfs(m[in_nod][0],cod<<1,l+1);
    dfs(m[in_nod][1],(cod<<1)|1,l+1);
}

int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>v[i];
        it.push(i);
    }
    nr=n;
    while((int)it.size()+(int)itn.size()>1)
    {
        long long a, b;
        a=gmin();
        b=gmin();
        int c;
        nr++;
        c=nr;
        v[c]=v[a]+v[b];
        itn.push(c);
        m[nr][0]=a;
        m[nr][1]=b;
        s=s+v[c];
    }
    dfs(nr, 0, 0);
    g<<s<<"\n";
    for(int i=1; i<=n; i++)
    {
        g<<lg[i]<<" "<<rezultat[i]<<"\n";
    }
    return 0;
}






