

#include <bits/stdc++.h>
using namespace std;
ifstream f("huffman.in");
ofstream g("huffman.out");

struct vct
{
    long long val;
    int l,r,lv;
}v[2000005];

void afis(int n)
{
    int i;
    for(i=1;i<=n;i++)
        g<<v[i].lv<<' '<<v[i].val<<'\n';
}
void create_codes(int root, long long cod, int lv)
{
    if(root!=0)
    {
        v[root].val=cod;
        v[root].lv=lv;
        cod=cod<<1;
        lv++;
        create_codes(v[root].r,cod+1,lv);
        create_codes(v[root].l,cod,lv);
    }
}
void huffman(int n)
{
    int i=1,j=n+2,t=n+2;
    long long sum=0;
    int nr1,nr2;
    v[n+1].val=LLONG_MAX;

    while(i<n || j<t-1)
    {
        if(j<t && v[j].val<v[i].val)
            nr1=j++;
        else
            nr1=i++;
        if(j<t && v[j].val<v[i].val)
            nr2=j++;
        else
            nr2=i++;

        v[t].val=v[nr1].val+v[nr2].val;
        sum+=v[t].val;
        v[t].l=nr1;
        v[t++].r=nr2;
    }
    create_codes(t-1,0,0);
    g<<sum<<'\n';
    afis(n);
}

int main()
{
    int n,i;
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i].val;

    huffman(n);

    return 0;
}