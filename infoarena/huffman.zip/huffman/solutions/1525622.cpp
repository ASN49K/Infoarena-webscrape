#include <fstream>
#define N 2000010

using namespace std;

ifstream f("huffman.in");
ofstream g("huffman.out");

int n,i,b1,b2,e1,e2,lg[N],s[N],d[N],c[N];
long long v[N],t;

int main()
{
    f>>n;
    for(i=0;i<n;i++)
        f>>v[i];
    b1=0;
    b2=n;
    e1=n;
    e2=n;
    while(e2<2*n-1)
    {
        if((b1==e1)||(e2-b2>1&&e1>b1&&v[b2+1]<=v[b1]))
        {
            v[e2]=v[b2]+v[b2+1];
            s[e2]=b2;
            d[e2]=b2+1;
            e2++;
            b2+=2;
            continue;
        }
        if((b2==e2)||(e1-b1>1&&e2>b2&&v[b1+1]<=v[b2]))
        {
            v[e2]=v[b1]+v[b1+1];
            s[e2]=b1;
            d[e2]=b1+1;
            e2++;
            b1+=2;
            continue;
        }
        v[e2]=v[b1]+v[b2];
        s[e2]=b1;
        d[e2]=b2;
        e2++; b1++; b2++;
    }
    for(i=e2-1;i>=n;i--)
    {
        c[s[i]]=c[i]<<1;
        c[d[i]]=(c[i]<<1)|1;
        lg[s[i]]=lg[d[i]]=lg[i]+1;
        t+=v[i];
    }
    g<<t<<'\n';
    for(i=0;i<n;i++)
        g<<lg[i]<<' '<<c[i]<<'\n';
    return 0;
}
