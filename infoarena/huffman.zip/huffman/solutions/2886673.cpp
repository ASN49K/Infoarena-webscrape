#include <bits/stdc++.h>

using namespace std;

typedef long long int lli;

const int MAXN = 1e6;

struct Node{
	lli v;
	int f[2];

	Node(lli v = 0) {
		this->v = v;
		f[0] = -1;
		f[1] = -1;
	}
};


int n, k;
Node nodes[2 * MAXN];
queue<pair<lli, int> > q;
lli sol;
lli lg[MAXN + 2];
int cnt[MAXN + 2];

void dfs(int k, lli code, int lvl) {
	if (k < n) {
	lg[k] = code;
	cnt[k] = lvl;
	}

	for (int i = 0; i < 2; ++ i) {
		if (nodes[k].f[i] != -1)
			dfs(nodes[k].f[i], code * 2 + i, lvl + 1);
	}
}


int main() {
	freopen("huffman.in", "r", stdin);
	freopen("huffman.out", "w", stdout);

	cin >> n;

	for (int i = 0; i < n; ++ i) {
		int v;
		cin >> nodes[i].v;
	}

	int le = 0, ri = n;
	int k = n;
	while (le < ri || q.size() > 1) {
		pair<lli, int> minn[2];

		for (int i = 0; i < 2; ++ i) {
			if (le >= ri) {
				minn[i] = q.front();
				q.pop();
			} else if (q.empty()) {
				minn[i] = {nodes[le].v, le ++};
			} else {
				minn[i] = nodes[le].v <= q.front().first ? make_pair(nodes[le].v, le) : q.front();
				if (nodes[le].v <= q.front().first)
					++ le;
				else
					q.pop();
			}
		}

		nodes[k ++].v = minn[0].first + minn[1].first;
		q.push({minn[0].first + minn[1].first, k - 1});

		sol += nodes[k - 1].v;

		for (int i = 0; i < 2; ++ i)
			nodes[k - 1].f[i] = minn[i].second;
	}

	dfs(k - 1, 0, 0);

	cout << sol << '\n';

	for (int i = 0; i < n; ++ i)
		cout << cnt[i] << ' ' << lg[i] << '\n';
	cout << '\n';

	return 0;
}