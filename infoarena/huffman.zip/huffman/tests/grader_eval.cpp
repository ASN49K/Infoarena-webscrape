//Evaluator huffman

#include <stdio.h>
#include <stdlib.h>
#include <set>

#define FIN "huffman.in"
#define FOUT "huffman.out"
#define FOK "huffman.ok"

#define maxn 1000100

using namespace std;

struct trie
{
    long f[3];
} t[60*maxn];

long n, i, j, k, nr, v[maxn], lg[maxn];
long long sol, sok, sob, b[maxn], dim;

void result(char msg[], int p)
{
    fprintf(stderr, msg);
    printf("%d", p);
    exit(0);
}

void insereaza(long long val, long long dim, long nod)
{
    long poz=!(!(val & dim));
    if(dim==0) return;
    if(!t[nod].f[poz])
    {
        nr++;
        t[nod].f[poz]=nr;
    }
    insereaza(val, dim/2, t[nod].f[poz]);
}

void cauta(long long val, long long dim, long nod)
{
    long poz=!(!(val & dim));
    if(dim==0)
    {
        result("Un cod este prefix al altuia!", 0);
        return;
    }
    if(!t[nod].f[poz])
        return;
    cauta(val, dim/2, t[nod].f[poz]);
}

int main()
{
    FILE *f;
    f=fopen(FIN, "r");
    if (!f)
        result("Fisier de intrare lipsa!", 0);
    if (fscanf(f, "%d", &n) != 1)
        result("Fisier de intrare corupt!", 0);
    if(n<1 || n>1000000)
        result("Fisier de intrare corupt!", 0);
    for (i = 1; i <= n; i++)
    {
        if (fscanf(f, "%d", &v[i]) != 1)
            result("Fisier de intrare corupt!", 0);
        if (v[i] < 0 || v[i] > 100000000)
            result("Fisier de intrare corupt!", 0);
    }

    f = fopen(FOK, "r");
    if (!f) result("Fisier ok lipsa!", 0);
    if (fscanf(f, "%lld", &sok) != 1)
        result("Fisier ok corupt!", 0);

    f = fopen(FOUT, "r");
    if (!f) result("Fisier de iesire lipsa!", 0);
    if (fscanf(f, "%lld", &sol) != 1)
        result("Fisier de iesire corupt!", 0);
    if(sol!=sok)
        result("Lungime incorecta!", 0);
    nr=1;
    for(i=1; i<=n; i++)
    {
        if (fscanf(f, "%d %lld", &lg[i], &b[i]) != 2)
            result("Fisier de iesire corupt!", 0);
        if (lg[i] > 64)
            result("Lungimea codului incorecta!", 0);
        sob+=1LL*v[i]*lg[i];
        dim=1;
        for(j=1; j<=lg[i]; j++)
            dim*=2;
        b[i]+=dim;
        cauta(b[i], dim, 1);
        insereaza(b[i], dim, 1);
    }
    if(sob!=sok)
        result("Suma lungimilor codurilor incorecta!", 0);
    result("OK!", 5);
    return 0;
}



