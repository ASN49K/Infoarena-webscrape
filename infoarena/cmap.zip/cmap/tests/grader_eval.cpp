#include <stdio.h>
#include <stdlib.h>
#define eps 0.000001

void result(const char *msg, int p) {
    fprintf(stderr, "%s", msg);
    printf("%d", p);
    exit(0);
}

bool equal(double x, double y) { return abs(x - y) <= eps; }

int main() {
    FILE *f;

    double x, y;

    f = fopen("cmap.ok", "r");
    if (!f) result("Fisier ok lipsa!", 0);
    if (fscanf(f, "%lf", &x) != 1) result("Fisier ok corupt!", 0);
    fclose(f);

    f = fopen("cmap.out", "r");
    if (!f) result("Fisier de iesire lipsa!", 0);
    if (fscanf(f, "%lf", &y) != 1) result("Fisier de iesire corupt!", 0);
    fclose(f);

    if (equal(x, y) == 1)
        result("Ok", 5);
    else
        result("Incorect", 0);
    return 0;
}
