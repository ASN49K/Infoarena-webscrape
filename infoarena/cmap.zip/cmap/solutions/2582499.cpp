#include <bits/stdc++.h>
#define MAX 100000 + 5
#define INF 2e9

using namespace std;

struct Point
{
    int x;
    int y;

    bool operator=(const Point &other)
    {
        x = other.x;
        y = other.y;
    }
};

Point xVector[MAX + 5], yVector[MAX + 5];

bool xCmp(Point a, Point b)
{
    return (a.x < b.x);
}

bool yCmp(Point a, Point b)
{
    return (a.y < b.y);
}

inline int dist(const Point &a, const Point &b)
{
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

void mergeVectorY(int st, int mij, int dr)
{
    int i = st;
    int j = mij + 1;
    int k = st;

    while(i <= mij && j <= dr)
    {
        if(yVector[i].x == yVector[j].x)
        {
            if(yVector[i].y <= yVector[j].y)
            {
                yVector[k].y = yVector[i].y;
                i++;
            }
            else
            {
                yVector[k].y = yVector[j].y;
                j++;
            }
        }
        else
        {
            yVector[k].y = yVector[i].y;
            i++;
        }

        k++;
    }

    while(i <= mij)
    {
        yVector[k].y = yVector[i].y;
        k++;
        i++;
    }

    while(j <= dr)
    {
        yVector[k].y = yVector[j].y;
        k++;
        j++;
    }
}

int solve(int st, int dr)
{
    if(st >= dr)return INF;
    if(dr == st + 1)
    {
        if(yVector[st].x == yVector[dr].x && yVector[st].y > yVector[dr].y)
            swap(yVector[st], yVector[dr]);

        return dist(xVector[st], xVector[dr]);
    }

    int mij = (st + dr) >> 1;
    int best = min(solve(st, mij), solve(mij + 1, dr));

    mergeVectorY(st, mij, dr);

    vector<Point>rectangle;

    for(int i = st; i <= dr; i++)
        if(abs(yVector[i].x - xVector[mij].x) < best)rectangle.push_back(yVector[i]);

    for(int i = 0; i < rectangle.size() - 1; i++)
        for(int j = i + 1; j < rectangle.size() && j - i < 8; j++)
            best = min(best, dist(rectangle[i], rectangle[j]));

    return best;
}

int main()
{
    ifstream fin("cmap.in");
    ofstream fout("cmap.out");

    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    srand(time(NULL));

    int n;

    fin >> n;

    for(int i = 1; i <= n; i++)
        fin >> xVector[i].x >> xVector[i].y;

    sort(xVector + 1, xVector + 1 + n, xCmp);

    for(int i = 1; i <= n; i++)
        yVector[i] = xVector[i];

    fout << setprecision(8) << sqrt(solve(1, n));

    fin.close();
    fout.close();

    return 0;
}
