#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct
{
    int id;
    float x,y;
} punct;
float dmin;
int id_p1,id_p2;
void citire(int *n,punct **p)
{
    FILE *f=fopen("puncte.txt","r");
    fscanf(f,"%d",n);
    *p=(punct*)malloc((*n)*sizeof(punct));
    for(int i=0; i<*n; i++)
    {
        fscanf(f,"%f%f",&(*p)[i].x,&(*p)[i].y);
        (*p)[i].id=i+1;
    }
    fclose(f);
}
int cmp(const void *a, const void *b)
{
    punct pa = *(punct*)a;
    punct pb = *(punct*)b;
    if(pa.x < pb.x) return -1;
    if(pa.x > pb.x) return  1;
    return 0;
}
float dist(punct a,punct b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
void div_et_imp(punct *p,int st,int dr)
{
    if(st<dr)
    {
        if(dr-st==1) //problema direct rezolvabila: o multime cu doar 2 puncte
        {
            float d=dist(p[st],p[dr]);
            if(dmin>d)
            {
                dmin=d;
                id_p1=p[st].id;
                id_p2=p[dr].id;
            }
        }
        else
        {
            int mij=(st+dr)/2;
            div_et_imp(p,st,mij);
            div_et_imp(p,mij+1,dr);
        }
    }


}
int main()
{
    punct *p;
    int n;
    citire(&n,&p);
    qsort(p, n, sizeof(punct), cmp); //sortam datele in functie de abscisa
    dmin=dist(p[0],p[1]); //initializam minimul cu distanta dintre primele 2 puncte
    id_p1=p[0].id;//initializam cu primele 2 puncte pentru a rezolva direct si cazul in care n=2
    id_p2=p[1].id;
    div_et_imp(p,0,n-1);
    printf("Distanta minima se afla intre punctele P%d si P%d si este egala cu %.2f",id_p1,id_p2,dmin);
    return 0;
}
/*
Exemple:
Ex1:
10
26 77
12 37
14 18
19 96
71 95
91 9
98 43
66 77
2 75
94 91

Distanta minima se afla intre punctele P8 si P5 si este egala cu 18.68

Ex2:
5
15.5 20
12 13
-3 5
-2 0
17 21.5

Distanta minima se afla intre punctele P1 si P5 si este egala cu 2.12

Ex3:
6
0.2 0.7
0.5 3
11 20
5.6 -8
11 -2
100 20
Distanta minima se afla intre punctele P1 si P2 si este egala cu 2.32

Ex4:
n=2 caz particular
2
1 2
2 3

Distanta minima se afla intre punctele P1 si P2 si este egala cu 1.41
*/
