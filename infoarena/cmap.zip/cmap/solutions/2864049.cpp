#include <bits/stdc++.h>
#define mp make_pair
#define pb push_back
#define pf push_front
#define ll long long
#define ull unsigned long long
#define pii pair<int,int>
#define pll pair<ll,ll>
#define EPSILON 0.000001

using namespace std;

const ll NMAX = 1e5+5, INF = 1e18, MOD = 1e9 + 7, MMAX = 1e2 + 5, inf = INT_MAX;


ifstream f("cmap.in");
ofstream g("cmap.out");

struct punct
{
    int x,y;
};

punct P[NMAX], Tmp[NMAX];
int N;

bool compx(const punct &A, const punct &B)
{
    return A.x<B.x;
}

bool compy(const punct &A,const punct &B)
{
    return A.y<B.y;
}

inline long long sqr(long long v)
{
    return v*v;
}

long long dist2(const punct &A, const punct &B)
{
    return sqr(A.x-B.x)+sqr(A.y-B.y);
}

long long distMin(int p,int u)
{
    long long dmin=INF;
    for(int i=p; i<u; i++)
    {
        for(int j=i+1; j<u; j++)
        {
            dmin=min(dmin,dist2(P[i],P[j]));
        }
    }
    return dmin;
}

long long calcDmin(int p,int u)
{
    if(u-p<3)
        return distMin(p,u);
    int m=(p+u)/2;
    long long d=min(calcDmin(p,m),calcDmin(m,u));
    int k=0;
    for(int i=p; i<=u; i++)
    {
        if(sqr(P[i].x-P[m].x)<d)
            Tmp[++k]=P[i];
    }
    sort(Tmp+1,Tmp+k+1,compy);
    for(int i=1; i<k; i++)
    {
        for(int j=i+1; j<=k&&sqr(Tmp[j].y-Tmp[i].y)<d; j++)
        {
            d=min(d,dist2(Tmp[i],Tmp[j]));
        }
    }
    return d;
}

int main()
{
    cin.tie ( 0 )->sync_with_stdio ( 0 );
    cin.tie ( NULL );
    cout.tie ( NULL );

    f>>N;
    for(int i=1; i<=N; i++)
    {
        f>>P[i].x>>P[i].y;
    }
    sort(P+1,P+N+1,compx);
    g<<fixed<<setprecision(6)<<sqrt(calcDmin(1,N));
    f.close();
    g.close();

    return 0;
}
