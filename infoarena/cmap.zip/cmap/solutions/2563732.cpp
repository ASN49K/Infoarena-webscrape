#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream fin("cmap.in");
ofstream fout("cmap.out");

struct Punct
{
    int x, y;
};

int n;
Punct A[100001];
double dmin = 100000000000000000000000.0d;

double Dist(Punct p1, Punct p2)
{
    long long dx = p1.x - p2.x, dy = p1.y - p2.y;
    long long d2 = dx * dx + dy * dy;
    return sqrt((double)d2);
}

int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
        fin >> A[i].x >> A[i].y;
    for (int i = 2; i <= n; ++i)
    {
        for (int j = 1; j < i; ++j)
            dmin = min(dmin, Dist(A[i], A[j]));
    }
    fout << fixed << setprecision(7) << dmin;

    return 0;
}
