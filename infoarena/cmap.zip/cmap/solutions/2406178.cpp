#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;
ifstream f("cmap.in");
ofstream g("cmap.out");
//--------------------------------
//Variabile globale
int n;
pair<long long,long long>v[100001];
//--------------------------------
//Functii
void citire();
void rezolvare();
//--------------------------------
int main()
{
	citire();
	rezolvare();
	return 0;
}
//--------------------------------
void rezolvare()
{
    long long mi = 1e18;
    long long dist,dist2;
	sort(v + 1,v + n + 1);
	for(int i = 1; i <= n; ++i)
		for(int j = i + 1; j <= n,j <= i + 8; ++j)
		{
		    dist = v[i].x - v[j].x;
            dist2 = v[i].y - v[j].y;
            if(dist2 * dist2 + dist * dist < mi)
                mi = dist2 * dist2 + dist * dist;
		}
    g << fixed << setprecision(7) << sqrt(mi);
}
//--------------------------------
void citire()
{
	f >> n;
	for(int i = 1; i <= n; ++i)
		f >> v[i].x >> v[i].y;
}
