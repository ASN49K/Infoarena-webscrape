#include <fstream>
// #include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <cmath>
#include <iomanip>
#define ll long long
using namespace std;

ifstream cin("cmap.in");
ofstream cout("cmap.out");

const int NMAX = 1e5;
const ll INF = LLONG_MAX;

struct Point
{
    int x, y;
    void Read()
    {
        cin >> x >> y;
    }
};

int n;
Point pointsX[NMAX + 1], pointsY[NMAX + 1];
Point pointsInterclasated[NMAX + 1];

bool cmpX(Point p1, Point p2)
{
    if(p1.x == p2.x)
        return p1.y < p2.y;
    return p1.x < p2.x;
}

bool cmpY(Point p1, Point p2)
{
    return p1.y > p2.y;
}

ll Square(int x)
{
    return (ll)x * x;
}

ll Distance(Point p1, Point p2)
{
    return Square(p1.x - p2.x) + Square(p1.y - p2.y);
}

ll FindMinDistance(int left, int right)
{
    if(left >= right)
        return INF;

    int mid = (left + right) / 2;
    ll dLeft = FindMinDistance(left, mid);
    ll dRight = FindMinDistance(mid + 1, right);
    ll d = min(dLeft, dRight);

    // Interclasare
    int i = left, j = mid + 1, ind = 0;
    while(i <= mid && j <= right)
    {
        if(pointsY[i].y > pointsY[j].y)
            pointsInterclasated[++ind] = pointsY[i++];
        else
            pointsInterclasated[++ind] = pointsY[j++];
    }

    while(i <= mid)
        pointsInterclasated[++ind] = pointsY[i++];
    while(j <= right)
        pointsInterclasated[++ind] = pointsY[j++];

    for(int i = left; i <= right; i++)
        pointsY[i] = pointsInterclasated[i - left + 1];

    ll dd = ceil(sqrt(d));
    vector<Point> strip;
    for(int i = left; i <= right; i++)
        if(abs(pointsX[mid].x - pointsY[i].x) < dd)
            strip.push_back(pointsY[i]);

    for(int i = 0; i < (int) strip.size(); i++)
        for(int j = i + 1; j < (int) strip.size() && j - i + 1 <= 8; j++)
            d = min(d, Distance(strip[i], strip[j]));
    
    return d;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n;
    for(int i = 1; i <= n; i++)
        pointsX[i].Read();

    sort(pointsX + 1, pointsX + n + 1, cmpX);
    for(int i = 1; i <= n; i++)
        pointsY[i] = pointsX[i];

    cout << fixed << setprecision(6) << sqrt(FindMinDistance(1, n));

    return 0;
}