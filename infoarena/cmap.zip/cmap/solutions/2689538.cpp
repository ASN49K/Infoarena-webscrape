#include <bits/stdc++.h>
using namespace std;

ifstream f("cmap.in");
ofstream g("cmap.out");

int n;
pair < int , int > v[100005];
double dmin=2000000007;

int main()
{
    f >> n;
    for (int i=1;i<=n;i++) {
        f >> v[i].first >> v[i].second;
    }
    for (int i=1;i<n;i++) {
        for (int j=i+1;j<=n;j++) {
            dmin = min(dmin,sqrt( (v[j].first-v[i].first)*(v[j].first-v[i].first) + (v[j].second-v[i].second)*(v[j].second-v[i].second) ) );
        }
    }
    g <<setprecision(9) <<  dmin;
    return 0;
}
