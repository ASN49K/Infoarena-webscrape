#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define all(a) (a).begin(), (a).end()
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define sz() size()
#define fr first
#define sc second
#define pb push_back
#define er erase
#define in insert
#define pi pair<int,int>
#define pii pair<pair<int,int>,int>
#define mp make_pair
#define int long long
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
using namespace std;

const int mod=1e9+7;
const int modu=1999999973;
const int modul=998244353;

const int nmax=1000005;

int n;
long double ans=1e18;
pair<int,int>a[100005];

long double dist(int x,int y,int z,int t){
    long double g = sqrt((ld)((x-z)*(x-z)+(y-t)*(y-t)));
    return g;
}

int32_t main(){
    ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
    srand(chrono::steady_clock::now().time_since_epoch().count());
    ifstream cin("cmap.in");
    ofstream cout("cmap.out");
    cout << fixed << setprecision(12);
    cin >> n;
    for(int i=1;i<=n;i++) cin >> a[i].fr >> a[i].sc;
    sort(a+1,a+n+1);
    set<pair<int,int>>q;
    int indx=1;
    for(int i=1;i<=n;i++){
            while(q.size()>=1 && (ld)(a[i].fr-a[indx].fr)>=ans){
                q.erase(q.find({a[indx].sc,a[indx].fr}));
                indx++;
            }
            auto it1=q.lower_bound({(ld)(a[i].sc-ans),(ld)(a[i].fr)});
            auto it2=q.upper_bound({(ld)(a[i].sc+ans),(ld)(a[i].fr)});
            auto it=it1;
            while(it!=it2){
                if(it==q.end()) break;
                int x=it->first;
                int y=it->second;
                ans=min(ans,dist(x,y,a[i].fr,a[i].sc));
                it++;
            }
            q.insert({a[i].sc,a[i].fr});
    }
    cout << ans << '\n';
}
