#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long double ld;
const int N = (int) 1e5 + 7;
int n;

struct point {
  ld x, y;
} p[N];

bool cmp(point a, point b) {
  return a.x < b.x;
}

ld dist(point a, point b) {
  ld dx = a.x - b.x, dy = a.y - b.y;
  return dx * dx + dy * dy;
}

int main() {
  freopen ("cmap.in", "r", stdin);
  freopen ("cmap.out", "w", stdout);

  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    int a, b;
    scanf("%d %d", &a, &b);
    p[i] = {a, b};
  }
  sort(p + 1, p + n + 1, cmp);
  ld cur = (ld) 1e18 + 7;
  for (int i = 2; i <= n; i++) {
    for (int j = i - 1; j >= 1; j--) {
      if ((p[i].x - p[j].x) * (p[i].x - p[j].x) > cur) {
        break;
      }
      cur = min(cur, dist(p[i], p[j]));
    }
  }
  cout << fixed << setprecision(6) << sqrt(cur) << "\n";
}
