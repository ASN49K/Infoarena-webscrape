#include<bits/stdc++.h>

using namespace std;


ifstream in("cmap.in");
ofstream out("cmap.out");


long long calc_dist(pair<int,int> a,pair<int,int> b){
    return 1LL*(a.first-b.first)*(a.first-b.first)+1LL*(a.second-b.second)*(a.second-b.second);
}

int main()
{
    long long dmin,dcurr;
    int n,a,b;
    in>>n;
    pair<int,int>p[n+1];
    for(int i=0;i<n;i++){
        in>>a>>b;
        p[i]={a,b};
    }

    dmin=calc_dist(p[0],p[1]);

    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++){
         dcurr=calc_dist(p[i],p[j]);
            if(dcurr<dmin)
                dmin=dcurr;
        }
    out<<sqrt(dmin);
}

