#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include<bits/stdc++.h>
using namespace std;
ifstream f("cmap.in");
ofstream g("cmap.out");
#define MAX_SIZE 100001
int n, i, j, pos;
long long dpos;
long long dist, dmin;
struct Punct {
    int x, y;
} punct[MAX_SIZE], fpunct[MAX_SIZE], w[MAX_SIZE];

long long Dist(int i, int j) {
    return (punct[i].x-punct[j].x)*(punct[i].x-punct[j].x) + (punct[i].y-punct[j].y)*(punct[i].y-punct[j].y);
}

long long fDist(int i, int j) {
    return (fpunct[i].x-fpunct[j].x)*(fpunct[i].x-fpunct[j].x) + (fpunct[i].y-fpunct[j].y)*(fpunct[i].y-fpunct[j].y);
}

long long Recursivitate(int in, int sf) {
    int dif = sf-in+1;
    int sum = sf+in;
    if(dif > 255) {
        dmin = min(Recursivitate(in, sum/2), Recursivitate(sum/2+1, sf));
        if(dif%2 == 1)
            dpos = double(punct[in+dif/2+1].x);
        else dpos = double(punct[in+dif/2].x + punct[in+dif+1].x)/2;

        pos = 0;
        for(i = in; i <= sf; i++) {
            if(abs(punct[i].x - dpos) < dmin) {
                fpunct[++pos] = punct[i];
            }
        }
        for(i = 1; i < pos; i++) {
            for(j = i+1; j <= pos; j++) {
                if(fpunct[i].y > fpunct[j].y) {
                    swap(fpunct[i], fpunct[j]);
                }
            }
        }

        for(i = 1; i < pos; i++) {
            for(j = i+1; j <= i+7 && j <= pos; j++) {
                dmin = min(dmin, fDist(i, j));
            }
        }
    }
    else {
        dmin = LONG_LONG_MAX;
        for(i = in; i < sf; i++)
            for(j = i+1; j <= sf; j++)
                dmin = min(dmin, Dist(i, j));
    }
    return dmin;
}

int main()
{
    dmin = LONG_LONG_MAX;
    f >> n;
    for(i = 1; i <= n; i++)
        f >> punct[i].x >> punct[i].y;

    for(i = 1; i < n; i++) {
        for(j = i+1; j <= n; j++) {
            if(punct[i].x > punct[j].x) {
                swap(punct[i], punct[j]);
            }
        }
    }

    g << fixed << setprecision(6) << double(sqrt(Recursivitate(1, n)));
    return 0;
}
