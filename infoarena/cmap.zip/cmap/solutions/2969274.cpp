#include <algorithm>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <set>

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 262144) {
			sp = 0;
			fread(buff, 1, 262144, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[262144]();
		sp = 262143;
	}

	void close() {
		fclose(fin);
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

InParser cin( "cmap.in" );
ofstream cout( "cmap.out" );

#define x first
#define y second
inline bool cmpByY( pair<int, int> A, pair<int, int> B) { return A.y == B.y ? A.x < B.x : A.y < B.y; }
set<pair<int, int>, decltype(cmpByY)*> s(cmpByY);

long long dis( pair<int, int> A, pair<int, int> B ) {
	return ( (long long)A.x - B.x ) * ( A.x - B.x ) + ( (long long)A.y - B.y ) * ( A.y - B.y );
}

const int32_t MAX = 1e5 + 1;
pair<int, int> v[ MAX ];
int32_t n;

signed main()
{
	ios_base::sync_with_stdio(false);

	cin >> n;
	for( int32_t i = 0; i < n; i++ )
		cin >> v[ i ].x >> v[ i ].y;

	sort( v, v + n, []( pair<int, int> A, pair<int, int> B ) {
			return A.x == B.x ? A.y < B.y : A.x < B.x;
		} );

	int32_t poz = 0;
	long long pp;
	long long dMin = dis( v[ 0 ], v[ 1 ] );
	for( int32_t i = 0; i < n; i++ ) {
		int DD = sqrt( dMin );
		while( v[ i ].x - v[ poz ].x > DD )
			s.erase( v[ poz++ ] );

		for( auto it = s.lower_bound( { -2e9, v[ i ].y - DD } ); it != s.end() && (*it).y <= v[ i ].y + DD; it++ ) {
			if( ( pp = dis( v[ i ], (*it) ) ) < dMin )
				dMin = pp;
		}
		s.insert( v[ i ] );
	}

	cout << fixed << setprecision( 6 ) << (long double)sqrt( dMin ) << '\n';
    return 0;
}
