#include <algorithm>
#include <climits>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <ios>
#include <iostream>
#include <istream>
#include <ostream>

struct koord{
	int x, y;
	koord(int a, int b){
		x = a;
		y = b;
	}
	koord(){
		x = 0;
		y = 0;
	}
	long long tavolsag ( koord masik ) {
		long long tav = ( masik.x - x ) * ( masik.x - x ) + ( masik.y - y ) * ( masik.y - y );
		return tav;
	}
};
std::istream & operator>>(std::istream & bem, koord & bemenet){
	bem >> bemenet.x >> bemenet.y;
	return bem;
}
std::ostream & operator<<(std::ostream & kim, koord & kimenet){
	kim << kimenet.x << ' ' << kimenet.y;
	return kim;
}

void merge(koord tomb[], int bal, int kozep, int jobb){
	int *temp = new int[jobb - bal + 1];
	int indexTemp = 0, indexBal = bal, indexJobb = kozep + 1;
	while (indexBal <= kozep && indexJobb <= jobb) {
		if(tomb[indexBal].y <= tomb[indexJobb].y)
			temp[indexTemp++] = tomb[indexBal++].y;
		else
		 temp[indexTemp++] = tomb[indexJobb++].y;
	}
	while (indexBal <= kozep)
		temp[indexTemp++] = tomb[indexBal++].y;
	while (indexJobb <= jobb)
		temp[indexTemp++] = tomb[indexJobb++].y;
	for (int i = 0; i < indexTemp; i++)
		tomb[bal + i].y = temp[i];
	delete [] temp;
	return;
}

void sort(koord tomb[], int bal, int jobb){
	if(bal >= jobb)
		return;
	int kozep = (bal + jobb) / 2;
	sort(tomb, bal, kozep);
	sort(tomb, kozep + 1, jobb);
	merge(tomb, bal, kozep, jobb);
}

int main(){
	std::ifstream bem("cmap.in");
	int n;
	long long minTav = LONG_MAX;
	bem >> n;
	koord * tomb = new koord[n];
	for(int i = 0; i < n; i++)
		bem >> tomb[i];
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			if(i != j){
				long long tav = tomb[i].tavolsag(tomb[j]);
				if(tav < minTav)
					minTav = tav;
			}
		}
	}
	//sort(tomb, 0, n - 1);

	/*for(int i = 0; i < n; i++)
		std::cout << tomb[i] << '\n';*/
	std::ofstream kim("cmap.out");
	kim << std::fixed << std::setprecision(6) << sqrt(minTav) << '\n';

	kim.close();
	delete [] tomb;
}
