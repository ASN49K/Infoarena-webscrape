#include <fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int x[20],n,i,p;
int valid(int k)
{
    int i;
    for(i=1;i<k;i++)
        if(x[i]>=x[k])
        return 0;
    return 1;
}
int main()
{
    cin>>n>>p;
    for(i=1;i<=n;i++)
        x[i]=0;i=1;
    do
    {
        do
        {
            x[i]++;
            if(x[i]>n)
            {
                x[i]=0;
                i--;
            }
            else
                if(valid(i))
                i++;
        }
        while(i<=p&&i>0);
        if(i>p)
        {
            for(i=1;i<=p;i++)
                cout<<x[i]<<" ";
            i=p;
            cout<<"\n";
        }
    }
    while(i>0);
}
