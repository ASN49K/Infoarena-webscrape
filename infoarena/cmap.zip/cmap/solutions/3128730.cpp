#include <bits/stdc++.h>
#define NMAX 100005
#define INF 4e18

#define pii pair <int, int>
#define x first
#define y second
#define ull unsigned long long

using namespace std;

pii v[NMAX];
pii aux[NMAX];
int n;

inline bool cmp(pii p1, pii p2) {
    return p1.y < p2.y;
}

inline ull sqr(ull x) {
    return x * x;
}

inline ull distx(pii p1, pii p2) {
    return ((ull)p1.x - (ull)p2.x) * ((ull)p1.x - (ull)p2.x);
}

inline ull disty(pii p1, pii p2) {
    return ((ull)p1.y - (ull)p2.y) * ((ull)p1.y - (ull)p2.y);
}

inline ull dist(pii p1, pii p2) {
    return distx(p1, p2) + disty(p1, p2);
}

ull minimum_distance(int left, int right) {

    if (left >= right)
        return INF;

    if (right - left == 1) {
        if (!cmp(v[left], v[right]))
            swap(v[left], v[right]);
        return dist(v[left], v[right]);
    }

    int mid = (right + left) >> 1;
    pii mid_point = v[mid];
    ull d1 = minimum_distance(left, mid);
    ull d2 = minimum_distance(mid + 1, right);
    ull d = min(d1, d2);

    for (int i = left, j = mid + 1, k = left; i <= mid || j <= right;)
        if (j > right || (i <= mid && cmp(v[i], v[j])))
            aux[k++] = v[i++];
        else
            aux[k++] = v[j++];

    vector <pii> points;
    for (int i = left; i <= right; ++i) {
        v[i] = aux[i];
        if (distx(v[i], mid_point) < d)
            points.push_back(v[i]);
    }

    for (int i = 0; i < (int)points.size() - 1; ++i)
        for (int j = i + 1; j < (int)points.size() && disty(points[i], points[j]) < d; ++j)
            d = min(d, dist(points[i], points[j]));

    return d;
}

void solve() {

    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> v[i].x >> v[i].y;

    sort(v + 1, v + n + 1);
    cout << setprecision(8) << fixed << sqrt(minimum_distance(1, n)) << '\n';
}

int main()
{
    freopen("cmap.in", "r", stdin);
    freopen("cmap.out", "w", stdout);

    int t = 1;
    // cin >> t;
    while (t--)
        solve();
    return 0;
}
