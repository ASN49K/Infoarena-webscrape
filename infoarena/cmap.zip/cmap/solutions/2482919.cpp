#include <bits/stdc++.h>
using namespace std;

using i64 = long long;

struct Point {
    int x, y;
};

istream& operator>>(istream& is, Point& pt) {
    return is >> pt.x >> pt.y;
}

ostream& operator<<(ostream& os, const Point& pt) {
    return os << "(" << pt.x << ", " << pt.y << ")";
}

const i64 INF = 1ll << 63;

i64 distance_square(Point a, Point b) {
    i64 dx = i64(a.x) - i64(b.x),
        dy = i64(a.y) - i64(b.y);

    return dx * dx + dy * dy;
}

i64 min_distance(size_t num_pts, const Point* xs, const Point* ys) {
    if (num_pts <= 1) {
        return INF;
    }
    if (num_pts == 2) {
        return distance_square(xs[0], xs[1]);
    }
    if (num_pts == 3) {
        i64 a = distance_square(xs[0], xs[1]),
            b = distance_square(xs[0], xs[2]),
            c = distance_square(xs[1], xs[2]);
        return min(a, min(b, c));
    }

    int mid = num_pts / 2;
    int mid_x = xs[mid].x;

    const Point* left_xs = xs;
    const Point* right_xs = xs + mid;
    vector<Point> left_ys, right_ys;
    left_ys.reserve(mid);
    right_ys.reserve(mid);

    for (size_t i = 0; i < num_pts; ++i) {
        if (ys[i].x < mid_x) {
            left_ys.push_back(ys[i]);
        } else {
            right_ys.push_back(ys[i]);
        }
    }

    i64 min_left = min_distance(mid, left_xs, left_ys.data()),
        min_right = min_distance(mid, right_xs, right_ys.data());

    i64 d = min(min_left, min_right);

    vector<Point> closer;
    closer.reserve(num_pts);
    for (size_t i = 0; i < num_pts; ++i) {
        i64 dx = i64(ys[i].x) - i64(mid_x);
        if (dx * dx <= d) {
            closer.push_back(ys[i]);
        }
    }

    size_t i = 0;
    while (i < closer.size() - 1) {
        size_t j = i + 1;
        while (j < closer.size() && (j - i) <= 8) {
            d = min(d, distance_square(closer[i], closer[j]));
            ++j;
        }
        ++i;
    }

    return d;
}

int main() {
    ifstream in("cmap.in");

    size_t num_pts;
    in >> num_pts;

    vector<Point> pts(num_pts);
    for (size_t i = 0; i < num_pts; ++i) {
        in >> pts[i];
    }

    vector<Point> xs = pts, ys = pts;

    sort(xs.begin(), xs.end(), [] (const Point& a, const Point& b) { return a.x < b.x; });
    sort(ys.begin(), ys.end(), [] (const Point& a, const Point& b) { return a.y < b.y; });

    ofstream out("cmap.out");
    i64 d_squared = min_distance(num_pts, xs.data(), ys.data());
    out << sqrt(d_squared) << '\n';
}
