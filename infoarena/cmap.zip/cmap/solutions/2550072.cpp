#include <bits/stdc++.h>

using namespace std;

int x[100002], y[100002], n;
double ans = DBL_MAX;

int main()
{
    ifstream cin("cmap.in");
    ofstream cout("cmap.out");
    cin >> n;
    for(int i = 1; i <= n; ++i)
        cin >> x[i] >> y[i];


    for(int i = 1; i <= n; ++i)
        for(int j = i + 1; j <= n; ++j)
            ans = min(ans, double(abs(x[i] - x[j]) * abs(x[i] - x[j]) + abs(y[i] - y[j]) * abs(y[i] - y[j])));

    cout << fixed << setprecision(6) << sqrt(ans) << '\n';
    cin.close(), cout.close();
}
