
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"

using namespace std;
pair <int,int> v[100001];
double distanta(pair <int,int> n, pair <int,int> m){
    pair <double,double> a = n,b = m;
    return sqrt((b.first - a.first) * (b.first - a.first) + (b.second - a.second) * (b.second - a.second));
}
int main()
{
    ifstream cin("cmap.in");
    ofstream cout("cmap.out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n,i;
    cin >> n;
    for(i = 1;i <= n;i++){
        cin >> v[i].first >> v[i].second;
    }
    double minim = (double)(1LL << 60);
    sort(v + 1,v + n + 1);
    for(i = 1;i <= n;i++){
        for(int j = i + 1;j <= min(i + (int)100,n);j++){
            minim = min(minim,distanta(v[i],v[j]));
        }
    }
    cout << fixed << setprecision(6) << minim;
    return 0;
}
