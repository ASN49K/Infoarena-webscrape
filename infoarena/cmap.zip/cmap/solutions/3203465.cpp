#include <fstream>
#include <vector>
#include <set>
#include <cmath>
#include <climits>
using namespace std;

int n,m;

struct coord {
	int x, y;
};

ifstream cin("dijkstra.in");
ofstream cout("dijkstra.out");

double calculateDistance(const coord& a, const coord& b) {
	return sqrt((a.x - b.x) * 1ll * (a.x - b.x) + (a.y - b.y) * 1ll * (a.y - b.y));
}

int main()
{
	cin >> n;

	vector<coord> v(n+1);
	for (int i = 1; i <= n; i++)
	{
		cin >> v[i].x >> v[i].y;
	}

	double minDistance = INT_MAX;
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			double distance = calculateDistance(v[i], v[j]);
			minDistance = min(minDistance, distance);
		}
	}

	cout.precision(8);
	cout << minDistance;
	return 0;
}
