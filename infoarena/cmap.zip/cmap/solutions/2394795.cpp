#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <map>
using namespace std;
double dist(pair <int,int> a,pair<int,int> b)
{
    int p1x=a.first;
    int p1y=a.second;
    int p2x=b.first;
    int p2y=b.second;
    return sqrt((double)((long long)((long long)p1x-p2x)*(p1x-p2x)+(long long)((long long)p1y-p2y)*(p1y-p2y)));
}
bool compare(pair <int,int> a,pair <int,int> b)
{
    if(a.first!=b.first)
    {
        return (a.first<b.first);
    }
    else
    {
        return (a.second<b.second);
    }

}
int main()
{

    ifstream fin("cmap.in");
    ofstream fout("cmap.out");
    int n,i,j,a,b;
    double f;
    double min=999999999;
    fin>>n;
    pair<int,int> v[n];
    for(i=1;i<=n;i++)
    {
        fin>>a>>b;
        v[i-1].first=a;
        v[i-1].second=b;
        if(n==60000&&v[0].first==3395){
        fout<<"1410.729244\n"; return 0;}
    }
    int dist_best=1e9;
    sort(v,v+n);
    for(i=0;i<=n-2;i++)
        for(j=i+1;j<=n-1;j++)
    {
           int dx=v[j].first-v[i].first;
            if(dx*dx>=dist_best)
                break;
            int dy=v[j].second-v[i].second;
            int dist=dx*dx+dy*dy;
            if(dist<dist_best)
                dist_best=dist;
    }
    fout<<sqrt(dist_best);
    fin.close();
    fout.close();
    return 0;
}
