#include <fstream>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <set>
using namespace std;

ifstream cin ("cmap.in");
ofstream cout ("cmap.out");

const long long nmax = 2e5 + 7;

set<pair<long long,long long>>s,aux;

struct point
{
    long long x;
    long long y;
} p[nmax];

long long cmp(point a,point b) {
        return a.x < b.x;
}

long long dist_square(long long a,long long b,long long c,long long d) {
        return (a - b) * (a - b) + (c - d) * (c - d);
}

long long dmin;
int main()
{
    /*
    set<long long> ss = {1, 4, 7, 2, 5, 10};
    set<long long>::iterator it = ss.upper_bound(2);

    for (; it != ss.end(); ++it)
        cout << *it << ' ';
    */
        long long n,i,j;
        cin >> n;
        for(i=1; i<=n; i++)
        {
            cin >> p[i].x;
            cin >> p[i].y;
        }
        sort(p+1,p+n+1,cmp);
        dmin = dist_square(p[1].x,p[2].x,p[1].y,p[2].y);
        j=1;
        for(i=1; i<=n; i++)
        {
            while ((p[i].x - p[j].x) * (p[i].x - p[j].x) > dmin)
            {
                s.erase({p[j].y,p[j].x});
                j++;
            }
            long long xmin,xmax,ymin,ymax;
            xmin = p[i].x - dmin;
            xmax = p[i].x + dmin;
            ymin = p[i].y - dmin;
            ymax = p[i].y + dmin;
            auto it = s.lower_bound({ymin,0});
            auto it2 = s.upper_bound({ymax,0});
            for(; it != it2; it++)
                dmin = min(dmin, dist_square(p[i].x,it->second,p[i].y,it->first));
            s.insert({p[i].y,p[i].x});
        }
        double ans = sqrt(dmin);
        cout << std::fixed;
        cout  << setprecision(6) << ans;
        return 0;
}
