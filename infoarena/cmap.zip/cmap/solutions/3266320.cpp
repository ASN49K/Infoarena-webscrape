#pragma GCC optimize("O3")
#pragma GCC optimize("fast-math")
#pragma GCC optimize("unroll-loops")
#include<bits/stdc++.h>
#define mod 194767
#define inf 0x3f3f3f3f
#define ll long long
#define ull unsigned long long
using namespace std;
const int dim = 100005;

ll n, sum, mini = inf;
struct el
{
    ll lin, col;
}v[dim];
ll dist(int i, int j)
{
    return 1ll * (v[i].lin - v[j].lin) * (v[i].lin - v[j].lin) + 1ll * (v[i].col - v[j].col) * (v[i].col - v[j].col);
}
ifstream fin("cmap.in");
ofstream fout("cmap.out");
ull lgput(ull a, ull b)
{
    ull p = 1;
    while(b)
    {
        if(b & 1)
            p = (p * a) % mod;

        b >>= 1;
        a = (a * a) % mod;
    }
    return p % mod;
}
bool cmp(el x, el y)
{
    return x.col < y.col;
}
void divide(int st, int dr)
{
    if(dr - st < 2)
    {
        if(st != dr)
        {

        mini =  min(mini, dist(st, dr));
        }
    }

    else
    {
        int mid = (st + dr) / 2;
        divide(st, mid);
        divide(mid + 1, dr);
        sort(v + st + 1, v + dr + 1, [](el x, el y)
        {
            return x.col < y.col;
        });
        for(int i = st; i <= dr; ++i)
        {
            for(int j = i - 1; j >= st && i - j < 8; --j)
            {
                 mini =  min(mini, dist(i, j));
            }
        }
    }
}
int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++i)
        fin >> v[i].lin >> v[i].col;
    sort(v + 1, v + n + 1, [](el x, el y)
    {
        return x.lin < y.lin;
    });
    divide(1, n);
    fout << fixed << setprecision(10) << (double)sqrt(mini);
    return 0;

}
