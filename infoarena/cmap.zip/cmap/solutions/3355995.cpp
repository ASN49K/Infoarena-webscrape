#include <algorithm>
#include <iomanip>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

ifstream fin("cmap.in");
ofstream fout("cmap.out");

struct Point {
  double x, y;
};

using Polygon = vector<Point>;

double squaredDist(Point a, Point b) {
  return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

double dist(Point a, Point b) {
  return sqrt(squaredDist(a, b));
}

double divideClosest(int st, int dr, const Polygon &poly) {
  if(st + 1 == dr) {
    return dist(poly[st], poly[dr]);
  }
  if(st + 2 == dr) {
    return min({dist(poly[st], poly[st + 1]), dist(poly[st + 1], poly[st + 2]), dist(poly[st + 2], poly[st])});
  }
  int mij = (st + dr) / 2;
  double minim = min(divideClosest(st, mij, poly), divideClosest(mij + 1, dr, poly));
  vector<Point> pts;
  for(int i = st; i <= dr; i++) {
    if((poly[i].x - poly[mij].x) * (poly[i].x - poly[mij].x) <= minim) {
      pts.push_back(poly[i]);
    }
  }
  sort(pts.begin(), pts.end(), [&](Point a, Point b) {
    return a.y < b.y;
  });
  for(int i = 0; i < (int)pts.size(); i++) {
    for(int j = i + 1; j < (int)pts.size(); j++) {
      if((pts[i].y - pts[j].y) * (pts[i].y - pts[j].y) > minim) {
        break;
      }
      minim = min(minim, dist(pts[i], pts[j]));
    }
  }
  return minim;
}

double closestPoints(Polygon &poly) {
  sort(poly.begin(), poly.end(), [&](Point a, Point b) {
    return a.x < b.x;
  });
  return divideClosest(0, (int)poly.size() - 1, poly);
}

int main() {
  int n;
  fin >> n;
  Polygon poly(n);
  for(int i = 0; i < n; i++) {
    fin >> poly[i].x >> poly[i].y;
  }
  fout << fixed << setprecision(6) << closestPoints(poly) << "\n";
  return 0;
}