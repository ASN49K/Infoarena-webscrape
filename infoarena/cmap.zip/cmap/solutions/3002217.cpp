#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("cmap.in" , "r" , stdin) , freopen("cmap.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

ll n;
pii a[N] , A[N] , B[N] , C[N] , aux[N];

ll cnt = 0;
ll sz = 0;

void merge(pii A[] , ll la , ll ra , pii B[] , ll lb , ll rb)
{
    ll i = la , j = lb;
    cnt = 0;

    while(i <= ra && j <= rb)
    {
        if(A[i].second < B[j].second)
            C[++cnt] = A[i++];
        else C[++cnt] = B[j++];
    }

    while(i <= ra)
        C[++cnt] = A[i++];

    while(j <= rb)
        C[++cnt] = B[j++];
}

void copy(pii A[] , pii B[] , ll l)
{
    for(ll i = 1 ; i <= cnt ; i++)
        A[i + l - 1] = B[i];
}

ll dist(pii a , pii b)
{
    return (a.first - b.first) * (a.first - b.first) + (a.second - b.second) * (a.second - b.second);
}

ll solve(ll l , ll r , pii A[] , pii B[])
{
    if(r - l + 1 <= 3)
    {
        for(ll i = l ; i <= r ; i++)
            A[i] = a[i];

        for(ll i = l ; i <= r ; i++)
            for(ll j = i + 1 ; j <= r ; j++)
                if(A[i].second > A[j].second)
                    swap(A[i] , A[j]);

        ll p = LLONG_MAX;

        for(ll i = l ; i <= r ; i++)
            for(ll j = i + 1 ; j <= r ; j++)
                p = min(p , dist(A[i] , A[j]));

        return p;
    }

    ll mid = (l + r) / 2;
    ll p = min(solve(l , mid , A , B) , solve(mid + 1 , r , B , A));

    merge(A , l , mid , B , mid + 1 , r);
    copy(A , C , l);

    sz = 0;

    for(ll i = 1 ; i <= cnt ; i++)
        if(abs(C[i].first - a[mid].first) <= p)
            aux[++sz] = C[i];

    for(ll i = 1 ; i <= sz ; i++)
        for(ll j = i + 1 ; j <= (i + 8) && j <= sz ; j++)
            p = min(p , dist(aux[i] , aux[j]));

    return p;
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

	ll i;

	cin >> n;

	for(i = 1 ; i <= n ; i++)
        cin >> a[i].first >> a[i].second;

    sort(a + 1 , a + n + 1);

    cout << fixed << setprecision(6) << sqrt(solve(1 , n , A , B));

    return 0;
}
