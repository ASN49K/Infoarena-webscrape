#include <bits/stdc++.h>

using namespace std;

struct el
{
    double long x,y;
};
el v[100005];

double long  t;

bool ord1(const el & a,const el & b)
{
    if(a.x<b.x)
    {
        return true;
    }
    return false;
}

bool ord2(const el & a,const el & b)
{
    if(a.y<b.y)
    {
        return true;
    }
    return false;
}

void rez(int a,int b)
{
    if(a==b)
    {
        return;
    }
    int mij=(a+b)/2;
    rez(a,mij);
    rez(mij+1,b);
    vector <el> s;
    for(int i=a;i<=b;++i)
    {
        if((v[i].x-v[mij].x)*(v[i].x-v[mij].x)<=t)
        {
            s.push_back(v[i]);
        }
    }
    sort(s.begin(),s.end(),ord2);
    for(int i=0;i<s.size()-1;++i)
    {
        for(int j=i+1;j<s.size();++j)
        {
            if(((v[i].x-v[j].x)*(v[i].x-v[j].x)+(v[i].y-v[j].y)*(v[i].y-v[j].y))>t)
            {
                break;
            }
            else
            {
                t=((v[i].x-v[j].x)*(v[i].x-v[j].x)+(v[i].y-v[j].y)*(v[i].y-v[j].y));
            }
        }
    }
}

int main()
{
    ifstream cin("cmap.in");
    ofstream cout("cmap.out");
    int n;
    cin>>n;
    for(int i=1;i<=n;++i)
    {
        cin>>v[i].x>>v[i].y;
    }
    sort(v+1,v+n+1,ord1);
    t=1e18;
    rez(1,n);
    t=sqrt(t);
    cout<<fixed<<setprecision(6)<<t;
    return 0;
}
