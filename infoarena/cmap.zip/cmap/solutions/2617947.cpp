#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>
#define dist(a, b) ((a.first - b.first) * (a.first - b.first) + (a.second - b.second) * (a.second - b.second))
#define mid (st + ((dr - st) >> 1))
#define min(a, b) ((a < b) ? a : b)

std::pair<int, int> X[100005], Y[100005];

int Solve(int st, int dr) {
    int minimum = 2147483647;
    if(st > dr)
        return minimum;
    if(dr - st <= 2) {
        for(int i = st; i < dr; ++i)
            for(int j = i+1; j <= dr; ++j)
                if(dist(X[i], X[j]) < minimum)
                    minimum = dist(X[i], X[j]);
        return minimum;
    }
    return min(Solve(st, mid), Solve(mid+1, dr));
}

int main() {
    int n, i;
    std::ifstream fin("cmap.in");
    std::ofstream fout("cmap.out");
    fin >> n;
    for(i = 1; i <= n; ++i)
        fin >> X[i].first >> X[i].second;
    std::sort(X+1, X+n+1);
    fout << std::fixed << std::setprecision(6) << sqrt(Solve(1, n));
}