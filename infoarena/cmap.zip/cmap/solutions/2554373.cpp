#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"

using namespace std;
pair <int,int> v[100001];
long double distanta(pair <int,int> n, pair <int,int> m){
    pair <long double,long double> a = n,b = m;
    return sqrt((b.first - a.first) * (b.first - a.first) + (b.second - a.second) * (b.second - a.second));
}
int main()
{
    ifstream cin("arrows.in");
    ofstream cout("arrows.out");
    int n,i;
    cin >> n;
    for(i = 1;i <= n;i++){
        cin >> v[i].first >> v[i].second;
    }
    long double minim = (long double)(1LL << 60);
    sort(v + 1,v + n + 1);
    for(i = 1;i <= n;i++){
        for(int j = i + 1;j <= min(i + (int)sqrt(n) + 1,n);j++){
            minim = min(minim,distanta(v[i],v[j]));
        }
    }
    cout << fixed << setprecision(6) << minim;
    return 0;
}
