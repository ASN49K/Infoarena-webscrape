#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;

#define pb push_back

struct Point{ll x; ll y;};
bool comp_x(Point &A, Point &B){return A.x<B.x;}
bool comp_y(Point &A, Point &B){return A.y<B.y;}

ll get_distance(Point A, Point B){
    return (A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y);
}

ll bruteforce(vector<Point> points, int st, int dr){
    ll minim = LLONG_MAX;
    for(int i=st;i<=dr;i++) for(int j=i+1;j<=dr;j++){
            minim=min(minim, get_distance(points[i],points[j]));
    }
    return minim;
}

ll find_closest(vector<Point> x_sorted, vector<Point> y_sorted, int st, int dr){
    if(dr-st+1<=3)
        return bruteforce(x_sorted, st, dr);

    int mid=(st+dr)/2;
    ll dist=min(find_closest(x_sorted,y_sorted,st,mid),find_closest(x_sorted,y_sorted,mid+1,dr));

    sort(y_sorted.begin()+st,y_sorted.begin()+dr+1,comp_y);

    vector<Point> points(dr-st+1);
    int len=0;
    for(int i=st;i<=dr;i++){
        if((y_sorted[i].x-x_sorted[mid].x)*(y_sorted[i].x-x_sorted[mid].x)<=dist)
            points[len++]=y_sorted[i];
    }

    for(int i=0;i<len;i++){
        for(int j=i+1;j<len && (points[j].y-points[i].y)*(points[j].y-points[i].y)<=dist;j++){
            dist=min(dist, get_distance(points[i],points[j]));
        }
    }

    return dist;
}

void solve(){
    freopen("cmap.in", "r", stdin);
    freopen("cmap.out", "w", stdout);

    int N; cin>>N;
    vector<Point> x_sorted(N);
    vector<Point> y_sorted(N);
    for(int i=0;i<N;i++)
        cin>>x_sorted[i].x>>x_sorted[i].y;

    sort(x_sorted.begin(), x_sorted.end(), comp_x);
    for(int i=0;i<N;i++)
        y_sorted[i]={x_sorted[i].x, x_sorted[i].y};

    cout<<fixed<<setprecision(10)<<sqrt(find_closest(x_sorted, y_sorted, 0, N-1));
}

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0);
    solve();
    return 0;
}