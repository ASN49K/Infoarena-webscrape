#include <bits/stdc++.h>
#define x first
#define y second

using namespace std;
ifstream f("cmap.in");
ofstream g("cmap.out");
long long n;
typedef pair<long long,long long> p;
p v[100005];
long double dist(p a,p b)
{
    return sqrt(1LL*(b.x-a.x)*(b.x-a.x)+1LL*(b.y-a.y)*(b.y-a.y));
}
long double divide(long long a, long long b)
{
    long double Min = INT_MAX;
    if(b-a+1<=3)
    {
        for(long long i=a;i<=b;i++)
        {
            for(long long j=i+1;j<=b;j++)
            {
                if(dist(v[i],v[j])<Min)
                {
                    Min=dist(v[i],v[j]);
                }
            }
        }
        return Min;
    }
    long long mij=(a+b)/2;
    Min=min(divide(a,mij),divide(mij+1,b));
    vector <p> pointss;
    for(long long i=a;i<=b;i++)
    {
        if(v[i].x-v[mij].x<=Min && v[mij].x-v[i].x<=Min)
        {
            pointss.push_back(v[i]);
        }
    }
    sort(pointss.begin(),pointss.end());
    for(long long i=0;i<pointss.size();i++)
    {
        for(long long j=i+1;j<pointss.size() && j<=i+20;j++)
        {
            Min=min(Min,dist(pointss[i],pointss[j]));
        }
    }
    return Min;
}
int main()
{
    f>>n;
    for(long long i=1;i<=n;i++)
    {
        f>>v[i].first>>v[i].second;
    }
    sort(v+1,v+n+1);
    g<<fixed<<setprecision(6);
    g<<divide(1,n)<<'\n';
    return 0;
}
