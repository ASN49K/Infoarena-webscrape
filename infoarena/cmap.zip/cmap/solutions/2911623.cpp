#include <bits/stdc++.h>
#define double long double
using namespace std;

const int N = (int) 1e5 + 7;

struct point
{
    double x, y;
} p[N];

bool cmp(point a, point b)
{
    return a.x < b.x;
}

double dist(point a, point b)
{
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return dx * dx + dy * dy;
}



int main()
{
    ifstream cin("cmap.in");
    ofstream cout("cmap.out");

    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        int a, b;
        cin >> a >> b;
        p[i] = {a, b};
    }
    sort(p + 1, p + n + 1, cmp);
    double cur = (double) 1e18 + 7;
    for (int i = 2; i <= n; i++)
    {
        for (int j = i - 1; j >= 1; j--)
        {
            if (p[i].x - p[j].x > cur)
            {
                break;
            }
            cur = min(cur, dist(p[i], p[j]));
        }
    }
    cout << fixed << setprecision(6) << sqrt(cur) << "\n";
    return 0;
}
