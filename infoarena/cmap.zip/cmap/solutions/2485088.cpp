#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;
ifstream f("cmap.in");
ofstream g("cmap.out");
pair<double,double> v[1<<17];
double dist(int a,int b)
{
    return sqrt((v[a].x-v[b].x)*(v[a].x-v[b].x)+(v[a].y-v[b].y)*(v[a].y-v[b].y));
}
int n,i,j;
double d;
int main()
{
    f>>n;
    for(i=1;i<=n;++i)
        f>>v[i].x>>v[i].y;
    sort(v+1,v+n+1);
    d=dist(1,n);
    for(i=1;i<=n;++i)
        for(j=i+1;j<=n;++j)
        {
            if(v[j].x-v[i].x>d||j-i>7) break;
            d=min(d,dist(i,j));
        }
    g<<fixed<<setprecision(6)<<d;
    return 0;
}
