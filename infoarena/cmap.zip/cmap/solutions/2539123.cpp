#include <fstream>
#include <algorithm>
#include <iomanip>
#include <cmath>
using namespace std;
#define ll long long
#define nrmax 100001
ifstream f("cmap.in");
ofstream g("cmap.out");
struct punct
{
    ll x , y;
}v[nrmax];
ll n , amin = 999999999999999999,i,j;
ll dist ( punct a, punct b )
{
    return (b.x-a.x)*(b.x-a.x) + (b.y-a.y)*(b.y-a.y);
}
bool cmp ( const punct a , const punct b )
{
    return a.x < b.x;
}

int main()
{
    f >> n;
    for (  i = 1; i <= n ; i++ )
        f >> v[i].x >> v[i].y;
    sort(v+1,v+n+1,cmp);

    for ( i = 1; i < n ; i++ )
        for(j=i+1;j<=n&&j<=i+7;j++)
      //  for (  j = i+1; j <= i+7 and j <= n ; j++ )
     // for(j=i+1;j<=i+7&&j<=n;j++)
            amin = min ( amin , dist(v[i],v[j]));
    g << fixed << setprecision(8) << sqrt(amin);
    return 0;
}
