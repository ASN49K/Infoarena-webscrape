#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("cmap.in" , "r" , stdin) , freopen("cmap.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char buff[5000];ll lg = 0 , p = 0;
    char nc()
    {
        if(lg == p){lg = fread(buff , 1 , 5000 , stdin);p = 0;if(!lg) return EOF;}
        return buff[p++];
    }
    template<class T>void read(T&x)
    {
        T sgn = 1; char c;while(!isdigit(c = nc()))if(c == '-')sgn = -1;
        x = c - '0';while(isdigit(c = nc()))x = x * 10 + c - '0';x *= sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

ll n;
pii X[N] , Y[N] , aux[N];

ll dist(pii a , pii b)
{
    return (a.first - b.first) * (a.first - b.first) + (a.second - b.second) * (a.second - b.second);
}

void merge(ll l1 , ll r1 , ll l2 , ll r2)
{
    ll i1 = l1 , i2 = l2 , lg = 0;

    while(i1 <= r1 && i2 <= r2)
    {
        if(Y[i1] <= Y[i2])
            aux[++lg] = Y[i1++];
        else aux[++lg] = Y[i2++];
    }

    while(i1 <= r1)
        aux[++lg] = Y[i1++];

    while(i2 <= r2)
        aux[++lg] = Y[i2++];
}

void copy(ll l , ll r)
{
    for(ll i = l ; i <= r ; i++)
        Y[i] = aux[i - l + 1];
}

ll divide(ll l , ll r , pii X[] , pii Y[])
{
    if(l >= r)
        return LLONG_MAX;

    if(r - l + 1 <= 3)
    {
        sort(Y + l , Y + r + 1);

        ll optimal = LLONG_MAX;

        for(ll i = l ; i < r ; i++)
            for(ll j = i + 1 ; j <= r ; j++)
                optimal = min(optimal , dist(X[i] , X[j]));

        return optimal;
    }

    ll mid = (r + l) / 2;
    ll optimal = min( divide(l , mid , X , Y) , divide(mid + 1 , r , X , Y) );

    merge(l , mid , mid + 1 , r);
    copy(l , r);

    ll lg = 0;

    for(ll i = l ; i <= r ; i++)
        if(abs(Y[i].second - X[mid].first) <= optimal)
            aux[++lg] = Y[i];

    for(ll i = 1 ; i <= lg ; i++)
        for(ll j = i + 1 ; j <= lg && j - i + 1 <= 8 ; j++)
            optimal = min(optimal , dist(aux[i] , aux[j]));

    return optimal;
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n;

    for(ll i = 1 ; i <= n ; i++)
        cin >> X[i].first >> X[i].second;

    sort(X + 1 , X + n + 1);

    for(ll i = 1 ; i <= n ; i++)
        Y[i] = {X[i].second , X[i].first};

    cout << fixed << setprecision(6) << sqrt(divide(1 , n , X , Y));

    return 0;
}
