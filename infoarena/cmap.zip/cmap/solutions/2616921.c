#include <stdio.h>
#include <stdlib.h>
#include <math.h>
FILE *f,*g;
struct punct
{
    int x,y;
}v[100];
int main()
{
    int n;
    float d=0,dd;
    f=fopen("cmap.in","r");
    g=fopen("cmap.out","w");
    fscanf(f,"%d",&n);
    for(int i=1;i<=n;i++)
    {
        fscanf(f,"%d %d",&v[i].x,&v[i].y);
    }
    for(int i=1;i<n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if((v[i].x>v[j].x)||(v[i].x==v[j].x&&v[i].y>v[j].y))
            {
                v[0]=v[i];
                v[i]=v[j];
                v[j]=v[0];
            }
        }
    }
    for(int i=1;i<=n-4;i++)
    {
        for(int j=i+1;j<=i+4;j++)
        {
            dd=sqrt((v[i].x-v[j].x)*(v[i].x-v[j].x)+(v[i].y-v[j].y)*(v[i].y-v[j].y));
            if(d==0||dd<d)
                d=dd;
        }
    }
    fprintf(g,"%f",d);
    return 0;
}
