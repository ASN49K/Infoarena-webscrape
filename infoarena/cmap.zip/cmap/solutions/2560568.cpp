#define MAX_N 100000

#include <fstream>
#include <cstdint>
#include <cmath>
#include <iomanip>
#include <limits>
using namespace std;

ifstream fin("cmap.in");
ofstream fout("cmap.out");

struct P
{
    int x, y;
};

int n;
P A[MAX_N + 1];

int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
    {
        fin >> A[i].x >> A[i].y;
    }

    long double dMin = 2e18;
    for (int i = 1; i < n; ++i)
    {
        for (int j = i + 1; j <= n; ++j)
        {
            int64_t x = A[i].x - A[j].x, y = A[i].y - A[j].y;
            x *= x;
            y *= y;

            dMin = min(dMin, (long double) x + y);
        }
    }

    fout << setprecision(numeric_limits<long double>::digits10 + 1) << sqrt(dMin);

    fin.close();
    fout.close();
    return 0;
}
