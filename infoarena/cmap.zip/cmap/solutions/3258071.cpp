#include <bits/stdc++.h>

using namespace std;

ifstream fin("cmap.in");
ofstream fout("cmap.out");
struct Punct {
    int x, y;

    Punct(int _x = 0, int _y = 0) {
        x = _x;
        y = _y;
    }

    int LungTo(Punct p) {
        return (p.x - x) * (p.x - x) + (p.y - y) * (p.y - y);
    }

    double Dist(Punct p) {
        return sqrt(LungTo(p));
    }
};
Punct p[100002];
int n, i;

static inline bool CmpX(Punct p1, Punct p2) {
    return p1.x < p2.x;
}

static inline bool CmpY(Punct p1, Punct p2) {
    return p1.y < p2.y;
}

static inline int Divi(int st, int dr) {
    if(st == dr) return INT_MAX;

    int mij = st + (dr - st) / 2;
    int rst = Divi(st, mij);
    int rdr = Divi(mij + 1, dr);
    int r = min(rst, rdr);

    vector<Punct> v;
    for(int i = st; i <= dr; i++) v.push_back(p[i]);

    sort(v.begin(), v.end(), CmpY);
    for(int i = 0; i < v.size() - 1; i++) {
        for(int j = i + 1; j < v.size(); j++) {
            if(v[i].LungTo(v[j]) > r) break;
            r = min(r, v[i].LungTo(v[j]));
        }
    }
    return r;
}

int main()  {
    fin >> n;
    for(i = 1; i <= n; i++) fin >> p[i].x >> p[i].y;

    sort(p + 1, p + n + 1, CmpX);

    fout << fixed << setprecision(6) << sqrt(Divi(1, n));

    return 0;
}
