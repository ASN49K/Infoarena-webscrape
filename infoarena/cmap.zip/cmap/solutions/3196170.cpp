#include <iostream>
#include <fstream>
#include <cmath>
#include <bits/stdc++.h>
using namespace std;

struct Pont{
double x;
double y;
};

double dist(double a1, double a2, double b1, double b2){
return (sqrt((a1-a2)*(a1-a2)+(b1-b2)*(b1-b2)));
}

int main()
{
    ifstream f ("cmap.in");
    ofstream g ("cmap.out");
    int n;
    double mi;
    f>>n;
    Pont p[100000];
    for(int i=0;i<n;i++){
        f>>p[i].x;
        f>>p[i].y;
    }
    mi=dist(p[0].x,p[1].x,p[0].y,p[1].y);
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(dist(p[i].x, p[j].x,    p[i].y, p[j].y) <mi)
                mi=dist(p[i].x,p[j].x,p[i].y,p[j].y);
        }
    }
g<<setprecision(10);
g<<mi;

    return 0;
}
