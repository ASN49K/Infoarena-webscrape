
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <fstream>

#define INF 2000000000
#define MAXN 100010
#define BUFF_SIZE 1048576
using namespace std;
struct punct{int x,y;}p[MAXN];
int i,j,n;
long long sol;

inline long long dist(punct a,punct b) {return (long long)((long long)(a.x-b.x)*(a.x-b.x)+(long long)(a.y-b.y)*(a.y-b.y));}
struct cmp{inline bool operator ()(punct a,punct b){return a.x<b.x;}};

struct cmp2{inline bool operator ()(punct a,punct b){return a.y<b.y;}};
int main()
{
    ifstream f  f("cmap.in");
    ofstream g("cmap.out");
    f>>n;
    for(i=0;i<n;i++)
    f>>p[i].x>>p[i].y;
    sort(p,p+n,cmp());
    sol=(1LL<<61);
    for(i=0;i<n;i++)
    for(j=i+1;j<=i+3 and j<n;j++)   if(dist(p[i],p[j])<sol) sol=dist(p[i],p[j]);
    sort(p,p+n,cmp2());
    for(i=0;i<n;i++)
    for(j=i+1;j<=i+3 and j<n;j++)   if(dist(p[i],p[j])<sol) sol=dist(p[i],p[j]);

    g<<setprecision(6)<<fixed;
    g<<sqrt((double)sol)<<"\n";
}
