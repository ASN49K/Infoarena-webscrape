#include <bits/stdc++.h>
#define x first
#define y second

using namespace std;
ifstream f("cmap.in");
ofstream g("cmap.out");
int n;
pair <int,int> a[100005];
set<pair<int,int>> v;
double distanta(pair <int, int > a,pair <int, int > b)
{
    return sqrt(1LL*(a.x-b.x)*(a.x-b.x)+1LL*(a.y-b.y)*(a.y-b.y));
}
int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>a[i].x>>a[i].y;
    }
    sort(a+1,a+n+1);
    double sol=2e9;
    int ind=1;
    for(int i=1; i<=n;i++)
    {
        while(!v.empty() && a[i].x-a[ind].x>=sol)
        {
            v.erase({a[ind].y,a[ind].x});
            ind++;
        }
        int y_Down=a[i].y-(int )(sol);
        int y_Up=a[i].y+(int )(sol);
        set<pair <int, int > >::iterator d=v.lower_bound({y_Down,1e9});
        set<pair <int, int > >::iterator u=v.lower_bound({y_Up,1e9});
        for(set<pair <int, int > >::iterator it=d; it!=u;it++)
        {
            pair <int, int > nr=*it;
            swap(nr.x,nr.y);
            double ans=distanta(nr,a[i]);
            sol=min(sol,ans);
        }
        v.insert({a[i].y,a[i].x});
    }
    g<<setprecision(6)<<fixed;
    g<<sol<<'\n';
    return 0;
}
