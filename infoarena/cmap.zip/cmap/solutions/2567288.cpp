#include <bits/stdc++.h>

#define ldb     long double

int N;
std::vector <std::pair <int, int>> V;

ldb dist(int x0, int y0, int x1, int y1) {
    ldb ans = (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1);
    return sqrt(ans);
}
ldb dist(std::pair <int, int> &p0, std::pair <int, int> &p1) {
    return dist(p0.first, p0.second, p1.first, p1.second);
}

#define FILENAME    std::string("cmap")
std::ifstream input (FILENAME+".in");
std::ofstream output(FILENAME+".out");

int32_t main()
{
    input >> N;
    V.resize(N);
    for (auto &it:V) input >> it.first >> it.second;
    std::sort(V.begin(), V.end());

    ldb min = 4e9;
    int ptr = 0;
    for (int i=0; i<V.size(); ++i) {
        while (dist(V[ptr].first, 0, V[i].first, 0) > min) ++ ptr;
        for (int j=ptr; j<i; ++j)
            min = std::min(min, dist(V[j], V[i]));
    }   output << std::fixed << std::setprecision(7) << min << '\n';

    return 0;
}
