include <iostream>

#include <fstream>

#include <stdint.h>

using namespace std;

ifstream fin("ssm.in");

ofstream fout("ssm.out");

int n, s, mi = 0, imi = 0, sma = 0, st, dr;

int main()

{

fin >> n;

for (int i = 1; i <= n; ++i)

{

int x;

fin >> x;

s += x;

if (s < mi)

{

mi = s;

imi = i;

}

else if (s - mi > sma)

{

sma = s - mi;

st = imi + 1, dr = i;

}

}

fout << sma << " " << st << " " << dr;

return 0;

}

