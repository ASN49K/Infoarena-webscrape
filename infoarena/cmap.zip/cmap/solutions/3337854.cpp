#include <bits/stdc++.h>

using namespace std;
ifstream fin("cmap.in");  // strudel
ofstream fout("cmap.out");// cmap
long long n,i;
struct pct{
    long long x,y;
};
pct a[100010];
bool cmp(pct a,pct b){
    return a.x<b.x||a.x==b.x&&a.y<b.y;
}
bool cmp1(pct a,pct b){
    return a.y<b.y;
}
long long divide(long long st, long long dr){
    long long mind=7e18;
    int i,j;
    if(dr-st+1<=3){
        for(i=st;i<=dr;i++){
            for(j=i+1;j<=dr;j++){
                long long dist=(a[i].x-a[j].x)*(a[i].x-a[j].x)+(a[i].y-a[j].y)*(a[i].y-a[j].y);
                if(dist<mind) mind=dist;
            }
        }
        sort(a+st,a+dr+1,cmp1);
        return mind;
    }
    long long mid=(st+dr)/2;
    int midx=a[mid].x;
    long long d1=divide(st,mid);
    long long d2=divide(mid+1,dr);
    mind=min(d1,d2);
    vector<pct> v;
    for(i=st,j=mid+1;i<=mid&&j<=dr;){
        if(a[i].y<a[j].y){
            v.push_back(a[i]);
            i++;
        }
        else{
            v.push_back(a[j]);
            j++;
        }
    }
    while(i<=mid){
        v.push_back(a[i]);
        i++;
    }
    while(j<=dr){
        v.push_back(a[j]);
        j++;
    }
    for(int i=0;i<v.size();i++){
        a[st+i]=v[i];
    }
    v.clear();
    for(i=st;i<=dr;i++){
        if((a[i].x-midx)*(a[i].x-midx)<mind){
            v.push_back(a[i]);
        }
    }
    for(int i=0;i<v.size();i++){
            for(auto j=i+1;j<v.size()&&j<=i+7;j++){
                long long dist=(v[i].x-v[j].x)*(v[i].x-v[j].x)+(v[i].y-v[j].y)*(v[i].y-v[j].y);
                if(dist<mind) mind=dist;
            }
        }
    return mind;
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>a[i].x>>a[i].y;
    }
    sort(a+1,a+n+1,cmp);
    fout<<fixed<<setprecision(6)<<sqrt(1.0*divide(1,n));
    return 0;
}