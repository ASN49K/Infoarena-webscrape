#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("cmap.in");
ofstream fout("cmap.out");
ll t=LLONG_MAX;
struct pct
{
    ll x,y;
    bool operator <(const pct&a) const
    {
        return (x<a.x || (x==a.x && y<a.y));
    }
}p[100001];
ll dist(pct a,pct b)
{
    return (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y);
}
bool cmp(pct a,pct b)
{
    return a.y<b.y;
}
void solve(int st,int dr)
{
    if(st>=dr)
        return;
    int mid=(st+dr)/2;
    solve(st,mid);
    solve(mid+1,dr);
    vector<pct>v;
    for(int i=st;i<=dr;i++)
    {
        if((p[i].x-p[mid].x)<=t)
            v.push_back(p[i]);
    }
    sort(v.begin(),v.end(),cmp);
    for(int i=0;i<v.size();i++)
        for(int j=i+1;j<v.size();j++)
        {
            long long d=dist(v[i],v[j]);
            if(d<t)
                t=d;
            else break;
        }
}
int main()
{
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>p[i].x>>p[i].y;
    sort(p+1,p+n+1);
    solve(1,n);
    fout<<fixed<<setprecision(6)<<sqrt(t);
    return 0;
}
