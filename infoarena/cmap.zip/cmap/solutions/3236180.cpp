#include <fstream>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <cmath>
#include <random>
#include <ctime>
using namespace std;
ifstream cin("cmap.in");
ofstream cout("cmap.out");
#pragma GCC optimize ("Ofast,unroll-loops")
mt19937 mt(time(nullptr));
// e infoarena deci probabil se ia 100 cu asta
int n;
struct point{int x,y;};
point p[100001];
double formula(point unu, point doi)
{
    return sqrtl(1LL*(unu.x-doi.x)*(unu.x-doi.x)+1LL*(unu.y-doi.y)*(unu.y-doi.y));
}
signed main()
{
    cin >> n;
    for(int i = 1 ; i <= n ; ++i)
    {
        int asta , ala;
        cin >> asta >> ala;
        p[i] = {asta,ala};
    }
    sort(p+1,p+1+n,[](point unu,point doi){
         if(unu.y==doi.y) return unu.x<doi.x;
         else return unu.y > doi.y;});
    double dist = formula(p[1],p[2]);
    for(int i = 3 ; i <= n ; ++i)
    {
        for(int j = i-1 ; j >= 1 ; --j)
        {
            int d = (int)dist;
            if(p[i].x-p[j].x > d) break;
            dist = min(dist,formula(p[i],p[j]));
        }
    }
    cout << fixed << setprecision(6) << dist ;
    return 0;
}
