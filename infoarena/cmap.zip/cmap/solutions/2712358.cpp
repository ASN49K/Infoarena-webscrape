#include <bits/stdc++.h>
#define ll long long
#define pp pair<ll, ll>
#define x first
#define y second

using namespace std;

const int mxn = 100 * 1000 + 10;


pair <ll, ll> punct[ mxn ];

int n;

inline ll dist(pp a, pp b){
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

inline ll distX(pp a, pp b){
    return (a.x - b.x) * (a.x - b.x);
}

int main()
{


    ifstream cin("cmap.in");
    ofstream cout("cmap.out");
    cin>> n;
    for(int i = 0; i < n; i++){
        cin>>punct[ i ].x >> punct[ i ].y;
    }

    sort(punct, punct + n);

    ll sol = 2000*1000*1000*1000000000;


    for(int i = 0; i < n - 1; i++){
        for(int j = i + 1; j < n && distX(punct[ i ], punct[ j ]) <= sol; j++){
            sol = min(sol, dist(punct[ i ], punct[ j ]));
        }
    }

    cout<< setprecision( 6 ) << fixed << (double)sqrt(sol);

    return 0;
}
