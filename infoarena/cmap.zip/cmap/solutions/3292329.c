#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define min(a,b) ((a) < (b) ? (a) : (b))

struct punct
{
    double ordonata;
    double abscisa;
};

int compare(const void *A, const void *B)
{
    struct punct a=*((struct punct*)A);
    struct punct b=*((struct punct*)B);
    if(a.ordonata-b.ordonata)
        return (a.ordonata-b.ordonata);
    if(a.abscisa-b.abscisa)
        return (a.abscisa-b.abscisa);
}

double distanta(struct punct a, struct punct b)
{
    return sqrt((a.ordonata-b.ordonata)*(a.ordonata-b.ordonata)+(a.abscisa-b.abscisa)*(a.abscisa-b.abscisa));
}

int search_stg(struct punct sir[], int i, int j, double d)
{
    int rez=i;
    while(i<=j)
    {
        int m=i+(j-i)/2;
        if(sir[m].ordonata<=d)
        {
            j=m-1;
            rez=m;
        }
        else
            i=m+1;
    }
    return rez;
}

int search_dr(struct punct sir[], int i, int j, double d)
{
    int rez=j;
    while(i<=j)
    {
        int m=i+(j-i)/2;
        if(sir[m].ordonata<=d)
        {
            i=m+1;
            rez=m;
        }
        else
            j=m-1;
    }
    return rez;
}

double di(struct punct sir[], int i, int j)
{
    if(j==i)
        return __INT_MAX__;
    if(j-i==1)
        return distanta(sir[i], sir[j]);

    int m=i+(j-i)/2;
    double d=min(di(sir, i, m), di(sir, m+1, j));

    int st=search_stg(sir, i, m, sir[m].ordonata-d);
    int dr=search_dr(sir, m+1, j, sir[m].ordonata+d);

    for(int k=st; i<=dr; i++)
    {
        for(int l=i+1; l<=dr && l<=k+6; l++)
            d=min(distanta(sir[k], sir[l]),d);
    }

    return d;
}

int main()
{
    FILE* in=fopen("cmap.in", "r"), *out=fopen("cmap.out" ,"w");
    int n;
    fscanf(in, "%d", &n);
    struct punct *sir=malloc(n*sizeof(struct punct));
    for(int i=0; i<n; i++)
    {
        fscanf(in, "%lf %lf", &sir[i].ordonata, &sir[i].abscisa);
    }
    qsort(sir, n, sizeof(struct punct), compare);
    double rez=di(sir, 0, n-1);
    fprintf(out, "%lf", rez);
    return 0;
}