#Problema celor mai apropiate 2 puncte

import math
puncte = list()


def dist(x1, x2, y1, y2):
    return math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1))


def dist_list(i1, i2):
    return dist(puncte[i1]['x'], puncte[i2]['x'], puncte[i1]['y'], puncte[i2]['y'])


def divide(st, dr):
    dmin = 99999999.0
    if dr-st+1 <= 3: #cazul celor 3 puncte
        for i in range(st, dr):
            for j in range(i+1, dr):
                print(dist_list(i, j))
                dmin = min(dmin, dist_list(i, j))
        return dmin
    else:
        mid = (st+dr)//2 #mediana
        dmin1 = divide(st, mid) #minim stanga
        dmin2 = divide(mid, dr) #minim dreapta
        dmin = min(dmin1, dmin2) #minim

        #unirea celor 2 jumatati
        puncte_2 = puncte[st:dr+1]

        #sortarea dupa y
        puncte_2 = sorted(puncte_2, key=lambda elem: (elem['y'], elem['x'])) #sortare dupa y si mai apoi dupa x in caz de egalitate

        '''puncte_inter = list()
        for elem in puncte_2:
            if abs(elem['x'] - puncte[mid]['x']) <= dmin:
                puncte_inter.append(elem)
        '''
        #selectarea elementelor din "banda"
        puncte_inter = [elem for elem in puncte_2 if abs(elem['x'] - puncte[mid]['x']) <= dmin]

        for i in range(0, len(puncte_inter)):
            for j in range(i+1, i+8):
                if len(puncte_inter) > j: #exista punctul cu care comparam\
                    dmin = min(dmin, dist(puncte_inter[i]['x'], puncte_inter[j]['x'], puncte_inter[i]['y'], puncte_inter[j]['y']))

    return dmin


with open("cmap.in") as f:
    numar_puncte = int(f.readline())
    for line in f.readlines():
        (x, y) = map(int, line.split())
        puncte.append({"x": x, "y": y})

puncte = sorted(puncte, key = lambda element: (element["x"], element["y"])) #sortare dupa x si mai apoi dupa y in caz de egalitate
print(puncte)

minim = divide(0, numar_puncte-1)
print(minim)
with open("cmap.out", "w") as f:
    f.write(repr(round(minim, 6)))

