#include<bits/stdc++.h>
using namespace std;
mt19937 rnd((long long)(new char));
bool eps=1.e-14;
struct dd
{
    double x,y;
    bool operator <(const dd &a) const
    {
        if(x==a.x)return y<a.y;
        return x<a.x;
    }
};
double dist(dd a,dd b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
const double pi=2*acos(0);
dd t[100005];
int main()
{
    freopen("cmap.in","r",stdin);
    freopen("cmap.out","w",stdout);
    int n,i;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        scanf("%lf%lf",&t[i].x,&t[i].y);
            sort(t+1,t+n+1);
    double dist_min=100000000;
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
        //printf("%.6lf\n",rez);
    }
    double pr=rnd();
    double cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
pr=rnd();
    cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
 
pr=rnd();
    cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
 

pr=rnd();
    cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
 

pr=rnd();
    cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
 

pr=rnd();
    cos1=cos(pr),sin1=sin(pr);
    for(i=1;i<=n;i++)
    {
        dd v;
        v.x=t[i].x*cos1-t[i].y*sin1;
        v.y=t[i].x*sin1+t[i].y*cos1;
        t[i]=v;
    }
    sort(t+1,t+n+1);
    for(i=1;i<n;i++)
    {
        double rez=dist(t[i],t[i+1]);
        if(dist_min>rez)dist_min=rez;
    }
 

    printf("%.6lf",dist_min);
    return 0;
}
