#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream fin("cmap.in");
ofstream fout("cmap.out");

struct Punct
{
    int x, y;
};

int n;
Punct A[100001];
long double dmin = 3000000000.0d;

int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
    {
        fin >> A[i].x >> A[i].y;
        for (int j = 1; j < i; ++j)
        {
            int c1 = A[i].x - A[j].x;
            int c2 = A[i].y - A[j].y;
            long long d2 = 1LL * c1 * c1 + 1LL * c2 * c2;
            dmin = sqrt((long double)d2);
        }
    }
    fout << fixed << setprecision(100) << dmin;

    return 0;
}