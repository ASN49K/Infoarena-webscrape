#include <bits/stdc++.h>

#define llg     long long
#define ldb     long double

int N;
std::vector <std::pair <int, int>> V;

ldb dist(int x0, int y0, int x1, int y1) {
    ldb ans = (ldb)(x0-x1)*(x0-x1) + (ldb)(y0-y1)*(y0-y1);
    return sqrt(ans);
}
ldb dist(std::pair <int, int> &p0, std::pair <int, int> &p1) {
    return dist(p0.first, p0.second, p1.first, p1.second);
}
llg dist2(int x0, int y0, int x1, int y1) {
    llg ans = 1ll*(x0-x1)*(x0-x1) + 1ll*(y0-y1)*(y0-y1);
    return ans;
}
llg dist2(std::pair <int, int> &p0, std::pair <int, int> &p1) {
    return dist2(p0.first, p0.second, p1.first, p1.second);
}

#define FILENAME    std::string("cmap")
std::ifstream input (FILENAME+".in");
std::ofstream output(FILENAME+".out");

int32_t main()
{
    input >> N;
    V.resize(N);
    for (auto &it:V) input >> it.first >> it.second;
    std::sort(V.begin(), V.end());

    int ptr = 0;
    llg min = 4e18;
    for (int i=0; i<V.size(); ++i) {
        while ((V[i].first - V[ptr].first)*(V[i].first - V[ptr].first) > min)
            ++ ptr;
        for (int j=ptr; j<i; ++j)
            if (dist2(V[j], V[i]) < min)
                min = std::min(min, dist2(V[i], V[j]));
    }   output << std::fixed << std::setprecision(6) << sqrt((ldb)(min)) << '\n';

    return 0;
}
