#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream fin("cmap.in");
ofstream fout("cmap.out");
float compara(int x1,int x2, int y1, int y2)
{
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
int main()
{
    int n,i,j;
    float x[100000],y[100000],maxi=1000;
    fin>>n;
    for (i=0; i<n; i++)
        fin>>x[i]>>y[i];
    maxi=compara (x[0],x[1],y[0],y[1]);
    for (i=0; i<n-1; i++)
    {
        for (j=i+1; j<n; j++)
        {

            float a=compara (x[i],x[j],y[i],y[j]);
            if (a<0)
                a=a*-1;
            if (a<maxi)
                maxi=a;
        }
    }
    fout<<fixed<<setprecision(6)<<maxi;
    return 0;
}
