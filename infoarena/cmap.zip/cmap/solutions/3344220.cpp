#include <bits/stdc++.h>
#define ll long long
#define pb push_back

using namespace std;
ifstream fin("cmap.in");
ofstream fout("cmap.out");
ll t;
struct P{
    ll x,y;;
    bool operator<(const P&other)const{
        if(x!=other.x)
            return x<other.x;
        return y<other.y;
    }
}p[100001];
ll dist(P a,P b){
    return (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y);
}
void solve(int st,int dr){
    if(st>=dr)
        return;
    int mid=(st+dr)/2;
    solve(st,mid);
    solve(mid+1,dr);
    vector<P>v;
    for(int i=st;i<=dr;i++){
        if(abs(p[i].x-p[mid].x)<=t)
            v.pb(p[i]);
    }
    for(int i=0;i<v.size();i++)
        for(int j=0;j<i;j++)
            t=min(t,dist(v[i],v[j]));
}

int main()
{
    int n;
    t=1e18;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>p[i].x>>p[i].y;
    sort(p+1,p+n+1);
    solve(1,n);
    fout<<fixed<<setprecision(6)<<sqrt(t);
    return 0;
}
