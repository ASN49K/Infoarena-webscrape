// https://infoarena.ro/problema/podm
#include <bits/stdc++.h>
using namespace std;
ifstream fin ("podm.in");
ofstream fout("podm.out");

int main() {
    int n;
    fin >> n;

    vector<int> v(n + 1);
    for (int i = 0; i <= n; i++)
        fin >> v[i];

    vector<vector<int64_t>> dp(n, vector<int64_t>(n));
    for (int i = 0; i < n; i++)
        dp[i][i] = 0;
    for (int i = 1; i < n; i++)
        dp[i - 1][i] = v[i - 1] * v[i] * v[i + 1];

    for (int l = 2; l < n; l++) {
        for (int i = 0, j = l; j < n; i++, j++) {
            int best = 1e9;
            //   (Mi ... Mk) (Mk+1 ... Mj)
            for (int k = i; k < j; k++) {
                const int c = dp[i][k] + v[i] * v[k+1] * v[j+1] + dp[k+1][j];
                best = min(best, c);
            }
            dp[i][j] = best;
        }
    }

    fout << dp[0][n - 1];
}
