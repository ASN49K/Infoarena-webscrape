#include <bits/stdc++.h>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

constexpr int N_MAX = 500;
int64_t dp[N_MAX + 1][N_MAX + 1];
int sizes[N_MAX + 1];

int main() {
    fin.tie(0);
    int n;
    fin >> n;
    for (int i = 0; i <= n; ++i) {
        fin >> sizes[i];
    }
    for (int i = 1; i <= n; ++i) {
        dp[i][i] = 0;
    }
    for (int len = 2; len <= n; ++len) {
        for (int i = 1; i <= n - len + 1; ++i) {
            int j = i + len - 1;
            dp[i][j] = LLONG_MAX;
            for (int k = i; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] +
                            1i64 * sizes[i - 1] * sizes[k] * sizes[j]);
            }
        }
    }
    fout << dp[1][n];
}
