//#include <iostream>
#include <fstream>
#define ll long long

using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");

ll dp[505][505];
ll v[505],n;


void dinamic()
{
   ll i=1,j=2,d=1;
   while(d<=n-1)
   {
       for(ll k=i;k<=j-1;k++)
       {
           if(dp[i][j]==0 || dp[i][j]>dp[i][k]+dp[k+1][j]+v[i-1]*v[k]*1LL*v[j])
                    {
                        dp[i][j]=dp[i][k]+dp[k+1][j]+v[i-1]*v[k]*1LL*v[j];
                    }
       }


       if(j==n)
        d++,j=d+1,i=1;
       else i++,j++;
   }
}

int main()
{

    cin>>n;
    //for(int i=1;i<=n;i++)
        //for(int j=1;j<=n;j++)
        //dp[i][j]=oo;

    for(int i=0; i<=n; i++)cin>>v[i];
    dinamic();
    //for(int i=1;i<=n;i++,cout<<'\n')
        //for(int j=1;j<=n;j++)
        //cout<<dp[i][j]<<" ";
    cout<<dp[1][n];

    return 0;
}
