#include <bits/stdc++.h>

#define int long long
#define pii pair<int, int>
#define fs first
#define sd second

using namespace std;

const string fileName = "podm";
ifstream in(fileName + ".in");
ofstream out(fileName + ".out");

const int di[] = {-1, 0, 1,  0};
const int dj[] = { 0, 1, 0, -1};

int n, d[505], dp[505][505];

signed main() {
   ios_base::sync_with_stdio(false);
   in.tie(NULL); in.tie(NULL);

   in >> n;
   for(int i = 0; i <= n; i++)
      in >> d[i];
   for(int i = 1; i <= n; i++)
      dp[i][i] = 0;
   for(int i = 1; i <= n - 1; i++)
      dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
   for(int k = 2; k <= n - 1; k++)
      for(int i = 1; i <= n - k; i++) {
         int j = i + k;
         dp[i][j] = LLONG_MAX;
         for(int nxt = i; nxt <= j - 1; nxt++)
            dp[i][j] = min(dp[i][j], dp[i][nxt] + dp[nxt + 1][j] + d[i - 1] * d[nxt] * d[j]);
      }
   out << dp[1][n] << '\n';

   return 0;
}
