#include <bits/stdc++.h>
#define NMAX 403

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long N,dp[NMAX][NMAX],d[NMAX];


int main()
{
    fin>>N;
    for(int i=0; i<=N; i++)
        fin>>d[i];

    for(int lg=2; lg<=N; lg++)
        for(int i=1; i<=N-lg+1; i++)
        {
            dp[i][i+lg-1]=LLONG_MAX;

            for(int k=i; k<=i+lg-1; k++)
                dp[i][i+lg-1]=min(dp[i][i+lg-1],dp[i][k]+dp[k+1][i+lg-1]+d[i-1]*d[i+lg-1]*d[k]);
        }


    fout<<dp[1][N];

    return 0;
}
