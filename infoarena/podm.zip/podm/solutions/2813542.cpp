#include <fstream>
#include <climits>

#define NMAX 505

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
int v[NMAX], dp[NMAX][NMAX];

int main()
{
    f >> n;
    for (int i = 1; i <= n + 1; i++)
        f >> v[i];

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {

            if (i == j)
                dp[i][j] = 0;
            else
                dp[i][j] = INT_MAX;
        }
    }

    for (int i = 1; i < n; i++)
        dp[i][i + 1] = v[i] * v[i + 1] * v[i + 2];

    for (int dist = 2; dist < n; dist++) {

        for (int i = 1; i <= n - dist; i++) {
            int j = i + dist;

            for (int k = i; k < j; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i] * v[k + 1] * v[j + 1]);
            }
        }
    }

    g << dp[1][n] << "\n";

    return 0;
}
