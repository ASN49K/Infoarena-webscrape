#include <bits/stdc++.h>
using namespace std;

long long a[503], n;
long long dp[503][503];

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);
    long long mn;
    int i, j, k;
    ifstream fin("podm.in");
    fin >> n;
    for (i = 1; i <= n + 1; i++)
        fin >> a[i];
    fin.close();
    for (i = 1; i < n; i++)
        dp[i][i + 1] = a[i]*a[i+1]*a[i+2];
    for (i = n - 2; i >= 1; i--)
      for (j = i + 2; j <= n; j++)
        {
            mn = (1LL << 60);
            for (k = i; k < j; k++)
                mn = min(mn, dp[i][k] + dp[k+1][j] + a[i]*a[k+1]*a[j+1]);
            dp[i][j] = mn;
        }
    ofstream fout("podm.out");
    fout << dp[1][n];
    fout.close();
    return 0;
}
