#include <fstream>
#include <algorithm>
#include <climits>
using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
long long dp[505][505];
int d[505];


int main()
{
    f>>n;
    for(int i=0; i<=n; i++)
        f>>d[i];
    for(int adaug=1; adaug<n; adaug++)
        for(int i=1; i+adaug<=n; i++){
            int j=i+adaug;
            long long vmin=LLONG_MAX;
            for(int k=i; k<=j-1; k++)
                vmin=min(dp[i][k] + dp[k+1][j] + 1LL*d[i-1]*d[k]*d[j], vmin);
            dp[i][j]=vmin;
    }
    g<<dp[1][n];

    return 0;
}
