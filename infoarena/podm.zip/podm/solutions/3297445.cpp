#include <stdio.h>

#include <vector>
#include <algorithm>

using ll = long long;
constexpr ll INF = 1e18;

int main() {
  FILE *fin = fopen( "podm.in", "r" );
  FILE *fout = fopen( "podm.out", "w" );

  int n;
  fscanf( fin, "%d", &n );
  std::vector<int> lat(n + 1);
  for( int i = 0; i <= n; i++ )
    fscanf( fin, "%d", &lat[i] );

  std::vector<std::vector<ll>> dp(n, std::vector<ll>(n, +INF));
  for( int i = 0; i < n; i++ )
    dp[i][i] = 0;

  for( int len = 2; len <= n; len++ )
    for( int st = 0; st + len - 1 < n; st++ ){
      int dr = st + len - 1;

      for( int k = st; k + 1 <= dr; k++ ){
        dp[st][dr] = std::min( dp[st][dr], dp[st][k] + dp[k + 1][dr] + lat[st] * (ll)lat[k + 1] * (ll)lat[dr + 1] );
      }
    }

  fprintf( fout, "%lld\n", dp[0][n - 1] );

  fclose( fin );
  fclose( fout );
  return 0;
}
