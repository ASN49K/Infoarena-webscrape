#include<bits/stdc++.h>
using namespace::std;

void setIO(string name, bool input = true, bool output = true){
	string inputname = name + ".in";
	string outputname = name + ".out";
	if(input) freopen(inputname.c_str(), "r", stdin);
	if(output) freopen(outputname.c_str(), "w", stdout);
}

const long long inf = 1e18 + 10;

int main(){
    setIO("podm");
	ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> p(n + 1);
    for(int i = 0; i <= n; i++) cin >> p[i];
    vector<vector<long long>> memo(n, vector<long long>(n, inf));
    for(int i = 0; i < n; i++) memo[i][i] = 0;
    for(int L = 2; L <= n; L++){
        for(int i = 0; i + L - 1 < n; i++){
            int j = i + L - 1;
            for(int k = i; k < j; k++){
                memo[i][j] = min(memo[i][j], memo[i][k] + memo[k + 1][j] + 1ll * p[i] * p[k + 1] * p[j + 1]);
            }
        }
    }
    cout << memo[0][n - 1] << endl;
    return 0;
}