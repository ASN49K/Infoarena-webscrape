#include <fstream>

using namespace std;

const int N = 500;
const long long INF = 1 << 50;

int a[N+1];
long long dp[N][N];

int main()
{
    ifstream in("podm.in");
    ofstream out("podm.out");
    int n;
    in >> n;
    for (int i = 0; i <= n; i++)
    {
        in >> a[i];
    }
    for (int i = n - 1; i >= 0; i--)
    {
        for (int j = i + 1; j  < n; j++)
        {
            dp[i][j] = INF;
            for (int k = i; k < j; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + (long long)a[i] * a[k+1] * a[j+1]);
            }
        }
    }
    out << dp[0][n-1];
    in.close();
    out.close();
    return 0;
}
