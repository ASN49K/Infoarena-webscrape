#include <iostream>
#include <cstdio>
#define NMAX 501
using namespace std;
const long long INF = 1LL << 62;
long long dp[NMAX][NMAX];
int dim[NMAX];

int main()
{
    FILE *fin, *fout;
    int n,i,j,k;
    fin = fopen("podm.in","r");
    fout = fopen("podm.out","w");
    fscanf(fin,"%d",&n);
    for(i=0; i<=n; i++)
        fscanf(fin,"%d",&dim[i]);
    for(i=n-1; i>=0; i--)
        for(j=i+1; j<n; j++){
            dp[i][j] = INF;
            for(k=i; k<j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k]+dp[k+1][j]+1LL*dim[i]*dim[k+1]*dim[j+1]);
        }
    fprintf(fout,"%lld\n",dp[0][n-1]);
    fclose(fin);
    fclose(fout);
    return 0;
}
