#include <bits/stdc++.h>
using namespace std;


ifstream fin("podm.in");
ofstream fout("podm.out");
/**
4
13 5 89 3 34

A(13 5)
B(5 89)
C(89 3)
D(3 24)

(AxB)x(CxD) : 13*5*89 + 89*3*24 + 13*89*24
(13 89)x(89 24)

(Ax(BxC))xD = 5*89*3 + 13*5*3 + 13*3*24
   (5,3)
(13,3)

dp[i][j] = costul minim pentru a inmulti
  matricele (A[i] x A[i+1] x ... x A[j])

Initial:
dp[i][i+1] = a[i]*a[i+1]*a[i+2], i=1..n-1

Recurente:
dp[i][j] = min(dp[i][k] + dp[k+1][j] + a[i]*a[k+1]*a[j+1])
k=i..j-1

Sol: dp[1][n]
*/

int a[503], n;
long long dp[503][503];

int main()
{
    long long mn;
    int i, j, k;
    fin >> n;
    for (i = 1; i <= n + 1; i++)
        fin >> a[i];
    /// initial:
    for (i = 1; i < n; i++)
        dp[i][i + 1] = a[i]*a[i+1]*a[i+2];
    /// recurente:
    for (i = n - 2; i >= 1; i--)
      for (j = i + 2; j <= n; j++)
        {
            mn = (1LL << 60);
            for (k = i; k < j; k++)
                mn = min(mn, dp[i][k] + dp[k+1][j] +
                         a[i]*a[k+1]*a[j+1]);
            dp[i][j] = mn;
        }


    /// solutia:
    fout << dp[1][n];
    return 0;
}
