#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <queue>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
int v[505];
int inf = 1e9;
int dp[505][505];
int t[505][505];

void citire()
{
	f >> n;
	for (int i = 0; i <= n; i++)
	{
		f >> v[i];
	}
}

void rezolvare_bu()
{
	for (int pas = 1; pas <= n - 1; pas++)
	{
		for (int i = 1; i <= n - pas; i++)
		{
			int j = i + pas;
			dp[i][j] = inf;
			for (int k = i; k < j; k++)
			{
				int cost = dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j];
				dp[i][j] = min(cost, dp[i][j]);
				t[i][k] = j;
			}
		}
	}
}

int main()
{
	citire();
	rezolvare_bu();
	/*
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			g << dp[i][j] << ' ';
		}
		g << '\n';
	}*/
	g << dp[1][n];
}