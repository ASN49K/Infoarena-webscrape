#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define vt vector
#define pb push_back
#define em emplace
#define emb emplace_back

#define all(x) x.begin(), x.end()
#define all1(x) x.begin() + 1, x.end()
#define sz(x) (int)(x).size()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T> void re(vt <T>& x);
template <class T> void re(T& x) {
    cin >> x;
}

template <class H, class... T> void re(H &x, T&... y) {
    re(x); re(y...);
}

template <class T> void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T> void wr(T x) {
    cout << x;
}

template <class H, class ...T> void wr(H x, T... y) {
    wr(x); wr(y...);
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

const ll INF = 1e18;

ll dp[501][501];

void solve() {
    int n; re(n);
    vt <ll> v(n + 1); re(v);
    for(int s = 2;s <= n;s++)
        for(int l = 1;l + s - 1 <= n;l++) {
            int r = l + s - 1;
            dp[l][r] = INF;
            for(int m = l;m < r;m++) {
                dp[l][r] = min(dp[l][r],
                    dp[l][m] + dp[m + 1][r] + v[l - 1] * v[m] * v[r]);
            }
        }
    wr(dp[1][n]);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("podm");

    int t = 1;
    for(;t;t--) {
        solve();
    }

    return 0;
}