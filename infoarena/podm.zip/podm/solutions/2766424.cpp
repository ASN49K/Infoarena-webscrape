#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
#define NMAX 505

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
long long v[NMAX], d[NMAX][NMAX];

int calcul(int i, int j)
{
    if(d[i][j])
        return d[i][j];

    if(j - i == 1)
        return 0;

    long long mini = INF;
    for(int k = i + 1; k <= j - 1; k++)
        mini = min(mini, calcul(i, k) + calcul(k, j) + v[i] * v[j] * v[k]);

    d[i][j] = mini;
    return mini;
}


int main()
{
    f >> n;
    n++;

    for(int i = 1; i <= n; i++)
        f >> v[i];

    g << calcul(1, n);

    return 0;
}
