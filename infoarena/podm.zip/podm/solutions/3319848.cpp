#include <fstream>
#include <climits>
#define inf INT_MAX
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
long long n,i,d[505][505],v[505],j,l,k;
int main()
{
    cin>>n;
    for(i=0;i<=n;i++) cin>>v[i];
    for(i=1;i<=n;i++) d[i][i]=0;
    for(i=1;i<=n;i++) d[i][i+1]=v[i-1]*v[i]*v[i+1];
    for(l=2;l<=n-1;l++)
    {
        for(i=1;i<=n-l;i++)
        {
            j=i+l;
            d[i][j]=inf;
            for(k=i;k<=j-1;k++)
            {
                d[i][j]=min(d[i][j],d[i][k]+d[k+1][j]+v[i-1]*v[k]*v[j]);
            }
        }
    }
    cout<<d[1][n];
    return 0;
}
