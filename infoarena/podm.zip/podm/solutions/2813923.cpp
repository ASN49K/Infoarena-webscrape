#include <fstream>
#define INF 100000000000000000LL
#define NMAX 501
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n, i, j, dif;
long long pd[NMAX][NMAX], d[NMAX];
long long int cuts[NMAX][NMAX];
int main()
{
    fin>>n;
    for(i=0;i<=n;i++)
        { fin>>d[i];
          pd[i][i]=0;
        }
    for(i=1;i<n;i++)
        pd[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(dif=2;dif<n;dif++)
        for(i=1;i<=n-dif;i++)
           {
             j=i+dif;
             pd[i][j]=INF;
             for(int k=i;k<j;k++)
                {
                 int sum;
                 sum=pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j];
                 if(sum<pd[i][j])
                   {
                     pd[i][j]=sum;
                     cuts[i][j]=k;
                   }
                }
           }
    fout<<pd[1][n];
    return 0;
}
