#include <iostream>
#include <fstream>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
const long long INF = 1LL << 62;

int N;
short int D[501];
long long M[500][500];

void calcul()
{
    for(int d = 1; d < N; d++)
        for(int i = N - d - 1; i >= 0; i--)
        {
            int j = i + d;
            M[i][j] = INF;
            for(int k = i; k < j; k++)
            {
                long long t = M[i][k] + M[k + 1][j] + (long long)D[i] * D[k + 1] * D[j + 1];
                if(M[i][j] > t)
                    M[i][j] = t;
            }
        }
}


int main()
{
    f >> N;
    for(int i = 0; i <= N; i++)
        f >> D[i];
    calcul();
    g << M[0][N - 1];
    return 0;
}
