#include <fstream>
#include <climits>
#include <algorithm>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int n, a[502], dp[501][501];
int main()
{
    f >> n;
    for (int i = 0; i <= n; ++i) f >> a[i];
    for (int d = 1; d < n; ++d) {
        for (int i = 1; i + d <= n; ++i) {
            int j = i + d;
            dp[i][j] = INT_MAX;
            for (int k = i; k <= j - 1; ++k) dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
        }
    }
    g << dp[1][n] << '\n';
    return 0;
}
