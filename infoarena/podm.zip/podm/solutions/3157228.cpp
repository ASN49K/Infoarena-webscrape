#include <bits/stdc++.h>

using namespace std;
using int64 = long long;
const int N_MAX = 500;

int n; int64 input[2 + N_MAX];

const int64 myINF = 1e18;
int64 dp[1 + N_MAX][1 + N_MAX];
void initDP (void) {
   for (int i = 1; i <= n; i ++)
      for (int j = 1; j <= n; j ++)
         dp[i][j] = myINF;
}

int64 getDP (int left, int right) {
   if (dp[left][right] != myINF) return dp[left][right];
   if (left == right) return dp[left][right] = 0;
   if (left + 1 == right) return dp[left][right] = input[left - 1] * input[left] * input[right];

   for (int k = left; k < right; k ++)
      dp[left][right] = min (dp[left][right], getDP (left, k) + input[left - 1] * input[k] * input[right] + getDP (k + 1, right));
   return dp[left][right];
}
int main()
{
   ifstream cin ("podm.in");
   ofstream cout ("podm.out");

   cin >> n;
   for (int i = 0; i <= n; i ++) cin >> input[i];

   initDP ();
   cout << getDP (1, n);
    return 0;
}
