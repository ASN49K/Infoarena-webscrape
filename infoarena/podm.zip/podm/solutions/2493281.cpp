#include <cstdio>
#include <algorithm>
#include <climits>
using namespace std;
int n;
long long dp[505][505];
int d[505];

int main()
{
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);
    scanf("%d", &n);
    for(int i=0; i<=n; i++)
        scanf("%d", &d[i]);
    for(int adaug=1; adaug<n; adaug++)
        for(int i=1; i+adaug<=n; i++){
            ///poz (i;i+adaug)
            int j=i+adaug;
            long long vmin=LLONG_MAX;
            for(int k=i; k<=j-1; k++)
                vmin=min(dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j], vmin);
            dp[i][j]=vmin;
    }
    printf("%lld", dp[1][n]);

    return 0;
}
