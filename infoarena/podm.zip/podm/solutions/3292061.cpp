#include <iostream>
#include <vector>
#include <bits/stdc++.h>


using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{
	int n;
	
	fin >> n;
	vector<int> p(n + 1);
	for (int i = 0; i < n + 1; i++) {
		fin >> p[i];
	}

	vector<vector<int>> dp(n + 1, vector<int>(n + 1));
	vector<vector<int>> s(n + 1, vector<int>(n + 1));

	for (int i = 1; i <= n; i++) {
		dp[i][i] = s[i][i] = 0;
	}

	for (int l = 1; l <= n - 1; l++) {
		for (int i = 1; i <= n - l; i++) {
			int j = i + l;
			
			dp[i][j] = INT_MAX;
			for (int k = i; k <= j - 1; k++) {
				int q = dp[i][k] + dp[k + 1][j] + p[i - 1] * p[k] * p[j];
				if (q < dp[i][j]) {
					dp[i][j] = q;
					s[i][j] = k;
				}
			}
		}
	}

	fout << dp[1][n];

}