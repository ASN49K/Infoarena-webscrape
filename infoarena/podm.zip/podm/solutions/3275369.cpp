#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

#define cin fin
#define cout fout

int cost[501][501], dim[501]; // cost[i][j] = cost minim pentru a înmulți matricile de la i la j

int main() {
    int n;
    cin >> n;
    
    for (int i = 0; i <= n; i++) {
        cin >> dim[i]; // citim dimensiunile matricilor
    }

    // Inițializăm matricea de costuri
    for (int lungime = 2; lungime <= n; lungime++) { // lungimea secvenței de matrici
        for (int i = 1; i <= n - lungime + 1; i++) { // începutul secvenței
            int j = i + lungime - 1; // sfârșitul secvenței
            cost[i][j] = 1e9; // inițializare la un număr mare

            for (int k = i; k < j; k++) { // poziția unde împărțim produsul
                int aux = cost[i][k] + cost[k + 1][j] + dim[i - 1] * dim[k] * dim[j];
                if (aux < cost[i][j]) {
                    cost[i][j] = aux;
                }
            }
        }
    }

    cout << cost[1][n] << endl; // afișăm costul minim pentru a înmulți toate matricile

    return 0;
}
