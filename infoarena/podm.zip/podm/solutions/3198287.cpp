#include <iostream>
#include <fstream>
#define nl '\n'

using namespace std;
const long long INF = 1LL << 62;

ifstream f("podm.in");
ofstream g("podm.out");

int N;
short int D[501];
long long M[500][500];

void calcul()
{
    for (int d = 1; d < N; d++)
    {
        for (int i = N - d - 1; i >= 0; i--)
        {
            int j = i + d;
            M[i][j] = INF;
            for (int k = i; k < j; k++)
            {
                long long t = M[i][k] + M[k+1][j] + (long long)D[i] * D[k+1] * D[j+1];
                if (M[i][j] > t)
                    M[i][j] = t;
            }
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    f >> N;
    for (int i = 0; i <= N; i++)
        f >> D[i];
    calcul();
    g << M[0][N-1];
    f.close();
    g.close();
    return 0;
}
