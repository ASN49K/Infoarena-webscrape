#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int64_t INF = INT64_MAX;

const int MAXN = 510;
int64_t DP[MAXN][MAXN];
int64_t DIM[MAXN];
int N;
int main() {
	fin >> N;
	for (int i = 0; i <= N; i++) fin >> DIM[i];

	for (int i = 1; i < N; i++) {
		DP[i][i + 1] = DIM[i - 1] * DIM[i] * DIM[i + 1];
	}

	for (int len = 2; len < N; len++) {
		for (int i = 1; i + len <= N; i++) {
			int left = i;
			int right = i + len;
			int64_t mn = INF;
			for (int stop = left; stop < right; stop++) {
				int64_t cost = DP[left][stop] + DP[stop + 1][right] +
							   DIM[left - 1] * DIM[stop] * DIM[right];
				
				mn = min(mn, cost);
			}
			DP[left][right] = mn;
		}
	}

	fout << DP[1][N];

	// for (int i = 1; i <= N; i++) {
	// 	for (int j = 1; j <= N; j++) {
	// 		cout << DP[i][j] << " ";

	// 	}
	// 	cout << endl;
	// }

	return 0;
}