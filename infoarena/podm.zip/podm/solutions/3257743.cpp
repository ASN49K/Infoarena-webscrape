#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

#define INF (long long)10e16
#define NMAX 500
#define VMAX 1000000

int n;
long long dp[NMAX+1][NMAX+1];
long long a[NMAX+1];
int main()
{
    fin >> n;
    for(int i=1;i<=n+1;i++)
    {
        fin >> a[i];
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            dp[i][j]=INF;
            if(i==j)
            {
                dp[i][j]=0;
            }
        }
    }
    for(int i=1;i<=n-1;i++)
    {
        dp[i][i+1] = a[i] * a[i+1] * a[i+2];
    }
    for(int d=2;d<=n;d++)
    {
        for(int i=1;i+d<=n;i++)
        {
            for(int k=i;k<=i+d;k++)
            {
                dp[i][i+d] = min(dp[i][i+d],dp[i][k] + a[i] * a[k+1] * a[i+d+1] + dp[k+1][i+d]);
            }
        }
    }
    fout << dp[1][n];

}
