#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long int n, valori[503], prodmatrici[503][503];
int i, j, ln, k;

int main()
{
    fin >> n;
    for(i = 0; i <= n; i++)
        fin >> valori[i];
    for(i = 1; i <= n; ++i)
        prodmatrici[i][i] = 0;
    for(ln = 2; ln <= n; ++ln)
        for(i = 1; i <= n - ln + 1; ++i) {
            j = i + ln - 1;
            prodmatrici[i][j] = prodmatrici[i][i] + prodmatrici[i + 1][j] + valori[i - 1] * valori[j] * valori[i];
            for(k = i; k <= j - 1; ++k) {
                prodmatrici[i][j] = min(prodmatrici[i][j], prodmatrici[i][k] + prodmatrici[k + 1][j] + valori[i - 1] * valori[k] * valori[j]);
            }
        }
    fout<<prodmatrici[1][n];
    return 0;
}
