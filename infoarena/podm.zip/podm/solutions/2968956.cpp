#include <fstream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <queue>

#define ll long long
#define pb push_back
#define bg begin()
#define ed end()
#define cl clear()
#define pi pair<int, int>

///#define int ll

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int MOD = 1e9;
const char nl = '\n';
const int NMAX = 500;
const ll INF = 1e18;

ll v[NMAX + 5], dp[NMAX + 5][NMAX + 5], n;

void solve(){
    for(int len = 2; len <= n; ++len){
        for(int i = 1, j = len; j <= n; i++, j ++){
            dp[i][j] = INF;
            for(int k = i; k < j; ++k){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
            }
        }
    }
    out << dp[1][n] << nl;
}

int main(){
    in >> n;
    for(int i = 0; i <= n; ++i)
        in >> v[i];
    solve();
    return 0;
}
