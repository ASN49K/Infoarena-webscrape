#include<bits/stdc++.h>
using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

long long ma[501][501],d[501];
int n;

int main()
{
    f>>n;
    for(int i=0;i<=n;++i)
        f>>d[i];
    for(int i=n-1;i>=0;--i)
    {
        for(int j=i+1;j<=n;++j)
        {
            ma[i][j]=LONG_LONG_MAX;
            for(int k=i;k<j;++k)
                {
                    ma[i][j]=min(ma[i][j],ma[i][k]+ma[k+1][j]+d[i-1]*d[k]*d[j]);
                }
        }
    }
    g<<ma[1][n];
}
