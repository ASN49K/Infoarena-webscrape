#include <fstream>
#define NMAX 504

using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");

int n, dim[NMAX], cuts[NMAX][NMAX];
unsigned long long int dp[NMAX][NMAX];

void citire();
void rezolvare();
void para(int i, int j);


int main()
{
    citire();
    rezolvare();
    fout << dp[1][n];
    //para(1, n);
    return 0;
}

void citire()
{
    fin >> n;
    for (int i = 1; i <= n + 1; i++)
        fin >> dim[i];
}

void rezolvare()
{
    for (int lg = 1; lg <= n; lg++)
    {
        for (int i = 1; i <= n - lg + 1; i++)
        {
            int j = i + lg - 1;
            if (i == j)
            {
                dp[i][j] = 0;
                continue;
            }
            int k = i;
            dp[i][j] = dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1];
            cuts[i][j] = i;
            for (int k = i + 1; k < j; k++)
            {
                if (dp[i][j] > dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1])
                {
                    dp[i][j] = dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1];
                    cuts[i][j] = k;
                }
            }
        }
    }
}

void para(int i, int j)
{
    if (i == j)
        fout << "matrice" << i;
    else
    {
        fout << '(';
        para(i, cuts[i][j]);
        fout << '*';
        para(cuts[i][j] + 1, j);
        fout << ')';
    }
}
