#include <bits/stdc++.h>
using namespace std;

const unsigned long long  nmax = 505;
const unsigned long long  INF = 100000000000000000LL;
ifstream fin("podm.in");
ofstream fout("podm.out");

unsigned long long  N;
unsigned long long  dim[nmax];
unsigned long long  best_scalar[nmax][nmax];

int  main() {

    fin >> N;

    for(unsigned long long  i = 0; i <= N; ++i) {
        fin >> dim[i];
    }

    for(unsigned long long  i = 1; i <= N; ++i) {
        best_scalar[i][i] = 0;
    }
    for(unsigned long long  dist = 1; dist <= N; ++dist)
        for(unsigned long long  i = 1; i <= N - dist; ++i) {
            unsigned long long  j = i + dist;
            best_scalar[i][j] = INF;
            for(unsigned long long  k = i; k <= j - 1; ++k)
                best_scalar[i][j] = min(best_scalar[i][j],
                                        best_scalar[i][k] +
                                        best_scalar[k + 1][j]
                                        + dim[i - 1] * dim[k]
                                        * dim[j]);
        }

    fout << best_scalar[1][N] << '\n';

    return 0;
}
