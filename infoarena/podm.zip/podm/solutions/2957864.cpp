#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");



unsigned long long n, v[501];
unsigned long long dp[501][501];

int main(){
    fin >> n;
    for(int i=0; i<=n; i++){
        fin >> v[i];
    }

    for(int i=1; i<n; i++){
        dp[i][i+1]=v[i-1]*v[i]*v[i+1];
    }

    for(int j=2; j<n; j++){
        for(int i=1; i<=n-j; i++){
            dp[i][i+j]=dp[i][i]+dp[i+1][i+j]+v[i-1]*v[i]*v[i+j];
            for(int k=i+1; k<i+j; k++){
                dp[i][i+j]=min(dp[i][i+j], dp[i][k]+dp[k+1][i+j]+v[i-1]*v[k]*v[i+j]);
            }
        }
    }

    fout << dp[1][n];
}

