#include <iostream>
#include <fstream>
#include <climits>
#define nmax 505
using namespace std;
unsigned long long n,mx,v[2*nmax],dp[2*nmax][2*nmax];
int main()
{
    ifstream f ("podm.in");
    ofstream g ("podm.out");
    f>>n;
    for (int i=0; i<=n; i++)
        f>>v[i];
    for (int d=1; d<n; d++)
    {
        for (int left=0; left<n-1; left++)
        {
            int right=left+d+1;
            dp[left][right]=INT_MAX;
            for (int mid=left+1; mid<right; mid++)
            {
                dp[left][right]=min(dp[left][right],dp[left][mid]+dp[mid][right]+v[left]*v[mid]*v[right]);
            }
        }
    }
    g<<dp[0][n];
}
