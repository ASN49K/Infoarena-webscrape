#include <fstream>

using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");

unsigned long long int n, i, j, d[510], C[510][510], mnm, k, h;
int main()
{
    fin>>n;
    for (i=0; i<=n; i++)
        fin>>d[i];
    for (i=1; i<n; i++)
        C[i][i+1]=d[i-1]*d[i]*d[i+1];
    for (h=3; h<=n; h++)
    {
        for (i=1; i<=n-h+1; i++)
        {
            j=i+h-1;
            mnm=1000000000000000000;
            for (k=i; k<=j-1; k++)
                if (C[i][k]+C[k+1][j]+d[i-1]*d[k]*d[j]<mnm)
                    mnm=C[i][k]+C[k+1][j]+d[i-1]*d[k]*d[j];
            C[i][j]=mnm;
            C[j][i]=k;
        }
    }
    fout<<C[1][n]<<'\n';
    return 0;
}
