#include <iostream>
#include <fstream>
#define MAX 505
#define inf (1 << 30)

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;

pair <int, int> mat[MAX];

int dp[MAX][MAX];

int main()
{
    fin >> n;
    int ant;
    fin >> ant;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        mat[i].first = ant;
        mat[i].second = x;
        ant = x;
    }
    int l;
    for (l = 1; l < n; l++)
    {
        for (int i = 1; i <= n - l; i++)
        {
            int j = i + l;
            int minim  = inf;
            for (int k = i; k < j; k++)
            {
                int val = dp[i][k] + dp[k + 1][j] + (mat[i].first * mat[k].second * mat[j].second);
                if (val < minim)
                    minim = val;
            }
            dp[i][j] = minim;
        }
    }
    fout << dp[1][n];
    return 0;
}
