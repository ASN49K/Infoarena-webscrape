#include <fstream>
#include <climits>
#include <algorithm>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int n;
long long dp[505][505], a[505];
int main()
{
    f >> n;
    for (int i = 0; i <= n; ++i) f >> a[i];
    for (int i = 1; i <= n - 1; ++i) dp[i][i + 1] = a[i - 1] * a[i] * a[i + 1];
    for (int d = 2; d < n; ++d) {
        for (int i = 1; i + d <= n; ++i) {
            int j = i + d;
            dp[i][j] = INT_MAX;
            for (int k = i; k <= j - 1; ++k) dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
        }
    }
    g << dp[1][n] << '\n';
    return 0;
}
