#include <stdio.h>
#define NMAX 502
#define LL long long
short int N,d[NMAX];
LL T[NMAX][NMAX];
int main()
{
    int i,j,k;
    freopen("podm.in","r",stdin);
    freopen("podm.out","w",stdout);
    scanf("%hd",&N);
    for (i=0;i<=N;++i) scanf("%hd",&d[i]);
    for (i=N-1;i;--i)
        for (j=i+1;j<=N;++j)
        {
            LL min=(LL)d[i-1]*d[i]*d[j]+T[i+1][j],ret;
            for (k=i+1;k<j;++k)
                if ((ret=T[i][k]+T[k+1][j]+(LL)d[i-1]*d[k]*d[j]) < min) min=ret;
            T[i][j]=min;
        }
    printf("%lld",T[1][N]);
    return 0;
}