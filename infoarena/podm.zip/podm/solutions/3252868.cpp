#include <fstream>
using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");
int n,i,j,k,v[502];
long long dp[501][501];
int main()
{
    fin>>n;
    for (i=1; i<=n+1; i++)
        fin>>v[i];
    for (i=n; i>0; i--)
    {
        dp[i][i]=0;
        for (j=i+1; j<=n; j++)
        {
            dp[i][j]=5e14;
            for (k=i; k<j; k++)
                dp[i][j]=min (dp[i][j],dp[i][k]+dp[k+1][j]+1ll*v[i]*v[k+1]*v[j+1]);
        }
    }
    fout<<dp[1][n];
    return 0;
}
