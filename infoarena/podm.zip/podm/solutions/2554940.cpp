#include <fstream>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

long long a[505][505],d[505];

int main()
{
    int n,i,j,k;
    cin>>n;
    for(i=0;i<=n;i++)
        cin>>d[i];
    for(j=1;j<=n-1;j++)
        for(i=1;i<=n-j;i++)
        {
            long long minim=2e17;
            for(k=1;k<=j;k++)
                minim=min(a[i][i+j-k]+a[i+j-k+1][i+j]+d[i-1]*d[i+j-k]*d[i+j],minim);
            a[i][i+j]=minim;
        }
    cout<<a[1][n];
    return 0;
}
