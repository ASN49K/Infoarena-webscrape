#include <bits/stdc++.h>
using namespace std;

long long dp[505][505];
long long v[505];

int main() {
	ifstream cin("podm.in");
	ofstream cout("podm.out");
	
	int n;
	cin >> n;
	
	for(int i = 0; i <= n; i++)
		cin >> v[i];
	
	// dp[i][j] = numarul minim de inmultiri ale matricilor din [i, j]
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++)
			dp[i][j] = 1e18;
		dp[i][i] = 0;
	}
	
	for(int len = 2; len <= n; len++)
		for(int i = 1; i + len - 1 <= n; i++) {
			int j = i + len - 1;
			for(int k = i; k < j; k++) // incercam sa impartim [i, j] in [i, k] si [k+1, j]
				dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + v[i-1] * v[k] * v[j]);
		}
		
	cout << dp[1][n] << "\n";
	
	return 0;
}
