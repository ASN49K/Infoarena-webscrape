#include <bits/stdc++.h>
#define INF 100000000000000000
using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

long long n,v[505],dp[505][505],d,i,k;
int main()
{
    fin>>n;
    for (i=0;i<=n;i++)
    {
        fin>>v[i];
    }
    for (i=1;i<=n;i++)
    {
        dp[i][i]=0;
    }
    for (i=1;i<=n-1;i++)
    {
        dp[i][i+1]=v[i-1]*v[i]*v[i+1];
    }
    for (d=2;d<n;d++)
    {
        for (i=1;i<=n-d;i++)
        {
            dp[i][i+d]=INF;
            for (k=i;k<i+d;k++)
            {
                dp[i][i+d]=min(dp[i][i+d],dp[i][k]+dp[k+1][i+d]+v[i-1]*v[k]*v[i+d]);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
