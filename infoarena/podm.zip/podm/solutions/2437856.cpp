#include <fstream>
#define NMAX 510

std::ifstream fin("podm.in");
std::ofstream fout("podm.out");

int n;
int64_t v[NMAX];
int64_t dp[NMAX][NMAX];

inline int64_t min(int64_t x, int64_t y) {
    return x < y ? x : y;
}

int main() {
    fin >> n;
    for (int i = 0; i <= n; i++)
        fin >> v[i];

    for (int i = n - 1; i >= 1; i--)
        for (int j = i + 1; j <= n; j++) {
            dp[i][j] = 1e18;
            for (int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
        }
    fout << dp[1][n] << '\n';

    fout.close();
    return 0;
}
