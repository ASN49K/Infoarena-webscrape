/*
https://infoarena.ro/problema/podm
*/
#include <fstream>

using namespace std;

const int N = 500;
const long long INF = 1LL << 60;

int dim[N+1];
long long nr[N+1][N+1];

int main()
{
    ifstream in("podm.in");
    ofstream out("podm.out");
    int n;
    in >> n;
    for (int i = 0; i <= n; i++)
    {
        in >> dim[i];
    }
    for (int i = n; i >= 1; i--)
    {
        nr[i][i] = 0;
        for (int j = i + 1; j <= n; j++)
        {
            nr[i][j] = INF;
            for (int k = i; k < j; k++)
            {
                nr[i][j] = min(nr[i][j], nr[i][k] + nr[k+1][j]+
                                    dim[i-1] * dim[k] * dim[j]);
            }
        }
    }
    out << nr[1][n] << "\n";
    in.close();
    out.close();
    return 0;
}
