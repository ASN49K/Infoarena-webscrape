#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long a[500][500];
int n,d[501];
long long mini;
int main()
{
    fin>>n;
    for(int i=0;i<=n;i++)
        fin>>d[i];
    for(int i=0;i<n-1;i++)
        a[i][i+1]=d[i]*d[i+1]*d[i+2];
    for(int j=2;j<n;j++)
         for(int i=0;i<n-j;i++)
    {
        mini=(a[i][i]+a[i+1][i+j])+d[i]*d[i+1]*d[i+j+1];
        if(mini<0) mini=999999912722012560;
            for(    int k=i+1;k<i+j;k++)
            {
                long long aux=(a[i][k]+a[k+1][i+j])+d[i]*d[k+1]*d[i+j+1];
               if(mini>aux and aux>0)
                    mini=aux;
            }
    //    fout<<mini<<" ";
        a[i][i+j]=mini;
    }
 //   fout<<endl;
  //  for(int i=1;i<=n;i++)
  //  {
  //      for(int j=1;j<=n;j++)
  //          fout<<a[i][j]<<" ";
  //      fout<<endl;
  //  }
    fout<<a[0][n-1];
    return 0;
}
