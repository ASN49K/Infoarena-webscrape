#include <stdio.h>
#define inf 100000000000000000LL
#define dim 510
#define nmax 500
using namespace std;
FILE *fin=fopen("podm.in","r");
FILE *fout=fopen("podm.out","w");
char buffer[dim];
long long n,d[nmax+5],dp[nmax+5][nmax+5],poz;
void read(long long &x)
{
    x=0;
    while(buffer[poz]<'0' || buffer[poz]>'9')
        if(++poz==dim)
            fread(buffer,1,dim,fin),poz=0;
    while(buffer[poz]>='0' && buffer[poz]<='9')
    {
        x=x*10+buffer[poz]-'0';
        if(++poz==dim)
            fread(buffer,1,dim,fin),poz=0;
    }
}
long long minv(long long x, long long y)
{
    return x<y?x:y;
}
int main()
{
    read(n);
    int j;
    for(int i=0;i<=n;i++)
        read(d[i]);
    for(int i=1;i<=n-1;i++)
        dp[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(int l=2;l<=n-1;l++)
        for(int i=1;i<=n-l;i++)
        {
            j=i+l;
            dp[i][j]=inf;
            for(int k=i;k<=j-1;k++)
                dp[i][j]=minv(dp[i][j],dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
        }
    fprintf(fout,"%lld\n",dp[1][n]);
    return 0;
}
