#include <iostream>
#include <fstream>
#include <algorithm>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
int d[514];
int dp[514][514];
void read(){
	fin >> n;
	for(int i = 0; i <= n; ++i){
		fin >> d[i];
	}
}

int calculassion(int i, int j){
	int mini = INT_MAX;
	for(int k = i; k < j; ++k){
		mini = min(mini, dp[i][k] + dp[k+1][j] + d[i]*d[k+1]*d[j+1]);
	}
	return mini;
}

void diag(int i, int j){
	while(i < n && j < n){
		dp[i][j] = calculassion(i, j);
		i++;j++;
	}
}

void solve(){
	for(int i = 1; i < n; ++i){
		diag(0, i);
	}
}

int main(){
	// ios_base::sync_with_stdio(false);
	read();
	solve();
	fout << dp[0][n-1];
	return 0;
}