#include <fstream>

using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int n,v[505];
long long dp[505][505];
int main()
{
    cin>>n;
    for(int i=1;i<=n+1;i++)
        cin>>v[i];
    for(int l=2;l<=n;l++)
    {
        for(int i=1;i+l-1<=n;i++)
        {
            int j=i+l-1;
            dp[i][j]=1e18;
            for(int k=i;k<j;k++)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+v[i]*v[k+1]*v[j+1]);
        }
    }
    cout<<dp[1][n];
    return 0;
}
///dp[i][j]=costul minim pentru a elimina toate elementele din secvența de la i la j,
