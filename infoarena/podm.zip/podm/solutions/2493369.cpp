#include <iostream>
#include <fstream>
#include <algorithm>
#include <climits>

using namespace std;

long long dim[5005], n;

long long dp[5000][5000];

void dinamica(){
    for (long long i = 1; i <= n; ++i) {
        dp[i][i] = 0;
    }
    for (long long i = 1; i <= n - 1; ++i) {
        dp[i][i + 1] = dim[i-1] * dim[i] * dim[i + 1];
    }
    for (long long d = 1; d < n; ++d) {
        for (long long i = 1; i <= n - d; ++i) {
            long long mini = LONG_LONG_MAX;
            for (long long k = i; k < i + d; ++k) {
                mini = min(mini, dp[i][k] + dp[k + 1][i + d] + dim[i - 1] * dim[k] * dim[i + d]);
            }
            dp[i][i + d] = mini;
        }
    }
}

int main() {
    ifstream f("podm.in");
    ofstream g("podm.out");
    f>>n;
    for (long long i = 0; i < n + 1; ++i) {
        f>>dim[i];
    }
    dinamica();
    g<<dp[1][n];
    return 0;
}