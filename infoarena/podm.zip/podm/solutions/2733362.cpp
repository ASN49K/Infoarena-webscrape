#include <bits/stdc++.h>
#define inf 1000000000000000000
using namespace std;
ifstream fin ("podm.in");
ofstream fout("podm.out");
long long v[502],dp[502][502];

int main()
{
    long long n,lg,i,k,st,dr;
    fin>>n;
    for (i=1;i<=n+1;i++)
        fin>>v[i];
    for (lg=2;lg<=n;lg++)
        for (st=1;st<=n-lg+1;st++)
    {
        dr=st+lg-1;
        dp[st][dr]=inf;
        for (k=st;k<dr;++k)
            dp[st][dr]=min(dp[st][dr],dp[st][k]+dp[k+1][dr]+v[st]*v[k+1]*v[dr+1]);
    }
    fout<<dp[1][n]<<'\n';
    return 0;
}

