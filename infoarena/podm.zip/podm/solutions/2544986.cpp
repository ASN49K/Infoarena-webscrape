#include <fstream>

using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

int main()
{
    int n, i, j, d, v[505], dp[505][505];

    fin >> n >> v[0];
    for ( i = 1 ; i <= n ; i++ ) fin >> v[i];

    for ( i = 1 ; i <= n ; i++ )
        for ( j = i ; j <= n ; j++ )
            dp[i][j] = 2147483647;

    for ( i = 1 ; i <= n ; i++ ) dp[i][i] = 0;
    for ( i = 1 ; i < n ; i++ ) dp[i][i+1] = v[i-1] * v[i] * v[i+1];

    for ( d = 2 ; d < n ; d++ )
        for ( i = 1 ; i <= n - d ; i++ )
            for ( j = i ; j < i + d ; j++ )
                dp[i][i+d] = min ( dp[i][i+d], dp[i][j] + dp[j+1][i+d] + v[i-1] * v[j] * v[i+d] );

    fout << dp[1][n];

    return 0;
}
