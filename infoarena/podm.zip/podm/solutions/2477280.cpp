#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
const int NMAX=504;

long long n,v[NMAX];
long long dp[NMAX][NMAX];

int main(){
    fin>>n;
    ++n;
    for(int i=1;i<=n;++i)
        fin>>v[i];
    for(int i=2;i<n;++i)
        dp[i-1][i+1]=v[i-1]*v[i]*v[i+1];
    for(int diff=2;diff<=n;++diff){
        for(int l=1, r=diff+1; r<=n; ++l, ++r){
            dp[l][r]=1e18;
            for(int k=l+1;k<r;++k){
                dp[l][r]=min(dp[l][r], dp[l][k]+dp[k][r] + v[l]*v[k]*v[r]);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
