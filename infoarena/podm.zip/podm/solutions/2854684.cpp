#include <fstream>
#include <deque>
#include <vector>
#include <iomanip>
#include <queue>
#include <algorithm>
#include <cmath>
#include <climits>

#define MOD 104659

using namespace std ;

ifstream cin ("podm.in") ;
ofstream cout ("podm.out") ;

int n ;

long long v[509] ;

void remov(int poz)
{
    for(int f = poz ; f <= n + 1 ; f ++)
        v[f] = v[f + 1] ;

    n -- ;
}

int main()
{
    cin >> n ;

    for(int f = 1 ; f <= n + 1 ; f ++)
        cin >> v[f] ;

    long long s = 0, auxn = n ;

    for(int f = 1 ; f <= auxn ; f ++)
    {
        int pozmax = 2 ;

        for(int f = 2 ; f <= n ; f ++)
            if(v[f] > v[pozmax])pozmax = v[f] ;

        s += v[pozmax] * v[pozmax - 1] * v[pozmax + 1] ;

        remov(pozmax) ;
    }

    cout << s ;

    return 0 ;
}
/*
5
2 4 3 4 2 3
*/
