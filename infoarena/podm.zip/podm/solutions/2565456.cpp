#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n, i, j, k, l, d[510][510], v[510];

int main(){
    fin>>n;
    for(i=1; i<=n+1; i++){
        fin>>v[i];
    }
    if(n==1){
        fout<<0;
        return 0;
    }
    for(l=2; l<=n; l++){
        for(i=1; i+l<=n+1; i++){
            j=i+l;
            d[i][j]=1000000000;
            for(k=i+1; k<j; k++){
                if(d[i][k]+d[k][j]+v[i]*v[j]*v[k]<d[i][j]){
                    d[i][j]=d[i][k]+d[k][j]+v[i]*v[j]*v[k];
                }
            }
        }
    }
    fout<<d[1][n+1];
}

