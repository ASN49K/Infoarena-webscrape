#include <fstream>
#define INF 1e18
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int d[505],n;
long long dp[505][505];
int main()
{
    cin>>n;
    for(int i=1;i<=n+1;i++)
        cin>>d[i];
    for(int i=1;i<n;i++)
        dp[i][i+1]=1ll*d[i]*d[i+1]*d[i+2];
    for(int l=3;l<=n;l++){
        for(int i=1;i<=n-l+1;i++){
            int j=i+l-1;
            dp[i][j]=INF;
            for(int k=i;k<=j;k++){
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+1LL*d[i]*d[k+1]*d[j+1]);
            }
        }
    }
    cout<<dp[1][n];
    return 0;
}
