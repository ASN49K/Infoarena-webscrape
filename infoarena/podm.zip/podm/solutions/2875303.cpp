#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
long long dp[505][505];
long long d[505];

int main()
{
    fin >> n;
    for(int i = 0; i <= n; ++i)
        fin >> d[i];
    for(int i = 1; i <= n + 1; ++i)
        dp[i][i] = 0;
    for(int dif = 1; dif <= n - 1; ++dif)
        for(int i = 1; i <= n; ++i)
        {
            int j = i + dif;
            dp[i][j] = dp[i][i]+ dp[i + i][j] + d[i - 1] * d[i] * d[j];
            for(int k = i + 1; k < j; ++k)
                dp[i][j] = min(dp[i][j], dp[i][k]+ dp[k + i][j] + d[i - 1] * d[k] * d[j]);
        }
    fout << dp[1][n];
    return 0;
}
