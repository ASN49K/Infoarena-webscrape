#include <bits/stdc++.h>
using namespace std;
const int nmx = 505;
#define ll long long
#if 1
ifstream fin("podm.in");
ofstream fout("podm.out");
#define cin fin
#define cout fout
#endif // 0
const ll inf = 5e14+1;
ll dp[nmx][nmx]; // minimum price in interval [i,j]
int main(){
    int n;
    cin >> n;
    n++;
    vector<int> a(n+1);
    for(int i=1;i<=n;i++){
        cin >> a[i];
    }
    for(int i=0;i<nmx;i++)
        for(int j=0;j<nmx;j++)
            dp[i][j] = inf;

    for(int i=0;i<nmx-1;i++)
        dp[i][i+1] = 0;

    for(int len=3;len<=n;len++){
        for(int j=1;j<=n-len+1;j++){
            for(int k=2;k<len;k++){
                dp[j][j+len-1] = min(dp[j][j+len-1],dp[j][j+k-1]+dp[j+k-1][j+len-1]+a[j]*a[j+k-1]*a[j+len-1]);
            }
        }
    }
    cout << dp[1][n];
}
