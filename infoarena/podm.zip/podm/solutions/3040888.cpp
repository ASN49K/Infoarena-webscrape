#include <fstream>
#include <string>
#include <algorithm>
#include <vector>
#include <string>
#include <unordered_map>
#define mod 1000000007
#define ll long long
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
ll n, v[505], dp[505][505];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (int i = 0; i <= n; i++)
        cin >> v[i];
    for (int l = 2; l <= n; l++)
    {
        for (int i = 1; i <= n; i++)
        {
            int j = i + l - 1;
            dp[i][j] = 2e18;
            for (int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + v[i - 1] * v[k] * v[j]);
        }
    }
    cout << dp[1][n];
    return 0;
}