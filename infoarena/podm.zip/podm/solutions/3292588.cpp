#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");
const long long INF = 1e18 + 7;
long long n, m, i, j, k, a[503], d[503][503];

int main() {
    fin >> n;
    for(i = 1; i <= n + 1; i++) fin >> a[i];
    
    for(i = 1; i <= n + 1; i++) {
	for(j = i; j <= n + 1; j++) d[i][j] = INF;
    }    
    for(i = 1; i <= n; i++) d[i][i + 1] = 0;

    for(i = 3; i <= n + 1; i++) {
        for(j = i - 2; j >= 1; j--) {
            for(k = j + 1; k < i; k++) {
                d[j][i] = min(d[j][i], d[j][k] + d[k][i] + a[j] * a[k] * a[i]);
            }
        }
    }
    fout << d[1][n + 1];

    return 0;
}
