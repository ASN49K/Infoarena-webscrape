#include <iostream>
#include<fstream>
using namespace std;

const long long INF=1LL<<62;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
short int D[501];
long long m[500][500];

void calcul()
{
    for(int d=1; d<n; d++)
        for(int i=n-d-1; i>=0; i--)
        {
            int j=i+d;
            m[i][j]=INF;
            for(int k=i; k<j; k++)
            {
                long long t=m[i][k]+m[k+1][j]+(long long)D[i]*D[k+1]*D[j+1];
                if(m[i][j]>t)
                    m[i][j]=t;
            }
        }
}

int main()
{
    fin>>n;
    for(int i=0; i<=n; i++)
        fin>>D[i];
    calcul();
    fout<<m[0][n-1];

    fin.close();
    fout.close();
    return 0;
}
