#include <iostream>
#include <fstream>
using namespace std;
ifstream f ("podm.in");
ofstream g ("podm.out");
long long n;
long long dim[502],dp[502][502];
int main()
{
    f >> n;
    for(long long i = 1; i<=n+1; i++)
        f >> dim[i];
    long long dif = 1,i,j;

    while(dif<=n-1)
    {
        i = 1;
        j = i+dif;
        while(j<=n)
        {
            for(long long k = i; k<=j-1; k++)
            {
                if(dp[i][j]==0)
                {
                    dp[i][j] = dp[i][k] + dp[k+1][j] + (dim[k+1]*dim[i]*dim[j+1]);
                }
                else
                {
                    dp[i][j] = min(dp[i][j],dp[i][k] + dp[k+1][j] + (dim[k+1]*dim[i]*dim[j+1]));
                }
            }
            i++;
            j++;
        }
        dif++;
    }
    g<<dp[1][n];
}
