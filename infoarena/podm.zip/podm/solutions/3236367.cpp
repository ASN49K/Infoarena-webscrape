#include<bits/stdc++.h>

std::ifstream fin("podm.in");
std::ofstream fout("podm.out");

int n, v[505], dp[505][505]; //dp[i][j] = costul minim pentru a transforma secventa (i, j)

int main(){
    fin >> n;

    ++n;

    for(int i = 1; i <= n; ++i)
        fin >> v[i];

    for(int i = 1; i < n; ++i)
        dp[i][i + 1] = 0;

    for(int len = 3; len <= n; ++len)
    for(int i = 1; i + len - 1 <= n; ++i){
        int j = i + len - 1;
        dp[i][j] = 1e9;
        for(int k = i + 1; k < j; ++k)
            dp[i][j] = std::min(dp[i][j], dp[i][k] + dp[k][j] + v[i] * v[j] * v[k]);
    }

    fout << dp[1][n];
}
