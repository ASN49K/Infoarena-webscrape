#include <bits/stdc++.h>
#define ll long long
#define cin fin
#define cout fout
#define right left + add
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
ll v[550], minCost[550][550];

int main() {
    int n;

    cin >> n;
    for (int i = 0; i <= n; i++)
        cin >> v[i];

    for (int i = 1; i < n; i++)
        for (int add = 1; add <= n - i; add++)
            minCost[i][i + add] = LLONG_MAX;

    for (int i = 1; i < n; i++)
        minCost[i][i + 1] = v[i - 1] * v[i] * v[i + 1];

    for (int add = 2; add < n; add++)
        for (int left = 1; left <= n - add; left++)
            for (int j = left + 1; j <= left + add; j++)
                minCost[left][right] = min(minCost[left][right], minCost[left][j - 1] + minCost[j][right] + v[left - 1] * v[right] * v[j - 1]);

    cout << minCost[1][n];

    return 0;
}
