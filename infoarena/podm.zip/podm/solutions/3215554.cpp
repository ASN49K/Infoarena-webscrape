
#include <fstream>
#include <vector>
#include <climits>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int n;
vector<long long> d;
long long dp[510][510];
int main()
{
    cin>>n;
    d.resize(n+1);
    for(int i=0;i<=n;i++)
        cin>>d[i];
    for(int i=n;i>=1;i--)
    {
        dp[i][i]=0;
        for(int j=i+1;j<=n;j++)
        {
           dp[i][j]=LLONG_MAX;
           for(int k=i;k<j;k++)
           {
             long long new_cost=dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j];
             dp[i][j]=min(dp[i][j],new_cost);
           }
        }
    }
    cout<<dp[1][n];
    return 0;
}
