#include<bits/stdc++.h>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n,i,j,ne,h,v[510],st[510],dr[510];
long long d[510][510];
int main()
{
    fin>>n;
    for(i=1;i<=n+1;i++) fin>>v[i];
    for(i=1;i<=n;i++) st[i]=v[i],dr[i]=v[i+1];
    for(i=1;i<n;i++)
        for(j=1;j+i<=n;j++)
        {
            ne=j+i;d[j][ne]=1000000000000000000;
            for(h=1;h<=i;h++)
                d[j][ne]=min(d[j][ne],d[j][j+h-1]+d[j+h][ne]+1ll*st[j]*st[j+h]*dr[ne]);
        }
    fout<<d[1][n];
    return 0;
}
