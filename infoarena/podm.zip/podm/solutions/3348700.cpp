#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMAX = 5e2;

long long int dp[NMAX][NMAX], dim[NMAX];

int main(){

    int n = 0;
    fin >> n;
    for (int i = 0; i < NMAX; i++) {
        for (int j = 0; j < NMAX; j++) {
            dp[i][j] = 1LL * 1e8;
        }
    }

    for (int i = 0; i < n + 1; i++) {
        fin >> dim[i];
        dp[i][i] = 0;
    }


    /*
        dp[i][j] = nr minim de operatii de a inmulti matricele i, i + 1, ..., j
        dp[i][j] = min(dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j])
    */

    for (int len = 2; len <= n; len++) {
        for (int i = 0; i + len - 1 <= n; i++) {
            int j = i + len - 1;
            for (int k = i; k < j; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + dim[i] * dim[k + 1] * dim[j + 1]);
            }
            //cout << "nr minim de operatii pt a paranteza corect matricele [" << i << ", " << j << "] este: " << dp[i][j] << "\n";
        }
    }

    fout << dp[0][n - 1];
    return 0;
}
