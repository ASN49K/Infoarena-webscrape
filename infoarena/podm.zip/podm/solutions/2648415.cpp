#include <climits>
#include <fstream>

using namespace std;

int dim[1024];
int costMinim[1024][1024];

int main() {
    ifstream in("podm.in");

    int n;
    in >> n;

    for (int i = 0; i <= n; ++i) {
        in >> dim[i];
    }

    // Costul produsul format dintr-o singură matrice
    for (int i = 1; i <= n; ++i) {
        costMinim[i][i] = 0;
    }

    // Costul produsului a două matrici adiacente
    for (int i = 1; i <= n; ++i) {
        costMinim[i][i + 1] = dim[i - 1] * dim[i] * dim[i + 1];
    }

    /// Costul unui produs de lungime l
    for (int l = 2; l < n; ++l) {
        for (int i = 1; i <= n - l; ++i) {
            int j = i + l;
            int valMinim = INT_MAX;
            for (int k = i; k < j; ++k) {
                int val = costMinim[i][k] + costMinim[k + 1][j] + dim[i - 1] * dim[k] * dim[j];
                valMinim = min(valMinim, val);
            }
            costMinim[i][j] = valMinim;
        }
    }

    ofstream out("podm.out");
    out << costMinim[1][n] << '\n';
}
