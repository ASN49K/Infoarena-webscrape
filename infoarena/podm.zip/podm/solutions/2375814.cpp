#include <iostream>
#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int NMAX = 5 * 1e2;

long long n;
long long d[1 + NMAX];
long long cmin[1 + NMAX][1 + NMAX];

int main()
{
  in >> n;

  for(int i = 0; i <= n; i++)
    in >> d[i];

  for(int i = 1; i < n; i++)
    cmin[i][i + 1] = d[i - 1] * d[i] * d[i + 1];

  for(int lg = 2; lg <= n - 1; lg++) {
    for(int i = 1; i <= n - lg; i++) {
      int j = i + lg;

      cmin[i][j] = cmin[i][i] + cmin[i + 1][j] + d[i - 1] * d[i] * d[j];

      for(int k = i + 1; k <= j - 1; k++)
        cmin[i][j] = min(cmin[i][j], cmin[i][k] + cmin[k + 1][j] + d[i - 1] * d[k] * d[j]);

    }
  }

  out << cmin[1][n] << '\n';

  in.close();
  out.close();

  return 0;
}
