#include <bits/stdc++.h>
using namespace std;

ifstream fin ("podm.in");
ofstream fout("podm.out");

#define cin  fin
#define cout fout

#define Nmax 510

int n;
int d[Nmax];
long long dp[Nmax][Nmax];

void read(){
    cin >> n;
    for(int i=0; i<=n; i++) {
        cin >> d[i];
    }
}

void solve() {

    for(int i = 1; i < n; i++) {
        dp[i][i+1] = d[i-1] * d[i] * d[i+1];
    }

    for(int k = 2; k < n; k++) {
        for(int i = 1; i <= n - k; i++) {
            dp[i][i+k] = LONG_MAX;
            for(int j=i; j < i+k; j++) {
                dp[i][i+k] = min(dp[i][i+k], dp[i][j] + dp[j+1][i+k] + d[i-1] * d[j] * d[i+k]);
            }
        }
    }

    /*
    for(int i=1; i<=n; i++) {
        for(int j=1; j<=n; j++)
        {
            cout << dp[i][j] << " ";
        }
        cout << endl;
    }
    */

    cout << dp[1][n];
}

int main()
{
    read();
    solve();
}
