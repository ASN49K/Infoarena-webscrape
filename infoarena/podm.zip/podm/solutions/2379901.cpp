#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMAX = 502;

int mat[NMAX][NMAX];
int N;
int x, y;
struct dimensiuni
{
    int l, c;
}D[NMAX];
void Read()
{
    fin >> N;
    fin >> x >> y;

    D[1].l = x;
    D[1].c = y;

    for(int i = 2; i <= N ; ++i)
    {
        fin >> x;

        D[i].c = x;
        D[i].l = D[i-1].c;
    }

    fin.close();
}

void Do()
{
    for (int i = 1; i <= N; ++i)
        mat[i][i+1] = D[i].l * D[i].c * D[i + 1].c;

    for(int d = 2; d < N; ++d)
    {
        for(int i = 1; i + d <= N; ++i)
        {
            for(int j = i; j < i + d; ++j)

               if(mat[i][i + d] == 0) mat[i][i + d] = mat[i][j] + mat[j+1][i+d] + D[i].l * D[j].c * D[i+d].c;

               else mat[i][i + d] = min(mat[i][i + d], (mat[i][j] + mat[j+1][i+d] + D[i].l * D[j].c * D[i+d].c) );

        }
    }

    fout << mat[1][N] << "\n";
}
int main()
{
    Read();
    Do();
    return 0;
}
