#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

int main(int argc, char** argv) {
    
    int n,k,j,i,r,t,m,p,s=0;
    freopen("h://varenapunctro//28_pdm//grader_test1.in","r",stdin);
    //freopen("h://varenapunctro//28_pdm//podm.out","w",stdout);
    cin >> n; int *d=new int[n+1];
    for(k=0; k<=n; k++) cin >> d[k];
    if(n==1) { s=0; }
    if(n==2) { s=d[0]*d[1]*d[2]; }
    t=n;
    r=d[0]*d[1]*d[2];
    for(i=1; i<t-1; i++) { 
        m=d[i]*d[i+1]*d[i+2];
        if(m<r) { r=m; j=i+1; }
    }
    s=s+r;
    for(p=j; p<t; p++) d[p]=d[p+1];
    for(k=1; k<n-1; k++) {
        r=d[0]*d[1]*d[2]; j=1;
        for(i=1; i<t-1; i++) {
            m=d[i]*d[i+1]*d[i+2];
            if(m<r) { r=m; j=i+1; }
        } 
    s=s+r;for(p=j; p<t; p++) d[p]=d[p+1];
    t=t-1;
    }
    cout << s << endl;
    return 0;
}

