#include <fstream>
#define ll long long

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

const int nmx = 505;
const int mx = 1e17;

int n;
ll dp[nmx][nmx], d[nmx];

void read(){
    cin >> n;

    for(int i = 0; i <= n; i++)
        cin >> d[i];
}

void solve(){
    for(int i = 1; i < n; i++)
        dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];

    for(int w = 2; w < n; w++)
        for(int i = 1; i <= n - w; i++){
            int j = i + w;
            dp[i][j] = mx;
            for(int k = i; k <= j - 1; k++)
                dp[i][j]= min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j]);
        }

    cout << dp[1][n];
}

int main()
{
    read();
    solve();

    return 0;
}
