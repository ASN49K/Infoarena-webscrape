#include <iostream>
#include <fstream>
#include <cstring>

int main() {
    std::ifstream input("podm.in");
    std::ofstream output("podm.out");

    int n;
    input >> n;
    long long d[501] = {0};
    for (int i = 0; i <= n; ++i) input >> d[i];

    long long dp[501][501];

    for (auto &i: dp) {
        for (auto &j: i) j = 1e9;
    }

    for (int i = 1; i <= n; ++i) dp[i][i] = 0;
    for (int i = 1; i < n; ++i) dp[i][i + 1] = d[i] * d[i - 1] * d[i + 1];

    for (int i = 2; i < n; ++i) {
        for (int j = 1; j <= n - i; ++j) {
            for (int k = j; k <= j + i; ++k) {
                dp[j][j + i] = std::min(dp[j][j + i], dp[j][k] + dp[k + 1][j + i] + d[j - 1] * d[k] * d[j + i]);
            }
        }
    }
    output << dp[1][n];
    return 0;
}
