#include <fstream>
#define Nmax 502
using namespace std;

const unsigned long long inf = 1LL << 62;

ifstream cin("podm.in");
ofstream cout("podm.out");

int n;
short int sizes[Nmax];
unsigned long long dp[Nmax][Nmax];

int main()
{
    cin >> n;
    for(int i = 0; i<=n; i++)
        cin >> sizes[i];

    for(int i = 0; i<=n; i++)
        for(int j = 0; j<=n; j++)
            if(i != j) dp[i][j] = inf;

    for(int len = 2; len<=n; len++)
        for(int i = 1, j = len; i<=n && j<=n; i++, j++)
        {
            for(int k = 1; k<=j; k++)  
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + sizes[i-1] * sizes[j] * sizes[k]);
        }
            
    cout << dp[1][n];
}