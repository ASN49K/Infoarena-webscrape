#include <fstream>
using namespace std;
const int NMAX = 500;
const long long INF = (1LL << 62);
int v[NMAX + 1];
long long op[NMAX + 1][NMAX + 1], miny;
long long interval ( int i, int k, int j ) {
    return op[i][k] + op[k+1][j] + (long long) v[i - 1] * v [k] * v[j];
}
static inline long long min ( long long a, long long b ) {
    return a < b ? a : b;
}
ifstream fin ( "podm.in" );
ofstream fout ( "podm.out" );
int main() {
    int n, i, l, j, k;

    fin >> n;
    for ( i = 0; i <= n; i++ )
        fin >> v[i];

    for ( i = 1; i < n; i++ )
        op[i][i+1] = (long long) v[i - 1] * v[i] * v[i + 1];
    for ( i = 2; i < n; i++ )
        for ( j = 1; j <= n - i; j++ ) {
            l = i + j;
            miny = INF;
            for ( k = j; k < l; k++ )
                if ( interval ( j, k, l ) < miny )
                    miny = interval ( j, k, l );
            op[j][l] = miny;
        }
    fout << op[1][n];


    return 0;
}
