#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

int n,Dim[501],PD[501][501],k;

int main()
{
   cin>>n;
   for(int i=1;i<=n+1;i++)
        cin>>Dim[i];

    for(int i=1;i<=n;i++)
        PD[i][i]=0;

    for(int i=2;i<=n;i++)
        for(int x=1;i+x-1<=n;x++) {
        int s=100000001;
        int j=i+x-1;
        for(int k=x;k<j;k++)
    {
        s=min(PD[x][k]+PD[k+1][j]+Dim[x]*Dim[k+1]*Dim[j+1],s);
    }
    PD[x][j]=s;
        }
    for(int i=1;i<=n;i++)
    {
     for(int j=i+1;j<=n;j++) cout<<PD[i][j]<<' ';
     cout<<'\n';
    }
}
