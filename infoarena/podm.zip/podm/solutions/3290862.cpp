#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    ifstream fin("podm.in");
    int N;
    fin >> N;
    vector<int>d(N + 1);

    for (int i = 0; i <= N; i++)
        fin >> d[i];
    fin.close();

    vector<vector<long long>> dp(N, vector<long long>(N));


    for (int l = 1; l < N; l++) {
        for (int i = 0; i < N - l; i++) {
            int j = i + l;
            dp[i][j] = INT64_MAX;
            for (int k = i; k <= j - 1; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i] * d[k + 1] * d[j + 1]);
            }
        }
    }
    
    ofstream fout("podm.out");
    fout << dp[0][N - 1];
    fout.close();

    return 0;

}
