#include <fstream>
#include <climits>
using namespace std;

int main() {
    int n;
    ifstream fin("podm.in");
    ofstream fout("podm.out");
    fin >> n;
    int d[n + 1], i, j, k, len;
    for (i = 0; i <= n; i++) {
        fin >> d[i];
    }

    long long dp[n + 1][n + 1];
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            dp[i][j] = (i == j) ? 0 : LLONG_MAX;
        }
    }

    for (len = 2; len <= n; len++ )
        for (i = 1; i <= n - len + 1; i++) {
            j = i + len - 1;
            for (k = i; k < j; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j]);
            }
    }
    fout << dp[1][n] << endl;
    return 0;
}