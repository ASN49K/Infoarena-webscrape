#include <iostream>
#include <fstream>
using namespace std;

const char iname[] = "podm.in";
const char oname[] = "podm.out";

#define MAXN 510
#define INF 100000000000000000LL

long long table[MAXN][MAXN], dims[MAXN];    int n;

int minimum(int a, int b) {
    if(a < b) return a;
    else return b;
}

int main(void) {
    ifstream in(iname);
    ofstream out(oname);
    in >> n;
    for(int i = 0; i <= n; ++i) in >> dims[i];
    for(int i = 1; i <= n - 1; ++i) table[i][i + 1] = dims[i - 1] * dims[i] * dims[i + 1];

    for(int dist = 2; dist < n; ++dist) {
        for(int i = 1; i <= n - dist; ++i) {
            int j = i + dist;
            table[i][j] = INF;
            for(int k = i; k < j; ++k) {
                table[i][j] = minimum(table[i][j], table[i][k] + table[k + 1][j] + dims[i - 1] * dims[k] * dims[j]);
            }
        }
    }

    out << table[1][n];

    in.close();
    out.close();
    return 0;
}