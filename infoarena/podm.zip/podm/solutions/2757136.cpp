#include <bits/stdc++.h>
//#define int ll
#define ll long long
using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n,dp[505][505];
int dim[505];

int main()
{
    f>>n;

    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j) dp[i][j]=(1e9);



    for(int i=0;i<=n;++i) f>>dim[i];

    for(int i=1;i<=n;++i) dp[i][i] =0;

    for(int i=1;i<n;++i)
    {
        dp[i][i+1] = dim[i-1]*dim[i+1]*dim[i];
    }

    for(int d = 2;d<n;++d)
    {
        for(int i=1;i<=n-d;++i)
        {

            int st= i;
            int dr = i+d;
            for(int j=st;j<dr;++j)
            {
                dp[st][dr] = min(dp[st][dr] , dp[st][j]+dp[j+1][dr]+dim[st-1]*dim[j]*dim[dr]);
            }
        }
    }

    g<<dp[1][n];

    return 0;
}
