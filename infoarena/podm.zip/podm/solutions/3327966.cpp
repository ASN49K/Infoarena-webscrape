/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
#include <climits>
using namespace std;
long long dp[503][503];
int n;
int v[503];
int main()
{
    ifstream f("podm.in");
    ofstream g("podm.out");
    f>>n;
    for(int i=0; i<=n; i++)
    {
        f>>v[i];
    }
    
    for(int i=1; i<=n; i++)
    {
        dp[i][i]=0;
    }
    for(int len=2; len<=n; len++)
    {
        for(int i=1; i+len-1<=n; i++)
        {
            int j=i+len-1;
            long long minim=LLONG_MAX;
            for(int k=i; k<=j-1; k++)
            {
                minim=min(dp[i][k]+dp[k+1][j]+v[i-1]*v[k]*v[j],minim);
            }   
            dp[i][j]=minim;
            
            
        }
    }
    g<<dp[1][n];
    

    return 0;
}