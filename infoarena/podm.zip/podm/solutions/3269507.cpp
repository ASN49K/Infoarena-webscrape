#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

// orice are dimensiune mare se declara global (pentru a evita probleme cu stiva)
long long dp[510][510];
int d[510];
// constante se declara global (ex INF)
const long long INF = 1e15;

int main()
{
    // orice alte variabile mai mici se declara acolo unde ai nevoie de ele
    int n;
    fin >> n;
    for (int i = 1; i <= n + 1; ++i) {
        fin >> d[i];
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = i + 1; j <= n + 1; ++j) {
            dp[i][j] = INF;
        }
    }
    for (int i = 1; i <= n; ++i) {
        dp[i][i + 1] = 0;
    }

    for (int lungime = 2; lungime <= n; ++lungime) {
        for (int i = 1; i <= n; ++i) {
            int j = i + lungime;
            if (j > n + 1) continue;

            for (int k = i + 1; k <= j - 1; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j] + 1LL * d[i] * d[k] * d[j]);
            }
        }
    }

    fout << dp[1][n + 1];
    return 0;
}