#include<fstream>
std::ifstream fin("podm.in");
std::ofstream fout("podm.out");
long long d[505], dp[505][505];
int n;
void read()
{
    fin>>n;
    for(int index=0; index<n+1; ++index)
        fin>>d[index];
}
void getVal(int i, int j)
{
    long long min=99999999999999999;
    for(int k=i; k<j; ++k)
    {
        long long local=dp[i][k]+dp[k+1][j]+(d[i-1]*d[k]*d[j]);
        if(local<min)
            min=local;
    }
    dp[i][j]=min;
}
void solve()
{
    for(int k=2; k<=n; ++k)
        for(int next=k; next<=n; ++next)
            getVal(next-k+1, next);
    fout<<dp[1][n];
}
int main()
{
    read();
    solve();
    return 0;
}