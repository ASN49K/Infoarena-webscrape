#include <bits/stdc++.h>
using namespace std;

    //(m23 * m34) * (m45 *m56)
    //m24 * m46 = m26

    //dp[i][j] = mi,mi+1,mi+2...mj

ifstream fin("podm.in");
ofstream fout("podm.out");
long long dp[505][505];
int main()
{
    long long n,i,j,a[505];
    fin>>n;
    for(i=0;i<=n;i++) fin>>a[i];

    for(i=1; i<=n; i++)
    {
        dp[i][i] = 0; //iniitalizare. cazul de o singura matrice
        for(j=i+1; j<=n; j++) dp[i][j] = LLONG_MAX;
    }

    for(int pas=1; pas<n; pas++)
        for(i=1; i<=n-pas; i++)
        {
            j=pas+i; //i=1, j=2
            for(int k=i; k<j;k++) //i=1 k=2, j=3 -> (m23 * m34)*m45 =
                dp[i][j] = min( dp[i][j], dp[i][k] + dp[k+1][j] + a[i-1]*a[k]*a[j]); //Mmn * Mnp are m*n*p inmultiri scalare
        }

    fout<<dp[1][n];
    return 0;
}
