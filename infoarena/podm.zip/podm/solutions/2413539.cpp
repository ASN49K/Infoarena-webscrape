#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

#define maxn 505
#define inf 1000000000000000
long long m[maxn][maxn],d[maxn],n;

int main()
{
    cin>>n;
    for(int i=0; i<=n; i++)
        cin>>d[i];
    for(int i=1; i<n; i++)
        m[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(int w=2; w<n; w++)
        for(int i=1; i<=n-w; i++){
            int j=w+i;
            m[i][j]=inf;
            for(int k=i; k<j; k++)
                m[i][j]=min(m[i][j],m[i][k]+m[k+1][j]+d[i-1]*d[k]*d[j]);
    }
    cout<<m[1][n];
    return 0;
}
