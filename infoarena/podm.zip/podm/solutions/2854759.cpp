#include <fstream>
#include <deque>
#include <vector>
#include <iomanip>
#include <queue>
#include <algorithm>
#include <cmath>
#include <climits>

#define MOD 104659

using namespace std ;

ifstream cin ("podm.in") ;
ofstream cout ("podm.out") ;

long long dp[509][509] ;

struct nod
{
    int st, dr ;
};

nod v[509] ;

int main()
{
    int n ;

    cin >> n ;

    int aux ;

    cin >> aux ;

    for(int f = 1, a ; f <= n ; f ++)
    {
        cin >> v[f].dr ;

        v[f].st = aux ;

        aux = v[f].dr ;
    }

    for(int f = n - 1 ; f ; f --)
    {

        for(int e = f + 1 ; e <= n ; e ++) /// costul minim pentru intervalul f, e
        {

        for(int k = f ; k < e ; k ++)
            dp[f][e] = min(dp[f][e] + INT_MAX * !(dp[f][e]), dp[f][k] + dp[k + 1][e] + v[f].st * v[k].dr * v[e].dr) ;

        }
    }

    cout << dp[1][n] ;

    return 0 ;
}
/*
7
10 1 7 2 2 6 10 7
*/
