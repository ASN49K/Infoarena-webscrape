#include <bits/stdc++.h>
using namespace std;
#define STOP fout.close(); exit(EXIT_SUCCESS);
ifstream fin("podm.in");
ofstream fout("podm.out");
///***********************
const int NMAX = 503;
using int64 = long long;
int n;
struct {
    int rows, cols;
} a[NMAX];
int64 dp[NMAX][NMAX];

void read() {
    int aux, curr;
    fin >> n >> aux;
    for (int i = 1; i <= n; i++) {
        fin >> curr;
        a[i] = {aux, curr};
        aux = curr;
    }
}

void init() {
    for (int i = 0; i < NMAX; i++)
        for (int j = 0; j < NMAX; j++)
            dp[i][j] = LLONG_MAX;
}

void solve() {
    for (int i = 1; i < n; i++) {
        dp[i][i] = 0;
        dp[i][i + 1] = a[i].rows * a[i].cols * a[i + 1].cols;
    }
    dp[n][n] = 0;
    for (int i = n; i; i--)
        for (int j = i + 1; j <= n; j++)
            for (int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], 1LL * dp[i][k] + 1LL * dp[k + 1][j] + 1LL * a[i].rows * a[k].cols * a[j].cols);
    fout << dp[1][n] << endl;
}

int main() {
    init();
    read();
    solve();
    STOP
}
