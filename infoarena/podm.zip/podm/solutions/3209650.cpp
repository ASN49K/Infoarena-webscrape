#include <bits/stdc++.h>

#define INF 100000000000000000LL

int main()
{
    int n;
    std::vector<int> dim;
    std::vector<std::vector<long long>> dp;

    std::ifstream fin("podm.in");

    fin >> n;

    dim.resize(n + 1);
    dp.resize(n + 1, std::vector<long long>(n + 1, 0));

    for (int i = 0; i <= n; ++i)
        fin >> dim[i];

    fin.close();

    for (int i = 1; i <= n; ++i)
        dp[i][i] = 0;

    for (int i = 1; i < n; ++i)
        dp[i][i + 1] = 1LL * dim[i - 1] * dim[i] * dim[i + 1];

    for (int len = 2; len < n; ++len) {
        for (int j, i = 1; i + len <= n; ++i) {
            j = i + len;
            dp[i][j] = INF;
            for (int k = i; k < j; ++k)
                dp[i][j] = std::min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1LL * dim[i - 1] * dim[k] * dim[j]);
        }
    }

    std::ofstream fout("podm.out");

    fout << dp[1][n] << '\n';

    fout.close();

    return 0;
}
