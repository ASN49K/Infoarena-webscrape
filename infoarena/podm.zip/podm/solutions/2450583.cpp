#include <bits/stdc++.h>

#define BUFFER_SIZE 1 << 17
const unsigned long long INF = (1e17);
char buffer[BUFFER_SIZE];
int pos = BUFFER_SIZE;
long long dp[505][505], d[505];

inline char next() {
	if (pos == BUFFER_SIZE) {
		fread(buffer, 1, BUFFER_SIZE, stdin);
		pos = 0;
	}

	return buffer[pos++];
}

inline long long read() {
	long long n = 0;
	char c = next();

	while (!('0' <= c && c <= '9')) {
		c = next();
	}

	while ('0' <= c && c <= '9') {
		n = (n << 3) + (n << 1) + (c - '0');
		c = next();
	}

	return n;
}

long long min(long long a, long long b) {
    return a < b ? a : b;
}

int main() {
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);

    int n = read();

    for (int i = 0 ; i <= n ; ++i) {
        d[i] = read();
    }


    for (int l = 2 ; l <= n ; ++l) {
        for (int i = 1 ; i <= n - l + 1; ++i) {
            int j = i + l - 1;
            dp[i][j] = INF;

            for (int k = i ; k < j; ++k) {
                dp[i][j] = min(dp[i][j],  dp[i][k] + dp[k + 1][j] + (d[i - 1] * d[k] * d[j]));
            }
        }
    }

   	printf("%llu\n", dp[1][n]);
    return 0;
}
