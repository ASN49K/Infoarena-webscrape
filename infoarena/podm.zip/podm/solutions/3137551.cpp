#include <bits/stdc++.h>
using namespace std;
using llx = long long;

ifstream fin("podm.in");
ofstream fout("podm.out");

const llx inf = 1ll<<59;
vector<int> d; // M[i] = d[i-1] x d[i]
vector<vector<llx>> dp; // dp[i][j] = nr minim de operatii pentru a inmulti matricile M[i], M[i+1], ..., M[j]

int main()
{
    int n, lg, i, j, k;

    fin >> n;
    d.resize(n+1);
    dp.assign(n+1, vector<llx>(n+1, inf));
    for (i = 0; i<=n; i++)
        fin >> d[i];

    for (i = 1; i<=n; i++)
        dp[i][i] = 0;

    for (lg = 2; lg<=n; lg++)
        for (i = 1; i<=n-lg+1; i++)
        {
            j = i+lg-1;
            for (k = i; k<j; k++) // combin dp[i][k] cu dp[k+1][j]
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + 1ll * d[i-1] * d[k] * d[j]);
        }

    fout << dp[1][n];
    return 0;
}
