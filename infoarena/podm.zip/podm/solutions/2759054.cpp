#include <bits/stdc++.h>
using namespace std;

int main() {
  freopen("podm.in", "r", stdin);
  freopen("podm.out", "w", stdout);
  int n;
  scanf("%d", &n);
  int a[n];
  for(int i=0;i<=n;i++)
    scanf("%d", &a[i]);
  unsigned long long dp[n][n];
  for(int l=n-1;l>=0;l--) {
    dp[l][l] = 0;
    for(int r = l+1;r<n;r++) {
      for(int i=l;i<r;i++) {
        dp[l][r] = min(dp[l][r], dp[l][i]+dp[i+1][r]+(unsigned long long)a[l]*a[i+1]*a[r+1]);
      }
    }
  }
  printf("%u\n", dp[0][n-1]);
  return 0;
}