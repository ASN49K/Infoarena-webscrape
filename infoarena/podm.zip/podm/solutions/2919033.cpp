#include <bits/stdc++.h>
#define N 505
#define INF 0x3f3f3f3
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long best[N][N],a[N];
int n;
int main()
{
    int i,j,k,d;
    fin>>n;
    for(i=0;i<=n;i++) fin>>a[i];
    //for(i=1;i<=n;i++) best[i][i]=0;
    for(i=1;i<n;i++) best[i][i+1]=a[i-1]*a[i]*a[i+1];
    for(d=2;d<n;d++)
        for(i=1;i<=n-d;i++)
    {
        j=i+d;
        best[i][j]=INF;
        for(k=1;k<j;k++)
            best[i][j]=min(best[i][j],best[i][k]+best[k+1][j]+a[i-1]*a[k]*a[j]);
    }
    fout<<best[1][n];
    return 0;
}
