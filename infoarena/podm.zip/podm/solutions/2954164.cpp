#include<fstream>
using namespace std;
ifstream F("podm.in");
ofstream G("podm.out");
long long i,j,k,d[501],n,m[501][501];
int main()
{
    for(F>>n;i<=n;F>>d[i++]);
    for(i=1;i<n;m[i][i+1]=d[i-1]*d[i]*d[i+1],++i);
    for(j=2;j<n;++j)
        for(i=1;i<=n-j;++i)
            for(m[i][i+j]=1e18,k=i;k<i+j;m[i][i+j]=min(m[i][i+j],m[i][k]+m[k+1][i+j]+d[i-1]*d[k]*d[i+j]),++k);
    return G<<m[1][n],0;
}
