#include <iostream>
#include <fstream>
#include <climits>
using namespace std;
ifstream fi("podm.in");
ofstream fo("podm.out");
///PODM
int n;
int v[503];
int dp[503][503];
int DP()
{
    for(int i = n - 1; i >= 1; i --)
    {
        for(int j = i + 1; j <= n; j ++)
        {
            dp[i][j] = 100000000;
            for(int k = i; k < j; k ++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] +  v[i] * v[k+1] * v[j+1]);
            }
        }
    }
}
int main()
{
    fi>>n;
    for(int i=1;i<=n+1;i++)
        fi>>v[i];
    DP();
    fo<<dp[1][n];
    return 0;
}
