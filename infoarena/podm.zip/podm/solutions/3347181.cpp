#include <bits/stdc++.h>   
using namespace std;  

ifstream fin("podm.in");
ofstream fout("podm.out");

long long n, v[502];
long long dp[501][501];

int main(){

// dp[i][j] = numarul minim de inmultiri folosind matricile de la i la j
// luam k intermediar
fin>>n;
for (int i = 1; i <= n + 1; i++){
    fin>>v[i];
}
for (int i = 1; i <= n; i++){
    for (int j = 1; j <= n; j++){
        dp[i][j] = 1e18;
    }
} 
for (int i = 1; i <= n; i++){
    dp[i][i] = 0;
}
for (int i = 1; i < n; i++){
    dp[i][i+1] = v[i] * v[i+1] * v[i+2];
}
// parcurgem lungimile altfel nu luam starile bine
for (int l = 1; l <= n; l++){
    // fixam i
    for (int i = 1; i <= n; i++){
        int j = i + l;
        if (j <= n){
        // luam k intermediar
            for (int k = i; k < j; k++){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + v[i] * v[k+1] * v[j+1]); 
            }
        }
    }
}
fout << dp[1][n];


return 0;
}   
