#include <fstream>
#include <algorithm>
#include <climits>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int n;
long long dp[505][505], d[505];

int main()
{
    f>>n;
    for(int i=0; i<=n; i++)
        f>>d[i];
    for(int dif=1; dif<n; dif++)
    {for(int i=1; i+dif<=n; i++)
{
long long vmin=99999999;
int j=i+dif;
for(int k=i; k<=j-1; k++)
vmin=min(vmin, dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
    dp[i][j]=vmin;}}
    g<<dp[1][n];
    return 0;
}
