#include <iostream>
#include <fstream>
#include <climits>
using namespace std;
long long int n,a[100005],dp[505][505];
ifstream fin ("podm.in");
ofstream fout("podm.out");
int  main()
{
    fin >> n;
    for(int i = 0; i <= n; i++)
        fin >> a[i];
    for(int l = 1; l < n; l++)
    {
        for(int i = 0 ,j = l; i < n, j < n; i++ ,j++)
        {
            dp[i][j] = LLONG_MAX;
            for(int k = i; k <= j - 1; k++)
            {
                dp[i][j]=min(dp[i][k] + dp[k+1][j] + a[i] * a[k + 1] * a[j + 1], dp[i][j]);
            }
    }
    }
      fout << dp[0][n - 1];


    return 0;
}
