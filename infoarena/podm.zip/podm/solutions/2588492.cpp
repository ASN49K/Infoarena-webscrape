#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n;
int v[502], sol[501][501];

int main() {
    fin >> n;

    for (int i = 1; i <= n + 1; i++)
        fin >> v[i];

    for (int h = 2; h <= n; h++) {
        int i = 1;
        int j = h;

        while (j <= n) {
            sol[i][j] = min(sol[i][j - 1] + v[i] * v[j] * v[j + 1], sol[i + 1][j] + v[i] * v[i + 1] * v[j + 1]);
            i++;
            j++;
        }
    }

    fout << sol[1][n];
    return 0;
}
