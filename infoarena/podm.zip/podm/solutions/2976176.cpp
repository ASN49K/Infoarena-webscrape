//
//  main.cpp
//  Parantezare optima de matrici (infoarena)
//
//  Created by Andrei Bădulescu on 08.02.23.
//

//#include <iostream>
#include <climits>
#include <fstream>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

const int N = 500;

int marimi[N + 1][2];
long long partials[N + 1][N + 1];
int n;

int main() {
    cin >> n;

    int x;
    cin >> x;
    marimi[1][0] = x;

    cin >> x;
    marimi[1][1] = x;

    for (auto i = 2; i <= n; i++) {
        marimi[i][0] = x;
        cin >> x;
        marimi[i][1] = x;
    }

    for (auto i = n; i >= 1; i--) {
        for (auto j = i + 1; j <= n; j++) {
            partials[i][j] = INT_MAX;

            for (auto k = i; k < j; k++) {
                partials[i][j] = min(partials[i][j], partials[i][k] + partials[k + 1][j] + marimi[i][0] * marimi[k][1] * marimi[j][1]);
            }
        }
    }

    cout << partials[1][n];
    return 0;
}
