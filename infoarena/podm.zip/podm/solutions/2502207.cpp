#include <iostream>
#include <fstream>
#define nmax 501
#define INF   100000000000000000LL

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int d[nmax];
long long dp[nmax][nmax];
int n;

int main()
{
    int n;
    fin>>n;
    for(int i=0; i<=n; i++)
        fin>>d[i];

    for(int i=1; i<=n; i++)
        {
            dp[i][i]=0;
            dp[i][i+1]=d[i-1]*d[i]*d[i+1];
        }

    int i=1;
    int val=3;
    while(i<=n-2)
        {
            int j=val;
            int it=1;
            //fout<<"linia "<<i<<endl;
            while(j<=n)
                {
                    //fout<<"coloana "<<j<<endl;
                    long long value=INF;
                    for(int it2=it; it2<j; it2++)
                        {
                            //fout<<i<<" "<<it2<<" "<<j<<endl;
                            value=min(dp[it][it2]+dp[it2+1][j]+d[it-1]*d[it2]*d[j],value);
                        }
                    dp[it][j]=value;
                    j++;
                    it++;
                }
            val++;
            i++;
        }

    /*for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
                {
                    fout<<dp[i][j]<<" ";
                }
            fout<<endl;
        }*/
    fout<<dp[1][n];

    return 0;
}
