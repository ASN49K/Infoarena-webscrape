#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

unsigned long long n,Dim[501],PD[501][501],k,i,j,x;

int main()
{
   cin>>n;
   for(i=1;i<=n+1;i++)
        cin>>Dim[i];

    for(i=2;i<=n;i++)
        for(x=1;i+x-1<=n;x++) {
        unsigned long long s=100000001;
        j=i+x-1;
        for(k=x;k<j;k++)
    {
        s=min(PD[x][k]+PD[k+1][j]+Dim[x]*Dim[k+1]*Dim[j+1],s);
    }
    PD[x][j]=s;
        }
    cout<<PD[1][n];
}
