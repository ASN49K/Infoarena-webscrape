#include <fstream>
#define NMAX 502
#define INF 100000000000000000LL

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long int n, i, j, k, w, v[NMAX], dp[NMAX][NMAX];

int main()
{
    fin >> n;
    for(i = 0; i <= n; i++)
        fin >> v[i];
    for(i = 1; i <= n; i++)
        dp[i][i] = 0;
    for(i = 1; i < n; i++)
        dp[i][i + 1] = v[i - 1] * v[i] * v[i + 1];
    for(w = 2; w < n; w++)
    {
        for(i = 1; i <= n - w; i++)
        {
            j = i + w;
            dp[i][j] = INF;
            for(k = 1; k <= j - 1; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
        }
    }
    fout << dp[1][n];
    return 0;
}
