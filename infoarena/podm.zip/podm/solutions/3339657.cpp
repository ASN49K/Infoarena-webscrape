#include <fstream>
#include <climits>

int main()
{
    short n;
    std::ifstream in("podm.in");
    in >> n;

    short *t = new short[n + 1];

    int **dp = new int *[n + 1];
    for (int i = 0; i <= n; i++)
    {
        dp[i] = new int[n + 1];
        for (int j = 0; j <= n; j++)
            dp[i][j] = (i == j) ? 0 : INT_MAX;
    }

    for (short i = 0; i <= n; i++)
        in >> t[i];
    in.close();

    for (int i = n; i >= 0; i--)
    {
        for (int j = i + 1; j <= n; j++)
        {
            for (int k = i; k < j; k++)
            {
                dp[i][j] = std::min(dp[i][j], dp[k + 1][j] + t[i] * t[k + 1] * t[j + 1]);
            }
        }
    }

    std::ofstream out("podm.out");
    out << dp[0][n];
    out.close();

    for (int i = 0; i <= n; i++)
        delete[] dp[i];
    delete[] dp;
    delete[] t;

    return 0;
}