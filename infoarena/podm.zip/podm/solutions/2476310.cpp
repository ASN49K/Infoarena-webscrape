#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long L[100005], C[100005];
long long X[10005][10005];

int main()
{
    int n;
    fin >> n;
    fin >> L[1];
    for( int i = 1 ; i <= n + 1  ; ++i )
    {
        fin >> C[i];
        L[i+1] = C[i];
    }

    for( int i = n-1; i >= 1 ; --i )
    {
        for (int j = i+1 ; j <= n ; ++j )
        {
            X[i][j] = X[i][i] + X[i+1][j] + L[i] * C[i] * C[j] ;
            for( int k = i ; k < j ; ++k )
                X[i][j] = min(X[i][j], X[i][k] + X[k+1][j] + L[i] * C[k] * C[j] );
        }
    }

    fout << X[1][n];
}
