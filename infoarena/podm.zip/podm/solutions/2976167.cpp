#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

int a[501], dp[501][501], n;

int main()
{
    cin >> n;
    for(int i = 0; i <= n; i++)
        cin >> a[i];
    for(int i = n; i >= 1; i--)
        for(int j = i + 1; j <= n; j++)
        {
            dp[i][j] = 999999999;
            for(int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
        }
    cout << dp[1][n] << "\n";
    return 0;
}
