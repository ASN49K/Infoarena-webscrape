#include <bits/stdc++.h>

using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

int v[505];
long long dp[505][505];
long long INF = 1e15;

int main()
{
    int n;
    fin >> n;
    for (int i=1;i<=n+1;++i){
        fin >> v[i];
    }
    for (int i=1;i<=n;++i){
        for (int j=1;j<=n;++j){
            dp[i][j] = INF;
        }
    }
    for (int i=1;i<=n;++i){
        dp[i][i+1] = 0;
    }
    for (int l=2;l<=n;++l){
        for (int i=1;i<=n;++i){
            int j = i+l;
            if (j>n+1) continue;
            for (int k=i+1;k<=j-1;++k){
                dp[i][j] = min(dp[i][j],dp[i][k]+dp[k][j]+1LL*v[i]*v[j]*v[k]);
            }
        }
    }
    fout << dp[1][n+1];
    return 0;
}
