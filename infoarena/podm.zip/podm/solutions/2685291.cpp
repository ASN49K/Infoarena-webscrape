#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const long long INF = 1e18;
const int NMAX = 505;

long long dp[NMAX][NMAX];
int v[NMAX];
int n;

int main()
{
    fin >> n;
    for(int i = 0; i <= n ; i++)
        fin >> v[i];
    for(int col = 2 ; col <= n ; col++)
    {
        int i = 1;
        for(int j = col ; j <= n ; j++)
        {
            dp[i][j] = INF;
            for(int k = i ; k < j ; k++)
            {
                long long ans = dp[i][k] + dp[k+1][j] + 1ll*v[i-1]*v[k]*v[j];
                dp[i][j] = min(dp[i][j],ans);
            }
            i++;
        }
    }
    fout << dp[1][n] << "\n";
    return 0;
}
