#include <fstream>
using namespace std;
ifstream f("paranteze.in");
ofstream g("paranteze.out");
int v[10000001],n,k;
char c;
struct sir_parantezat
{
    int a,b,lung;
} s[10000001];
int largire_sir_parantezat(int a,int b)
{
    /**verific daca sirul parantezat este incadrat intr-o pereche de
    paranteze de acelasi tip, mai intai deschisa si apoi inchisa*/
    if(v[a-1]+v[b+1]==7&&v[a-1]<v[b+1])
        return 1;
    return 0;
}
int mai_exista_extindere_prin_lipire()
{
    for(int i=1; i<k; i++)
        if(s[i].b+1==s[i+1].a)///daca sunt doua siruri parantezate alaturate
            return i;///indicele sirului parantezat care se poate extinde
    return 0;
}
/*void afisare_siruri()
{
    for(int i=1; i<=k; i++)
        g<<"sir "<<i<<": de la "<<s[i].a<<" la "<<s[i].b<<" de lungime "<<s[i].lung<<endl;
    g<<endl;
}*/
int lungimea_maxima_a_unui_sir_parantezat()
{
    int max_lung=0;
    for(int i=1; i<=k; i++)
        if(s[i].lung>max_lung)
            max_lung=s[i].lung;
    return max_lung;
}
int main()
{
    ///https://www.infoarena.ro/problema/paranteze
    /**legenda:
    '('=1
    ')'=6
    '['=2
    ']'=5
    '{'=3
    '}'=4
    '('+')'=7
    '['+']'=7
    '{'+'}'=7
    OBS: parateza deschisa are nr codului mai mic decal paranteza inchisa*/
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>c;
        if(c=='(')
            v[i]=1;
        else if(c==')')
            v[i]=6;
        else if(c=='[')
            v[i]=2;
        else if(c==']')
            v[i]=5;
        else if(c=='{')
            v[i]=3;
        else if(c=='}')
            v[i]=4;
    }
   // for(int i=1; i<=n; i++)
    //    g<<v[i];
   // g<<endl<<endl;
    ///secvente initiale simple
    for(int i=1; i<n; i++)
        if(v[i]+v[i+1]==7&&v[i]<v[i+1])
        {
            k++;
            s[k].a=i;
            s[k].b=i+1;
            s[k].lung=2;
            while(largire_sir_parantezat(s[k].a,s[k].b)==1)
            {
                s[k].a--;
                s[k].b++;
                s[k].lung+=2;
                i++;
            }
        }
   // afisare_siruri();
    int x=mai_exista_extindere_prin_lipire();
    while(x)
    {
        ///lipire sir
        s[x].b=s[x+1].b;
        s[x].lung+=s[x+1].lung;
        ///urmeaza sa elimin sirul parantezat pe care l-am lipit anterior
        for(int i=x+1; i<k; i++)
            s[i]=s[i+1];
        k--;
        //afisare_siruri();
        ///dupa aceea trebuia sa verific daca noile siruri se pot largi
        for(int i=1; i<=k; i++)
            while(largire_sir_parantezat(s[i].a,s[i].b)==1)
            {
                s[i].a--;
                s[i].b++;
                s[i].lung+=2;
            }
      //  afisare_siruri();
        x=mai_exista_extindere_prin_lipire();
    }
    g<<lungimea_maxima_a_unui_sir_parantezat();
    return 0;
}
