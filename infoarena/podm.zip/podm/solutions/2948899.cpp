#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMAX = 504;
const long long INF = 1e15;

long long v[NMAX], dp[NMAX][NMAX];

int main()
{
    long long n, i, j, k, lg;
    fin >> n;
    for ( i = 1; i <= n + 1; i++ )
      fin >> v[i];
    dp[1][1]=0;
    for ( lg = 2; lg <= n; lg++ ) {
      for ( i=1; i <= n - lg + 1; i++ ) {
        j = i + lg - 1;
        dp[i][j] = INF;
        for ( k = i; k < j; k++ ) {
          dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i] * v[j + 1] * v[k + 1]);
        }
      }
    }
    fout << dp[1][n];
    return 0;
}
