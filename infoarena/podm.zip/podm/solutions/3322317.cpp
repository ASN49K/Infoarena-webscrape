#include <bits/stdc++.h>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
const long long MOD = 666013, nMax = 1000, INF = 2e17;

long long dim[505], dp[505][505];

int main()
{
    int n;
    f >> n;
    for(int i=1; i<=n+1; i++)
        f >> dim[i];

    for(int i=1; i<=n; i++)
        for(int j = i+1; j<=n; j++)
            dp[i][j] = INF;

    for(int i=1; i<n; i++)
        dp[i][i+1] = dim[i] * dim[i+1] * dim[i+2];

    for(int len = 3; len<=n; len++)
    {
        for(int dr = len; dr<=n; dr++)
        {
            int st = dr - len + 1;
            for(int k=st; k<dr; k++)
                dp[st][dr] = min(dp[st][dr], dp[st][k] + dp[k+1][dr] + dim[st] * dim[k+1] * dim[dr+1]);
        }
    }
    g << dp[1][n];
}
