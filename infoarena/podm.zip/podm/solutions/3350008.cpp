#include<fstream>
#include<vector>

using namespace std;

#define MAXX 1e9

ifstream f("podm.in");
ofstream g("podm.out");

int main()
{
    int n;

    f >> n;

    vector<int> nums(n+1);

    for (int i = 0; i <= n; i++)
        f >> nums[i];

    vector<vector<unsigned long long>> dp(n+1, vector<unsigned long long>(n+1, 1e9));

    for (int i = 0; i <= n; i++)
        dp[i][i] = 0;

    for (int i = 1; i < n; ++i) {
        dp[i][i + 1] =  1ULL * nums[i - 1] * nums[i] * nums[i + 1];  
    }

    for (int i = n; i >= 1; i--) {
        for (int j = i + 1; j <= n; j++) {
            for (int k = i; k < j; k++) {
                unsigned long long aux = dp[i][k] + dp[k+1][j] + 1ULL * nums[i-1] * nums[k] * nums[j];
                dp[i][j] = min(aux, dp[i][j]);
            }
        }
    }
    g << dp[1][n];
}