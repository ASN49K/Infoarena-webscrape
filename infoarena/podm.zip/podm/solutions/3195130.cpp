#include <iostream>
#include <climits>

using namespace std;

long long d[10005], step, i, j, dp[503][503];

int main()
{
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);
    long long n;
    cin >> n;
    for (int i = 0; i <= n; i++)
        cin >> d[i];

    for (step = 1; step < n; step++)
        for (i = 1; i <= n - step; i++)
    {
        j = i + step;
        long long best = LONG_MAX;
        for (int k = i; k <= j-1; k++)
        {
            best = min(best, dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j]);
        }
        dp[i][j] = best;

    }
    cout << dp[1][n];
    return 0;
}
