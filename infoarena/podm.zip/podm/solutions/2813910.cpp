#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

unsigned long long int pd[503][503];
long long int d[503];

int n, nr, nrmin;

int main()
{
    int i, j ,k;
    fin>>n;
    for (i=0; i<=n; i++)
        fin>>d[i];
    for (i=1; i<n; i++)
	{
		pd[i][i+1]=d[i-1]*d[i+1]*d[i];
	}

	for (k=2; k<=n-1; k++)
	{
		for (i=1; i+k<=n; i++)
		{
			nrmin=pd[i][i]+pd[i+1][i+k]+d[i-1]*d[i]*d[i+k];

			for (j=i+1; j<i+k; j++)
			{
				nr=pd[i][j]+pd[j+1][i+k]+d[i-1]*d[j]*d[i+k];
				if (nr<nrmin)
				{
					nrmin=nr;
				}
			}

			pd[i][i+k]=nrmin;
		}
	}
	fout<<pd[1][n];
	return 0;
}
