#include <fstream>
#define mF "podm"
std::ofstream out(mF ".out");
std::ifstream in(mF ".in");
constexpr int N = 501; int V[N][N], A[N]; int F(int i, int j)
{
    if (j-i == 1 or V[i][j]) return V[i][j];
    V[i][j] = (1<<31)-1; for (int k = i+1; k < j; k++)
        V[i][j] = std::min(V[i][j],
        F(i, k) + F(k, j) + A[i] * A[k] * A[j]);
    return V[i][j];
}
int main()
{
    int n; in >> n; for (int i = 0; i <= n; i++) in >> A[i];
    out << F(0, n);
}
