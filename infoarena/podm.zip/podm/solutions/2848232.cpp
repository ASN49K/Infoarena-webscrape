#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long dp[505][505];
int a[505], n;

int main()
{
    int i, j, k;
    long long x;
    fin >> n;
    for (i = 0; i <= n; i++)
        fin >> a[i];
    for (i = 1; i < n; i++)
        dp[i][i+1] = 1;
    for (i = n - 1; i >= 1; i--)
        for (j = i + 1; j <= n; j++)
        {
            x = 1LL << 60;
            for (k = i + 1; k <= j; k++)
                x = min(x, dp[i][k-1] + dp[k][j] + a[i-1]*a[k-1]*a[j]);
            dp[i][j] = x;
        }
    fout << dp[1][n] << "\n";
    fout.close();
    return 0;
}
