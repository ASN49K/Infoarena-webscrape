#include <fstream>

using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
long long dim[505];
long long mat[505][505];
const long long INF = (1 << 63) - 1;
int main()
{
    long long n, i, j;
    cin >> n;
    n++;
    for(i = 0; i < n; i++)
        cin >> dim[i];
    for(int len = 1; len < n - 1; len++){
        for(i = 1; i < n - len; i++){
            j = i + len;
            long long minn = INF;
            for(int k = i; k <= j - 1; k++)
                minn = min(minn, mat[i][k] + mat[k + 1][j] + 1LL * dim[i - 1] * dim[j] * dim[k]);
            mat[i][j] = minn;
        }
    }
    cout << mat[1][n - 1];
    return 0;
}
