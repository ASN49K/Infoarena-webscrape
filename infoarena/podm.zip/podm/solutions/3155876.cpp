#include <fstream>
#include <climits>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n,d[501];
long long dp[501][501];
int main()
{
    fin>>n;
    for(int i=0;i<=n;i++)
    {
        fin>>d[i];
    }
    for(int l=3;l<=n;l++)
    {
        for(int i=1;i<=n-l+1;i++)
            dp[i][i+l-1]=LONG_MAX;
    }
    for(int i=1;i<n;i++)
        dp[i][i+1]=d[i-1]*d[i]*d[i+1];


    for(int l=3;l<=n;l++)
    {
        for(int i=1;i<=n-l+1;i++)
        {
            for(int k=i;k<=i+l-2;k++)
            {
                dp[i][i+l-1]=min(dp[i][i+l-1],dp[i][k]+dp[k+1][i+l-1]+d[i-1]*d[k]*d[i+l-1]);
            }
        }
    }
    fout<<dp[1][n];

    return 0;
}
