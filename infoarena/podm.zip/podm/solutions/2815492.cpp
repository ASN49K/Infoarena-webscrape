#include <fstream>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n, v[502], d[502][502], lenght;

int calcul (int st, int dr)
{
    if (dr-st==1)
    {
        d[st][dr]=0;
        return 0;
    }

    if(d[st][dr]!=0)
    {
        return d[st][dr];
    }
    int k=st+1;
    int result=v[st] * v[k] * v[dr] + calcul(st, k) + calcul(k, dr);
    for (k=st+2; k<dr; k++)
    {
        result = min(result, v[st] * v[k] * v[dr] + calcul(st, k) + calcul(k, dr));
    }
    d[st][dr]=result;
    return result;
}

int main()
{
    fin>>n;
    n++;
    for (int i=1; i<=n; i++)
    {
        fin>>v[i];
    }

    fout<<calcul(1,n);
    return 0;
}
