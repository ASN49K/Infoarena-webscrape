#include <bits/stdc++.h>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("podm.in");
    ofstream fout("podm.out");
#endif  // ST_DIO

long long n, i, j, k, l, v[502];
long long d[502][502];

static inline void Precalc() {}
static inline void Test(int testCur = 0) {
    fin >> n;
    n++;
    for(i = 1; i <= n; i++) fin >> v[i];
    for(i = 1; i <= n; i++) d[i][i] = 1e18 + 7;
    for(i = 1; i <  n; i++) d[i][i + 1] = 0;
    for(l = 3; l <= n; l++) {
        for(i = 1; i + l - 1 <= n; i++) {
            j = i + l - 1;
            d[i][j] = LLONG_MAX;
            for(k = i + 1; k < j; k++) {
                d[i][j] = min(d[i][j], d[i][k] + d[k][j] + v[i] * v[k] * v[j]);
            }
        }
    }
    fout << d[1][n];
}

int main() {
    if(ST_DIO) ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    Precalc();
    int t = 1;
    //fin >> t;
    for(int i = 1; i <= t; i++)
        Test(i);

    return 0;
}
