#include <fstream>
#define DMAX 512

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
unsigned long long int pd[DMAX][DMAX], d[DMAX];
void citire();
void dinamica();

int main()
{
 citire();
 dinamica();
 fout<<pd[1][n]<<'\n';
 return 0;
}

void citire() {
    fin>>n;
    for (int i=0; i<=n; i++) {
        fin>>d[i];
    }
}

void dinamica() {
    unsigned long long int actual, minim;
    int j;
    for (int i=1; i<n; i++) {
        j=i+1;
        pd[i][j] = d[i-1]*d[i]*d[i+1];
    }
    for (int dif = 2; dif<n; dif++)
        for (int i=1; i<n; i++) {
            j = i+dif;
            if (j<=n) {
                minim = pd[i][i]+pd[i+1][j] + d[i-1]*d[i]*d[j];
                for (int k=i; k<j; k++) {
                    actual = pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j];
                    if (actual < minim) {
                        minim = actual;
                    }
                }
            } else break;

            pd[i][j] = minim;
        }

}
