#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll INF=(1e17)+1;

ifstream fin("podm.in");
ofstream fout("podm.out");

ll dp[1001][1001],d[1002];
int main() {
    int n;
    fin>>n;
    for (int i=1;i<=n+1;i++) fin>>d[i];
    for (int i=1;i<=n;i++) {
        for (int j=1;j<=n;j++) {
            dp[i][j]=INF;
        }
    }
    for (int i=1;i<n;i++) dp[i][i+1]=d[i]*d[i+1]*d[i+2];
    for (int i=1;i<=n;i++) dp[i][i]=0;

    for (int i=3;i<=n;i++) {
        for (int j=i;j<=n;j++) {
            int st=j-i+1;
            for (int k=1;k<j;k++) {
                ll cand=dp[st][k]+dp[k+1][j]+d[st]*d[k+1]*d[j+1];
                dp[st][j]=min(dp[st][j],cand);
            }
        }
    }
    fout<<dp[1][n]<<endl;
    return 0;
}
