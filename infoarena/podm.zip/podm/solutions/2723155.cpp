#include <bits/stdc++.h>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

long long n,j,i,k,st[510],dr[510],d[510][510];

int main()
{
    f>>n;

    f>>st[1]>>dr[1];
    for(i=2;i<=n+1;i++)
    {
        f>>dr[i];
        st[i]=dr[i-1];
    }

    for(i=n;i>=1;i--)
    for(j=1;j<=n;j++)
    {
        if(i!=j)
        {
            d[i][j]=LONG_LONG_MAX/2;
            for(k=i;k<=j;k++)
                d[i][j]=min(d[i][j],d[i][k]+d[k+1][j]+st[i]*dr[k]*dr[j]);
        }
    }

    g<<d[1][n]<<'\n';
    return 0;
}
