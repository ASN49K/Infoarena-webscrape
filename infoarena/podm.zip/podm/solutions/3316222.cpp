#include <bits/stdc++.h>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");

const long long inf = 1e18;
int n, a[505];
long long dp[505][505];

int main()
{
    f >> n;
    for (int i=1; i<=n+1; ++i)
        f >> a[i];
    for (int i=1; i<=n; ++i)
        dp[i][i+1] = 0;
    for (int l=3; l<=n+1; ++l)
        for (int i=1; i<=n-l+2; ++i) {
            int j = i + l - 1;
            dp[i][j] = inf;
            for (int k=i+1; k<j; ++k)
                dp[i][j] = min (dp[i][j], dp[i][k] + dp[k][j] + 1ll*a[i]*a[k]*a[j]);
        }
    g << dp[1][n+1];
    return 0;
}
