#include<bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int N, v[505];
pair<int,int> arr[505];
long long dp[505][505];
int main(){
    fin >> N; N++;
    for( int i = 1; i <= N; i++ )
        fin >> v[i];
    for( int i = 1; i < N; i++ ){
        arr[i].first = v[i];
        arr[i].second = v[i + 1];
    }
    N--;

    for( int i = 1; i <= N; i++ )
        dp[i][i] = 0;

    for( int lg = 2; lg <= N; lg++ ){
        for( int i = 1; i + lg - 1 <= N; i++ ){
            int j = i + lg - 1;
            long long r1 = 1LL * arr[i].first * arr[i].second * arr[j].second + dp[i + 1][j];
            long long r2 = 1LL * arr[i].first * arr[j].first * arr[j].second + dp[i][j - 1];
            dp[i][j] = min( r1, r2 );
        }
    }
    fout << dp[1][N] << "\n";
    return 0;
}
