#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n,i,l,st,dr,k;
unsigned long long dp[505][505],d[505];

int main()
{
    fin>>n;
    for(i=1; i<=n+1; i++)
        fin>>d[i];
    for(i=1; i<=n; i++)
        dp[i][i+1]=d[i]*d[i+1]*d[i+2];
    for(l=3; l<=n; l++)
        for(st=1, dr=l; dr<=n ; st++, dr++)
        {
            dp[st][dr]=-1;
            for(k=st; k<=dr; k++)
                dp[st][dr]=min(dp[st][dr],dp[st][k]+dp[k+1][dr]+d[st]*d[k+1]*d[dr+1]);
        }
    fout<<dp[1][n];
    return 0;
}
