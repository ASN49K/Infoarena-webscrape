#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

/**
4
     0 1  2 3  4
a = 13 5 89 3 34

A(1) are a[0] x a[1]
A(2) are a[1] x a[2]
A(3) are a[2] x a[3]
A(4) are a[3] x a[4]

A(i) x A(i+1) se fac a[i-1]*a[i]*a[i+1]

5*89*3 + 13*5*3 + 13*3*34

13*5*89 + 13*89*3 + 13*3*34

dp[i][j] = numarul minim de operatii care se
  efectueaza pentru a inmulti matricele
  i..j si obtinand o singura matrice
  de dim a[i-1] linii si a[j] coloane

Date initiale:
dp[i][i] = 0, i=1..n
dp[i][i+1] = a[i-1]*a[i]*a[i+1], i=1..n-1

Recurente:
dp[i][j] = min (
    dp[i][k] + dp[k+1][j] + a[i-1]*a[k]*a[j],
                ), k=i..j-1

A(4)*[A(5)*A(6)*A(7)*A(8)*A(9)]
[A(4)*A(5)]*[A(6)*A(7)*A(8)*A(9)]
[A(4)*A(5)*A(6)]*[A(7)*A(8)*A(9)]
[A(4)*A(5)*A(6)*A(7)*A(8)]*[A(9)]

dp[4][9] = dp[4][6] + dp[7][9] +
     a[3]* a[6] * a[9]
*/

int n;
long long dp[504][504], a[504];

int main()
{
    int i, j, k, d;
    long long M;
    cin >> n;
    for (i = 0; i <= n; i++)
        cin >> a[i];

    /// init:
    for (i = 1; i < n; i++)
        dp[i][i+1] = a[i-1]*a[i]*a[i+1];

    /// recurente:
    for (d = 2; d < n; d++)
        for (i = 1; i <= n - d; i++)
        {
            j = i + d;
            M = (1LL << 60);
            /// aflam dp[i][j]:
            for (k = i; k < j; k++)
                M = min(M, dp[i][k] + dp[k+1][j] + a[i-1]*a[k]*a[j]);
            dp[i][j] = M;
        }
    cout << dp[1][n];
    return 0;
}
