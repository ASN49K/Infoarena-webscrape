#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main() {

    ifstream in("podm.in");
    int n;
    in >> n;
    std::vector <int> v;
   // v.push_back(0);
    for (int i = 0; i < n + 1; i++) {
        int x;
        in >> x;
        v.push_back(x);
    }

    std::vector <std::vector<unsigned long long >> dp(n + 1,std::vector<unsigned long long>(n + 1));

    for (int i = 1; i <= n; i++) {
        dp[i][i] = 0;
    }

    for (int i = 1; i < n; i++) {
        dp[i][i + 1] = 1ULL * v[i - 1] * v[i] * v[i + 1];
    }

    for (int len = 2; len <= n; len++) {
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;
            for (int k = i; k < j; k++) {
                if (dp[i][j] != 0) {
                    dp[i][j] = std::min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1LL * v[i - 1] * v[k] * v[j]);
                } else {
                    dp[i][j] = dp[i][k] + dp[k + 1][j] + 1LL * v[i - 1] * v[k] * v[j];
                }
            }
        }
    }
    
    ofstream fout("podm.out");

    fout<<dp[1][n]<<"\n";

    in.close();
    fout.close();


}

