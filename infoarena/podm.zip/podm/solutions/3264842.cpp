#include <fstream>
#define int long long
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int v[505];
int d[505][505];
signed main()
{
    int n;
    cin >> n;
    n++;
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i];
    }
    for(int l = 2; l <= n; l++)
    {
        for(int i = 1; i <= n - l; i++)
        {
            int j = i + l;
            d[i][j] = d[i][i+1] + d[i+1][j] + v[i] * v[i+1] * v[j];
            for(int k = i+2; k <= j-1; k++)
            {
                d[i][j] = min(d[i][j], d[i][k] + d[k][j] + v[i] * v[k] * v[j]);
            }
        }
    }
    cout << d[1][n];
}