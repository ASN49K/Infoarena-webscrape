#include <bits/stdc++.h>

using namespace std;

ifstream ci ("podm.in");
ofstream co ("podm.out");

const int N=505;
long long v[N], d[N][N];

int main ()
{
    int n;
    long long r=0;
    ci >> n;
    for (int i=0; i<=n; i++)
    {
        ci >> v[i];
    }
    for (int i=1; i<n; i++)
    {
        d[i][i+1]=v[i-1]*v[i]*v[i+1];
    }
    for (int i=n-1; i>=1; i--)
    {
        for (int j=i+2 ; j<=n; j++)
        {
            r=(1LL<<60);
            for (int k=i; k<=j-1; k++)
            {
                r=min(r, d[i][k]+d[k+1][j]+v[i-1]*v[k]*v[j]);
            }
            d[i][j]=r;
        }
    }
    co << d[1][n] << "\n";
    return 0;
}
