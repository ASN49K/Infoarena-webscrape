#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long  d[504][504],a[504],n,j,p;
int main()
{
    fin>>n;
    n++;
    for(long long i=1;i<=n;i++)
        fin>>a[i];
    for(long long len=3;len<=n;len++)
    {
        for(long long i=1;i<=n-len+1;i++)
        {
            j=len+i-1;
            d[i][j]=1000000000;
            for(long long m=i+1;m<j;m++)
            {
                p=d[i][m]+d[m][j]+a[i]*a[m]*a[j];
                d[i][j]=min(d[i][j],p);
            }
        }
    }
    fout<<d[1][n];
    return 0;
}
