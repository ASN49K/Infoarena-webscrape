#include <fstream>
using namespace std;

#define FILE_NAME "podm"
ifstream in (FILE_NAME".in");
ofstream out(FILE_NAME".out");

const long long INF = 0x3f3f3f3f3f3f3f3f;
const int MAX_DIM = 512;
long long Mat[MAX_DIM][MAX_DIM];
long long Dim[MAX_DIM];
int N;

int main()
{
    in >> N;
    for(int i = 0; i <= N; ++i)
        in >> Dim[i];

    for(int d = 1; d <= N; ++d)
        for(int i = 1; i + d <= N; ++i)
        {
            Mat[i][i+d] = INF;
            for(int k = i; k < i + d; ++k)
                Mat[i][i+d] = min(Mat[i][i+d],
                                  Mat[i][k] + Mat[k+1][i+d] + Dim[i-1] * Dim[k] * Dim[i+d]);
        }

    out << Mat[1][N] << '\n';

    return 0;
}
