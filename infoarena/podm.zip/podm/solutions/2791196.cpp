#include <fstream>


using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long int n,dp[502][502];
long long int v[502];
int main()
{
    int n;
    fin >> n;
    for (int i = 0; i <= n; i++)
        fin >> v[i];
    for (int i = 0; i <= n; i++)
        for(int j=0; j<=n;j++)
        {
         dp[i][j]=10000000000;
        }
    for (int i = 0; i < n; i++)
        dp[i][i] = 0;
    for (int lg=1;lg<=n;lg++)
        for (int i = 0; i < n - lg + 1; i++)
        {
            int j = i + lg - 1;
            for (int k = i; k < j; k++)
            {
                auto val = dp[i][k] + dp[k + 1][j] + v[i] * v[k + 1] * v[j + 1];
                dp[i][j] = min(dp[i][j], val);
            }
        }
    fout<<dp[0][n - 1]<<'\n';
    return 0;
}
