#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long a[501][501];
int n,d[501];
long long mini;
int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
        fin>>d[i];
    for(int i=1;i<n;i++)
        a[i][i+1]=d[i]*d[i+1]*d[i+2];
    for(int j=2;j<n;j++)
         for(int i=1;i<=n-j;i++)
    {
        mini=(a[i][i]+a[i+1][i+j])+d[i]*d[i+1]*d[i+j+1];
      //  fout<<mini<<" ";
            for(int k=i+1;k<i+j;k++)
            {
                int aux=(a[i][k]+a[k+1][i+j])+d[i]*d[k+1]*d[i+j+1];
               if(mini>aux)
                    mini=aux;
            }
    //    fout<<mini<<" ";
        a[i][i+j]=mini;
    }
 //   fout<<endl;
  //  for(int i=1;i<=n;i++)
  //  {
  //      for(int j=1;j<=n;j++)
  //          fout<<a[i][j]<<" ";
  //      fout<<endl;
  //  }
    fout<<a[1][n];
    return 0;
}
