#include <bits/stdc++.h>
#define MAX 500 + 5
#define INF 4e9

using namespace std;

long long v[MAX], dp[MAX][MAX];
int main()
{
    ifstream fin("podm.in");
    ofstream fout("podm.out");

    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    srand(time(NULL));

    int n;

    fin >> n;

    for(int i = 1; i <= n + 1; i++)
        fin >> v[i];

    for(int i = 1; i <= n; i++)
        for(int j = i; j <= n; j++)
            if(i == j)dp[i][j] = 0;
            else if(i + 1 == j)dp[i][j] = v[i] * v[i + 1] * v[i + 2];
            else dp[i][j] = INF;

    for(int k = 2; k < n; k++)
        for(int i = 1; i <= n - k; i++)
            for(int j = i; j < i + k; j++)
                if(dp[i][i + k] > dp[i][j] + dp[j + 1][i + k] + v[i] * v[j + 1] * v[i + k + 1])
                    dp[i][i + k] = dp[i][j] + dp[j + 1][i + k] + v[i] * v[j + 1] * v[i + k + 1];

    fout << dp[1][n];

    fin.close();
    fout.close();

    return 0;
}
