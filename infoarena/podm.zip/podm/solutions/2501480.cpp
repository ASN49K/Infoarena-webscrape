#include <iostream>
#include <fstream>
#include <map>
#include <vector>

#define NMAX 502
#define MOD 1000000007
//#define f cin


using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

long long int dp[NMAX][NMAX];

struct Matrice {
    long long int lin, col;
}m[NMAX];
long long int n;

int main() {
    f >> n;
    f >> m[0].lin;
    for (long long int i = 0; i < n; ++i) {
        f >> m[i].col;
        m[i + 1].lin = m[i].col;
    }

    for (long long int dist = 1; dist < n; ++dist) {
        for (long long int i = 0; i + dist < n; ++i) {
            long long int vmin = 1e16;
            for (long long int k = i; k < i + dist; ++k) {
                vmin = min(vmin, dp[i][k] + dp[k + 1][i + dist] + m[i].lin * m[k].col * m[i + dist].col);
            }
            dp[i][i + dist] = vmin;
        }
    }

    g << dp[0][n - 1];

	return 0;
}
