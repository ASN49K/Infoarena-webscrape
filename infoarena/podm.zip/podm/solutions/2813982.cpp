#include <bits/stdc++.h>
#define NMAX 504
#define DMAX 10004

using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");

int n, pd[NMAX][NMAX], d[DMAX], cuts[NMAX][NMAX];
void parantezare();

int main()
{
    int i;
    fin>>n;
    for (i=0; i<=n; i++)
        fin>>d[i];
    parantezare();
    fout<<pd[1][n]<<'\n';
    return 0;
}

void parantezare()
{
    int i, j, dif, k;
    long long sum;
    for (i=1; i<=n; i++)
        pd[i][i]=0;
    for (i=1; i<n; i++)
        {
         pd[i][i+1]=d[i-1]*d[i]*d[i+1];
         cuts[i][i+1]=i;
        }
    for (dif=2; dif<n; dif++)
        for (i=1; i<=n-dif; i++)
            {
             j=i+dif;
             pd[i][j]=DMAX;
             for (k=1; k<j; k++)
                 {
                  sum=pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j];
                  if (sum<pd[i][j])
                     {
                      pd[i][j]=sum;
                      cuts[i][j]=k;
                     }
                 }
            }
}
/*
#include <fstream>
#define INF 1000000000000000

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long int a[502], dp[502][502];
int n, i, j, k, len;

int main()
{
    fin >> n;
    for(i=0; i<=n; i++)
        fin >> a[i];
    for(len=2; len<=n; len++)
        for(i=1, j=len; j<=n; i++, j++){
            dp[i][j] = INF;
            for(k=i; k<j; k++)
                dp[i][j]=min(dp[i][j], dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j]);
           }
    fout << dp[1][n];
    return 0;
}*/
