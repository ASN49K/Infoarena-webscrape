#include <bits/stdc++.h>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

const int N = 502;
int n, d[N];
long long dp[N][N];

int main(){
    f >> n;
    for(int i = 1; i <= n + 1; i++)
        f >> d[i];

    f.close();
    for(int i = 1; i <= n + 1; i++){
        for(int j = 1; j <= n + 1; j++)
            dp[i][j] = -1;
    }

    for(int i = 1; i <= n; i++)
        dp[i][i] = 0;

    for(int i = n; i >= 1; i--){
        for(int j = i + 1; j <= n + 1; j++){
            for(int k = i; k < j; k++){
                if(dp[i][j] == -1)
                    dp[i][j] = dp[i][k] + dp[k + 1][j] + (long long)(d[i] * d[k + 1] * d[j + 1]);
                else
                    dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + (long long)(d[i] * d[k + 1] * d[j + 1]));
            }
        }
    }

    g << dp[1][n];
    g.close();
}

