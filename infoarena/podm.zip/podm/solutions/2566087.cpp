#include <fstream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long n,v[510],d[510][510],i,j,k,l;

int main(){
    fin>>n;
    for(i=1;i<=n+1;i++)
        fin>>v[i];

    for(l=2;l<=n;l++){
        for(i=1;i+l-1<=n;i++){
            j=i+l-1;
            d[i][j]=1000000000000;

            for(k=i;k<j;k++)
                d[i][j]=min(d[i][j],d[i][k]+d[k+1][j]+v[i]*v[j+1]*v[k+1]);
        }
    }

    fout<<d[1][n];

    return 0;
}
