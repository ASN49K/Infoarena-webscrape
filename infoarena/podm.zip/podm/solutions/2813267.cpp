#include <fstream>
#define INF 1ll<<62
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long dp[505][505];
int v[505],n,l;
int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
        fin>>v[i];

    for(int i=1;i<n;i++)
        dp[i][i+1]=1ll*v[i]*v[i+1]*v[i+2];

    for(int l=3;l<=n;l++)
    {
        for(int i=1;i+l-1<=n;i++)
        {
            int j=i+l-1;
            dp[i][j]=INF;
            for(int k=i;k<=j-1;k++)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+1ll*v[i]*v[k+1]*v[j+1]);
        }
    }
    fout<<dp[1][n];
    return 0;
}
