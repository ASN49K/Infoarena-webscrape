#include <bits/stdc++.h>
#define ll long long
#define nl '\n'
#define FOR(i, a, b) for (int i = a; i <= b; ++i) 
#define F0R(i, a, b) for (int i = a; i >= b; --i)
#define FORd(i, n) for (int i = 0; i < n; ++i)
#define F0Rd(i, n) for (int i = n - 1; i >= 0; --i)
#define trav(a, x) for (auto &a : x)
#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int mxN = 5 * 1e2 + 5;
const ll INF = 1e18;

int N;
ll d[mxN], m[mxN][mxN]; // dp[i][j] = parantezare optima pe intervalul [i, j]

ifstream fin("podm.in");
ofstream fout("podm.out");

void solve() {
    fin >> N;
    for (int i = 1; i <= N + 1; ++i) {
        fin >> d[i];
    }
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= N; ++j) {
            m[i][j] = 1e5;
        }
    }
    for (int i = 1; i < N; ++i) {
        m[i][i] = 0;
        m[i][i + 1] = d[i] * d[i + 1] * d[i + 2];
    }
    m[N][N] = 0;
    for (int i = 1; i < N; ++i) {
        for (int j = i + 1; j <= N; ++j) {
            for (int k = i; k < j; ++k) {
                m[i][j] = min(m[i][j], m[i][k] + m[k + 1][j] + d[i] * d[k + 1] * d[j + 1]);
            }
        }
    }
    fout << m[1][N];
}

int main() {
    fin.tie(0); fout.tie(0);
    ios::sync_with_stdio(0);
    int T = 1;
//    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}
