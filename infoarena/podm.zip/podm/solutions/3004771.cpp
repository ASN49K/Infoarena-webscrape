#include <fstream>
#include <cmath>
#include <queue>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n,d[501],m[501][501];
int main()
{
    fin >> n;
    for(int i=0;i<=n;i++)
        fin >> d[i];
    for(int i=1;i<=n-1;i++)
    {
        m[i][i+1]=d[i-1]*d[i]*d[i+1];
    }
    for(int w=2;w<=n-1;w++)
    {
        for(int i=1;i<=n-w;i++)
        {
            int j=i+w;
            m[i][j]=100000000000;
                for(int k=i;k<j;k++)
                {
                    m[i][j]=min(m[i][k]+m[k+1][j]+d[i-1]*d[k]*d[j],m[i][j]);
                }
        }
    }
    fout << m[1][n];
    return 0;
}
