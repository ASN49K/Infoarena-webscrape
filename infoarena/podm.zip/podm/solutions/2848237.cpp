#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

/**
4
13 5 89 3 34

A1(13,5) x A2(5,89) x A(89,3) x A(3,34)

5*89*3 + 5*3*34 + 13*5*34

dp[i][j] = costul minim al produsului Ai x A[i+1] x ... A[j]

dp[i][i] = 0
dp[i][i+1] = a[i-1]*a[i]*a[i+1]

Rec:
dp[i][j] = min(dp[i][i] + dp[i+1][j] + a[i-1]*a[i]*a[j],
               dp[i][i+1] + dp[i+2][j] + a[i-1]*a[i+1]*a[j]
               ...
               dp[i][j-1] + dp[j][j] + a[i-1]*a[j-1]*a[j])

           min(dp[i][k-1] + dp[k][j] + a[i-1]*a[k-1]*a[j],
               k=i+1..j)
*/

long long dp[505][505];
int a[505], n;

int main()
{
    int i, j, k;
    long long x;
    fin >> n;
    for (i = 0; i <= n; i++)
        fin >> a[i];
    /// initializare:
    for (i = 1; i < n; i++)
        dp[i][i+1] = 1;
    for (i = n - 1; i >= 1; i--)
        for (j = i + 1; j <= n; j++)
        {
            x = 1LL << 60;
            for (k = i + 1; k <= j; k++)
                x = min(x, dp[i][k-1] + dp[k][j] + a[i-1]*a[k-1]*a[j]);
            dp[i][j] = x;
        }
    fout << dp[1][n] << "\n";
    fout.close();
    return 0;
}
