#include <bits/stdc++.h>
#define ios ios::sync_with_stdio(0); cin.tie(NULL); cout.tie(NULL)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define enter cout << '\n'

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
typedef vector <int> vi;
typedef vector <pii> vii;
typedef vector <ll> vl;
typedef vector <pll> vll;
typedef queue <int> qi;
typedef queue <pii> qii;
typedef queue <ll> ql;
typedef queue <pll> qll;

const int INF = 0x3f3f3f3f;
const int MOD = 100003;
const int MOD1 = 1e5 + 7;
const int MOD2 = 1e5 + 21;
const int BASE = 73;
const double EPSILON = 1e-10;
const int NMAX = 5e2 + 5;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
ll d[NMAX];
ll dp[NMAX][NMAX];

int main()
{
    fin >> n;
    for (int i = 0; i <= n; ++i)
        fin >> d[i];

    for (int i = 1; i < n; ++i)
        dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];

    for (int dist = 2; dist < n; ++dist)
        for (int i = 1; i < n; ++i)
        {
            int j = i + dist;
            dp[i][j] = INF;
            for (int k = i; k < j; ++k)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j]);
        }

    fout << dp[1][n];

    return 0;
}
