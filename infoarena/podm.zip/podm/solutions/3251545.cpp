#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

bool cmp(pair<int, int> &a, pair<int, int> &b)
{

    if (a.second > b.second)
    return a.second > b.second;

    else if (a.second == b.second)
        return a.first > b.first;
}


int main()
{
    int n;
    fin >> n;


    vector <int> a;

    int x;
    for (int i = 0; i <= n; i++)
    {
        fin >> x;
        a.push_back(x);
    }


    long long int cnt = 0;
    while (a.size() > 2)
    {
        int ma = -1e9;
        int poz = 0;
        for (int i = 0 ; i <a.size(); i++)
            if (i > 0 && a[i] > ma && i < a.size() - 1) {ma = a[i]; poz = i;}

        //cout << a[poz - 1] << ' ' << a[poz]    << "      " << a[poz] << ' ' << a[poz + 1] << endl;



        cnt += a[poz - 1] * a[poz] * a[poz + 1];
        a.erase(a.begin() + poz );

        //cout << "11111111111" << endl;
        //for (auto i : a) cout << i << ' ';
        //cout << endl << "1111111111111111" << endl;
    }


    fout << cnt;

}
