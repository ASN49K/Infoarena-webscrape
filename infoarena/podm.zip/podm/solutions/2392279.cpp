
#include <fstream>

using namespace std;
long long dp[505][505], d[505];

ifstream fin ("podm.in");
ofstream fout ("podm.out");

int main()
{
    int i, j, k, dif, n;
    fin >> n;
    for (i = 0; i <= n; i++)
        fin >> d[i];
    for (dif = 1; dif < n; dif++)
        for (i = 1; i <= n - dif; i++)
        {
            j = i + dif;
            dp[i][j] = (1LL << 60);
            for (k = i; k < j; k++)
                dp[i][j] = min (dp[i][j], dp[i][k] + dp[k + 1][j]
                                 + d[i - 1] * d[k] * d[j]);
        }
    fout << dp[1][n] << "\n";
    return 0;
}
