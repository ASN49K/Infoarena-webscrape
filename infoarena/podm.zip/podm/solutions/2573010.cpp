#include <bits/stdc++.h>
#define infile "podm.in"
#define outfile "podm.out"
#define NMAX 505
#define INF 100000000000000000LL

using namespace std;


long long n, v[NMAX], dp[NMAX][NMAX];
int main()
{
    freopen(infile, "r", stdin);
    freopen(outfile, "w", stdout);

    scanf("%d", &n);
    for (int i = 0; i <= n; i++)
    {
        scanf("%d", &v[i]);
    }
    for (int i = 1; i <= n; i++)
    {
        dp[i][i] = 0;
    }
    for (int i = 1; i <= n - 1; i++)
    {
        dp[i][i + 1] = v[i - 1] * v[i] * v[i + 1];
    }
    for (int w = 2; w < n; w++)
    {
        for (int i = 1; i <= n - w; i++)
        {
            int j = i + w;
            dp[i][j] = INF;
            for (int k = i; k <= j - 1; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
            }
        }
    }
    printf("%d", dp[1][n]);

    fclose(stdin);
    fclose(stdout);
    return 0;
}
