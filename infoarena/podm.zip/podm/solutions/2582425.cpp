#include <cstdint>
#include <fstream>
#include <limits>
#include <vector>

using namespace std;

int64_t Solve(const vector<int64_t> &sizes) {
    int n = sizes.size() - 1;
    vector<vector<int64_t>> cost(n, vector<int64_t>(n));

    for (int i = 0; i < n; i += 1) {
        cost[i][i] = 0;
    }

    for (int len = 2; len <= n; len += 1) {
        for (int i = 0; i + len - 1 < n; i += 1) {
            int j = i + len - 1;
            cost[i][j] = numeric_limits<int64_t>::max();

            for (int k = i; k < j; k += 1) {
                auto cost_left = cost[i][k];
                auto cost_right = cost[k + 1][j];
                auto cost_curr = sizes[i] * sizes[k + 1] * sizes[j + 1];

                cost[i][j] = min(cost[i][j],
                                 cost_left + cost_right + cost_curr);
            }
        }
    }
    return cost[0][n - 1];
}

int main() {
    ifstream fin("podm.in");
    ofstream fout("podm.out");

    int n;
    fin >> n;

    vector<int64_t> sizes(n + 1);
    for (auto &size : sizes) {
        fin >> size;
    }

    auto res = Solve(sizes);
    fout << res << "\n";

    return 0;
}
