#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
long long d[505], dp[505][505];

int main()
{
    int i, j, k, M, prod, dif;
    fin >> n;
    for(i = 0; i <= n; i++)
        fin >> d[i];
    for(i = 1; i <= n; i++)
        dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    for(dif = 1; dif < n; dif++)
        for(i = 1; i <= n - dif; i++)
        {
            M = 1E9;
            j = i + dif;
            for(k = i; k <= j - 1; k++)
            {
                prod = dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j];
                M = min(M, prod);
            }
            dp[i][j] = M;
        }
    fout << dp[1][n];
    return 0;
}
