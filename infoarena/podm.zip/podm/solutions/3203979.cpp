#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const long long NMAX = 502, INF = 99999999999999;
long long n, d[NMAX], dp[NMAX][NMAX];

long long min_chain(int i, int j){
    if(i == j) return 0;
    if(dp[i][j] != -1) return dp[i][j];
    dp[i][j] = INF;
    for(int k = i; k < j; k++) dp[i][j] = min(dp[i][j], min_chain(i, k) + min_chain(k + 1, j) + d[i - 1] * d[k] * d[j]);
    return dp[i][j];
}

int main()
{
    fin >> n;
    for(int i = 0; i <= n; i++) fin >> d[i];
    for(int i = 0; i <= n; i++)
        for(int j = 0; j <= n; j++)
            dp[i][j] = -1;
    fout << min_chain(1, n);
    return 0;
}
