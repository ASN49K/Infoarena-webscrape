#include <iostream>
#include <vector>
#include <cassert>
#include <fstream>


#define int long long

using namespace std;

constexpr int INF = 1e18 + 5;

pair<int, int> dims(int i, int j, vector<int>& d) {
  int n = d.size();
  assert(j < n-1);
  return {d[i], d[j+1]};
}

int cost(pair<int, int> d1, pair<int, int> d2) {
  // costul de a inmulti matricea i cu matricea j
  assert(d1.second == d2.first);
  return d1.first * d1.second * d2.second;
}

int32_t main() {
  ifstream fin("podm.in");
  ofstream fout("podm.out");

  int n;
  fin >> n;
  n++;

  vector<int> d(n, 0);
  for (int i = 0; i < n; i++) {
    fin >> d[i];
  }
  //                                   n2 = 3
  // n = 4 => avem n-1 matrice          |
  // M0        *     M1    *     M2
  // (d0 x d1) * (d1 x d2) * (d2 x d3)
  
  // avem nevoie de indicii (0..n-2) inclusiv

  // dp[i][j] = cel mai mic cost parantezand cat de bine posibil expresia dintre indicii i si j
  int n2 = n - 1;
  vector<vector<int>> dp(n2, vector<int>(n2, INF));

  for (int i = 0; i < n2; i++) dp[i][i] = 0;

  for (int gap = 1; gap < n2; gap++) {
    for (int i = 0; i + gap < n2; i++) {
      int j = i + gap;
      for (int k = i; k < j; k++) {
        dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + cost(dims(i, k, d), dims(k + 1, j, d)));
      }
    }
  }

  fout << dp[0][n2-1] << endl;
  return 0;
}