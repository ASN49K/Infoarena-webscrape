#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n, ii;
long long v[505];
long long d[505][505];

int main(){


      fin>>n;
      for(int i=0; i<=n; i++)
            fin>>v[i];

      for(int i=1; i<=n-1; i++)
            d[i][i + 1]=1LL * v[i-1] * v[i] * v[i + 1];


      for(int j=2; j<=n; j++)
            for(int i=1; i<=n-j; i++){

                  ii = i + j;
                  d[i][ii] = 4000000000005;

                  for(int k=i; k<=ii; k++)
                        d[i][ii]=min(d[i][ii], d[i][k] + d[k + 1][ii] + 1LL * v[i - 1] * v[k] * v[ii]);
            }

      fout<<d[1][n];
      return 0;
}
