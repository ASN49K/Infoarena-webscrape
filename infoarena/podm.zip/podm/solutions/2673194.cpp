#include <iostream>
#include <fstream>
#include <algorithm>
#define nmax 505
#define INF 100000000000000000LL

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

int n;
long long d[nmax], mat[nmax][nmax];

int main() {
    in >> n;
    for (int i = 0; i <= n; ++i)
        in >> d[i];

    for (int i = 1; i < n; ++i)
        mat[i][i + 1] = d[i - 1] * d[i] * d[i + 1];

    for (int q = 2; q < n; ++q)
        for (int i = 1; i <= n - q; ++i) {
            int j = i + q;
            mat[i][j] = INF;

            for (int k = i; k < j; ++k)
                mat[i][j] = min(mat[i][j], mat[i][k] + mat[k + 1][j] + d[i - 1] * d[k] * d[j]);
        }

    out << mat[1][n];
    return 0;
}
