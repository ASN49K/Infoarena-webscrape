#include "bits/stdc++.h"
using namespace std;
ifstream f ("podm.in");
ofstream g ("podm.out");
long long d[502][502],l[502],c[502],v[502];
int main ()
{
    int n,x,min1,d1,k;
    f>>n;
    for (x=1;x<=n+1;x++)
        f>>v[x];
    for (x=1;x<=n;x++)
    {
        l[x]=v[x];c[x]=v[x+1];
    }
    for (x=1;x<=n-1;x++)
    {
             d[x][x+1]=l[x]*c[x]*c[x+1];
    }
    for (d1=1;d1<=n-1;d1++)
    {
        for (x=1;x<=n-d1;x++)
        {
            min1=10000000;
            for (k=x;k<=x+d1-1;k++)
            {
                min1=min(min1,d[x][k]+d[k+1][x+d1]+l[x]*c[k]*c[x+d1]);
            }
            d[x][x+d1]=min1;
        }
    }
    g<<d[1][n];
    f.close ();
    g.close ();
    return 0;
}
