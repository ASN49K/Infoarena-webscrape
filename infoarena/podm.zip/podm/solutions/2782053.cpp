#include <iostream>
#include <fstream>
#include <deque>
#include <algorithm>
#include <map>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int INF = (1<<30);
const int N = 505;

int n,v[N];

long long DP[N][N];

int main()
{
    fin>>n;
    for(int i=0; i<=n; i++)
        fin>>v[i];

    for(int pas=2; pas<=n; pas++)
        {
            for(int i=1; i<=n-pas+1; i++)
                {
                    int j=i+pas-1;
                    DP[i][j]=INF;
                    for(int k=i; k<j; k++)
                        DP[i][j]=min(DP[i][j],DP[i][k]+DP[k+1][j]+v[i-1]*v[k]*v[j]);
                }
        }

    fout<<DP[1][n]<<'\n';
}
