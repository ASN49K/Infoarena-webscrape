#include <bits/stdc++.h>
#define ll long long
#define nl '\n'
#define FOR(i, a, b) for (int i = a; i <= b; ++i) 
#define F0R(i, a, b) for (int i = a; i >= b; --i)
#define FORd(i, n) for (int i = 0; i < n; ++i)
#define F0Rd(i, n) for (int i = n - 1; i >= 0; --i)
#define trav(a, x) for (auto &a : x)
#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int mxN = 5e2 + 5;
const int INF = 1e9 + 7;

ifstream fin("podm.in");
ofstream fout("podm.out");

void solve() {
    int n; fin >> n;

    vector<int> dim(n + 1);
    FOR(i, 0, n) {
        fin >> dim[i];
    }

    int dp[mxN][mxN];
    FORd(i, mxN) {
        FORd(j, mxN) {
            dp[i][j] = INF;
        }
        dp[i][i] = 0;
    }

    FORd(i, n - 1) {
        dp[i][i + 1] = dim[i] * dim[i + 1] * dim[i + 2];
    }

    for (int len = 2; len < n; ++len) {
        for (int i = 0; i + len < n; ++i) {
            int j = i + len;
            for (int k = i; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + dim[i] * dim[k + 1] * dim[j + 1]);
            }
        }
    }

    fout << dp[0][n - 1];
}

int main() {
    cin.tie(0); cout.tie(0);
    ios::sync_with_stdio(0);
    int T = 1;
    //cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}

