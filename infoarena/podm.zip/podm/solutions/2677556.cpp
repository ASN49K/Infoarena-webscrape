#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#define ll long long
using namespace std;

const int N = 505;

int n, x, y;
ll ans = 0;
vector<pair<int,int>> v;

int main() {
    ifstream fin("podm.in");
    ofstream fout("podm.out");

    fin >> n;

    fin >> x >> y;
    v.push_back(make_pair(x,y));
    for (int i = 1; i < n; ++i) {
        fin >> x;
        v.push_back(make_pair(y, x));
        y = x;
    }

    for (int i = 0; i < n; ++i)
      //  cout << v[i].first <<  " " << v[i].second << '\n';
    //cout << '\n';

    for (int i = 0; i <= n; ++i) {
        int p = 0;
        for (int j = 0; j < n - 1; ++j) {

            if(v[j].first * v[j].second * v[j+1].second < v[p].first * v[p].second * v[p+1].second)
                p = j;

        }
      //  cout << p << '\n';
        ans += v[p].first * v[p].second * v[p+1].second;
        v[p].second = v[p+1].second;

        for (int j = p + 1; j < n - 1; ++j) {
            v[j].first = v[j+1].first;
            v[j].second = v[j+1].second;
        }
        --n;

       // for (int j = 0; j < n; ++j)
        //    cout << v[j].first << " " << v[j].second << '\n';
       // cout << '\n' << '\n';

    }
    fout << ans << '\n';




    return 0;
}
