#include <bits/stdc++.h>
using namespace std;

/// infoarena.ro/problema/podm

ifstream fin("podm.in");
ofstream fout("podm.out");

/**
A1(d0, d1) x A2(d1, d2) x A3(d2, d3) x ... x An(d[n-1], dn)

d[i][j] = costul minim necesar pentrru a face produsul
    A(i) x A(i+1) x ... A(j)

Date initiale:
dp[i][i] = 0, i=1..n
dp[i][i+1] = d[i-1]*d[i]*d[i+1], i=1..n-1

Recurente:
dp[i][j] = min{dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j],k = i..j-1}

Sol: dp[1][n]
*/

long long dp[502][502];
int d[502], n;

int main()
{
    int i, j, k, dif;
    long long minn;
    fin >> n;
    for(i = 0; i <= n; i++)
        fin >> d[i];
    /// init:
    for(i = 1; i < n; i++)
        dp[i][i+1] = 1LL*d[i-1]*d[i]*d[i+1];
    /// recurente:
    for(dif = 2; dif < n; dif++)
        for(i = 1; i <= n - dif; i++)
        {
            j = i + dif;
            /// calculam dp[i][j]
            minn = (1LL << 60);
            for(k = i; k < j; k++)
                minn = min(minn, dp[i][k] + dp[k+1][j] + 1LL*d[i-1]*d[k]*d[j]);
            dp[i][j] = minn;
        }
    fout << dp[1][n] << "\n";
    return 0;
}
