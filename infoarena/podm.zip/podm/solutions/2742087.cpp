#include <iostream>
#include <algorithm>
#include <fstream>
#define N_MAX 505
#define INF 1e9
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int n;
long long matrix[N_MAX], dp[N_MAX][N_MAX];
void read();
void minOperations();
int main() {
	read();
	minOperations();
	g << dp[1][n];
	return 0;
}
void read(){
	f >> n;
	for (int i = 0; i <= n; i++)
		f >> matrix[i];
}
void minOperations(){
	for (int i = 1; i < n; i++)
		dp[i][i+1] = matrix[i-1] * matrix[i] * matrix[i+1];
	for (int range = 2; range < n; range++)
		for (int i = 1; i + range <= n; i++){
			int end = range + i;
			dp[i][end] = INF;
			for (int j = i; j < end; j++){
				long long matricesProduct = matrix[i-1] * matrix[j] * matrix[end];
				long long currentResult = dp[i][j] + dp[j+1][end] + matricesProduct;
				dp[i][end] = min(dp[i][end], currentResult);
			}
		}
}