#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long int x[501], dp[501][501];

int main()
{   int n;
    fin>>n;
    for(int i=1;i<=n+1;i++)
    fin>>x[i];

    for(int i=1;i<=n+1;i++)
    for(int j=1;j<=n+1;j++)
    dp[i][j]=2000000000000000;

    for(int i=1;i<=n+1;i++)
    dp[i][i]=0;

    for(int l=1;l<n;l++)
    for(int i=1;i+l<=n;i++)
    {int j=i+l;
     for(int k=i;k<j;k++)
     dp[i][j]=min(dp[i][j], dp[i][k]+dp[k+1][j]+x[i]*x[k+1]*x[j+1]);
    }

    fout<<dp[1][n];
    return 0;
}
