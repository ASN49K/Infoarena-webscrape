#include <bits/stdc++.h>
using namespace std;
const int NMAX = 500;
using ll = long long;

ifstream fin( "podm.in" );
ofstream fout( "podm.out" );

int d[NMAX+1];
ll dp[NMAX+1][NMAX+1];
int main() {
  int n, i, dist, k;
  fin >> n;
  for( i = 0; i <= n; i++ )
    fin >> d[i];
  for( i = 1; i <= n; i++ )
    dp[i][i] = 0;
  for( dist = 1; dist < n; dist++ ) {
    for( i = 1; i + dist <= n; i++ ) {
      dp[i][i+dist] = 1e18;
      for( k = i; k < i + dist; k++ )
        dp[i][i+dist] = min( dp[i][i+dist], dp[i][k] + dp[k+1][i+dist] + 1LL * d[i-1] * d[k] * d[i+dist] );
    }
  }
  fout << dp[1][n];
  return 0;
}
