#include <fstream>
#include <climits>
#define nmax 505
#define INF 9223372036854775800
using namespace std;
long long n,mx,v[nmax],dp[nmax][nmax];
int main()
{
    ifstream f ("podm.in");
    ofstream g ("podm.out");
    f>>n;
    n++;
    for (int i=1; i<=n; i++)
        f>>v[i];
    for (int d=1; d<n; d++)
    {
        for (int left=1; left<n-1; left++)
        {
            int right=left+d+1;
            dp[left][right]=INF;
            for (int mid=left+1; mid<right; mid++)
            {
                dp[left][right]=min(dp[left][right],dp[left][mid]+dp[mid][right]+v[left]*v[mid]*v[right]);
            }
        }
    }
    g<<dp[1][n];
}
