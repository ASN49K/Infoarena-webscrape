#include <bits/stdc++.h>

using namespace std;

using ll = int64_t;
const ll INF = 1e18;
bool ckmin(ll &a, ll b) { return (b < a ? a = b, 1 : 0); }

ifstream in("podm.in");
ofstream out("podm.out");

ll dp[505][505];

int main() {
 	int n;
 	in >> n;
	vector<ll> dim(n + 2);
	for(int i = 1; i <= n + 1; i++) {
	 	in >> dim[i];
	}
	for(int i = n; i >= 1; i--) {
		for(int j = i + 1; j <= n; j++) {
		 	dp[i][j] = INF;
		 	for(int k = i; k < j; k++) {
		 	 	ckmin(dp[i][j], dp[i][k] + dp[k + 1][j] + dim[i] * dim[k + 1] * dim[j + 1]);
		 	}
		}
	}
	out << dp[1][n] << '\n';
}