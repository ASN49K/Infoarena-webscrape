#include <fstream>
#define NMAX 505

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n;
int d[NMAX];
long long int nrmin[NMAX][NMAX];
int kmin[NMAX][NMAX];
void afisare(int i, int j)
{
  if (i==j) { fout<<"A"<<i; return; }
  int k=kmin[i][j];
  fout<<"(";
  afisare(i,k);
  afisare(k+1,j);
  fout<<")";
}
int main()
{int i, j, lg, k;
 fin>>n;
 for (i=0; i<=n; i++) fin>>d[i];
 //pd
 //initializare pentru 2 matrici
 for (i=1; i<n; i++) { nrmin[i][i+1]=d[i-1]*d[i]*d[i+1]; kmin[i][i+1]=i; }
 //rezolv relatia de recurenta bottom-up
 for (lg=3; lg<=n; lg++) //iau secventele de lungime lg
      for (i=1; i<=n-lg+1; i++) //secventa care incepe la pozitia i
          {
           j=i+lg-1; nrmin[i][j]=9e18;
           for (k=i; k<j; k++)
               if (nrmin[i][j]>nrmin[i][k]+nrmin[k+1][j]+d[i-1]*d[k]*d[j])
                  {nrmin[i][j]=nrmin[i][k]+nrmin[k+1][j]+d[i-1]*d[k]*d[j];
                   kmin[i][j]=k;
                  }
          }
 fout<<nrmin[1][n];
 //afisare(1,n);
 return 0;
}
