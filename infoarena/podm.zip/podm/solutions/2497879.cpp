#include <iostream>
#include <fstream>

#define NMAX 500

const long long INF = 1LL << 62;

std::ifstream fin ( "podm.in" );
std::ofstream fout ( "podm.out" );

long long a[1 + NMAX + 1];
long long dp[1 + NMAX][1 + NMAX];

int main() {

	int N;

	fin >> N;

	for ( int i = 1; i <= N + 1; ++i ) 
		fin >> a[i];


	for ( int i = N; i >= 1; --i ) { 

		//dp[i][i] = 0;
	
		for ( int j = i + 1; j <= N; ++j ) {

			dp[i][j] = INF;
		
			for ( int k = i ; k < j; ++k ) 
				dp[i][j] = std::min ( dp[i][j], dp[i][k] + dp[k + 1][j] + a[i] * a[k + 1] * a[j + 1] );
		}
	}
	
	fout << dp[1][N] << '\n';

	return 0;
}