


#include <fstream>

using namespace std;

ifstream fi("podm.in");
ofstream fo("podm.out");
int n;
long long x[502];
long long a[501][501];

long long Min(int st, int dr) {
    int k;
    long long vmin, aux;

    vmin = 1LL << 60;
    for (k = st; k <= dr - 1; k++) {
        aux = a[st][k] + a[k + 1][dr] + x[st] * x[k + 1] * x[dr + 1];
        if (aux < vmin)
            vmin = aux;
    }
    return vmin;
}

//    (st   k) * ((k + 1)    dr)

int main() {
    int l, d, i;

    fi >> n;
    // Dimensiunile matricii i sunt x[i] si x[i + 1].
    for (i = 1; i <= n + 1; i++)
        fi >> x[i];
    for (d = 1; d <= n - 1; d++)
        for (l = 1; l <= n - d; l++)
            a[l][l + d] = Min(l, l + d);
    fo << a[1][n];
    return 0;
}