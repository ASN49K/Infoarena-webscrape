#include <iostream>
#include <fstream>
using namespace std;

#define INF 10000000

ifstream fin("podm.in");
ofstream fout("podm.out");

int n,L[101],C[101],X[101][101];

int main()
{
    fin >> n;
    int i,j,k;
    fin >> L[1] >> C[1];
    for (i=2;i<=n+1;++i)
    {
        L[i]=C[i-1];
        fin >> C[i];

    }
    for (i=n-1;i>=1;--i)
    {
        for (j=i+1;j<=n;++j)
        {
            X[i][j]=INF;
            for (k=i;k<=j-1;++k)
            {
                X[i][j]=min(X[i][j],X[i][k]+X[k+1][j]+L[i]*C[k]*C[j]);
            }
        }
    }
    fout << X[1][n];
    return 0;
}

