#include <bits/stdc++.h>

std::ifstream fin("input.txt");
std::ofstream fout("output.txt");

const long long INF = LLONG_MAX / 2;

int main() {
    int n;
    fin >> n;

    std::vector<long long> p(n + 5);
    for(int i = 0; i <= n; ++i)
        fin >> p[i];
    
    // Numarul minim de inmultiri 
    // pentru a calcula produsul M[i] * M[i + 1] * ... * M[j]
    std::vector<std::vector<long long>> dp(n + 5, std::vector<long long>(n + 5, INF));

    // Cazuri particulare
    for(int i = 1; i <= n; ++i)
        dp[i][i] = 0, dp[i][i + 1] = p[i - 1] * p[i] * p[i + 1];

    for(int dif = 2; dif <= n - 1; ++dif) {
        for(int i = 1, j = i + dif; j <= n; ++i, ++j) {
            // Acum fixez pe rand care inmultire sa fie ultima 
            for(int k = i; k <= j - 1; ++k) {
                dp[i][j] = std::min(
                    dp[i][j],
                    dp[i][k] + dp[k + 1][j] + p[i - 1] * p[k] * p[j]
                );
            }
        }
    }

    fout << dp[1][n];
    return 0;
}