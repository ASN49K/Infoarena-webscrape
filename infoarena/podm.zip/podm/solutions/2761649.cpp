#include <bits/stdc++.h>
#define ll long long
#define nl '\n'
#define FOR(i, a, b) for (int i = a; i <= b; ++i) 
#define F0R(i, a, b) for (int i = a; i >= b; --i)
#define FORd(i, n) for (int i = 0; i < n; ++i)
#define F0Rd(i, n) for (int i = n - 1; i >= 0; --i)
#define trav(a, x) for (auto &a : x)
#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int mxN = 5 * 1e2 + 5;
const ll INF = 1e18;

ifstream fin("podm.in");
ofstream fout("podm.out");

ll n, d[mxN], dp[mxN][mxN];

void solve() {
    fin >> n;
    for (int i = 1; i <= n + 1; ++i) {
        fin >> d[i];
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            dp[i][j] = INF;
        }
    }
    for (int i = 1; i < n; ++i) {
        dp[i][i] = 0LL;
        dp[i][i + 1] = d[i] * d[i + 1] * d[i + 2];
    }
    dp[n][n] = 0LL;
    for (int i = n - 1; i >= 1; --i) {
        for (int j = i + 1; j <= n; ++j) {
            for (int k = i; k <= j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i] * d[k + 1] * d[j + 1]);
            }
        }
    }
    fout << dp[1][n];
}

int main() {
    cin.tie(0); cout.tie(0);
    ios::sync_with_stdio(0);
    int T = 1;
//    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}


//File adress: C:\Users\asusv

