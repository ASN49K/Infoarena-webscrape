#include <iostream>
#include <fstream>
using namespace std;
ifstream fi("podm.in");
ofstream fo("podm.out");
///PODM
int n;
int v_diag[503];
int dp[503][503];
int DP()
{
    for(int len=2;len<=n;len++)
    {
        for(int i=1;i+len-1<=n;i++)
        {
            int j=i+len-1;
            int mn=INT_MAX;
            for(int k=i;k<=j-1;k++)
                mn=min(mn,dp[i][k]+dp[k+1][j]+v_diag[i-1]*v_diag[k]*v_diag[j]);
            dp[i][j]=mn;
        }
    }
    return dp[1][n];
}
int main()
{
    fi>>n;
    for(int i=0;i<=n;i++)
        fi>>v_diag[i];
    for(int i=1;i<=n;i++)
        dp[i][i]=0;
    for(int i=1;i<n;i++)
        dp[i][i+1]=v_diag[i-1]*v_diag[i]*v_diag[i+1];
    fo<<DP();
    return 0;
}
