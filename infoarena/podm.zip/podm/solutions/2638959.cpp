#include <bits/stdc++.h>
using namespace std;

/**unsigned long long solve(vector<unsigned long long> d)
{
    if(d.size()==2)///one matrix
        return 0;
    else if(d.size()==3)///two
        return d[0]*d[1]*d[2];
    unsigned long long mn=ULLONG_MAX, x, y;
    for(unsigned unsigned long long i=1;i<=d.size()-2;i++)
    {
        x=solve(vector<unsigned long long>(d.begin(), d.begin()+i+1));
        y=solve(vector<unsigned long long>(d.begin()+i, d.end()));
        mn=min(mn, x+y+d[0]*d[d.size()-1]*d[i]);
    }
    return mn;
}
int main()
{
    unsigned long long n;///de matrici
    vector<unsigned long long> d;///indici

    ///input
    ifstream f("podm.in");
    f>>n;
    d.resize(n+1);
    for(unsigned long long i=0;i<=n;i++)
        f>>d[i];

    ///output
    ofstream g("podm.out");
    g<<solve(d);

    return 0;
}*/

unsigned long long **m;
unsigned long long solve(vector<unsigned long long> d)
{
    unsigned long long n=d.size()-1;
    for(unsigned long long i=0;i<n;i++)///single matrix
        m[i][i]=0;
    for(unsigned long long i=0;i<n-1;i++)///simple products
        m[i][i+1]=d[i]*d[i+1]*d[i+2];
    for(unsigned long long k=2;k<n;k++)
    {
        for(unsigned long long i=0;i<n-k;i++)///product minimum for i, i+k
        {
            unsigned long long mn=ULLONG_MAX;
            for(unsigned long long j=i+1;j<=i+k;j++)
            {
                unsigned long long cost=m[i][j-1]+m[j][i+k]+d[i]*d[j]*d[i+k+1];
                mn=min(mn, cost);
            }
            m[i][i+k]=mn;
        }
    }
    return m[0][n-1];
}
int main()
{
    unsigned long long n;///de matrici
    vector<unsigned long long> d;///indici

    ///input
    ifstream f("podm.in");
    f>>n;
    d.resize(n+1);
    m=(unsigned long long**)malloc(n*sizeof(unsigned long long*));
    for(unsigned long long i=0;i<n;i++)
        m[i]=(unsigned long long*)malloc(n*sizeof(unsigned long long));
    for(unsigned long long i=0;i<=n;i++)
        f>>d[i];
    f.close();

    unsigned long long res=solve(d);

    ///output
    ofstream g("podm.out");
    g<<res;
    g.close();
    return 0;
}
