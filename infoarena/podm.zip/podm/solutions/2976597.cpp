#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int N=500;
const long long MAX= 1 << 63;
long long dim[N+2], dp[N+1][N+1];

int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n+1; i++)
        in>>dim[i];
    for(int i=n; i>=1; i--)
        for(int j=i+1; j<=n; j++)
        {
            dp[i][j]=MAX;
            for(int k=i; k<j; k++)
                dp[i][j]=min(dp[i][j], dp[i][k] + dp[k+1][j] + (long long)dim[i]*dim[k+1]*dim[j+1]);
        }
    out<<dp[1][n];
    return 0;
}
