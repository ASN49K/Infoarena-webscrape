#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMax = 500;

int N, DP[NMax + 5][NMax + 5], V[NMax + 5];

int main()
{
    fin >> N;

    for(int i = 1; i <= N + 1; i++)
        fin >> V[i];

    for(int l = 2; l <= N; l++)
        for(int st = 1; st + l - 1 <= N; st++)
        {
            int dr = st + l - 1;

            DP[st][dr] = min(DP[st + 1][dr] + V[st] * V[dr + 1] * V[st + 1], DP[st][dr - 1] + V[dr] * V[st] * V[dr + 1]);
        }
    fout << DP[1][N] << '\n';

    fin.close();
    fout.close();

    return 0;
}
