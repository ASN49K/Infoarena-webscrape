#include <iostream>
#include <fstream>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <iterator>
#include <iomanip>
#include <cassert>

using namespace std;

struct matrix_size
{
  size_t width;
  size_t height;
};

int main() 
{
  ifstream in{"./podm.in"};
  ofstream out{"./podm.out"};

  size_t count;
  in >> count;

  vector<size_t> raw;
  raw.reserve(count);
  copy_n(istream_iterator<size_t>(in), count + 1, back_inserter(raw));

  vector<vector<size_t>> cost(count, vector<size_t>(count, 0));

  for (size_t d = 1; d < count; d++)
  {
    for (size_t i = 0, j = i + d; i < count - d; i++, j++)
    {
      size_t min_cost = -1;
      for (size_t k = i; k < j; k++)
      {
        min_cost = std::min(
          min_cost,
          cost[i][k] + cost[k + 1][j] + raw[i] * raw[k + 1] * raw[j + 1]);
      }

      cost[i][j] = min_cost;
    }
  }

  out << cost.front().back();
  return 0;
}
