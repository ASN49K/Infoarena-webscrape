#include <fstream>
#define NMAX 501
#define INF 199999999
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int Min(unsigned long long int a,unsigned long long int b);

unsigned long long int n,M[NMAX][NMAX];
unsigned long long int d[NMAX];


int main()
{
    fin>>n;
    for(int i=0; i<=n; i++)
    {
        fin>>d[i];
    }

    for(int i=1; i<=n; i++) M[i][i] = 0;
    for(int i=1; i<=n - 1; i++)  M[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    for(int w=2; w<=n - 1; w++)
        for (int i= 1;i<=n - w; i++)
        {
            int j = i + w;
            M[i][j] = INF;
            for(int k=i; k<= j - 1; k++)
                M[i][j] = Min(M[i][j], M[i][k] + M[k + 1][j] + d[i - 1] * d[k] * d[j]);
        }
        fout<<M[1][n];

    return 0;


}

int Min(unsigned long long int a,unsigned long longint b)
{
   if(a>b)return b;
   return a;
}
