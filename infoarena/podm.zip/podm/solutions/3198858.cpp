#include <fstream>
#include <climits>

using namespace std;

const int N = 500;

int dim[N+1], nr[N+1][N+1];

int produs(int i1, int i2, int i3)
{
    return dim[i1-1] * dim[i2] * dim[i3];
}

int main()
{
    ifstream in("podm.in");
    ofstream out("podm.out");
    int n;
    in >> n;
    for (int i = 0; i <= n; i++)
    {
        in >> dim[i];
    }
    for (int i = n - 1; i >= 1; i--)
    {
        for (int j = i + 1; j <= n; j++)
        {
            nr[i][j] = INT_MAX;
            for (int k = i; k < j; k++)
            {
                nr[i][j] = min(nr[i][j], nr[i][k] + nr[k+1][j] + produs(i, k, j));
            }
        }
    }
    out << nr[1][n] << "\n";
    in.close();
    out.close();
    return 0;
}
