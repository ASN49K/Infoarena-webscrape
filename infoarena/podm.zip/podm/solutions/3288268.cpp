#include <bits/stdc++.h>
#include <fstream>
using namespace std;
#define ull unsigned long long

ull podm(const vector<ull> &d, int n) {
    vector<vector<ull>> dp(n + 1, vector<ull>(n + 1, ULLONG_MAX));
    
    for (int i = 1; i <= n; i++) {
        dp[i][i] = 0ULL;
        if (i != n)
            dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    }
    for (int len = 2; len <= n; len++)
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;

            for (int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1ULL * d[i - 1] * d[k] * d[j]);
        }
    return dp[1][n];
}

int main()
{
    ifstream fin("podm.in");
    ofstream fout("podm.out");
    int n;
    vector<ull> d;

    fin >> n;
    d.resize(n + 1);
    for (int i = 0; i <= n; i++)
        fin >> d[i];
    fout << podm(d, n);

    return 0;
}
