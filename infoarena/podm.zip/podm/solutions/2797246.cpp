#include <fstream>
#include <cstring>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

long long v[509] ;

/// cautam cel mai mare element mereu si il scoatem parantezandul

int cauta_max(int n)
{
    int mn = INT_MAX, poz ;

    for(int f = 2 ; f < n ; f ++)
        if(v[f - 1] * v[f + 1] < mn)mn = v[f - 1] * v[f + 1], poz = f ;

    return poz ;
}

void scoate(int poz, int &n)
{
    for(int f = poz ; f <= n ; f ++)
        v[f] = v[f + 1] ;

    n -- ;
}

int main()
{
    int n ;

    cin >> n ;

    n ++ ;

    for(int f = 1 ; f <= n ; f ++)
        cin >> v[f] ;

    long long rez = 0 ;

    while(n > 2)
    {
        int poz = cauta_max(n) ;

        rez += v[poz] * v[poz - 1] * v[poz + 1] ;

        scoate(poz, n) ;
    }

    cout << rez ;

    return 0;
}

