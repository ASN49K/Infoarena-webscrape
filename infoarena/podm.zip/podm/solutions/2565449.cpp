#include <bits/stdc++.h>
#define inf 2000000000
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n,v[510],d[510][510],i,j,l,k;
int main() {
    fin>>n;
    n++;
    for (int i=1;i<=n;i++)
        fin>>v[i];
    for (l=3;l<=n;l++) {
        for (i=1;i+l-1<=n;i++) {
            j=i+l-1;
            d[i][j]=inf;
            for (k=i+1;k<j;k++)
                d[i][j]=min(d[i][j],d[i][k]+d[k][j]+v[i]*v[k]*v[j]);
        }
    }
    fout<<d[1][n];
    return 0;
}
