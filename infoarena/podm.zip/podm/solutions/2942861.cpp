#include <iostream>
#include <fstream>
#include <climits>
using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
long long dp[505][505];
int c[505];

int main()
{
    int n;
    f >> n;
    for(int i = 0 ; i <= n ; i++)
        f >> c[i];
    ///for (int i = 1 ; i <= n ; i++)
    ///dp[i][i] = 0; ///inmultirea de la matricea i la matricea i impune 0 operatii
    for(int lung = 2 ; lung <= n ; lung++)  ///ave, j - lung + 1 matrice de inmultit
        for(int i = 1, j = lung; j <= n ; i++, j++)
        {
            dp[i][j] = LONG_LONG_MAX;
            for(int k = i ; k < j ; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + c[i - 1] * c[k] * c[j]);
        }

    g << dp[1][n] << '\n';

    return 0;
}
