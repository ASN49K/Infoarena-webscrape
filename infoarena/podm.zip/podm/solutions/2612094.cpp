#include<cstdio>
#define MAX_N 500
#define oo 1000000000000000000
using namespace std;

long long dp[MAX_N+1][MAX_N+1];
long long d[MAX_N];
int n;

long long MatrixMultiplicationCost()
{
    long long q;
    for(int l=2; l < n; l++)
    {
        for(int i=1; i <= n - l + 1; i++)
        {
            int j = i + l - 1;
            dp[i][j] = oo;
            for(int k=i; k <= j - 1; k++)
            {
                q = dp[i][k] + dp[k+1][j] + d[i-1] * d[k] * d[j];
                if(q < dp[i][j])
                    dp[i][j] = q;
            }
        }
    }
    return dp[1][n-1];
}

int main()
{
    long long cost;
    FILE *fin, *fout;
    fin = fopen("podm.in","r");
    fout = fopen("podm.out","w");
    fscanf(fin,"%d",&n);
    n++;
    for(int i=0; i<n; i++)
        fscanf(fin,"%lld",&d[i]);
    cost = MatrixMultiplicationCost();
    fprintf(fout,"%lld\n",cost);
    fclose(fin);
    fclose(fout);
    return 0;
}
