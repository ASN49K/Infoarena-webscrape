#include<fstream>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
long long d[502][502];
int a[502];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<n+2;cin>>a[i++]);
    for(int i=n;i;--i)
        for(int j=i+1;j<=n;++j) {
            d[i][j]=1e18;
            for(int k=i;k<j;d[i][j]=min(d[i][j],d[i][k]+d[k+1][j]+a[i]*a[k+1]*a[j+1]),++k);
        }
    return cout<<d[1][n],0;
}
