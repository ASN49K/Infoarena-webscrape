//
//  main.cpp
//  Parantezare optima de matrici
//
//  Created by Andrei Bădulescu on 18.11.22.
//

//#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

const int N = 500;

long long matrix[N + 5][N + 5];
long long values[N + 2];
int n;

int main() {
    cin >> n;
    
    for (auto i = 1; i <= n + 1; i++) {
        cin >> values[i];
    }
    
    for (auto diff = 1; diff <= n - 1; diff++) {
        for (auto i = 1; i <= n - diff; i++) {
            auto j = i + diff;
            matrix[i][j] = LONG_LONG_MAX;
            
            for (auto k = i; k <= j - 1; k++) {
                matrix[i][j] = min(matrix[i][j], matrix[i][k] + matrix[k + 1][j] + values[i] * values[k + 1] * values[j + 1]);
            }
        }
    }
    
    cout << matrix[1][n];
    return 0;
}
