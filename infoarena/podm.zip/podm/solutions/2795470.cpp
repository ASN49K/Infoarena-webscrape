#include <iostream>
#include <fstream>
#include <climits>
#define NMAX 500

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
int cost[NMAX + 1];
long long dp[NMAX][NMAX];

int main()
{
    fin >> n;
    for (int i = 0; i < n + 1; ++i) fin >> cost[i];

    //dp[i][i] = 0

    int i, j, dif;
    for (dif = 1; dif < n; ++dif)
    for (i = 0; i < n - dif; ++i) {
        j = i + dif;
        dp[i][j] = LLONG_MAX;
        for (int k = i; k < j; ++k)
            dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1LL * cost[i] * cost[k + 1] * cost[j + 1]);
    }

    fout << dp[0][n - 1];

    fin.close();
    fout.close();
    return 0;
}
