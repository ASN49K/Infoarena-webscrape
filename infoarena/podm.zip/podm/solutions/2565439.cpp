#include<fstream>
using namespace std;
int n, i, j, ii, lg;
long long d[505][505], v[505];
ifstream fin("podm.in");
ofstream fout("podm.out");
int main(){
    fin>> n;
    n++;
    for(i = 1; i <= n; i++){
        fin>> v[i];
    }
    for(lg = 3; lg <= n; lg++){
        for(i = 1; i <= n - lg + 1; i++){
            j = i + lg - 1;
            d[i][j] = 10000000000000000LL;
            for(ii = i + 1; ii < j; ii++){
                d[i][j] = min(d[i][ii] + d[ii][j] + v[i] * v[j] * v[ii], d[i][j]);
            }
        }
    }
    fout<< d[1][n] <<"\n";
    return 0;
}
