#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

ifstream cin ("podm.in");
ofstream cout ("podm.out");

long long int n,k,i,j,l,r,mij,a[100005],nr,sum,b,c,d,bbit,cbit,dbit,dp[1005][1005],maxi,x,ok;

string s1,s2;
set<int> q;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>n;
    for(i=0; i<=n; i++)
        cin>>a[i];
    for(i=0; i+2<=n; i++)
        dp[i][i+2]=a[i]*a[i+1]*a[i+2];
    for(l=3; l<=n; l++)
        for(i=0; i+l<=n; i++)
        {
            j=i+l;
            dp[i][j]=1e18;
            for(k=i; k<=j; k++)
            {
                dp[i][j]=min(dp[i][j], dp[i][k]+dp[k][j]+a[i]*a[j]*a[k]);
            }
        }
    cout<<dp[0][n];
    return 0;
}
