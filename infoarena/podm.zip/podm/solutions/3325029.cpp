#include <fstream>

#define NMAX 502
#define INFINIT 1e18
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
unsigned long long int d[NMAX];
unsigned long long int nrmin[NMAX][NMAX];

int main()
{int i, j, k, lg;
 fin>>n;
 for (i = 0; i <= n; i++) fin>>d[i];
 //pd
 //initializare pentru 2 matrici
 for (i = 1; i < n; i++) nrmin[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
 //rezolv relatia de recurenta bottom-up
 for (lg = 3; lg <= n; lg++) //iau secventele de lungime lg
      for (i = 1; i <= n - lg + 1; i++) //secventa care incepe la pozitia i
          {
           j=i + lg - 1; nrmin[i][j]=INFINIT;
           for (k = i; k < j; k++)
               if (nrmin[i][j] > nrmin[i][k] + nrmin[k + 1][j] + d[i - 1] * d[k] * d[j])
                  {nrmin[i][j] = nrmin[i][k] + nrmin[k + 1][j] + d[i - 1] * d[k] * d[j];
                   nrmin[j][i]=k;
                  }
          }
 fout<<nrmin[1][n]<<'\n';
 return 0;
}
