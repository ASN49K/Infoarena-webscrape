#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int N = 505;

int v[N];
long long dp[N][N];

int main() {
    int n;
    in >> n;
    for (int i = 1; i <= n + 1; i++) {
        in >> v[i];
    }

    for (int i = n; i >= 1; i--) {
        for (int j = i + 1; j <= n; j++) {
            dp[i][j] = 1LL << 60;
            for (int k = i; k < j; k++) {

                long long q = dp[i][k] + dp[k + 1][j] + (long long) v[i] * v[k + 1] * v[j + 1];

                dp[i][j] = min(dp[i][j], q);

            }

        }

    }

    out << dp[1][n];


    return 0;

}