#include <fstream>
#include <climits>
#define dMAX 502
std::ifstream fin("podm.in");
std::ofstream fout("podm.out");
// dp[i][i] = 0 operatii
unsigned long long int dp[dMAX][dMAX];
int input[dMAX], n;
void init(){
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            dp[i][j] = ULLONG_MAX;
        }
    }
    for(int i = 1; i <= n; i++)
        dp[i][i] = 0;
}
void computeDp(){
    for(int k = 1; k < n; k++){
        for(int i = 1; i <= n - k; i++){
            for(int j = i; j < i + k; j++){
                dp[i][i+k] = std::min(dp[i][i+k], dp[i][j] + dp[j+1][i+k] + input[i-1] * input[j] * input[i+k]);
            }
        }
    }
}
int main()
{
    fin >> n;
    init();
    for(int i = 0; i <= n; i++){
        fin >> input[i];
    }
    for(int i = 1; i < n; i++){
        dp[i][i+1] = (input[i-1] * input[i] * input[i+1]);
    }
    computeDp();
    fout << dp[1][n];
    return 0;
}
