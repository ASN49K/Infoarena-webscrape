#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <map>
#define pb push_back
#define ll long long
using namespace std;
const int siz = 510;
int n;
const ll inf=LLONG_MAX-1;
ll d[siz],m[siz][siz];
int main()
{
    ifstream fin("podm.in");
    ofstream fout("podm.out");
    fin>>n;
    for(int i = 0 ; i <= n ;i++){
        fin>>d[i];
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
        m[i][j]=inf;
    }
    for(int i=1;i<=n;i++){
        m[i][i]=0;
    }
    int p;
    for(int i=1;i<=n-1;i++)
        for(int j=1;j<=n-i;j++){
        p=i+j;
        for(int k=j;k<=p-1;k++)
        {
            m[j][p]=min(m[j][p],m[j][k]+m[k+1][p]+1LL*d[j-1]*d[k]*d[p]);
        }
    }
    fout<<m[1][n];
    fin.close();
    fout.close();
    return 0;
}
