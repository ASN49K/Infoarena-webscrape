#include <fstream>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

#define NAGY 999999999

long long dp[505][505],n,x[505],i,j,k,l;

int main()
{
    cin>>n;
    for(i=1;i<=(n+1);++i) cin>>x[i];

    for(i=1;i<=n;++i)
    for(j=i+1;j<=n;++j)
    dp[i][j]=NAGY;

    for(l=1;l<n;++l)
    {
        for(i=1;i<=(n-l);++i)
        {
            j=i+l;
            for(k=i+1;k<=j;++k)
            {
                dp[i][j]=min(dp[i][k-1]+dp[k][j]+x[i]*x[k]*x[j+1],dp[i][j]);
            }
        }
    }

    /*for(i=1;i<=n;++i)
    {
        for(j=1;j<=n;++j)
            cout<<dp[i][j]<<" ";
        cout<<"\n";
    }*/

    cout<<dp[1][n]<<"\n";

    return 0;
}
