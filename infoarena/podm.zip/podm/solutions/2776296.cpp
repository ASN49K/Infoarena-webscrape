#include<fstream>
using namespace std;
ifstream F("podm.in");
ofstream G("podm.out");
long long a[501][501],m,d[501];
int i,n,j,k;
int main()
{
	F>>n;
	for(i=0;i<=n;++i)
       F>>d[i];
	for(i=1;i<n;++i)
       a[i][i+1]=d[i-1]*d[i]*d[i+1];
	for(j=2;j<n;++j)
        for(i=1;i<=n-j;++i)
            for(a[i][i+j]=1LL<<62,k=i;k<i+j;++k)
                if(a[i][i+j]>(m=a[i][k]+a[k+1][i+j]+d[i-1]*d[k]*d[i+j]))
                    a[i][i+j]=m;
	G<<a[1][n];
	return 0;
}
