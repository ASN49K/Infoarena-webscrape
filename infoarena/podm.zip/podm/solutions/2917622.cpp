#include <fstream>
#define MAX 601
using namespace std;

long long ans[510][510];
long long v[MAX];

int main(){
	ifstream fin;
	ofstream fout;
	fin.open("podm.in");
	fout.open("podm.out"); 
	int m, n, q, a, b;
	int i, j, k;
	int diff;

	fin >> n;
	for(i=1; i <= n+1; ++i){
		fin >> v[i];
	}

	for(diff = 2; diff <=n; ++diff){
		for(i = 1; i + diff <= n+1; ++i){
			{
				j = i + diff;
				if(j - i == 2){
						ans[i][j] =  v[i] * v[i + 1] * v[j];
				}
				else{
					long long current = 1000000000000;
					for(k = i + 1; k <= j - 1; ++k){
						
						current = min(current, ans[i][k] + ans[k][j] + v[i] * v[k] * v[j]);
						//fout << "collapse: " << i << j << " through: " << k << " ans: " << ans[i][k] + ans[k][j] + v[i] * v[k] * v[j] << endl;	
					}
					ans[i][j] = current;
				}
				//fout << "subproblem: " << i << j << " ans: " << ans[i][j] << endl;	
			}
		}
	}

	fout << ans[1][n + 1];

}