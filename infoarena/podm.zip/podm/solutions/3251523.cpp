#include <bits/stdc++.h>
#define int long long

using namespace std;
int n;
vector<vector<int>> dp (10005, vector<int>(10005, 1e9));
int d[10005];



signed main()
{

    ifstream cin("podm.in");
    ofstream cout("podm.out");

    cin >> n;
    for(int i = 0; i <= n; ++i)
    {
        cin >> d[i];
    }

    for(int i = 1; i <= n; ++i)
    {
        dp[i][i] = 0;
        if(i > 1)
        dp[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    }
    

    for(int i = 1; i <= n; ++i)
        for(int j = i + 2; j <= n; ++j)
        {
            
            
            for(int k = i; k < j; ++k)
            {
                //cout << dp[i][j] << ' ';
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j]);
            }
        }

    cout << dp[1][n];





    return 0;


}