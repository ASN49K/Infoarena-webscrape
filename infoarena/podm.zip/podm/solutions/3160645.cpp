#include <iostream>
#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

long long inf = 9e18;

long long d[502], n, minim[507][507];
int main()
{
    in >> n;
    for(int i = 1; i <= n + 1; i++)
        in >> d[i];

    for(int i=1; i<=n; i++)
        minim[i][i]=0;

    for(int i=1; i<n; i++)
        minim[i][i+1]= d[i]*d[i+1]*d[i+2];


    for(int p=3; p<=n; p++)
        for(int i=1, j=p; j<=n; i++, j++)
        {
            // Ai.......Ak * A(k+1) .....Aj
            // Ai    A(i+1)
            long long mini =inf;
            for(int k = i; k <= j - 1; k++)
                mini = min(mini, minim[i][k] + minim[k+1][j] + d[i]*d[k+1]*d[j+1]);

            minim[i][j] = mini;
        }

    out << minim[1][n];
    return 0;
}
