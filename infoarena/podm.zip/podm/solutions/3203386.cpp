
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int n;
vector<int> d;
int dp[501][501];
int main()
{
    cin>>n;
    d.resize(n+1);
    for(int i=0;i<=n;i++)
     cin>>d[i];
    for(int i=n;i>=1;i--)
    {
        dp[i][i]=0;
        for(int j=i+1;j<=n;j++)
        {
            dp[i][j]=0x3f3f3f3f;
            for(int k=i;k<j;k++)
              dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
        }
    }
    cout<<dp[1][n];
    return 0;
}
