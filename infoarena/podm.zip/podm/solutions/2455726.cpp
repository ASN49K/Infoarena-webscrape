#include <fstream>
#define inf 0x3f3f3f3f

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{
    int v[501], m[501][501], d, i, j, n;

    fin >> n;
    for(i = 0; i <= n; i++) fin >> v[i];

    for(i = 1; i <= n; i++) for(j = 1; j <= n; j++)
        if(i >= j) m[i][j] = 0; else m[i][j] = inf;

    for(d = 1; d < n; d++){
        for(i = 1; i <= n - d; i++){
            for(j = i; j < i + d; j++){
                m[i][i + d] = min(m[i][i + d], m[i][j] + m[j + 1][i + d] + v[i - 1]*v[j]*v[i + d]);
            }
        }
    }
    fout << m[1][n];
    return 0;
}
