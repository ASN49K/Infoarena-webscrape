#include<fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,i,j,k,l;
long long v[503],D[503][503];
int main(){
    fin>>n;
    for(i=1;i<=n+1;i++){
        fin>>v[i];
    }
    for(i=1;i<=n;i++){
        D[i][i+1]=0;
    }
    for(l=3;l<=n+1;l++){
        for(i=1;l+i-1<=n+1;i++){
            j=i+l-1;
            D[i][j]=2000000000000;
            for(k=i+1;k<j;k++){
                D[i][j]=min(D[i][j],D[i][k]+D[k][j]+v[k]*v[i]*v[j]);
            }
        }
    }
    fout<<D[1][n+1];
    return 0;
}
