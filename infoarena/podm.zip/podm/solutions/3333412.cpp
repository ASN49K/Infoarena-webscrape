#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n, pd[501][501] = {0}, vect[502], s = 10000001,i, j,x,k;

int main()
{
    fin>>n;
    for(int i=1; i<=n+1; i++){
        fin>>vect[i];
    }

    for(x=1; x<n; x++){
        for(i =1; i<=n; i++ ){
            j=i+x;
            s = 10000001;
            for(k = i; k<j; k++){
                s = min((pd[i][k] + pd[k+1][j] + vect[i]*vect[k+1]*vect[j+1]), s);
            }
            pd[i][j] = s;
        }
    }
    fout<<pd[1][n];
}
