#include <iostream>

using namespace std;

int main()
{
   int n,v[501],i,j,m[501][501],l,k;
   cin >> n;
   for(i=0;i<=n;i++)
   {
       cin >> v[i];
   }
   for(l=2;l<=n;l++)
   {
       for(i=1;i<=n-l+1;i++)
       {
           j=i+l-1;
           m[i][j]=INT_MAX;
           for(k=i;k<j;k++)
           {
               m[i][j]=min(m[i][j],m[i][k]+m[k+1][j]+v[i-1]*v[k]*v[j]);
           }
       }
   }
   cout << m[1][n];
}
