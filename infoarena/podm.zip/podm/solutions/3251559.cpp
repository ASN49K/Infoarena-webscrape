#include <fstream>

using namespace std;
ifstream cin ("podm.in");
ofstream cout ("podm.out");
int n,a[501];
unsigned long long dp[501][501];
int main()
{
    cin >> n;
    for (int i=0;i<=n;i++)cin  >> a[i];///Mi are dimensiunea a[i-1]*a[i]
    for (int i=2;i<=n+1;i++)
        dp[i][i+1]=a[i-1]*a[i]*a[i+1];///Mi * Mi+1
    for (int lung=2;lung<=n;lung++)
    {
        for (int i=1;i<=n-lung+1;i++)
        {
            unsigned long long val;//dp[i][i+lung]=1<<63;
            int dr=i+lung-1;
            dp[i][dr]=99999999;
            for (int j=i;j<dr;j++)
            {
                val=dp[i][j]+dp[j+1][dr]+a[i-1]*a[j]*a[dr];
                if(dp[i][dr]>val) dp[i][dr]=val;
            }
        }
    }
    cout << dp[1][n];
    return 0;
}
