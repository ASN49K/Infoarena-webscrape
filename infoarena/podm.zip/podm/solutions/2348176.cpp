#include <fstream>
#define inf 2000000000000
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,i,v[510],l,j,k,D[510][510];
int main(){
    fin>>n;
    n++;
    for(i=1;i<=n;i++)
        fin>>v[i];
    for(i=1;i<n;i++)
        D[i][i+1];
    for(l=3;l<=n;l++){
        for(i=1;i+l-1<=n;i++){
            j=i+l-1;
            D[i][i+l-1]=inf;
            for(k=i+1;k<j;k++)
                D[i][j]=min(D[i][k]+D[k][j]+v[i]*v[k]*v[j],D[i][j]);
        }
    }
    fout<<D[1][n];
    return 0;
}
