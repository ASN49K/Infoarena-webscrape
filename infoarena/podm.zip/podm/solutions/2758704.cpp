#include <bits/stdc++.h>

using namespace std;
/**
4
     0 1  2 3  4
a = 13 5 89 3 34

(A1 * (A2 * A3)) * A4

13*5*89 : 13 89 3 34
89*3*34 : 13 89 34
13*89*34 : 13 34

5*89*3 : 13 5 3 34
13*5*3 : 13 3 34
13*3*34 : 13 34
A(n,m) * B(m, p) = C(n, p)
n*n*p

dp[i][j] = costul minim al inmultirii matricelor A(i) * ... A(j)
Sol: dp[1][n]
Initial:
dp[i][i+1] = A(i)*A(i+1) = a[i-1]*a[i]*a[i+1]

Recurente:
dp[i][j] = min(dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j], k=i..j-1)
*/

int n;
long long dp[503][503], a[503];
ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{
    int i, j, k;
    long long m;
    fin >> n;
    for (i = 0; i <= n; i++)
        fin >> a[i];

    /// initializari:
    for (i = 1; i < n; i++)
        dp[i][i+1] = a[i-1]*a[i]*a[i+1];

    for (i = n - 1; i >= 1; i--)
        for (j = i + 2; j <= n; j++)
        {
            m = 1LL << 60;
            for (k = i; k < j; k++)
                m = min(m, dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j]);
            dp[i][j] = m;
        }
    fout << dp[1][n] << "\n";
    fout.close();
    return 0;
}
