#include <fstream>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int dp[501][501];
int d[501];
int n;
int main() {
    cin >> n;
    for(int i=0;i<=n;i++)
        cin >> d[i];
    for(int di=1;di<n;di++)
        for(int i=1;i<=n-di;i++)
        {
            int j=di+i;
            for(int k=i;k<=j-1;k++)
                if(!dp[i][j])
                    dp[i][j]=dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j];
                else
                    dp[i][j]=min(dp[i][j],dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j]);
        }
    /*for(int i=1;i<=n;i++,cout << '\n')
        for(int j=1;j<=n;j++,cout << ' ')
            cout << dp[i][j];*/
    cout << dp[1][n];
    return 0;
}
