#include <fstream>

using ull = unsigned long long;

std::ifstream fin("podm.in");
std::ofstream fout("podm.out");

ull n, *dim, *inmul;

int main() {
  ull i, j, k, dig;

  fin >> n;
  dim = new ull[n + 1];
  inmul = new ull[n * n];

  for (i = 0; i <= n; ++i) {
    fin >> dim[i];
  }

  for (i = 0; i < n; ++i) {
    inmul[i * n + i] = 0;
  }

  for (dig = 1; dig < n; ++dig) {
    for (i = 0, j = dig; j < n; ++i, ++j) {
      inmul[i * n + j] = -1;

      for (k = i; k < j; ++k) {
        ull nr;

        nr = inmul[i * n + k] + inmul [(k + 1) * n + j] + dim[i] * dim[k + 1] * dim[j + 1];
        if (nr < inmul[i * n + j]) inmul[i * n + j] = nr;
      }
    }
  }

  fout << inmul[n - 1] << '\n';

  delete dim;
  delete inmul;

  return 0;
}
