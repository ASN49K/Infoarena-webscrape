#include <fstream>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n, d[505], j;
long long dp[505][505];

void citire()
{
    fin>>n;
    for(int i=0; i<=n; i++)
        fin>>d[i];
}

long long min(int a, int b)
{
    if(a<=b)
        return a;
    else
        return b;
}

long long calcul()
{
    for(int i=1; i<=n; i++)
    {
        dp[i][i] = 0;
    }

    for(int m=1; m<n; m++)
    {
        for(int i=1; i<=n-m; i++)
        {
            j=m+i;
            dp[i][j]=INT_MAX;
            for(int k=i; k<j; k++)
            {
                dp[i][j]=min(dp[i][j], dp[i][k] + dp[k+1][j] + d[i-1] * d[k] * d[j]);
            }
        }
    }
    return dp[1][n];
}

int main()
{
    citire();
    fout<<calcul();
    return 0;
}
