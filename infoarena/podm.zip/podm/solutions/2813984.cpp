#include <fstream>
#define NMAX 504
#define INF 18446744073709551614
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");

int n,i,j,k,d[NMAX],dif;
unsigned long long int pd[NMAX][NMAX];

int main()
{
    cin>>n;

    for(i=0; i<=n; i++)
    {
        cin>>d[i];
    }

    for(i=1; i<n; i++)
        pd[i][i+1]=d[i-1]*d[i]*d[i+1];

    for(dif=2; dif<n; dif++)
    {
        for(i=1; i<=n-dif; i++)
        {
            j=i+dif;
            pd[i][j]=INF;
            {
                for(k=i; k<j; k++)
                {
                    pd[i][j]=min(pd[i][j],pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j]);
                }
            }
        }
    }

    cout<<pd[1][n];



    return 0;
}
