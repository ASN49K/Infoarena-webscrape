#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

unsigned long long n,Dim[501],PD[501][501],k,i,j,x;

int main()
{
   cin>>n;
   for(i=0;i<=n;i++)
        cin>>Dim[i];
   for(i=1;i<=n;i++) PD[i][i]=0;

    for(i=2;i<=n;i++)
        for(x=1;i+x-1<=n;x++) {
        unsigned long long s=100000001;
        j=i+x-1;
        for(k=x;k<j;k++)
    {
        s=min(PD[x][k]+PD[k+1][j]+Dim[x-1]*Dim[k]*Dim[j],s);
    }
    PD[x][j]=s;
        }
    cout<<PD[1][n];
}
