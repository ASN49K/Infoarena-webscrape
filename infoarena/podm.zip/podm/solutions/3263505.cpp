#include <bits/stdc++.h>

using namespace std;

const int N_MAX = 502;
const long long INF = LONG_LONG_MAX;
int N;
long long v[N_MAX];
long long dp[N_MAX][N_MAX]; /// dp[i][j] best sum from elem i to j

void SetInput(string name)
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    (void)!freopen((name + ".in").c_str(), "r", stdin);
    (void)!freopen((name + ".out").c_str(), "w", stdout);
}

void ReadInput()
{
    cin >> N;
    N++;
    for(int i = 1; i <= N; i++)
        cin >> v[i];
}

void Solve()
{
    /// Initialization
    for(int i = 1; i < N; i++)
        dp[i][i+1] = 0;

    for(int len = 3; len <= N; len++)
        for(int i = 1, j; i <= N - len + 1; i++)
        {
            j = i + len - 1;
            dp[i][j] = INF;
            for(int k = i+1; k <= j-1; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j] + v[i] * v[k] * v[j]);
        }

    cout << dp[1][N];
}

int main()
{
    SetInput("podm");

    ReadInput();
    Solve();

    return 0;
}
