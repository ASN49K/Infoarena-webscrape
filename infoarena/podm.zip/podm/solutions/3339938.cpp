#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int k,n,m,dp[505][505],x,y,v[505];

int compute(int c,int d)// d = nr de matr inmultite, c = ultima matrice din sirul de d matrici
{
    if(d==0)
        return 0;
    c+=d;
    unsigned int Min=-1;
    int i=c-d,j=c;

    for(int k=c-d;k<c;k++)
        if(Min>dp[i][k]+dp[k+1][j]+v[i]*v[k+1]*v[j+1])
            Min=dp[i][k]+dp[k+1][j]+v[i]*v[k+1]*v[j+1];

    return Min;
}
int main()
{
    fin>>n;
    for(int i=0;i<=n;i++)
        fin>>v[i];
    for(int d=0;d<n;d++)
        for(int c=0;c<n-d;c++)
        {
            dp[c][c+d]=compute(c,d);
        }
    fout<<dp[0][n-1];
    return 0;
}