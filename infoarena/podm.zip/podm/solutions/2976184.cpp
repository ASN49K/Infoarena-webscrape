#include <fstream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int N = 505;
const long long Infinit = 1e18;

int n;
long long dim[N+2],dp[N][N];

int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
    {
        fin>>dim[i];
    }

    for(int i=1;i<=n;i++)
    {
        dp[i][i] = 0;
    }


    for(int i=n;i>=1;i--)
    {
        for(int j=i+1;j<=n;j++)
        {
            dp[i][j]=Infinit;
            for(int k=i;k<j;k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1]);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
