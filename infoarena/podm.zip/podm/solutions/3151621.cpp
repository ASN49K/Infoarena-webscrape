#include <bits/stdc++.h>
using namespace std;

#define ll unsigned long long
#define fast_read ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL)
#define INF 0x3f3f3f3f3f3f

const int maxn = 1e3;
const int maxm = 2e5;
const int mod = 666013;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
ll d[maxn + 2];
ll dp[maxn][maxn];
void read(){
    fin >> n;
    for(int i = 1; i <= n + 1; ++i) fin >> d[i];
}
void solve(){
    for(int i = n - 1; i >= 1; --i){
        for(int j = i + 1; j <= n; ++j){
            dp[i][j] = INF;
            for(int k = i; k < j; ++k){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + (1ull * d[i] * d[k] * d[j + 1]));
            }
        }
    }
    fout << dp[1][n];
}
int main(){
    read();
    solve();
    return 0;
}
/*
task:

*/
