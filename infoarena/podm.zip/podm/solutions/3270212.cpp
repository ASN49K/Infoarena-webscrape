#include <bits/stdc++.h>

#define ll long long

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int nmax = 1e4;
const ll inf = 2e9;

int n;
ll d[nmax + 1];
ll dp[nmax + 1][nmax + 1];

void input()
{
    fin >> n;
    for(int i = 0; i <= n; i++)
        fin >> d[i];
}

void init()
{
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++)
            dp[i][j] = inf;
        dp[i][i] = 0;
    }
}

void solve()
{
    for(int l = 2; l <= n; l++) {
        for(int i = 1; i + l <= n + 1; i++) {
            int j = i + l - 1;
            for(int mid = i; mid < i + l - 1; mid++) {
                ll cnt = dp[i][mid] + dp[mid + 1][j] + d[i - 1] * d[j] * d[mid];
                dp[i][j] = min(dp[i][j], cnt);
            }
        }
    }
    fout << dp[1][n];
}

int main()
{
    input();
    init();
    solve();

    return 0;
}
