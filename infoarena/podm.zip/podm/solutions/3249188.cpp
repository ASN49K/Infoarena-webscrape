#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp> 
#define ll long long
#define ull unsigned long long
#define ld long double
#define chad char
#define mod 666013
#define dim 100005
#define lim 1000000
#define BASE 31
#define NMAX 21'005
#define FOR(i,a,b) for(int i=(a); i<=(b); i++)
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 
#define pii pair<int,int>
#define pb push_back
#define mp make_pair
#define nr_biti __builtin_popcount
using namespace __gnu_pbds; 
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
ull d[506];
ull dp[505][505];

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n;
    for(int i=0; i<=n; i++)
        fin >> d[i];
    
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            dp[i][j]=LLONG_MAX;

    for(int i=1; i<=n; i++)
        dp[i][i]=0;

    for(int len=2; len<=n; len++)
    {
        for(int st=1; st<=n-len+1; st++)
        {
            int dr=st+len-1;

            for(int p=st; p<dr; p++)
            {
                dp[st][dr]=min(dp[st][dr],dp[st][p]+dp[p+1][dr]+d[st-1]*d[p]*d[dr]);
            }
        }
    } 

    fout << dp[1][n];

    return 0;
}