#include <bits/stdc++.h>
using namespace std;
#define STOP fout.close(); exit(EXIT_SUCCESS);
ifstream fin("podm.in");
ofstream fout("podm.out");
///***********************
const int NMAX = 503;
using uint64 = unsigned long long;
int n;
struct {
    int rows, cols;
} a[NMAX];
uint64 dp[NMAX][NMAX];

void read() {
    int aux, curr;
    fin >> n >> aux;
    for (int i = 1; i <= n; i++) {
        fin >> curr;
        a[i] = {aux, curr};
        aux = curr;
    }
}

void solve() {
    for (int i = n; i; i--)
        for (int j = i + 1; j <= n; j++) {
            dp[i][j] = ULLONG_MAX;
            for (int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1ULL * a[i].rows * a[k].cols * a[j].cols);
    }
    fout << dp[1][n] << endl;
}

int main() {
    read();
    solve();
    STOP
}
