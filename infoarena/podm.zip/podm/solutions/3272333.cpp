#include <fstream>

using namespace std;

#define int long long

ifstream in("podm.in");
ofstream out("podm.out");
int n, m;
int v[505];
pair<int, int> w[505];
int dp[505][505];
int INF = (1LL << 60);

signed main()
{
    in>>n;
    n++;
    for(int i = 1; i<=n; i++)
    {
        in>>v[i];
    }

    for(int i = 2; i<=n; i++)
    {
        m++;
        w[m] = {v[i-1], v[i]};

        //out<<w[m].first<<" "<<w[m].second<<'\n';
    }

    for(int i = 1; i<=m; i++)
    {
        for(int j = i+1; j<=m; j++)
        {
            dp[i][j] = INF;
        }
    }

    for(int i = 1; i<m; i++)
    {
        dp[i][i + 1] = w[i].first * w[i].second * w[i + 1].second;
    }

    for(int l = 3; l<=m; l++)
    {
        for(int i = 1; i<=m-l+1; i++)
        {
            int j = i + l - 1;

            for(int k = i; k<j; k++) //unesc dp[i][k] cu dp[k + 1][j]
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + w[i].first * w[k].second * w[j].second);
            }
        }
    }

    out<<dp[1][m];

    return 0;
}
