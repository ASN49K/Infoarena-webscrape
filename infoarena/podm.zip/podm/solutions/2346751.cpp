#include <iostream>
#include <fstream>
#define NMAX 505
using namespace std;
ifstream fi("podm.in");
ofstream fo("podm.out");
pair<long long, long long> bounds[NMAX];
long long N;
long long Q[NMAX][NMAX];
int main()
{
    long long curr, previous;
    fi >> N;

    fi >> previous;
    for(int i = 1; i <= N; ++i)
    {
        fi >> curr;
        bounds[i] = {previous, curr};
        previous = curr;
    }
    for(int i = 1; i < N; ++i)
        Q[i][i+1] = bounds[i].first * bounds[i].second * bounds[i+1].second;

    for(int w = 2; w < N; ++w)
    {
        for(int i = 1; i <= N - w; ++i)
        {
            int j = i + w;
            Q[i][j] = (1LL << 60);
            for(int k = i; k <= j-1; ++k)
                Q[i][j] = min(Q[i][j], Q[i][k] + Q[k+1][j] + bounds[i].first * bounds[k].second * bounds[j].second);
        }
    }

    fo << Q[1][N];
}
