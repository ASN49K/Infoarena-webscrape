#include <fstream>
using namespace std;
ifstream cin ("podm.in");
ofstream cout ("podm.out");
#define INF 18446744073709551614
int n,i,k,j,r;
unsigned long long int dp[504][504],d[504];
int main()
{
    cin>>n;
    for(i=0;i<=n;i++)
    {
        cin>>d[i];
    }
    for(i=1;i<=n;i++)
        dp[i][i]=0;
    for(i=1;i<=n-1;i++)
        dp[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(r=2;r<=n-1;r++)
        for(i=1;i<=n-r;i++)
        {
            int j=i+r;
            dp[i][j]=INF;
            for(k=i;k<=j-1;k++)
            dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
    }
    cout<<dp[1][n];
    return 0;
}
