#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int n;
long long v[505], dp[505][505];
int main()
{
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n+1; i++)
    {
        cin >> v[i];
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            dp[i][j] = 1e9;
    }
    for (int l = 1; l <= n; l++)
    {
        for (int i = 1; i <= n - l + 1; i++)
        {
            int j = i + l - 1;
            if (i == j) dp[i][j] = 0;
            for (int k = i; k < j; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i] * v[k + 1] * v[j + 1]);
            }
        }
    }
    cout << dp[1][n];
    return 0;
}