#include <bits/stdc++.h>

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,d[502],dp[502][502],vmin,z,i,j;
int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
        fin>>d[i];

    for(int i=1;i<=n-1;i++)
        dp[i][i+1]=d[i]*d[i+1]*d[i+2];

    for(int di=3;di<=n;di++)
        for(i=1, j=di;j<=n;i++,j++)
    {
        vmin=9999999;
        for(int k=i;k<j;k++)
        {
            z=dp[i][k]+dp[k+1][j]+d[i]*d[k+1]*d[j+1];
            if(z<vmin)
                vmin=z;
        }
        dp[i][j]=vmin;
    }
    fout<<dp[1][n];
    return 0;
}
