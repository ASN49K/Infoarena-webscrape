#include <iostream>

#define MAX 10001

using namespace std;

int main() {
    int n, p[501];
    FILE *f = fopen("podm.in", "r");
    fscanf(f, "%d", &n);
    //scanf("%d", &n);
    int i;
    for (i = 0; i <= n; i++){
        fscanf( f, "%d", &p[i]);
    }
    fclose(f);
    int matrix[501][501];
    for(i = 1; i <= n; i++)
        matrix[i][i] = 0;
    for (i = 1; i <= n-1; i++){
        matrix[i][i+1] = p[i-1]*p[i]*p[i+1];
    }
    int d, k, cost;
    for (d = 2; d < n; d++){
        for (i = 1; i <= n-d; i++ ){
            matrix[i][i+d] = MAX;
            for (k = i; k <= i+d; k++){
                cost = matrix[i][k] + matrix[k+1][i+d]+p[i-1]*p[k]*p[i+d];
                if (matrix[i][i+d] > cost){
                    matrix[i][i+d] = cost;
                }
            }
        }
    }
    f = fopen("podm.out", "w");
    printf("%d", matrix[1][n]);
    fclose(f);
    return 0;
}
