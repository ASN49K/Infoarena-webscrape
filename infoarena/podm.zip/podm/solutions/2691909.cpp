//ALEXANDRU MICLEA
 
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <assert.h>
 
using namespace std;
using ll = long long;
 
#include <fstream>
//ifstream cin("input.in"); ofstream cout("output.out");
ifstream cin("podm.in"); ofstream cout("podm.out");
 
//VARIABLES

ll dp[505][505];

//FUNCTIONS
 


//MAIN
 
int main() {
    
    int n; cin >> n;
    vector <ll> v(n + 1);

    for (auto& x : v) cin >> x;
    
    for (int lung = 2; lung <= n; lung++){
        for (int i = 1, j = lung; j <= n; i++, j++){
            dp[i][j] = 1e18;
            for (int k = i; k < j; k++){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
            }
        }
    }

    cout << dp[1][n] << '\n';
    
    return 0;
}