﻿#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

long long p[505], n, dp[505][505];

int main(){

    in >> n;
    for (int i = 0; i <= n; i++)
        in >> p[i];

    for (int i = 1; i < n; i++)
        dp[i][i + 1] = p[i - 1] * p[i] * p[i + 1];

    for(int len = 2; len <= n - 1; len++)
        for (int i = 1; i <= n - len; i++) {
            dp[i][i + len] = 1e18;
            for (int k = i; k <= i + len - 1; k++)
                dp[i][i + len] = min(dp[i][i + len], dp[i][k] + dp[k + 1][i + len] + p[i - 1] * p[k] * p[i + len]);
        }

    out << dp[1][n];

    return 0;
}