#include <fstream>
#define mF "podm"
std::ofstream out(mF ".out");
std::ifstream in(mF ".in");
constexpr int N = 501; using L = long long;
L V[N][N]; int A[N]; int main()
{
    int n; in >> n; for (int i = 0; i <= n; i++) in >> A[i];
    for (int l = 2; l <= n; l++) for (int i = 0; i+l <= n; i++)
    {V[i][i+l] = (1LL<<63)-1; for (int k = i+1; k < i + l; k++)
    V[i][i + l] = std::min(V[i][i + l], V[i][k] + V[k][i + l]
        + (L)A[i] * A[k] * A[i+l]);}
    out << (*V)[n];
}
