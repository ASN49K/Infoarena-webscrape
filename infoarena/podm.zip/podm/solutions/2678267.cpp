#include <bits/stdc++.h>
#define ll long long
#define cin fin
#define cout fout
#define right left + add
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
ll v[550], minCost[550][550];

int main() {
    int n;

    cin >> n;
    for (int i = 0; i <= n; i++)
        cin >> v[i];

    for (int left = 1; left < n; left++)
        for (int add = 1; right <= n; add++)
            minCost[left][right] = LLONG_MAX;

    for (int add = 1; add < n; add++)
        for (int left = 1; right <= n; left++)
            for (int j = left + 1; j <= right; j++)
                minCost[left][right] = min(minCost[left][right], minCost[left][j - 1] + minCost[j][right] + v[left - 1] * v[right] * v[j - 1]);

    cout << minCost[1][n];

    return 0;
}
