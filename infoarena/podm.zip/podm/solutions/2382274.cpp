#include <iostream>
#include <fstream>
#include <climits>
#include <vector>


int main ()
{
	std::ifstream in("podm.in");
	std::ofstream out("podm.out");
	
	int N;
	in >> N;
	std::vector<long long> x(N+1);
	for (int i = 0; i <= N; ++ i)
		in >> x[i];
	in.close();
	
	std::vector<std::vector<long long> > d(N+1, std::vector<long long>(N+1, LLONG_MAX));
	d[N][N] = 0;
	for (int i = 1; i < N; ++ i) {
		d[i][i] = 0;
		d[i][i+1] = x[i-1] * x[i] * x[i+1];
	}
	
	for (int j = 2; j < N; ++ j) {
		for (int i = 1; i + j <= N; ++ i) {
			for (int k = i; k < i + j; ++ k) {
				if (d[i][i+j] > d[i][k] + d[k+1][i+j] + x[i-1] * x[k] * x[i+j]) {
					d[i][i+j] = d[i][k] + d[k+1][i+j] + x[i-1] * x[k] * x[i+j];
				}
			}
		}
	}
	
	out << d[1][N] << "\n";
	
	out.close();
	
	return 0;
}