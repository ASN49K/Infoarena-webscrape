#include <fstream>

using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

const int Dim = 1001;
long long M[Dim][Dim],D[Dim * 2],n;

int main() {
	
	fin >> n;
	++n;
	for ( int i = 1; i <= n; ++i)
		fin >> D[i];
	
	for(int i = 1; i <= n; ++ i)
        for(int j = i+2; j <= n; ++ j)
            M[i][j] = 1LL<<58;
     for ( int l = 3; l <= n; ++l)      
	for ( int i = 1; i <= n-l+1; ++i) {
		int j = i + l-1;
			for ( int k = i+1; k < j; ++k)
				M[i][j] = min(M[i][k] + M[k][j] + D[i]*D[k]*D[j],M[i][j]);
	}
	fout << M[1][n];
}
