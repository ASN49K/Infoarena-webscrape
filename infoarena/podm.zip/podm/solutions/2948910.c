#include <stdio.h>
#include <stdint.h>

void read_uint32_t(FILE *__restrict stream, uint32_t *__restrict nr) {
  uint8_t ch;
  *nr = 0;
  while ((ch = fgetc(stream)) && ('0' <= ch && ch <= '9')) {
    *nr *= 10;
    *nr += ch - '0';
  }
  if (ch == '\r') {
    fgetc(stream);
  }
}
uint32_t __inline__ __attribute((pure)) min(uint32_t o1, uint32_t o2) {
  return o1 < o2 ? o1 : o2;
}

uint32_t a[501];
uint32_t dp[501][501];
uint32_t n;

uint32_t gdp(uint32_t x, uint32_t y) {
  uint32_t mi = UINT32_MAX;
  int32_t i;
  for(i = y - x; i < y; ++i) {
    mi = min(mi, dp[y - x][i] + a[y - x] * a[i + 1] * a[y + 1] + dp[i + 1][y]);
  }
  return mi;
}

int main(void) {
  {
    FILE *__restrict in = fopen("podm.in", "r");
  
    read_uint32_t(in, &n);
    {
      int32_t i;
      for(i = 0; i <= n; ++i) {
        read_uint32_t(in, a + i);
      }
    }
  
    fclose(in);
  }

  {
    int32_t i;
    for(i = 1; i < n; ++i) {
      dp[i - 1][i] = a[i + 1] * a[i] * a[i - 1];
    }
  }

  {
    int32_t i, j;
    for (i = 2; i < n; ++i) {
      for (j = i; j < n; ++j) {
        dp[j - i][j] = gdp(i, j);
      }
    }
  }

  {
    FILE *__restrict out = fopen("podm.out", "w");
  
    fprintf(out, "%u\n", dp[0][n - 1]);
  
    fclose(out);
  }

  return 0;
}
