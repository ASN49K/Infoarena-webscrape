#include <bits/stdc++.h>
using namespace std;

const int Inf = 1000000000;
int n, dim[502];
long long dp[501][501];
ifstream in("podm.in");
ofstream out("podm.out");

int main()
{
	in >> n;

	for (int i = 1; i <= n + 1; i++)
		in >> dim[i];

	for (int i = 1; i < n; i++)
		for (int j = i + 1; j <= n; j++)
			dp[i][j] = Inf;

	for (int k = 1; k < n; k++)
		for (int i = 1, j = k + 1; j <= n; i++, j++)
			for (int mij = i; mij < j; mij++)
				dp[i][j] = min(dp[i][j], dp[i][mij] + dp[mij + 1][j] + dim[i] * dim[j + 1] * dim[mij + 1]);

	out << dp[1][n];
	return 0;
}