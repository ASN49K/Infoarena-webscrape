#include <fstream>

using namespace std;

ifstream fin( "podm.in" );
ofstream fout( "podm.out" );

const int NMAX = 505;
const int INF = 2000000000;

int N;
int l[NMAX], c[NMAX];

int dp[NMAX][NMAX];

void Read()
{
  fin >> N;

  fin >> l[1];

  for( int i = 2; i <= N + 1; ++i )
  {
    fin >> c[i - 1];
    l[i] = c[i - 1];
  }

  fin.close();
}

void Do()
{
  for( int i = 1; i < N; ++i )
    dp[i][i + 1] = l[i] * l[i + 1] * c[i + 1];

  for( int d = 2; d <= N; ++d )
  {
    int minn = INF;

    for( int i = 1; i + d <= N; ++i )
    {
      for( int j = i; j < i + d; ++j )
        minn = min( minn, dp[i][j] + dp[j + 1][i + d] + l[i] * l[j + 1] * c[i + d] );

      dp[i][i + d] = minn;
    }
  }

  fout << dp[1][N] << '\n';
}

int main()
{
    Read();
    Do();

    return 0;
}
