#include <cstdio>

using namespace std;

int dim[502];
long long best[502][502];


int main() {
	freopen("podm.in", "r", stdin);
	freopen("podm.out", "w", stdout);

	int n, next, cand;
	scanf("%d", &n);

	for(int i=0; i<=n; ++i)
		scanf("%d", &dim[i]);
	for(int i=1; i<n; ++i)
		best[i][i+1] = dim[i-1] * dim[i] * dim[i+1];

	for(int i=2; i<n; ++i)
		for(int j=1; j<=n-i; ++j) {
			next = i + j;
			best[j][next] = -1;

			for(int k=j; k < next; ++k) {
				cand = best[j][k] + best[k+1][next] + dim[j-1] * dim[k] * dim[next];
				if (best[j][next] == -1 || best[j][next] > cand)
					best[j][next] = cand;
			}

		}

	printf("%lld\n", best[1][n]);

	return 0;
}
