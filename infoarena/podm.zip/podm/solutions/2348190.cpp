#include<iostream>
#include<fstream>
#include<climits>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,v[510],d[510][510],j;
int main(){
    fin>>n;
    n++;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    for(int q=3;q<=n;q++){
        for(int i=1;i+q-1<=n;i++){
            j=i+q-1;
            d[i][j]=LONG_LONG_MAX;
            for(int k=i+1;k<j;k++)
                d[i][j]=min(d[i][j],(d[i][k]+d[k][j]+v[i]*v[k]*v[j]));
        }
    }

    fout<<d[1][n];



return 0;
}
