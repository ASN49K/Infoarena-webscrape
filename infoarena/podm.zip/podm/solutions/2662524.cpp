	
#include <fstream>
#include <algorithm>
#include <climits>
 
using namespace std;
 
ifstream f("podm.in");
ofstream g("podm.out");
 
int n;
long long dp[505][505], d[505];
 
int main()
{
 
    f>>n;
    for(int i=0; i<=n; i++)
        f>>d[i];
 
    for(int i=1; i<n; i++)
    {
        for(int j=1; i+j<=n; j++)
        {
            long long mini=LLONG_MAX;
            int x=j+i;
            for(int k=j; k<=x-1; k++)
            {
                mini=min(mini, dp[j][k]+dp[k+1][x]+d[j-1]*d[k]*d[x]);
            }
            dp[j][x]=mini;
        }
    }
    g<<dp[1][n];
    return 0;
}