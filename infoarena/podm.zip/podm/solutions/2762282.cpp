#include <fstream>
#include <deque>
#include <vector>
#include <bitset>
#include <queue>
#include <unordered_set>
#include <algorithm>
#include <cmath>
#include <cstring>

#define MOD 123457

using namespace std ;

ifstream cin ("podm.in") ;
ofstream cout ("podm.out") ;

pair<int, int> v[509] ;

long long dp[509][509] ;

int main()
{
    int n ;

    cin >> n ;

    cin >> v[1].first ;

    for(int f = 1 ; f <= n ; f ++)
    {

        cin >> v[f].second ;

        v[f + 1].first = v[f].second ;

    }

    for(int f = n ; f ; f --)
        for(int e = f ; e <= n ; e ++)
    {

        dp[f][e] = INT_MAX ;

        if(f == e)dp[f][e] = 0 ;
        else
        for(int k = f ; k <= e ; k ++)
            dp[f][e] = min(dp[f][k] + dp[k + 1][e] + v[f].first * v[k].second * v[e].second, dp[f][e]) ;

    }

    cout << dp[1][n] ;

    return 0 ;

}
