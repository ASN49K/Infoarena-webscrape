#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("podm.in");
ofstream fout("podm.out");
long long P[501][501];
long long S[501], N;

int main()
{
    fin >> N;
    for (int i=1; i<=N+1; i++)
        fin >> S[i];

    for (int i=1; i<N; i++)
    {
        P[i][i+1] = S[i]*S[i+1]*S[i+2];
    }

    for (int d=3; d<=N; d++)
    {
        for (int i=1, j=d; j<=N; i++,j++)
        {
            long long m = 9e18;
            for (int k=i; k<j; k++)
            {
                m = min(m, P[i][k] + P[k+1][j] + S[i] * S[k+1] * S[j+1]);
            }
            P[i][j] = m;
        }
    }

    fout << P[1][N];

    return 0;
}

