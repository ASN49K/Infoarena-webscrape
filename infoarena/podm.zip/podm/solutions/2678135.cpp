#include <bits/stdc++.h>
#define ll long long
#define cin fin
#define cout fout
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
ll v[550], dp[550][550];

int main() {
    int n;

    cin >> n;
    for (int i = 0; i <= n; i++)
        cin >> v[i];

    for (int i = 1; i < n; i++)
        for (int add = 1; add <= n - i; add++)
            dp[i][i + add] = LLONG_MAX;

    for (int i = 1; i < n; i++)
        dp[i][i + 1] = v[i - 1] * v[i] * v[i + 1];

    for (int add = 2; add < n; add++)
        for (int ind = 1; ind <= n - add; ind++)
            for (int j = ind + 1; j <= ind + add; j++) {
                dp[ind][add + ind] = min(dp[ind][add + ind], dp[ind][j - 1] + dp[j][ind + add] + v[ind - 1] * v[ind + add] * v[j - 1]);
            //    cout << "add: " << add << '\n' << "ind: " << ind << '\n' << "j: " << j << '\n' << "CURRENT TOTAL " << dp[ind][j - 1] + dp[j][ind + add] + v[ind - 1] * v[ind + add] * v[j - 1] << '\n';
            }

    cout << dp[1][n];

    return 0;
}
