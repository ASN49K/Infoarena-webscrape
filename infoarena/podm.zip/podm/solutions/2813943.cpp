#include <fstream>
#define DMAX 502
#define NMAX 100000000
using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");
int n, i, j, k, dif;
long long int sum;
long long int pd[DMAX][DMAX];
long long int d[DMAX];

int main()
{ fin>>n;
for(i=0; i<n+1; i++) {fin >> d[i]; }

for(i=1; i<=n; i++)
{ pd[i][i]=0;}
for(i=1; i<=n; i++)
 pd[i][i+1]=d[i-1]*d[i]*d[i+1];

for(dif=2; dif<n; dif++)
for(i=1; i<=n-dif; i++)
{j=i+dif; pd[i][j]=NMAX;
    for(k=1; k<=n-1; k++)
    {sum = pd[i][k]+pd[k+1][j]+(d[i-1]*d[k]*d[j]);
      pd[i][j]=min(sum, pd[i][j]);
    }

  }
    fout<<pd[1][n]<<'\n';

    return 0;
}
