#include <iostream>
#include <fstream>
#define NMAX 510
#define oo 999999999999
#define min(a,b) a<b?a:b

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
long long d[NMAX];
long long m[NMAX][NMAX];

long long ParantezareMinima() {
	// conditii initiale
	for (int i = 1; i <= n - 1; i++)
	{
		m[i][i] = 0;
		m[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
	}
	m[n][n] = 0;

	long long currentNo;
	long long currMin;
	// parcurgere pe diagonale
	for (int diag = 2; diag <= n - 1; diag++) {

		// pt fiecare linie
		for (int i = 1; i <= n - diag; i++) {

			int j = i + diag;

			m[i][j] = oo;
			// pt fiecare coloana
			for (int k = i; k <= j - 1; k++) {
				currentNo = m[i][k] + m[k+1][j] + d[i-1] * d[k] * d[j];
				m[i][j] = min(currentNo, m[i][j]);
			}

			/*
			cout << "m = \n";
			for (int l = 1; l <= n; l++) {
				for (int j = 1; j <= n; j++) {
					cout << m[l][j] << " ";
				}
				cout << '\n';
			}
			cout << '\n';
			*/
		}

	}


	return m[1][n];
}


int main() {
	fin >> n;
	for (int i = 0; i < n + 1; i++)
		fin >> d[i];


	fout << ParantezareMinima() << '\n';
	//cout << "Solutie parantezare optima: " << ParantezareMinima() << '\n';
	/*
	cout << "m = \n";
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cout << m[i][j] << " ";
		}
		cout << '\n';
	}
	cout << '\n';
	*/

	return 0;
}