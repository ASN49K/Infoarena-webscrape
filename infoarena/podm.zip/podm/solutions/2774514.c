#include<stdio.h>
long long a[501][501],m,d[501];
int i,n,j,k;
int main()
{
	freopen("podm.in","r",stdin),freopen("podm.out","w",stdout),scanf("%d",&n);
	for(i=0;i<=n;++i)
       scanf("%d",d+i);
	for(i=1;i<n;++i)
       a[i][i+1]=d[i-1]*d[i]*d[i+1];
	for(j=2;j<n;++j)
        for(i=1;i<=n-j;++i)
            for(a[i][i+j]=1LL<<62,k=i;k<i+j;++k)
                if(a[i][i+j]>(m=a[i][k]+a[k+1][i+j]+d[i-1]*d[k]*d[i+j]))
                    a[i][i+j]=m;
	printf("%lld",a[1][n]);
	return 0;
}
