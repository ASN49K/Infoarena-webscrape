#include <stdio.h>
#include <bits/stdc++.h>

#define rep(i, n) for(int i = 0; i < (int)(n); i++)

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
const int INF = 0x3f3f3f3f;

ifstream fin ("podm.in");
ofstream fout ("podm.out");
const int Nmax = 505;
int n, a[Nmax];
ll dp[Nmax][Nmax];

ll go(int l, int r) {
  if (l == r) { return 0; }
  if (dp[l][r] != -1) { return dp[l][r]; }

  ll mx = 1e16;
  for(int k = l; k < r; k++) {
    mx = min(1ll*a[l-1]*a[k]*a[r] + go(l, k) + go(k+1, r), mx);
  }
  return dp[l][r] = mx;
}

int main(void) {
  // freopen("podm.in", "r", stdin);
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(NULL);
  fin >> n;
  rep(i, n+1) {
    fin >> a[i];
  }
  rep(i, n+1)
  rep(j, n+1)  {
    dp[i][j] = -1;
  }

  ll ans = go(1, n);
  fout << ans << endl;

  return 0;
}
