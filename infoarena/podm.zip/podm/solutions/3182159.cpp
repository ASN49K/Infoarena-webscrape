#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
long long d[550];

long long dp[550][550];

void din()
{
    for(int diag=1; diag<n; diag++)
    {
        for(int i=1; i<=n-diag; i++)
        {   int j=diag+i;
            for(int k=i; k<=j-1; k++)
            {   if(dp[i][j]!=0)
                dp[i][j]=min(dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j], dp[i][j]);
                else
                dp[i][j]=dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j];
            }
        }
    }
}

int main()
{
    fin >> n;
    for(int i=0; i<=n; i++)
        fin >> d[i];
    din();
    fout << dp[1][n];
    return 0;
}
