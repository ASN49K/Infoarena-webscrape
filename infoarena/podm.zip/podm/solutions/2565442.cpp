#include <bits/stdc++.h>
#define INF 2000000000000000000LL
using namespace std;
long long dp[510][510];
long long v[510];
int main()
{
    FILE *fin = fopen ("podm.in","r");
    FILE *fout = fopen ("podm.out","w");
    int n , i , j , k , d;
    fscanf (fin,"%d",&n);
    for (i=0;i<=n;i++)
        fscanf (fin,"%lld",&v[i]);
    /// v[i-1] si v[i] = dimensiuni matrice i

    /// dp[i][j] = nr inmultiri i..j

    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++)
            dp[i][j] = INF;
        dp[i][i] = 0;
    }

    for (d = 2 ; d <= n ; d++){
        for (i = 1 ; i + d - 1 <= n ; i++){
            j = i + d - 1;

            for (k = i ; k < j ; k++){
                /// produse i..k si k + 1 .. j

                dp[i][j] = min(dp[i][j] , dp[i][k] + dp[k+1][j] + v[k] * v[i-1] * v[j] );

            }

        }
    }
    fprintf (fout,"%lld",dp[1][n]);
    return 0;
}
