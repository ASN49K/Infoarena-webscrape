#include <fstream>
#define dim 510
#define INF 1LL*(1<<30)
using namespace std;
long long d[dim][dim];
long long a[dim];
long long b[dim];
long long i,j,k,n,val,len;

int main() {
    ifstream fin("podm.in");
    ofstream fout("podm.out");
    fin>>n;
    n++;
    for (i=1;i<=n;i++) {
        fin>>a[i];
    }
    for (len=3;len<=n;len++) {
        for (i=1;i<=n-len+1;i++) {
            j=len+i-1;
            val=INF;
            for (k=i+1;k<j;k++) {
                val=min(val,d[i][k]+d[k][j]+(a[i]*a[k]*a[j]));
            }
            d[i][j]=val;
        }
    }
    fout<<d[1][n];//<<" "<<INT_MAX<<" "<<INF;
    return 0;
}
