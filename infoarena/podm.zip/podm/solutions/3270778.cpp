#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{

    long long n;
    fin>>n;

    vector<pair<long long,long long>>a(n);
    vector<long long>mm(n+1);
    vector<vector<long long>>dp(n+2,vector<long long>(n+2,1e9));

    for(long long i=0;i<=n;i++){
        dp[i][i] = 0;
        fin>>mm[i];
    }

    for(long long i=0;i<n;i++){
        a[i] = {mm[i],mm[i+1]};
    }

    for(long long l = 1; l<=n;l++){

        for(long long i=0;i<=n-l;i++){

            long long j = i + l;

            for(long long k=i;k<=j;k++){

                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + a[i].first * a[k].second * a[j].second);
            }
        }
    }

    fout<<dp[0][n-1];

    return 0;
}
