#include <bits/stdc++.h>
#define NMAX 505
#define INF LLONG_MAX

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
long long d[NMAX];
long long dp[NMAX][NMAX]; // dp[i][j] - [i, j)

long long solve(int i, int j) {
    if (dp[i][j]) {
        return dp[i][j]; // calculata precedent
    }

    if (j - i == 1) {
        return 0;
    }

    long long mini = INF;
    for (int k = i + 1; k <= j - 1; k++) {
        mini = min(mini, solve(i, k) + solve(k, j) + 1ll * d[i] * d[k] * d[j]);
    }

    dp[i][j] = mini;
    return mini;
}

int main() {
    f >> n;
    for (int i = 1; i <= n + 1; i++) {
        f >> d[i];
    }
    
    g << solve(1, n + 1);

    return 0;
}