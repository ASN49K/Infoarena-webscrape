#include <iostream>
#include <fstream>
#include <climits>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int d[505],n;
long long a[100][100];

void pd()
{
    for(int i=n-1;i>=1;i--)
    {
        for(int j=i+2;j<=n;j++)
        {
            long long s,minn=LLONG_MAX;
            for(int k=i;k<j;k++)
            {
                s=a[i][k]+a[k+1][j]+d[i]*d[k+1]*d[j+1];
                if(s<minn)
                {
                    minn=s;
                }
            }
            a[i][j]=minn;
        }
    }
}
void afis()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            fout<<a[i][j]<<" ";
        }
        fout<<'\n';
    }
}
int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
    {
        fin>>d[i];
    }
    for(int i=1;i<=n;i++)
    {
        a[i][i+1]=d[i]*d[i+1]*d[i+2];
    }
    pd();
    //afis();
    fout<<a[1][n];
    return 0;
}

