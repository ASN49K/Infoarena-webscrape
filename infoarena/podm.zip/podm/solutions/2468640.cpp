#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
#define nmax 510
#define maxim 2000000000
#define ll long long
ll n,v[nmax][nmax],vec[nmax];
ll minim(ll inc,ll sf){
    ll nr_minim=maxim;
    for(ll k=inc;k<sf;k++){
        nr_minim=min(nr_minim,v[inc][k]+v[k+1][sf]+vec[inc-1]*vec[k]*vec[sf]);
    }
    return nr_minim;
}
int main()
{
    f>>n;
    for(int i=0;i<=n;i++){
        f>>vec[i];
    }
    for(int i=1;i<n;i++){
        v[i][i]=0;
        v[i][i+1]=vec[i-1]*vec[i]*vec[i+1];
    }
    for(int d=2;d<n;d++){
        for(int i=1;i<=n-d;i++){
            v[i][i+d]=minim(i,i+d);
        }
    }
    g<<v[1][n];
    return 0;
}
