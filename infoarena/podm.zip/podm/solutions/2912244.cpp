#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int maxn = 501;
const long long inf = 99999999999999999L;

long long dp[maxn][maxn], minn;
int dim[maxn], nrMat, k, d, i;


int main()
{
    fin >> nrMat;
    for (i = 0; i <= nrMat; ++i){
        fin >> dim[i];
    }
    for (i = 1; i <= nrMat-1; ++i){
        dp[i][i] = 0;
        dp[i][i+1] = 1LL * dim[i-1]*dim[i]*dim[i+1];
    }
    dp[nrMat][nrMat] = 0;
    for (d = 2; d <= nrMat; ++d){
        for (i = 1; i + d <=nrMat; ++i){
            minn = inf;
            for (k = i; k < i+d; ++k)
                minn = min(minn, 0LL + dp[i][k]+dp[k+1][i+d]+dim[i-1]*dim[k]*dim[i+d]);
            dp[i][i+d] = minn;
        }
    }
    fout << dp[1][nrMat];
    return 0;
}
