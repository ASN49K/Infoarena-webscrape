#include <fstream>
#define NMax 505
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long int m[NMax],i,j,n,dp[NMax][NMax];
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>m[i];
    for (i = 1; i < n; i++) {
        dp[i][i + 1] = m[i - 1] * m[i] * m[i + 1];
    }
    for(int len = 2; len < n; len++) {
        for (i = 1; i <= n - len; i++) {
            j = i + len;
            dp[i][j] = 1e18;
            for (int k = i; k < j; k++) {
                dp[i][j] = min(dp[i][j], m[i - 1] * m[k] * m[j] + dp[i][k] + dp[k + 1][j]);
            }
        }
    }
    fout << dp[1][n];
    return 0;
}
