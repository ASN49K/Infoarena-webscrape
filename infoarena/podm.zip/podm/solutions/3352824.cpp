#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#define NMAX 505

using namespace std;
ifstream in("podm.in");
ofstream out("podm.out");

long long dp[NMAX][NMAX];
long long v[NMAX];
const long long INF = 2e16 + 7;

int main() {
    int n;
    in >> n;
    for (int i = 0; i <= n; ++i)
        in >> v[i];

    for (int i = 0; i <= n; ++i) {
        for (int j = 0; j <= n; ++j) {
            dp[i][j] = INF;
        }
    }

    for (int i = 1; i < n; ++i) {
        dp[i][i + 1] = v[i - 1] * v[i] * v[i + 1];
        dp[i][i] = 0;
    }
    dp[n][n] = 0;

    for (int dif = 2; dif <= n; ++dif) {
        for (int i = 1; i + dif <= n; ++i) {
            int j = i + dif;
            for (int k = i; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i - 1] * v[k] * v[j]);
            }
        }
    }

    /*for (int i = 0; i <= n; ++i) {
        for (int j = 0; j <= n; ++j) {
            out << dp[i][j] << " ";
        }
        out << '\n';
    }*/

    out << dp[1][n] << '\n';
    return 0;
}