#include <fstream>

std::ifstream f("podm.in");
std::ofstream g("podm.out");

const long long INF = (1LL << 61);
const int NMAX = 505;
long long n,v[NMAX],D[NMAX][NMAX];

int main(){
    
    f >> n;
    
    n++;
    for(int i = 1;i <= n;++i)
        f >> v[i];
    
    for(int len = 3;len <= n;++len){
        for(int i = 1;i + len - 1 <= n;++i){
            
            int j = i + len - 1;
            
            D[i][j] = INF;
            for(int k = i + 1;k < j;++k){
                
                if(D[i][j] > D[i][k] + D[k][j] + v[i] * v[j] * v[k])
                    D[i][j] = D[i][k] + D[k][j] + v[i] * v[j] * v[k];
            }
        }
    }
    
    g << D[1][n];
    
    return 0;
}
