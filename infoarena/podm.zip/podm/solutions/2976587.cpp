/*
  Lefter Sergiu - 09/02/2023
*/
#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int N = 1000;
const long long INF = 9223372036854775807;

int n, dim[N+2];
long long dp[N+1][N+1];

int main() {
    in >> n;
    for (int i = 1; i <= n + 1; ++i) {
        in >> dim[i];
    }
    for (int i = n - 1; i >= 1; --i) {
        for (int j = i + 1; j <= n; ++j) {
            dp[i][j] = INF;
            for (int k = i; k < j; ++k) {
                long long rez = dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1];
                if (rez < dp[i][j]) {
                    dp[i][j] = rez;
                    dp[j][i] = k;
                }
            }
        }
    }
    out << dp[1][n] << '\n';
    in.close();
    out.close();
    return 0;
}