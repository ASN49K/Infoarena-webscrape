#include <bits/stdc++.h>

using namespace std;
#define cin f
#define cout g
#define NMAX 1010
ifstream f("podm.in");
ofstream g("podm.out");
long long int dp[NMAX][NMAX], dim[NMAX], n, mn=NMAX;

int main()
{
    cin>>n;
    for(int i=1;i<=n+1;i++)
    {
        cin>>dim[i];
    }
    for(int p=1;p<n;p++)
    {
        for(int i=1;i<=n-p;i++)
        {
            mn=100000000;
            int j=p+i;
            if(j>n)
                j=n;
            for(int k=i;k<j;k++)
            {
                dp[i][j]=dp[i][k]+dp[k+1][j]+dim[i]*dim[k+1]*dim[j+1];
                mn=min(mn, dp[i][j]);
            }
            dp[i][j]=mn;
        }
    }
    cout<<(dp[1][n]);

    return 0;
}
