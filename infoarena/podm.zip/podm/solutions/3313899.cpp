#include <fstream>
#define int long long
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

int mat[505][505];
int v[505];

signed main()
{
    int n, x, y;
    cin>>n;
    for(int i=1; i<=n+1; i++)
    {
        cin>>v[i];
    }
    for(int i=1; i<n; i++)
    {
        mat[i][i+1]=v[i]*v[i+1]*v[i+2];
    }
    for(int j=3; j<=n; j++)
    {
        x=1;
        y=j;
        while(y<=n)
        {
            mat[x][y] = 500000000000005;
            for(int i=x; i<=y-1; i++)
            {
                mat[x][y]=min(mat[x][y], mat[x][i]+mat[i+1][y]+v[x]*v[i+1]*v[y+1]);
            }
            x++;
            y++;
        }
    }
    cout<<mat[1][n];


    return 0;
}
