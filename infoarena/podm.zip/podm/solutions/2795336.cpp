#include <fstream>
#include <climits>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

int n;
long long d[505], dp[505][505];

void citire() {
    f >> n;
    for (int i = 0; i <= n; ++i)
        f >> d[i];
}

void dinamica() {
    for (int lg = 1; lg < n; ++lg) {
        int imax = n - lg;
        for (int i = 1; i <= imax; ++i) {
            int j = i + lg;
            dp[i][j] = LLONG_MAX;
            for (int k = i; k < j; ++k)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + d[i - 1] * d[k] * d[j]);
        }
    }
}

int main() {
    citire();
    dinamica();
    g << dp[1][n];
    return 0;
}
