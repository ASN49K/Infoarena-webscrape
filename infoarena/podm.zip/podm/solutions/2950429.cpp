#include <bits/stdc++.h>

using namespace std;

ifstream f ("podm.in");
ofstream g ("podm.out");

int n;
long long mt[505][505];
struct el
{
    long long lin;
    long long col;
};
el a[505];
long long v[505];

int main()
{
    f>>n;
    for(int i=1; i<=n+1; ++i)
        f>>v[i];

    a[1].lin=v[1];
    a[1].col=v[2];
    for(int i=2; i<=n; ++i)
    {
        a[i].lin=v[i];
        a[i].col=v[i+1];
    }
    for(int i=1; i<=n; ++i)
        for(int j=i; j<=n; ++j)
            mt[i][j]=INT_MAX;
    for(int i=1; i<=n; ++i)
        mt[i][i]=0, mt[i][i+1]=a[i].lin*a[i].col*a[i+1].col;

    for(int dif=2; dif<n; ++dif)
        for(int i=1; i+dif<=n; ++i)
        {
            int j=i+dif;
            for(int k=i; k<j; ++k)
            {
                mt[i][j]=min(mt[i][j], mt[i][k]+mt[k+1][j]+a[i].lin*a[k].col*a[j].col);
            }
        }

    g<<mt[1][n];

    return 0;
}
