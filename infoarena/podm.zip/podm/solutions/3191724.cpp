#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int MAX_N = 502;
long long memo[MAX_N][MAX_N];
int dims[MAX_N];

const long long INF = 1e18;

long long f_dp(int i, int j) {
    if (memo[i][j] != 0) {
        return memo[i][j];
    }

    if (i == j) {
        return 0;
    }

    long long minn = INF;
    for (int k = i; k < j; k++) {
        long long q = f_dp(i, k) 
            + f_dp(k + 1, j) 
            + dims[i - 1] * dims[k] * dims[j];

        minn = min(minn, q);
    }

    memo[i][j] = minn;
    return minn;
}

int main() {

    int n;

    fin >> n;
    for (int i = 0; i <= n; i++) {
        fin >> dims[i];
    }

    fout << f_dp(1, n);

    return 0;
}