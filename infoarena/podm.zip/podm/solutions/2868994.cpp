#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int MAX=505;
const int INF=1e17;
long long n,dp[MAX][MAX],d[MAX];

int main()
{
    fin >> n;
    for(int i=0;i<=n;i++)
        fin >> d[i]; /// Mi (d[i-1],d[i])
    for(int l=1;l<=n;l++)
        for(int i=1,j=i+l;j<=n;i++,j++)
        {
            dp[i][j]=INF;
            for(int k=i;k<j;k++) /// (Mi...Mk)(Mk+1...Mj)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
        }
    fout << dp[1][n];
    return 0;
}
