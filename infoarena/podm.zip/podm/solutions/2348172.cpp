#include <fstream>
#include <limits.h>
#define INF LONG_LONG_MAX
using namespace std;

ifstream fin ("podm.in");
ofstream fout("podm.out");

int n,i,j,k,l,v[505];
long long D[505][505];

int main(){
    fin>>n;n++;
    for (i=1;i<=n;i++)
        fin>>v[i];
    /*for (i=1;i<n;i++)
        D[i][i+1]=0;*/
    for (l=3;l<=n;l++)
        for (i=1;i+l-1<=n;i++){
            j=i+l-1;
            D[i][j]=INF;
            for (k=i+1;k<j;k++)
                D[i][j]=min(D[i][j],D[i][k]+D[k][j]+v[i]*v[k]*v[j]);
        }
    fout<<D[1][n];
    fin.close();
    fout.close();
    return 0;
}
