#include <fstream>

using namespace std;
int n,i,j,r;
long long d[505][505],v[505];
const long long inf=1000000000000000000;
int main()
{
    ifstream f("podm.in");
    ofstream g("podm.out");
///d[i][j]=costul minim de a inmulti matricea i cu matricea i+1...cu j.
    f>>n;
    for(i=1;i<=n+1;i++)
    f>>v[i];

    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    d[i][j]=inf;
    for(i=1;i<=n;i++)
    d[i][i]=0;
    for(i=1;i<n;i++)
    d[i][i+1]=v[i]*v[i+1]*v[i+2];

    for(r=2;r<n;r++)
    for(i=1;i+r<=n;i++)
    for(j=i;j<i+r;j++)
    if( (d[i][j]+d[j+1][i+r]+v[i]*v[j+1]*v[i+r+1])<d[i][i+r] )
        d[i][i+r]=d[i][j]+d[j+1][i+r]+v[i]*v[j+1]*v[i+r+1];

    g<<d[1][n];


    return 0;
}
