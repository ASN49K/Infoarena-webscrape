#include<bits/stdc++.h>

using ll = long long;
const int INF = 1e9;

using namespace std;

    ifstream f("podm.in");
    ofstream g("podm.out");

int main()
{
    ll n;
    f>>n;
    vector<ll> d(n + 1);
    for(ll &x : d){
        f>>x;
    }

    ll m[n + 1][n + 1];

    for(ll i = 1 ; i <= n ; i++){
        m[i][i] = 0;
    }
    for(ll i = 1 ; i <= n - 1 ; i++){
        m[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    }

    for(ll w = 2 ; w < n ; w ++){
        for(ll i = 1 ; i <= n - w ; i++){
            ll j = i + w;
            m[i][j] = INF;
            for(ll k = i ; k < j ; k++){
                m[i][j] = min(m[i][j], m[i][k] + m[k + 1][j] + d[i - 1] * d[k] * d[j]);
            }
        }
    }

    g<<m[1][n];

    return 0;
}
