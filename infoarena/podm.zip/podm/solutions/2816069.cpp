#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{
    int n, i, j, k, L;
    fin>>n;
    n++;
    long long d[502][502], a[502];
    for(i=1; i<=n; i++)
        fin>>a[i];
    for(i=1; i<=n; i++)
        d[i][i+1]=0;
    for(L=3; L<=n; L++)
    {
        for(i=1; i+L-1<=n; i++)
        {
            j=i+L-1;
            d[i][j]=INT_MAX;
            for(k=i+1; k<=j-1; k++)
                d[i][j]=min(d[i][j], a[i]*a[k]*a[j]+d[i][k]+d[k][j]);
        }
    }
    fout << d[1][n];
    return 0;
}
