#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>

#include <iomanip>

#define int long long

using namespace std;

string filename = "podm";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 500;
const int INF = 1e18;

int dp[NMAX + 1][NMAX + 1];

struct Matrix{
    int l, c;
}v[NMAX + 1];

int aux[NMAX + 1];

signed main(){

    int n;
    fin >> n;

    for(int i = 1; i <= n + 1; i++){
        fin >> aux[i];
    }

    for(int i = 1; i <= n; i++){
        v[i] = {aux[i], aux[i + 1]};
    }

    for(int len = 1; len <= n; len++){
        for(int i = 1; i + len <= n; i++){
            int j = i + len;
            if(len == 1){
                dp[i][j] = v[i].l * v[i].c * v[j].c;
            }else{
                dp[i][j] = INF;
                for(int k = i; k <= j - 1; k++){
                    dp[i][j] = min(dp[i][j], dp[i][k] + v[i].l * v[k].c * v[j].c + dp[k + 1][j]);
                }
            }
        }
    }

    fout << dp[1][n] << '\n';

    return 0;
}