#include <iostream>
#include <fstream>
using namespace std;

const char iname[] = "podm.in";
const char oname[] = "podm.out";

#define MAXN  505
#define Min(a, b) ((a) < (b) ? (a) : (b))
#define FOR(i, a, b)  for (int i = (a); i <= (b); ++ i)
#define INF   100000000000000000LL

typedef long long i64;

i64 best[MAXN][MAXN], d[MAXN];
int n;
int main()
{
    ifstream in(iname);
    in >> n;
    FOR (i, 0, n)  in >> d[i];
    in.close();

    ofstream out(oname);
    for(int i = 1 ; i <= n ; i++)
        best[i][i] = 0;
    for(int i = 1 ; i < n ; i++)
        best[i][i+1] = d[i-1] * d[i] * d[i+1];

    for(int add = 2 ; add < n ; add++)
        for(int i = 1 ; i <= n - add ; i++)
        {
            best[i][i+add] = INF;
            for(int k = i ; k < i+add ; k++)
                best[i][i+add] = min(best[i][i+add],
                best[i][k-1] + best[k][i+add] + d[i-1]*d[k]*d[i+add]);

        }

    out << best[1][n] << '\n';
    out.close();
    return 0;
}
