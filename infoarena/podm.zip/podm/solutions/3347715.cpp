#include <iostream>
#include <vector>
#include <limits.h>
using namespace std;


int rec(vector<vector<int>> &dp, vector<int> &v, int i, int j) {
    if (dp[i][j] < INT_MAX) {
        return dp[i][j];
    }

    int ret = INT_MAX;

    for (int k = i; k < j; k++) {
        ret = min(ret, rec(dp, v, i, k) + v[i] * v[k+1] * v[j+1] + rec(dp, v, k+1, j));
    }

    dp[i][j] = ret;

    return ret;
}

//2 3 4 -> [0, 2] -> 0, [1, 2]; k = 0 / [0, 1], 2

int main() {
    int n;
    cin >> n;

    vector<int> v(n+1);

    for (int i = 0; i < n+1; i++) {
        cin >> v[i];
    }

    vector<vector<int>> dp(n+1, vector<int>(n+1, INT_MAX));

    for (int i = 0; i < n-1; i++) {
        dp[i][i+1] = v[i] * v[i+1] * v[i+2];
        dp[i][i] = 0;
    }

    dp[n-1][n-1] = 0;


    cout << rec(dp, v, 0, n-1);

    return 0;
}