#include <fstream>
#define inf 1e18
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
int n,a[501],dp[502][502];
signed main()
{
    cin>>n;
    for(int i=1;i<=n+1;i++)
        cin>>a[i];
    for(int i=1;i<n;i++)
        dp[i][i+1]=a[i]*a[i+1]*a[i+2];
    for(int l=3;l<=n;l++){
        for(int i=1;i<=n-l+1;i++){
            int j=i+l-1;
            dp[i][j]=inf;
            for(int k=i;k<j;k++)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+a[i]*a[k+1]*a[j+1]);
        }
    }
    cout<<dp[1][n];
    return 0;
}
