import java.util.Scanner;

public class PODM {
    public long solve(int n, int[] d) {
        int i, j, k, len;
        long [][] dp =  new long[n + 1][n + 1];
        for (i = 1; i <= n; i++) {
            dp[i][i] = 0;
        }
        for (i = 1; i < n; i++) {
            dp[i][i + 1] = (long) d[i - 1] * d[i] * d[i + 1];
        }
        for (len = 2; len <= n; len++) {
            for (i = 1; i + len - 1 <= n; i++) {
                j = i + len - 1;
                dp[i][j] = Long.MAX_VALUE;
                for (k = i; k < j; k++) {
                    long sol = dp[i][k] + dp[k + 1][j] + (long) d[i - 1] * d[k] * d[j];
                    dp[i][j] = Math.min(dp[i][j], sol);
                }
            }
        }
        return dp[1][n];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i;
        int[] d = new int[n + 1];
        for (i = 0; i <= n; i++) {
            d[i] = sc.nextInt();
        }
        System.out.println(new PODM().solve(n, d));
    }
}
