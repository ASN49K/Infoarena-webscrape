#include <iostream>
#include <fstream>
#include <cstring>
#define Nmax 505

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

const long long INF = (1ll << 62) - 1;
int n;
int d[505];
long long dp[Nmax][Nmax];

int main()
{
    f >> n;
    for (int i = 0; i <= n; i++)
        f >> d[i];


    for (int i = 2; i <= n; i++)
        dp[i - 1][i] = d[i - 2] * d[i - 1] * d[i];


    for (int len = 2; len < n; len++)
        for (int i = 1; i + len <= n; i++)
        {
            dp[i][i + len] = INF;
            for (int mij = i; mij < i + len; mij++)
                dp[i][i + len] = min (dp[i][i + len], dp[i][mij] + dp[mij + 1][i + len] + d[i - 1] * d[mij] * d[i + len]);
        }

    g << dp[1][n] << '\n';
}
