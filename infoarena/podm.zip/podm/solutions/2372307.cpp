
#include <bits/stdc++.h>


using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

const short Nmax = 505;

int  a[Nmax] , n;

long long dp[Nmax][Nmax];

int main()
{
    fin >> n;
    for(int i = 0 ; i <= n ; i++)
        fin >> a[i];
    for(int i = 1 ; i < n ; i++)
        dp[i][i + 1] = 1LL * a[i - 1] * a[i] * a[i + 1];
    for(int pas = 2 ; pas < n ; pas++)
        for(int i = 1 ; i <= n - pas ; i++)
    {
        int j = i + pas;
        long long mn = (1LL << 60);
        for(int k = i  ; k < j ; k++)
            mn = min(mn , dp[i][k] + dp[k + 1][j] + 1LL * a[i - 1] * a[k] * a[j]);
        dp[i][j] = mn;
    }
    fout << dp[1][n] << "\n";
    fin.close();
    fout.close();
}
