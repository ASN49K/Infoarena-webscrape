#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int Nmax = 500;
const long long inf = 600000000000000;

int v[Nmax + 5], n;
long long d[Nmax + 5][Nmax + 5];

void Read(){
    fin >> n;
    for (int i = 0; i <= n; i++)
        fin >> v[i];
}

void Init(){
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            d[i][j] = inf;
    for (int i = 1; i <= n; i++)
        d[i][i] = 0;
}

void Solve(){
    for (int l = 1; l < n; l++)
        for (int i = 1; i <= n - l; i++){
            int j = i + l;
            for (int k = i; k < j; k++)
                d[i][j] = min(d[i][j], d[i][k] + d[k + 1][j] + 1LL * v[i - 1] * v[k] * v[j]);
        }
}

void Print(){
    fout << d[1][n] << '\n';
}

int main(){
    Read();
    Init();
    Solve();
    Print();
    return 0;
}
