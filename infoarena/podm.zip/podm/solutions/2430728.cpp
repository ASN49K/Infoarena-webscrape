#include <iostream>
#include <fstream>
#include <climits>

std::ifstream fin("podm.in");
std::ofstream fout("podm.out");

int n;
long long d[550];
long long m[550][550];

int main()
{
  fin>>n;
  for(int i=0;i<=n;i++)
    fin>>d[i];
  for(int i=0;i<n;i++)
    m[i][i+1]=d[i]*d[i+1]*d[i+2];
  for(int k=2;k<=n;k++)
    for(int i=0;i+k<=n;i++)
      m[i][i+k]=LONG_LONG_MAX;
  for(int k=2;k<=n;k++)
    for(int i=0;i+k<=n;i++)
      for(int j=i;j<i+k;j++)
        m[i][i+k] = std::min(m[i][i+k], m[i][j]+m[j+1][i+k]+d[i]*d[j+1]*d[i+k+1]);

  fout<<m[0][n-1];
}
