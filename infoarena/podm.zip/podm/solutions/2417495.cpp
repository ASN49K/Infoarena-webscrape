#include <fstream>
#define DIM 502
#define INF 1e18

using namespace std;

ifstream in ("podm.in");
ofstream out("podm.out");

int n;
long long v[DIM];
long long dp[DIM][DIM];

int main(int argc, const char * argv[]) {
    in>>n;
    
    for(int i = 1; i <= n + 1; ++ i){
        in>>v[i];
    }
    
    ++ n;
    
    for(int i = 1; i <= n - 2; ++ i){
        dp[i][i + 2] = v[i] * v[i + 1] * v[i + 2];
    }
    
    for(int k = 3; k < n; ++ k){
        for(int i = 1; i <= n - k; ++ i){
            int j = i + k;
            dp[i][j] = INF;
            for(int mid = i + 1; mid < j; ++ mid){
                dp[i][j] = min(dp[i][j], dp[i][mid] + dp[mid][j] + v[i] * v[mid] * v[j]);
            }
        }
    }
    
    out<<dp[1][n];
    
    return 0;
}
