#include <bits/stdc++.h>

using namespace std;

ifstream in ("podm.in");
ofstream out ("podm.out");

const long long inf = std::numeric_limits<long long>::max();

//int n, sizes[512], dp[512][512];
long long mini, n, sizes[512], dp[512][512];;

int main()
{
    in >> n;
    for(int i = 1; i <= n + 1; i++)
    {
        in >> sizes[i];
    }
    for(int i = n; i >= 1; i--)
    {
        for(int j = 1; j <= n; j++)
        {
            mini = inf;
            for(int k = i; k < j; k++)
            {
                mini = min(mini, dp[i][k] + dp[k + 1][j] + sizes[i] * sizes[k + 1] * sizes[j + 1]);
            }
            if(i != j)
            {
                dp[i][j] = mini;
            }
            else
            {
                dp[i][j] = 0;
            }
        }
    }
    out << dp[1][n];
    return 0;
}
