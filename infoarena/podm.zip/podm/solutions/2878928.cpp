#include <fstream>
#include <climits>

using namespace std;

ifstream cin ("podm.in");
ofstream cout ("podm.out");

typedef long long dt;

dt MatrixChainOrder(dt* p, int n)
{
    dt m[n][n];
    for (int i = 1; i < n; i++)
        m[i][i] = 0;
    for (int L = 2; L < n; L++)
    {
        for (int i = 1; i < n - L + 1; i++)
        {
            const int j = i + L - 1;
            m[i][j] = INT_MAX;
            for (int k = i; k <= j - 1; k++)
                m[i][j] = min(m[i][j], m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]);
        }
    }
    return m[1][n - 1];
}

int main()
{
    int n;
    cin >> n;

    if(n == 1)
    {
        cout << 0;
        return 0;
    }
    else if(n == 2)
    {
        cout << 1;
        return 0;
    }

    n++;
    dt dims[n];
    for(int i = 0; i < n; i++)
        cin >> dims[i];

    cout << MatrixChainOrder(dims, n);
    return 0;
}
