#include <fstream>
#include <climits>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

#define infinit INT_MAX;

int n,d[505];
int dp[505][505];

int main()
{
    fin>>n;
    for(int i=0;i<=n;i++){
        fin>>d[i];
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            dp[i][j]=infinit;
        }
    }
    for(int i=1;i<=n;i++){
        dp[i][i]=0;
        dp[i][i+1]=d[i-1]*d[i]*d[i+1];
    }
    for(int dist=2;dist<=n-1;dist++){
        ///luam distanta dintre i, j, si facem in intervalul [i,j]
        for(int i=1,j=i+dist;j<=n;i++,j++){
            ///vedem dp[i][j] cu un punct intermediar k
            for(int k=i;k<=j-1;k++){
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
