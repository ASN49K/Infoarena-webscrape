#include <fstream>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

#define inf 0x3f3f3f3f

int n, dp[501][501];
int a[501];

int main()
{
    cin >> n;

    for(int i = 0; i <= n; i++)
        cin >> a[i];

    for (int len = 2; len <= n; len++)
        for (int i = 1, j = len; j <= n; i++, j++){
            dp[i][j] = inf;

            for(int k = i; k < j; k++)
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
        }

    cout << dp[1][n];

    return 0;
}
