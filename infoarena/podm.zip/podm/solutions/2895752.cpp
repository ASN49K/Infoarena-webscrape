#include <bits/stdc++.h>

using namespace std;

long long dp[505][505];
long long v[505];
long long n;
int main()
{
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    cin >> n;
    for (int i = 1; i <= n+1; i++)
        cin >> v[i];


    for (int i = 1; i <= n-1; i++) {
        dp[i][i+1] = v[i]*v[i+1]*v[i+2];
    }

    for (int d = 3; d <= n; d++) {
        for (int i = 1; i <= n - d + 1; i++) {
            int j = i + d - 1;
            dp[i][j] = 1e10;
            for (int k = i; k < j; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i]*v[k+1]*v[j+1]);
            }
        }
    }

    cout << dp[1][n];
    return 0;
}
