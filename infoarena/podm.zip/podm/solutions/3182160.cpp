#include <fstream>
#include <climits>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");


long long n;
long long v[505];


struct mat{
long long l;
long long c;
}d[505];

long long dp[505][505];

int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
        fin>>v[i];
    for(int i=1;i<=n;i++)
        d[i]={v[i],v[i+1]};

    for(int i=1;i<=n;i++)
        dp[i][i+1]=1ll*d[i].l * d[i].c * d[i+1].c;
    for(int l=3;l<=n;l++)
        for(int i=1;i+l-1<=n;i++)
        {
            long long dr= i+l-1;
            dp[i][dr]=LLONG_MAX;
            for(int k = i;k<dr;k++)
                dp[i][dr]=min(dp[i][dr],1ll*dp[i][k] + dp[k+1][dr] + d[i].l * d[k+1].l * d[dr].c);
        }

    fout<<dp[1][n];
}
