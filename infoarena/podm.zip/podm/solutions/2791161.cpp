#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("podm.in" , "r" , stdin) , freopen("podm.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 5e2 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

ll n;
ll a[N] , d[N][N];

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

	ll i , j , k , l;

    cin >> n;

    for(i = 0 ; i <= n ; i++)
        cin >> a[i];

    for(l = 2 ; l <= n ; l++)
        for(i = 1 ; i + l - 1 <= n ; i++)
            for(k = i , d[i][i + l - 1] = LLONG_MAX ; k < i + l - 1 ; k++)
                d[i][i +  l - 1] = min(d[i][i + l - 1] , d[i][k] + d[k + 1][i + l - 1] + a[i - 1] * a[k] * a[i + l - 1]);

    cout << d[1][n];

    return 0;
}
