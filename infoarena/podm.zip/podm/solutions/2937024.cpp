#include <iostream>
#include <fstream>
using namespace std;
int d[505];
long long dp[505][505];
const long long MAAX = 5*1e14;
int main()
{
    ifstream fin("podm.in");
    ofstream fout("podm.out");
    int n;
    fin>>n;
    for(int i=1;i<=n+1;i++)
    {
        fin>>d[i];
    }
    for(int lungime=2;lungime<=n;lungime++) //lungime
    {
        for(int start=1;start+lungime-1<=n;start++)
        {
            int fin = start+lungime-1;
            dp[start][fin] = MAAX;
            for(int k=start;k<fin;k++)
            {
                dp[start][fin]=min(dp[start][fin],
                                   dp[start][k]+dp[k+1][fin]+d[start]*d[k+1]*d[fin+1]);
            }
        }
    }
    fout<<dp[1][n];
    fin.close();
    fout.close();
    return 0;
}
