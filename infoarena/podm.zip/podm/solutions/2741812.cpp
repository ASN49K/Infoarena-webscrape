#include <bits/stdc++.h>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

#define NMAX 505
#define INF 1e9

int a[NMAX], dp[NMAX][NMAX], n;

int main(){
    f >> n;
    for(int i=0;i<=n;++i){
        f >> a[i];
    }
    for(int i=1;i<n;++i){
        dp[i][i+1]=a[i-1]*a[i]*a[i+1];
    }
    for(int w=2;w<n;++w){
        for(int i=1;i<=n-w;++i){
            int j=i+w;
            dp[i][j]=INF;
            for(int k=i;k<=j-1;++k){
                dp[i][j]=min(dp[i][j], dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j]);
            }
        }
    }
    g << dp[1][n];
    return 0;
}