#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

#define INF 1 << 30

int main()
{
    ifstream in("podm.in");
    ofstream out("podm.out");

    int n, i, j, m[510][510], d[510];

    in >> n;
    for (i = 0; i <= n; ++i)
    {
        in >> d[i];
    }

    for (int i = 1; i <= n; ++i)
    {
        m[i][i] = 0;
    }
    for (int i = 1; i <= n-1; ++i)
    {
        m[i][i+1] = d[i-1] * d[i] * d[i+1];
    }
    for (int p = 2; p < n; ++p)
    {
        for (int i = 1; i <= n - p; ++i)
        {
            int mini = INF;
            for (int k = i; k < i + p; k += 1)
            {
                if (mini > m[i][k] + m[k+1][i+p] + d[i-1]*d[k]*d[i+p])
                    mini = m[i][k] + m[k+1][i+p] + d[i-1]*d[k]*d[i+p];
            }
            m[i][i+p] = mini;

        }
    }
    out << m[1][n];
    in.close();
    out.close();
    return 0;
}
