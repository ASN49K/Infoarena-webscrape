#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

const int NMAX = 502;
int n;
long long dp[NMAX][NMAX];
struct matrice {
    int n, m;
};
matrice a[NMAX];

void citire()
{
    fin >> n;
    int prev;
    fin >> prev;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        a[i] = {prev, x};
        prev = x;
    }
}

int main()
{
    citire();

    for (int i = 1; i < n; i++)
        dp[i][i+1] = a[i].n * a[i].m * a[i+1].m;

    for (int d = 2; d <= n; d++)
    {
        for (int i = 1; i+d-1 <= n; i++)
        {
            int j = i + d - 1;
            dp[i][j] = 1e18;
            for (int k = i; k <= j; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + a[i].n*a[k].m*a[j].m);
            }
        }
    }

    fout << dp[1][n];
    return 0;
}
