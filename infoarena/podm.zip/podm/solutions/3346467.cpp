#include <iostream>
#include <fstream>
#include <climits>
#include <vector>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

long long dp[501][501], dim[501];

int main()
{
    int n;
    in >> n;
    for(int i = 0; i <= n; i++)
    {
        in >> dim[i];
    }

    for(int i = 1; i <= n; i++)
    {
        dp[i][i] = 0;
    }

    for(int i = 1; i < n; i++)
    {
        dp[i][i + 1] = dim[i - 1] * dim[i] * dim[i + 1];
    }

    for(int len = 3; len <= n; len++)
    {
        for (int i = 1; i <= n - len + 1; i++)
        {
            int j = i + len - 1;
            dp[i][j] = LLONG_MAX;
            for(int k = i; k < j; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + dim[i - 1] * dim[k] * dim[j]);
            }
        }
    }

    out << dp[1][n] << "\n";

    in.close();
    out.close();
    return 0;
}