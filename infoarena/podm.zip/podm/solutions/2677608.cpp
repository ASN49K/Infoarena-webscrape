#include <iostream>
#include <fstream>
#include <vector>
#include <limits.h>
#include <algorithm>
#define ll long long
using namespace std;

const int N = 505;

int n, x, y;
ll dp[N][N];
ll v[N];

int main() {
    ifstream fin("podm.in");
    ofstream fout("podm.out");

    fin >> n;

    for (int i = 1; i <= n + 1; ++i)
        fin >> v[i];

    for (int i = n - 1; i >= 1; --i) {
        for (int j = i + 1; j <= n; ++j) {
            dp[i][j] = LONG_MAX
            for (int k = i; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + v[i] * v[k + 1] * v[j+1]);
            }
        }
    }

    fout << dp[1][n];
    return 0;
}
