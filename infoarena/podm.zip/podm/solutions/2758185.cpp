#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int N = 501;
int a[N], dp[N][N];

int main()
{
    int n;
    in >> n;
    for(int i = 0; i <= n; i++)
    {
        in >> a[i];
    }
    for (int l = 2; l <= n; l++)
    {
        for (int i = 1, j = l; j <= n; i++, j++)
        {
            dp[i][j] = 10000000000;
            for (int k = i; k < j; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
            }
        }
    }
    out << dp[1][n] << '\n';
    out.close();
    return 0;
}
