#include <bits/stdc++.h>
/// TONI BO$$ was here
/// #MLC

using namespace std;
int v[502];
long long dp[502][502];
int s[502][502];

void paranthesis(int i, int j)
{
    if(i == j)
    {
        printf("%d", i);
        return ;
    }
    printf("(");
    int k = s[i][j];
    paranthesis(i, k);
    printf("*");
    paranthesis(k + 1, j);
    printf(")");
}

int main()
{
    int i, n, l, j, pos, k;
    long long rezmin;
    freopen("podm.in","r",stdin);
    freopen("podm.out","w",stdout);
    scanf("%d", &n);
    for(i = 1; i <= n + 1; i++)
        scanf("%d", &v[i]);
    for(l = 1; l < n; l++)
        for(i = 1; i <= n - l; i++)
        {
            j = i + l;
            rezmin = LLONG_MAX;
            pos = 0;
            for(k = i; k < j; k++)
                if(rezmin > dp[i][k] + dp[k + 1][j] + 1LL * v[i] * v[k + 1] * v[j + 1])
                {
                    rezmin = dp[i][k] + dp[k + 1][j] + 1LL * v[i] * v[k + 1] * v[j + 1];
                    pos = k;
                }
            dp[i][j] = rezmin;
            s[i][j] = pos;
        }
    printf("%lld\n", dp[1][n]);
    //paranthesis(1, n);

    return 0;
}
