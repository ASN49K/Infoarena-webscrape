#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int MAX_N = 502;
const int MAX_VAL = 10000;
int dp[MAX_N][MAX_N];

const int INF = MAX_N * MAX_VAL;

int main() {

    int nr_mat;
    int dims[MAX_N];

    fin >> nr_mat;
    for (int i = 1; i <= nr_mat + 1; i++) {
        fin >> dims[i];
    }

    for (int len = 1; len <= nr_mat - 1; len++) {
        for (int i = 1; i <= nr_mat - 1; i++) {
            int j = i + len;
            dp[i][j] = INF;

            for (int k = i; k <= j - 1; k++) {
                int cost = dp[i][k] + dp[k + 1][j] 
                    + dims[i] * dims[k + 1] * dims[j + 1];

                if (dp[i][j] > cost) {
                    dp[i][j] = cost;
                }
            }
        }
    }

    fout << dp[1][nr_mat];

    return 0;
}