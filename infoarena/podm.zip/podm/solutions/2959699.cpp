#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long m[501][501];
int n;
int d[501];


long long gaseste_optim(int st, int dr)
{
    // de la matr st pana la matr dr
    if (st==dr) return 0;
    if (m[st][dr]) return m[st][dr];
    long long opt=1e18;
    for(int mij=st; mij<dr; mij++){  // mijloc nu e musai in mijloc
        long long optimal1 = gaseste_optim(st,mij);
        long long optimal2 = gaseste_optim(mij+1,dr);
        long long total = optimal1 + optimal2 + d[st-1]*d[mij]*d[dr];
        if (total<opt) opt = total;
    }
    m[st][dr]=opt;
    return opt;
}


int main()
{
    fin >> n;
    for(int i=0; i<=n; i++)
        fin >> d[i];
    fout << gaseste_optim(1, n);

    return 0;
}
