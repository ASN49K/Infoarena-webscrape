#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long d[504][504];
int n, i, lung, k, j, a[503];

int main(){
    fin>>n;
    n++;
    for(i=1;i<=n;i++){
        fin>>a[i];
    }
    for(i=1;i<n;i++)
        d[i][i+1] = 0;
    for(i=3;i<=n;i++){
        for(lung=2;i-lung>0;lung++){
            j = i-lung;
            d[j][i] = 50000000000000000;
            for(k=j+1;k<i;k++)
                d[j][i]= min(d[j][i], 1LL*a[j]*a[k]*a[i]+d[j][k]+d[k][i]);
        }
    }
    fout<<d[1][n];
    return 0;
}
