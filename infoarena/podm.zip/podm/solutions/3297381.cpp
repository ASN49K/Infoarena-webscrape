#include <bits/stdc++.h>

using namespace std;

const int NMAX = 500;
const long long INF = 1e18;

int v[NMAX + 1];

long long dp[NMAX + 1][NMAX + 1];

int main() {
    ifstream fin( "podm.in" );
    ofstream fout( "podm.out" );
    int n;
    fin >> n;
    for ( int i = 0; i <= n; i ++ ) {
        fin >> v[i];
    }

    for ( int l = 1; l < n; l ++ ) {
        for ( int i = 1; i + l <= n; i ++ ) {
            int j = i + l;
            dp[i][j] = INF;
            for ( int k = i; k < j; k ++ ) {
                dp[i][j] = min( dp[i][j], dp[i][k] + dp[k + 1][j] + (long long)v[i - 1] * v[k] * v[j] );
            }
        }
    }
    fout << dp[1][n] << '\n';
    return 0;
}