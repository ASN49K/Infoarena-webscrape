#include <iostream>
#include <climits>
#include <fstream>

using namespace std;

long long a[510];
long long dp[510][510];
int n;

const long long inf = LLONG_MAX;

ifstream fin("podm.in");
ofstream fout("podm.out");

int main()
{


    fin>>n;
    for(int i = 0;i <= n;i++)
        fin>>a[i];

    for(int i = 1;i < n;i++)
        dp[i][i + 1] = a[i - 1] * a[i] * a[i + 1];

    for(int lungime = 3;lungime <= n;lungime++)
    {
        for(int i = 1;i <= n - lungime + 1;i++)
        {
            int j = i + lungime - 1;
            dp[i][j] = inf;
            for(int k = i;k < j;k++)
                dp[i][j] = min(dp[i][j],dp[i][k] + dp[k + 1][j] + a[i - 1] * a[k] * a[j]);
        }
    }
    fout<<dp[1][n];
}
