// parantezare optima de matrici
#include <bits/stdc++.h>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

const int N = 502;
const long long INF64 = 0x3f3f3f3f3f3f3f3f;
int n, d[N]; // d[i], d[i + 1] - dimensiunile matricii a i-a
long long dp[N][N]; // dp[i][j] = nr. minim de inmultiri scalare pt. inmultirea matricilor 1 .. n

int main(){
    f >> n;
    for(int i = 1; i <= n + 1; i++)
        f >> d[i];

    f.close();
    for(int i = 1; i <= n + 1; i++){
        for(int j = 1; j <= n + 1; j++)
            dp[i][j] = INF64;

        dp[i][i] = 0;
    }

    for(int i = n - 1; i >= 1; i--){
        for(int j = i + 1; j <= n; j++){
            for(int k = i; k < j; k++){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + (1LL * d[i] * d[k + 1] * d[j + 1]));
            }
        }
    }


    cout << dp[1][n];
    g.close();
}
