#include <fstream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long v[502],n,i,j,l,k,d[502][502];

int main(){
    fin>>n;
    n++;
    for(i=1;i<=n;i++)
        fin>>v[i];

    for(i=1;i<n;i++)
        d[i][i+1]=0;

    for(l=3;l<=n;l++){
        for(i=1;i+l-1<=n;i++){
            j=i+l-1;
            d[i][j]=100000000000;

            for(k=i+1;k<j;k++)
                d[i][j]=min(d[i][j],d[i][k]+d[k][j]+v[i]*v[j]*v[k]);
        }
    }

    fout<<d[1][n];

    return 0;
}
