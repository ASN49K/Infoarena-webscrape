#include <fstream>
#define MAX 507
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n;
long long int d[MAX];
long long int cmin[MAX][MAX];
void citire();
void afisare();
void pd();

int main()
{
    citire();
    pd();
    afisare();
    return 0;
}
void citire()
{
    int i;
    fin>>n;
    for(i=0;i<=n;i++)
        fin>>d[i];
}
void pd()
{
    int i,j,k,nr;
    long long int minim;
    for(i=1;i<n;i++)
        cmin[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(nr=3;nr<=n;nr++)
        for(i=1;i<=n-nr+1;i++)
    {
        j=i+nr-1;
        minim=cmin[i+1][j]+d[i-1]*d[i]*d[j];
        for(k=i+1;k<j;k++)
            if(minim>cmin[i][k]+cmin[k+1][j]+d[i-1]*d[k]*d[j])
            minim=cmin[i][k]+cmin[k+1][j]+d[i-1]*d[k]*d[j];
        cmin[i][j]=minim;
    }




}
void afisare()
{
    fout<<cmin[1][n]<<'\n';
}
