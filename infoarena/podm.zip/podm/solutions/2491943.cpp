#include <iostream>
#include <fstream>

#define NMAX 100
#define INF 2000000000

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

//using namespace std;

std::ifstream cin("podm.in");
std::ofstream cout("podm.out");

int nMatrix;
int p[NMAX];
int t;
int cost[NMAX][NMAX];

int main()
{
	// ROD CUTTING

	//int lengths[NMAX];
	//int n;

	//cin >> n;
	//for (int i = 0; i < n; i++)
	//	cin >> lengths[i + 1];

	//int sol[NMAX];
	//sol[0] = 0;

	//for (int i = 1; i <= n; i++)
	//{
	//	int q = -INF;
	//	for (int j = 0; j <= i; j++)
	//		q = MAX(q, lengths[j] + sol[i - j]);
	//	sol[i] = q;
	//}

	//cout << sol[n] << '\n';
	
	// CHAIN MATRIX MULTIPLICATION

	//int nMatrix;
	//int p[NMAX];
	//int t;

	//int cost[NMAX][NMAX]; // cost matrix, cost[i][j] = cost for multiplying matrixes ai...aj
	//					  // the ans in cost[1][n]


	cin >> nMatrix;
	for (int i = 1; i <= nMatrix + 1; i++)
		cin >> p[i];

	for (int i = 1; i <= nMatrix; i++)
		cost[i][i] = 0;

	for (int l = 2; l <= nMatrix; l++)
	{
		for (int i = 1; i <= nMatrix - l + 1; i++)
		{
			int j = i + l - 1;
			int q = INF;

			for (int k = i; k < j; k++)
				q = MIN(q, cost[i][k] + cost[k + 1][j] + p[i] * p[k + 1] * p[j + 1]);

			cost[i][j] = q;
		}
	}
	cout << cost[1][nMatrix] << '\n';

	//system("PAUSE");

	return 0;
}