#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int maxn = 500;
unsigned long long D[maxn + 1], dp[maxn + 1][maxn + 1];
int n;
#define j (i + off)

// void dbg() {
//     for(int i = 1; i <= n; ++i)
//     {
//         for(int k = 1; k <= n; ++k)
//             cout << setw(10) << dp[i][k] << ' ';
//         cout << endl;
//     }
//     cout << endl;
// }

int main() {
    fin >> n;
    for(int i = 0; i < n + 1; ++i)
        fin >> D[i];
    for(int off = 1; off < n; ++off)
        for(int i = 1; j <= n; ++i)
        {
            // j = i + off
            if(off == 1)
            {
                dp[i][i + 1] = D[i-1] * D[i] * D[i + 1];
                continue;
            }
            dp[i][j] = ULLONG_MAX;
            for(int k = i; k <= j; ++k)
                dp[i][j] = min(
                    dp[i][j],
                    dp[i][k] + dp[k + 1][j] + D[i - 1] * D[k] * D[j]
                )
                //, dbg()
                ;
        }
    fout << dp[1][n];
    return 0;
}