#include <fstream>

using namespace std;

ifstream fi("podm.in");
ofstream fo("podm.out");
int n;
long long int x[502];
long long int a[501][501];

long long Min(int st, int dr) {
  int k;
  long long int vmin, aux;
 
  vmin = 1LL << 60;
  for (k = st; k <= dr - 1; k++) {
    aux = a[st][k] + a[k+1][dr] + x[st] * x[k + 1] * x[dr + 1];
    if (aux < vmin)
      vmin = aux;
  }
  return vmin;
}
 
// x[1] x[2] - coordonatele matricei 1
// x[dr] x[dr + 1]  - coordonatele matricei dr

int main() {
  int l, d, i;
 
  fi >> n;
  for (i = 1; i <= n + 1; i++)
    fi >> x[i];
  for (d = 1; d <= n - 1; d++) // Determinam pe rand elementele de pe fiecare diagonala.
    for (l = 1; l <= n - d; l++)
      a[l][l + d] = Min(l, l + d); 
  fo << a[1][n];
    return 0;
}

//   x     d 
// n - 1   1
// n - 2   2       x + d = n

  // x  l  d
  // 3  1  2
  // 4  2  2
  // 5  3  2
