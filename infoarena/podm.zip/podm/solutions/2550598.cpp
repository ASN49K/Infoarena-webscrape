#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long n, i, j, k, len, d[502][502], v[503];

int main(){
    fin>>n;
    n++;
    for(i=1;i<=n;i++)
        fin>>v[i];
    for(i=1;i<=n;i++)
        for(j=i+1;j<=n;j++)
            d[i][j] = 500000000000002;
    for(i=1;i<=n;i++)
        d[i][i+1] = d[i][i] = 0;
    for(len=3;len<=n;len++)
        for(i=1;i+len-1<=n;i++){
            j = i+len-1;
            for(k=i+1;k<j;k++)
                d[i][j] = min(d[i][j], d[i][k]+d[k][j]+v[i]*v[k]*v[j]);
        }
    fout<<d[1][n];
    return 0;
}

