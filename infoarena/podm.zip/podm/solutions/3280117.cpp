#include <bits/stdc++.h>

using namespace std;

int v[505];
long long dp[505][505];

int main()
{
    int n;
    cin >> n;
    for (int i=1;i<=n;++i){
        cin >> v[i];
    }
    cout << LONG_MAX;
    for (int i=1;i<=n;++i){
        for (int j=1;j<=n;++j){

        }
    }
    return 0;
}
