#include <fstream>
#define LMAX 507

using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");

unsigned long long int n, dim[LMAX], taiere[LMAX][LMAX];
unsigned long long int dp[LMAX][LMAX];

void citire();
void rezolvare();
void para(int i, int j);


int main()
{
    citire();
    rezolvare();
    fout << dp[1][n];
    ///para(1, n);
    return 0;
}

void citire()
{
    fin >> n;
    for (int i = 1; i <= n + 1; i++)
        fin >> dim[i];
}

void rezolvare()
{
    for (int lg = 2; lg <= n; lg++)
    {
        for (int i = 1; i <= n - lg + 1; i++)
        {
            int j = i + lg - 1;
            if (i == j)
            {
                dp[i][i] = 0;
                continue;
            }
            int k = i;
            dp[i][j] = dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1];
            taiere[i][j] = i;
            for (int k = i + 1; k < j; k++)
            {
                int maxim = dp[i][k] + dp[k+1][j] + dim[i] * dim[k+1] * dim[j+1];
                if (dp[i][j] > maxim)
                {
                    dp[i][j] = maxim;
                    taiere[i][j] = k;
                }
            }
        }
    }
}

void para(int i, int j)
{
    if (i == j)
        fout << "matrice" << i;
    else
    {
        fout << '(';
        para(i, taiere[i][j]);
        fout << '*';
        para(taiere[i][j] + 1, j);
        fout << ')';
    }
}
