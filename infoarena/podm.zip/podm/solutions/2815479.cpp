#include <fstream>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n, v[502], d[502][502], lenght;

int calcul (int st, int dr)
{
    if (dr-st==1)
    {
        return 0;
    }

    int result=0;
    for (int k=st+1; k<dr; k++)
    {
        d[st][dr] = min(d[st][dr], v[st] * v[k] * v[dr] + calcul(st, k) + calcul(k, dr));
    }
    result=d[st][dr];

    return result;
}

int main()
{
    fin>>n;
    n++;
    for (int i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    for (int i=1; i<=n; i++)
    {
        for (int j=i+1; j<=n; j++)
            d[i][j]= INT_MAX;
    }

    lenght=3;
    while (lenght <= n)
    {
        for (int i=1; i+lenght-1<=n; i++)
        {
            d[i][i+lenght-1] = calcul(i, i+lenght-1);
        }
        lenght++;
    }

    fout<<d[1][n];
    return 0;
}
