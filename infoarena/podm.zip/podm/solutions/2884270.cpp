#include <fstream>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMAX = 505;

int m[NMAX];
long long dp[NMAX][NMAX];

int main()
{
    int n;
    fin>>n;
    n++;
    for(int i = 1;i <= n;i++)
        fin>>m[i];
    for(int len = 1;len < n - 1;len++)
    {
        for(int i = 1;i <= n - len;i++)
        {
            int j = i + len;
            long long minn = INT_MAX;
            for(int k = i;j < j;k++)
            {
                minn = min(minn,dp[i][k - 1] + dp[k + 1][j] + 1LL * m[i - 1] * m[j] * m[k]);
            }
            dp[i][j] = minn;
        }
    }
    fout<<dp[1][n - 1];
    return 0;
}
