#include <iostream>
#include <fstream>
using namespace std;

const int dim = 505;
const int INF = 1e9;

ifstream f( "podm.in" );
ofstream g( "podm.out" );

int dimens[ dim ];
int dp[ dim ][ dim ], n;


int main()
{
    int i, j, k, termen;

    f >> n;
    for( i = 1; i <= n + 1; ++i )
        f >> dimens[ i ];


    for( i = 1; i < n; ++i )
        dp[ i ][ i + 1 ] = dimens[ i ]  *  dimens[ i + 1 ]  *  dimens[ i + 2 ];

    for( i = n - 2; i >= 1; --i )
        for( j = i + 2; j <= n; ++j )
            {
                dp[ i ][ j ] = INF;
                for( k = i; k < j; ++k )
                    {

                        termen = dp[ i ][ k ] +  dp[ k + 1 ][ j ] +  dimens[ i ] * dimens[ k + 1 ] * dimens[ j + 1 ];
                        dp[ i ][ j ] = min( dp[ i ][ j ], termen );
                    }
            }


    g << dp[ 1 ][ n ];

    return 0;
}
