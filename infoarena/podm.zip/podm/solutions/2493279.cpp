/**


Avem lantul de inmultiri A(i)A(i+1)...A(j)
Avem nevoie de nr de inmultiri optim pt lant
Numim inmultirea optima [A(i)A(i+1)...A(k)][A(k+1)A(k+2)..A(j)]
                            X               Y


           j-1   X-ul        Y-ul         inm. necesare inmultirii X cu Y
dp[i][j] = min(dp[i][k] + dp[k+1][k] + d[i-1]*d[k]*d[j])                 , unde d[] = nr linii/col
           k=i


Pentru calcularea dp[i][j] - avem nevoie de  cele de pe diagonale inainte
**/


#define NMAX 505
#include <cstdio>
#include <climits>
#include <algorithm>
using namespace std;


int n, d[NMAX];
long long dp[NMAX][NMAX];


void citire()
{
    scanf("%d", &n);
    for(int i=0; i<=n; ++i)
        scanf("%d", &d[i]);
}


void progr()
{

    for(int adaug = 0; adaug <= n-1; ++adaug)
    {
        for(int i=1; i+adaug <= n; ++i)
        {
            int j = i + adaug;
            long long vmin = LLONG_MAX;

            for(int k=i; k <= j-1; ++k)
                vmin = min (vmin, 1LL*dp[i][k] + dp[k+1][j] + d[i-1] * d[k] * d[j]);
            if(vmin == LONG_MAX)
                vmin = 0;
            dp[i][j] = vmin;
        }
    }

    printf("%lld", dp[1][n]);

}





int main()
{
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);
    citire();
    progr();

    return 0;
}
