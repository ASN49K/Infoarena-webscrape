
#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int MAX_SIZE = 505;

long long noMultiplications[MAX_SIZE][MAX_SIZE], d[MAX_SIZE];
int n;

int main() {
    fin >> n;
    for (int i = 0; i <= n; ++i) {
        fin >> d[i];
    }
    for (int i = 1; i < n; ++i) {
        noMultiplications[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    }
    for (int dist = 2; dist <= n - 1; ++dist) { // distanta maxima e n - 1 fata de start
        for (int start = 1; start <= n - dist; ++start) { // mergem cu start pana unde putem
            int end = start + dist; // asta va fi capatul
            noMultiplications[start][end] = INT_MAX;
            for (int k = start; k < end; ++k) { // verificam
                noMultiplications[start][end] = min(noMultiplications[start][end], noMultiplications[start][k] + noMultiplications[k + 1][end] + d[start - 1] * d[k] * d[end]);
            }
        }
    }
    fout << noMultiplications[1][n];
    return 0;
}
