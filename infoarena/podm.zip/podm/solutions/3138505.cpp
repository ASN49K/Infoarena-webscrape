#include <bits/stdc++.h>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const int NMAX = 500;
const long long INFLL = 1e18;

int v[NMAX + 1];
long long dp[NMAX + 1][NMAX + 1];

void minSelf(long long &x, long long y) {
	if(y < x) {
		x = y;
	}
}

int main() {
	ios_base :: sync_with_stdio(false);

	int n;
	fin >> n;

	for(int i = 0; i <= n; i++) {
		fin >> v[i];
	}

	for(int len = 2; len <= n; len++) {
		for(int i = 1, j = len; j <= n; i++, j++) {
			dp[i][j] = INFLL;
			for(int k = i; k < j; k++) {
				minSelf(dp[i][j], dp[i][k] + dp[k + 1][j] + (long long) v[i - 1] * v[k] * v[j]);
			}
		}
	}

	fout << dp[1][n] << '\n';

	return 0;
}