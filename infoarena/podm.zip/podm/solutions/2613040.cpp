#include <bits/stdc++.h>

using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int d[505];
unsigned long long c[505][505];
int n;

int main()
{
    f>>n;
    for(int i = 0;i <= n;++i)
        f>>d[i];
    for(int i = 1;i < n;++i)
        c[i][i + 1] = d[i - 1] * d[i] * d[i + 1];
    for(int k = 2;k < n;++k)
    {
        for(int i = 1;i <= n - k;++i)
        {
            int j = i + k;
            c[i][j] = 10000000000000000000;
            for(int h = i;h < j;++h)
                c[i][j] = min(c[i][j], c[i][h] + c[h + 1][j] + d[i - 1] * d[h] * d[j]);
        }
    }
    g<<c[1][n];
    return 0;
}
