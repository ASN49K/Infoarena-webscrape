n=int(input())
nums=list(map(int , input().split()))
n=len(nums)
dp=[[0 for _ in range(n)] for _ in range(n) ]
sum_mini=100000
for i in range (n-1 , 0 , -1):
  for j in range ( i , n ):
    if i==j:
        dp[i][j]=0
        continue
    sum_mini=10**18
    for k in range (i , j):
        suma=dp[i][k]+dp[k+1][j]+nums[i-1]*nums[k]*nums[j]
        if suma<sum_mini:
            sum_mini=suma 
    dp[i][j]=sum_mini

print(dp[1][n-1])