#include <iostream>
#include <vector>
#include <stdlib.h>
#include <fstream>

using namespace std;


unsigned long long podm(int n, vector<int> &d) {
	vector<vector<unsigned long long>> dp(n + 1, vector<unsigned long long>(n + 1));

	for (int i = 1; i <= n; ++i) {
		dp[i][i] = 0;
	}

	for (int i = 1; i < n; ++i) {
		dp[i][i + 1] = 1ULL * d[i - 1] * d[i] * d[i + 1];
	}

	for (int len = 2; len <= n; ++len) {
		for (int i = 1; i + len - 1 <= n; ++i) {
			int j = i + len - 1;

			for (int k = i; k < j; ++k) {
				unsigned long long new_sol = dp[i][k] + dp[k + 1][j] + 1ULL * d[i - 1] * d[k] * d[j];
				dp[i][j] = std::min(dp[i][j], new_sol);
			}
		}
	}
	return dp[1][n];
}

int main() {
	ifstream in("podm.in");
	int n;
	in >> n;
	std::vector <int> v;
	for (int i = 0; i < n + 1; ++i) {
		int x;
		cin >> x;
		v.push_back(x);
	}

	ofstream fout("podm.out");

	fout << podm(n, v);
	in.close();
	fout.close();
	return 0;

}