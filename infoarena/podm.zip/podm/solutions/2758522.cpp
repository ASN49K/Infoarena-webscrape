#include <bits/stdc++.h>

using namespace std;

ifstream fin ("podm.in");
ofstream fout ("podm.out");

const long long INF=100000000000000000
long long v[505], dp[505][505];

int main()
{
    int n;
    cin >> n;
    for (int i=0; i<=n; i++)
    {
        cin >> v[i];
    }
    for (int i=1; i<=n; i++)
    {
        dp[i][i]=0;
    }
    for (int i=1; i<=n-1; i++)
    {
        dp[i][i+1]=v[i-1]*v[i]*v[i+1];
    }
    for (int d=2; d<n; d++)
    {
        for (i=1; i<=n-d; i++)
        {
            dp[i][i+d]=INF;
            for (int k=i; k<i+d; k++)
            {
                dp[i][i+d]=min(dp[i][i+d],dp[i][k]+dp[k+1][i+d]+v[i-1]*v[k]*v[i+d]);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
