#include <fstream>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

long long v[510], d[510][510], n, i, j, k, l;

int main(){
    fin>>n;
    n++;
    for(i=1; i<=n; i++){
        fin>>v[i];
    }
    for(l=3; l<=n; l++){
        for(i=1; i+l-1<=n; i++){
            j=i+l-1;
            d[i][j]=1000000000;
            for(k=i+1; k<j; k++){
                d[i][j]=min(d[i][j], d[i][k]+d[k][j]+v[i]*v[k]*v[j]);
            }
        }
    }
    fout<<d[1][n];
}
