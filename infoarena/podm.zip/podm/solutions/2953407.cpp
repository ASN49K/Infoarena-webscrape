#include <fstream>
using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

///////////////////////////////////////

const int MAX = 5e2 + 3;

const int INF = MAX * (1e4+1);

int v[MAX] , n;

long long dp[MAX][MAX];

////////////////////////////////////


// descriere dinamica : dp[i][j] = numarul minim de inmultiri dintre matrici pentru intervalul [i,j]

// recurenta : dp[i][j] = max(dp[i][k] + dp[k][i] + (v[x] * v[y] * v[k]))

////////////////////////////////////

long long dinamica( int x , int y ){

    if(dp[x][y] != INF) return dp[x][y];

    for(int i = x + 1  ; i < y ; i++){

        dp[x][y] = min(dp[x][y] , 1LL * dinamica(x,i) + dinamica(i,y) + v[x] * v[y] * v[i]);

    }

    return dp[x][y];

}

int main(){

    cin >> n;

    n++;

    for(int i = 1 ; i <= n ; i++){

        cin >> v[i];

        dp[i][i] = dp[i][i+1] = 0;
    }

    // base case

    for(int i = 1 ; i <= n ; i++){

        for(int j = i + 2 ; j <= n ; j++) dp[i][j] = INF;
    }

    cout << dinamica(1,n);

    return 0;
}
