//#include <iostream>
#include <fstream>
using namespace std;
ifstream cin("podm.in");
ofstream cout("podm.out");
long long d[505][505],x[505],y[505];
long long solve(long long st,long long dr){
    if(d[st][dr]!=0){
        return d[st][dr];
    }
    if(st==dr){
        return 0;
    }
    d[st][dr]=INT64_MAX;
    for(long long i=st;i<dr;i++){
        long long xx=solve(st,i)+solve(i+1,dr)+x[st]*y[dr]*y[i];
        if(xx<d[st][dr]){
            d[st][dr]=xx;
        }
    }
    return d[st][dr];

}
int main() {
    long long n;
    cin>>n;
    long long a,b;
    cin>>a;
    for(long long i=1;i<=n;i++){
        cin>>b;
        x[i]=a;
        y[i]=b;
        a=b;
    }
    cout<<solve(1,n);
    return 0;
}
