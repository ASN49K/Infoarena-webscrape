//#include <iostream>
#include <fstream>
using namespace std;
const int NMAX = 5e2 + 2;
const int INF = 1e9 + 1;
long long int n, p[NMAX], dp[NMAX][NMAX];
ifstream cin("podm.in");
ofstream cout("podm.out");
int main()
{
    cin >> n;
    for (int i = 0; i < n + 1; i++)
    {
        cin >> p[i];
    }

    for (int l = 2; l <= n; l++)
    {
        for (int i = 1; i <= n - l + 1; i++)
        {
            int j = i + l - 1;
            dp[i][j] = INF;
            for (int k = i; k < j; k++)
            {
                //cout << i << ' ' << k << "  " << k + 1 << ' ' << j << '\n';
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + p[i - 1] * p[k] * p[j]);
            }
        }
    }
    cout << dp[1][n];
}