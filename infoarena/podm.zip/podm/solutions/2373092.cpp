#include <fstream>
#define INF 1000000000002
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int n,i,L[505],C[505],x,j,k;
unsigned long Q[505][505],mi;
int main()
{
    f>>n;
    for(i=1;i<=n+1;i++)
    {
        f>>x;
        L[i]=x;
        C[i-1]=x;
    }
    for(i=n-1;i>=1;i--)
    {
        for(j=i+1;j<=n;j++)
        {
            mi=INF;
            for(k=i;k<j;k++)
                if(Q[i][k]+Q[k+1][j]+L[i]*C[k]*C[j]<mi)
                    mi=Q[i][k]+Q[k+1][j]+L[i]*C[k]*C[j];
            Q[i][j]=mi;
        }
    }
    g<<Q[1][n];
    return 0;
}
