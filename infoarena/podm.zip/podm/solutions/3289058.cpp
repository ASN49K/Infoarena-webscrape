#include <bits/stdc++.h>
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
#define INF 999999999999999999
long long d[502],dp[502][502];
int main()
{
    int n,i,k;
    long long vmin,z;
    fin>>n;
    for(i=1;i<=n+1;i++)
        fin>>d[i];
    for(i=1;i<=n;i++)
        dp[i][i]=0;
    for(i=1;i<=n-1;i++)
        dp[i][i+1]=d[i]*d[i+1]*d[i+2];
    for(int L=2;L<=n;L++)
    {
        for(i=1;i<=n-L+1;i++)
        {
            int j=i+L-1;
            vmin=INF;
            for(k=i;k<j;k++)
            {
                z=dp[i][k]+dp[k+1][j]+d[i]*d[k+1]*d[j+1];
                if(z<vmin)
                    vmin=z;
            }
            dp[i][j]=vmin;
        }
    }
    fout<<dp[1][n]<<"\n";
    return 0;
}
