#include <bits/stdc++.h>
#define L 505
#define INF (1LL << 60)
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
int d[L];
long long dp[L][L];

int main(){
  fin >> n;
  for (int i = 0; i <= n; i++)
    fin >> d[i];
  for (int diag = 1; diag < n; diag++)
    for (int i = 1; i <= n - diag; i++){
      dp[i][i + diag] = INF;
      for (int k = i; k < i + diag; k++)
        dp[i][i + diag] = min(dp[i][i + diag], dp[i][k] + dp[k + 1][i + diag] + 1LL * d[i - 1] * d[k] * d[i + diag]);
    }
  fout << dp[1][n] << "\n";
  return 0;
}
