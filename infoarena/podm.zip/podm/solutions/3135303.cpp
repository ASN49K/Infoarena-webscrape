#include <bits/stdc++.h>
#define mod 666013
#define inf 999999999
using namespace std;
int n,l[505],c[505],dp[505][505];
ifstream fin("podm.in");
ofstream fout("podm.out");
int main(){
    fin>>n;
    fin>>l[1];
    for (int i=1;i<=n;i++){
        fin>>c[i];
        l[i+1]=c[i];
    }
    for (int i=1;i<=n;i++)
        for (int j=i+1;j<=n;j++){
            dp[i][j]=inf;
        }
    for (int i=n;i>=1;i--){
        for (int j=i+1;j<=n;j++){
            for (int k=i;k<j;k++){
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+l[i]*c[j]*l[k+1]);
            }
        }
    }
    fout<<dp[1][n];
}