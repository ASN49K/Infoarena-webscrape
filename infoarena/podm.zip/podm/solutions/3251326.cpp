#include <bits/stdc++.h>
using namespace std ;
ifstream in("podm.in");
ofstream out("podm.out");
long long n,a[505];
long long dp[505][505];
int main()
{
    in>>n;
    for(int i=0;i<=n;i++)
        in>>a[i];
    for(int i=n-1;i>=1;i--){
        for(int j=i+1;j<=n;j++){
            dp[i][j]=LLONG_MAX ;
            for(int k=i;k<j;k++)
                dp[i][j]=min(dp[i][j],1ll*dp[i][k]+dp[k+1][j]+1ll*a[i-1]*a[j]*a[k]);
        }
    }
    out<<dp[1][n];
    return 0 ;
}
