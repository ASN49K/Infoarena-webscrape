#include <iostream>
#include <fstream>
#include <climits>
using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

int n;
unsigned long long dp[501][501];
int v[501];
int main()
{
    in>>n;
    for(int i=1;i<=n+1;++i){
        in>>v[i];
    }
    for(int i=1;i<n;++i){
        dp[i][i+1]=v[i]*v[i+1]*v[i+2];
    }
    for(int lungime=2;lungime<n;++lungime){
        for(int i=1;i<=n-lungime;++i){
            int j=i+lungime;
            dp[i][j]=INT_MAX;
            for(int k=i;k<j;++k)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+v[i]*v[k+1]*v[j+1]);
        }
    }
    out<<dp[1][n];
    return 0;
}
