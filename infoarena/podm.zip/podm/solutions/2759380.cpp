#include <bits/stdc++.h>
#define mp make_pair
#define pb push_back
#define pf push_front
#define ll long long
#define ull unsigned long long
#define x first
#define y second
#define pi pair<int,int>
#define pl pair<ll,ll>
#define EPSILON 0.000001
#define zeros(x) ((x^(x-1))&x)

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

const double EPS=1e-9;
const ll NMAX=5e3+5,INF=1e18,MOD=998244353,inf=INT_MAX;

int N;
int v[NMAX],aux;
ll dp[NMAX][NMAX];

int main()
{
    fin>>N;
    for(int i=1;i<=N+1;i++)
    {
        fin>>v[i];
    }
    for(int i=1;i<=N;i++)
    {
        for(int j=i-1;j>=1;j--)
        {
            dp[i][j]=INF;
            for(int k=j;k<i;k++)
            {
                dp[i][j]=min(dp[i][j],dp[k][j]+dp[i][k+1]+v[j]*v[k+1]*v[i+1]);
            }
        }
    }
    fout<<dp[N][1];


    return 0;
}
