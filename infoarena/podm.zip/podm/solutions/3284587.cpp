#include <fstream>
#include <iostream>
#define int long long
const int mod=1e9+7;
using namespace std;
ifstream f("podm.in");
ofstream g("podm.out");
int v[100009], dp[509][509];
int calc (int st, int dr)
{
    if (st==dr || st==dr-1) return 0;
    if (dp[st][dr]!=-1) return dp[st][dr];
    int x=1e18;
    for (int k=st+1; k<dr; k++)
        x=min (x, calc(st,k)+calc(k, dr)+v[st]*v[k]*v[dr]);
    dp[st][dr]=x;
    return x;
}
signed main ()
{
    int n;
    f >> n;
    n++;
    for (int i=1; i<=n; i++)
        f >> v[i];
    for (int i=0; i<=n; i++)
        for (int j=0; j<=n; j++)
        dp[i][j]=-1;
    g << calc (1, n);
}
