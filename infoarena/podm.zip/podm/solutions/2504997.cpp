#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("podm.in");
ofstream g("podm.out");

const long long MAX = 1e18;

int main()
{
    int n;

    f >> n;

    vector <long long> v(n + 1, 0);
    vector <vector <long long>> dp(n + 2, vector<long long>(n + 2, MAX));

    for (int i = 0; i <= n; i++)
    {
        f >> v[i];

        dp[i][i] = 0;
    }

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n - i; j++)
    {
        for (int k = j; k < j + i; k++)
        {
            dp[j][i + j] = min(dp[j][i + j], dp[j][k] + dp[k + 1][i + j] + v[j - 1] * v[k] * v[i + j]);
        }
    }

    g << dp[1][n];

    f.close();
    g.close();
    return 0;
}
