#include <iostream>
#include <fstream>
using namespace std;

ifstream f( "podm.in" );
ofstream g( "podm.out" );



const int dim = 505;
const int inf = 1e4 * 5 * 1e2 * 10;
int dimens[ dim ];
int dp[ dim ][ dim ]; /// dp[ i ][ j ] = nr MINIM de inm pt sirul de matrice cu indicii i, i + 1, ... j-1, j


int main()
{
    int n, i, j, k, minim;
    f >> n;
    for( i = 1; i <= n + 1; ++i )
        f >> dimens[ i ];

    for( i = 1; i < n; ++i )
        dp[ i ][ i + 1 ] = dimens[ i ] * dimens[ i + 1 ] * dimens[ i + 2 ];


    /*g << "Dimensiunile folosite: " << endl;
    for( i = 1; i <= n + 1; ++i )
        g << dimens[ i ] << " ";
    g << endl << endl;*/


    for( i = 1; i <= n; ++i )
        for( j = i + 2; j <= n; ++j )
            {
                minim = inf;
                for( k = i; k < j; ++k )
                    minim = min( minim, dp[ i ][ k ] + dp[ k + 1 ][ j ] +
                                 dimens[ i ] * dimens[ k + 1 ] * dimens[ j + 1 ] );
                dp[ i ][ j ] = minim;
            }


     /*g << "Matricea de DP:" << endl;

     for( i = 1; i <= n; ++i )
        {
            for( j = 1; j <= n; ++j )
                g << dp[ i ][ j ] << " ";
            g << endl;
        }*/


    g<< dp[ 1 ][ n ];



    return 0;
}
