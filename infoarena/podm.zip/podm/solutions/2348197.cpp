#include <fstream>
#define DIM 510
#define inf (1LL<<62)
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,i,j,k,l,dim[DIM],d[DIM][DIM];
int main() {
    fin>>n; n++;
    for (i=1;i<=n;i++)
        fin>>dim[i];
    for (l=3;l<=n;l++)
        for (i=1;i+l-1<=n;i++) {
            j=i+l-1;
            d[i][j]=inf;
            for (k=i+1;k<j;k++)
                d[i][j]=min(d[i][j],d[i][k]+d[k][j]+dim[i]*dim[j]*dim[k]);
        }
    fout<<d[1][n];
    return 0;
}
