#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("podm.in");
ofstream fout ("podm.out");
int n,i,j,l,k;
long long dp[505][505],nou,x;
struct ha
{
    long long x; long long y;
} v[505];
int main()
{
    fin>>n;
    fin>>v[1].x;
    for(i=2;i<=n+1;i++)
    {
        fin>>x;
        v[i].x=x;
        v[i-1].y=x;
    }
    ///dp[i][j] = numarul minim de inmultiri care se pot face cu matricele de la i la j
    for(i=1;i<=n-1;i++)
    {
        dp[i][i+1]=v[i].x*v[i+1].x*v[i+1].y;
    }
    for(l=3;l<=n;l++)
    {
        for(i=1;i<=n-l+1;i++)
        {
            ///secventa i,i+l-1
            dp[i][i+l-1]=999999999;
            for(k=i;k<=i+l-2;k++)
            {
                nou=dp[i][k]+dp[k+1][i+l-1]+v[i].x*v[k].y*v[i+l-1].y;
                dp[i][i+l-1]=min(dp[i][i+l-1],nou);
            }
        }
    }
    fout<<dp[1][n];
    return 0;
}
