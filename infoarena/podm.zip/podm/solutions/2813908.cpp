#include <fstream>
#define INF 1000000000000000000
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
unsigned long long int n,pd[502][502],d[502];
void citire();
void pdin();
void para(int i,int j);
int main()
{
    citire();
    pdin();
    fout<<pd[1][n];
    return 0;
}
void citire()
{
    int i;
    fin>>n;
    for(i=0;i<=n;i++)
        fin>>d[i];
}
void pdin()
{
    unsigned long long int dd,i,j,k,calc;
    for(i=1;i<n;i++)
        pd[i][i+1]=d[i-1]*d[i]*d[i+1];
    for(dd=2;dd<n;dd++)
        for(i=1;i<=n-dd;i++)
        {
            j=i+dd;
            pd[i][j]=INF;
            for(k=i;k<j;k++)
            {
                calc=pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j];
                if(calc<pd[i][j])
                {
                    pd[i][j]=calc;
                }
            }
        }
}
