#include <bits/stdc++.h>
#define Inf (unsigned long long)1000000000000000000
#define ULL unsigned long long

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

ULL n,val[501];
ULL dp[501][501];

int main()
{
    in>>n;
    
    for(int i=0;i<=n;i++)
        in>>val[i];
        
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++)
            dp[i][j]=Inf;
        
    for(int k=0; k<=n-1; k++)
        for(int i=1; i+k<=n; i++)
            for(int j=i;j<=i+k;j++)
                dp[i][i+k]=min(dp[i][i+k], dp[i][j]+dp[j+1][i+k]+val[i-1]*val[j]*val[i+k] );
                
    out<<dp[1][n];
    
    return 0;
}