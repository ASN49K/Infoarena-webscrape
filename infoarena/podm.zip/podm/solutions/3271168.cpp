#include <iostream>
#include <vector>
#include <fstream>
#include <climits>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

const long long INF = 1e18;

int main()
{
    int n;
    int meretek[501];
    fin >> n;
    long long dp[502][502];
    for(int i = 0; i <= n+1; i++){
        for(int j = 0; j <= n+1; j++){
            dp[i][j] = INF;
        }
    }
    for(int i = 0; i <= n; i++){
        fin >> meretek[i];
        dp[i][i] = 0;
    }
    for(int atlo = 2; atlo <= n; atlo++){
        for(int sor = 1; sor <= n-atlo+1; sor++){
            int oszlop = sor + atlo-1;

            for(int koztes = sor; koztes <= oszlop; koztes++){
                long long temp = dp[sor][koztes] + meretek[sor-1]*meretek[oszlop]*meretek[koztes] + dp[koztes+1][oszlop];
                dp[sor][oszlop] = min(dp[sor][oszlop], temp);
            }
        }
    }
    fout << dp[1][n];
    return 0;
}
