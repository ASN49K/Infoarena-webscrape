#include <fstream>

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
int d[503];
int dp[503][503];

void citire()
{
    fin >> n;
    for(int i = 0; i < n + 1; i++)
        fin >> d[i];

}

void initializare_dp()
{
    for(int i = 0; i < n; i++)
        dp[i][i+1] = d[i] * d[i+1] * d[i+2];

}

void solve()
{
    for(int c = 2; c <= (2*n - 1)/2; c++)
    {
        for(int i = 0; i < n; i++)
        {
            dp[i][i + c] = dp[i][i] + dp[i+1][i + c] + (d[i] * d[i+1] * d[i + c + 1]);
            for(int  k = i + 1; k <= i + c - 1; k++)
                dp[i][i + c] = min(((dp[i][k] + dp[k+1][i + c]) + (d[i]* d[k+1]*d[i + c +1])), dp[i][i + c]);
        }
    }
}

int main()
{
    citire();
    initializare_dp();
    solve();
    fout << dp[0][n - 1];
    return 0;
}

