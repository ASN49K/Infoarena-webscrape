#include <fstream>
#define NMAX 510
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n;
long long int d[NMAX];
long long int pd[NMAX][NMAX];
void citire();
void afisare();
void prod();

int main()
{
    citire();
    prod();
    afisare();
    return 0;
}
void citire()
{
    int i;
    fin>>n;
    for(i=0;i<=n;i++)
        fin>>d[i];
}
void prod()
{
    int i,j,k,dif;
    long long int minim;
    for(i=1;i<n;i++)
        pd[i][i+1]=d[i-1]*d[i+1]*d[i];
    for(dif=3; dif<=n; dif++)
        for(i=1; i<=n-dif+1; i++)
    {
        j=i+dif-1;
        minim = pd[i+1][j]+d[i-1]*d[i]*d[j];
        for(k=i+1; k<j; k++)
            if(minim > pd[i][k] + pd[k+1][j] + d[i-1]*d[k]*d[j])
            minim = pd[i][k] + pd[k+1][j] + d[i-1]*d[k]*d[j];
        pd[i][j] = minim;
    }
}
void afisare()
{
    fout<<pd[1][n]<<endl;
}
