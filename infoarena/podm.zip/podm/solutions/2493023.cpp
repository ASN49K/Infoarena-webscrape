#include <fstream>
#include <vector>
#include <cassert>
#include <algorithm>

#define OO 0x3f3f3f3f


std::ifstream fin ("podm.in");
std::ofstream fout ("podm.out");

int n;
std::vector <int64_t> A;
std::vector <std::vector <int64_t>> DP;


inline void Print (int i, int j, char &name)
{
    if (i == j)
    {
        fout << name ++;
        return;
    }

    fout << "(";
    Print (i, DP[j][i], name);
    Print (DP[j][i] + 1, j, name);
    fout << ")";
}


int main ()
{
    assert (fin >> n);

    A = std::vector <int64_t> (n + 1);
    DP = std::vector <std::vector <int64_t>> (n + 1, std::vector <int64_t> (n + 1, 0));

    for (int i = 0; i <= n; ++ i)
        assert (fin >> A[i]);

    for (int len = 2; len <= n; ++ len)
        for (int i = 1, j = len; j <= n; ++ i, ++ j)
        {
            DP[i][j] = OO;
            for (int k = i; k < j; ++ k)
            {
                int64_t new_val = DP[i][k] + DP[k + 1][j] + A[i - 1] * A[k] * A[j];
                if (DP[i][j] > new_val)
                    DP[j][i] = k;
                DP[i][j] = std::min (DP[i][j], new_val);
            }
        }

    fout << DP[1][n] << "\n";
    ///char name = 'A';
    ///Print (1, n, name);

    fin.close (), fout.close ();
    return 0;
}
