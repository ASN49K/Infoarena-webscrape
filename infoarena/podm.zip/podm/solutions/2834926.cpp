#include <iostream>
#include <fstream>


using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n, d[501], M[501][501], nr, minim, kmin;
int main()
{long long i, j, k;
fin>>n;
for(i=0; i<=n; i++)
    fin>>d[i];

for(nr=2; nr<=n; nr++)
{for(i=1; i<=n-nr+1; i++)
{j=i+nr-1;
minim=1000000000000;
for(k=i; k<j; k++)
    if((M[i][k]+M[k+1][j]+d[i-1]*d[k]*d[j])<minim)
{minim=M[i][k]+M[k+1][j]+d[i-1]*d[k]*d[j];
kmin=k;
}
M[i][j]=minim; M[j][i]=kmin;
}
}
fout<<M[1][n];


    return 0;
}
