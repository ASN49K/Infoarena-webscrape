#include <cstdio>
#include <algorithm>
const int NMAX = 505;
int N, D[NMAX];

long long leastOperations[NMAX][NMAX];

int main() {
	freopen("podm.in", "r", stdin);
	freopen("podm.out", "w", stdout);

	scanf("%d", &N);
	for (int i = 1; i <= N + 1; i++) {
		scanf("%d", &D[i]);
	}

	memset(leastOperations, 0x3f, sizeof(leastOperations));
	for (int i = 1; i <= N; i++) {
		leastOperations[i][i] = 0;
	}
	
	for (int len = 2; len <= N; len++) {
		for (int start = 1; start <= N - len + 1; start++) {
			int end = start + len - 1;
			for (int mid = start; mid < end; mid++) {
				leastOperations[start][end] = std::min(
					leastOperations[start][end],
					leastOperations[start][mid] + 
					1LL * D[start] * D[mid + 1] * D[end + 1] +
					leastOperations[mid + 1][end]);
			}
		}
	}

	printf("%lld\n", leastOperations[1][N]);
	return 0;
}