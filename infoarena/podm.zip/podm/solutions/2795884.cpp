#include <fstream>
#define NMAX 502

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long int cmin[NMAX][NMAX], minn, d[NMAX];
int n;
int i, j, k, i2, mink;

int main()
{
    fin>>n;
    for (i=0; i<=n; i++)
        fin>>d[i];
    for (i2=2; i2<=n; i2++)
        for (j=i2; j<=n; j++)
        {
            i=j-i2+1;
            if (i==j-1) cmin[i][j]=d[i-1]*d[i]*d[i+1];
            else
            {
                minn=cmin[i][i]+cmin[i+1][j]+d[i-1]*d[i]*d[j];
                mink=i;
                for (k=i+1; k<=j-1; k++)
                {
                    if (cmin[i][k]+cmin[k+1][j]+d[i-1]*d[k]*d[j]<minn)
                    {
                        minn=cmin[i][k]+cmin[k+1][j]+d[i-1]*d[k]*d[j];
                        mink=k;
                    }
                }
                cmin[i][j]=minn;
                cmin[j][i]=mink;
            }
        }
    fout<<cmin[1][n];
    return 0;
}
