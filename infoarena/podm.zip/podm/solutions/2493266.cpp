#include <cstdio>
#include <algorithm>

using namespace std;

long long n, d[505];
long long dp[505][505];

int main()
{
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);

    scanf("%lld", &n);
    for(int i=0; i<=n; i++)
        scanf("%lld", &d[i]);
    for(int dif=1; dif<n; dif++)
    {
        for(int i=1; i<=n; i++)
        {
            long long vmin=999999999;
            int j=i+dif;
            for(int k=i; k<=j-1; k++)
                vmin=min(vmin, (dp[i][k]+dp[k+1][j]+d[i-1]*d[k]*d[j]));
            dp[i][j]=vmin;
        }
    }
    printf("%lld", dp[1][n]);

    return 0;
}
