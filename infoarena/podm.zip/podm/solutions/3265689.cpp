#include <iostream>
#include <fstream>
#include <climits>
#define int long long
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");

const int MAX=500;
int n,i,j,k,v[MAX+5],dp[MAX+5][MAX+5],lungime,i2;
signed main()
{
    fin>>n;
    n++;
    for (i=1; i<=n; i++)
        fin>>v[i];

    if (n==2)
    {
        fout<<v[1]*v[2];
        return 0;
    }

    for (i=1; i<=n; i++)
    for (j=1; j<=n; j++)
    dp[i][j]=LLONG_MAX;

    for (i=1; i<n; i++)
        dp[i][i+1]=0;

    for (lungime=3; lungime<=n; lungime++)
    {
        for (i=1; i-lungime+1<=n; i++)
        {
            i2=i+lungime-1;

            for (j=i+1; j<i2; j++)
                dp[i][i2]=min(dp[i][i2],dp[i][j]+dp[j][i2]+v[i]*v[j]*v[i2]);
        }
    }

    fout<<dp[1][n];

    return 0;
}
