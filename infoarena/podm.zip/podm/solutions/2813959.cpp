#include <fstream>

using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
int n, pd[504][504], d[504], cuts[504][504], INF=1000000000;
void citire();
void pdf();
void para(int i, int j);
int main()
{
    citire();
    pdf();
    fout<<pd[1][n];
    return 0;
}
void citire()
{
    int i;
    fin>>n;
    for(i=0; i<=n; i++)
        fin>>d[i];
}
void pdf()
{
    int i, j, k, dif;
    long long sum;
    for(i=1; i<=n; i++)
        pd[i][i]=0;
    for(i=1; i<n; i++)
    {
        pd[i][i+1]=d[i-1]*d[i+1]*d[i];
        cuts[i][i+1]=i;
    }
    for(dif=2; dif<n; dif++)
    {
        for(i=1; i<=n-dif; i++)
        {
            j=i+dif;
            pd[i][j]=INF;
            for(k=i; k<j; k++)
            {
                sum=pd[i][k]+pd[k+1][j]+d[i-1]*d[k]*d[j];
                if(sum<pd[i][j])
                {
                    pd[i][j]=sum;
                    cuts[i][j]=k;
                }
            }
        }
    }
}
