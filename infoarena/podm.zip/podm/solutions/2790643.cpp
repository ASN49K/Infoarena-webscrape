#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <cstring>
#include <string>
#include <unordered_set>
#include <cmath>
#include <functional>
#include <stack>

using namespace std;

ifstream cin("podm.in");
ofstream cout("podm.out");

constexpr long long INF = 1e17;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int n;
    cin >> n;

    vector<long long> v(n+1);
    for (int i = 0; i <= n; i++)
        cin >> v[i];

    vector<vector<long long>> dp(n, vector<long long>(n, INF));
    for (int i = 0; i < n; i++)
        dp[i][i] = 0;
    for (int lg=1;lg<=n;lg++)
        for (int i = 0; i < n - lg + 1; i++)
        {
            int j = i + lg - 1;
            for (int k = i; k < j; k++)
            {
                auto val = dp[i][k] + dp[k + 1][j] + v[i] * v[k + 1] * v[j + 1];
                dp[i][j] = min(dp[i][j], val);
            }
        }
    cout << dp[0][n - 1] << '\n';
    return 0;
}