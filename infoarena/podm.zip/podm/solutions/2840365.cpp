#include <fstream>

using namespace std;

long long dp[505][505];
long long v[505];

ifstream in("podm.in");
ofstream out("podm.out");

int main()
{
    int n;
    cin>>n;
    for(int i=1; i<=n+1; i++){
        cin>>v[i];
    }
    for(int i=n; i>=1; i--){
        for(int j=i+1; j<=n; j++){
            dp[i][j]=1e18;
            for(int k=i; k<j; k++){
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k+1][j]+(long long)v[i]*v[k+1]*v[j+1]);
            }
        }
    }
    cout<<dp[1][n];
    return 0;
}
