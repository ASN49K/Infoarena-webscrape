#include <iostream>
#include <climits>
#include <fstream>

using namespace std;

ifstream in("podm.in");
ofstream out("podm.out");

const int dim = 505;

int n;
unsigned long long d[dim],dp[dim][dim];

int main()
{
    int i,j,k;
    in >> n;
    for (i=0; i<=n; i++)
    {
        in >> d[i];
    }
    for (i=1; i<=n; i++)
    {
        for (j=1; j<=n; j++)
        {
            dp[i][j] = -1;
        }
    }
    for (i=1; i<n; i++)
    {
        dp[i][i] = 0;
        dp[i][i+1] = d[i-1]*d[i]*d[i+1];
    }
    dp[n][n] = 0;
    for (int len=2; len<=n; len++)
    {
        for (i=1; i + len - 1<=n; i++)
        {
            j = i + len -1;
            for (k=i; k<j; k++)
            {
                unsigned long long val = dp[i][k] + dp[k+1][j] + d[i-1]*d[k]*d[j];
                if (dp[i][j] == -1)
                {
                    dp[i][j] = val;
                }
                else dp[i][j] = min(dp[i][j], val);
            }
        }
    }
    out << dp[1][n];
    return 0;
}
