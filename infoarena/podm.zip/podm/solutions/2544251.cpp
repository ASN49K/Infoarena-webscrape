/* problema se reduce la a gasi costul minim de a elimina n-2 nr din sir(mai putin capetele)
costul eliminarii unui elem e egal cu produsul dintre el si vecinii lui
d[st][dr]=costul optim pt a sterge tot dintre st si dr
st,x,dr se obtine eliminand tot dintre [st,x] si [x,dr] (deja calculate)
matricea d o calculam incepand cu prima diagonala deasupra celei principale de sus in jos catre (1,n)
adica secvente [st..dr] cu dr-st intre (2,n-1) */
#include <fstream>
#define INF 10000000000000LL
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long n,i,j,lg,st,dr,k,v[505],d[505][505];
int main(){
    fin>>n; n++;
    for(i=1;i<=n;i++)
        fin>>v[i];
    // d[i][i+1]=0 (lg=1)
    for(lg=2;lg<n;lg++)
        for(st=1;st+lg<=n;st++){
            dr=st+lg;
            d[st][dr]=INF;
            for(k=st+1;k<dr;k++)
                d[st][dr]=min(d[st][dr], d[st][k]+d[k][dr]+v[st]*v[k]*v[dr]);
        }
    fout<<d[1][n];
    return 0;
}
