//
//  main.cpp
//  Podm
//
//  Created by Darius Buhai on 10/11/2018.
//  Copyright © 2018 Darius Buhai. All rights reserved.
//

#include <iostream>
#include <cstdio>

#define inf 110000000LL

using namespace std;

int n, d[501], m[501][501];

int main() {
    freopen("podm.in", "r", stdin);
    freopen("podm.out", "w", stdout);
    cin>>n;
    for(int i=0;i<=n;i++) cin>>d[i];
    for(int i=1;i<n;i++) m[i][i+1] = d[i-1]*d[i]*d[i+1];
    for(int w=2;w<n;w++)
        for(int i=1;i<=n-w;i++){
            int j = i+w;
            m[i][j] = inf;
            for(int k=i;k<j;k++)
                m[i][j] = min(m[i][j], m[i][k] + m[k+1][j] + d[i-1]*d[k]*d[j]);
        }
    cout<<m[1][n];
    return 0;
}
