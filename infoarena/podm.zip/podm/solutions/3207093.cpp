#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");
int dp[505][505];
int main()
{
    int n,i,j,a[505];
    fin>>n;
    for(i=1;i<=n+1;i++) fin>>a[i];

    for(i=1; i<=n; i++)
        dp[i][i] = 0; //iniitalizare. cazul de o singura matrice

    for(i=1; i<n-1; i++)
            {
                dp[i][i+1] =a[i] * a[i+1] * a[i+2]; //m13.5 * m5.89 => 13*5*89 inmultiri
            }

    //(m23 * m34) * (m45 *m56)
    //m24 * m46 = m26

    //dp[i][j] = mi,mi+1,mi+2...mj

    for(int pas=2; pas<n; pas++)
        for(i=1; pas+i<=n; i++)
        {
            j=pas+i; //i=1, j=2
            dp[i][j] = INT_MAX;
            for(int k=i; k<j;k++) //i=1 k=2, j=3 -> (m23 * m34)*m45 =
                dp[i][j] = min( dp[i][j], dp[i][k] + dp[k+1][j] + a[i]*a[k+1]*a[j+1]); //Mmn * Mnp are m*n*p inmultiri scalare
        }

    fout<<dp[1][n];
    return 0;
}
