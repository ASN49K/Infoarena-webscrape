#include <fstream>
#define INF 1000000000000000

using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

long long int a[502], dp[502][502];
int n, i, j, k, len;

int main()
{
    fin >> n;
    for(i=0; i<=n; i++)
        fin >> a[i];
    for(len=2; len<=n; len++)
        for(i=1, j=len; j<=n; i++, j++){
            dp[i][j] = INF;
            for(k=i; k<j; k++)
                dp[i][j]=min(dp[i][j], dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j]);
           }
    fout << dp[1][n];
    return 0;
}
