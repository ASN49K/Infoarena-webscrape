#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int minScalarMultiplications(const vector<int> &dimensiuni)
{
    int n = dimensiuni.size() - 1;
    vector<vector<int>> memo(n, vector<int>(n, INT_MAX));
    // Matricele de o singură dimensiune nu necesită înmulțiri scalare
    for (int i = 0; i < n; ++i)
    {
        memo[i][i] = 0;
    }
    // Calculează minimul pentru toate lungimile de lanțuri de matrice
    for (int lungime = 2; lungime <= n; ++lungime)
    {
        for (int i = 0; i <= n - lungime; ++i)
        {
            int j = i + lungime - 1;
            for (int k = i; k < j; ++k)
            {
                int cost = memo[i][k] + memo[k + 1][j] + dimensiuni[i] * dimensiuni[k + 1] * dimensiuni[j + 1];//Matematica
                memo[i][j] = min(memo[i][j], cost);
            }
        }
    }

    return memo[0][n - 1];
}

ifstream in("podm.in");
ofstream out("podm.out");

int main()
{
    int n;
    in >> n;
    vector<int> dimensiuni(n + 1);
    for (int i = 0; i <= n; ++i)
    {
        in >> dimensiuni[i];
    }
    int rezultat = minScalarMultiplications(dimensiuni);
    out << rezultat << endl;
    in.close();
    out.close();
    return 0;
}
