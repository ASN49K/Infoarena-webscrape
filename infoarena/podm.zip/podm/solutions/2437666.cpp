#include <bits/stdc++.h>
#define NMAX 510
#define INF 99999999999
using namespace std;
ifstream fin("podm.in");
ofstream fout("podm.out");
long long int m[NMAX][NMAX];
long long int d[NMAX];
int n;
void citire();
///vreau sa ii dau tare si pe interzis

int main()
{
 citire();
    return 0;
}
void citire()
{int i,k,dr;
 fin>>n;
 for(i=0;i<=n;i++)
        fin>>d[i];
 for(i=1;i<n;i++)
    m[i][i+1]=d[i-1]*d[i]*d[i+1];
for(dr=2;dr<n;dr++)
    for(i=1;i+dr<=n;i++)
        {
         long long int minim=INF;
         for(k=i;k<i+dr;k++)
             minim=min(minim, m[i][k]+m[k+1][i+dr] +d[i-1]*d[k]*d[i+dr]);
         m[i][i+dr]=minim;
        }
  fout<<m[1][n];
}
