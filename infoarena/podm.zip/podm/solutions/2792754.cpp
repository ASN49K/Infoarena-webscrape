#include <bits/stdc++.h>
using namespace std;

ifstream fin("podm.in");
ofstream fout("podm.out");

int n;
int v[505], dp[505][505];

int main()
{
    fin>>n;
    for(int i=0; i<=n; i++)
        fin>>v[i];
    for(int i=n; i>=0; i--)
    {
        for(int j=i+1; j<=n; j++)
        {
            dp[i][j] = INT_MAX;
            for(int w = i; w < j; w++)
                dp[i][j] = min(dp[i][j], dp[i][w] + dp[w+1][j] + v[i-1]*v[w]*v[j]);
        }
    }
    fout<<dp[1][n];
    return 0;
}
