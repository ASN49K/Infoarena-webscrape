#include <bits/stdc++.h>
#define int long long
using namespace std;
const int NMAX = 502;
int n,v[NMAX],dp[NMAX][NMAX];

ifstream fin("podm.in");
ofstream fout("podm.out");

signed main()
{
    fin >> n;
    n++;
    for(int i = 1; i <= n; i++){
        fin >> v[i];
        dp[i][i+1] = 0;
    }
    for(int l = 3; l <= n; l++){
        for(int i = 1; i <= n-l+1; i++){
            int j = i+l-1;
            dp[i][j] = LLONG_MAX;
            for(int k = i+1; k < j; k++){
                dp[i][j] = min(dp[i][j], dp[i][k]+dp[k][j]+v[i]*v[k]*v[j]);
            }
        }
    }
    fout << dp[1][n];
    return 0;
}
