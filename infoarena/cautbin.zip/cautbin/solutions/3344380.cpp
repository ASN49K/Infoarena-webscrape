#include <bits/stdc++.h>
using namespace std;
ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
long long int n,v[1000001],m,x,y;
int main(){
    fin>>n;
    for(int i=1; i<=n; ++i)
        fin>>v[i];
    fin>>m;
    for(int i=1; i<=m; ++i){
        fin>>x>>y;
        if(x==0){
            auto val1=*lower_bound(v+1,v+n+1,y);
            auto *val2=upper_bound(v+1,v+n+1,y);
            if(y==val1)
                fout<<val2-v-1<<"\n";
            else
                fout<<-1<<"\n";
        }else{
            if(x==1){
                auto *val2=upper_bound(v+1,v+n+1,y);
                fout<<val2-v-1<<"\n";
            }
            else{
                auto *val1=lower_bound(v+1,v+n+1,y);
                fout<<val1-v<<"\n";
            }
        }
    }
}