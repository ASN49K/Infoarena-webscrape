#include<fstream>
#include<math.h>
using namespace std;
long long int v[100019]={};
long long int cb0(long long int n, long long int v[], long long int x){
    long long int r=0;
    long long int t=1;
    while(t*2<=n){
        t*=2;
    }
    for(long long int i=t;i>0;i/=2){
        if(v[r+i]<=x && r+i<=n){
            r+=i;
        }
    }
    if(v[r]==x){
        return r;
    }else{
        return -1;
    }
}
long long int cb1(long long int n, long long int v[], long long int x){
    long long int r=0;
    long long int t=1;
    while(t*2<=n){
        t*=2;
    }
    for(long long int i=t;i>0;i/=2){
        if(v[r+i]<=x && (r+i)<=n){
            r+=i;
        }
    }
    return r;
}
long long int cb2(long long int n, long long int v[], long long int x){
    long long int r=n;
    long long int t=1;
    while(t*2<=n){
        t*=2;
    }
    for(long long int i=t;i>0;i/=2){
        if(v[r-i]>=x && (r-i)>0){
            r-=i;
        }
    }
    return r;
}
int main(){
    ifstream in("cautbin.in");
    ofstream out("cautbin.out");
    long long int n,m,x,y;
    in>>n;
    for(long long int i=1;i<=n;i++){
        in>>v[i];
    }
    in>>m;
    for(long long int i=1;i<=m;i++){
        in>>x>>y;
        if(x==0){
            out<<cb0(n,v,y)<<'\n';
        }else{
            if(x==1){
                out<<cb1(n,v,y)<<'\n';
            }else{
                out<<cb2(n,v,y)<<'\n';
            }
        }
    }
}
