#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100005];
    int n;
int cautarebinara(int x){
    int st=1;
    int dr=n;
    int ans=0;

    while(st<=dr){
        int med=(dr+st)/2;
        if(v[med]>x){
            dr=med-1;
        }
        else{
            st=med+1;
            ans=med;
        }
    }

    return ans;
}
int cautarebinara2(int x){
    int st=1;
    int dr=n;
    int ans=0;

    while(st<=dr){
        int med=(dr+st)/2;
        if(v[med]>=x){
            dr=med-1;
            ans=med;
        }
        else{
            st=med+1;

        }
    }
    return ans;
}
int main()
{

    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
    }
    int m,x;
    fin>>m;
    for(int i=1;i<=m;i++){
        int op;
        fin>>op>>x;
        if(op==1 || op==0){
            int poz=cautarebinara(x);
            if(v[poz]!=x){
                fout<<-1<<'\n';
            }
            else{
                fout<<cautarebinara(x)<<'\n';
            }

        }
        if(op==2){
            fout<<cautarebinara2(x)<<'\n';
        }


    }
}
