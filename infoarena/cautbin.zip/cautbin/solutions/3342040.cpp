#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100005];

int main()
{
    int n, m, tip, x;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    fin>>m;
    while(m--)
    {
        fin>>tip>>x;
        if(tip==0)
        {
            int ans=0;
            for(int pas=1<<17; pas>0; pas/=2)
            {
                if(ans+pas<=n && v[ans+pas]<=x)
                {
                    ans+=pas;
                }
            }
            if(v[ans]==x)
                fout<<ans<<"\n";
            else
                fout<<"-1\n";
        }
        else if(tip==1)
        {
            int ans=0;
            for(int pas=1<<17; pas>0; pas/=2)
            {
                if(ans+pas<=n && v[ans+pas]<=x)
                {
                    ans+=pas;
                }
            }
            fout<<ans<<"\n";
        }
        else
        {
            int ans=n;
            for(int pas=1<<17; pas>0; pas/=2)
            {
                if(ans>=pas && v[ans-pas]>=x)
                {
                    ans-=pas;
                }
            }
            fout<<ans<<"\n";
        }
    }
    return 0;
}
