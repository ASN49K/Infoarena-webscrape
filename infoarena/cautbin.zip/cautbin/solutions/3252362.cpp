#include <iostream>
#include <fstream>
#define DMAX 100005
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[DMAX];
int main()
{int n, i, cer, m, k, x;
fin >> n;
for(i = 1; i <= n; i++)fin >> v[i];
fin >> m;
for(k = 0; k < m; k++)
{fin >> cer >> x;
if(cer == 0)
{int st = 0, dr = n + 1;
while(dr - st > 1)
{int mij = (st + dr) / 2;
if(v[mij] > x)dr = mij;
else st = mij;
            }
            if(st <= n && v[st] == x)
                fout << st << '\n';
                else
                    fout << -1 << '\n';
        }
        else if(cer == 1)
        {
            int st = 0, dr = n + 1;
            while(dr - st > 1)
            {
                int mij = (st + dr) / 2;
                if(v[mij] > x)
                    dr = mij;
                    else
                        st = mij;
            }
            fout << st << '\n';
        }
        else
        {
            int st = 0, dr = n + 1;
            while(dr - st > 1)
            {
                int mij = (st + dr) / 2;

                if(v[mij] >= x)
                    dr = mij;
                    else
                        st = mij;
            }
            fout << dr << '\n';
        }

    }

    return 0;
}
