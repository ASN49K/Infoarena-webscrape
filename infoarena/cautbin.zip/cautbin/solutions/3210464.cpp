#include <fstream>

using namespace std;
const int nmax=100000;

int N,v[nmax+1];

ifstream f("cautbin.in");
ofstream g("cautbin.out");

int caut0(int x)
{
    int p=1,u=N,poz=-1;
    while(p<=u)
    {
        int m=(p+u)/2;
        if(x==v[m])
            poz=m;
        if(x>=v[m])
            p=m+1;
        else
            u=m-1;
    }
    return poz;
}

int caut1(int x)
{
    int p=1,u=N,poz=-1;
    while(p<=u)
    {
        int m=(p+u)/2;
        if(x>=v[m])
        {
            poz=m;
            p=m+1;
        }
        else
            u=m-1;
    }
    return poz;
}

int caut2(int x)
{
    int p=1,u=N,poz=-1;
    while(p<=u)
    {
        int m=(p+u)/2;
        if(x<=v[m])
        {
            poz=m;
            u=m-1;
        }
        else
            p=m+1;
    }
    return poz;
}

int main()
{
    int M,x,t;
    f>>N;
    for(int i=1;i<=N;i++)
        f>>v[i];
    f>>M;
    while(M--)
    {
        f>>t>>x;
        switch(t)
        {
        case 0:
            g<<caut0(x)<<'\n';
            break;
        case 1:
            g<<caut1(x)<<'\n';
            break;
        case 2:
            g<<caut2(x)<<'\n';
        }
    }
    f.close();
    g.close();
    return 0;
}
