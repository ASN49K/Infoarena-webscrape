#include <bits/stdc++.h>
#define START ios::sync_with_stdio(false); fin.tie(NULL); fout.tie(NULL);
#define STOP fin.close(); fout.close(); return 0;
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n, tip, x, m;

int main()
{
    START
    fin >> n;
    vector <int> v(n);
    for(int &a:v)
        fin >> a;
    fin >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> tip  >> x;
        int st = lower_bound(v.begin(),v.end(),x)-v.begin();
        int dr = upper_bound(v.begin(),v.end(),x)-v.begin()-1;
        if(tip==0)
        {
            if(v[dr]==x)
                fout << dr+1 << '\n';
            else
                fout << -1 << '\n';
        }
        else if(tip==1)
        {
            fout << dr+1 << '\n';
        }
        else if(tip==2)
        {
            fout << st+1 << '\n';
        }
    }
    STOP
}