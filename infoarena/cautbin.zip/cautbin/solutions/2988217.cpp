#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n,m,v[100005],x,nr;

int main()
{
    fin>>n;
    for(int i=1;i<=n;++i)
        fin>>v[i];
    fin>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>x>>nr;
        int a=upper_bound(v+1,v+n+1,nr)-v,b=lower_bound(v+1,v+n+1,nr)-v;
        if(x==0)
        {
            if(v[a-1]==nr)
                fout<<a-1<<'\n';
            else
                fout<<"-1\n";
        }else if(x==1)
        {
            if(v[a-1]==nr)
                fout<<a-1<<'\n';
            else
                fout<<a<<'\n';
        }else
        {
            fout<<b<<'\n';
        }
    }
    return 0;
}
