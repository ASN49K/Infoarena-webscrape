#include <cstdio>

using namespace std ;
FILE *fin, *fout ;

#define NMAX 100000
int v[NMAX + 5] ;
int n ;

int task0 (int nr)
{
    nr++;
    int left = 1, right = n, mid;
    bool ok = false;

    while(left <= right)
    {
        mid = (left + right) / 2 ;

        if(v[mid] < nr and v[mid + 1] >= nr)
            return mid;

        else if(v[mid] < nr)
            left = mid + 1 ;
        else if(v[mid] >= nr)
            right = mid - 1;
    }

    if(ok == false)
        return -1 ;
}



int task1 (int nr)
{
    int left = 1, right = n, mid ;

    while(left <= right)
    {
        mid = (left + right) / 2;

        if(mid == n)
            return mid;

        if(v[mid] <= nr and v[mid + 1] > nr)
            return mid;
        else if(v[mid] <= nr)
            left = mid + 1 ;
        else if(v[mid] > nr)
            right = mid - 1 ;
    }
}

int task2 (int nr)
{
    int left = 1, right = n, mid ;

    while(left <= right)
    {
        mid = (left + right) / 2 ;

        if(v[mid] >= nr and v[mid - 1] < nr)
            return mid;
        else if(v[mid] <= nr)
            left = mid + 1;
        else right = mid - 1;
    }
}

int main()
{
    fin = fopen("cautbin.in", "r") ;
    fout = fopen("cautbin.out", "w") ;

    fscanf(fin, "%d", &n) ;

    for(int i = 1 ; i <= n ; i++)
        fscanf(fin, "%d", &v[i]) ;

    int m ;
    fscanf(fin, "%d", &m) ;

    for(int i = 1 ; i <= m ; i++)
    {
        int task, nr ;
        fscanf(fin, "%d%d", &task, &nr) ;

        if(task == 0)
        {
            int t0 = task0(nr);

            if(t0 == -1)
                fprintf(fout, "-1\n");
            else if(v[t0] == nr)
                fprintf(fout, "%d\n", t0);
            else fprintf(fout, "-1\n");
        }
        else if(task == 1)
            fprintf(fout, "%d\n", task1(nr)) ;
        else if(task == 2)
            fprintf(fout, "%d\n", task2(nr)) ;
    }
    fclose(fin) ;
    fclose(fout) ;
    return 0 ;
}
