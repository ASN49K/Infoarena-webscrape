#include <bits/stdc++.h>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int N,M,a[100001],C,x;
int main()
{
    fin>>N;
    for(int i=1; i<=N; i++)
        fin>>a[i];
    fin>>M;
    for(int i=1; i<=M; i++)
    {
        fin>>C>>x;
        if(C==0)
        {
            int st=1,dr=N;
            while(st<dr)
            {
                int mij=(st+dr+1)/2;
                if(a[mij]<=x)
                    st=mij;
                else
                    dr=mij-1;
            }
            if(a[st]==x)
                fout<<st<<'\n';
            else
                fout<<-1<<'\n';
        }
        else if(C==1)
        {
            int st=1,dr=N;
            while(st<dr)
            {
                int mij=(st+dr+1)/2;
                if(a[mij]<=x)
                    st=mij;
                else
                    dr=mij-1;
            }
            fout<<st<<'\n';
        }
        else
        {
            int st=1,dr=N;
            while(st<dr)
            {
                int mij=(st+dr)/2;
                if(a[mij]<x) st=mij+1;
                else
                    dr=mij;
            }
            fout<<st<<'\n';
        }
    }
    return 0;
}
