#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("maraton1.in");
ofstream fout("maraton1.out");

int a[100000];
int main()
{
    int N,M,q,x;
    fin>>N;
    for(int i=0; i<N; i++) fin>>a[i];

    fin>>M;
    for(int i=0; i<M; i++)
    {
        fin>>q>>x;
        if(q==0)
        {
            int st=0,dr=N-1,mijl,poz=-1;
            while(st<=dr)
            {
                mijl=st+(dr-st)/2;
                if(x<a[mijl]) dr=mijl-1;
                else if(a[mijl]<x) st=mijl+1;
                else st=mijl+1,poz=mijl;
            }
            if(poz!=-1) fout<<poz+1<<'\n';
            else fout<<-1<<'\n';
        }
        else if(q==1)
        {
            int st=0,dr=N-1,mijl,poz=-1;
            while(st<=dr)
            {
                mijl=st+(dr-st)/2;
                if(a[mijl]<=x) st=mijl+1,poz=mijl;
                else dr=mijl-1;
            }
            if(poz!=-1) fout<<poz+1<<'\n';
            else fout<<-1<<'\n';
        }
        else
        {
            int st=0,dr=N-1,mijl,poz=-1;
            while(st<=dr)
            {
                mijl=st+(dr-st)/2;
                if(x<=a[mijl]) poz=mijl,dr=mijl-1;
                else st=mijl+1;
            }
            if(poz!=-1) fout<<poz+1<<'\n';
            else fout<<-1<<'\n';
        }
    }
    fin.close();
    fout.close();
    return 0;
}

