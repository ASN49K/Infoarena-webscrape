#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int maxN = 100005;
int n, q, v[maxN];

int main() {
    fin >> n;
    for (int i = 0; i < n; i++) {
        fin >> v[i];
    }
    fin >> q;
    while (q--) {
        int op, val;
        fin >> op >> val;
        if (op == 0) {
            int st = 0, dr = n, ans = 0;
            while (st < dr) {
                int med = (st + dr) / 2;
                if (v[med] <= val) {
                    st = med + 1;
                    ans = med;
                }
                else {
                    dr = med;
                }
            }
            if (v[ans] == val) {
                fout << ans + 1 << '\n';
            }
            else {
                fout << "-1\n";
            }
        }
        if (op == 1) {
            int st = 0, dr = n, ans = 0;
            while (st < dr) {
                int med = (st + dr) / 2;
                if (v[med] <= val) {
                    st = med + 1;
                    ans = med;
                }
                else {
                    dr = med;
                }
            }
            fout << ans + 1 << '\n';
        }
        if (op == 2) {
            int st = 0, dr = n, ans = 0;
            while (st < dr) {
                int med = (st + dr) / 2;
                if (v[med] < val) {
                    st = med + 1;
                    ans = med;
                }
                else {
                    dr = med;
                }
            }
            fout << ans + 2 << '\n';
        }
    }
    return 0;
}
