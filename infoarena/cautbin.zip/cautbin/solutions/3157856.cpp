#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
typedef long long ll;
int main()
{
    freopen("cautbin.in","r",stdin);
    freopen("cautbin.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll a,b,c,d,n,i,x,y,rez,j,k,l,m,q,st,dr,mid;
    cin>>n;
    vector<ll> v(n+1);
    for(i=1;i<=n;i++)cin>>v[i];
    cin>>q;
    while(q--)
    {
        cin>>c>>x;
        st=1,dr=n;
        if(c!=2)
        while(true)
        {
            if(st==dr){if(v[st]<=x)rez=st;break;}
            mid=(st+dr)/2;
            if(v[mid]<=x)rez=mid,st=mid+1;
            else dr=mid;
        }
        else
        while(true)
        {
            if(st==dr){if(v[st]>=x)rez=st;break;}
            mid=(st+dr)/2;
            if(v[mid]>=x)rez=mid,dr=mid;
            else st=mid+1;
        }
        if(c==0&&v[rez]!=x)rez=-1;
        cout<<rez<<'\n';
    }
	return 0;
}
