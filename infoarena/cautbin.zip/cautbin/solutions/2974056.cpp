#include<bits/stdc++.h>
using namespace std;

const int N = 100009;
int n, v[N];

ifstream in ("cautbin.in");
ofstream out("cautbin.out");
// auto& in = cin;
// auto& out = cout;
unsigned upper_bound(int x)
{
	unsigned poz=0;
	for(unsigned i=1<<31; i; i>>=1)
		if((poz|i) < n && v[poz|i] <= x)
		{
			// out<<"i: "<<i<<endl;
			// out<<"poz|i: "<<(poz|i)<<endl;
			poz|=i;	
		}
	return poz;
}
unsigned lower_bound(int x)
{
	unsigned poz=0;
	for(unsigned i=1<<31; i; i>>=1)
		if((poz|i) < n && v[poz|i] < x)
			poz|=i;
	return poz+1;
}
int main(){
	in>>n;
	for(int i=0; i < n; i++)
		in>>v[i];
	
	int m, t, x, u, l;
	for(in>>m; m>0; m--)
	{
		in>>t>>x;
		u = upper_bound(x) + 1;
		l = lower_bound(x) + 1;
		if(t==0) out<<(l<u?u:-1)<<endl;
		if(t==1) out<<u<<endl;
		if(t==2) out<<l<<endl;
		
	}
	return 0;
}