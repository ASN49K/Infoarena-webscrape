#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
int a[200001];
int main()
{
    ifstream cin ("cautbin.in");
    ofstream cout ("cautbin.out");
    int n, T, x, y, l, r, mid, m1, m2;
    cin >> n;
    for(int i=1; i<=n; i++)
    {
        cin >> a[i];
    }
    cin >> T;
    for(int i=1; i<=T; i++)
    {
        cin >> x >> y;
        l=1;
        r=n+1;
        while(l<r)
        {
            mid=(l+r)/2;
            if(a[mid]<x)
                l=mid+1;
            else
                r=mid;
        }
        m1=l;
        l=1;
        r=n+1;
        while(l<r)
        {
            mid=(l+r)/2;
            if(a[mid]<=y)
                l=mid+1;
            else
                r=mid;
        }
        m2=l;
        cout << m2-m1 << endl;
    }
    return 0;
}
