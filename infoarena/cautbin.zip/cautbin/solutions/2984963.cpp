#include <bits/stdc++.h>

using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");

int n, v[100005], m;
void cautareb(int x)
{
    int s = -1, l = 1, r = n, m;
    while (l <= r)
    {
        m = (l + r) / 2;

        if (v[m] > x)
        {
            r = m - 1;

        }
        if (v[m] <= x)
        {
            l = m + 1;
            s = m;
        }
    }
    if (v[s] != x)
    {
        g << -1 << "\n";
    }
    else g << s << "\n";
}

void cautareb2(int x, int n, int v[100005])
{
    int s = -1, l = 1, r = n, m;
    while (l <= r)
    {
        m = (l + r) / 2;

        if (v[m] > x)
        {
            r = m - 1;

        }
        if (v[m] <= x)
        {
            l = m + 1;
            s = m;
        }
    }
    g << s << "\n";
}

void cautareb1(int x)
{
    int s = -1, l = 1, r = n, m;
    while (l <= r)
    {
        m = (l + r) / 2;

        if (v[m] >= x)
        {
            r = m - 1;
            s = m;
        }
        if (v[m] < x)
        {
            l = m + 1;

        }
    }
    g << s << "\n";
}


int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
    }
    f >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;
        if (x == 0) cautareb(y);
        if (x == 1) cautareb2(y);
        if (x == 2) cautareb1(y);
    }

    return 0;
}