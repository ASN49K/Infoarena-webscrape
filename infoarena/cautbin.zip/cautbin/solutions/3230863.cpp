#include <bits/stdc++.h>

using namespace std;
int v[100001],n;
void binar1(int val)
{
    int st=1,dr=n,mid,rasp=-1;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(v[mid]==val)
        {
            rasp=mid;
            st=mid+1;
        }
        else if(v[mid]<val)
            st=mid+1;
        else dr=mid-1;
    }
    fout<<rasp<<'\n';
}
void binar2(int val)
{
    int st=1,dr=n,mid,rasp;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(v[mid]<=val)
        {
            rasp=mid;
            st=mid+1;
        }
        else dr=mid-1;
    }
    fout<<rasp<<'\n';
}
void binar3(int val)
{
    int st=1,dr=n,mid,rasp;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(v[mid]>=val)
        {
            rasp=mid;
            dr=mid-1;
        }
        else st=mid+1;
    }
    fout<<rasp<<'\n';
}
void binar(int val,int type)
{
    if(type==0)
        binar1(val);
    else if(type==1)
        binar2(val);
    else binar3(val);
}
int main()
{
    ifstream fin("cautbin.in");
    ofstream fout("cautbin.out");

    int q,x,type;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    sort(v+1,v+n+1);
    fin>>q;
    for(int i=1;i<=q;i++)
    {
        fin>>type>>x;
        binar(x,type);
    }
    return 0;
}
