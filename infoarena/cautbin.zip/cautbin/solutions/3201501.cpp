#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <limits.h>
#include <chrono>
#include <numeric>

#include <vector>
#include <string>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <bitset>
#include <deque>  
#include <stack>
#include <queue>
#include <list>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<string, string> pss;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;
typedef vector<pll> vll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef vector<bool> vb;
typedef vector<vb> vvb;
 
double EPS = 1e-9;
int INF = 1000000005;
long long INFF = 1000000000000000005LL;
double PI = acos(-1);

#define M 1000000007

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

struct custom_hash {
    static uint64_t splitmix64(uint64_t x) {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

template<class T> T nxt() {
    T x;
    cin >> x;
    return x;
}

int leftmostLowerBound(const vi& v,const int& x){
    int n=v.size();
    int step,pos;
    for(step=1;step<n;step<<=1);

    for(pos=n-1;step;step>>=1){
        if(pos-step>=0&&v[pos-step]>=x){
            pos-=step;
        }
    }

    return pos;
}

int leftmostUpperBound(const vi& v,const int& x){
    int n=v.size();
    int step,pos;
    for(step=1;step<n;step<<=1);

    for(pos=n-1;step;step>>=1){
        if(pos-step>=0&&v[pos-step]>x){
            pos-=step;
        }
    }

    return pos;
}

void Solve(){
    int n;
    cin>>n;
    vi v(n);
    for(int i=0;i<n;++i){
        cin>>v[i];
    }

    int m;
    cin>>m;
    for(int i=0;i<m;++i){
        int t,x,pos;
        cin>>t>>x;
        if(t==2){
            pos=leftmostLowerBound(v,x)+1;
        }
        else{
            pos=leftmostUpperBound(v,x);
            --pos;
            if(t==0){
                if(pos<0||pos>=n||v[pos]!=x){
                    pos=-2;
                }
            }
            ++pos;
        }

        cout<<pos<<'\n';
    }
}   

int main(){
    // freopen("cautbin.in", "r", stdin);
    // freopen("cautbin.out", "w", stdout);

    // ios_base::sync_with_stdio(false);
    // cin.tie(NULL);

    // std::string file="FILE";
    // std::ifstream in(file+".in");
    // std::streambuf *finbuf = std::fin.rdbuf(); //save old buf
    // fin.rdbuf(in.rdbuf()); //redirect std::fin
    
    // std::ofstream out(file+".out");
    // std::streambuf *foutbuf = std::fout.rdbuf(); //save old buf
    // fout.rdbuf(out.rdbuf()); //redirect std::fout
	
    Solve();

    // std::fin.rdbuf(finbuf);   //reset to standard input again
    // std::fout.rdbuf(foutbuf); //reset to standard output again

    return 0;
}