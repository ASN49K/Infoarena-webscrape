#include <iostream>
#include <fstream>
using namespace std;
ifstream in("cautbin.in");
ofstream out("cautbin.out");
int n, v[100001], x, m, t;
int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
        in>>v[i];
    in>>m;
    for(int i=1;i<=m;i++)
    {
        in>>t>>x;
        if(t==0)
        {
            int st=1, dr=n;
            int val=-1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>x)
                    dr=mij-1;
                else if(v[mij]<x)
                    st=mij+1;
                else
                {
                    val=mij;
                    st=mij+1;
                }
            }
            out<<val<<"\n";
        }
        else if(t==1)
        {
            int st=1, dr=n, val=-1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>x)
                    dr=mij-1;
                else
                {
                    val=mij;
                    st=mij+1;
                }
            }
            out<<val<<"\n";
        }
        else if(t==2)
        {
            int st=1, dr=n, val=n+1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]<x)
                    st=mij+1;
                else
                {
                    val=mij;
                    dr=mij-1;
                }
            }
            if(st==dr && v[st]>=x)
                val=st;
            out<<val<<"\n";
        }
    }
    return 0;
}
