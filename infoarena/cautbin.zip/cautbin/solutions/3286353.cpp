#include<fstream>
#include<algorithm>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
   int v[1000001] ;

int main(){
     
int n , k , x , q  ;
     cin>>n;
       for(int i = 1 ; i <= n ; i ++ )
         cin>>v[i];
        sort(v+1,v+n+1);
      cin>>k;
        for(int i = 1 ; i <= k ; i ++ ){
              cin>>q>>x;
                  if(q==0){
                    int ind = upper_bound(v+1,v+n+1,x) - v - 1  ; 
                           if(ind>=1 && ind<= n && v[ind] == x )
                                cout<<ind-1<<endl;
                                  else
                                   cout<<-1<<endl;
                  }else if(q==1){
                       int index = lower_bound(v+1,v+n+1,x) - v -1;
                         cout<<index<<endl;

                  }else if(q==2){
                       int indx = upper_bound(v+1,v+n+1,x) - v - 1 ;
                         cout<<indx<<endl;
                  }
        }
 
 
 
 
 
 
    return 0 ; 
}