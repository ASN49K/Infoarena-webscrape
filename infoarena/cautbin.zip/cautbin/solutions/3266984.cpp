#include<fstream>

using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int n,m[100002],dr,st,x,a,b,mij;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>m[i];
    cin>>x;
    for(int i=1;i<=x;i++){
        cin>>a>>b;
        int poz=0;
        st=1,dr=n;
        while(st<=dr){
            mij=(st+dr)/2;
            if(m[mij]==b){
                poz=mij;
                break;
            }
            if(m[mij]>b)
                dr=mij-1;
            else
                st=mij+1;
            poz=mij;
        }
        if(a==0){
            if(m[poz]==b){
                while(m[poz+1]==b)
                    poz++;
                cout<<poz<<'\n';
            }
            else
                cout<<-1<<'\n';
        }
        else if(a==1){
            while(m[poz+1]==b)
                poz++;
            if(m[poz]>b)
                cout<<poz-1<<'\n';
            else
                cout<<poz<<'\n';
        }
        else{
            while(m[poz-1]==b)
                poz--;
            if(m[poz]<b)
                cout<<poz+1<<'\n';
            else
                cout<<poz<<'\n';
        }
        //cout<<poz;
    }
    return 0;
}
