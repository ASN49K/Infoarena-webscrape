#include<fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX = 1e5;

int v[NMAX+1], n;

int cb_0(int y)
{
    int st = 1, dr = n, rez = -1;
    while(st <= dr)
    {
        int m = (st+dr)/2;
        if (v[m] == y)
            rez = m, st = m+1;
        if (v[m] < y)
            st = m+1;
        if (v[m] > y)
            dr = m-1;
    }
    return rez;
}

int cb_1(int y)
{
    int st = 1, dr = n, rez;
    while(st <= dr)
    {
        int m = (st+dr)/2;
        if(v[m] <= y)
            rez = m, st = m+1;
        else
            dr = m-1;
    }
    return rez;
}

int cb_2(int y)
{
    int st = 1, dr = n, rez;
    while(st <= dr)
    {
        int m =(st+dr)/2;
        if(v[m] >= y)
            rez = m, dr = m-1;
        else
            st = m+1;
    }
    return rez;
}

int main()
{
    int M, x, y;
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> v[i];
    fin >> M;
    for(int i = 0; i < M; i++)
    {
        fin >> x >> y;
        if (x == 0)
            fout << cb_0(y) << "\n";
        else
            if (x == 1)
                fout << cb_1(y) << "\n";
            else
                if (x == 2)
                    fout << cb_2(y) << "\n";
    }
}
