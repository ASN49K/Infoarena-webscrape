#include <fstream>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int v[100001];

int main() {
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> v[i];

    int m;
    cin >> m;

    for(int q = 0; q < m; q++) {
        int tip, x;
        cin >> tip >> x;

        if(tip == 0) {
            int st = 1, dr = n, rez = -1;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] == x) { rez = mid; st = mid + 1; }
                else if(v[mid] < x) st = mid + 1;
                else dr = mid - 1;
            }
            cout << rez << "\n";
        }
        else if(tip == 1) {
            int st = 1, dr = n, rez = 0;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] <= x) { rez = mid; st = mid + 1; }
                else dr = mid - 1;
            }
            cout << rez << "\n";
        }
        else if(tip == 2) {
            int st = 1, dr = n, rez = n+1;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] >= x) { rez = mid; dr = mid - 1; }
                else st = mid + 1;
            }
            cout << rez << "\n";
        }
    }

    return 0;
}
