#include <bits/stdc++.h>
#pragma GCC optimize("03")
#define ll long long
#define u unsigned
using namespace std;

signed main() {
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");

    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    sort(a.begin(), a.end());
    int q;
    cin >> q;
    for (int i = 0; i < n; i++) {
        char tip;
        int x;
        cin >> tip >> x;
        if (tip == '0') {
            int st = 0, dr = n-1;
            while (st<=dr) {
                int mid = (st+dr)/2;
                if (a[mid] > x) dr = mid+1;
                else if (a[mid] < x) st = mid-1;
            }
            while (a[dr] == a[dr+1]) dr++;
            if (a[dr] == x)cout << dr<<'\n';
            else cout<<-1<<'\n';

        } else if (tip == '1') {

        } else if (tip == '3') {

        }
    }
}
