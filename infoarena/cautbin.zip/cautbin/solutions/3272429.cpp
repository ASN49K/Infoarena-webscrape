#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int arr[100000];

int main()
{
    int n, m, c, x, l, r, mij, pos;
    fin >> n;
    for (int i=0; i<n; i++) fin >> arr[i];
    fin >> m;
    for (int i=1; i<=m; i++) {
        fin >> c >> x;
        if (c == 0 || c == 1) {
            pos = upper_bound(arr, arr + n, x) - arr - 1;
            if (c == 0 && arr[pos] != x) fout << "-1\n";
            else fout << pos + 1 << endl;
        }
        else {
            pos = lower_bound(arr, arr + n, x) - arr;
            fout << pos + 1 << endl;
        }
    }
}
