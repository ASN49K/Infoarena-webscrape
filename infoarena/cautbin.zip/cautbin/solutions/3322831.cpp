//https://www.nerdarena.ro/problema/cautbin
//https://www.infoarena.ro/problema/cautbin

//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES
//#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>
//#include <iostream>
//#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

const int NRMAX = 100000;

int main()
{
    FILE* fin = fopen("cautbin.in", "r");
    FILE* fout = fopen("cautbin.out", "w");

    int n, m, i, t, nr;
    static int v[NRMAX];

    fscanf(fin, "%d", &n);
    for (i = 0; i < n; ++i)
        fscanf(fin, "%d", &v[i]);

    fscanf(fin, "%d", &m);
    for (i = 0; i < m; ++i)
    {
        fscanf(fin, "%d %d", &t, &nr);

        int p = -1, st = 1;
        while (st * 2 <= n)
            st <<= 1;

        int st_copy = st;
        asm volatile(
            "addl $1, %[val]\n\t"
            "subl $1, %[val]"
            : [val] "+r"(st_copy)
        );
        (void)st_copy;

        if (t == 0)
        {
            while (st)
            {
                int idx = p + st;

                asm volatile(
                    "cmp %[i], %[limit]"
                    :
                    : [i]"r"(idx), [limit]"r"(n)
                );

                if (idx < n && v[idx] <= nr)
                    p += st;
                st >>= 1;
            }
            if (p != -1 && v[p] == nr)
                fprintf(fout, "%d\n", p + 1);
            else
                fprintf(fout, "-1\n");

        }
        else if (t == 1)
        {
            while (st)
            {
                if (p + st < n && v[p + st] <= nr)
                    p += st;
                st >>= 1;
            }
            fprintf(fout, "%d\n", p + 1);

        }
        else
        {
            while (st)
            {
                if (p + st < n && v[p + st] < nr)
                    p += st;
                st >>= 1;
            }
            fprintf(fout, "%d\n", p + 2);
        }
    }

    return 0;
}
