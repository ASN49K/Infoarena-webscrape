#include <fstream>

int elso(int tomb[], int n, int x){
	int bal = 0, jobb = n-1, megtalalt = -1;
	while(bal <= jobb){
		int kozep = (bal + jobb) / 2;
		if(tomb[kozep] == x){
			megtalalt = kozep + 1;
			bal = kozep + 1;
		}
		else if(tomb[kozep] < x) 
			bal = kozep + 1;
		else 
			jobb = kozep - 1;
	}
	return megtalalt;
}

int masodik(int tomb[], int n, int x){
	int bal = 0, jobb = n-1, megtalalt = -1;
	while(bal <= jobb){
		int kozep = (bal + jobb) / 2;
		if(tomb[kozep] <= x){
			megtalalt = kozep;
			bal = kozep + 1;
		}else 
			jobb = kozep - 1;
	}
	return megtalalt + 1;
}

int harmadik(int tomb[], int n, int x){
	int bal = 0, jobb = n-1, megtalalt = -1;
	while(bal <= jobb){
		int kozep = (bal + jobb) / 2;
		if(tomb[kozep] >= x){
			megtalalt = kozep;
			jobb = kozep - 1;
		}else 
			bal = kozep + 1;
	}
	return megtalalt + 1;
}

int main(){
	std::ifstream bem("cautbin.in");
	int n, tomb[1000], k;
	bem >> n;
	for(int i = 0; i < n; i++)
		bem >> tomb[i];
	bem >> k;
	std::ofstream kim("cautbin.out");
	for(int i = 0; i < k; i++){
		int keres, szam;
		bem >> keres >> szam;
		switch(keres){
			case 0:
				kim << elso(tomb, n, szam) << "\n";
				break;
			case 1:
				kim << masodik(tomb, n, szam) << "\n";
				break;
			case 2:
				kim << harmadik(tomb, n, szam) << "\n";
				break;
		}
	}
	kim.close();
}
