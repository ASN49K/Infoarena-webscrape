#include <iostream>
#include <fstream>
using namespace std;
 
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
 
int n , m , v[100005];
 
int main()
{
    fin>>n;
    for(int i=1 ; i<=n ; i++)
        fin>>v[i];
    fin>>m;
    for(int i=1 ; i<=m ; i++){
        int cer , val;
        fin>>cer>>val;
        if(cer == 0){
            int poz=0 , l=1 , r=n;
            int mij;
            while (l<=r) {
                mij=(l+r)/2;
                if (val < v[mij])
                    r = mij - 1;
                else 
                    l = mij + 1;
            }
            if (v[r] == val)
                fout << r;
            else fout << -1;
            
        }
        else if(cer == 1){
            int poz=0 , l=1 , r=n;
            int mij;
            while(l<=r){
                mij=(l + r) / 2;
                if (val >= v[mij])
                    l = mij+1;
                else
                    r = mij-1;
            }
            fout << r;

        }
        else if(cer == 2){
            int poz=0 , l=1 , r=n;
            int mij;
            while (l<=r) {
                mij=(l + r)/2;
                if(val <= v[mij])
                    r = mij - 1;
                else if(val > v[mij])
                    l = mij+1;
            }
            
            fout << l;
        }
        fout << '\n';
    }
    return 0;
}