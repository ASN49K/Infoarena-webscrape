#include <fstream>

using namespace std;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

const int N = 100000;
int vec[N];
int n, m;

void Citire()
{
    in >> n;
    for(int i = 0; i < n; i++)
    {
        in >> vec[i];
    }
}

int Test2(int x)
{
    int rez;
    int st = 0;
    int dr = n;
    while(st <= dr)
    {
        int mid = (st + dr) / 2;
        if(vec[mid] >= x)
        {
            rez = mid + 1;
            dr = mid - 1;
        }
        else
        {
            st = mid + 1;
        }
    }
    return rez;
}

int Test1(int x)
{
    int rez;
    int st = 0;
    int dr = n;
    while(st <= dr)
    {
        int mid = (st + dr) / 2;
        if(vec[mid] <= x)
        {
            rez = mid + 1;
            st = mid + 1;
        }
        else
        {
            dr = mid - 1;
        }
    }
    return rez;
}

int Test0(int x)
{
    int rez = -1;
    int st = 0;
    int dr = n;
    while(st <= dr)
    {
        int mid = (st + dr) / 2;
        if(vec[mid] == x)
        {
            rez = mid + 1;
            st = mid + 1;
        }
        else if(vec[mid] < x)
        {
            st = mid + 1;
        }
        else
        {
            dr = mid - 1;
        }
    }
    return rez;
}

int main()
{
    Citire();
    in >> m;
    for(int i = 0; i < m; i++)
    {
        int tip, nr;
        in >> tip >> nr;
        if(tip == 0)
        {
            out << Test0(nr) << "\n";
        }
        else if(tip == 1)
        {
            out << Test1(nr) << "\n";
        }
        else
        {
            out << Test2(nr) << "\n";
        }
    }

    return 0;
}
