#include <iostream>
#include <fstream>
using namespace std;
ifstream in("cautbin.in");
ofstream out("cautbin.out");
int n, v[100005];
void cautbin(int x, int c)
{
    int mid, st=1, dr=n;
    while (st<dr)
    {
        mid=(st+dr)/2;
        if (v[mid]<x)
            st=mid+1;
        else dr=mid;
    }   
    if (c==0)
    {
        if (v[st]!=x)
            cout<<-1;
        else while (v[st+1]==x)
                st++;
        cout<<st<<"\n";
    }
    if (c==1)
    {
        if (v[st]!=x)
            cout<<st-1<<"\n";
        else while (v[st+1]==x)
                st++;
        cout<<st<<"\n";
    }
    if (c==2)
    {
        if (v[st]!=x)
            cout<<st+1<<"\n";
        else while (v[st-1]==x)
            st--;
        cout<<st<<"\n";
    }
}
int main()
{
    int m, i, x, y, j;
    in>>n;
    for (i=1; i<=n; i++)
        in>>v[i];
    in>>m;
    for (i=0; i<m; i++)
    {
        in>>y>>x;
        cautbin(x, y);
    }
}