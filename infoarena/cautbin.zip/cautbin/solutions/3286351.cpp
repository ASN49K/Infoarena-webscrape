#include<fstream>
#include<algorithm>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
   int v[1000001] ;

int main(){
     
int n , k , x , q  ;
     cin>>n;
       for(int i = 1 ; i <= n ; i ++ )
         cin>>v[i];
 
      cin>>k;
        for(int i = 1 ; i <= k ; i ++ ){
              cin>>q>>x;
                  if(q==0){
                    int ind = upper_bound(v+1,v+n+1,x) - v - 1  ; 
                           if(binary_search(v+1,v+n+1,x))
                                cout<<ind-1<<endl;
                                  else
                                   cout<<-1<<endl;
                  }else if(q==1){
                       int index = lower_bound(v+1,v+n+1,x) - v ;
                         cout<<index-1<<endl;

                  }else if(q==2){
                       int indx = upper_bound(v+1,v+n+1,x) - v ;
                         cout<<indx-1<<endl;
                  }
        }
 
 
 
 
 
 
    return 0 ; 
}