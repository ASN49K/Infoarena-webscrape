#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

long long int n, m, x, v[200005], st, dr, mi, c, r;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++){
        fin >> v[i];
    }
    fin >> m;
    for(int i = 1; i <= m; i++){
        fin >> c >> x;
        st = 1;
        dr = n;
        r = -1;
        if(c == 0){
            while(dr >= st){
                mi = (st + dr) / 2;
                if(v[mi] == x){
                    r = mi;
                    st = mi + 1;
                }else if(x > v[mi]){
                    st = mi + 1;
                }else{
                    dr = mi - 1;
                }
            }
        }else if(c == 1){
            while(dr >= st){
                mi = (st + dr) / 2;
                if(v[mi] <= x){
                    r = mi;
                    st = mi + 1;
                }else{
                    dr = mi - 1;
                }
            }
        }else{
            while(dr >= st){
                mi = (st + dr) / 2;
                if(v[mi] >= x){
                    r = mi;
                    dr = mi - 1;
                }else{
                    st = mi + 1;
                }
            }
        }
        fout << r << '\n';
    }
    return 0;
}
