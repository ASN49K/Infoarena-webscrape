#include <fstream>
#include <iostream>
#include <vector>
#define FIN "cautbin.in"
#define FOUT "cautbin.out"

using namespace std;
ofstream fout(FOUT);
void first_request(vector<int> vec, int n, int N) {
	for(int k=N; k>=1; k--) {
		if(vec[k]==n) { fout<<k<<"\n"; return;}
	}
	fout<<"-1\n";
}
void second_request(vector<int> vec, int n, int N) {
	for(int k=N; k>=1; k--) {
		if(vec[k]<=n) { fout<<k<<"\n"; return; }
	}
}
void third_request(vector<int> vec, int n, int N) {
	for(int k=1; k<=N; k++) {
		if(vec[k]>=n) { fout<<k<<"\n"; return; }
	}
}
int main(int argc, char const *argv[])
{
	ifstream fin(FIN);
	
	int N; fin >> N; 
	vector<int> v(N);

	for(int i=1; i<=N; i++) fin>>v[i];

//	for(int i=1; i<=N; i++) cout<<v[i];
	int M; fin >> M;
	//vector<pair<int, int>> p;
	for(int q=1; q<=M; q++) {
		int i, j; fin>>i>>j;
		// p.push_back({i, j});
		if(i==0) first_request(v, j, N);
		else if(i==1) second_request(v, j, N);
		else if(i==2) third_request(v, j, N);
	}

	return 0;
}
