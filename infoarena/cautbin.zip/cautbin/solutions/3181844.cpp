#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main()
{
    int n, v[100001], intrebari, intrebare, x;
    fin>>n;
    for (int i=1; i<=n; i++){
        fin>>v[i];
    }
    fin>>intrebari;
    for (int k=0; k<intrebari; k++){
        fin>>intrebare>>x;

        int st=1, dr=n, mij, index=-1;
        while (dr >= st && index==-1){
            mij = (dr+st)/2;
            if (v[mij] == x)
                index = mij;
            else if (v[mij] > x)
                dr = mij-1;
            else if (v[mij] < x)
                st = mij+1;
        }
        if (intrebare == 0){
            if (index == -1)
                fout<<index;
            else{
                for (int i=index; i<=n; i++){
                    if (i==n) {
                            fout<<i;
                            break;
                    }
                    if (v[i] != x ){
                        fout<<i-1;
                        break;
                    }
                }
            }
        } else if (intrebare==1){
            if (index==-1)
                index = mij;
            for (int i=index; i<=n; i++){
                if (v[i] > x){
                    fout<<i-1;
                    break;
                }
            }
        } else if (intrebare==2){
            if (index==-1)
                index=mij;
            for (int i=index; i>=1; i--){
                if (v[i] < x){
                    fout<<i+1;
                    break;
                }
            }
        }
        fout<<endl;
    }

    return 0;
}
