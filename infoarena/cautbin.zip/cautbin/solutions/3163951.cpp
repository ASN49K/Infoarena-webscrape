#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream f("cautbin.in");
    ofstream g("cautbin.out");
    int tomb[100000],N,M,c,x,i,bal,jobb;
    f>>N;
    jobb=N-1;
    for (i = 0; i < N; ++i)
        f>>tomb[i];
    f>>M;
    for (i=0; i<M; i++){
        f>>c>>x;
        if(c==0){
            bal = 0, jobb = N-1;
            while (bal < jobb) {
                int kozep = (bal + jobb+1) / 2;

                if (tomb[kozep] >x) {
                jobb= kozep-1;
                }
                else {
                    bal= kozep;
                }
            }
            if(x!=tomb[jobb]) jobb=-1;
        }
        else if(c==1){
            bal = 0, jobb = N-1;
            while (bal < jobb) {
                int kozep = (bal + jobb+1) / 2;

                if (tomb[kozep] >x) {
                 jobb= kozep-1;
                }
                else {
                    bal= kozep;
                }
            }
        }
        else if(c==2){
            bal = 0, jobb = N-1;
            while (bal < jobb) {
                int kozep = (bal + jobb) / 2;

                if (tomb[kozep]<x) {
                bal= kozep+1;
                }
                else {
                    jobb=kozep;
                }
            }
        }
        g<<jobb<<endl;
    }
    f.close();
    g.close();

    return 0;
}
