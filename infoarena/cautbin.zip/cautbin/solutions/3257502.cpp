#include <fstream>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

#define int long long

int n;
int v[100001];

int caut_bin(int a){
    int poz=0,bit;
    for(bit=32;bit>=0;bit--){
        if(poz+(1ll<<bit)<=n && v[poz+(1ll<<bit)]<=a){
            poz+=(1ll<<bit);
        }
    }
    return poz;
}

signed main()
{
    int q,i,cer,a,poz;
    cin>>n;
    for(i=1;i<=n;i++){
        cin>>v[i];
    }
    cin>>q;
    for(i=1;i<=q;i++){
        cin>>cer>>a;
        if(cer==0){
            poz=caut_bin(a);
            if(poz && v[poz]==a) cout<<poz<<"\n";
            else cout<<"-1\n";
        }else if(cer==1){
            cout<<caut_bin(a)<<"\n";
        }else{
            cout<<caut_bin(a-1)+1<<"\n";
        }
    }
    return 0;
}
