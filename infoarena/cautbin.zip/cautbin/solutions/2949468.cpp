
#include <fstream>

using namespace std;

int ras, v[100005];

void bs0(int st, int dr, int x){
    int mij=st+(dr-st)/2;
    
    if(st>dr){ 
        return;
    }
    
    if(x<v[st] || v[dr]<x){
        return;
    }

    if(v[mij]==x){ 
        ras=mij;
        bs0(mij+1, dr, x);
    }
    
    else if(v[mij]<x){
        bs0(mij+1, dr, x);
    }
    
    else{
      bs0(st, mij-1, x);  
    } 
}

void bs1(int st, int dr, int x){
    int mij=st+(dr-st)/2;
    
    if(st>dr){ 
        return;
    }
    
    if(x<v[st]){
        return;
    }

    if(v[mij]<=x){
        ras=mij;
        bs1(mij+1, dr, x);
    }
    
    else{ 
        bs1(st, mij-1, x);
    }
}

void bs2(int st, int dr, int x){
    int mij=st+(dr-st)/2;

    if(st>dr){ 
        return;
    }
    
    if(v[dr]<x){
        return;
    }

    if(v[mij]<x){ 
        bs2(mij+1, dr, x);
    }
    
    else{                      
        ras=mij;
        bs2(st, mij-1, x);
    }
}

int main()
{
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");
    
    int n, x, t, q;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>v[i];
    }
    cin>>t;
    for(int i=0; i<t; i++){
        cin>>q>>x;
        ras=-1;
        if(q==0){ 
            bs0(0, n-1, x);
        }
        if(q==1){ 
            bs1(0, n-1, x);
        }
        if(q==2){
            bs2(0, n-1, x);
        } 
        if(ras!=-1){ 
            ras=ras+1;
        }
        cout<<ras<<endl;
    }


    return 0;
}