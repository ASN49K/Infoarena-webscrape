#include <bits/stdc++.h>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");

int n,m,v[100005];

int main()
{
    f >> n;
    for(int i = 1;i<=n;i++)
    {
        f >> v[i];
    }
    f >> m;
    for(int i = 1;i<=m;i++)
    {
        int q,nr;
        f >> q >> nr;
        if(q == 0)
        {
            int st = 1, dr = n;
            int m = (st+dr)/2;
            while(st<dr)
            {
                if(v[m] > nr)
                {
                    dr = m;
                }else{
                    st=m+1;
                }
                m = (st+dr)/2;
            }
            if(v[st] == nr)
            {
                g << st;
            }else if (v[st-1] == nr)
            {
                g << st-1;
            }else{
                g << -1;
            }
        }
    }
    return 0;
}
