#include <fstream>

using namespace std;

int n, m, v[100001];

int cautBin0(int x)
{
    int stg = 1, dr = n, mj, best_pos = -1;
    while (stg <= dr) {
        mj = (stg + dr) / 2;

        if (v[mj] < x) {
            stg = mj + 1;
        }
        if (v[mj] > x) {
            dr = mj - 1;
        }
        if (v[mj] == x) {
            best_pos = mj;
            stg = mj + 1;
        }
    }
    return best_pos;
}

int cautBin1(int x)
{
    int stg = 1, dr = n, mj, bs = -1;
    while (stg <= dr) {
        mj = (stg + dr) / 2;
        if (x < v[mj]) {
            dr = mj - 1;
        }
        else /// inseamna ca x >= v[mj]
        {
            bs = mj;
            stg = mj + 1;
        }
    }
    return bs;
}

int cautBin2(int x)
{
    int stg = 1, dr = n, mj, bs = -1;
    while (stg <= dr) {
        mj = (stg + dr) / 2;
        if (v[mj] >= x) {
            bs = mj;
            dr = mj - 1;
        }
        else /// v[mj] < x
        {
            stg = mj + 1;
        }
    }
    return bs;
}

int main()
{
    ifstream fin("cautbin.in");
    ofstream fout("cautbin.out");
    fin >> n;
    for (int i = 1; i <= n; i++) {
        fin >> v[i];
    }
    fin >> m;
    int tip, x, rezultat;
    for (int i = 1; i <= m; i++) {
        fin >> tip >> x;
        if (tip == 0) {
            rezultat = cautBin0(x);
        }
        if (tip == 1) {
            rezultat = cautBin1(x);
        }
        if (tip == 2) {
            rezultat = cautBin2(x);
        }
        fout << rezultat << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
