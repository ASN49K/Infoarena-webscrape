#include <iostream>
#include <fstream>
using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");

int bin1 ( long long a[] , long long x , long long n ){
//cea mai mare pozitie pe care se afla un element cu valoarea x sau -1 daca aceasta valoare nu se gaseste in sir
    long long st = 1 , dr = n , mid;
    while ( st <= dr ){
        mid = ( st + dr ) / 2;
        if ( a[mid] <= x )
            st = mid + 1;
        else
            dr = mid - 1;
    }
    if ( a[dr] == x ) return dr;
    else return -1;
}

int bin2 ( long long a[] , long long x , long long n ){
//cea mai mare pozitie pe care se afla un element cu valoarea mai mica sau egala cu x in sir.
    long long st = 1 , dr = n , mid;
    while ( st <= dr ){
        mid = ( st + dr ) / 2;
        if ( a[mid] <= x )
            st = mid + 1;
        else
            dr = mid - 1;
    }
    return dr;
}

int bin3 ( long long a[] , long long x , long long n ){
//cea mai mica pozitie pe care se afla un element cu valoarea mai mare sau egala cu x in sir.
    long long st = 1 , dr = n , mid;
    while ( st <= dr ){
        mid = ( st + dr ) / 2;
        if ( a[mid] < x )
            st = mid + 1;
        else
            dr = mid - 1;
    }
    return st;
}

int main()
{   long long n; f >> n;
    long long a[n+1] , i , M , x , y , s;
    for ( i = 1; i <= n; i++ )
        f >> a[i];
    f >> M;
    for ( i = 1; i <= M; i++ ){
        f >> x >> y;
        if ( x == 0 ) s = bin1( a , y , n );
        if ( x == 1 ) s = bin2( a , y , n );
        if ( x == 2 ) s = bin3( a , y , n );
        cout << s << endl;
    }
    return 0;
}
