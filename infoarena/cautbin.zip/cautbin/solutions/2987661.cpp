#include <iostream>
using namespace std;

int v[100000];
int cautbin1(int x, int n){
    int st=1;
    int dr=n;
    int ans=-1;
    while(st<=dr){
        int med=(st+dr)/2;
        if(v[med]<=x){
            st=med+1;
            ans=med;
        }
        else{
            dr=med-1;
        }
    }
    return ans;
}
int cautbin2(int x, int n){
    int st=1;
    int dr=n;
    int ans=-1;
    while(st<=dr){
        int med=(st+dr)/2;
        if(v[med]>=x){
            dr=med-1;
            ans=med;
        }
        else{
            st=med+1;
        }
    }
    return ans;
}
int main()
{
    int n,m,dr,st,med,ans,x,op;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
    }
    cin>>m;
    for(int i=1;i<=m;i++){
        cin>>op>>x;
        if (op == 1 || op==0) {
            cout<<cautbin1(x,n);
        }
        else if (op==2){
            cout<<cautbin2(x,n);
        }
    }
    return 0;
}
