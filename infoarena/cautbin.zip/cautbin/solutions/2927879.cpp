#include <bits/stdc++.h>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX = 1e5+5;
int arr[NMAX], n, m;

inline int b_search0(int x)
{
    int st = 1, dr = n, sol = 0;
    while(st <= dr)
    {
        int mid = (st+dr)/2;
        if(arr[mid] == x)
            sol = mid;
        if(arr[mid] <= x)
            st = mid+1;
        if(arr[mid] > x)
            dr = mid-1;
    }
    return sol;
}

inline int b_search1(int x)
{
    int st = 1, dr = n, sol = 0;
    while(st <= dr)
    {
        int mid = (st+dr)/2;
        if(arr[mid] == x)
            sol = mid;
        if(arr[mid] < x)
            st = mid + 1;
        if(arr[mid] >= x)
            dr = mid-1;
    }
    return sol;
}

inline void solve()
{
    fin >> m;
    while(m--)
    {
        int a, b;
        fin >> a >> b;
        if(a == 0)
        {
            int ans = b_search0(b);
            if(ans == 0)
                fout << -1 << '\n';
            else
                fout << ans << '\n';
        }
        if(a == 1)
        {
            int ans = b_search0(b);
            fout << ans << '\n';
        }
        if(a == 2)
        {
            int ans = b_search1(b);
            fout << ans << '\n';
        }
    }
}

int main()
{
    fin >> n;
    for(int i=1;i<=n;++i)
        fin >> arr[i];
    solve();
}
