#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100005];
int main()
{
    long long n, m, x, nr;
    fin >> n;
    for(int i=1; i<=n; i++)
    {
        fin >> v[i];
    }
    fin >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> x >> nr;
        long long st=1, dr=v[n], mid;
        while(st<dr-1)
        {
            mid=(st+dr)/2;
            if(x<2)
            {
                if(v[mid]<=nr)
                    st=mid;
                else
                    dr=mid;
            }
            else
            {
                if(v[mid]>=nr)
                    dr=mid;
                else
                    st=mid;
            }
        }
        if(x==0)
        {
            if(v[st]==nr)
                fout << st << "\n";
            else
                fout << -1 << "\n";
        }
        else if(x==1)
            fout << st << "\n";
        else
            fout << dr << "\n";
    }
    return 0;
}
