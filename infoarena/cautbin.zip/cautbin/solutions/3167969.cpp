#include <bits/stdc++.h>
using namespace std;

const int nmax = 100007;

int n, m;
int a[nmax];


void solve() {
  
  cin >> n;
  for (int i = 1; i <= n; i++) cin >> a[i];

  int m;
  cin >> m;

  for (int _ = 0; _ < m; _++) {
    
    int tip_intrebare, x;
    cin >> tip_intrebare >> x;

    if (tip_intrebare == 0) {
      for (int i = n; i >= 1; i--) {
        if (a[i] == x) {
          cout << i << '\n';
          break;
        }
        if (a[i] < x) {
          cout << -1 << '\n';
          break;
        }
      }
    }

    else if (tip_intrebare == 1) {
      for (int i = n; i >= 1; i--) {
        if (a[i] <= x) {
          cout << i << '\n';
          break;
        }
      }
    }

    else {
      for (int i = 1; i <= n; i++) {
        if (a[i] >= x) {
          cout << i << '\n';
          break;
        }
      }
    }




  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cautbin.in", "r", stdin);
  freopen("cautbin.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
 