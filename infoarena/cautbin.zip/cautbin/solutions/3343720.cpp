/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[1000001];
int main()
{
	int n,m,a,x,i;
	fin>>n;
	for(i=1; i<=n; i++)
		fin>>v[i];

	fin>>m;
	for(i=1; i<=m; i++) {
		fin>>a>>x;
		if(a==0) {
			auto *val=upper_bound(v,v+n+1,x);
			auto val4=*upper_bound(v,v+n+1,x);
			if(val4==x)
			fout<<val-v-1<<endl;
			else
			fout<<-1<<endl;
		}
		else if(a==1) {
			auto val1=*lower_bound(v,v+n+1,x);
            auto *val2=upper_bound(v,v+n+1,val1);
			fout<<val2-v-1<<endl;
		}
		else{
		   auto val1=*lower_bound(v,v+n+1,x);
            auto *val2=lower_bound(v,v+n+1,val1);
			fout<<val2-v<<endl;

		}
	}
	return 0;
}