#include<bits/stdc++.h>
using namespace std;
ifstream F("cautbin.in");
ofstream G("cautbin.out");
int n,i,a[100000],j,k;
int main()
{
    for(F>>n;i<n;F>>a[i++]);
    for(F>>i;F>>i>>j;i<2?k=upper_bound(a,a+n,j)-a,G<<(!i&&a[k-1]!=j?-1:k)<<'\n':G<<lower_bound(a,a+n,j)-a+1<<'\n');
    return 0;
}
