#include <bits/stdc++.h>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n, m;
int a[100005];

int CB0(int x)
{
    int st, dr, p, mij;
    st = 1; dr = n; p = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (a[mij] == x)
            p = max(p, mij);
        if (a[mij] <= x)
            st = mij + 1;
        else dr = mij - 1;
    }
    return p;
}

int CB1(int x)
{
    int st, dr, p, mij;
    st = 1; dr = n; p = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (a[mij] <= x)
        {
            p = mij;
            st = mij + 1;
        }
        else dr = mij - 1;
    }
    return p;
}

int CB2(int x)
{
    int st, dr, p, mij;
    st = 1; dr = n; p = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (a[mij] >= x)
        {
            p = mij;
            dr = mij - 1;
        }
        else st = mij + 1;
    }
    return p;
}

int main()
{
    int op, x;
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i];
    cout << "ok\n";
    fin >> m;
    while (m--)
    {
        fin >> op >> x;
        cout << op << " ";
        if (op == 0) fout << CB0(x) << "\n";
        else if (op == 1) fout << CB1(x) << "\n";
        else fout << CB2(x) << "\n";
        cout << "ok\n";
    }
    fin.close();
    fout.close();
    return 0;
}
