#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n, m, v[100001], x, y;

int binary0(int v[], int x){
    int st = 1, dr = n, sol = -1;
    while(st <= dr){
        int mij = (st + dr) / 2;
        if(v[mij] > x)
            dr = mij - 1;
        else if(v[mij] < x)
            st = mij + 1;
        else{
            sol = mij;
            st = mij + 1;
        }
    }
    return sol;
}

int binary1(int v[], int x){
    int st = 1, dr = n, sol = -1, rez;
    while(st <= dr){
        int mij = (st + dr) / 2;
        if(v[mij] > x)
            dr = mij - 1;
        else if(v[mij] < x)
            st = mij + 1, rez = mij;
        else{
            sol = mij;
            st = mij + 1;
        }
    }
    if(sol == - 1)
        return rez;
    return sol;
}

int binary2(int v[], int x){
    int st = 1, dr = n, sol = -1, rez = 0;
    while(st <= dr){
        int mij = (st + dr) / 2;
        if(v[mij] > x)
            dr = mij - 1, rez = mij;
        else if(v[mij] < x)
            st = mij + 1;
        else{
            sol = mij;
            dr = mij - 1;
        }
    }
    if(sol == -1)
        return rez;
    return sol;
}


int main(){
    
    
    fin >> n;
    for(int i = 1; i <= n; ++i)
        fin >> v[i];
    fin >> m;
    for(int i = 1; i <= m; ++i){
        fin >> x >> y;
        if(x == 0)
            fout << binary0(v, y) << '\n';
        else if(x == 1)
            fout << binary1(v, y) << '\n';
        else if(x == 2)
            fout << binary2(v, y) << '\n';
    }
    fin.close();
    fout.close();
    return 0;
}