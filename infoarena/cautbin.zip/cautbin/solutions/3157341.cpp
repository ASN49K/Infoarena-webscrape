#include <iostream>
#include <fstream>
using namespace std;

bool binker(int n, int ker, int t[1000])
{
    if (n == 0) {
        return false;
    }
     else if (t[n / 2] == ker) {
        return true;
    }
    else if (t[n / 2] < ker) {
        binker(n - n / 2, ker, t);
    }
    else {
        binker(n / 2, ker, t);
    }
}

int main()
{
    int n, ker, t[1000];
    cin >> n;
    cin >> ker;
    for (int i = 0; i < n; i++) {
        cin >> t[i];
    }
     cout << binker(n, ker, t);
     return 0;
}
