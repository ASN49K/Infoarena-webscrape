#include <fstream>
#include <iostream>
using namespace std;
ifstream in("cautbin.in");
ofstream out("cautbin.out");
int main()
{
    int n,m,M,v[1001],i;
    in>>M;
    for(i=1; i<=M; i++)
    {
        in>>v[i];
    }
    int st=1;
    int dr=M;
    in>>n;
    int intrebare[1001], val[10001];
    for(i=1; i<=n; i++)
    {
        in>>intrebare[i];
        in>>val[i];
    }
    for(i=1; i<=n; i++)
    {
        if(intrebare[i]==0)
        {
            st=1;
            dr=M;
            int pmax=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]<val[i])
                {
                    st=m+1;
                }
                else if(v[m]>val[i])
                {
                    dr=m-1;
                }
                else if(v[m]==val[i])
                {
                    while(v[m]==val[i])
                    {
                        m=m+1;
                    }
                    pmax=m-1;
                    break;
                }
                if(pmax>=0)
                    break;
            }
            out<<pmax<<endl;
        }
        else if(intrebare[i]==1)
        {
            st=1;
            dr=M;
            int pm=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]>val[i])
                {
                    dr=m-1;
                }
                else if(v[m]<=val[i])
                {
                    while(v[m]<=val[i])
                    {
                        m++;
                    }
                    pm=m-1;
                    break;
                }
                if(pm>=0)
                    break;
            }
            out<<pm<<endl;
        }
        else if(intrebare[i]==2)
        {
            st=1;
            dr=M;
            int pma=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]<val[i])
                {
                    st=m+1;
                }
                else if(v[m]>=val[i])
                {
                    while(v[m]>=val[i])
                    {
                        m--;
                    }
                    pma=m+1;
                    break;
                }
                if(pma>=0)
                break;
            }
            out<<pma<<endl;
        }
    }
    return 0;
}
