#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX = 100005;
int ans, v[NMAX];
void bs0(int st, int dr, int x){
    int mid = st + (dr-st)/2;
    if(st > dr) return;

    if(x < v[st] || v[dr] < x )return;


    if(v[mid] == x){
        ans = mid;
        bs0(mid + 1, dr, x);
    }
    else if(v[mid] < x)
        bs0(mid + 1, dr, x);
    else bs0(st, mid - 1, x);
}

void bs1(int st, int dr, int x){
    int mid = st + (dr-st)/2;

    if(st > dr) return;
    if(x < v[st] || v[dr] < x )return;


    if(v[mid] <= x ){
        ans = mid;
        bs1(mid + 1, dr, x);
    }
    else bs1(st, mid - 1, x);
}

void bs2(int st, int dr, int x){
    int mid = st + (dr-st)/2;

    if(st > dr) return;
    if(x < v[st] || v[dr] < x )return;

    if(v[mid] < x ) bs2(mid + 1, dr, x);
    else{
        ans = mid;
        bs2(st, mid - 1, x);
    }
}

int n, x, tests, q;
int main()
{

    fin >> n;
    for(int i = 0; i < n; i++)
        fin >> v[i];
    fin >> tests;
    for(int t = 0; t < tests; t++){
        fin >> q >> x;

        ans = -1;
        if(q == 0) bs0(0, n - 1, x);
        if(q == 1) bs1(0, n - 1, x);
        if(q == 2) bs2(0, n - 1, x);
        if(ans != -1) ans = ans + 1;
        fout << ans <<"\n";


    }


    return 0;
}
