#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main() {
    const int MAX_LENGTH = 100000;
    int n, a[MAX_LENGTH + 1];
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> a[i];
    }
    int m;
    fin >> m;
    while (m > 0) {
        int nr, x;
        fin >> nr >> x;
        if (nr == 0 || nr == 1) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                //cout << mid << " ";
                if (a[mid] <= x && a[mid + 1] <= x && mid + 1 <= n) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
            if (nr == 0) {
                if (a[mid] == x) {
                    fout << mid << "\n";
                } else {
                    fout << -1 << "\n";
                }
            } else {
                if (a[mid] <= x) {
                    fout << mid << "\n";
                }
            }
        } else if (nr == 2) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = (left + right) / 2;
                //cout << mid << " ";
                if (a[mid] >= x && a[mid - 1] >= x && mid - 1 >= 1) {
                    right = mid;
                } else {
                    left = mid + 1;
                }
            }
            if (a[left] >= x) {
                fout << left << "\n";
            }
        }
        --m;
    }
    return 0;
}
