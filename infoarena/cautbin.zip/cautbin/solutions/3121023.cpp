#include <fstream>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
int v[100005];
int n, m;

void cb0(int x)
{
    int st = 1;
    int dr = n;
    int m;
    int poz;
    while(st <= dr)
    {
        m = (st + dr) / 2;
        if(x >= v[m])
        {
            st = m + 1;
            poz = m;
        }
        else
        {
            dr = m - 1;
        }
    }

    if(v[poz] == x)
    {
        g<<poz<<'\n';
    }
    else
    {
        g<<-1<<'\n';
    }
}

void cb2(int x)
{
    int st = 1;
    int dr = n;
    int m;
    int poz;
    while(st <= dr)
    {
        m = (st + dr) / 2;
        if(x <= v[m])
        {
            dr = m - 1;
            poz = m;
        }
        else
        {
            st = m + 1;
        }
    }
    g<<poz<<'\n';
}

void cb1(int x)
{
    int st = 1;
    int dr = n;
    int m;
    int poz;
    while(st <= dr)
    {
        m = (st + dr) / 2;
        if(x >= v[m])
        {
            st = m + 1;
            poz = m;
        }
        else
        {
            dr = m - 1;
        }
    }
    g<<poz<<'\n';
}

int main()
{
    f>>n;
    for(int i = 1; i<=n; i++)
    {
        f>>v[i];
    }
    f>>m;
    int c, x;
    while(m--)
    {
        f>>c>>x;
        if(c == 0)
        {
            cb0(x);
        }
        else if(c == 1)
        {
            cb1(x);
        }
        else if(c == 2)
        {
            cb2(x);
        }
    }
    return 0;
}
