#include <fstream>

using namespace std;

int main() {
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");
    int n;
    cin >> n;
    int power = 1;
    while (power <= n) power *= 2;
    power /= 2;
    unsigned int v[n];
    for (int i = 0; i < n; ++i) cin >> v[i];
    int m;
    cin >> m;
    for (int i = 0; i < m; ++i) {
        int q, ans = -2, pos = 0;
        int x;
        cin >> q >> x;
        switch (q) {
            case 0: {
                /*
                for (int p = power; p; p /= 2)
                    if (pos + p < n && v[pos + p] <= x)
                        pos += p;
                */
                int ls = n, li = 0, mid = li + (ls - li) / 2;
                while (ls - li > 1) {
                    mid = (ls + li) / 2;
                    if (v[mid] > x) ls = mid;
                    else li = mid;

                }
                if (v[li] == x) ans = li;
                else ans = -2;
                break;
            }
            case 1: {
                /*
                for (int p = power; p; p /= 2)
                    if (pos + p < n && v[pos + p] <= x)
                        pos += p;
                */
                int ls = n, li = 0, mid = li + (ls - li) / 2;
                while (ls - li > 1) {
                    mid = (ls + li) / 2;
                    if (v[mid] > x) ls = mid;
                    else li = mid;

                }
                ans = li;
                break;
            }
            case 2: {
                /*
                for (int p = power; p; p /= 2)
                    if (pos + p < n && v[pos + p] < x)
                        pos += p;
                ++pos;
                 */
                int ls = n, li = 0, mid = li + (ls - li) / 2;
                while (ls - li > 1) {
                    mid = (ls + li) / 2;
                    if (v[mid] < x) li = mid;
                    else ls = mid;
                }
                ans = ls;
                break;
            }
            default:;

        }
        cout << ans + 1 << '\n';
    }
    return 0;
}