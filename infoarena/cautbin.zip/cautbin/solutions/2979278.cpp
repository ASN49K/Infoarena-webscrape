#include <bits/stdc++.h>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100001];

int main()
{
    unsigned n, m, operatie, numar, st, dr, mijloc = 0 ;
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> v[i];
    fin >> m;
    for(int k = 1; k <= m; k++)
    {
        fin >> operatie >> numar;
        if(operatie == 0)
        {
          st = 1;
          dr = n;
          while(st < dr)
          {
             mijloc = st + (dr - st + 1) / 2;
             if(numar >= v[mijloc])
             {
                 st = mijloc;
             }
             else
             {
                 dr = mijloc - 1;
             }

          }
          if(numar == v[st])
            fout << st <<'\n';
          else
            fout << -1 <<'\n';
        }
        if(operatie == 1)
        {
          st = 1;
          dr = n;
          while(st < dr)
          {
             mijloc = st + (dr - st + 1) / 2;
             if(numar >= v[mijloc])
             {
                 st = mijloc;
             }
             else
             {
                 dr = mijloc - 1;
             }

          }
          fout << st <<'\n';
        }
        if(operatie == 2)
        {
          st = 1;
          dr = n;
          while(st < dr)
          {
             mijloc = st + (dr - st) / 2;
             if(numar > v[mijloc])
             {
                 st = mijloc + 1;
             }
             else
             {
                 dr = mijloc;
             }

          }
          fout << st <<'\n';
        }
    }

}
