#include<fstream>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int v[100000];

int main(){
	int n,m,st,dr,mij,pozfin,x,c;
	cin>>n;
	for(int i=0;i<n;i++)
	    cin>>v[i];
	cin>>m;
	for(int i=0;i<m;i++){
	    cin>>c>>x;
        st=0;
        dr=n-1;
        if(c==0){
            while(st<=dr){
                mij=(st+dr)/2;
                if(v[mij]==x){
                    pozfin=mij;
                    st=mij+1;
                }
                else if(v[mij]<x)
                    st=mij+1;
                else
                    dr=mij-1;
            }
            cout<<pozfin+1;
        }
        if(c==1){
            while(st<=dr){
                mij=(st+dr)/2;
                if(v[mij]<=x){
                    st=mij+1;
                    pozfin=mij;
                }
                else
                    dr=mij-1;
            }
            cout<<pozfin+1;
        }
        if(c==2){
            while(st<=dr){
                int mij=(st+dr)/2;
                if(v[mij]>=x){
                    dr=mij-1;
                    pozfin=mij;
                }
                else
                    st=mij+1;
            }
            cout<<pozfin+1;
        }
        cout<<'\n';
	}
}