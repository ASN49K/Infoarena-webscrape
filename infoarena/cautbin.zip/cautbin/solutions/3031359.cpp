#include <fstream>
#include <vector>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

vector <int> v;
vector <int> rezultate;

int binSrch01(int st, int dr, int val)
{
    int rez = -1;
    while(st <= dr)
    {
        int m = (st + dr) / 2;
        if(v[m] <= val)
        {
            st = m + 1;
            rez = m;
        }
        else
        {
            dr = m - 1;
        }
    }
    return rez;
}

int binSrch2(int st, int dr, int val)
{
    int rez = -1;
    while(st <= dr)
    {
        int m = (st + dr) / 2;
        if(v[m] >= val)
        {
            dr = m - 1;
            rez = m;
        }
        else
        {
            st = m + 1;
        }
    }
    return rez;
}

struct tests{
    int type;
    int val;
};

vector <tests> teste;

int main()
{
    int n;
    cin >> n;
    v.resize(100001);
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i];
    }
    int nr_teste;
    cin >> nr_teste;
    teste.resize(100001);
    for(int i = 1; i <= nr_teste; i++)
    {
        cin >> teste[i].type >> teste[i].val;
    }
    int fin;
    for(int i = 1; i <= nr_teste; i++)
    {
        if(teste[i].type == 0 || teste[i].type == 1)
        {
            cout << binSrch01(1, n, teste[i].val) << "\n";
        }
        else
        {
            cout << binSrch2(1, n, teste[i].val) << "\n";
        }
    }
    /*for(int i = 0; i < rezultate.size(); i++)
    {
        cout << rezultate[i] << "\n";
    }*/
    return 0;
}