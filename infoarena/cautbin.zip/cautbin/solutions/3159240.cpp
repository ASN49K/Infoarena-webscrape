#include <iostream>
#include <fstream>
#define MAXN 100000

using namespace std;

int v[MAXN], n;

// if getFirst is set to true, cautbin will return the first apparition of the number in the vector
int cautbin(int e, bool getFirst){
  int mij, st = 0, dr = n;

  while(st < dr - 1){
    mij = (st + dr) / 2;
    if(v[mij] > e || (v[mij] == e && getFirst))
      dr = mij;
    else
      st = mij;
  }

  if(getFirst && v[dr] == e)
    return dr;
  return st;
}

int main(){
  int q, t, x;

  ifstream fin ("cautbin.in");
  fin >> n;
  for(int i = 0; i < n; i ++)
    fin >> v[i];

  ofstream fout ("cautbin.out");
  fin >> q;
  for(int i = 0; i < q; i ++){
    fin >> t >> x;
    bool getFirst = false;
    if(t == 2)
      getFirst = true;

    int pos;
    if(x < v[0])
      pos = -1;
    else
      pos = cautbin(x, getFirst);
    
    if(t == 0 && v[pos] != x)
      fout << "-1\n";
    else if(t == 2 && v[pos] != x)
      fout << pos + 2 << "\n";
    else
      fout << pos + 1 << "\n";
  }
  fout.close();
  fin.close();

  return 0;
}
