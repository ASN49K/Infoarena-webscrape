#include <fstream>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
int v[100005];

int binSearchL(int st , int dr , int val)
{
    int ans=-1;
    while(st<=dr)
    {
        int med=(st+dr)/2;
        if(v[med]<=val)
        {
            st=med+1;
            ans=med;
        }
        else
        {
            dr=med-1;
        }
    }
    return ans;
}

int binSearchU(int st , int dr , int val)
{
    int ans=-1;
    while(st<=dr)
    {
        int med=(st+dr)/2;
        if(v[med]>=val)
        {
            dr=med-1;
            ans=med;
        }
        else
        {
            st=med+1;
        }
    }
    return ans;
}
int main()
{
    int n,st=1,dr,m;
    f>>n;
    dr=n;
    for(int i=1;i<=n;i++)
    {
        f>>v[i];
    }
    f>>m;
    for(int i=0;i<m;i++)
    {
        int intr,x;
        f>>intr>>x;
        if(intr==0)
        {
            int j;
            j=binSearchL(st,dr,x);
            if(v[j]!=x)
            {
                g<<"-1"<<'\n';
            }
            else
                g<<j<<'\n';
        }
        else if(intr==1)
        {
            g<<binSearchL(st,dr,x)<<'\n';
        }
        else
            g<<binSearchU(st,dr,x)<<'\n';
    }
    
    
    return 0;
}