#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100000];

bool verif(int acc,int currentpower,int k,int n)
{

    return (acc + currentpower < n) && (v[acc+currentpower]<=k);
}

int cautbin(int problem,int currentpower, int searchedelem,int n)
{
    int acc=0;
    while(currentpower>0)
    {

        if(verif(acc,currentpower,searchedelem,n))
            acc+=currentpower;
        currentpower>>=1;
    }

    if(problem==0){
    if (acc < n && v[acc] == searchedelem) {
        while (acc + 1 < n && v[acc + 1] == searchedelem) {
            acc++;
        }
        return 1+acc;
    }

    return -1;
    }

    if (problem == 1) {
        if (acc < n) {
            while (acc + 1 < n && v[acc + 1] <= searchedelem) {
                acc++;
            }
            return acc + 1;  // Convert to 1-based index
        }
        return -1;
    }

    if (problem == 2) {
        if (acc < n) {
            while (acc > 0 && v[acc - 1] >= searchedelem) {
                acc--;
            }
            return acc + 2;  // Convert to 1-based index
        }
        return -1;
    }
    return -1;
}

int main()
{
    int n,m;
    int problem,val;
    fin>>n;
    int currentpower=0X1;

    while(currentpower<=n)
    {
        currentpower<<=1;
    }
    currentpower>>=1;

    for(int i=0;i<n;i++)
        fin>>v[i];

    fin>>m;

    for(int i=0;i<m;i++)
        {
            fin>>problem>>val;
            fout<<cautbin(problem,currentpower,val,n)<<'\n';
        }
    return 0;
}
