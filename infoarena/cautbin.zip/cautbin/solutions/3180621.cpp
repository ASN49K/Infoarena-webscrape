    #include <iostream>
    #include <fstream>
    using namespace std;
    ifstream fin ("cautbin.in");
    ofstream fout ("cautbin.out");
    int t[100005],q1[100005],q2[100005];
    int main()
    {
        int i, j, nrt, nrq, l, r, m, poz1=0, poz2=0, poz3=0;
        fin >> nrt;

        for (i=1;i<=nrt;i++)
        {
            fin >> t[i];
        }

        fin >> nrq;

        for (j=1;j<=nrq;j++)
        {
            fin >> q1[j] >> q2[j] ;

        }

        for (j=1;j<=nrq;j++)
        {
            r=nrt;
            l=1;
            poz1=-1;
            poz2=0;
            poz3=0;
            while (l<=r)
            {
                m=(l+r)/2;

                if (t[m]==q2[j])
                {
                    poz1=m;
                    l=m+1;
                }
                else if (t[m]>q2[j])
                {
                    r=m-1;

                }
                else
                {
                    l=m+1;
                }
            }

            r=nrt;
            l=1;
            while (l<=r)
            {
                m=(l+r)/2;
                if (t[m]<=q2[j])
                {
                    poz2=m;
                    l=m+1;
                }
                else
                {
                    r=m-1;
                }
            }
            r=nrt;
            l=1;
            while (l<=r)
            {
                m=(l+r)/2;
                if (t[m]>=q2[j])
                {
                    poz3=m;
                    r=m-1;
                }
                else
                {
                    l=m+1;

                }
            }

        }

        fout << poz1 << endl;
        fout << poz2 << endl;
        fout << poz3 << endl;
        return 0;
    }
