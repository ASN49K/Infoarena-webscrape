#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int main() {
    std::ios_base::sync_with_stdio(false); // optimizeaza citirea/afisarea datelor

    int n, m;
cin >> n;
vector<int> a(n);
    for (int i = 0; i < n; ++i) {
    cin >> a[i];
    }

    sort(a.begin(), a.end()); // sortam vectorul

cin >> m;

    for (int i = 0; i < m; ++i) {
        int type, x;
        cin >> type >> x;

        if (type == 0) { // cautam cea mai mare pozitie a lui x
            auto it = upper_bound(a.begin(), a.end(), x);
            if (it == a.begin()) {
                cout << -1 << '\n'; // x nu se gaseste in sir
            } else {
                cout << distance(a.begin(), --it)+1 << '\n';
            }
        } else if (type == 1) { // cautam cea mai mare pozitie a unui element mai mic sau egal cu x
            auto it = upper_bound(a.begin(), a.end(), x);
            if (it == a.begin()) {
                cout << -1 << '\n'; // niciun element nu este mai mic sau egal cu x
            } else {
                cout << distance(a.begin(), --it)+1 << '\n';
            }
        } else if (type == 2) { // cautam cea mai mica pozitie a unui element mai mare sau egal cu x
            auto it = lower_bound(a.begin(), a.end(), x);
            if (it == a.end()) {
                cout << -1 << '\n'; // niciun element nu este mai mare sau egal cu x
            } else {
                cout << std::distance(a.begin(), it)+1 << '\n';
            }
        }
    }

    return 0;
}
