#include <bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[200001];
int m,n,x,y;
void zero(int x){
    auto *val=upper_bound(v+1,v+n+1,x);
    if(x==*lower_bound(v+1,v+n+1,x)){
    fout<<val-v-1<<endl;
    }
    else{
        fout<<-1;
    }
}
void unu(int x){
    auto* val=upper_bound(v+1,v+n+1,x);
    fout<<(int)(val-v)-1<<endl;
}
void doi(int x){
    auto *val=lower_bound(v+1,v+n+1,x);
    fout<<(int)(val-v)<<endl;
}
int main()
{
    int i,nr,cnt,j;
    fin>>n;
    for(i=1; i<=n; i++){
        fin>>v[i];
    }
    sort(v+1,v+n+1);
    fin>>m;
    for(i=1; i<=m; i++){
        fin>>x>>y;
        if(x==0){
            zero(y);
        }
        if(x==1){
            unu(y);
        }
        if(x==2){
            doi(y);
        }
        
    }

    return 0;
}