#include <fstream>
#include <algorithm>
#include <string>
#include <cmath>
#include <queue>
#include <deque>
#include <map>
#include <stack>
#include <vector>
#define int long long
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int n, m, v[100005], a, x;

signed main(){
    cin>>n;
    for (int i = 1; i <= n; i++){
        cin>>v[i];
    }
    cin>>m;
    for (int i = 1; i <= m; i++){
        cin>>a>>x;
        if (a == 0){
            int c = upper_bound(v + 1, v + n + 1, x) - v - 1;
            if (v[c] == x){
                cout<<c;
            }
            else{
                cout<<-1;
            }
        }
        if (a == 1){
            int c = lower_bound(v + 1, v + n + 1, x) - v;
            if (v[c] == x){
                int j = c;
                while (v[j] == x){
                    j++;
                }
                cout<<j - 1;
            }
            else{
                cout<<c - 1;
            }
        }
        if (a == 2){
            cout<<lower_bound(v + 1, v + n + 1, x) - v;
        }
        cout<<"\n";
    }
}
