#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100002],N;
int CB(int a)
{
    int L=1,R=N,mij;
    while(L<R)
    {
    mij=(L+R)/2;
    if(v[mij]>a)
    R=mij-1;
    else
    if(v[mij]<a)
    L=mij+1;
    else
    return mij;
    
    if(v[L]==a)
    return L;
    else
    if(v[R]==a)
    return R;
    }
    return mij;
}
int main()
{
    int M,c,pz,x;
    fin>>N;
    for(int i=1;i<=N;i++)
    {
    fin>>v[i];
    }
    fin>>M;
    while(M)
    {
        fin>>c>>x;
        pz=CB(x);
        
        if(c==0)
        
        {
        if(v[pz]==x)
        {
        while(v[pz+1]==x && pz<=N)
        pz++;
        fout<<pz;
        }
        else
        fout<<-1;
        }
        
        else
        if(c==1)
        {
        while(v[pz+1]<=x && pz+1<=N)
        pz++;
        while(v[pz]>x && pz>=1)
        pz--;
        fout<<pz;
        }
        else
        if(c==2)
        {
        while(v[pz-1]>=x && pz-1>=1)
        pz--;
        while(v[pz]<x && pz<=N)
        pz++;
        fout<<pz;
        }
        M--;
        if(M!=0)
        fout<<'\n';
    }
    return 0;
}