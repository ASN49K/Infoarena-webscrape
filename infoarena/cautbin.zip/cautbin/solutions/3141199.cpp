#include <fstream>

using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int n;
int a[100003];
int zero(int val)
{
    int index=0;
    int st=1, dr=n;
    for(int bit=4; bit>=0; bit--)
    {
        index+=(1<<bit);
        if(index>n || a[index]>val) index-=(1<<bit);
    }
    return index;
}

int unu(int val)
{
    int st=1, dr=n;
    while(st<dr)
    {
        int mij=(st+dr+1)/2;
        if(a[mij]<=val)
            st=mij;
        else dr=mij-1;
    }
}

int doi(int val)
{
    int st=1, dr=n;
    while(st<dr)
    {
        int mij=(st+dr)/2;
        if(a[mij]<val)
            st=mij+1;
        else dr=mij;
    }
}

int main()
{
    int m,i, cer, x;
    cin >>n;
    for(i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    cin >>m;
    while(m)
    {
        cin >> cer>>x;
        if(cer==0)
            cout<<zero(x)<<'\n';
        else if(cer==1)
            cout<<unu(x)<<'\n';
        else cout<<doi(x)<<'\n';
        m--;
    }
}
