#include <bits/stdc++.h>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
int n,m;
const int NMAX=100005;
int v[NMAX];

int cb0(int x)
{
    int s=1,d=n,ans;
    int mij=(s+d)/2;
    bool ok=0;
    while(s<=d)
    {
        if(v[mij]<=x)
            s=mij+1;
        else
            d=mij-1;
        if(v[mij]==x)
        {
            ans=mij;
            ok=1;
        }
        mij=(s+d)/2;
    }
    if(ok==1)
        return ans;
    return -1;
}

int cb1(int x)
{
    int s=1,d=n,ans;
    int mij=(s+d)/2;
    while(s<=d)
    {
        if(v[mij]<=x)
        {
            s=mij+1;
            ans=mij;
        }
        else
            d=mij-1;
        mij=(s+d)/2;
    }
    return ans;
}

int cb2(int x)
{
    int s=1,d=n,ans;
    int mij=(s+d)/2;
    while(s<=d)
    {
        if(v[mij]>=x)
        {
            d=mij-1;
            ans=mij;
        }
        else
            s=mij+1;
        mij=(s+d)/2;
    }
    return ans;
}

int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
        f>>v[i];
    f>>m;
    while(m--)
    {
        int nr,x;
        f>>nr>>x;
        if(nr==0)
            g<<cb0(x)<<'\n';
        if(nr==1)
            g<<cb1(x)<<'\n';
        if(nr==2)
            g<<cb2(x)<<'\n';
    }
    return 0;
}
