#include <iostream>
#include <fstream>

using namespace std;
int v[100005];
int main()
{
    ifstream cin("cautbin.in");
    ifstream cin("cautbin.out");
    int n,q,cer,x,sol=-1;
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>v[i];

    cin>>q;
    for(int i=0; i<q; i++)
    {
        cin>>cer>>x;
        int st=0,dr=n;
        if(cer==0)
        {
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>x)
                    dr=mij-1;
                else if(v[mij]<x)
                    st=mij+1;
                else if(v[mij]==x)
                {
                    sol=mij;
                    st=mij+1;
                }
            }
            cout<<sol+1<<'\n';
        }
        else if(cer==1)
        {
            st=0;
            dr=n;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>x)
                    dr=mij-1;
                else if(v[mij]<x)
                    st=mij+1;
                else if(v[mij]==x)
                {
                    sol=mij;
                    st=mij+1;
                }
            }
            cout<<sol+1<<'\n';
        }
        else if(cer==2)
        {
            st=0;
            dr=n;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>x)
                    dr=mij-1;
                else if(v[mij]<x)
                    st=mij+1;
                else if(v[mij]==x)
                {
                    sol=mij;
                    dr=mij-1;
                }
            }
            cout<<sol+1<<'\n';
        }
    }


    return 0;
}
