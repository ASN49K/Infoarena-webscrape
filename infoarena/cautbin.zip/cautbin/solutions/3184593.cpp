/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100005];
int cb0(int st, int dr, int x)
{
    int m,poz;
    poz=-1;
    while(st<=dr && poz==-1)
    {
        m=(st+dr)/2;
        if(v[m]==x)
        {
            poz=m;
            st=m+1;
        }
        else
        {
            if(v[m]<x)
            {
                st=m+1;
            }
            else
            {
                dr=m-1;
            }
        }
    }
}
int cb1(int st,int dr, int x)
{
    int m,poz;
    while(st<=dr)
    {
        m=(st+dr)/2;
        if(v[m]<=x)
        {
            poz=m;
            st=m+1;
        }
        else
        {
            dr=m-1;
        }
    }
        return poz;
}
int cb2(int st, int dr, int x)
{
    int m;
    while(st<=dr)
    {
        m=(st+dr)/2;
        if(v[m]>=x)
        {
            dr=m-1;
        }
        else
        {
            st=m+1;
        }
    }
        return m;
}
int main()
{
    int n,i,j,x,m,t;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    fin>>m;
    for(i=1;i<=m;i++)
    {
        fin>>t>>x;
        if(t==0)
        {
            fout<<cb0(1,n,x)<<'\n';
        }
        if(t==1)
        {
            fout<<cb1(1,n,x)<<'\n';
        }
        if(t==2)
        {
            fout<<cb2(1,n,x)<<'\n';
        }
    }
    return 0;
}
