#include <bits/stdc++.h>
#pragma GCC optimize("03")
#define ll long long
#define u unsigned
using namespace std;

signed main() {
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");

    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];

    int q;
    cin >> q;
    for (int i = 0; i < n; i++) {
        char tip;
        int x;
        cin >> tip >> x;
        if (tip == '0') {
            int up = upper_bound(a.begin(), a.end(), x) - a.begin();
            if (a[up-1] == x) cout << up-1 << '\n';
            else cout << "-1\n";
        } else if (tip == '1') {

        } else if (tip == '3') {

        }
    }
}
