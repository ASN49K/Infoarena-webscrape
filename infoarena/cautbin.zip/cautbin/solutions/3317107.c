#include <stdio.h>
#define MAXN 100000

int ele[MAXN];
int main () {
    FILE *fin , *fout;
    int n , i , m , tip , x , ste , dre , mije;

    fin = fopen ( "cautbin.in" , "r" );
    fscanf ( fin , "%d" , &n );
    for ( i = 0 ; i < n ; i++ )
        fscanf ( fin , "%d" , &ele[i] );
    fscanf ( fin , "%d" , &m );
    fout = fopen ( "cautbin.out" , "w" );
    for ( i = 0 ; i < m ; i++ ) {
        fscanf ( fin , "%d%d" , &tip , &x );
        switch ( tip ) {
            case 0:
                ste = 0;
                dre = n;
                while ( dre - ste > 1 ) {
                    mije = ( ste + dre ) / 2;
                    if ( ele[mije] > x )
                        dre = mije;
                    else
                        ste = mije;
                }
                if ( ele[ste] == x )
                    fprintf ( fout , "%d" , ste + 1 );
                else
                    fprintf ( fout , "-1" );
                fputc ( '\n' , fout );
                break;
            case 1:
                ste = 0;
                dre = n;
                while ( dre - ste > 1 ) {
                    mije = ( ste + dre ) / 2;
                    if ( ele[mije] > x )
                        dre = mije;
                    else
                        ste = mije;
                }
                if ( ele[ste] == x )
                    ste++;
                fprintf ( fout , "%d\n" , ste );
                break;
            default:
                ste = -1;
                dre = n - 1;
                while ( dre - ste > 1 ) {
                    mije = ( ste + dre ) / 2;
                    if ( ele[mije] < x )
                        ste = mije;
                    else
                        dre = mije;
                }
                if ( ele[dre] != x )
                    dre++;
                fprintf ( fout , "%d\n" , dre + 1 );
        }
    }
    fclose ( fin );
    fclose ( fout );
    
    return 0;
}