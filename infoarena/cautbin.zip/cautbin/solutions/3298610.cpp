#include <fstream>
ifstream cin("cow.in");
ofsream cout("cow.out");
using namespace std;

int main()
{
    cout<<"3"<<endl<<"1";
}
