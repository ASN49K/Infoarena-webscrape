#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n, mid,dr,st,v[10001],sol0,sol1,sol2,x,c,M;
int main()
{

    fin >> n;
    for(int i=1;i<=n;i++)
        fin >> v[i];
    fin >> M;
    st=1,dr=n;
    while(M)
    {
        fin >> c >> x;
        if(c==0)
        {
            st=1,dr=n,sol0=-1;
            while(st<=dr)
            {
                mid=(st+dr)/2;
                if(v[mid]==x)
                    sol0=mid;
                if(v[mid]<=x)
                    st=mid+1;
                else if(v[mid]>x)
                    dr=mid-1;
            }
            fout << sol0 <<'\n';
        }
        else if(c==1)
        {
            st=1,dr=n,sol1=-1;
            while(st<=dr)
            {
                mid=(st+dr)/2;
                if(v[mid]<=x)
                    sol1=mid,st=mid+1;
                else if(v[mid]>x)
                    dr=mid-1;
            }
            fout << sol1 <<'\n';
        }
        else
        {
            st=1,dr=n,sol2=-1;
            while(st<=dr)
            {
                mid=(st+dr)/2;
                if(v[mid]<x)
                    st=mid+1;
                else if(v[mid]>=x)
                    sol2=mid,dr=mid-1;
            }
            fout << sol2 <<'\n';
        }

        M--;
    }

    return 0;
}
