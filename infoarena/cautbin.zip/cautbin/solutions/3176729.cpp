#include <iostream>
#include <fstream>
#include <cmath>
#include <climits>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n,m,a[100001],q,t,r0;
int main()
{

    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>a[i];
    fin>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>q>>t;
        if(q==0)
        {
            int st=1, dr=n, mij=(st+dr)/2;;
            while(st<=dr)
            {
                if(t>=a[mij])
                        st=mij+1;
                else
                    dr=mij-1;
                mij=(st+dr)/2;
            }
            if(dr<1 || a[dr]!=t)
                fout<<"-1\n";
            else
                fout<<dr<<"\n";
        }
        if(q==1)
        {
            int st=1, dr=n, mij=(st+dr)/2;;
            while(st<=dr)
            {
                if(t>=a[mij])
                        st=mij+1;
                else
                    dr=mij-1;
                mij=(st+dr)/2;
            }
            fout<<dr<<"\n";
        }
        if(q==2)
        {
            int st=1, dr=n, mij=(st+dr)/2;;
            while(st<=dr)
            {
                if(t<=a[mij])
                        dr=mij-1;
                else
                    st=mij+1;
                mij=(st+dr)/2;
            }
            fout<<st<<"\n";
        }
    }
    return 0;
}
