#include <fstream>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
    int v[10005], a[100005], pos[10005];
int main()
{
    int n;
    cin>>n;
    int x[n];
    for(int i=0; i<n; i++){
        cin>>a[i];
        v[a[i]]++;
        pos[a[i]]=i+1;
    }
    int t, a, b, j, c;
    cin>>t;
    for(int i=0; i<t; i++){
        cin>>a>>b;
        bool nu=true;
        for(j=0; j<n && nu; j++){
            if(b>=v[j] && b<v[j+1]) {
                c=j;
                nu=false;
            }
        }
        if(a==0) x[i]=pos[b];
        else if(a==1) x[i]=v[c];
        else if(a==2) x[i]=v[c+1];
    }
    for(int i=0; i<n; i++) cout<<x[i]<<"\n";
}