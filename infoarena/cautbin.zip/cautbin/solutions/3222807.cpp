#include <fstream>
using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");

const int nmax = 100005;
int a[nmax];
int n, q;

int main(){
    ios::sync_with_stdio(0);
    f.tie(0);
    f >> n;
    for(int i = 1; i <= n; i++){
        f >> a[i];
    }
    f >> q;
    while(q--){
        
        int t, x;
        f >> t >> x;
        if(t == 0){
            int sol = -1;
            int st = 1, dr = n;
           
            while(st <= dr){
                int m = (st + dr) / 2;
                if(a[m] == x){
                    sol = m;
                    st = m + 1;
                }
                else if(a[m] < x){
                    st = m + 1;
                }
                else if(a[m] > x){
                    dr = m - 1;
                }
            }
            g << sol << '\n';
        }
        else if(t == 1){
            int sol = -1;
            int st = 1, dr = n; 
            while(st <= dr){
               int m = (st + dr) / 2;
              
                if(a[m] <= x){
                    st = m + 1;
                    sol = m;
                }
                else{
                    dr = m - 1;
                }
            }
            g << sol << '\n';
        }
        else if(t == 2){
            int sol = -1;
            int st = 1, dr = n; 
            while(st <= dr){
               int m = (st + dr) / 2;
                
                if(a[m] >= x){
                    sol = m;
                    dr = m - 1;
                }
                else{
                    st = m + 1;
                }
            }
            g << sol << '\n';
        }
    }
}