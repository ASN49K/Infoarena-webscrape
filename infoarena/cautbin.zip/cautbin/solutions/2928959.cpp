#include <iostream>
#include <cstring>
using namespace std;

int main() {
    const int MAX_LENGTH = 100000;
    int n, a[MAX_LENGTH + 1];
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }
    int m;
    cin >> m;
    while (m > 0) {
        int q, x;
        cin >> q >> x;
        if (q == 0 || q == 1) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                if (a[mid] <= x) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
            if (q == 0) {
                if (a[mid] == x) {
                    cout << mid  << "\n";
                } else {
                    cout << -1 << "\n";
                }
            } else if (q == 1) {
                if (a[mid] <= x) {
                    cout << mid << "\n";
                }
            }
        } else if (q == 2) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                if (a[mid] >= x) {
                    right = mid;
                } else {
                    left = mid + 1;
                }
            }
            if (a[right] == x) {
                cout << right << "\n";
            }
        }
        --m;
    }
    return 0;
}
