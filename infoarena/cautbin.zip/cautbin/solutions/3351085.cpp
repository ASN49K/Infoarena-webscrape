#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100000];
int bin(int a, int b, int x)
{
    int m;
    m=(a+b)/2;
    while(a<=b){
        if(v[m]>x){
            b=m-1;
        }
        else{
            a=m+1;
        }
        m=(a+b)/2;
    }
        return m;
}
int main()
{
    int n,m,x,i,p,c;
    fin>>n;
    for(i=1; i<=n; i++){
        fin>>v[i];
    }
    fin>>m;
    for(i=0; i<m; i++){
        fin>>c>>x;
        if(c==0){
            p=bin(0,n,x);
            if(v[p]==x){
                while(v[p+1]==x)
                    p++;
                fout<<p<<'\n';
            }
            else{
                fout<<-1<<'\n';
            }
        }
        if(c==1){
            p=bin(0,n,x);
            if(v[p]<=x){
                while(v[p+1]<=x){
                    p++;
                }
            }
            else{
                while(v[p]>x){
                    p--;
                }
            }
            fout<<p<<'\n';
        }
        if(c==2){
            p=bin(0,n,x);
            if(v[p]>=x){
                while(v[p-1]>=x){
                    p--;
                }
            }
            else{
                while(v[p]<x){
                    p++;
                }
            }
            fout<<p<<'\n';
        }
    }
}
