#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream input("cautbin.in");
    ofstream output("cautbin.out");

    int N, M;
    input >> N;
    vector<int> sir(N);

    for (int i = 0; i < N; i++) {
        input >> sir[i];
    }

    input >> M;
    for (int i = 0; i < M; i++) {
        int tip, x;
        input >> tip >> x;

        if (tip == 0) {
            // Cautarea celei mai mari pozitii pentru valoarea x
            int pozitie = -1;
            for (int j = 0; j < N; j++) {
                if (sir[j] == x) {
                    pozitie = j;
                }
            }
            output << pozitie + 1 << endl;
        } else if (tip == 1) {
            // Cautarea celei mai mari pozitii pentru un element mai mic sau egal cu x
            int pozitie = -1;
            for (int j = 0; j < N; j++) {
                if (sir[j] <= x) {
                    pozitie = j;
                }
            }
            output << pozitie + 1 << endl;
        } else if (tip == 2) {
            // Cautarea celei mai mici pozitii pentru un element mai mare sau egal cu x
            int pozitie = -1;
            for (int j = N - 1; j >= 0; j--) {
                if (sir[j] >= x) {
                    pozitie = j;
                }
            }
            output << pozitie + 1 << endl;
        }
    }


    return 0;
}

