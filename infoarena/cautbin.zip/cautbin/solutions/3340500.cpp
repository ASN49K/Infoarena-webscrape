#include <iostream>
#include <fstream>

#define NMAX 100000


int bsearch0(int *arr, int n, int v)
{
    int l = 0;
    int r = n - 1;
    int m;

    while (l <= r) {
        m = l + ((r - l) / 2);

        if (arr[m] <= v)
            l = m + 1;
        else
            r = m - 1;
    }

    m = l + ((r - l) / 2);

    if (arr[m] > v)
        --m;

    if (arr[m] == v)
        return m;

    return -1;
}

int bsearch1(int *arr, int n, int v)
{
    int l = 0;
    int r = n - 1;
    int m;

    while (l < r) {
        m = l + ((r - l) / 2);

        if (arr[m] < v)
            l = m + 1;
        else
            r = m;
    }

    return l;
}

int bsearch2(int *arr, int n, int v)
{
    int l = 0;
    int r = n - 1;
    int m;

    while (l < r) {
        m = l + ((r - l) / 2);

        if (arr[m] <= v)
            l = m + 1;
        else
            r = m;
    }

    return l;
}


int main()
{
    int n, m;
    int arr[NMAX];
    std::ifstream fin("cautbin.in");
    std::ofstream fout("cautbin.out");


    fin >> n;

    for (int i = 0; i < n; ++i)
        fin >> arr[i];


    fin >> m;

    for (int q, v, p, i = 0; i < m; ++i)
    {
        fin >> q >> v;

        switch (q) {
        case 0:
            p = bsearch0(arr, n, v);

            if (p == -1)
                fout << -1 << '\n';
            else
                fout << p + 1 << "\n";

            break;
        case 1:
            fout << bsearch1(arr, n, v) - 1 + 1 << "\n";
            break;
        case 2:
            fout << bsearch2(arr, n, v) + 1 << "\n";
            break;
        }
    }


    fin.close();
    fout.close();


    return 0;
}
