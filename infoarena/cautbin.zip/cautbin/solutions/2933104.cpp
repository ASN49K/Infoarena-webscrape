#include <iostream>
#include <fstream>
using namespace std;
int x,n,t,c,v[100001],st,dr,sol,mid;
int main()
{
    ifstream f ("cautbin.in");
    ofstream g ("cautbin.out");
    f>>n;
    for (int i=1; i<=n; i++)
        f>>v[i];
    f>>t;
    while (t--)
    {
        f>>c>>x;
        st=1;
        dr=n;
        if (c==0)
        {
            sol=-1;
            while (st<=dr)
            {
                mid=(st+dr)/2;
                if (v[mid]<x)
                    st=mid+1;
                else if (v[mid]>x)
                    dr=mid-1;
                else
                {
                    sol=mid;
                    st=mid+1;
                }
            }
        }
        else if (c==1)
        {
            sol=-1;
            while (st<=dr)
            {
                mid=(st+dr)/2;
                if (v[mid]<=x)
                {
                    sol=mid;
                    st=mid+1;
                }
                else dr=mid-1;
            }
        }
        else
        {
            sol=n+1;
            while (st<=dr)
            {
                mid=(st+dr)/2;
                if (v[mid]>=x)
                {
                    sol=mid;
                    dr=mid-1;
                }
                else
                    st=mid+1;
            }
        }
        g<<sol<<'\n';
    }
}
