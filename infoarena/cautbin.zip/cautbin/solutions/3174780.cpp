#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");

int main()
{
    int n, m, v[100001], p, x, ans;
    
    fin>>n;
    for (int i=1; i<=n; i++){
        fin>>v[i];
    }
    fin>>m;
    int i;
    for (int j=1; j<=m; j++){
        fin>>p>>x;
        int left=1, right=n;
        i=(left+right)/2;
        if (p==0){
            ans=-1;
            while (v[i]!=x || v[i+1]==x){
                if(v[i]<=x){
                    left=i;
                    i=(left+right)/2;
                }
                else if(v[i]>x){
                    right=i;
                    i=(left+right)/2;
                }
            }
            if (v[i]==x){
                fout<<i;
            }
            else{
                cout<<ans;
            }
        }
        if (p==1){
            ans=-1;
            while (v[i]<=x && v[i+1]<=x){
                if(v[i]<=x){
                    left=i;
                    i=(left+right)/2;
                }
                else if(v[i]>x){
                    right=i;
                    i=(left+right)/2;
                }
            }
            fout<<i;
        }
        if (p==2){
            ans=-1;
            while (v[i]>=x && v[i-1]>=x){
                if(v[i]<=x){
                    left=i;
                    i=(left+right)/2;
                }
                else if(v[i]>x){
                    right=i;
                    i=(left+right)/2;
                }
            }
            fout<<i;
        }
        fout<<endl;
    }

    return 0;
}
