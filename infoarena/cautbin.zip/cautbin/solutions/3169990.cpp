#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int a[100001],N,M;

int main()
{
    fin>>N;
    int i,tip,x,li,lf,mj;
    for(i=1;i<=N;i++)fin>>a[i];
    fin>>M;
    for(i=1;i<=M;i++)
    {
        fin>>tip>>x;
        if(tip==0 || tip==1)
        {
            li=1;lf=N;mj=(li+lf)/2;
            while(li<=lf)
            {
                if(x>=a[mj])
                    li=mj+1;
                else
                    lf=mj-1;
                mj=(li+lf)/2;
            }
            if(tip==0)
                if(lf==0||a[lf]!=x)
                    fout<<-1<<"\n";
                else
                    fout<<lf<<"\n";
            else
                fout<<lf<<"\n";
        }
        else
        {
            li=1;lf=N;mj=(li+lf)/2;
            while(li<=lf)
            {
                if(x<=a[mj])
                    lf=mj-1;
                else
                    li=mj+1;
                mj=(li+lf)/2;
            }
            fout<<li<<"\n";
        }
    }
    return 0;
}
