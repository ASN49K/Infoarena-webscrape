#include <bits/stdc++.h>
using ll=long long;
#define S second
#define F first
#define endl '\n'
#define spid ios_base::sync_with_stdio(false);cin.tie(NULL);
const int mod=1e9+7;
const double pi=3.14159265359;
const int maxn=100001;
using namespace std;

int n,m,A[maxn];

int main(){
	ifstream cin("cautbin.in");
	ofstream cout("cautbin.out");
	cin>>n;
	for(int i=0;i<n;i++)cin>>A[i];
	cin>>m;
	while(m--){
		int c,x;
		cin>>c>>x;
		if(c==0){
			auto it=upper_bound(A,A+n,x);
			if(it==A+n){
				cout<<-1<<endl;
				continue;
			}
			it--;
			if(*it==x)cout<<it-A+1<<endl;
			else cout<<-1<<endl;
		}
		else if(c==1){
			auto it=upper_bound(A,A+n,x);
			cout<<it-A<<endl;
		}
		else{
			auto it=upper_bound(A,A+n,x-1);
			cout<<it-A+1<<endl;
		}
	}
}

