#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in"); ofstream fout("cautbin.out");

int main(){
    int n;
    fin >> n;
    vector<int> vec(n+1);
    for(int i = 1; i<=n; i++){
        fin >> vec[i];
    }

    int q;
    fin >> q;
    for(int i = 1; i<=q; i++){
        int c, x;
        fin >> c >> x;
        if(c == 0){
            int it = upper_bound(vec.begin()+1, vec.end(), x) - vec.begin()-1;
            if(it <= n && it >= -1 && vec[it] == x){
                fout << it << endl;
            } else fout << -1 << endl;
        } else if(c == 1){
            int it = lower_bound(vec.begin()+1, vec.end(), x+1) -vec.begin()-1;
            fout << it << endl;
        } else {
            int it = upper_bound(vec.begin()+1, vec.end(), x-1) - vec.begin();
            fout << it << endl;
        }
    }
}
