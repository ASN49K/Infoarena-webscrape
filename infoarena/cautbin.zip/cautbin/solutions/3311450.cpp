#include <fstream>

// Legnagyobb x

void bs0(int *t, int n, int x, std::ofstream &out)
{
    int l = 0, r = n - 1;

    while (l < r)
    {
        int mid = (l + r + 1) / 2;

        if (t[mid] <= x)
        {
            l = mid;
        }
        else
        {
            r = mid - 1;
        }
    }

    ((t[l] == x) ? (out << l + 1 << '\n') : (out << -1 << '\n'));

    return;
}

//-----------------------------------------------------------------------------
// kisebb vagy egyenlo mint x

void bs1(int *t, int n, int x, std::ofstream &out)
{
    int l = 0, r = n - 1;

    while (l < r)
    {
        int mid = (l + r + 1) / 2;

        if (t[mid] <= x)
        {
            l = mid;
        }
        else
        {
            r = mid - 1;
        }
    }

    out << l + 1 << '\n';

    return;
}

//-----------------------------------------------------------------------------

void bs2(int *t, int n, int x, std::ofstream &out)
{
    int l = 0, r = n - 1;

    while (l < r)
    {
        int mid = (l + r) / 2;

        if (t[mid] < x)
        {
            l = mid + 1;
        }
        else
        {
            r = mid;
        }
    }

    out << l + 1 << '\n';

    return;
}

//-----------------------------------------------------------------------------

int main()
{
    int n, x;

    std::ifstream in("cautbin.in");
    in >> n;

    int *t = new int[n], m;
    for (int i = 0; i < n; i++)
    {
        in >> t[i];
    }
    in >> m;

    std::ofstream out("cautbin.out");
    while (m--)
    {
        short q;
        in >> q >> x;

        if (q == 0)
        {
            bs0(t, n, x, out);
        }
        else if (q == 1)
        {
            bs1(t, n, x, out);
        }
        else
        {
            bs2(t, n, x, out);
        }
    }
    in.close();
    out.close();

    delete[] t;
    return 0;
}