#include <bits/stdc++.h>
using namespace std;

const int nmax = 100007;

int n, m;
int a[nmax];


void solve() {
  
  cin >> n;
  for (int i = 1; i <= n; i++) cin >> a[i];

  int m;
  cin >> m;

  for (int _ = 0; _ < m; _++) {
    
    int tip_intrebare, x;
    cin >> tip_intrebare >> x;

    if (tip_intrebare == 0) {
      int st = 1, dr = n;
      while (st != dr) {
        int mij = (st + dr + 1) / 2;
        if (a[mij] < x) st = mij + 1;
        else if (a[mij] > x) dr = mij - 1;
        else st = mij;
      }
      cout << (a[st] != x ? -1 : st) << '\n';
    }

    else if (tip_intrebare == 1) {
      int st = 1, dr = n;
      while (st != dr) {
        int mij = (st + dr + 1) / 2;
        if (a[mij] <= x) st = mij;
        else dr = mij - 1;
      }
      cout << st << '\n';
    }

    else {
      int st = 1, dr = n;
      while (st != dr) {
        int mij = (st + dr) / 2;
        if (a[mij] >= x) dr = mij;
        else st = mij + 1;
      }
      cout << st << '\n';
    }




  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cautbin.in", "r", stdin);
  freopen("cautbin.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
 