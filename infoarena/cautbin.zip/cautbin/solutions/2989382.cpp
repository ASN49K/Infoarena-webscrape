#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int lowerBound(vector<long long> elements, int left, int right, long long value);
int upperBound(vector<long long> elements, int left, int right, long long value);

int main(){

    int arraySize, queryCount;
    vector<long long> elements;

    fin >> arraySize;
    elements.resize(arraySize);

    for(int i = 0; i < elements.size(); i++)
        fin >> elements[i];

    fin >> queryCount;

    for(long long i = 0, queryType, queryValue, indexFound; i < queryCount; i++){
        fin >> queryType >> queryValue;

        if(queryType == 0){
            indexFound = upperBound(elements, 0, elements.size(), queryValue);

            if(indexFound > 0 && elements[indexFound - 1] == queryValue)
                fout << (indexFound - 1) + 1 << '\n';
            else
                fout << "-1\n";
        }else if(queryType == 1){
            indexFound = upperBound(elements, 0, elements.size(), queryValue);

            fout << (indexFound - 1) + 1 << '\n';
        }else if(queryType == 2){
            indexFound = lowerBound(elements, 0, elements.size(), queryValue);

            fout << indexFound + 1 << '\n';
        }
    }

    return 0;
}

int lowerBound(vector<long long> elements, int left, int right, long long value){
    int middle, indexFound = elements.size() - 1;

    while(left <= right){
        middle = (left + right) / 2;

        if(value <= elements[middle]){
            indexFound = middle;
            right = middle - 1;
        }else{
            left = middle + 1;
        }
    }

    return indexFound;
}

int upperBound(vector<long long> elements, int left, int right, long long value){
    int middle, indexFound = elements.size() - 1;

    while(left <= right){
        middle = (left + right) / 2;

        if(value < elements[middle]){
            indexFound = middle;
            right = middle - 1;
        }else{
            left = middle + 1;
        }
    }

    return indexFound;
}