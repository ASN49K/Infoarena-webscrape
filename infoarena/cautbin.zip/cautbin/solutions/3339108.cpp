#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
const int nmax=100005;
int n,m,cerinta,x;
int v[nmax];
int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
    }
    cin>>m;
    for(int i=1; i<=n; i++)
    {
        cin>>cerinta>>x;
        if(cerinta==0)
        {
            int st=1,dr=n;
            int ans=-1;///rezultatul cautarii
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]==x)
                {
                    ans=mij;
                    st=mij+1;
                }
                else if(v[mij]<x)
                {
                    st=mij+1;
                }
                else
                {
                    dr=mij-1;
                }
            }
            cout<<ans<<endl;
        }
        if(cerinta==1)
        {
            int st=1;
            int dr=n;
            int ans=-1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]<=x)
                {
                    ans=mij;
                    st=mij+1;
                }
                else
                {
                    dr=mij-1;
                }
            }
            cout<<ans<<endl;
        }
        if(cerinta==2)
        {
            int st=1,dr=n,ans=-1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>=x)
                {
                    ans=mij;
                    dr=mij-1;
                }
                else
                {
                    st=mij+1;
                }
            }
            cout<<ans<<endl;
        }
    }
}
