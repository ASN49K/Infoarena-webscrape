#include <fstream>
#include <algorithm> // pentru swap

using namespace std;

int v[100001];

ifstream cin("bete2.in");
ofstream cout("bete2.out");

int main() {
    int n, c = 0;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
    }

    // sortare cu bule (lent, dar conform codului tău)
    bool sortat;
    do {
        sortat = true;
        for (int i = 1; i < n; i++) {
            if (v[i] > v[i + 1]) {
                swap(v[i], v[i + 1]);
                sortat = false;
            }
        }
    } while (!sortat);

    // verificare triplete cu suma
    for (int i = 1; i <= n - 2; i++) {
        for (int j = i + 1; j <= n - 1; j++) {
            int s = v[i] + v[j];
            int st = j + 1, dr = n;
            while (st <= dr) {
                int mid = st + (dr - st) / 2;
                if (v[mid] == s) {
                    c++;
                    break;
                } else if (v[mid] < s) {
                    st = mid + 1;
                } else {
                    dr = mid - 1;
                }
            }
        }
    }

    cout << c;

    return 0;
}