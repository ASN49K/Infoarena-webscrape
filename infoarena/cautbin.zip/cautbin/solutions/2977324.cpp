#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[1000];

int CautareBinara(int st, int dr, int x, int v[],int op){
    int ans = -1;
    int maxpoz = -1;
    while(st<=dr){
        int med = (st+dr)/2;

        if(med>maxpoz && v[med]==x){
            maxpoz = med;
        }

        if(v[med]<=x){
            st = med+1;
            ans = med;
        }
        else{
            dr = med-1;
        }
    }

    if(op==0){
    fout << maxpoz <<"\n";
    }

    if(op==1){
    fout << ans <<"\n";
    }

}

int CMMP(int st, int dr, int x, int v[],int op){
    int ans = -1;
    int minpoz = 10000;
    while(st<=dr){
        int med = (st+dr)/2;

        if(med<minpoz && v[med]==x){
            minpoz = med;
        }

        if(v[med]>=x){
            dr = med-1;
            ans = med;
        }
        else{
            st = med+1;
        }
    }
    fout << minpoz <<"\n";


}

int main()
{
    int n;
    fin >> n;
    for(int i = 1;i<=n;i++){
            fin >> v[i];
    }
    int nrop;
    fin >> nrop;
    for(int j = 1;j<=nrop;j++){
        int op,x;
        fin >> op >> x;
        CautareBinara(1, n, x, v,op);
        if(op==2){
        CMMP(1, n, x, v,op);
        }
    }

    return 0;
}
