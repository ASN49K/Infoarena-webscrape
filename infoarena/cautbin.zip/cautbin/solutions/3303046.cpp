#include <fstream>
const int NMAX=1e5+5;

using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int v[NMAX],n;

void bin0(int st,int dr,int x,int ans)
{
    int mij;
    if(st<=dr)
    {
        mij=st+(dr-st)/2;
        if(v[mij]<=x)
        {
            if(v[mij]==x) ans=mij;
            bin0(mij+1,dr,x,ans);
        }
        else bin0(st,mij-1,x,ans);
    }
    else cout<<ans<<endl;
}

void bin1(int st,int dr,int x,int ans)
{
    int mij;
    if(st<=dr)
    {
        mij=st+(dr-st)/2;
        if(v[mij]<=x)
        {
            ans=mij;
            bin1(mij+1,dr,x,ans);
        }
        else bin1(st,mij-1,x,ans);
    }
    else cout<<ans<<endl;
}

int bin2(int x)
{
    int st=1,dr=n,mij,ans=-1;
    while(st<=dr)
    {
        mij=st+(dr-st)/2;
        if(v[mij]>=x)
        {
            dr=mij-1;
            ans=mij;
        }
        else st=mij+1;
    }
    return ans;
}

int main()
{
    int i,m;
    cin>>n;
    for(i=1;i<=n;i++) cin>>v[i];
    cin>>m;
    for(i=1;i<=m;i++)
    {
        int tip,x;
        cin>>tip>>x;
        if(tip==0) bin0(1,n,x,-1);
        else if(tip==1) bin1(1,n,x,-1);
        else cout<<bin2(x)<<endl;
    }
    return 0;
}
