#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100001], n, st, dr, mij, poz, m, x, y;
int main()
{
    fin>>n;
    for(int i=1 ; i<=n ; i++)
    {
        fin>>v[i];
    }
    fin>>m;
    for(int j=1 ; j<=m ; j++)
    {
        fin>>y>>x;
        if(y==0)
        {
            st=1;
            dr=n;
            poz=-1;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]==x)
                {
                    poz=mij;
                    st=mij+1;
                }
                else if(v[mij]>x)
                {
                    dr=mij-1;
                }
                else
                {
                    st=mij+1;
                }
            }
            fout<<poz<<"\n";
        }
        else if(y==1)
        {
            st=1;
            dr=n;
            poz=-1;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]<=x)
                {
                    poz=mij;
                    st=mij+1;
                }
                else
                {
                    dr=mij-1;
                }
            }
            fout<<poz<<"\n";
        }
        else if(y==2)
        {
            st=1;
            dr=n;
            poz=-1;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]>=x)
                {
                    poz=mij;
                    dr=mij-1;
                }
                else
                {
                    st=mij+1;
                }
            }
            fout<<poz<<"\n";
        }
    }

    return 0;
}
