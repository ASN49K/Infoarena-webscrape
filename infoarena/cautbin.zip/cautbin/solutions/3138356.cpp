#include <fstream>
using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");
int v[100000], n;

int cautBin1(int x) {
    int p = 1, u = n, poz = -1;
    while (p <= u) {
        int m = (p + u) / 2;
        if(x == v[m])
            poz = m;
        if(x >= v[m])
            p = m + 1;
        else
            u = m - 1;
    }

    return poz;
}

int cautBin2(int x) {
    int p = 1, u = n, poz = -1;
    while (p <= u) {
        int m = (p + u) / 2;
        if(x >= v[m]) {
            poz = m;
            p = m + 1;
        } else
            u = m - 1;
    }

    return poz;
}

int cautBin3(int x) {
    int p = 1, u = n, poz = -1;
    while (p <= u) {
        int m = (p + u) / 2;
        if(x <= v[m]) {
            poz = m;
            u = m - 1;
        } else
            p = m + 1;
    }

    return poz;
}

int main() {
    f >> n;
    for(int i = 1; i <= n; i++)
        f >> v[i];
    int m, x, y; f >> m;
    while (m --) {
        f >> x >> y;
        switch (x) {
            case 0:
                g << cautBin1(y) << '\n';
                break;
            case 1:
                g << cautBin2(y) << '\n';
                break;
            case 2:
                g << cautBin3(y) << '\n';
                break;
        }
    }
    f.close();
    f.close();

    return 0;
}
