#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}#include<fstream>
using namespace std;
int v[200005],n,x,poz,i,p,m;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int cautbin0(int x)
{
    int ras,mij,st,dr;
    ras=-1;
    st=1;
    dr=n;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(v[mij]==x)
        {
            ras=mij;
            st=mij+1;
        }
        else
          if(x>v[mij])
            st=mij+1;
          else
            dr=mij-1;
    }
    return ras;
}

///cea mai din dreapta pozitie pe care un element este <= x
int cautbin1(int x)
{
    int ras,mij,st,dr;
    st=1;
    dr=n;
    ras=-1;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(v[mij]<=x)
        {
            ras=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    return ras;
}

///cea mai din stanga pozitie pe care un element este >= x
int cautbin2(int x)
{
    int ras,mij,st,dr;
    st=1;
    dr=n;
    ras=-1;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(v[mij]>=x)
        {
            ras=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return ras;
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i];
    fin>>m;
    for(i=1;i<=m;i++)
    {
        fin>>p>>x;
        if(p==0)
            poz=cautbin0(x);
        else
            if(p==1)
                poz=cautbin1(x);
            else
                poz=cautbin2(x);
        fout<<poz<<'\n';
    }
    return 0;
}
