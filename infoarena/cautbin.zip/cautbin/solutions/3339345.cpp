#include <bits/stdc++.h>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100005];
int binarys0(int st, int dr, int val)
{
    int previousmid = -1;
    while(st<=dr)
    {
        int mid = (st+dr)/2;
        if(val == v[mid]){
            previousmid = mid;
            st = mid+1;
        }
        else if(val<=v[mid])
        {
            dr = mid-1;
        }
        else if(val>=v[mid])
        {
            st = mid+1;
        }
        
    }
    return previousmid;
}
int binarys1(int st, int dr, int val)
{
    int previousmid = -1;
    while(st<=dr)
    {
        int mid = (st+dr)/2;
        if(val == v[mid] or val >= v[mid]){
            previousmid = mid;
            st = mid+1;
        }
        else if(val<=v[mid])
        {
            dr = mid-1;
        }
        
    }
    return previousmid;
}
int binarys2(int st, int dr, int val)
{
    int previousmid = -1;
    while(st<=dr)
    {
        int mid = (st+dr)/2;
        if(val == v[mid] or v[mid]>=val)
        {
            previousmid = mid;
            dr = mid-1;
        }
        else if(val >= v[mid])
        {
            st = mid+1;
        }
        
    }
    return previousmid;
}
int main(){
    int n; fin >> n;
    for(int i = 1;i<=n;i++)
        fin >> v[i];
    int m; fin >> m;
    while(m--)
    {
        int c; fin >> c;
        int x; fin >> x;
        if(c == 0)
            fout << binarys0(1,n,x) << '\n';
        if(c == 1)
            fout << binarys1(1,n,x) << '\n';
        if(c == 2)
            fout << binarys2(1,n,x) << '\n';


    }
    return 0;
}