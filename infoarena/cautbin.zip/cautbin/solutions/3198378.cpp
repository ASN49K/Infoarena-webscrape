#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

void cautbinar0(int x, int n, int a[])
{
    int st, dr, poz, mij;
    poz=-1;
    st=1;
    dr=n;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(x==a[mij])
        {
            poz=mij;
            st=mij+1;
        }
        else
        {
            if(x>a[mij])    st=mij+1;
            else    dr=mij-1;
        }
    }
    fout << poz << '\n';
}
void cautbinar1(int x, int n, int a[])
{
    int st, dr, poz, mij;
    poz=-1;
    st=1;
    dr=n;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(x>=a[mij])
        {
            poz=mij;
            st=mij+1;
        }
        else    dr=mij-1;
    }
    fout << poz << '\n';
}
void cautbinar2(int x, int n, int a[])
{
    int st, dr, poz, mij;
    poz=-1;
    st=1;
    dr=n;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(x<=a[mij])
        {
            poz=mij;
            dr=mij-1;
        }
        else    st=mij+1;
    }
    fout << poz << '\n';
}
int n, v[100001], m, t, x;
int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        fin >> v[i];
    fin >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> t >> x;
        if(t==0)    cautbinar0(x, n, v);
        else if(t==1)   cautbinar1(x, n, v);
        else if(t==2)   cautbinar2(x, n, v);
    }
    
    return 0;
}