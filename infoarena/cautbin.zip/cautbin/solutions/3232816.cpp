#include<bits/stdc++.h>
using namespace std;
ifstream F("cautbin.in");
ofstream G("cautbin.out");
#define Z 2048
int n,m,a[100001],i,j,k,p=Z,q;
char s[Z],t[Z];
inline char A()
{
    if(p==Z)
        F.read(s,Z),p=0;
    return s[p++];
}
int B()
{
    char c;
    int n=0;
    for(c=A();isdigit(c);n=n*10+c-48,c=A());
    return n;
}
inline void C()
{
    if(q==Z)
        G.write(t,Z),q=0;
}
void D(int n)
{
    int k=0,a[6];
    for(a[k++]=n%10,n/=10;n;a[k++]=n%10,n/=10);
    for(;k;t[q++]=a[--k]+48,C());
    t[q++]='\n',C();
}
int main()
{
    for(n=B();i<n;a[i++]=B());
    for(m=B();m--;)
        if(i=B(),j=B(),i<2) {
            if(k=upper_bound(a,a+n,j)-a,!i&&a[k]!=j)
                t[q++]='-',C(),t[q++]=49,C(),t[q++]='\n',C();
            else
                D(k);
        } else
            D(lower_bound(a,a+n,j)-a+1);
    return G.write(t,q),0;
}
