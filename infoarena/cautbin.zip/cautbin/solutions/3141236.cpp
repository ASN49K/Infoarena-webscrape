#include <fstream>

using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
const int NMAX=1e5+2;
const int LONGMAX=16;
int n;
int a[NMAX];

int zero(int x)
{
    int index=0;
    for(int bit=LONGMAX; bit>=0; bit--)
    {
        index+=(1<<bit);
        if(index>n||a[index]>x) index-=(1<<bit);
    }

    if(a[index]==x)
    return index;
    else return -1;
}

int unu(int x)
{
    int index=0;
    for(int bit=LONGMAX; bit>=0; bit--)
    {
        index+=(1<<bit);
        if(index>n||a[index]>x) index-=(1<<bit);
    }
    return index;
}

int doi(int x)
{
    int index=0;
    for(int bit=LONGMAX; bit>=0; bit--)
    {
        index+=(1<<bit);
        if(index>n||a[index]>x-1) index-=(1<<bit);
    }
    return index+1;
}

int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a[i];
    }
    int m; cin>>m;

    while(m--)
    {
        int c; cin>>c;
        int x; cin>>x;
        if(c==0)
            cout<<zero(x)<<'\n';
        else if(c==1)
            cout<<unu(x)<<'\n';
        else cout<<doi(x)<<'\n';
    }
}
