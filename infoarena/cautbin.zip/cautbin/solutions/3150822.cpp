#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100001];

int caut(int v[100001], int y, int n){

    int st = 1, dr = n;
    int ans = 1;

    while(st <= dr){
        int med = (st + dr) / 2;

        if(v[med] <= y){
            ans = med;
            st = med + 1;
        }
        else{
            dr = med - 1;
        }
    }

    return ans;

}

int caut2(int v[100001], int y, int n){

    int st = 1, dr = n;
    int ans = 1;

    while(st <= dr){
        int med = (st + dr) / 2;

        if(v[med] >= y){
            ans = med;
            dr = med - 1;
        }
        else{
            st = med + 1;
        }
    }

    return ans;

}

int main(){

    int n, m;
    fin>>n;

    for(int i = 1; i <= n; i++){
        fin>>v[i];
    }

    fin>>m;
    for(int i = 1; i <= m; i++){
        int q, x;
        fin>>q>>x;

        if(q == 0 || q == 1){
            fout<<caut(v, x, n)<<"\n";
        }
        else{
            fout<<caut2(v, x, n)<<"\n";
        }
    }

    return 0;
}
