#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n, v[100003], m;
int main(){
    fin >> n;
    for(int i = 1; i <= n; i++){
        fin >> v[i];
    }
    fin >> m;
    for(int i = 1; i <= m; i++){
        int c, x;
        fin >> c >> x;
        if(c == 0){
            int p1 = 1, p2 = n, p = -1;
            while(p1 <= p2){
                int mij = (p1+p2)/2;
                if(v[mij] == x){
                    p = mij; 
                    p1 = mij+1;
                }else{
                    if(v[mij] < x){
                        p1 = mij+1;
                    }else{
                        p2 = mij-1;
                    }
                }
            }
            fout << p << "\n";
        }
        if(c == 1){
            int p1 = 1, p2 = n, p = -1;
            while(p1 <= p2){
                int mij = (p1+p2)/2;
                if(v[mij] <= x){
                    p = mij; 
                    p1 = mij+1;
                }else{
                    if(v[mij] < x){
                        p1 = mij+1;
                    }else{
                        p2 = mij-1;
                    }
                }
            }
            fout << p << "\n";
        }
        if(c == 2){
            int p1 = 1, p2 = n, p = -1;
            while(p1 <= p2){
                int mij = (p1+p2)/2;
                if(v[mij] >= x){
                    p = mij; 
                    p2 = mij-1;
                }else{
                    if(v[mij] < x){
                        p1 = mij+1;
                    }else{
                        p2 = mij-1;
                    }
                }
            }
            fout << p << "\n";
        }
    }
    return 0;
}