#include <bits/stdc++.h>

using namespace std;
int n,i,m,z,x[25001],y[200001],st,dr,mij,xx;
bool gasit;
int main()
{
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>x[i];
    cin>>m;
    for(i=1; i<=m; i++)
        cin>>y[i];
    for(i=1; i<=m; i++)
    {
        st = 1, dr = n, mij;
        gasit=0;
        xx=y[i];
        while(st<=dr && gasit==0)
        {
            mij = (st +dr)/2;
            if (x[mij]==xx)
                gasit=1;
            else if(xx<x[mij]) dr=mij-1;
            else st=mij+1;

        }
        cout<<gasit<<" ";
    }
    return 0;
}


