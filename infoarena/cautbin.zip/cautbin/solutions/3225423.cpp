#include <iostream>
#include <fstream>
#include <climits>
using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
#define cout g

#define MAXN 100002

int n;
long long a[MAXN] = {};


int main()
{
    f >> n;
    for (int i = 1; i <= n; i++) {
        f >> a[i];
    }

    int m;
    f >> m;
    while (m--) {
        int op, x;
        f >> op >> x;

        if (op == 0) {
            a[n+1] = INT_MAX+1ll;

            int st = 1;
            int dr = n;
            int rez = -1;
            while (st <= dr && rez == -1) {
                int mij = (st + dr) / 2;

                if (a[mij] == x && a[mij+1] > x) {
                    rez = mij;
                }

                if (x < a[mij]) {
                    dr = mij - 1;
                } else {
                    st = mij + 1;
                }
            }
            cout << rez << '\n';

        } else if (op == 1) {
            a[n+1] = INT_MAX+1ll;

            int st = 1;
            int dr = n;
            int rez = -1;
            while (st <= dr && rez == -1) {
                int mij = (st + dr) / 2;

                if (a[mij] <= x && a[mij+1] > x) {
                    rez = mij;
                }

                if (x < a[mij]) {
                    dr = mij - 1;
                } else {
                    st = mij + 1;
                }
            }
            cout << rez << '\n';
        } else if (op == 2) {
            int st = 1;
            int dr = n;
            int rez = -1;
            while (st <= dr && rez == -1) {
                int mij = (st + dr) / 2;

                if (a[mij] >= x && a[mij-1] < x) {
                    rez = mij;
                }

                if (x <= a[mij]) {
                    dr = mij - 1;
                } else {
                    st = mij + 1;
                }

                mij = (st + dr) / 2;
            }
            cout << rez << '\n';
        }
    }

    return 0;
}
