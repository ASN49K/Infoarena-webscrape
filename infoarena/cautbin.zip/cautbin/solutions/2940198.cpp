#include <fstream>
using namespace std;
int v[100005];
int main()
{
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");
    int n,m,cer,x;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    cin>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>cer>>x;
        if(cer<2)
        {
            int st=1,dr=n,retin=0;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]<=x)
                {
                    retin=mij;
                    st=mij+1;
                }
                else
                    dr=mij-1;
            }
            if(cer==1)
            {
                if(v[retin]==x)
                    cout<<retin<<"\n";
                else
                    cout<<"-1\n";
            }
            else
                cout<<retin<<"\n";
        }
        else
        {
            int st=1,dr=n,retin=0;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>=x)
                {
                    retin=mij;
                    dr=mij-1;
                }
                else
                    st=mij+1;
            }
            cout<<retin<<"\n";
        }
    }
    return 0;
}
