#include <fstream>

using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int v[100001];

int cautare(int nr, int n)
{
    int st=1,dr=n,ans=-1;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(v[mij]<=nr){
            ans=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    return ans;
}
int cautare2(int nr, int n){
    int st=1,dr=n,ans=-1;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(v[mij]>=nr){
            ans=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return ans;
}
int main()
{
    int n,m,i;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    cin>>m;
    for(i=1; i<=m; i++){
        int q,x;
        cin>>q>>x;
        if(q==0){
            int ans=cautare(x,n);
            if(v[ans]!=x)
                cout<<-1<<'\n';
            else
                cout<<ans<<'\n';

        }
        if(q==1)
            cout<<cautare(x,n)<<'\n';
        if(q==2)
            cout<<cautare2(x,n)<<'\n';
    }
    return 0;
}
