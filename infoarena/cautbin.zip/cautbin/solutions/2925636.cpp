#include<bits/stdc++.h>
using namespace std;
ifstream F("cautbin.in");
ofstream G("cautbin.out");
int a[100000],n,x,y;
int main()
{
	for(F>>n;x<n;F>>a[x++]);
    for(F>>y;F>>y>>x;G<<'\n')
        if(!y)
            y=upper_bound(a,a+n,x)-a,G<<(y&&a[y-1]==x?y:-1);
        else if(y==1)
            G<<upper_bound(a,a+n,x)-a;
        else
            G<<lower_bound(a,a+n,x)-a+1;
    return 0;
}
