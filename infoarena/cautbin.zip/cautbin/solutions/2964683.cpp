#include <bits/stdc++.h>

using namespace std;

const int N=100000;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

int main()
{
    int n,m,v[N+2],nrint,x;
    in>>n;
    for(int i=1; i<=n; i++)
        in>>v[i];
    in>>m;
    for(int i=1; i<=m; i++)
    {
        in>>nrint>>x;
        if(nrint==0)
        {
            int st,dr,poz,mid;
            st=1;
            dr=n;
            poz=n+1;
            while(st!=dr)
            {
                mid=st+(dr-st)/2;
                if(v[mid]>=x)
                    poz=mid,st=mid+1;
                else dr=mid-1;
            }
            if(v[poz]==x)
                out<<poz;
            else
                out<<-1;
            out<<'/n';
        }
        if(nrint==1)
        {
            int st,dr,poz,mid;
            st=1;
            dr=n;
            poz=n+1;
            while(st!=dr)
            {
                mid=st+(dr-st)/2;
                if(v[mid]==x && st<mid)
                    dr=mid-1;
                else  if(v[mid]>x)
                    st=mid+1;
                    else poz=mid;
            }
            if(v[poz]<=x)
                out<<poz;
            else
                out<<-1;
            out<<'\n';
        }
    }
    return 0;
}
