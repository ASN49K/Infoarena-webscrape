#include<fstream>
using namespace std;
int v[200005],n,x,i,p,m,ras,mij,st,dr;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i];
    fin>>m;
    for(i=1; i<=m; i++)
    {
        fin>>p>>x;
        st=1;
        dr=n;
        ras=-1;
        if(p==0)
        {
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]==x)
                {
                    ras=mij;
                    st=mij+1;
                }
                else if(x>v[mij])
                    st=mij+1;
                else
                    dr=mij-1;
            }
        }


        else
        if(p==1)
        {
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]<=x)
                {
                    ras=mij;
                    st=mij+1;
                }
                else
                    dr=mij-1;
            }

        }


        else
        {
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(v[mij]>=x)
                {
                    ras=mij;
                    dr=mij-1;
                }
                else
                    st=mij+1;
            }
        }
        fout<<ras<<'\n';
    }
    return 0;
}
