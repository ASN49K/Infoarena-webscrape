#include <bits/stdc++.h>

using namespace std;
ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
int n, m;
int cautat[100005];
int c[100005];
int x[100005];
int v[100005];
int main()
{
    cin>>n;
    for (int i=1; i<=n; ++i)
    {
        cin>>v[i];
    }
    cin>>m;
    for (int i=1;i<=m; ++i)
    {
        cautat[i]=-1;
        cin>>c[i]>>x[i];
        if (c[i]==0)
        {
            int st, dr, mijl;
            st=1;
            dr=n;
            while (st<dr)
            {
                mijl=(st+dr)/2;
                if (v[mijl]==x[i])
                {
                    cautat[i]=mijl;
                    st=mijl+1;
                }
                else if (v[mijl]>x[i])
                {
                    dr=mijl-1;
                }
                else if (v[mijl]<x[i])
                {
                    st=mijl+1;
                }
            }
        }
        else if (c[i]==1)
        {
            int st, dr, mijl;
            st=1;
            dr=n;
            while (st<dr)
            {
                mijl=(st+dr)/2;
                if (v[mijl]>x[i])
                {
                    dr=mijl-1;
                }
                else if (v[mijl]<=x[i])
                {
                    cautat[i]=mijl;
                    st=mijl+1;
                }
            }
        }
        else if (c[i]==2)
        {
            int st, dr, mijl;
            st=1;
            dr=n;
            while (st<dr)
            {
                mijl=(st+dr)/2;
                if (v[mijl]>=x[i])
                {
                    cautat[i]=mijl;
                    dr=mijl-1;
                }
                else if (v[mijl]<x[i])
                {
                    st=mijl+1;
                }
            }
            cautat=cautat-1;
        }
    }
    for (int i=1; i<=m; ++i)
    {
        cout<<cautat[i];
    }

    return 0;
}
