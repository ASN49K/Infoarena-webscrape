#include <fstream>

using namespace std;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

long long v[100001];

int CautBin(int st, int dr, long long val)
{
    if (st>dr)
        return -1;
    else
    {
        int mij = (st+dr)/2;
        if (v[mij]==val)
        {
            return mij;
        }
        if (v[mij]>val)
        {
            return CautBin (st,mij,val);
        }
        else
        {
            return CautBin (mij+1,dr,val);
        }
    }
}

int main()
{
    int n,m,c;
    long long val;
    in>>n;
    for (int i=1; i<=n; i++)
    {
        in>>v[i];
    }
    in>>m;
    for (int i=1; i<=m; i++)
    {
        in>>c>>val;
        if (c==0)
        {
            int rez=CautBin(1,n,val);
            while (v[rez+1]==val)
            {
                rez++;
            }
            out<<rez<<'\n';
        }
        else if (c==1)
        {
            int rez=CautBin(1,n,val);
            while (v[rez+1]==val)
            {
                rez++;
            }
            out<<rez<<'\n';
        }
        else if (c==2)
        {
            int rez=CautBin(1,n,val);
            while (v[rez-1]==val)
            {
                rez--;
            }
            out<<rez<<'\n';
        }
    }
    return 0;
}
