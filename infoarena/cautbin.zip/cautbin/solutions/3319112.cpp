#include<bits/stdc++.h>
#define ll long long
#define MAXN 100005
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
ll n, i, v[MAXN], m, c, x;
bool check(ll ind, ll val) {
    if (v[ind]<=val) return 1;
    return 0;
}
ll cautare_binara_cu_pas(ll val) {
    ll sol=0;
    ll x=1;
    ll exp=0;
    while (x<=n) {exp++; x*=2; cout<<exp<<' '<<x<<'\n';}
    for (ll bit=exp; bit>=0; bit--) {
        ll trysol=sol+(1<<bit);
        cout<<trysol<<'\n';
        if (trysol<=n && check(trysol, val)) sol=trysol;
    }
    return sol; /// va returna mereu cel mai mare nr cu proprietatea "stanga" (ex: <=val)
    /// upper_bound()
    /// lower_bound()
}
int main() {
    fin>>n;
    for (i=1; i<=n; i++) fin>>v[i];
    fin>>m;
    for (i=1; i<=m; i++) {
        fin>>c>>x;
        ll cb=cautare_binara_cu_pas(x);
        if (c==0) {
            if (v[cb]==x) fout<<cb<<'\n';
            else fout<<-1<<'\n';
        }
        if (c==1) fout<<cb<<'\n';
        if (c==2) fout<<cb+1<<'\n';
    }
}