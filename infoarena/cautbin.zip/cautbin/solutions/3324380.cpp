#include <bits/stdc++.h>
#define NMAX 100001
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int v[NMAX];

int main() {
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> v[i];

    int m;
    cin >> m;

    for(int q = 0; q < m; q++) {
        int tip, x;
        cin >> tip >> x;

        if(tip == 0) {
            int st = 1, dr = n, r = -1;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] == x) {
                    r = mid;
                    st = mid + 1;
                }
                else if(v[mid] < x)
                    st = mid + 1;
                else dr = mid - 1;
            }
            cout << r << "\n";
        }
        else if(tip == 1) {
            int st = 1, dr = n, r = 0;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] <= x) {
                    r = mid;
                    st = mid + 1;
                }
                else dr = mid - 1;
            }
            cout << r << "\n";
        }
        else if(tip == 2) {
            int st = 1, dr = n, r = n+1;
            while(st <= dr) {
                int mid = st + (dr - st) / 2;
                if(v[mid] >= x) {
                    r = mid;
                    dr = mid - 1;
                }
                else st = mid + 1;
            }
            cout << r << "\n";
        }
    }

    return 0;
}
