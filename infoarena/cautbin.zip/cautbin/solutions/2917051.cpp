#include <iostream>
#include <fstream>

std::ifstream fin("euclid2.in.txt");
std::ofstream fout("euclid2.out.txt");

void cautare_binara_0(int* x, int nr, int number, int st, int dr, int pos) {

	while (st <= dr)
	{
		int mid = st + (dr - st) / 2;

		if (x[mid] == number)
		{
			pos = mid;
			st = mid + 1;
		}
		else if(x[mid] > number)
		{
			dr = mid - 1;
		}
		else
		{
			st = mid + 1;
		}
	}

	fout << pos << "\n";
}

void cautare_binara_1(int* x, int nr, int number, int st, int dr, int pos) {

	while (st <= dr)
	{
		int mid = st + (dr - st) / 2;
		if (x[mid] <= number)
		{
			pos = mid;
			st = mid + 1;
		}
		else
		{
			dr = mid - 1;
		}
	}

	fout << pos << "\n";
}

void cautare_binara_2(int* x, int nr, int number, int st, int dr, int pos) {

	while (st <= dr)
	{
		int mid = st + (dr - st) / 2;
		if (x[mid] < number)
		{
			st = mid + 1;
		}
		else
		{
			pos = mid;
			dr = mid - 1;
		}
	}
	fout << pos;
}

void operations(int* x, int n) {
	int nr;
	int number;

	while (fin >> nr >> number)
	{
		if (nr == 0)
		{
			cautare_binara_0(x, nr, number, 1, n, -1);
		}
		else if (nr == 1)
		{
			cautare_binara_1(x, nr, number, 1, n, -1);
		}
		else
		{
			cautare_binara_2(x, nr, number, 1, n, -1);
		}
	}
}

int main() {
	int n;
	fin >> n;

	int* x = new int[n];

	for (int i = 1; i <= n; i++) {
		fin >> x[i];
	}

	int m;
	fin >> m;

	operations(x, n);

	return 0;
}