#include <bits/stdc++.h>

using namespace std;

ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");

int v[100005];

int FindDr(int x, int n){
    int L = 1,R = n,M;
    while (L<R){
        M = (L+R)/2;
        if (v[M+1]>x){
            R = M;
        }else{
            L = M+1;
        }
    }
    return L;
}

int FindSt(int x, int n){
    int L = 1,R = n,M;
    while (L<R){
        M = (L+R)/2;
        if (v[M]>=x){
            R = M;
        }else{
            L = M+1;
        }
    }
    return L;
}

int main()
{
    int n,m;
    fin >> n;
    for (int i=1;i<=n;++i) fin >> v[i];
    fin >> m;
    for (int i=1;i<=m;++i){
        int t,x,pos;
        fin >> t >> x;
        if (t==0){
            pos = FindDr(x,n);
            if (v[pos]==x) fout << pos;
            else fout << -1;
            fout << '\n';
        }else if (t==1){
            pos = FindDr(x,n);
            fout << pos << '\n';
        }else{
            pos = FindSt(x,n);
            fout << pos << '\n';
        }
    }
    return 0;
}
