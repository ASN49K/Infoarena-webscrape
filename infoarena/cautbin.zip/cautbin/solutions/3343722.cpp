#include<bits/stdc++.h>
using namespace std;
ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
long long int v[1000001],m,n,x,y,vf[1000001];
int main(){
    fin>>n;
    for(int i=1; i<=n; ++i){
        fin>>v[i];
        vf[v[i]]++;
    }
    sort(v+0,v+n+1);
    fin>>m;
    for(int i=1; i<=m; ++i){
        auto *val0= lower_bound(v+0,v+1,v[0]);
        fin>>x>>y;
        if(x==0){
            auto val2= upper_bound(v+0,v+m+1,y)-v;
            if(v[val2]==y)
                fout<<val2<<"\n";
            else
                fout<<-1<<"\n";
        }
        if(x==1){
            auto val2= upper_bound(v+0,v+m+1,y)-v;
            fout<<val2<<"\n";
        }
        if(x==2){
            auto val= lower_bound(v+0,v+m+1,y)-v;
            fout<<val<<"\n";
        }
    }
}