#include <iostream>
#include <fstream>

using namespace std;
ifstream f("cautareb.in");
ofstream g("cautareb.out");

int n, v[100005], m,x,y;

int cautare(int x, int n, int v[100005])
{
    int l = 0, r = n, m, s=-1;
    while (l <= r)
    {
        m = (l + r) / 2;
        if (v[m] == x)
        {
            s = m;
            l++;
        }
        if (v[m] > x)
        {
            r = m - 1;
        }
        if (v[m] < x)
        {
            l = m + 1;
        }
    }
    return s;
}

int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
    }
    
    f >> m;
    for (int i = 1; i <= m; i++)
    {
        f >> x >> y;
        if (x == 0)
        {
            int solmax = -1;
            for (int j = 1; j <= n; j++)
            {
                if (v[j] == y)
                {
                    int s = cautare(y, n, v);
                    if (s >= solmax)
                    {
                        solmax = s;
                    }
                }
            }
            g << solmax;
        }
    }
    
    
}

