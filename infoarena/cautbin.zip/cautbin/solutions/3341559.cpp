#include <fstream>
#include <iostream>
#include <cstdio>

using namespace std;

int v[100001];

int main()
{
    freopen("cautbin.in", "r", stdin);
    freopen("cautbin.out", "w", stdout);

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;
    for (int i=1; i<=n; i++) {
        cin >> v[i];
    }
    int intrebari;
    cin >> intrebari;
    int cerinta, x;
    for (int i=1; i<=intrebari; i++) {
        cin >> cerinta >> x;
        if (cerinta==0) {
            int rasp=0;
            for (int j=(1 << 17); j>=1; j/=2) {
                if (rasp+j<=n && v[rasp+j]<=x) {
                    rasp+=j;
                }
            }
            if (rasp==0 || v[rasp]!=x) cout << -1 << "\n";
            else cout << rasp << "\n";
        }
        if (cerinta==1) {
            int rasp=0;
            for (int j=(1 << 17); j>=1; j/=2) {
                if (rasp+j<=n && v[rasp+j]<=x) {
                    rasp+=j;
                }
            }
            if (rasp==0) cout << -1 << "\n";
            else cout << rasp << "\n";
        }
        if (cerinta==2) {
            int rasp=0;
            for (int j=(1 << 17); j>=1; j/=2) {
                if (rasp+j<=n && v[rasp+j]<x) {
                    rasp+=j;
                }
            }
            if (rasp==0) cout << -1 << "\n";
            else cout << rasp+1 << "\n";
        }
    }
    return 0;
}
