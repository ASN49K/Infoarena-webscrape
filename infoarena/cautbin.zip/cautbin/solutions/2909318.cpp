#include <bits/stdc++.h>
#define M 100001
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[M], q, n;

int cautbin0(int x)
{
  int sol=-1;
  int st=1, dr=n, mij;


  while(st<=dr)
  {
     mij = st + (dr-st)/2;
     if(v[mij] == x)
     {
       sol=mij;
       st = mij+1;
     }
     if(v[mij]>x)
       dr = mij-1;
     if(v[mij]<x)
       st = mij+1;
  }

  return sol;
}

int cautbin1(int x)
{
  int sol=-1;
  int st=1, dr=n, mij;


  while(st<=dr)
  {
     mij = st + (dr-st)/2;
     if(v[mij] <= x)
     {
       sol=mij;
       st = mij+1;
     }
     else
      dr = mij-1;
  }

  return sol;
}

int cautbin2(int x)
{
  int sol=-1;
  int st=1, dr=n, mij;


  while(st<=dr)
  {
     mij = st + (dr-st)/2;
     if(v[mij] >= x)
     {
       sol=mij;
       dr = mij-1;
     }
     else
      st = mij+1;
  }

  return sol;
}


void citire()
{
  fin>>n;
  for(int i=1; i<=n; i++)
    fin>>v[i];
  fin>>q;
}

int main()
{
  citire();

  for(int i=0; i<q; i++)
  {
    int t, x;
    fin>>t>>x;

    if(t==0)
      fout<<cautbin0(x)<<'\n';

    if(t==1)
      fout<<cautbin1(x)<<'\n';

    if(t==2)
      fout<<cautbin2(x)<<'\n';

  }

  return 0;
}
