#include <bits/stdc++.h>
#include <algorithm>
#include <fstream>

using namespace std;
ifstream fin("cautbinara.in");
ofstream fout("cautbinara.out");

int v[100005],n,M;

void citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
}

void cerinta0(int x)
{
    int y = upper_bound(v+1,v+n+1,x)-v-1;
    if(y<=n && y>=1 && v[y]==x)
        fout<<endl<<y;
    else fout<<endl<<-1;
}

void cerinta1(int x)
{
    int y = lower_bound(v+1,v+n+1,x+1)-v-1;
    fout<<y;
}

void cerinta2(int x)
{
    int y = upper_bound(v+1,v+n+1,x-1)-v;
    fout<<y;
}


int main()
{
    fin>>M;
    int i,intr,x;
    for(i=1;i<=M;i++)
    {
        fin>>intr>>x;
        if(intr==0)
            cerinta0(x);
        if(intr==1)
            cerinta1(x);
        if(intr==2)
            cerinta2(x);
    }
    return 0;
}
