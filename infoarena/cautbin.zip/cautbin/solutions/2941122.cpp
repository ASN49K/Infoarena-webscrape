#include <fstream>
#define DIM 100005
using namespace std;
int A[DIM];
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int N,M,cerinta,x;

int main()
{
    cin>>N;
    for(int i=1;i<=N;i++)
        cin>>A[i];
    cin>>M;
    for(int i=1;i<=M;i++)
    {
        cin>>cerinta>>x;
        if(cerinta<2)
        {
            int st=1,dr=N,Poz=0;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(A[mij]<=x)
                {
                    Poz=mij;
                    st=mij+1;
                }
                else
                    dr=mij-1;
            }
            if(cerinta==0)
            {
                if(A[Poz]==x)
                    cout<<Poz<<'\n';
                else
                    cout<<-1<<'\n';
            }
            else
                cout<<Poz<<'\n';
        }
        else
        {
            int st=1,dr=N,Poz=0;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(A[mij]>=x)
                {
                    Poz=mij;
                    dr=mij-1;
                }
                else
                    st=mij+1;
            }
            cout<<Poz<<'\n';
        }
    }
    return 0;
}
