#include <iostream>
#include <fstream>
using namespace std;
ifstream in("cautbin.in");
ofstream out("cautbin.out");
const int maxi = 100000;
int v[maxi+1];
int caut(int nr, int n)
{
    int st=1,dr=n;
    int ans = -1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]<=nr)
        {
            ans = mij;
            st=mij+1;
        }
        else
        {
            dr=mij-1;
        }
    }
    return ans;
}
int caut2(int nr, int n)
{
    int st=1,dr=n;
    int ans = -1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]>=nr)
        {
            ans = mij;
            dr=mij-1;
        }
        else
        {
            st=mij+1;
        }
    }
    return ans;
}
int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n; ++i)
        in>>v[i];
    int m;
    in>>m;
    for(int i=0; i<m; ++i)
    {
        int x, y;
        in>>x>>y;
        if(x==0)
        {
            int ans=caut(y,n);
            if(v[ans]!=y)
                out<<-1<<'\n';
            else
            {
                out<<ans<<'\n';
            }
        }
        else if(x==1)
            out<<caut(y, n)<<'\n';
        else
            out<<caut2(y,n)<<'\n';
    }
    return 0;
}
