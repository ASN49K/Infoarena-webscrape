#include <bits/stdc++.h>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
const int N=1e5+11;
int v[N];
int main()
{
    int n,i,q,t,x,pas,r;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i];
    fin>>q;
    while(q--)
    {
        fin>>t>>x;
        if(t!=2)
        {
            pas=(1<<16);
            r=0;
            while(pas)
            {
                if(r+pas<=n && v[r+pas]<=x)
                    r+=pas;
                pas/=2;
            }
            if(t==2 || v[r]==x)
                fout<<r;
            else
                fout<<-1;
            fout<<'\n';
        }
        else
        {
            pas=(1<<16);
            r=0;
            while(pas)
            {
                if(r+pas<=n && v[r+pas]<x)
                    r+=pas;
                pas/=2;
            }
            fout<<r+1;
            fout<<'\n';
        }
    }
    return 0;
}
