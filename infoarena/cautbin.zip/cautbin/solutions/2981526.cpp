#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100005];

int CautareBinara(int st, int dr, int x, int v[]){
    int ans = -1;
    while(st<=dr){
        int med = (st+dr)/2;

        if(v[med]<=x){
            st = med+1;
            ans = med;
        }
        else{
            dr = med-1;
        }
    }

    return ans;
}

int CMMP(int st, int dr, int x, int v[]){
    int minpoz = 10000;
    while(st<=dr){
        int med = (st+dr)/2;
        if(v[med]>=x){
            dr = med-1;
            minpoz = med;
        }
        else{
            st = med+1;
        }
    }
     return minpoz;

}

int main()
{
    int n;
    fin >> n;
    for(int i = 1;i<=n;i++){
            fin >> v[i];
    }
    int nrop;
    fin >> nrop;
    for(int j = 1;j<=nrop;j++){
        int op,x;
        fin >> op >> x;

        if(op==0){
            int poz = CautareBinara(1, n, x, v);
            if(v[poz]==v[x]){
                fout << poz<<"\n";
            }
            else {
                fout << -1 <<"\n";
            }
        }

        if(op==1){
            int poz = CautareBinara(1, n, x, v);
            fout << poz <<"\n";
        }

        if(op==2){
            int poz = CMMP(1, n, x, v);
            fout << poz <<"\n";
        }
    }

    return 0;
}
