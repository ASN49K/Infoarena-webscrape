#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100001];

int caut_bin1(int val,int st,int dp) {
    int ans=-1;
    while (st<=dp) {
        int med=(st+dp)/2;
        if (v[med]<=val) {
            ans=med;
            st=med+1;
        } else {
            dp=med-1;
        }
    }
    return ans;
}

int caut_bin2(int val,int st,int dp) {
    int ans=-1;
    while (st<=dp) {
        int med=(st+dp)/2;
        if (v[med]>=val) {
            ans=med;
            dp=med-1;
        } else {
            st=med+1;
        }
    }
    return ans;
}

int main() {
    int n,m,i,x,y;

    fin >> n;

    for (i=1;i<=n;i++) {
        fin >> v[i];
    }

    fin >> m;

    while (m) {
        fin >> x >> y;
        int rasp;
        if (x==2) {
            rasp=caut_bin2(y,1,n);
        } else {
            rasp=caut_bin1(y,1,n);
            if (x==0) {
                if (rasp == -1 || v[rasp]!=y) {
                    rasp=-1;
                } 
            }
        }
        fout << rasp << endl;
        m--;
    }
}