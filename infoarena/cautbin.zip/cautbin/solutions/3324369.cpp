#include <iostream>
#include <fstream>
#define NMAX 100000
using namespace std;

int main() {
    // citim vectorul, apoi tipurile + numarul dorit. verificam de care tip de tip este si aplicam algoritmul corespunzator tipului.
    ifstream fin("cautbin.in");
    ofstream fout("cautbin.out");

    int N, M;
    int v[NMAX];

    fin >> N;
    for (int i = 0; i < N; i++)
        fin >> v[i];

    fin >> M;

    while (M--) {
        int tip, x;
        fin >> tip >> x;

        int st, dr, mid, rasp = -1;

        if (tip == 0) {
            st = 0; dr = N - 1;
            while (st <= dr) {
                mid = st + (dr - st) / 2;
                if (v[mid] == x) {
                    rasp = mid + 1;
                    st = mid + 1;
                } else if (v[mid] < x) {
                    st = mid + 1;
                } else {
                    dr = mid - 1;
                }
            }
            fout << rasp << "\n";
        }

        else if (tip == 1) {
            st = 0; dr = N - 1; rasp = 1;
            while (st <= dr) {
                mid = st + (dr - st) / 2;
                if (v[mid] <= x) {
                    rasp = mid + 1;
                    st = mid + 1;
                } else {
                    dr = mid - 1;
                }
            }
            fout << rasp << "\n";
        }

        else if (tip == 2) {
            st = 0; dr = N - 1; rasp = N;
            while (st <= dr) {
                mid = st + (dr - st) / 2;
                if (v[mid] >= x) {
                    rasp = mid + 1;
                    dr = mid - 1;
                } else {
                    st = mid + 1;
                }
            }
            fout << rasp << "\n";
        }
    }

    return 0;
}
