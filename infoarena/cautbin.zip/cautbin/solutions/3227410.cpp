#include<fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100001];

int cautbin1 (int s, int d, int k)
{
    int ans = -1;
    while (s <= d)
    {
        int m = (s + d) / 2;
        if (v[m] <= k) {
            ans = m;
            s = m + 1;
        }
        else
            d = m - 1;
    }
    return ans;
}

int cautbin2 (int s, int d, int k)
{
    int m,ans=-1;
    while (s < d)
    {
        m = (s + d) / 2;
        if (v[m] < k)
        {
            s=m+1;
            ans=s;
        }
        else
        {
            ans=m;
            d=m;
        }
    }
    return ans;
}

int main()
{
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    int m;
    fin>>m;
    while(m--)
    {
        int c,e;
        fin>>c>>e;
        if(c==1)
            fout<<cautbin1(1, n, e)<<'\n';
        if(c==0)
        {
            int ans=cautbin1(1,n,e);
            if(ans==-1 || v[ans]!=e)
                fout<<"-1"<<'\n';
            else
                fout<<ans<<'\n';
        }
        if(c==2)
            fout<<cautbin2(1, n, e)<<'\n';
    }
}
