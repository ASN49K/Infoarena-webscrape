#include <stdio.h>
#include <vector>
#include <algorithm>

int main() {
  FILE *fin = fopen( "cautbin.in", "r" );
  FILE *fout = fopen( "cautbin.out", "w" );

  int n;
  fscanf( fin, "%d", &n );
  std::vector<int> v(n);
  for( int i = 0; i < n; i++ )
    fscanf( fin,"%d", &v[i] );

  int q;
  fscanf( fin, "%d", &q );
  for( int i = 0; i < q; i++ ){
    int task, x;
    fscanf( fin, "%d %d", &task, &x );

    if( task == 0 ){
      int idx = std::upper_bound( v.begin(), v.end(), x ) - v.begin() - 1;
      if( idx < 0 || idx >= n || v[idx] != x )
        fprintf( fout, "-1\n" );
      else
        fprintf( fout, "%d\n", idx + 1 );
      
    }else if( task == 1 ){
      int idx = std::upper_bound( v.begin(), v.end(), x ) - v.begin() - 1;
      if( idx < 0 || idx >= n )
        fprintf( fout, "-1\n" );
      else
        fprintf( fout, "%d\n", idx + 1 );
    }else{
      int idx = std::lower_bound( v.begin(), v.end(), x ) - v.begin();
      if( idx < 0 || idx >= n )
        fprintf( fout, "-1\n" );
      else
        fprintf( fout, "%d\n", idx + 1 );
    }
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
