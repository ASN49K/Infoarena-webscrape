#include <bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[1000001];
int main()
{
    int n,m,a,x,i;
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i];

    fin>>m;
    for(i=1; i<=m; i++) {
        fin>>a>>x;
        if(a==0) {
            auto *val=upper_bound(v+1,v+n+1,x);
            auto val1=*lower_bound(v+1,v+n+1,x);
            if(val1==x)
            fout<<val-v-1<<endl;
            else
            fout<<-1<<endl;
        }
        else if(a==1) {
            auto *val1=upper_bound(v+1,v+n+1,x);
            fout<<val1-v-1<<endl;
        }
        else{
            auto *val=lower_bound(v+1,v+n+1,x);
            fout<<val-v<<endl;
        }
    }
    return 0;
}