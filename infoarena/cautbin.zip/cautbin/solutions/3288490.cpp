#include <stdio.h>
#include <stdint.h>
#include <iostream>

bool valid(int Index, int *arr, int k){
    return(arr[Index] < k);
}

int main(){
    int N, k, acc = 0;
    
    int arr[N];

    std::cout << "Bin: ";
    std::cin >> N;
    std::cout << "arr[] " << std::ends;
    for(int i =0; i < N; i++){
        std::cin >> arr[i];
    }
    std::cout << "k: ";
    std::cin >> k;

    uint8_t cur_pow_2 = 0x00000008;

    while(cur_pow_2 > 0){
        if(valid(acc + cur_pow_2, arr, k)) acc += cur_pow_2;
        cur_pow_2 >> 1;
    }

    return 0;
}