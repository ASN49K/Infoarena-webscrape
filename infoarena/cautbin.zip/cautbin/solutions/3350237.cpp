#include <fstream>
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int n,m,v[100005];

int c0(int x)
{
    int st=1,dr=n,ans=-1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]==x)
        {
            ans=mij;
            st=mij+1;
        }
        else if(v[mij]<x)
            st=mij+1;
        else
            dr=mij-1;
    }
    return ans;
}

int c1(int x)
{
    int st=1,dr=n,ans=0;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]<=x)
        {
            ans=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    return ans;
}

int c2(int x)
{
    int st=1,dr=n,ans=n;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]>=x)
        {
            ans=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return ans;
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];

    cin>>m;

    while(m--)
    {
        int tip,x;
        cin>>tip>>x;

        if(tip==0)
            cout<<c0(x)<<"\n";
        else if(tip==1)
            cout<<c1(x)<<"\n";
        else
            cout<<c2(x)<<"\n";
    }

    return 0;
}
