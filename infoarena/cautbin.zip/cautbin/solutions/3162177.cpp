#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int keres0(int n, int tomb[], int x)
{
    int bal = 0, jobb = n-1;

    while (bal < jobb) {
        int kozep = (bal + jobb + 1) / 2; // jobbra kell húzzon!

        if (tomb[kozep] <= x) {
            bal = kozep;
        }
        else {
            jobb = kozep - 1;
        }
    }

    // it biztos, hogy bal == jobb
    if (tomb[bal] == x)
        return bal;
    else
        return -1;
}

int keres1(int n, int tomb[], int x)
{
    int bal = 0, jobb = n-1;

    while (bal < jobb) {
        int kozep = (bal + jobb + 1) / 2; // jobbra kell húzzon!

        if (tomb[kozep] <= x) {
            bal = kozep;
        }
        else {
            jobb = kozep - 1;
        }
    }

    // it biztos, hogy bal == jobb
    return bal;
}

int keres2(int n, int tomb[], int x)
{
    int bal = 0, jobb = n-1;

    while (bal < jobb) {
        int kozep = (bal + jobb) / 2; // balra kell húzzon!

        if (tomb[kozep] < x) {
            bal = kozep + 1;
        }
        else {
            jobb = kozep;
        }
    }

    // it biztos, hogy bal == jobb
    return bal;
}

int main()
{
    ifstream fin("cautbin.in");
    ofstream fout("cautbin.out");

    int tomb[100000];
    int n;
    fin >> n;

    for (int i = 0; i < n; ++i)
        fin >> tomb[i];

    int m;
    fin >> m;

    for (int kerdes = 0; kerdes < m; ++kerdes) {
        int tipus, x;
        fin >> tipus >> x;

        if (tipus == 0) {
            int poz = keres0(n, tomb, x);
            if (poz == -1)
                fout << "-1\n";
            else
                fout << poz + 1 << "\n";
        }
        else if (tipus == 1) {
            int poz = keres1(n, tomb, x);
            fout << poz + 1 << "\n";
        }
        else {
            int poz = keres2(n, tomb, x);
            fout << poz + 1 << "\n";
        }
    }

    return 0;
}
