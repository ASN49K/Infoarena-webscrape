#include <fstream>
#include <vector>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

vector <int> v(100001, 0);

int n, m;

int cautbin1(int val) {
    int i = -1;
    int step = 1;

    while (step < n)
        step *= 2;

    while (step > 0) {
        if (i + step < n && v[i + step] <= val)
            i += step;
        step /= 2;
    }
    if (i >= 0 && v[i] == val)
        return i;
    return -1;
}

int cautbin2(int val) {
    int i = -1;
    int step = 1;

    while (step < n)
        step *= 2;

    while (step > 0) {
        if (i + step < n && v[i + step] <= val)
            i += step;
        step /= 2;
    }
    return i;
}

int cautbin3(int val) {
    int i = -1;
    int step = 1;

    while (step < n)
        step *= 2;

    while (step > 0) {
        if (i + step < n && v[i + step] < val)
            i += step;
        step /= 2;
    }
    return i;
}

void citirevector()
{
    fin >> n;
    for (int i = 0; i < n; i++)
    {
        fin >> v[i];
    }
}

void rezolvare() {
    fin >> m;
    for (int i = 0; i < m; i++) {
        int t, x;
        fin >> t >> x;

        if (t == 0)
            fout << cautbin1(x) + 1 << "\n";
        else if (t == 1)
            fout << cautbin2(x) + 1 << "\n";
        else
            fout << cautbin3(x) + 2 << "\n";
    }
}

int main() {
    citirevector();
    rezolvare();
    return 0;
}
