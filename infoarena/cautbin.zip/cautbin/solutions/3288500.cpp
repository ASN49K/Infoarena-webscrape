/*
 * https://www.infoarena.ro/problema/cautbin
 */

#include <iostream>
#include <fstream>

#define MAXN 100005

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

void readElements(int& n, int sir[]);
void solveProblem(int n, int sir[]);
int bitBinarySearch(int n, int sir[], int k, int mode);
bool condition(int idx, int sir[], int k);

int main()
{
    int n = 0;
    int sir[MAXN];

    readElements(n, sir);

    //  for (int i = 0; i < n; i++)
    //      std::fout<<sir[i]<<" ";
    //
    // fout<<"\n";

    solveProblem(n, sir);

    // fclose("cautbin.in");
    // fclose("");
    return 0;
}

void readElements(int& n, int sir[])
{
    fin>>n;
    for (int i = 0; i < n; i++)
        fin>>sir[i];
}

void solveProblem(int n, int sir[])
{
    int m, i, qType, qVal, temp;
    fin>>m;

    for (i = 0 ; i < m; i++) {
        fin>>qType>>qVal;

        switch (qType) {
            case 0:
                temp = bitBinarySearch(n, sir, qVal, 1);

                if (i == 13 || i == 14)
                    cout<<temp<<' '<<sir[temp]<<endl;

                if (sir[temp] == qVal)
                    fout<<temp + 1<<'\n';
                else
                    fout<<-1<<'\n';

                break;
            case 1:
                fout<<bitBinarySearch(n, sir, qVal, 1) + 1<<'\n';
                break;
            case 2:
                fout<<bitBinarySearch(n, sir, qVal, 2) + 1<<'\n';
                break;
            default:
                fout<<"unknown operation\n";
                break;
        }
    }
}

int bitBinarySearch(int n, int sir[], int k, int mode)
{
    int acc = 0;

    if (mode == 0){
        int currPow2 = 1;
        while (currPow2 < n)
            currPow2 <<= 1;
        currPow2 >>= 1;
        cout<<currPow2<<endl;

        while (currPow2 > 0) {
            if (acc + currPow2 < n && sir[acc + currPow2] < k) {
                acc += currPow2;
            }
            currPow2 >>= 1;
            cout<<acc<<endl;
        }
    }
    else if (mode == 1) {
        int currPow2 = 1;
        while (currPow2 < n)
            currPow2 <<= 1;
        currPow2 >>= 1;
        cout<<currPow2<<endl;

        while (currPow2 > 0) {
            if (acc + currPow2 < n && sir[acc + currPow2] <= k) {
                acc += currPow2;
            }
            currPow2 >>= 1;
            cout<<acc<<endl;
        }
    }
    else {
        acc = n - 1;
        int currPow2 = 1;
        while (currPow2 < n)
            currPow2 <<= 1;
        currPow2 >>= 1;

        while (currPow2 > 0) {
            if (acc - currPow2 >= 0 && sir[acc - currPow2] >= k) {
                acc -= currPow2;
            }
            currPow2 >>= 1;
        }
    }

    return acc;
}

bool condition(int idx, int sir[], int k)
{
    return sir[idx] < k;
}