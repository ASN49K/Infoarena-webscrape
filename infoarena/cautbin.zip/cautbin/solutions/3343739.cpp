#include<bits/stdc++.h>
using namespace std;
ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
long long int v[1000001],m,n,x,y;
int main(){
    fin>>n;
    for(int i=1; i<=n; ++i){
        fin>>v[i];
    }
    sort(v+0,v+n+1);
    fin>>m;
    for(int i=1; i<=m; ++i){
        fin>>x>>y;
        if(x==0){
            long long int* val2= upper_bound(v+0,v+m+1,y);
            if(v[val2-v-1]==y)
                fout<<val2-v<<"\n";
            else
                fout<<-1<<"\n";
        }
        if(x==1){
            long long int* val2= upper_bound(v+0,v+m+1,y);
            fout<<val2-v<<"\n";
        }
        if(x==2){
            long long int* val= lower_bound(v+0,v+m+1,y);
            fout<<val-v<<"\n";
        }
    }
}