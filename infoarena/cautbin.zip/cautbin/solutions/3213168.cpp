#include <bits/stdc++.h>

using namespace std;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

#define pii pair<int, int>
#define pb push_back
#define fi first
#define se second

const int NMAX = 1e5 + 30;
const int INF = 0x3f3f3f3f;

int n, m, c, x;
vector<int> v;

void read()
{
    in >> n;
    for (int i = 1; i <= n; i++)
        in >> x, v.pb(x);
    in >> m;
}

void solve()
{
    for (int i = 1; i <= m; i++)
    {
        in >> c >> x;
        if (c == 0)
        {
            int le = 0, ri = n - 1, mid, poz = -2;
            while (le <= ri)
            {
                mid = (le + ri) / 2;
                if (v[mid] == x)
                    poz = mid, le = mid + 1;
                else if (v[mid] < x)
                    le = mid + 1;
                else
                    ri = mid - 1;
            }
            out << poz+1 << '\n';
        }
        else if (c == 1)
            out << lower_bound(v.begin(), v.end(), x+1) - v.begin() << '\n';
            //x+1 ca sa fie ultima valoare lui x inainte de x+1 sau chiar x+1 si deci scad 1 (nu scad fiindca se indexeaza de la 0)
        else
            out << upper_bound(v.begin(), v.end(), x-1) - v.begin() + 1 << '\n';
            //x-1 ca sa ia fie primul x, fie ia valoarea mai mare decat x-1 si decat x dar adaugam 1 fiindca indexarea e de la 0
    }
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);

    read();
    solve();

    return 0;
}