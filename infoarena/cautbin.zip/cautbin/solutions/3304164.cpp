#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int recursiv(int a[], int val, int lf, int rg)
{
    int mid = (lf + rg) / 2;
    if (lf > rg)
    {

        return -1;
    }
    if (a[mid] == val)
    {

        if (recursiv(a, val, mid + 1, rg) != -1)
        {
            return recursiv(a, val, mid + 1, rg);
        }
        else
        {
            return mid;
        }
    }
    if (val < a[mid])
    {
        return recursiv(a, val, lf, mid - 1);
    }
    else
    {

        return recursiv(a, val, mid + 1, rg);
    }
}
int recursiv_upb(int a[], int val, int lf, int rg)
{
    int mid = (lf + rg) / 2;
    if (lf > rg)
    {

        return -1;
    }

    if (val >= a[mid])
    {
        return max(mid, recursiv_upb(a, val, mid + 1, rg));
    }
    if (val < a[mid])
    {

        return recursiv_upb(a, val, lf, mid - 1);
    }
}
int recursiv_lwb(int a[], int val, int lf, int rg)
{

    int mid = (lf + rg) / 2;
    if (lf > rg)
    {

        return 100001;
    }
    if (val <= a[mid])
    {

        return min(mid, recursiv_lwb(a, val, lf, mid - 1));
    }
    if (val > a[mid])
    {

        return recursiv_lwb(a, val, mid + 1, rg);
    }
}
int a[100001];
int main()
{
    int n, m;
    fin >> n;
    for (int i = 1; i <= n; i++)
    {

        fin >> a[i];
    }
    fin >> m;
    int op, val;
    for (int i = 1; i <= m; i++)
    {

        cin >> op >> val;
        if (op == 0)
        {

            fout << recursiv(a, val, 1, n);
        }
        if (op == 1)
        {

            fout << recursiv_upb(a, val, 1, n);
        }
        if (op == 2)
        {

            fout << recursiv_lwb(a, val, 1, n);
        }
    }
    return 0;
}