#include <bits/stdc++.h>

using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");
    int v[100001];
int main()
{

    int n, m;
    f>>n;
    //int cnr=-1;
    for(int i=0; i<n; i++){
        int x;
        f>>x;
        //if(x!=cnr)

        v[i]=x;

    }

    f>>m;
    for(int i=1; i<=m; i++){
        int cerinta;
        f>>cerinta;
        if(cerinta==0){
            int x;
            f>>x;
            bool gasit=0;
            int stg=0, dr=n-1;
            while(stg<dr && !gasit){
                int m=(stg+dr)/2;
                if(v[m]==x)
                    if(v[m+1]!=x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        stg=m;
                    }
                if(v[m]!=x)
                    if(v[m-1]==x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        if(v[m]>x)
                            dr=m;
                        else
                            stg=x;
                    }
            }
            if(!gasit)
                 g<<-1<<'\n';
        }
         if(cerinta==1){
            int x;
            f>>x;
            bool gasit=0;
            int stg=0, dr=n-1;
            int m;
            while(stg<dr && !gasit){
                m=(stg+dr)/2;
                if(v[m]==x)
                    if(v[m+1]!=x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        stg=m;
                    }
                if(v[m]!=x)
                    if(v[m-1]==x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        if(v[m]>x)
                            dr=m;
                        else
                            stg=x;
                    }
            }
            if(!gasit)
                 g<<m+1<<'\n';

        }
        if(cerinta==2){
            int x;
            f>>x;
            bool gasit=0;
            int stg=0, dr=n-1;
            while(stg<dr && !gasit){
                int m=(stg+dr)/2;
                if(v[m]==x)
                    if(v[m-1]!=x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        dr=m;
                    }
                if(v[m]!=x)
                    if(v[m+1]==x){
                        g<<m+1<<'\n';
                        gasit=1;
                    }
                    else{
                        if(v[m]>x)
                            dr=m;
                        else
                            stg=x;
                    }
            }
            if(!gasit)
                 g<<-1<<'\n';
        }

    }
    return 0;
}
