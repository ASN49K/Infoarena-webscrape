#include <iostream>
#include <fstream>
using namespace std;

int x[100000];

ifstream in("cautbin.in");
ofstream out("cautbin.out");

int caut_bin_dr(int val, int st, int dr)
{
    int mij=(st+dr)/2, ans=-1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(x[mij]<val)
        {
            st=mij+1;
        }
        else
        {
            ans=mij;
            dr=mij-1;
        }
    }
    return ans;
}

int caut_bin_st(int val, int st, int dr)
{
    int mij=(st+dr)/2, ans=-1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(x[mij]<=val)
        {
            ans=mij;
            st=mij+1;
        }
        else
        {
            dr=mij-1;
        }
    }
    
    return ans;
}

int main()
{
    int n,m, nr_intrebare, val_intrebare, rasp;
    in >> n;
    for(int i=1;i<=n;i++) in >> x[i];
    in >> m;
    while(m)
    {
        in >> nr_intrebare >> val_intrebare;
        switch(nr_intrebare)
        {
            case 0: 
                rasp = caut_bin_st(val_intrebare, 1, n);
                if(x[rasp]==val_intrebare) 
                {
                    out << rasp << endl;
                }
                else out << -1 << endl;
                break;
            case 1:
                out << caut_bin_st(val_intrebare, 1, n) << endl;
                break;
            case 2:
                out << caut_bin_dr(val_intrebare, 1, n) << endl;
                break;
        }
        m--;
    }
}