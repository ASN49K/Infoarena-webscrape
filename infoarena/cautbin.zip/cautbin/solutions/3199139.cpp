#include <fstream>

using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int main()
{
    int n;
    cin >> n;

    int a[100001], i;

    for (i = 1; i <= n; i++) {
        cin >> a[i];
    }

    int m, t, x;
    cin >> m;

    for (i = 1; i <= m; i++) {
        cin >> t >> x;

        if (t == 0) {
            int st, dr, mij, poz;

            st = 1;
            dr = n;
            poz = -1;

            while (st <= dr) {
                mij = (st + dr) / 2;
                if (x == a[mij]) {
                    poz = mij;
                    st = mij + 1;
                }
                else if (x < a[mij]) {
                    dr = mij - 1;
                }
                else {
                    st = mij + 1;
                }
            }

            cout << poz << endl;
        }
        else if (t == 1) {
            int st, dr, mij, poz;

            st = 1;
            dr = n;
            poz = -1;

            while (st <= dr) {
                mij = (st + dr) / 2;
                if (a[mij] <= x) {
                    poz = mij;
                    st = mij + 1;
                }
                else {
                    dr = mij - 1;
                }
            }

            cout << poz << endl;
        }
        else {
            int st, dr, mij, poz;

            st = 1;
            dr = n;
            poz = -1;

            while (st <= dr) {
                mij = (st + dr) / 2;
                if (a[mij] >= x) {
                    poz = mij;
                    dr = mij - 1;
                }
                else {
                    st = mij + 1;
                }
            }

            cout << poz << endl;;
        }
    }

    return 0;
}
