#include <fstream>
using namespace std;

const int NMAX = 100000;

int N, v[NMAX + 1];

ifstream f("cautbin.in");
ofstream g("cautbin.out");

/*
 Cea mai mare pozitie pe care se afla un element cu valoarea x
 sau -1 daca aceasta valoare nu se gaseste in sir.
*/

int caut0(int x)
{
    int st = 1, dr = N, mij, poz = -1;
    while (st <= dr) //nu ne oprim
    {
        mij = (st + dr) / 2;
        if (v[mij] == x)
        {
            poz = mij;
            st = mij + 1;
        }
        else if (v[mij] > x)
            dr = mij - 1;
        else
            st = mij + 1;
    }
    return poz;
}

/*
 Cea mai mare pozitie pe care se afla un element <= x in sir
 Se garanteaza ca cel mai mic numar al sirului este <= x.
*/

int caut1(int x)
{
    int st = 1, dr = N, mij, poz = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (v[mij] <= x)
        {
            poz = mij;
            st = mij + 1;
        }
        else
            dr = mij - 1;
    }
    return poz;
}

/*
 Cea mai mica pozitie pe care se afla un element >= x in sir
 Se garanteaza ca cel mai mare numar din sir este >= x.
*/

int caut2(int x)
{
    int st = 1, dr = N, mij, poz = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (v[mij] >= x)
        {
            poz = mij;
            dr = mij - 1;
        }
        else
            st = mij + 1;
    }
    return poz;
}

int main()
{
    int M, x, t;

    f >> N;
    for (int i = 1; i <= N; i++)
        f >> v[i];

    f >> M;
    while (M--)
    {
        f >> t >> x;
        switch (t)
        {
            case 0:
                g << caut0(x) << '\n';
                break;
            case 1:
                g << caut1(x) << '\n';
                break;
            case 2:
                g << caut2(x) << '\n';
                break;
        }
    }

    f.close();
    g.close();
    return 0;
}
