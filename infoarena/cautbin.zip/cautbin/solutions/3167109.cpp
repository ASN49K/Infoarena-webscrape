#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
int n,i,m,t,x,verif,mid,st,dr,v[10000];
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[n];
    }
    sort(v,v+n+1);
    fin>>m;
    for(i=1;i<=m;i++)
    {
        fin>>t>>x;
        if(t==0)
        {
            verif=0;
            st=0;
            dr=n;
            while(verif==0)
            {
                mid=(st+dr)/2;
                if(v[mid]==x)
                {
                    while(v[mid+1]==x)
                    {
                        mid++;
                    }
                    fout<<mid<<endl;
                    verif=1;
                }
                else if(v[mid]>x)
                {
                    dr=mid;
                }
                else if(v[mid]<x)
                {
                    st=mid;
                }
                if(st>dr)
                {
                    verif=1;
                    fout<<"-1"<<endl;
                }
            }
        }
        if(t==1)
        {
            verif=0;
            st=0;
            dr=n;
            while(verif==0)
            {
                mid=(st+dr)/2;
                if(v[mid]==x)
                {
                    while(v[mid+1]==x)
                    {
                        mid++;
                    }
                    fout<<mid<<endl;
                    verif=1;
                }
                else if(v[mid]>x)
                {
                    dr=mid-1;
                }
                else if(v[mid]<x)
                {
                    st=mid+1;
                }
                if(st>dr)
                {
                    if(v[mid]<x)
                    {
                        fout<<mid<<endl;
                    }
                    else{
                        while(v[mid]>x)
                        {
                            mid--;
                        }
                        fout<<mid<<endl;
                    }
                    verif=1;
                }
            }
        }
        if(t==2)
        {
            verif=0;
            st=0;
            dr=n;
            while(verif==0)
            {
                mid=(st+dr)/2;
                if(v[mid]==x)
                {
                    while(v[mid-1]==x)
                    {
                        mid--;
                    }
                    fout<<mid<<endl;
                    verif=1;
                }
                else if(v[mid]>x)
                {
                    dr=mid;
                }
                else if(v[mid]<x)
                {
                    st=mid;
                }
                if(st>dr)
                {
                    if(v[mid]>x)
                    {
                        fout<<mid<<endl;
                    }
                    else
                    {
                        while(v[mid+1]<x)
                        {
                            mid++;
                        }
                        fout<<mid<<endl;
                    }
                }
            }
        }
    }
    return 0;
}
