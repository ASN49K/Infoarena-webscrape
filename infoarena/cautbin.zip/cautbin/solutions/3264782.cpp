#include <iostream>
#include <fstream>

std::ifstream in("cautbin.in");
std::ofstream out("cautbin.out");

unsigned int v[100000];
int N, M;

void cautbin0(unsigned int x){
  int st = 0, dr = N-1;
  while(st < dr){
    int med = (st + dr) / 2;
    if(v[med] == x){
      while(v[med+1] == x) med++;
      out << med+1 << std::endl;
      return;
    }
    else if(v[med] < x) st = med + 1;
    else dr = st - 1;
  }
   out << -1 << std::endl;
}

void cautbin1(unsigned int x){
  int st = 0, dr = N-1, med;
  while(st < dr){
    med = (st + dr) / 2;
    if(v[med] <= x){
      while(v[med+1] <= x) med++;
      out << med+1 << std::endl;
      return;
    }
    else if(v[med] > x){
      dr = med - 1;
    }
  }
}

void cautbin2(unsigned int x){
  int st = 0, dr = N-1, med;
  while(st < dr){
    med = (st + dr) / 2;
    if(v[med] >= x){
      while(v[med-1] >= x) med--;
      out << med+1 << std::endl;
      return;
    }
    else if(v[med] < x) st = med+1;
  }
}

int main(){
  in >> N;
  for(int i = 0; i<N; i++) in >> v[i];
  in >> M;
  while(M--){
    int caz, x;
    in >> caz >> x;
    if(caz == 0) cautbin0(x);
    if(caz == 1) cautbin1(x);
    if(caz == 2) cautbin2(x);
  }
}
