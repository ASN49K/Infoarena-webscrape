#include <iostream>
#include <fstream>
using namespace std;
int n,x,y,M,i,st,dr,mij,a[100001];
fstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>a[i];
    }
    fin>>M;
    for(i=1;i<=M;i++){
        fin>>x>>y;
        if(x==0){
           st=1;
           dr=n;
           while(st<=dr){
                mij=(st+dr)/2;
                if(a[mij]==y){
                   st=mij+1;
                }
                else if (a[mij]<y){
                    st=mij+1;
                }
                else{
                    dr=mij-1;
                }
           }
           if(a[dr]==y){
            fout<<dr;
           }
           else fout<<-1;
           fout<<endl;
        }
        else if (x==1){
            st=1;
            dr=n;
            while(st<=dr){
                mij=(st+dr)/2;
                if(a[mij]==y){
                    st=mij+1;
                }
                else if(a[mij]<y){
                    st=mij+1;
                }
                else {
                    dr=mij-1;
                }
            }
            fout<<dr;
            fout<<endl;
        }
        else if(x==2){
            st=1;
            dr=n;
            while(st<=dr){
                mij=(st+dr)/2;
                if(a[mij]==y){
                    dr=mij=1;
                }
                else if (a[mij]<y){
                    st=mij+1;
                }
                else{
                    dr=mij-1;
                }
            }
            fout<<st;
            fout<<endl;
        }
    }
    return 0;
}
