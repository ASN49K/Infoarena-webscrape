#include <iostream>
#include <fstream>

using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");
int n;
int v[100005];
int cerinta1(int x)
{
    int st=1;
    int dr=n;
    int mid;
    while(st<=dr)
    {
        mid=(st + dr)/2;
        if(x >= v[mid])
            {
            st=mid+1;

            }
        else
            dr=mid-1;;

    }
    if(v[dr]==x)
        return dr;
    return -1;
}
int cerinta2(int x)
{
    int st=1;
    int dr=n;
    int mid;
    while(st<=dr)
    {   cout<<st<<" "<<dr<<"\n";
        mid=(st + dr)/2;
        if(x >= v[mid])
            {
            st=mid+1;

            }
        else
            dr=mid-1;;

    }
        return dr;

}
int cerinta3(int x)
{
    int st=1;
    int dr=n;
    int mid;
    while(st<=dr)
    {   //cout<<st<<" "<<dr<<"\n";
        mid=(st + dr)/2;
        if(x > v[mid])
            {
            st=mid+1;

            }
        else
            dr=mid-1;;

    }
        return st;
}









int main()
{

    f >> n;

    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
    }
    int m;
    f >> m;
    int a;
    int p;
    for (int i = 1; i <= m; i++)
    {
        f>>a;
        f>>p;
        if(a==0)
            g<<cerinta1(p)<<"\n";
        if(a==1)
            g<<cerinta2(p)<<"\n";
        if(a==2)
            g<<cerinta3(p)<<"\n";

    }


}
