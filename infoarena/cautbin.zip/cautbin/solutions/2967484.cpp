#include <fstream>

using namespace std;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

int v[100001];

int main()
{
    int n, m, q, x;
    in>>n;
    for(int i=1; i<=n; i++)
        in>>v[i];
    in>>m;
    for(int i=0; i<m; i++)
    {
        in>>q>>x;
        if(q==0)
        {
            int st=1, dr=n, pozmax=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]<=x)
                {
                    if(v[m]==x)
                        pozmax=m;
                    st=m+1;
                }
                else
                    dr=m-1;
            }
            out<<pozmax<<"\n";
        }
        if(q==1)
        {
            int st=1, dr=n, pozmax=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]<=x)
                {
                    pozmax=m;
                    st=m+1;
                }
                else
                    dr=m-1;
            }
            out<<pozmax<<"\n";
        }
        if(q==2)
        {
            int st=1, dr=n, pozmax=-1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(v[m]>=x)
                {
                    pozmax=m;
                    dr=m-1;
                }
                else
                    st=m+1;
            }
            out<<pozmax<<"\n";
        }
    }
    return 0;
}
