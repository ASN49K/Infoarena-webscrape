#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int v[100005];
int N, M;

int cer_0(int x) {
    int st = 0, dr = N - 1, ans;
    while (st <= dr) {
        int mij = st + (dr - st) / 2;
        if (v[mij] == x) {
            ans = mij + 1;
            st = mij + 1;
        } else if (v[mij] < x)
            st = mij + 1;
        else
            dr = mij - 1;
    }
    return ans;
}


int cer_1(int x) {
    int st = 0, dr = N - 1, ans;
    while (st <= dr) {
        int mij = st + (dr - st) / 2;
        if (v[mij] <= x) {
            ans = mij + 1;
            st = mij + 1;
        } else
            dr = mij - 1;
    }
    return ans;
}

int cer_2(int x) {
    int st = 0, dr = N - 1, ans;
    while (st <= dr) {
        int mij = st + (dr - st) / 2;
        if (v[mij] >= x) {
            ans = mij + 1;
            dr = mij - 1;
        } else
            st = mij + 1;
    }
    return ans;
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);

    fin >> N;
    for (int i = 0; i < N; i++)
        fin >> v[i];

    fin >> M;
    for (int i = 0; i < M; i++) {
        int cer, x;
        fin >> cer >> x;

        if (cer == 0)
            fout << cer_0(x) << "\n";
        else if (cer == 1)
            fout << cer_1(x) << "\n";
        else if (cer == 2)
            fout << cer_2(x) << "\n";
    }

    return 0;
}
