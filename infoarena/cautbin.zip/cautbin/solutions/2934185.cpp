#include <fstream>
// https://www.infoarena.ro/problema/cautbin?fbclid=IwAR1HlZCcIPABA2kKMwfytr1btlwQsHd1v60IABclFH-E0eFjsgA_mZUj68s
using namespace std;

ifstream cin("cautbin.in");
ofstream cout("cautbin.out");

int main()
{
    int v[10000000002], N;
    cin >> N;
    for(int i = 1; i <= N; i++)
    {
        cin >> v[i];
    }

    int M, nr_in, x, poz_i;
    cin >> M;
    for(int i = 1; i <= M; i++)
    {
        cin >> nr_in >> x;
        switch(nr_in)
        {
        case 0:
            {
            int lo = 1, hi = N, poz_i;
            bool gasit = false;
            while(lo <= hi)
            {
                int mid = lo + (hi - lo ) / 2;
                if(v[mid] == x)
                {
                    poz_i = mid, gasit = true;
                    break;
                }
                if(v[mid] > x)
                    hi = mid - 1;
                if(v[mid] < x)
                    lo = mid + 1;
            }
            if(!gasit)
                return -1;
            for(int i = 1; i <= N; i++)
            {
                if(v[i] == v[poz_i] && i > poz_i)
                    poz_i = i;
            }
            cout << poz_i;
            break;
            }
        case 1 :
            {
            int lo = 1, hi = N, poz_i;
            while(lo <= hi)
            {
                int mid = lo + (hi - lo ) / 2;
                if(v[mid] == x)
                {
                    poz_i = mid;
                    break;
                }
                if(v[mid] > x)
                    hi = mid - 1;
                if(v[mid] < x)
                    lo = mid + 1;
            }
            for(int i = 1; i <= N; i++)
            {
                if(v[i] <= v[poz_i] && i > poz_i)
                    poz_i = i;
            }
            cout << poz_i;
            break;
            }
        case 2:
            {
            int lo = 1, hi = N, poz_i;
            while(lo <= hi)
            {
                int mid = lo + (hi - lo ) / 2;
                if(v[mid] == x)
                {
                    poz_i = mid;
                    break;
                }
                if(v[mid] > x)
                    hi = mid - 1;
                if(v[mid] < x)
                    lo = mid + 1;
            }
            for(int i = 1; i <= N; i++)
            {
                if(v[i] >= v[poz_i] && i < poz_i)
                    poz_i = i;
            }
            cout << poz_i;
            break;
            }
        }
    }
    return 0;
}
