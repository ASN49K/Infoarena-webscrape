/*Se da un sir de numere ordonat crescator cu N elemente, si se cere sa se raspunda la M intrebari de tipul:
0 x - cea mai mare pozitie pe care se afla un element cu valoarea x sau -1 daca aceasta valoare nu se gaseste in sir
1 x - cea mai mare pozitie pe care se afla un element cu valoarea mai mica sau egala cu x in sir. Se garanteaza ca cel mai mic numar al sirului este mai mic sau egal decat x
2 x - cea mai mica pozitie pe care se afla un element cu valoarea mai mare sau egala cu x in sir. Se garanteaza ca cel mai mare numar din sir este mai mare sau egal decat x*/
#include <iostream>
#include <fstream>
using namespace std;
bool valid(int i, int *v,int x)
{
	return (v[i] == x);
}
int main()
{
	int N,M,x, acc = 0, curent_pow_2 = 8, v[100001];
	cout << "N = ";
	cin >> N;
	for (int i = 1; i <= N; i++)
	{
		cin >> v[i];
	}
	cout << "x = ";
	cin >> x;
	while (curent_pow_2>0)
	{
		if (valid(acc + curent_pow_2, v,x))
			acc += curent_pow_2;
		curent_pow_2 >>= 1;
	}
	if (acc == 0)
	{
		cout << -1;
	}
	else
	{
		cout << acc;
	}
	return 0;
}