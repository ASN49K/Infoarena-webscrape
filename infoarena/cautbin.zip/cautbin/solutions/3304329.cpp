#include <iostream>
#include <fstream>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
const int NMAX = 100001;
int v[NMAX];

int main()
{
    int n;
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
    }
    int q;
    f >> q;
    while (q--)
    {
        int tip, x;
        f >> tip >> x;
        if (tip == 0)
        {
            int st = 1, dr = n, /// intervalul in care caut este [st,dr]
            ans = -1;/// ans va tine minte rezultatul cautarii si il initializez cu -1 in cazul in care nu gasesc nimic
            while (st <= dr)
            {
                int mij = (st + dr) / 2;
                if (v[mij] == x) /// am gasit un potential candidat
                {
                    ans = mij; /// il tin minte ca potential raspuns
                    st = mij + 1; /// mut cautarea in dreapta sa vad daca exista un taspuns mai bun
                }
                else if (v[mij] < x) /// am nimerit in stanga lui x
                {
                    st = mij + 1; /// ma mut la dreapta cu cautarea
                }
                else /// if(v[mij] > x) -> sunt in dreapta lui x
                {
                    dr = mij - 1; /// ma mut la stanga cu cautarea
                }
            }
            g << ans << '\n';
        }
        else if (tip == 1)
        {
            int st = 1, dr = n, /// intervalul in care caut este [st,dr]
            ans = -1;/// ans va tine minte rezultatul cautarii si il initializez cu -1 in cazul in care nu gasesc nimic
            while (st <= dr)
            {
                int mij = (st + dr) / 2;
                if (v[mij] <= x) /// am gasit un potential candidat
                {
                    ans = mij; /// il tin minte ca potential raspuns
                    st = mij + 1; /// mut cautarea in dreapta sa vad daca exista un taspuns mai bun
                }
                else /// if(v[mij] > x) -> sunt in dreapta lui x
                {
                    dr = mij - 1; /// ma mut la stanga cu cautarea
                }
            }
            g << ans << '\n';
        }
        else
        {
            int st = 1, dr = n, /// intervalul in care caut este [st,dr]
            ans = -1;/// ans va tine minte rezultatul cautarii si il initializez cu -1 in cazul in care nu gasesc nimic
            while (st <= dr)
            {
                int mij = (st + dr) / 2;
                if (v[mij] >= x) /// am gasit un potential candidat
                {
                    ans = mij; /// il tin minte ca potential raspuns
                    dr = mij - 1; /// mut cautarea in stanga sa vad daca exista un raspuns mai bun
                }
                else /// if(v[mij] < x) -> sunt in stanga lui x
                {
                    st = mij + 1; /// ma mut la dreapta cu cautarea
                }
            }
            g << ans << '\n';
        }
    }
    return 0;
}
