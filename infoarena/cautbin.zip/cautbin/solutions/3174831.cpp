#include <fstream>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX = 1e5 + 1;

int v[NMAX], n, m, q, x;

int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
        fin >> v[i];
    fin >> m;
    for (int i = 1; i <= m; ++i)
    {
        int left = 1, right = n, ans = -1;
        fin >> q >> x;
        if (q == 0)
        {
            while (left <= right)
            {
                int mid = (left + right) / 2;
                // if (v[mid] <= x)
                // {
                //     if (v[mid] == x && ans < mid)
                //         ans = mid;
                //     left = mid + 1;
                // }
                if (v[mid] == x)
                {
                    if (ans < mid)
                        ans = mid;
                    left = mid + 1;
                }
                else if (v[mid] < x)
                    left = mid + 1;
                else
                    right = mid - 1;
            }
        }
        else if (q == 1)
        {
            while (left <= right)
            {
                int mid = (left + right) / 2;
                if (v[mid] <= x)
                {
                    if (ans < mid)
                        ans = mid;
                    left = mid + 1;
                }
                else
                    right = mid - 1;
            }
        }
        else
        {
            ans = n + 1;
            while (left <= right)
            {
                int mid = (left + right) / 2;
                if (v[mid] >= x)
                {
                    if (ans > mid)
                        ans = mid;
                    right = mid - 1;
                }
                else
                    left = mid + 1;
            }
        }
        fout << ans << '\n';
    }
    return 0;
}