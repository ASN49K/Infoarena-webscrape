#include <bits/stdc++.h>
using namespace std;

int n, m;
vector<int> arr;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

void solve0(int num, int left, int right) {
    if (left == right) {
        if (arr[left] != num) {
            fout << -1;
        } else {
            fout << left + 1;
        }
        fout << "\n";
        return;
    }
    int mid = left + (right - left + 1) / 2;
    if (arr[mid] > num) {
        solve0(num, left, mid - 1);
    } else {
        solve0(num, mid, right);
    }
}

void solve1(int num, int left, int right) {
    if (left == right) {
        fout << left + 1;
        return;
    }
    int mid = left + (right - left + 1) / 2;
    if (arr[mid] >= num) {
        solve1(num, left, mid - 1);
    } else {
        solve1(num, mid, right);
    }
}

void solve2(int num, int left, int right, int &pos) {
    if (left > right) {
        fout << pos + 1 << "\n";
        return;
    }
    int mid = left + (right - left + 1) / 2;
    if (arr[mid] >= num) {
        pos = mid;
        solve2(num, left, mid - 1, pos);
    } else {
        solve2(num, mid + 1, right, pos);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    fin >> n;
    arr.resize(n);
    for (int i = 0; i < n; ++i) {
        fin >> arr[i];
    }
    fin >> m;
    while (m--) {
        int op, num;
        fin >> op >> num;
        int pos = -1;
        if (op == 0) {
            solve0(num, 0, n - 1);
        } else if (op == 1) {
            solve1(num, 0, n - 1);
        } else {
            solve2(num, 0, n - 1, pos);
        }
    }
    return 0;
}
