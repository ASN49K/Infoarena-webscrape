#include <fstream>
#include<algorithm>
using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");

int a[100001],n,k,x,y,p;
int main()
{f>>n;
for(int i=1;i<=n;i++)
f>>a[i];
sort(a+1,a+n+1);
f>>k;
for(int i=1;i<=k;i++)
{f>>x>>y;
if(x==0)
  {p=upper_bound(a+1,a+n+1,y)-a-1;
if(p<=n&&p>0&&a[p]==y)
   g<<p<<'\n';
else
    g<<"-1"<<'\n';
  }
if(x==1)
  {p=upper_bound(a+1,a+n+1,y)-a-1;
   g<<p<<'\n';
  }
  if(x==2)
    {p=lower_bound(a+1,a+n+1,y)-a;
   g<<p<<'\n';
  }
}

    return 0;
}
