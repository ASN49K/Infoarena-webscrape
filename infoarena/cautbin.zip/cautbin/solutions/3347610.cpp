#include<bits/stdc++.h>
using namespace std;
string NUME="cautbin";
ifstream fin(NUME+".in");
ofstream fout(NUME+".out");
int v[100005];
int main()
{
    int n,m;
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
    }
    fin>>m;
    int c,a;
    for(int i=1;i<=m;i++){
        fin>>c>>a;
        int rasp=0;
        for(int pas=(1<<17);pas;pas/=2){
            if(pas+rasp<=n){
                if((c==0 || c==1) && v[rasp+pas]<=a){
                    rasp+=pas;
                }else if(c==2 && v[rasp+pas]<a){
                    rasp+=pas;
                }
            }
        }
        if(c==0){
            if(v[rasp]==a)fout<<rasp<<'\n';
            else fout<<-1<<'\n';
        }else if(c==1)fout<<rasp<<'\n';
        else fout<<rasp+1<<'\n';
    }
}
