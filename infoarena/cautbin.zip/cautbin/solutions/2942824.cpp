#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX=1e5+5;
int v[NMAX];

int main()
{
    int n,m;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        fin>>v[i];
    }
    fin>>m;
    for(int i=1;i<=m;i++)
    {
        int op,val;
        fin>>op>>val;
        if(op==0)
        {
            int low=lower_bound(v,v+n,val+1)-v;
            if(v[low-1]==val)
            {
                fout<<low<<endl;
            }
            else
            {
                fout<<-1<<endl;
            }
        }
        else if(op==1)
        {
            int low=lower_bound(v,v+n,val+1)-v;
            fout<<low<<endl;

        }
        else
        {
            int up=upper_bound(v,v+n,val-1)-v;
            if(v[up]==val)
            {
                fout<<up+1<<endl;
            }
            else
            {
                fout<<up<<endl;
            }
        }
    }
    return 0;
}
