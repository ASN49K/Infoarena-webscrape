#include <bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int cb0(int v[], int st, int dr, int target) {
    while(st<=dr) {
        int mij=(st+dr)/2;
        if(v[mij]==target and v[mij+1]!=target) {
            return mij;
        }
        else if(v[mij]==target and v[mij+1]==target) {
            st=mij+1;
        }
        else if (v[mij]>target) {
            dr=mij-1;
        }
        else if(v[mij]<target) {
            st=mij+1;
        }
    }
    return -1;
}
int cb1(int v[], int st, int dr, int target) {
    while(st<=dr) {
        int mij=(st+dr)/2;
        if(v[mij]==target and v[mij+1]!=target) {
            return mij;
        }
        else if(v[mij]==target and v[mij+1]==target) {
            st=mij+1;
        }
        else if(v[mij]>target) {
            dr=mij-1;
        }
        else if(v[mij]<target) {
            st=mij+1;
        }
    }
    return dr;
}
int cb2(int v[], int st, int dr, int target) {
    while(st<=dr) {
        int mij=(st+dr)/2;
        if(v[mij]>=target and !(v[mij-1]>=target)) {
            return mij;
        }
        else if(v[mij]>=target and v[mij-1]>=target) {
            dr=mij-1;
        }
        else if(v[mij]<target) {
        st=mij+1;
        }
    }
    return dr;
}
int main()
{
    int n, v[100005], m;
    fin >> n;
    for(int i=1; i<=n; i++) {
        fin >> v[i];
    }
    fin >> m;
    for(int i=1; i<=m; i++) {
        int nr;
        int target;
        fin >> nr;
        fin >> target;
        if(nr==0) {
            fout << cb0(v, 1, n, target) << endl;
        }
        else if(nr==1) {
            fout << cb1(v, 1, n, target) << endl;
        }
        else if(nr==2) {
            fout << cb2(v, 1, n, target) << endl;
        }
    }
    return 0;
}