#include <iostream>
#include <fstream>
using namespace std;

int bsearch0(int v[], int n, int key)
{
    int p = 0, u = n - 1, m;
    while (p <= u)
    {
        m = (p + u) / 2;
        if (v[m] <= key)
            p = m + 1;
        else
            u = m - 1;
    }
    m = (p + u) / 2;
    if (v[m] > key) m--;
    if (v[m] == key)
        return m;
    return -1;
}

int bsearch1(int v[], int n, int key)
{
    int p = 0, u = n - 1, m;
    while (p < u)
    {
        m = (p + u) / 2;
        if (v[m] <= key)
            p = m + 1;
        else
            u = m;
    }
    m = (p + u) / 2;
    if (v[m] > key)
        m--;
    return m;
}

int bsearch2(int v[], int n, int key)
{
    int p = 0, u = n - 1, m;
    while (p < u)
    {
        m = (p + u) / 2;
        if (v[m] < key)
            p = m + 1;
        else
            u = m;
    }
    m = (p + u) / 2;
    if (v[m] < key)
        m++;
    return m;
}

int main()
{
    int i, n, m, tip, val;
    ifstream fin("cautbin.in");
    ofstream fout("cautbin.out");
    fin >> n;
    int v[n];
    for (i = 0; i < n; ++i)
        fin >> v[i];
    fin >> m;
    while (m--)
    {
        fin >> tip >> val;
        if (tip == 0)
            fout << bsearch0(v, n, val) << endl;
        if (tip == 1)
            fout << bsearch1(v, n, val) << endl;
        if (tip == 2)
            fout << bsearch2(v, n, val) << endl;
    }
    return 0;
}
