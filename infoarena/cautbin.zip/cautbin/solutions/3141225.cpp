#include <bits/stdc++.h>
using namespace std ;
ifstream cin ( "cautbin.in" ) ;
ofstream cout ( "cautbin.out" ) ;
int n ;
int rezolv ( int x , int y , int v[] )
{
    if ( x == 0 )
    {
        int st = 0 , dr = n - 1 ;
        while ( st < dr )
        {
            int mij = ( st + dr ) / 2 ;
            if ( v [ mij ] <= y ) st = mij + 1 ;
            else dr = mij ;
        }
        if ( v [ st - 1 ] == y ) return st ;
        return -1 ;
    }
     if ( x == 1 )
    {
        int st = 0 , dr = n - 1 ;
        while ( st < dr )
        {
            int mij = ( st + dr + 1 ) / 2 ;
            if ( v [ mij ] <= y ) st = mij ;
            else dr = mij - 1;
        }
        if ( v [ dr ] == y ) return dr + 1 ;
        return -1 ;
    }
     if ( x == 2 )
    {
        int st = 0 , dr = n - 1 ;
        while ( st < dr )
        {
            int mij = ( st + dr ) / 2 ;
            if ( v [ mij ] < y ) st = mij + 1 ;
            else dr = mij ;
        }
        if ( v [ st ] == y ) return st + 1 ;
        return -1 ;
    }
}
int main ( )
{
    //freopen( )
    cin >> n ;
    int v [ n ] ;
    for ( int i = 0 ; i < n ; i ++ )
        cin >> v [ i ] ;
    int m ; cin >> m ;
    short intr ; int comp ;
    for ( int i = 0 ; i < m ; i ++ )
    {
        cin >> intr >> comp ;
        cout << rezolv ( intr , comp , v ) << '\n' ;
    }
    return 0 ;
}
/*
#include <fstream>
using namespace std;

ifstream in("cautbin.in");
ofstream out("cautbin.out");

int n, m, p, x;
int a[100'001];

void read()
{
	in >> n;
	for(int i = 1; i <= n; ++i)
		in >> a[i];
	in >> m;
}

int caut(int x)
{
	int index = 0;
	for(int bit = 17; bit >= 0; bit--)
	{
		index += (1<<bit);
		if(index > n || a[index] > x)
			index -= (1<<bit);
	}

	if(a[index] == x)
		return index;
	return -1;
}

int upper_bound(int x)
{
	int index = 0;
	for(int bit = 16; bit >= 0; bit--)
	{
		index += (1<<bit);
		if(index > n || a[index] > x)
			index -= (1<<bit);
	}

	return index;
}

int lower_bound(int x)
{
	int index = 0;
	for(int bit = 16; bit >= 0; bit--)
	{
		index += (1<<bit);
		if(index > n || a[index] >= x)
			index -= (1<<bit);
	}

	return index+1;

}



int main()
{
	read();

	while(m--)
	{
		in >> p >> x;
		if(p == 0) out << caut(x);
		else if(p == 1) out << upper_bound(x);
		else out << lower_bound(x);
		out << '\n';
	}

	return 0;
}
*/
