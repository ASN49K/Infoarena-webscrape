
#include <stdio.h>
#include <stdlib.h>
int v[100000];
int main()
{
    FILE *fin, *fout;
    int t, n, m, i, x, s, dr, mij;
    fin = fopen("cautbin.in", "r");
    fscanf(fin, "%d", &n);
    for (i = 0; i < n; i++) {
        fscanf(fin, "%d", &v[i]);
    }
    fscanf(fin, "%d", &m);
    fout = fopen("cautbin.out", "w");
    for (i = 0; i < m; i++) {
        fscanf(fin, "%d%d", &t, &x);
        if (t != 2) {
            s = 0;
            dr = n;
            while (dr - s > 1) {
                mij = (dr + s) / 2;
                if (v[mij] > x)
                    dr = mij;
                else
                    s = mij;
            }
            if (x == v[s] || t == 1) {
                fprintf(fout, "%d\n", s + 1);
            }
            else {
                fprintf(fout, "-1\n");
            }
        }
        else {
            s = 0;
            dr = n;
            while (dr - s > 1) {
                mij = (dr + s) / 2;
                if (v[mij] < x)
                    s = mij;
                else
                    dr = mij;
            }
            if (x <= v[s]) {
                fprintf(fout, "%d\n", s + 1);
            }
            else {
                fprintf(fout, "%d\n", dr + 1);
            }
        }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
