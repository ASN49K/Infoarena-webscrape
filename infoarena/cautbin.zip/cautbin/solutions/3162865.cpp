#include <iostream>

using namespace std;
int v[100005];
int cautarebinara0(int n, int b){
    int st=1,dr=n,res=-1,mij;
    while(st<=dr){
            mij=(st+dr)/2;
            if(b==v[mij]){
                res=mij;
                st=mij+1;
            }
        else if(b>v[mij])
        st=mij+1;
        else
        dr=mij-1;
    }
    return res;
}
int cautarebinara1(int n, int b){
    int st=1,dr=n,res,mij;
    while(st<=dr){
        mij=(st+dr)/2;
        if(v[mij]<=b){
            res=mij;
            st=mij+1;
        }
        else
        dr=mij-1;
    }
    return res;
}
int cautarebinara2(int n, int b){
    int st=1,dr=n,res,mij;
    while(st<=dr){
        mij=(st+dr)/2;
        if(b<=v[mij]){
            res=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return res;
}
int main()
{
    int n,m;
    int a,b;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    cin>>m;
    for(int i=1;i<=m;i++){
        cin>>a>>b;
        if(a==0)
            cout<<cautarebinara0(n,b)<<'\n';
        else if(a==1)
            cout<<cautarebinara1(n,b)<<'\n';
            else if(a==2)
                cout<<cautarebinara2(n,b)<<'\n';
    }
    return 0;
}