#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int sir[100001];

int cautBin0(int n, int elem) {
    int stanga = 1, dreapta = n;
    while (stanga < dreapta) {
        int m = (stanga + dreapta) / 2;
        if (sir[m] > elem) {
            dreapta = m;
        } else {
            stanga = m + 1;
        }
    }
    if (sir[dreapta] == elem) {
        return dreapta;
    }
    if (sir[stanga - 1] == elem) {
        return stanga - 1;
    }
    return -1;
}

int cautBin1(int n, int elem) {
    int stanga = 1, dreapta = n;
    while (stanga < dreapta) {
        int m = (stanga + dreapta) / 2;
        if (sir[m] > elem) {
            dreapta = m;
        } else {
            stanga = m + 1;
        }
    }
    if (sir[dreapta] <= elem) {
        return dreapta;
    }
    if (dreapta - 1 > 0) {
        return dreapta - 1;
    }
    return 0;
}

int cautBin2(int n, int elem) {
    int stanga = 1, dreapta = n;
    while (stanga < dreapta) {
        int m = (stanga + dreapta) / 2;
        if (sir[m] < elem) {
            stanga = m + 1;
        } else {
            dreapta = m;
        }
    }
    if (sir[stanga] >= elem) {
        return stanga;
    }
    return 0;
}

int main() {
    int n;
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> sir[i];
    }
    int m, intrebare, elem;
    fin >> m;
    for (int i = 1; i <= m; ++i) {
        fin >> intrebare >> elem;
        if (intrebare == 0) {
            fout << cautBin0(n, elem) << "\n";
        }
        if (intrebare == 1) {
            fout << cautBin1(n, elem) << "\n";
        }
        if (intrebare == 2) {
            fout << cautBin2(n, elem) << "\n";
        }
    }
}
