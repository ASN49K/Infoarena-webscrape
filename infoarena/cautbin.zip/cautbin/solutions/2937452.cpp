#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int dim=1e5+2;

int n, v[dim];

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>v[i];

    sort(v+1, v+n+1);

    int op, k, x;

    fin>>k;

    for(int i=1; i<=k; i++)
    {
        fin>>op>>x;

        int poz=-1;

        if(op==0)
        {
            int st=1, dr=n;
            while(st<=dr)
            {
                int m=(st+dr)/2;

                if(v[m]==x)
                    poz=m, st=m+1;
                else if(x>v[m])
                    st=m+1;
                else dr=m-1;
            }
        }
        else if(op==1)
        {
            int st=1, dr=n;
            while(st<=dr)
            {
                int m=(st+dr)/2;

                if(v[m]<=x)
                    poz=m, st=m+1;
                else dr=m-1;
            }
        }
        else
        {
            int st=1, dr=n;
            while(st<=dr)
            {
                int m=(st+dr)/2;

                if(v[m]>=x)
                    poz=m, dr=m-1;
                else st=m+1;
            }
        }

        fout<<poz<<'\n';
    }

    fin.close();
    fout.close();

    return 0;
}
