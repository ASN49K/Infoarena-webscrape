#define FILEIO 1
#if  FILEIO == 1
#include <fstream>
std::ifstream cin("cautbin.in");
std::ofstream cout("cautbin.out");
#else
#include <iostream>
using std::cin;
using std::cout;
#endif // FILEIO
int BinarySearch(const int *v, const int lenght, const int value)
{
    int left=1, right=lenght;
    int middle;
    while(left<=right)
    {
        middle=left+(right-left)/2;
        if(v[middle]==value)
        {
            while (v[middle]==value) middle++;
            return --middle;
        }
        else if(v[middle]<value) left=middle+1;
        else right=middle-1;
    }
    return -1;
}

int BinarySearchGreatestLess(const int *v, const int lenght, const int value)
{
    int left=1, right=lenght;
    int middle, pos=-1;
    while(left<=right)
    {
        middle=left+(right-left)/2;
        if(v[middle]<=value)
        {
            left=middle+1;
            pos=middle;
        }
        else right=middle-1;
    }
    while (v[pos]<=value) pos++;
    return --pos;
}

int BinarySearchLeastGreater(const int *v, const int lenght, const int value)
{
    int left=1, right=lenght;
    int middle, pos=-1;
    while(left<=right)
    {
        middle=left+(right-left)/2;
        if(v[middle]>=value)
        {
            right=middle-1;
            pos=middle;
        }
        else left=middle+1;
    }
    while (pos>=0 && v[pos]>=value) pos--;
    return ++pos;
}
int main()
{
    int n, v[200], x, m, task;
    cin>>n;
    for(int i=1; i<=n; ++i) cin>>v[i];
    cin>>m;
    for(int i=0; i<m; ++i)
    {
        cin>>task>>x;
        switch(task)
        {
        case 0:
        {
            cout<<BinarySearch(v, n, x)<<'\n';
            break;
        }
        case 1:
        {
            cout<<BinarySearchGreatestLess(v, n, x)<<'\n';
            break;
        }
        case 2:
        {
            cout<<BinarySearchLeastGreater(v, n, x)<<'\n';
            break;
        }
        default:
            break;
        }
    }
    return 0;
}
