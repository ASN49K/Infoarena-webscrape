#include <fstream>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
    int v[10005], a[100005], pos[10005], x[10005], pos1[100005];
int main()
{
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
        v[a[i]]++;
        pos[a[i]]=i+1;
        if(pos1[a[i]]==0) pos1[a[i]]=i+1;
        else continue;
    }
    int t, y, b, j, c=0;
    cin>>t;
    for(int i=0; i<t; i++){
        cin>>y>>b;
        if(y==0){
          x[i]=pos[b];
          if(pos[b]==0){
              x[i]=-1;
          }
        }
        else {
                int m;
        for(j=0; j<n; j++){
            if(b>=v[j] && b<=v[j-1]) {
                c=j;
            }
            else continue;
        }
        for(j=0; j<n-1; j++){
            if(b>=v[j] && b<=v[j+1]) {
                m=j;
            }
            else continue;
        }
         if(y==1) x[i]=c;
        else if(y==2) x[i]=pos1[a[m]];
        }
    }
    for(int i=0; i<t; i++) {cout<<x[i]<<"\n";}
}
