#include <iostream>
#include <fstream>
using namespace std;
ifstream f("cautbin.in");
ofstream g("cautbin.out");

int upperBound(int v[], int n, int x)
{
    int left=0;
    int right=n;
    while(left<right)
    {
        int md=(left + right)/2;
        if(v[md]<=x)
        {
            left=md+1;
        }
        else
        {
            right=md;
        }
    }
    return left;
}

int lowerBound(int v[], int n, int x)
{
    int left=0;
    int right=n;
    while(left<right)
    {
        int md=(left+right)/2;
        if(v[md]<x)
        {
            left=md+1;
        }
        else
        {
            right=md;
        }
    }
    return left;
}

int main()
{
    int n, v[100001];
    f>>n;
    for(int i=0; i<n; i++)
    {
        f>>v[i];
    }
    int q;
    f>>q;
    int k, x;
    for(int i=0; i<q; i++)
    {
       f>>k>>x;
       if(k==0)
        {
                int i = upperBound(v, n, x);

            if(i>0 && v[i-1]==x)
            g<<i<<" ";
            else
            g<<-1<<" ";
        }
        if(k==1)
        {
            int i=upperBound(v, n, x);
            g<<i<<" ";
        }
        if(k==2)
        {
            g<<lowerBound(v, n, x) + 1<<" ";
        }
    }

    return 0;
}