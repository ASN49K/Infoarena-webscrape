#include <fstream>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int n,i,j,x,m,st,dr,mid,t,rez;
int v[25010];
int main () {
    cin>>n;
    for (i=1;i<=n;i++) {
        cin>>v[i];
    }
    cin>>m;
    for (i=1;i<=m;i++) {
        cin>>t>>x;
        if (t==0) {
            st=1;
            dr=n;
            while (st<=dr) {
                mid=(st+dr)/2;
                if (v[mid]<=x) {
                    st=mid+1;
                }
                if (v[mid]>x) {
                    dr=mid-1;
                }
            }
            if (v[dr]==x) {
                cout<<dr<<"\n";
            }
            else {
                cout<<"-1"<<"\n";
            }
        }
        if (t==1) {
            st=1;
            dr=5;
            while (st<=dr) {
                mid=(st+dr)/2;
                if (v[mid]<=x) {
                    st=mid+1;
                }
                if (v[mid]>x) {
                    dr=mid-1;
                }
            }
            cout<<dr<<"\n";
        }
        if (t==2) {
            st=1;
            dr=5;
            while (st<=dr) {
                mid=(st+dr)/2;
                if (v[mid]<x) {
                    st=mid+1;
                }
                if (v[mid]>=x) {
                    dr=mid-1;
                }
            }
            cout<<st<<"\n";
        }
    }
}
