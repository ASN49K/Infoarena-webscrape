#include<bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n,v[100005];
int main(){
    fin>>n;
    for(int i=1;i<=n;i++)fin>>v[i];
    int q;
    fin>>q;
    for(int i=1;i<=q;i++){
        int c,x;
        fin>>c>>x;
        if(c==0){
            int st(1),dr(n),mij((st+dr)/2),r(-1);
            while(st<=dr){
                if(v[mij]==x)r=mij,st=mij+1;
                else if(v[mij]<x)st=mij+1;
                else dr=mij-1;
                mij=(st+dr)/2;
            }
            fout<<r<<"\n";
        }
        if(c==1){
            int st(1),dr(n),mij((st+dr)/2),r(-1);
            while(st<=dr){
                if(v[mij]<=x)r=mij,st=mij+1;
                else dr=mij-1;
                mij=(st+dr)/2;
            }
            fout<<r<<"\n";
        }
        if(c==2){
            int st(1),dr(n),mij((st+dr)/2),r(-1);
            while(st<=dr){
                if(v[mij]>=x)r=mij,dr=mij-1;
                else st=mij+1;
                mij=(st+dr)/2;
            }
            fout<<r<<"\n";
        }
    }
    return 0;
}
