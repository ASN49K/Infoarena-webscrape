#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n,v[100001],mij,st=1,dr,M,x;
int main()
{
    fin>>n;dr=n;mij=(st+dr)/2;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    fin>>M;
    int optiune;
    while(fin>>optiune)
    {
        switch(optiune)
        {
        case 0:
            fin>>x;
            for(int i=n;i>=1;i--)
                if(v[i]==x)
                {
                    fout<<i<<endl;break;}
            break;
        case 1:
            fin>>x;
            for(int i=n;i>=1;i--)
                if(v[i]<=x)
                {
                    fout<<i<<endl;break;}
            break;
        case 2:
            fin>>x;
            for(int i=1;i<=n;i++)
                if(v[i]>=x)
                    {
                    fout<<i<<endl;break;}
            break;
        }
    }
    /*while(st<=dr)
    {
        if(v[mij]==numar)
        {
            cout<<mij;
            break;
        }
        if(v[mij]>numar)
        {
            st=mij;
            mij=(st+dr)/2;
        }
        if(v[mij]<numar)
        {
            dr=mij;
            mij=(st+dr)/2;
        }
    }*/
}
