#include <bits/stdc++.h>

using namespace std;

#define GUARD(expr) \
  do {              \
    if (!(expr)) {  \
      return 1;     \
    }               \
  } while (0)

int main() {
#ifndef LOCAL
  freopen("cautbin.in", "r", stdin);
  freopen("cautbin.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  size_t N;
  GUARD(cin >> N && N <= 100'000);
  vector<size_t> X(N);
  for (size_t i = 0; i < N; ++i) {
    GUARD(cin >> X[i] && X[i] < (static_cast<size_t>(1) << 31));
  }
  size_t M;
  GUARD(cin >> M && M <= 100'000);
  for (; M--;) {
    size_t o;
    GUARD(cin >> o && (o == 0 || o == 1 || o == 2));
    size_t x;
    GUARD(cin >> x);
    size_t p = static_cast<size_t>(
        std::distance(X.begin(), lower_bound(X.begin(), X.end(), x)));
    size_t q = static_cast<size_t>(
        std::distance(X.begin(), upper_bound(X.begin(), X.end(), x)));
    if (o == 0 && p == q) {
      cout << (-1);
    } else if (o == 2) {
      cout << (++p);
    } else {
      cout << q;
    }
    cout << '\n';
  }
  return 0;
}