/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>

using namespace std;

int f1(int x,int a[],int N){
    for(int i=N;i>=1;i--){
        if(a[i]==x) return i;
    }
    return -1;
}

int f2(int x,int a[],int N){
    for(int i=N;i>=1;i--){
        if(a[i]<=x) return i;
    }
    return -1;
}

int f3(int x,int a[],int N){
    for(int i=1;i<=N;i++){
        if(a[i]>=x) return i;
    }
    return -1;
}

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main()
{
    int N,M,c,x;
    fin>>N;
    int a[100000];
    for(int i=1;i<=N;i++){
        fin>>a[i];
    }
    fin>>M;
    for(int i=1;i<=M;i++){
        fin>>c>>x;
        if(c==0) fout<<f1(x,a,N)<<endl;
        else if(c==1) fout<<f2(x,a,N)<<endl;
        else fout<<f3(x,a,N)<<endl;
    }
    return 0;
}
