#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n,x,y,i,r,j,cnt,c,p,a,poz1,poz2,poz3,v[100001],st,dr,mijl,q,ok;

int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    fin>>q;
    while(q--)
    {
        fin>>x>>y;
        if(x==0)
        {
            ok=0;
            poz1=0;
            st=1;
            dr=n;
            while(st<=dr)
            {
                mijl=(st+dr)/2;
                if(v[mijl]==y)
                {
                    poz1=mijl;
                    ok=1;
                    st=mijl+1;
                }
                else if(v[mijl]>y)
                {
                    dr=mijl-1;
                }
                else
                {
                    st=mijl+1;
                }

            }
            if(ok)
            {
                fout<<poz1<<'\n';
            }
            else
            {
                fout<<-1<<'\n';
            }
        }
        else if(x==1)
        {
            st=1;
            dr=n;
            poz2=0;
            ok=0;
            while(st<=dr)
            {
                mijl=(st+dr)/2;
                if(v[mijl]<=y)
                {
                    poz2=mijl;
                    ok=1;
                    st=mijl+1;
                }
                else if(v[mijl]>y)
                {
                    dr=mijl-1;
                }

            }
            if(ok)
            {
                fout<<poz2<<'\n';
            }
            else
            {
                fout<<-1<<'\n';
            }
        }
        else
        {
            st=1;
            dr=n;
            poz3=0;
            ok=0;
            while(st<=dr)
            {
                mijl=(st+dr)/2;
                if(v[mijl]>=y)
                {
                    poz3=mijl;
                    ok=1;
                    dr=mijl-1;
                }
                else if(v[mijl]<y)
                {
                    st=mijl+1;
                }

            }
            if(ok)
            {
                fout<<poz3<<'\n';
            }
            else
            {
                fout<<-1<<'\n';
            }
        }
    }
    return 0;
}
