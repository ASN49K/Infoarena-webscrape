#include <bits/stdc++.h>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");

int m, v[100002], tip, x, lung, put, n, i;

int main()
{
    f >> n;

    for (i = 1; i <= n; ++i) {
        f >> v[i];
    }

    for (put = 1; put <= n; put <<= 1) {

    }

    put /= 2;

    f >> m;

    while (m--) {
        f >> tip >> x;

        if (tip < 2) {
            for (i = 0, lung = put; lung; lung >>= 1) {
                if (i + lung <= n && v[i + lung] <= x) {
                    i += lung;
                }
            }
            if (v[i] != x && tip == 0) {
                g << -1 << "\n";
            }
            else {
                g << i << "\n";
            }
        }

        else {
            for (i = n, lung = put; lung; lung >>= 1) {
                if (i - lung > 0 && v[i - lung] >= x) {
                    i -= lung;
                }
            }
            g << i << "\n";
        }
    }

    g.close();

    return 0;
}
