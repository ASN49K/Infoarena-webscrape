#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n,v[100001];
int cautare0(int x){
    int st=1,dr=n;
    int poz=0;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(v[mij]<=x)
            st=mij+1;
        if(v[mij]>x)
            dr=mij-1;
        if(v[mij]==x)
            poz=max(poz,mij);
    }
    if(poz==0)
        return -1;
    else
        return poz;
}
int cautare1(int x){
    int st=1,dr=n;
    int poz=0;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(v[mij]<=x)
            poz=max(poz,mij),st=mij+1;
        else
            dr=mij-1;
    }
    return poz;

}
int cautare2(int x){
    int st=1,dr=n;
    int poz=n+1;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(v[mij]>=x)
            poz=min(poz,mij),dr=mij-1;
        else
            st=mij+1;
    }
    return poz;
}
int main(){
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    int q;
    fin>>q;
    while(q--){
        int cer;
        fin>>cer;
        int x; fin>>x;
        if(cer==0){
            fout<<cautare0(x)<<'\n';
        }
        else if(cer==1)
            fout<<cautare1(x)<<'\n';
        else
            fout<<cautare2(x)<<'\n';
    }
    return 0;
}
