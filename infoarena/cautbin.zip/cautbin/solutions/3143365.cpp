#include <bits/stdc++.h>
using namespace std;

int main()
{
    //ifstream cin("cautbin.in");
    //ofstream cout("cautbin.out");
    cin.tie(0)->sync_with_stdio(0);
    int n, m, c, x;
    cin >> n;
    vector<int> a(n);

    for (int i = 0; i < n; ++i)
        cin >> a[i];

    cin >> m;

    while (m--)
    {
        cin >> c >> x;
        switch (c)
        {
        case 0:
            {
                auto it = upper_bound(a.begin(), a.end(), x);
                int index = it - a.begin();
                cout << index << "\n";
                break;
            }
        case 1:
            {
                auto it = upper_bound(a.begin(), a.end(), x);
                int index = it - a.begin();
                cout << index << "\n";
                break;
            }
        case 2:
            {
                auto it = upper_bound(a.begin(), a.end(), x);
                int index = it - a.begin();
                cout << index + 1 << "\n";
                break;
            }
        }
    }

    return 0;
}
