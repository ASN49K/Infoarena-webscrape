#include <bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n, a[100005];

///cea mai mare poz cu a[i] == x
int CautBin1(int x)
{
    //if(a[1] > x) return -1;
    int p = -1, mijl, st = 1, dr = n;
    while(st <= dr)
    {
        mijl = (st + dr) / 2;
        if(a[mijl] == x)
        {
            p = mijl;
            st = mijl + 1;
        }
        else dr = mijl - 1;
    }
    return p;
}

/// cea mai mare poz cu a[i] <= x
int CautBin2(int x)
{
    int p = -1, mijl, st = 1, dr = n;
    while(st <= dr)
    {
        mijl = (st + dr) / 2;
        if(a[mijl] <= x)
        {
            p = mijl;
            st = mijl + 1;
        }
        else dr = mijl - 1;
    }
    return p;
}

/// cea mai mica poz a[i] >= x
int Cautbin3(int x)
{
    int p = -1, mijl, st = 1, dr = n;
    while(st <= dr)
    {
        mijl = (st + dr) / 2;
        if(a[mijl] >= x)
        {
            p = mijl;
            dr = mijl - 1;
        }
        else st = mijl + 1;
    }
    return p;
}

int main()
{
    int i, task, k, x;
    fin >> n;
    for(i = 1; i <= n; i++)
        fin >> a[i];
    fin >> k;
    for(i = 1; i <= k; i++)
    {
        fin >> task >> x;
        if(task == 0) fout << CautBin1(x) << "\n";
        else if(task == 1) fout << CautBin2(x) << "\n";
        else fout << Cautbin3(x) << "\n";
    }
    return 0;
}
