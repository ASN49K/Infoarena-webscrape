#include<bits/stdc++.h>
using namespace std;
ifstream F("cautbin.in");
ofstream G("cautbin.out");
int i,n,a[100000],j,c;
int main()
{
    for(F>>n;i<n;F>>a[i++]);
    for(F>>c;F>>c>>i;c<2?j=upper_bound(a,a+n,i)-a,G<<(!c&&a[j-1]!=i?-1:j)<<'\n':G<<lower_bound(a,a+n,i)-a+1<<'\n');
    return 0;
}
