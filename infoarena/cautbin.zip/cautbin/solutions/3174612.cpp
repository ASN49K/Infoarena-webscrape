#include <bits/stdc++.h>
using namespace std;
ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");
void
longest_position_same (int x, vector < int >v, int dr)
{
    int st = 0, mij, afs;
    //fout<<dr<<endl;
    while (st != dr)
    {
        mij = (dr + st) / 2;
        //   fout<<mij<<" ";
        if (v[mij] == x)
        {
            while (v[mij] == v[mij + 1])
                mij++;
            fout << mij << endl;
            st = dr;
        }
        else
        {
            if (x > v[mij])
            {
                st = mij;
            }
            else
            {
                dr = mij;
            }
        }
    }
}

void
second_task (int x, vector < int >v, int dr)
{
    int st = 0, mij;
    bool ok = false;
    while (st != dr)
    {
        mij = (st + dr) / 2;
        if (x == v[mij])
        {

            ok = true;
            while (v[mij] == v[mij + 1]){
                mij++;
            }
            st = dr;
            fout << mij << endl;

        } else if (x > v[mij])
        {
            st = mij;
        }
        else
            dr = mij;
    }
    if (ok == false)
    {
        fout << " 5 ";
        fout << mij << endl;
    }
}

int n, m, x, y, z;
vector < int >v;
int main ()
{
    fin >> n;
    for (int i = 0; i < n; i++)
    {
        fin >> z;
        v.push_back (z);
    }
    fin >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        if (x == 0)
        {
            cout<<" 9 ";
            longest_position_same (y, v, n);
        }
        else if (x == 1)
        {
            cout<<" 8 ";
            second_task (y, v, n);
        }

    }
    return 0;
}
