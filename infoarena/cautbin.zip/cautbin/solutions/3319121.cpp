#include <bits/stdc++.h>
using namespace std;

int lg=0;

int v[100005];

int ex(int e, int p)
{
    if(p==0)
    {
        return 1;
    }
    else
    {
        int nr=ex(e, p/2);
        if(p%2==0)
        {
            return nr*nr;
        }
        else
        {
            return nr*nr*e;
        }
    }
}

int main()
{
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");
    int n, q, t, p, sol, tr;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        if((1<<i)>n)
        {
            lg=i-1;
            break;
        }
    }
    for(int i=0; i<n; i++)
    {
        cin>>v[i];
    }
    cin>>q;
    for(int z=0; z<q; z++)
    {
        cin>>t>>p;
        sol=tr=0;
        if(t==0)
        {
            for(int i=lg; i>=0; i--)
            {
                tr = sol+ex(2, i);
                if(tr<n && v[tr]<=p)
                {
                    sol=tr;
                }
            }
            if(v[sol]==p)
            {
                cout<<sol+1<<'\n';
            }
            else
            {
                cout<<"-1\n";
            }
        }
        else if(t==1)
        {
            for(int i=lg; i>=0; i--)
            {
                tr=sol+ex(2, i);
                if(tr<n && v[tr]<=p)
                {
                    sol=tr;
                }
            }
            cout<<sol+1<<'\n';
        }
        else
        {
            p--;
            for(int i=lg; i>=0; i--)
            {
                tr=sol+ex(2, i);
                if(tr<n && v[tr]<=p)
                {
                    sol=tr;
                }
            }
            cout<<sol+2<<'\n';
        }
    }
 
    return 0;
}