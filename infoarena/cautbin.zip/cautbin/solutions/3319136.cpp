#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int dim= 1e5+ 5;
int v[dim];
int n, pm;

int pas_max()
{
    int rez= 0, p= 1;
    while(p <= n)
    {
        p*= 2;
        rez++;
    }
    return rez- 1;
}

int cb(int k, int ce)
{
    int sol= 0;
    int exp= pm;
    int af= 0;
    for(;exp >= 0;exp--)
    {
        int tri= sol+ (1 << exp);
        if(tri > n)continue;
        if(v[tri] <= k)
            sol= tri, af= tri;
    }

    if(ce== 0)
    {
        if(v[af]== k)return af;
        return -1;
    }

    if(ce== 1)
        return af;

    return af+ 1;
}

int main()
{
    int i, j, k, ce;
    fin >> n;

    for(i= 1;i <= n;i++)
        fin >> v[i];

    int q;
    fin >> q;
    pm= pas_max();

    while(q--)
    {
        fin >> ce>> k;

        if(ce== 0)
            fout << cb(k, ce);
        else
        if(ce== 1)
            fout << cb(k, ce);
        else
            fout << cb(k- 1, ce);
        fout << '\n';
    }


    return 0;
}
