#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main() {
    const int MAX_LENGTH = 100000;
    int n, a[MAX_LENGTH + 1];
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> a[i];
    }
    int m;
    fin >> m;
    while (m > 0) {
        int q, x;
        fin >> q >> x;
        if (q == 0) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                if (a[mid] <= x) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
            if (q == 0) {
                if (a[mid] == x) {
                    fout << mid  << "\n";
                } else {
                    fout << -1 << "\n";
                }
            }
        } else if (q == 2) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                if (a[mid] >= x) {
                    right = mid;
                } else {
                    left = mid + 1;
                }
            }
            if (a[right] == x) {
                fout << right << "\n";
            }
        } else if (q == 1) {
            int left = 1, right = n, mid;
            while (left < right) {
                mid = left + (right - left) / 2;
                if (a[mid] <= x) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
            if (left == n && a[left] <= x) {
                fout << left << "\n";
            } else if (a[mid] <= x) {
                fout << mid << "\n";
            }
        }
        --m;
    }
    return 0;
}
