#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main()
{
    int n, m;
    fin>>n;
    int v[n+1];
    for(int i=1; i<=n; i++)fin>>v[i];
    fin>>m;
    for(int i=1; i<=m; i++)
    {
        int o, x;
        fin>>o>>x;
        if(o==0)
        {
            int st=1, dr=n;
            while(st<dr-1)
            {
                long long mij=((long long)st+dr+1)/2;
                if(v[mij]<=x)st=mij;
                else dr=mij-1;
            }
            if(v[st]==x)fout<<st<<'\n';
            else fout<<"-1\n";
        }
        if(o==1)
        {
            int st=1, dr=n;
            while(st<dr-1)
            {
                long long mij=((long long)st+dr+1)/2;
                if(v[mij]<=x)st=mij;
                else dr=mij-1;
            }
            fout<<st<<'\n';
        }
        if(o==2)
        {
            int st=1, dr=n;
            while(st<dr)
            {
                long long mij=((long long)st+dr)/2;
                if(v[mij]<x)st=mij+1;
                else dr=mij;
            }
            fout<<st<<'\n';
        }
    }
    return 0;
}
