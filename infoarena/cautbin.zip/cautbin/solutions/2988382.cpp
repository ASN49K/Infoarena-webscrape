#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n,m,v[100005],a,x,nr;

int main()
{
    fin>>n;
    for(int i=1;i<=n;++i)
        fin>>v[i];
    fin>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>x>>nr;
        if(x==0)
        {
            a=upper_bound(v+1,v+n+1,nr)-v-1;
            if(v[a]==nr)
                fout<<a<<'\n';
            else
                fout<<"-1\n";
        }else if(x==1)
        {
            a=lower_bound(v+1,v+n+1,nr+1)-v-1;
            fout<<a<<'\n';
        }else
        {
            a=upper_bound(v+1,v+n+1,nr-1)-v;
            fout<<a<<'\n';
        }
    }
    return 0;
}
