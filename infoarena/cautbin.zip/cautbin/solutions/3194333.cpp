#include <iostream>
#include <fstream>
#include <string.h>
#include <cmath>
using namespace std;

int v[100001];
int lower_bound(int val,int st,int dr)
{
    int sol=-1;
    while(st<=dr)
    {
        int med=(st+dr)/2;
        if(v[med]<=val)
        {
            sol=med;
            st=med+1;
        }
        else
            dr=med-1;
     }
    return sol;
}
int upper_bound(int val,int st,int dr)
{
    int sol=-1;
    while(st<=dr)
    {
        int med=(st+dr)/2;
        if(v[med]<val)
            st=med+1;
        else
        {
            sol=med;
            dr=med-1;
        }
     }
    return sol;
}
int main()
{
    ifstream f("cautbin.in");
    ofstream g("cautbin.out");
    int N,M;
    f>>N;
    for(int i=1;i<=N;i++)
        f>>v[i];
    f>>M;
    for(int rand=1;rand<=M;rand++)
    {
        int cerinta,val;
        f>>cerinta;
        f>>val;
        if(cerinta==0)
        {
            int poz=lower_bound(val,1,N);
            if(poz=-1)
                g<<poz<<"\n";
            else(v[poz]==val)
                g<<poz<<"\n";
        }
        if(cerinta==1)
        {
            g<<lower_bound(val,1,N)<<"\n";
        }
        if(cerinta==2)
        {
            g<<upper_bound(val,1,N)<<"\n";
        }
    }
    return 0;
}
