#include <iostream>
#include <string>
#include <cstdio>
#include <algorithm>
#include <numeric>
#include <fstream>

using namespace std;

ifstream f("cautbin.in");
ofstream g("cautbin.out");
int n, v[100005], k=0, x, m, tip;
int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++) {
        f >> v[i];
    }
    f >> m;
    for(int i = 1; i <= m; i ++) {
        f >> tip >> x;
        if(tip == 0) {
            int p = 1 << 30, r = 0;
            while(p != 0) {
                if(r + p <= n && v[r + p] <= x)
                    r += p;
                p /= 2;
            }
            if(v[r] != x)
                g << -1 << '\n';
            else
                g << r << '\n';
        } else if(tip == 1) {
            int p = 1 << 30, r = 0;
            while(p != 0) {
                if(r + p <= n && v[r + p] <= x)
                    r += p;
                p /= 2;
            }
            g << r << '\n';
        } else if(tip == 2) {
            int p = 1 << 30, r = 0;
            while(p != 0) {
                if(r + p <= n && v[r + p] < x)
                    r += p;
                p /= 2;
            }
            r++;
            g << r << '\n';
        }
    }
    f.close(); g.close();
    return 0;
}