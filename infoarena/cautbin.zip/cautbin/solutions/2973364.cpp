#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int main(){
    unsigned int n, m, id[10], x, v[100001];
    int r=0, i;
    fin >> n;
    for(i=1;i<=n;i++) fin >> v[i];

    fin >> m;

    for(i=1;i<=m;i++) fin >> id[m] >> x;


    for(i=1;i<=n;i++){
        if(v[i] == x)   r=i;
        else if(v[i] != x && r == 0)  r=-1;
    }

    fout << r;

    return 0;
}