
#include <fstream>


using namespace std;

ifstream fin("cautbinar.in");
ofstream fout("cautbinar.out");
const int N = 1e5;

int a[N], n;
inline int cb0( int n, int x) {
    int st = 0;
    int dr = n - 1;
    int rez = -1;

    while (st <= dr) {
        int mij = (st + dr) / 2;
        if (a[mij] <= x) {
            rez = mij;
            st = mij + 1;
        } else {
            dr = mij - 1;
        }
    }
    if (rez == -1 || a[rez] != x) {
        return -1;
    } else {
        return rez + 1;
    }
}

inline int cb2(int n, int x) {
    int st = 0;
    int dr = n - 1;
    int rez = -1;

    while (st <= dr) {
        int mij = (st + dr) / 2;
        if (a[mij] >= x) {
            rez = mij;
            dr = mij - 1;
        } else {
            st = mij + 1;
        }
    }
    if (rez == -1 || a[rez] != x) {
        return -1;
    } else {
        return rez + 1;
    }
}

int main() {
    int n;
    fin >> n;

    for (int i = 0; i < n; ++i) {
        fin >> a[i];
    }

    int q;
    fin >> q;

    while (q--) {
        short cerr;
        int x;
        fin >> cerr >> x;
        if (cerr == 0 || cerr == 1) {
            fout << cb0(n, x) << '\n';
        } else {
            fout << cb2(n, x) << '\n';
        }
    }

    return 0;
}
