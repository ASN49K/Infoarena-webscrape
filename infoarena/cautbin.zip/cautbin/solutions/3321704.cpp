
#include <fstream>

using namespace std;

#define N 100000

int v[N+1];

int main()
{
    ifstream cin ("cautbin.in");
    ofstream cout ("cautbin.out");

    int n, i, m, cer, a, st, dr, mij;

    cin >> n;
    for (i=0; i<n; i++)
        cin >> v[i];
    cin >> m;

    for (i=0; i<m; i++){
        cin >> cer >> a;
        if (cer == 2){
            st = -1;
            dr = n-1;
            while (dr - st > 1){
                mij = (st+dr) / 2;
                if (v[mij] < a)
                    st = mij;
                else
                    dr = mij;
            }
            cout << dr + 1 << '\n';
        }else{
            st = 0;
            dr = n;
            while (dr - st > 1){
                mij = (st+dr) / 2;
                if (v[mij] > a)
                    dr = mij;
                else
                    st = mij;
            }

            if (cer == 1)
                cout << st + 1 << '\n';
            else{
                if (a == v[st])
                    cout << st + 1 << '\n';
                else
                    cout << -1 << '\n';
            }
        }
    }

    return 0;
}
