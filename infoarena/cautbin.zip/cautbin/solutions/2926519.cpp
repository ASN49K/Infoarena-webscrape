#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int n, a[100001], m, q, x;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++i)
        fin >> a[i];
    fin >> m;
    while(m)
    {
        fin >> q >> x;
        int st = 1, dr = n;
        if(q == 0)
        {
            while(st <= dr)
            {
                int m = (st + dr) / 2;
                if(a[m] > x)
                    dr = m - 1;
                else if(a[m] <= x)
                    st = m + 1;
            }
            if(a[dr] == x)
                fout << dr << '\n';
            else
                fout << -1 << '\n';
        }
        else if(q == 1)
        {
            while(st <= dr)
            {
                int m = (st + dr) / 2;
                if(a[m] > x)
                    dr = m - 1;
                else
                    st = m + 1;
            }
            fout << dr << '\n';
        }
        else
        {
            while(st <= dr)
            {
                int m = (st + dr) / 2;
                if(a[m] >= x)
                    dr = m - 1;
                else
                    st = m + 1;
            }
            fout << st << '\n';
        }
        m--;
    }
    return 0;
}
