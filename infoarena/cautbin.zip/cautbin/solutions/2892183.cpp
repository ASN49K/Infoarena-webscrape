#include <bits/stdc++.h>

using namespace std;

const string fisier = "file";

ifstream fin (fisier + ".in");
ofstream fout (fisier + ".out");

const int N_MAX = 1e5 + 5;

int v[N_MAX];

void test_case(){
  int n; fin >> n;
  for (int i=1; i<=n; i++){
    fin >> v[i];
  }
  sort(v + 1 , v + n + 1);
  int q; fin >> q;
  while (q--){
    int task , x; fin >> task >> x;
    if (task == 0){
      int p = upper_bound(v + 1 , v + n + 1 , x) - v - 1;
      if (p > 0 && p <= n && v[p] == x){
        fout << p << '\n';
      }
      else{
        fout << -1 << '\n';
      }
    }
    else if (task == 1){
      int p = upper_bound(v + 1 , v + n + 1 , x) - v - 1;
      fout << p << '\n';
    }
    else{
      int p = lower_bound(v + 1 , v + n + 1 , x) - v;
      fout << p << '\n';
    }
  }
}

int main(){
  ios_base::sync_with_stdio(false);
  int tests = 1;
  for (int tc=0; tc<tests; ++tc){
    test_case();
  }
}
