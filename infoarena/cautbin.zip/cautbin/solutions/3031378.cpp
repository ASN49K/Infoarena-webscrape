#include <iostream>
#include <cstring>
#include <algorithm>
#include <stack>
#include <fstream>
#define ll long long
using namespace std;

ll v[100010];
int n;

ofstream g("cautbin.out");
ifstream f("cautbin.in");

int cb1(int x)
{
    int poz;
    int st = 1;
    int dr = n;
    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(v[mij] <= x)
        {
            st = mij + 1;
            poz = mij;
        }
        else
            dr = mij - 1;
    }
    return poz;
}

int cb2(int x)
{
    int poz;
    int st = 1;
    int dr = n;
    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(v[mij] >= x)
        {
            dr = mij - 1;
            poz = mij;
        }
        else 
            st = mij + 1;
    }
    return poz;
}

int main()
{
    f >> n;
    for(int i = 1; i <= n; ++i)
        f >> v[i];
    int m;
    f >> m;
    for(int i = 0; i < m; ++i)
    {
        ll x, y;
        f >> x >> y;
        if(x == 0)
        {
            int poz = cb1(y);
            if(v[poz] == y)
                g << poz;
            else 
                g << -1;
        }
        else if(x == 1)
            g << cb1(y);
        else 
            g << cb2(y);
        g << '\n';
    }
    return 0;
}