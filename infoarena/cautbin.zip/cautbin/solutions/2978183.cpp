#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
string np = "cautbin";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

ll n, v[100003];

ll cb(ll cer, ll x);
int main()
{
    f >> n;
    for (ll i = 1; i <= n; i++)
        f >> v[i];

    ll t;
    f >> t;
    while (t--)
    {
        ll cer, x;
        f >> cer >> x;
        g << cb(cer, x) << '\n';
    }

    return 0;
}
ll cb(ll cer, ll x)
{
    ll st = 0, dr = n - 1, rez = -1;
    if (cer == 0)
    {
        while (st <= dr)
        {
            ll mid = (st + dr) / 2;
            if (v[mid] == x)
                rez = mid, st = mid + 1;
            else
                dr = mid - 1;
        }
        return rez;
    }
    else if (cer == 1)
    {
        while (st <= dr)
        {
            ll mid = (st + dr) / 2;
            if (v[mid] <= x)
                rez = mid, st = mid + 1;
            else
                dr = mid - 1;
        }
        return rez;
    }
    else
    {
        while (st <= dr)
        {
            ll mid = (st + dr) / 2;
            if (v[mid] >= x)
                rez = mid, dr = mid - 1;
            else
                st = mid + 1;
        }
        return rez;
    }
}