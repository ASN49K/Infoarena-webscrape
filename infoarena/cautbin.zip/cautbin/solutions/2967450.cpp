#include <fstream>

using namespace std;

const int N = 100000;

int x[1+N], lung[1+N],nr[1+N];

ifstream in("subsiruri.in");
ofstream out("subsiruri.out");

int main()
{
    int n, pmax = 1,ap=0;
    in >> n;
    for (int i = 1; i <= n; i++)
    {
        in >> x[i];
        int l_j = 0;
        nr[i]=1;
        for (int j = 1; j < i; j++)
        {
            if (x[j] < x[i])
            {
                if(lung[j]>l_j)
                {
                    l_j=lung[j];
                    nr[i]=nr[j];
                }
                else if(lung[j]==l_j)
                    nr[i]=(nr[i] + nr[j]) % 9901;
            }
        }
        lung[i] = 1 + l_j;
        if (lung[i] > lung[pmax])
        {
            pmax = i;
        }
    }
    out << lung[pmax] << "\n";
        for (int i = 1; i <= n; ++i) {
        if (lung[i] == lung[pmax]) {
            ap = (ap + nr[i]) % 9901;
        }
    }
    out << ap;

    in.close();
    out.close();
    return 0;
}
