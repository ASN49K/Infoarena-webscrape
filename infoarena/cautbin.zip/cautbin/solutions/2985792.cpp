#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n, x, m;
vector<int> a;

int main()
{
    fin >> n;
    for (int i = 0 ; i < n; i++)
    {
        int temp;
        fin >> temp;
        a.push_back(temp);
    }
    fin >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        if (x == 0)
        {
            int up = *upper_bound(a.begin(), a.end(), y) - 1;
            if (up == -1 || a[up - 1] != y)
            {
                fout << -1 << '\n';
            }
            else
            {
                fout << up << '\n';
            }
        }
        else if (x == 1)
        {
            int up = *upper_bound(a.begin(), a.end(), y) - 1;
            if (up != -1)
            {
                if (a[up - 1] == y)
                    fout << up << '\n';
                else
                    fout << up + 1 << '\n';
            }
            else
            {
                fout << up + 1 << '\n';
            }
        }
        else
        {
            fout << a[*lower_bound(a.begin(), a.end(), y)] << '\n';
        }
    }
    return 0;
}
