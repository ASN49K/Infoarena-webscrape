#include <fstream>
using namespace std;

int v[100001];
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int cautare_binara(int val,int n)
{
    int ans=1;
    int st=1;
    int dr=n;
    while(st<=dr)
    {
        long long m=(st+dr)/2;
        if(v[m]<=val)
        {
            ans=m;
            st=m+1;
        }
        else
            dr=m-1;
    }
    return ans;
}
int cautare_binara2(int val,int n)
{
    int ans=1;
    int st=1;
    int dr=n;
    while(st<=dr)
    {
        long long m=(st+dr)/2;
        if(v[m]>=val)
        {
            ans=m;
            dr=m-1;
        }
        else
            st=m+1;
    }
    return ans;
}
int main()
{
    int n,m;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
    }
    cin>>m;
    for(int j=1; j<=m; j++)
    {
        int q,x;
        cin>>q>>x;
        if(q==0)
            if(v[cautare_binara(x,n)]!=x)
                cout<<-1<<'\n';
            else
                cout<<cautare_binara(x,n)<<'\n';
        else if(q==1)
                cout<<cautare_binara(x,n)<<'\n';
        else
            cout<<cautare_binara2(x,n)<<'\n';

    }
    return 0;
}
