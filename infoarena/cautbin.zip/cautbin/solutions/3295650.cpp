#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

int CautBin0(int x, vector<int> &v, int st, int dr) {
	// eu vreau cea mai mare pozitie
	int poz = -1;
	while (dr >= st) {
		int mid = st + (dr - st) / 2;
		if (v[mid] == x) {
			poz = mid;
			st = mid + 1;
			// ma mut mai la drepta
		}
		if (v[mid] > x) {
			// caut la stanga
			dr = mid - 1;
		}
		if (v[mid] < x) {
			// caut la dreapta
			st = mid + 1;
		}
	}
	return poz;
}

int CautBin1(int x, vector<int> &v, int st, int dr) {
	// cea mai mare pozitie pe care se afla un elem cu val <= x
	int poz = -1;
	while (dr >= st) {
		int mid = st + (dr - st) / 2;
		if (v[mid] <= x) {
			poz = mid;
			st = mid + 1;
		}
		if (v[mid] > x) {
			// caut la stanga
			dr = mid - 1;
		}
	}
	return poz;
}

int CautBin2(int x, vector<int> &v, int st, int dr) {
	// cea mai mica pozitie pe care se afla un elem cu val >= x
	int poz;
	while (dr >= st) {
		int mid = st + (dr - st) / 2;
		if (v[mid] >= x) {
			poz = mid;
			dr = mid - 1;
		}
		if (v[mid] < x) {
			// caut la dreapta
			st = mid + 1;
		}
	}
	return poz;
}

int main() {
	freopen("cautbin.in", "r", stdin);
	freopen("cautbin.out", "w", stdout);

	int N, M, x;
	// citim N
	cin >> N;
	vector<int> v(N);

	for(int i = 0; i < N; i++) {
		cin >> v[i];
	}

	cin >> M;

	int a, b;
	// citim "intrebarile"
	// 0 cea mai mare pozitie pe care se afla un elem cu val x sau -1
	// 1 cea mai mare pozitie pe care se afla un elem cu val <= x
	// 2 cea mai mica pozitie pe care se afla un elem cu val >= x
	int result;
	for(int i = 0; i < M; i++) {
		cin >> a >> x;
		if (a == 0) {
			result = CautBin0(x, v, 0, N-1);
		}
		if (a == 1) {
			result = CautBin1(x, v, 0, N-1);
		}
		if (a == 2) {
			result = CautBin2(x, v, 0, N-1);
		}
		if (result != -1) {
			result++;
		}
		cout << result<< endl;
	}

	return 0;
}