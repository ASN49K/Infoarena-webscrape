#include <bits/stdc++.h>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int sir[100001], n, m, i, number, value, stanga, dreapta;

int intrebare1(int x){
    stanga = 1;
    dreapta = n;
    int raspuns = -1;
    while(stanga <= dreapta){
        int mij = (stanga + dreapta)/2;
        if(sir[mij] <= x){
            if(sir[mij] == x) raspuns = mij;
            stanga = mij + 1;
        } else dreapta = mij - 1;
    }

    return raspuns;
}

int intrebare2(int x){
    stanga = 1;
    dreapta = n;
    int raspuns = -1;
    while(stanga <= dreapta){
        int mij = (stanga + dreapta)/2;
        if(sir[mij] <= x){
            raspuns = mij;
            stanga = mij + 1;
        } else dreapta = mij - 1;
    }

    return raspuns;
}

int intrebare3(int x){
    stanga = 1;
    dreapta = n;
    int raspuns = -1;
    while(stanga <= dreapta){
        int mij = (stanga + dreapta)/2;
        if(sir[mij] >= x){
            raspuns = mij;
            dreapta = mij - 1;
        } else stanga = mij + 1;
    } 
    return raspuns;
}

int main(){   
    fin >> n;
    for(i=1;i<=n;++i) fin >> sir[i];

    fin >> m;
    for(i=1;i<=m;++i){
        fin >> number >> value;
        if(number == 0) fout << intrebare1(value) << endl;
        else if(number == 1) fout << intrebare2(value) << endl;
        else if(number == 2) fout << intrebare3(value) << endl;
    }

    return 0;
}

