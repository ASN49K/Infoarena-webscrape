#include <fstream>
#include <vector>
using namespace std;
vector <int> v;
int main(){
	int n, q, i, tip, x, poz, st, dr, mij;
	ifstream fin( "cautbin.in" );
	ofstream fout( "cautbin.out" );
	fin >> n;
	for( i = 0; i < n; i++ ){
		fin >> x;
		v.push_back( x );
	}
	fin >> q;
	for( i = 0; i < q; i++ ){
		fin >> tip >> x;
		if( tip == 0 || tip == 1 ){
			st = 0;
			dr = n;
			while( dr - st > 1 ){
				mij = ( st + dr ) / 2;
				if( v[mij] > x ){
					dr = mij;
				}
				else{
					st = mij;
				}
			}
			if( tip == 0 && v[st] != x ){
				fout << "-1\n";
			}
			else{
				fout << st + 1 << '\n';
			}
		}
		else if( tip == 2 ){
			fout << lower_bound( v.begin(), v.end(), x ) - v.begin() + 1 << '\n';
		}
	}
	return 0;
}