#include<fstream>
#include<algorithm>
using namespace std;
ifstream cin("cautbin.in");
ofstream cout("cautbin.out");
int a[100000];
int main()
{
    int m,n;
    cin>>n;
    for(int i=0;i<n;cin>>a[i++]);
    for(cin>>m;m--;) {
        int i,j,k;
        cin>>i>>j,i<2?k=upper_bound(a,a+n,j)-a,cout<<(!i&&a[k-1]!=j?-1:k)<<'\n':cout<<lower_bound(a,a+n,j)-a+1<<'\n';
    }
    return 0;
}
