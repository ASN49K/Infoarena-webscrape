#include <stdio.h>

const int MAXN = 1e5;

int v[MAXN];

int main(){
  FILE *fin = fopen( "cautbin.in", "r" );
  FILE *fout = fopen( "cautbin.out", "w" );

  int n, q, i, task, a, st, dr, mij;

  fscanf( fin, "%d", &n );
  for( i = 0 ; i < n ; i++ )
    fscanf( fin, "%d", v + i );

  for( fscanf( fin, "%d", &q ) ; q-- ; ){
    fscanf( fin, "%d%d", &task, &a );

    if( task == 0 ){
      st = 0;
      dr = n;

      while( dr - st > 1 ){
        if( v[mij = (st + dr) >> 1] > a )
          dr = mij;
        else
          st = mij;
      }

      if( v[st] == a )
        fprintf( fout, "%d\n", 1 + st );
      else
        fputs( "-1\n", fout );
    }else if( task == 1 ){
      st = 0;
      dr = n;

      while( dr - st > 1 )
        if( v[mij = (st + dr) >> 1] > a )
          dr = mij;
        else
          st = mij;

      fprintf( fout, "%d\n", 1 + st );
    }else{ // if( task == 2 ){
      st = -1;
      dr = n - 1;

      while( dr - st > 1 )
        if( v[mij = (st + dr) / 2] < a )
          st = mij;
        else
          dr = mij;

      fprintf( fout, "%d\n", 1 + dr );
    }
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
