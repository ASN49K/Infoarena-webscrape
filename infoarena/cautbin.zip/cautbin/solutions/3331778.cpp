#include <bits/stdc++.h>

using namespace std;
ifstream fin(".IN");
ofstream fout(".out");
int n;
int v[100005];
int cerinta,x;
int m;
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    fin>>m;
    for(int i=1;i<=m;i++)
    {
        int maxim=-1;
        fin>>cerinta>>x;
        if(cerinta==0)
        {
            int st=1,dr=n;
            int i=1;
            bool ok=false;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(i>=maxim and v[i]==x){
                    ok=true;
                    maxim=i;
                    dr=mij;
                }
                else
                {
                    st=mij+1;
                }
                i++;
            }
            if(ok)
                fout<<maxim<<endl;
            else
                fout<<-1<<endl;
        }
        maxim=-1;
        if(cerinta==1)
        {
            int st=1,dr=n;
            int i=1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[i]<=x and i>=maxim)
                {
                    maxim=i;
                    dr=mij;
                }
                else
                    st=mij+1;
                i++;
            }
            fout<<maxim<<endl;
        }
        int minim=INT_MAX;
        if(cerinta==2)
        {
            int st=1;
            int dr=n;
            int i=1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(i<=minim and v[i]>=x)
                {
                    minim=i;
                    dr=mij;
                }
                else
                    st=mij+1;
                i++;
            }
            fout<<minim<<endl;
        }
    }
}
