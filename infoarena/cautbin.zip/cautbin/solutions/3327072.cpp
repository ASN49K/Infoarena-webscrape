#include <bits/stdc++.h>
using namespace std;
int cer1(int x, int st, int dr,int a[]){
int mij,poz;
poz=0;
while(st<=dr && !poz){
mij=(st+dr)/2;
if(x==a[mij]) poz=mij;
else if(x<a[mij]) dr=mij+1;
else st=mij-1;
    }
    return poz;
}
int cer2(int x, int st, int dr,int a[]){
int mij,poz;
while(st<=dr){
  mij=(st+dr)/2;
  if(a[mij]<=x){poz=mij; st=mij-1;}
  else dr=mij+1;
  }
  return poz;
}
int cer3(int x, int st, int dr,int a[]){
int mij,poz;
while(st<=dr){
mij=(st+dr)/2;
if(x<=a[mij]){poz=mij; dr=mij-1;}
else st=mij+1;
  }
  return poz;
}
ifstream ci ("cautbin.in");
ofstream cou ("cautbin.out");
int n,m,a[100005];
struct query{
int x,y;
}b[100005];
int main()
{ci >> n;
for(int i=1;i<=n;i++)
    ci >> a[i];
ci >> m;
for(int i=1;i<=m;i++){
ci >> b[i].x >> b[i].y;
 if(b[i].x==0) cou << cer1(b[i].y,1,n,a) << endl;
if(b[i].x==1) cou << cer2(b[i].y,1,n,a) << endl;
if(b[i].x==2) cou << cer3(b[i].y,1,n,a) << endl;
}


    return 0;
}
