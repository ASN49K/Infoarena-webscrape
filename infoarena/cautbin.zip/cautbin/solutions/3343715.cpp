#include<bits/stdc++.h>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

int n, m, c, i, x, y;
vector<int> nr;

int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>y;
        nr.push_back(y);
    }
    fin>>m;
    for(i=1;i<=m;i++)
    {
        fin>>c>>x;
        if(c==0)
        {
            auto val=upper_bound(nr.begin(),nr.end(),x);
            auto poz=val-nr.begin();
            val--;
            if(*val==x)
                fout<<poz;
            else
                fout<<-1;
        }
        else if(c==1)
        {
            auto val=upper_bound(nr.begin(),nr.end(),x);
            auto poz=val-nr.begin();
            fout<<poz;
        }
        else
        {
            auto val=lower_bound(nr.begin(),nr.end(),x);
            auto poz=val-nr.begin();
            fout<<poz+1;
        }
        fout<<"\n";
    }
}