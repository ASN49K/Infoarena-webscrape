#include <stdio.h>

int n,v[100001];

int cerinta0(int cautat)
{
    int st = 0, dr = n-1;
    while (st < dr)
    {
        int mij = (st + dr + 1) / 2;
        if (cautat == v[mij])
            st=mij;
        else if (cautat > v[mij])
            st = mij+1;
        else
            dr = mij-1;

    }
    if(st<n && v[st]== cautat)
        return st;
    return -1;
}

int cerinta1(int cautat)
{
    int st = 0, dr = n-1;
    while (st < dr)
    {
        int mij = (st + dr + 1) / 2;
        if (cautat == v[mij])
            st=mij;
        else if (cautat > v[mij])
            st = mij;
        else
            dr = mij-1;

    }
    if(st<n && v[st] <= cautat)
        return st;
    return -1;
}

int cerinta2(int cautat)
{
    int st = 0, dr = n-1;
    while (st < dr)
    {
        int mij = (st + dr) / 2;
        if (cautat == v[mij])
            dr=mij;
        else if (cautat > v[mij])
            st = mij+1;
        else
            dr=mij;

    }
    if(st<n && v[st] >= cautat)
        return st;
    return -1;
}

/*int cerinta0_secvential(int val)
{
    int rez=-1;
    for (int i=1;i<=n && v[i]<=val;++i)
        if (v[i]==val)
            rez=i;
    return rez;
}
int cerinta1_secvential(int val)
{
    int i;
    for (i=1;i<=n && v[i]<=val;++i);
    return i-1;
}
int cerinta2_secvential(int val)
{
    int i;
    for (i=1;i<=n && v[i]<val;++i);
    return i;
}*/
int main()
{
    int i,m,val,tip;
    FILE *f =fopen("cautbin.in","r");
    FILE *g =fopen("cautbin.out","w");
    fscanf(f,"%d",&n);
    for (i=1;i<=n;++i)
        fscanf(f,"%d",&v[i]);
    fscanf(f,"%d",&m);
    while (m--)
    {
          fscanf(f,"%d %d",&tip,&val);
          if (tip==0)
             fprintf(g,"%d\n",cerinta0(val));
          if (tip==1)
             fprintf(g,"%d\n",cerinta1(val));
          if (tip==2)
             fprintf(g,"%d\n",cerinta2(val));
    }
}
