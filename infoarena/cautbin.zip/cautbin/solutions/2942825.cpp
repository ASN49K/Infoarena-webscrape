#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("cautbin.in");
ofstream fout("cautbin.out");

const int NMAX=1e5+5;
int v[NMAX];

int main()
{
    int n,m;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        fin>>v[i];
    }
    fin>>m;
    for(int i=1;i<=m;i++)
    {
        int op,val;
        fin>>op>>val;
        if(op==0)
        {
            int up=upper_bound(v,v+n,val)-v;
            if(up==0)
            {
                fout<<-1;
            }
            else
            {
                if(v[up-1]!=val)
                {
                    fout<<-1;
                }
                else
                {
                    fout<<up;
                }
            }
        }
        else if(op==1)
        {
            int up=upper_bound(v,v+n,val)-v;
            if(up==0)
            {
                fout<<-1;
            }
            else
            {
                fout<<up;
            }
        }
        else
        {
            int low=lower_bound(v,v+n,val)-v;
            fout<<low+1;
        }
        fout<<endl;
    }
    return 0;
}
