#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("transport.in");
ofstream fout("transport.out");

int v[16000 + 5], k, n;
bool verif( int mij )
{
    int i, s = 0, nr = 0;
    for ( i = 1; i <= n; ++i )
    {
        s = 0;
        ++nr;
        while ( i <= n && s <= mij )
        {
            s += v[i];
            ++i;
        }
        if ( i > n )
        {
            if ( s > mij )
                ++nr;
            break;

        }
        i = i  - 2;
    }

    if ( nr <= k )
        return true;
    return false;
}

int main()
{
    int i, j;
    fin >> n >> k;
    int st = -1, dr = 0;
    for ( i = 1; i <= n; ++i )
    {
        fin >> v[i];
        st = max(st, v[i]);
        dr += v[i];
    }
    long long mij, sol = -1;
    while ( st <= dr )
    {
        mij = ( st + dr)/ 2;
        if ( verif(mij) == true )
        {
            sol = mij;
            dr = mij - 1;
        }
        else
            st = mij + 1;
  //  cout << st << " " << dr << endl;
    }
    fout << sol << endl;


   /// cout << verif(7);

    return 0;
}
