#include <stdio.h>

#define NMax 100005

int N, M, v[NMax], logN;

int main(void)
{
    int tip, x, i, lg;

    freopen("cautbin.in", "r", stdin);
    freopen("cautbin.out", "w", stdout);

    scanf("%d", &N);
    for (i = 1; i <= N; ++i)
        scanf("%d", &v[i]);

    for (logN = 1; logN <= N; logN <<= 1);

    scanf("%d", &M);
    for (; M; --M)
    {
        scanf("%d %d", &tip, &x);
        if (tip < 2)
        {
            for (lg = logN, i = 0; lg; lg >>= 1)
                if (i + lg <= N && v[i + lg] <= x)
                    i += lg;

            if (!tip && v[i] != x)
                printf("-1\n");
            else
                printf("%d\n", i);

            continue;
        }

        for (lg = logN, i = N; lg; lg >>= 1)
            if (i - lg > 0 && v[i - lg] >= x)
                i -= lg;
        printf("%d\n", i);
    }

    return 0;
}
/*
int N, A[N];

int binary_search(int val)
{
    int i, step;
    for (step = 1; step < N; step <<= 1);
    for (i = 0; step; step >>= 1)
        if (i + step < N && A[i + step] <= val)
           i += step;
    return i;
}
*/
