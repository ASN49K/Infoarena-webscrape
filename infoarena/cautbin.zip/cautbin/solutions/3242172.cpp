#include <fstream>
#include <algorithm>
using namespace std;
int v[100005],n;
int solve0(int x,int n)
{
    int st=1,dr=n,sol=-1,mid;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(v[mid]==x)
        {
            sol=mid;
            st=mid+1;
        }
        else if(v[mid]>x)
            dr=mid-1;
        else
            st=mid+1;
    }
    return sol;
}
int solve1(int x,int n)
{
     int st=1,dr=n,sol=-1,mid;
     while(st<=dr)
     {
         mid=(st+dr)/2;
         if(v[mid]<=x)
         {
             sol=mid;
             st=mid+1;
         }
         else
            dr=mid-1;
     }
     return sol;
}
int solve2(int x,int n)
{
     int st=1,dr=n,sol=-1,mid;
     while(st<=dr)
     {
         mid=(st+dr)/2;
             if(v[mid]>=x)
             {
             sol=mid;
             dr=mid-1;
             }
             else
                st=mid+1;


     }
     return sol;
}
int main()
{
    ifstream cin("cautbin.in");
    ofstream cout("cautbin.out");
cin>>n;
for(int i=1;i<=n;i++)
    cin>>v[i];
int m,task,x;
cin>>m;
for(int j=0;j<m;j++)
{
    cin>>task>>x;
    if(task==0)
        cout<<solve0(x,n);
    else if(task==1)
    cout<<solve1(x,n);
    else
        cout<<solve2(x,n);
    cout<<'\n';
}


    return 0;
}
