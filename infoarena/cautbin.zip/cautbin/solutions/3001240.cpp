#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

///#include <tryhardmode>
///#include <GODMODE::ON>
///PRACTICE

using namespace std;

ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");

const int NMAX=1e5+5;
int v[NMAX];

int lower_b(int x,int st,int dr)
{
    int mij,ans=-1;
    while(st<=dr)
    {
        mij=st+dr;
        mij/=2;
        if(v[mij]>=x)
        {
            st=mij+1;
            if(v[mij]==x)
                ans=mij;
        }
        else
            dr=mij-1;
    }
    return ans;
}

int lower_b2(int x,int st,int dr)
{
    int mij,ans;
    while(st<=dr)
    {
        mij=st+dr;
        mij/=2;
        if(v[mij]<=x)
        {
            st=mij+1;
            ans=mij;
        }
        else
            dr=mij-1;
    }
    return ans;
}

int upper_b(int x,int st,int dr)
{
    int mij,ans;
    while(st<=dr)
    {
        mij=st+dr;
        mij/=2;
        if(v[mij]>=x)
        {
            dr=mij-1;
            ans=mij;
        }
        else
            st=mij+1;
    }
}

int main()
{
    int cer,q,n,i,j;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i];
    fin>>q;
    while(q--)
    {
        int x;
        fin>>cer>>x;
        if(cer==0)
            fout<<lower_b(x,1,n);
        else if(cer==1)
            fout<<lower_b2(x,1,n);
        else
            fout<<upper_b(x,1,n);
        fout<<"\n";
    }
    return 0;
}
