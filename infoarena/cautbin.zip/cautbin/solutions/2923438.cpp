#include <bits/stdc++.h>
using namespace std;

///ifstream fin("cautbin.in");
///ofstream fout("cautbin.out");

int a[200005], n;

/// ret. cea mai din dreapta pozitie p in care a[p] < x
int CautBin(int poz, int x)
{
    if (x <= a[poz]) return poz - 1;
    if (x > a[n]) return n;
    int st, dr, mij, p;
    st = poz; dr = n; p = poz;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (a[mij] < x)
        {
            p = mij;
            st = mij + 1;
        }
        else dr = mij - 1;
    }
    return p;
}

int main()
{
    int j, i, contor = 0, p;
    cin >> n;
    for (i = 1; i <= n; i++)
        cin >> a[i];
    sort(a + 1, a + n + 1);
    for (i = 1; i <= n-2; i++)
        for (j = i + 1; j <= n-1; j++)
        {
            /// cautam in a[j+1..n] cate numere sunt < a[i]+a[j]
            p = CautBin(j + 1, a[i] + a[j]);
            contor += (p - j);
        }
    cout << contor;


    return 0;
}
