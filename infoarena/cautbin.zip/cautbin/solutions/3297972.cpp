#include <bits/stdc++.h>

using namespace std;

ifstream fin ("cautbin.in");
ofstream fout ("cautbin.out");

const int nmax=2e5+5;

int n, v[nmax];

int cb0 (int n, int x)
{
    int st=1, dr=n, poz=0;
    while (st<=dr)
    {
        int mij=(st+dr)/2;
        if (v[mij]<=x)
        {
            poz=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    if (v[poz]==x)
        return poz;
    return -1;
}

int cb1 (int n, int x)
{
    int st=1, dr=n, poz=0;
    while (st<=dr)
    {
        int mij=(st+dr)/2;
        if (v[mij]<=x)
        {
            poz=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    return poz;
}

int cb2 (int n, int x)
{
    int st=1, dr=n, poz=0;
    while (st<=dr)
    {
        int mij=(st+dr)/2;
        if (v[mij]>=x)
        {
            poz=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return poz;
}

int main()
{
    fin >> n;
    for (int i=1; i<=n; i++)
        fin >> v[i];
    int q;
    fin >> q;
    for (int i=1; i<=q; i++)
    {
        int cer, x;
        fin >> cer >> x;
        if (cer==0)
            fout << cb0(n,x) << '\n';
        if (cer==1)
            fout << cb1(n,x) << '\n';
        if (cer==2)
            fout << cb2(n,x) << '\n';
    }
    return 0;
}
