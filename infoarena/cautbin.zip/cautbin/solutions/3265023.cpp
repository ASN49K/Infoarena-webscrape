#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100002],N;
int CB(int a)
{
    int L=1,R=N,mij;
    while(L<R)
    {
    mij=(L+R)/2;
    if(v[mij]>a)
    R=mij;
    else
    if(v[mij]<a)
    L=mij;
    else
    return mij;
    }
    return mij;
}
int main()
{
    int M,c,pz,x;
    fin>>N;
    for(int i=1;i<=N;i++)
    {
    fin>>v[i];
    }
    fin>>M;
    while(M)
    {
        fin>>c>>x;
        pz=CB(x);
        
        if(c==0)
        {
        if(v[pz]==x)
        {
        while(v[pz]==x)
        pz++;
        pz--;
        fout<<pz<<'\n';
        }
        else
        fout<<-1<<'\n';
        }
        else
        if(c==1)
        {
        while(v[pz]<=x)
        pz++;
        pz--;
        fout<<pz<<'\n';
        }
        else
        if(c==2)
        {
        while(v[pz]>=x)
        pz--;
        pz++;
        fout<<pz<<'\n';
        }
        M--;
    }
    return 0;
}