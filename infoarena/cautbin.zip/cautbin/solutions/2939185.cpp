#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100005],n,i,m,c,x,ok,p,u,mij,poz;
int main()
{fin>>n;
for (i=1;i<=n;i++)
{
    fin>>v[i];
}
fin>>m;
for (i=1;i<=m;i++)
{
    fin>>c>>x;
    if (c==0)
    {
        ok=0;
        p=1;
        u=n;
        while (p<=u)
        {
            mij=(p+u)/2;
            if (v[mij]==x) {p=mij+1;poz=mij;ok=1;}
            else if (v[mij]>x) u=mij-1;
            else p=mij+1;
        }
        if (ok==0) fout<<"-1"<<'/n';
        else fout<<poz<<'\n';
    }
    else if (c==1)
    {
        p=1;u=n;
        while (p<=u)
        {
            mij=(p+u)/2;
            if (v[mij]<=x) {p=mij+1;poz=mij;}
            else u=mij-1;
        }
        fout<<poz<<'\n';
    }
    else if (c==2)
    {
        p=1;u=n;
        while (p<=u)
        {
            mij=(p+u)/2;
            if (v[mij]>=x) {u=mij-1;poz=mij;}
            else p=mij+1;
        }
        fout<<poz<<'\n';
    }

}

    return 0;
}
