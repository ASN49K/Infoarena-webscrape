#include <fstream>

using namespace std;
ifstream fin("cautbin.in");
ofstream fout("cautbin.out");
int v[100000+10];
int main()
{
    int st,dr,n,m,poz=-1,val,nr,mij;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    fin>>m;

    for(int i=1; i<=m; i++)
    {
        fin>>nr>>val;
        st=1;
        dr=n+1;
        if(nr==0)
        {
            while(st+1<dr)
            {
                mij=(st+dr)/2;
                if(v[mij]<val)
                {
                    st=mij;
                }
                else
                {
                    if(v[mij]>val)
                        dr=mij;
                    else if(v[mij]==val)
                    {
                        st=mij;
                        poz=st;

                    }
                }

            }
            fout<<poz<<'\n';
        }
        //---
        poz=-1;
        st=1;
        dr=n+1;
        if(nr==1)
        {
            while(st+1<dr)
            {
                mij=(st+dr)/2;
                if(v[mij]<=val)
                {
                    st=mij;
                    poz=st;
                }
                else if(v[mij]>val)
                    dr=mij;
            }
            fout<<poz<<'\n';


        }
        st=1;
        dr=n+1;
        poz=-1;
        if(nr==2)
        {
            while(st+1<dr)
            {
                mij=(st+dr)/2;
                if(v[mij]<val)
                    st=mij;
                else
                {
                    poz=mij;
                    dr=mij;

                }
            }
            fout<<poz<<'\n';

        }
    }
    return 0;
}
