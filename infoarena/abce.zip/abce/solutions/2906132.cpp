#include <iostream>
#include <fstream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
struct nod{
	int key;
    nod * left, * right;

};
void Insert(nod* &node, int x)
{
	if(node != NULL)
    {
    	if(node->key == x)
        	return;
        else
        	if(node->key > x)
            	Insert(node->left , x);
            else
            	Insert(node->right , x);
    }
    else
    {
    	node = new nod;
        node->key = x;
        node->left = NULL;
        node->right = NULL;
    }
}


int Search(nod* node , int x)
{
	if(node == NULL)
		return 0;
	if(node->key == x)
		return 1;
	if(node->key > x)
		return Search(node->left , x);
	else
		return Search(node->right , x);
}

void DeleteAux(nod* &p, nod* &node)
{
	if(p->right)
		DeleteAux(p -> right , node);
	else
	{
		node->key = p->key;
		nod* aux = p;
		p = p->left;
		delete aux;
	}
}

void Delete(nod* &node , int x)
{
	if(node != NULL)
	{
		if(node->key == x)
		{
			if(node->left == NULL && node->right == NULL)
			{
				delete node;
				node = NULL;
			}
			else
				if(node->right == NULL)
				{
					nod* aux = node;
					node = node->left;
					delete aux;
				}
				else
					if(node->left == NULL)
					{
						nod* aux = node;
						node = node->right;
						delete aux;
					}
					else
						DeleteAux(node->left, node);
		}
		else
			if(node->key > x)
				Delete(node->left , x);
			else
				Delete(node->right , x);
	}
	else
		return;
}
nod* node;
long long q;
int op, x, y;
int main()
{

    f>>q;
    for(int i = 1; i <= q; i++)
        {
            f>>op>>x;
            if(op == 1)
                Insert(node, x);
            if(op == 2)
                Delete(node, x);
            if(op == 3)
                g<<Search(node, x)<<'\n';
        }
    return 0;
}
