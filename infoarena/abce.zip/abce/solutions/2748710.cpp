#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct Node {
	int val;
	Node* left;
	Node* right;
	int height;

	Node(int x = 0) {
		val = x;
		left = NULL;
		right = NULL;
		height = 1;
	}
};

int getHeight(Node* a){
	if (a == nullptr) {
		return 0;
	}
	return 1+ max(getHeight(a->left),getHeight(a->right));
}


int balanceFactor(Node* a) {
	if (a == nullptr) {
		return 0;
	}
	return getHeight(a->left) - getHeight(a->right);
}

Node* rightRotation(Node* &a) {
	Node* b = a->left;
	a->left = b->right;
	b->right = a;
	a->height = 1 + max(getHeight(a->right), getHeight(a->left));
	b->height = 1 + max(getHeight(b->right), getHeight(b->left));
	return b;
}

Node* leftRotation(Node*& a) {
	Node* b = a->right;
	a->right = b->left;
	b->left = a;
	a->height = 1 + max(getHeight(a->right), getHeight(a->left));
	b->height = 1 + max(getHeight(b->right), getHeight(b->left));
	return b;
}


void insert(Node* &root, int x) {
	if (root == NULL) {
		root = new Node(x);
	}
	if (x < root->val) {
		if (root->left == NULL) {
			root->left = new Node(x);
			return;
		}
		else {
			insert(root->left, x);
		}
	}
	else if (x > root->val) {
		if (root->right == NULL) {
			root->right = new Node(x);
			return;
		}
		else {
			insert(root->right, x);
		}
	}

	root->height = 1 + max(getHeight(root->left), getHeight(root->right));
	int balance = balanceFactor(root);

	//left left
	if (balance > 1 && x < root->left->val) {
		root = rightRotation(root);
	}

	//right right
	if (balance < -1 && x > root->right->val) {
		root = leftRotation(root);
	}

	//left right
	if (balance > 1 && x > root->left->val) {
		root->left = leftRotation(root->left);
		root = rightRotation(root);
	}
	//right left
	if (balance < -1 && x < root->right->val) {
		root->right = rightRotation(root->right);
		root = leftRotation(root);
	}
}

int seeIfIn(Node* root,int x) {
	if (root == NULL)
		return 0;
	if (x < root->val)
		return seeIfIn(root->left, x);
	else if (x > root->val)
		return seeIfIn(root->right, x);
	else if (x == root->val)
		return 1;
}

Node* minVal(Node* root) {
	Node* curr = root;
	while (curr->left != NULL) {
		curr = curr->left;
	}
	return curr;
}

Node* maxVal(Node* root) {
	Node* curr = root;
	while (curr->right != NULL) {
		curr = curr->right;
	}
	return curr;
}

int succesor(Node* root, int val) {
	if (root == NULL)
		return 2147483647;
	if (root->val == val)
		return val;
	if (val < root->val) {
		return min(root->val, succesor(root->left, val));
	}
	else
		return succesor(root->right, val);
}

int predecesor(Node* root, int val) {

	if (root == NULL) {
		return -2147483648;
	}
	if (root->val == val) {
		return val;
	}
	if (val<root->val) {
		return predecesor(root->left, val);
	}
	else
		return max(root->val,predecesor(root->right, val));
}
void inorderBest(Node* root, int x, int y) {
	if (root == NULL) {
		return;
	}
	inorderBest(root->left, x, y);
	if(root->val>=x && root->val<=y) fout << root->val<<' ';
	inorderBest(root->right, x, y);
}

void inorder(Node* root) {
	if (root == NULL) {
		return;
	}
	inorder(root->left);
	cout << root->val << ' ';
	inorder(root->right);
}

void preorder(Node* root) {
	if (root == NULL) {
		return;
	}
	cout << root->val << ' ';
	preorder(root->left);
	preorder(root->right);
}

void remove(Node*& root, int val) {
	if (root == NULL) {
		return;
	}

	if (val < root->val) remove(root->left, val);
	else if (val > root->val) remove(root->right, val);

	//am gasit nodul pe care trebuie sa il stergem
	else {
		if (root->left == NULL || root->right == NULL)
		{
			Node* aux = NULL;
			if (root->left != NULL) {
				aux = root->left;
			}
			else if (root->right != NULL) {
				aux = root->right;
			}
			if (aux == NULL) {
				aux = root;
				root = NULL;
			}
			else {
				*root = *aux;
			}

			delete aux;
		}
		else {
			Node* aux = minVal(root->right);
			root->val = aux->val;
			remove(root->right, aux->val);
		}
	}
	if (root == NULL) {
		return;
	}

	root->height = 1 + max(getHeight(root->left), getHeight(root->right));
	int balance = balanceFactor(root);

	//left left
	if (balance > 1 && balanceFactor(root->left) >= 0)
		root = rightRotation(root);
	//left right
	if (balance > 1 && balanceFactor(root->left) < 0) {
		root->left = leftRotation(root->left);
		root = rightRotation(root);
	}
	//right right
	if (balance < -1 && balanceFactor(root->right) <= 0)
		root = leftRotation(root);
	//right left
	if (balance < -1 && balanceFactor(root->right)>0) {
		root->right = rightRotation(root->right);
		root = leftRotation(root);
	}
}
int main() {

	int n;
	fin >> n;
	
	int operatie;
	int x, y;
	Node* lel = new Node(0);
	
	Node* root = NULL;
	lel->right = root;
	for (int i = 0; i < n; i++) {
		fin >> operatie;
		switch (operatie) {
		case 1:
			fin >> x;
			insert(root, x);
			break;
		case 2:
			fin >> x;
			remove(root, x);
			break;
		case 3:
			fin >> x;
			fout << seeIfIn(root, x) << '\n';
			break;
		case 4:
			fin >> x;
			fout << predecesor(root, x) << '\n';
			break;
		case 5:
			fin >> x;
			fout << succesor(root, x) << '\n';
			break;
		case 6:
			fin >> x >> y;
			inorderBest(root, x, y);
			fout << '\n';
			break;
		}
	}
}