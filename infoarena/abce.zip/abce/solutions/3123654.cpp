#ifndef LOCAL
    #pragma GCC optimize("Ofast")
#endif // LOCAL
#include <bits/stdc++.h>

using namespace std;

static char buf[60 << 20];
void* operator new(size_t s) {
	static size_t i = sizeof buf;
	assert(s < i);
	return (void*)&buf[i -= s];
}
void operator delete(void*) {}

struct RNG {
    uint64_t x; /* The state can be seeded with any value. */

    uint64_t next() {
        uint64_t z = (x += 0x9e3779b97f4a7c15);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9;
        z = (z ^ (z >> 27)) * 0x94d049bb133111eb;
        return z ^ (z >> 31);
    }

    RNG(uint64_t _x) { x = _x; }
} rng(123);

template < typename Data >
struct Treap {
    struct Node {
        Data data;

        uint32_t prio;

        Node *left, *right;

        Node(Data _data) {
            data = _data;
            prio = rng.next();
            left = right = nullptr;
        }
    } *head;

    static int get_prio(Node *x) { return x == nullptr ? 0 : x->prio; }

    Treap() { head = nullptr; }
    Treap(Data _data) { head = new Node(_data); }

    static Node* merge(Node* l, Node* r) {
        if(l == nullptr) return r;
        if(r == nullptr) return l;

        if(get_prio(l) > get_prio(r)) {
            /// l as root
            l->right = merge(l->right, r);

            return l;
        }
        else {
            /// r as root
            r->left = merge(l, r->left);

            return r;
        }
    }

    static pair<Node*, Node*> split(Node* root, Data key) {
        if(root == nullptr) {
            return {nullptr, nullptr};
        }

        if(root->data < key) {
            pair<Node*, Node*> n = split(root->right, key);
            root->right = n.first;

            return {root, n.second};
        }
        else {
            pair<Node*, Node*> n = split(root->left, key);
            root->left = n.second;

            return {n.first, root};
        }
    }

    static void _prt(Node *h, ostream& out) {
        if(h == nullptr) return;
        _prt(h->left, out); out << h->data << ' '; _prt(h->right, out);
    }

    Data _get_min(Node *h) {
        if(h->left == nullptr) return h->data;
        return _get_min(h->left);
    }

    Data _get_max(Node *h) {
        if(h->right == nullptr) return h->data;
        return _get_max(h->right);
    }

    Data get_max() { return _get_max(head); }
    Data get_min() { return _get_min(head); }
};

#define RIT Treap<T>
#define Node (typename Treap<T>::Node)

template < typename T >
ostream& operator<<(ostream& out, RIT x) {
    RIT::_prt(x.head, out);

    return out;
}

template < typename T >
RIT merge(RIT a, RIT b) {
    RIT ret;
    ret.head = RIT::merge(a.head, b.head);
    return ret;
}

template < typename T >
pair<RIT, RIT> split(RIT a, T key) {
    auto pr = RIT::split(a.head, key);
    pair<RIT, RIT> ret;
    ret.first.head = pr.first;
    ret.second.head = pr.second;

    return ret;
}

#undef RIT
#undef Node

#ifndef LOCAL
ifstream in("abce.in");
ofstream out("abce.out");
#define cin in
#define cout out
#endif // LOCAL

signed main()
{
    #ifndef LOCAL
        ios_base::sync_with_stdio(false);
        cin.tie(0); cout.tie(0);
    #endif // LOCAL

    Treap<int> tr;
    int q; cin >> q;
    while(q--) {
        int t; cin >> t;

        if(t == 1) {
            int x; cin >> x;
            auto pr = split(tr, x);
            tr = merge(merge(pr.first, Treap<int>{x}), pr.second);
        }
        if(t == 2) {
            int x; cin >> x;
            auto pr = split(tr, x);
            tr = merge(pr.first, split(pr.second, x + 1).second);
        }
        if(t == 3) {
            int x; cin >> x;
            auto pr = split(tr, x);
            auto pr2 = split(pr.second, x + 1);

            cout << (pr2.first.head != nullptr) << '\n';
            tr = merge(pr.first, merge(pr2.first, pr2.second));
        }
        if(t == 4) {
            int x; cin >> x;
            auto pr = split(tr, x + 1);
            cout << pr.first.get_max() << '\n';

            cerr << pr.first << endl;
            cerr << pr.second << endl;

            tr = merge(pr.first, pr.second);
        }
        if(t == 5) {
            int x; cin >> x;
            auto pr = split(tr, x);
            cout << pr.second.get_min() << '\n';

            tr = merge(pr.first, pr.second);
        }
        if(t == 6) {
            int x, y; cin >> x >> y;
            auto pr = split(tr, y + 1);
            auto pr2 = split(pr.first, x);

            cout << pr2.second << '\n';
            tr = merge(merge(pr2.first, pr2.second), pr.second);
        }

        #ifdef LOCAL
            cerr << "TREAP: " << tr << '\n';
        #endif // LOCAL

    }

    // cout << x << '\n';

    return 0;
}
