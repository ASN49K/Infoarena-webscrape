#include <iostream>
#include <fstream>
using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class nod
{


public:

    nod *st, *dr;
    int val;

//    nod(int x): st(NULL), dr(NULL) { val = x; }
//
//    nod(): val(NULL), st(NULL), dr(NULL) {cout<<"Woohoo"<<endl;}

    nod* operator=(int x)
    {
        val = x;
        return this;
    }

    void afisare()
    {
        cout<<val<<" ";
    }

    void citire()
    {
        cin>>val;
    }

};

nod* zag(nod* x)
{
    nod *aux;
    aux = (*x).st;
    (*x).st = (*aux).dr;
    (*aux).dr = x;

    return aux;
}

nod* zig(nod* x)
{
    nod *aux;
    aux = (*x).dr;
    (*x).dr = (*aux).st;
    (*aux).st = x;

    return aux;
}

nod* treesplay(nod* rad, int valoare)
{
    if(rad == NULL || (*rad).val == valoare)
        return rad;

    if(valoare > (*rad).val)
    {
        if((*rad).dr == NULL) return rad;

        if (valoare > (*((*rad).dr)).val)
        {
            (*((*rad).dr)).dr = treesplay((*((*rad).dr)).dr, valoare);
            rad = zig(rad);
        }

        else if(valoare < (*((*rad).dr)).val)
        {
            (*((*rad).dr)).st = treesplay((*((*rad).dr)).st, valoare);
            if((*((*rad).dr)).st != NULL)
                (*rad).dr = zag((*rad).dr);
        }

        if((*rad).dr == NULL) return rad;
        else return zig(rad);
    }
    else  if(valoare < (*rad).val)
    {
        if((*rad).st == NULL)
            return rad;

        if(valoare > (*((*rad).st)).val)
        {
            (*((*rad).st)).dr = treesplay((*((*rad).st)).dr, valoare);

            if((*((*rad).st)).dr != NULL)
                (*rad).st = zig((*rad).st);
        }

        else if(valoare < (*((*rad).st)).val)
        {
            (*((*rad).st)).st = treesplay((*((*rad).st)).st, valoare);
            rad = zag(rad);
        }

        if((*rad).st == NULL)
            return rad;
        else return zag(rad);
    }

}

bool cautare(nod* x, int valoare)
{
    if(x)
    {if(treesplay(x, valoare)->val==valoare)
        return 1;
    else return 0;}
    return 0;
}

nod* adaugare(nod* rad, int valoare)
{
    if (rad == NULL)
    {
        nod *aux = new nod();
        (*aux).val = valoare;
        return aux;
    }

    rad = treesplay(rad, valoare);

    if ((*rad).val == valoare)
        return rad;

    nod *aux = new nod();
    (*aux).val = valoare;

    if(valoare < (*rad).val)
    {
        (*aux).dr = rad;
        (*aux).st = (*rad).st;
        (*rad).st = NULL;
    }
    else
    {
        (*aux).st = rad;
        (*aux).dr = (*rad).dr;
        (*rad).dr = NULL;
    }

    return aux;
}


void preordine(nod *rad)
{
    if(rad != NULL)
    {
        //cout<<(*rad).val<<" ";
        preordine((*rad).st);
        preordine((*rad).dr);
    }
}

nod* stergere(nod* rad, int valoare)
{
    nod *aux;

    if(rad == NULL)
    {

        return NULL;

    }

    rad = treesplay(rad, valoare);



      if(rad->val != valoare)
        {
            //cout<<"hei"<<endl;
            return rad;

        }

        if(rad->st == NULL)
            {
                //cout<<"hei"<<endl;
                aux = rad;
                rad = rad->dr;

            }
        else
        {
           //cout<<rad->val<<" ";
        aux = rad;

        rad = treesplay(rad->st, valoare);

        rad->dr = aux->dr;

        }

        free(aux);

        return rad;



}

nod* gaseste_minim(nod* x)
{
    while(x->st)
        x = x->st;
    return x;
}

nod* pred(nod* x, nod* p, int valoare)
{
    if(x == NULL)
        return p;
    if(x->val == valoare)
    {
        if(x->st != NULL)
        {
            return gaseste_minim(x->st);
        }
    }
    else if(valoare< x->val)
        return pred(x->st, p, valoare);
    else
    {
        p = x;
        return pred(x->dr, p, valoare);
    }
    return p;
}

nod* succ(nod* x, nod* p, int valoare)
{
    if(x == NULL)
        return p;
    if(x->val == valoare)
    {
        if(x->dr != NULL)
        {
            return gaseste_minim(x->dr);
        }
    }
    else if(valoare < x->val)
        {
            p = x;
            return succ(x->st, p, valoare); }
    else
    {

        return succ(x->dr, p, valoare);
    }
    return p;
}

//nod* pred(nod* x, nod* p, int valoare)
//{
//    if(x == NULL)
//        return p;
//    if(x->val == valoare)
//    {
//        if(x->st != NULL)
//        {
//            return gaseste_minim(x->st);
//        }
//    }
//    else if(valoare< x->val)
//        return pred(x->st, p, valoare);
//    else
//    {
//        p = x;
//        return pred(x->dr, p, valoare);
//    }
//    return p;
//}

int main()
{
    nod *rad;
    rad = new nod();
    rad = NULL;

    int optiune, n;

    f>>n;



    int x, y;
//
//    rad = adaugare(rad, 5);
//    rad = adaugare(rad, 7);
//    rad = stergere(rad, 7);
//    rad = adaugare(rad, 8);
//    rad = adaugare(rad, 10);


//    cin>>x>>y;
//            int nr = -1;
//            nod *aux = succ(rad, NULL, x);
//            cout<<aux->val;
//            while(aux && aux->val<y)
//            {
//                cout<<aux->val<<" ";
//                aux = succ(rad, NULL, aux->val+1);
//            }


    for (int i=0;i<n;i++)
    {
        f>>optiune;
        switch(optiune)
        {
        case 1:

            f>>x;
            rad = adaugare(rad, x);
            break;
        case 2:
            f>>x;
            rad = stergere(rad, x);
            break;
        case 3:
            f>>x;
            g<<cautare(rad, x)<<'\n';
            break;
//        case 4:
//            f>>x;
//            if(pred(rad, NULL, x)) g<<pred(rad, NULL, x)->val<<'\n';
//            else g<<NULL<<'\n';
//            break;
//        case 5:
//            f>>x;
//            if(succ(rad, NULL, x)) g<<succ(rad, NULL, x)->val<<'\n';
//            else g<<NULL<<'\n';
//            break;
//        case 6:
//            f>>x>>y;
//            int nr = -1;
//            nod *aux = succ(rad, NULL, x);
//           // cout<<aux->val;
//            while(aux && aux->val<y)
//            {
//                g<<aux->val<<" ";
//                aux = succ(rad, NULL, aux->val);
//            }

//            g<<'\n';
        case 4:
            f>>x;
            break;
        case 5:
            f>>x;
            break;
        case 6:
            f>>x>>y;
            break;

        }
}

}
