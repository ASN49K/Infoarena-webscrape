#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in") ;
ofstream fout("abce.out") ;
struct Treap
{
   int key, p;
    Treap *left, *right;
};
Treap* New_node (int x)
{
    Treap* nod=new Treap;
    nod->key=x;
    nod->p=rand();
    nod->left =nod->right= NULL;
    return nod;
}
Treap* rot_right (Treap* y)
{
    Treap *x=y->left;
    y->left=x->right;
    x->right=y;
    return x;
}
Treap* rot_left (Treap* y)
{
    Treap *x=y->right;
    y->right=x->left;
    x->left=y;
    return x;
}
void Insert (Treap* &node, int key)
{
    if(node->key==key)
    {
        return;
    }
    if(node==NULL)
    {
        node=New_node(key);
    }
    else{
        if(key<node->key)
        {
            Insert(node->left, key);
            if(node->p< node->left->p)
            {
                node= rot_right(node);
            }
        }
        else{
            Insert(node->right, key);
            if(node->p<node->right->p)
            {
                node=rot_left(node);
            }
        }
    }
}
bool Search(Treap* node, int val)
{
    if(node==NULL)
    {
        return 0;
    }
    if(node->key==val)
    {
        return 1;
    }
    if(val<node->key)
    {
        return Search(node->left,val);
    }
    return Search(node->right,val);
}
Treap *Delete(Treap* node, int key)
{
    if(!node)
    {
        return node;
    }
    if(key<node->key)
    {
        node->left=Delete(node->left, key);
    }
    else if(key>node->key)
    {
        node->right=Delete(node->right, key);
    }
    else if(!node->left ||!node->right)
    {
        Treap* aux=(node->left ? node->left:node->right);
        delete node;
        node=aux;
    }
    else if(node->left->p> node->right->p)
    {
        node=rot_right(node);
        node->right=Delete(node->right, key);
    }
    else
    {
        node=rot_left(node);
        node->left=Delete(node->left, key);
    }
    return node;
}
int Predecesor(Treap* radacina, int val)
{
    if(radacina->key>val)
    {
        return Predecesor(radacina->left, val);
    }
    return max(radacina->key, Predecesor(radacina->right, val));
}
int Succesor(Treap* radacina, int val)
{
    if(radacina->key<val)
    {
        return Succesor(radacina->right, val);
    }
    return min(radacina->key, Succesor(radacina->left, val));
}
void Interval(Treap* radacina, int left,int right)
{
    if(!radacina)
    {
        return;
    }
    Interval(radacina->left,left, right);
    if(radacina->key>=left && radacina->key<=right)
    {
        fout<<radacina->key<<" ";
    }
    Interval(radacina->right, left, right);
}
int main()
{
    int n,a,b,c;
    fout<<"introduceti n";
    fin>>n;
    Treap* t;
    for(int i=0;i<n;i++)
    {
        fin>>a>>b;
        if(a==1)
        {
            Insert(t,b);
        }
        if(a==2)
        {
            t=Delete(t,b);
        }
        if(a==3)
        {

            fout<<Search(t,b)<<'\n';
        }
        if(a==4)
        {
            fout<<Predecesor(t,b)<<'\n';
        }
        if(a==5)
        {
            fout<<Succesor(t,b)<<'\n';
        }
        if(a==6)
        {
            fin>>c;
            Interval(t,b,c);
            fout<<'\n';
        }
    }
    return 0;
}
