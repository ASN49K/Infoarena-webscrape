#include <iostream>
#include <list>
#include <queue>
#include <fstream>
#include <climits>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");


struct Node
{
    int data;
    Node* left;
    Node* right;
};


struct Node* newNode(int data)
{
    struct Node* node = new Node;
    node->data = data;
    node->left = node->right = NULL;
    
    return node;
}


void insert(Node* &root, int data)
{
    if(root == nullptr)
    {
        root = newNode(data);
        return;
    }

    if(data < root->data)
    {
        insert(root->left, data);
    }

    else
    {
        insert(root->right, data);
    }
}


Node* search(Node* root, int data) {
    if (root == nullptr) {

        return NULL;
    }

    if (root->data == data) {
     
        return root;
    }

    if (data < root->data) {
        return search(root->left, data);
    } else {
        return search(root->right, data);
    }
}



void deleteNode(Node* &root, int data)
{
    if(root == nullptr)
    {
        return;
    }

    if(data < root->data)
    {
        deleteNode(root->left, data);
    }

    else if(data > root->data)
    {
        deleteNode(root->right, data);
    }

    else
    {
        if(root->left == NULL && root->right == NULL)
        {
            delete root;
            root = NULL;
        }

        else if(root->left == NULL)
        {
            Node* temp = root;
            root = root->right;
            delete temp;
        }

        else if(root->right == NULL)
        {
            Node* temp = root;
            root = root->left;
            delete temp;
        }

        else
        {
            Node* temp = root->right;

            while(temp->left != NULL)
            {
                temp = temp->left;
            }

            root->data = temp->data;
            deleteNode(root->right, temp->data);
        }
    }
}


void search_min(Node* root)
{
    if(root == NULL)
    {
        return;
    }

    if(root->left == NULL)
{
        return;
    }

    search_min(root->left);
}


void search_max(Node* root)
{
    if(root == NULL)
    {
        return;
    }

    if(root->right == NULL)
    {
        return;
    }

    search_max(root->right);
}


int find_highest_lower(Node* root, int N)
{
    // If leaf node reached and is smaller than N
    if (root->left == NULL && root->right == NULL
                                && root->data > N)
        return -999999999;
 
    // If node's value is greater than N and left value
    // is NULL or smaller then return the node value
    if ((root->data <= N && root->left == NULL)
        || (root->data <= N && root->left->data > N))
        return root->data;
 
    // if node value is smaller than N search in the
    // right subtree
    if (root->right!=NULL and root->data >= N)
        return find_highest_lower(root->right, N);
 
    // if node value is greater than N search in the
    // left subtree
    else if(root->left!=NULL)
        return find_highest_lower(root->left, N);
}


int find_lowest_higher(Node* root, int N)
{
    // If leaf node reached and is smaller than N
    if (root->left == NULL && root->right == NULL
                                && root->data < N)
        return 999999999;
 
    // If node's value is greater than N and left value
    // is NULL or smaller then return the node value
    if ((root->data >= N && root->left == NULL)
        || (root->data >= N && root->left->data < N))
        return root->data;
 
    // if node value is smaller than N search in the
    // right subtree
    if (root->right!=NULL and root->data <= N)
        return find_lowest_higher(root->right, N);
 
    // if node value is greater than N search in the
    // left subtree
    else if(root->left!=NULL)
        return find_lowest_higher(root->left, N);
}


void sort_interval(Node *root, int k1, int k2)
{
    /* base case */
    if ( NULL == root )
        return;
     
    /* Since the desired o/p is sorted,
        recurse for left subtree first
        */
      
    sort_interval(root->left, k1, k2);
     
    /* if root's data lies in range,
    then prints root's data */
    if ( k1 <= root->data && k2 >= root->data )
        fout<<root->data<<" ";
     
    /* recursively call the right subtree */
   sort_interval(root->right, k1, k2);
}
 



void print(Node* root)
{

    if(root == NULL)
    {
        return;
    }

    print(root->left);
    cout<<root->data<<" ";
    print(root->right);

}





int main()
{



Node* root = nullptr;

int op_num;

fin >> op_num;



int val;
int val2;

while (op_num)
{
    int op;
    fin >> op;

    if (op == 1 && root == nullptr)
        fin >> val, root = newNode(val);

    else if (op == 1)
        fin >> val, insert(root, val);

    else if (op == 2)
        fin >> val, deleteNode(root, val);

    else if (op == 3)
    {
        fin >> val;
        Node* found = search(root, val);
        if (found != NULL)
            fout << 1 << endl;
        else
            fout << 0 << endl;
    }

    else if (op == 4)
    {
        fin >> val;
        fout<<find_lowest_higher(root, val)<<endl;
    }

    else if (op == 5)
    {
        fin>>val;
        fout<<find_highest_lower(root, val)<<endl;
    }

    else
        fin >> val >> val2, sort_interval(root, val, val2), fout << endl;

    op_num--;
}




return 0;



}
