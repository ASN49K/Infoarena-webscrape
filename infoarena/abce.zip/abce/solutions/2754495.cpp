#include <iostream>
#include <fstream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

#define xmax 1000000001

struct nod
{
    int val;
    nod *st, *dr, *tata;
    nod(): val(0), st(nullptr), dr(nullptr), tata(nullptr) {}
    explicit nod(int valoare, nod *s = nullptr, nod *d  = nullptr, nod *t  = nullptr): val(valoare), st(s), dr(d), tata(t) {}
};

class SplayTree
{
private:
    nod *radacina;
public:
    SplayTree(): radacina(nullptr) {};
    static nod* creeaza_nod(int x, nod* n)
    {
        nod* aux = new nod(x, nullptr, nullptr, n);
        return aux;
    }

    void rotatie_dreapta(nod* A)
    {
        nod* B = A->st;
        if (A->st != nullptr) A->st = B->dr;
        if (B->dr != nullptr) B->dr->tata = A;
        B->tata = A->tata;
        if (A->tata == nullptr) radacina = B;
        else if (A->tata->st == A) A->tata->st = B;
        else A->tata->dr = B;
        B->dr = A;
        A->tata = B;
    }

    void rotatie_stanga(nod* A)
    {
        nod* B = A->dr;
        if (A->dr != nullptr) A->dr = B->st;
        if (B->st != nullptr) B->st->tata = A;
        B->tata = A->tata;
        if (A->tata == nullptr) radacina = B;
        else if (A->tata->st == A) A->tata->st = B;
        else A->tata->dr = B;
        B->st = A;
        A->tata = B;
    }

    void splay(nod* x)
    {
        if (x == nullptr) return;
        while (x->tata != nullptr)
            if (x->tata->tata == nullptr)
            {
                if (x->tata->st == x) rotatie_dreapta(x->tata);
                else rotatie_stanga(x->tata);
            }
            else if (x->tata->st == x)
            {
                if (x->tata->tata->st == x->tata)
                {
                    rotatie_dreapta(x->tata->tata);
                    rotatie_dreapta(x->tata);
                }
                else
                {
                    rotatie_dreapta(x->tata);
                    rotatie_stanga(x->tata);
                }
            }
            else
            {
                if (x->tata->tata->dr == x->tata)
                {
                    rotatie_stanga(x->tata->tata);
                    rotatie_stanga(x->tata);
                }
                else
                {
                    rotatie_stanga(x->tata);
                    rotatie_dreapta(x->tata);
                }
            }
    }

    static nod* nod_min(nod* c)
    {
        while (c->st != nullptr) c = c->st;
        return c;
    }

    nod* getRadacina() const
    {
        return radacina;
    }

    void inserare(int x)
    {
        if(radacina == nullptr)
        {
            radacina = creeaza_nod(x, nullptr);
            return;
        }
        nod *n = radacina, *tata= nullptr ;
        while(n != nullptr)
        {
            tata = n;
            if(x < n->val)
            {
                n = n->st;
            }
            else
            {
                n = n->dr;
            }
        }
        nod* nod_nou = creeaza_nod(x, tata);
        if(x < tata->val) tata->st = nod_nou;
        else tata->dr = nod_nou;
        splay(nod_nou);
    }

    void stergere(int x)
    {
        nod* n = cautare(x), *tata;
        if(n != nullptr) tata = n->tata;
        if(n == nullptr) return;
        if(n->st == nullptr && n->dr == nullptr)
        {
            if(n != radacina)
                if(tata->st == n) tata->st = nullptr;
                else tata->dr = nullptr;
            else radacina = nullptr;
            delete n;
        }
        else if (n->st != nullptr && n->dr != nullptr)
        {
            nod* succesor = nod_min(n->dr);
            int val_succ = succesor->val;
            stergere(succesor->val);
            n->val = val_succ;
        }
        else
        {
            nod* fiu;
            if(n->st != nullptr) fiu = n->st;
            else fiu = n->dr;
            if (n != radacina)
            {
                if (n == tata->st) tata->st = fiu;
                else  tata->dr = fiu;
                fiu->tata = tata;
            }
            else
            {
                radacina = fiu;
                fiu->tata = nullptr;
            }
            delete n;
        }
    }

    nod* cautare(int x)
    {
        nod* n = radacina;
        while(n != nullptr && n->val != x)
        {
            if(x < n->val) n = n->st;
            else n = n->dr;
        }
        splay(n);
        return n;
    }

    int succesor(int x)
    {
        nod* n = radacina, *nn = nullptr;
        int dif = xmax;
        while(n != nullptr)
        {
            if(n->val == x)
            {
                splay(n);
                return n->val;
            }
            if(n->val > x && n->val - x < dif)
            {
                dif = n->val - x;
                nn = n;
            }
            if(x < n->val)
            {
                n = n->st;
            }
            else
            {

                n = n->dr;
            }
        }
        splay(nn);
        return nn->val;
    }

    int predecesor(int x)
    {
        nod* n = radacina, *nn = nullptr;
        int dif = xmax;
        while(n != nullptr)
        {
            if(n->val == x)
            {
                splay(n);
                return n->val;
            }
            if(n->val < x && x - n->val < dif)
            {
                dif = x - n->val;
                nn = n;
            }
            if(x < n->val)
            {
                n = n->st;
            }
            else
            {

                n = n->dr;
            }
        }
        splay(nn);
        return nn->val;
    }
    void afisare(nod *n, int x, int y)
    {
        if(n == nullptr) return;
        if(n->val >= x) afisare(n->st, x, y);
        if(n->val >=x && n->val <= y)g<< n->val << ' ';
        if(n->val <= y) afisare(n->dr, x, y);
    }
};

int main()
{
    SplayTree T;
    int n, x, y;
    char c;
    f >> n;
    for(int i = 1; i <= n; i++)
    {
        f >> c >> x;
        if(c == '1') T.inserare(x);
        else if(c == '2') T.stergere(x);
        else if(c == '3')
        {
            if (T.cautare(x) == nullptr)
            {
                g << "0\n";
            }
            else g << "1\n";
        }
        else if(c == '4') g << T.predecesor(x) << '\n';
        else if(c == '5') g << T.succesor(x) << '\n';
        else
        {
            f >> y;
            T.afisare(T.getRadacina(), x, y);
            g << "\n";
        }
    }
    return 0;
}
