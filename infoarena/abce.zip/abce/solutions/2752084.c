#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define swap(a, b) {void *aux = a; a = b; b = aux;}

typedef struct Node{
    struct Node *parent;
    struct Node *left, *right;

    int key; ///0-bleck, 1-red
    void *info;
} *Node, NodeVal;

void rotateLeft(Node*);
void rotateRight(Node*);
void fixN(Node);
void fixsonl(Node);
void fixsonr(Node);
Node initN(void*, Node);
void insertN(Node*, Node, void*, int (*Comp)(void*, void*));
Node biggestsmallerN(Node, void*, int (*Comp)(void*, void*));
Node smallestbiggerN(Node, void*, int (*Comp)(void*, void*));
Node findN(Node, void*, int (*Comp)(void*, void*));
void eraseN(Node*, void*, int (*Comp)(void*, void*), void (*Free)(void*));
void destroyN(Node*, void (*Free)(void*));
void showN(Node, void*, void*, int (*Comp)(void*, void*), void (*Show)(void*, FILE*), FILE*);

typedef struct Treap{
    Node root;

    int (*Comp)(void*, void*);
    void (*Show)(void*, FILE*);
    void (*Free)(void*);
} *Treap, TreapVal;

Treap initT(int (*Comp)(void*, void*), void (*Show)(void*, FILE*), void (*Free)(void*));
void insertT(Treap*, void*);
int findT(Treap, void*);
void smallestbiggerT(Treap, void*, FILE*);
void biggestsmallerT(Treap, void*, FILE*);
void eraseT(Treap*, void*);
void showT(Treap, void*, void*, FILE*);

/// Int functions ///
int CompInt(void *a, void *b)
{
    return *(int*)a - *(int*)b;
}

void ShowInt(void *a, FILE *fout)
{
    fprintf(fout, "%d", *(int*)a);
}

void FreeInt(void *a)
{
    free(a);
}

/// main ///
int main()
{

    srand(time(0));
    FILE *fin = fopen("abce.in", "r");
    FILE *fout = fopen("abce.out", "w");

    int Q;
    fscanf(fin, "%d", &Q);

    Treap treap = initT(CompInt, ShowInt, FreeInt);

    while (Q--) {
        int task;
        fscanf(fin, "%d", &task);

        switch(task) {
            case 1: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                insertT(&treap, (void*)val);
                break;
            }
            case 2: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                eraseT(&treap, (void*)val);
                break;
            }
            case 3: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                fprintf(fout, "%d\n", findT(treap, (void*)val));
                break;
            }
            case 4: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                biggestsmallerT(treap, val, fout);
                break;
            }
            case 5: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                smallestbiggerT(treap, val, fout);
                break;
            }
            default: {
                int *a = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", a);

                int *b = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", b);

                showT(treap, (void*)a, (void*)b, fout);
            }
        }
        //printf("1\n");
        while (treap->root && treap->root->parent) {
            treap->root = treap->root->parent;
        }
        if (treap->root && treap->root->key) {
            treap->root->key ^= 1;
        }
    }

    return 0;
}

/// Node functions ///
Node initN(void *info, Node parent)
{
    Node ret = (Node)malloc(sizeof(NodeVal));

    ret->parent = parent;
    ret->left = ret->right = NULL;
    ret->info = info;
    ret->key = 1;

    return ret;
}

void rotateLeft(Node *node)
{
    Node placeholder = (*node)->right->left;
    Node end = (*node)->right;
    end->left = *node;

    end->parent = (*node)->parent;
    if ((*node)->parent) {
        if ((*node)->parent->left == *node) {
            (*node)->parent->left = end;
        } else {
            (*node)->parent->right = end;
        }
    }

    (*node)->parent = end;
    (*node)->right = placeholder;
    if (placeholder) {
        placeholder->parent = *node;
    }
    *node = end;
}

void rotateRight(Node *node)
{
    Node placeholder = (*node)->left->right;
    Node end = (*node)->left;
    end->right = *node;
    end->parent = (*node)->parent;

    if ((*node)->parent) {
        if ((*node)->parent->left == *node) {
            (*node)->parent->left = end;
        } else {
            (*node)->parent->right = end;
        }
    }

    (*node)->parent = end;
    (*node)->left = placeholder;
    if (placeholder) {
        placeholder->parent = *node;
    }
    *node = end;
}

void fixN(Node node)
{
    if (!node || !(node->parent)) {
        return;
    }

    if (node->key ^ node->parent->key) {
        return;
    }

    Node parent = node->parent;
    Node granpa = parent->parent;
    Node uncle = (granpa->left == parent ? granpa->right : granpa->left);

    if (uncle && uncle->key) {
        uncle->key ^= 1;
        parent->key ^= 1;
        granpa->key ^= 1;
        fixN(granpa);
        return;
    }

    if (granpa->left == parent) {
        if (parent->right == node) {
            rotateLeft(&parent);
            node = parent->left;
        }

        rotateRight(&granpa);
        granpa = granpa->right;

        granpa->key ^= 1;
        parent->key ^= 1;
    } else {
        if (parent->left == node) {
            rotateRight(&parent);
            node = parent->right;
        }

        rotateLeft(&granpa);
        granpa = granpa->left;

        granpa->key ^= 1;
        parent->key ^= 1;
    }

}

void insertN(Node *root, Node parent, void *info, int (*Comp)(void*, void*))
{
    if (!*root) {
        if (parent) {
            *root = initN(info, parent);
            if (Comp(info, parent->info) < 0) {
                parent->left = *root;
            } else {
                parent->right = *root;
            }
        } else {
            *root = initN(info, NULL);
        }

        fixN(*root);
        return;
    }

    if (Comp(info, (*root)->info) < 0) {
        insertN(&((*root)->left), *root, info, *Comp);
    } else {
        insertN(&((*root)->right), *root, info, *Comp);
    }
}

Node biggestsmallerN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    if (Comp(root->info, info) > 0) {
        return biggestsmallerN(root->left, info, *Comp);
    } else {
        Node node = biggestsmallerN(root->right, info, *Comp);
        return (node ? node : root);
    }
}

Node smallestbiggerN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    if (Comp(root->info, info) < 0) {
        return smallestbiggerN(root->right, info, *Comp);
    } else {
        Node node = smallestbiggerN(root->left, info, *Comp);
        return (node ? node : root);
    }
}

Node findN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    int diff = Comp(root->info, info);
    if (!diff) {
        return root;
    } else if (diff < 0) {
        return findN(root->right, info, *Comp);
    } else {
        return findN(root->left, info, *Comp);
    }
}

void fixsonl(Node node)
{
    ///Case 1
    if (node->key) {
        rotateLeft(&node);
        fixN(node->left->right);
        return;
    }

    ///Case 2
    if (node->right->key) {
        rotateLeft(&node);
        node->key = 0;
        node->left->key = 1;
        fixsonl(node->left);
        return;
    }

    ///Case 3
    if (node->right->right && node->right->right->key) {
        rotateLeft(&node);
        node->right->key = 0;
        return;
    }

    ///Case 4
    if (node->right->left && node->right->left->key) {
        rotateRight(&(node->right));
        rotateLeft(&node);
        node->key = 0;
        return;
    }

    ///Case 5
    node->right->key = 1;
    if (node->parent) {
        if (node->parent->left == node) {
            fixsonl(node->parent);
        } else {
            fixsonr(node->parent);
        }
    }
}

void fixsonr(Node node)
{
    ///Case 1
    if (node->key) {
        rotateRight(&node);
        fixN(node->right->left);
        return;
    }

    ///Case 2
    if (node->left->key) {
        rotateRight(&node);
        node->key = 0;
        node->right->key = 1;
        fixsonl(node->right);
        return;
    }

    ///Case 3
    if (node->left->left && node->left->left->key) {
        rotateRight(&node);
        node->left->key = 0;
        return;
    }

    ///Case 4
    if (node->left->right && node->left->right->key) {
        rotateLeft(&(node->left));
        rotateRight(&node);
        node->key = 0;
        return;
    }

    ///Case 5
    node->left->key = 1;
    if (node->parent) {
        if (node->parent->right == node) {
            fixsonr(node->parent);
        } else {
            fixsonl(node->parent);
        }
    }
}

void eraseN(Node *root, void *info, int (*Comp)(void*, void*), void (*Free)(void*))
{
    Node node = findN(*root, info, *Comp);
    if (!node) {
        return;
    }

    if (node->left && node->right) {
        Node replace = biggestsmallerN(node->left, node->info, *Comp);
        swap(node->info, replace->info);
        node = replace;
    }

    Node parent = node->parent;
    Node replace;
  if (node->left) {
        replace = node->left;
    } else if (node->right) {
        replace = node->right;
    } else {
        replace = NULL;
    }

    if (replace) {
        replace->parent = parent;
    }

    int diff, dir = -1;

    if (node == *root) {
        *root = replace;
    } else {
        if (parent->left == node) {
            parent->left = replace;
            dir = 0;
        } else {
            parent->right = replace;
            dir = 1;
        }

    }

    diff = node->key ^ (replace ? replace->key : 0);
    destroyN(&node, *Free);

    if (diff || replace == *root) {
        if (replace) {
            replace->key = 0;
        }
        return;
    }

    if (!dir) {
        fixsonl(parent);
    } else if (dir == 1) {
        fixsonr(parent);
    }
}

void showN(Node root, void *a, void *b, int (*Comp)(void*, void*), void (*Show)(void*, FILE*), FILE *fout)
{
    if (!root) {
        return;
    }

    showN(root->left, a, b, *Comp, *Show, fout);

    if (Comp(a, root->info) <= 0 && Comp(root->info, b) <= 0) {
        //fprintf(fout, "(");
        Show(root->info, fout);
        //fprintf(fout, ", %d) ", root->key);
        fprintf(fout, " ");
    }

    showN(root->right, a, b, *Comp, *Show, fout);

    //fprintf(fout, "|");
}

void destroyN(Node *node, void (*Free)(void*))
{
    Free((*node)->info);
    free(*node);
    *node = NULL;
}

/// Treap functions ///
Treap initT(int (*Comp)(void*, void*), void (*Show)(void*, FILE*), void (*Free)(void*))
{
    Treap ret = (Treap)malloc(sizeof(TreapVal));

    ret->root = NULL;
    ret->Comp = Comp;
    ret->Show = Show;
    ret->Free = Free;

    return ret;
}

void insertT(Treap *treap, void *info)
{
    insertN(&((*treap)->root), NULL, info, *((*treap)->Comp));
}

int findT(Treap treap, void *info)
{
    return findN(treap->root, info, *(treap->Comp)) != NULL;
}

void smallestbiggerT(Treap treap, void *info, FILE *fout)
{
    void *out = smallestbiggerN(treap->root, info, *(treap->Comp))->info;
    (treap->Show)(out, fout);
    fprintf(fout, "\n");
}

void biggestsmallerT(Treap treap, void *info, FILE *fout)
{
    void *out = biggestsmallerN(treap->root, info, *(treap->Comp))->info;
    (treap->Show)(out, fout);
    fprintf(fout, "\n");
}

void eraseT(Treap *treap, void *info)
{
    eraseN(&((*treap)->root), info, *((*treap)->Comp), *((*treap)->Free));
}

void showT(Treap treap, void *a, void *b, FILE *fout)
{
    showN(treap->root, a, b, *(treap->Comp), *(treap->Show), fout);
    fprintf(fout, "\n");
}
