#include <fstream>
#include <iostream>
#include <bits/stdc++.h>

std::ifstream in("abce.in");
std::ofstream out("abce.out");

struct NodeRedBlack{
    int data;
    std::shared_ptr<NodeRedBlack> parent;
    std::shared_ptr<NodeRedBlack> left;
    std::shared_ptr<NodeRedBlack> right;
    int color;
};

class RedBlack{
private:
    using NodePtr = std::shared_ptr<NodeRedBlack>;
    NodePtr root;
    NodePtr T_null;

    void initializeNULLNode(NodePtr node, NodePtr parent) {
        node->data = int();
        node->parent = parent;
        node->left = T_null;
        node->right = T_null;
        node->color = 0;
    }

    void fixDelete(NodePtr x) {
        NodePtr s;
        while (x != root && x->color == 0) {
            if (x == x->parent->left) {
                s = x->parent->right;
                if (s->color == 1) {
                    s->color = 0;
                    x->parent->color = 1;
                    leftRotate(x->parent);
                    s = x->parent->right;
                }

                if (s->left->color == 0 && s->right->color == 0) {
                    s->color = 1;
                    x = x->parent;
                } else {
                    if (s->right->color == 0) {
                        s->left->color = 0;
                        s->color = 1;
                        rightRotate(s);
                        s = x->parent->right;
                    }

                    s->color = x->parent->color;
                    x->parent->color = 0;
                    s->right->color = 0;
                    leftRotate(x->parent);
                    x = root;
                }
            } else {
                s = x->parent->left;
                if (s->color == 1) {
                    s->color = 0;
                    x->parent->color = 1;
                    rightRotate(x->parent);
                    s = x->parent->left;
                }

                if (s->right->color == 0 && s->right->color == 0) {
                    s->color = 1;
                    x = x->parent;
                } else {
                    if (s->left->color == 0) {
                        s->right->color = 0;
                        s->color = 1;
                        leftRotate(s);
                        s = x->parent->left;
                    }
                    s->color = x->parent->color;
                    x->parent->color = 0;
                    s->left->color = 0;
                    rightRotate(x->parent);
                    x = root;
                }
            }
        }
        x->color = 0;
    }

    void fixInsert(NodePtr k){
        NodePtr u;
        while (k->parent->color == 1) {
            if (k->parent == k->parent->parent->right) {
                u = k->parent->parent->left;
                if (u->color == 1) {
                    u->color = 0;
                    k->parent->color = 0;
                    k->parent->parent->color = 1;
                    k = k->parent->parent;
                } else {
                    if (k == k->parent->left) {
                        k = k->parent;
                        rightRotate(k);
                    }
                    k->parent->color = 0;
                    k->parent->parent->color = 1;
                    leftRotate(k->parent->parent);
                }
            } else {
                u = k->parent->parent->right;

                if (u->color == 1) {
                    u->color = 0;
                    k->parent->color = 0;
                    k->parent->parent->color = 1;
                    k = k->parent->parent;
                } else {
                    if (k == k->parent->right) {
                        k = k->parent;
                        leftRotate(k);
                    }
                    k->parent->color = 0;
                    k->parent->parent->color = 1;
                    rightRotate(k->parent->parent);
                }
            }
            if (k == root) {
                break;
            }
        }
        root->color = 0;
    }

    void deleteNodeHelper(NodePtr node, int key) {

        NodePtr z = T_null;
        NodePtr x, y;
        while (node != T_null){
            if (node->data == key) {
                z = node;
            }

            if (node->data <= key) {
                node = node->right;
            } else {
                node = node->left;
            }
        }

        if (z == T_null) {
            //std::cout<<"Couldn't find key in the tree"<<std::endl;
            return;
        }

        y = z;
        int y_original_color = y->color;
        if (z->left == T_null) {
            x = z->right;
            rbTransplant(z, z->right);
        } else if (z->right == T_null) {
            x = z->left;
            rbTransplant(z, z->left);
        } else {
            y = minimum(z->right);
            y_original_color = y->color;
            x = y->right;
            if (y->parent == z) {
                x->parent = y;
            } else {
                rbTransplant(y, y->right);
                y->right = z->right;
                y->right->parent = y;
            }

            rbTransplant(z, y);
            y->left = z->left;
            y->left->parent = y;
            y->color = z->color;
        }
        if (y_original_color == 0){
            fixDelete(x);
        }
    }


    NodePtr searchTreeHelper(NodePtr node, int key) {
        if (node == T_null || key == node->data) {
            return node;
        }

        if (key < node->data) {
            return searchTreeHelper(node->left, key);
        }
        return searchTreeHelper(node->right, key);
    }

    void printHelper(NodePtr root2, std::string indent, bool last) const {
        if (root2 != T_null) {

            std::cout<<indent;

            if (last) {
                std::cout<<"R----";
                indent += "     ";
            } else {
                std::cout<<"L----";
                indent += "|    ";
            }

            std::string sColor = root2->color?"RED":"BLACK";
            std::cout<<root2->data<<"("<<sColor<<")"<<std::endl;
            printHelper(root2->left, indent, false);
            printHelper(root2->right, indent, true);
        }
    }

    void rbTransplant(NodePtr u, NodePtr v){
        if (u->parent == nullptr) {
            root = v;
        } else if (u == u->parent->left){
            u->parent->left = v;
        } else {
            u->parent->right = v;
        }
        v->parent = u->parent;
    }

    NodePtr minimum(NodePtr node) {
        while (node->left != T_null) {
            node = node->left;
        }
        return node;
    }

    void leftRotate(NodePtr x) {
        NodePtr y = x->right;
        x->right = y->left;
        if (y->left != T_null) {
            y->left->parent = x;
        }
        y->parent = x->parent;
        if (x->parent == nullptr) {
            this->root = y;
        } else if (x == x->parent->left) {
            x->parent->left = y;
        } else {
            x->parent->right = y;
        }
        y->left = x;
        x->parent = y;
    }

    void rightRotate(NodePtr x) {
        NodePtr y = x->left;
        x->left = y->right;
        if (y->right != T_null) {
            y->right->parent = x;
        }
        y->parent = x->parent;
        if (x->parent == nullptr) {
            this->root = y;
        } else if (x == x->parent->right) {
            x->parent->right = y;
        } else {
            x->parent->left = y;
        }
        y->right = x;
        x->parent = y;
    }


public:
    explicit RedBlack() {
        T_null = std::make_shared<NodeRedBlack>();
        initializeNULLNode(T_null, nullptr);
        root = T_null;
    }

    void insert(int key) {
        NodePtr node = std::make_shared<NodeRedBlack>();
        node->parent = nullptr;
        node->data = key;
        node->left = T_null;
        node->right = T_null;
        node->color = 1;

        NodePtr y = nullptr;
        NodePtr x = this->root;

        while (x != T_null) {
            y = x;
            if (node->data < x->data) {
                x = x->left;
            } else {
                x = x->right;
            }
        }

        node->parent = y;
        if (y == nullptr) {
            root = node;
        } else if (node->data < y->data) {
            y->left = node;
        } else {
            y->right = node;
        }

        if (node->parent == nullptr){
            node->color = 0;
            return;
        }

        if (node->parent->parent == nullptr) {
            return;
        }

        fixInsert(node);
    }

    void remove(int data) {
        deleteNodeHelper(this->root, data);
    }


    void search (int key){
        NodePtr result = searchTreeHelper(this->root, key);
        if (result != T_null) {
            out << "1" << std::endl;
        } else {
            out << "0" << std::endl;
        }
    }

    void display() const{
        if (root != T_null) {
            printHelper(root, "", true);
        }
    }

};
int main() {

    RedBlack tree;

    int nr_teste;
    in>>nr_teste;

    for(auto i = 0 ; i < nr_teste ; i++){
        int a, b;
        in >> a >> b;
        if(a == 1){
            tree.insert(b);
        }else if(a == 2){
            tree.remove(b);
        }else if(a == 3){
            tree.search(b);
        }if(a==6){
            int z;
            in>>z;
        }
    }

    return 0;
}

