#include <iostream>
#include <fstream>
#include <vector>
#include <random>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct TreeNode {
    int val;
    TreeNode* right;
    TreeNode* down;

    explicit TreeNode(int x) : val(x), right(nullptr), down(nullptr) {}
};

class SkipList {
public:
    TreeNode* base;
    double chance;
    std::mt19937 gen;
    std::bernoulli_distribution dist;

    explicit SkipList(int lev, double chance) : base(nullptr), chance(chance), gen(std::random_device()()), dist(chance) {
        if (lev > 0) {
            base = new TreeNode(0);
            TreeNode* current = base;

            for (int i = 1; i < lev; ++i) {
                current->down = new TreeNode(0);
                current = current->down;
            }
        }
    }

    bool coinFlip() {
        return dist(gen);
    }


    TreeNode* addNum(int val, TreeNode* node, bool& coinflip) {
        if (node == nullptr) return nullptr;

        TreeNode* current = node;
        TreeNode* insertedNode = nullptr;
        std::vector<TreeNode*> path;
        while (current != nullptr) {
            while (current->right != nullptr && current->right->val < val) {
                current = current->right;
            }
            path.push_back(current);
            current = current->down;
        }

        bool insertHere = true;
        for (auto it = path.rbegin(); it != path.rend() && insertHere; ++it) {
            TreeNode* temp = *it;
            TreeNode* newNode = new TreeNode(val);
            newNode->right = temp->right;
            temp->right = newNode;
            newNode->down = insertedNode;
            insertedNode = newNode;


            insertHere = coinFlip() && coinflip;
        }

        coinflip = insertHere;
        return insertedNode;
    }

    void deleteNum(int val, TreeNode* node) {
        while (node != nullptr) {
            while (node->right != nullptr && node->right->val < val) {
                node = node->right;
            }

            if (node->right != nullptr && node->right->val == val) {
                TreeNode* toDelete = node->right;
                node->right = node->right->right;
                delete toDelete;
            }

            node = node->down;
        }
    }

    bool search(int val, TreeNode* node) {
        while (node != nullptr) {
            while (node->right != nullptr && node->right->val < val) {
                node = node->right;
            }
            if (node->right != nullptr && node->right->val == val) return true;
            node = node->down;
        }
        return false;
    }

    void printRange(int low, int high, TreeNode* node) {
        TreeNode* current = lowerBound(low, node);
        while (current != nullptr && current->val <= high) {
            fout << current->val << " ";
            current = current->right;
        }
        fout << "\n";
    }

    void printNumbers(TreeNode* node){
        while (node != nullptr) {
            fout << node->val << " -> ";
            node = node->right;
        }
        fout << "nullptr" << std::endl << std::flush;
    }

    TreeNode* lowerBound(int val, TreeNode* node) {
        TreeNode* best = nullptr;
        while (node != nullptr) {
            TreeNode* current = node;
            while (current != nullptr && current->val < val) {
                current = current->right;
            }
            if (current != nullptr) {
                best = current;
            }
            node = node->down;
        }
        return best;
    }

    TreeNode* upperBound(int val, TreeNode* node) {
        TreeNode* best = nullptr;
        while (node != nullptr) {
            TreeNode* current = node;
            while (current != nullptr && current->val <= val) {
                best = current;
                current = current->right;
            }
            node = node->down;
        }
        fout << best -> val << "\n";
        return best;
    }

    ~SkipList() {
        while (base != nullptr) {
            TreeNode* nextLevel = base->down;

            TreeNode* current = base;
            while (current != nullptr) {
                TreeNode* nextNode = current->right;
                delete current;
                current = nextNode;
            }

            base = nextLevel;
        }
    }

    [[nodiscard]] TreeNode* get_base() const {
        return base;
    }
    [[nodiscard]] double get_chance() const {
        return chance;
    }
};

int main() {
    int total_numbers;
    fin >> total_numbers;

    SkipList myList(10, 0.5);
    for (int i = 0; i < total_numbers; ++i) {
        int operation;
        fin >> operation;
        int x, y;
        fin >> x;
        bool coinflip = true;

        switch (operation) {
            case 1:
                myList.addNum(x, myList.get_base(), coinflip);
                break;
            case 2:
                myList.deleteNum(x, myList.get_base());
                break;
            case 3:
                if(myList.search(x, myList.get_base())) fout << 1 << "\n";
                else fout << 0 << "\n";
                break;
            case 5:{
                TreeNode* best = myList.lowerBound(x, myList.get_base());
                fout << best -> val << "\n";
                break;
            }
            case 4:
                myList.upperBound(x, myList.get_base());
                break;
            case 6:
                fin >> y;
                myList.printRange(x, y, myList.get_base());
                break;
            default:
                break;
        }
    }
    return 0;
}
