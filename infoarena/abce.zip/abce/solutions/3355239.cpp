#include<iostream>
#include<fstream>
#include<random>
#include<ctime>
using namespace std;

struct Node {
    int key, priority;
    Node *leftSon, *rightSon;
    Node(int keyValue) {
        key=keyValue;
        priority=rand();
        leftSon=nullptr;
        rightSon=nullptr;
    }
};

struct Pair {
    Node *leftTree, *rightTree;
};
class Treap {
private:
    Node* root;
    Pair split(Node* currentNode, int splitKey) {
        if (currentNode==nullptr) {
            return {nullptr, nullptr};
        }
        if (currentNode->key <= splitKey) {
            Pair subTrees = split(currentNode->rightSon,splitKey);
            currentNode->rightSon=subTrees.leftTree;
            return {currentNode, subTrees.rightTree};
        }
        else {
            Pair subTrees= split(currentNode->leftSon, splitKey);
            currentNode->leftSon=subTrees.rightTree;
            return {subTrees.leftTree, currentNode};
        }
    }
    Node* merge(Node* leftTree, Node* rightTree) {
        if (!leftTree) return rightTree;
        if (!rightTree) return leftTree;
        if (leftTree->priority>rightTree->priority) {
            leftTree->rightSon=merge(leftTree->rightSon,rightTree);
            return leftTree;
        }
        else {
            rightTree->leftSon=merge(leftTree,rightTree->leftSon);
            return rightTree;
        }
    }
    bool find(Node* currentNode, int searchKey) {
        while (currentNode) {
            if (currentNode->key == searchKey) return true;
            if (searchKey < currentNode->key) {
                currentNode = currentNode->leftSon;
            } else {
                currentNode = currentNode->rightSon;
            }
        }
        return false;
    }
    void inorder(Node* currentNode, int x, int y, ofstream& fout) {
        if (!currentNode) return;
        if (currentNode->key>x) inorder(currentNode->leftSon,x,y,fout);
        if (currentNode->key>=x && currentNode->key<=y) fout <<currentNode->key<<" ";
        if (currentNode->key<y) inorder(currentNode->rightSon,x,y,fout);
    }
public:
    Treap() : root(nullptr){}
    void insert(int key) {
        if (find(root,key)) return;
        Pair p = split(root,key);
        Node* newNode= new Node(key);
        root=merge(merge(p.leftTree, newNode), p.rightTree);
    }
    void remove(int key) {
        if (!find(root,key)) return;
        Pair p1=split(root, key-1);
        Pair p2= split(p1.rightTree, key);
        delete p2.leftTree;
        root = merge(p1.leftTree, p2.rightTree);
    }

    int exists(int key) {
        if (find(root,key)) {
            return 1;
        }else {
            return 0;
        }
    }
    int predecesor(int key) {
        Node* currentNode=root;
        int found=-1;
        while (currentNode) {
            if (currentNode->key<=key) {
                found=currentNode->key;
                currentNode=currentNode->rightSon;
            }
            else {
                currentNode=currentNode->leftSon;
            }
        }
        return found;
    }
    int succesor(int key) {
        Node* currentNode=root;
        int found=-1;
        while (currentNode) {
            if (currentNode->key>=key) {
                found=currentNode->key;
                currentNode=currentNode->leftSon;
            }else {
                currentNode=currentNode->rightSon;
            }
        }
        return found;
    }
    void get_range(int x, int y, ofstream& fout) {
        inorder(root,x,y,fout);
        fout<<"\n";
    }
};
int main() {
    srand(time(0));
    ifstream fin("abce.in");
    ofstream fout("abce.out");

    int Queries;
    if (!(fin>>Queries)) return 0;

    Treap treap;
    while (Queries--) {
        int tip,x,y;
        fin>>tip;
        if (tip==1) {
            fin>>x;
            treap.insert(x);
        }
        else if (tip==2) {
            fin>>x;
            treap.remove(x);
        }
        else if (tip==3) {
            fin>>x;
            fout<<treap.exists(x)<<"\n";
        }
        else if (tip==4) {
            fin>>x;
            fout<<treap.predecesor(x)<<"\n";
        }
        else if (tip==5) {
            fin>>x;
            fout<<treap.succesor(x)<<"\n";
        }
        else if (tip==6) {
            fin>>x>>y;
            treap.get_range(x,y,fout);
        }
    }
    return 0;
}