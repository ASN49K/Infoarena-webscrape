#include <fstream>
#include <vector>

class node {
public:
    int data;
    node *parent;
    node *left;
    node *right;
    int color;

    explicit node(int value) : data(value), parent(nullptr), left(nullptr), right(nullptr), color(1) {}
};

class RedBlackTree {
public:
    node* root;
    node* nullNode;

private:
    node* searchTreeHelper(node* current, int key) {
        if (current == nullNode || key == current->data) {
            return current;
        }

        if (key < current->data) {
            return searchTreeHelper(current->left, key);
        }
        return searchTreeHelper(current->right, key);
    }

    // For balancing the tree after deletion
    void deleteFix(node* target) {
        node* sibling;
        while (target != root && target->color == 0) {
            if (target == target->parent->left) {
                sibling = target->parent->right;
                if (sibling->color == 1) {
                    sibling->color = 0;
                    target->parent->color = 1;
                    leftRotate(target->parent);
                    sibling = target->parent->right;
                }

                if (sibling->left->color == 0 && sibling->right->color == 0) {
                    sibling->color = 1;
                    target = target->parent;
                } else {
                    if (sibling->right->color == 0) {
                        sibling->left->color = 0;
                        sibling->color = 1;
                        rightRotate(sibling);
                        sibling = target->parent->right;
                    }

                    sibling->color = target->parent->color;
                    target->parent->color = 0;
                    sibling->right->color = 0;
                    leftRotate(target->parent);
                    target = root;
                }
            } else {
                sibling = target->parent->left;
                if (sibling->color == 1) {
                    sibling->color = 0;
                    target->parent->color = 1;
                    rightRotate(target->parent);
                    sibling = target->parent->left;
                }

                if (sibling->right->color == 0 && sibling->left->color == 0) {
                    sibling->color = 1;
                    target = target->parent;
                } else {
                    if (sibling->left->color == 0) {
                        sibling->right->color = 0;
                        sibling->color = 1;
                        leftRotate(sibling);
                        sibling = target->parent->left;
                    }

                    sibling->color = target->parent->color;
                    target->parent->color = 0;
                    sibling->left->color = 0;
                    rightRotate(target->parent);
                    target = root;
                }
            }
        }
        target->color = 0;
    }

    void rbTransplant(node* node1, node* node2) {
        if (node1->parent == nullptr) {
            root = node2;
        } else if (node1 == node1->parent->left) {
            node1->parent->left = node2;
        } else {
            node1->parent->right = node2;
        }
        node2->parent = node1->parent;
    }

    void deleteNodeHelper(node* current, int key) {
        node* target = nullNode;
        node* x; node* replacement;
        while (current != nullNode) {
            if (current->data == key) {
                target = current;
            }

            if (current->data <= key) {
                current = current->right;
            } else {
                current = current->left;
            }
        }

        if (target == nullNode) {
            return;
        }

        replacement = target;
        int y_original_color = replacement->color;
        if (target->left == nullNode) {
            x = target->right;
            rbTransplant(target, target->right);
        } else if (target->right == nullNode) {
            x = target->left;
            rbTransplant(target, target->left);
        } else {
            replacement = minimum(target->right);
            y_original_color = replacement->color;
            x = replacement->right;
            if (replacement->parent == target) {
                x->parent = replacement;
            } else {
                rbTransplant(replacement, replacement->right);
                replacement->right = target->right;
                replacement->right->parent = replacement;
            }

            rbTransplant(target, replacement);
            replacement->left = target->left;
            replacement->left->parent = replacement;
            replacement->color = target->color;
        }
        delete target;
        if (y_original_color == 0) {
            deleteFix(x);
        }
    }

    // For balancing the tree after insertion
    void insertFix(node* target) {
        node* uncle;
        while (target->parent->color == 1) {
            if (target->parent == target->parent->parent->right) {
                uncle = target->parent->parent->left;
                if (uncle->color == 1) {
                    uncle->color = 0;
                    target->parent->color = 0;
                    target->parent->parent->color = 1;
                    target = target->parent->parent;
                } else {
                    if (target == target->parent->left) {
                        target = target->parent;
                        rightRotate(target);
                    }
                    target->parent->color = 0;
                    target->parent->parent->color = 1;
                    leftRotate(target->parent->parent);
                }
            } else {
                uncle = target->parent->parent->right;

                if (uncle->color == 1) {
                    uncle->color = 0;
                    target->parent->color = 0;
                    target->parent->parent->color = 1;
                    target = target->parent->parent;
                } else {
                    if (target == target->parent->right) {
                        target = target->parent;
                        leftRotate(target);
                    }
                    target->parent->color = 0;
                    target->parent->parent->color = 1;
                    rightRotate(target->parent->parent);
                }
            }
            if (target == root) {
                break;
            }
        }
        root->color = 0;
    }



public:
    RedBlackTree() {
        nullNode = new node{0};
        nullNode->color = 0;
        root = nullNode;
    }

    node* search(int value){
        node* current = root;

        while(current != nullNode){
            if(value > current->data){
                current = current->right;
            }
            else if(value < current->data){
                current = current->left;
            }
            else{
                break;
            }
        }
        return current;
    }

    node* minimum(node* target) {
        while (target->left != nullNode) {
            target = target->left;
        }
        return target;
    }

    int max(node* current, int N)
{
    if (current == nullNode)
        return NULL;
    if (current->data == N)
        return N;
 
    else if (current->data < N) {
        int k = max(current->right, N);
        if (k == NULL)
            return current->data;
        else
            return k;
    }
 
    else if (current->data > N) 
        return max(current->left, N);    
}
    
    int min(node* current, int N)
{
    if (current->left == nullNode && current->right == nullNode 
                                && current->data < N)
        return NULL;
 
    if ((current->data >= N && current->left == nullNode) 
        || (current->data >= N && current->left->data < N))
        return current->data;
 
    if (current->right!=nullNode && root->data <= N)
        return min(current->right, N);
 
    else if(current->left!=nullNode)
        return min(current->left, N);
}

    void range(std::vector<int>& result, node *root, int k1, int k2)
    {
        if ( root == nullNode )
            return;

        range(result, root->left, k1, k2);

        if ( k1 <= root->data && k2 >= root->data )
            result.push_back(root->data);

        range(result, root->right, k1, k2);
    }

    void leftRotate(node* target) {
        node* right = target->right;
        target->right = right->left;
        if (right->left != nullNode) {
            right->left->parent = target;
        }
        right->parent = target->parent;
        if (target->parent == nullptr) {
            this->root = right;
        } else if (target == target->parent->left) {
            target->parent->left = right;
        } else {
            target->parent->right = right;
        }
        right->left = target;
        target->parent = right;
    }

    void rightRotate(node* target) {
        node* left = target->left;
        target->left = left->right;
        if (left->right != nullNode) {
            left->right->parent = target;
        }
        left->parent = target->parent;
        if (target->parent == nullptr) {
            this->root = left;
        } else if (target == target->parent->right) {
            target->parent->right = left;
        } else {
            target->parent->left = left;
        }
        left->right = target;
        target->parent = left;
    }

    // Inserting a node
    void insert(int key) {
        node* newNode = new node{key};
        newNode->left = nullNode;
        newNode->right = nullNode;

        node* prev = nullptr;
        node* current = root;

        while (current != nullNode) {
            prev = current;
            if (newNode->data < current->data) {
                current = current->left;
            } else {
                current = current->right;
            }
        }

        newNode->parent = prev;
        if (prev == nullptr) {
            root = newNode;
        } else if (newNode->data < prev->data) {
            prev->left = newNode;
        } else {
            prev->right = newNode;
        }

        if (newNode->parent == nullptr) {
            newNode->color = 0;
            return;
        }

        if (newNode->parent->parent == nullptr) {
            return;
        }

        insertFix(newNode);
    }

    void deleteNode(int data) {
        deleteNodeHelper(root, data);
    }

};

int main() {
    RedBlackTree tree;

    std::ifstream fin("abce.in");
    std::ofstream fout("abce.out");

    int n;
    fin >> n;

    for(int i=0; i<n; i++){
        int operation;
        fin >> operation;

        if(operation == 1){
            int value;
            fin >> value;
            tree.insert(value);
        }
        else if(operation == 2){
            int value;
            fin >> value;
            tree.deleteNode(value);
        }
        else if(operation == 3){
            int value;
            fin >> value;
            if (tree.search(value) == tree.nullNode)
            {
                fout << "0\n";
            }
            else{
                fout << "1\n";
            }
        }
        else if(operation == 4){
            int value;  
            fin >> value;

            fout << tree.max(tree.root, value) << "\n";
        }
        else if(operation == 5){
            int value;
            fin >> value;

            fout << tree.min(tree.root, value) << "\n";
        }
        else if(operation == 6){
            int x,y;
            fin >> x >> y;
            std::vector<int> result;

            tree.range(result, tree.root, x,y);

            for(auto& value : result){
                fout << value << " ";
            }
            fout << "\n";
        }
    }
}