//
// Created by Octavian Farcasi on 01.05.2023.
//
#include <iostream>
#include <fstream>
std::ofstream g("abce.out");
class MyAVL{
    public:
        long valoare_nod,height;
        MyAVL *left= nullptr,*right= nullptr;
        MyAVL(long valoare):valoare_nod(valoare){}
};

MyAVL* nod_nou(long valoare){
    MyAVL *nod=new MyAVL(valoare);
    return nod;
}

long max(long x, long y){
    if(x>y)
        return x;
    return y;
}
int find_nod(MyAVL *nod_baza,long valoare){
    while(nod_baza!= nullptr && nod_baza->valoare_nod!=valoare)
        if(nod_baza->valoare_nod<valoare)
            nod_baza= nod_baza->right;
        else
            nod_baza=nod_baza->left;
    if(nod_baza!= nullptr && nod_baza->valoare_nod==valoare)
        return 1;
    return 0;
}

long inaltime(MyAVL *nod) {
    if (nod != nullptr)
        return nod->height;
    return 0;
}

MyAVL* right_rotation(MyAVL *nod1){
    MyAVL *nod2 = nod1->left;
    nod1->left = nod2->right;
    nod2->right = nod1;
    nod1->height = max(inaltime(nod1->left),inaltime(nod1->right)) +1;
    nod2->height = max(inaltime(nod2->left),inaltime(nod2->right)) +1;
    return nod2;
}

MyAVL* left_rotation(MyAVL *nod1){
    MyAVL *nod2 = nod1->right;
    nod1->right = nod2->left;
    nod2->left = nod1;
    nod1->height = max(inaltime(nod1->left),inaltime(nod1->right)) +1;
    nod2->height = max(inaltime(nod2->left),inaltime(nod2->right)) +1;
    return nod2;
}

MyAVL* LRRotate(MyAVL* nod)
{
    nod->left= left_rotation(nod->left);
    return right_rotation(nod);
}
MyAVL* RLRotate(MyAVL* nod)
{
    nod->right = right_rotation(nod->right);
    return left_rotation(nod);
}

MyAVL *inserare_nod(MyAVL *nod_baza, long valoare) {
    if (nod_baza == nullptr)
        return (nod_nou(valoare));
    if (valoare < nod_baza->valoare_nod)
        nod_baza->left = inserare_nod(nod_baza->left, valoare);
    else if (valoare > nod_baza->valoare_nod)
        nod_baza->right = inserare_nod(nod_baza->right, valoare);
    else
        return nod_baza;

    nod_baza->height =1+ max(inaltime(nod_baza->left), inaltime(nod_baza->right));
    long bf = inaltime(nod_baza->left) -inaltime(nod_baza->right);;
    if (bf < -1) {
        if (valoare > nod_baza->right->valoare_nod) {
            return left_rotation(nod_baza);
        } else if (valoare < nod_baza->right->valoare_nod){
            nod_baza->right = right_rotation(nod_baza->right);
            return left_rotation(nod_baza);
        }
    }
    if (bf > 1) {
        if (valoare < nod_baza->left->valoare_nod) {
            return right_rotation(nod_baza);
        } else if (valoare > nod_baza->left->valoare_nod){
            nod_baza->left = left_rotation(nod_baza->left);
            return right_rotation(nod_baza);
        }

    }
    return nod_baza;
}


MyAVL* Predecesor(MyAVL *nod){
    MyAVL *copie=nod;
    while(copie->right!= nullptr)
        copie=copie->right;
    return copie;
}

long next(MyAVL *nod_baza, long valoare){
    long min;
    if(nod_baza->valoare_nod==valoare)
        return valoare;
    if(nod_baza->valoare_nod>valoare)
        min=nod_baza->valoare_nod;
    else{
        while(nod_baza->valoare_nod<valoare)
            nod_baza=nod_baza->right;
        if(nod_baza->valoare_nod==valoare)
            return valoare;
        min=nod_baza->valoare_nod;
    }
    while(nod_baza!= nullptr)
        if(nod_baza->valoare_nod<valoare)
            nod_baza= nod_baza->right;
        else{
            if(nod_baza->valoare_nod==valoare)
                return nod_baza->valoare_nod;
            if(min>nod_baza->valoare_nod)
            {min=nod_baza->valoare_nod;
            }
            nod_baza=nod_baza->left;
        }
    return min;
}

long before(MyAVL *nod_baza, long valoare){
    long max;
    if(nod_baza->valoare_nod==valoare)
        return valoare;
    if(nod_baza->valoare_nod<valoare)
        max=nod_baza->valoare_nod;
    else{
        while(nod_baza->valoare_nod>valoare)
            nod_baza=nod_baza->left;
        if(nod_baza->valoare_nod==valoare)
            return valoare;
        max=nod_baza->valoare_nod;
    }
    while(nod_baza!= nullptr)
        if(nod_baza->valoare_nod>valoare)
            nod_baza= nod_baza->left;
        else{
            if(nod_baza->valoare_nod==valoare)
                return nod_baza->valoare_nod;
            if(max<nod_baza->valoare_nod)
                max=nod_baza->valoare_nod;
            nod_baza=nod_baza->right;
        }
    return max;
}


MyAVL* sterge_nod(MyAVL *nod_baza, long valoare_nod_de_sters){

    if(nod_baza==nullptr)
        return nod_baza;

    if(nod_baza->valoare_nod<valoare_nod_de_sters)
        nod_baza->right=sterge_nod(nod_baza->right,valoare_nod_de_sters);
    else
        if(nod_baza->valoare_nod>valoare_nod_de_sters)
            nod_baza->left=sterge_nod(nod_baza->left,valoare_nod_de_sters);
        else
        {
            if(nod_baza->left== nullptr || nod_baza->right== nullptr){
                MyAVL *copie;
                if(nod_baza->left!= nullptr)
                    copie=nod_baza->left;
                else
                    copie=nod_baza->right;
                if(copie== nullptr){
                    copie=nod_baza;
                    nod_baza= nullptr;
                }else
                    *nod_baza=*copie;
                delete copie;
            }else{
                MyAVL *copie = Predecesor(nod_baza->left);
                nod_baza->valoare_nod = copie->valoare_nod;
                nod_baza->left = sterge_nod(nod_baza->left,copie->valoare_nod);
            }
        }
    if (nod_baza == nullptr)
        return nod_baza;

    nod_baza->height = 1+max(inaltime(nod_baza->left), inaltime(nod_baza->right));
    long bf = inaltime(nod_baza->left) -inaltime(nod_baza->right);
    if (bf < -1) {
        if (inaltime(nod_baza->right->left) -inaltime(nod_baza->right->right)<=0) {
            return left_rotation(nod_baza);
        } else if (valoare_nod_de_sters < nod_baza->right->valoare_nod)
            return RLRotate(nod_baza);
    }
    if (bf > 1) {
        if (inaltime(nod_baza->left->left) -inaltime(nod_baza->left->right)>=0) {
            return right_rotation(nod_baza);
        } else if (valoare_nod_de_sters > nod_baza->left->valoare_nod)
            return LRRotate(nod_baza);
    }
    return nod_baza;
}


void printare_crescator(MyAVL *nod_baza,long val_min, long val_max){
    if(nod_baza== nullptr)
        return;
    if(nod_baza->left!= nullptr)
        printare_crescator(nod_baza->left,val_min,val_max);
    if(nod_baza->valoare_nod<=val_max && nod_baza->valoare_nod>=val_min)
        g<<nod_baza->valoare_nod<<" ";
    if(nod_baza->right!= nullptr)
        printare_crescator(nod_baza->right,val_min,val_max);
}

int main(){
    MyAVL *nod= nullptr;
    std::ifstream f("abce.in");
    long x,y,q;
    f>>q;
    while(q>0){
        f>>y;
        f>>x;
        switch (y) {
            case 1:
                nod= inserare_nod(nod,x);
                break;
            case 2:
                nod= sterge_nod(nod,x);
                break;
            case 3:
                g<<find_nod(nod,x)<<"\n";
                break;
            case 4:
                g<<before(nod,x)<<"\n";
                break;
            case 5:
                g<<next(nod,x)<<"\n";
                break;
            case 6:
                f>>y;
                printare_crescator(nod,x,y);
                g<<"\n";
                break;
            }
        q--;
    }
    f.close();
    g.close();
    while(nod!= nullptr)
        nod= sterge_nod(nod,nod->valoare_nod);
    return 0;
}