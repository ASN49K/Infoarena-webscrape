#include <iostream>
#include <fstream>

class AVLTree {
    private: 
        struct Node {
            int val;
            Node* left;
            Node* right;
            int height = 0;
            Node (int x) {
                val = x;
                left = nullptr;
                right = nullptr;
            }
        };
        Node* root;
        int height(Node* node) {
            if (node == nullptr) {
                return -1;
            }
            return node -> height;
        }
        
        void updateHeight(Node* node) {
            if (node != nullptr) {
                node -> height = 1 + std::max(height(node -> left), height(node -> right));
            }
        }

        bool searchHelper(Node* root, int x) {
            if (root == nullptr) {
                return false;
            }
            else {
                if (root -> val == x) {
                    return true;
                }
                else {
                    if (root -> val > x) {
                        return searchHelper(root -> left, x);
                    }
                    else {
                        return searchHelper(root -> right, x);
                    }
                }
            }
        }

        void addHelper(Node* &root, int x) {
            if (root == nullptr) {
                root = new Node(x);
            }
            else {
                if (x < root -> val) {
                    addHelper(root -> left, x);
                }
                else {
                    addHelper(root -> right, x);
                }
            }
            updateHeight(root);
            balance(root);
        }

        void deleteHelper(Node* &root, int x) {
            if (root != nullptr) {
                if (x < root -> val) {
                    deleteHelper(root -> left, x);
                }
                else if (x > root -> val) {
                    deleteHelper(root -> right, x);
                }
                else {
                    if (root -> left == nullptr && root -> right == nullptr) {
                        Node* temp = root;
                        root = nullptr;
                        delete temp;
                    }
                    else if (root -> left != nullptr && root -> right == nullptr) {
                        Node* temp = root;
                        root = root -> left;
                        delete temp;
                    }
                    else if (root -> right != nullptr && root -> left == nullptr) {
                        Node* temp = root;
                        root = root -> right;
                        delete temp;
                    }
                    else {
                        Node* pred = root -> left;
                        while (pred -> right != nullptr) {
                            pred = pred -> right;
                        }
                        std::swap(root -> val, pred -> val);
                        deleteHelper(root -> left, pred -> val);
                    }
                }
            }
            updateHeight(root);
            balance(root);
        }

        void rotateRight(Node* &node) {
            Node* newRoot = node -> left;
            node -> left = newRoot -> right;
            newRoot -> right = node;
            updateHeight(node);
            updateHeight(newRoot);
            node = newRoot;
        }

        void rotateLeft(Node* &node) {
            Node* newRoot = node -> right;
            node -> right = newRoot -> left;
            newRoot -> left = node;
            updateHeight(node);
            updateHeight(newRoot);
            node = newRoot;
        }

        int balanceFactor (Node* node) {
            if(node == nullptr) return 0;
            return height(node -> left) - height(node -> right);
        }

        void balance(Node* &node) {
            if (node == nullptr) return;
            int bf = balanceFactor(node);

            if (bf > 1) {
                if (balanceFactor(node -> left) >= 0) {
                    rotateRight(node);
                }
                else {
                    rotateLeft(node -> left);
                    rotateRight(node);
                }
            }

            else if (bf < -1) {
                if (balanceFactor(node -> right) <= 0) {
                    rotateLeft(node);
                }
                else {
                    rotateRight(node -> right);
                    rotateLeft(node);
                }
            }
        }

        int predecessorHelper(Node* root, int x) {
            Node* current = root;
            int pred = -1;
            while (current != nullptr) {
                if (current -> val <= x) {
                    pred = current -> val;
                    current = current -> right;
                }
                else {
                    current = current -> left;
                }
            }
            return pred;
        }

        int successorHelper(Node* root, int x) {
            Node* current = root;
            int suc = -1;
            while (current != nullptr) {
                if (current -> val >= x) {
                    suc = current -> val;
                    current = current -> left;
                }
                else {
                    current = current -> right;
                }
            }
            return suc;
        }

        void rangeHelper(Node* node, int x, int y, std::ostream& out) {
            if (node == nullptr) return;
            if (node->val > x) {
                rangeHelper(node -> left, x, y, out);
            }
            if (node -> val >= x && node -> val <= y) {
                out << node->val << " ";
            }
            if (node->val < y) {
                rangeHelper(node -> right, x, y, out);
            }
        }

    public:

        bool search(int x) {
            return searchHelper(root, x);
        }

        void add(int x) {
            addHelper(root, x);
        }

        void del(int x) {
            deleteHelper(root, x);
        }

        int predecessor(int x) {
            return predecessorHelper(root, x);
        }

        int successor(int x) {
            return successorHelper(root, x);
        }

        void range(int x, int y, std::ostream& out) {
            rangeHelper(root, x, y, out);
            out << "\n";
        }

};

int main() {

    std::ifstream fin("abce.in");
    std::ofstream fout("abce.out");

    AVLTree tree;

    int Q, op, x, y;
    fin >> Q;

    while (fin >> op) {
        if (op == 1) {
            fin >> x;
            tree.add(x);
        }
        else if (op == 2) {
            fin >> x;
            tree.del(x);
        }
        else if (op == 3) {
            fin >> x;
            if (tree.search(x)) {
                fout << "1\n";
            }
            else {
                fout << "0\n";
            }
        }
        else if (op == 4) {
            fin >> x;
            fout << tree.predecessor(x) << '\n'; 
        }
        else if (op == 5) {
            fin >> x;
            fout << tree.successor(x) << '\n';
        }
        else if (op == 6) {
            fin >> x >> y;
            tree.range(x, y, fout);
        }
    }
    

    return 0;
}