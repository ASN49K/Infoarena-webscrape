#include <iostream>
#include <fstream>
#include <set>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

int main() {
    set<long long> nums;
    int q;

    fin >> q;

    for (int i = 0; i < q; i++) {
        int op;
        long long value;

        fin >> op >> value;

        if (op == 1) {
            nums.insert(value);
        } else if (op == 2) {
            nums.erase(value);
        } else if (op == 3) {
            if (nums.count(value)) {
                fout << 1 << endl;
            } else {
                fout << 0 << endl;
            }
        } else if (op == 4) {
            auto lower = nums.upper_bound(value);

            if (lower != nums.begin()) {
                --lower;
            }

            fout << *lower << endl;
        } else if (op == 5) {
            fout << *nums.lower_bound(value) << endl;
        } else if (op == 6) {
            long long value2;

            fin >> value2;

            for (auto x : nums) {
                if (x >= value && x <= value2) fout << x << " ";
            }

            fout << endl;
        }
    }
}
