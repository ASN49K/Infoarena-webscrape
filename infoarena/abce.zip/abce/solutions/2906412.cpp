/// RED-BLACK TREE
/// Inserarea unui element

#include <iostream>
#include <queue>
#include <fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

enum Color {RED, BLACK};
/// Nodul este ori rosu, ori negru

struct nod
{
    int data;
    bool color;
    nod *st, *dr, *parent;

    nod(int data)
    {
       this->data = data;
       st = dr = parent = NULL;
       this->color = RED;
    }
};

/// clasa red-black tree
class RBT
{

private:
    nod *rad;

public:

    void rotateSt(nod *&, nod *&);
    void rotateDr(nod *&, nod *&);
    void fixViolation(nod *&, nod *&);
    void inOrd();
    void inNivel();

    RBT() { rad = NULL; }
    void insert(const int &n);

};

/// Functie recursiva pt parcurgerea in ordine
void parcOrd(nod *rad)
{
    if (rad == NULL)
        return;

    parcOrd(rad->st);

    g << rad->data << "  ";

    parcOrd(rad->dr);
}


/// Inserarea nodului nou in arbore
nod* BSTInsert(nod* rad, nod *p)
{
    /// Daca arborele e gol, returnam un nod nou
    /// Altfel, coboram in arbore
    if (rad == NULL)
       return p;

    if (p->data < rad->data)
    {
        rad->st  = BSTInsert(rad->st, p);
        rad->st->parent = rad;
    }
    else if (p->data > rad->data)
    {
        rad->dr = BSTInsert(rad->dr, p);
        rad->dr->parent = rad;
    }

    return rad;
}


/// Functie pt parcurgere pe nivel
void parcNivel(nod *rad)
{
    if (rad == NULL)
        return;

    queue <nod *> q;
    q.push(rad);

    while (!q.empty())
    {
        nod *temp = q.front();
        g << temp->data << "  ";
        q.pop();

        if (temp->st != NULL)
            q.push(temp->st);

        if (temp->dr != NULL)
            q.push(temp->dr);
    }
}

/// Rotire stanga
void RBT::rotateSt(nod *&rad, nod *&p)
{
    nod *p_dr = p->dr;

    p->dr = p_dr->st;

    if (p->dr != NULL)
        p->dr->parent = p;

    p_dr->parent = p->parent;

    if (p->parent == NULL)
        rad = p_dr;

    else if (p == p->parent->st)
        p->parent->st = p_dr;

    else
        p->parent->dr = p_dr;

    p_dr->st = p;
    p->parent = p_dr;
}

/// Rotire Dreapta
void RBT::rotateDr(nod *&rad, nod *&p)
{
    nod *p_st = p->st;

    p->st = p_st->dr;

    if (p->st != NULL)
        p->st->parent = p;

    p_st->parent = p->parent;

    if (p->parent == NULL)
        rad = p_st;

    else if (p == p->parent->st)
        p->parent->st = p_st;

    else
        p->parent->dr = p_st;

    p_st->dr = p;
    p->parent = p_st;
}

/// Fixeaza regula incalcata cauzata de inserare.
/// Cand vom insera, se va incalca regula cu culorile:
/// daca nodul e rosu, acesta are copiii negri si regula
/// ca nodurile radacina este neagra.
void RBT::fixViolation(nod *&rad, nod *&p)
{
    nod *parent_p = NULL;
    nod *grand_parent_p = NULL;

    while ((p != rad) && (p->color != BLACK) &&
           (p->parent->color == RED))
    {

        parent_p = p->parent;
        grand_parent_p = p->parent->parent;


        /// Caz 1: Parintele lui p este fiul din stanga al bunicului lui p
        if (parent_p == grand_parent_p->st)
        {

            nod *uncle_p = grand_parent_p->dr;


            /// Caz 1.1: Daca unchiul lui p este si el rosu, atunci rezolvam problemaa doar recolorandu-i
            if (uncle_p != NULL && uncle_p->color ==
                                                   RED)
            {
                grand_parent_p->color = RED;
                parent_p->color = BLACK;
                uncle_p->color = BLACK;
                p = grand_parent_p;
            }

            else
            {

                /// Caz 1.2: p este copilul din dreapta, atunci rotim spre stanga
                if (p == parent_p->dr)
                {
                    rotateSt(rad, parent_p);
                    p = parent_p;
                    parent_p = p->parent;
                }


                /// Caz 1.3: p este copilul din stanga, atunci rotim spre dreapta
                rotateDr(rad, grand_parent_p);
                swap(parent_p->color,
                           grand_parent_p->color);
                p = parent_p;
            }
        }


        /// Caz 2: Parintele lui p este fiul din dreapta al bunicului lui p
        else
        {
            nod *uncle_p = grand_parent_p->st;



            /// Caz 2.1: Daca unchiul lui p este si el rosu, atunci rezolvam problemaa doar recolorandu-i
            if ((uncle_p != NULL) && (uncle_p->color ==
                                                    RED))
            {
                grand_parent_p->color = RED;
                parent_p->color = BLACK;
                uncle_p->color = BLACK;
                p = grand_parent_p;
            }
            else
            {

                /// Caz 2.2: p este copilul din stanga, atunci rotim spre dreapta
                if (p == parent_p->st)
                {
                    rotateDr(rad, parent_p);
                    p = parent_p;
                    parent_p = p->parent;
                }


                /// Caz 1.3: p este copilul din dreapta, atunci rotim spre stanga
                rotateSt(rad, grand_parent_p);
                swap(parent_p->color,
                         grand_parent_p->color);
                p = parent_p;
            }
        }
    }

    rad->color = BLACK;
}


/// Inserarea unui nod cu o anumita valoare
void RBT::insert(const int &data)
{
    nod *p = new nod(data);

    rad = BSTInsert(rad, p);

    fixViolation(rad, p);
}

/// Parcurgerea in ordine si pe nivel
void RBT::inOrd()     {  parcOrd(rad);}
void RBT::inNivel()  {  parcNivel(rad); }


int main()
{   int i, n, valoare;
    RBT tree;

    f >> n;

    /// In fisier introducem valorile nodurilor pe care dorim sa le inseram
    for(i = 1; i <= n; i++){

        f >> valoare;

        tree.insert(valoare);
    }

    g << "Afisarea in ordine a nodurilor inserate" << endl;
    tree.inOrd();

    g << endl << endl;

    g << "Afisarea pe nivele a nodurilor inserate" << endl;
    tree.inNivel();

    return 0;
}
