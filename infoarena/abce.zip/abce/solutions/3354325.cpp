#include <bits/stdc++.h>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct node {
    int key, priority;
    node *left, *right;

    node (int k){
        key = k;
        priority = rand();
        left = right = nullptr;
    }
};

using pnode = node*;

void split (pnode root, int key, pnode &leftTree, pnode &rightTree){
    if (!root){
        leftTree = rightTree = nullptr;
        return;
    }

    if (root->key <= key){
        split (root->right, key, root->right, rightTree);
        leftTree = root;
    } else{
        split (root->left, key, leftTree, root->left);
        rightTree = root;
    }
}

void merge (pnode &root, pnode leftTree, pnode rightTree){
    if (!leftTree || !rightTree){
        root = leftTree ? leftTree : rightTree;
        return;
    }

    if (leftTree->priority > rightTree->priority){
        merge(leftTree->right, leftTree->right, rightTree);
        root = leftTree;
    } else{
        merge (rightTree->left, leftTree, rightTree->left);
        root = rightTree;
    }
}

bool find(pnode root, int key){
    while (root){
        if (root->key == key)
            return true;
        if (key < root->key)
            root = root->left;
        else
            root = root->right;
    }

    return false;
}

void insert (pnode &root, int key){
    if(find(root, key))
        return;
    
        pnode A, B;
        split(root, key, A, B);

        pnode newNode = new node(key);
        merge(A, A, newNode);
        merge(root, A, B);
}

void eraseNode (pnode & root, int key){
    if (!root)
        return;

    if (root->key == key){
        pnode tmp = root;
        merge (root, root->left, root->right);
        delete tmp;
    } else if(key < root->key){
        eraseNode(root->left, key);
    }else {
        eraseNode(root->right, key);
    }
}

int predecesor(pnode root, int key){
    int ans = -2000000000;

    while (root){
        if (root->key <= key){
            ans = root->key;
            root = root->right;
        } else{
            root = root->left;
        }
    }
    return ans;
}

int succesor ( pnode root, int key){
    int ans = -2000000000;

    while (root){
        if (root->key >= key){
            ans = root->key;
            root = root->left;
        }else {
            root = root->right;
        }
    }
    return ans;
}

void printInterval (pnode root, int x, int y){
    if (!root)
        return;

    if(root->key > x)
        printInterval(root->left, x, y);
    if (x <= root->key && root->key <= y)
        fout << root->key << " ";
    if(root->key < y)
        printInterval(root->right, x, y);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand(time(nullptr));

    int Q;
    fin >> Q;

    pnode root = nullptr;

    while(Q--){
        int type;
        fin >> type;

        if ( type == 1){
            int x;
            fin >> x;
            insert(root,x);
        } else if(type == 2){
            int x;
            fin >> x;
            eraseNode(root, x);
        }else if (type == 3){
            int x;
            fin >> x;
            fout << find(root, x) << '\n';
        } else if (type == 4){
            int x;
            fin >> x;
            fout << predecesor(root, x) << '\n';
        }else if(type == 5){
            int x;
            fin >>x;
            fout << succesor(root, x) << '\n';
        }else if(type == 6){
            int x, y;
            fin >> x >> y;

            printInterval(root, x, y);
            fout << '\n';
        }
    }

    return 0;
}