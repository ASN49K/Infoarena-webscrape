#include <bits/stdc++.h>
#include <sys/time.h>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

namespace rng {
	unsigned int a = 1;
	void srand() {
		struct timeval tv;
		gettimeofday(&tv, nullptr);
		a = (tv.tv_sec ^ tv.tv_usec) | 1;
	}
	void srand(int seed) {
		a = seed;
	}
	int rand() {
		return (a *= 3) >> 1;
	}
};

const int kNil = -1;
const int kOffset = 1e9;
const int kInf = kOffset << 1 | 1;


struct node_t {
	int key, prio, l, r;
	node_t() {}
	node_t(int key) : key(key), prio(rng::rand()), l(kNil), r(kNil) {}
	node_t(int key, int prio) : key(key), prio(prio), l(kNil), r(kNil) {}
};

struct treap {
	vector<node_t> ptr;
	treap() : ptr(1, node_t(kInf, kInf)) {}
	void split(int t, int key, int &l, int &r) {
		if(t == kNil) {
			l = r = kNil;
		} else if(ptr[t].key <= key) {
			split(ptr[t].r, key, ptr[t].r, r);
			l = t;
		} else {
			split(ptr[t].l, key, l, ptr[t].l);
			r = t;
		}
	}
	void merge(int &t, int l, int r) {
		if(l == kNil || r == kNil) {
			t = (l == kNil ? r : l);
		} else if(ptr[l].prio > ptr[r].prio) {
			merge(ptr[l].r, ptr[l].r, r);
			t = l;
		} else {
			merge(ptr[r].l, l, ptr[r].l);
			t = r;
		}
	}
	void insert(int &t, int elem) {
		if(t == kNil) {
			t = elem;
		} else if(ptr[elem].prio > ptr[t].prio) {
			split(t, ptr[elem].key, ptr[elem].l, ptr[elem].r);
			t = elem;
		} else {
			insert(ptr[t].key <= ptr[elem].key ? ptr[t].r : ptr[t].l, elem);
		}
	}
	void insert(int key) {
		ptr.emplace_back(node_t(key));
		insert(ptr[0].l, ptr.size() - 1);
	}
	void erase(int &t, int key) {
		if(ptr[t].key == key) {
			merge(t, ptr[t].l, ptr[t].r);
		} else {
			erase(key < ptr[t].key ? ptr[t].l : ptr[t].r, key);
		}
	}
	void erase(int key) {
		erase(ptr[0].l, key);
	}
	int find(int t, int key) {
		if(t == kNil) {
			return kNil;
		}
		if(ptr[t].key == key) {
			return t;
		}
		return find(key < ptr[t].key ? ptr[t].l : ptr[t].r, key);
	}
	int find(int key) {
		return find(ptr[0].l, key);
	}
	int lowerbound(int t, int key, int res) {
		if(t == kNil) {
			return res;
		}
		if(ptr[t].key == key) {
			return t;
		}
		bool cmp = key < ptr[t].key;
		if(!cmp && (res == kNil || ptr[t].key > ptr[res].key)) res = t;
		int to = cmp ? ptr[t].l : ptr[t].r;
		return lowerbound(to, key, res);
	}
	int lowerbound(int key) {
		return lowerbound(ptr[0].l, key, kNil);
	}
	int upperbound(int t, int key, int res) {
		if(t == kNil) {
			return res;
		}
		if(ptr[t].key == key) {
			return t;
		}
		bool cmp = key < ptr[t].key;
		if(cmp && (res == kNil || ptr[t].key < ptr[res].key)) res = t;
		int to = key < ptr[t].key ? ptr[t].l : ptr[t].r;
		return upperbound(to, key, res);
	}
	int upperbound(int key) {
		return upperbound(ptr[0].l, key, kNil);
	}
	inline int getkey(int t) {
		return ptr[t].key;
	}
	void dump(int t) {
		if(ptr[t].l != kNil) {
			dump(ptr[t].l);
		}
		if(ptr[t].r != kNil) {
			dump(ptr[t].r);
		}
	}
	void dump() {
		dump(ptr[0].l);
	}
};

int main() {
	rng::srand();
	treap ds;
	int q;
	fin >> q;
	while(q--) {
		int op, x;
		fin >> op >> x;
		if(op == 1) {
			ds.insert(x);
		} else if(op == 2) {
			ds.erase(x);
		} else if(op == 3) {
			fout << (ds.find(x) != kNil) << '\n';
		} else if(op == 4) {
			fout << ds.getkey(ds.lowerbound(x)) << '\n';
		} else if(op == 5) {
			fout << ds.getkey(ds.upperbound(x)) << '\n';
		} else {
			int y;
			fin >> y;
			int crt = ds.upperbound(x), key;
			while(crt != kNil && (key = ds.getkey(crt)) <= y) {
				fout << key << " ";
				crt = ds.upperbound(key + 1);
			}
			fout << '\n';
		}
	}
	return 0;
}