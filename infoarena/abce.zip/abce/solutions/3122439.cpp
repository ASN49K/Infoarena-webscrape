// Proiect_2_Treaps_SD.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <ctime>
using namespace std;
//ifstream f("abce.in.txt");
//ofstream g("abce.out.txt");
ifstream f("abce.in");
ofstream g("abce.out");

const int max_int = 2000000001;
class Node
{
public:
    int value;
    unsigned priority;
    Node* left;
    Node* right;
    Node* parent;

public:
    Node() = default;
    Node(const int value)
    {
        this->value = value;
        this->priority = rand() % max_int;
        left = NULL;
        right = NULL;
        parent = NULL;
    }
};
class Treap : private Node
{
private:
    unsigned size;
    Node* begin_;

public:
    Treap()
    {
        size = 0;
        begin_ = NULL;
    }
    //////
    unsigned get_size()
    {
        return this->size;
    }
    Node* get_first()
    {
        return this->begin_;
    }
    //////
private:
    void In_Order(Node* init)
    {
        if (init == NULL)
            return;
        In_Order(init->left);
        cout << init->value << " | " << init->priority << "\n";
        In_Order(init->right);
    }
    bool Max_Heap_Property(Node* init)
    {
        if (init == NULL)
            return true;
        if ((init->left != NULL && init->priority < init->left->priority) || (init->right != NULL && init->priority < init->right->priority))
            return false;
        bool stanga = Max_Heap_Property(init->left);
        bool dreapta = Max_Heap_Property(init->right);
        return (stanga && dreapta);
    }
    Node* Find(const int val)
    {
        Node* temp = this->begin_;
        while (temp != NULL)
        {
            if (temp->value == val)
                return temp;
            if (val < temp->value)
                temp = temp->left;
            else
                temp = temp->right;
        }
        return NULL;
    }
    Node* closest_below(const int y)
    {
        Node* p = this->begin_;
        Node* parent_p = NULL;
        while (p != NULL)
        {
            if (p->value == y)
                return p;
            parent_p = p;
            if (y < p->value)
                p = p->left;
            else
                p = p->right;
        }
        while (parent_p != NULL && parent_p->value > y)
        {
            parent_p = parent_p->parent;
        }
        return parent_p;
    }
    Node* closest_above(const int y)
    {
        Node* p = this->begin_;
        Node* parent_p = NULL;
        while (p != NULL)
        {
            if (p->value == y)
                return p;
            parent_p = p;
            if (y < p->value)
                p = p->left;
            else
                p = p->right;
        }
        while (parent_p != NULL && parent_p->value < y)
        {
            parent_p = parent_p->parent;
        }
        return parent_p;
    }
    //
    Node* find_successor(Node* nd)
    {
        if (nd->right != NULL)
        {
            nd = nd->right;
            while (nd != NULL)
            {
                nd = nd->left;
            }
        }
        else
        {
            int copy_nd_value = nd->value;
            nd = nd->parent;
            while (nd != NULL && copy_nd_value > nd->value)
            {
                nd = nd->parent;
            }
        }
        return nd;
    }
    void delete_BST_case_1_2(Node* p, const int val)
    {
        if (p->left == NULL && p->right == NULL)
        {
            if (p->parent == NULL)
            {
                this->begin_ = NULL;
                delete p;
            }
            else
            {
                Node* del = p;
                p = p->parent;
                del->parent = NULL;
                if (val > p->value)
                    p->right = NULL;
                else
                    p->left = NULL;
                delete del;
            }
        }
        else if (p->left == NULL && p->right != NULL)
        {
            if (p->parent == NULL)
            {
                this->begin_ = this->begin_->right;
                this->begin_->parent = NULL;
                delete p;
            }
            else
            {
                if (p->value < p->parent->value)
                    p->parent->left = p->right;
                else
                    p->parent->right = p->right;

                p->right->parent = p->parent;
                delete p;
            }
        }
        else if (p->left != NULL && p->right == NULL)
        {
            if (p->parent == NULL)
            {
                this->begin_ = this->begin_->left;
                this->begin_->parent = NULL;
                delete p;
            }
            else
            {
                if (p->value < p->parent->value)
                    p->parent->left = p->left;
                else
                    p->parent->right = p->left;

                p->left->parent = p->parent;
                delete p;
            }
        }
    }
    //
public: 
    // private
    Node* insert_BST(const int val)
    {
        this->size++;
        Node* new_p = new Node(val);
        if (begin_ == NULL)
        {
            begin_ = new_p;
            return new_p;
        }
        else
        {
            Node* temp = begin_;
            while (true)
            {
                if (new_p->value < temp->value)
                {
                    if (temp->left != NULL)
                    {
                        temp = temp->left;
                    }
                    else
                    {
                        temp->left = new_p;
                        new_p->parent = temp;
                        return new_p;
                    }
                }
                else
                {
                    if (temp->right != NULL)
                    {
                        temp = temp->right;
                    }
                    else
                    {
                        temp->right = new_p;
                        new_p->parent = temp;
                        return new_p;
                    }
                }
            }
        }
    } 
    //
    void Print_In_Order()
    {
        cout << "Afisare TREAP (value | priority):\n\n";
        In_Order(this->begin_);
        cout << "\n\n";
    }
    void Is_Max_Heap()
    {
        cout << "Max Heap: ";
        if (Max_Heap_Property(this->begin_))
            cout << "Da!\n";
        else
            cout << "Nu!\n";
    }
    bool Value_Found(const int val)
    {
        Node* p = Find(val);
        if (p == NULL)
            return false;
        else
            return true;
    }
    
    int get_closest_above_or_below(const int y, const short choice)
    {
        Node* p;
        if (choice == 4)
        {
            p = closest_below(y);
            if (p != NULL)
            {
                return p->value;
            }
        }
        else if(choice == 5)
        {
            p = closest_above(y);
            if (p != NULL)
            {
                return p->value;
            }
        }
        return max_int;
    }

    
    //
    void delete_BST(const int val)
    {
        Node* p = Find(val);
        if (p == NULL)
            return;
        
        if(p->left != NULL && p->right != NULL)
        {
            Node* copy_p = p;
            p = find_successor(p);
            copy_p->value = p->value;
            copy_p->priority = p->priority;
        }
        delete_BST_case_1_2(p, val);
        this->size--;
    }
    //
    //////
/*
    void pushBack(const int num)
    {
        Node* new_node = new Node(num);
        if (begin_ == NULL)
        {
            begin_ = new_node;
        }
        else
        {
            end_->next = new_node;
            new_node->prev = end_;
        }
        end_ = new_node;
        size++;
    }
    void popBack()
    {
        if (end_ != NULL)
        {
            Node* py = end_;
            end_ = end_->prev;
            end_->next = NULL;
            delete py;
            size--;
        }
    }
    //
    void pushFront(const int num)
    {
        Node* new_node = new Node(num);
        if (begin_ == NULL)
        {
            end_ = new_node;
        }
        else
        {
            new_node->next = begin_;
            begin_->prev = new_node;
        }
        begin_ = new_node;
        size++;
    }
    void popFront()
    {
        if (end_ != NULL)
        {
            Node* py = begin_;
            begin_ = begin_->next;
            begin_->prev = NULL;
            delete py;
            size--;
        }
    }
    //
    void delete_at(const unsigned pos)
    {
        if (pos >= size)
            return;
        else if (pos == size - 1)
            popBack();
        else if (pos == 0)
            popFront();
        else
        {
            Node* p = find_pos(pos);
            p->prev->next = p->next;
            p->next->prev = p->prev;
            delete p;
            size--;
        }
    }
    void insert_value_at(const int num, const unsigned pos)
    {
        if (pos > size)
            return;
        else if (pos == size)
            pushBack(num);
        else if (pos == 0)
            pushFront(num);
        else
        {
            Node* new_node = new Node(num);
            Node* p = find_pos(pos);
            new_node->prev = p->prev;
            new_node->next = p;
            p->prev->next = new_node;
            p->prev = new_node;
            size++;
        }
    }
    Node* find_value(const int num)
    {
        Node* p = begin_;
        while (p != NULL)
        {
            if (p->value == num)
                return p;
            p = p->next;
        }
        return p;
    }
    Node* find_pos(const unsigned pos)
    {
        if (pos >= size)
            return NULL;
        unsigned count;
        Node* current;
        if (pos < size / 2)
        {
            current = begin_;
            count = 0;
            while (count < pos)
            {
                current = current->next;
                count++;
            }
        }
        else
        {
            current = end_;
            count = size - 1;
            while (count > pos)
            {
                current = current->prev;
                count--;
            }
        }
        return current;
    }
    void replace_value(const int num, const unsigned pos)
    {
        Node* p = find_pos(pos);
        if (p != NULL)
        {
            p->value = num;
        }
    }
    void Print()
    {
        Node* current = begin_;
        while (current != NULL)
        {
            cout << current->value << " ";
            current = current->next;
        }
        delete current;
        cout << "   size: " << this->size << "\n\n";
    }

    void Print_rev()
    {
        Node* current = end_;
        while (current != NULL)
        {
            cout << current->value << " ";
            current = current->prev;
        }
        delete current;
        cout << "   size(rev): " << this->size << "\n\n";
    }
*/
    //////
};
int main()
{
    Treap t;
    int Q;
    f >> Q;
    for (int i = 0; i < Q; i++)
    {
        int cerinta, x;
        f >> cerinta >> x;
        
        switch (cerinta)
        {
        case 1:
            t.insert_BST(x);
            break;
        case 2:
            t.delete_BST(x);
            break;
        case 3:
            // cout << t.Value_Found(x) << "\n";
            g << t.Value_Found(x) << "\n";
            break;
        case 4:
            // cout << x << " " << t.get_closest_above_or_below(x, 4) << "\n";
            g << t.get_closest_above_or_below(x, 4) << "\n";
            break;
        case 5:
            // cout << x << " " << t.get_closest_above_or_below(x, 5) << "\n";
            g << t.get_closest_above_or_below(x, 5) << "\n";
            break;
        case 6:
            int y;
            f >> y;
            break;
        default:
            break;
        }
    }
    f.close();
    ///
    /*
    t.Print_In_Order();
    cout << "Size: " << t.get_size() << "\n";
    t.Is_Max_Heap();
    */
    ///
    g.close();
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
