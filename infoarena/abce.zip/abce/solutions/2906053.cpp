#include <iostream>
#include <fstream>

using namespace std;

#define oo 1000000001

ifstream f("abce.in");
ofstream g("abce.out");

struct Nod{
    int x, y;
    Nod *st, *dr;
} *rad = NULL;

void rotateSt( Nod* &nod )
{
    Nod* dr = nod->dr;
    Nod* drSt = nod->dr->st;
    dr->st = nod;
    nod->dr = drSt;
    nod = dr;
}

void rotateDr( Nod* &nod )
{
    Nod* st = nod->st;
    Nod* stDr = nod->st->dr;
    st->dr = nod;
    nod->st = stDr;
    nod = st;
}

Nod* sterge( Nod *nod, int x )
{
    if( !nod )
        return nod;
    if( x < nod->x )
        nod->st = sterge( nod->st, x );
    else if( x > nod->x )
        nod->dr = sterge( nod->dr, x );
    else if( !nod->st )
    {
        Nod *aux = nod->dr;
        delete nod;
        nod = aux;
    }
    else if( !nod->dr )
    {
        Nod *aux = nod->st;
        delete nod;
        nod = aux;
    }
    else if( nod->st->y < nod->dr->y )
    {
        rotateSt( nod );
        nod->st = sterge( nod->st, x );
    }
    else
    {
        rotateDr( nod );
        nod->dr = sterge( nod->dr, x );
    }
    return nod;
}

Nod* insert( Nod *nod, int x, int y = rand() )
{
    if( !nod )
    {
        Nod *aux = new Nod;
        aux->x = x;
        aux->y = y;
        aux->st = NULL;
        aux->dr = NULL;
        return aux;
    }
    if( x < nod->x )
    {
        nod->st = insert( nod->st, x, y );
        if( nod->st->y > nod->y )
            rotateDr( nod );
    }
    else
    {
        nod->dr = insert( nod->dr, x, y );
        if( nod->dr->y > nod->y )
            rotateSt( nod );
    }
    return nod;
}

/*
void afisareRSD( Nod* nod )
{
    if( !nod )
        return;
    cout << nod->x << " " << nod->y << endl;
    afisareRSD( nod->st );
    afisareRSD( nod->dr );
}
*/

bool cautare( Nod *nod, int x )
{
    if( !nod )
        return false;
    if( nod->x == x )
        return true;
    if( x < nod->x )
        return cautare( nod->st, x );
    return cautare( nod->dr, x );
}

int celMaiMareMaiMic( int x )
{
    rad = insert( rad, x, oo );
    Nod *aux;
    for( aux = rad->st; aux->dr; aux = aux->dr );
    int rasp = aux->x;
    rad = sterge( rad, x );
    return rasp;
}

int celMaiMicMaiMare( int x )
{
    rad = insert( rad, x, oo );
    Nod *aux;
    for( aux = rad->dr; aux->st; aux = aux->st );
    int rasp = aux->x;
    rad = sterge( rad, x );
    return rasp;
}

void afisareSRD( Nod *nod )
{
    if( !nod )
        return;
    afisareSRD( nod->st );
    g << nod->x << " ";
    afisareSRD( nod->dr );
}

void interval( int x, int y )
{
    rad = insert( rad, x, oo );
    rad->dr = insert( rad->dr, y, oo );
    afisareSRD( rad->dr->st );
    g << "\n";
    rad->dr = sterge( rad->dr, y );
    rad = sterge( rad, x );
}

int main()
{
    srand( time( 0 ) );
    int n;
    f >> n;
    for( int i = 0; i < n; ++i )
    {
        int c, x;
        f >> c >> x;
        if( c == 1 )
            rad = insert( rad, x );
        else if( c == 2 )
            rad = sterge( rad, x );
        else if( c == 3 )
            g << cautare( rad, x ) << "\n";
        else if( c == 4 )
            g << celMaiMareMaiMic( x ) << "\n";
        else if( c == 5 )
            g << celMaiMicMaiMare( x ) << "\n";
        else
        {
            int y;
            f >> y;
            interval( x, y );
        }
    }
    return 0;
}