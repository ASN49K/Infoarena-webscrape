#include <iostream>
#include <random>
#include <fstream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class Node
{
public:
    int value;
    int code;
    Node *left, *right;

    Node(int value)
    {
        this->value = value;
        this->code = rand() % 65535;
        this->left = nullptr;
        this->right = nullptr;
    }
};

class Treap
{
private:
    Node *root;

    Node *insertNode(Node *root, int value)
    {
        if (root == nullptr)
        {
            return new Node(value);
        }

        if (value < root->value)
        {
            root->left = insertNode(root->left, value);

            if (root->left->code > root->code)
            {
                root = rotateRight(root);
            }
        }
        else
        {
            root->right = insertNode(root->right, value);

            if (root->right->code > root->code)
            {
                root = rotateLeft(root);
            }
        }

        return root;
    }

    Node *findNode(Node *root, int value)
    {
        if (root == nullptr)
        {
            return nullptr;
        }

        if (value == root->value)
        {
            return root;
        }
        else if (value < root->value)
        {
            return findNode(root->left, value);
        }
        else
        {
            return findNode(root->right, value);
        }
    }

    Node *deleteNode(Node *root, int value)
    {
        if (root == nullptr)
        {
            return root;
        }

        if (value < root->value)
        {
            root->left = deleteNode(root->left, value);
        }
        else if (value > root->value)
        {
            root->right = deleteNode(root->right, value);
        }
        else
        {
            if (root->left == nullptr)
            {
                Node *temp = root->right;
                delete root;
                root = temp;
            }
            else if (root->right == nullptr)
            {
                Node *temp = root->left;
                delete root;
                root = temp;
            }
            else
            {
                if (root->left->code > root->right->code)
                {
                    root = rotateRight(root);
                    root->right = deleteNode(root->right, value);
                }
                else
                {
                    root = rotateLeft(root);
                    root->left = deleteNode(root->left, value);
                }
            }
        }

        return root;
    }

    Node *rotateRight(Node *root)
    {
        Node *newRoot = root->left;
        root->left = newRoot->right;
        newRoot->right = root;
        return newRoot;
    }

    Node *rotateLeft(Node *root)
    {
        Node *newRoot = root->right;
        root->right = newRoot->left;
        newRoot->left = root;
        return newRoot;
    }

    Node *LessThanEqualMax(Node *root, int value)
    {
        if (root == NULL)
            return NULL;
        if (root->value == value)
            return root;
        else if (root->value > value)
        {
            Node *aux = LessThanEqualMax(root->left, value);
            if (aux == NULL)
                return root;
            else
                return aux;
        }
        else if (root->value < value)
            return LessThanEqualMax(root->right, value);

        return NULL;
        //     return LessThanEqualMax(root->left, value);
        // else
        // {
        //     Node *max = LessThanEqualMax(root->right, value);
        //     if (max == NULL || max->value < root->value)
        //         return root;
        //     else
        //         return max;
        // }
    }

    Node *MoreThanEqualMin(Node *root, int value)
    {
        if (root == NULL)
            return NULL;
        if (root->value == value)
            return root;
        else if (root->value < value)
        {
            Node *aux = MoreThanEqualMin(root->right, value);
            if (aux == NULL)
                return root;
            else
                return aux;
        }
        else if (root->value > value)
            return MoreThanEqualMin(root->left, value);
        //     return MoreThanEqualMin(root->right, value);
        // else
        // {
        //     Node *min = MoreThanEqualMin(root->left, value);
        //     if (min == NULL || min->value > root->value)
        //         return root;
        //     else
        //         return min;
        // }
        return NULL;
    }

public:
    Treap()
    {
        this->root = nullptr;
    }

    void insert(int value)
    {
        this->root = insertNode(this->root, value);
    }

    Node *find(int value)
    {
        return findNode(this->root, value);
    }

    void remove(int value)
    {
        this->root = deleteNode(this->root, value);
    }

    void printInOrder(Node *root, int X, int Y)
    {
        if (root == nullptr)
        {
            return;
        }

        printInOrder(root->left, X, Y);
        if (root->value >= X && root->value <= Y)
            fout << root->value << " ";
        printInOrder(root->right, X, Y);
    }

    void printInOrder(int X, int Y)
    {
        printInOrder(this->root, X, Y);
        cout << endl;
    }

    Node *LessThanEqualMax(int value)
    {
        return LessThanEqualMax(root, value);
    }

    Node *MoreThanEqualMin(int value)
    {
        return MoreThanEqualMin(root, value);
    }
};

int main()
{
    Treap t;

    int Q, choice, nr, X, Y;
    fin >> Q;
    Node *exercise = NULL;
    for (int i = 1; i <= Q; i++)
    {
        fin >> choice;
        switch (choice)
        {
        case 1:
            fin >> nr;
            t.insert(nr);
            break;

        case 2:
            fin >> nr;
            t.remove(nr);
            break;

        case 3:
            fin >> nr;
            exercise = t.find(nr);
            if (exercise != NULL)
                fout << "1\n";
            else
                fout << "0\n";
            break;

        case 4:
            fin >> nr;
            exercise = t.LessThanEqualMax(nr);
            fout << exercise->value << endl;
            break;

        case 5:
            fin >> nr;
            exercise = t.MoreThanEqualMin(nr);
            fout << exercise->value << endl;
            break;

        case 6:
            fin >> X >> Y;
            t.printInOrder(X, Y);
            fout << endl;
            break;
        }
    }
    return 0;
}