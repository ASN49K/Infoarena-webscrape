/*
Alexandru Enache (152)
Red-Black Tree

Documentation:
- https://www.geeksforgeeks.org/red-black-tree-set-1-introduction-2/
- https://en.wikipedia.org/wiki/Red%E2%80%93black_tree

*/

#include <vector>

using namespace std;

#include <fstream>
//ifstream cin("input"); ofstream cout("output");
ifstream cin("abce.in"); ofstream cout("abce.out");

class RedBlackTree {

#define RED true
#define BLACK false
#define inf 1e9

private:
	struct Node {
		int val;
		bool color; 
		Node* left, * right, * parent;

		Node(int _val) {
			val = _val;
			color = RED;
			left = nullptr;
			right = nullptr;
			parent = nullptr;
		}

	};

	Node* ROOT = nullptr;


	void leftRotate(Node* now) { //my right becomes my parent
		if (now == nullptr || now->right == nullptr) return;

		Node* right = now->right;
		Node* rightleft = right->left;

		right->left = now;
		right->parent = now->parent;

		if (rightleft != nullptr) rightleft->parent = now;

		now->right = rightleft;
		now->parent = right;
	}

	void rightRotate(Node* now) { //my left becomes my parent
		if (now == nullptr || now->left == nullptr) return;

		Node* left = now->left;
		Node* leftright = left->right;

		left->right = now;
		left->parent = now->parent;

		if (leftright != nullptr) leftright->parent = now;

		now->left = leftright;
		now->parent = left;
	}


	void remakeRoot() {
		if (ROOT == nullptr) return;
		while (ROOT->parent != nullptr) {
			ROOT = ROOT->parent;
		}
		ROOT->color = BLACK;
	}


	void rebalanceInsert(Node* now) {
		while (now->parent != nullptr && now->parent->parent != nullptr && now->parent->color == RED) { //parent si RED and I have a grandparent
			if (now->parent->parent->left == now->parent) { //parent is left of grandparent
			
				if (now->parent->parent->right == nullptr || now->parent->parent->right->color == RED) { //uncle is null or red -> swap
					now->parent->color = BLACK;
					if (now->parent->parent->right)
						now->parent->parent->right->color = BLACK;
					now->parent->parent->color = RED;
				}
				else { //uncle is black

					if (now->parent->right == now) { //triangle
						leftRotate(now->parent);
						now = now->left; //previous parent
					}

					//line
					now->parent->color = BLACK;
					now->parent->parent->color = RED;
					rightRotate(now->parent->parent);

				}

			}
			else { //parent is right of grandparent

				if (now->parent->parent->left == nullptr || now->parent->parent->left->color == RED) { //uncle is null or red -> swap
					now->parent->color = BLACK;
					if (now->parent->parent->left)
						now->parent->parent->left->color = BLACK;
					now->parent->parent->color = RED;
				}
				else { //uncle is black

					if (now->parent->left == now) { //triangle
						rightRotate(now->parent);
						now = now->right; //previous parent
					}

					//line
					now->parent->color = BLACK;
					now->parent->parent->color = RED;
					leftRotate(now->parent->parent);

				}

			}	
		}

		remakeRoot();
	}


	void rebalanceErase(Node* now, Node* parent) {


		while (parent != nullptr) {

			Node* bro = nullptr;
			if (now == parent->left)
				bro = parent->right;
			else
				bro = parent->left;

			if (bro == nullptr) { 
				if (parent->color == RED) { //and parent red
					parent->color = BLACK;
					break;
				}
				now = parent; parent = parent->parent; continue; //go up
			}

			if (bro->color == BLACK) { //bro is BLACK

				if ((bro->left == nullptr || bro->left->color == BLACK) && (bro->right == nullptr || bro->right->color == BLACK)) { //bro has no RED child
					bro->color = RED;
					if (parent->color == RED) { //parent red
						parent->color = BLACK;
						break;
					}
					now = parent; parent = parent->parent; continue; //go up
				}

				if (parent->left == bro) { 
					
					if (bro->right != nullptr && bro->right->color == RED) { 
						//LEFT RIGHT
						bro->color = RED;
						bro->right->color = BLACK;
						leftRotate(bro);
						bro = bro->parent;
					}

					//LEFT LEFT
					bro->left->color = BLACK;
					rightRotate(parent);
					break;
				}
				else { 
					if (bro->left != nullptr && bro->left->color == RED) { 
						//RIGHT LEFT
						bro->color = RED;
						bro->left->color = BLACK;
						rightRotate(bro);
						bro = bro->parent;
					}
					
					//RIGHT RIGHT
					bro->right->color = BLACK;
					leftRotate(parent);
					break;
				}

			}
			else { //bro is RED
				if (parent->left == bro) {
					rightRotate(parent);
					continue;
				}
				else {
					leftRotate(parent);
					continue;
				}
			}
		}

		remakeRoot();
	}

	void makeInterval(Node* now, int MIN, int MAX, vector < int >& ans) {
		if (now == nullptr) return;

		if (now->val >= MIN) makeInterval(now->left, MIN, MAX, ans);

		if (MIN <= now->val && now->val <= MAX) ans.push_back(now->val);

		if (now->val <= MAX) makeInterval(now->right, MIN, MAX, ans);
	}


public:

	void insert(int x) {

		Node* now = new Node(x); //a new RED node

		//search for the parent in the binary search tree
		Node* parent = nullptr;
		Node* node = ROOT;

		while (node != nullptr) {
			parent = node;
			if (x < node->val)
				node = node->left;
			else
				node = node->right;
		}


		if (parent == nullptr)    //if there is no parent -> I am the root
			ROOT = now;
		else if (x < parent->val) //left of the parent
			parent->left = now;
		else                      //right of the parent
			parent->right = now;

		now->parent = parent;

		//rebalance
		rebalanceInsert(now);
	}


	void erase(int x) {
		//search for x

		Node* now = ROOT;
		while (now != nullptr && now->val != x) {
			if (x < now->val) {
				now = now->left;
			}
			else {
				now = now->right;
			}
		}

		if (now == nullptr) return;
		 
		if (now->left != nullptr && now->right != nullptr) { //x has both childs -> search for successor
			Node* successor = now->right;
			while (successor->left != nullptr) {
				successor = successor->left;
			}
			now->val = successor->val;
			now = successor;
		}

		Node* child = nullptr;
		if (now->left != nullptr) child = now->left;
		if (now->right != nullptr) child = now->right;

		if (child != nullptr && (child->color == RED || now->color == RED)) { //either me or my child red -> just delete
			now->val = child->val;
			now->color = BLACK;
			now->left = child->left; if (child->left != nullptr) child->left->parent = now;
			now->right = child->right; if (child->right != nullptr) child->right->parent = now;
			delete child;
			return;
		}

		//double black

		if (now->parent == nullptr) { //root
			ROOT = child;
			delete now;
			return;
		}


		//delete node
		if (now->parent->left == now)
			now->parent->left = child;
		else
			now->parent->right = child;

		if (child != nullptr) child->parent = now->parent;

		Node* parent = now->parent;
		delete now;
		now = child;

		//rebalance
		rebalanceErase(now, parent);
	}

	bool find(int x) {
		Node* now = ROOT;

		while (now != nullptr && now->val != x) {
			if (x < now->val) {
				now = now->left;
			}
			else {
				now = now->right;
			}
		}

		if (now == nullptr) return false;
		return true;
	}

	int predecessor(int x) {
		Node* now = ROOT;

		int ans = -inf;

		while (now != nullptr) {
			if (now->val <= x) {
				ans = max(ans, now->val);
				now = now->right;
			}
			else {
				now = now->left;
			}
		}

		return ans;
	}

	int successor(int x) {
		Node* now = ROOT;

		int ans = inf;

		while (now != nullptr) {
			if (now->val >= x) {
				ans = min(ans, now->val);
				now = now->left;
			}
			else {
				now = now->right;
			}
		}

		return ans;
	}

	vector < int > interval(int MIN, int MAX) {
		vector < int > ans;
		makeInterval(ROOT, MIN, MAX, ans);
		return ans;
	}


#undef RED
#undef BLACK
#undef inf

};



int main() {
	
	RedBlackTree* RB = new RedBlackTree();

	int t;
	cin >> t;

	while (t--) {
		int tip;
		cin >> tip;

		int x;
		cin >> x;

		switch (tip){

		case 1: //insert x
			RB->insert(x);
			break;

		case 2: //erase x
			RB->erase(x);
			break;

		case 3: //find x
			cout << RB->find(x) << '\n';
			break;

		case 4: //predecessor x
			cout << RB->predecessor(x) << '\n';
			break;

		case 5: //successor x
			cout << RB->successor(x) << '\n';
			break;

		case 6: //interval MIN MAX
			int y;
			cin >> y;
			vector < int > ans = RB->interval(x, y);
			for (auto& x : ans) cout << x << " ";
			cout << '\n';
			break;

		}
	}

}