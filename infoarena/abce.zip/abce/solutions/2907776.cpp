#include <bits/stdc++.h>

using namespace std;
ifstream in("abce.in");
ofstream out("abce.out");

struct Nod {
    int continut; // retine valoare
    Nod *parinte;
    Nod *stanga;
    Nod *dreapta;
};

typedef Nod *NodPointer;

struct SplayTree {
    NodPointer radacina;

    void preOrder(NodPointer nod) {
        if (nod != nullptr) {
            cout << nod->continut << " ";
            preOrder(nod->stanga);
            preOrder(nod->dreapta);
        }
    }

    void inOrder(NodPointer nod) {
        if (nod != nullptr) {
            inOrder(nod->stanga);
            cout << nod->continut << " ";
            inOrder(nod->dreapta);
        }
    }

    void postOrder(NodPointer nod) {
        if (nod != nullptr) {
            postOrder(nod->stanga);
            postOrder(nod->dreapta);
            cout << nod->continut << " ";
        }
    }

    NodPointer cautare(NodPointer nod, int valoare) {
        if (nod == nullptr or valoare == nod->continut)
            return nod;
        if (valoare < nod->continut)
            return cautare(nod->stanga, valoare);
        else
            return cautare(nod->dreapta, valoare);
    }

    void stergere(NodPointer nod, int valoare) {
        NodPointer x = nullptr;
        NodPointer t, s;
        while (nod != nullptr) {
            if (nod->continut == valoare)
                x = nod;
            if (nod->continut <= valoare)
                nod = nod->dreapta;
            else
                nod = nod->stanga;
        }

        if (x == nullptr)
            return;
        split(x, s, t);
        if (s->stanga)
            s->stanga->parinte = nullptr;
        radacina = join(s->stanga, t);
        delete (s);
        s = nullptr;
    }

    void stergeNod(int continut) {
        stergere(this->radacina, continut);
    }

    void afisare(NodPointer radacina, int pozitie, int adancime) {
        if (radacina != nullptr) {
            if (radacina->parinte == nullptr)
                out << " ";
            else if (!pozitie)
                out << adancime << " ";
            else out << adancime << " ";
            out << radacina->continut << endl;

            afisare(radacina->stanga, 0, adancime + 1);
            afisare(radacina->dreapta, 1, adancime + 1);
            out << endl;
        }
    }


    void rotireStanga(NodPointer x) {
        NodPointer y = x->dreapta;
        x->dreapta = y->stanga;
        if (y->stanga != nullptr)
            y->stanga->parinte = x;
        y->parinte = x->parinte;
        if (x->parinte == nullptr)
            this->radacina = y;
        else if (x == x->parinte->stanga)
            x->parinte->stanga = y;
        else
            x->parinte->dreapta = y;
        y->stanga = x;
        x->parinte = y;
    }


    void rotireDreapta(NodPointer x) {
        NodPointer y = x->stanga;
        x->stanga = y->dreapta;
        if (y->dreapta != nullptr)
            y->dreapta->parinte = x;
        y->parinte = x->parinte;
        if (x->parinte == nullptr)
            this->radacina = y;
        else if (x == x->parinte->dreapta)
            x->parinte->dreapta = y;
        else
            x->parinte->stanga = y;
        y->dreapta = x;
        x->parinte = y;
    }

    void splay(NodPointer x) {
        while (x->parinte) {
            if (!x->parinte->parinte) {
                if (x == x->parinte->stanga)
                    rotireDreapta(x->parinte);       // rotatie zig
                else
                    rotireStanga(x->parinte);        // rotatie zag
            } else if (x == x->parinte->stanga && x->parinte == x->parinte->parinte->stanga) {      // rotatie zig-zig
                rotireDreapta(x->parinte->parinte);
                rotireDreapta(x->parinte);
            } else if (x == x->parinte->dreapta && x->parinte == x->parinte->parinte->dreapta) {    // rotatie zag-zag
                rotireStanga(x->parinte->parinte);
                rotireStanga(x->parinte);
            } else if (x == x->parinte->dreapta && x->parinte == x->parinte->parinte->stanga) {     // rotatie zig-zag
                rotireStanga(x->parinte);
                rotireDreapta(x->parinte);
            } else {
                rotireDreapta(x->parinte);                                                       // rotatie zag-zig
                rotireStanga(x->parinte);
            }
        }
    }


    NodPointer join(NodPointer s, NodPointer t) {
        if (!s)
            return t;
        if (!t)
            return s;
        NodPointer x = maxim(s);
        splay(x);
        x->dreapta = t;
        t->parinte = x;
        return x;
    }

    // impart arborele in 2 arbori s si t
    void split(NodPointer &x, NodPointer &s, NodPointer &t) {
        splay(x);
        if (x->dreapta) {
            t = x->dreapta;
            t->parinte = nullptr;
        } else
            t = nullptr;
        s = x;
        s->dreapta = nullptr;
        x = nullptr;
    }


    SplayTree() {
        radacina = nullptr;
    }

    // parcurgere Pre-Order
    // Nod -> Subarbore stanga -> Subarbore dreapta
    void parcurgPreorder() {
        preOrder(this->radacina);
    }

    // parcurgere In-Order
    // Subarbore stanga -> Nod -> Subarbore dreapta
    void parcrugInorder() {
        inOrder(this->radacina);
    }

    // parcurgere Post-Order
    // Subarbore stanga -> Subarbore dreapta -> Nod
    void parcurgPostorder() {
        postOrder(this->radacina);
    }

    void cautareNod(int k) {
        NodPointer x = cautare(this->radacina, k);
        if (x == nullptr)
            out << 0 << endl;
        else {
            out << 1 << endl;
            splay(x);
        }
    }

    void inserareNod(int valoare) {

        NodPointer nod = new Nod;
        nod->parinte = nullptr;
        nod->stanga = nullptr;
        nod->dreapta = nullptr;
        nod->continut = valoare;
        NodPointer y = nullptr;
        NodPointer x = this->radacina;
        while (x != nullptr) {
            y = x;
            if (nod->continut < x->continut)
                x = x->stanga;
            else
                x = x->dreapta;
        }

        nod->parinte = y;
        if (y == nullptr)
            radacina = nod;
        else if (nod->continut < y->continut)
            y->stanga = nod;
        else
            y->dreapta = nod;

        splay(nod);
    }

    NodPointer maxim(NodPointer nod) {
        while (nod->dreapta != nullptr)
            nod = nod->dreapta;
        return nod;
    }

    NodPointer minim(NodPointer Nod) {
        while (Nod->stanga != nullptr)
            Nod = Nod->stanga;
        return Nod;
    }

    int cautarePredecesor(NodPointer nod, int x) {
        if (nod == nullptr)
            return -1000000001;
        if (x < nod->continut)
            return cautarePredecesor(nod->stanga, x);
        return max(cautarePredecesor(nod->dreapta, x), nod->continut);
    }

    void predecesor(int x) {
        out << cautarePredecesor(this->radacina, x) << endl;
    }

    int cautareSuccesor(NodPointer nod, int x) {
        if (nod == nullptr)
            return 1000000001;
        if (x > nod->continut)
            return cautareSuccesor(nod->dreapta, x);
        return min(cautareSuccesor(nod->stanga, x), nod->continut);
    }

    void succesor(int x) {
        out << cautareSuccesor(this->radacina, x) << endl;
    }

    void arbore(NodPointer nod, int stanga, int dreapta) {
        if (nod == nullptr)
            return;
        arbore(nod->stanga, stanga, dreapta);
        if (nod->continut >= stanga && nod->continut <= dreapta)
            out << nod->continut << " ";
        arbore(nod->dreapta, stanga, dreapta);
    }

    void arboreFinal(int stanga, int dreapta) {
        arbore(this->radacina, stanga, dreapta);
        out << endl;
    }
};

int main() {
    SplayTree arbore;
    int Q, operatie, X, Y;
    in >> Q;
    for (int i = 0; i < Q; i++) {
        in >> operatie;
        if (operatie == 1) {
            in >> X;
            arbore.inserareNod(X);
        } else if (operatie == 2) {
            in >> X;
            arbore.stergeNod(X);
        } else if (operatie == 3) {
            in >> X;
            arbore.cautareNod(X);
        } else if (operatie == 4) {
            in >> X;
            arbore.predecesor(X);
        } else if (operatie == 5) {
            in >> X;
            arbore.succesor(X);
        } else if (operatie == 6) {
            in >> X >> Y;
            arbore.arboreFinal(X, Y);
        }
    }
    return 0;
}