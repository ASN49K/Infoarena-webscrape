#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct node {
    int key;
    node* left, * right;
};

node* newNode(int key) {
    node* t = new node;
    t->key = key;
    t->left = t->right = nullptr;
    return t;
}

node* rightRotate(node* x) {
    node* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

node* splay(node* root, int key) {
    if (root == nullptr || root->key == key)
        return root;

    if (root->key > key) {
        if (root->left == nullptr)
            return root;
        if (root->left->key > key) {
            root->left->left = splay(root->left->left, key);
            root = rightRotate(root);
        }
        else if (root->left->key < key) {
            root->left->right = splay(root->left->right, key);
            if (root->left->right != nullptr)
                root->left = leftRotate(root->left);
        }
        return (root->left == nullptr) ? root : rightRotate(root);
    }
    else {
        if (root->right == nullptr)
            return root;
        if (root->right->key > key) {
            root->right->left = splay(root->right->left, key);
            if (root->right->left != nullptr)
                root->right = rightRotate(root->right);
        }
        else if (root->right->key < key) {
            root->right->right = splay(root->right->right, key);
            root = leftRotate(root);
        }
        return (root->right == nullptr) ? root : leftRotate(root);
    }
}

node* insert(node* root, int key) {
    if (root == nullptr)
        return newNode(key);
    root = splay(root, key);
    if (root->key == key)
        return root;
    node* t = newNode(key);
    if (root->key > key) {
        t->right = root;
        t->left = root->left;
        root->left = nullptr;
    }
    else {
        t->left = root;
        t->right = root->right;
        root->right = nullptr;
    }
    return t;
}

node* deleteNode(node* root, int key) {
    if (root == nullptr)
        return root;
    root = splay(root, key);
    if (root->key != key)
        return root;
    node* t;
    if (root->left == nullptr) {
        t = root->right;
        delete(root);
        return t;
    }
    else {
        t = root->left;
        while (t->right != nullptr)
            t = t->right;
        t->right = root->right;
        node* newRoot = t;
        delete(root);
        return newRoot;
    }
}

bool search(node* root, int key) {
    root = splay(root, key);
    return (root != nullptr && root->key == key);
}

int findMin(node* root, int key) {
    node* result = nullptr;
    while (root != nullptr) {
        if (root->key >= key) {
            if (result == nullptr || root->key < result->key)
                result = root;
            root = root->left;
        } else {
            root = root->right;
        }
    }
    return (result != nullptr) ? result->key : -1;
}

int findMax(node* root, int key) {
    node* result = nullptr;
    while (root != nullptr) {
        if (root->key <= key) {
            if (result == nullptr || root->key > result->key)
                result = root;
            root = root->right;
        } else {
            root = root->left;
        }
    }
    return (result != nullptr) ? result->key : -1;
}






void inorder(node* root, int low, int high, vector<int>& result) {
    if (root == nullptr)
        return;
    inorder(root->left, low, high, result);
    if (root->key >= low && root->key <= high)
        result.push_back(root->key);
    inorder(root->right, low, high, result);
}

int main() {
    ifstream fin("abce.in");
    ofstream fout("abce.out");
    int Q;
    fin >> Q;
    node* root = nullptr;
    while (Q--) {
        int operation, X, Y;
        fin >> operation >> X;

        switch (operation) {
        case 1:
            root = insert(root, X);
            break;
        case 2:
            root = deleteNode(root, X);
            break;
        case 3:
            fout << search(root, X) << "\n";
            break;
        case 4:
            fout << findMax(root, X) << "\n";
            break;
        case 5:
            fout << findMin(root, X) << "\n";
            break;
        case 6:
            fin >> Y;
            vector<int> result;
            inorder(root, X, Y, result);
            for (int i = 0; i < result.size(); i++)
                fout << result[i] << " ";
            fout << "\n";
            break;
        }
    }
    fin.close();
    fout.close();
    return 0;
}
