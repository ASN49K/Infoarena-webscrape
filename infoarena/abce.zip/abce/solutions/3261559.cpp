#include <iostream>
#include <fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

#define f cin
#define g cout
#define ll long long

class SplayTree {
private:
    struct Node {
        ll val;
        Node* left;
        Node* right;

        Node(ll v) : val(v), left(nullptr), right(nullptr) {}
    };

    Node* root;

    Node* createNode(ll val) {
        return new Node(val);
    }

    Node* rightRotate(Node* root) {
        Node* leftSubTree = root->left;
        root->left = leftSubTree->right;
        leftSubTree->right = root;
        return leftSubTree;
    }

    Node* leftRotate(Node* root) {
        Node* rightSubTree = root->right;
        root->right = rightSubTree->left;
        rightSubTree->left = root;
        return rightSubTree;
    }

    Node* splay(Node* root, ll val) {
        if (!root || root->val == val)
            return root;

        if (root->val > val) {
            if (!root->left)
                return root;

            if (root->left->val > val) {
                root->left->left = splay(root->left->left, val);
                root = rightRotate(root);
            } else if (root->left->val < val) {
                root->left->right = splay(root->left->right, val);
                if (root->left->right)
                    root->left = leftRotate(root->left);
            }

            return (!root->left) ? root : rightRotate(root);
        } else {
            if (!root->right)
                return root;

            if (root->right->val > val) {
                root->right->left = splay(root->right->left, val);
                if (root->right->left)
                    root->right = rightRotate(root->right);
            } else if (root->right->val < val) {
                root->right->right = splay(root->right->right, val);
                root = leftRotate(root);
            }

            return (!root->right) ? root : leftRotate(root);
        }
    }

    void orderInterval(Node* root, ll X, ll Y) {
        if (!root)
            return;
        if (root->val >= X && root->val <= Y) {
            orderInterval(root->left, X, Y);
            g << root->val << " ";
            orderInterval(root->right, X, Y);
        } else if (root->val < X) {
            orderInterval(root->right, X, Y);
        } else {
            orderInterval(root->left, X, Y);
        }
    }

public:
    SplayTree() : root(nullptr) {}

    void insert(ll val) {
        if (!root) {
            root = createNode(val);
            return;
        }
        root = splay(root, val);
        if (root->val == val)
            return;

        Node* n2 = createNode(val);
        if (root->val > val) {
            n2->right = root;
            n2->left = root->left;
            root->left = nullptr;
        } else {
            n2->left = root;
            n2->right = root->right;
            root->right = nullptr;
        }
        root = n2;
    }

    void remove(ll val) {
        if (!root)
            return;

        root = splay(root, val);
        if (root->val != val)
            return;

        Node* temp;
        if (!root->left) {
            temp = root->right;
        } else {
            temp = splay(root->left, val);
            temp->right = root->right;
        }
        delete root;
        root = temp;
    }

    void search(ll val) {
        root = splay(root, val);
        g << (root && root->val == val ? 1 : 0) << "\n";
    }

    int predecessor(ll X) {
        Node* curr = root;
        Node* parent = nullptr;
        while (curr) {
            if (curr->val <= X) {
                parent = curr;
                curr = curr->right;
            } else {
                curr = curr->left;
            }
        }
        return parent ? parent->val : -1;
    }

    int successor(ll X) {
        Node* curr = root;
        Node* parent = nullptr;
        while (curr) {
            if (curr->val >= X) {
                parent = curr;
                curr = curr->left;
            } else {
                curr = curr->right;
            }
        }
        return parent ? parent->val : -1;
    }

    void interval(ll X, ll Y) {
        orderInterval(root, X, Y);
        g << "\n";
    }
};

int main() {
    SplayTree tree;
    ios::sync_with_stdio(false);
    f.tie(nullptr);

    ll q, type, X, Y;
    f >> q;

    while (q--) {
        f >> type >> X;
        switch (type) {
        case 1:
            tree.insert(X);
            break;
        case 2:
            tree.remove(X);
            break;
        case 3:
            tree.search(X);
            break;
        case 4:
            g << tree.predecessor(X) << "\n";
            break;
        case 5:
            g << tree.successor(X) << "\n";
            break;
        case 6:
            f >> Y;
            tree.interval(X, Y);
            break;
        }
    }

    return 0;
}