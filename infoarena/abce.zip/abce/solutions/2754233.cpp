#include<bits/stdc++.h>
using namespace std;


ifstream in ("abce.in");
ofstream out ("abce.out");

struct Node
{
    int key;
    int height;
    Node *left;
    Node *right;
};

///FUNCTIE PT INALTIMEA ARBORELUI
int height(Node *N)
{
    if (N == NULL)
        return 0;
    return N->height;
}


///functie de nod nou care este initial frunza
Node* newNode(int cheie)
{
    Node* node = new Node();
    node->key = cheie;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;

    return node;
}
///functie pt rotatie dreapta a subarborelui cu radacina in y care returneaza noua radacina
Node *rightRotate(Node *&y)
{
    Node *x = y->left;
    Node *T2 = x->right;

    ///Rotatia propriu-zisa
    x->right = y;
    y->left = T2;

    ///Actualizam inaltimea nodurilor cu formula: inaltimea este maximul inaltimilor fiilor +1
    x->height = max(height(x->left),height(x->right)) + 1;
    y->height = max(height(y->left),height(y->right)) + 1;


    ///Returnam noua radacina
    return x;
}

///functie pt rotatie stanga a subarborelui cu radacina in x care returneaza noua radacina(basically inversa functiei anterioare)
Node *leftRotate(Node *&x)
{
    Node *y = x->right;
    Node *T2 = y->left;

    ///Rotatia propriu-zisa
    y->left = x;
    x->right = T2;

    ///Actualizam inaltimea nodurilor cu formula: inaltimea este maximul inaltimilor fiilor +1
    x->height = max(height(x->left),height(x->right)) + 1;
    y->height = max(height(y->left),height(y->right)) + 1;

    ///Returnam noua radacina
    return y;
}

///Aflam factorul de echilibru al nodului N
int BF(Node *&N)
{
    if (N == NULL)
        return 0;

    return height(N->left) - height(N->right);
}


///Functie recursiva de inserare in subarborele cu radacina in node , care returneaza noua radacina
Node* insertn(Node* &node, int cheie)
{
    ///Inserare BST normala
    if (node == NULL)
        return newNode(cheie);

    ///Daca cheia pe care vrem sa o inseram este mai mica decat cea anterioara o inseram in stanga
    if (cheie < node->key)
        node->left = insertn(node->left, cheie);

    ///Altfel o inseram in dreapta
    else if (cheie > node->key)
        node->right = insertn(node->right, cheie);

    ///Nu putem insera chei egale (in avl)(oricum in prb abce este asigurat faptul ca toate keys sunt diferite, deci aici else nu este necesar)
    else
        return node;

    ///Actualizam inaltimea nodului
    node->height = max(height(node->left),height(node->right))+1;


    ///Aflam BF(balance factor) pt nodul tata ca sa vedem daca arborele a ramas sau nu balanced
    int balance = BF(node);


    /// Stanga Stanga
    if (balance > 1 && BF(node->left) >= 0)
        return rightRotate(node);

    ///Stanga Dreapta
    if (balance > 1 && BF(node->left) < 0)
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    ///Dreapta Dreapta
    if (balance < -1 && BF(node->right) <= 0)
        return leftRotate(node);

    /// Dreapta Stanga
    if (balance < -1 && BF(node->right) > 0)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }


    ///Rotatiile(in caz ca nu a ramas balanced)
/*
    ///Stanga Stanga
    if (balance > 1 && cheie < node->left->key)
        return rightRotate(node);

    ///Dreapta Dreapta
    if (balance < -1 && cheie > node->right->key)
        return leftRotate(node);

    ///Stanga Dreapta
    if (balance > 1 && cheie > node->left->key)
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    ///Dreapta Stanga
    if (balance < -1 && cheie < node->right->key)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
*/
    return node;
}

Node * minValueNode(Node* &node)
{
    Node* current = node;

    ///mergem cat de mult in stanga putem ca sa aflam val. minima din arbore
    while (current->left != NULL)
        current = current->left;

    return current;
}


void findPreSuc(Node* &root, Node*& pre, Node*& suc, int cheie)
{

    if (root == NULL)
        return ;

    ///Daca cheia este in radacina
    if (root->key == cheie)
    {
        ///Valoarea maxima din subarborele stang este predecesorul cautat
        if (root->left != NULL)
        {
            Node* tmp = root->left;
            while (tmp->right)
                tmp = tmp->right;
            pre = tmp ;
        }

        ///Valoarea minima din subarborele drept este succesorul cautat
        if (root->right != NULL)
        {
            Node* tmp = root->right ;
            while (tmp->left)
                tmp = tmp->left ;
            suc = tmp ;
        }
        return ;
    }

    ///Daca cheia nu este radacina si este mai mica, ne ducem in subarborele stang
    if (root->key > cheie)
    {
        suc = root ;
        findPreSuc(root->left, pre, suc, cheie);
    }
    ///Altfel ne ducem in subarborele drept
    else
    {
        pre = root ;
        findPreSuc(root->right, pre, suc, cheie);
    }
}

bool ok=0;
bool cautare(Node* &root, int cheie)
{

    if(root!=NULL)
    {
        ///Daca gasim key in radacina am terminat
        if (root->key == cheie)
            ok=1;
        ///Daca e mai mare , cautam in dreapta , altfel in stanga
        else if (root->key < cheie)
            cautare(root->right, cheie);
        else
            cautare(root->left, cheie);

    }
    return ok;
}


///Functie recursiva de stergere a unui nod care returneaza radacina subarborelui modificat
Node* deleteNode(Node* &root,int cheie)
{
    /// Stergere basic a unui nod in BST
    if (root == NULL)
        return root;

    ///Daca cheia pe care vrem s o stergem e mai mica decat cheia din tata, atunci se afla in subarborele stang
    if ( cheie < root->key )
        root->left = deleteNode(root->left, cheie);

    ///Altfel o cautam in subarborele drept
    else if( cheie > root->key )
        root->right = deleteNode(root->right, cheie);

    ///Altfel am gasit o si este nodul pe care vrem sa l stergem
    else
    {
        /// nod cu maxim un fiu
        if( (root->left == NULL) || (root->right == NULL) )
        {

            Node *temp; ///fiul
            if(root->left == NULL)
                temp = root->right;
            else if (root->right == NULL)
                temp = root->right;

            /// daca este frunza(nodul pe care trb sa l stergem)
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp; ///Copiem fiul
                free(temp); ///dezalocam memoria alocata temporar
        }
        ///altfel nodul are 2 fii
        else
        {

            /// Ii gasim succesorul din subarborele drept
            Node* temp = minValueNode(root->right);

            ///Copiem cheia din succesor in nodul cu cheia pe care vrem s o stergem
            root->key = temp->key;

            ///Stergem succesorul in mod recursiv
            root->right = deleteNode(root->right,temp->key);
        }
    }

    ///Daca avem arbore cu un singur nod atunci il returnam
    if (root == NULL)
        return root;

    ///Actualizam inaltimea nodului
    root->height = max(height(root->left),height(root->right)) + 1;

    ///Aflam BF ca sa determinam daca nodul este sau nu balanced
    int balance = BF(root);

    ///Daca nu este balanced ne aflam in unul din cele 4 cazuri

    /// Stanga Stanga
    if (balance > 1 && BF(root->left) >= 0)
        return rightRotate(root);

    ///Stanga Dreapta
    if (balance > 1 && BF(root->left) < 0)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    ///Dreapta Dreapta
    if (balance < -1 && BF(root->right) <= 0)
        return leftRotate(root);

    /// Dreapta Stanga
    if (balance < -1 && BF(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}
///Afisarea elementelor dintre x si y in ordine crescatoare
void InOrder(Node *&root,int k1 , int k2)
{

    if(root!=NULL)
    {
        InOrder(root->left,k1,k2);
        if(root->key>=k1 && root->key<=k2)
        {
            out << root->key << " ";
        }
        InOrder(root->right,k1,k2);

    }
}


int main()
{
    Node *root = NULL,* pre = NULL, *suc = NULL;
    int n;
    int ct=0;
    int x;
    in>>n;
    for( int i=1; i<=n; i++)
    {
        int a;
        in>>a;
        if(a == 1)
        {
            in>>x;
            root=insertn(root,x);
            //else if(root==NULL) root=insertn(root,x);
           // else insertn(root,x);
            //ct++;
        }
        if(a == 2)
        {
            in>>x;
            root = deleteNode(root, x);
        }
        if(a == 3)
        {
            in>>x;
            ok=0;
            out<<cautare(root,x)<<'\n';


        }
        if(a == 4)
        {
            in>>x;
            findPreSuc(root, pre,suc, x);
            out<<pre->key<<'\n';
            pre = NULL;
            suc = NULL;

        }
        if(a == 5)
        {
            in>>x;
            findPreSuc(root, pre,suc, x);
            out<<suc->key<<'\n';
            pre = NULL;
            suc = NULL;
        }
        if(a == 6)
        {
            int y;
            in>>x>>y;
            InOrder(root,x,y);
            out<<'\n';
        }
    }

    return 0;
}
