#include <random>
#include <fstream>
using namespace std;

#define mini -100000000000
#define maxi 100000000000

ifstream fin("abce.in");
ofstream fout("abce.out");
struct Treap
{
    int key, p;
    Treap* left, * right;
};

Treap* NewNode(int x)
{
    Treap* node = new Treap;
    node->key = x;
    node->p = rand();
    node->left = node->right = NULL;
    return node;
}

Treap* right_rot(Treap* y)
{
    Treap* x = y->left;
    y->left = x->right;
    x->right = y;
    return x;
}

Treap* left_rot(Treap* y)
{
    Treap* x = y->right;
    y->right = x->left;
    x->left = y;
    return x;
}

Treap* Insert(Treap* root, int x)
{
    if (!root)
        return NewNode(x);
    if (x <= root->key)
    {
        root->left = Insert(root->left, x);
        if (root->left->p > root->p)
            root = right_rot(root);
    }
    else
    {
        root->right = Insert(root->right, x);
        if (root->right->p > root->p)
            root = left_rot(root);
    }
    return root;
}

int Succesor(Treap* root, int x) {
    if (root == NULL)
        return maxi;
    if (root->key < x)
        return Succesor(root->right, x);
    return min(root->key, Succesor(root->left, x));
}

int Predecesor(Treap* root, int x)
{
    if (root == NULL)
        return mini;
    if (root->key > x)
        return Predecesor(root->left, x);
    return max(root->key, Predecesor(root->right, x));
}


int Search(Treap* node, int x)
{
    if (node == NULL)
        return 0;
    if (node->key == x)
        return 1;
    if (x < node->key)
        return Search(node->left, x);
    if (x > node->key)
        return Search(node->right, x);
}

Treap* Delete(Treap* root, int key)
{
    if (root == NULL) return root;

    if (key < root->key)
        root->left = Delete(root->left, key);
    else if (key > root->key)
        root->right = Delete(root->right, key);

    else if (root->left == NULL)
    {
        Treap* temp = root->right;
        delete(root);
        root = temp;
    }

    else if (root->right == NULL)
    {
        Treap* temp = root->left;
        delete(root);
        root = temp;
    }

    else if (root->left->p < root->right->p)
    {
        root = left_rot(root);
        root->left = Delete(root->left, key);
    }
    else
    {
        root = right_rot(root);
        root->right = Delete(root->right, key);
    }

    return root;
}

void Sortare(Treap* root, int left, int right) {
    if (root == nullptr)
        return;
    Sortare(root->left, left, right);
    if (root->key >= left && root->key <= right)
        fout << root->key << " ";
    Sortare(root->right, left, right);
}


int n;
Treap* r = NULL;
int main()
{
    int opt, x, y;
    fin >> n;
    for (int i = 0; i < n; i++)
    {
        fin >> opt;
        if (opt == 1)
        {
            fin >> x;
            r = Insert(r, x);
        }
        if (opt == 2)
        {
            fin >> x;
            r = Delete(r, x);
        }
        if (opt == 3)
        {
            fin >> x;
            if (Search(r, x))
                fout << 1 << '\n';
            else
                fout << 0 << '\n';
        }
        if (opt == 4)
        {
            fin >> x;
            fout << Succesor(r, x) << '\n';
        }
        if (opt == 5)
        {
            fin >> x;
            fout << Predecesor(r, x) << '\n';
        }
        if (opt == 6)
        {
            fin >> x >> y;
            Sortare(r, x, y);
            fout << '\n';
        }
    }

    return 0;
}
