#include <iostream>
#include <fstream>
#include <queue>

std::ifstream fin("abce.in");
std::ofstream fout("abce.out");

struct nod
{
    struct nod *dr,*st;
    int h,numar;
};

class ARBORE
{
private:
public:
     nod * rad;

    ARBORE(){ this->rad = NULL; }

    int balance( nod *nod1)
    {if(nod1->st && nod1->dr == NULL)
        {
            return nod1->st->h;
        }
        else if(nod1->st && nod1->dr)
        {
            return nod1->st->h - nod1->dr->h;
        }
        else if(nod1->st== NULL && nod1->dr )
        {
            return -nod1->dr->h;
        }
        return 0;
    }
    nod * ll(nod *nod1)
    {
        nod *a= nod1,*b;
        b = a->st;
        a->st = b->dr;
        b->dr = a;
        return b;
    }


    nod * rr(nod *nod1)
    {
        nod *a= nod1,*b;
        b = a->dr;
        a->dr = b->st;
        b->st = a;
        return b;
    }
    nod * lr(nod *nod1)
    {
        nod *a= nod1, *b,*c;

        b = a->st;
        c =a->st->dr;

        b ->dr = c->st;
        a ->st = c->dr;

        c->st = b;
        c ->dr = a;

        return c;
    }

    nod * rl(nod *nod1)
    { nod *a= nod1, *b,*c;

        c =a->dr->st;
        b = a->dr;

        a -> dr = c->st;
        b ->st = c->dr;

        c->dr = b;
        c ->st = a;

        return c;
    }

     nod* stang(nod* nod1)
    {
        while(nod1->st!=NULL)
            nod1 = nod1->st;

        return nod1;
    }

    nod* drept(nod* nod1)
    {
        while(nod1->dr!=NULL)
            nod1 = nod1->dr;
        return nod1;
    }

    nod* insert(nod *radacina,int numar)
    {

        if(radacina==NULL)
        {
            struct nod *n= new struct nod;
            n->numar = numar;
            radacina = n;
            radacina->h = 1;
            radacina->st = radacina->dr = NULL;
            return radacina;
        }
        else
        {
            if(numar < radacina->numar)
                radacina->st = insert(radacina->st,numar);
            else
                radacina->dr = insert(radacina->dr,numar);
        }
        if(radacina->st && radacina->dr)
        {
            if (radacina->st->h < radacina->dr->h)
                radacina->h= radacina->dr->h + 1;
            else
                radacina->h= radacina->st->h + 1;
        }
        else if(radacina->st ==NULL && radacina->dr)
        {
            radacina->h= radacina->dr->h + 1;
        }
        else if(radacina->st && radacina->dr == NULL)
        {
            radacina->h= radacina->st->h + 1;
        }
        else radacina->h= 0;
        if(balance(radacina)==2 && balance(radacina->st)==1)
        {
            radacina = ll(radacina);
        }
        else if(balance(radacina)==-2 && balance(radacina->dr)==-1)
        {
            radacina = rr(radacina);
        }
        else if(balance(radacina)==-2 &&balance(radacina->dr)==1)
        {
            radacina = rl(radacina);
        }
        else if(balance(radacina)==2 && balance(radacina->st)==-1)
        {
            radacina = lr(radacina);
        }
        return radacina;
    }

    int cautare(int numar)
    {
        nod* nod1 = rad;
        while (nod1)
        {
            if (nod1->numar == numar)
                return 1;
            else if (nod1->numar < numar)
                nod1 = nod1->dr;
            else
                nod1 = nod1->st;
        }
        return 0;
    }

    int suf(int numar)
    {
        nod* nod1 = rad, * last = nullptr;
        nod* celMaiApropiat = rad;
        while (nod1)
        {
            last = nod1;
            if (nod1->numar == numar)
                return nod1->numar;
            else if (nod1->numar < numar)
                nod1 = nod1->dr;
            else if (nod1->numar > numar)
            {
                if (celMaiApropiat->numar <numar || celMaiApropiat->numar - numar > nod1->numar - numar)
                    celMaiApropiat = nod1;
                nod1 = nod1->st;
            }
        }
        if (last->numar > numar && celMaiApropiat->numar < numar)
            return last->numar;
        if (last->numar < numar && celMaiApropiat->numar > numar)
            return celMaiApropiat->numar;
        if (last->numar > numar && celMaiApropiat->numar > numar)
        {
            if (last->numar < celMaiApropiat->numar)
                return last->numar;
            return celMaiApropiat->numar;
        }
    }

    int pref(int numar)
    {
        nod* nod1 = rad, * last = nullptr;
        nod* celMaiApropiat = rad;
        while (nod1)
        {
            last = nod1;
            if (nod1->numar == numar)
                return nod1->numar;
            else if (nod1->numar > numar)
                nod1 = nod1->st;
            else if (nod1->numar < numar)
            {
                if (celMaiApropiat->numar > numar ||numar - celMaiApropiat->numar > numar - nod1->numar)
                    celMaiApropiat = nod1;
                nod1 = nod1->dr;
            }
        }
        if (last->numar > numar && celMaiApropiat->numar <numar)
            return celMaiApropiat->numar;
        if (last->numar < numar && celMaiApropiat->numar > numar)
            return last->numar;
        if (last->numar < numar && celMaiApropiat->numar < numar)
        {
            if (last->numar > celMaiApropiat->numar)
                return last->numar;
            return celMaiApropiat->numar;
        }
    }

    nod * del(nod *nod1,int numar)
    {nod *nod3;
//nod *nod2;
        if(nod1->st == NULL && nod1->dr == NULL)
        {
            if(nod1==this->rad)
                this->rad = NULL;
            delete nod1;
            return NULL;
        }

        if(nod1->numar < numar)
        {
            nod1->dr = del(nod1->dr,numar);
        }
        else if(nod1->numar > numar)
        {
            nod1->st = del(nod1->st,numar);
        }
        else
        {
            if(nod1->st != NULL)
            {
                nod3 = drept(nod1->st);
                nod1->numar = nod3->numar;
                nod1->st=del(nod1->st,nod3->numar);
            }
            else
            {
                nod3 = stang(nod1->dr);
                nod1->numar = nod3->numar;
                nod1->dr = del(nod1->dr,nod3->numar);
            }
        }

        if(balance(nod1)==2 && balance(nod1->st)==1)
        {
            nod1 = ll(nod1);
        }
        else if(balance(nod1)==2 && balance(nod1->st)==-1)
        {
            nod1 = lr(nod1);
        }
        else if(balance(nod1)==2 && balance(nod1->st)==0)
        {
            nod1 = ll(nod1);
        }
        else if(balance(nod1)==-2 && balance(nod1->dr)==-1)
        {
            nod1 = rr(nod1);
        }
        else if(balance(nod1)==-2 && balance(nod1->dr)==1)
        {
            nod1 = rl(nod1);
        }
        else if(balance(nod1)==-2 &&balance(nod1->dr)==0)
        {
            nod1 = ll(nod1);
        }
        return nod1;
    }


    void SRD(nod* nod1,int x,int y) const
    {
        if (!nod1)
            return;
        SRD(nod1->st,x,y);
        if(nod1->numar>=x &&nod1->numar<=y)
            fout<<nod1->numar<<" ";
        SRD(nod1->dr,x,y);
    }
    ~ARBORE() {}
};
int main()
{
    ARBORE avl;
    int n,i,nr,x,y;

    fin >> n;
    for (i = 0; i < n; i++)
    {
        fin >>nr;
        if(nr==1)
        {
            fin>>x;
            avl.rad = avl.insert(avl.rad,x);
        }
        else if(nr==2)
        {
            fin>>x;
            avl.rad = avl.del(avl.rad,x);
        }
        else if(nr==3)
        {
            fin>>x;
            fout<<avl.cautare(x)<<'\n';
        }
        else if(nr==4)
        {
            fin>>x;
            fout<<avl.pref(x)<<'\n';
        }
        else if(nr==5)
        {
            fin>>x;
            fout<<avl.suf(x)<<'\n';
        }
        else
        {
            fin>>x>>y;
            avl.SRD(avl.rad,x,y);
            fout<<'\n';
        }
    }
    return 0;
}

