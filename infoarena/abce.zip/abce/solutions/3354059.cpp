#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Node
{
    int valoare, prioritate;
    Node *stanga, *dreapta;
    Node(int x)
    {
        valoare = x;
        prioritate = rand();
        stanga = dreapta = NULL;
    }
};

void rotestestanga(Node* &root)
{
    Node* p = root -> dreapta;
    root -> dreapta = p -> stanga;
    p -> stanga = root;
    root = p;
}

void rotestedreapta(Node* &root)
{
    Node* p = root -> stanga;
    root -> stanga = p -> dreapta;
    p -> dreapta = root;
    root = p;
}

void operatia1(Node* &root, int x)
{
    if(root == NULL)
    {
        root = new Node(x);
    }
    else if(x < root -> valoare)
    {
        operatia1(root -> stanga, x);
        if(root -> stanga -> prioritate > root -> prioritate)
        {
            rotestedreapta(root);
        }
    }
    else if(x > root -> valoare)
    {
        operatia1(root -> dreapta, x);
        if(root -> dreapta -> prioritate > root -> prioritate)
        {
            rotestestanga(root);
        }
    }
}

void operatia2(Node* &root, int x)
{
    if(root == NULL)
    {
        return;
    }
    else if(x < root -> valoare)
    {
        operatia2(root -> stanga, x);
    }
    else if(x > root -> valoare)
    {
        operatia2(root -> dreapta, x);
    }
    else if(root -> valoare == x)
    {
        if(root -> stanga == NULL && root -> dreapta == NULL)
        {
            delete root;
            root = NULL;
        }
        else if(root -> stanga == NULL)
        {
            Node* p = root;
            root = root -> dreapta;
            delete p;
        }
        else if(root -> dreapta == NULL)
        {
            Node* p = root;
            root = root -> stanga;
            delete p;
        }
        else 
        {
            if(root -> stanga -> prioritate > root -> dreapta -> prioritate)
            {
                rotestedreapta(root);
                operatia2(root -> dreapta, x);
            }
            else
            {
                rotestestanga(root);
                operatia2(root -> stanga, x);
            }
        }
    }
}

void operatia3(Node* &root, int x, ofstream& fout)
{
    if(root == NULL)
    {
        fout << 0 << endl;
    }
    else if(root -> valoare == x)
    {
        fout << 1 << endl;
    }
    else if(x < root -> valoare)
    {
        operatia3(root -> stanga,x,fout);
    }
    else if(x > root -> valoare)
    {
        operatia3(root -> dreapta,x,fout);
    }
}

void operatia4(Node* &root,int x, int& raspuns)
{
    if(root == NULL)
    {
        return;
    }
    else if(x == root -> valoare)
    {
        raspuns = root -> valoare;
    }
    else if(x > root -> valoare)
    {
        raspuns = root -> valoare;
        operatia4(root -> dreapta,x,raspuns);
    }
    else if(x < root -> valoare)
    {
        operatia4(root -> stanga,x,raspuns);
    }
}

void operatia5(Node* &root,int x, int& raspuns)
{
    if(root == NULL)
    {
        return;
    }
    else if(x == root -> valoare)
    {
        raspuns = root -> valoare;
    }
    else if(x < root -> valoare)
    {
        raspuns = root -> valoare;
        operatia5(root -> stanga,x,raspuns);
    }
    else if(x > root -> valoare)
    {
        operatia5(root -> dreapta,x,raspuns);
    }
}

void operatia6(Node* &root, int x, int y, ofstream& fout)
{
    if(root == NULL)
    {
        return;
    }
    if(x < root -> valoare)
    {
        operatia6(root -> stanga,x,y,fout);
    }
    if(x <= root -> valoare && root -> valoare <= y)
    {
        fout << root -> valoare << " ";
    }
    if(y > root -> valoare)
    {
        operatia6(root -> dreapta,x,y,fout);
    }
}

int main()
{
    ifstream fin("abcd.in");
    ofstream fout("abcd.out");
    int n;
    fin >> n;
    Node* root = NULL;
    srand(time(NULL));

    for(int ind = 0; ind < n; ind++)
    {
        int op;
        fin >> op;
        if(op == 1)
        {
            int x;
            fin >> x;
            operatia1(root,x);
        }
        else if(op == 2)
        {
            int x;
            fin >> x;
            operatia2(root, x);
        }
        else if(op == 3)
        {
            int x;
            fin >> x;
            operatia3(root,x,fout);
        }
        else if(op == 4)
        {
            int x;
            fin >> x;
            int raspuns = -1;
            operatia4(root,x,raspuns);
            if(raspuns != -1)
            {
                fout << raspuns << endl;
            }
        }
        else if(op == 5)
        {
            int x;
            fin >> x;
            int raspuns = -1;
            operatia5(root,x,raspuns);
            if(raspuns != -1)
            {
                fout << raspuns << endl;
            }
        }
        else if(op == 6)
        {
            int x, y;
            fin >> x >> y;
            operatia6(root,x,y,fout);
            fout << endl;
        }
    }

    fin.close();
    fout.close();
    return 0;
}