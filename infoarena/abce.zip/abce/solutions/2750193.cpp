#include <iostream>
#include <fstream>
#include <string>
#include <bits/stdc++.h>
using namespace std;

fstream fin("abce.in");
ofstream fout("abce.out");

int c;

struct T
{
    int key, priority;
    T *left, *right;
    T() {}
    T(int key, int priority, T* left, T* right)
    {
        this->key = key;
        this->priority = priority;
        this->left = left, this->right = right;
    }
} *R, *nil; // nil indica un nod 'gol'

void init(T* &R)
{
    srand(unsigned(time(0)));
    R = nil = new T(0, 0, NULL, NULL);
}

int search(T* n, long long key)
{
    if (n == nil) return 0;
    if (key == n->key) return 1;
    if (key < n->key)
        return search(n->left, key);
    else
        return search(n->right, key);
}

void rotleft(T* &n)
{
    T *t = n->left;
    n->left = t->right, t->right = n;
    n = t;
}

void rotright(T* &n)
{
    T *t = n->right;
    n->right = t->left, t->left = n;
    n = t;
}

void balance(T* &n)
{
    if (n->left&&n->left->priority > n->priority)
        rotleft(n);
    else if (n->right&&n->right->priority > n->priority)
        rotright(n);
}

void insert(T* &n, long long  key, long long  priority)
{
    if (n == nil)
    {
        n = new T(key, priority, nil, nil);
        return;
    }
    if (key < n->key)
        insert(n->left, key, priority);
    else if (key > n->key)
        insert(n->right, key, priority);

    balance(n);
}

void erase(T* &n, long long  key)
{
    if (n == nil) return;

    if (key < n->key)
        erase(n->left, key);
    else if (key > n->key)
        erase(n->right, key);
    else
    {
        if (n->left == nil && n->right == nil)
        {
            delete n;
            n = nil;
        }
        else
        {
            (n->left->priority > n->right->priority) ? rotleft(n) : rotright(n);
            erase(n, key);
        }
    }
}

int main()
{
    long long n, k, tip;
    T *r = nil; // radacina
    fin >> n; // cate operatii introduc
    for (long long i = 0; i < n; i++)
    {
        fin >> tip >> k;
        if (tip == 1)
            insert(r, k, rand() + 1);
        if (tip == 2)
            erase(r, k);
        if (tip == 3)
            fout << search(r, k) << '\n';
    }
//    RSD(r);
    return 0;
}
