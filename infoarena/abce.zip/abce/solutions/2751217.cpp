#include <iostream>
#include <fstream>

std::ifstream f("abce.in");
std::ofstream g("abce.out");

const int inf = 1e9 + 1;

struct nod
{
	int key;
	nod* left;
	nod* right;

	nod();
	nod(int cheie, nod* stang, nod* drept)
	{
		key = cheie;
		left = stang;
		right = drept;
	}
	nod* operator = (nod* sursa)
	{
		key = sursa->key;
		left = sursa->left;
		right = sursa->right;
		return this;
	}
} *R, * nodgol;

nod::nod()
{
	left = nodgol;
	right = nodgol;
	key = -inf;
}

nod* cauta(nod* crt, int cheie_cautata)
{
	if (crt == nodgol)
		return nodgol;

	if (cheie_cautata == crt->key)
		return crt;
	if (cheie_cautata < crt->key)
		return cauta(crt->left, cheie_cautata);
	return cauta(crt->right, cheie_cautata);
}

void rotire_st(nod*& crt)
{
	nod* stangul = crt->left;
	crt->left = stangul->right;
	stangul->right = crt;
	crt = stangul;
}

void rotire_dr(nod*& crt)
{
	nod* dreptul = crt->right;
	crt->right = dreptul->left;
	dreptul->left = crt;
	crt = dreptul;
}

void inserare(nod*& crt, int cheie)
{
	if (crt == nodgol)
	{
		crt = new nod(cheie, nodgol, nodgol);
		return;
	}
	if (cheie < crt->key)
		inserare(crt->left, cheie);
	else if (cheie > crt->key)
		inserare(crt->right, cheie);
}

void stergere(nod*& crt, int cheie)
{
	if (crt == nodgol)
		return;

	if (cheie < crt->key)
		stergere(crt->left, cheie);
	else if (cheie > crt->key)
		stergere(crt->right, cheie);
	else
	{
		if (crt->left == nodgol and crt->right == nodgol)
		{
			delete crt;
			crt = nodgol;
		}
		else
		{
			if (crt->left != nodgol)
				rotire_st(crt);
			else
				rotire_dr(crt);
			stergere(crt, cheie);
		}
	}
}

void afis_elem_sortate(nod* crt, int margInf, int margSup, bool inInterval)
{
	if (!inInterval)
	{
		if (crt->left != nodgol and crt->key > margSup)
		{
			if (margInf <= crt->left->key and crt->left->key <= margSup)
				inInterval = true;
			afis_elem_sortate(crt->left, margInf, margSup, inInterval);
		}
		else 	if (crt->right != nodgol and crt->key < margInf)
		{
			if (margInf <= crt->right->key and crt->right->key <= margSup)
				inInterval = true;
			afis_elem_sortate(crt->right, margInf, margSup, inInterval);
		}
	}
	else
	{
		if (crt->left != nodgol and margInf <= crt->left->key)
			afis_elem_sortate(crt->left, margInf, margSup, inInterval);
		g << crt->key << " ";
		if (crt->right != nodgol and crt->right->key <= margSup)
			afis_elem_sortate(crt->right, margInf, margSup, inInterval);
	}
}

void succesor(const nod* crt, int cheie, char poz_relativa, int& result, int& countdown)
{
	if (cheie <= crt->key and crt->key < result)
		result = crt->key;
	if (result == cheie)
	{
		countdown = 0;
		return;
	}
	if (countdown == 3)		//   coboram sa cautam cheia / urcam inapoi sa luam primul nod care a coborat pe fiul stang
	{
		if (crt->key != cheie)
		{
			if (crt->left != nodgol and cheie < crt->key)
			{
				poz_relativa = 's';
				succesor(crt->left, cheie, poz_relativa, result, countdown);
			}
			else if (crt->right != nodgol and crt->key < cheie)
			{
				poz_relativa = 'd';
				succesor(crt->right, cheie, poz_relativa, result, countdown);
			}

			if (countdown == 2 and poz_relativa == 's')
			{
				countdown = 0;
				result = crt->key;
			}
		}
		else if (crt->right != nodgol)	  //  daca exista subarborele drept, continuam cautarea acolo; 
		{											  //  daca nu, ne intoarcem din functiile recursive
			countdown = 1;
			succesor(crt->right, cheie, poz_relativa, result, countdown);
		}
		else
			countdown = 2;
	}
	else if (countdown == 1)	// dupa ce am gasit cheia, cautam cel mai stang nod din subarborele drept
	{
		if (crt->left == nodgol)
		{
			countdown = 0;
			result = crt->key;
		}
		else
			succesor(crt->left, cheie, poz_relativa, result, countdown);
	}
}

void predecesor(const nod* crt, int cheie, char poz_relativa, int& result, int& countdown)
{
	if (result < crt->key and crt->key <= cheie)
		result = crt->key;
	if (result == cheie)
	{
		countdown = 0;
		return;
	}
	if (countdown == 3)		//   coboram sa cautam cheia / urcam inapoi sa luam primul nod care a coborat pe fiul drept
	{
		if (crt->key != cheie)
		{
			if (crt->left != nodgol and cheie < crt->key)
			{
				poz_relativa = 's';
				predecesor(crt->left, cheie, poz_relativa, result, countdown);
			}
			else if(crt->right != nodgol and crt->key < cheie)
			{
				poz_relativa = 'd';
				predecesor(crt->right, cheie, poz_relativa, result, countdown);
			}

			if (countdown == 2 and poz_relativa == 'd')
			{
				countdown = 0;
				result = crt->key;
			}
		}
		else if (crt->left != nodgol)	  //  daca exista subarborele stang, continuam cautarea acolo; 
		{											  //  daca nu, ne intoarcem din functiile recursive
			countdown = 1;
			predecesor(crt->left, cheie, poz_relativa, result, countdown);
		}
		else
			countdown = 2;
	}
	else if (countdown == 1)	// dupa ce am gasit cheia, cautam cel mai drept nod din subarborele stang
	{
		if (crt->right == nodgol)
		{
			countdown = 0;
			result = crt->key;
		}
		else
			predecesor(crt->right, cheie, poz_relativa, result, countdown);
	}
}

int main()
{
	R = nodgol = new nod(-inf, NULL, NULL);

	int nrOp, tipOp, x, y;

	f >> nrOp;
	for (int i = 0; i < nrOp; i++)
	{
		f >> tipOp;
		f >> x;
		switch (tipOp)
		{
		case 1:
		{
			inserare(R, x);
		}
		break;
		case 2:
		{
			stergere(R, x);
		}
		break;
		case 3:
		{
			if (cauta(R, x) == nodgol)
				g << "0\n";
			else
				g << "1\n";
		}
		break;
		case 4:
		{
			int predecesorul = -1e9-1, countdown = 3;
			predecesor(R, x, 'x', predecesorul, countdown);
			g << predecesorul << "\n";
		}
		break;
		case 5:
		{
			int succesorul = 1e9+1, countdown = 3;
			succesor(R, x, 'x', succesorul, countdown);
			g << succesorul << "\n";
		}
		break;
		default:
		{
			f >> y;
			bool inInterval = false;
			if (x <= R->key and R->key <= y)
				inInterval = true;
			afis_elem_sortate(R, x, y, inInterval);
			g << "\n";
		}
		}
	}
	return 0;
}
