#include <fstream>

#define intmin -0x7FFFFFFFFFFFFFFF
#define intmax 0x7FFFFFFFFFFFFFFF

using namespace std;

struct Node {
    long long key;
    Node *left;
    Node *right;
    long long height;
};
long long q, op, x, y;

ifstream fin("abce.in");
ofstream fout("abce.out");

inline int height(Node *&n) {
    return n == nullptr ? 0 : n->height;
}

Node *newNode(long long &key) {
    Node *node = new Node();
    node->key = key;
    node->left = nullptr;
    node->right = nullptr;
    node->height = 1; // frunza

    return node;
}

inline int getBalance(Node *n) {
    if (n == nullptr) {
        return 0;
    }

    return height(n->left) - height(n->right);
}

Node *rightRotate(Node *y) {
    Node *x = y->left;
    Node *T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = 1 + max(height(y->left), height(y->right));
    x->height = 1 + max(height(x->left), height(x->right));

    return x;
}

Node *leftRotate(Node *x) {
    Node *y = x->right;
    Node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = 1 + max(height(x->left), height(x->right));
    y->height = 1 + max(height(y->left), height(y->right));

    return y;
}

inline void balanceTree(Node *&node, long long key, bool isDelete = false){
    // Balanta
    long long balance = getBalance(node);
    // LL
    if (balance > 1 && key < (isDelete ? getBalance(node->left) : node->left->key)) {
        node = rightRotate(node);
        return;
    }
    // RR
    if (balance < -1 && key > (isDelete ? getBalance(node->right) : node->right->key)) {
        node = leftRotate(node);
        return;
    }
    // LR
    if (balance > 1 && (isDelete ? getBalance(node->left) : key > node->left->key)) {
        node->left = leftRotate(node->left);
        node = rightRotate(node);
        return;
    }
    // RL
    if (balance < -1 && key < (isDelete ? getBalance(node->right) : node->right->key)) {
        node->right = rightRotate(node->right);
        node = leftRotate(node);
        return;
    }
}

void insert(Node *&node, long long key) {
    // BST
    if (node == nullptr) {
        node = newNode(key);
    }

    if (key < node->key) {
        insert(node->left, key);
    } else if (key > node->key) {
        insert(node->right, key);
    } else {
        return;
    }

    // Actualizare height
    node->height = 1 + max(height(node->left), height(node->right));

    balanceTree(node, key);
}


bool search(Node *&node, long long key){
    if(node == nullptr)
        return false;

    if(node->key == key)
        return true;

    if(node->left != nullptr && key <= node->left->key)
        return search(node->left, key);

    if(node->right != nullptr && key >= node->right->key)
        return search(node->right, key);

    return false;
}

Node *minKey(Node *root){
//    if(root == nullptr || root->left == nullptr)
//        return root;
//
//    return minKey(root);
    if(root == nullptr)
        return root;

    Node *tmp = root;

    while(tmp->left != nullptr)
        tmp = tmp->left;

    return tmp;
}

void deleteNode(Node *&root, long long key){
    if(root == nullptr)
        return;

    if(root->key < key) {
        deleteNode(root->right, key);
    } else if(root->key > key) {
        deleteNode(root->left, key);
    } else {
        Node *tmp;

        if(root->left == nullptr || root->right == nullptr){ // Maxim 1 copil
            tmp = root->right == nullptr ? root->left : root->right;

            // Fara copii
            if(tmp == nullptr){
//                tmp = root;
                root = nullptr;
            } else {
                // 1 copil
                root->key = tmp->key;
                root->left = tmp->left;
                root->right = tmp->right;

                delete tmp;
            }
        } else { // 2 copii
            tmp = minKey(root->right);
            root->key = tmp->key;
            deleteNode(root->right, tmp->key);
        }
    }

    // Nu mai sunt noduri
    if(root == nullptr)
        return;

    root->height = 1 + max(height(root->left), height(root->right));
    balanceTree(root, intmin, true);
}

long long op4(Node *&root, long long &key){
    if(root == nullptr)
        return intmin;

    if(root->key == key)
        return key;
    if(root->key < key)
        return max(root->key, op4(root->right, key));
    else
        return op4(root->left, key);
}

long long op5(Node *&root, long long &key){
    if(root == nullptr)
        return intmax;

    if(root->key == key)
        return key;
    if(root->key > key)
        return min(root->key, op5(root->left, key));
    else
        return op5(root->right, key);
}


void inorder(Node *&root, long long &x, long long &y){
    if(root == nullptr)
        return;

    inorder(root->left, x, y);
    if(root->key >=x && root->key <= y) fout << root->key << " ";
    inorder(root->right, x, y);
}


int main() {
    Node *root = nullptr;

    fin >> q;

    for(unsigned int i = 0; i < q; ++i){
        fin >> op;
        switch(op){
            case 1:{
                fin >> x;
                insert(root, x);

                break;
            }
            case 2:{
                fin >> x;
                deleteNode(root, x);

                break;
            }

            case 3:{
                fin >> x;
                fout << (search(root, x) ? '1' : '0') << '\n';
                break;
            }

            case 4: {
                fin >> x;
                fout << op4(root, x) << '\n';
                break;
            }

            case 5: {
                fin >> x;
                fout << op5(root, x) << '\n';
                break;
            }
            case 6:{
                fin >> x >> y;

                inorder(root, x, y);
                fout << '\n';

                break;
            }
        }
    }


    return 0;
}