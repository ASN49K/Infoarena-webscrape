#include <bits/stdc++.h>

using namespace std;

#define NIL NULL
#define BLACK false
#define RED true

ifstream input("abce.in");
ofstream output("abce.out");

// Proprietati:
// 1. Fiecare nod este fie rosu fie negru.
// 2. Toate frunzele NIL sunt considerate negre.
// 3. Daca un nod este rosu, ambi sai fii sunt negri.
// 4. Fiecare drum de la un nod to oricare frunza NIL descendenta merge prin acelasi numar de noduri negre.

struct Node {
  Node *parent;
  Node *right;
  Node *left;
  bool color; // false pentru NEGRU; true pentru ROSU
  int key;

  Node(int key) {
    this->key = key;
    left = right = parent = NULL;
    this->color = RED; // RED by default; Reparam abaterile in insertRB
  }
};

void rotateLeft(Node *&root, Node *&N) {
  Node *R = N->right;

  N->right = R->left;

  if (N->right != NULL)
    N->right->parent = N;

  R->parent = N->parent;

  if (N->parent == NULL)
    root = R;

  else if (N == N->parent->left)
    N->parent->left = R;

  else
    N->parent->right = R;

  R->left = N;
  N->parent = R;
}

void rotateRight(Node *&root, Node *&N) {
  Node *L = N->left;

  N->left = L->right;

  if (N->left != NULL)
    N->left->parent = N;

  L->parent = N->parent;

  if (N->parent == NULL)
    root = L;

  else if (N == N->parent->left)
    N->parent->left = L;

  else
    N->parent->right = L;

  L->right = N;
  N->parent = L;
}

// Returns root
Node *insertBST(Node *root, Node *N) {
  if (root == NULL) {
    root = N;
  } else if (N->key < root->key) {
    root->left = insertBST(root->left, N);
    root->left->parent = root;
  } else if (N->key > root->key) {
    root->right = insertBST(root->right, N);
    root->right->parent = root;
  }

  return root;
}

Node *minValueNode(Node *N) {
  Node *tmp = N;

  while (tmp && tmp->left != NULL)
    tmp = tmp->left;

  return tmp;
}

Node *deleteBST(Node *root, Node *N) {
  if (root == NULL)
    return root;

  if (N->key < root->key)
    root->left = deleteBST(root->left, N);
  else if (N->key > root->key)
    root->right = deleteBST(root->right, N);

  else {
    // nodul nu are fii
    if (root->left == NULL && root->right == NULL)
      return NULL;

      // Nodul are 1 singur fiu
    else if (root->left == NULL) {
      Node *tmp = root->right;
      free(root);
      return tmp;
    } else if (root->right == NULL) {
      Node *tmp = root->left;
      free(root);
      return tmp;
    } else {
      // Nod cu 2 fii
      Node *tmp = minValueNode(root->right);

      root->key = tmp->key;
      root->right = deleteBST(root->right, tmp);
    }
  }
  return root;
}

// Returnam noul root
Node *insertRB(Node *root, Node *N) {
  // Pasul 1: Inseram N (folosind insertBST) si il coloram RED
  root = insertBST(root, N);
  // Nodul este deja ROSU datorita constructorului de NodeRB.
  // Exceptie pt radacina, pe care o vom avea BLACK.

  // Step 2: Recoloram si rotim nodurile pentru a repara abaterile de la proprietatile arborilor rosu-negru.
  // Vom avea 4 cazuri:
  // I. N este radacina.
  // II. Unchiul lui N este rosu.
  // III. Unchiul lui N este negru (triunghi).
  // IV. Unchiul lui N este negru (linie).

  Node *P = NULL; // parinte
  Node *G = NULL; // bunic

  while (N != root && N->parent->color == RED) {

    P = N->parent; // Parinte
    G = N->parent->parent; // Bunic

    // Parintele fiul din staga al bunicului.
    if (P == G->left) {
      Node *U = G->right; // unchi
      if (U != NULL && U->color == RED) {
        // Cazul 1, unchiul este rosu
        P->color = BLACK;
        U->color = BLACK;
        G->color = RED;
        N = G;
      } else {
        // Cazul 2, N este fiul din dreapta al lui P.
        // Vom face rotatie spre stanga
        if (N == P->right) {
          rotateLeft(root, P);
          N = P;
          P = N->parent;
        }
        // Cazul 3, N este fiul din stanga al parintelui
        // Vom face rotatie la dreapta
        P->color = BLACK;
        G->color = RED;
        rotateRight(root, G);
        N = P;
      }
      // Parintele fiul din dreapta al bunicului.
      // Vom face asemanator cu mai sus, doar ca vom inversa stanga/dreapta.
    } else {
      Node *U = G->left;

      //  Caz 1
      if (U != NULL && U->color == RED) {
        G->color = RED;
        P->color = BLACK;
        U->color = BLACK;
        N = G;
      } else {
        // Caz 2
        if (N == P->left) {
          rotateRight(root, P);
          N = P;
          P = P->parent;
        }

        // Caz 3
        rotateLeft(root, G);
        P->color = BLACK;
        G->color = RED;
        N = P;
      }
    }
  }

  root->color = BLACK;
  return root;
}

// Functia o folosesc inainte de deleteBST. Imi returneaza nodul ce va fi sters in deleteBST.
Node *afterDelete(Node *N) {
  // Cand nodul are 2 fii
  if (N->left != NULL and N->right != NULL)
    return minValueNode(N->right);

  // Frunza
  if (N->left == NULL and N->right == NULL)
    return NULL;

  // Un singur fiu
  if (N->left != NULL)
    return N->left;
  else
    return N->right;
}

void fixTwoBlackCase(Node *root, Node *N) {
  if (N == root)
    return;

  Node *S = N->parent->left == N ? N->parent->right : N->parent->left; // S este sibling pt N

  Node *P = N->parent;
  if (S == NULL) {
    // nu avem frati
    fixTwoBlackCase(root, P);
  } else {
    if (S->color == RED) {
      P->color = RED;
      S->color = BLACK;
      if (S->parent->left == S)
        rotateRight(root, P);
      else
        rotateLeft(root, P);

      fixTwoBlackCase(root, N);
    } else {
      // cel putin 1 fiu rosu
      if ((S->right != NULL && S->right->color == RED) || (S->left != NULL && S->left->color == RED)) {
        // mergem pe stanga
        if (S->left != NULL and S->left->color == RED) {
          if (S->parent->left == S) {
            // stanga stanga
            S->left->color = S->color;
            S->color = P->color;
            rotateRight(root, P);
          } else {
            // dreapta stanga
            S->left->color = P->color;
            rotateRight(root, S);
            rotateLeft(root, P);
          }
        } else {
          // mergem pe dreapta
          if (S->parent->left == S) {
            // stanga dreapta
            S->right->color = P->color;
            rotateLeft(root, S);
            rotateRight(root, P);
          } else {
            // dreapta dreapta
            S->right->color = S->color;
            S->color = P->color;
            rotateLeft(root, P);
          }
        }
        P->color = BLACK;
      } else {
        S->color = RED;
        if (P->color == BLACK)
          fixTwoBlackCase(root, P);
        else
          P->color = BLACK;
      }
    }
  }
}

void deleteRB(Node *root, Node *N) {
  Node *U = afterDelete(N); // U este nodul urmator, ce-i va lua locul lui N dupa delete

  if (U == NULL && N == root) {
    root = NULL;
    N = NULL;
    return;
  } // Tratam cazul in care avem un singur nod, radacina;

  // In primul rand, facem o stergere ca in binary search tree
//  root = deleteBST(root, N);
// nevermind

  // Pasul urmator este sa rezolvam conflictele aparute.


  if (U == NULL) {// N este frunza

    Node *S = N->parent->left == N ? N->parent->right : N->parent->left; // S este sibling pt U

    // Cazul I: Daca nodul pe care il stergem sau nodul care inlocuieste nodul sters (U) este rosu:
//    if (N->color == RED || (U != NULL && U->color == RED))
    if (N->color == RED) { // edit: am verificat mai sus ca N este frunza
      if (S != NULL)
        S->color = RED;

    } else {
      // Cazul II, putin mai complicat, apare atunci cand si U si N sunt negre:
      fixTwoBlackCase(root, N);
    }

    if (N->parent->left == N)
      N->parent->left = NULL;
    else N->parent->right = NULL;
    N = NULL;
    return;
  }

  // Daca N are un singur fiu
  if (N->left == NULL or N->right == NULL) {
    Node *P = N->parent;
    // N este radacina
    if (N == root) {
      // Ii dam lui N valoarea urmatorului nod, U si-l stergem pe U
      N->key = U->key;
      N->left = N->right = NULL;
      U = NULL;
    } else {
      // Stergem pe N si mutam U in sus, in locul lui.
      if (P->left == U) {
        P->left = U;
      } else {
        P->right = U;
      }
      N = NULL;
      U->parent = P;
      if (U->color == BLACK && N->color == BLACK) {
        // cazul de ambele NEGRE; reparam cu functia definita anterior
        fixTwoBlackCase(root, N);
      } else {
        // cazul 1: N sau U este rosu, deci il vom face negru
        N->color = BLACK;
      }
    }
    return;
  }

  // Daca N are 2 fii atunci schimbam valorile si reaplam functia.
  int tmp = U->key;
  U->key = N->key;
  N->key = tmp;
  deleteRB(root, U);
}

// inordine
void printSRD(struct Node *root) {
  if (root == NULL)
    return;

  printSRD(root->left);
  cout << root->key << " ";
  printSRD(root->right);
}

// preordine
void printRSD(struct Node *root) {
  if (root == NULL)
    return;

  cout << root->key << " ";
  printRSD(root->left);
  printRSD(root->right);
}

// preodine cu o conditie, practic
void handleOpSix(struct Node *root, int X, int Y) {
  if (root == NULL)
    return;
  if (root->key >= X && root->key <= Y)
    output << root->key << " ";
  handleOpSix(root->left, X, Y);
  handleOpSix(root->right, X, Y);
}

// postordine
void printSDR(struct Node *root) {
  if (root == NULL)
    return;

  printSDR(root->left);
  printSDR(root->right);
  cout << root->key << " ";

}

// Cauta un nod
Node *searchForNode(Node *root, int key) {
  if (root == NULL)
    return NULL;

  if (root->key == key)
    return root;

  Node *left = searchForNode(root->left, key);
  Node *right = searchForNode(root->right, key);
  if (left != NULL) return left;
  if (right != NULL) return right;
  return NULL;
}

void findAndDelete(Node *root, int key) {
  Node *N = searchForNode(root, key);
  deleteRB(root, N);
}

int findMax(Node *root, int X) {
  int res = INT_MIN;
  if (root != NULL && root->key <= X)
    res = root->key;
  int leftValue = INT_MIN;
  int rightValue = INT_MIN;
  if (root->left != NULL)
    leftValue = findMax(root->left, X);
  if (root->right != NULL)
    rightValue = findMax(root->right, X);

  if (leftValue > res && leftValue <= X)
    res = leftValue;
  if (rightValue > res && rightValue <= X)
    res = rightValue;
  return res;
}
int findMin(Node *root, int X) {
  int res = INT_MAX;
  if (root != NULL && root->key >= X)
    res = root->key;

  int leftValue = INT_MIN;
  int rightValue = INT_MIN;
  if (root->left != NULL)
    leftValue = findMin(root->left, X);
  if (root->right != NULL)
    rightValue = findMin(root->right, X);

  if (leftValue < res && leftValue >= X)
  res = leftValue;
  if (rightValue < res && rightValue >= X)
    res = rightValue;
  return res;
}

int main() {
  int Q;
  input >> Q;
  int op, X, Y;
  Node *root = NULL;
  bool rootInitalized = false;
  for (int i = 0; i < Q; ++i) {
    input >> op;
    input >> X;
    if (op == 6) input >> Y;

    if (op == 1) { // insert
      if (rootInitalized == false) {
        root = insertRB(NULL, new Node(X));
        rootInitalized = true;
      } else {
        root = insertRB(root, new Node(X));
      }
    } else if (op == 2) { // delete
      findAndDelete(root, X);
    } else if (op == 3) { // search
      bool found = searchForNode(root, X) != NULL;
      if (found)
        output << "1\n";
      else
        output << "0\n";
    } else if (op == 4) { // max
      output << findMax(root, X) << "\n";
    } else if (op == 5) { // min
      output << findMin(root, X) << "\n";
    } else if (op == 6) { // ascending order
      handleOpSix(root, X, Y);
      output << '\n';
    }

  }


//
//  Node *myNode = new Node(14);
//  Node *myNode2 = new Node(1);
//  Node *myNode3 = new Node(2);
//  root = insertRB(NULL, new Node(10));
//  root = insertRB(root, new Node(5));
//  root = insertRB(root, new Node(6));
//  root = insertRB(root, new Node(11));
//  root = insertRB(root, myNode);
//  root = insertRB(root, myNode2);
//  root = insertRB(root, myNode3);
//  root = insertRB(root, new Node(3));
//
//  deleteRB(root, myNode);
//  deleteRB(root, myNode2);
//  deleteRB(root, myNode3);
//
//  print2D(root);
  return 0;
}