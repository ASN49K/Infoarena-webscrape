#include <iostream>
#include <fstream>

using namespace std;

/// Arbore binar de cautare echilibrat (de continuat candva).

/// Mai trebuie implementate rotatiile si echilibrarile.

class ABCE;

class Nod
{
public:

    int valoare;
    int frecventa;

private:

    static const int NR_FII = 2;

    Nod* tata;
    int pozInTata;
    Nod* fii[Nod::NR_FII];
    int inaltimeSubArbore;
    int dimensiuneSubArbore;
    int sumaFrecventeSubArbore;

    bool esteRadacina;

    Nod() : valoare(0), frecventa(0), tata(nullptr), pozInTata(-1), inaltimeSubArbore(0), dimensiuneSubArbore(0), sumaFrecventeSubArbore(0), esteRadacina(false)
    {
        for (int i = 0; i < Nod::NR_FII; ++i)
            this->fii[i] = nullptr;
    }

    friend class ABCE;
};

class ABCE
{
private:

    static const int INFINIT = 1e9 + 1;

    Nod* radacina;

    void stergeSubArboreInDestructor(Nod* nod);
    void insereaza(int x, Nod* nod);
    void sterge(int x, Nod* nod, bool stergereCompleta = false);
    void afiseazaCrescator(ostream& out, Nod* nod) const;
    void afiseazaDescrescator(ostream& out, Nod* nod) const;
    void recalculeazaParametriiSubArbore(Nod* nod);
    Nod* cauta(Nod* nod, int x, int st, int dr) const;
    void recalculeazaParametriiSubArborePeLant(Nod* inceput, Nod* sfarsit);
    Nod* maximSubSauEgalCu(Nod* nod, int x) const;
    Nod* minimPesteSauEgalCu(Nod* nod, int x) const;
    Nod* rotesteStanga(Nod* nod);
    Nod* rotesteDreapta(Nod* nod);
    void rebalanseazaNod(Nod* nod);
    void rebalanseazaLant(Nod* inceput, Nod* sfarsit);

    void afiseazaArbore(Nod* nod) const;

public:

    ABCE()
    {
        this->radacina = new Nod();
        this->radacina->esteRadacina = true;
    }

    void insereaza(int x);
    void sterge(int x, bool stergereCompleta = false);
    void afiseazaCrescator(ostream& out) const;
    void afiseazaDescrescator(ostream& out)const;
    Nod* cauta(int x) const;
    Nod* maximSubSauEgalCu(int x) const;
    Nod* minimPesteSauEgalCu(int x) const;

    Nod* succesorDistinct(Nod* nod) const;
    Nod* predecesorDistinct(Nod* nod) const;

    void afiseazaArbore() const;

    inline int dimensiune()
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->dimensiuneSubArbore;
        return 0;
    }

    inline int numarElemente()
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->sumaFrecventeSubArbore;
        return 0;
    }

    ~ABCE()
    {
        this->stergeSubArboreInDestructor(this->radacina);
    }
};

void ABCE::afiseazaArbore(Nod* nod) const
{
    std::cout << "Nodul " << nod->valoare << " are fiii: " << '\n';

    if (nod->fii[0] != nullptr)
        std::cout << nod->fii[0]->valoare << "(fiu stang)" << ' ';
    if (nod->fii[1] != nullptr)
        std::cout << nod->fii[1]->valoare << "(fiu drept)" << ' ';
    std::cout << '\n';

    if (nod->fii[0] != nullptr)
        this->afiseazaArbore(nod->fii[0]);
    if (nod->fii[1] != nullptr)
        this->afiseazaArbore(nod->fii[1]);
}

void ABCE::afiseazaArbore() const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaArbore(this->radacina->fii[1]);
    else
        std::cout << "Arborele este vid!" << '\n';
}

void ABCE::rebalanseazaLant(Nod* inceput, Nod* sfarsit)
{
    if (inceput == nullptr || sfarsit == nullptr)
        return;

    if (inceput->esteRadacina || sfarsit->esteRadacina)
        return;

    while (inceput != sfarsit)
    {
        this->rebalanseazaNod(inceput);
        inceput = inceput->tata;
    }

    this->rebalanseazaNod(inceput);
}

void ABCE::rebalanseazaNod(Nod* nod)
{
    if (nod->fii[0] != nullptr)
    {
        int inaltimeFiuStang = 0;
        if (nod->fii[0]->fii[0] != nullptr)
            inaltimeFiuStang = nod->fii[0]->fii[0]->inaltimeSubArbore;
        int inaltimeFiuDrept = 0;
        if (nod->fii[0]->fii[1] != nullptr)
            inaltimeFiuDrept = nod->fii[0]->fii[1]->inaltimeSubArbore;

        if (inaltimeFiuStang == inaltimeFiuDrept + 2) /// Cazul Left-Left (LL)
            nod = this->rotesteDreapta(nod);
        else if (inaltimeFiuStang + 2 == inaltimeFiuDrept) /// Cazul Left-Right (LR)
        {
            this->rotesteStanga(nod->fii[0]);
            nod = this->rotesteDreapta(nod);
        }
    }

    if (nod->fii[1] != nullptr)
    {
        int inaltimeFiuStang = 0;
        if (nod->fii[1]->fii[0] != nullptr)
            inaltimeFiuStang = nod->fii[1]->fii[0]->inaltimeSubArbore;
        int inaltimeFiuDrept = 0;
        if (nod->fii[1]->fii[1] != nullptr)
            inaltimeFiuDrept = nod->fii[1]->fii[1]->inaltimeSubArbore;

        if (inaltimeFiuDrept == inaltimeFiuStang + 2) /// Cazul Right-Right (RR)
            nod = this->rotesteStanga(nod);
        else if (inaltimeFiuStang == inaltimeFiuDrept + 2) /// Cazul Right-Left (RL)
        {
            this->rotesteDreapta(nod->fii[1]);
            nod = this->rotesteStanga(nod);
        }
    }

    int inaltimeFiuStang = 0;
    if (nod->fii[0] != nullptr)
        inaltimeFiuStang = nod->fii[0]->inaltimeSubArbore;
    int inaltimeFiuDrept = 0;
    if (nod->fii[1] != nullptr)
        inaltimeFiuDrept = nod->fii[1]->inaltimeSubArbore;

    if (inaltimeFiuStang + 2 == inaltimeFiuDrept)
        nod = this->rotesteDreapta(nod);
    if (inaltimeFiuStang == inaltimeFiuDrept + 2)
        nod = this->rotesteStanga(nod);
}

Nod* ABCE::rotesteStanga(Nod* nod)
{
    if (nod->esteRadacina || nod->fii[1] == nullptr)
        return nod;

    Nod* nodDrept = nod->fii[1];

    Nod* fiuStangNodDrept = nodDrept->fii[0];

    if (fiuStangNodDrept == nullptr)
        nod->fii[1] = nullptr;
    else
    {
        nod->fii[1] = fiuStangNodDrept;
        fiuStangNodDrept->tata = nod;
        fiuStangNodDrept->pozInTata = 1;
    }

    nodDrept->fii[0] = nod;
    nodDrept->tata = nod->tata;
    nod->tata->fii[nod->pozInTata] = nodDrept;
    nodDrept->pozInTata = nod->pozInTata;
    nod->tata = nodDrept;
    nod->pozInTata = 0;

    this->recalculeazaParametriiSubArbore(nod);
    this->recalculeazaParametriiSubArbore(nodDrept);

    return nodDrept;
}

Nod* ABCE::rotesteDreapta(Nod* nod)
{
    if (nod->esteRadacina || nod->fii[0] == nullptr)
        return nod;

    Nod* nodStang = nod->fii[0];

    Nod* fiuDreptNodStang = nodStang->fii[1];

    if (fiuDreptNodStang == nullptr)
        nod->fii[0] = nullptr;
    else
    {
        nod->fii[0] = fiuDreptNodStang;
        fiuDreptNodStang->tata = nod;
        fiuDreptNodStang->pozInTata = 0;
    }

    nodStang->fii[1] = nod;
    nodStang->tata = nod->tata;
    nod->tata->fii[nod->pozInTata] = nodStang;
    nodStang->pozInTata = nod->pozInTata;
    nod->tata = nodStang;
    nod->pozInTata = 1;

    this->recalculeazaParametriiSubArbore(nod);
    this->recalculeazaParametriiSubArbore(nodStang);

    return nodStang;
}

Nod* ABCE::maximSubSauEgalCu(Nod* nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->maximSubSauEgalCu(nod->fii[0], x);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
        {
            Nod* nodDreapta = this->maximSubSauEgalCu(nod->fii[1], x);

            if (nodDreapta == nullptr)
                return nod;
            else
                return nodDreapta;
        }
        else
            return nod;
    }
}

Nod* ABCE::minimPesteSauEgalCu(Nod* nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
        {
            Nod* nodStanga = this->minimPesteSauEgalCu(nod->fii[0], x);

            if (nodStanga == nullptr)
                return nod;
            else
                return nodStanga;
        }
        else
            return nod;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->minimPesteSauEgalCu(nod->fii[1], x);
        else
            return nullptr;
    }
}

Nod* ABCE::maximSubSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->maximSubSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

Nod* ABCE::minimPesteSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->minimPesteSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

void ABCE::recalculeazaParametriiSubArborePeLant(Nod* inceput, Nod* sfarsit)
{
    if (inceput == nullptr || sfarsit == nullptr)
        return;

    if (inceput->esteRadacina || sfarsit->esteRadacina)
        return;

    while (inceput != sfarsit)
    {
        this->recalculeazaParametriiSubArbore(inceput);
        inceput = inceput->tata;
    }

    this->recalculeazaParametriiSubArbore(inceput);
}

void ABCE::stergeSubArboreInDestructor(Nod* nod)
{
    for (int i = 0; i < Nod::NR_FII; ++i)
        if (nod->fii[i] != nullptr)
            stergeSubArboreInDestructor(nod->fii[i]);

    delete nod;
}

Nod* ABCE::succesorDistinct(Nod* nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas dreapta, apoi maxima stanga
    if (solutie->fii[1] != nullptr)
    {
        solutie = solutie->fii[1];

        while (solutie->fii[0] != nullptr)
            solutie = solutie->fii[0];
    }
    else /// altfel urcam cat timp venim din fiul drept si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 1 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 0 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::predecesorDistinct(Nod* nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas stanga, apoi maxima dreapta
    if (solutie->fii[0] != nullptr)
    {
        solutie = solutie->fii[0];

        while (solutie->fii[1] != nullptr)
            solutie = solutie->fii[1];
    }
    else /// altfel urcam cat timp venim din fiul stang si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 0 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 1 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::cauta(Nod* nod, int x, int st, int dr) const
{
    if (x < st || dr < x)
        return nullptr;

    if (nod->valoare == x && nod->frecventa > 0)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->cauta(nod->fii[0], x, st, nod->valoare - 1);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->cauta(nod->fii[1], x, nod->valoare + 1, dr);
        else
            return nullptr;
    }
}

Nod* ABCE::cauta(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->cauta(this->radacina->fii[1], x, -ABCE::INFINIT, +ABCE::INFINIT);
    return nullptr;
}

void ABCE::recalculeazaParametriiSubArbore(Nod* nod)
{
    nod->inaltimeSubArbore = 1;
    if (nod->fii[0] != nullptr)
        nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[0]->inaltimeSubArbore + 1);
    if (nod->fii[1] != nullptr)
        nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[1]->inaltimeSubArbore + 1);

    nod->dimensiuneSubArbore = 1;
    if (nod->fii[0] != nullptr)
        nod->dimensiuneSubArbore += nod->fii[0]->dimensiuneSubArbore;
    if (nod->fii[1] != nullptr)
        nod->dimensiuneSubArbore += nod->fii[1]->dimensiuneSubArbore;

    nod->sumaFrecventeSubArbore = nod->frecventa;
    if (nod->fii[0] != nullptr)
        nod->sumaFrecventeSubArbore += nod->fii[0]->sumaFrecventeSubArbore;
    if (nod->fii[1] != nullptr)
        nod->sumaFrecventeSubArbore += nod->fii[1]->sumaFrecventeSubArbore;
}

void ABCE::insereaza(int x)
{
    if (this->radacina->fii[1] == nullptr)
    {
        this->radacina->fii[1] = new Nod();
        this->radacina->fii[1]->valoare = x;
        this->radacina->fii[1]->frecventa = 1;
        this->radacina->fii[1]->tata = this->radacina;
        this->radacina->fii[1]->pozInTata = 1;
        this->radacina->fii[1]->inaltimeSubArbore = 1;
        this->radacina->fii[1]->dimensiuneSubArbore = 1;
        this->radacina->fii[1]->sumaFrecventeSubArbore = 1;
    }
    else
        this->insereaza(x, this->radacina->fii[1]);
}

void ABCE::insereaza(int x, Nod* nod)
{
    if (nod->valoare == x)
    {
        ++nod->frecventa;
        ++nod->sumaFrecventeSubArbore;
        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] == nullptr)
        {
            nod->fii[1] = new Nod();
            nod->fii[1]->valoare = x;
            nod->fii[1]->frecventa = 1;
            nod->fii[1]->tata = nod;
            nod->fii[1]->pozInTata = 1;
            nod->fii[1]->inaltimeSubArbore = 1;
            nod->fii[1]->dimensiuneSubArbore = 1;
            nod->fii[1]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[1]);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
    else
    {
        if (nod->fii[0] == nullptr)
        {
            nod->fii[0] = new Nod();
            nod->fii[0]->valoare = x;
            nod->fii[0]->frecventa = 1;
            nod->fii[0]->tata = nod;
            nod->fii[0]->pozInTata = 0;
            nod->fii[0]->inaltimeSubArbore = 1;
            nod->fii[0]->dimensiuneSubArbore = 1;
            nod->fii[0]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[0]);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
}

void ABCE::sterge(int x, bool stergereCompleta)
{
    if (this->radacina->fii[1] != nullptr)
        this->sterge(x, this->radacina->fii[1], stergereCompleta);
}

void ABCE::sterge(int x, Nod* nod, bool stergereCompleta)
{
    if (nod->valoare == x)
    {
        if (stergereCompleta)
        {
            nod->frecventa = 0;
            nod->sumaFrecventeSubArbore = 0;
        }
        else
        {
            --nod->frecventa;
            --nod->sumaFrecventeSubArbore;
        }

        if (nod->frecventa == 0) /// Presupun ca nodul nu e radacina, deci poate fi sters si are sigur tata.
        {
            if (nod->fii[0] == nullptr && nod->fii[1] == nullptr)
            {
                nod->tata->fii[nod->pozInTata] = nullptr;

                delete nod;
            }
            else if (nod->fii[0] != nullptr && nod->fii[1] == nullptr)
            {
                nod->fii[0]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[0];
                nod->fii[0]->pozInTata = nod->pozInTata;

                this->recalculeazaParametriiSubArbore(nod->fii[0]);

                this->rebalanseazaNod(nod->fii[0]);

                delete nod;
            }
            else if (nod->fii[0] == nullptr && nod->fii[1] != nullptr)
            {
                nod->fii[1]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[1];
                nod->fii[1]->pozInTata = nod->pozInTata;

                this->recalculeazaParametriiSubArbore(nod->fii[1]);

                this->rebalanseazaNod(nod->fii[1]);

                delete nod;
            }
            else /// Are ambii fii (in acest caz sigur are succesorul mai jos de el).
            {
                Nod* succesor = this->succesorDistinct(nod);

                std::swap(nod->valoare, succesor->valoare);
                std::swap(nod->frecventa, succesor->frecventa);

                if (succesor->fii[0] == nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* tataSuccesor = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = nullptr;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(tataSuccesor, nod);

                    this->rebalanseazaLant(tataSuccesor, nod);
                }
                else if (succesor->fii[0] != nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* tataSuccesor = succesor->fii[0];
                    succesor->fii[0]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[0];
                    succesor->fii[0]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(tataSuccesor, nod);

                    this->rebalanseazaLant(tataSuccesor, nod);
                }
                else /// succesor->fii[0] == nullptr && succesor->fii[1] != nullptr
                {
                    Nod* tataSuccesor = succesor->fii[1];
                    succesor->fii[1]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[1];
                    succesor->fii[1]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(tataSuccesor, nod);

                    this->rebalanseazaLant(tataSuccesor, nod);
                }
            }
        }

        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] != nullptr)
        {
            this->sterge(x, nod->fii[1], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
    else
    {
        if (nod->fii[0] != nullptr)
        {
            this->sterge(x, nod->fii[0], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
}

void ABCE::afiseazaCrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaCrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaCrescator(ostream& out, Nod* nod) const
{
    if (nod->fii[0] != nullptr)
        this->afiseazaCrescator(out, nod->fii[0]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[1] != nullptr)
        this->afiseazaCrescator(out, nod->fii[1]);
}

void ABCE::afiseazaDescrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaDescrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaDescrescator(ostream& out, Nod* nod) const
{
    if (nod->fii[1] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[1]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[0] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[0]);
}

int main()
{
    ABCE* abce = new ABCE();

    ifstream in("abce.in");
    ofstream out("abce.out");

    ios_base::sync_with_stdio(false);
    in.tie(nullptr);

    int q;
    in >> q;

    for (int j = 0; j < q; ++j)
    {
        int tip;
        in >> tip;

        if (tip == 1)
        {
            int x;
            in >> x;

            abce->insereaza(x);
        }
        else if (tip == 2)
        {
            int x;
            in >> x;

            abce->sterge(x, true);
        }
        else if (tip == 3)
        {
            int x;
            in >> x;

            if (abce->cauta(x) != nullptr)
                out << 1 << '\n';
            else
                out << 0 << '\n';
        }
        else if (tip == 4)
        {
            int x;
            in >> x;

            out << abce->maximSubSauEgalCu(x)->valoare << '\n';
        }
        else if (tip == 5)
        {
            int x;
            in >> x;

            out << abce->minimPesteSauEgalCu(x)->valoare << '\n';
        }
        else
        {
            int x, y;
            in >> x >> y;

            Nod* inceput = abce->minimPesteSauEgalCu(x);
            Nod* sfarsit = abce->maximSubSauEgalCu(y);

            while (inceput != sfarsit)
            {
                out << inceput->valoare << ' ';
                inceput = abce->succesorDistinct(inceput);
            }

            out << inceput->valoare << '\n';
        }
    }

    in.close();
    out.close();

    /*
    int q;
    cin >> q;

    for (int j = 0; j < q; ++j)
    {
        int tip;
        cin >> tip;

        if (tip == 1)
        {
            int x;
            cin >> x;

            abce->insereaza(x);
        }
        else if (tip == 2)
        {
            int x;
            cin >> x;

            abce->sterge(x, true);
        }

        abce->afiseazaArbore();
    }
    */


    delete abce;

    return 0;
}
