#include <fstream>

using namespace std;

template<typename T>
class AVL
{
private:

  struct Node
  {
    T m_val;
    Node* m_leftChild;
    Node* m_rightChild;
    Node* m_father;

    int m_maxDepth;

    Node() :
      m_leftChild(nullptr), m_rightChild(nullptr), m_father(nullptr), m_maxDepth(1) {};

    Node(T val, Node* father = nullptr, int m_maxDepth = 1) :
      m_val(val), m_leftChild(nullptr), m_rightChild(nullptr), m_father(father) {};
  };

  Node* m_root;

public:

  struct Iterator
  {
    AVL<T>* m_avl;
    Node* m_node;

    Iterator(AVL<T>* avl = nullptr, Node* node = nullptr) :
      m_avl(avl), m_node(node) {};

    T& operator *()
    {
      return m_node->m_val;
    }

    Iterator operator ++()
    {
      if (m_node->m_rightChild != nullptr)
      {
        m_node = m_node->m_rightChild;

        while (m_node->m_leftChild != nullptr)
          m_node = m_node->m_leftChild;

        return *this;
      }

      while (m_node != m_avl->m_end.m_node && m_node->m_father->m_rightChild == m_node)
        m_node = m_node->m_father;

      if (m_node == m_avl->m_end.m_node)
        return *this;

      m_node = m_node->m_father;

      return *this;
    }

    Iterator operator --()
    {
      if (m_node->m_leftChild != nullptr)
      {
        m_node = m_node->m_leftChild;

        while (m_node->m_rightChild != nullptr)
          m_node = m_node->m_rightChild;

        return *this;
      }

      while (m_node != m_avl->m_end.m_node && m_node->m_father->m_leftChild == m_node)
        m_node = m_node->m_father;

      if (m_node == m_avl->m_end.m_node)
        return *this;

      m_node = m_node->m_father;

      return *this;
    }

    bool operator !=(const Iterator& other) const
    {
      return m_node != other.m_node;
    }

    bool operator ==(const Iterator& other) const
    {
      return m_node == other.m_node;
    }
  };

  Iterator m_begin;
  Iterator m_end;

  Iterator begin() const { return m_begin; }
  Iterator end() const { return m_end; }

public:

  AVL()
  {
    m_root  = new Node();
    m_begin = Iterator(this, m_root);
    m_end   = Iterator(this, m_root);
  }

  void resetDepths(Node* node)
  {
    while (node != nullptr)
    {
      node->m_maxDepth = 1;

      if (node->m_leftChild != nullptr)
          node->m_maxDepth = max(node->m_maxDepth, node->m_leftChild->m_maxDepth + 1);
      if (node->m_rightChild != nullptr)
          node->m_maxDepth = max(node->m_maxDepth, node->m_rightChild->m_maxDepth + 1);

      node = node->m_father;
    }
  }

  void rotateRight(Node* node)
  {
    if (node->m_father == nullptr) return;
    if (node->m_leftChild == nullptr) return;

    auto leftChild = node->m_leftChild;

    removeFatherReference(node, leftChild);
    node->m_father = leftChild;
    if (leftChild->m_rightChild != nullptr)
    {
      node->m_leftChild = leftChild->m_rightChild;
      leftChild->m_rightChild->m_father = node;
    }
    else
    {
      node->m_leftChild = nullptr;
    }
    leftChild->m_rightChild = node;
  }

  void rotateLeft(Node* node)
  {
    if (node->m_father == nullptr) return;
    if (node->m_RightChild == nullptr) return;

    auto rightChild = node->m_rightChild;

    removeFatherReference(node, rightChild);
    node->m_father = rightChild;
    if (rightChild->m_leftChild != nullptr)
    {
      node->m_rightChild = rightChild->m_leftChild;
      rightChild->m_leftChild->m_father = node;
    }
    else
    {
      node->m_rightChild = nullptr;
    }
    rightChild->m_leftChild = node;
  }

  void rotation(Node* node)
  {
    while (node != nullptr && node != m_root)
    {

      node = node->m_father;
    }
  }

  bool insert(T val)
  {
    Node* crtNode = m_root->m_leftChild;

    while (crtNode != nullptr)
    {
      if (val < crtNode->m_val)
      {
        if (crtNode->m_leftChild != nullptr)
          crtNode = crtNode->m_leftChild;
        else
        {
          crtNode->m_leftChild = new Node(val, crtNode);
          resetDepths(crtNode->m_leftChild);
          rotation(crtNode->m_leftChild);
          if (m_begin.m_node == m_root || crtNode->m_leftChild->m_val < m_begin.m_node->m_val)
            m_begin.m_node = crtNode->m_leftChild;
          return true;
        }
      }
      else if (val == crtNode->m_val)
      {
        return false;
      }
      else // (val > crtNode->m_val)
      {
        if (crtNode->m_rightChild != nullptr)
          crtNode = crtNode->m_rightChild;
        else
        {
          crtNode->m_rightChild = new Node(val, crtNode);
          resetDepths(crtNode->m_rightChild);
          rotation(crtNode->m_rightChild);
          return true;
        }
      }
    }

    m_root->m_leftChild = new Node(val, m_root);
    resetDepths(m_root->m_leftChild);
    rotation(m_root->m_leftChild);
    m_begin.m_node = m_root->m_leftChild;
    return true;
  }

  void removeFatherReference(Node* node, Node* newReference = nullptr)
  {
    if (node->m_father->m_leftChild == node)
      node->m_father->m_leftChild  = newReference;
    else
      node->m_father->m_rightChild = newReference;

    if (newReference != nullptr)
      newReference->m_father = node->m_father;
  }

  bool erase(T val)
  {
    auto it = find(val);

    if (it == m_end) return false;

    if (it.m_node->m_leftChild == nullptr && it.m_node->m_rightChild == nullptr)
    {
      auto father = it.m_node->m_father;

      removeFatherReference(it.m_node);
      delete it.m_node;

      resetDepths(father);
      rotation(father);
    }
    else if (it.m_node->m_leftChild == nullptr)
    {
      auto rightChild = it.m_node->m_rightChild;

      removeFatherReference(it.m_node, it.m_node->m_rightChild);
      delete it.m_node;

      resetDepths(rightChild);
      rotation(rightChild);
    }
    else if (it.m_node->m_rightChild == nullptr)
    {
      auto leftChild = it.m_node->m_leftChild;

      removeFatherReference(it.m_node, it.m_node->m_leftChild);
      delete it.m_node;

      resetDepths(leftChild);
      rotation(leftChild);
    }
    else
    {
      auto next = it;
      ++next;

      if (next.m_node == it.m_node->m_rightChild)
      {
        auto rightChild = next.m_node->m_rightChild;

        removeFatherReference(it.m_node, next.m_node);
        it.m_node->m_leftChild->m_father = next.m_node;
        next.m_node->m_leftChild = it.m_node->m_leftChild;

        resetDepths(rightChild);
        rotation(rightChild);
      }
      else
      {
        next.m_node->m_father->m_leftChild = next.m_node->m_rightChild;

        if (next.m_node->m_rightChild != nullptr)
        {
          next.m_node->m_rightChild->m_father = next.m_node->m_father;
          resetDepths(next.m_node->m_rightChild);
          rotation(next.m_node->m_rightChild);
        }
        else
        {
          resetDepths(next.m_node->m_father);
          rotation(next.m_node->m_father);
        }

        removeFatherReference(it.m_node, next.m_node);

        it.m_node->m_leftChild->m_father = next.m_node;
        next.m_node->m_leftChild = it.m_node->m_leftChild;

        it.m_node->m_rightChild->m_father = next.m_node;
        next.m_node->m_rightChild = it.m_node->m_rightChild;
      }

      delete it.m_node;
    }

    return true;
  }

  Iterator find(T val)
  {
     auto it = lower_bound(val);

     if (it != m_end && *it != val)
       it = m_end;

    return it;
  }

  Iterator lower_bound(T val)
  {
    Node* best = m_root;

    Node* nodeCrt = m_root->m_leftChild;

    while (nodeCrt != nullptr)
    {
      if (val < nodeCrt->m_val)
      {
        best = nodeCrt;
        nodeCrt = nodeCrt->m_leftChild;
      }
      else if (val == nodeCrt->m_val)
        return Iterator(this, nodeCrt);
      else
        nodeCrt = nodeCrt->m_rightChild;
    }

    return Iterator(this, best);
  }

  Iterator upper_bound(T val)
  {
    Node* best = m_root;

    Node* nodeCrt = m_root->m_leftChild;

    while (nodeCrt != nullptr)
    {
      if (val < nodeCrt->m_val)
      {
        best = nodeCrt;
        nodeCrt = nodeCrt->m_leftChild;
      }
      else
        nodeCrt = nodeCrt->m_rightChild;
    }

    return Iterator(this, best);
  }
};

AVL<int> s;

int main()
{
  ifstream in("abce.in");
  ofstream out("abce.out");

  int q;
  in >> q;

  for (int i = 1; i <= q; i++)
  {
    int op;
    int x;
    in >> op >> x;

    if (op == 1)
    {
      s.insert(x);
    }
    else if (op == 2)
    {
      s.erase(x);
    }
    else if (op == 3)
    {
      if (s.find(x) != s.end())
        out << 1 << '\n';
      else
        out << 0 << '\n';
    }
    else if (op == 4)
    {
      out << *(--s.upper_bound(x)) << '\n';
    }
    else if (op == 5)
    {
      out << *s.lower_bound(x) << '\n';
    }
    else if (op == 6)
    {
      int y;
      in >> y;

      auto upperBound = s.upper_bound(y);

      for (auto it = s.lower_bound(x); it != upperBound; ++it)
      {
        out << *it << ' ';
      }
      out << '\n';
    }
  }

  return 0;
}
