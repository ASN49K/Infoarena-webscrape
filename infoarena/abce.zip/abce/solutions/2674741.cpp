#include <fstream>
#include <set>

std::ifstream fin("abce.in");
std::ofstream fout("abce.out");

std::multiset <int> s;

int q, o, x, y;

int main()
{
	fin >> q;
	while (q--)
	{
		fin >> o >> x;
		if (o == 1)
			s.insert(x);
		else if (o == 2)
			s.erase(x);
		else if (o == 3)
		{
			if (s.find(x) != s.end())
				fout << "1\n";
			else fout << "0\n";
		}
		else if (o == 4)
			fout << *(--s.upper_bound(x)) << "\n";
		else if (o == 5)
			fout << *s.lower_bound(x) << "\n";
		else
		{
			fin >> y;
			auto it = s.lower_bound(x);
			while (it != s.end() && *it <= y)
			{
				fout << *it << " ";
				++it;
			}
			fout << "\n";
		}
	}
	fout.close();
	return 0;
}