#include <iostream>
#include <fstream>
#include <limits>
#include <math.h>
#include <sstream>
#include <time.h>

const int VAL_MIN = std::numeric_limits<int>::min();
std::ifstream f("abce.in");
std::ofstream g("abce.out");

struct Nod{
    int val;
    Nod* dreapta;
    Nod* jos;

    Nod(int val = VAL_MIN){                  
        this->val = val;
        this->dreapta = NULL;
        this->jos = NULL;
    }
};

class SkipList{
    int nivel;                               
    int lungime;                            
    Nod* cap;                                                      

public:
    SkipList();

    Nod* cautare(const int&);
    void inserare(const int&);
    void nivelNou(Nod*);
    void sterge(const int&);
    int predecesor(const int&);
    const Nod* succesor(const int&);
    void afisInterval(const int&, const int&, std::ostringstream&);

    ~SkipList();
};

SkipList::SkipList(){                        
    this->nivel = 1;
    this->lungime = 0;
    this->cap = new Nod();
}

void SkipList::nivelNou(Nod* nodLegatura){
    ++this->nivel;
    Nod* capNou = new Nod();
    capNou->jos = this->cap;
    this->cap = capNou;
    this->cap->dreapta = nodLegatura;
}

Nod* SkipList::cautare(const int& val){
    Nod* nodCurent = this->cap;
    
    while(val > nodCurent->val){
         if(nodCurent->dreapta != NULL && val >= nodCurent->dreapta->val){
            nodCurent = nodCurent->dreapta;
            while(nodCurent->dreapta != NULL && val >= nodCurent->dreapta->val)
                nodCurent = nodCurent->dreapta;
        } 
        else
            if(nodCurent->jos != NULL){
                nodCurent = nodCurent->jos;
            }
            else
                break;
    }
    return nodCurent;
}

void SkipList::inserare(const int& val){
    Nod* nodInainte = this->cautare(val);

    ++this->lungime;
    int nivelCurent = 1;

    Nod* nodNou = new Nod(val);
    nodNou->jos = NULL;                       
    nodNou->dreapta = nodInainte->dreapta;    
    nodInainte->dreapta = nodNou;

    bool urcare = rand() & 1;
    while(urcare && nivelCurent + 1 <= log(this->lungime)){
        ++nivelCurent;

        Nod* nodNivelSuperior = new Nod(val);
        nodNivelSuperior->jos = nodNou;
        nodNou = nodNivelSuperior;    

        if(nivel < nivelCurent){
            this->nivelNou(nodNivelSuperior);
        }
       
        else{
            nodInainte = this->cap;

            int nivelDeParcurs = nivel;
            while(nivelDeParcurs > nivelCurent){
                while(nodInainte->dreapta != NULL && val > nodInainte->dreapta->val)
                    nodInainte = nodInainte->dreapta;
                nodInainte = nodInainte->jos;
                --nivelDeParcurs;
            }

            while(nodInainte->dreapta != NULL && val > nodInainte->dreapta->val)
                nodInainte = nodInainte->dreapta;
        
            nodNivelSuperior->dreapta = nodInainte->dreapta;
            nodInainte->dreapta = nodNivelSuperior;

            urcare = rand() & 1;
        }
    }
}

void SkipList::sterge(const int& val){
    if(this->lungime > 0){
        Nod* nodCurent = this->cap;
        Nod* vecinStanga = this->cap;

        while(val > nodCurent->val){
            if(nodCurent->dreapta != NULL && val >= nodCurent->dreapta->val){
                vecinStanga = nodCurent;
                nodCurent = nodCurent->dreapta;
                while(nodCurent->dreapta != NULL && val >= nodCurent->dreapta->val){
                    vecinStanga = nodCurent;
                    nodCurent = nodCurent->dreapta;
                }
            }
            else
                if(nodCurent->jos != NULL){
                    nodCurent = nodCurent->jos;
                    vecinStanga = vecinStanga->jos;
                    if(vecinStanga != nodCurent)
                        while(vecinStanga->dreapta != nodCurent)
                            vecinStanga = vecinStanga->dreapta;
                }
                else
                    break;
        }
        
        if(val == nodCurent->val){
            --this->lungime;
            while(nodCurent != NULL){
                bool coboara = 0;

                while(vecinStanga->dreapta != nodCurent)
                    vecinStanga = vecinStanga->dreapta;
                
                Nod* aux = nodCurent->jos;
                vecinStanga->dreapta = nodCurent->dreapta;
                delete nodCurent;
                nodCurent = aux;

                if(vecinStanga->val == VAL_MIN && vecinStanga->dreapta == NULL && vecinStanga->jos != NULL){
                    --this->nivel;
                    this->cap = vecinStanga->jos;
                    aux = vecinStanga->jos;
                    delete vecinStanga;
                    vecinStanga = aux;
                    coboara = 1;
                }
                if(!coboara)
                    vecinStanga = vecinStanga->jos;
            }
        }
    }
}

int SkipList::predecesor(const int& val){
    return this->cautare(val)->val;
}

const Nod* SkipList::succesor(const int& val){
    Nod* nodGasit = this->cautare(val);
    if(nodGasit->val == val)
        return nodGasit;

    while(nodGasit->jos != NULL)
        nodGasit = nodGasit->jos;
    return nodGasit->dreapta;
}

void SkipList::afisInterval(const int& mini, const int& maxi, std::ostringstream& buff){
    const Nod* capatStanga = this->succesor(mini);
    while(capatStanga->jos != NULL)
        capatStanga = capatStanga->jos;

    if(capatStanga->val <= maxi)
        buff << capatStanga->val << ' ';

    while(capatStanga->dreapta != NULL && capatStanga->dreapta->val <= maxi){
        capatStanga = capatStanga->dreapta;
        buff << capatStanga->val << ' ';
    }
}

SkipList::~SkipList(){
    while(this->cap != NULL){
        Nod* nodCurent = this->cap->dreapta;
        Nod* aux = nodCurent;

        while(nodCurent != NULL){
            nodCurent = nodCurent->dreapta;
            delete aux;
            aux = nodCurent;
        }

        aux = this->cap->jos;
        delete this->cap;
        this->cap = aux;
    }
}

int main(){
    srand(time(NULL));

    SkipList skip;
    int q, operatie, x;
    std::ostringstream buff;
 
    f >> q;
    while(q){
        f >> operatie;
        switch(operatie){
            case 1:{
                f >> x;
                skip.inserare(x);
                break;
            }

            case 2:{
                f >> x;
                skip.sterge(x);
                break;
            }

            case 3:{
                f >> x;
                buff << (skip.cautare(x)->val == x) << "\n";
                break;
            }

            case 4:{
                f >> x;
                buff << skip.predecesor(x) << "\n";
                break;
            }

            case 5:{
                f >> x;
                buff << skip.succesor(x)->val << "\n";
                break;
            }

            case 6:{
                int y;
                f >> x >> y; 
                skip.afisInterval(x, y, buff);
                buff << "\n";
                break;
            }
        }
        --q;
    }

    g << buff.str();

    f.close();
    g.close();
    return 0;
}