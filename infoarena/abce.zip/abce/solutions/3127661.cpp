#include <iostream>
#include <cstdlib>
#include <queue>

using namespace std;

class Treaps
{
    class Node
    {
    public:
        int value;
        int code;
        Node *left;
        Node *right;
        Node *parent;

        Node(int value_, int code_)
        {
            value = value_;
            code = code_;
            left = NULL;
            right = NULL;
            parent = NULL;
        }

        void print_node()
        {

            cout << endl;
            cout << "Node: " << value << " " << code << endl;
            if (parent != NULL)
            {
                cout << "Parent: " << parent->value << endl;
            }
            else
            {
                cout << "Parent: NULL" << endl;
            }
            if (left != NULL)
            {
                cout << "Left: " << left->value << endl;
            }
            else
            {
                cout << "Left: NULL" << endl;
            }
            if (right != NULL)
            {
                cout << "Right: " << right->value << endl;
            }
            else
            {
                cout << "Right: NULL" << endl;
            }
        }
    };

    Node *root_;

    Node *insert_(Node *node, int value, int code);
    Node *find_(Node *node, int value);
    Node *remove_(Node *node, int value);

    Node *rotate_left(Node *node);
    Node *rotate_right(Node *node);

public:
    Treaps()
    {
        root_ = NULL;
    }

    void insert(int value, int code);
    bool find(int value);
    void remove(int value);

    //! to be deleted
    void print();
    bool empty();
};

Treaps::Node *Treaps::rotate_left(Node *node)
{
    Node *other = node->right;
    other->parent = node->parent;
    if (other->parent != NULL)
    {
        if (other->parent->left == node)
            other->parent->left = node;
        else
            other->parent->right = other;
    }
    node->right = other->left;
    if (node->right != NULL)
        node->right->parent = node;
    node->parent = other;
    other->left = node;
    if (node == root_)
    {
        root_ = other;
        root_->parent = NULL;
    }
    return other;
}

Treaps::Node *Treaps::rotate_right(Node *node)
{
    //* We must be careful of a boundary case
    //! when u is the root

    Node *other = node->left;
    other->parent = node->parent;
    if (other->parent != NULL)
    {
        if (other->parent->left == node)
            other->parent->left = other;
        else
            other->parent->right = other;
    }
    node->left = other->right;
    if (node->left != NULL)
        node->left->parent = node;
    node->parent = other;
    other->right = node;
    if (node == root_)
    {
        root_ = other;
        root_->parent = NULL;
    }
    return other;
}

Treaps::Node *Treaps::insert_(Node *node, int value, int code)
{
    if (node == NULL)
        node = new Node(value, code);
    else
    {
        if (value <= node->value)
        {
            node->left = insert_(node->left, value, code);
            node->left->parent = node;
            // fata de BSTs, Treaps mai au proprietatea sa verifice codul (pt prioritate) a valorilor adaugate
            // codul trebuie sa fie mai mare fata de parinte (teorie Cormen)
            if (node->left->code < node->code)
                node = rotate_right(node);
            // rotim pentru echilibrare
            // fiind pe ramura stanga, echilibram pe dreapta
        }
        else
        {
            node->right = insert_(node->right, value, code);
            node->right->parent = node;
            if (node->right->code < node->code)
                // fiind pe ramura dreapta, echilibram pe stanga
                node = rotate_left(node);
        }
    }
    return node;
}

void Treaps::insert(int value, int code)
{
    root_ = insert_(root_, value, code);
}

Treaps::Node *Treaps::find_(Node *node, int value)
{
    if (node == NULL)
        return NULL;
    if (value == node->value)
        return node;
    else if (value <= node->value)
        return find_(node->left, value);
    else
        return find_(node->right, value);
}

bool Treaps::find(int value)
{
    Node *found = find_(root_, value);
    if (found == NULL)
        return false;
    else
        return true;
}

Treaps::Node *Treaps::remove_(Node *node, int value)
{
    if (node == NULL)
        return NULL;
    if (value < node->value)
        node->left = remove_(node->left, value);
    else if (value > node->value)
        node->right = remove_(node->right, value);
    else
    {
        // am gasit nodul pe care vrem sa il eliminam

        // Cazul 1,nodul este o frunza
        if (node->left == NULL && node->right == NULL)
        {
            delete node;
            return NULL;
        }

        // Cazul 2, nodul are un singur copil
        if (node->left == NULL)
        {
            Node *R_C = node->right;
            delete node;
            node = R_C;
        }
        else if (node->right == NULL)
        {
            Node *L_C = node->left;
            delete node;
            node = L_C;
        }
        else if (node->left->code < node->right->code)
        {
            node = rotate_left(node);
            node->left = remove_(node->left, value);
        }
        else if (node->right->code <= node->left->code)
        {
            node = rotate_right(node);
            node->right = remove_(node->right, value);
        }
    }
    return node;
}

void Treaps::remove(int value)
{
    root_ = remove_(root_, value);
}

void Treaps::print()
{
    queue<Node *> to_visit;
    if (empty())
    {
        throw invalid_argument("Nothing to print, tree empty.");
    }
    else
    {
        to_visit.push(root_);
        Node *current = root_;
        cout << "----------print--";
        while (!to_visit.empty())
        {
            current->print_node();
            if (current->left != NULL)
            {
                to_visit.push(current->left);
            }
            if (current->right != NULL)
            {
                to_visit.push(current->right);
            }
            to_visit.pop();
            current = to_visit.front();
        }
    }
}

bool Treaps::empty()
{
    if (root_ == NULL)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    Treaps tree;
    int Q, choice, nr;
    cin >> Q;
    for (int i = 1; i <= Q; i++)
    {
        cin >> choice;
        switch (choice)
        {
        case 1:
            cin >> nr;
            tree.insert(nr, rand() % 65535);
            break;
        case 2:
            cin >> nr;
            tree.remove(nr);
            break;
        case 3:
            cin >> nr;
            cout << tree.find(nr);
            break;
        }
    }

    // tree.insert(15, rand() % 65535);
    // tree.insert(6, rand() % 65535);
    // tree.insert(18, rand() % 65535);
    // tree.insert(4, rand() % 65535);

    // tree.print();

    // tree.remove(18);

    // tree.print();

    // cout << tree.find(6) << endl;
    // cout << tree.find(18) << endl;
    // cout << tree.find(20) << endl;

    // if (tree.find(6) == 1)
    //     cout << "exista\n";
    // else
    //     cout << "nu exista\n";

    // if (tree.find(20) == 1)
    //     cout << "exista\n";
    // else
    //     cout << "nu exista\n";

    return 0;
}