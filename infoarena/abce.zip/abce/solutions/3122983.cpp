#include <iostream>
#include <fstream>
using namespace std;

const int BranchingFactor = 2;

class Node{
public:
    int min_keys;
    int n_keys;
    int n_child;
    int* keys;
    Node** child;
    Node* parent;
    bool isLeaf;
    //static int BranchingFactor;
    Node();
    Node(int key);
    Node(Node* parentNode);
    int keySize()const;
    void insertKey(int key);
    void traverse()const; // to be deleted after
    void deleteLeafPos(int PosToDelete);
    void deleteNonLeafPos(int PosToDelete);
    void deleteElement(int toDelete);
    int getLower(int pos);//numarul lower < keys[pos];
    int getHigher(int pos);//numarul higher > keys[pos];
    void mergeNode(int pos);//merge cu urmatorul nod
    void fixChild(int pos);
    void borrowNext(int pos);//child[i] ia de la child[i + 1] daca are destule chei
    void borrowPrev(int pos);//child[i] ia de la child[i - 1] daca are destule chei
    friend class Btree;
};

class Btree{
    int min_keys;
public:
    Node* root;
    Btree();
    void insertElement(int toInsert);
    void insertElement(int toInsert, Node* currentNode);
    void deleteElement(int toDelete);
    bool searchElement(int toSearch);
    bool searchElement(int toSearch, Node* currentNode);
    int cerinta4(int X);
    int cerinta5(int X);
    void show();
};

//int Node::BranchingFactor = 2;


int main()
{
    Btree b_tree;
    ifstream fin("abce.in");
    ofstream fout("abce.out");

    int t, cerinta, X;
    fin >> t;
    while(t)
    {
        fin >> cerinta >> X;
        if(cerinta == 1){
            b_tree.insertElement(X);
        }
        else if(cerinta == 2){
            b_tree.deleteElement(X);
        }
        else if(cerinta == 3){
            fout << b_tree.searchElement(X) << endl;
        }
        else if(cerinta == 4){
            ///fout << b_tree.cerinta4(X) << endl;
        }
        else if(cerinta == 5){
            ///fout << b_tree.cerinta5(X) << endl;
        }
        else if(cerinta == 6){
            int Y;
            fin >> Y;
            ///fout << b_tree.cerinta6(X, Y) << endl;
        }
        t--;
    }
    fin.close();
    fout.close();
    return 0;
}

Node::Node()
{
    if(BranchingFactor % 2 == 0)
        min_keys = BranchingFactor/2;
    else
        min_keys = (BranchingFactor + 1)/2;
    n_keys = 0;
    keys = new int[2*BranchingFactor - 1];
    child = new Node*[2*BranchingFactor];
    isLeaf = true;
    parent = nullptr;
}

Node::Node(int key)
{
    if(BranchingFactor % 2 == 0)
        min_keys = BranchingFactor/2;
    else
        min_keys = (BranchingFactor + 1)/2;
    n_keys = 1;
    keys = new int[2*BranchingFactor - 1];
    child = new Node*[2*BranchingFactor];
    keys[0] = key;
    isLeaf = true;
    parent = nullptr;
}

Node::Node(Node * parentNode)
{
    n_keys = 0;
    keys = new int[2*BranchingFactor - 1];
    child = new Node*[2*BranchingFactor];
    isLeaf = true;
    this->parent = parentNode;
}

int Node::keySize() const
{
    return n_keys;
}

void Node::traverse() const {
    int i;
    for (i = 0; i < n_keys; i++) {
        if (!isLeaf) {
            if (child[i] != nullptr)
                child[i]->traverse();
            else
                cout << " nullptr";
        }
        cout << " " << keys[i];
    }
    if (!isLeaf)
        child[i]->traverse();
}

void Node::deleteLeafPos(int PosToDelete)
{
    for(int i = PosToDelete; i < n_keys - 1; i++)
        keys[i] = keys[i + 1];
    n_keys--;
    return;
}

void Node::deleteNonLeafPos(int PosToDelete)
{
    int aux = keys[PosToDelete];

    if(child[PosToDelete]->n_keys >= min_keys){
        //pot sa ma imprumut din dreapta
        int lower = getLower(PosToDelete);
        keys[PosToDelete] = lower;
        child[PosToDelete]->deleteElement(lower);
    }
    else if(child[PosToDelete + 1]->n_keys >= min_keys){
        int higher = getHigher(PosToDelete);
        keys[PosToDelete] = higher;
        child[PosToDelete + 1]->deleteElement(higher);
    }
    else{
        mergeNode(PosToDelete);
        child[PosToDelete]->deleteElement(aux);
    }
    return;
}

void Node::deleteElement(int toDelete)
{
    int i = 0;
    while(i < n_keys && toDelete > keys[i])
        i++;

    if(keys[i] == toDelete){
        if(this->isLeaf)
            this->deleteLeafPos(i);
        else
            this->deleteNonLeafPos(i);
    }
    else{
        if(this->isLeaf)
            return;
        bool isFound = false;
        if(i == n_keys) isFound = true;

        if(this->child[i]->n_keys < min_keys)
            fixChild(i);

        if(isFound && i > n_keys)
            this->child[i - 1]->deleteElement(toDelete);
        else
            this->child[i]->deleteElement(toDelete);
    }
    return;
}

Btree::Btree()
{
    //min_keys = BranchingFactor - 1;
    if(BranchingFactor % 2 == 0)
        min_keys = BranchingFactor/2;
    else
        min_keys = (BranchingFactor + 1)/2;
    root = nullptr;
}

void Btree::insertElement(int toInsert)
{
    /*
    if(root != nullptr)
    {
        cout << endl;
        cout << "Traversing: ";
        root->traverse();
        cout << endl;
    }DEBUG */
    if(root == nullptr){
        root = new Node(toInsert);
        //cout << toInsert << ": " << "if root == nullptr\n"; DEBUG
    }
    else{
        //cout << toInsert << ": " << "else\n"; DEBUG
        Node* currentNode = root;
        Node* parentNode = nullptr;

        while(currentNode->isLeaf == false){
            //cout << toInsert << ": " << "While currentNode->isLeaf == false\n"; DEBUG
            ///parcurg nodurile pana dau de o frunza
            parentNode = currentNode;
            parentNode->isLeaf = false; // ???????
            int i = 0;
            while(i < currentNode->n_keys && toInsert > currentNode->keys[i]){
                i++;
                //cout << toInsert << ": " << "while(i < currentNode->n_keys && toInsert > currentNode->keys[i])\n"; DEBUG
            }
            currentNode = currentNode->child[i];
        }
        currentNode->insertKey(toInsert);
        ///inserez, daca e full => split
        while(currentNode->n_keys == 2*BranchingFactor - 1){
            //cout << toInsert << ": " << "while(currentNode->n_keys == 2*BranchingFactor - 1)\n"; DEBUG
            if(currentNode == root){
                //for(int i = 0; i < currentNode->n_keys; i++)
                    //cout << currentNode->keys[i] << " "; DEBUG

                //cout << toInsert << ": " << "if(currentNode == root)\n"; DEBUG
                ///daca e radacina => fac o radacina noua
                Node* newRoot = new Node(currentNode->keys[BranchingFactor - 1]);
                ///urc elementul din mijloc
                newRoot->isLeaf = false;
                newRoot->child[0] = currentNode;
                Node* newNode = new Node();
                newNode->isLeaf = currentNode->isLeaf; // error because of this
                newNode->n_keys = BranchingFactor - 1;

                for(int i = 0; i < BranchingFactor - 1; i++)
                    newNode->keys[i] = currentNode->keys[i + BranchingFactor];

                for(int i = 0; i <= newNode->n_keys; i++)
                    newNode->child[i] = currentNode->child[i + BranchingFactor];

                currentNode->n_keys = BranchingFactor - 1;
                newRoot->child[1] = newNode;
                currentNode = newRoot;
                root = newRoot;
                parentNode = nullptr;
            }
            else{
                //cout << toInsert << ": " << "else\n"; DEBUG
                ///split si urc mijlocul la parent
                Node* newNode = new Node();
                newNode->isLeaf = currentNode->isLeaf; // changed from = true;
                newNode->n_keys = BranchingFactor - 1;
                for(int i = 0; i < BranchingFactor - 1; i++)
                    newNode->keys[i] = currentNode->keys[i + BranchingFactor];

                currentNode->n_keys = BranchingFactor - 1;

                for(int i = 0; i <= newNode->n_keys; i++)
                    newNode->child[i] = currentNode->child[i + BranchingFactor];

                int keyToParent = currentNode->keys[BranchingFactor - 1];
                int i = parentNode->n_keys;
                ///de la dreapta la stanga fac loc pentru cheie in timp ce ii gasesc pozitia potrivita
                while(i > 0 && keyToParent < parentNode->keys[i - 1]){
                        parentNode->keys[i] = parentNode->keys[i - 1];
                        parentNode->child[i + 1] = parentNode->child[i];
                        i--;
                }
                parentNode->keys[i] = keyToParent;
                parentNode->child[i + 1] = newNode;
                parentNode->n_keys++;

                currentNode = parentNode;
            }
        }
    }
}


void Node::fixChild(int pos)
{
    //ma pot imprumuta din stanga
    if(pos != 0 && child[pos - 1]->n_keys >= min_keys)
        borrowPrev(pos);
    else if(pos != n_keys && child[pos + 1]->n_keys >= min_keys)
        borrowNext(pos);
    else{
        if(pos != n_keys)
            mergeNode(pos);
        else
            mergeNode(pos - 1);
    }
    return;
}


void Node::insertKey(int toInsert) {
    int i = n_keys - 1;
    while (i >= 0 && keys[i] > toInsert) {
        keys[i + 1] = keys[i];
        i--;
    }
    keys[i + 1] = toInsert;
    n_keys++;
}

int Node::getLower(int pos)
{
    Node* curentNode = child[pos];
    while(!curentNode->isLeaf)
        curentNode = curentNode->child[curentNode->n_keys];
    return curentNode->keys[n_keys - 1];
}

int Node::getHigher(int pos)
{
    Node* curentNode = child[pos + 1];
    while(!curentNode->isLeaf)
        curentNode = curentNode->child[0];
    return curentNode->keys[0];
}

void Node::mergeNode(int pos)
{
    Node* mergeHere = child[pos];
    Node* mergeFrom = child[pos + 1];

    mergeHere->keys[min_keys - 1] = keys[pos];

    for(int i = 0; i < mergeFrom->n_keys; i++)
        mergeHere->keys[min_keys + i] = mergeFrom->keys[i];

    if(!mergeHere->isLeaf){
        for(int i = 0; i <= mergeFrom->n_keys; i++)
            mergeHere->child[i + 1] = mergeFrom->child[i];
    }

    for(int i = pos; i < n_keys - 1; i++)
        keys[i] = keys[i + 1];

    for(int i = pos + 1; i < n_keys; i++)
        child[i] = child[i + 1];
    mergeHere->n_keys += mergeFrom->n_keys + 1;
    n_keys--;
    delete mergeFrom;
    return;
}

void Node::borrowNext(int pos)
{
    Node *dest = child[pos];
    Node* source = child[pos + 1];

    dest->keys[dest->n_keys] = keys[pos];

    if(!dest->isLeaf)
        dest->child[dest->n_keys + 1] = source->child[0];

    keys[pos] = source->keys[0];

    for(int i = 0; i < source->n_keys - 1; i++)
        source->keys[i] = source->keys[i + 1];

    if(!source->isLeaf){
        for(int i = 0; i < source->n_keys; i++)
            source->child[i] = source->child[i + 1];
    }

    dest->n_keys++;
    source->n_keys--;
    return;
}

void Node::borrowPrev(int pos)
{
    Node* dest = child[pos];
    Node* source = child[pos - 1];

    for(int i = dest->n_keys; i>= 1; i--)
        dest->keys[i] = dest->keys[i - 1];

    if(!dest->isLeaf)
        for(int i = dest->n_keys + 1; i >= 1; i--)
            dest->child[i] = dest->child[i - 1];

    dest->keys[0] = keys[pos - 1];
    if(!dest->isLeaf)
        dest->child[0] = source->child[dest->n_keys];

    keys[pos - 1] = source->keys[source->n_keys - 1];

    dest->n_keys++;
    source->n_keys--;

    return;
}

bool Btree::searchElement(int toSearch)
{
    return searchElement(toSearch, root);
}

bool Btree::searchElement(int toSearch, Node* currentNode)
{
    int i = 0;

    if(currentNode == nullptr)
        return false;

    if(currentNode->n_keys == 0)
        return false;

    while(i < currentNode->n_keys && toSearch > currentNode->keys[i])
        i++;
    if(currentNode->keys[i] == toSearch){
        return true;
    }
    else if(currentNode->isLeaf == true){
        return false;
    }
    else{
        return searchElement(toSearch, currentNode->child[i]);
    }
}

void Btree::deleteElement(int toDelete)
{
    if(root == nullptr)
        return;
    root->deleteElement(toDelete);

    if(root->n_keys == 0)
    {
        Node* aux = root;
        if(root->isLeaf)
            root = nullptr;
        else
            root = root->child[0];
        delete aux;
    }
    return;
}


void Btree::show()
{
    root->traverse();
}
