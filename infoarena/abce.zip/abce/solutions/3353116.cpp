#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class avl {
private:
    struct node {
        int key;
        node* left;
        node* right;
        int height;

        node(int x) {
            key = x;
            left = nullptr;
            right = nullptr;
            height = 1;
        }
    };

    node* root;

    int height(node* node) {
        if (node == nullptr)
            return 0;

        return node->height;
    }

    int balanceFactor(node* node) {
        if (node == nullptr)
            return 0;

        return height(node->left) - height(node->right);
    }

    node* rotateRight(node* a) {
        node* b = a->left;
        node* temp = b->right;

        b->right = a;
        a->left = temp;

        a->height = 1 + max(height(a->left), height(a->right));
        b->height = 1 + max(height(b->left), height(b->right));

        return b;
    }

    node* rotateLeft(node* a) {
        node* b = a->right;
        node* temp = b->left;

        b->left = a;
        a->right = temp;

        a->height = 1 + max(height(a->left), height(a->right));
        b->height = 1 + max(height(b->left), height(b->right));

        return b;
    }

    void add_helper(node* &root, int x) {
        if (root == nullptr)
            root = new node(x);
        else
            if (x < root->key)
                add_helper(root->left, x);
            else
                add_helper(root->right, x);

        root->height = 1 + max(height(root->left), height(root->right));

        int balance = balanceFactor(root);

        if (balance > 1)
            if (balanceFactor(root->left) >= 0) // cazul LL
                root = rotateRight(root);
            else { // cazul LR
                root->left = rotateLeft(root->left); // cazul LR
                root = rotateRight(root);
            }

        if (balance < -1)
            if (balanceFactor(root->right) <= 0) // cazul RR
                root = rotateLeft(root);
            else {
                root->right = rotateRight(root->right); // cazul RL
                root = rotateLeft(root);
            }
    }

    bool search_helper(node* &root, int x) {
        if (root == nullptr)
            return false;
        else {
            if (root->key == x)
                return true;
            else if (root->key > x)
                return search_helper(root->left, x);
            else return search_helper(root->right, x);
        }
    }

    void delete_helper(node* &root, int x) {
        if (root != nullptr) {
            if (x < root->key)
                delete_helper(root->left, x);
            else if (x > root->key)
                delete_helper(root->right, x);
            else {
                if (root->left == nullptr && root->right == nullptr) {
                    delete root;
                    root = nullptr;
                }else {
                    if (root->left != nullptr && root->right == nullptr) {
                        node* temp = root->left;
                        root = root->left;
                        delete temp;
                    }else if (root->right != nullptr && root->left == nullptr) {
                        node* temp = root->right;
                        root = root->right;
                        delete temp;
                    }else {
                        node* pred = root->left;

                        while (pred->right != nullptr)
                            pred = pred->right;

                        swap (root->key, pred->key);
                        delete_helper(root->left, pred->key);
                    }
                }
            }

            if (root == nullptr)
                return;

            root->height = 1 + max(height(root->left), height(root->right));

            int balance = balanceFactor(root);

            if (balance > 1)
                if (balanceFactor(root->left) >= 0) // cazul LL
                    root = rotateRight(root);
                else {
                    root->left = rotateLeft(root->left); // cazul LR
                    root = rotateRight(root);
                }

            if (balance < -1)
                if (balanceFactor(root->right) <= 0) // cazul RR
                    root = rotateLeft(root);
                else {
                    root->right = rotateRight(root->right); // cazul RL
                    root = rotateLeft(root);
                }
        }
    }

    void in_order_helper(node* root) {
        if (root == nullptr)
            return;

        in_order_helper(root->left);
        fout << root->key << " ";
        in_order_helper(root->right);
    }

    void in_order_helper_cerinta6(node* root, int low_bound, int high_bound) {
        if (root == nullptr)
            return;

        in_order_helper_cerinta6(root->left, low_bound, high_bound);
        if (root->key >= low_bound && root->key <= high_bound)
            fout << root->key << " ";
        in_order_helper_cerinta6(root->right, low_bound, high_bound);
    }

    int lower_bound_helper(int val) {
        node* temp = root;
        int low_bound = -1;

        while (temp) {
            if (temp->key >= val) {
                low_bound = temp->key;
                temp = temp->left;
            }else
                temp = temp->right;
        }

        return low_bound;
    }

    int upper_bound_helper(int val) {
        node* temp = root;
        int upper_bound = -1;

        while (temp) {
            if (temp->key <= val) {
                upper_bound = temp->key;
                temp = temp->right;
            }else
                temp = temp->left;
        }

        return upper_bound;
    }

public:

    avl() {
        root = nullptr;
    }

    void add(int x) {
        add_helper(root, x);
    }

    bool search(int x) {
        return search_helper(root, x);
    }

    void del(int x) {
        delete_helper(root, x);
    }

    void in_order() {
        in_order_helper(root);
        fout << '\n';
    }

    void in_order_cerinta6(int lower, int upper) {
        in_order_helper_cerinta6(root, lower, upper);
        fout << '\n';
    }

    int lower_bound(int x) {
        return lower_bound_helper(x);
    }

    int upper_bound(int x) {
        return upper_bound_helper(x);
    }

};

int main() {
    avl avl;
    int n;

    fin >> n;

    for (int i = 0; i < n; i++) {
        int option;

        fin >> option;

        switch (option) {
            case 1:
                int x;
                fin >> x;

                avl.add(x);
                break;
            case 2:
                int y;
                fin >> y;

                avl.del(y);
                break;
            case 3:
                int z;
                fin >> z;

                fout << avl.search(z) << '\n';
                break;
            case 4:
                int a;
                fin >> a;

                fout << avl.upper_bound(a) << '\n';
                break;
            case 5:
                int b;
                fin >> b;

                fout << avl.lower_bound(b) << '\n';
                break;
            case 6:
                int lower, upper;

                fin >> lower >> upper;

                avl.in_order_cerinta6(lower, upper);
                break;
        }
    }
}


