#include <stdio.h>
#include <assert.h>

#include <vector>

struct Splay {
  struct Node {
    int c[2] = {0, 0}, par = 0;
    int key = -1;
  };

  std::vector<Node> t;
  Splay( int n ): t(n + 1) {}

  // void push( int u ) {}
  // void pull( int u ) {}

  int side( int u ) {
    if( t[t[u].par].c[0] == u ) return 0;
    if( t[t[u].par].c[1] == u ) return 1;
    return -1;
  }

  void link( int p, int u, int side ) {
    if( p ) t[p].c[side] = u;
    if( u ) t[u].par = p;
  }

  void zig( int x ) {
    int y = t[x].par, s = side( x );
    assert( s == 0 || s == 1 );

    int mij = t[x].c[s ^ 1];
    int up = t[y].par, sup = side( y );

    link( y, mij, s );
    link( x, y, s ^ 1 );
    link( up, x, sup );
  }

  void splay( int x ) {
    assert( x ); // should never splay null
    
    while( side( x ) >= 0 ) {
      int y = t[x].par, sx = side( x );
      if( side( y ) < 0 ){
        zig( x );
        continue;
      }

      int sy = side( y );
      if( sx == sy ){
        zig( y );
        zig( x );
      }else{
        zig( x );
        zig( x );
      }
    }
  }
};

struct Set : Splay {
  int root = 0, node_idx = 1;
  Set( int q ): Splay(q) {}

  int merge( int left, int right ) {
    if( !left ) return right;
    if( !right ) return left;

    // going right
    while( t[left].c[1] )
      left = t[left].c[1];

    splay( left );
    link( left, right, 1 );
    return left;
  }

  template<class CB> std::pair<int, int> go_down( int root, CB&& is_root_left ) {
    if( !root )
      return { 0, 0 };

    if( is_root_left( root ) ) {
      auto [el, down] = go_down( t[root].c[1], is_root_left );
      if( !down ) down = root;
      if( !el ) el = root;
      return { el, down };
    }else{
      auto [el, down] = go_down( t[root].c[0], is_root_left );
      if( !down ) down = root;
      return { el, down };
    }
  }

  // <, >=
  template<class CB> std::pair<int, int> split( int root, CB&& is_root_left ) {
    if( !root ) return { 0, 0 };
    
    auto [el, down] = go_down( root, is_root_left );
    splay( down );

    if( !el ) return { 0, down };
    splay( el );

    // cutoff right
    int right = t[el].c[1];
    link( el, 0, 1 );
    link( 0, right, 0 );

    return { el, right };
  }

  std::pair<int, int> split_l_ge( int root, int val ) {
    return split( root, [&]( int u ) -> bool {
      return t[u].key < val;
    } );
  }

  std::pair<int, int> split_le_g( int root, int val ) {
    return split( root, [&]( int u ) -> bool {
      return t[u].key <= val;
    } );
  }

  int leftmost( int u ) {
    while( t[u].c[0] )
      u = t[u].c[0];
    splay( u );
    return u;
  }

  int rightmost( int u ) {
    while( t[u].c[1] )
      u = t[u].c[1];
    splay( u );
    return u;
  }
  
  void insert( int x ) {
    t[node_idx].key = x; // previously unused
    auto [lx, rx] = split_l_ge( root, x );

    // nu mai e ca la treap, nu trebuie reparate prioritatile
    link( node_idx, lx, 0 );
    link( node_idx, rx, 1 );
    root = node_idx++;
  }

  void erase( int x ) {
    auto [left, right] = split_l_ge( root, x );
    if( !right ){
      root = left;
      return;
    }

    // printf( "have right!\n" );

    int u = leftmost( right );
    if( t[u].key != x ){
      root = merge( left, u );
      return;
    }

    // printf( "removing %d\n", x );

    right = t[u].c[1];
    link( u, 0, 1 );
    link( 0, right, 0 );
    root = merge( left, right );
  }

  bool find( int x ) {
    auto [left, right] = split_l_ge( root, x );
    if( !right ){
      root = left;
      return false;
    }

    int u = leftmost( right );
    bool ret = (t[u].key == x);
    
    root = merge( left, u );
    return ret;
  }

  int last_le( int x ) {
    auto [left, right] = split_le_g( root, x );
    left = rightmost( left );
    int ret = t[left].key;

    root = merge( left, right );
    return ret;
  }

  int first_ge( int x ) {
    auto [left, right] = split_l_ge( root, x );
    right = leftmost( right );
    int ret = t[right].key;

    root = merge( left, right );
    return ret;
  }

  void dump( int root, FILE *fout ) {
    if( !root ) return;

    dump( t[root].c[0], fout );
    fprintf( fout, "%d ", t[root].key );
    dump( t[root].c[1], fout );
  }

  void print_range( int x, int y, FILE *fout ) {
    auto [lx, rx] = split_l_ge( root, x );
    auto [mid, ry] = split_le_g( rx, y );

    dump( mid, fout );
    fputc( '\n', fout );

    rx = merge( mid, ry );
    root = merge( lx, rx );
  }
};

int main() {
  FILE *fin = fopen( "abce.in", "r" );
  FILE *fout = fopen( "abce.out", "w" );

  int q;
  fscanf( fin, "%d", &q );
  
  Set bomba(q);
  for( ; q--; ){
    int task;
    fscanf( fin, "%d", &task );

    int x, y;
    switch( task ){
    case 1: fscanf( fin, "%d", &x ); bomba.insert( x ); break;
    case 2: fscanf( fin, "%d", &x ); bomba.erase( x ); break;
    case 3: fscanf( fin, "%d", &x ); fprintf( fout, "%d\n", int(bomba.find( x )) ); break;
    case 4: fscanf( fin, "%d", &x ); fprintf( fout, "%d\n", bomba.last_le( x ) ); break;
    case 5: fscanf( fin, "%d", &x ); fprintf( fout, "%d\n", bomba.first_ge( x ) ); break;
    case 6: fscanf( fin, "%d%d", &x, &y ); bomba.print_range( x, y, fout ); break;
    }
  }

  fclose( fin );
  fclose( fout );
  return 0;
}
