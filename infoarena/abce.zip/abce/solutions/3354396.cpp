#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Node {
    long long value;
    int priority;
    Node* left;
    Node* right;

    Node(long long val) : value(val), priority(rand()), left(nullptr), right(nullptr) {}
};

class Treap {
private:
    Node* root;

    void rotateRight(Node*& node) {
        Node* temp = node->left;
        node->left = temp->right;
        temp->right = node;
        node = temp;
    }

    void rotateLeft(Node*& node) {
        Node* temp = node->right;
        node->right = temp->left;
        temp->left = node;
        node = temp;
    }

    Node* insertHelper(Node* node, long long val) {
        if (!node) return new Node(val);

        if (val < node->value) {
            node->left = insertHelper(node->left, val);
        } else if (val > node->value) {
            node->right = insertHelper(node->right, val);
        } else {
            return node;
        }

        if (node->left && node->left->priority > node->priority) {
            rotateRight(node);
        } else if (node->right && node->right->priority > node->priority) {
            rotateLeft(node);
        }

        return node;
    }

    Node* deleteHelper(Node* node, long long val) {
        if (!node) return nullptr;

        if (val < node->value) {
            node->left = deleteHelper(node->left, val);
        } else if (val > node->value) {
            node->right = deleteHelper(node->right, val);
        } else {
            if (!node->left && !node->right) {
                delete node;
                return nullptr;
            } else if (!node->left) {
                Node* temp = node->right;
                delete node;
                return temp;
            } else if (!node->right) {
                Node* temp = node->left;
                delete node;
                return temp;
            } else {
                if (node->left->priority > node->right->priority) {
                    rotateRight(node);
                    node->right = deleteHelper(node->right, val);
                } else {
                    rotateLeft(node);
                    node->left = deleteHelper(node->left, val);
                }
            }
        }

        return node;
    }

    bool searchHelper(Node* node, long long val) {
        if (!node) return false;

        if (val < node->value) return searchHelper(node->left, val);
        else if (val > node->value) return searchHelper(node->right, val);
        else return true;
    }

    long long floorHelper(Node* node, long long val, bool& found) {
        if (!node) return 0;

        if (node->value == val) {
            found = true;
            return val;
        } else if (val < node->value) {
            return floorHelper(node->left, val, found);
        } else {
            long long result = floorHelper(node->right, val, found);
            if (found) return result;
            found = true;
            return node->value;
        }
    }

    long long ceilingHelper(Node* node, long long val, bool& found) {
        if (!node) return 0;

        if (node->value == val) {
            found = true;
            return val;
        } else if (val > node->value) {
            return ceilingHelper(node->right, val, found);
        } else {
            long long result = ceilingHelper(node->left, val, found);
            if (found) return result;
            found = true;
            return node->value;
        }
    }

    void rangeHelper(Node* node, long long minVal, long long maxVal, vector<long long>& result) {
        if (!node) return;

        if (node->value > minVal) {
            rangeHelper(node->left, minVal, maxVal, result);
        }

        if (node->value >= minVal && node->value <= maxVal) {
            result.push_back(node->value);
        }

        if (node->value < maxVal) {
            rangeHelper(node->right, minVal, maxVal, result);
        }
    }

    void deleteTree(Node* node) {
        if (!node) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

public:
    Treap() : root(nullptr) {}

    ~Treap() {
        deleteTree(root);
    }

    void insert(long long val) {
        root = insertHelper(root, val);
    }

    void remove(long long val) {
        root = deleteHelper(root, val);
    }

    bool search(long long val) {
        return searchHelper(root, val);
    }

    long long floor(long long val) {
        bool found = false;
        return floorHelper(root, val, found);
    }

    long long ceiling(long long val) {
        bool found = false;
        return ceilingHelper(root, val, found);
    }

    vector<long long> range(long long minVal, long long maxVal) {
        vector<long long> result;
        rangeHelper(root, minVal, maxVal, result);
        return result;
    }
};

int main() {
    srand(time(NULL));
    Treap t;

    t.insert(3);
    t.insert(7);
    t.insert(1);
    t.insert(10);
    t.insert(5);
    t.insert(8);

    cout << t.search(7) << "\n";
    cout << t.search(4) << "\n";

    t.remove(7);
    cout << t.search(7) << "\n";

    cout << t.floor(6) << "\n";
    cout << t.floor(10) << "\n";

    cout << t.ceiling(4) << "\n";
    cout << t.ceiling(1) << "\n";

    vector<long long> r = t.range(3, 10);
    for (int i = 0; i < r.size(); i++) {
        if (i > 0) cout << " ";
        cout << r[i];
    }
    cout << "\n";

    t.insert(4);
    t.insert(6);
    r = t.range(4, 8);
    for (int i = 0; i < r.size(); i++) {
        if (i > 0) cout << " ";
        cout << r[i];
    }
    cout << "\n";

    return 0;
}
