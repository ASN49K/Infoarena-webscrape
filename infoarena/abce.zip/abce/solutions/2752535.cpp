#include <iostream>
#include <fstream>

using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");

struct AVL //Declar o structura in care o sa memorez valoarea nodului, inaltimea, subarborele drept si stang
{
    int val;
    int inaltime;
    AVL *nodStanga;
    AVL *nodDreapta;
};

int inaltime(AVL* nod) //Functie care returneaza inaltimea
{
    if(nod == NULL)
        return 0;
    else
        return nod->inaltime;
}

int balanta(AVL* nod) //Functie care returneaza valoarea dupa care trebuie sa echilibram AVL-ul
{
    if(nod == NULL)
        return 0;
    else
        return inaltime(nod->nodStanga) - inaltime(nod->nodDreapta);
}

AVL* rotireStanga(AVL* nod) //Rotirea stanga a arborelui
{
    AVL *y = nod->nodDreapta;
    AVL *T2 = y->nodStanga;

    y->nodStanga = nod;
    nod->nodDreapta = T2;

    nod->inaltime = max(inaltime(nod->nodStanga),
                    inaltime(nod->nodDreapta)) + 1;
    y->inaltime = max(inaltime(y->nodStanga),
                    inaltime(y->nodDreapta)) + 1;

    return y;
}

AVL* rotireDreapta(AVL* nod) //Rotirea dreapta a arborelui
{
    AVL *x = nod->nodStanga;
    AVL *T2 = x->nodDreapta;

    x->nodDreapta = nod;
    nod->nodStanga = T2;

    nod->inaltime = max(inaltime(nod->nodStanga),
                    inaltime(nod->nodDreapta)) + 1;
    x->inaltime = max(inaltime(x->nodStanga),
                    inaltime(x->nodDreapta)) + 1;

    return x;
}

AVL* inserare(AVL* nod, int x) //Inserare
{
    if(nod == NULL) //Daca nodul in care ne aflam este gol, cream unul nou
    {
        AVL* nod = new AVL();
        nod->val = x;
        nod->inaltime = 1;
        nod->nodStanga = NULL;
        nod->nodDreapta = NULL;
        return nod;
    }
    else
    {
        //Cautam unde ar trebui sa inseram nodul
        if(x < nod->val) //Daca e mai mic decat nodul in care ne aflam, trebuie sa cautam in subarborele stang
            nod->nodStanga = inserare(nod->nodStanga, x);
        else if(x > nod->val) //Daca e mai mare, cautam in subarborele drept
            nod->nodDreapta = inserare(nod->nodDreapta, x);
        else //Nu putem avea 2 valori egale
            return nod;

        nod->inaltime = max(inaltime(nod->nodStanga), inaltime(nod->nodDreapta)) + 1; //actualizam inaltimea dupa inserare

        //Calculam factorul de echilibrare si reechilibram arborele dupa cele 4 cazuri
        int bal = balanta(nod);

        if(bal > 1) // Cazurile Left
        {
            if(x < nod->nodStanga->val) // Cazul Left-Left
                return rotireDreapta(nod);
            else if(x > nod->nodStanga->val)
            {
                nod->nodStanga = rotireStanga(nod->nodStanga);
                return rotireDreapta(nod);
            }
        }
        else if(bal < -1) // Cazurile Right
            if(x > nod->nodDreapta->val)
                return rotireStanga(nod);
            else if(x < nod->nodDreapta->val)
            {
                nod->nodDreapta = rotireDreapta(nod->nodDreapta);
                return rotireStanga(nod);
            }
        return nod;
    }
}

AVL* valMin(AVL* nod) //Functie care sa returneze valoarea minima din arbore
{
    AVL* aux = nod;
    while(aux->nodStanga != NULL)
        aux = aux->nodStanga;
    return aux;
}

AVL* stergere(AVL* nod, int x) //Stergere
{
    if(nod == NULL)
        return nod;
    if(x < nod->val) //Daca valoarea care trebuie stearsa este mai mica decat nodul curent, cautam in subarborele stang
        nod->nodStanga = stergere(nod->nodStanga, x);
    else if(x > nod->val) //Daca este mai mare, cautam in subarborele drept
        nod->nodDreapta = stergere(nod->nodDreapta, x);
    else //Daca e egal, inseamna ca am gasit valoarea si trebuie sa o stergem
    {
        if(nod->nodStanga == NULL) //Daca nu are subarbore stang
        {
            AVL* aux = nod->nodDreapta;
            if(aux == NULL) //Daca nu are nici subarbore drept atunci stergem nodul
            {
                aux = nod;
                nod = NULL;
            }
            else
                (*nod) = (*aux); //Daca exista subarbore drept, atunci il pun in locul nodului actual
        }
        else if(nod->nodDreapta == NULL) //Daca nu subarbore drept
        {
            AVL* aux = nod->nodStanga;
            if(aux == NULL) //Si nu are nici subarbore stang, atunci il sterg
            {
                aux = nod;
                nod = NULL;
            }
            else
                (*nod) = (*aux); //Daca exista subarbore stang, il pun in locul nodului actual
        }
        else //Daca exista si subarbore drept si subarbore stang,
        {
            AVL* suc = valMin(nod->nodDreapta); //Calculez valoarea succesorului sau
            nod->val = suc->val; //Schimb valoarea nodului actual cu cea a succesorului
            nod->nodDreapta = stergere(nod->nodDreapta, nod->val); //Si repet procedeul de stergere pentru subarborele drept
        }
    }

    if(nod == NULL) //Daca arborele avea un singur nod inainte de stergere
        return nod;

    nod->inaltime = 1 + max(inaltime(nod->nodStanga), inaltime(nod->nodDreapta)); //Actualizam inaltimea

    int bal = balanta(nod); //Calculeaza factorul de echilibrare si reechilibram arborele dupa cele 4 cazuri

    if(bal > 1) //Cazurile Left
    {
        if(balanta(nod->nodStanga) >= 0) //Cazul Left-Left
            return rotireDreapta(nod);
        else if(balanta(nod->nodStanga) < 0) //Cazul Left-Right
        {
            nod->nodStanga = rotireStanga(nod->nodStanga);
            return rotireDreapta(nod);
        }
    }
    else if(bal < -1) //Cazurile Right
    {
        if(balanta(nod->nodDreapta) <= 0) //Cazul Right-Right
            return rotireStanga(nod);
        else if(balanta(nod->nodDreapta) > 0) //Cazul Right-Left
        {
            nod->nodDreapta = rotireDreapta(nod->nodDreapta);
            return rotireStanga(nod);
        }
    }
    return nod;
}

AVL* cautare(AVL* nod, int x) //Functie de cautare a unui nod in AVL
{
    if(nod == NULL || nod->val == x)
        return nod;
    if(x < nod->val)
        return cautare(nod->nodStanga, x);
    else
        return cautare(nod->nodDreapta, x);
}

int pred(AVL* nod, int x) //Functie care returneaza valoarea celui mai mare numar Y, mai mic decat un X dat
{
    if(nod == NULL)
        return -1;

    if(nod->val == x) //Daca nodul curent are valoarea X, il returnam, deoarece cerea sa fie mai mic sau egal
        return x;
    else if(nod->val < x) //Daca valoarea nodului curent este mai mica decat X
    {
        int aux = pred(nod->nodDreapta, x); //Cautam in subarborele drept
        if(aux == -1) //Si returnam valoarea ceruta, daca este egala sau nu cu X
            return nod->val;
        else
            return aux;
    }
    else if(nod->val > x) //Daca valoarea nodului curent este mai mare decat X, cautam in subarborele stang
        return pred(nod->nodStanga, x);
}

int succ(AVL* nod, int x) //Functie care returneaza valoarea celui mai mic numar Y, mai mare decat un X dat
{
    if (nod->nodStanga == NULL && nod->nodDreapta == NULL && nod->val < x) //Daca nodul curent nu are subarbori si valoarea lui e mai mica decat X
        return -1;

    if((nod->val >= x && nod->nodStanga == NULL) || (nod->val >= x && nod->nodStanga->val < x))
        return nod->val; //Daca valoarea nodului curent este mai mare decat X si nu avem subarbore stang
                        //Sau este mai mare decat X si valoarea fiului sau din subarborele stang este mai mica decat X, am gasit nodul cautat

    if(nod->val <= x) //Daca valoarea nodului e mai mica decat X, cautam in subarborele drept
        return succ(nod->nodDreapta, x);
    else //Daca nu, cautam in subarborele stang
        return succ(nod->nodStanga, x);
}

void inorder(AVL* nod, int v[], int &k) //Afisare inorder
{
    if(nod != NULL)
    {
        inorder(nod->nodStanga,v,k);
        //cout << nod->val << " ";
        v[k++] = nod->val;
        inorder(nod->nodDreapta,v,k);
    }
}

void afisare(int k, int v[], int s, int d)
{
    for(int i = 0; i<k && v[i]<=d; i++)
        if(v[i] >= s)
            out << v[i] << " ";
    out << "\n";
}


int main()
{
    int numar_operatii;
    int cod;
    int x,y;

    AVL* radacina = NULL;

    in >> numar_operatii;
    for(int i=1; i<=numar_operatii; i++)
    {
        in >> cod;
        if(cod == 1) //Inserare element X
        {
            in >> x;
            radacina = inserare(radacina,x);
        }
        else if(cod == 2) //Stergere element X
        {
            in >> x;
            radacina = stergere(radacina, x);
        }
        else if(cod == 3) //Cautare element X
        {
            in >> x;
            if(cautare(radacina,x) != NULL)
                out << 1 << "\n";
            else
                out << 0 << "\n";
        }
        else if(cod == 4) //Cel mai mare nr Y, mai mic sau egal cu X
        {
            in >> x;
            out << pred(radacina, x) << "\n";
        }
        else if(cod == 5) //Cel mai mic nr Y, mai mare sau egal cu X
        {
            in >> x;
            out << succ(radacina, x) << "\n";
        }
        else if(cod == 6) //Afisarea elementelor Z, unde X <= Z <= Y
        {
            in >> x >> y;
            int s = succ(radacina,x);
            int d = pred(radacina,y);
            int v[1001];
            int k = 0;
            inorder(radacina,v,k);
            afisare(k,v,s,d);
        }
    }
    return 0;
}
