#include <iostream>
#include <fstream>
#include <set>
#include <climits>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct node {
    int key;
    node* left, * right;
};

node* newNode(int key) {
    node* t = new node;
    t->key = key;
    t->left = t->right = nullptr;
    return t;
}

node* rightRotate(node* x) {
    node* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

node* splay(node* root, int key) {
    if (root == nullptr || root->key == key) {
        return root;
    }

    if (root->key > key) {
        if (root->left == nullptr) {
            return root;
        }
        if (root->left->key > key) {
            root->left->left = splay(root->left->left, key);
            root = rightRotate(root);
        }
        else if (root->left->key < key) {
            root->left->right = splay(root->left->right, key);
            if (root->left->right != nullptr) {
                root->left = leftRotate(root->left);
            }
        }
        return (root->left == nullptr) ? root : rightRotate(root);
    }
    else {
        if (root->right == nullptr) {
            return root;
        }
        if (root->right->key > key) {
            root->right->left = splay(root->right->left, key);
            if (root->right->left != nullptr) {
                root->right = rightRotate(root->right);
            }
        }
        else if (root->right->key < key) {
            root->right->right = splay(root->right->right, key);
            root = leftRotate(root);
        }
        return (root->right == nullptr) ? root : leftRotate(root);
    }
    return root;
}

node* insert(node* root, int key){
    if (!root) {
        root = newNode(key);
        return root;
    }

    root = splay(root,key);

    if (root->key==key) return root;

    node* temp = root;
    node* y = NULL;
    while (temp != NULL) {
        y = temp;
        if (key < temp->key) temp = temp->left;
        else temp = temp->right;
    }
    if (y->key > key) y->left = newNode(key);
    else y->right = newNode(key);

    return root;
}

bool search(node*& root, int key) {
    root = splay(root, key);
    if (root == nullptr || root->key != key) {
        return false;
    }
    else {
        return true;
    }
}

node* deleteNode(node* root, int key) {
    if (root == nullptr) {
        return root;
    }
    root = splay(root, key);
    if (root->key != key) {
        return root;
    }
    node* t;
    if (root->left == nullptr) {
        t = root->right;
        delete root;
        return t;
    }
    else {
        t = root->left;
        while (t->right != nullptr) {
            t = t->right;
        }
        t->right = root->right;
        node* newRoot = t;
        delete root;
        return newRoot;
    }
}
int* cautaMareMic(node* root, int key) {
    if (root == nullptr) return nullptr;

    int* mareMic;
    if (key < root->key) {
        mareMic = cautaMareMic(root->left, key);
        if (root->key <= key && mareMic == nullptr) return &(root->key);
        if (root->key <= key && root->key > *mareMic) return &(root->key);
        return mareMic;
    }

    if (key > root->key) {
        mareMic = cautaMareMic(root->right, key);
        if (root->key <= key && mareMic == nullptr) return &(root->key);
        if (root->key <= key && root->key > *mareMic) return &(root->key);
        return mareMic;
    }
    return &(root->key);
}

int* cautaMicMare(node* root, int key) {
    if (root == nullptr) return nullptr;

    int* micMare;
    if (key < root->key) {
        micMare = cautaMicMare(root->left, key);
        if (root->key >= key && micMare == nullptr) return &(root->key);
        if (root->key >= key && root->key < *micMare) return &(root->key);
        return micMare;
    }

    if (key > root->key) {
        micMare = cautaMicMare(root->right, key);
        if (root->key >= key && micMare == nullptr) return &(root->key);
        if (root->key >= key && root->key < *micMare) return &(root->key);
        return micMare;
    }
    return &(root->key);
}


set<int> setul;

void inOrderXY(node* root, int x, int y) {
    if (root == nullptr) {
        return;
    }
    if (x < root->key) {
        inOrderXY(root->left, x, y);
    }
    if (root->key >= x && root->key <= y) {
        setul.insert(root->key);
    }
    if (y > root->key) {
        inOrderXY(root->right, x, y);
    }
}

void callInOrderXY(node* root, int x, int y) {
    setul.clear();
    inOrderXY(root, x, y);
    for (auto it = setul.begin(); it != setul.end(); it++) {
        fout << *it << " ";
    }
    fout << "\n";
}



int main() {
    node* root = nullptr;
    int n, comanda, x, y;
    fin >> n;
    for (int i = 1; i <= n; i++) {
        fin >> comanda;
        switch (comanda) {
            case 1: {
                fin >> x;
                if (!search(root, x)) {
                    root = insert(root, x);
                }
                break;
            }
            case 2: {
                fin >> x;
                root = deleteNode(root, x);
                break;
            }
            case 3: {
                fin >> x;
                fout << search(root, x) << endl;
                break;
            }
            case 4: {
                fin >> x;
                int* nr = cautaMareMic(root, x);
                fout << *nr << "\n";
                break;
            }
            case 5: {
                fin >> x;
                int* nr = cautaMicMare(root, x);
                fout << *nr << "\n";
                break;
            }
            case 6: {
                fin >> x >> y;
                callInOrderXY(root, x, y);
                break;
            }
            default: {
                break;
            }
        }
    }
    fin.close();
    fout.close();
    return 0;
}
