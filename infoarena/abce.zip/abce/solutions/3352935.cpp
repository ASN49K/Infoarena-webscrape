#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Node { // Structura de nod pe care lucrez
    int value;
    int height;
    Node* left;
    Node* right;
    
    Node(int val) : value(val), height(1), left(nullptr), right(nullptr) {} // Atr default
};

class AVLTree {
private:
    Node* root;
    
    int height(Node* node) {
        return node ? node->height : 0;
    }
    
    int getBalance(Node* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }
    
    void updateHeight(Node* node) {
        if (node) {
            node->height = 1 + max(height(node->left), height(node->right));
        }
    }
    
    // Rotatie dreapta
    Node* rotateRight(Node* y) {
        Node* x = y->left;
        Node* T2 = x->right;
        
        x->right = y;
        y->left = T2;
        
        updateHeight(y);
        updateHeight(x);
        
        return x;
    }
    
    // Rotatie stanga
    Node* rotateLeft(Node* x) {
        Node* y = x->right;
        Node* T2 = y->left;
        
        y->left = x;
        x->right = T2;
        
        updateHeight(x);
        updateHeight(y);
        
        return y;
    }
    
    Node* insert(Node* node, int value) {
        // BST insert standard
        if (!node) return new Node(value);
        
        if (value < node->value)
            node->left = insert(node->left, value);
        else if (value > node->value)
            node->right = insert(node->right, value);
        else
            return node; // Duplicat, nu inseram
        
        // Update height
        updateHeight(node);
        
        // Balancing
        int balance = getBalance(node);
        
        // Left-Left
        if (balance > 1 && value < node->left->value)
            return rotateRight(node);
        
        // Right-Right
        if (balance < -1 && value > node->right->value)
            return rotateLeft(node);
        
        // Left-Right
        if (balance > 1 && value > node->left->value) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }
        
        // Right-Left
        if (balance < -1 && value < node->right->value) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }
        
        return node;
    }

    // Ma duc la stanga pana nu mai pot
    Node* minValueNode(Node* node) {
        Node* current = node;
        while (current && current->left)
            current = current->left;
        return current;
    }

    Node* remove(Node* node, int value) {
        if (!node) return node;
        
        // BST delete standard
        if (value < node->value) {
            node->left = remove(node->left, value);
        } else if (value > node->value) {
            node->right = remove(node->right, value);
        } else {
            // Nodul gasit
            if (!node->left || !node->right) {
                Node* temp = node->left ? node->left : node->right;
                
                if (!temp) {
                    temp = node;
                    node = nullptr;
                } else {
                    *node = *temp;
                }
                delete temp;
            } else {

                Node* temp = minValueNode(node->right);
                node->value = temp->value;
                node->right = remove(node->right, temp->value);
            }
        }
        
        if (!node) return node;
        
        // Update inaltime
        updateHeight(node);
        
        // Partea de balansare
        int balance = getBalance(node);
        
        // Left-Left
        if (balance > 1 && getBalance(node->left) >= 0)
            return rotateRight(node);
        
        // Left-Right
        if (balance > 1 && getBalance(node->left) < 0) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }
        
        // Right-Right
        if (balance < -1 && getBalance(node->right) <= 0)
            return rotateLeft(node);
        
        // Right-Left
        if (balance < -1 && getBalance(node->right) > 0) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }
        
        return node;
    }
    
    bool search(Node* node, int value) {
        if (!node) return false;
        if (value == node->value) return true;
        if (value < node->value) return search(node->left, value);
        return search(node->right, value);
    }
    
    int floor(Node* node, int value) {
        if (!node) return -2e9;
        
        if (node->value == value) return value;
        
        if (value < node->value) {
            return floor(node->left, value);
        }
        
        // value > node->value
        int rightFloor = floor(node->right, value);
        return (rightFloor != -2e9) ? rightFloor : node->value;
    }
    
    int ceiling(Node* node, int value) {
        if (!node) return 2e9;  // dne
        
        if (node->value == value) return value;
        
        if (value > node->value) {
            return ceiling(node->right, value);
        }
        
        // value < node->value
        int leftCeil = ceiling(node->left, value);
        return (leftCeil != 2e9) ? leftCeil : node->value;
    }

    // Returnez aici elementele din intervalul [x,y]
    void rangeQuery(Node* node, int x, int y, vector<int>& result) {
        if (!node) return;
        
        //Parcurg inordine
        if (x < node->value)
            rangeQuery(node->left, x, y, result);
        
        if (x <= node->value && node->value <= y)
            result.push_back(node->value);
        
        if (node->value < y)
            rangeQuery(node->right, x, y, result);
    }
    
public:
    AVLTree() : root(nullptr) {}
    
    void insert(int value) {
        root = insert(root, value);
    }
    
    void remove(int value) {
        root = remove(root, value);
    }
    
    bool contains(int value) {
        return search(root, value);
    }
    
    int floor(int value) {
        return floor(root, value);
    }
    
    int ceiling(int value) {
        return ceiling(root, value);
    }
    
    vector<int> rangeQuery(int x, int y) {
        vector<int> result;
        rangeQuery(root, x, y, result);
        return result;
    }
};

int main() {
    ifstream fin("abce.in");
    ofstream fout("abce.out");
    
    int q;
    fin >> q;
    
    AVLTree tree;
    
    for (int i = 0; i < q; i++) {
        int op;
        fin >> op;
        
        if (op == 1) {
            int x;
            fin >> x;
            tree.insert(x);
        } else if (op == 2) {
            int x;
            fin >> x;
            tree.remove(x);
        } else if (op == 3) {
            int x;
            fin >> x;
            fout << (tree.contains(x) ? 1 : 0) << '\n';
        } else if (op == 4) {
            int x;
            fin >> x;
            fout << tree.floor(x) << '\n';
        } else if (op == 5) {
            int x;
            fin >> x;
            fout << tree.ceiling(x) << '\n';
        } else if (op == 6) {
            int x, y;
            fin >> x >> y;
            vector<int> result = tree.rangeQuery(x, y);
            for (int j = 0; j < result.size(); j++) {
                if (j > 0) fout << ' ';
                fout << result[j];
            }
            fout << '\n';
        }
    }
    
    fin.close();
    fout.close();
    
    return 0;
}