#include<iostream>
#include <random>
#include <climits>
#include <fstream>

std::ifstream in("abce.in");
std::ofstream out("abce.out");

class Treap{
  struct Node{
    long int key;
    long long priority;
    Node *left, *right;

    Node(long int k, long long p) : key(k), priority(p), left(0), right(0) {}
  };

  Node* root;

  long long generatePriority(){
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<long long> dist(LLONG_MIN, LLONG_MAX);
    return dist(gen);
  }

  Node* innerSearch(Node* node, long int key){
    if(node == NULL)
      return NULL;

    if(node->key == key)
      return node;

    if(node->key > key)//go left
      return innerSearch(node->left, key);

    else//go right
      return innerSearch(node->right, key);
  }

  Node* rotateLeft(Node* root){
    Node* new_root = root->right;
    Node* beta = new_root->left;
    new_root->left = root;
    root->right = beta;
    return new_root;
  }

  Node* rotateRight(Node* root){
    Node* new_root = root->left;
    Node* beta = new_root->right;
    new_root->right = root;
    root->left = beta;
    return new_root;
  }

  Node* innerInsert(Node* root, long int key){
    if(root == NULL)
      root = new Node(key, generatePriority());

    else if(root->key > key){
      root->left = innerInsert(root->left, key);

      if(root->left->priority > root->priority)
        root = rotateRight(root);
    
    }else{
      root->right = innerInsert(root->right, key);
    
      if(root->right->priority > root->priority)
        root = rotateLeft(root);
    
    }

    return root;
  }

  Node* innerDelete(Node* root, long int key){
    if(root == NULL)
      return 0;
    
    if(root->key > key)
      root->left = innerDelete(root->left, key);
    else if(root->key < key)
      root->right = innerDelete(root->right, key);
    else if(root->left == NULL){
      Node* temp = root->right;
      delete(root);
      root = temp;
    }else if(root->right == NULL){
      Node* temp = root->left;
      delete(root);
      root = temp;
    }else if(root->left->priority < root->right->priority){
      root = rotateLeft(root);
      root->left = innerDelete(root->left, key);
    }else{
      root = rotateRight(root);
      root->right = innerDelete(root->right, key);
    }

    return root;
  }

  long int innerPredecessor(Node* node, long int key, long int prevPred){
    if(!node)
      return prevPred;

    if(node->key == key)
      return key;

    else if(node->key > key)
      return innerPredecessor(node->left, key, prevPred);

    else
      return innerPredecessor(node->right, key, node->key);
  }

  long int innerSuccesor(Node* node, long int key, long int prevSucc){
    if(!node)
      return prevSucc;

    if(node->key == key)
      return key;

    else if(node->key > key)
      return innerSuccesor(node->left, key, node->key);

    else
      return innerSuccesor(node->right, key, prevSucc);
  }

  void innerPrintRange(Node* node, long int l, long int r){
    if(!node)
      return;

    if(node->key >= l && node->key <= r){
      innerPrintRange(node->left, l, r);
      out<<node->key<<" ";
      innerPrintRange(node->right, l, r);

    }else if(node->key < l)
      innerPrintRange(node->right, l, r);
      
    else
      innerPrintRange(node->left, l, r);
  }

  public:

  Treap() : root(0) {}

  void insert(long int key){
    root = innerInsert(root, key);
  }

  void remove(long int key){
    root = innerDelete(root, key);
  }

  int search(long int key){
    Node* node = innerSearch(root, key);
    if(node)
      return 1;
    return 0;
  }

  long int predecessor(long int key){
    return innerPredecessor(root, key, 0);
  }

  long int successor(long int key){
    return innerSuccesor(root, key, 0);
  }

  void printRange(long int l, long int r){
    innerPrintRange(root, l, r);
  }

};

int main()
{


	int _, op, x, y;

	in>>_;

	Treap t;

	do
	{
		in>>op>>x;
		switch(op)
		{
		case 1:
			t.insert(x);
			break;
		case 2:
      t.remove(x);
			break;
		case 3:
      out<<t.search(x)<<std::endl;
			break;
		case 4:
			out<<t.predecessor(x)<<std::endl;
			break;
		case 5:
			out<<t.successor(x)<<std::endl;
			break;
		case 6:
			in>>y;
			t.printRange(x, y);
      out<<std::endl;
			break;
		}
	}while(_-=1); // Altfel se vede ciudat si se copiaza gresit.

	return 0;
}