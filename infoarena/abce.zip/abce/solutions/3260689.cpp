#include <iostream>
#include <vector>
#include <random>
#include <memory>
#include <fstream>
using namespace std;

ofstream fout("abce.out");

class Node {
public:
    int key;
    std::vector<Node*> forward;

    Node(int key, int level) : key(key), forward(level + 1, nullptr) {}
};

class SkipList {
private:
    int MAXLVL;
    float P;
    int curLevel;
    Node* header;
    std::default_random_engine generator;
    std::uniform_real_distribution<float> distribution;

    int randomLevel() {
        int lvl = 0;
        while (distribution(generator) < P && lvl < MAXLVL) {
            lvl++;
        }
        return lvl;
    }

    void freeList() {
        Node* current = header;
        while (current) {
            Node* next = current->forward[0];
            delete current;
            current = next;
        }
    }

public:
    SkipList(int maxLevel, float probability)
        : MAXLVL(maxLevel), P(probability), curLevel(0),
        header(new Node(-1, maxLevel)),
        distribution(0.0, 1.0) {
    }

    ~SkipList() {
        freeList();
    }

    void init() {
        freeList();
        header = new Node(-1, MAXLVL);
        curLevel = 0;
    }

    void add(int key) {
        Node* current = header;
        std::vector<Node*> update(MAXLVL + 1, nullptr);

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key < key) {
                current = current->forward[i];
            }
            update[i] = current;
        }

        current = current->forward[0];

        if (!current || current->key != key) {
            int rlevel = randomLevel();

            if (rlevel > curLevel) {
                for (int i = curLevel + 1; i <= rlevel; i++) {
                    update[i] = header;
                }
                curLevel = rlevel;
            }

            Node* n = new Node(key, rlevel);
            for (int i = 0; i <= rlevel; i++) {
                n->forward[i] = update[i]->forward[i];
                update[i]->forward[i] = n;
            }
        }
    }

    void erase(int key) {
        Node* current = header;
        std::vector<Node*> update(MAXLVL + 1, nullptr);

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key < key) {
                current = current->forward[i];
            }
            update[i] = current;
        }

        current = current->forward[0];

        if (current && current->key == key) {
            for (int i = 0; i <= curLevel; i++) {
                if (update[i]->forward[i] != current) break;
                update[i]->forward[i] = current->forward[i];
            }
            delete current;

            while (curLevel > 0 && !header->forward[curLevel]) {
                curLevel--;
            }
        }
    }

    bool exists(int key) const {
        Node* current = header;

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key < key) {
                current = current->forward[i];
            }
        }

        current = current->forward[0];
        return current && current->key == key;
    }

    const int* successor(int key) const {
        Node* current = header;

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key <= key) {
                current = current->forward[i];
            }
        }

        current = current->forward[0];
        return current ? &current->key : nullptr;
    }

    const int* predecessor(int key) const {
        Node* current = header;
        Node* pred = nullptr;

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key < key) {
                pred = current->forward[i];
                current = current->forward[i];
            }
        }

        return pred ? &pred->key : nullptr;
    }

    void parcurgere(int x, int y) const {
        Node* current = header;

        for (int i = curLevel; i >= 0; i--) {
            while (current->forward[i] && current->forward[i]->key < x) {
                current = current->forward[i];
            }
        }

        current = current->forward[0];

        while (current && current->key <= y) {
            fout << current->key << " ";
            current = current->forward[0];
        }
        fout << '\n';
    }

    void displayList() const {
        std::cout << "\n*****Skip List*****" << std::endl;
        for (int i = 0; i <= curLevel; i++) {
            Node* node = header->forward[i];
            std::cout << "Level " << i << ": ";
            while (node) {
                std::cout << node->key << " ";
                node = node->forward[i];
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    // std::ios_base::sync_with_stdio(false);
    // std::cin.tie(0);

    ifstream cin("abce.in");
    int t, op, x, y;

    cin >> t;

    SkipList list(32, 0.5);
    list.init();

    do {
        cin >> op >> x;
        switch (op) {
        case 1:
            list.add(x);
            break;
        case 2:
            list.erase(x);
            break;
        case 3:
            fout << (list.exists(x) ? 1 : 0) << '\n';
            break;
        case 4:
            fout << *list.predecessor(x) << '\n';;
            break;
        case 5:
            fout << *list.successor(x) << '\n';
            break;
        case 6:
            cin >> y;
            list.parcurgere(x, y);
            break;
        }
        // list.displayList();
    } while (--t);

    return 0;
}


// int main() {
//     SkipList list(5, 0.5);

//     list.add(3);
//     list.add(3);
//     list.add(7);
//     list.add(9);
//     list.add(12);
//     list.add(19);
//     list.add(17);
//     list.add(26);
//     list.add(21);
//     list.add(25);

//     list.displayList();

//     list.erase(19);

//     std::cout << "After deletion of 19:" << std::endl;
//     list.displayList();

//     std::cout << "Exists 17: " << (list.exists(17) ? "Yes" : "No") << std::endl;

//     const int* succ = list.successor(17);
//     if (succ) {
//         std::cout << "Successor of 17 is " << *succ << std::endl;
//     } else {
//         std::cout << "No successor found for 17" << std::endl;
//     }

//     const int* pred = list.predecessor(17);
//     if (pred) {
//         std::cout << "Predecessor of 17 is " << *pred << std::endl;
//     } else {
//         std::cout << "No predecessor found for 17" << std::endl;
//     }

//     std::cout << "Traversal between 6 and 21:" << std::endl;
//     list.parcurgere(6, 21);

//     return 0;
// }
