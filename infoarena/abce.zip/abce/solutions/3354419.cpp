#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val, height;
    Node *left, *right;
    Node(int v) : val(v), height(1), left(nullptr), right(nullptr) {}
};

int getHeight(Node* n) {
    if (n == nullptr) return 0;
    return n->height;
}

int getBalance(Node* n) {
    if (n == nullptr) return 0;
    return getHeight(n->left) - getHeight(n->right);
}

void updateHeight(Node* n) {
    if (n != nullptr)
        n->height = 1 + max(getHeight(n->left), getHeight(n->right));
}

Node* rotateRight(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;
    x->right = y;
    y->left = T2;
    updateHeight(y);
    updateHeight(x);
    return x;
}

Node* rotateLeft(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;
    y->left = x;
    x->right = T2;
    updateHeight(x);
    updateHeight(y);
    return y;
}

Node* balance(Node* n) {
    updateHeight(n);
    int bal = getBalance(n);
    
    if (bal > 1) {
        if (getBalance(n->left) < 0)
            n->left = rotateLeft(n->left);
        return rotateRight(n);
    }
    if (bal < -1) {
        if (getBalance(n->right) > 0)
            n->right = rotateRight(n->right);
        return rotateLeft(n);
    }
    return n;
}

Node* insert(Node* n, int val) {
    if (n == nullptr) return new Node(val);
    if (val < n->val) n->left = insert(n->left, val);
    else n->right = insert(n->right, val);
    return balance(n);
}

bool search(Node* n, int val) {
    if (n == nullptr) return false;
    if (val == n->val) return true;
    if (val < n->val) return search(n->left, val);
    return search(n->right, val);
}

int floorVal(Node* n, int val) {
    if (n == nullptr) return INT_MIN;
    if (n->val == val) return val;
    if (val < n->val) return floorVal(n->left, val);
    int rightFloor = floorVal(n->right, val);
    return (rightFloor == INT_MIN) ? n->val : rightFloor;
}

int ceilVal(Node* n, int val) {
    if (n == nullptr) return INT_MAX;
    if (n->val == val) return val;
    if (val > n->val) return ceilVal(n->right, val);
    int leftCeil = ceilVal(n->left, val);
    return (leftCeil == INT_MAX) ? n->val : leftCeil;
}

void rangeQuery(Node* n, int x, int y) {
    if (n == nullptr) return;
    if (n->val > x) rangeQuery(n->left, x, y);
    if (n->val >= x && n->val <= y) printf("%d ", n->val);
    if (n->val < y) rangeQuery(n->right, x, y);
}

int main() {
    freopen("abce.in", "r", stdin);
    freopen("abce.out", "w", stdout);
    
    int Q;
    scanf("%d", &Q);
    
    Node* root = nullptr;
    
    while (Q--) {
        int tip, x, y;
        scanf("%d %d", &tip, &x);
        
        if (tip == 1) {
            root = insert(root, x);
        } else if (tip == 2) {
            
        } else if (tip == 3) {
            printf("%d\n", search(root, x) ? 1 : 0);
        } else if (tip == 4) {
            printf("%d\n", floorVal(root, x));
        } else if (tip == 5) {
            printf("%d\n", ceilVal(root, x));
        } else if (tip == 6) {
            scanf("%d", &y);
            rangeQuery(root, x, y);
            printf("\n");
        }
    }
    
    return 0;
}