#include <algorithm>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <vector>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");
// #define f cin
// #define g cout

const int t = 100;  // Minimum degree

struct Tree {
  Tree **children;
  int *keys;
  int nKeys;

  Tree() {
    keys = new int[2 * t - 1];
    children = new Tree *[2 * t];
    nKeys = 0;
    memset(children, 0, sizeof(Tree *) * 2 * t);
  }

  inline bool is_leaf() const { return children[0] == nullptr; }

  int findKey(int k) {
    int left = 0, right = nKeys - 1;

    while (left <= right) {
      int mid = (left + right) >> 1;

      if (keys[mid] == k) {
        return mid;
      }
      if (keys[mid] < k) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }

    return left;  // If the key is not found, return
                  // the index where it should be inserted
  }

  void split_child(int i, Tree *y) {
    Tree *z = new Tree();
    z->nKeys = t - 1;

    for (int j = 0; j < t - 1; j++) z->keys[j] = y->keys[j + t];

    if (!y->is_leaf()) {
      for (int j = 0; j < t; j++) z->children[j] = y->children[j + t];
    }

    y->nKeys = t - 1;

    for (int j = nKeys; j >= i + 1; j--) children[j + 1] = children[j];

    children[i + 1] = z;

    for (int j = nKeys - 1; j >= i; j--) keys[j + 1] = keys[j];

    keys[i] = y->keys[t - 1];
    nKeys++;
  }

  void insert(int k) {
    int i = nKeys - 1;

    if (is_leaf()) {
      while (i >= 0 && keys[i] > k) {
        keys[i + 1] = keys[i];
        i--;
      }
      keys[i + 1] = k;
      nKeys++;
    } else {
      while (i >= 0 && keys[i] > k) i--;

      if (children[i + 1] && children[i + 1]->nKeys == 2 * t - 1) {
        split_child(i + 1, children[i + 1]);

        if (keys[i + 1] < k) i++;
      }
      if (children[i + 1]) children[i + 1]->insert(k);
    }
  }

  void remove(int k) {
    int idx = findKey(k);

    if (idx < nKeys && keys[idx] == k) {
      if (is_leaf())
        remove_leaf_node(idx);
      else
        remove_nonleaf_node(idx);
    } else {
      if (is_leaf()) {
        return;
      }

      bool flag = (idx == nKeys);

      if (children[idx] && children[idx]->nKeys < t) fill(idx);

      if (flag && idx > nKeys && children[idx - 1])
        children[idx - 1]->remove(k);
      else if (children[idx])
        children[idx]->remove(k);
    }
  }

  void remove_leaf_node(int idx) {
    for (int i = idx + 1; i < nKeys; ++i) keys[i - 1] = keys[i];
    nKeys--;
  }

  void remove_nonleaf_node(int idx) {
    int k = keys[idx];

    if (children[idx] && children[idx]->nKeys >= t) {
      int pred = get_pre(idx);
      keys[idx] = pred;
      children[idx]->remove(pred);
    } else if (children[idx + 1] && children[idx + 1]->nKeys >= t) {
      int succ = get_suc(idx);
      keys[idx] = succ;
      children[idx + 1]->remove(succ);
    } else {
      if (children[idx] && children[idx + 1]) merge(idx);
      if (children[idx]) children[idx]->remove(k);
    }
  }

  int get_pre(int idx) {
    Tree *cur = children[idx];
    while (cur && !cur->is_leaf()) cur = cur->children[cur->nKeys];
    return cur ? cur->keys[cur->nKeys - 1] : -1;
  }

  int get_suc(int idx) {
    Tree *cur = children[idx + 1];
    while (cur && !cur->is_leaf()) cur = cur->children[0];
    return cur ? cur->keys[0] : -1;
  }

  void fill(int idx) {
    if (idx != 0 && children[idx - 1] && children[idx - 1]->nKeys >= t)
      borrow_prev(idx);
    else if (idx != nKeys && children[idx + 1] && children[idx + 1]->nKeys >= t)
      borrow_next(idx);
    else {
      if (idx != nKeys)
        merge(idx);
      else
        merge(idx - 1);
    }
  }

  void borrow_prev(int idx) {
    Tree *child = children[idx];
    Tree *sibling = children[idx - 1];

    for (int i = child->nKeys - 1; i >= 0; i--)
      child->keys[i + 1] = child->keys[i];

    if (!child->is_leaf()) {
      for (int i = child->nKeys; i >= 0; i--)
        child->children[i + 1] = child->children[i];
    }

    child->keys[0] = keys[idx - 1];

    if (!child->is_leaf())
      child->children[0] = sibling->children[sibling->nKeys];

    keys[idx - 1] = sibling->keys[sibling->nKeys - 1];

    child->nKeys += 1;
    sibling->nKeys -= 1;
  }

  void borrow_next(int idx) {
    Tree *child = children[idx];
    Tree *sibling = children[idx + 1];

    child->keys[child->nKeys] = keys[idx];

    if (!child->is_leaf())
      child->children[child->nKeys + 1] = sibling->children[0];

    keys[idx] = sibling->keys[0];

    for (int i = 1; i < sibling->nKeys; i++)
      sibling->keys[i - 1] = sibling->keys[i];

    if (!sibling->is_leaf()) {
      for (int i = 1; i <= sibling->nKeys; i++)
        sibling->children[i - 1] = sibling->children[i];
    }

    child->nKeys += 1;
    sibling->nKeys -= 1;
  }

  void merge(int idx) {
    Tree *child = children[idx];
    Tree *sibling = children[idx + 1];

    child->keys[t - 1] = keys[idx];

    for (int i = 0; i < sibling->nKeys; i++)
      child->keys[i + t] = sibling->keys[i];

    if (!child->is_leaf()) {
      for (int i = 0; i <= sibling->nKeys; i++)
        child->children[i + t] = sibling->children[i];
    }

    for (int i = idx + 1; i < nKeys; i++) keys[i - 1] = keys[i];

    for (int i = idx + 2; i <= nKeys; i++) children[i - 1] = children[i];

    child->nKeys += sibling->nKeys + 1;
    nKeys--;

    delete sibling;
  }
};

struct BTree {
  Tree *root;

  BTree() { root = nullptr; }

  void insert(int k) {
    if (!root) {
      root = new Tree();
      root->keys[0] = k;
      root->nKeys = 1;
    } else {
      if (root->nKeys == 2 * t - 1) {
        Tree *s = new Tree();
        s->children[0] = root;
        s->split_child(0, root);

        int i = 0;
        if (s->keys[0] < k) i++;
        s->children[i]->insert(k);

        root = s;
      } else {
        root->insert(k);
      }
    }
  }

  void remove(int k) {
    if (!root) {
      return;
    }

    root->remove(k);

    if (root->nKeys == 0) {
      Tree *tmp = root;
      if (root->is_leaf())
        root = nullptr;
      else
        root = root->children[0];

      delete tmp;
    }
  }
};

BTree *b;

// BOILERPLATE START
void init();
void add(int x);
void erase(int x);
bool exists(int x);
int succesor(int x);
int predecesor(int x);
void parcurgere(int x, int y);
int main() {
  std::ios_base::sync_with_stdio(false);
  f.tie(0);
  int _, op, x, y;
  f >> _;
  init();
  do {
    f >> op >> x;
    switch (op) {
      case 1:
        add(x);
        break;
      case 2:
        erase(x);
        break;
      case 3:
        g << exists(x) << '\n';
        break;
      case 5:
        g << succesor(x) << '\n';
        break;
      case 4:
        g << predecesor(x) << '\n';
        break;
      case 6:
        f >> y;
        parcurgere(x, y);
        break;
    }
  } while (_ -= 1);
  return 0;
}
// BOILERPLATE END

void init() { b = new BTree(); }

void add(int x) { b->insert(x); }

void erase(int x) { b->remove(x); }

bool exists(int x) {
  Tree *current = b->root;
  while (current) {
    int i = 0;
    while (i < current->nKeys && current->keys[i] < x) i++;
    if (i < current->nKeys && current->keys[i] == x) return true;
    if (current->is_leaf()) return false;
    current = current->children[i];
  }
  return false;
}

int succesor(int x) {
  if (exists(x)) return x;
  Tree *current = b->root;
  int succ = -1;

  while (current) {
    int i = 0;
    while (i < current->nKeys && current->keys[i] <= x) {
      i++;
    }
    if (i < current->nKeys) {
      succ = current->keys[i];
      if (current->is_leaf()) {
        return succ;
      }
      current = current->children[i];
    } else {
      if (current->is_leaf()) {
        return succ;
      }
      current = current->children[current->nKeys];
    }
  }

  return succ;
}

int predecesor(int x) {
  if (exists(x)) return x;

  Tree *current = b->root;
  int pred = -1;

  while (current) {
    int i = current->nKeys - 1;
    while (i >= 0 && current->keys[i] >= x) {
      i--;
    }
    if (i >= 0) {
      pred = current->keys[i];
      if (current->is_leaf()) {
        return pred;
      }
      current = current->children[i + 1];
    } else {
      if (current->is_leaf()) {
        return pred;
      }
      current = current->children[0];
    }
  }

  return pred;
}

void parcurgere(int x, int y) {
  vector<int> result;
  Tree *current = b->root;

  function<void(Tree *)> traverse = [&](Tree *node) {
    if (!node) return;
    int i;
    for (i = 0; i < node->nKeys; i++) {
      if (node->keys[i] >= x && node->keys[i] <= y)
        result.push_back(node->keys[i]);
      if (!node->is_leaf()) traverse(node->children[i]);
    }
    if (!node->is_leaf()) traverse(node->children[i]);
  };

  traverse(current);

  sort(result.begin(), result.end());
  for (int val : result) g << val << " ";
  g << '\n';
}