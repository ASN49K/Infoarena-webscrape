#include <exception>
#include <vector>
#include <fstream>

using namespace std;

class AVLTree {
public:
    AVLTree() : root(nullptr) {}
    void add(int element) {
        root = insertRecursive(root, element);
    }

    bool search(int element) {
        auto currentNode = root;
        while (currentNode != nullptr) {
            if (element == currentNode->element)
                return true;
            if (element < currentNode->element)
                currentNode = currentNode->leftChild;
            else
                currentNode = currentNode->rightChild;
        }
        return false;
    }

    void remove(int element) {
        root = removeRecursive(root, element);
    }

    //Returns the biggest element of the tree that is smaller or equal to upperBound
    //If such element does not exist, an exception is raised
    int biggestElementAtMost(int upperBound) {
        auto currentNode = root;
        int candidateElement;
        bool found = false;

        while (currentNode != nullptr) {
            if (currentNode->element > upperBound)
                currentNode = currentNode->leftChild;
            else {
                candidateElement = currentNode->element;
                found = true;
                currentNode = currentNode->rightChild;
            }
        }

        if (!found)
            throw exception();
        return candidateElement;
    }

    //Returns the smallest element of the tree that is bigger or equal to lowerBound
    //If such element does not exist, an exception is raised
    int smallestElementAtLeast(int lowerBound) {
        auto currentNode = root;
        int candidateElement;
        bool found = false;

        while (currentNode != nullptr) {
            if (currentNode->element < lowerBound)
                currentNode = currentNode->rightChild;
            else {
                candidateElement = currentNode->element;
                found = true;
                currentNode = currentNode->leftChild;
            }
        }

        if (!found)
            throw exception();
        return candidateElement;
    }

    //Returns a sorted ascending vector with all elements of the tree between the two bounds,
    //including elements equal to the two bounds
    vector<int> elementsBetween(int lowerBound, int upperBound) {
        vector<int> v;
        elementsBetweenRecursive(root, lowerBound, upperBound, v);
        return v;
    }

private:
    struct Node {
        int element;
        Node* leftChild;
        Node* rightChild;
        int height;
    } *root;

    static Node* allocateNode(int element) {
        auto newNode = new Node;
        newNode->leftChild = nullptr;
        newNode->rightChild = nullptr;
        newNode->element = element;
        newNode->height = 0;
        return newNode;
    }

    static void recomputeHeight(Node* node) {
        if (node->leftChild == nullptr && node->rightChild == nullptr)
            node->height = 0;
        else if (node->leftChild == nullptr)
            node->height = node->rightChild->height + 1;
        else if (node->rightChild == nullptr)
            node->height = node->leftChild->height + 1;
        else {
            int leftHeight = node->leftChild->height;
            int rightHeight = node->rightChild->height;
            int maxHeight = leftHeight > rightHeight ? leftHeight : rightHeight;
            node->height = maxHeight + 1;
        }
    }

    static int balanceFactor(Node* node) {
        if (node->leftChild == nullptr && node->rightChild == nullptr)
            return 0;
        else if (node->leftChild == nullptr)
            return -1 - node->rightChild->height;
        else if (node->rightChild == nullptr)
            return node->leftChild->height + 1;
        else
            return node->leftChild->height - node->rightChild->height;
    }

    static Node* doubleRightRotation(Node* node) {
        auto k2 = node;
        auto k1 = k2->leftChild;
        auto k3 = k1->rightChild;
        k1->rightChild = k3->leftChild;
        k2->leftChild = k3->rightChild;
        k3->leftChild = k1;
        k3->rightChild = k2;
        recomputeHeight(k1);
        recomputeHeight(k2);
        recomputeHeight(k3);
        return k3;
    }

    static Node* doubleLeftRotation(Node* node) {
        auto k1 = node;
        auto k2 = k1->rightChild;
        auto k3 = k2->leftChild;
        k1->rightChild = k3->leftChild;
        k2->leftChild = k3->rightChild;
        k3->leftChild = k1;
        k3->rightChild = k2;
        recomputeHeight(k1);
        recomputeHeight(k2);
        recomputeHeight(k3);
        return k3;
    }

    static Node* singleRightRotation(Node* node) {
        auto k1 = node;
        auto k2 = node->leftChild;
        k1->leftChild = k2->rightChild;
        k2->rightChild = k1;
        recomputeHeight(k1);
        recomputeHeight(k2);
        return k2;

    }

    static Node* singleLeftRotation(Node* node) {
        auto k1 = node;
        auto k2 = node->rightChild;
        k1->rightChild = k2->leftChild;
        k2->leftChild = k1;
        recomputeHeight(k1);
        recomputeHeight(k2);
        return k2;
    }

    static Node* balanceNode(Node* node) {
        int balance = balanceFactor(node);
        if (balance < -1 ) {
            int rightBalance = balanceFactor(node->rightChild);
            if (rightBalance <= 0)
                return singleLeftRotation(node);
            else
                return doubleLeftRotation(node);
        }
        if(balance > 1) {
            int leftBalance = balanceFactor(node->leftChild);
            if (leftBalance >= 0)
                return singleRightRotation(node);
            else
                return doubleRightRotation(node);
        }
        return node;
    }

    static Node* insertRecursive(Node* node, int element) {
        if (node == nullptr)
            return allocateNode(element);
        if (element < node->element)
            node->leftChild = insertRecursive(node->leftChild, element);
        else
            node->rightChild = insertRecursive(node->rightChild, element);
        recomputeHeight(node);
        return balanceNode(node);
    }

    static Node* removeRecursive(Node* node, int element) {
        if (node == nullptr)
            return nullptr;

        if (element == node->element) {
            if (node->leftChild != nullptr && node->rightChild != nullptr) {
                auto biggestLeftNode = node->leftChild;
                while (biggestLeftNode->rightChild != nullptr)
                    biggestLeftNode = biggestLeftNode->rightChild;

                int movedElement = biggestLeftNode->element;
                node->leftChild = removeRecursive(node->leftChild, movedElement);
                node->element = movedElement;
                recomputeHeight(node);
                return balanceNode(node);
            }

            Node* returnValue;
            if (node->leftChild == nullptr && node->rightChild == nullptr)
                returnValue = nullptr;
            else if(node->rightChild == nullptr)
                returnValue = node->leftChild;
            else
                returnValue = node->rightChild;

            delete node;
            return returnValue;
        }

        else if (element < node->element)
            node->leftChild = removeRecursive(node->leftChild, element);
        else
            node->rightChild = removeRecursive(node->rightChild, element);
        recomputeHeight(node);
        return balanceNode(node);
    }

    static void elementsBetweenRecursive(Node* node, int lowerBound, int upperBound, vector<int> &v) {
        if (node == nullptr || node->element < lowerBound || node->element > upperBound)
            return;
        elementsBetweenRecursive(node->leftChild, lowerBound, upperBound, v);
        v.push_back(node->element);
        elementsBetweenRecursive(node->rightChild, lowerBound, upperBound, v);
    }
};

int main() {
    AVLTree tree;
    int Q, opType, X, Y;
    fstream fin("abce.in");
    fin >> Q;

    ofstream fout("abce.out");
    while(Q--) {
        fin >> opType >> X;
        switch (opType) {
            case 1:
                tree.add(X);
                break;
            case 2:
                tree.remove(X);
                break;
            case 3:
                fout << tree.search(X) << '\n';
                break;
            case 4:
                fout << tree.biggestElementAtMost(X) << '\n';
                break;
            case 5:
                fout << tree.smallestElementAtLeast(X) << '\n';
                break;
            case 6:
                fin >> Y;
                for(int number : tree.elementsBetween(X, Y))
                    fout << number << ' ';
                fout << '\n';
                break;
            default:
                throw exception();
        }
    }
}