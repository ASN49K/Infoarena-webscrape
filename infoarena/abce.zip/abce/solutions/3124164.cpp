#include<iostream>
#include<time.h>
#include<math.h>
#include<stdlib.h>
#include <fstream>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");


class Treap{
public:
    int key;
    int priority;
    Treap* stanga;
    Treap* dreapta;
//------------------
    Treap(){
    this->key = 0 ;
    this-> priority = 0;
    this->stanga = NULL;
    this->dreapta = NULL;
    }
//------------------
    Treap(int key,int priority, Treap* stanga,Treap* dreapta){
        this->key = key;
        this->priority = priority;
        this->stanga = stanga;
        this->dreapta = dreapta;
    }
};
//------------------
Treap* TreapNou(int key,int priority)
    {Treap* nou = new Treap(key,priority,NULL,NULL);
    return nou;
    }
//------------------
void cautare(Treap* &radacina, int key){
    if(radacina == NULL){fout<<"0\n";return;}
    if(radacina->key == key){fout<<"1\n"; return;}
    if(radacina->key < key) cautare(radacina->dreapta ,key);
    else cautare(radacina->stanga ,key);
}
//------------------
Treap* rotireDreapta(Treap* &radacina)
    {Treap* aux = radacina->stanga;
    Treap* aux2 = aux->dreapta;
    aux->dreapta =  radacina;
    radacina->stanga = aux2;
    return aux;
    }
//------------------
Treap* rotireStanga(Treap* &radacina)
    {Treap* aux = radacina->dreapta;
    Treap* aux2 = aux->stanga;
    aux->stanga = radacina;
    radacina->dreapta = aux2;
    return aux;
    }

//------------------

void traversare(Treap* radacina)
    {if (radacina == NULL)
        return;

    traversare(radacina->stanga);
    cout <<'('<< radacina->key<<','<<radacina->priority<<')' << " ";
    traversare(radacina->dreapta);
    }
//------------------
Treap* inserare(Treap* radacina,int key)
    {if(radacina == NULL){
        radacina = TreapNou(key,rand()%100000000);
        return radacina;
    }
    if(key <= radacina->key)
        {radacina->stanga = inserare(radacina->stanga,key);
        if(radacina->stanga->priority > radacina->priority)
            radacina = rotireDreapta(radacina);
        }
    else
        {radacina->dreapta = inserare(radacina->dreapta,key);
        if(radacina->dreapta->priority > radacina->priority)
            radacina = rotireStanga(radacina);
        }
    return radacina;
    }

Treap* inserare(Treap* radacina,int key,int priority){
    if(radacina == NULL){
        radacina = TreapNou(key,priority);
        return radacina;
    }
    if(key <= radacina->key){
        radacina->stanga = inserare(radacina->stanga,key,priority);
        if(radacina->stanga->priority > radacina->priority)
            radacina = rotireDreapta(radacina);
    }
    else{
        radacina->dreapta = inserare(radacina->dreapta,key,priority);
        if(radacina->dreapta->priority > radacina->priority)
            radacina = rotireStanga(radacina);
    }
    return radacina;
    }
 //-------------------------------------------------------------
Treap* construct(int v[], int n)
    {if (n == 0)
        return NULL;
    Treap* radacina = NULL;
    for (int i = 0; i < n; i++)
        radacina = inserare(radacina, v[i],rand()%100000000);
    return radacina;
    }
//--------------------------------------------------------------

Treap* minim(Treap* &radacina)
    {if(radacina->stanga != NULL)
        return minim(radacina->stanga);
    else
        return radacina;
    }
//--------------------------------------------------------------
Treap* maxim(Treap* &radacina)
    {if(radacina->dreapta != NULL)
        return maxim(radacina->dreapta);
    else
        return radacina;
    }
//--------------------------------------------------------------
Treap* stergere(Treap* &radacina,int key)
    {
    if(radacina == NULL) return NULL;

    if(key < radacina->key)
        radacina->stanga = stergere(radacina->stanga , key);
    else if(key > radacina->key)
    radacina->dreapta = stergere(radacina->dreapta , key);

    else if(key == radacina->key)
        { if(radacina->stanga ==NULL)   // n-are copil in stanga, mergem pe dreapta
            {Treap* aux = radacina->dreapta;
            delete radacina;
            radacina = aux;
            }
        else if(radacina->dreapta == NULL)   // n-are copil in dreapta, mergem pe stanga
            {Treap* aux = radacina->stanga;
            delete radacina;
            radacina = aux;
            }
        else if(radacina->stanga->priority < radacina->dreapta->priority)
            {radacina = rotireStanga(radacina);
            radacina->stanga = stergere(radacina->stanga,key);
            }
        else if(radacina->dreapta->priority <= radacina->stanga->priority)
            {radacina = rotireDreapta(radacina);
            radacina->dreapta = stergere(radacina->dreapta , key);
            }
        }
    return radacina;
    }
//--------------------------------------------------------------------------------

void dezalocare(Treap* &radacina)
    {if(radacina != NULL)
        {if(radacina->stanga != NULL)
                dezalocare(radacina->stanga);
         if(radacina->dreapta != NULL)
                dezalocare(radacina->dreapta);
        delete radacina;
        radacina = NULL;
        }
    }
 //--------------------------------------------------------------------------------------------
int minimN(Treap* &radacina,int key)
    {if(radacina == NULL) return -1;
     if(radacina->key == key) return key;
     else if(radacina->key > key)
        {int k = minimN(radacina->stanga , key);
         if( k == -1)
            return radacina-> key;
         else
            return k;
        }
     else if(radacina->key < key)
     {return minimN(radacina->dreapta,key);
     }
    return -1;
    }
//----------------------------------------------------------------------------------------------------
int maximN(Treap* &radacina, int key)
    {if(radacina == NULL) return -1;
     if(radacina->key == key) return key;
     else if(radacina->key < key)
        {int k = maximN(radacina->dreapta, key);
         if(k == -1)
            return radacina->key;
         else
            return k;
        }
     else if(radacina->key > key)
        {return maximN(radacina->stanga,key);
        }
    return -1;
    }

//---------------------------------------------------------------------------------------
void interval(Treap* &radacina,int key1 ,int key2)
    {if (radacina == NULL)
        return;
    interval(radacina->stanga,key1,key2);
    if(radacina->key >= key1 && radacina->key <= key2)
        fout<<radacina->key<<' ';
    interval(radacina->dreapta,key1,key2);
    }
//---------------------------------------------------------------------------------------

/*

//---------------------------------------------------------------------------------
Treap* copiere(Treap* &radacina,Treap* &aux)
    {if (radacina == NULL)
        return NULL;
    copiere(radacina->stanga,aux);
    aux = inserare(aux,radacina->key,radacina->priority);
    copiere(radacina->dreapta,aux);
    return aux;
    }
//---------------------------------------------------------------------------------
void afisareSplit(Treap* &radacina,int key)
    {radacina = inserare(radacina,key,INFINITY);
    cout<<"Subtreap Stang\n";
    traversare(radacina->stanga);
    cout<<"\nSubtreap Dreapta\n";
    traversare(radacina->dreapta);
    radacina = stergere(radacina,key);
    }
//---------------------------------------------------------------------------------
void split(Treap* &radacina, Treap* &stanga, Treap* &dreapta, int key)
    {Treap *subStanga=NULL,*subDreapta=NULL;
    radacina = inserare(radacina , key , INFINITY);
    subStanga = copiere(radacina->stanga,subStanga);
    subDreapta = copiere(radacina->dreapta,subDreapta);
    radacina = stergere(radacina , key);
    stanga = subStanga;
    dreapta = subDreapta;
    }
//-------------------------------------------------------------------------------------------
Treap* join(Treap* &stanga,Treap* &dreapta)
    {if(maxim(stanga)->key < minim(dreapta)->key)
        {int key = (maxim(stanga)->key + minim(dreapta)->key)/2;
        Treap *aux = new Treap(key,INFINITY,stanga,dreapta);
        aux = stergere(aux,key);
        return aux;
        }
    return NULL;
    }
//-------------------------------------------------------------------------------------------
Treap* reuniune(Treap* &stanga , Treap* &dreapta)
    {if (dreapta != NULL)
        {if(dreapta->stanga !=NULL)
            stanga = reuniune(stanga,dreapta->stanga);
         if(dreapta->dreapta !=NULL)
            stanga = reuniune(stanga,dreapta->dreapta);
         stanga = inserare(stanga,dreapta->key,dreapta->priority);
        }
    return stanga;
    }
*/

int main()
{srand(time(nullptr));
Treap *treap=NULL;
int nrOp,operatii,a,b;
    fin>>nrOp;
    for(int i = 0 ; i < nrOp ; i++){
        fin>>operatii;
        fin>>a;
        switch(operatii){
            case 1:
                {treap = inserare(treap,a);
                break;}
            case 2:
                {treap = stergere(treap,a);
                break;}
            case 3:
               {cautare(treap,a);
                break;}
            case 4:
                {fout<<maximN(treap,a)<<'\n';
                break;}
            case 5:
                {fout<<minimN(treap,a)<<'\n';
                break;}
            case 6:{fin>>b;
                interval(treap,a,b);
                fout<<'\n';
                break;}
                        }
                                    }



    fin.close();
    fout.close();
    dezalocare(treap);
}
