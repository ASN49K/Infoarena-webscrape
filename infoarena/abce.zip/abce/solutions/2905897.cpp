#include <iostream>
#include <fstream>
using namespace std;

template<typename T>
class SplayTree;

template<typename T>
class Nod{
public:
    T valoare;
    Nod<T> *stanga,*dreapta,*parinte;

    Nod(T& val) : valoare(val), stanga(NULL), dreapta(NULL), parinte(NULL){};

    Nod* getBunic(){
        return parinte == NULL ? parinte->parinte : NULL;
    }

    Nod<T>* rotireDreapta(Nod<T>* nod){
        Nod* aux = nod->stanga;
        nod->stanga = aux->dreapta;
        nod->dreapta = aux;
    }

    bool eStanga(){
        return this == parinte->stanga;
    }

    bool eDreapta(){
        return this == parinte->dreapta;
    }

    //friend class SplayTree<T>;
};

template<typename T>
class SplayTree{
    Nod<T>* radacina=NULL;

    void updateCopii(Nod<T>* nod, Nod<T>* nod2);

    void rotireDreapta(Nod<T>* nod);

    void rotireStanga(Nod<T>* nod);

    void splay(Nod<T>* nod);

public:
    Nod<T>*& getRadacina(){return radacina;}

    Nod<T>* getMaxim(Nod<T>* nod);

    Nod<T>* getMinim(Nod<T>* nod);

    Nod<T>* sterge(Nod<T>* nod, T& valoare);

    Nod<T>* insert(Nod<T>* nod, T& inserat);

    Nod<T>* cauta(T& valoare);

    Nod<T>* getMinim(Nod<T>* nod, T& valoare);

    Nod<T>* getMaxim(Nod<T>* nod, T& valoare);

    void inorder(Nod<T>* nod, ostream& out);

    void inserare(T& valoare){
        radacina = insert(radacina, valoare);
    }

    void sterge(T& valoare){
        radacina = sterge(radacina, valoare);
    }

    void inorder(Nod<T>* nod, T& a, T& b, ostream& out);
};

template<typename T>
void SplayTree<T>::updateCopii(Nod<T>* nod, Nod<T>* nod2){
    if(nod->parinte == NULL){
        radacina = nod2;
    }
    else if(nod->eStanga()){
        nod->parinte->stanga=nod2;
    }
    else{
        nod->parinte->dreapta=nod2;
    }
}

template<typename T>
void SplayTree<T>::rotireDreapta(Nod<T>* nod){
    Nod<T>* nodStanga = nod->stanga;
    nod->stanga=nodStanga->dreapta;
    if(nod->stanga != NULL){
        nod->stanga->parinte=nod;
    }

    updateCopii(nod, nodStanga);

    nodStanga->parinte=nod->parinte;
    nodStanga->dreapta=nod;
    nod->parinte=nodStanga;
}

template<typename T>
void SplayTree<T>::rotireStanga(Nod<T>* nod){
    Nod<T>* nodDreapta = nod->dreapta;
    nod->dreapta=nod->stanga;
    if(nod->dreapta != NULL){
        nod->dreapta->parinte=nod;
    }

    updateCopii(nod, nodDreapta);

    nodDreapta->parinte=nod->parinte;
    nodDreapta->stanga=nod;
    nod->parinte=nodDreapta;
}

template<typename T>
void SplayTree<T>::splay(Nod<T>* nod){
    while(nod != radacina){
        Nod<T>* parinte = nod->parinte;
        if(nod->getBunic() == NULL){ //zig
            if(nod->eStanga()){
                rotireDreapta(parinte);
            }
            else{
                rotireStanga(parinte);
            }
        }
        else if(nod->eStanga() && parinte->eStanga()){ //zig-zig - stanga
            rotireDreapta(parinte->parinte);
            rotireDreapta(parinte);
        }
        else if(nod->eDreapta() && parinte->eDreapta()){ //zig-zig - dreapta
            rotireStanga(parinte->parinte);
            rotireStanga(parinte);
        }
        else if(nod->eStanga() && parinte->eDreapta()){ //zig-zag - dreapta stanga
            rotireDreapta(parinte);
            rotireStanga(parinte);
        }
        else{ //zag-zig
            rotireStanga(parinte);
            rotireDreapta(parinte);
        }
    }
}

template<typename T>
Nod<T>* SplayTree<T>::getMaxim(Nod<T>* nod){
    while(nod->dreapta!=NULL)
        nod=nod->dreapta;
    return nod;
}

template<typename T>
Nod<T>* SplayTree<T>::getMinim(Nod<T>* nod){
    while(nod->stanga!=NULL)
        nod=nod->stanga;
    return nod;
}

template<typename T>
Nod<T>* SplayTree<T>::getMaxim(Nod<T>* nod, T &valoare){

    if(nod == NULL)
        return NULL;

    if(nod->valoare == valoare)
        return nod;

    if(nod->valoare < valoare){
        Nod<T>* val = getMaxim(nod->dreapta, valoare);
        if(val==NULL)
            return nod;
        return val;
    }
    else
        return getMaxim(nod->stanga, valoare);
}

template<typename T>
Nod<T>* SplayTree<T>::getMinim(Nod<T>* nod, T &valoare){

    if(nod == NULL)
        return NULL;

    if(nod->valoare == valoare)
        return nod;

    if(nod->valoare < valoare)
        return getMinim(nod->dreapta, valoare);
    else{
        Nod<T>* val = getMinim(nod->stanga, valoare);
        if(val==NULL)
            return nod;
        return val;
    }
}

template<typename T>
Nod<T>* SplayTree<T>::sterge(Nod<T>* nod, T& valoare){
    if(nod==NULL)
        return NULL;

    if(valoare<nod->valoare){
        nod->stanga=sterge(nod->stanga, valoare);
        if(nod->stanga != NULL)
            nod->stanga->parinte = nod;
    }
    else if(valoare > nod->valoare){
        nod->dreapta=sterge(nod->dreapta, valoare);
        if(nod->dreapta != NULL)
            nod->dreapta->parinte = nod;
    }
    else{
        if(nod->stanga == NULL)
            return nod->dreapta;
        else if(nod->dreapta == NULL)
            return nod->stanga;


        nod->valoare=getMaxim(nod->stanga)->valoare;
        nod->stanga=sterge(nod->stanga, nod->valoare);
        if(nod->stanga!=NULL)
            nod->stanga->parinte = nod;
    }

    return nod;
}

template<typename T>
Nod<T>* SplayTree<T>::insert(Nod<T>* nod, T& inserat){
    if(nod == NULL)
        return new Nod<T>(inserat);

    if(inserat < nod->valoare){
        nod->stanga = insert(nod->stanga, inserat);
        nod->stanga->parinte = nod;
    }
    else if(inserat > nod->valoare){
        nod->dreapta = insert(nod->dreapta, inserat);
        nod->dreapta->parinte = nod;
    }

    return nod;
}

template<typename T>
Nod<T>* SplayTree<T>::cauta(T& valoare){
    Nod<T>* nod = radacina;
    while(nod!=NULL){
        if(nod->valoare == valoare){
            //splay(nod);
            return nod;
        }


        if(valoare < nod->valoare)
            nod=nod->stanga;
        else
            nod=nod->dreapta;
    }
    return NULL;
}

template<typename T>
void SplayTree<T>::inorder(Nod<T>* nod, ostream& out){
    if(nod!=NULL){
        inorder(nod->stanga, out);
        out<<nod->valoare<<" ";
        inorder(nod->dreapta, out);
    }
}

template<typename T>
void SplayTree<T>::inorder(Nod<T>* nod, T& a, T& b, ostream& out){
    if(nod!=NULL){
        inorder(nod->stanga, out);
        if(a <= nod->valoare && nod->valoare <= b)
        out<<nod->valoare<<" ";
        inorder(nod->dreapta, out);
    }
}

int main()
{
    ifstream fin("abce.in");
    ofstream fout("abce.out");
    SplayTree<int> tree;

    int q;
    fin>>q;
    int op,a,b;
    while(q){
        fin>>op;
        if(op==1){
            fin>>a;
            tree.inserare(a);
        }
        else if(op==2){
            fin>>a;
            tree.sterge(a);
        }
        else if(op==3){
            fin>>a;
            fout<<(tree.cauta(a)==NULL?0:1)<<"\n";
        }
        else if(op==4){
            fin>>a;
            fout<<tree.getMaxim(tree.getRadacina(), a)->valoare<<"\n";
        }
        else if(op==5){
            fin>>a;
            //fout<<tree.getMinim(tree.getRadacina(), a)->valoare<<"\n";
        }
        else if(op==6){
            fin>>a>>b;
            tree.inorder(tree.getRadacina(), a, b, fout);
            fout<<"\n";
        }

        q--;
    }
    return 0;
}
