#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>
#include <time.h>

using namespace std;
ifstream in("abce.in");
ofstream out("abce.out");
struct Nod{
    int val;
    vector<Nod*> l;
};
void add(long val,Nod* sen){
    Nod* temp = sen;
    Nod* nou = new Nod;
    nou->val = val;
    int etaj=sen->l.size()-1;
    vector<Nod*> past;
    past.push_back(temp);
    if(sen->l[0]==nullptr){//daca e goala lista
        sen->l[0]=nou;
        nou->l.push_back(nullptr);
    }else{
        while(temp->l[0]!=nullptr&&etaj>=0){
            if(!temp->l[etaj] || val < temp->l[etaj]->val){
                past.push_back(temp);
                etaj--;
            }
            else if(val > temp->l[etaj]->val){
                temp=temp->l[etaj];
                while(!temp->l[0]&&etaj>=0){//ultimul
                    past.push_back(temp);
                    etaj--;
                }
            }
        }
        int i=0;
        do{
            nou->l.push_back(past.back()->l[i]);
            past.back()->l[i]=nou;
            if(past.size()>1)
            past.pop_back();
            i++;
            if(i>sen->l.size()-1){//creste peste sentinel
                nou->l.push_back(nullptr);
                sen->l.push_back(nou);
                break;
            }
        }while(rand()%2);
    }
}
void print(long val, long x,Nod* sen){
    Nod* temp = sen;
    int etaj=sen->l.size()-1;
     while(temp->l[0]!=nullptr&&etaj>=0){
            if(!temp->l[etaj] || val <= temp->l[etaj]->val){
                if(temp->l[etaj]&&temp->l[etaj]->val==val){
                    break;
                }
                etaj--;
            }
            else if(val > temp->l[etaj]->val){
                temp=temp->l[etaj];
                while(!temp->l[0]&&etaj>=0){//ultimul
                    etaj--;
                }
            }
        }
        temp=temp->l[0];
        while(temp->l[0]&&temp->val<x){
            out << temp->val << " ";
            temp=temp->l[0];
        }
        out << temp->val << " ";
        out << "\n";
}
void del(long val,Nod* sen){
    Nod* temp = sen;
    int etaj=sen->l.size()-1;
    vector<Nod*> past;
    past.push_back(temp);
    while(temp->l[0]!=nullptr&&etaj>=0){
        if(!temp->l[etaj] || val <= temp->l[etaj]->val){
            past.push_back(temp);
            etaj--;
        }
        else if(val > temp->l[etaj]->val){
            temp=temp->l[etaj];
            if(!temp->l[0]){past.push_back(temp);
                etaj--;
            }
        }
    }
    temp=temp->l[0];
    Nod* aux = temp;
    int siz = aux->l.size();
    for(int i=0;i<siz;i++){
        past.back()->l[i]=temp->l[i];
        past.pop_back();
    }
    delete temp;
}
bool isIn(long val,Nod* sen){
    Nod* temp = sen;
    int etaj=sen->l.size()-1;
    while(temp->l[0]!=nullptr&&etaj>=0){
        if(!temp->l[etaj] || val <= temp->l[etaj]->val){
            if(temp->l[etaj] &&temp->l[etaj]->val==val)return 1;
            etaj--;
        }
        else if(val > temp->l[etaj]->val){
            temp=temp->l[etaj];
        //if(temp->l[etaj]->val==val)return 1;
            if(!temp->l[0]){
                return 0;
                etaj--;
            }
        }
    }
    return 0;
}
long maiMic(long val,Nod* sen){
    Nod* temp = sen;
    int etaj=sen->l.size()-1;
     while(temp->l[0]!=nullptr&&etaj>=0){
            if(!temp->l[etaj] || val <= temp->l[etaj]->val){
				if(temp->l[etaj]&&temp->l[etaj]->val==val)return val;
                etaj--;
            }
            else if(val > temp->l[etaj]->val){
                temp=temp->l[etaj];
                while(!temp->l[0]&&etaj>=0){//ultimul
                    etaj--;
                }
            }
        }
        return temp->val;
}
long maiMare(long val,Nod* sen){
    Nod* temp = sen;
    int etaj=sen->l.size()-1;
     while(temp->l[0]!=nullptr&&etaj>=0){
            if(!temp->l[etaj] || val <= temp->l[etaj]->val){
				if(temp->l[etaj]&&temp->l[etaj]->val==val)return val;
                etaj--;
            }
            else if(val > temp->l[etaj]->val){
                temp=temp->l[etaj];
                while(!temp->l[0]&&etaj>=0){//ultimul
                    etaj--;
                }
            }
        }
        if(temp->l[0]&&temp->l[0]->val!=val)return temp->l[0]->val;
        else return temp->l[0]->l[0]->val;
}
int main()
{
    Nod* sentinel= new Nod;
    sentinel->val=0;
    sentinel->l.push_back(nullptr);
    srand (time(NULL));
    long n,x,val,f;
    in >> n;
    for(int i=1;i<=n;i++){
        in >> x;
        switch(x){
            case 1:
                in >> val;
                add(val,sentinel);
                break;
            case 2:
                in >> val;
                del(val,sentinel);
                break;
            case 3:
                in >> val;
                out << (isIn(val,sentinel) ? 1 : 0) << "\n";
                break;
            case 4:
                in >> val;
                out << maiMic(val,sentinel) << "\n";
                break;
            case 5:
                in >> val;
                out << maiMare(val,sentinel) << "\n";
                break;
            case 6:
                in >> val >> f;
                print(val,f,sentinel);
                break;
        }

    }
    return 0;
}
