#include <iostream>
#include <fstream>
#include <random>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

struct Nod{
    int valoare, prioritate;
    Nod *st, *dr;
};

Nod* creare_nod(int x){
    Nod* nod = new Nod;
    nod->valoare = x;
    nod->prioritate = rand();
    nod->st = nod->dr = NULL;
    return nod;
}

Nod* rot_dr(Nod* n)
{
    Nod* m = n->st;
    n->st = m->dr;
    m->dr = n;
    return m;
}

Nod* rot_st(Nod* n)
{
    Nod* m = n->dr;
    n->dr = m->st;
    m->st = n;
    return m;
}

Nod* inserare(Nod* nod, int x)
{
    if(nod == NULL)
        return creare_nod(x);
    if(nod->valoare == x)
        return nod;
    else
    {
        if(x < nod->valoare)
        {
            nod->st = inserare(nod->st, x);
            if(nod->prioritate < nod->st->prioritate)
                nod = rot_dr(nod);
        }
        else
        {
            nod->dr = inserare(nod->dr, x);
            if(nod->prioritate < nod->dr->prioritate)
                nod = rot_st(nod);
        }
    }
    return nod;
}

bool exista(Nod* nod, int x)
{
    if(nod == NULL)
        return 0;
    if(nod->valoare == x)
        return 1;
    if(x < nod->valoare)
        return exista(nod->st, x);
    return exista(nod->dr, x);
}

Nod* stergere(Nod* nod, int x)
{
    if(!nod)
        return nod;
    if(x < nod->valoare)
        nod->st = stergere(nod->st, x);
    else if(x > nod->valoare)
        nod->dr = stergere(nod->dr, x);
    else if(!nod->st || !nod->dr)
    {
        Nod* aux = (nod->st ? nod->st : nod->dr);
        delete nod;
        nod = aux;
    }
    else if(nod->st->prioritate > nod->dr->prioritate)
    {
        nod = rot_dr(nod);
        nod->dr = stergere(nod->dr, x);
    }
    else
    {
        nod = rot_st(nod);
        nod->st = stergere(nod->st, x);
    }
    return nod;
}
/*
Nod* maxim(Nod* rad)
{
    while(rad->dr)
        rad = rad->dr;
    return rad;
}

Nod* minim(Nod* rad)
{
    while(rad->st)
        rad = rad->st;
    return rad;
}*/

int succesor(Nod* rad, int x)
{
    if(rad == NULL)
        return 1000000000;
    if(rad->valoare < x)
        return succesor(rad->dr, x);
    if(rad->valoare < succesor(rad->st, x))
        return rad->valoare;
    return succesor(rad->st, x);
}

int predecesor(Nod* rad, int x)
{
    if(rad == NULL)
        return -1000000000;
    if(rad->valoare > x)
        return predecesor(rad->st, x);
    if(rad->valoare > predecesor(rad->dr, x))
        return rad->valoare;
    return predecesor(rad->dr, x);
}


void inordine_interval(Nod* rad, int st, int dr)
{
    if(rad == NULL)
        return;
    inordine_interval(rad->st, st, dr);
    if(rad->valoare >= st && rad->valoare <= dr)
        g << rad->valoare << ' ';
    inordine_interval(rad->dr, st, dr);
}

int main()
{int nr, op, x, i, st, dr;
Nod* nod = NULL;
f >> nr;
for(i = 0; i < nr; i++)
{
    f >> op;
    if(op == 1)
    {
        f >> x;
        nod = inserare(nod, x);
    }
    else if(op == 2)
    {
        f >> x;
        nod = stergere(nod, x);
    }
    else if(op == 3)
    {
        f >> x;
        g << exista(nod, x) << '\n';
    }
    else if(op == 4)
    {
        f >> x;
        g << predecesor(nod, x) << '\n';
    }
    else if(op == 5)
    {
        f >> x;
        g << succesor(nod, x) << '\n';
    }
    else
    {
        f >> st >> dr;
        inordine_interval(nod, st, dr);
        g << '\n';
    }
}
return 0;
}
