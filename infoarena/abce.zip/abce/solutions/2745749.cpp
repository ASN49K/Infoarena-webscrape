
#include <bits/stdc++.h>
#pragma GCC optimize("O3")

#define nozerous(x) (x & -x)
#define MOD 1000000007
#define M_PI           3.14159265358979323846
#define EPS 0.0001
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int INF = (1 << 30), NMAX(1005);
using VI  = vector<int>;
using VVI = vector<VI>;
using VB  = vector<bool>;
using Point = array<int, 2>;
using ll = long long;

void BUNA(const string& task = "")
{
    if (!task.empty())
        freopen((task + ".in").c_str(), "r", stdin),
                freopen((task + ".out").c_str(), "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
}
void PA()
{
    exit(0);
};

struct Treap{
    int key, prior;
    Treap *l, *r;
};
Treap* nill = new Treap{0, 0, nill, nill};
void split(Treap * t, int key, Treap * &l, Treap * &r){
    if(t == nill)
        l = r = nill;
    else if(key < t->key)
        split(t->l, key, l, t->l), r = t;
    else split(t->r, key, t->r, r), l = t;
}
void insert(Treap * &t, Treap * it){
    if(t == nill)
        t = it;
    else if(it->prior > t->prior)
        split(t, it->key, it->l, it->r), t = it;
    else insert(it->key < t->key ? t->l : t->r, it);
}
void merge(Treap * &t, Treap *l, Treap *r){
    if(l == nill || r == nill)
        t = (l != nill ? l : r);
    else if(l->prior > r->prior)
        merge(l->r, l->r, r), t = l;
    else merge(r->l, l, r->l), t = r;
}
void erase(Treap * &t, int key){
    if(t->key == key){
        Treap *th = t;
        merge(t, t->l, t->r);
        delete th;
    }
    else erase(key < t->key ? t->l : t->r, key);
}
bool search(Treap *t, int key){
    if(t == nill)
        return 0;
    if(t->key == key)
        return 1;
    if(t->key > key)
        return search(t->l, key);
    return search(t->r, key);
}
Treap* getMaxi(Treap *t, int key){
    if(t == nill)
        return nill;
    if(t->key > key)
        return getMaxi(t->l, key);
    Treap *ans = getMaxi(t->r, key);
    if(ans != nill)
        return ans;
    return t;
}
Treap* getMini(Treap *t, int key){
    if(t == nill)
        return nill;
    if(t->key < key)
        return getMini(t->r, key);
    Treap *ans = getMini(t->l, key);
    if(ans != nill)
        return ans;
    return t;
}
void print(Treap * t, int x, int y){
    if(t == nill)
        return;
    print(t->l, x, y);
    if(t->key >= x && t->key <= y)
        cout << t->key << ' ';
    print(t->r, x, y);
}

Treap* root = nill;

int main()
{
    BUNA("abce");
    int q;
    cin >> q;

    while(q--){
        int tip, x;
        cin >> tip >> x;

        if(tip == 1){
            Treap *aux = new Treap{x, rng(), nill, nill};
            insert(root, aux);
        }

        else if(tip == 2){
            if(search(root, x))
                erase(root, x);
        }
        else if(tip == 3)
            cout << search(root, x) << '\n';
        else if(tip == 4)
            cout << getMaxi(root, x)->key << '\n';
        else if(tip == 5)
            cout << getMini(root, x)->key << '\n';
        else{
            int y;
            cin >> y;
            print(root, x, y);
            cout << '\n';
        }
    }
    PA();
}
