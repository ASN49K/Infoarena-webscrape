#include <iostream>
#include <fstream>
using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");

struct node {
    int key;
    node *left, *right;
};

node* createNode(int key){
    node *newNode = new node;
    newNode->key = key;
    newNode->left = newNode->right = NULL;
    return newNode;
}

node* leftRotate(node* root){
    //salvez subarborele din dreapta radacinii
    node* RightNode = root->right;

    //subarborele din stanga nodului din dreapta al radacinii devine subarborele drept al radacinii
    root->right = RightNode->left;

    //radacina devine nodul din stanga al subarborelui drept
    RightNode->left = root;

    //returnez noua radacina dupa rotatie (adica nodul din dreapta radacinii)
    return RightNode;
}

node* rightRotate(node* root){
    //salvez subarborele din stanga radacinii
    node* LeftNode = root->left;

    //subarborele din dreapta nodului din stanga al radacinii devine subarborele stang al radacinii
    root->left = LeftNode->right;

    //radacina devine nodul din dreapta al subarborelui stang
    LeftNode->right = root;

    //returnez noua radacina dupa rotatie (adica nodul din stanga radacinii)
    return LeftNode;
}


void print(node* root){
    if(root){
        cout << root->key << endl;
        cout << "Arbore stang nodul " << root->key<<endl;
        print(root->left);
        cout << "Arbore drept nodul " << root->key<<endl;
        print(root->right);
    }
}

//functia splay -> efectueaza rotatii in arbore a.i. sa puna key in radacina
node* splay(node* root, int key){
    //daca radacina = NULL sau vrem sa dam splay pe ea, nu e nevoie sa facem splay
    if (!root || root->key == key) return root;

    //daca radacina e mai mare decat key, cautam in subarborele stang
    if (root->key > key){
        //daca nodul din stanga radacinii e null, returnam radacina deoarece key nu se afla in arbore
        if(!root->left) return root;

        //zig-zig rotation
        if(root->left->key >key){
            //recursiv, folosim tot splay pana aducem key ca radacina al subarborelui left-left
            root->left->left = splay(root->left->left, key);
            //prima rotatie, zig
            root = rightRotate(root);
        }

        //zig-zag rotation
        else if (root->left->key < key){
            //recursiv, folosim tot splay pana aducem key ca radacina al subarborelui left-right
            root->left->right = splay(root->left->right, key);
            //prima rotatie, zag
            if (root->left->right)
                root->left = leftRotate(root->left);
        }

        //a doua rotatie, zig
        return (!root->left) ? root : rightRotate(root);
    }

    //daca radacina e mai mica decat key, cautam in subarborele stang
    else{
        //daca nodul din dreapta radacinii e null, returnam radacina deoarece key nu se afla in arbore
        if(!root->right) return root;

        //zag-zig rotation
        if(root->right->key > key){
            //recursiv, folosim tot splay pana aducem key ca radacina al subarborelui right-left
            root->right->left = splay(root->right->left, key);
            //prima rotatie, zig
            if(root->right->left)
                root->right = rightRotate(root->right);
        }

        //zag-zag rotation
        else if (root->right->key < key){
            //recursiv, folosim tot splay pana aducem key ca radacina al subarborelui right-right
            root->right->right = splay(root->right->right, key);
            //prima rotatie, zag
            root = leftRotate(root);
        }

        //a doua rotatie, zag
        return (!root->right) ? root : leftRotate(root);
    }
    return root;
}

void search(node* root, int key){
    if (!root){
        out << 0 << "\n";
        return;
    }
    node* temp1 = root;
    node* temp2 = NULL;
    while (temp1){
        temp2 = temp1;
        if (key < temp1->key) temp1 = temp1->left;
        else if (key > temp1->key) temp1 = temp1->right;
        else {
            out << 1 << "\n";
            return;
        }
    }
    out << 0 << "\n";
}

node* insert(node* root, int key){
    if (!root) {
        root = createNode(key);
        return root;
    }

    root = splay(root,key);

    if (root->key==key) return root;

    node* temp = root;
    node* y = NULL;
    while (temp != NULL) {
        y = temp;
        if (key < temp->key) temp = temp->left;
        else temp = temp->right;
    }
    if (y->key > key) y->left = createNode(key);
    else y->right = createNode(key);

    return root;
}

node* remove(node* root, int key) {
    if (!root) return root;
    root = splay(root, key);
    if (key != root->key) return root;

    node* temp;
    if (!root->left){
        temp = root->right;
    }
    else {
        temp = splay(root->left, key);
        temp->right = root->right;
    }

    delete root;
    return temp;
}

int biggestY(node* root, int X) {
    if (!root) return -1;

    node* maxn = NULL;
    while (root) {
        if (root->key <= X) {
            maxn = root;
            root = root->right;
        } else {
            root = root->left;
        }
    }

    if (!maxn) return -1;
    return maxn->key;
}

int smallestY(node* root, int X){
    if (!root) return -1;

    node* minn = NULL;
    while (root) {
        if (root->key >= X) {
            minn = root;
            root = root->left;
        } else {
            root = root->right;
        }
    }

    if (!minn) return -1;
    return minn->key;
}

void orderInterval(node* root, int X, int Y) {
    if (!root) return;
    if (root->key >= X && root->key <= Y){
        orderInterval(root->left, X, Y);
        out << root->key << " ";
        orderInterval(root->right, X, Y);
    } else if (root->key < X){
        orderInterval(root->right, X, Y);
    } else {
        orderInterval(root->left, X, Y);
    }
}

void Interval(node* root, int X, int Y) {
    if (!root) return;
    if (root->key > Y) orderInterval(root->left, X, Y);
    else if (root->key < X) orderInterval(root->right, X, Y);
    else {
        orderInterval(root->left, X, Y);
        out << root->key << " ";
        orderInterval(root->right, X, Y);
    }
}

int Q, type, X, Y;
int main()
{

    node* root = NULL;
    in >> Q;
    for (int i = 0; i < Q; i++){
        in >> type >> X;
        // cout << "Operatia " << i+1 << ", tipul " << type << endl;
        switch (type){
            case 1:
                    root = insert(root, X);
                    // print(root);
                    // cout << "\n\n";
            break;
            case 2:
                    root = remove(root, X);
                    // print(root);
                    // cout << "\n\n";
            break;
            case 3: search(root, X);
                    // print(root);
                    // cout << "\n\n";
            break;
            case 4: out << biggestY(root, X) << "\n";
                    // print(root);
                    // cout << "\n\n";
            break;
            case 5: out << smallestY(root, X) << "\n";
                    // print(root);
                    // cout << "\n\n";
            break;
            case 6: in >> Y;
                    Interval(root, X, Y);
                    out << "\n";
                    // print(root);
                    // cout << "\n\n";
            break;
        }
    }
    in.close();
    out.close();
    return 0;
}
