#include <bits/stdc++.h>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

int Val[100005],St[100005],Dr[100005];
unsigned Prio[100005];
int NrNoduri=0;

mt19937 rng(1337);

int NodNou(int x){
    NrNoduri++;
    Val[NrNoduri]=x;
    Prio[NrNoduri]=rng();
    St[NrNoduri]=0;
    Dr[NrNoduri]=0;
    return NrNoduri;
}

void Split(int rad,int x,int &a,int &b){
    if(rad==0){
        a=0;
        b=0;
        return;
    }

    if(Val[rad]<=x){
        Split(Dr[rad],x,Dr[rad],b);
        a=rad;
    }
    else{
        Split(St[rad],x,a,St[rad]);
        b=rad;
    }
}

int Merge(int a,int b){
    if(a==0)
        return b;
    if(b==0)
        return a;

    if(Prio[a]>Prio[b]){
        Dr[a]=Merge(Dr[a],b);
        return a;
    }
    else{
        St[b]=Merge(a,St[b]);
        return b;
    }
}

int Insereaza(int rad,int x){
    int a,b,mij;
    Split(rad,x,a,b);
    Split(a,x-1,a,mij);

    if(mij==0)
        mij=NodNou(x);

    return Merge(Merge(a,mij),b);
}

int Sterge(int rad,int x){
    int a,b,mij;
    Split(rad,x,a,b);
    Split(a,x-1,a,mij);

    return Merge(a,b);
}

bool Exista(int &rad,int x){
    int a,b,mij;
    Split(rad,x,a,b);
    Split(a,x-1,a,mij);

    bool rasp=(mij!=0);

    rad=Merge(Merge(a,mij),b);
    return rasp;
}

int Predecesor(int &rad,int x){
    int a,b;
    Split(rad,x,a,b);

    int nod=a;
    while(Dr[nod]!=0)
        nod=Dr[nod];

    int rasp=Val[nod];

    rad=Merge(a,b);
    return rasp;
}

int Succesor(int &rad,int x){
    int a,b;
    Split(rad,x-1,a,b);

    int nod=b;
    while(St[nod]!=0)
        nod=St[nod];

    int rasp=Val[nod];

    rad=Merge(a,b);
    return rasp;
}

void Afisare(int rad){
    if(rad==0)
        return;

    Afisare(St[rad]);
    fout<<Val[rad]<<" ";
    Afisare(Dr[rad]);
}

int main(){
    int q;
    fin>>q;

    int Rad=0;

    while(q--){
        int Tip,x,y;
        fin>>Tip>>x;

        if(Tip==1)
            Rad=Insereaza(Rad,x);
        else if(Tip==2)
            Rad=Sterge(Rad,x);
        else if(Tip==3)
            fout<<Exista(Rad,x)<<"\n";
        else if(Tip==4)
            fout<<Predecesor(Rad,x)<<"\n";
        else if(Tip==5)
            fout<<Succesor(Rad,x)<<"\n";
        else if(Tip==6){
            fin>>y;

            int a,b,c;
            Split(Rad,y,a,c);
            Split(a,x-1,a,b);

            Afisare(b);
            fout<<"\n";

            Rad=Merge(Merge(a,b),c);
        }
    }

    return 0;
}
