/*https://www.geeksforgeeks.org/splay-tree-set-1-insert/
https://www.geeksforgeeks.org/splay-tree-set-2-insert-delete/
https://www.geeksforgeeks.org/splay-tree-set-3-delete/?ref=rp*/

#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct Node{
    int value;
    Node* right;
    Node* left;
};

Node* emptyNode;

Node* add(int val){
    Node* nod = new Node;
    nod->value = val;
    nod->right = nod->left = NULL;
    return nod;
}

Node* rightRotate(Node* A){
    Node* B = A->left;
    A->left = B->right;
    B->right = A;
    return B;
}

Node* leftRotate(Node* A){
    Node* B = A->right;
    A->right = B->left;
    B->left = A;
    return B;
}

Node* splay(Node* root, int val){

    if(root == NULL || root -> value == val)
        return root;

    if(root -> value > val){
        ///zig-zig -> 2 rotatii la dreapta
        if(root -> left == NULL)
            return root;
        if(root -> left -> value > val){

            root -> left -> left = splay(root -> left -> left, val);
            root = rightRotate(root);
        }
        ///zig-zag -> stanga apoi dreapta
        else if(root -> left -> value < val){
            root -> left -> right = splay(root -> left -> right, val);
            if(root -> left -> right != NULL)
                root -> left = leftRotate(root -> left);
        }
        if(root -> left !=NULL)
            return rightRotate(root);
        return root;
    }
    else{

        if(root -> right == NULL)
            return root;
        ///zig-zig -> 2 rotatii la stanga
        if(root -> right -> value < val){
            root -> right -> right = splay(root -> right -> right, val);
            root = leftRotate(root);
        }
        ///zag-zig -> dreapta apoi stanga
        else if(root -> right -> value > val){
                root -> right -> left = splay(root -> right -> left, val);
                if(root -> right -> left != NULL)
                    root -> right = rightRotate(root -> right);
        }
        if(root -> right != NULL)
            return leftRotate(root);
        else return root;
    }
}

Node* searchValue(Node* root,int k){
    root = splay(root, k);
    return root;
}

Node* insertValue(Node* root, int k){
    Node* node;
    if(root == NULL)
    {
        return add(k);
    }
    root = searchValue(root, k);
    if(root -> value == k)
        return root; ///valoare e deja in splay
    ///dupa searchValue avem valoarea cea mai apropiata de k in root
    node = add(k);
    if( k > root -> value){
        node -> left = root;
        node -> right = root -> right;
        root -> right = NULL;
        root = node;
    }
    else{
        node -> left = root -> left;
        node -> right = root;
        root -> left = NULL;
        root = node;
    }
    return root;
}

Node* removeValue(Node* root, int k){
    Node* maximLeft;
    Node* parent;
    if(root == emptyNode)
        return root;
    root = searchValue(root, k);
    if(root -> value !=k)
        return root;
    ///cautam maximul de pe subarborele stang
    if(root -> value == k && root -> left == NULL && root -> right == NULL)
        return emptyNode;
    if(root -> left == NULL)
        return root -> right;
    parent = root;
    maximLeft = root -> left;
    while(maximLeft -> right != NULL)
    {
        parent = maximLeft;
        maximLeft = maximLeft -> right;
    }
    parent -> right = NULL;
    maximLeft -> left = root -> left;
    maximLeft -> right = root -> right;
    delete root;
    return maximLeft;

}

Node* predecessor(Node* root, int k){

    Node* maxLeft;
    root = searchValue(root, k);
    if(root -> value <= k)
        return root;
    if(root -> left == NULL)
        return root;
    maxLeft = root -> left;
    while(maxLeft -> right != NULL)
        maxLeft = maxLeft -> right;
    return root;
}

Node* successor(Node* root, int k){

    Node* maxRight;
    root = searchValue(root, k);
    if(root -> value >= k)
        return root;
    if(root -> right == NULL)
        return root;
    maxRight = root -> right;
    while(maxRight -> left != NULL)
        maxRight = maxRight -> left;
    return root;
}

void inorder(Node* root, int x, int y){
    if(root == NULL)
        return;
    if(root -> value >= x)
        inorder(root -> left, x, y);
    if(root -> value >= x && root -> value <= y)
        fout << root -> value << " ";
    if( root -> value <= y)
        inorder(root -> right, x, y);
}

void solve(){
    Node* root;
    emptyNode = root;
    int q,x,y,c;
    fin >> q;
    for(int i = 0; i<q; ++i){
        fin >> c;
        switch (c){
            case 1:
                fin >> x;
                root = insertValue(root, x);
                break;
            case 2:
                fin >> x;
                root = removeValue(root, x);
                break;
            case 3:
                fin >> x;
                if(root == emptyNode)
                    fout << 0 << "\n";
                else{
                    root = searchValue(root,x);
                    fout << (root -> value == x) << "\n";
                }
                break;
            case 4:
                fin >> x;
                root = predecessor(root, x);
                fout << root -> value << "\n";
                break;
            case 5:
                fin >> x;
                root = successor(root, x);
                fout << root -> value << "\n";
                break;
            case 6:
                fin >> x >> y;
                inorder(root, x, y);
                fout << "\n";
                break;
            default:
                break;
        }
    }
}

int main()
{
    solve();
    return 0;
}
