#include <bits/stdc++.h>

using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");

struct treap
{
	int key;
	int priority;

	treap *l,*r;

	treap(int key,int priority,treap *l,treap *r) {
		this->key=key;
		this->priority=priority;
		this->l=l;
		this->r=r;
	}
};

treap *root,*null;

void L(treap* &n)
{
	treap *aux=n->l;
	n->l=aux->r;
	aux->r=n;
	n=aux;
}

void R(treap* &n)
{
	treap *aux=n->r;
	n->r=aux->l;
	aux->r=n;
	n=aux;
}

void balance(treap* &n)
{
	if(n->l->priority > n->priority)
		L(n);
	else if(n->r->priority >n->priority)
		R(n);
}

void insert(treap* &n,int key,int priority)
{
	if(n==null)
	{
		n=new treap(key,priority,null,null);
		return;
	}
	if(key<n->key)
		insert(n->l,key,priority);
	else if(key>n->key)
		insert(n->r,key,priority);
	balance(n);
}


void erase(treap* &n,int key)
{
	if(n==null) return;
	if(key<n->key) erase(n->l,key);
	else if(key>n->key) erase(n->r,key);
	else
	{	
		if(n->l==null && n->r==null)
			n=null;
		else
		{
			if(n->l->priority>n->r->priority)
				L(n);
			else R(n);
			erase(n,key);
		}
	}
}


int a4(treap* n,int key)
{
	if(n==null) return INT_MIN;
	if(n->key>key) return a4(n->l,key);
	return max(n->key,a4(n->r,key));
}

int a5(treap* n,int key)
{
	if(n==null) return INT_MAX;
	if(n->key<key) return a5(n->r,key);
	return min(n->key,a5(n->l,key));
}

void a6(treap* n, int x, int y)
{
	if (n==null) return;
	if (n->key<x) a6(n->r,x,y);
 	else if (n->key>y) a6(n->l,x,y);
    else
	{
        	a6(n->l,x,y);
        	out<<n->key<<" ";
        	a6(n->r,x,y);
   	}
}
bool search(treap *nod,int key)
{
	if(nod==null) return false;
	if(nod->key==key) return true;
	if(key<nod->key) return search(nod->l,key);
	return search(nod->r,key);
}
int main()
{ 
	srand(unsigned(time(0)));
	root=null=new treap(0,0,NULL,NULL);
	int q;
	in>>q;
	while(q--)
	{
		int cod,x,y;
		in>>cod>>x;
		if(cod==1)  insert(root,x,rand()+1);
		if(cod==2)  
			if(search(root,x))
				erase(root,x);
		if(cod==3) out<<search(root,x)<<"\n";
		if(cod==4)  out<<a4(root,x)<<"\n";
		if(cod==5)  out<<a5(root,x)<<"\n";
		if(cod==6) 
		{
			in>>y;
			a6(root,x,y);
			out<<"\n";
		}
	}
	return 0;
}
