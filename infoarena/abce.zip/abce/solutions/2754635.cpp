#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");


class btree_node{
public:
    int nr_keys;
    vector<int> keys;
    vector<btree_node*> children;
    bool leaf;

    btree_node(int t, bool le){
        nr_keys=0;
        keys.resize(2*t-1, 0);
        children.resize(2*t , nullptr);
        leaf = le;
    }

    void insert(int val, int t);
    bool search(int val);
    void remove(int val);
    int predecessor(int val);
    int successor(int val);

    void children_fusion(int i); /// left child's index
    int min_tree(); ///the min of the current (sub)tree
    int max_tree(); ///the max of the current (sub)tree
    void sorted_between(int st, int dr);
};

int btree_node::min_tree() {
    if(this->leaf)
        return keys[0];
    return children[0]->min_tree();
}
int btree_node::max_tree() {
    if(this->leaf)
        return keys[nr_keys-1];
    return children[nr_keys]->max_tree();
}

//// after insert in child check if child is filled;
void btree_node::insert(int val, int t) {
    int i=0;
    while(i<nr_keys && val > keys[i])
        ++i;
    if(this->leaf)
    {
        for(int j=nr_keys; j>i; --j)
        {
            keys[j] = keys[j-1];
        }
        keys[i] = val;
        ++nr_keys;
    }
    else{

        auto y = children[i];
        if(y->nr_keys == 2*t-1) ///divide child
        {
            ///  create new child z from 2nd half of child y
            auto z = new btree_node(t, y->leaf);

            for(int j=0;j<t-1;++j)
            {
                z->keys[j] = y->keys[t+j];
                z->children[j] = y->children[t+j]; y->children[t+j] = nullptr;
            }
            z->children[t-1] = y->children[2*t-1]; y->children[2*t-1] = nullptr;
            z->nr_keys=t-1;
            y->nr_keys=t-1;
            /// update myself-> shift keys and children with index>i to the right by 1
            for(int j=nr_keys; j>i; --j)
            {
                keys[j] = keys[j-1];
                children[j+1] = children[j];
            }
            ///z becomes the right brother of y
            children[i+1] = z;
            keys[i] = y->keys[t-1]; /// former key was shifted and now replaced with the median of former y;
            ++nr_keys;

            if(val<keys[i])
                y->insert(val, t);
            else
                z->insert(val, t);
        }
        else
            y->insert(val,t);
    }

}

bool btree_node::search(int val) {

    int i=0;
    while(i<nr_keys && val > keys[i])
        ++i;
    if(i<nr_keys && val == keys[i])
        return true;
    if(leaf)
        return false;
    return children[i]->search(val);
}

void btree_node::children_fusion(int i) {

    auto y = children[i];/// t-1 keys;
    auto z = children[i+1];/// t-1 keys;
    y->keys[y->nr_keys] = keys[i];
    y->nr_keys++; ///y->nr_keys = t

    for(int j=0; j<z->nr_keys; ++j)
    {
        y->keys[y->nr_keys +j] = z->keys[j];
        y->children[y->nr_keys +j] = z->children[j];
    }

    y->nr_keys += z->nr_keys; /// same as += t-1;
    y->children[y->nr_keys] = z->children[z->nr_keys]; /// last child of z becomes the last child of y;

    delete z; /// removed former right child of val;

    --nr_keys; /// current node lost a key; shift the following keys to the left by 1 position;
    for(;i<nr_keys ;++i)
    {
        keys[i] = keys[i+1];
        children[i+1] = children[i+2];
    }

}

void btree_node::remove(int val) {
    int i=0;
    while(i<nr_keys && val>keys[i])
        ++i;
    if(this->leaf) ///if this is a leaf and I found the element I just remove it;
    {
        if(i<nr_keys && keys[i] == val)
        {
            --nr_keys;
            for(int j=i; j<nr_keys; ++j)
                keys[j] = keys[j+1];
        }
    }
    else
    {
        int t = (int)children.size() / 2; /// I just realized I can get the value of t in function this way
        /// instead of sending another parameter to the function.....
        ///////////////////////////////////////////////
        if(children[i]->nr_keys == 0)
        {
            auto z= children[i]->children[0];
            delete children[i];
            children[i]=z;
        }
        ///////////////////////////////////////////
        if(i<nr_keys && val == keys[i]) /// val is in a non-leaf node;
        {
            if(children[i]->nr_keys > t-1) /// if I have enough elements to the left
            {                              /// I can take the max of the subtree to replace val and then remove that max from the subtree;
                keys[i] = children[i]->max_tree();
                children[i]->remove(keys[i]);
            }
            else if(children[i+1]->nr_keys > t-1)  /// analog; taking min from right subtree of val
            {
                keys[i] = children[i+1]->min_tree();
                children[i+1]->remove(keys[i]);
            }
            else ///fuse left and right children then remove val from the updated child
            {
                this->children_fusion(i);
                children[i]->remove(val);
            }
        }
        else
        {                                                                                 /// it shouldn't have less than that......
            if(children[i]->nr_keys <= t-1) /// if the root of the subtree containing val has t-1 keys (it can't have less than that)
            {                               /// removing val may end up reducing the nr of keys below t-1 in the root of that subtree
                                            /// so this is more of a precaution to ensure the subtree can later on fix itself;
                if(i>0 && children[i-1]->nr_keys>t-1) ///try to borrow from the left brother of the node, if there is one
                {
                    children[i]->insert(keys[i-1], t); ///
                    keys[i-1] = children[i-1]->max_tree();
                    children[i-1]->remove(keys[i-1]);

                    children[i]->remove(val);
                }
                else if(i<nr_keys && children[i+1]->nr_keys>t-1) /// try to borrow from right brother of the node, if there is one
                {
                    children[i]->insert(keys[i], t);
                    keys[i] = children[i+1]->min_tree();
                    children[i+1]->remove(keys[i]);

                    children[i]->remove(val);
                }
                else /// can't borrow, I have to fuse the child with one of his brothers
                {
                    if(i==nr_keys) /// val may be in the last child; fuse with his left brother and remove val from new last child
                    {
                        ///somehow there is an i=0 here; -> nr_keys = 0..... hmmmmmmmm
                        ///if(i==0)
                        ///children[0]->print();
                        ///
                        /// a node with 0 keys and 1 child and is not the root; the child is a leaf
                        /// the node is the last child of another node;
                        /// it looks to be a split or smthing; there are 2 values in his child which  =t-1 in this case;
                        ///
                        ///if(i==0)
                        ///    cout<<children[0]->leaf;
                        ///
                        /// right most split or remove seems to not work properly;
                        this->children_fusion(i-1);
                        children[nr_keys]->remove(val);
                    }
                    else
                    {
                        this->children_fusion(i); /// fuses the with his right brother
                        children[i]->remove(val);
                    }

                }
            }
            else
                children[i]->remove(val);
        }

    }


}

int btree_node::successor(int val) {
    int i=0;
    while(i<nr_keys && val>keys[i])
        ++i;
    if(i == nr_keys)
    {
        if(this->leaf)
            return INT32_MAX; /// there is no succesor in this leaf; return dummy value;
        return  children[nr_keys]->successor(val); /// not a leaf; val > all the keys
                                                /// -> search in last child which also has keys>this->keys[nr_keys-1]
    }
    if(val == keys[i] || this->leaf) /// found the val -> he is his own successor;
        return keys[i];             /// if leaf there is no better candidate than the first key>val

    /// val<keys[i] and not a leaf -> the successor of val is either keys[i]
    /// or the successor of val in children[i] (if there is one);
    int s = children[i]->successor(val); // the successor found in the subtree;
    /// if there was no successor, s = INT32_MAX > keys[i] ;
    /// otherwise s is smaller than keys[i];
    return min(s, keys[i]);
}

int btree_node::predecessor(int val) {

    int i=nr_keys-1;
    while(i>=0 && val<keys[i])
        --i;
    if(i==-1)   ///every key>val;
    {
        if(this->leaf) /// leaf node -> there is no predecessor;
            return INT32_MIN;
        return children[0]->predecessor(val); /// not a leaf node; val<keys[0] but children[0] also has keys<this-keys[0]
    }
    if(val == keys[i] || this->leaf)/// found the val -> he is his own predecessor;
        return keys[i];    /// or this is a leaf and keys[i] is the largest key < val <=> predecessor of val in this leaf
    /// val>keys[i] and not a leaf -> the predecessor of val is either keys[i]
    /// or the predecessor of val in children[i+1] (if there is one); (this->keys[i] <keys in children[i+1] < this->keys[i+1])
    /// val < this->keys[i+1]
    int p = children[i+1]->predecessor(val);
    /// if there was no predecessor, s = INT32_MIN < keys[i] ;
    /// otherwise s is bigger than keys[i] because s was found in children[i+1];
    return max(p, keys[i]);
}

void btree_node::sorted_between(int st, int dr) {
    int i=0,j=nr_keys-1;

    while(i<nr_keys && keys[i]<st)
        ++i;
    while(j>=0 && keys[j]>dr)
        --j;
    if(this->leaf)
    {
        for(; i<=j;++i) /// not out of range because i>=0 and j<nr_keys=1 no matter what;
                g<<keys[i]<<' ';
        /// i>j -> st>dr no x with st<x<dr;
    }
    else
    {
        if(i == nr_keys) /// there is no key>=st here
            children[nr_keys]->sorted_between(st, dr);
        else
        {
            if(j == -1) /// there is no key<=dr here
                children[0]->sorted_between(st, dr);
            else /// there is at leas 1 key; st<=key<=dr;
            {

                if(keys[i]>st) /// there may be keys >= st in children[i];
                    children[i]->sorted_between(st, dr); /// else keys[i] = st so the is no smaller key to print;
                for(;i<j; ++i)
                {
                    g<<keys[i]<<' ';
                    children[i+1]->sorted_between(st,dr);
                }

                g<<keys[j]<<' ';
                if(keys[j]<dr) /// there may be keys <= dr in children[j+1];
                    children[j+1]->sorted_between(st,dr); /// else dr = keys[j] so there is no bigger key to print;
            }
        }
    }
}



//////////////////////////////////////////////////////////////
class btree{
    const int t;
    btree_node* root;

public:
    explicit btree(int t):t(t), root(nullptr){};
    void insert(int val);
    bool search(int val);
    void remove(int val);
    int successor(int val);
    int predecessor(int val);

    void sorted_between(int st, int dr);

};

void btree::insert(int val) {
    if(root == nullptr){
        root = new btree_node(t, true);
        root->nr_keys = 1;
        root->keys[0] = val;
    }
    else{
        if(root->nr_keys == 2*t-1) /// The root doesn't have a father so I have to do the split for it
        {
            auto z=new btree_node(t, root->leaf);
            auto new_root = new btree_node(t, false);

            for(int j=0;j<t-1;++j)
            {
                z->keys[j] = root->keys[t+j];
                z->children[j] = root->children[t+j]; root->children[t+j] = nullptr;
            }
            z->children[t-1] = root->children[2*t-1]; root->children[2*t-1] = nullptr;
            z->nr_keys = t-1;
            root->nr_keys = t-1;

            new_root->nr_keys = 1;
            new_root->keys[0] = root->keys[t-1]; /// median of former root
            new_root->children[0] = root;
            new_root->children[1] = z;

            root = new_root;
        }
        root->insert(val, t);
    }
}

bool btree::search(int val) {
    if(root!= nullptr)
        return root->search(val);
    return false;
}

void btree::remove(int val) {
    if(root!= nullptr)
    {
        root->remove(val);
        if(root->nr_keys==0 && root->children[0]!= nullptr)/// the root only had 1 key and 2 children that had to fuse
        {
            auto new_root = root->children[0];
            delete root;
            root = new_root;
        }
    }

}

int btree::successor(int val) {
    return root->successor(val);
}
int btree::predecessor(int val) {
    return root->predecessor(val);
}

void btree::sorted_between(int st, int dr) {
    root->sorted_between(st, dr);
    g<<'\n';
}

int main() {

    btree tree(100);
    int q, i, opt, x, y;
    f>>q;
    for(i=1;i<=q;++i)
    {
        f>>opt>>x;
        if(opt == 1)
            tree.insert(x);
        else if(opt == 2)
        {
            if (tree.search(x))
                tree.remove(x);
        }
        else if(opt == 3)
            g<<tree.search(x)<<'\n';
        else if(opt == 4)
            g<<tree.predecessor(x)<<'\n';
        else if(opt == 5)
            g<<tree.successor(x)<<'\n';
        else
        {
            f>>y;
            tree.sorted_between(x,y);
        }
    }
    return 0;
}
