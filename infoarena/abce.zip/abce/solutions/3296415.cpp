#include <iostream>
#include <vector>
#include <ctime>
#include <fstream>
#include <cstdlib>
using namespace std;

const int max_levels = 25;
ifstream fin("abce.in");
ofstream fout("abce.out");

class Node {
public:
    int data;
    vector<Node*> next;
    Node(int data, int Level): data(data), next(Level + 1, nullptr) {}
};

class SkipList {
private:
    Node *head;
    int Level;
public:
    SkipList() {
        head = new Node(0, max_levels);
        Level = 0;
        srand(time(0));
    }

    void insert(int data) {
        int newLevel = 0;
        while (newLevel < max_levels && (rand()%2) == 1) {
            newLevel++;
        }
        if (Level < newLevel) {
            head->next.resize(newLevel + 1, nullptr);
            Level = newLevel;
        }
        Node* current = head;
        vector<Node*> Update(Level+1, nullptr);

        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data < data) {
                current = current->next[i];
            }
            Update[i] = current;
        }

        current = current->next[0];
        if (current == nullptr || current->data != data) {
            Node *newNode = new Node(data, newLevel);
            for (int i = 0; i <= newLevel; i++) {
                newNode->next[i] = Update[i]->next[i];
                Update[i]->next[i] = newNode;
            }
        }
    }

    void remove(int data) {
        Node* current = head;
        vector<Node*> Update(Level+1, nullptr);

        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data < data) {
                current = current->next[i];
            }
            Update[i] = current;
        }

        current = current->next[0];

        if (current && current->data == data) {
            for (int i = 0; i <= Level; i++) {
                if (Update[i]->next[i] != current)
                    break;
                Update[i]->next[i] = current->next[i];
            }
            delete current;
            while (Level > 0 && head->next[Level] == nullptr) {
                Level--;
            }
        }
    }

    bool search(int data) {
        Node* current = head;
        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data < data) {
                current = current->next[i];
            }
        }
        current = current->next[0];
        return (current && current->data == data);
    }

    void after_data(int data) {
        Node* current = head;
        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data <= data) {
                current = current->next[i];
            }
        }
        if (current->data >= data) {
            fout << current->data << '\n';
        } else if (current->next[0]) {
            fout << current->next[0]->data << '\n';
        } else {
            fout << "nu exista";
        }
    }

    void before_data(int data) {
        Node* current = head;
        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data < data) {
                current = current->next[i];
            }
        }
        if (current != head) {
            fout << current->data << '\n';
        } else {
            fout << "nu exista";
        }
    }

    void numbers_between(int x, int y) {
        Node* current = head;
        for (int i = Level; i >= 0; i--) {
            while (current->next[i] && current->next[i]->data < x) {
                current = current->next[i];
            }
        }
        current = current->next[0];

        bool found = false;
        while (current && current->data <= y) {
            if (current->data >= x) {
                fout << current->data << ' ';
                found = true;
            }
            current = current->next[0];
        }

        if (!found) {
            fout << "Nu exista valori in interval";
        }
        fout << '\n';
    }
};

int main() {

    int nr_op, op, data, x, y;
    SkipList s;

    fin >> nr_op;
    for (int i = 0; i < nr_op; i++) {
        fin >> op;
        if (op == 1) {
            fin >> data;
            s.insert(data);
        }
        else if (op == 2) {
            fin >> data;
            s.remove(data);
        }
        else if (op == 3) {
            fin >> data;
            fout << (s.search(data) ? 1 : 0) << '\n';
        }
        else if (op == 4) {
            fin >> data;
            s.before_data(data);
        }
        else if (op == 5) {
            fin >> data;
            s.after_data(data);
        }
        else if (op == 6) {
            fin >> x >> y;
            s.numbers_between(x, y);
        }
    }

    fin.close();
    fout.close();
    return 0;
}