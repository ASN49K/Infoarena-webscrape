#include <iostream>
#include <fstream>
std::ifstream fin("abce.in");
std::ofstream fout("abce.out");

class BST{
    private:
        struct Node{
            int val;
            Node* left;
            Node* right;
            int height;
            Node(int x){
                val = x;
                left = nullptr;
                right = nullptr;
                height = 1;
            }
        };

        Node* root;

        void addHelper(Node* &root, int x){
            if(root == nullptr){
                root = new Node(x);
            } else {
                if(x < root->val) {
                    addHelper(root->left, x);
                } else {
                    addHelper(root->right, x);
                }
            }
            balance(root);
        }

        bool searchHelper(Node* root, int x){
            if(root == nullptr){
                return false;
            } else {
                if(x == root->val) {
                    return true;
                } else {
                    if(x < root->val){
                        return searchHelper(root->left, x);
                    } else {
                        return searchHelper(root->right, x);
                    }
                }
            }
        }

        void deleteHelper(Node* &root, int x){
            if(root != nullptr){
                if(x < root->val){
                    deleteHelper(root->left, x);
                } else {
                    if(x > root->val){
                        deleteHelper(root->right, x);
                    } else {
                        if(root->left == nullptr && root->right == nullptr){
                            Node* temp = root;
                            root = nullptr;
                            delete temp;
                        } else {
                            if(root->left != nullptr && root->right == nullptr){
                                Node* temp = root;
                                root = root->left;
                                delete temp;
                            } else {
                                if(root->left == nullptr && root->right != nullptr){
                                    Node* temp = root;
                                    root = root->right;
                                    delete temp;
                                } else {
                                    Node* pred = root->left;
                                    while(pred->right != nullptr){
                                        pred = pred->right;
                                    }
                                    std::swap(root->val, pred->val);
                                    deleteHelper(root->left, pred->val);
                                }
                            }
                        }
                    }
                }
            }
            balance(root);
        }

        int getHeight(Node* n){
            if(n == nullptr) return 0;
            return n->height;
        }

        int getBalanceFactor(Node* n){
            return getHeight(n->left) - getHeight(n->right);
        }

        void updateHeight(Node* n){
            if(getHeight(n->left) > getHeight(n->right)) n->height = 1 + getHeight(n->left);
            else n->height = 1 + getHeight(n->right);
        }

        void rotateRight(Node* &n){
            Node* newRoot = n->left;
            n->left = newRoot->right;
            newRoot->right = n;
            updateHeight(n);
            updateHeight(newRoot);
            n = newRoot;
        }

        void rotateLeft(Node* &n){
            Node* newRoot = n->right;
            n->right = newRoot->left;
            newRoot->left = n;
            updateHeight(n);
            updateHeight(newRoot);
            n = newRoot;
        }

        void rotateRightLeft(Node* &n){
            rotateRight(n->right);
            rotateLeft(n);
        }

        void rotateLeftRight(Node* &n){
            rotateLeft(n->left);
            rotateRight(n);
        }

        void balance(Node* &n){
            if(n == nullptr) return;
            updateHeight(n);
            int bf = getBalanceFactor(n);
            if(bf == 2){
                if(getBalanceFactor(n->left) >= 0)
                    rotateRight(n);
                else
                    rotateLeftRight(n);
            }
            if(bf == -2){
                if(getBalanceFactor(n->right) <= 0)
                    rotateLeft(n);
                else
                    rotateRightLeft(n);
            }
        }

        int smallerHelper(Node* root, int x){
            if(root == nullptr) return -1000000001;
            if(root->val == x) return x;
            if(x < root->val) return smallerHelper(root->left, x);
            int res = smallerHelper(root->right, x);
            return (res == -1000000001) ? root->val : res;
        }

        int greaterHelper(Node* root, int x){
            if(root == nullptr) return 1000000001;
            if(root->val == x) return x;
            if(x > root->val) return greaterHelper(root->right, x);
            int res = greaterHelper(root->left, x);
            return (res == 1000000001) ? root->val : res;
        }

        void rangeHelper(Node* root, int x, int y){
            if(root == nullptr) return;
            rangeHelper(root->left, x, y);
            if(root->val >= x && root->val <= y) fout << root->val << ' ';
            rangeHelper(root->right, x, y);
        }

    public:
        BST(){
            root = nullptr;
        }

        void add(int x){
            addHelper(root, x);
        }

        bool search(int x){
            return searchHelper(root, x);
        }

        void del(int x){
            deleteHelper(root, x);
        }

        int printSmaller(int x){
            return smallerHelper(root, x);
        }

        int printGreater(int x){
            return greaterHelper(root, x);
        }

        void printRange(int x, int y){
            rangeHelper(root, x, y);
        }
};

int main(){
    BST tree;
    int Q, op, x, y;
    fin >> Q;
    while(Q--){
        fin >> op >> x;
        switch(op){
            case 1: {
                tree.add(x);
                break;
            }
            case 2: {
                tree.del(x);
                break;
            }
            case 3: {
                fout << tree.search(x) << '\n';
                break;
            }
            case 4: {
                fout << tree.printSmaller(x) << '\n';
                break;
            }
            case 5: {
                fout << tree.printGreater(x) << '\n';
                break;
            }
            case 6: {
                fin >> y;
                tree.printRange(x, y);
                fout << '\n';
                break;
            }
        }
    }
    fin.close();
    fout.close();
    return 0;
}