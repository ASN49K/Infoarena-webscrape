#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct Nod{
    int valoare, prioritate;
    Nod* stanga;
    Nod* dreapta;

    Nod(int val){
        valoare = val;
        prioritate = rand();
        stanga = nullptr;
        dreapta = nullptr;
    }
};
Nod* radacina = nullptr;

bool cautare(int n){
    Nod* prezent = radacina;
    while(prezent){
        if(prezent->valoare == n){
            return 1;
        }
        else if(n > prezent->valoare){
            prezent = prezent->dreapta;
        } else{
            prezent = prezent->stanga;
        }
    }
    return 0;
}

void rotatie(Nod* &n){
    if(n->stanga && n->prioritate < n->stanga->prioritate){
        Nod* copil = n->stanga;
        Nod* mijloc = copil->dreapta;
        n->stanga = mijloc;
        copil->dreapta = n;
        n = copil;
    } else if(n->dreapta && n->prioritate < n->dreapta->prioritate){
        Nod* copil = n->dreapta;
        Nod* mijloc = copil->stanga;
        n->dreapta = mijloc;
        copil->stanga = n;
        n = copil;
    }
}

void inserare(Nod* &n, int val){
    if(n == nullptr){
        n = new Nod(val);
        return;
    } else if(val > n->valoare){
        inserare(n->dreapta, val);
    } else if(val < n->valoare){
        inserare(n->stanga, val);
    }
    rotatie(n);
}

int predecesor(int x){
    Nod* n = radacina;
    int max;
    bool gasit=0;
    while(n){
        if(n->valoare > x){
            n = n->stanga;
        } else{
            max = n->valoare;
            gasit = 1;
            n = n->dreapta;
        }
    }
    if(gasit == 1){
        return max;
    } else {
        return 0;
    }   
}

int succesor(int x){
    Nod* n = radacina;
    int min;
    bool gasit = 0;
    while(n){
        if(n->valoare < x){
            n = n->dreapta;
        } else {
            min = n->valoare;
            gasit = 1;
            n = n->stanga;
        }
    }
    if(gasit == 1){
        return min;
    } else{
        return 0;
    }
}

void rotatieDreapta(Nod* &n){  
        Nod* copil = n->stanga;
        Nod* mijloc = copil->dreapta;
        n->stanga = mijloc;
        copil->dreapta = n;
        n = copil;    
}

void rotatieStanga(Nod* &n){
        Nod* copil = n->dreapta;
        Nod* mijloc = copil->stanga;
        n->dreapta = mijloc;
        copil->stanga = n;
        n = copil;
}
void stergere(Nod* &n,int val){
    Nod* aux;
    if (n != nullptr){
        if(n->valoare > val){
            stergere(n->stanga, val);
        } else if (n->valoare < val){
            stergere(n->dreapta,val);
        } else {
            if(n->stanga==nullptr && n->dreapta==nullptr){
                delete(n);
                n=nullptr;
            } else if(n->stanga && n->dreapta==nullptr){
                aux=n;
                n=n->stanga;
                delete(aux);
            } else if(n->stanga==nullptr && n->dreapta){
                aux=n;
                n=n->dreapta;
                delete(aux);
            } else if(n->stanga && n->dreapta){
                if(n->stanga->prioritate > n->dreapta->prioritate){
                    rotatieDreapta(n);
                    stergere(n->dreapta,val);
                } else {
                    rotatieStanga(n);
                    stergere(n->stanga,val);
                }
            }
        }
    } else return ;
}

void interval(Nod* n, int x, int y){
    if(n == nullptr){
        return ;
    }
    if(n->valoare > x ){
        interval(n->stanga,x,y);
    } 
    if(n->valoare >= x && n->valoare <= y){
        fout<<n->valoare <<" " ; 
    } 
    if( n->valoare < y) {
        interval(n->dreapta,x,y);
    }       
}

int main(){
    int q,tip,x,y;
    fin>>q;
    for(int i=1;i<=q;i++){
        fin>>tip;
        if(tip == 1){
            fin>>x;
            inserare(radacina, x);
        } else if(tip == 2){
            fin>>x;
            stergere(radacina, x);
        } else if(tip == 3){
            fin>>x;
            fout<<cautare(x)<<endl;
        } else if(tip == 4){
            fin>>x;
            fout<<predecesor(x)<<endl;
        } else if(tip == 5){
            fin>>x;
            fout<<succesor(x)<<endl;
        } else if(tip == 6){
            fin>>x>>y;
            interval(radacina,x,y);
            fout<<endl;
        }
    }
    fin.close();
    fout.close();
}