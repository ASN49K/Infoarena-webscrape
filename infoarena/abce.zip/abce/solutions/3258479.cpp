#include <iostream>
#include <random>
#include <climits>
#include <fstream>
#include <sys/time.h>

std::ifstream in("abce.in");
std::ofstream out("abce.out");

#pragma once
#include <iostream>
#include <random>
#include <climits>

class Treap{
  struct Node{
    long int key;
    long long priority;
    Node *left, *right;

    Node(long int k, long long p) : key(k), priority(p), left(0), right(0) {}
  };

  Node* root;

  static std::random_device rd;
  static std::mt19937_64 gen;
  static std::uniform_int_distribution<long long> dist;

  long long generatePriority(){
    return Treap::dist(Treap::gen);
  }

  Node* innerSearch(Node* node, long int key){
    if(node == NULL)
      return NULL;

    if(node->key == key)
      return node;

    if(node->key > key)//go left
      return innerSearch(node->left, key);

    else//go right
      return innerSearch(node->right, key);
  }

  Node* rotateLeft(Node* root){
    Node* new_root = root->right;
    Node* beta = new_root->left;
    new_root->left = root;
    root->right = beta;
    return new_root;
  }

  Node* rotateRight(Node* root){
    Node* new_root = root->left;
    Node* beta = new_root->right;
    new_root->right = root;
    root->left = beta;
    return new_root;
  }

  Node* innerInsert(Node* root, long int key){
    if(root == NULL)
      root = new Node(key, generatePriority());

    else if(root->key > key){
      root->left = innerInsert(root->left, key);

      if(root->left->priority > root->priority)
        root = rotateRight(root);
    
    }else{
      root->right = innerInsert(root->right, key);
    
      if(root->right->priority > root->priority)
        root = rotateLeft(root);
    
    }

    return root;
  }

  Node* innerDelete(Node* root, long int key){
    if(root == NULL)
      return 0;
    
    if(root->key > key)
      root->left = innerDelete(root->left, key);
    else if(root->key < key)
      root->right = innerDelete(root->right, key);
    else if(root->left == NULL){
      Node* temp = root->right;
      delete(root);
      root = temp;
    }else if(root->right == NULL){
      Node* temp = root->left;
      delete(root);
      root = temp;
    }else if(root->left->priority < root->right->priority){
      root = rotateLeft(root);
      root->left = innerDelete(root->left, key);
    }else{
      root = rotateRight(root);
      root->right = innerDelete(root->right, key);
    }

    return root;
  }

  void innerPredecessor(Node* node, long int key, long int & predecessor){
    if(!node)
      return;

    if(node->key == key)
      predecessor = key;

    else if(node->key > key)
      innerPredecessor(node->left, key, predecessor);

    else{
      predecessor = node->key;
      innerPredecessor(node->right, key, predecessor);
    }
  }

  void innerSuccesor(Node* node, long int key, long int & succesor){
    if(!node)
      return;

    if(node->key == key)
      succesor = key;

    else if(node->key > key){
      succesor = node->key;
      innerSuccesor(node->left, key, succesor);
    }
    else
      innerSuccesor(node->right, key, succesor);
  }

  int innerPrintRange(Node* node, long int l, long int r){
    if(!node)
      return 0;

    int nLeft, nRight;

    if(l <= node->key && node->key <= r){
      innerPrintRange(node->left, l, r);
      printf("%ld ", node->key);
      innerPrintRange(node->right, l, r);
      return 1;
    }else if(node->key < l)
      return innerPrintRange(node->right, l, r);
  
    else
      return innerPrintRange(node->left, l, r);    
  }

  public:

  Treap() : root(0) {}

  void insert(long int key){
    root = innerInsert(root, key);
  }

  void remove(long int key){
    root = innerDelete(root, key);
  }

  int search(long int key){
    Node* node = innerSearch(root, key);
    if(node)
      return 1;
    return 0;
  }

  long int predecessor(long int key){
    long int rez = -1000000001;
    innerPredecessor(root, key, rez);
    return rez;
  }

  long int successor(long int key){
    long int rez = 1000000001;
    innerSuccesor(root, key, rez);
    return rez;
  }

  void printRange(long int l, long int r){
    if(innerPrintRange(root, l, r))
      printf("\n");
    else
      printf("%ld %ld\n", -1000000001, 1000000001);
  }

};

std::random_device Treap::rd;
std::mt19937_64 Treap::gen(Treap::rd());
std::uniform_int_distribution<long long> Treap::dist(0, LLONG_MAX);

int main()
{

	int _, op, x, y;

	in>>_;

	Treap t;

	do
	{
		in>>op>>x;
		switch(op)
		{
		case 1:
			t.insert(x);
			break;
		case 2:
      t.remove(x);
			break;
		case 3:
      out<<t.search(x)<<std::endl;
			break;
		case 4:
			out<<t.predecessor(x)<<std::endl;
			break;
		case 5:
			out<<t.successor(x)<<std::endl;
			break;
		case 6:
			in>>y;
			t.printRange(x, y);
      out<<std::endl;
			break;
		}
	}while(_-=1); // Altfel se vede ciudat si se copiaza gresit.

	return 0;
}