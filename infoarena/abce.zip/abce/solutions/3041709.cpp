#include <algorithm>
#include <cassert>
#include <fstream>
#include <random>
#include <ctime>

using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
mt19937 G;
uniform_int_distribution<int> u(1 , 1e9);
inline int getr(){return u(G);}
typedef struct item* pitem;
struct item{
    int val , pr;
    pitem l{nullptr} , r{nullptr};
    item(int _val) : val(_val) , pr(getr()){}
};
void split(pitem t , int x , pitem &l , pitem &r){
    if(!t){
        l = r = nullptr;
    }else if(t->val <= x){
        split(t->r , x , t->r , r) , l = t;
    }else{
        split(t->l , x , l , t->l) , r = t;
    }
}
void join(pitem &t , pitem l , pitem r){
    if(!l || !r){
        t = l ? l : r;
    }else if(l->pr > r->pr){
        join(l->r , l->r , r) , t = l;
    }else{
        join(r->l , l , r->l) , t = r;
    }
}
void bag(pitem &t , pitem it){
    if(!t){
        t = it;
    }else if(it->pr > t->pr){
        split(t , it->val , it->l , it->r) , t = it;
    }else{
        bag(t->val <= it->val ? t->r : t->l , it);
    }
}
void scot(pitem &t , int x){
    if(t->val == x){
        pitem it = t;
        join(t , t->l , t->r);
        delete it;
    }else{
        scot(t->val <= x ? t->r : t->l , x);
    }
}
bool findx(pitem t , int x){
    if(!t)return 0;
    if(t->val == x)
        return 1;
    return findx(t->val <= x ? t->r : t->l , x);
}
int max(pitem t){
    assert(t != nullptr);
    if(!t->r)return t->val;
    return max(t->r);
}
int min(pitem t){
    assert(t != nullptr);
    if(!t->l)return t->val;
    return min(t->l);
}
void out(pitem t){
    if(!t)return;
    out(t->l);
    fout << t->val << ' ';
    out(t->r);
}

int q , a , b , c;
int main(){
    G.seed(time(0));
    fin >> q;
    pitem rt = nullptr;
    while(q --){
        fin >> a >> b;
        if(a == 1){
            bag(rt , new item(b));
        }else if(a == 2){
            findx(rt , b) ? scot(rt , b) : void();
        }else if(a == 3){
            fout << findx(rt , b) << '\n';
        }else if(a == 4){
            pitem l , r;
            split(rt , b , l , r);
            fout << max(l) << '\n';
            join(rt , l , r);
        }else if(a == 5){
            pitem l , r;
            split(rt , b - 1 , l , r);
            fout << min(r) << '\n';
            join(rt , l , r);
        }else if(a == 6){
            fin >> c;
            pitem l{nullptr} , r{nullptr} , u{nullptr} , z{nullptr};
            split(rt , b - 1 , l , r);
            split(r , c , u , z);
            out(u);
            fout << '\n';
            join(r , u , z);
            join(rt , l , r);
        }
    }
    return 0;
}
