#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class Nod
{
public:
    int key;
    Nod* left;
    Nod* right;
    int height;

    Nod(int key=0)
    {
        this->key=key;
        this->left=NULL;
        this->right=NULL;
        this->height=1;
    }
};

int height(Nod* x)
{
    if(x == NULL) return 0;
    return x->height;
}

Nod* rightRotate(Nod *y)
{
    Nod* x= y->left;
    Nod* T2= x->right;

    x->right = y;
    y->left = T2;

    y->height= max(height(y->left), height(y->right)) + 1;
    x->height= max(height(x->left), height(x->right)) + 1;

    return x;
}

Nod* leftRotate(Nod* x)
{
    Nod *y = x->right;
    Nod *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left),height(x->right)) + 1;
    y->height = max(height(y->left),height(y->right)) + 1;

    return y;
}

int getBalance(Nod* x)
{
    if(x == NULL) return 0;
    return height(x->left) - height(x->right);
}

Nod* insert1(Nod* nod, int key)
{
    if(nod == NULL) return(new Nod(key));

    if(key< nod->key) nod->left = insert1(nod->left, key);
    else if(key > nod->key) nod->right = insert1(nod->right, key);
    else return nod;

    nod->height = 1 + max(height(nod->left),height(nod->right));

    int balance = getBalance(nod);

    if(balance > 1 && key < nod->left->key)
        return rightRotate(nod);

    if(balance < -1 && key > nod->right->key)
        return leftRotate(nod);

    if(balance > 1 && key > nod->left->key)
    {
        nod->left = leftRotate(nod->left);
        return rightRotate(nod);
    }

    if(balance < -1 && key < nod->right->key)
    {
        nod->right = rightRotate(nod->right);
        return leftRotate(nod);
    }

    return nod;
}

Nod* goLeft(Nod* root)
{
    if(root==NULL) return NULL;

    if(root->left != NULL)
        return goLeft(root->left);

    return root;
}

Nod* goRight(Nod* root)
{
    if(root==NULL) return NULL;
    if(root->right != NULL)
        return goRight(root->right);

    return root;
}

Nod* pred(Nod *root)
{
    if(root==NULL) return NULL;
    if(root->left != NULL) return goRight(root->left);
    else return root;
}

Nod* succ(Nod *root)
{
    if(root==NULL) return NULL;
    if(root->right != NULL) return goLeft(root->right);
    else return root;
}

bool cauta_n(Nod *root, int key)
{
    if(root == NULL) return 0;


    if(key < root->key) return cauta_n(root->left, key);
    else if(key > root->key) return cauta_n(root->right, key);
    else return 1;
}

void fix_height(Nod* nod)
{
    if(nod->left != NULL) fix_height(nod->left);
    if(nod->right != NULL) fix_height(nod->right);

    nod->height = 1 + max(height(nod->left),height(nod->right));
}

Nod* del_n(Nod *nod, int key)
{
    if(nod == nullptr) return nullptr;
    if(key < nod->key) nod->left = del_n(nod->left, key);
    else if(key > nod->key) nod->right = del_n(nod->right, key);
    else
    {
        Nod* x = NULL;
        if(nod->left != NULL && nod->right == NULL) x = nod->left;
        else if(nod->left == NULL && nod->right != NULL) x = nod->right;
        else if(nod->left != NULL && nod->right != NULL)
        {
            Nod *pr = pred(nod);
            Nod *fpr = nod;
            if(fpr->left != pr)
            {
                fpr = fpr->left;
                while(fpr->right != pr) fpr = fpr->right;

                fpr->right = pr->left;
                pr->left = nod->left;


            }
            pr->right = nod->right;
            x=pr;

            fix_height(pr);

        }

        delete nod;

        return x;


    }

    nod->height = 1 + max(height(nod->left),height(nod->right));

    int balance = getBalance(nod);

    if(balance > 1 && key < nod->left->key)
        return rightRotate(nod);

    if(balance < -1 && key > nod->right->key)
        return leftRotate(nod);

    if(balance > 1 && key > nod->left->key)
    {
        nod->left = leftRotate(nod->left);
        return rightRotate(nod);
    }

    if(balance < -1 && key < nod->right->key)
    {
        nod->right = rightRotate(nod->right);
        return leftRotate(nod);
    }

    return nod;

}

void preord(Nod* nod)
{
    if(nod != NULL)
    {
        fout<<nod->key<<" ";
        preord(nod->left);
        preord(nod->right);
    }
}

void inordxy(Nod* nod, int x, int y)
{
    if(nod != NULL)
    {

        inordxy(nod->left, x, y);
        if(nod->key >= x && nod->key <= y) fout<<nod->key<<" ";
        inordxy(nod->right, x, y);
    }
}

int cautaPredX(Nod* nod, int x)
{
    int k;
    if(nod == NULL) return x+1;

    if(x < nod->key) k = cautaPredX(nod->left, x);
    else if( x > nod->key ) k = cautaPredX(nod->right, x);
    else return x;

    if(nod->key <= x && (nod->key > k || k == x+1)) return nod->key;
    else return k;


}

int cautaSucX(Nod* nod, int x)
{
    int k;
    if(nod == NULL) return x-1;

    if(x < nod->key) k = cautaSucX(nod->left, x);
    else if( x > nod->key ) k = cautaSucX(nod->right, x);
    else return x;

    if(nod->key >= x && (nod->key < k || k == x-1)) return nod->key;
    else return k;
}




int main()
{
    int n, comanda, x, y;
    Nod* root = NULL;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>comanda;
        switch(comanda)
        {
        case 1:
            {
                fin>>x;
                root = insert1(root, x);
                break;
            }
        case 2:
            {
                fin>>x;
                root = del_n(root, x);
                break;
            }
        case 3:
            {
                fin>>x;
                fout<<cauta_n(root, x)<<"\n";
                break;
            }
        case 4:
            {
                fin>>x;
                fout<<cautaPredX(root, x)<<"\n";
                break;
            }
        case 5:
            {
                fin>>x;
                fout<<cautaSucX(root, x)<<"\n";
                break;
            }
        case 6:
            {
                fin>>x>>y;
                inordxy(root, x, y);
                fout<<"\n";
                break;
            }
        }
    }

    while(root != NULL)
        root = del_n(root, root->key);
}
