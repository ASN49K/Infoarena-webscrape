#include<fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class Nod{
public:
    int data;
    int h;
    Nod* stanga;
    Nod* dreapta;

    Nod(int d){
        data=d;
        h=1;
        stanga=NULL;
        dreapta=NULL;
    }
};

class AVL{
public:
    Nod* root;

    int get_maxim(Nod* nod){
        if(nod->dreapta != NULL)
            return get_maxim(nod->dreapta);

        return nod->data;
    }

    int balanta(Nod* nod){
        int b=0;
        if(nod!=NULL){
            if(nod->stanga != NULL)
                b=nod->stanga->h;
            if(nod->dreapta != NULL)
                b-=nod->dreapta->h;
        }
        return b;
    }

    Nod* rotire_dreapta(Nod* nod){
        Nod* nStanga = nod->stanga;
        Nod* nCentru = nStanga->dreapta;
        nStanga->dreapta=nod;
        nod->stanga=nCentru;
        update_h(nod);
        update_h(nStanga);
        return nStanga;
    }

    Nod* rotire_stanga(Nod* nod){
        Nod* nDreapta = nod->dreapta;
        Nod* nCentru = nDreapta->stanga;
        nDreapta->stanga=nod;
        nod->dreapta=nCentru;
        update_h(nod);
        update_h(nDreapta);
        return nDreapta;
    }

    void update_h(Nod* nod){
        int maxH = max(nod->stanga == NULL ? 0 : nod->stanga->h,nod->dreapta == NULL ? 0 : nod->dreapta->h);
        nod->h=maxH+1;
    }

    Nod* aplica_rotatie(Nod* nod){
        int b=balanta(nod);
        if(b>1){
            if(balanta(nod->stanga) < 0){
                nod->stanga=rotire_stanga(nod->stanga);
            }
            return rotire_dreapta(nod);
        }
        if(b<-1){
            if(balanta(nod->dreapta) > 0){
                nod->dreapta = rotire_dreapta(nod->dreapta);
            }
            return rotire_stanga(nod);
        }

        return nod;
    }

    Nod* inserare(int data, Nod* nod){
        if(nod==NULL)
            return new Nod(data);

        if(data < nod->data){
            nod->stanga=inserare(data, nod->stanga);
        }
        else if(data > nod->data){
            nod->dreapta=inserare(data, nod->dreapta);
        }
        else{
            return nod;
        }

        update_h(nod);
        return aplica_rotatie(nod);
    }

    Nod* sterge(int data, Nod* nod){
        if(nod==NULL){
            return NULL;
        }

        if(data<nod->data){
            nod->stanga=sterge(data, nod->stanga);
        }
        else if(data>nod->data){
            nod->dreapta=sterge(data, nod->dreapta);
        }
        else{
            if(nod->stanga == NULL)
                return nod->dreapta;
            else if(nod->dreapta == NULL)
                return nod->stanga;

            nod->data=get_maxim(nod->stanga);
            nod->stanga=sterge(nod->data, nod->stanga);
        }
        update_h(nod);
        return aplica_rotatie(nod);
    }


    int cauta(int data){
        Nod* nod = root;
        while(nod!=NULL){
            if(nod->data == data){
                return 1;
            }

            if(data<nod->data)
                nod=nod->stanga;
            else
                nod=nod->dreapta;
        }

        return 0;
    }

    Nod* cerinta4(int data, Nod* nod){
        if(nod==0){
            return 0;
        }

        if(nod->data == data){
            return nod;
        }

        if(nod->data < data){
            Nod* d = cerinta4(data, nod->dreapta);
            if(d==0)
                return nod;
            else
                return d;
        }

        return cerinta4(data, nod->stanga);
    }


    Nod* cerinta5(int data, Nod* nod){
        if(nod==0){
            return 0;
        }

        if(nod->data == data){
            return nod;
        }

        if(nod->data < data){
            return cerinta5(data, nod->dreapta);
        }
        else{
            Nod* d = cerinta5(data, nod->stanga);
            if(d==0)
                return nod;
            else
                return d;
        }
    }

    void inorder(Nod* nod, int x, int y){
        if(nod == NULL)
            return;

        inorder(nod->stanga, x, y);
        if(x<=nod->data && nod->data<=y)
            fout<<nod->data<<" ";
        inorder(nod->dreapta, x, y);
    }
};

int main(){
    AVL mlem;
    int q;
    fin>>q;
    for(int i=0;i<q;i++){
        int o,x,y;
        fin>>o;
        if(o==1){
            fin>>x;
            mlem.root=mlem.inserare(x, mlem.root);
        }
        else if(o==2){
            fin>>x;
            mlem.root=mlem.sterge(x, mlem.root);
        }
        else if(o==3){
            fin>>x;
            fout<<mlem.cauta(x)<<"\n";
        }
        else if(o==4){
            fin>>x;
            fout<<mlem.cerinta4(x, mlem.root)->data<<"\n";
        }
        else if(o==5){
            fin>>y;
            fout<<mlem.cerinta5(x, mlem.root)->data<<"\n";
        }
        else if(o==6){
            fin>>x>>y;
            mlem.inorder(mlem.root, x, y);
            fout<<"\n";
        }
    }

    return 0;
}
