#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

unsigned seedRandom = 123456789;

unsigned prioritateNoua() {
    seedRandom ^= seedRandom << 13;
    seedRandom ^= seedRandom >> 17;
    seedRandom ^= seedRandom << 5;
    return seedRandom;
}

struct Nod {
    int valoare;
    unsigned prioritate;
    Nod *stanga, *dreapta;

    Nod(int x) {
        valoare = x;
        prioritate = prioritateNoua();
        stanga = dreapta = nullptr;
    }
};

Nod* radacina = nullptr;

void rotireStanga(Nod* &nod) {
    Nod* aux = nod->dreapta;
    nod->dreapta = aux->stanga;
    aux->stanga = nod;
    nod = aux;
}

void rotireDreapta(Nod* &nod) {
    Nod* aux = nod->stanga;
    nod->stanga = aux->dreapta;
    aux->dreapta = nod;
    nod = aux;
}

void inserare(Nod* &nod, int x) {
    if (!nod) {
        nod = new Nod(x);
        return;
    }

    if (x < nod->valoare) {
        inserare(nod->stanga, x);

        if (nod->stanga->prioritate > nod->prioritate)
            rotireDreapta(nod);
    } else {
        inserare(nod->dreapta, x);

        if (nod->dreapta->prioritate > nod->prioritate)
            rotireStanga(nod);
    }
}

bool cautare(Nod* nod, int x) {
    while (nod) {
        if (nod->valoare == x)
            return true;

        if (x < nod->valoare)
            nod = nod->stanga;
        else
            nod = nod->dreapta;
    }

    return false;
}

void stergere(Nod* &nod, int x) {
    if (!nod)
        return;

    if (x < nod->valoare)
        stergere(nod->stanga, x);
    else if (x > nod->valoare)
        stergere(nod->dreapta, x);
    else {
        if (!nod->stanga && !nod->dreapta) {
            delete nod;
            nod = nullptr;
        }
    }
}

void afisareInterval(Nod* nod, int x, int y) {
    if (!nod)
        return;

    if (nod->valoare > x)
        afisareInterval(nod->stanga, x, y);

    if (x <= nod->valoare && nod->valoare <= y)
        fout << nod->valoare << ' ';

    if (nod->valoare < y)
        afisareInterval(nod->dreapta, x, y);
}

int main() {
    int q;
    fin >> q;

    while (q--) {
        int tip, x, y;
        fin >> tip >> x;

        if (tip == 1)
            inserare(radacina, x);
        else if (tip == 2)
            stergere(radacina, x);
        else if (tip == 3)
            fout << cautare(radacina, x) << '\n';
        else if (tip == 6) {
            fin >> y;
            afisareInterval(radacina, x, y);
            fout << '\n';
        }
    }

    return 0;
}
