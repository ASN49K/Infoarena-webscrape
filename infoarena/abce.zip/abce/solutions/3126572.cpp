#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("../abce.in");
ofstream g("../abce.out");
struct Nod {
    int valoare_nod;
    Nod* fiu_stanga;
    Nod* fiu_dreapta;

    Nod(int valoare_nod) {
        this->valoare_nod = valoare_nod;
        this->fiu_stanga = nullptr;
        this->fiu_dreapta = nullptr;
    }
};

class Arbore_binar {
public:
    Arbore_binar() {
        radacina = nullptr;
    }
    void inserare(int data) {
        radacina = _inserare(radacina, data);
    }
    void afisare() {
        _afisare(radacina);
        cout << endl;
    }
    void stergere(int data) {
        radacina = _stergere(radacina, data);
    }
    bool cautare(int valoare_nod){
        return _cautare(radacina,valoare_nod);
    }
    int cel_mai_mare_numar_mai_mic(int valoare_nod){
        return _cel_mai_mare_numar_mai_mic(valoare_nod);
    }
    int cel_mai_mic_numar_mai_mare(int valoare_nod){
        return _cel_mai_mic_numar_mai_mare(valoare_nod);
    }
    vector<int> interval(int x,int y){
        return _interval(radacina,x,y);
    }
private:
    Nod* radacina;
    vector<int> interval_nr;
    Nod* _inserare(Nod* nod, int data) {
        if (nod == nullptr) {
            nod = new Nod(data);
        }
        else if (data < nod->valoare_nod) {
            nod->fiu_stanga = _inserare(nod->fiu_stanga, data);
        }
        else if (data > nod->valoare_nod) {
            nod->fiu_dreapta = _inserare(nod->fiu_dreapta, data);
        }
        return nod;
    }

    void _afisare(Nod* nod) {
        if (nod == nullptr) {
            return;
        }
        _afisare(nod->fiu_stanga);
        cout << nod->valoare_nod << " ";
        _afisare(nod->fiu_dreapta);
    }

    Nod* _stergere(Nod* nod, int valoare_stearsa) {
        if (nod == nullptr) {
            return nod;
        }

        if (valoare_stearsa < nod->valoare_nod) {
            nod->fiu_stanga = _stergere(nod->fiu_stanga, valoare_stearsa);
        }
        else if (valoare_stearsa > nod->valoare_nod) {
            nod->fiu_dreapta = _stergere(nod->fiu_dreapta, valoare_stearsa);
        }
        else {
            if (nod->fiu_stanga == nullptr) {
                Nod* temp = nod->fiu_dreapta;
                delete nod;
                return temp;
            }
            else if (nod->fiu_dreapta == nullptr) {
                Nod* temp = nod->fiu_stanga;
                delete nod;
                return temp;
            }

            Nod* temp = nod_minim(nod->fiu_dreapta);
            nod->valoare_nod = temp->valoare_nod;
            nod->fiu_dreapta = _stergere(nod->fiu_dreapta, temp->valoare_nod);
        }
        return nod;
    }

    Nod* nod_minim(Nod* nod) {
        Nod* nod_actual = nod;
        while (nod_actual && nod_actual->fiu_stanga != nullptr) {
            nod_actual = nod_actual->fiu_stanga;
        }
        return nod_actual;
    }
    bool _cautare(Nod* radacina,int valoare_nod){
        Nod* nod_actual = radacina;
        while (nod_actual != nullptr) {
            if (nod_actual->valoare_nod == valoare_nod) {
                return 1;
            }
            else if (nod_actual->valoare_nod > valoare_nod) {
                nod_actual = nod_actual->fiu_stanga;
            }
            else {
                nod_actual = nod_actual->fiu_dreapta;
            }
        }
        return 0;
    }
    int _cel_mai_mare_numar_mai_mic(int valoare_nod) {
        Nod* nod_actual = radacina;
        int numar = -1;
        while (nod_actual != nullptr) {
            if (nod_actual->valoare_nod < valoare_nod) {
                numar = nod_actual->valoare_nod;
                nod_actual = nod_actual->fiu_dreapta;
            }
            else {
                nod_actual = nod_actual->fiu_stanga;
            }
        }
        return numar;
    }
    int _cel_mai_mic_numar_mai_mare(int valoare_nod) {
        Nod* nod_actual = radacina;
        int numar = -1;
        while (nod_actual != nullptr) {
            if (nod_actual->valoare_nod < valoare_nod) {
                nod_actual = nod_actual->fiu_dreapta;
            }
            else {

                numar = nod_actual->valoare_nod;
                nod_actual = nod_actual->fiu_stanga;
            }
        }
        return numar;
    }
    vector<int> _interval(Nod* radacina,int x,int y){

        if(radacina== nullptr){
            return interval_nr;
        }
        if(radacina->valoare_nod>=x && radacina->valoare_nod<=y)
            interval_nr.push_back(radacina->valoare_nod);
        if(radacina->valoare_nod>x)
            interval_nr=_interval(radacina->fiu_stanga,x,y);

        if(radacina->valoare_nod<y)
            interval_nr=_interval(radacina->fiu_dreapta,x,y);
        return interval_nr;
    }
};

int main() {
    Arbore_binar arboreBinar;
    int nr_cerinte, decizie,n;
    f >> nr_cerinte;
    for (int i = 0; i < nr_cerinte; i++) {
        f >> decizie;
        switch (decizie) {
            case 1: {
                f >> n;
                arboreBinar.inserare(n);
                break;
            }
            case 2: {
                f >> n;
                arboreBinar.stergere(n);
                break;
            }
            case 3: {
                f >> n;
                g << arboreBinar.cautare(n)<<endl;
                break;
            }
            case 4:{
                f>>n;
                g << arboreBinar.cel_mai_mare_numar_mai_mic(n)<<endl;
                break;
            }
            case 5:{
                f>>n;
                g << arboreBinar.cel_mai_mic_numar_mai_mare(n)<<endl;
                break;
            }
            case 6:{
                int m,j;
                f>>m>>n;
                vector<int> interval_nr;
                interval_nr=arboreBinar.interval(m, n);
                for(auto j:interval_nr) {
                    g << j << " ";
                    cout << j << " ";
                }
                g<<endl;
                break;
            }
            default: {
                cout<<"Optiune inexistenta.";
                exit(1);
            }
        }
    }

    f.close();
    g.close();
    return 0;
}
