#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class node{

    int val;
    node* tata;
    node* fiu1;
    node* fiu2;

public:
    node();
    node(int a);
    node* getfiu1();
    node* getfiu2();
    node* gettata();
    int getval();
    void setfiu1(node* nod);
    void setfiu2(node* nod);
    void settata(node* nod);
    void setval(int a);
    ~node();

};

node::node(){
    this->val=0;
    tata=nullptr;
    fiu1=nullptr;
    fiu2=nullptr;
}

node::node(int a){
    this->val=a;
    tata=nullptr;
    fiu1=nullptr;
    fiu2=nullptr;
}

node* node::getfiu1(){
    return this->fiu1;
}

node* node::getfiu2(){
    return this->fiu2;
}

node* node::gettata(){
    return this->tata;
}

int node::getval(){
    return this->val;
}

void node::setfiu1(node* nod){
    this->fiu1=nod;
}
void node::setfiu2(node* nod){
    this->fiu2=nod;
}

void node::settata(node* nod){
    this->tata=nod;
}

void node::setval(int a){
    this->val=a;
}

node::~node(){
    this->val=0;
    this->fiu1=nullptr;
    this->fiu2=nullptr;
    this->tata=nullptr;
}


class Splaytree{

    node* radacina;

public:
    Splaytree();
    Splaytree(int x);
    void push(int x);
    void inorder();
    void preorder();
    void postorder();
    void splay(node* nod);
    node* getradacina();
    void right(node* nod);
    void left(node* nod);
    node* search(int x);
    bool remove(int x);
};

Splaytree::Splaytree(){
    this->radacina=nullptr;
}

Splaytree::Splaytree(int x){
    node * nod = new node(x);
    this->radacina=nod;
}

void Splaytree::push(int x){
    node* nod = new node(x);
    if(this->radacina==nullptr){
        this->radacina=nod;
    }
    else{
        node* act = this->radacina;
        while(act!=nullptr){
            nod->settata(act);
            if(act->getval() > x){
                act = act->getfiu1();
            }
            else{
                act = act->getfiu2();
            }
        }
        if(x > nod->gettata()->getval()){
            nod->gettata()->setfiu2(nod);
        }
        else{
            nod->gettata()->setfiu1(nod);
        }
    }
    splay(nod);
}

void Splaytree::right(node* nod){
    node* tata = nod->gettata();
    node* bunic = tata->gettata();
    if(tata == radacina){
        nod->settata(nullptr);
        radacina=nod;
    }
    else{
        nod->settata(bunic);
        if(bunic->getval() > tata->getval()){
            bunic->setfiu1(nod);
        }
        else{
            bunic->setfiu2(nod);
        }
    }
    if(nod->getfiu2() != nullptr){
        tata->setfiu1(nod->getfiu2());
        nod->getfiu2()->settata(tata);
    }
    else{
        tata->setfiu1(nullptr);
    }
    tata->settata(nod);
    nod->setfiu2(tata);
}

void Splaytree::left(node* nod){
    node* tata = nod->gettata();
    node* bunic = tata->gettata();
    if(tata == radacina){
        nod->settata(nullptr);
        radacina=nod;
    }
    else{
        nod->settata(bunic);
        if(bunic->getval() > tata->getval()){
            bunic->setfiu1(nod);
        }
        else{
            bunic->setfiu2(nod);
        }
    }
    if(nod->getfiu1() != nullptr){
        tata->setfiu2(nod->getfiu1());
        nod->getfiu1()->settata(tata);
    }
    else{
        tata->setfiu2(nullptr);
    }
    tata->settata(nod);
    nod->setfiu1(tata);
}

void Splaytree::splay(node* nod){
    while(nod != this->radacina){
        if(nod->gettata() == this->radacina){
            int x = this->radacina->getval();
            if(nod->getval() < x){
                right(nod);
            }
            else{
                left(nod);
            }
        }
        else{
            if(nod->gettata()->gettata()->getval() > nod->gettata()->getval()){
                if(nod->gettata()->getval() > nod->getval()){
                    right(nod);
                    right(nod);
                }
                else{
                    left(nod);
                    right(nod);
                }
            }
            else{
                if(nod->gettata()->getval() > nod->getval()){
                    right(nod);
                    left(nod);
                }
                else{
                    left(nod);
                    left(nod);
                }
            }
        }
    }
}

void inordine(node* nod){
    if(nod==nullptr){
        return;
    }
    inordine(nod->getfiu1());
    cout<<nod->getval()<<" ";
    inordine(nod->getfiu2());
}

void Splaytree::inorder(){
    inordine(this->radacina);
    cout<<"\n";
}

void preordine(node* nod){
    if(nod==nullptr){
        return;
    }
    cout<<nod->getval()<<" ";
    preordine(nod->getfiu1());
    preordine(nod->getfiu2());
}

void Splaytree::preorder(){
    preordine(this->radacina);
    cout<<"\n";
}

node* Splaytree::search(int x){
    node* nod = this->radacina;
    if(nod == nullptr){
        return nod;
    }
    while(nod != nullptr){
        if(nod->getval() == x){
            splay(nod);
            return nod;
        }
        if(x < nod->getval()){
            if(nod->getfiu1() == nullptr){
                splay(nod);
                return nullptr;
            }
            nod = nod->getfiu1();
        }
        else{
            if(nod->getfiu2() == nullptr){
                splay(nod);
                return nullptr;
            }
            nod = nod->getfiu2();
        }
    }
    return nullptr;
}

bool Splaytree::remove(int x){
    node* nod = this->search(x);
    if(nod == nullptr){
        return 0;
    }
    if(nod->getfiu1() == nullptr && nod->getfiu2() == nullptr){
        this->radacina = nullptr;
        delete nod;
        return 1;
    }
    if(nod->getfiu1() == nullptr){
        nod->getfiu2()->settata(nullptr);
        this->radacina = nod->getfiu2();
        delete nod;
        return 1;
    }
    node* act = nod->getfiu1();
    while(act->getfiu2() != nullptr){
        act = act->getfiu2();
    }
    this->radacina = nod->getfiu1();
    this->radacina->settata(nullptr);
    node* exfiu = nod->getfiu2();
    delete nod;
    splay(act);
    act->settata(nullptr);
    act->setfiu2(exfiu);
    this->radacina = act;
    return 1;
}

void postordine(node* nod){
    if(nod==nullptr){
        return;
    }
    postordine(nod->getfiu1());
    postordine(nod->getfiu2());
    cout<<nod->getval()<<" ";
}

void Splaytree::postorder(){
    postordine(this->radacina);
    cout<<"\n";
}

node* Splaytree:: getradacina(){
    return this->radacina;
}

ifstream in("abce.in");
ofstream out("abce.out");
int main(){
    int n, c;
    in>>n;
    Splaytree sp;
    for(int i=0; i<n; ++i){
        in>>c;
        if(c==1){
            int x;
            in>>x;
            sp.push(x);
        }
//        else if(c==2){
//            int x;
//            in>>x;
//            sp.remove(x);
//        }
        else if(c==3){
            int x;
            in>>x;
            node* nod = sp.search(x);
            if(nod==nullptr){
                out<<0<<'\n';
            }
            else{
                out<<1<<'\n';
            }
        }
    }
    return 0;
}
