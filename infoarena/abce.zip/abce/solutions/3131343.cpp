#include <iostream>
#include <fstream>
#include <set>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
struct node {
    int key;
    node *stanga,*dreapta;
    node* parinte;
};
node* newNode(int key) {
    node* t=new node;
    t->key=key;
    t->stanga=t->dreapta=nullptr;
    return t;
}
node* rightRotate(node* x) {
    node* y = x->stanga;
    x->stanga = y->dreapta;
    if (y->dreapta != nullptr) {
        y->dreapta->parinte = x;
    }
    y->dreapta = x;
    y->parinte = x->parinte;
    x->parinte = y;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->dreapta;
    x->dreapta = y->stanga;
    if (y->stanga != nullptr) {
        y->stanga->parinte = x;
    }
    y->stanga = x;
    y->parinte = x->parinte;
    x->parinte = y;
    return y;
}
node* splay(node* root, int key) {
    if(root == nullptr || root->key == key)
        return root;

    if(root->key > key) {
        if(root->stanga==nullptr)
            return root;
        if(root->stanga->key>key){
            root->stanga->stanga=splay(root->stanga->stanga,key);
            root=rightRotate(root);
        }
        else if(root->stanga->key<key){
            root->stanga->dreapta=splay(root->stanga->dreapta,key);
            if(root->stanga->dreapta != nullptr)
                root->stanga=leftRotate(root->stanga);
        }
        return (root->stanga == nullptr) ? root:rightRotate(root);
    }
    else {
        if(root->dreapta == nullptr)
            return root;
        if(root->dreapta->key>key){
            root->dreapta->stanga=splay(root->dreapta->stanga,key);
            if(root->dreapta->stanga != nullptr)
                root->dreapta=rightRotate(root->dreapta);
        }
        else if(root->dreapta->key<key){
            root->dreapta->dreapta=splay(root->dreapta->dreapta,key);
            root=leftRotate(root);
        }
        return(root->dreapta==nullptr) ? root:leftRotate(root);
    }
}
node* insert(node* root,int key){
    if(root==nullptr)
        return newNode(key);
    root=splay(root,key);
    if(root->key==key)
        return root;
    node* t=newNode(key);
    if(root->key>key){
        t->dreapta=root;
        t->stanga=root->stanga;
        root->stanga=nullptr;
    }
    else{
        t->stanga=root;
        t->dreapta=root->dreapta;
        root->dreapta=nullptr;
    }
    return t;
}
void search(node*& root, int key) {
    root = splay(root, key);
    if (root == nullptr || root->key != key) {
        fout << "0" << endl; // cheia nu a fost găsită
    } else {
        fout << "1" << endl; // cheia a fost găsită
        root = splay(root, key); // reasociem noului nod rădăcină
    }
}
node* deleteNode(node* root,int key) {
    if(root==nullptr)
        return root;
    root=splay(root,key);
    if(root->key!=key)
        return root;
    node *t;
    if (root->stanga == nullptr) {
        t=root->dreapta;
        delete(root);
        return t;
    }
    else{
        t=root->stanga;
        while(t->dreapta != nullptr)
            t=t->dreapta;
        t->dreapta=root->dreapta;
        node* newRoot=t;
        delete(root);
        return newRoot;
    }
}
set<int> setul;
void inOrderXY(node* root, int x, int y)
{

    if(root == nullptr) return;
    if(x < root->key) inOrderXY(root->stanga, x, y);
    if(x > root->key) inOrderXY(root->dreapta, x, y);

    if(root->key >= x && root->key <= y) setul.insert(root->key);

    if(y < root->key) inOrderXY(root->stanga, x, y);
    if(y > root->key) inOrderXY(root->dreapta, x, y);
}
void callInOrderXY(node* root, int x, int y)
{
    setul.clear();
    inOrderXY(root, x, y);
    for(auto it = setul.begin(); it != setul.end(); it++)
        fout<<*it<<" ";
    fout<<"\n";
}
void preorderTraversal(node* root){
    if(root!=nullptr) {
        fout<<root->key<<" ";
        preorderTraversal(root->stanga);
        preorderTraversal(root->dreapta);
    }
}
int findLargestY(node* root, int x) {
    int largestY = -1; // Valoarea inițială negativă înseamnă că nu există niciun număr Y mai mic sau egal cu X
    while (root != nullptr) {
        if (root->key <= x) {
            largestY = max(largestY, root->key);
            root = root->dreapta;
        } else {
            root = root->stanga;
        }
    }
    return largestY;
}
int findSmallestY(node* root, int x) {
    int smallestY = INT_MAX; // Valoarea inițială este MAX_INT pentru a găsi cel mai mic număr
    while (root != nullptr) {
        if (root->key >= x) {
            smallestY = min(smallestY, root->key);
            root = root->stanga;
        } else {
            root = root->dreapta;
        }
    }
    return (smallestY == INT_MAX) ? -1 : smallestY;
}
int main() {
    node* root = nullptr;
    int n, comanda, x, y;
    fin >> n;
    for (int i = 1; i <= n; i++) {
        fin >> comanda;
        switch (comanda) {
        case 1: {
            fin >> x;
            root = insert(root, x);
            break;
        }
        case 2: {
            fin >> x;
            root = deleteNode(root, x);
            break;
        }
        case 3: {
            fin >> x;
            search(root, x);
            break;
        }
        case 4: {
            fin >> x;
            int largestY = findLargestY(root, x);
            fout << largestY << "\n";
            break;
            }
        case 5: {
            fin >> x;
            int smallestY = findSmallestY(root, x);
            fout << smallestY << "\n";
            break;
}
        case 6: {
            fin >> x >> y;
            callInOrderXY(root, x, y);
            break;
        }
        default: {
            break;
        }
        }
    }
    fin.close();
    fout.close();
    return 0;
}
