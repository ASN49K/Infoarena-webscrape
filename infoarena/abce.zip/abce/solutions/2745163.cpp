#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("abce.in");
ofstream g ("abce.out");

class Node{
public:
    Node* parent = nullptr;
    long long data;
    Node* left = nullptr;
    Node* right = nullptr;


    Node(Node* parent, long long data);
    Node(long long data);
};

Node::Node(Node* parent, long long data): parent(parent), data(data)
{

}

Node::Node(long long data): data(data)
{

}

class SplayTree{
private:
    Node* root;

public:
    SplayTree();

    void insert(long long);
    void splay(Node*);
    void inorder(long long, long long, Node* node = nullptr);
    void rotate(Node*);
    void rotateRight(Node*);
    void rotateLeft(Node*);
    Node* findNode(long long value, Node* = nullptr);
    void remove(long long);
    Node* getBiggestInSubtree(Node*);
    Node* getSuccessor(Node*);
	Node* getPredecessor(Node*);
};

Node* SplayTree::getSuccessor(Node* node)
{
    if (node == nullptr)
        return nullptr;
    if (node->right != nullptr)
    {
        Node* curr_node = node->right;
        while (curr_node->left != nullptr)
            curr_node = curr_node->left;
        return curr_node;
    }
    else
    {
        Node* curr_node = node;
        while (curr_node->parent != nullptr)
        {
            if (curr_node->data >= node->data)
                return curr_node;
            curr_node = curr_node->parent;
        }
        return curr_node;
    }
}

Node* SplayTree::getPredecessor(Node* node)
{
    if (node == nullptr)
        return nullptr;
    if (node->left != nullptr)
    {
        Node* curr_node = node->left;
        while (curr_node->right != nullptr)
            curr_node = curr_node->right;
        return curr_node;
    }
    else
    {
        Node* curr_node = node;
        while (curr_node->parent != nullptr)
        {
            if (curr_node->data <= node->data)
                return curr_node;
            curr_node = curr_node->parent;
        }
        return curr_node;
    }
}

Node* SplayTree::getBiggestInSubtree(Node* node)
{
    if (node == nullptr)
    {
        return nullptr;
    }
    Node* curr = node;
    while (curr->right != nullptr)
    {
        curr = curr->right;
    }
    return curr;
}

void SplayTree::remove(long long value)
{
    if (this->root == nullptr)
        return;

    Node* node = this->findNode(value, this->root);

    if (node->data == value)
    {
        // no longer splaying here, we always splay when searching
        // now we remove the root
        if (this->root->left != nullptr)
        {
            if (this->root->left->right == nullptr)
            {
                // we just make left the root and connect its right child to the old right child of the old root
                this->root->left->right = this->root->right;
                if (this->root->right != nullptr)
                    this->root->right->parent = this->root->left;
                Node* old_root = this->root;
                this->root = this->root->left;
                this->root->parent = nullptr;
                delete old_root;
            }
            else
            {
                // store the right subtree
                Node* right_subtree = this->root->right;
                right_subtree->parent = nullptr;
                this->root->right = nullptr;
                // set the root to be the left subtree
                Node* old_root = this->root;
                this->root = this->root->left;
                this->root->parent = nullptr;
                delete old_root;
                // we make the root of the left subtree its biggets element and then we make it the root of the tree
                Node* biggest_in_left_subtree = this->getBiggestInSubtree(this->root);
                // we splay the biggest element we found in the subtree, so now the root wont have a right child
                this->splay(biggest_in_left_subtree);
                this->root->right = right_subtree;
                right_subtree->parent = this->root;
            }
        }
        else
        {
            if (this->root->right != nullptr)
            {
                // make right subtree the root
                this->root = this->root->right;
                delete this->root->parent;
                this->root->parent = nullptr;
            }
            else
            {
                // root had no children, we just remove it
                delete this->root;
                this->root = nullptr;
            }
        }
    }
    else
    {
        // we didnt find the value we looked for, we just splay the closest node
        this->splay(node);
    }
}

Node* SplayTree::findNode(long long value, Node* curr_node)
{
    if (this->root == nullptr)
        return nullptr;
    if (curr_node == nullptr)
        curr_node = this->root;
    if (curr_node->data == value)
    {
        this->splay(curr_node);
        return curr_node;
    }
    else
    {
        if (value < curr_node->data)
        {
            if (curr_node->left != nullptr
                && std::abs(curr_node->left->data - value) < std::abs(curr_node->data - value))
                return findNode(value, curr_node->left);
            else
            {
                this->splay(curr_node);
                return curr_node;
            }

        }
        else if (value > curr_node->data)
        {
            if (curr_node->right != nullptr
                && std::abs(curr_node->right->data - value) < std::abs(curr_node->data - value))
                return findNode(value, curr_node->right);
            else
            {
                this->splay(curr_node);
                return curr_node;
            }
        }
    }
}

void SplayTree::rotateRight(Node* node)
{
    Node* old_parent = node->parent;
    Node* old_right = node->right;

    old_parent->left = old_right;
    if (old_right != nullptr)
    {
        old_right->parent = old_parent;
    }

    if (old_parent->parent != nullptr)
    {
        node->parent = old_parent->parent;
        if (old_parent->parent->left == old_parent)
            old_parent->parent->left = node;
        else
            old_parent->parent->right = node;
    }
    else if (old_parent->parent == nullptr)
    {
        this->root = node;
        node->parent = nullptr;
    }

    node->right = old_parent;
    old_parent->parent = node;
}

void SplayTree::rotateLeft(Node* node)
{
    Node* old_parent = node->parent;
    Node* old_left = node->left;

    old_parent->right = old_left;
    if (old_left != nullptr)
    {
        old_left->parent = old_parent;
    }

    if (old_parent->parent != nullptr)
    {
        node->parent = old_parent->parent;
        if (old_parent->parent->left == old_parent)
            old_parent->parent->left = node;
        else
            old_parent->parent->right = node;
    }
    else if (old_parent->parent == nullptr)
    {
        this->root = node;
        node->parent = nullptr;
    }

    node->left = old_parent;
    old_parent->parent = node;
}

void SplayTree::rotate(Node* node)
{
    if (node->parent == nullptr)
        return;
    if (node->parent->left == node)
        this->rotateRight(node);
    else if (node->parent->right == node)
        this->rotateLeft(node);
}

void SplayTree::splay(Node* node)
{
        // if node is root do nothing
    if (node == this->root)
        return;
    // if node is child of root
    if (node->parent == this->root)
    {
        this->rotate(node);
    }
    else
    {
        // check if zig zig or zig zag
        int zig_count = 0;
        // check parent
        if (node->parent->left == node)
            zig_count += 1;
        else
            zig_count -= 1;
        // check grandparent
        if (node->parent->parent->left == node->parent)
            zig_count += 1;
        else
            zig_count -= 1;

        // if zig_count == 0 that meansa zig zag, else it means zag
        if (zig_count == 0)
        {
            this->rotate(node);
            //this->rotate(node->parent);
            this->splay(node);
        }
        else
        {
            this->rotate(node->parent);
            //this->rotate(node);
            this->splay(node);
        }
    }
}

SplayTree::SplayTree()
{
    this->root = nullptr;
}

void SplayTree::insert(long long val)
{
    Node* curr_node = root;

    // if root is null
    if (root == nullptr)
    {
        root = new Node(val);
        return;
    }

    //while (curr_node != nullptr)
    while (true)
    {
        if (val <= curr_node->data)
        {
            if (curr_node->left == nullptr)
            {
                Node* new_node = new Node(curr_node, val);
                curr_node->left = new_node;
                this->splay(new_node);
                return;
            }
            else
                curr_node = curr_node->left;
        }
        else if (val > curr_node->data)
        {
            if (curr_node->right == nullptr)
            {
                Node* new_node = new Node(curr_node, val);
                curr_node->right = new_node;
                this->splay(new_node);
                return;
            }
            else
                curr_node = curr_node->right;
        }
    }
}

void SplayTree::inorder(long long minim, long long maxim, Node* node)
{
    if (node == nullptr)
        node = this->root;

    if (node->left != nullptr)
        this->inorder(minim, maxim, node->left);

    if (node->data >= minim && node->data <= maxim)
        g << node->data << ' ';

    if (node->data <= maxim)
        if (node->right != nullptr)
            this->inorder(minim, maxim, node->right);
}

int main()
{
    int n;
    f >> n;

    SplayTree tree;

    for (int i = 0; i < n; i++)
    {
        long long tip, val, val2;
        f >> tip >> val;
        if (tip == 6)
            f >> val2;

        switch (tip)
        {
        case 1:
            tree.insert(val);
            break;
        case 2:
            tree.remove(val);
            break;
        case 3:
            {
                Node* found = tree.findNode(val);
                if (found == nullptr)
                {
                    g << 0 << '\n';
                    break;
                }
                if (found != nullptr && found->data != val)
                    g << 0 << '\n';
                if (found != nullptr && found->data == val)
                    g << 1 << '\n';
                break;
            }
        case 4:
            {
                Node* node_found = tree.findNode(val);
                if (node_found->data == val)
                    g << node_found->data << '\n';
                else
                {
                    g << tree.getPredecessor(node_found)->data << '\n';
                }
                break;
            }
        case 5:
            {
                Node* node_found = tree.findNode(val);
                if (node_found->data == val)
                    g << node_found->data << '\n';
                else
                {
                    g << tree.getSuccessor(node_found)->data << '\n';
                }
                break;
            }
        case 6:
            tree.inorder(val, val2);
            g << '\n';
            break;

        default:
            break;
        }
    }

    return 0;
}
