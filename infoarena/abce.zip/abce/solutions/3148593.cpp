#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <list>
#include <forward_list>
#include <cmath>
#include <algorithm>
#include <stack>
#include <queue>
#include <utility>

#define cin fin
#define cout fout

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct node
{
    int val, height;
    node *left, *right;

    void operator=(node& x)
    {
        this->val = x.val;
        this->height = x.height;
        this->left = x.left;
        this->right = x.right;
    }
};

class AVLTree
{
private:
    struct pairNodepRow;

    node makeNode(int val, int height, node* left, node* right);
    pairNodepRow makePairNodepRow(node* nodep, int row);

    node* createNode(int val);
    node* insert(node* nodep, int val, bool& inseration);
    void erase(node* nodep, int val, int& phase, bool& deletion, bool& deleteDirection, node& deleteNode);
    void print(node& node_, int row, int& lastRow);
    void rotateRight(node& x, node& father);
    void rotateLeft(node& x, node& father);
    void balanceNode(node& node_, node& father);
    int balance(node& node_);
    void updateNode(node& node_);
public:

    node* root;

    AVLTree();
    node* insert(int val);
    void erase(int val);
    node* find(int val);
    node* find(node& node_, int val);
    node* find(node& node_, int val, node*& father);
    void print();
};

void solveTest();
void dfsType6(node* node_, int x, int y);

int main()
{
    int q;
    AVLTree tree;

    cin >> q;

    for(int i = 0, type, x, y; i < q; i++)
    {
        cin >> type;

        if(type == 1)
        {
            cin >> x;
            tree.insert(x);
        }
        else if(type == 2)
        {
            cin >> x;
            tree.erase(x);
        }
        else if(type == 3)
        {
            cin >> x;
            cout << (tree.find(x) != NULL) << '\n';
        }
        else if(type == 4)
        {
            cin >> x;

            int answer = INT_MIN;
            node* node_ = tree.root;

            while(node_ != NULL)
            {
                if(node_->val <= x && node_->val > answer)
                {
                    answer = node_->val;
                }

                if(node_->val > x)
                {
                    node_ = node_->left;
                }
                else
                {
                    node_ = node_->right;
                }
            }

            cout << answer << '\n';
        }
        else if(type == 5)
        {
            cin >> x;

            int answer = INT_MAX;
            node* node_ = tree.root;

            while(node_ != NULL)
            {
                if(node_->val >= x && node_->val < answer)
                {
                    answer = node_->val;
                }

                if(node_->val < x)
                {
                    node_ = node_->right;
                }
                else
                {
                    node_ = node_->left;
                }
            }

            cout << answer << '\n';
        }
        else if(type == 6)
        {
            cin >> x >> y;

            node* start = tree.root;

            while(!(x <= start->val && start->val <= y))
            {
                if(start->val < x)
                {
                    start = start->right;
                }
                else if(start->val > y)
                {
                    start = start->left;
                }
            }

            dfsType6(start, x, y);

            cout << '\n';
        }
    }

    return 0;
}

void solveTest()
{

}
void dfsType6(node* node_, int x, int y)
{
    if(node_->left != NULL && node_->val > x)
    {
        dfsType6(node_->left, x, y);
    }
    
    if(x <= node_->val && node_->val <= y)
        cout << node_->val << ' ';

    if(node_->right != NULL && node_->val < y)
    {
        dfsType6(node_->right, x, y);
    }
}
struct AVLTree::pairNodepRow
{
    node* nodep;
    int row;
};
node AVLTree::makeNode(int val, int height, node* left, node* right)
{
    node temp;
    temp.val = val;
    temp.height = height;
    temp.left = left;
    temp.right = right;

    return temp;
}
AVLTree::pairNodepRow AVLTree::makePairNodepRow(node* nodep, int row)
{
    pairNodepRow temp;
    temp.nodep = nodep;
    temp.row = row;

    return temp;
}
node* AVLTree::createNode(int val)
{
    node* temp = new node;
    temp->val = val;
    temp->height = 0;
    temp->left = NULL;
    temp->right = NULL;

    return temp;
}
node* AVLTree::insert(node* nodep, int val, bool& inseration)
{
    if(nodep == NULL)
    {    
        inseration = true;
        return createNode(val);
    }

    inseration = false;

    bool inseration_;
    node* returnVal;

    if(val == nodep->val)
    {
        return nodep;
    }
    else if(val < nodep->val)
    {
        returnVal = this->insert(nodep->left, val, inseration_);

        if(inseration_)
        {
            nodep->left = returnVal;
        }

        this->updateNode(*nodep);
        this->balanceNode(*nodep->left, *nodep);
    }
    else
    {
        returnVal = insert(nodep->right, val, inseration_);

        if(inseration_)
        {
            nodep->right = returnVal;
        }

        this->updateNode(*nodep);
        this->balanceNode(*nodep->right, *nodep);
    }
    
    return returnVal;
}
void AVLTree::erase(node* nodep, int val, int& phase, bool& deletion, bool& deleteDirection, node& deleteNode)
{
    bool deletion_ = false;
    node* nextNode = NULL;

    if(nodep->val == val && phase == 0)
    {
        phase = 1;

        deleteNode = *nodep;

        if(nodep->left != NULL)
        {
            deleteDirection = 0;
            nextNode = nodep->left;  
        }    
        else if(nodep->right != NULL)
        {
            deleteDirection = 1;
            nextNode = nodep->right;
        }
        else
        {
            deleteNode.val = nodep->val;

            delete nodep;
            deletion = true;

            phase = 2;

            return;
        }
    }

    if(phase == 0)
    {
        if(val < nodep->val)
        {
            if(nodep->left != NULL)
            {
                nextNode = nodep->left;
            }
        }
        else
        {
            if(nodep->right != NULL)
            {
                nextNode = nodep->right;
            }
        }
    }
    else if(phase == 1 && nodep->val != val)
    {
        if(deleteDirection == 0)
        {
            if(nodep->right == NULL)
            {
                deleteNode.val = nodep->val;

                delete nodep;
                deletion = true;

                phase = 2;

                return;
            }
            else
            {
                nextNode = nodep->right;
            }
        }
        else
        {
            if(nodep->left == NULL)
            {
                deleteNode.val = nodep->val;

                delete nodep;
                deletion = true;

                phase = 2;

                return;
            }
            else
            {
                nextNode = nodep->left;
            }
        }
    }

    erase(nextNode, val, phase, deletion_, deleteDirection, deleteNode);

    if(deletion_)
    {
        if(nextNode == nodep->left)
        {
            nodep->left = NULL;
        }
        else
        {
            nodep->right = NULL;
        }
    }

    if(!deletion_)
    {
        updateNode(*nodep);
        balanceNode(*nextNode, *nodep);
    }
}
void AVLTree::print(node& node_, int row, int& lastRow)
{
    if(row != lastRow)
    {
        cout << '\n';
        lastRow = row;
    }

    cout << node_.val << ' ';

    if(node_.left != NULL)
        this->print(*node_.left, row + 1, lastRow);

    if(node_.right != NULL)
        this->print(*node_.right, row + 1, lastRow);
}
void AVLTree::rotateRight(node& x, node& father)
{
    node& y = *x.left;

    if(&x == this->root)
    {
        this->root = &y;
    }
    else
    {
        if(father.left == &x)
        {
            father.left = &y;
        }
        else
        {
            father.right = &y;
        }
    }

    x.left = y.right;
    y.right = &x;

    this->updateNode(x);
    this->updateNode(y);
    if(&x != this->root)
        this->updateNode(father);
}
void AVLTree::rotateLeft(node& x, node& father)
{
    node& y = *x.right;

    if(&x == this->root)
    {
        this->root = &y;
    }
    else
    {
        if(father.left == &x)
        {
            father.left = &y;
        }
        else
        {
            father.right = &y;
        }
    }

    x.right = y.left;
    y.left = &x;

    this->updateNode(x);
    this->updateNode(y);
    if(&x != this->root)
        this->updateNode(father);
}
void AVLTree::balanceNode(node& node_, node& father)
{
    if(balance(node_) > 1)
    {
        if(balance(*node_.left) > 0)
        {
            rotateRight(node_, father);
        }
        else
        {
            rotateLeft(*node_.left, node_);
            rotateRight(node_, father);
        }
    }
    else if(balance(node_) < -1)
    {
        if(balance(*node_.right) > 0)
        {
            rotateRight(*node_.right, node_);
            rotateLeft(node_, father);
        }
        else
        {
            rotateLeft(node_, father);
        }
    }
}
int AVLTree::balance(node& node_)
{
    int left = -1, right = -1;
    
    if(node_.left != NULL)
        left = node_.left->height;
    
    if(node_.right != NULL)
        right = node_.right->height;

    return left - right;
}
void AVLTree::updateNode(node& node_)
{
    int maxHeight = -1;

    if(node_.left != NULL)
        maxHeight = max(maxHeight, node_.left->height);

    if(node_.right != NULL)
        maxHeight = max(maxHeight, node_.right->height);

    node_.height = maxHeight + 1;
}
AVLTree::AVLTree()
{
    this->root = NULL;
}
node* AVLTree::insert(int val)
{
    node* returnVal;
    bool inseration;

    returnVal = this->insert(this->root, val, inseration);

    if(inseration)
    {
        this->root = returnVal;
    }

    this->updateNode(*this->root);
    this->balanceNode(*this->root, *this->root);

    return returnVal;
}
void AVLTree::erase(int val)
{
    int phase = 0;
    bool deletion, deleteDirection;
    node deleteNode;

    erase(this->root, val, phase, deletion, deleteDirection, deleteNode);

    if(deletion)
    {
        this->root = NULL;
    }

    if(!deletion)
    {
        updateNode(*this->root);
        balanceNode(*this->root, *this->root);
    }
}
node* AVLTree::find(int val)
{
    if(this->root == NULL)
        return NULL;

    return find(*this->root, val);
}
node* AVLTree::find(node& node_, int val)
{
    if(node_.val == val)
    {   
        return &node_;
    }
    
    node* returnVal = NULL;
    
    if(val < node_.val && node_.left != NULL)
        returnVal = find(*node_.left, val);
    else if(val > node_.val && node_.right != NULL)
        returnVal = find(*node_.right, val);

    return returnVal;
}
node* AVLTree::find(node& node_, int val, node*& father)
{
    if(node_.val == val)
    {   
        return &node_;
    }
    
    node* returnVal = NULL;
    
    if(val < node_.val && node_.left != NULL)
        returnVal = find(*node_.left, val, father);
    else if(val > node_.val && node_.right != NULL)
        returnVal = find(*node_.right, val, father);

    if(returnVal != NULL && father == NULL)
    {
        father = &node_;
    }

    return returnVal;
}
void AVLTree::print()
{
    int lastRow = 0;
    queue<pairNodepRow> next;
    
    if(this->root == NULL)
        return;
    
    next.push(makePairNodepRow(this->root, 0));

    while(!next.empty())
    {   
        if(next.front().row != lastRow)
        {
            cout << '\n';
            lastRow = next.front().row;
        }

        cout << next.front().nodep->val << ' ';

        if(next.front().nodep->left != NULL)
            next.push(makePairNodepRow(next.front().nodep->left, next.front().row + 1));

        if(next.front().nodep->right != NULL)
            next.push(makePairNodepRow(next.front().nodep->right, next.front().row + 1));

        next.pop();
    }

    cout << '\n';
}