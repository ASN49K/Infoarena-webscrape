#include <iostream>
#include<fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class ABC {
	int val;
	ABC *fiustanga, *fiudreapta;

public:
	ABC(int value=0){val=value;fiustanga=NULL; fiudreapta=NULL;};
	ABC* inserare(ABC*, int);
	ABC* cautare(ABC*, int);
	ABC* stergere(ABC*, int);
	ABC* valmin(ABC*);
	int maxmin(ABC*, int);
	int minMax(ABC*, int);
	void parcurgere(ABC*, int, int);
};


void ABC::parcurgere(ABC* tata, int x, int y)
{
	if (tata==0) return;
	parcurgere(tata->fiustanga,x,y);
	if(tata->val>x && tata->val<y) g<<tata->val<<' ';
	parcurgere(tata->fiudreapta,x,y);
}

int ABC::minMax(ABC* tata, int x)
{
  if(tata->fiustanga==NULL && tata->fiudreapta==NULL && tata->val<x)
    return -1;
  if((tata->val>x && tata->fiustanga==NULL) || (tata->val>x && tata->fiustanga->val<x))
    return tata->val;
  if(tata->val<x)
    return minMax(tata->fiudreapta,x);
  else return minMax(tata->fiustanga,x);
  return -1;
}

int ABC::maxmin(ABC* tata, int x)
{
    if(tata==NULL) return -1;
    if(tata->val==x) return x;
    else if(tata->val<x)
    {
        int n=maxmin(tata->fiudreapta,x);
        if(n==-1) return tata->val;
        else return n;

    }

    else if(tata->val>x)
        return maxmin(fiustanga,x);
    return -1;
}

ABC* ABC::cautare(ABC* tata, int val)
{
    if(tata==NULL || tata->val==val) return tata;
    if (tata->val< val) return cautare(tata->fiudreapta, val);
    return cautare(tata->fiustanga, val);
}

ABC* ABC::inserare(ABC* tata, int val)
{
	if (tata==0)
    {
		return new ABC(val);
	}
	if (tata->val<val)
    {
		tata->fiudreapta=inserare(tata->fiudreapta,val);
	}
	else
	{
		tata->fiustanga=inserare(tata->fiustanga,val);
	}
	return tata;
}

ABC* ABC::valmin(ABC* n)
{

    ABC* nod=n;
    while(nod && nod->fiustanga!=NULL)
    {
        nod=nod->fiustanga;
    }

    return nod;
}

ABC* ABC::stergere(ABC* tata, int val)
{
	if (tata==0)
    {
		return new ABC(val);
	}
	if (tata->val<val)
    {
		tata->fiudreapta=stergere(tata->fiudreapta,val);
	}
	else if(tata->val>val)
	{
		tata->fiustanga=stergere(tata->fiustanga,val);
	}
	else
    {
        if(tata->fiustanga==NULL && tata->fiudreapta==NULL)
            return NULL;

        else if(tata->fiustanga==NULL)
        {
            ABC *a=tata->fiudreapta;
            return a;
        }

        else if(tata->fiudreapta==NULL)
        {
            ABC *a=tata->fiustanga;
            return a;
        }

        ABC* a=valmin(tata->fiudreapta);
        tata->val=a->val;
        tata->fiudreapta=stergere(tata->fiudreapta,a->val);

    }
	return tata;
}


int main()
{
	ABC a, *tata = NULL;
	int q,optiune,x,y;
	f>>q;
	for(int i=0;i<q;i++)
    {
        f>>optiune;
        if(optiune==1)
        {
            f>>x;
            if(tata==NULL) tata=a.inserare(tata,x);
            else a.inserare(tata,x);
        }

        if(optiune==2)
        {
            f>>x;
            a.stergere(tata,x);
        }

        if(optiune==3)
        {
            f>>x;
            if(a.cautare(tata,x)==NULL) g<<'0'<<'\n';
            else g<<'1'<<'\n';
        }

        if(optiune==4)
        {
            f>>x;
            //g<<a.maxmin(tata,x)<<'\n';
        }

        if(optiune==5)
        {
            f>>x;
            //g<<a.minMax(tata,x)<<'\n';
        }

        if(optiune==6)
        {
            f>>x>>y;
            a.parcurgere(tata,x,y);
            g<<'\n';
        }

    }
}

