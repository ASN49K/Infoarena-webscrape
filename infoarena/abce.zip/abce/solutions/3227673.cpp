#include <iostream>
#include <fstream>
#include <random>
#include <climits>

std::ifstream fin("abce.in");
std::ofstream fout("abce.out");

std::random_device rd;
std::mt19937_64 gen64(rd());

struct TreapNode
{
    long long key, priority;
    TreapNode *left, *right;
};

TreapNode *rightRotate(TreapNode *y)
{
    TreapNode *x = y->left, *T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Return new root
    return x;
}

// A utility function to left rotate subtree rooted with x
// See the diagram given above.
TreapNode *leftRotate(TreapNode *x)
{
    TreapNode *y = x->right, *T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Return new root
    return y;
}

/* Utility function to add a new key */
TreapNode* newNode(long long key)
{
    TreapNode* temp = new TreapNode;
    temp->key = key;
    temp->priority = rand()%100;
    temp->left = temp->right = NULL;
    return temp;
}

// C function to search a given key in a given BST
TreapNode* search(TreapNode* root, long long key)
{
    // Base Cases: root is null or key is present at root
    if (root == NULL || root->key == key)
        return root;

    // Key is greater than root's key
    if (root->key < key)
        return search(root->right, key);

    // Key is smaller than root's key
    return search(root->left, key);
}

/* Recursive implementation of insertion in Treap */
TreapNode* insert(TreapNode* root, long long key)
{
    // If root is NULL, create a new node and return it
    if (!root)
        return newNode(key);

    // If key is smaller than root
    if (key <= root->key)
    {
        // Insert in left subtree
        root->left = insert(root->left, key);

        // Fix Heap property if it is violated
        if (root->left->priority > root->priority)
            root = rightRotate(root);
    }
    else // If key is greater
    {
        // Insert in right subtree
        root->right = insert(root->right, key);

        // Fix Heap property if it is violated
        if (root->right->priority > root->priority)
            root = leftRotate(root);
    }
    return root;
}

/* Recursive implementation of Delete() */
TreapNode* deleteNode(TreapNode* root, long long key)
{
    if (root == NULL)
        return root;

    if (key < root->key)
        root->left = deleteNode(root->left, key);
    else if (key > root->key)
        root->right = deleteNode(root->right, key);

        // IF KEY IS AT ROOT

        // If left is NULL
    else if (root->left == NULL)
    {
        TreapNode *temp = root->right;
        delete(root);
        root = temp; // Make right child as root
    }

        // If Right is NULL
    else if (root->right == NULL)
    {
        TreapNode *temp = root->left;
        delete(root);
        root = temp; // Make left child as root
    }

        // If key is at root and both left and right are not NULL
    else if (root->left->priority < root->right->priority)
    {
        root = leftRotate(root);
        root->left = deleteNode(root->left, key);
    }
    else
    {
        root = rightRotate(root);
        root->right = deleteNode(root->right, key);
    }

    return root;
}

long long fix_mai_mare(long long n, TreapNode* root) {
    if (!root)
        return LLONG_MAX;

    long long dif = LLONG_MAX;
    long long closest = LLONG_MAX;
    TreapNode* candidat = root;

    while (candidat) {
        long long current_dif = candidat->key - n;
        if (current_dif >= 0 && current_dif <= dif) {
            dif = current_dif;
            closest = candidat->key;
        }

        if (candidat->key > n) {
            candidat = candidat->left;
        } else {
            candidat = candidat->right;
        }
    }

    return closest;
}

long long fix_mai_mic(long long n, TreapNode* root) {
    if (!root)
        return LLONG_MIN;

    long long dif = -LLONG_MAX;
    long long closest = LLONG_MAX; // e doar limita, do not panic
    TreapNode* candidat = root;
    while (candidat) {
        long long current_dif = candidat->key - n;
        if(current_dif <= 0 && std::abs(current_dif) <= std::abs(dif))
        {
            closest=candidat->key;
            dif=current_dif;
        }
        if (candidat->key > n) {
            candidat = candidat->left;
        } else {
            candidat = candidat->right;
        }
    }

    return closest;
}

void interval(TreapNode *root, long long left, long long right) {
    if(root == nullptr) return;

    interval(root->left, left, right);
    if(left <= root->key && root->key <= right) {
        fout << root->key << ' ';
    }
    interval(root->right, left, right);
}

int main()
{
    TreapNode *root = NULL;

    int q;

    fin>>q;
    for(int i = 0; i < q; i++)
    {
        int op;
        long long x;
        fin>>op >> x;
        if(op == 1) {
            root = insert(root, x);
        }
        else if(op == 2) {
            root = deleteNode(root, x);
        }
        else if(op == 3) {
            fout << (search(root, x) != nullptr) << '\n';
        }
        else if(op == 4) {
            fout << fix_mai_mic(x, root) <<'\n';
        }
        else if(op == 5) {
            fout<< fix_mai_mare(x, root) <<'\n';
        }
        else {
            int y;
            fin>>y;
            interval(root, x, y);
            fout<<'\n';
        }
    }

    fin.close();
    fout.close();

    return 0;
}