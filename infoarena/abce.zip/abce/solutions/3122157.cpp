#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream in("abce.in");
ofstream out("abce.out");
ofstream tout("tree.out");
class Node
{
public:
    vector<Node *> children;
    vector<int> keys;
    bool leaf;
    Node(bool leaf = false)
    {
        this->children = {};
        this->keys = {};
        this->leaf = leaf;
    }
    void printInfo()
    {
        out << "\n\nchildren: ";
        for (auto i : children)
            out << i << " ";
        out << "\nkeys: ";
        for (auto i : keys)
            out << i << " ";
        out << endl;
    }
};
class Btree
{
public:
    vector<Node *> nodes;
    Node *root;
    long t;
    Btree(long t)
    {
        this->root = new Node(true);
        this->t = t;
    }
    void splitChild(Node *parent, int i);
    void insert( long long k);
    void insert_not_full(Node *node, long long k);
    void printTree(Node *node, int level);
    bool find(long long k, Node *node);
    void deleteKey(Node *node, long long k);
    void delete_internal_node(Node *node, long long k, int i);
    int delete_predecessor(Node *node);
    int delete_successor(Node *node);
    void delete_merge(Node *node, int i, int j);
    void delete_sibling(Node *node, int i, int j);
    int biggestKeyBelowLimit(long long x, Node *node);
    int smallestKeyOverLimit(long long x, Node *&end, long long &pos, Node *node);
    void printKeysInInterval(long long x, long long y, Node *node);
};
void Btree::splitChild(Node *parent, int i)
{
    Node *child = parent->children[i];
    auto it = parent->children.begin();
    parent->children.insert(it + i + 1, new Node(child->leaf)); /// create  new node and link it to the parent
    Node *new_child = parent->children[i + 1];

    auto it2 = parent->keys.begin();
    parent->keys.insert(it2 + i, child->keys[t - 1]); // add the median key of the child to the parent

    for (long i = t; i < 2 * t - 1; i++)
        (*new_child).keys.push_back((*child).keys[i]); // add the keys on the right side of the median to the new node

    (*child).keys.resize(t - 1);
    if (child->leaf == false) // if the child is not a leaf we transfer the children of the previously moved keys to the new child
    {
        for (long i = t; i < 2 * t; i++)
            new_child->children.push_back(child->children[i]);
        child->children.resize(t);
    }
    /// out << "\nnew child:" << new_child;
}

void Btree::insert_not_full(Node *node, long long k)
{
    long i = node->keys.size() - 1;
    
    if (node->leaf == true) // if the node is a leaf we complete the insertion
    {
        node->keys.push_back(LONG_MAX);
        while (i >= 0 && k < node->keys[i])
        {
            
            node->keys[i + 1] = node->keys[i];
            i--;
        }
        
        node->keys[i + 1] = k;
    }
    else /// else we call recusively until we get to a leaf
    {
        while (i >= 0 && k < node->keys[i])
            i--;
        if (node->children[i + 1]->keys.size() == (2 * (long)this->t - 1)) /// if the selected child is full we split it
        {
            this->splitChild(node, i + 1);
            if (k > node->keys[i + 1])
                i++;
        }
        this->insert_not_full(node->children[i + 1], k);
    }
}

void Btree::insert(long long k)
{

    Node *old_root = this->root;
    if (old_root->keys.size() == ((2 * (long)this->t) - 1)) // if the root is full add a new node to the tree and make it the new root
    {
        this->root = new Node;
        this->root->children.push_back(old_root);
        this->splitChild(this->root, 0);
        this->insert_not_full(this->root, k);
    }
    else
    {

        this->insert_not_full(old_root, k);
    }
}

void Btree::printTree(Node *node, int level = 0)
{
    tout << "Level " << level << ":";
    for (long i = 0; i < node->keys.size(); i++)
        tout << node->keys[i] << " ";
    tout << endl;
    level++;
    if (node->children.size() > 0)
        for (auto child_node : node->children)
        {
            this->printTree(child_node, level);
        }
}
bool Btree::find(long long k, Node *node=nullptr)
{
    if (node == nullptr)
        node = root;
    long i = 0;
    while (i < node->keys.size() && k > node->keys[i])
        i++;
    if (i < node->keys.size() && node->keys[i] == k)
        return 1;
    else
    {
        if (node->leaf == true)
            return 0;
        else
            return this->find(k, node->children[i]);
    }
}
void Btree::deleteKey(Node *node, long long k)
{
    long i = 0;
    while (i < node->keys.size() && k > node->keys[i])
        i++;
    if (node->leaf)
    {
        if (i < node->keys.size() && node->keys[i] == k)
        {
            node->keys.erase(node->keys.begin() + i);
        }
        return;
    }

    if (i < node->keys.size() && node->keys[i] == k)
        return delete_internal_node(node, k, i);
    else if (node->children[i]->keys.size() >= t)
        deleteKey(node->children[i], k);

    else
    {
        if (i != 0 && i + 2 < node->children.size())
        {
            if (node->children[i - 1]->keys.size() >= t)
                delete_sibling(node, i, i - 1);
            else if (node->children[i + 1]->keys.size() >= t)
                delete_sibling(node, i, i + 1);
            else
                delete_merge(node, i, i + 1);
        }
        else if (i == 0)
        {
            if (node->children[i + 1]->keys.size() >= t)
                delete_sibling(node, i, i + 1);
            else
                delete_merge(node, i, i + 1);
        }
        else
        {
            if (i + 1 == node->children.size())
               { if (node->children[i - 1]->keys.size() >= t)
                    delete_sibling(node, i, i - 1);
                else
                    delete_merge(node, i, i - 1);}
        }
        deleteKey(node->children[i], k);
    }
}
void Btree::delete_internal_node(Node *node, long long k, int i)
{
    if (node->leaf)
    {
        if (node->keys[i] == k)
            node->keys.erase(node->keys.begin() + i);
        return;
    }
    if (node->children[i]->keys.size() >= t)
    {
        node->keys[i] = delete_predecessor(node->children[i]);
        return;
    }
    else if (node->children[i + 1]->keys.size() >= t)
    {
        node->keys[i] = delete_successor(node->children[i + 1]);
        return;
    }
    else
    {
        delete_merge(node, i, i + 1);
        delete_internal_node(node->children[i], k, t - 1);
    }
}
int Btree::delete_predecessor(Node *node)
{
    if (node->leaf)
    {
        int aux = node->keys.back();
        node->keys.pop_back();
        return aux;
    }
    int n = node->keys.size() - 1;
    if (node->children[n]->keys.size() >= t)
        delete_sibling(node, n + 1, n);
    else
        delete_merge(node, n, n + 1);
    return delete_predecessor(node->children[n]);
}
int Btree::delete_successor(Node *node)
{
    if (node->leaf)
    {
        int aux = node->keys[0];
        node->keys.erase(node->keys.begin());
        return aux;
    }
    if (node->children[1]->keys.size() >= (long)t)
        delete_sibling(node, 0, 1);
    else
        delete_merge(node, 0, 1);
    return delete_successor(node->children[0]);
}
void Btree::delete_merge(Node *node, int i, int j)
{
    Node *child = node->children[i], *new_node = nullptr;
    if (j > i)
    {
        Node *rchild = node->children[j];
        child->keys.push_back(node->keys[i]);
        for (long k = 0; k < rchild->keys.size(); k++)
        {
            child->keys.push_back(rchild->keys[k]);
            if (rchild->children.size() > 0)
                child->children.push_back(rchild->children[k]);
        }
        if (rchild->children.size() > 0)
        {
            child->children.push_back(rchild->children.back());
            rchild->children.pop_back();
        }
        node->keys.erase(node->keys.begin() + i);
        node->children.erase(node->children.begin() + j);
    }
    else
    {
        Node *lchild = node->children[j];
        lchild->keys.push_back(node->keys[j]);
        for (long k = 0; k < child->keys.size(); k++)
            lchild->keys.push_back(child->keys[k]);
        if (lchild->children.size() > 0)
            lchild->children.push_back(child->children[i]);
        if (lchild->children.size() > 0)
        {
            lchild->children.push_back(child->children.back());
            child->children.pop_back();
        }
        new_node = lchild;
        node->keys.erase(node->keys.begin() + j);
        node->children.erase(node->children.begin() + i);
    }
    if (node == this->root && node->keys.size() == 0)
    {
        this->root = new_node;
    }
}
void Btree::delete_sibling(Node *node, int i, int j)
{
    Node *child = node->children[i];
    if (i < j)
    {
        Node *rchild = node->children[j];
        child->keys.push_back(node->keys[i]);
        node->keys[i] = rchild->keys[0];
        if (rchild->children.size() > 0)
        {
            child->children.push_back(rchild->children[0]);
            rchild->children.erase(rchild->children.begin());
        }
        rchild->keys.erase(rchild->keys.begin());
    }
    else
    {
        Node *lchild = node->children[j];
        child->keys.insert(child->keys.begin(), node->keys[i - 1]);
        node->keys[i - 1] = lchild->keys.back();
        lchild->keys.pop_back();
        if (lchild->children.size() > 0)
        {
            child->children.insert(child->children.begin(), lchild->children.back());
            lchild->children.pop_back();
        }
    }
}
int Btree::biggestKeyBelowLimit(long long x, Node *node = nullptr)
{
    if (node == nullptr)
    {
        node = root;
    }
    if (node->leaf == true)
    {
        long i = 0;
        while (i < node->keys.size() && node->keys[i] < x)
            i++;
        return node->keys[i - 1];
    }
    else
    {
        long i = 0;
        while (i < node->keys.size() && node->keys[i] < x)
            i++;
        if (i < node->keys.size() && node->keys[i] == x)
            return x;
        else
        {
            if (node->children[i]->keys.size() > 0 && node->children[i]->keys[0] <= x)
                return biggestKeyBelowLimit(x, node->children[i]);
            else
                return node->keys[i - 1];
        }
    }
}
int Btree::smallestKeyOverLimit(long long x, Node *&end, long long &pos, Node *node = nullptr)
{
    if (node == nullptr)
    {
        node = root;
    }
    if (node->leaf)
    {
        long i = 0;
        while (i < node->keys.size() && node->keys[i] < x)
            i++;
        pos = i;
        end = node;
        return node->keys[i];
    }
    else
    {
        long i = 0;
        while (i < node->keys.size() && node->keys[i] < x)
            i++;
        if (i < node->keys.size() && node->keys[i] == x)
        {
            pos = i;
            end = node;
            return x;
        }

        else
        {

            if (node->children[i]->keys.size() > 0)
                return smallestKeyOverLimit(x, end, pos, node->children[i]);
            else
            {
                pos = i - 1;
                end = node;
                return node->keys[i - 1];
            }
        }
    }
}
void Btree::printKeysInInterval(long long x, long long y, Node *node = nullptr)
{
    long pos = 0;
    if (node == nullptr)
        node = this->root;

    if (node->leaf)
    {
        for (long k = pos; k < node->keys.size(); k++)
        {
            if (node->keys[k] > y)
                return;
            else
            {
                if (node->keys[k] > x)
                    out << node->keys[k] << " ";
            }
        }
    }
    else
    {
        printKeysInInterval(x, y, node->children[0]);
        for (long k = pos; k < node->keys.size(); k++)
        {
            if (node->keys[k] > y)
                return;
            else
            {
                if (node->keys[k] > x)
                    out << node->keys[k] << " ";
                printKeysInInterval(x, y, node->children[k + 1]);
            }
        }
    }
}
int main()
{
    Btree b(3);
    int n;
    in >> n;
    for (int i = 0; i < n; i++)
    {

        int k;
        long long x, y;
        in >> k;
        switch (k)
        {
        case 1:
            in >> x;
            cout<<"1";
            b.insert(x);
            break;

        case 2:
            in >> x;
                        cout<<"2";

            if (b.find(x))
                b.deleteKey(b.root, x);
            break;
        case 3:
                    

            in >> x;
            cout<<"3-"<<x<<endl;
            b.printTree(b.root);
            tout<<endl;
            out << b.find(x) << endl;
            break;
        case 4:
                    cout<<"4";

            in >> x;
            out << b.biggestKeyBelowLimit(x) << endl;
            break;
        case 5:
                    cout<<"5";

            in >> x;
            Node *n;
            out << b.smallestKeyOverLimit(x, n, y) << endl;
            break;
        case 6:
                    cout<<"6";

            in >> x;
            in >> y;
            b.printKeysInInterval(x, y);
            out << endl;
            break;
        default:
            break;
        }
    }
    b.printTree(b.root);

    return 0;
}