#include <bits/stdc++.h>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
// #define f cin
// #define g cout

const int t = 40;
const int maxKeys = 2 * t - 1;
const int minKeys = t - 1;
const int midPos = minKeys;
const int inf = 1e9 + 1;
const int minf = -1e9 - 1;

class BTree;

class BTreeNode
{
    int *keys;
    int nKeys;
    BTreeNode **children;

    friend class BTree;

    void LeafInsertKey(int k, int position)
    {
        for (int i = this->nKeys; i > position; i--)
            keys[i] = keys[i - 1];
        keys[position] = k;
        this->nKeys++;
    }

    void innerInsertKey(int k, int position, BTreeNode *left, BTreeNode *right)
    {
        for (int i = this->nKeys; i > position; i--)
        {
            keys[i] = keys[i - 1];
            children[i + 1] = children[i];
        }
        keys[position] = k;
        children[position] = left;
        children[position + 1] = right;
        this->nKeys++;
    }

    tuple<int, BTreeNode *, BTreeNode *> RemoveExtraKey()
    {
        BTreeNode *right = new BTreeNode();
        int mid = keys[midPos];

        for (int i = midPos + 1; i < nKeys; i++)
        {
            right->keys[i - midPos - 1] = keys[i];
            right->children[i - midPos - 1] = children[i];
            children[i] = nullptr;
        }

        right->children[nKeys - midPos - 1] = children[nKeys];
        children[nKeys] = nullptr;

        this->nKeys = midPos;
        right->nKeys = maxKeys - midPos;
        return {mid, this, right};
    }

    void mergeSibilings(int position)
    {
        BTreeNode *left = children[position];
        BTreeNode *right = children[position + 1];

        left->keys[left->nKeys++] = keys[position];
        for (int i = 0; i < right->nKeys; i++)
        {
            left->keys[left->nKeys] = right->keys[i];
            left->children[left->nKeys++] = right->children[i];
        }
        left->children[left->nKeys] = right->children[right->nKeys];

        delete right;

        for (int i = position; i < nKeys - 1; i++)
        {
            keys[i] = keys[i + 1];
            children[i + 1] = children[i + 2];
        }
        nKeys--;
    }

    void borrowLeft(int position)
    {
        BTreeNode *leftSibling = children[position - 1];
        BTreeNode *current = children[position];

        for (int i = current->nKeys; i > 0; i--)
        {
            current->keys[i] = current->keys[i - 1];
            current->children[i + 1] = current->children[i];
        }
        current->children[1] = current->children[0];

        current->keys[0] = keys[position - 1];
        current->children[0] = leftSibling->children[leftSibling->nKeys];

        leftSibling->children[leftSibling->nKeys] = nullptr;

        keys[position - 1] = leftSibling->keys[leftSibling->nKeys - 1];
        leftSibling->nKeys--;
        current->nKeys++;
    }

    void borrowRight(int position)
    {
        BTreeNode *rightSibling = children[position + 1];
        BTreeNode *current = children[position];

        current->keys[current->nKeys] = keys[position];
        current->children[current->nKeys + 1] = rightSibling->children[0];
        keys[position] = rightSibling->keys[0];

        for (int i = 0; i < rightSibling->nKeys - 1; i++)
        {
            rightSibling->keys[i] = rightSibling->keys[i + 1];
            rightSibling->children[i] = rightSibling->children[i + 1];
        }
        rightSibling->children[rightSibling->nKeys - 1] = rightSibling->children[rightSibling->nKeys];
        rightSibling->children[rightSibling->nKeys] = nullptr;
        rightSibling->nKeys--;
        current->nKeys++;
    }

    void mergeRight(int position)
    {
        children[position]->keys[minKeys] = keys[position];
        children[position]->nKeys++;

        for (int i = 0; i < minKeys; i++)
        {
            children[position]->keys[children[position]->nKeys] = children[position + 1]->keys[i];
            children[position]->children[children[position]->nKeys] = children[position + 1]->children[i];
            children[position]->nKeys++;
        }

        children[position]->children[children[position]->nKeys] = children[position + 1]->children[minKeys];

        delete children[position + 1];

        for (int i = position; i < nKeys - 1; i++)
        {
            keys[i] = keys[i + 1];
            children[i + 1] = children[i + 2];
        }
        children[nKeys] = nullptr;
        nKeys--;
    }

    void printRange(int x, int y, bool &flag) const
    {
        int lb = lower_bound(keys, keys + nKeys, x) - keys;

        for (int i = lb; i <= nKeys; i++)
        {
            if (children[i])
                children[i]->printRange(x, y, flag);
            if (i < nKeys && keys[i] >= x && keys[i] <= y)
            {
                g << keys[i] << " ";
                flag = true;
            }
            if (i < nKeys && keys[i] > y)
                break;
        }
    }

  public:
    BTreeNode() : keys{new int[maxKeys + 1]}, nKeys(0), children{new BTreeNode *[maxKeys + 2]}
    {
        memset(children, 0, sizeof(BTreeNode *) * (maxKeys + 2));
    }

    inline bool isLeaf() const
    {
        return children[0] == nullptr;
    }

    tuple<int, BTreeNode *, BTreeNode *> insert(int k)
    {
        int lb = lower_bound(keys, keys + nKeys, k) - keys;
        if (nKeys && lb != nKeys && keys[lb] == k)
            return {inf, nullptr, nullptr};

        if (this->isLeaf())
            LeafInsertKey(k, lb);
        else
        {
            tuple<int, BTreeNode *, BTreeNode *> toInsert = children[lb]->insert(k);
            if (get<0>(toInsert) != inf)
                innerInsertKey(get<0>(toInsert), lb, get<1>(toInsert), get<2>(toInsert));
        }

        if (nKeys > maxKeys)
            return RemoveExtraKey();
        return {inf, nullptr, nullptr};
    }

    void remove(int k)
    {
        if (nKeys == 0)
            return;

        int lb = lower_bound(keys, keys + nKeys, k) - keys;

        if (isLeaf())
        {
            if (lb < nKeys && keys[lb] == k)
            {
                for (int i = lb; i < nKeys - 1; i++)
                    keys[i] = keys[i + 1];
                nKeys--;
            }
            return;
        }

        if (lb < nKeys && keys[lb] == k)
        {
            if (children[lb]->nKeys > minKeys)
            {
                BTreeNode *cur = children[lb];
                while (!cur->isLeaf())
                    cur = cur->children[cur->nKeys];
                int val = cur->keys[cur->nKeys - 1];
                children[lb]->remove(val);
                keys[lb] = val;
            }
            else if (children[lb + 1]->nKeys > minKeys)
            {
                BTreeNode *cur = children[lb + 1];
                while (!cur->isLeaf())
                    cur = cur->children[0];
                int val = cur->keys[0];
                children[lb + 1]->remove(val);
                keys[lb] = val;
            }
            else
            {
                mergeSibilings(lb);
                children[lb]->remove(k);
            }
        }
        else
        {
            if (children[lb]->nKeys == minKeys)
            {
                if (lb > 0 && children[lb - 1]->nKeys > minKeys)
                    borrowLeft(lb);
                else if (lb < nKeys && children[lb + 1]->nKeys > minKeys)
                    borrowRight(lb);
                else if (lb > 0)
                    mergeRight(lb - 1), lb--;
                else
                    mergeRight(lb);
            }
            children[lb]->remove(k);
        }
    }
};

struct BTree
{
    BTreeNode *root;

  public:
    BTree()
    {
        this->root = new BTreeNode();
    }
    void insert(int k)
    {
        tuple<int, BTreeNode *, BTreeNode *> toInsert = root->insert(k);
        if (get<0>(toInsert) != inf)
        {
            BTreeNode *newRoot = new BTreeNode();
            newRoot->keys[0] = get<0>(toInsert);
            newRoot->children[0] = get<1>(toInsert);
            newRoot->children[1] = get<2>(toInsert);
            newRoot->nKeys = 1;
            root = newRoot;
        }
    }
    void remove(int k)
    {
        root->remove(k);
        if (root->nKeys == 0)
        {
            BTreeNode *newRoot = root->children[0];
            delete root;
            root = newRoot;
        }
    }

    bool exists(int k) const
    {
        BTreeNode *cur = root;
        while (cur)
        {
            if (cur->nKeys == 0)
                return false;

            int lb = lower_bound(cur->keys, cur->keys + cur->nKeys, k) - cur->keys;

            if (lb < cur->nKeys && cur->keys[lb] == k)
                return true;
            cur = cur->children[lb];
        }
        return false;
    }

    int predecessor(int k) const
    {
        BTreeNode *cur = root;
        int pred = minf;
        while (cur)
        {
            if (cur->nKeys == 0)
                return pred;

            int lb = lower_bound(cur->keys, cur->keys + cur->nKeys, k) - cur->keys;

            if (lb < cur->nKeys && cur->keys[lb] == k)
                return k;

            if (lb > 0)
                pred = cur->keys[lb - 1];

            cur = cur->children[lb];
        }
        return pred;
    }

    int successor(int k) const
    {
        BTreeNode *cur = root;
        int succ = inf;
        while (cur)
        {
            if (cur->nKeys == 0)
                return succ;

            int lb = lower_bound(cur->keys, cur->keys + cur->nKeys, k) - cur->keys;

            if (lb < cur->nKeys && cur->keys[lb] == k)
                return k;

            if (lb < cur->nKeys)
                succ = cur->keys[lb];

            cur = cur->children[lb];
        }
        return succ;
    }

    void printRange(int x, int y) const
    {
        bool flag = false;
        root->printRange(x, y, flag);

        if (!flag)
            g << minf << " " << inf;

        g << '\n';
    }

} tree;

int main()
{
    ios::sync_with_stdio(false);
    f.tie(nullptr);
    int q;

    f >> q;
    while (q--)
    {
        int type, X;
        f >> type >> X;

        if (type == 1)
        {
            tree.insert(X);
        }
        else if (type == 2)
        {
            tree.remove(X);
        }
        else if (type == 3)
        {
            g << tree.exists(X) << '\n';
        }
        else if (type == 4)
        {
            g << tree.predecessor(X) << '\n';
        }

        else if (type == 5)
        {
            g << tree.successor(X) << '\n';
        }
        else if (type == 6)
        {
            int Y;
            f >> Y;
            tree.printRange(X, Y);
        }
    }
    return 0;
}