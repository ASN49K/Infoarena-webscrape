#include <iostream>
#include <fstream>

using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
int n,i,j,x,k,ok,max1,min1,y;
struct nod{
	int info;
    nod * st, * dr;

};
void Inserare(nod * & R, int x)
{
	if(R != NULL)
    {
    	if(R->info == x)
        	return;
        else
        	if(R->info > x)
            	Inserare(R->st , x);
            else
            	Inserare(R->dr , x);
    }
    else
    {
    	R = new nod;
        R->info = x;
        R->st = NULL;
        R->dr = NULL;
    }
}
void Afisare(nod * r)
{
    if(r != NULL)
    {
		Afisare(r->st);
		g << r->info << " ";
		Afisare(r->dr);
	}
}
void Afisare3(nod * r)
{
    if(r != NULL)
    {
		Afisare3(r->st);
		if(r->info>=x&&r->info<=y)
            g<<r->info<< " " ;
		Afisare3(r->dr);
	}
}
void Afisare1(nod * r)
{
    if(r != NULL)
    {
		Afisare1(r->st);
		if(r->info<=x&&r->info>=max1)
            max1=r->info;

		Afisare1(r->dr);
	}
}
void Afisare2(nod * r)
{
    if(r != NULL)
    {
		Afisare2(r->st);
		if(r->info>=x&&r->info<=min1)
            min1=r->info;
		Afisare2(r->dr);
	}
}
void StergAux(nod * & p, nod * & R)
{
	// R - nodul care trebuie sters
	// p - pointer cu care identificăm nodul cel mai din dreapta
	if(p->dr)
		StergAux(p -> dr , R);
	else
	{
		R->info = p->info;
		nod * aux = p;
		p = p->st;
		delete aux;
	}
}

void Stergere(nod * & R , int x)
{
	if(R != NULL)
	{
		if(R->info == x)
		{
			// nodul trebuie șters
			if(R->st == NULL && R->dr == NULL)
			{
				delete R;
				R = NULL;
			}
			else
				if(R->dr == NULL)
				{
					nod * aux = R;
					R = R->st;
					delete aux;
				}
				else
					if(R->st == NULL)
					{
						nod * aux = R;
						R = R->dr;
						delete aux;
					}
					else
						StergAux(R->st, R);
		}
		else
			if(R->info > x)
				Stergere(R->st , x);
			else
				Stergere(R->dr , x);
	}
	else
		return; // valoarea x nu apare în arbore
}
nod * Cautare(nod * R , int x)
{
	if(R == NULL)
		return NULL;
	if(R->info == x)
		return R;
	if(R->info > x)
		return Cautare(R->st , x);
	else
		return Cautare(R->dr , x);
}
int main()
{
    nod *R,*A;
    f>>n;
    j=1;
    ok=1;
    while(ok==1)
    {
        f>>k;
        if(k==3)
            {
                f>>x;
                g<<0<<endl;}
        if(k==1)
           {
               f>>x;
               ok=0;

    R = new nod;
    R->info = x;
    R->st = NULL;
    R->dr = NULL;

           }



        j++;

    }
    for(i=j;i<=n;i++)
    {
        f>>k;
        if(k==1)
        {
            f>>x;
            Inserare(R,x);
        }
        if(k==2)
        {
            f>>x;
            Stergere(R,x);
        }
        if(k==3)
        {
            f>>x;
            A=Cautare(R,x);
            if(A==0)
                g<<0<<endl;
            else
                g<<1<<endl;

        }
        if(k==4)
        {
            f>>x;
            max1=0;
            Afisare1(R);
            g<<max1<<endl;

        }
        if(k==5)
        {
            f>>x;
            min1=999;
            Afisare2(R);
            g<<min1<<endl;
        }
        if(k==6)
        {
            f>>x>>y;
            Afisare3(R);
            g<<endl;
        }
    }








     /*
    nod *R;
    R = new nod;
    R->info = x;
    R->st = NULL;
    R->dr = NULL;
    cin>>x;
    Inserare(R,x);
    Stergere(R,3);
    Afisare(R);*/



    return 0;
}
