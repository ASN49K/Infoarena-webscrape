///Bibliografie: https://www.geeksforgeeks.org/red-black-tree-set-1-introduction-2/

#include <bits/stdc++.h>

using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");


enum COLOR { RED, BLACK };

struct Node
{
    int val;
    COLOR color;
    Node *left, *right, *parent;

    Node(int val)
    {
        this->val = val;
        parent = left = right = NULL;
        color = RED;
    }
    bool isOnLeft()
    {
        return this == parent->left;
    }
    Node *unchi()
    {
        if (parent == NULL or parent->parent == NULL)
            return NULL;
        if (parent->isOnLeft())
            return parent->parent->right;
        else
            return parent->parent->left;
    }
    Node *frate()
    {
        if (parent == NULL)
            return NULL;
        if (isOnLeft())
            return parent->right;
        return parent->left;
    }
    bool hasRedChild()
    {
        return (left != NULL and left->color == RED) or (right != NULL and right->color == RED);
    }

};

void inorder(Node *x)
{
    if (x == NULL)
        return;
    inorder(x->left);
    out << x->val << " ";
    inorder(x->right);
}

void intervalSortat(Node* x, int start, int sfarsit)
{
    if(x != NULL)
    {
        if(x->val >= start and x->val <= sfarsit)
        {
            intervalSortat(x->left, start, sfarsit);
            out << x->val << " ";
            intervalSortat(x->right, start, sfarsit);

        }
        else if(x->val < start)
            intervalSortat(x->right, start, sfarsit);

        else if(x->val > sfarsit)
            intervalSortat(x->left, start, sfarsit);
    }
}

Node *gasesteInlocuitor(Node *x)
{
    if (x->left != NULL and x->right != NULL)
    {
        Node *aux = x->right;
        while (aux->left != NULL)
            aux = aux->left;
        return aux;
    }
    if (x->left == NULL and x->right == NULL)
        return NULL;

    if (x->left != NULL)
        return x->left;
    else
        return x->right;
}

class RB
{
private:
    Node *root;
public:
    void predecesor(int val)
    {
        Node *aux = root;
        int maxim = INT_MIN;
        while (aux != NULL)
        {
            if (aux->val > maxim and aux->val <= val)
                maxim = aux->val;
            if (aux->val > val)
                aux = aux->left;
            else if (aux->val == val)
                break;
            else
                aux = aux->right;
        }
        out << maxim;
    }
    void succesor(int val)
    {
        Node *aux = root;
        int minim = INT_MAX;
        while (aux != NULL)
        {
            if (aux->val < minim and aux->val >= val)
                minim = aux->val;
            if (aux->val < val)
                aux = aux->right;
            else if (aux->val == val)
                break;
            else
                aux = aux->left;
        }
        out << minim;
    }
    Node* getRoot()
    {
        return this->root;
    }
    RB()
    {
        root = NULL;
    }
    Node *cautaVal(int n)
    {
        Node *aux = root;
        while (aux != NULL)
        {
            if (n < aux->val)
            {
                if (aux->left == NULL)
                    break;
                else
                    aux = aux->left;
            }
            else if (n == aux->val)
                break;
            else
            {
                if (aux->right == NULL)
                    break;
                else
                    aux = aux->right;
            }
        }
        return aux;
    }
    void leftRotate(Node *x)
    {
        Node *newParinte = x->right;
        if (x == root)
          root = newParinte;

        if (x->parent != NULL)
        {
            if (x->isOnLeft())
                x->parent->left = newParinte;
            else
                x->parent->right = newParinte;
        }

        newParinte->parent = x->parent;
        x->parent = newParinte;
        x->right = newParinte->left;
        if (newParinte->left != NULL)
          newParinte->left->parent = x;

        newParinte->left = x;
    }
    void rightRotate(Node *x)
    {
        Node *newParinte = x->left;
        if (x == root)
          root = newParinte;

        if (x->parent != NULL)
        {
            if (x->isOnLeft())
                x->parent->left = newParinte;
            else
                x->parent->right = newParinte;
        }

        newParinte->parent = x->parent;
        x->parent = newParinte;
        x->left = newParinte->right;
        if (newParinte->right != NULL)
          newParinte->right->parent = x;

        newParinte->right = x;
    }
    void fixDoubleRedOnInsert(Node *x)
    {
        if (x == root)
        {
            x->color = BLACK;
            return;
        }

        Node *parinte = x->parent,
             *bunic = parinte->parent,
             *unchi = x->unchi();

        if (parinte->color != BLACK)
        {
            if (unchi != NULL and unchi->color == RED)
            {
                parinte->color = BLACK;
                unchi->color = BLACK;
                bunic->color = RED;
                fixDoubleRedOnInsert(bunic);
            }
            else
            {
                if (parinte->isOnLeft())
                {
                    if (x->isOnLeft())
                        swap(parinte->color, bunic->color);
                    else
                    {
                        leftRotate(parinte);
                        swap(x->color, bunic->color);
                    }
                    rightRotate(bunic);
                }
                else
                {
                    if (x->isOnLeft())
                    {
                        rightRotate(parinte);
                        swap(x->color, bunic->color);
                    }
                    else
                        swap(parinte->color, bunic->color);

                    leftRotate(bunic);
                }
            }
        }
    }
    void fixDoubleBlackOnDelete(Node *x)
    {
        if (x == root)
            return;
        Node *frate = x->frate(), *parinte = x->parent;
        if (frate == NULL)
          fixDoubleBlackOnDelete(parinte);
        else
        {
            if (frate->color == RED)
            {
                parinte->color = RED;
                frate->color = BLACK;
                if (frate->isOnLeft())
                    rightRotate(parinte);
                else
                    leftRotate(parinte);

                fixDoubleBlackOnDelete(x);
            }
            else
            {
                if (frate->hasRedChild())
                {
                    if (frate->left != NULL and frate->left->color == RED)
                    {
                        if (frate->isOnLeft())
                        {
                            frate->left->color = frate->color;
                            frate->color = parinte->color;
                            rightRotate(parinte);
                        }
                        else
                        {
                            frate->left->color = parinte->color;
                            rightRotate(frate);
                            leftRotate(parinte);
                        }
                    }
                    else
                    {
                        if (frate->isOnLeft())
                        {
                            frate->right->color = parinte->color;
                            leftRotate(frate);
                            rightRotate(parinte);
                        }
                        else
                        {
                            frate->right->color = frate->color;
                            frate->color = parinte->color;
                            leftRotate(parinte);
                        }
                    }
                    parinte->color = BLACK;
                }
                else
                {
                    frate->color = RED;
                    if (parinte->color == BLACK)
                        fixDoubleBlackOnDelete(parinte);
                    else
                        parinte->color = BLACK;
                }
            }
        }
    }
    void deleteNode(Node *sters)
    {
        Node *inlocuitorSters = gasesteInlocuitor(sters);
        Node *parinte = sters->parent;
        if (inlocuitorSters == NULL)
        {
            if (sters == root)
                root = NULL;
            else
            {
                if ((inlocuitorSters == NULL or inlocuitorSters->color == BLACK) and (sters->color == BLACK))
                    fixDoubleBlackOnDelete(sters);
                else
                    if (sters->frate() != NULL)
                        sters->frate()->color = RED;
                if (sters->isOnLeft())
                    parinte->left = NULL;
                else
                    parinte->right = NULL;
            }
            delete sters;
            return;
        }

        if (sters->left == NULL or sters->right == NULL)
        {
            if (sters == root)
            {
                sters->val = inlocuitorSters->val;
                sters->left = sters->right = NULL;
                delete inlocuitorSters;
            }
            else
            {
                if (sters->isOnLeft())
                    parinte->left = inlocuitorSters;
                else
                    parinte->right = inlocuitorSters;

                delete sters;
                inlocuitorSters->parent = parinte;
                if ((inlocuitorSters == NULL or inlocuitorSters->color == BLACK) and (sters->color == BLACK))
                    fixDoubleBlackOnDelete(inlocuitorSters);
                else
                    inlocuitorSters->color = BLACK;
            }
            return;
        }
        swap(inlocuitorSters->val, sters->val);
        deleteNode(inlocuitorSters);
    }
    void insereazaRB(int nr)
    {
        Node *newNode = new Node(nr);
        if (root == NULL)
        {
            newNode->color = BLACK;
            root = newNode;
        }
        else
        {
            Node *aux = cautaVal(nr);
            if (aux->val == nr)
                return;

            newNode->parent = aux;
            if (nr < aux->val)
                aux->left = newNode;
            else
                aux->right = newNode;

            fixDoubleRedOnInsert(newNode);
        }
    }
    void stergeRB(int nr)
    {
        if (root == NULL)
            return;
        Node *v = cautaVal(nr);
        deleteNode(v);
    }
    void afisareInorder()
    {
        if (root != NULL)
            inorder(root);
    }
    void afisareIntervalSortat(int start, int sfarsit)
    {
        intervalSortat(root, start, sfarsit);
    }
    Node* gasesteValoare(Node* root, int val)
    {
        if (root == NULL)
            return NULL;
        if (root->val == val)
            return root;
        if (root->val < val)
            return gasesteValoare(root->right, val);
        return gasesteValoare(root->left, val);
    }
    void afisareValoareGasita(int x)
    {
        if(gasesteValoare(root, x) != NULL)
            out << 1;
        else
            out << 0;
    }
};

int main()
{
    RB arbore;
    int n, cod, x, y;
    in >> n;
    for(int i = 0; i < n; i++)
    {
        in >> cod;
        if(cod == 6)
        {
            in >> x >> y;
            arbore.afisareIntervalSortat(x, y);
            out << "\n";
        }
        else
        {
            in >> x;
            if(cod == 1)
                arbore.insereazaRB(x);
            else if(cod == 2)
                arbore.stergeRB(x);
            else if(cod == 3)
            {
                arbore.afisareValoareGasita(x);
                out << "\n";
            }
            else if(cod == 4)
            {
                arbore.predecesor(x);
                out << "\n";
            }
            else if(cod == 5)
            {
                arbore.succesor(x);
                out << "\n";
            }

        }
    }

  return 0;
}
