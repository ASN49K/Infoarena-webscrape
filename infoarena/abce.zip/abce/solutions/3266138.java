import edu.princeton.cs.algs4.Stopwatch;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main {

    private class Node {
        private Node left;
        private Node right;
        // private int size;
        private int height;
        private int key;

        public Node(int key) {
            this.key = key;
            this.left = this.right = null;
            // this.size = 1;
            this.height = 0;
        }
    }

    private Node root;

    public Main() {
        root = null;
    }

    // private int size(Node n) {
    //     if (n == null) return 0;
    //     else return n.size;
    // }

    private int height(Node n) {
        if (n == null) return -1;
        else return n.height;
    }

    private void fixUp(Node n) {
        if (n == null) return;
        // n.size = 1 + size(n.left) + size(n.right);
        n.height = 1 + Math.max(height(n.left), height(n.right));
    }

    private int balanceFactor(Node n) {
        return height(n.left) - height(n.right);
    }

    private Node balance(Node n) {
        if (balanceFactor(n) < -1) { // right-heavy
            if (balanceFactor(n.right) > 0) {
                n.right = rightRotate(n.right);
            }
            n = leftRotate(n);
        }
        else if (balanceFactor(n) > 1) { // left-heavy
            if (balanceFactor(n.left) < 0) {
                n.left = leftRotate(n.left);
            }
            n = rightRotate(n);
        }
        return n;
    }

    private Node leftRotate(Node x) {
        Node y = x.right;
        Node B = y.left;
        y.left = x;
        x.right = B;

        fixUp(x);
        fixUp(y);

        return y;
    }

    private Node rightRotate(Node x) {
        Node y = x.left;
        Node C = y.right;
        y.right = x;
        x.left = C;

        fixUp(x);
        fixUp(y);

        return y;
    }

    private Node insert(Node n, int k) {
        if (n == null) return new Node(k);

        if (k < n.key) {
            n.left = insert(n.left, k);
        }
        else if (k > n.key) {
            n.right = insert(n.right, k);
        }

        fixUp(n);
        return balance(n);
    }

    public void insert(int k) {
        root = insert(root, k);
    }

    private Node min(Node n) {
        while (n.left != null) {
            n = n.left;
        }
        return n;
    }

    private Node deleteMin(Node n) {
        if (n.left != null) {
            n.left = deleteMin(n.left);
            fixUp(n);
            return balance(n);
        }
        return n.right;
    }

    private Node delete(Node n, int k) {
        if (n == null) return null;

        if (k < n.key) {
            n.left = delete(n.left, k);
        }
        else if (k > n.key) {
            n.right = delete(n.right, k);
        }
        else { // n == key
            if (n.left == null) return n.right;
            if (n.right == null) return n.left;

            // Node current = n;
            Node min = min(n.right);
            n.key = min.key;
            n.right = delete(n.right, min.key);
        }

        fixUp(n);
        return balance(n);
    }

    public void delete(int k) {
        root = delete(root, k);
    }

    private void stringify(Node n, StringBuilder sb) {
        if (n == null) return;
        stringify(n.left, sb);
        sb.append(n.key).append(" ");
        stringify(n.right, sb);
    }

    private int search(Node n, int k) {

        while (n != null) {
            if (n.key == k) return 1;
            else if (k < n.key) n = n.left;
            else n = n.right;
        }

        return 0;
        // if (n == null) return 0;
        //
        // if (k < n.key) return search(n.left, k);
        // else if (k > n.key) return search(n.right, k);
        // else return 1;
    }

    public int search(int k) {
        return search(root, k);
    }

    private Node floor(Node n, int k) {
        if (n == null) return null;

        if (k == n.key) return n;
        else if (k < n.key) return floor(n.left, k);
        else {
            Node floorRight = floor(n.right, k);
            if (floorRight != null) {
                return floorRight;
            }
            return n;
        }
    }

    public int floor(int k) {
        return floor(root, k).key;
        // return Objects.requireNonNull(floor(root, k)).key;
    }


    private Node ceiling(Node n, int k) {
        if (n == null) return null;

        if (k == n.key) return n;
        else if (k > n.key) return ceiling(n.right, k);
        else {
            Node left = ceiling(n.left, k);
            if (left != null) {
                return left;
            }
            return n;
        }
    }

    public int ceiling(int k) {
        return ceiling(root, k).key;
        // return Objects.requireNonNull(ceiling(root, k)).key;
    }

    private void keys(Node n, int min, int max, PrintWriter ps) {
        if (n == null) return;

        if (min <= n.key) keys(n.left, min, max, ps);
        if (min <= n.key && n.key <= max) {
            ps.print(n.key + " ");

        }
        if (max >= n.key) keys(n.right, min, max, ps);
    }

    public void keys(int min, int max, PrintWriter ps) {
        keys(root, min, max, ps);
    }


    public String toString() {
        StringBuilder sb = new StringBuilder();
        stringify(root, sb);
        return sb.toString();
    }

    public static void main(String[] args) throws IOException {
        Stopwatch sw = new Stopwatch();
        Main tree = new Main();
        // BufferedReader reader = new BufferedReader(new FileReader("abce.in"));
        // Scanner scanner = new Scanner(new BufferedInputStream(new FileInputStream("abce.in")),
        //                               "UTF-8");

        BufferedReader scanner = Files.newBufferedReader(Paths.get("abce.in"));
        // BufferedWriter out2 = Files.newBufferedWriter(Paths.get("abce.out"));

        PrintWriter out = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream("abce.out"), "UTF-8"),
                true);

        // PrintStream out = new PrintStream("abce.out");

        int Q = Integer.parseInt(scanner.readLine());

        for (int i = 0; i < Q; i++) {
            String op = scanner.readLine();
            String[] parts = op.split(" ");
            switch (parts[0]) {
                case "1":
                    tree.insert(Integer.parseInt(parts[1]));
                    break;
                case "2":
                    tree.delete(Integer.parseInt(parts[1]));
                    break;
                case "3":
                    out.println(tree.search(Integer.parseInt(parts[1])));
                    break;
                case "4":
                    out.println(tree.floor(Integer.parseInt(parts[1])));
                    break;
                case "5":
                    out.println(tree.ceiling(Integer.parseInt(parts[1])));
                    break;
                case "6":
                    int min = Integer.parseInt(parts[1]);
                    int max = Integer.parseInt(parts[2]);
                    tree.keys(min, max, out);
                    out.println();
                    break;
                default:
                    throw new IllegalArgumentException("unknown operation!");
            }
        }

        System.out.println(sw.elapsedTime());
    }
}
