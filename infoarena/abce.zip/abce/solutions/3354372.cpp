#include <fstream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

int val[100005], st[100005], dr[100005], cnt = 0;

void ins(int &n, int v) {
    if (!n) {
        n = ++cnt;
        val[n] = v;
        return;
    }
    if (val[n] == v) return;

    if (v < val[n]) ins(st[n], v);
    else ins(dr[n], v);
}

void del(int &n, int v) {
    if (!n) return;
    if (v < val[n]) del(st[n], v);
    else if (v > val[n]) del(dr[n], v);
    else {
        if (!st[n] && !dr[n]) n = 0;
        else if (!st[n]) n = dr[n];
        else if (!dr[n]) n = st[n];
        else {
            int max_st = st[n];
            while (dr[max_st]) max_st = dr[max_st];

            val[n] = val[max_st];
            del(st[n], val[max_st]);
        }
    }
}

bool exista(int n, int v) {
    if (!n) return false;
    if (val[n] == v) return true;
    return v < val[n] ? exista(st[n], v) : exista(dr[n], v);
}

int get_max(int n, int v, int ans) {
    if (!n) return ans;
    if (val[n] <= v) return get_max(dr[n], v, val[n]);
    return get_max(st[n], v, ans);
}

int get_min(int n, int v, int ans) {
    if (!n) return ans;
    if (val[n] >= v) return get_min(st[n], v, val[n]);
    return get_min(dr[n], v, ans);
}

void afis(int n, int x, int y) {
    if (!n) return;
    if (val[n] > x) afis(st[n], x, y);
    if (val[n] >= x && val[n] <= y) fout << val[n] << " ";
    if (val[n] < y) afis(dr[n], x, y);
}

int main() {
    int q, rad = 0;
    fin >> q;

    while (q--) {
        int tip, x, y;
        fin >> tip >> x;

        if (tip == 1) ins(rad, x);
        else if (tip == 2) del(rad, x);
        else if (tip == 3) fout << exista(rad, x) << endl;
        else if (tip == 4) fout << get_max(rad, x, -1) << endl;
        else if (tip == 5) fout << get_min(rad, x, -1) << endl;
        else {
            fin >> y;
            afis(rad, x, y);
            fout << endl;
        }
    }
    
    return 0;
}