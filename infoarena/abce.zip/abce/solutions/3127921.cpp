#include <iostream>
#include <fstream>

using namespace std;
ifstream in("abce.in");
ofstream out("abce.out");

struct node
{
    int val;
    node* tata;
    node* copilS;
    node* copilD;
    node(int);
};

node::node(int val)
{
    this->val = val;
    this->tata = nullptr;
    this->copilS = nullptr;
    this->copilD = nullptr;
}

node* rad = nullptr;

void inserare(int val)
{
    node* newNode = new node(val);
    node* y = nullptr;
    node* x = rad;

    while (x != nullptr)
    {
        y = x;
        if (newNode->val < x->val)
            x = x->copilS;
        else
            x = x->copilD;
    }

    newNode->tata = y;
    if (y == nullptr)
        rad = newNode;
    else if (newNode->val < y->val)
        y->copilS = newNode;
    else
        y->copilD = newNode;

}

node* cautare(int val)
{
    node* nodActual = rad;

    while (nodActual != nullptr && val != nodActual->val)
        if (val < nodActual->val)
            nodActual = nodActual->copilS;
        else
            nodActual = nodActual->copilD;

    return nodActual;
}

node* minimLocal(node* nodActual)
{
    while (nodActual->copilS != nullptr)
        nodActual = nodActual->copilS;

    return nodActual;
}

node* succesor(int val)
{
    node* nodDeCautatSuccesor = cautare(val);

    if (nodDeCautatSuccesor->copilD != nullptr)
        return minimLocal(nodDeCautatSuccesor->copilD);

    node* y = nodDeCautatSuccesor->tata;

    while (y != nullptr && nodDeCautatSuccesor == y->copilD)
    {
        nodDeCautatSuccesor = y;
        y = y->tata;
    }

    return y;

}

void sterge(int val)
{
    node* nodDeSters = cautare(val);

    if (nodDeSters != nullptr)
    {
        node* y = nullptr;
        node* x = nullptr;

        if (nodDeSters->copilS == nullptr || nodDeSters->copilD == nullptr)
            y = nodDeSters;
        else
            y = succesor(nodDeSters->val);

        if (y->copilS != nullptr)
            x = y->copilS;
        else
            x = y->copilD;

        if (x != nullptr)
            x->tata = y->tata;

        if (y->tata == nullptr)
            rad = x;
        else if (y == y->tata->copilS)
            y->tata->copilS = x;
        else
            y->tata->copilD = x;

        if (y != nodDeSters)
            nodDeSters->val = y->val;
    }
}


node* cerinta4(int val)
{
    node* nodActual = rad;
    node* nodMaximal = rad;

    while (nodActual != nullptr)
    {
        if (nodActual->val == val)
            return nodActual;
        else if (nodActual->val < val)
        {
            if (nodActual->copilD == nullptr)
            {
                if (nodActual->val > val)
                    return nodMaximal;
                else
                    return nodActual;
            }
            else if (nodActual->copilD->val <= val)
                nodActual = nodActual->copilD;
            else
            {
                nodMaximal = nodActual;
                nodActual = nodActual->copilD;
            }
        }
        else
        {
            if (nodActual->copilS == nullptr)
            {
                if (nodActual->val > val)
                    return nodMaximal;
                else
                    return nodActual;
            }
            else
                nodActual = nodActual->copilS;
        }

    }
}


node* cerinta5(int val)
{
    node* nodActual = rad;
    node* nodMinimal = rad;

    while (nodActual != nullptr)
    {
        if (nodActual->val == val)
            return nodActual;
        else if (nodActual->val > val)   //se duce pe st
        {
            if (nodActual->copilS == nullptr)
            {
                if (nodActual->val < val)
                    return nodMinimal;
                else
                    return nodActual;
            }
            else if (nodActual->copilS->val >= val)
                nodActual = nodActual->copilS;
            else
            {
                nodMinimal = nodActual;
                nodActual = nodActual->copilS;
            }
        }
        else
        {
            if (nodActual->copilD == nullptr)
            {
                if (nodActual->val < val)
                    return nodMinimal;
                else
                    return nodActual;
            }
            else
                nodActual = nodActual->copilD;
        }

    }
}


void afis(node* nodAfis)
{
    if (nodAfis != nullptr)
    {
        cout << nodAfis->val << " " << nodAfis << endl;
        afis(nodAfis->copilS);
        afis(nodAfis->copilD);
    }
}

int main()
{
    int q, i, x, y, z, zUltim, op;
    in >> q;

    for (i = 1; i <= q; i++)
    {
        in >> op;
        if (op == 1)
        {
            in >> x;
            inserare(x);
        }
        else if (op == 2)
        {
            in >> x;
            sterge(x);
        }
        else if (op == 3)
        {
            in >> x;
            if (cautare(x) != nullptr)
                out << 1 << '\n';
            else
                out << 0 << '\n';
        }
        else if (op == 4)
        {
            in >> x;
            out << cerinta4(x)->val << '\n';
        }
        else if (op == 5)
        {
            in >> x;
            out << cerinta5(x)->val << '\n';
        }
        else if (op == 6)
        {
            in >> x >> y;

            z = cerinta5(x)->val;
            zUltim = cerinta4(y)->val;
            while (z < zUltim)
            {
                out << z << " ";
                z = cerinta5(z + 1)->val;
            }
            out << zUltim << '\n';
        }
    }

    return 0;
}
