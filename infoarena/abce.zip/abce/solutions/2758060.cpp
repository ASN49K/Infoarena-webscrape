#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <numeric>
#include <sstream>
#include <cmath>
#include <set>
#include <stack>
#include <iomanip>
#include <limits.h>
#include <queue>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <exception>
#include <deque>
#include <string>
#include <stdlib.h>

#define m 4
using namespace std;

fstream in_file;
fstream out_file;

struct NodB {
    int nr;
    int chei[m + 1];
    struct NodB* st;
    struct NodB* dr;
    struct NodB* pointerNoduri[m + 1];
};

/*void cautareElement(NodB* nod, int element);
//cauta o cheie in arbore
NodB* inserareCheie(int cheie);
// insereaza cheia citita in B tree si returneaza pointerul corespondent de la radacina

void divizarePagina(NodB* nod, int cheie, int& parinte, int& ok);
// cauta cheia in nodul paginii curente si o insereaza in locul corespunzator
void inserareInPagina(NodB* nod, int pozitie, int cheie, int& parinte, int& ok);
//introducerea cheii in nodul paginii pe pozitia corespunzatoare in vectorul de chei
void inserareFrunza(NodB* nod, int pozitie, int cheie, int& parinte, int& ok);
//inserare in nodul frunza curent care nu este plin

NodB* stergereCheie(NodB** nod, int cheie);
// stergerea unei chei
void afisareArbore(NodB* nod, int nivel);
//afisarea arborelui*/

NodB* pointerParinte, * radacina;

void copiePagina(NodB* destinatie, NodB* sursa, int sursaIndex, int destIndex, int n) {
    //copiaza informatia din pagina sursa in pagina destinatie incepand cu index ul
    while (n > 0) { //nr chei din pag
        n--;        
        destinatie->chei[destIndex + n] = sursa->chei[sursaIndex + n];      //copia cheilor
        destinatie->pointerNoduri[destIndex + n] = sursa->pointerNoduri[sursaIndex + n]; //adresa descendentilor
    }
}

void inserareFrunza(NodB* nod, int pozitie, int cheieX, int& parinte, int& ok) {   //introducere in frunza
    NodB* adr; //pointer la un nod
    int ind; //pozitia
    ok = 0;
    nod->nr = nod->nr + 1;
    copiePagina(nod, nod, pozitie, pozitie + 1, nod->nr - pozitie); //inserare in aceeasi pagina pe urmatoarea pozitie
    nod->pointerNoduri[pozitie] = pointerParinte; 
    nod->chei[pozitie] = parinte;
    if (parinte == cheieX) {
        ind = pozitie;
        adr = nod;
    }

}

void inserareInPagina(NodB* nod, int pozitie, int cheieX, int& parinte, int& ok) {   //inserarea efectiva a lui X in pagina in pozitia corespunzatoare in vectorul de chei
    NodB* pv; //copie a parintelui
    int cheie;
    int jumatate; //nr min de chei dintr o pagina
    jumatate = nod->nr / 2;
    if (nod->nr == m) {  //daca e fuzionabila 
        pv = new NodB;
        pv->nr = jumatate;
        nod->nr = jumatate;
        if (pozitie > jumatate) {   //jumatatea dreapta a paginii
            if (pozitie == jumatate + 1) {
                copiePagina(pv, nod, jumatate + 1, 1, jumatate); 
                pv->pointerNoduri[0] = pointerParinte;
            }
            else { // urca elementul cheie[n+1]
                pozitie = pozitie - jumatate - 1;
                copiePagina(pv, nod, jumatate + 2, 1, pozitie - 1);
                pv->chei[pozitie] = parinte;
                pv->pointerNoduri[pozitie] = pointerParinte;
                copiePagina(pv, nod, jumatate + pozitie + 1, pozitie + 1, jumatate - pozitie);
                pv->pointerNoduri[0] = nod->pointerNoduri[jumatate + 1];
                parinte = nod->chei[jumatate + 1];
            }
        }
        else {    //jumatatea stanga a paginii
            copiePagina(pv, nod, jumatate + 1, 1, jumatate);
            pv->pointerNoduri[0] = nod->pointerNoduri[jumatate];
            cheie = nod->chei[jumatate];
            copiePagina(nod, nod, pozitie, pozitie + 1, jumatate - pozitie);
            nod->pointerNoduri[pozitie] = pointerParinte;
            nod->chei[pozitie] = parinte;
            parinte = cheie;
        }
        pointerParinte = pv;
    }
    else
        inserareFrunza(nod, pozitie, cheieX, parinte, ok); //face inserarea simpla in frunza
}

void divizarePagina(NodB* nod, int cheieX, int& parinte, int& ok) {   // cauta X ul in pagina curenta si il insereaza in locul corespunzator
    NodB* adr;
    int ind, gasit;
    int pozitie, new1;
    if (nod == NULL) {       //nu e gasit
        ok = 1;
        new1 = 1;
        parinte = cheieX;
        pointerParinte = NULL;
    }
    else {           //e gasit, deci cauta in pagina curenta
        pozitie = 1;
        gasit = 0;
        while (pozitie <= nod->nr && !gasit)
        {
            if (nod->chei[pozitie] >= cheieX)
                gasit = 1;
            pozitie++;
        }
        if (gasit)
            pozitie--;  //!= gasit
        if (pozitie > nod->nr)
            gasit = 0;
        else {
            if (nod->chei[pozitie] == cheieX)
                gasit = 1;
            else
                gasit = 0;
        }
        if (gasit) {
            new1 = 0;
            adr = nod;
            ind = pozitie;
            ok = 0;
        }
        else {
            divizarePagina(nod->pointerNoduri[pozitie - 1], cheieX, parinte, ok); //cautare recursiv
            if (ok)
                inserareInPagina(nod, pozitie, cheieX, parinte, ok);  //X e inserat in pagina
        }
    }
}

NodB* inserareCheie(int cheie) {       // insereaza cheia citita in arbore si returneaza pointer ul corespunzator parintelui
    int ind, cheieX, parinte, ok;
    NodB* pv;
    NodB* adr;
    cheieX = cheie;
    //cautare incepand cu partea radacinii inserarii lui X
    divizarePagina(radacina, cheieX, parinte, ok);
    if (ok) {
        //pv = (NodB*)malloc(100);
        pv = new NodB;
        pv->pointerNoduri[0] = radacina;
        pv->pointerNoduri[1] = pointerParinte;
        pv->chei[1] = parinte;
        pv->nr = 1;
        radacina = pv;
    }
    if (cheieX == parinte) {
        adr = radacina;
        ind = 1;
    }
    return radacina;
}

void cautareElement(NodB* nod, int element) { //cautarea unui element                                   
    int pozitie, ok;
    if (nod == nullptr) {  //!=ok
        out_file << "0\n"; //cheia nu exista in arbore
    }
    else { //cautare in pagina curenta
        pozitie = 1;
        ok = 0;
        while ((pozitie <= nod->nr) && (!ok)) {
            ok = (nod->chei[pozitie] == element);
            pozitie++;
        }
        if (ok) {
            pozitie--;
            cout << "1\n";  //e gasit, ok e true, elementul exista 
        }
        else {
            if (pozitie > nod->nr) {
                ok = 0;
            }
            else {
                ok = (nod->chei[pozitie] == element);
            }
            if (ok) {
                out_file << "1\n"; //cheia exista in arbore
            }
            else {
                cautareElement(nod->pointerNoduri[pozitie - 1], element);
            }
        }
    }
}

NodB* cautarePNod(NodB* nod, int element) { //cautarea unui element (pointerul la un nod)       
    //cauta elementul si returneaza nodul in care se afla
    int pozitie, ok;
    if (nod == nullptr) {  //!=ok
        return nullptr; //cheia nu exista in arbore
    }
    else { //cautare in pagina curenta
        pozitie = 1;
        ok = 0;
        while ((pozitie <= nod->nr) && (!ok)) {
            ok = (nod->chei[pozitie] == element);
            pozitie++;
        }
        if (ok) {
            pozitie--;
            return nod;  //e gasit, ok e true, elementul exista in nod
        }
        else {
            if (pozitie > nod->nr) {
                ok = 0;
            }
            else {
                ok = (nod->chei[pozitie] == element);
            }
            if (ok) {
                out_file << nod; //cheia exista in arbore
            }
            else {
                cautarePNod(nod->pointerNoduri[pozitie - 1], element);
            }
        }
    }
}

int aux_gasire;


int CautaSuccesor(NodB* pagina, int valoare) //cauta cea mai mica valoare mai mare decat "valoare"
{
    int pozitie = 0;
    while (pozitie < pagina->nr && valoare > pagina->chei[pozitie])
        pozitie++;

    if (pozitie<pagina->nr && pagina->chei[pozitie]>valoare)
        aux_gasire = pagina->chei[pozitie];

    if (pagina->st == NULL && pagina->dr == NULL)
        return aux_gasire;

    return CautaSuccesor(pagina->pointerNoduri[pozitie], valoare);

}

int GasesteSuccesor(int valoare) //gaseste cea mai mica valoare mai mare decat "valoare"
{
    aux_gasire = INT_MIN;
    NodB* nodCuVal = cautarePNod(radacina, valoare);
    if (nodCuVal == nullptr)
    {
        return CautaSuccesor(radacina, valoare);
    }
    else
        return valoare; //valoare gasita

}

int CautaPredecesor(NodB* pagina, int valoare) //cauta cea mai mare valoare mai mica decat "valoare"
{

    int pozitie = pagina->nr - 1;
    while (pozitie >= 0 && pagina->chei[pozitie] > valoare)
        pozitie--;

    if (pozitie >= 0 && pagina->chei[pozitie] < valoare)
        aux_gasire = pagina->chei[pozitie];

    if (pagina->st == NULL && pagina->dr == NULL)
        return aux_gasire;

    return CautaPredecesor(pagina->pointerNoduri[pozitie + 1], valoare);

}

int GasestePredecesor(int valoare) //gaseste cea mai mare valoare mai mica decat "valoare"
{
    aux_gasire = INT_MIN; //valoarea posibila

    NodB* rez = cautarePNod(radacina, valoare);
    if (rez == nullptr)
    {
        return CautaPredecesor(radacina, valoare);
    }
    else
        return valoare; //valoare gasita

}

void afisareArbore(NodB* nod, int nivel) {   //afisarea arborelui
    int j;
    if (nod != nullptr) {
        for (j = 1; j <= nivel; j++)
            cout << " ";
        for (j = 1; j <= nod->nr; j++)
            cout << nod->chei[j] << " ";  //afiseaza cheile
        cout << "\n";
        for (j = 0; j <= nod->nr; j++)
            afisareArbore(nod->pointerNoduri[j], nivel + 1);
    }
}

int cautareMinim(NodB* pagina) { //valoarea minima din arbore (cea mai din stanga frunza)
    if (pagina->pointerNoduri[0] == NULL)
        return pagina->chei[1];
    else
        return cautareMinim(pagina->pointerNoduri[0]);
}

int cautareMaxim(NodB* pagina) { //valoarea maxima din arbore(cea mai din dreapta frunza)
    if (pagina->pointerNoduri[m] == NULL)
        return pagina->chei[m - 1];
    else
        return cautareMaxim(pagina->pointerNoduri[m]);
}

NodB* stergereCheie(NodB** nod, int cheie) {    //stergerea unei chei 
    NodB* temp; //copie pt radacina
    int i = 1, j, nr = (*nod)->nr;
    NodB* fiu = NULL;
    NodB* creditor; //vecinul de la care imprumutam pentru a "umple" pagina din care am sters
    if ((*nod)->chei[nr] < cheie) {     //cheie are acces doar la ultimul nod fiu
        fiu = (*nod)->pointerNoduri[nr];
        i = nr;
        if (fiu == NULL) { // cheia de sters nu e gasita in arbore
            return radacina;
        }
    }
    else { //cheia poate fi gasita intr-un nod sau in fiu
        while (cheie > (*nod)->chei[i])
            i++;
        if (cheie == (*nod)->chei[i]) {   //gasit in nodul curent
            if ((*nod)->pointerNoduri[i] == NULL) {  //este frunza
                for (; i < nr; i++) {  //mut cu o pozitie in stanga cheile ramase dupa stergere
                    (*nod)->chei[i] = (*nod)->chei[i + 1];
                }
                (*nod)->nr--; //nivelul este gol
                return radacina;
            }   // cauta succesorul cheii sterse
            cheie = cautareMinim((*nod)->pointerNoduri[i]);
            (*nod)->chei[i] = cheie;
            fiu = (*nod)->pointerNoduri[i]; //fiul nodului nod de pe pozitia i
        }
        else {// cheie e mai mic decat cheie[i]
        //i va fi mereu indexul cheii care trebuie decrementat
            i--;
            fiu = (*nod)->pointerNoduri[i];
        }
    }

    //stergere din fiu
    stergereCheie(&fiu, cheie);  //cautam daca avem numarul de chei in fiu
    if (fiu->nr < (m / 2)) {
        if (i > 0) {    //fiul nu e primul nod
            creditor = (*nod)->pointerNoduri[i - 1];
            if (creditor->nr > (m / 2)) {   //spatiu pentru imprumut
                for (j = fiu->nr; j > 0; j--) {
                    fiu->chei[j + 1] = fiu->chei[j];
                    fiu->pointerNoduri[j + 1] = fiu->pointerNoduri[j];
                }   //primul nod nu e mutat
                fiu->pointerNoduri[1] = fiu->pointerNoduri[0];
                fiu->nr++;  //imprumuta o cheie din stanga, prin parinte 
                fiu->chei[1] = (*nod)->chei[i];
                (*nod)->chei[i] = creditor->chei[creditor->nr];
                fiu->pointerNoduri[0] = creditor->pointerNoduri[creditor->nr]; // nodul din stanga are cu o cheie mai putin
                creditor->nr--;
            }
            else { //nodul din stanga are prea putine chei, asa ca fuzionam nodurile
                j = creditor->nr + 1; //iau cheile din parinte
                creditor->chei[j] = (*nod)->chei[i];
                creditor->pointerNoduri[j] = fiu->pointerNoduri[0];
                for (; i < nr - 1; i++) { //cheile ramase dupa stergere merg in stanga cu o pozitie
                    (*nod)->chei[i] = (*nod)->chei[i + 1];
                    (*nod)->pointerNoduri[i] = (*nod)->pointerNoduri[i + 1];
                }// parintele are cu un fiu mai putin
                (*nod)->nr--;
                creditor->nr += 1 + fiu->nr;
                while (fiu->nr > 0) {
                    creditor->chei[j + fiu->nr] = fiu->chei[fiu->nr];
                    fiu->nr--;
                }
                free(fiu);
            }
        }
        else {//fiu e primul nod
            creditor = (*nod)->pointerNoduri[1];
            if (creditor->nr > (m / 2)) {//imprumut
                fiu->nr++;//imprumut o cheie din nodul drept prin parinte
                fiu->pointerNoduri[fiu->nr] = creditor->pointerNoduri[0];
                fiu->chei[fiu->nr] = (*nod)->chei[1];//mut catre stanga cheia creditor
                (*nod)->chei[1] = creditor->chei[1];
                creditor->pointerNoduri[0] = creditor->pointerNoduri[1];
                for (j = 1; j < creditor->nr; j++) {
                    creditor->chei[j] = creditor->chei[j + 1];
                    creditor->pointerNoduri[j] = creditor->pointerNoduri[j + 1];
                }// nodul drept are cu o cheie mai putin
                creditor->nr--;
            }
            else {//nodul drept are prea putine chei, deci fuzionam
                j = fiu->nr + 1;//luam o cheie din parinte
                i = 1;
                fiu->chei[j] = (*nod)->chei[i];
                fiu->pointerNoduri[j] = creditor->pointerNoduri[0];
                for (; i < nr; i++) {//mut toate cheile sterse din dreapta catre stanga cu o pozitie
                    (*nod)->chei[i] = (*nod)->chei[i + 1];
                    (*nod)->pointerNoduri[i] = (*nod)->pointerNoduri[i + 1];
                }//parintele are cu un fiu mai putin
                (*nod)->nr--;
                fiu->nr += 1 + creditor->nr;
                while (creditor->nr > 0) {
                    fiu->chei[j + creditor->nr] = creditor->chei[creditor->nr];
                    fiu->pointerNoduri[j + creditor->nr] = creditor->pointerNoduri[creditor->nr];
                    creditor->nr--;
                }
                delete creditor;
            }
        }
    }
    if ((radacina)->nr == 0) {//nu avem nicio cheie in radacina
        temp = radacina;
        radacina = (radacina)->pointerNoduri[0];
        delete temp;
    }
    return radacina;
}


int main() {
    in_file.open("abce.in");
    out_file.open("abce.out", ios::out);
    int cheie, cheieX, cheieY;
    NodB* rad;
    rad = NULL;

    int Q, aux;
    in_file >> Q;
    while (Q--) {

        in_file >> aux;

        switch (aux) {
        case 1:
            in_file >> cheieX;
            rad = inserareCheie(cheieX);
            break;

        case  2:
            in_file >> cheieX;
            rad = stergereCheie(&rad, cheieX);
            break;

        case 3:
            in_file >> cheieX;
            cautareElement(rad, cheieX);
            break;

        case 4:
            in_file >> cheieX;
            out_file << GasestePredecesor(cheieX) << "\n";
            break;

        case 5:
            in_file >> cheieX;
            out_file << GasesteSuccesor(cheieX) << "\n";
            break;
        }
    }
}