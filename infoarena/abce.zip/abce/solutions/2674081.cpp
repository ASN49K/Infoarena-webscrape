#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define debug(x) cerr << #x << " " << x << "\n"
#define debug_with_space(x) cerr << #x << " " << x << " "

using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
typedef pair <ll, ll> pii;
typedef pair <ll, pii> piii;
typedef tree <pii, null_type, less <pii>, rb_tree_tag, tree_order_statistics_node_update> OST;

const ll NMAX = 200001;
const ll INF = (1 << 16) - 1;
const ll MOD = 1000000007;
const ll BLOCK = 101;
const ll nr_of_bits = 20;

multiset <int> s;

int main() {
    int i;
    ifstream cin("abce.in");
    ofstream cout("abce.out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    while(n--){
        int a, b;
        cin >> a >> b;
        if(a == 1){
            s.insert(b);
        }else if(a == 2){
            s.erase(b);
        }else if(a == 3){
            if(s.find(b) != s.end())
                cout << 1 << "\n";
            else
                cout << 0 << "\n";
        }else if(a == 4){
            cout << *(--s.upper_bound(b)) << "\n";
        }else if(a == 5){
            cout << *s.lower_bound(b) << "\n";
        }else{
            int c;
            cin >> c;
            auto it = s.lower_bound(b);
            while(it != s.end() && (int)(*it) <= c)
            {
                cout << *it << " ";
                ++it;
            }
            cout << "\n";
        }
    }
    return 0;
}
