#include <iostream>
#include <list>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");


struct Node
{
    int data;
    Node* left;
    Node* right;
};


struct Node* newNode(int data)
{
    struct Node* node = new Node;
    node->data = data;
    node->left = node->right = NULL;
    
    return node;
}


void insert(Node* &root, int data)
{
    if(root == nullptr)
    {
        root = newNode(data);
        return;
    }

    if(data < root->data)
    {
        insert(root->left, data);
    }

    else
    {
        insert(root->right, data);
    }
}


Node* search(Node* root, int data) {
    if (root == nullptr) {

        return NULL;
    }

    if (root->data == data) {
     
        return root;
    }

    if (data < root->data) {
        return search(root->left, data);
    } else {
        return search(root->right, data);
    }
}



void deleteNode(Node* &root, int data)
{
    if(root == nullptr)
    {
        return;
    }

    if(data < root->data)
    {
        deleteNode(root->left, data);
    }

    else if(data > root->data)
    {
        deleteNode(root->right, data);
    }

    else
    {
        if(root->left == NULL && root->right == NULL)
        {
            delete root;
            root = NULL;
        }

        else if(root->left == NULL)
        {
            Node* temp = root;
            root = root->right;
            delete temp;
        }

        else if(root->right == NULL)
        {
            Node* temp = root;
            root = root->left;
            delete temp;
        }

        else
        {
            Node* temp = root->right;

            while(temp->left != NULL)
            {
                temp = temp->left;
            }

            root->data = temp->data;
            deleteNode(root->right, temp->data);
        }
    }
}


void search_min(Node* root)
{
    if(root == NULL)
    {
        return;
    }

    if(root->left == NULL)
{
        return;
    }

    search_min(root->left);
}


void search_max(Node* root)
{
    if(root == NULL)
    {
        return;
    }

    if(root->right == NULL)
    {
        return;
    }

    search_max(root->right);
}


int find_highest_lower(Node* root, int datax, int &max_val)
{
    if(root == nullptr)
    {
        return max_val;
    }


    if(root->data < datax)
    {
        max_val = max(max_val, root->data);
        return find_highest_lower(root->right, datax, max_val);
    }
    else
    {
        return find_highest_lower(root->left, datax, max_val);
    }
}


int find_lowest_higher(Node* root, int data, int& min_val)
{
    if(root == nullptr)
    {
        return min_val;
    }


    if(root->data > data)
    {
        min_val = (min_val == 0) ? root->data : min(min_val, root->data);
        return find_lowest_higher(root->left, data, min_val);
    }
    else
    {
        return find_lowest_higher(root->right, data, min_val);
    }
}


void sort_interval(Node* root, int a, int b)
{
    if(root == NULL)
    {
        return;
    }

    sort_interval(root->left, a, b);

    if(root->data >= a && root->data <= b)
    {
        fout<<root->data<<" ";
    }

    sort_interval(root->right, a, b);
}



void print(Node* root)
{

    if(root == NULL)
    {
        return;
    }

    print(root->left);
    cout<<root->data<<" ";
    print(root->right);
}





int main()
{



Node* root = nullptr;

    
int op_num;

fin>>op_num;

int max = 0;
int min = 0;

int val;
int val2;

while(op_num)
    { 

        int op;
        fin>>op;
        

      if (op==1 && root == nullptr)
        fin>>val, root = newNode(val);

      else if(op == 1)
        fin>>val, insert(root, val);

      else if (op==2)
        fin>>val, deleteNode(root, val);

      else if (op==3)
        {
            fin>>val;
            Node* found = search(root, val);
            if (found != NULL)
            fout<<1<<endl;
            else fout<<0<<endl;
        }

      else if (op==4){

        fin>>val;
        int m = find_highest_lower(root, val, max);
        fout<<m<<endl;

      }

      else if (op==5)
        {
            fin>>val;
            int n = find_lowest_higher(root, val, min);
            fout<<n<<endl;
        }

      else fin>>val>>val2, sort_interval(root, val, val2), fout<<endl;

      op_num--;

    }


    
    return 0;
}


/*

          6
          /\
          4   8
          /\   /\
          1 9   5 10
*/