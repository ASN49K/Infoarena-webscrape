#include <fstream>
#include <set>
using namespace std;
ifstream cin("abce.in");
ofstream cout("abce.out");
int n, cer, x, y;
set<int>s;
int main() {
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>cer>>x;
        if(cer==6){
            cin>>y;
            auto poz1=s.lower_bound(x);
            auto poz2=s.upper_bound(y);
            for(auto it=poz1;it!=poz2;it++){
                cout<<*it<<" ";
            }
        }
        if(cer==1){
            s.insert(x);
        }
        if(cer==2){
            s.erase(x);
        }
        if(cer==3){
            if(s.find(x)!=s.end())
                cout<<1<<"\n";
            else cout<<0<<"\n";
        }
        if(cer==4){
            auto poz2=s.upper_bound(x);
            poz2--;
            cout<<*poz2<<"\n";
        }
        if(cer==5){
            auto poz1=s.lower_bound(x);
            cout<<*poz1<<"\n";
        }
    }


}
