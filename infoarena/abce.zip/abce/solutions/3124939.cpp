#include <iostream>
#include <fstream>

using namespace std;

/// Arbore binar de cautare echilibrat (de imbunatatit candva).

/// Functii
/*
insereaza(x) = insereaza valoarea x in arbore
sterge(x, stergereCompleta) = sterge valoarea x din arbore. Daca stergereCompleta e pus pe true, atunci sterge toate aparitiile valorii x din arbore, altfel sterge doar o aparitie. Implicit, stergereCompleta = false.
cauta(x) = returneaza adresa nodului unde valoarea x e stocata, altfel returneaza nullptr daca nu gaseste valoarea x in arbore.
succesorDistinct(Nod*) = returneaza adresa nodului care contine cea mai mica valoare strict mai mare decat valoarea din nodul dat ca parametru. Daca nu exista, returneaza nullptr.
predecesorDistinct(Nod*) = returneaza adresa nodului care contine cea mai mare valoare strict mai mica decat valoarea din nodul dat ca parametru. Daca nu exista, returneaza nullptr.
afiseazaCrescator(out) = afiseaza elementele din arbore in ordine crescatoare
afiseazaDescrescator(out) = afiseaza elementele din arbore in ordine descrescatoare
maximSubSauEgalCu(x) = returneaza adresa nodului care contine o valoare maxima care este mai mica sau egala cu x. Daca nu exista, returneaza nullptr.
minimPesteSauEgalCu(x) = returneaza adresa nodului care contine o valoare minima, care este mai mare sau egala cu x. Daca nu exista, returneaza nullptr.
alNleaElementDistinct(index) = returneaza adresa nodului care contine al N-lea element distinct ca valoare din arbore. Daca nu exista, returneaza nullptr. Indexarea este de la 0.

+alte posibile chestii ce pot fi implementate
*/
///

class ABCE;

class Nod
{
public:

    int valoare;
    int frecventa;

private:

    static const int NR_FII = 2;

    Nod* tata;
    int pozInTata;
    Nod* fii[Nod::NR_FII];
    int inaltimeSubArbore;
    int dimensiuneSubArbore;
    int sumaFrecventeSubArbore;

    bool esteRadacina;

    Nod() : valoare(0), frecventa(0), tata(nullptr), pozInTata(-1), inaltimeSubArbore(0), dimensiuneSubArbore(0), sumaFrecventeSubArbore(0), esteRadacina(false)
    {
        for (int i = 0; i < Nod::NR_FII; ++i)
            this->fii[i] = nullptr;
    }

    friend class ABCE;
};

class ABCE
{
private:

    static const int INFINIT = 1e9 + 1;

    Nod* radacina;

    void stergeSubArboreInDestructor(Nod* nod);
    void insereaza(int x, Nod* nod);
    void sterge(int x, Nod* nod, bool stergereCompleta);
    void afiseazaCrescator(ostream& out, Nod* nod) const;
    void afiseazaDescrescator(ostream& out, Nod* nod) const;
    void recalculeazaParametriiSubArbore(Nod* nod);
    Nod* cauta(Nod* nod, int x, int st, int dr) const;
    void recalculeazaParametriiSubArborePeLant(Nod* inceput, Nod* sfarsit);
    Nod* maximSubSauEgalCu(Nod* nod, int x) const;
    Nod* minimPesteSauEgalCu(Nod* nod, int x) const;
    Nod* rotesteStanga(Nod* nod);
    Nod* rotesteDreapta(Nod* nod);
    Nod* rebalanseazaNod(Nod* nod);
    Nod* rebalanseazaLant(Nod* inceput, Nod* sfarsit);
    Nod* alNleaElementDistinct(Nod* nod, int index) const;

    void debugArbore(ostream& out, Nod* nod) const;

public:

    ABCE()
    {
        this->radacina = new Nod();
        this->radacina->esteRadacina = true;
    }

    void insereaza(int x);
    void sterge(int x, bool stergereCompleta = false);
    void afiseazaCrescator(ostream& out = std::cout) const;
    void afiseazaDescrescator(ostream& out = std::cout)const;
    Nod* cauta(int x) const;
    Nod* maximSubSauEgalCu(int x) const;
    Nod* minimPesteSauEgalCu(int x) const;

    Nod* succesorDistinct(Nod* nod) const;
    Nod* predecesorDistinct(Nod* nod) const;

    Nod* alNleaElementDistinct(int index) const;

    inline int dimensiune() const /// returneaza numarul de noduri din arbore (i.e. numarul de valori distincte)
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->dimensiuneSubArbore;
        return 0;
    }

    inline int numarElemente() const /// returneaza numarul de valori (distincte sau nu) din tot arborele
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->sumaFrecventeSubArbore;
        return 0;
    }

    ~ABCE()
    {
        this->stergeSubArboreInDestructor(this->radacina);
    }

    void debugArbore(ostream& out = std::cout) const;
};

void ABCE::debugArbore(ostream& out, Nod* nod) const
{
    out << "Nodul: " << nod->valoare << '\n';

    out << "Valori nod: " << '\n';

    out << "Inaltime: " << nod->inaltimeSubArbore << '\n';
    out << "Dimensiune subarbore: " << nod->dimensiuneSubArbore << '\n';
    out << "Suma frecvente subarbore: " << nod->sumaFrecventeSubArbore << '\n';

    out << "Fii: " << '\n';

    if (nod->fii[0] != nullptr)
        out << nod->fii[0]->valoare << ' ';
    else
        out << "nullptr" << ' ';
    if (nod->fii[1] != nullptr)
        out << nod->fii[1]->valoare << '\n';
    else
        out << "nullptr" << '\n';

    if (nod->fii[0] != nullptr)
        this->debugArbore(out, nod->fii[0]);
    if (nod->fii[1] != nullptr)
        this->debugArbore(out, nod->fii[1]);
}

void ABCE::debugArbore(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->debugArbore(out, this->radacina->fii[1]);
    else
        out << "Arborele este vid!" << '\n';
}

Nod* ABCE::alNleaElementDistinct(Nod* nod, int index) const
{
    if (nod->fii[0] != nullptr)
    {
        if (nod->fii[0]->dimensiuneSubArbore > index)
            return this->alNleaElementDistinct(nod->fii[0], index);
        else
        {
            index -= nod->fii[0]->dimensiuneSubArbore;

            if (index == 0)
                return nod;
            else
            {
                --index;

                if (nod->fii[1] != nullptr)
                    return this->alNleaElementDistinct(nod->fii[1], index);
                else
                    return nullptr;
            }
        }
    }
    else
    {
        if (index == 0)
            return nod;
        else
        {
            --index;

            if (nod->fii[1] != nullptr)
                return this->alNleaElementDistinct(nod->fii[1], index);
            else
                return nullptr;
        }
    }
}

Nod* ABCE::alNleaElementDistinct(int index) const
{
    if (this->radacina->fii[1] == nullptr)
        return nullptr;

    if (index < 0 || this->dimensiune() <= index)
        return nullptr;

    this->alNleaElementDistinct(this->radacina->fii[1], index);
}

Nod* ABCE::rebalanseazaLant(Nod* inceput, Nod* sfarsit)
{
    if (inceput == nullptr || sfarsit == nullptr)
        return nullptr;

    if (inceput->esteRadacina || sfarsit->esteRadacina)
        return nullptr;

    while (inceput != sfarsit)
    {
        inceput = this->rebalanseazaNod(inceput);
        this->recalculeazaParametriiSubArbore(inceput);
        inceput = inceput->tata;
    }

    inceput = this->rebalanseazaNod(inceput);
    this->recalculeazaParametriiSubArbore(inceput);

    return inceput;
}

Nod* ABCE::rebalanseazaNod(Nod* nod)
{
    if (nod->esteRadacina)
        return nod;

    if (nod->fii[0] != nullptr)
    {
        int inaltimeFiuStang = 0;
        if (nod->fii[0]->fii[0] != nullptr)
            inaltimeFiuStang = nod->fii[0]->fii[0]->inaltimeSubArbore;
        int inaltimeFiuDrept = 0;
        if (nod->fii[0]->fii[1] != nullptr)
            inaltimeFiuDrept = nod->fii[0]->fii[1]->inaltimeSubArbore;

        if (inaltimeFiuStang == inaltimeFiuDrept + 2) /// Cazul Left-Left (LL)
            nod = this->rotesteDreapta(nod);
        else if (inaltimeFiuStang + 2 == inaltimeFiuDrept) /// Cazul Left-Right (LR)
        {
            this->rotesteStanga(nod->fii[0]);
            nod = this->rotesteDreapta(nod);
        }
    }

    if (nod->fii[1] != nullptr)
    {
        int inaltimeFiuStang = 0;
        if (nod->fii[1]->fii[0] != nullptr)
            inaltimeFiuStang = nod->fii[1]->fii[0]->inaltimeSubArbore;
        int inaltimeFiuDrept = 0;
        if (nod->fii[1]->fii[1] != nullptr)
            inaltimeFiuDrept = nod->fii[1]->fii[1]->inaltimeSubArbore;

        if (inaltimeFiuDrept == inaltimeFiuStang + 2) /// Cazul Right-Right (RR)
            nod = this->rotesteStanga(nod);
        else if (inaltimeFiuStang == inaltimeFiuDrept + 2) /// Cazul Right-Left (RL)
        {
            this->rotesteDreapta(nod->fii[1]);
            nod = this->rotesteStanga(nod);
        }
    }

    /*
    int inaltimeFiuStang = 0;
    if (nod->fii[0] != nullptr)
        inaltimeFiuStang = nod->fii[0]->inaltimeSubArbore;
    int inaltimeFiuDrept = 0;
    if (nod->fii[1] != nullptr)
        inaltimeFiuDrept = nod->fii[1]->inaltimeSubArbore;

    if (inaltimeFiuStang + 2 == inaltimeFiuDrept)
        nod = this->rotesteStanga(nod);
    if (inaltimeFiuStang == inaltimeFiuDrept + 2)
        nod = this->rotesteDreapta(nod);
        */

    return nod;
}

Nod* ABCE::rotesteStanga(Nod* nod)
{
    if (nod->esteRadacina || nod->fii[1] == nullptr)
        return nod;

    Nod* nodDrept = nod->fii[1];

    Nod* fiuStangNodDrept = nodDrept->fii[0];

    if (fiuStangNodDrept == nullptr)
        nod->fii[1] = nullptr;
    else
    {
        nod->fii[1] = fiuStangNodDrept;
        fiuStangNodDrept->tata = nod;
        fiuStangNodDrept->pozInTata = 1;
    }

    nodDrept->fii[0] = nod;
    nodDrept->tata = nod->tata;
    nod->tata->fii[nod->pozInTata] = nodDrept;
    nodDrept->pozInTata = nod->pozInTata;
    nod->tata = nodDrept;
    nod->pozInTata = 0;

    this->recalculeazaParametriiSubArbore(nod);
    this->recalculeazaParametriiSubArbore(nodDrept);

    return nodDrept;
}

Nod* ABCE::rotesteDreapta(Nod* nod)
{
    if (nod->esteRadacina || nod->fii[0] == nullptr)
        return nod;

    Nod* nodStang = nod->fii[0];

    Nod* fiuDreptNodStang = nodStang->fii[1];

    if (fiuDreptNodStang == nullptr)
        nod->fii[0] = nullptr;
    else
    {
        nod->fii[0] = fiuDreptNodStang;
        fiuDreptNodStang->tata = nod;
        fiuDreptNodStang->pozInTata = 0;
    }

    nodStang->fii[1] = nod;
    nodStang->tata = nod->tata;
    nod->tata->fii[nod->pozInTata] = nodStang;
    nodStang->pozInTata = nod->pozInTata;
    nod->tata = nodStang;
    nod->pozInTata = 1;

    this->recalculeazaParametriiSubArbore(nod);
    this->recalculeazaParametriiSubArbore(nodStang);

    return nodStang;
}

Nod* ABCE::maximSubSauEgalCu(Nod* nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->maximSubSauEgalCu(nod->fii[0], x);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
        {
            Nod* nodDreapta = this->maximSubSauEgalCu(nod->fii[1], x);

            if (nodDreapta == nullptr)
                return nod;
            else
                return nodDreapta;
        }
        else
            return nod;
    }
}

Nod* ABCE::minimPesteSauEgalCu(Nod* nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
        {
            Nod* nodStanga = this->minimPesteSauEgalCu(nod->fii[0], x);

            if (nodStanga == nullptr)
                return nod;
            else
                return nodStanga;
        }
        else
            return nod;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->minimPesteSauEgalCu(nod->fii[1], x);
        else
            return nullptr;
    }
}

Nod* ABCE::maximSubSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->maximSubSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

Nod* ABCE::minimPesteSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->minimPesteSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

void ABCE::recalculeazaParametriiSubArborePeLant(Nod* inceput, Nod* sfarsit)
{
    if (inceput == nullptr || sfarsit == nullptr)
        return;

    if (inceput->esteRadacina || sfarsit->esteRadacina)
        return;

    while (inceput != sfarsit)
    {
        this->recalculeazaParametriiSubArbore(inceput);
        inceput = inceput->tata;
    }

    this->recalculeazaParametriiSubArbore(inceput);
}

void ABCE::stergeSubArboreInDestructor(Nod* nod)
{
    for (int i = 0; i < Nod::NR_FII; ++i)
        if (nod->fii[i] != nullptr)
            stergeSubArboreInDestructor(nod->fii[i]);

    delete nod;
}

Nod* ABCE::succesorDistinct(Nod* nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas dreapta, apoi maxima stanga
    if (solutie->fii[1] != nullptr)
    {
        solutie = solutie->fii[1];

        while (solutie->fii[0] != nullptr)
            solutie = solutie->fii[0];
    }
    else /// altfel urcam cat timp venim din fiul drept si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 1 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 0 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::predecesorDistinct(Nod* nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas stanga, apoi maxima dreapta
    if (solutie->fii[0] != nullptr)
    {
        solutie = solutie->fii[0];

        while (solutie->fii[1] != nullptr)
            solutie = solutie->fii[1];
    }
    else /// altfel urcam cat timp venim din fiul stang si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 0 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 1 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::cauta(Nod* nod, int x, int st, int dr) const
{
    if (x < st || dr < x)
        return nullptr;

    if (nod->valoare == x && nod->frecventa > 0)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->cauta(nod->fii[0], x, st, nod->valoare - 1);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->cauta(nod->fii[1], x, nod->valoare + 1, dr);
        else
            return nullptr;
    }
}

Nod* ABCE::cauta(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->cauta(this->radacina->fii[1], x, -ABCE::INFINIT, +ABCE::INFINIT);
    return nullptr;
}

void ABCE::recalculeazaParametriiSubArbore(Nod* nod)
{
    nod->inaltimeSubArbore = 1;
    if (nod->fii[0] != nullptr)
        nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[0]->inaltimeSubArbore + 1);
    if (nod->fii[1] != nullptr)
        nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[1]->inaltimeSubArbore + 1);

    nod->dimensiuneSubArbore = 1;
    if (nod->fii[0] != nullptr)
        nod->dimensiuneSubArbore += nod->fii[0]->dimensiuneSubArbore;
    if (nod->fii[1] != nullptr)
        nod->dimensiuneSubArbore += nod->fii[1]->dimensiuneSubArbore;

    nod->sumaFrecventeSubArbore = nod->frecventa;
    if (nod->fii[0] != nullptr)
        nod->sumaFrecventeSubArbore += nod->fii[0]->sumaFrecventeSubArbore;
    if (nod->fii[1] != nullptr)
        nod->sumaFrecventeSubArbore += nod->fii[1]->sumaFrecventeSubArbore;
}

void ABCE::insereaza(int x)
{
    if (this->radacina->fii[1] == nullptr)
    {
        this->radacina->fii[1] = new Nod();
        this->radacina->fii[1]->valoare = x;
        this->radacina->fii[1]->frecventa = 1;
        this->radacina->fii[1]->tata = this->radacina;
        this->radacina->fii[1]->pozInTata = 1;
        this->radacina->fii[1]->inaltimeSubArbore = 1;
        this->radacina->fii[1]->dimensiuneSubArbore = 1;
        this->radacina->fii[1]->sumaFrecventeSubArbore = 1;
    }
    else
        this->insereaza(x, this->radacina->fii[1]);
}

void ABCE::insereaza(int x, Nod* nod)
{
    if (nod->valoare == x)
    {
        ++nod->frecventa;
        ++nod->sumaFrecventeSubArbore;
        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] == nullptr)
        {
            nod->fii[1] = new Nod();
            nod->fii[1]->valoare = x;
            nod->fii[1]->frecventa = 1;
            nod->fii[1]->tata = nod;
            nod->fii[1]->pozInTata = 1;
            nod->fii[1]->inaltimeSubArbore = 1;
            nod->fii[1]->dimensiuneSubArbore = 1;
            nod->fii[1]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod); /// TREBUIE

            this->rebalanseazaNod(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[1]);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
    else
    {
        if (nod->fii[0] == nullptr)
        {
            nod->fii[0] = new Nod();
            nod->fii[0]->valoare = x;
            nod->fii[0]->frecventa = 1;
            nod->fii[0]->tata = nod;
            nod->fii[0]->pozInTata = 0;
            nod->fii[0]->inaltimeSubArbore = 1;
            nod->fii[0]->dimensiuneSubArbore = 1;
            nod->fii[0]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod); /// TREBUIE

            this->rebalanseazaNod(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[0]);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
}

void ABCE::sterge(int x, bool stergereCompleta)
{
    if (this->radacina->fii[1] != nullptr)
        this->sterge(x, this->radacina->fii[1], stergereCompleta);
}

void ABCE::sterge(int x, Nod* nod, bool stergereCompleta)
{
    if (nod->valoare == x)
    {
        if (stergereCompleta)
        {
            nod->sumaFrecventeSubArbore -= nod->frecventa;
            nod->frecventa = 0;
        }
        else
        {
            --nod->frecventa;
            --nod->sumaFrecventeSubArbore;
        }

        if (nod->frecventa == 0) /// Presupun ca nodul nu e radacina, deci poate fi sters si are sigur tata.
        {
            if (nod->fii[0] == nullptr && nod->fii[1] == nullptr)
            {
                nod->tata->fii[nod->pozInTata] = nullptr;

                delete nod;
            }
            else if (nod->fii[0] != nullptr && nod->fii[1] == nullptr)
            {
                nod->fii[0]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[0];
                nod->fii[0]->pozInTata = nod->pozInTata;

                /// this->recalculeazaParametriiSubArbore(nod->fii[0]);

                /// this->rebalanseazaNod(nod->fii[0]);

                delete nod;
            }
            else if (nod->fii[0] == nullptr && nod->fii[1] != nullptr)
            {
                nod->fii[1]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[1];
                nod->fii[1]->pozInTata = nod->pozInTata;

                /// this->recalculeazaParametriiSubArbore(nod->fii[1]);

                /// this->rebalanseazaNod(nod->fii[1]);

                delete nod;
            }
            else /// Are ambii fii (in acest caz sigur are succesorul mai jos de el).
            {
                Nod* succesor = this->succesorDistinct(nod);

                std::swap(nod->valoare, succesor->valoare);
                std::swap(nod->frecventa, succesor->frecventa);

                if (succesor->fii[0] == nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* inlocuitorSuccesor = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = nullptr;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(inlocuitorSuccesor, nod);

                    this->rebalanseazaLant(inlocuitorSuccesor, nod);
                }
                else if (succesor->fii[0] != nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* inlocuitorSuccesor = succesor->fii[0];
                    succesor->fii[0]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[0];
                    succesor->fii[0]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(inlocuitorSuccesor->tata, nod);

                    this->rebalanseazaLant(inlocuitorSuccesor->tata, nod);
                }
                else /// succesor->fii[0] == nullptr && succesor->fii[1] != nullptr
                {
                    Nod* inlocuitorSuccesor = succesor->fii[1];
                    succesor->fii[1]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[1];
                    succesor->fii[1]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiSubArborePeLant(inlocuitorSuccesor->tata, nod);

                    this->rebalanseazaLant(inlocuitorSuccesor->tata, nod);
                }
            }
        }

        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] != nullptr)
        {
            this->sterge(x, nod->fii[1], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
    else
    {
        if (nod->fii[0] != nullptr)
        {
            this->sterge(x, nod->fii[0], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);

            this->rebalanseazaNod(nod);
        }
    }
}

void ABCE::afiseazaCrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaCrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaCrescator(ostream& out, Nod* nod) const
{
    if (nod->fii[0] != nullptr)
        this->afiseazaCrescator(out, nod->fii[0]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[1] != nullptr)
        this->afiseazaCrescator(out, nod->fii[1]);
}

void ABCE::afiseazaDescrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaDescrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaDescrescator(ostream& out, Nod* nod) const
{
    if (nod->fii[1] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[1]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[0] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[0]);
}

int main()
{
    ABCE* abce = new ABCE();

    ifstream in("abce.in");
    ofstream out("abce.out");

    ios_base::sync_with_stdio(false);
    in.tie(nullptr);

    int q;
    in >> q;

    for (int j = 0; j < q; ++j)
    {
        int tip;
        in >> tip;

        if (tip == 1)
        {
            int x;
            in >> x;

            abce->insereaza(x);
        }
        else if (tip == 2)
        {
            int x;
            in >> x;

            abce->sterge(x, true);
        }
        else if (tip == 3)
        {
            int x;
            in >> x;

            if (abce->cauta(x) != nullptr)
                out << 1 << '\n';
            else
                out << 0 << '\n';
        }
        else if (tip == 4)
        {
            int x;
            in >> x;

            out << abce->maximSubSauEgalCu(x)->valoare << '\n';
        }
        else if (tip == 5)
        {
            int x;
            in >> x;

            out << abce->minimPesteSauEgalCu(x)->valoare << '\n';
        }
        else
        {
            int x, y;
            in >> x >> y;

            Nod* inceput = abce->minimPesteSauEgalCu(x);
            Nod* sfarsit = abce->maximSubSauEgalCu(y);

            while (inceput != sfarsit)
            {
                out << inceput->valoare << ' ';
                inceput = abce->succesorDistinct(inceput);
            }

            out << inceput->valoare << '\n';
        }
    }

    in.close();
    out.close();

    delete abce;

    /*
    int q;
    cin >> q;

    for (int j = 0; j < q; ++j)
    {
        int tip;
        cin >> tip;

        if (tip == 1)
        {
            int x;
            cin >> x;

            abce->insereaza(x);
        }
        else if (tip == 2)
        {
            int x;
            cin >> x;

            abce->sterge(x);
        }

        abce->debugArbore();
    }

    delete abce;
    */

    return 0;
}
