#include <bits/stdc++.h>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

const int NEG_INF = -1e9 - 1;
const int INF = 1e9 + 1;

int main()
{
    // ios_base::sync_with_stdio(false);
    // cin.tie(NULL);

    int Q;
    set<int> s;
    f >> Q;

    for (int q = 0; q < Q; q++)
    {
        int op, x, y;
        f >> op;

        if (op == 1)
        {
            f >> x;
            s.insert(x);
        }
        else if (op == 2)
        {
            f >> x;
            s.erase(x);
        }
        else if (op == 3)
        {
            f >> x;
            g << (s.find(x) != s.end()) << '\n';
        }
        else if (op == 4)
        {
            f >> x;
            set<int>::iterator it = s.lower_bound(x);
            if (it == s.begin())
                g << NEG_INF << '\n';
            else
            {
                it--;
                g << *it << '\n';
            }
        }
        else if (op == 5)
        {
            f >> x;
            set<int>::iterator it = s.lower_bound(x);
            if (it == s.end())
                g << INF << '\n';
            else
                g << *it << '\n';
        }
        else
        {
            f >> x >> y;
            set<int>::iterator it1 = s.lower_bound(x);
            set<int>::iterator it2 = s.upper_bound(y);

            vector<int> ans;
            for (; it1 != it2; it1++)
                ans.push_back(*it1);

            if (!ans.size())
            {
                ans.push_back(NEG_INF);
                ans.push_back(INF);
            }

            for (int value : ans)
                g << value << ' ';
            g << '\n';
        }
    }
    return 0;
}