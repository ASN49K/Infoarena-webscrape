#include<iostream>
#include<fstream>
#include <cstdio>
#include <cctype>

using namespace std;

class InParser {
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch() {
        ++sp;
        if (sp == 4096) {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char *nume) {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser &operator>>(int &n) {
        char c;
        while (!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }

    InParser &operator>>(long long &n) {
        char c;
        n = 0;
        while (!isdigit(c = read_ch()) && c != '-');
        long long sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }
};

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char *name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }

    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser &operator<<(int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser &operator<<(long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser &operator<<(char ch) {
        write_ch(ch);
        return *this;
    }

    OutParser &operator<<(const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

struct node {
    node *father, *left, *right;
    int value;
    int height;

    node(int _value) : value(_value), height(1), left(nullptr), right(nullptr) {

    }
};

void update_height(node *x) {
    x->height = 0;
    if (x->left != nullptr) {
        x->height = max(x->height, 1 + x->left->height);
    }
    if (x->right != nullptr) {
        x->height = max(x->height, 1 + x->right->height);
    }
}


//Right-rotation, the left child is not empty.
void rotate_right(node *&x) {
    node *current = x;
    node *new_root = current->left;
    new_root->father = current->father;

    if (current->father != nullptr) {
        if (current->father->left == current) {
            current->father->left = new_root;
        } else {
            current->father->right = new_root;
        }
    }

    current->left = new_root->right;
    if (current->left != nullptr) {
        current->left->father = current;
    }
    new_root->right = current;
    current->father = new_root;
    update_height(current);
    x = new_root;
    update_height(x);
}

//Left-rotation, the right child is not empty.
void rotate_left(node *&x) {
    node *current = x;
    node *new_root = current->right;
    new_root->father = current->father;

    if (current->father != nullptr) {
        if (current->father->left == current) {
            current->father->left = new_root;
        } else {
            current->father->right = new_root;
        }
    }

    current->right = new_root->left;
    if (current->right != nullptr) {
        current->right->father = current;
    }
    new_root->left = current;
    current->father = new_root;
    update_height(current);
    x = new_root;
    update_height(x);
}


void insert(node *&here, int value, node *father) {
    if (here == nullptr) {
        here = new node(value);
        here->father = father;
    } else if (here->value == value) {
        return;
    } else if (value < here->value) {
        insert(here->left, value, here);
        int r = (here->right == nullptr) ? 0 : here->right->height;
        if (here->left->height == r + 2) {
            if (here->left->left == nullptr || here->left->left->height != r + 1) {
                rotate_left(here->left);
            }
            rotate_right(here);
        }
    } else {
        insert(here->right, value, here);
        int r = (here->left == nullptr) ? 0 : here->left->height;
        if (here->right->height == r + 2) {
            if (here->right->right == nullptr || here->right->right->height != r + 1) {
                rotate_right(here->right);
            }
            rotate_left(here);
        }
    }
    update_height(here);
}

int maximum(node *here) {
    while (here->right != nullptr) {
        here = here->right;
    }
    return here->value;
}

int minimum(node *here) {
    while (here->left != nullptr) {
        here = here->left;
    }
    return here->value;
}


void erase(node *&here, int value) {
    if (here == nullptr)
        return;
    if (value < here->value) {
        erase(here->left, value);

        int r = (here->left == nullptr) ? 0 : here->left->height;
        if (here->right != nullptr && here->right->height == r + 2) {
            if (here->right->right == nullptr || here->right->right->height != r + 1) {
                rotate_right(here->right);
            }
            rotate_left(here);
        }
    } else if (value > here->value) {
        erase(here->right, value);
        int r = (here->right == nullptr) ? 0 : here->right->height;
        if (here->left != nullptr && here->left->height == r + 2) {
            if (here->left->left == nullptr || here->left->left->height != r + 1) {
                rotate_left(here->left);
            }
            rotate_right(here);
        }
    } else {
        if (here->height == 0) {
            delete here;
            here = nullptr;
        } else if (here->left != nullptr && here->left->height == here->height - 1) {
            here->value = maximum(here->left);
            erase(here->left, here->value);
        } else {
            here->value = minimum(here->right);
            erase(here->right, here->value);
        }
    }

    if (here != nullptr) {
        update_height(here);
    }
}

bool exists(node *here, int value) {
    if (here == nullptr) {
        return false;
    }
    if (here->value == value) {
        return true;
    }

    if (value < here->value) {
        return exists(here->left, value);
    } else {
        return exists(here->right, value);
    }
}

void between(node *here, int left, int right) {
    if (here == nullptr) {
        return;
    }
    if (here->value >= left) {
        between(here->left, left, right);
    }
    if (here->value >= left && here->value <= right) {
        out << here->value << " ";
    }
    if (here->value <= right) {
        between(here->right, left, right);
    }


}

node *root;

void insert_value(int value) {
    insert(root, value, nullptr);
}

void erase_value(int value) {
    erase(root, value);
}


bool exists_value(int value) {
    return exists(root, value);
}

int lequal(int value) {
    node *here = root;
    int best = -1;
    while (here != nullptr) {
        if (value == here->value) {
            best = here->value;
            break;
        } else if (value > here->value) {
            best = here->value;
            here = here->right;
        } else if (value < here->value) {
            here = here->left;
        }
    }
    return best;
}

int gequal(int value) {
    node *here = root;
    int best = -1;
    while (here != nullptr) {
        if (value == here->value) {
            best = here->value;
            break;
        } else if (value > here->value) {
            here = here->right;
        } else if (value < here->value) {
            best = here->value;
            here = here->left;
        }
    }
    return best;
}

void between(int l, int r) {
    between(root, l, r);
}

InParser in("abce.in");
OutParser out("abce.in");

int main() {
    int q, p, x, y;
    in >> q;
    while (q--) {
        in >> p;
        if (p == 1) {
            in >> x;
            insert_value(x);
        } else if (p == 2) {
            in >> x;
            erase_value(x);
        } else if (p == 3) {
            in >> x;
            out << exists_value(x) << '\n';
        } else if (p == 4) {
            in >> x;
            out << lequal(x) << '\n';
        } else if (p == 5) {
            in >> x;
            out << gequal(x) << '\n';
        } else {
            in >> x >> y;
            between(x, y);
            out << '\n';
        }
    }
}
