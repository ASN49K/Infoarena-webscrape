#include<iostream>
#include<vector>
#include<ctime>
#include <stdlib.h>
#include <fstream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
class skiplist
{
	struct node
	{
		int key;
		node * right, *down;
	};

	int dimensiune;
	vector <node*> liste;

	node * createNode(int val)
	{
		node * newNode = new node();
		newNode->down = nullptr;
		newNode->right = nullptr;
		newNode->key = val;
		return newNode;
	}

	void createListLevel()
	{
		node * newLevel = new node();
		newLevel->right = nullptr;
		if (liste.size() > 0)
		{
			newLevel->down = liste[liste.size() - 1];
		}
		else
		{
			newLevel->down = nullptr;
		}
		liste.push_back(newLevel);
	}

	int heightAtThis(node * temp)
	{
		int h = 0;
		while (temp != nullptr)
		{
			temp = temp->down;
			h++;
		}
		return h;
	}

	node * insertion(int newKey, int level)
	{
		node * newNode = createNode(newKey);
		node * a = liste[liste.size() - 1];
		node * b = a->right;
		while (true)
		{
			if (b->key > newKey)
			{
				while (heightAtThis(b) != level)
				{
					b = b->down;
					a = a->down;
				}
				break;
			}
			if (b->right == nullptr)
			{
				if (heightAtThis(b) == level)
				{
					a = b;
					break;
				}
				b = b->down;
				a = a->down;
			}
			else
			{
				a = b;
				b = b->right;
			}
		}

		if (a == b)
		{
			a->right = newNode;
		}
		else
		{
			node * temp = a;
			a = a->right;
			while (a->key < newKey)
			{
				temp = a;
				a = a->right;
			}
			newNode->right = a;
			temp->right = newNode;
		}
		return newNode;
	}

public:

	skiplist()
	{
		createListLevel();
	}

	void inserare(int newKey)
	{
		int random = 2;
		int level = 1;

		if (liste[0]->right == nullptr)
		{
			liste[0]->right = createNode(newKey);
			dimensiune++;
			int k = 1;
			while (random != 0)
			{
				random = rand() % 2;
				if (random == 1)
				{
					createListLevel();
					liste[k]->right = createNode(newKey);
					liste[k]->right->down = liste[k - 1]->right;
					k++;
					dimensiune++;
				}
			}
		}
		else
		{
			node * bl = insertion(newKey, 1);
			dimensiune++;
			node * bh = nullptr;
			int k = 1;
			while (random != 0)
			{
				random = rand() % 2;
				if (random == 1)
				{
					dimensiune++;
					if (liste.size() < k + 1)
					{
						createListLevel();
						if (k % 2 == 1 || k == 1)
						{
							bh = liste[k]->right = createNode(newKey);
							liste[k]->right->down = bl;
						}
						else
						{
							bl = liste[k]->right = createNode(newKey);
							liste[k]->right->down = bh;
						}
					}
					else
					{
						node * temp2 = insertion(newKey, k + 1);
						if (k % 2 == 1 || k == 1)
						{
							bh = temp2;
							temp2->down = bl;
						}
						else
						{
							bl = temp2;
							temp2->down = bh;
						}
					}
					k++;
				}
			}
		}
	}

	int cautare(int keyToFind)
	{
		node * a = liste[liste.size() - 1];
		node * b = a->right;
		if (b == nullptr)
		{
			return 0;
		}
		if (b->key == keyToFind)
		{
			return 1;
		}
		while (true)
		{
			if (b->key > keyToFind)
			{
				while (heightAtThis(b) != 1)
				{
					b = b->down;
					a = a->down;
				}
				break;
			}
			else if (b->key == keyToFind)
			{
				return 1;
			}

			if (b->right == nullptr)
			{
				if (heightAtThis(b) == 1)
				{
					break;
				}
				b = b->down;
				a = a->down;
			}
			else
			{
				a = b;
				b = b->right;
			}
		}
		while (a->right != b)
		{
			a = a->right;
			if (a->key == keyToFind)
			{
				return 1;
			}
		}
		return 0;
	}

	void stergere(int rkey)
	{
		if (cautare(rkey) == 0)
			return;

		node * prev = liste[liste.size() - 1];
		node * curr = liste[liste.size() - 1]->right;
		node * prev2 = nullptr;
		node * Down = nullptr;
		while (true)
		{
			if (curr->key == rkey)
			{
				break;
			}
			else if (curr->key > rkey)
			{
				prev = prev->down;
				curr = prev->right;
				if (curr->down == nullptr)
				{
					break;
				}
			}
			else
			{
				if (curr->right == nullptr)
				{
					prev = prev->down;
					curr = curr->down;
					if (curr->down == nullptr)
					{
						break;
					}
				}
				else
				{
					prev = curr;
					curr = curr->right;
				}
			}
		}
		if (curr->key == rkey)
		{
			while (true)
			{
				if (curr->down == nullptr)
				{
					prev->right = curr->right;
					delete curr;
					dimensiune--;
					break;
				}
				Down = curr->down;
				prev2 = prev->down;

				prev->right = curr->right;
				delete curr;
				dimensiune--;

				if (liste[liste.size() - 1]->right == nullptr)
				{
					liste.pop_back();
				}

				while (prev2->right != Down)
				{
					prev2 = prev2->right;
				}
				prev = prev2;
				curr = Down;
			}
		}
		else
		{
			node * temp = prev;
			prev = prev->right;
			while (prev->key != rkey)
			{
				temp = prev;
				prev = prev->right;
			}
			temp->right = prev->right;
			delete prev;
			dimensiune--;
		}
	}

	~skiplist(){}
};

int main()
{
	skiplist l;
	int q;
	f>>q;
	int op, x, y;
	for(int i = 0; i < q; i++)
    {
        f>>op>>x;
        if(op == 1)
        {
            l.inserare(x);
        }
        else if(op == 2)
        {
            l.stergere(x);
        }
        else if(op == 3)
        {
            g<<l.cautare(x)<<'\n';
        }
    }
	return 0;
}
