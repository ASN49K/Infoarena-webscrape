#include <fstream>

using namespace std;

ifstream cin("abce.in");
ofstream cout("abce.out");

//structura unui nod din splay tree
struct nod
{
    int val;
    nod* left;
    nod* right;
};

//functii pentru crearea unui nou nod
nod* newNode(int x)
{
    nod* n = new nod;
    n->val = x;
    n->left = NULL;
    n->right = NULL;

    return n;
}

//functie ce executa o rotatie la dreapta
nod* rotatie_dr(nod* x)
{
    nod* y = x->left;
    x->left = y->right;
    y->right = x;

    return y;
}

//functie ce executa o rotatie la stanga
nod* rotatie_st(nod* x)
{
    nod* y = x->right;
    x->right = y->left;
    y->left = x;

    return y;
}

//functie de cautare a unui element in splay tree(are ca parametrii radacina arborelui si valoarea cautata),
//care pune elmentul gasit pe post de radacina, sau, in cazul in care elementul nu este gasit,
//pune ca radacian ultimul nod la care s-a oprit cautarea
nod* cauta(nod* radacina, int val)
{
    //daca arborele este vid returnez radacina(care e NULL)
    if(radacina == NULL)
        return radacina;

    //daca valoarea cautat este chiar in radacina, returnez radacina(nu am rotatii de efectuat)
    if(radacina->val == val)
        return radacina;

    //daca valoarea cautata este in subarborele stang
    if(radacina->val > val)
    {
        //daca nu exista fiul stang al radacinii, returnez radacina(pentru ca ultima accesare a fost radacina)
        if(radacina->left == NULL)
            return radacina;

        //daca valoarea fiului din stanga a radacinii este mai mare decat valoarea cautata -  Zig-Zig (Left Left)
        if(radacina->left->val > val)
        {
            //caut recursiv valoarea val in subarborele stang al fiului stang
            radacina->left->left = cauta(radacina->left->left, val);

            //aduce rezultatul final al cautarii(care va fi fie elementul cu valoarea val, fie elementul la care
            // s-a oprit cautarea nereusita) pe postul de radacina
            radacina = rotatie_dr(radacina);
        }
            //daca valoarea fiului din stanga a radacinii este mai mica decat valoarea cautata - Zig-Zag (Left Right)
        else if (radacina->left->val < val)
        {
            //caut recursiv valoarea val in subarborele drept al fiului stang
            radacina->left->right = cauta(radacina->left->right, val);

            //rotirea nu se poate realiza daca fiul drept al fiului stang al radaciniieste NULL
            if (radacina->left->right != NULL)
                radacina->left = rotatie_st(radacina->left);
        }

        //se face a doua rotatie, cea pentru radacina(cele de mai sus fiind pentru fii radacinii)
        //daca radacina nu are fiu stanga, nu se face nicio rotatie deci in final returnez radacina(arborele ramane neschimbat);
        //altfel efectuam o rotatir spre dreapta si returnez rezultatul(adica noua radacina)
        //rotatia la dreapta nu se poate efectua daca nu exista fiu stang
        if(radacina->left == NULL)
            return radacina;
        else
            return rotatie_dr(radacina);
    }
    //altfel, daca valoarea cautata este in subarborele drept
    else
    {
        //daca nu exista fiul drept al radacinii, returnez radacina(pentru ca ultima accesare a fost radacina)
        if(radacina->right == NULL)
            return radacina;

        //daca valoarea fiului din dreapta a radacinii este mai mare decat valoarea cautata - Zag-Zig (Right Left)
        if (radacina->right->val > val)
        {
            //caut recursiv valoarea val in subarborele stang al fiului drept
            radacina->right->left = cauta(radacina->right->left, val);

            //daca exista subarborele stang al fiului drept al radacinii
            //atunci se face rotirea la dreapta a fiului drept al radacinii
            if (radacina->right->left != NULL)
                radacina->right = rotatie_dr(radacina->right);
        }
        //daca valoarea fiului din dreapta a radacinii este mai mica decat valoarea cautata - Zag-Zag (Right Right)
        else if (radacina->right->val < val)
        {
            //caut recursiv valoarea val in subarborele drept al fiului drept
            radacina->right->right = cauta(radacina->right->right, val);
            //apoi efectueaza rotatie la stanga pentru radacina
            radacina = rotatie_st(radacina);
        }
        //se face a doua rotatie, cea pentru radacina(cele de mai sus fiind pentru fii radacinii)
        //daca radacina nu are fiu dreapta, nu se face nicio rotatie deci in final returnez radacina(arborele ramane neschimbat);
        //altfel efectuam o rotatir spre stanga si returnez rezultatul(adica noua radacina)
        //rotatia la stanga nu se poate efectua daca nu exista fiu drept
        if(radacina->right == NULL)
            return radacina;
        else
            return rotatie_st(radacina);
    }
}

//functie de inserare a unei valori in splay tree
nod* inserare(nod* radacina, int val)
{
    //daca arborele este vid, creez un nou nod si il fac radacina, iar apoi il returnez
    if (radacina == NULL)
        return newNode(val);

    //cautam valoarea val in actualul arbore;
    //daca am gasit-o, ea va fi adusa pe postul de radacina si inserarea nu mai are rost
    //(am deja elementul in arbore, acum chiar pe radacina);
    //daca nu gasesc valoarea, pe radacina va veni cea mai apropiata valoare din arbore de val
    radacina = cauta(radacina, val);
    if (radacina->val == val)
        return radacina;
    //nu am gasit valoarea in arbore, deci o inserez:

    //creez noul nod care va fi si noua radacina
    nod* nn = newNode(val);

    //vad cum este valoarea din radacina comparativ cu valoarea nou creata
    //ca sa vad pe ce parte leg vechea radcina la noul nod(noua radacina)
    if (radacina->val > val)
    {
        nn->right = radacina;
        nn->left = radacina->left;
        radacina->left = NULL;
    }
    else
    {
        nn->left = radacina;
        nn->right = radacina->right;
        radacina->right = NULL;
    }

    return nn; // returnez noua radacina a arborelui(obtinuta in urma inserarii)
}


//functie pentru afisarea elementelor din splay tree in ordine cresatoare(parcurgere in inordine a unui BST)
void inordine(nod* radacina)
{
    if(radacina != NULL)
    {
        inordine(radacina->left);
        cout << radacina->val << " ";
        inordine(radacina->right);
    }
}

//functie de stergere a unui element din splay tree(functia va returna radacina noului arbore, cel format  dupa stergere)
nod* sterge(nod* radacina, int val)
{
    if(radacina == NULL) //daca arborele este vid nu am cum sa sterg
        return radacina;

    radacina = cauta(radacina, val); //caut in arbore elementul ce trebuie sters
    //daca nu gasesc elementul inseamna ca nu am ce sa sterg iar arborele ramane cu aceleasi elemente,
    //dar nu in aceeasi ordine pt ca in fnctia de cautare se vor efectua rotatii
    if(radacina->val != val)
        return radacina;

    //daca am doar un singur subarbore(doar cel drept sau doar cel stang)
    //atunci sterg pur si simplu radacina, iar arborele ramas(cel constituit din unul dintre subarbori)
    //va reprezenta noul arbore(si va fi un BST valid)
    nod* temp = radacina;
    if(radacina->left == NULL)
    {
        radacina = radacina->right;
        delete temp;
        return radacina;
    }
    else if(radacina->right == NULL)
    {
        radacina = radacina->left;
        delete temp;
        return radacina;
    }
    else //am si subarbore stang si drept
    {
        radacina = cauta(radacina->left, val); //imi va intoarce cea mai apropiata valoare de valoarea radacinii,
                                              //mai mica decat aceasta(cea mai mare valoare din subarborele stang)

        radacina->right = temp->right; //refac legaturi inainte de stergere
        delete temp;
        return radacina;
    }
}

//functii pt gasirea succesorului/predecesorului din arbore pentru o valoare data
void predecesor(nod* radacina, nod* &pre, int val)
{

    if (radacina == NULL)
        return ;

    if (radacina->val == val)
    {
        pre = radacina;
        return;
    }

    if (radacina->val > val)
    {
        predecesor(radacina->left, pre, val) ;
    }
    else
    {
        pre = radacina ;
        predecesor(radacina->right, pre, val) ;
    }
}

void succesor(nod* radacina, nod* &suc, int val)
{

    if (radacina == NULL)
        return ;

    if (radacina->val == val)
    {
        suc = radacina;
        return;
    }

    if (radacina->val > val)
    {
        suc = radacina ;
        succesor(radacina->left, suc, val) ;
    }
    else
    {
        succesor(radacina->right, suc, val) ;
    }
}


//int succesor(nod* &radacina, int val)
//{
//    //caut valaorea in arbore si daca o gasesc o returnez,
//    //deoarece ea este cea mai apropiata valoarea mai mare sau egala cu ea insasi
//    radacina = cauta(radacina, val);
//    if(radacina->val == val)
//        return val;
//
//    //daca nu am gasit-o, inseamna ca pe radacina am cea mai apropiata valoare de valoarea cautata,
//    //dar nu stiu daca este mai mare sau mai mica asa ca testez
//    if(radacina->val > val) //in radacina este fix succesorul
//        return radacina->val;
//    else
//    {
//        if(radacina->right == NULL)//daca nu am subarbore drept(nu mai am sanse sa gasesc succesor pt valoarea data)
//            return -1;
//        else //sigur am succesor, asa ca il caut si il returnez
//        {
//            radacina = cauta(radacina->right, val); //caut cea mai mica valoare mai mare decat radacina
//            return radacina->val;
//        }
//    }
//}
//
//int predecesor(nod* &radacina, int val)
//{
//    //caut valaorea in arbore si daca o gasesc o returnez,
//    //deoarece ea este cea mai apropiata valoarea mai mica sau egala cu ea insasi
//    radacina = cauta(radacina, val);
//    if(radacina->val == val)
//        return val;
//
//    //daca nu am gasit-o, inseamna ca pe radacina am cea mai apropiata valoare de valoarea cautata,
//    //dar nu stiu daca este mai mare sau mai mica asa ca testez
//    if(radacina->val < val) //in radacina este fix predecesorul
//        return radacina->val;
//    else
//    {
//        if(radacina->left == NULL)//daca nu am subarbore stang(nu mai am sanse sa gasesc predecesor pt valoarea data)
//            return -1;
//        else //sigur am predecesor, asa ca il caut si il returnez
//        {
//            radacina = cauta(radacina->left, val); //caut cea mai mica valoare mai mare decat radacina
//            return radacina->val;
//        }
//    }
//}

//functie pt afisarea elementelor din arbore ce se afla in intervalul descris de cele doua limite ls si ld
void afisare_interval(nod* radacina, int ls, int ld)
{
    if(radacina != NULL)
    {
        afisare_interval(radacina->left, ls, ld);
        if(radacina->val >= ls && radacina->val <= ld)
            cout << radacina->val << " ";
        afisare_interval(radacina->right, ls, ld);
    }
}


int main()
{

    nod* radacina = NULL;
    int n=0; //nr de operatii ce se vor efectua asupra splay tree-ului
    int tip_op, x, y;

    cin >> n;

    nod* suc = NULL;
    nod* pred = NULL;

    while(n--)
    {
        cin >> tip_op;
        switch (tip_op)
        {
            case 1: cin >> x; radacina = inserare(radacina, x); break;

            case 2: cin >> x; radacina = sterge(radacina, x); break;

            case 3: cin >> x; radacina = cauta(radacina, x);
            if(radacina->val ==x) cout << 1 << "\n";
            else cout << 0 << "\n";
            break;

            case 4: cin >> x;
            succesor(radacina, suc, x);
            if(suc != NULL) cout << suc->val << "\n";
            else cout << "-1\n";
            break;

            case 5: cin >> x;
            predecesor(radacina, pred, x);
            if(pred != NULL) cout << pred->val << "\n";
            else cout << "-1\n";
            break;

            case 6: cin >> x >> y;
            afisare_interval(radacina, x, y);
            cout << "\n";
            break;
        }
    }
    return 0;
}

//
//
//int main_()
//{
//    nod* radacina = NULL;
//    int n, i, x;
//    cin >> n;
//    for(i=1; i<=n; ++i)
//    {
//        cin >> x;
//        radacina = inserare(radacina, x);
//    }
//    inordine(radacina);
//    cout << "\n";
//
//    afisare_interval(radacina, 5, 10);
//    cout << "\n";
//    afisare_interval(radacina, 0, 100);
//    cout << "\n";
//    afisare_interval(radacina, 7, 30);
//    cout << "\n";
//    return 0;
//    radacina = sterge(radacina, 16);
//    inordine(radacina);
//    cout << "\n";
//    radacina = sterge(radacina, 100);
//    inordine(radacina);
//    cout << "\n";
//    radacina = sterge(radacina, 1);
//    inordine(radacina);
//    cout << "\n";
//    radacina = inserare(radacina, 100);
//    inordine(radacina);
//    cout << "\n";
//    return 0;
//}
