#include <iostream>
using namespace std;

struct node {
    int key;
    node *stanga, *dreapta;
};

node* newNode(int key) {
    node* t = new node;
    t->key = key;
    t->stanga = t->dreapta = nullptr;
    return t;
}

node* rightRotate(node* x) {
    node* y = x->stanga;
    x->stanga = y->dreapta;
    y->dreapta = x;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->dreapta;
    x->dreapta = y->stanga;
    y->stanga = x;
    return y;
}

node* splay(node* root, int key) {
    if (root == nullptr || root->key == key)
        return root;

    if (root->key > key) {
        if (root->stanga == nullptr)
            return root;
        if (root->stanga->key > key) {
            root->stanga->stanga = splay(root->stanga->stanga, key);
            root = rightRotate(root);
        }
        else if (root->stanga->key < key) {
            root->stanga->dreapta = splay(root->stanga->dreapta, key);
            if (root->stanga->dreapta != nullptr)
                root->stanga = leftRotate(root->stanga);
        }
        return (root->stanga == nullptr) ? root : rightRotate(root);
    }
    else {
        if (root->dreapta == nullptr)
            return root;
        if (root->dreapta->key > key) {
            root->dreapta->stanga = splay(root->dreapta->stanga, key);
            if (root->dreapta->stanga != nullptr)
                root->dreapta = rightRotate(root->dreapta);
        }
        else if (root->dreapta->key < key) {
            root->dreapta->dreapta = splay(root->dreapta->dreapta, key);
            root = leftRotate(root);
        }
        return (root->dreapta == nullptr) ? root : leftRotate(root);
    }
}

node* insert(node* root, int key) {
    if (root == nullptr)
        return newNode(key);
    root = splay(root, key);
    if (root->key == key)
        return root;
    node* t = newNode(key);
    if (root->key > key) {
        t->dreapta = root;
        t->stanga = root->stanga;
        root->stanga = nullptr;
    }
    else {
        t->stanga = root;
        t->dreapta = root->dreapta;
        root->dreapta = nullptr;
    }
    return t;
}

node* deleteNode(node* root, int key) {
    if (root == nullptr)
        return root;
    root = splay(root, key);
    if (root->key != key)
        return root;
    node* t;
    if (root->stanga == nullptr) {
        t = root->dreapta;
        delete(root);
        return t;
    }
    else {
        t = root->stanga;
        while (t->dreapta != nullptr)
            t = t->dreapta;
        t->dreapta = root->dreapta;
        node* newRoot = t;
        delete(root);
        return newRoot;
    }
}

void preorderTraversal(node* root) {
    if (root != nullptr) {
        cout << root->key << " ";
        preorderTraversal(root->stanga);
        preorderTraversal(root->dreapta);
    }
}

int main() {
    node* root = nullptr;
    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        char op;
        int val;
        cin >> op >> val;

        if (op == 'I') {
            root = insert(root, val);
        }
        else if (op == 'S') {
            root = deleteNode(root, val);
        }
    }

    preorderTraversal(root);

    return 0;
}
