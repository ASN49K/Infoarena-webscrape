/// ARORE BINAR DE CAUTARE SIMPLU CU OPERATIILE:
/// --> inserare valoare
/// --> cautare valoare
/// --> stergere valoare

#include <iostream>
#include <fstream>

using namespace std;

ifstream citeste("abce.in");
ofstream scrie("abce.out");

/// STRUCTURA UNUI NOD
/// -- valoare
/// -- pointer catre fiul stang
/// -- pointer catre fiul drept

struct nod
{
    int valoare;
    nod *fiuStang;
    nod *fiuDrept;
};


/// CREAREA UNUI NOD NOU

nod *nodNou (int valoare)
{
    auto *nodCreat = new nod();
    nodCreat->valoare = valoare;
    nodCreat->fiuDrept = nullptr;
    nodCreat->fiuStang = nullptr;
    return nodCreat;
}


/// INSERARE
/// In cazul in care arborele sau subarborele nu are radacina, o setam (introducem nodul).
/// Recursiv parcurgem arborele in stanga sau in dreapta in functie de valoarea pe care vrem sa o inseram:
/// --> valoare mai mica --> stanga
/// --> valoare mai mare --> dreapta
/// Pentru a iesi din functie fara a 'strica' arborele returnam nodul. Astfel, acelasi
/// nod este returnat pe masura ce ne intoarcem spre radacina.

nod *inserare (nod *radacina, int valoare)
{
    if (radacina == nullptr)
    {
        radacina = nodNou(valoare);
        return radacina;
    }
    else if (valoare > radacina->valoare)
        radacina->fiuDrept = inserare(radacina->fiuDrept, valoare);
    else radacina->fiuStang = inserare(radacina->fiuStang, valoare);
    return radacina;
}


/// CAUTARE
/// Cautam valoarea in functie de valoarea ei:
/// --> valoare mai mica --> stanga
/// --> valoare mai mare --> dreapta

bool cautare(nod *radacina, int valoare)
{
    if(radacina == nullptr)
        return false;
    if(radacina->valoare == valoare)
        return true;
    else if (valoare > radacina->valoare)
        return cautare(radacina->fiuDrept, valoare);
    else return cautare(radacina->fiuStang, valoare);
}


/// VALOAREA MINIMA
/// Pentru a gasi valoarea minima mergem cat de in stanga putem.

nod* valoareaMinima(nod *radacina)
{
    if(radacina == nullptr)
        return nullptr;
    while (radacina->fiuStang != nullptr)
        radacina = radacina->fiuStang;
    return radacina;
}


/// STERGERE
/// Pentru stergere avem 3 cazuri:
/// 1. Nodul este frunza - il stergem pur si simplu
/// 2. Nodul are un copil - inlocuim nodul cu copilul sau si stergem copilul
/// 3. Nodul are doi copii - gasim succesorul lui, il inlocuim cu el si eliminam succesorul de la locul lui
/// Primele randuri ale functiei simuleaza o cautare a nodului.

nod *stergere(nod *radacina, int valoare)
{
    if(radacina == nullptr)
        return radacina;
    if(valoare < radacina->valoare)
        radacina->fiuStang = stergere(radacina->fiuStang, valoare);
    else if(valoare > radacina->valoare)
        radacina->fiuDrept = stergere(radacina->fiuDrept, valoare);
    else
    {
        if(radacina->fiuDrept == nullptr)
        {
            nod *nodAuxiliar = radacina->fiuStang;
            free(radacina);
            return nodAuxiliar;
        }
        else if(radacina->fiuStang == nullptr)
        {
            nod *nodAuxiliar = radacina->fiuDrept;
            free(radacina);
            return nodAuxiliar;
        }

        nod *nodAuxiliar = valoareaMinima(radacina->fiuDrept);
        radacina->valoare = nodAuxiliar->valoare;
        radacina->fiuDrept = stergere(radacina->fiuDrept, nodAuxiliar->valoare);
    }
    return radacina;
}


int main()
{
    int q, op, x, y;
    citeste >> q;
    nod* radacina;
    radacina = nullptr;
    for(int i=0; i<q; i++)
    {
        citeste >> op;
        cout << "Operatia " << op;
        if (op == 1)
        {
            cout << " - INSERARE\n";
            citeste >> x;
            radacina = inserare(radacina, x);
            cout << "Valoarea " << x << " a fost inserata in arbore.\n" << endl;
        }
        else if (op == 2)
        {
            cout << " - STERGERE\n";
            citeste >> x;
            radacina = stergere(radacina, x);
            cout << "Valoarea " << x << " a fost stearsa din arbore.\n" << endl;
        }
        else if (op == 3)
        {
            cout << " - CAUTARE\n";
            citeste >> x;
            if (cautare(radacina, x))
            {
                cout << "Valoarea " << x << " a fost gasita.\n" << endl;
                scrie << '1\n';
            }
            else
            {
                cout << "Valoarea " << x << " nu a fost gasita.\n" << endl;
                scrie << '0/n';
            }
        }
    }

    return 0;
}
