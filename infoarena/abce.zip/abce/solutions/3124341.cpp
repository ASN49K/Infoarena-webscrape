#include <iostream>
#include <fstream>

using namespace std;

#define MAX(a, b) ((a) > (b) ? (a) : (b))

typedef struct Nod {
    struct Nod* parent;
    struct Nod* leftChild;
    struct Nod* rightChild;
    long long int balanceFactor;
    long long int height;
    long long int key;
    long long int value;
} Nod, *PNod;

PNod createNod(long long int key, long long int value){
    PNod newNode = new Nod;
    newNode->parent = NULL;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    newNode->balanceFactor = 0;
    newNode->height = 0;
    newNode->key = key;
    newNode->value = value;

    return newNode;
}

class AVL{


public:

    int size;

    void nodeHeight(PNod nod){
        if (nod == NULL)
            return;

        int left = -1, right = -1;

        if (nod->rightChild)
            right = nod->rightChild->height;
        if (nod->leftChild)
            left = nod->leftChild->height;

        nod->height = MAX(left, right) + 1;
        nod->balanceFactor = right - left;
    }

    void updateHeightRec(PNod nod) {
        if (nod == NULL) return;
        nodeHeight(nod);
        updateHeightRec(nod->parent);
    }

//    void nodeHeight(PNod &nod){
//        if (nod == NULL)
//            return;
//        else {
//            nodeHeight(nod->leftChild);
//            long long int left = nod->leftChild == NULL ? -1 : nod->leftChild->height;
//            nodeHeight(nod->rightChild);
//            long long int right = nod->rightChild == NULL ? -1 : nod->rightChild->height;
//            nod->height = MAX(left, right) + 1;
//            nod->balanceFactor = right - left;
//
//            if (nod->balanceFactor < -1){
//                if (nod->leftChild->balanceFactor < 0)
//                    balanceAVL(nod->leftChild->leftChild);
//                else balanceAVL(nod->leftChild->rightChild);
//            }
//            else if (nod->balanceFactor > 1){
//                if (nod->rightChild->balanceFactor < 0)
//                    balanceAVL(nod->rightChild->leftChild);
//                else balanceAVL(nod->rightChild->rightChild);
//            }
//
//            return nod->height;
//        }
//    }

    void balanceAVL(PNod nod){
        if (nod == NULL || nod->parent == NULL || nod->parent->parent == NULL)
            return;

        PNod parent = nod->parent;
        PNod grandParent = nod->parent->parent;
//
//        while (grandParent != NULL) {
            nodeHeight(grandParent);

            int BF = grandParent->balanceFactor;

            if (BF < -1 && nod->key < parent->key)
                rotateRight(nod->parent);

            if (BF > 1 && nod->key > parent->key)
                rotateLeft(nod->parent);

            if (BF < -1 && nod->key > parent->key) {
                rotateLeft(nod);
                rotateRight(nod);
            }

            if (BF > 1 && nod->key < parent->key) {
                rotateRight(nod);
                rotateLeft(nod);
            }
//
//            nod = parent;
//            parent = grandParent;
//            grandParent = grandParent->parent;
//        }

    }

    void rotateRight(PNod nod){
        if (nod == NULL || nod->parent == NULL)
            return;

        PNod parent = nod->parent;
        PNod grandParent = nod->parent->parent;

        parent->leftChild = nod->rightChild;
        if (parent->leftChild != NULL)
            parent->leftChild->parent = parent;

        nod->rightChild = parent;
        parent->parent = nod;

        if (grandParent == NULL) {
            root = nod;
            nod->parent = NULL;
        }
        else {
            nod->parent = grandParent;
            if (grandParent->key > nod->key)
                grandParent->leftChild = nod;
            else grandParent->rightChild = nod;
        }

        nodeHeight(parent);
        nodeHeight(parent->parent);
    }

    void rotateLeft(PNod nod){
        if (nod == NULL || nod->parent == NULL)
            return;

        PNod parent = nod->parent;
        PNod grandParent = nod->parent->parent;

        parent->rightChild = nod->leftChild;
        if (parent->rightChild != NULL)
            parent->rightChild->parent = parent;

        nod->leftChild = parent;
        parent->parent = nod;
        if (grandParent == NULL){
            root = nod;
            nod->parent = NULL;
        }
        else {
            nod->parent = grandParent;
            if (grandParent->key > nod->key)
                grandParent->leftChild = nod;
            else grandParent->rightChild = nod;
        }

        nodeHeight(parent);
        nodeHeight(parent->parent);
    }

    void afisareNod(PNod nod){
        if (nod == NULL)
            return;
        if (nod->parent == NULL){
            cout<<"ROOT"<<" node_key: "<<nod->key<<" height: "<<nod->height<<" BF: "<<nod->balanceFactor<<endl;
        }
        else{
            cout<<"node_key: "<<nod->key<<" parent_key: "<<nod->parent->key<<" height: "<<nod->height<<" BF: "<<nod->balanceFactor<<endl;
        }
        afisareNod(nod->leftChild);
        afisareNod(nod->rightChild);
    }

    PNod root;
    AVL(){
        this->root = NULL;
        this->size = 0;
    }

    PNod keySearch(long long int key){
        PNod aux = root;

        while (aux != NULL){
            if (aux->key == key)
                return aux;
            if (key < aux->key)
                aux = aux->leftChild;
            else aux = aux->rightChild;
        }

        return NULL;
    }

    void insertElement(long long int key, long long int value = 0){
        PNod newNode = createNod(key, value);
        if (root == NULL){
            this->root = newNode;
            return;
        }
        PNod p = this->root, parent = NULL;
        while (p != NULL){
            parent = p;
            if (p->key < newNode->key){
                p = p->rightChild;
            }
            else p = p->leftChild;
        }

        if (parent->key < newNode->key){
            newNode->parent = parent;
            parent->rightChild = newNode;
            nodeHeight(parent);
        }

        else {
            newNode->parent = parent;
            parent->leftChild = newNode;
            nodeHeight(parent);
        }

        PNod pa = parent;
        while (pa != NULL) {
            nodeHeight(p);
            if (pa->balanceFactor < -1){
                if (pa->leftChild->balanceFactor < 0)
                    balanceAVL(pa->leftChild->leftChild);
                else balanceAVL(pa->leftChild->rightChild);
            }
            else if (pa->balanceFactor > 1) {
                if (pa->rightChild->balanceFactor < 0)
                    balanceAVL(pa->rightChild->leftChild);
                else balanceAVL(pa->rightChild->rightChild);
            }
            pa = pa->parent;
        }
        this->size++;
    }

    void heightCalc(){
        if (this->root != NULL)
            /*root->height =*/ nodeHeight(root);
    }

    PNod deepest_node(PNod root) {
        PNod p = root, parent = NULL;
        while (p != NULL) {
            parent = p;
            int bf = p->balanceFactor;
            if (bf < 0)
                p = p->leftChild;
            else
                p = p->rightChild;
        }
        return parent;
    }

    void deleteElement(long long int key){
        PNod parcurgere = this->root;
        PNod parent = NULL;

        while (parcurgere != NULL){
            if (key == parcurgere->key){
                break;
            }

            parent = parcurgere;

            if (key < parcurgere->key)
                parcurgere = parcurgere->leftChild;
            else parcurgere = parcurgere->rightChild;
        }

        if (parcurgere == NULL)
            return;

        this->size--;

        PNod new_tree = NULL;
        if (parent == NULL) {
            new_tree = buildSubs(parcurgere->leftChild, parcurgere->rightChild);
            this->root = new_tree;
            if (this->root != NULL) {
                this->root->parent = NULL;
            }
            delete parcurgere;
            return;
        } else {
            if (parcurgere->rightChild == NULL && parcurgere->leftChild == NULL)
                new_tree = NULL;
            else
                new_tree = buildSubs(parcurgere->leftChild, parcurgere->rightChild);
            if (parent->rightChild != NULL && parent->rightChild->key == key) {
                parent->rightChild = new_tree;
                if (new_tree != NULL)
                    new_tree->parent = parent;
            } else {
                parent->leftChild = new_tree;
                if (new_tree != NULL)
                    new_tree->parent = parent;
            }
            PNod p = parent;
            while (p != NULL) {
                nodeHeight(p);
                if (p->balanceFactor < -1){
                    if (p->leftChild->balanceFactor < 0)
                        balanceAVL(p->leftChild->leftChild);
                    else balanceAVL(p->leftChild->rightChild);
                }
                else if (p->balanceFactor > 1) {
                    if (p->rightChild->balanceFactor < 0)
                        balanceAVL(p->rightChild->leftChild);
                    else balanceAVL(p->rightChild->rightChild);
                }
                p = p->parent;
            }

            delete parcurgere;

            return;
        }
//        if (parcurgere->leftChild == NULL && parcurgere->rightChild == NULL){
//            if (parent == NULL){
//                this->root = NULL;
//            }
//            else{
//                if (parent->rightChild == parcurgere)
//                    parent->rightChild = NULL;
//                if (parent->leftChild == parcurgere)
//                    parent->leftChild = NULL;
//
//                nodeHeight(parent);
//
//                if (parent->balanceFactor < -1){
//                    if (parent->leftChild->balanceFactor < 0)
//                        balanceAVL(parent->leftChild->leftChild);
//                    else balanceAVL(parent->leftChild->rightChild);
//                }
//                else if (parent->balanceFactor > 1) {
//                    if (parent->rightChild->balanceFactor < 0)
//                        balanceAVL(parent->rightChild->leftChild);
//                    else balanceAVL(parent->rightChild->rightChild);
//                }
//            }
//            delete parcurgere;
//
//        }
//
//        else if (parcurgere->leftChild != NULL && parcurgere->rightChild == NULL){
//            if (parent == NULL){
//                root = parcurgere->leftChild;
//                root->parent = NULL;
//            }
//            else {
//                parent->leftChild = parcurgere->leftChild;
//                parcurgere->leftChild->parent = parent;
//
//                nodeHeight(parent);
//
//                if (parent->balanceFactor < -1){
//                    if (parent->leftChild->balanceFactor < 0)
//                        balanceAVL(parent->leftChild->leftChild);
//                    else balanceAVL(parent->leftChild->rightChild);
//                }
//                else if (parent->balanceFactor > 1) {
//                    if (parent->rightChild->balanceFactor < 0)
//                        balanceAVL(parent->rightChild->leftChild);
//                    else balanceAVL(parent->rightChild->rightChild);
//                }
//            }
//            delete parcurgere;
//        }
//
//        else if (parcurgere->leftChild == NULL && parcurgere->rightChild != NULL){
//            if (parent == NULL){
//                root = parcurgere->rightChild;
//                root->parent = NULL;
//            }
//            else {
//                parent->rightChild = parcurgere->rightChild;
//                parcurgere->rightChild->parent = parent;
//
//                nodeHeight(parent);
//
//                if (parent->balanceFactor < -1){
//                    if (parent->leftChild->balanceFactor < 0)
//                        balanceAVL(parent->leftChild->leftChild);
//                    else balanceAVL(parent->leftChild->rightChild);
//                }
//                else if (parent->balanceFactor > 1) {
//                    if (parent->rightChild->balanceFactor < 0)
//                        balanceAVL(parent->rightChild->leftChild);
//                    else balanceAVL(parent->rightChild->rightChild);
//                }
//            }
//            delete parcurgere;
//        }
//
//        else {
//            if (parent == NULL){
//                root = buildSubs(parcurgere->leftChild, parcurgere->rightChild);
//                root->parent = NULL;
//
//                if (root->balanceFactor < -1){
//                    if (root->leftChild->balanceFactor < 0)
//                        balanceAVL(root->leftChild->leftChild);
//                    else balanceAVL(root->leftChild->rightChild);
//                }
//                else if (root->balanceFactor > 1) {
//                    if (root->rightChild->balanceFactor < 0)
//                        balanceAVL(root->rightChild->leftChild);
//                    else balanceAVL(root->rightChild->rightChild);
//                }
//            }
//            else {
//                PNod tempRoot = buildSubs(parcurgere->leftChild, parcurgere->rightChild);
//                if (parent->leftChild == parcurgere){
//                    parent->leftChild = tempRoot;
//                    tempRoot->parent = parent;
//                }
//                if (parent->rightChild == parcurgere){
//                    parent->rightChild = tempRoot;
//                    tempRoot->parent = parent;
//                }
//
//                nodeHeight(parent);
//            }
//
//            delete parcurgere;
//        }



    }

    PNod buildSubs(PNod left, PNod right){
        PNod parcurgere = left;
        PNod parinte = NULL;

        if (left == NULL) return right;
        if (right == NULL) return left;

        if (left->rightChild == NULL) {
            left->rightChild = right;
            right->parent = left;
            nodeHeight(left);
            return left;
        }

        while (parcurgere->rightChild != NULL){
            parinte = parcurgere;
            parcurgere = parcurgere->rightChild;
        }

        parinte->rightChild = parcurgere->leftChild;
        if (parcurgere->leftChild != NULL)
            parcurgere->leftChild->parent = parinte;

        parcurgere->parent = NULL;

        parcurgere->leftChild = left;
        parcurgere->rightChild = right;

        left->parent = parcurgere;
        right->parent = parcurgere;

        while (parinte != parcurgere){
            nodeHeight(parinte);
            parinte = parinte->parent;
        }
        nodeHeight(parcurgere);

        return parcurgere;
    }

    void printAVL(){
        afisareNod(root);
        cout<<endl;
    }
};



int main() {
    AVL avl;

//    avl.insertElement(25);
//    avl.insertElement(20);
//    avl.insertElement(36);
//    avl.insertElement(10);
//    avl.insertElement(22);
//    avl.insertElement(30);
//    avl.insertElement(40);
//    avl.insertElement(12);
//    avl.insertElement(28);
//    avl.insertElement(38);
//    avl.insertElement(48);
//
//    avl.deleteElement(40);
//    avl.deleteElement(22);
//
//    avl.printAVL();

    ifstream f("abce.in");
    ofstream g("abce.out");

    long long int operatii;
    f>>operatii;

    for (long long int i=0; i<operatii; i++) {
        long long int operatie;
        f>>operatie;
//        cout<<i<<" "<<operatie<<" ";
        switch (operatie) {
            case 1:{
                long long int x;
                f>>x;
//                cout<<x<<endl;
                avl.insertElement(x);
                break;
            }
            case 2:{
                long long int x;
                f>>x;
//                cout<<x<<endl;
                avl.deleteElement(x);
                break;
            }
            case 3:{
                long long int x;
                f>>x;
//                cout<<x<<endl;
                if (avl.keySearch(x) != NULL)
                    g<<1<<endl;
                else g<<0<<endl;
                break;
            }
            case 4:{
                long long int x;
                f>>x;
//                cout<<x<<endl;
                g<<"Predecesor"<<endl;
                break;
            }
            case 5:{
                long long int x;
                f>>x;
//                cout<<x<<endl;
                g<<"Succesor"<<endl;
                break;
            }
            case 6:{
                long long int x, y;
                f>>x>>y;
                g<<"Interval"<<endl;
                break;
            }
        }
    }

//    avl.printAVL();

    f.close();
    g.close();


    return 0;
}
