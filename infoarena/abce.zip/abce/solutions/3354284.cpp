#include <iostream>
#include <climits>
#include <cstdio>
using namespace std;

class AVL {
private:
    struct Node {
        int val;
        int height;
        Node* left;
        Node* right;
        Node(int x) {
            val = x;
            height = 1;
            left = nullptr;
            right = nullptr;
        }
    };
    Node* root;

    int getHeight(Node* node) {
        if (node == nullptr) return 0;
        return node->height;
    }

    void updateHeight(Node* node) {
        if (node == nullptr) return;
        int h1 = getHeight(node->left);
        int h2 = getHeight(node->right);
        node->height = 1 + (h1 > h2 ? h1 : h2);
    }

    int getBalance(Node* node) {
        if (node == nullptr) return 0;
        return getHeight(node->left) - getHeight(node->right);
    }

    Node* rotateRight(Node* y) {
        Node* x  = y->left;
        Node* T2 = x->right;
        x->right = y;
        y->left  = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    Node* rotateLeft(Node* x) {
        Node* y  = x->right;
        Node* T2 = y->left;
        y->left  = x;
        x->right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    Node* balance(Node* node) {
        updateHeight(node);
        int bf = getBalance(node);

        if (bf > 1 && getBalance(node->left) >= 0)
            return rotateRight(node);

        if (bf > 1 && getBalance(node->left) < 0) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }

        if (bf < -1 && getBalance(node->right) <= 0)
            return rotateLeft(node);

        if (bf < -1 && getBalance(node->right) > 0) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;
    }

    Node* addHelper(Node* node, int x) {
        if (node == nullptr)
            return new Node(x);
        if (x < node->val)
            node->left  = addHelper(node->left,  x);
        else
            node->right = addHelper(node->right, x);
        return balance(node);
    }

    bool searchHelper(Node* node, int x) {
        if (node == nullptr) {
            return false;
        }
        if (x == node->val) {
            return true;
        }
        if (x < node->val) {
            return searchHelper(node->left, x);
        }
        return searchHelper(node->right, x);
    }

    Node* deleteHelper(Node* node, int x) {
        if (node == nullptr) return nullptr;

        if (x < node->val) {
            node->left  = deleteHelper(node->left,  x);
        } else if (x > node->val) {
            node->right = deleteHelper(node->right, x);
        } else {
            if (node->left == nullptr && node->right == nullptr) {
                delete node;
                return nullptr;
            }
            if (node->right == nullptr) {
                Node* temp = node;
                node = node->left;
                delete temp;
                return node;
            }
            if (node->left == nullptr) {
                Node* temp = node;
                node = node->right;
                delete temp;
                return node;
            }
            Node* pred = node->left;
            while (pred->right != nullptr)
                pred = pred->right;
            int predVal = pred->val;
            node->val   = predVal;
            node->left  = deleteHelper(node->left, predVal);
        }

        return balance(node);
    }

    int predecessorHelper(Node* node, int x) {
        if (node == nullptr) return INT_MIN;
        if (node->val == x)  return x;
        if (x < node->val)   return predecessorHelper(node->left, x);
        int rightResult = predecessorHelper(node->right, x);
        if (rightResult == INT_MIN) return node->val;
        return rightResult;
    }

    int successorHelper(Node* node, int x) {
        if (node == nullptr) return INT_MAX;
        if (node->val == x)  return x;
        if (x > node->val)   return successorHelper(node->right, x);
        int leftResult = successorHelper(node->left, x);
        if (leftResult == INT_MAX) return node->val;
        return leftResult;
    }

    void rangeHelper(Node* node, int x, int y) {
        if (node == nullptr) return;
        if (node->val > x)   rangeHelper(node->left,  x, y);
        if (node->val >= x && node->val <= y)
            printf("%d ", node->val);
        if (node->val < y)   rangeHelper(node->right, x, y);
    }

public:
    AVL() { root = nullptr; }

    void add(int x)          { root = addHelper(root, x); }
    void del(int x)          { root = deleteHelper(root, x); }
    bool search(int x)       { return searchHelper(root, x); }
    int  predecessor(int x)  { return predecessorHelper(root, x); }
    int  successor(int x)    { return successorHelper(root, x); }
    void range(int x, int y) { rangeHelper(root, x, y); printf("\n"); }
};

int main() {
    freopen("abce.in",  "r", stdin);
    freopen("abce.out", "w", stdout);

    AVL avl;
    int Q;
    scanf("%d", &Q);

    while (Q--) {
        int tip;
        scanf("%d", &tip);

        if (tip == 1) {
            int x; scanf("%d", &x);
            avl.add(x);
        } else if (tip == 2) {
            int x; scanf("%d", &x);
            avl.del(x);
        } else if (tip == 3) {
            int x; scanf("%d", &x);
            printf("%d\n", avl.search(x));
        } else if (tip == 4) {
            int x; scanf("%d", &x);
            printf("%d\n", avl.predecessor(x));
        } else if (tip == 5) {
            int x; scanf("%d", &x);
            printf("%d\n", avl.successor(x));
        } else {
            int x, y; scanf("%d %d", &x, &y);
            avl.range(x, y);
        }
    }

    return 0;
}