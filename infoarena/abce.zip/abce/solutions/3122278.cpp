//
// Created by macelaru on 18.04.2023.
//
#include <fstream>
#include <iostream>
#include <memory>
#include <vector>

using namespace std;

class Nod {
public:
    int val;
    std::shared_ptr<Nod> stg;
    std::shared_ptr<Nod> drp;

    Nod(int val);
};

Nod::Nod(int val) : val(val), stg(nullptr), drp(nullptr) {}

class ArboreBinar {
public:
    std::vector<int> interval;

    std::shared_ptr<Nod> root;

    ArboreBinar();

    void insert(int val);

    std::shared_ptr<Nod> remove(std::shared_ptr<Nod> node, int val);

    std::shared_ptr<Nod> findMin(std::shared_ptr<Nod> node);

    int cauta(std::shared_ptr<Nod> root, int val);

    int cel_mai_mare_nr_mai_mic(std::shared_ptr<Nod> root, int X);

    int cel_mai_mic_nr_mai_mare(std::shared_ptr<Nod> root, int X);

    void afiseazaInInterval(std::shared_ptr<Nod> root, int X, int Y);
};

ArboreBinar::ArboreBinar() : root(nullptr) {}

void ArboreBinar::insert(int val) {

    shared_ptr<Nod> newNod = make_shared<Nod>(val);

    if (root == nullptr) {
        root = newNod;
        return;
    }

    shared_ptr<Nod> curr = root;

    while (true) {
        if (val < curr->val) {
            if (curr->stg == nullptr) {
                curr->stg = newNod;
                return;
            } else
                curr = curr->stg;
        } else {
            if (curr->drp == nullptr) {
                curr->drp = newNod;
                return;
            } else
                curr = curr->drp;
        }
    }
}

shared_ptr<Nod> ArboreBinar::remove(shared_ptr<Nod> nod, int val) {
    if (nod == nullptr) {
        return nullptr;
    } else if (val < nod->val) {
        nod->stg = remove(nod->stg, val);
    } else if (val > nod->val) {
        nod->drp = remove(nod->drp, val);
    } else {
        if (nod->stg == nullptr) {
            shared_ptr<Nod> temp = nod->drp;
            return temp;
        } else if (nod->drp == nullptr) {
            shared_ptr<Nod> temp = nod->stg;
            return temp;
        } else {
            std::shared_ptr<Nod> successor = findMin(nod->stg);
            nod->val = successor->val;
            nod->drp = remove(nod->drp, successor->val);
        }
    }
    return nullptr;
}

std::shared_ptr<Nod> ArboreBinar::findMin(std::shared_ptr<Nod> node) {
    while (node->stg != nullptr) {
        node = node->stg;
    }
    return node;
}

int ArboreBinar::cauta(std::shared_ptr<Nod> root, int val) {
    if (root == nullptr) {
        return 0;
    }

    std::shared_ptr<Nod> curr = root;

    while (curr != nullptr) {
        if (curr->val == val) {
            return 1;
        } else if (val < curr->val) {
            curr = curr->stg;
        } else {
            curr = curr->drp;
        }
    }
    return 0;
}

int ArboreBinar::cel_mai_mare_nr_mai_mic(std::shared_ptr<Nod> root, int X) {
    if (root == nullptr) {
        return -1;
    }

    int Y = -1;
    std::shared_ptr<Nod> curr = root;

    while (curr != nullptr) {
        if (curr->val <= X) {
            Y = curr->val;
            curr = curr->drp;
        } else {
            curr = curr->stg;
        }
    }

    return Y;
}

int ArboreBinar::cel_mai_mic_nr_mai_mare(std::shared_ptr<Nod> root, int X) {
    if (root == nullptr) {
        return -1;
    }

    int Y = -1;
    std::shared_ptr<Nod> curr = root;

    while (curr != nullptr) {
        if (curr->val >= X) {
            Y = curr->val;
            curr = curr->stg;
        } else {
            curr = curr->drp;
        }
    }

    return Y;
}

void ArboreBinar::afiseazaInInterval(std::shared_ptr<Nod> root, int X, int Y) {
    if (root == nullptr) {
        return;
    }

    if (root->val >= X) {
        afiseazaInInterval(root->stg, X, Y);
    }

    if (root->val >= X && root->val <= Y) {
        interval.push_back(root->val);
    }

    if (root->val <= Y) {
        afiseazaInInterval(root->drp, X, Y);
    }
}

class Meniu {
private:
    ArboreBinar tree;
public:
    void start();


};

void Meniu::start() {
    std::ifstream f("abce.in");
    std::ofstream g("abce.out");

    int X, Y, Q, decizie;
    int i;
    cout <<1;
    f >> Q;
    for (i = 0; i < Q; i++) {
        f >> decizie;
        switch (decizie) {
            case 1: {
                f >> X;
                tree.insert(X);
                break;
            }
            case 2: {
                f >> X;
                tree.remove(tree.root, X);
                break;
            }
            case 3: {
                f >> X;
                g << tree.cauta(tree.root, X) << " ";
                break;
            }
            case 4: {
                f >> X;
                g << tree.cel_mai_mare_nr_mai_mic(tree.root, X) << " ";
                break;
            }
            case 5: {
                f >> X;
                g << tree.cel_mai_mic_nr_mai_mare(tree.root, X) << " ";
                break;
            }
            case 6: {
                f >> X >> Y;
                tree.interval.clear();
                tree.afiseazaInInterval(tree.root, X, Y);
                for (auto x: tree.interval)
                    g << x << " ";
                break;
            }
            default:
                break;
        }
    }
    f.close();
    g.close();
}

int main() {
    Meniu M;
    M.start();
    return 0;
}