#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,f16c,fma,sse3,ssse3,sse4.1,sse4.2") 

#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;

template <class T>
class Node {
private:
	T values[3];				// Array of keys
	int valuesCount = 0;		// Counter to know how many keys we have
	bool children[3];

	Node** connects = nullptr;	// Array of child node pointers
	int connectsCount = 0;		// Counter to know how many children we have

public:
	Node(T a) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
	}
	Node(T a, T b) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
		this->addValue(1, b);
	}
	Node(T a, T b, T c) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
		this->addValue(1, b);
		this->addValue(2, c);
	}
	Node(const Node<T>& copyElem) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->connectsCount = copyElem.connectsCount;
		for (int i = 0; i < copyElem.connectsCount; ++i) {
			this->connects[i] = new Node<T>;
			*this->connects[i] = *copyElem.connects[i];
		}
		this->valuesCount = copyElem.valuesCount;
		for (int i = 0; i < copyElem.valuesCount; ++i) {
			this->values[i] = copyElem.values[i];
		}
		for (int i = 0; i < copyElem.valuesCount; ++i) {
			this->children[i] = copyElem.children[i];
		}
	}
	~Node() {
		for (int i = 0; i < this->connectsCount; ++i) {
			delete this->connects[i];
		}
		delete[] this->connects;
		this->connects = nullptr;
	}

	int getValuesCount() {
		return this->valuesCount;
	}
	T getValue(int pos) {
		return this->values[pos];
	}
	void addValue(int pos, T elem) {
		if ((pos + 1) <= this->valuesCount) {
			for (int i = this->valuesCount; i > pos; --i) {
				this->values[i] = this->values[i - 1];
				this->children[i] = this->children[i - 1];
			}
		}
		this->values[pos] = elem;
		this->children[pos] = true;
		++(this->valuesCount);
	}
	void removeValue(int pos) {
		for (int i = pos; i < this->valuesCount - 1; ++i) {
			this->values[i] = this->values[i + 1];
			this->children[i] = this->children[i + 1];
		}
		--(this->valuesCount);
	}

	int getConnectsCount() {
		return this->connectsCount;
	}
	Node<T>* getConnect(int pos) {
		return this->connects[pos];
	}
	void addConnect(int pos, Node<T>* elem) {
		if ((pos + 1) <= this->connectsCount) {
			for (int i = this->connectsCount; i > pos; --i) {
				this->connects[i] = this->connects[i - 1];
			}
		}
		this->connects[pos] = elem;
		++(this->connectsCount);
	}
	void removeConnect(int pos) {
		this->connects[pos] = nullptr;

		for (int i = pos; i < this->connectsCount - 1; ++i) {
			this->connects[i] = this->connects[i + 1];
		}
		--(this->connectsCount);
	}

	bool isLeaf() {
		return this->connectsCount == 0;
	}
	bool isFull() {
		return this->valuesCount == 3;
	}

	void setChild(int index, bool x) {
		this->children[index] = x;
	}
	bool getChild(int index) {
		return this->children[index];
	}
};

template <typename T>
class Tree234 {
private:
	Node<T>* root = nullptr;

	int children = 0;
	int total = 0;
private:
	bool rec_find(Node<T>* currentNode, const T& elem) {
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (currentNode->getChild(i) && currentNode->getValue(i) == elem)
				return true;
		}
		if (currentNode->isLeaf())
			return false;
		else {
			if (currentNode->getValue(0) > elem) {
				return this->rec_find(currentNode->getConnect(0), elem);
			}
			else if (currentNode->getValue(currentNode->getValuesCount() - 1) < elem) {
				return this->rec_find(currentNode->getConnect(currentNode->getConnectsCount() - 1), elem);
			}
			else {
				for (int i = 0; i < currentNode->getValuesCount() - 1; ++i) {
					if ((currentNode->getValue(i) < elem) && (currentNode->getValue(i + 1) > elem)) {
						return this->rec_find(currentNode->getConnect(i + 1), elem);
					}
				}
			}
		}
		return false;
	}
	T rec_getMin(Node<T>* currentNode) {
		if (currentNode->isLeaf())
			return currentNode->getValue(0);
		else
			return rec_getMin(currentNode->getConnect(0));
	}
	T rec_getMax(Node<T>* currentNode) {
		if (currentNode->isLeaf())
			return currentNode->getValue(currentNode->getValuesCount() - 1);
		else
			return rec_getMax(currentNode->getConnect(currentNode->getConnectsCount() - 1));
	}

	void rec_getElements(Node<T>* currentNode, vector<T>& container) {
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (currentNode->getChild(i)) {
				container.push_back(currentNode->getValue(i));
			}
		}
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			rec_getElements(currentNode->getConnect(i), container);
		}
	}
	void rec_getElementsMin(Node<T>* currentNode, vector<T>& container,T minVal) {
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (currentNode->getChild(i) && currentNode->getValue(i) >= minVal) {
				container.push_back(currentNode->getValue(i));
			}
		}
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			rec_getElementsMin(currentNode->getConnect(i), container, minVal);
		}
	}
	void rec_getElementsMax(Node<T>* currentNode, vector<T>& container, T maxVal) {
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (currentNode->getChild(i) && currentNode->getValue(i) <= maxVal) {
				container.push_back(currentNode->getValue(i));
			}
		}
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			rec_getElementsMax(currentNode->getConnect(i), container, maxVal);
		}
	}
	void rec_getSorted(T minVal, T maxVal, Node<T>* currentNode, vector<T>& container) {
		if (currentNode->isLeaf()) {
			for (int i = 0; i < currentNode->getValuesCount(); ++i) {
				if (currentNode->getValue(i) >= minVal && currentNode->getValue(i) <= maxVal)
					container.push_back(currentNode->getValue(i));
			}
		}
		else
		{
			for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
				this->rec_getSorted(minVal, maxVal, currentNode->getConnect(i), container);
				if (i != currentNode->getConnectsCount() - 1) {
					if (currentNode->getValue(i) >= minVal && currentNode->getValue(i) <= maxVal)
						container.push_back(currentNode->getValue(i));
				}
			}
		}
	}

	int rec_getHeight(Node<T>* currentNode) {
		if (currentNode == nullptr) {
			return 0;
		}
		int height = 0;
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			height = max(height, this->rec_getHeight(currentNode->getConnect(i)) + 1);
		}
		return height;
	}
	bool rec_isBalanced(Node<T>* currentNode) {
		if (currentNode == nullptr) {
			return true;
		}
		int first_child_height = this->rec_getHeight(currentNode->getConnect(0));
		for (int i = 1; i < currentNode->getConnectsCount(); ++i) {
			int child_height = this->rec_getHeight(currentNode->getConnect(i));
			if (child_height != first_child_height) {
				return false;
			}
		}
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			if (this->rec_isBalanced(currentNode->getConnect(i)) == false) {
				return false;
			}
		}
		return true;
	}
public:
	void insert(T elem) { // Insert, Top-Down implementation
		if (this->root == nullptr) {
			this->root = new Node<T>(elem);
			++this->total;
			return;
		}

		Node<T>* lastNode = this->root;
		Node<T>* currentNode = this->root;
		while ((currentNode->isLeaf() == false) || (currentNode->isFull() == true)) {
			for (int i = 0; i < currentNode->getValuesCount(); ++i) {
				if (currentNode->getValue(i) == elem) {
					if (currentNode->getChild(i) == false) {
						--children;
						return currentNode->setChild(i, true);
					}
				}
			}

			if (currentNode->isFull() == true) { // Split
				if (currentNode == this->root) { // Split Root

					Node<T>* a = new Node<T>(currentNode->getValue(0));
					Node<T>* b = new Node<T>(currentNode->getValue(2));

					if (currentNode->isLeaf() == false) {
						a->addConnect(0, currentNode->getConnect(0));
						a->addConnect(1, currentNode->getConnect(1));
						b->addConnect(0, currentNode->getConnect(2));
						b->addConnect(1, currentNode->getConnect(3));
					}

					currentNode->removeValue(2);
					currentNode->removeValue(0);
					for (int i = currentNode->getConnectsCount() - 1; i >= 0; --i) {
						currentNode->removeConnect(i);
					}

					currentNode->addConnect(0, b);
					currentNode->addConnect(0, a);
				}
				else { // Split normal node but not leaf
					Node<T>* a = new Node<T>(currentNode->getValue(0));
					Node<T>* b = new Node<T>(currentNode->getValue(2));

					if (currentNode->isLeaf() == false) {
						a->addConnect(0, currentNode->getConnect(0));
						a->addConnect(1, currentNode->getConnect(1));
						b->addConnect(0, currentNode->getConnect(2));
						b->addConnect(1, currentNode->getConnect(3));
					}

					T pushUpValue = currentNode->getValue(1);
					currentNode->removeValue(2);
					currentNode->removeValue(1);
					currentNode->removeValue(0);
					for (int i = currentNode->getConnectsCount() - 1; i >= 0; --i) {
						currentNode->removeConnect(i);
					}

					if (lastNode->getValue(0) > pushUpValue) { // Find index to push our value in
						lastNode->addValue(0, pushUpValue);
						lastNode->removeConnect(0);
						lastNode->addConnect(0, b);
						lastNode->addConnect(0, a);
					}
					else if (lastNode->getValue(lastNode->getValuesCount() - 1) < pushUpValue) {
						lastNode->addValue(lastNode->getValuesCount(), pushUpValue);
						lastNode->removeConnect(lastNode->getConnectsCount() - 1);
						lastNode->addConnect(lastNode->getConnectsCount(), a);
						lastNode->addConnect(lastNode->getConnectsCount(), b);
					}
					else {
						for (int i = 0; i < lastNode->getValuesCount() - 1; ++i) {
							if ((lastNode->getValue(i) < pushUpValue) && (lastNode->getValue(i + 1) > pushUpValue)) {
								lastNode->addValue(i + 1, pushUpValue);
								lastNode->removeConnect(i + 1);
								lastNode->addConnect(i + 1, b);
								lastNode->addConnect(i + 1, a);
								break;
							}
						}
					}

					delete currentNode; // Delete split node
					currentNode = lastNode; // Doing this to parse the tree correctly, currentNode is Undefined after last line
				}
			}

			if (currentNode->isLeaf() == false) { // Moving down a node
				lastNode = currentNode;
				if (currentNode->getValue(0) > elem) {
					currentNode = currentNode->getConnect(0);
				}
				else if (currentNode->getValue(currentNode->getValuesCount() - 1) < elem) {
					currentNode = currentNode->getConnect(currentNode->getConnectsCount() - 1);
				}
				else {
					for (int i = 0; i < currentNode->getValuesCount() - 1; ++i) {
						if ((currentNode->getValue(i) < elem) && (currentNode->getValue(i + 1) > elem)) {
							currentNode = currentNode->getConnect(i + 1);
							break;
						}
					}
				}
			}
		}


		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (currentNode->getValue(i) == elem) {
				if (currentNode->getChild(i) == false) {
					--children;
					return currentNode->setChild(i, true);
				}
			}
		}
		// Actual Inserting
		if (currentNode->getValue(0) > elem) {
			currentNode->addValue(0, elem);
		}
		else if (currentNode->getValue(currentNode->getValuesCount() - 1) < elem) {
			currentNode->addValue(currentNode->getValuesCount(), elem);
		}
		else {
			for (int i = 0; i < currentNode->getValuesCount() - 1; ++i) {
				if ((currentNode->getValue(i) < elem) && (currentNode->getValue(i + 1) > elem)) {
					currentNode->addValue(i + 1, elem);
					break;
				}
			}
		}
		++this->total;
	}
	bool remove(T elem, bool isTopDown) {
		if (this->root == nullptr || 1)
			return this->remove(elem);	// No tree, no deletee :)

		int found = -1;
		int lastConnect = 0;	// Have to know the last entry point to the node
		Node<T>* lastNode = this->root;
		Node<T>* currentNode = this->root;
		while (true) { // Finds the target element
			if (currentNode->isLeaf() == false) { // Validating merge
				Node<T>* leftNode = currentNode->getConnect(0);
				Node<T>* rightNode = currentNode->getConnect(1);
				if ((leftNode->getValuesCount() == 1) && (rightNode->getValuesCount() == 1)) { // Merge artefact
					currentNode->addValue(0, leftNode->getValue(0));
					currentNode->addValue(2, rightNode->getValue(0));
					currentNode->removeConnect(1);
					currentNode->removeConnect(0);
					if (leftNode->isLeaf() == false) {
						currentNode->addConnect(0, leftNode->getConnect(0));
						currentNode->addConnect(1, leftNode->getConnect(1));
						currentNode->addConnect(2, rightNode->getConnect(0));
						currentNode->addConnect(3, rightNode->getConnect(1));
						leftNode->removeConnect(1);
						leftNode->removeConnect(0);
						rightNode->removeConnect(1);
						rightNode->removeConnect(0);
					}
					delete leftNode;
					delete rightNode;
				}
			}

			for (int i = 0; i < currentNode->getValuesCount(); ++i) {
				if (currentNode->getValue(i) == elem) {
					found = i;
					break;
				}
			}

			if (found != -1) break; // Found element

			// Moving down a node
			if (currentNode->isLeaf() == false) {
				lastNode = currentNode;
				if (currentNode->getValue(0) > elem) {
					lastConnect = 0;
					currentNode = currentNode->getConnect(lastConnect);
				}
				else if (currentNode->getValue(currentNode->getValuesCount() - 1) < elem) {
					lastConnect = currentNode->getConnectsCount() - 1;
					currentNode = currentNode->getConnect(lastConnect);
				}
				else {
					for (int i = 0; i < currentNode->getValuesCount() - 1; ++i) {
						if ((currentNode->getValue(i) < elem) && (currentNode->getValue(i + 1) > elem)) {
							lastConnect = i + 1;
							currentNode = currentNode->getConnect(lastConnect);
							break;
						}
					}
				}
			}
			else
				break; // Didn't find anything
		}

		if (found == -1)
			return false;	// Can't find, can't delete


		// Actual Removing
		// Case 1: Element is in a leaf node
		//			a. If node has 2 or 3 keys, delete Element from node
		//			b. If node has 1 key - 3 more cases
		//				i. If node has at least one neighbor with at least 2 keys, rotate operation and delete Element from node
		//				ii. If node has all neighbors with 1 key, and parent has at least 2 keys, merge then delete
		//				iii. If node has all neighbors with 1 key and parent has 1 key, merge parent with neighbors then delete
		// Case 2: Element is in an internal node
		//		1) Find the predecessor of that element. Successor is always a leaf node
		//		2) Switch the predecessor with the Element. Now the Element is in a leaf node
		//		3) Apply Case 1
		if (currentNode->isLeaf() == false) { // Case 2. Execute before case 1 to make code pretty		TODO MERGE WHILE MOVING DOWN
			int newFound = -1; // Should always be found
			lastConnect = found;
			lastNode = currentNode;
			Node<T>* pred = currentNode->getConnect(lastConnect);
			while (true) {
				if (pred->getValuesCount() == 1) { // Validating merge
					Node<T>* leftNode = pred->getConnect(0);
					Node<T>* rightNode = pred->getConnect(1);
					if ((leftNode->getValuesCount() == 1) && (rightNode->getValuesCount() == 1)) { // Merge artefact
						pred->addValue(0, leftNode->getValue(0));
						pred->addValue(2, rightNode->getValue(0));
						pred->removeConnect(1);
						pred->removeConnect(0);
						if (leftNode->isLeaf() == false) {
							pred->addConnect(0, leftNode->getConnect(0));
							pred->addConnect(1, leftNode->getConnect(1));
							pred->addConnect(2, rightNode->getConnect(0));
							pred->addConnect(3, rightNode->getConnect(1));
							leftNode->removeConnect(1);
							leftNode->removeConnect(0);
							rightNode->removeConnect(1);
							rightNode->removeConnect(0);
						}
						delete leftNode;
						delete rightNode;
					}
				}

				if (pred->isLeaf()) {
					newFound = pred->getValuesCount() - 1;
					break;
				}
				else {
					lastNode = pred;
					lastConnect = pred->getConnectsCount() - 1;
					pred = pred->getConnect(lastConnect);
				}
			}

			// Switching elements
			T inter = currentNode->getValue(found);
			currentNode->removeValue(found);
			currentNode->addValue(found, pred->getValue(newFound));
			pred->removeValue(newFound);
			pred->addValue(newFound, inter);

			found = newFound;
			currentNode = pred;
		}

		{ // Case 1
			if (currentNode == this->root) { // Edgecase of root being only node with 1 key
				if (this->root->getValuesCount() == 1) {
					delete this->root;
					return true;
				}
			}

			if (currentNode->getValuesCount() > 1) { // Case 1a
				currentNode->removeValue(found);
			}
			else { // Case 1b
				int lastConnectsCount = lastNode->getConnectsCount();
				bool hasLeft = (lastConnect > 0);
				bool hasRight = (lastConnect < (lastConnectsCount - 1));
				if (hasRight && hasLeft) { // Work with both children, find best one
					Node<T>* leftNeighbor = lastNode->getConnect(lastConnect - 1);
					Node<T>* rightNeighbor = lastNode->getConnect(lastConnect + 1);

					if (leftNeighbor->getValuesCount() == 1) { // Merge left with target and parent
						if (lastNode->getValuesCount() == 1) { // Case1b iii
							lastNode->addValue(0, leftNeighbor->getValue(0));
							lastNode->removeConnect(1);
							lastNode->removeConnect(0);
							delete leftNeighbor;
							delete currentNode;
						}
						else { // Case1b ii
							currentNode->removeValue(0);
							currentNode->addValue(0, leftNeighbor->getValue(0));
							currentNode->addValue(0, lastNode->getValue(lastConnect - 1));
							lastNode->removeValue(lastConnect - 1);
							lastNode->removeConnect(lastConnect - 1);
							delete leftNeighbor;
						}
					}
					else if (rightNeighbor->getValuesCount() == 1) { // Merge right with target and parent
						if (lastNode->getValuesCount() == 1) { // Case1b iii
							lastNode->addValue(1, rightNeighbor->getValue(0));
							lastNode->removeConnect(1);
							lastNode->removeConnect(0);
							delete rightNeighbor;
							delete currentNode;
						}
						else { // Case1b ii
							currentNode->removeValue(0);
							currentNode->addValue(0, lastNode->getValue(lastConnect));
							currentNode->addValue(0, rightNeighbor->getValue(0));
							lastNode->removeValue(lastConnect);
							lastNode->removeConnect(lastConnect + 1);
							delete rightNeighbor;
						}
					}
					else {	// Rotate and remove
						// Implicit rotation from left node to target node
						currentNode->removeValue(0);
						currentNode->addValue(0, lastNode->getValue(lastConnect - 1));
						lastNode->removeValue(lastConnect - 1);
						lastNode->addValue(lastConnect - 1, leftNeighbor->getValue(leftNeighbor->getValuesCount() - 1));
						leftNeighbor->removeValue(leftNeighbor->getValuesCount() - 1);
					}
				}
				else {
					if (hasRight) { // Work with right child
						Node<T>* rightNeighbor = lastNode->getConnect(lastConnect + 1);

						if (rightNeighbor->getValuesCount() == 1) { // Merge right with target and parent
							if (lastNode->getValuesCount() == 1) { // Case1b iii
								lastNode->addValue(1, rightNeighbor->getValue(0));
								lastNode->removeConnect(1);
								lastNode->removeConnect(0);
								delete rightNeighbor;
								delete currentNode;
							}
							else { // Case1b ii
								currentNode->removeValue(0);
								currentNode->addValue(0, lastNode->getValue(lastConnect));
								currentNode->addValue(1, rightNeighbor->getValue(0));
								lastNode->removeValue(lastConnect);
								lastNode->removeConnect(lastConnect + 1);
								delete rightNeighbor;
							}
						}
						else {	// Rotate and remove
							// Implicit rotation from right node to target node
							currentNode->removeValue(0);
							currentNode->addValue(0, lastNode->getValue(lastConnect));
							lastNode->removeValue(lastConnect);
							lastNode->addValue(lastConnect, rightNeighbor->getValue(0));
							rightNeighbor->removeValue(0);
						}
					}
					else { // Work with left child
						Node<T>* leftNeighbor = lastNode->getConnect(lastConnect - 1);

						if (leftNeighbor->getValuesCount() == 1) { // Merge left with target and parent
							if (lastNode->getValuesCount() == 1) { // Case1b iii
								lastNode->addValue(0, leftNeighbor->getValue(0));
								lastNode->removeConnect(1);
								lastNode->removeConnect(0);
								delete leftNeighbor;
								delete currentNode;
							}
							else { // Case1b ii
								currentNode->removeValue(0);
								currentNode->addValue(0, leftNeighbor->getValue(0));
								currentNode->addValue(0, lastNode->getValue(lastConnect - 1));
								lastNode->removeValue(lastConnect - 1);
								lastNode->removeConnect(lastConnect - 1);
								delete leftNeighbor;
							}
						}
						else {	// Rotate and remove
							// Implicit rotation from left node to target node
							currentNode->removeValue(0);
							currentNode->addValue(0, lastNode->getValue(lastConnect - 1));
							lastNode->removeValue(lastConnect - 1);
							lastNode->addValue(lastConnect - 1, leftNeighbor->getValue(leftNeighbor->getValuesCount() - 1));
							leftNeighbor->removeValue(leftNeighbor->getValuesCount() - 1);
						}
					}
				}
			}
		} // If it gets here, element was removed successfully

		return true;
	}
	bool remove(T elem) {
		if (this->root == nullptr)
			return false;

		int found = -1;
		Node<T>* currentNode = this->root;
		while (true) { // Finds the target element
			for (int i = 0; i < currentNode->getValuesCount(); ++i) {
				if (currentNode->getValue(i) == elem) {
					found = i;
					break;
				}
			}

			if (found != -1) break; // Found element

			// Moving down a node
			if (currentNode->isLeaf() == false) {
				if (currentNode->getValue(0) > elem) {
					currentNode = currentNode->getConnect(0);
				}
				else if (currentNode->getValue(currentNode->getValuesCount() - 1) < elem) {
					currentNode = currentNode->getConnect(currentNode->getConnectsCount() - 1);
				}
				else {
					for (int i = 0; i < currentNode->getValuesCount() - 1; ++i) {
						if ((currentNode->getValue(i) < elem) && (currentNode->getValue(i + 1) > elem)) {
							currentNode = currentNode->getConnect(i + 1);
							break;
						}
					}
				}
			}
			else
				break; // Didn't find anything
		}

		if (found == -1)
			return false;	// Can't find, can't delete

		currentNode->setChild(found, false);
		++this->children;

		if (true) { //if (((this->total / 4) <= this->children) && (this->children >= 10)) {
			vector<T> elems;
			this->rec_getElements(this->root, elems);
			delete this->root;
			this->root = nullptr;

			this->children = 0;
			this->total = 0;
			for (int i = 0; i < elems.size(); ++i) {
				this->insert(elems[i]);
			}
		}
		return true;
	}

	bool find(T elem) {
		if (this->root == nullptr)
			return false;
		else
			return this->rec_find(this->root, elem);
	}

	T getMax() {
		return this->rec_getMax(this->root);
	}
	T getMin() {
		return this->rec_getMin(this->root);
	}

	T getPred(T elem) {
		Node<T>* currentNode = this->root;
		int childIndex = -1;
		vector<T> bucket;
		while (currentNode->isLeaf() == false) {
			for (int i = currentNode->getValuesCount() - 1; i >= 0; --i) {
				if (elem == currentNode->getValue(i)) {
					return elem;
				}
				else if (elem > currentNode->getValue(i)) {
					//bucket.push_back(-currentNode->getValue(i));
					childIndex = i + 1;
					break;
				}
				childIndex = 0;
			}
			currentNode = currentNode->getConnect(childIndex);
		}

		for (int i = currentNode->getValuesCount() - 1; i >= 0; --i) {
			if (elem > currentNode->getValue(i)) {
				//bucket.push_back(-currentNode->getValue(i));
			}
			else if (elem == currentNode->getValue(i)) {
				return elem;
			}
		}
		rec_getElementsMax(root, bucket, elem);
		nth_element(bucket.begin(), bucket.begin() + bucket.size() - 1, bucket.end());
		return bucket[bucket.size() - 1];
	}
	bool hasSucc(T elem) {
		vector<T> bucket;
		rec_getElementsMin(root, bucket, elem);
		return bucket.size() != 0;
	}
	T getSucc(T elem) {
		Node<T>* currentNode = this->root;
		int childIndex = -1;
		vector<T> bucket;
		while (currentNode->isLeaf() == false) {
			for (int i = 0; i < currentNode->getValuesCount(); ++i) {
				if (elem == currentNode->getValue(i)) {
					return elem;
				}
				else if (elem < currentNode->getValue(i)) {
					//bucket.push_back(currentNode->getValue(i));
					childIndex = i;
					break;
				}
				childIndex = i + 1;
			}
			currentNode = currentNode->getConnect(childIndex);
		}

		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (elem < currentNode->getValue(i)) {
				bucket.push_back(currentNode->getValue(i));
			}
			else if (elem == currentNode->getValue(i)) {
				return elem;
			}
		}
		rec_getElementsMin(root, bucket, elem);
		nth_element(bucket.begin(), bucket.begin(), bucket.end());
		return bucket[0];
	}

	void getSorted(T minVal, T maxVal, vector<T>& bucket) {
		this->rec_getSorted(minVal, maxVal, this->root, bucket);
	}

	bool testBalance() {
		return this->rec_isBalanced(this->root);
	}
};

ifstream myIn("abce.in");
ofstream myOut("abce.out");

int main() {
	ios_base::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
    Tree234<int> tree;
    
	int tests;
	myIn >> tests;
	for (int i = 0; i < tests; ++i) {
		int testType;
		myIn >> testType;
		if (testType == 1) {
			int nr;
			myIn >> nr;
			tree.insert(nr);
		}
		else if (testType == 2) {
			int nr;
			myIn >> nr;
			tree.remove(nr);
		}
		else if (testType == 3) {
			int nr;
			myIn >> nr;
			myOut << tree.find(nr) << '\n';
		}
		else if (testType == 4) {
			int nr;
			myIn >> nr;
			myOut << tree.getPred(nr) << '\n';
		}
		else if (testType == 5) {
			int nr;
			myIn >> nr;
			myOut << tree.getSucc(nr) << '\n';
		}
		else if (testType == 6) {
			int nr1, nr2;
			myIn >> nr1 >> nr2;
			vector<int> bucket;
			tree.getSorted(nr1, nr2, bucket);
			for (int i = 0; i < bucket.size(); ++i) {
				myOut << bucket[i] << ' ';
			}
			myOut << '\n';
		}
	}

    return 0;
}