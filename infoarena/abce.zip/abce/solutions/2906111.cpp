#include<bits/stdc++.h>
#include<fstream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

class Node{
public:
    int MAXL;
    int key;
    Node **forward;
    Node(int,int);
};
Node::Node(int key, int level)
{
    this->key=key;
    forward= new Node*[level+1];
    memset(forward,0,sizeof(Node*)*(level+1));

}

class SkipList{
    int MAXL;
    float P;
    int level;
    Node* header;
public:
    SkipList(int,float);
    int RandomLvl();
    Node* NewNode(int, int);
    void AdaugareNod(int);
    void CautareNod(int);
    void StergereNod(int);
    void AfisareLista();
    void Cautareminmax(int,int,int);

};

SkipList::SkipList(int MAXL,float P)
{
    this->MAXL=MAXL;
    this->P=P;
    level=0;
    header=new Node(-1,MAXL);
}

int SkipList::RandomLvl()
{
    float r=(float)rand()/RAND_MAX;
    int lvl=0;
    while(lvl<MAXL && r<P)
    {
        lvl++;
        r=(float)rand()/RAND_MAX;
    }
    return lvl;
}

Node* SkipList::NewNode(int key, int level)
{
    Node* n= new Node(key,level);
    return n;
}

void SkipList::AdaugareNod(int key)
{
    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));

    for(int i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current==NULL || current->key!=key)
    {
        int newlevel=RandomLvl();

        if(newlevel>level)
        {
            for(int i=level+1;i<newlevel+1;i++)
                update[i]=header;
            level=newlevel;
        }
        Node* n=NewNode(key,newlevel);
        for(int i=0;i<=newlevel;i++)
        {
            n->forward[i]=update[i]->forward[i];
            update[i]->forward[i]=n;
        }

    }

}


void SkipList::StergereNod(int key)
{

    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));
    for(int i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current!=NULL || current->key==key)
    {
        for(int i=0;i<=level;i++)
        {
            if(update[i]->forward[i]!=current)
                break;
            update[i]->forward[i]=current->forward[i];

        }
        while(level>0&& header->forward[level]==0)
            level--;
    }


}

void SkipList::CautareNod(int key)
{
    Node* current= header;
    for(int i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
    current=current->forward[0];
    if(current and current->key==key)
        g<<1<<endl;
    else
        g<<0<<endl;

}

void SkipList::Cautareminmax(int key, int tip,int y=0)
{
    Node* current=header;
        for(int i =level; i>=0;i--)
            while(current->forward[i]!=NULL && current->forward[i]->key<key)
                current=current->forward[i];

    if(tip==4)
    {
        if(current->forward[0]->key==key)
            g<<current->forward[0]->key<<endl;
        else
            g<<current->key<<endl;
    }
    else if(tip==5)
        g<<current->forward[0]->key<<endl;
    else if(tip==6)
    {
        current=current->forward[0];
        while(current->forward[0]!=NULL && current->forward[0]->key<=y)
        {
            g<<current->key<<" ";
            current=current->forward[0];
        }
        if(current->key<=y)
            g<<current->key;
        g<<endl;
    }
}

SkipList lista(1000,0.2);
int main()
{
    unsigned int Q,tip;
    int x,y;
    f>>Q;
    for(int i=0;i<Q;i++)
    {
        f>>tip;
        f>>x;
        switch(tip)
        {
            case 1:
            {

                lista.AdaugareNod(x);
                break;
            }
            case 2:
            {

                lista.StergereNod(x);
                break;
            }
            case 3:
            {

                lista.CautareNod(x);
                break;
            }
            case 4:
            {

                lista.Cautareminmax(x,tip);
                break;
            }
            case 5:
            {

                lista.Cautareminmax(x,tip);
                break;
            }
            case 6:
            {
                f>>y;
                lista.Cautareminmax(x,tip,y);
                break;
            }


        }


    }
    return 0;
}
