
#include <fstream>
 
using namespace std;
 
ifstream in("abce.in");
ofstream out("abce.out");
 
class Node{
public:
    int key;
    Node *stg;
    Node *dr;
    int inaltime;
};
 
Node* newNode(int key)
{
    Node* node = new Node();
    node->key = key;
    node->stg = NULL;
    node->dr = NULL;
    node->inaltime = 1;
    return(node);
}
 
int inaltime(Node *N)
{
    if (N == NULL)
        return 0;
    return N->inaltime;
}
 
Node *rotatie_dr(Node *y)
{
    Node *x = y->stg;
    Node *T2 = x->dr;
 
    x->dr = y;
    y->stg = T2;
 
    y->inaltime = max(inaltime(y->stg), inaltime(y->dr)) + 1;
    x->inaltime = max(inaltime(x->stg), inaltime(x->dr)) + 1;
 
    return x;
}
 
Node *rotatie_stg(Node *x)
{
    Node *y = x->dr;
    Node *T2 = y->stg;
 
    y->stg = x;
    x->dr = T2;
 
    x->inaltime = max(inaltime(x->stg), inaltime(x->dr)) + 1;
    y->inaltime = max(inaltime(y->stg), inaltime(y->dr)) + 1;
 
    return y;
}
 
int getBalance(Node *N)
{
    if (N == NULL)
        return 0;
    return inaltime(N->stg) - inaltime(N->dr);
}
 
Node* insert(Node* node, int key)
{
    if (node == NULL)
        return(newNode(key));
 
    if (key < node->key)
        node->stg = insert(node->stg, key);
    else if (key > node->key)
        node->dr = insert(node->dr, key);
    else
        return node;
 
    node->inaltime = 1 + max(inaltime(node->stg), inaltime(node->dr));
 
    int balance = getBalance(node);
 
    if (balance > 1 && key < node->stg->key)
        return rotatie_dr(node);
 
    if (balance < -1 && key > node->dr->key)
        return rotatie_stg(node);
 
    if (balance > 1 && key > node->stg->key)
    {
        node->stg = rotatie_stg(node->stg);
        return rotatie_dr(node);
    }
 
    if (balance < -1 && key < node->dr->key)
    {
        node->dr = rotatie_dr(node->dr);
        return rotatie_stg(node);
    }
 
    return node;
}
 
Node * minim(Node* node)
{
    Node* current = node;
 
    while (current->stg != NULL)
        current = current->stg;
 
    return current;
}
 
Node* deleteNode(Node* rad, int key)
{
    if (rad == NULL)
        return rad;
 
    if ( key < rad->key )
        rad->stg = deleteNode(rad->stg, key);
 
    else if( key > rad->key )
        rad->dr = deleteNode(rad->dr, key);
 
    else
    {
        if( (rad->stg == NULL) || (rad->dr == NULL) )
        {
            Node *temp = rad->stg ?  rad->stg :  rad->dr;
 
            // No child case
            if (temp == NULL)
            {
                temp = rad;
                rad = NULL;
            }
            else
                *rad = *temp;
 
            free(temp);
        }
        else
        {
            Node* temp = minim(rad->dr);
 
            rad->key = temp->key;
 
            rad->dr = deleteNode(rad->dr,
                                     temp->key);
        }
    }
 
    if (rad == NULL)
        return rad;

    rad->inaltime = 1 + max(inaltime(rad->stg), inaltime(rad->dr));
 
    int balance = getBalance(rad);
 
    if (balance > 1 && getBalance(rad->stg) >= 0)
        return rotatie_dr(rad);
 
    if (balance > 1 && getBalance(rad->stg) < 0)
    {
        rad->stg = rotatie_stg(rad->stg);
        return rotatie_dr(rad);
    }
 
    if (balance < -1 && getBalance(rad->dr) <= 0)
        return rotatie_stg(rad);
 
    if (balance < -1 && getBalance(rad->dr) > 0)
    {
        rad->dr = rotatie_dr(rad->dr);
        return rotatie_stg(rad);
    }
 
    return rad;
}
 
bool find(Node *rad, int key)
{
    if(rad == NULL)
        return false;
    if(rad->key < key)
        return find(rad->dr, key);
    if(rad->key > key)
        return find(rad->stg, key);
    return true;
}
 
void ordine(Node *rad)
{
    if(rad != NULL)
    {
        ordine(rad->stg);
        out << rad->key << " ";
        ordine(rad->dr);
    }
}
 
int cmmare(Node *rad, int x)
{
    int ret = -2000000000;
    if(rad != NULL)
    {
        if(rad->key == x)
            ret = rad->key;
        else if(rad->key > x)
            ret = cmmare(rad->stg, x);
        else if(rad->key < x)
            ret = max(rad->key, cmmare(rad->dr, x));
    }
    return ret;
}
 
int cmmic(Node *rad, int x)
{
    int ret = 2000000000;
    if(rad != NULL)
    {
        if(rad->key == x)
            ret = rad->key;
        else if(rad->key < x)
            ret = cmmic(rad->dr, x);
        else if(rad->key > x)
            ret = min(rad->key, cmmic(rad->stg, x));
    }
    return ret;
}
 
void print(Node *rad, int x, int y)
{
    if(rad != NULL)
    {
        if(rad->key > x)
            print(rad->stg, x, y);
 
        if(rad->key >= x && rad->key <= y)
            out << rad->key << ' ';
 
        if(rad->key < y)
            print(rad->dr, x, y);
    }
}
int main()
{
    Node *rad = NULL;
    int n, Q, x, y;
    in >> n;
    for(int i = 1; i <= n; i++)
    {
        in >> Q;
        switch(Q)
        {
        case 1:
            in >> x;
            rad = insert(rad, x);
            break;
        case 2:
            in >> x;
            rad = deleteNode(rad, x);
            break;
        case 3:
            in >> x;
            out << find(rad, x) << '\n';
            break;
        case 4:
            in >> x;
            out << cmmare(rad, x) << '\n';
            break;
        case 5:
            in >> x;
            out << cmmic(rad, x) << '\n';
            break;
        default:
            in >> x >> y;
            print(rad, x, y);
            out << '\n';
        }
 
    }
    return 0;
}