#include <iostream>
#include <bits/stdc++.h>
#include<fstream>
using namespace std;
struct nodtreap{
    int key,prioritate;
    nodtreap *st,*dr;

    nodtreap(int n)
    {
        this->key=n;
        this->prioritate=rand();
        this->st=this->dr=nullptr;
    }
};
ifstream r("abce.in");
ofstream w("abce.out");

class Treap{
public:

    nodtreap *Rotiridreapta(nodtreap* n){    //right rotate
        nodtreap* s = n->st;
        nodtreap* d = s->dr;
        s->dr=n;
        n->st=d;
        return s;
    }


    nodtreap *Rotiristanga(nodtreap*n ){
        nodtreap* m = n->dr;
        nodtreap* p = m->st;
        m->st=n;
        n->dr=p;
        return m;
    }

    nodtreap *cautare(nodtreap*n, int x)
    {
        if (n == NULL || n->key == x)
            return n;
        if (n->key < x)
            return cautare(n->dr, x);


        return cautare(n->st, x);
    }

    nodtreap  *inserare(nodtreap*n , int x)
    {
        if(!n){
            n= new nodtreap(x);
            *n=nodtreap(x);
        }
        if (x < n->key) {
            inserare(n->st, x);
            if (n->st != nullptr && n->st->prioritate > n->prioritate)
                Rotiridreapta(n);
        } else {
            inserare(n->dr, x);
            if (n->dr!= nullptr && n->dr->prioritate > n->prioritate)
                Rotiristanga(n);
        }
    }

    nodtreap *stergere(nodtreap *n,int x){
        if (n == NULL)
            return n;

        if (x < n->key)
            n->st = stergere(n->st, x);
        else if (x > n->key)
            n->dr = stergere(n->dr, x);
        else if (n->st == NULL)
        {   nodtreap *y = n->dr;
            delete(n);
            n = y;
        }
        else if (n->dr == NULL)
        {
            nodtreap *y = n->st;
            delete(n);
            n= y;
        }
        else if (n->st->prioritate < n->dr->prioritate)
        {
            n = Rotiristanga(n);
            n->st = stergere(n->st, x);
        }
        else
        {
            n = Rotiridreapta(n);
            n->dr = stergere(n->dr, x);
        }

        return n;
    }

    int maxY(int x, nodtreap*n )
    {   int max=-1000000000;
        while(n){
            if(x<n->key)//un fel de parcurgere inorder
                n=n->st;
            else
            if(x>n->key)
            {if(n->key>max)
                    max=n->key;
                n=n->dr;
            }
            else
                return x;
        }
        return max;
    }
    int minY(int x, nodtreap*n )
    {   int min=1000000000;
        while(n){
            if(x>n->key)
                n=n->dr;
            else
            if(x<n->key)
            {if(n->key<min)
                    min=n->key;
                n=n->st;
            }
            else
                return x;
        }
        return min;
    }

    void cerinta6i(nodtreap *radacina, int x, int y) {
        if (radacina) {
            cerinta6i(radacina->st, x, y);
            if (radacina->key >= x and radacina->key <= y)
                w << radacina->key << " ";
            cerinta6i(radacina->dr, x, y);
        }}





};
int main() {
    srand(time(NULL));
    int cerinta,n,x,y,i;
    nodtreap* radacina = nullptr;
    r>>n;
    Treap treap;
    for(i=0;i<n;i++)
    {
        r>>cerinta;
        if(cerinta==1){
            r>>x;
            treap.inserare(radacina,x);

        } else if (cerinta==2){
            r>>x;
            treap.stergere(radacina,x);
        }else if(cerinta==3){
            r>>x;
            if(treap.cautare(radacina,x))
                w<<"1"<<endl;
            else
                w<<"0"<<endl;;
        } else if(cerinta==4){
            r>>x;
            int y;
            y=treap.maxY( x, radacina);
            if(y>-1000000000)
                w<<y<<endl;
            else
                w<<endl;
        }else if(cerinta==5){
            r>>x;
            int y;
            y=treap.minY( x, radacina);
            if(y<1000000000)
                w<<y<<endl;
            else
                w<<endl;

        }else{
            r>>x>>y;
            treap.cerinta6i(radacina,x,y);
            w<<endl;
        }

    }
    return 0;
}
