#include <iostream>
#include <bits/stdc++.h>
#include<fstream>
using namespace std;
struct nodtreap{
    int key,prioritate;
    nodtreap *st,*dr;

    nodtreap(){
        this->key=NULL;
        this->prioritate=-1;
        this->st= nullptr;
        this->dr=nullptr;
    }

    nodtreap(int n)
    {
        this->key=n;
        this->prioritate=rand();
        this->st=this->dr=nullptr;
    }

};
ifstream r("abce.in");
ofstream w("abce.out");

class Treap{

    nodtreap *radacina;
    nodtreap static *Rotiridreapta(nodtreap* n){    //right rotate
        nodtreap* s = n->st;
        nodtreap* d = s->dr;
        s->dr=n;
        n->st=d;
        return s;
    }


    nodtreap static *Rotiristanga(nodtreap*n ){
        nodtreap* m = n->dr;
        nodtreap* p = m->st;
        m->st=n;
        n->dr=p;
        return m;
    }

    nodtreap *cautare(nodtreap*n, int x)
    {
        if(n== nullptr or n->key==x)
            return n;
        if(x > n->key)
            return cautare(n->dr,x);
        else
            return cautare(n->st,x );
    }
public:
    Treap() {
        radacina=NULL;
    }
    void cerinta3(int x){
        if(cautare(radacina,x))
            w<<"1"<<endl;
        else
            w<<"0"<<endl;

    }
    nodtreap  *inserare(nodtreap *n , int x)
    {
            if(n==NULL){
                n=new nodtreap;
                *n=nodtreap(x);
            }
            else if(x < n->key){
                n->st = inserare(n->st,x);
                if(n->st->prioritate > n->prioritate)
                    n=Rotiridreapta(n);
            }
            else if(x > n->key){
                n->dr = inserare(n->dr,x);
                if(n->dr->prioritate > n->prioritate)
                    n=Rotiristanga(n);
            }
            return n;

    }

    nodtreap *stergere(nodtreap *n,int x){
        if (n == NULL)
            return n;

        if (x < n->key)
            n->st = stergere(n->st, x);
        else if (x > n->key)
            n->dr = stergere(n->dr, x);
        else if (n->st == NULL)
        {   nodtreap *y = n->dr;
            delete(n);
            n = y;
        }
        else if (n->dr == NULL)
        {
            nodtreap *y = n->st;
            delete(n);
            n= y;
        }
        else if (n->st->prioritate < n->dr->prioritate)
        {
            n = Rotiristanga(n);
            n->st = stergere(n->st, x);
        }
        else
        {
            n = Rotiridreapta(n);
            n->dr = stergere(n->dr, x);
        }

        return n;
    }

    int maxY(int x, nodtreap*n )
    {   int max=-1000000000;
        while(n){
            if(x<n->key)//un fel de parcurgere inorder
                n=n->st;
            else
            if(x>n->key)
            {if(n->key>max)
                    max=n->key;
                n=n->dr;
            }
            else
                return x;
        }
        return max;
    }
    int minY(int x, nodtreap*n )
    {   int min=1000000000;
        while(n){
            if(x>n->key)
                n=n->dr;
            else
            if(x<n->key)
            {if(n->key<min)
                    min=n->key;
                n=n->st;
            }
            else
                return x;
        }
        return min;
    }

    void cerinta6i(nodtreap *n, int x, int y) {
        if (n) {
            cerinta6i(n->st, x, y);
            if (n->key >= x and n->key <= y)
                w << n->key << " ";
            cerinta6i(n->dr, x, y);
        }}

};
int main() {
    srand(time(NULL));
    int cerinta,n,x,y,i;
    nodtreap* radacina = nullptr;
    r>>n;
    Treap treap;
    for(i=0;i<n;i++)
    {
        r>>cerinta;
        if(cerinta==1){
            r>>x;
            treap.inserare(radacina,x);

        } else if (cerinta==2){
            r>>x;
            treap.stergere(radacina,x);
        }else if(cerinta==3){
            r>>x;
            treap.cerinta3(x);

        } else if(cerinta==4){
            r>>x;
            y=treap.maxY( x, radacina);
            if(y>-1000000000)
                w<<y<<endl;
            else
                w<<endl;
        }else if(cerinta==5){
            r>>x;
            y=treap.minY( x, radacina);
            if(y<1000000000)
                w<<y<<endl;
            else
                w<<endl;

        }else{
            r>>x>>y;
            treap.cerinta6i(radacina,x,y);
            w<<endl;
        }

    }
    return 0;
}
