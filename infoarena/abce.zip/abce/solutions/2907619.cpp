#include <iostream>
#include <fstream>
enum COLOR{RED, BLACK};
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

struct Node{
    COLOR color;
    int key;
    Node *lft, *rgt, *p;
    
    Node(COLOR _color, int _key, Node* _lft, Node* _rgt, Node* _p){
        color= _color;
        key= _key;
        lft= _lft;
        rgt= _rgt;
        p= _p;
    }
};
typedef struct Node* Nod;
 
class RBT{
private:
    Nod root;
    Nod NIL;
 
    Nod T_Minim(Nod x);
    Nod T_Maxim(Nod x);
    Nod SearchNode(int val);
    void LeftRotate(Nod x);
    void RightRotate(Nod x);
    void InsertNode(Nod z);
    void InsertFixup(Nod z);
    void Replace(Nod u, Nod v);
    void DeleteNode(Nod z);
    void DeleteFixup(Nod x);
public:
    RBT(){
        NIL = new Node(BLACK, 0, nullptr, nullptr, nullptr);
        root = NIL;
    }
    int Minim();
    int Maxim();
    int Search(int val);
    void Insert(int val);
    void Delete(int val);
    int Successor(int val);
    int Predecessor(int val);
    void Sort(int l, int r);
};

Nod RBT:: T_Minim(Nod x){
    while(x-> lft!=NIL)
    x=x->lft;
    return x;
}
Nod RBT::T_Maxim(Nod x){
    while(x-> rgt!=NIL)
    x=x->lft;
    return x;
}
int RBT::Minim(){
    return T_Minim(root)->key;
} 
int RBT::Maxim(){
    return T_Maxim(root)->key;
} 

Nod RBT:: SearchNode( int val){
    Nod x=root;
    while(x!=NIL&& x->key!=val){
        if(val<x->key)
        x=x->lft;
        else
        x=x->rgt;
    } return x;
}
int RBT::Search(int val){
    return SearchNode(val) != NIL;
}
void RBT::LeftRotate(Nod x){
    Node *y = x -> rgt;
    x->rgt= y->lft;
    if(y->lft!= NIL)
    y->lft-> p=x;
    y->p= x->p;
    if(x->p== NIL)
    root= y;
    else if(x== x->p-> lft)
    x -> p-> lft= y;
    else
    x-> p-> rgt= y;
    y-> lft= x;
    x-> p= y;
}
void RBT::RightRotate(Nod x){
    Node *y = x -> lft;
    x->rgt= y->rgt;
    if(y->rgt!= NIL)
    y->rgt-> p=x;
    y->p= x->p;
    if(x->p== NIL)
    root= y;
    else if(x== x->p-> rgt)
    x -> p-> rgt= y;
    else
    x-> p-> lft= y;
    y-> rgt= x;
    x-> p= y;
}
void RBT::InsertNode(Nod z){
    Node *y= NIL;
    Node *x= root;
    while(x!= NIL){
        y= x;
        if(z->key<x->key)
            x= x ->lft;
        else
            x= x->rgt;
    }
    z->p= y;
    if(y== NIL)
        root= z;
    else if(z->key<y->key)
        y->lft= z;
    else
        y->rgt= z;
    z -> lft= NIL;
    z -> rgt= NIL;
    z -> color= RED;
    InsertFixup(z);
}
void RBT::InsertFixup(Nod z){
    while(z->p -> color == RED)
        if(z -> p == z->p->p-> lft){
            Nod y = z -> p -> p -> rgt;
            if(y ->color== RED){
                z ->p->color= BLACK;
                y ->color= BLACK;
                z ->p -> p -> color=RED;
                z = z -> p -> p;
            }
            else{
                if(z == z -> p ->rgt){
                    z = z -> p;
                    LeftRotate(z);
                }
                z -> p -> color=BLACK;
                z -> p -> p -> color=RED;
                RightRotate(z -> p -> p);
            }
        }
        else{
            Nod y = z -> p -> p -> lft;
            if(y -> color==RED){
                z -> p -> color=BLACK;
                y -> color=BLACK;
                z -> p -> p -> color=RED;
                z = z -> p -> p;
            }
            else{
                if(z == z -> p -> lft){
                    z = z -> p;
                    RightRotate(z);
                }
                z -> p -> color=BLACK;
                z -> p -> p -> color=RED;
                LeftRotate(z -> p -> p);
            }
        }
    root->color=BLACK;
}
void RBT::Insert(int val){
    Node *z = new Node(RED, val, NIL, NIL, NIL);
    InsertNode(z);
}
void RBT::Replace(Nod u, Nod v){
    if(u -> p== NIL)
        root=v;
    else if(u== u -> p -> lft)
        u -> p -> lft = v;
    else
        u -> p -> rgt = v;
    v -> p = u -> p;
}
void RBT::DeleteNode(Nod z){
    Nod x, y = z;
    COLOR yOriginalColor = y -> color;
    if(z -> lft == NIL){
        x = z -> rgt;
        Replace(z, z -> rgt);
    }
    else if(z -> rgt == NIL){
        x = z -> lft;
        Replace(z, z -> lft);
    }
    else{
        y = T_Minim(z -> rgt);
        yOriginalColor = y -> color;
        x = y -> rgt;
        if(y -> p == z)
            x -> p = y;
        else{
            Replace(y, y -> rgt);
            y -> rgt = z -> rgt;
            y -> rgt -> p = y;
        }
        Replace(z, y);
        y -> lft = z -> lft;
        y -> lft -> p = y;
        y -> color = z -> color;
    }
    if(yOriginalColor == BLACK)
        DeleteFixup(x);
}
void RBT::DeleteFixup(Nod x){
    while(x != root && x -> color == BLACK){
        if(x == x -> p -> lft){
            Nod w = x -> p -> rgt;
            if(w -> color==RED){
                w -> color=BLACK;
                x -> p -> color=RED;
                LeftRotate(x -> p);
                w = x -> p -> rgt;
            }
            if(w -> lft -> color == BLACK && w -> rgt -> color == BLACK){
                w -> color = RED;
                x = x -> p;
            }
            else{
                if(w -> rgt -> color == BLACK){
                    w -> lft -> color = BLACK;
                    w -> color = RED;
                    RightRotate(w);
                    w = x -> p -> rgt;
                }
                w -> color = x -> p -> color;
                x -> p -> color = BLACK;
                w -> rgt -> color = BLACK;
                LeftRotate(x -> p);
                x = root;
            }
        }
        else{
            Nod w = x -> p -> lft;
            if(w -> color == RED){
                w -> color = BLACK;
                x -> p -> color = RED;
                RightRotate(x -> p);
                w = x -> p -> lft;
            }
            if(w -> lft -> color == BLACK && w -> rgt -> color == BLACK){
                w -> color = RED;
                x = x -> p;
            }
            else{
                if(w -> lft -> color == BLACK){
                    w -> rgt -> color = BLACK;
                    w -> color = RED;
                    LeftRotate(w);
                    w = x -> p -> lft;
                }
                w -> color = x -> p -> color;
                x -> p -> color = BLACK;
                w -> lft -> color = BLACK;
                RightRotate(x -> p);
                x = root;
            }
        }
    }
    x -> color = BLACK;
}
void RBT::Delete(int val){
    Nod x = SearchNode(val);
    if(x != NIL)
        DeleteNode(x);
}
int RBT::Successor(int val){
    Nod x = root;
    int ans;
    while(x != NIL){
        if(x -> key == val)
            return x -> key;
        if(x -> key < val)
            x = x -> rgt;
        else{
            ans = x -> key;
            x = x -> lft;
        }
    }
    return ans;
}
int RBT::Predecessor(int val){
    Nod x = root;
    int ans;
    while(x != NIL){
        if(x -> key == val)
            return x -> key;
        if(x -> key > val)
            x = x -> lft;
        else{
            ans = x -> key;
            x = x -> rgt;
        }
    }
    return ans;
}
void RBT::Sort(int l, int r){
    int next = Successor(l);
    while(next <= r){
        g<< next << " ";
        next = Successor(next + 1);
    }
}
 
int main(){
    RBT *T= new RBT();
    int q;
    f>>q;
    for(int i=0; i<q; i++){
        int oper, x, y;
        f>>oper;
        if(oper==1){
            f>>x;
            T->Insert(x);
        }
        if(oper==2){
            f>>x;
            T->Delete(x);
        }
        if(oper==3){
            f>>x;
            g<<T->Search(x)<<"\n";
        }
        if(oper==4){
            f>>x;
            g<<T->Predecessor(x)<<"\n";
        }
        if(oper==5){
            f>>x;
            g<<T->Successor(x)<<"\n";
        }
        if(oper==6){
            f>>x>>y;
            T->Sort(x,y);
            g<<"\n";
        }
    }
    return 0;
}



