#include <fstream>
#include <functional>
#include <iostream>
#include <vector>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
// #define f cin
// #define g cout

struct Tree {
  int *keys;       // Array of keys
  int t;           // Minimum degree
  Tree **C;        // Array of child pointers
  int n;           // Current number of keys
  bool leaf_node;  // True if leaf node

  Tree(int _t, bool _leaf_node) {
    t = _t;
    leaf_node = _leaf_node;
    keys = new int[2 * t - 1];
    C = new Tree *[2 * t];
    n = 0;
  }

  void traverse() {
    int i;
    for (i = 0; i < n; i++) {
      if (!leaf_node) C[i]->traverse();
      cout << " " << keys[i];
    }
    if (!leaf_node) C[i]->traverse();
  }

  int findKey(int k) {
    int idx = 0;
    while (idx < n && keys[idx] < k) ++idx;
    return idx;
  }

  void insert_more(int k) {
    int i = n - 1;

    if (leaf_node) {
      while (i >= 0 && keys[i] > k) {
        keys[i + 1] = keys[i];
        i--;
      }
      keys[i + 1] = k;
      n++;
    } else {
      while (i >= 0 && keys[i] > k) i--;

      if (C[i + 1]->n == 2 * t - 1) {
        split_child(i + 1, C[i + 1]);

        if (keys[i + 1] < k) i++;
      }
      C[i + 1]->insert_more(k);
    }
  }

  void split_child(int i, Tree *y) {
    Tree *z = new Tree(y->t, y->leaf_node);
    z->n = t - 1;

    for (int j = 0; j < t - 1; j++) z->keys[j] = y->keys[j + t];

    if (!y->leaf_node) {
      for (int j = 0; j < t; j++) z->C[j] = y->C[j + t];
    }

    y->n = t - 1;

    for (int j = n; j >= i + 1; j--) C[j + 1] = C[j];

    C[i + 1] = z;

    for (int j = n - 1; j >= i; j--) keys[j + 1] = keys[j];

    keys[i] = y->keys[t - 1];
    n++;
  }

  void Deletenode(int k) {
    int idx = findKey(k);

    if (idx < n && keys[idx] == k) {
      if (leaf_node)
        remove_leaf_node(idx);
      else
        remove_nonleaf_node(idx);
    } else {
      if (leaf_node) {
        cout << "The key " << k << " does not exist in the tree\n";
        return;
      }

      bool flag = (idx == n);

      if (C[idx]->n < t) fill(idx);

      if (flag && idx > n)
        C[idx - 1]->Deletenode(k);
      else
        C[idx]->Deletenode(k);
    }
  }

  void remove_leaf_node(int idx) {
    for (int i = idx + 1; i < n; ++i) keys[i - 1] = keys[i];
    n--;
  }

  void remove_nonleaf_node(int idx) {
    int k = keys[idx];

    if (C[idx]->n >= t) {
      int pred = get_pre(idx);
      keys[idx] = pred;
      C[idx]->Deletenode(pred);
    } else if (C[idx + 1]->n >= t) {
      int succ = get_suc(idx);
      keys[idx] = succ;
      C[idx + 1]->Deletenode(succ);
    } else {
      merge(idx);
      C[idx]->Deletenode(k);
    }
  }

  int get_pre(int idx) {
    Tree *cur = C[idx];
    while (!cur->leaf_node) cur = cur->C[cur->n];
    return cur->keys[cur->n - 1];
  }

  int get_suc(int idx) {
    Tree *cur = C[idx + 1];
    while (!cur->leaf_node) cur = cur->C[0];
    return cur->keys[0];
  }

  void fill(int idx) {
    if (idx != 0 && C[idx - 1]->n >= t)
      borrow_prev(idx);
    else if (idx != n && C[idx + 1]->n >= t)
      borrow_next(idx);
    else {
      if (idx != n)
        merge(idx);
      else
        merge(idx - 1);
    }
  }

  void borrow_prev(int idx) {
    Tree *child = C[idx];
    Tree *sibling = C[idx - 1];

    for (int i = child->n - 1; i >= 0; i--) child->keys[i + 1] = child->keys[i];

    if (!child->leaf_node) {
      for (int i = child->n; i >= 0; i--) child->C[i + 1] = child->C[i];
    }

    child->keys[0] = keys[idx - 1];

    if (!child->leaf_node) child->C[0] = sibling->C[sibling->n];

    keys[idx - 1] = sibling->keys[sibling->n - 1];

    child->n += 1;
    sibling->n -= 1;
  }

  void borrow_next(int idx) {
    Tree *child = C[idx];
    Tree *sibling = C[idx + 1];

    child->keys[child->n] = keys[idx];

    if (!child->leaf_node) child->C[child->n + 1] = sibling->C[0];

    keys[idx] = sibling->keys[0];

    for (int i = 1; i < sibling->n; i++)
      sibling->keys[i - 1] = sibling->keys[i];

    if (!sibling->leaf_node) {
      for (int i = 1; i <= sibling->n; i++) sibling->C[i - 1] = sibling->C[i];
    }

    child->n += 1;
    sibling->n -= 1;
  }

  void merge(int idx) {
    Tree *child = C[idx];
    Tree *sibling = C[idx + 1];

    child->keys[t - 1] = keys[idx];

    for (int i = 0; i < sibling->n; i++) child->keys[i + t] = sibling->keys[i];

    if (!child->leaf_node) {
      for (int i = 0; i <= sibling->n; i++) child->C[i + t] = sibling->C[i];
    }

    for (int i = idx + 1; i < n; i++) keys[i - 1] = keys[i];

    for (int i = idx + 2; i <= n; i++) C[i - 1] = C[i];

    child->n += sibling->n + 1;
    n--;

    delete sibling;
  }
};

struct BTree {
  Tree *root;
  int t;

  BTree(int _t) {
    root = nullptr;
    t = _t;
  }

  void traverse() {
    if (root) root->traverse();
  }

  void insert_more(int k) {
    if (!root) {
      root = new Tree(t, true);
      root->keys[0] = k;
      root->n = 1;
    } else {
      if (root->n == 2 * t - 1) {
        Tree *s = new Tree(t, false);
        s->C[0] = root;
        s->split_child(0, root);

        int i = 0;
        if (s->keys[0] < k) i++;
        s->C[i]->insert_more(k);

        root = s;
      } else {
        root->insert_more(k);
      }
    }
  }

  void Deletenode(int k) {
    if (!root) {
      cout << "The tree is empty\n";
      return;
    }

    root->Deletenode(k);

    if (root->n == 0) {
      Tree *tmp = root;
      if (root->leaf_node)
        root = nullptr;
      else
        root = root->C[0];

      delete tmp;
    }
  }
};

BTree *b;
// BOILERPLATE START
void init();
void add(int x);
void erase(int x);
int exists(int x);
int succesor(int x);
int predecesor(int x);
void parcurgere(int x, int y);
int main() {
  std::ios_base::sync_with_stdio(false);
  f.tie(0);
  int _, op, x, y;
  f >> _;
  init();
  do {
    f >> op >> x;
    switch (op) {
      case 1:
        add(x);
        break;
      case 2:
        erase(x);
        break;
      case 3:
        g << exists(x) << '\n';
        break;
      case 5:
        g << succesor(x) << '\n';
        break;
      case 4:
        g << predecesor(x) << '\n';
        break;
      case 6:
        cin >> y;
        parcurgere(x, y);
        break;
    }
  } while (_ -= 1);
  return 0;
}
// BOILERPLATE END
void init() {
  b = new BTree(3);  // Initialize with minimum degree 3
}

void add(int x) { b->insert_more(x); }

void erase(int x) { b->Deletenode(x); }

int exists(int x) {
  Tree *current = b->root;
  while (current) {
    int i = 0;
    while (i < current->n && current->keys[i] < x) i++;
    if (i < current->n && current->keys[i] == x) return 1;
    if (current->leaf_node) return 0;
    current = current->C[i];
  }
  return 0;
}

int succesor(int x) {
  Tree *current = b->root;
  int succ = -1;
  while (current) {
    for (int i = 0; i < current->n; i++) {
      if (current->keys[i] > x) {
        succ = current->keys[i];
        if (!current->leaf_node) {
          current = current->C[i];
          break;
        } else
          return succ;
      }
    }
    if (!current->leaf_node)
      current = current->C[current->n];
    else
      break;
  }
  return succ;
}

int predecesor(int x) {
  Tree *current = b->root;
  int pred = -1;
  while (current) {
    for (int i = current->n - 1; i >= 0; i--) {
      if (current->keys[i] < x) {
        pred = current->keys[i];
        if (!current->leaf_node) {
          current = current->C[i + 1];
          break;
        } else
          return pred;
      }
    }
    if (!current->leaf_node)
      current = current->C[0];
    else
      break;
  }
  return pred;
}

void parcurgere(int x, int y) {
  vector<int> result;
  Tree *current = b->root;

  function<void(Tree *)> traverse = [&](Tree *node) {
    if (!node) return;
    int i;
    for (i = 0; i < node->n; i++) {
      if (node->keys[i] >= x && node->keys[i] <= y)
        result.push_back(node->keys[i]);
      if (!node->leaf_node) traverse(node->C[i]);
    }
    if (!node->leaf_node) traverse(node->C[i]);
  };

  traverse(current);

  for (int val : result) cout << val << " ";
  cout << '\n';
}
