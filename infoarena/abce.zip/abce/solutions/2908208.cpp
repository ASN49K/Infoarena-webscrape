#include <iostream>
#include <fstream>
using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");

int x, a, b, op, q;

class node
{

    int *keys, t, n;
    node **children;
    bool isLeaf;

public:
    node(int, bool);
    void print();
    void printInterval();
    node *search(int);
    int nextKey(int);
    void insertIntoChild(int);
    void splitFullChild(int, node *);
    void erase(int);
    void eraseFromLeaf(int);
    void eraseFromNonLeaf(int);
    int getPrev(int);
    int getNext(int);
    void fillChild(int);
    void borrowFromPrev(int);
    void borrowFromNext(int);
    void mergeChildren(int);
    int nextSmallest(int, int);
    int prevBiggest(int, int);
    friend class BTree;
};

class BTree
{

    node *root;
    int t;

public:
    BTree(int minDegree)
    {
        root = NULL;
        t = minDegree;
    }
    void print()
    {
        if (root)
            root->print();
    }
    void printInterval()
    {
        if (root)
            root->printInterval();
    }
    node *search(int key)
    {
        return (root == NULL) ? NULL : root->search(key);
    }
    void insert(int key);
    void erase(int key);
    int nextSmallest(int x)
    {
        int i = 0;
        while (i < root->n && x > root->keys[i])
            i++;
        int above = root->keys[i];
        return (root == NULL) ? 0 : root->nextSmallest(x, above);
    }
    int prevBiggest(int x)
    {
        int i = 0;
        while (i < root->n && x > root->keys[i])
            i++;
        int above;
        if (i == 0)
            above = root->keys[0];
        else
            above = root->keys[i - 1];
        return (root == NULL) ? 0 : root->prevBiggest(x, above);
    }
};

int node::nextSmallest(int x, int above)
{
    int i = 0;
    while (i < n && x > keys[i])
        i++;
    if (isLeaf)
        if (i == n)
            return above;
        else
            return keys[i];
    above = keys[i];
    return children[i]->nextSmallest(x, above);
}

int node::prevBiggest(int x, int above)
{
    int i = 0;
    while (i < n && x > keys[i])
        i++;
    if (i == 0)
        return above;
    if (isLeaf)
        if (i == 0)
            return above;
        else
            return keys[i - 1];

    above = keys[i - 1];
    return children[i]->prevBiggest(x, above);
}

node *node::search(int key)
{
    int i = 0;
    while (i < n && key > keys[i])
        i++;

    if (keys[i] == key)
        return this;

    if (isLeaf == true)
        return NULL;
    return children[i]->search(key);
}

node::node(int minDegree, bool leaf)
{
    t = minDegree;
    isLeaf = leaf;
    keys = new int[2 * t - 1];
    children = new node *[2 * t];
    n = 0;
}

int node::nextKey(int key)
{
    int index = 0;
    while (index < n && keys[index] < key)
        ++index;
    return index;
}

void node::erase(int key)
{
    int index = nextKey(key);
    if (index < n && keys[index] == key)
    {
        if (isLeaf)
            eraseFromLeaf(index);
        else
            eraseFromNonLeaf(index);
    }
    else
    {
        if (isLeaf)
            return;
        bool ok = ((index == n) ? true : false);
        if (children[index]->n < t)
            fillChild(index);
        if (ok && index > n)
            children[index - 1]->erase(key);
        else
            children[index]->erase(key);
    }
}

void node::eraseFromLeaf(int index)
{
    for (int i = index + 1; i < n; ++i)
        keys[i - 1] = keys[i];
    n--;
}

void node::eraseFromNonLeaf(int index)
{

    int key = keys[index];
    if (children[index]->n >= t)
    {
        int prev = getPrev(index);
        keys[index] = prev;
        children[index]->erase(prev);
    }
    else if (children[index + 1]->n >= t)
    {
        int next = getNext(index);
        keys[index] = next;
        children[index + 1]->erase(next);
    }
    else
    {
        mergeChildren(index);
        children[index]->erase(key);
    }
}

int node::getPrev(int index)
{
    node *current = children[index];
    while (!current->isLeaf)
        current = current->children[current->n];
    return current->keys[current->n - 1];
}

int node::getNext(int index)
{
    node *current = children[index + 1];
    while (!current->isLeaf)
        current = current->children[0];
    return current->keys[0];
}

void node::fillChild(int index)
{
    if (index != 0 && children[index - 1]->n >= t)
        borrowFromPrev(index);
    else if (index != n && children[index + 1]->n >= t)
        borrowFromNext(index);
    else if (index != n)
        mergeChildren(index);
    else
        mergeChildren(index - 1);
}

void node::borrowFromPrev(int index)
{
    node *child = children[index];
    node *prevChild = children[index - 1];

    for (int i = child->n - 1; i >= 0; --i)
        child->keys[i + 1] = child->keys[i];

    if (!child->isLeaf)
        for (int i = child->n; i >= 0; --i)
            child->children[i + 1] = child->children[i];

    child->keys[0] = keys[index - 1];

    if (!child->isLeaf)
        child->children[0] = prevChild->children[prevChild->n];
    keys[index - 1] = prevChild->keys[prevChild->n - 1];
    child->n++;
    prevChild->n--;
}

void node::borrowFromNext(int index)
{
    node *child = children[index];
    node *nextChild = children[index + 1];
    child->keys[(child->n)] = keys[index];

    if (!(child->isLeaf))
        child->children[(child->n) + 1] = nextChild->children[0];
    keys[index] = nextChild->keys[0];

    for (int i = 1; i < nextChild->n; ++i)
        nextChild->keys[i - 1] = nextChild->keys[i];

    if (!nextChild->isLeaf)
        for (int i = 1; i <= nextChild->n; ++i)
            nextChild->children[i - 1] = nextChild->children[i];

    child->n++;
    nextChild->n--;
}

void node::mergeChildren(int index)
{
    node *child = children[index];
    node *nextChild = children[index + 1];

    child->keys[t - 1] = keys[index];
    for (int i = 0; i < nextChild->n; ++i)
        child->keys[i + t] = nextChild->keys[i];

    if (!child->isLeaf)
    {
        for (int i = 0; i <= nextChild->n; ++i)
            child->children[i + t] = nextChild->children[i];
    }

    for (int i = index + 1; i < n; ++i)
        keys[i - 1] = keys[i];

    for (int i = index + 2; i <= n; ++i)
        children[i - 1] = children[i];

    child->n += nextChild->n + 1;
    n--;
    delete (nextChild);
}

void BTree::insert(int key)
{
    if (root == NULL)
    {
        root = new node(t, true);
        root->keys[0] = key;
        root->n = 1;
    }
    else if (root->n == 2 * t - 1)
    {
        node *newRoot = new node(t, false);
        newRoot->children[0] = root;
        newRoot->splitFullChild(0, root);
        int i = 0;
        if (newRoot->keys[0] < key)
            i++;
        newRoot->children[i]->insertIntoChild(key);
        root = newRoot;
    }
    else
        root->insertIntoChild(key);
}

void node::insertIntoChild(int key)
{
    int i = n - 1;
    if (isLeaf == true)
    {
        while (i >= 0 && keys[i] > key)
        {
            keys[i + 1] = keys[i];
            i--;
        }
        keys[i + 1] = key;
        n = n + 1;
    }
    else
    {
        while (i >= 0 && keys[i] > key)
            i--;

        if (children[i + 1]->n == 2 * t - 1)
        {
            splitFullChild(i + 1, children[i + 1]);
            if (keys[i + 1] < key)
                i++;
        }
        children[i + 1]->insertIntoChild(key);
    }
}

void node::splitFullChild(int i, node *Node)
{
    node *newNode = new node(Node->t, Node->isLeaf);
    newNode->n = t - 1;

    for (int j = 0; j < t - 1; j++)
        newNode->keys[j] = Node->keys[j + t];

    if (Node->isLeaf == false)
        for (int j = 0; j < t; j++)
            newNode->children[j] = Node->children[j + t];

    Node->n = t - 1;
    for (int j = n; j >= i + 1; j--)
        children[j + 1] = children[j];

    children[i + 1] = newNode;
    for (int j = n - 1; j >= i; j--)
        keys[j + 1] = keys[j];

    keys[i] = Node->keys[t - 1];
    n++;
}

void node::print()
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (isLeaf == false)
            children[i]->print();
        cout << keys[i] << ' ';
    }
    if (!isLeaf)
        children[i]->print();
}

void node::printInterval()
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (isLeaf == false)
            children[i]->printInterval();
        if (keys[i] >= a && keys[i] <= b)
            out << keys[i] << ' ';
    }
    if (!isLeaf)
        children[i]->printInterval();
}

void BTree::erase(int key)
{
    if (!root)
        return;
    root->erase(key);

    if (root->n == 0)
    {
        node *tmp = root;
        if (root->isLeaf)
            root = NULL;
        else
            root = root->children[0];
        delete tmp;
    }
}

int main()
{
    BTree t(3);
    in >> q;
    while (q)
    {
        in >> op;
        if (op == 1)
        {
            // inserare
            in >> x;
            t.insert(x);
        }
        if (op == 2)
        {
            // stergere
            in >> x;
            t.erase(x);
        }
        if (op == 3)
        {
            // 1 sau 0 daca nr exista
            in >> x;
            if (t.search(x))
                out << 1 << '\n';
            else
                out << 0 << '\n';
        }
        if (op == 4)
        {
            // cel mai mare nr <= x
            in >> x;
            out << t.prevBiggest(x) << '\n';
        }
        if (op == 5)
        {
            // cel mai mic nr >= x
            in >> x;
            out << t.nextSmallest(x) << '\n';
        }
        if (op == 6)
        {
            // interval a b sortat
            in >> a >> b;
            t.printInterval();
            out << '\n';
        }
        q--;
    }
    return 0;
}