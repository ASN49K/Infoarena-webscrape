#include <fstream>
#include <set>
using namespace std;

ifstream cin("abce.in");
ofstream cout("abce.out");

set<int> s;

int main()
{
    int q;
    cin>>q;
    while(q--) 
    {
        int op;
        cin >> op;
        if(op == 1) 
        {
            int x;
            cin >> x;
            s.insert(x);
        }
        if(op == 2)
        {
            int x;
            cin >> x;
            s.erase(x);
        }
        if(op == 3)
        {
            int x;
            cin >> x;
            if(s.find(x) != s.end()) cout << 1 << '\n';
            else cout << 0 << '\n';
        }
        if(op == 4)
        {
            int x;
            cin >> x;
            auto it = s.upper_bound(x);
            it--;
            cout << *it << '\n';
        }
        if(op == 5)
        {
            int x;
            cin>> x;
            auto it = s.lower_bound(x);
            cout << *it << '\n';
        }
        if(op == 6)
        {
            int x, y;
            cin >> x >> y;
            auto it = s.lower_bound(x);
            while(it != s.end()) 
            {
                if(*it > y) break;
                cout << *it << ' ';
                it++;
            }
            cout << '\n';
        }
    }
}
