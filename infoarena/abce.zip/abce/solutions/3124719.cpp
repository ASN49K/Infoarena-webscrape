#include <iostream>
#include <fstream>

using namespace std;

/// Arbore binar de cautare echilibrat (de continuat candva).
/// NU AM ROTATII SI INTRA IN TIMP

class ABCE;

class Nod
{
public:

    int valoare;
    int frecventa;

private:

    static const int NR_FII = 2;

    Nod* tata;
    int pozInTata;
    Nod* fii[Nod::NR_FII];
    int inaltimeSubArbore;
    int dimensiuneSubArbore;
    int sumaFrecventeSubArbore;

    bool esteRadacina;

    Nod() : valoare(0), frecventa(0), tata(nullptr), pozInTata(-1), inaltimeSubArbore(0), dimensiuneSubArbore(0), sumaFrecventeSubArbore(0), esteRadacina(false)
    {
        for (int i = 0; i < Nod::NR_FII; ++i)
            this->fii[i] = nullptr;
    }

    friend class ABCE;
};

class ABCE
{
private:

    static const int INFINIT = 1e9;

    Nod* radacina;

    void stergeSubArbore(Nod*& nod);
    /// void stergeNodFrunza(Nod*& nod);

    void insereaza(int x, Nod*& nod);
    void sterge(int x, Nod*& nod, bool stergereCompleta = false);
    void afiseazaCrescator(ostream& out, Nod*& nod) const;
    void afiseazaDescrescator(ostream& out, Nod*& nod) const;
    void recalculeazaParametriiSubArbore(Nod*& nod);
    Nod* cauta(Nod*& nod, int x, int st, int dr) const;
    void recalculeazaParametriiPeLant(Nod*& inceput, Nod*& sfarsit);
    Nod* maximSubSauEgalCu(Nod*& nod, int x) const;
    Nod* minimPesteSauEgalCu(Nod*& nod, int x) const;

public:

    ABCE()
    {
        this->radacina = new Nod();
        this->radacina->esteRadacina = true;
    }

    void insereaza(int x);
    void sterge(int x, bool stergereCompleta = false);
    void afiseazaCrescator(ostream& out) const;
    void afiseazaDescrescator(ostream& out)const;
    Nod* cauta(int x) const;
    Nod* maximSubSauEgalCu(int x) const;
    Nod* minimPesteSauEgalCu(int x) const;

    Nod* succesorDistinct(Nod*& nod) const;
    Nod* predecesorDistinct(Nod*& nod) const;

    inline int dimensiune()
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->dimensiuneSubArbore;
        return 0;
    }

    inline int numarElemente()
    {
        if (this->radacina->fii[1] != nullptr)
            return this->radacina->fii[1]->sumaFrecventeSubArbore;
        return 0;
    }

    ~ABCE()
    {
        this->stergeSubArbore(this->radacina);
    }
};

Nod* ABCE::maximSubSauEgalCu(Nod*& nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->maximSubSauEgalCu(nod->fii[0], x);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
        {
            Nod* nodDreapta = this->maximSubSauEgalCu(nod->fii[1], x);

            if (nodDreapta == nullptr)
                return nod;
            else
                return nodDreapta;
        }
        else
            return nod;
    }
}

Nod* ABCE::minimPesteSauEgalCu(Nod*& nod, int x) const
{
    if (nod->valoare == x)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
        {
            Nod* nodStanga = this->minimPesteSauEgalCu(nod->fii[0], x);

            if (nodStanga == nullptr)
                return nod;
            else
                return nodStanga;
        }
        else
            return nod;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->minimPesteSauEgalCu(nod->fii[1], x);
        else
            return nullptr;
    }
}

Nod* ABCE::maximSubSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->maximSubSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

Nod* ABCE::minimPesteSauEgalCu(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->minimPesteSauEgalCu(this->radacina->fii[1], x);
    return nullptr;
}

/*
void ABCE::stergeNodFrunza(Nod*& nod) /// Functia presupune ca nodul ce urmeaza a fi sters e frunza.
{
    if (nod->esteRadacina)
        return;

    nod->tata->fii[nod->pozInTata] = nullptr;

    /// this->recalculeazaParametriiSubArbore(nod->tata); /// NU

    delete nod;
}
*/

void ABCE::recalculeazaParametriiPeLant(Nod*& inceput, Nod*& sfarsit)
{
    if (inceput == nullptr || sfarsit == nullptr)
        return;

    if (inceput->esteRadacina || sfarsit->esteRadacina)
        return;

    Nod* nod = inceput;

    while (nod != sfarsit)
    {
        this->recalculeazaParametriiSubArbore(nod);
        nod = nod->tata;
    }

    this->recalculeazaParametriiSubArbore(nod);
}

void ABCE::stergeSubArbore(Nod*& nod)
{
    for (int i = 0; i < Nod::NR_FII; ++i)
    {
        if (nod->fii[i] != nullptr)
        {
            stergeSubArbore(nod->fii[i]);
            nod->fii[i] = nullptr;
        }
    }

    if (!nod->esteRadacina)
    {
        if (nod->tata != nullptr)
            nod->tata->fii[nod->pozInTata] = nullptr;

        delete nod;
    }
}

Nod* ABCE::succesorDistinct(Nod*& nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas dreapta, apoi maxima stanga
    if (solutie->fii[1] != nullptr)
    {
        solutie = solutie->fii[1];

        while (solutie->fii[0] != nullptr)
            solutie = solutie->fii[0];
    }
    else /// altfel urcam cat timp venim din fiul drept si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 1 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 0 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::predecesorDistinct(Nod*& nod) const
{
    if (nod->esteRadacina)
        return nullptr;

    Nod* solutie = nod;

    /// un pas stanga, apoi maxima dreapta
    if (solutie->fii[0] != nullptr)
    {
        solutie = solutie->fii[0];

        while (solutie->fii[1] != nullptr)
            solutie = solutie->fii[1];
    }
    else /// altfel urcam cat timp venim din fiul stang si cat timp nu dam in radacina
    {
        while (solutie->pozInTata == 0 && !solutie->tata->esteRadacina)
            solutie = solutie->tata;

        if (solutie->pozInTata == 1 && !solutie->tata->esteRadacina) /// pozInTata pentru nodul fictiv radacina este -1
            solutie = solutie->tata;
        else
            solutie = nullptr;
    }

    return solutie;
}

Nod* ABCE::cauta(Nod*& nod, int x, int st, int dr) const
{
    if (x < st || dr < x)
        return nullptr;

    if (nod->valoare == x && nod->frecventa > 0)
        return nod;

    if (x < nod->valoare)
    {
        if (nod->fii[0] != nullptr)
            return this->cauta(nod->fii[0], x, st, nod->valoare - 1);
        else
            return nullptr;
    }
    else
    {
        if (nod->fii[1] != nullptr)
            return this->cauta(nod->fii[1], x, nod->valoare + 1, dr);
        else
            return nullptr;
    }
}

Nod* ABCE::cauta(int x) const
{
    if (this->radacina->fii[1] != nullptr)
        return this->cauta(this->radacina->fii[1], x, -ABCE::INFINIT, +ABCE::INFINIT);
    return nullptr;
}

void ABCE::recalculeazaParametriiSubArbore(Nod*& nod)
{
        nod->inaltimeSubArbore = 1;
        if (nod->fii[0] != nullptr)
            nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[0]->inaltimeSubArbore + 1);
        if (nod->fii[1] != nullptr)
            nod->inaltimeSubArbore = max(nod->inaltimeSubArbore, nod->fii[1]->inaltimeSubArbore + 1);

        nod->dimensiuneSubArbore = 1;
        if (nod->fii[0] != nullptr)
            nod->dimensiuneSubArbore += nod->fii[0]->dimensiuneSubArbore;
        if (nod->fii[1] != nullptr)
            nod->dimensiuneSubArbore += nod->fii[1]->dimensiuneSubArbore;

        nod->sumaFrecventeSubArbore = nod->frecventa;
        if (nod->fii[0] != nullptr)
            nod->sumaFrecventeSubArbore += nod->fii[0]->sumaFrecventeSubArbore;
        if (nod->fii[1] != nullptr)
            nod->sumaFrecventeSubArbore += nod->fii[1]->sumaFrecventeSubArbore;
}

void ABCE::insereaza(int x)
{
    if (this->radacina->fii[1] == nullptr)
    {
        this->radacina->fii[1] = new Nod();
        this->radacina->fii[1]->valoare = x;
        this->radacina->fii[1]->frecventa = 1;
        this->radacina->fii[1]->tata = this->radacina;
        this->radacina->fii[1]->pozInTata = 1;
        this->radacina->fii[1]->inaltimeSubArbore = 1;
        this->radacina->fii[1]->dimensiuneSubArbore = 1;
        this->radacina->fii[1]->sumaFrecventeSubArbore = 1;
    }
    else
        this->insereaza(x, this->radacina->fii[1]);
}

void ABCE::insereaza(int x, Nod*& nod)
{
    if (nod->valoare == x)
    {
        ++nod->frecventa;
        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] == nullptr)
        {
            nod->fii[1] = new Nod();
            nod->fii[1]->valoare = x;
            nod->fii[1]->frecventa = 1;
            nod->fii[1]->tata = nod;
            nod->fii[1]->pozInTata = 1;
            nod->fii[1]->inaltimeSubArbore = 1;
            nod->fii[1]->dimensiuneSubArbore = 1;
            nod->fii[1]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[1]);

            this->recalculeazaParametriiSubArbore(nod);
        }
    }
    else
    {
        if (nod->fii[0] == nullptr)
        {
            nod->fii[0] = new Nod();
            nod->fii[0]->valoare = x;
            nod->fii[0]->frecventa = 1;
            nod->fii[0]->tata = nod;
            nod->fii[0]->pozInTata = 0;
            nod->fii[0]->inaltimeSubArbore = 1;
            nod->fii[0]->dimensiuneSubArbore = 1;
            nod->fii[1]->sumaFrecventeSubArbore = 1;

            this->recalculeazaParametriiSubArbore(nod);
        }
        else
        {
            this->insereaza(x, nod->fii[0]);

            this->recalculeazaParametriiSubArbore(nod);
        }
    }
}

void ABCE::sterge(int x, bool stergereCompleta)
{
    if (this->radacina->fii[1] != nullptr)
        this->sterge(x, this->radacina->fii[1], stergereCompleta);
}

void ABCE::sterge(int x, Nod*& nod, bool stergereCompleta)
{
    if (nod->valoare == x)
    {
        if (stergereCompleta)
        {
            nod->frecventa = 0;
            nod->sumaFrecventeSubArbore = 0;
        }
        else
        {
            --nod->frecventa;
            --nod->sumaFrecventeSubArbore;
        }

        if (nod->frecventa == 0) /// Presupun ca nodul nu e radacina, deci poate fi sters si are sigur tata.
        {
            if (nod->fii[0] == nullptr && nod->fii[1] == nullptr)
            {
                nod->tata->fii[nod->pozInTata] = nullptr;

                delete nod;
            }
            else if (nod->fii[0] != nullptr && nod->fii[1] == nullptr)
            {
                nod->fii[0]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[0];
                nod->fii[0]->pozInTata = nod->pozInTata;

                delete nod;
            }
            else if (nod->fii[0] == nullptr && nod->fii[1] != nullptr)
            {
                nod->fii[1]->tata = nod->tata;
                nod->tata->fii[nod->pozInTata] = nod->fii[1];
                nod->fii[1]->pozInTata = nod->pozInTata;

                delete nod;
            }
            else /// Are ambii fii (in acest caz sigur are succesor).
            {
                Nod* succesor = this->succesorDistinct(nod);

                std::swap(nod->valoare, succesor->valoare);
                std::swap(nod->frecventa, succesor->frecventa);

                if (succesor->fii[0] == nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* tataSuccesor = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = nullptr;

                    delete succesor;

                    this->recalculeazaParametriiPeLant(tataSuccesor, nod);
                }
                else if (succesor->fii[0] != nullptr && succesor->fii[1] == nullptr)
                {
                    Nod* tataSuccesor = succesor->fii[0];
                    succesor->fii[0]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[0];
                    succesor->fii[0]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiPeLant(tataSuccesor, nod);
                }
                else /// succesor->fii[0] == nullptr && succesor->fii[1] != nullptr
                {
                    Nod* tataSuccesor = succesor->fii[1];
                    succesor->fii[1]->tata = succesor->tata;
                    succesor->tata->fii[succesor->pozInTata] = succesor->fii[1];
                    succesor->fii[1]->pozInTata = succesor->pozInTata;

                    delete succesor;

                    this->recalculeazaParametriiPeLant(tataSuccesor, nod);
                }
            }
        }

        return;
    }

    if (nod->valoare < x)
    {
        if (nod->fii[1] != nullptr)
        {
            this->sterge(x, nod->fii[1], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);
        }
    }
    else
    {
        if (nod->fii[0] != nullptr)
        {
            this->sterge(x, nod->fii[0], stergereCompleta);

            this->recalculeazaParametriiSubArbore(nod);
        }
    }
}

void ABCE::afiseazaCrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaCrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaCrescator(ostream& out, Nod*& nod) const
{
    if (nod->fii[0] != nullptr)
        this->afiseazaCrescator(out, nod->fii[0]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[1] != nullptr)
        this->afiseazaCrescator(out, nod->fii[1]);
}

void ABCE::afiseazaDescrescator(ostream& out) const
{
    if (this->radacina->fii[1] != nullptr)
        this->afiseazaDescrescator(out, this->radacina->fii[1]);

    out << '\n';
}

void ABCE::afiseazaDescrescator(ostream& out, Nod*& nod) const
{
    if (nod->fii[1] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[1]);

    for (int i = 0; i < nod->frecventa; ++i)
        out << nod->valoare << ' ';

    if (nod->fii[0] != nullptr)
        this->afiseazaDescrescator(out, nod->fii[0]);
}

int main()
{
    ifstream in("abce.in");
    ofstream out("abce.out");

    ios_base::sync_with_stdio(false);
    in.tie(nullptr);

    ABCE* abce = new ABCE();

    int q;
    in >> q;

    for (int j = 0; j < q; ++j)
    {
        int tip;
        in >> tip;

        if (tip == 1)
        {
            int x;
            in >> x;

            abce->insereaza(x);
        }
        else if (tip == 2)
        {
            int x;
            in >> x;

            abce->sterge(x, true);
        }
        else if (tip == 3)
        {
            int x;
            in >> x;

            if (abce->cauta(x) != nullptr)
                out << 1 << '\n';
            else
                out << 0 << '\n';
        }
        else if (tip == 4)
        {
            int x;
            in >> x;

            out << abce->maximSubSauEgalCu(x)->valoare << '\n';
        }
        else if (tip == 5)
        {
            int x;
            in >> x;

            out << abce->minimPesteSauEgalCu(x)->valoare << '\n';
        }
        else
        {
            int x, y;
            in >> x >> y;

            Nod* nodCurent = abce->minimPesteSauEgalCu(x);
            Nod* sfarsit = abce->maximSubSauEgalCu(y);

            while (nodCurent != sfarsit)
            {
                out << nodCurent->valoare << ' ';
                nodCurent = abce->succesorDistinct(nodCurent);
            }

            out << nodCurent->valoare << '\n';
        }
    }

    delete abce;

    in.close();
    out.close();

    return 0;
}
