#include <fstream>
#include <cstdlib>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
class Nod {
    Nod *fiuStang;
    Nod *fiuDrept;
    int val;
    const int priority;
public:
    int getVal() const;
    void setVal(int val);
    int getPriority() const;
    ~Nod();
    explicit Nod(const int &val);
    Nod(const Nod &) = delete;
    Nod *getFiuStang() const;
    void setFiuStang(Nod *fiuStang);
    Nod *getFiuDrept() const;
    void setFiuDrept(Nod *fiuDrept);
};
void Nod::setFiuDrept(Nod *fiuDrept) {
    Nod::fiuDrept = fiuDrept;
}
Nod *Nod::getFiuStang() const {
    return fiuStang;
}

void Nod::setFiuStang(Nod *fiuStang) {
    Nod::fiuStang = fiuStang;
}

Nod *Nod::getFiuDrept() const {
    return fiuDrept;
}
Nod::~Nod() {}
Nod::Nod(const int &val) : val(val), priority(rand()) {
    fiuDrept = fiuStang = nullptr;
}
int Nod::getVal() const {
    return val;
}

void Nod::setVal(int val) {
    Nod::val = val;
}
int Nod::getPriority() const {
    return priority;
}

class Treap {
    Nod *radacina;
    void balance(Nod *nodBunic, Nod *nodTata) {
        if (nodTata->getFiuStang() != nullptr && nodTata->getFiuStang()->getPriority() > nodTata->getPriority())
            rotDreapta(nodBunic, nodTata, nodTata->getFiuStang());
        else if (nodTata->getFiuDrept() != nullptr && nodTata->getFiuDrept()->getPriority() > nodTata->getPriority())
            rotStanga(nodBunic, nodTata, nodTata->getFiuDrept());
    }
    void inserare(Nod *nodDeInserat, Nod *nodTata, Nod *nodBunic) {
        if (nodDeInserat->getVal() == nodTata->getVal())//daca am duplicat, nu il mai inserez
            return;
        else if (nodDeInserat->getVal() < nodTata->getVal()) {///daca nodul meu e mai mic, il inseram in stanga
            if (nodTata->getFiuStang() != nullptr)///daca mai copii, cobor
                inserare(nodDeInserat, nodTata->getFiuStang(), nodTata);
            else//altfel, il leg
                nodTata->setFiuStang(nodDeInserat);
        } else {///altfel il inseram in dreapta
            if (nodTata->getFiuDrept() != nullptr)///daca mai am copiii cobor
                inserare(nodDeInserat, nodTata->getFiuDrept(), nodTata);
            else//altfel il leg
                nodTata->setFiuDrept(nodDeInserat);
        }//rebalansez in fct de prioritati ca sa respecte proprietatea de heap
        balance(nodBunic, nodTata);
    }
    Nod *cautare(const int nrCautat, Nod *nodCurent) {///parcurgere SRD (inordine)
        if (nodCurent == nullptr || nodCurent->getVal() == nrCautat)
            return nodCurent;
        else if (nrCautat < nodCurent->getVal())
            return cautare(nrCautat, nodCurent->getFiuStang());
        else
            return cautare(nrCautat, nodCurent->getFiuDrept());
    }
    void rotDreapta(Nod *nodBunic, Nod *nodTata, Nod *nodCurent) {
        if (nodTata == radacina)
            radacina = nodCurent;
        else if (nodBunic != nullptr) {
            if (nodBunic->getFiuStang() == nodTata)
                nodBunic->setFiuStang(nodCurent);
            else
                nodBunic->setFiuDrept(nodCurent);
        }
        nodTata->setFiuStang(nodCurent->getFiuDrept());
        nodCurent->setFiuDrept(nodTata);
    }
    void rotStanga(Nod *nodBunic, Nod *nodTata, Nod *nodCurent) {
        if (nodTata == radacina)
            radacina = nodCurent;
        else if (nodBunic != nullptr) {
            if (nodBunic->getFiuStang() == nodTata)
                nodBunic->setFiuStang(nodCurent);
            else
                nodBunic->setFiuDrept(nodCurent);
        }
        nodTata->setFiuDrept(nodCurent->getFiuStang());
        nodCurent->setFiuStang(nodTata);
    }
    void sRD(std::ofstream &fout, const int st, const int dr, Nod *nodCurent) {
        if (nodCurent != nullptr) {
            sRD(fout, st, dr, nodCurent->getFiuStang());
            if (nodCurent->getVal() >= st && nodCurent->getVal() <= dr)
                fout << nodCurent->getVal() << ' ';
            sRD(fout, st, dr, nodCurent->getFiuDrept());
        }
    }
public:
    Treap() {
        radacina = nullptr;
    }
    void inserare(const int &val) {
        Nod *nodNou = new Nod(val);
        if (radacina == nullptr)
            radacina = nodNou;
        else
            inserare(nodNou, radacina, nullptr);
    }

    int cautare(const int nrCautat) {
        Nod *nod = cautare(nrCautat, radacina);
        if (nod == nullptr)
            return 0;
        else
            return 1;
    }

    void stergere(const int val) {
        Nod *nodCurent = radacina;
        ///gasim nodul si tatal lui
        Nod *nodTata = nullptr;
        while (nodCurent != nullptr && nodCurent->getVal() != val) {
            nodTata = nodCurent;
            if (val < nodCurent->getVal())
                nodCurent = nodCurent->getFiuStang();
            else
                nodCurent = nodCurent->getFiuDrept();
        }
        if (nodCurent != nullptr) {
            ///cazul 1-nu are niciun fiu
            if (nodCurent->getFiuStang() == nullptr && nodCurent->getFiuDrept() == nullptr) {
                if (nodCurent == radacina)
                    radacina = nullptr;
                else if (nodTata->getFiuStang() == nodCurent)
                    nodTata->setFiuStang(nullptr);
                else
                    nodTata->setFiuDrept(nullptr);
            } else if (nodCurent->getFiuStang() != nullptr && nodCurent->getFiuDrept() == nullptr) {
                ///cazul 2A - doar fiu stang
                if (nodCurent == radacina)
                    radacina = nodCurent->getFiuStang();
                else if (nodTata->getFiuStang() == nodCurent)
                    nodTata->setFiuStang(nodCurent->getFiuStang());
                else
                    nodTata->setFiuDrept(nodCurent->getFiuStang());
            } else if (nodCurent->getFiuStang() == nullptr && nodCurent->getFiuDrept() != nullptr) {
                ///cazul 2B - doar fiu drept
                if (nodCurent == radacina)
                    radacina = nodCurent->getFiuDrept();
                else if (nodTata->getFiuStang() == nodCurent)
                    nodTata->setFiuStang(nodCurent->getFiuDrept());
                else
                    nodTata->setFiuDrept(nodCurent->getFiuDrept());
            } else if (nodCurent->getFiuStang() != nullptr && nodCurent->getFiuDrept() != nullptr) {
                ///cazul 3 - are ambii fii
                Nod *nodAux = nodCurent->getFiuDrept();
                Nod *tataNodAux = nodCurent;
                while (nodAux->getFiuStang() != nullptr) {  ///iau succesorul
                    tataNodAux = nodAux;
                    nodAux = nodAux->getFiuStang();
                }
                nodCurent->setVal(nodAux->getVal());///mut succesorul pe pozitia nodului pe care il sterg,
                /// pastrand insa prioritatea nodului sters
                if (tataNodAux != nodCurent)
                    tataNodAux->setFiuStang(nodAux->getFiuDrept());//refac legatura
                else
                    tataNodAux->setFiuDrept(nodAux->getFiuDrept());
                nodCurent = nodAux;//marchez nodul in care se afla succesorul pentru stergere
            }
            delete nodCurent;
        }
    }

    int predecesor(const int val) {
        Nod *nodAux = radacina;
        int maxi = -2000000000;
        while (nodAux != nullptr) {
            if (nodAux->getVal() > maxi && nodAux->getVal() <= val)
                maxi = nodAux->getVal();
            if (nodAux->getVal() > val)
                nodAux = nodAux->getFiuStang();
            else if (nodAux->getVal() == val)
                break;
            else {
                if (nodAux->getFiuDrept() != nullptr && nodAux->getFiuDrept()->getVal() <= val)
                    nodAux = nodAux->getFiuDrept();
                else
                    nodAux = nodAux->getFiuStang();
            }
        }
        return maxi;
    }

    int succesor(const int val) {
        Nod *nodAux = radacina;
        int mini = 2000000000;
        while (nodAux != nullptr) {
            if (nodAux->getVal() < mini && nodAux->getVal() >= val)
                mini = nodAux->getVal();
            if (nodAux->getVal() < val)
                nodAux = nodAux->getFiuDrept();
            else if (nodAux->getVal() == val)
                break;
            else {
                if (nodAux->getFiuStang() != nullptr && nodAux->getFiuStang()->getVal() >= val)
                    nodAux = nodAux->getFiuStang();
                else
                    nodAux = nodAux->getFiuDrept();
            }
        }
        return mini;
    }

    void sRD(std::ofstream &fout, const int st, const int dr) {
        sRD(fout, st, dr, radacina);
    }
    void clearTreap(Nod *nod) {
        if (nod != nullptr) {
            clearTreap(nod->getFiuStang());
            clearTreap(nod->getFiuDrept());
            delete nod;
        }
    }
    ~Treap() {
        clearTreap(radacina);
    }
};

int main() {
    srand(time(NULL));
    Treap t;
    int n;
    fin >> n;
    for (int i = 0; i < n; i++) {
        int a, b;
        fin >> a >> b;
        if (a == 1) {
            t.inserare(b);
        } else if (a == 2) {
            t.stergere(b);
        } else if (a == 3) {
            fout << t.cautare(b) << '\n';
        } else if (a == 4) {
            fout << t.predecesor(b) << '\n';
        } else if (a == 5) {
            fout << t.succesor(b) << '\n';
        } else if (a == 6) {
            int c;
            fin >> c;
            t.sRD(fout, b, c);
            fout << '\n';
        }
    }
    return 0;
}