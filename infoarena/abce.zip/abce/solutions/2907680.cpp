T_george_T
George Teodorescu
• T_george_T
logout | contul meu
infoarena informatica de performanta
infoarena
blog
forum
calendar
profilul meu
mesaje
Home
Arhiva de probleme
Arhiva educatională
Arhiva monthly
Arhiva ACM
Concursuri
Concursuri virtuale
Clasament
Articole
Downloads
Links
Documentaţie
Despre infoarena
Monitorul de evaluare
Trimite soluţii
Contul meu
! Cautare

In curand...
150406 membri inregistrati

09:03:57
Fii un bun infoarenaut! Implică-te!

Pagini recente » abce | infoarena - comunitate informatica, concursuri de programare | Monitorul de evaluare | Borderou de evaluare (job #2906157) | Cod sursa (job #2906157)

Cod sursa(job #2906157)
Utilizator	T_george_TGeorge Teodorescu T_george_T	Data	24 mai 2022 23:55:08
Problema	Arbori binari de cautare echilibrati	Scor	50
Compilator	cpp-64	Status	done
Runda	arhiva-test	Marime	5.09 kb
Raporteaza aceasta sursa

#include <iostream>
#include <random>
#include <algorithm>
#include <time.h>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");
const int maxh=11;

string output;
struct node {
    int val;
    node* above[maxh+1];
public:
    node(int maxh, int val) {
        for (int i = 0; i <= maxh; i++)
            above[i] = nullptr;
        this->val = val;
    }

    node(const node& node1) {
        for (int i = 0; i <= maxh; i++)
            above[i] = node1.above[i];
        val = node1.val;
    }

    node operator=(const node& node1) {
        if (&node1 == this)
            return *this;
        for (int i = 0; i <= maxh; i++)
            above[i] = node1.above[i];
        val = node1.val;
    }

    void modifyAbove(int poz, node* nod);

    ~node() {

    }
};

void node::modifyAbove(int poz, node* nod) {
    above[poz] = nod;
}


class skip_list {
    node* begin;

    int generateLevel();

public:
    skip_list(int n = -2e9) {
        begin = new node(maxh, n);
    }


    void insert(int);

    bool search(int);

    void afisare() {
        for (int h = maxh; h >= 0; h--) {
            cout << h << ": ";
            for (node* p = begin->above[h]; p != nullptr; p = p->above[h])
                cout << p->val << " ";
            cout << '\n';
        }
    }

    void erase(int);

    int lower_bound(int);

    int upper_bound(int);

    void interval(int, int);
};



void skip_list::interval(int x, int y) {
    node* current = begin;
    for (int h = maxh; h >= 0; h--) {
        if (current->above[h] == nullptr)
            continue;
        while (current->above[h] != nullptr && current->above[h]->val < x)
            current = current->above[h];

    }
    current = current->above[0];
    while (current != nullptr && current->val <= y) {
        output.append(to_string(current->val)+" ");
        current = current->above[0];
    }
}

int skip_list::lower_bound(int val) {
    node* current = begin;
    for (int h = maxh; h >= 0; h--) {
        if (current->above[h] == nullptr)
            continue;
        while (current->above[h] != nullptr && current->above[h]->val <= val)
            current = current->above[h];

    }
    return current->val;
}

int skip_list::upper_bound(int val) {
    node* current = begin;
    for (int h = maxh; h >= 0; h--) {
        if (current->above[h] == nullptr)
            continue;
        while (current->above[h] != nullptr && current->above[h]->val < val)
            current = current->above[h];

    }
    return current->above[0]->val;
}

bool skip_list::search(int val) {
    node* current = begin;
    for (int h = maxh; h >= 0; --h) {
        if (current->above[h] == nullptr)
            continue;
        while (current->above[h] != nullptr && current->above[h]->val <= val)
            current = current->above[h];
        if (current != nullptr && current->val == val)
            return 1;
    }
    return 0;
}

void skip_list::erase(int val) {
    if (begin->val == val) {
        for (int h = maxh; h >= 0; --h) {
            if (begin->above[0]->above[h] == nullptr)
                begin->above[0]->above[h] = begin->above[h];
        }
        node* aux = begin;
        begin = begin->above[0];
        delete aux;
        return;
    }

    node* current = begin, * ans=nullptr;
    for (int h = maxh; h >= 0; --h) {
        if (current->above[h] == nullptr)
            continue;
        while (current->above[h] != nullptr && current->above[h]->val < val)
            current = current->above[h];
        if (current->above[h] != nullptr && current->above[h]->val == val) {
            ans = current->above[h];
            current->above[h] = current->above[h]->above[h];
        }
    }
    if(ans!=nullptr)
        delete ans;

}


int skip_list::generateLevel() {
    int lvl = 0;
    unsigned int val = rand()&1;
    while (lvl < maxh && val ==0) {
        val = rand()&1;
        lvl++;
    }
    return lvl;
}

void skip_list::insert(int val) {
    int nlevel = generateLevel();
    node* current = begin;
    node* nod = new node(nlevel, val);
    for (int h = nlevel; h >= 0; --h) {
        if (current->above[h] == nullptr) {
            current->above[h] = nod;
            continue;
        }
        while (current->above[h] != nullptr && current->above[h]->val <= val)
            current = current->above[h];
        nod->above[h] = current->above[h];
        current->above[h] = nod;
    }
    return;
}


int main() {
    srand(time(nullptr));
    skip_list l;
    int n, tip, a, b;
    in >> n;
    for (int i = 0; i < n; ++i) {
        in >> tip >> a;
        if (tip == 1) {
            l.insert(a);
        }
        else if (tip == 2) {
            l.erase(a);
        }
        else if (tip == 3) {
            output.append(to_string(l.search(a))+"\n");
        }
        else if (tip == 4) {
            output.append(to_string(l.lower_bound(a))+"\n");
        }
        else if (tip == 5) {
            output.append(to_string(l.upper_bound(a))+"\n");
        }
        else {
            in >> b;
            l.interval(a, b);
            output.append("\n");
        }
    }
    out<<output;
    return 0;
}
© 2004-2022 Asociatia infoarenaPrima paginaDespre infoarenaTermeni si conditiiContactSari la inceputul paginii ↑
Creative Commons LicenseCu exceptia cazurilor in care se specifica altfel, continutul site-ului infoarena
este publicat sub licenta Creative Commons Attribution-NonCommercial 2.5.
