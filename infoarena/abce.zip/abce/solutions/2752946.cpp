#include <bits/stdc++.h>

using namespace std;

/// documentatie :https://www.geeksforgeeks.org/avl-tree-set-1-insertion/


ifstream fin("abce.in");
ofstream fout("abce.out");

struct nod  // struct de noduri
{
    int val;
    nod * st;
    nod *dr;
    int h;
};


nod * root = NULL;
/*
int maxx(int x, int y)
{
    if(x>y)
        return x;
    return y;
}
*/
int inaltime(nod * n)
{
    if(n == NULL)
        return 0;
    return n->h;
}
/*
nod * newnod(int valoare)
{
    nod* n = new nod();
    n-> val =  valoare;
    n-> st = NULL;
    n-> dr = NULL;
    n-> h = 1;

    return n;
}
*/


nod* rRotate(nod* n)
{
    nod *x = n->st;
    nod *copil2x = x->dr;

    x->dr = n;
    n->st = copil2x;

    n->h = max(inaltime(n->st),inaltime(n->dr)) + 1;

    x->h = max(inaltime(x->st), inaltime(x->dr)) + 1;


    return x;
}

nod* lRotate(nod* n)
{
    nod *y = n->dr;
    nod *copil1y = y->st;

    y->st = n;
    n->dr = copil1y;

    n->h = max(inaltime(n->st),inaltime(n->dr)) + 1;

    y->h = max(inaltime(y->st),inaltime(y->dr)) + 1;


    return y;
}

int difNivel(nod *n)
{
    if(n == NULL)
        return 0;
    else
        return inaltime(n->st) - inaltime(n->dr);
}


nod * insrt(nod * n, int valoare)
{
    /// inserarea elementelor in arbore ca si frunze
    if(n == NULL)
    {
        //return (newnod(valoare));
        nod * n = new nod();
        n->val = valoare;
        n->st = NULL;
        n->dr = NULL;
        n->h = 1;
        return n;
    }
    else
    {


    if (valoare < n->val)
    {
        n-> st = insrt(n->st,valoare);
    }
    else if(valoare > n->val)
    {
        n->dr = insrt(n->dr,valoare);
    }
    else //if (valoare == n->val)
        return n;

    /// update la h
    n->h = max(inaltime(n->st), inaltime(n->dr)) +1;

    /// calc dif dintre copiii unui nod
    int dif = difNivel(n);

    /// in cazul in care dupa inserare arborele in mai e avl
    ///(dif dintre h a 2copii ai unui nod >1 || <-1)

    /// caz 1: left left
    if(dif > 1 && valoare < n->st->val)
    {
        return rRotate(n);
    }

     ///  caz 2: right right
    else if(dif < -1 && valoare > n->dr->val)
    {
        return lRotate(n);
    }

    /// caz 3: left right
    else if(dif > 1 && valoare > n->st->val)
    {
        n -> st = lRotate(n ->st);
        return rRotate(n);
    }

    /// caz 4: r l
    else if(dif < -1 && valoare < n->dr->val)
    {
        n -> dr = rRotate(n ->dr);
        return lRotate(n);
    }

    /// returnezi nodul pe care te afli daca in adaugarea unui
    /// nod nou avl-ul nu a fost stricat
    return n;
    }
}


nod * findMin (nod *n)///returneaza nodul in care se afla val min
{
    nod * aux = n;
    while(aux->st !=NULL)
        aux = aux->st;
    return aux;
}

/*nod * findMax (nod * n)
{
    nod * aux = n;
    while(aux->dr !=NULL)
        aux = aux-> dr;
    return aux;
}*/

nod* dlete(nod* n, int valoare)
{
    if(n == NULL)    // cazul in care nodul e nul
        return n;

    if(valoare < n->val)
        n->st = dlete(n->st, valoare);
    else if(valoare > n->val)
        n->dr = dlete(n->dr, valoare);
    else  /// cand gasesc nodul pe care in sterg
    {
        if((n->dr == NULL) || (n->st == NULL))/// nod are cel mult un copil
        {
            nod * temp;
            if(n->dr == NULL && n->st == NULL)
            {
                temp = n;
                n = NULL;
            }
            else
            {
                if(n->dr == NULL && n->st != NULL)
                {
                    temp = n->st;
                    //n =  n->st;
                    *n = *temp;
                }
                else if(n->dr != NULL && n->st == NULL)
                {
                    temp = n->dr;
                    //n = n->dr;
                    *n = *temp;
                }
            }
            free(temp);
            /* nod *temp = n->st ?
                         n->st :
                         n->dr;

            // No child case
            if (temp == NULL)
            {
                temp = n;
                n = NULL;
            }
            else // One child case
            *n = *temp; // Copy the contents of
                           // the non-empty child
            free(temp); */

        }
        else /// nod cu 2 copii
        {
            nod* temp = findMin(n->dr);

            n->val = temp->val;

            n ->dr = dlete(n->dr, temp ->val);
        }
    }

    if(n == NULL) // daca arborele avea doar 1 nod
        return n;

    n->h = 1+ max(inaltime(n->st),inaltime(n->dr));

    int dif = difNivel(n);

     /// caz 1: left left
    if(dif > 1 && difNivel(n->st) >= 0)
    {
        return rRotate(n);
    }

     ///  caz 2: right right
    if(dif < -1 && difNivel(n->dr) <= 0)
    {
        return lRotate(n);
    }

    /// caz 3: left right
    if(dif > 1 && difNivel(n->st) < 0)
    {
        n -> st = lRotate(n ->st);
        return rRotate(n);
    }

    /// caz 4: r l
    if(dif < -1 && difNivel(n->dr) > 0)
    {
        n -> dr = rRotate(n ->dr);
        return lRotate(n);
    }


    return n;
}


void preorder(nod* n)
{
    if(n != NULL)
    {
        cout<< n->val<<" ";
        preorder(n->st);
        preorder(n->dr);
    }
}

void inorder (nod * n)
{
    if(n != NULL)
    {
        inorder(n->st);
        cout<< n->val<<" ";
        inorder(n->dr);
    }
}


int cautare (nod *n, int valoare)
{
    if(n == NULL)
    {
        return 0;
    }
    if(n->val == valoare)
        return 1;
    if(n->val > valoare)
        return cautare(n->st,valoare);
    if(n->val < valoare)
        return cautare(n->dr,valoare);
}


void pred(int val)
{
        nod *aux =root;
        int maxim =-1000000000;
        while (aux!=NULL)
        {
            if (aux->val>maxim && aux->val<=val)
            {
                maxim= aux->val;
                //cout << maxim<<" ";
            }
            if (aux->val> val)
               {
                    aux= aux->st;
                    //cout << maxim<<" ";
               }
            else if (aux->val==val)
            {
                //cout << maxim<<" ";
                break;
            }
            else
                aux =aux->dr;
            //cout << maxim<<" ";


        }
        fout<<maxim;
}

void succ(int val)
{
        nod *aux =root;
        int minim =1000000000;
        while (aux!=NULL)
        {
            if (aux->val<minim && aux->val>= val)
            {
                minim= aux->val;
            }
            if (aux->val <val)
            {
                aux=aux->dr;
            }
            else if (aux->val==val)
                break;
            else
            {
                aux= aux->st;
            }
        }
        fout<<minim;
}

void sortare(nod* n, int x, int y)
{
    if(n != NULL)
    {
        if(n->val >=x && n->val<= y)
        {
            sortare(n->st,x,y);
            fout<<n->val<<" ";
            sortare(n->dr,x,y);

        }
        else if(n->val <x)
        {
            sortare(n->dr,x,y);
        }
        else if(n->val >y)
        {
            sortare(n->st,x,y);
        }
    }
}

int main()
{
/*

    root = insrt(root, 9);
    root = insrt(root, 5);
    root = insrt(root, 10);
    root = insrt(root, 0);
    root = insrt(root, 6);
    root = insrt(root, 11);
    root = insrt(root, -1);
    root = insrt(root, 1);
    root = insrt(root, 2);

    preorder(root);
    cout<<"\n";
    pred(0);
    cout<<"\n";
    succ(11);
    //inorder(root);
    //cout<<"\n"<<cautare(root,9)<<"\n";

    //root = dlete(root, 10);
    //preorder(root);

    //cout<<"\n"<<cautare(root,10);
*/

    int i,n, op , x, y;

    fin>>n;
    root = NULL;
    for(i=1;i<=n;++i)
    {
        fin>> op;
        if(op == 1)
        {
            fin>>x;
            root = insrt(root,x);
        }
        else if(op == 2)
        {
            fin>>x;
            root = dlete(root,x);

        }
        else if(op == 3)
        {
            fin>>x;
            if(cautare(root, x) == 1)
                fout<<1<<"\n";
            else
                fout<<0<<"\n";
        }
        else if(op == 4)
        {
            fin>>x;
            pred(x);
            fout<<"\n";
        }
        else if(op == 5)
        {
            fin>>x;
            succ(x);
            fout<<"\n";
        }
        else if(op == 6)
        {
            fin>>x>>y;
            sortare(root,x,y);
            fout<<"\n";
        }
    }
    return 0;
}


