#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class Node{
private:
    const int t; //minimum number of keys in a non-root node
    //the order of a btree is 2t => each node can have max 2t-1 keys and max 2t children
    vector<int> keys; // array of keys
    vector<Node*> children; //array of child pointers
    int nrKeys; //the nr of keys *this* node has
    bool leaf;
public:
    Node(int, bool);

    bool isFull();
    bool contains(int);

    void insertNewKey(int);
    void splitChild(int, Node*);

    void borrowFromPrev(int);
    void borrowFromNext(int);

    void merge(int);
    void fill(int);

    int getPred(int);
    int getSucc(int);

    void removeFromLeaf(int);
    void removeFromNonLeaf(int);

    void traverseInterval(int, int);
    int searchSmaller(int, int = 0);
    int searchBigger(int, int = 0);


    void removeChild(int);

    friend class BTree;
};

class BTree{
    Node *root;
    const int t;  
public:
    BTree(int);
    void insert(int);
    void remove(int);
    bool contains(int);
    int searchSmaller(int);
    int searchBigger(int);
    void traverseInterval(int, int);
};

//constructors
Node::Node(int t, bool leaf):t(t){
    this->leaf = leaf;
    this->nrKeys = 0;
    keys.resize(2*t+1);
    children.resize(2*t);
}
BTree::BTree(int t): t(t){
    this->root = nullptr;
}

//check if the node contains the maximum number of keys or not
bool Node::isFull(){
    return nrKeys == 2*t-1;
}
// 1. INSERT A KEY
void Node::insertNewKey(int key){
    // initiliaze index at the rightmost key of this node
    int i = nrKeys-1;

    if (leaf){
       // LEAF NODE
       // if and while the key we want to insert is smaller than the keys present in this node, we move all the keys greater than it one position to the right in order to make space and insert our new key at its correct position
        while (i >= 0 && key < keys[i]){
            keys[i+1] = keys[i];
            i--;
        }
        keys[i+1] = key;
        nrKeys++;
    }
    else{
    // INTERNAL NODE
    // find the child which will have the new key
        while (i >= 0 && key < keys[i])
            i--;

        if (children[i+1]->isFull()){
            // split children[i+1] into two
            splitChild(i+1, children[i+1]);
            // after split, the middle key of children[i] went up 
            //compare the key with the new middle key to see in which child to insert its 
            if (key < keys[i+1]) 
                children[i+1]->insertNewKey(key);
            else
                children[i+2]->insertNewKey(key);
        }// if the found child node is NOT full, we insert the key 
        else 
            children[i+1]->insertNewKey(key);
    }
}

void Node::splitChild(int i, Node *child){
    // create a new node to store half of keys of child
    Node *newNode = new Node(child->t, child->leaf);
    newNode->nrKeys = t - 1;

    // copy the last half keys of child to the newNode
    for (int index = 0; index < t-1; index++)
        newNode->keys[index] = child->keys[index+t];

    // copy the last half children of child to newNode
    if (!child->leaf)
      for (int index = 0; index < t; index++)
        newNode->children[index] = child->children[index+t];

    //update the number of keys of the splitted child
    child->nrKeys = t - 1;

    // THIS node is having newNode as a child, so we find the correct position for newNode
    for (int j = this->nrKeys; j >= i+1; j--)
        this->children[j+1] = this->children[j];

    this->children[i+1] = newNode;

    // this node will have the middle key of child so creating space for that 
    for (int j = this->nrKeys-1; j >= i; j--)
        this->keys[j+1] = this->keys[j];
    this->keys[i] = child->keys[t-1];

    //updating THIS node's keys number (+ middle key from splitted child)
    this->nrKeys++;
}
void BTree::insert(int key){
    // if tree is empty, it means we are now inserting the root
    if (root == nullptr){
        root = new Node(t, true);
        root->keys[0] = key;
        root->nrKeys = 1;
        return;
    }
    // if tree is not empty
    if(!root->isFull()){
        // if the root is not full (it doesn't have the max nr of keys a node can have) => we append the key here in this node
        root->insertNewKey(key);
    }
    else{
        // if the root is full, we must split it and create a new root
        Node *newRoot = new Node(t, false);

        newRoot->children[0] = root;
        newRoot->splitChild(0, root);
        // newRoot has 2 children nodes now
        // we want to append the key in one of them (so either on children[0] or on children[1]), coresponding to its value
        // in order to do that we compare the value of the key with the value in our newRoot
        if(key < newRoot->keys[0])
            newRoot->children[0]->insertNewKey(key);
        else
            newRoot->children[1]->insertNewKey(key);

        root = newRoot;
    }
}

///////////////////////////////
//2. DELETE A KEY
void Node::removeChild(int x){

    int idx=0;
    while (idx<nrKeys && keys[idx] < x)
        ++idx;

    if (idx < nrKeys && keys[idx] == x){
        if (leaf) 
            removeFromLeaf(idx);
        else 
            removeFromNonLeaf(idx);
    }
    else{
        if (leaf) 
            return;

        bool flag = (idx == nrKeys);
        if (children[idx]->nrKeys < t)
            fill(idx);

        if (flag && idx > nrKeys)
            idx--;
        children[idx]->removeChild(x);
    }
}


void Node::removeFromLeaf (int idx){
    // move all the keys after the idx-th position one place backward
    for (int i = idx+1; i < nrKeys; ++i)
        keys[i-1] = keys[i];
    nrKeys--;
}

void Node::removeFromNonLeaf(int i){
    int key = keys[i];
    // If the child that precedes k (C[i]) has atleast t keys, find the predecessor 'pred' of k in the subtree rooted at C[i]. Replace k by pred. Recursively delete pred in C[i]
    if (children[i]->nrKeys >= t){
        int pred = getPred(i);
        keys[i] = pred;
        children[i]->removeChild(pred);
    }
    
    // If the child C[i] has less that t keys, examine C[i+1].
    // If C[i+1] has atleast t keys, find the successor 'succ' of k in
    // the subtree rooted at C[i+1]
    // Replace k by succ
    // Recursively delete succ in C[i+1]
    else if  (children[i+1]->nrKeys >= t){
        int succ = getSucc(i);
        keys[i] = succ;
        children[i+1]->removeChild(succ);
    }
    // If both C[i] and C[i+1] has less that t keys,merge k and all of C[i+1]
    // into C[i]
    // Now C[i] contains 2t-1 keys
    // Free C[i+1] and recursively delete k from C[i]
    else{
        merge(i);
        children[i]->removeChild(key);
    }
}

int Node::getPred(int i){
    Node *cur=children[i];
    // keep moving to the right most node until we reach a leaf
    while (!cur->leaf)
        cur = cur->children[cur->nrKeys];
    // return the last key of the leaf
    return cur->keys[cur->nrKeys-1];
}

int Node::getSucc(int idx){
    Node *cur = children[idx+1];
    // keep moving the left most node starting from C[idx+1] until we reach a leaf
    while (!cur->leaf)
        cur = cur->children[0];
    // return the first key of the leaf
    return cur->keys[0];
}

void Node::fill(int i){
    // If the previous child(children[idx-1]) has more than t-1 keys, borrow a key from that child
    if (i!=0 && children[i-1]->nrKeys>=t)
        borrowFromPrev(i);
    // If the next child(children[idx+1]) has more than t-1 keys, borrow a key from that child
    else if (i!=nrKeys && children[i+1]->nrKeys>=t)
        borrowFromNext(i);
    // Merge children[idx] with its sibling
    // If children[idx] is the last child, merge it with its previous sibling
    // Otherwise merge it with its next sibling
    else{
        if (i != nrKeys)
            merge(i);
        else
            merge(i-1);
    }
}

void Node::borrowFromPrev(int index){

    Node *child=children[index];
    Node *sibling=children[index-1];
    // The last key from C[idx-1] goes up to the parent and key[idx-1]
    // from parent is inserted as the first key in C[idx]. Thus, the  loses
    // sibling one key and child gains one key
 
    // Moving all key in C[idx] one step ahead
    for (int i=child->nrKeys-1; i>=0; --i)
        child->keys[i+1] = child->keys[i];
    // If C[idx] is not a leaf, move all its child pointers one step ahead
    if (!child->leaf)
        for(int i=child->nrKeys; i>=0; --i)
            child->children[i+1] = child->children[i];
// Setting child's first key equal to keys[idx-1] from the current node
    child->keys[0] = keys[index-1];

    // Moving sibling's last child as C[idx]'s first child
    if(!child->leaf)
        child->children[0] = sibling->children[sibling->nrKeys];

    // Moving the key from the sibling to the parent
    // This reduces the number of keys in the sibling
    keys[index-1] = sibling->keys[sibling->nrKeys-1];

    child->nrKeys++;
    sibling->nrKeys--;
}

void Node::borrowFromNext(int idx){
    Node *child=children[idx];
    Node *sibling=children[idx+1];
    // keys[idx] is inserted as the last key in C[idx]
    child->keys[(child->nrKeys)] = keys[idx];

    // Sibling's first child is inserted as the last child into children[idx]
    if (!(child->leaf))
        child->children[(child->nrKeys)+1] = sibling->children[0];
    //The first key from sibling is inserted into keys[idx]
    keys[idx] = sibling->keys[0];
    // Moving all keys in sibling one step behind
    for (int i=1; i<sibling->nrKeys; ++i)
        sibling->keys[i-1] = sibling->keys[i];
    // Moving the child pointers one step behind
    if (!sibling->leaf)
        for(int i=1; i<=sibling->nrKeys; ++i)
            sibling->children[i-1] = sibling->children[i];
    // Increasing and decreasing the key count of C[idx] and C[idx+1]
    // respectively
    child->nrKeys++;
    sibling->nrKeys--;
}

void Node::merge(int idx){
    Node *child = children[idx];
    Node *sibling = children[idx+1];

    // Pulling a key from the current node and inserting it into (t-1)th
    // position of children[idx]
    child->keys[t-1] = keys[idx];
    // Copying the keys from children[idx+1] to children[idx] at the end
    for (int i=0; i<sibling->nrKeys; ++i)
        child->keys[i+t] = sibling->keys[i];
    // Copying the child pointers from children[idx+1] to children[idx]
    if (!child->leaf)
        for(int i=0; i<=sibling->nrKeys; ++i)
            child->children[i+t] = sibling->children[i];
    // Moving all keys after idx in the current node one step before - to fill the gap created by moving keys[idx] to children[idx]
    for (int i=idx+1; i<nrKeys; ++i)
        keys[i-1] = keys[i];
    // Moving the child pointers after (idx+1) in the current node one step before
    for (int i=idx+2; i<=nrKeys; ++i)
        children[i-1] = children[i];
    // Updating the key count of child and the current node
    child->nrKeys += sibling->nrKeys+1;
    nrKeys--;

    delete(sibling);
}
void BTree::remove(int x){
    //call the remove function for the root
    root->removeChild(x);
    // if the root node has 0 keys, make its first child as the new root if it has a child, otherwise set root as NULL
    if (root->nrKeys==0){
        Node *tmp = root;
        if (root->leaf)
            root = NULL;
        else
            root = root->children[0];
        // free the old root
        delete tmp;
    }
}
//////////////////////
// 3. SEARCH FOR A KEY
bool Node::contains(int x) {
    int i=0;
    while(i<nrKeys && x>keys[i])
        ++i;
    if(i<nrKeys && keys[i]==x)
        return true;
    if(leaf)
        return false;
    return children[i]->contains(x);
}
bool BTree::contains(int x){
    if(this->root == nullptr) 
        return false;
    return this->root->contains(x);
}
// 4. SEARCH biggest number SMALLER THAN A GIVEN X KEY 
int Node::searchSmaller(int x, int last){
    int i = 0;
    while (i < nrKeys && x > keys[i])
        i++;

    if(i<nrKeys)
        if (keys[i] == x) 
            return keys[i];
    
    if(i>0) 
        last = keys[i-1];
    if (leaf)
        return last;

    return children[i]->searchSmaller(x, last);
}

int BTree::searchSmaller(int x){
    if(this->root == nullptr) 
        return 0;
    return this->root->searchSmaller(x);
    
}
// 5. SEARCH smallest number BIGGER THAN A GIVEN X KEY 
int Node::searchBigger(int x, int last){
    //If it finds a key greater than x, it updates the last variable to that key. If the node is a leaf node, it returns the updated last value.
    int i = 0;
    while (i < nrKeys && x > keys[i])
        i++;
    if (i<nrKeys) 
        if (keys[i] == x) 
            return keys[i];
        last = keys[i];
    
    if (leaf)
        return last;

    return children[i]->searchBigger(x, last = 0);
}


int BTree::searchBigger(int x){
    if(this->root == nullptr) 
        return 0;
    return this->root->searchBigger(x);
}

// 6. TRAVERSE INTERVAL
void Node::traverseInterval(int x, int y){
    int i;
    // a node has n keys and n+1 children

    // traverse the first n children of the node
    for (i = 0; i < this->nrKeys; i++){
        // if this node is not a leaf, then before storing its keys,
        // traverse the subtree rooted with child children[i].
        if (!this->leaf)
            children[i]->traverseInterval(x, y);
        if(x <= keys[i] && keys[i] <= y)
            g<<this->keys[i]<<" ";
    }
    // traverse the last child
    if (!this->leaf) 
        children[i]->traverseInterval(x, y);
}

void BTree::traverseInterval(int x, int y) {
    if(this->root!= nullptr)
        this->root->traverseInterval(x, y);
}

int main() {
    int n, command, x, y;
    BTree btree(100000);

    f>>n;
    while(n--){
      f>>command>>x;
       switch(command){
        case 1:{
          btree.insert(x);
          break;
        }
        case 2:{
          btree.remove(x);
          break;
        }
        case 3:{
          g<<btree.contains(x)<<endl;
          break;
        }
        case 4:{
          g<<btree.searchSmaller(x)<<endl;
          break;
        }
        case 5:{
          g<<btree.searchBigger(x)<<endl;
          break;
        }
        case 6:{
          f>>y;
          btree.traverseInterval(x, y);
          g<<endl;
          break;
        }
        default:{
          break;
        }
      }
    }
    f.close();
    g.close();
    return 0;
}
/*The algorithm uses a proactive insertion. Before going down to a node, we split it if it is full.
The advantage of splitting before is, we never traverse a node twice. If we don’t split a node before going down to it and split it only if a new key is inserted (reactive), we may end up traversing all nodes again from leaf to root. This happens in cases when all nodes on the path from the root to leaf are full. So when we come to the leaf node, we split it and move a key up. Moving a key up will cause a split in parent node (because the parent was already full). This cascading effect never happens in this proactive insertion algorithm. There is a disadvantage of this proactive insertion though, we may do unnecessary splits. */