#include <fstream>
#import <algorithm>
#import <vector>
#import <map>
#import <set>
#import <deque>
#import <queue>
#import <cassert>
//#import <cmath>
#import <cstring>
#import <cctype>
#import <cstdlib>
#import <stack>
using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};


class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};
InParser cin("abce.in");
OutParser cout("abce.out");
struct nod
{
    int val,pri;
    nod *st,*dr;
    nod(int v,int p,nod* s,nod* d)
    {
        this->st=s;
        this->dr=d;
        this->val=v;
        this->pri=p;
    }
}*S,*nil;
void b_left(nod*&t)
{
    nod*aux=t->st;
    t->st=aux->dr;
    aux->dr=t;
    t=aux;
}
void b_right(nod*&t)
{
    nod*aux=t->dr;
    t->dr=aux->st;
    aux->st=t;
    t=aux;
}
void balance(nod*&t)
{
    if(t->st->pri>t->pri)
    {
        b_left(t);
    }
    else if(t->dr->pri>t->pri)
    {
        b_right(t);
    }
}
void insert(nod*& t,const int& key)
{
    if(t==nil)
    {
        t=new nod(key,rand()+1,nil,nil);
        return;
    }
    if(t->val>key)insert(t->st,key);
    else if(t->val<key)insert(t->dr,key);
    balance(t);
}
void erase(nod*& t,const int& key)
{
    if(t==nil)return;
    if(t->val>key)erase(t->st,key);
    else if(t->val<key)erase(t->dr,key);
    else
    {
        if(t->st==nil && t->dr==nil)
        {
            delete t;
            t=nil;
        }
        else
        {
            if(t->st->pri > t->dr->pri)
            {
                b_left(t);
            }
            else
            {
                b_right(t);
            }
            erase(t,key);
        }
    }
}
bool find(nod*&t,const int& key)
{
    if(t==nil)return 0;
    if(t->val==key)
    {
        return 1;
    }
    if(t->val>key) return find(t->st,key);
    return find(t->dr,key);
}
int caut_l(nod*&t,const int& key)
{
    if(t==nil)return -2e9;

    if(t->val>key)
    {
        return caut_l(t->st,key);
    }
    else
    {
        return max(t->val,caut_l(t->dr,key));
    }
}
int caut_r(nod*&t,const int& key)
{
    if(t==nil)return 2e9;
    if(t->val<key)
    {
        return caut_r(t->dr,key);
    }
    else
    {
        return min(t->val,caut_r(t->st,key));
    }
}

void cer_6(nod*&t,const int& l,const int& r)
{
    if(t==nil)return;
    if(t->val>=l)
    {
        cer_6(t->st,l,r);
    }
    if(t->val>=l && t->val<=r)
    {
        cout<<t->val<<' ';
    }
    if(t->val<=r)
    {
        cer_6(t->dr,l,r);
    }
}
main()
{
    S=nil=new nod(0,0,nullptr,nullptr);
    int q;cin>>q;
    while(q--)
    {
        int cer,x;
        cin>>cer>>x;
        if(cer==1)
        {
            insert(S,x);
        }
        else if(cer==2)
        {
            erase(S,x);
        }
        else if(cer==3)
        {
            cout<<find(S,x)<<'\n';
        }
        else if(cer==4)
        {
            cout<<caut_l(S,x)<<'\n';
        }
        else if(cer==5)
        {
            cout<<caut_r(S,x)<<'\n';
        }
        else
        {
            int y;
            cin>>y;
            cer_6(S,x,y);
            cout<<'\n';
        }
    }

}
