#include <iostream>
#include <set>
#define lol long long
using namespace std;

set<lol> s;

int main()
{
    freopen("abce.in", "r", stdin);
    freopen("abce.out", "w", stdout);
    int q;
    scanf("%d", &q);
    while (q--)
    {
        int command;
        lol x;
        scanf("%d", &command);
        scanf("%lld", &x);
        if (command == 1)
        {
            s.insert(x);
        }
        else if (command == 2)
        {
            s.erase(x);
        }
        else if (command == 3)
        {
            if (s.find(x) != s.end())
                printf("1\n");
            else
                printf("0\n");
        }
        else if (command == 4)
        {
            if (*(s.lower_bound(x)) != x)
                printf("%lld\n", *(--(s.lower_bound(x))));
            else
                printf("%lld\n", x);
        }
        else if (command == 5)
        {
            printf("%lld\n", *(s.lower_bound(x)));
        }
        else
        {
            lol y;
            scanf("%lld", &y);
            for (auto it : s)
            {
                if (it <= y && it >= x)
                    printf("%lld ", it);
            }
            printf("\n");
        }
    }
}