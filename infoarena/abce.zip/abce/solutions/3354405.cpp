#include <bits/stdc++.h>
using namespace std;

struct Nod
{
    int cheie, inaltime;
    Nod *stanga, *dreapta;
    Nod(int c) : cheie(c), inaltime(1), stanga(nullptr), dreapta(nullptr) {}
};

Nod rezerva[100005];
int idx_rezerva = 0;
Nod *nod_nou(int c)
{
    rezerva[idx_rezerva] = Nod(c);
    return &rezerva[idx_rezerva++];
}

int inal(Nod *t) { if (t) return t->inaltime; return 0; }
int dezechilibru(Nod *t) { return inal(t->stanga) - inal(t->dreapta); }
void actualizeaza(Nod *t) { t->inaltime = 1 + max(inal(t->stanga), inal(t->dreapta)); }

Nod *rotatie_dreapta(Nod *y)
{
    Nod *x = y->stanga;
    y->stanga = x->dreapta;
    x->dreapta = y;
    actualizeaza(y);
    actualizeaza(x);
    return x;
}

Nod *rotatie_stanga(Nod *x)
{
    Nod *y = x->dreapta;
    x->dreapta = y->stanga;
    y->stanga = x;
    actualizeaza(x);
    actualizeaza(y);
    return y;
}

Nod *echilibreaza(Nod *t)
{
    actualizeaza(t);
    int d = dezechilibru(t);
    if (d > 1)
    {
        if (dezechilibru(t->stanga) < 0)
            t->stanga = rotatie_stanga(t->stanga);
        return rotatie_dreapta(t);
    }
    if (d < -1)
    {
        if (dezechilibru(t->dreapta) > 0)
            t->dreapta = rotatie_dreapta(t->dreapta);
        return rotatie_stanga(t);
    }
    return t;
}

Nod *insereaza(Nod *t, int c)
{
    if (!t)
        return nod_nou(c);
    if (c < t->cheie)
        t->stanga = insereaza(t->stanga, c);
    else
        t->dreapta = insereaza(t->dreapta, c);
    return echilibreaza(t);
}

Nod *sterge(Nod *t, int c)
{
    if (!t)
        return nullptr;
    if (c < t->cheie)
        t->stanga = sterge(t->stanga, c);
    else if (c > t->cheie)
        t->dreapta = sterge(t->dreapta, c);
    else
    {
        if (!t->stanga)
            return t->dreapta;
        if (!t->dreapta)
            return t->stanga;
        Nod *min = t->dreapta;
        while (min->stanga)
            min = min->stanga;
        t->cheie = min->cheie;
        t->dreapta = sterge(t->dreapta, min->cheie);
    }
    return echilibreaza(t);
}

bool contine(Nod *t, int c)
{
    while (t)
    {
        if (t->cheie == c)
            return true;
        else if (c < t->cheie)
            t = t->stanga;
        else
            t = t->dreapta;
    }
    return false;
}

int maxim_mai_mic_egal(Nod *t, int c)
{
    int rez = INT_MIN;
    while (t)
    {
        if (t->cheie <= c)
        {
            rez = t->cheie;
            t = t->dreapta;
        }
        else
            t = t->stanga;
    }
    return rez;
}

int minim_mai_mare_egal(Nod *t, int c)
{
    int rez = INT_MAX;
    while (t)
    {
        if (t->cheie >= c)
        {
            rez = t->cheie;
            t = t->stanga;
        }
        else
            t = t->dreapta;
    }
    return rez;
}

void interval(Nod *t, int x, int y, FILE *fout)
{
    if (!t)
        return;
    if (t->cheie > x)
        interval(t->stanga, x, y, fout);
    if (t->cheie >= x && t->cheie <= y)
        fprintf(fout, "%d ", t->cheie);
    if (t->cheie < y)
        interval(t->dreapta, x, y, fout);
}

int main()
{
    FILE *fin = fopen("abce.in", "r");
    FILE *fout = fopen("abce.out", "w");

    Nod *radacina = nullptr;
    int q;
    fscanf(fin, "%d", &q);

    while (q--)
    {
        int op, x, y;
        fscanf(fin, "%d %d", &op, &x);
        switch (op)
        {
        case 1:
            radacina = insereaza(radacina, x);
            break;
        case 2:
            radacina = sterge(radacina, x);
            break;
        case 3:
            fprintf(fout, "%d\n", contine(radacina, x) ? 1 : 0);
            break;
        case 4:
            fprintf(fout, "%d\n", maxim_mai_mic_egal(radacina, x));
            break;
        case 5:
            fprintf(fout, "%d\n", minim_mai_mare_egal(radacina, x));
            break;
        case 6:
            fscanf(fin, "%d", &y);
            interval(radacina, x, y, fout);
            fprintf(fout, "\n");
            break;
        }
    }
    return 0;
}