#include <bits/stdc++.h>

using namespace std;

#ifndef LOCAL

ifstream in("abce.in");
ofstream out("abce.out");

#define cin in
#define cout out

#endif //LOCAL

int main()
{
	set<int> abce;

	int q; cin >> q;
	while(q--)
	{
		char t; cin >> t;
		if(t == '1') {
			int x; cin >> x;
			abce.insert(x);
		} 
		if(t == '2') {
			int x; cin >> x;
			abce.erase(x);
		}
		if(t == '3') {
			int x; cin >> x;
			cout << abce.count(x) << '\n';
		}
		if(t == '4') {
			int x; cin >> x;
			cout << *(--abce.lower_bound(x)) << '\n';
		}
		if(t == '5') {
			int x; cin >> x;
			cout << *(abce.lower_bound(x)) << '\n';
		}
		if(t == '6') {
			int x, y; cin >> x >> y;
			for(auto it = abce.lower_bound(x); it != abce.end() && *it <= y; it++)
				cout << *(it) << " ";
			cout << '\n';
		}
	}
}