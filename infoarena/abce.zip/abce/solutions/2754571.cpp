#include <fstream>
#include <vector>
using namespace std;

ifstream in("abce.in");
ofstream out("abce.out");

class node{

    int val;
    node* tata;
    node* fiu1;
    node* fiu2;

public:
    node();
    node(int a);
    node* getfiu1();
    node* getfiu2();
    node* gettata();
    int getval();
    void setfiu1(node* nod);
    void setfiu2(node* nod);
    void settata(node* nod);
    void setval(int a);
    ~node();

};

node::node(){
    this->val=0;
    tata=nullptr;
    fiu1=nullptr;
    fiu2=nullptr;
}

node::node(int a){
    this->val=a;
    tata=nullptr;
    fiu1=nullptr;
    fiu2=nullptr;
}

node* node::getfiu1(){
    return this->fiu1;
}

node* node::getfiu2(){
    return this->fiu2;
}

node* node::gettata(){
    return this->tata;
}

int node::getval(){
    return this->val;
}

void node::setfiu1(node* nod){
    this->fiu1=nod;
}

void node::setfiu2(node* nod){
    this->fiu2=nod;
}

void node::settata(node* nod){
    this->tata=nod;
}

void node::setval(int a){
    this->val=a;
}

node::~node(){
    this->val=0;
    this->fiu1=nullptr;
    this->fiu2=nullptr;
    this->tata=nullptr;
}

class Splaytree{

    node* radacina;

public:
    Splaytree();
    Splaytree(int x);
    void push(int x);
    void inorder(int x, int y);
    void splay(node* nod);
    node* getradacina();
    void right(node* nod);
    void left(node* nod);
    node* search(int x);
    bool remove(int x);
	node* predecessor(int x);
    node* successor(int x);
    void interval(int x, int y);
};

Splaytree::Splaytree(){
    this->radacina=nullptr;
}

Splaytree::Splaytree(int x){
    node * nod = new node(x);
    this->radacina=nod;
}

void Splaytree::push(int x){
    node* nod = new node(x);
    if(this->radacina==nullptr){
        this->radacina=nod;
    }
    else{
        node* act = this->radacina;
        while(act!=nullptr){
            nod->settata(act);
            if(act->getval() > x){
                act = act->getfiu1();
            }
            else{
                act = act->getfiu2();
            }
        }
        if(x > nod->gettata()->getval()){
            nod->gettata()->setfiu2(nod);
        }
        else{
            nod->gettata()->setfiu1(nod);
        }
    }
    splay(nod);
}

node* Splaytree::search(int x){
    node* nod = this->radacina;
    if(nod == nullptr || (nod->getfiu1()==nullptr && nod->getfiu2()==nullptr)){
        return nullptr;
    }
    while(nod){
        if(nod->getval() == x){
            splay(nod);
            return nod;
        }
        if(x < nod->getval()){
            if(nod->getfiu1() == nullptr){
                splay(nod);
                return nullptr;
            }
            nod = nod->getfiu1();
        }
        else{
            if(nod->getfiu2() == nullptr){
                splay(nod);
                return nullptr;
            }
            nod = nod->getfiu2();
        }
    }
    return nullptr;
}

bool Splaytree::remove(int x){
    node* nod = this->search(x);
    if(nod == nullptr){
        return 0;
    }
    if(nod->getfiu1() == nullptr && nod->getfiu2() == nullptr){
        this->radacina = nullptr;
        delete nod;
        return 1;
    }
    if(nod->getfiu1() == nullptr){
        nod->getfiu2()->settata(nullptr);
        this->radacina = nod->getfiu2();
        delete nod;
        return 1;
    }
    node* act = nod->getfiu1();
    while(act->getfiu2() != nullptr){
        act = act->getfiu2();
    }
    this->radacina = nod->getfiu1();
    this->radacina->settata(nullptr);
    node* exfiu;
    if(nod->getfiu2()!=nullptr){
        exfiu = nod->getfiu2();
        exfiu->settata(act);
    }
    else{
        exfiu = nullptr;
    }
    delete nod;
    splay(act);
    act->settata(nullptr);
    act->setfiu2(exfiu);
    this->radacina = act;
    return 1;
}

void Splaytree::right(node* nod){
    node* tata = nod->gettata();
    node* bunic = tata->gettata();
    if(tata == radacina){
        nod->settata(nullptr);
        radacina=nod;
    }
    else{
        if(bunic->getval() > tata->getval()){
            bunic->setfiu1(nod);
        }
        else{
            bunic->setfiu2(nod);
        }
        nod->settata(bunic);
    }
    if(nod->getfiu2() != nullptr){
        tata->setfiu1(nod->getfiu2());
        nod->getfiu2()->settata(tata);
    }
    else{
        tata->setfiu1(nullptr);
    }
    tata->settata(nod);
    nod->setfiu2(tata);
}

void Splaytree::left(node* nod){
    node* tata = nod->gettata();
    node* bunic = tata->gettata();
    if(tata == radacina){
        nod->settata(nullptr);
        radacina=nod;
    }
    else{
        if(bunic->getval() > tata->getval()){
            bunic->setfiu1(nod);
        }
        else{
            bunic->setfiu2(nod);
        }
        nod->settata(bunic);
    }
    if(nod->getfiu1() != nullptr){
        tata->setfiu2(nod->getfiu1());
        nod->getfiu1()->settata(tata);
    }
    else{
        tata->setfiu2(nullptr);
    }
    tata->settata(nod);
    nod->setfiu1(tata);
}

void Splaytree::splay(node* nod){
    //while(nod != this->radacina){
        if(nod->gettata() == this->radacina){
            if(nod->getval() < this->radacina->getval()){
                right(nod);
            }
            else{
                left(nod);
            }
        }
        else if(nod != this->radacina){
            if(nod->gettata()->getval() > nod->getval()){
                if(nod->gettata()->gettata()->getval() > nod->getval()){
                    right(nod->gettata());
                    right(nod);
                }
                else{
                    right(nod);
                    left(nod);
                }
            }
            else{
                if(nod->gettata()->gettata()->getval() < nod->getval()){
                    left(nod->gettata());
                    left(nod);
                }
                else{
                    left(nod);
                    right(nod);
                }
            }
            splay(nod);
        }
    //}
}

node* Splaytree::predecessor(int x){
    if(this->search(x)==nullptr){
        this->push(x);
    }
    if(this->radacina->getfiu1() == nullptr){
        this->remove(x);
        return nullptr;
    }
    else{
        node* act = this->radacina->getfiu1();
        while(act->getfiu2() != nullptr){
            act = act->getfiu2();
        }
        this->remove(x);
        return act;
    }
    this->remove(x);
    return nullptr;
}

node* Splaytree::successor(int x){
    if(this->search(x)==nullptr){
        this->push(x);
    }
    if(this->radacina->getfiu2() == nullptr){
        this->remove(x);
        return nullptr;
    }
    else{
        node* act = this->radacina->getfiu2();
        while(act->getfiu1() != nullptr){
            act = act->getfiu1();
        }
        this->remove(x);
        return act;
    }
    this->remove(x);
    return nullptr;
}

void Splaytree::interval(int x, int y){
    this->inorder(x, y);
    return;
}

void inordine(node* nod, int x, int y){
    if(nod==nullptr){
        return;
    }
    inordine(nod->getfiu1(), x, y);
    int z = nod->getval();
    if(z>=x && z<=y){
        out<<z<<' ';
    }
    inordine(nod->getfiu2(), x, y);
}

void Splaytree::inorder(int x, int y){
    inordine(this->radacina, x, y);
    out<<"\n";
}

node* Splaytree:: getradacina(){
    return this->radacina;
}
int main(){
    int n, c;
    in>>n;
    Splaytree sp;
    for(int i=0; i<n; ++i){
        in>>c;
        if(c==1){
            int x;
            in>>x;
            sp.push(x);
        }
        else if(c==2){
            int x;
            in>>x;
            sp.remove(x);
        }
        else if(c==3){
            int x;
            in>>x;
            node* nod = sp.search(x);
            if(nod==nullptr){
                out<<0<<'\n';
            }
            else{
                out<<1<<'\n';
            }
        }
        else if(c==4){
            int x;
            in>>x;
            out<<sp.predecessor(x)->getval()<<'\n';
        }
        else if(c==5){
            int x;
            in>>x;
            out<<sp.successor(x)->getval()<<'\n';
        }
        else{
            int x, y;
            in>>x>>y;
            node* nod=sp.getradacina();
            inordine(nod, x, y);
            out<<'\n';
        }
    }
    return 0;
}
