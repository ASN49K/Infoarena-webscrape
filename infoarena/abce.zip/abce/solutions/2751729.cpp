#include <bits/stdc++.h>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct nod
    {
        long long cheie;
        nod* stanga;
        nod* dreapta;
        nod* tata;
    };


nod* rad=NULL;

void insereaza(long long val)
{
    if(rad == NULL)
    {
        nod* aux;
        aux = new nod();
        aux->cheie = val;
        aux->tata = NULL;
        aux->dreapta =NULL;
        aux->stanga=NULL;
        rad = aux;
        return;
    }
    nod* aux;
    aux=new nod();
    aux->cheie = val;
    aux->stanga=NULL;
    aux->dreapta=NULL;
    nod* aux2;
    aux2 = rad;
    int ok = 1;
    while(ok == 1)
    {
        if(aux->cheie<aux2->cheie && aux2->stanga == NULL)
        {
            aux2->stanga = aux;
            aux->tata = aux2;
            ok = 0;
        }
        else
            if(aux->cheie>aux2->cheie && aux2->dreapta == NULL)
            {
                aux2->dreapta = aux;
                aux->tata = aux2;
                ok = 0;
            }
            else
                if(aux->cheie>aux2->cheie && aux2->dreapta!=NULL)
                    aux2 = aux2->dreapta;
                else
                    if(aux->cheie<aux2->cheie && aux2->stanga!=NULL)
                        aux2 = aux2->stanga;
    }
}

nod* cauta(nod* aux,long long val)
{
    if(aux != NULL)
    {
        if(val==aux->cheie)
        {
            while(aux->tata!=NULL)
            {
                //zig situation
                if(aux->tata->tata==NULL)
                {

                    if(aux->cheie>aux->tata->cheie)
                    {

                        aux->tata->dreapta = aux->stanga;
                        if(aux->stanga!=NULL)
                            aux->stanga->tata = aux->tata;
                        aux->tata->tata = aux;
                        aux->stanga = aux->tata;
                        aux->tata = NULL;
                    }
                    else
                    {

                        aux->tata->stanga = aux->dreapta;
                        if(aux->dreapta != NULL)
                            aux->dreapta->tata = aux->tata;
                        aux->tata->tata = aux;
                        aux->dreapta = aux->tata;
                        aux->tata = NULL;

                    }
                }
                else
                {
                    //zig zag stiuation
                    if(aux->cheie>aux->tata->cheie && aux->tata->cheie<aux->tata->tata->cheie)
                    {

                        nod* aux2;
                        aux2 = aux->tata->tata;
                        aux->tata->dreapta = aux->stanga;
                        if(aux->stanga!=NULL)
                            aux->stanga->tata = aux->tata;
                        aux->stanga = aux->tata;
                        aux->stanga->tata = aux;
                        aux->tata = aux2;
                        aux->tata->stanga = aux;


                    }
                    else if(aux->cheie<aux->tata->cheie && aux->tata->cheie>aux->tata->tata->cheie)
                    {
                        nod* aux2;
                        aux2 = aux->tata->tata;
                        aux->tata->stanga = aux->dreapta;
                        if(aux->dreapta!=NULL)
                            aux->dreapta->tata = aux->tata;
                        aux->dreapta = aux->tata;
                        aux->dreapta->tata = aux;
                        aux->tata = aux2;
                        aux->tata->dreapta = aux;
                    }
                    //zig zig situation
                    else if(aux->cheie<aux->tata->cheie && aux->tata->cheie<aux->tata->tata->cheie)
                    {
                        nod* aux2;
                        aux2 = aux->tata->tata;
                        aux->tata->stanga=aux->dreapta;
                        if(aux->dreapta!=NULL)
                            aux->dreapta->tata = aux->tata;
                        aux->dreapta = aux->tata;
                        aux->dreapta->tata = aux;
                        aux->tata = aux2;
                        aux->tata->stanga= aux;
                    }
                    else if(aux->cheie>aux->tata->cheie && aux->tata->cheie>aux->tata->tata->cheie)
                    {
                        nod* aux2;
                        aux2 = aux->tata->tata;
                        aux->tata->dreapta = aux->stanga;
                        if(aux->stanga!=NULL)
                            aux->stanga->tata = aux->tata;
                        aux->stanga = aux->tata;
                        aux->stanga->tata = aux;
                        aux->tata = aux2;
                        aux->tata->dreapta = aux;

                    }

                }
            }
            rad = aux;
            return rad;
        }
        if(val>aux->cheie)
            return cauta(aux->dreapta,val);
        if(val<aux->cheie)
            return cauta(aux->stanga,val);
    }
    else
        return NULL;
}

void inordine(nod* aux)
{
    if(aux!=NULL)
    {
        inordine(aux->stanga);
        cout<<aux->cheie<<" ";
        inordine(aux->dreapta);
    }
}
void inordine_min_max(nod* aux,long long minim,long long maxim)
{
    if(aux!=NULL)
    {
        if(aux->cheie>=minim && aux->cheie<=maxim)
        {
            inordine_min_max(aux->stanga,minim,maxim);
            fout<<aux->cheie<<" ";
            inordine_min_max(aux->dreapta,minim,maxim);

        }
        else if(aux->cheie<minim)
        {
            inordine_min_max(aux->dreapta,minim,maxim);
        }
        else if(aux->cheie>maxim)
        {
            inordine_min_max(aux->stanga,minim,maxim);
        }

    }
}
nod* succ(long long val)
{
    nod* aux2 = cauta(rad,val);
    if(aux2==NULL)
        return NULL;
    aux2 = aux2->dreapta;
    if(aux2 == NULL)
        return NULL;
    while(aux2->stanga!=NULL)
        aux2=aux2->stanga;
    return aux2;
}

nod* pred(long long val)
{
    nod* aux2 = cauta(rad,val);
    if(aux2== NULL)
        return NULL;
    aux2 = aux2->stanga;
    if(aux2 == NULL)
        return NULL;
    while(aux2->dreapta!=NULL)
        aux2=aux2->dreapta;
    return aux2;
}
void sterge(long long val)
{
    nod* aux;
    if(succ(val)!=NULL)
    {

        aux = succ(val);
        if(aux->tata->cheie ==val )
        {
            aux->tata->cheie = aux->cheie;
            aux->tata->dreapta = aux->dreapta;
            if(aux->tata->dreapta!=NULL)
                aux->tata->dreapta->tata = aux->tata;
        }
        else
        {
            nod* aux2;
            aux2 = cauta(rad,val);
            aux2 ->cheie = aux->cheie;
            aux->tata->stanga = aux->dreapta;
            if(aux->tata->stanga!=NULL)
                aux->tata->stanga->tata = aux->tata;
        }
    }
    else if(pred(val)!=NULL)
    {
        aux = pred(val);
        if(aux->tata->cheie == val)
        {
            aux->tata->cheie = aux->cheie;
            aux->tata->stanga = aux->stanga;
            if(aux->tata->stanga!=NULL)
                aux->tata->stanga->tata = aux->tata;
        }
        else
        {
            nod* aux2;
            aux2 = cauta(rad,val);
            aux2 ->cheie = aux->cheie;
            aux->tata->dreapta = aux->stanga;
            if(aux->tata->dreapta!=NULL)
                aux->tata->dreapta->tata = aux->tata;
        }
    }
    else
    {
        nod* aux3;
        aux3 = cauta(rad,val);
        if(aux3 == NULL)
            cout<<"Nu exista valoare\n";
        else
            rad =NULL;
    }


}
int main() {


    int n;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        int comanda;
        fin>>comanda;
        if(comanda==1)
        {
            long long x;
            fin>>x;
            insereaza(x);
        }
        if(comanda ==2)
        {
            long long x;
            fin>>x;
            sterge(x);
        }
        if(comanda==3)
        {
            long long x;
            fin>>x;
            if(cauta(rad,x)==NULL)
                fout<<"0\n";
            else
                fout<<"1\n";
        }
        if(comanda == 4)
        {
            long long x;
            fin>>x;
            if(cauta(rad,x)==NULL)
            {
                while(cauta(rad,x)==NULL)
                {
                    x--;
                }
                fout<<x<<"\n";
            }
            else
                fout<<pred(x)->cheie<<"\n";
        }
        if(comanda == 5)
        {
            long long x;
            fin>>x;
            if(cauta(rad,x)==NULL)
            {
                while(cauta(rad,x)==NULL)
                    x++;
                fout<<x<<"\n";
            }
            else
            {
                fout<<succ(x)->cheie<<"\n";
            }
        }
        if(comanda == 6)
        {
            long long x,y;
            fin>>x>>y;
            inordine_min_max(rad,x,y);
            fout<<"\n";
        }
    }


    return 0;

}
