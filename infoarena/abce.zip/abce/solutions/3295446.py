import random

class Node:
    __slots__ = ["value", "forward"]
    def __init__(self, value, level):
        self.value = value
        self.forward = [None] * (level + 1)

class SkipList:
    MAX_LEVEL = 14
    P = 0.25

    def __init__(self):
        self.header = Node(None, self.MAX_LEVEL)
        self.level = 0

    def random_level(self):
        lvl = 0
        while random.random() < self.P and lvl < self.MAX_LEVEL:
            lvl += 1
        return lvl

    def insert(self, value):
        update = [None] * (self.MAX_LEVEL + 1)
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value < value:
                current = current.forward[i]
            update[i] = current
        current = current.forward[0]
        if current is None or current.value != value:
            new_level = self.random_level()
            if new_level > self.level:
                for i in range(self.level + 1, new_level + 1):
                    update[i] = self.header
                self.level = new_level
            new_node = Node(value, new_level)
            for i in range(new_level + 1):
                new_node.forward[i] = update[i].forward[i]
                update[i].forward[i] = new_node

    def delete(self, value):
        update = [None] * (self.MAX_LEVEL + 1)
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value < value:
                current = current.forward[i]
            update[i] = current
        current = current.forward[0]
        if current and current.value == value:
            for i in range(self.level + 1):
                if update[i].forward[i] != current:
                    break
                update[i].forward[i] = current.forward[i]
            while self.level > 0 and self.header.forward[self.level] is None:
                self.level -= 1

    def search(self, value):
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value < value:
                current = current.forward[i]
        current = current.forward[0]
        return current is not None and current.value == value

    def floor(self, x):
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value <= x:
                current = current.forward[i]
        return current.value

    def ceil(self, x):
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value < x:
                current = current.forward[i]
        current = current.forward[0]
        return current.value

    def range_query(self, x, y):
        current = self.header
        for i in range(self.level, -1, -1):
            while current.forward[i] and current.forward[i].value < x:
                current = current.forward[i]
        current = current.forward[0]
        while current and current.value <= y:
            yield current.value
            current = current.forward[0]

def run_abce_test(input_file="abce.in", output_file="abce.out"):
    with open(input_file) as fin:
        Q = int(fin.readline())
        ops = [list(map(int, fin.readline().strip().split())) for _ in range(Q)]

    ds = SkipList()
    with open(output_file, "w") as fout:
        for op in ops:
            t = op[0]
            if t == 1:
                ds.insert(op[1])
            elif t == 2:
                ds.delete(op[1])
            elif t == 3:
                fout.write(f"{int(ds.search(op[1]))}\n")
            elif t == 4:
                fout.write(f"{ds.floor(op[1])}\n")
            elif t == 5:
                fout.write(f"{ds.ceil(op[1])}\n")
            elif t == 6:
                fout.write(" ".join(map(str, ds.range_query(op[1], op[2]))) + "\n")

if __name__ == "__main__":
    run_abce_test()
