#include<bits/stdc++.h>
using namespace std;

ifstream fin ("abce.in");
ofstream fout ("abce.out");

multiset<int> arbore;
multiset<int> :: iterator it;

int main() {
    int operatii, o, x, y;
    fin >> operatii;
    while (operatii--) {
        fin >> o >> x;
        switch(o) {
            case 1:
                arbore.insert(x);
                break;
            case 2:
                arbore.erase(x);
                break;
            case 3:
                if (arbore.find(x) != arbore.end())
                    fout << "1\n";
                else 
                    fout << "0\n";
                break;
            case 4: 
                it = arbore.lower_bound(x);
                it--;
                fout << *it << "\n";
                break;
            case 5: 
                it = arbore.lower_bound(x);
                fout << *it << "\n";
                break;
            case 6: 
                fin >> y;
                for (it = arbore.lower_bound(x); *it <= y && it != arbore.end(); it++) 
                    fout << *it << " ";
                fout << "\n";
                break;
        }
    }
}
