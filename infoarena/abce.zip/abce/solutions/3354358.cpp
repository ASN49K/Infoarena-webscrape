#include <iostream>
#include <fstream>

using namespace std;

struct Node {
   int key;
   Node *left;
   Node *right;
   int height;
   
   Node(int k) {
      key = k;
      left = nullptr;
      right = nullptr;
      height = 1;
   }
};

int height(Node *node) {
   if (node == nullptr) {
      return 0;
   }
   return node->height;
}

Node *rotateRight(Node *y) {
   Node *x = y->left;
   Node *z = x->right;

   x->right = y;
   y->left = z;

   x->height = max(height(x->left), height(x->right)) + 1;
   y->height = max(height(y->left), height(y->right)) + 1;

   return x;
}

Node *rotateLeft(Node *x) {
   Node *y = x->right; 
   Node *z = y->left;

   y->left = x;
   x->right = z;

   y->height = max(height(y->left), height(y->right)) + 1;
   x->height = max(height(x->left), height(x->right)) + 1;

   return y;  
}

int getBalance(Node *node) {
   if (node == nullptr) {
      return 0;
   }
   return height(node->left) - height(node->right);
}

Node *insert(Node *node, int key) {
   if (node == nullptr) {
      return new Node(key);
   }

   if (key < node->key) {
      node->left = insert(node->left, key);
   } else if (key > node->key) {
      node->right = insert(node->right, key);
   } else {
      return node;
   }

   node->height = 1 + max(height(node->left), height(node->right));

   int balance = getBalance(node);

   // LL
   if (balance > 1 && key < node->left->key) {
      return rotateRight(node);
   }

   // RR
   if (balance < -1 && key > node->right->key) {
      return rotateLeft(node);
   }

   // LR
   if (balance > 1 && key > node->left->key) {
      node->left = rotateLeft(node->left);
      return rotateRight(node);
   }

   // RL
   if (balance < -1 && key < node->right->key) {
      node->right = rotateRight(node->right);
      return rotateLeft(node);
   }

   return node;
}

Node* stergere(Node* root, int key) {
   if (root == nullptr) {
      return root;
   }

   if (key < root->key) 
      root->left = stergere(root->left, key);
   else if (key > root->key)
      root->right = stergere(root->right, key);

   //delroot
   else {
      if ((root->left == nullptr) || (root->right == nullptr)) {
         Node *temp = root->left ? root->left : root->right;

         if (temp == nullptr) {
            delete root;
            return nullptr;
         } else {
            delete root;
            return temp;
         }
      } else {
         //minval
         Node* temp = root->right;
         while (temp->left != nullptr)
            temp = temp->left;
         root->key = temp->key;
         root->right = stergere(root->right, temp->key);
      }
   }

   if (root == nullptr) {
      return root;
   }

   root->height = 1 + max(height(root->left), height(root->right));
   int balance = getBalance(root);

   // LL
   if (balance > 1 && getBalance(root->left) >= 0) {
      return rotateRight(root);
   }

   // LR
   if (balance > 1 && getBalance(root->left) < 0) {
      root->left = rotateLeft(root->left);
      return rotateRight(root);
   }

   // RR
   if (balance < -1 && getBalance(root->right) <= 0) {
      return rotateLeft(root);
   }

   // RL
   if (balance < -1 && getBalance(root->right) > 0) {
      root->right = rotateRight(root->right);
      return rotateLeft(root);
   }

   return root;
}

void preOrder(Node *root) {
   if (root != nullptr) {
      cout << root->key << " ";
      preOrder(root->left);
      preOrder(root->right);
   }
}

bool exista(Node *root, int key) {
   if (root == nullptr) {
      return false;
   }
   if (root->key == key) {
      return true;
   }
   if (key < root->key) {
      return exista(root->left, key);
   } else {
      return exista(root->right, key);
   }
}

int maiMicSauEgal(Node *root, int x) {
   int result = -1;
   while (root != nullptr) {
      if (root->key == x) return x;
      if (root->key < x) { result = root->key; root = root->right; }
      else root = root->left;
   }
   return result;
}

int maiMareSauEgal(Node *root, int x) {
   int result = -1;
   while (root != nullptr) {
      if (root->key == x) return x;
      if (root->key > x) { result = root->key; root = root->left; }
      else root = root->right;
   }
   return result;
}

ofstream fout("abce.out");

void showSorted(Node *root, int x, int y){
   if (root == nullptr) return;
   if (root->key > y){
      showSorted(root->left, x, y);
      return;
   }
   if(root->key < x){
      showSorted(root->right, x, y);
      return;
   }

   if(root->key > x)
      showSorted(root->left, x, y);
   fout << root->key << " ";
   if(root->key < y)
      showSorted(root->right, x, y); 
}

ifstream fin("abce.in");


int main() { 
   Node *root = nullptr;

   int n;
   fin >> n;
   while (n--){
      int op;
      fin >> op;
      if (op == 1) {
         int key;
         fin >> key;
         root = insert(root, key);
      }
      else if (op == 2) {
         int key;
         fin >> key;
         root = stergere(root, key);
      }
      else if (op == 3) {
         int key;
         fin >> key;
         fout << (exista(root, key) ? "1\n" : "0\n");
      }
      else if (op == 4) {
         int key;
         fin >> key;
         fout << maiMicSauEgal(root, key) << "\n";
      }
      else if (op == 5) {
         int key;
         fin >> key;
         fout << maiMareSauEgal(root, key) << "\n";
      }
      else if (op == 6) {
         int x, y;
         fin >> x >> y;
         showSorted(root, x, y);
         fout << endl;
      }
   }
   fin.close();
   fout.close();
   return 0;

}