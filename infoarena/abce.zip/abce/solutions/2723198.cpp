#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>
#include <vector>

using namespace std;

int N;

set<int> tree;

void add(int x)
{
	tree.insert(x);
}
void remove(int x)
{
	tree.erase(x);
}
int find(int x)
{
	auto it = tree.find(x);
	if (it == tree.end())
	{
		return 0;
	}
	return 1;
}
int smaller(int x)
{
	auto it = tree.lower_bound(x);
	if (*it == x)
		return x;
	else
	{
		return *(--it);
	}
}
int bigger(int x)
{
	auto it = tree.lower_bound(x);
	return *it;
}
void between(int x, int y, vector<int>& numbers)
{
	auto it = tree.lower_bound(x);
	auto end = tree.upper_bound(y);
	while (it != end)
	{
		numbers.push_back(*it);
		it++;
	}
}

int main()
{
	ifstream f("abce.in");
	ofstream g("abce.out");
	// Program
	f >> N;
	for (int i = 0; i < N; i++)
	{
		int Q,x,y;
		f >> Q;
		switch (Q)
		{
		case 1:
		{
			f >> x;
			add(x);
			break;
		}
		case 2:
		{
			f >> x;
			remove(x);
			break;
		}
		case 3:
		{
			f >> x;
			g << find(x) << '\n';
			break;
		}
		case 4:
		{
			f >> x;
			g << smaller(x) << '\n';
			break;
		}
		case 5:
		{
			f >> x;
			g << bigger(x) << '\n';
			break;
		}
		case 6:
		{
			f >> x >> y;
			vector<int> numbers;
			between(x, y, numbers);
			for (auto it = numbers.begin(); it != numbers.end(); it++)
			{
				g << *it << " ";
			}
			g << '\n';
			break;
		}
		default:
			break;
		}
	}


	// Exit
	f.close();
	g.close();
	return 0;
}
