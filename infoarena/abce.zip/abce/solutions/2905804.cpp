#include <fstream>
#include <iostream>

using namespace std ;

ifstream fin("abce.in") ;
ofstream fout("abce.out") ;

class Treap {
public :
    int info ;
    int priority ;
    Treap *left, *right ;
    Treap(int info) {
        this -> info = info ;
        this -> priority = rand() * rand() ;
        this -> left = this -> right = nullptr ;
    }
    Treap* rightRotate(Treap*&) ;
    Treap* leftRotate(Treap*&) ;
    Treap* Search(Treap*, int);
    Treap* Insert(Treap*&, int);
    Treap* Delete(Treap*&, int);
    int Succesor(Treap*, int);
    int Predecesor(Treap*, int);
    void Interval(Treap*, int, int) ;
    void Inorder(Treap*);
    int getInfo();

};

int Treap::getInfo() {
    return info ;
}

Treap* Treap::rightRotate(Treap *&root) {
    Treap *leftSubtree = root -> left ;
    Treap *rightSubtreeOfLeftSubtree = leftSubtree -> right;

    leftSubtree -> right = root;
    root -> left = rightSubtreeOfLeftSubtree ;

    return leftSubtree;

}

Treap* Treap::leftRotate(Treap *&root) {
    Treap *rightSubtree = root -> right ;
    Treap *leftSubtreeOfRightSubtree = rightSubtree -> left ;

    rightSubtree -> left = root ;
    root -> right = leftSubtreeOfRightSubtree ;

    return rightSubtree ;

}

Treap* Treap::Search(Treap *node, int value) {
    if (node == NULL || node->info == value)
        return node ;
    if ( node->info > value )
        return Search(node->left, value) ;
    return Search(node->right, value) ;
}

Treap* Treap::Insert(Treap *&node, int value) {
    if ( node == NULL ) {
        node = new Treap(value) ;
        return node ;
    }
    if (value <= node -> info) {
        node -> left = Insert(node -> left, value) ;
        if (node -> left -> priority > node -> priority)
            node = rightRotate(node) ;
    }
    else {
        node -> right = Insert(node -> right, value) ;
        if (node -> right -> priority > node -> priority)
            node = leftRotate(node) ;
    }
    return node ;
}

Treap* Treap::Delete(Treap *&node, int value) {
    if ( node == NULL )
        return node ;

    if ( value < node -> info )
        node -> left = Delete(node -> left, value) ;
    else if ( value > node -> info )
        node -> right = Delete(node -> right, value) ;

    else if ( node -> right == NULL ) {
        Treap *leftSubtree = node -> left ;
        delete(node);
        node = leftSubtree ;
    }
    else if ( node -> left == NULL ) {
        Treap *rightSubtree = node -> right ;
        delete(node) ;
        node = rightSubtree ;
    }

    else if ( node -> left -> priority < node -> right -> priority ){
        node = leftRotate(node) ;
        node -> left = Delete(node -> left, value) ;
    }
    else {
        node = rightRotate(node) ;
        node -> right = Delete(node -> right, value);
    }
    return node;
}

int Treap::Succesor(Treap *root, int value) {
    if ( root == NULL )
        return INT32_MAX;
    if ( root -> info < value )
        return Succesor(root -> right, value) ;
    return min(root -> info, Succesor(root -> left, value)) ;
}

int Treap::Predecesor(Treap *root,  int value) {
    if ( root == NULL )
        return INT32_MIN ;
    if ( root -> info > value )
        return Predecesor(root -> left, value) ;
    return max(root -> info, Predecesor(root -> right, value)) ;
}

void Treap::Interval(Treap *root, int left, int right) {
    //similar cu parcurgera in inordine
    if ( root == nullptr )
        return;
    Interval(root -> left, left, right);
    if ( root -> info >= left && root -> info <= right )
        fout << root -> info << " " ;
    Interval( root -> right, left, right) ;
}

int main() {
    srand(time(NULL));
    Treap *root = NULL ;
    int numberOfOperations, operation, x ;
    fin >> numberOfOperations ;
    for ( int i = 1 ; i <= numberOfOperations ; i ++) {
        fin >> operation ;
        if ( operation == 1 ) {
            fin >> x ;
            root = root ->Insert(root,x) ;
        }
        else if ( operation == 2 ) {
            fin >> x ;
            Treap *res = res ->Search(root, x) ;
            if ( res != NULL )
                root = root ->Delete(root,x) ;
        }
        else if ( operation == 3 ) {
            fin >> x ;
            Treap *res = res ->Search(root,x) ;
            if ( res == NULL )
                fout << 0 << endl ;
            else
                fout << 1 << endl ;
        }
        else if ( operation == 4 ) {
            fin >> x ;
            fout << root ->Predecesor(root,x) << endl ;
        }
        else if ( operation == 5 ) {
            fin >> x ;
            fout << root ->Succesor(root,x) << endl ;
        }
        else {
            int left, right;
            fin >> left >> right ;
            root -> Interval(root, left, right);
            fout << '\n' ;
        }

    }
}
