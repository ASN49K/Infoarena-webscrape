#include <bits/stdc++.h>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

struct BTreeNode {
  int *keys;      // An array of keys
  int t;          // Minimum degree (defines the range for number of keys)
  BTreeNode **C;  // An array of child pointers
  int n;          // Current number of keys
  bool leaf;      // Is true when node is leaf. Otherwise false

  BTreeNode(int t1, bool leaf1) {
    t = t1;
    leaf = leaf1;

    keys = new int[2 * t - 1];
    C = new BTreeNode *[2 * t];

    n = 0;
  }

  void traverse() {
    int i;
    for (i = 0; i < n; i++) {
      if (leaf == false) C[i]->traverse();
      cout << keys[i] << " ";
    }
    if (leaf == false) C[i]->traverse();
  }

  BTreeNode *search(int k) {
    int i = 0;
    while (i < n && k > keys[i]) i++;
    if (keys[i] == k) return this;
    if (leaf == true) return NULL;
    return C[i]->search(k);
  }

  // A function that returns the index of the first key that is greater
  // or equal to k
  int findKey(int k) {
    int idx = 0;
    while (idx < n && keys[idx] < k) ++idx;
    return idx;
  }

  void insertNonFull(int k) {
    int i = n - 1;

    if (leaf == true) {
      // The following loop does two things
      // a) Finds the location of new key to be inserted
      // b) Moves all greater keys to one place ahead
      while (i >= 0 && keys[i] > k) {
        keys[i + 1] = keys[i];
        i--;
      }

      keys[i + 1] = k;
      n = n + 1;
    } else  // If this node is not leaf
    {
      while (i >= 0 && keys[i] > k) i--;

      if (C[i + 1]->n == 2 * t - 1) {
        splitChild(i + 1, C[i + 1]);

        if (keys[i + 1] < k) i++;
      }
      C[i + 1]->insertNonFull(k);
    }
  }

  void splitChild(int i, BTreeNode *y) {
    BTreeNode *z = new BTreeNode(y->t, y->leaf);
    z->n = t - 1;
    for (int j = 0; j < t - 1; j++) z->keys[j] = y->keys[j + t];

    if (y->leaf == false) {
      for (int j = 0; j < t; j++) z->C[j] = y->C[j + t];
    }

    y->n = t - 1;

    for (int j = n; j >= i + 1; j--) C[j + 1] = C[j];

    C[i + 1] = z;

    for (int j = n - 1; j >= i; j--) keys[j + 1] = keys[j];

    keys[i] = y->keys[t - 1];

    n = n + 1;
  }

  void remove(int k) {
    int idx = findKey(k);

    if (idx < n && keys[idx] == k) {
      if (leaf)
        removeFromLeaf(idx);
      else
        removeFromNonLeaf(idx);
    } else {
      if (leaf) {
        cout << "The key " << k << " is does not exist in the tree\n";
        return;
      }

      bool flag = ((idx == n) ? true : false);

      if (C[idx]->n < t) fill(idx);

      if (flag && idx > n)
        C[idx - 1]->remove(k);
      else
        C[idx]->remove(k);
    }
    return;
  }

  void removeFromLeaf(int idx) {
    for (int i = idx + 1; i < n; ++i) keys[i - 1] = keys[i];

    n--;

    return;
  }

  void removeFromNonLeaf(int idx) {
    int k = keys[idx];

    if (C[idx]->n >= t) {
      int pred = getPred(idx);
      keys[idx] = pred;
      C[idx]->remove(pred);
    } else if (C[idx + 1]->n >= t) {
      int succ = getSucc(idx);
      keys[idx] = succ;
      C[idx + 1]->remove(succ);
    } else {
      merge(idx);
      C[idx]->remove(k);
    }
    return;
  }

  // A function to get predecessor of keys[idx]
  int getPred(int idx) {
    BTreeNode *cur = C[idx];
    while (!cur->leaf) cur = cur->C[cur->n];
    return cur->keys[cur->n - 1];
  }

  int getSucc(int idx) {
    BTreeNode *cur = C[idx + 1];
    while (!cur->leaf) cur = cur->C[0];
    return cur->keys[0];
  }

  // A function to fill up the child node present in the idx-th
  // position in the C[] array if that child has less than t-1 keys
  // A function to fill child C[idx] which has less than t-1 keys
  void fill(int idx) {
    // If the previous child(C[idx-1]) has more than t-1 keys, borrow a key
    // from that child
    if (idx != 0 && C[idx - 1]->n >= t) borrowFromPrev(idx);

    // If the next child(C[idx+1]) has more than t-1 keys, borrow a key
    // from that child
    else if (idx != n && C[idx + 1]->n >= t)
      borrowFromNext(idx);

    // Merge C[idx] with its sibling
    // If C[idx] is the last child, merge it with its previous sibling
    // Otherwise merge it with its next sibling
    else {
      if (idx != n)
        merge(idx);
      else
        merge(idx - 1);
    }
    return;
  }

  void borrowFromPrev(int idx) {
    BTreeNode *child = C[idx];
    BTreeNode *sibling = C[idx - 1];
    for (int i = child->n - 1; i >= 0; --i) child->keys[i + 1] = child->keys[i];

    if (!child->leaf) {
      for (int i = child->n; i >= 0; --i) child->C[i + 1] = child->C[i];
    }
    child->keys[0] = keys[idx - 1];

    // Moving sibling's last child as C[idx]'s first child
    if (!child->leaf) child->C[0] = sibling->C[sibling->n];

    keys[idx - 1] = sibling->keys[sibling->n - 1];

    child->n += 1;
    sibling->n -= 1;

    return;
  }

  void borrowFromNext(int idx) {
    BTreeNode *child = C[idx];
    BTreeNode *sibling = C[idx + 1];

    child->keys[(child->n)] = keys[idx];

    if (!(child->leaf)) child->C[(child->n) + 1] = sibling->C[0];

    keys[idx] = sibling->keys[0];

    for (int i = 1; i < sibling->n; ++i)
      sibling->keys[i - 1] = sibling->keys[i];

    if (!sibling->leaf) {
      for (int i = 1; i <= sibling->n; ++i) sibling->C[i - 1] = sibling->C[i];
    }

    child->n += 1;
    sibling->n -= 1;

    return;
  }

  void merge(int idx) {
    BTreeNode *child = C[idx];
    BTreeNode *sibling = C[idx + 1];

    child->keys[t - 1] = keys[idx];

    for (int i = 0; i < sibling->n; ++i) child->keys[i + t] = sibling->keys[i];

    if (!child->leaf) {
      for (int i = 0; i <= sibling->n; ++i) child->C[i + t] = sibling->C[i];
    }

    for (int i = idx + 1; i < n; ++i) keys[i - 1] = keys[i];
    for (int i = idx + 2; i <= n; ++i) C[i - 1] = C[i];

    child->n += sibling->n + 1;
    n--;

    delete (sibling);
    return;
  }
};

struct BTree {
  BTreeNode *root;  // Pointer to root node
  int t;            // Minimum degree

  BTree(int _t) {
    root = NULL;
    t = _t;
  }

  void traverse() {
    if (root != NULL) root->traverse();
  }

  BTreeNode *search(int k) { return (root == NULL) ? NULL : root->search(k); }

  void insert(int k) {
    if (root == NULL) {
      root = new BTreeNode(t, true);
      root->keys[0] = k;
      root->n = 1;
    } else {
      if (root->n == 2 * t - 1) {
        BTreeNode *s = new BTreeNode(t, false);

        s->C[0] = root;

        s->splitChild(0, root);
        int i = 0;
        if (s->keys[0] < k) i++;
        s->C[i]->insertNonFull(k);

        root = s;
      } else
        root->insertNonFull(k);
    }
  }

  void remove(int k) {
    if (!root) {
      return;
    }

    root->remove(k);
    if (root->n == 0) {
      BTreeNode *tmp = root;
      if (root->leaf)
        root = NULL;
      else
        root = root->C[0];
      delete tmp;
    }
    return;
  }

  int getSuccessorValue(int x) {
    BTreeNode *current = root;
    int successor = -1;

    while (current != NULL) {
      int i = 0;

      // Find the first key greater than or equal to x
      while (i < current->n && current->keys[i] < x) i++;

      // If a valid key is found in this node, update the successor
      if (i < current->n) {
        successor = current->keys[i];
      }

      // If it's a leaf node, stop. Otherwise, go to the appropriate child
      current = current->leaf ? NULL : current->C[i];
    }

    return successor;
  }

  int getPredecessorValue(int x) {
    BTreeNode *current = root;
    int predecessor = -1;

    while (current != NULL) {
      int i = 0;
      while (i < current->n && current->keys[i] < x) {
        predecessor = current->keys[i];
        i++;
      }
      if (i < current->n && current->keys[i] == x) return current->keys[i];
      current = current->leaf ? NULL : current->C[i];
    }

    return predecessor;
  }
};

BTree *btree;

// BOILERPLATE START
void init();
void add(int x);
void erase(int x);
int exists(int x);
int succesor(int x);
int predecesor(int x);
void parcurgere(int x, int y);
int main() {
  std::ios_base::sync_with_stdio(false);
  f.tie(0);
  int _, op, x, y;
  f >> _;
  init();
  do {
    f >> op >> x;
    switch (op) {
      case 1:
        add(x);
        break;
      case 2:
        erase(x);
        break;
      case 3:
        cout << exists(x) << '\n';
        break;
      case 5:
        cout << succesor(x) << '\n';
        break;
      case 4:
        cout << predecesor(x) << '\n';
        break;
      case 6:
        cin >> y;
        parcurgere(x, y);
        break;
    }
  } while (_ -= 1);
  return 0;
}
// BOILERPLATE END

void init() {
  int t = 3;  // Minimum degree
  btree = new BTree(t);
}

void add(int x) { btree->insert(x); }

void erase(int x) { btree->remove(x); }

int exists(int x) { return (btree->search(x) != NULL); }

int succesor(int x) { return btree->getSuccessorValue(x); }

int predecesor(int x) { return btree->getPredecessorValue(x); }

void parcurgere(int x, int y) {
  BTreeNode *current = btree->root;
  std::vector<int> result;

  std::function<void(BTreeNode *)> traverseInRange = [&](BTreeNode *node) {
    if (!node) return;
    for (int i = 0; i < node->n; ++i) {
      if (!node->leaf) traverseInRange(node->C[i]);
      if (node->keys[i] >= x && node->keys[i] <= y)
        result.push_back(node->keys[i]);
    }
    if (!node->leaf) traverseInRange(node->C[node->n]);
  };

  traverseInRange(current);
  for (int key : result) g << key << ' ';
  g << '\n';
}
