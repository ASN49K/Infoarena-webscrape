#include <iostream>
#include <fstream>

std::ifstream f("abce.in");
std::ofstream g("abce.out");

int val, q, t, st, dr;

struct Node{
    int data;
    Node *parent;
    Node *left;
    Node *right;
    bool color; //true=red, false=black
};

Node* newNode(int data){
    Node* node = new Node;
    node->data= data;
    node->parent = nullptr;
    node->left = nullptr;
    node->right = nullptr;
    node->color = true;

    return node;
}

Node* root = nullptr;

Node* cauta(Node* root, int data){
    if(root == nullptr || root->data == data) {/*std::cout<<"gasit "<<data<<"\n"*/;return root;}

    if(data < root->data) return cauta(root->left, data);
    if(data >= root->data) return cauta(root->right, data);

    return root;
}

//inserare pas 1
Node* adauga(Node* root, Node* nou){
    if(root ==nullptr)
        return nou;

    if( nou->data < root->data ){
        root->left = adauga( root->left, nou);
        root->left->parent = root;
    }
    else if( nou->data > root->data ){
        root->right = adauga( root->right, nou);
        root->right->parent = root;
    }

    return root;
}

void rotate_dr( Node* nou ){
    Node* stanga = nou->left;
    nou->left = stanga->right;

    if(nou->left) nou->left->parent = nou;

    stanga->parent = nou->parent;

    if(!nou->parent) root = stanga;
    else if(nou == nou->parent->left)
        nou->parent->left = stanga;
    else nou->parent->right = stanga;

    stanga->right = nou;
    nou->parent = stanga;
}

void rotate_st( Node* nou ){
    Node* dreapta = nou->right;
    nou->right = dreapta->left;

    if(nou->right) nou->right->parent = nou;

    dreapta->parent = nou->parent;

    if(!nou->parent) root = dreapta;
    else if(nou == nou->parent->left)
        nou->parent->left = dreapta;
    else nou->parent->right = dreapta;

    dreapta->left = nou;
    nou->parent =dreapta;
}

//inserare pas 2
void repara_adauga(Node* root, Node* nou){
    Node* p = nullptr;
    Node* gp = nullptr;

    while((nou !=root) && nou->color && nou->parent->color){
        p = nou->parent;
        gp = nou->parent->parent;

        if(p == gp->left){ // A parintele e copilul din stanga
            Node* u = gp->right;

            if(u != nullptr && u->color){ // unchiul e rosu
                gp->color = true;
                p->color = false;
                u->color = false;
                nou = gp;
            }
            else{ // unchiul e negru
                if(nou == p->right){ //right left
                    rotate_st(p);
                    nou = p;
                    p = nou->parent;
                }
                else{
                    rotate_dr(gp); // left left
                    bool c = p->color;
                    p->color = gp->color;
                    gp->color = c;
                    nou = p;
                }
            }
        }
        else{ // B parintele e copilul din dreapta
            Node* u = gp->left;

            if(u != nullptr && u->color){ // modificat //unchiul e rosu
                gp->color = true;
                p->color = false;
                u->color = false;
                nou = gp;
            }
            else{
                if(nou == p->left){ //left right
                    rotate_dr(p);
                    nou = p;
                    p = nou->parent;
                }
                else{
                    rotate_st(gp); //right right
                    bool c = p->color;
                    p->color = gp->color;
                    gp->color = c;
                    nou = p;
                }
            }
        }
    }

    root->color = false;
}

void inorder(Node* root){
    if(root == nullptr) return;

    inorder(root->left);
    std::cout<<root->data<<" ";
    inorder(root->right);
}

Node* succesor( Node* root){
    Node* nod = root;

    while(nod->left != nullptr) nod = nod->left;

    return nod;
}

Node* frate(Node* nod){
    if( nod->parent == nullptr ) return nullptr;

    if(nod == nod->parent->left) return nod->parent->right;

    return nod->parent->left;
}

void fix_negru(Node* nod){
    if(nod == root) return;

    Node* f = frate(nod);
    Node* p = nod->parent;

    if(f == nullptr) fix_negru(p);
    else{
        if(f->color){ //fratele e rosu
            p->color = true;
            f->color = false;

            if(f == f->parent->left) rotate_dr(p); //////////////
            else rotate_st(p);

            fix_negru(nod);
        }
        else{ //fratele e negru
            if((f->left != nullptr && f->left->color) || (f->right != nullptr && f->right->color)){ //are cel putin un copil rosu
                if(f->left != nullptr and f->left->color){
                    if(f == f->parent->left){ //left left
                        f->left->color = f->color;
                        f->color=p->color;
                        rotate_dr(p);
                    }
                    else{
                        f->left->color = p->color; //right left
                        rotate_dr(f);
                        rotate_st(p);
                    }
                }
                else{
                    if(f == f->parent->left){ //left right
                        f->right->color = p->color;
                        rotate_st(f);
                        rotate_dr(p);
                    }
                    else{ //right right
                        f->right->color = f->color;
                        f->color = p->color;
                        rotate_st(p);
                    }
                }
                p->color = false;
            }
            else{ //copii fratelui sunt negrii
                f->color = true;
                if(!p->color) fix_negru(p);
                else p->color = false;
            }
        }
    }
}

void sterge(int val){
    Node* nod = cauta(root, val);

    if(nod != nullptr){
        Node* s;

        if(nod->left != nullptr && nod->right != nullptr) s =succesor(nod->right); //cand nodul are 2 copii
        else if(nod->left == nullptr && nod->right == nullptr) s = nullptr;
        else if(nod->left != nullptr) s = nod->left;
        else  s = nod->right;

        bool negru;
        if(( s == nullptr || !s->color) && !nod->color) negru = true;
        else negru = false;

        Node* p = nod->parent;

        if( s == nullptr){ //nodul nostru e frunza
            if(nod == root) root = nullptr;
            else{
                if(negru) fix_negru(nod);
                else{
                    Node* f = frate(nod);
                    if(f != nullptr) f->color = true;
                }

                if(nod == nod->parent->left) nod->parent->left = nullptr;
                else nod->parent->right = nullptr;
            }
            delete nod;
            return;
        }

        if(nod->left == nullptr || nod->right == nullptr){ //nodul are cel putin un copil
            if(nod == root){
                nod->data = s->data;
                nod->left = nullptr;
                nod->right = nullptr;
                delete s;
            }
            else{
                if(nod == nod->parent->left) p->left = s;
                else p->right = s;
                delete nod;

                s->parent = p;

                if(negru)fix_negru(s);
                else s->color = false;
            }

            return;
        }

        int aux;
        aux = s->data;
        s->data = nod->data;
        nod->data = aux;
        sterge(s->data);
    }
}

int cauta_pre(Node* root, int val){
    int nr_aux=0;
    while(root != nullptr){
        if( root->data == val)
            return val;
        if( root->data > val)
            root = root->left;
        else{
            nr_aux = root->data;
            root = root->right;
        }
    }
    return nr_aux;
}

int cauta_suc(Node* root, int val){
    int nr_aux=0;
    while(root != nullptr){
        if( root->data == val)
            return val;
        if( root->data < val)
            root = root->right;
        else{
           // std::cout<<nr_aux;
            nr_aux = root->data;
            root = root->left;
        }
    }
    return nr_aux;
}

void sortare(Node* root, int st, int dr){
    int val = cauta_suc(root, st);
    while(val<dr){
        g<<val<<" ";
        val = cauta_suc(root, val+1);
    }
    if(val==dr) g<<val<<"\n";
}

int main() {
    f>>q;
    while(q--){
        f>>t;

        if(t==1){ f>>val; Node* nou= newNode(val); root=adauga(root, nou); repara_adauga(root, nou);}

        if(t==2){ f>>val; sterge(val);}

        if(t==3){ f>>val; if(cauta(root, val)==nullptr)g<<0<<"\n"; else g<<1<<"\n";}

        if(t==4){ f>>val; g<<cauta_pre(root, val)<<"\n";}

        if(t==5){ f>>val; g<<cauta_suc(root, val)<<"\n";}

        if(t==6){f>>st>>dr; st = cauta_suc(root, st); dr = cauta_pre(root, dr); sortare(root, st, dr);}

    }

    //inorder(root);

    return 0;
}
