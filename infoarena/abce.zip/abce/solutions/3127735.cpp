#include <iostream>
#include <random>
#include <fstream>

using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class Node
{
public:
    int key;
    int priority;
    Node *left, *right;

    Node(int key)
    {
        this->key = key;
        this->priority = rand() % 65535;
        this->left = nullptr;
        this->right = nullptr;
    }
};

class Treap
{
private:
    Node *root;

    Node *insertNode(Node *root, int key)
    {
        if (root == nullptr)
        {
            return new Node(key);
        }

        if (key < root->key)
        {
            root->left = insertNode(root->left, key);

            if (root->left->priority > root->priority)
            {
                root = rotateRight(root);
            }
        }
        else
        {
            root->right = insertNode(root->right, key);

            if (root->right->priority > root->priority)
            {
                root = rotateLeft(root);
            }
        }

        return root;
    }

    Node *findNode(Node *root, int key)
    {
        if (root == nullptr)
        {
            return nullptr;
        }

        if (key == root->key)
        {
            return root;
        }
        else if (key < root->key)
        {
            return findNode(root->left, key);
        }
        else
        {
            return findNode(root->right, key);
        }
    }

    Node *deleteNode(Node *root, int key)
    {
        if (root == nullptr)
        {
            return root;
        }

        if (key < root->key)
        {
            root->left = deleteNode(root->left, key);
        }
        else if (key > root->key)
        {
            root->right = deleteNode(root->right, key);
        }
        else
        {
            if (root->left == nullptr)
            {
                Node *temp = root->right;
                delete root;
                root = temp;
            }
            else if (root->right == nullptr)
            {
                Node *temp = root->left;
                delete root;
                root = temp;
            }
            else
            {
                if (root->left->priority > root->right->priority)
                {
                    root = rotateRight(root);
                    root->right = deleteNode(root->right, key);
                }
                else
                {
                    root = rotateLeft(root);
                    root->left = deleteNode(root->left, key);
                }
            }
        }

        return root;
    }

    Node *rotateRight(Node *root)
    {
        Node *newRoot = root->left;
        root->left = newRoot->right;
        newRoot->right = root;
        return newRoot;
    }

    Node *rotateLeft(Node *root)
    {
        Node *newRoot = root->right;
        root->right = newRoot->left;
        newRoot->left = root;
        return newRoot;
    }

public:
    Treap()
    {
        this->root = nullptr;
    }

    void insert(int key)
    {
        this->root = insertNode(this->root, key);
    }

    Node *find(int key)
    {
        return findNode(this->root, key);
    }

    void remove(int key)
    {
        this->root = deleteNode(this->root, key);
    }

    void printInOrder(Node *root)
    {
        if (root == nullptr)
        {
            return;
        }

        printInOrder(root->left);
        cout << root->key << " ";
        printInOrder(root->right);
    }

    void printInOrder()
    {
        printInOrder(this->root);
        cout << endl;
    }
};

int main()
{
    Treap t;

    int Q, choice, nr;
    fin >> Q;
    for (int i = 1; i <= Q; i++)
    {
        fin >> choice;
        switch (choice)
        {
        case 1:
            fin >> nr;
            t.insert(nr);
            break;

        case 2:
            fin >> nr;
            t.remove(nr);
            break;

        case 3:
            fin >> nr;
            Node *found = t.find(nr);
            if (found != NULL)
                fout << "1\n";
            else
                fout << "0\n";
            break;
        }
    }

    // t.insert(5);
    // t.insert(3);
    // t.insert(7);
    // t.insert(2);
    // t.insert(4);
    // t.insert(6);
    // t.insert(8);

    // cout << "In-order traversal: ";
    // t.printInOrder();

    // Node *foundNode = t.find(7);
    // if (foundNode != nullptr)
    // {
    //     cout << "Found node with key " << foundNode->key << endl;
    // }
    // else
    // {
    //     cout << "Node not found" << endl;
    // }

    // t.remove(4);

    // cout << "In-order traversal: ";
    // t.printInOrder();

    return 0;
}