#include <bits/stdc++.h>
#ifdef BLAT
    #include "debug/debug.hpp"
#else
    #define debug(x...)
#endif

using namespace std;

ifstream in ("abce.in");
ofstream out ("abce.out");

class SplayTree {
private:
    struct Node {
        int child[2], parent, value;
        Node() : parent(0) {
            child[0] = child[1] = 0;
            value = 0;
        }
    };
    vector <Node> tree;
    vector <int> freeindices;

    void setChild(int x, int y, bool dir) {
        tree[x].child[dir] = y;
        if (y)
            tree[y].parent = x;
    }

    int direction(int x) {
        int parent = tree[x].parent;

        if (parent == 0) return -1;
        if (tree[parent].child[0] == x) return 0;
        if (tree[parent].child[1] == x) return 1;

        return -1; // LCT stuff, if tree[parent] has no child x
    }

    void rotate(int x) {
        int y = tree[x].parent, z = tree[y].parent;
        int dx = direction(x), dy = direction(y);

        setChild(y, tree[x].child[dx ^ 1], dx);
        setChild(x, y, dx ^ 1);
        if (dy != -1) setChild(z, x, dy);

        tree[x].parent = z;
    }

    int splay(int x) {
        while (direction(x) != -1) {
            int y = tree[x].parent;
            int dx = direction(x), dy = direction(y);

            if (dy != -1) {
                if (dx == dy) rotate(y); // zig-zig
                else rotate(x); // zig-zag
            }
            rotate(x);
        }

        return root = x;
    }

    void range(int node, int l, int r) {
        if (node == 0) return;
        
        range(tree[node].child[0], l, r);
        if (l <= tree[node].value && tree[node].value <= r) 
            out << tree[node].value << ' ';
        range(tree[node].child[1], l, r);
    }

public:
    int root;
    SplayTree(int n) : tree(1 + n), freeindices(n) {
        iota(freeindices.begin(), freeindices.end(), 1);
        root = 0;
    }

    int valueFromKey(int key) {
        return tree[key].value;
    }

    void print(int l = 0, int r = INT_MAX) {
        range(root, l, r);
        out << '\n';
    } 

    int insert(int value) {
        int key = freeindices.back(); freeindices.pop_back(); 
        tree[key].value = value;

        int x = smallerEqual(tree[key].value, root); 

        if (x) {
            int y = tree[x].child[1];
            setChild(x, 0, 1); // right son of x is 0
            setChild(key, x, 0); // left son of key is x
            setChild(key, y, 1); // right son of key is the old right son of x
        } else
            setChild(key, root, 1);

        return root = key; // key is root
    }

    int smallerEqual(int value, int node) { // returns key to the node with the largest value smaller or equal than value
        if (node == 0) return node;
        if (tree[node].value > value)
            return smallerEqual(value, tree[node].child[0]);
        return smallerEqual(value, tree[node].child[1]) ?: splay(node);
    }

    int greaterEqual(int value, int node) { // returns key to the node with the smallest value larger or equal than value
        if (node == 0) return node;
        if (tree[node].value < value)
            return greaterEqual(value, tree[node].child[1]);
        return greaterEqual(value, tree[node].child[0]) ?: splay(node);
    }

    bool find(int value) {
        int x = smallerEqual(value, root);
        return tree[x].value == value;
    }

    int erase(int value) { // works only if value is present in the tree
        int x = smallerEqual(value, root);
        Node &node = tree[x];
        int &left = node.child[0], &right = node.child[1];

        tree[left].parent = tree[right].parent = 0;
        if (!left) // no left child
            root = right;
        else {
            int y = smallerEqual(value, left);
            setChild(y, right, 1);
        }

        left = right = 0;
        node.value = 0;
        freeindices.push_back(x);

        return x;
    }
};

int main() {
    int q;
    in >> q;
    SplayTree tree(q);

    while (q--) {
        int t, x, y;
        in >> t;
        switch (t) {
            case 1:
                in >> x;
                tree.insert(x);
                break;

            case 2:
                in >> x;
                tree.erase(x);
                break;

            case 3:
                in >> x;
                out << tree.find(x) << '\n';
                break;
            
            case 4:
                in >> x;
                out << tree.valueFromKey(tree.smallerEqual(x, tree.root)) << '\n';
                break;
            
            case 5:
                in >> x;
                out << tree.valueFromKey(tree.greaterEqual(x, tree.root)) << '\n';
                break;
            
            case 6:
                in >> x >> y;
                assert(x <= y);
                tree.print(x, y);
                break;
        }
    }
    in.close();
    out.close();
    return 0;
}
