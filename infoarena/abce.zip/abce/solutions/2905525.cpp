#include <fstream>

#define intmin -1000000001
#define intmax 1000000000

using namespace std;

struct Node {
    long long key;
    Node *left;
    Node *right;
    long long height;
} *root;
long long q, op, x, y;

ifstream fin("abce.in");
ofstream fout("abce.out");

 long long height(Node *&n) {
    return n == nullptr ? 0 : n->height;
}

Node *newNode(long long &key) {
    Node *node = new Node();
    node->key = key;
    node->left = nullptr;
    node->right = nullptr;
    node->height = 1; // frunza

    return node;
}

 long long getBalance(Node *&n) {
    if (n == nullptr) {
        return 0;
    }

    return height(n->left) - height(n->right);
}

 Node *rightRotate(Node *y) {
    Node *x = y->left;
    Node *T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = 1 + max(height(y->left), height(y->right));
    x->height = 1 + max(height(x->left), height(x->right));

    return x;
}

 Node *leftRotate(Node *x) {
    Node *y = x->right;
    Node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = 1 + max(height(x->left), height(x->right));
    y->height = 1 + max(height(y->left), height(y->right));

    return y;
}

void insert(Node *&node, long long &key) {
    // BST
    if (node == nullptr) {
        node = newNode(key);
    }

    if (key < node->key) {
        insert(node->left, key);
    } else if (key > node->key) {
        insert(node->right, key);
    } else {
        return;
    }

    // Actualizare height
    node->height = 1 + max(height(node->left), height(node->right));

    // Balanta
    long long balance = getBalance(node);
    // LL
    if (balance > 1 && key < (node->left->key)) {
        node = rightRotate(node);
//        {
//            Node *a = node->left;
//            Node *T2 = a->right;
//
//            a->right = node;
//            node->left = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }

        return;
    }
    // RR
    if (balance < -1 && key > (node->right->key)) {
        node = leftRotate(node);

//        {
//            Node *a = node->right;
//            Node *T2 = a->left;
//
//            a->left = node;
//            node->right = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }
        return;
    }
    // LR
    if (balance > 1 && key > node->left->key) {
        node->left = leftRotate(node->left);
//        {
//            Node *a = node->left;
//            Node *T2 = a->right;
//
//            a->right = node;
//            node->left = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }
        node = rightRotate(node);
//        {
//            Node *a = node->left;
//            Node *T2 = a->right;
//
//            a->right = node;
//            node->left = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }
        return;
    }
    // RL
    if (balance < -1 && key < (node->right->key)) {
        node->right = rightRotate(node->right);
//        {
//            Node *a = node->left;
//            Node *T2 = a->right;
//
//            a->right = node;
//            node->left = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }
        node = leftRotate(node);
//        {
//            Node *a = node->left;
//            Node *T2 = a->right;
//
//            a->right = node;
//            node->left = T2;
//
//            node->height = 1 + max(height(node->left), height(node->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            node = a;
//        }
        return;
    }
}


bool search(Node *&node, long long &key) {
    if (node == nullptr)
        return false;

    if (node->key == key)
        return true;

    if (node->key > key)
        return search(node->left, key);
    else
        search(node->right, key);

    return false;
}

Node *minKey(Node *&node) {
    if (node == nullptr || node->left == nullptr)
        return node;

    return minKey(node);
//    if(root == nullptr)
//        return root;
//
//    Node *tmp = root;
//
//    while(tmp->left != nullptr)
//        tmp = tmp->left;
//
//    return tmp;
}

void deleteNode(Node *&node, long long &key) {
    if (node == nullptr)
        return;

    if (node->key < key) {
        deleteNode(node->right, key);
    } else if (node->key > key) {
        deleteNode(node->left, key);
    } else {
        Node *tmp;

        if (node->left == nullptr || node->right == nullptr) { // Maxim 1 copil
            tmp = node->right == nullptr ? node->left : node->right;

            // Fara copii
            if (tmp == nullptr) {
//                tmp = root;
                node = nullptr;
            } else {
                // 1 copil
                node->key = tmp->key;
                node->left = tmp->left;
                node->right = tmp->right;

                delete tmp;
            }
        } else { // 2 copii
            tmp = minKey(node->right);
            if (tmp == nullptr)
                return;
            node->key = tmp->key;
            if (node->right != nullptr)
                deleteNode(node->right, tmp->key);
        }
    }

    // Nu mai sunt noduri
    if (node == nullptr)
        return;

    node->height = 1 + max(height(node->left), height(node->right));
    // Balanta
    long long balance = getBalance(node);
    // LL
    if (balance > 1 && key < (getBalance(node->left))) {
        node = rightRotate(node);
//        {
//            Node *a = root->left;
//            Node *T2 = a->right;
//
//            a->right = root;
//            root->left = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        return;
    }
    // RR
    if (balance < -1 && key > (getBalance(node->right))) {
        node = leftRotate(node);
//        {
//            Node *a = root->right;
//            Node *T2 = a->left;
//
//            a->left = root;
//            root->right = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        return;
    }
    // LR
    if (balance > 1 && key > (getBalance(node->left))) {
        node->left = leftRotate(node->left);
//        {
//            Node *a = root->right;
//            Node *T2 = a->left;
//
//            a->left = root;
//            root->right = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        node = rightRotate(node);
//        {
//            Node *a = root->left;
//            Node *T2 = a->right;
//
//            a->right = root;
//            root->left = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        return;
    }
    // RL
    if (balance < -1 && key < (getBalance(node->right))) {
        node->right = rightRotate(node->right);
//        {
//            Node *a = root->left;
//            Node *T2 = a->right;
//
//            a->right = root;
//            root->left = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        node = leftRotate(node);
//        {
//            Node *a = root->right;
//            Node *T2 = a->left;
//
//            a->left = root;
//            root->right = T2;
//
//            root->height = 1 + max(height(root->left), height(root->right));
//            a->height = 1 + max(height(a->left), height(a->right));
//
//            root = a;
//        }
        return;
    }
}

long long op4(Node *&node, long long &key) {
    if (node == nullptr)
        return intmin;

    if (node->key == key)
        return key;
    if (node->key < key)
        return max(node->key, op4(node->right, key));
    else
        return op4(node->left, key);
}

long long op5(Node *&node, long long &key) {
    if (node == nullptr)
        return intmax;

    if (node->key == key)
        return key;
    if (node->key > key)
        return min(node->key, op5(node->left, key));
    else
        return op5(node->right, key);
}


void inorder(Node *&node, long long &x, long long &y) {
    if (node == nullptr)
        return;

    inorder(node->left, x, y);
    if (node->key >= x && node->key <= y) fout << node->key << " ";
    inorder(node->right, x, y);
}


int main() {
//    Node *root = nullptr;
    root = nullptr;

    fin >> q;

    for (unsigned int i = 0; i < q; ++i) {
        fin >> op;
        switch (op) {
            case 1: {
                fin >> x;
                insert(root, x);

                break;
            }
            case 2: {
                fin >> x;
                deleteNode(root, x);

                break;
            }

            case 3: {
                fin >> x;
                fout << (search(root, x) ? '1' : '0') << '\n';
                break;
            }

            case 4: {
                fin >> x;
                fout << op4(root, x) << '\n';
                break;
            }

            case 5: {
                fin >> x;
                fout << op5(root, x) << '\n';
                break;
            }
            case 6: {
                fin >> x >> y;

                inorder(root, x, y);
                fout << '\n';

                break;
            }
        }
    }


    return 0;
}