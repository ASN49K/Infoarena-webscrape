#include <iostream>
#include <fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class Node{
    private:
        int info;
        Node* left;
        Node* right;
    
    public:
        Node();
        Node(int value);
        bool isLeaf();
    
        friend class BinarySearchTree;

};
 
class BinarySearchTree{
    private:
        Node* root;
        void InsertRecursiv_(Node* & p, int value);
        bool CautareRecursiv_(Node* & p, int value);
        void StergereRecursiv_(Node* & p, int value);
        void StergAux(Node* & p, Node* & P);
        void cerinta6_(Node* currentNode, int x, int y);

    public:
        BinarySearchTree();
        void Insert(int value);
        void InsertRecursiv(int value);
        void ParcurgereInordine();
        void ParcurgereInordine(Node* currentNode);
        bool Cautare(int value);
        bool CautareRecursiv(int value);
        void Stergere(int value);
        void StergereRecursiv(int value);
        int cerinta4(int value);
        int cerinta5(int value);
        void cerinta6(int x, int y);
};

//Node
//
Node::Node(){
    left=nullptr;
    right=nullptr;
}

Node::Node(int value)
    :info(value)
{
    left=nullptr;
    right=nullptr;
}

bool Node::isLeaf(){
    if (right==nullptr && left==nullptr)
        return true;
    return false;
}
//

//BST
BinarySearchTree::BinarySearchTree(){
    root=nullptr;
}

void BinarySearchTree::ParcurgereInordine(){
    ParcurgereInordine(root);
}

void BinarySearchTree::ParcurgereInordine(Node* currentNode){
    if (currentNode != nullptr){
        ParcurgereInordine(currentNode->left);
        cout<<currentNode->info<<" ";
        ParcurgereInordine(currentNode->right);
    }
}

void BinarySearchTree::Insert(int value){
    if (root==nullptr){ 
        root=new Node(value);
    }
    else{
        Node* currentNode = root;
        while (true)
        {   if (value > currentNode->info){
                if (currentNode->right==nullptr){
                    currentNode->right=new Node(value);
                    break;
                }
                else currentNode=currentNode->right;
            }
            else{
                if (currentNode->left==nullptr){
                    currentNode->left=new Node(value);
                    break;
                }
                else currentNode=currentNode->left;
            }
        }
    }
}

void BinarySearchTree::InsertRecursiv(int value){
    InsertRecursiv_(root, value);
}

void BinarySearchTree::InsertRecursiv_(Node* & p, int value){
    
    if (p!=nullptr)
    { if (p->info > value)
        InsertRecursiv_(p->left, value);
      else if (p->info < value)
        InsertRecursiv_(p->right, value);
    }
    else
    { p=new Node(value);
    }
}

bool BinarySearchTree::Cautare(int value){
    
    Node* currentNode=root;
    
    while (true){
        
        if (currentNode==nullptr)
            return false;
        
        if (currentNode->info == value)
            return true;

        if (currentNode->info > value){
            currentNode=currentNode->left;
        }
        else if (currentNode->info < value){
            currentNode=currentNode->right;
        }
    }
}

bool BinarySearchTree::CautareRecursiv(int value){
    return CautareRecursiv_(root, value);
}

bool BinarySearchTree::CautareRecursiv_(Node* & p, int value){
    if (p==nullptr)
        return false;
    
    if (p->info==value)
        return true;

    if (p->info > value)
        return CautareRecursiv_(p->left, value);
    
    else if (p->info < value)
        return CautareRecursiv_(p->right, value);
    
}

void BinarySearchTree::StergereRecursiv(int value){
    StergereRecursiv_(root, value);
}

void BinarySearchTree::StergereRecursiv_(Node* & p, int value){
    if(p!=nullptr)
    { if (p->info==value)
      { if (p->isLeaf()==true)
            delete p;
        
        else if (p->left==nullptr)
        { Node* aux=p;
          p=p->right;
          delete aux;
        }
        else if(p->right==nullptr)
        { Node* aux=p;
          p=p->left;
          delete aux;
        }
        else
            StergAux(p->left, p);
      }
      else if (p->info>value)
        StergereRecursiv_(p->left, value);
      else if (p->info<value)
        StergereRecursiv_(p->right, value);
    }
    else return;
}

void BinarySearchTree::StergAux(Node*& p, Node*& P){
    //P nodul care il stergem
    //p nodul cel mai din dreapta
    if(p->right!=nullptr)
        StergAux(p->right, P);
    else{
        P->info=p->info;
        Node* aux=p;
        p=p->left;
        delete aux;
    }

}

void BinarySearchTree::Stergere(int value){
    if (root==nullptr)
        return;

    Node* currentNode=root;
    Node* parinte=nullptr;

    bool gasit=0;

    while(true)
    { if (currentNode->info==value)
      { gasit=1;
        break;
      }

      if (currentNode==nullptr)
      { gasit=0;
        break;
      }

      if (currentNode->info > value)
      { parinte=currentNode;
        currentNode=currentNode->left;
      } 
      
      if (currentNode->info < value)
      { parinte=currentNode;
        currentNode=currentNode->right;
      }
    }

    if (gasit==0)
        return;

    if (currentNode->isLeaf()==true && currentNode==root)
    { root=nullptr;
      return;
    }

    if (currentNode->isLeaf()==true)
    { if (parinte->left==currentNode)
        parinte->left=nullptr;
      else if (parinte->right==currentNode)
        parinte->right=nullptr;
      delete currentNode;
      return;
    }

    if (currentNode->left==nullptr || currentNode->right==nullptr)
    { Node *aux=nullptr;

      if (currentNode->right==nullptr)
        aux=currentNode->left;
      else aux=currentNode->right;

      if (parinte==nullptr)
        root=aux;
      else if (parinte->left==currentNode)
        parinte->left=aux;
      else parinte->right=aux;

      delete currentNode;
      
      return;
    }

    //sunt pe cazul cand si left si right nu sunt nullptr

    Node* CelMaiDinDrNod=currentNode->left;
    parinte=currentNode;
    while (CelMaiDinDrNod->right!=nullptr){
        parinte=CelMaiDinDrNod;
        CelMaiDinDrNod=CelMaiDinDrNod->right;
    }    
    currentNode->info=CelMaiDinDrNod->info;
    if (parinte->left==CelMaiDinDrNod){
        parinte->left=CelMaiDinDrNod->left;
    }
    else if (parinte->right==CelMaiDinDrNod){
        parinte->right=CelMaiDinDrNod->left;
    }

    delete CelMaiDinDrNod;

}

/*void BinarySearchTree::Stergere(int value){

    if (root==nullptr)
        return;
    
    Node* currentNode=root;

    while (true){

        if (currentNode->info==value){
            
            if (currentNode->isLeaf()==true)
            {   delete currentNode;
                currentNode=nullptr;
                break;
            }

            else{
                
                if (currentNode->right==nullptr){
                    Node* aux=currentNode;
                    currentNode=currentNode->left;
                    delete aux;
                    break;
                }

                else if (currentNode->left==nullptr){
                    Node* aux=currentNode;
                    currentNode=currentNode->right;
                    delete aux;
                    break;
                }

                else{
                    Node* CelMaiDinDrNod=currentNode->left;
                    while (CelMaiDinDrNod->right!=nullptr){
                        CelMaiDinDrNod=CelMaiDinDrNod->right;
                    }
                    currentNode->info=CelMaiDinDrNod->info;
                    Node* aux=CelMaiDinDrNod;
                    CelMaiDinDrNod=CelMaiDinDrNod->left;
                    delete aux;
                    break;
                }

            }
        }

        if (currentNode->info > value){
            currentNode=currentNode->left;
        }
        else currentNode=currentNode->right;

    }

}
*/

int BinarySearchTree::cerinta4(int value){
    Node* currentNode=root;

    int y=0;

    while (currentNode!=nullptr)
    { if (currentNode->info <= value)
      { y=currentNode->info;
        currentNode=currentNode->right;
      }
      else currentNode=currentNode->left;
    }

    return y;

}

int BinarySearchTree::cerinta5(int value){
    Node* currentNode=root;

    int y=0;

    while (currentNode!=nullptr)
    { if (currentNode->info >= value)
      { y=currentNode->info;
        currentNode=currentNode->left;
      }
      else currentNode=currentNode->right;
    }
    
    return y;

}

void BinarySearchTree::cerinta6(int x, int y)
{ cerinta6_(root, x, y);
  g<<endl;
}

void BinarySearchTree::cerinta6_(Node* currentNode, int x, int y)
{ if (currentNode==nullptr)
    return;
  
  if (currentNode->info>=x && currentNode->info<=y)
  { cerinta6_(currentNode->left, x, y);
    g<<currentNode->info<<" ";
    cerinta6_(currentNode->right, x, y);
  }
  else if(currentNode->info<x)
  { cerinta6_(currentNode->right, x, y);
  }
  else cerinta6_(currentNode->left, x, y);

}

//

int main()
{
    BinarySearchTree copac;
    int t=0;
    f>>t;
    int op=0, x=0, y=0;
    while(t)
    { f>>op;
      if (op==1)
        f>>x, copac.InsertRecursiv(x);
      else if (op==2)
        f>>x, copac.Stergere(x);
      else if (op==3)
        f>>x, g<<copac.CautareRecursiv(x)<<'\n';
      else if (op==4)
        f>>x, g<<copac.cerinta4(x)<<'\n';
      else if (op==5)
        f>>x, g<<copac.cerinta5(x)<<'\n';
      else f>>x>>y, copac.cerinta6(x, y);

      t--;

    }
}