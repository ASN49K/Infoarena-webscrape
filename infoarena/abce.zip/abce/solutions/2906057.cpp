#include<bits/stdc++.h>
#include<fstream>
using namespace std;
#define MAXL 1000
ifstream f("abce.in");
ofstream g("abce.out");

class Node{
public:
    long key;
    Node **forward;
    Node(long,long);
};
Node::Node(long key, long level)
{
    this->key=key;
    forward= new Node*[level+1];
    memset(forward,0,sizeof(Node*)*(level+1));

}

class SkipList{
    long maxx;
    float P;
    long level;
    Node* header;
public:
    SkipList(long,float);
    int RandomLvl();
    Node* NewNode(long, long);
    void AdaugareNod(long);
    void CautareNod(long);
    void StergereNod(long);
    void AfisareLista();
    void Cautareminmax(long,int);
    void Cautaremin(long);
    void intreXsiY(long,long);
};

SkipList::SkipList(long,float P)
{
    this->maxx=MAXL;
    this->P=P;
    level=0;
    header=new Node(-1,MAXL);
}

int SkipList::RandomLvl()
{
    float r=(float)rand()/RAND_MAX;
    long lvl=0;
    while(lvl<MAXL && r<P)
    {
        lvl++;
        r=(float)rand()/RAND_MAX;
    }
    return lvl;
}

Node* SkipList::NewNode(long key, long level)
{
    Node* n= new Node(key,level);
    return n;
}

void SkipList::AdaugareNod(long key)
{
    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));

    for(long i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current==NULL || current->key!=key)
    {
        long newlevel=RandomLvl();

        if(newlevel>level)
        {
            for(long i=level+1;i<newlevel+1;i++)
                update[i]=header;
            level=newlevel;
        }
        Node* n=NewNode(key,newlevel);
        for(long i=0;i<=newlevel;i++)
        {
            n->forward[i]=update[i]->forward[i];
            update[i]->forward[i]=n;
        }

    }

}


void SkipList::StergereNod(long key)
{

    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));
    for(long i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current!=NULL || current->key==key)
    {
        for(long i=0;i<=level;i++)
        {
            if(update[i]->forward[i]!=current)
                break;
            update[i]->forward[i]=current->forward[i];

        }
        while(level>0&& header->forward[level]==0)
            level--;
    }


}

void SkipList::CautareNod(long key)
{
    Node* current= header;
    for(long i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
    current=current->forward[0];
    if(current and current->key==key)
        cout<<1<<endl;
    else
        cout<<0<<endl;

}

void SkipList::Cautareminmax(long key, int tip)
{
    Node* current=header;
        for(long i =level; i>=0;i--)
            while(current->forward[i]!=NULL && current->forward[i]->key<key)
                current=current->forward[i];

    if(tip==4)
    {
        if(current->forward[0]->key==key)
            cout<<current->forward[0]->key<<endl;
        else
            cout<<current->key<<endl;
    }
    else if(tip==5)
        cout<<current->forward[0]->key<<endl;
}

void SkipList::intreXsiY(long x, long y)
{
    Node* current=header;
    for(long i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<x)
            current=current->forward[i];
    current=current->forward[0];
    while(current->forward[0]!=NULL && current->forward[0]->key<=y)
    {
        cout<<current->key<<" ";
        current=current->forward[0];
    }
    if(current->key<=y)
        cout<<current->key;
    cout<<endl;
}


SkipList lista(MAXL,0.5);

int main()
{
    long Q, tip,x,y;
    f>>Q;
    for(long i=0;i<Q;i++)
    {
        f>>tip;
        switch(tip)
        {
        case 1:
        {
            f>>x;
            lista.AdaugareNod(x);
            break;
        }
        case 2:
        {
            f>>x;
            lista.StergereNod(x);
            break;
        }
        case 3:
        {
           f>>x;
            lista.CautareNod(x);
            break;
        }
        case 4:
            {
                f>>x;
            lista.Cautareminmax(x,tip);
            break;
            }
        case 5:
            {
                 f>>x;
            lista.Cautareminmax(x,tip);
            break;
            }
        case 6:
            {
                f>>x>>y;
            lista.intreXsiY(x,y);
            break;
            }


        }


    }
    return 0;
}
