#include <iostream>
#include <fstream>
#include <vector>
#include <random>

std::ifstream fin("abce.in");
std::ofstream fout("abce.out");

struct Node {
    Node() : key(0), priority(0), left(nullptr), right(nullptr) {}
    Node(long long key_, long long priority_) : key(key_), priority(priority_), left(nullptr), right(nullptr) {}

    long long key;
    long long priority;

    Node *left, *right;
};

Node* find(Node *node, long long key) {
    if(node == nullptr) return nullptr;

    if(node->key == key) {
        return node;
    }

    if(key >= node->key) {
        return find(node->right, key);
    }
    return find(node->left, key);
}

void rotateRight(Node *&root) {
    Node *t = root->right;
    root->right = t->left;
    t->left = root;
    root = t;
}

void rotateLeft(Node *&root) {
    Node *t = root->left;
    root->left = t->right;
    t->right = root;
    root = t;
}

void insert(Node *&root, long long key, long long priority) {
    if(root == nullptr) {
        root = new Node(key, priority);
        return;
    }

    if(key < root->key) {
        insert(root->left, key, priority);

        if (root->left->priority > root->priority)
            rotateLeft(root);
    }
    else if(key > root->key) {
        insert(root->right, key, priority);

        if (root->right->priority > root->priority)
            rotateRight(root);
    }
}

void erase(Node *&root, long long key) {
    if(root == nullptr) return;

    if(key < root->key) {
        erase(root->left, key);
    }
    else if(key > root->key) {
        erase(root->right, key);
    }
    else {
        if(root->left == nullptr && root->right == nullptr) {
            delete root;
            root = nullptr;
        }
        else if(!root->left || !root->right) {
            Node *child;

            if(root->left) child = root->left;
            else child = root->right;

            Node *old = root;
            root = child;

            delete old;
        }
        else {
            if(root->left->priority < root->right->priority) {
                rotateLeft(root);
                erase(root->left, key);
            }
            else {
                rotateRight(root);
                erase(root->right, key);
            }
        }
    }
}

long long maxLessThan(Node *root, long long key) {
    long long val = key;

    while(root) {
        if(root->key >= key) {
            root=root->left;
        }
        else {
            val = root->key;
            root=root->right;
        }
    }

    return val;
}

long long minGreaterThan(Node *root, long long key) {
    long long val = key;

    while(root) {
        if(root->key <= key) {
            root=root->right;
        }
        else {
            val = root->key;
            root=root->left;
        }
    }

    return val;
}


void interval(Node *root, long long left, long long right) {
    if(root == nullptr) return;

    interval(root->left, left, right);
    if(left <= root->key && root->key <= right) {
        fout << root->key << ' ';
    }
    interval(root->right, left, right);
}

Node* search(Node *root, long long key) {
    if(root == nullptr) return nullptr;

    if(root->key == key) {
        return root;
    }
    else if(key <= root->key) {
        search(root->left, key);
    }
    else {
        search(root->right, key);
    }
}

int main() {
    std::random_device rd;
    std::mt19937_64 gen64(rd());

    int q;

    fin>>q;
    Node *root = nullptr;
    for(int i = 0; i < q; i++)
    {
        int op, x;
        fin>>op >> x;
        if(op == 1) {
            insert(root, x, gen64());
        }
        else if(op == 2) {
            erase(root, x);
        }
        else if(op == 3) {
            fout << (search(root, x) != nullptr) << '\n';
        }
        else if(op == 4) {
            fout << maxLessThan(root, x) <<'\n';
        }
        else if(op == 5) {
            fout<<minGreaterThan(root, x) <<'\n';
        }
        else {
            int y;
            fin>>y;
            interval(root, x, y);
            fout<<'\n';
        }
    }

    fin.close();
    fout.close();

    return 0;
}