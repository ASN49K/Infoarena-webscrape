#include <bits/stdc++.h>
 
using namespace std;
 
ifstream fin("abce.in");
ofstream fout("abce.out");
 
const int MOD = 1e9 + 7;
 
struct Treap
{
    int key;
    int priority;
 
    Treap *left, *right;
};
 
Treap *root, *nul;
 
void rot_left(Treap* &root)
{
    Treap* aux = root-> left;
    root-> left = aux-> right;
    aux-> right = root;
    root = aux;
}
 
void rot_right(Treap* &root)
{
    Treap *aux = root-> right;
    root-> right = aux-> left;
    aux-> left = root;
    root = aux;
}
 
void balance(Treap* &root)
{
    if(root-> priority < root-> left-> priority)
        rot_left(root);
 
    if(root-> priority < root-> right-> priority)
        rot_right(root);
}
 
void Insert(Treap* &root, int key, int priority)
{
    if(root == nul)
    {
        root = new Treap
        {
            key,
            priority,
            nul,
            nul
        };
        return;
    }
 
    if(key < root-> key)
        Insert(root-> left, key, priority);
    else
        Insert(root-> right, key, priority);
 
    balance(root);
}
 
bool Find(Treap* root, int key)
{
    if(root == nul)
        return false;
 
    if(key == root-> key)
        return true;
 
    if(key < root-> key)
        return Find(root-> left, key);
 
    return Find(root-> right, key);
}
 
void Delete(Treap* &root, int key)
{
    if(root == nul)
        return;
 
    if(key < root-> key)
        Delete(root-> left, key);
    else if(key > root-> key)
        Delete(root-> right, key);
    else
    {
        if(root-> left == nul && root-> right == nul)
        {
            delete root;
            root = nul;
        }
        else
        {
            if(root-> left-> priority > root-> right-> priority)
                rot_left(root);
            else
                rot_right(root);
 
            Delete(root, key);
        }
    }
}
 
int Find_Sm(Treap* root, int key)
{
    if(root == nul)
    {
        return -MOD;
    }
 
    if(root-> key > key)
    {
        return Find_Sm(root-> left, key);
    }
 
    return max(root-> key, Find_Sm(root-> right, key));
}
 
int Find_Bg(Treap* root, int key)
{
    if(root == nul)
    {
        return MOD;
    }
 
    if(root-> key < key)
    {
        return Find_Bg(root-> right, key);
    }
 
    return min(root-> key, Find_Bg(root-> left, key));
}
 
void Find_Range(Treap* root, int l, int r)
{
    if(root == nul)
        return;
 
    Find_Range(root-> left, l, r);
 
    if(l <= root-> key && root-> key <= r)
        fout << root-> key << ' ';
 
    Find_Range(root-> right, l, r);
}
 
int main()
{
    int T;
    fin >> T;
 
    nul = new Treap
    {
        0,
        -MOD,
        NULL,
        NULL
    };
 
    root = nul;
 
    while(T--)
    {
 
        int t, x, y;
        fin >> t >> x;
 
        if(t == 1)
        {
            ///INSERT X
            Insert(root, x, ((rand() << 15) + rand()) % MOD);
        }
        else if(t == 2)
        {
            ///DELETE X
            if(Find(root, x))
                Delete(root, x);
        }
        else if(t == 3)
        {
            ///FIND X
            fout << Find(root, x) << '\n';
        }
        else if(t == 4)
        {
            ///FIND X-
            fout << Find_Sm(root, x) << '\n';
        }
        else if(t == 5)
        {
            ///FIND X+
            fout << Find_Bg(root, x) << '\n';
        }
        else
        {
            fin >> y;
            ///X---Y
            Find_Range(root, x, y);
            fout << '\n';
        }
    }
 
    return 0;
}
