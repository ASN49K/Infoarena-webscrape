#include <fstream>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");

//splay trees are BSTs that bring the recently accessed item to root of the tree
//ZIG/ZAG = Node is child of the root (has no grand-parent) and is a right child (we do left rotation) or left child (we do right rotation)
//ZIG-ZIG/ZAG-ZAG = Node is left child of parent and parent is left child of grand parent (2 right rotation) or right child of parent and parent is right child of grand parent (2 left rotation)
//ZIG-ZAG/ZAG-ZIG = Node is left child of parent and parent is right child of grand parent (left rotation + right rotation) or right child of parent and parent is left child of grand parent (right rotation+left rotation)

struct node
{
    int val;
    node* left, * right;
};

node* newNode(int val)       //function for new node
{
    node* N = new node();
    N->val = val;
    N->left = NULL;
    N->right = NULL;
    return (N);
}


node* rightRotation(node* x)        //right rotation for subtree that has y as root
{
    node* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

node* leftRotation(node* x)         //right rotation for subtree that has y as root
{
    node* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

//splaying
node* splay(node* root, int val)     //brings the wanted value as root or the last accessed item as root if the value does not exist
{
    if (root == NULL || root->val == val)   return root;
    if (root->val > val)            //the value is in the left sub-tree
    {
        if (root->left == NULL) return root;  // value is not in tree
        if (root->left->val > val)  // Zig-Zig (Left Left) 
        {
            root->left->left = splay(root->left->left, val);  //bring the value as root of left-left
            root = rightRotation(root);   //first right rotation
        }
        else if (root->left->val < val) // Zig-Zag (Left Right) 
        {
            root->left->right = splay(root->left->right, val);
            if (root->left->right != NULL)  root->left = leftRotation(root->left);
        }
        return (root->left == NULL) ? root : rightRotation(root);
    }
    else // value is in right subtree 
    {
        if (root->right == NULL) return root;          // value is not in tree
        if (root->right->val > val) // Zag-Zig (Right Left) 
        {
            root->right->left = splay(root->right->left, val);   // bring the value as root of right-left 
            if (root->right->left != NULL)             //first tight rotation for right 
                root->right = rightRotation(root->right);
        }
        else if (root->right->val < val)// Zag-Zag (Right Right) 
        {
            root->right->right = splay(root->right->right, val);  //bring the value as root
            root = leftRotation(root);                   //first right right rotation
        }

        return (root->right == NULL) ? root : leftRotation(root);
    }
}

//insertion
node* insert(node* root, int k)
{
    if (root == NULL) return newNode(k);   //empty tree
    root = splay(root, k);        // Bring the closest leaf node to root
    node* newnode = newNode(k);   //allocate memory for new node
    if (root->val > k)              //if root value is greater
    {
        newnode->right = root;        //make root as right child of new node
        newnode->left = root->left;   // and copy the left child of root to newnode
        root->left = NULL;
    }


    else
    {
        newnode->left = root;  // make root as left child of newnode
        newnode->right = root->right; // and copy the right child of root to newnode
        root->right = NULL;
    }

    return newnode; // newnode becomes new root
}

//deletion
node* deleteValue(node* root, int val) // returns the new root after removing the val 
{
    node* t;
    if (root == NULL) return NULL;
    root = splay(root, val);
    if (val != root->val)  return root;   //if we dont have what to delete
    if (root->left == NULL)     // If left child of root does not exist
    {
        t = root;
        root = root->right;  // make root->right as root   
    }
    else
    {
        t = root;
        root = splay(root->left, val);   //splaying the maximum node of left subtree
        root->right = t->right;
    }
    free(t);
    return root;
}

//searching
node* search(node* root, int val)
{
    return splay(root, val);
}

void Print(node* root, int x, int y)
{
    if (root == NULL) return;
    if (x < root->val)  //the tree is ordered => If root->val is greater than x, then only we search keys in left subtree
        Print(root->left, x, y);
    if (x <= root->val && y >= root->val)   // if root's value is in range
        fout << root->val << " ";  
    if (y > root->val)  //the tree is ordered => If root->val is smaller than x, then only we search keys in right subtree
        Print(root->right, x, y);
}


int main()
{
    int N, task, x, y;
    fin >> N;
    node* root = NULL;
    for (int i = 1; i <= N; i++)
    {
        fin >> task >> x;
        if (task == 1) root = insert(root, x);
        if (task == 2) root = deleteValue(root, x);
        if (task == 3)
        {
            if (root == NULL) fout << 0 << "\n";
            else 
            {
                root = search(root, x);
                if (root == NULL || root->val != x)  fout << 0 << "\n";
                if (root->val == x) fout << 1 << "\n";
            }
        }
        if (task == 4)   //equivalent with predecessor
        {
            int ok = 0;
            while (!ok)   //while we didnt find the predecessor
            {
                root = search(root, x);  //we search for it
                if (root->val == x) fout << x << "\n" , ok = 1;  //if found, print it
                else x--;   //else, we go to the next possible predecessor
            }
        }
        if (task == 5) //equivalent with successor
        {
            int ok = 0;
            while (!ok)  //while we didnt find the successor
            {
                root = search(root, x);   //we search for it
                if (root->val == x) fout << x << "\n", ok = 1;    //if found, print it
                else x++;  //else, we go to the next possible successor
            }
        }
        if (task == 6)
        {
            fin >> y;
            Print(root, x, y);
            fout << "\n";
        }

    }
    return 0;
}