#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin ("abce.in");
ofstream fout ("abce.out");

class Nod{
    private:

        bool leaf;  // daca nodul este frunza sau nu
        int degree; // numarul minim de chei
        vector <int> keys; // un vector cu cheile nodului curent
        vector<Nod*> children;  // un vector cu copii nodului curent
        int n;  // cate elemente sunt in keys
    public:
        Nod(int leaf, int degree){
            this->leaf = leaf;
            this->degree = degree;
            this->n = 0;
            keys.reserve(63);   // degree = 32 deci rezerv in vector 2*32 - 1 locuri pentru chei
            children.reserve(64);   // rezerv 2*32 locuri pentru copii
        }
        ~Nod(){
        }
        void insertChildNotFull(int);
        void splitChild(Nod*, int);
        int FirstGreaterKey(int);
        void remove(int);
        void removeFromLeaf(int);
        void removeFromInterior(int);
        int getPredecesor(int);
        int getSuccesor(int);
        void fillChild(int);
        void borrowFromLeft(int);
        void borrowFromRight(int);
        void mergeChildren(int);
        friend class BTree;
        void traverse();
};

class BTree{
    private:
        Nod* root;  // pointer catre radacina
        int degree; // numarul minim de chei din vector
    public:
        BTree(int dim){
            this->root = NULL;
            this->degree = dim;
        }
        ~BTree(){
        }
        int search(int );
        void insert(int);
        void remove(int);
        int Pred(int);
        int Succ(int);
        void traverse()
    {
        if (root != NULL) root->traverse();
    }
};

// fucntie care cauta cheia x in arbore
int BTree::search(int x){
    // verific daca exista ceva in radacina
    // daca nu atunci opresc cautarea
    if (root == NULL)
        return -1;
    // pornesc din radacina
    Nod* nod = root;
    // cat timp nu am gasit radacina sau nu am ajuns la o frunza
    while(true){
        int i = 0;
        // caut prima cheie mai mare ca x
        while (i < nod->n && x > nod->keys[i])
            i++;

        // daca la pozitia i gasesc chiar cheia x atunci ii returnez pozitia
        if (nod->keys[i] == x)
            return i;
        // daca am ajuns la o frunza atunci nu mai pot continua
        if (nod->leaf == true)
            return -1;
        // verific daca x este mai mic ca prima cheie
        // daca da atunci ma duc in in primul copil
        // daca nu, ma duc in copilul corespunzator
        if (x < nod->keys[0])
            nod = nod->children[0];
        else
            nod = nod->children[i + 1];
    }
}

// insereaza o noua cheie in arbore
void BTree::insert(int elem){
    // daca arborele este gol
    if (this->root == NULL){
        // creez radacina (fac un nod)
        this->root = new Nod(true, degree);
        // prima cheie din radacina o sa fie elementul pe care vreau sa-l inserez
        root->keys[0] = elem;
        // retin ca am o cheie
        root->n = 1;
    }
    // daca am elemente in radacina
    else{
        // daca am deja numarul maxim (2*degree - 1) de chei in radacina
        if (root->n  == 2 * degree - 1){
            // creez noua radacina
            Nod* newRoot = new Nod(false, degree);
            // radacina veche o sa fie copil pentru noua radacina
            newRoot->children[0] = root;
            // dau split radacinii vechi
            newRoot->splitChild(root, 0);

            // noua radacina are doi fii
            // decid in ce fiu pun cheia (elem)
            int i = 0;
            // daca elementul meu este mai mare decat cheia din noua radacina atunci adaug elementul in fiul drept
            if (newRoot->keys[0] < elem)
                i++;
            // adaug elem in fiul corect
            newRoot->children[i]->insertChildNotFull(elem);
            // schimb radacina
            root = newRoot;
        }
        else
            // daca radacina nu este plina atunci adaug elem in ea
            root->insertChildNotFull(elem);
    }
}

// functia insereaza un o cheie intr-un nod care nu este deja plin
void Nod::insertChildNotFull(int elem){
    int poz = n - 1;
    // daca nodul este o frunza
    if (leaf == true){
        // caut pozitia unde trebuie sa inserez cheia
        while (poz >= 0 && keys[poz] > elem)
        {
            keys[poz+1] = keys[poz];
            poz--;
        }
        // inserez cheia la pozitia corecta
        keys[poz + 1] = elem;
        // cresc numarul de chei
        n++;
    }
    // daca nodul nu e frunza
    else{
        // caut fiul unde pot introduce cheia
        while (poz >= 0 && keys[poz] >= elem)
            poz--;
        // verific daca fiul este plin
        if (children[poz+1]->n == 2 * degree - 1){
            // daca este plin atunci ii dau split
            splitChild(children[poz+1], poz+1);
            // decid in care din cei doi fii pun cheia
            if (keys[poz+1] < elem)
                poz++;
        }
        children[poz+1]->insertChildNotFull(elem);
    }
}

// impart fiul left in doua noduri
void Nod::splitChild(Nod* left, int poz){
    // nodul drept in care o sa pun a doua jumatate a cheilor din nodul left
    Nod* right = new Nod(left->leaf, left->degree);
    right->n = degree - 1; // numarul minim de chei dintr-un nod

    // copiez jumatatea in right
    for (int i = 0; i < degree - 1; i++)
        right->keys[i] = left->keys[i+degree];

    // daca left nu este frunza atunci nici right nu o sa fie deci o sa aiba fii
    // atunci copiez si jumatatea corespunzatoare de fii
    if (left->leaf == false){
        for (int i = 0; i < degree ; i++)
            right->children[i] = left->children[i + degree];
    }
    // redimensionez vectorul left
    left->n = degree - 1;

    // fac spatiu pentru fiul ce urmeaza sa fie adaugat
    for (int i = n; i >= poz + 1; i--)
        children[i + 1] = children[i];
    // adaug copilul right la nod
    children[poz + 1] = right;
    // fac loc pentru cheia ce urmeaza sa fie adaugata
    for (int i = n - 1; i >= poz; i--)
        keys[i + 1] = keys[i];
    // adaug cheia in nod
    keys[poz] = left->keys[degree - 1];
    n++;
}


// elimina cheia elem
void Nod::remove(int elem){
    int index = 0;
    // gasesc pozitia primei chei care este mai mare decat elem
    while (index < n && keys[index] < elem)
        index++;

    // cheia cautata se afla la index
    if (index < n && keys[index] == elem){
        // daca este frunza
        if (leaf == true)
            removeFromLeaf(index);
        else
            removeFromInterior(index);
    }
    else{
        // daca nodul este frunza
        if (leaf){
            return;
        }
        // verific daca cheia mea se afla in ultimul fiul din dreapta
        bool ok = 0;
        if (index == n)
            ok = 1;

        // daca fiul in care se afla cheia noastra are mai putine chei decat degree (numarul minim de chei pentru un nod)
        // atunci mai adaugam chei de la vecinii lui
        if (children[index]->n < degree){
            // daca exista un fiu imediat la stanga si fiul respectiv are mai multe chei decat numarul minim (degree) atunci
            if (index > 0 && children[index - 1]->keys.size() >= degree)
                borrowFromLeft(index);
            else{
                // daca exista un fiu imediat la dreapta si fiul respectiv are mai multe chei decat numarul minim (degree) atunci
                if (index != n && children[index + 1]->keys.size() >= degree)
                    borrowFromRight(index);
                else{
                    // daca nu am ce sa imprumut, atunci
                    // daca sunt la ultimul fiu atunci ii dau merge cu cel de dinaintea lui
                    // daca nu ii dau merge cu cel de dupa el
                    if (index < n)
                        mergeChildren(index);
                    else
                        mergeChildren(index);
                }
            }

        }

        // verificam daca am facut merge, daca am facut merge la ultimul fiu atunci el a facut merge cu cel de pe poztia anterioara lui asa ca el nu mai exista deci cheia mea cautata se gaseste in fiul cu care a facut merge

        if (ok == true && index > n)
            children[index - 1]->remove(elem);
        else
            children[index]->remove(elem);

    }
    return;
}

void Nod::removeFromLeaf(int index){
    for (int i=index+1; i<n; ++i)
        keys[i-1] = keys[i];
    n--;
    return;
}

void Nod::removeFromInterior(int index){
    int key = keys[index];
    // daca fiul de dinaintea cheii mele are mai mult de degree chei
    // gasesc predecesorul, inlocuiesc pe key cu valoarea predecesorului
    if (children[index]->n >= degree){
        int predecesor = getPredecesor(index);
        keys[index] = predecesor;
        children[index]->remove(predecesor);
    }
    else {// daca fiul stang nu are dedstule chei atunci verific fiul drept, din care iau succesorul
            if(children[index + 1]->n >= degree){
                int succesor = getSuccesor(index);
                keys[index] = succesor;
                children[index + 1]->remove(succesor);
            }
        // daca amandoi fii au mai putin decat nr minim de chei atunci dau merge fiilor si sterg cheia din noul fiu
        else{
            mergeChildren(index);
            children[index]->remove(key);
        }}
    return;
}
// returneaza predecesorul
int Nod::getPredecesor(int index){
    Nod* nod = children[index];
    while(nod->leaf == false)
        nod = nod->children[nod->n];
    return nod->keys[nod->n - 1];
}

// returneaza succesorul
int Nod::getSuccesor(int index){
    Nod* nod = children[index + 1];
    while(nod->leaf == false)
        nod = nod->children[0];
    return nod->keys[0];
}

// iau o cheie din stanga fiului si o adaug in fiul meu curent
// iau ultima cheie din copil, o introduc in parinte, iar cheia de la index - 1 este introdusa in fiul meu care are nevoie de o cheie
void Nod::borrowFromLeft(int index){
    //Nod* copil = children[index];
   // Nod* frate = children[index - 1];

    // fac loc cheii
    for (int i = children[index]->n - 1; i >= 0; i--)
        children[index]->keys[i + 1] = children[index]->keys[i];

    // daca nodul meu nu este o frunza atunci redirectionez si fii lui la fel
    if (children[index]->leaf == false){
        for (int i = children[index]->n; i >= 0; i--)
            children[index]->children[i + 1] = children[index]->children[i];
    }
    // pun pe prima pozitie valoare cheii de pe poztia index - 1
    children[index]->keys[0] = keys[index - 1];
    // mut ultimul copil al lui c[index - 1] ca prim copil al lui c[index]
    if (children[index]->leaf == false)
        children[index]->children[0] = children[index - 1]->children[children[index - 1]->n];

    // adaug cheia lui c[index - 1] "parintelui"
    keys[index - 1] = children[index - 1]->keys[children[index - 1]->n - 1];
    children[index]->n += 1;
    children[index - 1]-> n -= 1;
    return;
}

void Nod::borrowFromRight(int index){
    //Nod* copil = children[index];
    //Nod* frate = children[index + 1];

    children[index]->keys[children[index]->n] = keys[index];
    if (children[index]->leaf == false)
        children[index]->children[children[index]->n + 1] = children[index + 1]->children[0];

    keys[index] = children[index + 1]->keys[0];
    for (int i = 1; i < children[index + 1]->n; i++)
        children[index + 1]->keys[i-1] = children[index + 1]->keys[i];
    if (children[index + 1]->leaf == false){
        for (int i = 1; i <= children[index + 1]->n; i++)
            children[index + 1]->children[i-1] = children[index + 1]->children[i];
    }
    children[index]->n += 1;
    children[index + 1]->n -= 1;
    return;
}

// dam merge la children[index] si children[index + 1]
void Nod::mergeChildren(int index){
    //Nod* copil = children[index];
    //Nod* frate = children[index  + 1];
    children[index]->keys[degree - 1] = keys[index];
    // copiez cheile din children[index + 1] in children[index]
    for (int i = 0 ; i < children[index  + 1]->n; i++)
        children[index]->keys[i + degree] = children[index  + 1]->keys[i];
    // daca nodul nu este frunza copiez si fii
    if (children[index]->leaf == false){
        for (int i = 0 ; i <= children[index  + 1]->n; i++)
            children[index]->children[i + degree] = children[index  + 1]->children[i];
    }
    // pentru ca am mutat keys[index] in children trebuie sa il elimin din keys
    for (int i = index + 1; i < degree; i++)
        keys[i - 1] = keys[i];

    for (int i = index + 2; i <= n; i++)
        children[i - 1] = children[i];
    children[index]->n += children[index  + 1]->n + 1;
    n--;

    return;
}

void BTree::remove(int elem){
    if (this->root == NULL){
        return;
    }
    this->root->remove(elem);
    if (this->root->n == 0){
        if (this->root->leaf == false)
            this->root = this->root->children[0];
        else
            this->root = NULL;
    }
    return;
}


void Nod::traverse(){
    int i;
    for (i = 0; i < n; i++){
        if (leaf == false)
            children[i]->traverse();

    }
    if (leaf == false)
        children[i]->traverse();
}

int BTree::Pred(int elem){
    int s;
    bool ok = 0;
    Nod* nod = this->root;
    while(true){
        int pozitie = 0;
        while(pozitie < nod->keys.size() && elem < nod->keys[pozitie])
            pozitie ++;
        if (nod->keys[pozitie] == elem)
            return elem;
        if (nod->leaf == true){
            if (nod->keys[pozitie] < elem)
                return nod->keys[pozitie];
            if (ok == true)
                return s;
            return -1;
        }
        else{
            if (nod->keys[pozitie] > elem)
                nod = nod->children[0];
            else{
                ok = true;
                s = nod->keys[pozitie];
                nod = nod->children[pozitie + 1];
            }
        }
    }

}

int BTree::Succ(int elem){
    int s;
    bool ok = 0;
    Nod* nod = this->root;
    while(true){
        int pozitie;
        while (pozitie < nod->n && elem > nod->keys[pozitie])
            pozitie++;
        if (nod->keys[pozitie] == elem)
            return elem;
        if (nod->leaf == true){
            if (nod->keys[pozitie] < elem)
                return nod->keys[pozitie];
            if (ok == true)
                return s;
            return -1;
        }
        else{
            if (nod->keys[pozitie] > elem)
                nod = nod->children[0];
            else{
                ok = true;
                s = nod->keys[pozitie];
                nod = nod->children[pozitie + 1];
            }
        }
    }
}


int main(){
    BTree bt(32);
    int nr_op, op, x;
    fin >> nr_op;
    for (int i = 0; i < nr_op; i++){
        fin >> op >> x;
        switch(op){
            case 1:
                bt.insert(x); break;
            case 2:
                bt.remove(x); break;
            case 3:
                if (bt.search(x) == -1)
                    fout << 0 << '\n';
                else
                    fout << 1 << '\n';
                break;
            case 4:
                fout << bt.Pred(x) << '\n'; break;
            case 5:
                fout << bt.Succ(x) << '\n'; break;
            case 6:
                fin >> x;
                break;
        }
    }

    return 0;
}
