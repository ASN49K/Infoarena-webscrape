#include <iostream>
#include <fstream>
std::ofstream g("abce.out");


class AVL{
    public:
        long height, nod_valoare;
        AVL *left= nullptr,*right= nullptr;
        AVL(long valoare):nod_valoare(valoare){}
};

AVL* nod_nou(long valoare){
    AVL *nod=new AVL(valoare);
    return nod;
}

long max(long x, long y){
    return (x > y) ? x : y;
}

long inaltime(AVL *nod) {
    return (nod != nullptr) ? nod->height : 0;
}

int find_nod(AVL *nod_baza,long valoare){
    while(nod_baza!= nullptr && nod_baza->nod_valoare!=valoare)
        if(nod_baza->nod_valoare>valoare)
            nod_baza=nod_baza->left;
        else
            nod_baza= nod_baza->right;
    if(nod_baza!= nullptr && nod_baza->nod_valoare==valoare)
        return 1;
    return 0;
}

AVL* right_rotation(AVL *nod1){
    AVL *nod2 = nod1->left;
    nod1->left = nod2->right;
    nod2->right = nod1;
    nod1->height = max(inaltime(nod1->left),inaltime(nod1->right)) +1;
    nod2->height = max(inaltime(nod2->left),inaltime(nod2->right)) +1;
    return nod2;
}

AVL* left_rotation(AVL *nod1){
    AVL *nod2 = nod1->right;
    nod1->right = nod2->left;
    nod2->left = nod1;
    nod1->height = max(inaltime(nod1->left),inaltime(nod1->right)) +1;
    nod2->height = max(inaltime(nod2->left),inaltime(nod2->right)) +1;
    return nod2;
}


AVL* LRRotate(AVL* nod)
{
    nod->left= left_rotation(nod->left);
    return right_rotation(nod);
}

AVL* RLRotate(AVL* nod)
{
    nod->right = right_rotation(nod->right);
    return left_rotation(nod);
}


AVL *inserare_nod(AVL *nod_baza, long valoare) {
    if (nod_baza == nullptr)
        return (nod_nou(valoare));
    if (valoare > nod_baza->nod_valoare)
        nod_baza->right = inserare_nod(nod_baza->right, valoare);
    else if (valoare < nod_baza->nod_valoare)
        nod_baza->left = inserare_nod(nod_baza->left, valoare);
    else
        return nod_baza;


    nod_baza->height =1+ max(inaltime(nod_baza->left), inaltime(nod_baza->right));
    long bf = inaltime(nod_baza->left) -inaltime(nod_baza->right);;
    if (bf > 1) {
        if (valoare > nod_baza->left->nod_valoare) {
            nod_baza->left = left_rotation(nod_baza->left);
            return right_rotation(nod_baza);
        } else if (valoare < nod_baza->left->nod_valoare){
            return right_rotation(nod_baza);

        }
    }

    if (bf < -1) {
        if (valoare < nod_baza->right->nod_valoare) {
            nod_baza->right = right_rotation(nod_baza->right);
            return left_rotation(nod_baza);
        } else if (valoare > nod_baza->right->nod_valoare){
            return left_rotation(nod_baza);
        }
    }

    return nod_baza;
}



AVL* Predecesor(AVL *nod){
    AVL *copie=nod;
    while(copie->right!= nullptr)
        copie=copie->right;
    return copie;
}

long before(AVL *nod_baza, long valoare){
    long max;
    if(nod_baza->nod_valoare==valoare)
        return valoare;
    if(nod_baza->nod_valoare<valoare)
        max=nod_baza->nod_valoare;
    else{
        while(nod_baza->nod_valoare>valoare)
            nod_baza=nod_baza->left;
        if(nod_baza->nod_valoare==valoare)
            return valoare;
        max=nod_baza->nod_valoare;
    }
    while(nod_baza!= nullptr)
        if(nod_baza->nod_valoare>valoare)
            nod_baza= nod_baza->left;
        else{
            if(nod_baza->nod_valoare==valoare)
                return nod_baza->nod_valoare;
            if(max<nod_baza->nod_valoare)
                max=nod_baza->nod_valoare;
            nod_baza=nod_baza->right;
        }
    return max;
}

long next(AVL *nod_baza, long valoare){
    long min;
    if(nod_baza->nod_valoare==valoare)
        return valoare;
    if(nod_baza->nod_valoare>valoare)
        min=nod_baza->nod_valoare;
    else{
        while(nod_baza->nod_valoare<valoare)
            nod_baza=nod_baza->right;
        if(nod_baza->nod_valoare==valoare)
            return valoare;
        min=nod_baza->nod_valoare;
    }
    while(nod_baza!= nullptr)
        if(nod_baza->nod_valoare<valoare)
            nod_baza= nod_baza->right;
        else{
            if(nod_baza->nod_valoare==valoare)
                return nod_baza->nod_valoare;
            if(min>nod_baza->nod_valoare)
            {min=nod_baza->nod_valoare;
            }
            nod_baza=nod_baza->left;
        }
    return min;
}

AVL* sterge_nod(AVL *nod_baza, long valoare_nod_de_sters){

    if(nod_baza==nullptr)
        return nod_baza;

    if(nod_baza->nod_valoare<valoare_nod_de_sters)
        nod_baza->right=sterge_nod(nod_baza->right,valoare_nod_de_sters);
    else
        if(nod_baza->nod_valoare>valoare_nod_de_sters)
            nod_baza->left=sterge_nod(nod_baza->left,valoare_nod_de_sters);
        else
        {
            if(nod_baza->left== nullptr || nod_baza->right== nullptr){
                AVL *copie;
                if(nod_baza->left!= nullptr)
                    copie=nod_baza->left;
                else
                    copie=nod_baza->right;
                if(copie== nullptr){
                    copie=nod_baza;
                    nod_baza= nullptr;
                }else
                    *nod_baza=*copie;
                delete copie;
            }else{
                AVL *copie = Predecesor(nod_baza->left);
                nod_baza->nod_valoare = copie->nod_valoare;
                nod_baza->left = sterge_nod(nod_baza->left,copie->nod_valoare);
            }
        }
    if (nod_baza == nullptr)
        return nod_baza;

    nod_baza->height = 1+max(inaltime(nod_baza->left), inaltime(nod_baza->right));
    long bf = inaltime(nod_baza->left) -inaltime(nod_baza->right);
    if (bf < -1) {
        if (inaltime(nod_baza->right->left) -inaltime(nod_baza->right->right)<=0) {
            return left_rotation(nod_baza);
        } else if (valoare_nod_de_sters < nod_baza->right->nod_valoare)
            return RLRotate(nod_baza);
    }
    if (bf > 1) {
        if (inaltime(nod_baza->left->left) -inaltime(nod_baza->left->right)>=0) {
            return right_rotation(nod_baza);
        } else if (valoare_nod_de_sters > nod_baza->left->nod_valoare)
            return LRRotate(nod_baza);
    }
    return nod_baza;
}


void printare_crescator(AVL *nod_baza,long val_min, long val_max){
    if(nod_baza== nullptr)
        return;
    if(nod_baza->right!= nullptr)
        printare_crescator(nod_baza->right,val_min,val_max);
    if(nod_baza->left!= nullptr)
        printare_crescator(nod_baza->left,val_min,val_max);
    if(nod_baza->nod_valoare<=val_max && nod_baza->nod_valoare>=val_min)
        g<<nod_baza->nod_valoare<<" ";
}

int main(){
    AVL *nod= nullptr;
    std::ifstream f("abce.in");
    long x,y,q;
    f>>q;
    while(q>0){
        f>>y;
        f>>x;
        switch (y) {
            case 1:
                nod= inserare_nod(nod,x);
                break;
            case 2:
                nod= sterge_nod(nod,x);
                break;
            case 3:
                g<<find_nod(nod,x)<<"\n";
                break;
            case 4:
                g<<before(nod,x)<<"\n";
                break;
            case 5:
                g<<next(nod,x)<<"\n";
                break;
            case 6:
                f>>y;
                printare_crescator(nod,x,y);
                g<<"\n";
                break;
            }
        q--;
    }
    f.close();
    g.close();
    while(nod!= nullptr)
        nod= sterge_nod(nod,nod->nod_valoare);
    return 0;
}