#include<iostream>
#include<fstream>
using namespace std;

ofstream g("abce.out");

struct Nod{
    Nod* st, *dr;
    int val;

    Nod(int val=0,Nod* st=nullptr,Nod* dr=nullptr):val{val},st{st},dr{dr}{}

};

class SplayTree{

    Nod *prim;


    Nod* rotatieSt(Nod *p){
        Nod *c=p->dr;
        p->dr=c->st;
        c->st=p;
        return c;
    }

    Nod* rotatieDr(Nod *p){
        Nod *c=p->st;
        p->st=c->dr;
        c->dr=p;
        return c;
    }

    bool cautare(int val){
        Nod* nod=this->prim;
        
        while(nod!=nullptr){
            if(nod==nullptr)
                return false;
            else if(nod->val==val)
                return true;
            else if(nod->val<val)
                nod=nod->dr;
            else
                nod=nod->st;
        }
        return false;
    }

    Nod* splay(Nod* nod,int val){

        if(nod==nullptr || nod->val==val)
            return nod;
        //stanga
        if(nod->val>val){
            if(nod->st==nullptr)
                return nod;
            //o iei prin stanga
            if(nod->st->val>val){
                
                nod->st->st=splay(nod->st->st,val);
                
                if (nod->st->st != nullptr)
                    nod->st=rotatieDr(nod->st);
            }
            // o iei prin dreapta
            else if(nod->st->val<val){
                nod->st->dr=splay(nod->st->dr,val);
                if(nod->st->dr!=nullptr)
                    nod->st=rotatieSt(nod->st);
            }
            if(nod->st==nullptr)
                return nod;
            return rotatieDr(nod);
        }
        else{
            //dreapta
            if(nod->dr==nullptr)
                return nod;
            
            if(nod->dr->val>val){

                nod->dr->st=splay(nod->dr->st,val);
                if(nod->dr->st!=nullptr)
                    nod->dr=rotatieDr(nod->dr);                

            }
            else if(nod->dr->val<val){
                nod->dr->dr=splay(nod->dr->dr,val);
                if(nod->dr->dr!=nullptr)
                    nod->dr=rotatieSt(nod->dr);
            }
            if(nod->dr==nullptr)
                return nod;
            return rotatieSt(nod);            
        }

    }

    Nod* stergere(int val){
        if(prim==nullptr)
            return prim;
        if(!cautare(val))
            return prim;
        
        prim=splay(prim,val);
        Nod *nod_del=prim;

        if(prim->st==nullptr){

            prim = prim->dr;
            delete nod_del;
            return prim;
        }
        Nod* nod1=prim->st;
        Nod* nod2=prim->dr;
        
        //Calcularea maximului din partea stanga
        while(nod1->dr!=nullptr)
            nod1=nod1->dr;
        
        prim=splay(prim->st,nod1->val);
        prim->dr=nod2;    
        delete nod_del;
        return prim;
    }
    void afisare(Nod *nod,int start, int stop){
        if(nod!=nullptr){
            afisare(nod->st,start,stop);
            if(nod->val>=start && nod->val<=stop)
                g<<nod->val<<" ";
            afisare(nod->dr,start,stop);

        }
    }

    Nod* inserare(int val){
        Nod *newnod=new Nod{val,nullptr,nullptr};

        if(prim==nullptr)
            return newnod;

        prim=splay(prim,val);
        if(prim->val==val){
            delete newnod;
            return prim;
        }

        if(prim->val>val){
            newnod->dr=prim;
            newnod->st=prim->st;
            prim->st=nullptr;
        }
        else{
            newnod->st=prim;
            newnod->dr=prim->dr;
            prim->dr=nullptr;
        }
        return newnod;
    }   

    void dezaloc(Nod* nod){
        
        if(nod!=nullptr){
            dezaloc(nod->dr);
            dezaloc(nod->st);
            delete nod;
        }
        
    }

    public:
    SplayTree(Nod* prim=nullptr):prim{prim}{}

void cauta(int val){
        if(cautare(val))
            g<<"1\n";
        else g<<"0\n";
    }

void insereaza(int val){
        prim=inserare(val);
    }

void sterge(int val){
        prim=stergere(val);
    }

void print(int start, int stop){
        afisare(prim,start,stop);
        g<<"\n";
    }

int cautare_mai_mic(int val){
    if(cautare(val))
        return val;

    prim=inserare(val);
    if(prim->st==nullptr){
        prim=stergere(val);
        return 0;
    }
    Nod* nod=prim->st;
    while(nod->dr)
        nod=nod->dr;
    prim=stergere(val);
    return nod->val;
}

int cautare_mai_mare(int val){

    if(cautare(val))
        return val;

    prim=inserare(val);
    if(prim->dr==nullptr){
        prim=stergere(val);
        return 0;
    }
    
    Nod* nod=prim->dr;
    while(nod->st)
        nod=nod->st;
    
    prim=stergere(val);
    return nod->val;
} 

    ~SplayTree(){
        dezaloc(prim);
    }

}; 

int main(){
    ifstream f("abce.in");
    SplayTree tree;
  int q,x,y;
    f>>q;
    while(q--){
        int op;
        f>>op;
        if(op==1){
            f>>x;
           tree.insereaza(x);
        }
        if(op==2){
            f>>x;
            tree.sterge(x);
        }
        if(op==3){
            f>>x;
            tree.cauta(x);
        }
        if(op==4){
            f>>x;
            g<<tree.cautare_mai_mic(x)<<"\n";
        }
        if(op==5){
            f>>x;
           g<<tree.cautare_mai_mare(x)<<"\n";
        }
        if(op==6){
            f>>x>>y;
            tree.print(x,y);
            
        }
    }
    f.close();
    g.close();
    return 0;

}