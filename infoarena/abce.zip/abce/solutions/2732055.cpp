#include <bits/stdc++.h>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
int M;
set<int>v;
void adaug(int x)
{
    v.insert(x);
}
int caut(int x)
{
    auto it = v.find(x);
    if(it == v.end())
    {
        ///nu exista;
        return 0;
    }
    return 1;
}
void sterg(int x)
{
    if(caut(x) == 1)
    {
        v.erase(x);
    }
}
void mic(int x)
{
    auto it = v.lower_bound(x);
    if(*it == x)
    {
        fout<<*it<<"\n";
    }
    else
        fout<<*(--it)<<"\n";
}
void mare(int x)
{
    auto it = v.upper_bound(x);
    fout<<*it<<"\n";
}
void ordine(int a, int b)
{
    auto start = v.lower_bound(a);
    auto finish = v.upper_bound(b);

    if(start != finish)
    {
        fout<<*start<<" ";
        start++;
    }
    if(finish == v.end())
    {
        fout<<*start<<" ";
    }
    fout<<"\n";

}
void citire()
{
    fin>>M;
    int cer, a, b;
    for(int i=1; i<=M; i++)
    {
        fin>>cer>>a;
        if(cer == 1)
            adaug(a);
        if(cer == 2)
            sterg(a);
        if(cer == 3)
            fout<<caut(a)<<"\n";
        if(cer == 4)
            mic(a);
        if(cer == 5)
            mare(a);
        if(cer == 6)
        {
            fin>>b;
            ordine(a, b);
        }
    }
}
int main()
{
    citire();
    return 0;
}
