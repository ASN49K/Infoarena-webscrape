#include <iostream>
#include <fstream>
using namespace std;

struct node {
    int key;
    node *left, *right;
};

node* newNode(int key) {
    node* t = new node;
    t->key = key;
    t->left = t->right = nullptr;
    return t;
}

node* rightRotate(node* x) {
    node* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

node* splay(node* root, int key) {
    if (root == nullptr || root->key == key)
        return root;

    if (root->key > key) {
        if (root->left == nullptr)
            return root;
        if (root->left->key > key) {
            root->left->left = splay(root->left->left, key);
            root = rightRotate(root);
        }
        else if (root->left->key < key) {
            root->left->right = splay(root->left->right, key);
            if (root->left->right != nullptr)
                root->left = leftRotate(root->left);
        }
        return (root->left == nullptr) ? root : rightRotate(root);
    }
    else {
        if (root->right == nullptr)
            return root;
        if (root->right->key > key) {
            root->right->left = splay(root->right->left, key);
            if (root->right->left != nullptr)
                root->right = rightRotate(root->right);
        }
        else if (root->right->key < key) {
            root->right->right = splay(root->right->right, key);
            root = leftRotate(root);
        }
        return (root->right == nullptr) ? root : leftRotate(root);
    }
}

node* insert(node* root, int key) {
    if (root == nullptr)
        return newNode(key);
    root = splay(root, key);
    if (root->key == key)
        return root;
    node* t = newNode(key);
    if (root->key > key) {
        t->right = root;
        t->left = root->left;
        root->left = nullptr;
    }
    else {
        t->left = root;
        t->right = root->right;
        root->right = nullptr;
    }
    return t;
}

node* deleteNode(node* root, int key) {
    if (root == nullptr)
        return root;
    root = splay(root, key);
    if (root->key != key)
        return root;
    node* t;
    if (root->left == nullptr) {
        t = root->right;
        delete(root);
        return t;
    }
    else {
        t = root->left;
        while (t->right != nullptr)
            t = t->right;
        t->right = root->right;
        node* newRoot = t;
        delete(root);
        return newRoot;
    }
}

bool search(node* root, int key) {
    root = splay(root, key);
    return (root != nullptr && root->key == key);
}

int findMax(node* root, int key) {
    root = splay(root, key);
    if (root->key <= key)
        return root->key;
    if (root->left != nullptr)
        return findMax(root->left, key);
    return -1;
}

int findMin(node* root, int key) {
    root = splay(root, key);
    if (root->key >= key)
        return root->key;
    if (root->right != nullptr)
        return findMin(root->right, key);
    return -1;
}

void inOrderTraversal(node* root, int x, int y, ofstream& output) {
    if (root == nullptr)
        return;
    if (root->key >= x && root->key <= y) {
        output << root->key << " ";
        inOrderTraversal(root->left, x, y, output);
        inOrderTraversal(root->right, x, y, output);
    }
    else if (root->key < x)
        inOrderTraversal(root->right, x, y, output);
    else
        inOrderTraversal(root->left, x, y, output);
}

int main() {
    ifstream in("abce.in");
    ofstream out("abce.out");

    int q;
    in >> q;
    node* root = nullptr;

    for (int i = 0; i < q; ++i) {
        int op, x, y;
        in >> op >> x;
        if (op == 1) {
            root = insert(root, x);
        }
        else if (op == 2) {
            root = deleteNode(root, x);
        }
        else if (op == 3) {
            out << search(root, x) << endl;
        }
        else if (op == 4) {
            out << findMax(root, x) << endl;
        }
        else if (op == 5) {
            out << findMin(root, x) << endl;
        }
        else if (op == 6) {
            in >> y;
            inOrderTraversal(root, x, y, out);
            out << endl;
        }
    }

    in.close();
    out.close();

    return 0;
}
