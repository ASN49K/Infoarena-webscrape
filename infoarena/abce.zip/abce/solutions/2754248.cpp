#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

ifstream f("abce.txt");
ofstream g("abce.out");


class btree_node{
public:

    int nr_keys;
    vector<int> keys;
    vector<btree_node*> children;
    bool leaf;

    btree_node(int t, bool le){
        nr_keys=0;
        keys.resize(2*t-1, 0);
        children.resize(2*t, nullptr);
        leaf = le;
    }

    void insert(int val, int t);
    bool search(int val);
    void remove(int val);

    void children_fusion(int i); /// left child's index
    int min_tree(); ///the min of the current (sub)tree
    int max_tree(); ///the max of the current (sub)tree
    void print();
};

void btree_node::print(){
    for(int i=0;i<nr_keys;++i)
    {
        if(!leaf)
            children[i]->print();
        cout<<keys[i]<<" ";
    }
    if(!leaf)
        children[nr_keys]->print();

}

int btree_node::min_tree() {
    if(this->leaf)
        return keys[0];
    return children[0]->min_tree();
}
int btree_node::max_tree() {
    if(this->leaf)
        return keys[nr_keys-1];
    return children[nr_keys]->min_tree();
}

//// after insert in child check if child is filled;
void btree_node::insert(int val, int t) {
    int i=0;
    while(i<nr_keys && val > keys[i])
        ++i;
    if(this->leaf)
    {
        for(int j=nr_keys; j>i; --j)
        {
            keys[j] = keys[j-1];
        }
        keys[i] = val;
        ++nr_keys;
    }
    else{
        auto y = children[i];
        if(y->nr_keys == 2*t-1) ///divide child
        {
            ///  create new child z from 2nd half of child y
            auto z = new btree_node(t, y->leaf);

            for(int j=0;j<t-1;++j)
            {
                z->keys[j] = y->keys[t+j];
                z->children[j] = y->children[t+j]; y->children[t+j] = nullptr;
            }
            z->children[t-1] = y->children[2*t]; y->children[2*t] = nullptr;
            z->nr_keys=t-1;
            y->nr_keys=t-1;
            /// update myself-> shift keys and children with index>i to the right by 1
            for(int j=nr_keys; j>i; --j)
            {
                keys[j] = keys[j-1];
                children[j+1] = children[j];
            }
            ///z becomes the right brother of y
            children[i+1] = z;
            keys[i] = y->keys[t-1]; /// former key was shifted and now replaced with the median if former y;
            ++nr_keys;


            if(val<keys[i])
                y->insert(val, t);
            else
                z->insert(val, t);
        }
        else
            y->insert(val,t);
    }

}

bool btree_node::search(int val) {
    if(leaf){
        int i=0;
        while(i<nr_keys && val > keys[i])
            ++i;
        if(i == nr_keys)
            return false;
        if(val == keys[i])
            return true;
        return false;
    }

    int i=0;
    while(i<nr_keys && val > keys[i])
        ++i;
    if(i==nr_keys)
        return children[i]->search(val);
    if(val == keys[i])
        return true;
    return children[i]->search(val);
}

void btree_node::children_fusion(int i) {
    auto y = children[i];/// t-1 keys;
    auto z = children[i+1];/// t-1 keys;

    y->keys[y->nr_keys++] = keys[i];
    for(int j=0; j<z->nr_keys; ++j)
    {
        y->keys[y->nr_keys+j] = z->keys[j];
        y->children[y->nr_keys+j] = z->children[j];
    }
    y->nr_keys+=z->nr_keys; /// same as += t-1;
    y->children[y->nr_keys] = z->children[z->nr_keys]; /// last child of z becomes the last child of y;
    delete z; /// removed former right child of val;

    --nr_keys; /// current node lost a key; shift the following keys to the left by 1 position;
    for(;i<nr_keys;++i)
    {
        keys[i] = keys[i+1];
        children[i+1] = children[i+2];
    }
}


void btree_node::remove(int val) {
    int i=0;
    while(i<nr_keys && val>keys[i])
        ++i;
    if(this->leaf) ///if this is a leaf and I found the element I just remove it;
    {
        if(i<nr_keys && keys[i] == val)
        {
            --nr_keys;
            for(int j=i; j<nr_keys; ++j)
                keys[j] = keys[j+1];
        }
    }
    else
    {
        int t = (int)children.size() / 2; /// I just realized I can get the value of t in function this way
        /// instead of sending another parameter to the function.....

        if(i<nr_keys && val == keys[i]) /// val is in a non-leaf node;
        {
            if(children[i]->nr_keys > t-1) /// if I have enough elements to the left
            {                              /// I can take the max of the subtree to replace val and then remove it from the subtree;
                keys[i] = children[i]->max_tree();
                children[i]->remove(keys[i]);
            }
            else if(children[i+1]->nr_keys > t-1)  /// analog; taking min from right subtree of val
            {
                keys[i] = children[i+1]->min_tree();
                children[i+1]->remove(keys[i]);
            }
            else ///fuse left and right children then remove val from the updated child
            {
                this->children_fusion(i);
                children[i]->remove(val);
            }
        }
        else
        {
            if(children[i]->nr_keys == t-1) /// if the root of the subtree (possibly) containing val has t-1 keys (it can't have less than that)
            {                               /// removing val may end up reducing the nr of keys below t-1 somewhere in that subtree
                                            /// so this is just a precaution to ensure the subtree can later on fix itself;
                if(i>0 && children[i-1]->nr_keys>t-1) ///try to borrow from the left brother of the node, if there is one
                {
                    children[i]->insert(keys[i-1], t);
                    keys[i-1] = children[i-1]->max_tree();
                    children[i-1]->remove(keys[i-1]);
                    children[i]->remove(val);
                }
                else if(i<nr_keys && children[i+1]->nr_keys>t-1) /// try to borrow from right brother of the node, if there is one
                {
                    children[i]->insert(keys[i], t);
                    keys[i] = children[i+1]->min_tree();
                    children[i+1]->remove(keys[i]);
                    children[i]->remove(val);
                }
                else /// can't borrow, I have to fuse the child with one of his brothers
                {
                    if(i==nr_keys) /// val may be in the last child; fuse with his left brother and remove val from new last child
                    {
                        this->children_fusion(i-1);
                        children[nr_keys]->remove(val);
                    }
                    else
                    {
                        this->children_fusion(i); /// fuses the with his right brother
                        children[i]->remove(val);
                    }

                }
            }
            else
                children[i]->remove(val);
        }

    }


}


//////////////////////////////////////////////////////////////
class btree{
    const int t;
    btree_node* root;

public:
    explicit btree(int t):t(t), root(nullptr){};
    void insert(int val);
    bool search(int val);
    void remove(int val);

    void print();
};

void btree::print(){
    root->print();
}


void btree::insert(int val) {
    if(root == nullptr){

        root = new btree_node(t, true);
        root->nr_keys = 1;
        root->keys[0] = val;
    }
    else{
        if(root->nr_keys == 2*t-1) /// The root doesn't have a father so I have to do the split for it
        {
            auto z=new btree_node(t, root->leaf);
            auto new_root = new btree_node(t, false);

            new_root->nr_keys = 1;
            new_root->keys[0] = root->keys[t-1]; /// median of former root
            new_root->children[0] = root;
            new_root->children[1] = z;

            for(int j=0;j<t-1;++j)
            {
                z->keys[j] = root->keys[t+j];
                z->children[j] = root->children[t+j]; root->children[t+j] = nullptr;
            }
            z->children[t-1] = root->children[2*t]; root->children[2*t] = nullptr;

            z->nr_keys = t-1;
            root->nr_keys = t-1;

            root = new_root;
        }
        root->insert(val, t);
    }
}

bool btree::search(int val) {
    if(root!= nullptr)
        return root->search(val);
    return false;
}

void btree::remove(int val) {
    if(root!= nullptr)
    {
        root->remove(val);
        if(root->nr_keys==0)/// the root only had 1 key and no children/ 2 children that had to fuse
        {
            auto new_root = root->children[0];
            delete root;
            root = new_root;
        }
    }

}

int main() {

    btree tree(100);
    int q, i, opt, x, y;
    f>>q;
    for(i=1;i<=q;++i)
    {
        f>>opt>>x;
        if(opt<4)
        {
            if(opt == 1)
                tree.insert(x);
            else if(opt == 2 && tree.search(x))
                tree.remove(x);
            else
                g<<tree.search(x)<<'\n';
        }
        else
        {
            if(opt == 6)
                f>>y;
        }
    }

    return 0;
}
