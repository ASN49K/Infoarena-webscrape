#include <fstream>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
int v[100005], l[100005], r[100005], nr = 0;

void add(int &nod, int x) {
    if (!nod) {
        nod = ++nr;
        v[nod] = x;
        l[nod] = r[nod] = 0;
        return;
    }
    if (x == v[nod]) return;
    if (x < v[nod]) add(l[nod], x);
    else add(r[nod], x);
}

void scoate(int &nod, int x) {
    if (!nod) return;
    if (x < v[nod]) {
        scoate(l[nod], x);
        return; }
    if (x > v[nod]) {
        scoate(r[nod], x);
        return; }
    if (!l[nod] && !r[nod]) {
        nod = 0;
        return; }
    if (!l[nod]) {
        nod = r[nod];
        return; }
    if (!r[nod]) {
        nod = l[nod];
        return; }
    int succesor = r[nod];
    while (l[succesor]) succesor = l[succesor];
    v[nod] = v[succesor];
    scoate(r[nod], v[succesor]);
}

bool cauta(int nod, int x) {
    while (nod) {
        if      (x < v[nod]) nod = l[nod];
        else if (x > v[nod]) nod = r[nod];
        else return true;
    }
    return false;
}

int maxim(int nod, int x, int rez) {
    while (nod) {
        if (v[nod] <= x) {
            rez = v[nod];
            nod = r[nod]; }
        else nod = l[nod];
    }
    return rez;
}

int minim(int nod, int x, int rez) {
    while (nod) {
        if (v[nod] >= x) {
            rez = v[nod];
            nod = l[nod]; }
        else nod = r[nod];
    }
    return rez;
}

void interval(int nod, int x, int y) {
    if (!nod) return;
    if (v[nod] > x) interval(l[nod], x, y);
    if (v[nod] >= x && v[nod] <= y) fout << v[nod] << " ";
    if (v[nod] < y) interval(r[nod], x, y);
}

int main() {
    int i, rad = 0;
    fin >> i;
    while (i--) {
        int t, x, y;
        fin >> t >> x;
        switch(t) {
            case 1: add(rad, x); break;
            case 2: scoate(rad, x); break;
            case 3: fout << cauta(rad, x) << "\n"; break;
            case 4: fout << maxim(rad, x, -1) << "\n"; break;
            case 5: fout << minim(rad, x, -1) << "\n"; break;
            default:
                fin >> y;
                interval(rad, x, y);
                fout << "\n";
        }
    }
    return 0;
}