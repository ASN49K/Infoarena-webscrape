#include <iostream>
#include <fstream>
std::fstream fin("abce.in");
std::ofstream fout("abce.out");
class avlnode
{
    public:
        int value;
        avlnode *left;
        avlnode *right;
        int height;

        avlnode () {}
        avlnode (int value) : 
        value(value), 
        left(nullptr), 
        right(nullptr),
        height(1) {}
};

class avltree
{
    private:
        avlnode *node;

        int get_value(avlnode *node)
            {return node->value;}
        int get_height(avlnode *node)
            {
                if(node == nullptr)
                    return 0;
                return node->height;
            }
        int get_balance(avlnode *node)
            {
                if(node == nullptr)
                    return 0;
                return get_height(node->left) - get_height(node->right);
            }
        int max(int a, int b)
            {
                if(a>b) return a;
                else return b;
            }
        int update_height(avlnode *node)
            { 
                return 1 + max(get_height(node->left), get_height(node->right)); 
            }
        avlnode* minimum(avlnode *node)
            {
                if(node==nullptr) return nullptr;
                avlnode *current_node = node;
                while(current_node->left!=nullptr)
                    current_node=current_node->left;
                return current_node; 
            }
        avlnode* right_rotation(avlnode *a)
        {
            avlnode *b=a->left;
            avlnode *rightsubtreeof_b = b->right;

            a->left=rightsubtreeof_b;
            b->right=a;

            b->height=update_height(b);
            a->height=update_height(a);

            return b; ///the new root
        }

        avlnode* left_rotation(avlnode *a)
        {
            avlnode *b=a->right;
            avlnode *leftsubtreeof_b = b->left;

            b->left=a;
            a->right=leftsubtreeof_b;

            b->height=update_height(b);
            a->height=update_height(a);

            return b;
        }
        avlnode* balance_tree(avlnode *node, int balance)
        {
            if(balance > 1)
                {
                    int left_balance=get_balance(node->left);
                    if(left_balance >= 0) 
                        return right_rotation(node);
                    if(left_balance < 0) 
                    {
                        node->left=left_rotation(node);
                        return right_rotation(node);                    
                    }
                }
            if(balance < -1)
                {
                    int right_balance = get_balance(node->right);
                    if(right_balance >= 0)
                        return left_rotation(node);
                    if(right_balance < 0)
                        {
                            node->right=right_rotation(node);
                            return left_rotation(node);
                        }
                }
            return node;
        }
        avlnode* insert_node(avlnode *node, int value)
        {
            if(node==nullptr) 
                return new avlnode(value);

            bool inserted = false;

            if(value < node->value) 
            {
                node->left=insert_node(node->left, value);
                inserted=true;
            }
            if(value > node->value) 
            {
                node->right=insert_node(node->right, value);
                inserted=true;
            }

            if(inserted==false) 
                return node;

            node->height=update_height(node);

            int balance=get_balance(node);
            node=balance_tree(node, balance);
            return node;
            
        }
        bool search_node(avlnode *node, int value)
        {
            if(node==nullptr)
                return false;
            if(node->value == value)
                return true;
            if(value < node->value)
                return search_node(node->left, value);
            else return search_node(node->right, value);
        }
        avlnode* delete_node(avlnode *node, int value)
        {
            if(node == nullptr) 
            {
                return node;
            }
            if(node->value > value)
                {node->left = delete_node(node->left, value);}
            else
                if(node->value < value)
                {node->right=delete_node(node->right, value);}

            if(node->left==nullptr || node->right==nullptr)
                {
                    avlnode* child;avlnode *temp;
                    temp=node;
                    child=node->left ? node->left : node->right;
                    if(child == nullptr)
                    {
                        child=node;
                        node=nullptr;
                    }
                    //if one child
                    else
                        {
                        avlnode *child = node->left ? node->left : node->right;
                        node=child;
                        }
                    delete temp;
                }
            else
            {
                avlnode *aux=minimum(node->right); ////substitute with predecesor
                node->value=aux->value;
                node->right=delete_node(node->right, aux->value);
            }
            if(node==nullptr) 
                {return node;}
            node->height=update_height(node);
            int balance = get_balance(node);
            node=balance_tree(node, balance);
            return node; 
        }
        
        avlnode *greatest_smaller_node(avlnode *node, int x, avlnode *result)
        {
            if(node == nullptr) 
                return result;
            if(node->value >= x)
                return greatest_smaller_node(node->left, x, result);
            else
                return greatest_smaller_node(node->right, x, result);
        }
        avlnode *smallest_greater_node(avlnode *node, int x, avlnode *result)
        {
            if(node == nullptr)
                return result;
            if(node->value < x)
                {
                //result->value=node->value;
                return smallest_greater_node(node->right, x, node);
                }
            else
                {
                //result->value=node->value;
                return smallest_greater_node(node->left, x, node);
                }
        }

        void print_xy(avlnode *node, int x, int y)
        {
            if(node == nullptr) return;

            if(x < node->value)
                print_xy(node->left, x, y);
            if(node->value > y)
                print_xy(node->right, x, y);

            if(x <= node->value && node->value <= y)
            {
                fout<< node-> value<<" ";
            }
        }
        
        public:
            avltree() : node(nullptr) {}

            void print_x_to_y(int x, int y)
            {
                print_xy(node, x, y);
                fout<<"\n";
            }

            void insert(int value) { node = insert_node(node, value); }
            void deletion(int value) { node = delete_node(node, value); }
            bool search(int value) { return search_node(node, value); }
            int greatest_smaller(int value)
            {
                int result;
                avlnode *result_;
                result_ = greatest_smaller_node(node, value, nullptr);
                if(result_ != nullptr)
                    result=result_->value;
                return result;
            }
            int smallest_greater(int value)
            {
                int result;
                avlnode *result_;
                result_=smallest_greater_node(node, value, nullptr);
                if(result_ != nullptr)
                    result=result_->value;
                return result;
            }
            void execute(int operation, int x) 
            {switch(operation)
                {
                    case 1:
                        {
                            insert(x);
                            break;
                        }
                    case 2:
                        {
                            deletion(x);
                            break;
                        }
                    case 3: 
                        {
                            
                            fout<<search(x)<<" ";
                            break;
                        }
                    case 4:
                        {
                            greatest_smaller(x);
                            break;
                        }
                    case 5:
                        {
                            smallest_greater(x);
                            break;
                        }
                    
                }
            }
            void inorder(avlnode *node)
        {
            if(node != nullptr)
            {
                inorder(node->left);
                fout<<node->value<<" ";
                inorder(node->right);
            }
        }
            void print() 
            {
                inorder(this->node);
                std::cout<<std::endl;
            }

};
int main()
{
    avltree tree;
    int Q, operation_number, X, Y;
    fin>>Q;
    for(int i=1;i<=Q;i++)
        {
            fin>>operation_number;
            fin>>X;
            if(6 != operation_number)
                {
                    tree.execute(operation_number, X);
                    tree.print();
                }
            else 
            {
                fin>>Y;
                tree.print_x_to_y(X, Y);
                tree.print();
            }
        }
    fout.close();
}