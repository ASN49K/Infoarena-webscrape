#include <fstream>
#import <algorithm>
#import <vector>
#import <map>
#import <set>
#import <deque>
#import <queue>
#import <cassert>
//#import <cmath>
#import <cstring>
#import <cctype>
#import <cstdlib>
#import <stack>
using namespace std;
ifstream cin("abce.in");
ofstream cout("abce.out");
struct nod
{
    int val,pri;
    nod *st,*dr;
    nod(int v,int p,nod* s,nod* d)
    {
        this->st=s;
        this->dr=d;
        this->val=v;
        this->pri=p;
    }
}*S,*nil;
void b_left(nod*&t)
{
    nod*aux=t->st;
    t->st=aux->dr;
    aux->dr=t;
    t=aux;
}
void b_right(nod*&t)
{
    nod*aux=t->dr;
    t->dr=aux->st;
    aux->st=t;
    t=aux;
}
void balance(nod*&t)
{
    if(t->st->pri>t->pri)
    {
        b_left(t);
    }
    else if(t->dr->pri>t->pri)
    {
        b_right(t);
    }
}
void insert(nod*& t,const int& key)
{
    if(t==nil)
    {
        t=new nod(key,rand()+1,nil,nil);
        return;
    }
    if(t->val>key)insert(t->st,key);
    else if(t->val<key)insert(t->dr,key);
    balance(t);
}
void erase(nod*& t,const int& key)
{
    if(t==nil)return;
    if(t->val>key)erase(t->st,key);
    else if(t->val<key)erase(t->dr,key);
    else
    {
        if(t->st==nil && t->dr==nil)
        {
            delete t;
            t=nil;
        }
        else
        {
            if(t->st->pri > t->dr->pri)
            {
                b_left(t);
            }
            else
            {
                b_right(t);
            }
            erase(t,key);
        }
    }
}
bool find(nod*&t,const int& key)
{
    if(t==nil)return 0;
    if(t->val==key)
    {
        return 1;
    }
    if(t->val>key) return find(t->st,key);
    return find(t->dr,key);
}
int rez;
void caut_l(nod*&t,const int& key)
{
    if(t==nil)return;

    if(t->val>key)
    {
        caut_l(t->st,key);
    }
    else
    {
        rez=max(rez,t->val);
        caut_l(t->dr,key);
    }
}
void caut_r(nod*&t,const int& key)
{
    if(t==nil)return;
    if(t->val<key)
    {
        caut_r(t->dr,key);
    }
    else
    {
        rez=min(rez,t->val);
        caut_r(t->st,key);
    }
}
main()
{
    S=nil=new nod(0,0,nullptr,nullptr);
    int q;cin>>q;
    while(q--)
    {
        int cer,x;
        cin>>cer>>x;
        if(cer==1)
        {
            insert(S,x);
        }
        else if(cer==2)
        {
            erase(S,x);
        }
        else if(cer==3)
        {
            cout<<find(S,x)<<'\n';
        }
        else if(cer==4)
        {
            rez=-1;
            caut_l(S,x);
            cout<<rez<<'\n';
        }
        else if(cer==5)
        {
            rez=2e9;
            caut_r(S,x);
            cout<<rez<<'\n';
        }
        else
        {
            cin>>x;
        }
    }

}
