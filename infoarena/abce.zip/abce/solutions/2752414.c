#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define swap(a, b) {void *aux = a; a = b; b = aux;}

typedef struct Node{
    struct Node *parent;
    struct Node *sons[2]; ///0-left, 1-right

    int key; ///0-bleck, 1-red
    void *info;
} *Node, NodeVal;

void fixN(Node);
Node initN(void*, Node);
void insertN(Node*, Node, void*, int (*Comp)(void*, void*));
Node biggestsmallerN(Node, void*, int (*Comp)(void*, void*));
Node smallestbiggerN(Node, void*, int (*Comp)(void*, void*));
Node findN(Node, void*, int (*Comp)(void*, void*));
void eraseN(Node*, void*, int (*Comp)(void*, void*), void (*Free)(void*));
void destroyN(Node*, void (*Free)(void*));
void showN(Node, void*, void*, int (*Comp)(void*, void*), void (*Show)(void*, FILE*), FILE*);

typedef struct Treap{
    Node root;

    int (*Comp)(void*, void*);
    void (*Show)(void*, FILE*);
    void (*Free)(void*);
} *Treap, TreapVal;

Treap initT(int (*Comp)(void*, void*), void (*Show)(void*, FILE*), void (*Free)(void*));
void insertT(Treap*, void*);
int findT(Treap, void*);
void smallestbiggerT(Treap, void*, FILE*);
void biggestsmallerT(Treap, void*, FILE*);
void eraseT(Treap*, void*);
void showT(Treap, void*, void*, FILE*);

/// Int functions ///
int CompInt(void *a, void *b)
{
    return *(int*)a - *(int*)b;
}

void ShowInt(void *a, FILE *fout)
{
    fprintf(fout, "%d", *(int*)a);
}

void FreeInt(void *a)
{
    free(a);
}

/// main ///
int main()
{

    FILE *fin = fopen("abce.in", "r");
    FILE *fout = fopen("abce.out", "w");

    int Q;
    fscanf(fin, "%d", &Q);

    Treap treap = initT(CompInt, ShowInt, FreeInt);

    while (Q--) {
        int task;
        fscanf(fin, "%d", &task);

        switch(task) {
            case 1: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                insertT(&treap, (void*)val);
                break;
            }
            case 2: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                eraseT(&treap, (void*)val);
                break;
            }
            case 3: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                fprintf(fout, "%d\n", findT(treap, (void*)val));
                break;
            }
            case 4: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                biggestsmallerT(treap, val, fout);
                break;
            }
            case 5: {
                int *val = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", val);

                smallestbiggerT(treap, val, fout);
                break;
            }
            default: {
                int *a = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", a);

                int *b = (int*)malloc(sizeof(int));
                fscanf(fin, "%d", b);

                showT(treap, (void*)a, (void*)b, fout);
            }
        }
    }

    return 0;
}

/// Node functions ///
Node initN(void *info, Node parent)
{
    Node ret = (Node)malloc(sizeof(NodeVal));

    ret->parent = parent;
    ret->sons[0] = ret->sons[1] = NULL;
    ret->info = info;
    ret->key = 1;

    return ret;
}

void rotateN(Node *node, int dir)
{
    Node end = (*node)->sons[1 - dir];
    Node moves = end->sons[dir];

    end->parent = (*node)->parent;
    (*node)->parent = end;
    end->sons[dir] = *node;

    (*node)->sons[1 - dir] = moves;
    if (moves) {
        moves->parent = *node;
    }

    if (end->parent) {
        if (end->parent->sons[0] == *node) {
            end->parent->sons[0] = end;
        } else {
            end->parent->sons[1] = end;
        }
    }
    *node = end;

}

void fixN(Node node)
{
    if (!node || !(node->parent)) {
        return;
    }

    if (node->key ^ node->parent->key) {
        return;
    }

    Node parent = node->parent;
    Node granpa = parent->parent;
    Node uncle = (granpa->sons[0] == parent ? granpa->sons[1] : granpa->sons[0]);

    if (uncle && uncle->key) {
        uncle->key ^= 1;
        parent->key ^= 1;
        granpa->key ^= 1;
        fixN(granpa);
        return;
    }

    int dir = (granpa->sons[0] == parent ? 0 : 1);

    if (parent->sons[1 - dir] == node) {
        rotateN(&parent, dir);
    }

    rotateN(&granpa, 1 - dir);
    granpa = granpa->sons[1 - dir];

    granpa->key ^= 1;
    parent->key ^= 1;
}

void insertN(Node *root, Node parent, void *info, int (*Comp)(void*, void*))
{
    if (!*root) {
        *root = initN(info, parent);
        if (parent) {
            parent->sons[Comp(info, parent->info) > 0] = *root;
        }

        fixN(*root);
        return;
    }

    if (Comp(info, (*root)->info) < 0) {
        insertN(&((*root)->sons[0]), *root, info, *Comp);
    } else {
        insertN(&((*root)->sons[1]), *root, info, *Comp);
    }
}

Node biggestsmallerN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    if (Comp(root->info, info) > 0) {
        return biggestsmallerN(root->sons[0], info, *Comp);
    } else {
        Node node = biggestsmallerN(root->sons[1], info, *Comp);
        return (node ? node : root);
    }
}

Node smallestbiggerN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    if (Comp(root->info, info) < 0) {
        return smallestbiggerN(root->sons[1], info, *Comp);
    } else {
        Node node = smallestbiggerN(root->sons[0], info, *Comp);
        return (node ? node : root);
    }
}

Node findN(Node root, void *info, int (*Comp)(void*, void*))
{
    if (!root) {
        return NULL;
    }

    int diff = Comp(root->info, info);
    if (!diff) {
        return root;
    } else if (diff < 0) {
        return findN(root->sons[1], info, *Comp);
    } else {
        return findN(root->sons[0], info, *Comp);
    }
}

void fixsonN(Node node, int dir)
{
    ///Case 1
    if (node->key) {
        rotateN(&node, dir);
        fixN(node->sons[dir]->sons[1 - dir]);
        return;
    }

    ///Case 2
    if (node->sons[1 - dir]->key) {
        rotateN(&node, dir);
        node->key = 0;
        node->sons[dir]->key = 1;
        fixsonN(node->sons[dir], dir);
        return;
    }

    ///Case 3
    if (node->sons[1 - dir]->sons[1 - dir] && node->sons[1 - dir]->sons[1 - dir]->key) {
        rotateN(&node, dir);
        node->sons[1 - dir]->key = 0;
        return;
    }

    ///Case 4
   if (node->sons[1 - dir]->sons[dir] && node->sons[1 - dir]->sons[dir]->key) {
        rotateN(&(node->sons[1 - dir]), 1 - dir);
        rotateN(&node, dir);
        node->key = 0;
        return;
    }

    ///Case 5
    node->sons[1 - dir]->key = 1;
    if (node->parent) {
        dir = !(node->parent->sons[0] == node);
        fixsonN(node->parent, dir);
    }
}

void eraseN(Node *root, void *info, int (*Comp)(void*, void*), void (*Free)(void*))
{
    Node node = findN(*root, info, *Comp);
    if (!node) {
        return;
    }

    if (node->sons[0] && node->sons[1]) {
        Node replace = biggestsmallerN(node->sons[0], node->info, *Comp);
        swap(node->info, replace->info);
        node = replace;
    }

    Node parent = node->parent;
    Node replace;
  if (node->sons[0]) {
        replace = node->sons[0];
    } else if (node->sons[1]) {
        replace = node->sons[1];
    } else {
        replace = NULL;
    }

    if (replace) {
        replace->parent = parent;
    }

    int diff, dir = -1;

    if (node == *root) {
        *root = replace;
    } else {
        if (parent->sons[0] == node) {
            parent->sons[0] = replace;
            dir = 0;
        } else {
            parent->sons[1] = replace;
            dir = 1;
        }

    }

    diff = node->key ^ (replace ? replace->key : 0);
    destroyN(&node, *Free);

    if (diff || replace == *root) {
        if (replace) {
            replace->key = 0;
        }
        return;
    }

    if (dir != -1) {
        fixsonN(parent, dir);
    }
}

void showN(Node root, void *a, void *b, int (*Comp)(void*, void*), void (*Show)(void*, FILE*), FILE *fout)
{
    if (!root) {
        return;
    }

    showN(root->sons[0], a, b, *Comp, *Show, fout);

    if (Comp(a, root->info) <= 0 && Comp(root->info, b) <= 0) {
        Show(root->info, fout);
        fprintf(fout, " ");
    }

    showN(root->sons[1], a, b, *Comp, *Show, fout);
}

void destroyN(Node *node, void (*Free)(void*))
{
    Free((*node)->info);
    free(*node);
    *node = NULL;
}

/// Treap functions ///
Treap initT(int (*Comp)(void*, void*), void (*Show)(void*, FILE*), void (*Free)(void*))
{
    Treap ret = (Treap)malloc(sizeof(TreapVal));

    ret->root = NULL;
    ret->Comp = Comp;
    ret->Show = Show;
    ret->Free = Free;

    return ret;
}

void insertT(Treap *treap, void *info)
{
    insertN(&((*treap)->root), NULL, info, *((*treap)->Comp));

    while ((*treap)->root && (*treap)->root->parent) {
        (*treap)->root = (*treap)->root->parent;
    }

    if ((*treap)->root && (*treap)->root->key) {
        (*treap)->root->key ^= 1;
    }
}

int findT(Treap treap, void *info)
{
    return findN(treap->root, info, *(treap->Comp)) != NULL;
}

void smallestbiggerT(Treap treap, void *info, FILE *fout)
{
    void *out = smallestbiggerN(treap->root, info, *(treap->Comp))->info;
    (treap->Show)(out, fout);
    fprintf(fout, "\n");
}

void biggestsmallerT(Treap treap, void *info, FILE *fout)
{
    void *out = biggestsmallerN(treap->root, info, *(treap->Comp))->info;
    (treap->Show)(out, fout);
    fprintf(fout, "\n");
}

void eraseT(Treap *treap, void *info)
{
    eraseN(&((*treap)->root), info, *((*treap)->Comp), *((*treap)->Free));
    while ((*treap)->root && (*treap)->root->parent) {
        (*treap)->root = (*treap)->root->parent;
    }
    if ((*treap)->root && (*treap)->root->key) {
        (*treap)->root->key ^= 1;
    }
}

void showT(Treap treap, void *a, void *b, FILE *fout)
{
    showN(treap->root, a, b, *(treap->Comp), *(treap->Show), fout);
    fprintf(fout, "\n");
}
