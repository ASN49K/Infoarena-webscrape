#include <fstream>
#include <filesystem>
#include<iostream>
using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
/// clasa este luata de la laborator 
class BST{
protected:
    struct Node{
        int val;
        Node* left;
        Node* right;
        Node(int x){
            val = x;
            left=nullptr;
            right=nullptr;
        }
    };
    Node* root;
    Node* NIL_Base;
    void inorder_Helper(Node* root,int lower,int upper){
            if(root !=nullptr && root!=NIL_Base){
                if(root->val>= lower)
                    inorder_Helper(root -> left,lower,upper);
                if(root->val >= lower && root-> val <= upper)
                    fout<< root ->val <<' ';
                if(root->val <= upper)
                    inorder_Helper(root->right,lower,upper);
            }
        }
    Node* search_helper(Node* root, int x){
        if(root ==nullptr || root == NIL_Base){
            return nullptr;
        }
        else{
            if(x == root->val){
                return root;
            }
            else{
                if(x < root->val){
                    return search_helper(root->left,x);
                }
                else{
                    return search_helper(root->right,x);
                }
            }
        }
    }
public:
    BST(){ root =nullptr; NIL_Base = nullptr;}
    virtual void del(int x) = 0;
    virtual void add(int x) = 0;
    bool search(int x){
        if (search_helper(root,x)==nullptr)
            return false;
        else
            return true;
    }
    void inorder(int x,int y ){
        inorder_Helper(root,x,y);
    }

};

/// Am ales Red-Black Tree
class RBT : public BST{
private:
    
    struct RBNode:public BST::Node{
        bool color; // 0- red 1-black
        RBNode* parent;
        RBNode(int x) : BST::Node(x), color(0), parent(nullptr) {}
    };
    RBNode* NIL;
    void init_NIL(){
        
        NIL = new RBNode(0);
        NIL->color = 1;
        NIL->left = nullptr;
        NIL->parent = nullptr;
        NIL-> right = nullptr;
        BST::NIL_Base = NIL;
        BST::root = NIL;
    }
    RBNode* asRB(Node* n){ return static_cast<RBNode*>(n); }
    void rotate_left(RBNode* n){
        RBNode* m = asRB(n->right);
        n->right = m->left;
        if(m->left != NIL){
            asRB(m->left)->parent = n;
        }
        m->parent = n->parent;
        if(n->parent == nullptr){
            BST::root = m;
        }
        else if( n == asRB(n->parent->left))
            n->parent->left = m;
        else
            n->parent->right = m;
        m->left = n;
        n->parent = m;
    }
    void rotate_right(RBNode* n){
         RBNode* m = asRB(n->left);
        n->left = m->right;
        if(m->right != NIL){
            asRB(m->right)->parent = n;
        }
        m->parent = n->parent;
        if(n->parent == nullptr){
            BST::root = m;
        }
        else if( n == asRB(n->parent->right))
            n->parent->right = m;
        else
            n->parent->left = m;
        m->right = n;
        n->parent = m;
    }
    void replace(RBNode* x, RBNode* y){
        if(y ->parent == nullptr){
            BST::root = x;
        }
        else if( y == asRB(y->parent->left)){
            y->parent->left = x;
        }
        else{
            y->parent->right = x;
        }
        x->parent = y->parent;
    }
    void del_fix(RBNode* r){
        while(r!=asRB(root) && r->color == 1){
            if(r== r->parent->left){
                RBNode* w = asRB(r->parent->right);
                if(w->color == 0 ){
                    w->color = 1;
                    r->parent->color = 0;
                    rotate_left(r->parent);
                    w = asRB(r->parent->right);
                }
                if(asRB(w->left)->color ==1 && asRB(w->right)->color ==1){
                    w->color = 0;
                    r = r->parent;
                }
                else{
                    if(asRB(w->right)->color == 1){
                        asRB(w->left)->color =1;
                        w->color = 0;
                        rotate_right(w);
                        w= asRB(r->parent->right);
                    }
                    w->color = r->parent->color;
                    r->parent->color = 1;
                    asRB(w->right)->color = 1;
                    rotate_left(r->parent);
                    r = asRB(BST::root);
                }

            }
            else{
                RBNode* w = asRB(r->parent->left);
                if(w->color == 0){
                    w->color = 1;
                    r->parent->color = 0;
                    rotate_right(r->parent);
                    w = asRB(r->parent->left);
                }
                if(asRB(w->right)->color ==1 && asRB(w->left)->color ==1){
                    w->color = 0;
                    r = r->parent;
                }
                else{
                    if(asRB(w->left)->color == 1){
                        asRB(w->right)->color =1;
                        w->color = 0;
                        rotate_left(w);
                        w= asRB(r->parent->left);
                    }
                    w->color = r->parent->color;
                    r->parent->color = 1;
                    asRB(w->left)->color = 1;
                    rotate_right(r->parent);
                    r = asRB(BST::root);
                }
            }
        }

        r->color = 1;
}
    void add_fix(RBNode* r){
        while(r->parent !=nullptr && r->parent->parent != nullptr && r->parent->color == 0){
                if(r->parent == r->parent->parent->left){
                    RBNode* unc = asRB(r->parent->parent->right);
                    if(unc->color ==0 ){
                        r->parent->color =1;
                        unc->color =1;
                        r->parent->parent->color = 0;
                        r = r->parent->parent;
                    }
                    else{
                        if(r == r->parent->right){
                            r = r->parent;
                            rotate_left(r);
                        }
                        r->parent->color =1;
                        r->parent->parent->color =0 ;
                        rotate_right(r->parent->parent);
                    } 
                }
                else{
                    RBNode* unc = asRB(r->parent->parent->left);
                    if(unc->color ==0 ){
                        r->parent->color =1;
                        unc->color =1;
                        r->parent->parent->color = 0;
                        r = r->parent->parent;
                    }
                    else{
                        if(r == r->parent->left){
                            r = r->parent;
                            rotate_right(r);
                        }
                        r->parent->color =1;
                        r->parent->parent->color =0 ;
                        rotate_left(r->parent->parent);
                    } 
                }
        }
        asRB(BST::root)->color = 1;
}
public:
    RBT(){init_NIL();}

    void del(int x) override{
        RBNode*  z = asRB(search_helper(BST::root,x));
        if(z!= NIL && z!= nullptr){
            RBNode* y = z;
            RBNode* replacement;
            bool origin_color = y->color;
            if(z->left == NIL){
                replacement = asRB(z->right);
                replace(asRB(z->right),z);
            }
            else if(z->right == NIL){
                replacement = asRB(z->left);
                replace(asRB(z->left),z);
            }
            else{
                y = asRB(z->right);
                while(y->left != NIL){
                    y = asRB(y->left);
                }
                origin_color = y->color;
                replacement = asRB(y->right);
                if(y->parent == z){
                    replacement->parent = y;
                }
                else{
                    replace(asRB(y->right),y);
                    y->right = z->right;
                    asRB(y->right)->parent = y;

                }
                replace(y,z);
                y->left = z->left;
                asRB(y->left)->parent = y;
                y->color = z->color;
            }
            delete z;
            if(origin_color == 1)
                del_fix(replacement);
        }

    }
    void add(int x) override{
        RBNode* b = new RBNode(x);
        b->left = NIL;
        b->right = NIL;
        b->parent = nullptr;
        RBNode* y = nullptr;
        RBNode* current = asRB(BST::root);
        while(current != NIL){
            y= current;
            if(b->val < current->val)
                current = asRB(current->left);
            else
                current = asRB(current->right);
        }
        b->parent = y;
        if(y == nullptr) 
            BST::root = b;
        else if(b->val < y->val)
            y->left = b;
        else 
            y->right = b;
        b->color = 0;
        add_fix(b);
    }
    void predecessor(int x){
        RBNode* current =   asRB(BST::root);
        RBNode* result = NIL;
        while(current != NIL){
            if(current->val <=x){
                result = current;
                current = asRB(current->right);
            }else{
                current = asRB(current->left);
            }
        }
        if(result != NIL)
            fout<<result->val<<"\n";
    }
    void successor(int x){
        RBNode* current =   asRB(BST::root);
        RBNode* result = NIL;
        while(current != NIL){
            if(current->val >=x){
                result = current;
                current = asRB(current->left);
            }else{
                current = asRB(current->right);
            }
        }
        if(result != NIL)
            fout<<result->val<<"\n";
    }

};
int main (){
    
    int n;
    fin>>n;
    cout<<n;
    RBT tree;
    for(int i=1;i<=n;i++){
        int op;
        fin>>op;
        switch(op){
            case 1:{
                int x;
                fin>>x;
                tree.add(x);
                break;
            }
            case 2:{
                int x;
                fin>>x;
                tree.del(x);
                break;
            }
            case 3:{
                int x;
                fin>>x;
                fout<<tree.search(x)<<'\n';
                break;
            }
            case 4:{
                int x;
                fin>>x;
                tree.predecessor(x);
                break;
            }
            case 5:{
                int x;
                fin>>x;
                tree.successor(x);
                break;
            }
            case 6:{
                int lower,upper;
                fin>>lower>>upper;
                tree.inorder(lower,upper);
                fout<<"\n";
                break;
            }
        }
    }
    return 0;
}