//voiam sa fac ca sa imi dea mai multe puncte la arhiva educationala
//dar nu imi da :(
//deci nu mai fac problema :)

#include <fstream>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef tree<
int,
null_type,
less<int>,
rb_tree_tag,
tree_order_statistics_node_update> ordered_set;

ifstream in("abce.in");
ofstream out("abce.out");
int q;
ordered_set s;

int main()
{
    in>>q;

    int tip, x;
    while(q--)
    {
        in>>tip;

        if(tip == 1)
        {
            in>>x;
            s.insert(x);
        }
        else if(tip == 2)
        {
            in>>x;
            s.erase(x);
        }
        else if(tip == 3)
        {
            in>>x;
            int cnt = s.order_of_key(x);

            auto it = s.find_by_order(cnt);
            if(it != s.end() && (*it) == x)
            {
                out<<1<<'\n';
            }
            else
            {
                out<<0<<'\n';
            }
        }
        else
        {
            return 1;
        }
    }
    return 0;
}
