#include <iostream>
#include <fstream>

using namespace std;

class Noduri {
public:
    long val;
    Noduri *st, *dr;

    explicit Noduri(long val=0, Noduri *st=NULL, Noduri *dr=NULL) {
        this->val = val;
        this->st = st;
        this->dr = dr;
    }
};

Noduri* zig(Noduri* nod){
    Noduri* n = nod->st;
    if(!n){
        return nod;
    }
    nod->st = n->dr;
    n->dr = nod;
    return n;
}

Noduri* zag(Noduri* nod){
    Noduri* n = nod->dr;
    if(!n){
        return nod;
    }
    nod->dr = n->dr;
    n->st = nod;
    return n;
}

Noduri* splay(long curent, Noduri* nod){
    if(!nod)
        return nod;
    if(curent == nod->val)
        return nod;
    if(curent < nod->val){
        if(!nod->st)
            return nod;
        if(curent < nod->st->val){
            nod->st->st = splay(curent, nod->st->dr);
            nod = zig(nod);
        }
        else if(curent > nod->st->val)
            nod->st->dr = splay(curent, nod->st->dr);
        if(nod->st->dr)
            nod->st = zag(nod->st);
        if(!nod->st)
            return zig(nod);
        else return zag(nod);
    }
    else {
        if (!nod->dr)
            return nod;
        if (curent < nod->dr->val) {
            nod->dr->st = splay(curent, nod->dr->st);
            if (nod->dr->st)
                nod->dr = zag(nod->dr);
         }
        else if(curent > nod->dr->val){
            nod->dr->dr = splay(curent, nod->dr->dr);
            nod = zag(nod);
        }
        if(!nod->dr)
            return zag(nod);
        else return zig(nod);
        }
}

Noduri* insert(long curent, Noduri* rad){
    if(!rad){
        rad = new Noduri(curent);
        return rad;
    }
    Noduri* nod = rad;
    while(true){
        if(curent < nod->val){
            if(!nod->st){
                nod->st = new Noduri(curent);
                return rad;
            }
            else nod = nod->st;
        }
        else{
            if(!nod->dr){
                nod->dr = new Noduri(curent);
                return rad;
            }
            else nod = nod->dr;
        }
    }

}

Noduri* sterge(long curent, Noduri* rad){
    if(!rad)
        return rad;
    if(curent < rad->val){
        rad->st = sterge(curent, rad->st);
        return rad;
    }
    else if(curent > rad->val){
        rad->dr = sterge(curent, rad->dr);
        return rad;
    }
    else{
        if(!rad->st)
            return rad->st;
        else if(!rad->dr)
            return rad->dr;
        else{
            Noduri* next_nod = rad->dr;
            while(next_nod->st)
                    next_nod = next_nod->st;
            rad->val = next_nod->val;
            rad->dr = sterge(next_nod->val, rad->dr);
            return rad;
        }
    }
}

int exista(long curent, Noduri* rad){
    if(!rad)
        return 0;
    Noduri* nod = rad;
    while(nod){
        if(curent < nod->val)
            nod = nod->st;
        else if(curent > nod->val)
            nod = nod->dr;
        else return 1;
    }
    return 0;
}

Noduri* mic(long curent, Noduri* rad){
    rad = splay(curent, rad);
    if(!rad)
        return rad;
    if(rad->val <= curent)
        return rad;
    while(true){
        if(rad->st and rad->st->val <= curent)
            rad = rad->st;
        else if(rad->dr and rad->dr->val <= curent)
            rad = rad->dr;
        else return splay(curent, rad);
    }
}

Noduri* mare(long curent, Noduri* rad){
    rad = splay(curent, rad);
    if(!rad)
        return rad;
    if(rad->val <= curent)
        {if(rad->dr){
            rad = rad->dr;
            while(rad->st)
                rad = rad->st;
            return rad;
    }
        else return NULL;}
    while(true){
        if(rad->st && rad->st->val <= curent)
            rad = rad->st;
        else if(rad->dr && rad->dr->val <=curent)
                if(rad->dr->st){
                    rad = rad->dr->st;
                    while(rad->st)
                        rad = rad->st;
                    return rad;
                }
                else return rad->dr;
            else return splay(curent, rad);
    }
}

int main() {
    int ok = 1;
    Noduri* radacina = NULL;

    ifstream fin("abce.in");
    ofstream fout("abce.out");
    long q;
    fin >> q;
    for (int i = 0; i < q; i++) {
        long actiune, val;
        fin >> actiune >> val;
        if (actiune == 1) {
            if (ok) {
                radacina = new Noduri(val);
                ok = 0;
            }
            else {
                radacina = insert(val, radacina);
            }
        }
        else if (actiune == 2) {
            radacina = sterge(val, radacina);
        }
        else if (actiune == 3) {
            fout << exista(val, radacina) << endl;
        }
        else if (actiune == 4) {
            fout << mic(val,radacina)->val << endl;
        }
        else if (actiune == 5) {
            fout << mare(val, radacina)->val << endl;
        }
        else if (actiune == 6) {
            int val2;
            fin >> val2;
            Noduri* a = mare(val, radacina);
            while(a){
                if(a->val <= val2){
                    fout << a->val << " ";
                    a = mare(a->val, a);
                    }
                }
            fout << endl;
        }
    }
    fin.close();
    fout.close();
    return 0;
}
