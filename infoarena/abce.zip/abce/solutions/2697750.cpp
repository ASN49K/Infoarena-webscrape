#include<bits/stdc++.h>
using namespace std;

set<int> arbore;
set<int> :: iterator it;

int main() {
    int operatii, o, x, y;
    cin >> operatii;
    while (operatii--) {
        cin >> o >> x;
        switch(o) {
            case 1:
                arbore.insert(x);
                break;
            case 2:
                arbore.erase(x);
                break;
            case 3:
                if (arbore.find(x) != arbore.end())
                    cout << "1\n";
                else 
                    cout << "0\n";
                break;
            case 4: 
                it = arbore.lower_bound(x);
                it--;
                cout << *it << "\n";
                break;
            case 5: 
                it = arbore.lower_bound(x);
                cout << *it << "\n";
                break;
            case 6: 
                cin >> y;
                for (it = arbore.lower_bound(x); *it <= y && it != arbore.end(); it++) 
                    cout << *it << " ";
                cout << "\n";
                break;
        }
    }
}
