#include <iostream>
#include <fstream>
#include <set>
#include <climits>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

struct node {
    int key;
    node* left, * right;
    node* parent;
};

node* newNode(int key) {
    node* t = new node;
    t->key = key;
    t->left = t->right = t->parent = nullptr;
    return t;
}

node* rightRotate(node* x) {
    node* y = x->left;
    x->left = y->right;
    if (y->right != nullptr) {
        y->right->parent = x;
    }
    y->right = x;
    y->parent = x->parent;
    x->parent = y;
    return y;
}

node* leftRotate(node* x) {
    node* y = x->right;
    x->right = y->left;
    if (y->left != nullptr) {
        y->left->parent = x;
    }
    y->left = x;
    y->parent = x->parent;
    x->parent = y;
    return y;
}

node* splay(node* root, int key) {
    if (root == nullptr || root->key == key)
        return root;

    if (root->key > key) {
        if (root->left == nullptr)
            return root;
        if (root->left->key > key) {
            root->left->left = splay(root->left->left, key);
            root = rightRotate(root);
        }
        else if (root->left->key < key) {
            root->left->right = splay(root->left->right, key);
            if (root->left->right != nullptr)
                root->left = leftRotate(root->left);
        }
        return (root->left == nullptr) ? root : rightRotate(root);
    }
    else {
        if (root->right == nullptr)
            return root;
        if (root->right->key > key) {
            root->right->left = splay(root->right->left, key);
            if (root->right->left != nullptr)
                root->right = rightRotate(root->right);
        }
        else if (root->right->key < key) {
            root->right->right = splay(root->right->right, key);
            root = leftRotate(root);
        }
        return (root->right == nullptr) ? root : leftRotate(root);
    }
}

node* insert(node* root, int key) {
    if (root == nullptr)
        return newNode(key);

    root = splay(root, key);
    if (root->key == key)
        return root;

    node* t = newNode(key);
    if (root->key > key) {
        t->right = root;
        t->left = root->left;
        if (root->left != nullptr) {
            root->left->parent = t;
        }
        root->left = nullptr;
    }
    else {
        t->left = root;
        t->right = root->right;
        if (root->right != nullptr) {
            root->right->parent = t;
        }
        root->right = nullptr;
    }
    t->parent = nullptr;
    return t;
}

node* deleteNode(node* root, int key) {
    if (root == nullptr)
        return root;

    root = splay(root, key);
    if (root->key != key)
        return root;

    node* t;
    if (root->left == nullptr) {
        t = root;
        root = root->right;
    }
    else {
        t = root;
        root = splay(root->left, key);
        root->right = t->right;
        if (t->right != nullptr) {
            t->right->parent = root;
        }
    }
    delete t;
    return root;
}

int search(node* root, int key) {
    root = splay(root, key);
    if (root == nullptr || root->key != key)
        return 0;
    return 1;
}

int findMax(node* root, int key) {
    node* maxNode = nullptr;
    while (root != nullptr) {
        if (root->key <= key) {
            if (maxNode == nullptr || root->key > maxNode->key)
                maxNode = root;
            root = root->right;
        }
        else {
            root = root->left;
        }
    }
    return maxNode->key;
}

int findMin(node* root, int key) {
    node* minNode = nullptr;
    while (root != nullptr) {
        if (root->key >= key) {
            if (minNode == nullptr || root->key < minNode->key)
                minNode = root;
            root = root->left;
        }
        else {
            root = root->right;
        }
    }
    return minNode->key;
}

void inorder(node* root, set<int>& sortedSet) {
    if (root == nullptr)
        return;
    inorder(root->left, sortedSet);
    sortedSet.insert(root->key);
    inorder(root->right, sortedSet);
}

void printSortedRange(node* root, int minX, int maxX) {
    set<int> sortedSet;
    inorder(root, sortedSet);
    for (int num : sortedSet) {
        if (num >= minX && num <= maxX)
            fout << num << " ";
    }
}

int main() {
    int Q;
    fin >> Q;

    node* root = nullptr;

    for (int i = 0; i < Q; i++) {
        int operation;
        fin >> operation;

        if (operation == 1) {
            int X;
            fin >> X;
            root = insert(root, X);
        }
        else if (operation == 2) {
            int X;
            fin >> X;
            root = deleteNode(root, X);
        }
        else if (operation == 3) {
            int X;
            fin >> X;
            fout << search(root, X) << "\n";
        }
        else if (operation == 4) {
            int X;
            fin >> X;
            fout << findMax(root, X) << "\n";
        }
        else if (operation == 5) {
            int X;
            fin >> X;
            fout << findMin(root, X) << "\n";
        }
        else if (operation == 6) {
            int X, Y;
            fin >> X >> Y;
            printSortedRange(root, X, Y);
            fout << "\n";
        }
    }

    fin.close();
    fout.close();

    return 0;
}
