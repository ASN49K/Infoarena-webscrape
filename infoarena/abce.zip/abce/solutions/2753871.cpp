#include <bits/stdc++.h>
#include <stdlib.h>

using namespace std;
ifstream fin("abce.in");
ofstream fout("abce.out");
class SkipNode{
public:
    int value;
    SkipNode** forw;

    SkipNode(int val, int lvl){ //definim un nod nou cu valoarea val si un vector de pointeri continand  lvl+1 elem ce indica urmatorul nod de pe nivelul lvl

    forw = new SkipNode*[lvl +1];
    memset(forw,0,sizeof(SkipNode*)*(lvl + 1));
    this->value = val;
    }
};

class SkipList{
public:
    SkipNode* first; //primul nod va fi initializat cu -1 si "nu va face parte" din lista cu valoare
    int level;
    int max_lvl;

    SkipList(int max_lvl){
    this->max_lvl = max_lvl;
    this->level = 0;

    first = new SkipNode(-1,max_lvl); //cream nodul "nul" in fata caruia vor fi inserate toate celelalte noduri.
    }

    SkipNode* createNode(int val, int level){
        SkipNode* new_node = new SkipNode(val,level);
        return new_node;

    }

    int RNL(){  // choosing random node level for new node
    int i = 0;
    int r =rand()%2;

    while(r && i < max_lvl){
        i++;
        r =rand()%2;
    }
    return i;

    }



    bool searchValue(int value){
    SkipNode* curr = first;

    for(int i = level; i >= 0; i--){
        while(curr->forw[i] != NULL && curr->forw[i]->value < value)
            curr = curr->forw[i];
    }

    if(curr->forw[0] == NULL) //am ajuns la finalul listei si nu am gasit nodul
        return 0;

    if(curr->forw[0]->value == value)
        return 1;

    return 0;
    }

    void insertNode(int value){


        SkipNode* curr = first;
        SkipNode* new_link[max_lvl+1]; //vector de pointeri catre cel mai mare nod mai mic decat nodul care va fi inserat pentru fiecare nivel din lista


        for(int i = level; i >= 0; i--){
            while(curr->forw[i] != NULL && curr->forw[i]->value < value)
                curr = curr->forw[i];
            new_link[i] = curr;
        }


            int rlevel = RNL();
            if(rlevel > level){
                for(int i = level + 1; i <= rlevel; i++)
                    new_link[i] = first;

                level = rlevel;

            }
            SkipNode* n = createNode(value, rlevel);

            for(int i = 0; i <= rlevel; i++){
                n->forw[i] = new_link[i]->forw[i];
                new_link[i]->forw[i] = n;
            }



    }

    void Print(){
    for(int i = level; i >= 0; i--){
        SkipNode* curr = first->forw[i];
        cout<<"\nElements on level "<<i<<": ";
        while(curr != NULL ){
            cout<<curr->value<<" ";
            curr = curr->forw[i];}
    }
    cout<<"\n";

    }

    void DeleteNode(int value){

        SkipNode* curr = first;
        SkipNode* new_link[max_lvl+1];

        for(int i = level; i >= 0; i--){
            while(curr->forw[i] != NULL && curr->forw[i]->value < value)
                curr = curr->forw[i];
            new_link[i] = curr;
        }
        curr = curr->forw[0];
        if(curr->value == value){
            for(int i = 0; i <= level; i++){
                    if(new_link[i]->forw[i] != curr)
                    break;
                new_link[i]->forw[i] = curr->forw[i];
            }
        }

    }

    void Operation4(int x){
        SkipNode* curr = first;
         for(int i = level; i >= 0; i--){
        while(curr->forw[i] != NULL && curr->forw[i]->value <= x)
            curr = curr->forw[i];
    }
        fout<<curr->value<<"\n";
    }
    void Operation5(int x){
        SkipNode* curr = first;
         for(int i = level; i >= 0; i--){
        while(curr->forw[i] != NULL && curr->forw[i]->value < x)
            curr = curr->forw[i];
    }
    curr = curr->forw[0];
        fout<<curr->value<<"\n";

    }

    void Operation6(int x, int y){
        SkipNode* curr = first;
         for(int i = level; i >= 0; i--){
        while(curr->forw[i] != NULL && curr->forw[i]->value < x )
            curr = curr->forw[i];
    }
    //curr = curr->forw[0];
    while(curr->forw[0] != NULL && curr->forw[0]->value <= y  ){
        fout<<curr->forw[0]->value<<" ";
        curr = curr->forw[0];
    }
    fout<<"\n";

    }

};



int n, x, y,comanda;
int main(){
    srand(time(0));
    SkipList lst(10);
    fin>> n;
    for(int i = 1 ; i <= n; i++){
        fin>>comanda;
        switch(comanda){
    case 1:{
        fin>>x;
        lst.insertNode(x);
        break;}
    case 2:{
        fin>>x;
        lst.DeleteNode(x);
        break;}
    case 3:{
        fin>>x;
        if(lst.searchValue(x) == 1)
            fout<<1<<"\n";
        else
            fout<<0<<"\n";
        break;}
    case 4:{
        fin>>x;
        lst.Operation4(x);
        break;}
    case 5:{
        fin>>x;
        lst.Operation5(x);
        break;}
    case 6:{
        fin>>x>>y;
        lst.Operation6(x,y);
        break;}



        }
    }


    fin.close();
    fout.close();




    return 0;
}
