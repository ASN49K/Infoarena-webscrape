#include <iostream>
#include <fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class RBT {
	struct Node {
		Node* parinte;
		Node* st;
		Node* dr;
		int val;
		bool culoare;//rosu = 1, negru = 0
		Node(int x, bool culoare=1) {
			val = x;
			parinte = nullptr;
			st = nullptr;
			dr = nullptr;
			this->culoare = culoare;
		}
	};

	Node* root;
	//Node* NIL;

	Node* addHelper(Node*& root, int val, Node* p)
	{
		if (root == nullptr) {
			root = new Node(val);
			root->parinte = p;
			return root;
		}
		else
		{
			if (val < root->val)
			{
				return addHelper(root->st, val, root);
			}
			else {
				return addHelper(root->dr, val, root);
			}
		}
	}

	void leftRotation(Node*& root, Node*& x)
	{
		Node* y = x->dr;
		x->dr = y->st;

		if (y->st != nullptr)
			y->st->parinte = x;

		y->parinte = x->parinte;

		if (x->parinte == nullptr)
			root = y;
		else
			if (x->parinte->st == x)
				x->parinte->st = y;
			else
				if (x->parinte->dr == x)
					x->parinte->dr = y;

		y->st = x;
		x->parinte = y;

	}

	void rightRotation(Node*& root, Node*& y)
	{
		Node* x = y->st;
		y->st = x->dr;

		if (x->dr != nullptr)
			x->dr->parinte = y;

		x->parinte = y->parinte;

		if (y->parinte == nullptr)
			root = x;
		else
			if (y->parinte->st == y)
				y->parinte->st = x;
			else
				if (y->parinte->dr == y)
					y->parinte->dr = x;
		x->dr = y;
		y->parinte = x;
	}

	void FixInsert(Node*& root, Node*& act)
	{
		
		
		while (act->parinte != nullptr && act->parinte->culoare == 1)
		{
			Node* tata = act->parinte;
			if (tata->parinte != nullptr && tata->parinte->st == tata)
			{
				Node* bunic = tata->parinte;
				if (bunic->dr!=nullptr && bunic->dr->culoare == 1)
				{
					bunic->dr->culoare = 0;
					bunic->st->culoare = 0;
					bunic->culoare = 1;
					act = bunic;
				}
				else
				{
					//unchiul e negru
					if (tata->dr == act)
					{
						act = tata;
						leftRotation(root, act);
						tata = act->parinte;
						bunic = tata->parinte;
					}
					tata->culoare = 0;
					bunic->culoare = 1;
					rightRotation(root, bunic);
				}
			}
			else 
				if (tata->parinte != nullptr && tata->parinte->dr == tata) {
					Node* bunic = tata->parinte;
				//parintele este un copil drept
				if (bunic->st != nullptr && bunic->st->culoare == 1)
				{
					bunic->st->culoare = 0;
					bunic->dr->culoare = 0;
					bunic->culoare = 1;
					act = bunic;
				}
				else
				{
					//unchiul e negru
					if (tata->st == act)
					{
						act = tata;
						rightRotation(root, act);
						tata = act->parinte;
						bunic = tata->parinte;
					}
					tata->culoare = 0;
					bunic->culoare = 1;
					leftRotation(root, bunic);
				}
			}
			root->culoare = 0;
		}
	}

	Node* searchHelper(Node* root, int x)
	{
		if (root != nullptr)
			if (root->val == x)
				return root;
			else
				if (root->val > x)
					return searchHelper(root->st, x);
				else
					return searchHelper(root->dr, x);
		return NULL;
	}

	void InorderHelper(Node* root, int x, int y)
	{
		if (root != nullptr)
		{
			InorderHelper(root->st, x, y);
			if (root->val >= x && root->val <= y)
				g << root->val << " ";
			InorderHelper(root->dr, x, y);
		}
	}

	int YhelperMax(Node* root,int x, int maxActual)
	{
		if (root != nullptr)
		{
			if (root->val == x)
				return x;
		
			if (root->val > x)
					return YhelperMax(root->st, x, maxActual);
			
			if (root->val < x)
				return YhelperMax(root->dr, x, root->val);
					
		}
		return maxActual;

	}
	int YhelperMin(Node* root, int x, int minActual)
	{
		if (root != nullptr)
		{
			if (root->val == x)
				return x;
			
			if (root->val > x)
				return YhelperMin(root->st, x, root->val);

			if (root->val < x)
				return YhelperMin(root->dr, x, minActual);
			
			
		}
		return minActual;

	}

	Node* minim(Node* n)
	{
		while (n->st != nullptr)
			n = n->st;
		return n;
	}

	void transplant(Node*& u, Node*& v)
	{
		if (u->parinte == nullptr)
			root = v;
		else
			if (u == u->parinte->st)
				u->parinte->st = v;
			else
				u->parinte->dr = v;
		if(v!=nullptr)
		v->parinte = u->parinte;
	}

	void delHelper(int val)
	{
		Node* z = searchHelper(root,val);

		if (z == NULL)
		{
			cout << "\nValoare nu exista\n";
			return;
		}

		Node* y = z;
		bool y_cul_orig = y->culoare;
		Node* x;
		if (z->st == nullptr)
		{
			x = z->dr;
			transplant(z, z->dr);
		}
		else
			if(z->dr == nullptr)
			{
				x = z->st;
				transplant(z, z->st);
			}
			else {
				y = minim(z->dr);
				y_cul_orig = y->culoare;
				x = y->dr;
				if (x!=nullptr && y->parinte == z)
				{
					x->parinte = y;
				}
				else if (y->parinte != z) {
					transplant(y, y->dr);
					y->dr = z->dr;
				}
				transplant(z, y);
				y->st = z->st;
				y->st->parinte = y;
				y->culoare = z->culoare;

			}

		if (y_cul_orig == 0)
			FixDelete(x);



	}

	void FixDelete(Node*& x)
	{
		if(x)
		while ( x != root && x->culoare == 0)
		{
			if (x == x->parinte->st)
			{
				Node* w = x->parinte->dr;
				if (w->culoare == 1)
				{
					w->culoare = 0;
					x->parinte->culoare = 1;
					leftRotation(root,x->parinte);
					w = x->parinte->dr;
				}
				if (w->st->culoare == 0 && w->dr->culoare == 0)
				{
					w->culoare = 1;
					x = x->parinte;
				}
				else {
					if (w->dr->culoare == 0)
					{
						w->st->culoare = 0;
						w->culoare = 1;
						rightRotation(root, w);
						w = x->parinte->dr;
					}
					w->culoare = x->parinte->culoare;
					x->parinte->culoare = 0;
					w->dr->culoare = 0;
					leftRotation(root, x->parinte);
					x = root;
				}
			}
			else
			{
				Node* w = x->parinte->st;

				if (w->culoare == 1)
				{
					w->culoare = 0;
					x->parinte->culoare = 1;
					rightRotation(root, x->parinte);
					w = x->parinte->st;
				}
				if (w->dr->culoare == 0 && w->st->culoare == 0)
				{
					w->culoare = 1;
					x = x->parinte;
				}
				else {
					if (w->st->culoare == 0)
					{
						w->dr->culoare = 0;
						w->culoare = 1;
						leftRotation(root, w);
						w = x->parinte->st;
					}
					w->culoare = x->parinte->culoare;
					x->parinte->culoare = 0;
					w->st->culoare = 0;
					rightRotation(root, x->parinte);
					x = root;
				}
			}
			x->culoare = 0;
		}
	}

	//void FixRBT()
public:
	RBT() {
		root = nullptr;
	}
	void add(int x)
	{
		Node* n = addHelper(root, x, nullptr);
		FixInsert(root, n);
	}
	void del(int x)
	{
		delHelper(x);
	}


	bool search(int x)
	{
		if(searchHelper(root, x)!=NULL)
			return 1;
		return 0;
	}

	void celMaiMareY(int x)
	{
		g << YhelperMax(root, x, -root->val) << endl;
	}

	void celMaiMicY(int x)
	{
		g << YhelperMin(root, x, root->val) << endl;
	}

	void MINIM()
	{
		g << minim(root)->val;
	}

	void Inorder(int x, int y) {
		InorderHelper(root, x, y);
	}

};


int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	RBT b;
	int nr;
	f >> nr;
	for (int i = 0; i < nr; i++)
	{
		int numar;
		f >> numar;
		int x, y;
		switch (numar) {
		case(1):
			f >> x;
			b.add(x);
			break;
		case(2):
			f >> x;
			b.del(x);
			break;
		case(3):
			f >> x;
			g << b.search(x) << endl;
			break;
		case(4):
			f >> x;
			b.celMaiMareY(x);
			break;
		case(5):
			f >> x;
			b.celMaiMicY(x);
			break;
		case(6):
			f >> x >> y;
			b.Inorder(x,y);
			g << endl;
			break;
		}


	}


}