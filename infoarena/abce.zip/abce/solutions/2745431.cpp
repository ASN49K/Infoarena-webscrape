#include<bits/stdc++.h>
using namespace std;

struct AVLTree
{
    int key;
    int height;
    AVLTree *left,*right;

    AVLTree()
    {
        key=0;
        height=0;
        left=nullptr; //for now
        right=nullptr;
    }

    AVLTree(int key,int height)
    {
        this->key=key;
        this->height=height;
        left=nullptr;
        right=nullptr;
    }

    AVLTree(const AVLTree &node)
    {
        this->key=node.key;
        this->height=node.height;
        this->left=node.left;
        this->right=node.right;
    }
}*root=new AVLTree(0,-1),*specialNode=new AVLTree(0,-1);

void init()
{
    specialNode->left=specialNode;
    specialNode->right=specialNode;
    root->left=root->right=specialNode;
}

void solveLeftLeft(AVLTree* &node)
{
    AVLTree* aux=node->left;
    AVLTree* currentRoot=node;

    node->left=aux->right;
    node=aux;
    node->right=currentRoot;
}

void solveRightRight(AVLTree* &node)
{
    AVLTree* aux=node->right;
    AVLTree* currentRoot=node;

    node->right=aux->left;
    node=aux;
    node->left=currentRoot;
}
void solveLeftRight(AVLTree* &node)
{
    AVLTree* aux=node->left->right;
    AVLTree* currentRoot=node;
    AVLTree* aux2=node->left;

    node->left=aux->right;
    aux2->right=aux->left;
    node=aux;
    node->left=aux2;
    node->right=currentRoot;
}

void solveRightLeft(AVLTree* &node)
{
    AVLTree* aux=node->right->left;
    AVLTree* currentRoot=node;
    AVLTree* aux2=node->right;

    node->right=aux->left;
    aux2->left=aux->right;
    node=aux;
    node->left=currentRoot;
    node->right=aux2;

}

void computeHeight(AVLTree* &node)
{
    if(node==specialNode)
    {
        node->height=-1;
        return;
    }

    node->height=1+max(node->left->height,node->right->height);

   // else node->height=0;
}
void Balance(AVLTree* &node)
{
    computeHeight(node->left);
    computeHeight(node->right);
    computeHeight(node);

    if(node->height<=0) return;

    if(abs(node->left->height-node->right->height)>1)
    {
        if(node->left->height>node->right->height )
        {

            if(node->left->left->height>node->left->right->height)
                solveLeftLeft(node);
            else
            solveLeftRight(node);
        }
                else
        {
            if(node->right->left->height<node->right->right->height)
                solveRightRight(node);
            else
                solveRightLeft(node);
        }

    }
    computeHeight(node->left);
    computeHeight(node->right);
    computeHeight(node);
}
void Insert(AVLTree* &node,int key)
{
    if(node->height==-1)
    {
        node=new AVLTree;
        node->height=0;
        node->key=key;
        node->left=specialNode;
        node->right=specialNode;
        return;
    }

    if(key<node->key) Insert(node->left,key);
            else Insert(node->right,key);

    Balance(node);

}



void Inorder(AVLTree* node,int x,int y)
{
    if(node->height==-1)
        return;

    Inorder(node->left,x,y);
    if(node->key>=x && node->key<=y) printf("%d ",node->key);
    Inorder(node->right,x,y);
}

int Search(AVLTree* node,int key)
{
    if(node->key==key)
        return 1;
    if(node->height==-1)
        return 0;

    if(key<node->key) return Search(node->left,key);
        else return Search(node->right,key);
}


void findMax(AVLTree* &node,AVLTree* &mainNode)
{
    if(node->right->height==-1)
    {
        mainNode->key=node->key;
        node=node->left;
        Balance(node);
        return;
    }

    findMax(node->right,mainNode);
    Balance(node);
}

void Erase(AVLTree* &node,int key)
{
    if(node->height==-1)
        return;

    if(key<node->key)
    {
        Erase(node->left,key);
        Balance(node);
    }    else
    if(key>node->key)
    {
        Erase(node->right,key);
        Balance(node);
    }

        else
    if(key==node->key)
    {
        if(node->height==0)
        {
            node=specialNode;
            Balance(node);
            return;
        }
            else

        if(node->left->height==-1)
        {
            node=node->right;
            Balance(node);
            return;
        }
            else

        if(node->right->height==-1)
        {
            node=node->left;
            Balance(node);
            return;
        }

            else

        findMax(node->left,node);
        Balance(node);
    }
}
int getMin(AVLTree* node)
{
    if(node->left==specialNode)
        return node->key;

    return getMin(node->left);
}




int getNext(AVLTree* node,int key)
{
    if(node==specialNode)
        return INT_MAX;

    if(node->key==key)
        return key;

    if(node->key>key)
        return min(node->key,getNext(node->left,key));
    else
        return getNext(node->right,key);
}

int q,x,y,op;
int main()
{

    freopen("abce.in","r",stdin);
    freopen("abce.out","w",stdout);

    init();


    scanf("%d",&q);


    while(q--)
    {

        scanf("%d",&op);
        if(op==1)
        {
            scanf("%d",&x);
            Insert(root,x);
        }
            else
        if(op==2)
        {

            scanf("%d",&x);
            Erase(root,x);
        }
            else
        if(op==3)
        {
            scanf("%d",&x);
            printf("%d\n",Search(root,x));
        }
            else
        if(op==4)
        {
            scanf("%d",&x);
            printf("%d\n",0);
        }
            else
        if(op==5)
        {
            scanf("%d",&x);
            printf("%d\n",0);
        }
            else
        {

            scanf("%d%d",&x,&y);
            Inorder(root,x,y);
            printf("\n");
        }
    }

    return 0;
}