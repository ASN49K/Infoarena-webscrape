#include <iostream>
#include <fstream>
using namespace std;
ifstream f("abce.in");;
ofstream g("abce.out");

struct nod{
    int val;
    nod *st, *dr, *tata;
    nod(): val(0), st(nullptr), dr(nullptr), tata(nullptr){}
    explicit nod(int valoare, nod *s = nullptr, nod *d  = nullptr, nod *t  = nullptr): val(valoare), st(s), dr(d), tata(t){}
};

class SplayTree{
private:
    nod *radacina;
public:
    SplayTree(): radacina(nullptr) {};
    static nod* creeaza_nod(int x, nod* n){
        nod* aux = new nod;
        aux->val = x;
        aux->st = aux->dr = nullptr;
        aux->tata = n;
        return aux;
    }

    void rotatie_dreapta(nod* x)
    {
        nod* y = x->st;
        if (x->st != nullptr)  x->st = y->dr;
        if (y->dr != nullptr) y->dr->tata = x;
        y->tata = x->tata;
        if (x->tata == nullptr) radacina = y;
        else if (x->tata->st == x)  x->tata->st = y;
        else  x->tata->dr = y;
        y->dr = x;
        x->tata = y;
    }

    void rotatie_stanga(nod* x)
    {
        nod* y = x->dr;
        if (x->dr != nullptr) x->dr = y->st;
        if (y->st != nullptr) y->st->tata = x;
        y->tata = x->tata;
        if (x->tata == nullptr) radacina = y;
        else if (x->tata->st == x) x->tata->st = y;
        else x->tata->dr = y;
        y->st = x;
        x->tata = y;
    }

    void splay(nod* x)
    {
        if (x == nullptr) return;
        while (x->tata != nullptr)
            if (x->tata->tata == nullptr) {
                if (x->tata->st == x) rotatie_dreapta(x->tata);
                else rotatie_stanga(x->tata);
            }
            else if (x->tata->st == x) {
                if (x->tata->tata->st == x->tata) {
                    rotatie_dreapta(x->tata->tata);
                    rotatie_dreapta(x->tata);
                }
                else {
                    rotatie_dreapta(x->tata);
                    rotatie_dreapta(x->tata);
                }
            }
            else {
                if (x->tata->tata->dr == x->tata) {
                    rotatie_stanga(x->tata->tata);
                    rotatie_stanga(x->tata);
                }
                else {
                    rotatie_stanga(x->tata);
                    rotatie_dreapta(x->tata);
                }
            }
    }

    static nod* nod_min(nod* c)
    {
        while (c->st != nullptr) c = c->st;
        return c;
    }

    nod* getRadacina() const {
        return radacina;
    }

    void inserare(int x){
        if(radacina == nullptr){
            radacina = creeaza_nod(x, nullptr);
            return;
        }
        nod *n = radacina;
        while(n->dr != nullptr && n->st != nullptr){
            if(x < n->val){
                n = n->st;
            }
            else {
                n = n->dr;
            }
        }
        nod* nod_nou = creeaza_nod(x, n->tata);
        if(x < n->tata->val) n->tata->st = nod_nou;
        else n->tata->dr = nod_nou;
    }

    void stergere(int x)
    {
        nod* n = cautare(x);
        nod* tata = n->tata;
        if(n == nullptr) return;
        if(n->st == nullptr && n->dr == nullptr){
            if(n != radacina)
                if(tata->st == n) tata->st = nullptr;
                else tata->dr = nullptr;
            else radacina = nullptr;
            delete n;
        }
        else if (n->st != nullptr && n->dr != nullptr)  //node has two children
        {
            nod* successor = nod_min(n->dr);
            int val_succ = successor->val;
            stergere(successor->val);
            n->val = val_succ;
        }
        else
        {
            nod* fiu;
            if(n->st != nullptr) fiu = n->st;
            else fiu = n->dr;
            if (n != radacina)
                if (n == tata->st) tata->st = fiu;
                else  tata->dr = fiu;
            else
            {
                radacina = fiu;
                fiu->tata = nullptr;
            }
            delete n;
        }
    }

    nod* cautare(int x){
        nod* n = radacina;
        while(n != nullptr && n->val != x){
            if(x < n->val) n = n->st;
            else n = n->dr;
        }
        return n;
    }

    void inordine(nod *r)
    {
        if(r == nullptr) return;
        inordine(r->st);
        g<< r->val << ' ';
        inordine(r->dr);
    }
};

int main() {
    SplayTree T;
    int n, x, y;
    char c;
    f >> n;
    for(int i = 1; i <= n; i++)
    {
        f >> c >> x;
        if (c == '1') T.inserare(x);
        if (c == '2')   T.stergere(x);
        if (c == '3') {
            if (T.cautare(x) == nullptr) {
                g << "0\n";
            }
            else g << "1\n";
        }
        if (c == '6')
        {
            f >> y;
            g << "\n";
        }
    }
    return 0;
}
