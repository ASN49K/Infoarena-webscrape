#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int MAX_NODURI = 100005;

int cheie[MAX_NODURI];
int prio[MAX_NODURI];
int st[MAX_NODURI];
int dr[MAX_NODURI];

int newKnot = 0;


int creeazaNod(int val) {
    newKnot++;
    cheie[newKnot] = val;
    prio[newKnot] = rand() % 2000000 + 1;
    st[newKnot] = 0;
    dr[newKnot] = 0;
    return newKnot;
}

// Rotire la dreapta
void balanceRight(int &r) {
    int aux = st[r];
    st[r] = dr[aux];
    dr[aux] = r;
    r = aux;
}

// Rotire la stanga
void balanceLeft(int &r) {
    int aux = dr[r];
    dr[r] = st[aux];
    st[aux] = r;
    r = aux;
}

//  Inserare
void insereaza(int &r, int val) {
    if (r == 0) {
        r = creeazaNod(val);
        return;
    }
    if (val < cheie[r]) {
        insereaza(st[r], val);
        if (prio[st[r]] > prio[r]) {
            balanceRight(r);
        }
    } else if (val > cheie[r]) {
        insereaza(dr[r], val);
        if (prio[dr[r]] > prio[r]) {
            balanceLeft(r);
        }
    }
}

// Stergere
// Stergere corectata
void sterge(int &r, int val) {
    if (r == 0) return;

    if (val < cheie[r]) {
        sterge(st[r], val);
    } else if (val > cheie[r]) {
        sterge(dr[r], val);
    } else {

        if (st[r] == 0) {
            r = dr[r];
        } else if (dr[r] == 0) {
            r = st[r];
        } else {

            if (prio[st[r]] > prio[dr[r]]) {
                balanceRight(r);
                sterge(dr[r], val);
            } else {
                balanceLeft(r);
                sterge(st[r], val);
            }
        }
    }
}
//  Cautare
int cauta(int r, int val) {
    while (r != 0) {
        if (cheie[r] == val) return 1;
        if (val < cheie[r]) r = st[r];
        else r = dr[r];
    }
    return 0;
}

//  Predecesor
int findPred(int r, int val) {
    int rezultat = -1;
    while (r != 0) {
        if (cheie[r] <= val) {
            rezultat = cheie[r];
            r = dr[r];
        } else {
            r = st[r];
        }
    }
    return rezultat;
}

//  Succesor
int findSuc(int r, int val) {
    int rezultat = -1;
    while (r != 0) {
        if (cheie[r] >= val) {
            rezultat = cheie[r];
            r = st[r];
        } else {
            r = dr[r];
        }
    }
    return rezultat;
}

//  Afisare interval
void afiseazaInterval(int r, int x, int y, ofstream &fout) {
    if (r == 0) return;

    if (cheie[r] > x) {
        afiseazaInterval(st[r], x, y, fout);
    }
    if (cheie[r] >= x && cheie[r] <= y) {
        fout << cheie[r] << " ";
    }
    if (cheie[r] < y) {
        afiseazaInterval(dr[r], x, y, fout);
    }
}

int main() {

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ifstream fin("abce.in");
    ofstream fout("abce.out");

    srand(time(NULL));

    int radacina = 0; 

    int liniiQueries;
    if (!(fin >> liniiQueries)) return 0;

    while (liniiQueries--) {
        int tip, x;
        fin >> tip >> x;

        if (tip == 1) {
            insereaza(radacina, x);
        } else if (tip == 2) {
            sterge(radacina, x);
        } else if (tip == 3) {
            fout << cauta(radacina, x) << "\n";
        } else if (tip == 4) {
            fout << findPred(radacina, x) << "\n";
        } else if (tip == 5) {
            fout << findSuc(radacina, x) << "\n";
        } else if (tip == 6) {
            int y;
            fin >> y;
            afiseazaInterval(radacina, x, y, fout);
            fout << "\n";
        }
    }

    return 0;
}