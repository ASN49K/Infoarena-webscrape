#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,f16c,fma,sse3,ssse3,sse4.1,sse4.2") 

#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <limits>

using namespace std;

template <class T>
class Node {
private:
	T values[3];				// Array of keys
	int valuesCount = 0;		// Counter to know how many keys we have

	Node** connects = nullptr;	// Array of child node pointers
	int connectsCount = 0;		// Counter to know how many children we have

	Node* parent = nullptr;
public:
	Node(T a) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
	}
	Node(T a, T b) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
		this->addValue(1, b);
	}
	Node(T a, T b, T c) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->addValue(0, a);
		this->addValue(1, b);
		this->addValue(2, c);
	}
	Node(const Node<T>& copyElem) {
		this->connects = new Node * [4];
		for (int i = 0; i < 4; ++i) {
			this->connects[i] = nullptr;
		}
		this->connectsCount = copyElem.connectsCount;
		for (int i = 0; i < copyElem.connectsCount; ++i) {
			this->connects[i] = new Node<T>;
			*this->connects[i] = *copyElem.connects[i];
		}
		this->valuesCount = copyElem.valuesCount;
		for (int i = 0; i < copyElem.valuesCount; ++i) {
			this->values[i] = copyElem.values[i];
		}
	}
	~Node() {
		for (int i = 0; i < this->connectsCount; ++i) {
			delete this->connects[i];
		}
		delete[] this->connects;
		this->connects = nullptr;
	}

	int getValuesCount() {
		return this->valuesCount;
	}
	T getValue(int pos) {
		return this->values[pos];
	}
	void addValue(int pos, T elem) {
		if ((pos + 1) <= this->valuesCount) {
			for (int i = this->valuesCount; i > pos; --i) {
				this->values[i] = this->values[i - 1];
			}
		}
		this->values[pos] = elem;
		++(this->valuesCount);
	}
	void removeValue(int pos) {
		for (int i = pos; i < this->valuesCount - 1; ++i) {
			this->values[i] = this->values[i + 1];
		}
		--(this->valuesCount);
	}

	int getConnectsCount() {
		return this->connectsCount;
	}
	Node<T>* getConnect(int pos) {
		return this->connects[pos];
	}
	void addConnect(int pos, Node<T>* elem) {
		if ((pos + 1) <= this->connectsCount) {
			for (int i = this->connectsCount; i > pos; --i) {
				this->connects[i] = this->connects[i - 1];
			}
		}
		this->connects[pos] = elem;
		++(this->connectsCount);
	}
	void removeConnect(int pos) {
		this->connects[pos] = nullptr;

		for (int i = pos; i < this->connectsCount - 1; ++i) {
			this->connects[i] = this->connects[i + 1];
		}
		--(this->connectsCount);
	}

	bool isLeaf() {
		return this->connectsCount == 0;
	}
	bool isFull() {
		return this->valuesCount == 3;
	}

	void setParent(Node<T>* parent) {
		this->parent = parent;
	}
	Node<T>* getParent() {
		return this->parent;
	}

	Node* split() {
		if (this->getParent() == nullptr) { // ROOT SPLIT
			Node<T>* a = new Node<T>(this->getValue(0));
			Node<T>* b = new Node<T>(this->getValue(2));
			this->removeValue(this->getValuesCount() - 1);
			this->removeValue(0);

			if (this->isLeaf() == false) {
				a->addConnect(0, this->getConnect(0));
				a->addConnect(1, this->getConnect(1));
				this->getConnect(0)->parent = a;
				this->getConnect(1)->parent = a;
				b->addConnect(0, this->getConnect(2));
				b->addConnect(1, this->getConnect(3));
				this->getConnect(2)->parent = b;
				this->getConnect(3)->parent = b;
				for (int i = this->getConnectsCount() - 1; i >= 0; --i) {
					this->removeConnect(i);
				}
			}
			this->addConnect(0, a);
			this->addConnect(1, b);
			a->setParent(this);
			b->setParent(this);
			return this;
		}
		else { // NORMAL SPLIT
			Node<T>* rightNode = new Node<T>(this->getValue(2));
			rightNode->setParent(this->getParent());
			this->removeValue(2);
			if (this->isLeaf() == false) {
				rightNode->addConnect(0, this->getConnect(2));
				rightNode->addConnect(1, this->getConnect(3));
				this->getConnect(2)->parent = rightNode;
				this->getConnect(3)->parent = rightNode;
				this->removeConnect(3);
				this->removeConnect(2);
			}

			int index = this->getParent()->getValuesCount();
			for (int i = 0; i < this->getParent()->getValuesCount(); ++i) {
				if (this->getValue(1) < this->getParent()->getValue(i)) {
					index = i;
					break;
				}
			}
			this->getParent()->addValue(index, this->getValue(1));
			this->removeValue(1);
			this->getParent()->addConnect(index + 1, rightNode);
			return this->getParent();
		}
	}

	void rightRotate(int index) { // Index represents left child
		//cout << "RIGHT ROTATE\n";
		Node<T>* a = this->getConnect(index);
		Node<T>* b = this->getConnect(index + 1);

		a->addValue(a->getValuesCount(), this->getValue(index));
		this->removeValue(index);
		this->addValue(index, b->getValue(0));
		b->removeValue(0);
		if (b->isLeaf() == false) {
			Node<T>* child = b->getConnect(0);
			child->setParent(a);
			b->removeConnect(0);
			a->addConnect(a->getConnectsCount(), child);
		}
	}

	void leftRotate(int index) { // Index represents right child
		//cout << "LEFT ROTATE\n";
		Node<T>* a = this->getConnect(index - 1);
		Node<T>* b = this->getConnect(index);

		b->addValue(0, this->getValue(index - 1));
		this->removeValue(index - 1);
		this->addValue(index - 1, a->getValue(a->getValuesCount() - 1));
		a->removeValue(a->getValuesCount() - 1);
		if (a->isLeaf() == false) {
			Node<T>* child = a->getConnect(a->getConnectsCount() - 1);
			child->setParent(b);
			a->removeConnect(a->getConnectsCount() - 1);
			b->addConnect(0, child);
		}
	}

	void merge(int index) { // Index represents value to merge with
		if (index == -1) { // Merge root
			//cout << "MERGE ROOT\n";
			Node<T>* a = this->getConnect(0);
			Node<T>* b = this->getConnect(1);
			this->addValue(0, a->getValue(0));
			this->addValue(2, b->getValue(0));
			this->removeConnect(1);
			this->removeConnect(0);
			if (a->isLeaf() == false) {
				this->addConnect(0, a->getConnect(0)); a->getConnect(0)->setParent(this);
				this->addConnect(1, a->getConnect(1)); a->getConnect(1)->setParent(this);
				this->addConnect(2, b->getConnect(0)); b->getConnect(0)->setParent(this);
				this->addConnect(3, b->getConnect(1)); b->getConnect(1)->setParent(this);
				b->removeConnect(1);
				b->removeConnect(0);
				a->removeConnect(1);
				a->removeConnect(0);
			}

			delete a;
			delete b;
		}
		else { // Merge normal node
			//cout << "MERGE NORMAL\n";
			Node<T>* a = this->getConnect(index);
			Node<T>* b = this->getConnect(index + 1);

			a->addValue(1, this->getValue(index));
			a->addValue(2, b->getValue(0));
			if (b->isLeaf() == false) {
				a->addConnect(2, b->getConnect(0)); b->getConnect(0)->setParent(a);
				a->addConnect(3, b->getConnect(1)); b->getConnect(1)->setParent(a);
				b->removeConnect(1);
				b->removeConnect(0);
			}
			delete b;
			this->removeConnect(index + 1);
			this->removeValue(index);
		}
	}
};

template <typename T>
class Tree234 {
private:
	Node<T>* root = nullptr;
private:
	bool rec_isBalanced(Node<T>* currentNode) {
		if (currentNode == nullptr) {
			return true;
		}
		int first_child_height = this->rec_getHeight(currentNode->getConnect(0));
		for (int i = 1; i < currentNode->getConnectsCount(); ++i) {
			int child_height = this->rec_getHeight(currentNode->getConnect(i));
			if (child_height != first_child_height) {
				return false;
			}
		}
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			if (this->rec_isBalanced(currentNode->getConnect(i)) == false) {
				return false;
			}
		}
		return true;
	}
	int rec_getHeight(Node<T>* currentNode) {
		if (currentNode == nullptr) {
			return 0;
		}
		int height = 0;
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			height = max(height, this->rec_getHeight(currentNode->getConnect(i)) + 1);
		}
		return height;
	}
	int rec_getTotal(Node<T>* currentNode) {
		int res = currentNode->getValuesCount();
		for (int i = 0; i < currentNode->getConnectsCount(); ++i) {
			if (currentNode->getConnect(i) != nullptr) {
				res += rec_getTotal(currentNode->getConnect(i));
			}
		}
		return res;
	}
	bool rec_find(T& elem, Node<T>* currentNode) {
		int index = currentNode->getValuesCount(); // Finding the current index of between value
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (elem <= currentNode->getValue(i)) {
				index = i;
				break;
			}
		}
		if (index < currentNode->getValuesCount() && elem == currentNode->getValue(index)) {
			return true;
		}
		else {
			if (currentNode->isLeaf()) {
				return false;
			}
			else {
				return this->rec_find(elem, currentNode->getConnect(index));
			}
		}
	}
	T rec_pred(T& elem, Node<T>* currentNode) {
		int index = 0; // Finding the current index of between value
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (elem >= currentNode->getValue(i)) {
				index = index + 1;
			}
			else {
				break;
			}
		}

		if (index > 0 && currentNode->getValue(index - 1) == elem) {
			return elem;
		}
		else {
			if (currentNode->isLeaf() == false) {
				if (index != 0) {
					return max(this->rec_pred(elem, currentNode->getConnect(index)), currentNode->getValue(index - 1));
				}
				else {
					return this->rec_pred(elem, currentNode->getConnect(0));
				}
			}
			else {
				if (index == 0) {
					return -std::numeric_limits<T>::max();
				}
				return currentNode->getValue(index - 1);
			}
		}
	}
	T rec_succ(T& elem, Node<T>* currentNode) {
		int index = 0; // Finding the current index of between value
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (elem >= currentNode->getValue(i)) {
				index = index + 1;
			}
			else {
				break;
			}
		}

		if (index > 0 && currentNode->getValue(index - 1) == elem) {
			return elem;
		}
		else {
			if (currentNode->isLeaf() == false) {
				if (index < currentNode->getValuesCount()) {
					return min(this->rec_pred(elem, currentNode->getConnect(index)), currentNode->getValue(index));
				}
				else {
					return this->rec_pred(elem, currentNode->getConnect(currentNode->getConnectsCount() - 1));
				}
			}
			else {
				if (index == currentNode->getValuesCount()) {
					return std::numeric_limits<T>::max();
				}
				return currentNode->getValue(index);
			}
		}
	}


	T getSmallestInSubTree(Node<T>* currentNode) {
		if (currentNode->isLeaf()) {
			return currentNode->getValue(0);
		}
		return this->getSmallestInSubTree(currentNode->getConnect(0));
	}

	T getBiggestInSubTree(Node<T>* currentNode) {
		if (currentNode->isLeaf()) {
			return currentNode->getValue(currentNode->getValuesCount() - 1);
		}
		return this->getSmallestInSubTree(currentNode->getConnect(currentNode->getConnectsCount() - 1));
	}

	void _insert(T& elem, Node<T>* currentNode) { // Insert, Top-Down implementation
		if (currentNode->isFull() == false) { // Can move down, Might be internal or leaf node
			if (currentNode->isLeaf()) {
				for (int i = 0; i < currentNode->getValuesCount(); ++i) {
					if (elem < currentNode->getValue(i)) {
						currentNode->addValue(i, elem);
						return;
					}
				}
				return currentNode->addValue(currentNode->getValuesCount(), elem);
			}
			else {
				for (int i = 0; i < currentNode->getValuesCount(); ++i) {
					if (elem < currentNode->getValue(i)) {
						this->_insert(elem, currentNode->getConnect(i));
						return;
					}
				}
				this->_insert(elem, currentNode->getConnect(currentNode->getValuesCount()));
				return;
			}
		}
		else { // We split node
			currentNode = currentNode->split(); // Split
			for (int i = 0; i < currentNode->getValuesCount(); ++i) { // Search for best child
				if (elem < currentNode->getValue(i)) {
					this->_insert(elem, currentNode->getConnect(i));
					return;
				}
			}
			this->_insert(elem, currentNode->getConnect(currentNode->getValuesCount()));
			return;
		}
	}

	void _remove(T& elem, Node<T>* currentNode) {
		// Actual Removing
		// Case 1: Element is in a leaf node
		//			a. If node has 2 or 3 keys, delete Element from node
		//			b. If node has 1 key - 3 more cases
		//				i. If node has at least one neighbor with at least 2 keys, rotate operation and delete Element from node
		//				ii. If node has all neighbors with 1 key, and parent has at least 2 keys, merge then delete
		//				iii. If node has all neighbors with 1 key and parent has 1 key, merge parent with neighbors then delete
		// Case 2: Element is in an internal node
		//		1) Find the predecessor of that element. Successor is always a leaf node
		//		2) Switch the predecessor with the Element. Now the Element is in a leaf node
		//		3) Apply Case 1

		int index = currentNode->getValuesCount(); // Finding the current index of between value
		for (int i = 0; i < currentNode->getValuesCount(); ++i) {
			if (elem <= currentNode->getValue(i)) {
				index = i;
				break;
			}
		}

		if (currentNode->isLeaf() == true) {
			if (index < currentNode->getValuesCount()) {
				if (currentNode->getValue(index) == elem) {
					currentNode->removeValue(index);
					//cout << "CONFIRMED REMOVED\n";
				}
			}
		}
		else {
			if (index < currentNode->getValuesCount() && elem == currentNode->getValue(index)) { // If we found element in node
				// Index here represents Value index
				if (currentNode->getConnect(index + 1)->getValuesCount() >= 2) { // If right child has at least 2 values
					// TODO substitute with successor and remove successor in subtree
					T succ = this->getSmallestInSubTree(currentNode->getConnect(index + 1));
					currentNode->removeValue(index);
					currentNode->addValue(index, succ);
					this->_remove(succ, currentNode->getConnect(index + 1));
				}
				else {
					if (currentNode->getConnect(index)->getValuesCount() >= 2) { // If left child has at least 2 values
						// TODO substitute with predecessor and remove predecessor in subtree
						T pred = this->getBiggestInSubTree(currentNode->getConnect(index));
						currentNode->removeValue(index);
						currentNode->addValue(index, pred);
						this->_remove(pred, currentNode->getConnect(index));
					}
					else {
						if (currentNode->getValuesCount() >= 2) { // Merge children with internal, and recursively bleed out elem
							currentNode->merge(index);
							this->_remove(elem, currentNode->getConnect(index));
						}
						else { // Current node is root, merge root and bleed out elem
							currentNode->merge(-1);
							this->_remove(elem, currentNode);
						}
					}
				}
			}
			else { // Have to move down. Index here represents Connect index
				if (currentNode->getConnect(index)->getValuesCount() >= 2) { // If child node has at least 2 values, move down
					this->_remove(elem, currentNode->getConnect(index));
				}
				else { // If child node has 1 value
					if ((index < currentNode->getValuesCount()) && (currentNode->getConnect(index + 1)->getValuesCount() >= 2)) { // And child node has right sibling with at least 2 values
						currentNode->rightRotate(index);
						this->_remove(elem, currentNode->getConnect(index));
					}
					else {
						if ((index > 0) && (currentNode->getConnect(index - 1)->getValuesCount() >= 2)) { // And child node has left sibling with at least 2 values
							currentNode->leftRotate(index);
							this->_remove(elem, currentNode->getConnect(index));
						}
						else {
							// Siblings have 1 child, and parent has 2 children, merge
							// Elseif parent has 1 child and siblings have 1 child, merge with root
							if (currentNode->getValuesCount() >= 2) {
								if (index > 0) { // Merge left child
									currentNode->merge(index - 1);
									this->_remove(elem, currentNode->getConnect(index - 1));
								}
								else { // Merge right child
									currentNode->merge(index);
									this->_remove(elem, currentNode->getConnect(index));
								}
							}
							else {
								// Merge root with children
								currentNode->merge(-1);
								this->_remove(elem, currentNode);
							}
						}
					}
				}
			}
		}
	}
public:
	void insert(T elem) {
		if (this->root == nullptr) {
			this->root = new Node<T>(elem);
			return;
		}
		this->_insert(elem, this->root);
	}
	void remove(T elem) {
		if (this->root == nullptr)
			return;
		this->_remove(elem, this->root);
	}
	bool find(T elem) {
		if (this->root == nullptr)
			return false;
		return this->rec_find(elem, this->root);
	}
	T pred(T elem) {
		return this->rec_pred(elem, this->root);
	}
	T succ(T elem) {
		return this->rec_succ(elem, this->root);
	}
	bool testBalance() {
		return this->rec_isBalanced(this->root);
	}
	int getTotal() {
		return rec_getTotal(this->root);
	}
};

ifstream myIn("abce.in");
ofstream myOut("abce.out");

int main() {
	ios_base::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
    Tree234<int> tree;
    
	int tests;
	myIn >> tests;
	for (int i = 0; i < tests; ++i) {
		int testType;
		myIn >> testType;
		if (testType == 1) {
			int nr;
			myIn >> nr;
			//cout << "TRYING INSERT\n";
			tree.insert(nr);
			//cout << "\tINSERTED, BALANCED: " << tree.testBalance() << '\n';
		}
		else if (testType == 2) {
			int nr;
			myIn >> nr;
			//cout << "TRYING REMOVE\n";
			tree.remove(nr);
			//cout << "\tREMOVED, BALANCED: " << tree.testBalance() << '\n';
		}
		else if (testType == 3) {
			int nr;
			myIn >> nr;
			myOut << tree.find(nr) << '\n';
		}
		else if (testType == 4) {
			int nr;
			myIn >> nr;
			myOut << tree.pred(nr) << '\n';
		}
		else if (testType == 5) {
			int nr;
			myIn >> nr; 
			myOut << tree.succ(nr) << '\n';
		}
		else if (testType == 6) {
			int nr1, nr2;
			myIn >> nr1 >> nr2;
			while (true) {
				nr1 = tree.succ(nr1);
				if (nr1 >> nr2)
					break;
				myOut << nr1 << ' ';
				++nr1;
			}
			myOut << '\n';
		}
		//cout << "TOTAL: " << tree.getTotal() << '\n';
	}
	//cout << "FINISHED\n";

    return 0;
}