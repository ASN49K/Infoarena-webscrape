/*
    Folosim structura treap = arbore binar cu chei si prioritati cu proprietatea ca:
        -- treapul este un arbore de cautare pentru chei
        -- treapul este un max-heap pentru proprietati
*/
#include <bits/stdc++.h>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
struct Nod
{
    int key;
    int priority;
    int weight;
    Nod* left_son;
    Nod* right_son;
};
Nod* nil = NULL;
struct treap
{
    Nod* root;           //radacina
    void insert(int x)                   //insertion function
    {
        insertion(root, x);
    }
    void insertion(Nod* & node, int x)
    {
        if(node == nil)
        {
            node = new Nod;
            node -> key = x;
            node -> priority = rand();
            node -> weight = 1;
            node -> left_son = NULL;
            node -> right_son = NULL;
            return;
        }
        if(x <= node -> key)insertion(node -> left_son, x);
        else insertion(node -> right_son, x);
        node -> weight = 1;
        if(node -> left_son != nil)node -> weight = node -> weight + node -> left_son -> weight;
        if(node -> right_son != nil)node -> weight = node -> weight + node -> right_son -> weight;

        balance(node);            //rebalanseaza arborele prin rotatii ca sa fie un max-heap dupa prioritati
    }
    void balance(Nod* & node)
    {
        if(node -> left_son != nil && node -> left_son -> priority > node -> priority)rotate_left(node);
        else if(node -> right_son != nil && node -> right_son -> priority > node -> priority)rotate_right(node);
    }
    void rotate_left(Nod* & node)
    {
        int weight_aux = 1;
        if(node -> left_son -> right_son != nil)weight_aux += node -> left_son -> right_son -> weight;
        if(node -> right_son != nil)weight_aux += node -> right_son -> weight;
        Nod* aux = node -> left_son;
        aux -> weight = node -> weight;
        node -> left_son = aux -> right_son, aux -> right_son = node;
        node = aux;
        node -> right_son -> weight = weight_aux;
    }
    void rotate_right(Nod* & node)
    {
        int weight_aux = 1;
        if(node -> right_son -> left_son != nil)weight_aux += node -> right_son -> left_son -> weight;
        if(node -> left_son != nil)weight_aux += node -> left_son -> weight;
        Nod* aux = node -> right_son;
        aux -> weight = node -> weight;
        node -> right_son = aux -> left_son, aux -> left_son = node;
        node = aux;
        node -> left_son -> weight = weight_aux;
    }
    void erase(int x)                         //delete function
    {
        eraser(root, x);
    }
    void eraser(Nod* & node, int x)
    {
        if(node == nil)return;
        if(x < node -> key)eraser(node -> left_son, x);
        else if(x > node -> key)eraser(node -> right_son, x);
        else
        {
            if(node -> left_son == nil && node -> right_son == nil)
            {
                delete node;                        // stergerea efectiva
                node = nil;
                //cout << "Delete successfull!\n";
                return;
            }
            else if(node -> left_son == nil)
            {
                rotate_right(node);
                eraser(node, x);
            }
            else if(node -> right_son == nil)
            {
                rotate_left(node);
                eraser(node, x);
            }
            else if(node -> left_son -> priority > node -> right_son -> priority)
            {
                rotate_left(node);
                eraser(node, x);
            }
            else
            {
                rotate_right(node);
                eraser(node, x);
            }
        }
        node -> weight = 1;
        if(node -> left_son != nil)node -> weight = node -> weight + node -> left_son -> weight;
        if(node -> right_son != nil)node -> weight = node -> weight + node -> right_son -> weight;
    }
    int minn()
    {
        Nod* aux = root;
        while(aux -> left_son != nil)
            aux = aux -> left_son;
        return aux -> key;
    }
    int maxx()
    {
        Nod* aux = root;
        while(aux -> right_son != nil)
            aux = aux -> right_son;
        return aux -> key;
    }
    int succesor(int x)
    {
        bool found = false;
        int poz = find_poz_of(root, x, found);
        if(found == false)return -1;
        int elem = find_elem_of(root, poz + 1, found);
        if(found == false)return -1;
        return elem;
    }
    int predecesor(int x)
    {
        bool found = false;
        int poz = find_poz_of(root, x, found);
        if(found == false || poz == -1)return -1;
        int elem = find_elem_of(root, poz - 1, found);
        if(found == false)return -1;
        return elem;
    }
    int find_poz_of(Nod* & node, int x, bool & found)
    {
        if(node == nil)return 0;
        if(node -> key > x)return find_poz_of(node -> left_son, x, found);
        else if(node -> key < x)
        {
            if(node -> left_son != nil)return node -> left_son -> weight + 1 + find_poz_of(node -> right_son, x, found);
            else return 1 + find_poz_of(node -> right_son, x, found);
        }
        else
        {
            found = true;
            if(node -> left_son != nil)return  node -> left_son -> weight + 1;
            else return 1;
        }
    }
    int find_elem_of(Nod* & node, int poz, bool & found)
    {
        if(node == nil)return 0;
        int aux;
        if(node -> left_son != nil)aux = node -> left_son -> weight;
        else aux = 0;
        if(aux + 1 == poz)
        {
            found = true;
            return node -> key;
        }
        if(aux + 1 < poz)return find_elem_of(node -> right_son, poz - aux - 1, found);
        else return find_elem_of(node -> left_son, poz, found);
    }
    int cardinal()
    {
        return root -> weight;
    }
    int este_in(int x)
    {
        bool found = false;
        int poz = find_poz_of(root, x, found);
        if(found == false)return 0;
        return 1;
    }
    void sir_sortat(int st, int dr)
    {
        sorteaza(root, st, dr);
    }
    void sorteaza(Nod* & node, int st, int dr)
    {
        if(node == nil)return;
        //if(node -> left_son != nil && node -> left_son -> key >= st)sorteaza(node -> left_son, st, dr);
        //if(st <= node -> key && node -> key <= dr)g << node -> key << " ";                // inorder spanning of the tree is the sorted array
        //if(node -> right_son != nil && node -> right_son -> key <= dr)sorteaza(node -> right_son, st, dr);
        sorteaza(node -> left_son, st, dr);
        if(st <= node -> key && node -> key <= dr)g << node -> key << " ";
        sorteaza(node -> right_son, st, dr);
    }
    int aux_pred(int x)
    {
        return aux_predd(root, x);
    }
    int aux_predd(Nod * & node, int x)
    {
        if(node == nil)return INT_MIN;
        if(node -> key <= x)return max(node -> key, aux_predd(node -> right_son, x));
        else return aux_predd(node -> left_son, x);
    }
    int aux_succ(int x)
    {
        return aux_suc(root, x);
    }
    int aux_suc(Nod * & node, int x)
    {
        if(node == nil)return INT_MAX;
        if(node -> key >= x)return min(node -> key, aux_suc(node -> left_son, x));
        else return aux_suc(node -> right_son, x);
    }
};
treap S;
int ii, q, op, x, st, dr;
int main()
{
    f >> q;
    for(ii = 1; ii <= q; ii ++)
    {
        f >> op;
        if(op == 1)
        {
            f >> x;
            S.insert(x);
        }
        if(op == 2)
        {
            f >> x;
            S.erase(x);
        }
        if(op == 3)
        {
            f >> x;
            g << S.este_in(x) << "\n";
        }
        if(op == 4)
        {
            f >> x;
            g << S.aux_pred(x) << "\n";
        }
        if(op == 5)
        {
            f >> x;
            g << S.aux_succ(x) << "\n";
        }
        if(op == 6)
        {
            f >> st >> dr;
            S.sir_sortat(st, dr);
            g << "\n";
        }
    }
    return 0;
}
