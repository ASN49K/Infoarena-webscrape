#include <bits/stdc++.h>
using namespace std;

struct Node {
    long long key;
    int height;
    Node* left;
    Node* right;

    Node(long long k) : key(k), height(1), left(nullptr), right(nullptr) {}
};

int height(Node* n) {
    return n ? n->height : 0;
}

int bf(Node* n) {
    return n ? height(n->left) - height(n->right) : 0;
}

void updateHeight(Node* n) {
    if (n)
        n->height = 1 + max(height(n->left), height(n->right));
}

Node* rotateRight(Node* y) {
    Node* x  = y->left;
    Node* T2 = x->right;
    x->right = y;
    y->left  = T2;
    updateHeight(y);
    updateHeight(x);
    return x;
}

Node* rotateLeft(Node* x) {
    Node* y  = x->right;
    Node* T2 = y->left;
    y->left  = x;
    x->right = T2;
    updateHeight(x);
    updateHeight(y);
    return y;
}

Node* balance(Node* n) {
    updateHeight(n);
    int b = bf(n);
    if (b > 1) {
        if (bf(n->left) < 0)
            n->left = rotateLeft(n->left);
        return rotateRight(n);
    }
    if (b < -1) {
        if (bf(n->right) > 0)
            n->right = rotateRight(n->right);
        return rotateLeft(n);
    }
    return n;
}

Node* insert(Node* n, long long key) {
    if (!n)
        return new Node(key);
    if (key < n->key)
        n->left  = insert(n->left,  key);
    else
        if (key > n->key)
            n->right = insert(n->right, key);
    else
        return n;
    return balance(n);
}

Node* minNode(Node* n) {
    while (n->left)
        n = n->left;
    return n;
}

Node* erase(Node* n, long long key) {
    if (!n)
        return nullptr;
    if (key < n->key)
        n->left  = erase(n->left,  key);
    else
        if (key > n->key)
            n->right = erase(n->right, key);
    else {
        if (!n->left || !n->right) {
            Node* child = n->left ? n->left : n->right;
            delete n;
            return child;
        }
        Node* succ = minNode(n->right);
        n->key     = succ->key;
        n->right   = erase(n->right, succ->key);
    }
    return balance(n);
}

bool search(Node* n, long long key) {
    while (n) {
        if (key < n->key)
            n = n->left;
        else
            if (key > n->key)
                n = n->right;
        else
            return true;
    }
    return false;
}

long long floorVal(Node* n, long long x) {
    long long res = LLONG_MIN;
    while (n) {
        if (n->key <= x) {
            res = n->key;
            n = n->right;
        }
        else
            n = n->left;
    }
    return res;
}

long long ceilVal(Node* n, long long x) {
    long long res = LLONG_MAX;
    while (n) {
        if (n->key >= x) {
            res = n->key;
            n = n->left;
        }
        else
            n = n->right;
    }
    return res;
}

void rangeQuery(Node* n, long long x, long long y, vector<long long>& out) {
    if (!n) return;
    if (n->key > x) rangeQuery(n->left,  x, y, out);
    if (n->key >= x && n->key <= y) out.push_back(n->key);
    if (n->key < y) rangeQuery(n->right, x, y, out);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("abce.in",  "r", stdin);
    freopen("abce.out", "w", stdout);

    int Q;
    cin >> Q;

    Node* root = nullptr;

    while (Q--) {
        int op;
        cin >> op;

        if (op == 1) {
            long long x; cin >> x;
            root = insert(root, x);
        }
        else
            if (op == 2) {
            long long x; cin >> x;
            root = erase(root, x);
        }
        else
            if (op == 3) {
            long long x; cin >> x;
            cout << (search(root, x) ? 1 : 0) << '\n';
        }
        else
            if (op == 4) {
            long long x; cin >> x;
            cout << floorVal(root, x) << '\n';
        }
        else
            if (op == 5) {
            long long x; cin >> x;
            cout << ceilVal(root, x) << '\n';
        }
        else {
            long long x, y; cin >> x >> y;
            vector<long long> out;
            rangeQuery(root, x, y, out);
            for (int i = 0; i < (int)out.size(); i++) {
                if (i) cout << ' ';
                cout << out[i];
            }
            cout << '\n';
        }
    }
    return 0;
}