// Red Black Tree - Alexandru Miclea
// FMI UNIBUC 2023

// TODO general
// TODO remove

#include <iostream>
#include <assert.h>
using namespace std;

#define INF 1e9 + 7

class RBT {
private: // VIEW no no
    struct node {
        int value;
        bool isBlack;

        node *left, *right, *dad;

        node(node* left, node* right, node* dad, int val = INF, bool isBlack = true) : value(val), isBlack(isBlack) {
            this->left = left;
            this->right = right;
            this->dad = dad;
        }
    };
    
    node *treeRoot, *NIL;

public:
    RBT() {
        treeRoot = new node(NULL, NULL, NULL);
        NIL = treeRoot;
    }

    node* search(int);
    int inTree(int);
    void leftRotate(node*);
    void rightRotate(node*);
    void insert(int);
    void remove(int);
    void transplant(node*, node*);
    int successor(int);
    int predecessor(int);
    void sorted(int, int);
    void insert_fix_up(node*);
    void remove_fix_up(node*);
    void redoRoot();
};

// TODO DOCUMENT
void RBT::rightRotate(node* root) {
    // right rotation needs left son
    assert(root->left != NIL);

    // the new top node will be called swap
    node* swap = root->left;

    root->left = swap->right;
    if (swap->right != NIL) swap->right->dad = root;
    swap->dad = root->dad;
    if (root == root->dad->left) root->dad->left = swap;
    else root->dad->right = swap;

    swap->right = root;
    root->dad = swap;
    
}

// TODO DOCUMENT
void RBT::leftRotate(node* root) {
    // left rotation needs right son
    assert(root->right != NIL);

    node* swap = root->right;


    root->right = swap->left;
    if (swap->left != NIL) swap->left->dad = root;
    swap->dad = root->dad;

    // check 
    if (root->dad->left == root) root->dad->left = swap;
    else root->dad->right = swap;

    swap->left = root;
    root->dad = swap;
}

void RBT::insert(int val) {
    if (treeRoot == NIL) {
        // if the root is NIL, then root shall be the new node
        treeRoot = new node(NIL, NIL, NIL, val, true);
    }
    else {
        node *pointer = treeRoot;

        // traverse the tree using a pointer 
        
        while (true) {
            // corner case, no values are inserted if they already exist
            assert (pointer->value != val);

            // descend left
            if (pointer->value > val && pointer->left != NIL) {
                pointer = pointer->left;
                continue;
            }
            // descend right
            if (pointer->value < val && pointer->right != NIL) {
                pointer = pointer->right;
                continue;
            }

            break;
        }

        // I have reached a node whose descendant has the value I want to insert
        // the new node will be red (false), and now I will go about fixing the tree

        if (pointer->value < val) {
            // pun noul nod pe dreapta
            pointer->right = new node(NIL,NIL,pointer,val,false);
            insert_fix_up(pointer->right);
        }
        if (pointer->value > val) {
            // pun noul nod pe stanga
            pointer->left = new node(NIL, NIL, pointer, val, false);
            insert_fix_up(pointer->left);
        }
    }
}

void RBT::redoRoot() {
    if (treeRoot->dad == NIL){
        treeRoot->isBlack = true;
        return;
    }
    while (treeRoot->dad != NIL) {
        treeRoot = treeRoot->dad;
    }
    treeRoot->isBlack = true;
}

RBT::node* RBT::search(int val) {
    
    // same traversal as in RBT::insert()
    node* pointer = treeRoot;

    while (true) {
        // you don't have a tree, return NIL
        if (pointer == NIL) return NIL;

        if (pointer->value == val) {
            // I have found the value
            return pointer;
        }
        if (pointer->value > val && pointer->left != NIL) {
            pointer = pointer->left;
            continue;
        }
        if (pointer->value < val && pointer->right != NIL) {
            pointer = pointer->right;
            continue;
        }
        // I have not found the value
        return NIL;
    }
}

int RBT::inTree(int val) {
    node* pointer = search(val);
    if (pointer != NIL) return 1;
    return 0;
}

int RBT::predecessor(int val) {
    int ans = -INF;

    node* pointer = treeRoot;

    while (pointer != NIL) {
        if (pointer->value <= val) {
            ans = max(ans, pointer->value);
            pointer = pointer->right;
        }
        else {
            pointer = pointer->left;
        }
    }

    return ans;
}

int RBT::successor(int val){
    int ans = INF;

    node* pointer = treeRoot;

    while (pointer != NIL) {
        if (pointer->value >= val) {
            ans = min(ans, pointer->value);
            pointer = pointer->left;
        }
        else {
            pointer = pointer->right;
        }
    }

    return ans;
}

void RBT::sorted(int st, int dr){
    
    int val;
    if (this->inTree(st)) val = st;
    else val = successor(st);

    while (val <= dr) {
        cout << val << ' ';
        val = successor(val + 1);
    }
}

// TODO document
void RBT::insert_fix_up(node* root) {

    // check whether the root node and dad are both red, case in which
    // we need to see what case we are in
    while (root->dad->isBlack == false) {
        assert(root->dad->dad != NIL);

        if (root->dad == root->dad->dad->left) {
            if (root->dad->dad->right->isBlack == false) {
                root->dad->isBlack = true;
                root->dad->dad->right->isBlack = true;
                root->dad->dad->isBlack = false;
                root = root->dad->dad;
            }
            else {
                if (root == root->dad->right) {
                    root = root->dad;
                    leftRotate(root);
                }
                root->dad->isBlack = true;
                root->dad->dad->isBlack = false;
                rightRotate(root->dad->dad);
            }
        }
        else {
            if (root->dad->dad->left->isBlack == false) {
                root->dad->isBlack = true;
                root->dad->dad->left->isBlack = true;
                root->dad->dad->isBlack = false;
                root = root->dad->dad;
            }
            else {
                if (root == root->dad->left) {
                    root = root->dad;
                    rightRotate(root);
                }
                root->dad->isBlack = true;
                root->dad->dad->isBlack = false;
                leftRotate(root->dad->dad);
            }
        }
        //redoRoot();
    }
    redoRoot();
    //treeRoot->isBlack = true;
}

void RBT::transplant(node* root, node* replace) {
    // if the root node is the tree root then modify treeRoot
    if (root->dad == NIL) {
        treeRoot = replace;
    }
    // if the root node is the left son of dad
    // then replace the left child
    else if (root == root->dad->left) {
        root->dad->left = replace;
    // by exclusion, replace the right child
    } else root->dad->right = replace;
    // the dad of replace shall be the dad of root
    replace->dad = root->dad;
}

// TODO document
void RBT::remove(int val) {
    node* child = NIL;
    node* z = search(val);
    if (z == NIL) return;
    node* y = z;
    bool origColor = y->isBlack;

    /*node* pointer = treeRoot;

    while (pointer != NIL) {
        if (pointer->value > val) {
            ans = min(ans, pointer->value);
            pointer = pointer->left;
        }
        else {
            pointer = pointer->right;
        }
    }*/
    if (z->left == NIL) {
        child = z->right;
        transplant(z, z->right);
    }
    else if (z->right == NIL){
        child = z->left;
        transplant(z, z->left);
    }
    else {
        node* aux = z->right;

        while (aux->left != NIL) aux = aux->left;

        y = aux;
        origColor = y->isBlack;
        child = y->right;
        if (y->dad == z) child->dad = y;
        else {
            transplant(y, y->right);
            y->right = z->right;
            y->right->dad = y;
        }
        transplant(z,y);
        y->left = z->left;
        y->left->dad = y;
        y->isBlack = z->isBlack;
    }

    if (origColor == true) remove_fix_up(child);
}

// TODO document
void RBT::remove_fix_up(node* root) {
    while (root != treeRoot && root->isBlack == true) {
        if (root == root->dad->left) {
            node* w = root->dad->right;
            if (w->isBlack == false) {
                w->isBlack = true;
                root->dad->isBlack = false;
                leftRotate(root->dad);
                w = root->dad->right;
            }
            if (w->left->isBlack == true && w->right->isBlack == true) {
                w->isBlack = false;
                root = root->dad;
            }
            else {
                if (w->right->isBlack == true){
                    w->left->isBlack = true;
                    w->isBlack = false;
                    rightRotate(w);
                    w = root->dad->right;
                }
                w->isBlack = root->dad->isBlack;
                root->dad->isBlack = true;
                w->right->isBlack = true;
                leftRotate(root->dad);
                root = treeRoot;
            }
        }
        else if (root == root->dad->right){
            node* w = root->dad->left;
            if (w->isBlack == false) {
                w->isBlack = true;
                root->dad->isBlack = false;
                rightRotate(root->dad);
                w = root->dad->left;
            }
            if (w->left->isBlack == true && w->right->isBlack == true) {
                w->isBlack = false;
                root = root->dad;
            }
            else {
                if (w->left->isBlack == true) {
                    w->right->isBlack = true;
                    w->isBlack = false;
                    leftRotate(w);
                    w = root->dad->left;
                }
                w->isBlack = root->dad->isBlack;
                root->dad->isBlack = true;
                w->left->isBlack = true;
                rightRotate(root->dad);
                root = treeRoot;
            }
        }
    }
    root->isBlack = true;
}

int main(){
    
#ifdef INFOARENA
    freopen("abce.in", "r", stdin);
    freopen("abce.out", "w", stdout);
#endif
    
    RBT arbore;


    /*arbore.insert(10);
    arbore.insert(20);
    arbore.insert(-10);
    arbore.insert(15);
    arbore.insert(17);
    arbore.insert(40);
    arbore.insert(50);
    arbore.insert(60);

    cout << arbore.inTree(40) << endl;
    arbore.remove(40);
    cout << arbore.inTree(40) << endl;
    cout << arbore.inTree(10) << endl;
    arbore.remove(10);
    cout << arbore.inTree(10) << endl;
    cout << arbore.inTree(50) << endl;
    arbore.remove(50);
    cout << arbore.inTree(50) << endl;*/

    /*arbore.sorted(10, 40);
    cout << endl;
    arbore.sorted(12, 45);
    cout << endl;*/
    //cout << endl << arbore.nextHighest(12);

    //cout << arbore.inTree(15);

    /*cout << arbore.treeRoot->value << " " << arbore.treeRoot->isBlack << endl;
    cout << arbore.treeRoot->left->value << " " << arbore.treeRoot->left->isBlack << endl;
    cout << arbore.treeRoot->left->left->value << " " << arbore.treeRoot->left->left->isBlack << endl;
    cout << arbore.treeRoot->left->right->value << " " << arbore.treeRoot->left->right->isBlack << endl;
    cout << arbore.treeRoot->right->value << " " << arbore.treeRoot->right->isBlack << endl;
    cout << arbore.treeRoot->right->left->value << " " << arbore.treeRoot->right->left->isBlack << endl;
    cout << arbore.treeRoot->right->right->value << " " << arbore.treeRoot->right->right->isBlack << endl;
    cout << arbore.treeRoot->right->right->right->value << " " << arbore.treeRoot->right->right->right->isBlack << endl;*/




    int n, c, x, y;
    cin >> n;
    while (n--) {
        cin >> c >> x;
        switch (c) {
            case 1:
                arbore.insert(x);
                break;
            case 2:
                arbore.remove(x);
                break;
            case 3:
                cout << arbore.inTree(x) << endl;
                break;
            case 4:
                cout << arbore.predecessor(x) << endl;;
                break;
            case 5:
                cout << arbore.successor(x) << endl;
                break;
            case 6:
                cin >> y;

                arbore.sorted(x, y);
                cout << endl;
                break;
        }
    }

    return 0;
}