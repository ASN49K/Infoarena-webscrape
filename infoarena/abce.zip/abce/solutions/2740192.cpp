#include <iostream>
#include <fstream>

using namespace std;

ifstream f("abce.in");
ofstream g("abce.out");

class SplayTree
{
private:
    struct node
    {
        int val;
        node *left, *right, *parent;
    };
    node* root = nullptr;
    node* newNode(int data,node* p)
    {
        node* aux = new node;

        aux -> val = data;

        aux -> left = NULL;
        aux -> right = NULL;
        aux -> parent = p;
        return aux;
    }
public:
    node* getroot()
    {
        return root;
    }

    node* minValue(node* current)
    {
        if(current == nullptr)
            return nullptr;
        while(current->left != nullptr)
        {
            current = current->left;
        }
        return current;
    }

    void Zig(node *x)
    {
        node *y = x -> left;
        if(x -> left != nullptr)
        {
            x -> left = y -> right;
        }
        if(y -> right != nullptr)
        {
            y -> right -> parent = x;
        }
        y -> parent = x -> parent;
        if(x -> parent == nullptr)
        {
            root = y;
        }
        else if(x -> parent -> left == x)
        {
            x -> parent -> left = y;
        }
        else
        {
            x -> parent -> right = y;
        }
        y -> right = x;
        x -> parent = y;
    }
    void Zag(node *x)
    {
        node *y = x -> right;
        if(x -> right != nullptr)
        {
            x -> right = y -> left;
        }
        if(y -> left != nullptr)
        {
            y -> left -> parent = x;
        }
        y -> parent = x -> parent;
        if(x -> parent == nullptr)
        {
            root = y;
        }
        else if(x -> parent -> left == x)
        {
            x -> parent -> left = y;
        }
        else
        {
            x -> parent -> right = y;
        }
        y -> left = x;
        x -> parent = y;
    }

    void splay(node *x)
    {
        if(x == nullptr)
            return;
        while(x -> parent != nullptr)
        {
            if(x -> parent -> parent == nullptr)
            {
                if(x -> parent -> left == x)
                    Zig(x -> parent);
                else
                    Zag(x -> parent);
            }
            else
            {
                if(x -> parent -> left == x)
                {
                    if(x -> parent -> parent -> left == x -> parent)
                    {
                        Zig(x -> parent -> parent);
                        Zig(x -> parent);
                    }
                    else
                    {
                        Zig(x -> parent);
                        Zag(x -> parent);
                    }
                }
                else
                {
                    if(x -> parent -> parent -> right == x -> parent)
                    {
                        Zag(x -> parent -> parent);
                        Zag(x -> parent);
                    }
                    else
                    {
                        Zag(x -> parent);
                        Zig(x -> parent);
                    }
                }
            }
        }
    }

    void insert_node(int value)
    {
        if (root == nullptr)
        {
            root = newNode(value,nullptr);
            return;
        }
        node *current = root;
        node *parent = nullptr;

        while(current != nullptr)
        {
            parent = current;
            if(current -> val > value)
                current = current -> left;
            else
                current = current -> right;
        }
        node *splaynode = newNode(value,parent);
        if (value < parent -> val)
            parent->left = splaynode;
        else
            parent->right = splaynode;
        splay(splaynode);
    }

    node* find_value(int value)
    {
        node *current = root;
        while (current != nullptr && current -> val != value)
        {
            if (value < current -> val)
                current = current -> left;
            else
                current = current -> right;
        }
        if (current == nullptr)
            return nullptr;
        else
            return current;

    }
    void delete_node(int value)
    {
        node* current = find_value(value);
        if (current == nullptr)
            return;
        splay(current);
        node* parent = current -> parent;
        if(current -> left == nullptr && current -> right == nullptr)
        {
            if (current != root)
            {
                if (parent->left == current)
                    parent->left = nullptr;
                else
                    parent->right = nullptr;
            }
            else
                root = nullptr;
            delete current;
        }
        else if(current -> left != nullptr && current -> right != nullptr)
        {
            node* successor  = minValue(current->right);
            node *aux = successor;
            int valoare = current -> val;
            successor = current;
            successor -> val = aux -> val;
            current = aux;
            current -> val = valoare;
            parent = current -> parent;
            root = successor;
            root -> val = successor -> val;
            if(current -> right == nullptr)
            {
                if (current != root)
                {
                    if (parent->left == current)
                        parent->left = nullptr;
                    else
                        parent->right = nullptr;
                }
                else
                    root = nullptr;
                delete current;
            }
            else
            {
                node* child = current -> right;
                if (current != root)
                {
                    if (current == parent->left)
                        parent->left = child;
                    else
                        parent->right = child;
                    child -> parent = parent;
                }
                else
                {
                    root = child;
                    child -> parent = nullptr;
                }
                delete current;
            }
        }
        else
        {
            node* child;
            if(current -> left != nullptr)
                child = current -> left;
            else
                child = current -> right;
            child -> parent = parent;
            if (current != root)
            {
                if (current == parent->left)
                    parent->left = child;
                else
                    parent->right = child;
            }
            else
            {
                root = child;
                child -> parent = nullptr;
            }
            delete current;
        }
    }
    int max_node(int value)
    {
        node *current = root, *parent = nullptr;
        while (current != nullptr)
        {
            if (value == current -> val)
            {
                splay(current);
                return current -> val;
            }
            if (value < current -> val)
                current = current -> left;
            else
            {
                parent = current;
                current = current -> right;
            }
        }
        splay(parent);
        return parent -> val;
    }

    int min_node(int value)
    {
        node *current = root, *parent = nullptr;
        while (current != nullptr)
        {
            if (value == current -> val)
            {
                splay(current);
                return current -> val;
            }
            if (value < current -> val)
            {
                parent = current;
                current = current -> left;
            }
            else
            {
                current = current -> right;
            }
        }
        splay(parent);
        return parent -> val;
    }

    void print_numbers(node* root,int x,int y)
    {
        if ( root == nullptr )
            return;
        if ( x < root -> val )
            print_numbers(root -> left, x, y);
        if (x <= root -> val && y >= root -> val )
            g <<root -> val<<" ";
        if ( y > root -> val )
            print_numbers(root -> right,x,y);
    }
};

int main()
{
    int Q, tip, x, y;
    f >> Q;
    SplayTree a;
    while (Q--)
    {
        f >> tip >> x;
        if(tip == 1)
            a.insert_node(x);
        if(tip == 2)
            a.delete_node(x);
        if(tip == 3)
        {
            if(a.find_value(x) == nullptr)
                g << false << endl;
            else
                g<< true << endl;
        }
        if(tip == 4)
            g << a.max_node(x) << endl;
        if(tip == 5)
            g << a.min_node(x) << endl;
        if(tip == 6)
        {
            f >> y;
            a.print_numbers(a.getroot(),x,y);
            g<<endl;
        }
    }
    return 0;
}
