#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>

using namespace std;

struct Nod {
    int cheie, pr;
    Nod *st, *dr;
    Nod(int _cheie) {
        cheie = _cheie;
        pr = rand();
        st = dr = NULL;
    }
};

Nod *rotatest(Nod *r) {
    Nod *drCopil = r->dr;
    r->dr = drCopil->st;
    drCopil->st = r;
    return drCopil;
}

Nod *rotatedr(Nod *r) {
    Nod *stCopil = r->st;
    r->st = stCopil->dr;
    stCopil->dr = r;
    return stCopil;
}

Nod *insert(Nod *r, int cheie) {
    if (r == NULL) {
        return new Nod(cheie);
    }
    if (cheie < r->cheie) {
        r->st = insert(r->st, cheie);
        if (r->st->pr > r->pr) {
            r = rotatedr(r);
        }
    } else {
        r->dr = insert(r->dr, cheie);
        if (r->dr->pr > r->pr) {
            r = rotatest(r);
        }
    }
    return r;
}

Nod *deleteNod(Nod *r, int cheie) {
    if (r == NULL) {
        return r;
    }
    if (cheie < r->cheie) {
        r->st = deleteNod(r->st, cheie);
    } else if (cheie > r->cheie) {
        r->dr = deleteNod(r->dr, cheie);
    } else {
        if (r->st == NULL) {
            Nod *temp = r->dr;
            delete r;
            return temp;
        } else if (r->dr == NULL) {
            Nod *temp = r->st;
            delete r;
            return temp;
        } else {
            if (r->st->pr < r->dr->pr) {
                r = rotatedr(r);
                r->dr = deleteNod(r->dr, cheie);
            } else {
                r = rotatest(r);
                r->st = deleteNod(r->st, cheie);
            }
        }
    }
    return r;
}

Nod *search(Nod *r, int cheie) {
    if (r == NULL || r->cheie == cheie) {
        return r;
    }
    if (r->cheie < cheie) {
        return search(r->dr, cheie);
    }
    return search(r->st, cheie);
}

Nod *findMin(Nod *r) {
    while (r->st != NULL) {
        r = r->st;
    }
    return r;
}

Nod *findMax(Nod *r) {
    while (r->dr != NULL) {
        r = r->dr;
    }
    return r;
}

Nod *findMaxLessThanOrEqualTo(Nod *r, int cheie) {
    if (r == NULL) {
        return NULL;
    }
    if (r->cheie == cheie) {
        return r;
    }
    if (r->cheie < cheie) {
        Nod *drResult = findMaxLessThanOrEqualTo(r->dr, cheie);
        if (drResult != NULL) {
            return drResult;
        } else {
            return r;
        }
    }
    return findMaxLessThanOrEqualTo(r->st, cheie);
}

Nod *findMinGreaterThanOrEqualTo(Nod *r, int cheie) {
    if (r == NULL) {
        return NULL;
    }
    if (r->cheie == cheie) {
        return r;
    }
    if (r->cheie > cheie) {
        Nod *stResult = findMinGreaterThanOrEqualTo(r->st, cheie);
        if (stResult != NULL) {
            return stResult;
        } else {
            return r;
        }
    }
    return findMinGreaterThanOrEqualTo(r->dr, cheie);
}

vector<int> inOrder(Nod *r, int x, int y) {
    vector<int> result;
    if (r == NULL) {
        return result;
    }
    if (r->cheie >= x) {
        vector<int> st = inOrder(r->st, x, y);
        result.insert(result.end(), st.begin(), st.end());
    }
    if (r->cheie >= x && r->cheie <= y) {
        result.push_back(r->cheie);
    }
    if (r->cheie <= y) {
        vector<int> dr = inOrder(r->dr, x, y);
        result.insert(result.end(), dr.begin(), dr.end());
    }
    return result;
}

int main() {
    srand(time(NULL));
    int q;
    ifstream fin("abce.in");
    ofstream fout("abce.out");
    fin >> q;
    Nod *r = NULL;
    while (q--) {
        int type, x, y;
        fin >> type >> x;
        if (type == 1) {
            r = insert(r, x);
        } else if (type == 2) {
            r = deleteNod(r, x);
        } else if (type == 3) {
            if (search(r, x) != NULL) {
                fout << "1\n";
            } else {
                fout << "0\n";
            }
        } else if (type == 4) {
            Nod *Nod = findMaxLessThanOrEqualTo(r, x);
            if (Nod != NULL) {
                fout << Nod->cheie << "\n";
            } else {
                fout << "-1\n";
            }
        } else if (type == 5) {
            Nod *Nod = findMinGreaterThanOrEqualTo
(r, x);
            if (Nod != NULL) {
                fout << Nod->cheie << "\n";
            } else {
                fout << "-1\n";
            }
        } else if (type == 6) {
            fin >> y;
            vector<int> result = inOrder(r, x, y);
            for (int i = 0; i < result.size(); i++) {
                fout << result[i] << " ";
            }
            fout << "\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}
