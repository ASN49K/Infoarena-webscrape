#include <bits/stdc++.h>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");
struct Nod {
    Nod** next;
    int val;

    Nod(int, int);
};
Nod::Nod(int val, int lvl){
    this->val = val;
    next = new Nod*[lvl+1];
    memset(next, 0, sizeof(Nod*)*(lvl+1));
}

struct SkipList {
public:
    int max_level;
    int nivel;
    Nod *tabel;
    ///functii
    SkipList(int); ///creare skiplist
    int randlvl(int);
    void insertElem(int);
    Nod* creareNod(int,int);
    int gasire(int);
    void afis();
    void interval(int,int);
    void mic(int);
    void mare(int);
    void sterge(int);
};
SkipList::SkipList(int max_level){
    this->max_level = max_level;
    nivel = 0; /// nivel initial
    tabel  = new Nod(INT32_MIN, max_level);
}

int SkipList::randlvl(int max_level){
    int auxnivel=0,r;
    int ok = true;
    while(ok){
        r = rand();
        ///cout<<r<<endl;
        if(r%2==1)
            auxnivel++;
        else
            ok= false;
    }
    if(auxnivel<max_level)
        return auxnivel;
    else
        return max_level;
}
Nod* SkipList::creareNod(int val, int level){
    Nod *n = new Nod(val, level);
    return n;
}
void SkipList::afis()
{
    cout<<"\n=============Skip List==========="<<"\n";
    for (int i=0;i<=nivel;i++){
        Nod *node = tabel->next[i];
        cout << "Nivel " << i << ": ";
        while (node != NULL){
            cout << node->val<<" ";
            node = node->next[i];
        }
        cout << "\n";
    }
}
void SkipList::insertElem(int val) {
    Nod *x = tabel;
    Nod *update[max_level];
    memset(update, 0, sizeof(Nod*)*(max_level+1)); /// populam cu 0 rapid
    ///populare cu pointerii urmatoarelor elemente de sus in jos
    for (int i = nivel; i >= 0; --i)
    {   if(x->next[i] != NULL) {
            while (x->next[i] != NULL and x->next[i]->val < val)
                x = x->next[i];
        }
        update[i] = x;
    }
    if(x->next[0] == NULL or x->next[0]->val != val){
        int nivelrand = randlvl(max_level); ///aflam nivelul pe care trebuie sa il aiba elementul
        if(nivelrand > nivel){
            for (int i=nivel+1; i<=nivelrand; ++i){
                update[i] = tabel;
            }
            nivel = nivelrand;
        }

        Nod* n = creareNod(val, nivelrand);
        /// populare next
        for (int i = 0; i <= nivelrand; ++i){
            n->next[i] = update[i]->next[i];
            update[i]->next[i] = n;
        }
    }
}
int SkipList::gasire(int val) {
    Nod *fin = tabel;
    for(int i=nivel; i>=0; --i){
        while(fin->next[i] and fin->next[i]->val < val){
            fin = fin->next[i];
        }
    }
    fin = fin->next[0];
    if(fin and fin->val == val)
        return 1;
    else
        return 0;
}

void SkipList::mare(int val) {
    Nod *fin = tabel;
    for(int i=nivel; i>=0; i--){
        while(fin->next[i] and fin->next[i]->val <= val){
            fin = fin->next[i];
        }
    }
    g << fin->val << endl;
}
void SkipList::mic(int val) {
    Nod *fin = tabel;
    for(int i=nivel; i>=0; i--){
        while(fin->next[i] and fin->next[i]->val < val){
            fin = fin->next[i];
        }
    }
    fin = fin->next[0];
    g << fin->val << '\n';
}

void SkipList::interval(int x, int y) {
    Nod *fin = tabel;
    for(int i = nivel; i>=0; --i){
        while(fin->next[i] and fin->next[i]->val < x){
            fin = fin->next[i];
        }
    }
    g<<fin->next[0]->val<<' ';
    fin = fin->next[0];
    while(fin->next[0] and fin->next[0]->val <= y){
        g<<fin->next[0]->val<<' ';
        fin = fin->next[0];
    }
    g<<endl;

}

void SkipList::sterge(int val) {
    Nod *fin = tabel;
    Nod *update[max_level+1];
    memset(update, 0, sizeof(Nod*)*(max_level+1)); /// populam cu 0 rapid
    for(int i=nivel; i>=0; i--){
        while(fin->next[i] and fin->next[i]->val < val){
            fin = fin->next[i];
        }
        update[i] = fin;
    }
    fin = fin->next[0];
    if(fin != NULL and fin->val == val){
        for(int i=0; i < nivel+1; ++i){
            if(update[i]->next[i] != fin)
                break;
            update[i]->next[i] = fin->next[i]; ///mutam pointerul
        }
    }
    ///eliminare nivele in plus
    while(nivel > 0 and fin->next[nivel] == 0)
        nivel = nivel-1;
}

int main()
{   srand((unsigned)time(0)); ///pentru a avea seed ul random
    int k;
    f>>k;
    SkipList lst(15);
    for(int j=1; j<=k; j++){
        int c;
        int val;
        f>>c;
        if(c==1){
            f>>val;
            lst.insertElem(val);
            ///adaugare
        }
        else if(c==2){
            f>>val;
            lst.sterge(val);
            ///stergere
        }
        else if(c==3){
            f>>val;
            int r = lst.gasire(val);
            g<<r<<'\n';
            ///gasire
        }
        else if(c==4){
            f>>val;
            lst.mare(val);
            ///cel mai mare numar y mai mare sau egal ca x
        }
        else if(c==5){
            f>>val;
            lst.mic(val);
            ///cel mai mic numar y mai mare sau egal ca x
        }
        else if(c==6){
            f>>val;
            int final;
            f>>final;
            lst.interval(val,final);
            /// nr interval
        }
    }
    lst.afis();
    return 0;
}
/**
lst.insertElem(3);
lst.insertElem(5);
lst.insertElem(11);
lst.insertElem(12);
lst.insertElem(7);
lst.insertElem(20);
lst.insertElem(29);
lst.insertElem(25);
lst.insertElem(23);
lst.insertElem(22);
lst.insertElem(21);
lst.insertElem(55);
lst.insertElem(95);
lst.insertElem(75);
lst.insertElem(65);
lst.gasire(23);
lst.sterge(23);
lst.afis();
lst.interval(4,100);
 */
