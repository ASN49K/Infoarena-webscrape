#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <climits>
#include <set>
#include <map>
#include <queue>
#include <iostream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");

class RpNode {
public:
    int value, rank;
    RpNode* parent;
    RpNode* left_child;
    RpNode* right_sibling;

    RpNode(int val) : value(val), rank(0), parent(nullptr), left_child(nullptr), right_sibling(nullptr) {}
};

class RankPairingHeap {
public:
    RpNode* root;
    // Auxiliary data structure to track values for O(log n) lookup
    set<int> values;

    RankPairingHeap() : root(nullptr) {}

    ~RankPairingHeap() {
        // Cleanup to prevent memory leaks
        if (root) {
            queue<RpNode*> q;
            q.push(root);
            while (!q.empty()) {
                RpNode* node = q.front();
                q.pop();
                if (node->left_child) q.push(node->left_child);
                if (node->right_sibling) q.push(node->right_sibling);
                delete node;
            }
        }
    }

    void insert(int value) {
        RpNode* new_node = new RpNode(value);
        root = link(root, new_node);
        values.insert(value); // Track value in set
    }

    void delete_value(int value) {
        if (values.find(value) == values.end()) return; // O(log n) check if value exists

        RpNode* node = find_node(value);
        if (!node) return;

        node->value = INT_MIN;
        bubble_up(node);
        extract_min();
        values.erase(value); // Remove from tracking set
    }

    int contains(int value) const {
        // O(log n) instead of O(n)
        return values.find(value) != values.end() ? 1 : 0;
    }

    int max_leq(int x) const {
        // O(log n) using set lower_bound
        auto it = values.upper_bound(x);
        if (it == values.begin()) return INT_MIN;
        --it;
        return *it;
    }

    int min_geq(int x) const {
        // O(log n) using set lower_bound
        auto it = values.lower_bound(x);
        if (it == values.end()) return INT_MAX;
        return *it;
    }

    vector<int> sorted_range(int x, int y) const {
        // O(k) where k is number of elements in range, instead of O(n log n)
        vector<int> result;
        auto start = values.lower_bound(x);
        auto end = values.upper_bound(y);

        for (auto it = start; it != end; ++it) {
            result.push_back(*it);
        }
        return result; // Already sorted by the set
    }

    void meld(RankPairingHeap& other) {
        root = link(root, other.root);
        // Merge the sets
        for (int val : other.values) {
            values.insert(val);
        }
        other.root = nullptr;
        other.values.clear();
    }

private:
    static RpNode* link(RpNode* a, RpNode* b) {
        if (!a) return b;
        if (!b) return a;
        if (b->value < a->value)
            swap(a, b);

        b->right_sibling = a->left_child;
        if (b->right_sibling)
            b->right_sibling->parent = b;
        a->left_child = b;
        b->parent = a;

        // Update ranks for better balancing
        a->rank = max(a->rank, (b->rank > 0 ? b->rank + 1 : 1));

        return a;
    }

    static void bubble_up(RpNode* node) {
        while (node->parent && node->value < node->parent->value) {
            swap(node->value, node->parent->value);
            node = node->parent;
        }
    }

    void extract_min() {
        if (!root) return;

        // Remove min value from set
        if (root->value != INT_MIN) {
            values.erase(root->value);
        }

        vector<RpNode*> children;
        RpNode* child = root->left_child;
        while (child) {
            RpNode* next = child->right_sibling;
            child->parent = nullptr;
            child->right_sibling = nullptr;
            children.push_back(child);
            child = next;
        }

        delete root;
        root = nullptr;

        // Optimize merge using pair-wise linking
        if (!children.empty()) {
            root = children[0];
            for (size_t i = 1; i < children.size(); i++) {
                root = link(root, children[i]);
            }
        }
    }

    // Iterative version of find_node to avoid stack overflow
    RpNode* find_node_iterative(int value) {
        if (!root) return nullptr;

        queue<RpNode*> q;
        q.push(root);

        while (!q.empty()) {
            RpNode* node = q.front();
            q.pop();

            if (node->value == value) return node;

            if (node->left_child) q.push(node->left_child);
            if (node->right_sibling) q.push(node->right_sibling);
        }

        return nullptr;
    }

    // Keep original recursive functions for reference
    static RpNode* find_node(RpNode* node, int value) {
        if (!node) return nullptr;
        if (node->value == value) return node;
        RpNode* found = find_node(node->left_child, value);
        if (found) return found;
        return find_node(node->right_sibling, value);
    }
};

int main() {
    if (!f.is_open() || !g.is_open()) {
        cerr << "Failed to open input or output file!" << endl;
        return 1;
    }

    int q, op_id, x, y;
    RankPairingHeap rpheap;
    f >> q;
    for (int i = 0; i < q; i++) {
        f >> op_id;
        switch (op_id) {
            case 1: {
                f >> x;
                rpheap.insert(x);
                break;
            }
            case 2: {
                f >> x;
                rpheap.delete_value(x);
                break;
            }
            case 3: {
                f >> x;
                g << rpheap.contains(x) << '\n';
                break;
            }
            case 4: {
                f >> x;
                g << rpheap.max_leq(x) << '\n';
                break;
            }
            case 5: {
                f >> x;
                g << rpheap.min_geq(x) << '\n';
                break;
            }
            case 6: {
                f >> x >> y;
                for (auto element : rpheap.sorted_range(x, y))
                    g << element << ' ';
                g << '\n';
                break;
            }
            default: g << "eroare\n"; break;
        }
    }
    f.close();
    g.close();
    return 0;
}
