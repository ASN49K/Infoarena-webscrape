#include<bits/stdc++.h>
#include<fstream>
using namespace std;
ifstream f("abce.in");
ofstream g("abce.out");


class Node{
public:
    int key;
    Node **forward;
    Node(int,int);
};
Node::Node(int key, int level)
{
    this->key=key;
    forward= new Node*[level+1];
    //umplem vectorul forward cu 0
    memset(forward,0,sizeof(Node*)*(level+1));

}

class SkipList{
    int MAXL;
    float P;
    int level;
    Node* header;
public:
    SkipList(int, float);
    int RandomLvl();
    Node* NewNode(int, int);
    void AdaugareNod(int);
    void CautareNod(int);
    void StergereNod(int);
    void AfisareLista();
    void Cautaremax(int);
    void Cautaremin(int);
    void IntreXsiY(int,int);
};

SkipList::SkipList(int MAXL, float P)
{
    this->MAXL=MAXL;
    this->P=P;
    level=0;
    header=new Node(-1,MAXL);
}

int SkipList::RandomLvl()
{
    float r=(float)rand()/RAND_MAX;
    int lvl=0;
    while(lvl<MAXL && r<P)
    {
        lvl++;
        r=(float)rand()/RAND_MAX;
    }
    return lvl;
}

Node* SkipList::NewNode(int key, int level)
{
    Node* n= new Node(key,level);
    return n;
}

void SkipList::AdaugareNod(int key)
{
    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));

    for(int i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current==NULL || current->key!=key)
    {
        int newlevel=RandomLvl();

        if(newlevel>level)
        {
            for(int i=level+1;i<newlevel+1;i++)
                update[i]=header;
            level=newlevel;
        }
        Node* n=NewNode(key,newlevel);
        for(int i=0;i<=newlevel;i++)
        {
            n->forward[i]=update[i]->forward[i];
            update[i]->forward[i]=n;
        }
        //cout<<"Am inserat nodul "<<key<<endl;

    }
    //else
        //cout<<"Nod existent"<<endl;
}


void SkipList::StergereNod(int key)
{

    Node* current=header;
    Node* update[MAXL+1];
    memset(update, 0, sizeof(Node*)*(MAXL+1));
    for(int i =level; i>=0;i--)
    {
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
        update[i]=current;
    }
    current=current->forward[0];
    if(current!=NULL || current->key==key)
    {
        for(int i=0;i<=level;i++)
        {
            if(update[i]->forward[i]!=current)
                break;
            update[i]->forward[i]=current->forward[i];

        }
        while(level>0&& header->forward[level]==0)
            level--;
        //cout<<"Am sters elementul "<<key<<endl;
    }
    //else
        //cout<<key<<": Element inexistent"<<endl;

}

void SkipList::CautareNod(int key)
{
    Node* current= header;
    for(int i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];
    current=current->forward[0];
    if(current and current->key==key)
        cout<<1<<endl;
    else
        cout<<0<<endl;

}

void SkipList::Cautaremax(int key)
{
    Node* current=header;
        for(int i =level; i>=0;i--)
            while(current->forward[i]!=NULL && current->forward[i]->key<key)
                current=current->forward[i];
    if(current->forward[0]->key==key)
        cout<<current->forward[0]->key<<endl;
    else
        cout<<current->key<<endl;
}

void SkipList::IntreXsiY(int x, int y)
{
    Node* current=header;
    for(int i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<x)
            current=current->forward[i];
    current=current->forward[0];
    while(current->forward[0]!=NULL && current->forward[0]->key<=y)
    {
        cout<<current->key<<" ";
        current=current->forward[0];
    }
    if(current->key<=y)
        cout<<current->key;
    cout<<endl;
}


void SkipList::Cautaremin(int key)
{
    Node* current=header;
    for(int i =level; i>=0;i--)
        while(current->forward[i]!=NULL && current->forward[i]->key<key)
            current=current->forward[i];

    cout<<current->forward[0]->key<<endl;
}


SkipList lista(6,0.5);

int main()
{
    int Q, tip,x,y;
    f>>Q;
    for(int i=0;i<Q;i++)
    {
        f>>tip;
        if(tip==1)
        {
            f>>x;
            lista.AdaugareNod(x);
        }
        else if(tip==2)
        {
            f>>x;
            lista.StergereNod(x);
        }
        else if(tip==3)
        {
            f>>x;
            lista.CautareNod(x);
        }
        else if(tip==4)
        {
            f>>x;
            lista.Cautaremax(x);
        }
        else if(tip==5)
        {
            f>>x;
            lista.Cautaremin(x);
        }
        else
        {
            f>>x>>y;
            lista.IntreXsiY(x,y);
        }
    }
    return 0;
}
