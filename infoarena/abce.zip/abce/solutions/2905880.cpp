#include <iostream>
#include<bits/stdc++.h>
using namespace std;
/*
Contine:
    - structura de nod cu fiulStang si fiulDrept (fiecare are o valueoare si o prioritate)
    - 2 fctii rotationLefttanga + rotationRightreapta
    - functia Inserare
    - functia cautare
    - functia stergere
    - predecesor + succesor
    - random priority


    * Pt ca un treap este un arbore de cautare binar, nodurile din Treap vor avea aceeasi proprietate:
    prioritatea copilului > prioritatea parintelui (root->priority < child -> priority)

    * Proprietatea arborelui binar de cautare ne spune ca orice copil care are key-ul/valoarea maai mica decat
    a parintelui va fi inserat la stanga cu rotate_left, si orice copil cu key-ul mai mare decat key-ul parintelui
    va fi inserat la dreapta cu rotate_right

    * Lucrul important despre prioritatea in Treap e faptul ca prioritatile sunt asignate random si unic
    * Treap poate suporta add(x) si delete(x). Pentru a mentine proprietatea heap-ului, va fi nevoie sa se faca rotiri

    * O rotatie intr-un arbore binar este o modificare locala ce ia parintele u al unui nod w si il face
    pe w parintele lui u, pastrand proprietatea arborelui. O rotatie poate fi la stanga sau la dreapta in functie
    de unde este pozitionat copilul in subarbore (stanga sau dreapta).

    * Add -> cand adaugam un nod nou u, ii atribuim un key/valueoare si o prioritate random
    Il inseram ca o frunza, apoi verificam sa vedem daca nu cumva prioritatea parintelui e mai mare
    decat cea a lui u, daca e facem o rotatie a.i. copilul devine parintele parintelui
    si repatam pana cand prioritatile sunt in ordine ok

    O(log n) expected running time
    * Remove/Delete va fi inversul lui Add(x). Se va cauta nodul u cu key x, se vor face
    rotatii pana u ajunge sa fie o frunza jos de tot, apoi il eliminam.
    Ca sa ne asiguram ca treapul ramane conectat corect, exista trei tipuri de operatii:
    - daca nodul u nu are copii (stg, dr == null) atunci u e frunza si nu se efectuaza rotatii
    - daca copilul din stanga/dreapta e null, atunci se face o rotatie la dreapta/ stanga
    - daca prioritatea copilului din stanga < pr copilului din dreapta se face o rotatie la dreapta, altfel daca left.priority > right.priority in sens invers la nodul parinte u



*/
ifstream in("in.in");
ofstream out("out.out");


struct Treap
{
    int key;
    int priority;
    Treap *leftNode,*rightNode;
    Treap(int key)
    {
        this->key=key;
        this->priority=rand() %300;
        this->leftNode=nullptr;
        this->rightNode=nullptr;
    }
};
Treap* rotationLeft(Treap* &A)
{
    Treap* B =A->rightNode;
    Treap* C =A->rightNode->leftNode;
    A->rightNode=C;
    B->leftNode=A;
    A=B;
    return B;
}
Treap* rotationRight(Treap* &A)
{
    Treap* B = A->leftNode;   //copilul stang al radacinii
    A->leftNode= B->rightNode;  //de radacina se va lega copilul dreapt al copilului stang al radacinii
    B->rightNode=A;           //in dreapta copilului stang al radacinii se va lega radacina
    A=B;                       //la final radacina devine copilul stang
    return B;
}
Treap* addNode(Treap *&A,int key)
{
    if(!A)
    {
        A=new Treap(key);
        return A;
    }
    if(key < A->key)
    {
        addNode(A->leftNode,key);

        if(!A->leftNode  && A->leftNode->priority > A->priority)
            rotationRight(A);
    }
    else
    {
        addNode(A->rightNode,key);

        if(!A->rightNode && A->rightNode->priority > A->priority)
            rotationLeft(A);
    }
    return A;
}

bool searchValue(Treap *A,int value)
{
    if(A == nullptr)
        return 0;
    if(A->key == value)
        return 1;
    if (value < A->key)
        return searchValue(A->leftNode,value);
    else return searchValue(A->rightNode,value);

}
Treap* DeleteNod(Treap* &A,int value)
{
    if(A == nullptr)
        return A;
    if ( value < A->key)
        DeleteNod(A->leftNode,value);
    else if (value >A->key)
        DeleteNod(A->rightNode,value);
    else
    {

        if(!A -> leftNode)
        {
            delete A;
            A=nullptr;
        }

        else if(!A->rightNode)
        {
            delete A;
            A=nullptr;
        }


        else if (A->leftNode && A->rightNode)
        {
            if(A->leftNode->priority < A->rightNode->priority)
            {
                rotationLeft(A);
                DeleteNod(A->leftNode,value);
            }
            else
            {
                rotationRight(A);
                DeleteNod(A->rightNode,value);

            }
        }

        else
        {
            Treap* child = (A->leftNode)? A->leftNode:A->rightNode;
            Treap* aux = A;
            A= child;
            delete aux;

        }

    }
    return A;
}
void AfisInterval(Treap* A,int value1,int value2)
{
    if (A)
    {
        AfisInterval(A->leftNode,value1,value2);
        if(A->key > value1 && A->key <value2)
            out<<A->key<<" ";
        AfisInterval(A->rightNode,value1,value2);
    }

    return;
}
int predecessor(Treap* A, int x, int& maxi)
{


    if(!A)
    {
        return maxi;
    }
    if(A)

    {

        if(A->key==x)
            return x;

        else if(A->key<x)
        {
            if(A->key >= maxi)
            {
                maxi=A->key;
            }
            predecessor(A->rightNode, x, maxi);
        }
        else predecessor(A->leftNode, x, maxi);
    }
}

int succesor(Treap *A,int value,int &mini)
{
    if(!A)
    {
        return mini;
    }

    if(A)
    {

        if(A->key > value)
        {
            if(A->key < mini)
            {

                mini = A -> key;
                succesor(A -> leftNode, value, mini);
            }
        }
        else succesor(A->rightNode,value,mini);
    }
}
int main()
{
    int q, x, value, z;
    in>>q;

    Treap* A= nullptr;
    for(int i=0; i<q; i++)
    {
        in>>x;
        if(x==1)
        {
            in>>value;
            A=addNode(A, value);


        }
        else if (x==2)
        {
            in>>value;

            A=DeleteNod(A, value);

        }
        else if (x==3)
        {
            in>>value;
            out<<searchValue(A, value)<<"\n";
        }
        else if (x==4)
        {
            in>>value;
            int maxi=-1000000000;
            out<<predecessor(A, value, maxi)<<"\n";
        }
        else if (x==5)
        {

            in>>value;
            int mini=1000000000;
            out<<succesor(A, value, mini)<<"\n";
        }
        else if (x==6)
        {
            in>>value>>z;
            AfisInterval(A, value, z);
            out<<"\n";
        }

    }

    return 0;
}
