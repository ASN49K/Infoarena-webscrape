#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("abce.in");
ofstream fout("abce.out");

class Treaps
{
public: // trebuie declarat public, altfel primim erori de inaccesibilitate
    int value;
    int code;
    Treaps *left;
    Treaps *right;
    // Treaps *parent;

    Treaps()
    {
        // constructor default;
        value = 0;
        code = 0;
        left = NULL;
        right = NULL;
        // parent = NULL;
    }

    Treaps(int value_, int code_, Treaps *left_, Treaps *right_)
    {
        // constructor cu mai multi parametri
        value = value_;
        code = code_;
        left = left_;
        right = right_;
        // parent = parent_;
    }
};
void dealloc(Treaps *&node)
{
    if (node != NULL)
    {
        if (node->left != NULL)
            dealloc(node->left);
        if (node->right != NULL)
            dealloc(node->right);
        delete node;
        node = NULL;
    }
}

// Treaps *root_ = NULL;

Treaps *AnotherTreap(int value, int code)
{
    Treaps *another = new Treaps(value, code, NULL, NULL);
    return another;
}

bool find(Treaps *&node, int value)
{
    if (node == NULL)
        return false;
    if (node->value == value)
        return true;
    else if (node->value < value)
        return find(node->left, value);
    else
        return find(node->right, value);
}

Treaps *rotate_left(Treaps *&node)
{
    Treaps *left_branch = node->left;
    Treaps *right_left_branch = left_branch->right;
    left_branch->right = node;
    node->left = right_left_branch;
    return left_branch;
    // Treaps *other = node->right;
    // other->parent = node->parent;
    // if (other->parent != NULL)
    // {
    //     if (other->parent->left == node)
    //         other->parent->left = node;
    //     else
    //         other->parent->right = other;
    // }
    // node->right = other->left;
    // if (node->right != NULL)
    //     node->right->parent = node;
    // node->parent = other;
    // other->left = node;
    // if (node == root_)
    // {
    //     root_ = other;
    //     root_->parent = NULL;
    // }
    // return other;
}

Treaps *rotate_right(Treaps *&node)
{
    Treaps *right_branch = node->right;
    Treaps *left_right_branch = node->right->left;
    right_branch->left = node;
    node->right = left_right_branch;
    return right_branch;
    // Treaps *other = node->left;
    // other->parent = node->parent;
    // if (other->parent != NULL)
    // {
    //     if (other->parent->left == node)
    //         other->parent->left = other;
    //     else
    //         other->parent->right = other;
    // }
    // node->left = other->right;
    // if (node->left != NULL)
    //     node->left->parent = node;
    // node->parent = other;
    // other->right = node;
    // if (node == root_)
    // {
    //     root_ = other;
    //     root_->parent = NULL;
    // }
    // return other;
}

Treaps *insert(Treaps *node, int value, int code)
{
    if (node == NULL)
    {
        node = AnotherTreap(value, code);
        return node;
    }
    if (value <= node->value)
    {
        node->left = insert(node->left, value, code);
        // fata de BSTs, Treaps mai au proprietatea sa verifice codul (pt prioritate) a valorilor adaugate
        // codul trebuie sa fie mai mare fata de parinte (teorie Cormen)
        if (node->left->code < node->code)
            node = rotate_right(node);
        // rotim pentru echilibrare
        // fiind pe ramura stanga, echilibram pe dreapta
    }
    else
    {
        node->right = insert(node->right, value, code);
        if (node->right->code < node->code)
            // fiind pe ramura dreapta, echilibram pe stanga
            node = rotate_left(node);
    }
    return node;
}

Treaps *remove(Treaps *&node, int value)
{
    if (node == NULL)
        return NULL;
    if (value < node->value)
        node->left = remove(node->left, value);
    else if (value > node->value)
        node->right = remove(node->right, value);
    else
    {
        // am gasit nodul pe care vrem sa il eliminam

        // Cazul 1,nodul este o frunza
        if (node->left == NULL && node->right == NULL)
        {
            delete node;
            return NULL;
        }

        // Cazul 2, nodul are un singur copil
        if (node->left == NULL)
        {
            Treaps *R_C = node->right;
            delete node;
            node = R_C;
        }
        else if (node->right == NULL)
        {
            Treaps *L_C = node->left;
            delete node;
            node = L_C;
        }
        else if (node->left->code < node->right->code)
        {
            node = rotate_left(node);
            node->left = remove(node->left, value);
        }
        else if (node->right->code <= node->left->code)
        {
            node = rotate_right(node);
            node->right = remove(node->right, value);
        }
    }
    return node;
}

int main()
{
    Treaps *tree = NULL;
    int Q, choice, nr;
    fin >> Q;
    for (int i = 1; i <= Q; i++)
    {
        fin >> choice;
        switch (choice)
        {
        case 1:
            fin >> nr;
            tree = insert(tree, nr, rand() % 65535);
            break;
        case 2:
            fin >> nr;
            remove(tree, nr);
            break;
        case 3:
            fin >> nr;
            fout << find(tree, nr);
            break;
        }
    }
    // dealloc(tree);
    return 0;
}