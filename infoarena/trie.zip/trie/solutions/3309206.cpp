#include <bits/stdc++.h>

using namespace std;

struct nod{
    int cnt, nrfii;
    nod *fiu[26];
    nod(){
        cnt=0;
        nrfii=0;
        for (int i=0;i<26;i++){
            fiu[i]=nullptr;
        }
    }
};

void adaugacuvant(nod * trie, string cuvant, int lit=0){
    if (lit<(int)cuvant.size()){
        char curr=cuvant[lit];
        if (trie->fiu[curr-'a']==nullptr){
            trie->fiu[curr-'a']=new nod;
            trie->nrfii++;
        }
        adaugacuvant(trie->fiu[curr-'a'], cuvant, lit+1);
    }
    else{
        trie->cnt++;
    }
}

int aparitiicuvant(nod * trie, string cuvant, int lit=0){
    if (lit<(int)cuvant.size()){
        char curr=cuvant[lit];
        if (trie->fiu[curr-'a']==nullptr){
            return 0;
        }
        return aparitiicuvant(trie->fiu[curr-'a'], cuvant, lit+1);
    }
    else{
        return trie->cnt;
    }
}

int stergecuvant(nod * trie, string cuvant, int lit=0){
    if (lit<(int)cuvant.size()){
        char curr=cuvant[lit];
        if (trie->fiu[curr-'a']==nullptr){
            return 0;
        }
        int stersfiu=stergecuvant(trie->fiu[curr-'a'], cuvant, lit+1);
        if (stersfiu==1){
            trie->nrfii--;
            trie->fiu[curr-'a']=nullptr;
        }
    }
    else{
        trie->cnt--;
    }
    if (trie->cnt==0 && trie->nrfii==0 && lit!=0){
        delete trie;
        return 1;
    }
    return 0;
}

int prefixcuvant(nod *trie, string cuvant, int lit=0, int nivel=0){
    if (lit<(int)cuvant.size()){
        char curr=cuvant[lit];
        if (trie->fiu[curr-'a']==nullptr){
            return nivel;
        }
        return prefixcuvant(trie->fiu[curr-'a'], cuvant, lit+1, nivel+1);
    }
    else{
        return nivel;
    }
}

int main()
{
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);
    nod * trie = new nod;
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    while (true){
        int op;string cuv;
        if (cin>>op){
            cin>>cuv;
            if (op==0){
                adaugacuvant(trie, cuv);
            }
            else if (op==1){
                stergecuvant(trie, cuv);
            }
            else if (op==2){
                cout<<aparitiicuvant(trie, cuv)<<'\n';
            }
            else if (op==3){
                cout<<prefixcuvant(trie, cuv)<<'\n';
            }
        }
        else{
            break;
        }
    }
    return 0;
}
