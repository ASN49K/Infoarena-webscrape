#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <climits>
#include <iomanip>
#include <cmath>

#define MOD 666013
#define INT_MAX 1000000000

using namespace std ;

ifstream cin ("trie.in") ;
ofstream cout ("trie.out") ;

struct nod
{
    int val = 0, prefix = 0 ;

    nod *v[30] = {0} ;
};

void update(nod *&tata, string a)
{
    if(!tata)tata = new nod ;

    tata -> prefix ++ ;

    if(a.size() == 0)
    {
        tata -> val ++ ;

        return ;
    }
    update(tata -> v[a[0] - 'a'], &a[1]) ;
}

void del(nod *tata, string a)
{
    tata -> prefix -- ;

    if(a.size() == 0)
    {
        tata -> val -- ;

        return ;
    }

    del(tata -> v[a[0] - 'a'], &a[1]) ;
}

int query(nod *tata, string a)
{
    if(!tata)return 0 ;

    if(a.size() == 0)return tata -> val ;

    return query(tata -> v[a[0] - 'a'], &a[1]) ;
}

int cauta(nod *tata, string a, int k)
{
    if(!tata)return 0 ;

    if(!a.size())return k ;

    return max(k * (bool)(tata -> prefix != 0), cauta(tata -> v[a[0] - 'a'], &a[1], k + 1)) ;
}

nod *root = 0 ;

int main()
{
    string a ;
    int p ;

    while(cin >> p >> a)
    {
        if(p == 0) /// adauga pe a
        {
            update(root, a) ;
        }
        if(p == 1) /// sterge pe a
        {
            del(root, a) ;
        }
        if(p == 2) /// de cate ori apare a
        {
            cout << query(root, a) << '\n' ;
        }
        if(p == 3) /// prefix etc
        {
            cout << cauta(root, a, 0) << '\n' ;
        }
    }

    return 0 ;
}


