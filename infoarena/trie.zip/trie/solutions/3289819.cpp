#include <fstream>
#include <string>
using namespace std;
ifstream f("trie.in");
ofstream g("trie.out");
struct trie{
    int aps=0;
    signed char children=0;
    trie* urm[26]={NULL};
}*root;
void add(trie* nod, char* it)
{
    char c=*it;
    if(c=='\0')
    {
        nod->aps++;
        return;
    }
    if(nod->urm[c-'a']==NULL)
    {
        nod->urm[c-'a']=new trie;
        nod->children++;
    }
    add(nod->urm[c-'a'],it+1);
}
bool erase(trie* nod, char* it)
{
    char c=*it;
    if(c=='\0')
        nod->aps--;
    else if(erase(nod->urm[c-'a'],it+1))
    {
        nod->children--;
        nod->urm[c-'a']=NULL;
    }
    if(nod->aps+nod->children==0&&nod!=root)
    {
        delete nod;
        return true;
    }
    return false;
}
int count_aparitions(trie* nod, char* it)
{
    char c=*it;
    if(c=='\0')
        return nod->aps;
    if(nod->urm[c-'a']==NULL)
        return 0;
    return count_aparitions(nod->urm[c-'a'],it+1);
}
int prefix_length(trie* nod, char* it)
{
    char c=*it;
    if(c=='\0'||nod->urm[c-'a']==NULL)
        return 0;
    return 1+prefix_length(nod->urm[c-'a'],it+1);
}
int main()
{
    root=new trie;
    int c;
    string str;
    while(f>>c>>str)
        switch(c)
        {
            case 0:
            add(root,&str[0]);
            break;
            case 1:
            erase(root,&str[0]);
            break;
            case 2:
            g<<count_aparitions(root,&str[0])<<'\n';
            break;
            case 3:
            g<<prefix_length(root,&str[0])<<'\n';
            break;
        }
    return 0;
}