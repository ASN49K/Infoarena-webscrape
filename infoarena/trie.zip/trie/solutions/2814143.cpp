#include <fstream>
#include <vector>
using namespace std;
ifstream Gigi ("trie.in");
ofstream Marcel ("trie.out");
/*
aparitii
capete
26 fii cu fiecare dupa
*/

class nod
    {
    public:

        int aparitii;
        int capete;
        vector <nod*> fii;

        nod()
        {
            fii.resize(26, NULL);
            aparitii=0;
            capete=0;
        }

    };
class trie
{

public:


    nod* radacina=new nod();
    void insert(char* s)
    {
        radacina=insert_(s,radacina);
    }
    void erase(char* s)
    {
        radacina=erase_(s,radacina);
    }
    int pref(char* s)
    {
        return querypref(s,radacina);
    }
    int cuv(char* s)
    {
        return querycuv(s,radacina);
    }
    nod* insert_(char* s,nod* node);
    nod* erase_(char* s,nod* node);
    int querycuv(char* s,nod* node);
    int querypref(char* s,nod* node);
};

nod* trie::insert_(char* s,nod* node)
{
    if (node==NULL)
    {
        node=new nod();
    }
    node->aparitii++;
    if (s[0]==NULL)
    {
        node->capete++;
    }
    else
    {
        node->fii[s[0]-'a']=insert_(s+1,node->fii[s[0]-'a']);
    }
    return node;
}
nod* trie:: erase_(char* s, nod * node)
{
    if (node==NULL)
    {
        return node;
    }
    node->aparitii--;
    if (s[0]==NULL)
    {
        node->capete--;
    }
    else
    {
        node->fii[s[0]-'a']=erase_(s+1,node->fii[s[0]-'a']);
    }
    if (node->aparitii==0)
    {
        delete node;
        node=NULL;
    }
    return node;
}
int trie :: querypref(char * s,nod* node)
{
    if (s[0]==NULL|| node==NULL)
    {
        return 0;
    }
    if (node->fii[s[0]-'a']!=NULL)
    {
        return querypref(s+1,node->fii[s[0]-'a'])+1;
    }
    return 0;
}
int trie :: querycuv(char *s, nod* node)
{
    if (node==NULL)
    {
        return 0;
    }
    else if(s[0]==NULL)
    {
        return node->capete;
    }
    else
    {
        return querycuv(s+1,node->fii[s[0]-'a']);
    }
}
int main()
{
    char s[21];
    int n;
    trie tries;
    while(Gigi>>n)
    {
        Gigi>>s;
        switch(n)
        {
        case 0:
            tries.insert(s);
            break;
        case 1:
            tries.erase(s);
            break;
        case 2:
            Marcel<<tries.cuv(s)<<"\n";
            break;
        case 3:
            Marcel<<tries.pref(s)<<"\n";
            break;
        }
    }
    return 0;
}
