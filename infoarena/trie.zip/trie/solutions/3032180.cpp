#include <bits/stdc++.h>
#define ch (*s - 'a')
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    int aparitii, nrfii;
    Trie *fii[30];
    Trie()
    {
        nrfii = 0;
        aparitii = 0;
        for(int i = 0;i < 26;i++)
            fii[i] = 0;
    }
};

Trie *T = new Trie;
char s[30];
void Add(Trie *nod, char s[])
{
    if(s[0] == 0)
    {
        nod ->aparitii++;
        return;
    }
    if(nod -> fii[s[0] - 'a'] == 0)
    {
       nod -> fii[s[0] - 'a'] = new Trie;
       nod -> nrfii++;
    }
    Add(nod ->fii[s[0] - 'a'], s + 1);
}
bool Delete(Trie *nod, char s[])
{
    if(s[0] == 0)
        nod -> aparitii--;
    else
    {
        if(Delete(nod -> fii[ch], s + 1))
        {
            nod ->nrfii--;
            nod ->fii[s[0] - 'a'] = 0;
        }

    }
    if(nod -> aparitii == 0 && nod -> nrfii == 0 && nod != T)
    {
        delete nod;
        return true;
    }
    return false;
}

int NrCuv(Trie *nod, char s[])
{
    if(s[0] == 0)
        return nod -> aparitii;
    if(nod -> fii[s[0] - 'a'] != 0)
        return NrCuv(nod -> fii[ch], s + 1);
    return 0;
}
int Prefix(Trie *nod, char *s, int l)
{
    if(s[0] == 0 || nod -> fii[s[0] - 'a'] == 0)
        return l;
    return Prefix(nod -> fii[s[0] - 'a'], s + 1, l + 1);
}
int main()
{
    int op;
    while(fin >> op >> s)
    {
        if(op == 0)
            Add(T, s);
        if(op == 1)
            Delete(T, s);
        if(op == 2)
            fout << NrCuv(T, s) << "\n";
        if(op == 3)
            fout << Prefix(T, s, 0) << "\n";
    }
    return 0;
}
