#include <fstream>
#include <unordered_map>

using namespace std;
unordered_map <int, int[30]> m;
int main()
{
	ifstream cin("trie.in");
	ofstream cout("trie.out");

	int o, cnt=0, l, nr=1;
	string s;
	m[0][28]=-1;
	m[0][27]++;

	while(cin>>o>>s)
	{
		if(o==0)
		{
			l=0;
            for(int i=0;i<s.size();i++)
			{
                if(m[l][s[i]-'a'+1]==0)
				{
					m[l][s[i]-'a'+1]=nr;
					m[nr][28]=l;
					m[nr][27]++;
					l=nr;
					nr++;
				}
				else
				{
					l=m[l][s[i]-'a'+1];
					m[l][27]++;
				}
			}
			m[l][27]++;
			m[l][29]++;
		}
		else if(o==1)
		{
			l=0;
            for(int i=0;i<s.size();i++)
			{
                if(m[l][s[i]-'a'+1]==0)
				{
					m[l][s[i]-'a'+1]=nr;
					m[nr][28]=l;
					m[nr][27]--;
					l=nr;
					nr++;
				}
				else
				{
					l=m[l][s[i]-'a'+1];
					m[l][27]--;
				}
			}
			m[l][27]--;
			m[l][29]--;
		}
		else if(o==2)
		{
			l=0;
			for(int i=0;i<s.size();i++)
			{
                if(m[l][s[i]-'a'+1]==0)
				{
					m[l][s[i]-'a'+1]=nr;
					m[nr][28]=l;
					l=nr;
					nr++;
				}
				else
				{
					l=m[l][s[i]-'a'+1];
				}
			}
			cout<<m[l][29]<<'\n';
		}
		else
		{
			l=0;
			cnt=0;
            for(int i=0;i<s.size();i++)
			{
                if(m[l][s[i]-'a'+1]==0 || m[m[l][s[i]-'a'+1]][27]==0)
				{
					break;
				}
				else
				{
					l=m[l][s[i]-'a'+1];
					cnt++;
				}
			}
			cout<<cnt<<'\n';
		}
	}

    return 0;
}
