#include <bits/stdc++.h>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

int N = 0, nxt[20*30][26], terminal[20*30], nr_cuvinte[20*30];

void adauga(string s);
void sterge(string s);
int nr_aparitii(string s);
int lungimea_celui_mai_lung_prefix_comun_cu_un_alt_cuvant(string s);

int main()
{
    int x;
    string s;

    while(fin >> x)
    {
        fin >> s;
        if(x == 0) adauga(s);
        else if(x == 1) sterge(s);
        else if(x == 2) fout << nr_aparitii(s) << '\n';
        else fout << lungimea_celui_mai_lung_prefix_comun_cu_un_alt_cuvant(s) << '\n';
    }

    return 0;
}

void adauga(string s)
{
    int nod = 0;

    nr_cuvinte[0]++;
    for(char c:s)
    {
        if(nxt[nod][c-'a'] == 0) nxt[nod][c-'a'] = ++N;
        nod = nxt[nod][c-'a'], nr_cuvinte[nod]++;
    }
    terminal[nod]++;
}

void sterge(string s)
{
    int nod = 0;

    nr_cuvinte[0]--;
    for(char c:s) nod = nxt[nod][c-'a'], nr_cuvinte[nod]--;
    terminal[nod]--;
}

int nr_aparitii(string s)
{
    int nod = 0;

    for(char c:s)
    {
        if(nxt[nod][c-'a'] == 0) return 0;
        else nod = nxt[nod][c-'a'];
    }

    return terminal[nod];
}

int lungimea_celui_mai_lung_prefix_comun_cu_un_alt_cuvant(string s)
{
    int nod = 0, nr = 0;

    for(char c:s)
    {
        if(nxt[nod][c-'a'] == 0 || nr_cuvinte[nxt[nod][c-'a']] == 0) break;
        nod = nxt[nod][c-'a'], nr++;
    }

    return nr;
}
