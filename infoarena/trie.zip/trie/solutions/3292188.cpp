#include <iostream>
#include<fstream>
using namespace std;ifstream fin("trie.in");ofstream fout("trie.out");int k;string s;
struct Nod{
int val,cuv;Nod *v[26];
Nod(){val=cuv=0;for(int i=0;i<26;i++)v[i]=nullptr;}

void add(int poz=0){
    int ch=s[poz]-'a';
if(v[ch]==nullptr){
    v[ch]=new Nod();
}v[ch]->val++;
if(poz==s.size()-1)v[ch]->cuv++;
else v[ch]->add(poz+1);
}

void delt(int poz=0){
    int ch=s[poz]-'a';v[ch]->val--;
    if(poz==s.size()-1){
            v[ch]->cuv--;
        if(v[ch]->val==0){
            delete v[ch];
            v[ch]=nullptr;
            return;
        }
    }v[ch]->delt(poz+1);
    if(v[ch]->val==0){delete v[ch];v[ch]=nullptr;}
}
void cnt(int poz=0){
    int ch=s[poz]-'a';
    if(poz==s.size()-1){
        fout<<v[ch]->cuv<<'\n';
        return;
    }
    v[ch]->cnt(poz+1);
}

int comun(int poz=0){
    int ch=s[poz]-'a';
    if(v[ch]==nullptr)return 0;
    if(poz==s.size()-1)return 1;
        return 1+v[ch]->comun(poz+1);
}
};
int main()
{
    Nod T;
    while(fin>>k>>s){
        if(k==0)T.add();
        else if(k==1)T.delt();
        else if(k==2)T.cnt();
        else fout<<T.comun()<<'\n';
    }
    return 0;
}
