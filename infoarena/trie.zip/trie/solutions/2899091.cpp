#include<bits/stdc++.h>
#define teta 26
using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct trie
{
    int k,p;
    trie *son[teta]={};
    trie()
    {
        this->k=0;
        this->p=0;
        memset(this->son,0,sizeof(this->son));
    }
};

void insertt(trie *t, char s[], int lenght, int val)
{
    t->p+=val;
    if(lenght==0)
    {
        t->k+=val;
        return;
    }
    if(t->son[s[0]-'a']==nullptr)
    {
        trie *nod=new trie;
        t->son[s[0]-'a']=nod;
    }
    insertt(t->son[s[0]-'a'],s+1,lenght-1,val);
}

int q2(trie *t, char s[], int lenght)
{
    if(lenght==0)
    {
        return t->k;
    }
    if(t->son[s[0]-'a']==nullptr)
        return 0;
    return q2(t->son[s[0]-'a'],s+1,lenght-1);
}

int q3(trie *t, char s[], int lenght, int maxlenght)
{
    if(lenght==0)
    {
        return maxlenght;
    }
    if(t->son[s[0]-'a']==nullptr || t->son[s[0]-'a']->p==0)
        return maxlenght-lenght;
    return q3(t->son[s[0]-'a'],s+1,lenght-1,maxlenght);
}

int main()
{
    int nr;
    char s[23];
    trie *T=new trie;
    while(f>>nr>>s)
    {
        if(nr==0)
        {
            insertt(T,s,strlen(s),1);
        }
        else
        if(nr==1)
        {
            insertt(T,s,strlen(s),-1);
        }
        else
        if(nr==2)
        {
            g<<q2(T,s,strlen(s))<<'\n';
        }
        else
            g<<q3(T,s,strlen(s),strlen(s))<<'\n';
    }
    return 0;
}
