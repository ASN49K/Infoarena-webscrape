#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <cstring>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

int n;

struct Nod
{
    int cnt;
    int nrc;
    Nod* urmator[30];

    Nod(){
        cnt = 0;
        nrc = 0;
        for (size_t i = 0;i < 26;i++)urmator[i] = nullptr;
    }
}*l;

void update0(Nod* l,char* c,int lg);
bool update1(Nod* l,char* c,int lg);
int query0(Nod* l,char* c,int lg);
int query1(Nod* l,char* c,int lg,int rez);

int main()
{
    l = new Nod();
    int cerinta;
    char c[25];
    while(f >> cerinta){
        f.get();
        f.getline(c,25);
        if (cerinta == 0)update0(l,c,strlen(c));
        else if (cerinta == 1)update1(l,c,strlen(c));
        else if (cerinta == 2)g << query0(l,c,strlen(c)) << '\n';
        else g << query1(l,c,strlen(c),0) << '\n';
        
    }
}

void update0(Nod* l,char* c,int lg)
{
    if (lg == 0){l->cnt++;return;}
    int i = *c - 'a';

    if (l->urmator[i] == nullptr){
        l->urmator[i] = new Nod();
        l->nrc++;
    }
    update0(l->urmator[i],c+1,lg-1);
}

bool update1(Nod* l,char* c,int lg)
{
    if (lg == 0){
        l->cnt--;
        if (l->cnt == 0 && l->nrc == 0){
            delete l;
            return true;
        }
        return false;
    }
    int i = *c - 'a';

    if (update1(l->urmator[i],c+1,lg-1) ==  true){
        l->nrc--;
        l->urmator[i] = nullptr;
    }
    if (l->cnt == 0 && l->nrc == 0){
        delete l;
        return true;
    }
    return false;
}

int query0(Nod* l,char* c,int lg)
{
    if (lg == 0)return l->cnt;
    int i = *c - 'a';
    if (l->urmator[i] == nullptr)return 0;
    return query0(l->urmator[i],c+1,lg-1);
}

int query1(Nod* l,char* c,int lg,int rez)
{
    if (lg == 0)return rez; 
    int i = *c - 'a';
    if (l->urmator[i] == nullptr)return rez;
    return query1(l->urmator[i],c+1,lg-1,rez+1);
}