///define val = frecventa nodului
#include <fstream>
#include <string>
#include <string.h>
#include <map>

using namespace std;

ifstream cin ("trie.in");
ofstream cout ("trie.out");

const int N = 26;

int cer;

char s[N];

map <string, int> m;

struct trie
{
    trie * fii[N];
    int val;
    trie ()
    {
        val = 1;
        memset (fii, 0, sizeof (fii));
    }
};

trie * root = new trie;

void insertus (trie * root, char * s)
{
    if (*s != NULL)
    {
        trie * nod = root;
        int pos = *s - 'a';
        if (nod->fii[pos] == NULL)
            nod->fii[pos] = new trie;
        else
            nod->fii[pos]->val++;
        insertus (nod->fii[pos], s + 1);
    }
}

void deletus (trie * root, char * s)
{
    if (*s != NULL)
    {
        trie * nod = root;
        int pos = *s - 'a';
        if (nod->fii[pos] != NULL)
        {
            deletus (nod->fii[pos], s + 1);
            if (nod->fii[pos]->val - 1 > 0)
                nod->fii[pos]->val--;
            else
            {
                nod->fii[pos] = 0;
                delete nod->fii[pos];
            }
        }
    }
}

int prefix (trie * root, char * s)
{
    trie * nod = root;
    int last = -1, n = strlen (s);
    for (int i = 0; i < n; ++i)
    {
        int pos = s[i] - 'a';
        if (nod->fii[pos] != NULL)
            last = i;
        else
            break;
        nod = nod->fii[pos];
    }
    return last + 1;
}

int main()
{
    while (cin >> cer >> s)
    {
        switch (cer)
        {
        case 0 :
            insertus (root, s), m[s]++;
            break;
        case 1:
        {
            deletus (root, s);
            if (m.find (s) != m.end())
                m[s]--;
            break;

        }

        case 2:
            cout << m[s] << '\n';
            break;
        case 3:
            cout << prefix (root, s)  << '\n';
            break;
        }
    }
    return 0;
}
