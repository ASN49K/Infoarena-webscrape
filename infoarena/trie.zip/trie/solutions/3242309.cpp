#include <iostream>
#include <fstream>
#include <unordered_map>
#include <stack>
#include <string>
#define nl '\n'

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

const int NMAX = 100001, SIGMA = 26, NODES_MAX = NMAX*SIGMA;
struct node
{
    unordered_map<char, int> childs;
    unsigned short finished;
    char childsNr;
    int tata;
    char ch;
};

stack<int> st; /// stiva sa reutilizez
node trie[NODES_MAX];
int n = 1, i, op, sz, it;
string s;

int get_place()
{
    if (st.empty())
        return ++n;
    else
    {
        op = st.top();
        st.pop();
        return op;
    }
}

void add()
{
    i = 1;
    sz = s.size();
    for (it = 0; it < sz; it++)
    {
        if (!trie[i].childs[s[it]])
        {
            trie[i].childs[s[it]] = get_place();
            trie[i].childsNr++;
        }
        trie[trie[i].childs[s[it]]].tata = i;
        trie[trie[i].childs[s[it]]].ch = s[it];
        i = trie[i].childs[s[it]];
    }
    trie[i].finished++;
    return;
}

void sterge()
{
    i = 1;
    sz = s.size();
    for (it = 0; it < sz; it++)
        i = trie[i].childs[s[it]];
    trie[i].finished--;
    while (i != 1 && !trie[i].childsNr && !trie[i].finished)
    {
        trie[trie[i].tata].childsNr--;
        trie[trie[i].tata].childs.erase(trie[i].ch);
        st.push(i);
        i = trie[i].tata;
    }
    return;
}

int countApp()
{
    i = 1;
    sz = s.size();
    for (it = 0; it < sz; it++)
    {
        if (!trie[i].childs[s[it]])
            return 0;
        i = trie[i].childs[s[it]];
    }
    return trie[i].finished;
}

int longestPrefix()
{
    i = 1;
    sz = s.size();
    op = 0;
    for (it = 0; it < sz; it++)
    {
        if (!trie[i].childs[s[it]])
            return op;
        i = trie[i].childs[s[it]];
        op++;
    }
    return op;
}

int main()
{
    while (fin >> op)
    {
        fin >> s;
        if (op == 0)
            add();
        else if (op == 1)
            sterge();
        else if (op == 2)
            fout << countApp() << nl;
        else if (op == 3)
            fout << longestPrefix() << nl;
    }
    return 0;
}

