#include <fstream>

using namespace std;

ifstream in ("trie.in");
ofstream out ("trie.out");

class TrieNode
{
private:
    int cnt;
    int subtreecnt;
    TrieNode * edges[26];

public:
    TrieNode()
    {
        cnt = 0;
        subtreecnt = 0;

        for(int i = 0; i < 26; i++)
        {
            edges[i] = nullptr;
        }
    }

    void insert(string &word, int poz = 0)
    {
        if(poz == word.size())
        {
            subtreecnt++;
            cnt++;
            return;
        }

        int edgeidx = word[poz] - 'a';

        if(edges[edgeidx] == nullptr)
        {
            edges[edgeidx] = new TrieNode();
        }

        edges[edgeidx] -> insert(word, poz + 1);
        subtreecnt++;
    }

    void erase(string &word, int poz = 0)
    {
        if(poz == word.size())
        {
            subtreecnt--;
            cnt--;
            return;
        }

        int edgeidx = word[poz] - 'a';

        edges[edgeidx] -> erase(word, poz + 1);

        subtreecnt--;
    }

    int nr_app(string &word, int poz = 0)
    {
        if(poz == word.size())
        {
            return cnt;
        }

        int edgeidx = word[poz] - 'a';

        return edges[edgeidx] -> nr_app(word, poz + 1);
    }

    int prefix(string &word, int poz = 0)
    {
        int edgeidx = word[poz] - 'a';

        if(edges[edgeidx] == nullptr or edges[edgeidx] -> subtreecnt == 0 or poz == word.size())
            return poz;

        return edges[edgeidx] -> prefix(word, poz + 1);
    }
};

int main()
{
    int op;
    TrieNode r;
    string s;

    while(in >> op >> s)
    {
        if(op == 0)
            r.insert(s);
        else if(op == 1)
            r.erase(s);
        else if(op == 2)
            out << r.nr_app(s) << '\n';
        else if(op == 3)
            out << r.prefix(s) << '\n';
    }

    in.close();
    out.close();
    return 0;
}
