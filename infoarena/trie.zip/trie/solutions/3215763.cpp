#include<iostream>
#include<vector>
#include<deque>
#include<queue>
#include<stack>
#include<set>
#include<unordered_map>
#include<map>
#include<unordered_set>
#include<ctime>
#include<random>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<cassert>
#define fi first
#define se second
#define eb emplace_back
#define pb push_back
using namespace std;
using pii = pair<int,int>;
using ll = long long;
using ld = long double;

mt19937 rng(time(nullptr));

struct nod
{
    int cnt = 0;
    nod* next[26] = {nullptr};

    void baga(string &s,int p,int a)
    {
        if(p==s.size()) cnt += a;
        else
            {   int l = s[p]-'a';
                if(!next[l]) next[l] = new nod;
                next[l]->baga(s,p+1,a);
            }

    }

    pii info(string &s,int p)
    {
        if(s.size()==p) return {p,cnt};
        int l = s[p]-'a'; if(!next[l]) return{p,0};
        return next[l]->info(s,p+1);
    }
};

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

    freopen("trie.in","r",stdin);
    freopen("trie.out","w",stdout);

    int t; string s; nod* trie = new nod;
    while(cin >> t >> s)
    {
        if(t==0 || t == 1)
            trie->baga(s,0,t==0?1:-1);
        else
            {
                pii f = trie->info(s,0);
                if(t==2) cout << f.second << '\n';
                else cout << f.first << '\n';
            }
    }
}
