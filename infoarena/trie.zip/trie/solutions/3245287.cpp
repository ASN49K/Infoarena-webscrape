#include <bits/stdc++.h>

const std :: string FILENAME = "trie";

std :: ifstream f(FILENAME + ".in");

std :: ofstream g(FILENAME + ".out");

const int S = 30;

struct nod
{
    int fr = 0;

    nod * next[S];

    nod()
    {
        for(int i = 0; i < S; i ++)
        {
            next[i] = nullptr;
        }
    }
};

int cer;

int maxi;

std :: string s;

void add(nod * & trie, int poz)
{
    trie -> fr ++;

    if(poz < s.size())
    {
        int fiu = s[poz] - 'a';

        if(trie -> next[fiu] == nullptr)
        {
            trie -> next[fiu] = new nod;
        }

        add(trie -> next[fiu], poz + 1);
    }
}

void rem(nod * & trie, int poz)
{
    trie -> fr --;

    if(poz < s.size())
    {
        int fiu = s[poz] - 'a';

        if(trie -> next[fiu] == nullptr)
        {
            trie -> next[fiu] = new nod;
        }

        rem(trie -> next[fiu], poz + 1);
    }
}

int query(nod * trie, int poz)
{
    if(poz == s.size())
    {
        int ret = trie -> fr;

        for(int i = 0; i < S; i ++)
        {
            if(trie -> next[i] != nullptr)
            {
                ret -= trie -> next[i] -> fr;
            }
        }

        return ret;
    }

    int fiu = s[poz] - 'a';

    if(trie -> next[fiu] == nullptr || trie -> next[fiu] -> fr == 0)
    {
        return 0;
    }

    return query(trie -> next[fiu], poz + 1);
}

void query1(nod * trie, int poz)
{
    if(trie -> fr)
    {
        maxi = std :: max(maxi, poz);

        if(poz < s.size())
        {
            int fiu = s[poz] - 'a';

            if(trie -> next[fiu] != nullptr)
            {
                query1(trie -> next[fiu], poz + 1);
            }
        }
    }
}

int main()
{

    nod * trie = new nod;

    while(f >> cer >> s)
    {
        if(cer == 0)
        {
            add(trie, 0);
        }
        else if(cer == 1)
        {
            rem(trie, 0);
        }
        else if(cer == 2)
        {
            g << query(trie, 0) << '\n';
        }
        else
        {
            maxi = 0;

            query1(trie, 0);

            g << maxi << '\n';
        }
    }

    return 0;
}
