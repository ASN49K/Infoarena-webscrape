#include<bits/stdc++.h>
using namespace std;

string numeFisier="trie";
ifstream Fin(numeFisier+".in"); ofstream fout(numeFisier+".out");
#define cin Fin
#define cout fout

#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount

int cnt[2000200];
int en[2000200];
int trie[2000200][26];
int fin;

void add(string s){
int cr=0;

for(int i=0; i<s.length(); i++){
    if(trie[cr][s[i]-'a' ]==0){
        fin++;
        trie[cr][s[i]-'a' ]=fin;
    }
    cr=trie[cr][s[i]-'a' ];
    cnt[cr]++;
}
en[cr]++;

}

void del(string s){

int cr=0;
for(int i=0; i<s.length(); i++){
    cr=trie[cr][s[i]-'a' ];
    cnt[cr]--;
}
en[cr]--;

}

int app(string s){
int cr=0;

for(int i=0; i<s.length(); i++){
    if(trie[cr][s[i]-'a' ]==0){
        cr=0;
        res=0;
        break;
    }
    cr=trie[cr][s[i]-'a' ];
}

if(cr!=0){
return en[cr];
}
else{
    return 0;
}

}

int pref(string s){
int res=0;
int cr=0;

for(int i=0; i<s.length(); i++){
    if( (trie[cr][s[i]-'a' ]==0) ){
        break;
    }
    cr=trie[cr][s[i]-'a' ];
    if(cnt[cr]==0){
        break;
    }
    res++;
}

return res;
}

int32_t main(){
INIT
int tp;
string s;
while(cin>>tp){
    cin>>s;
    switch(tp){
        case 0:{
            add(s);
            break;
        }
        case 1:{
            del(s);
            break;
        }
        case 2:{
            cout<<app(s)<<"\n";
            break;
        }
        case 3:{
            cout<<pref(s)<<"\n";
            break;
        }
    }
}

return 0;
}
