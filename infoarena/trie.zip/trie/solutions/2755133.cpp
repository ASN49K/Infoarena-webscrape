#include <fstream>
#include <cstring>

using namespace std;

const int NL = 26, N = 20;

struct Nod
{
    Nod* fii[NL];
    int nr_cuv, nr_pref;

    Nod()
    {
        for (int i = 0; i < NL; i++)
        {
            fii[i] = NULL;
        }
        nr_pref = nr_cuv = 0;
    }

};

Nod* adauga_cuvant(Nod *p, char *s)
{
    if (p == NULL)
    {
        p = new Nod();
    }
    p->nr_pref++;
    if (s[0] == '\0')
    {
        p->nr_cuv++;
    }
    else
    {
        p->fii[s[0] - 'a'] = adauga_cuvant(p->fii[s[0] - 'a'], s + 1);
    }
    return p;
}

Nod* sterge_cuvant(Nod *p, char *s)
{
    p->nr_pref--;
    if (s[0] == '\0')
    {
        p->nr_cuv--;
    }
    else
    {
        p->fii[s[0] - 'a'] = sterge_cuvant(p->fii[s[0] - 'a'], s + 1);
    }
    if (p->nr_pref == 0)
    {
        delete p;
        p = NULL;
    }
    return p;
}

int nr_aparitii_cuvant(Nod *p, char *s)
{
    if (p == NULL)
    {
        return 0;
    }
    if (s[0] == '\0')
    {
        return p->nr_cuv;
    }
    return nr_aparitii_cuvant(p->fii[s[0] - 'a'], s + 1);
}

int lungime_prefix(Nod *p, char *s)
{
    if (p == NULL)
    {
        return 0;
    }
    if (s[0] == '\0')
    {
        return 0;
    }
    if (p->fii[s[0] - 'a'] == NULL)
    {
        return 0;
    }
    return 1 + lungime_prefix(p->fii[s[0] - 'a'], s + 1);
}

int main()
{
    ifstream in("trie.in");
    ofstream out("trie.out");
    Nod *r = NULL;
    int tip;
    char s[N+1];
    while (in >> tip >> s)
    {
        if (tip == 0)
        {
            r = adauga_cuvant(r, s);
        }
        if (tip == 1)
        {
            r = sterge_cuvant(r, s);
        }
        if (tip == 2)
        {
            out << nr_aparitii_cuvant(r, s) << "\n";
        }
        if (tip == 3)
        {
            out << lungime_prefix(r, s) << "\n";
        }
    }
    return 0;
}
