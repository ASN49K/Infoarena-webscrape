#include <bits/stdc++.h>

using namespace std;

ifstream fin( "trie.in" );
ofstream fout( "trie.out" );

const int SIGMA = 26;

struct Trie {
  Trie(): freq(0), nxt_cnt(0) {
	memset(nxt, 0, sizeof(nxt));
  }
  Trie* nxt[SIGMA];
  int freq; 
  int nxt_cnt;
};

char w[21];
int n;

void ins( Trie *node, int idx ) {
  if ( idx == n ) {
	++node->freq;
	return;
  }
  int z = w[idx] - 'a';
  if ( node->nxt[z] == NULL ) {
	node->nxt[z] = new Trie;
    ++node->nxt_cnt;
  }
  ins(node->nxt[z], idx + 1); 
}
Trie *del( Trie *node, int idx ) {
  if ( idx == n ) {
	--node->freq;
  } else {
    int z = w[idx] - 'a';
    node->nxt[z] = del(node->nxt[z], idx + 1);
    if ( node->nxt[z] == NULL ) --node->nxt_cnt;
  }
  if ( node->freq == 0 && node->nxt_cnt == 0 ) {
	delete node;
	return NULL;
  }
  return node;
}
int frequency( Trie *node, int idx ) {
  if ( idx == n ) {
	return node->freq;
  }
  int z = w[idx] - 'a';
  if ( node->nxt[z] == NULL ) {
	return 0;
  }
  return frequency(node->nxt[z], idx + 1);
}
int maxpref( Trie *node, int idx, int dep = 0 ) {
  if ( node == NULL ) return dep - 1;
  if ( idx == n ) return dep;

  int z = w[idx] - 'a';
  return maxpref(node->nxt[z], idx + 1, dep + 1);
}

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0);
  int tp;

  Trie *root = new Trie;
  while ( fin >> tp ) {
	fin >> w;
	n = strlen(w);
	if ( tp == 0 ) {
	  if ( root == NULL ) {
		root = new Trie;
	  }
	  ins(root, 0);
	} else if ( tp == 1 ) {
	  del(root, 0);
	} else if ( tp == 2 ) {
	  fout << frequency(root, 0) << "\n";
	} else {
	  fout << maxpref(root, 0) << "\n";
	}
  }
  fin.close();
  fout.close();
  return 0;
}
