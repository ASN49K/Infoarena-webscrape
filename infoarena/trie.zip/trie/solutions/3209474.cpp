#include <iostream>
#include <string>

using namespace std;

int tip;
string s;

struct trie {
    trie *nxt[30] = {};
    int val = 0, sz = 0;
} *root;

void add(trie *root, int pos) {
    if(pos == s.size()) {
        root->val++;
        return;
    }

    if(root->nxt[s[pos]-'a'+1] == nullptr)
        root->nxt[s[pos]-'a'+1] = new trie;
    add(root->nxt[s[pos]-'a'+1], pos+1);
    root->sz++;
}
void del(trie *root, int pos) {
    if(pos == s.size()) {
        root->val--;
        return;
    }

    root->sz--;
    del(root->nxt[s[pos]-'a'+1], pos+1);
    if(root->nxt[s[pos]-'a'+1]->sz == 0) {
        delete root->nxt[s[pos]-'a'+1];
        root->nxt[s[pos]-'a'+1] = nullptr;
    }
}
int queryap(trie *root, int pos) {
    if(pos == s.size())
        return root->val;
    else {
        if(root->nxt[s[pos]-'a'+1] == nullptr)
            return 0;
        return queryap(root->nxt[s[pos]-'a'+1], pos+1);
    }
}
int querylg(trie *root, int pos) {
    if(pos == s.size())
        return pos;
    if(root->nxt[s[pos]-'a'+1] == nullptr)
        return pos;
    else
        return querylg(root->nxt[s[pos]-'a'+1], pos+1);
}

int main()
{
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(0);

    root = new trie;
    while(cin >> tip) {
        cin >> s;
        if(tip == 0)
            add(root, 0);
        else if(tip == 1)
            del(root, 0);
        else if(tip == 2)
            cout << queryap(root, 0) << '\n';
        else
            cout << querylg(root, 0) << '\n';
        s = "";
    }
    return 0;
}
