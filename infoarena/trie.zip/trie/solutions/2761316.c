#include <stdio.h>
#include <stdlib.h>
#include <string.h>
FILE *f, *g;
typedef struct element{
    int endw, NrOfNodes; /// it's a frequency in the same time
    int poz[150];
    struct element *next[150];
}Trie;

Trie* CreateNod() {
    Trie* p = calloc(1, sizeof(Trie));
    p->endw = p->NrOfNodes = 0;
    for(int i = 90; i < 130; ++i) {
         p->next[i] = NULL;
         p->poz[i] = 0;
    }
    return p;
}

void AddTrie(Trie* root, char* cuv) {
    int lengh = strlen(cuv) - 1;
    Trie* last;
    for(int i = 0; cuv[i] != '\0'; ++i) {
        if(!root->poz[cuv[i]]) {
            root->poz[cuv[i]] = 1;
            root->next[cuv[i]] = CreateNod();
            ++(root->NrOfNodes);
        }
        last = root = root->next[cuv[i]];
    }
    ++(last->endw);
}

void DeleteTrie(Trie* root, char* cuv) {
    int lengh = strlen(cuv) - 1, m = -1;
    Trie* last, *queue[lengh + 2], *prev1, *prev2;
    char c1, c2;
    for(int i = 0; cuv[i] != '\0'; ++i) {
        if(!root->poz[cuv[i]])
            return;
        if(root->NrOfNodes == 1)
            queue[++m] = root;
        else
            m = -1, prev1 = root, c1 = cuv[i];
        prev2 = root, c2 = cuv[i];
        last = root = root->next[cuv[i]];
    }
    if(!last->NrOfNodes && last->endw == 1) {
        free(last);
        --(prev2->NrOfNodes);
        prev2->poz[c2] = 0;
        for(int i = 0; i <= m; ++i)
            free(queue[i]);
        if(m != -1) {
            prev1->poz[c1] = 0;
            --(prev1->NrOfNodes);
        }
        return;
    }
    --(root->endw);
}

int PrintFreg(Trie* root, char* cuv) {
    int lengh = strlen(cuv) - 1;
    Trie* last;
    for(int i = 0; cuv[i] != '\0'; ++i) {
        if(!root->poz[cuv[i]])
            return;
        last = root = root->next[cuv[i]];
    }
    return last->endw;
}

int PrintPref(Trie* root, char* cuv) {
    int lenght = strlen(cuv) - 1, lgt = 0, maxfreq;
    Trie* last;
    for(int i = 0; cuv[i] != '\0'; ++i) {
        if(!root->poz[cuv[i]])
            return maxfreq;
        ++maxfreq;
        last = root = root->next[cuv[i]];
    }
    return maxfreq;
}

int main() {
    f = fopen("trie.in", "r");
    g = fopen("trie.out", "w");
    char cuv[21];
    int operatie, k;
    Trie* root = CreateNod();
    while(fscanf(f,"%d %s", &operatie, &cuv) == 2) {
        switch(operatie) {
            case 0:
                AddTrie(root, cuv);
                break;
            case 1:
                DeleteTrie(root, cuv);
                break;
            case 2:
                k = PrintFreg(root, cuv);
                fprintf(g, "%d\n", k);
                break;
            case 3:
                k = PrintPref(root, cuv);
                fprintf(g, "%d\n", k);
                break;
        }
    }
    return 0;
}
