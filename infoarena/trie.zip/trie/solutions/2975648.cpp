#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
    int nr, rasp;
    trie *fii[27];
};

int op;
char s[27];
trie *t = new trie();

inline void add(trie *poz, char *s)
{
    poz->nr++;
    if(*s == '\0')
    {
        poz->rasp++;
        return;
    }
    int x = *s - 'a';
    if(poz->fii[x] == NULL)
    {
        poz->fii[x] = new trie();
    }
    add(poz->fii[x], s +  1);
}

inline void rem(trie *poz, char *s)
{
    poz->nr--;
    if(*s == '\0')
    {
        poz->rasp--;
        return;
    }
    int x = *s - 'a';
    rem(poz->fii[x], s + 1);
}

inline int first_search(trie *poz, char *s)
{
    if(*s == '\0')
        return poz->rasp;
    int x = *s - 'a';
    if(poz->fii[x] == NULL)
        return 0;
    return first_search(poz->fii[x], s + 1);
}

inline int second_search(trie *poz, char *s)
{
    int x = *s - 'a';
    if(*s == '\0' || poz->fii[x] == NULL || !poz->fii[x]->nr)
        return 0;
    return second_search(poz->fii[x], s + 1) + 1;
}

int main()
{
    while(fin >> op >> s)
    {
        if(op == 0)
        {
            add(t, s);
        }
        if(op == 1)
        {
            rem(t, s);
        }
        if(op == 2)
        {
            fout << first_search(t, s) << '\n';
        }
        if(op == 3)
        {
            fout << second_search(t, s) << '\n';
        }
        memset(s, 0, sizeof(s));
    }
}
