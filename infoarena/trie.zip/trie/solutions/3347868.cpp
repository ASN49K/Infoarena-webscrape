#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie_node{
    int frec, cnt;
    trie_node* copii[30];

    trie_node() {
        frec=cnt=0;
        for(int i=0;i<30;i++)
            copii[i]=nullptr;
    }
};
trie_node* rad=new trie_node;

void adauga(string s){
    trie_node* nod=rad;
    for(auto c: s){
        if(nod->copii[c-'a'] == nullptr){
            nod->copii[c-'a']=new trie_node;
        }
        nod=nod->copii[c-'a'];
        nod->cnt++;
    }
    nod->frec++;
}

void sterge(string s){
    trie_node* nod=rad;
    for(auto c: s){
        nod=nod->copii[c-'a'];
        nod->cnt--;
    }
    nod->frec--;
}

int getCount(string s){
    trie_node* nod=rad;
    for(auto c: s){
        nod=nod->copii[c-'a'];
    }

    return nod->frec;
}

int longestPref(string s){
    trie_node* nod=rad;
    int cnt=0;
    for(auto c: s){
        if(nod->copii[c-'a'] == nullptr){
            break;
        }
        if(nod->copii[c-'a']->cnt==0)
            break;
        nod=nod->copii[c-'a'];
        cnt++;
    }

    return cnt;
}

int main()
{
    int t;
    string s;
    while(fin>>t>>s){
        if(t==0){
            adauga(s);
        }
        if(t==1){
            sterge(s);
        }
        if(t==2){
            fout<<getCount(s)<<'\n';
        }
        if(t==3){
            fout<<longestPref(s)<<'\n';
        }
    }


    return 0;
}
