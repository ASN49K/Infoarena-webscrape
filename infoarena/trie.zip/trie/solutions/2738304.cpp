#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");

struct trie
{
    int word, nrFii;
    trie *next[27];

    trie()
    {
        word = 0;
        nrFii = 0;

        for(int i = 0; i < 27; i++)
            next[i] = nullptr;
    }
};

trie *T = new trie;

void ins(trie *node, char *s)
{
    if(*s == '\0')
    {
        node -> word++;
        return;
    }

    char x = *s - 'a';

    if(node -> next[x] == nullptr)
        node -> next[x] = new trie;

    node -> nrFii++;
    ins(node -> next[x], s + 1);
}

bool del(trie *node, char *s)
{
    if(*s == '\0')
    {
        node -> word--;

        if(node -> nrFii == 0 && node -> word == 0)
            return true;

        return false;
    }

    int x = *s - 'a';

    if(node -> next[x] == nullptr)
        return false;

    bool ok = del(node -> next[x], s + 1);

    node -> nrFii--;

    if(ok)
        node -> next[x] = nullptr;

    if(node -> nrFii == 0 && node -> word == 0 && ok)
        return true;

    return false;
}

int counter(trie *node, char *s)
{
    if(*s == '\0')
        return node -> word;

    int x = *s - 'a';

    if(node -> next[x] == nullptr)
        return 0;

    return counter(node -> next[x], s + 1);
}

int prefix(trie *node, char *s)
{
    if(*s == '\0')
        return 0;

    int x = *s - 'a';

    if(node -> next[x] == nullptr)
        return 0;

    return 1 + prefix(node -> next[x], s + 1);
}

int main()
{

    int operation;
    char s[21];

    while(in >> operation >> s)
    {
        switch(operation)
        {
        case 0:
            ins(T, s);
            break;

        case 1:
            del(T, s);
            break;

        case 2:
            out << counter(T, s) << '\n';
            break;

        case 3:
            out << prefix(T, s) << '\n';
            break;

        default:
            break;
        }
    }

    return 0;
}
