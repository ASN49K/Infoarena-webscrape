#include <bits/stdc++.h>
using namespace std;
ifstream f("trie.in");
ofstream g("trie.out");
string s;
int curr=0, l;
struct elem
{
    int sum, fv;
    int v[28];
};
vector <elem> a;
void add (int nod, int idx)
{
    a[nod].sum++;
    if (idx==l)
        a[nod].fv++;
    else
    {
        if (a[nod].v[s[idx]-'a']==0)
        {
            a[nod].v[s[idx]-'a']=++curr;
            a.push_back({0,0,0});
        }
        add (a[nod].v[s[idx]-'a'], idx+1);
    }
}
void del (int nod, int idx)
{
    a[nod].sum--;
    if (idx==l)
        a[nod].fv--;
    else
        del (a[nod].v[s[idx]-'a'], idx+1);

}
int ap (int nod, int idx)
{
    if (idx==l)
        return a[nod].fv;
    if (a[nod].v[s[idx]-'a']==0)
        return 0;
    return ap(a[nod].v[s[idx]-'a'], idx+1);
}
int pref (int nod, int idx)
{
    if (a[nod].sum==0)
        return max (idx-1, 0);
    if (idx==l)
        return l;
    if (!a[nod].v[s[idx]-'a'])
        return idx;
    return pref (a[nod].v[s[idx]-'a'], idx+1);
}
signed main ()
{
    a.push_back ({0, 0, 0});
    int op;
    while (f>>op)
    {
        f >> s;
        l=s.size();
        if (op==0)
            add (0, 0);
        if (op==1)
            del (0, 0);
        if (op==2)
            g << ap (0, 0) << '\n';
        if (op==3)
            g << pref (0, 0) << '\n';
    }
}
