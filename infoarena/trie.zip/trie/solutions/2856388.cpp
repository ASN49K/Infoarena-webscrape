#include <bits/stdc++.h>
#define NR (*s - 'a')

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie {
    int cnt, nrfii;
    trie *fiu[26];

    trie() {
        cnt = 0, nrfii = 0;
        memset(fiu, 0, sizeof(fiu));
    }
};

trie *t = new trie;

void ins(trie *nod, char *s) {
    if(*s == NULL) {
        nod->cnt++;
        return;
    }
    if(!nod->fiu[NR]) {
        nod->fiu[NR] = new trie;
        nod->nrfii++;
    }
    ins(nod->fiu[NR], s + 1);
}

int del(trie *nod, char *s) {
    if(*s == NULL)
        nod->cnt--;
    else if(del(nod->fiu[NR], s + 1)) {
        nod->fiu[NR] = 0;
        nod->nrfii--;
    }

    if(!nod->cnt && !nod->nrfii && nod != t) {
        delete nod;
        return 1;
    }
    return 0;
}

int query(trie *nod, char *s) {
    if(*s == NULL)
        return nod->cnt;
    if(nod->fiu[NR])
        return query(nod->fiu[NR], s + 1);
    else
        return 0;
}

int prefix(trie *nod, char *s, int k = 0) {
    if(*s == NULL || !nod->fiu[NR])
        return k;
    return prefix(nod->fiu[NR], s + 1, k + 1);
}

void solve() {
    int tip;
    char str[21];
    while(fin >> tip >> str) {
        if(!tip)
            ins(t, str);
        if(tip == 1)
            del(t, str);
        if(tip == 2)
            fout << query(t, str) << "\n";
        if(tip == 3)
            fout << prefix(t, str) << "\n";
    }
}

int main()
{
    solve();
    return 0;
}
