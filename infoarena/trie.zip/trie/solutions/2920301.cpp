#include <bits/stdc++.h>
#include <sys/time.h>
/// TONI BO$$ was here
/// #MLC

using namespace std;
struct Node
{
    int val = 0;
    int nrfii = 0;
    Node * _goto[26];
    Node ()
    {
        memset(_goto, 0, sizeof(_goto));
    }
};

Node * root = new Node;
string s;

void _insert(string &s)
{
    Node * curstate = root;
    for(auto it : s)
        if(curstate->_goto[it - 'a'] == 0)
            curstate->nrfii++, curstate = curstate->_goto[it - 'a'] = new Node;
        else
            curstate = curstate->_goto[it - 'a'];
    curstate->val++;
}

int _delete(int i, Node * curstate, string &s)
{
    if(i == s.size())
        curstate->val--;
    else
        if(_delete(i + 1, curstate->_goto[s[i] - 'a'], s))
            curstate->nrfii--, curstate->_goto[s[i] - 'a'] = 0;
    if(curstate->val == 0 && curstate->nrfii == 0 && curstate != root)
    {
        delete curstate;
        return 1;
    }
    return 0;
}

int _occurences(string &s)
{
    Node * curstate = root;
    int n = s.size();
    for(int i = 0; i < n && curstate != 0; i++)
        curstate = curstate->_goto[s[i] - 'a'];
    if(!curstate)
        return 0;
    return curstate->val;
}

int _prefix(string &s)
{
    Node * curstate = root;
    int i, lg = 0, n = s.size();
    for(i = 0; i < n; i++)
    {
        curstate = curstate->_goto[s[i] - 'a'];
        if(curstate == 0)
            break;
    }
    return i;
}

int main()
{
    int q;
    freopen("trie.in","r",stdin);
    freopen("trie.out","w",stdout);
    struct timeval start, stop;
    //gettimeofday(&start, NULL);
    while(cin >> q)
    {
        getline(cin, s);
        s = s.substr(1);
        //cout << s << endl;

        //if(s ==  "inahcylqworvygvxjc")
            //int fcsb = 1;
        switch(q)
        {
            case 0:  _insert(s); break;
            case 1:  _delete(0, root, s); break;
            case 2:  printf("%d\n", _occurences(s)); break;
            case 3:  printf("%d\n", _prefix(s)); break;
        }
        //s.clear();
    }
    //gettimeofday(&stop, NULL);
    //printf("%u sec: %u milsec\n", start.tv_sec, start.tv_usec);
    //printf("%u sec: %u milsec\n", stop.tv_sec, stop.tv_usec);

    return 0;
}
