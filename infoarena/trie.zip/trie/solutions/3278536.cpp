#include <iostream>
#include <fstream>
using namespace std;

struct trie {
    char litera;
    int nr_aparitii;
    trie* tr[26];
    trie() {
        for(int i = 0; i < 26; i++) {
            tr[i] = NULL;
        }
        nr_aparitii = 0;
    }
};

void adauga(trie *t, string s) {
    if(s.size() == 0) {
        (t -> nr_aparitii)++;
        return;
    }
    if(t -> litera == '&') {
        if(!(t -> tr[s[0] - 'a'])) {
            t -> tr[s[0] - 'a'] = new trie();
            t -> tr[s[0] - 'a'] -> litera = s[0];
        }
        adauga(t -> tr[s[0] - 'a'], s);
        return;
    }
    s = s.substr(1, s.size() - 1);
    (t -> nr_aparitii)++;
    if(s.size() == 0) {
        return;
    }
    if(!(t -> tr[s[0] - 'a'])) {
        t -> tr[s[0] - 'a'] = new trie();
        t -> tr[s[0] - 'a'] -> litera = s[0];
    }
    adauga(t -> tr[s[0] - 'a'], s);
}

void sterge(trie *t, string s) {
    if(s.size() == 0) {
        (t -> nr_aparitii)--;
        return;
    }
    if(t -> litera == '&') {
        sterge(t -> tr[s[0] - 'a'], s);
        return;
    }
    (t -> nr_aparitii)--;
    s = s.substr(1, s.size() - 1);
    if(s.size() == 0) {
        return;
    }
    sterge(t -> tr[s[0] - 'a'], s);
    if(t -> tr[s[0] - 'a'] -> nr_aparitii == 0) {
        t -> tr[s[0] - 'a'] = NULL;
    }
}

int nr_aparitii(trie* t, string s) {
    trie* t2 = t;
    for(auto c : s) {
        if(t2 -> tr[c - 'a'] == NULL) {
            return 0;
        }
        t2 = t2 -> tr[c - 'a'];
    }
    int nr = t2 -> nr_aparitii;
    for(int i = 0; i < 26; i++) {
        if(t2 -> tr[i] != NULL) {
            nr = nr - t2 -> tr[i] -> nr_aparitii;
        }
    }
    return nr;
}

int lp(trie* t, string s) {
    trie* t2 = t;
    int l = 0;
    for(auto c : s) {
        if(t2 -> tr[c - 'a'] == NULL) {
            return l;
        }
        l++;
        t2 = t2 -> tr[c - 'a'];
    }
    return l;
}

void print_trie(trie* t) {
    cout << t -> litera << " " << t -> nr_aparitii << endl;
    for(int i = 0; i < 26; i++) {
        if(t -> tr[i] != NULL) {
            print_trie(t -> tr[i]);
        }
    }
}

int main() {
    trie *t = new trie();
    t -> litera = '&';
    int op;
    string s;
    while(fin >> op >> s) {
        cout << op << " " << s << endl;
        if(op == 0) {
            adauga(t, s);
        } else if(op == 1) {
            sterge(t, s);
        } else if(op == 2) {
            fout << nr_aparitii(t, s) << "\n";
        } else if(op == 3) {
            fout << lp(t, s) << "\n";
        }
    }
    fin.close();
    fout.close();
}