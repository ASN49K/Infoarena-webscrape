#include <fstream>
#include <vector>
#include <stack>
#include <stack>
#include <queue>
#include <algorithm>
#include <map>
#include <deque>
#include <cstring>
#define Nmax 352
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

int op;
string sir;

struct trie{
    int howMany, NrOfWords;
    trie *son[28];

    trie(){
        howMany = NrOfWords = 0;
        fill(son, son + 27, nullptr);
    }
};

trie *T = new trie();

void Add(trie *T, string s, int k){
    if(k > s.length())
        return;

    int pos = s[k] - 'a' + 1;

    if(T -> son[pos] == NULL){
        T -> son[pos] = new trie();
    }
    T -> son[pos] -> howMany++;

    if(k == s.length() - 1)
        T -> son[pos] -> NrOfWords++;
  
    Add(T -> son[pos], s, k + 1);
}
void Del(trie *T, string s, int k){
     if(k > s.length())
        return;

    int pos = s[k] - 'a' + 1;

    if(T -> son[pos] == NULL)
        return;
    
    if(T -> son[pos] -> howMany)
        T -> son[pos] -> howMany--;
    
    if(k == s.length() - 1 &&  T -> son[pos] -> NrOfWords)
        T -> son[pos] -> NrOfWords--; 
    
    Del(T -> son[pos], s, k + 1);
}
int NrAp(trie *T, string s, int k){
    int pos = s[k] - 'a' + 1;

    if(T -> son[pos] == NULL)
        return 0;

    if(k == s.length() - 1)
        return T -> son[pos] -> NrOfWords;
    
    return NrAp(T -> son[pos], s, k + 1);
}
int MaxLength(trie *T, string s, int k){
    int pos = s[k] - 'a' + 1;

    if(T -> son[pos] == NULL) 
        return k;

    if(T -> son[pos] -> howMany == 0)
        return k;

    if(k == s.length() - 1 && T -> son[pos] -> howMany)
        return k;

    return MaxLength(T -> son[pos], s, k + 1);
}
int main() {
    while(fin >> op >> sir){
        if(op == 0)
            Add(T, sir, 0);
        else 
            if(op == 1)
                Del(T, sir, 0);
            else if(op == 2)fout << NrAp(T, sir, 0) << "\n";
            else fout << MaxLength(T, sir, 0) << "\n";
    }


    return 0;
}