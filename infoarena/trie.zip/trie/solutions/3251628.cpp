#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");
#define dim 27
struct trie
{
    int cnt=0,nr=0,fii[dim];
};
trie root;
vector<trie> v;
void update(int nod,int poz,int val,string s)
{
    v[nod].nr+=val;
    if(poz==s.length())
    {
        v[nod].cnt+=val;
        return ;
    }
    int car=s[poz]-'a';
    if(v[nod].fii[car]==0)
    {
        v[nod].fii[car]=v.size();
        v.push_back(root);///initializare
    }
    update(v[nod].fii[car],poz+1,val,s);
}
int query(int nod,int poz,string s)
{
    if(nod==0 && poz>0) ///nu suntem intr-un fiu valid
        return 0;
    if(poz==s.length())
        return v[nod].cnt;
    int car=s[poz]-'a';
    return query(v[nod].fii[car],poz+1,s);
}
int prefix(string s)
{
    int i,nod;
    nod=0;
    for(i=0;i<s.length() && v[nod].nr;i++)
    {
        nod=v[nod].fii[s[i]-'a'];
        if(nod==0)
            return i;
    }
    if(v[nod].nr==0)
        i--;
    return i;
}

int main()
{
    int c,i;
    string s;
    for(i=0;i<dim;i++)
        root.fii[i]=0;
    v.push_back(root);
    while(fin>>c>>s)
    {
        switch(c)
        {
            case 0:
                update(0,0,1,s);
                break;
            case 1:
                update(0,0,-1,s);
                break;
            case 2:
                fout<<query(0,0,s)<<'\n';
                break;
            case 3:
                fout<<prefix(s)<<'\n';
                break;
        }
    }
    return 0;
}
