#include <bits/stdc++.h>
using namespace std;

////fac recursiv!
ifstream fin("trie.in");
ofstream fout("trie.out");
struct Node{
    int ap , sf;
    Node *fii[26];
    Node(){
        ap = sf = 0;
        for(int i = 0 ; i < 26 ; ++ i)
            fii[i] = 0x0;
    }
};
Node const NMK;
class Trie{
public:
    Trie(){
        root = 0x0;
    }
    void add(char *p){
        root = add(root , p);
    }
    void rem(char *p){
        root = rem(root , p);
    }
    int query(char *p){
        return query(root , p);
    }
    int lp(char *p){
        return lp(root , p);
    }
private:
    Node *root;
    Node* add(Node *node , char *p){
        if(node == 0x0)
            node = new Node();
        ++ node->ap;
        if(p[0] == '\0')
            ++ node->sf;
        else
            node->fii[p[0] - 'a'] = add(node->fii[p[0] - 'a'] , p + 1);
        return node;
    }
    Node *rem(Node *node , char *p){
        if(node == 0x0)
            return node;
        -- node->ap;
        if(p[0] == '\0')
            -- node->sf;
        else
            node->fii[p[0] - 'a'] = rem(node->fii[p[0] - 'a'] , p + 1);
        if(node->ap == 0){
            delete node;
            node = 0x0;
        }
        return node;
    }
    int query(Node *node , char *p){
        if(node == 0x0)
            return 0;
        if(p[0] == '\0')
            return node->sf;
        return query(node->fii[p[0] - 'a'] , p + 1);
    }
    int lp(Node *node , char *p){
        if(node == 0x0 || p[0] == '\0')
            return 0;
        if(node->fii[p[0] - 'a'] == 0x0)
            return 0;
        return 1 + lp(node->fii[p[0] - 'a'] , p + 1);
    }
}t;
char s[21];
int main(){
    int op;
    while(fin >> op >> s){
        switch(op){
        case 0:
            t.add(s);
            break;
        case 1:
            t.rem(s);
            break;
        case 2:
            fout << t.query(s) << '\n';
            break;
        case 3:
            fout << t.lp(s) << '\n';
        }
    }

    return 0;
}
