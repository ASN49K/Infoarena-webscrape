#include <bits/stdc++.h>
using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct nod{
    nod *fiu[26];
    int nr_fii;
    int nr_ap;
    nod() {
        memset(fiu,0,sizeof(fiu));
        nr_fii = 0; nr_ap = 0;
    }
};

nod *root = new nod;
string w;
int op;
bool ok=0;
int max_pref;

void adds(nod *parent, int pos) {
    if (pos==w.size()) {
        parent->nr_ap++;
    }
    else {
        if (parent->fiu[w[pos]-'a']==0) {
            parent->nr_fii++;
            parent->fiu[w[pos]-'a'] = new nod;
        }
        adds(parent->fiu[w[pos]-'a'],pos+1);
    }
}

bool deletes(nod *parent, int pos) {
    if (pos==w.size()) {
        parent->nr_ap--;
    }
    else {
        if (deletes(parent->fiu[w[pos]-'a'],pos+1)) {
            parent->fiu[w[pos]-'a']=0;
            parent->nr_fii--;
        }
    }
    if (parent->nr_ap==0 && parent->nr_fii==0 && parent!=root) {
        delete parent;
        return 1;
    }
    return 0;
}

int appears(nod *parent, int pos) {
    if (pos==w.size()) return parent->nr_ap;
    else if (parent->fiu[w[pos]-'a']) {
        return appears(parent->fiu[w[pos]-'a'],pos+1);
    }
    return 0;
}

int common_prefix(nod *parent, int pos) {
    if (parent->fiu[w[pos]-'a']==0 || pos==w.size()) {
        return pos;
    }
    return common_prefix(parent->fiu[w[pos]-'a'],pos+1);
}

int main()
{
    while (f >> op) {
        f >> w;
        if (op==0) {
            adds(root,0);
        }
        else if (op==1) {
            ok=0; deletes(root,0);
        }
        else if (op==2) {
            g << appears(root,0) << '\n';
        }
        else {
            g << common_prefix(root,0) << '\n';
        }
    }
    return 0;
}
