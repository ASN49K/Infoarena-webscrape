#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");
char cuv[21];
struct Nod
{
    int cnt , nr;
    Nod * leg[26];
};

Nod * L;

void Insert(const char cuv[])
{
    int x;
    Nod *p , *q;
    p = L;
    for(int i = 0 ; cuv[i] ; i++)
    {
        x = cuv[i] - 'a';
        if(p -> leg[x] != 0)
        {
            p = p -> leg[x];
            p -> cnt++;
        }
        else
        {
            q = new Nod;
            q -> nr = 0;
            q -> cnt = 1;
            for(int j = 0 ; j < 26 ; j++)
                q -> leg[j] = 0;
            p -> leg[x] = q;
            p = q;
        }
    }
    p -> nr++;
}

void Delete(const char cuv[])
{
    int x;
    Nod *p;
    p = L;
    for(int i = 0 ; cuv[i] ; i++)
    {
        x = cuv[i] - 'a';
        p = p -> leg[x];
        p -> cnt--;
    }
    p -> nr--;
}

int FindCuvant(const char cuv[])
{
    int x;
    Nod *p;
    p = L;
    for(int i = 0 ; cuv[i] ; i++)
    {
        x = cuv[i] - 'a';
        if(p -> leg[x] == 0)
            return 0;
        p = p -> leg[x];
    }
    return (p -> nr);
}

inline int FindPrefix(const char cuv[])
{
    int x , ans = 0;
    Nod *p;
    p = L;
    for(int i = 0 ; cuv[i] ; i++)
    {
        x = cuv[i] - 'a';
        if(p -> leg[x] == 0 || p -> leg[x] -> cnt == 0)
            return ans;
        ans++;
        p = p -> leg[x];
    }
    return ans;
}

int main()
{
    int op;
    L = new Nod;
    L -> cnt = 0;
    L -> nr = 0;

    for(int i = 0 ; i < 26 ; i++)
        L -> leg[i] = 0;

    while(fin >> op >> cuv)
    {
        //cout << op << " " << cuv << "\n";
        if(op == 0)
            Insert(cuv);
        else if(op == 1)
            Delete(cuv);
        else if(op == 2)
            fout << FindCuvant(cuv) << "\n";
        else fout << FindPrefix(cuv) << "\n";
    }

    fin.close();
    fout.close();

    return 0;
}
