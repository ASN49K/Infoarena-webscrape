#include<iostream>
#include<fstream>
#include<string>
using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");
int op;
string ss;
struct node
{
    node *next[26];
    int ct_cuv;
    int ct_trace;
    node()
    {
        for(int it=0;it<26;it++)
        {
            next[it]=NULL;
        }
        ct_cuv=0;
        ct_trace=0;
    }
};
void add(string &s,int poz,node *curent)
{
    curent->ct_trace++;
    if(poz==s.size())
    {
        curent->ct_cuv++;
        return;
    }
    if(curent->next[s[poz]-'a']==NULL)
    {
        curent->next[s[poz]-'a']=new node();
    }
    add(s,poz+1,curent->next[s[poz]-'a']);
}
void del(string &s,int poz,node *curent)
{
    curent->ct_trace--;
    if(poz==s.size())
    {
        curent->ct_cuv--;
        return;
    }
    del(s,poz+1,curent->next[s[poz]-'a']);
}
void cnt(string &s,int poz,node *curent)
{
    if(poz==s.size())
    {
        out<<curent->ct_cuv<<"\n";
        return;
    }
    if(curent->next[s[poz]-'a']==NULL)
    {
        curent->next[s[poz]-'a']=new node();
    }
    cnt(s,poz+1,curent->next[s[poz]-'a']);
}
void tr(string &s,int poz,node *curent)
{
    if(curent->ct_trace==0)
    {
        if(poz==0)
        {
            out<<0<<"\n";
        }
        out<<poz-1<<"\n";
        return;
    }
    if(poz==s.size())
    {
        if(poz==0)
        {
            out<<0<<"\n";
        }
        out<<poz-1<<"\n";
        return;
    }
    if(curent->next[s[poz]-'a']==NULL)
    {
        curent->next[s[poz]-'a']=new node();
    }
    tr(s,poz+1,curent->next[s[poz]-'a']);
}
int main()
{
    node *adresa=new node();
    while(in>>op>>ss)
    {
        if(op==0)
        {
            add(ss,0,adresa);
        }
        else if(op==1)
        {
            del(ss,0,adresa);
        }
        else if(op==2)
        {
            cnt(ss,0,adresa);
        }
        else if(op==3)
        {
            tr(ss,0,adresa);
        }
    }
}
