#include <bits/stdc++.h>
#define N 1005
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
struct Trie
{
    int cnt,nrfii;
    Trie *fiu[26];
    Trie()
    {
        cnt=nrfii=0;
        memset(fiu,0,sizeof(fiu));
    }
};
Trie *T=new Trie;
void Adaugare(Trie *nod,char *s)
{
    if(*s==NULL) {nod->cnt++;return;}
    if(!nod->fiu[*s-'a'])
    {
        nod->fiu[*s-'a']=new Trie;
        nod->nrfii++;
    }
    Adaugare(nod->fiu[*s-'a'],s+1);
}
bool Stergere(Trie *nod,char *s)
{
    if(*s==NULL) nod->cnt--;
    else if(Stergere(nod->fiu[*s-'a'],s+1))
        nod->fiu[*s-'a']=0,nod->nrfii--;
    if(!nod->cnt&&!nod->nrfii&&nod!=T)
    {
        delete nod;
        return 1;
    }
    return 0;
}
int NrAp(Trie *nod,char *s)
{
    if(*s==NULL) return nod->cnt;
    return NrAp(nod->fiu[*s-'a'],s+1);
   // return 0;
}
int Prefix(Trie *nod,char *s,int nivel)
{
    if(*s==NULL||!nod->fiu[*s-'a']) return nivel;
    return  Prefix(nod->fiu[*s-'a'],s+1,nivel+1);
}
int main()
{
    int op;char s[N];
    while(fin>>op>>s)
    {
        if(!op) Adaugare(T,s);
        else if(op==1) Stergere(T,s);
        else if(op==2) fout<<NrAp(T,s)<<"\n";
        else fout<<Prefix(T,s,0)<<"\n";
    }
    return 0;
}
