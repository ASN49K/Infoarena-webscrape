#include <bits/stdc++.h>
using namespace std;

class Nod
{
public:
    int fr,cuv;
    Nod *leg[26];
    Nod(){
        fr=0;
        cuv=1;
        for(int i=0;i<=25;i++)
            leg[i] = NULL;
    }
    Nod(int frq){
        fr=frq;
        cuv=1;
        for(int i=0;i<=25;i++)
            leg[i] = NULL;
    }
    Nod(int frq,int nr){
        fr=frq;
        cuv=nr;
        for(int i=0;i<=25;i++)
            leg[i] = NULL;
    }
};

class Trie
{
private:
    int tot;
public:
    Nod *rad;
    Trie(){
        rad=new Nod(0,0);
        tot=0;
    }
    Trie(string s){
        Add(s);
    }
    virtual void Add(string s){
        tot++;
        int x;
        Nod *p = rad,*q;
        for(unsigned int i=0;i<s.size();i++){
            x=s[i]-'a';
            if(p->leg[x]!=NULL){
                p=p->leg[x];
                p->cuv++;
            }
            else{
                q=new Nod();
                p->leg[x]=q;
                p=q;
            }
        }
        p->fr++;
    }
    virtual void Delete(string s){
        tot--;
        int x;
        Nod*p = rad;
        for(unsigned int i=0;i<s.size();i++){
            x=s[i]-'a';
            p=p->leg[x];
            p->cuv--;
        }
        p->fr--;
    }
    virtual int Freq(string s){
        int x;
        Nod*p = rad;
        for(unsigned int i=0;i<s.size();i++){
            x=s[i]-'a';
            if(p->leg[x]==NULL) return 0;
            p=p->leg[x];
        }
        return p->fr;
    }
};

class IATrie : public Trie
{
public:
    IATrie() : Trie(){};
    IATrie(string _s) : Trie(_s){};
    int Comun(string s){
        int x,ml=0;
        Nod*p = rad;
        for(unsigned int i=0;i<s.size();i++){
            x=s[i]-'a';
            if(p->leg[x]==NULL) return ml;
            p=p->leg[x];
            if(p->cuv==0) return ml;
            ml++;
        }
        return ml;
    }
};

ifstream fin("trie.in");
ofstream fout("trie.out");

int main()
{
    string s;
    int c;
    IATrie rad;
    while(fin >> c >> s){
        if(c==0) rad.Add(s);
        else if(c==1) rad.Delete(s);
        else if(c==2) fout << rad.Freq(s)<< "\n";
        else fout << rad.Comun(s) << "\n";
    }
    return 0;
}
