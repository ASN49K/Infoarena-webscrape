#include <bits/stdc++.h>

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");

struct nod
{
    unsigned short cuv = 0;
    unsigned short pref = 0;
    nod* fiu[26];
    nod()
    {
        for (int i = 0 ; i < 26; i++)
            fiu[i] = NULL;
    }
};

nod* root = new nod;

void ins(string s)
{
    nod* act = root;
    for (int i = 0; i < s.size(); i++)
    {
        act -> pref++;
        if (act -> fiu[s[i] - 'a'] == NULL)
            act -> fiu[s[i] - 'a'] = new nod;
        act = act -> fiu[s[i] - 'a'];
    }
    act -> pref++;
    act -> cuv++;
}

void er(string s)
{
    nod* act = root;
    for (int i = 0; i < s.size(); i++)
    {
        act -> pref--;
        act = act -> fiu[s[i] - 'a'];
    }
    act -> pref--;
    act -> cuv--;
}

int ap(string s)
{
    nod* act = root;
    for (int i = 0; i < s.size(); i++)
        act = act -> fiu[s[i] - 'a'];
    return act -> cuv;
}

int pref_max(string s)
{
    int nr = 0;
    nod* act = root;
    for (int i = 0; i < s.size(); i++)
    {
        if (act -> fiu[s[i] - 'a'] == NULL)
            break;
        act = act -> fiu[s[i] - 'a'];
        if (act -> pref == 0)
            break;
        nr++;
    }
    return nr;
}

int main()
{
    int tip;
    string s;
    while (in >> tip >> s)
    {
        if (tip == 0)
            ins(s);
        if (tip == 1)
            er(s);
        if (tip == 2)
            out << ap(s) << '\n';
        if (tip == 3)
            out << pref_max(s) << '\n';
    }
    return 0;
}
