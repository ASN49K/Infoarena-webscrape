#include <bits/stdc++.h>

using namespace std;

struct node {
    node *f[26];
    int cnt, in_cuv;
    node() {
        cnt = 0;
        in_cuv = 0;
        for(char i = 'a'; i <= 'z'; i ++) {
            f[i - 'a'] = NULL;
        }
    }
};

void update(node *root, string &s, int add) {
    node *curr = root;
    for(auto it : s) {
        if(curr->f[it - 'a'] == NULL) {
            curr->f[it - 'a'] = new node;
        }
        curr = curr->f[it - 'a'];
        curr->in_cuv += add;
    }
    curr->cnt += add;
}

int nr(node *root, string &s) {
    node *curr = root;
    for(auto it : s) {
        if(curr->f[it - 'a'] == NULL) {
            return 0;
        }
        curr = curr->f[it - 'a'];
    }
    return curr->cnt;
}

int max_pref(node *root, string &s) {
    node *curr = root;
    int i = 0, ans = 0;
    for(auto it : s) {
        if(curr->f[it - 'a'] == NULL) {
            return ans;
        }
        i ++;
        curr = curr->f[it - 'a'];
        if(curr->in_cuv > 0) {
            ans = i;
        }
    }
    return ans;
}

int main() {
    ifstream cin("trie.in");
    ofstream cout("trie.out");
    node *root = new node;
    int cer;
    string s;
    while(cin >> cer >> s) {
        if(cer == 0) {
            update(root, s, 1);
        } else if(cer == 1) {
            update(root, s, -1);
        } else if(cer == 2) {
            cout << nr(root, s) << '\n';
        } else {
            cout << max_pref(root, s) << '\n';
        }
    }
    return 0;
}
