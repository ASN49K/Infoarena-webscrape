#include <bits/stdc++.h>

using namespace std;

ifstream f ("trie.in");
ofstream g ("trie.out");

struct nod
{
    char val;
    nod *adr[30];
    int ajuns;
    int termin;
};
nod *vf;

void init(nod *&vf)
{
    vf=new nod;
    vf->val='$';
    vf->ajuns=0;
    vf->termin=0;
    for(int i=1; i<='z'-'a'; ++i)
        vf->adr[i]=0;
}


void adauga(nod *&p, char cuvant[30], int ind)
{


    if(ind==strlen(cuvant))
    {
        p->termin++ ;
        return;
    }

    if(p->adr[cuvant[ind]-'a'+1]!=NULL)
    {

        p=p->adr[cuvant[ind]-'a'+1];
        p->ajuns+=1;
        adauga(p, cuvant, ind+1);
    }
    else
    {

        nod *aux;
        aux=new nod;
        p->adr[cuvant[ind]-'a'+1]=aux;
        p=aux;
        p->ajuns++;
        p->val=cuvant[ind];
        for(int i=1; i<='z'-'a'; ++i)
            p->adr[i]=0;
        adauga(p, cuvant, ind+1);
    }
}
void scoate(nod *&p, char cuvant[30], int ind)
{

    if(ind==strlen(cuvant) && p!=vf)
    {
        p->termin--;
        return;
    }

    if(p->adr[cuvant[ind]-'a'+1]->ajuns!=0)
    {

        if(p->ajuns==0 && p!=vf)
        {
            nod *aux=p;
            p=p->adr[cuvant[ind]-'a'+1];
            delete aux;
            p->ajuns--;


        }
        else
        {
            p=p->adr[cuvant[ind]-'a'+1];
            p->ajuns--;
        }


        scoate(p, cuvant, ind+1);
    }
    else return;

}

int gasire(nod *&p, char cuvant[50], int ind)
{
 ///cout<<cuvant<<" "<<cuvant[ind]<<" "<<p->val<<" "<<p->ajuns<<"\n";
    if(ind==strlen(cuvant))
        return p->termin;
    if(p->adr[cuvant[ind]-'a'+1]!=0 && p->adr[cuvant[ind]-'a'+1]->ajuns>0)
    {
        p=p->adr[cuvant[ind]-'a'+1];
        gasire(p, cuvant, ind+1);
    }
    else
    {
        return 0;
    }
}
int prefix(nod *&p, char cuvant[50], int ind)
{

    if(ind==strlen(cuvant))
        return strlen(cuvant);
    if(p->adr[cuvant[ind]-'a'+1]!=0 && p->adr[cuvant[ind]-'a'+1]->ajuns>0)
    {
        p=p->adr[cuvant[ind]-'a'+1];
        prefix(p, cuvant, ind+1);
    }
    else
    {
        return ind;
    }
}


int main()
{


    init(vf);
    int tip;
    char cuvant[50];
    while(f>>tip>>cuvant)
    {
        nod *p=vf;
        if(tip==0)
            adauga(p, cuvant, 0);

        if(tip==1)
            scoate(p, cuvant, 0);

        if(tip==2)
            g<<gasire(p, cuvant, 0)<<"\n";

        if(tip==3)
            g<<prefix(p, cuvant, 0)<<"\n";

    }



    return 0;
}
