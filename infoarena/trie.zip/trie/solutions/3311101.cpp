#include <fstream>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
int task,p,k;
char s[21];
struct nod{
    int fr[27],cuv,pref;
}t[300001];
void add(int nod){
    t[nod].pref++;
    if(s[p]==0){
        t[nod].cuv++;
        return ;
    }
    if(t[nod].fr[s[p]-'a']==0)
        t[nod].fr[s[p]-'a']=++k;
    add(t[nod].fr[s[p++]-'a']);
}
void cut(int nod){
    t[nod].pref--;
    if(s[p]==0){
        t[nod].cuv--;
        return ;
    }
    cut(t[nod].fr[s[p++]-'a']);
}
int ap(int nod){
    if(s[p]==0)
        return t[nod].cuv;
    if(t[nod].fr[s[p]-'a']==0)
        return 0;
    return ap(t[nod].fr[s[p++]-'a']);
}
int lg(int nod){
    if(s[p]==0)
        return p;
    if(t[nod].pref==0)
        return p-1;
    if(t[nod].fr[s[p]-'a']==0)
        return p;
    return lg(t[nod].fr[s[p++]-'a']);
}
int main()
{
    while(cin>>task>>s){
        p=0;
        if(task==0)
            add(0);
        else if(task==1)
            cut(0);
        else if(task==2)
            cout<<ap(0)<<'\n';
        else
            cout<<lg(0)<<'\n';
    }
    return 0;
}
