#include <fstream>
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
int task,k,i,lg;
string s;
struct nod{
    int fr[27],cuv,prefix;
}t[300001];
void add(int nod){
    t[nod].prefix++;
    if(s[i]==0){
        t[nod].cuv++;
        return ;
    }
    if(t[nod].fr[s[i]-'a']==0)
        t[nod].fr[s[i]-'a']=++k;
    add(t[nod].fr[s[i++]-'a']);
}
void cut(int nod){
    t[nod].prefix--;
    if(s[i]==0){
        t[nod].cuv--;
        return ;
    }
    cut(t[nod].fr[s[i++]-'a']);
}
int get_number(int nod){
    if(s[i]==0)
        return t[nod].cuv;
    if(t[nod].fr[s[i]-'a']!=0)
        return get_number(t[nod].fr[s[i++]-'a']);
    return 0;
}
void lg_prefix(int nod,int l){
    if(t[nod].prefix<=0)
        return;
    lg=l;
    if(s[i]==0)
        return ;
    if(t[nod].fr[s[i]-'a']!=0)
        lg_prefix(t[nod].fr[s[i++]-'a'],l+1);
}
int main()
{
    while(cin>>task>>s){
        i=0;
        if(task==0)
            add(0);
        else if(task==1)
            cut(0);
        else if(task==2)
            cout<<get_number(0)<<'\n';
        else{
            lg=0;
            lg_prefix(0,0);
            cout<<lg<<'\n';
        }
    }
    return 0;
}
