#include <fstream>
#include <algorithm>
#include <map>
#include <vector>


using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");

struct per
{
    vector <int> dest,frecv;
    vector <char> lit;

}v[200050];
int x;
int n;
int cnt;
string cuv;
int rez;
int num;


int adau()
{
    int poz=0;

    for(int i=0;i<cuv.length();i++)
    {
        bool f=0;
        for(int k=0;k<v[poz].dest.size();k++)
        {
            if(v[poz].lit[k]==cuv[i])
            {
                v[poz].frecv[k]++;
                poz=v[poz].dest[k];
                f=1;
                break;
            }

        }
        if(f==0)
        {

            cnt++;
            v[poz].dest.push_back(cnt);
            v[poz].frecv.push_back(1);
            v[poz].lit.push_back(cuv[i]);
            poz=cnt;

        }



    }


    return 0;
}
int sterg()
{
    int poz=0;
    for(int i=0;i<cuv.length();i++)
    {
        for(int k=0;k<v[poz].dest.size();k++)
        {
            if(cuv[i]==v[poz].lit[k])
            {
                v[poz].frecv[k]--;
                poz=v[poz].dest[k];
                break;
            }
        }
    }
    return 0;

}



int fre()
{
     int poz=0;
    for(int i=0;i<cuv.length();i++)
    {
        bool f=0;
        for(int k=0;k<v[poz].dest.size();k++)
        {

            if(cuv[i]==v[poz].lit[k])
            {
                f=1;
                //v[i].frecv[k]--;
                rez=v[poz].frecv[k];
                if(rez==0)
                {
                  //  cout<<"bloc"<< cuv[i]<< " "<<poz<<"   " ;
                    return 0;
                }
                poz=v[poz].dest[k];
                break;
            }
        }
        if(f==0)
        {
            rez=0;
            return 0;
        }
    }


    int sum=0;
    for(int i=0;i<v[poz].dest.size();i++)
    {
        sum+=v[poz].frecv[i];
    }

    rez-=sum;


    return 0;
}



int calc()
{
    int poz=0;
    int r=0;
    while(1)
    {
        bool f=0;
       for(int i=0;i<v[poz].dest.size();i++)
        {
            if(v[poz].frecv[i]>0 && cuv[r]==v[poz].lit[i])
            {

           // cout<<poz<<" "<<v[poz].dest[i]<<" "<<v[poz].frecv[i]<<" "<<v[poz].lit[i]<<'\n';

                poz=v[poz].dest[i];
                f=1;
                r++;
                break;
            }
        }
        if(f==0)
        {
            break;
        }
    }
    cout<<r<<'\n';
    return 0;

}



int main()
{

  while(cin>>x)
  {
      cin>>cuv;

      if(x==0)
      {
          num++;
          adau();
      }
      if(x==1)
      {
          num--;
          sterg();
      }
      if(x==2)
      {
          fre();
          cout<<rez<<'\n';
      }
      if(x==3)
      {
          calc();
      }




  }


    return 0;
}






//manuscrisul voinici
