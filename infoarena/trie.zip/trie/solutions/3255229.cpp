#include <iostream>
#include <fstream>

using namespace std;

struct TrieNode
{
    TrieNode* alphabet[26]={};
    int cnt=0, children=0;
};

TrieNode *head=new TrieNode;

void insert(TrieNode *currNode, const string& word, int index)
{
    if (index==word.length())
    {
        ++currNode->cnt;
        return;
    }
    ++currNode->children;
    if (currNode->alphabet[word[index]-'a']==nullptr)
        currNode->alphabet[word[index]-'a']=new TrieNode;
    insert(currNode->alphabet[word[index]-'a'], word, index+1);
}

bool remove(TrieNode *currNode, const string& word, int index)
{
    if (index==word.length())
    {
        --currNode->cnt;
        if (currNode->children==0)
        {
            delete currNode;
            return true;
        }
        return false;
    }
    --currNode->children;
    if (remove(currNode->alphabet[word[index]-'a'], word, index+1))
        currNode->alphabet[word[index]-'a']=nullptr;
    if (currNode->children==0 && currNode!=head)
    {
        delete currNode;
        return true;
    }
    return false;
}

int frequency(TrieNode *currNode, const string& word, int index)
{
    if (index==word.length())
        return currNode->cnt;
    if (currNode->alphabet[word[index]-'a']==nullptr)
        return 0;
    return frequency(currNode->alphabet[word[index]-'a'], word, index+1);
}

int longestPrefix(TrieNode *currNode, const string& word, int index)
{
    if (index==word.length())
    {
        if (currNode->cnt>=2 || currNode->children>=1)
            return index;
        return index-1;
    }
    if (currNode->alphabet[word[index]-'a']==nullptr)
        return index;
    if (currNode->children>=2)
        return longestPrefix(currNode->alphabet[word[index]-'a'], word, index+1);
    return index+1;
}

int main()
{
    ifstream fin("trie.in");
    ofstream fout("trie.out");
    int op;
    string word;
    while (fin>>op>>word)
    {
        if (op==0)
        {
            insert(head, word, 0);
        }
        else if (op==1)
        {
            remove(head, word, 0);
        }
        else if (op==2)
        {
            fout<<frequency(head, word, 0)<<'\n';
        }
        else
        {
            fout<<longestPrefix(head, word, 0)<<'\n';
        }
    }


    return 0;
}
