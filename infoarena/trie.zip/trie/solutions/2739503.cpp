#include <fstream>
using namespace std;
ifstream cin ("trie.in");
ofstream cout ("trie.out");
struct trie
{
    int cnt;
    trie* adj[26];
};
void add (trie* nod, char* s)
{
    if(s[0]==NULL)
    {
        ++nod->cnt;
        return;
    }
    if(nod->adj[s[0]-'a']==NULL)
        nod->adj[s[0]-'a']=new trie();
    add(nod->adj[s[0]-'a'],s+1);
}
void remove (trie* nod, char* s)
{
    if(s[0]==NULL)
    {
        --nod->cnt;
        return;
    }
    remove(nod->adj[s[0]-'a'],s+1);
}
int find (trie* nod, char* s)
{
    if(s[0]==NULL)
        return nod->cnt;
    if(nod->adj[s[0]-'a']==NULL)
        return 0;
    return find(nod->adj[s[0]-'a'],s+1);
}
int maxpref (trie* nod, char* s)
{
    if(s[0]==NULL)
        return 0;
    if(nod->adj[s[0]-'a']==NULL)
        return 0;
    return 1+maxpref(nod->adj[s[0]-'a'],s+1);
}
char v[30];
int main()
{
    int a;
    trie* myTrie=new trie();
    while(cin>>a)
    {
        cin>>v;
        if(a==0)
            add(myTrie,v);
        if(a==1)
            remove(myTrie,v);
        if(a==2)
            cout<<find(myTrie,v)<<'\n';
        if(a==3)
            cout<<maxpref(myTrie,v)<<'\n';
    }
	return 0;
}

