#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct Node {
	int nr_cuv = 0;
	int nr_ap = 0;
	vector<Node*> fii;

	Node() : fii(26) {}
};

Node* insert(Node* node, const char* s) {
	if (node == nullptr) { node = new Node; }
	
	node->nr_ap++;

	if (s[0] == '\0') {
		node->nr_cuv++;
	} else {
		node->fii[s[0] - 'a'] = insert(node->fii[s[0] - 'a'], s + 1);
	}

	return node;
}

Node* erase(Node* node, const char* s) {
	if (node == nullptr) { return node; }

	if (s[0] == '\0') {
		node->nr_cuv--;
	} else {
		node->fii[s[0] - 'a'] = erase(node->fii[s[0] - 'a'], s + 1);
	}

	node->nr_ap--;
	if (node->nr_ap == 0) {
		delete node;
		node = nullptr;
	}

	return node;
}

int query_word(Node* node, const char* s) {
	if (node == nullptr) { return 0; }

	if (s[0] == '\0') {
		return node->nr_cuv;
	} else {
		return query_word(node->fii[s[0] - 'a'], s + 1);
	}
}

int query_prefix(Node* node, const char* s) {
	if (node == nullptr || s[0] == '\0') { return 0; }

	if (node->fii[s[0] - 'a'] == nullptr) {
		return 0;
	} else {
		return 1 + query_prefix(node->fii[s[0] - 'a'], s + 1);
	}
}

int main() {
	ifstream in("trie.in");
	ofstream out("trie.out");

	Node* trie = nullptr;

	int op;
	while (in >> op) {
		string s; in >> s;

		if (op == 0) {
			trie = insert(trie, s.c_str());
		} else if (op == 1) {
			trie = erase(trie, s.c_str());
		} else if (op == 2) {
			out << query_word(trie, s.c_str()) << "\n";
		} else {
			out << query_prefix(trie, s.c_str()) << "\n";
		}
	}

	return 0;
}