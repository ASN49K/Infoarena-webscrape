#include<bits/stdc++.h>
//#define inf 0x3f3f3f3f
#define int long long
#define bit(x,i)(((x)>>(i))&1)
#define FAST ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
ifstream f("trie.in");
ofstream g("trie.out");
const int mod=666013;
//typedef long long ll;
//const long long int mare=1LL*1000000000000000000;
const int mare=1e9+5;
const int nmax=1e5+5;
const int dx[] = { -1,0,1, };
const int dy[] = { 0,1,0 };
int T,C,n,k,y,q,d,p,maxx,maxy,ok,i,j,nr,l,m,a,b;
int s,minn,ans;
char sir[25];
struct trie
{
    int cnt, nrfii, here;
    trie *f[30];
    trie()
    {
        cnt = nrfii = here = 0;
        memset(f, 0, sizeof(f));
    }
};
trie *rad = new trie;
trie *t;
signed main() {
    while(f>>T)
    {
        f>>sir;
        n=strlen(sir);
        ok=0;
        if(T==0)
        {
            t = rad;
            for (int i = 0; i < n; ++i)
            {
                int q = sir[i]-'a';
                if(t->f[q] == NULL)
                {
                    ++t->nrfii;
                    t->f[q] = new trie;
                    ++t->f[q]->cnt;
                }
                else
                    ++t->f[q]->cnt;
                t = t->f[q];
            }
            ++t->here;
        }
        if(T==1)
        {
            t = rad;
            ok = false;
            for (int i = 0; i < n; ++i)
            {
                int q = sir[i]-'a';
                if(t->f[q]->cnt == 1)
                {
                    delete t->f[q];
                    t->f[q] = NULL;
                    --t->nrfii;
                    ok = true;
                    break;
                }
                --t->f[q]->cnt;
                t = t->f[q];
            }
            if(!ok)
                --t->here;
        }
        if(T==2)
        {
            t = rad;
            ok=0;
            for (int i = 0; i < n; ++i)
            {
                int q = sir[i]-'a';
                if(!t->f[q])
                {
                    ok=1;
                    break;
                }
                t = t->f[q];
            }
            if(ok)
                g<<0<<'\n';
            else
                g<<t->here<<'\n';
        }
        if(T==3)
        {
            t = rad;
            ok =0;
            for (int i = 0; i < n; ++i)
            {
                int q = sir[i]-'a';
                if(!t->f[q])
                {
                    ok=1;
                    g<<i<<'\n';
                    break;
                }
                t = t->f[q];
            }
            if(!ok)
                g<<n<<'\n';
        }
    }
    return 0;
}

/*

4 3
4 3 0
9 2 6
1 4 9
2 6 7

 64
2 3

 *
 */