#include <bits/stdc++.h>
using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");


struct nod {
    nod *fiu[26];
    int sons;
    int w_nr;
    nod() {
        memset(fiu,0,sizeof(fiu));
        w_nr = 0;
        sons = 0;
    }
};

nod *root = new nod;
string w;
int op;

void add(nod *parent, int pos) {
    if (pos==w.size()) {
        parent->w_nr++;
    }
    else {
        if (parent->fiu[w[pos]-'a']==0) {
            parent->sons++;
            parent->fiu[w[pos]-'a'] = new nod;
        }
        add(parent->fiu[w[pos]-'a'],pos+1);
    }
}

bool deletion(nod *parent, int pos) {
    if (pos==w.size()) {
        parent->w_nr--;
    }
    else {
        if (deletion(parent->fiu[w[pos]-'a'],pos+1)==1) {
            parent->fiu[w[pos]-'a'] = 0;
            parent->sons--;
        }
    }
    if (parent->w_nr==0 && parent->sons==0 && parent!=root) {
        delete parent;
        return 1;
    }
    return 0;
}


int appears(nod *parent, int pos) {
    if (pos==w.size()) {
        return parent->w_nr;
    }
    else {
        if (parent->fiu[w[pos]-'a']==0) {
            return 0;
        }
        else {
            return appears(parent->fiu[w[pos]-'a'],pos+1);
        }
    }
}

int longest_prefix(nod *parent, int pos) {
    if (parent->fiu[w[pos]-'a']==0 || pos==w.size()) {
        return pos;
    }
    else {
        return longest_prefix(parent->fiu[w[pos]-'a'], pos+1);
    }
}

int main()
{
    while (f >> op) {
        f >> w;
        if (op==0) {
            add(root,0);
        }
        else if (op==1) {
            deletion(root,0);
        }
        else if (op==2) {
            g << appears(root,0) << '\n';
        }
        else {
            g << longest_prefix(root,0) << '\n';
        }
    }
    return 0;
}
