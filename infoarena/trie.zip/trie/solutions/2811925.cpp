#include <fstream>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
struct trie
{
    trie* v[26];
    int k;
    int nr;
    trie()
    {
        for (int i = 0; i <= 25; i++)
            v[i] = nullptr;
        k = 0;
        nr = 0;
    }
};

int p;
string s;
trie* x = new trie;
void adaug(trie* r, const char* s)
{
    if (s[0] == '\0')
    {
        r->k++;
        return;
    }
    if (r->v[s[0] - 'a'] == nullptr)
    {
        r->v[s[0] - 'a'] = new trie;
        r->nr++;
    }

    adaug(r->v[s[0] - 'a'], s + 1);
}
void stergere(trie* &r, const char* s)
{
    if (s[0] == '\0')
    {
        r->k--;
        if (r!=x && r->k == 0 && r->nr == 0)
        {
            delete r;
            r = nullptr;
        }
        return;
    }
    stergere(r->v[s[0] - 'a'], s + 1);
    if (r->v[s[0] - 'a'] == nullptr)
        r->nr--;
    if (r != x && r->k == 0 && r->nr == 0)
    {
        delete r;
        r = nullptr;
    }
}
int afisare(trie* r, const char* s)
{
    if (s[0] == '\0')
    {
        return r->k;
    }
    if (r->v[s[0] - 'a'] == nullptr)
        return 0;
    return afisare(r->v[s[0] - 'a'], s + 1);
}
int prefix(trie* r, const char* s)
{
    if (s[0] == '\0' || r->v[s[0] - 'a'] == nullptr)
    {
        return 0;
    }
    return 1 + prefix(r->v[s[0] - 'a'], s + 1);
}
int main()
{
    ios_base::sync_with_stdio(false);
    while (cin >> p >> s)
    {
        if (p == 0)
        {
            adaug(x,s.c_str());
        }
        else if (p == 1)
        {
            stergere(x, s.c_str());
        }
        else if (p == 2)
        {
            cout<<afisare(x, s.c_str())<<'\n';
        }
        else if (p == 3)
        {
            cout << prefix(x, s.c_str()) << '\n';
        }
    }

    return 0;
}