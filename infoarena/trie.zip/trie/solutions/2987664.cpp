#include <iostream>
#include <fstream>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

const int LETTERS_IN_ALPHABET = 26;

struct TrieNode
{
    int cnt = 0, endOfWord = 0;
    TrieNode *children[LETTERS_IN_ALPHABET] = { NULL };
};

void Push(TrieNode *&root, string word)
{
    TrieNode *curr = root;
    int len = word.length();

    for (int i = 0; i < len; i++)
    {
        int index = word[i] - 'a';
        if (curr -> children[index] == NULL)
        {
            curr -> children[index] = new TrieNode;
        }
        curr = curr -> children[index];
        curr -> cnt++;
    }

    curr -> endOfWord++;
}

void Pop(TrieNode *&root, string word)
{
    TrieNode *curr = root;
    int len = word.length();

    for (int i = 0; i < len; i++)
    {
        int index = word[i] - 'a';
        if (curr -> children[index] == NULL)
        {
            return;
        }
        curr = curr -> children[index];
        curr -> cnt--;
    }

    if (curr -> endOfWord > 0)
    {
        curr -> endOfWord--;
    }
}

int Frequency(TrieNode *root, string word)
{
    TrieNode *curr = root;
    int len = word.length();

    for (int i = 0; i < len; i++)
    {
        int index = word[i] - 'a';
        if (curr -> children[index] == NULL)
        {
            return 0;
        }
        curr = curr -> children[index];
    }

    return curr -> endOfWord;
}

int LongestPrefix(TrieNode *root, string word)
{
    TrieNode *curr = root;
    int len = word.length();
    int temp = 0, maximum = 0;

    for (int i = 0; i < len; i++)
    {
        int index = word[i] - 'a';
        if (curr -> children[index] == NULL)
        {
            return maximum;
        }
        curr = curr -> children[index];
        temp++;
        if (curr -> cnt > 0)
        {
            maximum = temp;
        }
    }

    return maximum;
}

int main()
{
    TrieNode *root = new TrieNode;
    int query;  string s;
    while(f >> query >> s) {
        if(query == 0) {
            Push(root, s);
        } else if(query == 1) {
            Pop(root, s);
        } else if(query == 2) {
            g << Frequency(root, s) << '\n';
        } else {
            g << LongestPrefix(root, s) << '\n';
        }
    }
    return 0;
}
