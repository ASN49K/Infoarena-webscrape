/*
  ____   ___  _     ___ ____    _
 / ___| / _ \| |   |_ _/ ___|  / \
 \___ \| | | | |    | | |     / _ \
  ___) | |_| | |___ | | |___ / ___ \
 |____/ \___/|_____|___\____/_/   \_\

*/
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long int
#define pii pair<int,int>

const int NMAX = 2e5+9;

const int MOD = 1e9+7;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

#define cin fin
#define cout fout

int binpow(int n, int k)
{
    if (k==0)
    {
        return 1;
    }
    int x=binpow(n,k/2)%MOD;
    if (k%2==0)
    {
        return x*x%MOD;
    }
    else
    {
        return x*x%MOD*n%MOD;
    }
}

struct trie
{
    int cnt=0,lvs=0;
    trie *next[26]={};
    void insert (string word, int pos=0)
    {
        if (pos==(int)word.size())
        {
            cnt++;
            lvs++;
        }   
        else
        {
            if (!next[word[pos]-'a'])
            {
                next[word[pos]-'a']=new trie;
            }
            next[word[pos]-'a']->insert(word,pos+1);
            lvs++;
        }
    }
    int count (string word, int pos=0)
    {
        if (pos==(int)word.size())
        {
            return cnt;
        }
        else
        {
            if (!next[word[pos]-'a'])
            {
                return 0;
            }
            return (next[word[pos]-'a']->count(word,pos+1));
        }
    }
    int lcp (string word, int pos=0)
    {
        if (pos==(int)word.size())
        {
            return 0;
        }
        if (!next[word[pos]-'a'])
        {
            return 0;
        }
        return 1 + next[word[pos]-'a']->lcp(word,pos+1);
    }
    void erase (string word, int pos=0)
    {
        lvs--;
        if (pos==(int)word.size())
        {
            cnt--;
        }
        else
        {
            next[word[pos]-'a']->erase(word,pos+1);
            if (!next[word[pos]-'a']->lvs)
            {
                delete next[word[pos]-'a'];
                next[word[pos]-'a']=NULL;
            }
        }
    }
}*tri;


int type;

string word;

void run_case ()
{
    tri=new trie;
    while (cin>>type>>word)
    {
        if (type==0)
        {
            tri->insert(word);
        }
        if (type==1)
        {
            tri->erase(word);
        }
        if (type==2)
        {
            cout<<tri->count(word)<<'\n';
        }
        if (type==3)
        {
            cout<<tri->lcp(word)<<'\n';
        }
    }
}

signed main ()
{
    ios_base::sync_with_stdio(0);
    cin.tie(NULL),cout.tie (NULL);
    int teste;
    teste=1;
    while (teste--)
    {
        run_case();
    }
}
