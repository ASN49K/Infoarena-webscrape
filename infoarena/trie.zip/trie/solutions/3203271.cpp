#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cstdio>
#include <utility>
#include <numeric>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
typedef long long ll;
typedef pair<ll,ll> pll;
class trie{
public:
  ll cnt=0,lvs=0;
  trie *next[30]={};
  void insert(const string &s,ll p=0){
    lvs++;
    if(p==s.size())return cnt++,void();
    if(!next[s[p]-'a'])next[s[p]-'a']=new trie;
    next[s[p]-'a']->insert(s,p+1);
  }
  void erase(const string &s,ll p=0){
    lvs--;
    if(p==s.size())return cnt--,void();
    next[s[p]-'a']->erase(s,p+1);
    if(next[s[p]-'a']->lvs==0)delete next[s[p]-'a'],next[s[p]-'a']=nullptr;
  }
  ll count(const string&s,ll p=0){
    if(p==s.size())return cnt;
    if(!next[s[p]-'a'])return 0;
    return next[s[p]-'a']->count(s,p+1);
  }
  ll lcp(const string&s,ll p=0){
    if(!next[s[p]-'a']||p==s.size())return p;
    return next[s[p]-'a']->lcp(s,p+1);
  }
};
int main(){
  ios::sync_with_stdio(false);
  cin.tie(0);
  ll c;
  string s;
  trie aaa;
  while(fin>>c>>s){
    switch(c){
    case 0:
      aaa.insert(s);
      break;
    case 1:
      aaa.erase(s);
      break;
    case 2:
      fout<<aaa.count(s)<<'\n';
      break;
    case 3:
      fout<<aaa.lcp(s)<<'\n';
      break;
    }
  }
  return 0;
}
