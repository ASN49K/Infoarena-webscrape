#include <fstream>
#include <vector>

using namespace std;

struct Node {
	int nr_ap = 0;
	int nr_cuv = 0;
	vector<Node*> fii;

	Node() {
		fii.resize(26, nullptr);
	}
};

Node* trie_insert(Node* node, const char* s) {
	if (node == nullptr) {
		node = new Node;
	}

	node->nr_ap++;
	if (s[0] == '\0') {
		node->nr_cuv++;
	} else {
		node->fii[s[0] - 'a'] =
			trie_insert(node->fii[s[0] - 'a'], s + 1);
	}

	return node;
}

Node* trie_delete(Node* node, const char* s) {
	if (node == nullptr) {
		return node;
	}

	node->nr_ap--;
	if (s[0] == '\0') {
		node->nr_cuv--;
	} else {
		node->fii[s[0] - 'a'] = trie_delete(node->fii[s[0] - 'a'], s + 1);
	}

	if (node->nr_ap == 0) {
		delete node;
		node = nullptr;
	}

	return node;
}

int nr_ap(Node* node, const char* s) {
	if (node == nullptr) {
		return 0;
	}

	if (s[0]=='\0') {
		return node->nr_cuv;
	} else {
		return nr_ap(node->fii[s[0] - 'a'], s + 1);
	}
}

int pref_max(Node* node, const char* s) {
	if (node == nullptr) {
		return 0;
	} 
	if (s[0] == '\0' || node->fii[s[0] - 'a'] == nullptr) {
		return 0;
	} else {
		return pref_max(node->fii[s[0] - 'a'], s + 1) + 1;
	}
}

int main() {
	ifstream cin("trie.in");
	ofstream cout("trie.out");

	Node* root = nullptr;

	int op;
	while (cin >> op) {
		string s; cin >> s;
		if (op == 0) {
			root = trie_insert(root, s.c_str());
		} else if (op == 1) {
			root = trie_delete(root, s.c_str());
		} else if (op == 2) {
			cout << nr_ap(root, s.c_str());
		} else {
			cout<<pref_max(root, s.c_str());
		}
	}

	return 0;
}