#include <fstream>
#include <string>
#include <iostream>
#include <cstring>
std::ifstream fin("trie.in");
std::ofstream fout("trie.out");
const int SIZE = 'z' - 'a' + 1;
struct trie_node{
    int end_index;
    int passing_index;
    trie_node* sons[SIZE];
    trie_node(){
        end_index = 0;
        passing_index = 0;
        memset(sons, NULL, sizeof(sons));
    }
};

void trie_insert(trie_node* root, const std::string& s, int pos){
    root ->passing_index ++;
    if(pos >= s.size()){
        root ->end_index ++;
        return;
    }

    int son_index = s[pos] - 'a';

    if(root ->sons[son_index] == NULL){
        root ->sons[son_index] = new trie_node();

        //std::cout << root ->sons[son_index] ->end_index + 1;
    }
    trie_insert(root ->sons[son_index], s, pos+1);
}

void trie_erase(trie_node* root, const std::string& s, int pos){
    root ->passing_index --;
    if(pos >= s.size()){
        root ->end_index --;
        return;
    }

    int son_index = s[pos] - 'a';
    trie_erase(root ->sons[son_index], s, pos + 1);
}

int get_frequency(trie_node* root, const std::string&s, int pos){
    if(pos >= s.size()){
        return root ->end_index;
    }
    int son_index = s[pos] - 'a';

    if(root ->sons[son_index] == NULL){
        return NULL;
    }
    return get_frequency(root ->sons[son_index], s, pos + 1);
}

int get_lcp(trie_node* root, const std::string &s, int pos){
    if(pos >= s.size()){
        return root ->end_index;
    }
    int son_index = s[pos] - 'a';
    if(root ->sons[son_index] == NULL || root ->sons[son_index] ->passing_index == 0){
        return 0;
    }
    else
        return 1 + get_lcp(root ->sons[son_index], s, pos + 1);
}

int main()
{
    int op; std::string s;
    trie_node* root = new trie_node();

    while(fin >> op >> s){
        if(op == 0){
            trie_insert(root, s, 0);
        }
        else if(op == 1){
            trie_erase(root, s, 0);
        }
        else if(op == 2){
            fout << get_frequency(root, s, 0) << "\n";
        }
        else{
            fout << get_lcp(root, s, 0) << "\n";
        }
    }
    return 0;
}
