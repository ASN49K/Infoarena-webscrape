#include <bits/stdc++.h>

using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");

struct Node{
    Node* letters[26];
    int counter;
    int num_letters;

    Node(){
        this->counter = 0;
        this->num_letters = 0;
        for(int i = 0; i < 26; i++){
            this->letters[i] = NULL;
        }
    }
};

Node* trie = new Node();

void Trie_Insert(string word){
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        if(!p->letters[index]){
            p->letters[index] = new Node();
        }
        p->num_letters++;
        p = p->letters[index];
    }
    p->counter++;
}

void Trie_Delete(string word){
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        p->num_letters--;
        if(p->letters[index]->num_letters == 0 && p->letters[index]->counter == 1){
            delete  p->letters[index];
            p->letters[index] = NULL;
            return;
        }
        p = p->letters[index];
    }
    p->counter--;

}

void Trie_Count(string word){
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        p = p->letters[index];
    }
    out << p->counter << '\n';
}

void Trie_Prefix(string word){
    int len = 0;
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        if(!p->letters[index]){
            out << len << '\n';
            return;
        }
        p = p->letters[index];
        ++len;
    }
}

int main()
{
    int op;
    string word;
    while(in >> op >> word){
        switch(op){
            case 0:
                Trie_Insert(word);
                break;
            case 1:
                Trie_Delete(word);
                break;
            case 2:
                Trie_Count(word);
                break;
            case 3:
                Trie_Prefix(word);
                break;
        }
    }

    return 0;
}
