#include <fstream>
using namespace std;
int v[200006][27],val[3000005],f[3000005];
char litera[200005];
int main()
{
    ifstream cin("trie.in");
    ofstream cout("trie.out");
    int cer,cnt=1;
    string cuv;
    while(cin>>cer>>cuv)
    {
        if(cer==0)
        {
            int inc=1;
            for(int i=0;i<cuv.size();i++)
            {
                if(v[inc][cuv[i]]==0)
                {
                    cnt++;
                    v[inc][cuv[i]]=cnt;
                    inc=cnt;
                }
                else
                {
                    inc=v[inc][cuv[i]];
                }
            }
            f[inc]++;
        }
        else if(cer==1)
        {
            int inc=1,ok=0,ant;
            for(int i=0;i<cuv.size();i++)
            {
                if(v[inc][cuv[i]]>0)
                {
                    ant=inc;
                    inc=v[inc][cuv[i]];
                }
                else
                {
                    ok=1;
                    break;
                }
            }
            if(ok==0)
                f[inc]--;
        }
        else if(cer==2)
        {
            int inc=1;
            for(int i=0;i<cuv.size();i++)
            {
                inc=v[inc][cuv[i]];
            }
            cout<<f[inc]<<'\n';
        }
        else if(cer==3)
        {
            int inc=1,ok=0;
            for(int i=0;i<cuv.size();i++)
            {
                if(v[inc][cuv[i]]==0)
                {
                    cout<<i<<'\n';
                    ok=1;
                    break;
                }
                inc=v[inc][cuv[i]];
            }
            if(ok==0)
                cout<<cuv.size()<<'\n';
        }
    }
    return 0;
}
