#include <bits/stdc++.h>
#define ch (*s - 'a')
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    int aparitii, nrfii;
    Trie *fiu[30];
    Trie()
    {
        aparitii = 0;
        nrfii = 0;
        for(int i = 1;i < 26;i++)
            fiu[i] = 0;
    }
};

Trie *T = new Trie;
char s[30];

inline void Add(Trie *nod, char *s)
{
    if(*s == 0)
    {
        nod -> aparitii++;
        return;
    }
    if(nod -> fiu[ch] == 0)
    {
        nod -> fiu[ch] = new Trie;
        nod -> nrfii++;
    }
    Add(nod -> fiu[ch], s + 1);
}

inline bool Delete(Trie *nod, char *s)
{
    if(*s == 0)
        nod -> aparitii--;
    else
    {
        if(Delete(nod -> fiu[ch], s + 1) == 1)
        {
            nod -> nrfii --;
            nod -> fiu[ch] = 0;
        }
    }
    if(nod -> aparitii == 0 && nod -> nrfii == 0 && nod != T)
    {
        delete nod;
        return true;
    }
    return false;

}

inline int Search(Trie *nod, char *s)
{
    if(*s == 0)
        return nod -> aparitii;
    if(nod -> fiu[ch] != 0)
        return Search(nod -> fiu[ch], s + 1);
    return 0;
}

inline int Prefix(Trie *nod, char *s, int len)
{
    if(*s == 0 || nod -> fiu[ch] == 0)
        return len;
    return Prefix(nod -> fiu[ch], s + 1, len + 1);
}
int main()
{
    int t;
    while(fin >> t >> s)
    {
        if(t == 0)
            Add(T, s);
        else if(t == 1)
            Delete(T, s);
        else if(t == 2)
            fout << Search(T, s) << "\n";
        else
            fout << Prefix(T, s, 0) << "\n";
    }
    fout.close();
    return 0;
}
