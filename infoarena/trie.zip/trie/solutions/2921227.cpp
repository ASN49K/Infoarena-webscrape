#include <fstream>
#include <iostream>
#import <algorithm>
#import <vector>
#import <map>
#import <set>
#import <deque>
#import <queue>
#import <cassert>
//#import <cmath>
#import <cstring>
#import <cctype>
#import <cstdlib>
#import <stack>
using namespace std;
string s;
struct nod
{
    int s,v;
    nod *a[26];
    nod()
    {
        s=0;
        v=0;
        for(int i=0;i<26;i++)
        {
            a[i]=NULL;
        }
    }
}*S;
void insert(nod*&t,const int& acm)
{
    if(acm==(int)s.size())
    {
        t->s++;
        t->v++;
        return;
    }
    int nr=s[acm]-'a';
    if(t->a[nr]==NULL)
    {
        t->a[nr]=new nod();
    }
    insert(t->a[nr],acm+1);
    t->s++;
}
void del(nod*&t,const int acm)
{
    if(acm==(int)s.size())
    {
        t->s--;
        t->v--;
        return;
    }
    t->s--;
    int nr=s[acm]-'a';
    del(t->a[nr],acm+1);
    if(t->a[nr]->s==0)t->a[nr]=NULL;

}
int cnt(nod*t,const int& acm)
{
    if(acm==(int)s.size())
    {
        return t->v;
    }
    if(t->a[s[acm]-'a']!=NULL)return cnt(t->a[s[acm]-'a'],acm+1);
    return 0;
}
int pre(nod*&t,const int acm)
{
    if(acm==(int)s.size())
    {
        return acm;
    }
    int nr=s[acm]-'a';
    if(t->a[nr]!=NULL)return pre(t->a[nr],acm+1);
    return acm;
}
main()
{
    ifstream fin("trie.in");
    ofstream fout("trie.out");
    S=new nod();
    int cer,i=0;
    while(fin>>cer>>s)
    {
        if(cer==0)
        {
            insert(S,0);
        }
        else if(cer==1)
        {
            del(S,0);
        }
        else if(cer==2)
        {
            fout<<cnt(S,0)<<'\n';
        }
        else
        {
            fout<<pre(S,0)<<'\n';
        }
    }
}
