#include <fstream>
#include <string>

using namespace std;

ifstream in ("trie.in");
ofstream out ("trie.out");

struct arb
{
    int nrfii, fr;
    arb * fii[26];
    arb()
    {
        nrfii = 0;
        fr = 0;
        for (int i = 0; i < 26; i++)
        {
            fii[i] = 0;
        }
    }
};

arb * t = new arb;
string s;

void ins (arb * nod, int poz)
{
    if (poz == s.size())
    {
        nod -> fr++;
        return;
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] == 0)
    {
        nod -> fii[urm] = new arb;
        nod -> nrfii++;
    }
    ins(nod -> fii[urm], poz + 1);
}

bool del (arb * nod, int poz)
{
    if (poz == s.size())
    {
        nod -> fr--;
    }
    else
    {
        int urm = (s[poz] - 'a');
        if (del(nod -> fii[urm], poz + 1))
        {
            nod -> nrfii--;
            nod -> fii[urm] = 0;
        }
    }
    if (nod -> fr == 0 && nod -> nrfii == 0 && nod != t)
    {
        delete nod;
        return true;
    }
    return false;
}

int query1 (arb * nod, int poz)
{
    if (poz == s.size())
    {
        return nod -> fr;
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] == 0)
    {
        return 0;
    }
    return query1(nod -> fii[urm], poz + 1);
}

int query2 (arb * nod, int poz)
{
    if (poz == s.size())
    {
        return s.size();
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] != 0)
    {
        return query2(nod -> fii[urm], poz + 1);
    }
    return poz;
}

int main ()
{
    int op;
    while (in >> op >> s)
    {
        if (op == 0)
        {
            ins(t, 0);
        }
        if (op == 1)
        {
            del(t, 0);
        }
        if (op == 2)
        {
            out << query1(t, 0) << '\n';
        }
        if (op == 3)
        {
            out << query2(t, 0) << '\n';
        }
    }
    in.close();
    out.close();
    return 0;
}
