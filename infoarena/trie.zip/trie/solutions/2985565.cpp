#include <bits/stdc++.h>

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");
class Trie
{
    int cnt = 0;
    int lvs = 0;
    Trie *next[26] = {};

public:
    void insert(const string& str, int pos = 0)
    {
        lvs++;
        if (pos == int(str.size()))
            cnt++;
        else
        {
            if (!next[str[pos] - 'a'])
                next[str[pos] - 'a'] = new Trie;
            next[str[pos] - 'a']->insert(str, pos + 1);
        }
    }
    void erase(const string& str, int pos = 0)
    {
        lvs--;
        if (pos == int(str.size()))
            cnt--;
        else
        {
            next[str[pos] - 'a']->erase(str, pos + 1);
            if (!next[str[pos] - 'a']->lvs)
            {
                delete next[str[pos] - 'a'];
                next[str[pos] - 'a'] = nullptr;
            }
        }
    }

    int count(const string& str, int pos = 0)
    {
        if (pos == int(str.size()))
            return cnt;
        if (!next[str[pos] - 'a'])
            return 0;
        return next[str[pos] - 'a']->count(str, pos + 1);
    }

    int lcp(const string& str, int pos = 0)
    {
        if (pos == int(str.size()))
            return 0;
        if (!next[str[pos] - 'a'])
            return 0;
        return 1 + next[str[pos] - 'a']->lcp(str, pos + 1);
    }
};


int main()
{
    int tip;
    string str;
    Trie trie;
    while(in >> tip >> str)
    {
        if(tip == 0)
            trie.insert(str);
        else if(tip == 1)
            trie.erase(str);
        else if(tip == 2)
            out << trie.count(str) << '\n';
        else
            out << trie.lcp(str) << '\n';
    }
    return 0;
}
