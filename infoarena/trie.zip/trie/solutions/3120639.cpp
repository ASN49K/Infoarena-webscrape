#include <iostream>
#include <fstream>
#include <vector>
#include<set>
#include<queue>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");


struct trie
{
	trie* child[26];
	int cnt;
	int nrAp;
};

trie* head;

void TrieInsert(string s)
{
	trie* p = head;
	int len = s.length();
	for (int i = 0; i < len; i++)
		if (p->child[s[i] - 'a'] != 0)
		{
			p->nrAp++;
			p = p->child[s[i] - 'a'];
		}
		else
		{
			trie* q = new trie();
			p->child[s[i] - 'a'] = q;
			p->nrAp++;
			p = p->child[s[i] - 'a'];
		}
	p->cnt++;
	p->nrAp++;
}

void TrieDelete(string s)
{
	trie* p = head;
	trie* last = head;
	int len = s.length();
	for (int i = 0; i < len; i++)
	{
		p->nrAp--;
		trie* q = p;
		p = p->child[s[i] - 'a'];
		if (q->nrAp == 0 && q != head && last->child[s[i - 1] - 'a'] == q)
		{
			delete q;
			last->child[s[i - 1] - 'a'] = 0;
		}
		else last = q;
	}
	p->nrAp--;
	p->cnt--;
	if (p->nrAp == 0 && last->child[s[len - 1] - 'a'] == p)
	{
		delete p;
		last->child[s[len - 1] - 'a'] = 0;
	}
}

int TrieAparitii(string s)
{
	trie* p = head;
	int len = s.length();
	for (int i = 0; i < len; i++)
	{
		if (p->child[s[i] - 'a'] == 0) return 0;
		p = p->child[s[i] - 'a'];
	}
	return p->cnt;
}

int TrieLongestCommonPrefix(string s)
{
	trie* p = head;
	int len = s.length();
	int cnt = 0;
	for (int i = 0; i < len; i++)
	{
		if (p->child[s[i] - 'a'] == 0) return cnt;
		cnt++;
		p = p->child[s[i] - 'a'];
	}
	return cnt;
}

int main()
{
	head = new trie();
	int op;
	string s;
	while (fin >> op >> s)
	{
		if (op == 0) TrieInsert(s);
		else if (op == 1) TrieDelete(s);
		else if (op == 2) fout << TrieAparitii(s) << "\n";
		else fout << TrieLongestCommonPrefix(s) << "\n";
	}
}