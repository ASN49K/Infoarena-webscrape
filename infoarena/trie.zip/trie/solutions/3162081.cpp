#include <bits/stdc++.h>

using namespace std;
typedef unsigned long long int ll;
#define MOD 1000000009

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
    int nr=0,cnt=0;
    trie *fii[26]={0};
};

trie *T = new trie();
void ins(trie *p,char *s)
{
    if(*s=='\n')
    {
        p->cnt++;
        return;
    }
    if(p->fii[*s-'a']==0)
    {
        p->nr++;
        p->fii[*s-'a']= new trie;
    }

    ins(p->fii[*s-'a'],s+1);
}
int del(trie *p,char *s)
{
    if(*s=='\n')
    {
        p->cnt--;
    }
    else if(del(p->fii[*s-'a'],s+1))
    {
        p->nr--;
        p->fii[*s-'a']=0;
    }
    if(p->cnt==0 && p->nr==0 && p!=T)
    {
        delete p;
        return 1;
    }
    return 0;
}
int query(trie *p,char *s)
{
    if(*s=='\n')
    {
        return p->cnt;
    }
    if(p->fii[*s-'a']==0)return 0;
    return query(p->fii[*s-'a'],s+1);
}
int pref(trie *p, char *s)
{
    if(*s=='\n')return 0;
    if(p->fii[*s-'a']==0)return 0;
    return 1+pref(p->fii[*s-'a'],s+1);
}
int main()
{

    int t;
    while(fin >> t)
    {
        char c[30];
        fin >> c;
        c[strlen(c)]='\n';
        if(t==0)
        {
            ins(T,c);
        }
        if(t==1)
        {
            del(T,c);
        }
        if(t==2)
        {
            fout << query(T,c) << "\n";
        }
        if(t==3)
        {

            fout << pref(T,c) << "\n";
        }

    }
}

