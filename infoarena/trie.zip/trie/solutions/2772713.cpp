#include <bits/stdc++.h>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct trie
{
    int nr, fii;
    trie* F[26];
    trie()
    {
        fii = nr = 0;
        for(int i = 1; i < 26; i++)
            F[i] = 0;
    }
};

int ops;
char s[25];
trie* rad = new trie;

int deleteTrie(trie* &p, int ind, int n)
{
    if(ind < n)
    {
        if(deleteTrie(p -> F[s[ind] - 'a'], ind + 1, n))
        {
            p -> fii--;
            if(p -> nr == 0 && p -> fii == 0 && p != rad)
            {
                delete p;
                p = 0;
                return 1;
            }
        }
    }
    else
    {
        p -> nr--;
        if(p -> nr == 0 && p -> fii == 0 && p != rad)
        {
            delete p;
            p = 0;
            return 1;
        }
    }


    return 0;
}

int main()
{

    while(f >> ops >> s)
    {
        if(ops == 0)
        {
            int ind = 0;
            int n = strlen(s);
            trie* p = rad;
            while(p -> F[s[ind] - 'a'] && ind < n)
                p = p -> F[s[ind] - 'a'], ind++;
            if(ind == n)
            {
                p -> nr++;
                continue;
            }
            else
            {
                while(ind < n)
                {
                    trie* t = new trie;
                    p -> fii++;
                    p -> F[s[ind] - 'a'] = t;
                    p = t;
                    ind++;
                }
                p -> nr++;
            }
        }

        if(ops == 1)
        {
            trie* p = rad;
            int ind = 0;
            deleteTrie(p, ind, strlen(s));
        }

        if(ops == 2)
        {
            int n = strlen(s);
            trie* p = rad;
            int ind = 0;
            while(ind < n && p -> F[s[ind] - 'a'])
            {
                p = p -> F[s[ind] - 'a'];
                ind++;
            }
            if(ind < n)
                g << 0 << "\n";
            else
                g << p -> nr << "\n";
        }

        if(ops == 3)
        {
            int ind = 0, n = strlen(s), ans = 0;
            trie* p = rad;
            while(p -> F[s[ind] - 'a'] && ind < n)
            {
                p = p -> F[s[ind] - 'a'];
                ind++;
            }
            g << ind << "\n";
        }
    }

    return 0;
}
