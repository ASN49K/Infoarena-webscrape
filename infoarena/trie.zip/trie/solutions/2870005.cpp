#include <bits/stdc++.h>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
class Trie {
private:
    int cntsons, freq;
    Trie* sons[26];
public:
    Trie() : cntsons(0), freq(0) {
        memset(sons, 0, sizeof(sons));
    }
    inline void Query(int const& op, string const& s) {
        if (op == 0) Add(s);
        else if (op == 1) Erase(s);
        else if (op == 2) fout << Count(s) << '\n';
        else if (op == 3) fout << LP(s) << '\n';
    }
    inline void Add(string const& s, size_t const& ind = 0) {
        int x = s[ind] - 'a';
        if (!sons[x]) {
            sons[x] = new Trie;
            ++cntsons;
        }
        if (ind == s.size() - 1)
            ++sons[x] -> freq;
        else sons[x] -> Add(s, ind + 1);
    }
    inline void Erase(string const& s, size_t const& ind = 0) {
        int x = s[ind] - 'a';
        if (ind == s.size() - 1)
            --sons[x] -> freq;
        else sons[x] -> Erase(s, ind + 1);
        if (sons[x] -> freq == 0 && sons[x] -> cntsons == 0) {
            delete sons[x];
            sons[x] = 0;
            --cntsons;
        }
    }
    inline int Count(string const& s, size_t const& ind = 0) const {
        int x = s[ind] - 'a';
        if (!sons[x]) return 0;
        if (ind == s.size() - 1)
            return sons[x] -> freq;
        return sons[x] -> Count(s, ind + 1);
    }
    inline int LP(string const& s, size_t const& ind = 0) const {
        int x = s[ind] - 'a';
        if (sons[x] && ind < s.size() - 1)
            return sons[x] -> LP(s, ind + 1);
        return ind;
    }
};
Trie* root = new Trie;
main() {
    int op;
    string s;
    while (fin >> op >> s)
        root -> Query(op, s);
    return 0;
}
