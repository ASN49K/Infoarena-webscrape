#include <iostream>
using namespace std;

struct Trie {
    unsigned nrAp;
    Trie *lit[26];
    Trie() {
        nrAp = 0;
        for (int i = 0; i < 26; i += 1) {
            lit[i] = nullptr;
        }
    }
};

void adauga(Trie* trie, char* cuv) {
    Trie *it = trie;
    for (int i = 0; cuv[i] != 0; i += 1) {
        if(it->lit[cuv[i] - 'a'] != nullptr) {
            it = it->lit[cuv[i] - 'a'];
            continue;
        }

        Trie *new_trie = new Trie;
        it->lit[cuv[i] - 'a'] = new_trie;
        it = new_trie;
    }
    it->nrAp += 1;
}

unsigned aparitii(Trie* trie, char* cuv) {
    Trie *it = trie;
    for (int i = 0; cuv[i] != 0; i += 1) {
        if (it == nullptr) {
            return 0;
        }
        it = it->lit[cuv[i] - 'a'];
    }
    return it->nrAp;
}

void sterge(Trie* trie, char* cuv) {
    Trie *it = trie;
    Trie *last_needed = trie;
    char first_unused = cuv[0];
    for (int i = 0; cuv[i] != 0; i += 1) {

        for (int j = 0; j < 26; j += 1) {
            if (it->lit[j] != nullptr && cuv[i] - 'a' != j) {
                last_needed = it;
                first_unused = cuv[i];
                break;
            }
        }
        if (it->nrAp > 0) {
            last_needed = it;
            first_unused = cuv[i];
        }

        it = it->lit[cuv[i] - 'a'];

        

    }
    it->nrAp -= 1;
    if (it->nrAp > 0) {
        return;
    }
    for (int i = 0; i < 26; i += 1) {
        if (it->lit[i] != nullptr) {
            return;
        }
    }
    last_needed->lit[first_unused - 'a'] = nullptr;
}

unsigned prefix(Trie* trie, char* cuv) {
    Trie *it = trie;
    unsigned i = 0;
    for (i = 0; cuv[i] != 0; i += 1) {
        it = it->lit[cuv[i] - 'a'];
        if (it == nullptr) {
            return i;
        }
    }
    return i;
}

int main() {
    // ios_base::sync_with_stdio(false);
    // cin.tie(nullptr);

    Trie *trie = new Trie;
    int cod;
    char cuv[21];

    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);
    while (cin >> cod) {
        cin >> cuv;
        switch (cod) {
        case 0:
            adauga(trie, cuv);
            break;
        case 1:
            sterge(trie, cuv);
            break;
        case 2:
            cout << aparitii(trie, cuv) << '\n';
            break;
        default:
            cout << prefix(trie, cuv) << '\n';
        }
    }

    return 0;
}