#include <bits/stdc++.h>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct Trie {
  int no_chld, fin;
  unordered_map<char, Trie*> children;

  Trie() {
    no_chld = fin = 0;
  }
};

Trie *T = new Trie;

void insert(Trie* node, char* word) {
  if(!isalpha(*word)) {
    node->fin++;
    return;
  }
  if(!node->children.count(*word)) {
    node->no_chld++;
    node->children[*word] = new Trie;
  }
  insert(node->children[*word], word + 1);
}

bool del(Trie* node, char *word) {
  if(!isalpha(*word)) {
    node->fin--;
  } else if(del(node->children[*word], word + 1)) {
    node->no_chld--;
    node->children.erase(*word);
  }
  if(!node->fin && !node->no_chld && node != T) {
    delete node;
    return true;
  }
  return false;
}

int occ(Trie* node, char *word) {
  if(!isalpha(*word)) {
    return node->fin;
  }
  if(!node->children.count(*word)) {
    return 0;
  }
  return occ(node->children[*word], word + 1);
}

int pref(Trie* node, char *word, int len) {
  if(!isalpha(*word) || !node->children.count(*word)) {
    return len;
  }
  return pref(node->children[*word], word + 1, len + 1);
}

void solve() {
  int x;
  char word[25];
  while(f>>x>>word) {
    if(!x) {
      insert(T, word);
    } else if(x == 1) {
      del(T, word);
    } else if(x == 2) {
      g<<occ(T, word)<<'\n';
    } else {
      g<<pref(T, word, 0)<<'\n';
    }
  }
}

int main() {
  solve();

  return 0;
}
