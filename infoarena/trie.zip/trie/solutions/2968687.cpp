#include <fstream>

using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");

class TrieNode
{
private:
    int cnt;// prefix  nr ap cuvant
    int subtreecnt;//length of the letters that exist
    TrieNode *edges[26];

public:
    TrieNode()
    {
        cnt=0;
        subtreecnt=0;
        for(int i=0;i<26;i++)
        {
            edges[i]=nullptr;
        }
    }
void insert1(string &word,int poz=0)
{
    if(poz==word.size())
    {
        subtreecnt++;
        cnt++;
        return;
    }
    int edgeindex=word[poz]-'a';
    if(edges[edgeindex]==nullptr)
    {
        edges[edgeindex]=new TrieNode();
    }
    edges[edgeindex]->insert1(word,poz+1);
    subtreecnt++;
}
void delete1(string &word,int poz=0)
{
    if(poz==word.size())
    {
        subtreecnt--;
        cnt--;
        return;
    }
    int edgeindex=word[poz]-'a';
    //edges[edgeindex]=nullptr;
    edges[edgeindex]->delete1(word,poz+1);
    subtreecnt--;
}
int parcurgere(string &word,int poz=0)
{
    if(poz==word.size())
        return cnt;
    int edgeindex=word[poz]-'a';
    if(edges[edgeindex]==nullptr)
        return 0;
    return edges[edgeindex]->parcurgere(word,poz+1);

}
int longest_common_length(string &word,int poz=0)
{
    int edgeindex=word[poz]-'a';
    if(edges[edgeindex]==nullptr || edges[edgeindex] -> subtreecnt==0 || poz==word.size())
        return poz;
    return edges[edgeindex]->longest_common_length(word,poz+1);

}
};
int main()
{
    int cerinta;
    string s;
    TrieNode x;
    while(in>>cerinta>>s)
    {
        if(cerinta==1)
            x.delete1(s);
        else if(cerinta==0)
            x.insert1(s);
        else if(cerinta==2)
            out<<x.parcurgere(s)<<'\n';
        else if(cerinta==3)
            out<<x.longest_common_length(s)<<'\n';

    }
    return 0;
}
