
#include <fstream>

using namespace std;

const int NL = 26;
const int L = 21;

struct nod
{
    nod* fii[NL];
    int nrcuv, nrpref;

    nod()
    {
        for (int i = 0; i < NL; i++)
        {
            fii[i] = NULL;
        }
        nrcuv = 0;
        nrpref = 0;
    }
};

nod* adauga(nod* p, char* s)
{
    if (p == NULL)
    {
        p = new nod();
    }
    p->nrpref++;
    if (s[0] == '\0')
    {
        p->nrcuv++;
        return p;
    }
    int i = s[0] - 'a';
    p->fii[i] = adauga(p->fii[i], s+1);
    return p;
}

nod* sterge(nod* p, char* s)
{
    p->nrpref--;
    if (s[0] == '\0')
    {
        p->nrcuv--;
    }
    else
    {
        int i = s[0] - 'a';
        p->fii[i] = sterge(p->fii[i], s+1);
    }
    if (p->nrpref == 0)
    {
        delete p;
        return NULL;
    }
    return p;
}

int nr_cuvinte(nod* p, char* s)
{
    if (p == NULL)
    {
        return 0;
    }
    if (s[0] == '\0')
    {
        return p->nrcuv;
    }
    int i = s[0] - 'a';
    return nr_cuvinte(p->fii[i], s+1);
}

int lungime_pref_comun(nod* p, char* s)
{
    if (p == NULL)
    {
        return -1;
    }
    if (s[0] == '\0')
    {
        return 0;
    }
    int i = s[0] - 'a';
    return 1 + lungime_pref_comun(p->fii[i], s+1);
}

int main()
{
    ifstream in("trie.in");
    ofstream out("trie.out");
    nod* r = NULL;
    int tip;
    char cuvant[L];
    while (in >> tip >> cuvant)
    {
        if (tip == 0)
        {
            r = adauga(r, cuvant);
        }
        if (tip == 1)
        {
            r = sterge(r, cuvant);
        }
        if (tip == 2)
        {
            out << nr_cuvinte(r, cuvant) << "\n";
        }
        if (tip == 3)
        {
            out << lungime_pref_comun(r, cuvant) << "\n";
        }
    }
    in.close();
    out.close();
    return 0;
}
