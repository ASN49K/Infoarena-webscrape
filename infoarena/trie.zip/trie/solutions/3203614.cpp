#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdio>
using namespace std;
typedef long long ll;
typedef pair<ll,ll> pll;
class trie{
public:
  ll lvs,cnt;
  trie*next[30];
  void insert(const string&s,ll p=0){
    lvs++;
    if(p==s.size())return cnt++,void();
    if(!next[s[p]-'a'])next[s[p]-'a']=new trie;
    next[s[p]-'a']->insert(s,p+1);
  }
  void erase(const string&s,ll p=0){
    lvs--;
    if(p==s.size())return cnt--,void();
    next[s[p]-'a']->erase(s,p+1);
    if(next[s[p]-'a']->lvs==0)delete next[s[p]-'a'],next[s[p]-'a']=nullptr;
  }
  ll count(const string&s,ll p=0){
    if(p==s.size())return cnt;
    if(!next[s[p]-'a'])return 0;
    return next[s[p]-'a']->count(s,p+1);
  }
  ll lcp(const string&s,ll p=0){
    if(p==s.size()||!next[s[p]-'a'])return 0;
    return 1+next[s[p]-'a']->lcp(s,p+1);
  }
};
ifstream fin("trie.in");
ofstream fout("trie.out");
int main(){
  ll c;
  string s;
  trie tr;
  while(fin>>c>>s){
    switch(c){
    case 0:
      tr.insert(s);
      break;
    case 1:
      tr.erase(s);
      break;
    case 2:
      fout<<tr.count(s)<<'\n';
      break;
    case 3:
      fout<<tr.lcp(s)<<'\n';
      break;
    }
  }
  return 0;
}
