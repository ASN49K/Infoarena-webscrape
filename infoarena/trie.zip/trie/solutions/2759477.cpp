#include <fstream>

using namespace std;

const int NL = 26;
const int L = 21;

struct nod
{
    nod* fii[NL];
    int nrcuv, nrpref;///numarul de cuvinte coresp drumului de la radacina la nodul curent, nr prefixe...

    nod()
    {
        for (int i = 0; i < NL; i++)
        {
            fii[i] = NULL;
        }
        nrcuv = 0;
        nrpref = 0;
    }
};

nod* adauga(nod* p, char* s)
{
    if (p == NULL)
    {
        p = new nod();
    }
    p->nrpref++;
    if (s[0] == '\0')///nu mai am litere neprelucrate in cuvantul curent s
    {
        p->nrcuv++;
        return p;
    }
    int i = s[0] - 'a';///pozitia literei curente in alfabet
    p->fii[i] = adauga(p->fii[i], s+1);
    return p;
}

nod* sterge(nod* p, char* s)
{
    p->nrpref--;
    if (s[0] == '\0')///nodul curent corespunde cuvantului sters
    {
        p->nrcuv--;
    }
    else
    {
        int i = s[0] - 'a';
        p->fii[i] = sterge(p->fii[i], s+1);
    }
    if (p->nrpref == 0)
    {
        delete p;
        return NULL;
    }
    return p;
}

int nr_cuvinte(nod* p, char* s)
{
    if (p == NULL)///cuvantul verificat nu apare in trie
    {
        return 0;
    }
    if (s[0] == '\0')///am ajuns in nodul corespunzator cuvantului prelucrat
    {
        return p->nrcuv;
    }
    int i = s[0] - 'a';///pozitia primei litere in alfabet
    return nr_cuvinte(p->fii[i], s+1);
}

int lungime_pref_comun(nod* p, char* s)
{
    if (p == NULL || s[0] == '\0')
    {
        return 0;
    }
    int i = s[0] - 'a';///pozitia literei in alfabet
    return 1 + lungime_pref_comun(p->fii[i], s+1);
}

int main()
{
    ifstream in("trie.in");
    ofstream out("trie.out");
    nod* r = NULL;
    int tip;
    char cuvant[L];
    while (in >> tip >> cuvant)
    {
        if (tip == 0)
        {
            r = adauga(r, cuvant);
        }
        if (tip == 1)
        {
            r = sterge(r, cuvant);
        }
        if (tip == 2)
        {
            out << nr_cuvinte(r, cuvant) << "\n";
        }
        if (tip == 3)
        {
            out << lungime_pref_comun(r, cuvant) - 1 << "\n";
        }
    }
    in.close();
    out.close();
    return 0;
}
