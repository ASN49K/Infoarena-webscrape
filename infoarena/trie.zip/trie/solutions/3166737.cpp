#include <bits/stdc++.h>
using namespace std;
#define pb push_back

ifstream f("trie.in");
ofstream g("trie.out");

struct T {
	T *fiu[26];
	int cnt, cntfin;
	T(){
		for (int i = 0; i <= 25; i++)
			fiu[i] = NULL;
		cnt = cntfin = 0;
	}
};
char w[23], task;
T *root;

int main()
{
	root = new T;
	while (f >> task >> w){
		T *aux = root;
		char *p = w;
		if (task == '0'){
			while (*p){
				int ch = *p - 'a';
				if (aux->fiu[ch] == NULL) 
					aux->fiu[ch] = new T;
				aux = aux->fiu[ch];
				aux->cnt++;
				p++;
			}
			aux->cntfin++;
		}
		else if (task == '1'){
			while (*p){
				int ch = *p - 'a';
				aux = aux->fiu[ch];
				aux->cnt--;
				p++;
			}
			aux->cntfin--;
		}
		else if (task == '2'){
			while (*p){
				int ch = *p - 'a';
				if (aux->fiu[ch] == nullptr || !aux->fiu[ch]->cnt) break;
				aux = aux->fiu[ch]; 
				p++;
			}
			g << (*p == 0 ? aux->cntfin : 0) << '\n';
		}
		else {
			int l = 0;
			while (*p){
				int ch = *p - 'a';
				if (aux->fiu[ch] == nullptr || !aux->fiu[ch]->cnt) 
					break;
				l++; p++;
				aux = aux->fiu[ch];
			}
			g << l << '\n';
		}
	}
	
	return 0;
}
