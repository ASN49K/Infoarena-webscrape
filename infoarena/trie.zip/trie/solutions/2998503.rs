use std::{
    fs::File,
    error::Error,
    io::{BufReader, BufRead},
};
fn main() -> Result<(), Box<dyn Error>> {
    let file = File::open("trie.in")?;
    let reader = BufReader::new(file);
    for line in reader.lines() {
        line?.clear();
    }
    Ok(())
}
