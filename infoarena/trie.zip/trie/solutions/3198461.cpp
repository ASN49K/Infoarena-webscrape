#include <fstream>
#include <string>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

const int sz = 100000;

char s[35];

struct nod
{
    int pref;
    int cuv;
    int f[27];
} t[sz + 5];

int lid = 0;

int op;

void insert(char* st,int node)
{

    t[node].pref++;
    if(st[0]==0){
        t[node].cuv++;
        return;
    }
        if(t[node].f[st[0]-'a'])
            insert(st+1,t[node].f[st[0]-'a']);
        else
        {
            t[node].f[st[0]-'a'] = ++lid;
            insert(st+1,lid);
        }

}
void erase(char* st,int node)
{
    t[node].pref--;

    if(st[0]==0){
        t[node].cuv--;
        return;
    }

    erase(st+1,t[node].f[st[0]-'a']);
    //if(t[node].f[st[0]-'a'].pref==0)
    //  t[node].f[st[0]-'a']=0;
}

int find(char*st,int node)
{
    if(st[0]==0)
        return t[node].cuv;
    if(t[node].f[st[0]-'a']!=0)
        return find(st+1,t[node].f[st[0]-'a']);
    else
        return 0;
}
int solprefix = 0;
void prefix(char *st,int node,int l)
{
    if(t[node].pref>0)
    {
        solprefix=l;
        if(st[0]==0)
            return;
        if(t[node].f[st[0]-'a']!=0)
            prefix(st+1,t[node].f[st[0]-'a'],l+1);
    }
}

int main()
{
    while(fin>>op>>s)
    {
        if(op==0)
            insert(s,0);

        else if (op==1)
            erase(s,0);

        else if (op==2)
            fout<<find(s,0)<<'\n';
        else
        {
            solprefix=0;
            prefix(s,0,0);
            fout<<solprefix<<'\n';
        }
    }
}
