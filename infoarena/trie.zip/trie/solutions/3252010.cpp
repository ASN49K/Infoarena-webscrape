#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream fin( "trie.in" );
ofstream fout( "trie.out" );

struct node {
    int cnt, fii;
    node* v[26];
    node() {
        cnt = fii = 0;
        for( int i = 0; i < 25; i++ ) v[i] = NULL;
    }
};
node* rad = new node;

void add_dfs( node* nod, string str, int i ) {
    if( i >= str.size() ) {
        nod->cnt++;
        return;
    }
    if( nod->v[str[i]-'a'] == NULL ) {
        nod->v[str[i]-'a'] = new node;
        nod->fii++;
    }
    add_dfs( nod->v[str[i]-'a'], str, i + 1 );
}

int del_dfs( node* nod, string str, int i ) {
    int g;
    if( i >= str.size() ) {
        g = 0;
        nod->cnt--;
        if( nod->cnt == 0 && nod->fii == 0 && nod != rad ) {
            delete nod;
            g = 1;
        }
        return g;
    }
    g = del_dfs( nod->v[str[i]-'a'], str, i + 1 );
    if( g == 1 ) {
        nod->v[str[i]-'a'] = NULL;
    }
    g = 0;
    if( nod->cnt == 0 && nod->fii == 0 && nod != rad ) {
        delete nod;
        g = 1;
    }
    return g;
}

int app_dfs( node* nod, string str, int i ) {
    if( i >= str.size() )
        return nod->cnt;
    if( nod->v[str[i]-'a'] == NULL )
        return 0;
    return app_dfs( nod->v[str[i]-'a'], str, i + 1 );
}

int pref_dfs( node* nod, string str, int i ) {
    if( i >= str.size() )
        return i;
    if( nod->v[str[i]-'a'] == NULL )
        return i;
    return pref_dfs( nod->v[str[i]-'a'], str, i + 1 );
}


int main() {
    string str;
    char ch;
    int op;
    while( fin >> op ) {
        fin >> str;
        
        if( op == 0 ) { // add str
            add_dfs( rad, str, 0 );
        }
        else if( op == 1 ) { // del str
            del_dfs( rad, str, 0 );
        }
        else if( op == 2 ) { // de cate ori apare str
            fout << app_dfs( rad, str, 0 ) << '\n';
        }
        else if( op == 3 ) { // cel mai lung pref comun cu str
            fout << pref_dfs( rad, str, 0 ) << '\n';
        }
        
    }
    return 0;
}
