#include <fstream>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

class TrieNod
{
    int nr_cuvinte;
    int subtreesum;
    TrieNod *muchii[26];

public:
    TrieNod()
    {
        nr_cuvinte = 0;
        subtreesum = 0;
        for (int i = 0; i < 26; i++)
        {
            muchii[i] = nullptr;
        }
    }
    void inserare(string &cuv, int curpoz)
    {
        if (curpoz == cuv.size())
        {
            subtreesum++;
            this->nr_cuvinte++;
            return;
        }
        int curedge = cuv[curpoz] - 'a';
        if (muchii[curedge] == nullptr)
            muchii[curedge] = new TrieNod();
        subtreesum++;
        muchii[curedge]->inserare(cuv, curpoz + 1);
    }
    void stergere(string &cuv, int curpoz)
    {
        if (curpoz == cuv.size())
        {
            subtreesum--;
            nr_cuvinte--;
            return;
        }
        int curedge = cuv[curpoz] - 'a';
        subtreesum--;
        muchii[curedge]->stergere(cuv, curpoz + 1);
    }
    int tiparire(string &cuv, int curpoz)
    {
        if (curpoz == cuv.size())
            return nr_cuvinte;
        int curedge = cuv[curpoz] - 'a';
        if (muchii[curedge] == nullptr)
            return 0;
        return muchii[curedge]->tiparire(cuv, curpoz + 1);
    }
    int tiparire_prefix_comun(string &cuv, int curpoz)
    {
        int curedge = cuv[curpoz] - 'a';
        // S-a terminat partea comuna
        if (muchii[curedge] == nullptr || muchii[curedge]->subtreesum == 0)
            return curpoz;
        return muchii[curedge]->tiparire_prefix_comun(cuv, curpoz + 1);
    }
};

int main()
{
    TrieNod *root = new TrieNod();
    int comanda;
    string sir;
    while (fin >> comanda >> sir)
    {
        if (comanda == 0)
            root->inserare(sir, 0);
        else if (comanda == 1)
            root->stergere(sir, 0);
        else if (comanda == 2)
            fout << root->tiparire(sir, 0) << "\n";
        else
            fout << root->tiparire_prefix_comun(sir, 0) << "\n";
    }
    return 0;
}