#include <fstream>
#include <string>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
struct node
{
    int fr, afr;
    node* dad;
    node* next[26];
};
node* root = NULL;
int op, n, m, i, j;
string s;
int main()
{
    node* root = new node;
    root->fr = 0;
    root->afr = 0;
    root->dad = NULL;
    for (i = 0; i < 26; i++)
        root->next[i] = NULL;
    while (fin >> op >> s)
    {
        if (op == 0)
        {
            node* p = root;
            for (i = 0; i < s.size(); i++)
            {
                if (p->next[int(s[i]) - 'a'] == NULL)
                {
                    node* q = new node;
                    q->fr = 0;
                    q->afr = 0;
                    q->dad = p;
                    for (int i = 0; i < 26; i++)
                        q->next[i] = NULL;
                    p->next[int(s[i]) - 'a'] = q;
                }
                p = p->next[int(s[i]) - 'a'];
            }
            p->fr++;
            while (p != NULL)
            {
                p->afr++;
                p = p->dad;
            }
        }
        else if (op == 1)
        {
            node* p = root;
            for (i = 0; i < s.size(); i++)
                p = p->next[int(s[i]) - 'a'];
            p->fr--;
            while (p != NULL)
            {
                p->afr--;
                p = p->dad;
            }
        }
        else if (op == 2)
        {
            node* p = root;
            for (i = 0; i < s.size(); i++)
            {
                if (p->next[int(s[i]) - 'a'] == NULL)
                {
                    fout << 0 << "\n";
                    break;
                }
                p = p->next[int(s[i]) - 'a'];
            }
            if (i == s.size()) fout << p->fr << "\n";
        }
        else if (op == 3)
        {
            node* p = root;
            int val = 0, counter = 0, broken = 0;
            for (i = 0; i < s.size(); i++)
            {
                if (p->next[int(s[i])-'a'] == NULL || p->next[int(s[i])-'a']->afr == 0)
                    break;
                p = p->next[int(s[i])-'a'];
            }
            fout << i << "\n";

        }
    }
    return 0;
}
