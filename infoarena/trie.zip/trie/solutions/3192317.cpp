#include<fstream>
using namespace std;
ifstream F("trie.in");
ofstream G("trie.out");
struct T {
    unsigned short w,p;
    T *a[26];
}*r,*t;
unsigned short c,i,k;
string s;
int main()
{

    for(r=new T();F>>c>>s;)
        if(t=r,k=s.size(),!c) {
            for(++t->p,i=0;i<k;t=t->a[s[i++]-97],++t->p)
                if(!t->a[s[i]-97])
                    t->a[s[i]-97]=new T();
            ++t->w;
        } else if(c<2) {
            for(--t->p,i=0;i<k&&t->a[s[i]-97];t=t->a[s[i++]-97],--t->p);
            --t->w;
        } else if(c<3) {
            for(i=0;i<k&&t->a[s[i]-97];t=t->a[s[i++]-97]);
            G<<(i<k?0:t->w)<<'\n';
        } else {
            for(i=0;i<k&&t->a[s[i]-97]&&t->a[s[i]-97]->p>0;t=t->a[s[i++]-97]);
            G<<i<<'\n';
        }
    return 0;
}
