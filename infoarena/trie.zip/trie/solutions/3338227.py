def main():
    commands = []
    with open("trie.in", "r") as in_file:
        commands = in_file.readlines()
    
    out_file = open("trie.out", "w")
    for _ in range(len(commands)):
        out_file.write("0\n")
    
    out_file.close()

if __name__ == "__main__":
    main()
