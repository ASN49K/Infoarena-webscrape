#include <bits/stdc++.h>

using namespace std;

#define N 200000

struct Nod{
    int pre,en;
    Nod *next[26];

    Nod(){
        pre=en=0;
        for (int i=0; i<26; i++)
            next[i]=NULL;
    }
};

Nod *t=new Nod;

void ins(Nod *&i, string s, int k=-1){
    if (k==s.size()-1){
        i->en++;
        return;
    }

    if (i->next[s[k+1]-'a']==NULL)
        i->next[s[k+1]-'a']=new Nod;

    i->next[s[k+1]-'a']->pre++;
    ins(i->next[s[k+1]-'a'], s, k+1);
}

void eras(Nod *&i, string s, int k=-1){
    if (k==s.size()-1){
        i->en--;
        return;
    }

    i->next[s[k+1]-'a']->pre--;
    eras(i->next[s[k+1]-'a'], s, k+1);
}

int query(Nod *i, string s, int k=-1){
    if (i==NULL)
        return 0;
    if (k!=-1 && i->pre==0)
        return 0;
    if (k==s.size()-1)
        return i->en;

    return query(i->next[s[k+1]-'a'], s, k+1);
}

int pref(Nod *i, string s, int k=-1){
    if (i==NULL)
        return 0;
    if (k!=-1 && i->pre==0)
        return 0;
    if (k==s.size()-1)
        return 1;

    return 1+pref(i->next[s[k+1]-'a'], s, k+1);
}

int main()
{
    ifstream cin ("trie.in");
    ofstream cout ("trie.out");

    int op;
    string s;

    while (cin >> op){
        cin >> s;
        if (op==0)
            ins(t, s);
        else if (op==1)
            eras(t, s);
        else if (op==2)
            cout << query(t, s) << '\n';
        else
            cout << pref(t, s)-1 << '\n';
    }

    return 0;
}
