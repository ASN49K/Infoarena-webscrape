#include <bits/stdc++.h>
#define readFast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fin cin
#define ll long long
#define sz(x) (int)(x).size()
#define all(v) v.begin(), v.end()
#define output(x) ((int)x && cout << "YES\n") || cout << "NO\n";
#define LSB(x) ((-x)&x)
using namespace std;

#ifdef LOCAL
#define read() ifstream fin("date.in.txt")
#else
#define read() ifstream fin("trie.in"); ofstream fout("trie.out");
#endif // LOCAL

#define cifra(a) a - 'a'

const int N = 26;

int op;
string w;

struct trie {
    int cuv, prf;
    trie *fiu[N];

    trie() {
        cuv = prf = 0;
        memset(fiu, 0, sizeof(fiu));
    }
};
trie *T = new trie;

void add(trie *nod, int p) {
    int x = w[p] - 'a';

    if(p == sz(w)) {
        nod -> cuv++;
        return;
    }
    if(nod -> fiu[x] == 0) {
        nod -> fiu[x] = new trie;
        nod -> prf++;
    }

    add(nod -> fiu[x], p + 1);
}

int del(trie *nod, int p) {
    int x = w[p] - 'a';

    if(p == sz(w)) {
        nod -> cuv--;
    }
    else if(del(nod -> fiu[x], p + 1)) {
        nod -> fiu[x] = 0;
        nod -> prf--;
    }

    if(nod -> cuv == 0 && nod -> prf == 0 && nod != T) {
        delete nod;
        return 1;
    }
    return 0;
}

int counter(trie *nod, int p) {
    int x = w[p] - 'a';

    if(p == sz(w))
        return nod -> cuv;

    if(nod -> fiu[x])
        return counter(nod -> fiu[x], p + 1);
    return 0;
}

int prf(trie *nod, int p, int k) {
    int x = w[p] - 'a';

    if(p == sz(w) || nod -> fiu[x] == 0)
        return k;
    return prf(nod -> fiu[x], p + 1, k + 1);
}

int main() {
    read();


    while(fin >> op >> w) {
        if(op == 0) {
            add(T, 0);
        }
        else if(op == 1) {
            del(T, 0);
        }
        else if(op == 2) {
            fout << counter(T, 0) << '\n';
        }
        else {
            fout << prf(T, 0, 0)<< '\n';
        }
        //cout << "works\n";
    }

    return 0;
}  /*stuff you should look for
	* int overflow, array bounds
	* special cases (n=1?)
	* do smth instead of nothing and stay organized
	* WRITE STUFF DOWN
	* DON'T GET STUCK ON ONE APPROACH
~Benq~*/
