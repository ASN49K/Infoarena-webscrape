#include <fstream>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie{
    trie *leg[26];
    int nrfii,fr;
    trie(){
        for(int i=0;i<26;i++)
            leg[i] = nullptr;
        nrfii = fr = 0;
    }
};
trie *root = new trie;
string s;

void add(trie *node, int pos){
    if(pos == (int)s.size()){
        node->fr++;
        return;
    }
    int ch = (int)(s[pos]-'a');
    trie a;
    if(!node->leg[ch]){
        node->leg[ch] = &a;
        node->nrfii++;
    }
    add(node->leg[ch],pos+1);
}
bool dell(trie *node, int pos){
    if(pos == (int)s.size())
        node->fr--;
    else{
        int ch = (int)(s[pos]-'a');
        if(dell(node->leg[ch], pos+1)){
            node->nrfii--;
            node->leg[ch] = nullptr;
        }
    }
    if(node->fr == 0 && node->nrfii == 0 && node!=root){
        delete node;
        return 1;
    }
    return 0;
}
int srch(trie *node, int pos){
    if(pos == (int)s.size())
        return node->fr;
    int ch = (int)(s[pos]-'a');
    if(!node->leg[ch])
        return 0;
    return srch(node->leg[ch],pos+1);
}
int length(trie *node, int pos){
    if(pos == (int)s.size())
        return pos;
    int ch = (int)(s[pos]-'a');
    if(!node->leg[ch])
        return pos;
    return length(node->leg[ch],pos+1);
}

int main()
{
    int type;
    bool ok;
    while(fin >> type >> s){
        if(type == 0)
            add(root,0);
        else if(type == 1)
            ok = dell(root,0);
        else if(type == 2)
            fout << srch(root,0) << '\n';
        else
            fout << length(root,0) << '\n';
    }
    return 0;
}
