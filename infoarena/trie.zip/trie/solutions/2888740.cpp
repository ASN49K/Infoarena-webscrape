#include <iostream>
#include <map>
#include <fstream>

using namespace std;

struct node {
    map<char, node> x;
    int cnt = 0, cnt1 = 0;

    void Insert(const string& s, int i) {
        ++cnt1;
        if (i == s.length()) ++cnt;
        else x[s[i]].Insert(s, i + 1);
    }

    void Delete(const string& s, int i) {
        --cnt1;
        if (i == s.length()) --cnt;
        else x[s[i]].Delete(s, i + 1);
    }
    
    int Number(const string& s, int i) {
        if (i == s.length()) return cnt;
        if (x.count(s[i])) return x[s[i]].Number(s, i + 1);
        return 0;
    }

    int Prefix(const string& s, int i) {
        if (i < s.length() && x.count(s[i]) && x[s[i]].cnt1 != 0) return x[s[i]].Prefix(s, i + 1) + 1;
        return 0;
    }
};

int main(){
    ifstream F("trie.in");
    ofstream Fo("trie.out");

    int t;
    string s;
    node root;

    while (F >> t >> s) {
        if (t == 0) root.Insert(s, 0);
        else if (t == 1) root.Delete(s, 0);
        else if (t == 2) Fo << root.Number(s, 0) << '\n';
        else Fo << root.Prefix(s, 0) << '\n';
    }
    return 0;
}
