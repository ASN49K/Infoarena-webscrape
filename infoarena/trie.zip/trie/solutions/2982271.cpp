#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <cctype>
#include <unordered_map>
#include <cmath>
#include <bitset>
#include <string>
#include <cstring>
#include <algorithm>
using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");
int a,b,c,d,e,f,g,i,j,k,l,m,n,o,q,r,s,S,t,T,x,y,z,ok,nr,w,C,k1,k2,poz,pas,Max,mid,nways,MOD;
map <string,int>M;
map <string,int>pref;
string str,aux;
int main()
{
   while(in>>x>>str){
    if(x==0){
        M[str]++;
        n=str.size();
        aux.clear();
        for(i=0;i<n;i++){
            aux=aux+str[i];
            pref[aux]++;
        }
    }
    if(x==1){
        M[str]--;
   if(M[str]==0) {M.erase(M.find(str));}
      aux.clear();
      n=str.size();
      for(i=0;i<n;i++){
        aux=aux+str[i];
        pref[aux]--;
        if(pref[aux]==0) {pref.erase(pref.find(aux));}
      }
    }
    if(x==2){
            if(M.find(str)==M.end()) {out<<0<<'\n';}
        else {out<<M[str]<<'\n';}
    }
    if(x==3){
         n=str.size()-1;
        aux=str;
        for(i=n;i>=0;i--){
            if(pref.find(aux)!=pref.end()) {out<<i+1<<'\n'; break;}
            aux.pop_back();
            if(i==0) {out<<0<<'\n';}
        }
    }

   }
   return 0;
}
