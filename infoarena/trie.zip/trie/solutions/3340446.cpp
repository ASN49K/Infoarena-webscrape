/*
    Author: Paul Ciumandru
    Hard work beats talent!
*/
#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#include <bits/stdc++.h>

using namespace std;

#define NMAX 100000
#define MMAX 50000
#define PMAX 524288
#define LOG 18
#define INF_INT 2e9
#define INF_LL 1e18
#define BS 666013
#define MOD 1000000007

#define debug(x) cout << #x << " = " << x << "\n";
#define vdebug(a) cout << #a << " = "; for(auto x: a) cout << x << " "; cout << "\n";

#define ll long long
#define ull unsigned long long
#define dbl double
#define ldb long double
#define pii pair<int, int>
#define pll pair<ll, ll>
#define piv pair<int, vector<int>>
#define pipii pair<int, pair<pii, pii>>
#define tpl tuple<int, int, int>
#define tpl2 tuple<int, int, vector<int>>
#define vpi vector<pii>

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Node {
    unordered_map<char, int> mp;
    int cnt = 0, nr = 0;
};
vector<Node> Trie{1};

int op;
string s;

void insert(const string &s) {
    int node = 0;

    for (char ch : s) {
        if (!Trie[node].mp.count(ch)) {
            Trie[node].mp[ch] = Trie.size();
            Trie.push_back({});
        }
        node = Trie[node].mp[ch];
        Trie[node].nr++;
    }
    Trie[node].cnt++;
}

void erase(const string &s) {
    int node = 0;

    for (char ch : s) {
        node = Trie[node].mp[ch];
        Trie[node].nr--;
    }

    Trie[node].cnt--;
    node = 0;
    for (char ch : s) {
        if (!Trie[Trie[node].mp[ch]].nr) {
            Trie[node].mp.erase(ch);
            return;
        }
        node = Trie[node].mp[ch];
    }
}

int cnt_word(const string &s) {
    int node = 0;

    for (char ch : s) {
        if (!Trie[node].mp.count(ch)) {
            return 0;
        }
        node = Trie[node].mp[ch];
    }
    return Trie[node].cnt;
}

int lcp(const string &s) {
    int node = 0, lg = 0;

    for (char ch : s) {
        if (!Trie[node].mp.count(ch)) {
            return lg;
        }
        node = Trie[node].mp[ch];
        lg++;
    }
    return lg;
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    while (fin >> op >> s) {
        if (op == 0) {
            insert(s);
        }
        else if (op == 1) {
            erase(s);
        }
        else if (op == 2) {
            fout << cnt_word(s) << "\n";
        }
        else {
            fout << lcp(s) << "\n";
        }
    }
    return 0;
}