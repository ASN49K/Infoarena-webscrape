#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream f("trie.in");
ofstream g ("trie.out");
struct nod{
    int fr_cuvinte,prefixe;
    nod *copii[30];

    nod()
    {
        fr_cuvinte = 0;
        prefixe = 0;
        for(int i = 0;i<30;i++)
            copii[i] = NULL;
    }
}*rad;
void adaugare(nod *curent,int indice,int lungime,char cuvant[])
{
    curent->prefixe++;
    if(indice == lungime)
    {
        curent->fr_cuvinte++;
        return;
    }

    int lit =cuvant[indice]-'a';
    if(curent->copii[lit]==NULL)
     curent->copii[lit] = new nod();
    adaugare(curent->copii[lit],indice+1,lungime,cuvant);
}
void stergere(nod *curent,int indice,int lungime,char cuvant[])
{
    curent->prefixe--;
    if(indice == lungime)
    {
        curent->fr_cuvinte--;

        return;
    }

    int lit =cuvant[indice]-'a';
    stergere(curent->copii[lit],indice+1,lungime,cuvant);
}
int numarare(nod *curent,int indice,int lungime,char cuvant[])
{
    if(indice == lungime)
    {
        return curent->fr_cuvinte;
    }

    int lit =cuvant[indice]-'a';

    if(curent->copii[lit] ==NULL || curent->copii[lit]->prefixe == 0)
        return 0;

    numarare(curent->copii[lit],indice+1,lungime,cuvant);
}
int gasire_prefix(nod *curent,int indice,int lungime,char cuvant[])
{
    if(indice==lungime)
    {
        return lungime;
    }

    int lit =cuvant[indice]-'a';

    if(curent->copii[lit] == NULL || curent->copii[lit]->prefixe ==0)
        return indice;
    gasire_prefix(curent->copii[lit],indice+1,lungime,cuvant);


}
int main()
{
    int c;
    char cuv[21];
    rad = new nod();
    while(f>>c>>cuv)
    {
        if(c == 0)
            {
                adaugare(rad,0,strlen(cuv),cuv);
            }
        if(c==2)
        {
             g<< numarare(rad,0,strlen(cuv),cuv)<<'\n';
        }
        if(c==1)
        {
            stergere(rad,0,strlen(cuv),cuv);
        }
        if(c==3)
        {
            g<< gasire_prefix(rad,0,strlen(cuv),cuv)<<'\n';
        }
        cout << c<< " "<<cuv<< endl;
    }
}
