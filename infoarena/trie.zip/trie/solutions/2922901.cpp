#include <bits/stdc++.h>
using namespace std;
const int SIGMA = 26;

ifstream fin( "trie.in" );
ofstream fout( "trie.out" );

struct Node {
  Node* edges[SIGMA];
  int value, pref;

  Node() {
    value = pref = 0;
    for( int i = 0; i < 26; i++ )
      edges[i] = NULL;
  }

  inline Node* getEdge(char c) {
    return edges[c - 'a'] ? edges[c - 'a'] : NULL;
  }

  inline Node* addEdge(char c) {
    if (edges[c - 'a'] == NULL)
      edges[c - 'a'] = new Node();
    edges[c - 'a']->pref++;
    return edges[c - 'a'];
  }

  inline Node* delEdge(char c) {
    edges[c - 'a']->pref--;
    return edges[c - 'a'];
  }
};

Node* root = new Node;
void addWord( const char* word ) {
  int i;
  Node* node = root;
  i = 0;
  while( word[i] )
    node = node->addEdge( word[i++] );
  node->value++;
}

void delWord( const char*word ) {
  int i;
  Node* node = root;
  i = 0;
  while( word[i] )
    node = node->delEdge( word[i++] );
  node->value--;
}

int aparitii( const char*word ) {
  int i;
  Node* node = root;
  i = 0;
  while( word[i] && node != NULL )
    node = node->getEdge( word[i++] );
  if( node == NULL )
    return 0;
  return node->value;
}

int prefix( const char*word ) {
  int i, len;
  Node* node = root;
  i = len = 0;
  while( word[i] && node != NULL && node->pref != 0 ) {
    node = node->getEdge( word[i++] );
    len++;
  }
  if( node == NULL || node-> pref == 0 )
    len--;
  return len;
}

char s[20];
int main() {
  int op;
  root->pref = 1;
  while( fin >> op >> s ) {
    if( op == 0 )
      addWord( s );
    else if( op == 1 )
      delWord( s );
    else if( op == 2 )
      fout << aparitii( s ) << "\n";
    else
      fout << prefix( s ) << "\n";
  }
  return 0;
}
