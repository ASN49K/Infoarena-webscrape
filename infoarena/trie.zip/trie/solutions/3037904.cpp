#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cmath>

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

InParser fin ("mindist.in");
ofstream fout ("mindist.out");

const int INF=2e9;
const int NMAX=5e4+5;

struct coords{
    int x;
    int y;
}v[NMAX];

int manhattan(coords a,coords b)
{
    return (int)abs(a.x-b.x)+(int)abs(a.y-b.y);
}

int main()
{
    int n,m,i,j;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i].x>>v[i].y;
        if(i==1)
        {
            fout<<0<<"\n";
            continue;
        }
        int best=INF;
        for(j=1;j<i;j++)
            best=min(best,manhattan(v[i],v[j]));
        fout<<best<<"\n";
    }
    return 0;
}
