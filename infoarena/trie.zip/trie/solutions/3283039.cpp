#include <iostream>
#include <fstream>
#include <vector>
#include <climits>

using namespace std;

struct Nod {
    vector<Nod*> copii;
    string cuvant;
    int aparitii;

    Nod(string cuvant) : copii(26, nullptr), aparitii(0), cuvant(cuvant) {}

    void adaugare(string sir) {
        if(sir.size()) {
            if(!copii[sir[0] - 'a']) {
                copii[sir[0] - 'a'] = new Nod(cuvant + sir[0]);
            }

            copii[sir[0] - 'a']->adaugare(sir.substr(1, sir.size()-1));
        } else {
            ++aparitii;
        }
    }

    bool suprimare(string sir) {
        if(sir.size()) {
            bool gol = copii[sir[0] - 'a']->suprimare(sir.substr(1, sir.size()-1));
            if(gol) {
                delete copii[sir[0] - 'a'];
                copii[sir[0] - 'a'] = nullptr;
            }
        } else {
            --aparitii;
        }
        int suma = 0, i;
        for(i=0; i<26; ++i) {
            if(copii[i]) {
                ++suma;
                break;
            }
        }
        if(!suma && aparitii <= 0) {
            return true;
        }
        return false;
    }

    int cautare(string sir) {
        if(sir.size()) {
            if(!copii[sir[0] - 'a']) {
                return 0;
            }
            return copii[sir[0] - 'a']->cautare(sir.substr(1, sir.size()-1));
        }
        return this->aparitii;
    }

    int prefix(string sir) {
        if(sir.empty()) {
            return 0;
        }
        if(!copii[sir[0] - 'a']) {
            return 0;
        }
        return copii[sir[0] - 'a']->prefix(sir.substr(1, sir.size()-1)) + 1;
    }
};

int main() {
    ifstream fin("trie.in");
    ofstream fout("trie.out");
    short int op;
    int contor;
    string cuvant;
    Nod radacina("");
    while(fin >> op) {
        fin >> cuvant;
        if(op == 0) {
            radacina.adaugare(cuvant);
        } else if(op == 1) {
            radacina.suprimare(cuvant);
        } else if(op == 2) {
            contor = radacina.cautare(cuvant);
            fout << contor << '\n';
        } else if(op == 3) {
            contor = radacina.prefix(cuvant);
            fout << contor << '\n';
        }
    }
    return 0;
}
