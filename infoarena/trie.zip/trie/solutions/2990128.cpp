#include <bits/stdc++.h>

using namespace std;
ifstream f("trie.in");
ofstream g("trie.out");
struct tNod
{
    int cnt;/// numara cate cuvinte se termina in nod
    int nr;/// numara cate cuvinte trec prin nod
    tNod *F[26];/// fii din nod pt fiecare litera
    tNod()///constructor implicit
    {
        cnt=0;
        nr=0;
        for(int i=0;i<26;i++)
            F[i]=NULL;
    }
};
char w[25];
int tip;
tNod *root;
int main()
{
    root = new tNod;
    while(f>>tip)
    {
        f>>w;
        if(tip==0)
        {
            tNod *aux=root;
            char *p=w;
            while(*p)
            {
                int i=*p-'a';
                if(aux->F[i]==NULL)aux->F[i]=new tNod;
                aux=aux->F[i];
                aux->nr++;
                p++;
            }
            aux->cnt++;
        }
        else if(tip==1)
        {
            tNod *aux=root;
            char *p=w;
            while(*p)
            {
                int i=*p-'a';
                aux=aux->F[i];
                aux->nr--;
                p++;
            }
            aux->cnt--;
        }
        else if(tip==2)
        {
            tNod *aux=root;
            char *p=w;
            while(*p)
            {
                int i=*p-'a';
                if(aux->F[i]==NULL)
                    break;
                if(aux->F[i]->nr==0)
                    break;
                aux=aux->F[i];
                p++;
            }
            if(*p==0)
                g<<aux->cnt<<'\n';
            else
                g<<"0\n";
        }
        else
        {
            int LG=0;
            tNod *aux=root;
            char *p=w;
            while(*p)
            {
                int i=*p-'a';
                if(aux->F[i]==NULL)
                    break;
                if(aux->F[i]->nr==0)
                    break;
                aux=aux->F[i];
                LG++;
                p++;
            }
            g<<LG<<"\n";
        }

    }
    return 0;
}
