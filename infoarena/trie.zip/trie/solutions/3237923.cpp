#include <bits/stdc++.h>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
struct nod {
    int info, nrcuvinte;
    nod* v[26];
    nod() {
        nrcuvinte=0;
        info=0;
        for (int i=0; i<=25; i++) v[i]=nullptr;
    }
};
nod* start=new nod();
void adauga(string s) {
    int n=s.size(), i;
    nod* curent=start;
    start->nrcuvinte++;
    for (i=0; i<=n-1; i++) {
        if (curent->v[s[i]-'a']==nullptr) {
            nod* urmator=new nod();
            curent->v[s[i]-'a']=urmator;
        }
        curent=curent->v[s[i]-'a'];
        curent->nrcuvinte++;
    }
    curent->info++;
}
void nr(string s) {
    int n=s.size(), i;
    nod* curent=start;
    for (i=0; i<=n-1; i++) {
        if (curent->v[s[i]-'a']!=nullptr) {
            curent=curent->v[s[i]-'a'];
        }
        else {
            fout<<0<<'\n';
            return;
        }
    }
    fout<<curent->info<<'\n';
}
void sterge(string s) {
    int n=s.size(), i;
    nod* curent=start;
    start->nrcuvinte--;
    for (i=0; i<=n-1; i++) {
        curent=curent->v[s[i]-'a'];
        curent->nrcuvinte--;
    }
    curent->info--;
}
void pref(string s) {
    int n=s.size(), i;
    nod* curent=start;
    for (i=0; i<=n-1; i++) {
        if (curent->nrcuvinte<2 || curent->v[s[i]-'a']==nullptr) {
            fout<<i<<'\n';
            return;
        }
        curent=curent->v[s[i]-'a'];
    }
    fout<<n<<'\n';
}
int main()
{
    int c;
    string s;
    while (fin>>c>>s) {
        if (c==0) adauga(s);
        if (c==1) sterge(s);
        if (c==2) nr(s);
        if (c==3) pref(s);
        cout<<1;
    }
    return 0;
}
