#include <fstream>
#include <set>
#include <string>
#include <vector>
#include <map>

using namespace std;

ifstream cin("trie.in");
ofstream cout("trie.out");

set<string> v;
map<string,int> app;

size_t longPre(const string& word) {
    size_t len = 0;
    for (const string& s : v) {
        size_t pref = 0;
        while (pref < word.size() && pref < s.size() && word[pref] == s[pref]) {
            pref++;
        }
        len = max(len, pref);
    }
    return len;
}

int main() {
    int x;
    string w;
    while (cin >> x >> w) 
    {
        if (x == 0) 
        {
            v.insert(w);
            app[w]++;
        }
        else if (x == 1) 
        {
            v.erase(w);
            app[w]--;
        }
        else if (x == 2) 
        {
            cout << app[w] << "\n";
        }
        else if (x == 3) 
        {
            cout << longPre(w) << "\n";
        }
    }
    return 0;
}
