#include <bits/stdc++.h>
using namespace std;

/**
TRIE
{1}
Este un arbore cu radacina in care muchiile
sunt etichetate.
*/

struct Nod
{
    int fr; /// de cate ori apare un cuvant
    int nrprefix;
    Nod *leg[26];
    /// leg[0] = 'a'
    /// leg[1] = 'b'
    /// ... leg[25] = 'z'
    Nod()
    {
        fr = nrprefix = 0;
        for (int i = 0; i < 26; i++)
            leg[i] = NULL;
    }
};

class Trie
{
protected:
    Nod *rad;
public:
    Trie()
    {
        rad = new Nod;
    }
    void Ad(string w)
    {
        int i, j;
        Nod *p, *q;
        p = rad;
        for (i = 0; i < w.length(); i++)
        {
            j = w[i] - 'a';
            if (p->leg[j] == NULL)
            {
                q = new Nod;
                p->leg[j] = q;
            }
            p = p->leg[j];
            p->nrprefix++;
        }
        p->fr++;
    }
    void Sterge(string w)
    {
        Nod *p = rad;
        int i, j;
        for (i = 0; i < w.length(); i++)
        {
            j = w[i] - 'a';
            p = p->leg[j];
            p->nrprefix--;
        }
        p->fr--;
    }
    int NrAp(string w)
    {
        Nod *p = rad;
        int i, j;
        for (i = 0; i < w.length(); i++)
        {
            j = w[i] - 'a';
            if (p->leg[j] == NULL) return 0;
            p = p->leg[j];
        }
        return p->fr;
    }

    int Prefix(string w)
    {
        Nod *p = rad;
        int i, j, len = 0;
        for (i = 0; i < w.length(); i++)
        {
            j = w[i] - 'a';
            if (p->leg[j] == NULL) return len;
            p = p->leg[j];
            if (p->nrprefix == 0) return len;
            len++;
        }
        return len;
    }
};

int main()
{
    ifstream fin("trie.in");
    ofstream fout("trie.out");
    Trie T;
    int op;
    string cuv;
    while (fin >> op >> cuv)
    {
        if (op == 0) T.Ad(cuv);
        else if (op == 1) T.Sterge(cuv);
        else if (op == 2)
            fout << T.NrAp(cuv) << "\n";
        else fout << T.Prefix(cuv) << "\n";
    }
    fout.close();
    fin.close();
    return 0;
}
