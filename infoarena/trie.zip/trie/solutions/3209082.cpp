#include <bits/stdc++.h>

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
unordered_map<string,int> mp;
char s[25],a[100005][25],aux[25];
int c,nr,maxim,cnt;
int main()
{
    while(fin>>c>>s){
        if(c==0){
            if(mp.find(s)==mp.end())
                strcpy(a[++nr],s);
            mp[s]++;
        }
        else
            if(c==1){
                mp[s]--;
        }
        else
            if(c==2)
        {
            if(mp[s]<0)
                fout<<0<<endl;
            else
                fout<<mp[s]<<endl;
        }
        else
            if(c==3){
                maxim=0;
                cnt=0;
                for(int j=1;j<=nr;j++)
                {
                    if(mp[a[j]]>0){
                    cnt=0;
                    for(int i=0;i<min(strlen(s),strlen(a[j]));i++)
                        if(s[i]==a[j][i]){
                            cnt++;
                        }
                        else
                            i=min(strlen(s),strlen(a[j]));
                    if(cnt>maxim)maxim=cnt;
                }
            }
            fout<<maxim<<endl;
        }
    }
    return 0;
}
