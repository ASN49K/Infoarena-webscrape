#include <bits/stdc++.h>
/// TONI BO$$ was here
/// #MLC

using namespace std;
struct Node
{
    int val = 0;
    int nrfii = 0;
    Node * _goto[26];
    Node ()
    {
        memset(_goto, 0, sizeof(_goto));
    }
};

Node * root = new Node;
string s;

void _insert(string &s)
{
    Node * curstate = root;
    for(auto it : s)
        if(curstate->_goto[it - 'a'] == 0)
            curstate->nrfii++, curstate = curstate->_goto[it - 'a'] = new Node;
        else
            curstate = curstate->_goto[it - 'a'];
    curstate->val++;
}

int _delete(int i, Node * curstate, string &s)
{
    if(i == s.size())
        curstate->val--;
    else
        if(_delete(i + 1, curstate->_goto[s[i] - 'a'], s))
            curstate->nrfii--, curstate->_goto[s[i] - 'a'] = 0;
    if(curstate->val == 0 && curstate != root && curstate->nrfii == 0)
    {
        delete curstate;
        return 1;
    }
    return 0;
}

int _occurences(string &s)
{
    Node * curstate = root;
    for(int i = 0; i < s.size(); i++)
        curstate = curstate->_goto[s[i] - 'a'];
    return curstate->val;
}

int _prefix(string &s)
{
    Node * curstate = root;
    int i, lg = 0;
    for(i = 0; i < s.size(); i++)
    {
        curstate = curstate->_goto[s[i] - 'a'];
        if(curstate == 0)
            break;
    }
    return i;
}

int main()
{
    int q;
    freopen("trie.in","r",stdin);
    freopen("trie.out","w",stdout);
    while(cin >> q)
    {
        cin >> s;
        switch(q)
        {
            case 0: _insert(s); break;
            case 1: _delete(0, root, s); break;
            case 2: printf("%d\n", _occurences(s)); break;
            case 3: printf("%d\n", _prefix(s)); break;
        }
    }

    return 0;
}
