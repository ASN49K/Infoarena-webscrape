#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

class Trie
{
public:
    int val = 0, nrNext = 0;
    vector<Trie *> next;

    Trie()
    {
        next.resize(30);

        for (int i = 0; i < 26; i++)
            next[i] = NULL;
    }

    void insert(char *s, int len)
    {
        if (len == 0)
        {
            val++;
            return;
        }

        if (next[s[0] - 'a'] == NULL)
        {
            next[s[0] - 'a'] = new Trie;
            nrNext++;
        }
        next[s[0] - 'a']->insert(s + 1, len - 1);
    }

    bool erase(char *s, int len)
    {
        if (len == 0)
        {
            val--;
            return (val == 0 && nrNext == 0);
        }

        if (next[s[0] - 'a']->erase(s + 1, len - 1))
        {
            delete next[s[0] - 'a'];
            next[s[0] - 'a'] = NULL;
            nrNext--;
            return (val == 0 && nrNext == 0);
        }
        return false;
    }

    int count(char *s, int len)
    {
        if (len == 0)
            return val;
        if (next[s[0] - 'a'] != NULL)
            return next[s[0] - 'a']->count(s + 1, len - 1);
        return 0;
    }

    int maxSuf(char *s, int len, int res)
    {
        if (len == 0)
            return res;
        if (next[s[0] - 'a'] != NULL)
            return max(res + 1, next[s[0] - 'a']->maxSuf(s + 1, len - 1, res + 1));
        return 0;
    }
};

int main()
{
    Trie *head = new Trie;
    char s[30];
    int q;

    while (fin >> q >> s)
        switch (q)
        {
        case 0:
            head->insert(s, strlen(s));
            break;

        case 1:
            head->erase(s, strlen(s));
            break;

        case 2:
            fout << head->count(s, strlen(s)) << "\n";
            break;

        case 3:
            fout << head->maxSuf(s, strlen(s), 0) << "\n";
            break;
        }

    return 0;
}