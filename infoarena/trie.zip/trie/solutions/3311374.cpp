#include <bits/stdc++.h>
#define cin ci
#define cout co
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
int c;
string s;
struct Node
{
    int apps = 0, fin = 0;
    vector<Node*> sons;
    Node():sons(26) {}
    ~Node()
    {
        for(int i=0; i<26; i++)
            if(this->sons[i] != nullptr)
                delete this->sons[i];
    }
};
void add(Node *&trie, int pos)
{
    trie->apps++;
    if(pos == s.size())
        trie->fin++;
    if(pos < s.size())
    {
        int next = s[pos] - 'a';
        if(trie->sons[next] == nullptr)
            trie->sons[next] = new Node;
        add(trie->sons[next], pos + 1);
    }
}
void rem(Node *&trie, int pos)
{
    if(!trie) return;
    trie->apps--;
    if(pos == s.size())
        trie->fin--;
    else
    {
        int next = s[pos] - 'a';
        rem(trie->sons[next], pos + 1);

        if(trie->sons[next]->apps == 0)
        {
            delete trie->sons[next];
            trie->sons[next] = nullptr;
        }
    }
}
void numapps(Node *&trie, int pos)
{
    if(!trie) {
        cout << 0 << '\n';
        return;
    }
    if(pos == (int)s.size()) {
        cout << trie->fin << '\n';
        return;
    }
    int next = s[pos] - 'a';
    numapps(trie->sons[next], pos + 1);
}

int maxi = 0;
void query(Node *&trie, int pos)
{
    if(!trie) return;
    maxi = max(maxi, pos);
    if(pos < s.size())
    {
        int next = s[pos] - 'a';
        if(trie->sons[next] != nullptr)
            query(trie->sons[next], pos + 1);
    }

}
int main()
{
    Node *trie = new Node;
    while(cin >> c)
    {
        cin >> s;
        if(c == 0)
            add(trie, 0);
        else if(c == 1)
            rem(trie, 0);
        else if(c == 2)
            numapps(trie, 0);
        else
        {
            maxi = 0;
            query(trie, 0);
            cout << maxi << '\n';
        }
    }
    return 0;
}
