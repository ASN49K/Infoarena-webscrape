#include <bits/stdc++.h>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

class Trie {
    struct Nod {
        unordered_map<char, Nod*> copii;
        int cnt = 0;

        ~Nod() {
            for (pair<const char, Nod*>& p : copii)
                delete p.second;
        }
    };

    Nod* root;

public:
    Trie() {
        root = new Nod();
    }

    ~Trie() {
        delete root;
    }

    void insert(const string& s) {
        Nod* cur = root;

        for (char c : s) {
            if (!cur->copii[c])
                cur->copii[c] = new Nod();

            cur = cur->copii[c];
        }

        cur->cnt++;
    }

    int count(const string& s) const {
        Nod* cur = root;

        for (char c : s) {
            auto it = cur->copii.find(c);

            if (it == cur->copii.end())
                return 0;

            cur = it->second;
        }

        return cur->cnt;
    }

    int longest_prefix(const string& s) const {
        Nod* cur = root;
        int len = 0;

        for (char c : s) {
            auto it = cur->copii.find(c);

            if (it == cur->copii.end())
                break;

            cur = it->second;
            len++;
        }

        return len;
    }

    void erase(const string& s) {
        erase(root, s, 0);
    }

    bool erase(Nod* cur, const string& s, unsigned long i) {
        if (i == s.size()) {
            if (cur->cnt)
                cur->cnt--;

            return ((cur->cnt) == 0 && (cur->copii).empty());
        }

        auto it = cur->copii.find(s[i]);

        if (it == cur->copii.end())
            return false;

        if (erase(it->second, s, i + 1)) {
            delete it->second;
            cur->copii.erase(it);
        }

        if (cur == root) return false;

        return (((cur->cnt == 0)) && ((cur->copii).empty()));
    }
};

int main() {
    Trie trie;

    int k;
    char s[20];

    while (fin>>k) {
        fin>>s;
        if (k==0) {
            trie.insert(s);
        }
        else if (k==1) {
            trie.erase(s);
        }
        else if (k==2) {
            fout<<trie.count(s)<<"\n";
        }
        else if (k==3) {
            fout<<trie.longest_prefix(s)<<"\n";
        }
    }

    fin.close();
    fout.close();

    return 0;
}
