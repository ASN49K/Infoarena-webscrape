#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>

///#include <tryhardmode>
///#include <GOMDODE::ON>

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

const int NMAX=1e6+5;

int alpha;
int t[NMAX][26];
int frecv[NMAX];
int cuv[NMAX];
int words[NMAX];
int kon=2;

void add_string(string s)
{
    int n,p=1,i;
    n=s.size();
    for(i=0;i<n;i++)
    {
        if(t[p][s[i]-'a']==0)
        {
            t[p][s[i]-'a']=kon;
            kon++;
        }
        p=t[p][s[i]-'a'];
        frecv[p]++;
    }
    cuv[p]++;
}

void remove_string(string s)
{
    int n,p=1,i;
    n=s.size();
    for(i=0;i<n;i++)
    {
        p=t[p][s[i]-'a'];
        frecv[p]--;
    }
    cuv[p]--;
}

int freq(string s)
{
    int i,p=1,n;
    n=s.size();
    for(i=0;i<n;i++)
    {
        if(frecv[t[p][s[i]-'a']]==0)
            return 0;
        p=t[p][s[i]-'a'];
    }
    return cuv[p];
}

int lcp(string s)
{
    int i,p=1,n;
    int poz=0;
    n=s.size();
    for(i=0;i<n;i++)
    {
        if(frecv[t[p][s[i]-'a']]==0)
            return poz;
        else
        {
            poz++;
            p=t[p][s[i]-'a'];
        }
    }
    return poz;
}

void trie_dfs(int p,int lvl)
{
    int i;
    for(i=0;i<alpha;i++)
    {
        if(t[p][i]==0)
            words[lvl]++;
        else
            if(cuv[t[p][i]]==0)
                trie_dfs(t[p][i],lvl+1);
    }
}
int main()
{
    int t,i,j;
    while(fin>>t)
    {
        string s;
        fin>>s;
        if(t==0)
            add_string(s);
        else if(t==1)
            remove_string(s);
        else if(t==2)
            cout<<freq(s)<<"\n";
        else
            cout<<lcp(s)<<"\n";
    }
    return 0;
}
