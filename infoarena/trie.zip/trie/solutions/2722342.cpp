#include <bits/stdc++.h>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct trie
{
    int words,prefixes,next[51];
};

vector<trie>v;
trie zero;
int cerinta,t,n;
char s[51];

void update(int poz_trie, int poz_string, int val)
{
    v[poz_trie].prefixes+=val;
    if(poz_string==n)v[poz_trie].words+=val;
    else
    {
        int next_indice=s[poz_string]-'a';
        if(v[poz_trie].next[next_indice]==0)
        {
            v.push_back(zero);
            t++;
            v[poz_trie].next[next_indice]=t;
        }
        update(v[poz_trie].next[next_indice],poz_string+1,val);
    }
}

int query1()
{
    int i,next_indice,poz_trie=0;
    for(i=0;i<n;i++)
    {
        next_indice=s[i]-'a';
        if(v[poz_trie].next[next_indice]==0)return 0;
        else poz_trie=v[poz_trie].next[next_indice];
    }
    return v[poz_trie].words;
}

int query2()
{
    int i,next_indice,poz_trie=0;
    for(i=0;i<n;i++)
    {
        next_indice=s[i]-'a';
        if(v[poz_trie].next[next_indice]==0 || v[v[poz_trie].next[next_indice]].prefixes<=0)return i;
        else poz_trie=v[poz_trie].next[next_indice];
    }
    return n;
}

int main()
{
    t=0;
    v.push_back(zero);

    while(f>>cerinta>>s)
    {
        n=strlen(s);
        if(cerinta==0)update(0,0,1);
        else if(cerinta==1)update(0,0,-1);
        else if(cerinta==2)g<<query1()<<'\n';
        else g<<query2()<<'\n';
    }
    return 0;
}
