#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
struct Trie{
    int nr_ap,nr_fii;
    Trie*fii[26];
    Trie()
    {
        nr_ap=0;
        nr_fii=0;
        memset(fii,NULL,sizeof(fii));
    }
};
Trie*ROOT=new Trie();
inline int ord(char*s)
{
    return *s-97;
}
void insert(Trie*r,char*s)
{
    if(*s==NULL)
    {r->nr_ap++;return;}
    else{
        if(r->fii[ord(s)]==nullptr)
            r->fii[ord(s)]=new Trie(),r->nr_fii++;
        insert(r->fii[ord(s)],s+1);
    }
}
bool del(Trie*r,char*s)
{
    if(*s==NULL)
        r->nr_ap--;
    else if(del(r->fii[ord(s)],s+1))
    {
        r->nr_fii--;
        r->fii[ord(s)]=nullptr;
    }
    if(r!=ROOT&&r->nr_fii==0&&r->nr_ap==0)
    {
        delete r;
        return true;
    }
    return false;
}
int query(Trie*r,char*s)
{
    if(*s==NULL)
        return r->nr_ap;
    if(r->fii[ord(s)]!=nullptr)
        return query(r->fii[ord(s)],s+1);
    else return 0;
}
int prefix(Trie*r,char*s,int k)
{
    if(*s==NULL||r->fii[ord(s)]==nullptr)
        return k;
    return prefix(r->fii[ord(s)],s+1,k+1);
}
int main()
{
    ifstream f;
    f.open("trie.in",ios::in);
    ofstream g;
    g.open("trie.out",ios::out);
    char*linie=new char[30];
    while(!f.eof())
    {
        f.getline(linie,30,'\n');
        switch(linie[0])
        {
            case '0':{
                insert(ROOT,linie+2);
            }break;
            case '1':{
                del(ROOT,linie+2);
            }break;
            case '2':{
                g<<query(ROOT,linie+2)<<'\n';
            }break;
            case '3':{
                g<<prefix(ROOT,linie+2,0)<<'\n';
            }
        }
    }
    f.close();
    g.close();
    return 0;
}