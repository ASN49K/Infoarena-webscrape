#include <fstream>
#include <vector>
#include <queue>
#include <deque>
using namespace std;
using pii = pair<int,int>;
ifstream cin("trie.in");
ofstream cout("trie.out");
struct trie
{
    trie *next[26] = {nullptr};
    int nrd = 0 , e = 0;
    void add(int poz , string &s)
    {
        if(poz == s.size())
        {
            e++;
            return;
        }
        if(next[s[poz]-'a'] == NULL) next[s[poz]-'a'] = new trie;
        next[s[poz]-'a']->nrd++;
        next[s[poz]-'a']->add(poz+1,s);
    }
    void del(int poz , string &s)
    {
        if(poz == s.size())
        {
            e--;
            return;
        }
        next[s[poz]-'a']->del(poz+1,s);
        next[s[poz]-'a']->nrd--;
        if(next[s[poz]-'a']->nrd == 0) next[s[poz]-'a'] = NULL;
    }
    int nrapp(int poz , string &s)
    {
        if(poz == s.size()) return e;
        if(next[s[poz]-'a'] == NULL) return 0;
        return next[s[poz]-'a']->nrapp(poz+1,s);
    }
    int lcp(int poz , string &s)
    {
        if(next[s[poz]-'a'] != NULL) return 1 + next[s[poz]-'a']->lcp(poz+1,s);
        else return 0;
    }
}t;
int num;
string a;
signed main()
{
    while(cin >> num)
    {
        cin >> a;
        if(!num) t.add(0,a);
        if(num == 1) t.del(0,a);
        if(num == 2) cout << t.nrapp(0,a) << '\n';
        if(num == 3) cout << t.lcp(0,a) << '\n';
    }
    return 0;
}

