#include <bits/stdc++.h>
#define SIGMA 30
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    struct Node
    {
        int cnt, rasp;
        Node *fii[SIGMA];
    };

    Node *root = new Node();

    inline void add(char *s, Node *poz)
    {
        poz->cnt++;
        if(*s == '\0')
        {
            poz->rasp++;
            return;
        }
        int x = *s - 'a';
        if(poz->fii[x] == NULL)
            poz->fii[x] = new Node();
        add(s + 1, poz->fii[x]);
    } 

    inline void rem(char *s, Node *poz)
    {
        poz->cnt--;
        if(*s == '\0')
        {
            poz->rasp--;
            return;
        }
        int x = *s - 'a';
        rem(s + 1, poz->fii[x]);
    }

    inline int search_1(char *s, Node *poz)
    {
        if(*s == '\0')
            return poz->rasp;
        int x = *s - 'a';
        return search_1(s + 1, poz->fii[x]);
    }

    inline int search_2(char *s, Node *poz)
    {
        int x = *s - 'a';
        if(*s == '\0' || poz->fii[x] == NULL || !poz->fii[x]->cnt)
            return 0;
        return search_2(s + 1, poz->fii[x]) + 1;
    }
};

int op;
char s[28];
Trie trie;

int main()
{
    ios::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    while(fin >> op >> s)
    {
        if(op == 0)
        {
            trie.add(s, trie.root);  
        }
        if(op == 1)
        {
            trie.rem(s, trie.root);
        }
        if(op == 2)
        {
            fout << trie.search_1(s, trie.root) << '\n';
        }
        if(op == 3)
        {
            fout << trie.search_2(s, trie.root) << '\n';
        }
        memset(s, 0, sizeof(s));
    }
}