#include <bits/stdc++.h>
#define pb push_back
#define pf push_front
#define ll long long
#define ull unsigned long long
#define pii pair<int,int>
#define pll pair<ll,ll>
#define EPSILON 0.000001

using namespace std;

const ll NMAX = 1e5 + 5, INF = 1e18, MOD = 666013, MMAX = 1e2 + 5, inf = INT_MAX;


ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    int nrCuv, nrFii;
    Trie *Fiu[26];

    Trie()
    {
        nrCuv = nrFii = 0;
        for(int i = 0; i < 26; i++)
        {
            Fiu[i] = NULL;
        }
    }
};

Trie *T;

void Add(Trie *nod, char *s)
{
    if(*s == '\0')
    {
        nod->nrCuv++;
    }
    else
    {
        int i = *s - 'a';
        if(nod->Fiu[i] == NULL)
        {
            nod->Fiu[i] = new Trie();
            nod->nrFii++;
        }
        Add(nod->Fiu[i], s + 1);
    }
}

int Lcp(Trie *nod, char *s, int k)
{
    if(*s == '\0')
        return k;
    int i = *s - 'a';
    if(nod->Fiu[i] == NULL || nod->nrFii < 2)
    {
        return k;
    }
    return Lcp(nod->Fiu[i], s + 1, k + 1);
}

int Count(Trie *nod, char *s)
{
    if(*s == '\0')
        return nod->nrCuv;
    int i = *s - 'a';
    if(nod->Fiu[i])
        return Count(nod->Fiu[i], s + 1);
    return 0;
}

bool Delete(Trie *nod, char *s)
{
    if(*s == '\0')
    {
        nod->nrCuv--;
    }
    else
    {
        int i = *s - 'a';
        if(Delete(nod->Fiu[i], s + 1))
        {
            nod->Fiu[i] = NULL;
            nod->nrFii--;
        }
    }
    if(nod->nrCuv == 0 && nod->nrFii == 0 && nod != T)
    {
        delete nod;
        return 1;
    }
    return 0;
}

int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);
    int op;
    char w[21];
    T = new Trie();
    while(fin >> op >> w)
    {
        switch(op)
        {
        case 0:
            Add(T, w);
            break;
        case 1:
            Delete(T, w);
            break;
        case 2:
            fout << Count(T, w) << '\n';
            break;
        case 3:
            fout << Lcp(T, w, 0) << '\n';
            break;
        }
    }
    return 0;
}
