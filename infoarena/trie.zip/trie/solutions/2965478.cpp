#include <fstream>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

int op;
string sir;

struct trie
{
    int cnt = 0, howMany = 0;
    trie* sons[26];

    trie(){
        for(int i = 0; i < 26; ++i)
            sons[i] = 0;
    }
};
trie* root = new trie();

void Insert(string s, trie* node, int pos){
    (*node).howMany++;

    if(pos == s.length()){
        (*node).cnt++;
        return;
    }

    if(node -> sons[s[pos] -'a'] == NULL)
        node -> sons[s[pos] -'a'] = new trie();
    
    Insert(s, node -> sons[s[pos] - 'a'], pos + 1);
}
void Delete(string s, trie* node, int pos){
    (*node).howMany--;

    if(pos == s.length()){
        (*node).cnt--;
        return;
    }

    if(node -> sons[s[pos] - 'a'] == NULL)
        return;

    Delete(s, node -> sons[s[pos] - 'a'], pos + 1);

    if(node -> sons[s[pos] - 'a'] -> howMany == 0 && pos > 0)
        delete node -> sons[s[pos] - 'a'];
}
int Query1(string s, trie *node, int pos){

    if(pos == s.length())
        return (*node).cnt;

    if(node -> sons[s[pos] - 'a'] != NULL)
        return Query1(s, node -> sons[s[pos] - 'a'], pos + 1);
    else return 0;
}
int Query2(string s, trie *node, int pos){
    if(pos == s.length())
        return pos;
    if(node -> sons[s[pos] - 'a'] == NULL || node -> sons[s[pos] - 'a'] -> howMany == 0){
        return pos;
    }
    return Query2(s, node -> sons[s[pos] - 'a'], pos + 1);
}
int main() {
    while(fin >> op){
        fin >> sir;

        if(op == 0)
            Insert(sir, root, 0);
        else if(op == 1)
            Delete(sir, root, 0);
        else if(op == 2)
            fout << Query1(sir, root, 0) << "\n";
        else fout << Query2(sir, root, 0) << "\n";
         
    }

    return 0;
}