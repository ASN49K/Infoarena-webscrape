#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
class trienode
{
public:
    trienode *urm[27];
    int cnt;
    int cuvinte_sub_el;
    trienode()
    {
        cnt=0;
        cuvinte_sub_el=0;
        for(int i=0;i<=26;i++)
        {
            urm[i]=nullptr;
        }
    }
    void insereaza(string &s, int poz)
    {
        cuvinte_sub_el++;
        if(s.size()==poz)
        {
            cnt++;
            return;
        }
        char litera_curenta=s[poz]-'a';
        if(urm[litera_curenta]==nullptr)
        {
            urm[litera_curenta]=new trienode();
        }
        urm[litera_curenta]->insereaza(s,poz+1);
    }
    void sterge(string& s, int poz)
    {
        cuvinte_sub_el--;
        if(s.size()==poz)
        {
            cnt--;
            return;
        }
        char litera_curenta=s[poz]-'a';
        urm[litera_curenta]->sterge(s,poz+1);
    }
    int nr_aparitii(string &s, int poz)
    {
        if(s.size()==poz)
        {
            return cnt;
        }
        char litera_curenta=s[poz]-'a';
        if(urm[litera_curenta]==nullptr)
        {
            return 0;
        }
        return urm[litera_curenta]->nr_aparitii(s,poz+1);
    }
    int lung_prefix(string &s, int poz)
    {
        if(s.size()==poz)
        {
            return s.size()-1;
        }
        char litera_curenta=s[poz]-'a';
        if(cuvinte_sub_el==0)
        {
            return (poz-1);
        }
        if(urm[litera_curenta]==nullptr)
        {
            return poz;
        }
        return urm[litera_curenta]->lung_prefix(s,poz+1);
    }
};
int main()
{
    int op;
    trienode primul;
    while(fin>>op)
    {
        string sir;
        fin>>sir;
        if(op==0)
        {
            primul.insereaza(sir,0);
        }
        else if(op==1)
        {
            primul.sterge(sir,0);
        }
        else if(op==2)
        {
            fout<<primul.nr_aparitii(sir,0)<<'\n';
        }
        else
        {
            fout<<primul.lung_prefix(sir,0)<<'\n';
        }
    }
    return 0;
}
