#include <bits/stdc++.h>
using namespace std;

int v[101];

struct Trie{
    int cntCuv;
    int cntCopii;
    int lit;
    Trie* fii[26];
    Trie* tata;
    Trie(){
        cntCuv = 0;
        lit = 0;
        cntCopii = 0;
        memset(fii, 0, sizeof(fii));
        tata = NULL;
    }
};

Trie *root = new Trie;

string s;

int main()
{
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);
    int t;
    while(!feof(stdin))
    {
        cin >> t >> s >> ws;
        if(t == 0)
        {
            Trie *nod = root;
            for(int i = 0; i < s.size(); i++)
            {
                if(nod->fii[s[i] - 'a'] == NULL)
                {
                    nod->cntCopii++;
                    nod->fii[s[i] - 'a'] = new Trie;
                    nod->fii[s[i] - 'a']->tata = nod;
                    nod->fii[s[i] - 'a']->lit = s[i] - 'a';
                }
                nod = nod->fii[s[i] - 'a'];
            }
            nod->cntCuv++;
        }
        else if(t == 1)
        {
            Trie *nod = root;
            for(int i = 0; i < s.size(); i++)
                nod = nod->fii[s[i] - 'a'];
            nod->cntCuv--;
            while(nod != root)
            {
                Trie *urm = nod->tata;
                int lit = nod->lit;
                if(nod->cntCuv == 0 && nod->cntCopii == 0)
                {
                    delete(nod);
                    urm->cntCopii--;
                    urm->fii[lit] = NULL;
                }
                nod = urm;
            }
        }
        else if(t == 2)
        {
            Trie *nod = root;
            for(int i = 0; i < s.size(); i++)
            {
                if(nod->fii[s[i] - 'a'] == NULL)
                {
                    cout << "0\n";
                    break;
                }
                nod = nod->fii[s[i] - 'a'];
                if(i == s.size() - 1)
                    cout << nod->cntCuv << '\n';
            }
        }
        else
        {
            Trie *nod = root;
            for(int i = 0; i < s.size(); i++)
            {
                if(nod->fii[s[i] - 'a'] == NULL)
                {
                    cout << i << '\n';
                    break;
                }
                nod = nod->fii[s[i] - 'a'];
                if(i == s.size() - 1)
                    cout << s.size() << '\n';
            }
        }
    }
    return 0;
}
