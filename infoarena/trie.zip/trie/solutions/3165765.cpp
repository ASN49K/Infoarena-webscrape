/*
    "care a facut teste cu Lattice reduction attack e ciudat"
    "linistiti va putin"
    - 2023 -
*/
#include<bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")

using namespace std;

struct Node
{
    int freq;
    int traffic;
    int muchii[27];
};

vector <Node> trie;
int sz;

string s;

void ins(int pos, int nodeidx)
{
    trie[nodeidx].traffic++;
    if (trie[nodeidx].muchii[s[pos]-'a'+1]==0)
    {
        sz++;
        trie[sz]={0,0,0};
        trie[nodeidx].muchii[s[pos]-'a'+1]=sz;
    }
    if (pos!=(s.size()))
    ins(pos+1,trie[nodeidx].muchii[s[pos]-'a'+1]);
    else
    trie[nodeidx].freq++;
}

void ers(int pos, int nodeidx)
{
     trie[nodeidx].traffic--;
     if (pos!=(s.size()))
     ers(pos+1,trie[nodeidx].muchii[s[pos]-'a'+1]);
     else
     trie[nodeidx].freq--;
}

int ans;

void app(int pos, int nodeidx)
{
    if (pos!=(s.size()) && trie[nodeidx].muchii[s[pos]-'a'+1]!=0)
    app(pos+1,trie[nodeidx].muchii[s[pos]-'a'+1]);
    else
    {
        if (trie[nodeidx].muchii[s[pos]-'a'+1]==0)
        ans=0;
        else
        ans=trie[nodeidx].freq;
        return;
    }
}

int lungime;

void lgpref(int pos, int nodeidx)
{
    if (trie[nodeidx].traffic>=1)
    lungime++;
    else
    return;
    if (pos!=(s.size()) && trie[nodeidx].muchii[s[pos]-'a'+1]!=0)
    lgpref(pos+1,trie[nodeidx].muchii[s[pos]-'a'+1]);
    else
    return;
}

int main()
{
    ifstream fin("trie.in");
    ofstream fout("trie.out");
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int type;
    sz=0;
    trie[0]={0,0,0};
    while (fin >> type  >> s)
    {
        if (type==0)
        {
            ins(0,0);
        }
        if (type==1)
        {
            ers(0,0);
        }
        if (type==2)
        {
            ans=0;
            app(0,0);
            fout << ans << "\n";
        }
        if (type==3)
        {
            lungime=-1;
            lgpref(0,0);
            fout << lungime << "\n";
        }
    }
}
