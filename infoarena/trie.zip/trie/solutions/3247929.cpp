#include <bits/stdc++.h>

#define VMAX 100000
#define NMAX 22

#define LOG 19
#define INF (long long)(1e9)
#define MOD 1000000007
#define ll long long int

#define ADD 1e9

#define NIL 0

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
    int cnt,nrfii;
    trie* fiu[26];

    trie()
    {
        memset(fiu,0,sizeof(fiu));
        cnt=nrfii=0;
    }
};
trie* root;
char s[NMAX+1];
int len;

void insertTrie(trie* nod,int j)
{
    if(j==len)
    {
        nod->cnt++;
        return;
    }
    int c = s[j]-'a';
    if(nod->fiu[c] == 0)
    {
        nod->fiu[c] = new trie;
        nod->nrfii++;
    }
    insertTrie(nod->fiu[c],j+1);
}
int deleteTrie(trie* nod,int j)
{

    if(j==len)
    {
        nod->cnt--;
    }
    else if(deleteTrie(nod->fiu[s[j]-'a'],j+1))
    {
        nod->fiu[s[j]-'a']=0;
        nod->nrfii--;
    }
    if(nod->cnt==0 && nod->nrfii==0 && nod!=root)
    {
        delete nod;
        return 1;
    }
    return 0;
}
int cntTrie(trie* nod , int j)
{
    if(j==len)
    {
        return nod->cnt;
    }
    int c = s[j]-'a';
    if(nod->fiu[c]==0)
    {
        return 0;
    }
    return cntTrie(nod->fiu[c],j+1);
}
int prefTrie(trie* nod , int j)
{
    if(j==len || nod->fiu[s[j]-'a']==0)
    {
        return j;
    }

    return prefTrie(nod->fiu[c],j+1);
}
int main()
{
    int t;
    root = new trie;
    while(fin >> t >> s)
    {
        len = strlen(s);
        if(t==0)
        {
            insertTrie(root,0);
        }
        else if(t==1)
        {
            deleteTrie(root,0);
        }
        else if(t==2)
        {
            fout << cntTrie(root,0) << "\n";
        }
        else if(t==3)
        {

            fout << prefTrie(root,0) << "\n";
        }

    }

}
