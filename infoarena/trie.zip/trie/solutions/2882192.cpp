#include <iostream>
#include <fstream>

using namespace std;

struct Nod
{
    int nrCuv, nrAp;
    Nod *F[26];

    Nod()
    {
        nrCuv = nrAp = 0;

        for ( int i = 0; i < 26; i++ )
            F[i] = NULL;
    }
};

Nod *Trie;

ifstream f ( "trie.in" );
ofstream g ( "trie.out" );

void Add ( char *s ) ///adaugare cuvant
{
    Nod *crt = Trie;

    for ( ; *s != '\0'; ++s )
    {
        int i = *s - 'a';

        if ( crt->F[i] == NULL )
        {
            crt->F[i] = new Nod();
        }

        crt = crt->F[i];
        crt->nrAp++;
    }

    crt->nrCuv++;
}

int Count ( char *s )
{
    Nod *crt = Trie;

    for ( ; *s != '\0'; ++s )
    {
        int i = *s - 'a';

        if ( crt->F[i] == NULL )
            return 0;

        crt = crt->F[i];
    }

    return crt->nrCuv;
}

void Delete ( char *s ) ///s apare cel putin o data in lista de cuvinte
{
    Nod *crt = Trie, *ant;

    for ( ; *s != '\0'; s++ )
    {
        int i = *s - 'a';
        ant = crt;
        crt = crt->F[i];
        crt->nrAp--;

        if ( ant->nrAp == 0 )
            delete ant;
        else
        {
            if ( crt->nrAp == 0 )
                ant->F[i] = NULL;
        }
    }

    crt->nrCuv--;

    if ( crt->nrAp == 0 )
    {
        delete crt;
    }
}

int Lcp ( char *s ) ///Lungimea celui mai lung prefix comun al lui s
{
    int i, lg = 0;
    Nod *crt = Trie;

    for ( ; *s != '\0' ; ++s )
    {
        i = *s - 'a';

        if ( crt->F[i] == NULL )
            return lg;

        ++lg;
        crt = crt->F[i];
    }

    return lg;
}

int main()
{
    int op;
    char w[21];
    Trie = new Nod();
    Trie->nrAp = 1; ///Cuvantul vid

    while ( f >> op >> w )
    {
        switch ( op )
        {
        case 0:
            Add ( w );
            break;

        case 1:
            Delete ( w );
            break;

        case 2:
            g << Count ( w ) << '\n';
            break;

        case 3:
            g << Lcp ( w ) << '\n';
        }
    }

    return 0;
}
