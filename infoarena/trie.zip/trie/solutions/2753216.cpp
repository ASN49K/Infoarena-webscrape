#include <iostream>
#include <fstream>
using namespace std;
ifstream f("disjoint.in");
ofstream g("disjoint.out");
int a[100005],b[100005],n,m,cod,tx,ty;
int rex(int x){
    if(b[x]!=x){
        rex(b[x]);
    }
    else tx=x;
    b[x]=tx;
}
int rey(int y){
    if(b[y]!=y){
        rey(b[y]);
    }
    else ty=y;
    b[y]=ty;
}
void reun(int x,int y){
    rex(x);
    rey(y);
    b[ty]=tx;
}
int verif(int x,int y){
    rex(x);
    rey(y);
    if(b[tx]==b[ty])return 1;
    return 0;
}
int main()
{
    int x,y;
    f>>n>>m;
    for(int i=1;i<=n;i++){
        b[i]=i;
    }
    for(int i=1;i<=m;i++){
        f>>cod>>x>>y;
        if(cod==1)reun(x,y);
        else{
            if(verif(x,y))g<<"DA\n";
        else g<<"NU\n";
        }
    }
    return 0;
}
