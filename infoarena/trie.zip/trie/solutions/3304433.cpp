#include <bits/stdc++.h>
#include <cstdlib>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("trie.in");
    ofstream fout("trie.out");
#endif  // ST_DIO

struct NodTrie {
    NodTrie* fii[32];
    int nrFii;
    int fr;
};
char s[22];
int op;

NodTrie* rad;

static inline bool FinalCar(char* c) {
    return (*c == '\0' || c == NULL);
}

static inline void InitNod(NodTrie* cur) {
    for(int i = 0; i < 26; i++) cur->fii[i] = NULL;
}

static inline void CleanNod(NodTrie* cur) {
    for(int i = 0; i < 26; i++) {
        if(cur->fii[i] != NULL) CleanNod(cur->fii[i]);
    }
    delete cur;
}

static inline void Insert(char* car, NodTrie* cur) {
    if(FinalCar(car)) {
        cur->fr++;
        return;
    }

    int carCur = *car - 'a';

    if(cur->fii[carCur] == NULL) {
        cur->fii[carCur] = new NodTrie;
        InitNod(cur->fii[carCur]);
        cur->nrFii++;
    }
    Insert(car + 1, cur->fii[carCur]);
}

static inline bool Delete(char* car, NodTrie* cur) {
    int carCur = *car - 'a';

    if(FinalCar(car)) cur->fr--;
    else if(Delete(car + 1, cur->fii[carCur])) {
        cur->fii[carCur] = NULL;
        cur->nrFii--;
    }

    if(cur->fr == 0 && cur->nrFii == 0 && cur != rad) {
        delete cur;
        return true;
    }

    return false;
}

static inline int GetNrApariti(char* car, NodTrie* cur) {
    int carCur = *car - 'a';

    if(FinalCar(car)) return cur->fr;
    else if(cur->fii[carCur] == NULL) return 0;

    return GetNrApariti(car + 1, cur->fii[carCur]);
}

static inline int GetLungMa(char* car, NodTrie* cur, int lung = 0) {
    int carCur = *car - 'a';

    if(FinalCar(car)) return lung;
    else if(cur->fii[carCur] == NULL) return lung;

    return GetLungMa(car + 1, cur->fii[carCur], lung + 1);
}

int main() {
    rad = new NodTrie();
    while(fin >> op >> s) {
        if(op == 0)      Insert(s, rad);
        else if(op == 1) Delete(s, rad);
        else if(op == 2) fout << GetNrApariti(s, rad)   << "\n";
        else             fout << GetLungMa(s, rad) << "\n";
    }

    delete rad;

    return 0;
}

