#define nr_lit 'z'-'a'+1 
#include<cstdio>
using namespace std;
struct varf{
	varf* fii[nr_lit];
	int frecv,nr_fii;
};
varf *t;
varf* creeaza_nod(){
	varf *t;
	int i;
	t=new varf;
	t->nr_fii=0;
	t->frecv=0;
	for(i=0;i<nr_lit;i++)
		t->fii[i]=NULL;
	return t;
}

void adauga(char w[21],varf *t){
 
	if(w[0]!=0){
		int lit=w[0]-'a';
		if (t->fii[lit]==NULL){
			t->fii[lit]=creeaza_nod();	
			t->nr_fii++;
		}
		adauga(w+1,t->fii[lit]);
	}
	else
		t->frecv++;
}
void adauga(char w[21]){
	adauga(w,t);
}

int sterge(char w[21],varf *&t){
	int lit=w[0]-'a';
	if(w[0]!=0){
		
		
		if (t->fii[lit]==NULL)
			return 0;
		int x=sterge(w+1,t->fii[lit]);
		if(x==1){
			t->fii[lit]=NULL;
			t->nr_fii--;
			if(t->frecv==0 && t->nr_fii==0){
				delete t;
				return 1;
			}
		}
		return 0;
	}
	else{
		t->frecv--;
		if(t->frecv==0 && t->nr_fii==0){
			delete t;
			return 1;
		}
		
	}
	return 0;
}

void sterge(char w[21]){
	sterge(w,t);
}


int nr_aparitii(char w[21],varf *t){

	int lit=w[0]-'a';
	if(w[0]!=0){
		
		if(t->fii[lit]==NULL)
			return 0;
		return nr_aparitii(w+1,t->fii[lit]);
	}
	else
		return t->frecv;
}

int nr_aparitii(char w[21]){
	return nr_aparitii(w,t);
}

int lungime_prefix_comun(char w[21], varf *t){
	
	
	if(w[0]!=0){
		int lit=w[0]-'a';
		if(t->fii[lit]==NULL)
			return 0;
		return 1+lungime_prefix_comun(w+1,t->fii[lit]);
	}
	else
		return 0;
}

int lungime_prefix_comun(char w[21]){
	return lungime_prefix_comun(w,t);
}

int main(){
	FILE *f,*g;
	f=fopen("trie.in","r");
	g=fopen("trie.out","w");
	int x;
	char w[21];
	t=creeaza_nod();
	while(!feof(f)){
		fscanf(f,"%d",&x);
		fscanf(f,"%s",w);
 
		switch(x){
			case 0: adauga(w);break;
			case 1: sterge(w);break;
			case 2: fprintf(g,"%d\n",nr_aparitii(w)); break;
			case 3: fprintf(g,"%d\n",lungime_prefix_comun(w));
		}
	}
	fclose(f);
	fclose(g);
	
}

