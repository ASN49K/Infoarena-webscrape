#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define NMAX 2000
#define INF 2e9
using namespace std;
ifstream f("pirati.in");
ofstream g("pirati.out");
struct Trie
{
    int cnt,nrfii;
    Trie *fiu[26];
    Trie()
    {
        cnt = nrfii = 0;
        memset( fiu, 0, sizeof( fiu ) );
    }
};
Trie *T= new Trie;
void ins(Trie *nod,char *s)
{
    if(*s=='\n')
    {
        nod->cnt++;
        return;
    }

    if(nod->fiu[*s-'a']==0)
    {
        nod->fiu[*s-'a']=new Trie;
        nod->nrfii++;
    }
    ins(nod->fiu[*s-'a'],s+1);

}
int del(Trie *nod,char *s)
{
    if(*s=='\n')
    {
        nod->cnt--;
    }
    else
    {
        if(del(nod->fiu[*s-'a'],s+1))
        {
            nod->fiu[*s-'a']=0;
            nod->nrfii--;
        }
    }
    if( nod->cnt == 0 && nod->nrfii == 0 && nod != T ) {
		delete nod; return 1;
	}
	return 0;
}
int freq(Trie *nod,char *s)
{
    if(*s=='\n')
    {
        return nod->cnt;
    }
    if(nod->fiu[*s-'a'])
    {
        return freq(nod->fiu[*s-'a'],s+1);
    }
    return 0;
}
int pref(Trie *nod,char *s,int k)
{
    if(*s=='\n'||nod->fiu[*s-'a']==0)
    {
        return k;
    }
    return pref(nod->fiu[*s-'a'],s+1,k+1);
}
int main()
{

char line[ 32 ];

	freopen( "trie.in", "r", stdin );
	freopen( "trie.out", "w", stdout );

	fgets( line, 32, stdin );

	while( !feof( stdin ) ) {
		switch( line[0] ) {
			case '0': ins( T, line+2 ); break;
			case '1': del( T, line+2 ); break;
			case '2': printf( "%d\n", freq( T, line+2 ) ); break;
			case '3': printf( "%d\n", pref( T, line+2, 0 ) ); break;
		}

		fgets( line, 32, stdin );
	}
	return 0;



}
