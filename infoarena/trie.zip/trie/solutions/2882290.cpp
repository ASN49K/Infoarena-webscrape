//Ilie Dumitru
#include<cstdio>
#include<cstring>
typedef long long int ll;
const int NMAX=2000005;

struct trie
{
    int nrK, ap;
    trie* next[26];
};

trie* T;

void init(trie* t)
{
    int i;
    for(i=0;i<26;++i)
        t->next[i]=0;
}

void insert(trie*& t, char* cuv)
{
    if(*cuv)
    {
        if(t)
        {
            t->nrK+=!(t->next[*cuv-'a']);
            insert(t->next[*cuv-'a'], cuv+1);
        }
        else
        {
            t=new trie;
            init(t);
            insert(t->next[*cuv-'a'], cuv+1);
            t->nrK=1;
            t->ap=0;
        }
    }
    else
    {
        if(t)
            t->ap++;
        else
        {
            t=new trie;
            init(t);
            t->ap=1;
            t->nrK=0;
        }
    }
}

void remove(trie*& t, char* cuv)
{
    if(*cuv)
    {
        remove(t->next[*cuv-'a'], cuv+1);
        t->nrK-=!(t->next[*cuv-'a']);
    }
    else
        t->ap--;
    if(!t->ap && !t->nrK)
    {
        delete t;
        t=0;
    }
}

int nrAp(trie* t, char* cuv)
{
    if(t)
    {
        if(*cuv)
            return nrAp(t->next[*cuv-'a'], cuv+1);
        return t->ap;
    }
    return 0;
}

int maxPref(trie* t, char* cuv)
{
    if(t)
    {
        if(*cuv)
            return maxPref(t->next[*cuv-'a'], cuv+1)+1;
        return -1;
    }
    return -1;
}

void clearTrie(trie*& t)
{
    if(t)
    {
        for(int i=0;i<26;++i)
            clearTrie(t->next[i]);
        delete t;
        t=0;
    }
}

int main()
{
    FILE* f=fopen("trie.in", "r"), *g=fopen("trie.out", "w");
    char row[30];
    int l;
    fgets(row, 30, f);
    do
    {
        l=strlen(row);
        if(row[l-1]=='\n')
            row[--l]=0;
        switch(*row)
        {
        case '0':
            insert(T, row+2);
            break;
        case '1':
            remove(T, row+2);
            break;
        case '2':
            fprintf(g, "%d\n", nrAp(T, row+2));
            break;
        case '3':
            fprintf(g, "%d\n", maxPref(T, row+2));
            break;
        }
        fgets(row, 30, f);
    }while(!feof(f));
    fclose(f);
    fclose(g);
    clearTrie(T);
    return 0;
}