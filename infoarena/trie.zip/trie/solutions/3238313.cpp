#include <bits/stdc++.h>

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
int tip;
string sir;

struct TrieNode {
    TrieNode* copil[26];
    bool finalCuvant;
    int nrCuvinte, cnt;
    TrieNode() {
        finalCuvant = false, nrCuvinte = cnt = 0;
        for(int i=0; i<26; i++) copil[i] = NULL;
    }
};

class Trie {
private:
    TrieNode* root;
public:
    Trie() { root = new TrieNode(); }
    void adaugareCuvant(string cuvant) {
        TrieNode* nod = root;
        for(char ch : cuvant) {
            int index = ch - 'a';
            if(!nod->copil[index]) nod->copil[index] = new TrieNode();
            nod->cnt++;
            nod = nod->copil[index];
        }
        nod->finalCuvant = true, nod->nrCuvinte++;
    }
    void stergereCuvant(string cuvant) {
        TrieNode* nod = root;
        for(char ch : cuvant) {
            int index = ch - 'a';
            nod = nod->copil[index]; ///stim ca exista
            nod->cnt--;
        }
        nod->nrCuvinte--;
        if(!nod->nrCuvinte) nod->finalCuvant = false;
    }
    int longestPrefix(string cuvant) {
        TrieNode* nod = root;
        int cnt = 0;
        for(char ch : cuvant) {
            int index = ch - 'a';
            if(!nod->copil[index]) return cnt;
            nod = nod->copil[index], cnt++;
        }
        return cnt;
    }
    int gasireCuvinte(string cuvant) {
        TrieNode* nod = root;
        for(char ch : cuvant) {
            int index = ch - 'a';
            if(!nod->copil[index]) return 0;
            nod = nod->copil[index];
        }
        return nod->nrCuvinte;
    }
};

int main()
{
    Trie trie;
    while(fin >> tip) {
        fin >> sir;
        if(tip == 0) trie.adaugareCuvant(sir);
        else if(tip == 1) trie.stergereCuvant(sir);
        else if(tip == 2) fout << trie.gasireCuvinte(sir) << '\n';
        else fout << trie.longestPrefix(sir) << '\n';
    }

    return 0;
}
