#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
    int nr, rasp;
    trie *fii[27];
};

int op, ans;
char sir[27];
trie *t = new trie(); 

inline void add(trie *poz, char *s)
{
    int x = *s - 'a';
    poz->nr++;
    if(*s == '\0')
    {
        poz->rasp++;
        return;
    }
    if(poz->fii[x] == NULL)
    {
        poz->fii[x] = new trie();
    }
    add(poz->fii[x], s + 1);
}

inline void rem(trie *poz, char *s)
{
    poz->nr--;
    if(*s == '\0')
    {
        poz->rasp--;
        return;
    }
    int x = *s - 'a';
    rem(poz->fii[x], s + 1);
}

inline int first_search(trie *poz, char *s)
{
    if(*s == '\0')
    {
        return poz->rasp;
    }
    int x = *s - 'a';
    if(poz->fii[x] == NULL)
    {
        return 0;
    }
    return first_search(poz->fii[x], s + 1);
}

inline int second_search(trie *poz, char *s)
{
    if(*s == '\0')
        return ans;
    int x = *s - 'a';
    if(poz->fii[x]->nr == 0 || poz->fii[x] == NULL)
    {
        return ans;
    }
    else
    {
        ans++;
    }
    return second_search(poz->fii[x], s + 1);
}

int main()
{
    while(fin >> op >> sir)
    {
        if(op == 0)
        {
            add(t, sir);
        }
        if(op == 1)
        {
            rem(t, sir);
        }
        if(op == 2)
        {
            fout << first_search(t, sir) << '\n';
        }
        if(op == 3)
        {
            ans = 0;
            fout << second_search(t, sir) << '\n';
        }
        for(int i = 1; i <= 26; ++ i)
            sir[i] = '\0';
    }
}