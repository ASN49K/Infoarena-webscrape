#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_SIZE 26

typedef struct TrieNode {
    struct TrieNode* children[ALPHABET_SIZE];
    int count;    // Contador de apariciones de la palabra
    int prefix;   // Contador de prefijo común
} TrieNode;

TrieNode* createNode() {
    // Crea un nuevo nodo Trie
    TrieNode* node = (TrieNode*)malloc(sizeof(TrieNode));
    node->count = 0;
    node->prefix = 0;

    // Inicializa los punteros a NULL
    for (int i = 0; i < ALPHABET_SIZE; i++) {
        node->children[i] = NULL;
    }
    return node;
}

void insert(TrieNode* root, const char* word) {
    TrieNode* current = root;

    while (*word) {
        int index = *word - 'a';

        if (current->children[index] == NULL) {
            // Si el nodo correspondiente a la letra no existe, crea uno nuevo
            current->children[index] = createNode();
        }

        // Incrementa el contador de prefijo
        current->children[index]->prefix++;

        // Avanza al siguiente nodo
        current = current->children[index];

        // Avanza a la siguiente letra de la palabra
        word++;
    }

    // Incrementa el contador de apariciones de la palabra en el último nodo
    current->count++;
}

void removeWord(TrieNode* root, const char* word) {
    TrieNode* current = root;

    while (*word) {
        int index = *word - 'a';

        // Decrementa el contador de prefijo
        current->children[index]->prefix--;

        // Avanza al siguiente nodo
        current = current->children[index];

        // Avanza a la siguiente letra de la palabra
        word++;
    }

    // Decrementa el contador de apariciones de la palabra en el último nodo
    current->count--;
}

int search(TrieNode* root, const char* word) {
    TrieNode* current = root;

    while (*word) {
        int index = *word - 'a';

        if (current->children[index] == NULL) {
            // Si el nodo correspondiente a la letra no existe, la palabra no está en el Trie
            return 0;
        }

        // Avanza al siguiente nodo
        current = current->children[index];

        // Avanza a la siguiente letra de la palabra
        word++;
    }

    // Devuelve el contador de apariciones de la palabra en el último nodo
    return current->count;
}

int findLongestPrefix(TrieNode* root, const char* word) {
    TrieNode* current = root;
    int length = 0;
    int maxPrefix = 0;

    while (*word) {
        int index = *word - 'a';

        if (current->children[index] == NULL) {
            // Si el nodo correspondiente a la letra no existe, devuelve el prefijo máximo encontrado
            return maxPrefix;
        }

        // Avanza al siguiente nodo
        current = current->children[index];

        // Incrementa la longitud del prefijo
        length++;

        if (current->prefix == 1) {
            // Si el prefijo es único, actualiza el prefijo máximo encontrado
            maxPrefix = length;
        }

        // Avanza a la siguiente letra de la palabra
        word++;
    }

    // Devuelve el prefijo máximo encontrado
    return maxPrefix;
}

int main() {
    FILE* inputFile = fopen("trie.in", "r");
    FILE* outputFile = fopen("trie.out", "w");
    TrieNode* root = createNode();

    int operation;
    char word[21];

    while (fscanf(inputFile, "%d %s", &operation, word) == 2) {
        switch (operation) {
            case 0:
                insert(root, word);
                break;
            case 1:
                removeWord(root, word);
                break;
            case 2:
                fprintf(outputFile, "%d\n", search(root, word));
                break;
            case 3:
                fprintf(outputFile, "%d\n", findLongestPrefix(root, word));
                break;
            default:
                break;
        }
    }

    fclose(inputFile);
    fclose(outputFile);
    return 0;
}