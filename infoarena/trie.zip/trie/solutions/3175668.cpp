#include <bits/stdc++.h>

using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");
const int NMAX = 100000;
struct Nod{
    char lit;
    int frcv, cuv_dupa;
    int next[26];
};
int arb_size;
Nod arb[NMAX * 20 + 5];
int queryPrefix( string s ){
    int nod_curr = 0;
    for( int i = 0; i < s.size(); i++ ){
//        cout << s[i] << " " << nod_curr  << " " << arb[nod_curr].cuv_dupa << " " << arb[nod_curr].next[s[i]-'a'] << " gugugaga\n";
        if( !arb[nod_curr].cuv_dupa )
            return i-1;
        if( !arb[nod_curr].next[s[i]-'a'] )
            return i;
        nod_curr = arb[nod_curr].next[s[i]-'a'];
    }
    if( !arb[nod_curr].cuv_dupa )
        return s.size()-1;
    return s.size();
}
int queryCount( string s ){
    int nod_curr = 0;
    for( int i = 0; i < s.size(); i++ )
        if( arb[nod_curr].cuv_dupa && arb[nod_curr].next[s[i]-'a'] )
            nod_curr = arb[nod_curr].next[s[i]-'a'];
        else return 0;
    return arb[nod_curr].frcv;
}

void adaug( string s ){
    int nod_curr = 0;
    for( int i = 0; i < s.size(); i++ ){
        arb[nod_curr].cuv_dupa++;
        if( !arb[nod_curr].next[s[i]-'a'] ){
            arb[nod_curr].next[s[i]-'a'] = ++arb_size;
//            cout << s[i] << " " << nod_curr << " " << arb[nod_curr].next[s[i]-'a'] << " " << arb_size << "\n";
            nod_curr = arb[nod_curr].next[s[i]-'a'];
            arb[nod_curr].lit = s[i];
        }
        else
            nod_curr = arb[nod_curr].next[s[i]-'a'];
    }
    arb[nod_curr].cuv_dupa++;
    arb[nod_curr].frcv++;
}
void sterg( string s ){
    int nod_curr = 0;
    for( int i = 0; i < s.size(); i++ ){
        arb[nod_curr].cuv_dupa--;
        nod_curr = arb[nod_curr].next[s[i]-'a'];
    }
    arb[nod_curr].cuv_dupa--;
    arb[nod_curr].frcv--;
}

int main()
{
    int op;
    string cuv;
    while( in >> op >> cuv ){
        if( op == 0 )
            adaug(cuv);
        else if( op == 1 )
            sterg(cuv);
        else if( op == 2 )
            out << queryCount(cuv) << "\n";
        else
            out << queryPrefix(cuv) << "\n";
    }
    return 0;
}
