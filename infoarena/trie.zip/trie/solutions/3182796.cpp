#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <string>

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
string y;
struct node
{
    int cuv_dupa=0;
    char litera=0;
    int frecventa=0;
    node *next[26]={};
};
node *nod=new node();
int maxim;
void func_insert(node *nod, string &s, int pos)
{
    if(pos==s.size())
    {
        nod->frecventa++;
        nod->cuv_dupa++;
        return;
    }
    char lit = s[pos]-'a';
    if(nod->next[lit]==nullptr)
    {
        nod->next[lit]=new node();
    }
    func_insert(nod->next[lit],s,pos+1);
    nod->cuv_dupa++;
}
void func_del(node *nod, string &s,int pos)
{
    if(pos==s.size())
    {
        nod->frecventa--;
        nod->cuv_dupa--;
    }
    char lit = s[pos]-'a';
    nod->cuv_dupa--;
    if(nod->next[lit]==nullptr)
    {
        return;
    }
    func_del(nod->next[lit],s,pos+1);
}
int query_cnt(node *nod,string &s,int pos)
{
    if(pos==s.size())
    {
        return nod->frecventa;
    }
    char lit = s[pos]-'a';
    query_cnt(nod->next[lit],s,pos+1);
}
int query_prefix(node *nod,string &s,int pos)
{
    char lit=s[pos]-'a';
    if(nod->next[lit]==nullptr)
    {
        return maxim;
    }
    if(nod->cuv_dupa<=0)
    {
        return maxim;
    }
    if(pos==s.size())
    {
        return maxim+1;
    }
    maxim++;
    query_prefix(nod->next[lit],s,pos+1);
}
int main()
{
    int x;
    while(fin>>x)
    {
        fin>>y;
        if(x==0)
        {
            func_insert(nod,y,0);
        }
        else if(x==1)
        {
            func_del(nod,y,0);
        }
        else if(x==2)
        {
            fout<<query_cnt(nod,y,0)<<"\n";
        }
        else if(x==3)
        {
            maxim=0;
            fout<<query_prefix(nod,y,0)<<"\n";
        }
    }
}
