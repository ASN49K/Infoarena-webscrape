#include <fstream>
#include <string>

using namespace std;

ifstream in ("trie.in");
ofstream out ("trie.out");

struct trie{
    int fr;
    trie * fii[26];
    trie()
    {
        fr = 0;
        for (int i = 0; i < 26; i++)
        {
            fii[i] = 0;
        }
    }
};

trie * t = new trie;
string s;
int sz;

void ins (trie * nod, int poz)
{
    if (poz == sz)
    {
        nod -> fr++;
        return;
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] == 0)
    {
        nod -> fii[urm] = new trie;
    }
    ins(nod -> fii[urm], poz + 1);
}

void del (trie * nod, int poz)
{
    if (poz == sz)
    {
        nod -> fr--;
    }
    else
    {
        int urm = (s[poz] - 'a');
        del(nod -> fii[urm], poz + 1);
    }
}

int query (trie * nod, int poz)
{
    if (poz == sz)
    {
        return nod -> fr;
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] != 0)
    {
        return query(nod -> fii[urm], poz + 1);
    }
    return 0;
}

int pref (trie * nod, int poz)
{
    if (sz == poz)
    {
        return poz;
    }
    int urm = (s[poz] - 'a');
    if (nod -> fii[urm] == 0)
    {
        return poz;
    }
    return pref(nod -> fii[urm], poz + 1);
}

int main ()
{
    int op;
    while (in >> op >> s)
    {
        sz = s.size();
        if (op == 0)
        {
            ins(t, 0);
        }
        if (op == 1)
        {
            del(t, 0);
        }
        if (op == 2)
        {
            out << query(t, 0) << '\n';
        }
        if (op == 3)
        {
            out << pref(t, 0) << '\n';
        }
    }
    in.close();
    out.close();
    return 0;
}
