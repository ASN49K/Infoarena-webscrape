#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Node{
    char letter;
    unsigned int apparitions;
    struct Node *next_alphabet_node[26];
    struct Node *parent;
};

void InsertInTrie(Node **Trie,char *word){

    if(NULL==(*Trie)){
        (*Trie)=(Node *) malloc(sizeof(Node));
        (*Trie)->letter='\0';
        (*Trie)->apparitions=0;
        (*Trie)->parent=NULL;
        for(int i=0;i<26;i++)
            (*Trie)->next_alphabet_node[i]=NULL;
    }
    Node *curr_node=(*Trie);
    unsigned int iteration=0,size_word= strlen(word);
    while(iteration<size_word){
        if(NULL==curr_node->next_alphabet_node[word[iteration]-'a']){
            Node *temp=(Node *) malloc(sizeof(Node));
            temp->letter=word[iteration];
            temp->apparitions=0;
            temp->parent=curr_node;
            for(int i=0;i<26;i++)
                temp->next_alphabet_node[i]=NULL;
            curr_node->next_alphabet_node[word[iteration]-'a']=temp;
        }
        iteration++;
        curr_node=curr_node->next_alphabet_node[word[iteration-1]-'a'];
        if(iteration==size_word)
            curr_node->apparitions+=1;
    }
}
int NumApparitionsDictionary(Node **Trie,char *word){
    Node *curr_node=(*Trie);
    unsigned int iteration=0,size_word= strlen(word);
    while(iteration<size_word){
        if(NULL==curr_node->next_alphabet_node[word[iteration]-'a'])
            return 0;
        iteration++;
        curr_node=curr_node->next_alphabet_node[word[iteration-1]-'a'];
        if(iteration==size_word)
           return curr_node->apparitions;
    }

    return 0;
}
void DeleteApparition(Node **Trie,char *word){

    Node *curr_node=(*Trie);
    unsigned int iteration=0,size_word= strlen(word);
    while(iteration<size_word){
        if(NULL==curr_node->next_alphabet_node[word[iteration]-'a'])
            return;
        iteration++;
        curr_node=curr_node->next_alphabet_node[word[iteration-1]-'a'];
        if(iteration==size_word && curr_node->apparitions!=0)
            curr_node->apparitions-=1;
    }

    iteration-=1;
    bool loneChild=true;
    while(iteration>=0 && loneChild && curr_node->apparitions==0){
        loneChild= true;
        for(int i=0;i<26;i++)
            if(NULL!=curr_node->next_alphabet_node[i])
                loneChild=false;

        if(loneChild){
            curr_node=curr_node->parent;
            curr_node->next_alphabet_node[word[iteration]-'a']=NULL;
        }

    }
}
int LengthLargestPrefix(Node **Trie,char *word){
    Node *curr_node=(*Trie);
    unsigned int iteration=0,size_word= strlen(word);
    while(iteration<size_word){
        if(NULL==curr_node->next_alphabet_node[word[iteration]-'a']){
            break;
        }
        iteration++;
        curr_node=curr_node->next_alphabet_node[word[iteration-1]-'a'];
    }

    return iteration;
}
int main() {

    freopen("trie.in","r",stdin);
    freopen("trie.out","w",stdout);

    Node *Trie=NULL;


    int op;
    char word[20];
    while(scanf("%d %s",&op,word)==2) {
       // printf("%d %s\n", op, word);
        switch (op) {
            case 0:
                InsertInTrie(&Trie,word);
                break;
            case 1:
                DeleteApparition(&Trie,word);
                break;
            case 2:
                printf("%d\n", NumApparitionsDictionary(&Trie,word));
                break;
            case 3:
                printf("%d\n", LengthLargestPrefix(&Trie,word));
                break;
        }

    }


    return 0;
}
