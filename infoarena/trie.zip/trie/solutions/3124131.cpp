#include <fstream>
#define ch (*s-'a')

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");

struct trie
{
    int pr, rasp;
    trie *fii[26];
};
trie *t = new trie();
char s[30];
int ans, c;

void adauga(trie *p, char*s)
{
    p->pr++;

    if(*s == '\0')
    {
        p->rasp++;
        return;
    }
    else
    {
        if(p->fii[ch] == NULL)
        {
            p->fii[ch] = new trie();
        }
        adauga(p->fii[ch], s+1);
    }
}

void elimina(trie *p, char *s)
{
    p->pr--;

    if(*s == '\0')
    {
        p->rasp--;
        return;
    }
    else
    {
        elimina(p->fii[ch], s+1);
    }
}

int calculeaza(trie *p, char *s)
{
    if(*s == '\0')
    {
        return p->rasp;
    }
    else if(p->fii[ch] == NULL)
    {
        return 0;
    }
    else
    {
        return calculeaza(p->fii[ch], s+1);
    }
}

int cauta(trie *p, char *s)
{
    if(*s != '\0' && p->fii[ch] != NULL && p->fii[ch]->pr>0)
    {
        ans++;
        cauta(p->fii[ch], s+1);
    }
    else
    {
        return ans;
    }
}

int main()
{
    while(in>>c>>s)
    {
        if(c == 0)
        {
            adauga(t, s);
        }
        else if(c == 1)
        {
            elimina(t, s);
        }
        else if(c == 2)
        {
            out<<calculeaza(t, s)<<'\n';
        }
        else if(c == 3)
        {
            ans = 0;
            out<<cauta(t, s)<<'\n';
        }
    }
    return 0;
}
