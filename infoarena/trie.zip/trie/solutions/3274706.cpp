#include <fstream>
#include <string.h>
#include <map>
using namespace std;
ifstream cin ("trie.in");
ofstream cout ("trie.out");
int long long c,x,mod=1000000009,l,n;
map<int,int>m1;
map<int,int>m2;
map<string, int> m3, m4;
char s[30];
int main()
{
    while (cin>>c)
    {
        cin>>s;
        n=strlen(s);
        x=l=0;
        string crt;
        for (int i=0; i<n; i++)
        {
            x=x*31+(s[i]-'a'+1);
            x=x%mod;
            crt = crt + s[i];
            if (c==0) m1[x]++, m3[crt]++;
            if (c==1) m1[x]--, m3[crt]--;
            if (c==3 && m3[crt]) l++;
            else if (c==3) break;
        }
        if (c==0) m2[x]++, m4[crt]++;
        if (c==1) m2[x]--, m4[crt]--;;
        if (c==2) cout<<m4[crt]<<'\n';
        if (c==3) cout<<l<<'\n';

    }

    return 0;
}
