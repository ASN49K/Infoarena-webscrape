#include <fstream>

using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
char sir[21];
struct Trie
{
    Trie *fiu[26];
    int cnt=0,nrfii=0;
};
void setup(Trie *nod)
{
    for(int i=0;i<=25;i++)
        nod->fiu[i]=NULL;
}
void elim(Trie *nod, char *p)
{
    nod->nrfii--;
    if(*p==NULL)
        nod->cnt--;
    else
        elim(nod->fiu[p[0]-'a'],p+1);
}
void adaug(Trie *nod, char *p)
{
    nod->nrfii++;
    if(*p==NULL)
        nod->cnt++;
    else
    {
        if(nod->fiu[p[0]-'a']==NULL)
        {
            nod->fiu[p[0]-'a']=new Trie;
            setup(nod->fiu[p[0]-'a']);
        }
        adaug(nod->fiu[p[0]-'a'],p+1);
    }
}
int nrap(Trie *nod , char *p)
{
    if(*p==NULL)
        return nod->cnt;
    else
    {
        if(nod->fiu[p[0]-'a']==NULL)
            return 0;
        else
            return nrap(nod->fiu[p[0]-'a'],p+1);
    }
}
int cmlpc(Trie *nod, char *p)
{
    if(nod->nrfii==0)
        return -1;
    else
    if(*p==NULL||nod->fiu[p[0]-'a']==NULL)
        return 0;
    else
        return cmlpc(nod->fiu[p[0]-'a'],p+1)+1;
}
int main()
{
    int t;
    Trie *root=new Trie;
    setup(root);
    while(cin>>t)
    {
        cin>>sir;
        if(t==0)
            adaug(root,sir);
        else
        if(t==1)
            elim(root,sir);
        else
        if(t==2)
            cout<<nrap(root,sir)<<'\n';
        else
            cout<<cmlpc(root,sir)<<'\n';
    }
    return 0;
}
