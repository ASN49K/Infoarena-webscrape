#include <bits/stdc++.h>

using namespace std;

#define INFILE "trie.in"
#define OUTFILE "trie.out"

const int CHILDREN_MAX = 26;

class Trie {

private:
    int cnt = 0;
    int level = 0;
    Trie *children[CHILDREN_MAX] = {};

public:
    void insert(string s, int position = 0){
        ++level;
        if((int)s.size() == position) ++cnt;
        else {
            int to = s[position] - 'a';
            if(!children[to]) children[to] = new Trie;
            children[to] -> insert(s, position + 1);
        }
    }

    void erase(string s, int position = 0){
        --level;
        if((int)s.size() == position) --cnt;
        else {
            int to = s[position] - 'a';
            children[to] -> erase(s, position + 1);
            if(!children[to] -> level) {
                delete children[to];
                children[to] = nullptr;
            }
        }
    }

    int count(string s, int position = 0){
        if(position == (int)s.size()) return cnt;
        int to = s[position] - 'a';
        if(!children[to]) return 0;
        return children[to] -> count(s, position + 1);
    }

    int longestCommonPrefix(string s, int position = 0){
        if(position == (int)s.size()) return 0;
        int to = s[position] - 'a';
        if(!children[to]) return 0;
        return 1 + children[to] -> longestCommonPrefix(s, position + 1);
    }

};

void solve(){

    Trie *root = new Trie;

    int type; string s;
    while(cin >> type >> s){
        if(type == 0) root -> insert(s);
        else if(type == 1) root -> erase(s);
        else if(type == 2) cout << root -> count(s) << '\n';
        else cout << root -> longestCommonPrefix(s) << '\n';
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}
