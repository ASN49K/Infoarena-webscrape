#include <fstream>
#include <vector>
#include <deque>
#include <stack>
#include <algorithm>
#include <limits.h>

using namespace std;
ifstream cin("trie.in") ;
ofstream cout("trie.out") ;

struct nod
{

    int val = 0, prefix = 0 ;

    nod *v[30] = {0} ;

};

void adaugare(string a, nod *cap)
{

    nod *curent = cap ;

    for(int f = 0 ; f < a.size() ; f ++)
    {

        if(curent -> v[a[f] - 'a'] == 0)
            curent -> v[a[f] - 'a'] = new nod ;

        curent -> prefix ++ ;

        curent = curent -> v[a[f] - 'a'] ;

    }

    curent -> prefix ++ ;

    curent -> val ++ ;

}

void stergere(string a, nod *cap)
{

    nod *curent = cap ;

    for(int f = 0 ; f < a.size() ; f ++)
        curent -> prefix --, curent = curent -> v[a[f] - 'a'] ;

    if(!curent)return ;

    curent -> prefix -- ;

    curent -> val -- ;

}

int nr_apar(string a, nod *cap)
{

    nod *curent = cap ;

    for(int f = 0 ; f < a.size() && curent && curent -> prefix > 0 ; f ++)
        curent = curent -> v[a[f] - 'a'] ;

    if(!curent || curent -> prefix <= 0)return 0 ;

    return curent -> val ;

}

int nr_pref(string a, nod *cap)
{

    nod *curent = cap ;

    int f = 0 ;

    for(f = 0 ; f < a.size() && curent && curent -> prefix > 0 ; f ++)
        curent = curent -> v[a[f] - 'a'] ;

    if(curent && curent -> prefix > 0)f ++ ;

    return f - 1 ;

}

int main()
{

    nod *head = new nod ;

    int a ;

    string x ;

    while(cin >> a >> x)
        if(a == 0)adaugare(x, head) ;
            else if(a == 1)stergere(x, head) ;
                else if(a == 2)cout << nr_apar(x, head) << '\n' ;
                    else cout << nr_pref(x, head) << '\n' ;


    return 0;
}

/*
struct nod
{

    int val = 0, prefix = 0 ;

    nod *v[30] = {0} ;

};

void adaugare(string a, nod *cap)
{

    nod *curent = cap ;

    reverse(a.begin(), a.end()) ;

    for(int f = 0 ; f < a.size() ; f ++)
    {

        if(curent -> v[a[f] - 'a'] == 0)
            curent -> v[a[f] - 'a'] = new nod ;

        curent -> prefix ++ ;

        curent = curent -> v[a[f] - 'a'] ;

    }

    curent -> prefix ++ ;

    curent -> val ++ ;

}

void stergere(string a, nod *cap)
{

    nod *curent = cap ;

    reverse(a.begin(), a.end()) ;

    for(int f = 0 ; f < a.size() && curent && curent -> prefix > 0 ; f ++)
        curent -> prefix --, curent = curent -> v[a[f] - 'a'] ;

    if(!curent)return ;

    curent -> prefix -- ;

    curent -> val -- ;

}

int nr_apar(string a, nod *cap)
{

    nod *curent = cap ;

    for(int f = 0 ; f < a.size() && curent && curent -> prefix > 0 ; f ++)
        curent = curent -> v[a[f] - 'a'] ;

    if(!curent || curent -> prefix <= 0)return 0 ;

    return curent -> val ;

}

int nr_pref(string a, nod *cap)
{

    nod *curent = cap ;

    int f = 0 ;

    for(f = 0 ; f < a.size() && curent && curent -> prefix > 0 ; f ++)
        curent = curent -> v[a[f] - 'a'] ;

    return f - 1 ;

}

int main()
{

    nod *head = new nod ;

    int n ;

    string a ;

    cin >> n ;

    for(int f = 1 ; f <= n ; f ++)
        {

            cin >> a ;

            string aux ;

            for(int e = a.size() - 1 ; e >= 0 ; e --)
                aux += a[e], adaugare(aux, head) ;

        }

    cin >> n ;

    for(int f = 1 ; f <= n ; f ++)
        {

            cin >> a ;

            string aux ;

            for(int e = a.size() - 1 ; e >= 0 ; e --)
                aux += a[e], stergere(aux, head) ;

        }

    cout << nr_apar("caf", head) ;

    return 0;
}
*/


