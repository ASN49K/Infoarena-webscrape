#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

struct nod{
    int subtree; //cate cuvinte trec prin acest nod
    int freq; //nr de cuv care se termina pe aceasta pozitie, prefix
    nod *next[26];
};

void ins(nod *n, string &s, int poz){
    if (poz == s.size()) {
        n->freq++;
        n->subtree++;
        return;
    }
    int charIdx = s[poz] - 'a';
    if (n->next[charIdx] == nullptr) {
        n->next[charIdx] = new nod();
    }
    ins(n->next[charIdx], s, poz + 1);
    /*n->frecv++;
    if(poz == s.size()){
        n->t++;
        return;
    }*/
    n->subtree++;
}

void del(nod *n, string &s, int poz){
    if(poz == s.size()){
        n->subtree--;
        n->freq--;
        return;
    }
    int charIdx = s[poz] - 'a';
    del(n->next[charIdx], s, poz+1);
    n->subtree++;
}
//tipareste nr de apartiiti ale cuvantului w in lista
int queryCount(nod *n, string &s, int poz){
    if(poz == s.size())
        return n->freq;
    int charIdx = s[poz] - 'a';
    if(n->next[charIdx] == nullptr)
        return 0;
    return queryCount(n->next[charIdx], s, poz+1);
}

//tipareste lungimea celui mai lung prefix comun al lui w cu oricare cuvant din lista

int queryPrefix(nod *n, string &s, int poz){
    if(n->subtree == 0)
        return poz - 1;
    if(poz == s.size()) {
        return poz;
    }
    int charIdx = s[poz] - 'a';
    if(n->next[charIdx] == nullptr) {
        return poz;
    }
    return queryPrefix(n->next[charIdx], s, poz + 1);
}

nod *trie = new nod();

int main()
{
    int op;
    while(f>>op){
        string s;
        f>>s;
        if(op==0)
            ins(trie,s,0);
        if(op==1)
            del(trie,s,0);
        if(op==2)
            g<<queryCount(trie,s,0)<<'\n';
        if(op==3)
            g<<queryPrefix(trie,s,0)<<'\n';
    }
    return 0;
}
