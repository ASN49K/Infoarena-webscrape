#include<fstream>
#include<cstring>
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
struct T
{
	char c;
	int n,p,s,b;
}t[5200001];
char w[21];
int main()
{
	for(int v,z=0;cin>>v;) {
		cin.getline(w,21);
        int l=strlen(w);
        if(v>2) {
            int r=0;
            for(int i=1,j,k=0;i<l;++r,k=j,++i) {
                for(j=t[k].s;j&&(t[j].c!=w[i]||!t[j].p);j=t[j].b);
                if(!j)
                    break;
            }
            cout<<r<<'\n';
		} else if(v>1) {
		    int j=0;
		    for(int i=1,k=0;i<l;k=j,++i) {
                for(j=t[k].s;j&&(t[j].c!=w[i]||!t[j].p);j=t[j].b);
                if(!j)
                    break;
		    }
		    cout<<(j?t[j].n:0)<<'\n';
		} else if(v) {
		    for(int i=1,j,k=0;i<l;--t[j].p,--t[j].n,k=j,++i) {
                for(j=t[k].s;j&&t[j].c!=w[i];j=t[j].b);
                if(!j)
                    break;
		    }
		} else {
            int r=0,b=0;
            bool g=1;
            for(int p=1;p<l&&g;++p) {
                bool f=0;
                for(int o=t[r].s;o&&!f&&g;o=t[o].b)
                    if(t[o].c==w[p]) {
                        if(++t[o].p,r=o,f=1,p==l-1)
                            ++t[o].n,g=0;
                    } else
                        b=o;
                if(!f&&g)
                    t[++z].c=w[p],t[z].n=p==l-1,t[z].p=1,t[r].s?t[b].b=z:t[r].s=z,r=z;
            }
		}
	}
	return 0;
}
