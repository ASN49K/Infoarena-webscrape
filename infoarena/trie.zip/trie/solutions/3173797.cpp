#include <bits/stdc++.h>
using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");

void Add_Word_To_Tree(int node, int p, string word, vector<vector<int>> &Vec, vector<vector<char>> &Cost, vector<int> &Appear)
{
    if (word.length() == 0)
    {
        Appear[node]++;
        return;
    }

    for (int i = 0; i < Vec[node].size(); i++)
    {
        if (Vec[node][i] == p)
            continue;

        if (Cost[node][i] == word[0])
        {
            word.erase(word.begin());
            Add_Word_To_Tree(Vec[node][i], node, word, Vec, Cost, Appear);
            return;
        }
    }

    Vec[node].push_back(Vec.size());
    Vec.push_back(vector<int> (1, node));
    Cost[node].push_back(word[0]);
    Cost.push_back(vector<char> (1, word[0]));
    Appear.push_back(0);

    word.erase(word.begin());
    Add_Word_To_Tree(Vec.size() - 1, node, word, Vec, Cost, Appear);
}

void DeleteWord(int node, int p, string word, vector<vector<int>> &Vec, vector<vector<char>> &Cost, vector<int> &Appear)
{
    if (word.length() == 0)
    {
        Appear[node] = max(0, Appear[node] - 1);
        return;
    }

    for (int i = 0; i < Vec[node].size(); i++)
    {
        if (Vec[node][i] == p)
            continue;

        if (word[0] == Cost[node][i])
        {
            word.erase(word.begin());
            DeleteWord(Vec[node][i], node, word, Vec, Cost, Appear);
            return;
        }
    }
}

void Appearances(int node, int p, string word, vector<vector<int>> &Vec, vector<vector<char>> &Cost, vector<int> &Appear)
{
    if (word.length() == 0)
    {
        out<< Appear[node] << "\n";
        return;
    }

    for (int i = 0; i < Vec[node].size(); i++)
    {
        if (Vec[node][i] == p)
            continue;

        if (word[0] == Cost[node][i])
        {
            word.erase(word.begin());
            Appearances(Vec[node][i], node, word, Vec, Cost, Appear);
            return;
        }
    }

    out<< 0 << "\n";
}

int CountDownWards(int node, int p, vector<vector<int>> &Vec, vector<int> &Appear)
{
    int Sum = Appear[node];

    for (int i = 0; i < Vec[node].size(); i++)
    {
        if (Vec[node][i] == p)
            continue;

        Sum += CountDownWards(Vec[node][i], node, Vec, Appear);
    }

    return Sum;
}

void PrefixAppear(int node, int p, string word, vector<vector<int>> &Vec, vector<vector<char>> &Cost, vector<int> &Appear)
{
    int ans = 0;
    int Sum = CountDownWards(node, p, Vec, Appear);
    while (word.length() > 0 && Sum > 0)
    {
        bool Found = false;
        for (int i = 0; i < Vec[node].size(); i++)
        {
            if (Vec[node][i] == p)
                continue;

            if (word[0] == Cost[node][i])
            {
                word.erase(word.begin());
                Found = true;

                p = node;
                node = Vec[node][i];

                Sum = CountDownWards(node, p, Vec, Appear);
                if (Sum != 0)
                    ans++;

                break;
            }
        }

        if (!Found)
            break;
    }

    out<< ans << "\n";
}

int main()
{
    vector<vector<int>> Vec(1);
    vector<vector<char>> Cost(1);
    vector<int> Appear(1, 0);

    int Type;
    string Word;

    while (in>> Type)
    {   
        in>> Word;

        switch (Type)
        {
        case 0: { Add_Word_To_Tree(0, -1, Word, Vec, Cost, Appear); break; }
        case 1: { DeleteWord(0, -1, Word, Vec, Cost, Appear); break; }
        case 2: { Appearances(0, -1, Word, Vec, Cost, Appear); break; }
        case 3: { PrefixAppear(0, -1, Word, Vec, Cost, Appear); break; }
        }
    }

    return 0;
}