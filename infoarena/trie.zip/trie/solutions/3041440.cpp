///nu am mai scris trie de vreo luna
///sunt retard

#include <fstream>
#include <string.h>
#include <string>
#include <map>

using namespace std;

ifstream cin ("trie.in");
ofstream cout ("trie.out");

const int N = 1e4;

struct trie
{
    trie *v[30];
    int val;
    trie ()
    {
        val = 0;
        memset (v, 0, sizeof(v));
    }
};

trie * head = new trie();

map <string, int> m;

void addtrie (trie *head, char *s)
{
    if (*s == NULL)
        return;
    int pos = (*s - 'a');
    if (head->v[pos] == NULL)
        head->v[pos] = new trie();
    head->v[pos]->val++;
    addtrie(head->v[pos], (s + 1));

}

void sterge (trie *head, char *s)
{
    if (*s == NULL)
        return;
    int pos = (*s - 'a');
    if (head->v[pos] != NULL)
    {
        sterge(head->v[pos], (s + 1));
        head->v[pos]->val--;
        if (!head->v[pos]->val)
        {
            head->v[pos] = 0;
            delete head->v[pos];
        }

    }
}

int prefix (trie *head, char *s)
{
    if (*s == NULL)
        return 0;
    int pos = (*s - 'a');
    if (head->v[pos] != NULL)
        return 1 + prefix (head->v[pos], (s + 1));
    return 0;
}

int op;

char s[N + 1];

int main()
{
    while (cin >> op >> s)
    {
        if (op == 0)
        {
            m[s]++;
            addtrie(head, s);
        }
        if (op == 1)
        {
            m[s]--;
            sterge (head, s);
        }
        if (op == 2)
        {
            cout << m[s] << '\n';
        }
        if (op == 3)
        {
            cout << prefix (head, s) << '\n';
        }
    }
    return 0;
}
