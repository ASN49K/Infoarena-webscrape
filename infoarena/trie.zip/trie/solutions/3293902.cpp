#include <fstream>
#include <string>

using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");


struct trie
{
    int nrcuvinte, nraplitera;
    trie* fii[26];
    trie() {
        nrcuvinte = 0;
        nraplitera = 0;
        for (int i = 0; i < 26; ++i)
            fii[i] = nullptr;
    }

    void adaugacuvant(string s, int pozitie)
    {
        int caractercrt = s[pozitie] - 'a';
        if(fii[caractercrt] == nullptr)
        {
            fii[caractercrt] = new trie();
        }
        fii[caractercrt]->nraplitera++;
        if(pozitie == s.size() - 1)
        {
            fii[caractercrt]->nrcuvinte++;
        }
        else
        {
            fii[caractercrt]->adaugacuvant(s, pozitie+1);
        }
    }

    void stergecuvant(string s, int pozitie)
    {
        int caractercrt = s[pozitie] - 'a';
        fii[caractercrt]->nraplitera--;

        if(pozitie == s.size() - 1)
        {
            fii[caractercrt]->nrcuvinte--;
            if(fii[caractercrt]->nraplitera == 0)
            {
                delete fii[caractercrt];
                fii[caractercrt] = nullptr;
            }
            return;
        }
        fii[caractercrt]->stergecuvant(s, pozitie+1);
        if(fii[caractercrt]->nraplitera == 0)
        {
            delete fii[caractercrt];
            fii[caractercrt] = nullptr;
        }

    }

    int numaraaparitii(string s, int pozitie)
    {
        int caractercrt = s[pozitie] - 'a';
        if(fii[caractercrt] == nullptr)
            return 0;
        if(pozitie == s.size() - 1)
        {
            return fii[caractercrt]->nrcuvinte;
        }

        return fii[caractercrt]->numaraaparitii(s, pozitie + 1);
    }

    int prefcomun(string s, int pozitie)
    {
        int caractercrt = s[pozitie] - 'a';
        if(fii[caractercrt] == nullptr)
            return 0;
        if(pozitie == s.size() - 1)
            return 1;
        return 1 + fii[caractercrt]->prefcomun(s, pozitie + 1);
    }


};

int main()
{
    int operatie;
    string cuvant;
    trie T;
    while(cin>>operatie>>cuvant)
    {
        if(operatie == 0)
            T.adaugacuvant(cuvant, 0);

        else if(operatie == 1)
            T.stergecuvant(cuvant, 0);

        else if(operatie == 2)
            cout<<T.numaraaparitii(cuvant, 0)<<"\n";

        else if(operatie == 3)
            cout<<T.prefcomun(cuvant, 0)<<"\n";
    }
    return 0;
}


