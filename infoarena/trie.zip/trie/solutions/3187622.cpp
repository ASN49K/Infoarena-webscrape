#include <iostream>
#include <fstream>
#include <cstring>
#define cv (*s - 'a') // convert

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie {
	int nr, nrchild;
	trie* child[26];

	trie() {
		nr = nrchild = 0;
		memset(child, 0, sizeof(child));
	}
};

trie* head = new trie;

void ins(trie* nod, char* s) {
	if (*s == '\0') {
		nod->nr++; return;
	}
	if (nod->child[cv] == 0) {
		nod->child[cv] = new trie;
		nod->nrchild++;
	}
	ins(nod->child[cv], s + 1);
}

int del(trie* nod, char* s) {
	if (*s == '\0')
		nod->nr--;
	else if (del(nod->child[cv], s + 1)) {
		nod->child[cv] = 0;
		nod->nrchild--;
	}
	if (nod->nr == 0 && nod->nrchild == 0 && nod != head) {
		delete nod; return 1;
	}
	return 0;
}

int query(trie* nod, char* s) {
	if (*s == '\0')
		return nod->nr;
	if (nod->child[cv])
		return query(nod->child[cv], s + 1);
	return 0;
}

int prefix(trie* nod, char* s, int k) {
	if (*s == '\0' || nod->child[cv] == 0)
		return k;
	return prefix(nod->child[cv], s + 1, k + 1);
}

int main() {
	char s[32];
	while (fin.getline(s, 32)) {
		switch (s[0]) {
			case '0': ins(head, s + 2); break;
			case '1': del(head, s + 2); break;
			case '2': fout << query(head, s + 2) << "\n"; break;
			case '3': fout << prefix(head, s + 2, 0) << "\n"; break;
		}
	}
	return 0;
}

