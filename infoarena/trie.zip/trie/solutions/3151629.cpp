#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    struct Node
    {
        int nr, rasp;
        Node *fii[27];
    };
    
    Node *root = new Node();
    
    inline void add(Node *poz, char *s)
    {
        poz->nr++;
        if(*s == '\0')
        {
            poz->rasp++;
            return;
        }
        int x = *s - 'a';
        if(poz->fii[x] == NULL)
            poz->fii[x] = new Node();
        add(poz->fii[x], s + 1);
    }
    
    inline void rem(Node *poz, char *s)
    {
        poz->nr--;
        if(*s == '\0')
        {
            poz->rasp--;
            return;
        }
        int x = *s - 'a';
        rem(poz->fii[x], s + 1);
    }
    
    inline int search1(Node *poz, char *s)
    {
        if(*s == '\0')
        {
            return poz->rasp;
        }
        int x = *s - 'a';
        if(poz->fii[x] == NULL)
            return 0;
        search1(poz->fii[x], s + 1);
    }
    
    inline int search2(Node *poz, char *s, int l)
    {
        int x = *s - 'a';
        if(*s == NULL || poz->fii[x] == NULL || !poz->fii[x]->nr)
            return l;
        search2(poz->fii[x], s + 1, l + 1);
        //return 0;
    }
};

Trie trie;

int main()
{
    int op;
    char s[28];
    memset(s, 0, 28);
    while(fin >> op >> s)
    {
        if(op == 0)
        {
            trie.add(trie.root, s);
        }
        if(op == 1)
        {
            trie.rem(trie.root, s);
        }
        if(op == 2)
        {
            cout << trie.search1(trie.root, s) << '\n';
        }
        if(op == 3)
        {
            cout << trie.search2(trie.root, s, 0) << '\n';
        }
    }
}