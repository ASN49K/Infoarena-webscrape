#include <bits/stdc++.h>
using namespace std;

struct trie{
	
	int cnt;
	trie *fi[26];
	trie(){
		cnt = 0;

		memset(fi, 0, sizeof(fi));
	}
};

trie *t = new trie;


void inserts(trie *node, string a, int poz){
	if(poz == a.size()){
		node->cnt++;
		return;
	}	
	if(node->fi[a[poz] - 'a'] == 0){
		node->fi[a[poz] - 'a'] = new trie;
	}	
	inserts(node->fi[a[poz] -'a'], a, poz + 1);

}

bool del(trie *node, string a, int pos){
	
	if(pos == a.size()){
		node->cnt--;
	}
	else if(del(node->fi[a[pos] - 'a'], a, pos + 1)){
		
		node->fi[a[pos] - 'a'] = 0;
	}

	if(node->cnt == 0 && node != t){
		delete node;
		return 1;
	}
	return 0;

}

int query(trie * node, string a, int pos){
	
	if(pos == a.size()){
		return node->cnt;
	}
	if(node->fi[a[pos] - 'a']){
		return query(node->fi[a[pos] - 'a'], a, pos + 1);
	}
	return 0;
}

int prefix(trie* node, string a, int pos, int k){
	
	if(pos == a.size() || node->fi[a[pos] - 'a'] == 0){
		return k;
	}
	return prefix(node->fi[a[pos] - 'a'], a, pos + 1, k + 1);
}


int main(){
	
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	ifstream fin("trie.in");
	ofstream fout("trie.out");

	int task; string a;
	while(fin >> task >> a){
		if(task == 0) inserts(t, a, 0);
		else if(task == 1) del(t, a, 0);
		else if(task == 2) fout << query(t, a, 0) << '\n';
		else if(task == 3) fout << prefix(t, a, 0 , 0) << '\n';
	}	
	

}