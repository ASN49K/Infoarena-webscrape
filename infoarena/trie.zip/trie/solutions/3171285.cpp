#include <iostream>
#include <fstream>
#include <cstring>

#define CH (*s - 'a')

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

struct trie {
    int k, nr_ap;
    trie *fiu[26];
    /// k - cate cuvinte trec prin nod cand le adaug
    /// nr_ap - cate cuvinte se termina in acest nod

    trie() {
        k = nr_ap = 0;
        memset(fiu, 0, sizeof(fiu));
    }
};

trie *T = new trie;

void ins(trie *nod, char *s)
{
    nod->k++;
    if (*s == '\0')
    {
        nod->nr_ap++;
        return;
    }
    if (nod->fiu[CH] == 0)
    {
        nod->fiu[CH] = new trie;
    }

    ins(nod->fiu[CH], s+1);
}
int del(trie *nod, char *s)
{
    nod->k--;
    if (*s == '\0')
    {
        nod->nr_ap--;
    }
    else if (del(nod->fiu[CH], s+1))
    {
        nod->fiu[CH] = 0;
    }
    if (nod->k == 0 && nod != T)
    {
        delete nod;
        return 1;
    }
    return 0;
}
int aparitii(trie *nod, char *s)
{
    if (*s == '\0')
        return nod->nr_ap;
    if (nod->fiu[CH])
        return aparitii(nod->fiu[CH], s+1);
    return 0;
}
int prefix(trie *nod, char *s, int k)
{
    if (*s == '\0' || nod->fiu[CH] == 0) return k;
    return prefix(nod->fiu[CH], s+1, k+1);
}

int main()
{
    char line[32];
    while (fin.getline(line, 32) && line[0]!=EOF)
    {
        if (line[0] == '0') ins(T, line + 2);
        else if (line[0] == '1') del(T, line + 2); // stergere
        else if (line[0] == '2') fout << aparitii(T, line+2) << "\n"; // afis aparitii w
        else if (line[0] == '3') fout << prefix(T, line+2, 0) << "\n"; // afis prefix comun
    }
    return 0;
}
