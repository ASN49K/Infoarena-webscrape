
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream f ("trie.in");
ofstream g ("trie.out");

struct trie
{
    int cuv,prefixe;
    trie *copii[30];

    trie()
    {
        cuv = 0;
        prefixe = 0;
        for(int i = 0;i<30;i++)
            copii[i] = 0;
    }
};

void adaugare(trie *rad,char *c,int poz)
{
    rad->prefixe++;
    if(poz == strlen(c))
    {
        rad->cuv++;
        return;
    }

    int litera = c[poz] - 'a';
    if(rad->copii[litera] == 0)
        rad->copii[litera] = new trie;
    adaugare(rad->copii[litera],c,poz+1);
}

void stergere(trie *rad,char *c,int poz)
{
    rad->prefixe--;
    if(poz == strlen(c))
    {
        rad->cuv--;
        return;
    }
    int litera = c[poz] - 'a';
    stergere(rad->copii[litera],c,poz+1);
}

int nr_aparitii(trie *rad,char *c,int poz)
{
    if(poz == strlen(c))
    {
        return rad->cuv;
    }
    int litera = c[poz] - 'a';
    if(rad->copii[litera] == 0 || rad->copii[litera]->prefixe == 0)
        return 0;

    return nr_aparitii(rad->copii[litera],c,poz+1);
}
int max_prefix_comun(trie *rad,char *c,int poz)
{
    if(poz == strlen(c))
    {
        return strlen(c);
    }
    int litera = c[poz] - 'a';
    if(rad->copii[litera] == 0 || rad->copii[litera]->prefixe == 0)
        return poz;

    return max_prefix_comun(rad->copii[litera],c,poz+1);
}
int main()
{
    int op;
    char ch[21];
    trie *rad = new trie;
    while(f >> op >> ch)
    {
        switch(op)
        {
        case 0:
            adaugare(rad,ch,0);
            break;
        case 1:
            stergere(rad,ch,0);
            break;
        case 2:
            g << nr_aparitii(rad,ch,0)<<'\n';
            break;
        case 3:
            g << max_prefix_comun(rad,ch,0)<<'\n';
            break;
        }
    }

}
