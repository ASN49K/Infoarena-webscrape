#include <iostream>
#include <fstream>
#include <vector>
//#include <bits/stdc++.h>
#define in fin
#define out fout

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct node{
    int cnt, fii;
    node* v[30];

    node(){
        cnt = 0;
        fii = 0;
        for(int i = 0; i < 30; i++){
            v[i] = NULL;
        }
    }
};
node* r = new node();

void add(node* nod, string s, int i){
    if(i == s.size()){
        nod->cnt++;
        return;
    }

    if( nod->v[ s[i] - 'a' ] == NULL ){
        nod->v[ s[i] - 'a' ] = new node();
        nod->fii++;
    }

    add( nod->v[ s[i] - 'a' ], s, i + 1 );
}

bool del(node* nod, string s, int i){
    // cout << "(DEL) s = " << s << " mergem spre : " << s[i] << '\n';
    if(i == s.size()){
        nod->cnt--;
        // cout << "  -- > nod->cnt = " << nod->cnt << "  fii = " << nod->fii << '\n';
        if( nod->fii == 0 && nod->cnt == 0 && nod != r ){
            // cout << "-----\n";
            delete nod;
            nod = 0;
            return 1;
        }
        return 0;
    }

    // if( nod->v[ s[i] - 'a' ] == NULL ){
    //     return 0;
    // }

    if( del( nod->v[ s[i] - 'a' ], s, i + 1 ) ){
        nod->fii--;
        nod->v[ s[i] - 'a' ] = NULL;
        if(nod->cnt == 0 && nod->fii == 0 && nod != r){
            delete nod;
            nod = 0;
            return 1;
        }
    }
    return 0;
}

int query(node* nod, string s, int i){
    if(i == s.size()){
        return nod->cnt;
    }

    if(nod->v[ s[i] - 'a' ] == NULL) return 0;
    return query( nod->v[ s[i] - 'a' ], s, i + 1 );
}

int prefx(node* nod, string s, int i){
    if(i == s.size()){
        return i;
    }

    // cout << "(PREFX) suntem la s = " << s[i] << '\n';

    if( nod->v[ s[i] - 'a' ] == NULL ){
        // cout << "E null\n";
        return i;
    }

    return prefx(nod->v[ s[i] - 'a' ], s, i + 1 );
}

signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    while(!fin.eof()){
        int op; string v; in >> op >> v;

        if(op == 0) add(r, v, 0);
        if(op == 1) del(r, v, 0);
        if(op == 2) out << query(r, v, 0) << '\n';
        if(op == 3) out << prefx(r, v, 0) << '\n';
    }

    return 0;
}