#include <cstdio>
#include <iostream>
#include <fstream>
#include <stack>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");


#define SIZE 26
struct nod {
    int nr_l = 0, nr_c = 0;
    nod* childrens[SIZE];
};

nod* create_nod() {
    nod* p = new nod;
    for(int i= 0;i<SIZE;++i) {
        p->childrens[i] = nullptr;
    }
    return p;
}

void insereaza(nod* rad, string a) {
    nod* p = rad;
    for(char c : a) {
        int index = c - 'a';
        if(!p->childrens[index]) p->childrens[index] = create_nod();
        p->childrens[index]->nr_l++;
        p = p->childrens[index];
    }
    p->nr_c++;
}
void sterge(nod*rad, string a) {
    nod* p = rad;
    for(char c : a) {
        int index = c - 'a';
        p->childrens[index]->nr_l--;
        p = p->childrens[index];
    }
    p->nr_c--;
}
int cauta(nod* rad, string a) {
    nod* p = rad;
    for(char c : a) {
        int index = c - 'a';
        if(!p->childrens[index]) return false;
        p = p->childrens[index];
    }
    return p->nr_c;
}
int cauta_prefix(nod* rad, string a) {
    nod * p = rad;
    int cnt = 0;
    for(char c : a) {
        int index = c - 'a';
        if(p->childrens[index]) cnt++;
        else return cnt;

        p = p->childrens[index];
    }
    return cnt;
}
int cauta_prefix2(nod* rad, string a) {
    nod * p = rad;
    int cnt = 0;
    for(int i = 0;i<a.length();++i) {
        int index = a[i] - 'a';
        if(p->childrens[index]) cnt = i + 1;
        else return cnt;
        p = p->childrens[index];
    }
    return cnt;
}



int main() {
    nod* root = create_nod();
    int x;
    std::string s;
    while (fin >> x >> s)
    {
        switch (x)
        {
        case 0:
            insereaza(root, s);
            break;
        case 1:
            sterge(root, s);
            break;
        case 2:
            fout << cauta(root, s) << "\n";
            break;
        case 3:
            fout << cauta_prefix(root, s) << "\n";
            break;
        }
    }

    return 0;
}