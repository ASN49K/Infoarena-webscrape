#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
	trie()
	{
		cuvinte = nrfii = 0;
		for (int i = 0; i < 26; i++)
		{
			fiu[i] = nullptr;
		}
	}

	int cuvinte, nrfii;
	trie* fiu[26];
};

trie* radacina = new trie;

void adaugaCuvant(trie* nod, char* cuvant)
{
	if (*cuvant == '\0')
	{
		nod->cuvinte++;
		return;
	}

	int index = cuvant[0] - 'a';
	if (nod->fiu[index] == nullptr)			// daca nu exista un fiu, creeaza unul
	{
		nod->nrfii++;
		nod->fiu[index] = new trie;
	}

	adaugaCuvant(nod->fiu[index], cuvant + 1);
}

bool stergeCuvant(trie* nod, char* cuvant)
{
	if (*cuvant == '\0')
	{
		nod->cuvinte--;
	}
	else
	{
		int index = cuvant[0] - 'a';
		if (stergeCuvant(nod->fiu[index], cuvant + 1))
		{
			nod->nrfii--;
			nod->fiu[index] = nullptr;
		}
	}

	if (nod->cuvinte == 0 && nod->nrfii == 0 && nod != radacina)
	{
		delete nod;
		return true;
	}
	return false;
}

int aparitiiCuvant(trie* nod, char* cuvant)
{
	if (*cuvant == '\0')
	{
		return nod->cuvinte;
	}

	int index = cuvant[0] - 'a';
	if (nod->fiu[index])
	{
		return aparitiiCuvant(nod->fiu[index], cuvant + 1);
	}
	return 0;
}

void maxPrefix(trie* nod, char* cuvant, int& ans)
{
	if (*cuvant == '\0')
	{
		return;
	}

	int index = cuvant[0] - 'a';
	if (nod->fiu[index] == nullptr)
	{
		return;
	}

	ans++;
	maxPrefix(nod->fiu[index], cuvant + 1, ans);
}

int main()
{
	int op;
	char cuv[30];
	while (fin >> op >> cuv)
	{
		if (op == 0)
		{
			// adauga o aparitie in lista
			adaugaCuvant(radacina, cuv);
		}
		else if (op == 1)
		{
			// sterge o aparitie din lista
			stergeCuvant(radacina, cuv);
		}
		else if (op == 2)
		{
			// nr de aparitii ale cuv
			fout << aparitiiCuvant(radacina, cuv) << '\n';
		}
		else
		{
			// lungimea celui mai lung prefix comun al cuv cu oricare alt cuvant din lista
			int ans = 0;
			maxPrefix(radacina, cuv, ans);
			fout << ans << '\n';
		}
	}
}

