#include <fstream>
using namespace std;

ifstream cin("trie.in");
ofstream cout("trie.out");

int op , n , nr;

string a;

struct Trie{

    int f = 0 , numm;

    Trie * next[26] = {nullptr};

    void add( int ind=0 ){

        f++;

        if(ind == n){

            numm++;

            return;
        }

        if(!next[a[ind]-'a']){

            next[a[ind]-'a'] = new Trie;
        }

        next[a[ind]-'a'] -> add(ind+1);
    }

    void del( int ind=0 ){

        f--;

        if(ind == n){

            numm--;

            return;
        }

        next[a[ind]-'a'] -> del(ind+1);

        if(!next[a[ind]-'a']->f){

            delete next[a[ind]-'a'];

            next[a[ind]-'a'] = nullptr;
        }

    }

    int num(int ind=0){

        if(ind == n){

            return numm;
        }

        if(!next[a[ind]-'a']){

            return 0;

        }else return next[a[ind]-'a']->num(ind+1);
    }

    void l(int ind=0){

        if(ind == n){

            return;

        }

        if(!next[a[ind]-'a']) return;
        else{

            nr++;

            next[a[ind]-'a']->l(ind+1);
        }

    }

}t;

int main(){

    while(cin >> op >> a){

        n = a.size();

        if(!op) t.add();
        if(op == 1) t.del();
        if(op == 2) cout << t.num() << '\n';
        if(op == 3){nr=0; t.l(); cout << nr << '\n';}
    }

    return 0;
}
