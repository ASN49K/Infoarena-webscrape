#include <iostream>
#include <fstream>
#include <cstdlib>
#include <climits>
#include <iomanip>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <iterator>
#include <vector>
#include <algorithm>
#include <numeric>
#include <queue>
#include <stack>
#include <bitset>
#include <functional>
#include <utility>
#include <cmath>
#include <string>
#include <deque>
#include <array>
#include <tuple>
#include <cstring>
#include <ctime>
#include <random>
#include <chrono>
///#include <windows.h>

#pragma GCC optimize("fast-math")

#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define fir first
#define sec second
#define mp make_pair
#define pb push_back
#define all(x) (x).begin() + 1, (x).end()
#define all0(x) (x).begin(), (x).end()
#define allrev(x) (x).rbegin(), (x).rend() - 1
#define allrev0(x) (x).rbegin(), (x).rend()
#define println(thing) cout << thing << '\n'
#define yes println("YES")
#define no println("NO")
#define maybe println("MAYBE")
#define mda println("/////////////////")
#define msb(x) ((x) == 0 ? 0 : (1 << (64 - __builtin_clzll(x) - 1)))
#define lsb(x) ((x) & (-x))

using namespace std;

mt19937_64 rng(chrono :: steady_clock :: now().time_since_epoch().count());

const size_t fixed_random = rng();

clock_t start_time = clock(), end_time;

ll random_seed(ll modulo) {
    return rng() % modulo;
}

template <typename T>
inline void hash_combine(size_t& seed, const T& value) {
    seed ^= hash<T>{}(value) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}

struct pair_hash {
    template <typename T1, typename T2>
    size_t operator () (const pair<T1, T2>& p) const {
        size_t seed = fixed_random;

        hash_combine(seed, p.fir);
        hash_combine(seed, p.sec);

        return seed;
    }
};

struct normal_hash {
    template <typename T>
    size_t operator () (const T& p) const {
        size_t seed = fixed_random;

        hash_combine(seed, p);

        return seed;
    };
};

template <typename unordered_Map>
void optimize_map(unordered_Map& M) {
    M.reserve(1024);
    M.max_load_factor(0.5);
}

template <typename T1, typename T2>
istream& operator >> (istream& in, pair<T1, T2>& p) {
    in >> p.first >> p.second;
    return in;
}

template <typename T1, typename T2>
ostream& operator << (ostream& out, pair<T1, T2>& p) {
    out << p.first << ' ' << p.second;
    return out;
}

/// for bitset bits
template <typename T1, typename T2> T1 operator ^= (T1 t1, T2 t2) {t1 = t1 ^ t2; return t1;}
template <typename T1, typename T2> T1 operator |= (T1 t1, T2 t2) {t1 = t1 | t2; return t1;}
template <typename T1, typename T2> T1 operator &= (T1 t1, T2 t2) {t1 = t1 & t2; return t1;}

const ll NMX = (ll) 1e7;
const ll MOD = (ll) 1e9 + 7;
const ll INF = (ll) 1e17;

ll binExp(ll base, ll exp) {
    ll P = 1;
    for (ll bit = 1; bit <= exp; bit <<= 1) {
        if (exp & bit)
            P = (P * base) % MOD;
        base = (base * base) % MOD;
    }
    return P;
}

inline ll modInv(ll x) {
    return binExp(x, MOD - 2);
}

ll test_case = 0;

class Node {
public:
    Node* children[26];
    ll cnt, kids;

    Node() {
        cnt = 0, kids = 0;
        memset(children, 0, sizeof(children));
    }
};

void solve(ll testcase)
{
    Node* Trie = new Node;

    ll type;
    string s;

    function<void(Node* &, string, ll)> addWord = [&](Node* &node, string str, ll index) {
        if (index == (ll) str.size()) {
            node -> cnt += 1;
            return;
        }

        ll ch = str[index] - 'a';

        if (node -> children[ch] != nullptr) {
            addWord(node -> children[ch], str, index + 1);
            return;
        }

        node -> kids += 1;
        node -> children[ch] = new Node;

        addWord(node -> children[ch], str, index + 1);

        return;
    };

    function<ll(Node*&, string, ll)> deleteWord = [&](Node* &node, string str, ll index) {
        if (index == (ll) str.size()) {
            node -> cnt -= 1;
            if (node -> cnt == 0 && node -> kids == 0) {
                delete node;
                return 1LL;
            }
            return 0LL;
        }

        ll ch = str[index] - 'a';

        ll deleted_child = deleteWord(node -> children[ch], str, index + 1);

        if (deleted_child) {
            node -> kids -= 1;
            node -> children[ch] = nullptr;
            if (node -> cnt == 0 && node -> kids == 0) {
                delete node;
                return 1LL;
            }
        }

        return 0LL;
    };

    function<ll(Node*&, string, ll)> countWord = [&](Node* &node, string str, ll index) {
        if (index == (ll) str.size()) {
            return node -> cnt;
        }

        ll ch = str[index] - 'a';

        if (node -> children[ch] == nullptr) {
            return 0LL;
        }

        return countWord(node -> children[ch], str, index + 1);
    };

    function<ll(Node*&, string, ll, ll)> maximumPrefixWord = [&](Node* &node, string str, ll index, ll prefix) {
        if (index == (ll) str.size() || node -> children[str[index] - 'a'] == nullptr) {
            return prefix;
        }

        ll ch = str[index] - 'a';

        return maximumPrefixWord(node -> children[ch], str, index + 1, prefix + 1);
    };

    while (cin >> type >> s) {
        s = '$' + s;
        switch (type) {
        case 0: addWord(Trie, s, 1); break;
        case 1: deleteWord(Trie, s, 1); break;
        case 2: cout << countWord(Trie, s, 1) << '\n'; break;
        case 3: cout << maximumPrefixWord(Trie, s, 1, 0) << '\n'; break;
        }
    }

    return;
}

int main(void)
{
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);

	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    ///cout << fixed << setprecision(20);

    ///ll tt; cin >> tt; while (tt--)
       solve(++test_case);
    \

    return 0;
}

/**

1
3
10 11 12
23

///

**/
