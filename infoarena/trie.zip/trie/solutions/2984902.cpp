#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ull unsigned long long
#define pb push_back
#define pf push_front
#define FASTIO ios::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define pii pair<int , int>

const int MOD = 1e9 + 7;
const int MAX = 2e5 +5;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trie
{
    struct node
    {
        int cnt = 0,cnt2 = 0;
        node* next[27]{};
    }*root = new node;
    void insert(const string& s, int cnt = 1)
    {
        node* curr = root;
        root->cnt += cnt;
        for(auto it  : s)
        {
            if(curr->next[it-'a'] == NULL)
                curr->next[it-'a'] = new node;
            curr = curr->next[it-'a'];
            curr->cnt += cnt;
        }
        curr->cnt2+=cnt;
    }
    void erase(const string &s)
    {
        insert(s,-1);
    }
    int count(const string&s)
    {
            node* curr = root;
            for(auto it : s)
            {
                if(curr->cnt == 0 || curr->next[it-'a'] == NULL)
                        return 0;
                curr = curr->next[it-'a'];
            }
            return curr->cnt2;
    }
    int lcp(const string& s)
    {
        node* curr = root;
        int height = 0;
        for(auto it : s)
        {
            if(curr->next[it-'a'] == NULL || curr->next[it-'a']->cnt == 0)
                return height;
            curr = curr->next[it-'a'];
            height++;
        }
        return height;
    }
}Trie;

int32_t main()
{
    FASTIO;
    int cs; string a;
    while(fin>>cs>>a)
    {
        if(cs==0)
            Trie.insert(a);
        if(cs==1)
            Trie.erase(a);
        if(cs==2)
            fout<<Trie.count(a)<<'\n';
        if(cs==3)
            fout<<Trie.lcp(a)<<'\n';
    }
}
