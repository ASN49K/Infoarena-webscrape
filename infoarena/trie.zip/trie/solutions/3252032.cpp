#include <fstream>

using namespace std;

ifstream cin("trie.in");
ofstream cout("trie.out");

struct noduri {
    int cnt; ///cate val pt nr resp
    int fii; ///cati fii
    int depth;
    noduri *v[27]; ///fiii
    noduri() {
        cnt = 0;
        fii = 0;
        depth = 0;
        for(int i = 0; i <= 25; i++)
            v[i] = NULL;
    }
};
noduri *radacina;

void add_dfs(noduri *start, string s, int i) { ///i--> ADAUGAM poz i, start e FARA poz i
    if(i == s.size()) {
        start->cnt++;
        return;
    }
    if(start->v[s[i] - 'a'] == NULL) {
        start->v[s[i] - 'a'] = new noduri;
        start->v[s[i] - 'a']->depth = start->depth + 1;
        start->fii++;
    }
    add_dfs(start->v[s[i] - 'a'], s, i + 1);
}
bool del_dfs(noduri* start, string s, int i) {
    if(i == s.size()) {
        start->cnt--;
        if(start->cnt == 0 && start->fii == 0 && start != radacina) {
            delete start;
            return true;
        }
        return false;
    }
    bool ok = del_dfs(start->v[s[i] - 'a'], s, i + 1);
    if(ok) {
        start->fii--;
        start->v[s[i] - 'a'] = NULL;
    }
    if(start->fii == 0 && start->cnt == 0 && start != radacina) {
        delete start;
        return true;
    }
    return false;
}
int ap_dfs(noduri *start, string s, int i) {
    if(i == s.size())
        return start->cnt;
    if(start->v[s[i] - 'a'] == NULL) ///nu exista urm
        return 0;
    return ap_dfs(start->v[s[i] - 'a'], s, i + 1);
}
int maxx = 0;
void pref_dfs(noduri *start, string s, int i) {
    if(i == s.size())
        return;
    if(start->fii != 0 || start->cnt != 0)
        maxx = max(maxx, start->depth);
    if(start->v[s[i] - 'a'] == NULL)
        return;
    pref_dfs(start->v[s[i] - 'a'], s, i + 1);
}

int main()
{
    radacina = new noduri;
    int tip;
    string s;
    while(cin >> tip >> s) {
        if(tip == 0)
            add_dfs(radacina, s, 0);
        else if(tip == 1)
            del_dfs(radacina, s, 0);
        else if(tip == 2)
            cout << ap_dfs(radacina, s, 0) << '\n';
        else if(tip == 3) {
            maxx = 0;
            pref_dfs(radacina, s, 0);
            cout << maxx << '\n';
        }
    }
    return 0;
}
/*
0- adauga
1- sterge
2- aparitii
3- lg celui mai lung prefix comun
*/
