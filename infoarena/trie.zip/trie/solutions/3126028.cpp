#include <bits/stdc++.h>

using namespace std;

ifstream f ("trie.in");
ofstream g ("trie.out");

const int nmax = 2e6 + 3;

struct
{
    int pre, cuv;
    int son[33];
}t[nmax];

int tip, nod, urm, nr;

string s;

void adauga()
{
    nod = 0;

    for (int i = 0; i < s.size(); ++i)
    {
        urm = t[nod].son[s[i] - 'a'];
        if (!urm)
        {
            urm = ++nr;
            t[nod].son[s[i] - 'a'] = urm;
        }
        ++t[urm].pre;
        nod = urm;
    }
    ++t[nod].cuv;
}

void sterge()
{
    nod = 0;
    for (int i = 0; i < s.size(); ++i)
    {
        urm = t[nod].son[s[i] - 'a'];
        --t[urm].pre;
        nod = urm;
    }
    --t[nod].cuv;
}

int aparitii()
{
    nod = 0;
    for (int i = 0; i < s.size(); ++i)
    {
        urm = t[nod].son[s[i] - 'a'];
        if (!t[urm].pre)
            return 0;
        nod = urm;
    }
    return t[nod].cuv;
}

int prefix()
{
    nod = 0;
    for (int i = 0; i < s.size(); ++i)
    {
        urm = t[nod].son[s[i] - 'a'];
        if (!t[urm].pre)
            return i;
        nod = urm;
    }
    return s.size();
}

int main()
{
    while (f >> tip >> s)
    {
        if (tip == 0)
            adauga();
        else if (tip == 1)
            sterge();
        else if (tip == 2)
            g << aparitii() << '\n';
        else
            g << prefix() << '\n';
    }
    return 0;
}
