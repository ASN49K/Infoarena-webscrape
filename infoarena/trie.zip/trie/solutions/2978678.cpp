#include <bits/stdc++.h>
using namespace std ;
ifstream fin("trie.in") ;
ofstream fout("trie.out") ;
class Trie
{
private:
    int frunze=0,cnt=0 ;
    Trie *next[26]= {} ;
public:
    void insert(string &s,int pos)
    {
        frunze++ ;
        if(pos==s.size()) cnt++ ;
        else
        {
            if(!next[s[pos]-'a']) next[s[pos]-'a']=new Trie ;
            next[s[pos]-'a']->insert(s,pos+1) ;
        }
    }
    void sterge(string &s,int pos)
    {
        frunze-- ;
        if(pos==s.size()) cnt-- ;
        else
        {
            next[s[pos]-'a']->sterge(s,pos+1) ;
            if(!next[s[pos]-'a']->frunze)
            {
                delete next[s[pos]-'a'] ;
                next[s[pos]-'a']=nullptr;
            }
        }
    }
    int count(string &s,int pos)
    {
        if(pos==s.size()) return cnt ;
        if(!next[s[pos]-'a']) return 0 ;
        return next[s[pos]-'a']->count(s,pos+1) ;
    }
    int prefix(string &s,int pos)
    {
        if(pos==s.size() || !next[s[pos]-'a']) return 0 ;
        return 1+next[s[pos]-'a']->prefix(s,pos+1) ;
    }
};
int main()
{
    Trie dict ;
    string s ;
    int op ;
    while(fin>>op>>s)
    {
        if(!op) dict.insert(s,0) ;
        if(op==1) dict.sterge(s,0) ;
        if(op==2) fout<<dict.count(s,0)<<'\n' ;
        if(op==3) fout<<dict.prefix(s,0)<<'\n' ;
    }

    return 0 ;
}
