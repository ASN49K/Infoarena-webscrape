#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct trieNode
{
    trieNode *nxt[26];
    int fr;
};
trieNode *root;

void init(trieNode *&p)
{
    p=new trieNode;
    for(int i=0; i<26; i++)
        p->nxt[i]=NULL;
    p->fr=0;
}

void addWord(string s)
{
    int sz=s.size();
    trieNode *p=root;
    for(int i=0; i<sz; i++)
    {
        trieNode *q=p->nxt[s[i]-'a'];
        if(q==NULL)
        {
            init(q);
            p->nxt[s[i]-'a']=q;
        }
        p=q;
        if(i==sz-1)
            p->fr++;
    }
}

void deleteWord(string s)
{
    int sz=s.size();
    trieNode *p=root;
    for(int i=0; i<sz; i++)
    {
        trieNode *q=p->nxt[s[i]-'a'];
        if(i==sz-1)
        {
            q->fr--;
            if(q->fr==0)
            {
                delete q;
                p->nxt[s[i]-'a']=NULL;
            }
        }
        else
            p=q;
    }
}

int howMany(string s)
{
    int sz=s.size();
    trieNode *p=root;
    for(int i=0; i<sz; i++)
    {
        p=p->nxt[s[i]-'a'];
        if(p==NULL)
            return 0;
        if(i==sz-1)
            return p->fr;
    }
}

int longestPrefix(string s)
{
    int sz=s.size();
    trieNode *p=root;
    for(int i=0; i<sz; i++)
    {
        p=p->nxt[s[i]-'a'];
        if(p==NULL)
            return i;
    }
    return sz;
}

int main()
{
    int op;
    string s;
    init(root);
    while(fin >> op >> s)
    {
        if(op==0)
            addWord(s);
        else if(op==1)
            deleteWord(s);
        else if(op==2)
            fout << howMany(s) << "\n";
        else
            fout << longestPrefix(s) << "\n";
    }
    return 0;
}
