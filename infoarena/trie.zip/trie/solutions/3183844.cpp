#include <bits/stdc++.h>

using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");

struct Node{
    Node* letters[26];
    int counter;
    int num_letters;

    Node(){
        this->counter = 0;
        this->num_letters = 0;
        for(int i = 0; i < 26; i++){
            this->letters[i] = NULL;
        }
    }
};

Node* trie = new Node();

void Trie_Insert(string word){
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        if(!p->letters[index]){
            p->letters[index] = new Node();
        }
        p->num_letters++;
        p = p->letters[index];
    }
    p->counter++;
}

void Trie_Delete(string word){
    Node* p = trie;
    Node* previous;
    int index = -1;
    int previous_index;
    for(unsigned i = 0; i < word.length() - 1; i++){
        previous_index = index;
        index = word[i] - 'a';
        p->num_letters--;
        if(i != 0 && p->num_letters == 0){
            previous->letters[previous_index] = NULL;
            return;
        }
        previous = p;
        p = p->letters[index];
    }
    previous_index = index;
    index = word[word.length() - 1] - 'a';
    p->num_letters--;
    if(p->num_letters == 0){
        previous->letters[previous_index] = NULL;
        return;
    }
    else{
        p->letters[index]->counter--;
    }

}

void Trie_Count(string word){
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        if(!p->letters[index]){
            out << 0 << '\n';
            return;
        }
        p = p->letters[index];
    }
    out << p->counter << '\n';
}

void Trie_Prefix(string word){
    int len = 0;
    Node* p = trie;
    for(unsigned i = 0; i < word.length(); i++){
        int index = word[i] - 'a';
        if(!p->letters[index]){
            out << len << '\n';
            return;
        }
        p = p->letters[index];
        ++len;
    }
    out << word.length() << '\n';
}

int main()
{
    int op;
    string word;
    int i = 0;
    while(in >> op >> word){
        /*
        if(op == 3 || op == 2){
            i++;
            cout << i << ". " <<  op << " " << word << '\n';
        }
        */
        if(word == "aerocartograf")
            cout << ++i << ". " << op << '\n';
        switch(op){
            case 0:
                Trie_Insert(word);
                break;
            case 1:
                Trie_Delete(word);
                break;
            case 2:
                Trie_Count(word);
                break;
            case 3:
                Trie_Prefix(word);
                break;
        }
    }

    return 0;
}
