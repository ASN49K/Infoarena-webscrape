#include <bits/stdc++.h>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");

struct NODE {
  int wordCnt;
  int prefixCnt;
};

unordered_map <string, NODE> G;

void insertOperation(string s) {
  string str = "";
  for (int i = 0; i < (int)s.size(); i++) {
    str += s[i];
    G[str].prefixCnt++;
  }
  G[s].wordCnt++;
}

void eraseOperation(string s) {
  string str = "";
  for (int i = 0; i < (int)s.size(); i++) {
    str += s[i];
    G[str].prefixCnt--;
  }
  G[s].wordCnt--;
}

void countOperation(string s) {
  fout << G[s].wordCnt << "\n";
}

void prefixOperation(string s) {
  string str = "";
  for (int i = 0; i < (int)s.size(); i++) {
    str += s[i];
    if (G[str].prefixCnt < 1) {
      fout << i << "\n";
      return;
    }
  }
}

int main() {
  int t;
  string s;
  while (fin >> t >> s)
    if (t == 0)
      insertOperation(s);
    else if (t == 1)
      eraseOperation(s);
    else if (t == 2)
      countOperation(s);
    else
      prefixOperation(s);
  return 0;
}
