#include <bits/stdc++.h>

using namespace std;

ifstream f ("trie.in");
ofstream g ("trie.out");

struct trie{


    int val , nrfii;
    trie *fiu[26];


};

trie *T = new trie();

void trie_push (trie *t , char c[] , int k)
{
    if (k == strlen (c))
    {
        t -> val++;
        return;
    }
    int x = c[k] - 'a';
    if (t -> fiu[x] == 0)
    {
        t -> fiu[x] = new trie();
        t -> nrfii++;
    }
    trie_push (t -> fiu[x] , c , k + 1);
}

bool trie_delete (trie *t , char c[] , int k)
{
   if (k == strlen (c))
        t -> val--;
   else
   {
       int x = c[k] - 'a';
       if (trie_delete (t -> fiu[x] , c , k + 1))
       {
           t -> nrfii--;
           t -> fiu[x] = 0;
       }
   }
       if (t -> val == 0 && t -> nrfii == 0 && t != T)
       {
           delete t;
           return 1;
       }
       return 0;

}

void trie_querry (trie *t , char c[] , int k)
{
    if (k == strlen (c))
    {
        g << t -> val << '\n';
        return ;
    }
    int x = c[k] - 'a';
    if (t -> fiu[x] == NULL)
    {
        g << "0" << '\n';
        return ;
    }
    trie_querry (t -> fiu[x] , c , k + 1);
}

void trie_prefix (trie *t , char c[] , int k)
{
    if (k == strlen (c))
    {
        g << k <<  '\n';
        return ;
    }
    int x = c[k] - 'a';
    if (t -> fiu[x] == 0)
    {
        g << k << '\n';
        return;
    }
    trie_prefix (t -> fiu[x] , c , k + 1);
}

char c[21];
int C;

int main()
{
    while (f >> C >> c)
    {
        if (C == 0)
            trie_push (T , c , 0);
        else
            if (C == 1)
            trie_delete (T , c , 0);
        else
            if (C == 2)
            trie_querry (T , c , 0);
        else
        {

            trie_prefix (T , c , 0);
        }
    }
    return 0;
}
