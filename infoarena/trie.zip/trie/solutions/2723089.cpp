#include <iostream>
#include <fstream>

using namespace std;

// 26 chars
struct node
{
	int aparitii;
	int childCount;
	node* children[26];

	node() : children()
	{
		aparitii = childCount = 0;
	}

	node* getGhild(char c)
	{
		return children[c - 'a'];
	}
	node* createChild(char c)
	{
		children[c - 'a'] = new node();
		return children[c - 'a'];
	}
	void removeChild(char c)
	{
		delete children[c - 'a'];
		children[c - 'a'] = 0;
		childCount--;
	}
};

node* root = new node();

void add(string& s)
{
	
	node* test = root;
	int sz = s.size();
	for (int i = 0; i < sz; i++)
	{
		node* child = test->getGhild(s[i]);
		if (!child)
		{
			test->childCount++;
			test = test->createChild(s[i]);
		}
		else
		{
			test = child;
		}
	}
	test->aparitii++;
}
bool removeRec(node*, string&, int);

void remove(string& s)
{

	node* test = root;
	removeRec(test, s, 0);
	/*int sz = s.size();
	for (int i = 0; i < sz - 1; i++)
	{
		if(test->childCount == 1)
		node* child = test->getGhild(s[i]);
		test = child;
	}
	node* child = test->getGhild(s[sz - 1]);
	if (child->aparitii == 1 && child->childCount == 0)
	{
		test->removeChild(s[sz - 1]);
	}
	else
	{
		child->aparitii--;
	}*/
}

bool removeRec(node* nod, string& s, int k)
{
	if (k == s.size())
	{
		nod->aparitii--;
	}
	else if (removeRec(nod->getGhild(s[k]), s, k + 1))
	{
		nod->removeChild(s[k]);
	}

	if (nod->aparitii == 0 && nod->childCount == 0 && nod != root)
	{
		return true;
	}
	return false;
}

int getAparitii(string& s)
{
	node* test = root;
	int sz = s.size();
	for (int i = 0; i < sz ; i++)
	{
		node* child = test->getGhild(s[i]);
		if (!child) return 0;
		test = child;
	}
	return test->aparitii;
}
int prefix(string& s)
{
	int k = 0;
	node* test = root;
	int sz = s.size();
	for (int i = 0; i < sz; i++)
	{
		node* child = test->getGhild(s[i]);
		if (!child)
		{
			return k;
		}
		k++;
		test = child;
	}
	return s.size();
}


int main()
{
	ifstream f("trie.in");
	ofstream g("trie.out");
	// Program
	string s;
	int x;
	s.resize(21);
	while (f >> x >> s)
	{
		/*if (s == "surmontare")
		{
			cout << x << ":" << getAparitii(s) << endl;
		}*/
		switch (x)
		{
		case 0: {
			add(s);
			break;
		}
		case 1: {
			remove(s);
			break;
		}
		case 2: {
			g << getAparitii(s) << '\n';
			break;
		}
		case 3: {
			g << prefix(s) << '\n';
			break;
		}
		default:
			break;
		}
	}


	// Exit
	f.close();
	g.close();
	return 0;
}
