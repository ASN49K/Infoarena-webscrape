#include <fstream>
#include <cstring>
#include <vector>

using namespace std;

ifstream fin ("trie.in");
ofstream fout("trie.out");

struct miau
{
    int nr;
    char ch;
    miau* loc[27];///26 de posibile litere descendente dintr una
};

vector<miau> v;

miau pl;

long long int cnt=0;

miau copie;

int main()
{
    char s[24];
    while(fin.getline(s,24))
    {
        ///de la s[2] incepe cuvantul

        if(s[0]=='0')///adaug
        {
            int l=strlen(s);
            s[l]='\0';

            int j=2;///de unde uncepe cuv

            miau* x;
            //miau* cx;

            if(pl.loc[(s[j]-96)]==0)///adaug prima litera
            {
                copie.ch=s[j];
                v.push_back(copie);///am adaugat prima litera pe o pozitie

                //fout<<s[j]<<" ";

                pl.loc[(s[j]-96)]=&v.at(cnt);///salvez locatia literei

                cnt++;///urmatoarea litera va fi pe pozitia aceasta in vector

                x=pl.loc[(s[j]-96)];///x memoreaza locul acestei litere acum memorate

                j++; ///ma duc la urmatoarea litera

                //fout<<(*pl[s[j]].loc).ch<<" ";
            }
            else///trebuie sa cobor pe ramuri
            {

                ///stim ca exista prima litera

                x=pl.loc[(s[j]-96)];///i am memorat locatia

                ///x este pointer la locul din vector care il contine pe s[j]

                /// eu vreau sa ma duc la acel loc sa verific daca el are conexiune cu s[j+1] apoi repeat

                while( s[j+1]!='\0' )
                {
                    /// *x.ch este s[j]
                    /// *x.loc[s[j+1]] este pointer la s[j+1]

                    if( (*x).loc[(s[j+1]-96)] !=0 )///daca litera este notata in arbore
                    {
                        x=(*x).loc[(s[j+1]-96)]; ///calatoresc in acel punct
                        j++;
                    }
                    else///in acest caz de acum in colo trebuie sa imi croiesc spatiu prin arbore si deci ies din while
                        break;
                }
                j++;///locatia lui s[j] este memorata
                //fout<<"lol "<<s[j]<<" lol ";

            }
            while(s[j]!='\0')///daca mai exista litere neindexate
            {
                ///de aici in colo aloc spatiu in arbore
                copie.ch=s[j];
                v.push_back(copie);///am adaugat litera in vector;

                //fout<<s[j]<<" ";

                cnt++;

                ///mai trebuie sa fac legatura dintre litera asta si cea precedenta

                ///x se afla la litera precedenta

                (*x).loc[(s[j]-96)]=&v.at(cnt-1); ///fac legatura
                //cx=x;

                x=&v.at(cnt-1);///x se duce la noua litera

                j++;///noua litera devine penultima
            }

            //fout<<(*cx).ch<<" ";
            //fout<<(*x).ch<<"    ";
            (*x).nr++;

        }/*
        else if(s[0]=='1')///elimin
        {
            int l=strlen(s);
            s[l]='\0';
            int j=2;
            miau* x=pl.loc[s[j]-96];
            while(s[j+1]!='\0')
            {
                x=(*x).loc[(s[j+1]-96)];
                j++;
            }
            (*x).nr--;
            //fout<<(*x).nr<<"   ";
        }
        else if(s[0]=='2')/// nr de aparitii (daca e prefix / sufix nu se pune)
        {
            int l=strlen(s);
            s[l]='\0';

            int j=2;
            miau* x=pl.loc[s[j]-96];
            while(s[j+1]!='\0')
            {
                x=(*x).loc[(s[j+1]-96)];
                j++;
            }
            fout<<(*x).nr<<'\n';
        }
        else///cel mai lung prefix comun
        {
        }*/
    }
    //miau xx;
    return 0;
}
