#include <iostream>
#include <fstream>

using namespace std;

struct node {
    int cnt, nrfii;
    node *v[26];
    node() {
        cnt = 0;
        for( int i = 0; i < 26; i++ )
            v[i] = NULL;
    }
};

node *radacina = new node;

void ins( node *nod, string s, int i ) {
    if( i >= s.size() ) {
        nod -> cnt++;
        return;
    }
    if( nod -> v[s[i] - 'a'] == NULL ) {
        nod -> v[s[i] - 'a'] = new node;
        nod -> nrfii++;
    }
    ins( nod -> v[s[i] - 'a'], s, i + 1 );
}

int del( node *nod, string s, int i ) {
    if( i >= s.size() ) {
        nod -> cnt--;
    } else {
        if ( del( nod -> v[s[i] - 'a'], s, i + 1 ) == 1 ) {
            nod -> nrfii--;
            nod -> v[s[i] - 'a'] = NULL;
        }
    }
    if( nod -> cnt == 0 && nod -> nrfii == 0 && nod != radacina ) {
        delete nod;
        return 1;
    }
    return 0;
}

int aparitii( node *nod, string s, int i ) {
    if( i >= s.size() )
        return nod -> cnt;
    if( nod == NULL )
        return 0;
    return aparitii( nod -> v[s[i] - 'a'], s, i + 1 );
}

int prefcom( node *nod, string s, int i ) {
    if( i >= s.size() )
        return i;
    if( nod -> v[s[i] - 'a'] == NULL )
        return i;
    return prefcom( nod -> v[s[i] - 'a'], s, i + 1 );
}

int main() {
    ifstream cin("trie.in");
    ofstream cout("trie.out");
    int tip;
    string s;
    while( cin >> tip ) {
        cin >> s;
        if( tip == 0 )
            ins( radacina, s, 0 );
        else if( tip == 1 )
            del( radacina, s, 0 );
        else if( tip == 2 )
            cout << aparitii(radacina, s, 0) << "\n";
        else
            cout << prefcom( radacina, s, 0 ) << "\n";
    }
    return 0;
}
