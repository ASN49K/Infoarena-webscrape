#include <bits/stdc++.h>

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

struct trie {
    int count = 0;
    int numar_fii = 0;
    trie * litere[26] = {0};
};

void add_to_trie (trie * nod, char * word)
{
    if (word[0]=='\0') {
        nod->count++;
        return;
    }
    char first_letter = word[0];
    int letter_index = first_letter - 'a';
    if (nod->litere[letter_index]==NULL) {
        nod->litere[letter_index] = new trie;
        nod->numar_fii++;
    }
    add_to_trie(nod->litere[letter_index], word+1);
}

void remove_from_trie (trie * nod, char * word) 
{
    if (word[0]=='\0') {
        nod->count--;
        return;
    }
    char first_letter = word[0];
    int letter_index = first_letter - 'a';
    remove_from_trie(nod->litere[letter_index], word+1);
    if (nod->litere[letter_index]->numar_fii==0&&nod->litere[letter_index]->count==0) {
        delete nod->litere[letter_index];
        nod->litere[letter_index] = 0;
        nod->numar_fii--;
    }
}

int how_many_in_trie (trie * nod, char * word)
{
    if (word[0]=='\0') {
        return nod->count;
    }
    char first_letter = word[0];
    int letter_index = first_letter - 'a';
    if (nod->litere[letter_index]==NULL) return 0;
    return how_many_in_trie(nod->litere[letter_index], word+1);
}

int longest_common_prefix (trie * nod, char * word)
{
    char first_letter = word[0];
    int letter_index = first_letter - 'a';
    if (nod->litere[letter_index]==NULL) return 0;
    return 1 + longest_common_prefix(nod->litere[letter_index], word+1);
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    trie *root= new trie;
    int op; char cuvant[25];
    memset(cuvant, 0, sizeof(cuvant));
    while (fin>>op>>cuvant) {
        if (op==0) {
            add_to_trie(root, cuvant);
        }
        if (op==1) {
            remove_from_trie(root, cuvant);
        }
        if (op==2) {
            fout<<how_many_in_trie(root, cuvant)<<'\n';
        }
        if (op==3) {
            fout<<longest_common_prefix(root, cuvant)<<'\n';
        }
        memset(cuvant, 0, sizeof(cuvant));
    }
    return 0;
}