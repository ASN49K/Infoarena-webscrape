#include <fstream>

using namespace std;

const string txt = "trie";

ifstream f(txt + ".in");
ofstream g(txt + ".out");

struct trie {
    int son, cnt;
    trie* v[30];

    trie() {
        son = cnt = 0;
        for (int i = 0; i <= 28; i++) v[i] = nullptr;
    }
};

trie* root = new trie;

void add(int i, string& s, trie* node)
{
    if (i == s.size()) {
        node->cnt++;
        return;
    }

    int ind = s[i] - 'a' + 1;
    if (!node->v[ind]) 
        node->son++, node->v[ind] = new trie;

    add(i + 1, s, node->v[ind]);
}

bool check(trie* node) {
    return (!node->cnt && !node->son && node != root);
}

bool del(int i, string& s, trie* node)
{
    if (i == s.size()) {
        if(node->cnt)
            node->cnt--;

        if (check(node)) {
            delete node;
            return true;
        }

        return false;
    }

    int ind = s[i] - 'a' + 1;

    if (del(i + 1, s, node->v[ind]))
        node->son--, node->v[ind] = nullptr;

    if (check(node)) {
        delete node;
        return true;
    }

    return false;
}

int num(int i, string& s, trie* node)
{
    if (i == s.size())
        return node->cnt;

    int ind = s[i] - 'a' + 1;
    
    if (!node->v[ind]) return 0;

    return num(i + 1, s, node->v[ind]);
}

int pref(int i, string& s, trie* node)
{
    if (i == s.size())
        return i;

    int ind = s[i] - 'a' + 1;
    if (!node->v[ind]) return i;

    return pref(i + 1, s, node->v[ind]);
}

int main()
{
    int op; string s;
    while (f >> op >> s)
    {
        if (op == 0) add(0, s, root);
        else if (op == 1) del(0, s, root);
        else if (op == 2) g << num(0, s, root) << '\n';
        else g << pref(0, s, root) << '\n';
    }
    return 0;
}