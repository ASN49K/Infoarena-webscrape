#include <bits/stdc++.h>
using namespace std;

#define SIGMA 26

struct Node {
  Node* edges[SIGMA];

  int noWords;
  int noFinalWords;

  inline Node* getEdge(char c) {
    return edges[c - 'a'] ? edges[c - 'a'] : NULL;
  }

  inline Node* addEdge(char c) {
    if (!edges[c - 'a'])
      edges[c - 'a'] = new Node();

    ++edges[c - 'a']->noWords;

    return edges[c - 'a'];
  }

  inline Node* removeEdge(char c) {
    --edges[c - 'a']->noWords;
    return edges[c - 'a'];
  }
};

Node root;

void addWord(const char* word) {
  int i;
  Node* current;

  i = 0;
  current = &root;
  while (word[i])
    current = current->addEdge(word[i++]);

  ++root.noWords;
  ++current->noFinalWords;
}

void removeWord(const char* word) {
  int i;
  Node* current;

  i = 0;
  current = &root;
  while (word[i] && current && current->noWords)
    current = current->getEdge(word[i++]);

  if (current && current->noFinalWords) {
    i = 0;
    current = &root;
    while (word[i])
      current = current->removeEdge(word[i++]);

    --root.noWords;
    --current->noFinalWords;
  }
}

int countWord(const char* word) {
  int i;
  Node* current;

  i = 0;
  current = &root;
  while (word[i] && current && current->noWords)
    current = current->getEdge(word[i++]);

  return current ? current->noFinalWords : 0;
}

int prefixLength(const char* word) {
  int i;
  Node* current;

  i = 0;
  current = &root;
  while (word[i] && current && current->noWords)
    current = current->getEdge(word[i++]);

  return current && current->noWords ? i : i - 1;
}

#define WORD_LENGTH 20
char word[WORD_LENGTH + 1];

int main() {
  FILE *fin, *fout;
  fin = fopen("trie.in", "r");
  fout = fopen("trie.out", "w");

  int op;
  while (fscanf(fin, "%d %s\n", &op, word) == 2) {
    if (op == 0)
      addWord(word);
    else if (op == 1)
      removeWord(word);
    else if (op == 2)
      fprintf(fout, "%d\n", countWord(word));
    else
      fprintf(fout, "%d\n", prefixLength(word));
  }

  fclose(fin);
  fclose(fout);
  return 0;
}
