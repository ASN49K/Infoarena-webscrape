#include <bits/stdc++.h>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Node { int apar = 0, cuv = 0; };
unordered_map<string, Node> trie_dar_defapt_nu_e_trie_deloc_gen;
string word;

int op;

void insert_(string &cine) {
	trie_dar_defapt_nu_e_trie_deloc_gen[cine].cuv++;
	while(cine.size() > 0) {
		trie_dar_defapt_nu_e_trie_deloc_gen[cine].apar++;
		cine.pop_back();
	}
}

void delete_(string &cine) {
	trie_dar_defapt_nu_e_trie_deloc_gen[cine].cuv--;
	while(cine.size() > 0) {
		trie_dar_defapt_nu_e_trie_deloc_gen[cine].apar--;
		cine.pop_back();
	}
}

int cuv_(string &cine) {
	return trie_dar_defapt_nu_e_trie_deloc_gen[cine].cuv;
}

int pref_(string &cine) {
	while(cine.size() > 0) {
		if(trie_dar_defapt_nu_e_trie_deloc_gen[cine].apar > 0)
			break;
		cine.pop_back();
	}
	return cine.size();
}

int main() {
	while(fin >> op) {
		fin >> word;
		if(op == 1) {
                        delete_(word);
		} else if(op == 2) {
                        fout<<cuv_(word)<<"\n";
		} else if(op == 3) {
                        fout<<pref_(word)<<"\n";
		} else if(op == 0) {
			insert_(word);
		}
	}
	return 0;
}
