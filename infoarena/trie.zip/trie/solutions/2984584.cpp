#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");

struct nod{
    int k, t;
    nod * x[26];
};
char a[21];

void F(nod * & R, int p)
{if(R==NULL)
 {R = new nod;
  for(int i=0;i<26;i++)
  R->x[i]=NULL;

  R->k=1;
  R->t=0;
 }
 else if(p!=0)R->k++;

 if(p<strlen(a))F(R->x[a[p]-'a'], p+1);
 else R->t++;
}

void S(nod * R, int p, int& t)
{if(R==NULL)t=0;
 else if(p<strlen(a))S(R->x[a[p]-'a'], p+1, t);
 else
 {t=R->t;
  if(t!=0)R->t--;
 }
 if(t!=0)R->k=max(R->k-1, 0);
}

void C(nod * & R, int p, int& k)
{if(R!=NULL)
 {if(p<strlen(a))C(R->x[a[p]-'a'], p+1, k);
  else k=R->t;
 }
}

void D(nod * R, int p, int& maxi)
{if(R!=NULL)
 {if(p!=0 && R->k>1)maxi=max(maxi, p);

  if(p<strlen(a))D(R->x[a[p]-'a'], p+1, maxi);
 }
}

int main()
{   int t;
    nod *R=NULL;

    while(fin>>t>>a)
    {int t1=1;

     if(t==0)F(R, 0);
     else if(t==1)S(R, 0, t1);
     else if(t==2)
     {int k=0;
      C(R, 0, k);
      fout<<k<<"\n";
     }
     else
     {int maxi=-1;
      D(R, 0, maxi);
      fout<<maxi+1<<"\n";
     }cout<<endl;
    }
    return 0;
}
