#include <fstream>
#include <vector>
#include <stack>
#include <stack>
#include <queue>
#include <algorithm>
#include <map>
#include <deque>
#include <cstring>
#define Nmax 352
using namespace std;

ifstream cin("trie.in");
ofstream cout("trie.out");

int op;

struct trie{
    int howMany, NrOfWords;
    trie *son[28];

    trie(){
        howMany = NrOfWords = 0;
        fill(son, son + 27, nullptr);
    }
};

trie *T = new trie();

void Add(trie *T, char *s){
    int pos = s[0] - 'a';
    
    if(s[0] == 0)
        return;

    if(T -> son[pos] == NULL)
        T -> son[pos] = new trie();
    
    T -> son[pos] -> howMany++;

    if(strlen(s) == 1)
        T -> son[pos] -> NrOfWords++;

    Add(T -> son[pos], s + 1);
}
void Del(trie *T, char *s){
    int pos = s[0] - 'a';
    
    if(s[0] == 0)
        return;
    
    if(T -> son[pos] == NULL)
        return;

    T -> son[pos] -> howMany--;

    if(strlen(s) == 1)
        T -> son[pos] -> NrOfWords--;
    
    Del(T -> son[pos], s + 1);
}
int NrAp(trie *T, char *s){
    int pos = s[0] - 'a';
    
    if(s[0] == 0)
        return 0;
    
    if(T -> son[pos] == NULL)
        return 0;

    if(strlen(s) == 1)
        return T -> son[pos] -> NrOfWords;
    
    return NrAp(T -> son[pos], s + 1);
}
int MaxLength(trie *T, char *s, int k){
    int pos = s[0] - 'a';

    if(T -> son[pos] == NULL || s[0] == 0)
        return k;

    if(T -> son[pos] -> howMany == 0)
        return k;

    return MaxLength(T -> son[pos], s + 1, k + 1);
}
int main() {
    char *sir = new char[101];
    char p[101];
    int a = 0;
    while(cin >> op >> p){
        sir = p;
        a++;
   
        if(op == 0)
            Add(T, sir);
        else 
            if(op == 1)
                Del(T, sir);
            else if(op == 2)cout << NrAp(T, sir) << "\n";
            else cout << MaxLength(T, sir, 0) << "\n";
    }


    return 0;
}