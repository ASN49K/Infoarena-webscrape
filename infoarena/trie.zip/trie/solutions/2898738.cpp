#include <iostream>
#include <cstdio>
#include <cstring>
#define teta 26
FILE *f=fopen("trie.in","r");
FILE *g=fopen("trie.out","w");

struct trie {
    int k, p;
    trie * sons[teta] = {};
    trie () {
        this->k = 0;
        this->p = 0;
        memset(this->sons, 0, sizeof(this->sons));
    }
};

using namespace std;

void traverse(trie *pTrie, char word [], int len, int semn)
{
    pTrie->p += semn;
    if (len == 0) {
        pTrie->k += semn;
        return;
    }
    if (pTrie->sons[word[0] - 'a'] == nullptr) {
        trie * nt = new trie();
        pTrie->sons[word[0] - 'a'] = nt;
    }
    traverse(pTrie->sons[word[0] - 'a'], word + 1, len - 1, semn);
}

int que(trie *pTrie, char word [], int len) {

    if (len == 0)
        return pTrie->k;

    if (pTrie->sons[word[0] - 'a'] == nullptr)
        return 0;

    return que(pTrie->sons[word[0] - 'a'], word + 1, len - 1);
}

int pre(trie *pTrie, char word [], int len, int maxlen) {

    if (len == 0)
        return maxlen;

    if (pTrie->sons[word[0] - 'a'] == nullptr || pTrie->sons[word[0] - 'a']->p == 0)
        return maxlen - len;

    return pre(pTrie->sons[word[0] - 'a'], word + 1, len - 1, maxlen);
}

int main()
{

    trie * t = new trie();
    t->k = 0;

    trie * i;

    char line[ 32 ];

    freopen( "trie.in", "r", stdin );
    freopen( "trie.out", "w", stdout );


    while( !feof( stdin ) ) {
        memset(line, NULL, sizeof(line));
        fgets( line, 32, stdin );
        switch( line[0] ) {
            case '0':
                traverse(t, line + 2, strlen(line + 2) - 1, 1);
                break;
            case '1':
                traverse( t, line+2, strlen(line + 2) - 1, - 1 );
                break;
            case '2':
                printf( "%d\n", que( t, line+2, strlen(line + 2) - 1 ) );
                break;
            case '3':
                printf( "%d\n", pre( t, line+2, strlen(line + 2) - 1, strlen(line + 2) - 1 ) );
                break;
        }
    }
    return 0;
}
