#include <bits/stdc++.h>
using namespace std;

ifstream f("trie.in");
ofstream g("trie.out");

class Node {
  private:
    vector<Node*> childs;
    int counter, noChilds;
  public:
    Node() {
      childs.resize(26);
      counter = 0;
    }

    void add(Node* node, string s, short int index) {
      while(index < s.size()) {
        if(node->childs[s[index] - 'a'] == nullptr) {
          node->childs[s[index] - 'a'] = new Node();
          node->noChilds++;
        }
        node = node->childs[s[index] - 'a'];
        ++index;
      }
      node->counter++;
    }

    void del(Node* node, string s, short int index) {
      short i;
      Node* n = nullptr;
      while(index < s.size()) {
        if(node->childs[s[index] - 'a']->noChilds <= 1 && n == nullptr) {
          n = node;
          i = index;
        } else if(node->childs[s[index] - 'a']->noChilds > 1) {
          n = nullptr;
        }
        node = node->childs[s[index] - 'a'];
        ++index;
      }
      node->counter--;
      n->noChilds--;
      n->childs[s[i] - 'a'] = nullptr;
    }

    void printCounter(Node* node, string s, short int index) {
      short int i;
      Node* n = nullptr;
      while(index < s.size()) {
        node = node->childs[s[index] - 'a'];
        if(node->counter > 0) {
          n = node;
          i = index;
        }
        ++index;
      }
      g << node->counter << '\n';
    }

    void longestPrefix(Node* node, string s, short int index) {
      while(index < s.size()) {
        if(node->childs[s[index] - 'a'] == nullptr)
          break;
        node = node->childs[s[index] - 'a'];
        ++index;
      }
      g << index << '\n';
    }
};

int main() {
  int t;
  string s;
  Node* trie = new Node();
  while(f >> t >> s) {
    if(t == 0) {
      // adauga s in trie
      trie->add(trie, s, 0);
    } else if(t == 1) {
      // sterge s din trie
      trie->del(trie, s, 0);
    } else if(t == 2) {
      // aparitii s in trie
      trie->printCounter(trie, s, 0);
    } else {
      // cel mai mare prefix comun al lui s in trie
      trie->longestPrefix(trie, s, 0);
    }
  }
  return 0;
}
