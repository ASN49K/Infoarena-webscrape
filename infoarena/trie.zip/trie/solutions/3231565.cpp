#include <bits/stdc++.h>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

class Nod
{
private:
    int nr, cnt;
    Nod *leg[26];
public:
    Nod()
    {
        nr = cnt = 0;
        for (int i = 0; i < 26; i++)
            leg[i] = NULL;
    }
    void increment(){nr++;}
    void incrementcnt(){cnt++;}
    void decrement(){nr--;}
    void decrementcnt(){cnt--;}
    int info(){return nr;}
    bool IsNULL(char ch) {return (leg[ch - 'a'] == NULL);}
    void LegaturaNoua(char ch) {leg[ch - 'a'] = new Nod;}
    Nod* Inainte(char ch){return leg[ch - 'a'];}
};

class Trie
{
private:
    Nod *rad;
public:
    Trie() {rad = new Nod;}
    void Adauga(string s)
    {
        Nod *p = rad;
        int n = s.size();
        for (int i = 0; i < n; i++)
        {
            if (p->IsNULL(s[i])) p->LegaturaNoua(s[i]);
            p = p->Inainte(s[i]);
            p->incrementcnt();
        }
        p->increment();
    }
    void Sterge(string s)
    {
        Nod *p = rad;
        int n = s.length();
        for (int i = 0; i < n && p != NULL; i++)
        {
            p = p->Inainte(s[i]);
            if (p != NULL) p->decrementcnt();
        }
        if (p != NULL) p->decrement();
    }
    int Afis(string s)
    {
        Nod *p = rad;
        int n = s.length();
        for (int i = 0; i < n && p != NULL; i++)
            p = p->Inainte(s[i]);
        if (p == NULL)
            return 0;
        return p->info();
    }
    int Prefix(string s)
    {
        Nod *p = rad;
        int i;
        int n = s.length();
        for (i = 0; i < n && p != NULL; i++)
            p = p->Inainte(s[i]);
        return (i - 1);
    }
};

Trie T;

int main()
{
    string s;
    int op;
    while (fin >> op)
    {
        fin >> s;
        if (op == 0) T.Adauga(s);
        else if (op == 1) T.Sterge(s);
        else if (op == 2) fout << T.Afis(s) << "\n";
        else fout << T.Prefix(s) << "\n";
    }
    return 0;
}
