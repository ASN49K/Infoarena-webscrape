#include <bits/stdc++.h>

using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie {
    Trie* c[30];

    int cuv = 0;
    int pref = 0;
};
void add(Trie*& t, string s, int ind = 0) {
    t->pref++;
    if (ind == s.size()) {
        t->cuv++;
        return;
    }

    int i = s[ind] - 'a';
    if (!t->c[i]) {
        t->c[i] = new Trie;
    }

    add(t->c[i], s, ind + 1);
}

void remove(Trie*& t, string s, int ind = 0) {
    t->pref--;
    if (ind == s.size()) {
        t->cuv--;
        return;
    }

    int i = s[ind] - 'a';
    if (!t->c[i]) {
        return;
    }
    remove(t->c[i], s, ind + 1);
}

int get(Trie*& t, string s, int ind = 0) {
    if (ind == s.size()) {
        return t->cuv;
    }

    int i = s[ind] - 'a';
    if (!t->c[i]) {
        return 0;
    }
    return get(t->c[i], s, ind + 1);
}

int prefmx(Trie*& t, string s, int ind = 0) {
    if (t->pref <= 0) {
        return ind - 1;
    }

    if (ind == s.size()) {
        return ind;
    }

    int i = s[ind] - 'a';
    if (!t->c[i]) {
        return ind;
    }
    return prefmx(t->c[i], s, ind + 1);
}

int x;
string s;

int main() {
    Trie* t = new Trie;
    while (fin >> x >> s) {
        if (x == 0) {
            add(t, s);
            // t.print();
        } else if (x == 1) {
            remove(t, s);
        } else if (x == 2) {
            fout << get(t, s) << "\n";
        } else {
            fout << prefmx(t, s) << "\n";
        }
    }
}