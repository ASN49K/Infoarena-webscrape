#include <cstdio>
#include <cstring>
#include<string>
#include <iostream>
#include<fstream>
#include<list>
#include<set>
#define MAX_CHAR 26
using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");
struct Trie {
	int cnt, nr;
	Trie* child[26];

	Trie() {
		cnt = 0;
		nr = 0;
		memset(child, 0, sizeof(child));
	}
};

Trie* T = new Trie;

void insert(Trie* nod, string s) {
	if (s.empty()==true) {
		nod->cnt++; return;
	}

	if (nod->child[s[0]-'a'] == 0) {
		nod->child[s[0] - 'a'] = new Trie;
		nod->nr++;
	}

	insert(nod->child[s[0] - 'a'], s.substr(1));
}

int deleteWord(Trie* nod, string s) {
	if (s.empty())
		nod->cnt--;
	else if (deleteWord(nod->child[s[0] - 'a'], s.substr(1))) {
		nod->child[s[0] - 'a'] = 0;
		nod->nr--;
	}

	if (nod->cnt == 0 && nod->nr == 0 && nod != T) {
		delete nod; return 1;
	}
	return 0;
}

int count(Trie* nod, string s) {
	if (s.empty()==true)
		return nod->cnt;

	if (nod->child[s[0] - 'a'])
		return count(nod->child[s[0] - 'a'], s.substr(1));
	return 0;
}

int preffix(Trie* nod, string s, int k) {
	if (s.empty()==true || nod->child[s[0] - 'a'] == 0)
		return k;
	return preffix(nod->child[s[0] - 'a'], s.substr(1), k + 1);
}



int main() {

    string word, pattern;
    int n,ok=0;
    while (in >> n >> word) {
        if (n == 0)
        {
			insert(T, word);
        }
        else
            if (n == 1)
                deleteWord(T,word);
            else
                if (n == 2) {
                  out<<count(T,word)<<'\n';
                }
				else {
					int k = 0;
					out << preffix(T, word, k)<<'\n';
				}
    }
	return 0;
}
