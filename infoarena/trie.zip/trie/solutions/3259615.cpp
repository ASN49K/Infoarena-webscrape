#include <fstream>
#include <cmath>
#include <iomanip>
#include <cstring>
#include <string>
#include <queue>
#include <algorithm>
using namespace std;
ifstream cin("trie.in");
ofstream cout("trie.out");
struct trie
{
    int nrap,nrfii;
    trie *f[26];
    trie()
    {
        nrap=0;
        nrfii=0;
        for(int i=0; i<26; i++)
            f[i]=0;
    }
};
trie *rad;
int cer;
char c[25];

void inserare(trie *p,char *c)
{
    if(*c!=0)
    {
        if(p->f[*c-'a']==0)
        {
            p->f[*c-'a']=new trie;
            p->nrfii++;
        }
        inserare(p->f[*c-'a'],c+1);
    }
    else
        p->nrap++;
}
int stergere(trie *p,char *c)///daca stergem returnam 1
{
    if(*c==0)
    {
        p->nrap--;
    }
    else if( stergere(p->f[*c-'a'],c+1) )
    {
        p->f[*c-'a']=0;
        p->nrfii--;
    }
    if(p->nrap==0 && p->nrfii==0 && p!=rad)
    {
        delete p;
        return 1;
    }
    return 0;
}
int nr_aparitii(trie *p,char *c)
{
    if(*c==0)
        return p->nrap;
    if(p->f[*c-'a']==0)
        return 0;

    return nr_aparitii(p->f[*c-'a'],c+1);
}
int cel_mai_lung_prefix_comun(trie *p,char *c)
{
    if(*c==0)
        return 0;
    if(p->f[*c-'a']==0)
        return 0;

    return 1+cel_mai_lung_prefix_comun(p->f[*c-'a'],c+1);
}
int main()
{
    rad=new trie;

    while(cin>>cer>>c)
    {
        if(cer==0)
        {
            inserare(rad,c);
        }
        else if(cer==1)
        {
            int nimic=stergere(rad,c);
        }
        else if(cer==2)
        {
            cout<<nr_aparitii(rad,c)<<'\n';
        }
        else if(cer==3)
        {
            cout<<cel_mai_lung_prefix_comun(rad,c)<<'\n';
        }
    }

    return 0;
}
