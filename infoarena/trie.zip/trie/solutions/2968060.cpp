#include <bits/stdc++.h>

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");

struct Trie_Nod
{
    int nrc,fin;
    Trie_Nod* fii[26];
    Trie_Nod()
    {
        nrc = 0,fin = 0;
        for (int i = 0; i < 26; i++)
            fii[i] = NULL;
    }
};

Trie_Nod* root = new Trie_Nod;

void op0(string s)
{
    Trie_Nod* nod = root;
    root->nrc++;
    for (int i = 0; i < s.size(); i++)
    {
        int ff = s[i] - 'a';
        if (nod->fii[ff] == NULL)
            nod->fii[ff] = new Trie_Nod;
        nod = nod->fii[ff];
        nod->nrc++;
    }
    nod->fin++;
}

void op1(string s)
{
    Trie_Nod* nod = root;
    root->nrc--;
    for (int i = 0; i < s.size(); i++)
    {
        int ff = s[i] - 'a';
        nod = nod->fii[ff];
        nod->nrc--;
    }
    nod->fin--;
}

void op2(string s)
{
    Trie_Nod* nod = root;
    for (int i = 0; i < s.size(); i++)
    {
        int ff = s[i] - 'a';
        if (nod->fii[ff] == NULL)
        {
            out << "0\n";
            return;
        }
        nod = nod->fii[ff];
    }
    out << nod->fin << '\n';
}

void op3(string s)
{
    Trie_Nod* nod = root;
    int i;
    for (i = 0; i < s.size(); i++)
    {
        int ff = s[i] - 'a';
        if (nod->fii[ff] == NULL)
            break;
        nod = nod->fii[ff];
        if (nod->nrc == 0)
            break;
    }
    out << i << '\n';
}

int main()
{
    int type;
    string s;
    while (in >> type)
    {
        in >> s;
        if (type == 0)
            op0(s);
        else if (type == 1)
            op1(s);
        else if (type == 2)
            op2(s);
        else
            op3(s);
    }
    return 0;
}
