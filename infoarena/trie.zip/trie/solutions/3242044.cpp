#include <fstream>
#define dim 1000001
#include<cstring>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
struct nod{
    int prefix, cuv;
    int fr[26];
}trie[dim];
char s[21];
int cnt, sol;
void prefix(int nod, int lg, char s[]){
   if(trie[nod].prefix>0){
      sol=lg;
      if(s[0]==0)
           return ;
      if(trie[nod].fr[s[0]-'a']!=0)
            prefix(trie[nod].fr[s[0]-'a'],lg+1,s+1);
      else
          return;
   }

}
void inserare(int nod, char s[]){
    trie[nod].prefix++;
    if(s[0]==0)
    {
        trie[nod].cuv++;
        return ;
    }
    if(trie[nod].fr[s[0]-'a']!=0)
         inserare(trie[nod].fr[s[0]-'a'],s+1);
    else
    {
        cnt++;
        trie[nod].fr[s[0]-'a']=cnt;
         inserare(trie[nod].fr[s[0]-'a'],s+1);
    }

}
void stergere(int nod, char s[]){
   trie[nod].prefix--;
   if(s[0]==0){
       trie[nod].cuv--;
       return;
   }
   stergere(trie[nod].fr[s[0]-'a'],s+1);
}
int nrcuv(int nod,char s[]){
   if(s[0]==0)
       return trie[nod].cuv;
    else
          if(trie[nod].fr[s[0]-'a']!=0)
              return nrcuv(trie[nod].fr[s[0]-'a'],s+1);
          else
              return 0;
}
int main(){
    int op;
   while(fin>>op>>s)
    if(op==0)
         inserare(0,s);
     else
        if(op==1)
            stergere(0,s);
        else
           if(op==3){
                sol=0;
                prefix(0,0,s);
                fout<<sol<<"\n";
             }
             else
                   fout<<nrcuv(0,s)<<"\n";

    return 0;
}
