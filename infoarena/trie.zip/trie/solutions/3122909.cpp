#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 100003
using namespace std;
typedef long long ll;
ifstream in("trie.in");
ofstream out("trie.out");
#define w 10000000
int q,a[w],b[w],i,j,k,l=1,t,d[w];char s[22];bitset<w>c;
int main()
{
while(in>>q>>s)
{
    j=0;
    if(q==0)
    {
        for(i=0;s[i];i++)
        {
            ++d[j];
            if(c[j])
                j=b[j]+s[i]-'a';
                else c[j]=1,b[j]=l,l+=26,j=b[j]+s[i]-'a';
        }
        ++d[j],++a[j];
    }
        else if(q==1)
        {
            for(i=0;s[i];i++)
            {
                --d[j];
                if(c[j])
                    j=b[j]+s[i]-'a';
                    else c[j]=1,b[j]=l,l+=26,j=b[j]+s[i]-'a';
            }
            --d[j],--a[j];
        }
            else if(q==2)
            {
                for(i=0;s[i];i++)
                {
                    if(c[j])
                        j=b[j]+s[i]-'a';
                        else c[j]=1,b[j]=l,l+=26,j=b[j]+s[i]-'a';
                }
                out<<a[j]<<"\n";
            }
                else
                {
                    t=0;
                    for(i=0;s[i];i++)
                    {
                        if(d[j])t=i;
                        if(c[j])
                            j=b[j]+s[i]-'a';
                            else c[j]=1,b[j]=l,l+=26,j=b[j]+s[i]-'a';
                    }
                    out<<t<<"\n";
                }
}
}
