#include <iostream>
#include <cstring>

using namespace std;

struct trie {
    int val, nrfii;
    trie *nxt[26];

    trie() {
        memset(nxt, 0, sizeof(nxt));
        val = 0;
        nrfii = 0;
    }
};

trie *radac = new trie;

int sl;
char s[25];

inline void addAp(trie *x, int poz) {
    if(poz == sl + 1) {
        x -> val++;
        return;
    }
    if((x -> nxt[s[poz] - 'a']) == NULL) {
        x -> nxt[s[poz] - 'a'] = new trie;
        x -> nrfii++;
    }
    addAp(x -> nxt[s[poz] - 'a'], poz + 1);
}

inline int remAp(trie *x, int poz) {
    if(poz == sl + 1)
        x -> val--;
    if(poz <= sl && remAp(x -> nxt[s[poz] - 'a'], poz + 1))
        x -> nxt[s[poz] - 'a'] = NULL,
        x -> nrfii--;

    if(x -> val == 0 && x -> nrfii == 0 && x != radac) {
        delete x;
        return 1;
    }
    return 0;
}

int nrAp(trie *x, int poz) {
    if(poz == sl + 1) return x -> val;
    if(x -> nxt[s[poz] - 'a'] != NULL)
        return nrAp(x -> nxt[s[poz] - 'a'], poz + 1);
    return 0;
}

int nrComun(trie *x, int poz) {
    if(poz == sl + 1) return poz - 1;
    if(x -> nxt[s[poz] - 'a'] == NULL)
        return poz - 1;
    return nrComun(x -> nxt[s[poz] - 'a'], poz + 1);
}

int main()
{
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);
    for(int op; scanf("%d %s ", &op, s + 1) != -1;) {
        sl = strlen(s + 1);
        if(op == 0) addAp(radac, 1);
        if(op == 1) remAp(radac, 1);
        if(op == 2) printf("%d\n", nrAp(radac, 1));
        if(op == 3) printf("%d\n", nrComun(radac, 1));
    }
    return 0;
}
