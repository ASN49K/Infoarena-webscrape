#include <string>

#define notlocal 1

#if !notlocal

#include <iostream>
#define fin std::cin
#define fout std::cout

#else

#include <fstream>
std::ifstream fin("trie.in");
std::ofstream fout("trie.out");

#endif

using namespace std;

struct nod
{
    int val;
    int num;
    nod* copii[26];
    nod()
        : val(0), num(0)
    {
        for (int i = 0; i < 26; ++i)
        {
            copii[i] = nullptr;
        }
    }
};

void add(nod*& node, const char* s)
{
    if (node == nullptr)
    {
        node = new nod;
    }
    ++node->num;
    if (!s[0])
    {
        ++node->val;
    }
    else
    {
        add(node->copii[s[0] - 'a'], s + 1);
    }
}

void sub(nod*& node, const char* s)
{
    --node->num;
    if (!s[0])
    {
        --node->val;
    }
    else
    {
        sub(node->copii[s[0] - 'a'], s + 1);
    }
    /**if (!node->num)
    {
        delete node;
        node = nullptr;
    }*/
}

int query(nod*& node, const char* s)
{
    if (node == nullptr)
    {
        return 0;
    }
    if (!s[0])
    {
        return node->val;
    }
    return query(node->copii[s[0] - 'a'], s + 1);
}

int prefix(nod*& node, const char* s)
{
    if (node == nullptr || !node->num)
    {
        return -1;
    }
    if (!s[0])
    {
        return 0;
    }
    return 1 + prefix(node->copii[s[0] - 'a'], s + 1);
}

int main()
{
    nod* root = nullptr;
    short int a;
    string w;
    while (fin >> a >> w)
    {
        switch (a)
        {
        case 0:
            add(root, w.c_str());
            break;
        case 1:
            if (query(root, w.c_str()))
            {
                sub(root, w.c_str());
            }
            break;
        case 2:
            fout << query(root, w.c_str()) << '\n';
            break;
        case 3:
            if (root == nullptr)
            {
                fout << "0\n";
                break;
            }
            fout << prefix(root, w.c_str()) << '\n';
            break;
        }
    }
    return 0;
}
