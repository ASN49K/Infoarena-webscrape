#include <bits/stdc++.h>

using namespace std;

#define int long long

struct Trie {
	struct Node {
		int pref = 0,ends = 0;
		int next[26] = {};
	};
	vector<Node> nodes;

	int create_node() {
		Node new_node;
		nodes.push_back(new_node);
		return nodes.size() - 1;
	}

	void add_to_trie(int curr_node, string cuv, int cuv_ind) {
		if(cuv_ind == cuv.length()) {
			nodes[curr_node].ends ++;
			return;
		}
		int let = cuv[cuv_ind] - 'a';
		if(nodes[curr_node].next[let] == 0) {
			nodes[curr_node].next[let] = create_node();
		}
		nodes[nodes[curr_node].next[let]].pref ++;
		add_to_trie(nodes[curr_node].next[let], cuv, cuv_ind + 1);
	}

	void remove_from_trie(int curr_node, string cuv, int cuv_ind) {
		if(cuv_ind == cuv.length()) {
			nodes[curr_node].ends --;
			return;
		}
		int let = cuv[cuv_ind] - 'a';
		if(nodes[curr_node].next[let] == 0) {
			// curr_node.next[let] = create_node();
			return; // no such word
		}
		nodes[nodes[curr_node].next[let]].pref --;
		remove_from_trie(nodes[curr_node].next[let], cuv, cuv_ind + 1);
		if(nodes[nodes[curr_node].next[let]].pref == 0) {
			nodes[curr_node].next[let] = 0;
		}
	}

	int get_ap(int curr_node, string cuv, int cuv_ind) {
		if(cuv_ind == cuv.length()) {
			return nodes[curr_node].ends;
		}
		int let = cuv[cuv_ind] - 'a';
		if(nodes[curr_node].next[let] == 0) {
			return 0;
		}
		return get_ap(nodes[curr_node].next[let], cuv, cuv_ind + 1);
	}

	int get_pref_len(int curr_node, string cuv, int cuv_ind) {
		if(cuv_ind == cuv.length()) {
			return cuv_ind;
		}
		int let = cuv[cuv_ind] - 'a';
		if(nodes[curr_node].next[let] == 0) {
			return cuv_ind;
		}
		if(nodes[curr_node].next[let])
		return get_pref_len(nodes[curr_node].next[let], cuv, cuv_ind + 1);
	}
};

int32_t main()
{
	int op;
	string word;
	Trie trie;
	int root = trie.create_node();
	while(cin >> op >> word) {
		if(op == 0) {
			trie.add_to_trie(root, word, 0);
		} else if(op == 1) {
			trie.remove_from_trie(root, word, 0);
		} else if(op == 2) {
			cout << trie.get_ap(root, word, 0) << "\n";
		} else {
			cout << trie.get_pref_len(root, word, 0) << "\n";
		}
	}
}