#include <bits/stdc++.h>
using namespace std;

/**
0 w - adauga w
1 w - sterge w din lista
2 w - nr ap ale lui w in lista
3 w - cel mai lung prefix w cu
      oricare cuvant din lista

*/
ifstream fin("trie.in");
ofstream fout("trie.out");

struct Trie
{
    Trie *leg[26];
    int fr, nrcuv;
    Trie()
    {
        fr = nrcuv = 0;
        for (int i = 0; i < 26; i++)
            leg[i] = NULL;
    }
};
Trie *rad;

void Op0(char w[])
{
    int j;
    Trie *p, *q;
    p = rad;
    p->nrcuv ++;
    for (int i = 0; w[i] != 0; i++)
    {
        j = w[i] - 'a';
        if (p->leg[j] != NULL)
            p = p->leg[j];
        else
        {
            q = new Trie;
            p->leg[j] = q;
            p = q;
        }
        p->nrcuv ++;
    }
    p->fr ++;
}

void Op1(char w[])
{
    int j;
    Trie *p;
    p = rad;
    p->nrcuv --;
    for (int i = 0; w[i] != 0; i++)
    {
        j = w[i] - 'a';
        p = p->leg[j];
        p->nrcuv --;
    }
    p->fr --;
}

int Op2(char w[])
{
    int j;
    Trie *p;
    p = rad;
    for (int i = 0; w[i] != 0; i++)
    {
        j = w[i] - 'a';
        if (p->leg[j] == NULL)
            return 0;
        p = p->leg[j];
    }
    return p->fr;
}

int Op3(char w[])
{
    int j, len = 0;
    Trie *p;
    p = rad;
    for (int i = 0; w[i] != 0; i++)
    {
        j = w[i] - 'a';
        if (p->leg[j] == NULL)
            return len;
        p = p->leg[j];
        if (p->nrcuv == 0)
            return len;
        len++;
    }
    return len;
}

int main()
{
    int op;
    char w[21];
    rad = new Trie;
    while (fin >> op >> w)
    {
        if (op == 0) Op0(w);
        else if (op == 1) Op1(w);
        else if (op == 2) fout << Op2(w) << "\n";
        else fout << Op3(w) << "\n";
    }
    return 0;
}
