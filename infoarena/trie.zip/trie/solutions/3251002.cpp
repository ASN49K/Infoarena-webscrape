#include <bits/stdc++.h>
using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
struct nod {
    int info, nrcuvinte;
    nod* v[26];
    nod() {
        nrcuvinte=0;
        info=0;
        for (int i=0; i<=25; i++) v[i]=nullptr;
    }
};
nod* start=new nod();
void nraparitii(string s) {
    nod* curent=start;
    int n=s.size();
    if (curent->v[s[0]-'a']==nullptr) {
        fout<<0<<'\n';
        return ;
    }
    curent=curent->v[s[0]-'a'];
    for (int i=2; i<=n; i++) {
        if (curent->v[s[i-1]-'a']!=nullptr && curent->info!=0) {
            curent=curent->v[s[i-1]-'a'];
        }
        else {
            fout<<0<<'\n';
            return ;
        }
    }
    fout<<curent->nrcuvinte<<'\n';
}
void adauga(string s) {
    nod* curent=start;
    int n=s.size();
    for (int i=1; i<=n; i++) {
        if (curent->v[s[i-1]-'a']!=nullptr) {
            curent=curent->v[s[i-1]-'a'];
            curent->info++;
        }
        else {
            nod* urmator=new nod();
            curent->v[s[i-1]-'a']=urmator;
            curent=curent->v[s[i-1]-'a'];
            curent->info++;
        }
    }
    curent->nrcuvinte++;
}
void sterge(string s) {
    nod* curent=start->v[s[0]-'a'];
    int n=s.size();
    if (n==1) {
        curent->nrcuvinte--;
        return ;
    }
    for (int i=2; i<=n; i++) {
        curent->info--;
        curent=curent->v[s[i-1]-'a'];
    }
    curent->info--;
    curent->nrcuvinte--;
}
void prefix(string s) {
    nod* curent=start;
    int n=s.size();
    if (curent->v[s[0]-'a']==nullptr) {
        fout<<0<<'\n';
        return ;
    }
    curent=curent->v[s[0]-'a'];
    for (int i=2; i<=n; i++) {
        if (curent->v[s[i-1]-'a']!=nullptr && curent->v[s[i-1]-'a']->info!=0) {
            curent=curent->v[s[i-1]-'a'];
        }
        else {
            fout<<i-1<<'\n';
            return ;
        }
    }
}
int main()
{
    int x;
    string s;
    while (fin>>x>>s) {
        if (x==0) adauga(s);
        if (x==1) sterge(s);
        if (x==2) nraparitii(s);
        if (x==3) prefix(s);
    }
    return 0;
}
