#include <iostream>
#include <cstring>

using namespace std;

#define ch (*s - 'a')
const int SIGMA = 26, N = 32;

struct Trie{
    int cnt, nrFii;
    Trie *fiu[SIGMA];
    Trie(){
        cnt = nrFii = 0;
        memset(fiu, 0, sizeof(fiu));
    }
};

Trie *T = new Trie;
char line[N];

void adaugare(Trie * nod, char * s){
    if(*s == '\n'){
        nod->cnt++;
        return;
    }

    if(nod->fiu[ch] == 0){
        nod->fiu[ch] = new Trie;
        nod->nrFii++;
    }

    adaugare(nod->fiu[ch], s + 1);
}

bool stergere(Trie * nod, char * s){
    if(*s == '\n')
        nod->cnt--;
    else if(stergere(nod->fiu[ch], s + 1)){
        nod->fiu[ch] = 0;
        nod->nrFii--;
    }

    if(nod->cnt == 0 && nod->nrFii == 0 && nod != T){
        delete nod;
        return 1;
    }

    return 0;
}

int aparitii(Trie * nod, char * s){
    if(*s == '\n')
        return nod->cnt;

    if(nod->fiu[ch])
        return aparitii(nod->fiu[ch], s + 1);

    return 0;
}

int prefix(Trie * nod, char * s, int k){
    if(*s == '\n' || nod->fiu[ch] == 0)
        return k;

    return prefix(nod->fiu[ch], s + 1, k + 1);
}

int main(){
    freopen("trie.in", "r", stdin);
    freopen("trie.out", "w", stdout);

    while(!feof(stdin)){
        fgets(line, 32, stdin); /// cum pot sa citesc asta fara fgets si freopen (ie. cu cin sau getline sau cin.get)?
        switch(line[0]){
            case '0': adaugare(T, line + 2); break;
            case '1': stergere(T, line + 2); break;
            case '2': cout << aparitii(T, line + 2) << '\n'; break;
            case '3': cout << prefix(T, line + 2, 0) << '\n'; break;
        }
    }
}
