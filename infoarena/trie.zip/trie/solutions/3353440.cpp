#include <fstream>
#include <vector>
#include <string>

std::ifstream f("trie.in");
std::ofstream g("trie.out");

struct TrieNode {
    std::vector<TrieNode*> children;
    int count;

    TrieNode() : children(26, nullptr), count(0) {}
};

TrieNode* get_end_of_word(TrieNode* node, const std::string &word, bool find_only = true) {
    for (char c : word) {
        int index = c - 'a';
        if (!node->children[index]) {
            if (find_only) return nullptr;
            node->children[index] = new TrieNode();
        }
        node = node->children[index];
    }
    return node;
}

bool remove_word(TrieNode* node, const std::string& word, size_t depth = 0) {
    if (!node) return false;

    if (depth == word.length()) {
        if (node->count > 0) node->count--;
    } else {
        int index = word[depth] - 'a';
        if (remove_word(node->children[index], word, depth + 1)) {
            node->children[index] = nullptr;
        }
    }

    if (depth > 0 && node->count == 0) {
        for (int i = 0; i < 26; i++) {
            if (node->children[i]) return false;
        }
        delete node;
        return true;
    }
    return false;
}

void cleanup_trie(TrieNode* node) {
    if (!node) return;
    for (int i = 0; i < 26; i++) {
        if (node->children[i]) {
            cleanup_trie(node->children[i]);
        }
    }
    delete node;
}

int main() {
    TrieNode *root = new TrieNode();

    int op;
    std::string word;

    while (f >> op >> word) {

        if (op == 0) {
            TrieNode *node = get_end_of_word(root, word, false);
            if (node) node->count++;
        }

        if (op == 1) {
            remove_word(root, word, 0);
        }

        if (op == 2) {
            TrieNode *node = get_end_of_word(root, word, true);
            g << (node ? node->count : 0) << "\n";
        }

        if (op == 3) {
            int prefix_length = 0;
            TrieNode *node = root;
            for (char c : word) {
                int index = c - 'a';
                if (!node->children[index]) {
                    break;
                }
                prefix_length++;
                node = node->children[index];
            }
            g << prefix_length << "\n";
        }
    }

    cleanup_trie(root);
    return 0;
}