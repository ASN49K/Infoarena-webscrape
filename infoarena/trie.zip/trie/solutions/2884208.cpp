#include <fstream>
using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

struct trie
{
    int nrcuv = 0, nrf = 0;
    trie *f[26] = {};
};

trie *r = new trie;

void pune (trie *t, char *c)
{
    if (c[0] == '\0')
        t->nrcuv++;
    else
    {
        if (t->f[c[0]-'a'] == NULL)
        {
            t->f[c[0]-'a'] = new trie;
            t->nrf++;
        }
        pune (t->f[c[0]-'a'], c+1);
    }
}

bool sterge (trie *t, char *c)
{
    if (c[0] == '\0')
        t->nrcuv--;
    else
    {
        if (sterge (t->f[c[0]-'a'], c+1) == 1)
        {
            t->f[c[0]-'a'] = NULL;
            t->nrf--;
        }
    }

    if (t->nrf == 0 && t->nrcuv == 0 && t != r)
    {
        delete t;
        return 1;
    }
    return 0;
}

int nrap (trie *t, char *c)
{
    if (c[0] == '\0')
        return t->nrcuv;

    if (t->f[c[0]-'a'] != NULL)
        return nrap (t->f[c[0]-'a'], c+1);
    return 0;
}

int lgmax (trie *t, char *c)
{
    if (c[0] == '\0')
        return 0;
    if (t->f[c[0]-'a'] == NULL)
        return 0;
    return 1 + lgmax (t->f[c[0]-'a'], c+1);
}

int main()
{
    int tip;
    char c[21];

    while (fin >> tip >> c)
    {
        if (tip == 0)
            pune (r, c);
        else if (tip == 1)
            sterge (r, c);
        else if (tip == 2)
            fout << nrap (r, c) << '\n';
        else
            fout << lgmax (r, c) << '\n';
    }
    return 0;
}
