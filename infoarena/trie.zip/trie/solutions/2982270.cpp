#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <cctype>
#include <unordered_map>
#include <cmath>
#include <bitset>
#include <string>
#include <cstring>
#include <algorithm>
using namespace std;
ifstream in("trie.in");
ofstream out("trie.out");
int a,b,c,d,e,f,g,i,j,k,l,m,n,o,q,r,s,S,t,T,x,y,z,ok,nr,w,C,k1,k2,poz,pas,Max,mid,nways,MOD;
struct inf{
   int ap;
   bool pref;
};
map <string,inf>M;
string str,aux;
int main()
{
   while(in>>x>>str){
    if(x==0){
        M[str].ap++;
        n=str.size();
        aux.clear();
        for(i=0;i<n;i++){
                aux=aux+str[i];
            M[aux].pref=1;
        }
    }
    if(x==1){
        M[str].ap--;
   if(M[str].ap==0) {M.erase(M.find(str));}
    }
    if(x==2){
            if(M.find(str)==M.end()) {out<<0<<'\n';}
        else {out<<M[str].ap<<'\n';}
    }
    if(x==3){
         n=str.size()-1;
        aux=str;
        for(i=n;i>=0;i--){
            if(M[aux].pref==1) {out<<i+1<<'\n'; break;}
            aux.pop_back();
            if(i==0) {out<<0<<'\n';}
        }
    }

   }
   return 0;
}
