#include <iostream>
#include <string>

using namespace std;
const int TOTAL_LEN = 1e5;
const int SIGMA = 26;
const int ROOT = 0;


struct trie {
      struct node {
            int link[SIGMA];
            int frecv;
      } ds[1 + TOTAL_LEN * SIGMA];

      int node_index = 0;
      void add_string ( string elem ) {
          int node = ROOT;
          for ( auto letter : elem ) {
             int code = letter - 'a';
             if ( !ds[node].link[code] ) {
               ds[node].link[code] = ++ node_index;
             node = ds[node].link[code];
             ds[node].frecv ++;
          }
      }

      void delete_string ( string elem ) {
          int node = ROOT;
          for ( auto letter : elem ) {
             int code = letter - 'a';
             if ( ds[node].frecv == 1 )
               ds[node].link[code] = 0;
             node = ds[node].link[code];
             ds[node].frecv --;
          }
      }

      int count_app ( string target ) {
          int node = ROOT;
          auto letter = target.begin (); int code = *letter - 'a';
          int last_frecv = 0;
          while ( letter != target.end () && ds[node].link[code] ) {
             letter ++;
             node = ds[node].link[code];
             last_frecv = ds[node].frecv;
          }
          if ( letter == target.end () )
            return last_frecv;
          return 0;
      }

      int longest_common_pref ()
};

ifstream fin ( "trie.in" );
ofstream fout ( "trie.out" );
int main()
{

    return 0;
}
