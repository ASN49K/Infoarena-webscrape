#include <iostream>
#include <cstring>

#define CH(*s - 'a')

using namespace std;

struct Trie
{
    int cnt, nrfii;
    Trie *fiu[26];

    Trie()
    {
        cnt = nrfii = 0;
        memset(fiu, 0, sizeof(fiu));
    }
};

Trie *T = new Trie;

void ins(Trie *nod, char *s)
{
    if(*s == '\n')
    {
        nod->cnt++;
        return ;
    }


    if(nod->fiu[CH] == 0)
    {
        nod->fiu[ CH ] = new Trie;
        nod->nrfii ++;
    }

    ins(nod->fiu[CH], s+1);
}

int del(Trie *nod, char *s)
{
    if(*s == '\n')
        nod->cnt--;

    else if(del(nod->fiu[CH], s+1) )
    {
        nod->fiu[CH] = 0;
        nod->nrfii--;
    }

    if(nod->cnt == 0 && nod->nrfii == 0 &&
            nod != T)
    {
        delete nod;
        return 1;
    }

    return 0;
}

int que( Trie *nod, char *s )
{
    if( *s == '\n' )
        return nod->cnt;

    if( nod->fiu[ CH ] )
        return que( nod->fiu[ CH ], s+1 );
    return 0;
}

int pre(Trie *nod, char *s, int k)
{
    if( *s == '\n' || nod->fiu[ CH ] == 0 )
		return k;
    return pre(nod->fiu[CH], s+1, k+1);
}


int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
