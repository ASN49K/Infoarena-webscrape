#include <fstream>	
#include <cstring>

using namespace std;

#define AC (*str - 'a')

struct Trie{
    int nr, nrfii;
    Trie* fiu[26];

    Trie(){
        nr = nrfii = 0;
        for(int i = 0; i < 26; ++i)
            fiu[i] = nullptr;
    }

};

Trie* T = new Trie();

void insert(Trie* node, char* str){


    if(*str == '\0'){
        ++node->nr;
        return;
    } 
    if(node->fiu[AC] == nullptr){
        node->fiu[AC] = new Trie();
        ++node->nrfii;
    }
    insert(node->fiu[AC], str + 1);
}

bool del(Trie* node, char* str){

    if(*str == '\0')
        --node->nr;
    else if(del(node->fiu[AC], str + 1)){
        node->nrfii--;
        node->fiu[AC] = nullptr;
    }

    if(node->nr == 0 && node->nrfii == 0 && node != T){
        delete node;
        return true;
    }
    return false;
}

int ap(Trie* node, char* str){
    if(*str == '\0')
        return node->nr;
    if(node->fiu[AC] != nullptr)
        return ap(node->fiu[AC], str + 1);
    return 0;
}

int pre(Trie* node, char* str, int len){
    if(*str == '\0' || node->fiu[AC] == nullptr)
        return len;
    return pre(node->fiu[AC], str + 1, len + 1);
}
		
int main(){
	
    ifstream cin("trie.in");
    ofstream cout("trie.out");
	
    char line[32];

    while(cin.getline(line, 32)){
        
        int op = line[0] - '0';
        strcpy(line, line + 2);

        switch(op){
            case 0:
                insert(T, line);
                break;
            case 1:
                del(T, line);
                break;
            case 2:
                cout << ap(T, line) << "\n";
                break;
            case 3:
                cout << pre(T, line, 0) << "\n";
                break;
            default:
                break;
        }
    }
  
    cin.close();
    cout.close();
	
    return 0;	
}