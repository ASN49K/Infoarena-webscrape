#include <bits/stdc++.h>

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

int op;
char str[25];

struct Node
{
    int prefix_frq;
    int word_frq;
    Node *child[26];
    Node()
    {
        for(int i = 0; i < 26; ++i)
            child[i] = NULL;
        prefix_frq = 0;
        word_frq = 0;
    }
}*root;

void Add (char str[])
{
    Node *p = root;
    for(int i = 0; str[i]; ++i)
    {
        int l = str[i] - 'a';
        if(p -> child[l] == NULL)
            p -> child[l] = new Node;
        p = p -> child[l];
        ++p -> prefix_frq;
    }
    ++p -> word_frq;
}

void Delete (char str[])
{
    Node *p = root;
    int l;
    for(int i = 0; str[i]; ++i)
    {
        l = str[i] - 'a';
        p = p -> child[l];
        --p -> prefix_frq;
    }
    --p -> word_frq;
}

int Count (char str[])
{
    Node *p = root;
    for(int i = 0; str[i]; ++i)
    {
        int l = str[i] - 'a';
        if(p -> child[l] == NULL)
            return 0;
        p = p -> child[l];
    }
    return p -> word_frq;
}

int Longest_Pref (char str[])
{
    Node *p = root;
    int K = 0;
    for(int i = 0; str[i]; ++i)
    {
        int l = str[i] - 'a';
        if(p -> child[l] != NULL && p -> child[l] -> prefix_frq)
            p = p -> child[l];
        else
            break;

        ++K;
    }
    return K;
}

int main()
{
    root = new Node;
    while (fin >> op >> str)
    {
        if(op == 0)
            Add(str);
        else if(op == 1)
            Delete(str);
        else if(op == 2)
            fout << Count(str) << "\n";
        else
            fout << Longest_Pref(str) << "\n";
    }
}
