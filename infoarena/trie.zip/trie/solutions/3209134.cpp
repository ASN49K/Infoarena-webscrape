#include <bits/stdc++.h>

using namespace std;
ifstream fin("trie.in");
ofstream fout("trie.out");
map<string,int> mp;
char s[25],a[100005][25];
int c,nr,maxim,cnt;
int main()
{
    while(fin>>c>>s){
        if(c==0){
            if(mp.find(s)==mp.end())
                strcpy(a[++nr],s);
            mp[s]++;
        }
        else
            if(c==1){
                if(mp[s]>0)
                    mp[s]--;
        }
        else
            if(c==2)
        {
            fout<<mp[s]<<'\n';
        }
        else
            if(c==3){
                maxim=0;
                cnt=0;
                for(int j=1;j<=nr;j++)
                {
                    if(mp[a[j]]>0){
                    int l,k;
                    l=k=0;
                    while(l<strlen(a[j]) && k<strlen(s)){
                        if(a[j][l]==s[k])
                            l++,k++;
                        else
                            l=strlen(a[j]);
                    }
                    if(k>maxim)maxim=k;
                }
            }
            fout<<maxim<<'\n';
        }
    }
    return 0;
}
