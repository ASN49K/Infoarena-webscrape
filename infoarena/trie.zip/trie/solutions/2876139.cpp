#include <iostream>
#include <cstring>
#include <array>
using namespace std;

struct Node {
  Node *arr[26];
  int end, suc;
  Node() {
    memset(this, 0, sizeof(Node));
  }
};

void add(Node *u, char *s) {
  
  if (!*s) {
    u->end++;
    return;
  }

  Node *&v = u->arr[*s - 'a'];
  if (v == NULL) v = new Node;
  add(v, s + 1), u->suc++;

}

void remove(Node *&u, char *s) {

  if (!*s) {
    u->end--;
    if (!u->end && !u->suc) delete u, u = NULL;
    return;
  }

  Node *&v = u->arr[*s - 'a'];
  if (v == NULL) return;
  remove(v, s + 1), u->suc--;
  if (!u->end && !u->suc) delete u, u = NULL;

}

void occs(Node *u, char *s) {

  Node *v;
  
  while (*s) {

    u = u->arr[*s - 'a'];
    if (u == NULL) break;
    s++;

  }

  if (*s) cout << 0 << '\n';
  else cout << u->end << '\n';

}

void longpf(Node *u, char *s) {
  
  Node *v;
  char *it = s;

  while (*it) {
    
    v = u->arr[*it - 'a'];
    if (v == NULL) break;
    u = v;
    it++;

  }

  cout << it - s << '\n';

}

void print(Node *u, char *b, char *e) {

  for (int i = 0; i < u->end; i++)
    cout << b << endl;
  for (int i = 0; i < 26; i++) {
    Node *&v = u->arr[i];
    if (v == NULL) continue;
    *e++ = 'a' + i;
    print(v, b, e);
    *--e = '\0';
  }

}

int main() {

  freopen("trie.in", "r", stdin);
  freopen("trie.out", "w", stdout);
  ios_base::sync_with_stdio(false), cin.tie(NULL);

  int op;
  char s[30];
  Node *r = new Node;

  while (cin >> op >> s) {
    switch (op) {
      case 0: add(r, s); break;
      case 1: remove(r, s); break;
      case 2: occs(r, s); break;
      case 3: longpf(r, s); break;
    }
  }

}