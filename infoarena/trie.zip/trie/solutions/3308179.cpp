#include <algorithm>
#include <bitset>
#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <unordered_map>
#include <cstring>
using namespace std;

ifstream fin("trie.in");
ofstream fout("trie.out");

struct nod{
    int cnt, nrfii;
    nod * fiu[26];
    nod() {
        cnt = 0;
        nrfii = 0;
        for(int i = 0; i <= 25; i ++)
            fiu[i] = nullptr;
    }
};

void adaugaCuvant(nod * trie, string cuvant, int lit = 0) {
    if(lit < cuvant.size()) {
        char literaCurenta = cuvant[lit];
        if(trie -> fiu[literaCurenta - 'a'] == nullptr) {
            trie -> fiu[literaCurenta - 'a'] = new nod;
            trie -> nrfii ++;
        }
        adaugaCuvant(trie -> fiu[literaCurenta - 'a'], cuvant, lit + 1);
    } else {
        // am terminat de parcurs tot cuvantul
        trie -> cnt ++; // crestem frecventa in nodul in care am ajuns
    }
}

int aparitiiCuvant(nod *trie, string cuvant, int lit = 0) {
    if(lit < cuvant.size()) {
        char literaCurenta = cuvant[lit];
        if(trie -> fiu[literaCurenta - 'a'] == nullptr) {
            return 0;
        }
        return aparitiiCuvant(trie -> fiu[literaCurenta - 'a'], cuvant, lit + 1);
    } else {
        return trie -> cnt;
    }
}

int stergeCuvant(nod * trie, string cuvant, int lit = 0) {
    if(lit < cuvant.size()) {
        char literaCurenta = cuvant[lit];
        if(trie -> fiu[literaCurenta - 'a'] == nullptr) {
            return 0;
        }
        int stersFiu = stergeCuvant(trie -> fiu[literaCurenta - 'a'], cuvant, lit + 1);
        if(stersFiu == 1) {
            trie -> nrfii --;
            trie -> fiu[literaCurenta - 'a'] = nullptr;
        }
    } else {
        trie -> cnt --;
    }
    if(trie -> cnt == 0 && trie -> nrfii == 0) {
        delete trie;
        return 1; // semnifica stergerea nodului
    }
    return 0; // nu am sters nodul
}

int prefixCuvant(nod * trie, string cuvant, int lit = 0, int nivel = 0) {
    if(lit < cuvant.size()) {
        char literaCurenta = cuvant[lit];
        if(trie -> fiu[literaCurenta - 'a'] == nullptr) {
            return nivel;
        }
        return prefixCuvant(trie -> fiu[literaCurenta - 'a'], cuvant, lit + 1, nivel + 1);
    } else {
        return nivel;
    }
}
int op;
string cuvant;
int main() {
    nod * trie = new nod;
//    adaugaCuvant(trie, "lat");
//    cout << aparitiiCuvant(trie, "lat") << '\n';
//    adaugaCuvant(trie, "lat");
//    adaugaCuvant(trie, "lat");
//    cout << aparitiiCuvant(trie, "lat") << '\n';
//    stergeCuvant(trie, "lat");
//    cout << aparitiiCuvant(trie, "lat") << '\n';
//    cout << prefixCuvant(trie, "larma");
    while(fin >> op >> cuvant) {
        if(op == 0) {
            adaugaCuvant(trie, cuvant);
        } else if(op == 1) {
            stergeCuvant(trie, cuvant);
        } else if(op == 2) {
            fout << aparitiiCuvant(trie, cuvant) << '\n';
        } else if(op == 3) {
            fout << prefixCuvant(trie, cuvant) << '\n';
        }
    }
    return 0;
}