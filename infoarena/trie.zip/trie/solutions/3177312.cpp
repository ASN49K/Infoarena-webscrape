#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
ifstream fin("trie.in");
ofstream fout("trie.out");

int trie[200001][26];
int pos=1;
int isword[200001];
int cnt[200001];
int main()
{
    int t;
    string s;
    while(fin >> t >> s)
    {
        if(t==0)
        {
            int p=1;
            for(int i=0;i<s.size();i++)
            {
                int c= s[i]-'a';
                if(trie[p][c])
                {
                    p = trie[p][c];
                }
                else
                {
                    trie[p][c]=++pos;
                    p=trie[p][c];
                }
                cnt[p]++;
            }
            isword[p]++;
        }
        if(t==1)
        {
            int p=1;
            for(int i=0;i<s.size();i++)
            {
                int c = s[i]-'a';
                p=trie[p][c];
                cnt[p]--;
            }
            if(p)isword[p]--;
            //cout << p << " ";
        }
        if(t==2)
        {
            int p=1;
            for(char i : s)
            {
                int c=i-'a';
                p = trie[p][c];
            }
            fout << isword[p] << "\n";
        }
        if(t==3)
        {
            int p=1,k=0;
            for(char i : s)
            {
                int c=i-'a';
                p=trie[p][c];
                if(cnt[p])k++;
                else
                {
                    break;
                }
            }
            fout << k << "\n";
        }
    }


}

