#include <bits/stdc++.h>

using namespace std;

ifstream fin ("trie.in");
ofstream fout ("trie.out");

unordered_map <string, int> mp;

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n; string word;
    while (fin>>n>>word) {
        if (n==0) mp[word]++;
        if (n==1) mp[word]--;
        if (n==2) {
            //cout<<2<<' '<<word<<' '<<mp[word]<<endl;
            fout<<mp[word]<<'\n';
        }
        if (n==3) {
            int maxi_siz=0; string bword="";
            for (auto it=mp.begin(); it!=mp.end(); it++) {
                if (it->second==0) continue;
                int siz=0;
                string new_word=it->first;
                while (word[siz]==new_word[siz]) siz++;
                if (siz>maxi_siz) {
                    maxi_siz=siz;
                    bword=new_word;
                }
            } 
            //cout<<3<<' '<<word<<' '<<bword<<endl;
            fout<<maxi_siz<<'\n';
        }
    }
    return 0;
}