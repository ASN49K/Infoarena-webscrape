#include <fstream>
#include <string>

using namespace std;

struct Node {
    int wordCount;
    int prefixCount;
    Node* children[26]{};

    Node() {
        wordCount = 0;
        prefixCount = 0;
        for (auto & i : children)
            i = nullptr;
    }
};

class Trie {
    Node* root;

    void clear(Node* node) {
        if (node == nullptr) return;
        for (auto & i : node->children) {
            if (i != nullptr) {
                clear(i);
            }
        }
        delete node;
    }

public:
    Trie() {
        root = new Node();
    }
    ~Trie() {
        clear(root);
    }

    void insert(const string& word) {
        Node* currNode = root;
        currNode->prefixCount++;

        for (char c : word) {
            const int index = c - 'a';
            if (currNode->children[index] == nullptr)
                currNode->children[index] = new Node();

            currNode = currNode->children[index];
            currNode->prefixCount++;
        }
        currNode->wordCount++;
    }

    void remove(const string& word) {
        Node* currNode = root;
        currNode->prefixCount--;

        for (char c : word) {
            const int index = c - 'a';
            Node* nextNode = currNode->children[index];
            nextNode->prefixCount--;

            if (nextNode->prefixCount == 0) {
                clear(nextNode);
                currNode->children[index] = nullptr;
                return;
            }
            currNode = nextNode;
        }
        currNode->wordCount--;
    }

    int count(const string& word) const
    {
        Node* currNode = root;
        for (char c : word) {
            const int index = c - 'a';
            if (currNode->children[index] == nullptr)
                return 0;
            currNode = currNode->children[index];
        }
        return currNode->wordCount;
    }

    int longestCommonPrefix(const string& word) const
    {
        Node* currNode = root;
        int length = 0;
        for (char c : word) {
            const int index = c - 'a';
            if (currNode->children[index] == nullptr)
                break; // Path ends
            currNode = currNode->children[index];
            length++;
        }
        return length;
    }
};

int main() {
    ifstream fin("trie.in");
    ofstream fout("trie.out");

    Trie trie;
    int operation;
    string word;

    while (fin >> operation >> word) {
        switch (operation) {
            case 0:
                trie.insert(word);
                break;
            case 1:
                trie.remove(word);
                break;
            case 2:
                fout << trie.count(word) << '\n';
                break;
            case 3:
                fout << trie.longestCommonPrefix(word) << '\n';
                break;
            default: ;
        }
    }
    return 0;
}