#include <bits/stdc++.h>

using namespace std;

ifstream in("trie.in");
ofstream out("trie.out");

const int alpha = 26;

struct Trie {
  int endWord;
  int cnt;
  Trie *child[alpha];
  Trie() {
    for (int i = 0; i < alpha; i++) {
      child[i] = nullptr;
    }
    endWord = cnt = 0;
  }
};

int m;

char s[alpha];

Trie *root = new Trie;

void add(Trie *root, char *s) {
  Trie *currNode = root;
  int n = strlen(s);
  for (int i = 0; i < n; i++) {
    if (currNode -> child[s[i] - 'a'] == nullptr) {
      currNode -> child[s[i] - 'a'] = new Trie;
    }
    currNode -> child[s[i] - 'a'] -> cnt++;
    currNode = currNode -> child[s[i] - 'a'];
  }
  currNode -> endWord++;
}

int countOcc(Trie *root, char *s) {
  Trie *currNode = root;
  int n = strlen(s);
  for (int i = 0; i < n; i++) {
    if (currNode -> child[s[i] - 'a'] == nullptr) {
      return 0;
    }
    currNode = currNode -> child[s[i] - 'a'];
  }
  return currNode -> endWord;
}

int longestPrefix(Trie *root, char *s) {
  Trie *currNode = root;
  int n = strlen(s);
  for (int i = 0; i < n; i++) {
    if (currNode -> child[s[i] - 'a'] == nullptr) {
      return i;
    }
    currNode = currNode -> child[s[i] - 'a'];
  }
  return n;
}

void del(Trie *root, char *s) {
  root -> cnt--;
  if (s[0] == '\0') {
    root -> endWord--;
    return;
  }
  del(root -> child[s[0] - 'a'], s + 1);
  if (root -> child[s[0] - 'a'] -> cnt == 0) {
    Trie *node = root -> child[s[0] - 'a'];
    delete node;
    root -> child[s[0] - 'a'] = nullptr;
  }
}

int main() {
  int op;
  while (in >> op >> s) {
    if (op == 0) {
      add(root, s);
    } else if (op == 1) {
      del(root, s);
    } else if (op == 2) {
      out << countOcc(root, s) << "\n";
    } else {
      out << longestPrefix(root, s) << "\n";
    }
  }
  return 0;
}
