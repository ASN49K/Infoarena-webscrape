#include <fstream>

#include <vector>

#include <queue>

using namespace std;

ifstream fin ("bfs.in");

ofstream fout ("bfs.out");

void BFS (int n, vector<vector<int>>& v, int s, vector<bool>& vizitat, vector<int>& nivel) {

	queue<int> q;

	q.push(s);

	vizitat[s] = true;

	nivel[s] = 1;

	while (!q.empty()) {

		int nod = q.front();

		q.pop();

		for (int i = 0; i < v[nod].size(); ++i) {

			int vecin = v[nod][i];

			if (!vizitat[vecin]) {

				vizitat[vecin] = true;

				nivel[vecin] = nivel[nod] + 1;

				q.push(vecin);
			}
		}
	}
}

int main () {

	int n, m, s;

	fin >> n >> m >> s;

	vector<vector<int>> v (n + 1);

	for (int i = 1; i <= m; ++i) {

		int x, y;

		fin >> x >> y;

		v[x].push_back(y);
	}

	vector<bool> vizitat (n + 1);

	vector<int> nivel (n + 1);

	BFS (n, v, s, vizitat, nivel);

	for (int i = 1; i <= n; ++i)
		fout << nivel[i] - 1 << ' ';
	
	return 0;
}