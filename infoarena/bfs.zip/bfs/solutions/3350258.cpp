#include <bits/stdc++.h>
#define pi pair<int,int>
using namespace std;

ifstream fin ("bfs.in") ;
ofstream fout ("bfs.out") ;

queue < int > q ;
vector < int > g[100001] ;
bool sel[100001] ;
int d[100001] ;

void bfs ( int nod )
{
    q.push(nod) ;
    while ( ! q.empty() )
    {
        nod = q.front() ;
        q.pop() ;
        sel[nod] = 1 ;
        for ( auto it : g[nod] )
            if ( sel[it] == 0 )
            {
                d[it] = d[nod] + 1 ;
                q.push(it) ;
            }
    }
}

void solve ()
{
    int n , m , k ;
    fin >> n >> m >> k ;
    for ( int i = 1 ; i <= m ; i ++ )
    {
        int x , y ;
        fin >> x >> y ;
        g[x].push_back(y) ;
    }

    for ( int i = 1 ; i <= n ; i ++ )
        d[i] = -1 ;
    d[k] = 0 ;

    bfs ( k ) ;

    for ( int i = 1 ; i <= n ; i ++ )
        fout << d[i] << " " ;
}

int main()
{
    std :: ios_base :: sync_with_stdio ( false ) ;
    fin.tie(0) ;
    fout.tie(0) ;
    solve() ;

    return 0;
}
