#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s, dist[100005], viz[100005];
vector<int> G[100005];
queue<int> q;

void citire() {
    fin>>n>>m>>s;
    int x, y;
    for (int i=1; i<=m; i++) {
        fin>>x>>y;
        G[x].push_back(y);
    }
}

void bfs(int st) {
    viz[st]=1;
    q.push(st);
    while (!q.empty()) {
        int x=q.front();
        q.pop();
        for (auto i: G[x]) {
            if (viz[i]==0) {
                viz[i]=1;
                q.push(i);
                dist[i]=dist[x]+1;
            }
        }
    }
}

void afisare() {
    for (int i=1; i<=n; i++) {
        if (dist[i]==0 && i!=s)
            fout<<"-1"<<" ";
        else
            fout<<dist[i]<<" ";
    }
}

int main() {
    citire();
    bfs(s);
    afisare();
    return 0;
}