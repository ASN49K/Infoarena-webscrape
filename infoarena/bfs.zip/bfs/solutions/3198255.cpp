#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int INF = 1e9;

void bfs(int source, const vector<vector<int>>& graph, vector<int>& distances) {
    queue<int> q;
    q.push(source);
    distances[source] = 0;

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        for (int neighbor : graph[current]) {
            if (distances[neighbor] == INF) {
                distances[neighbor] = distances[current] + 1;
                q.push(neighbor);
            }
        }
    }
}

int main() {
    int N, M, S;
    fin >> N >> M >> S;

    vector<vector<int>> graph(N + 1);
    vector<int> distances(N + 1, INF);

    for (int i = 0; i < M; ++i) {
        int u, v;
        fin >> u >> v;
        graph[u].push_back(v);
    }

    bfs(S, graph, distances);

    for (int i = 1; i <= N; ++i) {
        if (distances[i] == INF) {
            fout << -1 << " ";
        } else {
            fout << distances[i] << " ";
        }
    }

    return 0;
}
