#include <iostream>
#include <queue>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");


const int nmax = 100005;
vector<long long> dp(nmax, -1);
vector<int> a[nmax];
bool viz[nmax];
int n, m, s;

queue<int> q;

void bfs(int start){
    
    q.push(start);
    viz[start] = 1;
    while(!q.empty()){
        int node = q.front();
        q.pop();
        for(int vec : a[node]){
            if(viz[vec] == 0){
                viz[vec] = 1;
                dp[vec] = dp[node] + 1;
                q.push(vec);
            }
        }
        
    }
    
}
int main(){

    f >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        int x, y;
        f >> x >> y;
        a[x].push_back(y);
    }
    dp[s] = 0;
    bfs(s);
    for(int i = 1; i <= n; i++){
        g << dp[i] << ' ';
    }
}