#include <fstream>
#include <vector>
#include <queue>

using std::vector;

struct Node{
    vector<int> edges;
    int utHossz;
    Node(){
        utHossz = -1;
    }
    void addEdge(int x){
        edges.push_back(x);
    }
    int nrEdges(){
        return edges.size();
    }
};

int main(){
    std::ifstream bem("bfs.in");
    std::ofstream kim("bfs.out");
    int n, m, s;
    bem >> n >> m >> s;
    vector<Node> nodes(n);
    for(int i = 0; i < m; i++){
        int x, y;
        bem >> x >> y;
        x--;
        y--;
        nodes[x].addEdge(y);
    }
    bem.close();

    nodes[s - 1].utHossz = 0;
    std::queue<Node> varoLista;
    varoLista.push(nodes[s - 1]);
    
    while(!varoLista.empty()){
        Node jelenlegi = varoLista.front();
        varoLista.pop();
        for(int i = 0; i < jelenlegi.nrEdges(); i++){
            if(nodes[jelenlegi.edges[i]].utHossz == -1){
                nodes[jelenlegi.edges[i]].utHossz = jelenlegi.utHossz + 1;
                varoLista.push(nodes[jelenlegi.edges[i]]);
            }
        }
    }
    for(int i = 0; i < n; i++)
        kim << nodes[i].utHossz << ' ';
}