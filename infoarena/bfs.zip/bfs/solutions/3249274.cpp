#include <iostream>
#include <queue>
#include <list>
#include <fstream>
#include <unordered_set>
#include <cstring>
#include <stdio.h>
using namespace std; 
ifstream in("bfs.in");
ofstream out("bfs.out");
struct nod
{
	int cost = -1;
	list <int> p;
}el[100005];
bool frecventa[100005];
void crearelista(nod el[], int n, int m,bool ordonat)
{
	int x1, x2;
	for (int i = 1; i <= m; i++)
	{
		in >> x1 >> x2;
		el[x1].p.push_back(x2);
		if (ordonat == 0)
			el[x2].p.push_back(x1);
	}
}
void afisarelista(nod el[], int n)
{
	for (int i = 1; i <= n; i++)
	{
		out << "Nodul " << i << " duce la urmatoarele noduri:" << '\n';
		for (auto p = el[i].p.begin(); p != el[i].p.end(); p++)
			out << *p << ' ';
		out << '\n';
	}
}
void clear(queue <int>& q1)
{
	std::queue<int> emp;
	swap(q1, emp);


};
bool alreadyvisited(int el, list<int> m)
{
	for (auto t = m.begin(); t != m.end(); t++)
		if (*t == el)
			return 1;
	return 0;
}
int BFS(nod el[], int pas, queue <int> q1,int n)
{
	int cnt = q1.size();
	int cnt2 = 0;
	int aux = 0;
	while (!q1.empty())
	{
		auto i = q1.front();
		q1.pop();
		if (frecventa[i] == 0)
		{
		frecventa[i] = 1;
			//std::cout << i << "!!!!" << '\n';
			for (auto t = el[i].p.begin(); t != el[i].p.end(); t++)
			{
				if(frecventa[*t]==0) {
				q1.push(*t);
				el[*t].cost = pas + 1;
				//std::cout << *t << ' ' << pas + 1 << '\n';
			}
			}
			//std::cout << '\n';
		}
		
	cnt2++;
	if (cnt2 == cnt)
	{
		cnt = q1.size();
		cnt2 = 0;
		pas += 1;
	}
}	
	return -1;
}

int main()
{
	int n, m, s;
	in >> n >> m >> s;
	crearelista(el, n, m, 1);
	//afisarelista(el, n);
	unordered_set <int> p;
	queue <int> q1;
	q1.push(s);
	BFS(el, 0, q1,n)<<' ';
	el[s].cost = 0;
	for (int i = 1; i <= n; i++)
		out << el[i].cost << ' ';

	


}