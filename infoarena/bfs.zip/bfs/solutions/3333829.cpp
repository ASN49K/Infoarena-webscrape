#include <fstream>
#include <vector>
#define nmax 100001
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");
int n,start;
int viz[nmax];
int c[nmax];
int inc,sf;

vector<int> a[nmax];//am declarat un vector cu nmax elemente de ti vector din stl cu 0 elemente de tip int numit a

void citire();
void afisare_lad();
void bfs(int x);

int main()
{
  int i;
    citire();
    bfs(start);
    for (i=1; i<=n; i++)
      fout<<viz[i]-1<<' ';

    return 0;
}
void citire()
{
  int i,m,x,y;
  fin>>n>>m>>start;
  for (i=0; i<m; i++)
  {
    fin>>x>>y;
    a[x].push_back(y);
  }
}
void bfs (int x)
//parcurge bfs graful incepad cu x
{
  int i;
  c[0]=x; inc=sf=0;//initializez coada cu vf de start
  viz[x]=1;//vizitez vf de start
  while (inc<=sf)
  {
    x=c[inc++];
    //parcurg vecinii lui x
    for (i=0; i<a[x].size(); i++)
      if (!viz[a[x][i]])
      {
        viz[a[x][i]]=1+viz[x];
        c[++sf]=a[x][i];
      }
  }
}
