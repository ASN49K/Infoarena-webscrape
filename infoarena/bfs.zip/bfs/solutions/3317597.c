#include <stdlib.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct Node{
  int val;
  struct Node* next;
}Node;

typedef struct S{
  int val;
  struct S* next;
}S;

int pop(Node* head){
  if(head == NULL){
    return -1;
  }
  if(head->next == NULL){
    int v = head->val;
    free(head);
    head = NULL;
    return v;
  }
  Node* new = head;
  int val = head->val;
  head = head->next;
  free(new);
  return val;
}

S* pushS(S* head, int val){
  if(head == NULL){
    S* new = (S*)malloc(sizeof(S));
    new->val = val;
    new->next = NULL;
    return new;
  }
  S* cp = head;
  while(cp->next){
    cp=cp->next;
  }
  S* new = (S*)malloc(sizeof(S));
  new->val = val;
  new->next = NULL;
  cp->next = new;
  return head;
}


Node* pushN(Node* head, int val){
  if(head == NULL){
    Node* newNode = (Node* )malloc(sizeof(Node));
    newNode->val = val;
    newNode->next = NULL;
    return newNode;
  }
  Node* cp = head;
  while(cp->next){
    cp=cp->next;
  }
  Node* newNode = (Node*)malloc(sizeof(Node));
  newNode->val = val;
  newNode->next = NULL;
  cp->next = newNode;
  return head;
}

S* popS(S* head){
  if(head == NULL){
    return NULL;
  }
  if(head->next == NULL){
    free(head);
    head = NULL;
    return head;
  }
  S* new = head->next;
  free(head);
  head = new;
  return new;
}

void bfs(int head, Node** vecini, int distante[]){
  S* stiva = NULL;
  distante[head] = 0;
  stiva = pushS(stiva, head);
  while(stiva != NULL){
    int actual = stiva->val;
    stiva = popS(stiva);
    Node* ac = vecini[actual];
    while(ac != NULL){
      if(distante[ac->val] < 0) {
        stiva = pushS(stiva, ac->val);
        distante[ac->val] = distante[actual]+1;
      }
      ac = ac->next;
    }
  }
}

void deleteList(Node* head){
  if(head == NULL){
    return;
  }
  if(head->next == NULL){
    free(head);
    return;
  }
  Node* next = head->next;
  while(next){
    free(head);
    head = next;
    next=next->next;
  }

}

void afisareList(Node* head){
  Node* cp = head;
  while(cp){
    printf("%d, ", cp->val);
    cp=cp->next;
  }
}


int main(){
  char path[] = "bfs.in";
  int n, m, s;
  FILE* file = fopen(path, "r");
  FILE* out = fopen("bfs.out", "w");
  fscanf(file, "%d %d %d", &n, &m, &s);
  Node** noduri = (Node**)malloc(sizeof(Node*)*(n+1));
  int* distante = (int*)malloc(sizeof(int)*(n+1));

  for(int i = 1; i <= n; i++){
    noduri[i] = NULL;
    distante[i] = -1;
  }

  for(int i = 0; i < m; i++){
    int st, dr;
    fscanf(file, "%d %d", &st, &dr);
    noduri[st] = pushN(noduri[st], dr);
  }

  bfs(s, noduri, distante);
  for(int i = 1; i <= n; i++){
    fprintf(out, "%d ", distante[i]);
  }
  for(int i = 1; i <= n; i++){
    deleteList(noduri[i]);
  }
  return 0;
}
