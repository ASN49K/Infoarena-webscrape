#include <bits/stdc++.h>

using namespace std;

vector <int> L[100001];
ifstream f("bfs.in");
ofstream g("bfs.out");

int d[100000];
int BFS(int s) {
    queue<int>q;
    d[s] = 0;
    q.push(s);
    while (q.size() > 0) {
        int nod = q.front();
        q.pop();
        for (auto& vecin: L[nod]) {
            if (d[vecin] > d[nod] + 1) {
                d[vecin] = d[nod] +1;
                q.push(vecin);
            }
        }

    }
}
int main() {
    int n, m, s, x, y;
    cin >> n >> m >> s;
    for (int i = 1; i <= n; i++) {
        d[i] = INT_MAX;
    }
    for (int i=1; i<=m; i++) {
        cin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for (int i=1; i<=n; i++) {
        sort(L[i].begin(), L[i].end());
    }
    BFS(s);
    for (int i=1; i<=n;i++)
        cout << d[i] << " ";
    return 0;
}