#include<bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int v[100001], x[100001];
int main()
{
    queue<int> q;
    vector<int> a[1001];
    memset(x, -1, sizeof(x));
    int n, m, start, i, h, d, k = 10, ok = 0;
    fin >> n >> m >> start;
    for (i = 1; i <= m; i++) {
        fin >> d >> h;
        a[d].push_back(h);
    }
    q.push(start);
    v[start] = 1;
    x[start] = 0;
    for (i = 1; i <= n; i++) {
        sort(a[i].begin(), a[i].end());
    }
    while (!q.empty()) {
        k = q.front();
        for (auto e : a[k]) {
            if (v[e] == 0) {
                v[e] = 1;
                x[e] = x[k] + 1;
                q.push(e);
            }
        }
        q.pop();
    }
    for (int y = 1; y <= n; y++) {
        fout << x[y] << ' ';
    }
}