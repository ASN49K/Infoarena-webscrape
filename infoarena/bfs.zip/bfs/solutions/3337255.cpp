#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> dist;
vector<vector<int>> vec;
queue<int> coada;

void bfs(const int nod_de_start) {
    coada.push(nod_de_start);
    dist[nod_de_start] = 0;

    while (!empty(coada)) {
        curent = coada.front();
        coada.pop();

        for (int i : vec[curent]) {
            if (dist[i] == -1) {
                coada.push(i);
                dist[i] = dist[curent] + 1;
            }
        }
    }
}

int main() {
    int n, m, start;
    fin >> n >> m >> start;

    viz.resize(n + 1, -1);
    vec.resize(n + 1);

    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        vec[x].push_back(y);
    }

    bfs(start);

    for (int i = 1; i <= n; i++) {
        fout << dist[i] << " ";
    }
    fout << "\n";

    return 0;
}
