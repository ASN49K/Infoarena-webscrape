#include <bits/stdc++.h>
#define oo 2000000
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> g[100001];
int d[100001];
int n, m, S; /// d[i] = dist minima de la S la i

void Citire()
{
    int i, j, p;
    fin >> n >> m >> S;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        g[i].push_back(j);
    }
}

void BFS(int k)
{
    for (int i = 1; i <= n; i++)
        d[i] = oo;
    queue<int> q;
    q.push(k);
    d[k] = 0;
    while (!q.empty())
    {
        k = q.front();
        q.pop();
        for (int i : g[k])
            if (d[i] == oo)
            {
                d[i] = 1 + d[k];
                q.push(i);
            }
    }
}

void Afis()
{
    for (int i = 1; i <= n; i++)
    {
        if (d[i] == oo) d[i] = -1;
        fout << d[i] << " ";
    }
}

int main()
{
    Citire();
    BFS(S);
    Afis();
    return 0;
}
