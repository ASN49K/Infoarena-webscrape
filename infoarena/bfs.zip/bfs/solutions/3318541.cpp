#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<int> graf[100001];
int dist[100001];
int n,m,s;
void bfs(int start) {
    for (int i=1;i<=n;i++) {
        dist[i]=-1;

    }
    dist[start]=0;
    queue<int> q;
    q.push(start);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (int vecin : graf[nod]) {
            if (dist[vecin]==-1) {
                dist[vecin]=dist[nod] + 1;
                q.push(vecin);
            }
        }
    }
}
int main() {
    fin>>n>>m>>s;
    for (int i=0;i<m;i++) {
        int x, y;
        fin>>x>>y;
        graf[x].push_back(y);
    }
    bfs(s);
    for (int i=1;i<=n;i++) {
        fout<<dist[i]<< " ";
    }
    return 0;
}
