#include <iostream>
#include <vector>
#include <fstream>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int nmax = 100000;
vector<int> l[nmax + 1];
int n, m, s, x, y;
int distances[nmax + 1];

void bfs(int start) {
    vector<int> visited(n + 1, 0);
    queue<int> q;

    q.push(start);
    visited[start] = 1;
    distances[start] = 0;

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        for (int node : l[current]) {
            if (!visited[node]) {
                q.push(node);
                visited[node] = 1;
                distances[node] = distances[current] + 1;
            }
        }
    }
}

int main() {
    fin >> n >> m >> s;

    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        l[x].push_back(y);
    }

    for (int i = 1; i <= n; i++) {
        if (i != s) {
            bfs(i);
            fout << (distances[i] == 0 ? -1 : distances[i]) << " ";
        }
    }

    return 0;
}
