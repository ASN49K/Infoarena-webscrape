#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");



void BFS(int nod, vector<bool>& v, vector<vector<int>>& n,vector<int> &d,queue<int> &q) {
	v[nod] = true;
	for (int vecin : n[nod]) {
		if (not v[vecin]) {
			d[vecin] = d[nod] + 1;
			q.push(vecin);
		}
	}


}

int main()
{
	int n, m,s;
	fin >> n >> m>>s;
	int x, y;
	queue<int> q;
	vector<bool> visited(n+1,false);
	vector<int> distance(n + 1, -1);
	vector<vector<int>> noduri(n+1);
	for (int i = 0;i < m;i++)
	{
		fin >> x >> y;
		noduri[x].push_back(y);
		
	}
	q.push(s);
	distance[s] = 0;
	while (not q.empty()) {
		BFS(q.front(),visited,noduri,distance,q);
		q.pop();
	}
	distance[s] = 0;
	for (int i = 1;i <= n;i++)
		fout << distance[i] << ' ';
	
}

