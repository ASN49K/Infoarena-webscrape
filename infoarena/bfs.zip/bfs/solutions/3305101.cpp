#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int NMAX=1e5;
vector<int> mat[NMAX+5], distanta(NMAX+5,0);
void bfs(int nod){
    distanta[nod]=1;
    queue<int> q;
    q.push(nod);
    while(!q.empty()){
        nod=q.front();
        q.pop();
        for(int it:mat[nod]){
            if(distanta[it]==0){
                distanta[it]=distanta[nod]+1;
                q.push(it);
            }
        }
    }
}
int main(){
    int n, m, s;
    fin>>n>>m>>s;
    for(int i=1;i<=m;i++){
        int x, y;
        fin>>x>>y;
        mat[x].push_back(y);
    }
    bfs(s);
    for(int i=1;i<=n;i++){
        fout<<distanta[i]-1<<' ';
    }
}
