#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

const int N = 100000;

int n, m, k, x, y, d[N+1];
vector <int> l[N+1];
queue <int> q;

int main()
{
    in >> n >> m >> k;
    for (int i = 1; i <= m; ++i)
    {
        in >> x >> y;
        l[x].push_back(y);
    }
    for (int i = 1; i <= n; i++)
    {
        d[i] = -1;
    }
    d[k] = 0;
    q.push(k);
    while (!q.empty())
    {
        int nod = q.front();
        q.pop();
        for (int i = 0; i < l[nod].size(); i++)
        {
            int vec = l[nod][i];
            if (d[vec] == -1)
            {
                d[vec] = d[nod] + 1;
                q.push(vec);
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        out << d[i] << " ";
    }
    in.close();
    out.close();
    return 0;
}
