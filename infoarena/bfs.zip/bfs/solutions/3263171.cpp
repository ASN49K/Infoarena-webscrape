#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

long long n, m, s, viz[10002];
vector<vector<bool>> a;

void citire()
{
    a.resize(100002);
    for(int i=0; i<=100002; i++)
        a[i].resize(100002);
    fin>>n>>m>>s;
    for(int i=1; i<=m; i++){
        int x, y;
        fin>>x>>y;
        a[x][y]=1;
    }
    for(int i=1; i<=n; i++)
        viz[i] = -1;
}

void parc(int k)
{
    int x;
    queue<int> Q;
    Q.push(k);
    viz[k]=0;
    while(!Q.empty()){
        x = Q.front();
        Q.pop();
        for(int i=1; i<=n; i++)
            if(a[x][i]==1 && viz[i]==-1){
                Q.push(i);
                a[x][i]=0;
                viz[i] = viz[x]+1;
            }
    }
    for(int i=1; i<=n; i++)
        fout<<viz[i]<<" ";
}

int main()
{
    citire();
    parc(s);
}
