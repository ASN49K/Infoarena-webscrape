#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");	

struct Graph {
	vector<int> node;

	int len() {
		return node.size();
	}
}graph[100009];

int visited[100009];

int bfs(int n, Graph graph[], int start) {
	queue<int> q;
	vector<int> distance = vector<int>(n + 1, 0);
	memset(visited, -1, sizeof(int)* 100009);

	q.push(start);
	visited[start] = 0;

	while (q.size() != 0) {
		int vertex = q.front();
		q.pop();

		//if (visited[vertex] != -1)
			//continue;

		for (int i = 0; i < (int)graph[vertex].node.size(); ++i) {
			if (visited[graph[vertex].node[i]] == -1) {
				visited[graph[vertex].node[i]] = visited[vertex] + 1;
				q.push(graph[vertex].node[i]);
			}	
		}
	}
	return -1;
}

int n, m, s, x, y;

int main()
{
	fin >> n >> m >> s;
	for (int i = 0; i < m; i++) {
		fin >> x >> y;
		graph[x].node.push_back(y);
	}
	bfs(n, graph, s);
	for (int i = 1; i <= n; i++) {
		fout << visited[i] << " ";
	}
	return 0;
}