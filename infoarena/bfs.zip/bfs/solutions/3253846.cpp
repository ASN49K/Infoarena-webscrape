#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const string file_name = "bfs";

ifstream fin(file_name + ".in");
ofstream fout(file_name + ".out");

int main()
{
    int n, m, s;

    fin >> n >> m >> s;

    vector<vector<int>> graph(n + 1);

    for(int e = 0; e < m; e++)
    {
        int x, y;
        fin >> x >> y;
        graph[x].push_back(y);
    }

    vector<int> dist(n + 1, - 1);
    vector<int> visited(n + 1, 0);
    queue<int> q;

    dist[s] = 0;
    visited[s] = 1;
    q.push(s);
    
    while(!q.empty())
    {
        int node = q.front();
        q.pop();

        for(int neigh: graph[node])
        {
            if(visited[neigh] == 0)
            {
                visited[neigh] = 1;
                dist[neigh] = dist[node] + 1;
                q.push(neigh);
            }
        }
    }

    for(int i = 1; i <= dist.size() - 1; i++)
    {
        cout << dist[i] << ' ';
    }


   return 0;
}