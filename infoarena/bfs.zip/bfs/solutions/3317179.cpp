#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
std::ifstream in("bfs.in");
std::ofstream out("bfs.out");

const int NMAX = 100000;
std::queue<int> q;
std::vector<int> la[NMAX + 1];
int d[NMAX + 1];
void BFS(int nod, int n) {
    for(int i = 1; i <= n; i++)
        d[i] = -1;
    d[nod] = 0;
    q.push(nod);
    while(!q.empty())
    {
        nod = q.front();
        q.pop();
        for(int x : la[nod]) {
            if(d[x] == -1) {
                d[x] = d[nod] + 1;
                q.push(x); }
        }
    }


}

int main() {
    int n, m, s, x, y; 
    in >> n >> m >> s;
    for(int i = 0; i < m; i++) {
        in >> x >> y;
        la[x].push_back(y);
    }
    BFS(s,n);
    for(int i = 1; i <= n; i++)
        out << d[i] << " ";
    return 0;
}