#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream fin("deque.in");
ofstream fout("deque.out");

queue <long long int> q;
int vizitat[100001];
vector<vector<int>> conex;

int main()
{
    long unsigned int n, m, i, j, k, s,x;
    fin >> n >> m >> s;

    conex.resize(n + 1);

    for (i = 0; i < m; i++)
    {
        fin >> j >> k;
        conex[j].push_back(k);
    }

    q.push(s);
    vizitat[s] = 1;
    while (!q.empty())
    {
        x = q.front();
        q.pop();
        for (i = 0; i < conex[x].size(); i++)
        {
            if (vizitat[conex[x][i]] == 0)
            {
                vizitat[conex[x][i]] = vizitat[x] + 1;
                q.push(conex[x][i]);
            }
        }
    }

    for (i = 1; i <= n; i++)
    {
        if (vizitat[i] == 0)
            fout << "-1 ";
        else if (i == s)
            fout << "0 ";
        else
            fout << vizitat[i] - 1 << ' '; // subtract 1 to get the correct distance
    }

    fout.flush();
    return 0;
}
