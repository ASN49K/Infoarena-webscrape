#include <iostream>
#include <vector>
#include <queue>

int main() {
  int N, M, S;
  std::cin >> N >> M >> S;
  
  std::vector<std::vector<int>> graph;
  std::vector<int> dist;

  graph.resize(N + 1);
  dist.resize(N + 1);
  std::fill(dist.begin(), dist.end(), -1);
  
  int x, y;
  for (int i = 0; i < M; i++) {
    std::cin >> x >> y;
    graph[x].push_back(y);
  }
  
  std::queue<int> q;
  q.push(S);
  dist[S] = 0;
  while (!q.empty()) {
    auto curr = q.front();
    q.pop();
    for (auto& next : graph[curr]) {
      if (dist[next] == -1) {
        q.push(next);
        dist[next] = dist[curr] + 1;
      }
    }
  }
  
  for (int i = 1; i <= N; i++) {
    std::cout << dist[i] << ' ';
  }
  std::cout << std::endl;
  return 0;
}
