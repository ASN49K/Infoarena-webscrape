#include <bits/stdc++.h>
using namespace std;

const int MAX = 100005;
vector<int> graph[MAX];
vector<int> dist;

void bfs(int node)
{
    queue<int> q;
    dist[node] = 1;
    q.push(node);
    while (!q.empty())
    {
        node = q.front();
        q.pop();
        for (int next : graph[node])
        {
            if (!dist[next])
            {
                dist[next] = dist[node]+1;
                q.push(next);
            }
        }
    }
}

int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    int n, m, k;
    cin >> n >> m >> k;
    dist.assign(n+1, 0);

    for (int i = 1; i <= m; ++i)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
    }

    bfs(k);
    for (int i = 1; i <= n; ++i)
        cout << dist[i]-1 << " ";

    return 0;
}
