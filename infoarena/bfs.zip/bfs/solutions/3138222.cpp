#include<bits/stdc++.h>
using namespace std;
ifstream F("bfs.in");
ofstream G("bfs.out");
vector<int> v[100001];
int i,j,n,s,c[100001],d[100001],p,q=1;
int main()
{
    for(F>>n>>i>>s;F>>i>>j;v[i].push_back(j));
    for(c[0]=s,d[s]=1;p<q;++p)
        for(int j:v[c[p]])
            if(!d[j])
                d[j]=d[c[p]]+1,c[q++]=j;
    for(i=1;i<=n;G<<d[i++]-1<<' ');
    return 0;
}
