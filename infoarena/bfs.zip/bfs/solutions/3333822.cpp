#include <fstream>

using namespace std;
ifstream fin("BFS.in");
ofstream fout ("BFS.out");
/////////////////////////////////////////
const int NMAX = 101;
int n, start;
bool A[NMAX][NMAX];

void afisare_mad();
void citire();
void dfs(int x);
int cc[NMAX]; //vix[x] = 1; daca x a fost ccitat
int nrc;
bool viz[NMAX];
void afisare_cc();
void bfs(int x);
int C[NMAX];
int inc, sf;
////////////////////////////////
int main()
{
    int i;
    citire();
    //  afisare_mad();
    bfs(start);
    return 0;
}

void citire()
{
    int i,m;
    int x,y;
    fin>>n>>m>>start;
    while(fin>>x>>y)
    {
        A[x][y] = 1;
        A[y][x] = 1; //doar pentru graf neorientat
    }
}

void afisare_mad()
{
    for (int i =1; i<=n; i++)
    {

        for (int j=1; j<=n; j++)
        {
            fout<<A[i][j]<<' ';
        }
        fout<<'\n';
    }
}

void dfs(int x) //parcurg graful incepand din varful x
{
    int i;
    cc[x] = nrc;
    //parcurg vecinii lui x
    for(i = 1; i<=n; i++)
        if(A[x][i] && !cc[i]) //exista (x,i)/[x,i]
            dfs(i);
}
void afisare_cc()
{
    fout<<nrc<<'\n';
    for (int i=1; i<=nrc; i++)
    {
        for (int j=1; j<=n; j++)
        {
            if (cc[j] == i)
                fout<<j<<' ';
        }
        fout<<'\n';
    }
}

void bfs(int x) //parcurge BFS graful incepand din x
{
    C[0] = x; inc = sf = 0; viz[x] = 1; fout<<x<<' ';
    while (inc <=sf)
    {
        x = C[inc++];
        //parcurg vecinii lui x
        for ( int i=1; i<=n; i++)
        {
            if (A[x][i] && !viz[i])
            {
                viz[i] = 1; fout<<i<<' ';
                C[++sf] = i;
            }
        }
    }
}
