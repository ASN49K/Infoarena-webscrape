#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int maxn = 100005;

vector<int> g[maxn];
int dist[maxn];

void bfs(int start) {
    queue<int> coada;
    coada.push(start);
    dist[start] = 0;
    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        for (int j = 0; j < g[nod].size(); ++j) {
            int vecin = g[nod][j];
            if (dist[vecin] == -1) {
                coada.push(vecin);
                dist[vecin] = dist[nod] + 1;
            }
        }
    }
}

int main() {
    ifstream in("bfs.in");
    ofstream out("bfs.out");
    int n, m, start;
    in >> n >> m >> start;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        in >> x >> y;
        g[x].push_back(y);
    }
    for (int i = 1 ; i <= n; ++i)
        dist[i] = -1;
    bfs(start);
    for (int i = 1; i <= n; ++i)
        out << dist[i] << " ";
    return 0;
}
