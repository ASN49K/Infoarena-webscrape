#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream reader("bfs.in");
ofstream writer("bfs.out");

vector<int> lista[100001]; 
int dist[100001];

void BFS(int start);

int main(){
    int n, m, s;
    reader>>n>>m>>s;
    for(int i=1; i<=n; i++)
        dist[i]=-1; 
    for(int i=0; i<m; i++){
        int a, b;
        reader>>a>>b;
        lista[a].push_back(b); 
    }

    BFS(s);
    for(int i=1; i<=n; i++)
        writer<<dist[i]<<" ";
    
    return 0;
}

void BFS(int start){
    queue<int> q;
    q.push(start);
    dist[start]=0;

    while(!q.empty()){
        int nod=q.front();
        q.pop();

        for(int i=0; i<lista[nod].size(); i++){
            int vecin = lista[nod][i];
            if(dist[vecin] == -1){
                dist[vecin]=dist[nod]+1;
                q.push(vecin);
            }
        }
    }
}
