#include<fstream>
#include<list>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int main() 
{

    int n, m, s;
    fin >> n >> m >> s;

    vector< vector<int> > adj(n + 1);
    adj.reserve(n + 1);

    for (int i = 0; i < m; ++i) 
    {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }


    vector<int> dist(n + 1, -1);
    queue<int> q;

    dist[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int u = q.front(); 
        q.pop();
        for (int v : adj[u]) 
        {
            if (dist[v] == -1) 
            {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }

    for (int i = 1; i <= n; ++i) 
        fout << dist[i] << " ";

    return 0;
}
