#include <fstream>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,op,s,i,j,v[10001][10001],coada[100001],pret[100001],x,y,lungime,ok[100001];
int main()
{
    fin>>n>>op>>s;
    for(i=1;i<=op;i++)
        {fin>>x>>y;
        v[x][y]=1;}
    i=1;
    lungime=1;
    coada[1]=s;
    pret[s]=0;
    ok[s]=1;
    do{
        for(j=1;j<=n;j++)
            if(v[coada[i]][j]==1 && ok[j]==0)
        {lungime++;
         coada[lungime]=j;
         if(pret[j]==0)pret[j]=pret[coada[i]]+1;
         else  pret[j]=min(pret[j],pret[coada[i]]+1);
         ok[j]=1;
        }
     i++;
    }while(i<=lungime);
    for(i=1;i<=n;i++)
    {if(pret[i]==0 && i!=s)fout<<"-1"<<" ";
        else fout<<pret[i]<<" ";}
    return 0;
}
