#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

void bfs(vector<vector<int>>& adj, int start, vector<int>& visited, queue<int>& q) {
    visited[start] = 0;
    q.push(start);
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (int neighbor : adj[node]) {
            if (visited[neighbor] < 0) {
                visited[neighbor] = visited[node] + 1;
                q.push(neighbor);
            }
        }
    }
}

int main() {
    vector<vector<int>> adj;
    int n, m, start;
    fin >> n >> m >> start;
    adj.resize(n + 1);
    for (int i = 0; i < m; ++i) {
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
    }
    vector<int> visited(n + 1, -1);
    queue<int> q;
    bfs(adj, start, visited, q);
    for (int i = 1; i <= n; ++i) {
        fout << visited[i] << " ";
    }
    return 0;
}