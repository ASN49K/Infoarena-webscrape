#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");
const int NMAX = 100005;
std::vector <int> G[NMAX + 1];
int vis[NMAX + 1];
int d[NMAX + 1];

void BFS(int x)
{
    std::queue<int> q;
    q.push(x);
    vis[x] = 1;
    d[x] = 0;
    while(!q.empty())
    {
        x = q.front();
        q.pop();
        //std::cout << x << " ";
        for(auto next : G[x])
        {
            if(!vis[next])
            {
                vis[next] = 1;
                q.push(next);
                d[next] = d[x] + 1;
            }
        }
    }

}

int main()
{
    int n, m;
    int s;
    fin >> n >> m >> s;

    ///Liste de adiacenta
    for(int i = 1; i <= m; ++i)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        //G[y].push_back(x);
    }
    
    BFS(s);
    for(int i = 1; i <= n; ++i)
    {
        if(i == s)
            fout << 0 << " ";
        else if (d[i] == 0) 
            fout << -1 << " ";
        else
            fout << d[i] << " ";   
    }
    
    return 0;
}