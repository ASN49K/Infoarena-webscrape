#include <iostream>
#include <fstream>
#include <vector>
std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");
void bfs(int i,std::vector<std::vector<int>>& lista,std::vector<int> &dis,int nr){
    int ok=0;
    for(int j=0;j<lista[i].size();j++){
        if(dis[lista[i][j]]<0){
            dis[lista[i][j]]=nr;
            ok=1;
        }
    }
    if(ok==0){
        return;
    }
    for(int j=0;j<lista[i].size();j++){
        bfs(lista[i][j],lista,dis,nr+1);
    }
}
int main(){
    int n,m,s,x,y;
    fin>>n>>m>>s;
    std::vector<std::vector<int>> lista(n+1);
    std::vector<int> dis(n+1);
    for(int i=1;i<=n;i++){
        dis[i]=-1;
    }
    dis[s]=0;
    while(m){
        fin>>x>>y;
        if(x!=y){
            lista[x].push_back(y);
        }
        m--;
    }
    bfs(s,lista,dis,1);
    for(int i=1;i<=n;i++){
        fout<<dis[i]<<" ";
    }
    // for(int i=1;i<=n;i++){
    //     std::cout<<i<<" ";
    //     for(int j=0;j<lista[i].size();j++)
    //     {
    //         std::cout<<lista[i][j]<<" ";
    //     }
    //     std::cout<<"\n";
    // }
}