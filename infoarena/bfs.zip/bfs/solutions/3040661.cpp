#include <bits/stdc++.h>
using namespace std;
ifstream fin ("bfs.in"); 
ofstream fout ("bfs.out");

vector<int> a[100001];
int n,m,start,x,y;
int vizite[100001],distanta[100001];
queue<int> orase;
void BFS(int start){
    vizite[start]=1;
    distanta[start]=0;
    orase.push(start);
    while(!orase.empty()){
        int city=orase.front();
        for(auto vecin:a[city]){
            if (vizite[vecin]==0){
                vizite[vecin]=1;
                orase.push(vecin);
                distanta[vecin]=distanta[city]+1;
            }
        }
       orase.pop();
    }
}
int main()
{
    
    fin>>n>>m>>start;
    while(fin>>x>>y){
        a[x].push_back(y);
    }
    for(int i=1;i<=n;++i){
        sort(a[i].begin(),a[i].end());
    }
    for(int i=1;i<=n;++i){
        distanta[i]=-1;
    }
    BFS(start);
    for(int i=1;i<=n;++i){
        fout<<distanta[i]<<" ";
    }
    
    
    return 0;
}