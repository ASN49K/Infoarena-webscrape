#include <bits/stdc++.h>

using namespace std;

int n,m,s;
vector<vector<int>> arc;
vector<int> aleax;

int main () 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("bfs.in","r",stdin);
    freopen("bfs.out","w",stdout);
    cin>>n>>m>>s;
    arc.resize(n+1);
    for(int i=1; i<=m; i++)
    {
        int x,y;
        cin>>x>>y;
        arc[x].push_back(y);
        aleax.push_back(x);
    }
    vector<int> viz,numere;
    viz.resize(n+1,0);
    int ok=0;
    queue<int> q;
    viz[s]=true;
    q.push(s);
    vector<int>dist(n+1,-1);
    dist[s]=0;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(int it:arc[nod])
        {
            if(!viz[it])
            {
                viz[it]=true;
                if(dist[it]==-1)
                {
                    dist[it]=dist[nod]+1;
                }
                q.push(it);
            }
        }
    }   
    for(int i=1; i<=n; i++)
    {
        cout<<dist[i]<<" ";
    }
}