#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin( "bfs.in" );
ofstream fout( "bfs.out" );

const int N = 1e5;
vector <int> g[N];
int d[N];

int distanta ( int s ) {
    
    queue <int> q;
    q.push (s);
    d[s] = 1;
    
    while ( q.size() > 0 ) {
        
        int x = q.front ();
        
        for ( int i = 0; i < g[x].size(); i++ )
            if ( d[g[x][i]] == 0 ) {
                d[g[x][i]] = d[x] + 1;
                q.push ( g[x][i] );
            }
        
        q.pop ();
    }
    
    return 0;
}

int main() {
    
    int n, m, s, i, a, b;
    
    fin >> n >> m >> s;
    
    for ( i = 0; i < m; i++ ) {
        fin >> a >> b;
        g[a].push_back (b);
    }
    
    distanta (s);
    
    for ( i = 1; i <= n; i++ )
        fout << d[i] - 1 << " ";
    
    
    return 0;
}
