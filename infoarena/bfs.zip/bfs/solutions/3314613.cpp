#include <bits/stdc++.h>
using namespace std;

vector<int> L[100001];
int d[100001];
 int n, m, s;

void bfs(int s) {
    queue<int> q;
    for(int i = 1; i <= n; i++) {
        d[i] = 1e9;
    }
    d[s] = 0;
    q.push(s);
    while(!q.empty()) {
        int nod = q.front();
        q.pop();
        for(int i = 0; i < L[nod].size(); i++) {
            int vecin = L[nod][i];
            if(d[vecin] > d[nod] + 1) {
                d[vecin] = d[nod] + 1;
                q.push(vecin);
            }
        }
    }
}

int main() {
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
   
    cin >> n >> m >> s;
    for(int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        L[x].push_back(y);
        //L[y].push_back(x);
    }
    bfs(s);
    for(int i = 1; i <= n; i++) {
        if(d[i] == 1e9) {
            cout << -1 << ' ';
        } else {
            cout << d[i] << ' ';
        }
    }
}