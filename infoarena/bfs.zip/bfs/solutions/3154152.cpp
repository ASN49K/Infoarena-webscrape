#include <fstream>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int N,M,S;
vector<int>G[100001];
int d[100001];
bool vis[100001];

int notVisited(){
    for(int i=1; i<=N; i++){
        if(vis[i]==0){
            return i;
        }
    }
    return 0;
}

void bfs(int x){
    d[x]=0;
    queue<int>q;
    q.push(x);
    while(!q.empty()){
        x=q.front();
        q.pop();
        vis[x]=1;
        //cout<<x;
        for(auto next:G[x]){
            if(!vis[next]){
                q.push(next);
                d[next]=d[x]+1;
                vis[next]=1;
            }
        }
    }
}

int main(){
    fin>>N>>M>>S;
    for(int i=0; i<M; i++){
        int x,y;
        fin>>x>>y;
        G[x].push_back(y);
    }
    bfs(S);
    for(int i=1; i<=N; i++){
        if(i==S){
            fout<<0<<' ';
        } else if(d[i]==0){
        fout<<-1<<' ';} else{
    fout<<d[i]<<' ';
        }
    }
    return 0;
}
