#include<bits/stdc++.h>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

struct graf{
    vector<int>vec;
    int nr=0, dist=-1;
};

void bfs(vector<graf>&G, int poz, int cnt){
    if(G[poz].dist<=cnt && G[poz].dist!=-1){
        return;
    }
    G[poz].dist=cnt;
    
    //cout<<"Am vizitat nodul "<<poz<<" si i-am dat dist "<<cnt<<"\n";
    
    cnt++;
    for(int i=0; i<G[poz].nr;i++){
        bfs(G, G[poz].vec[i],cnt);
    }
}

int main(){
    long long n, m, s, aux1, aux2;
    in>>n>>m>>s;
    vector<graf>G(n);
    // cout<<"test";
    
    for(int i=0;i<m;i++){
        in>>aux1>>aux2;
        G[aux1-1].vec.push_back(aux2-1);
        G[aux1-1].nr++;
    }
    
    bfs( G, s-1, 0);
    
    for(int i=0;i<n;i++){
        out<<G[i].dist<<" ";
    }
    
    
    
    
    
    
    
    
    
    
    /*for(int i=0;i<n;i++){
        for(int j=0;j<G[i].nr;j++){
            out<<G[i].vec[j]<<" ";
        }
        out<<"\n";
    }
    */
}