#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int Nmax = 100005;

int n, m, s;
int dis[Nmax];
vector<int> L[Nmax];
queue<int> Q;

void bfs() {
    int nod;
    while(!Q.empty()) {
        nod = Q.front();
        Q.pop();
        for(int vec : L[nod]) {
            if(dis[vec] > dis[nod] + 1) {
                dis[vec] = dis[nod] + 1;
                Q.push(vec);
            }
        }
    }
}

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");
    fin >> n >> m >> s;
    while(m--) {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
    }
    for(int i = 1; i <= n; i++) {
        dis[i] = INT_MAX;
    }
    Q.push(s);
    dis[s] = 0;
    bfs();
    for(int i = 1; i <= n; i++) {
        if(dis[i] == INT_MAX) {
            fout << "-1" << " ";
        }
        else {
            fout << dis[i] << " ";
        }
    }
    
    return 0;
}