#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int N = 1e5;

int main()
{
    ifstream in("bfs.in");
    ofstream out("bfs.out");
    int n, m, x0;
    in >> n >> m >> x0;
    vector < vector<int> > s(n+1);
    for (int i = 1; i <= m; i++){
        int x, y;
        in >> x >> y;
        s[x].push_back(y);
    }
    vector <int> d(n+1, -1);
    queue <int> q;
    d[x0] = 0;
    q.push(x0);
    while (!q.empty()){
        int x = q.front();
        q.pop();
        for (auto y: s[x]){
            if (d[y] == -1){
                d[y] = 1 + d[x];
                q.push(y);
            }
        }
    }
    for (int i = 1; i <= n; i++){
        out << d[i] << " ";
    }
    in.close();
    out.close();
    return 0;
}
