#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int noduri, muchii, sursa;
vector<int> vecini[100001];
int distante[100001];
void bfs(){
    queue<int> q;
    q.push(sursa);
    distante[sursa] = 0;
    while (!q.empty()){
        int front = q.front();
        q.pop();
        for (int i = 0; i < vecini[front].size(); i++){
            int vecin = vecini[front][i];
            if (distante[vecin] == 0 && vecin != sursa){
                distante[vecin] = distante[front] + 1;
                q.push(vecin);
            }
        }
    }
}
int main(){
    fin >> noduri >> muchii >> sursa;
    for (int i = 1; i <= muchii; i++){
        int x, y;
        fin >> x >> y;
        vecini[x].push_back(y);
    }
    bfs();
    for (int i = 1; i <= noduri; i++){
        if (distante[i] == 0 && i != sursa)
            fout << -1 << " ";
        else
            fout << distante[i] << " ";
    }
    return 0;
}