#include <fstream>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int N,M,S;
vector<int>G[100001];
int d[100001];
bool vis[100001];

int notVisited(){
    for(int i=1; i<=N; i++){
        if(vis[i]==0){
            return i;
        }
    }
    return 0;
}

void bfs(int x){
    queue<int>q;

    q.push(x);
    while(!q.empty()){
        x=q.front();
        vis[x]=1;
        //cout<<x;
        q.pop();
        for(auto next:G[x]){
            if(!vis[next]){
                q.push(next);
                d[next]=d[x]+1;
            }
        }
    }
}

int main(){
    fin>>N>>M>>S;
    for(int i=0; i<M; i++){
        int x,y;
        fin>>x>>y;
        G[x].push_back(y);
    }
    d[S]=0;
    bfs(S);
    for(int i=1; i<=N; i++){
        if(!vis[i]){
            d[i]=-1;
        }
    }
    for(int i=1; i<=N; i++){
        fout<<d[i]<<' ';
    }
    return 0;
}
