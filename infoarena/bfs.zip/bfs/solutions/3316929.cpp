#include <bits/stdc++.h>

using namespace std;

vector <int> L[100001];
ifstream f("bfs.in");
ofstream g("bfs.out");

int d[100001];
int n, m, s;
void BFS(int s) {
    queue<int>q;
for (int i = 1; i <= n; i++) {
        d[i] = -1;
    }
    d[s] = 0;
    q.push(s);
    while (q.size() > 0) {
        int nod = q.front();
        q.pop();
        for (auto& vecin: L[nod]) {
            if (d[vecin] == -1) {
                d[vecin] = d[nod] +1;
                q.push(vecin);
            }
        }

    }
}
int main() {
    int x, y;
    f >> n >> m >> s;
   
    for (int i=1; i<=m; i++) {
        f >> x >> y;
        L[x].push_back(y);
    }
for (int i = 1; i <= n; i++) {
        d[i] = -1;
    }
    for (int i=1; i<=n; i++) {
        sort(L[i].begin(), L[i].end());
    }
    BFS(s);
    for (int i=1; i<=n;i++)
        g << d[i] << " ";
    return 0;
}