#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
vector<vector<int>> adj;
vector<int> dist;
vector<bool> viz;
void BFS(int start)
{
    queue<int> q;
    dist[start] = 0;
    viz[start] = 1;
    q.push(start);
    while(!q.empty())
    {
        int vf = q.front();
        q.pop();
        for(int vecin:adj[vf])
            if(!viz[vecin])
            {
                q.push(vecin);
                dist[vecin] = dist[vf]+1;
                viz[vecin] = true;
            }
    }
}
int main()
{
    int n,m,s;
    cin>>n>>m>>s;
    adj.resize(n+1);
    dist.resize(n+1);
    fill(dist.begin(),dist.end(),-1);
    viz.resize(n+1);
    fill(viz.begin(),viz.end(),false);
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        adj[x].push_back(y);
    }
    BFS(s);
    for(int i=1;i<=n;i++)
        cout<<dist[i]<<' ';
    return 0;
}
