// https://www.infoarena.ro/problema/bfs
#include <fstream>
#include <queue>
#include <vector>

constexpr int MaxNoduri = 100001;

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
int numarNoduri, numarMuchii, nodStart, nod1, nod2, indice;
vector<int> listaAdiacenta[MaxNoduri];
queue<int> coada;
int distanta[MaxNoduri];

int main() {
    fin >> numarNoduri >> numarMuchii >> nodStart;
    for (indice = 1; indice <= numarMuchii; indice++) {
        fin >> nod1 >> nod2;
        listaAdiacenta[nod1].push_back(nod2);
    }
    for (indice = 1; indice <= numarNoduri; indice++)
        distanta[indice] = -1;
    coada.push(nodStart);
    distanta[nodStart] = 0;
    while (not coada.empty()) {
        int nodCurent = coada.front();
        for (int vecin : listaAdiacenta[nodCurent]) 
            if (distanta[vecin] == -1) {
                coada.push(vecin);
                distanta[vecin] = distanta[nodCurent] + 1;
            }
        coada.pop();
    }
    for (indice = 1; indice <= numarNoduri; indice++)
        fout << distanta[indice] << ' ';
    return 0;
}