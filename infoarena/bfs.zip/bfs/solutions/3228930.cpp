#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin ("bfs.in");
ofstream cout ("bfs.out");

int n,m,s,i,a[100005],k,x,y;
vector<int>v[100005];
queue<int>q;

void bfs(int s)
{
    a[s]=1;
    q.push(s);
    while(!q.empty())
    {
        int x=q.front();
        for(int i=0;i<v[x].size();i++)
        {
            k=v[x][i];
            if(a[k]==0)
            {
                a[k]=a[x]+1;
                q.push(k);
            }
        }
        q.pop();
    }
}
int main()
{
    cin>>n>>m>>s;
    for(i=1; i<=m; i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
    }
    bfs(s);
    for(i=1;i<=n;i++)
        cout<<a[i]-1<<' ';
    return 0;
}
