// https://www.infoarena.ro/problema/bfs - Szucs Patrik - Kevin
#include <fstream>
#include <queue>
#include <vector>

int main()
{
    int n, m, s;

    std::ifstream in("bfs.in");
    in >> n >> m >> s;

    std::vector<std::vector<int>> graf(n + 1);
    for (int i = 0; i < m; i++)
    {
        int a, b;
        in >> a >> b;

        graf[a].push_back(b);
    }
    in.close();

    std::queue<int> sor;
    std::vector<int> indx(n + 1, -1);

    sor.push(s);
    indx[s] = 0;

    while (!sor.empty())
    {
        int curr = sor.front(); // utoljara berakott elem - 1
        sor.pop();
        for (int i : graf[curr])
            if (indx[i] == -1)
            {
                indx[i] = indx[curr] + 1;
                sor.push(i);
            }
    }

    std::ofstream out("bfs.out");
    for (int i = 1; i <= n; i++)
        out << indx[i] << " ";

    out.close();
    return 0;
}