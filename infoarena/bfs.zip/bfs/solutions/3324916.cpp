#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<vector<int>> v(100100);
int w[100100];
int d[100100];
int n,m,s;
void BFS(int a){
    queue<int> q;
    q.push(a);
    w[a]=1;
    d[a]=0;
    while(!q.empty()){
    int r=q.front();
    for(auto e : v[r]){
        if(!w[e]){
        d[e]=d[r]+1;
        q.push(e);
        }
    }
    w[r]=1;
    q.pop();
    }

}
int main(){
    int a,b;
    fin>>n>>m>>s;
    for(int i=1; i<=m; i++){
        fin>>a>>b;
        v[a].push_back(b);
    }
    for(int i=1; i<=n; i++)
        d[i]=-1;
    BFS(s);
    for(int i=1; i<=n; i++){
        fout<<d[i]<<" ";
    }
    return 0;
}
