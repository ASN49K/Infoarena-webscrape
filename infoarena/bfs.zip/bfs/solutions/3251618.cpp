#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

int n,m,start,dist[100002];
const int INF=1e9+4;
vector <int> adj[100002];

void bfs(int x)
{
    queue <int> q;
    for(int i=1;i<=n;i++)
        dist[i]=INF;
    q.push(x);
    dist[x]=0;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto vec : adj[nod])
        {
            if(dist[vec]==INF)
            {
                dist[vec]=dist[nod]+1;
                q.push(vec);
            }
        }
    }
}

int main()
{
    int i,j;
    fin>>n>>m>>start;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
        {
            int x,y;
            fin>>x>>y;
            adj[x].push_back(y);
        }
    bfs(start);
    for(i=1;i<=n;i++)
    {
        if(dist[i]==INF) fout<<-1<<' ';
        else fout<<dist[i]<<' ';
    }
    return 0;
}
