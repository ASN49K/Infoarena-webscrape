#include <bits/stdc++.h>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 100005;
int n,m,s,dist[NMAX];
vector <int>Muchii[NMAX];
queue <int>q;

void bfs(){
    int nod,vecin;
    while(!q.empty()){
        nod=q.front();
        cout<<nod<<endl;
        q.pop();
        for(int i=0;i<Muchii[nod].size();i++){
            vecin=Muchii[nod][i];
            if(dist[vecin]==-1){
                q.push(vecin);
                dist[vecin]=dist[nod]+1;
            }
        }
    }
}

void Citire()
{
    fin>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        Muchii[x].push_back(y);
    }
}

int main()
{
    Citire();
    for(int i=1;i<=n;i++) dist[i]=-1;
    dist[s]=0;
    q.push(s);
    bfs();
    for(int i=1;i<=n;i++) fout<<dist[i]<<' ';
    return 0;
}
