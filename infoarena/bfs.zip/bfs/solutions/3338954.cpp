#include <bits/stdc++.h>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
int n,m,nr,x,y;
vector < int > v[100001];
int viz[100001];
void dfs(int nod)
{
  viz[nod]=1;
  for(int j=0; j<v[nod].size();j++)
  {
    int vec=v[nod][j];
    if(!viz[vec])
      dfs(vec);
  }
}
int main()
{f>>n>>m;
for(int i=1;i<=m;++i)
{
  f>>x>>y;
  v[x].push_back(y);
  v[y].push_back(x);
}
for(int i=1;i<=n;++i)
{
  if(!viz[i])
{nr++;
dfs(i);
}
}
g<<nr;
    return 0;
}
