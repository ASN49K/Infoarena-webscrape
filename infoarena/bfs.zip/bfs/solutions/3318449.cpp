//
// Created by h4rapa1b on 10/28/25.
//

#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");
    if (!fin.is_open()) return 1;

    int N, M, S;
    fin >> N >> M >> S;

    vector<vector<int>> graph;
    graph.resize(N + 1);

    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        if (x >= 1 && x <= N) graph[x].push_back(y);
    }

    vector<int> dist(N + 1, -1);
    queue<int> q;
    if (S >= 1 && S <= N) {
        dist[S] = 0;
        q.push(S);
    }

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : graph[u]) {
            if (dist[v] == -1) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }

    for (int i = 1; i <= N; ++i) {
        fout << dist[i] << (i == N ? '\n' : ' ');
    }

    return 0;
}