#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int main(){
    int n, m, nodStart;
    vector<vector<int>> veciniNod;
    vector<int> dist;
    queue<int> coada;

    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    /// Citeste numarul de varfuri, numarul de arce, varful de start, arcele
    fin >> n >> m >> nodStart;

    veciniNod.resize(n + 1);
    dist.resize(n + 1);

    /// Salveaza varfurile adiacente in veciniNod
    for (int i = 0; i < m; i++) {
        int nod1, nod2;
        fin >> nod1 >> nod2;
        veciniNod[nod1].push_back(nod2);
    }

    /// Varfurile nevizitate au distanta -1
    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
    }

    /// Insereaza varful de start
    dist[nodStart] = 0;
    coada.push(nodStart);

    while (!empty(coada)) {
        int nodCurent = coada.front();
        coada.pop();

        for (int nodVecin : veciniNod[nodCurent]) {
            if (dist[nodVecin] == -1) {
                dist[nodVecin] = dist[nodCurent] + 1;
                coada.push(nodVecin);
            }
        }
    }

    /// Afiseaza distantele
    for (int i = 1; i <= n; i++) {
        fout << dist[i] << " ";
    }
    fout << "\n";

    return 0;
}
