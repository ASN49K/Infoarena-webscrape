#include <fstream>
#include <deque>
#include <vector>
using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

int viz[100001];
vector<vector<int>> v;

int main(){
    int n,m,s1,poz,next,i,a,b;
    cin>>n>>m>>s1;v.resize(n+1);
    for(i=0;i<m;i++){
        cin>>a>>b;
        v[a].push_back(b);
    }
    deque<int> s;
    s.push_back(s1);
    viz[s1]=1;
    while(!s.empty()){
        poz=s.front();s.pop_front();printf("%d ",poz);
        for(i=0;i<v[poz].size();i++){
            next=v[poz][i];
            if(!viz[next]){
                s.push_back(next);viz[next]=viz[poz]+1;
            }
        }
    }
    for(i=1;i<=n;i++) cout<<viz[i]-1<<" ";
    return 0;
}
