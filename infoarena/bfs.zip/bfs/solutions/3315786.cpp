#include <bits/stdc++.h>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s;
vector<int> L[100005];
int d[100005];

void bfs(int nod){
    queue<int> Q;
    for(int i = 1; i <= n; i++)
        d[i] = 1e9;
    Q.push(s);
    d[s] = 0;
    while(!Q.empty()){
        int nod = Q.front();
        Q.pop();
        for(int i = 0; i < L[nod].size(); i++){
            if(d[L[nod][i]] > d[nod] + 1){
                d[L[nod][i]] = d[nod] + 1;
                Q.push(L[nod][i]);
            }
        }
    }
}

int main(){
    fin >> n >> m >> s;
    for(int i = 0; i < m; i++){
        int a, b;
        fin >> a >> b;
        L[a].push_back(b);
    }
    bfs(s);
    for(int i = 1; i <= n; i++){
        if(d[i] == 1e9)
            fout << -1 << " ";
        else
            fout << d[i] << " ";
    }
    return 0;
}