#include<bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int v[100001], x[100001];
int main()
{
  queue<int> q;
  int a[100001][100001];
  int n, m, start, i, h, d, k=10, ok=0;
  fin>>n>>m>>start;
  for(i=1; i<=m; i++){
      fin>>d>>h;
      a[d][h]=1;}
  for(i=1; i<=n; i++){
    q.push(start);
    v[start]=1;
    x[start]=0;
    while(!q.empty()){
        k=q.front();
        for(int j=1;j<=n;++j){
            if(v[j]==0 && a[k][j]==1){
                v[j]=1;
                x[j]=x[k]+1;
                q.push(j);
            }
        }
        q.pop();
    }
    //cout<<endl;
    for(int y=1; y<=n; y++){v[y]=0;}
    if(i==start)fout<<0<<' ';
    else if(x[i]==0&&i!=start)fout<<-1<<' ';
    else fout<<x[i]<<' ';
   }
}