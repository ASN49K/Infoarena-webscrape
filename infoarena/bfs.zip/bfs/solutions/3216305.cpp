#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<vector<int>> mat(1001);
int n, m, s;

void citire() {
  fin >> n >> m >> s;
  for (int i = 1; i <= m; i++) {
    int x,y;
    fin >> x >> y;
    mat[x].push_back(y);
  }
}

void bfs(int source) {
  vector<int> dist(n+1);
  vector<int> viz(n+1);
  viz[source] = 1;
  dist[source] = 0;
  queue<int> q;
  q.push(source);
  while (!q.empty()) {
    int current = q.front();
    q.pop();
    viz[current] = 1;
    for (int vecin : mat[current])
      if (!viz[vecin]) {
      q.push(vecin);
      dist[vecin] = dist[current] + 1;
    }
  }
  for (int i = 1; i <= n; i++)
    if (!dist[i] && i != s)
      dist[i] = -1;
  for (int i = 1; i <= n; i++)
    fout << dist[i] << " ";
}

int main() {
  citire();
  bfs(s);
  return 0;
}
