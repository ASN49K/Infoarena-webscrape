#include <fstream>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");

vector<int> vecini[100007];
int main() {

  int n,m,X;
  f>>n>>m>>X;
  for (int i=0;i<m;i++) {
    int x,y;
    f>>x>>y;
    vecini[x].push_back(y);
  }

  int distanta[100007]={0};
  distanta[X]=1;
  queue<int> deVizitat;
  deVizitat.push(X);
  while (!deVizitat.empty()) {
    int x=deVizitat.front();
    deVizitat.pop();
    for (int j:vecini[x]) {
      if (distanta[j]==0) {
        distanta[j]=distanta[x]+1;
        deVizitat.push(j);
      }
    }
  }
  for (int i=1;i<=n;i++) {
    g<<distanta[i]-1<<" ";
  }
  return 0;
}