#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
typedef long long ll;

int n, m, S;
vector <int> v[100005];
int visited[100005];
int res[100005];
queue <int> q;

void bfs(int nod) {
    visited[nod] = 1; // marcam nodul de la care incepem ca a fost vizitat
    q.push(nod); // punem nodul sursa in coada
    res[nod] = 0; // de la nodul sursa la nodul sursa lungimea drumului e 0

    while (!q.empty()){ // cat timp coada nu e goala
        int nodc = q.front(); //nodul curent este primul element din coada
        q.pop(); // am retinut deja nodul curent, este ok sa il scoatem
        for (auto& x : v[nodc]){ // iteram prin vecinii nodului curent
            if (!visited[x]){ // cand gasim un vecin nevizitat
                visited[x] = 1; // il marcam
                res[x] = res[nodc] + 1; // crestem lungimea drumului cu 1
                q.push(x); // adaugam vecinul nevizitat in coada
            }
        }
    }

}

int main() {

    fin >> n >> m >> S;
    while (m--) {
        int a,b;
        fin >> a >> b;
        v[a].push_back(b); // facem lista de adiacenta
    }

    for (int i = 1; i <= n; i++){
        res[i] = -1;
    }

    bfs(S);

    for (int i = 1; i <= n; i++){
        fout << res[i] << ' ';
    }

    return 0;
}