#include <iostream>
#include <queue> //push si pop, front()
#include <vector>//push_back
#define pb push_back
#define SIZE 500001
#define FIN "bfs.in"
#define FOUT "bfs.out"

using namespace std;

int dist[SIZE];
bool visited[SIZE];
vector<int> Adj_list[SIZE];
queue<int> Queue;//first_index, last_index
int num_nodes,
    num_edges,
    source;

void read_graph() {

      int x, y;

      freopen(FIN, "r", stdin);

      scanf("%d %d %d", &num_nodes, &num_edges, &source);

      for(;num_edges;num_edges--) {

           scanf("%d %d", &x, &y);
           Adj_list[x].pb(y);
      }

      fclose( stdin );
}

void write_solution() {

  freopen(FOUT, "w", stdout);

  for(int k = 1; k <= num_nodes; ++k) {

      if(dist[k] != 0) printf("%d ", dist[k]);

        else if(dist[k] == 0 && k == source) printf("%d ",0);

        else printf("-1 ");
  }

}

void BFS() {

     int node;

     //memset(dist, 0, sizeof(dist))
     for(int k = 1; k <= num_nodes; ++k) dist[ k ] = 0, visited[ k ] = false;

     visited[ source ] = true;

     Queue.push( source );

     //front--->2 3 4 5 6 7 8 9 10 <---rear
     while( !Queue.empty() ) {

          node = Queue.front();

          visited[ node ] = true;

          Queue.pop();

          for(vector<int>::iterator it = Adj_list[ node ].begin(); it != Adj_list[node].end(); ++it) {

                    if(!visited[ *it ]) {

                        visited[ *it ] = true;

                        Queue.push( *it );

                        dist[ *it ] = dist[ node ] + 1;
                    }
          }

     }
}

int main(int argc, char const *argv[]) {

  read_graph();
  BFS();
  write_solution();

  return 0;
}
