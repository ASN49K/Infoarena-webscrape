#include <bits/stdc++.h>

#define all(x) (x).begin(), (x).end()
using namespace std;
using ll = long long;

const int NMAX = 1e5 + 10, mod = 1e9 + 7;
int n, dist[NMAX], start, m;
bool viz[NMAX];
vector<vector<int>> g;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    cin >> n >> m >> start;
    g.resize(n + 1);
    for (int i = 1; i <= m; i++) {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
    }

    fill(dist + 1, dist + 1 + n, -1);
    queue<pair<int, int>> q;
    q.emplace(start, 0);
    viz[start] = 1;
    while (!q.empty()) {
        auto [node, d] = q.front();
        q.pop();
        dist[node] = d;
        for (auto u: g[node])
            if (!viz[u]) {
                viz[u] = 1;
                q.emplace(u, d + 1);
            }
    }

    for (int i = 1; i <= n; i++)
        cout << dist[i] << ' ';
}