#include <fstream>
#include <vector>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
vector<int>l[100005];
int c[100005],d[100005];
int n,m,nod,x,y,p,u,s;
int main()
{
    cin>>n>>m>>s;
    for(int i=1; i<=m; i++)
    {
        cin>>x>>y;
        l[x].push_back(y);
    }
    ///bfs
    p=u=1;
    c[1]=s;
    d[s]=1;
    while(p<=u)
    {
        nod=c[p];
        for(int i=0; i<l[nod].size(); i++)
        {
            int vecin=l[nod][i];
            if(d[vecin]==0)
            {
                u++;
                c[u]=vecin;
                d[vecin]=d[nod]+1;
            }
        }
        p++;
    }
    for(int i=1;i<=n;i++)
        cout<<d[i]-1<<" ";
    return 0;
}
