#include <bits/stdc++.h>
using namespace std;

int n,m,m1,m2,sol,s;
vector<vector<int>>adj(100010);
vector<int>dist(100010,-1);
queue<int>q;

void bfs()
{
    if(q.empty())
        return;
    else
    {
        int fr = q.front();
        q.pop();
        for(int i = 0;i < adj[fr].size();i++)
            if(dist[adj[fr][i]] == -1)
        {
            q.push(adj[fr][i]);
            dist[adj[fr][i]] = dist[fr] + 1;
        }
        bfs();
    }
}

int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");

    cin>>n>>m>>s;
    for(int i = 1;i <= m;i++)
    {
        cin>>m1>>m2;
        adj[m1].push_back(m2);
    }
    dist[s] = 0;
    q.push(s);
    bfs();
    for(int i = 1;i <= n;i++)
        cout<<dist[i]<<" ";
}
