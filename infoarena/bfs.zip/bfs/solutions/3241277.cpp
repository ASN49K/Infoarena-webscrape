#include "bits/stdc++.h"
std :: vector < std :: vector < int > > adj(100001);
std :: vector < int > ans(100001, -1);
std :: bitset < 100001 > vis;
int n, m, target;
inline static void AddEdge(int x, int y){
            adj[x].push_back(y);
}
inline static void BFS(int target){
             std :: queue < int > q;
             ans[target] = 0;
             q.push(target);
             while(q.empty() == false){
                      int node = q.front();
                      q.pop();
                      for(auto i : adj[node]){
                                if(ans[i] == -1){
                                        vis[i] = true;
                                        ans[i] = ans[node] + 1;
                                        q.push(i);
                                }
                      }
             }
}
inline static void Solve(){
            std :: cin >> n >> m >> target;
            while(m -- ){
                  int x, y;
                  std :: cin >> x >> y;
                  AddEdge(x, y);
            }
             BFS(target);
            for(int i = 1; i <= n; i++){
                      std :: cout << ans[i] << ' ';
             }
}
signed main(){
      freopen("bfs.in", "r", stdin);
      freopen("bfs.out", "w", stdout);
      std :: ios_base :: sync_with_stdio(false);
      std :: cin.tie(0);
      std :: cout.tie(0);
      Solve();
      return 0;
}
