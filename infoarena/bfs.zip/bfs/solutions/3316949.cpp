#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

queue<int> q;
vector <int> N[100005];
int d[100005];
int n, m, x, y;

void BFS(int s) {
    for (int i = 1; i <= n; i++) {
        d[i] = 100005;
    }
    d[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (int vecin : N[nod]) {
            if (d[vecin] > d[nod] +1 )
            {
                d[vecin] = d[nod] + 1;
                q.push(vecin);
            }
        }
    }
}

int main() {
    int s;
    fin >> n >> m >> s;
    int i = 0;
    while(i < m){
        fin >> x >> y;
        N[x].push_back(y);
        i++;
     }

    BFS(s);
    for (int i = 1; i <= n; i++)
    {
        if(d[i]==100005)
            d[i]=-1;
        fout << d[i] << " ";
    }

    return 0;
}
