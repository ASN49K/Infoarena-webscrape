#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
#define maxn 100010
int d[maxn+1],viz[maxn+1],tata[maxn+1];

void BFS(vector<vector<int>> adiacenta, int Start,int n){
    queue<int> q;
    q.push(Start);
    viz[Start]=1;
    d[Start]=0;
    while(!q.empty()){
        int i=q.front();
        q.pop();
        for(auto j: adiacenta[i]){
            if(viz[j]==0){
                q.push(j);
                viz[j]=1;
                tata[j]=i;
                d[j]=d[i]+1;
            }
        }
    }
}
int main() {
    int n,m,Start,x,y;
    f>>n>>m>>Start;
    vector<vector<int>> Lista(n+1);
    for(int i=1;i<=m;i++){
        f>>x>>y;
        Lista[x].push_back(y);
    }
    for(int i=1;i<n+1;i++)
        d[i]=-1;
    BFS(Lista,Start,n);
    for (int i = 1; i <= n; i++)
        g<<d[i]<<" ";
}
