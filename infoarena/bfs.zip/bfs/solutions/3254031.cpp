#include <bits/stdc++.h>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s;
vector<int> G[100001];
int viz[100001];

void bfs(int nod)
{
    queue<int> q;
    q.push(nod);
    viz[nod] = 0;

    while(!q.empty()){
        nod = q.front();
        q.pop();
        for(int i = 0; i < (int)G[nod].size(); i++)
            if(viz[G[nod][i]] == -1){
                q.push(G[nod][i]);
                viz[G[nod][i]] = viz[nod] + 1;
            }
    }
}

int main()
{
    fin >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }

    for(int i = 1; i <= n; i++){
        viz[i] = -1;
    }

    bfs(s);

    for(int i = 1; i <= n; i++){
        fout << viz[i] << " ";
    }

    return 0;
}
