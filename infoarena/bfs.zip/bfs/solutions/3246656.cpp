#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <iostream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int N, M, S;
const int NMAX = 100005;

unordered_map<int, vector<int>> graph;
vector<int> dist(NMAX, -1);

void bfs(int source){
    queue<int> q;
    q.push(source);
    dist[source] = 0;

    while(!q.empty()){
        int curr = q.front();
        q.pop();

        for(auto v : graph[curr]){
            if(dist[v] == -1) {
                dist[v] = dist[curr] + 1;
                q.push(curr);
            }
        }
    }
}

int main(){

    fin >> N >> M >> S;

    for(int i = 0; i < M; i++){
        int x, y;
        fin >> x >> y;
        graph[x].push_back(y);
    }
    bfs(S);
    for(int i = 1; i <= N; i++){
        fout << dist[i] << " ";
    }

    return 0;
}