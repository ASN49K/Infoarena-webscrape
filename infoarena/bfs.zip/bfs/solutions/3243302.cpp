#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NMAX = 100001;

vector<vector<int>>G(NMAX);
bool viz[NMAX];
int sol[NMAX];
int n, m, sursa;

void bfs(int nod)
{
    queue<int>Q;
    Q.push(nod);
    viz[nod] = 1;
    while(!Q.empty())
    {
        int x = Q.front();
        Q.pop();
        for(auto y : G[x])
            if(viz[y] == 0)
            {
                sol[y] = sol[x] + 1;
                Q.push(y);
                viz[y] = 1;
            }
    }
}

void solve()
{
    for(int i = 1; i <= n; i++)
        sol[i] = -1;
    sol[sursa] = 0;
    ///
    bfs(sursa);
    for(int i = 1; i <= n; i++)
        g << sol[i] << ' ';
}

void ReadGraf()
{
    int x, y;
    f >> n >> m >> sursa;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
    }
}
int main()
{
    ReadGraf();
    solve();
    return 0;
}

