#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
const int NMAX = 100001;
int s[NMAX];
bool a[NMAX];
vector<vector<int>>G(NMAX);
void bfs(int plc){
    queue<int> Q;
    Q.push(plc);
    a[plc]=1;
    while(!Q.empty())
    {
        int x=Q.front();
        for(auto y: G[x])
        {

            if(a[y]==0)
            {
                a[y]=1;
                s[y]=s[x]+1;
                Q.push(y);
            }
        }
        Q.pop();
    }

}
int main()
{
    int n,m,pctplc,x,y;
    f>>n>>m>>pctplc;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        s[i]=-1;
    s[pctplc]=0;
    bfs(pctplc);
    for(int i=1;i<=n;i++)
        g<<s[i]<<' ';
    return 0;
}
