#include <bits/stdc++.h>

using namespace std;

#define TITLE ""
ifstream f (TITLE".in");
ofstream g (TITLE".out");

void bfs(int StartNode, vector<vector<int>> &Graph, vector<int> &Visited)
{
    Visited[StartNode]=1;
    queue<int>Q;
    for(Q.emplace(StartNode); !Q.empty(); Q.pop())
    {
        int CurrentNode=Q.front();
        for(auto it : Graph[CurrentNode])
            if(!Visited[it])
            {
                Visited[it]=Visited[CurrentNode]+1;
                Q.emplace(it);
            }
    }
}

int main()
{
    int n,m,StartNode;
    f>>n>>m>>StartNode;
    vector<vector<int>>Graph(n+1);
    for(int a,b; f>>a>>b; Graph[a].emplace_back(b));
    vector<int> Answer(n+1);
    bfs(StartNode,Graph,Answer);
    for(int i=1; i<=n; i++)
        g<<Answer[i]-1<<' ';
    return 0;
}
