def build_adjacency_list(tokens, n, m, oriented=False):
    adj_list = [[] for _ in range(n + 1)]
    index = 3
    for _ in range(m):
        u = int(tokens[index])
        v = int(tokens[index + 1])
        adj_list[u].append(v)
        if not oriented:
            adj_list[v].append(u)
        index += 2

    return adj_list

def print_adjacency_list(adj_list):
    for i in range(1, len(adj_list)):
        print(f"{i}: {' '.join(map(str, adj_list[i]))}")  

def BFS(adjacency_list, start_node):
    cost = [-1] * len(adjacency_list)
    queue = [start_node]
    cost[start_node] = 0

    while queue:
        current = queue.pop(0)
        for neighbor in adjacency_list[current]:
            if cost[neighbor] == -1:
                cost[neighbor] = cost[current] + 1
                queue.append(neighbor)

    return cost


with open('graf.in', 'r') as f:
    tokens = f.read().split()

n = int(tokens[0])
m = int(tokens[1])
s = int(tokens[2])


adjacency_list = build_adjacency_list(tokens, n, m, oriented=True)
costs = BFS(adjacency_list, s)
for i in costs[1:]:
    print(i, end=' ')
