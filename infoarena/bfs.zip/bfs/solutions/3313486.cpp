#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int N = 100000;
vector <int> la[N + 1];
vector <int> d(N + 1, - 1);

void bfs(int s)
{
    d[s] = 0;
    queue <int> q;
    q.push(s);
    while (!q.empty())
    {
        s = q.front();
        q.pop();
        for (auto urm: la[s])
        {
            if (d[urm] == -1)
            {
                d[urm] = d[s] + 1;
                q.push(urm);
            }
        }
    }
}
int main()
{
    ifstream in("bfs.in");
    ofstream out("bfs.out");

    int n, m, s;
    in >> n >> m >> s;
    for (int i = 0; i < m; i ++)
    {
        int x, y;
        in >> x >> y;
        la[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i ++)
    {
        out << d[i] << ' ';
    }

    in.close();
    out.close();

    return 0;
}