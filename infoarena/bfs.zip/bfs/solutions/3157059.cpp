#include <bits/stdc++.h>

using namespace std;

ifstream f ("bfs.in");
ofstream g ("bfs.out");

const int NMAX = 1e5;
const int MMAX = 1e6;

vector<int> v[NMAX+1];
int rez[NMAX+1], marked[NMAX+1];

queue<int> q;

void bfs(int s){
    q.push(s);
    rez[s] = 0;
    while(!q.empty()){
        int x = q.front();
        for(auto ver : v[x]){
            if(!marked[ver]){
                marked[ver] = true;
                q.push(ver);
                if(rez[ver] == -1)
                    rez[ver] = rez[x] + 1;
                else rez[ver] = min(rez[ver], rez[x] + 1);
            }
        }
        q.pop();
    }
}

int main()
{
    fill(rez+1, rez+1+NMAX, -1);
    int n, m, s;
    f >> n >> m >> s;
    for(int i=1; i<=m; i++){
        int x, y;
        f >> x >> y;
        v[x].push_back(y);
    }
    bfs(s);
    for(int i=1; i<=n; i++)
        g << rez[i] << ' ';
    return 0;
}
