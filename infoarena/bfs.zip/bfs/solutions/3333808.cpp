#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,start;

//vector<int> A; am declarat un vector din STL cu 0 elemente de tip int numit A

vector<int> A[NMAX]; //am declarat un vector cu NMAX elemente de tip vector din STL cu 0 elemente de tip int numit A
int C[NMAX];
int inc,sf;

void citire();
int viz[NMAX];
void bfs(int x);

int main()
{
    int i;
    citire();
    bfs(start);
    for(i=1; i<=n; i++)
        fout<<viz[i]-1<<' ';
    return 0;
}

void citire()
{
    int i,m,x,y;
    fin>>n>>m>>start;
    for(i=0; i<m; i++)
    {
        fin>>x>>y; //arc de la x la y
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
    }
}

void bfs(int x)
//parcurge BFS graful din vf x
{
    int i;
    C[0]=x; inc=sf=0; //initializez coada cu varful de start
    viz[x]=1; //vizitez vf de start
    while(inc<=sf)
        {
         x=C[inc++];
         //parcurg vecinii lui x
         for(i=0; i<A[x].size(); i++)
            if(!viz[A[x][i]])
                {
                 viz[A[x][i]]=1+viz[x];
                 C[++sf]=A[x][i];
                }
        }
}

