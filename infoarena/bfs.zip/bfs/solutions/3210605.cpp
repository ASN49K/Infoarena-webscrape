#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
const int NMAX = 1e5+1;
int costuri[NMAX];
vector<int> coada;

int n, m,t;
vector<int> graf[NMAX];
 void citire() {
	f >> n >> m >> t;
	for (int i = 0; i < m; i++) {
		int x, y;
		f >> x >> y;
		graf[x].push_back(y);
	}
}
void afisare() {
	for (int i = 1; i <= n; i++) {
		g << costuri[i] << " ";
	}
}
void bfs(int start) {
	coada.push_back(start);
	for (int i = 1; i < NMAX; i++)costuri[i] = -1;
	costuri[start] = 0;
	while (!coada.empty()) {
		int cur = coada.front();
		coada.erase(coada.begin());
		for (auto e : graf[cur]) {
			if (costuri[e] == -1)
			{
				coada.push_back(e);
				costuri[e] = costuri[cur]+1;
			}
		}
	}
}
int main()
{
	citire();
	bfs(t);
	afisare();

}

