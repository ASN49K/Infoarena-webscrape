#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
vector<vector<int>> v;

int n,m,s;
bool viz[100001];
int dist[1000001];
void bfs(int start)
{
   dist[start]=1;
   queue <int> q;
   q.push(start);
   while(!q.empty())
   {
      int node=q.front();
      q.pop();
      for(int vec:v[node])
      {
          if(!dist[vec])
          {
              dist[vec]=dist[node]+1;
              q.push(vec);
          }
      }
   }
}
int main()
{
    cin>>n>>m>>s;
    v.resize(n+1);
    for(int i=1;i<=m;i++)
    {
        int a,b;
        cin>>a>>b;
        v[a].push_back(b);
    }
    bfs(s);
    for(int i=1;i<=n;i++)
    {
        if(!dist[i])
           {
               cout<<-1<<" ";
           }
        else{
            cout<<dist[i]-1<<" ";
        }
    }
    return 0;
}
