#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("graf.in");
ofstream fout("graf.out");
vector<vector<int>> gf;
vector<int> viz;
vector<int> niv;
queue<int> q;
int N, M, S;

void bfs(int vf)
{
    int nr = 0;
    q.push(vf);
    viz[vf] = 1;
    niv[S] = 0;
    while(!q.empty())
    {
        int x;
        x = q.front();
        for(auto& y : gf[x])
        {
            if(viz[y] == 0){
                q.push(y);
                viz[y] = 1;
                niv[y] = niv[x] + 1;
            }
        }
        q.pop();
    }
}

int main()
{
    fin>>N>>M>>S;
    gf.resize(N+1);
    viz.resize(N+1);
    niv.assign(N+1, -1);
    for(int i=1; i<=M; i++){
        int x,y;
        fin>>x>>y;
        gf[x].push_back(y);
    }

    for(int i=1; i<=N; i++){
        cout<<i<<": ";
        for(auto& x : gf[i])
            cout<<x<<' ';
        cout<<endl;
    }

    bfs(S);
    for(int i=1; i<=N; i++)
    {
        if(viz[i] == 0)
            {
                bfs(i);
            }
    }

    for(int i=1; i<=N; i++)
        cout<<niv[i]<< ' ';


    return 0;
}
