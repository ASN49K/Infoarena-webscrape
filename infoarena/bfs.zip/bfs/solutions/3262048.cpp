#include <fstream>
#include <vector>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

vector <int> graph[100001];

int distances[100001];
void bfs(int startNode, int n) {
    for (int i = 1; i <= n; ++i) {
        distances[i] = -1;
    }

    queue <int> q;

    q.push(startNode);
    distances[startNode] = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (auto vecin :graph[node]) {
            if (distances[vecin] != -1) continue;

            q.push(vecin);
            distances[vecin] = distances[node] + 1;
        }
    }
}

int main() {
    int N, M, S, x, y;
    f>>N>>M>>S;
    for(int i = 1; i<=M; i++){
        f>>x>>y;
        graph[x].push_back(y);
    }

    bfs(S, N);
    for (int i = 1; i <= N; ++i) {
        g << distances[i] << ' ';
    }
    return 0;
}
