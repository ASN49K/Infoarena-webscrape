#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int N,M,S;
const int nmax = 100001;
vector<int>g[nmax];//lista de vecini
queue<int>q;
int dist[nmax];
void bfs(int node){
  dist[node]=1;
  q.push(node);
  while(!q.empty()){
    int node=q.front();
    for(int i=0; i<g[node].size(); i++){
      int vecin = g[node][i];
      if(dist[vecin]==0){
        dist[vecin]=dist[node]+1;
        q.push(vecin);
      }
    }
    q.pop();
  }
}

int main()
{
  fin>>N>>M>>S;
  for(int i=0; i<M; i++){
    int x,y;
    fin>>x>>y;
    g[x].push_back(y);
  }
  bfs(S);
  for(int i=1; i<=N; i++){
    fout<<dist[i] - 1<<" ";
  }

return 0;
}

