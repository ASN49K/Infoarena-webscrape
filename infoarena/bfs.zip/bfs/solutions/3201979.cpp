/*#include <bits/stdc++.h>
#include <fstream>

struct nod {
	std::vector<int> vecini; 
	bool vizitat;
};
std::vector<nod> noduri;

void dfs(int nod_curent) {
	std::cout << nod_curent + 1 << ' ';

	noduri[nod_curent].vizitat = true;

	std::sort(noduri[nod_curent].vecini.begin(), noduri[nod_curent].vecini.end());
	//for(int i = 0; i < noduri[nod_curent].vecini.size(); i++)
	for(int index_vecin : noduri[nod_curent].vecini) {
		if(noduri[index_vecin].vizitat == false)
			dfs(index_vecin);
	}
}

int main() {
	//std::ifstream fin("dfs.in");
	freopen("dfs.in", "r", stdin);
	freopen("dfs.out", "w", stdout);

	int n, m; std::cin >> n >> m;
	int start; std::cin >> start;
	noduri.resize(n);

	for(int i = 0; i < m; i++) {
		int a, b;
		std::cin >> a >> b;
		a--; b--;
		noduri[a].vecini.push_back(b);
		noduri[b].vecini.push_back(a);

	}

	dfs(start - 1);
	return 0;
}
*/

#include <bits/stdc++.h>

const int LIM = 1e5+5;
std::vector<int> vecini[LIM];
int dist[LIM];

void bfs(int start) {
	for(int i = 0; i < LIM; i++)
		dist[i] = 2e9;

	std::queue<int> q;
	q.push(start);
	dist[start] = 0;

	while(!q.empty()) {
		int curent = q.front();
		int parcurs = dist[curent];
		q.pop();

		for(int v : vecini[curent]) {
			if(dist[v] <= parcurs + 1) continue;

			dist[v] = parcurs + 1;
			q.push(v);
		}
	}
}

int main()
{
	freopen("bfs.in", "r", stdin);
	freopen("bfs.out", "w", stdout);

	int n, m, start; std::cin >> n >> m >> start;
	while(m--) {
		int a, b; std::cin >> a >> b;
		a--; b--;
		vecini[a].push_back(b);
	}

	bfs(start - 1);
	for(int i = 0; i < n; i++)
	{
		if(dist[i] == 2e9)
			std::cout << "-1 ";
		else
			std::cout << dist[i] << ' ';
	}
    return 0;
}