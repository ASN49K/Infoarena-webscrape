#include <bits/stdc++.h>

using namespace std;

int f[100005];

vector <int> s[100055];

deque <int> q;

int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    int n,m,x,y,k;
    cin>>n>>m>>k;
    for(int i=1;i<=m;++i)
    {
        cin>>x>>y;
        s[x].push_back(y);
    }

            f[k]=1;
            q.push_back(k);
            while(q.size())
            {
                for(auto a:s[q.front()])
                {
                    if(f[a]==0)
                    {
                        f[a]=f[q.front()]+1;
                        q.push_back(a);
                    }
                }
                q.pop_front();
            }


    for(int i=1;i<=n;++i)
    {
        cout<<f[i]-1<<" ";
    }

    return 0;
}
