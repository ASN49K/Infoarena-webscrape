#include <bits/stdc++.h>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

vector <int> gr[100005];
int vis[100005];
int v[100005];

void bfs(int start){
    queue <int> q;
    q.push(start);
    vis[start] = 1;
    int loc = 0;
    while (!q.empty()){
        int node = q.front();
        loc++;
        q.pop();
        for (auto x:gr[node]){
            if (vis[x]) continue;
            v[x] = loc;
            q.push(x);
            vis[x] = vis[node]+1;
        }
    }
    return;
}

int main()
{
    int n,m,s;
    fin >> n >> m >> s;
    for (int i=1;i<=m;++i){
        int x,y;
        fin >> x >> y;
        gr[x].push_back(y);
    }
    bfs(s);
    for (int i=1;i<=n;++i){
        fout << vis[i]-1 << ' '; // daca nu sse poate ajunge acolo se va afisa 0-1 == -1
    }
    return 0;
}
