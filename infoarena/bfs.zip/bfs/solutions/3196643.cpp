#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;


void addEdge(vector<vector<int>>& adj, int x, int y) {
    adj[x].push_back(y);
}

vector<int> minDistances(vector<vector<int>>& adj, int N, int source) {
    vector<int> distances(N + 1, -1);
    distances[source] = 0;

    queue<int> q;
    q.push(source);

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        for (int neighbor : adj[current]) {
            if (distances[neighbor] == -1) {
                distances[neighbor] = distances[current] + 1;
                q.push(neighbor);
            }
        }
    }

    return distances;
}

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    int N, M, S;
    fin >> N >> M >> S;

    vector<vector<int>> adj(N + 1);

    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        addEdge(adj, x, y);
    }

    vector<int> distances = minDistances(adj, N, S);

    for (int i = 1; i <= N; ++i) {
        fout << distances[i] << " ";
    }
    fout << endl;

    fin.close();
    fout.close();

    return 0;
}

