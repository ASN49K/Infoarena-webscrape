#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;
ifstream fin("bfs.in");
ofstream gout("bfs.out");

const int nmax = 100000;
vector<int> g[nmax + 1];
int viz[nmax + 1], d[nmax + 1];

void bfs(int x) {
    queue<int> q;
    q.push(x);
    d[x] = 0;
    viz[x] = 1;

    while (!q.empty()) {
        x = q.front();
        q.pop();

        for (auto next : g[x]) {
            if (!viz[next]) {
                q.push(next);
                viz[next] = 1;
                d[next] = d[x] + 1;
            }
        }
    }
}

int main() {
    int n, m, nod;
    fin >> n >> m >> nod;

    while (m--) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
    }

    // Inițializează toate distanțele cu -1 pentru a gestiona cazurile inaccesibile.
    for (int i = 1; i <= n; i++) {
        d[i] = -1;
    }

    bfs(nod);

    // Afișează distanțele pentru fiecare nod.
    for (int i = 1; i <= n; i++) {
        gout << d[i] << ' ';
    }

    return 0;
}
