//#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

std::ifstream cin("bfs.in");
std::ofstream cout("bfs.in");


const int NMAX = 1e5;
std::vector<int> L[NMAX + 1];
int dist[NMAX + 1];

void bfs(int x) {
    dist[x] = 0;
    std::queue<int> q;
    q.push(x);
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (auto next : L[node]) {
            if (dist[next] == -1) {
                q.push(next);
                dist[next] = dist[node] + 1;
            }
        }
    }
}

int main() {
    int n, m, s;
    cin >> n >> m >> s;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        cin >> x >> y;
        L[x].push_back(y);
    }
    for (int i = 1; i <= n; ++i)
        dist[i] = -1;

    bfs(s);
    for (int i = 1; i <= n; ++i)
        cout << dist[i] << ' ';
    return 0;
}
