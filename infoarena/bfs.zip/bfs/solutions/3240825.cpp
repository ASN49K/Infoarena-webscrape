#include <bits/stdc++.h>
using namespace std;

class Task { // T = O(n + m) 
 public:
    void solve() {
        read_input();
        print_output(get_result());
    }
 
 private:
    // numarul maxim de noduri
    static constexpr int NMAX = (int)1e5 + 5; // 10^5 + 5 = 100.005

    // distanta maxima in graf
    static constexpr int INF = 1e9; // 10^9 = 1.000.000.000

    // n = numar de noduri, m = numar de muchii/arce
    int n, m;

    // adj[node] = lista de adiacenta a nodului node
    // exemplu: daca adj[node] = {..., neigh, ...} => exista muchia (node, neigh)
    vector<int> adj[NMAX];

    // nodul sursa in parcurgerea BFS
    int source;

    void read_input() {
        ifstream fin("bfs.in");
        fin >> n >> m >> source;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y; // muchie (x, y)
            adj[x].push_back(y);
        }
        fin.close();
    }

    vector<int> get_result() {
        return bfs(source);
    }

    vector<int> bfs(int s)
    {
        // Step 0: alocare vector de distante
        // d[node] = INF, oricare ar fi node
        vector<int> d(n + 1, INF);

        // Step 1: declaram o coada in care putem baga noduri
        queue<int> q;

        // Step 2: pasul initial: pun in coada TOATE nodurile cu grad intern 0
        q.push(s);
        d[s] = 0;

        // Step 3: cat timp NU am parcurs toate nodurile
        while (!q.empty()) {
            // Step 3.1: extragem si procesam urmatorul nod din coada
            int node = q.front();
            q.pop();

            // Step 3.2: parcurgem vecinii lui node
            for (auto& neigh : adj[node]) {
                // actulizam distanta lui x fata de sursa daca
                // am gasit o solutie mai buna
                if (d[node] + 1 < d[neigh]) {
                    d[neigh] = d[node] + 1;
                    q.push(neigh);
                }
            }
        }

        // Step 4: problema ne cere ca acolo unde nu exista drum sa punem -1
        // inlocuim valorile egale cu INF din d cu -1
        for (auto& value : d) {
            if (value == INF) {
                value = -1;
            }
        }

        return d;
    }

    void print_output(const vector<int>& d) {
        ofstream fout("bfs.out");
        for (int node = 1; node <= n; node++) {
            fout << d[node] << (node == n ? '\n' : ' ');
        }
        fout.close();
    }
};


int main() {
    auto* task = new (nothrow) Task();

    if (!task) {
        cerr << "new failed!\n";
        return -1;
    }

    task->solve();
    delete task;

    return 0;
}
