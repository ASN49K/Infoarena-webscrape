#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");
//sa se determine numarul minim de arce ce trebuie parcurse pentru a ajunge din nodul sursa S la nodul X
const int nmax=100000;
vector<int>v[nmax+1];
int n,m,s,x,y;
int vis[nmax+1], d[nmax+1];
void BFS(int x){
    queue<int>q;
    q.push(x);
    d[x]=0;
    vis[x]=1;
    while(!q.empty()){
        x=q.front();
        q.pop();
        for(auto next:v[x]){
            if(!vis[next]){
                q.push(next);
                d[next]=d[x]+1;
                vis[next]=1;
            }
        }
    }
}

int main()
{
    f>>n>>m>>s;
    for(int i=1;i<=m;i++){
        f>>x>>y;
        v[x].push_back(y);
    }
    BFS(s);
    for(int i=1;i<=n;i++)
        if(i!=s && d[i]==0)
            g<<-1<<" ";
        else 
            g<<d[i]<<" ";
}