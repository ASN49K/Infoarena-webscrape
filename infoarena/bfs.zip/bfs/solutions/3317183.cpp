#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

void bfs(int nod_sursa, vector<vector<int>>& lista_adiacenta, vector<int>& dist) {

    queue<int> coada;
    dist[nod_sursa] = 0;
    coada.push(nod_sursa);

    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();

        for (int vecin : lista_adiacenta[nod]) {
            if (dist[vecin] > dist[nod] + 1) {
                dist[vecin] = dist[nod] + 1;
                coada.push(vecin);
            }
        }
    }
}

int main() {
    int n, m, x, y, s;

    fin >> n >> m>>s;

    vector<vector<int>> lista_adiacenta(n + 1);
    vector<int> dist(n + 1, 1e9); //10^9

    for (int i = 0; i < m; i++) {
        fin >> x >> y;

        lista_adiacenta[x].push_back(y);

    }

    bfs(s, lista_adiacenta, dist);

    for (int i = 1; i <= n; i++) {
        if (dist[i] == 1e9)
            fout << "-1" << " ";
        else
            fout << dist[i] << " ";
    }

    return 0;
}
