// BFS orietated graph
// https://infoarena.ro/problema/bfs

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 1e5 + 5;
const int MMAX = 1e6 + 5;
int n, m, s;
int len[NMAX];
bool visited[NMAX];

vector<vector<int>> gp(NMAX);

void BFS(int source)
{
    queue<int> q;
    q.push(source);
    len[source] = 0;
    while (!q.empty())
    {
        int node = q.front();
        q.pop();
        visited[node] = 1;
        for (auto next : gp[node])
        {
            if (!visited[next] && (len[next] == 0 || len[next] > len[node] + 1))
            {
                q.push(next);
                visited[next] = 1;
                len[next] = len[node] + 1;
            }
        }
    }
    for (int i = 1; i <= n; i++)
        if (!visited[i])
            len[i] = -1;
}

int main()
{
    fin >> n >> m >> s;
    while (m--)
    {
        int x, y;
        fin >> x >> y;
        cout << x << " " << y << '\n';
        gp[x].push_back(y);
    }
    BFS(s);
    for (int i = 1; i <= n; i++)
        fout << len[i] << ' ';
    fin.close();
    fout.close();
    return 0;
}