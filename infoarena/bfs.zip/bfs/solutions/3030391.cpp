#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s, a, b, viz[100003];
vector<int> G[100003];

void BFS(int start){
    queue<int> que;
    que.push(start);
    viz[start] = 1;
    while(!que.empty()){
        int x = que.front();
        for(int i = 0; i < G[x].size(); i++){
            int j = G[x][i];
            if(!viz[j]){
                viz[j] = viz[x] + 1;
                que.push(j);
            }
        }
        que.pop();
    }
}

int main(){
    fin >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        fin >> a >> b;
        G[a].push_back(b);
    }
    BFS(s);
    for(int i = 1; i <= n; i++)
        fout << viz[i] - 1 << ' ';
    return 0;
}
