#include <iostream>
#include <vector>
#include <queue>

int main()
{
    int n, m, s;
    std::cin >> n >> m >> s;
    s --;
    std::vector<std::vector<int>> la;
    for (int i = 0; i < n; i ++) {
        la.push_back(std::vector<int>());
    }
    for (int i = 0; i < m; i ++) {
        int x, y;
        std::cin >> x >> y;
        x --;
        y --;
        la[x].push_back(y);
    }
    std::vector<int> d;
    for(int i = 0; i < n; i ++) {
        d.push_back(-1);
    }
    std::queue<int> q;
    q.push(s);
    d[s] = 0;
    while (!q.empty()) {
        int act = q.front();
        q.pop();
        for (auto vec: la[act]) {
            if (d[vec] == -1) {
                d[vec] = d[act] + 1;
                q.push(vec);
            }
        }
    }
    for (auto r: d) {
        std::cout << r << ' ';
    }
        
    return 0;
}