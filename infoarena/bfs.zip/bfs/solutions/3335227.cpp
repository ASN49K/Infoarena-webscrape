#include <bits/stdc++.h>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NMAX = 100005;

vector <int> G[NMAX];
int n,m,s;
int d[NMAX];
bool viz[NMAX];

void BFS(int start){
    for (int i=1;i<=n;i++)
        d[i] = -1;

    queue <int> q;

    d[start]=0;
    viz[start]=true;
    q.push(start);

    while (!q.empty()){
        int nod = q.front();
        q.pop();

        for (auto vecin : G[nod]){
            if (viz[vecin]==false){
                viz[vecin]=true;
                d[vecin]=d[nod]+1;
                q.push(vecin);
            }
        }
    }

}

int main(){
    f>>n>>m>>s;
    for (int i=1;i<=m;i++){
        int nod1, nod2;
        f>>nod1>>nod2;
        G[nod1].push_back(nod2);
    }

    BFS(s);

    for (int i=1;i<=n;i++)
        g<<d[i]<<" ";
}
