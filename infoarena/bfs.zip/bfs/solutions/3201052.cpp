
#include <fstream>
#include <vector>
#include <set>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
int n,m,s;
int x,y;
vector<set<int>> A;
vector<long long> ans;
vector<bool> fr;
void bfs(int nod)
{
    queue<int> Q;
    Q.push(nod);
    fr[nod]=1;
    ans[nod]=0;
    while(!Q.empty())
    {
        int cap=Q.front();
        Q.pop();
        for(auto i=A[cap].begin();i!=A[cap].end();i++)
        {
            int vecin=*i;
            if(!fr[vecin])
            {
                fr[vecin]=1;
                ans[vecin]=ans[cap]+1;
                Q.push(vecin);
            }
        }
    }
}
int main()
{

    cin>>n>>m>>s;
    A.resize(n+1);
    ans.resize(n+1);
    fr.resize(n+1);
    for(int i=1;i<=n;i++)
       ans[i]=-1;
    for(int i=0;i<m;i++)
    {
        cin>>x>>y;
        A[x].insert(y);
    }
    bfs(s);
    for(int i=1;i<=n;i++)
      cout<<ans[i]<<" ";
    return 0;
}
