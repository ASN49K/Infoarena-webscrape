#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    ifstream input("bfs.in");
    int N, M, S;
    input >> N >> M >> S;
    vector<vector<int>> graf(N + 1, vector<int>());
    
    for (int i = 0; i < M; i++) {
        int x, y;
        input >> x >> y;
        graf[x].push_back(y);
    }
    
    vector<int> distante(N + 1, -1);
    distante[S] = 0;
    queue<int> q;
    q.push(S);
    
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        
        for (int vecin : graf[nod]) {
            if (distante[vecin] == -1) {
                distante[vecin] = distante[nod] + 1;
                q.push(vecin);
            }
        }
    }

    input.close();

    ofstream output("bfs.out");
    for (int i = 1; i <= N; i++) {
        output << distante[i] << " ";
    }
    output.close();
    
    return 0;
}
