#include <iostream>
#include <vector>
#include <fstream>
#include <queue>

using namespace std;

#define ALB 0
#define GRI 1
#define NEGRU 2

void bfs(vector<vector<int>>& graf, int n, int s, vector<int>& d) {
    queue<int> pq;
    vector<int> color(n + 1, ALB);
    pq.push(s);
    d[s] = 0;
    color[s] = GRI;

    while (!pq.empty()) {
        int x = pq.front();
        pq.pop();

        for (int i = 0; i < graf[x].size(); i++) {
            int node = graf[x][i];
            if (color[node] == ALB) {
                d[node] = d[x] + 1;
                pq.push(node);
                color[node] = GRI;
            }
        }

        color[x] = NEGRU;
    }
}

int main() {
    ifstream input("bfs.in");
    ofstream output("bfs.out");

    int n, m, s;
    input >> n >> m >> s;

    vector<vector<int>> graf(n + 1);
    for (int i = 0; i < m; i++) {
        int x, y;
        input >> x >> y;

        graf[x].push_back(y);
    }

    vector<int> distance(n + 1, -1);
    bfs(graf, n, s, distance);

    for (int i = 1 ; i <= n; i ++) {
        output << distance[i] << " ";
    }

    output << "\n";

    return 0;
}