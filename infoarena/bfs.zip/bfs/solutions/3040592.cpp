#include <bits/stdc++.h>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");
int a[1001][1001];
int n, m, start, x, y;
int vizite[1001] = { 0 };

int orase[1001];
int distanta[1001];

void
bfs (int start)
{

  int st = 1, dr = 1;
  vizite[start] = 1;
  distanta[start] = 0;
  orase[dr] = start;
  while (st <= dr)
    {
      int city = orase[st];
      for (int i = 1; i <= n; i++)
	{
	  if (vizite[i] == 0 && a[city][i] == 1)
	    {
	      vizite[i] = 1;
	      dr++;
	      distanta[i] = distanta[city] + 1;
	    }
	}
      st++;
    }
}

int
main ()
{
  fin >> n >> m >> start;
  while (fin >> x >> y)
    {
      a[x][y] = 1;
    }
  for (int i; i <= n; i++)
    {
      distanta[i] = -1;
    }
  bfs (start)
  {
    for (int i; i <= n; i++)
      {
	fout << distanta[i] << " ";
      }
  }

  return 0;
}
