#include <bits/stdc++.h>

using namespace std;

vector <int> vecini[200005];
int distanta[200005];
const int INF = 1000000000;
queue <int> q;

ifstream f ("bfs.in");
ofstream g ("bfs.out");

void bfs(int n, int sursa)
{
    int i;
    for(i = 1; i <= n; ++i)
    {
        distanta[i] = INF;
    }
    distanta[sursa] = 0;
    q.push(sursa);
    while(!q.empty())
    {
        int node = q.front();
        q.pop();
        for(auto nodnou: vecini[node])
        {
            if(distanta[nodnou] > distanta[node] + 1)
            {
                distanta[nodnou] = distanta[node] + 1;
                q.push(nodnou);
            }
        }
    }
}

void afisare(int n)
{
    int i;
    for(i = 1; i <= n; ++i)
    {
        if(distanta[i] == INF)
            distanta[i] = -1;
        g << distanta[i] << " ";
    }
}

int main()
{
    int n, m, sursa, i, x, y;
    f >> n >> m >> sursa;
    for(i = 1; i <= m; ++i)
    {
        f >> x >> y;
        vecini[x].push_back(y);
    }
    bfs(n, sursa);
    afisare(n);
    return 0;
}
