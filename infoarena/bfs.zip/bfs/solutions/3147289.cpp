#include <iostream>
//#include <fstream>
using namespace std;
//ifstream cin("bfs.in");
//ofstream cout("bfs.out");
int n,m,s,b[200001],v[200001],a[2001][2001],i,x,y;
void bfs(int c)
{
  int i,k,st,dr,nr;
  st=dr=1;
  b[1]=c;
  v[c]=1;
  while(st<=dr)
  {
    k=b[st];
    for(i=1;i<=n;i++)
      if(v[i]==0 && a[k][i]==1)
      {
        v[i]=v[k]+1;
        dr++;
        b[dr]=i;
      }
    st++;
  }
  for(i=1;i<=n;i++)
    if(i==s)
        cout<<0<<" ";
    else if(i!=s && v[i]==0)
        cout<<-1<<" ";
    else
        cout<<v[i]-1<<" ";

}
int main()
{
    cin>>n>>m>>s;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        a[x][y]=1;
    }
    bfs(s);
   
}