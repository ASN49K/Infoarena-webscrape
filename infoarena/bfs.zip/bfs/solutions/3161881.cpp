#include <iostream>
#include <vector>
#include <queue>

using namespace std;

vector<int> edges[100005];
int dist[100005];
bool vis[100005];

void bfs(int s)
{
    queue<int> q;
    q.push(s);

    while (q.empty() == false)
    {
        int x = q.front();
        vis[x] = 1;
        q.pop();
        for (auto u: edges[x])
        {
            if (!vis[u])
            {
                dist[u] = dist[x] + 1;
                vis[u] = 1;
                q.push(u);

            }
        }
    }


}

int main()
{
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);
    int n, m, s;
    cin >> n >> m >> s;
    while (m--)
    {
        int x, y;
        cin >> x >> y;
        edges[x].push_back(y);
    }

    bfs(s);

    for (int z = 1; z <= n; z++)
    {
        if (vis[z])
        cout << dist[z] << " ";
        else
        cout << -1 << " ";
    }
    return 0;
}
