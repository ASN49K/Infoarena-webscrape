#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int N = 1e5;

vector <int> s[N+1];
int d[N+1], n;

void bfs(int x0)
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = -1;
    }
    queue <int> q;
    d[x0] = 0;
    q.push(x0);
    while (!q.empty())
    {
        int x = q.front();
        q.pop();
        for (auto y: s[x])
        {
            if (d[y] == -1)///pana acum nu am gasit un drum de la x0 la y
            {
                d[y] = 1 + d[x];///cel mai scurt drum de la x0 la y e drumul de la x0 la x + arcul (x,y)
                q.push(y);
            }
        }
    }
}

int main()
{
    ifstream in("bfs.in");
    ofstream out("bfs.out");
    int m, x0;
    in >> n >> m >> x0;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        s[x].push_back(y);
    }
    bfs(x0);
    for (int i = 1; i <= n; i++)
    {
        out << d[i] << " ";
    }
    in.close();
    out.close();
    return 0;
}
