//
//  main.cpp
//  BFS
//
//  Created by Andrada Minca on 05.02.2026.
//

#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
struct kk{
    int val;
    int dist;
};
int n,m,s;
vector<vector<bool>> a(n+1,vector<bool>(n));
vector<int> v(n+1,-1);
vector<bool>pr(n+1);
void bfs(int s)
{
    stack<kk>st;
    st.push({s,0});
    pr[s]=1;
    while(!st.empty())
    {
        kk nod=st.top();
        //cout<<nod.val<<endl;
        v[nod.val]=nod.dist;
        st.pop();
        for(int i=0;i<n;i++)
        {
            if(a[nod.val][i]==1&&pr[i]==0)
            {
                st.push({i,nod.dist+1});
                pr[i]=1;
            }
        }
    }
}
int main()
{
    cin>>n>>m>>s;
    pr.resize(n);
    v.resize(n);
    a.resize(n);
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        x--;
        y--;
        a[x][y]=1;
    }
    bfs(s-1);
    for(int i=0;i<n;i++)cout<<v[i]<<" ";
    return 0;
}
