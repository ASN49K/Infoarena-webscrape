#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int main() {
    int N, M, S;
    fin>>N>>M>>S;
    vector<vector<int>> adj(N + 1);
    for(int i=0;i<M;i++){
        int x, y;
        fin>>x>>y;
        adj[x].push_back(y);
    }

    const int INF = -1;
    vector<int> dist(N + 1, INF);
    queue<int> q;

    dist[S] = 0;
    q.push(S);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : adj[u]) {
            if (dist[v] == INF) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
    for (int i = 1; i <= N; i++) {
        fout << dist[i];
        if (i < N) fout << ' ';
    }
    return 0;
}
