#include <iostream>
#include <fstream>
#include <queue>
#include <bitset>
#include <vector>

#define maxSize 100001

using namespace std;

vector<vector<int>> readAdjacencyList(ifstream &fin, int nodes, int edges, bool isDirected = false) {
    vector<vector<int>> adjList(nodes + 1);
    for (int i = 0; i < edges; i++) {
        int x, y;
        fin >> x >> y;
        adjList[x].push_back(y);
        if (!isDirected) {
            adjList[y].push_back(x);
        }
    }
    return adjList;
}

vector<int> breadthFirstSearch(const vector<vector<int>>& adjList, int start) {
    bitset<maxSize> marked;
    marked[start] = true;
    vector<int> distance(adjList.size(), -1);
    distance[start] = 0;

    queue<int> q;
    q.push(start);

    while (!q.empty()) {
        int head = q.front();
        q.pop();

        for (auto node : adjList[head]) {
            if (!marked[node]) {
                distance[node] = distance[head] + 1;
                marked[node] = true;
                q.push(node);
            }
        }
    }
    return distance;
}

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    int nodes, edges, start;
    fin >> nodes >> edges >> start;

    auto distance = breadthFirstSearch(readAdjacencyList(fin, nodes, edges), start);

    for (int i = 1; i <= nodes; i++) {
        fout << distance[i] << " ";
    }
    fout << endl;

    fin.close();
    fout.close();

    return 0;
}
