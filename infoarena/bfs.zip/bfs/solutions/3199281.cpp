#include <iostream>
#include <fstream>

using namespace std;
struct nod
{
    int a, b;
}v[100005];
ifstream f("bfs.in");
ofstream g("bfs.out");
int viz[100010],c[300010],start[1000010],t[2][1000010],n,m,s,x,y;
void bfsucliste(int s)
{
    int pi,ps,k,om,cnt=1;
    pi=ps=1;
    c[ps]=s;
    viz[s]=1;
    while(pi<=ps)
    {
        k=c[pi];
        om=start[k];
        cnt++;
        while(om)
        {
            if(viz[t[0][om]]==0)
            {

                c[++ps]=t[0][om];
                viz[t[0][om]]=cnt;
            }
            om=t[1][om];
        }
        pi++;
    }
}
int main()
{
    f>>n>>m>>s;
    int k=0;
    viz[s]=1;
    while(f>>x>>y)
    {
        k++;
        t[0][k]=y;
        t[1][k]=start[x];
        start[x]=k;
    }
    bfsucliste(s);
    viz[s]=0;
    for(int i=1;i<=n;i++)
    {
        if(i==s)
            g<<"0 ";
        else
        g<<viz[i]-1<<" ";
    }
    return 0;
}
