#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector < vector<int> > adj;
vector<bool> used;
int n,m,s;
queue<int> q;
vector<int> d, p;

void bfs(){
    while(!q.empty()){
        int v = q.front();
        q.pop();
        for (int u: adj[v]){
            if(!(used[u])){
                used[u]=true;
                q.push(u);
                d[u] = d[v] + 1;
                p[u] = v;
            }
        }
    }
}



int main(){
    fin >> n >> m >> s;
    adj.resize(n+1);
    d.resize(n+1);    
    p.resize(n+1);
    used.resize(n+1);

    for (int i=0;i<m;i++){
        int x,y;
        fin >> x >> y;
        adj[x].push_back(y);
    }

    p[s] = -1;
    q.push(s);
    used[s] = true;
    bfs();

    for(int i=1;i<=n;i++){
        if(used[i]){
            fout << d[i] << " ";    
        }
        else{
            fout << "-1" << " ";
        }
    }
    
    return 0;

}