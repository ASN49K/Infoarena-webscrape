#include<queue>
#include<vector>
#include<fstream>
#define MAX 100000
using namespace std;

ofstream cout("bfs.out");
ifstream cin("bfs.in");
vector<int> g[MAX+1];
int vis[MAX+1],d[MAX+1];
void bfs(int x){
    queue<int> q;
    q.push(x);
    vis[x]=1;
    d[x]=0;
    while (not q.empty())
    {
       x=q.front();
       q.pop();

    for(int next:g[x]){
       if(not vis[next]){
        q.push(next);
        vis[next]=1;

        d[next]=d[x]+1;
       }

    }
    }
    
}

int main(){
    int n,m,s;
    cin>>n>>m>>s;
    for(int i=1;i<=m;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
    
    }
    bfs(s);
    for(int i=1;i<=n;i++){
        if(i!=s&&d[i]==0) cout<<-1<<" ";
        else cout<<d[i]<<" ";
    }
}