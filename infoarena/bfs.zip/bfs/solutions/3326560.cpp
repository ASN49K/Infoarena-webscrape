#include <bits/stdc++.h>
#define ll long long

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<int>G[100001];
int n,m,d[100001];
void bfs(int nod){
    // merg in toti vecinii nodului, dupa care din fiecare apelez bfs
    queue<int>Q;
    for(auto x : G[nod]){
        if(1+d[nod] < d[x]){
            d[x]=1+d[nod];
            Q.push(x);
        }
    }
    while(!Q.empty()){
        bfs(Q.front());
        Q.pop();
    }
}
int main(){
    int start = 0;
    fin>>n>>m>>start;
    for(int i = 1;i<=n;i++)
        d[i]=1000000000;
    while(m--){
        int x,y; cin>>x>>y;
        G[x].push_back(y);

        }
    d[start] = 0;
    bfs(start);
    for(int i = 1; i<=n; i++){
       if(d[i]==1000000000)
       fout<<-1<<" ";
        else
            fout<<d[i]<<" ";
    }
    return 0;
}
