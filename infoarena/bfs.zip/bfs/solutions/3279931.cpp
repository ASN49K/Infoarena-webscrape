#include <fstream>
#include <vector>
#include <cmath>
#include <queue>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

int n, m, nod_start;
const int NMAX = 100005;
vector<int> Muchii[NMAX];
int distanta[NMAX];
queue<int> q;

void BFS() {
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (unsigned int i = 0; i < Muchii[nod].size(); i++) {
            int vecin = Muchii[nod][i];
            if (distanta[vecin] == -1) {
                q.push(vecin);
                distanta[vecin] = distanta[nod] + 1;
            }
        }
    }
}

int main()
{
    cin >> n >> m >> nod_start;
    for (int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        Muchii[x].push_back(y);
    }
    for (int i = 1; i <= n; i++) distanta[i] = -1;
    distanta[nod_start]=0;
    q.push(nod_start);
    BFS();
    for (int i = 1; i <= n; i++) cout << distanta[i] << " ";
    return 0;
}

