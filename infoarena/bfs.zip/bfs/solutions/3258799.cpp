#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
vector<int> g[100001];
int f[100001];
void bfs(int nod)
{
    queue<int> q;
    q.push(nod);
    f[q.front()] = 1;
    while(!q.empty())
    {
        int qn = q.front();
        q.pop();
        for(int i = 0; i < g[qn].size(); i++)
        {
            if(f[g[qn][i]] == 0)
            {
                q.push(g[qn][i]);
                f[g[qn][i]] = f[qn]+1;
            }
        }
    }
    return;
}
int main()
{
    int n, m, s;
    cin >> n >> m >> s;
    for(int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
    }
    int cnt = 0;
    bfs(s);
    for(int i = 1; i <= n; i++)
    {
        cout << f[i]-1 << " ";
    }
}