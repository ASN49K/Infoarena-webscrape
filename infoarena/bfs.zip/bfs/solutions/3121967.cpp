#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int s, n, viz[100001], l[100001];
long a[100001][100001];

void citire(){
    int x, y, m;
    fin >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        fin >> x >> y;
        a[x][y] = 1;
    }
}

void bfs(int x){
    for(int i = 1; i <= n; i++)
        l[i] = -1;
    viz[x] = 1;
    l[x] = 0;
    int p, u, c[100001];
    p = u = 1;
    c[1] = x;
    while(p <= u){
        x = c[p++];
        for(int i = 1; i <= n; i++)
           if(a[x][i] == 1 && !viz[i]){
             c[++u] = i;
             viz[i] = 1;
             l[i] = l[x] + 1;
        }
    }
}

int main()
{
    citire();
    bfs(s);
    for(int i = 1; i <= n; i++)
        fout << l[i] << ' ';

    return 0;
}
