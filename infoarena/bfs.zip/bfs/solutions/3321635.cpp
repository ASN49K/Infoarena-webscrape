
// https://infoarena.ro/problema/bfs
// n-am citit cerinta inainte de a scrie ;-;

#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

std::ifstream in("bfs.in");
std::ofstream out("bfs.out");

void bfs(std::vector<unsigned>* graph, long long* distance, unsigned entry) {
    std::queue<unsigned> queue;

    distance[entry] = 0;
    
    for(queue.push(entry); !queue.empty(); queue.pop()) {
        for(unsigned node : graph[queue.front()]) if( distance[node] == -1 ) {
            distance[node] = distance[queue.front()] + 1;
            queue.push(node);
        }
    }
}

int main() {
    unsigned nodes, edges, target;

    in >> nodes >> edges >> target;

    std::vector<unsigned> graph[100001];

    unsigned a, b;
    for(unsigned edge = 0; edge < edges; edge += 1) {
        in >> a >> b;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }

    long long distance[100001];
    for(unsigned node = 1; node <= nodes; node += 1) distance[node] = -1;

    bfs(graph, distance, target);

    for(unsigned node = 1; node <= nodes; node += 1) {
        out << distance[node] << ' ';
    }
}
