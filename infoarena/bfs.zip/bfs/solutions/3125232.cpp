#include <bits/stdc++.h>
using namespace std;

ifstream f ("bfs.in");
ofstream g ("bfs.out");

const int nmax = 1e5 + 3;

vector <int> v[nmax];

int a, b, n, m, st, nod, d[nmax];

queue <int> q;

int main()
{
    f >> n >> m >> st;

    while (m--)
    {
        f >> a >> b;
        v[a].push_back(b);
    }

    q.push(st);

    while (!q.empty())
    {
        nod = q.front();
        q.pop();

        for (int i = 0; i < v[nod].size(); ++i)
        {
            int urm = v[nod][i];

            if (urm == st)
                continue;

            if (d[urm] == 0)
            {
                d[urm] = d[nod] + 1;
                q.push(urm);
            }
        }
    }

    for (int i = 1; i <= n; ++i)
    {
        if (i != st && d[i] == 0)
            d[i] = -1;

        g << d[i] << ' ';
    }

    return 0;
}
