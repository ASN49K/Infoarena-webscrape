#include<fstream>
#include<vector>
#include<queue>
using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

const int N = 1e6, M=1e5;

vector<int> g[N+1];
int dist[M+1];

int main()
 {
    int n, m, s;
    cin >> n >> m >> s;

    for (int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
    }

    for (int i = 1; i <= n; i++)
        dist[i] = -1;
    dist[s] = 0;

    // BFS
    queue<int> q;
    q.push(s);
    while (!q.empty())
    {
        int nod = q.front();
        q.pop();

        for (auto vecin : g[nod])
            if (dist[vecin] ==-1)
            {
                dist[vecin]= dist[nod] + 1;
                q.push(vecin);
            }
    }

    for (int i = 1; i <= n; i++)
    {
        cout << dist[i] << ' ';
    }
    return 0;
}




