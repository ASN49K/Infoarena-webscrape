#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

int n,m,nod;
vector<int> v[100005];
int viz[100005], d[100005];
queue<int> q;

void BFS(int x){
    viz[x]=1;
    d[x]=0;
    q.push(x);
    while (q.empty()==false){
        int nod=q.front();
        q.pop();
        for (auto &it:v[nod]){
            if (viz[it]==0){
                viz[it]=1;
                d[it]=d[nod]+1;
                q.push(it);
            }
        }
    }
}

int main(){
    f>>n>>m;
    f>>nod;
    for (int i=1;i<=m;i++){
        int nod1, nod2;
        f>>nod1>>nod2;
        v[nod1].push_back(nod2);
    }

    for (int i=1;i<=n;i++){
        viz[i]=0;
        d[i]=-1;
    }

    BFS(nod);

    for (int i=1;i<=n;i++){
        g<<d[i]<<" ";
    }
    return 0;
}