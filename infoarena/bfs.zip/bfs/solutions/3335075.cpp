#include <iostream>
#include <vector>
#include <fstream>
#include <bitset>
#include <algorithm>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
int dist[100005];
vector<int> L[100005];
void bfs(int nod) {
    queue<int> q;
    q.push(nod);
    while (!q.empty()) {
        int curr=q.front();
        q.pop();
        for (auto it:L[curr])
            if (dist[it]>1+dist[curr]) {
                dist[it]=1+dist[curr];
                q.push(it);
            }
    }
}

int main() {
    int n,m,x;
    fin>>n>>m>>x;
    for (int i=1; i<=m; i++) {
        int a,b;
        fin>>a>>b;
        L[a].push_back(b);
    }
    for (int i=1; i<=n; i++)
        dist[i]=1e9;
    dist[x]=0;
    bfs(x);
    for (int i=1; i<=n; i++) {
        if (dist[i]!=1e9)
            fout<<dist[i]<<" ";
        else
            fout<<-1<<" ";
    }
    return 0;
}
// num=10,/=11,*=12,-=13,+=14,enter=15,.=16,