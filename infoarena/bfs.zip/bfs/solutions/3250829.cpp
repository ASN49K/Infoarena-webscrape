#include <iostream>
#include "vector"
#include "queue"
#include "algorithm"
#include "fstream"
#include "stack"
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");

int n, m;
vector<int> U[100], Viz;
vector<vector<int>> A;
queue<int> coada;
stack<int> stiva;
void citire_listaad(int cod, vector<int> U[100]) {
    int x, y;
    for (int i = 0; i < m; i++) {
        f >> x >> y;
        U[x].push_back(y);
        if (cod == 1)
            U[y].push_back(x);
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < U[i].size(); j++)
            cout << U[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

void BFS(int nod) {
    coada.push(nod);
    Viz.push_back(nod);
    while (!coada.empty()) {
        int a = coada.front();
        coada.pop();
        for (int i = 0; i < U[a].size(); i++)
            if (find(Viz.begin(), Viz.end(), U[a][i]) == Viz.end()) {
                Viz.push_back(U[a][i]);
                coada.push(U[a][i]);
                cout << U[a][i] << " ";
            }
    }
}

void bfs(int nod) {
    vector<int> V, Viz;
    V.resize(n + 1);
    Viz.resize(n + 1);
    for (int i = 1; i <= n; i++)
        V[i] = 0;
    for (int i = 1; i <= n; i++)
        Viz[i] = 0;
    coada.push(nod);
    Viz[nod] = 1;
    while (!coada.empty()) {
        int a = coada.front();
        coada.pop();
        for (int i = 0; i < U[a].size(); i++) {
            if (Viz[U[a][i]] == 0) {
                Viz[U[a][i]] = 1;
                V[U[a][i]] = V[a] + 1;
                coada.push(U[a][i]);
            }
        }
    }
    for (int i = 1; i <= n; i++)
        if (i != nod && V[i] == 0)
            V[i] = -1;
    for (int i = 1; i <= n; i++)
        g << V[i] << " ";
}

void DFS (int nod){
    vector<int>  Viz;
    Viz.resize(n + 1);
    for (int i = 1; i <= n; i++)
        Viz[i] = 0;
    stiva.push(nod);
    Viz[nod] = 1;
    while (!stiva.empty()) {
        int a = stiva.top();
        stiva.pop();
        for (int i = 0; i < U[a].size(); i++) {
            if (Viz[U[a][i]] == 0) {
                Viz[U[a][i]] = 1;
                stiva.push(U[a][i]);
            }
        }
    }

}

int main() {
    f >> n >> m;
    citire_listaad(2, U);
    bfs(2);
    return 0;
}
