#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> G[100001];
int N, M, S;

void citire() {
    fin >> N >> M >> S;

    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
}
void bfs(int start, int dist[]) {
    queue<int> q;
    q.push(start);
    dist[start] = 0;

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (int vec : G[nod]) {
            if (dist[vec] == -1) {
                q.push(vec);
                dist[vec] = dist[nod] + 1;
            }
        }
    }
}

int main() {

    int dist[100001];
    for (int i = 0; i <= 100001; ++i)
    {
        dist[i] = -1;
    }

    bfs(S, dist);

    for (int i = 1; i <= N; ++i) {
        fout << dist[i] << " ";
    }

    return 0;
}
