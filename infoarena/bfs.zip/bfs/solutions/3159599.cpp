#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");
const int NMax = 10000;
vector <int> ad[NMax + 1];
int cost[NMax+ 1];
bool viz[NMax + 1];
queue <int> Q;
int n, m, S;

void construire(int m, vector <int> ad[NMax + 1])
{
    int x, y;
    for (int i = 1; i <= m; i++)
    {
        in >> x >> y;
        ad[x].push_back(y);
    }
}

void afisare()
{
    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0) {
            out << -1 << ' ';
        }
        else 
            out << cost[i] << ' ';
    }
}

void bfs(int S){
    Q.push(S);
    viz[S] = 1;
    while (!Q.empty()) {
        int nod = Q.front();
        Q.pop();
        for (int i = 0; i < ad[nod].size(); i++) {
            int vecin = ad[nod][i];
            if (!viz[vecin]) {
                viz[vecin] = true;
                Q.push(vecin);
                cost[vecin] = cost [nod] + 1;
            }
        }
    }
}

int main(){
    in >> n >> m >> S;
    construire(m, ad);
    bfs(S);
    afisare();
    in.close();
    return 0;
}