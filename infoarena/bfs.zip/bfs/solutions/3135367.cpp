/*
 * Graph struct
 */
//#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
struct Graph{
    struct Edge{
        ///struct for edges
        int u,v,w;
        Edge(int u,int v,int w){
            this->u=u;
            this->v=v;
            this->w=w;
        }
        Edge(int u,int v){
            this->u=u;
            this->v=v;
            this->w=1;
        }
    };
    struct Corr_Edge{
        ///struct for the correspondent node and weight for a certain edge
        int v,w;
        Corr_Edge(int v,int w){
            this->v=v;
            this->w=w;
        }
        Corr_Edge(int v) {
            this->v = v;
            this->w = 1;
        }
    };

    int nodes,edges;
    vector <Edge> edge_set;
    vector <int> reachable;
    vector <vector<Corr_Edge > >adjacency_list;
    Graph(int nodes){
        this->nodes=nodes;
        this->edges=0;
        for(int i=0;i<=nodes;i++){
            vector <Corr_Edge > v;
            adjacency_list.push_back(v);
            reachable.push_back(-1);
        }
    }
    void add_Edge(Edge x){
        edge_set.push_back(x);
        adjacency_list[x.u].push_back(Corr_Edge(x.v,x.w));
    }
    void add_Edge(int u,int v,int w){
        edge_set.push_back(Edge(u,v,w));
        adjacency_list[u].push_back(Corr_Edge(v,w));
        adjacency_list[v].push_back(Corr_Edge(u,w));
    }
    void add_Edge(int u,int v){
        edge_set.push_back(Edge(u,v));
        adjacency_list[u].push_back(Corr_Edge(v,1));
        adjacency_list[v].push_back(Corr_Edge(u,1));
    }
    void add_DirEdge(int u,int v,int w){
        edge_set.push_back(Edge(u,v,w));
        adjacency_list[u].push_back(Corr_Edge(v,w));
    }
    void add_DirEdge(int u,int v){
        edge_set.push_back(Edge(u,v));
        adjacency_list[u].push_back(Corr_Edge(v,1));
    }
    void bfs(int source){
        vector <int> s;
        s.push_back(source);
        bfs(s);
    }
    void bfs(vector <int> source){
        queue <pair<int,int> >q;
        for(auto u:source) {
            q.push(make_pair(u, 0));
        }
        fill(reachable.begin(),reachable.end(),-1);
        reachable[source]=0;
        while(!q.empty()){
            auto u=q.front();
            q.pop();
            int curr=u.first,curr_cost=u.second;
            for(auto uu:adjacency_list[curr]){
                if(reachable[uu.v]==-1){
                    reachable[uu.v]=curr_cost+1;
                    q.push(make_pair(uu.v,curr_cost+1));
                }
            }
        }
    }
    int bfs_distance(int nod){
        return reachable[nod];
    }
};


int main(){
    int n,m,s;
    cin>>n>>m>>s;
    Graph g(n);
    for(int i=1;i<=m;i++){
        int a,b;
        cin>>a>>b;
        g.add_DirEdge(a,b);
    }
    g.bfs(s);
    for(int i=1;i<=n;i++){
        cout<<g.bfs_distance(i)<<" ";
    }

}