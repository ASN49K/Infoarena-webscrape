#include <bits/stdc++.h>

using namespace std;

int main() {
#ifndef LOCAL
  freopen("bfs.in", "r", stdin);
  freopen("bfs.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int N;
  int M;
  int S;
  cin >> N >> M >> S;
  --S;
  vector<vector<int>> G(N);
  for (; M--;) {
    int X;
    int Y;
    cin >> X >> Y;
    --X;
    --Y;
    G[X].push_back(Y);
  }
  vector<int> D(N, INT_MAX);
  queue<int> q;
  D[S] = 0;
  q.push(S);
  for (; q.size();) {
    int X = q.front();
    q.pop();
    for (int const Y : G[X]) {
      if (D[Y] == INT_MAX) {
        D[Y] = D[X] + 1;
        q.push(Y);
      }
    }
  }
  for (int i = 0; i < N; ++i) {
    if (i) {
      cout << " ";
    }
    cout << (D[i] == INT_MAX ? -1 : D[i]);
  }
  cout << endl;
  return 0;
}