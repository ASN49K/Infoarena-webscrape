from collections import deque

def rezolva_bfs():
    try:
        with open('bfs.in', 'r') as fin:
            n, m, s = map(int, fin.readline().split())
            
            graf = [[] for _ in range(n + 1)]
            
            for _ in range(m):
                x, y = map(int, fin.readline().split())
                graf[x].append(y)

        distante = [-1] * (n + 1)
        coada = deque()

        distante[s] = 0
        coada.append(s)

        while coada:
            nod_curent = coada.popleft()
            
            for vecin in graf[nod_curent]:
                if distante[vecin] == -1:
                    distante[vecin] = distante[nod_curent] + 1
                    coada.append(vecin)
        
        with open('bfs.out', 'w') as fout:
            rezultat = distante[1:]
            fout.write(' '.join(map(str, rezultat)))

    except FileNotFoundError:
        print("Eroare: Fisierul 'bfs.in' nu a fost gasit.")
    except Exception as e:
        print(f"A aparut o eroare: {e}")

rezolva_bfs()