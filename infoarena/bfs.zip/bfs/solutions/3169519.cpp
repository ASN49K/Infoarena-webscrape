 #include <vector>
 #include <queue>
 #include <fstream>
  
 using namespace std;
  ifstream in("bfs.in");
  ofstream out("bfs.out");
     
int n,m;
vector <int> v[100001];
queue <int> q;
int d[100001];
int main() {
  
  int s,i,x,y;
  in>>n>>m>>s;  
  for(i=1;i<=m;i++)
  {
    in>>x>>y;
    v[x].push_back(y);
  }
  d[s]=1;
  q.push(s);
  while(!q.empty())
  {
    x=q.front();
    q.pop();
    int l=v[x].size();
    for(i=0;i<l;i++)
      if(d[v[x][i]]==0)
        {
          d[v[x][i]]=d[x]+1;
          q.push(v[x][i]);
        }
  }
  for(i=1;i<=n;i++)
    out<<d[i]-1<<" ";
  return 0;
}