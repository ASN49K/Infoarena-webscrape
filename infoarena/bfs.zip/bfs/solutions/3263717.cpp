#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector <int> a[NMAX];
bool viz[NMAX]; //viz[i]=0, daca vf i nu a fost vizitat;sau  nr de vf de pe cel mai scurt drum de la start la i
int c[NMAX];
int n, start, inc , sf, i;
void bfs(int x);
void citire();

int main()
{
    citire();
    bfs(start);
    for(i=1; i<=n; i++)
    {
        fout << viz[i]-1 << ' ';
    }
    fout.close();
    return 0;
}

void citire()
{
    int i, x, m, y;
    fin >> n >> m >> start;
    for(i=0; i<m; i++)
    {
        fin>>x>>y;
        //y intra in lista de adiacenta a lui x
        a[x].push_back(y);
    }
}

void bfs(int x)
{
    int i;
    viz[x]=1;
    c[1]=x; inc=sf=1; //punem pe x in coada
    while(inc<=sf)
    {
        x=c[inc++];

    //parcurg vf adiacente cu x
    for(i=0; i<=a[x].size(); i++)
        if(!viz[a[x][i]])
        {
            viz[a[x][i]]=1+viz[x];;
            c[++sf]=a[x][i];
        }
    }
}
