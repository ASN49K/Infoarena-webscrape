#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

long long n, m, x, y, a,viz[1000], d[1000];

vector<int> v[1000];

void BFS(int st)
{
    queue<int> q;
    q.push(st);
    while(!q.empty())
    {
        int j=q.front();
        viz[j]=1;
        for(auto i: v[j])
        {
            if(!viz[i])
            {
                d[i]=d[j]+1;
                q.push(i);
            }
        }
        q.pop();
    }
}

int main()
{
    cin>>n>>m>>a;
    for(int i=1;i<=n;i++)
        d[i]=-1;
    d[a]=0;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
    }
    BFS(a);
    for(int i=1;i<=n;i++)
        cout<<d[i]<<" ";
}
