#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <utility>
#include <algorithm>
#include <fstream>


std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");

// void edgeList(int n, int m, std::list<std::pair<int, int>>& E){
//     int x, y;
//     while (fin >> x >> y){
//         E.push_back(std::make_pair(x, y));
//     }
// }

void BFS(int n, int m, int s, std::vector<std::vector<int>> v){
    std::queue<int> q;
    q.push(s);

    std::vector<int> visited(n + 1, 0);
    visited[s] = 1;

    std::vector<int> road;
    road.resize(n + 1);
    road[0] = s;
    int cnt = 1;

    std::vector<int> distance;
    distance.resize(n + 1);
    distance[s] = 0;
    // 1 0 0 0 1 0 0 1 1 0
    for (auto x : road){
        for (const auto& next : v[x]){
            if (visited[next] == 0){
                q.push(next);
                visited[next] = 1;
                road[cnt++] = next;
                distance[next] = distance[x] + 1;
            }
        }
    }

    // while (!q.empty()){
    //     std::cout << q.front() << ' ';
    //     q.pop();
    // }

    for (int i = 1; i < n + 1; ++i){
        bool ok = true;
        std::queue<int> tempQ = q;
        while(!tempQ.empty()){
            if (tempQ.front() == i)
                ok = false;
            tempQ.pop();
        }
        if (ok)
            distance[i] = -1;
    } 

    for (int i = 1 ; i <= n; ++i)
        fout << distance[i] << ' ';

}


int main(){

    int n, m, s, x, y;
    fin >> n >> m >> s;

    std::vector<std::vector<int>> v;
    v.resize(n + 1);
    while (fin >> x >> y) {
        v[x].push_back(y);
    }

    BFS(n, m, s, v);
    // for (int i = 0; i < v.size(); ++i, std::cout << '\n')
    //     for (int j = 0; j < v[i].size(); ++j)
    //         std::cout << v[i][j] << ' ';
    return 0;
}