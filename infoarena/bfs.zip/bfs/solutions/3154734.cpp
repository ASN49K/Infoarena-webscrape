#include <fstream>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

vector<int> mat[100001];
queue<int> q;
int n, m, s;
int viz[100001];
int dist[100001];

void bfs()
{
    while(!q.empty())
    {
        int nod = q.front();
        for(int i : mat[nod])
        {
            if(viz[i] == 0)
            {
                dist[i] = dist[nod] + 1;
                q.push(i);
                viz[i] = 1;
            }
        }

        q.pop();
    }
}

int main()
{
    cin >> n >> m >> s;
    for(int i = 0; i<m; i++)
    {
        int a, b;
        cin >> a >> b;
        mat[a].push_back(b);
    }

    q.push(s);
    viz[s] = 1;
    bfs();

    for(int i = 1; i<=n; i++)
    {
        if(dist[i] == 0 && i != s)
            cout << -1 << ' ';
        else
            cout << dist[i] << ' ';
    }

}
