#include<iostream>
#include<fstream>
#include<vector>
#include<queue>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int Nmax = 100001;
const int Mmax = 1000001;

int n, m, s;
vector<int> edges[Mmax];
int viz[Nmax], tata[Nmax], d[Nmax];

void BFS(int start)
{
    for (int i=1; i<=n; i++) // reset valori
    {
        viz[i]=0;
        tata[i]=0;
        d[i]=-1;
    }
    
    queue<int> q;

    d[start] = 0;
    viz[start] = 1;
    q.push(start);

    while (!q.empty())
    {
       int currNode = q.front();
       q.pop();

       for ( int vec : edges[currNode])
       {
            if (viz[vec] == 0)
            {
                q.push(vec);
                viz[vec] = 1;
                d[vec] = d[currNode]+1;
                tata[vec] = tata[currNode];
            }
       }
    }
}

int main()
{
    int x, y;

    fin >> n >> m >> s;

    for (int i = 0; i < m; i++)
    {
        fin >> x >> y;
        edges[x].push_back(y);
    }

    BFS(s);

    for(int i = 1; i <= n; i++)
        fout<<d[i]<<" ";
    fout<<"\n";

    return 0;
}