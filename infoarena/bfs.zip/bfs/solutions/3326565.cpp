#include <bits/stdc++.h>
#define ll long long

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<int>G[100001];
int n,m,d[100001];

int main(){
    int start = 0;
    fin>>n>>m>>start;
    for(int i = 1;i<=n;i++)
        d[i]=1000000000;
    while(m--){
        int x,y; fin>>x>>y;
        G[x].push_back(y);

        }
    d[start] = 0;
    queue<int>Q;
    Q.push(start);
    while(!Q.empty()){
        int nod = Q.front();
        Q.pop();
        for(auto x : G[nod]){
            if(d[x] > d[nod]+1){
                d[x]=d[nod]+1;
                Q.push(x);
            }
        }
    }
    for(int i = 1; i<=n; i++){
       if(d[i]==1000000000)
       fout<<-1<<" ";
        else
            fout<<d[i]<<" ";
    }
    return 0;
}
