#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int Nmax = 1e5 + 5;
vector<vector<int>>v(Nmax);
int ans[Nmax],viz[Nmax];
int n,m,S;
queue<int>Q;
void bfs(){
  while(Q.empty() == false){
     int x = Q.front();
     for(int i = 0; i < v[x].size(); ++ i){
        int aux = v[x][i];
        if(viz[aux] == 0){
            viz[aux] = 1;
            ans[aux] = ans[x] + 1;
            Q.push(aux);
        }
     }
     Q.pop();
  }

}
int main()
{
    fin >> n >> m >> S;
    while(m){
        -- m;
        int x,y;
        fin >> x >> y;
        v[x].push_back(y);
    }
    ans[S] = 1;
    viz[S] = 1;
    Q.push(S);
    bfs();
    for(int i = 1; i <= n; ++ i){
        if(ans[i] == 0){
            fout << -1 << " ";
        }
        else{
            fout << ans[i] - 1 << " ";
        }
    }
    return 0;
}
