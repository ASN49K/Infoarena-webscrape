#include  <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
const int NMAX = 1e5;
// bool havelHakimi(int deg[NMAX+1], int m) {
//
//     int sum=0;
//     for (int i=0; i<m; i++) {
//         sum+=deg[i];
//         if (deg[i]>=m) return false;
//         if (deg[i]<0) return false;
//     }
//     if ( sum%2 ==1 ) return false;
//     sort(deg, deg+m, greater<int>());
//     for (int i=0; i<m; i++) {
//         int t=deg[i];
//         if (t > m-i-1) return false;
//         for (int j=i+1; j<i+t+1; j++) {
//             deg[j]--;
//             if (deg[j]<0) return false;
//         }
//         deg[i]=0;
//         if (deg[i]>0 ) return false;
//         sort(deg, deg+m, greater<int>());
//     }
//     return true;
// }



int main () {
    // int n, m;
    // cin>>n;
    // for (int i=0; i<n; i++) {
    //     cin>>m;
    //     int deg[100001];
    //     for (int j=0; j<m; j++) {
    //         cin>>deg[j];
    //     }
    //     int ok=havelHakimi(deg, m);
    //
    //     if (ok==1) cout<<"POSSIBLE"<<endl;
    //     else cout<<"IMPOSSIBLE"<<endl;
    // }

    int n,m,a,b,s;
    cin>>n>>m>>s;
    vector<vector<int> > adj(n+1);

    for (int i=0; i<m; i++) {
        cin>>a>>b;
        adj[a].push_back(b);
    }
    vector<int> dist(n+1, -1);
    queue<int> q;
    dist[s]=0;
    q.push(s);

    while(!q.empty()) {
        int u=q.front();
        q.pop();
        for ( auto i : adj[u]) {
            if (dist[i]==-1) {
                dist[i]=dist[u]+1;
                q.push(i);
            }
        }
    }

    for ( int i=1; i<=n; i++ ) {
        cout<<dist[i]<<" ";
    }
    return 0;
}

