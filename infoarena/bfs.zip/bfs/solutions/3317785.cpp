#include <iostream>
#include <queue>
#include <vector>

using namespace std;
const int NMax=100000;
vector<int> V;
vector<int> G[NMax+3];
queue<int> Q;
int N,M;
int D[NMax+3];
int S;
bool Use[NMax+3];

void Read(){
    cin >> N >> M >> S;
    for(int i=1;i<=M;++i){
        int x,y;
        cin >> x >> y;
        G[x].push_back(y);
    }
}

void BFS(int Start){
    for(int i=1;i<=N;++i){
        D[i]=-1;
    }
    Q.push(Start);D[Start]=0;
    while(!Q.empty()){
        int Nod=Q.front();Q.pop();
        for(auto Vecin : G[Nod]){
            if(D[Vecin]==-1){
                D[Vecin]=D[Nod]+1;
                Q.push(Vecin);
            }
        }
    }
}

int main()
{
    Read();
    BFS(S);
    for(int i=1;i<=N;i++){
        cout << D[i] << " ";
    }
}
