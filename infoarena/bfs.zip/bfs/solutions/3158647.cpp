#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int Nmax = 100005;

vector<int> graf[Nmax];
int pasi[Nmax];
queue<int> q;

int main(){
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    int n, m, s, nod, a, b;

    fin >> n >> m >> s;

    for(int i = 0; i < m; i++){
        fin >> a >> b;
        graf[a].push_back(b);
    }

    for(int i = 1; i <= n; i++){
        pasi[i] = -1;
    }

    pasi[s] = 0;
    q.push(s);

    while(!q.empty()){
        nod = q.front();
        q.pop();

        for(int vecin : graf[nod]){
            if(pasi[vecin] == -1){
                pasi[vecin] = pasi[nod] + 1;
                q.push(vecin);
            }
        }
    }

    for(int i = 1; i <= n; i++){
        fout << pasi[i] << " ";
    }

    return 0;
}
