#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 1e5 + 5, INF = 1e9;
vector<int> g[NMAX];
int d[NMAX], n, m, s;

void bfs(const int &start) {
    for (int i = 1; i <= n; i++)
        d[i] = INF;
    d[start] = 0;

    queue<int> q;
    q.push(start);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (auto nxt : g[nod]) {
            if (d[nod] + 1 < d[nxt]) {
                d[nxt] = d[nod] + 1;
                q.push(nxt);
            }
        }
    }
}

int main() {

    fin >> n >> m >> s;
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i++) {
        if (d[i] >= INF)
            d[i] = -1;
        fout << d[i] << ' ';
    }

    return 0;
}
