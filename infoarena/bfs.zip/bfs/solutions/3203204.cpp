// #include <iostream>

#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

const int NMAX = 100001;
int dist[NMAX];
vector<int>g[NMAX];

void bfs(int st)
{
	queue<int>q;
	q.push(st);
	dist[st] = 0;
	while (!q.empty())
	{
		int p = q.front();
		q.pop();
		for(auto x:g[p])
			if (dist[x] == -1)
			{
				dist[x] = dist[p] + 1;
				q.push(x);
			}
	}
}

int main()
{
	int n, m, s;
	cin >> n >> m >> s;
	for (int i = 1; i <= n; i++)
		dist[i] = -1;
	for (int i = 0; i < m; i++)
	{
		int x, y;
		cin >> x >> y;
		g[x].push_back(y);
	}
	bfs(s);
	for (int i = 1; i <= n; i++)
		cout << dist[i] << ' ';
	return 0;
}