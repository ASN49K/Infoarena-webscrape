#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int NMAX = 100005;
vector<int> adj[NMAX];
int dist[NMAX];

void bfs(int s, int n) {
    for (int i = 1; i <= n; ++i) {
        dist[i] = -1;
    }
    queue<int> q;
    dist[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (int neighbor : adj[node]) {
            if (dist[neighbor] == -1) {
                dist[neighbor] = dist[node] + 1;
                q.push(neighbor);
            }
        }
    }
}

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    int n, m, s;
    fin >> n >> m >> s;

    for (int i = 0; i < m; ++i) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }

    bfs(s, n);

    for (int i = 1; i <= n; ++i) {
        fout << dist[i] << " ";
    }
    fout << "\n";

    fin.close();
    fout.close();
    return 0;
}