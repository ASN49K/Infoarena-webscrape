#include <bits/stdc++.h>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

vector <int> v[100001];
int dist[100001];
int n, m;

void bfs(int sursa)
{
    for (int i = 1; i <= n; i++)
        dist[i] = -1;
    dist[sursa] = 0;

    queue <int> q;
    q.push(sursa);
    while (!q.empty())
    {
        int nod = q.front();
        q.pop();
        for (auto vecin : v[nod])
        {
            if (dist[vecin] == -1)
            {
                q.push(vecin);
                dist[vecin] = dist[nod] + 1;
            }
        }
    }
}
int main()
{
    int s;
    fin >> n >> m >> s;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i++)
        fout << dist[i] << " ";
    return 0;
}
