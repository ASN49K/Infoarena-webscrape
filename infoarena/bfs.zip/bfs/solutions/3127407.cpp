#include <fstream>
#include <queue>
using namespace std;

vector<int> v[100005];
bool vis[100005];
int dist[100005];
void bfs(int st)
{
    queue<int> q;
    q.push(st);
    vis[st]=1;
    while(!q.empty())
    {
        int t=q.front();
        for(auto x : v[t])
        {
            if(vis[x]==0)
            {
                q.push(x);
                dist[x]=dist[t]+1;
                vis[x]=1;
            }
        }
        //vis[t]=1;
        q.pop();
    }
}
int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    int n,m,st,x,y;
    cin >> n >> m >> st;
    for(int i=0;i<m;i++)
    {
        cin >> x >> y;
        v[x].push_back(y);
    }
    bfs(st);
    for(int i=1;i<=n;i++)
    {
        if(dist[i]==0 && i!=st)
            cout << "-1 ";
        else
            cout << dist[i] << " ";
    }
    return 0;
}
