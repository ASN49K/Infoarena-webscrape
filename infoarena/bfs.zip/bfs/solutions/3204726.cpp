#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int N,M,S;
int d[100001];
int main()
{
    fin>>N>>M>>S;
    queue<int> q;
    vector<int>drumuri[N+1];
    for(int i=1;i<=M;i++)
    {
        int x,y;
        fin>>x>>y;
        drumuri[x].push_back(y);
    }
    for(int i=1;i<=N;i++)
    {
       d[i]=10000000;
    }
    d[S]=0;
    q.push(S);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        for(auto node:drumuri[x]) {
            if (d[node] >= d[x] + 1) {
                d[node] = d[x] + 1;
                q.push(node);
            }
        }
    }
    for(int i=1;i<=N;i++)
    {
        if (d[i]==10000000)
        {
            d[i]=-1;
        }
    }
    for(int i=1;i<=N;i++)
    {
        fout<<d[i]<<" ";
    }
    return 0;
}
