#include <bits/stdc++.h>

using namespace std;

int n, m, s, x, y, dist[105], viz[105], i;
vector<int> v[105];
queue<int> q;

void bfs ( int st ){
     viz[st] = 1;
     q.push(st);
     while ( !q.empty() ){
             int x = q.front();
             q.pop();
             for ( auto el:v[x] ){
                   if ( viz[el] == 0 ){
                        viz[el] = 1;
                        q.push(el);
                        dist[el] = dist[x] + 1;
                   }
             }
     }
}

int main()
{
    cin >> n >> m >> s;
    for ( i = 1; i <= m; i++ ){
          cin >> x >> y;
          v[x].push_back(y);
    }
    bfs(s);
    for ( i = 1; i <= n; i++ ){
          if ( dist[i] == 0 && i != s ) cout << "-1" << " ";
          else cout << dist[i] << " ";
    }

}
