#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> l[100001];
int d[100001];

void bfs(int start) {
    for (int i = 0; i < 100001; i++) {
        d[i] = -1;
    }

    queue<int> q;
    q.push(start);
    d[start] = 0;
    while(!q.empty()) {
        int curr = q.front();
        q.pop();
        for(auto v : l[curr]) {
            if(d[v] == -1) {
                d[v] = d[curr] + 1;
                q.push(v);
            }
        }
    }
}

int main() {

    int n, m, s;
    fin >> n >> m >> s;
    for(int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        l[x].push_back(y);
    }
    
    bfs(s);

    for(int i = 1; i <= n; i++) {
        fout << d[i] << ' ';
    }

    return 0;
}