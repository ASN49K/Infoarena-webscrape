#include <iostream>
#include <vector>
#include <queue>

#define NMAX 200000

using namespace std;

int
main() {
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);
    int n, m, source;
    cin >> n >> m >> source;
    vector<int> adj[n + 1];
    int nod1, nod2;
    for (int i = 0; i < m; ++i) {
        cin >> nod1 >> nod2;
        adj[nod1].push_back(nod2);
    }
    int parent[n + 1];
    for (int i = 1; i <= n; ++i) {
        parent[i] = 0;
    }
    int d[n + 1];
    for (int i = 1; i <= n; ++i) {
        d[i] = INT32_MAX - 2;
    }
    d[source] = 0;

    queue<int> q;

    q.push(source);
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (int i = 0; i < adj[node].size(); ++i) {
            int neigh = adj[node][i];
            if (d[node] + 1 < d[neigh]) {
                parent[neigh] = node;
                d[neigh] = d[node] + 1;
                q.push(neigh);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (d[i] == (INT32_MAX - 2)) {
            cout << -1 << " ";
            continue;
        }
        cout << d[i] << " ";
    }

    return 0;
}