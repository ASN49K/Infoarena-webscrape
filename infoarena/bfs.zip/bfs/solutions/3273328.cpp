#include <iostream>
#include<fstream>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int mat[10001][10001];
int dist[10001];
const int INF=1e9;

int main()
{
    int n, m, k, x, y;
    fin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        mat[x][y]=1;
    }
    int C[10001], p = 1, u = 1;
    C[1] = k;
    for(int i=1;i<=n;i++)
        dist[i]=INF;
    dist[k] = 0;
    while (p <= u)
    {
        int nodCrt = C[p];
        for (int vecin = 1; vecin <= n; vecin++)
            if (mat[nodCrt][vecin] == 1 && dist[vecin]==INF)
            {
                dist[vecin] = dist[nodCrt] + 1;
                u++;
                C[u] = vecin;
            }
        p++;
    }
    for(int i=1;i<=n;i++){
        if(dist[i]==INF)
            dist[i]=-1;
        fout<<dist[i]<<" ";
    }
    return 0;
}
