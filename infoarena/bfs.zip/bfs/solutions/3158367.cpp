#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

std::ifstream f("bfs.in");
std::ofstream g("bfs.out");

const int MAX_N = 100001;
std::vector<std::vector<int>> adjacencyList(MAX_N);

// construire lista adiacenta
void buildAdjacencyList(int n, int m)
{
    for (int i = 0; i < n; ++i)
    {
        adjacencyList[i].clear();
    }

    for (int i = 0; i < m; i++)
    {
        int u, v;
        f >> u >> v;
        if(u != v)
            adjacencyList[u].push_back(v);
    }
}

void BFS(int node, std::vector<int> &d)
{
    std::queue<int> c;
    c.push(node);
    while (!c.empty())
    {
        int n = c.front();
        c.pop();
        for (int x : adjacencyList[n])
        {
            if (d[x] == 0)
                d[x] = d[n] + 1, c.push(x);
        }
    }
}

int main()
{
    if (!f.is_open())
    {
        std::cerr << "Eroare deschidere fisier\n";
        return 1;
    }

    int n, m, s;
    f >> n >> m >> s;

    buildAdjacencyList(n, m);

    std::vector<int> d(n + 1);
    BFS(s, d);

    for (int i = 1; i < d.size(); i++)
    {
        if (i == s)
            g << 0 << " ";
        else if (d[i] == 0)
            g << -1 << " ";
        else
            g << d[i] << " ";
    }

    return 0;
}