#include <fstream>
#include <queue>
#include <vector>

#define MAX_N 100005

std::vector<int> adj[MAX_N];
int dist[MAX_N];

void bfs(int start) {
    std::queue<int> queue;
    queue.push(start);
    dist[start] = 0;

    while (!queue.empty()) {
        int node = queue.front();
        queue.pop();

        for (int neighbor : adj[node]) {
            if (dist[neighbor] == -1) {
                dist[neighbor] = dist[node] + 1;
                queue.push(neighbor);
            }
        }
    }
}

int main() {
    std::ifstream fin("bfs.in");
    std::ofstream fout("bfs.out");

    int n, m, s;
    fin >> n >> m >> s;

    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
    }

    for (int i = 0; i < m; i++) {
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
    }

    bfs(s);

    for (int i = 1; i <= n; i++) {
        fout << dist[i] << " ";
    }
    fout << "\n";

    fin.close();
    fout.close();
}
