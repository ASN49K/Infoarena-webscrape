#include <fstream>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

ofstream output("bfs.out");
vector <vector < int > > adj_list;
queue <int> bfs_queue;
vector < int > dist;

int main() {
    int N, M, S;
    ifstream input("bfs.in");
    input >> N >> M >> S;
    adj_list.resize(N + 1);
    dist.resize(N + 1, -1);
    int from, to;
    while (input >> from >> to) {
        adj_list[from].push_back(to);
    }
    dist[S] = 0;
    bfs_queue.push(S);
    while (!bfs_queue.empty()) {
        int current = bfs_queue.front();
        bfs_queue.pop();
        for (int neighbour : adj_list[current]) {
            if (dist[neighbour] == -1) {
                dist[neighbour] = dist[current] + 1;
                bfs_queue.push(neighbour);
            }
        }
    }
    for (int i = 1; i <= N; i++)
        output << dist[i] << " ";
    return 0;
}