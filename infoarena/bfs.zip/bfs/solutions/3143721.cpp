#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5, INF = 1e6;
vector<int> edges[NMAX + 5];
int ans[NMAX + 5];

int main()
{
    #ifndef TEST
        freopen("bfs.in", "r", stdin);
        freopen("bfs.out", "w", stdout);
    #endif
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    
    int n, m, s;
    cin >> n >> m >> s;
    for (int i = 1; i <= n; i++)
        ans[i] = -1;
    while (m--)
    {
        int u, v;
        cin >> u >> v;
        edges[u].push_back(v);
    }
    queue<int> q;
    q.push(s);
    ans[s] = 0;
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        for (auto v : edges[u])
            if (ans[v] == -1)
            {
                ans[v] = ans[u] + 1;
                q.push(v);
            }
    }
    for (int i = 1; i <= n; i++)
        cout << ans[i] << ' ';
    return 0;
}