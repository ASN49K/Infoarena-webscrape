#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NMAX = 100000;
vector <int> G[NMAX + 1];
int vis[NMAX + 1];
int d[NMAX+1];

void BFS(int x) {

    queue<int>q;
    q.push(x);
    d[x]=0;
    vis[x]=1;
    while(!q.empty()){
        x=q.front();
        g<<x<<" ";
        q.pop();
        for(auto next: G[x]){
            if(!vis[next]){
                q.push(next);
                vis[next]=1;
                d[next]=d[x]+1;
            }
        }
    }

}

int main()
{
	int n, m, t;
	f >> n >> m >> t;
	for (int i = 1; i <= m; i++) {
		int x, y;
		f >> x >> y;
		G[x].push_back(y);
	}


    return 0;
}

