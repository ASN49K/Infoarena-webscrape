#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

#define NMAX 100005
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, dist[NMAX];
vector<int> g[NMAX];
queue<int> coada;

void bfs() {
    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        for (int vecin : g[nod])
        {
            if (dist[vecin] == -1)
            {
                coada.push(vecin);
                dist[vecin] = dist[nod] + 1;
            }
        }
    }
}

void citire() {
    int nodstart;
    fin >> n >> m >> nodstart;

    for (int i = 0; i < m; ++i) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
    }

    memset(dist, -1, sizeof(dist));
    dist[nodstart] = 0;
    coada.push(nodstart);
    bfs();

    for (int i = 1; i <= n; ++i)
        fout << dist[i] << ' ';
}

int main() {
    citire();
    return 0;
}
