#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");

int n,m;
int viz[100001];
queue <int> q;
vector <int> lista[100001];

void bfs(int nod)
{
    viz[nod]=1;
    q.push(nod);
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(auto x:lista[nod])
        {
            if(viz[x]==0)
            {
                viz[x]=viz[nod]+1;
                q.push(x);
            }
        }
    }
}

int main()
{
    int x,y,i,s;
    cin>>n>>m>>s;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        lista[x].push_back(y);
    }
    
    bfs(s);
    
    for(int i=1;i<=n;i++)
        cout<<viz[i]-1<<" ";
    return 0;
}