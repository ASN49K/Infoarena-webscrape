#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
#define N 100005

int n, m, source;
vector<int> v[N];

void read() {
	fin >> n >> m >> source;
	for (int i = 1; i <= m; i++) {
		int x, y;
		fin >> x >> y;
		v[x].push_back(y);
	}
}

// minumum distance from source to every node
void calculate()
{
	int d[N];
	for (int i = 1; i <= n; i++)
		d[i] = -1;
	d[source] = 0;
	queue<int> q;
	q.push(source);
	while (!q.empty()) {
		int x = q.front();
		q.pop();
		for (int i = 0; i < v[x].size(); i++) {
			int y = v[x][i];
			if (d[y] == -1) {
				d[y] = d[x] + 1;
				q.push(y);
			}
		}
	}
	for (int i = 1; i <= n; i++)
		fout << d[i] << " ";
}

int main()
{
	read();
	calculate();
	return 0;
}
