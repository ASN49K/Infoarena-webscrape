#include<iostream>
#include<vector>
#include <queue>
#include<fstream>
using namespace std;
const int NMAX = 10e5;
vector<int>G[NMAX];
int viz[NMAX + 1];
#include<fstream>
#include<queue>
#include<vector>
ifstream in("dfs.in");
ofstream out("dfs.out");
int d[NMAX + 1];
void BFS(int x)
{
	queue <int> q;
	q.push(x);
	d[x] = 0;
	viz[x] = 1;
	while (!q.empty()) {
		x = q.front();
		//cout<<x<<" ";
		for (auto next : G[x]) {
			if (!viz[next]) {
				q.push(next);
				viz[next] = 1;
				d[next] = d[x] + 1;
			}
			
		}
	}
}
int main()
{
	int n, m, v;
	in >> n >> m >> v;

    for (int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        G[x].push_back(y);
        //G[y].push_back(x); // doar daca e neorientat
    }
	BFS(v);

//    DFS(v);
//    int cc = 0;
//
//    /*for (int i = 1; i <= n; i++)
//    {
//        if (!vis[i])
//        {
//            cc++;
//            DFS(i);
//        }
//    }*/
//    //out << cc;
	for (int i = 1; i <= n; i++)
	{
		if (i != v && d[i] == 0)
			out << "-1";
		else
			out << d[i];
	}
    return 0;
}