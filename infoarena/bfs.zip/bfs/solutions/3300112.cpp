#include <bits/stdc++.h>

using namespace std;

int f[100005];

set <int> s[100055];

void dfs(int kk)
{
    for(auto a:s[kk])
    {
        if(f[a]==0)
        {
            f[a]=f[kk]+1;
            dfs(a);
        }
        else if(f[kk]+1<f[a])
        {
            f[a]=f[kk]+1;
            dfs(a);
        }
    }
}

int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    int n,m,x,y,k;
    cin>>n>>m>>k;
    for(int i=1;i<=m;++i)
    {
        cin>>x>>y;
        s[x].insert(y);
    }
    f[k]=1;
    dfs(k);
    for(int i=1;i<=n;++i)
    {
        cout<<f[i]-1<<" ";
    }
    return 0;
}
