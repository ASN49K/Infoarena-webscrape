#include <bits/stdc++.h>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

int n,m,s,x,y,viz[100200];
vector <int> edges[100200];
queue <int> q;

void bfs(int x)
{
    for(int i=1; i<=n; i++)
        viz[i]=-1;
    viz[x]=0, q.push(x);
    while(!q.empty())
    {
        x=q.front();
        q.pop();
        for(auto y:edges[x])
            if(viz[y]==-1)
                viz[y]=viz[x]+1, q.push(y);
    }
}

int32_t main()
{
    f>>n>>m>>s;
    for(int i=1; i<=m; i++)
        f>>x>>y, edges[x].push_back(y);
    bfs(s);
    for(int i=1; i<=n; i++)
        g<<viz[i]<<' ';
    return 0;
}
