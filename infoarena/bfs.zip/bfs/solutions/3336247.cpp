#include <iostream>
#include <mutex>
#include <queue>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

void MatriceDeAdiacenta() {
    vector<vector<int> > matrice;
    int n, m;
    cin >> n >> m;
    matrice.resize(n + 1, vector<int>(n + 1, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        matrice[u][v] = matrice[v][u] = 1;
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++)
            cout << matrice[i][j] << ' ';
        cout << '\n';
    }
}

void ListaDeAdiacenta() {
    vector<vector<int> > lista_muchii;
    int n, u, v;

    cin >> n;
    lista_muchii.resize(n + 1);

    while (cin >> u >> v) {
        lista_muchii[u].push_back(v);
        lista_muchii[v].push_back(u);
    }

    for (int i = 1; i <= n; i++) {
        cout << "Vecinii nodului " << i << ": ";
        for (auto vecin : lista_muchii[i])
            cout << vecin << ' ';
        cout << '\n';
    }
}

void BFS_NEORIENTAT(int s) {
    vector<vector<int>> lista_noduri;
    int n, m, u, v;
    cin >> n >> m ;
    lista_noduri.resize(n+1);

    for (int i=1; i<= m; i++){
        cin >> u >> v;
        lista_noduri[u].push_back(v);
        lista_noduri[v].push_back(u);
    }

    vector<int> viz(n+1, 0), tata(n+1, 0), d(n+1, 2e9);
    priority_queue<int> q;

    q.push(s);
    viz[s] = 1;
    d[s] = 0;

    while (!q.empty()) {
        int nod = q.top();
        q.pop();
        for (auto vec:lista_noduri[nod]) {
            if (!viz[vec]) {
                q.push(vec);
                tata[vec] = nod;
                viz[vec] = 1;
                d[vec] = d[nod] + 1;
            }
        }
    }
}


void bfs_infoarena() {
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");

    int n,m,s;
    cin>>n>>m>>s;
    vector<vector<int>> lista_adiacenta(n+1);
    vector<int> viz(n+1), tata(n+1), d(n+1, -1);
    queue<int> coada;

    for (int i = 1; i<=m; i++) {
        int u, v;
        cin >> u >> v;
        lista_adiacenta[u].push_back(v);
    }

    viz[s] = 1;
    d[s] = 0;
    coada.push(s);
    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        for (auto vec:lista_adiacenta[nod]) {
            if (!viz[vec]) {
                coada.push(vec);
                viz[vec] = 1;
                tata[vec] = nod;
                d[vec] = d[nod] + 1;
            }
        }
    }

    for (int i = 1; i<=n; i++) {
        cout << d[i]<<' ';
    }
}

int main() {

    bfs_infoarena();
}
