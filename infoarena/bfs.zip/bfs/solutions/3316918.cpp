#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

priority_queue<pair<int, int>> pq;
queue<int> q;
vector <int> L[100005];
int d[100005];
int n, m, x, y;

void BFS(int s) {
    for (int i = 1; i <= n; i++) {
        d[i] = -10;
    }
    d[1] = 0;
    q.push(s);
    while (q.size() > 0) {
        int nod = q.front();
        q.pop();

        for (int vecin : L[nod]) {
            if (d[vecin] == -10)
            {
                d[vecin] = d[nod] + 1;
                q.push(vecin);
            }
        }
    }
}

int main() {
    int s;
    fin >> n >> m >> s;
    int i = 0;
    while(i < n){
        fin >> x >> y;
        L[x].push_back(y);
        i++;
        //L[y].push_back(x);
     }
    BFS(s);
    for (int i = 1; i <= n; i++)
        fout << d[i] << " ";

    return 0;
}