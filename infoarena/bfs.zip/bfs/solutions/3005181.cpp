#define INF 2e9
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

const int N = 1e5;

int n, m, s, d[N+1];
vector <int> a[N+1];

void BFS(int x0)
{
    queue <int> q;
    for(int i = 1; i <= n; i++)
        d[i] = INF;
    d[x0] = 0;
    q.push(x0);
    while(!q.empty())
    {
        int x = q.front();
        q.pop();
        for(auto y : a[x])
        {
            if(d[y] == INF)
            {
                d[y] = 1 + d[x];
                q.push(y);
            }
        }
    }
}

int main()
{
    cin >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        int x, y;
        a[x].push_back(y);
    }
    BFS(s);
    for(int i = 1; i <= n; i++)
        cout << d[i] << " ";
    in.close();
    out.close();
    return 0;
}
