#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5 + 5;
int n, m, x, dist[NMAX];
vector <int> v[NMAX];
queue <int> q;

int main()
{
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);
    cin >> n >> m >> x;

    for(int i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        v[a].push_back(b);
    }

    for(int i = 1; i <= n; i++)
        dist[i] = -1;

    dist[x] = 0;
    q.push(x);
    while(!q.empty())
    {
        int node = q.front();   
        q.pop();

        for(auto u : v[node])
        {
            if(dist[u] == -1 && u != node)
            {
                q.push(u);
                dist[u] = dist[node] + 1;
            }
        }
    }

    for(int i = 1; i <= n; i++)
    {
        cout << dist[i] << " ";
    }
}