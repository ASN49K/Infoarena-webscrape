#include <fstream>
#include <vector>
#include <queue>
std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");
int main(){
    int n,m,s,x;
    fin>>n>>m>>s;
    std::vector<std::vector<int>>lista(n+1);
    std::vector<bool>viz(n+1);
    for(int i=0;i<m;i++){
        int u,v;
        fin>>u>>v;
        lista[u].push_back(v);
    }
    std::vector<int>d(n+1);
    // std::vector<int>tata(n+1);
    std::queue<int>q;
    viz[s]=1;
    d[s]=0;
    q.push(s);
    while(!q.empty()){
        int cap=q.front();
        q.pop();
        for(auto vecin:lista[cap]){
            if(!viz[vecin]){
                // tata[vecin]=cap;
                d[vecin]=d[cap]+1;
                viz[vecin]=true;
                q.push(vecin);
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(i!=s && d[i]==0){
            fout<<-1<<" ";
        }else{
            fout<<d[i]<<" ";
        }
    }
    return 0;
}