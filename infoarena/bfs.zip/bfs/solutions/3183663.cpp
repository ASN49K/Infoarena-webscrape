#include <iostream>
#include <fstream>
using namespace std;
int n,viz[5001],a[5001][5001];
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");
void bfs(int nod)
{
    int coada[5005],st=1,dr=0,x;
    dr++;
    coada[dr]=nod;
    viz[nod]=1;
    while(st!=dr+1)
    {
        x=coada[st];
        for(int i=1; i<=n; i++)
            if(a[x][i]==1)
            {
                if(viz[i]==0)
                {
                    dr++;
                    coada[dr]=i;
                    viz[i]=viz[x]+1;
                }
            }
        st++;
    }

}
int main()
{
    int m,nod,x,y;
    fin>>n>>m>>nod;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        a[x][y]=1;
    }
    bfs(nod);
    for(int i=1;i<=n;i++)
        fout<<viz[i]-1<<' ';
    return 0;
}
