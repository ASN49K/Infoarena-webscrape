#include <fstream>
#include <vector>
#define NMAX 100002
using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

vector<int> G[NMAX];//G[x] lista de adiacenta a lui x
int n,x,y,i,nrc,j,start,c[NMAX],m,sf,in,t;


int viz[NMAX]; //viz[x]= numarul componentei conexe din care face parte x
void citire();
void bfs(int x);

int main()
{
    citire();
    c[1]=start;
    sf=1;
    in=1;
    viz[start]=1;
    while(in<=sf)
    {
        t=c[in];
        for(i=0; i<G[t].size(); i++)
        {
            if(viz[G[t][i]]==0)
            {
                viz[G[t][i]]=viz[t]+1;
                sf++;
                c[sf]=G[t][i];
            }
        }
        in++;
    }
    for(j=1; j<=n; j++)
    {
        if(viz[j])
        cout<<viz[j]-1<<" ";
        else cout<<-1<<" ";
    }
    return 0;
}
void citire()
{
    int i;
    cin>>n>>m>>start;
    for(i=1; i<=m; i++)
    {
        cin>>x>>y;
        //y intra in lista de adiacenta a lui x
        G[x].push_back(y);
    }
}

