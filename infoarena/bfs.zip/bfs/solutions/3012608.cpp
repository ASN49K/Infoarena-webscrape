#include <fstream>
#include <vector>
#include <iostream>
#include <queue>

using namespace std;

int n,m,start;

const int grafSize = 100005;

vector<int> graf[grafSize];
vector<int> distanta(grafSize, -1);
queue<int> coada;

int bfs () {
    int node, vecin;
    while(!coada.empty()) {
        node = coada.front();
        coada.pop();
        for(unsigned int i = 0; i < graf[node].size(); i++) {
            vecin = graf[node][i];
            if(distanta[vecin] == -1) {
                coada.push(vecin);
                distanta[vecin] = distanta[node] + 1;
            }
        }
    }
}

void read() {
    ifstream in("bfs.in");
    in >> n >> m >> start;
    for(int i = 1; i <= m; i++) {
        int x,y;
        in >> x >> y;
        graf[x].push_back(y);
    }
    distanta[start] = 0;
}

int main() {
    read();
    ofstream out("bfs.out");
    coada.push(start);
    bfs();
    for(int i = 1; i <= n; i++)
        out << distanta[i] << " ";
    return 0;
}