#include <bits/stdc++.h>
#define N 104

using namespace std;

ifstream fin("BFS.in");
ofstream fout("BFS.out");

int n, m;
int A[N][N];
int X;
bool viz[N];
int Q[N], prim, ultim;

void Citire()
{
    int i;
    int x, y;
    fin >> n >> m;
    fin >> X;
    for(  i=1; i<=m; i++ )
    {
        fin >> x >> y;
        A[x][y] = A[y][x] = 1;
    }
}

void BFS( int x )
{
    int i;
    int nod;
    fout << x << " ";
    viz[x] = 1;
    Q[1] = x;
    prim = ultim = 1;
    while( prim <= ultim )
    {
        nod = Q[prim];
        prim++;
        for( i=1; i<=n; i++ )
            if( A[nod][i] && !viz[i] )
            {
                fout << i << " ";
                viz[i] = 1;
                Q[++ultim] = i;
            }
    }
}

int main()
{
    Citire();
    BFS(X);
    return 0;
}