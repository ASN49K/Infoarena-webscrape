#include <iostream>
#include <bits/stdc++.h>
#include <vector>

using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

int main()
{
    int a[100001][100001];
    int n,m,start;
    fin>>n>>m>>start;
    for(int i=1;i<=m;i++){
        int x,y;
        fin>>x>>y;
        a[x][y]=1;
    }
    
    int distance[100001]={-1};
    distance[start]=0;
    
    int st=1,dr=1;
    int vizite[100001]={0},orase[100001];
    vizite[start]=1;
    orase[dr]=start;
    while(st<=dr){
        int city=orase[st];
        for(int i=1;i<=n;i++){
            if (vizite[i]==0 && a[city][i]==1){
                vizite[i]=1;
                dr++;
                orase[dr]=i;
                
                distance[i]=distance[city]+1;
            }
        }
        st++;
    }
    
    for (int i=1;i<=n;i++){
        if (vizite[i]==0){
            fout << "-1 ";
        }else{
            fout << distance[i] << " ";
        }
    }

    return 0;
    
}
