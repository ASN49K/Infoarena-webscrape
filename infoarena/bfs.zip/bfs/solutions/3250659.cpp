#include <bits/stdc++.h>
#include <fstream>

using namespace std;

ifstream f ("bfs.in");
ofstream g ("bfs.out");

vector<vector<int>> graph;
vector<int> dist;

int main()
{
    int n, m, s, l ,r;
    f >> n >> m >> s;
    graph.resize(n + 1);
    vector<int> dist(n + 1, -1);
    for (int i = 0; i < m; i++) {
        f >> l >> r;
        graph[l].push_back(r);
    }
    int cnt = 0;
    dist[s] = 0;
    deque<int> bfs = { s };
    while (!bfs.empty()) {
        int aux = bfs.size();
        cnt++;
        for (int i = 0; i < aux; i++) {
            int curr = bfs.front();
            bfs.pop_front();
            for (int node : graph[curr]) {
                if (dist[node] == -1) {
                    dist[node] = cnt;
                    bfs.push_back(node);
                }
            }
        }
    }
    for (int i = 1; i <= n; i++)
        g << dist[i] << " ";
    return 0;
}