#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
// vector <int> - un tip de date

vector <int> graph[100005]; // graph[i] - vector <int>
// int graph[100005]; // graph[i] - int
// graph[1] - este un vector <int> si va contine toti vecinii lui 1 - initia este gol

int distances[100005];
const int INF = 1e9;

void bfs(int source, int n) {
    queue<int> q;

    for (int i = 1; i <= n; i++) {
        distances[i] = INF;
    }

    distances[source] = 0;
    q.push(source);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (auto x : graph[node]) {
            if (distances[x] <= distances[node] + 1) continue;
            distances[x] = distances[node] + 1;
            q.push(x);
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (distances[i] == INF) {
            distances[i] = -1;
        }
        fout << distances[i] << " ";
    }

}

int main()
{
    int n, m, s;
    fin >> n >> m >> s;
    for (int i = 1; i <= m; ++i) {
        int x, y;
        fin >> x >> y;

        graph[x].push_back(y); // pushez nodul y in lista de vecini ai lui x
    }

    bfs(s, n);
    return 0;
}