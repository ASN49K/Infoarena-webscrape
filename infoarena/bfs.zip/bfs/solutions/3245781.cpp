#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

#define NMAX 100008

int n,i,j,m,s,a,b;

vector<int>muchii[NMAX];

int cost[NMAX];

void bfs (int startnode);

int main()
{
    fin>>n>>m>>s;
    for (i=1; i<=m; i++)
    {
        fin>>a>>b;
        muchii[a].push_back(b);
    }
    bfs(s);
    for (i=1; i<=n; i++)
    {
        fout<<cost[i]-1<<' ';
    }
    return 0;
}

void bfs (int startnode)
{
    queue<int>q;
    q.push(startnode);
    cost[startnode]=1;
    while (!q.empty())
    {
        int node=q.front();
        q.pop();
        for (auto it : muchii[node])
        {
            if (!cost[it])
            {
                cost[it]=cost[node]+1;
                q.push(it);
            }
        }
    }
}
