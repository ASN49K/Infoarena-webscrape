#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>
#include <fstream>
using namespace std;

const int NMAX = 100000; // nr maxim din restrictii

vector<int> adj[NMAX + 1]; // lista de adiacenta

int N;
int M;
int S;

vector<int> dist;


void readInput() {
    ifstream f("bfs.in");
    f >> N >> M >> S;
    for (int i = 1; i <= M; i++) {
        int u, v;
        f >> u >> v;
        adj[u].push_back(v); // orientat
        // adj[v].push_back(u); // neorientat
    }
    f.close();
    // alte inputuri din porblema
}

// alte functii pentru rezolvarea problemei

void bfs(int start) {
    vector<bool> visited(N + 1, false);
    vector<int> tata(N + 1, 0);
    dist = vector(N + 1, -1);

    queue<int> q;

    q.push(start);
    visited[start] = true;
    dist[start] = 0;

    while (q.size() > 0) {
        int nod = q.front();
        q.pop();

        for (auto j : adj[nod]) {
            if (visited[j] == false) {
                q.push(j);

                visited[j] = true;
                tata[j] = nod;
                dist[j] = dist[nod] + 1;
            }
        }

    }
}

void output() {
    // afisare rezultate
    ofstream g("bfs.out");
    for (int i = 1; i <= N; i++) {
        g << dist[i] << " ";
    }
    g.close();
}

int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    readInput();
    bfs(S);
    output();
    return 0;
}
