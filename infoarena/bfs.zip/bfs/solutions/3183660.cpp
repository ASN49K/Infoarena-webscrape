#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n,m,k;
int viz[100005];
int dist[100005];
vector<int>v[200001];


void bfs(int x)
{
    queue<int>q;
    viz[x]=1;
    q.push(x);
    while(!q.empty())
    {
        int k;
        k=q.front();
        for(int i=0;i<v[k].size();i++)
            if(!viz[v[k][i]])
            {
                viz[v[k][i]]=1;
                q.push(v[k][i]);
                dist[v[k][i]]=dist[k]+1;
            }
        q.pop();
    }
}



int main()
{
    fin>>n>>m>>k;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        
    }
    
    bfs(k);
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
            dist[i]=-1;
    for(int i=1;i<=n;i++)
        fout<<dist[i]<<" ";
    
}
