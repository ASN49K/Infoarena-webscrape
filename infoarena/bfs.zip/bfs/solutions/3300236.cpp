#include <iostream>
#include<fstream>
#include<queue>
#include<vector>
using namespace std;ifstream fin("bfs.in");ofstream fout("bfs.out");vector<int>v[100001];
int n,m,start,x,y,dist[100001],i;
void bfs(int nr){int k;
    queue<int>q;q.push(nr);
    while(!q.empty()){
        k=q.front();q.pop();
        for(int j=0;j<v[k].size();j++){
            if(!dist[v[k][j]]){dist[v[k][j]]=dist[k]+1;q.push(v[k][j]);}
        }
    }
}
int main()
{
    fin>>n>>m>>start;for(i=1;i<=m;i++){fin>>x>>y;v[x].push_back(y);}dist[start]=1;bfs(start);
    for(i=1;i<=n;i++)fout<<dist[i]-1<<' ';
    return 0;
}
