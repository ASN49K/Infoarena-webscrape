#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;

ifstream f1("bfs.in");
ofstream f2("bfs.out");

void bfs(vector<vector<int>> &matrix, int s)
{
    queue<int> q;
    vector<bool> visited(matrix.size(), false);
    vector<int> distance(matrix.size(),-1);
    visited[s] = true;
    q.push(s);
    distance[s] = 0;

    while(!q.empty())
    {
        int curent = q.front();
        q.pop();
        for(int x : matrix[curent])
        {
            if(!visited[x])
            {
                visited[x] = true;
                distance[x] = distance[curent] + 1;
                q.push(x);
            }
        }
    }

    for(int i = 1; i<distance.size(); i++)
    {
        f2 << distance[i] << " ";
    }
}

void adaugare_muchie(vector<vector<int>> &matrix, int p1, int p2)
{
    matrix[p1].push_back(p2);
}

void afisare(vector<vector<int>> &matrix, int n)
{
    for(int i=1; i<=n; i++)
    {
        cout << "Nodul: " << i << " ";
        for(int j=0; j<matrix[i].size(); j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int n,m,s;
    f1 >> n >> m >> s;
    vector<vector<int>> matrix(n+1);
    for(int i=1; i<=m; i++)
    {
        int p1, p2;
        f1 >> p1 >> p2;
        adaugare_muchie(matrix,p1,p2);
    }
    bfs(matrix,s);
    return 0;
}
