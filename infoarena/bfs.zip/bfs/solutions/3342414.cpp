#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
vector <int> conex[100005];
vector <int> dist;
queue<int> q;
int n,m,s,a,b;
void bfs(int org){
    for(int i =0; i<=n;i++) dist.push_back(-1);
    q.push(org);
    dist[org] = 0;
    while(!q.empty()){
        int nod = q.front();
        q.pop();
        for(int i = 0; i < conex[nod].size(); i++){
            if(dist[conex[nod][i]] == -1){
                q.push(conex[nod][i]);
                dist[conex[nod][i]] = dist[nod] + 1;

            }
        }
    }
}

int main() {

    cin >> n >> m >>s;
    for(int i = 1; i <= m; i++){
        cin >> a >> b;
        conex[a].push_back(b);
    }
    bfs(s);
    for(int i =1;i <=n;i++){
        cout << dist[i] <<" ";
    }
    return 0;
}