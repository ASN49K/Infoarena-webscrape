#include <bits/stdc++.h>

using namespace std;

#define Nmax 100005

vector<int> adj[Nmax];
queue<int> q;
bool used[Nmax];
int dist[Nmax];

int main()
{
    int n, m, s, i, u, v;
    ifstream fin ( "bfs.in" );
    ofstream fout ( "bfs.out" );

    fin >> n >> m >> s;
    q.push( s );
    dist[s] = 0;
    used[s] = true;
    for( i = 0; i < m; i ++ ) {
      fin >> u >> v;
      adj[u].push_back( v );
    }
    fin.close();

    while ( !q.empty() ) {
      u = q.front();
      for ( i = 0; i < adj[u].size(); i ++ )
        if ( !used[ adj[u][i] ] ) {
          dist[ adj[u][i] ] = dist[u] + 1;
          used[ adj[u][i] ] = true;
          q.push( adj[u][i] );
        }
      q.pop();
    }

    for ( i = 1; i <= n; i ++ ) {
      if ( i == s )
        fout << 0 << " "; else if ( dist[i] == 0 ) {
        fout << -1 << " ";
        } else {
        fout << dist[i] << " ";
        }
    }

    fout.close();

    return 0;
}
