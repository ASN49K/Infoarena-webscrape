#include <bits/stdc++.h>

using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

vector<int> adj[100005];
queue<int> q;
int n, m, s, x, y, dist[100005];

void bfs(int start) {

    q.push(start);

    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
    }
    dist[start] = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (auto it : adj[node]) {
            if (dist[it] == -1) {
                q.push(it);
                dist[it] = dist[node] + 1;
            }
        }
    }
}

int main() {
    in >> n >> m >> s;
    for (int i = 1; i <= m; i++) {
        in >> x >> y;
        adj[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i++) {
        if (dist[i] == 1e9) {
            out << -1 << " ";
        } else {
            out << dist[i] << " ";
        }
    }

    return 0;
}