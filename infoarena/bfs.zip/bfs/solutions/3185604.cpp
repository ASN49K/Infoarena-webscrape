#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin ("bfs.in");
ofstream fout("bfs.out");

const int Max = 1e5 + 1;

vector <int> graf[Max];
queue <int> q;

int d[Max], n, m, start;

void bfs (int nod)
{
    q.push(nod);
    d[nod] = 1;
    while (!q.empty())
    {
        nod = q.front();
        q.pop();
        for (int i : graf[nod])
            if (!d[i])
            {
                q.push(i);
                d[i] = d[nod] + 1;
            }
    }
}

void citire()
{
    int x, y;
    fin >> n >> m >> start;
    for (int i = 1 ; i <= m ; ++i)
    {
        fin >> x >> y;
        graf[x].push_back(y);
    }
}

void afisare()
{
    for (int i = 1 ; i <= n ; ++i)
        if (d[i])
            fout << d[i] - 1 << " ";
        else
            fout << -1 << " ";
}

int main()
{
    citire();
    bfs(start);
    afisare();

    fin.close();
    fout.close();
    return 0;
}