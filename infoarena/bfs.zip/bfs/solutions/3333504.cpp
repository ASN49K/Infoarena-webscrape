#include <bits/stdc++.h>

using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
const int Nmax=1e5+5;
vector<int> l[Nmax];
int v[Nmax];
void bfs (int x,int n)
{
    int s=x;
    queue<int>q;
    q.push(x);
    v[x]=1;
    int k=1;
    int ok=0;
    while(!q.empty())
    {   x=q.front();
        q.pop();
        for(auto it : l[x])
            if(v[it]==0)
        {
            q.push(it);
            v[it]=k;
            ok=1;

        }
        if(ok==1)
        {

            k++;
            ok=0;
        }


    }
    for(int i=1;i<=n;i++)
        if(i==s)
            g<<0<<' ';
    else
    {   if(v[i]!=0)
            g<<v[i]<<' ';

        else g<<-1<<' ';
    }



}
int main()
{
    int n ,m,s;
    f>>n>>m>>s;
    while(m--)
    {

        int x,y;
        f>>x>>y;
        l[x].push_back(y);

    }
    bfs(s,n);
    return 0;
}
