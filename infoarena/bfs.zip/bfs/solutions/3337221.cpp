// BFS
#include <bits/stdc++.h>
#define NMAX 1e7
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");
int N, M, S;
vector<vector<int>> A;
vector<int> k; //nr de cate ori a fost vizitat
queue<int> Q;

void read() {
    fin>>N>>M>>S;
    A.resize(N+1);
    k.resize(N+1, -1);
    for (int i=1; i<=M; i++) {
        int x, y;
        fin>>x>>y;
        A[x].push_back(y);
    }
}

void bfs(int s) {
    Q.push(s);
    k[s] = 0;
    int current = s;
    while(!Q.empty()) {
        current = Q.front();
        Q.pop();
        for(int neighbor:A[current]) {
            if(k[neighbor] == -1) {
                Q.push(neighbor);
                k[neighbor] = k[current] + 1;
            }
        }
    }
    
}

int main() {

    read();
    bfs(S);
    for(int i=1;i<=N;i++) {
        fout<<k[i]<<' ';
    }
    return 0;

}