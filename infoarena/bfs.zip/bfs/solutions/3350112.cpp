
#include <fstream>
#include <vector>
using namespace std;

ifstream cin ("bfs.in");
ofstream cout ("bfs.out");

vector<int> g[100001];
int dist[100001];
int coada[100001];
int viz[100001];

void bfs (int x)
{
    int st = 1,dr = 1;
    coada[st] = x;
    viz[x] = 1;
    while (st <= dr)
    {
        int y = coada[st];
        for (int i = 0; i < g[y].size(); i++)
        {
            if (viz[g[y][i]] == 0)
            {
                viz[g[y][i]] = 1;
                dr++;
                coada[dr] = g[y][i];
                dist[g[y][i]] = dist[y] + 1;
            }
        }
        st++;
    }
}

int main()
{
    int n,m,pornire;
    cin >>n>>m>>pornire;
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        cin >>x>>y;
        g[x].push_back(y);
    }
    bfs(pornire);
    for (int i = 1; i <= n; i++)
    {
        if (dist[i] == 0 && i != pornire)
        {
            dist[i] = -1;
        }
        cout <<dist[i]<<" ";
    }
    return 0;
}
