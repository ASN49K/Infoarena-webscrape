#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int main(){
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);
    
    int n,m,s;
    fin>>n>>m>>s;
    vector<vector<int>> adj(n+1);
    vector<int> dist(n+1, -1);
    
    for(int i=0;i<m;i++){
        int x,y;
        fin>>x>>y;
        adj[x].push_back(y);
    }
    
    queue<int> q;
    q.push(s);
    dist[s] = 0;
    
    while(!q.empty()){
        int node = q.front();
        q.pop();
        
        for(int neighbor: adj[node]){
            if(dist[neighbor] == -1){
                dist[neighbor] = dist[node] + 1;
                q.push(neighbor);
            }
        }
    }
    
    for(int i = 1; i <= n; i++){
        fout<<dist[i];
        
    }
    
    return 0;
}
