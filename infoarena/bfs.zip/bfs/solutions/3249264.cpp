#include <iostream>
#include <queue>
#include <list>
#include <fstream>
#include <unordered_set>
using namespace std; 
ifstream in("bfs.in");
ofstream out("bfs.out");
struct nod
{
	list <int> p;
}el[100005];
void crearelista(nod el[], int n, int m,bool ordonat)
{
	int x1, x2;
	for (int i = 1; i <= m; i++)
	{
		in >> x1 >> x2;
		el[x1].p.push_back(x2);
		if (ordonat == 0)
			el[x2].p.push_back(x1);
	}
}
void afisarelista(nod el[], int n)
{
	for (int i = 1; i <= n; i++)
	{
		out << "Nodul " << i << " duce la urmatoarele noduri:" << '\n';
		for (auto p = el[i].p.begin(); p != el[i].p.end(); p++)
			out << *p << ' ';
		out << '\n';
	}
}
void clear(queue <int>& q1)
{
	std::queue<int> emp;
	swap(q1, emp);


};
bool alreadyvisited(int el, list<int> m)
{
	for (auto t = m.begin(); t != m.end(); t++)
		if (*t == el)
			return 1;
	return 0;
}
int BFS(nod el[],int final, int pas, queue <int> q1,int n)
{
	queue <int> q2;
	bool frecventa[100005] = { 0 };
	bool ok = 1;
	while(ok)
	{ 
	while (!q1.empty())
	{
		auto i = q1.front();
		q1.pop();
		
		if (i == final)
			return pas;
		if(frecventa[i]==0)
		for (auto t = el[i].p.begin(); t != el[i].p.end(); t++)
			q2.push(*t);
	frecventa[i] = 1;
	}	
	ok = 0;
	if (!q2.empty())
	{
			pas += 1;
			swap(q1, q2);
			ok = 1;
	}
 }
	return -1;

}
	





int main()
{
	int n, m, s;
	in >> n >> m >> s;
	crearelista(el, n, m, 1);
	//afisarelista(el, n);
	unordered_set <int> p;
	queue <int> q1;
	for (int i = 1; i <= n; i++)
	{
		q1.push(s);
		out << BFS(el, i, 0, q1,n)<<' ';
		clear(q1);
		//p.clear();
	}


}