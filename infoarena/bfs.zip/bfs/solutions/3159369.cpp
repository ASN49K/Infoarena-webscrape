#include <bits/stdc++.h>
#define N 100005
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,b,i,j,x,y,c,k,f[N],d[N];
set<int> s[N];
queue<int> q;
int main()
{
    fin>>n>>m>>b;
    while(m--)
    {
        fin>>x>>y;
        s[x].insert(y);
    }
    for(i=1;i<=n;++i)
    {
        d[i]=-1;
    }
    q.push(b); f[b]=1; d[b]=0;
    while(!q.empty())
    {
        x=q.front();
        q.pop();
        set<int>::iterator it;
        for(it=s[x].begin();it!=s[x].end();++it)
        {
            k=*it;
            if(f[k]) continue;
            f[k]=1;
            d[k]=d[x]+1;
            q.push(k);
        }
    }
    for(i=1;i<=n;++i)
    {
        fout<<d[i]<<' ';
    }
    return 0;
}
