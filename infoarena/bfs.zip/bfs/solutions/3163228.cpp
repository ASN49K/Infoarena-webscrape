#include<fstream>
#include<iostream>
#include<vector>
#include<queue>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NMAX = 100000;
vector<int>G[NMAX+1];
bool vis[NMAX+1];
int dist[NMAX+1];

void bfs(int x){
    dist[x]=0;
    queue<int>q;
    q.push(x);
    while(!q.empty()){
        x=q.front();
        vis[x]=1;
        q.pop();
        for(auto next: G[x]){
            if(!vis[next])
                {
                    q.push(next);
                    dist[next]=dist[x]+1;
                    vis[next]=1;
                }
        }
    }
}
int main()
{
    int N,M,x,y;
    int S;
    f>>N>>M>>S;
    while(M--){
        f>>x>>y;
        G[x].push_back(y);
    }
    bfs(S);
    for(int i=1; i<=N; i++){
       if(i==S)
       g<<0<<" ";
       else
       {
        if(dist[i]==0)
           g<<-1<<" ";
        else
            g<<dist[i]<<" ";
       }
    }
    
    return 0;
}
