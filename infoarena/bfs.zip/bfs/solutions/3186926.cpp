#include <bits/stdc++.h>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, S;
queue<int> q;
int d[100005];
vector<int> L[100005];

void BFS(int k)
{
    for (int i = 1; i <= n; i++)
        d[i] = 2e9;
    d[k] = 0;
    q.push(k);
    while (!q.empty())
    {
        k = q.front();
        q.pop();
        for (int i : L[k])
            if (d[i] > d[k] + 1)
            {
                d[i] = d[k] + 1;
                q.push(i);
            }
    }
}

int main()
{
    int i, j;
    fin >> n >> m >> S;
    while (m--)
    {
        fin >> i >> j;
        L[i].push_back(j);
    }

    BFS(S);
    for (i = 1; i <= n; i++)
        if (d[i] == 2e9)
            fout << -1 << " ";
        else 
            fout << d[i] << " ";
    return 0;
}