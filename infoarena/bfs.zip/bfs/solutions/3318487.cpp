#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <fstream>
using namespace std;
queue<int> q;
vector<int> D;
vector<vector<int>> L;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

void bfs(int nod) {
    q.push(nod);
    while (!q.empty()) {
        int curr = q.front();
        q.pop();
        for (int vecin : L[curr]) {
            if (D[vecin] == -1) {
                D[vecin] = D[curr] + 1;
                q.push(vecin);
            }
        }
    }
}

int main () {
    int n, m, s;
    cin >> n >> m >> s;
    L.resize(n + 1);
    D.resize(n + 1, -1);
    int x, y;
    for (int i = 0; i < m; i++) {
        cin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    D[s] = 0;
    bfs(s);
    for (int i = 1; i <= n; i++) {
        cout << D[i] << " ";
    }
    return 0;
}