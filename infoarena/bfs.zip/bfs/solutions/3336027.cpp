#include <fstream>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");

vector<vector<int>> la;
queue<int> q;
vector<bool> visited;
vector<int> niv;

void bfs(int s, int n) {

    visited[s] = true;
    niv[s] = 0;
    q.push(s); 
    while(!q.empty()) {
        int curr = q.front();
        q.pop();
        for(int neighbour : la[curr]) {
            if(!visited[neighbour]) {
                q.push(neighbour);
                visited[neighbour] = true;
                niv[neighbour] = niv[curr] + 1;
            }
        }
    }

}

int main() {
    int n, m, s, x, y;
    cin >> n >> m >> s;
    la.assign(n + 1, {});
    visited.assign(n + 1, 0);
    niv.assign(n + 1, -1);

    for(int i = 1; i <= m; i++) {
        cin >> x >> y;
        la[x].push_back(y);
    }

    bfs(s, n);

    for(int i = 1; i <= n; i++)
        cout << niv[i] << ' ';
    return 0;
}