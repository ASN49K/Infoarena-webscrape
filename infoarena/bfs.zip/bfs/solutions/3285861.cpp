#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m, d[100005], s;
vector<int> G[100005];
void BFS(int x)
{
    for(int i = 1; i <= n; i++)
        d[i] = -1;
    d[x] = 0;
    queue<int> q;
    q.push(x);
    while(!q.empty())
    {
        int t = q.front();
        q.pop();
        for(auto e : G[t])
            if(d[e] == -1)
            {
                d[e] = 1 + d[t];
                q.push(e);
            }
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i,j;
    fin >> n >> m >> s;
    while(m--)
    {
        fin >> i >> j;
        G[i].push_back(j);
        ///G[j].push_back(i);
    }
    BFS(s);
    for(i = 1; i <= n; i++)
        fout << d[i] << " ";
    return 0;
}
