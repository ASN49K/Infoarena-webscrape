#include <bits/stdc++.h>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

vector<int> graph[100002];
int d[100002];

void bfs(int node,int n) {
    for (int i=1;i<=n;i++) {
        d[i]=n+1;
    }

    queue<int> q;
    q.push(node);
    d[node]=0;
    while(!q.empty()) {
        int i=q.front();
        q.pop();
        for (auto j:graph[i]) {
            if (d[j]>d[i]) {
                d[j]=d[i]+1;
                q.push(j);
            }
        }
    }
    for (int i=1;i<=n;i++) {
        if (d[i]==n+1)
            d[i]=-1;
        out<<d[i]<<" ";
    }
}

int main() {
    int n,m,s;
    in>>n>>m>>s;

    while(m--) {
        int x,y;
        in>>x>>y;
        graph[x].push_back(y);
    }

    bfs(s,n);
}