#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
using namespace std;

int N, M, source;
vector<vector<int>> graph;
vector<int> sol;
queue<int> nodesQueue;

int main() {
    freopen("bfs.in", "r", stdin);
    // freopen("bfs.out", "w", stdout);

    cin >> N >> M >> source;
    graph.assign(N + 1, vector<int>());
    int x, y;
    for (int idx = 0; idx < M; idx++) {
        cin >> x >> y;
        graph[x].push_back(y);
    }

    sol.assign(N + 1, INT_MAX);
    nodesQueue.push(source);
    sol[source] = 0;
    while (!nodesQueue.empty()) {
        int node = nodesQueue.front();
        nodesQueue.pop();
        for (auto neighbour : graph[node]) {
            if (sol[neighbour] > sol[node] + 1) {
                sol[neighbour] = sol[node] + 1;
                nodesQueue.push(neighbour);
            }
        }
    }
    for (int idx = 1; idx <= N; idx++) {
        cout << (sol[idx] == INT_MAX ? -1 : sol[idx]) << " ";
    }
    cout << "\n";
    return 0;
}