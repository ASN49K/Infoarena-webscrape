#include <fstream>
#include <queue>
#include <vector>
#define VMAX 100005
using namespace std;

ifstream fin("deque.in");
ofstream fout("deque.out");

queue<int> q;
int vizitat[VMAX];
vector<vector<int>> conex;

void bfs(int s)
{
    int i, j, x;
    q.push(s);
    vizitat[s] = 1;
    while (!q.empty())
    {
        x = q.front();
        q.pop();
        for (i = 0; i < conex[x].size(); i++)
        {
            if (vizitat[conex[x][i]] == 0)
            {
                vizitat[conex[x][i]] = vizitat[x] + 1;
                q.push(conex[x][i]);
            }
        }
    }
}

int main()
{
    long long int n, m, i, j, k, minim = 0, nr, s;
    fin >> n >> m >> s;

    // Resize conex to have n+1 elements (0 to n)
    conex.resize(n + 1);

    for (i = 0; i < m; i++)
    {
        fin >> j >> k;
        conex[j].push_back(k);
    }

    bfs(s);

    for (i = 1; i <= n; i++)
    {
        if (vizitat[i] == 0)
            fout << "-1 ";
        else if (i == s)
            fout << "0 ";
        else
            fout << vizitat[i] - 1 << ' '; // subtract 1 to get the correct distance
    }

    fout.flush();
    return 0;
}
