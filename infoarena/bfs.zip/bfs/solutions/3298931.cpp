#include <iostream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
map<int,vector<int>>netanyahu;
queue<int>lapid;
map<int,int>v;
int main()
{
    int n,m,s;
    fin>>n>>m>>s;
    int a,b;
    for(int i =1;i<=n;i++){
        v[i]=-1;
    }
    for(int i = 0;i<m;i++){
            fin>>a>>b;
            netanyahu[a].push_back(b);
            v[a]=-1;
            v[b]=-1;
    }

    lapid.push(s);
    v[s]=0;
    int q= 1;
    while(!lapid.empty()){
            int bezalel=lapid.front();
        for(int i =0;i<netanyahu[bezalel].size();i++){
            if(v[netanyahu[bezalel][i]]==-1){
                    v[netanyahu[bezalel][i]]=v[bezalel]+1;
            lapid.push(netanyahu[bezalel][i]);
                }
        }
        lapid.pop();
    }
    std::map<int,int>::iterator it=v.begin();
    while(it!=v.end()){
        fout<<it->second<<" ";
        it++;
    }



    return 0;
}
