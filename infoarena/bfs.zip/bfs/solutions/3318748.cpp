#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;

ifstream f("bfs.in");
ofstream fout("bfs.out");

int n,m,s;
int x,y;

vector<vector<int>>g;
vector<int>dist;
vector<int>viz;
queue<int>q;


void citire(){
    f >>n >>m >>s;
    dist.resize(n+1, -1);
   viz.resize(n+1, 0);


    g.resize(n+1);
    for (int i =0;i<m;i++)
    {
        f >>x>>y;
        g[x].push_back(y);
        
    }
}

void bfs(){

    citire();
    q.push(s);

    dist[s]=0;
    viz[s]=1;

    while(q.size() > 0)
    {
        int nod_curent =q.front();
        q.pop();
        for(auto v :g[nod_curent])
        {
            if(viz[v]==0)
            {
                q.push(v);
                viz[v]=1;
                dist[v]=dist[nod_curent]+1;
                
            }
        }
    }
}

void afis()
{
    for(int i=1;i<=n;i++)
    {
        fout << dist[i] << " ";
    }
}

int main()
{
    bfs();
    afis();
}