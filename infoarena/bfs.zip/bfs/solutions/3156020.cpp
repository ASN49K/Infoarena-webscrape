#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
const int nMAX=1e5;
vector<int> G[nMAX+1];
bool explorat[nMAX+1];
int cost[nMAX+1];
queue<int> q;
ifstream f("bfs.in");
ofstream g("bfs.out");
int main()
{
    int n,m,s;
    f>>n>>m>>s;
    
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
    }
    // for(int i=1;i<=n;i++)
    // {
    //     for(auto x:G[i])
    //     cout<<x<<" ";
    //     cout<<'\n';
    // }
    for(int i=1;i<=n;i++)
    {
        q.push(s);
        int cntArce=-1;
        if(s==i) 
        {   q.pop();
            cntArce++;
        }
        while(!q.empty())
        {
            int nodCurent=q.front();
            if(nodCurent==i) 
            {
                while(!q.empty())
                q.pop();
                cntArce=cost[nodCurent];
            }
            else
            {
                explorat[nodCurent]=1;
                q.pop();
                for(auto x:G[nodCurent])
                    {   
                        if(explorat[x]==0) {q.push(x); cost[x]=cost[nodCurent]+1;}
                    }
            }
        }
        g<<cntArce<<" ";
        for(int j=1;j<=n;j++) cost[j]=explorat[j]=0;
    }
}