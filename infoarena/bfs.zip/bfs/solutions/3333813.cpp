#include <fstream>
#include <vector>

using namespace std;
ifstream fin("bfs.in");
ofstream fout ("bfs.out");
/////////////////////////////////////////
const int NMAX = 100002;
int n,start;

//vector<int> A; // am declarat un vectro din STL cu 0 elemente de tip int numit A
vector<int> A[NMAX]; //am declarat un vector cu nmax elemente de tip vector din stl
int viz[NMAX];
int inc, sf;
int C[NMAX];
void bfs(int x);
////////////////////////////////
void citire();
int main()
{
    citire();
    //afisare_lad();
    bfs(start);
    for (int i=1; i<=n; i++) fout<<viz[i] - 1<<' ';
    return 0;
}

void citire()
{
    int i,m;
    int x,y;
    fin>>n>>m>>start;
    for (i=0; i<m; i++)
    {
        fin>>x>>y;
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
    }
}


void bfs(int x) //parcurge BFS graful incepand din x
{
    C[0] = x;
    inc = sf = 0;
    viz[x] = 1;
    while (inc <=sf)
    {
        x = C[inc++];
        //parcurg vecinii lui x
        for ( int i=0; i<A[x].size(); i++)
        {
            if (viz[A[x][i]] == 0)
            {
                viz[A[x][i]] = 1+viz[x];
                C[++sf] = A[x][i];
            }
        }
    }
}
