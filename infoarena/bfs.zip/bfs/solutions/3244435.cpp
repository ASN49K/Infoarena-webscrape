#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int nmax = 100005;
int n, m, s, fr[nmax];
vector<int> v[nmax];
queue<int> Q;

void Bfs(int nod)
{
    Q.push(nod); fr[nod] = 0;
    while(!Q.empty())
    {
        int nod = Q.front(); Q.pop();

        for(auto x : v[nod])
            if(fr[x] == -1)
                fr[x] = fr[nod] + 1, Q.push(x);
    }
}

int main()
{
    f >> n >> m >> s;
    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        f >> x >> y;
        v[x].push_back(y);
    }

    for(int i = 1; i <= n; i ++)
        fr[i] = -1;

    Bfs(s);

    for(int i = 1; i <= n; i ++)
        g << fr[i] << " ";
    return 0;
}
