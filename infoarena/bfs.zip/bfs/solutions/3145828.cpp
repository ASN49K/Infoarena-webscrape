#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "date.in"
#define OUTFILE "date.out"

const int VMAX = 1e5 + 2;

vector<int> adj[VMAX];
int dist[VMAX];
bool viz[VMAX];

void bfs(int sursa){

    queue<int> q;

    q.push(sursa);
    dist[sursa] = 0;

    while(!q.empty()){

        int nod = q.front();
        q.pop();

        viz[nod] = 1;
        for(auto& to : adj[nod]){

            if(!viz[to]){

                q.push(to);

                dist[to] = dist[nod] + 1;

            }

        }

    }

}

void solve(){

    int n, m, s;
    int x, y;

    cin >> n >> m >> s;

    for(int i = 1; i <= m; ++i){

        cin >> x >> y;

        adj[x].push_back(y);

    }

    for(int i = 1; i <= n; ++i){

        dist[i] = -1;

    }

    bfs(s);

    for(int i = 1; i <= n; ++i){

        cout << dist[i] << ' ';

    }

}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}