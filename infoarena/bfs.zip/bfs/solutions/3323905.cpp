#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

ifstream cin ("bfs.in");
ofstream cout ("bfs.out");

queue<int>c;

void bfs(vector<vector<int>> &adiacenta, int startNode, vector<int>&viz, queue<int>& q, vector<int> &dist){
    q.push(startNode);
    viz[startNode]=1;
    dist[startNode] = 0;  
    while(!q.empty()){
        int curr = q.front();
        q.pop();
        for(auto x : adiacenta[curr]){
            if(viz[x]==0){
                viz[x]=1;
                q.push(x);
                dist[x] = dist[curr] + 1;  
            }
        }
        
    }
}
int main(){
    int nrNoduri, nrMuchii, s,i,j;
    cin>>nrNoduri>>nrMuchii>>s;
    vector<vector<int>> adc(nrNoduri+1);
    vector<int>dist(nrNoduri+1,-1);
    vector<int> viz(nrNoduri+1, 0);
    while(nrMuchii){
        cin>>i>>j;
        adc[i].push_back(j);
        nrMuchii--;
    }
    bfs(adc,s,viz,c,dist);
    for (i =1 ; i<=nrNoduri; i++)
    cout<<dist[i]<<" ";
}