#include <fstream>
#include <vector>
#define NMAX 100001
using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");

int n,start;
vector<int> A[NMAX]; //am declarat un vector cu NMAX elemente de tip vector din stl cu 0 elemente de tip int numit A
int viz[NMAX];
int C[NMAX];
int inc,sf;

void bfs(int x);
void citire();
int main()
{
    int i;
    citire();
    bfs(start);
    for(i=1; i<=n; i++) fout<<viz[i]-1<<' ';
    return 0;
}
void citire()
{
    int i,m,x,y;
    fin>>n>>m>>start;
    for(i=0; i<m; i++)
    {
        fin>>x>>y;
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
    }
}
void bfs(int x)
{
    int i;
    C[0]=x; inc=sf=0;  //initializez coada cu varful de start
    viz[x]=1;
    while (inc<=sf)
    {
        x=C[inc++];
        //parcurg vecinii lui x
        for(i=0; i<A[x].size(); i++)
            if(viz[A[x][i]]==0)
        {
            viz[A[x][i]]=1+viz[x];
            C[++sf]=A[x][i];
        }
    }
}
