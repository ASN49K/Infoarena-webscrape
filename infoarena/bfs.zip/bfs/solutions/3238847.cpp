#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

long long n, m, x, y, a,viz[100002], d[100002];

vector<int> v[100002];

void BFS(int st)
{
    queue<int> q;
    q.push(st);
    while(!q.empty())
    {
        int j=q.front();
        viz[j]=1;
        for(auto i: v[j])
        {
            if(!viz[i])
            {
                d[i]=d[j]+1;
                q.push(i);
            }
        }
        q.pop();
    }
}

int main()
{
    cin>>n>>m>>a;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
    }
    BFS(a);
    for(int i=1;i<=n;i++)
    if(d[i]==0 && i!=a)
    cout<<-1<<" ";
    else
        cout<<d[i]<<" ";
}
