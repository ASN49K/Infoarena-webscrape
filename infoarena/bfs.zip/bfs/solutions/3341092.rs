use std::io::{BufWriter,Write};
use std::fs::{self,File};
use std::collections::VecDeque;
macro_rules! parse_line {
    ($iter: expr, $($t: ty),+) => {{
        let line = $iter.next().unwrap();
        let mut parts = line.split_whitespace();
        ($(parts.next().unwrap().parse::<$t>().unwrap()), +)
    }};
}




fn main() -> std::io::Result<()>{
    let content = fs::read_to_string("bfs.in")?;
    let mut lines = content.lines();
    let mut writer = BufWriter::new(File::create("bfs.out")?);
    let (n, m, s) = parse_line!(lines, usize, usize, usize);
    let mut adj : Vec<Vec<usize>> = vec![vec![]; n+1];
    for _ in 0..m {
        let (x, y) = parse_line!(lines, usize, usize);
        adj[x].push(y);
    }
    let mut dist: Vec<i32> = vec![-1; n+1];
    dist[s] = 0;
    let mut q = VecDeque::new();
    q.push_back(s);
    while let Some(nod) = q.pop_front() {
        for &vec in &adj[nod] {
            if dist[vec] == -1 {
                q.push_back(vec);
                dist[vec] = dist [nod] + 1;
            }
        }
    }
    for &item in dist.iter().skip(1) {
        write!(writer,"{} ",item)?;
    }
    Ok(())
}
