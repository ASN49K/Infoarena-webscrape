#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
#define cin fin
#define cout fout
int n,m,s;
int distanta[100002];
vector<int>gr[100005];
void bfs(int start){
    queue<int>q;
    q.push(start);
    distanta[start]=1;
    while(!q.empty()){
        int tata=q.front();
        q.pop();
        for(auto i:gr[tata]){
            if(distanta[i]==0){
                q.push(i);
                distanta[i]=distanta[tata]+1;
            }
        }
    }
}
int main(){
    cin>>n>>m>>s;
    for(int i=1;i<=m;i++){
        int n1,n2;
        cin>>n1>>n2;
        gr[n1].insert(n2);

    }
    bfs(s);
    for(int i=1;i<=n;i++){
        if(distanta[i]==0)cout<<-1<<' ';
    else
        cout<<distanta[i]-1<<' ';


    }




}
