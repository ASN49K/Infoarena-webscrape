//#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

int bfs(unsigned int start, unsigned int end,
                 std::vector<int> &dist, std::vector<std::vector<unsigned int>> &v) {

  if (start == end) return 0;
  std::queue <unsigned int> q;
  q.push(start);

  dist[start] = 0;
  while (!q.empty()) {
    unsigned int curr = q.front(); q.pop();

    for (unsigned int neighbour : v[curr]) {

      if (dist[neighbour] == -1) {
        dist[neighbour] = dist[curr] + 1; // vector de costuri
        if(neighbour == end) return dist[neighbour]; // opreste daca nodul actual e end
        q.push(neighbour);
      }
    }
  }

  return -1;
} // pt tipul unsigned, se va produce underflow

int main(void) {

  std::ios::sync_with_stdio(false);

  unsigned long m;
  unsigned int n, s;

  std::ifstream in("bfs.in");
  std::ofstream out("bfs.out");

  //in.tie(nullptr);
  //out.tie(nullptr);

  //std::cin >> n >> m >> s;

  in >> n >> m >> s;
  std::vector<std::vector<unsigned int>> l(n + 1, std::vector<unsigned int> ());

  for (size_t i = 0; i < m; i++) {
    unsigned int x, y;
    //std::cin >> x >> y;
    in >> x >> y;
    l[x].push_back(y);
  } // lista de succesori

  for (size_t i = 1; i <= n; i++) {
    std::vector<int> viz(n + 1, -1);
    //std::cout << bfs(s, i, viz, l) << " ";
    out << bfs(s, i, viz, l) << " ";
  }

  in.close();
  out.close();
  return 0;
}
