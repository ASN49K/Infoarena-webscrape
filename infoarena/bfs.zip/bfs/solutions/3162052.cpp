#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int nmax = 100003;
int n, m, start;
int nrPasi[nmax];
vector <int> g[nmax];
queue <int> q;

void read(void);
void bfs(int start);

int main(){
    int i;

    read();
    
    bfs(start);

    for(i = 1; i <= n; i++)
        if(nrPasi[i] == 0 && i != start)
            fout<<"-1"<<" ";
        else fout<<nrPasi[i]<<" ";
    }

void read(void){
    int i, j;
    
    fin>>n>>m>>start;

    while(m--){
        fin>>i>>j;
        g[i].push_back(j);
        }
    }

void bfs(int start){
    int nod, vecin, i;

    q.push(start);

    while(!q.empty()){
        nod = q.front();
        q.pop();

        for(i = 0; i < g[nod].size(); i++){
            vecin = g[nod][i];

            if(!nrPasi[vecin] && (vecin != start)){
                nrPasi[vecin] = nrPasi[nod] + 1;
                q.push(vecin);
                }
            }
        }
    }