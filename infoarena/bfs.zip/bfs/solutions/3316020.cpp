#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("BFS.in");
ofstream fout("BFS.out");

int main(){
    int N, M, S;
    fin >> N >> M >> S;
    vector<vector<int>> adiac(N + 1);
    for(int i = 0; i < M; i++)
    {
        int x, y;
        fin >> x >> y;
        adiac[x].push_back(y);
    }
    
    vector<int> d(N + 1, -1);
    deque<int> q;

    for(d[S] = 0, q.push_back(S); !q.empty();)
    {
        int vf = q.front();
        q.pop_front();
        for(int vecin : adiac[vf])
            if(d[vecin] == -1)
            {
                d[vecin] = d[vf] + 1;
                q.push_back(vecin);
            }
    }
    for(int i = 1; i <= N; i++)
        fout << d[i] << ' ';
    return 0;
}
