//ALEXANDRU MICLEA

// #include <vector>
// #include <algorithm>
// #include <string>
// #include <cstring>
// #include <queue>
// #include <map>
// #include <set>
// #include <unordered_set>
// #include <unordered_map>
// #include <time.h>
// #include <iomanip>
// #include <deque>
// #include <math.h>
// #include <cmath>
// #include <assert.h>
// #include <stack>
// #include <bitset>
// #include <random>
// #include <chrono>
// #include <iostream>
// #include <fstream>
// #include <array>
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

//VARIABLES

int n, m, S;
vector <int> v[100005];
int visited[100005];
int res[100005];
queue <int> q;

//FUNCTIONS

void bfs(int nod) {
    visited[nod] = 1;
    q.push(nod);
    res[nod] = 0;

    while (!q.empty()){
        int nodc = q.front();
        q.pop();
        for (auto& x : v[nodc]){
            if (!visited[x]){
                visited[x] = 1;
                res[x] = res[nodc] + 1;
                q.push(x);
            }
        }
    }

}

//MAIN
int main() {

#ifdef INFOARENA
    ifstream fin("bfs.in"); ofstream fout("bfs.out");
    cin.rdbuf(fin.rdbuf()); cout.rdbuf(fout.rdbuf());
#endif

    //cout << "Hello world!\n";

    cin >> n >> m >> S;
    while (m--) {
        int a,b;
        cin >> a >> b;
        v[a].push_back(b);
    }

    for (int i = 1; i <= n; i++){
        res[i] = -1;
    }

    bfs(S);

    for (int i = 1; i <= n; i++){
        cout << res[i] << ' ';
    }

    return 0;
}