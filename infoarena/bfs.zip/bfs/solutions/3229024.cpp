#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int nmax = 1e5+10;
int n,m,k;
vector<vector<int>> mat(nmax);
vector<int> visited(nmax),distante(nmax);
queue<int> q;
void read_input(){
   fin >> n >> m >> k;
   int nod_1,nod_2;
   for(int i = 1; i <=m; i++){
	 fin >> nod_1 >> nod_2;
	 mat[nod_1].push_back(nod_2);
   }
};
void bfs(int nod){
	distante[nod] = 0;
	visited[nod] = 1;
	q.push(nod);
	while(!q.empty()){
		int nod_aux = q.front();
		for(auto i : mat[nod_aux]){
			if(!visited[i]){
				visited[i] = 1;
				distante[i] = distante[nod_aux]+1;
				q.push(i);
			}
		};
		q.pop();
	}
};
void solve(){
	bfs(k);
	for(int i = 1; i <=n; i++){
	    if(i != k && distante[i] == 0){fout << -1 << " ";}else{
		fout << distante[i] << " ";}
	};
}
int main(){
	read_input();
	solve();
	return 0;
}

