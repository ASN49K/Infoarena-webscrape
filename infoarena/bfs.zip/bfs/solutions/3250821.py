import numpy as np
import matplotlib.pyplot as plt


# 1
# def getProb(a, b, c, d):
#     count = 0
#     cazuri = 100000
#     x = np.random.uniform(a, b, size=cazuri)
#     count = np.sum((x >= c) & (x <= d))
#     return count/cazuri

# print(getProb(0, 7, 3, 5))
# print(getProb(0, 7, 1, 2))
# print(getProb(0, 7, 1, 6))

# 2
import numpy as np
import matplotlib.pyplot as plt

# def getProb(a, b, c, d, a1, b1, c1, d1):
#     # Create a plot
#     plt.figure()

#     # Set x and y axis limits
#     plt.xlim(a, b)
#     plt.ylim(c, d)

#     # Draw x and y axes
#     plt.axhline(0, color='black', linewidth=1)  # x-axis
#     plt.axvline(0, color='black', linewidth=1)  # y-axis

#     plt.grid(True)

#     cazuri = 1000
#     x = np.random.uniform(a, b, size=cazuri)
#     y = np.random.uniform(c, d, size=cazuri)
    
#     in_region = (x >= a1) & (x <= b1) & (y >= c1) & (y <= d1)
    
#     plt.plot(x, y, 'C0.', label='Outside region')

#     plt.plot(x[in_region], y[in_region], 'C1.', color='red', label='Inside region')
#     plt.legend()
#     plt.show()

#     return np.sum(in_region) / cazuri

# print(getProb(0, 10, 3, 5, 2, 8, 3.5, 4.5))


# 3
import numpy as np

def getArie(r, d):
    cazuri = 5000
    
    x = np.random.uniform(-r, r, size=(cazuri, d))
    
    distances = np.linalg.norm(x, axis=1)
    count = np.sum(distances <= r)
    volume_of_cube = (2 * r) ** d
    estimated_area_or_volume = (count / cazuri) * volume_of_cube
    return estimated_area_or_volume

# Example usage
print(getArie(1, 2))  # Estimate area for a 2D circle of radius 1
