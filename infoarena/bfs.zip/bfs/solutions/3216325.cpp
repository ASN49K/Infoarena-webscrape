#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n,m,s;
vector<int> L[100005];
int dist[100005];
queue<int> q;
void bfs()
{
    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        for(auto vec:L[node])
        {
            if(dist[node]+1<dist[vec])
            {
                dist[vec]=dist[node]+1;
                q.push(vec);
            }
        }
    }
}

int main()
{
    fin>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        L[x].push_back(y);
    }
    q.push(s);
    for(int i=1;i<=n;i++)
    {
        dist[i]=INT_MAX;
    }
    dist[s]=0;
    bfs();
    for(int i=1;i<=n;i++)
    {
        fout<<dist[i]<<" ";
    }
    return 0;
}
