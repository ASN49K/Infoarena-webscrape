#include <fstream>
#include <vector>
#include <bitset>

std::ifstream fin("graf.in");
std::ofstream fout("graf.out");

const int nMax = 7500;

std::vector<std::vector<int>> graf;

std::bitset<nMax> viz;

int main() {
    int n, m, x, y;

    fin >> n >> m;

    graf.assign(n, std::vector<int>());
    
    for(int i = 0; i < m; ++i) {
	int n1, n2;
	fin >> n1 >> n2;
	n1 -= 1, n2 -= 1;
	graf[n1].push_back(n2);
	graf[n2].push_back(n1);
    }

    return 0;
}
