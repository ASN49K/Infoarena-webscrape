#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, node1, node2, vis[100005], cnt, s;
vector<vector<int>> graf;

void ct()
{
    fin >> n >> m >> s;
    graf.resize(n + 1);
    for(int i = 1; i <= m; i++)
    {
        fin >> node1 >> node2;
        graf[node1].push_back(node2);
    }
    for(int i = 1; i <= n; i++)
        vis[i] = -1;
    vis[s] = 0;
}

void afis()
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 0; j < graf[i].size(); j++)
            fout << graf[i][j] << ' ';
        fout << endl;
    }
}

void dfs(int nodestart)
{
    int node;
    stack<int> st;
    st.push(nodestart);
    while(!st.empty())
    {
        node = st.top();
        //fout << node << ' ';
        st.pop();
        for(int i = 0; i < graf[node].size(); i++)
        {
            if(!vis[graf[node][i]])
            {
                vis[graf[node][i]] = 1;
                st.push(graf[node][i]);
            }
        }
    }
}

void bfs(int nodestart)
{
    stack<int> q;
    q.push(nodestart);
    int node;
    while(!q.empty())
    {
        node = q.top();
        q.pop();

        for(int i = 0; i < graf[node].size(); i++)
        {
            if(vis[graf[node][i]] == -1 || vis[graf[node][i]] > vis[node] + 1)
            {
                q.push(graf[node][i]);
                vis[graf[node][i]] = vis[node] + 1;
            }
        }
    }
}

int main()
{
    ct();
    //afis();
    bfs(s);
    for(int i = 1; i <= n; i++)
        fout << vis[i] << ' ';

    return 0;
}
