#include "bits/stdc++.h"
#define NMAX 100010

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s, x, y;
int c[NMAX], d[NMAX];
vector <int> L[NMAX];

void bfs(int s) {
    int nod, p = 1, u = 1;
    c[1] = s, d[s] = 1;

    while (p <= u) {
        nod = c[p];
        for (int i = 0; i < L[nod].size(); i++) {
            int vecin = L[nod][i];
            if (d[vecin] == 0) {
                u++;
                c[u] = vecin;
                d[vecin] = 1 + d[nod];
            }
        } 
        p++;
    }
}

int main() {
    fin >> n >> m >> s;

    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        L[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i++) {
        fout << d[i] - 1<< ' ';
    }
    return 0;
}