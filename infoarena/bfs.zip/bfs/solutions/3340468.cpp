#include <bits/stdc++.h>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

const int N_MAX = 1000005;

int n, m, s, x, y, v[N_MAX];
vector<int> g[N_MAX];

void bfs(int nod) {
    queue<int> q;
    q.push(nod);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (auto fiu : g[nod]) {
            if (v[fiu] == 0) {
                q.push(fiu);
                v[fiu] = v[nod] + 1;
            }
        }
    }
}

int main() {
    fin >> n >> m >> s;
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        if (x != y)
            g[x].push_back(y);
    }
    bfs(s);
    for (int i = 1; i <= n; i++) {
        if (i == s)
            fout << "0 ";
        else if (v[i] != 0)
            fout << v[i] << " ";
        else
            fout << "-1 ";
    }
    fout << "\n";
    return 0;
}
