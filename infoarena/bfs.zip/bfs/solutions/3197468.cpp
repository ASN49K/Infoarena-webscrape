#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector <int> l[1000001];
queue <int> q;
int p;

void bfs(int n){
    int viz[100001]={0};
    int dis[100001]={0};
    q.push(n);
    viz[q.front()]=1;
    while(!q.empty()){
        
        for(int node:l[q.front()]){
            if(viz[node]==0){
                viz[node]=1;
                q.push(node);
                dis[node]=dis[q.front()]+1;
                
            }
            
        }
        q.pop();
    }
    if(dis[p]==0&&p!=n){
        fout<<"-1";
        return;
    }
    fout<<dis[p];
}

int main() {
    int n,m;
    fin>>n>>m>>p;
    int x,y;
    for(int i=1;i<=m;i++){
        fin>>y>>x;
        l[x].push_back(y);
    }
    for(int i=1;i<=n;i++){
        bfs(i);
        fout<<" ";
    }
    return 0;
}
