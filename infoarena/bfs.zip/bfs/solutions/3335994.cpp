#include <bits/stdc++.h>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NMAX=100001;
int n,m,d[NMAX],viz[NMAX];
vector<int> G[NMAX];
queue<int> Q;

void BFS(int start)
{
    viz[start]=1;
    Q.push(start);
    while(!Q.empty())
    {
        int nod = Q.front();
        Q.pop();
        for (int v:G[nod])
        {
            if(!viz[v])
            {
                viz[v]=1;
                d[v]++;
                Q.push(v);
            }
        }
    }
}
int main()
{       
    int s;
    f>>n>>m>>s;

    for(int i=1;i<=n;++i)
    {
        d[i]=-1;
    }
    for(int i=0;i<m;++i)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    BFS(s);

    for(int i=1;i<=n;++i)
    {
        g<<d[i]<<" ";
    }

    return 0;
}
