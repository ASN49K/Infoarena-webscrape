#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <iterator>

std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");

void bfs(std::vector<std::vector<int>> const &adj, std::queue<int> &q, std::vector<int> &distance) {
    if(q.empty())
        return;

    int node = q.front();
    q.pop();

    for(auto n : adj[node]) {
        if(distance[n] == -1) {
            q.push(n);
            distance[n] = distance[node] + 1;
        }
    }

    bfs(adj, q, distance);
}

int main() {
    int n, m, s;
    fin >> n >> m >> s;
    std::vector<std::vector<int>> adj(n);
    while(m--) {
        int a, b;
        fin >> a >> b;
        a--, b--;
        adj[a].push_back(b);
    }

    std::vector<int> distance(n, -1);
    {
        std::queue<int> tmp({s});
        bfs(adj, tmp, distance);
    }
    std::copy(distance.begin(), distance.end(), std::ostream_iterator<int>(fout, " "));
    return 0;
}
