#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
typedef unsigned long long ull;



const int sze = 100000;
vector<int> G[sze + 1];
bitset<sze + 1> F;
vector<int> A;
void bfs(int x){
    queue<pair<int, int>> q;
    F[x] = 1;
    A[x] = 0;
    q.push({x, 0});
    while(!q.empty()){
        auto t = q.front();
        q.pop();
        for(int i : G[t.first]){
            if(!F[i]){
                F[i] = 1;
                A[i] = t.second + 1;
                q.push({i, t.second + 1});
            }
        }
    }
}




int main()
{
    int n, m, k;
    fin>>n>>m>>k;
    A = vector<int>(n + 1, -1);

    for(int i = 1;i<=m;++i){
        int a, b;
        fin>>a>>b;
        G[a].push_back(b);
    }
    bfs(k);
    for (int i =1; i<=n;++i){
        fout<<A[i]<<" ";
    }
    

    return 0;
}