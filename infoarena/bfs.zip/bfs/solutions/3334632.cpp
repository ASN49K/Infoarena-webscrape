#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");
int n,m,s;
vector<vector<int>> M;
int viz[100001];
int cost[100001];
// fac Q, push start si viz start
// cat timp Q. iau din Q, afisez
// pt fiecare vecin, daca nu-i viz, viziteaza-l si da-i push

void bfs(int start) {
    queue<int> Q;
    Q.push(start);
    viz[start] = 1;
    cost[start] = 0;
    while (!Q.empty()) {
        int k = Q.front(); Q.pop();
        for (int i=0;i<M[k].size();i++) {
            int x = M[k][i];
            if (!viz[x]) {
                viz[x];
                cost[x] = cost[k]+1;
                Q.push(x);
            }
        }
    }
}

int main() {
    fin>>n>>m>>s;
    M.resize(n+1);
    for (int i=1;i<=m;i++) {
        int x,y;
        fin>>x>>y;
        M[x].push_back(y);
    }
    for (int i=1;i<=n;i++)cost[i]=-1;
    bfs(s);
    for (int i=1;i<=n;i++)fout<<cost[i]<<' ';
    return 0;
}