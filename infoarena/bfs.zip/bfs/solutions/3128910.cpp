#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int Nmax=100005;
vector<int> v[Nmax];
int viz[Nmax];
queue<int> q;
int main()
{
    int n,m,x,y,s;
    fin>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
    {
        viz[i]=-1;
    }
    q.push(s);
    viz[s]=0;
    while(!q.empty())
    {
        int a=q.front();
        q.pop();
        for(int i=0;i<v[a].size();i++)
        {
            if(viz[v[a][i]]==-1)
            {
                q.push(v[a][i]);
                viz[v[a][i]]=viz[a]+1;
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        fout<<viz[i]<<' ';
    }
    return 0;
}
