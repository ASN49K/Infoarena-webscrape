#include <iostream>
#include <fstream>
#include <vector>
#include <stdint.h>

const int32_t MAX_N = 100000;

std::vector<int32_t> adj[MAX_N];
int32_t dist[MAX_N];
int32_t q[MAX_N];

int main() {
	std::ifstream fin("bfs.in");
	std::ofstream fout("bfs.out");

	int32_t n, m, s;
	fin >> n >> m >> s;
	--s;

	for(int32_t i = 0; i != m; ++i) {
		int32_t x, y;
		fin >> x >> y;
		--x; --y;
		adj[x].push_back(y);
	}
	for(int32_t i = 0; i != n; ++i)
		dist[i] = -1;
	dist[s] = 0;

	int32_t st = 0, dr = 1;
	q[0] = s;
	for(; st != dr; ++st) {
		int32_t vf = q[st];

		for(int32_t next : adj[vf]) {
			if(dist[next] != -1)
				continue;
			
			dist[next] = dist[vf] + 1;
			q[dr++] = next;
		}
	}

	for(int32_t i = 0; i != n; ++i)
		fout << dist[i] << ' ';

	fin.close();
	fout.close();

	return 0;
}