#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n,m,s,dist[100010];
list<int>vecini[100010];
bool thr[100010];
queue<int>bfs;

int main()
{
    fin >>n >>m >>s;
    while(m--)
    {
        int x,y;
        fin >>x >>y;
        vecini[x].push_back(y);
    }
    for(int i = 1;i <= n;i++)
    {
        dist[i] = -1;
    }
    dist[s] = 0;
    bfs.push(s);
    thr[s] = 1;
    while(!bfs.empty())
    {
         for(int node : vecini[bfs.front()])
         {
             if(!thr[node])
             {
                 thr[node] = 1;
                 dist[node] = dist[bfs.front()]+1;
                 bfs.push(node);
             }
         }
         bfs.pop();
    }
    for(int i = 1;i <= n;i++)
    {
        fout <<dist[i]<<" ";
    }
    return 0;
}
