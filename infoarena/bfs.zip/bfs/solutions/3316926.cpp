#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");

int N, M, S;
std::vector<std::vector<int>> adj;
std::vector<int> dist;
std::queue<int> q;

void bfs() {
    dist.assign(N + 1, -1);

    q.push(S);
    dist[S] = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : adj[u]) {
            if (dist[v] == -1) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
}

int main() {
    fin >> N >> M >> S;
    adj.resize(N + 1);

    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }

    bfs();

    for (int i = 1; i <= N; ++i) {
        fout << dist[i] << " ";
    }
    fout << "\n";

    return 0;
}