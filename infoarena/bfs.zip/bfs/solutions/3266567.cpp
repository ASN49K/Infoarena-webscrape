#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector <int> v[100005];
queue <int> q;
int d[100005],n,m,s;
void bfs(int s)
{
    q.push(s);
    while (!q.empty())
    {
        int nod = q.front();
        for (int i : v[nod])
        {
            if (d[i]==0)
            {
                d[i]=d[nod]+1;
                q.push(i);
            }
        }
        q.pop();
    }
}
int main()
{
    fin>>n>>m>>s;
    for (int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        v[a].push_back(b);
    }
    d[s]=1;
    bfs(s);
    for (int i=1;i<=n;i++)
        fout<<d[i]-1<<' ';
    return 0;
}
