#include <vector>
#include <fstream>
#include <bitset>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n, m,nod;
vector<int> L[100005];
int dist[100005];
void bfs()
{
    for (int i = 1; i <= n; i++)
        dist[i] = 2e9;
    dist[nod] = 0;
    queue<int> q;
    q.push(nod);
    while (!q.empty())
    {
        int curr = q.front();
        q.pop();
        for (auto it : L[curr])
            if (dist[it] > dist[curr] + 1)
                dist[it] = dist[curr] + 1, q.push(it);
    }
}
int main()
{
    fin >> n >> m >> nod;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
    }
    bfs();
    for (int i = 1; i <= n; i++)
    {
        if (dist[i] != 2e9)
            fout << dist[i] << " ";
        else
            fout << -1 << " ";
    }
    return 0;
}