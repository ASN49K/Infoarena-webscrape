#include <fstream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,st,x,y;
//int a[10001][10001];
int q[1000001];
int viz[1000001];
vector<int>a[100001];
int main()
{
    fin>>n>>m>>st;
    for(int i=0;i<m;i++){
        fin>>x>>y;
        if(x!=y)
            a[x].push_back(y);
    }

     for(int i=1;i<=n;i++)
          sort(a[i].begin(), a[i].end());

    int p,u,nr=0;
    p=u=1;
    q[p]=st;
    viz[st]=1;

    while(p<=u){
        int k=q[p];
        for(int i=0;i<a[k].size();i++){
                int vec=a[k][i];
            if(viz[vec]==0){
                q[++u]=vec;
                viz[vec]=viz[k]+1;
            }
        }
        p++;

    }

    for(int i=1;i<=n;i++)
        fout<<viz[i]-1<<" ";


    return 0;
}
