#include <fstream>
#include <vector>
#include <queue>

using namespace std;

using VI = vector <int>;
using VB = vector <bool>;
using VVI = vector<VI>;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

VVI G;
VI v;

void bfs(int x)
{
    queue<int> Q;
    v[x] = 0;
    Q.push(x);
    while (!Q.empty())
    {
        int x = Q.front();
        Q.pop();
        for (auto y : G[x])
        {
            if (v[y] == -1)
            {
                v[y] = v[x] + 1;
                Q.push(y);
            }
        }
    }
}

int main()
{
    int n, m, s, x, y;
    cin >> n >> m >> s;
    G = VVI(n + 1);
    v = VI(n + 1, -1);
    for (int i = 1; i <= m; ++i)
    {
        cin >> x >> y;
        G[x].push_back(y);
    }
    bfs(s);
    for (int i = 1; i <= n; ++i)
        cout << v[i] << ' ';

    return 0;
}
