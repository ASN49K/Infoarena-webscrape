#include <fstream>
#include <vector>
#include <list>
#include <queue>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

int  n, m, op, x, y, k, s, v;
int sol[50001], viz[100001];
vector<int> G[100001];
queue<int> q;


void bfs(int st)
{
    viz[st] = 1;
    q.push(st);

    while (!q.empty())
    {
        int v = q.front();
        for (int i = 0; i < G[v].size(); ++i)
        {
            int j = G[v][i];
            if (viz[j] == 0)
            {
                viz[j] = viz[v] + 1;
                q.push(j);
            }
        }
        q.pop();
    }
}
int main()
{
    f >> n >> m >> s;
    for (int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n; i++)
        g << viz[i] - 1 << " ";

    return 0;
}
