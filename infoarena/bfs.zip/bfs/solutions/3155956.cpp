#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

const int NMAX = 1e5;

int d[NMAX+1];
bool vis[NMAX+1];

queue<int > q;

vector <int> G[NMAX+1];

//bool a[NMAX+1][NMAX+1];

void BFS(int x)
{
    q.push(x);
    d[x] = 0;
    while(!q.empty())
    {
        x = q.front();
        q.pop();
        for(auto i : G[x])
        {
            if(!vis[i])
            {
                q.push(i);
                d[i] = d[x] + 1;
                
            }
        }
    }
}

int main(int argc, const char * argv[])
{
    int n,m,x;
    cin >> n >> m >> x;
//    for(int i = 0; i < n; i++) //citire in matrice de aficienta
//    {
//        int x,y;
//        in >> x >> y;
//        a[x][y] = a[y][x] = true;
//    }
    for(int i = 0; i < n; i++) //citire in liste de adiacenta
    {
        int x,y;
        cin >> x >> y;
        G[x].push_back(y);
    }
    BFS(x);
    for(int i = 0 ; i < n; i++)
    {
        out << d[i] << " ";
    }
//    for(int i = 0; i < n; i++)
//    {
//        for(auto x: G[i])
//        {
//            cout << x << " ";
//        }
//    }
//    for(int i = 0; i < n; i++)
//    {
//        for(int j = 0; j < n; j++)
//        {
//            cout << a[i][j] << " ";
//        }
//        cout << "\n";
//    }
    return 0;
}
