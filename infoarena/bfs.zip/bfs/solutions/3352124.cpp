#include <fstream>
#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    ifstream in("bfs.in");
    ofstream out("bfs.out");
    int n, m, x_0;
    in >> n >> m >> x_0;
    vector <vector<int>> l_s(n + 1);
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        l_s[x].push_back(y);
    }
    in.close();
    vector <int> d(n + 1, -1);
    queue <int> q;
    d[x_0] = 0;
    q.push(x_0);
    while (!q.empty()) {
        int x = q.front();
        q.pop();
        for (auto y: l_s[x]) {
            if (d[y] == -1) {
                d[y] = 1 + d[x];
                q.push(y);
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        out << d[i] << " ";
    }
    out << "\n";
    out.close();
    return 0;
}
