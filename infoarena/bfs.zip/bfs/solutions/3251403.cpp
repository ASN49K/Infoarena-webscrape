#include <bits/stdc++.h>
using namespace std;

#define maxn 100000

ifstream in("bfs.in");
ofstream out("bfs.out");

vector<int> ad[maxn];
int cost[maxn], q[maxn];

int n;

int bfs(int s)
{
    memset(cost, -1, sizeof(cost));

    cost[s] = 0;

    int l = 1;
    q[l] = s;

    for (int i = 1; i <= l; ++i)
    {
        for (int j = 0; j < ad[q[i]].size(); ++j)
        {
            if (cost[ad[q[i]][j]] == -1) {
                cout << "vecin: " << j << endl;
                q[++l] = ad[q[i]][j];
                cost[q[l]] = cost[q[i]] + 1;
            }
        }
    }

}

int main()
{
    int m, s, i, x, y;

    in >> n >> m >> s;

    for (i = 0; i < m; ++i)
    {
        in >> x >> y;
        ad[x].push_back(y);
    }

    bfs(s);

    for (i = 1; i <= n; ++i)
    {
        out << cost[i] << ' ';
    }

    return 0;
}