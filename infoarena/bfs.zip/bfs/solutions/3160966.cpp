#include <bits/stdc++.h>

using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
#define fi first
#define se second

#define NMAX 100005
#define MOD 1000000007
#define INF 0x3f3f3f3f

vector<int> graf[NMAX];
int n, m, s, x, y, ans[NMAX];
bool visited[NMAX];

void read()
{
    in >> n >> m >> s;
    for (int i = 1; i <= m; i++)
    {
        in >> x >> y;
        graf[x].push_back(y);
    }
}

int BFS()
{
    queue<pii> Q;
    Q.emplace(s, 0);
    visited[s] = 1;
    ans[s] = 0;
    while (!Q.empty())
    {
        int v, dist;
        tie(v, dist) = Q.front();
        Q.pop();
        for (auto it : graf[v])
            if (!visited[it])
                visited[it] = 1, Q.emplace(it, dist + 1), ans[it] = dist + 1;
    }
}

void solve()
{
    BFS();
    for (int i = 1; i <= n; i++)
    {
        if (!ans[i] && i!=s) // nu se poate ajunge de la s la i
            out << -1<<' ';
        else
            out << ans[i] << ' ';
    }
}

int main()
{
    read();
    solve();
    return 0;
}