#include<fstream>
#include<queue>
#include<climits>
#include<unordered_set>
#include<vector>
using namespace std ; 
ifstream cin("bfs.in");
ofstream cout("bfs.out");
void solve (int src , vector<int> &dist , vector<vector<int> > &adj ){
      dist[src] = 0 ; 
       queue <int> q ; 
        unordered_set<int> seen ; 
          seen.insert(src) ; 
            q.push(src) ; 
              while(!q.empty()){
                  int fr = q.front() ; 
                    q.pop() ; 
                      for(int j = 0 ; j < adj[fr].size() ; j ++ ){
                             int v = adj[fr][j] ; 
                             if(dist[v] > dist[fr] + 1 ){
                                  dist[v] = dist[fr] + 1 ; 
                                     
                             }
                               if(!seen.count(v)){
                                   seen.insert(v) ; 
                                   q.push(v);
                               }
                      }
              }
}
int main(){

    int n , m , src ; 
    cin>>n>>m>>src ; 
      vector<vector<int> > adj(n+1) ;
      int x , y ; 
      for(int i = 1 ; i <= m ; i ++ ){
              cin>>x>>y;
              adj[x].push_back(y) ;
      }
        vector<int> dist (n+1,INT_MAX) ; 
           
   solve(src,dist,adj) ; 
      for(int i = 1 ; i <= n ; i ++ ){
          if(dist[i] == INT_MAX ) 
           dist[i] = -1 ; 
            cout<<dist[i]<< ' ';
      }


    return 0 ; 
}