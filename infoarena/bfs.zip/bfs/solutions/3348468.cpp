#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int NMAX = 100001;
long long nr_noduri, nr_muchii;
vector<long long>v[NMAX];
long long dist[NMAX];

void BFS(long long start)
{
    queue<long long>q;
    for(long long i = 1; i <= nr_noduri; i++)
        dist[i] = -1;
    q.push(start);
    dist[start] = 0;

    while(!q.empty())
    {
        long long nod = q.front();
        q.pop();

        for(auto vecin : v[nod])
        {
            if (dist[vecin] == -1)
            {
                dist[vecin] = dist[nod] + 1;
                q.push(vecin);
            }
        }
    }
}

int main()
{
    long long s;
    fin >> nr_noduri >> nr_muchii >> s;
    long long x, y;
    for(long long i = 1; i <= nr_muchii; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
    }
    BFS(s);

    for(long long i = 1; i <= nr_noduri; i++)
    {
        fout << dist[i] << " ";
    }
    return 0;
}
