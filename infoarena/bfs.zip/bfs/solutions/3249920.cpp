#include <fstream>
#include <queue>
using namespace std;
ifstream cin("bfs.in");
ofstream cout("bfs.out");
const int Nmax = 100001;
int n, m, s, x, y;
vector<vector<int>> graf;
vector <int> dist;
void bfs(int nod)
{
    queue <int> q;
    q.push(nod);
    dist[nod] = 1;
    while(!q.empty())
    {
        nod = q.front();
        q.pop();
        for(int next:graf[nod])
            if(dist[next] == 0)
            {
                dist[next] = dist[nod] + 1;
                q.push(next);
            }
    }
}
int main()
{
    cin >> n >> m >> s;
    dist.resize(n+1);
    graf.assign(n+1, vector<int>());
    for(int i=1; i<=m; i++)
    {
        cin >> x >> y;
        graf[x].push_back(y);
    }
    bfs(s);
    for(int i=1; i<=n; i++)
        cout << dist[i] - 1 << " ";
    return 0;
}
