#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
const int nmax = 100005;
int n, m, s, sol[nmax], fr[nmax];
vector<int> a[nmax];
void bfs(int start){
    queue<int> q;
    q.push(start);
    fr[start] = 1;
    while(!q.empty()){
        int current = q.front();
        q.pop();
        for(int vecin : a[current]){
            if(fr[vecin] == 0){
                sol[vecin] = sol[current] + 1;
                fr[vecin] = 1;
                q.push(vecin);
            }
        }
    }
}
int main(){
    f >> n >> m >> s;
    for(int i = 1; i <= m; i++){
        int x, y;
        f >> x >> y;
        a[x].push_back(y);
    }
    for(int i = 1; i <= n; i++){
        sol[i] = -1;
    }
    sol[s] = 0;
    bfs(s);
    for(int i = 1; i <= n; i++){
        g << sol[i] << ' ';
    }
}