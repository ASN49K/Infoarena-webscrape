#include <bits/stdc++.h>
#define MAXN 100001
#define INF 1000000
using namespace std;

vector<int> g[MAXN];
int dist[MAXN];

deque<int> q;

int n, m, s;

void bfs(int start){
  dist[start] = 0;
  q.push_back(start);
  while(!q.empty()){
    int node = q.front();
    q.pop_front();
    for(int i=0; i<g[node].size(); i++){
      int vecin = g[node][i];
      if(dist[vecin]<dist[node]+1) continue;

      dist[vecin] = dist[node]+1;
      q.push_back(vecin);
    }
  }
}

int main(){
  for(int i=0; i<=MAXN; i++){
    dist[i] = INF;
  }
  FILE *fin, *fout;
  fin = fopen("bfs.in", "r");
  fscanf(fin, "%d%d%d", &n, &m, &s);
  for(int i=0; i<m; i++){
    int a, b;
    fscanf(fin, "%d%d", &a, &b);
    g[a].push_back(b);
  }
  fclose(fin);

  bfs(s);

  fout = fopen("bfs.out", "w");
  for(int i=1; i<=n; i++){
    if(dist[i]!=INF) fprintf(fout, "%d ", dist[i]);
    else fprintf(fout, "-1 ");
  }
  fprintf(fout, "\n");
  fclose(fout);
  return 0;
}
