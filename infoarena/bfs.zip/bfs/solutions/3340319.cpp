#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    ifstream in("bfs.in");
    ofstream out("bfs.out");

    int n, m, x0;
    in >> n >> m >> x0;

    vector <vector <int>> a(n + 1);
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
    }
    in.close();

    vector <int> d(n + 1, -1);
    queue <int> q;

    q.push(x0);
    d[x0] = 0;
    while (!q.empty()) {
        int x = q.front();
        q.pop();
        for (auto y : a[x]) {
            if (d[y] == -1) {
                q.push(y);
                d[y] = 1 + d[x];
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        out << d[i] << " ";
    }

    out.close();
    return 0;
}
