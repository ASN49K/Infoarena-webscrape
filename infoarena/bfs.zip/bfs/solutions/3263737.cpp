#include <bits/stdc++.h>
#include <fstream>

#define int long long

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

void solve() {
   int n, m, s; fin >> n >> m >> s;
   vector<int> v[n + 1];
   for(int i = 1; i <= m; i++) {
      int x, y; fin >> x >> y;
      v[x].push_back(y);
   }
   vector<int> ans(n + 1, -1);
   vector<bool> used(n + 1, false);
   queue<pair<int, int>> q;
   q.push({s, 0}); used[s] = true;
   while(!q.empty()) {
      auto elm = q.front(); q.pop();
      ans[elm.first] = elm.second;
      for(auto nxt : v[elm.first]) {
         if(used[nxt] == false) q.push({nxt, elm.second + 1}), used[nxt] = true;
      }
   }
   for(int i = 1; i <= n; i++)
      fout << ans[i] << ' ';
   fout << '\n';
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t = 1; // cin >> t;
    while(t--) {
      solve();
   }

    return 0;
}
