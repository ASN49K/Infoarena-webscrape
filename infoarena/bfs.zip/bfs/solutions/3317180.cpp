#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int MAXN = 100005;
vector<int> graf[MAXN];
int dist[MAXN];
int parent[MAXN];
bool vizitat[MAXN];

void bfs(int start, int n) {
    // Initializare distante cu -1 (neajuns)
    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
        parent[i] = -1;
        vizitat[i] = false;
    }
    
    queue<int> q;
    q.push(start);
    dist[start] = 0;
    vizitat[start] = true;
    
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        
        for (int vecin : graf[nod]) {
            if (!vizitat[vecin]) {
                vizitat[vecin] = true;
                dist[vecin] = dist[nod] + 1;
                parent[vecin] = nod;
                q.push(vecin);
            }
        }
    }
}

int main() {
    int n, m, s;
    fin >> n >> m >> s;
    
    // Citire graf
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        graf[x].push_back(y);
    }
    
    // Rulare BFS din nodul S
    bfs(s, n);
    
    // Afisare rezultate
    for (int i = 1; i <= n; i++) {
        fout << dist[i];
        if (i < n) fout << " ";
    }
    fout << "\n";
    
    fin.close();
    fout.close();
    
    return 0;
}