#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

const int NMAX = 100001;
const int INF = 1e9;

std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");

int N, M, Start;
std::vector<int>G[NMAX];
int Viz[NMAX];
int Dist[NMAX];

void Citire()
{
	fin >> N >> M >> Start;
	for (int i = 1; i <= M; ++i)
	{
		int x, y;
		fin >> x >> y;
		G[x].push_back(y);
	}

	for (int i = 1; i <= N; ++i)
		Dist[i] = -1;

	Dist[Start] = 0;
}

void Bfs()
{
	std::queue<int>Q;
	Viz[Start] = 1;
	Q.push(Start);
	while (!Q.empty())
	{
		int nod = Q.front();
		Q.pop();
		for (auto& x : G[nod])
		{
			if (!Viz[x])
			{
				Viz[x] = 1;
				Q.push(x);
				Dist[x] = Dist[nod] + 1;
			}
		}

	}
}


void Afisare()
{
	for (int i = 1; i <= N; ++i)
		fout << Dist[i] << " ";
}

int main()
{
	Citire();
	Bfs();
	Afisare();
}


