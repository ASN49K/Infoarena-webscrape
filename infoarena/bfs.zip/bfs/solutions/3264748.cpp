#include <fstream>
#include <list>
#include <bitset>
#include <queue>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

list<int> adj[100001];
bitset<100001> vis;
long long distfs[100001];


void readGraph(const int& m)
{
    int master, slave;
    for(int i=0; i<m; i++)
    {
        cin>>master>>slave;
        adj[master].push_back(slave);
    }    
}

void setDV(const int& n)
{
    for(int i=0 ;i<n; i++)
    {
        distfs[i]=-1;
    }
}

void bfs(int start, long long d)
{
    queue<pair<int, long long>> Q;

    Q.push({start, d});
    vis[start]=1;
    distfs[start]=d;

    while(!Q.empty())
    {
        if(!adj[Q.front().first].empty())
        {
            for(int i: adj[Q.front().first])
            {
                if(vis[i]==0)
                {
                    vis[i]=1;
                    distfs[i]=Q.front().second+1;
                    Q.push({i, distfs[i]});
                }
            }
        }
        Q.pop();
    }
}


int main()
{
    ios::sync_with_stdio(false);
    
    int n, m, s;
    cin>>n>>m>>s;

    readGraph(m);
    setDV(n);
    bfs(s, 0);

    for(int i=1; i<=n; i++)
    {
        cout<<distfs[i]<<" ";
    }

}