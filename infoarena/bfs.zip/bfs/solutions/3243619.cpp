#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define inf 1e9
using namespace std;

const string file = "dfs";
ifstream fin(file+".in");
ofstream fout(file+".out");

const int dim = 1e5+1;
int n, m, s, i, drum[dim];
vector<int> g[dim];

void bfs(int nod)
{
    int i;
    for (i = 1; i <= n; i++)
        drum[i] = inf;
    drum[nod] = 0;
    queue<int> q;
    q.push(nod);
    while (!q.empty())
    {
        auto x = q.front();
        q.pop();
        for (auto y : g[x])
        {
            if (drum[y] == inf)
                drum[y] = drum[x]+1, q.push(y);
        }
    }
}

int main()
{
    fin >> n >> m >> s;
    int x, y;
    for (i = 1; i <= m; i++)
    {
        fin >> x >> y;
        g[x].pb(y);
    }
    bfs(s);
    for (i = 1; i <= n; i++)
        if (drum[i] == inf)
            fout << -1 << ' ';
        else
            fout << drum[i] << ' ';
    return 0;
}
