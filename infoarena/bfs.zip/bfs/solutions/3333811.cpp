#include <bits/stdc++.h>
#define NMAX 100000

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,start;

vector<int> A[NMAX]; //am declarat un vector cu NMAX celem de tip vector din STL numit A
int viz[NMAX];
int c[NMAX];
int inc,sf;

void citire();
void bfs(int x);
int main()
{
    int i;
    citire();
    bfs(start);
    for(i=1;i<=n;i++){
        fout<<viz[i]-1<<' ';
    }
    return 0;
}
void citire(){
    int i,x,y;
    fin>>n>>m>>start;
    for(i=0;i<m;i++){
        fin>>x>>y; //arc de la x la y
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
    }
}
void bfs(int x){
    int i;
    //parcurge BFS grafuri incepand din x
    c[0] = x; inc = sf = 0; //initializez coada cu varful de start
    viz[x] = 1; //vizitez vf de start
    while(inc<=sf){
        x = c[inc++];
        //parcurg vecinii lui x
        for(i=0;i<A[x].size();i++){
            if(viz[A[x][i]]==0){
                viz[A[x][i]] = 1+viz[x];
                c[++sf] = A[x][i];
            }
        }
    }

}
//graf stl
