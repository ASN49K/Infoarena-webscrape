#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

#define INF 2000000000
#define Nmax 100005

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");


int n,m,s,dp[Nmax];
queue<int> q;
vector<int> L[Nmax];

void bfs()
{
    int nod,len,i;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        len=L[nod].size();
        for(i=0;i<len;++i)
        {
            if(dp[L[nod][i]]>dp[nod]+1)
            {
                dp[L[nod][i]]=dp[nod]+1;
                q.push(L[nod][i]);
            }
        }
    }
}

int main()
{
    fin>>n>>m>>s;
    while(m--)
    {
        int x,y;
        fin>>x>>y;
        L[x].push_back(y);
    }
    q.push(s);
    for(int i=1;i<=n;i++)
    {
        dp[i]=INF;
    }
    dp[s]=0;
    bfs();
    for(int i=1;i<=n;i++)
    {
        if(dp[i]==INF)
        {
            fout<<"-1 ";
        }
        else
        {
            fout<<dp[i]<<" ";
        }
    }
    return 0;
}
