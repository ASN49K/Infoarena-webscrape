#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <iomanip>

using namespace std;

#define ll long long

int numNodes, numEdges, startNode;
vector<vector<int>> graph;

void ReadData() {
    cin >> numNodes >> numEdges >> startNode;
    startNode--;
    graph.assign(numNodes, vector<int>());

    for (int i = 0; i < numEdges; i++){ 
        int start, end = 0;
        cin >> start >> end;
        start--; end--;
        graph[start].push_back(end);
    }
    
}

void Solve() {
    unordered_set<int> visited;
    vector<int> result(numNodes, -1);

    queue<int> q;
    q.push(startNode);
    visited.insert(startNode);
    result[startNode] = 0;

    while (!q.empty()){
        int node = q.front();
        q.pop();
        
        for(int neighbour: graph[node]){
            if (visited.find(neighbour) == visited.end()){
                visited.insert(neighbour);
                result[neighbour] = result[node] + 1;
                q.push(neighbour);
            }  
        }
        
    }

    for (int val : result){
        cout << val << " ";
    }
    cout << "\n";
    
    
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    int t = 1;
    // cin >> t; // Uncomment for multiple test cases
    while (t--) {
        ReadData();
        Solve();   
    }
    return 0;
}