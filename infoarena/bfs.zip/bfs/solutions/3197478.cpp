#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector <int> l[1000001];
int p;

void bfs(int n,int nil){
    queue <int> q;
    int viz[100001]={0};
    vector<int> dis(nil+1,-1);
    viz[n]=1;
    dis[n]=0;
    q.push(n);
    
    while(!q.empty()){
        
        for(int node:l[q.front()]){
            if(viz[node]==0){
                viz[node]=1;
                q.push(node);
                dis[node]=dis[q.front()]+1;
                
            }
            
        }
        q.pop();
    }
    if(dis[p]==0&&p!=n){
        fout<<"-1";
        return;
    }
    fout<<dis[p];
}

int main() {
    int m,n;
    fin>>n>>m>>p;
    int x,y;
    for(int i=1;i<=m;i++){
        fin>>y>>x;
        l[x].push_back(y);
    }
    for(int i=1;i<=n;i++){
        bfs(i,n);
        fout<<" ";
    }
    return 0;
}
