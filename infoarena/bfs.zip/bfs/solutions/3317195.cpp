#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 100005;
vector<int> adj[NMAX];
int dist[NMAX];
int n, m, s;

void bfs(int start) {
    queue<int> q;
    dist[start] = 0;
    q.push(start);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (int vecin : adj[nod]) {
            if (dist[vecin] == -1) {
                dist[vecin] = dist[nod] + 1;
                q.push(vecin);
            }
        }
    }
}

int main() {
    fin >> n >> m >> s;
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y); // orientat: doar din x în y
    }

    for (int i = 1; i <= n; i++)
        dist[i] = -1;

    bfs(s);

    for (int i = 1; i <= n; i++)
        fout << dist[i] << " ";

    fout << "\n";
    return 0;
}
