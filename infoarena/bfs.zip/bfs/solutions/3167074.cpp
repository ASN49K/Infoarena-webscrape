
#include <bits/stdc++.h>
#define NMAX 1000001
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");


int N,M, nod_start,x,y;


vector<int> G[NMAX];
bool viz[NMAX];
int dist[NMAX];
queue<int> q;


void citire()
{
    fin>>N>>M>>nod_start;
    for(int i=1;i<=M;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
}


void BFS()
{
    int i;
    q.push(nod_start);
    viz[nod_start] = 1;
    while(!q.empty())
    {
        int nodc = q.front();
        q.pop();
        for(auto nod:G[nodc])
        {
            if(viz[nod]==0)
            {
                viz[nod]=1;
                dist[nod]=dist[nodc]+1;
                q.push(nod);
            }
        }
    }
}

void afisare()
{
    int i;
    for(i=1;i<=N;i++)
    {
        if(viz[i]==0 && i!=nod_start)
        {
            fout<<-1<<" ";
        }
        else fout<<dist[i]<<" ";
    }
}


int main()
{
    citire();
    BFS();
    afisare();
}
