//bfs
#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int MAXN=100000,INF = -1;
int main()
{
    int N,M,S;
    fin>>N>>M>>S;
    vector<int>a[MAXN+1];
    for (int i=0;i<M;i++)
    {
        int x,y;
        fin>>x>>y;
        a[x].push_back(y);
    }
    vector<int>dist(N+1,INF);
    queue<int>q;
    dist[S]=0;
    q.push(S);
    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        for (int vecin:a[node])
        {
            if (dist[vecin]==INF)
            {
                dist[vecin]=dist[node]+1;
                q.push(vecin);
            }
        }
    }
    for(int i=1;i<=N;i++)fout<<dist[i]<<" ";
    return 0;
}
