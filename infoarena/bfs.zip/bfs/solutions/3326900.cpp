#include <fstream>
#include <vector>
#include <queue>

#define NMAX 100002
using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

int n, m, S;

vector<vector<int>> graf;
queue<int> coada;

int ans[NMAX]; //ans[i] = raspunsul pentru nodul i

void BFS();

int main()
{
    int i, x, y;
    fin>>n>>m>>S;
    graf.resize(n + 2);
    for(i = 1; i <= m; i++)
    {
        fin>>x>>y;
        graf[x].push_back(y);
    }
    for(i = 1; i <= n; i++) ans[i] = -1;
    ans[S] = 0;
    BFS();
    for(i = 1; i <= n; i++)
        fout<<ans[i]<<' ';
    return 0;
}

void BFS()
{
 //pornesc din S = nod sursa
 int nod, i;
 coada.push(S);
 while(!coada.empty())
 {
     nod = coada.front(); coada.pop();
     for(i = 0; i < graf[nod].size(); i++)
        if(ans[graf[nod][i]] == -1) //daca nu am ajuns la acest nod inca
        {
           coada.push(graf[nod][i]);
           ans[graf[nod][i]] = ans[nod] + 1;
        }
 }
}
