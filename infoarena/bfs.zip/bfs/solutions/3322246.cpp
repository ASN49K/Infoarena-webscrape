#include <iostream>
#include <fstream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");

vector<vector<int>> graf;
vector<int> viz;
vector<int> niv;
queue<int> coada;

void bfs(int x)
{
    viz[x] = 1;
    while(!coada.empty())
    {
        for(auto &i : graf[x])
        {
            if(viz[i] == 0)
            {
                viz[i] = 1;
                niv[i] = niv[x] + 1;
                coada.push(i);
            }
        }
        coada.pop();
        if(!coada.empty())
            x = coada.front();
    }
}

int main()
{
   int N,M,S;
   fin>>N>>M>>S;
   graf.resize(N+1);
   viz.assign(N+1, 0);
   niv.assign(N+1, -1);
   niv[S] = 0;
   for(int i=1; i<=M; i++)
   {
       int x,y;
       fin>>x>>y;
       graf[x].push_back(y);
   }

   coada.push(S);
   bfs(S);

    for(int i=1; i<=N; i++)
        fout<<niv[i]<<' ';




    return 0;
}
