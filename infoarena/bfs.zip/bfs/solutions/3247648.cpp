#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

vector<vector<int>> v;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
void bfs(int s, int n)
{
    vector<int> viz;
    viz.resize(n + 2);
    for(int i = 1; i <=n ; i++)
    {
        viz[i] = -1;
    }
    queue<int> coada;
    coada.push(s);
    viz[s] = 0;
    while(!coada.empty())
    {
        int curent = coada.front();
        coada.pop();
        for(int i = 0; i < v[curent].size(); i++)
        {
            if(viz[v[curent][i]] == -1)
            {
                viz[v[curent][i]] = viz[curent] + 1;
                coada.push(v[curent][i]);
            }
        }
    }
    for(int i = 1; i <= n; i++)
    {
        fout << viz[i] << " ";
    }

}
int main()
{
    int n, m, s;
    fin >> n >> m >> s;
    v.resize(n + 2);
    for(int i = 0; i < m ; i++)
    {
        int x,y;
        fin >> x >> y;
        v[x].push_back(y);
    }
    bfs(s,n);
}
