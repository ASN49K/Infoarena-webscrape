#include <fstream>
#include <vector>
#include <queue>
#define NMAX 100002
using namespace std;
ifstream  fin("bfs.in");
ofstream fout("bfs.out");
int N,M,S;
queue<int>q;
vector<int> dist(NMAX,-1),graph[NMAX];

void citire()
{
    fin>>N>>M>>S;

    int x,y;
    for(int i=1; i<=M; i++)
    {
        fin>>x>>y;
        graph[x].push_back(y);
    }
}

int main()
{
    citire();

    dist[S]=0;
    q.push(S);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();

        for(int i=0; i<graph[nod].size(); i++)
        {
            int next_nod=graph[nod][i];
            if(dist[next_nod]==-1)
            {
                dist[next_nod]=dist[nod]+1;
                q.push(next_nod);
            }
        }
    }

    for(int i=1; i<=N; i++)
    {
        fout<< dist[i] << " ";
    }
    fout<< "\n";

    return 0;
}
