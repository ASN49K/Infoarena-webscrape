// bfs ul este parcurgerea in latime s icum functioneaza ea
// imi iau o lista
//bfss
// #include <iostream>
// #include <vector>
// #include <queue>
// #include <fstream>
//
//
// using namespace std;
// ifstream in("BFS.in");
// ofstream out("BFS.out");
//  vector <int> vecini[101];
// int viz[101];
// int nivel[101];
// vector <int> ordine;
// queue <int> p;
//
// void bfs(int start) {
//     p.push(start);
//     viz[start] = 1;
//     nivel[start] = 0;
//
//     while(!p.empty()) {
//         int k = p.front();
//         p.pop();
//         ordine.push_back(k);
//
//         for(auto i : vecini[k])
//             if(viz[i] == 0)
//             {
//                 viz[i] = 1;
//                 nivel[i] = nivel[k] + 1;
//                 p.push(i);
//
//             }
//     }
// }
//
// int main()
//         {
//             int n , m , x, i, a,b;
//             in>>n>>m>>x;
//             for(i=0;i<m;i++)
//             {
//                 cin>>a>>b;
//                 vecini[a].push_back(b);
//                 vecini[b].push_back(a);
//
//             }
//             bfs(x);
//     for (i = 0 ; i < ordine.size(); i++)
//         out<<ordine[i]<<" ";
//         }

// //merg in adancime si dupa ma intorc si asa parcurg toate varfurile o sa folosesc in implementare recursivitatea
//
// #include<iostream>
// #include<vector>
// #include<fstream>
//
// using namespace std;
// ifstream in("dfs.in");
// ofstream out("dfs.out");
// vector <int> vecini[101];
// int viz[101];
// vector <int> ordine;
//
// void dfs(int nod) {
//     viz[nod] = 1;
//     ordine.push_back(nod);
//     for (auto v : vecini[nod])
//         if (viz[v] == 0){
//         dfs(v);
//     }
//
//  }
// int main() {
//     int n,m,x, a,b,i;
//     in>>n>>m>>x;
//     for(int i=0;i<m;i++) {
//         in>>a>>b;
//         vecini[a].push_back(b);
//         vecini[b].push_back(a);
//
//
//     }
//
//     dfs(x);
//
//     for (i=0; i<n; i++)
//         out<<ordine[i]<<" ";
// }

// SORTAREA TOPOLOGICA asta inseamna ca eu daca am un o muchie intre nodul i si nodul j i trebuie sa apara inaintea lui j la final
// cum m am gandit sa implementez asta numar imi iau gradele pentru fiecare nod si dupa elimin varf cu varf cand nu mai imi pleaca nimic din el)
// pentru asta o sa imi fac o coada

#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
int viz[100001], nivel[100001],n,m,x;
queue<int> q;
vector<int> vecini[100001];
ifstream in("bfs.in");
ofstream out("bfs.out");

void bfs(int nod) {
    viz[nod] = 1;
    q.push(nod);
    while (!q.empty()) {
        int k = q.front();
        q.pop();
        for (auto v : vecini[k])
            if (viz[v] == 0) {
                viz[v] = 1;
                q.push(v);
                nivel[v] = nivel[k] + 1;
            }
    }
    for (int i = 1; i <= n; i++)
        if (nivel[i] == 0 && i != x)
            nivel[i] = -1;
    for (int i = 1; i <= n; i++) {
        out<<nivel[i]<<" ";
    }
}

int main() {
    in>>n>>m>>x;
    for (int i = 0;i < m; i++) {
        int x,y;
        in>>x>>y;
        vecini[x].push_back(y);
    }
    nivel[x] = 0;
    bfs(x);
}
