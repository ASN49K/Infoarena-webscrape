#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

vector<int> G[100005];
queue<pair<int, int>> q;

int n, m, s, viz[100005], dist[100005];

void bfs(int start)
{
    memset(dist, 0x3f, sizeof(dist));
    q.push(make_pair(start, 0));

    while (!q.empty())
    {
        int c = q.front().first, d = q.front().second;
        q.pop();

        if (viz[c]) continue;
        viz[c] = 1;
        dist[c] = d;

        for (int i = 0; i < G[c].size(); i++)
            q.push(make_pair(G[c][i], d + 1));
    }
}

int main()
{
    fin >> n >> m >> s;

    for (int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }

    bfs(s);

    for (int i = 1; i <= n ; i++)
        if (dist[i] == 0x3f3f3f3f) fout << -1 << " ";
        else fout << dist[i] << " ";
    return 0;
}
