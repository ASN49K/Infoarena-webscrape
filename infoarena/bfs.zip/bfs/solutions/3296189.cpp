#include <bits/stdc++.h>
using namespace std;
vector <int> v[100005];
int h[100005];
int main(){
    int n, m, i, x, y, p;
    ifstream fin( "bfs.in" );
    ofstream fout( "bfs.out" );
    fin >> n >> m >> p;
    for( i = 0; i < m; i++ ){
        fin >> x >> y;
        v[x].push_back( y );
    }
    queue <int> q;
    for( i = 1; i <= n; i++ ){
        h[i] = -1;
    }
    q.push( p );
    h[p] = 0;
    while( q.empty() == false ){
        x = q.front();
        ///cout << x << ' ' << h[x] << '\n';
        q.pop();
        for( i = 0; i < v[x].size(); i++ ){
            y = v[x][i];
            if( h[y] == -1 ){
                h[y] = h[x] + 1;
                q.push( y );
            }
        }
    }
    for( i = 1; i <= n; i++ ){
        fout << h[i] << ' ';
    }
    return 0;
}
