#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<vector<int>> graph(100001);
vector<int> dist(100001, -1);
queue<int> q;

void bfs(int node)
{
   q.push(node);
   dist[node] = 0;
   while (!q.empty())
   {
      int current = q.front();
      q.pop();
      for (auto neighbor : graph[current])
      {
         if (dist[neighbor] == -1)
         {
            dist[neighbor] = dist[current] + 1;
            q.push(neighbor);
         }
      }
   }
}

int main()
{
   int n, m, s;
   fin >> n >> m >> s;

   for (int i = 0; i < m; i++)
   {
      int a, b;
      fin >> a >> b;
      graph[a].push_back(b);
   }

   bfs(s);

   for (int i = 1; i <= n; i++)
      fout << dist[i] << " ";

   return 0;
}