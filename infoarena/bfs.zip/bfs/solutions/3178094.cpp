#include <fstream>
#include <vector>
#include <queue>

std::ifstream fin("bfs.in");
std::ofstream fout("bfs.out");

std::vector<int> vis;

std::queue<int> queue;

std::vector<std::vector<int>> graph;

void bfs(int node) {
	int x;
	queue.push(x);
	vis[x] = 1;
	while (!queue.empty()) {
		x = queue.front();
		queue.pop();
		for (int i : graph[x])
			if (!vis[i]) {
				queue.push(i);
				vis[i] = vis[x]+1;
			}
	}
}

int main() {
	int N, M, S;
	fin >> N >> M >> S;
	graph.assign(N + 1, std::vector<int>());

	for (int i = 1; i <= M; i++) {
		int x, y;
		fin >> x >> y;
		graph[x].emplace_back(y);
	}

	bfs(S);

	for (int i = 1; i <= N; i++)
		if (!vis[i])
			fout << -1;
		else
			fout << vis[i] << ' ';

	graph.clear();
	fin.clear(); fout.clear();
	return 0;
}