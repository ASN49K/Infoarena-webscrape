#include <iostream>
#include <queue>
#include <stack>
#include <vector>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 100005;
const int INF = -1;

vector<int> G[NMAX];
int dist[NMAX];

int main()
{
    int N, M, S;
    fin >> N >> M >> S;

    for(int i = 0 ; i < M; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
    for(int i = 1; i <= N; i++)
    {
        dist[i] = INF;
    }

    queue<int> coada;
    coada.push(S);
    dist[S] = 0;
    while(!coada.empty())
    {
        int curr = coada.front();
        coada.pop();
        for(int vecin : G[curr])
        {
            if(dist[vecin] == INF)
            {
                dist[vecin] = dist[curr] + 1;
                coada.push(vecin);
            }            
        }
    }
    for(int i = 1; i <= M; i++)
    {
        fout << dist[i] << " ";
    }
    fout << endl;
    fin.close();
    fout.close();
    return 0;
}
