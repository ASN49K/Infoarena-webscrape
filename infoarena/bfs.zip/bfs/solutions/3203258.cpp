#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#define MAX 100005
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,s;
int l[MAX]={-1};
vector <int> G[MAX];
void citire()
{
    int x,y;
    fin>>n>>m>>s;
    for(int i=0;i<m;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
}
void initializare()
{
    for(int i=1;i<=n;i++)
        l[i]=-1;
}
void bfs(int nod)
{
    l[nod]=0;
    queue <int> coada;
    coada.push(nod);
    while(!coada.empty())
    {
        int vecin=coada.front();
        for(auto i:G[vecin])
        {
            if(l[i]==-1)
            {
              l[i]=l[vecin]+1;
              coada.push(i);
            }
        }
        coada.pop();
    }
}
int main()
{
    citire();
    initializare();
    bfs(s);
    for(int i=1;i<=n;i++)
    {
        fout<<l[i]<<" ";
    }
    return 0;
}
