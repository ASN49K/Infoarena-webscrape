#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s, d[100001];
vector <int> G[1000001];
queue <int> q;

void BFS(int nod)
{
    int i, curr;
    for (i = 1 ; i <= n ; i++)
        d[i] = 2e9;
    d[nod] = 0;
    q.push(nod);
    while (!q.empty())
    {
        curr = q.front();
        q.pop();
        for (auto next : G[curr])
            if (d[next] > d[curr] + 1)
        {
            d[next] = d[curr] + 1;
            q.push(next);
        }
    }
}

int main()
{
    int i, x, y;
    fin >> n >> m >> s;
    for (i = 1 ; i <= m ; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
    }
    BFS(s);
    for (i = 1 ; i <= n ; i++)
    {
        if (d[i] != 2e9)
            fout << d[i] << " ";
        else
            fout << -1 << " ";
    }
    return 0;
}
