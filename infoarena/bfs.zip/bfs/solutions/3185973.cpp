#include <stdio.h>

#define NMAX (100'000)
#define MMAX (1'000'000)

struct node_t
{
    int begin;
    int end;
};

struct edge_t
{
    int v;
};

int n, m, s;
node_t nodes[NMAX];
edge_t edges[MMAX];

int alloc_edges(int n)
{
    static int top = 0;

    int ans = top;
    top += n;
    return ans;
}

void bfs(int s, int* distances)
{
    static int queue[NMAX];

    for(int i = 0; i < n; i++)
        distances[i] = -1;

    int top = 0;
    queue[top++] = s;
    distances[s] = 0;

    for(int front = 0; front < top; front++)
    {
        int u = queue[front];
        for(int i = nodes[u].begin; i != nodes[u].end; i++)
        {
            int v = edges[i].v;
            if(distances[v] == -1)
            {
                queue[top++] = v;
                distances[v] = distances[u] + 1;
            }
        }
    }
}

int distances[NMAX];

struct
{
    int u, v;
} _edges[MMAX];

int main()
{
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    scanf("%d %d %d", &n, &m, &s);
    s--;

    for(int i = 0; i < m; i++)
    {
        scanf("%d %d", &_edges[i].u, &_edges[i].v);
        _edges[i].u--; _edges[i].v--;

        nodes[_edges[i].u].end++;
    }

    for(int i = 0; i < n; i++)
    {
        nodes[i].begin = alloc_edges(nodes[i].end);
        nodes[i].end = nodes[i].begin;
    }

    for(int i = 0; i < m; i++)
    {
        int u = _edges[i].u;
        edges[nodes[u].end].v = _edges[i].v;
        nodes[u].end++;
    }

    bfs(s, distances);

    for(int i = 0; i < n; i++)
        printf("%d ", distances[i]);
    printf("\n");
    return 0;
}

