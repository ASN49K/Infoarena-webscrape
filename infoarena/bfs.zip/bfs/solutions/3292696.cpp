#include <bits/stdc++.h>

using namespace std;

ifstream f("bfs.in");
ofstream gg("bfs.out");

int n,m,s,dist[1005];
const int inf=INT_MAX;

vector <int> g[10005];

void bfs (int start)
{
    fill(dist+1,dist+n+1,inf);

    queue <int> q;
    q.push(start);

    dist[start]=0;

    while ( !q.empty() )
    {
        int nod=q.front();
        q.pop();

        for (auto vec:g[nod] )
        {
            if ( dist[vec]==inf )
            {
                q.push(vec);
                dist[vec]=dist[nod]+1;
            }
        }
    }
}

int main()
{
    f >> n >> m >> s;
    for (int i=1; i<=m; i++ )
    {
        int x,y;
        f >> x >> y;
        g[x].push_back(y);
    }

    bfs(s);

    for (int i=1; i<=n; i++ )
        if ( dist[i]==inf )
            gg << -1 << " ";
        else gg << dist[i] << " ";
    return 0;
}
