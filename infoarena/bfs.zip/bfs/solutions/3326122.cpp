#include<iostream> 
#include<fstream> 
#include<vector> 
#include<queue>

using namespace std; 

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> lista_adiacenta[100001];
int dist[100001];

void BFS(int start)
{
    queue<int> q; 
    q.push(start);
    dist[start] = 0;
    
    while(!q.empty())
    {
        int node = q.front();
        q.pop();
        
        for(int v : lista_adiacenta[node])
            if(dist[v] == -1)
            {
                q.push(v);
                dist[v] = dist[node] + 1;
            }
    }
}


int main() 
{
    int n, m, a, b, start, i; 
    fin >> n >> m; 
    fin >> start;
    for(i = 0; i < m; i++)
    {
        fin >> a >> b;
        lista_adiacenta[a].push_back(b);
    }
    
    for(i = 1; i <= n; i++)
        dist[i] = -1;
        
    BFS(start);
    for(i = 1; i <= n; i++)
        fout << dist[i] << " ";
}


