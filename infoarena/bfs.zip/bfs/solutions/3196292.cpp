#include <bits/stdc++.h>

using namespace std;
ifstream f("bfs.in");
ofstream out("bfs.out");

const int nmax = 1e3;
const int inf = 1e9;

vector<vector<int>>g(nmax);
int n, m,s;
vector<bool> vis(nmax + 1, false);
vector<int> d(nmax + 1, inf);

void bfs(int start){

    queue<pair<int, int>> q;
    d[start] = 0;
    q.push({start, d[start]});


    while(!q.empty()){

        int u = q.front().first;
        int dist = q.front().second;
        q.pop();

        for(int i = 0; i < g[u].size(); ++i){
            if(d[g[u][i]] == inf){
                q.push({g[u][i], d[u] + 1});
                d[g[u][i]] = d[u] + 1;
            }
        }
    }
}

int cmp = 0;
int main(){

    f >> n >> m >> s;
    for(int i = 0; i < m; ++i){
        int x, y;
        f >> x >> y;
        g[x].push_back(y);
        //g[y].push_back(x);
    }
    bfs(s);
    for(int i = 1; i <= n; ++i){
        if(d[i] == inf) out << -1 << " ";
        else out << d[i] << " ";
    }
    return 0;
}