#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n, m, s, i, j, a, b, x, y, c[100001];
vector <int> v[100001];
queue <int> q;
int main()
{
    fin>>n>>m>>s;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back(b);
    }
    q.push(s);
    c[s]=1;
    while(!q.empty())
    {
        x=q.front();
        for(auto i=v[x].begin(); i<v[x].end(); i++)
        {
            if(c[*i]==0)
            {
                c[*i]=c[x]+1;
                q.push(*i);
            }
        }
        q.pop();
    }
    for(i=1; i<=n; i++)
    {
        if(c[i]==0 && i!=s)
            fout<<-1<<" ";
        else
            fout<<c[i]-1<<" ";

    }
    return 0;
}
