#include<bits/stdc++.h>
using namespace std;
ifstream F("bfs.in");
ofstream G("bfs.out");
#define Z 2048
int n,i,j,b[100001],d[100001],p=Z,q,k,e[5],m;
vector<int> a[100001];
char s[Z],t[Z];
inline char A()
{
    if(p==Z)
        F.read(s,Z),p=0;
    return s[p++];
}
int B()
{
    int n=0;
    char c;
    for(c=A();isdigit(c);n=n*10+c-48,c=A());
    return n;
}
inline void C()
{
    if(q==Z)
        G.write(t,Z),q=0;
}
int main()
{
    for(n=B(),m=B(),j=B(),b[++b[0]]=j,d[j]=1;m--;i=B(),j=B(),a[i].push_back(j));
    for(i=1;i<=b[0];++i)
        for(int j:a[b[i]])
            if(!d[j])
                d[j]=d[b[i]]+1,b[++b[0]]=j;
    for(i=1;i<=n;t[q++]=' ',C(),++i)
        if(d[i]<1)
            t[q++]='-',C(),t[q++]=49,C();
        else {
            for(k=0,j=d[i]-1,e[k++]=j%10,j/=10;j;e[k++]=j%10,j/=10);
            for(;k;t[q++]=e[--k]+48,C());
        }
    return G.write(t,q),0;
}
