#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bfs.in");
ofstream cout("bfs.out");

vector < vector < int > > g;
vector < int > dist;

queue < int > q;

void BFS (int nod) {
    dist[nod] = 1;
    q.push(nod);
    while (!q.empty()) {
        int x = q.front();
        q.pop();
        for(int i : g[x]) {
            if(dist[i] == 0) {
                dist[i] = dist[x] + 1;
                q.push(i);
            }
        }
    }
}

int main() {
    dist.resize(100001);
    g.resize(100001);
    int n, m, s;
    cin >> n >> m >> s;
    for(int i = 0; i < m; i++) {
        int nod1, nod2;
        cin >> nod1 >> nod2;
        g[nod1].push_back(nod2);
    }
    BFS(s);
    for(int i = 1; i <= n; i++) {
        if(dist[i] == 0 && i != s) {
            cout << -1 << " ";
        }
        else {
            cout << dist[i] - 1 << " ";
        }
    }
    return 0;
}
