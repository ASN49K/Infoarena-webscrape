#include <iostream>
#include <vector>
#include <queue>

using namespace std;


ifstream f("bfs.in");
ofstream g("bfs.out");
const int NMAX= 1e5;

vector <int> L[NMAX+1];
int d[NMAX+1];

void bfs(int s){
    d[s]=0;
    queue<int> q;
    q.push(s);
    while ( !q.empty()){
        int node = q.front();
        q.pop();
        for(auto next: L[node]) {
            if(d[next] == -1)
            d[next] = d[node] +1;
            q.push(next);
        }
    }
}

int main(){

    int n,m,s;
    f >> n >> m >>s;
    for(int i =1 ; i<=m; i++){
        int x,y;
        f>>x>>y;
        L[x].push_back(y);
    }
for(int i =1 ; i<=n; i++){
    d[i]=-1;
}

bfs(s);
for(int i =1; i <=n; i++){
    g<<d[i]<<' '; 
}

    return 0;
}