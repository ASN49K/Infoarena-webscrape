#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

vector <int> a[100001];
queue <int> q;
int viz[100001];

void bfs(int s)
{
    int nod,i;
    viz[s]=1;
    q.push(s);
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(i=0;i<a[nod].size();i++)
        {
            if(viz[a[nod][i]]==0)
            {
                viz[a[nod][i]]=viz[nod]+1;
                q.push(a[nod][i]);
            }
        }
    }
}

int main()
{int n,m,i,j,x,y,nr=0,s;
    f>>n>>m>>s;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x].push_back(y);
    }
    bfs(s);
    for(i=1;i<=n;i++)
    {
        g<<viz[i]-1<<" ";
    }
    return 0;
}
