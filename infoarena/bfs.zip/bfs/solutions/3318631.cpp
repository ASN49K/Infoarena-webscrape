#include <bits/stdc++.h>

using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
int n,m,s, dist[100001], x,y,cnt_comp;
vector<int> L[100001];
queue<int>q;
void bfs()
{
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(int i=0;i<L[nod].size();i++)
        {
            int v=L[nod][i];
            if(dist[v]==-1)
            {
                dist[v]=dist[nod]+1;
                q.push(v);
            }
        }
    }
}
int main()
{
    f>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        f>>x>>y;
        L[x].push_back(y);
        //L[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        dist[i]=-1;
    }
    q.push(s);
    dist[s]=0;

    bfs();
    for(int i=1;i<=n;i++)
    {
        g<<dist[i]<<" ";
    }

    return 0;
}
