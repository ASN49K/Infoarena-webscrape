#include <fstream>
#include <vector>
#include <queue>

using namespace std;

struct nod
{
    vector <int> vec;
};

ifstream f("bfs.in");
ofstream g("bfs.out");
int n, m, x;
nod v[100005];
int viz[100005];

void bfs(int k)
{
    queue <pair<int, int>> q;
    viz[k] = -1;
    q.push(make_pair(k, 0));

    int cur, cost;
    while(!q.empty())
    {
        cur = q.front().first;
        cost = q.front().second;

        for(int i = 0; i<v[cur].vec.size(); i++)
        {
            if(viz[v[cur].vec[i]] == 0)
            {
                viz[v[cur].vec[i]] = cost+1;
                q.push(make_pair(v[cur].vec[i], cost+1));
            }
        }

        q.pop();
    }
}

int main()
{
    f>>n>>m>>x;
    int st, dr;
    for(int i = 1; i<=m; i++)
    {
        f>>st>>dr;
        if(st == dr)
        {
            continue;
        }
        v[st].vec.push_back(dr);
    }

    bfs(x);

    for(int i = 1; i<=n; i++)
    {
        if(viz[i] == 0)
        {
            g<<-1<<" ";
        }
        else if(viz[i] == -1)
        {
            g<<0<<" ";
        }
        else
        {
            g<<viz[i]<<" ";
        }

    }

    return 0;
}
