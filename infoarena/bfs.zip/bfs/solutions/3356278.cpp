#include <fstream>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int v[10001],x[10001],a[10001][10001],n,m,s,dr,st,k,tata[10001],drum[10001];

void bfs(int start){
    st=dr=1;
    v[start]=1;
    x[1]=start;
    while(st<=dr){
        k=x[st];
        for(int i=1;i<=n;i++){
            if(a[k][i]==1 and v[i]==0){
                v[i]=1;
                x[++dr]=i;
                tata[i]=k;
                drum[i]=drum[k]+1;
            }
        }
        st++;
    }
}

int main(){
    int t,z;
    fin >> n >> m >> s;
    for(int i=1;i<=m;i++){
        fin >> z >> t;
        a[z][t]=1;
    }
    bfs(s);
    for(int i=1;i<=n;i++){
        if(drum[i]==0 and i!=s)
            drum[i]=-1;
        fout << drum[i] << " ";
    }
    return 0;
}