#include <fstream>
#include <vector>
#include <queue>
#define NMAX 100002

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n,m;
int S;
vector<int> G[NMAX];

void bfs(int x);
int dmin[NMAX];
queue<int> C;

int main()
{
    int i,x,y;
    fin>>n>>m>>S;
    for(i=1; i<=m; i++)
        {
         fin>>x>>y;
         G[x].push_back(y);
        }
    bfs(S);
    for(i=1; i<=n; i++)
        if(dmin[i]==0)
            fout<<-1<<' ';
            else fout<<dmin[i]-1<<' ';
    return 0;
}

void bfs(int x)
{
    int i;
    C.push(x);
    dmin[x]=1;
    while(!C.empty())
        {
         x=C.front();
         C.pop();
         for(i=0; i<G[x].size(); i++)
            if(!dmin[G[x][i]])
                {
                 dmin[G[x][i]]=1+dmin[x];
                 C.push(G[x][i]);
                }
        }
}