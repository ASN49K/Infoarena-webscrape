#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int N = 100005;
vector<int> g[N];
int d[N];
int n, m, s;

int main() {
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    cin >> n >> m >> s;
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
    }

    for (int i = 1; i <= n; i++) d[i] = -1;
    queue<int> q;
    q.push(s);
    d[s] = 0;

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : g[u])
            if (d[v] == -1) {
                d[v] = d[u] + 1;
                q.push(v);
            }
    }

    for (int i = 1; i <= n; i++)
        cout << d[i] << " ";
    return 0;
}
