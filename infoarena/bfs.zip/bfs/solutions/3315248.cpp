#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, s;
vector<vector<int>> v(100001);
int distante[100001];

void bfs(int start) {
    for(int i = 1; i <= n; i++) distante[i] = -1;
    distante[start] = 0;
    queue<int> q;
    q.push(start);

    while(!q.empty()) {
        int acuma = q.front();
        q.pop();
        for(auto i : v[acuma]) {
            if(distante[i] == -1) {
                distante[i] = distante[acuma] + 1;
                q.push(i);
            }
        }
    }

}

int main()
{
    fin >> n >> m >> s;
    for(int i = 1; i <= m; i++) {
        int a, b;
        fin >> a >> b;
        v[a].push_back(b);
    }
    bfs(s);
    for(int i = 1; i <= n; i++) {
        if(distante[i] == -1) fout << -1 << " ";
        else fout << distante[i] << " ";
    }
    return 0;
}
