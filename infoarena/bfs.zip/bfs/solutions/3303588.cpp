#include <bits/stdc++.h>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");
const int dim = 100002;
vector<int> a[dim], ordine;
queue<int> coada;
bool viz[dim];
int dist[dim];

void bfs(int sursa)
{
    viz[sursa] = 1;
    dist[sursa] = 0;
    coada.push(sursa);
    ordine.push_back(sursa);

    while (!coada.empty())
    {
        int x = coada.front();

        for (int y : a[x])
            if (!viz[y])
        {
            viz[y] = 1;
            dist[y] = dist[x] + 1;
            coada.push(y);
            ordine.push_back(y);
        }

        coada.pop();
    }
}

int main()
{
    int n, m, x, y, sursa;
    fin >> n >> m >> sursa;

    for (int i = 1; i <= n; i++)
        dist[i] = INT_MAX;

    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
    }

    bfs(sursa);

    for (int i = 1; i <= n; i++)
        if (dist[i] == INT_MAX)
            fout << "-1 ";
        else fout << dist[i] << ' ';
    return 0;
}
