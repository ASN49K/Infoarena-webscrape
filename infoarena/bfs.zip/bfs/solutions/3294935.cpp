#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int NMAX=100002;
vector<int>mat[NMAX];
queue<int> q;
int dist[NMAX], viz[NMAX],n,m,s;

void bfs(int node)
{
    q.push(node);
    viz[node]=1;
    while(!q.empty())
    {
        int nodCrt=q.front();
        q.pop();
        for(auto i:mat[nodCrt])
            if(viz[i]==0)
        {
            viz[i]=1;
            q.push(i);
            dist[i]=dist[nodCrt]+1;
        }
    }
}

int main()
{
    fin>>n>>m>>s;
    int x,y;
    while(fin>>x>>y)
        mat[x].push_back(y);
    bfs(s);
    for(int j=1;j<=n;j++)
        if(viz[j]==0)
            fout<<-1<<" ";
        else{ fout<<dist[j];
        fout<<" ";}
    return 0;
}
