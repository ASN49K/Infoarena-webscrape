#include <bits/stdc++.h>
using namespace std;

int C[100100];
int nr, r, n, c, A[100100], v[100100];
vector<int> V[100100];

int main(){
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    cin >> nr >> r >> n;
    int x, y;

    for(int i=1; i<=r; i++){
        cin >> x >> y;
        V[x].push_back(y);
    }

    C[1] = n;
    c++;

    for(int l=1; l<=c; l++){
        int de = C[l];
        for(int i=0; i<V[de].size(); i++){
            int la = V[de][i];

            v[la] = 1;
             if(la != n){
                A[la] = A[de] + 1;
                c++;
                C[c] = la;
            }
        }
    }

    for(int i=1; i<=nr; i++){
        if(!v[i]){
            A[i] = -1;
        }
    }

    for(int i=1; i<=nr; i++){
        cout << A[i] << ' ';
    }

}