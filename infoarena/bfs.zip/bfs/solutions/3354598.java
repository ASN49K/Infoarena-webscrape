import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.StringTokenizer;

class MyScanner1 {
    private BufferedReader br;
    private StringTokenizer st;

    public MyScanner1(Reader reader) {
        br = new BufferedReader(reader);
    }

    public String next() {
        while (st == null || !st.hasMoreElements()) {
            try {
                st = new StringTokenizer(br.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return st.nextToken();
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }

    public long nextLong() {
        return Long.parseLong(next());
    }

    public double nextDouble() {
        return Double.parseDouble(next());
    }

    public String nextLine() {
        String str = "";
        try {
            str = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }
}

class bfs {

    public static void main(String[] args) {
        MyScanner1 scanner = new MyScanner1(new InputStreamReader(System.in));

        int n, m, s;
        n = scanner.nextInt();
        m = scanner.nextInt();
        s = scanner.nextInt();

        int[] number = new int[n + 1];
        int[][] graph = new int[n + 1][n + 1];
        int[] distance = new int[n + 1];

        Arrays.fill(distance, Integer.MAX_VALUE);
        Arrays.fill(number, 1);

        for (int i = 1; i <= m; i++)
        {
            int a = scanner.nextInt();
            int b = scanner.nextInt();

            graph[a][number[a]] = b;
            number[a]++;
        }

        Queue<Integer> q = new ArrayDeque<>();
        q.add(s);
        distance[s] = 0;

        while (!q.isEmpty())
        {
            int node = q.poll();

            for (Integer adj : graph[node])
            {
                if (distance[node] + 1 < distance[adj])
                {
                    distance[adj] = distance[node] + 1;
                    q.add(adj);
                }
            }
        }

        for (int i = 1; i <= n; i++)
        {
            if (distance[i] == Integer.MAX_VALUE)
            {
                distance[i] = -1;
            }
        }

        for  (int i = 1; i <= n; i++)
        {
            System.out.print(distance[i] + " ");
        }

    }
}
