#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

int main() {
    int n, m, s;
    fin >> n >> m >> s;

    // lista de adiacenta
    vector<vector<int>> g(n + 1);
    for (int i = 0; i < m; ++i) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
    }

    vector<int> dist(n + 1, -1); // init cu -1 caz in care e inaccesibil
    queue<int> q;
    dist[s] = 0;
    q.push(s); // primul nod din coada e s, cel de care am nevoie

    // algoritmul de bfs
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        // scoatem primul nod din coada
        // loop ul: luam pe rand cele adiacente si incrementam distanta cu 1 pt fiecare nod
        for (int vec : g[node]) {
            if (dist[vec] == -1) {
                dist[vec] = dist[node] + 1; // actualizarea propriu zisa
                q.push(vec); // le punem in queue in ordine
            }
        }
    }

    // asa scoatem outputul
    for (int i = 1; i <= n; ++i)
        fout << dist[i] << " ";
    fout << "\n";

    return 0;
}
