#include <fstream>
#include <vector>
#include <queue>
#define NMAX 100002
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n, m, s;
vector<int> G[NMAX]; //lista de adiacenta a vf x
int viz[NMAX]; //viz[x]=distanta minima de la start la x exprimata in nr de varfuri de pe lant/drum

queue <int> C;
int inc ,sf;
void citire();
void BFS(int x);
int main()
{
    int x;
    citire();
    BFS(s);
    for(x=1; x<=n; x++)
    {
        fout<<viz[x]-1<<' ';
    }
    return 0;
}
void citire()
{
    int i, x, y;
    fin>>n>>m>>s;
    for(i=0; i<m; i++)
    {
        fin>>x>>y; //arc
        G[x].push_back(y);
    }
}
void BFS(int x)
{
    int i;
    C.push(x);
    viz[x]=1;
    while(!C.empty())
        {
           x=C.front();
           C.pop();
            ///parcurg vecinii lui x
            for(i=0; i<G[x].size(); i++)
            {
                if(!viz[G[x][i]])
                {
                   viz[G[x][i]]=1+viz[x];
                C.push(G[x][i]);
                }
            }

        }
}
