from collections import deque


def bfs(target, graph, dist):
    dist[target] = 0
    q = deque([target])

    while q:
        curr = q.popleft()

        for neighbour in graph[curr]:
            if dist[neighbour] == -1:
                dist[neighbour] = dist[curr] + 1
                q.append(neighbour)

    

def main():
    fin = open('bfs.in', 'r')
    fout = open('bfs.out', 'w')
    input = fin.readline

    n, m, s = map(int, input().split())
    graph = [[] for _ in range(n+1)]
    dist = [-1] * (n+1)

    for _ in range(m):
        x, y = map(int, input().split())
        graph[x].append(y)

    bfs(s, graph, dist)
    for i in range(1, n + 1):
        fout.write(str(dist[i]) + " ")
    
    fin.close()
    fout.close()

main()