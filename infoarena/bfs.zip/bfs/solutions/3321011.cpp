#include <bits/stdc++.h>

using namespace std;

int save[100005], n;
vector<int> adj[100005];
queue<int> q;

void bfs(int k)
{
    q.push(k);

    for(int i=1; i<=n; i++)
        save[i] = 21e8;
    save[k] = 0;

    while(q.empty() == false)
    {
        int nod = q.front(); q.pop();

        for(auto x : adj[nod])
            if(save[x] > save[nod] + 1)
                save[x] = save[nod] + 1, q.push(x);
    }
}

int main()
{
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");
    int m, a, b, k, cnt = 0;
    cin>>n>>m>>k;

    for(int i=0; i<m; i++)
    {
        cin>>a>>b;
        adj[a].push_back(b);
    }

    bfs(k);

    for(int i=1; i<=n; i++)
        if(save[i] == 21e8)
            save[i] = -1;

    for(int i=1; i<=n; i++)
        cout<<save[i]<<" ";

    return 0;
}
