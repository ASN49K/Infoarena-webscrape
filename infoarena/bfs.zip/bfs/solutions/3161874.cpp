#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int N, M, S;
const int NMax = 100000;
vector<int> G[NMax + 2];
int dist[NMax + 2];

void Read()
{
    int x, y;
    fin >> N >> M >> S;
    for (int i = 1; i <= M; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
    }
}
queue<int> Q;
void BFS(int Start)
{
    Q.push(Start);
    while (!Q.empty())
    {
        int Nod = Q.front();
        // cout<<
        Q.pop();
        for (int i = 0; i < (int)G[Nod].size(); i++)
        {
            if (dist[G[Nod][i]] == -1)
            {
                dist[G[Nod][i]] = dist[Nod] + 1;
                Q.push(G[Nod][i]);
            }
        }
    }
}
void Write()
{
    for (int i = 1; i <= N; i++)
    {
        fout << dist[i] << " ";
    }
}
int main()
{
    Read();
    for (int i = 1; i <= N; i++)
        dist[i] = -1;
    dist[S]=0;
    BFS(S);
    Write();
}