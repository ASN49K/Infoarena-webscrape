#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

void bfs(int node, vector<vector<int>> &adj, vector<int> &vizitat, vector<int> &depth, queue<int> &q)
{

    q.push(node);
    depth[node] = 0;
    int nr = 0;
    while (!q.empty())
    {
        int s = q.front();
        q.pop();
        vizitat[s] = 1;

        for (auto vecin : adj[s])
        {
            if (!vizitat[vecin])
            {
                q.push(vecin);
                vizitat[vecin] = 1;
                depth[vecin] = depth[s] + 1;
            }
        }
    }
}

int main()
{
    int m, n, x;
    f >> m >> n >> x;
    int a, b;
    vector<vector<int>> adj(m + 1);
    while (f >> a >> b)
    {
        adj[a].push_back(b);
    }
    vector<int> vizitat(m + 1, 0);
    queue<int> q;
    vector<int> depth(m + 1, -1);
    bfs(x, adj, vizitat, depth, q);
    depth[x] = 0;
    for (int i = 1; i <= m; i++)
        g << depth[i] << " ";

    return 0;
}
