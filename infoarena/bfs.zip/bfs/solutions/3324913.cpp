#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<vector<int>> v(100100);
int w[100100];
int d[100100];
int n,m,s;
void BFS(int a){
    queue<int> q;
    q.push(a);
    d[a]=0;
    //w[a]=1;
    while(!q.empty()){
    int r=q.front();
        if(!w[r]){
            for(auto e : v[r]){
                if(!w[e]){
                    cout<<e<<" "<<r<<" "<<d[r]+1<<endl;
                    d[e]=d[r]+1;
                    q.push(e);
                }
            }
            w[r]=1;
        }
        q.pop();
    }

}
int main(){
    int a,b;
    fin>>n>>m>>s;
    for(int i=1; i<=m; i++){
        fin>>a>>b;
        if(a!=b)
        v[a].push_back(b);
    }
    BFS(s);
    for(int i=1; i<=n; i++){
            if(i==s)
            fout<<0<<" ";
            else if(w[i])
            fout<<d[i]<<" ";
            else
            fout<<-1<<" ";
        //cout<<(w[s]-w[i])<<" ";
    }
    return 0;
}
