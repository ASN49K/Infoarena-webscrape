#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

fstream fin("bfs.in");
fstream fout("bfs.out");

vector<bool> visited;
vector<vector<int>> adjlist;
vector<int> costul ;

int N , M , S;
int x , y;

void bfs(int node) {
    queue<int> q;
    visited[node] = true;
    q.push(node);
    costul[node] = 0;
    while (!q.empty()) {
        int x = q.front();
        q.pop();
        for ( int y : adjlist[x] ) {
            if (!visited[y]) {
                visited[y] = true;
                costul[y] = costul[x] + 1;
                q.push(y);
            }
        }
    }
}
int main()
{
    fin >> N >> M >> S;
    adjlist.resize(N+5);
    visited.resize(N+5);
    costul.resize(N+5);
    fill(costul.begin(), costul.end(), -1);

    for (int i = 1; i <= M; i++) {
        fin >> x >> y;
        adjlist[x].push_back(y);
    }
    bfs(S);
    for (int i = 1; i <= N; i++)
        fout << costul[i] << " ";


}
