#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");	

struct Graph {
	vector<int> node;

	int len() {
		return node.size();
	}
}graph[100009];

int shortest_path_bfs(int n, Graph graph[], int start, int end) {
	queue<int> q;
	vector<int> visited;
	vector<int> distance = vector<int>(n + 1, 0);

	q.push(start);
	visited.push_back(start);

	while (q.size() != 0) {
		int vertex = q.front();
		q.pop();

		if (vertex == end)
			return distance[vertex];
		for (int i = 0; i < (int)graph[vertex].node.size(); i++) {
			if ((int)count(visited.begin(), visited.end(), graph[vertex].node[i]) == 0) {
				distance[graph[vertex].node[i]] = distance[vertex] + 1;
				visited.push_back(graph[vertex].node[i]);
				q.push(graph[vertex].node[i]);
			}	
		}
	}
	return -1;
}

int n, m, s, x, y;

int main()
{
	fin >> n >> m >> s;
	for (int i = 0; i < m; i++) {
		fin >> x >> y;
		graph[x].node.push_back(y);
	}
	for (int i = 1; i <= n; i++) {
		fout << shortest_path_bfs(n, graph, s, i) << " ";
	}
	return 0;
}