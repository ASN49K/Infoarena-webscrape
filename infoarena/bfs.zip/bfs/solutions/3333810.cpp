#include <iostream>
#include <fstream>
#include <vector>

#define NMAX 100001
using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");
int n,start,m,x,y;
int c[NMAX];
// vector<int> A; /// am declarat un vector din STL cu 0 elemente de tip int numit A

int viz[NMAX];
vector<int> A[NMAX]; ///vector cu NMAX elem de tip vector din STL

void bfs(int x)
{
  int i,k,st,dr;
  //initializez coada
  st=dr=1;
  c[1]=x;
  viz[x]=1;//vizitez varful initial
  while(st<=dr)//cat timp coada nu este vida
  {
    k=c[st];//preiau un element din coada
    for(i=0 ;i< A[x].size();i++)//parcurg varfurile
      if(viz[A[k][i]]==0)//daca i este vecin cu k si nu este vizitat
      {
        viz[A[k][i]]=1+viz[k];//il vizitez
        dr++;
        c[dr]=A[k][i];//il adaug in coada
      }
    st++;//sterg din coada
  }
}


void citire()
{
    fin>>n>>m>>start;
    for (int i=0; i<m; i++)
    {
        fin>>x>>y;
        //adaug pe y in lista lui x
        /// A[x][d[x]]=y;
        A[x].push_back(y);

    }
}

afisare_lad()
{
    for (int i=1; i<=n;i++)
    {
        for (int j=0; j<A[i].size(); j++)
            fout<<A[i][j]<<' ';
        fout<<'\n';
    }
}

int main()
{
    citire();
    bfs(start);
    for (int i=1; i<=n; i++)
        fout<<viz[i]-1<<' ';

    return 0;
}
