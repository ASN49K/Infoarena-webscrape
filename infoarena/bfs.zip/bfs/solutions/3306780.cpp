#include <bits/stdc++.h>
using namespace std;

vector<int> G[101];
int sol[101];
bool viz[101];
void BFS (int y) {
    sol[y] = 0;
    queue <int> q;
    q.push(y);
    viz[y] = true;
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (auto i: G[nod]) {
            if (viz[i] == false) {
                viz[i] = true;
                q.push(i);
                sol[i] = sol[nod] + 1;
            }
        }
    }
}

int main() {
    ifstream cin ("bfs.in");
    ofstream cout ("bfs.out");
    int n, m, s;
    cin >> n >> m >> s;
    for (int i = 0; i < m; ++i) {
        int x, y;
        cin >> x >> y;
        G[x].push_back(y);
    }
    for (int i = 1; i <= n; ++i) {
        sol[i] = -1;
    }
    BFS(s);
    for (int i = 1; i <= n; ++i) {
        cout << sol[i] << " ";
    }
    return 0;
}
