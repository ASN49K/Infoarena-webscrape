#include <iostream>
#include <fstream>
#define nrn 100001
#define nrm 1000001
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");
int x, y, n, start[nrn], t[2][2*nrm], k, c[nrn];
int plec, ajung,m,i,cost[nrn];
void bfs_cu_liste(int plec)
{
    int pi, ps, k, om;
    pi=ps=1;
    c[ps]=plec;
    cost[plec]=0;
    while(ps<=pi)
    {
        k=c[ps];
        om=start[k];
        while(om)
        {
            if(cost[t[0][om]]==-1)
            {
                c[++pi]=t[0][om];
                cost[t[0][om]]=cost[k]+1;///costul lui ps+1
            }
            om=t[1][om];
        }
        ps++;
    }
}
int main()
{
    f>>n>>m>>plec;
    ///creez lista de vecini
    for (i=1;i<=m;i++)
    {
        f>>x>>y;
        k++;
        t[0][k]=y;
        t[1][k]=start[x];
        start[x]=k;
    }
    for (i=1;i<=nrn;i++)
        cost[i]=-1;
    bfs_cu_liste(plec);
    for (i=1;i<=n;i++)
        g<<cost[i]<<" ";
    return 0;
}
