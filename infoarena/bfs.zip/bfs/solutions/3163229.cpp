/*
Se considera un graf orientat cu N varfuri si M arce.
Fiind dat un nod S, sa se determine, pentru fiecare nod X, numarul minim de arce ce trebuie parcurse pentru a ajunge din nodul sursa S la nodul X.
*/
#include<iostream>
#include<fstream>
#include<vector>
#include<queue>
using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int NR_MAX_NODURI=100000;
vector<int>G[NR_MAX_NODURI+1];
int distanta[NR_MAX_NODURI+1];
bool vizitat[NR_MAX_NODURI+1];

void bfs(int nod_start)
{
    distanta[nod_start]=0;
    queue<int>coada;
    coada.push(nod_start);
    while(!coada.empty())
    {
        nod_start = coada.front();
        vizitat[nod_start]=1;
        coada.pop();
        for(auto next: G[nod_start])
        {
            if(!vizitat[next])
            {
                coada.push(next);
                distanta[next]=distanta[nod_start]+1;
                vizitat[next]=1;
            }
        }
    }
}

int main(){
    int N,M,S;
    int nod1, nod2;
    f>>N>>M>>S;
    for(int i=1; i<=M; i++){
        f>>nod1>>nod2;
        G[nod1].push_back(nod2);
    }

    bfs(S);
    for(int i=1; i<=N; i++){
        if(i==S){
            g<<0<<" ";
        }
        else{
            
            if(distanta[i]==0){
                g<<-1<<" ";
            }

            else 
                g<<distanta[i]<<" ";
        } 
    }
       return 0;
}
 
