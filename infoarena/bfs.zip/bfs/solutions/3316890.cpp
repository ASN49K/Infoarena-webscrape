///DFS
/*
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

const int maxn = 100001;
vector<int> graf[maxn];
bool vizitat[maxn];

void dfs(int nod) {
    vizitat[nod] = true;
    for (int vecin : graf[nod]) {
        if (!vizitat[vecin]) {
            dfs(vecin);
        }
    }
}

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");
    int n, m;
    fin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v;
        fin >> u >> v;
        graf[u].push_back(v);
        graf[v].push_back(u);
    }

    int componente_conexe = 0;
    for (int i = 1; i <= n; ++i) {
        if (!vizitat[i]) {
            dfs(i);
            componente_conexe++;
        }
    }

    fout << componente_conexe << '\n';
    fin.close();
    fout.close();
    return 0;
}
*/

/// BFS
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int maxn = 100001;
vector<int> graf[maxn];
int dist[maxn];

int main() {
    ifstream fin("bfs.in");
    ofstream fout("bfs.out");

    int n, m, S;
    fin >> n >> m >> S;

    for (int i = 0; i < m; ++i) {
        int u, v;
        fin >> u >> v;
        graf[u].push_back(v);//orientat
    }

    for (int i = 1; i <= n; ++i) {
        dist[i] = -1;
    }

    queue<int> q;
    q.push(S);
    dist[S] = 0;

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (int vecin : graf[nod]) {
            if (dist[vecin] == -1) {
                dist[vecin] = dist[nod] + 1;
                q.push(vecin);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        fout << dist[i] << " ";
    }
    fout << '\n';

    fin.close();
    fout.close();
    return 0;
}
