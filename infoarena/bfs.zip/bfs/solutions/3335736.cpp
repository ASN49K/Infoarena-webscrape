/*
https://infoarena.ro/problema/bfs

 */
#include <bitset>
#include <fstream>
#include <iostream>
#include <queue>
#include <vector>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<vector<int> > ma(100001);


int v[100001];
bitset <100001> visitat;

queue<int> q;
int main() {
    int n, m, s, a, b;
    fin >> n >> m >> s;

    for (int i = 0; i < m; i++) {
        fin >> a >> b;
        ma[a].push_back(b);
    }


    q.push(s);
    visitat[s] = 1;
    while (q.size() > 0 ) {
        int nod_curent = q.front();
        q.pop();
        for (int i = 0; i < ma[nod_curent].size() ; i++) {
            if (visitat[ma[nod_curent][i]] == 0 ) {
                q.push (ma[nod_curent][i]);
                v[ma[nod_curent][i]] = v[nod_curent] + 1;
                visitat[ma[nod_curent][i]] = 1;
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        if (v[i]!=0) {
            fout << v[i] << " ";
        }else {
            if (i != s ) {
                fout <<-1 <<" ";
            }else {
                fout <<0<<" ";
            }
        }
    }
    return 0;
}
