#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n;
int start;
int C[NMAX];
int inc,sf;
vector<int> a[NMAX];
int viz[NMAX];
// viz[i]=0 daca nu a fost vizitat; numarul d evarfuri de pe cel mai scurt
void citire();
void bfs(int x);
int main()
{
    int i;
     citire();
     bfs(start);
     for(i=1;i<=n;i++)
         fout<<viz[i]-1<<' ';
    return 0;
}
void citire()
        {
          int m,i,x,y;
          fin>>n>>m>>start;
          for(i=0;i<m;i++)
          {
              fin>>x>>y;
              //y intra in klista de adiacenta a lui z
              a[x].push_back(y);
          }
        }
void bfs(int x)
        {
        int i;
        viz[x]=1;
        C[1]=x;
        inc=sf=1;
        while(inc<=sf)
        {
            x=C[inc++];
            for(i=0;i<a[x].size();i++)
                if(!viz[a[x][i]])
                {
                    viz[a[x][i]]=1+viz[x];
                    C[++sf]=a[x][i];
                }
        }

        }
