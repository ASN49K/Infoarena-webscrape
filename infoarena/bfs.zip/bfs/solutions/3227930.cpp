#include <bits/stdc++.h>

using namespace std;

class Task {
public:
    void solve() {
        read_input();
        print_output(bfs(source));
    }

private:
    static const int NMAX = (int)1e5 + 5;
    const int INF = 1e9;

    int n, m, source;
    vector<int> adj[NMAX];

    void read_input() {
        ifstream fin("bfs.in");
        fin >> n >> m >> source;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y;
            adj[x].push_back(y);
        }
        fin.close();
    }

    vector<int> bfs(int source)
    {
        vector<int> dist(n + 1, INF);
        queue<int> q;

        q.push(source);
        dist[source] = 0;

        while (!q.empty()) {
            int node = q.front();
            q.pop();

            for (auto& neigh : adj[node]) {
                if (dist[node] + 1 < dist[neigh]) {
                    dist[neigh] = dist[node] + 1;
                    q.push(neigh);
                }
            }
        }

        for (auto& value : dist) {
            if (value == INF) {
                value = -1;
            }
        }

        return dist;
    }

    void print_output(const vector<int>& dist) {
        ofstream fout("bfs.out");
        for (int node = 1; node <= n; node++) {
            fout << dist[node] << ' ';
        }
        fout.close();
    }
};

int main() {
    auto* task = new (nothrow) Task();
    if (!task) {
        cerr << "Error\n";
        return -1;
    }
    task->solve();
    delete task;
    return 0;
}
