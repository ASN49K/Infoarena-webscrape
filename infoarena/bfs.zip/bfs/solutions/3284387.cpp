﻿#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000
#define MOD 1000000007
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n, x, y, dist[100005],m,p;
vector<int>l[100005];
void Bfs(int nod)
{
	queue<int>q;
	for (int i = 1; i <= n; i++)
		dist[i] = 2e9;
	dist[nod] = 0;
	q.push(nod);
	while (!q.empty())
	{
		int curr = q.front();
		q.pop();
		for (auto next : l[curr])
		{
			if (dist[next] > dist[curr] + 1)
			{
				dist[next] = dist[curr] + 1;
				q.push(next);
			}
		}
	}
}
int main()
{
	fin >> n >> m >> p;
	for (int i = 1; i <= m; i++)
	{
		fin >> x >> y;
		l[x].push_back(y);
	}
	Bfs(p);
	for (int i = 1; i <= n; i++)
		if (dist[i] != 2e9)
			fout << dist[i] << " ";
		else fout << "-1 ";


}
