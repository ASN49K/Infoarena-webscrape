#include <bits/stdc++.h>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 1e5 + 5;

vector <int> ad[NMAX];
int ans[NMAX];
queue <int> q;
int n, m, s;

void bfs(int origin) {
    for (int i = 1; i <= n; i++) {
        ans[i] = -1;
    }
    ans[origin] = 0;
    q.push(origin);
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (auto it : ad[node]) {
            if (ans[it] == -1) {
                ans[it] = ans[node] + 1;
                q.push(it);
            }
        }
    }
}

int main()
{
    fin >> n >> m >> s;
    for (int i = 1; i <= m; i++) {
        int a, b;
        fin >> a >> b;
        ad[a].push_back(b);
    }
    bfs(s);
    for (int i = 1; i <= n; i++) {
        fout << ans[i] << ' ';
    }
    return 0;
}
