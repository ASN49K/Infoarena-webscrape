#include <bits/stdc++.h>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, k;
vector<int> G[100001];
int viz[100001];

void dfs(int nod)
{
    viz[nod] = k;
    for(int i = 0; i < (int)G[nod].size(); i++)
        if(viz[G[nod][i]] == 0){
            dfs(G[nod][i]);
        }
}

void bfs(int nod)
{
    queue<int> q;
    q.push(nod);
    viz[nod] = k;

    while(!q.empty()){
        nod = q.front();
        q.pop();
        for(int i = 0; i < (int)G[nod].size(); i++)
            if(viz[G[nod][i]] == 0){
                q.push(G[nod][i]);
                viz[G[nod][i]] = k;
            }
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    for(int i = 1; i <= n; i++){
        if(viz[i] == 0){
           k++;
           bfs(i);
        }
    }

    fout << k;
    return 0;
}
