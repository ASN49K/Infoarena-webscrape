#include <iostream>
#include <fstream>
#include <math.h>
#include <algorithm>
#include <vector>
#include <queue>


using namespace std;

ifstream f("bfs.in");
ofstream g("bfs.out");

const int nMax = 100005;
int n, m, nodS;
int distanta[nMax];
vector < int > muchii[nMax];
queue < int > coada;

void bfs()
{
    int Nod, vecin;
    while(!coada.empty()){
        Nod = coada.front();
        coada.pop();
        for (unsigned int i = 0;i < muchii[Nod].size();i++){
            vecin = muchii[Nod][i];
            if (distanta[vecin] == -1){
                coada.push(vecin);
                distanta[vecin] = distanta[Nod] + 1;
            }
        }
    }
}

int main()
{
    f >> n >> m >> nodS;
    for (int i = 1;i <= m;i++){
        int x, y;
        f >> x >> y;
        muchii[x].push_back(y);
    }
    for (int i = 1;i <= n;i++)distanta[i] = -1;
    distanta[nodS] = 0;
    coada.push(nodS);
    bfs();
    for (int i = 1;i <= n;i++)g << distanta[i] << " ";
}