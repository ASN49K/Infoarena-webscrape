#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
const int NMAX = 1e5 + 2;
const unsigned int INF = -1;
vector<int> adj [ NMAX ];
bool viz [ NMAX ];
int dist [ NMAX ];


void bfs ( int source )
{
	queue<int> Q;
	Q.push(source);
	dist [ source ] = 0;
	viz [ source ] = 1;
	while ( !Q.empty() )
	{
		int nod = Q.front();
		Q.pop();
		viz [ nod ] = 1;
		for ( auto& to : adj [ nod ] )
		{
			if ( ! viz [ to ] )
			{
				viz [ to ] = 1;
				dist [ to ] = dist [ nod ] + 1;
				Q.push( to );
			}
		}
	}
}

int main()
{
	( void )! freopen ( "bfs.in" , "r" , stdin );
	( void )! freopen ( "bfs.out" , "w" , stdout );
    ios_base::sync_with_stdio ( false );
    cin.tie ( NULL );
    int n, m, s; cin >> n >> m >> s;
    for ( int i = 1 ; i <= m; ++ i )
    {
    	int x, y; cin >> x >> y;
    	adj [ x ].push_back( y );
    }
    for ( int i = 1 ; i <= n; ++ i )
    {
    	dist [ i ] = INF;
    }
    bfs ( s );
    for ( int i = 1 ; i <= n ; ++ i , cout << ' ' )
    {
    	cout << dist [ i ];
    }
    return 0;
}