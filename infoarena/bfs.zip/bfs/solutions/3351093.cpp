#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int Nmax = 1e5 + 5;
vector <int> vecini[Nmax];
int n, dist[Nmax];
void Bfs( int sursa )
{
    queue<int> coada;
    coada.push(sursa);
    dist[sursa] = 1;
    while ( !coada.empty() )
    {
        int fr = coada.front();
        coada.pop();

        for ( int i = 0; i < vecini[fr].size(); ++i )
        {
            if ( dist[  vecini[fr][i]  ] == 0 )
            {
                dist[  vecini[fr][i]  ] = dist[fr] + 1;
                coada.push(vecini[fr][i]);
            }
        }
    }
}
int main()
{
    int i, m, sursa;
    fin >> n >> m;
    fin >> sursa;
    for ( i = 1; i <= m; ++i )
    {
        int a, b;
        fin >> a >> b;
        vecini[a].push_back(b);
    }
    Bfs(sursa);
    for ( i = 1; i <= n; ++i )
    {
        fout << dist[i]  - 1 << " ";
    }

    return 0;
}
