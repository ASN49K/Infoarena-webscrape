#include <bits/stdc++.h>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int DIM = 1e5 + 3;
int n, m, start, distanta[DIM];
vector<int> muchii[DIM];
queue<int> q;

inline void bfs() {
    while(!q.empty()) {
        int nod = q.front();
        q.pop();
        for(int i : muchii[nod])
            if(distanta[i] == -1) q.push(i), distanta[i] = distanta[nod] + 1;
    }
}

int main()
{
    fin >> n >> m >> start;
    for(int i=1; i<=m; i++) {
        int x, y;
        fin >> x >> y;
        muchii[x].push_back(y);
    }
    for(int i=1; i<=n; i++) distanta[i] = -1;
    distanta[start] = 0, q.push(start);
    bfs();
    for(int i=1; i<=n; i++) fout << distanta[i] << " ";

    return 0;
}
