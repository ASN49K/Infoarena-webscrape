#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <deque>
#include <iomanip>
#include <vector>
#include <bitset>

#pragma GCC optimize("O3")
#define fi first
#define se second
#define pb push_back
#define pf push_front

using namespace std;
ifstream fin ("ciur.in");
ofstream fout ("ciur.out");
typedef long long ll;
const ll Nmax=1e5+5, inf=1e9+5;
using pii=pair<int, int>;

int n, m, s;
vector <int> ad[Nmax];
int vis[Nmax];

queue <pii> q;
int main()
{
    cin>>n>>m>>s;
    int a, b;
    for (int i=0; i<m; i++){
        cin>>a>>b;
        ad[a].pb(b);
    }
    q.push({s, 1});
    while (!q.empty()){
        auto crt=q.front();
        q.pop();
        vis[crt.fi]=crt.se;
        for (auto it:ad[crt.fi])
            if (vis[it]==0)
                q.push({it, crt.se+1});
    }
    for (int i=1; i<=n; i++)
        cout<<vis[i]-1<<' ';
    return 0;
}
