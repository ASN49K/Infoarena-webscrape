#include <bits/stdc++.h>
using namespace std;

vector<int> bfs(int n, int m, int s, vector<vector<int>>& adj) {
    vector<int> dist(n+1, -1);
    queue<int> q;
    dist[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (int i : adj[node]) {
            if (dist[i] == -1) {
                q.push(i);
                dist[i] = dist[node] + 1;
            }
        }
    }

    return dist;
}

int main() {
    ifstream in("bfs.in");
    ofstream out("bfs.out");

    int n, m, s;
    in >> n >> m >> s;

    vector<vector<int>> adj(n+1);
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        adj[x].push_back(y);
    }

    vector<int> dist = bfs(n, m, s, adj);

    for (int i = 1; i <= n; i++) {
        out << dist[i] << " ";
    }

    return 0;
}
