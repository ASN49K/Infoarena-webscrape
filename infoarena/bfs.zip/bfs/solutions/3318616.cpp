#include <fstream>
#include <vector>
#include <queue>
#define INF 999999
using namespace std;
ifstream f("bfs.in");
ofstream g("bfs.out");

queue<int>q;
vector<int>L[100001];
int n,m,s,d[100001];

void BFS(int s)
{
    int nod;
    for(int i=1;i<=n;i++)
        d[i]=INF;
    d[s]=0;
    q.push(s);
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(int v=0;v<L[nod].size();v++)
            if(d[L[nod][v]]>d[nod]+1)
        {
            d[L[nod][v]]=d[nod]+1;
            q.push(L[nod][v]);
        }
    }

}

int main()
{
    int x,y;
    f>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        f>>x>>y;
        L[x].push_back(y);
    }
    BFS(s);
    for(int i=1;i<=n;i++)
        if(d[i]==INF)
        g<<-1<<' ';
    else
        g<<d[i]<<' ';


    return 0;
}
