#include <iostream>
#include <vector>
#include <queue>
using namespace std;
vector<int> g[100005];
int dist[100005];
void bfs(int nod)
{
    queue<int> q;
    q.push(nod);
    while (!q.empty()) {
        int nod=q.front();
        q.pop();
        for (int i=0; i<g[nod].size(); i++) {
            int vecin=g[nod][i];
            if (dist[vecin]==-1) {
                dist[vecin]=dist[nod]+1;
                q.push(vecin);
            }
        }
    }
}
int main()
{
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);
    cin.tie(0);
    cin.sync_with_stdio(false);
    int n, m, s, a , b;
    cin>>n>>m>>s;
    for (int i=1; i<=m; i++) {
        cin>>a>>b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    for (int i=1; i<=n; i++) dist[i]=-1;
    dist[s]=0;
    bfs(s);
    for (int i=1; i<=n; i++) {
        cout<<dist[i]<<' ';
    }
    return 0;
}
