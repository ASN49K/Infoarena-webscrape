#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

const int INF = numeric_limits<int>::max();

void bfs(int N, const vector<vector<int>>& adj, int S, vector<int>& dist) {
    queue<int> q;
    dist[S] = 0;
    q.push(S);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : adj[u]) {
            if (dist[v] == INF) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
}

int main() {
    ifstream infile("bfs.in");
    ofstream outfile("bfs.out");

    if (!infile || !outfile) {
        cerr << "Error opening file" << endl;
        return 1;
    }

    int N, M, S;
    infile >> N >> M >> S;

    vector<vector<int>> adj(N + 1);
    for (int i = 0; i < M; ++i) {
        int x, y;
        infile >> x >> y;
        adj[x].push_back(y);
    }

    vector<int> dist(N + 1, INF);
    bfs(N, adj, S, dist);

    for (int i = 1; i <= N; ++i) {
        if (dist[i] == INF) {
            outfile << "-1 ";
        } else {
            outfile << dist[i] << " ";
        }
    }
    outfile << endl;

    infile.close();
    outfile.close();

    return 0;
}
