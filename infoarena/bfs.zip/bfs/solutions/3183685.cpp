#include <fstream>
#include <vector>
#include<queue>
using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");
int viz[100005];
queue<int>q;
int n,nr=1,s;
bool ok=0;
vector<int>v[2000009];
void bfs(int nod)
{
    viz[nod]=1;
    int k;
   q.push(nod);
   while(!q.empty())
   {
ok=0;
       k=q.front();
       for(int i=0;i<v[k].size();i++)
       {
            if(!viz[v[k][i]])
            {
                viz[v[k][i]]=nr;
                q.push(v[k][i]);
                ok=1;
            }


       }
       if(ok==1)
                nr++;
       q.pop();

   }
}
int main()
{
    int m,x,y;
    fin>>n>>m>>s;



    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);


    }
bfs(s);

  for(int i=1;i<=n;i++)
  {
     if(viz[i]==0)
        viz[i]=-1;
  }
  viz[s]=0;
  for(int i=1;i<=n;i++)
    fout<<viz[i]<<" ";

}
