#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector < int > v[100005];
int distanta [100005];
queue < int > coada;

void bfs(){
    int nod, vecin;
    while(!coada.empty())
    {
        nod = coada.front();
        coada.pop();
        for(int i = 0; i < v[nod].size(); i++){
            vecin = v[nod][i];
            if(distanta[vecin] == -1){
                coada.push(vecin);
                distanta[vecin] = distanta[nod] + 1;
            }
        }
    }
}

int main()
{
    int n, m, nods;
    fin >> n >> m >> nods;
    for(int i = 0; i < m; i++){
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
    }

    for(int i = 1; i <= n; i++){
        distanta[i] = -1;
    }
    distanta[nods] = 0;
    coada.push(nods);

    bfs();

    for(int i = 1; i <= n; i++)
        fout << distanta[i] << " ";

    return 0;
}
