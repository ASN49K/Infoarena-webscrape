#include <iostream>
#include <vector>
#include <fstream>
#include <queue>

using namespace std;
int main() {

    ifstream fin("bfs.in");
    ofstream fout("bfs.out");


    int n, m, start;
    fin >> n >> m >> start;
    vector<vector<int>> vecin(n);
    start--;
    for (int muchie = 0; muchie < m; muchie++) {
        int x, y;
        fin >> x >> y;
        x--, y--;
        vecin[x].push_back(y);
    }

    vector<int> dist(n, -1);
    vector<bool> viz(n, false);

    dist[start] = 0;
    viz[start] = true;

    // BFS
    queue<int> Q;
    Q.push(start);

    while (!Q.empty()) {
        int node = Q.front();
        Q.pop();
        for (int v: vecin[node]) {
            if (!viz[v]) {
                Q.push(v);
                dist[v] = dist[node] + 1;
                viz[node] = true;
            }
        }
    }
    // END BFS

    for (int d : dist) {
        fout << d << " ";
    }
    fin.close();
    fout.close();
    return 0;
}