#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("bfs.in");
ofstream fout ("bfs.out");

void CreareLista(int n , int m, vector<vector<int>> &lista, bool orientat)
{
    for (int i = 0; i < m ; i ++)
    {
        int x, y;
        fin >> x >> y;
        if (x != y)
            lista[x].push_back(y);
        if (orientat == false)
            lista[y].push_back(x);
    }
}

void AfiseazaLista(vector<vector<int>> lista)
{
    for (int i = 1; i < lista.size(); i ++)
    {
        cout << i << ": ";
        for (int j = 0; j < lista[i].size(); j ++)
            cout << lista[i][j] << " ";
        cout << endl;
    }
}

void BFS(int nod, vector<vector<int>> listaAdiacenta, vector<int> &lungimeDrum)
{
    queue<int> s;
    s.push(nod);
    while(!s.empty())
    {
        int n = s.front();
        s.pop();
        for (int x : listaAdiacenta[n]){
            if (lungimeDrum[x] == 0)
                lungimeDrum[x] = lungimeDrum[n] + 1, s.push(x);
        }
    }
    
}

int main()
{
    int n, m, s;
    fin >> n >> m >> s;
    vector<int> lungimeDrum(n + 1);
    vector<vector<int>> listaAdiacenta(n + 1);
    
    CreareLista(n, m, listaAdiacenta, true);

    BFS(s, listaAdiacenta, lungimeDrum);

    for (int i = 1; i < lungimeDrum.size(); i ++)
        if (i == s)
            fout << 0 << " ";
        else if (lungimeDrum[i] == 0)
            fout << -1 << " ";
        else
            fout << lungimeDrum[i] << " ";
    fout << endl;
    return 0;
}