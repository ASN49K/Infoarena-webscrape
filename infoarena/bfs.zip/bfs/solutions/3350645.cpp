#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main() {
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    int numar_noduri, numar_arce, nod_target;
    cin >> numar_noduri >> numar_arce >> nod_target;
    
    // citim arcele si construim matricea de legatura
    vector<vector<int>> matrice_legatura(numar_noduri + 1);
    while (numar_arce--) {
        int baza, target;
        cin >> baza >> target;
        matrice_legatura[baza].push_back(target);
    }

    // parcurgere noduri de la target pentru a afla distanta
    vector<int> distante(numar_noduri + 1, -1);
    distante[nod_target] = 0;
    queue<int> noduri_de_parcurs;
    noduri_de_parcurs.push(nod_target);
    while (noduri_de_parcurs.size() != 0) {
        int nod_actual = noduri_de_parcurs.front();
        for (int nod_vecin : matrice_legatura[nod_actual]) {
            if (distante[nod_vecin] == -1) {
                distante[nod_vecin] = distante[nod_actual] + 1;
                noduri_de_parcurs.push(nod_vecin);
            }
        }
        noduri_de_parcurs.pop();
    }
    for (int i = 1; i <= numar_noduri; ++i) {
        cout << distante[i] << " ";
    }
    cout << endl;
    return 0;
}