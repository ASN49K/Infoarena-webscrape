#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int numNodes, numEdges, startNode;
vector<vector<int>> graph;

void ReadData() {
    cin >> numNodes >> numEdges >> startNode;
    startNode--; // convert to 0-based index

    graph.assign(numNodes, vector<int>());

    for (int i = 0; i < numEdges; i++) {
        int u, v;
        cin >> u >> v;
        u--; v--; // convert to 0-based
        graph[u].push_back(v);
        // If the graph is undirected, also add:
        // graph[v].push_back(u);
    }
}

void Solve() {
    vector<int> result(numNodes, -1); // distance from startNode
    vector<bool> visited(numNodes, false);

    queue<int> q;
    q.push(startNode);
    visited[startNode] = true;
    result[startNode] = 0;

    while (!q.empty()) {
        int node = q.front(); q.pop();

        for (int neighbour : graph[node]) {
            if (!visited[neighbour]) {
                visited[neighbour] = true;
                result[neighbour] = result[node] + 1;
                q.push(neighbour);
            }
        }
    }

    for (int val : result) {
        cout << val << " ";
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    int t = 1;
    while (t--) {
        ReadData();
        Solve();
    }

    return 0;
}