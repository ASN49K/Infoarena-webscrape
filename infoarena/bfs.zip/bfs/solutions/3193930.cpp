#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int const NMAX = 100005;

vector <int> G[NMAX];
queue <int> q;

int n,m,s;
int x,y;

int dad[NMAX];
int dist[NMAX];
bool viz[NMAX];

void BFS()
{
    q.push(s);
    dad[s] = 0;
    dist[s]= 0;
    viz[s]=1;
    while(!q.empty())
    {
        int nodc = q.front();
        q.pop();
        for(int nbr: G[nodc])
        {
            if(!viz[nbr])
            {
                q.push(nbr);
                viz[nbr]=1;
                dist[nbr]=dist[nodc]+1;
                dad[nbr]=nodc;
            }
        }
    }
    
}

int main()
{
    fin>>n>>m>>s;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
    BFS();
    for(int i=1;i<=n;i++)
    {
        if(i != s && dist[i] == 0)
        {
            fout << -1 << " ";
        }else{
            fout<<dist[i]<<" ";
        }
    }
}
