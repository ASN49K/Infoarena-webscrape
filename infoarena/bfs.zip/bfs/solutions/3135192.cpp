#include <bits/stdc++.h>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

const int NMAX = 1e5;
bool viz[NMAX + 5];
int dist[NMAX + 5];

vector<int> adj[NMAX + 5];

void bfs(int start){
    queue<int> q;
    q.push(start);
    viz[start] = true;
    dist[start] = 0;
    while(!q.empty()){
        int nod = q.front();
        q.pop();
        for(auto it:adj[nod]){
            if(!viz[it]){
                viz[it] = true;
                dist[it] = dist[nod] + 1;
                q.push(it);
            }
        }
    }
}

int main(){
    int n, m, start;
    fin>>n>>m>>start;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin>>x>>y;
        adj[x].push_back(y);
    }
    bfs(start);
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            fout<<-1<<" ";
            continue;
        }
        fout<<dist[i]<<" ";
    }
    return 0;   
}