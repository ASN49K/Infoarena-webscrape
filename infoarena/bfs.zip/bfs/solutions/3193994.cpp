#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");

vector <int> G[1000005];
int n, m, s;
int vizitat[1000005], dist[1000005];

void read()
{
    in >> n >> m >> s;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        G[x].push_back(y);
    }
}

queue <int> q;

void bfs(int nod)
{
    q.push(nod);
    vizitat[nod] = 1;
    while(!q.empty())
    {
        int nod_curent = q.front();
        q.pop();
        for(int vecin : G[nod_curent])
        {
            if(!vizitat[vecin])
            {
                q.push(vecin);
                dist[vecin] = dist[nod_curent] + 1;
                vizitat[vecin] = 1;
            }
        }
    }
}

int main()
{
    read();
    bfs(s);
    for(int i = 1; i <= n; i++)
    {
        if(vizitat[i] == 0)
        {
            dist[i] = -1;
        }
        out << dist[i] << " ";
    }
    return 0;
}