#include<bits/stdc++.h>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int n, m, root, x, y;
vector<int> G[100005];
vector<int> D;

int main(){
    fin >> n >> m >> root;

    for(;m--;){
        fin >> x >> y;
        G[x].emplace_back(y);
    }

    D.resize(n + 1, 1e9);
    D[root] = 0;
    queue<int> Q;
    Q.push(root);

    while(!Q.empty()){
        int node = Q.front();
        Q.pop();

        for(int x : G[node])
        if(D[x] > D[node] + 1){
            D[x] = D[node] + 1;
            Q.push(x);
        }
    }

    for(int i = 1; i <= n; ++i)
        if(D[i] == (int)1e9)
            fout << -1 << ' ';
        else
            fout << i << ' ';
}
