#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1000004;
int n, m, s;

vector<int> adj[NMAX];
int dist[NMAX];
int main()
{
    int i;
    freopen("bfs.in", "r", stdin);
    freopen("bfs.out", "w", stdout);

    scanf("%d %d %d", &n, &m, &s);

    for (i = 0; i < m; i++)
    {
        int x, y;
        scanf("%d %d", &x, &y);
        adj[x].push_back(y);
    }
    memset(dist, -1, sizeof(dist));
    queue<int> q;
    q.push(s);
    dist[s] = 1;
    while (!q.empty())
    {
        int nod_curent = q.front();
        q.pop();
        for (i = 0; i < adj[nod_curent].size(); i++)
        {
            if (dist[adj[nod_curent][i]] == -1)
            {
                dist[adj[nod_curent][i]] = dist[nod_curent] + 1;
                q.push(adj[nod_curent][i]);
            }
        }
    }
    for (i = 1; i <= n; i++)
    {
        if (dist[i] != -1)
            printf("%d ", dist[i] - 1);
        else
            printf("%d ", dist[i]);
    }
    return 0;
}
