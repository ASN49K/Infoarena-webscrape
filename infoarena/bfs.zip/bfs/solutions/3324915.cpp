#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
vector<vector<int>> v(100100);
int w[100100];
int d[100100];
int n,m,s;
void BFS(int a){
    queue<int> q;
    q.push(a);
    w[a]=1;

    while(!q.empty()){
    int r=q.front();
    for(auto e : v[r]){
        if(!w[e]){
        d[e]=d[r]+1;
        q.push(e);
        }
    }
    w[r]=1;
    q.pop();
    }

}
int main(){
    int a,b;
    fin>>n>>m>>s;
    for(int i=1; i<=m; i++){
        fin>>a>>b;
        if(a!=b && find(v[a].begin(),v[a].end(),b)==v[a].end() )
        v[a].push_back(b);
    }
    BFS(s);
    for(int i=1; i<=n; i++){
            if(i==s)
            fout<<0<<" ";
            else if(w[i])
            fout<<d[i]<<" ";
            else
            fout<<-1<<" ";
    }
    return 0;
}
