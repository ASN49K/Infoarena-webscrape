#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;
ifstream fin ("bfs.in");
ofstream fout("bfs.out");

int n;
int start;

//vector<int> A;
//am declarat un vector din STL cu 0 elem de tip int numit A

vector<int> A[NMAX];
//am declarat un vector cu NMAX elem
//de tip STL cu 0 elem de tip int numit A
int viz[NMAX]; //viz[x]=0 daca NU a fost vizitat
int C[NMAX], inc, sf;

void citire();
void bfs (int x);

int main()
{
    int i;
    citire();
    bfs(start);
    for (i=1; i<=n; i++) fout<<viz[i]-1<<' ';
    fout<<'\n';
    fin.close(); fout.close(); return 0;
}

void citire()
{
    int i, m, x, y;
    fin>>n>>m>>start;
    for (i=0; i<m; i++)
    {
        fin>>x>>y; //arc de la x la y
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
    }
}

void bfs (int x)
{
    int i;
    C[0]=x; inc=sf=0; //initializez coada cu start
    viz[x]=1; //initializez vf de start
    while (inc<=sf)
    {
        x=C[inc++];
        //parcurg vecinii lui x
        for (i=0; i<A[x].size(); i++)
            if (viz[A[x][i]]==0)
            {
                viz[A[x][i]]=viz[x]+1;
                C[++sf]=A[x][i];
            }
    }
}
