#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");

vector<int> adj[100000];
int dist[100000];



int main(){
    int n, m, s;
    fin >> n >> m >> s;

    for(int i = 0; i < m; i++){
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);

    }

    queue<int> q;
    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
    }
    dist[s] = 0;
    q.push(s);
    while(!q.empty()){
        int nod_curr = q.front();
        q.pop();

        for(auto vecin: adj[nod_curr]){
            if(dist[vecin] == -1){
                dist[vecin] = dist[nod_curr] + 1;
                q.push(vecin);
            }
        }
    }

    for(int i = 1; i <= n; i++)
        fout << dist[i] << " ";

    fin.close();
    fout.close();
    return 0;

}