#include <fstream>
#include <vector>

using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");

int q[100001],pas[100001];
bool viz[100001];
vector<vector<int>>mat;

int main()
{
    int n,m,S,x,y;
    fin>>n>>m>>S;

    mat.resize(n+1);

    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        mat[x].push_back(y);
    }

    viz[S]=true;
    q[1]=S;
    int inc=1,sf=1;

    while(inc<=sf)
    {
        for(int i=0;i<mat[q[inc]].size();i++)
            if(viz[mat[q[inc]][i]]==false)
            {
                int vec=mat[q[inc]][i];
                viz[vec]=true;
                q[++sf]=vec;

                pas[vec]=pas[q[inc]]+1;
            }
        inc++;
    }
    for(int i=1;i<=n;i++)
        if(pas[i]==0&&i!=S)
            fout<<-1<<' ';
        else
            fout<<pas[i]<<' ';
}
