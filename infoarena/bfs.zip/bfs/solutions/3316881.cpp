#include <bits/stdc++.h>
#include <queue>
#include <fstream>
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");
/*
vector<int> L[1000001];
vector<bool> viz(100001, false);

void dfs(int nod, int cnt)
{
    viz[nod] = true;
    for(auto vecin: L[nod])
    {
        if(!viz[vecin])
        {
            dfs(vecin, cnt);
        }
    }
}

int main()
{
    int n, m, cnt = 0;

    fin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }

    for(int i = 1; i <= n; i ++)
    {
        sort(L[i].begin(), L[i].end());
        L[i].erase(unique(L[i].begin(), L[i].end()), L[i].end());
    }

    for(int i = 1; i <= n; i ++)
    {
        if(!viz[i])
            dfs(i, ++cnt);
    }

    fout << cnt;

    return 0;
}
    */

queue<pair<int, int>> q;
vector<int> L[1000001];
vector<bool> viz(100001, false);
vector<int> cost(100001, -1);

void bfs(queue<pair<int, int>> &q)
{
    while(!q.empty())
    {
        int nod = q.front().first;
        int cst = q.front().second;
        viz[nod] = true;
        q.pop();

        for(auto vecin: L[nod])
        {
            if(!viz[vecin])
            {
                viz[vecin] = true;
                cost[vecin] = cst + 1;
                q.push({vecin, cst + 1});
            }
        }
    }
}

int main()
{
    int n, m, s;

    fin >> n >> m >> s; 

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
    }

    for(int i = 1; i <= n; i ++)
    {
        sort(L[i].begin(), L[i].end());
        L[i].erase(unique(L[i].begin(), L[i].end()), L[i].end());
    }

    q.push({s, 0});

    viz[s] = true;
    cost[s] = 0;

    bfs(q);

    for(int i = 1; i <= n; i ++)
        fout << cost[i] << ' ';

    return 0;
}