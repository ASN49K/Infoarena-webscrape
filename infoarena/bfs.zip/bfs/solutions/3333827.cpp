#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
int n,m,start;
int viz[NMAX],C[NMAX];
vector<int>A[NMAX];

void citire();
void bfs(int x);

int main()
{
    int i;
    citire();
    bfs(start);
    for(i=1;i<=n;i++) fout<<viz[i]-1<<' ';
    return 0;
}

void citire()
{
    int i,x,y;
    fin>>n>>m>>start;
    for(i=0;i<m;i++)
    {
        fin>>x>>y;
        A[x].push_back(y);
    }
}

void bfs(int x)
//parcurg graful incepand din varful x
{
    int i,inc,sf;
    C[0]=x; inc=sf=0; //initializez coada cu vf de start
    viz[x]=1;
    while(inc<=sf)
    {
        x=C[inc++];
        //parcurg vecinii lui x
        for(i=0;i<A[x].size();i++)
            if(!viz[A[x][i]])
            {
                viz[A[x][i]]=1+viz[x];
                C[++sf]=A[x][i];
            }
    }
}
