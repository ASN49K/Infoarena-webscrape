#include <bits/stdc++.h>
using namespace std;

ifstream in("bfs.in");
ofstream out("bfs.out");
vector<int> a[100010];
int v[100010], s;
queue<int> q;
void parcurgere()
{
    int d;
    while (!q.empty()) {
        d = q.front();
        q.pop();
        for (auto b : a[d]) {
            if (v[b] == -1) {
                q.push(b);
                v[b] = v[d] + 1;
            }
        }
    }
}

int main()
{
    int i, j, l, n, m, x, y;
    in >> n >> m >> s;
    for (i = 1; i <= m; i++) {
        in >> x >> y;
        a[x].push_back(y);
    }
    for (i = 1; i <= n; i++) {
        sort(a[i].begin(), a[i].end());
    }
    for (i = 1; i <= n; i++)   //sau memeset(v,-1,sizeof(v));
        v[i] = -1;
    q.push(s);
    v[s] = 0;
    parcurgere();
    for (int i = 1; i <= n; i++)
        out << v[i] << ' ';

}