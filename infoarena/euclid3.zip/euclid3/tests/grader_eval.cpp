#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int NR_T;

void error(int points, char *msg)
{
	fprintf(stderr, "%s", msg);
	printf("%d", points);
	exit(0);
}

int T, A, B, C;
long long outX, outY, okX, okY;
char tmp[1024];

int main()
{
	FILE *fin = fopen("euclid3.in", "rt");
	if (!fin) error(0, "Missing IN file!");

	FILE *fok = fopen("euclid3.ok", "rt");
	if (!fok) error(0, "Missing OK file!");

	fscanf(fok, "%s %d", tmp, &NR_T); NR_T--;
	if (strcmp( tmp, "TEST" ) != 0 || NR_T < 0 || NR_T >= 10)
		error(0, "Invalid OK file!");

	FILE *fout = fopen("euclid3.out", "rt");
	if (!fout) error(0, "Missing output file!");

	fscanf(fin, "%d", &T);
	for (int i = 0; i < T; i++)
	{
		fscanf(fin, "%d %d %d", &A, &B, &C);

		fscanf(fout, "%lld %lld", &outX, &outY);
		fscanf(fok, "%lld %lld", &okX, &okY);
		int ok = (okX != 0 || okY != 0);

		if (!ok)
		{
			if (outX != 0 || outY != 0)
			{
				sprintf(tmp, "Ecuatia %d (%d %d %d) nu are solutie, dar programul tau a afisat %lld %lld", i + 1, A, B, C, outX, outY);
				error(0, tmp);
			}
			continue;
		}

		if (abs(okX) > 2000000000 || abs(okY) > 2000000000 || A * okX + B * okY != C)
			error(0, "Invalid OK file!");

		if (abs(outX) > 2000000000 || abs(outY) > 2000000000 || A * outX + B * outY != C)
		{
			sprintf(tmp, "Solutie gresita la ecuatia %d (%d %d %d)", i + 1, A, B, C);
			error(0, tmp);
		}
	}

	char c;
	if (fscanf(fout, " %c ", &c) != EOF)			//caractere invalide ( non-whitespace )
		error(0, "Ai afisat caractere in plus");

	error( 10, "Raspuns Corect" );

	return 0;
}

