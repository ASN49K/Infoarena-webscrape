#include<iostream>
#include<fstream>

using namespace std;

ifstream fin("rmq.in");
ofstream fout("rmq.out");

void euclid(int a,int b,int &d,int &x,int &y)
{
   if(b==0)
   {
      d = a;
      x = 1;
      y = 0;
   }
   else
   {
      int x0,y0;
      euclid(b,a%b,d,x0,y0);
      x = y0;
      y = x0 - (a/b) * y0;

   }
}

int main() {

   int n;
   fin>>n;

   for(int i=1;i<=n;i++)
   {
      int a,b,c,d,x,y;
      fin>>a>>b>>c;

      euclid(a,b,d,x,y);
      if(c%d!=0)
         fout<<"0 0\n";
      else
      {
         fout<<a*(c/d)<<" "<<b*(c/d)<<'\n';
      }
   }

}
