using namespace std;
#include<cstdio>
 void euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}
int main()
{
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	int a,b,T,d,x,y;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d %d",&a,&b,&d);
		euclid(a,b,&d,&x,&y);
		printf("%d %d\n",x,y);
	}
	return 0;
}
