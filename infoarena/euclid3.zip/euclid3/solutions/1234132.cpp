#include <fstream>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int cmmdc(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int X,Y,D;
    D=cmmdc(b,a%b,X,Y);
    x=Y;
    y=X-(a/b)*Y;
    return D;
}
int t,a,b,c,d,x,y;
int main()
{
    fin>>t;
    for(;t;t--)
    {
        fin>>a>>b>>c;
        d=cmmdc(a,b,x,y);
        if(c%d)
        {
            fout<<"0 0\n";
        }
        else fout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
    }

    return 0;
}
