#include <cstdio>

using namespace std;



void euclidex(int a,int b,int &k,int &l,int &d)
{
    if(b==0)
    {
        l=1;
        k=0;
        d=a;
        return;
    }
    int k1,l1,d1;
    euclidex(b,a%b,k1,l1,d1);
    l=k1;
    d=d1;
    k=l1-(a/b)*k1;
}


int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);

    int n,a,b,c,k,l,d;

    scanf("%d",&n);

    for(int i=1;i<=n;i++)
    {
        scanf("%d %d %d",&a,&b,&c);
        euclidex(a,b,k,l,d);
        int x=0,y=0;
        if(c%d == 0)
        {
            x=l*(c/d);
            y=k*(c/d);
        }
        printf("%d %d\n",x,y);
    }

    return 0;
}
