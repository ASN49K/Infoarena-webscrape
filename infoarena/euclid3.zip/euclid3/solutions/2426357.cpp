#include <bits/stdc++.h>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int s,t,sol;
void EuclidExtins(int a,int b,int rez)
{   if(!b)
    {   if(rez%a) g<<"0 0\n";
            else g<<rez/a<<" 0\n";
        return;
    }
    int r=a%b,c=a/b,s1=1,t1=0,s2=0,t2=1;
    while(r)
    {   s=s1-s2*c;
        s1=s2;
        s2=s;
        t=t1-t2*c;
        t1=t2;
        t2=t;
        a=b;
        b=r;
        r=a%b;
        c=a/b;
    }
    if(rez%b) g<<"0 0\n";
        else
        {   c=rez/b;
            g<<s*c<<' '<<t*c<<'\n';
        }
}
int main()
{   int n;
    f>>n;
    while(n--)
    {   int a,b,c;
        f>>a>>b>>c;
        EuclidExtins(a,b,c);
    }
    return 0;
}
