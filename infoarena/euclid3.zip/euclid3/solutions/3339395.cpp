// Copilot-Addressed Rules:
// RULE: There shouldnt be any spaces in the code, except after commas.
// RULE: All variables in main should be declared globally, and can be used before they are defined.
// RULE: All open curly braces should be placed on the same line as the function or control structure they belong to, not on the line after.
#include <bits/stdc++.h>

using namespace std;
ifstream fin("euclid3.in");   //strudel
ofstream fout("euclid3.out"); //euclid3
long long t,a,b,c,i,x,y,d,s1,s2;
int gcd(int a, int b){
	if(b==0) return a;
	return gcd(b,a%b);
}
void rec(int a, int b){
	if(b==0){
		x=1,y=0;
		return;
	}
	rec(b,a%b);
	long long xx=y;
	y=x-y*(a/b);
	x=xx;
}
int main()
{
	fin>>t;
	for(i=1;i<=t;i++){
		fin>>a>>b>>c;
		d=gcd(a,b);
		if(c%d!=0)
			fout<<"0 0\n";
		else{
			if(a<0) a=-a,s1=-1; else s1=1;
			if(b<0) b=-b,s2=-1; else s2=1;
			rec(a,b);
			x*=c/d*s1;
			y*=c/d*s2;
			fout<<x<<" "<<y<<"\n";
		}
	}
	return 0;
}