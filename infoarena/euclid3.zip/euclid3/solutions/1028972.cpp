#include<fstream.h>
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
void cmmdc(int a,int b,int &d,int &x,int &y)
{
    if(!b)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
    int x0,y0;
    cmmdc(b,a%b,d,x0,y0);
     
    x=y0;
    y= x0 - (a/b) * y0;  
    }
 
}
void citire(int &a, int &b, int &c)
{
    cin>>a>>b>>c;
}
 
void rez(int a, int b, int c)
{
    int x,y,d;
    cmmdc(a,b,d,x,y);
 
    if(c%d)
        cout<<"Forma generala a solutiilor este de forma (x + k * b/di, y - k * a/di), oricare k intreg respecta ecuatia.";
    else
        cout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
}
 
int main()
{
    int a,b,c;
        citire(a,b,c);
        rez(a,b,c);
    return 0;
}