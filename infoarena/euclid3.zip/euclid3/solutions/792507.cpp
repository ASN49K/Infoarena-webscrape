#include <cstdio>

using namespace std;
int n , a , b , c;
int euclid_extins(int a,int b , int &x , int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        return a ;
    }
    int x0 , y0 ;
    int factorC = euclid_extins(b , a%b , x0 , y0);
    x = y0;
    y = x0 - (a/b)*y0;
    return factorC;
}
void solve(int a , int b , int c)
{
    int x ,y;
    int factorComun = euclid_extins(a,b,x,y);
    if ( c % factorComun)
        printf("0 0\n");
    else
        printf("%d %d\n" , x*(c/factorComun) , y*(c/factorComun) );
}
void citire()
{
    freopen("euclid3.in" , "r" , stdin);
    freopen("euclid3.out", "w" ,stdout);
    scanf("%d",&n);
    for(int i = 0 ; i < n ; ++i)
    {
        scanf("%d %d %d" , &a, &b , &c);
        solve (a,b,c);
    }
}
int main()
{

    citire();

    return 0;
}
