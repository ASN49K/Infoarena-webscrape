#include <fstream>
#include <iostream>
#define ll long long
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

//auto p;
pair<ll,ll>euclid_extended(ll a,ll b)
///perechi de a si b, pt fiecare iteratie din algoritmul determinarii cmmdc
{
    if(b==0)
        return {1,0};
    auto p=euclid_extended(b,a%b);
    return {p.second,p.first-(a/b)*p.second};

}

int main()
{
    ll a,b,c,d,t;
    fin>>t;
    for(int i=0; i<t; i++)
    {
        fin>>a>>b>>c;

        auto coef=euclid_extended(a,b);
        //cout<<coef.first<<" "<<coef.second<<"\n";
        ll d=a*coef.first+b*coef.second;
        if(c%d!=0)
            fout<<"0 0\n";
        else
            fout<<coef.first*(c/d)<<" "<<coef.second*(c/d)<<"\n";
    }
    return 0;
}
