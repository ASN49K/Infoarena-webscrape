#include <cstdio>
using namespace std;

int a,b;

void Euclid(int a,int &x,int b,int &y,int &d){

    if (b==0){d=a;x=1;y=0;}
    else {
         int x0,y0;
         Euclid(b,x0,a%b,y0,d);
         x=y0;
         y=x0-(a/b)*y0;
         }
}

void Solve(){

    int n,x,y,d,c;

    scanf("%d",&n);
    while (n--){
        scanf("%d%d%d",&a,&b,&c);
        Euclid(a,x,b,y,d);
        if (c%d) printf("0 0\n");
        else printf("%d %d\n",x*(c/d),y*(c/d));

        }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    Solve();
    return 0;
}
