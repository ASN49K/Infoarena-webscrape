#include <fstream>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
long long euclid(long long a, long long b, long long *x, long long *y)
{
    if( b == 0){
        *x = 1;
        *y =0;
        return a;
    }
    else {
        long long x0, y0,cmmdc;
        cmmdc = euclid(b,a%b,&x0,&y0);
        *x = y0;
        *y = x0 - (a/b)*y0;
        return cmmdc;
    }
}
int main()
{
    int t, i;
    long long a,b,c,x,y,d;
    fin >> t;
    for( i = 1; i <= t; i++)
    {
        fin >> a >> b >>c;
        d = euclid(a,b,&x,&y);
        fout<< x *(c/d)<< " " << y*(c/d) << "\n" ;
    }

    return 0;
}
