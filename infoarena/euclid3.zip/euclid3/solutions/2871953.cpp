#include <iostream>
#include <cmath>
using namespace std;
int v[100],n;
int pali(int x)
{
    int aux=x,inv=0;
    while(x)
    {
        inv=inv*10+x%10;
        x=x/10;
    }
    if(aux==inv) return 1;
    else return 0;
}
int palindrom(int p,int u)
{
    int m,x1,x2;
    if(p==u)
        return pali(v[p]);
    else
    {
        m=(p+u)/2;
        x1=palindrom(p,m);
        x2=palindrom(m+1,u);
        return x1+x2;
    }
}
int sumapali(int p,int u)
{
    int m,x1,x2;
    if(p==u && pali(v[p])==1) return v[p];
    if(p==u && pali(v[p])==0) return 0;
    m=(p+u)/2;
    x1=sumapali(p,m);
    x2=sumapali(m+1,u);
    return x1+x2;

}
int cpare(int x)
{
    while(x!=0)
    {
        if(x%2==1) return 0;
        x=x/10;
    }
    return 1;
}
int scifpare(int p,int u)
{
    int m,x1,x2;
    if(p==u && cpare(v[p])==1) return v[p];
    if(p==u && cpare(v[p])==0) return 0;
    m=(p+u)/2;
    x1=scifpare(p,m);
    x2=scifpare(m+1,u);
    return x1+x2;

}
int nrcifpare(int p,int u)
{
    int m,x1,x2;
    if(p==u) return cpare(v[p]);
    else
    {
        m=(p+u)/2;
        x1=nrcifpare(p,m);
        x2=nrcifpare(m+1,u);
        return x1+x2;
    }

}
int prodcif(int x)
{
    int p=1;
    while(x)
    {
        p=p*(x%10);
        x=x/10;
    }
    if(p%2==0) return 1;//par
    else return 0;
}
int pcpar(int p,int u)
{
    int m,x1,x2;
    if(p==u) return prodcif(v[p]);
    else
    {
        m=(p+u)/2;
        x1=pcpar(p,m);
        x2=pcpar(m+1,u);
        return x1+x2;
    }
}
int primsaunu(int x)
{
    int nr=0;
    for(int d=1; d<=x; d++)
        if(x%d==0)
            nr++;
    if(nr==2) return 1;
    else return 0;
}
int prim(int p,int u) //numar cate elem prime sunt in vector
{
    int m,x1,x2;
    if(p==u)
        return primsaunu(v[p]);
    else
    {
        m=(p+u)/2;
        x1=prim(p,m);
        x2=prim(m+1,u);
        return x1+x2;
    }
}
int ocifrapara(int x)
{
    while(x!=0)
    {
        if(x%2==0) return 1;
        x=x/10;
    }
    return 0;
}
int scifpar1(int p,int u)
{
    int m,x1,x2;
    if(p==u && ocifrapara(v[p])==1)
        return v[p];
    if(p==u && ocifrapara(v[p])==0)
        return 0;
    else
    {
        m=(p+u)/2;
        x1=scifpar1(p,m);
        x2=scifpar1(m+1,u);
        return x1+x2;
    }

}
int ordcresc(int p,int u)
{
    int m,x1,x2;
    if(p==u) return 1;
    /*else
    {
        if(v[p]<=v[p+1]) return ordcresc(p+1,u);
        if(v[p]>v[p+1]) return 0;
    }*/
    else
    {
        m=(p+u)/2;
        x1=ordcresc(p,m);
        x2=ordcresc(m+1,u);
        if(x1==1 && x2==1 && v[m]<=v[m+1]) return 1;
        else return 0;

    }
}
int cmmdcxy(int x,int y)
{
    while(x!=y)
        if(x>y)
            x=x-y;
        else
            y=y-x;
    return x;

}
int cmmdc(int p,int u)
{
    int m,x1,x2;
    if(p==u)
        return v[p];
    else
    {
        m=(p+u)/2;
        x1=cmmdc(p,m);
        x2=cmmdc(m+1,u);
        return cmmdcxy(x1,x2);
    }

}
int perfect(int x)
{
    int s=0,d;
    for(d=1;d<x;d++)
    {
        if(x%d==0)
            s=s+d;
    }
    if(x==s) return 1;
    else return 0;
}
int sperfecte(int p,int u)
{
    int m,x1,x2;
    if(p==u && perfect(v[p])==1) return v[p];
    if(p==u && perfect(v[p])==0) return 0;
    m=(p+u)/2;
    x1=sperfecte(p,m);
    x2=sperfecte(m+1,u);
    return x1+x2;
}
int pp(int x)
{
    if(sqrt(x)==(int)sqrt(x)) return 1;
    else return 0;
}
int sumapp(int p,int u)
{
    int m,x1,x2;
    if(p==u && pp(v[p])==1) return v[p];
    if(p==u && pp(v[p])==0) return 0;
    else
    {
        m=(p+u)/2;
        x1=sumapp(p,m);
        x2=sumapp(m+1,u);
        return x1+x2;
    }
}

void cauta(int p,int u,int x)
{
    int m;
    if(p==u && v[p]==x) cout<<p<<" ";
    if(p==u) return;
    else
    {
        m=(p+u)/2;
        cauta(p,m,x);
        cauta(m+1,u,x);
    }
}
int cifdistincte(int x)
{
    int c[10],cif,ok=1,i;
    for(i=0;i<=9;i++) c[i]=0;
    while(x)
    {
        cif=x%10;
        c[cif]++;
        if(c[cif]>1) ok=0;
        x=x/10;
    }
    if(ok==1) return 1; //are cif distincte
    else return 0;
}
void pozcdist(int p,int u)
{
    int m;
    if(p==u && cifdistincte(v[p])==1) cout<<p<<" ";
    if(p==u) return;
    else
    {
        m=(p+u)/2;
        pozcdist(p,m);
        pozcdist(m+1,u);
    }
}

int superprim(int x)
{
    while(x)
    {
        if(primsaunu(x)==0) return 0;
            x=x/10;
    }
    return 1;
}
int nrsuperprime(int p,int u)
{
    int m,x1,x2;
    if(p==u && superprim(v[p])==1) return 1;
    if(p==u && superprim(v[p])==0) return 0;
    else
    {
        m=(p+u)/2;
        x1=nrsuperprime(p,m);
        x2=nrsuperprime(m+1,u);
        return x1+x2;
    }
}
int maxim(int p,int u)
{
    int m,x1,x2;
    if(p==u)
        return v[p];
    else
    {
        m=(p+u)/2;
        x1=maxim(p,m);
        x2=maxim(m+1,u);
        if (x1>x2) return x1;
        else return x2;
    }

}
int primacifra(int x)
{
    while(x>9) x=x/10;
    return x;
}
int prodcif(int p,int u)
{
    int m,x1,x2;
    if(p==u)
        return primacifra(v[p]);
    else
    {
        m=(p+u)/2;
        x1=prodcif(p,m);
        x2=prodcif(m+1,u);
        return x1*x2;
    }

}
int simetric(int p,int u)
{
    int m;
    if(p==u) return 1;
    else
    {
        m=(p+u)/2;
        if((u-p+1)%2==1)
        {if(v[m-1]==v[m+1]) return 1;
        else return 0;}
        if((u-p+1)%2==0)
        {if(v[m]==v[m+1]) return 1;
        else return 0;}
        simetric(p,m);
        simetric(m+1,u);
    }
}
int main()
{
    int i,c;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    cout<<"Numarul componentelor palindrom:"<<palindrom(1,n)<<endl;
    cout<<"Suma elementelor palindrom:"<<sumapali(1,n)<<endl;
    cout<<"Suma elementelor care au toate cifrele pare:"<<scifpare(1,n)<<endl;
    cout<<"Numarul de elemente cu toate cifrele pare:"<<nrcifpare(1,n)<<endl;
    cout<<"Numarul de elemente care au produsul cifrelor un nr par:"<<pcpar(1,n)<<endl;
    cout<<"Exista macar un numar prim?";
    if(prim(1,n)) cout<<" DA"<<endl;
    else cout<<" NU"<<endl;
    cout<<"Suma elementelor care au cel putin o cifra para:"<<scifpar1(1,n)<<endl;
    cout<<"Toate elementele din vector sunt prime?";
    if(prim(1,n)==n) cout<<" DA"<<endl;
    else cout<<" NU"<<endl;
    cout<<"Elementele sunt ordonate crescator?"<<ordcresc(1,n)<<endl;
    cout<<"Cmmdc:"<<cmmdc(1,n)<<endl;
    cout<<"Suma elementelor din sir care sunt perfecte:"<<sperfecte(1,n)<<endl;
    //perfecte=egale cu suma divizorilor sai mai putin el insusi (ex: 6)
    cout<<"Suma elementelor patrate perfecte:"<<sumapp(1,n)<<endl;
    cout<<"Cautati in vector valoarea="; cin>>c; cout<<"Apare pe pozitiile:"; cauta(1,n,c); cout<<endl;
    cout<<"Pozitile elementelor care au toate cifrele distincte: "; pozcdist(1,n);  cout<<endl;
    cout<<"Exista macar un element superprim?"; if(nrsuperprime(1,n)) cout<<" DA"<<endl; else cout<<" NU"<<endl;
    cout<<"Valoarea maxima:"<<maxim(1,n)<<endl;
    cout<<"Produsul primelor cifre:"<<prodcif(1,n)<<endl;
    cout<<"Vectorul este simetric?"; if(simetric(1,n)==1) cout<<" DA"<<endl; else cout<<" NU"<<endl;

    return 0;
}
