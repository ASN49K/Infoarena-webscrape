#include <cstdio>
#define f stdin
#define g stdout
using namespace std;

int gcd(int &in,int &il,int a,int b)
{
    if(!b)
    {
        in=1;
        il=0;
        return a;
    }
    int d,in0,il0;
    d=gcd(in0,il0,b,a%b);
    in=in0;
    il=in0-(a/b)*il0;
    return d;
}

int main()
{
    int a,b,c,nr,d;
    freopen("euclid3.in","r",f);
    freopen("euclid3.out","w",g);
    scanf("%d",&nr);
    for(int i=1;i<=nr;i++)
    {
        scanf("%d %d %d",&a,&b,&c);
        int il,in;
        d=gcd(in,il,a,b);
        if(c%d)
        {
            printf("0 0\n");
        }
        else
        {
            printf("%d %d\n",in*(c/d),il*(c/d));
        }
    }
    return 0;
}
