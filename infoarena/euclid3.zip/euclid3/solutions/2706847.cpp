#include <iostream>
#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int T;
int Euclid_Extins(int A,int B,int &X,int &Y)
{
    if(B==0)
    {
        X=1;
        Y=0;
        return A;
    }
    int X0,Y0;

    int D=Euclid_Extins(B,A%B,X0,Y0);

    X=Y0;
    Y=X0-(A/B)*Y0;

    return D;
}
int main()
{
    f>>T;
    for(int i=0; i<T; i++)
    {
        int A,B,C,D,X,Y;
        f>>A>>B>>C;
        D=Euclid_Extins(A,B,X,Y);

        if(C%D)
            g<<0<<" "<<0<<'\n';
        else g<<X*(C/D)<<" "<<Y*(C/D)<<'\n';
    }
    return 0;
}
