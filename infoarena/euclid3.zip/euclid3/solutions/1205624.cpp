#include <iostream>
#include<fstream>
using namespace std;
int cmmdc(long long a,long long b)
{
    long long c;
    while(b)
    {
        c=a%b;
        a=b;
        b=c;
    }
    return a;
}
int main()
{ int t,i,ok;
  long long a,b,c,m,l,x,y;
  ifstream f("euclid3.in");
  ofstream g("euclid3.out");
  f>>t;
  for(i=1;i<=t;i++)
  {
      f>>a>>b>>c;
      l=cmmdc(a,b);
      if(c%l!=0)
       g<<0<<" "<<0<<'\n';
      else
      {
          a=a/l;b=b/l;c=c/l;
          m=b;
          ok=0;
          while(ok==0)
          {
              if((m-c)%a==0)
              {
                  x=(m-c)/(-a);
                  y=(c-a*x)/b;
                  ok=1;
              }
              else
              {
                  m=m+b;
              }
          }
         g<<x<<" "<<y<<"\n";
      }
  }
  f.close();
  g.close();
    return 0;
}
