#include <stdio.h>

void euclid(int &x,int &y,int &z,int c,int d)
{
     int a,a1,b,b1,r,q,t;
     a1=1;
     a =0;
     b1=0;
     b =1;
     while (c%d)
     {
          q = c/d;
          r = c%d;
          t = a1;
          a1 = a;
          a = t-a*q;
          t = b1;
          b1 = b;
          b = t-b*q;
          c=d;
          d=r;
     }
     x=a;
     y=b;
     z=d;
}
int main()
{
    int a,b,c,n,x,y,z;
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    for(;n;n--)
    {
               scanf("%d %d %d",&a,&b,&c);
               euclid(x,y,z,a,b);
               
               if (c%z==0) printf("%d %d\n",x*c/z,y*c/z);
               else printf("0 0\n");
    }
}
