#include <iostream>
#include <fstream>

using namespace std;

int v[1000000];
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int main()
{
    int t,i,x,y,c,j,a,b,lg,d;

    fin>>t;
    for(i=0;i<t;i++)
    {
        fin>>a>>b>>c;
        lg=-1;
        while(b)
        {
            d=a%b;
            v[++lg]=a/b;
            a=b;
            b=d;
        }
        if(c%a==0){
        x=1;y=0;
        for(j=lg;j>=0;j--)
        {
            d=x;
            x=y;
            y=d-v[j]*y;
        }
        fout<<x*(c/a)<<" "<<y*(c/a)<<'\n';
        }
        else fout<<0<<" "<<0<<'\n';
    }

}
