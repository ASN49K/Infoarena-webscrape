#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");

long t,a,b,c,d,x,y,aux;

void euclid(long m,long n);

int main()
{
    long i;
    f>>t;
    for(i=1;i<=t;i++){
        x=1;y=0;
        f>>a>>b>>c;
        if(!b){
            if(!(c%a))
                g<<c/a<<" 0\n";
            else
                g<<"0 0\n";
            continue;}
        euclid(a,b);
        if(c%d)
            g<<"0 0\n";
        else
            g<<x*c/d<<' '<<y*c/d<<'\n';}
    f.close();
    g.close();
    return 0;
}

void euclid(long m,long n){
    if(!n)
        d=m;
    else{
        euclid(n,m%n);
        aux=y;
        if(!y)
            y=x;
        else
            y=x-(a/b)*y;
        x=aux;}}
