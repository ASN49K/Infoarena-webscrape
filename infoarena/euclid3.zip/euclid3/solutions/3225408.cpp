#include <bits/stdc++.h>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
typedef long long ll;
typedef pair<ll,ll> pll;
ll t,a,b,c;
void solve()
{
    fin>>a>>b>>c;
    ll g=__gcd(a,b);
    if(c%g!=0)
    {
        fout<<"0 0\n";
        return;
    }
    c/=g;
    a/=g;
    b/=g;
    pll Va={1,0};
    pll Vb={0,1};
    pll Vr;
    while(b)
    {
        ll cat=a/b;
        ll rest=a%b;
        Vr.first=Va.first-cat*Vb.first;
        Vr.second=Va.second-cat*Vb.second;
        a=b;
        b=rest;
        Va=Vb;
        Vb=Vr;
    }
    fout<<Va.first*c<<' '<<Va.second*c<<'\n';
}
int main()
{
    fin>>t;
    while(t--)
        solve();
    return 0;
}
