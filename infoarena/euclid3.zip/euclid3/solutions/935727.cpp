#include <fstream>
#include <cstdlib>

using namespace std;

inline int gcd(int a, int b, int& x, int& y)
{
	if(!b)
	{
		x = 1;
		y = 0;
		return a;
	}
	int d, x0, y0;
	
	d = gcd(b, a % b, x0, y0);

	x = y0;
	y = x0 - (a / b) * y0;
	
	return d;	
}

int main()
{
	int T, a, b, c, d, x, y;
	ifstream in("euclid3.in");
	ofstream out("euclid3.out");
	
	for(in >> T; T; --T)
	{
		in >> a >> b >> c;
		d = gcd(a, b, x, y);
		if(c % d) out <<"0 0";
		else out << (x * (c / d)) << ' ' << (y * (c / d));
		out << '\n';
	}
	
	return EXIT_SUCCESS;
}
