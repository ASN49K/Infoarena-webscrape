#include <fstream>

using namespace std;

ifstream in("euclid3.in");
ofstream o("euclid3.out");

int T;
int a,b,c;

int euclid(int a, int b, int &x, int &y)
{
    int c,x0,y0;
    if(!b)
    {
        x=1;
        y=0;
        return a;
    }
    c=euclid(b, a%b,x0,y0);
    x=y0;
    y=x0-y0*(a/b);
    return c;
}

int main()
{
    int x,y,p,e;
    in>>T;
    while(T)
    {
        T--;
        in>>a>>b>>c;
        e=euclid(a,b,x,y);
        if(c%e)
        {
            o<<"0 0\n";
        }
        else
            o<<x*(c/e)<<" "<<y*(c/e)<<'\n';
    }
    in.close();
    o.close();
    return 0;
}
