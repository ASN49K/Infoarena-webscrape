#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int n,a,b,c,d,x,y;
int cmmdc(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;y=0;
        return a;
    }
    int D,X,Y;
    D=cmmdc(b,a%b,X,Y);
    x=Y;y=X-(a/b)*Y;
    return D;
}
int main()
{
    fin>>n;
    for(;n;n--)
    {
        fin>>a>>b>>c;
        d=cmmdc(a,b,x,y);
        if(c%d)
            cout<<"0 0\n";
        else
            cout<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }
    return 0;
}
