#include <iostream>
#include <cstdio>
using namespace std;
int a,b,c;
int gcd(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d=gcd(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
void citire()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        int d,x,y;
        d=gcd(a,b,x,y);
        if(c%d!=0)
            printf("0 0\n");
        else
            printf("%d %d\n",x*(c/d),y*(c/d));
    }
}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    citire();
   // cout << "Hello world!" << endl;
    return 0;
}
