#include<stdio.h>
int cmmdc(int a,int b)
{
 if (a%b==0)
	 return b;
 return cmmdc(b, a%b);
 
}
/*int cmmdc(int a,int b)
{
	int r=a%b;
	while (r)
	{
	a=b;b=r;r=a%b;
	}
	return b;
}*/
int cmmdc(int a,int b, int&x, int &y){
	if (a%b==0){
		x=1; 
		y=0;
		return as;
	}
	int x1,y1,d;
	d=cmmdc(b,a%b,x1,y1);
	x=y1;
	y=x1-a/b*y1;
	return d;
}
int main()
{
  int a,b,t,d,x,y,c;
  freopen ("euclid3.in","r",stdin);
  freopen ("euclid3.out","w",stdout);
  scanf("%d",&t);
  while (t--){
  scanf("%d%d%d",&a,&b,&c);
  //printf("%d\n",cmmdc(a,b));
  d=cmmdc(a,b,x,y);
  if (c%d)
	  printf("0 0\n");
  else
	  printf("%d %d\n",c/d*x, c/d*y);
  }
  return 0;
}