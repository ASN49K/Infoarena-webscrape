#include<fstream>
using namespace std;
void euclid(long a, long b, long c, long x, long y)
{
    if (b==0) 
	{
        c=a;
        x=1;
        y=0;
    }
	else 
	{
       long x0,y0;
        euclid (b,a%b,c,x0,y0);
        x=y0;
        y=x-(a/b)*y0;
    }
}
long n,a,b,c,i,d,x,y;
int main()
{
	ifstream f("euclid3.in");
	ofstream g("euclid3.out");
	f>>n;
	for(i=1;i<=n;i++)
	{
		f>>a>>b>>d;
		euclid(a,b,c,x,y);
		if(d%c==0)
		{
			g<<x*(d/c)<<" "<<y*(d/c);
			g<<"\n";
		}
		else
			g<<"0 0";
	}
	return 0;
}