#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <string>
#include <algorithm>
using namespace std;
ifstream ff("euclid3.in");
ofstream gg("euclid3.out");

int t,a,b,c;
struct tuple{ 
	int x,y; 
	tuple(int x0=0, int y0=0){ x=x0; y=y0; }
	tuple(const tuple& a){ x=a.x; y=a.y; }
};
tuple operator-(tuple a, tuple b){ return tuple(a.x-b.x, a.y-b.y); }
tuple operator*(int a, tuple b){ return tuple(a*b.x, a*b.y); }

int gcd(int a,int b, tuple& p){
	int q,r;
	tuple vr, va(1,0), vb(0,1);
	while(b!=0){
		q=a/b;
		r=a%b;
		a=b;
		b=r;
		vr=va-q*vb;
		va=vb;
		vb=vr;
	}
	p=va;
	return a;
}

int main(){
	int d;
	tuple p;
	ff >> t;
	while(t--){
		ff >> a >> b >> c;
		d = gcd(a,b,p);
		if(c%d) cout << "0 0\n"; else
			cout << (c/d)*p.x << " " << (c/d)*p.y << "\n";
	}	
	return 0;
}
