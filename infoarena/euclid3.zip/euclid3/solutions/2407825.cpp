#include <bits/stdc++.h>

int a,b,c,d;
long long x,y;

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void P(long long &x,long long &y,int &d, int a, int b)
{
     if(b==0) x=1,y=0,d=a;
     else
     {
         P(x,y,d,b,a%b);
         long long o=x;
         x=y;
         y=o-y*(a/b);
     }
}

int t;

int main()
{
    fin>>t;
    while(t--)
    {
        fin>>a>>b>>c;
        P(x,y,d,a,b);
        if(c%d==0) {d=c/d;
        fout<<x*d<<' '<<y*d<<'\n';}
        else fout<<"0 0\n";
    }
    return 0;
}
