#include <iostream>
#include <stdio.h>
using namespace std;
int euclid(int a,int b){
	if(b==0)return a;
	euclid(b,a%b);
}

int v0[2],v1[2],vt[2];
void solution(int a,int b,int c){
	int cmmdc=euclid(a,b);
	if(c%cmmdc!=0)cout<<0<<" "<<0<<endl;
	else{
		if(cmmdc!=1){
			a=a/cmmdc,b=b/cmmdc,c=c/cmmdc;
		}
		v0[0]=1,v0[1]=0,v1[0]=0,v1[1]=1;
		while(b!=0){
			a=b,b=a%b;
			vt[0]=v0[0],vt[1]=v0[1];
			v0[0]=v1[0],v0[1]=v1[1];
			v1[0]=vt[0]-(a/b)*v1[0];
			v1[1]=vt[1]-(a/b)*v1[1];
		}
		
		cout<<vt[0]<<" "<<vt[1];
	}
}

int main() {
	freopen("euclid2.in", "r", stdin);
	freopen("euclid2.out", "w", stdout);
	int x,y,z,t;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d %d %d", &x,&y,&z);
		solution(x,y,z);
	}
}

