#include<stdio.h>


void euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}


int main()
{
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
    int t,a,b,c,d,x,y;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d %d %d",&a,&b,&c);
		euclid(a,b,&d,&x,&y);
		if(c%d) printf("0 0\n");
		else
			printf("%d %d\n",x*(c/d),y*(c/d));
	}
}