#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void euclid(int a, int b, int &d, int &x, int &y)
{
    if(b==0)
    {
        d = a;
        x = 1;
        y = 0;
    }
    else
    {
        int x0, y0;
        euclid(b, a%b, d, x0, y0);
        x = y0;
        y = x0 - y0*(a/b);
    }
}

int main()
{
    int a, b, c, d, x, y, T, i;
    fin >> T;
    for(i=1; i<=T; i++)
    {
        fin >> a >> b >> c;
        euclid(a, b, d, x, y);
        if(c%d)
            fout << 0 << " " << 0 << "\n";
        else
            fout << x*(c/d) << " " << y*(c/d) << "\n";
    }
    fin.close();
    return 0;
}
