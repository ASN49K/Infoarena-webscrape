#include <cstdio>
int tests;
 
int euclid(int a, int b, int &x, int &y)
{
    if (b==0)
    {
        x = 1; y = 0;
        return a;
    }
    int d = euclid(b, a % b, x, y);
     
    int x2,y2;
    x2 = y;
    y2 = x - (a / b) * y;
    x = x2; y = y2;
     
    return d;
     
}
 
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&tests);
    int a,b,c,x,y,d;
    while (tests--)
    {
        scanf("%d%d%d",&a, &b, &c);
        d = euclid(a, b, x, y);
        if (c % d)
            printf("0 0\n");
        else
            printf("%d %d\n",x * (c / d), y * (c / d));
    }
    return 0;
}
