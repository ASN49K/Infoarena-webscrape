#include<stdio.h>
#include<iostream>
#include<fstream>
#include<algorithm>
#include<stack>
using namespace std;
long long cmmdc(long long a,long long b)
{
    int r=a%b;
    while(r)
    {
        a=b;
        b=r;
        r=a%b;
    }
    return b;
}
void euc(long long a,long long b,long long &x,long long &y)
{
    if(b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        long long x0,y0;
        euc(b,a%b,x0,y0);
        x=y0;
        y=x0-x*(a/b);
    }
}
int main()
{
    ifstream si;
    si.open("euclid3.in");
    ofstream so;
    so.open("euclid3.out");
int t;
si>>t;
while(t--)
{
    long long a,b,c;
    si>>a>>b>>c;
    if(b==0)
        if(c%a!=0)
        {
            so<<0<<' '<<0<<'\n';
        }
        else
        {
            so<<c/a<<' '<<1<<'\n';
        }
    else
    {
    long long d=cmmdc(a,b);
    if(c%d!=0)
        so<<0<<' '<<0<<'\n';
    else
    {
        long long x,y;
        euc(a,b,x,y);
        so<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }
    }
}
}
