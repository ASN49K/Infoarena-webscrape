#include <fstream>
using namespace std;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");
int x,y,a,b,c,n,d,i,u=1,U,v,V=1,r,cat;


int main () {
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>a>>b>>c;
        x=y=d=0;
        while(b!=0){
            r=a%b;
            cat=a/b;
            a=b;
            b=r;
            if(b==0)
                break;
            r=u;
            u=U;
            U=r-cat*U;

            r=v;
            v=V;
            V=r-cat*v;
        }
        if(c%a==0)
            fout<<U*c<<" "<<V*c<<"\n";
        else fout<<0<<" "<<0<<"\n";
    }
}
