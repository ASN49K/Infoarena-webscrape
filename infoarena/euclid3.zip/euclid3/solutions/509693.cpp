#include<iostream>
#include<fstream>
using namespace std;

int T,x,y,d;

void euclid(int a, int b, int &d, int &x, int &y)
{
	if(b==0)
	{
		d=a;
		x=1;
		y=0;
	}
	else
	{
		int x0,y0;
		euclid(b,a%b,d,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}



ifstream aa("euclid3.in");
ofstream ss("euclid3.out");
int main() {
	int a,b,c;
	int i;
	aa >> T;
	for (i=1;i<=T;++i) {
		aa >> a >> b >> c;
		euclid(a,b,d,x,y);
		if(c%d==0) ss << x*(c/d) << " " << y*(c/d);
		else ss << "0 0\n";

	}
	aa.close();
	ss.close();
	return 0;
}
