// gcd extins - O(logN)
// Sa se gaseasca o solutie (x,y) ,
// pentru ecuatia ax+by=c , a,b,c,x,y intregi , a,b,c date

#include <fstream>
#include <algorithm>
using namespace std;
ifstream f("euclid3.in"); ofstream g("euclid3.out");

int T,a,b,c;

int gcd(int a,int b,int &x,int &y)
{
     if(!b)
     {
          x=1;
          y=0;
          return a;
     }
     int x0,y0;
     int d = gcd(b, a % b , x0,y0);
     x=y0;
     y=x0- (a/b)*y0;
     return d;
}

int main()
{
     f>>T;
     for(int i=1;i<=T;++i)
     {
          f>>a>>b>>c;
          int x,y;
          int d=gcd(a,b,x,y);
          if(c % d)g<<"0 0\n";
               else g<< x*(c/d)<<' '<<y*(c/d)<<'\n';
     }
     f.close();g.close();
     return 0;
}
