#include <bits/stdc++.h>

using namespace std;

long long euclid(long long a,long long b, long long &c,long long &d)
{
    if(b==0)
    {
        c=1;
        d=0;
        return a;
    }
    else
    {
        long long c0,d0;
        long long dd=euclid(b,a%b,c0,d0);
        c=d0;
        d=c0-a/b*d0;
        return dd;

    }


}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    long long n,a,b,c,jj,d,cc;
    scanf("%lld",&n);

    for(; n; --n)
    {
        scanf("%lld%lld%lld",&a,&b,&cc);
        long long j=euclid(a,b,c,d);
              if(cc%j)
        {
            printf("0 0");

        }
        else
        {

            printf("%lld %lld",c*(cc/j),d*(cc/j));
            printf("\n");
        }
    }
    return 0;
}
