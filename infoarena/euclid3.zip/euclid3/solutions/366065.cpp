/* 
 * File:   main.cpp
 * Author: virtualdemon
 *
 * Created on November 20, 2009, 6:33 PM
 */
#include <fstream>

/*
 *
 */
using namespace std;
ifstream in;
ofstream out;
int euclid( int a, int b, int& x, int& y )
{
    if( !b )
    {
        x=1;
        y=0;
        return a;
    }
    int x0, y0, d=euclid( b, a%b, x0, y0 );
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{int n;
    in.open("euclid3.in");
    in>>n;
    out.open("euclid3.out");
    while( n-- )
    {int a, b, c;
        in>>a>>b>>c;
        int x, y, d=euclid( a, b, x, y );
        if( c%d )
        {
            out<<"0 0\n";
            continue;
        }
        c/=d;
        out<<x*c<<' '<<y*c<<'\n';
    }
    return 0;
}