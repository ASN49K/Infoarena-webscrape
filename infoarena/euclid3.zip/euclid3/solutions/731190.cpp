#include <stdio.h>

using namespace std;

int euclid(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0, d = euclid(b, a % b, x0, y0);
    y = x0 - (a / b) * y0;
    x = y0;
    return d;
}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    int x, y, t, d, a, b, c;

    scanf("%d", &t);

    while(t--)
    {
        scanf("%d %d %d", &a, &b, &c);
        d = euclid(a, b, x, y);
        if(c % d)
            printf("0 0\n");
        else
            printf("%d %d\n", (c / d) * x, (c / d) * y);
    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}
