#include <stdio.h>
#include <stdlib.h>

//se cere aflarea x,y astfel incat a*x+b*y=c; !!! d=c
//*d va fi valoare cmmdc(a,b), *x a fi valoare lui x ia *y va fi valoarea calculata pt y.

void euclid_extins(int a,int b,int *c,int *x,int *y) {
    if(b == 0) {
        *c=a;
        *x=1;
        *y=0;
    }else {
        int x0,y0;
        euclid_extins(b,a%b,&c,&x0,&y0);
        *x=y0;
        *y=x0-(a/b)*y0;
    }

}

int main() {
    FILE *fin,*fout;
    fin=fopen("euclid3.in","r");
    fout=fopen("euclid3.out","w");

    int T,A,B,C,i,x,y;
    fscanf(fin,"%d",&T);

    for(i=0;i<T;i++) {
       // printf("\n%d",T);
        fscanf(fin,"%d %d %d",&A,&B,&C);
        euclid_extins(A,B,&C,&x,&y);
        printf("\n%d %d %d",A,B,C);
        fprintf(fout,"%d %d",x,y);
    }


    return 0;
}
