#include <iostream>
#include <fstream>
using namespace std;

int x, y, d;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclide(int a,int b,int &x,int &y, int &d){
    if (b==0)
    {
        x=1;
        y=0;
        d=a;
        return;
    }
    int x1,y1;
    euclide(b,a%b,x1,y1,d);
    x=y1;
    y=x1-y1*(a/b);
}

int main()
{
int a, b, c, i, n;

in>>n;
for(i=1;i<=n;++i)
{
    in>>a>>b>>c;
    euclide(a, b, x, y, d);
    if(c%d==0)
        out<<x*(c/d)<<" "<<y*(c/d)<<endl;
    else
        out<<0<<" "<<0<<endl;
}
    return 0;
}
