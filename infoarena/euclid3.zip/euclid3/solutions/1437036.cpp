#include <iostream>
#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
#define ll long long
ll T;

void euclid(ll,ll,ll*,ll*,ll*);

int main()
{
    ll a,b,c,d,x,y;
    f>>T;
    while (T--)
    {
        f>>a>>b>>c;
        euclid(a,b,&d,&x,&y);
        if (d==1 || c%d!=0)
            g<<"0 0\n";
        else
            g<<(x*c/d)<<' '<<(y*c/d)<<'\n';
    }
}


void euclid(ll a,ll b,ll* d,ll* x,ll* y)
{
    if (b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
        ll x0,y0;
        euclid(b,a%b,d,&x0,&y0);
        *x=y0;
        *y=x0-y0*(a/b);
    }
}
