#include <cstdio>

using namespace std;
int n, a, b, c;
int k, l;
int x, y;
/// a- x, b - y
/// x1, y1 - k', l'

void euclid3(int a, int b, int &d, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
        return;
    }
    int x1, y1;
    euclid3(b, a%b, d, x1, y1);
    x = y1;
    y = x1-(a/b)*y1;

}
int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);
    scanf("%d", &n);
    int d=0;
    for(int i=1; i<=n; i++)
    {
        scanf("%d %d %d", &a, &b, &c);
        euclid3(a, b, d, k, l);
        if(c%d == 0)
            printf("%d %d\n", k*(c/d), l*(c/d));
        else printf("0 0\n");
    }
    return 0;
}
