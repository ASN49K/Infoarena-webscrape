# include <fstream>
using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");

/****************************************/

inline int euc(int a,int b, int &x,int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d=euc(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}

/****************************************/

int main()
{
    int n,a,b,c,i;
    in>>n;
    for (i=1;i<=n;i++)
    {
        int d,x,y;
        in>>a>>b>>c;
        d=euc(a,b,x,y);
        if (c%d) out<<0<<' '<<0<<'\n';
        else out<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }
    return 0;
}
