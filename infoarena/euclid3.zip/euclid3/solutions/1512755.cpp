#include <iostream>
#include <stdio.h>
using namespace std;
int x,y,d,a,b,c,n;
void Eu_extins(int x,int y,int &d,int &a,int &b)
{
    if(!y)
    {
        d = x;
        a = 1;
        b = 0;
        return;
    }
    else
    {
        int b1,a1;
        Eu_extins(y,x%y,d,a1,b1);
        a = b1;
        b = a1 - b1 * (x / y);
    }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    for(int i = 0 ; i < n ; i++)
    {
        scanf("%d %d %d",&a,&b,&c);
        Eu_extins(a,b,d,x,y);
        if(c % d != 0)
            printf("%d %d\n",0,0);
        else
        {
            x *= (c / d);
            y *= (c / d);
            printf("%d %d\n",x,y);
        }
    }
    return 0;
}
