#include <fstream>

using namespace std;

ifstream cin ("euclid3.in");
ofstream cout("euclid3.out");

int euclid(int a,int b,int &x,int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
        int x0,y0,d;
        d=euclid(b, a%b,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
        return d;
    }
}

int main()
{
    int n,i,a,b,d,c,x,y;
    cin>>n;
    for (i=1;i<=n;i++)
    {
        cin>>a>>b>>c;
        d=euclid(a,b,x,y);
        if (c%d==0)
            cout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
        else cout<<"0 0"<<"\n";
    }
    return 0;
}
