#include <iostream>
#include<fstream>
#include <assert.h>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

inline int gcd(int a, int b, int &x, int &y)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
		return a;
	}
	else
	{
		int x0, y0, D;
		D=gcd(b, a%b, x0, y0);
		x = y0;
		y = x0 - (a / b)*y0;
		return D;
	}
}

int main()
{
	int n,i, A, B, C;
	fin >> n;
	for (i = 0; i < n; ++i) {
		
		fin >> A >> B >> C;
		assert(-1000000000 <= A &&A <= 1000000000);
		assert(-1000000000 <= B && B<= 1000000000);
		assert(-1000000000 <= C && C<= 1000000000 && C!=0);
		
		int x, y, d;
		d = gcd(A, B, x, y);
		if (C%d)
			fout << "0 0\n";
		else
			fout << x*(C / d) << " " << y*(C/ d) << "\n";
	}
	fin.close();
	fout.close();
	return 0;
}