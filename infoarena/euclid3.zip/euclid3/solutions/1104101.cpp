#include <stdio.h>

int gcd(int a,int b,int &x,int &y){
 
   if(b==0){
       x=1;
       y=0;
       return a;
   }
   else{
       int s,r,d;
       d=gcd(b,a%b,s,r);
       x=r;
       y=s-a/b*r;
       return d;
   }
   
}
 


int main()
{
   FILE *fp_r,*fp_w;
   int N,a,b,c,x,y,d,i;
   fp_r = fopen("euclid3.in", "r");
   fp_w= fopen("euclid3.out","w");
   
   fscanf(fp_r,"%d",&N);
   for(i=0;i<N;i++){
      fscanf(fp_r,"%d%d%d",&a,&b,&c);
      d=gcd(a,b,x,y);
      if(c%d){
          fprintf(fp_w,"0 0\n");
      }
      else{
          fprintf(fp_w,"%d %d\n",(c/d)*x,(c/d)*y);
      }
   }
   
   return 0;
}