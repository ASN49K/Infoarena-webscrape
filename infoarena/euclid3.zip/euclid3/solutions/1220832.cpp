//https://www.youtube.com/watch?v=hB34-GSDT3k
// http://www.infoarena.ro/algoritmul-lui-euclid
#include <iostream>
#include <fstream>
using namespace std;
inline int cmmdc(int a, int b)
{
    int r;
    do
    {
        r=a%b;
        a=b;
        b=r;
    }while (b!=0);
    return a;
}
void euclid_extins(int a, int b, int d, int &x, int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        int x0,y0;
        euclid_extins(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int main()
{
    int t,a,b,c,d,x,y;
    fstream f,g;
    f.open("euclid3.in",ios::in);
    g.open("euclid3.out",ios::out);
    f>>t;
    while(t--)
    {
        f>>a>>b>>c;
        d=cmmdc(a,b);
        if (c%d!=0)
            g<<"0 0\n";
        else
        {
            euclid_extins(a,b,d,x,y);
            g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        }
    }
}
