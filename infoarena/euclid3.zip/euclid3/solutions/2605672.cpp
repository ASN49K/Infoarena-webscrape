#include <iostream>

using namespace std;

void euclid(int a, int b, int &x, int &y, int &d){
    if(b==0){
        x = 1;
        y = 0;
        d = a;
        return;
    }
    int xx,yy,q=a/b;
    euclid(b,a%b,xx,yy,d);
    x=yy;
    y=xx-q*yy;
}

int main()
{
    ifstream in("euclid3.in");
    ofstream out("euclid3.out");
    int t,a,b,c;
    in >> t;
    for(int i = 0; i < t; i++){
        int x,y,d;
        in >> a >> b >> c;
        euclid(a,b,x,y,d);
        if(c%d!=0){
            out << "0 0\n";
        }else{
            out << (c/d)*x << " " << (c/d)*y << "\n";
        }
    }
    in.close();
    out.close();
    return 0;
}
