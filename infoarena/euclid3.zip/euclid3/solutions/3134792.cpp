#include <iostream>
using namespace std;

int d,a,b;
int cmmdc(int &x, int &y)
{
    if (b == 0){
        x = 1;
        y = 0;
        return a;
    }

    int x0, y0;
    a = b;
    b = a % b;
    d = cmmdc(x0, y0);

    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    int t;
    cin >> t;
    for (int i =0 ; i < t; i++)
    {
        int a, b, c;
        cin >>a>>b>>c;
        int x, y;
        d = cmmdc(x, y);

        if (c % d)
            cout << "0 0" << endl;
        else
            printf("%d %d\n", x * (c / d), y * (c / d));
    }

    return 0;
}