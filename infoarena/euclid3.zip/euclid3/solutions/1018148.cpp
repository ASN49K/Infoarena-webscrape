#include<fstream>
using namespace std;
void euclid(int a, int b, int &d, int *x, int *y)
{
    if (b == 0) {
        d = a;
        *x = 1;
        *y = 0;
    } 
	else 
	{
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}
int main()
{
	int a,b,d,x,y,n,c;
	ifstream f("euclid3.in");
	ofstream g("euclid3.out");
	f>>n;
	for(int i=1;i<=n;i++)
	{
		f>>a>>b>>c;
		euclid(a,b,d,&x,&y);
		if(c%d!=0) g<<"0 0\n";
		else
			g<<x*(c/d)<<" "<<y*(c/d)<<"\n";
	}
	f.close();
	g.close();
	return 0;
}
