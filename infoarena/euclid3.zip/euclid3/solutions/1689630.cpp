#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int nrquiz, a, b, c, x, y;

int cmmdc(int a, int b)
{
    if (b == 0)
        return a;
    return cmmdc(b, a % b);
}

int euclid(int a, int b, int &x, int &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    else
    {
        int xx, yy, d;
        d = euclid(b, a % b, xx, yy);
        x = yy;
        y = xx - (a / b) * yy;
    }
}

int main()
{
    for (f >> nrquiz; nrquiz; -- nrquiz)
    {
        f >> a >> b >> c;

        int d = cmmdc(a, b);

        if (c % d != 0)
            g << "0 0" << '\n';
        else
        {
            euclid(a, b, x, y);
            x *= c / d;
            y *= c / d;
            g << x << " " << y << '\n';
        }
    }
    return 0;
}
