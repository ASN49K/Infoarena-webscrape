#include <bits/stdc++.h>

using namespace std;

void euclid(int a, int b, int &gcd, int &x, int &y)
{
    if (!b)
    {
        x = 1;
        y = 0;
        gcd = a;
    }
    else
    {
        int x0, y0;
        euclid(b, a % b, gcd, x0, y0);

        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    ifstream in("euclid3.in");
    ofstream out("euclid3.out");

    int T, a, b, c;

    in >> T;

    while (T--)
    {
        in >> a >> b >> c;

        int x, y, g;
        euclid(a, b, g, x, y);

        if (c % g)
            out << "0 0\n";
        else
            out << x * (c / g) << " " << y * (c / g) << "\n";
    }

    return 0;
}
