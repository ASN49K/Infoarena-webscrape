#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <queue>
#include <set>
#include <unordered_map>
#include <cstring>
#include <climits>
#include <iomanip>   
#include <stack>

#define NMAX 4003
using namespace std;

int n;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int euclid(int a, int b, int& x, int& y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }

    int X0, Y0, D;
    D = euclid(b, a % b, X0, Y0);

    x = Y0;
    y = X0 - (a / b) * Y0;
    return D;
}

int main()
{
    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        int a, b, c;
        fin >> a >> b >> c;
        int x = 0, y = 0,d=0;
        d= euclid(a, b, x, y);
        if (c % d) {
            fout << "0 0\n";
        }
        else {
            fout << x * (c / d) << " " << y * (c / d) << "\n";
            
        }
        
    }
    return 0;
}