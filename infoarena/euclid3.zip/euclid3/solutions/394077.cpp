#include <cstdio>

int euclid(int A,int B,int &X,int &Y ){
	if(B==0){
		X = 1;
		Y = 0;
		return A;
	}
	int X0, Y0, D;
	D= euclid( B, A % B, X0, Y0 );
	X=Y0;
	Y=X0-(A/B)*Y0;
	return D;
}

int main(){
	freopen("euclid2.in","rt",stdin);
	freopen("euclid2.out","wt",stdout);
	int N;
	scanf("%u",&N);
	for(int i=0;i<N;i++){
		int a,b,c,d,x,y;
		scanf("%u %u %u",&a,&b,&c);
		d=euclid(a,b,x,y);
		if(c%d){
			printf("0 0\n");
		}else{
			printf("%d %d\n",x*(c/d),y*(c/d));
		}
	}
	return 0;
}