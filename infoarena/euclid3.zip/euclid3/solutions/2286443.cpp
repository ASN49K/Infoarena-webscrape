#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll d;

pair<ll,ll>slove(ll a,ll b)
{
    if(b==0)
    {
        d=a;
        return {1LL,0LL};
    }
    else
    {
        pair<ll,ll>p=slove(b,a%b);
        return {p.second,p.first-(a/b)*p.second};
    }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    int t;
    cin>>t;
    for(int tc=1;tc<=t;tc++)
    {
        ll a,b,c;
        cin>>a>>b>>c;
        pair<ll,ll>p=slove(a,b);
        if(c%d==0)
        {
            cout<<p.first*(c/d)<<" "<<p.second*(c/d)<<"\n";
        }
        else
        {
            cout<<"0 0\n";
        }
    }
    return 0;
}
