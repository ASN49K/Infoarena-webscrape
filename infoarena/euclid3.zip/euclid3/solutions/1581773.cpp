#include <iostream>
#include <fstream>
using namespace std;
int T,a,b,c,x,y;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
inline int cmmdc(int a, int b, int& x, int& y)
{
    if(!b)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d=cmmdc(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    f>>T;
    for(int i=1;i<=T;i++)
    {
        f>>a>>b>>c;
        int d=cmmdc(a,b,x,y);
        if(c%d)g<<"0 0\n";
        else g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
    return 0;
}
