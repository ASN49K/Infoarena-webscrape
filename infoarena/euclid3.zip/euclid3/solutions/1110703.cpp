#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");

int N, a, b, c;

int gcd_extins(int a, int b, int &x, int &y)
{
    if (!b) { x=1; y=0; return a; }
    int x0, y0, d=gcd_extins(b, a%b, x0, y0);
    x=y0; y=x0-(a/b)*y0;
    return d;
}

int main()
{
    f>>N;
    for (int i=1; i<=N; ++i)
    {
        f>>a>>b>>c;
        int x, y, d=gcd_extins(a, b, x, y);
        if (c%d!=0) { g<<"0 0\n"; continue; }
        x*=(c/d); y*=(c/d);
        g<<x<<' '<<y<<'\n';
    }
    return 0;
}
