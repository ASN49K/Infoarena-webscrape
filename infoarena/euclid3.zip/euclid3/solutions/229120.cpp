#include<stdio.h>
int a[200],b[200],c,x[200],y[200],i,t,n;
void readd();
int main()
{       readd();
	return 0;
}
void readd()
{
	freopen("inversmodular.in","r",stdin);
	freopen("inversmodular.out","w",stdout);
	scanf("%d%d",&a[1],&b[1]);
	c=1;i=1;
	while(b[i]){a[i+1]=b[i];b[i+1]=a[i]%b[i];i++;}
	n=i;
	x[n]=c/a[n];y[n]=0;
	for(i=n-1;i>=1;i--)
	{ x[i]=y[i+1];y[i]=x[i+1]-(a[i]/b[i])*y[i+1];}
	while(x[1]>=b[1])x[1]-=b[1];
        while(x[1]<0)x[1]+=b[1];
	printf("%d\n",x[1]);
}
