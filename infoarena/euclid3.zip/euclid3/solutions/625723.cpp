#include <fstream>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclidextins(int a, int b, int &x, int &y, int &d){
	if(b==0){
		d=a;
		x=1;
		y=0;
		return;
	}
	int x0,y0;
	euclidextins(b,a%b,x0,y0,d);
	x=y0;
	y=x0-(a/b)*y0;
}


int main(){
	int n,a,b,c,d,x,y;
	in>>n;
	for(int i=1;i<=n;i++){
		in>>a>>b>>c;
		euclidextins(a,b,x,y,d);
		if(c%d)
			out<<"0 0\n";
		else
			out<<x<<" "<<y<<"\n";
	}
	return 0;
}