#include <iostream>
#include <fstream>
typedef long long ll;
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
ll euclext(ll a,ll b,ll &x,ll &y)
{
if(b==0)
{x=1;
 y=0;
 return a;
}else {ll x0,y0,d;
    d=euclext(b,a%b,x0,y0);
    x=y0;
    y=x0-y0*(a/b);
    return d;
}

}

int main()
{ll t,a,b,d,x,y,c;
    fin>>t;
    while(t--)
    {
        fin>>a>>b>>c;
        d=euclext(a,b,x,y);
        if(c%d){fout<<0<<' '<<0<<'\n';}
        else   {fout<<x*(c/d)<<' '<<y*(c/d)<<'\n';}
    }
}
