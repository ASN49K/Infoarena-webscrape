#include <iostream>
#include <fstream>

using namespace std;

int euclid(int a, int b, int &x, int &y) {
    if (b == 0) {
        x = 1, y = 0;
        return a;
    }

    int x0, y0;
    int d = euclid(b, (a % b), x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);
    int t, a, b, c, x, y, d;
    cin>>t;
    while(t--)
    {
        cin >> a >> b >> c;
        d =euclid(a, b, x, y);
        if (c % d != 0)
            cout << "0 0\n";
        else
            cout << (c / d) * x << " " << (c / d) * y << "\n";
    }
    return 0;
}
