#include <iostream>
#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int a,b,c,t;
int n1,n2;
int testc;
int zero1,zero2;

int EuclidExtins(int d,int e,int &x,int &y){
    //d<=>a
    //e<=>b
    if(e==0){
        return d;
        x=1;
        y=0;
    }
//    else{
//        //k1=k2=0 testul care pleaca de la zero iar
//        int k1,k2,f;
//        f=EuclidExtins(e,d%e,k1,k2);
//        x=k1;
//        y=
//        //work in progress...
//    }
}

int main(){
    f>>t;
    for(int i=1;i<=t;i++){
        f>>a>>b>>c;
        testc=EuclidExtins(a,b,zero1,zero2);
        if(c%testc==0)g<<"0 0";
    }
return 0;
}
