#include <iostream>
#include <stdio.h>
#define fr(i,a,b) for(int i=a;i<b;++i)
#define ll long long

int a,b,c;
int x,y,x1;
int n;

int gdkp(int a,int b)
{
    if(!b) {x=1;y=0;return a;}
    int k=gdkp(b,a%b);
   // printf("x= %d y= %d\n",x,y);
    x1=x;x=y;y=x1-y*(a/b);
    return k;
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    fr(i,0,n)
    {
        scanf("%d %d %d",&a,&b,&c);
        //if(a>b) a^=b^=a^=b;
        int d=gdkp(a,b);
        //printf("%d\n",d);
        //printf("%d*%d+%d*%d=%d\n",x,a,y,b,c);
        x*=c/d;
        y*=c/d;
        if(c%d)
            printf("0 0\n");
        else
            //printf("%d*%d+%d*%d=%d\n",x,a,y,b,c);
            printf("%d %d\n",x,y);
    }
    return 0;
}

