#include<stdio.h>

FILE*f=fopen("euclid3.in","r");
FILE*g=fopen("euclid3.out","w");

void gcd ( int a , int b , int &x , int &y , int &d ){
	
	if ( b == 0 ){
		x = 1; y = 0;
		d = a;
		return ;
	}
	
	int x0,y0;
	gcd(b,a%b,x0,y0,d);
	
	x = y0;
	y = x0 - (a/b)*y0;
}

int main () {
	
	int T;
	fscanf(f,"%d",&T);
	while ( T-- ){
		
		int a,b,c;
		fscanf(f,"%d %d %d",&a,&b,&c);
		int x,y,d;
		gcd(a,b,x,y,d);
		
		if ( c%d ){
			x = y = 0;
		}
		else{
			x = x*c/d;
			y = y*c/d;
		}
		
		fprintf(g,"%d %d\n",x,y);
	}
	
	fclose(f);
	fclose(g);
	
	return 0;
}
