#include<fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int n,a,b,r,x,y,d,i;

int euc3(int a,int b,int &x,int &y)
{
	int r;
	if (b==0)
	{
		x=1;
		y=0;
		r=a;
	}
	else
	{
		int x0,y0;
		r=euc3(b,a%b,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
	return r;
}

int main()
{
	f>>n;
	for (i=1;i<=n;++i)
	{
		f>>a>>b>>r;
		
		d=euc3(a,b,x,y);
		
		if (r%d==0)
			g<<x*(r/d)<<' '<<y*(r/d)<<'\n';
		else g<<0<<' '<<0<<'\n';
	}
	
	f.close();
	g.close();
	return 0;
}
