#include <cstdio>
using namespace std;

int t, a, b, c, d, x, y;

void euclid (int a, int b, int &d, int &x, int &y)
{
	if (!b)
	{
		d = a;
		x = 1;
		y = 0;
	}
	else
	{
		int x0;
		int y0;
		euclid(b, a%b, d, x0, y0);
		x = y0;
		y = x0 - a/b * y0;
	}
}

int main()
{
	FILE *g = fopen("euclid3.in", "r");
	FILE *f = fopen("euclid3.out", "w");
	
	fscanf(g, "%d", &t);
	
	for (; t; --t)
	{
		fscanf(g, "%d%d%d", &a, &b, &c);
		euclid(a, b, d, x, y);
		
		if (c % d)
			fprintf(f, "0 0\n");
		else
			fprintf(f, "%d %d\n", x*(c/d), y*(c/d));
		
	}
	
	return 0;
}
