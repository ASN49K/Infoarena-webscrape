#include <cstdio>

using namespace std;
void euclidex(int a,int b,int &k,int &l,int &d)
{
    if(b==0){
        l=1;
        k=0;
        d=a;

      return;  }
        int k1,l1,d1;
        euclidex(b,a%b,k1,l1,d1);
    l=k1;
    k=l1-(a/b)*k1;
    d=d1;}

int main()
{int a,b,c,t,d,l,k;
freopen("euclid3.in","r",stdin);
freopen("euclid3.out","w",stdout);
scanf("%d\n",&t);
for(int i=0;i<t;i++)
{
    scanf("%d %d %d\n",&a, &b ,&c);
    euclidex(a,b,k,l,d);
    if(c%d==0)
        printf("%d %d\n",l*(c/d),k*(c/d));
    else
        printf("0 0\n");
}

    return 0;
}
