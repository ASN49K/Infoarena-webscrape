#include <fstream>

using namespace std;

ifstream fin ( "euclid3.in" );
ofstream fout ( "euclid3.out" );

int t;
int a, b, c;

int euclid(int a, int b, int& x, int& y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int d = euclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - y1 * (a / b);
    return d;
}
int main()
{
    fin >> t;
    while ( t-- )
    {
        fin >> a >> b >> c;
        int x = 0; int y = 0;
        int d = euclid(a, b, x, y);
        if ( c % d != 0 ) fout << "0 0" << '\n';
        else fout << x * c / d << " " << y * c / d << '\n';
    }
    return 0;
}
