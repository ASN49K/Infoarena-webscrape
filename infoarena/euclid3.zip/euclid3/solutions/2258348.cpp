#include <iostream>
#include <fstream>

using namespace std;

inline void euclid(int a, int b, int &d, int &x, int &y)
{
    if(!b)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        int x0,y0;
        euclid(b, a%b, d, x0, y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");
    int t; f>>t;
    while(t--)
    {
        int a,b,c; f>>a>>b>>c;
        int x=0,y=0,d=0;
        euclid(a, b, d, x, y);
        if(c%d)
            g<<"0 0\n";
        else
            g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
    return 0;
}
