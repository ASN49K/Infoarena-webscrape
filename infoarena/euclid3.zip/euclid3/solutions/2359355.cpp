#include <bits/stdc++.h>
#define inf 1000000000
using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid.out");

int t,a,b,c;

int main()
{
    int i,j,coeficient,m;
    fin>>t;
    for(coeficient=1;coeficient<=t;coeficient++)
    {
        fin>>a>>b>>c;
        for(i=-inf;i<=inf;i++)
        {
            m=(-inf+i)/2;
            a*=m;
            c-=m;
            if(c%b==0) {c/=b; break;}
        }
        fout<<a<<" "<<b<<"\n";
    }
    return 0;
}
