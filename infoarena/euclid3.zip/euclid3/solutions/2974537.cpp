#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

long long int t, i, a, b, c, d, x, y;

void euclid(long long int a, long long int b, long long int &d, long long int &x, long long int &y)
{
    if(b == 0)
    {
        d = a;
        x = 1;
        y = 1;
    }
    else
    {
        long long int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    fin >> t;
    for(i = 1; i <= t; i++)
    {
        fin >> a >> b >> c;
        euclid(a, b, d, x, y);
        if(c % d == 0)
            fout << x * (c / d) << ' ' << y * (c / d) << '\n';
        else
            fout << 0 << ' ' << 0 << '\n';
    }
    return 0;
}
