#include <iostream>
#include <cstdio>

using namespace std;

int n, a, b, c, d, k, l, ok=0, r, ln, kn;

void euclid(int a, int b)
{
    if(b && !ok) euclid(b, a%b);
    if(!b)
    {
        ok=1;
        k=1;
        l=0;
        d=a;
    }
    if(b && ok)
    {
        ln=k-l*(a/b);
        kn=l;
        l=ln;
        k=kn;
    }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%d %d %d", &a, &b, &c);
        euclid(a, b);
        if(a*k*(c/d)+b*l*(c/d)==c)
            printf("%d %d\n", k*(c/d), l*(c/d));
        else
            printf("0 0\n");
        ok=0;
    }
    return 0;
}
