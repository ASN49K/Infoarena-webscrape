#include <cstdio>


int euclid( int a, int b, int &x, int &y )
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x1,y1,nr;
    nr=euclid(b,a%b,x1,y1);
    x=y1;
    y=x1-(a/b)*y1;
    return nr;
}
int n,k1,k2,k3;
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    for (int i=1;i<=n;i++)
    {
        int k1,k2,k3;
        scanf("%d%d%d",&k1,&k2,&k3);
        int nr,x,y;
        nr=euclid(k1,k2,x,y);
        if (k3%nr)
        {
            printf("0 0\n");
        }
        else
        {
            printf("%d %d\n",x*(k3/nr),y*(k3/nr));
        }
    }
    return 0;
}
