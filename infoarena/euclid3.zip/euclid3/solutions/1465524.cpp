#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void euclid(int &a, int b, int &k){
    while(b){
        int r;
        r = a % b;
        a = b;
        b = r;
        k++;
    }
}

void solutii(int &a, int &b, int k){
    int i, x = 1, y = 0;
    for(i=k-1; i>=0; i--){
        a = y;
        b = x - y * i;
        x = a;
        y = b;
    }
}

int main()
{
    int n, a, b, c, k;

    fin >> n;
    while(n){
        fin >> a >> b >> c;

        k = 0;
        euclid(a, b, k);
        if(c % a != 0)
            fout<<"0 0"<<"\n";
        else{
            int x=0, y=0, d;
            d = c / a;
            solutii(x, y, k);
            fout<<x*d<<" "<<y*d<<"\n";
        }
        n --;
    }

    return 0;
}
