#include <iostream>
#include <fstream>

using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");
void euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main ()
{
   int n,a,b,c;
   cin>>n;
   for (int i=0; i<n; i++)
   {
    int x,y,d;
    in>>a>>b>>c;
    euclid(a,b,&d,&x,&y);
    if (c%d!=0)
        out<<0<<' '<<0<<'\n';
    else
        out<<x*(c/d)<<' '<<y*(c/d)<<'\n';
   }
    return 0;
}
