#include <fstream>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int euclid(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int d,x0,y0;
    d=euclid(b,a%b,x0,y0);

    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    int a,b,c,d,t,x,y;
    f>>t;
    while(t--)
    {
        f>>a>>b>>c;
        d=euclid(a,b,x,y);
        if(c%d!=0)
            g<<"0 0"<<'\n';
        else
            g<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }
}
