#include<fstream>

int main()
{
ifstream f;f.open("euclid.in");ofstream g;g.open("euclid.out");
float y;
long int k,m,a,b,x,ok,c,n;
f>>k;


while(k!=0)
{
f>>a>>b>>c;
m=a;n=b;
while(m!=n)
 if(m>n) m=m-n;
	else n=n-m;
x=0;
ok=0;
if(c%n!=0) g<<"0 0";
else
 while(ok==0)
	{
	float y = (float)(c-a*x)/b;
	if(y==(int) y) ok=1;
	else x++;
	if(x>2000000000) x=-2000000000;

	}
if(ok==1) g<<x<<" "<<y;
k--;
}
g.close();
f.close();
return 0;
}