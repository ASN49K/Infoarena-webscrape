#include <fstream>
using namespace std;

ifstream in ("euclid3.in");
ofstream out ("euclid3.out");

int t, a, b, c;

void euclid (int a, int b, int &x, int &y, int &d) {
	if (b == 0) {
		x = 1;
		y = 0;
		d = a;
		return;
	}
	int x1, y1, q = a / b;
	euclid (b, a % b, x1, y1, d);
	x = y1;
	y = x1 - q * y1;
}

void citire () {
	in >> t;
	for (; t--; ) {
		in >> a >> b >> c;
		int x, y, d;
		euclid (a, b, x, y, d);
		if (d % c == 0) {
			out << "0 0\n";
		} else {
			out << x * c / d << ' ' << y * c / d << '\n';
		}
	}
}

int main () {
	citire ();
	
	return 0;
}
