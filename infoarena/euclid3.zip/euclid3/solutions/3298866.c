#include <stdio.h>
//https://infoarena.ro/problema/euclid3
#define LL long long

LL euclid(LL a, LL b, LL *x, LL *y) {
    //base case
    if (b == 0) {
        *x = 1;
        *y = 0;
        return a;
    }
    LL x1, y1;
    LL d = euclid(b, a % b, &x1, &y1);
    *x = y1;
    *y = x1 -(a/b)*y1;
    return d;
}

int main() {
    FILE *in = fopen("euclid3.in", "r");
    FILE *out = fopen("euclid3.out", "w");

    int t;
    fscanf(in, "%d", &t);

    while (t--)
    {
        LL a, b, c, x, y;
        fscanf(in, "%lld %lld %lld", &a, &b, &c);

        LL d = euclid(a, b, &x, &y);
        if (c % d != 0)
            fprintf(out, "0 0\n");
        else {
            x *= c / d;
            y *= c / d;
            fprintf(out, "%lld %lld\n", x, y);
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}
