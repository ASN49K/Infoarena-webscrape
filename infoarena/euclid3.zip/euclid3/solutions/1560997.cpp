#include <fstream>

void gcd (int x, int y, int& d, int& a, int& b) {
    if (0 == y) {
        d = x;
        a = 1;
        b = 0;
    }
    else {
        int a0, b0;
        gcd (y, x % y, d, a0, b0);
        x = b0;
        y = a0 - (x / y) * b0;
    }
}

int main() {
    int T, x, y, a, b, c, d;
    std::ifstream in{"euclid3.in"};
    std::ofstream out{"euclid3.out"};

    for (in >> T; T; --T) {
        in >> x >> y >> c;
        gcd(x, y, d, a, b);

        if (c % d) {
            out << "0 0\n";
        }
        else {
            out << ((c / d) * x) << " " << ((c / d) * y) << "\n";
        }
    }

    return 0;
}
