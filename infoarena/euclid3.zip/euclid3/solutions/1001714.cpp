#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <climits>
#include <algorithm>
#include <cmath>
#include <queue>
#include <iomanip>
using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
#define baza 10
#define MAX 1000

typedef long long int lli;

lli n,sum;

void euclid(int a, int b, int* d, int *x, int* y)
{
    if(b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
        int x0, y0;
        euclid(b, a%b, d, &x0, &y0);
        *x=y0;
        *y=x0-(a/b)*y0;

    }
}


int main()
{
    int a, b, z, t, ki, c;
    fin>>t;
    for(ki=1;ki<=t;ki++)
    {
        fin>>a>>b>>c;
        int d, x1, x2;
        euclid(a,b,&d, &x1, &x2);

        if(c%d==0)
            fout<<x1*(c/d)<<" "<<x2*(c/d)<<"\n";
        else
            fout<<"0 0\n";


    }

    return 0;
}

