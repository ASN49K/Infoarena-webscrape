#include <fstream>
#include <stdio.h>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int T,a,b,c,d,x,y;

int euclid_extins(int a,int b,int &x,int &y){
    if(!b){
        x=1;
        y=0;
        return a;
    }
    else {
        int x0,y0;
        d=euclid_extins(b, a%b, x0, y0);
        x=y0;
        y=x0-(a/b)*y0;
        return d;
    }
}

void citire() {
    fin>>T;
    for(int i=0;i<T;i++) {
        fin>>a>>b>>c;
        d=euclid_extins(a,b,x,y);
        if(c%d)
            fout<<"0 0"<<"\n";
        else
            fout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
    }
    fin.close();
}

int main()
{
        citire();
        fout.close();
        return 0;
}
