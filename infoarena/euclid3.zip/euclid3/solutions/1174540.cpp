#include <fstream>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

int euclidExtins(int a, int b, int& x, int& y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    int nx, ny;
    int d = euclidExtins(b, a%b, nx, ny);
    x = ny;
    y = nx-(a/b)*ny;
    return d;
}

int main()
{
    int n;
    int a, b, c;
    int x, y, d;
    in >> n;
    for(int i = 0; i < n; i++)
    {
        in >> a >> b >> c;
        d = euclidExtins(a, b, x, y);
        if(c%d == 0)
        {
            out << (c/d)*x << " " << (c/d)*y << "\n";
        } else
        {
            out << "0 0\n";
        }
    }
}
