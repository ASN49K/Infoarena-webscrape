#include <fstream>

using namespace std;

ifstream cin ( "euclid3.in" );
ofstream cout ( "euclid3.out" );

void euclid(int a, int b, int *d, int *x, int *y)
 {
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{
    int a, b, c, x, y, n, i, z;
    cin >> n;
    for ( i = 1; i <= n; i++ ) {
       cin >> a >> b >> c;
       euclid( a, b, &z, &x, &y );
       if ( c % z != 0 )
        cout << "0 0\n";
       else
        cout << x * ( c / z ) << " " << y * ( c / z ) << "\n";
    }
    return 0;
}
