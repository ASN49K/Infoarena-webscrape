#include <bits/stdc++.h>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");


inline void euclid(int a, int b, int &d, int &x, int &y)
{
    if(!b)
    {
        d = a;
        x = 1; y = 0;
    }
    else
    {
        int x1,y1;
        euclid(b,a%b,d,x1,y1);
        x = y1;
        y = x1 - (a/b) * y1;
    }
}

int main()
{
     int t;
     f>>t;
     for(int i = 1; i <= t; i++)
     {
         int a,b,c,d,x,y;
         f>>a>>b>>c;
         euclid(a,b,d,x,y);
         if(c%d)
            g<<"0 0\n";
         else
            g<<x*(c/d)<<" "<<y*(c/d)<<"\n";
     }


    return 0;
}
