#include <iostream>
#include <fstream>
#include <assert.h>

using namespace std;

inline int euclidExtins(int a,int b,int &x,int &y)
{
    if (b==0)
    {
        x = 1;
        y = 0;
        return a;
    }

    int d;
    d = euclidExtins(b,a%b,x,y);

    int t = x;
    x = y;
    y = t - (a/b) * y;
    return d;
}

int main()
{
    int T;

    ifstream f;
    ofstream g;

    f.open("euclid3.in");
    g.open("euclid3.out");

    for (f>>T/*,assert(T<=100)*/;T;T--)
    {
        int a,b,c;
        f>>a>>b>>c;

        /*
        assert(-1000000000<=a && a<=1000000000);
        assert(-1000000000<=b && b<=1000000000);
        assert(-2000000000<=c && c<=2000000000 && c!=0);
        */

        int d,x,y;
        d = euclidExtins(a,b,x,y);

        if (c%d) g<<"0 0\n";
        else g<<x*c/d<<' '<<y*c/d<<'\n';
    }

    f.close();
    g.close();

    return 0;
}
