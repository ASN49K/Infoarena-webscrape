#include <bits/stdc++.h>

using namespace std;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

int n;


void euclid(long long a, long long b, long long &d, long long &x, long long &y)
{
    long long x0, y0;
    if(b == 0)
    {
        d = a;
        x = 1;
        y = 0;
    }
    else
    {
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    long long a, b, c, d;
    long long x, y;
    fin >> n;
    for(int i = 1 ; i <= n ; i++)
    {
        fin >> a >> b >> c;
        euclid(a, b, d, x, y);
        if(c % d == 0)
            fout << x * c / d << ' ' << y * c / d;
        else
             fout << "0 0";
        fout << '\n';
    }
    return 0;
}
