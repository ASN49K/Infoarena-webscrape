#include <bits/stdc++.h>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int T, a, b, c, x, y, gcd;

int ExtendedEuclid(int a, int b, int &x0, int &y0)
{
    if (b == 0)
    {
        x0 = 1;
        y0 = 0;
        return a;
    }
    else
    {
        int gcd = ExtendedEuclid(b, a % b, x0, y0);
        int x = y0;
        int y = x0 - a / b * y0;
        x0 = x;
        y0 = y;
        return gcd;
    }
}

int main()
{
    fin >> T;
    while (T--)
    {
        fin >> a >> b >> c;
        gcd = ExtendedEuclid(a, b, x, y);
        if (c % gcd == 0)
            fout << x * (c / gcd) << " " << y * (c / gcd) << "\n";
        else
            fout << "0 0\n";
    }
    return 0;
}
