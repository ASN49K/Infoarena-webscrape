#include <iostream>
#include <fstream>

using namespace std;

ifstream input("euclid3.in");
ofstream output("euclid3.out");

int gcd(int a, int b, int &x, int &y)
{
	if(b == 0)
	{
		x = 1;
		y = 0;
		return a;
	}
	else
	{
		int x0, y0, d;
		
		d = gcd(b, a%b, x0, y0);
		
		x = y0;
		y = x0 - (a/b) * y0;
		return d;
	}
}

int main()
{
	int n, a, b, c;
	
	input >> n;
	
	for(int i = 0; i < n; i++)
	{
		input >> a >> b >> c;
		
		int d, x, y;
		
		d = gcd(a, b, x, y);
		
		cout << c << " "<< d << endl;
		
		if(c%d)
		{
			output << "0 0\n";
		}
		else
		{
			output << x * (c/d) << " " << y * (c/d) << "\n";
		}
	}
	
	return 0;
}
