#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void euclid(int a, int b, int &x, int &y, int &d)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
        return;
    }
    int x0, y0, q;q=a/b;
    euclid(b,a%b,x0,y0,d);
    x=y0;y=x0-q*y0;
}

int main()
{
    int t;fin>>t;
    while(t--)
    {
        int a, b, c, x, y, d;
        fin>>a>>b>>c;
        euclid(a,b,x,y,d);
        if(c%d==0)fout<<c/d*x<<' '<<c/d*y<<'\n';
        else fout<<"0 0\n";
    }
    fin.close();
    fout.close();
    return 0;
}
