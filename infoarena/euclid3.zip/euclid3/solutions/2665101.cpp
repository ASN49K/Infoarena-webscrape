#include <fstream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

void euclid(long long a, long long b, long long *d, long long *x, long long *y)
{
    if(b == 0)
    {
        *d = a;
        *x = 1;
        *y = 0;
    }
    else
    {
        long long x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

long long t, a, b, c, X, Y, D, *x, *y, *d;

int main()
{
    f >> t;
    x = &X, y = &Y, d = &D;
    while(t--)
    {
        f >> a >> b >> c;
        
        euclid(a, b, d, x, y);

        if(c % D == 0)  g << X * c / D << ' ' << Y * c / D << '\n';
        else            g << 0 << ' ' << 0 << '\n';
        
    }
    return 0;
}