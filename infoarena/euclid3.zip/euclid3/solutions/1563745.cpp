#include <bits/stdc++.h>
using namespace std;
#define endl "\n"
const char* IN = "euclid3.in";
const char* OUT = "euclid3.out";

class Math {
    private :
        Math(){}
        ~Math(){}

    public :
        static int euclidExtended(int a,int b,int &x,int &y){
            if (b==0) {
                x = 1;
                y = 0;
                return a;
            }
            int x0,y0,gcd;
            gcd = euclidExtended(b,a%b,x0,y0);
            x = y0;
            y = x0 - a/b * y0;
            return gcd;
        }
};

int n,a,b,c,x,y,sol;
int main(void){
    ifstream cin(IN);
    ofstream cout(OUT);
    cin>>n;
    while(n--){
        cin>>a>>b>>c;
        sol = Math::euclidExtended(a,b,x,y);
        if (c%sol==0) cout<<x*c/sol<<" "<<y*c/sol<<endl;
              else cout<<"0 0"<<endl;
    }
    return 0;
}
