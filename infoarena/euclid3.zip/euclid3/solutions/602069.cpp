#include <stdio.h>


int cmmdc (int a, int b)
{
	
	while(a!=b)
	{
		if(a>b)
			a=a-b;
		else
			b=b-a;
	}
	
	return a;
}

 void rezolva_ec(int a, int b,int &d,int &x ,int &y )
{
	int x0,y0;

	if(b==0)
	{
		d = a;
		x = 1;
		y = 0;	
	}
	else
	{
		
		rezolva_ec(b,a%b,d,x0,y0);

		x=y0;
		y=x0-(a/b)*y0;
	}
}

 
int main()
{
	int T;
	
	FILE *f,*g;

	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	
	fscanf(f,"%d",&T);
	for(int i=0;i<T;i++)
	{
		int a,b,c;
		int d;

		fscanf(f,"%d %d %d",&a,&b,&c);
		
		int x,y;
		rezolva_ec(a,b,d,x,y);
		if(c%d)
				fprintf(g,"0 0\n");
			 else	  
				fprintf(g,"%d %d \n",x*(c/d),y*(c/d));
	  
	}
		
	scanf("%lf");
	return 0;
	
}