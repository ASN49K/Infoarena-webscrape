#include <fstream>
using namespace std;
ifstream cin;
ofstream cout;
int s(int a, int b, int& x, int& y)
{
	if (b == 0) { x = 1, y = 0; return a; }
		int x0, y0,d;
		d=s(b, a % b, x0, y0);
		x = y0;
		y = x0 - (a / b) * y0;
		return d;
}
signed main()
{
	int t, a, b, c;
	cin.open("euclid.in");
	cout.open("euclid.out");
	cin >> t;
	for (t; t > 0; t--)
	{
		cin >> a >> b >> c;
		int d,x,y;
		d = s(a, b, x, y);
		if (c % d)
			cout << 0 << " " << 0 << "\n";
		else cout << x * (c / d) << " " << y * (c / d)<<"\n";
	}
	cin.close();
	cout.close();
}