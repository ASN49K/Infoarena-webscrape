#include<cstdio>
#include<cstdlib>
using namespace std;
int t,a,b,c;
int euclid(int a,int b,int &x,int &y)
{int x0,y0;
if(b==0) {x=1;y=0;return a;}

else{
int f=euclid(b,a%b,x0,y0);
x=y0;
y=x0-(a/b)*y0;
return f;}
}
int main()
{freopen("euclid3.in","r",stdin);
freopen("euclid3.out","w",stdout);
scanf("%d",&t);
for(;t;t--)
{scanf("%d %d %d",&a,&b,&c);
 int d,x,y;
 d=euclid(a,b,x,y);
 if(c%d==0) printf("%d %d \n",x*(c/d),y*(c/d));
 else printf("0 0 \n");
}

      return 0;
}
