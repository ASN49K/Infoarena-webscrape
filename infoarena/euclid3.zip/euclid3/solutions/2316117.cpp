#include <bits/stdc++.h>
using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");
int euclid(int a,int b,int &x,int &y)
{
    if(!b)
    {
        x=1;y=0;
        return a;
    }
    int x0,y0,d;
    d=euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    int t,a,b,c,d,x,y;
    in>>t;
    while(t--)
    {
        in>>a>>b>>c;
        d=euclid(a,b,x,y);
        if(c%d)
            out<<"0 0\n";
        else
            out<<x*(c/d)<<" "<<y*(c/d)<<"\n";
    }
    return 0;
}
