// 100 Puncte
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

int gcd (int a, int b, int &x, int &y) {
    if (b==0) {
        x=1; y=0;
        // cout<<a<<'*'<<x<<'+'<<b<<'*'<<y<<'='<<a<<endl;
        return a;
    }
    else {
        int x1, y1;
        int d = gcd(b, a % b, x1, y1);
        x = y1;
        y = x1 - y1 * (a / b);
        // cout<<a<<'*'<<x<<'+'<<b<<'*'<<y<<'='<<d<<endl;
        return d;
    }
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int t; fin>>t;
    while (t--) {
        int a, b, c; fin>>a>>b>>c;
        int x, y; int d = gcd(a, b, x, y);
        // cout<<endl;
        int rap = c / d;
        if (c%d!=0) {
            fout<<"0 0\n";
            continue;
        }
        else {
            x*=rap; y*=rap;
            fout<<x<<' '<<y<<'\n';
        }
    }
    return 0;
}