#include <bits/stdc++.h>

using namespace std;

void euclid(int a, int b, int &d, int &x, int &y)
{
    if (b == 0)
    {
        d = a;
        x = 1;
        y = 0;
    }
    else
    {
        int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    ifstream fin("euclid3.in");
    ofstream fout("ieuclid3.out");
    int T, a, b, c, d, x, y;
    fin >> T;
    while (T > 0)
    {
        fin >> a >> b >> c;
        euclid(a, b, d, x, y);
        if (c % d == 0) // daca sol intregi
        {
            x *= c / d;
            y *= c / d;
            fout << x << " " << y << endl;
        }
        else
        {
            fout << 0 << " " << 0 << endl;
        }

        T--;
    }

    return 0;
}