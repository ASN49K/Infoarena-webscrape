#include<fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
long long x,y,d;
inline void eucl(long long  a,long long b)
{int tmp=y;
	if (!b)
	{   x=1;
		y=0;
		d=a;
		return;
	}
	eucl(b,a%b);
	y=x-(a/b)*y;
	x=tmp;
}
int main()
{long long n,a,b,c,i;
	fin >> n;
	for (i=1;i<=n;++i)
	{	fin >> a >> b >> c;
		eucl(a,b);
		if(c%d)
			fout << "0 0 /n";
		else
			fout << x*c/d << " " << y*c/d << '\n';
	}
	return 0;
}

