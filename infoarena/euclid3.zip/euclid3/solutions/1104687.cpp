/*
Se dau T ecuatii de forma a * x + b * y = c, cu coeficientii
a, b si c. Pentru fiecare dintre aceste ecuatii se cere aflarea
unei perechi de numere intregi x y care sa satisfaca ecuatia,
in cazul in care o astfel de pereche exista.

euclid3.in
3
24 15 147
24 16 104
2 4 5

euclid3.out
33 -43
33 -43
0 0
*/

#include<cstdio>

int n;
int d;

int cmmdc(int a,int b)
{
    int c;
    while(b)
    {
        c=a%b;
        a=b;
        b=c;
    }
    return a;
}

void euclid(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        int x0;
        int y0;
        euclid(b,a%b,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    FILE *f=fopen("euclid3.in","r");
    FILE *g=fopen("euclid3.out","w");
    fscanf(f,"%d",&n);
    while (n)
    {
        int a;
        int b;
        int c;
        fscanf(f,"%d%d%d",&a,&b,&c);
        d=cmmdc(a,b);
        if (c%d==0)
        {
            int x;
            int y;
            euclid(a,b,x,y);
            fprintf(g,"%d %d\n",x*(c/d),y*(c/d));
        }
        else fprintf(g,"0 0\n");
        n--;
    }
    fclose(f);
    fclose(g);
    return 0;
}
