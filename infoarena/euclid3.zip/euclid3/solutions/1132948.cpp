#include<fstream>
using namespace std;
long long int a,b,c,x,y,d;
ifstream f("euclid3.in");
ofstream g("euclid3.out");

void euclid(long long int a,long long int b,long long int &d,long long int &x,long long int &y){
	if(b==0){
		d=a;
		x=1;
		y=0;
	}
	else{
		long long int x0,y0;
		euclid(b,a%b,d,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}
int cmmdc(long int a,long int b){
	if(b==0)
		return a;
	else
		return cmmdc(b,a%b);
}
int main (){
	f>>a>>b>>c;
	d=cmmdc(a,b);
	if(c%d!=0)
		g<<0<<" "<<0;
	else
	{
		euclid(a,b,d,x,y);
		g<<x*(c/d)<<" "<<y*(c/d);
	}
	return 0;
}