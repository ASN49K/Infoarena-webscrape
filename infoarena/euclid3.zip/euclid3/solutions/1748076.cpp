#include <fstream>
#include <tuple>
#include <type_traits>

template <typename T>
struct euclid{
	using ResultType = std::tuple<T,T,T>;
	static ResultType extended_euclid(T a, T b)
	{
		if (b == 0) {
			return ResultType{T(1), T(0), a};
		}
		T x0, y0, d;
		std::tie(x0, y0, d) = extended_euclid(b, a % b);
		return ResultType{y0, x0 - (a / b) *y0, d};
	}
};

int main()
{
	int T;
	using IntDomain = int32_t;
	IntDomain a,b,c, x, y, d;
	std::ifstream fin("euclid3.in");
	std::ofstream fout("euclid3.out");

	fin >> T;
	while (T--) {
		fin >> a >> b >> c;
		std::tie(x,y,d) = euclid<IntDomain>::extended_euclid(a, b);
		if (c % d != 0) {
			fout << "0 0\n";
		}
		else {
			fout << x * (c / d) << " " << y * (c / d) << "\n";
		}
	}

	fin.close();
	fout.close();
	return 0;
}