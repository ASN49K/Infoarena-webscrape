#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int a,b,x,y,d,t,i,c;

void euclid_ext (int a, int b, int &x, int &y,int &d)
{
    if(b==0) { x=1; y=0; d=a; }
    else{

    int xp=0, yp=0;

    euclid_ext(b, a%b, xp, yp, d);

    x=yp;
    y=xp-(a/b)*yp;

    }
}

int main()
{
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>a>>b>>c;
        euclid_ext(a,b,x,y,d);

        if (c%d!=0) fout<<"0 0"<<'\n';
        else fout<<x*c/d<<" "<<y*c/d<<'\n';

    }

    return 0;
}
