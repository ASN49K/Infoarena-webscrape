#include <bits/stdc++.h>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int n;

int gcd(int a, int b, int &x, int &y){
    if(!b){
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0, D;
    D = gcd(b,a%b,x0,y0);

    x = y0;
    y = x0 - (a / b) * y0;
    return D;
}

int main(){
    int a,b,c;
    f >> n;
    while(n){
        int d,x,y;
        f >> a >> b >> c;
        d = gcd(a,b,x,y);
        if(c % d)
            g << 0 << " " << 0 << "\n";
        else
            g << x * (c / d) << " " << y * (c / d) << "\n";

        n--;
    }


    return 0;
}
