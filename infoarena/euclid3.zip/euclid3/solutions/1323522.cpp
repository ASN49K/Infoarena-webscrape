#include <fstream>
 
using namespace std;
void euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}
 
int main()
{fstream f("euclid3.in");
ofstream g("euclid3.out");
int a,b,c,d,i;
for(f>>i;i;--i)
{f>>a>>b>>c;
euclid(a,b,&d,&a,&b);
if(c%d==0)
    g<<a*c/d<<' '<<b*c/d<<'\n';
    else g<<0<<' '<<0<<'\n';
}
}
