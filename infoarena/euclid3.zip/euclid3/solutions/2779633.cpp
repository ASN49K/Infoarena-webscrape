#include <bits/stdc++.h>
using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int n,d,x,y;

int euclid(int a, int b, int &x, int &y)
{
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0, d;      
    d = euclid(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main(){
    fin >> n ;
    for(int i=1; i<=n; i++){
        int a,b,c;
        fin >> a >> b >> c;
        int d,x,y;
        d= euclid(a,b,x,y);
        if(c%d) fout << "0 0" << endl;
        else fout << x*(c/d) << ' ' << y*(c/d) << endl;
    }
    return 0;
}