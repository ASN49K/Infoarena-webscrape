#include<fstream>
using namespace std;
ifstream F("euclid3.in");
ofstream G("euclid3.out");
int a,b,c,d,e,f,g,h,r,w,s,t,q;
int main()
{
	for(F>>a;F>>a>>b>>w;G<<(w%c?0:w/c*d)<<' '<<(w%c?0:w/c*e)<<'\n')
	    for(c=a,r=b,d=1,s=0,e=0,t=1;r;q=c/r,f=r,r=c-q*r,c=f,g=s,s=d-q*s,d=g,h=t,t=e-q*t,e=h);
    return 0;
}
