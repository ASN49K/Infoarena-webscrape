#include <fstream>
#define int long long

using namespace std;

ifstream cin ("euclid3.in");
ofstream cout ("euclid3.out");

int n, a, b, c, x, y;

int exteuclid (int a, int b, int& x, int & y)
{
    if (!b)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int d = exteuclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - a / b * y1;
    return d;
}

signed main()
{
    for (cin >> n; n ; --n)
    {
        cin >> a >> b >> c;
        int d = exteuclid(a, b, x, y);
        if (c % d)
        {
            cout << "0 0\n";
        }
        else
            cout << x * c / d << ' ' << y * c / d << '\n';
    }
    return 0;
}
