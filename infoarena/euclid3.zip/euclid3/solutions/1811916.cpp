# include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
long long t,a,b,c,d,x,y,i;
long long euclid(long long a,long long b,long long &x,long long &y){
    long long r,xa,ya;
    if(!b){
        x=1;
        y=0;
        return a;
    }
    r=euclid(b,a%b,xa,ya);
    x=ya;
    y=xa-(a/b)*ya;
    return r;
}
int main () {
    fin>>t;
    for(i=1;i<=t;i++){
        fin>>a>>b>>c;
        d=euclid(a,b,x,y);
        if(c%d!=0){
            fout<<"0 0\n";
            continue;
        }
        fout<<x*c/d<<" "<<y*c/d<<"\n";
    }
    return 0;
}
