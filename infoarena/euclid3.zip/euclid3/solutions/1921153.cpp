#include <fstream>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int w;
int cmmdc(int a,int b)
{
    while(b)
    {
        w=a%b;
        a=b;
        b=w;
    }
    return a;
}
void euclid(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        int x0,y0;
        euclid(b,a%b,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int main()
{
    int t,a,b,c,d,e,x,y;
    f>>t;
    for(int q=1;q<=t;q++)
    {
        f>>a>>b>>c;
        e=cmmdc(a,b);
        if(c%e==0)
        {
            euclid(a,b,x,y);
            e=c/e;
            g<<x*e<<" "<<y*e<<'\n';
        }
        else
            g<<"0 0"<<'\n';
    }
    return 0;
}
