#include<stdio.h>
int tc;
int sir[15000];
int contor;
int x;
int y;
int cmmdc;
void PreCalcul(int aux1, int aux2) // se calculeaza iterativ sirul valorilor a / b
{
    sir[0] = 0;

    while (aux2 != 0)
          {
              sir[++sir[0]] = aux1 / aux2;
              int e3 = aux1;
              aux1 = aux2;
              aux2 = e3 % aux2;
          }
    cmmdc = aux1;    // se retine cmmdc(a,b) pentru a fi utilizat la final
}
void Rezolva()      // se calculeaza x,y in functie de sirul calculat in PreCalcul()
{
     while (sir[0] != 0)
          {
              int aux = x;
              x = y;
              y = aux - sir[sir[0]] * y;
              sir[0]--;
          }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);

    scanf("%d",&tc);
    for(; tc; tc--)
     {
         int a, b, c;
         scanf("%d %d %d", &a, &b, &c);
         PreCalcul(a, b);
         x = 1;
         y = 0;
         Rezolva();
         if (c % cmmdc)
                 printf("0 0\n");
            else
             printf("%d %d\n", x * (c / cmmdc), y * (c / cmmdc));
     }
    return 0;
}
