#include<stdio.h>
FILE *f=fopen("euclid3.in","r"),
     *g=fopen("euclid3.out","w");
int euclid(int a,int b,int &x,int &y)
{ if(b==0) { x=1;
             y=0;
             return a;
             }
  int x0,y0,d;
  d=euclid(b,a%b,x0,y0);
  x=y0;
  y=x0-(a/b)*y0;
  return d;
}
int d,i,n,x,y,a,b,c;
int main()
{ fscanf(f,"%d",&n);
  for(i=1;i<=n;++i){ fscanf(f,"%d %d %d",&a,&b,&c);
                     d=euclid(a,b,x,y);
                     if(c%d) fprintf(g,"0 0\n");
                     else fprintf(g,"%d %d\n",x*(c/d),y*(c/d));
                     }
  fclose(f);
  fclose(g);
  return 0;
}
