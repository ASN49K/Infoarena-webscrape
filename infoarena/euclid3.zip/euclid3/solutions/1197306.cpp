#include <cstdio>
using namespace std;

int main()
{
    int t, a, b, c, cat[32], x, y, nc, r, i;
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);
    scanf("%d", &t);
    while(t--){
        scanf("%d%d%d", &a, &b, &c);
        nc = 0;
        while(b!=0){
            r = a%b;
            cat[++nc] = a/b;
            a = b;
            b = r;
        }
        x = 1; y = 0;
        for(i=nc; i>=1; i--){
            r = x;
            x = y;
            y = r - cat[i]*y;
        }
        if(c%a==0)
            printf("%d %d\n", x*(c/a), y*(c/a));
        else
            printf("0 0\n");

    }
    return 0;
}
