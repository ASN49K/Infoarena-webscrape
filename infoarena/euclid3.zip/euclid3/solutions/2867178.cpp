#include <bits/stdc++.h>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int t, a, b, c, d, x, y;
void citire();
int euclid(int a, int b, int& x, int &y);
int main()
{
    citire();
    return 0;
}
int euclid(int a, int b, int& x, int &y)
{
    int x1, y1;
    if (b==0) {x=1; y=0; return a;}
    int d=euclid(b, a%b, x1, y1);
    x=y1;
    y=x1-y1*(a/b);
    return d;
}
void citire()
{
    int i;
    fin>>t;
    for (i=1; i<=t; i++)
    {
        fin>>a>>b>>c;
        d=euclid(a,b,x,y);
        if(c%d!=0) fout<<0<<' '<<0<<'\n';
        else
        {
            fout<<x*(c/d)<<' '<<y*(c/d)<<'\n';
        }
    }
}
