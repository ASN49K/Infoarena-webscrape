#include<stdio.h>
int a,b,c,x,y,d,g,t;
int E(int a,int b) { return !b?a:E(b,a%b); }
void W(int a,int b,int *x,int *y) {
	int p,r;
	if(!b)
    	*x=1,*y=0;
	else
    	W(b,a%b,&p,&r),*x=r,*y=p-a/b*r;
}
int main() {
	freopen("euclid3.in","r",stdin),freopen("euclid3.out","w",stdout),scanf("%d",&t);
	while(t--) {
		scanf("%d%d%d",&a,&b,&c),d=E(a,b);
      	if(c%d)
            printf("0 0\n");
      	else
            W(a,b,&x,&y),g=c/d,printf("%d %d\n",x*g,y*g);
	}
}
