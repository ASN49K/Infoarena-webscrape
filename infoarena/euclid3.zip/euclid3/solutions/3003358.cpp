#include <bits/stdc++.h>

#define MAX 100000
#define FILES freopen("euclid3.in","r",stdin);\
              freopen("euclid3.out","w",stdout);
#define mod 666013

using namespace std;

int a, b, c, t;

void euclid_extins(int a, int b, int &x, int &y)
{
    if(b == 0)
        x = 1, y = 0;
    else
    {
        int x0, y0;
        euclid_extins(b, a % b, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    FILES
    std::cin >> t;
    while(t--)
    {
        std::cin >> a >> b >> c;
        if(c % __gcd(a, b))
        {
            std::cout << "0 0\n";
            continue;
        }
        int x, y;
        euclid_extins(a, b, x, y);
        std::cout << x * (c / __gcd(a, b)) << ' ' << y * (c / __gcd(a, b)) << '\n';
    }
}
