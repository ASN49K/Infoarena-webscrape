#include<fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
long long t,a,b,c,r1,r2,r3;
void gcd(int a,int b,long long &r1,long long &r2,long long &r3)
{
	if(b==0)
	{
		r1=a;
		r2=1;
		r3=0;
		//cout<<a<<' '<<b<<' '<<r2<<' '<<r3<<'\n';
		return;
	}
	long long r4,r5;
	gcd(b,a%b,r1,r4,r5);
	long long d=a/b;
	r2=r5;
	r3=r4-d*r5;

	//cout<<a<<' '<<b<<' '<<r2<<' '<<r3<<'\n';
}
int main()
{
	fin>>t;
	while(t--)
	{
		fin>>a>>b>>c;
		gcd(a,b,r1,r2,r3);
		if(c%r1)
		{
			fout<<0<<' '<<0<<'\n';
			continue;
		}
		//cout<<r1<<' '<<r2<<' '<<r3<<'\n';
		c/=r1;
		r2*=c;
		r3*=c;
		fout<<r2<<' '<<r3<<'\n';
	}
}
