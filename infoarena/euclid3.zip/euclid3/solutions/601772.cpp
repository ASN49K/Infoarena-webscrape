#include <stdio.h>
int x,y;


int cmmdc (int a, int b)
{
	if(a<0) 
		a = -a;
	if(b<0)
		b = -b;

	if(b!=0)
	while(a!=b)
	{
		if(a>b)
			a=a-b;
		else
			b=b-a;
	}
	
	return a;
}


int rezolva_ec(int a, int b, int &d, int &x, int &y)
{
	int a0,b0,x0,y0,r;
	
	if(b==0)
	{
		d = a;
		x = 1;
		y = 0;
		return 1;
	}
	
	r = a % b;
	a0 = b;
	b0 = r;

	rezolva_ec(a0,b0,d,x0,y0);
    
	x=y0;
	y=x0-(a/b)*y0;


	return 1;
}


int main()
{
	int T;
	int a,b,c;
	int d;
	FILE *f,*g;

	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	
	fscanf(f,"%d",&T);
	for(int i=0;i<T;i++)
	{
		fscanf(f,"%d %d %d",&a,&b,&c);
		d = cmmdc(a,b);
	
		if(c%d)
		{
			int z0 = 0;
			fprintf(g,"%d %d\n",z0,z0);
		}
		else
		{
			rezolva_ec(a,b,d,x,y);
			fprintf(g,"%d %d \n",(x*c)/d,(y*c)/d);
			//printf("%d %d \n",(x*c)/d,(y*c)/d);
			printf("\n");
		}	
	}
	
	fclose(f);
	fclose(g);
	return 0;
}
