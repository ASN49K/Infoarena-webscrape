#include <stdio.h>
long a,b,c,d,x,y,i,t;
void euclid3xtins(long a,long b,long &d,long &x,long &y){
	if(b==0){
		d=a;
		x=1;
		y=0;
	}
	else{
		long x0,y0;
		euclid3xtins(b,a%b,d,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}
int main(){
	FILE *f,*g;
	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	fscanf(f,"%ld",&t);
	for(i=1;i<=t;i++){
		fscanf(f,"%ld%ld%ld",&a,&b,&c);
		euclid3xtins(a,b,d,x,y);
		if(c%d) fprintf(g,"0 0\n");
		else fprintf(g,"%ld %ld\n",x,y);
	}
	fclose(f);
	fclose(g);
	return 0;
}
