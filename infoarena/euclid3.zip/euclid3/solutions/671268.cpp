#include <stdio.h>
#include <fstream>

int euclid(int a, int b, int &x, int &y)
{
	if (b == 0) {
		x = 1;
		y = 0;
		return a;
	}

	int x0, y0, d;

	d = euclid(b, a % b, x, y);

	x = y0;
	y = x0 - (a / b) * y0;

	return d;
}

void solve(std::ofstream &f, int a, int b, int c)
{
	int x, y;
	int d = euclid(a, b, x, y);

	if (c % d) {
		f << "0 0\n";
		return;
	} else 
		f << x * (c / d) << " " << y * (c / d);
}

int main()
{
	int t, a, b, c;
	std::ifstream fin("euclid3.in");
	std::ofstream fout("euclid3.out");

	fin >> t;
	for (int i = 0; i < t; i++) {
		fin >> a;
		fin >> b;
		fin >> c;

		solve(fout, a, b, c);
	}

	return 0;
}
