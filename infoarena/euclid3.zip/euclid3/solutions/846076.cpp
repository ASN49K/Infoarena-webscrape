#include <stdio.h>
#include <algorithm>
using namespace std;
void OpenFiles(int);
void Euclid(int,int,int&,int&,int&);

int main(int arg,char *argv[])
{
	OpenFiles(arg);
		int n,a,b,c,d,x,y;
		scanf("%d",&n);
		while(n--)
		{
			scanf("%d %d %d",&a,&b,&c);
			Euclid(a,b,d,x,y);
			if(c%d==0)printf("%d %d\n",(c/d)*x,(c/d)*y);
			else 
			printf("0 0\n");
		}
	return 0;
}

void Euclid(int a,int b,int &d,int &x,int &y)
{
	if(b==0)
	{
		d=a;
		x=1;
		y=0;
	} else
	{
		int x0,y0;
		Euclid(b,a%b,d,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}

void OpenFiles(int arg)
{
	freopen("euclid3.in","r",stdin);
	if(arg==0)
	{
		freopen("euclid3.out","w",stdout);
	}
}
