#include <fstream>

using namespace std;

ifstream cin("euclid3.in");
ofstream cout("euclid3.out");

int euclid(int a, int b, int& x, int &y){
    if(b == 0){
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0, d;

    d = euclid(b, a%b, x0, y0);

    x = y0;
    y = x0-(a/b) * y0;

    return d;
}
int main(){
    int t;
    cin >> t;
    for(int i = 0; i < t; ++i){
        int a, b, c;
        cin >> a >> b >> c;
        int x, y;
        int d = euclid(a, b, x, y);
        if(c % d) cout << "0 0\n";
        else cout << x*(c/d) << " " << y*(c/d) << '\n';

    }
    return 0;
}
