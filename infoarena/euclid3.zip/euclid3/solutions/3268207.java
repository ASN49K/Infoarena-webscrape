import java.io.*;
import java.util.StringTokenizer;

public class Main {

  public static int euclid(int a, int b, int[] k) {
    if (b == 0) {
      k[0] = 1;
      k[1] = 0;
      return a;
    }

    int d = euclid(b, a % b, k);
    int t = k[1];
    k[1] = k[0] -  (a/b) * k[1];
    k[0] = t;
    return d;
  }

  public static void main(String[] args) throws IOException {
    try (BufferedReader reader = new BufferedReader(new FileReader("euclid3.in"), 1 << 12);
         PrintWriter writer = new PrintWriter(new FileOutputStream("euclid3.out"), true)) {
      int T = Integer.parseInt(reader.readLine());

      int[] k = new int[] {0, 0};

      for (int i = 0; i < T; i++) {
        StringTokenizer st = new StringTokenizer(reader.readLine());
        int a = Integer.parseInt(st.nextToken());
        int b = Integer.parseInt(st.nextToken());
        int c = Integer.parseInt(st.nextToken());

        k[0] = 0;
        k[1] = 0;

        int d = euclid(a, b, k);
        if (c % d != 0) {
          writer.write("0 0\n");
        } else {
          int factor = c / d;
          writer.write(k[0] * factor + " " + k[1] * factor + "\n");
        }
      }
    }
  }
}
