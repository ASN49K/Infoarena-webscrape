#include <cstdio>

using namespace std;

long a,b,c,d,x,y;

int gcd(long a, long b, long *x, long *y) {
    if (b == 0) {
        *x = 1; *y = 0;
        return a;
    }

    long d,x0,y0;

    d = gcd(b, a % b, &x0, &y0);
    *x = y0;
    *y = x0 - (a / b) * y0;

    return d;
}

int main()
{
    freopen("euclid3.in","rt",stdin);
    freopen("euclid3.out","wt",stdout);
    scanf("%ld %ld %ld",&a,&b,&c);
    d=gcd(a,b,&x,&y);
    if(c%d)
        printf("0 0\n");
    else
        printf("%ld %ld\n",x*(c/d),y*(c/d));
    return 0;
}
