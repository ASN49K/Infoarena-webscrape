#include <cstdlib>
#include <cstdio>
using namespace std;

#define FIN "euclid3.in"
#define FOUT "euclid3.out"

int euclid(int a, int b, int &x, int &y)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
		return a;
	}
	int x0, y0, d;
	d = euclid( b, a%b, x0, y0 );
	x = y0;
	y = x0 - (a/b)*y0;
	return d;
}

int main()
{
	freopen(FIN,"r",stdin);
	freopen(FOUT,"w",stdout);
	
	int T,a,b,c,x,y,d;
	
	scanf("%d ",&T);
	for (;T;--T)
	{
		scanf("%d %d %d ",&a,&b,&c);
		
		d = euclid(a,b,x,y);
		if (c%d)
			printf("0 0\n");
		else
			printf("%d %d\n", x*(c/d), y*(c/d));
		
	}
	
	return 0;
}