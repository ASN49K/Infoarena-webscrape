#include <iostream>
#include <fstream>

using namespace std;

typedef long long ll;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

ll qry, a, b, c, d, yy, xx;

ll gcd(ll a, ll b, ll &x, ll &y)
{
    if(!b)
    {
        x=y=1;
        return a;
    }
    ll rez, y1, x1;
    rez=gcd(b, a%b, x1, y1);
    x=y1;
    y=x1-a/b*y1;
    return rez;
}

int main()
{
    in>>qry;
    while(qry--)
    {
        in>>a>>b>>c;
        d=gcd(a, b, xx, yy);
        if(c%d) out<<"0 0\n";
        else out<<xx*(c/d)<<' '<<yy*(c/d)<<'\n';
    }
    return 0;
}
