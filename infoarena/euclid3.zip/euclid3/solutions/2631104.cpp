#include <stdio.h>

int gcdExtended(int a, int b, int & x, int & y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0;
    int d = gcdExtended(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main() {
    FILE * fin, * fout;
    int t, a, b, c;

    fin = fopen("euclid3.in", "r");
    fout = fopen("euclid3.out", "w");

    fscanf(fin, "%d", &t);
    for (int i = 0; i < t; i++) {

        fscanf(fin, "%d%d%d", &a, &b, &c);
        int x, y;
        int d =  gcdExtended(a, b, x, y);

        if (c % d) {
            fprintf(fout, "0 0\n");
        } else {
            fprintf(fout, "%d %d\n", x * (c / d), y * (c / d));
        }
    }

    fclose(fin);
    fclose(fout);

    return 0;
}