
#include <fstream>

using namespace std;

ifstream fin  ("euclid3.in");
ofstream fout ("euclid3.out");

long long teste, t, a, b, c, x, y, k;

inline long long euclidpp (long long a, long long b, long long &x, long long &y){
    long long xa, ya, d;
    if (b == 0){
        y = 0, x = 1;
        return a;
    }
    else{
        d = euclidpp (b, a%b, xa, ya), x = ya, y = xa - a/b*ya;
        return d;
    }
}

int main(){
    fin >> teste;
    for (t=1; t<=teste; t++){
        fin >> a >> b >> c;
        k = euclidpp (a, b, x, y);
        (c%k == 0 ? fout << x*c/k << " " << y*c/k << "\n" : fout << "0 0\n");
    }
    return 0;
}
