#include <iostream>
#include<fstream>
using namespace std;
int a,b,i,x[100],y[100],D,c,d,t;
int gcde(int A,int B,int i)
{
    if(B==0)
    {
        x[i]=1;
        y[i]=0;
        return A;
    }
    d=gcde(B,A%B,i+1);
    x[i]=y[i+1];
    y[i]=x[i+1]-(A/B)*y[i+1];
    return d;

}
int main()
{
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");
    f>>t;
    for(int cnt=1;cnt<=t;cnt++)
    {
        f>>a>>b>>c;
        D=gcde(a,b,1);
        cout<<x[1]<<' '<<y[1]<<' '<<D<<'\n';
        if(c%D!=0) {g<<'0'<<' '<<'0'<<'\n';}
        else g<<x[1]*(c/D)<<' '<<y[1]*(c/D)<<'\n';
    }
    return 0;
}
