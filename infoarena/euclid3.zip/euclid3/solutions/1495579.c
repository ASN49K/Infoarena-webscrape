#include <stdio.h>

void euclidExtins(int a, int b, int *d, int *x, int *y)
{
    if (b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
        int x0,y0;
        euclidExtins(b,a%b,d,&x0,&y0);
        *x=y0;
        *y=x0-(a/b)*y0;
    }
}

int main()
{
    int n,i,a,b,c,d,x,y;
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);

    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        euclidExtins(a,b,&d,&x,&y);
        if (c%d!=0)
            printf("0 0\n");
        else
            printf("%d %d\n",x*(c/d),y*(c/d)); //daca c e multiplul a lui d
    }

    return 0;
}
