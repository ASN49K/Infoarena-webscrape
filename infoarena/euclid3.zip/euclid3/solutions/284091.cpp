#include <stdio.h>
long a,b,d,x,y,t,i,c;

long euclid(long a, long b, long &x, long &y)
{
    if (b == 0) {
     x = 1;
     y = 0;
     return a;
		} else
		  {
		   long x0, y0,d;
		   d=euclid(b, a % b, x0, y0);
		   x = y0;
		   y = x0 - (a / b) * y0;
		   return d;
		  }
}

int main()
{freopen("euclid3.in","r",stdin);freopen("euclid3.out","w",stdout);
 scanf("%ld",&t);
 for(i=1;i<=t;i++)
  {scanf("%ld%ld%ld",&a,&b,&c);x=0;y=0;
   d=euclid(a,b,x,y);
   if(c%d==0)
   printf("%ld %ld\n",x*(c/d),y*(c/d));
	    else printf("0 0\n");
  }
 fclose(stdin);fclose(stdout);
 return 0;
}