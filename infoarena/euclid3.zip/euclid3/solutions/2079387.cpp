#include <iostream>
#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int a, b, c, x, y, dd, d;

int euclid (int a, int b, int &x, int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0, y0;
    d = euclid (b, a%b, x0, y0);
    x = y0;
    y = x0 - (a/b) * y0;
    return d;
}


int main()
{
    int t;
    f>>t;
    while (t--)
    {
        f>>a>>b>>c;
        dd = euclid (a,b,x,y);
        if (c%dd)
            g<<"0 0\n";
        else
            g<< 1LL*x*c/dd << ' ' << 1LL*y*c/dd<<'\n';
    }
    return 0;
}
