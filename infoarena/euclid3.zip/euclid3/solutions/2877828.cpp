#include <bits/stdc++.h>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
#define cin f
#define cout g
void euclid(int a, int b, int *d, int *x, int *y)
{
	if(b == 0)
	{
		*x = 1;
		*y = 0;
		*d = a;
	}
	else
	{
		int x0, y0;
		euclid(b, a % b, d, &x0, &y0);
		*x = y0;
		*y = x0 - (a / b) * y0;
	}
}
void solve()
{
	int a, b, c;
	cin >> a >> b >> c;
	int x, y, d;
	euclid(a, b, &d, &x, &y);
	if(c % d == 0)
	{
		x *= c / d;
		y *= c / d;
		cout<<x<<" "<<y<<'\n';
	}
	else
		cout<<0<<" "<<0<<'\n';
}
int main()
{
	int t; cin >> t;
	while(t--)
	{
		solve();
	}
	return 0;
}