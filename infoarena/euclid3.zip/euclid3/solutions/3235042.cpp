#include <fstream>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
void euclid(int a, int b, int &d, int &x, int &y)
{
    if (b == 0) {
        d = a;
        x = 1;
        y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}
int T, a, b, c, x, y, d;
int main()
{
    fin >> T;
    x=1; y=0;
    for(int i=1; i<=T; i++)
    {
        fin >> a >> b >> c;
        x=1; y=0;
        euclid(a, b, d, x, y);
        if(c%d==0)
        {
            fout << x*c/d << " " << y*c/d << endl;
        }
        else
            fout << "0 0" << endl;
    }

    return 0;
}
