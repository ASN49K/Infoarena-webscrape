#include <stdio.h>
#include <stdlib.h>

void euclidExtins(int a, int b, int *x, int *y, int *gcd)
{
    int aux;

    if(b == 0 )
    {
        (*x) = 1;
        (*y) = 0;
        (*gcd) = a;
    }
    else
    {
        euclidExtins(b, a%b, x, y, gcd);
        aux = (*x);
        (*x) = (*y);
        (*y) = aux - a/b * (*y);
    }
}

int main()
{
    int a,b,c,d,x,y, n,i;

    FILE *f = fopen("euclid3.in", "r");
    FILE *g = fopen("euclid3.out", "w");
    fscanf(f,"%d",&n);

    for(i=0;i<n;i++)
    {
        fscanf(f, "%d %d %d", &a, &b, &c);
        euclidExtins(a,b,&x,&y, &d);
        if( c%d == 0)
            fprintf(g, "%d %d\n", x*(c/d), y*(c/d));
        else
            fprintf(g, "0 0\n");
    }

    fclose(f);
    fclose(g);

    return 0;
}
