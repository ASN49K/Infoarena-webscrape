#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int64_t exeuclid(int64_t a, int64_t b, int64_t *x, int64_t *y) {
    if (b == 0) {
        *x = 1;
        *y = 0;
        return a;
    }
    int64_t x1, y1;
    int64_t g = exeuclid(b, a % b, &x1, &y1);
    *x = y1;
    *y = x1 - (a / b) * y1;
    return g;
}

int main() {
    int64_t a, b, c, x, y;
    FILE *input = fopen("euclid3.in", "r");
    FILE *output = fopen("euclid3.out", "w");

    if (!input || !output) {
        fprintf(stderr, "Eroare deschidere fisiere!");
        exit(-1);
    }

    if (fscanf(input, "%lld %lld %lld", &a, &b, &c) != 3) {
        fprintf(stderr, "Eroare la citire a, b, c!\n");
        exit(-1);
    }

    int64_t g = exeuclid(a, b, &x, &y);
    if (g % c != 0) {
        fprintf(output, "Nu exista solutie\n");
    } else {
        fprintf(output, "%lld %lld\n", x * (c / g), y * (c / g));
    }

    fclose(input);
    fclose(output);
    return 0;
}