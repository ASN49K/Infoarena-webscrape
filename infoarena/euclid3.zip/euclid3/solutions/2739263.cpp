#include <bits/stdc++.h>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
long long euclid_extins(int a, int b, long long &x, long long &y)
{
    if(a==0)
    {
        x = 0;
        y = 1;
        return b;
    }
    long long x1,y1;
    long long d = euclid_extins(b%a,a,x1,y1);
    x = y1-(b/a)*x1;
    y = x1;
    return d;
}
int main()
{
    int t;
    f>>t;
    for(int test=1;test<=t;test++)
    {
        long long a,b,c;
        f>>a>>b>>c;
        long long x,y;
        long long d = euclid_extins(a,b,x,y);
        if(c%d!=0)
        {
            g<<"0 0"<<'\n';
            continue;
        }
        x*=c/d;
        y*=c/d;
        g<<x<<' '<<y<<'\n';
    }
    return 0;
}
