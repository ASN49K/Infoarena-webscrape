#include <bits/stdc++.h>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
typedef pair<int,int> pii;
int t,a,b,c;
void solve()
{
    fin>>a>>b>>c;
    int g=__gcd(a,b);
    if(c%g!=0)
    {
        fout<<"0 0\n";
        return;
    }
    c/=g;
    a/=g;
    b/=g;
    pii Va={1,0};
    pii Vb={0,1};
    pii Vr;
    while(b)
    {
        int cat=a/b;
        int rest=a%b;
        Vr.first=Va.first-cat*Vb.first;
        Vr.second=Va.second-cat*Vb.second;
        a=b;
        b=rest;
        Va=Vb;
        Vb=Vr;
    }
    fout<<Va.first*c<<' '<<Va.second*c<<'\n';
}
int main()
{
    fin>>t;
    while(t--)
        solve();
    return 0;
}
