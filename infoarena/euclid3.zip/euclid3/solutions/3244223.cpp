#include <bits/stdc++.h>

using namespace std;
ifstream fin ("euclid3.in");
ofstream fout("euclid3.out");
int n,a,b,c,x,y;
void euclid(int a , int b ,int & d, int & x ,int & y)
{
    if(b == 0)
    {
        d = a;
        x = 1, y = 1;
    }
    else
    {
        int x1 , y1;
        euclid(b , a % b , d, x1 , y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}
int main()
{
    cin>>n;
    while (n)
        {
            cin>>a>>b>>c;
            n--;
            euclid(a,b,)
        }
    return 0;
}
