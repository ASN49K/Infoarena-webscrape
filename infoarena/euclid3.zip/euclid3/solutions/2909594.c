#include <stdio.h>

int x,y;
int eucli(int a, int b, int X, int Y)
{
	if(b==0)
	{
		X=1;
		Y=0;
		return a;
	}

	int X0, Y0, d;
	d=eucli(b, a%b, X0, Y0);

	X=Y0;
	Y=X0-(a/b)*Y0;

	x=X; y=Y;
	return d;
}

int main()
{
    FILE *fin=fopen("euclid3.in", "r");
    FILE *fout=fopen("euclid3.out", "w");
    int n, A, B, C, D, X, Y;
    fscanf(fin, "%d", &n);
    for(int i=0; i<n; ++i)
    {
        fscanf(fin, "%d %d %d", &A, &B, &C);
        D=X=Y=0;
        D=eucli(A,B,X,Y);
        if (C % D)
            fprintf(fout, "0 0\n");
        else
            fprintf(fout, "%d %d\n", x * C / D, y * C / D);
    }

}
