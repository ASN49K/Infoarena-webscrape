#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

long long cmmdc(long long a,long long b)
{
    int aux;
    while (b!=0)
    {
        aux=a%b;
        a=b;
        b=aux;
    }
    return a;
}
int main()
{
    long long T,a,x,b,y,c,d,n,m,im;
    fin>>T;
    for (int i=1;i<=T;i++)
    {
        fin>>a>>b>>c;
        d=cmmdc(a,b);
        n=a/d;
        m=b/d;
        im=c/d;
        x=0;
        if (c%d>0)
            fout<<0<<" "<<0<<'\n';
        else
        {
            while ((1-n*x)%m!=0)
                x++;
            y=(1-n*x)/m;
            fout<<x*im<<" "<<y*im;
            fout<<'\n';
        }
    }
    return 0;
}
