#include<fstream>
using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclid(int a,int b,int &x, int &y,int &d){
	
	if(!b){
		x=1;
		y=0;
		d=a;
		return;
	}
	int x1,y1,q=a/b;
	euclid(b,a%b,x1,y1,d);
	x=y1;
	y=x1-q*y1;
}
int main(){
	int t,x,y,d,a,b,c,q;
	in>>t;
	for(int i=1 ; i<=t ; i++){
		in>>a>>b>>c;
		euclid(a,b,x,y,d);
		if(c%d==0)
			out<<c/d*x<<" "<<c/d*y<<"\n";
		else
			out<<"0 0\n";
	}
	return 0;
}
