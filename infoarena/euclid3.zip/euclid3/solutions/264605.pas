var i,n,a,b,x,y,x0,y0,d,c:longint;
    f,g:text;

procedure gcd(a,b:longint);
  begin
    if b=0 then begin
      x0:=1; y0:=0; d:=a;
    end
      else begin
        gcd(b,a mod b);
        x:=y0;
        y:=x0-(a div b)*y0;
        x0:=x;
        y0:=y;
      end;
  end;

begin
  assign(f,'euclid3.in');
  reset(f);
  assign(g,'euclid3.out');
  rewrite(g);
  readln(f,n);
  for i:=1 to n do begin
    readln(f,a,b,c);
    gcd(a,b);
    if c mod d<>0 then writeln(g,'0 0') else
      writeln(g,x*(c div d),' ',y*(c div d));
  end;
  close(f);
  close(g);
end.