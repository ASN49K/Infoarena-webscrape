#include<bits/stdc++.h>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");

int gcd(int a, int b, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    else
    {
        int x0, y0;

        int sol = gcd(b, a%b, x0, y0);

        x = y0;
        y = x0 - (a/b) * y0;

        return sol;
    }
}

int main()
{
    int n,a,b,c;
    f >> n;
    while(n--)
    {
        f >> a >> b >> c;
        int x, y;
        int d = gcd(a, b, x, y);
        if(c%d == 0)
        {
            g << x*(c/d) << " " << y*(c/d) << "\n";
        }
        else
        {
            g << "0 0\n";
        }
    }
    return 0;
}
