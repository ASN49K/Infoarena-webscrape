#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

int a, b, c, d, x, y, n;

void euclid(int a, int b, int &d, int &x, int &y)
{
    if (b==0)
    {
        d=a;
        x=1;
        y=0;
        return;
    }
    int xp, yp;
    euclid(b,a%b,d,xp,yp);
    x=yp;
    y=-(a/b)*yp+xp;
}

int main()
{
    fin >> n;
    for (int i=0;i<n;++i)
    {
        fin >> a >> b >> c;
        euclid(a,b,d,x,y);
        if (c%d!=0)
        {
            fout << "0 0\n";
        }
        else
            fout << x*c/d << " " << y*c/d << "\n";
    }
    return 0;
}
