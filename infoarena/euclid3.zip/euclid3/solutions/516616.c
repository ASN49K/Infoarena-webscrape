#include <stdio.h>
#include <assert.h>


int euclid(int a, int b, int *x, int *y)
{
    if (b == 0) {
        *x = 1;
        *y = 0;
		return a;
    } else {
        int x0, y0, d;
        d = euclid(b, a % b, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
		return d;
    }
}

int main()
{
	freopen("euclid3.in", "rt", stdin);
	freopen("euclid3.out", "wt", stdout);

	int T;
	scanf("%d", &T);
	assert( 1<=T && T <= 100 )
	
	for (; T; T--)
	{
		int A, B, C;
		scanf("%d %d %d", &A, &B, &C);

		assert( -1000000000 <= A && A <= 1000000000 );
		assert( -1000000000 <= B && B <= 1000000000 );
		assert( -2000000000 <= C && C <= 2000000000 && C != 0 );
		
		int D, X, Y;
		D = gcd( A, B, X, Y );
		
		if (C % D)
			printf("0 0\n");
		else
			printf("%d %d\n", X * (C / D), Y * (C / D));
	}

	return 0;
}
