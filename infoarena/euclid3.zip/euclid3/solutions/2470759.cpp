#include <iostream>
#include <cstdio>
using namespace std;
int euclid(int a,int b,int c,int&x,int&y)
      { int q[100],xo,yo,r,pas=0;
          while(b)
              { q[++pas]==a/b;
                  r=a%b;
                  a=b;
                   b=r;
              }
           if(c%a) {x =y=0;return 0;}
           x=xo=c/a;
           y=yo=0;
           while(pas)
               { x=yo;
                  y=xo-q[pas--] *yo;
                    int x0=x;
                     yo=y;
               }
         return 1;

      }


int main()
{ int a,b,c,x,y,T;
    freopen("euclid3.in","r",stdin);
      freopen("euclid3.out","w",stdout);
         scanf("%d",T);
           for(int i=1;i<=T;i++)
             {scanf("%d%d%d",&a,&b,&c);
            euclid(a,b,c,x,y);
            printf("%d %d\n",&x,&y);}



    return 0;
}
