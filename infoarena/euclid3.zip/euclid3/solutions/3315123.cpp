#include <bits/stdc++.h>

using namespace std;

const string NUMEFISIER="euclid3";
ifstream fin(NUMEFISIER+".in");
ofstream fout(NUMEFISIER+".out");


void euclidExtins(int a, int b, int& x, int& y, int& d)
{
    if(b==0)
    {
        x=1; y=0;d=a;
        return;
    }
    int x1,y1,q=a/b;
    euclidExtins(b, a%b, x1, y1, d);
    x=y1;
    y=x1-q*y1;
}

int main()
{
    int n;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        int x,y,d;
        euclidExtins(a, b, x, y, d);
        if(c%d==0)
        {
            fout<<(c/d)*x<<' '<<(c/d)*y<<'\n';
        }
        else fout<<"0 0\n";
    }
    return 0;
}
