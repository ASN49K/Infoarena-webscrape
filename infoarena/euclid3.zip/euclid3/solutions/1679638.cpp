#include <fstream>

using namespace std;
ifstream f ("euclid3.in");
ofstream g ("euclid3.out");

void ex()
{
        long a, b, c, aa, bb, r, q, s1, s2, aux, j=0;
        f>>a>>b>>c;
        aa=a;
        bb=b;
        s2=1;
        q=0;
        s1=0;
        do
            {
                r=a%b;
                aux=s2;
                s2=s1-q*s2;
                s1=aux;
                q=a/b;
                //g<<++j<<'|'<<'\t'<<a<<'\t'<<b<<'\t'<<r<<'\t'<<q<<'\t'<<s1<<'\t'<<s2<<'\n';
                a=b;
                if (r) b=r;
            }
        while (r);
        s1=(b-s2*aa)/bb;
        //g<<b<<'\t'<<s2<<'\t'<<s1<<'\n';
        if (c%b==0)
            {
                q=c/b;
                g<<s2*q<<' '<<s1*q<<'\n';
            }
        else
            {
                g<<'0'<<' '<<'0';
            }
}

int main()
{
    int n;
    f>>n;
    while (n)
        {
            ex();
            n--;
        }
    f.close();
    g.close();
    return 0;
}
