#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
void euclid(int a, int b, int *d, int *x, int *y) {
    if(b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *y = x0 - y0 * (a / b);
        *x = y0;
    }
}
int main()
{
    int a,b,c,n,x,y,d;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        fin>>a>>b>>c;
         euclid(a, b, &d, &x, &y);
        if(c % d != 0) {
            fout<<"0 0\n";
        } else {
            fout<<x * (c / d)<<' '<<y * (c / d)<<'\n';
    }
    return 0;
}
