#include <cstdio>

using namespace std;

void euclid(int &x, int &y, int &d, int a, int b)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
        return ;
    }
    int x0,y0;
    euclid(x0,y0,d,b,a%b);

    x = y0;
    y = x0 - (a / b) * y0;
}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    int teste;

    scanf("%d", &teste);

    while(teste--)
    {
        int a,b,c,x,y,d;

        scanf("%d %d %d", &a ,&b, &c);

        euclid(x,y,d,a,b);

        if(c % d == 0)
        {
            printf("%d %d\n", x * (c / d), y * (c / d));
        }
        else
        {
            printf("0 0\n");
        }
    }

    return 0;
}
