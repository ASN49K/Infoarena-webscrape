#include <fstream>
using namespace std;
ifstream cin("euclid3.in");
ofstream cout("euclid3.out");
void gcd(int a, int b, int& d, int& k, int& l)
{
	if (!b)
	{
		d = a;
		k = 1;
		l = 0;
	}
	else
	{
		int lnou, knou;
		gcd(b, a % b, d, knou, lnou);
		k = lnou;
		l = knou - (a / b) * lnou;
	}
}
int main()
{
	int t, a, b, c;
	cin >> t;
	for (int i = 0; i < t; i++)
	{
		cin >> a >> b >> c;
		int k, l, d;
		gcd(a, b, d, k, l);
		if (c % d == 0)
			cout << k * c / d << ' ' << l * c / d << '\n';
		else
			cout << 0 << ' ' << 0 << '\n';
	}
	return 0;
}