#include <fstream>
#include <iostream>
#define ll long long

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void euclid(ll a,ll b,ll d,ll&x,ll&y)
{
    if(b==0)
    {
        x=1;
        y=0;
        d=a;
        return;
    }
    ll x1,y1;
    euclid(b,a%b,d,x1,y1);
    x=y1;
    y1=x1-(a/b)*y1;
    euclid(b,a%b,d,x1,y1);
}

int main()
{
    ll t,a,c,b;
    fin>>t;
    for(int i=0;i<t;i++)
    {
        fin>>a>>b>>c;
        ll x,y,d;
        euclid(a,b,d,x,y);
        //if(c%d!=0)
        //cout<<"0 0"<<'\n';
        //else
        fout<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
    return 0;
}
