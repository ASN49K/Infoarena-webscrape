#include <iostream>
#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

void euclidExtins(int a,int b,int &d,int &x, int &y){
    if(b==0){
        d=a;
        x=1;
        y=0;
    }else{
        int x0,y0;
        euclidExtins(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    int T,a,b,c;
    f >> T;
    for(int i=1;i<=T;i++){
        int d,v,u;
        f >> a >> b >> c;
        euclidExtins(a,b,d,v,u);
        if(c%d==0) g << 1ll*c/d*v << ' ' << 1ll*c/d*u << '\n';
        else g << 0 << ' ' << 0 << '\n';
    }
    f.close();
    g.close();
    return 0;
}
