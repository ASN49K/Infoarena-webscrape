#include <bits/stdc++.h>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclid(long long int a, long long int b, long long int &d, long long int &x, long long int &y);

int main()
{
    long long int a, b, d, x, y, c, n;
    in>>n;
    for(int i=0; i<n; i++)
    {
        in>>a>>b>>c;
        euclid(a, b, d, x, y);
        if(c%d)
        {
            out<<0<<' '<<0<<'\n';
        }
        else
        {
            out<<x*(c/d)<<' '<<y*(c/d)<<'\n';
        }
    }


    return 0;
}


void euclid(long long int a, long long int b, long long int &d, long long int &x, long long int &y)
{
    long long int x0, y0;
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        euclid(b, a%b, d, x0, y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
