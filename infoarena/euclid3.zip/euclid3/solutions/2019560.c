#include <stdio.h>

int BEZOUT (int a, int b, int *alpha, int *beta)
{
    if (b == 0)
    {
        *alpha = 1;
        *beta = 0;
        return a;
    }
    
    int x, y, D;

    D = BEZOUT (b, a % b, &x, &y);
        
    *alpha = y;
    *beta = x - (a / b) * y;
    return d;
}

int main ()
{
    int lines, A, B, C;

    freopen ("euclid3.in", "r", stdin);
    freopen ("euclid3.out", "w", stdout);

    scanf ("%d", &lines);
    for ( ; lines; --lines)
    {
        scanf ("%d %d %d", &A, &B, &C);
        
        int alpha, beta, D;
        D = BEZOUT (A, B, &alpha, &beta);
        if (C % D)
            printf("0 0\n");
        else
            printf("%d %d\n", alpha * (C / D), beta * (C / D));
    }   
    return 0;
}