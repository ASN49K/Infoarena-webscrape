#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int r,i;
    long T;
    long long a,b;
    ifstream f1("euclid3.in.txt");
    ofstream f2("euclid3.out.txt");
    f1>>T;
    for (i=0;i<T;i++){
        f1>>a;
        f1>>b;
    }
    while(b){
        r=a%b;
        a=b;
        b=r;
    }
    f2<<a<<b<<endl;

    return 0;
}
