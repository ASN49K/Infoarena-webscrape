#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int a,n,d,i,b,x,y,c;
int euclid(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0;
    int d=euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>a>>b>>c;
        d=euclid(a,b,x,y);
         if(c%d==0)
            fout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
        else
            fout<<"0 0\n";
    }
    return 0;
}
