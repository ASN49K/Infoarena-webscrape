#include <cstdlib>
#include <fstream>

using namespace std;

void gcd(int a, int b, int& x, int& y, int& d) {
  if (!b) {
    x = 0;
    y = 1;
    d = a;
    return;
  }
  int x0, y0;
  gcd(b, a % b, x0, y0, d);
  x = y0;
  y = x0 - (a / b) * y0;
}

int main() {
  int N, a, b, c, d, x, y;
  ifstream in {"euclid3.in"};
  ofstream out {"euclid3.out"};

  for (in >> N; N; --N) {
    in >> a >> b >> c;
    gcd(a, b, x, y, d);
    if (c % d) {
      out << "0 0";
    }
    else {
       c /= d;
       out << (c * x) << ' ' << (c * y);
    }
    out << '\n';
  }
  return EXIT_SUCCESS;
}
