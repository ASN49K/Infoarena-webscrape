#include <fstream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");



void euclid(int a,int b,int &d,int &x,int &y)
{
    if(b==0)
       {
           d=a;
           x=1;
           y=0;
       }
    else
       {
           int x0,y0;
           euclid(b, a%b , d, x0, y0);
           x=y0;
           y=x0-(a/b)*y0;
       }
}

int i,T,a,b,c,x,y,d;

int main()
{
    f>>T;

    for(i=1;i<=T;i++)
        {f>>a>>b>>c;
        euclid(b, a, d, x, y);
        if(c%d)
           g<<0<<' '<<0<<'\n';
        else
           {x=x*(c/d);
           y=y*(c/d);
           g<<y<<' '<<x<<'\n';}}
    f.close();
    g.close();
    return 0;
}
