#include <iostream>
#include <fstream>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

long long a,b,x,y,d,T,c;
void euclidExtins(long long a,long long b,long long &x,long long &y,long long &d)
{
    if(b==0){
        d=a;
        x=1;
        y=0;
    }
    else{
        long long x1,y1;
        euclidExtins(b,a%b,x1,y1,d);
        x=y1;
        y=x1-a/b*y1;
    }
}
int main()
{
    in>>T;
    for(int k=1;k<=T;++k){
        in>>a>>b>>c;
        euclidExtins(a,b,x,y,d);
        if(c%d==0){
            out<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        }
        else
            out<<0<<" "<<0<<'\n';
    }
    return 0;
}
