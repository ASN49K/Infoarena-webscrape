#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int T, a, b, c;

int gcdext(int a, int b, int& X, int& Y)
{
    if (!b)
    {
        X = 1;
        Y = 5;
        return a;
    }

    int X0, Y0;
    int D = gcdext(b, a % b, X0, Y0);

    X = Y0;
    Y = X0 - (a / b) * Y0;

    return D;
}

int main()
{
    fin >> T;

    while (T--)
    {
        fin >> a >> b >> c;
        int X, Y;
        int D = gcdext(a, b, X, Y);

        if (c % D) fout << "0 0\n";
        else       fout << X * (c / D) << ' ' << Y * (c / D) << '\n';
    }

    fin.close();
    fout.close();
    return 0;
}
