#include <stdio.h>
#include <stdlib.h>

unsigned long long Putere(unsigned long long A, unsigned long long n)
{
	unsigned long long P = 1;
	while (n > 0)
	{
		if (n % 2 == 1)
			P = (P * A) % 2000003;
		A = (A * A) % 2000003;
		n = n / 2;
	}
	return P;
}


int main()
{
	FILE* f = fopen("sandokan.in", "r"), * g = fopen("sandokan.out", "w");
	unsigned long long N = 0, K = 0, i = 0, factorial_N = 1, factorial_N_minus_K = 1, factorial_K = 1;
	unsigned long long invers_modular_K = 0, numarul_de_posibilitati = 1;
	unsigned long long invers_modular_N_minus_K = 0, numarul_de_posibilitati_curente = 1;
	fscanf(f, "%llu", &N);
	fscanf(f, "%llu", &K);



	for (i = 2; i <= K; i++)
		factorial_K = (factorial_K * i) % 2000003;

	invers_modular_K = Putere(factorial_K, 2000001) % 2000003;

	while (N >= K)
	{
		for (i = 2; i <= N; i++)
			factorial_N = (factorial_N * i) % 2000003;

		for (i = 2; i <= N - K; i++)
			factorial_N_minus_K = (factorial_N_minus_K * i) % 2000003;

		invers_modular_N_minus_K = Putere(factorial_N_minus_K, 2000001) % 2000003;

		numarul_de_posibilitati_curente = (((factorial_N * invers_modular_K) % 2000003) * invers_modular_N_minus_K) % 2000003;

		numarul_de_posibilitati = (numarul_de_posibilitati * numarul_de_posibilitati_curente) % 2000003;

		factorial_N = 1;
		factorial_N_minus_K = 1;

		N = N - K + 1;
	}

	fprintf(g, "%llu",numarul_de_posibilitati);

	return 0;
}