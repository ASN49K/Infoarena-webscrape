#include<fstream.h>

int cmmdc(int a,int b)
{
 if(b==0)
	return a;

 return cmmdc(b,a%b);
}


int main()
{int i,n,x,d,y,a,b,c;
 ifstream f("euclid3.in");
 f>>n;
 ofstream g("euclid3.out");
 for(i=0;i<n;i++)
	{
		f>>a>>b>>c;
		d=cmmdc(a,b);

		if(c%d!=0)
			x=y=0;
		else
		   {y=1;
			x=(c-b*c/d*y)/a*c/d;
			}




 g<<x<<" "<<y<<'\n';



}
f.close();
g.close();
return 0;
}

