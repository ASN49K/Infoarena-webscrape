#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int gcd(int a,int b,int &x,int &y) {
	if(b == 0) {
		x = 1;
		y = 0;
		return a;
	}
	int d = gcd(b,a%b,x,y);
	int aux = x;
	x = y;
	y = aux - (a/b)*y;
	return d;
}

int main()
{
	int T, A, B, C, D, X, Y;
	for(fin>>T;T;T--) {
		fin>>A>>B>>C;
		D = gcd(A,B,X,Y);
		if(C % D) fout<<"0 0\n";
		else
		fout<<X * (C/D)<<" "<<Y * (C/D)<<'\n';
	}
	return 0;
}
