#include<stdio.h>
void euclid(int a, int b, int &x, int &y,int &d){
	if(b==0){
		x=1;
		y=0;
		d=a;
		return;
	}
	int x1,y1,q=a/b;
	euclid(b, a%b, x1, y1,d);
	x=y1;
	y=x1-q*y1;
}
int main(){
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	int T,a,b,c,d,x,y;
	scanf("%d",&T);
	for(int i=0;i<T;i++){
		scanf("%d%d%d",&a, &b, &c);
		euclid(a,b,x,y,d);
		if(c%d)
			printf("0 0\n");
		else
			printf("%d %d\n", x*(c/d), y*(c/d));
	}
	return 0;
}
