#include <iostream>
#include <fstream>

using namespace std;

/*void euclid(int a, int b, int &d, int &x , int &y)
{
    if(!b)
    {
        x=1;
        y = 0;
        d = a;
        return;
    }
    int x1, y1;
    euclid(b,a%b,d,x1,y1);
    x = y1;
    y = x1 - (a/b)*y1;

}*/

int cmmdc(int x , int y)
{
    int a;
    while(y > 0)
   {
        a = x % y;
        x = y;
        y =a;
   }
   return x;
}

int main()
{
    int x, y;

    ifstream f("cmmdc.in");
    ofstream g("cmmdc.out");

    f>>x>>y;


   if(cmmdc(x,y) == 1)
   {
        g << 0;
   }
   else
        g << cmmdc(x,y);

    return 0;
}
