#include <iostream>
#include <cstdio>

using namespace std;
int n, a, b, c, k, l;

int Euclid(int a, int b)
{
    if (b == 0)
        return a;
    else
        return Euclid(b, a % b);
}

void EuclidExtins(int a, int b, int &k, int &l)
{
    if(b==0)
        k=1, l=0;
    else
    {
        int kp, lp;
        EuclidExtins(b, a%b, kp, lp);
        k=lp;
        l=kp-lp*(a/b);
    }
}

int main()
{
    freopen("euclid3.in", "rt", stdin);
    freopen("euclid3.out", "wt", stdout);
    int a, b, c, t;
    cin>>t;
    for(int i=0; i<t; i++)
    {
        cin>>a>>b>>c;
        int d=Euclid(a, b);
        if(c%d==0)
        {
            EuclidExtins(a, b, k, l);
            cout<<k*(c/d)<<" "<<l*(c/d)<<endl;
        }
        else cout<<"0 0"<<endl;

    }
    return 0;
}
