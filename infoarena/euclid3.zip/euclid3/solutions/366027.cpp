/* 
 * File:   main.cpp
 * Author: virtualdemon
 *
 * Created on November 20, 2009, 6:33 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

