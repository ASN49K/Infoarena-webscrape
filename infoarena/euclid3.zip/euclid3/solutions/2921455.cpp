#include <fstream>

using namespace std;

int solve(int a, int b, int& x, int& y) {
    if (a < b) {
        return solve(b, a, y, x);
    }
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int r = a % b;
    int d = solve(b, r, x, y);

    int aux = y;
    y = x - (a / b) * y;
    x = aux;
    return d;
}

int main() {
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");

    int n;
    f >> n;

    for (int i = 0; i < n;i++) {
        int a, b, c;
        int x, y, d;
        f >> a >> b >> c;
        d = solve(a, b, x, y);
        if (d == 0 || c % d != 0)
            g << "0 0\n";
        else {
            int k = c / d;
            g << x * k << ' ' << y * k << '\n';
        }
    }

    f.close();
    g.close();
    return 0;
}