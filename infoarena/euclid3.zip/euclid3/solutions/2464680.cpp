#include <fstream>

using namespace std;
void gcd(long a, long b, long* d, long * x, long* y) {
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    }
    else {
        long x0, y0;
        gcd(b, a%b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a/b) * y0;
    }
}
int main()
{
    ifstream f ("euclid3.in");
    ofstream g ("euclid3.out");
    int t; long a, b, c;
    f >> t;
    for (int i = 1; i <= t; ++i) {
        long d, x, y;
        f >> a >> b >> c;
        gcd(a, b, &d, &x, &y);
        if (c % d != 0)
            g << "0 0";
        else
            g << x * (c/d) << " " << y * (c/d) << "\n";
    }
    return 0;
}
