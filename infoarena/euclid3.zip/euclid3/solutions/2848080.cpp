#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int s(int a, int b, int& x, int& y)
{
	if (b == 0) { x = 1, y = 0; return a; }
		int x0, y0,d;
		d=s(b, a % b, x0, y0);
		x = y0;
		y = x0 - (a / b) * y0;
		return d;
}
int main()
{
	int t, a, b, c;
	for (fin>>t; t > 0; t--)
	{
		fin >> a >> b >> c;
		int d,x,y;
		d = s(a, b, x, y);
		if (c % d)
			fout << 0 << " " << 0 << "\n";
		else fout << x * (c / d) << " " << y * (c / d)<<"\n";
	}
	return 0;
}