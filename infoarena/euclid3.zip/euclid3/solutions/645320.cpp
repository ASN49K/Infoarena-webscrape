#include <stdio.h>
int t,i,a,b,c;

FILE *f,*g;


inline int gcd(int A,int B,int &X,int &Y){
	if (B==0)
	{
		X=1;
		Y=0;
		return A;
	}
	int X0,Y0,D;
	D=gcd(B,A%B,X0,Y0);
	X=Y0;
	Y=X0-(A/B)*Y0;
	return D;
}

int main(){
	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	
	fscanf(f,"%d ",&t);
	for (i=1;i<=t;i++)
	{   
		fscanf(f,"%d %d %d",&a,&b,&c);
		int d,x,y;
		d=gcd(a,b,x,y);
		
		if (c%d)
			fprintf(g,"0 0\n");
		else
			fprintf(g,"%d %d\n",x*(c/d),y*(c/d));
	}
	fclose(f);
	fclose(g);
	return 0;
}
