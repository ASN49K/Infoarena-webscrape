#include <bits/stdc++.h>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int t, a, b, c, cmmdc, x, y;

void euclid (int a, int b, int &k, int &l)
{
    if(b==0)
    {
        k=1;
        cmmdc=a;
        l=0;
        return;
    }
    int kp, lp;
    euclid(b,a%b,kp,lp);
    l=kp;
    k=lp-kp*(a/b);
}

int main()
{
    f >> t;
    for (int test=1; test<=t; ++test)
    {
        f >> a >> b >> c;
        euclid(a,b,x,y);
        if (c%cmmdc)
            g << 0 <<' ' << 0 << '\n';
        else
        {
            x=x*(c/cmmdc);
            y=y*(c/cmmdc);
            g << x <<' ' << y << '\n';
        }
    }
    return 0;
}
