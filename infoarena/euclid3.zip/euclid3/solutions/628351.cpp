#include<iostream.h>
#include<fstream.h>
int a,b,c,i,t,x,y,d;

using namespace std;
fstream f("euclid3.in",ios::in);
fstream g("euclid3.out",ios::out);

int eextins(int a,int b,int &x,int &y)
{
	int x0,y0;
	if(b==0)
	{
		x=1;
		y=0;
                return a;
	}

	
	d=eextins(b,a%b,x0,y0);
	x=y0;
	y=x0-(a/b)*y0;
        return d;
}


int main()
{
	f>>t;
	for(i=1;i<=t;i++)
	{
		f>>a>>b>>c;
		d=eextins(a,b,x,y);
		if(!c%d)g<<x<<" "<<y<<endl;
			else g<<"0"<<"0"<<endl;
	}
}
	
