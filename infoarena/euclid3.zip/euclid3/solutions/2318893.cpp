#include<fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int a,b,c,d,x,y,t;
int f(int a,int b,int &x,int &y){
    if(b==0){
        x=1;
        y=0;
        return a;
    }
    else{
        int x1,y1;
        int d=f(b,a%b,x1,y1);
        x=y1;
        y=x1-(a/b)*y1;
        return d;
    }
}
int main(){
    fin>>t;
    for(int i=1;i<=t;i++){
        fin>>a>>b>>c;
        d=f(a,b,x,y);
        if(c%d!=0){
            fout<<"0"<<" "<<"0"<<"\n";
        }
        else{
            fout<<x*(c/d)<<" "<<y*(c/d)<<"\n";
        }
    }
    return 0;
}
