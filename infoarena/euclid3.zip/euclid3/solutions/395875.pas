Program euclid;
var x,y,i,a,b,c,d,n : longint;
    fin,fout : text;



Procedure cmmdc(a,b : longint; var d,x,y : longint);
var x0,y0 : longint;
begin
if b=0 then
begin
d:=a;
x:=1;
y:=0;
end
else
begin
cmmdc(b,a mod b,d,x0,y0);
x:=y0;
y:=x0-(a div b)*y0;
end;
end;


begin
assign(fin,'euclid3.in'); reset(fin);
assign(fout,'euclid3.out'); rewrite(fout);
readln(fin,n);
for i:=1 to n do
begin
readln(fin,a,b,c);
cmmdc(a,b,d,x,y);
if c mod d=0 then writeln(fout,x*(c div d),' ',y*(c div d)) else writeln(fout,'0 0');
end;
close(fin);
close(fout);
end.