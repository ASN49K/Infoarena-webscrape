#include <iostream>
#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
long long int n,a,b,c,x,y,d;
int cmmdc (int x1,int x2)
{
    if (x1==0 || x2==0)
        return 0;
    else
    {
    int r=x1%x2;
    while (r!=0)
    {
        x1=x2;
        x2=r;
        r=x1%x2;
    }
    return x2;
    }
}
void euclidex (long long int a,long long int b,long long int &d,long long int &x,long long int &y)
{
    if (b==0)
    {
        d=a;
        x=1;
        y=1;
    }
    else
    {
        long long int x0,y0;
        euclidex(b,a%b,d,x0,y0);
        x=y0;
        y=x0-a/b*y0;
    }
}
int main()
{
    f>>n;
    for (int i=0; i<n; i++)
    {
        f>>a>>b>>c;
        d=cmmdc(a,b);
        if (c%d==0)
        {
            euclidex(a,b,d,x,y);
            g<<x*c/d<<' '<<y*c/d<<'\n';
        }
        else g<<0<<' '<<0<<'\n';
    }
    return 0;
}
