#include<cstdio>
using namespace std;
int cmmdc(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d=cmmdc(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;

}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    int n,i,x,y,a,b,c,d;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        d=cmmdc(a,b,x,y);
        if(c%d)printf("0 0\n");
            else printf("%d %d\n",x*c/d,y*c/d);
    }

    return 0;
}
