#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>

int64_t ee(int64_t a, int64_t b, int64_t *x, int64_t *y);
void solve(int64_t a, int64_t b, int64_t c, FILE *out);

int64_t main(void)
{
	FILE *in = fopen("euclid3.in", "r");
	FILE *out = fopen("euclid3.out", "w");
	if(in != NULL && out != NULL)
	{
		uint64_t t, i = 0;
		fscanf(in, "%u%*c", &t);
		for(; i < t; i++)
		{
			int64_t a, b, c;
			fscanf(in, "%lld%*c%lld%*c%lld%*c", &a, &b, &c);
			solve(a, b, c, out);
		}

		fclose(in);
		fclose(out);
	}
	else
	{
		printf("Error\n");
	}

	return 0;
}

void solve(int64_t a, int64_t b, int64_t c, FILE *out)
{
	int64_t x, y;
	int64_t d = ee(abs(a), abs(b), &x, &y);
	if(c % d == 0)
	{
		int64_t q = x * (c / d);
		int64_t w = y * (c / d);

		if(a < 0)
		{
			q = -q;
		}
		if(b < 0)
		{
			w = -w;
		}
		fprintf(out, "%lld %lld\n", q, w);
	}
	else
	{
		fprintf(out, "0 0\n");
	}
}

int64_t ee(int64_t a, int64_t b, int64_t *x, int64_t *y)
{
	if(a == 0)
	{
		*x = 0;
		*y = 1;
		return b;
	}
	else
	{
		int64_t x1, y1;
		int64_t d = ee(b % a, a, &x1, &y1);
		*x = y1 - (b / a) * x1;
		*y = x1;
		return d;
	}
}