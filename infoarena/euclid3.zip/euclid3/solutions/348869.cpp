#include <stdio.h>

FILE *fin = fopen("euclid3.in","r");
FILE *fout = fopen("euclid3.out","w");

long t,a,b,c,x,y;

void euclid(long a, long b, long *d, long *x, long *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        long x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{
    fscanf(fin, "%ld", &t);

    for(long i = 0; i<t; i++)
    {
        fscanf(fin,"%ld%ld%ld",&a,&b,&c);

        euclid(a, b, &c, &x, &y);

        fprintf(fout,"%ld %ld\n",x,y);
    }

    fclose(fin);
    fclose(fout);
}
