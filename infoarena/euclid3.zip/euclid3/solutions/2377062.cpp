#include <bits/stdc++.h>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

typedef long long i64;

const i64 NMAX = 100;

i64 ggg(i64 a, i64 b, i64 &ca, i64 &cb)
{
    i64 aa = 1, bb = 1, ab = 0, ba = 0;
    while( a ) {
        i64 r = b / a;
        swap(a, b -= r * a);
        swap(aa, ba -= r * aa);
        swap(ab, bb -= r * ab);
    }
    ca = ba;
    cb = bb;
    return b;
}

int main()
{
    i64 t;
    in >> t;
    while(t--) {
        i64 a,b,x,y,r;
        in >> a >> b >> r;
        i64 gc = ggg(a, b, x, y);
        if( r % gc ) out << "0 0\n";
        else out << x * r / gc << ' ' << y * r / gc << '\n';
    }
    return 0;
}
