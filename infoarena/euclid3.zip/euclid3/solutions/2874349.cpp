#include <fstream>
#define int long long
using namespace std;
ifstream cin("euclid3.in");
ofstream cout("euclid3.out");
int g;
void euclid(int a,int b,int &x0,int &y0)
{
if(b){
    euclid(b,a%b,x0,y0);}
    else{
    x0=1,y0=0;
        g=a;
        return ;}
    int x,y;
    y=x0-a/b*y0;
    x=y0;
    x0=x;
    y0=y;
}
 main ()
{int t;
    cin>>t;
    while(t--)
{
    int a,b,c;
        cin>>a>>b>>c;
        int x,y;
        euclid(a,b,x,y);
       // cout<<x<<" "<<g<<endl;
        cout<<c/g*x<<" "<<c/g*y<<'\n';
}
    return 0;}