#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int euclid_extins(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x0,y0,d;
    d = euclid_extins(b,a%b,x0,y0);
    x =  y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);

    int t,a,b,c,cm,x,y;
    fin >> t;
    while(t--)
    {
        fin >> a >> b >> c;
        cm = euclid_extins(a,b,x,y);
        if(c % cm)
            fout << "0 0\n";
        else
            fout << x * (c / cm) << " " << y * (c / cm) << "\n";
    }
    return 0;
}
