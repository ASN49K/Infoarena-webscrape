#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int a,b,d;

int euclid(int a,int b,int &x1,int &y1)
{
    if (b==0)
     {
         x1=1;
         y1=0;

         return a;
     }
    else
     {
         int x2,y2,c;

         c=euclid(b,a%b,x2,y2);

         x1=y2;
         y1=x2-(a/b)*y2;

         return c;
     }
}

int main()
{
    int t;

   f>>t;

   for (int i=1;i<=t;i++)
    {
        int x1,y1;

        f>>a>>b>>d;

        int c=euclid(a,b,x1,y1);

        int prop=d/c;

        if (d%c)
         g<<0<<" "<<0<<'\n';
        else
         g<<x1*prop<<" "<<y1*prop<<'\n';
    }

   f.close();
   g.close();
}
