#include<fstream.h>

long eu(long a, long b, long &x, long &y)
{
 if(b==0)
  {
   x=1;
   y=0;
   return a;
   }
 long d,x0,y0;

 d=eu(b,a%b,x0,y0);
 x=y0;
 y=x0-(a/b)*y0;
 return d;
 }

int main()
{

 long n,i,a,b,c,x,y,d;
 ifstream f("euclid3.in");
 ofstream g("euclid3.out");
 f>>n;
 for(i=1;i<=n;i++)
 {
  f>>a>>b>>c;
  d=eu(a,b,x,y);
  if(c%d)g<<'0'<<' '<<'0';
  else g<<(c/d)*x<<' '<<c/d*y<<'\n';
  }    
 return 0;
 }
 