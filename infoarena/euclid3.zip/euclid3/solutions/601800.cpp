#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>


void EuclidEx(int a, int b, int &d, int &x, int &y)
{
	int a0,b0,x0,y0,r;
	
	if(b==0)
	{
		d = a;
		x = 1;
		y = 0;
	}
	else
	{
		EuclidEx(b, a%b, d, x0, y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}


int main()
{
	int x,y;
	int T;
	int a,b,c;
	int d;
	FILE *f,*g;

	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	
	fscanf(f,"%d",&T);
	for(int i=0;i<T;i++)
	{
		fscanf(f,"%d %d %d",&a,&b,&c);
		
		EuclidEx(a,b,d,x,y);
	
		if(c%d)
		{
			fprintf(g,"0 0\n");
		}
		else
		{
			fprintf(g,"%d %d \n",(x*c)/d,(y*c)/d);
		}	
	}
	
	fclose(f);
	fclose(g);
	return 0;
}
