#include <stdio.h>

void euclid(int a, int b, int *x0, int *y0, int *d)
{
  if (b == 0) {
    *d = a;
    *x0 = 1;
    *y0 = 0;
    return;
  }
  
  int r = a % b;
  int c = a / b;
  int aux, auxx;

  euclid(b, r, x0, y0, d);
  
  aux = *x0;
  auxx = *y0;
  *x0 = *y0;
  *y0 = aux - c * auxx;
}

int main()
{
  int t;
  int a, b, c, x, y;
  int d;
  int i;

  FILE *f = freopen("euclid3.in", "r", stdin);
  FILE *g = freopen("euclid3.out", "w", stdout);

  scanf("%d", &t);
  for (i = 0; i < t; i++) {
    scanf("%d %d %d", &a, &b, &c);
    
    euclid(a, b, &x, &y, &d);

    if (c % d == 0) {
      printf("%d %d\n", x * c / d, y * c / d);
    } else {
      printf("0 0\n");
    }
     
  }
	
  return 0;
}
