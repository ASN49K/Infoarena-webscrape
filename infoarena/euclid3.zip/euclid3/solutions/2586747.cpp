#include <cstdio>
using namespace std;
void euclid_extins(int a,int b,int &d,int &x,int &y)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        int x1,y1;
        euclid_extins(b,a%b,d,x1,y1);
        x=y1;
        y=x1-(a/b)*y1;
    }
}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    int n,a,b,c,i,x,y,d;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        euclid_extins(a,b,d,x,y);
        if(c%d==0)
        {
            x=x*(c/d);
            y=y*(c/d);
            printf("%d %d\n",x,y);
        }
        else
            printf("0 0\n");
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
