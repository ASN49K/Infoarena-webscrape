#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void EuclidE(int a,int b,int&x,int&y,int&d)
{if(b==0){x=1;y=0;d=a;}
else{int x0,y0;EuclidE(b,a%b,x0,y0,d);
    x=y0;
    y=x0-a/b * y0;
}}

int t,a,b,c,d,k,x,y;

int main()
{fin>>t;
while(t--){
fin>>a>>b>>c;
EuclidE(a,b,x,y,d);
k=c/d;
if(c%d!=0)fout<<0<<' '<<0<<'\n';
else
fout<<x<<y<<endl;}
fin.close();
fout.close();
    return 0;
}
