#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define INF 1234567890
#define N (int)(2e5 + 5)
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
struct sol{
int x, y;
};
sol gcd(int a, int b, int x, int y, int x1, int y1)
{
   if(!b) return {x, y};
   int q = a / b;
   int x0 = x - q * x1, y0 = y - q * y1;
   gcd(b, a % b, x1, y1, x0, y0);
}
int main()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
    int t;
    fin >> t;
    for(int i = 1; i <= t; ++i)
    {
        int a, b, c;
        fin >> a >> b >> c;
        a = abs(a), b = abs(b);
        sol s;
        int cmmdc = __gcd(a, b);
        if(c % cmmdc == 0){
        s = gcd(a, b, 1, 0, 0, 1);
        fout << s.x * (c / cmmdc) << " " << s.y * (c / cmmdc)<< "\n";
        } else fout << "0 0\n";
    }
    return 0;
}
