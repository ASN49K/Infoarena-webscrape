#include <iostream>

using namespace std;
int euclid(int a, int b, int&x, int &y);
int a, b, c, x, y, ceva, d, t;

int main()
{int i;
 cin>>t;
 for(i=0; i<t; i++)
    {cin>>a>>b>>c;
     euclid(a, b, x, y);
     if(c%d!=0) cout<<0<<' '<<0;
       else
      {ceva=c/d;
       cout<<x*ceva<<' '<<y*ceva;
      }
    }
    return 0;
}
int euclid(int a, int b, int&x, int &y)
{int d, x1, y1;
 if(b==0) {x=1; y=0; return a;}
   else
   {d=euclid(b, a%b, x1, y1);
    x=y1; y=x1-y1*(a/b);
    return d;
   }

}
