#include <fstream>

std::ifstream fin("euclid3.in");
std::ofstream fout("euclid3.out");

int gcd(int a, int b, int& x, int& y) {
    if (!b) {
        x = 1;
        y = 0;
        return a;
    }

    int x0, y0;
    int d = gcd(b, a % b, x0, y0);

    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main() {
    int t;
    fin >> t;

    while (t--) {
        int a, b, c;
        fin >> a >> b >> c;

        int x, y;
        int d = gcd(a, b, x, y);

        if (c % d)
            fout << "0 0\n";
        else
            fout << x * c / d << ' ' << y * c / d << '\n';
    }

    fout.close();
    return 0;
}
