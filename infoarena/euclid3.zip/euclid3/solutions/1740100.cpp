
#include <fstream>
#define ull long long int
using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");
void euclidExtins(ull  a, ull b , ull *d, ull *x, ull *y)
{
    if(b == 0)
    {
        *x = 1;
        *y = 0;
        *d = a;
    }
    else
    {
        ull x0,y0;
        euclidExtins(b, a%b, d, &x0, &y0);

        *x = y0;
        *y = x0 - (a/b) * y0;
    }
}
int main()
{
    ull x,y,a,b,c,d,t,i;
    in >> t;
    for( i = 0 ; i < t ; i++)
    {
        in >> a >> b >> c;
        euclidExtins(a, b, &d, &x, &y);
        if (c % d == 0 )
            out<<( x * c/d) << " " <<  (y * c/d) << '\n';
        else
            out<<"0 0\n";
    }
    return 0;
}
