#include <iostream>
#include <cstdio>
using namespace std;

int T;

void cmmdc(int a,int b,int &d,int &k,int &l)
{
    if(b==0)
    {
        d=a;
        k = 1;
        l = 0;
    }
    else
    {
        int k0, l0;
        cmmdc(b,a%b,d,k0,l0);

        k = l0;
        l = k0 - (a/b)*l0;
    }
}

int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","r",stdin);
    scanf("%d ",&T);

    while(T--)
    {
        int a, b, c, d, k, l;
        scanf("%d %d %d",&a,&b,&c);
        cmmdc(a,b,d,k,l);
        if(c%d)
        {
            printf("0 0\n");
        }
        else printf("%d %d\n",k*(c/d),l*(c/d));
    }

    return 0;
}
