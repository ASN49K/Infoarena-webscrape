#include <stdio.h>

long long cmmdc(int a , int b , int &x , int &y){
	int x0 , y0 , d;
	if(b==0){
		x=1;
		y=0;
		return a;
	}
	else{
		d=cmmdc(b , a%b , x0 , y0);
		x=y0;
		y=x0-(a/b)*y0;
		return d;
	}
}
int main(){
	int d , x , y, i , n , c , a , b;
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d %d %d",&a,&b,&c);
		d=cmmdc(a , b , x , y);
		if(c%d)
			printf("%d %d\n",0,0);
		else
			printf("%d %d\n",x*c/d,y*c/d);
	}
	return 0;
}