#include <fstream>
using namespace std;

ifstream is("euclid3.in");
ofstream os("euclid3.out");

int n, a, b, c, d;
int Euclid( int a, int b, int& x, int &y );

int main()
{
    is >> n;
    for ( int i = 1; i <= n; i++ )
    {
        is >> a >> b >> c;
        int x, y;
        d = Euclid( a, b, x, y );
        if ( c % d != 0 )
            os << "0 0\n";
        else
            os << x * ( c / d ) << ' ' << y * ( c / d ) << '\n';
    }
    is.close();
    os.close();
    return 0;
}

int Euclid( int a, int b, int& x, int &y )
{
    if ( b == 0 )
    {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0;
    int d = Euclid( b, a % b, x0, y0 );
    x = y0;
    y = x0 - ( a / b ) * y0;
    return d;
}
