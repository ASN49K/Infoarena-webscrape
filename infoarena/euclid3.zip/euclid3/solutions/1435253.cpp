#include <iostream>
#include <fstream>

#define INPUT_FILE "euclid3.in"
#define OUTPUT_FILE "euclid3.out"

std::fstream in(INPUT_FILE, std::fstream::in);
std::fstream out(OUTPUT_FILE, std::fstream::out);

using namespace std;

int cmmdc(int a, int b) {
	if (b == 0) {
		return a;
	}
	return cmmdc(b, a%b);
}

int euclid(int a, int b, int &x, int &y) {
	if (b == 0) {
		x = 1;
		y = 0;
		return a;
	} else {
		int x_aux, y_aux, d;
		d = euclid(b, (a%b), x_aux, y_aux);
		x = y_aux;
		y = x_aux - (a/b)*y_aux;

		return d;
	}
}

int main(int argc, char const *argv[])
{
	int numberOf;
	int a, b, c;
	int x, y;
	in >> numberOf;
	for (int i = 0; i < numberOf; i++) {
		in >> a >> b >> c;
		int d = cmmdc(a, b);
		if (c%d) {
			out << "0 0\n";
		} else {
			euclid(a, b, x, y);
			out << x*(c/d) << " " << y*(c/d) << endl;
		}
//		cout << x << " " << y << " " << sol << " " << c << "\n";
	}

	out.close();
	in.close();
	return 0;
}
