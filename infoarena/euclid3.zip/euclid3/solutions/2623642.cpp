#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(0); cin.tie(); cout.tie();mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
ifstream fin("euclid3.in"); ofstream fout("euclid3.out");
#define cin fin
#define cout fout

int a, b, c;



int32_t main(){
INIT

int T;
cin>>T;
for(;T;T--){

cin>>a>>b>>c;


if(a<b){
        swap(a, b);
if(c%(__gcd(a, b))>0){cout<<"0 0\n"; continue;}
int r1=a, r2=b, s1=1, s2=0, t1=0, t2=1;



while(r2>0){

int q=(r1/r2);
int t=s2;
s2=s1-q*s2; s1=t;
t=t2;
t2=t1-q*t2; t1=t;
t=r2;
r2=r1-q*r2; r1=t;



}

cout<<t1*(c/(__gcd(a, b)) )<<" "<<s1*(c/(__gcd(a, b)) )<<"\n";


}
else{

if(c%(__gcd(a, b))>0){cout<<"0 0\n"; continue;}
int r1=a, r2=b, s1=1, s2=0, t1=0, t2=1;



while(r2>0){

int q=(r1/r2);
int t=s2;
s2=s1-q*s2; s1=t;
t=t2;
t2=t1-q*t2; t1=t;
t=r2;
r2=r1-q*r2; r1=t;



}

cout<<t1*(c/(__gcd(a, b)) )<<" "<<s1*(c/(__gcd(a, b)) )<<"\n";



}


}


return 0;
}
