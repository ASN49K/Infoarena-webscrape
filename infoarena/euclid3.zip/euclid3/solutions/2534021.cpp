#include <fstream>
#include <iostream>

using namespace std;

typedef long long ll;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

int t;
ll a, b;

void euclid(ll a, ll b, ll *d, ll *x, ll *y)

{

    if (b == 0) {

        *d = a;

        *x = 1;

        *y = 0;

    } else {

        ll x0, y0;

        euclid(b, a % b, d, &x0, &y0);

        *x = y0;

        *y = x0 - (a / b) * y0;

    }

}

int main()
{
    ll a, b, c, d, x, y;
    in>>t;
    for(int i = 1;i <= t;i++)
    {
        in>>a>>b>>c;
        euclid(a, b, &d, &x, &y);
        if(c % d == 0)
            out<<x*c/d<<' '<<y*c/d<<'\n';
        else out<<"0 0\n";
    }
    return 0;
}
