#include <fstream>

using namespace std;
typedef unsigned long long int ULL;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

void cmmdc(ULL a, ULL b, ULL &d, ULL &x, ULL &y)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        unsigned long long int x0,y0;
        cmmdc(b, a%b, d, x0, y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int main()
{
    ULL a,b,c,n,x,y,d;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>a>>b>>c;
        cmmdc(a,b,d,x,y);
        if(c%d!=0)
            fout<<"0 0"<<'\n';
        else{
            x=x*c/d;
            y=y*c/d;
            fout<<x<<" "<<y<<'\n';
        }
    }
    fin.close();
    fout.close();
    return 0;
}
