#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
int tt;

inline void solve()
{

}

int main()
{
    cin >> tt;
    while(tt--)
    {
        solve();
    }
}
