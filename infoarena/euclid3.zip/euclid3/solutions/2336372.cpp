#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("euclid3.in");
ofstream g ("euclid3.out");

void rezolvare();
//int divizor(int a, int b) {
//    int r = 1;
//    while(r != 0) {
//        r = a % b;
//        a = b;
//        b = r;
//    }
//    return a;
//}

void euclid(int a, int b, int &d, int &x, int &y)
{
    if (b == 0) {
        d = a;
        x = 1;
        y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    rezolvare();
    return 0;
}

void rezolvare() {
    int n;
    int a, b, c;
    int d, x, y;

    f >> n;
    for(int i = 1; i <= n; ++i) {
        f >> a >> b >> c;
        euclid (a, b, d, x, y);
        if (c%d == 0)
            g << x*(c/d) << ' ' << y*(c/d) << '\n';
        else
            g << 0 << ' ' << 0 << '\n';
    }
}
