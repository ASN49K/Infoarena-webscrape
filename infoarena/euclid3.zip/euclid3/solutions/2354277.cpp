#include <fstream>

using namespace std;

ifstream cin("euclid3.in");
ofstream cout("euclid3.out");

int a,b,c,i,n;

int lnko (int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d=lnko(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}

int main()
{
    cin>>n;
    for(i=1;i<=n;++i)
    {
        cin>>a>>b>>c;
        int d,x,y;
        d=lnko(a,b,x,y);

        if(c%d!=0) cout<<"0 0\n";
        else
        {
            cout<<x*(c/d)<<" "<<y*(c/d)<<"\n";;
        }
    }

    return 0;
}
