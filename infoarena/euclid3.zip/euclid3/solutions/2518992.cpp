#include <bits/stdc++.h>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

int t,a,b,c;

void cmmdc(int a,int b,int &d,int &x,int &y)
{
    if(b==0)
    {
        x=1;y=0;d=a;
        return;
    }

    cmmdc(b,a%b,d,x,y);
    x=y;
    y=(d-a*x)/b;
}

int main()
{
    in>>t;

    while(t--)
    {
        int x,y,d;
        in>>a>>b>>c;

        cmmdc(a,b,d,x,y);

        if(c%d)
            out<<"0 0\n";
        else
            out<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }

    return 0;
}
