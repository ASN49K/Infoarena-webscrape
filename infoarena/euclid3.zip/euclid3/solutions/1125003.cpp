#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int gcd(int A, int B, int &X, int &Y) {
    if (B == 0) {
        X = 1;
        Y = 0;
        return A;
    }

    int X0, Y0, D;
    D = gcd( B, A % B, X0, Y0 );

    X = Y0;
    Y = X0 - (A / B) * Y0;
    return D;
}

int main() {
    int T, A, B, C;
    fin >> T;
    while (T--) {
        fin >> A >> B >> C;
        int D, X, Y;
        D = gcd( A, B, X, Y );

        if (C % D)
            fout << "0 0\n";
        else
            fout << X * (C / D) << ' ' << Y * (C / D) << '\n';
    }
    fin.close();
    fout.close();
    return 0;
}
