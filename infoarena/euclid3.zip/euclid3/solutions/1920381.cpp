#include <fstream>
#include <math.h>
#include <vector>
#include <set>
#include <algorithm>
#include <cstring>
//#include <unordered_map>
#include <iomanip>
#include <time.h>
#include <stdio.h>
#include <bitset>
#include <map>
#define MAX 500000000000
//#include <iostream>
//#include <windows.h>
#include <deque>
//#include "PEZai.h"
//#include <Tlhelp32.h>
using namespace std;
ifstream cin("jocul.in");
ofstream cout("jocul.out");
//ifstream cin("euclid3.in");
//ofstream cout("euclid3.out");
using namespace std;
int gcd(int a, int b, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    int xx, yy;
    int r = gcd(b, a % b, xx, yy);
    x = yy;
    y = xx - (a / b) * yy;
    return r;
}
int main()
{
    int t;
    cin >> t;
    for(int i = 0; i < t; i++){
        int a, b, c;
        cin >> a >> b >> c;
        int x, y;
        int d = gcd(a, b, x, y);
        if(c % d)
            cout << "0 0\n";
        else
            cout << x * (c / d) << " " << y * (c / d) << "\n";
    }
}
