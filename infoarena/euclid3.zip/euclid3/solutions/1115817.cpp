//#include "stdafx.h"

 //references
//http://www.infoarena.ro/algoritmul-lui-euclid

#include <fstream>
#include <iostream>

std::ifstream in("euclid3.in");
std::ofstream out("euclid3.out");

void euclid(long a, long b, long* d, long* x, long *y)
{
    if (b==0)
    {
        *d = a;
        *x = 1;
        *y = 0;
    }
    else 
    {
        long x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a/b) * y0;
    }
}

int main()
{
    int T;
    in >> T;

    for (int i = 0; i < T; i++)
    {
        long a,b,c;
        in >> a >> b >> c;
        long x, y, d = 0;

        euclid(a, b, &d, &x, &y);

        if (c % d != 0)
        {
            x = 0;
            y = 0;
        }
        else 
        {
            long mult = c / d;
            x *= mult;
            y *= mult;
        }

        out << x << " " << y << "\n";
    }
}