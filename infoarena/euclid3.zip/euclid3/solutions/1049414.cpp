#include <cstdio>
#include <algorithm>
using namespace std;

void euclid(int a,int b,int &d,long long &x,long long &y) {
    if(b==0) {
        d=a;
        x=1;
        y=0;
        return ;
    }
    long long x0,y0;
    euclid(b,a%b,d,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
}


int main() {
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    
    int t;
    for(scanf("%d",&t);t;t--) {
        int a,b,c,d;
        long long x,y;
        scanf("%d%d%d",&a,&b,&c);
        euclid(a,b,d,x,y);
        if(c%d==0) {
            long long X,Y;
            X=(c/d)*x;
            Y=(c/d)*y;
            printf("%lld %lld\n",X,Y);
        }
        else {
            printf("0 0\n");
        }
    }

    return 0;
}
