#include <bits/stdc++.h>

using namespace std;

int x,y;

int euclid(int a, int b, int s1, int s0, int t1, int t0){
    if(b == 0){
        x = s0;
        y = t0;
        return a;
    }
    euclid(b, a%b, s0-(a/b)*s1, s1, t0-(a/b)*t1, t1);
}

int main()
{
    int a,b,c,d,t;
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);
    scanf("%d",&t);
    for(int i = 1;i <= t;i++){
        scanf("%d %d %d",&a,&b,&c);
        d = euclid(a, b, 1, 0, 0, 1);
        if(c%d){
            cout<<"0 0"<<'\n';
        }else{
            cout<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        }
    }
    return 0;
}
