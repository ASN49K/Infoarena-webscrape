#include<fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int a,b,c,n;
int cmmdc(int a,int b, int &x,int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int d=cmmdc(b,a%b,x,y);
    int aux=x;
    x=y;
    y=aux-y*(a/b);
    return d;
}

int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>a>>b>>c;
        int x,y,d;
        d=cmmdc(a,b,x,y);
        if(c%d==0)
            g<<c/d*x<<" "<<c/d*y<<"\n";
        else
            g<<"0 0\n";
    }
    return 0;
}
