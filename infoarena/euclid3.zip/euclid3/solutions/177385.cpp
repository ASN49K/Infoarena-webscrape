#include <fstream.h>
int gcd(int a, int b, int &x, int &y)
{   if (b == 0)    
    {   x = 1; y = 0; return a;      
    }
    int x0, y0, d;
    d = gcd(b, a%b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int  main()
{   int a, b, c, d, x, y, n, i;
    ifstream fin("euclid3.in");
    ofstream fout("euclid3.out");
    fin >> n;
    for (i = 1; i <= n; i++)
    {     fin >> a >> b >> c;
          d = gcd(a, b, x, y);
          if (c%d != 0) fout << 0 << " " << 0 << "\n";
          else          
            fout << x*(c/d) << " " << y * (c/d) << "\n";
    }
    fin.close(); fout.close();
    return 0;
}
