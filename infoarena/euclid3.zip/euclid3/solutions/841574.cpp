#include<iostream>
#include<fstream>
using namespace std;

inline void gcd(int a, int b, int &d, int &x, int &y)
{
	if(b==0) {
		y=0;
		x=1;
		d=a;
	}
	else {
		int x0,y0;
		gcd(b,a%b,d,x0,y0);
		x=y0;
		y=x0-(a/b)*y0;
	}
}

int main ()
{
	int i,t,a,b,c,x,y,d;
	ifstream f("euclid3.in");
	ofstream g("euclid3.out");
	f>>t;
	for(i=1;i<=t;i++) {
		f>>a>>b>>c;
		gcd(a,b,d,x,y);
		if(c%d==0) 
			g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
		else g<<"0 0\n";
	}
	f.close();
	g.close();
}