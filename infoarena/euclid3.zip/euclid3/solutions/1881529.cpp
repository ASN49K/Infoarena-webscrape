#include<fstream>
using namespace std;
#define ll long long
ll x,y,a,b,c,d,n;
ll cmmdc(ll a,ll b)
{
    ll r=(a%b),x=a,y=b;
    while(r!=0)
    {
        x=y;
        y=r;
        r=x%y;
    }
    return y;
}
void euclid(ll &a,ll &b,ll &x,ll &y)
{
    if(!b)
    {
        y=0;
        x=1;
    }
    ll x0,y0;
    euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
}
int main()
{
    ifstream f("euclid3.in");
    f>>n;
    ofstream g("euclid3.out");
    while(--n)
    {
        f>>a>>b>>c;
        d=cmmdc(a,b);
        if(c%d>0)
            g<<"0 0\n";
        else
        {
            euclid(a,b,x,y);
            x=x*(c/d);y=y*(c/d);
            g<<x<<" "<<y<<'\n';
        }
    }
    return 0;
}
