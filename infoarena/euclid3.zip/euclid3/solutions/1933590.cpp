#include <stdio.h>

using namespace std;

FILE *fin = fopen("euclid3.in", "r");
FILE *fout = fopen("euclid3.out", "w");

int cm;

void gcd(int a, int b, int &x, int &y)  {
    if(b == 0)  {
        x = 1, y = 0;
        cm = a;
        return;
    }
    int x1, y1;
    gcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
}

int main()  {
    int a, b;
    int T;
    fscanf(fin, "%d", &T);
    while(T)  {
        --T;
        int a, b, c, x, y;
        fscanf(fin, "%d%d%d", &a, &b, &c);
        gcd(a, b, x, y);
        if(c % cm)
            fprintf(fout, "0 0\n");
        else
            x = x * (c / cm), y = y * (c / cm), fprintf(fout, "%d %d\n", x, y);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
