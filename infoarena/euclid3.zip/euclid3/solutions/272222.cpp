#include <stdio.h>

int A, B, C, D, T;

int gcd(int a, int b, int &x, int &y)
{
	if (!b) 
	{
		x = 1;
		y = 0;
		return a;
	}

	int x0, y0, d;
	d = gcd(b, a % b, x0, y0);
	x = y0;
	y = x0 - (a/b) * y0;

	return d;
}

int main()
{
	int X, Y;
	FILE *fin = fopen("euclid3.in", "rt"), *fout = fopen("euclid3.out", "wt");
	fscanf(fin, "%d", &T);
	for (; T; --T)
	{
		fscanf(fin, "%d %d %d", &A, &B, &C);
		D = gcd(A, B, X, Y);
		if (C %D)
			fprintf(fout, "0 0\n");
		else
			fprintf(fout, "%d %d\n", X * C/D, Y*C/D);
	}
	fclose(fin), fclose(fout);
}
