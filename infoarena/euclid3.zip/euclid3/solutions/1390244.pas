program angrenaj;
type ele=record
        p,q:longint;
end;
var a:array[1..200,1..200] of integer;
    i,j,n,m,rx,ry,marc,st,sf:longint;
    f,g:text;
    x,y,z:longint;
    cd,viz:array[1..200] of integer;
    v:array[1..200] of ele;
    ok:boolean;

function cmmdc(a,b:longint):longint;
var r:longint;
begin
  repeat
    r:=a mod b;
    a:=b;
    b:=r;
  until r=0;
  cmmdc:=a;
end;

begin
   assign(f,'angrenaj.in'); reset(f);
   assign(g,'angrenaj.out'); rewrite(g);
   readln(f,n,m);
   for i:=1 to m do
     begin
       readln(f,x,y,rx,ry);
       if a[x,y]=0 then
         begin
           a[x,y]:=rx; a[y,x]:=ry;
         end
           else
             if a[x,y]/a[y,x]<>rx/ry then
               begin
                 a[x,y]:=-1; a[y,x]:=-1;
               end;
     end;
   st:=1;
   sf:=1;
   cd[st]:=1;
   viz[1]:=1;
   marc:=-1;
   ok:=true;
   v[1].p:=1;
   v[1].q:=1;
   while (st<=sf) and ok do
     begin
       for i:=1 to n do
         if viz[i]=0 then
           begin
             if a[cd[st],i]=-1 then
               ok:=false
                 else
                   if a[cd[st],i]<>0 then
                     begin
                       inc(sf);
                       cd[sf]:=i;
                       x:=v[cd[st]].p*a[cd[st],i];
                       y:=v[cd[st]].q*a[i,cd[st]];
                       z:=cmmdc(x,y);
                       v[i].p:=x div z;
                       v[i].q:=y div z;
                       viz[i]:=-viz[cd[st]];
                     end;
           end
             else
               begin
                if (viz[i]=viz[cd[st]]) and (a[cd[st],i]<>0) then
                  ok:=false  // ;

                    else
                     if a[cd[st],i]<>0 then
                      begin
                       x:=v[cd[st]].p*a[cd[st],i];
                       y:=v[cd[st]].q*a[i,cd[st]];
                       z:=cmmdc(x,y);
                       if v[i].p<>x div z then
                         ok:=false
                           else
                             if v[i].q<>y div z then
                               ok:=false;
                      end;
              end;
       inc(st);
     //  marc:=-marc;
     end;

   if ok then
     begin
       for i:=1 to n do
        if v[i].p=0 then
          writeln(g,0,' ',1)
            else
          writeln(g,v[i].p*viz[i],' ',v[i].q);
     end
       else
         for i:=1 to n do
            writeln(g,0,' ',1);

   close(f); close(g);
end.
