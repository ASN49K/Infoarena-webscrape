#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int Euclid_extins(int a, int b, int &x, int &y);
int main()
{int a, b, c, d, ceva, x, y, i, n;
    fin>>n;
    for(i=0; i<=n; i++)
    {fin>>a>>b>>c;
        d=Euclid_extins(a,b,x,y);
    if(c%d) fout<<"0 0\n";
    else
    {
        ceva=c/d;
        fout<<x*ceva<<' '<<y*ceva<<'\n';
    }
    }
    return 0;
}
int Euclid_extins(int a, int b, int &x, int &y)
{int d, x1, y1;
    if(b==0)
    {
        x=1; y=0; return a;
    }
    else
    {
        d=Euclid_extins(b,a%b,x1,y1);
        x=y1; y=x1-y1*(a/b);
        return d;
    }

}
