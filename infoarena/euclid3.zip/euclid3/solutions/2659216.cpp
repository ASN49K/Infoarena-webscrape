#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <set>
#include <algorithm>
#include <list>
#include <map>
#include <math.h>
#define NMAX 100001
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
typedef pair<int,int> p;

p euclid(int a , int b,  int c)
{
    if(b == 0)
    {
        if(c%a)return make_pair(0, 0);
        else return make_pair(c/a, 0);
    }
    else
    {
        p rez = euclid(b, a%b, c);
        return make_pair(rez.second, rez.first - a/b * rez.second);
    }
}
int main() {
    int a , b , c ,n;
    f>>n;
    while(n--){
    f>>a>>b>>c;
    auto rez = euclid(a, b, c);
        g<<rez.first<<" "<<rez.second<<'\n';
    }
    return 0;
}
