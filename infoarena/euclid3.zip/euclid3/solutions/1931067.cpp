#include <fstream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int euclid(int a,int b,int &X,int &Y)
{
    if(b!=0)
    {
        int X0,Y0,D;
        D=euclid(b,a%b,X0,Y0);
        X=Y0;
        Y=X0-Y0*(a/b);
        return D;
    }
    else
    {
        X=1;
        Y=0;
        return a;
    }
}

int main()
{
    int t;
    f>>t;
    for(int i=0;i<t;i++)
    {
    int a,b,c;
    f>>a>>b>>c;
    int D,X,Y;
    D=euclid(a,b,X,Y);
    if(c%D==0)
        g<<X*c/D<<" "<<Y*c/D<<"\n";
    else
        g<<"0 0\n";
    }
    f.close();
    g.close();
}
