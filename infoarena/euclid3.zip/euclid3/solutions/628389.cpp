#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;
int n;
int euclid(int a, int b, int &x, int &y)
{
    if(b==0)
    {x=1; y=0; return a;}
    else{int x0, y0,d;
         d=euclid(b,a%b,x0,y0);
         x=y0;
         y=x0-(a/b)*y0;
         return d;} 
 }

int main()
{
    FILE *fin = fopen("euclid3.in", "r");
    FILE *fout = fopen("euclid3.out","w");
    
    fscanf(fin, "%d", &n);
    int i,a,b,c,d,x,y;
    for(i=1;i<=n;i++) 
       { fscanf(fin,"%d %d %d", &a, &b, &c);
         d=euclid(a,b,x,y);
         if(c%d) fprintf(fout,"0 0\n");
         else fprintf(fout,"%d %d\n", x*(c/d), y*(c/d));
       }
    
    
    return 0;
}
