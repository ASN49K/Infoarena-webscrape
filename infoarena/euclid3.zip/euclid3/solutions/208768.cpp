#include<stdio.h>
void euclid(int a, int b, int &x, int &y, int &d){
	if (b==0){
		d=a;
		x=1;
		y=0;
		return;}
	int xx, yy;
	int q=a/b;
	euclid(b, a%b, xx, yy, d);
	x=yy;
	y=xx-yy*q;
}

int main(){
	int a, b,c, x, y, d, t;
	freopen("euclid3.in", "r", stdin);
	freopen("euclid3.out", "w", stdout);
	scanf("%d", &t);
	for(int i=1; i<=t; ++i){
	scanf("%d", &a);
	scanf("%d", &b);
	scanf("%d", &c);
	euclid(a, b, x, y, d);
	if(c%d!=0){
		printf("0 0\n");
		return 0;}
	c=c/d;
	x=x*c;
	y=y*c;
	printf("%d ", x);
	printf("%d\n", y);
	}
	
	
	
	
	
	
	
	
	
	return 0;}