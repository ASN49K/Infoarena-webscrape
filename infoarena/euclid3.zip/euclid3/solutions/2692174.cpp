#include <bits/stdc++.h>
#define int int64_t
#define cin fin
#define cout fout

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int gcd(int a, int b, int& x, int& y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int d = gcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - y1 * (a / b);
    return d;
}

bool find_any_solution(int a, int b, int c, int &x0, int &y0, int &g) {
    g = gcd(abs(a), abs(b), x0, y0);
    if (c % g) {
        return false;
    }

    x0 *= c / g;
    y0 *= c / g;
    if (a < 0) x0 = -x0;
    if (b < 0) y0 = -y0;
    return true;
}

int32_t main()
{
    int t,a,b,c,x,y,d;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        cin>>a>>b>>c;
        if (a==0&&b==0)
        cout<<"NO";
        else
        {
            if (a>b)
                swap(a,b);
            if (find_any_solution(a,b,c,x,y,d))
            {
                int bd=b/d;
                int ad=a/d;
                int aux=y/ad;
                y=y-aux*ad;
                x=x+aux*bd;
                cout<<x<<" "<<y<<'\n';
            }
            else
            {
                cout<<"0 0\n";
            }
        }
    }
    return 0;
}