
#include<bits/stdc++.h>
#pragma GCC optimize("O3")
#define fi first
#define se second
#define pb push_back
#define pf push_front
#define mod 1000000007

using namespace std;

typedef long long ll;


int add(int a, int b)
{
    ll x = a+b;
    if(x >= mod)
        x -= mod;
    if(x < 0)
        x += mod;
    return x;
}
ll mul(ll a, ll b)
{
    return (a*b) % mod;
}

ll pw(ll a, ll b)
{
    ll ans = 1;
    while(b)
    {
        if(b & 1)
            ans = (ans * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return ans;
}

int dc = 0;

int cmmdc(int a, int b)
{
    while(b)
    {
        int c = a % b;
        a = b;
        b = c;
    }
    return a;
}
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int a, b, c;
int ap = 0;
pair<int, int> euclid(int xa, int ya, int xb, int yb)
{
    if(1LL * xa * a + 1LL * ya * b == dc)
        return {xa, ya};
    long long rap = (1LL * xa * a + 1LL * ya * b) / (1LL * xb * a + 1LL * yb * b);
    return euclid(xb, yb, xa-xb*rap, ya-yb*rap);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    f >> t;
    for(; t; --t)
    {
        f >> a >> b >> c;
        bool sw = 0;
        if(a < b)
            swap(a, b), sw = 1;
        dc = cmmdc(a, b);
        if(c % dc != 0)
            g << "0 0\n";
        else
        {
            pair<int, int> ans = euclid(1, 0, 0, 1);
            if(!sw)
                g << ans.fi * (c / dc) << " " << ans.se * (c / dc) << '\n';
            else
                g << ans.se * (c / dc) << " " << ans.fi * (c / dc) << '\n';
        }
    }
    return 0;
}
