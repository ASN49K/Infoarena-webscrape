#include<cstdio>
long long t,a,b,c,d,x,y,aa,bb;
FILE *f,*g;
long long cmmdc(long long a,long long b,long long &x,long long &y){
    long long xa,ya;
    if(b==0){
        x=1;
        y=0;
        return a;
    }
    d=cmmdc(b,a%b,xa,ya);
    x=ya;
    y=xa-(a/b)*ya;
    return d;
}
int main(){
    f=fopen("euclid3.in","r");
    g=fopen("euclid3.out","w");
    fscanf(f,"%lld",&t);
    while(t--){
        fscanf(f,"%lld%lld%lld",&a,&b,&c);
        x=y=0;
        /*if(a>b){
            int aux=a;
            a=b;
            b=aux;
        }*/
        aa=a;
        bb=b;
        d=cmmdc(a,b,x,y);
        d=aa*bb/d;
        if( (d > c / (aa * x + bb * y ) ) && (x!=0&&y!=0) && ( c % (aa * x + bb * y ) ==0 ) ){
            fprintf(g,"%lld %lld\n",x*c/(aa*x+bb*y),y*c/(aa*x+bb*y));
        }
        else{
            fprintf(g,"0 0\n");
        }
    }





    fclose(f);
    fclose(g);
    return 0;
}
