#include <fstream>

using namespace std;
ifstream in ("euclid3.in");
ofstream out ("euclid3.out");
void eeuclid(int a,int b,int &x,int &y,int &d)
{
    if (b==0)
    {
        x=1, y=0, d=a;
        return ;
    }
    int xx,yy,q=a/b;
    eeuclid(b,a%b,xx,yy,d);
    x=yy;
    y=xx-q*yy;
}
int main()
{
    int a,b,c,x,y,d,n,i;
    in>>n;
    for (i=1;i<=n;i++)
    {
        in>>a>>b>>c;
        eeuclid(a,b,x,y,d);
        if (c%d==0)
            out<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        else
            out<<"0 0\n";
    }
    return 0;
}
