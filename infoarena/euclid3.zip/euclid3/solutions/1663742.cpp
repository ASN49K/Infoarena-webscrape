#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int T;

void euclid(long long a, long long b, long long &d, long long &x, long long &y)
{
    if (b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        long long x0, y0;
        euclid(b, a%b, d, x0, y0);
        x = y0;
        y = x0 - (a/b)*y0;
    }
}

int main()
{
    long long i, a, b, c, d, x, y;
    fin>>T;
    for (i=1; i<=T; i++)
    {
        fin>>a>>b>>c;
        euclid(a, b, d, x, y);
        if (c%d)
            fout<<0<<" "<<0<<'\n';
        else
        {
            fout<<c/d*x<<" "<<c/d*y<<'\n';
        }
    }
    return 0;
}
