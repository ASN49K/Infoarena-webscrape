#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
#define cout fout
int gcd(int a, int b, int &x, int &y)
{
    /**
    a * x + b * y = d;
    b * x' + (a%b) * y' = d
    ax + by = bx' + ay' - b*[a / b]y'
    a(x - y') = b(x' - y - [a / b]y')
    ===> x = y'
    ===> y = x' - [a / b]y'
    **/
    if(!b)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0;
    int d = gcd(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main()
{
    int t, a, b, c, d, x, y;
    fin >> t;
    while(t--)
    {
        fin >> a >> b >> c;
        d = gcd(a, b, x, y);

        if(c % d != 0)
        {
            cout << "0 0\n";
        }
        else
        {
            cout << 1ll*x * c / d << " " << 1ll*y * c / d << "\n";
        }
    }
}
