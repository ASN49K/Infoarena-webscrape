program eclextins;
 var fin,fou:text;
     t,i:byte;
     a,b,d,x,y,c:longint;
 procedure euclid(a,b:longint; var d,x,y:longint);
  var x0,y0:longint;

  begin
   if b=0 then
    begin
     d:=a;
     x:=1;
     y:=0;
    end else
          begin
            euclid(b,a mod b,d,x0,y0);
            x:=y0;
            y:=x0-(a div b)*y0;
          end;
  end;


 begin
 assign(fin,'euclid3.in'); reset(fin);
 assign(fou,'euclid3.out'); rewrite(fou);
  read(fin,t);
  for i:=1 to t do
   begin

      read(fin,a,b,c);
      euclid(a,b,d,x,y);
       if c mod d=0 then writeln(fou,x*(c div d),' ',y*(c div d))
       else writeln(fou,'0 0');

   end;

  close(fin);
  close(fou);

 end.