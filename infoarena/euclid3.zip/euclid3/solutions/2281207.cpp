#include <iostream>
#include <fstream>
#include <assert.h>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int gcd( int A, int B, int &X, int &Y )
{
	if (B == 0)
	{
		X = 1;
		Y = 0;
		return A;
	}

	int X0, Y0, D;
	D = gcd( B, A % B, X0, Y0 );

	X = Y0;
	Y = X0 - (A / B) * Y0;
	return D;
}

int main()
{
	int T;
	f>>T;

	for (int i = 1; i <= T; i++)
	{
		int A, B, C;
		f>>A>>B>>C;
		int D, X, Y;
		assert( -1000000000 <= A && A <= 1000000000 );
		assert( -1000000000 <= B && B <= 1000000000 );
		assert( -2000000000 <= C && C <= 2000000000 && C != 0 );
		D = gcd( A, B, X, Y);

		if (C % D)
			g<<"0 0";
		else
            g<<X *(C / D)<<" "<<Y *(C / D)<<endl;
	}
	return 0;
}
