#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int a,b,d,x,c,y,n;
int gcd( int A, int B, int &X, int &Y )
{
	if (B == 0)
	{
		X = 1;
		Y = 0;
		return A;
	}

	int X0, Y0, D;
	D = gcd( B, A % B, X0, Y0 );

	X = Y0;
	Y = X0 - (A / B) * Y0;
	return D;
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a>>b>>c;
        d=gcd(a,b,x,y);
        if(c%d)
        {
            fout<<0<<" "<<0<<'\n';
        }
        else
        {
            fout<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        }
    }
    fin.close();
    fout.close();
    return 0;
}
