#include <bits/stdc++.h>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int t;

int euclid_e(int a, int b, int &x, int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
        int x1,y1,d;
        d=euclid_e(b,a%b,x1,y1);
        x=y1;
        y=x1-(a/b)*y1;
        return d;
    }
}

int main()
{
    int a,b,c,x,y,d;
    fin>>t;
    while(t--)
    {
        fin>>a>>b>>c;
        d=euclid_e(a,b,x,y); // a*x+b*y = c -> cmmdc(a,b)
        // cout<<x<<" * "<<a<<" + "<<y<<" * "<<b<<" = "<<d<<endl;
        if(c%d)
            fout<<"0 0"<<'\n';
        else fout<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
}
