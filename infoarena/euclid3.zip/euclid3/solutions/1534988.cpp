#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int x, y, d;


void gcd(int a, int b) { // a > b
  if (b == 0) {
    d = a;
    x = 1;
    y = 0;
    return;
  } else {
    int q = a/ b;
    gcd(b, a%b);
    int tmp = y;
    y = x - q*y;
    x = tmp;
    return;
  }
}

int main() {
  ifstream fin ("euclid3.in");
  ofstream fout ("euclid3.out");

  int T, a,b, apos, bpos, c;
  fin >> T;
  for (int i = 0; i < T; i++) {
    fin >> a >> b >> c;
    apos = abs(a);
    bpos = abs(b);
    if (apos > bpos) {
      gcd(apos, bpos);
    } else {
      gcd(bpos, apos);
      swap(x, y);
    }
    //cout << x << ' ' << y << ' ' << d << '\n';
    x *= a/ apos;
    y *= b/ bpos;
    if (c % d == 0) {
      fout << x*(c/d) << ' ' << y*(c/d) << '\n';
    } else {
      fout << "0 0\n";
    }
  }

  return 0;
}