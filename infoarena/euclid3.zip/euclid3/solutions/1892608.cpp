#include <iostream>
#include <cstdio>

using namespace std;

int n, a, b, c, k, l;

int Euclid(int a, int b)
{
    if (b == 0)
        return a;
    else
        return Euclid(b, a % b);
}

void EuclidExtins(int a, int b, int &k, int &l)
{
    if(b==0)
        k=1, l=0;
    else
    {
        int kp, lp;
        EuclidExtins(b, a%b, kp, lp);
        k=lp;
        l=kp-lp*(a/b);
    }
}


void Citire()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);
    scanf("%d\n", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%d %d %d", &a, &b, &c);
        int d=Euclid(a, b);
        if(c%d==0)
            EuclidExtins(a, b, k, l);
        cout<<k*(c/d)<<" "<<l*(c/d)<<endl;
    }
}

int main()
{
    Citire();
    return 0;
}
