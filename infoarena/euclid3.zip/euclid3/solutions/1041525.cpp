#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int n;

int Euclid_ext(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x = 1;
        y = 0;
        return a;
    }
    else
    {
        int x0, y0, d;
        d  =  Euclid_ext(b, a%b, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
        return d;
    }
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        int a, b, c, x, y, d;
        fin>>a>>b>>c;
        d =  Euclid_ext(a, b, x, y);
        if(c % d != 0)
            fout<<"0 0\n";
        else
            fout<<x * (c / d)<<' '<<y * (c / d)<<'\n';
    }
    return 0;
}
