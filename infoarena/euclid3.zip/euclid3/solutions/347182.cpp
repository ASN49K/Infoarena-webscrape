#include <stdio.h>

int euc(int a, int b, int &x, int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
        }
    int d, x0, y0;
    d=euc(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
    }
int main()
{
    int a, b, c, d, t, x, y;
    
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    
    scanf("%d",&t);
    while (t--)
        {
            scanf("%d%d%d",&a,&b,&c);
            d=euc(a,b,x,y);
            if (c%d)
                printf("0 0\n");
            else 
                printf("%d %d\n",x*(c/d),y*(c/d)); 
            }
    return 0;
    }