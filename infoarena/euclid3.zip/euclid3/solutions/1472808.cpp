#include <iostream>
#include <fstream>
using namespace std;

ifstream f("euclid3.in",ios::in);
ofstream g("euclid3.out",ios::out);

void euclid_extins(int a, int b, int &cmmdc, int &x  ,int &y )
{
    if (b==0)
    {
        cmmdc = a;
        x = 1;
        y = 0;
    }
    else
    {
        int x0,y0;
        euclid_extins(b,a%b,cmmdc,x0,y0);
        x = y0;
        y = x0 - (a/b)*y0;
    }
}

int main()
{
    int a,b,c,t,cmmdc,x,y;
    f>>t;
    while(t--)
    {
        f>>a>>b>>c;
        euclid_extins(a,b,cmmdc,x,y);
        if(c%cmmdc)
        {
            g<<"0 0\n";
        }
        else
            g<<c/cmmdc*x<<" "<<c/cmmdc*y<<"\n";
    }
    return 0;
}
