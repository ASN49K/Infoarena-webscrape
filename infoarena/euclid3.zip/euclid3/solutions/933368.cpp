#include <stdio.h>
#include <iostream>
#include <utility>
#include <fstream>

using namespace std;

void gcd_ext(int a, int b, int &d, int &x, int &y)
{
    if (b == 0)
    {
        d = a;
        x = 1;
        y = 0;
    } else {
        int x0, y0;
        gcd_ext(b, a%b, d, x0, y0);
        x = y0;
        y = x0 - (a / b)* y0;
    }
}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    int T;
    scanf("%d", &T);
    printf("%d\n", T);

    int a,b,c;
    int d;
    long long x,y;
    for(int i = 0; i < T; ++i)
    {
        scanf("%d %d %d", &a, &b, &c);
        gcd_ext(a, b, d, x, y);
        if (c % d) {printf("%d %d\n", 0, 0);}
        else{
            x = x * (c / d);
            y = y * (c / d);
            int tmp = b / d;
            long long r = x % tmp;
            long long q = x / tmp;
            x = r;
            y = y + (a / d)*q;
            printf("%lld %lld\n", x, y);
        }
    }
    return 0;
}
