#include <fstream>

void extended_euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *y = 0;
        *x = 1;
    } else {
        int x0, y0;
        extended_euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - a / b * y0;
    }
}

// Test code
int main()
{
    std::ifstream fin("euclid3.in");
    std::ofstream fout("euclid3.out");

    int T;
    fin >> T;

    while (T--) {
        int a, b, c;
        fin >> a >> b >> c;

        int x, y, d;
        extended_euclid(a, b, &d, &x, &y);
        if (c % d != 0) {
            fout << 0 << " " << 0 << "\n";
        } else {
            x = x * (c / d);
            y = y * (c / d);
            fout << x << " " << y << "\n";
        }
    }

    return 0;
}
