#include <cstdio>
using namespace std;

void euclid( int a, int b, int &x, int &y, int &d ){

    if( b == 0 ){
        x = 1;
        y = 0;
        d = a;
        return ;
    }

    int x1, y1, q;
    q = a / b;
    euclid( b, a%b, x1, y1, d );
    x = y1;
    y = x1 - y1*q;


}


int main()
{

    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);

    int n, i, j, s, t, d, c, x, y, a, b;

    scanf("%d",&n);
    for( i = 1; i <= n; ++i ){
        scanf("%d%d%d",&a,&b,&c);
        x = y = d = 0;
        euclid( a, b, x, y, d );
        if( c % d != 0 ) printf("0 0\n");
        else{
            printf("%d %d\n",x*(c/d),y*(c/d));
        }

    }



    return 0;
}
