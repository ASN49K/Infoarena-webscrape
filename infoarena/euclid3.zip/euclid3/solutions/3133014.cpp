#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclid(int a, int b, int &d, int &x, int &y)
{
    if(b == 0)
    {
        d = a;
        x = 1;
        y = 0;
        return;
    }
    else
    {
        int x0, y0;
        euclid(b, a%b, d, x0, y0);
        x = y0;
        y = x0 - (a/b)*y0;
    }
}


int main()
{
    int t, a, b, c, x, y, d;
    cin >> t;
    while(t-->0)
    {
        cin >> a >> b>>c;
        euclid(a, b, d, x, y);
        if(c%d != 0)
            cout << "0 0\n";
        else
            cout << x*c/d << ' ' << y*c/d << endl;//am inmultit cu c/d deoarece am calculat pentru ax+by=d

    }


    return 0;
}
