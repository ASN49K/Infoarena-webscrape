#include <fstream.h>


void euclid(int a, int b, int &d, int &x, int &y)
{
 if (b==0) {
	    d=a;
	    x=1;
	    y=0;
	   }
    else
    {
     int x0,y0;
     euclid(b,a%b,d,x0,y0);
     x=y0;
     y=x0-(a/b)*y0;
    }
}

int main()
{
 ifstream fin("euclid3.in");
 ofstream fout("euclid3.out");
 int a,b,d,c,x,y,test;
 fin>>test;
 while (test--)
  {
   fin>>a>>b>>c;
   euclid(a,b,d,x,y);
   if (c%d) fout<<"0 0\n";
      else
       {
	x*=c/d; y*=c/d;
	fout<<x<<" "<<y<<"\n";
       }
  }
 fin.close(); fout.close();
 return 0;
}