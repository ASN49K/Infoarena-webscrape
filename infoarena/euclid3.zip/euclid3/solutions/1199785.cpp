#include <cstdio>

using namespace std;
int euclid(int a, int b, int &x, int &y);
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    int a, b, c, n, i, d, x, y;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        d = euclid(a,b,x,y);
        if(c%d)
            printf("0 0\n");
        else
            printf("%d %d\n",x*(c/d),y*(c/d));
    }
    return 0;
}
int euclid(int a, int b, int &x, int &y)
{
    if(b==0)
    {
        x=1; y=0;
        return a;
    }
    int x0, y0, d;
    d=euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-y0*(a/b);
    return d;
}
