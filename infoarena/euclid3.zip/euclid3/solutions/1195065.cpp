#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int t, l, a, b, x, y, d, c, cm;
void euclid(int a, int b, int *x, int *y)
{
    if (b==0) {
        *x=1;
        *y=0;
    }
    else {
        int x0, y0;
        euclid(b, a%b, &x0, &y0);
        *x=y0;
        *y=x0-(a/b)*y0;
    }
}
int main()
{
    f>>t;
    for (l=1; l<=t; l++) {
        f>>a>>b>>c;
        int copa=a, copb=b;
        while (copb!=0) {
            int r=copa%copb;
            copa=copb;
            copb=r;
        }
        cm=copa;
        euclid(a, b, &x, &y);
        if (c%cm==0)
            g<<x*(c/cm)<<" "<<y*(c/cm)<<"\n";
        else
            g<<0<<" "<<0<<"\n";
    }
    return 0;
}

