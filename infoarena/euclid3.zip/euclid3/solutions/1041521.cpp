#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("perm2.in");
ofstream fout("perm2.out");

const int N = 100005;

int n, k, nr, a[N];
vector <bool> viz(N);
vector <int> sol;

void Dfs(int x)
{
    nr++;
    viz[x] = 1;
    if(!viz[a[x]]) Dfs(a[x]);
}

int cmmdc(int a, int b)
{
    if(!b) return a;
    else return cmmdc(b, a%b);
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>a[i];
    for(int i=1; i<=n; i++)
        if(!viz[i])
        {
            nr = 0;
            Dfs(i);
            cout<<nr<<endl;
            sol.push_back(nr);
        }
    long long div, cmmc = 1;
    for(unsigned i=0; i<sol.size(); i++)
    {
        div = cmmdc(cmmc, sol[i]);
        cmmc = cmmc * sol[i] / div;
    }
    fout<<cmmc;
    return 0;
}
