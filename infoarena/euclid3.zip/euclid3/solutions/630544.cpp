#include <fstream>


using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");

long long cmmdc( int a, int b, int &x, int &y )
{
  if (b==0)
  {
    x=1;
    y=0;
    return a;
  }
  int x0,y0,d;
  d=cmmdc(b,a%b,x0,y0);
  x=y0;
  y=x0-(a/b)*y0;
  return d;
}

int main()
{
  int t,a,b,c,d,x,y;
//  cout<<"a= "<<"b= "<<"c= "<<endl;;
  in>>t;
  for (int i=1;i<=t;i++)
  {
    in>>a>>b>>c;
    d=cmmdc(a,b,x,y);
    if (c%d)
      out<<"0 0";
    else
      out<<x*(c/d)<<" "<<y*(c/d)<<endl;
  }
  return 0;
}
