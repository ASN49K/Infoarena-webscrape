#include<cstdio>
using namespace std;
int T,a,b,c,d,x,y;
void cmmdc(int a,int b)
{
    if(b==0)
    {
        d=a; x=1; y=0;
        return;
    }
    cmmdc(b,a%b);
    int x0=x,y0=y;
    x=y0; y=x0-(a/b)*y0;
}
int main()
{
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	scanf("%d",&T);
	for(;T;T--)
	{
	    scanf("%d%d%d",&a,&b,&c);
	    cmmdc(a,b);
	    if(c%d) printf("0 0\n");
	    else printf("%d %d\n",x*(c/d),y*(c/d));
	}
	return 0;
}
