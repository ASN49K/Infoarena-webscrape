#include <cstdio>
#define in "euclid3.in"
#define out "euclid3.out"

using namespace std;

inline void Euclid(int a,int b,int &d,int &x,int &y)
{
    if(b == 0)
    {
        d = a;
        x = 1;
        y = 0;
    }
    else
    {
        int x0,y0;
        Euclid(b,a%b,d,x0,y0);
        x = y0;
        y = x0 -(a/b)*y0;
    }
}

int main()
{
    freopen(in,"r",stdin);
    freopen(out,"w",stdout);

    int n,a,b,c;
    scanf("%d",&n);

    while(n--)
    {
        scanf("%d%d%d",&a,&b,&c);
        int d,x,y;
        Euclid(a,b,d,x,y);

        if(c%d == 0)
            printf("%d %d\n",x*(c/d,y*(c/d)));
        else printf("0 0\n");
    }


    fclose(stdin); fclose(stdout);
    return 0;
}
