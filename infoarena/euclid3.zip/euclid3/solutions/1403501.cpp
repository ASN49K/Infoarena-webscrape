#include <fstream>
using namespace std;
long euclid(long a, long b, long *x, long *y)
{
    if(b==0)
    {
        *x=1;
        *y=0;
        return a;
    }
    else
    {
        long x0, y0, d;
        d=euclid(b, a%b, &x0, &y0);
        *x=y0;
        *y=x0-(a/b)*y0;
        return d;
    }
}
int main()
{
    ifstream in("euclid3.in");
    ofstream out("euclid3.out");
    long t, a, b, x, y, c, d;
    in>>t;
    for(long i=0; i<t; ++i)
    {
        in>>a>>b>>c;
        d=euclid(a, b, &x, &y);
        if(c%d) out<<"0 0\n";
        else out<<x*c/d<<' '<<y*c/d<<'\n';
    }
    return 0;
}
