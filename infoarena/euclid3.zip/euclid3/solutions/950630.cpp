#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int x,y,d;

void extended_euclid (int a, int b)
{
    if (b==0)
    {
        d=a; x=1; y=0; return;
    }
    else extended_euclid (b,a%b);
    int temp=y;
    y=x-(a/b)*y;
    x=temp;
}

int main()
{
    int t,a,b,c;
    f>>t;
    for (int i=1;i<=t;i++)
    {
        f>>a>>b>>c;
        extended_euclid (a,b);
        if (c%d==0) g<<x*(c/d)<<" "<<y*(c/d)<<"\n";
        else g<<"0 0\n";
    }

    f.close();g.close();
    return 0;
}
