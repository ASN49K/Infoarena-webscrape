#include <iostream>
#include <fstream>
#include <unordered_set>

std::ifstream fin("euclid3.in");
std::ofstream fout("euclid3.out");

#define maxim(a, b) ((a > b) ? a : b)
#define FOR(i, a, b) for (i = a; i <= b; ++i)


int gcdExtended(int a, int b, int *x, int *y)
{
	if (a == 0)
	{
		*x = 0;
		*y = 1;
		return b;
	}

	int x1, y1;
	int gcd = gcdExtended(b%a, a, &x1, &y1);


	*x = y1 - (b / a) * x1;
	*y = x1;

	return gcd;
}

int main()
{
	int T;
	fin >> T;

	while (T-- > 0) {
		int A, B, C;
		fin >> A >> B >> C;
		int D, X, Y;
		D = gcdExtended(A, B, &X, &Y);

		if (C%D) {
			fout << 0 << '\n';
		}
		else
			fout << X * (C / D)<< ' ' << Y * (C / D) << '\n';
	}

	system("pause");
	return 0;
}