#include<stdio.h>
int tc;
int sir[15000];
int contor;


int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);

    scanf("%d",&tc);
    for(; tc; tc--)
     {
         int a, b, c;
         scanf("%d %d %d", &a, &b, &c);
         int aux1 = a;
         int aux2 = b;
         sir[0] = 0;
         while (aux2 != 0)
          {
              sir[++sir[0]] = aux1 / aux2;
              int e3 = aux1;
              aux1 = aux2;
              aux2 = e3 % aux2;
          }
         int x = 1;
         int y = 0;
         while (sir[0] != 0)
          {
              int aux = x;
              x = y;
              y = aux - sir[sir[0]] * y;
              sir[0]--;
          }

         if (c % aux1)
                 printf("0 0\n");
            else
             printf("%d %d\n", x * (c / aux1), y * (c / aux1));
     }
    return 0;
}
