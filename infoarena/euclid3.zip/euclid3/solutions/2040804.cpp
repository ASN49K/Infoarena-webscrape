#include <iostream>
#include <fstream>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
long long int a,b,d,x,y,c;

void cmmdc(int a, int b, int &x, int &y, int &d)
{
    if(!b)
    {
        x=1;
        y=0;
        d=a;
    }
    else
    {
        int x0,y0;
        cmmdc(b,a%b,x0,y0,d);
        y=x0-y0*(a/b);
        x=y0;
    }
}

int main()
{
    int n;
    f>>n;
    for(int i=0;i<n;++i)
    {
        f>>a>>b>>c;
        cmmdc(a,b,x,y,c);
        if(c%d==0)
            g<<"0 0\n";
        else
            g<<x<<' '<<y<<'\n';
    }
    return 0;
}
