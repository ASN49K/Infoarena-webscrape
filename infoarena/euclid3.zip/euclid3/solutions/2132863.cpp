#include<stdio.h>
using namespace std;


void eeuclid(int a, int b, int &x, int &y, int &d){
  if(b==0){
    x=1;
    y=0;
    d=a;
    return;
  }
  int xx, yy, q=a/b;
  eeuclid(b, a%b, xx, yy, d);
  x=yy;
  y=xx-q*yy;
}

int main(){
  FILE*fin=fopen("euclid3.in", "r");
  FILE*fout=fopen("euclid3.out", "w");
  int n, i, a, b, c, r, d, x, y;
  fscanf(fin, "%d", &n);
  for(i=1; i<=n; i++){
    fscanf(fin, "%d%d%d", &a, &b, &c);
    eeuclid(a, b, x, y, d);
    if(c%d==0)
      fprintf(fout, "%d %d\n", x*(c/d), y*(c/d));
    else
      fprintf(fout, "0 0");
  }
  return 0;
}

