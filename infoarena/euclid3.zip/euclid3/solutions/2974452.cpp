#include <bits/stdc++.h>

using namespace std;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");
int t;
int a,b,c;
int d,x,y;
void euclid(int a,int b,int &d,int &x,int &y)
{
    if (b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        int x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int main()
{
    fin>>t;
    while (t--)
    {
        fin>>a>>b>>c;
        x=y=0;
        euclid(a,b,d,x,y);
        if (c%d!=0) fout<<"0 0\n";
        else
        fout<<x*(c/d)<<' '<<y*(c/d)<<'\n';
    }
    return 0;
}
