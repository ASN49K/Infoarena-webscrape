#include <fstream>

using namespace std;
int x,y,x0,y0;
int cmmdc(int a ,int b)
{
    int r;
    while(b)
    {
        r=a%b;
        a=b;
        b=r;
    }
    return a;
}
void euler (int a , int b)
{
    if(b==0)
    {
        x=1;
        y=0;
        return ;
    }
    else
    {
        euler(b,a%b);
        x0=x;y0=y;
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int main()
{
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");
     int a,t,b,i,c,d;
     f>>t;
     for(i=1;i<=t;i=i+1)
     {
    f>>a>>b>>c;
   d=cmmdc(a,b);
   euler(a,b);
   if(c%d!=0)
    g<<0<<' '<<0<<'\n';
   else
    g<<x*(c/d)<<' '<<y*(c/d)<<'\n';

     }


    return 0;
}
