#include <fstream>
#include <iostream>
#include <algorithm>
#include <tuple>

using namespace std;

template<class T>
tuple<T, T, T> Gcd(T a, T b) {
    if (b == 0) {
        return make_tuple(a, 1, 0);
    } else {
        const auto& x = Gcd(b, a % b);
        return make_tuple(get<0>(x),
                          get<2>(x),
                          get<1>(x) - get<2>(x) * (a / b));
    }
}

int main() {
#ifdef INFOARENA
    ifstream cin("euclid3.in");
    ofstream cout("euclid3.out");
#endif
    int num_tests; cin >> num_tests;
    while (num_tests--> 0) {
        int a, b, c; cin >> a >> b >> c;
        const auto& gcd_values = Gcd(a, b);
        if (c % get<0>(gcd_values)) {
            cout << "0 0\n";
        } else {
            c /= get<0>(gcd_values);
            cout << get<1>(gcd_values) * c << ' '
                 << get<2>(gcd_values) * c << '\n';
        }
    }
}
