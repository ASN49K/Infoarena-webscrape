#include <fstream>
using namespace std;

int x, y;


int euclid(int a, int b, int &x, int &y){
    using namespace std;
    if(b==0){
        x=1;
        y=0;
        return a;
    }
    int x0, y0, d;
    d=euclid(b, a%b, x0, y0);

    x=y0;
    y=x0-(a/b)*y0;
    return d;
}

int main(){
    using namespace std;
    ofstream out("euclid3.out");
    ifstream in("euclid3.in");

    int n;

    in>>n;

    for(; n ; n--){
        int a, b, c, d;
        in>>a>>b>>c;
        d=euclid(a, b, x, y);
        //out<<d<<" ";
        if(c%d!=0) out<<"0 0\n";
        else out<<x*(c/d)<<" "<<y*(c/d)<<"\n";
    }
    return 0;
}
