#include <bits/stdc++.h>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int cmmdc(int,int,int&,int&);
int main()
{
    int t;
    f>>t;
    for(;t;t--)
    {
        int a,b,c,d,x,y;
        f>>a>>b>>c;
        d=cmmdc(a,b,x,y);
        if(c%d)
        {
            x=y=0;
        }
        else
        {
            x*=c/d;
            y*=c/d;
        }
        g<<x<<' '<<y<<'\n';
    }

    return 0;
}
int cmmdc(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;y=0;
        return a;
    }
    int X,Y,D;
    D=cmmdc(b,a%b,X,Y);
    x=Y;
    y=X-(a/b)*Y;
    return D;
}
