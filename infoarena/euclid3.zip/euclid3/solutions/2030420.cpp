#include<stdio.h>
FILE*fin,*fout;
void euclid(int a,int b,int* x,int* y,int* d)
{
    //printf("aici %d %d\n",a,b);
    if(b==0)
    {
        *x=1;
        *y=0;
        *d=a;
    } //daca am ajuns la 0 putem determina x si y si cmmdc
    else
    {
        int x0,y0; //alocam in memorie x,y pentru pasul anterior
        euclid(b,a%b,&x0,&y0,d); //ne ducem cu un pas mai jos pentru a determina x0,y0 si d
        *x=y0;
        *y=x0-(a/b)*y0;
    }
}
int main()
{
    fin=fopen("euclid3.in","r");
    fout=fopen("euclid3.out","w");
    int T;
    fscanf(fin,"%d",&T);
    for(int i=1; i<=T; i++)
    {
        int a,b,c;
        fscanf(fin,"%d%d%d",&a,&b,&c);
        int X,Y;
        int D;
        euclid(a,b,&X,&Y,&D);
        printf("%d %d %d\n",X,Y,D);
        if(c%D==0)
        {
            X*=c/D;
            Y*=c/D;
        }
        else
        {
            X=0;
            Y=0;
        }
        fprintf(fout,"%d %d\n",X,Y);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
