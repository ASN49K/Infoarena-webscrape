#include <fstream>



using namespace std;



ifstream fin("euclid3.in");

ofstream fout("euclid3.out");



int t, a, b, c, d, x, y;



void euclid(int a, int b, int &x, int &y){

    if(b == 0){

        d = a;

        x = 1;

        y = 0;

        return;

    }

    int x0, y0;

    euclid(b, a%b, x0, y0);

    x = y0;

    y = x0 - (a/b)*y0;

}



int main(){

    fin>>t;

    while(t--){

        fin>>a>>b>>c;

        x, y = 0;

        euclid(a, b, x, y);

        if(c%d == 0)

            fout<<x*(c/d)<<" "<<y*(c/d);

        else

            fout<<"0 0";

        fout<<"\n";

    }

    return 0;

}
