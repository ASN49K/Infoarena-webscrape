#include <stdio.h>

void euclid( int a, int b, int *c, int *x, int *y )
{
  int x0, y0;
  if (b == 0){
    *c = a;
    *x = 1;
    *y = 0;
  }
  else{
    euclid( b, a % b, c, &x0, &y0 );
    *x = y0;
    *y = x0 - ( a / b ) * y0;
  }
}
int main()
{
    FILE *fin, *fout;
    fin = fopen( "euclid3.in", "r" );
    fout = fopen( "euclid3.out", "w" );
    int n, a, b, c, i, cmmdc, x, y;
    fscanf( fin, "%d", &n );
    for ( i = 0; i < n; i++ ){
      fscanf( fin, "%d%d%d", &a, &b, &c );
      euclid( a, b, &cmmdc, &x, &y );
      if ( c % cmmdc != 0 ){
        fprintf( fout, "0 0\n" );
      }
      else{
        fprintf( fout, "%d %d\n", x * ( c / cmmdc ), y * ( c / cmmdc ) );
      }
    }
    return 0;
}
