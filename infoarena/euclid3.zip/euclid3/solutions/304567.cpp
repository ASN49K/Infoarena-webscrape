#include <stdio.h>
int a,b,c,x,y,t;
int main(){
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d %d %d",&a,&b,&c);
		for(x=-c;x<=c;x++)
			for(y=-c;y<=c;y++){
				if ( ( a*x+b*y ) == c ) printf("%d %d\n",x,y),x=c+1,y=c+1;
				if (x==c && y==c) printf("0 0\n");
			}

	};
return 0;
}