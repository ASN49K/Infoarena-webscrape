#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");

long long cmmdc(long long a,long long b)
{
    long long aux;
    while (b!=0)
    {
        aux=a%b;
        a=b;
        b=aux;
    }
    return a;
}
int main()
{
    int T,a,x,b,y,c,d,n,m,im;
    fin>>T;
    for (int i=1;i<=T;i++)
    {
        /// A*X+B*Y=C
        /// N*X+M*Y=C
        fin>>a>>b>>c;
        if (a==0||b==0)
        {
            y=1;
            d=a+b;
            if (d!=0&&c%d==0)
                fout<<c/d<<" "<<c/d;
            else
                fout<<0<<" "<<0;
        }
        else
        {
            d=cmmdc(a,b);
            n=a/d;
            m=b/d;
            im=c/d;
            if (c%d==0)
            {
                x=1;
                while ((1-n*x)%m!=0)
                    x++;
                y=(1-n*x)/m;
                fout<<x*im<<" "<<y*im;
            }
            else
                fout<<0<<" "<<0;
        }
        fout<<'\n';
    }
    return 0;
}
