#include <fstream>
#include <iostream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int euclid (int a, int b, int &x, int &y) {
    if (b == 0) {
            x = 1;
            y = 0;
            return a;
    }
    int x0, y0;
    int d = euclid(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;

}

int main()
{
    int n, a, b, c, x, y, i, euc;
    f >> n;
    for (i = 1; i <= n; ++i) {
        f >> a >> b >> c;

        euc = euclid(a, b, x, y);
        if (c % euc == 0) g << x * (c / euc) << " " << y * (c / euc) << "\n";
        else g << "0 0\n";
    }

    return 0;
}
