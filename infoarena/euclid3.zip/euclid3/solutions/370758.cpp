#include <stdio.h>
#include <assert.h>

inline int euclid(int a,int b,int &x,int &y){
 if(b==0){
 x=1;
 y=0;
 return a;}
  int x0,y0,d;
  d=euclid(b,a%b,x0,y0);
  x=y0;
  y=x0-(a/b)*y0;
    return d;


}


int main(){
freopen("euclid3.in","rt",stdin);
freopen("euclid3.out","wt",stdout);


 int t;
for(scanf("%d",&t),assert(t<=100);t;t--){
int a,b,c;
scanf("%d %d %d",&a,&b,&c);
assert(-1000000000<=a && a<=1000000000);
assert(-1000000000<=b && b<=1000000000);
assert(-2000000000<=c && c<=2000000000 && c!=0);
int d,x,y;
d=euclid(a,b,x,y);
if(c%d!=0){printf("0 0\n");}else{

printf("%d %d\n",x*(c/d),y*(c/d)); }

}

 return 0;
}