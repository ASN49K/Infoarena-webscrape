#include <stdio.h>
#include <stdlib.h>

#define FILE_IN "euclid3.in"
#define FILE_OUT "euclid3.out"

void gcd(int a, int b, int *d) {
    if(b == 0) {
        *d = a;
    }
    else {
        gcd(b, a % b, d);
    }
}

void euclid(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");

    int n, a, b, c, d;
    int x, y;

    fscanf(fileIn, "%d", &n);
    for(int i = 0; i < n; i++) {
        fscanf(fileIn, "%d%d%d", &a, &b, &c);
        gcd(a, b, &d);
        if(c % d != 0) {
            fprintf(fileOut, "0 0\n");
        }
        else {
            euclid(a, b, &d, &x, &y);
            fprintf(fileOut, "%d %d\n", x * c / d, y * c / d);
        }
    }

    fclose(fileIn);
    fclose(fileOut);
    return 0;
}
