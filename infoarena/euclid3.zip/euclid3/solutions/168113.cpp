#include <iostream.h>
#include <stdio.h>

int main(void){

ifstream 
   
return 0;    
}
