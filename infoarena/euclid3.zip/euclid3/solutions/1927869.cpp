#include <stdio.h>

using namespace std;

FILE*f=fopen("euclid3.in","r");
FILE*g=fopen("euclid3.out","w");

int cmmdc(int a, int b)
{
    int aux;
    while (b>0)
    {
        aux=a;
        a=b;
        b=aux%b;
    }
    return a;
}

void euclid_extins(int &x,int &y,int a,int b)
{
    int aux;
    if (b==0)
    {
        x=1;y=0;
    }
    else
    {
        euclid_extins(x,y,b,a%b);
        aux=x;
        x=y;
        y=aux-(a/b)*y;
    }
}

int main()
{
    int a,b,c,x,y,t,d;
    fscanf(f,"%d",&t);
    while (t>0)
    {
        t--;
        fscanf(f,"%d%d%d",&a,&b,&c);
        d=cmmdc(a,b);
        if (c%d!=0) fprintf(g,"0 0\n");
        else{
        euclid_extins(x,y,a,b);
        fprintf(g,"%d %d\n",x*(c/d),y*(c/d));
        }
    }
    fclose(f);
    fclose(g);
    return 0;
}
