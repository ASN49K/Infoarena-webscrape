#include <fstream>

using namespace std;

ifstream cin("euclid3.in");

ofstream cout("euclid3.out");

int gcd(int a, int b, int &x, int &y)

{

    if (b == 0)
    {

        x = 1, y = 0;

        return a;
    }

    int d, x0, y0;

    d = gcd(b, a % b, x0, y0);

    x = y0;

    y = x0 - (a / b) * y0;

    return d;
}

int main()

{

    int T;
    cin >> T;

    while (T--)

    {

        int a, b, c, x, y;

        cin >> a >> b >> c;

        int d = gcd(a, b, x, y);

        if (c % d != 0)

            cout << 0 << ' ' << 0 << '\n';

        else

            cout << x * (c / d) << ' ' << y * (c / d) << '\n';
    }

    return 0;
}