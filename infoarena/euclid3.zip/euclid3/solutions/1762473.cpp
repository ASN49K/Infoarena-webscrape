#include <stdio.h>
#include <stdlib.h>

using namespace std;

void cmmdc(int a, int b, int &x, int &y){
    if(b==0){
        x=1;
        y=0;
    }else{
        int x1,y1;
        cmmdc(b,a%b,x1,y1);
        x=y1;
        y=x1-a/b*y1;
    }
}

int main()
{
    FILE *fin, *fout;
    int n,a,b,x,y,c,cm;
    fin=fopen("euclid3.in","r");
    fout=fopen("euclid3.out","w");
    fscanf(fin,"%d",&n);
    for(n;n>0;n--){
        fscanf(fin,"%d%d%d",&a,&b,&c);
        cmmdc(a,b,x,y);
        cm=a*x+b*y;
        if(c%cm!=0){
            fprintf(fout,"0 0\n");
        }else{
            fprintf(fout,"%d %d\n",x*c/cm,y*c/cm);
        }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
