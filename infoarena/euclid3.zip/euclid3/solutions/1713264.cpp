#include <fstream>
using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

int T;

void euclid(int a, int b, int *d, int *x, int *y)
{
	if (b == 0) {
		*d = a;
		*x = 1;
		*y = 0;
	}
	else {
		int x0, y0;
		euclid(b, a % b, d, &x0, &y0);
		*x = y0;
		*y = x0 - (a / b) * y0;
	}
}

int main()
{
	in >> T;
	int a, b, c, d, x, y;

	for (int i = 0; i < T; ++i) {
		in >> a >> b >> c;
		euclid(a, b, &d, &x, &y);
		if (c % d)
			out << "0 0\n";
		else
			out << x * (c / d) << " " << y * (c / d) << endl;
	}

	return 0;
}