#include <iostream>
#include <fstream>
#include <limits.h>

using namespace std;

int euclid(int a, int b, int &x, int &y)
{
        if (b == 0){
            x = 1;
            y = 0;
            return a;
        }
        else{
            int x0,y0,c;
            c = euclid(b,a%b,x0,y0);
            x = y0;
            y = x0 - (a/b)*y0;

            return c;
        }
}

int main()
{
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");

    int t;
    int a,b,c,aux;
    int x,y;
    f>>t;
    for(int i=0;i<t;++i){
        f>>a>>b>>c;
        aux = euclid(a,b,x,y);

        if (c % d != 0)
            g << "0 0"<<'\n';
        else
            g << x << y << '\n';
    }
    return 0;
}
