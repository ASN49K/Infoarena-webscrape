#include <iostream>
#include <fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
int a,b,c,t,d;

int cmmdc(int x,int y){
    if(y==0) return x;
    return cmmdc(y,x&y);
}

int main(){
    f>>t;
    for(int i=1;i<=t;i++){
        f>>a>>b>>c;
        d=cmmdc(a,b);
        if(c%d==0)g<<a<<" "<<b;
    }
return 0;
}
