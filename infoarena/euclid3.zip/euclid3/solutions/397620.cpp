#include<cstdio>
int a,b,c,n,x,y,d;
int xf,yf;
void eucl(int a,int b,int &x,int &y,int &d)
{
    if(b==0)
    {
        x=1;
        y=0;
        d=a;
        return ;
    }
    int x1,y1;
    eucl(b,a%b,x1,y1,d);
    x=y1;
    y=x1-a*y1/b;
}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        eucl(a,b,x,y,d);
        if(c%d!=0)
        {
            printf("0 0\n");
            continue;
        }
        xf=x*(c/d);
        yf=y*(c/d);
        printf("%d %d\n",xf,yf);
    }
    return 0;
}
