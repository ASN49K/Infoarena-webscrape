#include <bits/stdc++.h>

std::ifstream in("euclid3.in");
std::ofstream out("euclid3.out");

int gcd(int a, int b, int &x, int &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    
    int x0, y0;
    int ans = gcd(b, a % b, x0, y0);
    
    x = y0;
    y = x0 - (a / b) * y0;

    return ans;
}

void solve() {
    int a, b, c;
    in >> a >> b >> c;

    int x, y;
    int d = gcd(a, b, x, y);

    if (c % d != 0) {
        out << 0 << " " << 0 << '\n';
    } else {
        out << x * c / d << " " << y * c / d << '\n';
    }
}

int main() {
    int t;

    in >> t;
    while (t--) {
        solve();
    }


    return 0;
}