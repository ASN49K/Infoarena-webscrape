#include <bits/stdc++.h>

using namespace std;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");
int t, a, b, c, sa, sb, d, x, y, s;
int euclid(int a, int b, int &x, int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0, y0, d;
    d=euclid(b, a%b, x0, y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    fin >> t;
    while(t--)
    {
        fin >> a >> b >> c;
        if(a>=0)
            sa=1;
        else {
            sa=-1;
            a=-a;
        }
        if(b>=0)
            sb=1;
        else {
            sb=-1;
            b=-b;
        }
        d=euclid(a, b, x, y);

        if(c%d!=0)
            fout << "0 0" << '\n';
        else
        {
            s=c/d;
            fout << s*x*sa << ' ' << s*y*sb << '\n';
        }
    }
    return 0;
}
