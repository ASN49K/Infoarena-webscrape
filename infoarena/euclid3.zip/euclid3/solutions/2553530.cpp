#include <bits/stdc++.h>
#define P 10234573
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void Euclid(int a, int b, int &d, int &x, int &y)
{if(b==0) {d=a; x=1; y=0;}
 else {int x0,y0;
       Euclid(b,a%b,d,x0,y0);
       x=y0; y=x0-a/b*y0;
      }
}


int main()
{ int i,d,x,y,n,a,b,c;
  fin>>n;
  for(i=1;i<=n;++i)
     {fin>>a>>b>>c;
      Euclid(a,b,d,x,y);
      if(c%d!=0)
         fout<<"0 0\n";
      else fout<<c/d*x<<" "<<c/d*y<<"\n";

     }

    return 0;
}
