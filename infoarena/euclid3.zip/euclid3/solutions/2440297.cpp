#include <fstream>
#include <iostream>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

void gcd(int a, int b, int* d) {
	if(b == 0) {
		*d = a;
	} else {
		gcd(b, a % b, d);
	}
}

void euclid_extins(int a, int b, int *d, int *x, int *y)
{
    if (b == 0) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        int x0, y0;
        euclid_extins(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main(){

	int T;
	in >> T;

	int i;
	int d;
	int x, y;
	int a, b, c;

	for (i = 0; i < T; i++) {
		in >> a;
		in >> b;
		in >> c;
		euclid_extins(a, b, &d, &x, &y);
		if (c % d != 0) {
			out << "0 0\n";
		} else {
			out << x * (c / d) << " " << y * (c / d) << "\n";
		}
	}

	return 0;
}
