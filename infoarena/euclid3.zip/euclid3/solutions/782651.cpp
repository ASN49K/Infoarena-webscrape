# include <cstdio>
# define FOR(i,a,b) for(i=a;i<=b;i++)


int euclid (int a,int b, int x, int y)
{
	if (b==0)
	{
		x=1;
		y=0;
		return a;
	}
	
	int xx, yy,d;
	d=euclid (b,a%b,xx,yy);
	x=yy;
	y=xx-(a/b)*yy;
	return d;
}
main()
{
	int n,i,a,b,c,d,x,y;
	freopen ("euclid3.in","r",stdin);
	freopen ("euclid3.out","w",stdout);
	
	scanf ("%d",&n);
	
	FOR (i,1,n)
	{
		scanf ("%d%d%d",&a,&b,&c);
		d= euclid(a,b,x,y);
		if (c%d) 
			printf("0 0\n");
		else printf ("%d %d\n",x*(c/d),y*(c/d));
	}
}	
	