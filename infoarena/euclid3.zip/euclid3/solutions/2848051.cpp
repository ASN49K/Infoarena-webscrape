#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#include <bits/stdc++.h>
#define int long long

using namespace std;
#define pb push_back
#define FASTIO ios::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

#define pii pair<int , int>
#define sz(a) ((int)((a).size()))
const unsigned int MAX = 1e2+1;
inline void euclid(int a , int b ,int & d, int & x ,int & y)
{
    if(b == 0)
    {
        d = a;
        x = 1, y = 1;
    }
    else
    {
        int x1 , y1;
        euclid(b , a % b , d, x1 , y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}
int T;
int32_t main()
{
    FASTIO;
    fin>>T;
    while(T--)
    {
        int a, b , c;
        int x1 , x2 , d;
        fin>>a>>b>>c;
        euclid(a,b,d,x1,x2);
        if(x1>2000000000||x1<-2000000000 || x2>2000000000||x2<-2000000000)
            fout<<0<<' '<<0<<'\n';
        else
            c % d ? fout<<0<<' '<<0<<'\n' : fout<<x1*(c/d)<<' '<<x2*(c/d)<<'\n';
    }
}
