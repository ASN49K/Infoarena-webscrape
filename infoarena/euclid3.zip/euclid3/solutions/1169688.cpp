#include <fstream>
#include <stdio.h>
using namespace std;
FILE *fin=fopen("euclid3.in", "r");
ofstream fout("euclid3.out");
int x, y, a, b, c;

void Euclid(int a, int b, int *d, int *x, int *y)
{
    if(b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
            int x0, y0;
            Euclid(b, a%b, d, &x0, &y0);
            *x=y0;
            *y=x0-(a/b)*y0;
    }
}

int main()
{
    int i, d, t;
    fscanf(fin, "%d ", &t);
    for(i=1; i<=t; i++)
    {
        fscanf(fin, "%d %d %d ", &a, &b, &c);
        Euclid(a, b, &d, &x, &y);
        if(c%d) fout<<"0 0\n";
        else fout<<x*c/d<<' '<<y*c/d<<'\n';
    }
    fclose(fin);
    fout.close();
    return 0;
}
