program euclid3;
var fi,fo:text;
   a,b,i,d,c,n,x,y:longint;
procedure ex(a,b:longint;var d,x,y:longint);
var x0,y0:longint;
begin
if b=0 then begin  d:=a;x:=1;y:=0;end
        else begin ex(b,a mod b,d,x0,y0);
        x:=y0;
        y:=x0-(a div b)*y0;
end;
end;
begin
assign(fi,'euclid3.in');reset(fi);
assign(fo,'euclid3.out');rewrite(fo);
read(fi,n);
for i:=1 to n do begin readln(fi,a,b,c);
                       ex(a,b,d,x,y);
                       if c mod d=0 then writeln(fo,x*(c div d),' ',y*(c div d))
                                       else writeln(fo,'0 0');

                           end;
close(fi);close(fo);
end.