#include <isotream>
#include <fstream>

using namespace std;

long cmmdc(long a, long b, &X, &Y)
{

	if(!b) return a;
	
	long R, X0, Y0;
	
	R = cmmdc(b, a % b, X0, Y0);
	
	X = Y0;
	
	Y = X0 - (a / b) * Y0;
	
	return R;

}

int main()
{
	
	short T, i:
	
	long a, b, c, X, Y;
	
	freopen("euclid3.in", "r", stdin);
	freopen("euclid3.out", "w", stdout);
	
	scanf("%hd", &T);
	
	for(i=1;i<=T;++i)
	{		
		scanf("%ld %ld %ld", &a, &b, &c);
		
		X = 0, Y = 0;
		
		if(cmmdc(a, b) == c)
			print("%ld %ld\n", &X, &Y);
		else
			printf("0 0\n");
		
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;

}