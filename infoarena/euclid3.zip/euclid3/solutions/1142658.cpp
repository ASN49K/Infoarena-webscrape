#include <iostream>
#include <fstream>
using namespace std;

void euclid(int a,int b, int &d,int &x,int &y)
{
    if(b==0)
       {
           d=a;
           x=1;y=0;
       }
    else
    {

        int x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-y0*(a/b);
    }
}

int main()
{
    int n,a,b,c;
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");
    f>>n;
    while(f>>a>>b>>c)
       {
           int d,x,y;
           euclid(a,b,d,x,y);
           if(c%d)
              g<<"0 0\n";
              else
              g<<x*(c/d)<<" "<<y*(c/d)<<endl;
       }
    return 0;
}
