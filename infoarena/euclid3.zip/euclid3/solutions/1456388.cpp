# include <bits/stdc++.h>
using namespace std;
# define fi cin
# define fo cout
int gcd(int a,int b,int &x,int &y)
{
    if (!b)
    {
        x = 1;y = 0;
        return a;
    }
    int x1,y1;
    int d = gcd(b,a%b,x1,y1);
    y = x1 - int(a/b) * y1;
    x = y1;
    return d;
}
int main(void)
{
    ifstream fi("euclid3.in");
    ofstream fo("euclid3.out");
    int t;
    fi>>t;
    while (t --)
    {
        int a,b,c;
        fi>>a>>b>>c;
        int x,y;
        int d = gcd(a,b,x,y);
        if (c%d) fo << "0 0\n";
        else
        {
            c /= d;
            x *= c;y *= c;
            fo << x << ' ' << y << '\n';
        }
    }
    return 0;
}
