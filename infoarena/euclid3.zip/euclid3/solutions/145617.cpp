#include<fstream.h>
 void euclid(int a, int b, int *d, int *x, int *y)  
 {  
     if (b == 0) {  
         *d = a;  
         *x = 1;  
         *y = 0;  
     } else {  
         int x0, y0;  
         euclid(b, a % b, d, &x0, &y0);  
         *x = y0;  
         *y = x0 - (a / b) * y0;  
     }  
 }  
int main()
	{
	long a,b,d,x,y,t;
	ifstream f("euclid3.in");
	ofstream g("euclid3.out");
	f>>t;
	for(int i=\1;i<=t;i++)
		{f>>a>>b>>d;
		euclid(a,b,d,x,y);
		g<<x<<y<<endl;
		}
	f.close();
	g.close();
	return 0;
	}