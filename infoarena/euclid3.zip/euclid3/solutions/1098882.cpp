#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int a, b, c, x, y, t;

void Euclid(int, int, int&, int&);
int cmmdc(int, int);

int main(){
    int i, d;
    fin>>t;
    for(i=1; i<=t; i++){
        fin>>a>>b>>c;
        d=cmmdc(a, b);
        if(c%d!=0){
            fout<<"0 0"<<'\n';
            continue;
        }
        Euclid(a, b, x, y);
        fout<<x*c/d<<' '<<y*c/d<<'\n';
    }
    fout.close();
    return 0;
}

void Euclid(int a, int b, int &x, int &y){
    int x0, y0;
    if(!b)  {x=1; y=0; return;}
    else    Euclid(b, a%b, x0, y0);
    x=y0;
    y=x0-y0*(a/b);
}

int cmmdc(int a, int b){
    if(!b)  return a;
    return cmmdc(b, a%b);
}
