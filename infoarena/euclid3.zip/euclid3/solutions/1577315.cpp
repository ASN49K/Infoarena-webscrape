#include <fstream>
using namespace std;
ifstream f1("euclid3.in");
ofstream f2("euclid3.out");
int i,n,a,b,c,d,x,y;

int ecuatie(int a,int b,int &x,int &y)
	{
		if(b==0)
		{
			x=1;
			y=1;
			return a;
		} else
			{
				int x0,y0,d;
				d=ecuatie(b,a%b,x0,y0);
				x=y0;
				y=x0-y0*a/b;
				return d;
			}
	}

int main()
	{
		f1>>n;
		for(i=1;i<=n;i++)
			{
				f1>>a>>b>>c;
				d=ecuatie(a,b,x,y);
				if(c%d!=0)
					f2<<"0 0\n"; else
						f2<<x*(c/d)<<" "<<y*(c/d)<<'\n';
			}
		return 0;
	}
