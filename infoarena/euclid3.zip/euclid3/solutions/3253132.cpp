    #include <cstring>
    #include <fstream>
    using namespace std;
    ifstream cin("euclid3.in");
    ofstream cout("euclid3.out");
    long long Euclid(long long a, long long b, long long &x, long long &y)  {
        if(b==0) {
            x=1;
            y=0;
            return a;
        }
        else {
            long long x0,y0;
            long long d=Euclid(b,a%b,x0,y0);
            x=y0;
            y=x0-a/b*y0;
            return d;
        }

    }
    int main() {
        long long a, b, c, t;
        cin >> t;
        for (int i = 1; i <= t; i++) {
            cin >> a >> b >> c;
            long long x, y;
            long long d = Euclid(a, b, x, y);
            if (c % d == 0) {
                x *= c / d;
                y *= c / d;
                cout << x << " " << y<<" ";
                cout<<endl;
            }
            else
                cout<<0<<" "<<0;

        }
    }
