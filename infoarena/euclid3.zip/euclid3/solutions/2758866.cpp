#include <fstream>

using namespace std;

void euclid(int A, int B, int& d, int& x, int& y){
    if(B == 0){
        d = A;
        x = 1;
        y = 0;
    }
    else{
        int _x, _y;
        euclid(B, A % B, d, _x, _y);
        x = _y;
        y = _x - (A / B) * _y;
    }

}

int main()
{
    ifstream cin("euclid3.in");
    ofstream cout("euclid3.out");
         
    int T, A, B, C;
    cin >> T;
    for(int x, y, d; T > 0; --T){
        cin >> A >> B >> C;
        euclid(A, B, d, x, y);
        if(C % d)
            cout << "0 0\n";
        else cout << (long long)x * C / d << " " << (long long)y * C / d  << "\n";
    }

    cin.close();
    cout.close();

    return 0;
}