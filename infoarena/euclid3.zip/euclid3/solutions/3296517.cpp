#include <fstream>
using namespace std;
ifstream cin("euclid3.in");
ofstream cout("euclid3.out");
void euclid(int a, int b, int& d, int& x, int& y)
{
	if (b == 0)
	{
		d = a;
		x = 0;
		y = 1;
	}
	else
	{
		int xnou, ynou;
		euclid(b, a % b, d, xnou, ynou);
		x = ynou;
		y = xnou - (a / b) * ynou;
	}
}
int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		int a,b,c,x,y,d;
		cin >> a >> b >> c;
		euclid(a, b, d, x, y);
		if (c % d)
			cout << 0 << ' ' << 0 << '\n';
		else
			cout << x * (c / d) << ' ' << y * (c / d) << '\n';
 	}
}