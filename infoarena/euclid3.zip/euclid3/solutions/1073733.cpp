#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream fin("euclid3.in");
    ofstream fout("euclid3.out");
    int t;
    fin>>t;
    int a, b, c, x, y;
    for(int i=0; i< t; i++)
    {
            x = 0;y = 0;
            fin>>a>>b>>c;
            for(;;)
            {
            if(c%a == 0)
            {
                   x += c/a;
                   c = 0;
                   break;
            }
            if(c%b == 0)
            {
                   y += c/b;
                   c = 0;
                   break;
            }
            if(c< a+b) break;
            if(1)
            {
                 c -=a+b;
                 x++;y++;
            }
            if(c == 0) break;
            }
            if(c == 0) fout<<x<<" "<<y<<endl;
            else fout<<"0 0"<<endl;
    }
    return 0;
}
