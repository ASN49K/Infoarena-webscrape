#include <algorithm>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

int gcd(int a, int b) {
    if (b)
        return gcd(b, a % b);
    return a;
}

pair <int, int> coef(int a, int b) {
    if (!b)
        return make_pair(1, 0);
    pair <int, int> sol = coef(b, a % b);
    swap(sol.first, sol.second);
    sol.second -= (a / b) * sol.first;

    return sol;
}

int main() {
    ifstream cin("euclid3.in");
    freopen("euclid3.out", "w", stdout);

    int testCases, a, b, c;
    for (cin >> testCases; testCases; testCases--) {
        cin >> a >> b >> c;
        if (c % gcd(a, b) != 0)
            printf("0 0\n");
        else {
            pair <int, int> sol = coef(a, b);
            printf("%d %d\n", sol.first / gcd(a, b) * c, sol.second / gcd(a, b) * c);
        }
    }

    return 0;
}

