#include <fstream>
using namespace std;

int d;
void euclid(int a, int b, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
        return ;
    }
    int x0, y0;
    euclid(b, a % b, x0, y0);
    int c = a / b;
    x = y0;
    y = x0 - y0 * c;
}

int main()
{
    ifstream fin("euclid3.in");
    ofstream fout("euclid3.out");
    int a, b, c, t;
    fin >> t;
    for(;t;--t)
    {
        fin >> a >> b >> c;
        int x, y;
        euclid(a, b, x, y);
      //  fout << d << " " << c << '\n';
        if(c % d == 0)
        {
            fout << x * (c / d) << " " << y * (c / d) << '\n';
        }
        else
        {
            fout << 0 << " " << 0 << '\n';
        }
    }

    return 0;
}


