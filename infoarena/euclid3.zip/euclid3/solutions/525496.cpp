#include <algorithm>
using namespace std;

int t,a,b,c;

inline int euclid (int a,int b,int &x,int &y)
{
    int d,x0,y0;

    if (!b)
    {
        x=1; y=0;
        return a;
    }
    d=euclid (b,a%b,x0,y0);
    x=y0; y=x0-(a/b)*y0;

    return d;
}


int main ()
{
    freopen ("euclid3.in","r",stdin);
    freopen ("euclid3.out","w",stdout);
    int i,d,x,y;

    scanf ("%d",&t);
    for (i=1; i<=t; ++i)
    {
        scanf ("%d%d%d",&a,&b,&c);
        d=euclid (a,b,x,y);
        if (!(c%d))
            printf ("%d %d\n",x*(c/d),y*(c/d));
        else
            printf ("0 0\n");
    }

    return 0;
}
