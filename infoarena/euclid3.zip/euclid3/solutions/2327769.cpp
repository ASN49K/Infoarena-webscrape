#include<bits/stdc++.h>

using namespace std;

int q,a,b,c;
int x,y;

int ext_gcd(int a, int b, int& x, int& y) {
    if (b==0) {
        x=1;
        y=0;
        return a;
    }
    int x0,y0;
    int gcd=ext_gcd(b, a%b, x0, y0);
    x=y0;
    y=x0-a/b*y0;
    return gcd;
}

int main() {
    ifstream cin("euclid3.in");
    ofstream cout("euclid3.out");
    cin>>q;
    while (q--) {
        cin>>a>>b>>c;
        int gcd=ext_gcd(a,b,x,y);
        if (c%gcd) cout<<"0 0\n";
        else cout<<x*(c/gcd)<<" "<<y*(c/gcd)<<'\n';
    }

    return 0;
}
