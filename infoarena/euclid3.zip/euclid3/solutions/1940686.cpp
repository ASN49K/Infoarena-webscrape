#include <fstream>
using namespace std;
ifstream fin ("euclid3.in");
ofstream fout ("euclid3.out");
int n,a,b,d,x,y;
int euclid(int a, int b, int &x, int &y)
{
    int aux;
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    else
    {
        int x0,y0;
        int z = euclid(b, a % b, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
        return z;
    }
}
int main()
{
    int z;
    fin >> n;
    for(int i=1; i<=n ; i++)
    {
        fin >> a >> b >> d;
        z = euclid (a,b,x,y);
        if(d%z == 0)
            fout << x*(d/z) << ' ' << y*(d/z) << '\n';
        else
            fout<<"0 0 \n";
    }

    return 0;
}
