program euclid3;
var     f,g:text;
        t,i,a,b,c,d,x,y:longint;
procedure euclid(a,b:longint; var d,x,y:longint);
var       x0,y0:longint;
begin
  if b=0 then
    begin
      d:=a; x:=1; y:=0;
    end
  else
    begin
      euclid(b,a mod b,d,x0,y0);
      x:=y0; y:=x0-(a div b)*y0;
    end;
end;

begin
  assign(f,'euclid3.in'); reset(f);
  assign(g,'euclid3.out'); rewrite(g);
  readln(f,t);
  for i:=1 to t do
    begin
      readln(f,a,b,c);
      euclid(a,b,d,x,y);
      if c mod d<>0 then writeln(g,'0 0')
      else
        begin
          x:=x*(c div d);
          y:=y*(c div d);
          writeln(g,x,' ',y);
        end;
    end;
  close(f);
  close(g);
end.