#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

int ExtendedGCD(int a, int b, int &x, int &y)
{
    if(b == 0)
    {
        x = 1, y = 0;
        return a;
    }

    int x0, y0;
    int d = ExtendedGCD(b, a % b, x0, y0);

    x = y0;
    y = x0 - y0 * (a / b);

    return d;
}

int main()
{
    int T, A, B, C, D, X, Y;
    fin >> T;

    while(T--)
    {
        fin >> A >> B >> C;

        D = ExtendedGCD(A, B, X, Y);

        if(C % D == 0)
            fout << X * (C / D) << ' ' << Y * (C / D) << '\n';
        else
            fout << 0 << ' ' << 0 << '\n';
    }

    return 0;
}
