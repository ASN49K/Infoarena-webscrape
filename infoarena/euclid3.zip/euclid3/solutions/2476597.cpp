#include <fstream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

int d = 0;
int n, a, b, c;

pair<long long, long long> euclid_ext(int x, int y)
{
    if(y == 0)
    {
        d = x;
        return {1, 0};
    }
    pair<long long, long long> p = euclid_ext(y, x%y);
    return {p.second, p.first-(x/y)*p.second};
}


void citire()
{
    f>>n;
    for(int i=0; i<n; ++i)
    {
        f>>a>>b>>c;
        d = 0;
        pair<long long, long long> rez = euclid_ext(a, b);
        if(c%d !=0)
            g<<"0 0\n";
        else g<<rez.first*(c/d)<<" "<<rez.second*(c/d)<<'\n';

    }
}


int main()
{
    ios::sync_with_stdio(false);
    citire();
    return 0;
}
