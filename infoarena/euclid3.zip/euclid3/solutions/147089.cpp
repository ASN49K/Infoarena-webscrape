#include<cstdio>
long t,a,b,c,x,y,d;
void euclid(long a, long b, long *d, long *x, long *y){
	if(b==0){
		*d=a;
		*x=1;
		*y=0;
	}
	else{
		long x0,y0;
		euclid(b,a%b,d,&x0,&y0);
		*x=y0;
		*y=x0-y0*(a/b);
	}
}
int main(){
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	scanf("%ld",&t);
	for( ; t>0; t--){
		scanf("%ld%ld%ld",&a,&b,&c);
		euclid(a,b,&d,&x,&y);
		if(c%d!=0)
			printf("0 0\n");
		else
			printf("%ld %ld\n",x*(c/d),y*(c/d));
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
