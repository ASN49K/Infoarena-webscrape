#include <fstream>

using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

void euclid(int  a, int b, int *d, int *x, int*y)
{
    if (b == 0)
    {
        *d = a;
        *x = 1;
        *y = 0;
    }
    else
    {
        int  x0, y0;

        euclid(b, a % b, d, &x0, &y0);

        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{
    int a, b, c;
    int o, p;

    int *d, *x, *y;

    int n;

    x = &o;
    y = &p;
    d = &a;

    in>>n;

    for(int i=1; i<=n; i++)
    {
        in>>a>>b>>c;

        euclid(a,b,d,x,y);

        if(c%a==0)
            out<<1ll*o*c/a<<' '<<1ll*p*c/a<<'\n';

        else
            out<<"0 0\n";
    }

    return 0;
}
