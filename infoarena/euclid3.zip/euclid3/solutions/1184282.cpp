#include <cstdio>
#include <cstdlib>
#pragma warning(disable: 4996)
using namespace std;

int euclid(int a, int b, int &x, int &y)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
		return a;
	}
	else
	{
		int cmmdc = euclid(b, a%b, x, y) , xx;
		xx = x;
		x = y;
		y = xx - (a / b) * y;
		return cmmdc;
	}
}

int main()
{
	freopen("euclid3.in", "r", stdin);
	freopen("euclid3.out", "w", stdout);
	int nc;
	int a, b, c , cmmdc;
	int x, y , s1 , s2;

	scanf("%d", &nc);

	while (nc--)
	{
		scanf("%d %d %d", &a, &b, &c);

		cmmdc = euclid(a, b, x, y);

		if (c % cmmdc == 0)
		{
			s1 = x * (c / cmmdc);
			s2 = y * (c / cmmdc);

			printf("%d %d\n", s1, s2);
		}
		else
		{
			printf("0 0\n");
		}
	}
	
	return 0;
}