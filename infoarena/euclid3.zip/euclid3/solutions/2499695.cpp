#include <fstream>
using namespace std;
ifstream cin("euclid3.in");
ofstream cout("euclid3.out");
int cmmdc(int a,int b,int c)
{
    int r;
    while(b)
    {
        r=a%b;
        a=b;
        b=r;
    }
    if(c%a!=0)
        return 1;
    return 0;
}
long long t,i,a,b,c,x,g,j;
int main()
{
    cin>>t;
    for(i=1;i<=t;i++)
    {
        cin>>a>>b>>c;
        if(cmmdc(a,b,c)==1)
            cout<<0<<" "<<0<<"\n";
        else
        {
            g=0;
           x=c/a;
           while(g==0)
           {
               j=0;
               while((x*a)-(j*b)>=c&&g==0)
               {
                   if((x*a)-(j*b)==c)
                    {
                    cout<<x<<" "<<j<<"\n";
                   g=1;
                    }
                   j++;
               }
               x++;
           }
        }
    }
    return 0;
}
