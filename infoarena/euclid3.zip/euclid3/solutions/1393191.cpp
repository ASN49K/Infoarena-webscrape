#include <stdio.h>

using namespace std;

FILE*f=fopen("euclid3.in","r"),*g=fopen("euclid3.out","w");
int a, b, c, t;

int euclid(int k, int p,int &x, int &y)
{
    if(p == 0)
    {
        x = 1;
        y = 0;
        return k;
    }
    else{
        int x0, y0;
        int r = euclid(p, k%p, x0, y0);
        x = y0;
        y = x0 - (k/p)*y0;
        return r;
    }
}


int main()
{
    int sol1, sol2;
    fscanf(f,"%d\n",&t);
    for(int i = 1; i <= t; i++)
    {
        fscanf(f,"%d %d %d\n", &a, &b, &c);
        int d = euclid(a, b, sol1, sol2);
        if(c % d == 0)
        {
            fprintf(g,"%d %d\n",sol1 * (c/d), sol2 * (c/d));
        }
        else{
            fprintf(g,"0 0\n");
        }
    }

    return 0;
}
