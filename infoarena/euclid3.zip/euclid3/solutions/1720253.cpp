#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
int a,b,c,t,cmd,x1,x2,y,x,xi,yi;
int euclid1(int x1,int x2)
{
    if(x2==0)
        return x1;
    else
        return euclid1(x2,x1%x2);
}
void euclid2(int a,int b)
{
    int cat,r,xj,yj;
    x=1;
    xi=0;
    y=0;
    yi=1;
    while(a%b!=0)
    {
        cat=a/b;
        r=a%b;
        xj=x-(xi*cat);
        yj=y-(yi*cat);
        x=xi;
        y=yi;
        xi=xj;
        yi=yj;
        a=b;
        b=r;

    }

}
int main()
{
    int i;
    fin>>t;
    for(i=1;i<=t;i++)
    {
        fin>>a>>b>>c;
        x1=a;
        x2=b;
        cmd=euclid1(x1,x2);
     if(a==c)
        {fout<<"1"<<" "<<"0";
        fout<<"\n";}
    else if(b==c)
        {fout<<"0"<<"  "<<"1";
        fout<<"\n";}
    else if(c%cmd==0)
    {
        euclid2(a,b);
        fout<<xi*(c/cmd)<<"  "<<yi*(c/cmd);
        fout<<"\n";
    }
    else
    {
        fout<<"0"<<"  "<<"0";
        fout<<"\n";
    }
    }
    return 0;
}
