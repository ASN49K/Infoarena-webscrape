#include <fstream>

using namespace std;

ifstream cin("euclid3.in");
ofstream cout("euclid3.out");

bool pp;
long long  c,aux;
pair <long long ,long long > R;

void cmmdc(long long a,long long b)
{
    if(b==0)
        if(c%a!=0)
            R.first=R.second=0;
        else
        {
            R.first=1;
            R.second=0;
            c=c/a;
//            cout<<c<<'\n';
        }
    else
    {
        cmmdc(b,a%b);
//        cout<<'\n'<<R.first<<" "<<R.second;
//        cout<<'\n'<<a<<" "<<b;
        aux=R.first;
        R.first=R.second;
        R.second=aux-(a/b)*R.second;
//        cout<<'\n'<<R.first<<" "<<R.second<<'\n';

    }
}

int main()
{
    long long t,a,b;
    cin>>t;
    for(long long k=1;k<=t;k++)
    {
        cin>>a>>b>>c;
        if(a>=b)
        {
            cmmdc(a,b);
            cout<<R.first*c<<" "<<R.second*c<<'\n';
        }
        else
        {
            cmmdc(b,a);
            cout<<R.second*c<<" "<<R.first*c<<'\n';
        }
    }
    return 0;
}
