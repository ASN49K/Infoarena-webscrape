#include <fstream>

using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
void cmmdc(int a, int b, int &d, int &x, int &y)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        int x0,y0;
        cmmdc(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    int n;
    f>>n;
    for(int i=1;i<=n;i++)
    {
        int a,b,x,y,d,c;
        f>>a>>b>>c;
        cmmdc(a,b,d,x,y);
        if(c%d!=0)
            g<<0<<" "<<0<<'\n';
        else
            g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
    return 0;
}
