#include <stdio.h>


int cmmdc (int a, int b)
{
	if(a<0)
		a = -a;
	if(b<0)
		b = -b;
	while(a!=b)
	{
		if(a>b)
			a=a-b;
		else
			b=b-a;
	}
	
	return a;
}

 void rezolva_ec(int a, int b,int &x ,int &y )
{
	

	if(b==0)
	{
		x = 1;
		y = 0;	
	}
	else
	{
		int x0,y0;
		rezolva_ec(b,a%b,x0,y0);

		x=y0;
		y=x0-(a/b)*y0;
	}
}


int main()
{
	int T;
	
	FILE *f,*g;

	f=fopen("euclid3.in","r");
	g=fopen("euclid3.out","w");
	
	fscanf(f,"%d",&T);
	for(int i=0;i<T;i++)
	{
		int a,b,c;
		int d;

		fscanf(f,"%d %d %d",&a,&b,&c);


		//fprintf(g,"%d %d \n",a,b);

		d = cmmdc(a,b);	

		if(c%d)
				fprintf(g,"0 0\n");
			 else
			   {
				int x,y;
				rezolva_ec(a,b,x,y);
				fprintf(g,"%d %d \n",x*(c/d),y*(c/d));
			   }
	  
	}
		

	return 0;
	
}