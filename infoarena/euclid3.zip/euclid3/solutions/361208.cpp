#include<cstdio>

const int CATVA = 1<<30;

int cmmdc(int a, int b)
{
	if (a%b)
		return cmmdc(b, a%b);
	
	return b;
}

int main()
{
	FILE *f = fopen("euclid3.in", "r");
	FILE *g = fopen("euclid3.out", "w");
	int a, b, c, t;
	fscanf(f, "%d", &t);
	
	
	for (int i = 1; i <= t; ++i)
	{
		fscanf(f, "%d%d%d", &a, &b, &c);
		int d = cmmdc(a, b);
		if (c % d != 0)
		{
			fprintf(g, "0 0 \n");
			break;
		}
			
		for (int x = 1; x <= CATVA; ++x)
		
			if ((c - a * x) % b == 0)
			{
				fprintf (g, "%d %d\n", x, (c - a * x) / b);
				break;
			}
	}
	fclose(f);
	fclose(g);
	return 0;
	
}
