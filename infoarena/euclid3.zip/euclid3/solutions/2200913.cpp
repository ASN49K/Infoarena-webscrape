#include <fstream>

using namespace std;
long long a,b,c,d,x,y,n,e,z,i;
void euclid(int a,int b)
{
    if (e)
    if (b==0)
    {
        if (d%a!=0) e=0;
        d=a;
        return;
    }
    else
    {
        euclid(b,a%b);
        long long x2=y,y2=x-y*(a/b);
        x=x2;
        y=y2;
    }
}
int main()
{
    ifstream fin("euclid3.in");
    ofstream fout("euclid3.out");
    fin>>n;
    for (i=1;i<=n;i++)
    {
        fin>>a>>b>>d;
        x=1; y=0;
        e=1;
        z=d;
        euclid(a,b);
        if (e) fout<<x*z/d<<" "<<y*z/d<<"\n"; else fout<<0<<" "<<0<<"\n";
    }
    return 0;
}
