#include <fstream>

using namespace std;

const char InFile[]="euclid3.in";
const char OutFile[]="euclid3.out";

long long int a,b,c,t,d,x,y;

long long int gcd(long long int a, long long int b, long long int &x, long long int &y)	
{
	if(b==0){
		x=1;
		y=0;
		return a;
	}
	long long int x0,y0,d;
	d=gcd(b,a%b,x0,y0);
	x=y0;
	y=x0-(a/b)*y0;
	return d;
}

int main(){
	ifstream fin(InFile);
	ofstream fout(OutFile);
	fin>>t;
	for(register long long int i=0;i<t;++i){
		fin>>a>>b>>c;
		x=0;y=0;
		d=gcd(a,b,x,y);
		if(c%d==0){
			fout<<x*c/d<<" "<<y*c/d<<"\n";
		}else{
			fout<<"0 0\n";
		}
	}
	fout.close();
	fin.close();
	return 0;
}
