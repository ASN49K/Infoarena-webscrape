#include <cstdio>

inline void euclid(int a, int b, int *d, int *x, int *y) {
  if (!b) {
    *d = a;
    *x = 1;
    *y = 0;
  } else {
    int x0, y0;
    euclid(b, a % b, d, &x0, &y0);
    *x = y0;
    *y = x0 - a / b * y0;
  }
}

int main() {
  int t, a, b, c, x, y, d;
  FILE *fin = fopen("euclid3.in", "r");
  fscanf(fin, "%d", &t);
  FILE *fout = fopen("euclid3.out", "w");
  for (; t > 0; --t) {
    fscanf(fin, "%d%d%d", &a, &b, &c);
    euclid(a, b, &d, &x, &y);
    if (!(c % d)) {
      fprintf(fout, "%d %d\n", x * c / d, y * c / d);
    } else {
      fprintf(fout, "0 0\n");
    }
  }
  fclose(fin);
  fclose(fout);
  return 0;
}