#include <bits/stdc++.h>
using namespace std;
ifstream f ( "euclid3.in" );
ofstream g  ( "euclid3.out" );
int cmmdc(int a,int b,int &x,int &y)
{
    if(!b)
    {
        x=1;
        y=0;
        return a;
    }
    int xi,yi,d;
    d=cmmdc(b,a%b,xi,yi);
    x=yi;
    y=xi-(a/b)*yi;
    return d;
}
int main()
{
    int a,b,c,n;
    f>>n;
    while(n--)
    {
        f>>a>>b>>c;
        int x,y,d;
        d=cmmdc(a,b,x,y);
        if(c%d) g<<"0 0\n";
        else g<<x*(c/d)<< ' '<<y*(c/d)<< '\n';
    }

    return 0;
}
