#include <bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define pb push_back

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

void euclid(ll a,ll b, ll &d,ll&x,ll&y){
    if(!b){
        x=1;
        y=1;
        d=a;
    }
    else{
        ll x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-a/b*y0;
    }
}


int main() {
    ios_base::sync_with_stdio (false);
    cin.tie (nullptr);
    int t;
    fin>>t;
    while(t--){
        ll a,b,c,d,x,y;
        fin>>a>>b>>c;
        euclid(a,b,d,x,y);
        if(c%d)
            fout<<"0 0\n";
        else fout<<c/d*x<<' '<<c/d*y<<'\n';
    }
    return 0;
}
