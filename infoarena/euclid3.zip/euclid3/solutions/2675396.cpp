#include <iostream>
#include <fstream>
using namespace std;
ifstream f ("euclid3.in");
ofstream g ("euclid3.out");
long long euclid_extins(long long a,long long b,long long &x,long long &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    long long  fost_x,fost_y;
    long long cmmdc = euclid_extins(b,a%b,fost_x,fost_y);
    x = fost_y;
    y = fost_x + (-a/b)*fost_y;
    return cmmdc;
}
int main()
{
    long long a,b,x,y,c,t;
    f >> t;
    for(int i = 1; i<=t; i++)
    {
        f >> a >> b>> c;
        long long cmmdc;
        cmmdc =  euclid_extins(a,b,x,y);
        /// inmultim ecuatia cu c / d (d este cmmdc) pentru a ajunge la ecuatia alg lui euclid extins (daca c/d nu apartine nr naturale atunci ecuatia din pb nu are solutie)
        if(c%cmmdc==0)
            g << x*(c/cmmdc)*1LL<< " "<< y*(c/cmmdc)*1LL;
        else
            g << 0 << " "<< 0;
            g<< '\n';
    }
}
