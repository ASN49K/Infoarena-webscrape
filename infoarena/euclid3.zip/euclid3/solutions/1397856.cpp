#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll t,a,b,c,d;
ll euclid(ll a,ll b,ll &x,ll &y)
{
    if(!b)
    {
        x=1;
        y=0;
        return a;
    }
    ll x0,y0,d;
    d=euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
    return d;
}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%lld",&t);
    for(;t;t--)
    {
        scanf("%lld%lld%lld",&a,&b,&c);
        ll x,y;
        d=euclid(a,b,x,y);
        if(c%d)
            printf("0 0\n");
        else
            printf("%lld %lld\n",x*(c/d),y*(c/d));
    }
    return 0;
}
