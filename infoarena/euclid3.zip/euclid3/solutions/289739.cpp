#include<fstream.h>
ifstream f("euclid3.in");
ofstream g("euclid3.out");

float y;
long int k,m,a,b,x,ok,c,n,r;

int main()
{

f>>k;
while(k!=0)
{
f>>a>>b>>c;
m=a;n=b;

while(n!=0)
 {
  r=n;
  n=m%n;
  m=r;
  }
x=0;
ok=0;
if(c%n!=0) g<<"0 0"<<endl;
else
 while(ok==0)
	{
	(float) y = (float)(c-a*x)/b;
	if(y==(int) y) ok=1;
	else x++;
	if(x>2000000000) x=-2000000000;

	}
if(ok==1) g<<x<<" "<<y<<endl;
k--;
}
g.close();
f.close();
return 0;
}