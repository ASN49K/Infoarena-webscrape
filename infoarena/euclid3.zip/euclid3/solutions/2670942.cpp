#include <fstream>
using namespace std;
ifstream in ("euclid3.in");
ofstream out ("euclid3.out");

long long int gcd(long long int a, long long int b, long long int& x, long long int& y) {
	if (a == 0) {
		x = 0;
		y = 1;
		return b;
	}

	long long int x1, y1, d;
	d = gcd(b % a, a, x1, y1);

	x = y1 - (b / a) * x1;
	y = x1;

	return d;
}

int main()
{
    long long int n, i, a, b, c, x, y, d;

    in>>n;

    for(i = 0 ; i < n ; i++)
    {
        in >> a >> b >> c;
        d=gcd(a,b,x,y);

        if(c%d)
           out<< 0 << " " << 0 ;
        else
            out<< x * (c/d) <<" "<< y * (c/d);
        out<<'\n';
    }

    return 0;
}
