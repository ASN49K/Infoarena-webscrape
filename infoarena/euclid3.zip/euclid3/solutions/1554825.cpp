#include <fstream>

using namespace std ;

ifstream f ("euclid3.in") ;
ofstream g ("euclid3.out") ;

int euclid_extins ( int a , int b , int &x , int &y )
{
    if ( b == 0 )
        {
         x = 1 ;
         y = 0 ;
         return a ;
        }

    int x0 , y0 , d ;
    d = euclid_extins( b , a % b , x0 , y0 ) ;

    x = y0 ;
    y = x0 - ( a / b ) * y0 ;
    return d ;
}

int main()
{
    int T ;
    f >> T ;
    for ( ; T ; --T )
        {
         int a , b , c ;
         f >> a >> b >> c ;
         int d , x , y ;
         d = euclid_extins( a , b , x , y );
         if ( c % d )
            g << "0 0\n" ;
         else
            g << x * ( c / d ) << " " << y * ( c / d ) << "\n" ;
        }
    return 0;
}
