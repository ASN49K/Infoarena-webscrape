#include<cstdio>
using namespace std;
long a,b,c,d,x,y,t;
void euclid(long a, long b,long &d, long &x, long &y)
{
    if(b==0)
	{
        d=a;
        x=1;
        y=0;
	}
    else
	{
        euclid(b, a%b,d,x,y);
        long x0=x;
        x=y;
        y=x0-y*(a/b);
	}
}
int main(void)
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%ld",&t);
    while(t--)
    {
        scanf("%ld%ld%ld",&a,&b,&c);
        euclid(a,b,d,x,y);
        if(c%d)
            printf("0 0\n");
        else
            printf("%ld %ld\n",x*c/d,y*c/d);
    }
    return 0;
}
