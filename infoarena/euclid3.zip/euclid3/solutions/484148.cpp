#include <fstream>

using namespace std;


//Euclid:
int euclid(int a, int b, int &x, int &y)
{
    if (b == 0)
	{
		x = 1;
        y = 0;
		return a;
    } 
	else 
	{
        int x0, y0,D;
        D=euclid(b, a % b, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
		return D;
    }
}

//Citire:
void citire()
{
	fstream fin("euclid3.in",ios::in);
	fstream fout("euclid3.out",ios::out);
	int a,b,c,D,x,y;
	int T;
	fin>>T;
	for(register int i=1;i<=T;i++)
	{
		fin>>a>>b>>c;
		D=euclid(a,b,x,y);
		if(c%D==0) 
			fout<<x*(c/D)<<" "<<y*(c/D)<<"\n";
		else fout<<"0 0\n";
	}
	
	fin.close();
	fout.close();
}


//Main:
int main(int argc,char *argv[])
{
	citire();
	
}
