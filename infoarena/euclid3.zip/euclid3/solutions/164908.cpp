#include<stdio.h>
long x, y, r;
int t;
void gcd(long a, long b){
	if (a>=b) {r=b;}
	if (a<b) {r=a;}
		for (x=0;x<=b;x++)
			for (y=1;y>=(-a);y--){
				if( ( (a*x)+(b*y) )<r)
				if( ( (a*x)+(b*y) )>0) 
				r=(a*x)+(b*y);}
}
int main () {
	long a,b,c;
	freopen("euclid3.in", "r", stdin);
	freopen("euclid3.out", "w", stdout);
	scanf("%d", &t);
	for(int i=1; i<=t;++i){
	scanf("%d", &a); 
	scanf("%d", &b);
	scanf("%d", &c);
	gcd(a, b);
	int m=c/r;
	if (c%r==0)
			printf("%d %d\n ",-x*m , -y*m);
	else printf("0 0\n");
	}
	return 0;
}