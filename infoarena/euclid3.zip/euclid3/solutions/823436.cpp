#include <iostream>
#include <fstream>
using namespace std;
void euclid_extins(long long a, long long b, long long *d, long long *x, long long *y)
{
	if (b == 0)
	{
		*d = a;
		*x = 1;
		*y = 0;
	}
	else
	{
		long long x0, y0;
		euclid_extins(b, a % b, d, &x0, &y0);
		*x = y0;
		*y = x0 - (a / b) * y0;
	}
}
int main ()
{
	long long a,b,c,d,x,y,T;
	ifstream fi("euclid3.in");
	ofstream fo("euclid3.out");
	fi>>T;
	for (int i=1; i<=T; ++i)
	{
		fi>>a>>b>>c;
		euclid_extins(a,b,&d,&x,&y);
		if(c/d==(double)c/d)
		{
		fo<<c/d*x<<" "<<c/d*y<<"\n";
		}
		else
		{
		fo<<0<<" "<<0<<"\n";
		}
	}
	return 0;
}