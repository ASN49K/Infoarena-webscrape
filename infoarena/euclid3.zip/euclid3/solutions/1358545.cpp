#include <stdio.h>
using namespace std;
int n,a,b,c;
inline int euclid(int a, int b, int &x, int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d = euclid(b,a%b,x0,y0);
    x = y0;
    y = x0 - (a/b)*y0;
    return d;
}
int main()
{
    freopen("euclid3.in","r",stdin);
    freopen("euclid3.out","w",stdout);
    scanf("%d",&n);
    for(int i=1; i<=n; ++i)
    {
        scanf("%d %d %d",&a,&b,&c);
        int d,x,y;
        d = euclid(a,b,x,y);
        ((c%d)?printf("0 0\n"):printf("%d %d\n",x*(c/d),y*(c/d)));
    }
    return 0;
}
