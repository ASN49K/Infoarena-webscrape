#include<stdio.h>
int a,b,c;

int cmmdc(int a, int b)
{
	int r;
	while(b)
	{
		r=a%b;
		a=b;
		b=r;
	}
	return a;
}

void euclid(int a, int b, int &x, int &y, int &d)
{
	if(b==0)
	{
		x=1;
		y=0;
		d=a;
	}
	else
	{
		int x1,y1;
		euclid(b,a%b,x1,y1,d);
		x=y1;
		y=x1-a/b*y1;
	}
}

void read()
{
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	int t,d,x,y;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d%d",&a,&b,&c);
		d=cmmdc(a,b);
		if(c%d==0)
		{
			euclid(a,b,x,y,d);
			printf("%d %d\n",x*c/d,y*c/d);
		}
		else
			printf("0 0\n");
	}
}

int main()
{
	read();
	return 0;
}
