#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("euclid3.in");
ofstream fout("euclid3.out");

long long int cmmdc(long long int a, long long int b)
{
    while(a!=0)
    {
    long long r = b%a;
    b=a;
    a=r;
    }
    return b;
}

void euclid(long long int a,long long int b,long long int* d,long long int* x,long long int* y)
{
    if (!b) {
        *d = a;
        *x = 1;
        *y = 0;
    } else {
        long long int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{

long long int a, b, c, x, y, nr;

fin>>nr;
while(nr!=0)
{
    nr--;
    fin>>a>>b>>c;
    long long d =cmmdc(a, b);
    long long rez = c/d;
    if(c%d)
        fout<<0<<" "<<0<<endl;
    else
    {


        euclid(a, b, &d, &x, &y);
        fout<<x*rez<<" "<<y*rez<<endl;
    }

}

    return 0;
}
