#include <fstream>
#include <iostream>
using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

/**
void EuclidExtins(int a, int b, int &d, int &x, int &y)
{
    int x1 = 0, y1 = 1;
    x = 1, y = 0;
    while(b != 0)
    {
        int q = a / b;
        int r = a % b;
        a = b;
        b = r;
        int x0 = x - x1 * q;
        int y0 = y - y1 * q;
        x = x1;
        y = y1;
        x1 = x0;
        y1 = y0;
    }
    d = a;
}
*/

void EuclidExtins(int a, int b, int &d, int &x, int &y) //Varianta recursiva
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
    }
    else
    {
        int x0, y0;
        EuclidExtins(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    int T, a, b, c, d, x, y, k;
    f >> T;
    while(T--)
    {
        cin >> a >> b >> c;
        EuclidExtins(a, b, d, x, y);
        if(c % d != 0)
            g << "0 0\n";
        else
        {
            k = c / d;
            x *= k;
            y *= k;
            cout << x << ' ' << y << '\n';
        }
    }
    return 0;
}
