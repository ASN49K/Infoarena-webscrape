#include <fstream>
using namespace std;
ifstream in("euclid3.in");
ofstream out("euclid3.out");
void euclid(int a, int b, int &x, int &y, int &d)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
        return;
    }
    else
    {
        int xp, yp, q;
        q=a/b;
        euclid(b, a%b, xp, yp, d);
        x=yp;
        y=xp-q*yp;
    }
}
int main()
{
    int n, i, a, b, c;
    in >> n;
    for(i = 1; i <= n; i++)
    {
        in >> a >> b >> c;
        int d, x, y;
        euclid(a, b, x, y, d);
        if(c%d==0)
        {
            out << c/d * x << " " << c/d * y << '\n';
        }
        else
        {
            out << "0 0" << '\n';
        }
    }
    return 0;
}