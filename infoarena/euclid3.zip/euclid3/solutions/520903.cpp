#include <cstdio>

using namespace std;

int x, y, z,
    a, b, d,
    rev;

int stck[1024];
int size = 0;

int pop()
{
    size--;
    return stck[size];
}

void push(int x)
{
    stck[size] = x;
    size++;
}

void euclid_cmmdc()
{
    while ((x != 0)&&(y != 0))
    {
        push(x/y);
        d = y;
        y = x % y;
        x = d;
    }

    d = x + y;

    if (z % d == 0)
    {
        z = z / d;
        a = 1;
        b = 1;

        while(size)
        {
            x = b;
            y = a - pop() * b;
            a = x;
            b = y;
        }

        if (rev)
            printf("%d %d\n", b*z, a*z);
        else
            printf("%d %d\n", a*z, b*z);
    }
    else
    {
        printf("0 0\n");
        size = 0;
    }
}

int main()
{
    int nr;

    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    scanf("%d", &nr);

    while(nr--)
    {
        scanf("%d %d %d", &x, &y, &z);
        euclid_cmmdc();
    }

    return 0;
}

