#include <cstdio>
using namespace std;
long long u1, u2, u3, v1, v2, v3, r1, r2, r3;
void euclid(){
  while (v3){
    long long q = u3 / v3;
    r1 = u1 - q * v1;
    r2 = u2 - q * v2;
    r3 = u3 - q * v3;
    u1 = v1;
    u2 = v2;
    u3 = v3;
    v1 = r1;
    v2 = r2;
    v3 = r3;
  }
}
int main(){
  freopen("euclid3.in", "r", stdin);
  freopen("euclid3.out", "w", stdout);
  long long t;
  scanf("%lld", &t);
  for (long long i = 1; i <= t; ++i){
    long long u, v, x;
    scanf("%lld%lld%lld", &u, &v, &x);
    u1 = 1;
    u2 = 0;
    u3 = u;
    v1 = 0;
    v2 = 1;
    v3 = v;
    euclid();
    if (x % u3 == 0)
      printf("%lld %lld\n", u1 * x / u3, u2 * x / u3);
    else
      printf("0 0\n");
  }
  return 0;
}
