#include <fstream>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");
int t;

void euclid(int a, int b, int *d, int *x, int *y)
{
    if(b == 0)
    {
        *d = a;
        *x = 1;
        *y = 0;
    }
    else
    {
        int x0, y0;
        euclid(b, a%b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a/b) * y0;
    }
}

void solve()
{
    int a, b, c;
    f>>a>>b>>c;

    int d, x, y;
    d = 0;
    x = 0;
    y = 0;
    euclid(a, b, &d, &x, &y);
    if(c % d == 0)
    {
        g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
    }
    else
    {
        g<<0<<'\n';
    }
}

int main()
{
    f>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
