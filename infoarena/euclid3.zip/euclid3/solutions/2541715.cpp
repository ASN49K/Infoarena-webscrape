#include <bits/stdc++.h>
using namespace std;
ifstream f("euclid2.in");
ofstream g("euclid2.out");
int a,b,c,x,y,d;
void euclid(int a, int b, int d, int x, int y)
{
    if (b == 0)
    {
        d = a;
        x = 1;
        y = 0;
    }
    else
    {
        int x0, y0;
        euclid(b, a % b, d, &x0, &y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}
int n;
int main()
{
    f>>n;
    while(n--)
    {
        f>>a>>b>>c;
        euclid(a,b,d,x,y);
        if(c%d!=0)
            g<<"0 0"<<"\n";
        else
            g<<x*(c/d)<<" "<<y*(c/d)<<"\n";
    }
    return 0;
}
