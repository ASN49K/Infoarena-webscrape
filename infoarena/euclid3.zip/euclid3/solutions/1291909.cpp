#include<fstream>
using namespace std;
ifstream f("euclid3.in");
ofstream g("euclid3.out");
void euclidextins(int a,int b,int *d,int *x,int *y)
{
    if(b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
        int x0,y0;
        euclidextins(b,a%b,d,&x0,&y0);
        *x=y0;
        *y=x0-(a/b)*y0;
    }
}
int t,i,x,y,d,a,b,c;
int main()
{
    f>>t;
    for(i=0;i<t;i++)
    {
        f>>a>>b>>c;
        euclidextins(a,b,&d,&x,&y);
        if(c%d)
            g<<"0 0 \n";
        else
            g<<(c/d)*x<<' '<<(c/d)*y<<'\n';
    }
    return 0;
}
