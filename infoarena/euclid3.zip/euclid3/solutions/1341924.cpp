#include <bits/stdc++.h>

using namespace std;

int a, b, n, d, t, c, x, y;

int euclid(int a, int b, int& x, int& y)
{

    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
        int x0, y0;
        d=euclid(b, a%b, x0, y0);

        x=y0;
        y=x0-(a/b)*y0;
        return d;
    }



}

int main()
{
    freopen("euclid3.in", "r", stdin);
    freopen("euclid3.out", "w", stdout);

    scanf("%i", &t);

    for(int i=1;i<=t;++i)
    {
        scanf("%i %i %i", &a, &b, &c);

        d=euclid(a, b, x, y);

        if(c%d)
            printf("0 0\n");
        else printf("%i %i", x*(c/d), y*(c/d));
    }



    return 0;


}
