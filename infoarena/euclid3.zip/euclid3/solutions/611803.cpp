#include <fstream>
using namespace std;

ifstream in("euclid3.in");
ofstream out("euclid3.out");

int euclid(int a,int b,int& x,int&y)
{
	if (!b)
	{
		x=1;
		y=0;
		return a;
	}
	int x1,y1,d;
	d=euclid (b,a%b,x1,y1);
	x=y1;
	y=x1-a/b*y1;
	return d;
}
	
int main()
{
	int t,a,b,c,x,y,d;
	in>>t;
	while (t--)
	{
		in>>a>>b>>c;
		d=euclid(a,b,x,y);
		if (c%d)
			x=y=0;
		out<<c/d*x<<" "<<c/d*y<<"\n";
	}
	return 0;
}