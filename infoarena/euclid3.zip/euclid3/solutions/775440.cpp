#include<cstdio>
using namespace std;


int t,a,b,c,d,x,y;

int cmmdc(int a,int b)
{
	int r;
	while(b)
		r=a%b,a=b,b=r;
	return a;
}
int main()
{
	freopen("euclid3.in","r",stdin);
	freopen("euclid3.out","w",stdout);
	scanf("%d",&t);
	
	for(int i=1;i<=t;i++)
	{
		scanf("%d %d %d",&a,&b,&c);
		d=cmmdc(a,b);
		if(c%d)
		{
			printf("0 0\n");
			continue;
		}
		else
		{
			a=a/d;b=b/d;c=c/d;
			x=1;
			if(b==0)y=2;
			else
			{
			while((c-a*x)%b)
				{
					if((c+a*x)%b==0){x=-x;break;}
					x++;
				}
			y=(c-a*x)/b;
			}
			printf("%d %d\n",x,y);
			
		}
	}
	return 0;
}