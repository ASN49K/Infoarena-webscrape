#include <fstream>

using namespace std;

int euclid(const int a, const int b, int &x, int &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int nx, ny;
    int d = euclid(b, a % b, nx, ny);
    x = ny;
    y = nx - (a / b) * ny;
    return d;
}

int main() {
    ifstream f("euclid3.in");
    ofstream g("euclid3.out");
    int tests;
    f >> tests;
    for (; tests > 0; --tests) {
        int a, b, c;
        f >> a >> b >> c;
        int x, y;
        int d = euclid(a, b, x, y);
        if (c % d != 0)
            g << "0 0\n";
        else
            g << x * (c / d) << " " << y * (c / d) << "\n";
    }
    return 0;
}

