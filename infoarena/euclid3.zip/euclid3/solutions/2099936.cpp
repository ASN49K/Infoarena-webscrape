#include <bits/stdc++.h>

using namespace std;

ifstream f("euclid3.in");
ofstream g("euclid3.out");

void euclid(int a,int b,int &d,long long &x,long long &y)
{
    if (b==0)
    {
        x=1; y=0; d=a;
    }
    else
    {
        long long x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    int t,a,b,c,d;
    long long x,y;
    f>>t;
    for (int i=1;i<=t;++i)
    {
        f>>a>>b>>c;
        euclid(a,b,d,x,y);
        if (c%d==0) g<<x*(c/d)<<" "<<y*(c/d)<<'\n';
        else g<<0<<" "<<0<<'\n';
    }
    return 0;
}
