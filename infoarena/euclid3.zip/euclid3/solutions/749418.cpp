#include <fstream>
#include <cstdlib>

using namespace std;

inline void gcd(int a, int b, int& x, int& y, int& d)
{
	if(!b)
	{
		x=1;
		y=0;
		d=a;
	}
	else {
			int x0, y0;

			gcd(b, a%b, x0, y0, d);
			x=y0;
			y=x0-(a/b)*y0;
		 }
}

int main()
{
	int T, a, b, c, x, y, d;
	ifstream in("euclid3.in");
	ofstream out("euclid3.out");
	
	for(in>>T; T; --T)
	{
		in>>a>>b>>c;
		gcd(a, b, x, y, d);
		if(c%d)
			out<<"0 0\n";
		else c/=d, out<<(c*x)<<' '<<(c*y)<<'\n';
	}
	
	return EXIT_SUCCESS;
}