#include <iostream>
#include <fstream>
#define MAXN 100000
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int nodes[4*MAXN];
int v[MAXN+1];
void build(int nod, int left, int right){
    int middle=(left+right)/2;
    if(left!=right){
        build(2*nod, left, middle);
        build(2*nod+1, middle+1, right);
        nodes[nod]=max(nodes[2*nod], nodes[2*nod+1]);
    }
    else{
        nodes[nod]=v[left];
    }
}
void update(int nod, int left, int right, int poz, int val){
    int middle=(left+right)/2;
    if(left==right && left==poz){
        nodes[nod]=val;
    }
    else{
        if(poz<=middle){
            update(2*nod, left, middle, poz, val);
        }
        else{
            update(2*nod+1, middle+1, right, poz, val);
        }
        nodes[nod]=max(nodes[2*nod], nodes[2*nod+1]);
    }
}
int querry(int nod, int left, int right, int x, int y){
    if(left == x && right == y){
        return nodes[nod];
    }
    int middle=(left+right)/2;
    if(y<=middle){
        return querry(nod*2, left, middle, x, y);
    }
    if(x>middle){
        return querry(nod*2+1, middle+1, right, x, y);
    }
    return max(querry(nod*2, left, middle, x, middle), querry(nod*2+1, middle+1, right, middle + 1, y));
}
int main(){
    int n, i, m, tip, st, dr;
    fin>>n>>m;
    for(i=1;i<=n;i++){
        fin>>v[i];
    }
    build(1, 1, n);
    for(i=0;i<m;i++){
        fin>>tip>>st>>dr;
        if(tip==1){
            update(1, 1, n, st, dr);
        }
        else{
            fout<<querry(1, 1, n, st, dr)<<'\n';
        }
    }
    return 0;
}