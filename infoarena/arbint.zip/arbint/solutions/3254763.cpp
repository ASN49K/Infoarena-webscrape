#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

int n, m;
int arb[4 * 100000 + 5];

void add(const int& node, const int& left, const int& right, const int& position, const int& val) {
    if(left > right || position > right || position < left) {
        return;
    }

    if(left == right) {
        arb[node] = val;
        return;
    }

    int mid = (left + right) / 2;
    add(2 * node, left, mid, position, val);
    add(2 * node + 1, mid + 1, right, position, val);
    arb[node] = max(arb[2 * node], arb[2 * node + 1]);
}

int get(const int& node, const int& left, const int& right, const int& a, const int& b) {
    if(left > right || b < left || a > right) {
        return 0;
    }

    if(a <= left && right <= b) {
        return arb[node];
    }

    int mid = (left + right) / 2;
    return max(get(2 * node, left, mid, a, b), get(2 * node + 1, mid + 1, right, a, b));
}

void read() {
    f>>n>>m;
    int x;
    for(int i = 1;i <= n;++i) {
        f>>x;
        add(1, 1, n, i, x);
    }
}

void solve() {
    int x, y, z;
    for(int i = 1;i <= m;++i) {
        f>>x>>y>>z;
        if(x) {
            add(1, 1, n, y, z);
            continue;
        }
        g<<get(1, 1, n, y, z)<<'\n';
    }
}

int main() {
    read();
    solve();


    return 0;
}