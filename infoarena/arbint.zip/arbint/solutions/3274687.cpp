#include <iostream>
#include <fstream>
#define NMAX 100000
#include <vector>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n , m;
vector<int> aint(4*NMAX,0);
int v[NMAX];

void build(int nod, int st, int dr)
{
    if(st > dr)
        return ;
    if(st == dr)
    {
        aint[nod] = v[st];
        return ;
    }
    int m = (st + dr) / 2;
    build(nod * 2 , st , m);
    build(nod * 2 + 1 , m + 1 , dr);
    aint[nod] = max(aint[nod * 2],aint[nod * 2 + 1]);
}

void update(int nod, int st, int dr, int pos, int val)
{
    if(st > dr)
        return ;
    if(st == dr)
    {
        aint[nod] = val;
        return ;
    }
    int m = (st + dr) / 2;
    if(pos <= m)
        update(nod * 2, st, m, pos, val);
    else
        update(nod * 2 + 1, m + 1, dr, pos, val);
    aint[nod] = max(aint[nod * 2],aint[nod * 2 + 1]);
}

int query(int nod , int st , int dr , int qst , int qdr)
{
    if(qst <= st && qdr >= dr)
        return aint[nod];
    int m = (st + dr) / 2;
    if(qdr <= m)
    {
        return query(nod * 2 , st , m , qst , qdr);
    }
    else if(qst > m)
    {
        return query(nod * 2 + 1 , m + 1 , dr , qst , qdr);
    }
    else
    {
        return max(query(nod * 2 , st , m , qst , qdr) , query(nod * 2 + 1 , m + 1 , dr , qst , qdr));
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1 ; i <= n ; i++)
    {
        fin >> v[i];
    }
    build(1 , 1 , n);
    for(int i = 1 ; i <= m ; i++)
    {
        int q , a , b;
        fin >> q >> a >> b;
        if(q == 0)
        {
            fout << query(1 , 1 , n , a , b) << '\n';
        }
        else
            update(1 , 1 , n , a , b);
    }
    return 0;
}
