#include <bits/stdc++.h>
using namespace std;

#define ll int
#define cll const ll
#define nl '\n'
#define sp ' '
#define rightChild index + 2 * ((l + r) / 2 - l + 1)
#define leftChild index + 1
// #define fi cin
// #define fo cout

const string FILENAME = "arbint";
ifstream fi (FILENAME + ".in");
ofstream fo (FILENAME + ".out");

vector<ll> aint;
ll n, m;

void read();
void update(ll, ll, ll, ll, ll);
void updateNodeVal(ll, ll, ll);
void query(ll, ll, ll, ll, ll, ll&);

int main() {

    read();

    for(ll q, x, y, ans; m-- && fi >> q >> x >> y; ans = 0)
        if(q == 1)
            update(0, 0, n - 1, x - 1, y);
        else
        ans = 0, query(0, 0, n - 1, x - 1, y - 1, ans), fo << ans << nl;
    return 0;
}

void update(cll index, cll l, cll r, cll pos, cll val) {

    if(l == r)
        return void(aint[index] = val);

    cll mij = (l + r) / 2;

    if(pos <= mij)
        update(leftChild, l, mij, pos, val);
    else
        update(rightChild, mij + 1, r, pos, val);

    updateNodeVal(index, l, r);
}

void updateNodeVal(const ll index, const ll l, const ll r) {

    aint[index] = max(aint[leftChild], aint[rightChild]);
}

void read() {

    fi >> n >> m;
    aint.resize(2 * n - 1);

    for(int i = 0, a; i < n && fi >> a; ++i)
        update(0, 0, n - 1, i, a);
}

auto query(cll index, cll l, cll r, cll ql, cll qr, ll& ans)->void{

    if(ql <= l && r <= qr)
        return void(ans = max(ans, aint[index]));

    cll mij = (l + r) / 2;

    if(mij >= ql)
        query(leftChild, l, mij, ql, qr, ans);
    if(mij < qr)
        query(rightChild, mij + 1, r, ql, qr, ans);
}