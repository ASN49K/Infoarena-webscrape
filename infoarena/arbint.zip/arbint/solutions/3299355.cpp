#include <iostream>
#include <fstream>

using namespace std;

int N, M;
int A[400004];

int maxim(int a,int b)
{
    if(a>b)
        return a;
    return b;
}

void update(int nod,int st,int dr,int pos,int val)
{
    int mid;
    if(st==dr)
    {
        A[nod]=val;
        return;
    }
    mid=(st+dr)/2;
    if (pos<=mid)
        update(2*nod,st,mid,pos,val);
    else
        update(2*nod+1,mid+1,dr,pos,val);
    A[nod]=maxim(A[2*nod],A[2*nod+1]);
}


int query(int nod,int st,int dr,int l,int r)
{
    int mid;
    if(r<st || dr<l)
        return 0;
    if(l<=st && dr<=r)
        return A[nod];
     mid=(st+dr)/2;
    return maxim(query(2*nod,st,mid,l,r),query(2*nod+1,mid+1,dr,l,r));
}

int main() {
    int i,val;
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    fin>>N>>M;

    for(i=1;i<=N;i++) {
        fin >> val;
        update(1,1,N,i,val);
    }

    for(i=0;i<M;i++) {
        int op,a,b;
        fin>>op>>a>>b;
        if(op==0)
            fout<<query(1,1,N,a,b)<<'\n';
         else
            update(1,1,N,a,b);

    }
    fin.close();
    fout.close();
    return 0;
}
