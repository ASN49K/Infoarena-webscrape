#include <stdio.h>

#define MAXN 100001

int arb[4 * MAXN];
int v[MAXN];

int max(int x, int y) {
    return (x > y) ? x : y;
}

void build(int nod, int st, int dr) {
    if (st == dr) {
        arb[nod] = v[st];
        return;
    }
    
    int mij = (st + dr) / 2;
    build(2 * nod, st, mij);
    build(2 * nod + 1, mij + 1, dr);
    
    arb[nod] = max(arb[2 * nod], arb[2 * nod + 1]);
}

void update(int nod, int st, int dr, int poz, int val) {
    if (st == dr) {
        arb[nod] = val;
        return;
    }
    
    int mij = (st + dr) / 2;
    if (poz <= mij) {
        update(2 * nod, st, mij, poz, val);
    } else {
        update(2 * nod + 1, mij + 1, dr, poz, val);
    }
    
    arb[nod] = max(arb[2 * nod], arb[2 * nod + 1]);
}

int query(int nod, int st, int dr, int L, int R) {
    if (L <= st && dr <= R) {
        return arb[nod];
    }
    
    int mij = (st + dr) / 2;
    int rez_st = -1, rez_dr = -1;
    
    if (L <= mij) {
        rez_st = query(2 * nod, st, mij, L, R);
    }
    if (R > mij) {
        rez_dr = query(2 * nod + 1, mij + 1, dr, L, R);
    }
    
    return max(rez_st, rez_dr);
}

int main() {
    FILE *fin = fopen("arbint.in", "r");
    FILE *fout = fopen("arbint.out", "w");

    if (fin == NULL || fout == NULL) {
        printf("Eroare la deschiderea fisierelor!\n");
        if (fin) fclose(fin);
        if (fout) fclose(fout);
        return 1;
    }

    int n, m;
    if (fscanf(fin, "%d %d", &n, &m) != 2) {
        printf("Eroare la citirea datelor de intrare!\n");
        fclose(fin);
        fclose(fout);
        return 1;
    }

    for (int i = 1; i <= n; i++) {
        if (fscanf(fin, "%d", &v[i]) != 1){
            printf("Eroare la citirea elementelor vectorului!\n");
            fclose(fin);
            fclose(fout);
            return 1;
        } 
    }

    build(1, 1, n);

    for (int i = 0; i < m; i++) {
        int tip, a, b;
        if (fscanf(fin, "%d %d %d", &tip, &a, &b) == 3) {
            if (tip == 0) {
                fprintf(fout, "%d\n", query(1, 1, n, a, b));
            } else if (tip == 1) {
                update(1, 1, n, a, b);
            }
        }
    }

    fclose(fin);
    fclose(fout);
    return 0;
}