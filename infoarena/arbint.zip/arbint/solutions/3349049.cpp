#include <fstream>
#define nmax 100001
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,q,x,y,tip,val,aint[4*nmax];
void update(int nod,int st,int dr,int x,int val){
    if(st==dr){
        aint[nod]=val;
        return ;
    }
    int mid=(st+dr)/2;
    if(x<=mid)
        update(2*nod,st,mid,x,val);
    else
        update(2*nod+1,mid+1,dr,x,val);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
void query(int nod,int st,int dr,int x,int y){
    if(x<=st&&dr<=y){
        val=max(val,aint[nod]);
        return ;
    }
    int mid=(st+dr)/2;
    if(x<=mid)
        query(2*nod,st,mid,x,y);
    if(mid<y)
        query(2*nod+1,mid+1,dr,x,y);
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>x;
        update(1,1,n,i,x);
    }
    while(q--){
        cin>>tip>>x>>y;
        if(tip==0){
            val=0;
            query(1,1,n,x,y);
            cout<<val<<'\n';
        }else
            update(1,1,n,x,y);
    }
    return 0;
}
