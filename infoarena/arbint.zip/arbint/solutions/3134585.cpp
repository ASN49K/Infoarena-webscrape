#include <fstream>

using namespace std;
const int MAXN=1e5+5;
int mini,n,m,i,x,tip,y;
int aint[4*MAXN];

ifstream cin("arbint.in");
ofstream cout("arbint.out");

void build(int nod, int l, int r)
{
    if (l==r) cin>>aint[nod];
    else
    {
        int mid=(l+r)>>1;
        build(2*nod,l,mid);
        build(2*nod+1,mid+1,r);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }

}

void update(int nod,int l,int r,int poz,int x)
{
    if (l==r)
    {
        aint[nod]=x;
        return;
    }
    int mij=(l+r)>>1;
    if (poz<=mij) update(nod*2,l,mij,poz,x);
    else update(nod*2+1,mij+1,r,poz,x);
    aint [nod]=max(aint[nod*2],aint[nod*2+1]);
}

void query(int nod,int l,int r,int st,int dr)
{
    if (st<=l && dr>=r)
    {
        mini=max(mini,aint[nod]);
        return;
    }
    int mij=(l+r)>>1;
    if (st<=mij) query(nod*2,l,mij,st,dr);
    if (dr>mij) query(nod*2+1,mij+1,r,st,dr);
}

int main()
{
    cin>>n>>m;
    build(1,1,n);
    for (i=1;i<=m;i++)
    {
        cin>>tip>>x>>y;
        if (tip==0)
        {
            mini=-(1<<30);
            query(1,1,n,x,y);
            cout<<mini<<"\n";
        }
        if (tip==1) update(1,1,n,x,y);
    }
}
