#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100000
#define FILE_IN "arbint.in"
#define FILE_OUT "arbint.out"

int n, m, numbers[MAX_SIZE + 1];

typedef struct node_t {
    int value;
    struct node_t *leftChild, *rightChild;
} Node;

int max(int a, int b) {
    return a > b ? a : b;
}

Node* makeTree(Node *currNode, int left, int right, int arrIndex, int val) {
    if(!currNode) {
        currNode = malloc(sizeof(Node));
        currNode->leftChild = NULL;
        currNode->rightChild = NULL;
    }

    if(left == right) {
        currNode->value = val;
        return currNode;
    }

    int mid = (left + right) / 2;
    if(arrIndex <= mid) {
        currNode->leftChild = makeTree(currNode->leftChild, left, mid, arrIndex, val);
    }
    else {
        currNode->rightChild = makeTree(currNode->rightChild, mid + 1, right, arrIndex, val);
    }

    if(currNode->leftChild && currNode->rightChild) {
        currNode->value = max(currNode->leftChild->value, currNode->rightChild->value);
    }
    else if(!currNode->rightChild) {
        currNode->value = currNode->leftChild->value;
    }
    else if(!currNode->leftChild) {
        currNode->value = currNode->rightChild->value;
    }

    return currNode;
}

int searchTree(Node *currNode, int left, int right, int arrIndex1, int arrIndex2) {
    int mid = (left + right) / 2;
    int arrMid = (arrIndex1 + arrIndex2) / 2;

    if(mid == arrMid) {
        return currNode->value;
    }

    if(arrMid <= mid) {
        return searchTree(currNode->leftChild, left, mid, arrIndex1, arrIndex2);
    }
    else {
        return searchTree(currNode->rightChild, mid + 1, right, arrIndex1, arrIndex2);
    }
    /*
    if(arrIndex1 <= mid && arrIndex2 > mid) {
        return max(searchTree(currNode->leftChild, left, mid, arrIndex1, arrIndex2),
                   searchTree(currNode->rightChild, mid + 1, right, arrIndex1, arrIndex2));
    }
    else if(arrIndex2 <= mid) {
        return searchTree(currNode->leftChild, left, mid, arrIndex1, arrIndex2);
    }
    else if(arrIndex1 > mid) {
        return searchTree(currNode->rightChild, mid + 1, right, arrIndex1, arrIndex2);
    }
    */
}

void printTree(Node *currNode) {
    if(!currNode) {
        return;
    }

    printTree(currNode->leftChild);
    printTree(currNode->rightChild);
    printf("%d ", currNode->value);
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");

    Node *tree = NULL;

    fscanf(fileIn, "%d%d", &n, &m);
    for(int i = 1; i <= n; i++) {
        fscanf(fileIn, "%d", &numbers[i]);
        tree = makeTree(tree, 1, n, i, numbers[i]);
    }
    /*
    printTree(tree);
    printf("\n-----\n");
    */
    int comms[3];
    for(int i = 0; i < m; i++) {
        fscanf(fileIn, "%d%d%d", &comms[0], &comms[1], &comms[2]);

        if(comms[0] == 0) {
            fprintf(fileOut, "%d\n", searchTree(tree, 1, n, comms[1], comms[2]));
        }
        else if(comms[0] == 1) {
            tree = makeTree(tree, 1, n, comms[1], comms[2]);
        }

        printTree(tree);
        printf("\n-----\n");

    }

    fclose(fileIn);
    fclose(fileOut);
    return 0;
}
