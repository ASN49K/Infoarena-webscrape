#include <cstdio>
#define maxim(a, b) (a > b) ? a : b
using namespace std;
int n, m, i, op, a, b, nr, maxx;
int arb[400080]; // de 4 ori >n,n=100000
void update(int nod, int left, int right, int poz, int val)
{
    if (left == right)
    {
        arb[nod] = val;
        return;
    }
    int mij = (left + right) / 2;
    if (poz <= mij)
        update(2 * nod, left, mij, poz, val);
    else
        update(2 * nod + 1, mij + 1, right, poz, val);

    arb[nod] = maxim(arb[2 * nod], arb[2 * nod + 1]);
}
void query(int nod, int left, int right, int a, int b)
{
    if (a <= left && right <= b)
    {
        if (maxx < arb[nod])
            maxx = arb[nod];
        return;
    }
    int mij = (left + right) / 2;
    if (a <= mij)
        query(2 * nod, left, mij, a, b);
    if (mij < b)
        query(2 * nod + 1, mij + 1, right, a, b);
}
int main()
{
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);
    scanf("%d %d", &n, &m);
    for (i = 1; i <= n; i++)
    {
        scanf("%d", &nr);
        update(1, 1, n, i, nr);
    }
    for (i = 1; i <= m; i++)
    {
        scanf("%d %d %d", &op, &a, &b);
        if (op == 0)
        {
            maxx = 0;
            query(1, 1, n, a, b);
            printf("%d\n", maxx);
        }
        else
            update(1, 1, n, a, b);
    }
    return 0;
}