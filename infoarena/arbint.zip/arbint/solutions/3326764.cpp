#include <fstream>
#include <algorithm>
#define nmax 100005
using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int A[4*nmax];
int lazy[4*nmax];
int n, q, a, b, c, t, sol, op;

void build(int nod, int st, int dr)
{
    if(st==dr)
    {
        cin>>A[nod];
    }
    else
    {
        int mid=(st+dr)/2;
        build(2*nod,st,mid);
        build(2*nod+1,mid+1,dr);
        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}

void propagare(int nod, int st, int dr)
{
    if(lazy[nod]!=0 && st!=dr)
    {
        A[2*nod]=lazy[nod];
        A[2*nod+1]=lazy[nod];
        lazy[2*nod]=lazy[nod];
        lazy[2*nod+1]=lazy[nod];
        lazy[nod]=0;
    }
}

void update(int nod, int st, int dr, int a, int b, int val)
{
    if(a<=st && b>=dr)
    {
        A[nod]=val;
        lazy[nod]=val;
        return;
    }
    propagare(nod,st,dr);
    int mid=(st+dr)/2;
    if(a<=mid)
        update(2*nod,st,mid,a,b,val);
    if(b>mid)
        update(2*nod+1,mid+1,dr,a,b,val);
    A[nod]=max(A[2*nod],A[2*nod+1]);
}

int query(int nod, int st, int dr, int a, int b)
{
    propagare(nod,st,dr);
    if(a<=st && b>=dr)
    {
        return A[nod];
    }
    int mid=(st+dr)/2;
    int sol=-1;
    if(a<=mid)
        sol=max(sol,query(2*nod,st,mid,a,b));
    if(b>mid)
        sol=max(sol,query(2*nod+1,mid+1,dr,a,b));
    return sol;
}


int main()
{
    cin>>n>>q;
    build(1,1,n);
    while(q--)
    {
        cin>>op;
        if(op==0)
        {
            cin>>a>>b;
            cout<<query(1,1,n,a,b)<<'\n';
        }
        else if(op==1)
        {
            cin>>a>>b;
            update(1,1,n,a,a,b);
        }
    }

    return 0;
}
