
#include <fstream>
using namespace std;

ifstream cin ("arbint.in");
ofstream cout ("arbint.out");

int v[100001];
int arbore[400001];

void build (int nod , int st , int dr)
{
    if (st == dr)
    {
        arbore[nod] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    build(nod * 2 , st , mij);
    build(nod * 2 + 1 , mij + 1 , dr);

    arbore[nod] = max(arbore[nod * 2] , arbore[nod * 2 + 1]);
}

void update (int nod , int st , int dr , int poz , int val)
{
    if (st == dr)
    {
        arbore[nod] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if (mij >= poz)
    {
        update(nod * 2 , st , mij , poz , val);
    }
    else
    {
        update(nod * 2 + 1 , mij + 1 , dr , poz , val);
    }

    arbore[nod] = max(arbore[nod * 2] , arbore[nod * 2 + 1]);
}

int suma (int nod , int st , int dr , int l , int r)
{
    if (st == l && dr == r)
    {
        return arbore[nod];
    }
    int mij = (st + dr) / 2;
    if (mij < l)
    {
        return suma(nod * 2 + 1 , mij + 1 , dr , l , r);
    }
    if (mij >= r)
    {
        return suma(nod * 2 , st , mij , l , r);
    }
    return max(suma(nod * 2 + 1 , mij + 1 , dr , mij + 1 , r) , suma(nod * 2 , st , mij , l , mij));
}

int main()
{
    int n,m;
    cin >>n>>m;
    for (int i = 1; i <= n; i++)
    {
        cin >>v[i];
    }
    build(1 , 1 , n);
    for (int i = 1; i <= m; i++)
    {
        int c,st,dr;
        cin >>c>>st>>dr;
        if (c == 1)
        {
            update(1 , 1 , n , st , dr);
        }
        else
        {
            cout <<suma(1 , 1 , n , st , dr)<<"\n";
        }
    }
    return 0;
}
