#include <fstream>

using namespace std;

ifstream in;
ofstream out;

int n, m, a[100005], aint[400005];

void formareaint(int st, int dr, int pos)
{
	if (st == dr)
	{
		aint[pos] = a[st];
	}
	else
	{
		formareaint(st, st+(dr-st)/2, 2*pos);
		formareaint(st+(dr-st)/2+1, dr, 2*pos+1);
		aint[pos] = max(aint[2*pos], aint[2*pos+1]);
	}
}

int suma(int st, int dr, int wst, int wdr, int pos)
{
	if (dr < wst || st > wdr) return -1;
	if (st < wst || dr > wdr)
	{
		if (wst > st+(dr-st)/2)
		{
			return suma(st+(dr-st)/2+1, dr, wst, wdr, 2*pos+1);
		}
		else if (wdr <= st+(dr-st)/2)
		{
			return suma(st, st+(dr-st)/2, wst, wdr, 2*pos);
		}
		else
		{
			return max(suma(st+(dr-st)/2+1, dr, wst, wdr, 2*pos+1), suma(st, st+(dr-st)/2, wst, wdr, 2*pos));
		}
	}
	else
	{
		return aint[pos];
	}
}

void setare(int st, int dr, int unde, int val, int pos)
{
	if (st == dr)
	{
		aint[pos] = val;
	}
	else
	{
		if (unde <= st+(dr-st)/2)
			setare(st, st+(dr-st)/2, unde, val, 2*pos);
		else
			setare(st+(dr-st)/2+1, dr, unde, val, 2*pos+1);
		aint[pos] = max(aint[2*pos], aint[2*pos+1]);
	}
}

int main()
{
	in.open("arbint.in");
	out.open("arbint.out");
	in >> n >> m;
	for (int i = 0; i < n; i++)
	{
		in >> a[i];
	}
	formareaint(0, n-1, 1);
	for (int i = 0; i < m; i++)
	{
		int c, x, y;
		in >> c >> x >> y;
		if (c == 0)
		{
			x--; y--;
			out << suma(0, n-1, x, y, 1) << "\n"s;
		}
		else
		{
			x--;
			setare(0, n-1, x, y, 1);
		}
	}
}