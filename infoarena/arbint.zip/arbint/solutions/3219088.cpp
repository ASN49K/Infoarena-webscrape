#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX=100005;

int n, m, op, pos, val, start, finish, ans, v[NMAX], MaxTree[4 * NMAX];

void build(int node, int left, int right) {
    if(left == right) {
        MaxTree[node] = v[left];
        return;
    }

    int middle = (left + right) / 2;
    build(2 * node, left, middle);
    build(2 * node + 1,middle + 1, right);
    MaxTree[node] = max(MaxTree[2 * node], MaxTree[2 * node + 1]);
}

void update(int node,int left, int right) {
    if(left == right) {
        MaxTree[node] = val;
        return;
    }
    int middle = (left + right) / 2;
    if(pos <= middle)
        update(2 * node, left, middle);
    else
        update(2 * node + 1, middle + 1, right);
    MaxTree[node] = max(MaxTree[2 * node], MaxTree[2 * node + 1]);
}

void query(int node, int left, int right) {
    if(start<=left && right<=finish) {
        ans = max(ans, MaxTree[node]);
        return;
    }
    int middle = (left + right) / 2;
    if(start <= middle)
        query(2 * node, left, middle);
    if(middle<  finish)
        query(2 * node + 1, middle + 1, right);
}

int main() {
    fin >> n >> m;
    for(int i = 1; i <= n; i += 1)
        fin >> v[i];

    build(1, 1, n);

    for(int i = 1; i <= m; i += 1) {
        fin>>op;
        if(op == 1) {
            fin >> pos >> val;
            update(1, 1, n);
        } else {
            fin >> start >> finish;
            ans = 0;
            query(1, 1, n);
            fout << ans << '\n';
        }
    }
    return 0;
}
