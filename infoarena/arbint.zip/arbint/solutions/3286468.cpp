#include <fstream>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n, m, i, j, x[100005], a[400005], ans;
void build (int nod, int st, int dr)
{
    if(st==dr)
        a[nod]=x[st];
    else
    {
        int mij=(st+dr)/2;
        build(2*nod, st, mij);
        build(2*nod+1, mij+1, dr);
        a[nod]=max(a[2*nod], a[2*nod+1]);
    }
}
void update(int nod, int st, int dr, int poz, int val)
{
    if(st==dr)
        a[nod]=val;
    else
    {
        int mij=(st+dr)/2;
        if(poz<=mij)
            update(2*nod, st, mij, poz, val);
        if(poz>mij)
            update(2*nod+1, mij+1, dr, poz, val);
        a[nod]=max(a[2*nod], a[2*nod+1]);
    }
}
void query(int nod, int st, int dr, int l, int r)
{
    if(l<=st && dr<=r)
        ans=max(ans, a[nod]);
    else
    {
        int mij=(st+dr)/2;
        if(l<=mij)
            query(2*nod, st, mij, l, r);
        if(r>mij)
            query(2*nod+1, mij+1, dr, l, r);
    }
}
int main()
{
    int l, r, t;
    fin>>n>>m;
    for(i=1; i<=n; i++)
        fin>>x[i];
    build(1, 1, n);
    for(i=1; i<=m; i++)
    {
        fin>>t>>l>>r;
        if(t==1)
            update(1, 1, n, l, r);
        else
        {
            ans=0;
            query(1, 1, n, l, r);
            fout<<ans<<'\n';
        }
    }
    return 0;
}
