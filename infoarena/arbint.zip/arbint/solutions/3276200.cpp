#include <bits/stdc++.h>
#define nmax 100001
using namespace std;
int n,q,maxim;
int aint[4*nmax+56];
int v[nmax],opp;
void create(int pos,int st,int dr)
{
    if(st==dr)
    {
        aint[pos]=v[st];
        return;
    }
    else{
        int mij= (st+dr)/2;
        create(2*pos,st,mij);
        create(2*pos+1,mij+1,dr);
        aint[pos]=max(aint[2*pos],aint[2*pos+1]);
    }
}
void update(int pos,int st,int dr,int x)
{
    if(x < st || x > dr)
        return ;
    if(st==dr)
    {
        aint[pos]=v[x];
        return;
    }
    else{
        int mij= (st+dr)/2;
        if(x<=mij)
            update(2*pos,st,mij,x);
        else
            update(2*pos+1,mij+1,dr,x);
        aint[pos]=max(aint[2*pos],aint[2*pos+1]);
    }
}
void query(int pos,int st,int dr,int x,int y)
{
    if( x > dr || y < st)
        return;
    if(st==dr)
    {
        maxim=max(maxim,aint[pos]);
        return ;
    }
    else
    {
        int mij= (st+dr)/2;
        query(2*pos,st,mij,x,y);
        query(2*pos+1,mij+1,dr,x,y);
    }
}
int main()
{
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);
    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(false);

    cin >> n >> q;
    for(int i=1;i<=n;i++)
        cin >> v[i];
    create(1,1,n);
    for(int i=1;i<=q;i++)
    {
        cin >> opp;
        int a,b;
        cin >> a>> b;
        if(opp==1)
        {
            v[a]=b;
            update(1,1,n,a);
        }
        else
        {
            maxim=0;
            query(1,1,n,a,b);
            cout << maxim << '\n';
        }
    }


    return 0;
}
