#include <bits/stdc++.h>
#define nmax 100005
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n,m,v[nmax],aint[4*nmax],task,x,y;
void build(int node,int st,int dr)
{
    if(st==dr)
        aint[node]=v[st];
    else
    {
        int mid=(st+dr)/2;
        build(2*node,st,mid);
        build(2*node+1,mid+1,dr);
        aint[node]=max(aint[2*node],aint[2*node+1]);
    }
}
void update(int node,int st,int dr,int poz,int val)
{
    if(st==dr)
        aint[node]=val;
    else
    {
        int mid=(st+dr)/2;
        if(poz<=mid)
            update(2*node,st,mid,poz,val);
        else
            update(2*node+1,mid+1,dr,poz,val);
        aint[node]=max(aint[2*node],aint[2*node+1]);
    }
}
int query(int node,int st,int dr,int qst,int qdr)
{
    if(qst<=st && dr<=qdr)
        return aint[node];
    else
    {
        int mid=(st+dr)/2;
        if(qst<=mid)
            return query(2*node,st,mid,qst,qdr);
        if(mid<=qdr)
            return query(2*node+1,mid+1,dr,qst,qdr);
        return max(query(2*node,st,mid,qst,qdr),
                   query(2*node+1,mid+1,dr,qst,qdr));
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    build(1,1,n);
    while(m--)
    {
        fin>>task>>x>>y;
        if(task==0)
            fout<<query(1,1,n,x,y)<<'\n';
        else
            update(1,1,n,x,y);
    }
    return 0;
}
