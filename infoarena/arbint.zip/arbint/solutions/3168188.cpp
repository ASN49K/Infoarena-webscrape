#include <fstream>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>

#define ll long long
#define pb push_back
#define bg begin
#define en end
#define x first
#define y second

#define int ll

using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

const int NMAX = 1e5 + 5;
const double INF = 1e9 + 5;
const char nl = '\n';

int v[NMAX], tree[4 * NMAX], n, q;

void build(int node = 1, int l = 1, int r = n){
    if(l > r)
        return ;
    if(l == r){
        tree[node] = v[l];
        return ;
    }
    int mid = (l + r) / 2;
    build(2 * node, l, mid);
    build(2 * node + 1, mid + 1, r);
    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

int query(int ql, int qr, int node = 1, int l = 1, int r = n){
    if(l > r || r < ql || l > qr)
        return 0;
    if(l >= ql && r <= qr)
        return tree[node];
    int mid = (l + r) / 2;
        return max(query(ql, qr, node * 2, l, mid),
               query(ql, qr, node * 2 + 1, mid + 1, r));
}

void update(int pos, int value, int node = 1, int l = 1, int r = n){
    if(l == r){
        tree[node] = value;
        return ;
    }
    int mid = (l + r) / 2;
    if(pos <= mid)
        update(pos, value, 2 * node, l, mid);
    else
        update(pos, value, 2 * node + 1, mid + 1, r);
    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

signed main()
{
    in >> n >> q;
    for(int i = 1; i <= n; ++i)
        in >> v[i];
    build();
    while(q--){
        int op, x, y;
        in >> op >> x >> y;
        if(op == 0)
            out << query(x, y) << nl;
        else
            update(x, y);
    }
    return 0;
}
