#include<fstream>
std::ifstream fin("arbint.in");
std::ofstream fout("arbint.out");
int n, m;
int arbint[400001];
void update(int val, int index, int st, int dr, int pos)
{
    if(st==dr)
    {
        arbint[pos]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(index>mij)
        update(val, index, mij+1, dr, 2*pos+1);
    else
       update(val, index, st, mij, 2*pos);
    arbint[pos]=std::max(arbint[2*pos], arbint[2*pos+1]);
}

bool commonPart(int st, int dr, int start, int stop)
{
    if(st>=start && st<=stop)
        return true;
    if(dr>=start && dr<=stop)
        return true;
    if(start>=st && start<=dr)
        return true;
    if(stop>=st && stop<=dr)
        return true;
    return false;
}
void query(int start, int stop, int st, int dr, int pos, int &max)
{
    if(st>=start && dr<=stop)
    {
        max=std::max(arbint[pos], max);
        return;
    }
    int mij=(st+dr)/2;
    if(commonPart(st, mij, start, stop))
        query(start, stop, st, mij, 2*pos, max);
    if(commonPart(mij+1, dr, start, stop))
        query(start, stop, mij+1, dr, 2*pos+1, max);
}
void solve()
{
    fin>>n>>m;
    for(int index=1; index<=n; ++index)
    {
        int val;
        fin>>val;
        update(val, index, 1, n, 1);
    }
    for(int index=0; index<m; ++index)
    {
        int q;
        fin>>q;
        if(!q)
        {
            int a, b;
            fin>>a>>b;
            int max=-1;
            query(a, b, 1, n, 1, max);
            fout<<max<<'\n';
        }
        else
        {
            int i, val;
            fin>>i>>val;
            update(val, i, 1, n, 1);
        }
    }
}
int main()
{
    solve();
    fin.close();
    fout.close();
    return 0;
}


/*11 3
4 6 2 5 1 3 8 9 1 2 3




 void display()
{
    for(int index=1; index<=3*n; ++index)
        fout<<arbint[index]<<" ";
    fout<<'\n';
}
*/
