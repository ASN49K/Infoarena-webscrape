#include <bits/stdc++.h>

using namespace std;

class SegmentTree{
private:
    vector<int>tree;
    int n;
    
void build(const vector<int>&arr, int node, int left, int right){
    if(left == right){
        tree[node] = arr[left];
    } 
    else{
        int mid = (left + right) / 2;
        build(arr, 2 * node, left, mid);
        build(arr, 2 * node + 1, mid + 1, right);
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

void update(int node, int left, int right, int index, int value){
    if(left == right){
        tree[node] = value;
    }
    else{
        int mid = (left + right) / 2;
        if(index <= mid){
            update(2 * node, left, mid, index, value);
        }
        else{
            update(2 * node + 1, mid + 1, right, index, value);
        }
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

int query(int node, int left, int right, int L, int R){
    if(R < left || right < L){
        return INT_MIN;
    }
    if(L <= left && right <= R){
        return tree[node];
    }
    int mid = (left + right) / 2;
    int leftMax = query(2 * node, left, mid, L, R);
    int rightMax = query(2 * node + 1, mid + 1, right, L, R);
    return max(leftMax, rightMax);
}

public:
    SegmentTree(const vector<int>&arr){
        n = arr.size();
        tree.resize(4 * n);
        build(arr, 1, 0, n - 1);
    }
    
    void update(int idx, int value) {
        update(1, 0, n - 1, idx, value);
    }
    
    int query(int L, int R) {
        return query(1, 0, n - 1, L, R);
    }
};


int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int N, M, x, y, z;
    cin >> N >> M;
    vector<int>v(N);
    for(int i = 0; i < N;i++){
        cin >> v[i];
    }
    SegmentTree tree(v);
    
    for(int i = 0; i < M;i++){
        cin >> x >> y >> z;
        y --;
        z --;
        if(x == 0){
            cout<<tree.query(y, z)<<endl;
        }
        else{
            tree.update(y,z);
        }
    }

    return 0;
}