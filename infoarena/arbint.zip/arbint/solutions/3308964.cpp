#include <bits/stdc++.h>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int det(int a, int b, int st, int dr, int nod);
void update(int poz, int val, int st, int dr, int nod);

int arbore[4000002], n, m;

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fin>>n>>m;
    for(int i = 1; i <= n; ++i)
    {
        int nr;
        fin>>nr;
        update(i, nr, 1, n, 1);
    }

    for(int i = 1; i <= m; ++i)
    {
        int tip, a, b;
        fin>>tip>>a>>b;
        if(tip == 0)
            fout<<det(a, b, 1, n, 1)<<"\n";
        else
            update(a, b, 1, n, 1);

    }







    return 0;
}

void update(int poz, int val, int st, int dr, int nod)
{
    if(st == dr)
    {
        arbore[nod] = val;
        return;
    }
    int mijl = (st + dr) / 2;
    if(poz <= mijl)
    {
        update(poz, val, st, mijl, 2 * nod);
    }
    else
    {
        update(poz, val, mijl + 1, dr, 2 * nod + 1);
    }
    arbore[nod] = max(arbore[nod * 2], arbore[nod * 2 + 1]);
}

int det(int a, int b, int st, int dr, int nod)
{
    if(a <= st && dr <= b)
        return arbore[nod];

    int mijl = (st + dr) / 2, maxi = -1;
    if(mijl >= a)
        maxi = max(maxi, det(a, b, st, mijl, 2 * nod));
    if(mijl + 1 <= b)
        maxi = max(maxi, det(a, b, mijl + 1, dr, 2 * nod + 1));

    return maxi;
}



