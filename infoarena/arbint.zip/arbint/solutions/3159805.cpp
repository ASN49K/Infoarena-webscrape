#include <bits/stdc++.h>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
const int N=1<<18;
int aint[N],v[N];
int mini=-1;
void construire(int p,int st,int dr)
{
    if(st==dr)
    {
        aint[p]=v[st];
    }
    else
    {
        int mij=(dr+st)/2,fs=2*p,fd=2*p+1;
        construire(fs,st,mij);
        construire(fd,mij+1,dr);
        aint[p]=max(aint[fs],aint[fd]);
    }
}
void inlocuire(int p,int st,int dr,int a,int b)
{
    if(st==dr)
    {
        aint[p]=b;
    }
    else
    {
        int mij=(st+dr)/2,fs=2*p,fd=2*p+1;
        if(a<=mij)
            inlocuire(fs,st,mij,a,b);
        else
        {
            inlocuire(fd,mij+1,dr,a,b);
        }
        aint[p]=max(aint[fs],aint[fd]);
    }
}
int interogare(int p,int st,int dr,int a,int b)
{
    if(a<=st && dr<=b)
    {
        return aint[p];
    }
    else
    {
        int mij=(st+dr)/2,fd=2*p+1,fs=2*p;
        int rs=mini,rd=mini;
        if(a<=mij)
            rs=interogare(fs,st,mij,a,b);
        if(b>mij)
        {
            rd=interogare(fd,mij+1,dr,a,b);
        }
        return max(rs,rd);
    }

}
int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        fin>>v[i];
    construire(1,1,n);
    for(int i=1; i<=m; i++)
    {
        int tip,a,b;
        fin>>tip>>a>>b;
        if(tip==0)
        {
            fout<<interogare(1,1,n,a,b)<<'\n';
        }
        else
        {
            inlocuire(1,1,n,a,b);
        }
    }
}
