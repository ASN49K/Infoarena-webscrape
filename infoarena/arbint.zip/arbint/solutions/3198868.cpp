#include <iostream>
#include <fstream>

using namespace std;

int v[100001], aint[400001], n, m, max;

void build(int nod, int st, int dr)
{
    if(st == dr)
    {
        aint[nod] = v[st];
    }
    else
    {
        int mij = (st + dr) / 2;
        build(2 * nod, st, mij);
        build(2 * nod + 1, mij + 1, dr);
        aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
    }
}

void update(int nod, int st, int dr, int a, int b)
{
   if(st == dr)
   {
       aint[nod] = b;
   }
   else
   {
       int mij = (st + dr) / 2;
       if(a <= mij)
       {
           update(2 * nod, st, mij, a, b);
       }
       else
       {
           update(2 * nod + 1, mij + 1, dr, a, b);
       }
       aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
   }
}

void query(int nod, int st, int dr, int a, int b)
{
    if(a <= st && dr <= b)
    {
        if(aint[nod] > max)
        {
            max = aint[nod];
        }
    }
    else
    {
        int mij = (st + dr) / 2;
        if(a <= mij)
        {
            query(2 * nod, st, mij, a, b);
        }
        if(b > mij)
        {
            query(2 * nod + 1, mij + 1, dr, a, b);
        }
    }
}

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    int t, a, b;
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i];
    }
    build(1, 1, n);
    for(int i = 1; i <= m; i++)
    {
        cin >> t >> a >> b;
        if(t == 1)
        {
            update(1, 1, n, a, b);
        }
        else
        {
            max = 1e9;
            query(1, 1, n, a, b);
            cout << max << "\n";
        }
    }
    return 0;
}
