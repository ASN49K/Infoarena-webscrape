#include <fstream>
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
const int nmax = 1e5+1;
const int buc = 316;
int op , a , b , v[nmax] , bat[nmax] , n , m;
int main()
{
    cin >> n >> m;
    for(int i = 1 ; i <= n ; ++i)
    {
        cin >> v[i];
        bat[i/buc] = max(bat[i/buc],v[i]);
    }
    for(int i = 1 ; i <= m ; ++i)
    {
        cin >> op >> a >> b;
        if(!op)
        {
            int mx = -1e9;
            int ba = a/buc;
            int bb = b/buc;
            if(ba == bb)
            {
                for(int j = a ; j <= b ; ++j) mx = max(mx,v[j]);
                cout << mx << '\n';
                continue;
            }
            for(int j = ba + 1 ; j < bb ; ++j)
            {
                mx = max(mx,bat[j]);
            }
            if(a == ba*buc) mx = max(mx,bat[ba]);
            else
            {
                int up = (ba+1)*buc;
                for(int j = a ; j < up ; ++j)
                {
                    mx = max(mx,v[j]);
                }
            }
            if(b == n || b == (bb+1)*buc - 1) mx = max(mx,bat[bb]);
            else
            {
                int low = bb*buc;
                for(int j = b ; j >= low ; --j)
                {
                    mx = max(mx,v[j]);
                }
            }
            cout << mx << '\n';
        }
        else
        {
            int ba = a/buc;
            if(v[a] <= b || bat[ba] > v[a])
            {
                v[a] = b;
                bat[ba] = max(bat[ba],b);
            }
            else
            {
                int mx = -1e9;
                v[a] = b;
                int ub = min(n,(ba+1)*buc-1);
                for(int j = ba*buc ; j <= ub ; ++j) mx = max(mx,v[j]);
                bat[ba] = mx;
            }
        }
    }
	return 0;
}
