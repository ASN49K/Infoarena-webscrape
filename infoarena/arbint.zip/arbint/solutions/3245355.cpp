#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream input("arbint.in");
ofstream output("arbint.out");

struct Node
{
    int value = 0;
    int left;
    int right;
    Node *parent = nullptr;
    Node *child_1 = nullptr;
    Node *child_2 = nullptr;
};

void Construct(Node *curr, int N, vector<int> numbers)
{
    if(curr->left == curr->right){
        curr->value = numbers[curr->left];
        return;
    }
    int mid = (curr->left + curr->right)/2;

    curr->child_1 = new Node;
    curr->child_1->left = curr->left;
    curr->child_1->right = mid;
    curr->child_1->parent = curr;
    Construct(curr->child_1, N, numbers);

    curr->child_2 = new Node;
    curr->child_2->left = mid+1;
    curr->child_2->right = curr->right;
    curr->child_2->parent = curr;
    Construct(curr->child_2, N, numbers);

    curr->value = max(curr->child_1->value, curr->child_2->value);
    return;
}

int solution;

void Query(Node *curr, int N, int a, int b)
{
    if(a <= curr->left && b >= curr->right){
        solution = max(solution, curr->value);
        return;
    }
    int mid = (curr->left + curr->right)/2;
    if(a <= mid){
        Query(curr->child_1, N, a, b);
    }
    if(b > mid){
        Query(curr->child_2, N, a ,b);
    }
    return;
}

void Change(Node* root, int a, int b, int N, vector<int> numbers)
{
    Node *act = root;
    int mid;
    while(act->left != act->right){
        mid = (act->left + act->right)/2;
        if(a <= mid){
            act = act->child_1;
        }
        else{
            act = act->child_2;
        }
    }
    act->value = numbers[b];
    while(act != root){
        act = act->parent;
        act->value = max(act->child_1->value, act->child_2->value);
    }
    root->value = max(root->child_1->value, root->child_2->value);

}

int main()
{
    int N, M;
    input >> N >> M;
    vector<int> numbers(N);
    for(int i = 0; i < N; i++){
        input >> numbers[i];
    }
    Node *root = new Node;
    root->left = 0;
    root->right = N-1;

    Construct(root, N, numbers);

    for(int i = 0; i < M; i++){
        int k, a, b;
        input >> k >> a >> b;
        a--;
        b--;
        if(k == 0){
            solution = 0;
            Query(root, N, a, b);
            output << solution << endl;
        }
        else{
            Change(root, a, b, N, numbers);
            numbers[a] = numbers[b];
        }
    }

    return 0;
}
