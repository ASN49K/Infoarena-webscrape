#include <bits/stdc++.h>
#define MAXN 100000

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int v[MAXN + 1], aint[4 * MAXN];

void build(int nod, int st, int dr){
    int mij;
    if(st == dr){
        aint[nod] = v[st];
    }else{
        mij = (st + dr) / 2;
        build(2 * nod, st, mij);
        build(2 * nod + 1, mij + 1, dr);
        aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
    }
}
int query(int nod, int st, int dr, int a, int b){
    int mij;
    if(dr < a || st > b){
        return 0;
    }
    if(st >= a && dr <= b){
        return aint[nod];
    }
    mij = (st + dr) / 2;
    return max(query(2 * nod, st, mij, a, b), query(2 * nod + 1, mij + 1, dr, a, b));
}
void update(int nod, int st, int dr, int poz, int val){
    int mij;
    if(st == dr){
        aint[nod] = val;
    }else{
        mij = (st + dr) / 2;
        if(poz <= mij){
            update(2 * nod, st, mij, poz, val);
        }else{
            update(2 * nod + 1, mij + 1, dr, poz, val);
        }
        aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
    }
}

int main()
{
    int n, m, i, tip, a, b, j;

    fin >> n >> m;
    for(i = 1; i <= n; i++){
        fin >> v[i];
    }
    build(1, 1, n);
    for(i = 1; i <= m; i++){
        fin >> tip >> a >> b;
        if(tip == 0){
            fout << query(1, 1, n, a, b) << "\n";
        }else{
            update(1, 1, n, a, b);
        }
    }
    return 0;
}
