#include <bits/stdc++.h>

using namespace std;
long long putere(long long n)
{
    long long p=1;
    while(p<n)
    {
        p*=2;
    }
    return p;
}
void set1(long long i, long long val, vector<long long>&tree)
{
    long long pos=tree.size()/2+i;
    tree[pos]=val;
    pos=pos/2;
    while(pos>0)
    {
        tree[pos]=max(tree[2*pos],tree[2*pos+1]);
        pos=pos/2;
    }
}
long long query(long long l,long long r,vector<long long>&tree,long long pos,long long sl,long long sr)
{
    if(l==sl&&r==sr)
    {
        return tree[pos];
    }
    long long mid=(sl+sr)/2;
    if(r<=mid)
    {
        return query(l,r,tree,2*pos,sl,mid);
    }
    if(l>mid)
    {
        return query(l,r,tree,2*pos+1,mid+1,sr);
    }
    long long r1=query(l,mid,tree,2*pos,sl,mid);
    long long r2=query(mid+1,r,tree,2*pos+1,mid+1,sr);
    return max(r1,r2);
}
int main()
{
    ifstream cin{"arbint.in"};
    ofstream cout{"arbint.out"};
    long long m, n;
    cin>>n>>m;
    vector<long long>tree(putere(n)*2, -1);
    for(long long i=0; i<n; i++)
    {
        long long val;
        cin>>val;
        set1(i,val,tree);
    }
    long long k,a,b;
    for(long long i=0; i<m; i++)
    {
        cin>>k>>a>>b;
        if(k==0)
        {
            long long res=query(--a,--b,tree,1,0,(tree.size()-1)/2);
            cout<<res<<endl;
        }
        else if(k==1)
        {
            set1(--a,b,tree);
        }
    }
    return 0;
}
