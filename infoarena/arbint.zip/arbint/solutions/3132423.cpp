#include <iostream>
#include <fstream>
#include <vector>

class ArboreSegment {
private:
    std::vector<int> arbore;
    int dimensiune;

    int getMaxim(int a, int b) {
        return std::max(a, b);
    }

    void actualizare(int nod, int stanga, int dreapta, int index, int valoare) {
        if (stanga == dreapta) {
            arbore[nod] = valoare;
        } else {
            int mijloc = (stanga + dreapta) / 2;
            if (index <= mijloc) {
                actualizare(2 * nod, stanga, mijloc, index, valoare);
            } else {
                actualizare(2 * nod + 1, mijloc + 1, dreapta, index, valoare);
            }
            arbore[nod] = getMaxim(arbore[2 * nod], arbore[2 * nod + 1]);
        }
    }

    int interogare(int nod, int stanga, int dreapta, int stanga_cautare, int dreapta_cautare) {
        if (stanga_cautare <= stanga && dreapta <= dreapta_cautare) {
            return arbore[nod];
        } else if (dreapta < stanga_cautare || stanga > dreapta_cautare) {
            return 0;
        } else {
            int mijloc = (stanga + dreapta) / 2;
            int rezultat_stanga = interogare(2 * nod, stanga, mijloc, stanga_cautare, dreapta_cautare);
            int rezultat_dreapta = interogare(2 * nod + 1, mijloc + 1, dreapta, stanga_cautare, dreapta_cautare);
            return getMaxim(rezultat_stanga, rezultat_dreapta);
        }
    }

public:
    ArboreSegment(int n) {
        dimensiune = n;
        arbore.resize(4 * dimensiune);
    }

    void actualizare(int index, int valoare) {
        actualizare(1, 1, dimensiune, index, valoare);
    }

    int interogare(int stanga, int dreapta) {
        return interogare(1, 1, dimensiune, stanga, dreapta);
    }
};

class Meniu {
    int n, m, x, t, p, q;
    ArboreSegment *arboreSegment;
public:
    void run() {
        std::ifstream fin("arbint.in");
        std::ofstream fout("arbint.out");

        fin >> n >> m;
        arboreSegment = new ArboreSegment(n);

        for (int i = 1; i <= n; i++) {
            fin >> x;
            arboreSegment->actualizare(i, x);
        }

        for (int i = 1; i <= m; i++) {
            fin >> t >> p >> q;
            if (t) {
                arboreSegment->actualizare(p, q);
            } else {
                fout << arboreSegment->interogare(p, q) << '\n';
            }
        }
    }

    ~Meniu() {
        delete arboreSegment;
    };
};

int main() {
    Meniu meniu;
    meniu.run();
    return 0;
}
