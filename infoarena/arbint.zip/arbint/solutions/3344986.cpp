#include <fstream>


using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int a[400001];
int n,m;

void build(int nod, int st, int dr)
{
    if(st==dr)
        fin>>a[nod];
    else
    {
        int mij=(st+dr)/2;
        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);
        a[nod]=max(a[2*nod],a[2*nod+1]);
    }

}

void update(int nod, int st, int dr, int pos, int val)
{
    if(st==dr)
        a[nod]=val;
    else
    {
        int mij=(st+dr)/2;
        if(pos<=mij)
            update(2*nod,st,mij,pos,val);
        else
            update(2*nod+1,mij+1,dr,pos,val);
        a[nod]=max(a[2*nod],a[2*nod+1]);
    }

}

int query(int nod, int st, int dr,int l,int r)
{
    if(l<=st&&dr<=r)
        return a[nod];
    else
    {
        int mij=(st+dr)/2;
        int maxim=0;
        if(l<=mij)
            maxim=max(maxim, query(2*nod,st,mij,l,r));
        if(mij<r)
            maxim=max(maxim,query(2*nod+1,mij+1,dr,l,r));
        return maxim;

    }

}

int main()
{
    bool op;
    int x,y;
    fin>>n>>m;
    build(1,1,n);
    for(int i=1;i<=m;i++)
    {
        fin>>op>>x>>y;
        if(!op)
        {
            int rez=query(1,1,n,x,y);
            fout<<rez<<'\n';
        }

        else
            update(1,1,n,x,y);
    }
    return 0;

}
