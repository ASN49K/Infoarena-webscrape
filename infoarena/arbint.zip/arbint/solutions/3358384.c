#include <stdio.h>
#define MAX 100005
int A[MAX];
int arbore[4 * MAX];
int maxim(int a, int b)
{
    if(a > b)
        return a;
    return b;
}

void initial(int nod, int st, int dr)
{
    if (st == dr)
    {
        arbore[nod] = A[st];
        return;
    }
    int mij = st + (dr - st) / 2;
    int st1 = 2 * nod;
    int dr1 = 2 * nod + 1;
    initial(st1, st, mij);
    initial(dr, mij + 1, dr);
    arbore[nod] = maxim(arbore[st1], arbore[dr1]);
}

void schimbare(int nod, int st, int dr, int pos, int val)
{
    if (st == dr)
    {
        arbore[nod] = val;
        return;
    }
    int mij = st + (dr - st) / 2;
    int st1 = 2 * nod;
    int dr1 = 2 * nod + 1;
    if (pos <= mij)
        schimbare(st1, st, mij, pos, val);
    else
        schimbare(dr1, mij + 1, dr, pos, val);
    arbore[nod] = maxim(arbore[st1], arbore[dr1]);
}

int q(int nod, int st, int dr, int q_st, int q_dr)
{
    if (q_st <= st && dr <= q_dr)
        return arbore[nod];
    if (q_dr < st || dr < q_st)
        return -1;
    int mij = st + (dr - st) / 2;
    int st1 = 2 * nod;
    int dr1 = 2 * nod + 1;
    int maxim_st = q(st1, st, mij, q_st, q_dr);
    int maxim_dr = q(dr1, mij + 1, dr, q_st, q_dr);
    return maxim(maxim_st, maxim_dr);
}

int main(void)
{
    int n, m;
    FILE *in = fopen("arbint.in", "r");
    FILE *out = fopen("arbint.out", "w");
    fscanf(in, "%d %d", &n, &m);
    for(int i = 1; i <= n; i++)
        fscanf(in, "%d", &A[i]);
    initial(1, 1, n);
    for(int i = 0; i < m; i++)
    {
        int t, a, b;
        fscanf(in, "%d %d %d", &t, &a, &b);
        if(t == 0)
        {
            int maxi = q(1, 1, n, a, b);
            fprintf(out, "%d\n", maxi);
        }
        else
            schimbare(1, 1, n, a, b);
    }
    return 0;
}