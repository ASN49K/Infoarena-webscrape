#include <fstream>

using namespace std;

const int Nmax = 100005;

int n, m;
int v[Nmax], aint[4 * Nmax];

void build(int nod, int st, int dr){
    if(st == dr){
        aint[nod] = v[st];
        return;
    }

    int mid = (st + dr) / 2;

    build(2 * nod, st, mid);
    build(2 * nod + 1, mid + 1, dr);

    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

void update(int nod, int st, int dr, int poz, int val){
    int mid;

    if(st == poz && dr == poz){
        aint[nod] = val;
        return;
    }

    mid = (st + dr) / 2;

    if(poz <= mid){
        update(2 * nod, st, mid, poz, val);
    }
    else{
        update(2 * nod + 1, mid + 1, dr, poz, val);
    }

    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

int query(int nod, int st, int dr, int a, int b){
    if(st == a && dr == b){
        return aint[nod];
    }

    int mid;

    mid = (st + dr) / 2;

    if(b <= mid){
        return query(2 * nod, st, mid, a, b);
    }
    else if(mid < a){
        return query(2 * nod + 1, mid + 1, dr, a, b);
    }
    else{
        return max(query(2 * nod, st, mid, a, mid), query(2 * nod + 1, mid + 1, dr, mid + 1, b));
    }
}

int main(){
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");

    int a, b, poz, val;
    bool type;

    fin >> n >> m;

    for(int i = 1; i <= n; i++){
        fin >> v[i];
    }

    build(1, 1, n);

    for(int i = 1; i <= m; i++){
        fin >> type;

        if(type){
            fin >> poz >> val;
            update(1, 1, n, poz, val);
        }
        else{
            fin >> a >> b;
            fout << query(1, 1, n, a, b) << '\n';
        }
    }
    return 0;
}
