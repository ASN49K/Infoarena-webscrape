#include <fstream>
#include <algorithm>
using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int tree[400005],a[100005];

void calc(int nod){
    tree[nod] = max(tree[nod*2+1],tree[nod*2+2]);
}

void constr(int nod,int l,int r){
    if(l==r) {
        tree[nod]=a[r];
        return;
    }

    int mid = (l+r)/2;
    constr(nod*2+1,l,mid);
    constr(nod*2+2,mid+1,r);
    calc(nod);
}

void upd(int nod,int l,int r,int pos,int val){

    if(l==r) {
        tree[nod]=val;
        return;
    }

    int mij = (l+r)/2;
    if(pos<=mij)
        upd(nod*2+1,l,mij,pos,val);
    else
        upd(nod*2+2,mij+1,r,pos,val);

    calc(nod);
}

int afis(int nod,int l,int r,int a,int b){

    if(a <= l && r <= b) {

        return tree[nod];
    }
    else {
        int maxim = 0,mij = (l+r)/2;

        if(a<=mij)
            maxim = max(maxim,afis(nod*2+1,l,mij,a,b));
        if(b>=mij+1)
            maxim = max(maxim,afis(nod*2+2,mij+1,r,a,b));

        return maxim;
    }
}

int main(){
    int n,q;
    cin>>n>>q;

    for(int i=1;i<=n;i++)
    cin>>a[i];

    constr(0,1,n);

    for(int i=1;i<=q;i++){
        int c,a,b;
        cin>>c>>a>>b;
        if(c==0)
            cout<<afis(0,1,n,a,b)<<endl;
        else
            upd(0,1,n,a,b);
    }
}
