#include <stdio.h>
#include <stdlib.h>

#define MAX(a, b) ((a) > (b) ? a : b)

typedef struct nod_t
{
    long long limleft, limright, val;
    struct nod_t *right, *left;
} nod;

nod *createNod(long long *vec, long long start, long long stop)
{
    if (start == stop)
    {
        nod *ret = (nod *)malloc(sizeof(nod));
        ret->limleft = start;
        ret->limright = stop;
        ret->right = NULL;
        ret->left = NULL;
        ret->val = vec[start];
        return ret;
    }

    long long mid = start + (stop - start) / 2;
    nod *ret = (nod *)malloc(sizeof(nod));
    ret->limleft = start;
    ret->limright = stop;
    ret->left = createNod(vec, start, mid);
    ret->right = createNod(vec, mid + 1, stop);
    ret->val = ret->left->val * (ret->left->val > ret->right->val) + ret->right->val * (ret->right->val > ret->left->val);
    return ret;
}

void updateNod(long long pos, long long val, nod *arb)
{
    if (arb->limleft == arb->limright)
    {
        arb->val = val;
        return;
    }

    long long mid = (arb->limleft + arb->limright) / 2;
    if (pos <= mid)
    {
        updateNod(pos, val, arb->left);
    }
    else
    {
        updateNod(pos, val, arb->right);
    }
    arb->val = arb->left->val * (arb->left->val > arb->right->val) + arb->right->val * (arb->right->val > arb->left->val);
}

long long intvMax(nod *arb, long long strInt, long long endInt)
{
    if (arb->limright == arb->limleft)
    {
        return arb->val;
    }
    long long strB = (strInt < arb->limleft ? arb->limleft : strInt);
    long long endB = (endInt > arb->limright ? arb->limright : endInt);
    long long max1 = intvMax(arb->left, strB, endB);
    long long max2 = intvMax(arb->right, strB, endB);

    return MAX(max1, max2);
}

int main()
{
    long long n = 0, m = 0, c = 0;
    FILE *file = fopen("arbint.in", "rb");
    FILE *fout = fopen("arbint.out", "wb");

    fscanf(file, "%lld", &n);
    fscanf(file, "%lld", &m);

    long long *vec = malloc(n * sizeof(long long));

    while (n)
    {
        fscanf(file, "%lld", &vec[c]);
        ++c;
        n -= 1;
    }

    nod *arb = createNod(vec, 0, c - 1);
    long long opt, par1, par2;
    while (m)
    {
        fscanf(file, "%lld", &opt);
        fscanf(file, "%lld", &par1);
        fscanf(file, "%lld", &par2);
        if (opt == 0)
        {
            updateNod(par1 - 1, par2, arb);
        }
        else
        {
            fprintf(fout, "%lld\n", intvMax(arb, par1 - 1, par2 - 1));
        }
        m--;
    }
    fclose(fout);
    fclose(file);
    return 0;
}