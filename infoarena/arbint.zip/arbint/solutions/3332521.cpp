#include <bits/stdc++.h>
using namespace std;

class segTree{
private:
    vector<int> tree;
    int zp,n;
public:
    void build(vector<int> v){
        n=v.size();
        zp=1<<(int)ceil(log2(n));
        tree.resize(2*zp,0);
        for(int i=0;i<n;i++) tree[zp+i]=v[i];
        for(int i=zp-1;i>0;i--) tree[i]=max(tree[2*i],tree[2*i+1]);
    }
    int query(int l,int r){
        l+=zp;
        r+=zp;
        int ans=0;
        while(l<=r){
            if(l%2==1) ans=max(ans,tree[l++]);
            if(r%2==0) ans=max(ans,tree[r--]);
            l/=2;
            r/=2;
        }
        return ans;
    }
    void update(int idx,int val){
        idx+=zp;
        tree[idx]=val;
        idx/=2;
        while(idx>0){
            tree[idx]=max(tree[2*idx],tree[2*idx+1]);
            idx/=2;
        }
    }
};

int main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);
    int N,Q;cin>>N>>Q;
    vector<int> v(N);
    for(int i=0;i<N;i++) cin>>v[i];
    segTree st;
    st.build(v);
    for(int i=0;i<Q;i++){
        int t;cin>>t;
        if(t==1){
            int a,b;cin>>a>>b;
            st.update(a-1,b);
        }
        else{
            int a,b;cin>>a>>b;
            cout<<st.query(a-1,b-1)<<"\n";
        }
    }
}