#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, cer, x, y;
int arb[400005], v[100005];

/*void build(int nod, int st, int dr){
    if(st==dr){
        arb[st]=nod;
        return;
    }
    int mij=(st+dr)/2;
    build(2*nod, st, mij);
    build(2*nod+1, mij+1, dr);
    arb[nod]=max(arb[2*nod], arb[2*nod+1]);
}*/

void update(int nod, int val, int poz, int st, int dr){
    //cout<<nod<<" "<<poz<<" "<<st<<" "<<dr<<"\n";
    if(st==dr){
        arb[nod]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(poz<=mij)
        update(2*nod, val, poz, st, mij);
    else
        update(2*nod+1, val, poz, mij+1, dr);

    arb[nod]=max(arb[2*nod], arb[2*nod+1]);
}

int query(int nod, int x, int y, int st, int dr){
    //cout<<nod<<" "<<x<<" "<<y<<" "<<st<<" "<<dr<<"\n";
    if(x==st && y==dr)
        return arb[nod];

    int mij=(st+dr)/2;
    if(x>mij)
        return query(2*nod+1, x, y, mij+1, dr);

    else if(y<=mij)
        return query(2*nod, x, y, st, mij);

    else
        return max(query(2*nod+1, mij+1, y, mij+1, dr),
                   query(2*nod, x, mij, st, mij));
}


int main(){
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        update(1, v[i], i, 1, n);
    }
    for(int i=1;i<=m;i++){
        fin>>cer>>x>>y;
        ///      poz val
        if(cer==1)
            update(1, y, x, 1, n);

        else
            fout<<query(1, x, y, 1 ,n)<<'\n';
    }
    return 0;
}
