#include <bits/stdc++.h>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int n,p=1,q,t,a,b,getMax(int,int,int);
void upd();
vector<int> A;
int main()
{
    f>>n>>q;
    while(p<n)p*=2;
    A=vector<int>(2*p,0);
    for(int i=1;i<=n;i++)
        f>>A[p+i-1];
    for(int i=p-1;i>=1;i--)
        A[i]=max(A[2*i],A[2*i+1]);
    for(;q;q--)
    {
        f>>t>>a>>b;
        if(t==0)
            g<<getMax(1,1,p)<<'\n';
        else upd();
    }
    return 0;
}
int getMax(int i,int x,int y)
{
    if(a<=x&&y<=b)
        return A[i];

    if(a>y||x>b)
        return 0;

    int z=(x+y)/2;
    return max ( getMax(2*i,x,z) , getMax(2*i+1,z+1,y));
}
void upd()
{
    a=a+p-1;
    A[a]=b;
    a/=2;
    while(a>=1)
    {
        A[a]=max(A[2*a],A[2*a+1]);
        a/=2;
    }
}
