#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, arb[400005], vmax;

void update(int pos, int val, int nod, int st, int dr) {
    if (st==dr) {
        arb[nod]=val;
        return;
    }
    int mij=(st+dr)/2;
    if (pos<=mij)
        update(pos, val, 2*nod, st, mij);
    else
        update(pos, val, 2*nod+1, mij+1, dr);
    arb[nod]=max(arb[2*nod], arb[2*nod+1]);
}

void query(int start, int final, int nod, int st, int dr) {
    if (st>=start && dr<=final) {
        if (arb[nod]>vmax)
            vmax=arb[nod];
        return;
    }
    int mij=(st+dr)/2;
    if (start<=mij)
        query(start, final, 2*nod, st, mij);
    if (final>mij)
        query(start, final, 2*nod+1, mij+1, dr);
}

void citire() {
    fin>>n>>m;
    int x;
    for (int i=1; i<=n; i++) {
        fin>>x;
        update(i, x, 1, 1, n);
    }
}

void operatii() {
    int op, a, b;
    for (int i=1; i<=m; i++) {
        fin>>op>>a>>b;
        if (!op) {
            vmax=-1;
            query(a, b, 1, 1, n);
            fout<<vmax<<"\n";
        } else
            update(a, b, 1, 1, n);
    }
}

int main() {
    citire();
    operatii();
    return 0;
}