#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100000;
int aint[4*NMAX + 5], v[NMAX + 5];
int n, m;

ifstream f ("arbint.in");
ofstream g ("arbint.out");

void build(int nod, int l, int r)
{
    if(l != r)
    {
        int m=(l + r)/2;
        build(2*nod, l, m);
        build(2*nod + 1, m + 1, r);
        aint[nod] = max(aint[2*nod], aint[2*nod + 1]);
    }
    else
    {
        ///l = r
        aint[nod] = v[l];
    }
}

void update(int nod, int l, int r, int poz, int elem)
{
    int m = (l + r)/2;
    if(l != r)
    {
        if(m >= poz) ///ma duc in stanga
        {
            update(2*nod, l, m, poz, elem);
            aint[nod] = max(aint[2*nod], aint[2*nod + 1]);
        }
        else
        {
            ///poz >= m + 1, deci ma duc in dreapta
            update(2*nod + 1, m + 1, r, poz, elem);
            aint[nod] = max(aint[2*nod], aint[2*nod + 1]);
        }
    }
    else
    {
        ///l = r
        aint[nod] = elem;
    }
}

int q(int nod, int l, int r, int ql, int qr)
{
    if(l > qr || r < ql || r < l)
    {
        return -1;
    }
    else
    {
        if( ql <= l && ql <= r && qr >= l && qr >= r)
        {
            ///int [l, r] este inclus in [ql, qr]
            return aint[nod];
        }
        else
        {
            int m = (l + r)/2;
            return max(q(2*nod, l, m, ql, qr), q(2*nod + 1, m + 1, r, ql, qr));
        }
    }
}

int main()
{
    int i, a, b, k;
    f >> n >> m;
    for(i = 1; i<= n; ++i)
    {
        f >> v[i];
    }
    build(1, 1, n);
    for(i = 1; i <= m; ++i)
    {
        f >> k >> a >> b;
        if(k == 0)
        {
            g << q(1, 1, n, a, b) << "\n";
        }
        else
        {
            ///k = 1
            update(1, 1, n, a, b);
        }
    }
    return 0;
}
