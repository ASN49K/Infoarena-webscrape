#include <bits/stdc++.h>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
const int NMAX=100005;
int n,m,op,pos,val,start,finish,ans,v[NMAX],MaxTree[4*NMAX];
void build(int node,int left,int right)
{
    if(left==right)///leaf
    {
        MaxTree[node]=v[left];
        return;
    }
    int middle=(left+right)/2;
    build(2*node,left,middle);///left son
    build(2*node+1,middle+1,right);///right son
    MaxTree[node]=max(MaxTree[2*node],MaxTree[2*node+1]);///build the current node based on his sons
}
void update(int node,int left,int right)
{
    if(left==right)///leaf
    {
        MaxTree[node]=val;
        return;
    }
    int middle=(left+right)/2;
    if(pos<=middle)
        update(2*node,left,middle);///update on the left son
    else///pos>middle
        update(2*node+1,middle+1,right);///update on the right son
    MaxTree[node]=max(MaxTree[2*node],MaxTree[2*node+1]);///update the current node based on his sons
}
void query(int node,int left,int right)
{
    if(start<=left && right<=finish)///verify if the current interval is inside the one from the query
    {
        ans=max(ans,MaxTree[node]);
        return;
    }
    int middle=(left+right)/2;
    if(start<=middle)
        query(2*node,left,middle);///query on the left son
    if(middle<finish)
        query(2*node+1,middle+1,right);///query on the right son
}
int main()
{
    f>>n>>m;
    for(int i=1; i<=n; i++)
        f>>v[i];
    build(1,1,n);
    for(int i=1; i<=m; i++)
    {
        f>>op;
        if(op==1)
        {
            f>>pos>>val;
            update(1,1,n);
        }
        else
        {
            f>>start>>finish;
            ans=0;
            query(1,1,n);
            g<<ans<<'\n';
        }
    }
    return 0;
}
