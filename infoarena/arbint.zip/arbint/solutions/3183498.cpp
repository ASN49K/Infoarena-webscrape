#include <algorithm>
#include <fstream>
using namespace std;

constexpr unsigned maxn = 100000;

namespace {
template <unsigned niv>
unsigned buf[niv];

template <unsigned niv = maxn>
void build() {
    if constexpr (niv > 1) {
#pragma GCC unroll 128
        for (unsigned i = 0; i < niv; i += 2)
            buf<niv / 2>[i / 2] = max(buf<niv>[i], buf<niv>[i + 1]);
        build<niv / 2>();
    }
}

template <unsigned niv>
void rebuild(unsigned i) {
    if constexpr (niv > 1) {
        buf<niv / 2>[i / 2] = max(buf<niv>[i], buf<niv>[i ^ 1]);
        rebuild<niv / 2>(i / 2);
    }
}

void update(unsigned i, unsigned x) {
    buf<maxn>[i] = x;
    rebuild<maxn>(i);
}

template <unsigned niv = maxn>
unsigned query(unsigned st, unsigned dr, unsigned r = 0) {
    if constexpr (niv >= 1) {
        if (st == dr) return r;

        if (st % 2) r = max(r, buf<niv>[st++]);
        if (dr % 2) r = max(r, buf<niv>[--dr]);
        return query<niv / 2>(st / 2, dr / 2, r);
    }
    return 0;
}

ifstream f("arbint.in");
ofstream g("arbint.out");

char rdbuf[maxn] = {}, *ip = rdbuf;
void adv() {
    if (++ip == rdbuf + maxn) f.read(ip = rdbuf, maxn);
}

unsigned get_int() {
    unsigned x = 0;
    while (*ip < '0') adv();
    for (; *ip >= '0'; adv()) x = 10 * x + *ip - '0';
    return x;
}

char wrbuf[maxn + 100], *op = wrbuf;
void write_int(int x) {
    if (x == 0) {
        *op++ = '0';
        *op++ = '\n';
    } else {
        char *p = op;
        while (x) *p++ = x % 10 + '0', x /= 10;
        reverse(op, p);
        *p++ = '\n';
        op = p;

        if (op >= wrbuf + maxn) {
            g.write(wrbuf, op - wrbuf);
            op = wrbuf;
        }
    }
}
};  // namespace

int main() {
    f.read(rdbuf, maxn);

    unsigned n = get_int(), q = get_int();

    for (unsigned i = 0; i < n; ++i) buf<maxn>[i] = get_int();

    build();

    for (unsigned t, a, b; q--;) {
        t = get_int(), a = get_int(), b = get_int();
        if (t == 1)
            update(a - 1, b);
        else
            write_int(query(a - 1, b));
    }

    g.write(wrbuf, op - wrbuf);
}
