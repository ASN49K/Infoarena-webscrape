#include <iostream>
#include <iomanip>
#include <fstream>
#include <queue>
#define piii pair<int,pair<int,int>>
#define mp make_pair
using namespace std;

ifstream fin("umbra.in");
ofstream fout("umbra.out");

priority_queue <piii> pq;
long long int n,m;
int k=1;

struct arbore
{
    int st,dr;
    int tata;
    int fst,fdr;
    int val=0;
} a[800005];

void del(int l, int r,int st, int dr, int x)
{
    queue <pair<int,pair<int,piii>>> Q;
    Q.push(mp(l,mp(r,mp(st,mp(dr,x)))));
    while(!Q.empty())
    {
        l=Q.front().first;
        r=Q.front().second.first;
        st=Q.front().second.second.first;
        dr=Q.front().second.second.second.first;
        x=Q.front().second.second.second.second;
        Q.pop();
        int mij=(st+dr)/2;
        if(r<st || l>dr)
            continue;
        if(l<=st && dr<=r)
        {
            a[x].val--;
            continue;
        }
        if(a[x].fst != 0) Q.push(mp(l,mp(r,mp(st,mp(mij,a[x].fst)))));
        if(a[x].fdr != 0) Q.push(mp(l,mp(r,mp(mij+1,mp(dr,a[x].fdr)))));
    }

}
void update(int l, int r,int st, int dr, int x)
{
    queue <pair<int,pair<int,piii>>> Q;
    Q.push(mp(l,mp(r,mp(st,mp(dr,x)))));
    while(!Q.empty())
    {
        l=Q.front().first;
        r=Q.front().second.first;
        st=Q.front().second.second.first;
        dr=Q.front().second.second.second.first;
        x=Q.front().second.second.second.second;
        Q.pop();
        int mij=(st+dr)/2;
        if(r<st || l>dr)
            continue;
        if(l<=st && dr<=r)
        {
            a[x].val++;
            continue;
        }
        if(a[x].fst != 0) Q.push(mp(l,mp(r,mp(st,mp(mij,a[x].fst)))));
        if(a[x].fdr != 0) Q.push(mp(l,mp(r,mp(mij+1,mp(dr,a[x].fdr)))));
    }
}
bool query(int p,int st, int dr,int x)
{
    queue <pair<int,piii>> Q;
    Q.push(mp(p,mp(st,mp(dr,x))));
    while(!Q.empty())
    {
        p=Q.front().first;
        st=Q.front().second.first;
        dr=Q.front().second.second.first;
        x=Q.front().second.second.second;
        Q.pop();
        if(st==dr)
        {
            return a[x].val>0;
        }
        int mij=(st+dr)/2;
        if(p <= mij && a[x].fst != 0)
            Q.push(mp(p, mp(st, mp(mij, a[x].fst))));
        else if(p > mij && a[x].fdr != 0)
            Q.push(mp(p, mp(mij+1, mp(dr, a[x].fdr))));
    }
    return 0;

}
void init(int st, int dr,int x)
{
    int mij=(st+dr)/2;
    a[x].val=0;
    a[x].st=st;
    a[x].dr=dr;
    if(st==dr)
    {
        a[x].fst=0;
        a[x].fdr=0;
        return;
    }
    a[x].fdr=x*2+1;
    a[x].fst=x*2;
    init(st,mij,a[x].fst);
    init(mij+1,dr,a[x].fdr);


}
int main()
{
    fin>>n>>m;
    init(1,n,1);
    for(int i=1; i<=m; i++)
    {
        int c;
        fin>>c;
        if(c==1)
        {
            int h,p;
            fin>>h>>p;
            pq.push(mp(h,mp(i,p)));
            int dist=p+h-1;
            if(dist>n)
                dist=n;
            update(p,dist,1,n,1);
        }
        if(c==2)
        {
            int h,p;
            h=pq.top().first;
            p=pq.top().second.second;
            pq.pop();
            int dist=p+h-1;
            if(dist>n)
                dist=n;
            del(p,dist,1,n,1);
        }
        if(c==3)
        {
            int p;
            fin>>p;
            if(query(p,1,n,1))
                fout<<"DA"<<"\n";
            else
                fout<<"NU"<<"\n";
        }
    }
    return 0;
}
