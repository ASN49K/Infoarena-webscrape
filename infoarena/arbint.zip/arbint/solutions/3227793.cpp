#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int arb[500005];
int x, a, b, n, m;
int maxim;
void update(int poz, int val, int nod, int left, int right){
    if (left==right){
        arb[nod]=val;
        return;
    }
    int mij=(left+right)/2;
    if (poz<=mij){
        update(poz,val,2*nod,left,mij);
    }
    else{
        update(poz,val,2*nod+1,mij+1,right);
    }
    arb[nod]=max(arb[2*nod],arb[2*nod+1]);
}
int query(int qleft, int qright, int nod, int left, int right){
    if (qleft<=left && qright>=right){
        return arb[nod];
    }
    int mij=(left+right)/2;
    if (qleft<=mij){
        maxim=max(maxim,query(qleft,qright,nod*2,left,mij));
    }
    if (qleft>mij){
        maxim=max(maxim,query(qleft,qright,nod*2+1,mij+1,right));
    }
    return maxim;
}
int main()
{

    fin >> n >> m;
    for (int i=1; i<=n; ++i){
        fin >> x;
        update(i,x,1,1,n);
    }
    for (int i=1; i<=m; ++i){
        fin >> x >> a >> b;
        if (x==0){
            maxim=-1;
            fout << query(a,b,1,1,n) << '\n';
        }
        else if (x==1){
            update(a,b,1,1,n);
        }
    }
    return 0;
}
