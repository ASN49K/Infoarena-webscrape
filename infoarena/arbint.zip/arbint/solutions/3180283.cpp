#include <stdio.h>
#include <stdlib.h>

unsigned int Maximum(unsigned int a,unsigned int b){
    return (a<b) ? b:a;
}
void BuildSegTree(unsigned int *segarr,unsigned int *arr,unsigned int low,unsigned int high,unsigned int currnode){

    if(low==high) {
        segarr[currnode] = arr[low];
        return;
    }

    if(low<high){
        unsigned int mid=low+(high-low)/2;
        BuildSegTree(segarr,arr,low,mid,(currnode<<1)+1);
        BuildSegTree(segarr,arr,mid+1,high,(currnode<<1)+2);
        segarr[currnode]= Maximum(segarr[(currnode<<1)+1],segarr[(currnode<<1)+2]);
    }
}
unsigned int Query(unsigned int *segarr,unsigned int low,unsigned int high,unsigned int a,unsigned int b,unsigned int currnode){

      if(a<=low && high<=b)
          return segarr[currnode];

      if(low<high){
          unsigned int mid=low+(high-low)/2;
          if(a<=mid && mid<b)
              return Maximum(Query(segarr,low,mid,a,b,(currnode<<1)+1), Query(segarr,mid+1,high,a,b,(currnode<<1)+2));
          if(a<=mid)
              return Query(segarr,low,mid,a,b,(currnode<<1)+1);

          if(mid<b)
              return Query(segarr,mid+1,high,a,b,(currnode<<1)+2);
      }
}
void Update(unsigned int *segarr,unsigned int *arr,unsigned int low,unsigned int high,unsigned int a,unsigned int b,unsigned int currnode){

    if(low==high){
        arr[a]=b;
        segarr[currnode]=b;
        return;
    }

    if(low<high){
        unsigned int mid=low+(high-low)/2;
        if(a<=mid) Update(segarr,arr,low,mid,a,b,(currnode<<1)+1);
        else if(mid<a) Update(segarr,arr,mid+1,high,a,b,(currnode<<1)+2);
        segarr[currnode]=Maximum(segarr[(currnode<<1)+1],segarr[(currnode<<1)+2]);
    }
}
int main() {
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);

    unsigned int M,N,op,a,b;
    scanf("%u",&N);
    scanf("%u",&M);
    unsigned int *segarr=(unsigned int*) malloc(sizeof(unsigned int)*((N<<1)-1));
    unsigned int*arr=(unsigned int*) malloc(sizeof(unsigned int)*N);

    for(unsigned int i=0;i<N;i++)
        scanf("%u",&arr[i]);

    BuildSegTree(segarr,arr,0,N-1,0);
    for(unsigned int i=0;i<M;i++){
        scanf("%u",&op);
        scanf("%u",&a);
        scanf("%u",&b);
        if(op==0)
            printf("%u\n", Query(segarr,0,N-1,a-1,b-1,0));
        else Update(segarr,arr,0,N-1,a-1,b,0);
    }
//
//    for(unsigned int i=0;i<(N<<1)-1;i++)
//        printf("%u ",segarr[i]);

    free(segarr);
    free(arr);
    return 0;
}
