//
// Created by Cosmin Dumitru on 06.04.2024.
//
#include <fstream>
using namespace std;

const int N=1e5;
const int L = 17;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int v[N+1],aint[(1<<(L+1))];

void constructie(int p, int st, int dr){
    if (st == dr){///problema elementara: secventa de lungime 1 -> frunza in aint
        aint[p] = v[st];
        return;
    }
    int m = (st + dr) / 2, fs = 2 * p, fd = 2 * p + 1;
    constructie(fs, st, m);///subarborele stang retine datele pentru prima jumatate a secv. curente
    constructie(fd, m + 1, dr);///subarborele drept ... a doua jumatate
    ///rezultatul curent se obtine combinand rez. din cei doi fii
    aint[p] = max(aint[fs], aint[fd]);
}

int interogare(int p, int st, int dr, int a, int b){
    ///returneaza rezultatul corespunzator intersectie dintre [st,dr] si [a,b]
    if (a <= st && dr <= b){
        return aint[p];///rezuntatul curent e unul dintre cele care dau rez. pe intervalul [a,b]
    }
    int m = (st + dr) / 2, fs = 2 * p, fd = 2 * p + 1;
    int rez_st = -1, rez_dr = -1;
    if (a <= m){///daca intervalul care ne intereseaza, [a,b] are elemente comune cu jumatatea stanga

        rez_st = interogare(fs, st, m, a, b);
    }
    if (m + 1 <= b){///intervalul care ne intereseaza, [a,b] are elemente comune cu jumatatea dreapta
        rez_dr = interogare(fd, m + 1, dr, a, b);
    }
    ///rezultatul final se obtine combinand rez_st cu rez_dr
    return max(rez_st, rez_dr);
}

void actualizare(int p, int st, int dr, int poz, int val){
    if (st == dr){///stim de fapt ca st = poz = dr
        aint[p] = val;
        return;
    }
    int m = (st + dr) / 2, fs = 2 * p, fd = 2 * p + 1;
    ///in functie de poz vom actualiza doar subarborele stang sau cel drept
    if (poz <= m){
        actualizare(fs, st, m, poz, val);
    }else{
        actualizare(fd, m + 1, dr, poz, val);
    }
    ///rezultatul curent se obtine combinand rezultatele din cei doi fii
    aint[p] = max(aint[fs], aint[fd]);
}


int main(){
    int n,nr_op;
    fin >> n >> nr_op;
    for (int i = 1; i <=n; ++i) {
        fin >> v[i];
    }
    constructie(1,1,n);
    for (int i = 0; i < nr_op; i++)
    {
        int tip;
        fin >> tip;
        if (tip == 0)
        {
            int a, b;
            fin >> a >> b;
            fout << interogare(1, 1, n, a, b) << "\n";
        }
        else
        {
            int poz, val;
            fin >> poz >> val;
            actualizare(1, 1, n, poz, val);
        }
    }
    fin.close();
    fout.close();
    return 0;
}