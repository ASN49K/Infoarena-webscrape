#include <stdio.h>
#include <stdlib.h>

#define MAX_N 100001

int seg_tree[4 * MAX_N];
int n, m;

int max_of(int a, int b){
  return a > b ? a : b;
}

void build(int* array, int node, int start, int end){
  if(start == end){
    seg_tree[node] = array[start];
    return;
  }
  int mid = (start + end) / 2;
  build(array, 2 * node,     start,   mid);
  build(array, 2 * node + 1, mid + 1, end);
  seg_tree[node] = max_of(seg_tree[2 * node], seg_tree[2 * node + 1]);
}

void update(int node, int start, int end, int idx, int val){
  if(start == end){
    seg_tree[node] = val;
    return;
  }
  int mid = (start + end) / 2;
  if(idx <= mid){
    update(2 * node,     start,   mid, idx, val);
  }else{
    update(2 * node + 1, mid + 1, end, idx, val);
  }
  seg_tree[node] = max_of(seg_tree[2 * node], seg_tree[2 * node + 1]);
}

int query(int node, int start, int end, int l, int r){
  if(r < start || end < l)
    return 0;
  if(l <= start && end <= r)
    return seg_tree[node];
  int mid = (start + end) / 2;
  int left_max  = query(2 * node,     start,   mid, l, r);
  int right_max = query(2 * node + 1, mid + 1, end, l, r);
  return max_of(left_max, right_max);
}

int main(void){
  FILE* fin  = fopen("arbint.in",  "r");
  FILE* fout = fopen("arbint.out", "w");
  if(fin == NULL){
    perror("arbint.in");
    return 1;
  }
  if(fout == NULL){
    perror("arbint.out");
    fclose(fin);
    return 1;
  }

  fscanf(fin, "%d %d", &n, &m);

  int* array = (int*)malloc(sizeof(int) * (n + 1));
  if(array == NULL){
    perror("Out of memory");
    fclose(fin);
    fclose(fout);
    return 1;
  }

  for(int i = 1; i <= n; i++){
    fscanf(fin, "%d", &array[i]);
  }

  build(array, 1, 1, n);

  for(int i = 0; i < m; i++){
    int op, a, b;
    fscanf(fin, "%d %d %d", &op, &a, &b);
    if(op == 0){
      fprintf(fout, "%d\n", query(1, 1, n, a, b));
    }else{
      update(1, 1, n, a, b);
    }
  }

  free(array);
  fclose(fin);
  fclose(fout);
  return 0;
}
