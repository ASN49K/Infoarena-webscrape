#include <iostream>
#include <fstream>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int N, M;
int MaxArb[400070];
int start, finish, Val, Pos, maxim;

void Update(int nod, int st, int dr)
/// functie care se apeleaza intotdeauna (1,1,N), unde n e nr de frunze
/// in Val se va stoca valoarea ce trebuie stocata/modificata
/// in Pos se va stoca pozitia pe care se va pune val
{
    if(st == dr)///primul element
    {
        MaxArb[nod] = Val;///se adauga in varf
        return;
    }
    ///Pos - pozitia pe care trebuie adaugat/modificat elementul
    int div = (st + dr) / 2;
    if(Pos <= div)/// alege pe care ramura sa o ia
        Update(2 * nod, st, div);
    else  /// se apeleaza recursiv pentru copilul potrivit, unde trebuie adaugat
        Update(2 * nod + 1, div + 1, dr);
    ///cerinte in functie de problema, aici sa aflam maximul
    MaxArb[nod] = max(MaxArb[2 * nod], MaxArb[2 * nod + 1]);
}

void interogare(int nod, int st, int dr)
/// se apeleaza intotdeauna cu interogare(1,1,N), N-nr de frunze
/// in start se va stoca de unde incepe intervalul
/// in finish va stoca limita superioara a intervalului
{
    if(start <= st && dr <= finish)///orice interval dinauntrul [st,dr]
    {
        if(maxim < MaxArb[nod]) maxim = MaxArb[nod];///verifica maximul
        ///se adapteaza in fct de pb
        return;
    }
    int div = (st + dr) / 2;
    if(start <= div) ///avanseaza pe copilul din st
        interogare(2 * nod, st, div);
    if(div < finish) ///avanseaza pe copilul din dreapta
        interogare(2 * nod + 1, div + 1, dr);
    ///!!! poate avansa pe ambii copii, deci ifuri fara else
}

int main()
{
    int n,a,b,m,caz;
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        Pos=i;f>>Val;
        Update(1,1,n);
    }
    for(int i=1;i<=m;i++)
    {
        f>>caz>>a>>b;
        if(caz==0)
        {
            maxim=-1;
            start=a;finish=b;
            interogare(1);
            g<<maxim<<'\n';
        }
        else{
            Pos=a;Val=b;
            Update(1,1,n);
        }

    }
    return 0;
}
