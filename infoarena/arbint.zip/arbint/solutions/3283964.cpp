#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int aint[400055];
int v[100002];
int n, m;
int maxim;
void create(int pos, int st, int dr)
{
    if (st == dr)
    {
        aint[pos] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    create(2 * pos, st, mij);
    create(2 * pos + 1, mij + 1, dr);
    aint[pos] = max(aint[2 * pos], aint[2 * pos + 1]);
}
void update(int pos, int st, int dr, int x)
{
    if (st == dr)
    {
        aint[pos] = v[x];
        return;
    }
    int mij = (st + dr) / 2;
    if (x <= mij)
    {
        update(2 * pos, st, mij, x);
    }
    else
    {
        update(2 * pos + 1, mij + 1, dr, x);
    }
    aint[pos] = max(aint[2 * pos], aint[2 * pos + 1]);
}

void query(int pos, int st, int dr, int x, int y)
{
    if (x > dr || y < st)
        return;
    if (x <= st && dr <= y)
    {
        maxim = max(maxim, aint[pos]);
        return;
    }
    int mij = (st + dr) / 2;
    query(2 * pos, st, mij, x, y);
    query(2 * pos + 1, mij + 1, dr, x, y);
}
void read_and_solve()
{
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        fin >> v[i];
    }
    create(1, 1, n);
    for (int i = 1; i <= m; i++)
    {
        int opp, a, b;
        fin >> opp >> a >> b;
        if (opp == 1)
        {
            v[a] = b;
            update(1, 1, n, a);
        }
        else
        {
            maxim = 0;
            query(1, 1, n, a, b);
            fout << maxim << '\n';
        }
    }
}
int main()
{
    read_and_solve();
    return 0;
}