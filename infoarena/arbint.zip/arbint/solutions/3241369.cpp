#include <iostream>
#include <fstream>
using namespace std;
ifstream f("arbint.in");ofstream g("arbint.out");const int NMAX = 1e5;int aint[4 * NMAX];int n, m, op, a, b;void build(int node, int st, int dr){   if (st == dr)   {      f >> aint[node];      return;   }   int mid = (st + dr) / 2;   build(node * 2, st, mid);   build(node * 2 + 1, mid + 1, dr);   aint[node] = max(aint[node * 2], aint[node * 2 + 1]);}void update(int node, int st, int dr, int pos, int val){   if (st == dr)   {      aint[node] = val;      return;   }   int mid = (st + dr) / 2;   if (pos <= mid)      update(node * 2, st, mid, pos, val);   else      update(node * 2 + 1, mid + 1, dr, pos, val);   aint[node] = max(aint[node * 2], aint[node * 2 + 1]);}int query(int node, int st, int dr, int x, int y){   if (dr < x || y < st)      return 0;   if (x <= st && dr <= y)      return aint[node];   int mid = (st + dr) / 2;   int query_st = query(node * 2, st, mid, x, y);   int query_dr = query(node * 2 + 1, mid + 1, dr, x, y);   return max(query_st, query_dr);}
int main()
{   f >> n >> m;   build(1, 1, n);   while (m--)   {      f >> op >> a >> b;      if (op == 0)         g << query(1, 1, n, a, b) << '\n';      else         update(1, 1, n, a, b);   }
   f.close();   g.close();
   return 0;
}
