#include<fstream>

std::ifstream fin("arbint.in");
std::ofstream fout("arbint.out");

const int MAX = 1e5;
int v[MAX + 5], n, q;

class AINT {
private:
	int seg[4 * MAX + 5];
public:
	void build(int poz, int st, int dr) {
		if (st == dr)
			seg[poz] = v[st];
		else {
			int m = (st + dr) / 2;
			build(2 * poz, st, m);
			build(2 * poz + 1, m + 1, dr);
			seg[poz] = std::max(seg[2 * poz], seg[2 * poz + 1]);
		}
	}

	void update(int poz, int x, int p, int st, int dr) {
		if (st == dr)
			seg[poz] = x;
		else {
			int m = (st + dr) / 2;
			if (p <= m)
				update(2 * poz, x, p, st, m);
			else
				update(2 * poz + 1, x, p, m + 1, dr);
			seg[poz] = std::max(seg[2 * poz], seg[2 * poz + 1]);
		}
	}

	int query(int poz, int st, int dr, int query_left, int query_right) {
		if (query_left <= st and dr <= query_right)
			return seg[poz];
		else {
			int m = (st + dr) / 2;
			if (query_right <= m)
				return query(2 * poz, st, m, query_left, query_right);
			if (m < query_left)
				return query(2 * poz + 1, m + 1, dr, query_left, query_right);
			return std::max(query(2 * poz, st, m, query_left, query_right), query(2 * poz + 1, m + 1, dr, query_left, query_right));
		}
	}
};

AINT A;

int main() {
	fin >> n >> q;

	for (int i = 1; i <= n; ++i)
		fin >> v[i];

	A.build(1, 1, n);

	int type, a, b;

	for (; q--;) {
		fin >> type >> a >> b;
		if (type == 0)
			fout << A.query(1, 1, n, a, b) << '\n';
		else
			A.update(1, b, a, 1, n);
	}
}