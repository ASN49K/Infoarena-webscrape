#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <string>
#include <queue>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

const int NMAX = 100005;
int n, m;
int a[4 * NMAX];


void update(int nod, int st, int dr, int poz, int val)
{
	if (st == dr)
	{
		a[nod] = val;
		return;
	}
	int mij = (st + dr) / 2;
	if (poz <= mij)
		update(2 * nod, st, mij, poz, val);
	else
		update(2 * nod + 1, mij + 1, dr, poz, val);
	a[nod] = max(a[2 * nod], a[2 * nod + 1]);
}

int query(int nod, int st, int dr, int l, int r)
{
	if(l <= st && dr <= r)
		return a[nod];
	int mij = (st + dr) / 2;
	int ans = 0;
	if (mij >= l)
	{
		ans = max(ans, query(2 * nod, st, mij, l, r));
	}

	if (mij + 1 <= r)
	{
		ans = max(ans, query(2 * nod + 1, mij + 1, dr, l, r));
	}
		
	return ans;
}

int main()
{
	f >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		int x;
		f >> x;
		update(1, 1, n, i, x);
	}


	for (int i = 1; i <= m; i++)
	{
		int op, x, y;
		f >> op >> x >> y;
		if (op == 1)
			update(1, 1, n, x, y);
		else
			g << query(1, 1, n, x, y) << '\n';
	}
}