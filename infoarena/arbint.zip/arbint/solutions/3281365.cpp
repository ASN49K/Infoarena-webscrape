#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, k, a[400010], Q;

void Update(int p, int x)
{
    p += (n - 1);
    a[p] = x;
    while (p > 1)
    {
        p /= 2;
        a[p] = max(a[2 * p], a[2 * p + 1]);
    }
}

/// aflu max pe intervalul [x,y]
/// nodul k reprezinta intervalul [st, dr]
int Query(int k, int x, int y, int st, int dr)
{
    if (x == st && y == dr) return a[k];
    int m = (st + dr) / 2;
    if (y <= m) /// [x,y] este inclus in [st,m]
        return Query(2 * k, x, y, st, m);
    if (m + 1 <= x) /// [x,y] este inlus in [m+1,dr]
        return Query(2 * k + 1, x, y, m + 1, dr);
    /// [x,y] se imparte in [x,m] si [m+1,y]
    return max(Query(2 * k, x, m, st, m),
               Query(2 * k + 1, m + 1, y, m + 1, dr));
}

int main()
{
    int i, op, x, y;
    fin >> k >> Q;
    for (n = 1; n < k; n *= 2)
        ;
    for (i = 1; i <= k; i++)
        fin >> a[n - 1 + i];
    for (i = n - 1; i >= 1; i--)
        a[i] = max(a[2 * i], a[2 * i + 1]);
    while (Q--)
    {
        fin >> op >> x >> y;
        if (op == 0) fout << Query(1, x, y, 1, n) << "\n";
        else Update(x, y);
    }
    return 0;
}
