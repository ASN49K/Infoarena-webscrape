#include <bits/stdc++.h>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int n, m, p, v[100005], x, y, z, a[1005];

int find (int x)
{
    return (x+p-1)/p;
}

int main()
{
    cin >> n >> m;
    p=floor(sqrt(n));
    for (int i=1; i<=n; i++)
    {
        cin >> v[i];
        a[find(i)]=max(a[find(i)],v[i]);
    }
    for (int i=1; i<=m; i++)
    {
        cin >> z >> x >> y;
        if (z==0)
        {
            int Max=-1;
            for (int j=x; find(j)==find(x); j++)
                Max=max(Max,v[j]);
            for (int j=find(x)+1; j<=find(y)-1; j++)
                Max=max(Max,a[j]);
            for (int j=y; find(j)==find(y); j--)
                Max=max(Max,v[j]);
            cout << Max << '\n';
        }
        else
        {
            v[x]=y;
            a[find(x)]=0;
            for (int j=x; find(j)==find(x); j--)
                a[find(x)]=max(a[find(x)],v[j]);
            for (int j=x+1; find(j)==find(x); j++)
                a[find(x)]=max(a[find(x)],v[j]);
        }
    }
    return 0;
}
