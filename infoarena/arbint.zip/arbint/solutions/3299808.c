#include <stdio.h>
#include <stdlib.h>

#define MAX_N 100005

int n, m;
int arr[MAX_N];
int tree[4 * MAX_N];

int max(int a, int b) {
    return (a > b) ? a : b;
}

void build(int node, int start, int end) {
    if (start == end) {
        tree[node] = arr[start];
    } else {
        int mid = (start + end) / 2;
        build(2 * node, start, mid);
        build(2 * node + 1, mid + 1, end);
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

void update(int node, int start, int end, int idx, int val) {
    if (start == end) {
        arr[idx] = val;
        tree[node] = val;
    } else {
        int mid = (start + end) / 2;
        if (idx <= mid) {
            update(2 * node, start, mid, idx, val);
        } else {
            update(2 * node + 1, mid + 1, end, idx, val);
        }
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

int query(int node, int start, int end, int l, int r) {
    if (r < start || end < l) {
        return 0;
    }
    if (l <= start && end <= r) {
        return tree[node];
    }
    int mid = (start + end) / 2;
    int p1 = query(2 * node, start, mid, l, r);
    int p2 = query(2 * node + 1, mid + 1, end, l, r);
    return max(p1, p2);
}

int main() {
    FILE *fin = NULL;
    FILE *fout = NULL;
    
    if((fin = fopen("arbint.in", "r")) == NULL) {
        fprintf(stderr, "Eroare la deschidere\n");
        return 1;
    }

    if((fout = fopen("arbint.out", "w")) == NULL) {
        fprintf(stderr, "Eroare la deschidere\n");
        fclose(fin);
        return 1;
    }
    
    fscanf(fin, "%d %d", &n, &m);
    
    for (int i = 1; i <= n; i++) {
        fscanf(fin, "%d", &arr[i]);
    }
    
    build(1, 1, n);
    
    for (int i = 0; i < m; i++) {
        int type;
        fscanf(fin, "%d", &type);
        
        if (type == 0) {
            int a, b;
            fscanf(fin, "%d %d", &a, &b);
            int result = query(1, 1, n, a, b);
            fprintf(fout, "%d\n", result);
        } else if (type == 1) {
            int a, b;
            fscanf(fin, "%d %d", &a, &b);
            update(1, 1, n, a, b);
        }
    }
    
    fclose(fin);
    fclose(fout);
    
    return 0;
}