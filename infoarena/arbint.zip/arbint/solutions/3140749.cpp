#include <iostream>
#include <fstream>

using namespace std;

#define MAXN 4 * 100000

ifstream f("arbint.in");
ofstream g("arbint.out");

int v[MAXN], n, m, a, b, maxim, o;

void update(int nod, int l, int r) {
    if (l == r) {
        v[nod] = b;
        return;
    }
    int mid = (l + r) / 2;
    if (a <= mid) {
        update(2 * nod, l, mid);
    } else {
        update(2 * nod + 1, mid + 1, r);
    }
    v[nod] = max(v[2 * nod], v[2 * nod + 1]);
}

void query(int nod, int l, int r) {
    if (a <= l && b >= r) {
        maxim = max(maxim, v[nod]);
        return;
    }
    int mid = (l + r) / 2;
    if (a <= mid) {
        query(2 * nod, l, mid);
    }
    if (mid < b) {
        query(2 * nod + 1, mid + 1, r);
    }
}

int main()
{
    f >> n >> m;
    for (int i = 1; i <= n; ++i) {
        f >> b;
        a = i;
        update(1, 1, n);
    }

    while (m--) {
        f >> o >> a >> b;
        if (o == 0) {
            maxim = -1;
            query(1, 1, n);
            g << maxim << '\n';
        } else {
            update(1, 1, n);
        }
    }

    return 0;
}
