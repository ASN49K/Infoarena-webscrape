#include <bits/stdc++.h>
//#pragma GCC optimize("O2")
using namespace std;
int st[700000];

void update(int node, int from, int to, int pos, int val)
{
    if(from==to)
    {
        st[node]=val;
        return;
    }
    int mid=(from+to)/2;
    if(pos<=mid)
    {
        update(node*2, from, mid, pos, val);
    }
    else
    {
        update(node*2+1, mid+1, to, pos, val);
    }

    st[node]=max(st[node*2], st[node*2+1]);
}

int query(int node, int from, int to, int qleft, int qright)
{
    int smin=210000000;
    if(qleft<=from && to<=qright)
    {
        return st[node];
    }
    int mid=(from+to)/2;
    if(qleft<=mid)
    {
        int s=query(node*2, from, mid, qleft, qright);
        smin=max(smin, s);
    }

    if(mid+1<=qright)
    {
        int s=query(node*2+1, mid+1, to, qleft, qright);
        smin=max(smin, s);
    }

    return smin;
}

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    int n, q, a, x, y;
    cin>>n>>q;
    for(int i=1; i<=n; i++)
    {
        cin>>a;
        update(1, 1, n, i, a);
    }
    for(int i=1; i<=q; i++)
    {
        cin>>a>>x>>y;
        if(a==1)
        {
            update(1, 1, n, x, y);
        }
        else
        {
            cout<<query(1, 1, n, x, y)<<'\n';
        }
    }
    return 0;
}
