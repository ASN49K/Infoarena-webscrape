#include <iostream>

#define NMAX 100000

using namespace std;

int n, m;
int vec[NMAX+1];
int aint[NMAX*4];

void init(int st = 0, int dr = n-1, int nod = 1)
{
    if(st == dr)
    {
        aint[nod] = vec[st];
    }
    else
    {
        int mij = (st+dr)/2;
        init(st, mij, 2*nod);
        init(mij+1, dr, 2*nod+1);
        aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
}

int query(const int &cst, const int &cdr, int st = 0, int dr = n-1, int nod = 1)
{
    if(cst <= st && dr <= cdr)
        return aint[nod];
    else
    {
        int mij = (st+dr)/2, val = 0;
        if(cst <= mij)
            val = query(cst, cdr, st, mij, 2*nod);
        if(mij+1 <= cdr)
            val = max(val, query(cst, cdr, mij+1, dr, 2*nod+1));
        return val;
    }
}

void update(const int &pos, const int &val, int st = 0, int dr = n-1, int nod = 1)
{
    if(st == dr && st == pos)
        aint[nod] = val;
    else
    {
        int mij = (st+dr)/2;
        if(pos <= mij)
            update(pos, val, st, mij, 2*nod);
        else
            update(pos, val, mij+1, dr, 2*nod+1);

        aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
}

void printaint(int st = 0, int dr = n-1, int nod = 1)
{
    printf("[%d, %d, %d] ", st, dr, aint[nod]);
    if(st != dr)
    {
        int mij = (st+dr)/2;
        printaint(st, mij, 2*nod);
        printaint(mij+1, dr, 2*nod+1);
    }
}

int main()
{
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);

    scanf("%d%d", &n, &m);
    for(int i=0; i<n; i++)
        scanf("%d", &vec[i]);

    init();

    for(int i=0; i<m; i++)
    {
        int cer, x, y;
        scanf("%d%d%d", &cer, &x, &y);

        if(cer == 0)
            printf("%d\n", query(x-1, y-1));
        else
            update(x-1, y);
    }
    return 0;
}