#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");
int v[100101], b[100101];
const int l=1024;
void DisplayB()
{
    for(int i=0; i<l; i++)
    {
        out<<b[i]<<" ";
    }out<<'\n';
}
int main()
{
    int n, m;
    in>>n>>m;
    for(int i=0; i<n; i++)
    {
        in>>v[i];
    }
    for(int i=0; i<n; i++)
        b[i/l]=max(b[i/l], v[i]);
    //DisplayB();
    int op, x, y, maxi=0;
    for(int i=0; i<m; i++)
    {
        in>>op>>x>>y; x--;
        maxi=0;
        if(op==1)
        {
            v[x]=y;
            if(v[x]>b[x/l])
                b[x/l]=v[x];
        }
        else
        {
            y--;
            for(int j=x; j<=y;)
            {
                if(j%l==0 && j+l-1<=y)
                {
                    maxi=max(maxi, b[j/l]);
                    j=j+l;
                }
                else
                {
                    maxi=max(maxi, v[j]);
                    j++;
                }
            }
            out<<maxi<<'\n';
        }
    }
    //DisplayB();
}
