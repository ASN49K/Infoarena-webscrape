#include <iostream>
#include <fstream>

using namespace std;
#define Maxn 100000
int aint[Maxn*4], v[Maxn];
void build(int node, int nLeft, int nRight){
    if(nLeft==nRight){
        aint[node]=v[nLeft];
        return;
    }
    int nMid, leftson, rightson;
    nMid=(nLeft+nRight)/2;
    leftson=node*2;
    rightson=leftson+1;
    build(leftson, nLeft, nMid);
    build(rightson, nMid+1, nRight);
    aint[node]=max(aint[leftson],aint[rightson]);
}
int query(int node, int nLeft, int nRight, int qLeft, int qRight){
    if(qLeft<=nLeft && nRight<=qRight)
        return aint[node];
    int nMid, leftson, rightson, result;
    nMid=(nLeft+nRight)/2;
    leftson=node*2;
    rightson=leftson+1;
    result=0;
    if(qLeft<=nMid)
    result=max(result, query(leftson, nLeft, nMid, qLeft, qRight));
    if(qRight>nMid)
    result=max(result, query(rightson, nMid+1, nRight, qLeft, qRight));

    return result;
}
void update(int node, int nLeft, int nRight, int poz, int val){
    if(nLeft==nRight){
        aint[node]=val;
        return;
    }
    int nMid, leftson, rightson;
    nMid=(nLeft+nRight)/2;
    leftson=node*2;
    rightson=leftson+1;
    if(poz<=nMid)
        update(leftson, nLeft, nMid, poz, val);
    else
        update(rightson, nMid+1, nRight, poz, val);
    aint[node]=max(aint[leftson], aint[rightson]);
}
int main()
{
    ifstream in("arbint.in");
    ofstream out("arbint.out");
    int n, a, i, m, q, b;
    in>>n>>m;
    for(i=1; i<=n; i++)
        in>>v[i];
    build(1, 1, n);
    for(i=1; i<=m; i++){
        in>>q>>a>>b;
        if(q==0){
        out<<query(1, 1, n, a, b)<<'\n';
        }
        if(q==1)
        update(1, 1, n, a, b);

    }
    return 0;
}
