#include <iostream>

int tree[400004];

void update(int node, int val, int ind, int st, int dr)
{
    if(st == dr)
    {
        tree[node] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if(ind <= mij)
        update(2 * node, val, ind, st, mij);
    else
        update(2 * node + 1, val, ind, mij + 1, dr);

    tree[node] = std::max(tree[2 * node], tree[2 * node + 1]);
}

int query(int node, int a, int b, int st, int dr)
{
    if(a <= st && b >= dr)
    {
        return tree[node];
    }
    int mij = (st + dr) / 2;
    int ans = -1;

    if(a <= mij)
        ans = std::max(ans, query(2 * node, a, b, st, mij));

    if(b > mij)
        ans = std::max(ans, query(2 * node + 1, a, b, mij + 1, dr));

    return ans;
}

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);

    int n, m;
    std::cin >> n >> m;
    for(int i = 1; i <= n; i ++)
    {
        int a;
        std::cin >> a;
        update(1, a, i, 1, n);
    }
    for(int i = 1; i <= m; i++)
    {
        int op, a, b;
        std::cin >> op >> a >> b;
        if(op == 1)
        {
            update(1, b, a, 1, n);
        }
        else
        {
            std::cout << query(1, a, b, 1, n) << '\n';
        }
    }
    return 0;
}
