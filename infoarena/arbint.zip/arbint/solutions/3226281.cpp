//HASH , map -------------------------------------------------------------------
#include <bits/stdc++.h>
using namespace std;
const int nmax = 1e5 + 5;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int aint[4 * nmax], offset, n, m, x, cerinta, a, b;


void update_begin(int poz, int val){
    
    aint[offset + poz] = val;
    
    for(int j=(offset + poz) / 2;j>0;j/=2){
        aint[j] = max (aint[j] , val);
    }
    
}

void update(int poz, int val){
    
    aint[offset + poz] = val;
    
    for(int j=(offset + poz) / 2;j>0;j/=2){
        aint[j] = max (aint[j*2] , aint[j*2+1]);
    }
    
}


int query(int node, int l, int r, int gl, int gr){
    
    if(l > gr || r < gl) return 0;
    
    if(gl <= l && r <= gr) return aint[node];
    
    int mij = (l + r) / 2;
    
    int stanga = query(node*2, l, mij, gl, gr);
    int dreapta = query(node*2+1, mij+1, r, gl, gr);
    
    //cout<<stanga<<" "<<dreapta<<endl;
    return max(stanga , dreapta);
    
}


int main()
{
    fin>>n>>m;
    
    offset = 1;
    while(offset < n){
        offset *= 2;
    }
    offset *= 2;
    
    for(int i=1;i<=n;i++){
        fin>>x;
        update_begin(i-1 , x);
    }
    
    // for(int i=1;i<=offset+n;i++){
    //     cout<<aint[i]<<" ";
    // }
    
    for(int i=1;i<=m;i++){
        fin>>cerinta>>a>>b;
        
        if(cerinta == 1){
            update(a-1, b);
        }else{
            fout<<query(1, 0, offset, a-1, b)<<"\n";
        }
        
    }
    
    
    
    
    
    
}


