#include <bits/stdc++.h>
#define oo 1000000007
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n,k,Q;
int a[400005];
void Update(int p, int x)
{
    p += (n - 1);
    a[p] = x;
    while(p > 1)
    {
        p /= 2;
        a[p] = max(a[2 * p], a[2 * p + 1]);
    }
}
int Query(int k, int x, int y, int st, int dr)
{
    if(x == st && y == dr) return a[k];
    int m = (st + dr) / 2;
    if(y <= m) return Query(2 * k, x, y, st, m);
    if(m + 1 <= x) return Query(2 * k + 1, x, y, m + 1, dr);
    return max(Query(2 * k + 1, m + 1, y, m + 1, dr), Query(2 * k, x,m,st,m));
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i,x,y,task;
    cin >> k >> Q;
    for(n = 1; n < k; n *= 2)
        ;
    for(i = 1; i <= k; i++)
        cin >> a[n - 1 + i];
    for(i = n - 1; i >= 1; i--)
        a[i] = max(a[2 * i], a[2 * i + 1]);
    while(Q--)
    {
        cin >> task >> x >> y;
        if(task == 1) Update(x,y);
        else cout << Query(1, x, y, 1, n) << "\n";
    }
    return 0;
}
