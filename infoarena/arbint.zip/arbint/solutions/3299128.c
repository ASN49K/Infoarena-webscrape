#include<stdio.h>
#include<stdlib.h>

#define max 400005

int n, m, a[100005] = { 0 }, arb[max] = { 0 };
// construim arborele de intervale
void construieste(int nod, int st, int dr)
{
    if (st == dr) {
        arb[nod] = a[st];
        return;
    }
    int mij = (st + dr) / 2;
    construieste(2 * nod, st, mij);
    construieste(2 * nod + 1, mij + 1, dr);
    if (arb[2 * nod] > arb[2 * nod + 1])
        arb[nod] = arb[2 * nod];
    else
        arb[nod] = arb[2 * nod + 1];
}
// cautam maximul in [l,r]
int interogare(int nod, int st, int dr, int l, int r)
{
    if (r < st || dr < l)
        return 0;
    if (l <= st && dr <= r)
        return arb[nod];
    int mij = (st + dr) / 2;
    int q1 = interogare(2 * nod, st, mij, l, r);
    int q2 = interogare(2 * nod + 1, mij + 1, dr, l, r);
    if (q1 > q2)
        return q1;
    else
        return q2;
}
// actualizam valoarea de pe pozitia poz cu val
void actualizeaza(int nod, int st, int dr, int poz, int val)
{
    if (st == dr)
    {
        arb[nod] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if (poz <= mij)
        actualizeaza(2 * nod, st, mij, poz, val);
    else
        actualizeaza(2 * nod + 1, mij + 1, dr, poz, val);
    if (arb[2 * nod] > arb[2 * nod + 1])arb[nod] = arb[2 * nod];
    else
        arb[nod] = arb[2 * nod + 1];
}

int main() {
    FILE* fin = fopen("arbint.in", "r");
    if (fin == NULL)
    {
        perror("eroare deschidere arbint.in");
        exit(1);
    }
    FILE* fout = fopen("arbint.out", "w");
    if (fout == NULL)
    {
        perror("eroare deschidere arbint.out");
        exit(1);
    }
    fscanf(fin, "%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        fscanf(fin, "%d", &a[i]);
    construieste(1, 1, n); // initializam arborele
    for (int i = 0; i < m; i++)
    {
        int tip, x, y;
        fscanf(fin, "%d%d%d", &tip, &x, &y);
        if (tip == 0)
            fprintf(fout, "%d\n", interogare(1, 1, n, x, y)); // interogare
        else
            actualizeaza(1, 1, n, x, y); // actualizare
    }
    fclose(fin); fclose(fout);
    return 0;
}
