#include <fstream>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,q,x,y,task,aint[4*nmax];
void update(int nod,int st,int dr,int p,int x){
    if(st==dr){
        aint[nod]=x;
        return;
    }
    int mid=(st+dr)/2;
    if(p<=mid)
        update(2*nod,st,mid,p,x);
    else
        update(2*nod+1,mid+1,dr,p,x);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
int query(int nod,int st,int dr,int x,int y){
    if(x<=st&&dr<=y)
        return aint[nod];
    int mid=(st+dr)/2;
    if(x>mid)
        return query(2*nod+1,mid+1,dr,x,y);
    else if(y<=mid)
        return query(2*nod,st,mid,x,y);
    else
        return max(query(2*nod,st,mid,x,y),query(2*nod+1,mid+1,dr,x,y));
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>x;
        update(1,1,n,i,x);
    }
    while(q--){
        cin>>task>>x>>y;
        if(task==0)
            cout<<query(1,1,n,x,y)<<'\n';
        else
            update(1,1,n,x,y);
    }
    return 0;
}
