#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int Nmax, n, m, v[100005], Nod[400005];
void citire() {
    fin >> n >> m;
    int i;
    for (i = 1; i <= n; i++)
        fin >> v[i];
}
void Build(int nod, int st, int dr) {
    if (st == dr) {
        Nod[nod] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    Build(2 * nod, st, mij);
    Build(2 * nod + 1, mij + 1, dr);
    Nod[nod] = max(Nod[2 * nod], Nod[2 * nod + 1]);
}
void Query(int nod, int st, int dr, int Qst, int Qdr) {
    if(st > Qdr || dr < Qst)
        return;
    if(st >= Qst && dr <= Qdr) {
        Nmax = max(Nmax, Nod[nod]);
        return;
    }
    int mij = (st + dr) / 2;
    Query(2 * nod, st, mij, Qst, Qdr);
    Query(2 * nod + 1, mij + 1, dr, Qst, Qdr);

}
void Update(int nod, int st, int dr, int pos, int val) {
    if(st == dr) {
        Nod[nod] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if(pos <= mij)
        Update(2*nod, st, mij, pos, val);
    else
        Update(2 * nod + 1, mij + 1, dr, pos, val);
    Nod[nod] = max(Nod[2 * nod], Nod[2 * nod + 1]);
}
int main() {
    citire();
    Build(1, 1, n);
    int i;
    for(i = 1; i <= m; i++) {
        int p, a, b;
        fin >> p >> a >> b;
        if(p == 0) {
                Nmax = 0;
                Query(1, 1, n, a, b);
                fout << Nmax << '\n';
            }
        else
            Update(1, 1, n, a, b);
    }
    return 0;
}