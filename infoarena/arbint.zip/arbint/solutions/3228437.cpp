#include <bits/stdc++.h>

using namespace std;

int v[100000];
int segtree[1<<18];


int max(int a, int b)
{
    if(a>=b)
        return a;
    else
        return b;
}

void TreeGrowing(int st, int dr, int id)
{
    //printf("%d %d %d", st, dr, id);
    if(st==dr)
    {
        segtree[id-1] = v[st];
        //printf("\n");
    }
    else
    {
        int mij;
        mij = st+(dr-st+1)/2;
        //printf("  %d\n", mij);
        TreeGrowing(st, mij-1, id*2);
        TreeGrowing(mij, dr, id*2+1);
        segtree[id-1] = max(segtree[id*2-1], segtree[id*2]);
    }
}

int a, b, maxul;
void TreeSearching(int st, int dr, int id)
{
    if(a<=st && dr<=b)
    {
        if(maxul<segtree[id-1])
            maxul = segtree[id-1];
    }
    else if(st!=dr)
    {
        int mij = st+(dr-st+1)/2;
        TreeSearching(st, mij-1, id*2);
        TreeSearching(mij, dr, id*2+1);
    }
}

void TreeUpdateing(int st, int dr, int id)
{
    if(st==dr && st==a)
        segtree[id-1] = b;
    else
    {
        //if(segtree[id-1]<b)
            //segtree[id-1] = b;

        int mij = st+(dr-st+1)/2;
        if(st<=a && a<=mij-1)
            TreeUpdateing(st, mij-1, id*2);
        else if(mij<=a && a<=dr)
            TreeUpdateing(mij, dr, id*2+1);
        segtree[id-1] = max(segtree[id*2-1], segtree[id*2]);
    }
}

int main()
{
    FILE *fin, *fout;
    int n, m, i, j;
    int type, k;
    fin = fopen("arbint.in", "r");
    fout = fopen("arbint.out", "w");


  /*11 5
    4 3 5 6 1 4 8 10 1 9 3*/
    fscanf(fin, "%d%d", &n, &m);

    for(i=0; i<n; i++)
        fscanf(fin, "%d", &v[i]);

    TreeGrowing(0, n-1, 1);

    //for(i=0; i<40; i++)
        //fprintf(fout, "%d ", segtree[i]);
    //fprintf(fout, "\n");
    /*k=0;
    for(i=0; i<4; i++)
    {
        for(j=0; j<1<<i; j++)
        {
            fprintf(fout, "%d ", segtree[k]);
            k++;
        }
        fprintf(fout, "\n");
    }*/

    for(i=0; i<m; i++)
    {
        fscanf(fin, "%d%d%d", &type, &a, &b);

        if(type==0)
        {
            a--;
            b--;
            maxul = 0;
            TreeSearching(0, n-1, 1);
            fprintf(fout, "%d\n", maxul);
        }
        else if(type==1)
        {
            a--;
            TreeUpdateing(0, n-1, 1);

            /*k=0;
            for(j=0; j<4; j++)
            {
                for(type=0; type<1<<j; type++)
                {
                    fprintf(fout, "%d ", segtree[k]);
                    k++;
                }
                fprintf(fout, "\n");
            }*/
        }

    }

    fclose(fin);
    fclose(fout);
    return 0;
}
