#include <fstream>
#include <iostream>
#include <queue>

using namespace std;
const int N=1e5;

int aint[4*N];
int a[N];

int max(int a, int b){
    return a > b ? a : b;
}

void init(int node, int st, int dr){
    if(st==dr){
        aint[node]=a[st];
        return;
    }
    int mij=(st+dr)/2;
    init(2*node+1, st, mij);
    init(2*node+2, mij+1, dr);
    aint[node]=max(aint[2*node+1], aint[2*node+2]);
}

void update(int node, int st, int dr, int poz, int x){
    if(st>poz || dr<poz)
        return;
    if(st==dr){
        aint[node]=x;
        return;
    }
    int mij=(st+dr)/2;
    if(mij>=poz)
        update(2*node+1, st, mij, poz, x);
    else
        update(2*node+2, mij+1, dr, poz, x);
    aint[node]=max(aint[2*node+1], aint[2*node+2]);
}
int query(int node, int st, int dr, int l, int r){
    if(st>r || dr<l)
        return -1;
    if(l<=st && dr<=r)
        return aint[node];
    int mij=(st+dr)/2;
    return max(query(2*node+1, st, mij, l, r), query(2*node+2, mij+1, dr, l, r));
}


int main(){
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    int n, m, tip, l, r, poz, x;
    fin>>n>>m;
    for(int i=0; i<n; i++)
        fin>>a[i];
    init(0, 0, n-1);
    for(int i=0; i<m; i++){
        fin>>tip;
        if(tip==1){
            fin>>poz>>x;
            update(0, 0, n-1, poz-1, x);
        }else{
            fin>>l>>r;
            fout<<query(0, 0, n-1, l-1, r-1)<<"\n";
        }
    }
    return 0;
}
