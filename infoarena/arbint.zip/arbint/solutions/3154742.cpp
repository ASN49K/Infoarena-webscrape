#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ( "arbint.in" );
ofstream fout ( "arbint.out" );

const int N = 200000;
int v[N + 1], aint[N + 1];

int query ( int q_st, int q_dr, int i, int st, int dr ) {

    if ( st == q_st && dr == q_dr )
        return aint[i];
    
    int mid = ( st + dr ) / 2;
    
    if ( mid >= q_dr )
         return query ( q_st, q_dr, i * 2 + 1, st, mid );
    else if ( q_st >= mid + 1 )
        return query ( q_st, q_dr, i * 2 + 2, mid + 1, dr );

    else
        return max ( query ( q_st, mid, i * 2 + 1, st, mid ), query ( mid + 1, q_dr, i * 2 + 2, mid + 1, dr ) );
}

void update ( int pos, int val, int i, int st, int dr ) {

    if ( st == dr ) {
        aint[i] = val;
        return;
    }

    int mid = ( st + dr ) / 2;

    if ( pos <= mid )
        update( pos, val, i * 2 + 1, st, mid );
    else
        update( pos, val, i * 2 + 2, mid + 1, dr );

    aint[i] = max ( aint[i * 2 + 1], aint[i * 2 + 2] );
}

int main () {
    
    int n, m, i, a, b, c;
    
    fin >> n >> m;
    
    for ( i = 1; i <= n; i++ ) {
        fin >> v[i];
        update ( i, v[i], 0, 1, n );
    }
    
    for ( i = 0; i < m; i++ ){
        
        fin >> c >> a >> b;
        
        if ( c == 1 )
            update ( a, b, 0, 1, n );
        else
            fout << query ( a, b, 0, 1, n ) << "\n";
    }
    
}
