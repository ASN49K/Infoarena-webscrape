#include <iostream>
#include <fstream>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");

int aray[100005], segment_tree[4 * 100005], a, b, c, n, m;
void build(int node, int left, int right)
{
    if(left == right)
        segment_tree[node] = aray[left];
    else
    {
        int middle = (left + right) / 2;
        build(node * 2, left, middle);
        build(node * 2 + 1, middle + 1, right);
        segment_tree[node] = max(segment_tree[node * 2], segment_tree[node * 2 + 1]);
    }
}
void update(int node, int left, int right, int position, int new_value)
{
    if(left == right)
        segment_tree[node] = new_value;
    else
    {
        int middle = (left + right) / 2;
        if(position <= middle)
            update(node * 2, left, middle, position, new_value);
        else
            update(node * 2 + 1, middle + 1, right, position, new_value);
        segment_tree[node] = max(segment_tree[node * 2], segment_tree[node * 2 + 1]);
    }
}
int query(int node, int left, int right, int query_left, int query_right)
{
    int middle;
    if(query_left <= left and right <= query_right)
        return segment_tree[node];
    else
    {
        middle = (left + right) / 2;
        if(query_right <= middle)
            return query(node * 2, left, middle, query_left, query_right);
        if (middle + 1 <= query_left)
            return query(node * 2 + 1, middle + 1, right, query_left, query_right);
        return max(query(node * 2, left, middle, query_left, query_right), query(node * 2 + 1, middle + 1, right, query_left, query_right));
    }
}

int main()
{
    f >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        f >> aray[i];
    }
    build(1, 1, n);
    for(int i = 1; i <= m; i++)
    {
        f >> a >> b >> c;
        if(a == 0)
            g << query(1, 1, n, b, c) << endl;
        else
            update(1, 1, n, b, c);
    }
    return 0;
}
