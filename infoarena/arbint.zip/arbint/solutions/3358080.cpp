#include <fstream>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
const int N_MAX=100000;

int tree[4*N_MAX+5];
int V[N_MAX+5];

void build(int node, int le, int ri) {
    if(le == ri)
    {
        tree[node]=V[le];
        return;
    }

    int mid =(le+ri)/2;

    build(2*node,le,mid);
    build(2*node+1,mid+1,ri);

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void update(int node, int le, int ri, int pos, int val) {
    if(le==ri) {
        tree[node]=val;
        return;
    }
    
    int mid = (le + ri) / 2;

    if(pos <= mid) {
        update(2*node,le,mid,pos,val);
    }
    else {
        update(2*node+1,mid+1,ri,pos,val);
    }

    tree[node]=max(tree[2 * node],tree[2*node+1]);
}

void query(int node, int le, int ri, int x, int y, int &ans) {
    if(x<=le && ri<=y) {
        ans=max(ans,tree[node]);
        return;
    }

    int mid=(le+ri)/2;

    if(x<=mid) {
        query(2*node,le,mid,x,y,ans);
    }
    if(y>mid) {
        query(2*node+1,mid+1,ri,x,y,ans);
    }
}
int main(void)
{
    int N,M;
    int op,a,b;
    f>>N>>M;
    for(int i=1;i<=N;i++)
    f>>V[i];
    build(1,1,N);
    for(int i=1;i<=M;i++)
    {
        int ans=-1;
        f>>op>>a>>b;
        if(op==0)
        {
            query(1,1,N,a,b,ans);
            g<<ans<<'\n';
        }
        else
        {
            update(1,1,N,a,b);
            V[a]=b;
        }
    }
    return 0;
}