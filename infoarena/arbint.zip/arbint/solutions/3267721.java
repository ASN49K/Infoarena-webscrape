import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

  private int[] tree;

  public Main() {
    tree = new int[4*100005];
  }

  public void build(int node, int left, int right, StringTokenizer stringTokenizer) {
    if (left == right) {
      tree[node] = Integer.parseInt(stringTokenizer.nextToken());
      return;
    }

    int mid = (left + right) >>> 1;
    build(2*node, left, mid, stringTokenizer);
    build(2*node+1, mid+1, right, stringTokenizer);
    tree[node] = Math.max(tree[2*node], tree[2*node+1]);
  }

  public void update(int node, int left, int right, int pos, int val) {
    if (left == right) {
      tree[node] = val;
      return;
    }

    int mid = (left + right) >>> 1;
    if (pos <= mid) {
      update(2*node, left , mid, pos, val);
    } else {
      update(2*node+1, mid+1, right, pos, val);
    }
    tree[node] = Math.max(tree[2*node], tree[2*node+1]);
  }

  public int query(int node, int left, int right, int a, int b) {
    if (a <= left && right <= b) {
      return tree[node];
    }

    int mid = (left + right) >>> 1;
    int leftMax = a <= mid ? query(2 * node, left, mid, a, b) : Integer.MIN_VALUE;
    int rightMax = mid < b ? query(2 * node + 1, mid+1, right, a, b) : Integer.MIN_VALUE;
    return Math.max(leftMax, rightMax);
  }

  public void print(int node, int left, int right, StringBuilder sb) {
    if (left == right) {
      sb.append("[leaf]:" + tree[node] + " ");
      return;
    }

    int mid = (left + right) >>> 1;
    print(2*node, left, mid, sb);
    print(2*node+1, mid+1, right, sb);
    sb.append("[internal]:" + tree[node] + " ");
  }


  public static void main(String[] args) throws FileNotFoundException {

    // new Scanner(new BufferedInputStream(new FileInputStream("arbint.in"))
    try ( BufferedReader reader = new BufferedReader(new FileReader("arbint.in"));
          BufferedWriter writer = new BufferedWriter(new FileWriter("arbint.out"))) {
      String[] tokens = reader.readLine().split(" ");
      int N = Integer.parseInt(tokens[0]);
      int M = Integer.parseInt(tokens[1]);

//      int closestPowerOfTwo = 1;
//      while (closestPowerOfTwo < N) {
//        closestPowerOfTwo *= 2;
//      }

      StringTokenizer stringTokenizer = new StringTokenizer(reader.readLine());
      Main st = new Main();
      st.build(1, 1, N, stringTokenizer);

      for (int i = 1; i <= M; i++) {
        tokens = reader.readLine().split(" ");
        int op = Integer.parseInt(tokens[0]);
        switch (op) {
          case 0:
            writer.write(st.query(1, 1, N, Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2])) + "\n");
            break;
          case 1:
            int poz = Integer.parseInt(tokens[1]);
            int val = Integer.parseInt(tokens[2]);
            st.update(1, 1, N, poz, val);
            break;
        }
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

}
