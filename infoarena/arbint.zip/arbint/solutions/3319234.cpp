#include <fstream>
#include <map>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

struct interval{
    int left, right, max;
};

map<int, int> positionsMap;
int counter;

void buildTree(interval interval[], int currentIndex, int left, int right){
    interval[currentIndex].left = left;
    interval[currentIndex].right = right;

    if(left == right){
        int value;
        fin >> value;
        positionsMap.insert(pair(counter++, currentIndex));
        interval[currentIndex].max = value;
    }else{
        int middle = (left + right) / 2;
        buildTree(interval, currentIndex * 2 + 1, left, middle);
        buildTree(interval, currentIndex * 2 + 2, middle + 1, right);
    }

}

int checkForMaximum(interval intervalVector[],int indexFirst, int firstExtreme, int secondExtreme){

    int a = min(firstExtreme, secondExtreme);
    int b = max(firstExtreme, secondExtreme);

    int parent = (indexFirst - 1) / 2;
    int maximum = intervalVector[indexFirst].max;

    while(intervalVector[parent].left >= a && intervalVector[parent].right <= b){
        maximum = max(maximum, intervalVector[parent].max);
        if(parent == 0)
            break;
        parent = (parent - 1) / 2;
    }

    return maximum;
}

int main() {

    int n, m;
    fin >> n >> m;

    interval intervalVector[199999];
    buildTree(intervalVector, 0, 0, n - 1);

    for(int i = n - 2; i >= 0; i--){
        int left = i * 2 + 1;
        int right = i * 2 + 2;
        intervalVector[i].max = max(intervalVector[left].max, intervalVector[right].max);
    }

    for(int i = 0; i < m; i++){
        int op, a, b;
        fin >> op >> a >> b;
        a--;
        b--;
        if(op == 0){
            fout << max(checkForMaximum(intervalVector, positionsMap.at(a), a, b),
                        checkForMaximum(intervalVector, positionsMap.at(b), b ,a)) << endl;
        }else{
            b++;
            int posA = positionsMap.at(a);
            intervalVector[posA].max = b;
            int parentIndex = (posA - 1) / 2;

            while(true){
                int leftChildMax = intervalVector[parentIndex * 2 + 1].max;
                int rightChildMax = intervalVector[parentIndex * 2 + 2].max;
                intervalVector[parentIndex].max = max(leftChildMax, rightChildMax);
                if(parentIndex == 0)
                    break;
                parentIndex = (parentIndex - 1) / 2;
            }
        }
    }
    return 0;
}


