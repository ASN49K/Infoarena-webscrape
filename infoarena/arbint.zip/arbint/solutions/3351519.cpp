#include<bits/stdc++.h>
using namespace std;

const int NMAX = 4e5 + 5;
int n, m, arbint[NMAX], v[NMAX];

void update(int idx, int val, int arbleft, int arbright, int arbpoz) {
    if(arbleft > arbright || arbright < arbleft)
        return;

    if(arbleft == arbright) {
        arbint[arbpoz] = val;
        return;
    }

    int mij = (arbleft + arbright) / 2;
    if(idx > mij) {
        update(idx, val, mij + 1, arbright, arbpoz * 2 + 1);
    }
    else
        update(idx, val, arbleft, mij, arbpoz * 2);

    arbint[arbpoz] = max(arbint[arbpoz * 2], arbint[arbpoz * 2 + 1]);
}

int query(int left, int right, int arbleft, int arbright, int arbpoz) {
    if(arbleft > right || arbright < left) {
        return -10000;
    } 
    if(left >= arbleft && right <= arbright) {
        return arbint[arbpoz];
    }

    int mij = (left + right) / 2;
    return max(query(left, mij, arbleft, arbright, arbpoz * 2), query(mij + 1, right, arbleft, arbright, arbpoz * 2 + 1));
}

int main() {
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);
    
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {
        cin >> v[i];
        update(i, v[i], 1, n, 1);
    }

    for(int i = 1; i <= m; i++) {
        int c, a, b;
        cin >> c >> a >> b;
        if(c == 1) {
            update(a, b, 1, n, 1);
        }
        else {
            cout << query(1, n, a, b, 1) << "\n";
        }
    }
}

