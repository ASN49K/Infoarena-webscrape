#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>

using namespace std;

int aint[400000], v[100001], maxx;

void build ( int nod, int st, int dr )
{
    int m;
    if ( st == dr )
        aint [nod] = v[st];
    else
    {
        m = ( st + dr ) / 2;
        build ( 2 * nod, st, m );
        build ( 2 * nod, m + 1, dr );
        aint[nod] = max ( aint[2 * nod], aint[2 * nod + 1] );
    }
}

void update ( int nod, int st, int dr, int poz, int val )
{
    if ( st == dr )
        aint[nod] = val;
    else
    {
        int m = ( st + dr ) / 2;
        if ( poz >= m )
            update ( 2 * nod, st, m, poz, val );
        else update ( 2 * nod, m + 1, dr, poz , val);
        aint[nod] = max ( aint[2 * nod], aint[2 * nod + 1 ]);
    }
}

void query ( int nod, int st, int dr, int a, int b )
{
    if ( st <= a && dr >= b )
        maxx = max ( maxx, aint[nod] );
    else
    {
        int m = ( st + dr ) / 2;
        if ( a <= m )
            query ( 2 * nod, st, m, a, b );
        if ( b > m )
            query (2 * nod + 1, m + 1, dr, a, b );
    }
}

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
