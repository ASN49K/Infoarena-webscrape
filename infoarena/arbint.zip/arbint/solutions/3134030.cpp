#include <fstream>
#include <vector>
#include <climits>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
class AInt {
private:
    vector<int> tree;
    int n;
    void init(const vector<int>& arr,int st,int dr,int pos) {
        if (st == dr) {
            tree[pos]=arr[st];
            return;
        }
        int mid=st+(dr-st)/2;
        init(arr,st,mid,2*pos+1);
        init(arr,mid+1,dr,2*(pos+1));
        tree[pos]=max(tree[2*pos+1],tree[2*(pos+1)]);
    }
    int getMax_(int ql,int qr,int st,int dr,int pos) {
        if (ql<=st && qr>=dr)
            return tree[pos];

        if (ql>dr || qr<st)
            return INT_MIN;

        int mid=st+(dr-st) / 2;
        return max(getMax_(ql,qr,st,mid,2*pos+1),getMax_(ql,qr,mid+1,dr,2*(pos+1)));
    }


    void schimba_(int x,int val,int st,int dr,int pos) {
        if (x<st || x>dr)
            return;
        if (st == dr) {
            tree[pos]=val;
            return;
        }
        int mid=st+(dr-st) / 2;
        schimba_(x,val,st,mid,2*pos+1);
        schimba_(x,val,mid+1,dr,2*pos+2);
        tree[pos]=max(tree[2*pos+1],tree[2*(pos+1)]);
    }
public:
    AInt(const vector<int>& arr) {
        n=arr.size();
        tree.resize(4*n);
        init(arr,0,n-1,0);
    }
    void schimba(int x,int val) {
        schimba_(x,val,0,n-1,0);
    }
    int getMax(int ql,int qr) {
        return getMax_(ql,qr,0,n-1,0);
    }
};

int main() {
    vector<int> arr;
    int n,m,x,op,y;
    fin>>n>>m;
    for(int i=0;i<n;i++){
        fin>>x;
        arr.push_back(x);
    }
    AInt aint(arr);
    for(int i=0;i<m;i++){
        fin>>op>>x>>y;
        if(op==0)
            fout<<aint.getMax(x-1,y-1)<<"\n";
        else
            aint.schimba(x-1,y);
    }

    return 0;
}
