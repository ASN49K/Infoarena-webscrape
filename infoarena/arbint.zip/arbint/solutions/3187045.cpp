#include <algorithm>
#include <fstream>
#include <iostream>
using namespace std;

constexpr unsigned maxn = 1 << 17;

namespace {
template <unsigned niv>
unsigned buf[niv];

template <unsigned niv = maxn>
void build() {
    if constexpr (niv > 1) {
#pragma GCC unroll 128
        for (unsigned i = 0; i < niv; i += 2)
            buf<niv / 2>[i / 2] = max(buf<niv>[i], buf<niv>[i + 1]);
        build<niv / 2>();
    }
}

template <unsigned niv>
void rebuild(unsigned i) {
    if constexpr (niv > 1) {
        buf<niv / 2>[i / 2] = max(buf<niv>[i], buf<niv>[i ^ 1]);
        rebuild<niv / 2>(i / 2);
    }
}

void update(unsigned i, unsigned x) {
    buf<maxn>[i] = x;
    rebuild<maxn>(i);
}

template <unsigned niv = maxn>
unsigned query(unsigned st, unsigned dr, unsigned r = 0) {
    if constexpr (niv >= 1) {
        if (st == dr) return r;
        if (st % 2) r = max(r, buf<niv>[st++]);
        if (dr % 2) r = max(r, buf<niv>[--dr]);
        return query<niv / 2>(st / 2, dr / 2, r);
    }
    return 0;
}

ifstream f("arbint.in");
ofstream g("arbint.out");

constexpr int maxbuf = 2e6 + 100;
char rdbuf[maxbuf] = {}, *ip = rdbuf;

unsigned get_int() {
    unsigned x = 0;
    while (*ip < '0') ++ip;
    for (; *ip >= '0'; ++ip) x = 10 * x + *ip - '0';
    return x;
}

// Thanks to:
// https://stackoverflow.com/questions/25892665/performance-of-log10-function-returning-an-int
unsigned digits(unsigned x) {
    static constexpr unsigned char guess[33] = {
        0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4,
        5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9};
    static constexpr unsigned int tenToThe[] = {
        1,      10,      100,      1000,      10000,
        100000, 1000000, 10000000, 100000000, 1000000000,
    };
    unsigned int digits = guess[32 - __builtin_clz(x)];
    return digits + (x >= tenToThe[digits]);
}

char wrbuf[maxbuf], *op = wrbuf;
void write_int(int x) {
    if (x < 10) {
        *op++ = '0' + x;
        *op++ = '\n';
    } else {
        char *p = (op += digits(x));
        for (int y; x;) {
            y = x / 10;
            *--p = x - 10 * y + '0';
            if (y) {
                x = y / 10;
                *--p = y - 10 * x + '0';
            } else
                break;
        }
        *op++ = '\n';
    }
}
};  // namespace

int main() {
    f.read(rdbuf, maxbuf);

    unsigned n = get_int(), q = get_int();

    for (unsigned i = 0; i < n; ++i) buf<maxn>[i] = get_int();

    build();

    for (unsigned t, a, b; q--;) {
        t = get_int(), a = get_int(), b = get_int();
        if (t == 1)
            update(a - 1, b);
        else
            write_int(query(a - 1, b));
    }

    g.write(wrbuf, op - wrbuf);
}
