#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#define min(a,b) (a>b?a:b)
int *aint,s,n;
void update(int ind,int val){
    ind=ind+s-1;
    aint[ind]=val;
    ind/=2;
    do{
        aint[ind]=min(aint[2*ind],aint[2*ind+1]);
        ind/=2;
    }while(ind>0);
};
void swap(int *a,int *b){
    int t=*a;
    *a=*b;
    *b=t;
};
int rasp(int a,int b){
    a=a+s-1;
    b=b+s-1;
    int r=INT_MIN;
    if(a>=b) swap(&a,&b);
    while(a<=b){
        if((a&1)==1){
            r=min(r,aint[a]);
            a++;
        };
        if((b&1)==0){
            r=min(r,aint[b]);
            b--;
        };
        a/=2;
        b/=2;
    };
    return r;
};
int main()
{
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);
    int m,a,b,v,c;
    scanf("%d%d",&n,&m);
    double l=(double)(log(n))/(double)(log(2));
    s=(int)pow(2,(int)(l)+(int)(!(l==(int)l)));
    aint=(int *)calloc(s<<1,sizeof(int));
    int p=s<<1;
    for(int i=0;i<p;i++)
        aint[i]=INT_MAX;
    for(int i=0;i<n;i++)
    scanf("%d",&v),update(i+1,v);
    for(int i=0;i<m;i++){
        scanf("%d%d%d",&c,&a,&b);
        if(c==0)
        printf("%d\n",rasp(a,b));
        else update(a,b);
    };
    return 0;
}