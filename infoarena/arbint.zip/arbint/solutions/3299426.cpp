#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

long long tree[400005];

void modifica(int nod,int st,int dr,int poz,long long val)
{
    if(st==dr)
    {
        tree[nod]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(poz<=mij)
    {
        modifica(2*nod,st,mij,poz,val);
    }
    else
    {
        modifica(2*nod+1,mij+1,dr,poz,val);
    }
    tree[nod]=max(tree[2*nod],tree[2*nod+1]);
}

long long interogare(int nod,int st,int dr,int left,int right)
{
    long long res=0;
    if(left<=st && dr<=right)
    {
        return tree[nod];
    }
    int mij=(st+dr)/2;
    if(left<=mij)
    {
        res=max(res,interogare(2*nod,st,mij,left,right));
    }
    if(mij+1<=right)
    {
        res=max(res,interogare(2*nod+1,mij+1,dr,left,right));
    }
    return res;
}

int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        long long val;
        fin>>val;
        modifica(1,1,n,i,val);
    }
    for(int i=0;i<m;i++)
    {
        int op,x,y;
        fin>>op>>x>>y;
        if(op==1)
        {
            modifica(1,1,n,x,y);
        }else
        {
            fout<<interogare(1,1,n,x,y)<<endl;
        }
    }

    fin.close();
    fout.close();
    return 0;
}
