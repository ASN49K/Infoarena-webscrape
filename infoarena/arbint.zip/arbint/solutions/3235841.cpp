#include <fstream>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

int n, m, a, b, caz, AI[300010], maxim, poz, val;

void update(int nod, int st, int dr, int poz, int val)
{
    if (st == dr) {
        AI[nod] = val;
        return;
    }
    else {
        int mij = (st + dr) / 2;

        if (poz <= mij) {
            update(2 * nod, st, mij, poz, val);
        }
        else {
            update(2 * nod + 1, mij + 1, dr, poz, val);
        }
    }

    AI[nod] = max(AI[2 * nod], AI[2 * nod + 1]);
}

void query(int nod, int st, int dr, int &maxim, int a, int b)
{
    if (a <= st && dr <= b) {
        maxim = max(maxim, AI[nod]);
        return;
    }
    else {
        int mij = (st + dr) / 2;

        if (a <= mij) {
            query(2 * nod, st, mij, maxim, a, b);
        }

        if (b > mij) {
            query(2 * nod + 1, mij + 1, dr, maxim, a, b);
        }
    }
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= n; ++i) {
        f >> val;
        update(1, 1, n, i, val);
    }

    while (m--) {
        f >> caz >> a >> b;

        if (caz == 0) {
            maxim = 0;
            query(1, 1, n, maxim, a, b);

            g << maxim << '\n';
        }
        else if (caz == 1) {
            update(1, 1, n, a, b);
        }
    }

    return 0;
}
