import java.io.*;
import java.util.Scanner;

public class Main {

  private int[] tree;

  public Main(int N) {
    tree = new int[N+1];
  }

  public void build(int node, int left, int right, Scanner scanner) {
    if (left == right) {
      tree[node] = scanner.nextInt();
      return;
    }

    int mid = (left + right) >>> 1;
    build(2*node, left, mid, scanner);
    build(2*node+1, mid+1, right, scanner);
    tree[node] = Math.max(tree[2*node], tree[2*node+1]);
  }

  public void update(int node, int left, int right, int pos, int val) {
    if (left == right) {
      tree[node] = val;
      return;
    }

    int mid = (left + right) >>> 1;
    if (pos <= mid) {
      update(2*node, left , mid, pos, val);
    } else {
      update(2*node+1, mid+1, right, pos, val);
    }
    tree[node] = Math.max(tree[2*node], tree[2*node+1]);
  }

  public int query(int node, int left, int right, int a, int b) {
    if (a <= left && right <= b) {
      return tree[node];
    }

    int mid = (left + right) >>> 1;
    int leftMax = a <= mid ? query(2 * node, left, mid, a, b) : Integer.MIN_VALUE;
    int rightMax = mid < b ? query(2 * node + 1, mid+1, right, a, b) : Integer.MIN_VALUE;
    return Math.max(leftMax, rightMax);
  }

  public void print(int node, int left, int right, StringBuilder sb) {
    if (left == right) {
      sb.append("[leaf]:" + tree[node] + " ");
      return;
    }

    int mid = (left + right) >>> 1;
    print(2*node, left, mid, sb);
    print(2*node+1, mid+1, right, sb);
    sb.append("[internal]:" + tree[node] + " ");
  }


  public static void main(String[] args) throws FileNotFoundException {

    // new Scanner(new BufferedInputStream(new FileInputStream("arbint.in"))
    try (Scanner scanner = new Scanner(new BufferedInputStream(new FileInputStream("arbint.in")));
         PrintStream ps = new PrintStream(new BufferedOutputStream(new FileOutputStream("arbint.out")), true)) {
      int N = scanner.nextInt();
      int M = scanner.nextInt();

      int closestPowerOfTwo = 1;
      while (closestPowerOfTwo < N) {
        closestPowerOfTwo *= 2;
      }

      Main st = new Main(closestPowerOfTwo);
      st.build(1, 1, N, scanner);

      for (int i = 1; i <= M; i++) {
        int op = scanner.nextInt();
        switch (op) {
          case 0:
            ps.println(st.query(1, 1, N, scanner.nextInt(), scanner.nextInt()));
            break;
          case 1:
            int poz = scanner.nextInt();
            int val = scanner.nextInt();
            st.update(1, 1, N, poz, val);
            break;
        }
      }
    }
  }

}
