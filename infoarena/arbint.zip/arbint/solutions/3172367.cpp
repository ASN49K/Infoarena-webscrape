#include <bits/stdc++.h>
#define N 100000
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n,q,i,j,x,v[N],t,a,b;
void update(int b,int a,int st,int dr,int r)
{
    if(st==dr)
    {
        v[r]=b;
        return;
    }
    int mid=(st+dr)>>1;
    if(a<=mid) update(b,a,st,mid,r*2);
    else update(b,a,mid+1,dr,r*2+1);
    v[r]=max(v[2*r],v[2*r+1]);
}
int query(int qst,int qdr,int st,int dr,int r)
{
    if(qst==st && qdr==dr)
    {
        return v[r];
    }
    int mid=(st+dr)>>1;
    if(qdr<=mid) return query(qst,qdr,st,mid,r*2);
    else if(qst>mid) return query(qst,qdr,mid+1,dr,r*2+1);
    return max(query(qst,mid,st,mid,r*2),query(mid+1,qdr,mid+1,dr,r*2+1));
}
int main()
{
    fin>>n>>q;
    for(i=1;i<=n;++i)
    {
        fin>>x;
        update(x,i,1,n,1);
    }
    for(i=1;i<=q;++i)
    {
        fin>>t>>a>>b;
        if(t==1)
        {
            update(b,a,1,n,1);
        }
        else
        {
            fout<<query(a,b,1,n,1)<<'\n';
        }
    }
    return 0;
}
