﻿#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

int n, m;
vector<long long>a;

void build(int nod, int st, int dr) {
	if (st == dr) {
		in >> a[nod];
		return;
	}
	int mid = (st + dr) / 2;
	build(nod * 2, st, mid);
	build(nod * 2 + 1, mid + 1, dr);
	a[nod] = max(a[nod * 2], a[nod * 2 + 1]);
}

void update(int nod, int st, int dr, int x, int y) {
	if (st == dr) {
		a[nod] = y;
		return;
	}
	int mid = (st + dr) / 2;
	if(x<=mid) {
		update(nod * 2, st, mid, x, y);
	} else {
		update(nod * 2 + 1, mid + 1, dr, x, y);
	}
	a[nod] = max(a[nod * 2] , a[nod * 2 + 1]);
}

int query(int nod, int st, int dr, int x, int y) {
	if (st > y || dr < x) {
		return 0;
	}
	if (st >= x && dr <= y) {
		return a[nod];
	}
	int mid = (st + dr) / 2;
	return max(query(nod * 2, st, mid, x, y), query(nod * 2 + 1, mid + 1, dr, x, y));
}

int main()
{
	in >> n >> m;
	a.resize(2*n);
	build(1, 1, n);
	for(int i=1;i<=m;i++) {
		int q, x, y;
		in >> q >> x >> y;
		if (q == 1) {
			update(1, 1, n, x, y);
		} else {
			out << query(1, 1, n, x, y) << "\n";
		}
	}
	return 0;
}
