#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

int n, v[100005], a[200005];

void tom(int nod, int st, int dr){
    if(st == dr){
        a[nod] = v[st];
        return;
    }
    int mij = (st + dr) / 2, stc = nod + 1, drc = 2 * (mij - st + 1) + nod;
    tom(stc, st, mij);
    tom(drc, mij + 1, dr);
    a[nod] = max(a[stc], a[drc]);
}
void update(int nod, int st, int dr, int poz, int val){
    if(st == dr){
        a[nod] = val;
        return;
    }
    int mij = (st + dr) / 2, stc = nod + 1, drc = 2 * (mij - st + 1) + nod;
    if(poz <= mij){
        update(stc, st, mij, poz, val);
    }
    else{
        update(drc, mij + 1, dr, poz, val);
    }
    a[nod] = max(a[stc], a[drc]);
}
int jerry(int nod, int st, int dr, int stj, int drj){
    if(stj <= st && drj >= dr){
        return a[nod];
    }
    int mij = (st + dr) / 2, rez = 0, stc = nod + 1, drc = nod + 2 * (mij - st + 1);
    if(stj <= mij){
        rez = jerry(stc, st, mij, stj, drj);
    }
    if(drj > mij){
        rez = max(jerry(drc, mij + 1, dr, stj, drj), rez);
    }
    return rez;
}

int main()
{
    int m, i, cer, a, b;
    in >> n >> m;
    for(i = 0; i < n; i++){
        in >> v[i];
    }
    tom(0, 0, n - 1);
    for(i = 1; i <= m; i++){
        in >> cer >> a >> b;
        if(cer == 0){
            out << jerry(0, 0, n - 1, a - 1, b - 1) << '\n';
        }
        else{
            update(0, 0, n - 1, a - 1, b);
        }
    }
    return 0;
}
