#include <fstream>
#include <cmath>

using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

const int N = 1e5;
int v[4 * N], ans;

void update(int poz, int number){
    v[poz] = number;
    for(int i = poz / 2; i > 0; i--){
        v[i] = max(v[2 * i], v[2 * i + 1]);
    }
}

void query(int st_cautare, int dr_cautare, int st_crt, int dr_crt, int nod_crt){
    if(st_crt > dr_cautare or dr_crt < st_cautare)
        return;
    if(st_cautare <= st_crt and dr_crt <= dr_cautare) {
        ans = max(ans, v[nod_crt]);
        return;
    }
    int mij = (st_crt + dr_crt) / 2;
//    cout << nod_crt << ' ' << st_crt << ' ' << dr_crt << '\n';
//    if(dr_crt >= dr_cautare)
    query(st_cautare, dr_cautare, st_crt, mij, 2 * nod_crt);
//    if(st_crt <= st_cautare)
    query(st_cautare, dr_cautare, mij + 1, dr_crt, 2 * nod_crt + 1);
}

int main() {
    int operatii, nr_frunze_date;
    /// nr_noduri = nr total de elemente, nr_frunze_date
    cin >> nr_frunze_date >> operatii;
    int aux = log2(nr_frunze_date), nr_frunze_total = nr_frunze_date;
    if((1 << aux) != nr_frunze_date)
        nr_frunze_total = 1 << (aux + 1);
    int nr_noduri = 2 * nr_frunze_total - 1;
    ///read
    for (int i = 1; i <= nr_frunze_date; ++i)
        cin >> v[nr_noduri - nr_frunze_total + i];
    ///build
    for(int i = nr_noduri - nr_frunze_total; i > 0; i--)
        v[i] = max(v[2 * i], v[2 * i + 1]);
//    for (int i = 1; i <= nr_noduri; ++i) {
//        cout << v[i] << ' ';
//    }
    for (int i = 0; i < operatii; ++i) {
        bool cer;
        int a, b;
        cin >> cer >> a >> b;
        if(cer)
            update(nr_noduri - nr_frunze_total + a, b);
        else{
            ans = 0;
            query(a, b, 1, nr_frunze_total, 1);
//            for (int i = 1; i <= nr_noduri; ++i) {
//                cout << v[i] << ' ';
//            }
            cout << ans << '\n';
        }
    }
//    for (int i = 1; i <= nr_noduri; ++i) {
//        cout << v[i] << ' ';
//    }
    return 0;
}