#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,q;
int A[100005];
int aint[200005];
void build(int node,int st,int dr)
{
    if(st==dr)
    {
        aint[node]=A[st];
        return;
    }
    int mij=(st+dr)>>1;
    build(node+1,st,mij);
    build(node+2*(mij-st+1),mij+1,dr);
    aint[node]=max(aint[node+1],aint[node+2*(mij-st+1)]);
}
void update(int node,int st,int dr,int x,int v)
{
    if(st==dr)
    {
        aint[node]=v;
        return;
    }
    int mij=(st+dr)>>1;
    if(x<=mij)
        update(node+1,st,mij,x,v);
    else
        update(node+2*(mij-st+1),mij+1,dr,x,v);
    aint[node]=max(aint[node+1],aint[node+2*(mij-st+1)]);
}
int query(int node,int st,int dr,int x,int y)
{
    if(st>=x && dr<=y)
        return aint[node];
    if(st>y || dr<x)
        return 0;
    int mij=(st+dr)>>1;
    int l=query(node+1,st,mij,x,y);
    int r=query(node+2*(mij-st+1),mij+1,dr,x,y);
    return max(l,r);
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>A[i];
    build(1,1,n);
    while(q--)
    {
        int op,x,y;
        cin>>op>>x>>y;
        if(op==0)
            cout<<query(1,1,n,x,y)<<"\n";
        else
            update(1,1,n,x,y);
    }
    return 0;
}
