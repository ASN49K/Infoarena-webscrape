#include <iostream>
#define dim 100001

using namespace std;

int arr[4 * dim];

void query(int nod, int left, int right, int start, int finish, int *maxim){
    if ( start <= left && right <= finish ){
        if (*maxim < arr[nod] ) *maxim = arr[nod];
        return;
    }

    int div = (left+right)/2;
    if ( start <= div ) query(2 * nod, left, div, start, finish, maxim);
    if ( div < finish ) query(2 * nod + 1, div + 1, right, start, finish, maxim);
}

int cmp(int a, int b) {
    if ( a > b ) return a;
    return b;
}

void update(int nod, int left, int right, int Pos, int Val){
    if ( left == right ){
        arr[nod] = Val;
        return;
    }

    int div = (left+right)/2;
    if ( Pos <= div ) update(2 * nod, left, div, Pos, Val);
    else update(2 * nod + 1, div + 1, right, Pos, Val);

    arr[nod] = cmp(arr[2 * nod], arr[2 * nod + 1]);
}

int main()
{
    int x, a, b,maxim,n,m;
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);

    cin >> n >> m;
    for (int i = 1; i <= n; i++ ){
        cin >> x;
        update(1, 1, n, i, x);
    }

    for (int i = 1; i <= m; i++ ){
        cin >> x >> a >> b;
        if (x == 0 ){
            maxim = 0;
            query(1, 1, n, a, b, &maxim);

            cout << maxim << endl;
        }
        else update(1, 1, n, a, b);
    }
}
