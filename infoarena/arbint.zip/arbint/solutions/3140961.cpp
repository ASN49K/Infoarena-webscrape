#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("fisier.in");
ofstream fout("fisier.out");

int n, m, a, b, minim, v[400001], citire[400001], maxim;

void build(int nod, int st, int dr) {
    if (st == dr)
        v[nod] = citire[st]; // alternativ putem citi direct de aici v[nod]
    else {
        int mij = (st + dr) / 2;
        build(nod * 2, st, mij);
        build(nod * 2 + 1, mij + 1, dr);
        v[nod] = max(v[nod * 2], v[nod * 2 + 1]);
    }
}

void update(int nod, int st, int dr, int poz, int val) {
    if (st == dr)
        v[nod] = val;
    else {
        int mij = (st + dr) / 2;
        if (poz <= mij)
            update(nod * 2, st, mij, poz, val);
        else
            update(nod * 2 + 1, mij + 1, dr, poz, val);
        v[nod] = max(v[nod * 2], v[nod * 2 + 1]);
    }
}

void query(int nod, int st, int dr, int intst, int intdr) {
    if (intst <= st and dr <= intdr) {
        maxim = max(maxim, v[nod]);
        return;
    }
    else {
        int mij = (st + dr) / 2;
        if (intst <= mij)
            query(nod * 2, st, mij, intst, intdr);
        if (mij + 1 <= intdr)
            query(nod * 2 + 1, mij + 1, dr, intst, intdr);
    }
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
        fin >> citire[i];
    build(1, 1, n);
    for (int i = 1; i <= m; i++) {
        int t;
        fin >> t >> a >> b;
        if (t == 0) {
            maxim = -1;
            query(1, 1, n, a, b);
            fout << maxim << "\n";
        }
        else
            update(1, 1, n, a, b);
    }
    return 0;
}
