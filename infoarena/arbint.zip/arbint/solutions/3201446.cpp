#include <iostream>
#include <algorithm>
#include <fstream>
#include <cmath>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");

int n, m;

int nrbatog, lunbatog;
const int maxn = 1e5, maxnum = 1e3;
int batog[ maxnum + 1 ], v[maxn + 1];

void build()
{
    for( int i = 0; i < n; ++i )
    {
        batog[ i / lunbatog ] = max( batog[ i / lunbatog ], v[i] );
    }
}

void mymax ( int a, int b )
{
    --a;
    --b;
    ///pentru indexare de la 0
    int maxx = 0;
    int caregrupra_a = a / lunbatog;
    if( a % lunbatog == 0 )
    {
        maxx = max( maxx, v[ caregrupra_a * lunbatog ] );
    }
    else
    {
        for( int i = a % lunbatog; i < lunbatog; ++i )
        {
            maxx = max( maxx, v[ caregrupra_a * lunbatog + i ] );
        }
        ++caregrupra_a;
    }

    int caregrupra_b = b / lunbatog;
    if( b % lunbatog == 0 )
    {
        maxx = max( maxx, v[ caregrupra_b * lunbatog ] );
        --caregrupra_b;
    }
    else
    {
        cout << "Incepem de la " << b % lunbatog << '\n';
        for( int i = b % lunbatog; i >= 0; --i )
        {
            maxx = max( maxx, v[ caregrupra_b * lunbatog + i ] );
        }
        --caregrupra_b;
    }
    for( int i = caregrupra_a; i <= caregrupra_b; ++i )
    {
        maxx = max( maxx, batog[ i ] );
        cout << "batog [" << i << "] " << batog[i] << '\n';
    }
    cout << "pe intervalul initial " << a << ", " << b << " -> " << maxx << " este pe intervalul modificat fara capete: (" << caregrupra_a << ", " << caregrupra_b << ")\n";
    g << maxx << '\n';
}

void myupdate( int a, int b )
{
    --a;///pentru indexare de la 0
    int caregrupa = a/lunbatog;
    cout << a << " este in grupa " << caregrupa << '\n';
    if( batog[ caregrupa ] <= b )
    {
        batog[ caregrupa ] = b;
    }
    v[a] = b;
    int maxx = 0;
    for( int i = 0; i < lunbatog; ++i )
    {
        cout << " avem i pe " << i << '\n';
        maxx = max( maxx, v[ caregrupa * lunbatog + i ] );
    }
    batog[ caregrupa ] = maxx;
    cout << "Am gasit pentru " << caregrupa << " " << maxx << '\n';
}

int main() {
    ios_base::sync_with_stdio(false);
    f.tie(nullptr);
    g.tie(nullptr);

    f >> n >> m;
    for( int i = 0; i < n; ++i )
    {
        f >> v[i];
    }
    lunbatog = sqrt( n );
    nrbatog = n / lunbatog;
    cout << "lunbatog : " << lunbatog << '\n';
    cout << "nrbatog : " << nrbatog << '\n';
    build();
    for( int i = 1; i <= m; ++i )
    {
        int o, a, b;
        f >> o >> a >> b;
        if( o == 0 )
        {
            mymax( a, b );
        }
        else
        {
            myupdate( a, b );
        }
        
    }
    return 0;
}