#include <bits/stdc++.h>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int n, m, p, v[100005], a[1005];

int find (int x)
{
    return (x+p-1)/p;
}

void read ()
{
    fin >> n >> m;
    p=floor(sqrt(n));
    for (int i=1; i<=n; i++)
    {
        fin >> v[i];
        a[find(i)]=max(a[find(i)],v[i]);
    }
}

int task1 (int x, int y)
{
    int Max=-1;
    if (find(x)==find(y))
    {
        for (int j=x; j<=y; j++)
            Max=max(Max,v[j]);
    }
    else
    {
        for (int j=x; find(j)==find(x); j++)
            Max=max(Max,v[j]);
        for (int j=find(x)+1; j<=find(y)-1; j++)
            Max=max(Max,a[j]);
        for (int j=y; find(j)==find(y); j--)
            Max=max(Max,v[j]);
    }
    return Max;
}

void task2 (int x, int y)
{
    v[x]=y;
    a[find(x)]=0;
    for (int j=x; find(j)==find(x); j--)
        a[find(x)]=max(a[find(x)],v[j]);
    for (int j=x+1; find(j)==find(x); j++)
        a[find(x)]=max(a[find(x)],v[j]);
}

int main()
{
    read();
    for (int i=1; i<=m; i++)
    {
        int t, x, y;
        fin >> t >> x >> y;
        if (t==0)
            fout << task1(x,y) << '\n';
        else
            task2(x,y);
    }
    return 0;
}
