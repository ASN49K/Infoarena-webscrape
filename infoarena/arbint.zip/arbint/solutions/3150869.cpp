#include <fstream>
using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

struct Arbint {
    int n;
    int *v;

    Arbint(int n) : n(n) {
        v=new int[4*n+1];
        for(int i=0;i<=2*n;i++)
            v[i]=-1;
    }
    ~Arbint() { delete[] v; }

    void update(int i, int x, int node, int st, int dr)
    {

        if(st==dr)
        {
            v[node]=x;
            return;
        }

        int mid=(st+dr)/2;

        if(i<=mid)
            update(i, x, 2*node, st, mid);
        else
            update(i, x, 2*node+1, mid+1, dr);

        v[node]=max(v[2*node], v[2*node+1]);
    }

    int getmax(int a, int b, int node, int st, int dr)
    {
        if(st==dr||a<=st&&b>=dr)
            return v[node];

        int mid=(st+dr)/2;

        int x=-1, y=-1;
        if(a<=mid)
            x=getmax(a, min(mid, b), 2*node, st, mid);
        if(b>mid)
            y=getmax(max(a, mid+1), b, 2*node+1, mid+1, dr);

        return max(x, y);
    }
};


int main() {

    int n, m;
    in>>n>>m;
    Arbint arb(n);

    for(int i=1;i<=n;i++)
    {
        int x;
        in>>x;
        arb.update(i, x, 1, 1, n);
    }

    while(m)
    {
        int c;
        in>>c;
        if(c==0)
        {
            int a, b;
            in>>a>>b;
            out<<arb.getmax(a, b, 1, 1, n)<<'\n';
        }
        else
        {
            int i, x;
            in>>i>>x;
            arb.update(i, x, 1, 1, n);
        }

        m--;
    }

    return 0;
}
