#include <bits/stdc++.h>

using namespace std;

ifstream f ("arbint.in");
ofstream g ("arbint.out");

const int NMAX = 1e5;

int v[NMAX+1], aint[4 * NMAX + 4];

void update(int nod, int st, int dr, int poz, int val){
    
    if(st == dr){
        
        aint[nod] = val;
        
        return;
        
    }
    
    int mij = (st + dr)/2;
    
    if(poz <= mij)
        update(2 * nod, st, mij, poz, val);
        
    else update(2 * nod + 1, mij + 1, dr, poz, val);
    
    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
    
}

int query(int nod, int st, int dr, int sti, int dri){
    
    
    if(st == sti and dr == dri)
        return aint[nod];
        
    int mij = (st + dr)/2;
    
    if(dri <= mij)
        return query(nod * 2, st, mij, sti, dri);
    
    if(sti > mij)
        return query(nod * 2 + 1, mij + 1, dr, sti, dri);
        
    return max(
        query(nod * 2, st, mij, sti, mij),
        query(nod * 2 + 1, mij + 1, dr, mij + 1, dri)
        );
        
        
    
}

int main()
{
    
    int n, q;
    
    f >> n >> q;
    
    for(int i=1; i<=n; i++){
        
        f >> v[i];
        
        update(1, 1, n, i, v[i]);
        
    }
    
    for(int i=1; i<=q; i++){
        
        int t, x, y;
        f >> t >> x >> y;
        
        if(t == 0)
            g << query(1, 1, n, x, y) << "\n";
            
        else update(1, 1, n, x, y);
        
    }
    
    
    

    return 0;
}