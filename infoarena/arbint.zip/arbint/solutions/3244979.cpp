#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;



ifstream fin("aint.in");
ofstream fout("aint.out");

int v[400005];
int a[100005];
int n, m;

void build(int nod, int st, int dr) {
    if (st == dr) {
        v[nod] = a[st];
        return;
    }
    int mij = (st + dr) / 2;
    build(2 * nod, st, mij);
    build(2 * nod + 1, mij + 1, dr);
    v[nod] = max(v[2 * nod], v[2 * nod + 1]);
}

int query(int nod, int st, int dr, int a, int b) {
    if (a > dr || b < st) return INT_MIN;  
    if (a <= st && dr <= b) return v[nod];  

    int mij = (st + dr) / 2;
    return max(query(2 * nod, st, mij, a, b), query(2 * nod + 1, mij + 1, dr, a, b));  
}

void update(int nod, int st, int dr, int el, int val) {
    if (st == dr) {
        v[nod] = val;  
        a[st] = val;   
        return;
    }
    int mij = (st + dr) / 2;
    if (el <= mij) {
        update(2 * nod, st, mij, el, val);
    } else {
        update(2 * nod + 1, mij + 1, dr, el, val);
    }
    v[nod] = max(v[2 * nod], v[2 * nod + 1]);  
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= n; i++) {
        fin >> a[i];  
    }
    build(1, 1, n);
    for (int i = 1; i <= m; i++) {
        int c;
        fin >> c; 
        if (!c) {
            int x, y;
            fin >> x >> y;
            fout << query(1, 1, n, x, y) << '\n';
        } else {
            int x, y;
            fin >> x >> y;
            update(1, 1, n, x, y);
        }
    }

    return 0;
}
