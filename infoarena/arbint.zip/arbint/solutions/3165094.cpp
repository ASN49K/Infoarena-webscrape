#include <bits/stdc++.h>

using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");
const int NMAX = 100000;
int arb[4*NMAX], v[NMAX];
void update( int poz_arb ){
    if( poz_arb < 1 )
        return ;
    arb[poz_arb] = max( arb[poz_arb*2], arb[poz_arb*2+1] );
    update( poz_arb / 2);
}
int query( int capat_st, int capat_dr, int st, int dr, int poz ){
    if( capat_st > dr || capat_dr < st )
        return 0;
    if( capat_st >= st && capat_dr <= dr )
        return arb[poz];
    int mij = ( capat_st + capat_dr ) / 2;
    return max( query( capat_st, mij, st, dr, poz * 2 ),
               query( mij+1, capat_dr, st, dr, poz * 2 + 1) );
}

int main()
{
    int n, m;
    in >> n >> m;
    int log2n = log2(n);
    log2n += ((1 << log2n) < n);
    int size_ = 1 << log2n;
    for( int i = 1; i <= n; i++ ){
        in >> v[i];
        arb[i + size_ - 1] = v[i];

    }
    for( int i = size_; i < size_ + n; i++ )
        update(i/2);
//    for( int i = 1; i < size_ * 2; i++ )
//        out << arb[i] << " ";
    for( int i = 0; i < m; i++ ){
        int cerinta, a, b;
        in >> cerinta >> a >> b;
        if( !cerinta )
            out << query( 1, size_, a, b, 1) << "\n";
        else{
            int poz = size_ + a - 1;
            arb[poz]  = b;
            update( poz/2 );
        }
    }
    return 0;
}
