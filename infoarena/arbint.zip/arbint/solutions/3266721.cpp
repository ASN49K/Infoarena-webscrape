#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e5+2;
int n,q,v[NMAX];

ifstream fin("arbint.in");
ofstream fout("arbint.out");

struct SegTree {
  int n;
  vector<int> aint;
  SegTree(){}
  SegTree(int _n){
    n = _n;
    aint.resize(4*n+1);
  }
  void build(int nod, int st, int dr){
    if(st == dr){
      aint[nod] = v[st];
    }else{
      int mid = (st+dr)/2;
      build(2*nod, st, mid);
      build(2*nod+1, mid+1, dr);
      aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
  }
  int query(int nod, int st, int dr, int l, int r){
    if(l <= st && dr <= r){
      return aint[nod];
    }else{
      int ans = 0, mid = (st+dr)/2;
      if(l <= mid){
        ans = max(ans, query(2*nod, st, mid, l, r));
      }
      if(r >= mid+1){
        ans = max(ans, query(2*nod+1, mid+1, dr, l, r));
      }
      return ans;
    }
  }
  void update(int nod, int st, int dr, int pos, int val){
    if(st == dr){
      aint[nod] = val;
    }else{
      int mid = (st+dr)/2;
      if(pos <= mid){
        update(2*nod, st, mid, pos, val);
      }else{
        update(2*nod+1, mid+1, dr, pos, val);
      }
      aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
  }
};

int main() {
  fin >> n >> q;
  for(int i = 1; i <= n; i++){
    fin >> v[i];
  }
  SegTree aint(n);
  aint.build(1, 1, n);
  for(int i = 1; i <= q; i++){
    int t, a, b;
    fin >> t >> a >> b;
    if(t == 0){
      fout << aint.query(1, 1, n, a, b) << "\n";
    }else{
      aint.update(1, 1, n, a, b);
    }
  }
  return 0;
}
