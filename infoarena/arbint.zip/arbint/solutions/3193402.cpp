#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

const int NMAX = 100002, inf = 0x3f3f3f3f;
int n, m, sol = inf, tree[4*NMAX];

void update(int poz, int el, int nod = 1, int st = 1, int dr = n)
{
    if (st == dr)
    {
        tree[nod] = el;
        return;
    }

    int mijl = (st + dr) / 2;
    if (poz <= mijl) update(poz, el, 2 * nod, st, mijl);
    if (poz > mijl) update(poz, el, 2 * nod + 1, mijl + 1, dr);

    tree[nod] = max(tree[2*nod], tree[2*nod+1]);
}

void query(int a, int b, int nod = 1, int st = 1, int dr = n)
{
    if (a <= st && dr <= b)
    {
        sol = max(sol, tree[nod]);
        return;
    }

    int mijl = (st + dr) / 2;
    if (a <= mijl)
        query(a, b, 2 * nod, st, mijl);
    if (b > mijl)
        query(a, b, 2 * nod + 1, mijl + 1, dr);
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        update(i, x);
    }

    for (int i = 1; i <= m; i++)
    {
        int c, a, b;
        fin >> c >> a >> b;

        if (c == 0)
        {
            sol = 0;
            query(a, b);
            fout << sol << "\n";
        }
        if (c == 1)
            update(a, b);
    }
    return 0;
}
