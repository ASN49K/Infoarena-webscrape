#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    ifstream f1("../arbint.in");
    ofstream f2("../arbint.out");

    int N, M;
    f1 >> N >> M;

    vector<int> vector_elemente(N);
    for (int i = 0; i < N; i++) {
        f1 >> vector_elemente[i];
    }

    while (M--) {
        int tip, a, b;
        f1 >> tip >> a >> b;

        if (tip == 0) {
            int valoare_max = *max_element(vector_elemente.begin() + a - 1, vector_elemente.begin() + b);
            f2 << valoare_max << endl;
        } else if (tip == 1) {
            vector_elemente[a - 1] = b;
        }
    }

    f1.close();
    f2.close();

    return 0;
}
