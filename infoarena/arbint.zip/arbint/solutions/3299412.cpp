#include <bits/stdc++.h>
using namespace std;
#define MAX 100009

int V[MAX], tree[MAX];

ifstream f("arbint.in");
ofstream g("arbint.out");

void build(int node, int l, int r) {
    if (l == r) {
        tree[node] = V[l];
        return;
    }
    int mid = (l + r) / 2;
    build(2 * node, l, mid);
    build(2 * node + 1, mid + 1, r);

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}
void update(int node, int l, int r, int pos, int val) {
    if (l == r) {
        tree[node] = val;
        return;
    }

    int mid = (l + r) / 2;

    if (pos <= mid) {
        update(2 * node, l, mid, pos, val);
    } else {
        update(2 * node + 1, mid + 1, r, pos, val);
    }

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void query(int node, int l, int r, int x, int y, int &ans) {
    if (x <= l && r <= y) {
        ans = max(ans, tree[node]);
        return;
    }

    int mid = (l + r) / 2;

    if (x <= mid) {
        query(2 * node, l, mid, x, y, ans);
    }
    if (y > mid) {
        query(2 * node + 1, mid + 1, r, x, y, ans);
    }
}
int main() {
    int n, m;
    f >> n >> m;
    for (int i = 1; i <= n; i++) {
        f >> V[i];
    }
    build(1, 1, n);
    while (m--) {
        int o, a, b, ans = INT_MIN;
        f >> o >> a >> b;
        if (o == 0) {
            query(1, 1, n, a, b, ans);
            g << ans << '\n';
        } else {
            update(1, 1, n, a, b);
        }
    }
    return 0;
}