#include <bits/stdc++.h>
using namespace std;
//ifstream  in("arbint.in");
//ofstream  out("arbint.out");
const int MAXN=100000+1;
int n,t[4*MAXN],arr[MAXN],i,cod,x,y,k;


void build(int a[], int v, int tl, int tr) {
    if (tl == tr) {
        t[v] = a[tl];
    } else {
        int tm = (tl + tr) / 2;
        build(a, v*2, tl, tm);
        build(a, v*2+1, tm+1, tr);
        t[v] = max(t[v*2],t[v*2+1]);
    }
}

int sum(int v, int tl, int tr, int l, int r) {
    if (l > r) 
        return 0;
    if (l == tl && r == tr) {
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return max(sum(v*2, tl, tm, l, min(r, tm)),sum(v*2+1, tm+1, tr, max(l, tm+1), r));
}

void update(int v, int tl, int tr, int pos, int new_val) {
    if (tl == tr) {
        t[v] = new_val;
    } else {
        int tm = (tl + tr) / 2;
        if (pos <= tm)
            update(v*2, tl, tm, pos, new_val);
        else
            update(v*2+1, tm+1, tr, pos, new_val);
        t[v] = max(t[v*2],t[v*2+1]);
    }
}

int main()
{
	freopen("arbint.in","r",stdin);
	freopen("arbint.out","w",stdout);
	cin >> n >> k ;
	for (i=0;i<n;i++)cin>>arr[i];
	build(arr,1,0,n-1);
	for (i=1;i<=k;i++)
	{
		cin >> cod >> x >>y ;
		if (cod==0)
		{
			cout << sum(1,0,n-1,x-1,y-1)<<"\n";
		}
		else 
		{
			update(1,0,n-1,x-1,y-1);
		}
	}
    return 0;
}
