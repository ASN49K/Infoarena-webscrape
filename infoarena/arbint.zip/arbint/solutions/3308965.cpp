#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
const int NMAX = 1e6 + 5;
const int NAINT = 4 * NMAX;
long long aint[NAINT];
void update(int poz,int val,int node,int st,int dr)
{
    if(st==dr)
    {
        aint[node]=val;
        return;
    }
    int mij=st+(dr-st)/2;
    if(poz<=mij)
    {
        update(poz,val,2*node,st,mij);
    }
    else update(poz,val,2*node+1,mij+1,dr);
    aint[node]=max(aint[2*node],aint[2*node+1]);
}
long long  query(int a,int b,int node,int st,int dr)
{
    if(b<st || a>dr)return 0;
    if(st>=a && dr<=st)
    {
        return aint[node];
    }
    int mij=st+(dr-st)/2;
    long long  x=query(a,b,2*node,st,mij);
    long long y=query(a,b,2*node+1,mij+1,dr);
    return max(x,y); 
}
int main()
{
    ios::sync_with_stdio(false);
    fin.tie(nullptr);
    int n, q;
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin>>x;
        update(i,x,1,1,n);
    }
    while(q--)
    {
        int op,st,dr;
        fin>>op>>st>>dr;
        if(op){update(st,dr,1,1,n);}
        else fout<<query(st,dr,1,1,n)<<'\n';
    }
}