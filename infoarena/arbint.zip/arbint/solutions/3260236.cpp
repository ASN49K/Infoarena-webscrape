#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

#define NMAX 4 * 100005

int v[NMAX];
int maxim;

void update(int nod, int st, int dr, int poz, int val) {
    if (st == dr) {
        v[nod] = val;
    } else {
        int mij = (st + dr) / 2;
        if (poz <= mij) {
            update(2 * nod, st, mij, poz, val);
        } else {
            update(2 * nod + 1, mij + 1, dr, poz, val);
        }
        v[nod] = max(v[2 * nod], v[2 * nod + 1]);
    }
}

void query(int nod, int st, int dr, int a, int b) {
    if (a <= st && dr <= b) {
        maxim = max(maxim, v[nod]);
    } else {
        int mij = (st + dr) / 2;
        if (a <= mij) {
            query(2 * nod, st, mij, a, b);
        }
        if (b > mij) {
            query(2 * nod + 1, mij + 1, dr, a, b);
        }
    }
}

int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        int x;
        fin >> x;

        update(1, 1, n, i, x);
    }

    while (m--) {
        int op, a, b;
        fin >> op >> a >> b;

        if (op == 0) {
            maxim = -1;

            query(1, 1, n, a, b);

            fout << maxim << '\n';
        } else {
            update(1, 1, n, a, b);
        }
    }
    return 0;
}
