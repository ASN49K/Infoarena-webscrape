#include <iostream>
#include <fstream>
#include <math.h>

#define NMAX 100001

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, v[NMAX], sq, noIntervals, batog[401], interval;

void build_batog(){
    for(int i=0;i<n;i++){
      int j=i/sq;
      if(v[i]>batog[j])
        batog[j]=v[i];
    }
}

int query(int left, int right){
    int firstInterval = (left + sq - 1) / sq * sq;
    int lastInterval = right / sq * sq;
    int el_max=0;
    //cout<<firstInterval<<" "<<lastInterval<<"\n";
    while(left<=right&&left<firstInterval)
      el_max=std::max(el_max, v[left++]);
    while(right>=left&&right>= lastInterval)
      el_max=std::max(el_max, v[right--]);

    firstInterval/=sq;
    lastInterval/=sq;

    while(firstInterval<=lastInterval)
      el_max=std::max(el_max, batog[firstInterval++]);

    return el_max;
}

int main()
{
    fin>>n>>m;
    sq=sqrt(n);
    noIntervals=(n+sq-1)/sq;

    for(int i=1;i<=n;i++)
      fin>>v[i];

    build_batog();

    int operatie, e1, e2;
    for(int i=0;i<m;i++){
      fin>>operatie>>e1>>e2;
      if(!operatie){
        fout<<query(e1, e2)<<"\n";
      }
      else{
          if(v[e1]!=batog[e1/sq]){
            v[e1]=e2;
            interval=e1/sq;
            if(e2>batog[interval])
              batog[interval]=e2;
          }
          else{
            v[e1]=e2;
            interval=e1/sq;
            int start=interval*sq;
            int end=(interval+1)*sq-1;
            batog[interval]=0;
            for(int i=start;i<=end;i++){
              if(v[i]>batog[interval])
                batog[interval]=v[i];
            }
          }
      }
    }


    return 0;
}
