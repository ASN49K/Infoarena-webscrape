#include <bits/stdc++.h>
using namespace std;
int aint[400005];
int n,m;

void update(int node, int l, int r, int poz, int val)
{
    if(l==r)
    {
        aint[node]=val;
        return;
    }
    int mij=(l+r)/2;
    if(poz<=mij)
    {
        update(node*2,l,mij,poz,val);
    }
    else
    {
        update(node*2+1,mij+1,r,poz,val);
    }
    aint[node]=max(aint[node*2],aint[node*2+1]);
}
int query(int node, int l, int r, int ql, int qr)
{
    int maxx=0;
    if(ql<=l&&r<=qr)
        return aint[node];
    int mij=(l+r)/2;
    if(ql<=mij)
    {
        int nr=query(node*2,l,mij,ql,qr);
        maxx=max(maxx,nr);
    }
    if(mij+1<=qr)
    {
        int nr=query(node*2+1,mij+1,r,ql,qr);
        maxx=max(maxx,nr);
    }
    return maxx;
}

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    cin>>n>>m;
    for(int i=1;i<=n;++i)
    {
        int a;cin>>a;
        update(1,1,n,i,a);
    }
    //for(int i=1;i<=n;++i)
        //cout<<aint[i]<<" ";
    //cout<<'\n';
    for(int i=1;i<=m;++i)
    {
        int op,a,b;cin>>op>>a>>b;
        if(op==1)
        {
            update(1,1,n,a,b);
        }
        else
        {
            cout<<query(1,1,n,a,b)<<'\n';
        }
    }
}