#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, task, a, b;
int v[100001], arb[400004];
int i, j;

void build(int nod, int st, int dr){
    if(st==dr)
        arb[nod]=v[st];
    else{
        int mij=(st+dr)/2;
        build(nod*2, st, mij);
        build(nod*2+1, mij+1, dr);
        arb[nod]=max(arb[nod*2], arb[nod*2+1]);
    }
}

void update(int nod, int st, int dr, int poz, int val){
    if(st==dr)
        arb[nod]=val;
    else{
        int mij=(st+dr)/2;
        if(poz<=mij)
            update(nod*2, st, mij, poz, val);
        else
            update(nod*2+1, mij+1, dr, poz, val);
        arb[nod]=max(arb[nod*2], arb[nod*2+1]);
    }
}

int query(int nod, int st, int dr, int qst, int qdr){
    if(qst<=st && dr<=qdr)
        return arb[nod];
    else{
        int mij=(st+dr)/2;
        if(qdr<=mij)
            return query(nod*2, st, mij, qst, qdr);
        if(qst>mij)
            return query(nod*2+1, mij+1, dr, qst, qdr);
        return max(query(nod*2, st, mij, qst, qdr), query(nod*2+1, mij+1, dr, qst, qdr));
    }
}

int main(){
    fin>>n>>m;
    for(i=1; i<=n; i++)
        fin>>v[i];
    build(1, 1, n);
    for(i=1; i<=m; i++){
        fin>>task>>a>>b;
        if(task==0)
            fout<<query(1, 1, n, a, b)<<"\n";
        if(task==1)
            update(1, 1, n, a, b);
    }
    return 0;
}
