#include <bits/stdc++.h>

using namespace std;
ifstream fin ("arbint.in");
ofstream fout ("arbint.out");
int n,q,aint[400005],maxim, op,a,b;
void build (int nod, int st, int dr)
{
    if (st==dr) fin>>aint[nod];
    else
    {
        int mij=(st+dr)/2;
        build (2*nod,st,mij);
        build (2*nod+1,mij+1,dr);
        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}
void update (int nod,int st, int dr, int poz, int val)
{
    if (st==dr) aint[nod]=val;
    else
    {
        int mij=(dr+st)/2;
        if (poz<=mij)
            update (2*nod,st,mij,poz,val);
        else update (2*nod+1,mij+1,dr,poz,val);
        aint [nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}
/*void query (int nod, int st, int dr, int a, int b)
{
    if (a<=st && dr<=b) maxim=max(maxim, aint[nod]);
    else
        {
            int mij=(st+dr)/2;
            if (a<=mij)
                query(2*mij,st,mij,a,b);
            if (b>mij) query (2*mij+1,mij+1,dr,a,b);
        }
}*/
int query(int nod,int st,int dr,int a,int b)
{int x1=0,x2=0;
 if(a<=st && b>=dr)
    return aint[nod];
 else
 {int m=(st+dr)/2;
  if(a<=m)
    x1=query(2*nod,st,m,a,b);
  if(b>m)
    x2=query(2*nod+1,m+1,dr,a,b);
  return max(x1,x2);
 }
}
int main()
{
    fin>>n>>q;
    build (1,1,n);
    while (q--)
    {
        fin>>op>>a>>b;
        if (op==0)
        {
            fout<<query (1,1,n,a,b)<<'\n';
        }
        else
        {
            update (1,1,n,a,b);
        }
    }
    return 0;
}
