#include <fstream>
#include <math.h>
#include <algorithm>
#define MAX_N 100001

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int v[MAX_N], n, m, op, a, b,result;

int main() {
    fin>>n>>m;
    for (int i = 1; i <= n; i++)
        fin>>v[i];
    while (m--)
	{
        fin>>op>>a>>b;
		if (op == 0)
		{
			result=0;
			while (a <= b)
        		result = max(result,v[a++]);
			fout<<result<<'\n';
		}
        if (op == 1)
            v[a]=b;
    }
    return 0;
}
