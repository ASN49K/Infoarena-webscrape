#include <fstream>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n, q, arbore[1000005];
void update(int pozitie, int valoare, int st= 1, int dr = n, int nod = 1)
{
    if(st == dr)
    {
        arbore[nod] = valoare;
        return;
    }
    int mijloc  = (st + dr) / 2;
    if(mijloc >= pozitie)
    {
        update(pozitie, valoare, st, mijloc, nod*2);
    }
    else
    {
        update(pozitie, valoare, mijloc + 1, dr, (nod*2) + 1);
    }
    arbore[nod] = max(arbore[nod*2], arbore[nod*2 + 1]);
}
int show_max(int st_prim, int dr_prim, int st = 1, int dr = n, int nod = 1)
{
    if(st_prim <= st && dr <= dr_prim)
    {
        return arbore[nod];
    }
    int mijloc = (st + dr) / 2;
    int maxim = -1e9;
    if(st_prim <= mijloc)
    {
        maxim = max(maxim, show_max(st_prim, dr_prim, st, mijloc, nod*2));
    }
    if(dr_prim > mijloc)
    {
        maxim = max(maxim, show_max(st_prim, dr_prim, mijloc + 1, dr, (nod*2) + 1));
    }
    return maxim;
}
int main()
{
    fin>>n>>q;
    int x;
    for(int i = 1; i <= n; i++)
    {
        fin>>x;
        update(i, x);
    }
    int a,b, tip;
    for(int i = 1; i <= q; i++)
    {
        fin>>tip>>a>>b;
        if(tip == 0)
        {
            fout<<show_max(a, b)<<'\n';
        }
        else
        {
            update(a, b);
        }
    }
    return 0;
}
