#include <fstream>

using namespace std;

const int nmax = 1e5;

int aint[4 * nmax + 5];
int v[nmax + 5];

void build (int node, int left, int right){
  if (left == right){
    aint[node] = v[left];
    return;
  }

  int mij = (left + right) / 2;
  int leftson = (node << 1);
  int rightson = (node << 1) + 1;

  build (leftson, left, mij);
  build (rightson, mij + 1, right);

  aint[node] = max (aint[leftson], aint[rightson]);
}

void update (int node, int left, int right, int poz, int val){
  if (left == right){
    aint[node] = val;
    return;
  }

  int mij = (left + right) / 2;
  int leftson = (node << 1);
  int rightson = (node << 1) + 1;

  if (poz <= mij){
    update (leftson, left, mij, poz, val);
  }

  else{
    update (rightson, mij + 1, right, poz , val);
  }

  aint[node] = max (aint[leftson], aint[rightson]);
}


int query (int node, int left, int right, int qleft, int qright){
  if (qleft <= left && right <= qright){
    return aint[node];
  }

  int mij = (left + right) / 2;
  int leftson = (node << 1);
  int rightson = (node << 1) + 1;

  if (qleft > mij){
    return query (rightson, mij + 1, right, qleft, qright);
  }
  if (qright <= mij)
    return query (leftson, left, mij, qleft, qright);

  return max (query (rightson, mij + 1, right, qleft, qright), query (leftson, left, mij, qleft, qright));
}

int main(){

  ifstream fin ("arbint.in");
  ofstream fout ("arbint.out");

  int n, m;
  fin >> n >> m;

  for (int i = 1; i <= n; i++){
    fin >> v[i];
  }

  build (1, 1, n);

  while (m--){
    int type, a, b;
    fin >> type >> a >> b;
    if (type == 1){
      update (1, 1, n, a, b);
    }
    else {
      fout << query (1, 1, n, a, b) << "\n";
    }
  }
  return 0;
}
