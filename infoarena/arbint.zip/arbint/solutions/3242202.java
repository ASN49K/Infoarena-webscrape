import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "arbint.in";
    static final String OUTPUT_FILE = "arbint.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static class SegmentTreeMax {
        public int n;
        public int[] nodes;

        public SegmentTreeMax(int n) {
            this.n = n;
            this.nodes = new int[4 * n];
            Arrays.fill(this.nodes, 0);
        }

        public SegmentTreeMax(int[] a) {
            this(a.length);
            for (int i = 1; i < a.length; ++i) {
                internalUpdate(1, 1, n, i, i, a[i]);
            }
        }

        private void internalUpdate(int idx, int left, int right, int a, int b, int value) {
            if (left > b || right < a) {
                return;
            }
            if (left >= a && right <= b) {
                nodes[idx] = value;
                return;
            }
            int mid = (left + right) / 2;
            internalUpdate(idx * 2, left, mid, a, b, value);
            internalUpdate(idx * 2 + 1, mid + 1, right, a, b, value);
            nodes[idx] = Math.max(nodes[idx * 2], nodes[idx * 2 + 1]);
        }

        public void update(int left, int right, int value) {
            internalUpdate(1, 1, n, left, right, value);
        }

        public int query(int left, int right) {
            return internalQuery(1, 1, n, left, right);
        }

        private int internalQuery(int idx, int left, int right, int a, int b) {
            if (left > b || right < a) {
                return -1;
            }
            if (left >= a && right <= b) {
                return nodes[idx];
            }
            int mid = (left + right) / 2;
            return Math.max(
                    internalQuery(idx * 2, left, mid, a, b),
                    internalQuery(idx * 2 + 1, mid + 1, right, a, b)
            );
        }
    }


    public static void solve(TokenizedReader reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        int m = reader.nextInt();

        int[] arr = new int[n + 1];
        for (int i = 1; i <= n; ++i) {
            arr[i] = reader.nextInt();
        }
        SegmentTreeMax segmentTree = new SegmentTreeMax(arr);
        while (m-- > 0) {
            int op = reader.nextInt();
            if (op == 0) {
                int a = reader.nextInt();
                int b = reader.nextInt();
                writer.println(segmentTree.query(a, b));
            } else if (op == 1) {
                int a = reader.nextInt();
                int b = reader.nextInt();
                segmentTree.update(a, a, b);
            }
        }
    }
}