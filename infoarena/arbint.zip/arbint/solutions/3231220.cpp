#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n,m,A[100001];

int divide_et_impera(int ls,int ld)
{
    int max1,max2;
    if(ls == ld)
        return A[ls];
    int mij = (ls+ld)/2;
    max1 = divide_et_impera(ls,mij);
    max2 = divide_et_impera(mij+1,ld);
    return max(max1,max2);
}

int main()
{
    int c,a,b,i;
    fin>>n>>m;
    for(i=1;i<=n;i++)
        fin>>A[i];
    for(i=1;i<=m;i++)
    {
        fin>>c>>a>>b;
        if(c==0)
        {
            fout<<divide_et_impera(a,b)<<"\n";
        }
        if(c==1)
        {
            A[a] = b;
        }
    }
    return 0;
}
