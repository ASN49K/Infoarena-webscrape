#include<fstream>
#include<algorithm>
using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");
const int NMAX=100001, BLKSZ=350;
int n;
int v[NMAX], blk[NMAX/BLKSZ+2];
int blockId(int poz)
{
    return poz/BLKSZ;
}
int main()
{
	int op, q, a, b;
	in>>n>>q;
	for(int i=0; i<n; i++)
	{
		in>>v[i];
		blk[blockId(i)]=max(blk[blockId(i)], v[i]);
	}
	while(q)
    {
		in>>op>>a>>b;
		if(op==1)//pe pozitia a vine valoarea b
		{
			a--;
			if(blk[blockId(a)]==v[a] && v[a]>b)//maximul era chiar pe pozitia a
			{
				blk[blockId(a)]=b;
				v[a]=b;
				for(int i=blockId(a)*BLKSZ; i<n && i<(blockId(a)+1)*BLKSZ; i++)
					blk[blockId(a)]=max(blk[blockId(a)], v[i]);
			}
			else
			{
				v[a]=b;
				blk[blockId(a)]=max(blk[blockId(a)], b);
			}
		}
		else if(op==0)//max pe interval a b
		{
			a--;
			b--;
			int ans=0;
            int c_l = a / BLKSZ, c_r = b / BLKSZ;
            if (c_l == c_r)
                for (int i=a; i<=b; i++)
                    ans = max(ans, v[i]);
            else
            {
                int last=(c_l+1)*BLKSZ-1;
                for(int i=a; i<=last; i++)
                    ans = max(ans, v[i]);
                for(int i=c_l+1; i<=c_r-1; i++)
                    ans = max(ans, blk[i]);
                for(int i=c_r*BLKSZ; i<=b; i++)
                    ans = max(ans, v[i]);
            }
			out<<ans<<'\n';
		}
		q--;
	}
	return 0;
}
