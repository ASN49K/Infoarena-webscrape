#include <stdio.h>

int main() {
    
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);

    int nrElem, nrOperatii;
    scanf("%d%d", &nrElem, &nrOperatii);
    int v[100000];
    for (int i = 1; i <= nrElem; i++) {
        scanf("%d", &v[i]);
    }
    for (int i = 1; i <= nrOperatii; i++) {
        int x;
        scanf("%d", &x);
        if (x == 0) {
            int left, right;
            scanf("%d%d", &left, &right);
            int maxi = 0;
            for (int j = left; j <= right; j++) {
                if (v[j] > maxi) {
                    maxi = v[j];
                }
            }
            printf("%d\n", maxi);
        } else {
            int y;
            scanf("%d%d", &x, &y);
            v[x] = v[y];
        }
    }
    return 0;
}

