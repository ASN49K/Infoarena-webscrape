#include <stdio.h>

int v[100005];
int aint[400005];

int max(int a, int b) {
    return (a > b) ? a : b;
}

void build(int nod, int st, int dr) {
    if (st == dr) {
        aint[nod] = v[st];
    } else {
        int mij = (st + dr) / 2;
        build(nod * 2, st, mij);
        build(nod * 2 + 1, mij + 1, dr);
        aint[nod] = max(aint[nod * 2], aint[nod * 2 + 1]);
    }
}

void update(int nod, int st, int dr, int poz, int val) {
    if (st == dr) {
        aint[nod] = val;
    } else {
        int mij = (st + dr) / 2;
        if (poz <= mij) {
            update(nod * 2, st, mij, poz, val);
        } else {
            update(nod * 2 + 1, mij + 1, dr, poz, val);
        }
        aint[nod] = max(aint[nod * 2], aint[nod * 2 + 1]);
    }
}

int query(int nod, int st, int dr, int a, int b) {
    if (a <= st && dr <= b) {
        return aint[nod];
    }
    
    int mij = (st + dr) / 2;
    int mx = -1;
    
    if (a <= mij) {
        int val = query(nod * 2, st, mij, a, b);
        if (val > mx) mx = val;
    }
    if (b > mij) {
        int val = query(nod * 2 + 1, mij + 1, dr, a, b);
        if (val > mx) mx = val;
    }
    
    return mx;
}

int main() {
    FILE *fin = fopen("arbint.in", "r");
    FILE *fout = fopen("arbint.out", "w");
    
    int n, m;
    fscanf(fin, "%d %d", &n, &m);
    
    for (int i = 1; i <= n; i++) {
        fscanf(fin, "%d", &v[i]);
    }
    
    build(1, 1, n);
    
    while (m--) {
        int op, a, b;
        fscanf(fin, "%d %d %d", &op, &a, &b);
        
        if (op == 0) {
            fprintf(fout, "%d\n", query(1, 1, n, a, b));
        } else {
            update(1, 1, n, a, b);
        }
    }
    
    fclose(fin);
    fclose(fout);
    return 0;
}