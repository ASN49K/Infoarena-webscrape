//
//  main.cpp
//  Aint cu batog
//
//  Created by Andrada Minca on 20.01.2026.
//

#include <fstream>
#include <vector>
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int B=300;
vector<int>v(100000),bucket(100000);
vector<bool>bb(100000);
void check(int start)
{
    bucket[start]=0;
    bb[start]=0;
    for(int i=start*B;i<=(start+1)*B;i++)bucket[start]=max(bucket[start],v[i]);
}
void calc_max(int a,int b)
{
    int dist=b/B-a/B-1;
    int ans=0;
    while(dist>0)
    {
        if(bb[a/B+dist])check(a/B+dist);
        ans=max(ans,bucket[a/B+dist]);
        dist--;
    }
    for(int i=a;i<=min((a/B)*B+1,b);i++)
    {
        if(v[i]>ans)ans=v[i];
    }
    for(int i=max((b/B),a)*B;i<=b;i++)
    {
        if(v[i]>ans)ans=v[i];
    }
    cout<<ans<<'\n';
}
void schimba(int a,int b)
{
    v[a]=b;
    bb[a/B]=1;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++)
    {
        cin>>v[i];
        bucket[i/B]=max(bucket[i/B],v[i]);
    }
    for(int i=0;i<m;i++)
    {
        int c,a,b;
        cin>>c>>a>>b;
        a--;
        b--;
        if(c==0)
        {
            calc_max(a,b);
        }
        else
        {
            schimba(a,b+1);
        }
    }
    return EXIT_SUCCESS;
}
