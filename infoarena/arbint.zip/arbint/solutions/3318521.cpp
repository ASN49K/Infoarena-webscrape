#include <bits/stdc++.h>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX = 100005, BLOCK_size = 320;
int v[NMAX], mx[BLOCK_size + 5];

int main()
{
    int i, j, op, n, m, a, b, ans;
    fin >> n >> m;

    for (i = 0; i < n; i++)
    {
        fin >> v[i];
        mx[i / BLOCK_size] = max(mx[i / BLOCK_size], v[i]);
    }

    for (j = 1; j <= m; j++)
    {
        fin >> op >> a >> b;
        if (op)
        {
            a--;
            int block_a = a / BLOCK_size;
            if (mx[block_a] == v[a] && v[a] > b)
            {
                int start_a = block_a * BLOCK_size, finish_a = min(n - 1, (block_a + 1) * BLOCK_size - 1);
                v[a] = b;
                mx[block_a] = 0;
                for (i = start_a; i <= finish_a; i++)
                    mx[block_a] = max(mx[block_a], v[i]);
            }
            else
            {
                v[a] = b;
                mx[block_a] = max(mx[block_a], v[a]);
            }
        }
        else
        {
            a--;
            b--;
            ans = 0;
            int block_a, block_b;
            block_a = a / BLOCK_size;
            block_b = b / BLOCK_size;
            if (block_a == block_b)
            {
                for (i = a; i <= b; i++)
                    ans = max(ans, v[i]);
            }
            else
            {
                int finish_a = (block_a + 1) * BLOCK_size - 1, start_b = block_b * BLOCK_size;
                for (i = a; i <= finish_a; i++)
                    ans = max(ans, v[i]);
                for (i = block_a + 1; i <= block_b - 1; i++)
                    ans = max(ans, mx[i]);
                for (i = start_b; i <= b; i++)
                    ans = max(ans, v[i]);
            }
            fout << ans << '\n';
        }
    }

    fin.close();
    fout.close();
    return 0;
}
