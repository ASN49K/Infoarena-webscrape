#include <bits/stdc++.h>

using namespace std;

const int Nmax=1e5+5;

int n,v[Nmax],aint[4*Nmax];

void build(int nod, int st, int dr) {
    if (st==dr) aint[nod]=v[st];
    else {
        int mij=(st+dr)/2;
        build(nod*2,st,mij);
        build(nod*2+1,mij+1,dr);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }
}

void update(int nod, int st, int dr, int poz, int val) {
    if (st==dr) aint[nod]=val;
    else {
        int mij=(st+dr)/2;
        if (poz<=mij) update(nod*2,st,mij,poz,val);
        else update(nod*2+1,mij+1,dr,poz,val);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }
}

int query(int nod, int st, int dr, int x, int y) {
    if (st>=x && dr<=y) return aint[nod];
    int mij=(st+dr)/2;
    if (mij>=x) return query(nod*2,st,mij,x,y);
    if (mij<y) return query(nod*2+1,mij+1,dr,x,y);
    return max(query(nod*2,st,mij,x,y),query(nod*2+1,mij+1,dr,x,y));
}

int main()
{
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    int q;
    fin>>n>>q;
    for (int i=1; i<=n; ++i) fin>>v[i];
    build(1,1,n);
    while (q--) {
        bool type;
        int a,b;
        fin>>type>>a>>b;
        if (type==0) fout<<query(1,1,n,a,b)<<'\n';
        else update(1,1,n,a,b);
    }
    fin.close();
    fout.close();
    return 0;
}
