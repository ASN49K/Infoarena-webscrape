#include <fstream>
const int NMAX=100005;

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

void build(int, int, int);
void update(int, int, int, int, int);
int query(int, int, int, int, int);

int a[NMAX], aint[4*NMAX];
int n, q;

int main()
{
  int i, aa, b, tip;
  fin>>n>>q;
  for(i=1; i<=n; i++) fin>>a[i];
  build(1, 1, n);
  for(i=1; i<=q; i++)
  {
    fin>>tip>>aa>>b;
    if(tip==1) update(1, 1, n, aa, b);
    else fout<<query(1, 1, n, aa, b)<<'\n';
  }
}

void build(int nod, int st, int dr)
{
  if(st==dr)
  {
    aint[nod]=a[st];
    return;
  }
  int mij=(st+dr)/2;
  build(2*nod, st, mij);
  build(2*nod+1, mij+1, dr);
  aint[nod]=max(aint[2*nod], aint[2*nod+1]);
}

void update(int nod, int st, int dr, int poz, int val)
{
  if(st==dr && st==poz)
  {
    aint[nod]=val;
    return;
  }
  int mij=(st+dr)/2;
  if(poz<=mij) update(2*nod, st, mij, poz, val);
  if(poz>mij) update(2*nod+1, mij+1, dr, poz, val);
  aint[nod]=max(aint[2*nod], aint[2*nod+1]);
}

int query(int nod, int st, int dr, int a, int b)
{
  if(st>=a && dr<=b) return aint[nod];
  int mij=(st+dr)/2, maxim=0;
  if(a<=mij) maxim=max(maxim, query(2*nod, st, mij, a, b));
  if(b>mij) maxim=max(maxim, query(2*nod+1, mij+1, dr, a, b));
  return maxim;
}
