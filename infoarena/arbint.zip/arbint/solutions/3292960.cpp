#include <bits/stdc++.h>

#pragma GCC optimize ("O3")
#pragma GCC optimize ("inline,unroll-loops,fast-math")
#pragma GCC target ("avx2,bmi,bmi2,lzcnt,popcnt")

using namespace std;

class inParser {
private:
        FILE *fin; char *buff; int id;
        char readCh( ) {
                ++id;
                if (id == 8192) { id = 0; fread(buff, sizeof(char), 4096, fin); }
                return buff[id];
        }
public:
        inParser (const char *name) {
                fin = fopen(name, "r");
                buff = new char[4096]( );
                id = 4095;
        }

        inParser& operator >> (int& num) {
                char ch;
                while (!isdigit(ch = readCh( )));
                num = ch - '0';
                while (isdigit(ch = readCh( )))
                        num = num * 10 + ch - '0';
                return *this;
        }
};

inParser in ("arbint.in");
ofstream out ("arbint.out");

int n, m;
int tree[400002];
int i, elem;
int op, a, b;

static inline int maxTree(int l, int r) {
        l += n; r += n;

        int ans = -1;
        while (l <= r) {
                if ((l & 1) == 1) ans = max(ans, tree[l++]);
                if ((r & 1) == 0) ans = max(ans, tree[r--]);
                l >>= 1; r >>= 1;
        }
        return ans;
}

static inline void updateTree(int pos, int elem) {
        pos += n; tree[pos] = elem;
        pos >>= 1;
        while (pos >= 1) {
                tree[pos] = max(tree[(pos << 1)], tree[(pos << 1) + 1]);
                pos >>= 1;
        }
}


int main( ) {
        in >> n >> m;


        for (i = 1; i <= n; ++i) {
                in >> elem;
                updateTree(i, elem);
        }


        for (i = 1; i <= m; ++i) {
                in >> op >> a >> b;
                if (op == 0) out << maxTree(a, b) << '\n';
                else updateTree(a, b);
        }


        return 0;
}
