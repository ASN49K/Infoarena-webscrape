#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, Q;
int a[100005], tree[100005];

void Build(int node, int st, int dr)
{
    if (st == dr)
        tree[node] = a[st];
    else
    {
        int mij = (st + dr) / 2;
        Build(2 * node, st, mij);
        Build(2 * node + 1, mij + 1, dr);

        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}
void Update(int node, int st, int dr, int poz, int val)
{
    if (st == dr)
        tree[node] = val;
    else
    {
        int mij = (st + dr) / 2;
        if (poz <= mij)
            Update(2 * node, st, mij, poz, val);
        else
            Update(2 * node + 1, mij + 1, dr, poz, val);

        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}
int Query(int node, int st, int dr, int x, int y)
{
    if (x <= st && dr <= y)
        return tree[node];
    int mij, r1, r2;
    r1 = r2 = -2e9;
    mij = (st + dr) / 2;
    if (x <= mij)
        r1 = Query(2 * node, st, mij, x, y);
    else if (y > mij)
        r2 = Query(2 * node + 1, mij + 1, dr, x, y);
    return max(r1, r2);
}

int main()
{
    int i, op, x, y ;
    fin >> n >> Q;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    Build(1, 1, n);
    while (Q--)
    {
        fin >> op >> x >> y;
        if (op == 0)
            fout << Query(1, 1, n, x, y) << "\n";
        else
            Update(1, 1, n, x, y);
    }
    return 0;
}
