/*
Refren (2x)
Forza steaua Forza steaua ale ale
Steaua e numai una
Ne mandrim k ea in toata lumea
Steaua e fermecata
Echipa noastra kalificata
(Forza steaua hey forza steau hey forza manele).

Azi am demonstat k suntem o valoare
Si k altii nu's in stare
Ne mandrim c ei cum nu se poate
Au picioare fermecate
Toti am kastigat sa kastige razboiu
Echipa lu Olaroiu
Ku Gigi Becali, Lacatusi, Meme Stoica
Sa cucerim Europa.

Refren (2x)
Steaua e numai una
Ne mandrim k ea in toata lumea
Steaua e fermecata
Echipa noastra kalificata.

De invidiat incepand cu portaru
Bastina si Ogararu
I'am avut pe Dica pe Banel si Radoi
https://www.versuri.ro/w/66i1
Si pe Dumnezeu c noi.

Steaua nu putea sa ne dezamageasca

E mandria Romaneasca
Si sarbatorim sa ne kante lautarii
Sa petrecem cu Gigi Becali.

Refren :Steaua e numai una
Ne mandrim k ea in toata lumea
Steaua e fermecata
Echipa noastra kalificata.

Si akum sa curga banii
Bucuria lu Gigi Becali
Suntem plini de fericire
E ce mai frumoasa amintire.

Forza steaua hey forza steaua hey forza manele
Refren
Steaua e numai una
Ne mandrim k ea in toata lumea
Steaua e fermecata
Echipa noastra kalificata.

Si akum sa curga banii
Bucuria lu Gigi Becali
Suntem plini de fericire
E ce mai frumoasa amintire.
*/

#include <fstream>
using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int a1[100001],v[400001];

void build(int nod,int st,int dr){
    if(st==dr){
        v[nod]=a1[st];return ;
    }
    int mij=(st+dr)/2;
    build(2*nod,st,mij);
    build(2*nod+1,mij+1,dr);
    v[nod]=max(v[2*nod],v[2*nod+1]); 
}

void update(int nod,int st,int dr,int poz,int val){
    if(st==dr){
        v[nod]=val;
        return ;
    }
    int mij=(st+dr)/2;
    if(poz>mij){
        update(2*nod+1,mij+1,dr,poz,val);
    }else{
        update(2*nod,st,mij,poz,val);
    }
    v[nod]=max(v[2*nod+1],v[2*nod]);
}

int query(int nod,int st,int dr,int a,int b){
    if(st>b || dr<a) return -1;
    if(st>=a && dr<=b) return v[nod];
    int mij=(st+dr)/2;
    return max(query(2*nod+1,mij+1,dr,a,b),query(2*nod,st,mij,a,b));
}

int main()
{
    int n,i,cer,a,b,q;
    cin>>n>>q;
    for(i=1;i<=n;i++){
        cin>>a1[i];
    }
    build(1,1,n);
    for(i=1;i<=q;i++){
        cin>>cer>>a>>b;
        if(cer==0){
            cout<<query(1,1,n,a,b)<<"\n";
        }else{
            update(1,1,n,a,b);
        }
    }
    return 0;
}
