#include <fstream>

using namespace std;
const int NMAX = 100002;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int n;
int v[NMAX];
int aint[4 * NMAX];
void build(int nod, int st, int dr) {
    if(st == dr) {
        aint[nod] = v[st];
        return;
    }
    int mid = (st + dr) / 2;
    build(2 * nod, st, mid);
    build(2 * nod + 1, mid + 1, dr);
    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}
void update(int nod, int st, int dr, int pos, int val) {
    if(st == dr) {
        aint[nod] = val;
        return;
    }
    int mid = (st + dr) / 2;
    if(pos <= mid)
        update(2 * nod, st, mid, pos, val);
    else
        update(2 * nod + 1, mid + 1, dr, pos, val);
    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}
int query(int nod, int st, int dr, int pos1, int pos2) {
    if(st == pos1 && dr == pos2)
        return aint[nod];
    int mid = (st + dr) / 2, ans = 0;
    if(pos1 <= mid)
        ans = query(2 * nod, st, mid, pos1, min(pos2, mid));
    if(mid < pos2)
        ans = max(ans, query(2 * nod + 1, mid + 1, dr, max(pos1, mid + 1), pos2));
    return ans;
}
int main()
{
    int m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
        cin >> v[i];
    build(1, 1, n);
    while(m--) {
        bool ok;
        int a, b;
        cin >> ok >> a >> b;
        if(ok == 0)
            cout << query(1, 1, n, a, b) << '\n';
        else
            update(1, 1, n, a, b);
    }
    return 0;
}
