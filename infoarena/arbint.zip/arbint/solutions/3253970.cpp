#include <bits/stdc++.h>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int v[400005];
int T[400005];
void build(int node,int le,int ri,int *v)
{
    if(le==ri)
    {
        T[node]=v[le];
        return;
    }
    int mid=(le+ri)/2;
    build(2*node,le,mid,v);
    build(2*node+1,mid+1,ri,v);
    T[node]=max(T[2*node],T[2*node+1]);
}
void update(int node,int le,int ri,int pos,int val)
{
    if(le==ri)
    {
        T[node]=val;
        v[pos]=val;
        return;
    }
    int mid=(le+ri)/2;
    if(pos<=mid)
    {
        update(2*node,le,mid,pos,val);
    }
    else
    {
        update(2*node+1,mid+1,ri,pos,val);
    }
    T[node]=max(T[2*node],T[2*node+1]);
}
void query(int node,int le,int ri,int a,int b,int &ans)
{
    if(a<=le && ri<=b)
    {
        ans=max(ans,T[node]);
        return;
    }
    int mid=(le+ri)/2;
    if(a<=mid)
    {
        query(2*node,le,mid,a,b,ans);
    }
    if(b>mid)
    {
        query(2*node+1,mid+1,ri,a,b,ans);
    }
}
int main()
{
    int n,m,t,a,b;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    build(1,1,n,v);
    for(int i=0;i<m;i++)
    {
        fin>>t>>a>>b;
        if(t==1)
        {
            update(1,1,n,a,b);
        }
        else
        {
            int mx=-INT_MAX;
            query(1,1,n,a,b,mx);
            fout<<mx<<'\n';
        }
    }
    return 0;
}
