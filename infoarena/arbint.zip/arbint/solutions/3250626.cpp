#include <bits/stdc++.h>
using namespace std;

const int MAX_NUM = 1e5 + 5;
vector<int> a(MAX_NUM), tree(4 * MAX_NUM);

void build(int node, int l, int r) {
    if (l == r) {
        tree[node] = a[l];
    } else {
        int mid = (l + r) / 2;
        build(node * 2 + 1, l, mid);
        build(node * 2 + 2, mid + 1, r);
        tree[node] = max(tree[node * 2 + 1], tree[node * 2 + 2]);
    }
}

int query(int node, int l, int r, int left, int right) {
    if (left <= l && right >= r) {
        return tree[node];
    }
    if (l > right || r < left) {
        return INT_MIN;
    }
    int mid = (l + r) / 2;
    return max(query(2 * node + 1, l, mid, left, right), query(2 * node + 2, mid + 1, r, left, right));
}

void update(int node, int l, int r, int pos, int value) {
    if (l == r) {
        tree[node] = value;
    } else {
        int mid = (l + r) / 2;
        if (pos <= mid) {
            update(2 * node + 1, l, mid, pos, value);
        } else {
            update(2 * node + 2, mid + 1, r, pos, value);
        }
        tree[node] = max(tree[2 * node + 1], tree[2 * node + 2]);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);
    int n, q;
    cin >> n >> q;
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    build(0, 0, n - 1);
    while (q--) {
        int c, x, y;
        cin >> c >> x >> y;
        if (c == 0) {
            --x, --y;
            cout << query(0, 0, n - 1, x, y) << "\n";
        } else {
            --x;
            update(0, 0, n - 1, x, y);
        }
    }
    return 0;
}

/*

*/
