#include <fstream>

using namespace std;

struct ArbNode {
	int maxValue;
	ArbNode *left;
	ArbNode *right;

	ArbNode(int value, ArbNode *left, ArbNode *right) {
		this->maxValue = value;
		this->left = left;
		this->right = right;
	}
};

ArbNode *root, *NILL;

void sum(int a, int b, int &sum) {
	sum = a + b;
}

void insert(ArbNode*& node, int left, int right, int value, int pos) {
	if (node == NILL) {
		node = new ArbNode(0, NILL, NILL);
	}
	if (left == right) {
		node->maxValue = value;
		return;
	}
	int middle = (left + right) / 2;

	if (pos <= middle) {
		insert(node->left, left, middle, value, pos);
	} else {
		insert(node->right, middle + 1, right, value, pos);
	}

	node->maxValue = max(node->left->maxValue, node->right->maxValue);
}

int getMax(ArbNode* node, int left, int right, int a, int b) {
	if (node == NILL) {
		return 0;
	}
	if (a <= left && right <= b) {
		return node->maxValue;
	}
	int middle = (left + right) / 2;
	int maxLeft = 0, maxRight = 0;

	if (left <= middle) {
		maxLeft = getMax(node->left, left, middle, a, b);
	}
	if (middle + 1 <= right) {
		maxRight = getMax(node->right, middle + 1, right, a, b);
	}
	return max(maxLeft, maxRight);
}

int main() {
	ifstream cin("arbint.in");
	ofstream cout("arbint.out");

	NILL = new ArbNode(-1, nullptr, nullptr);

	root = NILL;

	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; i++) {
		int x;
		cin >> x;
		insert(root, 1, n, x, i + 1);
	}

	for (int i = 0; i < m; i++) {
		int a, b, type;
		cin >> type >> a >> b;

		if (type == 0) {
			cout << getMax(root, 1, n, a, b) << '\n';
		} else {
			insert(root, 1, n, b, a);
		}
	}
	return 0;
}