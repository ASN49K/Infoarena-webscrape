#include <iostream>
#include <fstream>
#define N 100005
#include <algorithm>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int n,m,cod,a,b, v[N], A[N * 5], i;

void construire(int nod, int st, int dr)
{
    if (st == dr)
        A[nod] = v[st];
    else
    {
        int mij = (st + dr) / 2;

        construire(nod * 2, st, mij);
        construire(nod * 2 + 1, mij + 1, dr);

        A[nod] = max(A[nod * 2], A[nod * 2 + 1]);
    }
}

void actualizare(int nod, int st, int dr, int poz, int val)
{
    if (st == dr)
        A[nod] = val;
    else
    {
        int mij = (st + dr) / 2;

        if (poz <= mij)
            actualizare(nod * 2, st, mij, poz, val);
        else
            actualizare(nod * 2 + 1, mij + 1, dr, poz, val);

        A[nod] = max(A[nod * 2], A[nod * 2 + 1]);
    }
}

int maxim(int nod, int st, int dr, int a, int b)///intervalul [a,b]
{
    if (a <= st && b >= dr)
        return A[nod];
    else
    {
        int mij = (st + dr) / 2;

        if (a <= mij)
            return maxim(nod * 2, st, mij, a, b);
        if (b >= dr + 1)
            return maxim(nod * 2 + 1, mij + 1, dr, a, b);

        return max(A[nod * 2, st, mij, a, b], A[nod * 2 + 1, mij + 1, dr, a, b]);
    }
}

int main()
{
    f >> n >> m;
    for (i = 1; i <= n ; i++)
        f >> v[i];

    construire(1, 1, n);

    while (m)
    {
        f >> cod >> a >> b;
        if (cod == 0)
            g << maxim(1,1,n,a,b) << '\n';
        else
            actualizare(1,1,n,a,b);
        m--;
    }
    return 0;
}
