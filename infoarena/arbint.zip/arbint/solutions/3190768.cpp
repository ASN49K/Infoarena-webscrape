#include <fstream>

#define DIM 100005

using namespace std;

ifstream f("aint.in");
ofstream g("aint.out");

int n, m;
int v[DIM];
int aint[4 * DIM];

void build(int node, int st, int dr) {
    if (st == dr) {
        aint[node] = v[st];
        return ;
    }

    int mid = (st + dr) / 2;
    build(2 * node, st, mid);
    build(2 * node + 1, mid + 1, dr);

    aint[node] = max(aint[2 * node], aint[2 * node + 1]);
}

void update(int node, int st, int dr, int val, int pos) {
    if (st == dr) {
        aint[node] = val;
        return;
    }

    int mid = (st + dr) / 2;
    if (mid <= pos) {
        update(2 * node, st, mid, val, pos);
    } else {
        update(2 * node + 1, mid + 1, dr, val, pos);
    }

    aint[node] = max(aint[2 * node], aint[2 * node + 1]);
}

int query(int node, int st, int dr, int stQ, int drQ) {
    if (stQ <= st && dr <= drQ) {
        return aint[node];
    }

    int mid = (st + dr) / 2;
    int r1(0), r2(0);
    if (mid <= drQ) {
        r1 = query(2 * node, st, mid, stQ, drQ);
    }
    if (mid > stQ) {
        r2 = query(2 * node + 1, mid + 1, dr, stQ, drQ);
    }

    return max(r1, r2);
}

int main() {

    f >> n >> m;

    for (int i = 1; i <= n; i++) {
        f >> v[i];
    }

    build(1, 1, n);

    while (m--) {
        int op, x, y;
        f >> op >> x >> y;

        if (op == 0) {
            g << query(1, 1, n, x, y) << "\n";
        } else {
            update(1, 1, n, x, y);
        }
    }

    return 0;
}