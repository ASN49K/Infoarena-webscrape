#include <bits/stdc++.h>

using namespace std;

int power_of_two(int n) {
  int crt = 1;
  while (crt < n) {
    crt *= 2;
  }

  return crt * 2;
}

class SegmentTree {
private:
  int n;
  vector<int> tree;
  int len;

public:
  SegmentTree(vector<int> &tree) {
    n = tree.size();
    this->tree.resize(power_of_two(tree.size()), 0);
    len = this->tree.size() / 2;
    build(tree);
  }

  void build(vector<int> &tree) {
    for (int i = 0; i < n; i++) {
      this->tree[i + len] = tree[i];
    }

    for (int index = len * 2 - 1; index > 1; index -= 2) {
      this->tree[index / 2] = max(this->tree[index], this->tree[index - 1]);
    }
  }

  void update(int pos, int value) {
    pos = pos + len - 1;
    this->tree[pos] = value;

    while (pos != 0) {
      if (pos % 2 == 0) {
        this->tree[pos / 2] = max(this->tree[pos], this->tree[pos + 1]);
      } else {
        this->tree[pos / 2] = max(this->tree[pos], this->tree[pos - 1]);
      }
      pos = pos / 2;
    }
  }

  int query(int l, int r) {
    l = l + len - 1;
    r = r + len - 1;
    int res = -1;

    while (l <= r) {
      if (l % 2 == 1) {
        res = max(res, this->tree[l]);
        l++;
      }
      if (r % 2 == 0) {
        res = max(res, this->tree[r]);
        r--;
      }
      r /= 2;
      l /= 2;
    }

    return res;
  }

  void print_tree() {
    for (int index = 1; index < this->tree.size(); index++) {
      cout << this->tree[index] << " ";
    }
    cout << endl;
  }
};

int main() {
  ifstream cin{"arbint.in"};
  ofstream cout{"arbint.out"};

  int n, q;
  cin >> n >> q;

  vector<int> tree(n);

  for (int i = 0; i < n; i++) {
    cin >> tree[i];
  }

  SegmentTree CopilCopac(tree);

  for (int index = 0; index < n; index++) {
    int type, a, b;
    cin >> type >> a >> b;

    if (type == 0) {
      cout << CopilCopac.query(a, b) << '\n';
    } else {
      CopilCopac.update(a, b);
    }
  }

  return 0;
}

/*
       10
   10       1
 10   6   1   0
4 10 5 6 1 0 0 0
*/