#include <bits/stdc++.h>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

#define MAXN 50000

int aint[4 * MAXN];
int v[MAXN + 1];
int maxx = -1;

void build ( int nod, int st, int dr )
{
    if ( st == dr )
    {
        aint[nod] = v[st];
        return;
    }
    int mij = ( st + dr ) / 2;
    build ( nod * 2, st, mij );
    build ( nod * 2 + 1, mij + 1, dr );
    aint[nod] = max ( aint[nod * 2], aint[nod * 2 + 1] );
}

void update ( int nod, int st, int dr, int idx, int val )
{
    if ( st == dr )
    {
        aint[nod] = val;
        return;
    }
    int mij = ( st + dr ) / 2;
    if ( idx <= mij )
        update ( nod * 2, st, mij, idx, val );
    else update ( nod * 2 + 1, mij + 1, dr, idx, val );
    aint[nod] = max ( aint[nod * 2], aint[nod * 2 + 1] );
}

void query ( int nod, int st, int dr, int a, int b )
{
    if ( st > b || dr < a )
        return;
    if ( a <= st && dr <= b )
    {
        maxx = max ( maxx, aint[nod] );
        return;
    }
    int mij = ( st + dr ) / 2;
    query ( nod * 2, st, mij, a, b );
    query ( nod * 2 + 1, mij + 1, dr, a, b );
}

int main()
{
    int q, n;
    f >> n >> q;
    for ( int i = 1; i <= n; i ++ )
        f >> v[i];
    build ( 1, 1, n );
    while ( q -- )
    {
        int tip, a, b;
        f >> tip >> a >> b;
        if ( tip == 0 )
        {
            maxx = INT_MIN;
            query ( 1, 1, n, a, b );
            g << maxx << '\n';
        }
        else update ( 1, 1, n, a, b );
    }
    return 0;
}
