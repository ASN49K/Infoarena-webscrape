#include <fstream>

using namespace std;

ifstream cin ("arbint.in");
ofstream cout ("arbint.out");

int st[100001];

void update(int to, int from, int pos, int val, int node) {
    if(to == from) {
        st[node] = val;
        return;
    }
    int mid = (from+to)/2;
    if(pos <= mid)
        update(mid, from, pos, val, node*2);
    else update(to, mid+1, pos, val, node*2+1);
    st[node] = max(st[2*node], st[2*node+1]);
}

int query(int from, int to, int node, int ql, int qr) {
    if(ql <= from && to <= qr)
        return st[node];
    int mid = (to+from)/2, s = 0;
    if(ql <= mid)
        s = max(s, query(from, mid, node*2, ql, qr));
    if(mid+1 <= qr)
        s = max(s, query(mid+1, to, node*2+1, ql, qr));
    return s;
}

int main() {
    int n,q, x;
    cin >> n >> q;
    for(int i = 1; i <= n; i++) {
        cin >> x;
        update(n, 1, i, x, 1);
    }
    while(q--) {
        int cer, a, b;
        cin >> cer >> a >> b;
        if(cer == 1)
            update(1, n, a, b, 1);
        else cout << query(1, n, 1, a, b) << '\n';
    }
}
