#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n,m,len,segT[500005];

int search(int L,int R,int pos,int st,int dr){
    // confirmation case
    if(pos>=2*len || dr < L || st > R) return 0;
    if(L<=st && dr<=R){
        return segT[pos];
    }
    int mij = (st+dr) /2;
    return max(search(L,R,pos*2,st,mij),search(L,R,pos*2+1,mij+1,dr));
    // split
}

void update(int pos, int val){
    int poz = len + pos - 1;
    segT[poz] = val;
    poz/=2;
    while(poz > 0){
        segT[poz] = max(segT[poz*2],segT[poz*2+1]);
        poz/=2;
    }
}

int main(){
    fin>>n>>m;
    len = (1<<int(ceil(log2(n))));
    for(int i=len;i<len+n;i++){
        fin>>segT[i];
    }
    for(int i=2*len-1;i>=2;i--){
        segT[i/2] = max(segT[i/2],segT[i]);
    }
    int q,a,b;
    for(int i=1;i<=m;i++){
        fin>>q>>a>>b;
        if(q==0){
            fout<<search(a,b,1,1,len)<<'\n';
        }
        else{
            update(a,b);
        }
    }
    //for(int i=1;i<2*len;i++) fout<<segT[i]<<' ';
    return 0;
}