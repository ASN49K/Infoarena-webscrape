#include<bits/stdc++.h>
using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");
int a[400005];
int n, q;
int fs(int i){ return i * 2; }
int fd(int i){ return i * 2 + 1; }
void update(int nod, int st, int dr, int poz, int val)
{
    if ( st == dr )
    {
        a[nod] = val;
        return;
    }
    int mij = ( st + dr ) / 2;
    if ( poz <= mij )
        update(fs(nod), st, mij, poz, val);
    else
        update(fd(nod), mij + 1, dr, poz, val);
    a[nod] = max(a[fs(nod)], a[fd(nod)]);
}
int query(int nod, int st, int dr, int qs, int qd)
{
    if ( qs <= st && dr <= qd )
        return a[nod];
    if ( st > qd || dr < qs )
        return INT_MIN;
    int mij = ( st + dr ) / 2;
    return max(query(fs(nod), st, mij, qs, qd), query(fd(nod), mij + 1, dr, qs, qd));
}
void citire()
{
    in>>n>>q;
    for ( int i = 1 ; i <= n ; i++ )
    {
        int x;
        in>>x;
        update(1, 1, n, i, x);
    }
}
void rez()
{
    for ( int i = 1 ; i <= q ; i++ )
    {
        int op, a, b;
        in>>op>>a>>b;
        if ( op == 0 )
        {
            out<<query(1, 1, n, a, b)<<'\n';
        }
        else
        {
            update(1, 1, n, a, b);
        }
    }
}
int main()
{
    citire();
    rez();
    return 0;
}
