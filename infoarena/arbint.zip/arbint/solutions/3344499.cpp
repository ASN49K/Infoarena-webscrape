#include <bits/stdc++.h>
std::ifstream fin("arbint.in");
std::ofstream fout("arbint.out");

const int N = 100001;
int tree[4 * N];

void update(int node, int val, int ind, int st, int dr)
{
    if(st == dr)
    {
        tree[node] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if(ind <= mij)
        update(2 * node, val, ind, st, mij);
    else
        update(2 * node + 1, val, ind, mij + 1, dr);

    tree[node] = std::max(tree[2 * node], tree[2 * node + 1]);
}

int query(int node, int a, int b, int st, int dr)
{
    if(a <= st && dr <= b)
    {
        return tree[node];
    }
    int max1 = -1, max2 = - 1;
    int mij = (st + dr) / 2;
    if(a <= mij)
    {
        max1 = query(node * 2, a, b, st, mij);
    }
    if(b > mij)
    {
        max2 = query(node * 2 + 1, a, b, mij + 1, dr);
    }
    return std::max(max1, max2);
}
int main()
{
    std::ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        int a;
        fin >> a;
        update(1, a, i, 1, n);
    }
    for(int i = 1; i <= m; i++)
    {
        int tip, a, b;
        fin >> tip >> a >> b;
        if(tip == 0)
            fout << query(1, a, b, 1, n) << '\n';
        else
            update(1, b, a, 1, n);
    }
    return 0;
}
