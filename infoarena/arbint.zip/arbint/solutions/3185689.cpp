#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define ld long double
#define chad char
#define mod 1'000'000'007
#define dim 100005
#define lim 1000000
#define mdim 1501
#define mult 2e9
#define maxx 200002
#define simaimult 1e17
#define FOR(i,a,b) for(int i=(a); i<=(b); i++)
#define pli pair<ll,int>
#define pil pair<int,ll>
#define piii pair<int,pair<int,int> > 
#define pii pair<int,int>
#define pll pair<ll,ll>
#define pb push_back
#define mp make_pair
#define nr_biti __builtin_popcount
using namespace std;
 
ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n,q;
int a[dim];

struct segtree 
{
    vector<int> aint;

    void init(int n)
    {
        aint=vector<int>(4*n+4);
    }

    void build(int nod,int st,int dr)
    {
        if(st==dr)
        {
            aint[nod]=a[st];
            return;
        }

        int mij=(st+dr)/2;

        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);

        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }

    void update(int nod,int st,int dr,int pos,int val)
    {
        if(st>dr)
            return;

        if(st==dr)
        {
            aint[nod]=val;
            return;
        }

        int mij=(st+dr)/2;

        if(pos<=mij)
            update(2*nod,st,mij,pos,val);
        else 
            update(2*nod+1,mij+1,dr,pos,val);

        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }

    int query(int nod,int st,int dr,int qst,int qdr)
    {
        if(st>dr)
            return -1;

        if(st>qdr || dr<qst)
            return -1;

        if(st>=qst && dr<=qdr)
            return aint[nod];

        int mij=(st+dr)/2;

        return max(query(2*nod,st,mij,qst,qdr),query(2*nod+1,mij+1,dr,qst,qdr));
    }

}v;

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr); 

    fin >> n >> q;

    for(int i=1; i<=n; i++)
        fin >> a[i];

    v.init(n);
    v.build(1,1,n);

    while(q--)
    {
        int tip,st,dr;

        fin >> tip >> st >> dr;

        if(!tip)
        {
            fout << v.query(1,1,n,st,dr) << "\n";
        }
        else
        {
            v.update(1,1,n,st,dr);
        }
    }

    return 0;
}