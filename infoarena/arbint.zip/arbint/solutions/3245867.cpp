#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int aint[400005];
int query(int nod, int a, int b, int st, int dr)
{
    if (st==dr)
        return aint[nod];
    int mid=(st+dr)/2;
    int c=0, d=0;
    if (a<=mid)
        c=query(2*nod, a, b, st, mid);
    if (b>mid)
        d=query(2*nod+1, a, b, mid+1, dr);
    if (c>d)
        return c;
    return d;
}
int upd(int nod, int a, int x, int st, int dr)
{
    if (st==dr && dr==a)
    {
        aint[nod]=x;
        return x;
    }
    if (st==dr)
        return aint[nod];
    int mid=(st+dr)/2;
    int c;
    if (a<=mid)
    {
        c=upd(2*nod, a, x, st, mid);
        if (c>aint[nod])
            aint[nod]=c;
    }
    else
    {
        c=upd(2*nod+1, a, x, mid+1, dr);
        if (c>aint[nod])
            aint[nod]=c;
    }
    return aint[nod];
}
int main()
{
    int n, m;
    int x;
    cin>>n>>m;
    int ceva;
    for (int i=1; i<=n; i++)
    {
        cin>>x;
        ceva=upd(1, i, x, 1, n);
    }
    int a, b, c;
    for (int i=1; i<=m; i++)
    {
        cin>>a>>b>>c;
        if (a==0)
            cout<<query(1, b, c, 1, n)<<'\n';
        else
            ceva=upd(1, b, c, 1, n);
    }
    return 0;
}
