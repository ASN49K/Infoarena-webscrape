#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int N, M, sol;
int v[100005];
int ai[400005];

void build(int nod, int st, int dr){
    if(st == dr){
        ai[nod] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    build(2 * nod, st, mij);
    build(2 * nod + 1, mij + 1, dr);
    ai[nod] = max(ai[2 * nod], ai[2 * nod + 1]);
}

void update(int nod, int st, int dr, int p, int x){
    if(st == dr){
        ai[nod] = x;
        return;
    }

    int mij = (st + dr) / 2;
    if(p <= mij){
        update(2 * nod, st, mij, p, x);
    }else{
        update(2 * nod + 1, mij + 1, dr, p, x);
    }

    ai[nod] = max(ai[2 * nod], ai[2 * nod + 1]);
}

void query(int nod, int st, int dr, int a, int b){
    if(a <= st && dr <= b){
        sol = max(sol, ai[nod]);
        return;
    }

    int mij = (st + dr) / 2;
    if(a <= mij){
        query(2 * nod, st, mij, a, b);
    }
    if(b > mij){
        query(2 * nod + 1, mij + 1, dr, a, b);
    }
}

int main()
{
    fin >> N >> M;
    for(int i = 1; i <= N; i++){
        fin >> v[i];
    }

    build(1, 1, N);

    int op, a, b;
    for(int i = 1; i <= M; i++){
        fin >> op >> a >> b;
        if(op == 0){
            sol = -1;
            query(1, 1, N, a, b);
            fout << sol << "\n";
        }else{
            update(1, 1, N, a, b);
        }
    }
    return 0;
}
