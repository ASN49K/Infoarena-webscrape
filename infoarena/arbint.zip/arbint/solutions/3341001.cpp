#include <iostream>
#include <cstring>

using namespace std;

int main()
 {
    char s1[201];
    char s2[3];
    int nr = 0;


    cout << "Introduceti propozitia ";
    cin.getline(s1, 201);
    cout << "Introduceti silaba (de 2 litere): ";
    cin >> s2;
    char *p = strstr(s1, s2);
    while (p != NULL) {
        nr++;
        p = strstr(p + 1, s2);
    }

    cout << nr;
    return 0;
}
