#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");
typedef const int cint;
cint N_max = 100005, NOD_max = 525000;
int a[100005];
int pou[525000];
void Build(int nod, int st, int dr){
    if(st == dr){ pou[nod] = a[st];return;}
    int mij = (st + dr) / 2;
    Build(2 * nod, st, mij);
    Build(2 * nod + 1, mij + 1, dr);
    pou[nod] = max(pou[2 * nod], pou[2 * nod + 1]);
}
int Get_Max(int nod, int st, int dr, int x, int y){
    if(x == st && y == dr) return pou[nod];
    int mij = (st + dr) / 2;
    if(y <= mij){
        return Get_Max(2 * nod, st, mij, x, y);
    }else{
        if(x > mij){
            return Get_Max(2 * nod + 1, mij + 1, dr, x, y);
        }else{
            return max(Get_Max(2 * nod, st, mij, x, mij),Get_Max(2 * nod + 1, mij + 1, dr, mij + 1, y));
        }
    }
}
void replace(int nod, int st, int dr, int x, int y){
    if(st == dr){ pou[nod] = y;return;}
    int mij = (st + dr) / 2;
    if (x <= mij) replace(2 * nod, st, mij, x, y);
    else          replace(2 * nod + 1, mij + 1, dr, x, y);
    pou[nod] = max(pou[2 * nod], pou[2 * nod + 1]);
}

int main() {
    int n, q;
    fin >> n >> q;
    for(int i = 1; i <= n; i++)fin >> a[i];
    Build(1, 1, n);
    for(int p = 1; p <= q; p++){
        int tip, x, y;
        fin >> tip >> x >> y;
        if(tip == 0){
            fout << Get_Max(1, 1, n, x, y) << '\n';
        }else{
            a[x] = y;
            replace(1, 1, n, x, y);
        }
    }
}
