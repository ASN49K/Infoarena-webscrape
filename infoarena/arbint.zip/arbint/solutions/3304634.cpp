#include <fstream>
#define NMAX 100002
using namespace std;
ifstream  fin("arbint.in");
ofstream fout("arbint.out");
int N,M,v[NMAX],aint[4*NMAX];

void citire()
{
    fin>>N>>M;

    for(int i=1; i<=N; i++)
    {
        fin>>v[i];
    }
}

void build(int nod, int st, int dr)
{
    if(st==dr)
    {
        aint[nod]=v[st];
    }
    else
    {
        int pmijl=(st+dr)/2;

        build(2*nod,st,pmijl);
        build(2*nod+1,pmijl+1,dr);

        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}

void update(int poz, int val, int nod, int st, int dr)
{
    if(st==dr)
    {
        aint[nod]=val;
    }
    else
    {
        int pmijl=(st+dr)/2;

        if(poz<=pmijl)
        {
            update(poz,val,2*nod,st,pmijl);
        }
        else
        {
            update(poz,val,2*nod+1,pmijl+1,dr);
        }

        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}

int query(int a, int b, int nod, int st, int dr)
{
    if(st>b || dr<a)
    {
        return 0;
    }

    if(a<=st && dr<=b)
    {
        return aint[nod];
    }

    int pmijl=(st+dr)/2;

    return max(query(a,b,2*nod,st,pmijl),query(a,b,2*nod+1,pmijl+1,dr));
}

int main()
{
    citire();

    build(1,1,N);

    for(int q=1; q<=M; q++)
    {
        int op,a,b;
        fin>>op>>a>>b;

        if(op==0)
        {
            fout<< query(a,b,1,1,N) << "\n";
        }

        if(op==1)
        {
            update(a,b,1,1,N);
        }
    }

    return 0;
}
