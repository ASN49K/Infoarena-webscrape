#include <fstream>
#include <iostream>
#include <climits>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
#define NMAX 100001
int st[NMAX * 4];
void update(int cntIndex, int pos, int val, int l, int r)
{
    if (l == r)
    {
        st[cntIndex] = val;
        return;
    }
    int mid = (l + r) / 2;
    if (pos <= mid)
    {
        update(cntIndex * 2, pos, val, l, mid);
    }
    else
    {
        update(cntIndex * 2 + 1, pos, val, mid + 1, r);
    }
    st[cntIndex] = max(st[cntIndex * 2], st[cntIndex * 2 + 1]);
}
int ql, qr;
void query(int cntIndex, int l, int r, int &ans)
{
    if (ql <= l && r <= qr)
    {
        ans = max(ans, st[cntIndex]);
        return;
    }
    int mid = (l + r) / 2;

    if (ql <= mid)
    {
        query(cntIndex * 2, l, mid, ans);
    }
    if (mid < qr)
    {
        query(cntIndex * 2 + 1, mid + 1, r, ans);
    }
}
int main()
{
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        update(1, i, x, 1, n);
    }
    while (m--)
    {
        int c, a, b;
        fin >> c >> a >> b;
        if (c == 0)
        {
            ql = a;
            qr = b;
            int ans;
            ans = INT_MIN;
            query(1, 1, n, ans);
            fout << ans << '\n';
        }
        else
        {

            update(1, a, b, 1, n);
        }
    }
    return 0;
}