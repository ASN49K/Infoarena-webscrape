#include <iostream>
#include <fstream>
#include <deque>
using namespace std;

ifstream fin("aint.in");
ofstream fout("aint.out");

int t[400005], n;

void update(int v, int tl, int tr, int pos, int new_val) 
{
    if (tl == tr) 
    {
        t[v] = new_val;
        return;
    }
    int tm = (tl + tr) / 2;
    if (pos <= tm)
        update(v * 2, tl, tm, pos, new_val);
    else
        update(v * 2 + 1, tm + 1, tr, pos, new_val);
    t[v] = max(t[v * 2], t[v * 2 + 1]);
}

int query(int v, int tl, int tr, int l, int r) {
    if (l > r)
        return 0;
    if (l == tl && r == tr) 
        return t[v];
    int tm = (tl + tr) / 2;
    return max(query(v * 2, tl, tm, l, min(r, tm))
       , query(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r));
}

int main()
{
    int i, q, op, x, y;
    fin >> n >> q;
    for (i = 1; i <= n; i++)
    {
        fin >> x;
        update(1, 1, n, i, x);
    }
    while (q--)
    {
        fin >> op >> x >> y;
        if (op == 1)
            update(1, 1, n, x, y);
        else
            fout << query(1, 1, n, x, y) << "\n";
    }
    return 0;
}
