#include <bits/stdc++.h>
#define int long long

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

const int nmax=1e5+5;
int n,n_og;
int a[3*nmax+5],aint[3*nmax+5];

void nxt2(int &n)
{
    while ( n&(n-1) )
        n+=(n&-n);
}

struct AINT
{
    void build()
    {
        for (int i=0; i<n_og; i++ )
            aint[i+n]=a[i];

        /*for (int i=n_og; i<n; i++ )
            aint[i+n]=INT_MAX;*/

        for (int i=n-1; i>=1; i-- )
            aint[i]=max(aint[2*i],aint[2*i+1]);
    }

    void update(int pos, int x)
    {
        a[pos]=x;

        pos+=n;
        aint[pos]=x;

        for (pos/=2; pos; pos/=2 )
            aint[pos]=max(aint[2*pos],aint[2*pos+1]);
    }

    int query(int l, int r)
    {
        l+=n;
        r+=n;

        int maxi=0;

        while ( l<=r )
        {
            if ( l&1 )
                maxi=max(maxi,aint[l++]);

            l>>=1;

            if ( !(r&1) )
                maxi=max(maxi,aint[r--]);

            r>>=1;
        }

        return maxi;
    }

}tree;

int main()
{
    int q; f >> n >> q;
    for (int i=1; i<=n; i++ )
        f >> a[i];

    n_og=n;
    nxt2(n);

    tree.build();

    while ( q-- )
    {
        int c; f >> c;
        if ( c==0 )
        {
            int l,r; f >> l >> r;
            g << tree.query(l,r) << '\n';
        }
        if ( c==1 )
        {
            int pos,x; f >> pos >> x;
            tree.update(pos,x);
        }
    }
    return 0;
}
