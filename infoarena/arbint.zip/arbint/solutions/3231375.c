#include <stdio.h>
#include <stdlib.h>

#define in "arbint.in"
#define out "arbint.out"

typedef struct arbore
{
    int info, stanga, dreapta;
    struct arbore *st, *dr;
} arbore;

arbore *newNod(int info, int stanga, int dreapta)
{
    arbore *new = (arbore *)malloc(sizeof(arbore));
    new->info = info;
    new->stanga = stanga;
    new->dreapta = dreapta;
    new->st = new->dr = NULL;
    return new;
}

arbore *newArbore(int stanga, int dreapta)
{
    arbore *radacina = newNod(0, stanga, dreapta);
    if (stanga != dreapta)
    {
        int mijloc = (stanga + dreapta) / 2;
        radacina->st = newArbore(stanga, mijloc);
        radacina->dr = newArbore(mijloc + 1, dreapta);
    }
    else
    {
        radacina->st = radacina->dr = NULL;
    }
    return radacina;
}

int max(int a, int b)
{
    return a > b ? a : b;
}

void actualizare(arbore *radacina, int pozitie, int valoare)
{
    if (radacina->stanga == radacina->dreapta)
    {
        radacina->info = valoare;
    }
    else
    {
        int mijloc = (radacina->stanga + radacina->dreapta) / 2;
        if (pozitie <= mijloc)
        {
            actualizare(radacina->st, pozitie, valoare);
        }
        else
        {
            actualizare(radacina->dr, pozitie, valoare);
        }
        radacina->info = max(radacina->st->info, radacina->dr->info);
    }
}

int interogare(arbore *radacina, int stanga, int dreapta)
{
    if (radacina->stanga == stanga && radacina->dreapta == dreapta)
    {
        return radacina->info;
    }
    else
    {
        int mijloc = (radacina->stanga + radacina->dreapta) / 2;
        if (dreapta <= mijloc)
        {
            return interogare(radacina->st, stanga, dreapta);
        }
        else if (stanga > mijloc)
        {
            return interogare(radacina->dr, stanga, dreapta);
        }
        else
        {
            return max(interogare(radacina->st, stanga, mijloc), interogare(radacina->dr, mijloc + 1, dreapta));
        }
    }
}

int main(void)
{
    FILE *fin, *fout;
    fin = fopen("arbint.in", "r");
    fout = fopen("arbint.out", "w");
    int n, m, optiune, a, b, info, i;
    fscanf(fin, "%d %d", &n, &m);
    arbore *radacina = newArbore(1, n);
    for (i = 1; i <= n; i++)
    {
        fscanf(fin, "%d", &info);
        actualizare(radacina, i, info);
    }
    for (i = 1; i <= m; i++)
    {
        fscanf(fin, "%d %d %d", &optiune, &a, &b);
        if (optiune == 0)
        {
            fprintf(fout, "%d\n", interogare(radacina, a, b));
        }
        else
        {
            actualizare(radacina, a, b);
        }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}