#include <bits/stdc++.h>

#define NM 400002

using namespace std;
ifstream fin ("arbint.in");
ofstream fout ("arbint.out");
int n, m, v[NM];

void update (int st, int dr, int node, int poz, int val)
{
    if(st == dr)
    {
        v[node] = val;
        return;
    }
    int mid = (st + dr) / 2;
    if(poz <= mid)
        update(st, mid, node * 2, poz, val);
    else
        update(mid + 1, dr, node * 2 + 1, poz, val);
    v[node] = max(v[node * 2], v[node * 2 + 1]);
}

int qry (int st, int dr, int node, int a, int b)
{
    int r1 = 0, r2 = 0;
    if(a <= st && b >= dr)
        return v[node];
    int mid = (st + dr) / 2;
    if(a <= mid)
        r1 = qry(st, mid, node * 2, a, b);
    if(b >= mid + 1)
        r2 = qry(mid + 1, dr, node * 2 + 1, a, b);
    return max(r1, r2);
}

int main()
{
    
    fin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        int t;
        fin >> t;
        update(1, n, 1, i, t);
    }
    for(int i = 1; i <= m; i++)
    {
        int x,y,z;
        fin >> x>>y>>z;
        if(x == 1)
            update(1, n, 1, y, z);
        else
            fout << qry(1, n, 1, y, z) << "\n";
    }
    return 0;
}