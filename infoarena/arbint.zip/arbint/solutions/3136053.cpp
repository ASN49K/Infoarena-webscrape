#include <iostream>
#include <fstream>
using namespace std;
#define MAX 100001
ifstream in("arbint.in");
ofstream out("arbint.out");
int tree[4 * MAX + 5];
int V[MAX + 5];

void build(int node, int le, int ri)
{
    if (le == ri)
    {
        tree[node] = V[le];
        return;
    }

    int mid = (le + ri) / 2;

    build(2 * node, le, mid);
    build(2 * node + 1, mid + 1, ri);

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}
void query(int node, int le, int ri, int x, int y, int &ans)
{
    if (x <= le && ri <= y)
    {
        ans = max(ans, tree[node]);
        return;
    }

    int mid = (le + ri) / 2;

    if (x <= mid)
    {
        query(2 * node, le, mid, x, y, ans);
    }
    if (y > mid)
    {
        query(2 * node + 1, mid + 1, ri, x, y, ans);
    }
}

int main()
{

    int N, M;
    in >> N >> M;
    for (int i = 1; i <= N; i++)
    {
        in >> V[i];
    }
    // for (int i = 0; i < N; i++)
    // {
    //     out << V[i] << " " << endl;
    // }
    build(1, 1, 5);
    int ans = 0;
    // query(1, 1, 5, 1, 3, ans);
    // out << "ans=" << ans << endl;
    // for (int i = 0; i < 100; i++)
    // {
    //     out << "tree[" << i << "]=" << tree[i] << endl;
    // }
    int op, x, y;
    for (int i = 0; i < M; i++)
    {
        in >> op >> x >> y;
        if (op == 0)
        {
            query(1, 1, 5, x, y, ans);
            out << ans << endl;
        }
        else
        {
            tree[x] = y;
        }
    }
}