#include <bits/stdc++.h>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int v_len = 100001;
int vec[v_len], tree[v_len * 4 + 5];

void buildTree(int node, int l, int r)
{
    if (l == r)
    {
        tree[node] = vec[l];
        return;
    }

    int mid = (l + r) / 2;

    buildTree(node * 2, l, mid);
    buildTree(node * 2 + 1, mid + 1, r);

    tree[node] = max(tree[node * 2], tree[node * 2 + 1]);
}

void updateTree(int node, int l, int r, int pos, int val)
{
    if (l == r)
    {
        tree[node] = vec[l] = val;
        return;
    }

    int mid = (l + r) / 2;
    if (pos <= mid)
        updateTree(node * 2, l, mid, pos, val);
    else
        updateTree(node * 2 + 1, mid + 1, r, pos, val);

    tree[node] = max(tree[node * 2], tree[node * 2 + 1]);
}

int maxx = INT_MIN;
void queryTree(int node, int l, int r, int ql, int qr)
{
    if (ql <= l && r <= qr)
    {
        maxx = max(maxx, tree[node]);
        return;
    }

    int mid = (l + r) / 2;
    if (ql <= mid)
        queryTree(node * 2, l, mid, ql, qr);
    if (qr >= mid + 1)
        queryTree(node * 2 + 1, mid + 1, r, ql, qr);
}

int main()
{
    ios::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    int n, m;
    fin >> n >> m;

    for (int i = 1; i <= n; i++)
        fin >> vec[i];

    buildTree(1, 1, n);

    for (int i = 1; i <= m; i++)
    {
        int op, x, y;
        fin >> op >> x >> y;
        if (op == 0)
        {
            maxx = INT_MIN;
            queryTree(1, 1, n, x, y);
            fout << maxx << "\n";
        }
        else
            updateTree(1, 1, n, x, y);
    }

    return 0;
}