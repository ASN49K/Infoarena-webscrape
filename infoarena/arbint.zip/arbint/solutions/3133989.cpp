#include <fstream>
#include <iostream>
using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

int m, n, v[100005], arbint[200010], t, a, b, maxim;

void update(int nod, int st, int dr, int poz, int val)
{
    if(st == dr)
    {
        arbint[nod] = val;
        return;
    }

    int m = (st+dr)/2;
    if(m >= poz)
        update(2*nod, st, m, poz, val);
    else
        update(2*nod+1, m+1, dr, poz, val);
    arbint[nod] = max(arbint[2*nod], arbint[2*nod+1]);
}

void query(int nod, int st, int dr)
{
    if(a <= st && dr <= b)
    {
        maxim = max(maxim, arbint[nod]);
        return;
    }

    int m = (st+dr)/2;
    if(a <= m)
        query(2*nod, st, m);
    if(m < b)
        query(2*nod+1, m+1, dr);
}


void citire()
{
    f >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        f >> v[i];
        update(1, 1, n, i, v[i]);
    }
}

int main()
{
    citire();

    while(m--)
    {
        f >> t >> a >> b;
        if(t == 0)
        {
            maxim = 0;
            query(1, 1, n);
            g << maxim << '\n';
        }
        else
            update(1, 1, n, a, b);
    }
}
