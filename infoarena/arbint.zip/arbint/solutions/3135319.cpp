#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
const int MAXN = 100000;
int arbore[4*MAXN];

void build(int a[], int v, int capatSt, int capatDr) {
    if (capatSt == capatDr) {
        arbore[v] = a[capatSt];
    } else {
        int mij = (capatSt + capatDr) / 2;
        build(a, v*2, capatSt, mij);
        build(a, v*2+1, mij+1, capatDr);
        arbore[v] = max(arbore[v*2], arbore[v*2+1]);
    }
}

int getMaxim(int v, int capatSt, int capatDr, int st, int dr) {
    if (st > dr)
        return -1;
    if (st == capatSt && dr == capatDr)
        return arbore[v];
    int mij = (capatSt + capatDr) / 2;
    return max(getMaxim(v*2, capatSt, mij, st, min(dr, mij)),
               getMaxim(v*2+1, mij+1, capatDr, max(st, mij+1), dr));
}

void update(int v, int capatSt, int capatDr, int pozitie, int valoare_noua) {
    if (capatSt == capatDr) {
        arbore[v] = valoare_noua;
    } else {
        int mij = (capatSt + capatDr) / 2;
        if (pozitie <= mij)
            update(v*2, capatSt, mij, pozitie, valoare_noua);
        else
            update(v*2+1, mij+1, capatDr, pozitie, valoare_noua);
        arbore[v] = max(arbore[v*2], arbore[v*2+1]);
    }
}

int main() {
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    int N, M;
    fin >> N >> M;
    int A[N];
    for(int i = 0; i < N; i++) {
        fin >> A[i];
    }
    build(A, 1, 0, N-1);
    for(int i = 0; i < M; i++) {
        int op, a, b;
        fin >> op >> a >> b;
        a--; // 0-indexing
        if(op == 0) {
            int max_val = getMaxim(1, 0, N-1, a, b-1);
            fout << max_val << "\n";
        } else if(op == 1) {
            update(1, 0, N-1, a, b);
        }
    }

    fin.close();
    fout.close();
    return 0;
}
