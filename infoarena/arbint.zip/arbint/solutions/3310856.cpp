#include <fstream>
using namespace std;
ifstream cin ("arbint.in");
ofstream cout ("arbint.out");
int v[400001];
void update(int pos)
{
    if(pos==0)
        return;
    v[pos]=max(v[pos*2],v[pos*2+1]);
    update(pos/2);
}
int query(int st,int dr, int qst,int qdr,int node )
{
    if(dr< qst or st>qdr)
        return 0;
    if(st>=qst and dr<=qdr)
        return v[node];
    int mij=(st+dr)/2;
    int stval=query(st, mij, qst,qdr,node*2);
    int drval=query(mij+1,dr,qst,qdr,node*2+1);
    return max(stval,drval);
}
int main(){
    int n,m;
    cin>>n>>m;
    int sizes=1;
    while(sizes<=n)
        sizes=(sizes<<1);
    for(int i=sizes;i<n+sizes;i++)
        cin>>v[i];
    for(int i=sizes;i<n+sizes;i++)
        update(i/2);
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        cin>>c>>a>>b;
        if(c==0)
        {
                for(int i=1;i<n+sizes;i++)
                    cout<<i<<' ';
                cout<<'\n';
                for(int i=1;i<n+sizes;i++)
                    {
                        cout<<v[i]<<' ';
                        if(i+1>=10)
                            cout<<' ';
                    }
                cout<<"\n\n";
                cout<<query(1,sizes,a,b,1)<<"\n"<<a+sizes-1<<" "<<b+sizes-1<<"\n\n";
        }

        else
        {
            a+=sizes-1;
            v[a]=b;
            update(a/2);
        }
    }
    return 0;
}
