#include <bits/stdc++.h>
#define all(x) (x).begin(),(x).end()
using namespace std;

#ifndef DLOCAL
   #define cin fin
   #define cout fout
   ifstream cin("arbint.in");
   ofstream cout("arbint.out");
#endif

using ll = long long;
using ld = long double;

//#define int ll
#define sz(x) ((int)(x).size())

using pii = pair<int,int>;
using tii = tuple<int,int,int>;

template<typename T>
struct AINT {
   struct Node {
      int l, r;
      T data;
   };
   
   using ns = int;
   vector<Node> M;
   ns nil = 0;
   int newv(int a, int b, T c) { M.emplace_back(a, b, c); return sz(M) - 1; }
   AINT() { M.clear(); nil = newv(0, 0, T()); }
   
   
   ns root = nil;
   int L, R;
   void initaint(int l_, int r_) {
      L = l_;
      R = r_;
      nil = root = 0;
   }
   
   template<class CB> void walk(CB&& cb) { walk(cb, L, R); }
   template<class CB> void walk(CB&& cb, int l, int r) { root = walk(cb, l, r, root, L, R); }
   template<class CB> ns walk(CB&& cb, int l, int r, ns node, int cl, int cr) { 
      if(r < cl || cr < l) return node;
      if(node == nil) node = newv(nil, nil, T());
      if(l <= cl && cr <= r && !cb(node, cl, cr)) return node; 
      int mid = (cl + cr) >> 1;
      M[node].l = walk(cb, l, r, M[node].l, cl, mid);
      M[node].r = walk(cb, l, r, M[node].r, mid + 1, cr);
      M[node].data.pull(M[M[node].l].data, M[M[node].r].data);
      return node;
   }
   
   void erase() { M.clear(); M.shrink_to_fit(); }
};

const int inf = 1e9 + 500;

struct Max {
   int val;
   Max(int x = -inf): val(x) {;}
   void pull(const Max& a, const Max& b) {val = max(a.val, b.val); }
};

struct MaxAint : AINT<Max> {
   void upd(int p, int x) {
      walk([&](ns node, int cl, int cr) {
         M[node].data.val = x;
         return 0;
      }, p, p);
   }
   int query(int l, int r) {
      int mx = -1;
      walk([&](ns node, int cl, int cr) {
         mx = max(mx, M[node].data.val);
         return 0;
      }, l, r);
      return mx;
   }
   void init(vector<int> v) {
      initaint(1, sz(v) - 1);
      walk([&](ns node, int cl, int cr) {
         if(cl != cr) return 1;
         M[node].data.val = v[cl];
         return 0;
      }, 1, sz(v) - 1);
   }
};

signed main() {
   cin.tie(0) -> sync_with_stdio(0);
   int n, q;
   cin >> n >> q;
   vector<int> v(n + 1);
   for(auto &x : v | views::drop(1)) cin >> x;
   MaxAint aint;
   aint.init(v);
   for(int i = 0, t, x, y; i < q; i++) {
      cin >> t >> x >> y;
      if(t == 0)
         cout << aint.query(x, y) << '\n';
      else 
         aint.upd(x, y);
   }
}

/**
      Binecuvanteaza Doamne Ukraina.
--
*/ 
