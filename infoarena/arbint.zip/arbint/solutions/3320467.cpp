#include <bits/stdc++.h>
using namespace std;
ifstream fin("experimente.in");
ofstream fout("experimente.out");
#define cin fin
#define cout fout



int main()
{
    int n, m;
    cin >> n >> m;
    vector<bool> v(n);
    vector<int> res(m + 1);
    for(int i = 1; i <= m; i++) {
        int x, y, ct = 0;
        cin >> x >> y;
        if(i == 1) {
            if(x <= y) {
                for(int j = x; j <= y; j++) v[j] = true, ct++;
            }
            else {
                for(int j = x; j < n; j++) v[j] = true, ct++;
                for(int j = 0; j <= y; j++) v[j] = true, ct++;
            }
            res[1] = ct;
            cout << ct << endl;
            continue;
        }
        else {
            int s = (x + res[i - 1]) % n;
            int f = (y + res[i - 1]) % n;

            if(s <= f) {
                for(int j = 0; j < n; j++) {
                    if(v[j] && s <= j && j <= f) ct++;
                    else v[j] = false;
                }
            }
            else {
                for(int j = 0; j < n; j++) {
                    if(v[j] && j <= s && f <= j) ct++;
                    else v[j] = false;
                }
            }
            res[i] = ct;
            cout << ct << endl;

        }
    }


    return 0;

}
