#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
using ll = long long;
typedef tree <ll, null_type, less_equal<ll>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
template <class T> using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>; 
//priority_queue <ll, vector<ll>, greater<ll>> q;

struct ST {
    #define vl v * 2 + 1
    #define vr v * 2 + 2

    const int inf = 1e9 + 1;

    int n;
    vector <int> t;

    ST() {}
    ST(int _n) {
        n = _n;
        t.resize(4 * n + 10);
    }

    void init(int _n) {
        n = _n;
        t.resize(4 * n + 10);
    }

    void build(const vector <int>& a, int v, int tl, int tr) {
        if (tl == tr) {
            t[v] = a[tl];
            return;
        }

        int tm = (tl + tr) / 2;
        build(a, vl, tl, tm);
        build(a, vr, tm + 1, tr);
        t[v] = max(t[vl], t[vr]);
    }

    void build(const vector <int>&a) {
        build(a, 0, 0, n - 1);
    }

    void upd(int v, int tl, int tr, int pos, int val) {
        if (tl > pos or tr < pos) {
            return;
        }

        if (tl == pos and pos == tr) {
            t[v] = val;
            return;
        }

        int tm = (tl + tr) / 2;
        upd(vl, tl, tm, pos, val);
        upd(vr, tm + 1, tr, pos, val);
        t[v] = max(t[vl], t[vr]);
    }

    void upd(int pos, int val) {
        upd(0, 0, n - 1, pos, val);
    }

    int query(int v, int tl, int tr, int l, int r) {
        if (tl > r or tr < l) {
            return -inf;
        }

        if (l <= tl and tr <= r) {
            return t[v];
        }

        int tm = (tl + tr) / 2;
        int L = query(vl, tl, tm, l, r);
        int R = query(vr, tm + 1, tr, l, r);
        return max(L, R);
    }

    int query(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    ifstream f("arbint.in");
    ofstream g("arbint.out");
    int n, m;
    f >> n >> m;
    vector<int> a(n);
    for(int i = 0; i < n; i++) {
        f >> a[i];
    }

    ST T(n);
    T.build(a);
    for(int i = 1; i <= m; i++) {
        int t;
        f >> t;
        if(t == 0) {
            int l, r;
            f >> l >> r;
            g << T.query(l - 1, r - 1) << "\n"; 
        }
        else {
            int poz, val;
            f >> poz >> val;
            T.upd(poz - 1, val);
        }
    }
    return 0; 
}