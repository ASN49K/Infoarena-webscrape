#include <fstream>
#include <vector>
#include <cmath>
#include <climits>

const int NMAX=1e5+8;
int n,q;
int a[NMAX];

struct segtree {
    std::vector<int> aint;
    segtree(int n) {
        aint=std::vector<int>(4*n+8);
    }

    void build(int nod,int st,int dr) {
        if(st==dr) {
            aint[nod]=a[st];
            return;
        }

        int mij=(st+dr)/2;
        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);
        aint[nod]=std::max(aint[2*nod],aint[2*nod+1]);
    }

    void update(int nod,int st,int dr,int pos,int ce) {
        if(st==dr) {
            aint[nod]=ce;
            return;
        }

        int mij=(st+dr)/2;
        if(pos<=mij) {
            update(2*nod,st,mij,pos,ce);
        }
        else {
            update(2*nod+1,mij+1,dr,pos,ce);
        }
        aint[nod]=std::max(aint[2*nod],aint[2*nod+1]);
    }

    int query(int nod,int st,int dr,int qst,int qdr) {
        if(st>dr || st>qdr || dr<qst) {
            return INT_MIN;
        }

        if(st>=qst && dr<=qdr) {
            return aint[nod];
        }

        int mij=(st+dr)/2;
        return std::max(query(2*nod,st,mij,qst,qdr),query(2*nod+1,mij+1,dr,qst,qdr));
    }
};

int main() {

    std::ifstream fin("arbint.in");
    std::ofstream fout("arbint.out");

    std::ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> q;
    for(int i=1; i<=n; i++) {
        fin >> a[i];
    }

    segtree at(n);
    at.build(1,1,n);

    while(q--) {
        int tip,st,dr;
        fin >> tip >> st >> dr;

        if(!tip) {
            fout << at.query(1,1,n,st,dr) << '\n';
        }
        else {
            at.update(1,1,n,st,dr);
        }
    }

    return 0;
}