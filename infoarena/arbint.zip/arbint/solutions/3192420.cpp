#include <bits/stdc++.h>
using namespace std;
int aint[262149], v[100005];
void build(int nod, int st, int dr){
    if(st==dr)
        aint[nod]=v[st];
    else{
        int mid=(st+dr)/2;
        build(nod*2, st, mid);
        build(nod*2+1, mid+1, dr);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }
}
void update(int nod, int st, int dr, int pos, int new_val){
    if(st==dr && st == pos)
        aint[nod]=new_val;
    else{
        int mid=(st+dr)/2;
        if(pos<=mid)
            update(nod*2, st, mid, pos, new_val);
        else
            update(nod*2+1, mid+1, dr, pos, new_val);
        aint[nod]=max(aint[nod*2], aint[nod*2+1]);
    }
}
int query(int nod, int st, int dr, int left, int right){
    if(left>right)
        return 0;
    else if(left==st && right==dr)
        return aint[nod];
    else{
        int mid=(st+dr)/2;
        return max(query(nod*2, st, mid, left, min(mid, right)),
        query(nod*2+1, mid+1, dr, max(mid+1, left), right));
    }
}
int main(){
    ifstream cin ("arbint.in");
    ofstream cout ("arbint.out");
    int m, n, tip, a, b;
    cin >> n >> m;
    for(int i=1; i<=n; i++)
        cin >> v[i];
    build(1, 1, n);
    for(int i=1; i<=m; i++){
        cin >> tip >> a >> b;
        if(tip==0)
            cout << query(1, 1, n, a, b) << "\n";
        else
            update(1, 1, n, a, b);
    }
    return 0;
}
