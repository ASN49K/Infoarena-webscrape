#include <fstream>
#define NMAX (int)(1e5+5)

using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int aint[4*NMAX], v[NMAX];

void build(int nod, int l, int r)
{
    if(l==r)
    {
        aint[nod]=v[l];
        return;
    }
    build(2*nod, l, (l+r)/2);
    build(2*nod+1, (l+r)/2+1, r);
    aint[nod]=max(aint[2*nod], aint[2*nod+1]);
}

void update(int nod, int l, int r, int pos, int val)
{
    if(pos<l || r<pos)
        return;
    if(l==r)
    {
        aint[nod]=val;
        return;
    }
    update(2*nod, l, (l+r)/2, pos, val);
    update(2*nod+1, (l+r)/2+1, r, pos, val);
    aint[nod]=max(aint[2*nod], aint[2*nod+1]);
}

int query(int nod, int l, int r, int ql, int qr)
{
    if(r<ql || qr<l)
        return 0;
    if(ql<=l && r<=qr)
        return aint[nod];
    return max(query(2*nod, l, (l+r)/2, ql, qr), query(2*nod+1, (l+r)/2+1, r, ql, qr));
}

int main()
{
    int n, m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    build(1, 1, n);
    for(int i=1;i<=m;i++)
    {
        int t, a, b;
        cin>>t>>a>>b;
        if(t)
            update(1, 1, n, a, b);
        else
            cout<<query(1, 1, n, a, b)<<'\n';
    }
    return 0;
}