#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX=1e5+5;
const int INF=-1e9;
int v[NMAX],arb[4*NMAX],poz[NMAX];

void generate(int node,int left,int right){
    if(left==right){
        poz[left]=node;
        arb[node]=v[left];
    }
    else{
        int mid=(left+right)/2;
        generate(2*node,left,mid);
        generate(2*node+1,mid+1,right);
        arb[node]=max(arb[node*2],arb[node*2+1]);
    }
}

void update(int node){
    while(node!=0){
        node/=2;
        arb[node]=max(arb[node*2],arb[node*2+1]);
    }
}

int query(int node,int node_left,int node_right,int query_left,int query_right){
    int rightmax=INF,leftmax=INF;
    if(node_left>=query_left && node_right<=query_right){
        return arb[node];
    }
    int mid=(node_left+node_right)/2;
    if(query_left<=mid){
        leftmax=query(node*2,node_left,mid,query_left,query_right);
    }
    if(query_right>=mid+1){
        rightmax=query(node*2+1,mid+1,node_right,query_left,query_right);
    }
    return max(leftmax,rightmax);
}

int main()
{
    int n,m,type,a,b;
    fin>>n>>m;
    for(int i=1;i<=n;++i){
        fin>>v[i];
    }
    generate(1,1,n);
    for(int i=1;i<=m;++i){
        fin>>type>>a>>b;
        if(type){
            arb[poz[a]]=b;
            update(poz[a]);
        }
        else{
            fout<<query(1,1,n,a,b)<<"\n";
        }
    }
    return 0;
}
