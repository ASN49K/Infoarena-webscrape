#include <iostream>
#include <fstream>
using namespace std;

const int MAX=100005;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int v[MAX];
void change(int st, int dr, int node, int p, int x){
    if (st==dr){
        v[node]=x;
        return;
    }
    int mij=(st+dr)/2;
    if(p<=mij){
        change(st, mij, 2*node, p, x);
    }
    else
        change(mij+1, dr, 2*node+1, p ,x);
    v[node]=max(v[2*node], v[node*2+1]);
}
int querry(int st, int dr, int node, int a, int b){
    int aux=-1, aux2=-1;

    if(a<=st && dr<=b){
        return v[node];
    }
    int mij=(st+dr)/2;

    if(a<=mij){
        aux=querry(st, mij, 2*node,a,b);
    }
    if(mij<b){
        aux2=querry(mij+1, dr, 2*node+1,a, b);
    }
    return max(aux,aux2);
}
int main()
{
    int n, m, i, op, x, y;
    fin>>n>>m;
    for(i=1;i<=n;i++){
        fin>>x;
        change(1, n, 1, i, x);
    }
    for(i=1;i<=m;i++){
        fin>>op>>x>>y;
        if(op==0){
            fout<<querry(1, n, 1, x, y)<<"\n";
        }
        else
            change(1,n,1,x,y);
    }

    return 0;
}
