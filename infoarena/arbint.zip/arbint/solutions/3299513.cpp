/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
//#include <fstream>
using namespace std;

/*ifstream fin("arbint.in");
ofstream fout("arbint.out");*/

int vect[100000] = {0}, tree[400000] = {0};

void arbint(int nod, int st, int dr){
    if (st==dr){
        tree[nod]=vect[st];
        return;
    }
    int mij = (st + dr)/2;
    arbint(2 * nod, st, mij);
    arbint(2 * nod + 1, mij + 1, dr);
    if (tree[2 * nod]>tree[2 * nod + 1])
        tree[nod] = tree[2 * nod];
    else
        tree[nod] = tree[2 * nod + 1];
}

int maximul(int nod, int st, int dr, int x, int y){
    if (x <= st && dr <= y)
        return tree[nod];
    int mij = (st + dr) / 2, aux = -1;
    if (x <= mij){
        aux = maximul(2 * nod, st, mij, x, y);
    }
    if (y > mij){
        aux = maximul(2 * nod + 1, mij + 1, dr, x, y);
    }
    return aux;
}

void schimba(int nod, int st, int dr, int x, int y){
    if (st == dr){
        tree[nod] = y;
        return;
    }
    int mij = (st + dr)/2;
    if (x <= mij)
        schimba(2 * nod, st, mij, x, y);
    else
        schimba(2 * nod + 1, mij + 1, dr, x, y);
    if (tree[2 * nod] > tree[2 * nod + 1])
        tree[nod] = tree[2 * nod];
    else
        tree[nod] = tree[2 * nod + 1];
}

int main(){
    
    int m,n,nr,x,y;
    cin>>n>>m;
    for (int i=1; i<=n; i++)
        cin >> vect[i];
    arbint(1, 1, n); 
    for (int i=0; i<m; i++)
    {
        cin>>nr>>x>>y;
        if (nr == 0)
            cout<<maximul(1, 1, n, x, y)<<"\n"; 
        else
            schimba(1, 1, n, x, y);
    }
    return 0;
}