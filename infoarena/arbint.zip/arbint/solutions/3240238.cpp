#include <iostream>
#include <fstream>#define DIM 100000
using namespace std;
ifstream f("arbint.in");ofstream g("arbint.out");int AINT[4 * DIM + 5], V[DIM + 5];int N, M, op, a, b;void build(int node, int left, int right){	if (left == right)		AINT[node] = V[left];	else	{		int middle = (left + right) / 2;		build(node * 2, left, middle);		build(node * 2 + 1, middle + 1, right);		AINT[node] = max(AINT[node * 2], AINT[node * 2 + 1]);	}}void update(int node, int left, int right, int pos, int value){	if (left == right)		AINT[node] = value;	else	{		int middle = (left + right) / 2;		if (pos <= middle)			update(node * 2, left, middle, pos, value);		if (pos > middle)			update(node * 2 + 1, middle + 1, right, pos, value);		AINT[node] = max(AINT[node * 2], AINT[node * 2 + 1]);	}}int query(int node, int left, int right, int a, int b){	if (a <= left && right <= b)		return AINT[node];	else	{		int middle = (left + right) / 2;		if (b <= middle)			return query(node * 2, left, middle, a, b);		if (middle + 1 <= a)			return query(node * 2 + 1, middle + 1, right, a, b);		return max(query(node * 2, left, middle, a, b), query(node * 2 + 1, middle + 1, right, a, b));	}}
int main()
{	f >> N >> M;	for (int i = 1; i <= N; i++)		f >> V[i];	build(1, 1, N);	while (M--)	{		f >> op >> a >> b;		if (op == 0)			g << query(1, 1, N, a, b) << '\n';		else // if (op == 1)			update(1, 1, N, a, b);	}
	f.close();	g.close();
    return 0;
}
