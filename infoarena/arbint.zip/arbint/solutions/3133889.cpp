//
// Created by Octavian Farcasi on 27.05.2023.
//
#include<iostream>
#include<fstream>

int maxim(int x, int y){
    if(x>y)
        return x;
    return y;
}

//int get_dimensiune(int numar){
//    int x=1;
//    while(x<numar)
//        x*=2;
//    return numar*2-1;
//}

void creare_arb(int valori[],int arb_int[], int low, int high, int poz){
    if(low==high){
        arb_int[poz]=valori[low];
        return;
    }
    int mijloc=(low+high)/2;
    creare_arb(valori,arb_int,low,mijloc,poz*2);
    creare_arb(valori,arb_int,mijloc+1,high,(poz*2)+1);
    arb_int[poz]= maxim(arb_int[poz*2],arb_int[(poz*2)+1]);
}

void actualizare(int arb_int[], int low, int high, int radacina,int pozitie, int valoare){
    if(low==high){
        arb_int[radacina]=valoare;
        return;
    }
    int mijloc = (low+high)/2;
    if (pozitie<=mijloc)                                                            //in functie de cum e pozitia fata de mijloc, mergem pe stanga sau pe dreapta
        actualizare(arb_int,low,mijloc,radacina*2,pozitie,valoare);
    else
        actualizare(arb_int,mijloc+1,high,(radacina*2)+1,pozitie,valoare);
    arb_int[radacina]= maxim(arb_int[radacina*2],arb_int[(radacina*2)+1]);
}

int afla_maximul(int arb_int[],int low, int high, int x, int y, int radacina) {
    if(x<=low && high<=y)
        return arb_int[radacina];                                               //intervalul este complet inclus si nodul contine valoarea cautata
    int mijloc=(low + high)/2;
    int max_stanga = -1, max_dreapta = -1;
    if(mijloc>=x)                                                               //ne ducem pe stanga si cautam maximul
        max_stanga = afla_maximul(arb_int,low,mijloc, x, y,radacina*2);
    if(mijloc < y)                                                              //ne ducem pe dreapta si cautam maximul
        max_dreapta = afla_maximul(arb_int,mijloc+1,high, x, y,(radacina*2)+1);
    return maxim(max_stanga, max_dreapta);                                //aflam maximul dintre cele doua
}


int main(){
    std::ifstream f("arbint.in");
    std::ofstream g("arbint.out");

    int n,m,operatie,a,b,dimensiune;
    f>>n>>m;
    dimensiune= 2*n;
    int arb_int[dimensiune], valori[n+1];
    for(int i=1;i<=n;i++)
        f>>valori[i];
    for(int i=0;i<dimensiune;i++)
        arb_int[i]=-1;
    creare_arb(valori,arb_int,1,n,1);
    for(int i=1;i<=m;i++){
        f>>operatie>>a>>b;
        switch (operatie) {
            case 0:
                g<<afla_maximul(arb_int,1,n,a,b,1)<<"\n";
                break;
            case 1:
                actualizare(arb_int,1,n,1,a,b);
                valori[a]=b;
                break;
        }
    }
    f.close();
    g.close();
    return 0;
}