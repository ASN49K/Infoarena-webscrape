#include <fstream>

using namespace std;

const int NMAX = 100001;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, ai[4 * NMAX];

void update(int rad, int st, int dr, int poz, int val)
{
    if(st == dr) ai[rad] = val;
    else
    {
        int mij = (st + dr) / 2;
        if(poz <= mij) update(2 * rad, st, mij, poz, val);
        else update(2 * rad + 1, mij + 1, dr, poz, val);
        ai[rad] = max(ai[2 * rad], ai[2 * rad + 1]);
    }
}

int query(int rad, int st, int dr, int a, int b)
{
    if(a <= st && b >= dr) return ai[rad];
    int mij = (st + dr) / 2, r1 = 0, r2 = 0;
    if(a <= mij) r1 = query(2 * rad, st, mij, a, b);
    if(b > mij) r2 = query(2 * rad + 1, mij + 1, dr, a, b);
    return max(r1, r2);
}

int main()
{
    int op, a, b;
    fin >> n >> m;
    for(int i = 1; i <= n; ++i)
    {
        fin >> a;
        update(1, 1, n, i, a);
    }
    while(m--)
    {
        fin >> op >> a >> b;
        if(op) update(1, 1, n, a, b);
        else fout << query(1, 1, n, a, b) << '\n';
    }
    return 0;
}
