#include <fstream>
using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

#define int long long

int n,arr[100005],v[500005],mx;

void build(int l,int r,int nd)
{
    if (l==r)
    {
        v[nd]=arr[l];
        return;
    }
    int mid=(l+r)/2;
    build(l,mid,nd*2);
    build(mid+1,r,nd*2+1);
    v[nd]=max(v[nd*2],v[nd*2+1]);
}

void update(int l,int r,int pos,int val,int nd)
{
    if (l==r)
    {
        v[nd]=val;
        return;
    }
    int mid=(l+r)/2;
    if (pos<=mid) update(l,mid,pos,val,nd*2);
    else update(mid+1,r,pos,val,nd*2+1);
    v[nd]=max(v[nd*2],v[nd*2+1]);

}

void sol(int l,int r,int ql,int qr,int nd)
{
    if (r<ql||l>qr) return;
    if (ql<=l&&r<=qr)
    {
        mx=max(v[nd],mx);
        return;
    }
    int mid=(l+r)/2;
    sol(l,mid,ql,qr,nd*2);
    sol(mid+1,r,ql,qr,nd*2+1);
}

int32_t main()
{
    int n,q;
    cin>>n>>q;
    for (int i=1; i<=n; i++) cin>>arr[i];
    build(1,n,1);
    for (int i=1; i<=q; i++)
    {
        int cer,a,b;
        cin>>cer>>a>>b;
        if (cer==0) {mx=0; sol(1,n,a,b,1); cout<<mx<<"\n";}
        else update(1,n,a,b,1);
    }
}
