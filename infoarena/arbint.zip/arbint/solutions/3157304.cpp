#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int maxn = 1e5;
int arb[4*maxn];
int v[maxn + 1];

int query(int nod, int currleft, int currright, int left, int right) {
    //cout << currleft << ' ' << currright << ' ' << left << ' ' << right << '\n';
    if (currleft >= left && currright <= right)
        return arb[nod];
    int mij = (currleft + currright)/2;
    if (right <= mij)
        return query(nod<<1, currleft, mij, left, right);
    if (left > mij)
        return query((nod<<1)|1, mij + 1, currright, left, right);
    return max(query(nod<<1, currleft, mij, left, right), query((nod<<1)|1, mij + 1, currright, left, right));
}

void update(int root, int left, int right, int poz, int val) {
    if (left == right) {
        arb[root] = val;
        return;
    }
    int mij = (left + right)/2;
    if (poz <= mij)
        update(root<<1, left, mij, poz, val);
    else
        update((root<<1)|1, mij + 1, right, poz, val);
    arb[root] = max(arb[root<<1], arb[(root<<1)|1]);
}

void build(int root, int left, int right) {
    if (left == right) {
        arb[root] = v[left];
        return;
    }
    int mij = (left + right)/2;
    build(root<<1, left, mij);
    build((root<<1)|1, mij + 1, right);
    arb[root] = max(arb[root<<1], arb[(root<<1)|1]);
}

int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
    build(1, 1, n);
    for (int i = 0; i < m; i++) {
        int op, a, b;
        fin >> op >> a >> b;
        if (op == 0)
            fout << query(1, 1, n, a, b) << '\n';
        else
            update(1, 1, n, a, b);
    }

    return 0;
}