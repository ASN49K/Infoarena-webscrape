using namespace std;
#include<iostream>
#include<fstream>

ifstream fin("arbint.in");
ofstream fout("arbint.out");

#define NMAX 500005

int AINT[4*NMAX];

///nod = 1, st = 1, dr = 8

void update(int nod, int st, int dr, int pos, int val) {
    if (st == dr) {
        AINT[nod] = val;
        return;
    }
    
    int mid = (st+dr)/2;
    if (pos <= mid) {
        update(2*nod, st, mid, pos, val);
    } else {
        update(2*nod+1, mid+1, dr, pos, val);
    }
    
    AINT[nod] = max(AINT[2*nod], AINT[2*nod+1]);
}

int query(int nod, int st, int dr, int L, int R) {
    if (L <= st && dr <= R) {
        return AINT[nod];
    }
    
    int mid = (st+dr)/2;
    int a = 0, b = 0;
    
    if (L <= mid) {
        a = query(nod*2, st, mid, L, R);
    }
    
    if (mid < R) {
        b = query(nod*2+1, mid+1, dr, L, R);
    }
    
    return max(a, b);
}

int n, m;
int v[NMAX];

int main() {
    
    fin >> n >> m;
    for (int i = 1; i<=n; i++) {
        fin >> v[i];
        update(1, 1, n, i, v[i]);
    }
    
    for (int i = 1; i<=m; i++) {
        bool op;
        int a, b;
        fin >> op >> a >> b;
        
        if (op == 0) {
            fout << query(1, 1, n, a, b) << "\n";
        } else {
            update(1, 1, n, a, b);
        }
    }
    
    return 0;
}
