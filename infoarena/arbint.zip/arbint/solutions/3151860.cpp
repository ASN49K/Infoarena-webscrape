#include <bits/stdc++.h>

struct Aint {
    int lroot, rroot;
    std::vector<int> aint;
    std::vector<int> lazy;

    explicit Aint(int _lroot, int _rroot) {
        lroot = _lroot;
        rroot = _rroot;
        int len = rroot - lroot + 1;

        aint.resize(1 + 4 * len);
        lazy.resize(1 + 4 * len);
    }

    void push_lazy(int node, int l, int r) {
        if (aint[node] == -1) return;
        aint[node] = lazy[node];

        if (l < r) {
            aint[2 * node] = aint[node];
            aint[2 * node + 1] = aint[node];
        }

        aint[node] = -1;
    }

    void _update(int i, int j, int val, int l, int r, int node) {
        if (j < l || r < i || j < i) return;

        if ()
    }
};

int main() {

    return 0;
}

