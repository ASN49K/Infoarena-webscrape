#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define N_MAX 100010

int tree[4 * N_MAX + 10];
int V[N_MAX + 10];

int return_maxim(int a, int b){
    if (a > b){
        return a;
    }
    return b;
}

void build_tree(int node, int left, int right)
{
    if (left == right){
        tree[node] = V[left];
        return;
    }

    int mid = (left + right) / 2;
    build_tree(2 * node, left, mid);
    build_tree(2 * node + 1, mid + 1, right);

    tree[node] = return_maxim(tree[2 * node], tree[2 * node + 1]);
}

int query(int node, int left, int right, int x, int y)
{
    if (x <= left && right <= y){
        return tree[node];
    }

    int ans = INT32_MIN;  // dam valoare foarte mare;
    int mid = (left + right) / 2;

    if (x <= mid){
        ans = query(2 * node, left, mid, x, y);
    }
    if (y > mid){
        int temp = query(2 * node + 1, mid + 1, right, x, y);
        ans = return_maxim(ans, temp);
    }

    return ans;
}

void update_tree (int node, int left, int right, int index, int value)
{
    if (left == right){
        tree[node] = value;
        return;
    }

    int mid = (left + right) / 2;
    if (index <= mid){
        update_tree(2 * node, left, mid, index, value);
    }
    else{
        update_tree(2 * node + 1, mid + 1, right, index, value);
    }

    tree[node] = return_maxim(tree[2 * node], tree[2 * node + 1]);
}

int main(void)
{
    FILE *fin = fopen("arbint.in", "r");
    FILE *fout = fopen("arbint.out", "w");

    int n, m;
    fscanf(fin, "%d %d", &n, &m);
    // scanf("%d %d", &n, &m);

    printf("n = %d; m = %d\n\n",n,m);

    for (int i = 0; i < n; i++){ //indexat de la 1
        // scanf("%d", &V[i + 1]);
        fscanf(fin,"%d",&V[i + 1]);
    }

    for (int i = 1; i < n + 1; i++){
        printf("V[%d] = %d\n", i, V[i]);
    }

    build_tree(1, 1, n);

    for (int i = 0; i < m; i++){
        int option;
        int x;
        int y;
        // scanf("%d %d %d", &option , &x, &y);
        // printf("\n optiune: %d %d %d \n", option, x, y);
        fscanf(fin, "%d %d %d", &option , &x, &y);

        if (option == 0){
            int res = query(1, 1, n, x ,y);
            // printf("%d\n", res);
            fprintf(fout, "%d\n", res);
            continue;
        }
        update_tree(1, 1, n, x, y);
    }
    

    fclose(fin);
    fclose(fout);
    return 0;
}