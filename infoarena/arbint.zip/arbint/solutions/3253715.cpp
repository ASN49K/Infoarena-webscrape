#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

int N, M;
vector<int> arbore(4 * 100000);

void UPDATE(int nod, int st, int dr, int a, int b){
    if(st == dr){
        arbore[nod] = b;
        return;
    }
    int mij = (st + dr) / 2;
    if(a <= mij)
        UPDATE(nod * 2, st, mij, a, b);
    else
        UPDATE(nod * 2 + 1, mij + 1, dr, a, b);
    arbore[nod] = max(arbore[nod * 2], arbore[nod * 2 + 1]);
}

void QUERY(int nod, int st, int dr, int x, int y, int &maxx){
    if(x <= st && dr <= y){
        maxx = max(maxx, arbore[nod]);
        return;
    }
    int mij = (st + dr) / 2;
    if(x <= mij)
        QUERY(nod * 2, st, mij, x, y, maxx);
    if(mij + 1 <= y)
        QUERY(nod * 2 + 1, mij + 1, dr, x, y, maxx);
}

int main()
{
    in >> N >> M;
    for(int i = 1; i <= N; i++){
        int x;
        in >> x;
        UPDATE(1, 1, N, i, x);
    }
    for(int i = 0; i < M; i++){
        int k;
        in >> k;
        if(k == 0){
            int x, y;
            in >> x >> y;
            int maxx = -1;
            QUERY(1, 1, N, x, y, maxx);
            out << maxx << "\n";
        }
        else{
            int a, b;
            in >> a >> b;
            UPDATE(1, 1, N, a, b);
        }
    }
    return 0;
}
