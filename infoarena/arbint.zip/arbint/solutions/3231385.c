#include <stdio.h>

int arbore[100001];

int maxim(int x,int y)
{
    if(x>y)
        return x;
    return y;
}

void update(int nod,int st,int dr,int p,int val)
{
    if(st==dr)//este frunza
    {
       arbore[nod]=val;
       return ;
    }
    int mij=(st+dr)/2;
    if(p<=mij)//e in prima jumatate
        update(2*nod,st,mij,p,val);
    else//e in a doua jum
        update(2*nod+1,mij,dr,p,val);
    arbore[nod]=maxim(arbore[2*nod],arbore[2*nod+1]);
}

int query(int nod,int st,int dr,int a,int b)
{
    if(a>dr||b<st)
        return -1;
    if(a<=st && dr<=b)//intervalul [st,dr] e continut total in [a,b]
        return arbore[nod];

    int mij=(st+dr)/2;
    int max_st=query(2*nod,st,mij,a,b);
    int max_dr=query(2*nod+1,mij,dr,a,b);
    return maxim(max_st,max_dr);
}

int main(int argc,char **argv)
{
    FILE *f1=fopen("arbint.in","r"),*f2=fopen("arbint.out","w");
    if(!f1||!f2)
    {
        perror(NULL);
        exit(-1);
    }
    int n,m;
    fscanf(f1,"%d %d",&n,&m);
    int val;
    for(int i=1;i<=n;i++)
    {
        fscanf(f1,"%d",&val);
        update(1,1,n,i,val);
    }
    int a,b,tip;
    for(int i=0;i<m;i++)
    {
        fscanf(f1,"%d %d %d",&tip,&a,&b);
        if(tip==0)
        {
            fprintf(f2,"%d\n",query(1,1,n,a,b));
        }
        else
        {
            update(1,1,n,a,b);
        }
    }
    if(fclose(f1)!=0||fclose(f2)!=0)
    {
        perror(NULL);
        exit(-1);
    }
    return 0;
}
