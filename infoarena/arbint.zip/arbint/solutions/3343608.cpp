#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int v[100009], aint[400009], n;
void init (int nod, int st, int dr)
{
    if (st==dr)
        aint[nod]=v[st];
    else
    {
        int mij=(st+dr)/2;
        init (2*nod, st, mij);
        init (2*nod+1, mij+1, dr);
        aint[nod]=max (aint[2*nod], aint[2*nod+1]);
    }
}
void init ()
{
    init (1, 1, n);
}
void update (int nod, int st, int dr, int poz, int val)
{
    if (st==dr)
        aint[nod]=val;
    else
    {
        int mij=(st+dr)/2;
        if (poz<=mij)
            update (2*nod, st, mij, poz, val);
        else
            update (2*nod+1, mij+1, dr, poz, val);
        aint[nod]=max (aint[2*nod], aint[2*nod+1]);
    }
}
void update (int poz, int val)
{
    update (1, 1, n, poz, val);
}
int query (int nod, int st, int dr, int l, int r)
{
    if (st==l && dr==r)
        return aint[nod];
    int mij=(st+dr)/2;
    if (r<=mij)
        return query (2*nod, st, mij, l, r);
    else if (l>mij)
        return query (2*nod+1, mij+1, dr, l, r);
    return max (query (2*nod, st, mij, l, mij), query (2*nod+1, mij+1, dr, mij+1, r));
}
int query (int l, int r)
{
    return query (1, 1, n, l, r);
}
signed main ()
{
    int q;
    f >> n >> q;
    for (int i=1; i<=n; i++)
        f >> v[i];
    init ();
    while (q--)
    {
        int tip, x, y;
        f >> tip >> x >> y;
        if (!tip) g << query (x, y) << '\n';
        else update (x, y);
    }
}
