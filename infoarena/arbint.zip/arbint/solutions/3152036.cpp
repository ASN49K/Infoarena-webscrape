#include <fstream>

using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

const int NMAX = 100001;

int v[NMAX], N, tree[4 * NMAX], Q;

void build(int nod, int st, int dr)
{
	if (st == dr)
	{
		tree[nod] = v[st];
	}
	else
	{
		int mij = (st + dr) / 2;
		build(2 * nod, st, mij);
		build(2 * nod + 1, mij + 1, dr);
		tree[nod] = max(tree[2 * nod], tree[2 * nod + 1]);
	}
}

int query(int nod, int stnodcurr, int drnodcurr, int st, int dr)
{
	if (stnodcurr >= st && drnodcurr <= dr)
	{
		return tree[nod];
	}
	else
	{
		int mid = (stnodcurr + drnodcurr) / 2;
		if (mid >= dr)
		{
			return query(2 * nod, stnodcurr, mid, st, dr);
		}
		if (mid < st)
		{
			return query(2 * nod + 1, mid + 1, drnodcurr, st, dr);
		}
		return max(query(2 * nod, stnodcurr, mid, st, dr), query(2 * nod + 1, mid + 1, drnodcurr, st, dr));
	}

}

void update(int nod, int stnodcurr, int drnodcurr, int pos, int val)
{
	if (stnodcurr == drnodcurr)
	{
		tree[nod] = val;
	}
	else
	{
		int mij = (stnodcurr + drnodcurr) / 2;
		if (pos <= mij)
		{
			update(2 * nod, stnodcurr, mij, pos, val);
		}
		else
		{
			update(2 * nod + 1, mij + 1, drnodcurr, pos, val);
		}
		tree[nod] = max(tree[2 * nod], tree[2 * nod + 1]);
	}
}


int main()
{
	cin >> N >> Q;
	for (int i = 1; i <= N; i++)
		cin >> v[i];
	build(1, 1, N);
	for (int i = 1; i <= Q; i++)
	{
		int cer;
		int x, y;
		cin >> cer >> x >> y;
		if (cer == 1)
		{
			cout << query(1, 1, N, x, y) << '\n';
		}
		else
		{
			update(1, 1, N, x, y);
		}
	}
}