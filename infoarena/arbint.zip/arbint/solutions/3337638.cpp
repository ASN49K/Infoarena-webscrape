#include <fstream>
#define NMAX 100001
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int n,q,v[NMAX],aint[4*NMAX],ans,val,poz,q_st,q_dr;
void build(int nod, int st, int dr)
{
    if (st==dr)
    {
        aint[nod]=v[st];
    }
    else{
        int m=(st+dr)>>1;
        build(2*nod, st, m);
        build(2*nod+1, m+1, dr);
        aint[nod]=max(aint[2*nod], aint[2*nod+1]);
    }
}
void update(int nod, int st, int dr)
{
    if (st==dr)
    {
        aint[nod]=val;
    }
    else{
        int m=(st+dr)>>1;
        if (poz<=m)
            update(2*nod, st, m);
        else
            update(2*nod+1, m+1, dr);
        aint[nod]=max(aint[2*nod], aint[2*nod+1]);
    }
}
void query(int nod, int st, int dr)
{
    if (st>=q_st && dr<=q_dr)
    {
        ans=max(ans, aint[nod]);
    }
    else{
        int m=(st+dr)>>1;
        if (q_st<=m)
            query(2*nod, st, m);
        if (q_dr>m)
            query(2*nod+1, m+1, dr);
    }
}
int main()
{
    fin>>n>>q;
    for (int i=1;i<=n;i++)
        fin>>v[i];
    build(1, 1, n);
    while (q--)
    {
        int op;
        fin>>op;
        if (op==0)
        {
            ans=-1;
            fin>>q_st>>q_dr;
            query(1, 1, n);
            fout<<ans<<"\n";
        }
        else{
            fin>>poz>>val;
            update(1, 1, n);
        }
    }

    return 0;
}
