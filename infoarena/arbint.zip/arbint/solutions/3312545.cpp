#include <bits/stdc++.h>

using namespace std;

struct SegTree {
  int n;
  vector<int> arr;

  SegTree(vector<int> rra) : n(rra.size()), arr(2 * n) {
    for (int i = 0; i < n; ++i) {
      arr[n + i] = rra[i];
    }
    for (int i = n - 1; i; --i) {
      arr[i] = max(arr[i << 1], arr[i << 1 | 1]);
    }
  }

  void put(int i, int x) {
    i += n;
    arr[i] = x;
    for (i >>= 1; i; i >>= 1) {
      arr[i] = max(arr[i << 1], arr[i << 1 | 1]);
    }
  }

  int get(int p, int q) {
    int x = 0;
    for (p += n, q += n; p <= q; p >>= 1, q >>= 1) {
      if (p & 1) {
        x = max(x, arr[p++]);
      }
      if (!(q & 1)) {
        x = max(x, arr[q--]);
      }
    }
    return x;
  }
};

int main() {
#ifndef LOCAL
  freopen("arbint.in", "r", stdin);
  freopen("arbint.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int N;
  int M;
  cin >> N >> M;
  vector<int> arr(N);
  for (int i = 0; i < N; ++i) {
    cin >> arr[i];
  }
  SegTree T(arr);
  for (; M--;) {
    int o;
    int a;
    int b;
    cin >> o >> a >> b;
    --a;
    --b;
    if (o) {
      T.put(a, b);
    } else {
      cout << T.get(a, b) << "\n";
    }
  }
  return 0;
}
