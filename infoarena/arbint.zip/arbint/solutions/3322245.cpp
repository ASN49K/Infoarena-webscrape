#include <vector>
#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

void update(vector<int>& aint, int p, int st, int dr, int poz, int val) {
    if (st == dr) {
        aint[p] = val;
        return;
    }
    int m = (st + dr) / 2;
    int fs = 2 * p;
    int fd = 2 * p + 1;
    if (poz <= m) {
        update(aint, fs, st, m, poz, val);
    }
    else {
        update(aint, fd, m + 1, dr, poz, val);
    }
    aint[p] = max(aint[fs], aint[fd]);
}
int query(vector<int>& aint, int p, int st, int dr, int a, int b) {
    if (a <= st && dr <= b) {
        return aint[p];
    }
    int m = (st + dr) / 2;
    int fs = 2 * p;
    int fd = 2 * p + 1;
    int rezSt = -1;
    int rezDr = -1;

    if (a <= m) {
        rezSt = query(aint, fs, st, m, a, b);
    }
    if (m + 1 <= b) {
        rezDr = query(aint, fd, m + 1, dr, a, b);
    }
    return max(rezSt, rezDr);
}

int main()
{
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    int n, m;
    fin >> n >> m;
    int logSup = (int)log2(n);
    if ((1 << logSup) < n)
        logSup++;
        
    vector<int> aint(1 << (logSup + 1), -1);

    for (int i = 1; i <= n; i++) {
        int aux;
        fin >> aux;
        update(aint, 1, 1, n, i, aux);
    }
    for (int i = 0; i < m; i++) {
        int tip;
        fin >> tip;
        if (tip == 0) {
            int a, b;
            fin >> a >> b;
            fout << query(aint, 1, 1, n, a, b) << '\n';
        }
        else {
            int poz, val;
            fin >> poz >> val;
            update(aint, 1, 1, n, poz, val);
        }
    }
    
    fin.close();
    fout.close();
    return 0;
}