#include <fstream>
#include <cmath>
using namespace std;
ifstream cin ("arbint.in");
ofstream cout ("arbint.out");
int v[100000],batog[400];
int main()
{
    int n,m;
    cin>>n>>m;
    int r=sqrt(n);
    int c,a,b;
    for (int i=0;i<n;i++)
    {
        cin>>v[i];
        if (v[i]>batog[i/r])
        {
            batog[i/r]=v[i];
        }
    }
    for (int i=1;i<=m;i++)
    {
        cin>>c>>a>>b;
        a--;
        if (c==0)
        {
            b--;
            int max=0;
            while (a%r!=0)
            {
                if (v[a]>max)
                    max=v[a];
                a++;
            }
            a+=r;
            while (a<b)
            {
                if (batog[a/r]>max)
                    max=v[a];
                a+=r;
            }
            a-=r;
            while (a<=b)
            {
                if (v[a]>max)
                    max=v[a];
                a++;
            }
            cout<<max<<'\n';
        }
        if (c==1)
        {
            int x=v[a];
            v[a]=b;
            if (v[a]>batog[a/r])
                batog[a/r]=v[a];
            if (v[a]<batog[a/r] && x==batog[a/r])
            {
                int x=(a/r+1)*r;
                batog[a/r]=0;
                for (i=(a/r)*r;i<x;i++)
                {
                    if (v[i]>batog[i/r])
                    {
                        batog[i/r]=v[i];
                    }
                }
            }
        }
    }
    return 0;
}
