#include <bits/stdc++.h>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
const int nmax = 100004;
void init(int nod, int st, int dr);
void update(int nod, int st, int dr, int poz, int val);
int query(int nod, int st, int dr, int lq, int rq);

int n, m, aint[4*nmax], v[nmax];

int main()
{
    fin>>n>>m;
    for(int i = 1; i <= n; ++i)
        fin>>v[i];
    init(1, 1, n);
    while(m--)
    {
        int tip, a, b;
        fin>>tip>>a>>b;
        if(tip == 0)
            fout<<query(1, 1, n, a, b)<<"\n";
        else
            update(1, 1, n, a, b);
    }

    return 0;
}

int query(int nod, int st, int dr, int lq, int rq)
{
    if(lq <= st && dr <= rq)
        return aint[nod];

    int mijl = (st + dr) / 2, ans = -1;
    if(lq <= mijl)
        ans = max(ans, query(2*nod, st, mijl, lq, rq));
    if(mijl+1 <= rq)
        ans = max(ans, query(2*nod+1, mijl+1, dr, lq, rq));
    return ans;
}

void update(int nod, int st, int dr, int poz, int val)
{
    if(st == dr)
    {
        aint[nod] = val;
        return;
    }
    int mijl = (st + dr) / 2;
    if(poz <= mijl)
        update(2*nod, st, mijl, poz, val);
    else
        update(2*nod+1, mijl+1, dr, poz, val);

    aint[nod] = max(aint[2*nod], aint[2*nod+1]);
}

void init(int nod, int st, int dr)
{
    if(st == dr)
    {
        aint[nod] = v[st];
         return;
    }

    int mijl = (st + dr) / 2;
    init(2*nod, st, mijl);
    init(2*nod+1, mijl+1, dr);

    aint[nod] = max(aint[2*nod], aint[2*nod+1]);
}
