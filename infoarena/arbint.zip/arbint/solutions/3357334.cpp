#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

const int maximN = 100005;
int n, m;
int a[maximN];
int aib[4 * maximN];

void construct_arbore(int nod, int left, int right){

	if (left == right) {
		aib[nod] = a[left];
		return;
	}
	int middle = (left + right)/2;
	//recursiv 
	construct_arbore(2 * nod, left, middle);
	construct_arbore(2 * nod + 1, middle + 1, right);

	aib[nod] = max(aib[2 * nod], aib[2 * nod + 1]);

}

void update(int nod, int st, int dr, int pos, int val) {
	if (st == dr) {
		aib[nod] = val; 
		return;
	}

	int mij = (st + dr) / 2;
	if (pos <= mij) {
		update(2 * nod, st, mij, pos, val); 
	}
	else {
		update(2 * nod + 1, mij + 1, dr, pos, val); 
	}

	aib[nod] = max(aib[2 * nod], aib[2 * nod + 1]);
}


int query(int nod, int st, int dr, int L, int R) {
	
	if (L <= st && dr <= R) {
		return aib[nod];
	}

	
	if (dr < L || st > R) {
		return -1; 
	}

	
	int mij = (st + dr) / 2;
	int max_stanga = query(2 * nod, st, mij, L, R);
	int max_dreapta = query(2 * nod + 1, mij + 1, dr, L, R);

	return max(max_stanga, max_dreapta);
}

int main(void)
{
	ifstream fin("arbint.in");
	ofstream fout("arbint.out");

	if (!(fin >> n>>m))
		return 0;

	for (int i = 1; i <= n; i++)
	{
		fin >> a[i];
	}

	construct_arbore(1, 1, n);

	for (int i = 0; i < m; ++i) {
		int tip, a, b;
		fin >> tip >> a >> b;

		if (tip == 0) {
			
			fout << query(1, 1, n, a, b) << "\n";
		}
		else if (tip == 1) {
			
			update(1, 1, n, a, b);
		}
	}
	return 0;
}
