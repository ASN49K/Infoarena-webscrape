#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int N_MAX = 100000;

int tree[4 * N_MAX + 5];
int v[N_MAX + 5] ,n, m, p , a, b, ans = INT_MIN;

void build(int node, int le, int ri) {
    if(le == ri) {
        tree[node] = v[le];
        return;
    }

    int mid = (le + ri) / 2;

    build(2 * node, le, mid);
    build(2 * node + 1, mid + 1, ri);

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void update(int node, int le, int ri, int pos, int val) {
    if(le == ri) {
        tree[node] = val;
        return;
    }
    
    int mid = (le + ri) / 2;

    if(pos <= mid) {
        update(2 * node, le, mid, pos, val);
    }
    else {
        update(2 * node + 1, mid + 1, ri, pos, val);
    }

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void query(int node, int le, int ri, int x, int y, int &ans) {
    if(x <= le && ri <= y) {
        ans = max(ans, tree[node]);
        return;
    }

    int mid = (le + ri) / 2;

    if(x <= mid) {
        query(2 * node, le, mid, x, y, ans);
    }
    if(y > mid) {
        query(2 * node + 1, mid + 1, ri, x, y, ans);
    }
}


int main(){
    fin>>n>>m;
    for(int i = 1 ; i <= n; i++){
        fin>>v[i];
    }
    build(1, 1, n);
    for(int i = 1 ; i <= m; i++){
        fin>>p;
        fin>>a>>b;
        if(p == 0){
            ans = INT_MIN;
            query(1, 1, n, a, b, ans);
            fout<<ans<<"\n";
        }
        else{
            update(1, 1, n, a, b);
        }
    }
    return 0;
}

