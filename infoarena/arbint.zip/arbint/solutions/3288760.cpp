#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
const int NMAX=1e5;
int v[NMAX+5],A[NMAX*2+5],n,q,x,y,tip,ans;
void build(int nod,int st,int dr)
{
    if(st==dr)
    {
        A[nod]=v[st];
    }
    else
    {
        int mij=(st+dr)/2;
        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);
        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}
void update(int nod,int st,int dr,int p,int x)
{
    if(st==dr)
    {
        A[nod]=x;
    }
    else
    {
        int mij=(st+dr)/2;
        if(p<=mij) update(2*nod,st,mij,p,x);
        else update(2*nod+1,mij+1,dr,p,x);
        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}
void query(int nod,int st,int dr,int a,int b)
{
    if(st==dr)
    {
        ans=max(ans,A[nod]);
    }
    else
    {
        int mij=(st+dr)/2;
        if(a<=mij) query(2*nod,st,mij,a,b);
        if(b>=mij+1) query(2*nod+1,mij+1,dr,a,b);
    }
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++) cin>>v[i];
    build(1,1,n);
    while(q)
    {
        q--;
        cin>>tip>>x>>y;
        if(tip==1)
        {
            update(1,1,n,x,y);
        }
        else
        {
            ans=0;
            query(1,1,n,x,y);
            cout<<ans<<'\n';
        }
    }
    return 0;
}
