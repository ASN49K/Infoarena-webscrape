#include <stdio.h>

using namespace std;

#define buffsze 65536

inline bool isdigit(char ch) {
        return '0' <= ch && ch <= '9';
}

class inParser {
public:
        FILE *fin; char *buff; unsigned short id;
        inline char readCh( ) {
                ++id;
                if (id == buffsze) { id = 0; fread(buff, sizeof(char), buffsze, fin); }
                return buff[id];
        }

        inParser (const char *name) {
                fin = fopen(name, "rb");
                buff = new char[buffsze]( );
                id = buffsze - 1;
        }

        inParser& operator >> (int& num) {
                char ch;
                while (!isdigit(ch = readCh( )));
                num = ch - '0';
                while (isdigit(ch = readCh( )))
                        num = num * 10 + ch - '0';
                return *this;
        }
};

class outParser {
public:
        FILE *fout; char *buff; unsigned short id;
        inline void writeCh(char ch) {
                ++id;
                if (id == buffsze) { id = 0; fwrite(buff, sizeof(char), buffsze, fout); }\
                buff[id] = ch;
        }

        outParser (const char *name) {
                fout = fopen(name, "w");
                buff = new char[buffsze]( );
                id = -1;
        }

        ~outParser ( ) {
                fwrite(buff, sizeof(char), id, fout);
        }

        outParser& operator << (int num) {
                if (num < 10) writeCh(num + '0');
                else {
                        (*this) << (num / 10);
                        writeCh(num % 10 + '0');
                }
                return *this;
        }


        outParser& operator << (char ch) {
                writeCh( ch );
                return *this;
        }
};

inParser in ("arbint.in");
outParser out ("arbint.out");

const int maxsze = 1e6 + 1;
const int inf = 0x3f3f3f3f;
const int modulo = 1e9 + 7;

int n, m;
int tree[maxsze << 1];
inline int max(int a, int b) {
        return a > b ? a : b;
}

inline int maxTree(int l, int r) {
        l += n; r += n;

        int ans = -inf;
        while (l <= r) {
                if ((l & 1) == 1) ans = max(ans, tree[l++]);
                if ((r & 1) == 0) ans = max(ans, tree[r--]);
                l >>= 1; r >>= 1;
        }
        return ans;
}

inline void updateTree(int pos, int elem) {
        pos += n; tree[pos] = elem;
        pos >>= 1;
        while (pos >= 1) {
                tree[pos] = max(tree[(pos << 1)], tree[(pos << 1) + 1]);
                pos >>= 1;
        }
}


signed main( ) {
        in >> n >> m;

        int elem;
        for (int i = 1; i <= n; ++i) {
                in >> elem;
                updateTree(i, elem);
        }

        int op, a, b;
        for (int i = 1; i <= m; ++i) {
                in >> op >> a >> b;
                switch ( op ) {
                        case 0: out << maxTree(a, b) << '\n'; break;
                        case 1: updateTree(a, b); break;
                }
        }

        return 0;
}
