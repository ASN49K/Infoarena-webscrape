#include <stdio.h>
#include <stdlib.h>

#define DIMENSION 100000
#define FILE_IN "arbint.in"
#define FILE_OUT "arbint.out"

int n, m, numbers[DIMENSION + 1];
int tree[4 * DIMENSION + 5 + 1];

int max(int a, int b) {
    return a > b ? a : b;
}

void printArray(int *arr, int len) {
    for(int i = 1; i <= len; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void printTree() {
    int s = 1;
    for(int i = 1; i < n; i++) {
        s *= 2;
    }
    int pow = 1, ct = 0;
    for(int i = 1; i < s; i++) {
        printf("%d ", tree[i]);
        ct++;
        if(ct == pow) {
            ct = 0;
            pow *= 2;
            printf("\n");
        }
    }
    printf("\n");
    printArray(tree, s);
    printf("\n");
}

void updateTree(int left, int right, int arrIndex, int treePos, int val) {
    if(left == right) {
        tree[treePos] = val;
        return;
    }

    int mid = (left + right) / 2;
    if(arrIndex <= mid) {
        updateTree(left, mid, arrIndex, 2 * treePos, val);
    }
    else {
        updateTree(mid + 1, right, arrIndex, 2 * treePos + 1, val);
    }
    tree[treePos] = max(tree[2 * treePos], tree[2 * treePos + 1]);
}

void createTree(int arrIndex, int val) {
    updateTree(1, n, arrIndex, 1, val);
}

int searchTree(int left, int right, int treePos, int currLeft, int currRight) {
    if(currLeft == currRight) {
        return tree[treePos];
    }

    int currMid = (currLeft + currRight) / 2;
    if(right <= currMid) {
        return searchTree(left, right, 2 * treePos, currLeft, currMid);
    }
    else if(currMid < left) {
        return searchTree(left, right, 2 * treePos + 1, currMid + 1, currRight);
    }
    else {
        return max(searchTree(left, right, 2 * treePos, currLeft, currMid),
                   searchTree(left, right, 2 * treePos + 1, currMid + 1, currRight));
    }
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");

    fscanf(fileIn, "%d%d", &n, &m);
    for(int i = 1; i <= n; i++) {
        fscanf(fileIn, "%d", &numbers[i]);
        createTree(i, numbers[i]);

        //printTree();
        //printf("\n");
    }

    //printTree();
    //printf("\n");

    int comms[3];

    for(int i = 0; i < m; i++) {
        fscanf(fileIn, "%d%d%d", &comms[0], &comms[1], &comms[2]);

        if(comms[0] == 0) {
            int toPrint = searchTree(comms[1], comms[2], 1, 1, n);
            fprintf(fileOut, "%d\n", toPrint);
            //printf("\nPrinted: %d\n", toPrint);
        }
        else if(comms[0] == 1) {
            updateTree(1, n, comms[1], 1, comms[2]);
            //printTree();
        }
    }

    fclose(fileIn);
    fclose(fileOut);

    return 0;
}
