#include <bits/stdc++.h>

using namespace std;
using ll = long long;
const int N = 1e5 + 5;
struct Segtree {
    struct node {
        int x;
        friend node merge(const node& l, const node& r) {
            return node{max(l.x, r.x)};
        }
    };
    int n;
    vector <node> t;
    template <typename Iterator>
    void build(Iterator begin, Iterator end) {
        n = distance(begin, end);
        t.resize(n * 2);
        int i = 0;
        for(auto it = begin; it != end; ++it, ++i) {
            t[n + i] = node(*it);
        }
        for(int i = n - 1; i > 0; --i) {
            t[i] = merge(t[i << 1], t[i << 1 | 1]);
        }
    }
    void update(int pos, node val) {
        t[pos + n] = val;
        for(int i = pos + n; i > 1; i >>= 1) {
            t[i >> 1] = merge(t[i & -2], t[i | 1]);
        }
    }
    node query(int l, int r) {
        node ansl, ansr;
        for(l += n, r += n; l < r; l >>= 1, r >>= 1) {
            if(l & 1) ansl = merge(ansl, t[l++]);
            if(r & 1) ansr = merge(t[--r], ansr);
        }
        return merge(ansl, ansr);
    }
} S;

// #define HOME
int a[N];

int main() {
#ifndef HOME
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
#endif
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    S.build(a, a + n);
    for(int i = 0; i < m; i++) {
        int t, l, r;
        cin >> t >> l >> r;
        if(t == 0) {
            cout << S.query(l - 1, r).x << '\n';
        } else {
            S.update(l - 1, Segtree::node{r});
        }
    }
    return 0;
}