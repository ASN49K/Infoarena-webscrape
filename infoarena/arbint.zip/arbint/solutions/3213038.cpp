#include <iostream>
#include <fstream>
using namespace std;
#define N 100001
ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, a, b, cer, maxi;
int v[N], ar[4 * N];

void build(int nod, int st, int dr)
{
    if(st == dr)
        fin >> ar[nod];
    else
    {
        int mij = (st + dr) / 2;
        build(2 * nod, st, mij);
        build(2 * nod + 1, mij+1, dr);

        ar[nod] = max(ar[2 * nod], ar[2 * nod + 1]);
    }

}

void inserare(int nod, int st, int dr, int poz, int val)
{
    if(st == dr)
        ar[nod] = v[st];
    else
    {
        int mij = (st + dr) / 2;
        if(poz <= mij)
            inserare(2 * nod, st, mij, poz, val);
        else
            inserare(2 * nod + 1, mij+1, dr, poz, val);

        ar[nod] = max( ar[2*nod], ar[2*nod+1] );
    }

}

void gasire_max(int nod, int st, int dr, int a, int b)
{
    if (a <= st && dr <= b)
        maxi = max(maxi, ar[nod]);
    else
    {
        int mij = (st + dr)/2;
        if (a <= mij)
            gasire_max(2 * nod, st, mij, a, b);
        if (b > mij)
            gasire_max(2 * nod + 1, mij+1, dr, a, b);
    }
}

int main()
{
    fin >> n >> m;
    build(1, 1, n);

    for(int i=1; i<=m; i++)
    {
        fin >> cer >> a >> b;
        if( !cer)
        {
            maxi = -1;
            gasire_max(1, 1, n, a, b);
            fout << maxi << "\n";
        }
        else
            inserare(1 , 1, n, a, b);
    }
    return 0;
}
