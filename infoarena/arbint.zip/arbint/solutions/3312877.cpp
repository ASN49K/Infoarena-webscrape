#include <bits/stdc++.h>

using namespace std;
int v[262150], mx = 0, n, p;
inline void update(int poz, int val, int st, int dr){
    poz += p - 1;
    v[poz] = val;
    poz /= 2;
    while(poz){
        v[poz] = max(v[poz * 2], v[poz * 2 + 1]);
        poz /= 2;
    }
}
int query(int fst, int fdr, int st, int dr, int ind){
    if(fst <= st  &&  dr <= fdr){
        return max(mx, v[ind]);
    }
    int mij = (st + dr) / 2;
    if(fst <= mij){
        mx = max(mx, query(fst, fdr, st, mij, ind*2));
    }
    if(mij + 1 <= fdr){
        mx = max(mx, query(fst, fdr, mij+1, dr, 1+ind*2));
    }
    return mx;
}
int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    int m, k, ok, a, b;
    cin >> n >> m;
    k = log2(n) + 1;
    p = (1<<k);
    for(int i = p; i < p + n; i++){
        cin >> v[i];
    }
    for(int i = p - 1; i > 0; i--){
        v[i] = max(v[2 * i], v[2 * i + 1]);
    }
    for(int i = 0; i < m; i++){
        cin >> ok >> a >> b;
        if(ok == 0){
            mx = 0;
            cout << query(a, b, 1, p, 1)<<"\n";
        }else{
            update(a, b, 1, p);
        }
    }
    return 0;
}
