#include <fstream>
using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");

const int nmax = 100006;
int n, m, aint[4*nmax]; //maximum in a given interval

int maxim(int a, int b)
{
    if(a>b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

void update(int nod, int st, int dr, int pos, int val)
{
    if(st==pos && dr==pos)
    {
        aint[nod] = val;
        return;
    }

    int mij = (st + dr) / 2;
    if(pos<=mij)
    {
        update(nod*2, st, mij, pos, val);
    }
    else
    {
        update(2*nod + 1, mij + 1, dr, pos, val);
    }

    aint[nod] = maxim(aint[2*nod], aint[2*nod + 1]);
}

int query(int nod, int st, int dr, int x, int y)
{
    if(x<=st && dr<=y)
        return aint[nod];

    int mij = (st + dr) / 2, ans = 0;
    if(x<=mij)
        ans = query(2*nod, st, mij, x, y);
    if(y>mij)
        ans = maxim(ans, query(2*nod + 1, mij + 1, dr, x, y));
    return ans;
}

int main()
{
    in>>n>>m;
    for(int i = 1; i<=n; i++)
    {
        int x;
        in>>x;
        update(1, 1, n, i, x);
    }

    for(int i = 0; i<m; i++)
    {
        int q, a, b;
        in>>q>>a>>b;

        if(q==0)
        {
            out<<query(1, 1, n, a, b)<<'\n';
        }
        if(q==1)
        {
            update(1, 1, n, a, b);
        }
    }

    return 0;
}
