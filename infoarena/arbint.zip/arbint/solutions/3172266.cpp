#include <bits/stdc++.h>

std::ifstream f("arbint.in");
std::ofstream g("arbint.out");

const int SIZE=10000;

int a[SIZE*4+4];
int v[SIZE+1];

int combine(int a, int b){
	return std::max(a, b);
}

void build(int node, int left, int right){
	if(left==right){
		a[node]=v[left];
		return;
	}
	int mid=(left+right)/2;
	build(node*2,left,mid);
	build(node*2+1,mid+1,right);
	a[node]=combine(a[node*2],a[node*2+1]);
}

void update(int node, int left, int right, int poz, int val){
	if(left==right){
		a[node]=val;
		return;
	}
	int mid=(left+right)/2;
	if(poz<=mid)
		update(node*2,left,mid,poz,val);
	else
		update(node*2+1,mid+1,right,poz,val);
	a[node]=combine(a[node*2],a[node*2+1]);
}

int query(int node, int tl, int tr, int ql, int qr){
	if(ql<=tl  && qr>=tr)
		return(a[node]);
	int mid=(tl+tr)/2,a=0,b=0;
	if(ql<=mid)
		a=query(node*2,tl,mid,ql,qr);
	if(mid<qr)
		b=query(node*2+1,mid+1,tr,ql,qr);
	return combine(a,b);
}

int n, q;
int main(){
	f>>n>>q;
	for(int i=1;i<=n;i++)
		f>>v[i];
	build(1,1,n);
	for(int i=1;i<=q;i++){
		int t,s,e;
		f>>t>>s>>e;
		if(t==0)
			g<<query(1,1,n,s,e)<<'\n';
		else
			update(1,1,n,s,e);

	}
	return 0;
}
