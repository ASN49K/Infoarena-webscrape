#include <iostream>
#include <stack>
#include <queue>

#define NMAX 100000

using namespace std;
int n, q, tip, st, dr;
int val[NMAX+2];
int aint[4*NMAX+2];

void init(int st, int dr, int pos)
{
    if(st==dr)
    {
        aint[pos]=val[st];
        return;
    }

    int mij=(st+dr)/2;
    init(mij+1, dr, pos*2+1);
    init(st, mij, pos*2);
    aint[pos]=max(aint[pos*2], aint[pos*2+1]);
}

bool inters(int st1, int dr1, int st2, int dr2)
{
    if(max(st1, st2) <= min(dr1, dr2))
        return 1;
    return 0;
}

int query(int st, int dr, int orst=1, int ordr=n, int pos=1)
{
    if(st<=orst && dr>=ordr) //fully enclosed by the original query
    {
        return aint[pos];
    }
    int mij=(orst+ordr)/2;
    int v1=0, v2=0;
    if(inters(st, dr, orst, mij))
        v1=query(st, dr, orst, mij, 2*pos);
    if(inters(st, dr, mij+1, ordr))
        v2=query(st, dr, mij+1, ordr, 2*pos+1);
    return max(v1, v2);
}

void update(int pos, int val, int orst=1, int ordr=n, int orpos=1)
{
    if(orst==ordr)
    {
        if(ordr==pos)
            aint[orpos]=val;
        return;
    }

    int mij=(orst+ordr)/2;
    if(pos<=mij)
    {
        update(pos, val, orst, mij, orpos*2);
    }
    else
    {
        update(pos, val, mij+1, ordr, orpos*2+1);
    }
    aint[orpos]=max(aint[2*orpos], aint[2*orpos+1]);
}
int main()
{
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);

    scanf("%d %d", &n, &q);

    for(int i=1; i<=n; i++)
    {
        scanf("%d", &val[i]);
    }

    init(1, n, 1);

    for(int i=1; i<=q; i++)
    {
        scanf("%d %d %d", &tip, &st, &dr);
        if(tip==0)
        {
            printf("%d\n", query(st, dr));
        }
        else
        {
            update(st, dr);
        }
    }
    return 0;
}
