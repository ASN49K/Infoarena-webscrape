#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

const int MAXN = 100005;

int n, m;
int a[MAXN];
int tree[4 * MAXN];

void build(int node, int start, int end) {
    if (start == end) {
        tree[node] = a[start];
    } else {
        int mid = (start + end) / 2;

        build(2 * node, start, mid);
        build(2 * node + 1, mid + 1, end);

        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

void update(int node, int start, int end, int idx, int val) {
    if (start == end) {
        a[idx] = val;
        tree[node] = val;
    } else {
        int mid = (start + end) / 2;

        if (idx <= mid)
            update(2 * node, start, mid, idx, val);
        else
            update(2 * node + 1, mid + 1, end, idx, val);

        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

int query(int node, int start, int end, int l, int r) {
    if (r < start || end < l)
        return INT_MIN;

    if (l <= start && end <= r)
        return tree[node];

    int mid = (start + end) / 2;

    int left = query(2 * node, start, mid, l, r);
    int right = query(2 * node + 1, mid + 1, end, l, r);

    return max(left, right);
}

int main() {
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");

    fin >> n >> m;

    for (int i = 0; i < n; i++)
        fin >> a[i];

    build(1, 0, n - 1);

    for (int i = 0; i < m; i++) {
        int op, x, y;
        fin >> op >> x >> y;

        if (op == 0) {
            fout << query(1, 0, n - 1, x - 1, y - 1) << '\n';
        } else {
            update(1, 0, n - 1, x - 1, y);
        }
    }

    return 0;
}