#include <bits/stdc++.h>
using namespace std;

class SQRTDecomposition {
private:    
    vector<int> arr;
    vector<int> b;
    int len;

public:
    SQRTDecomposition(const vector<int>& input) {
        arr = input;
        int n = arr.size();
        len = static_cast<int>(sqrt(n) + 1);  
        b = vector<int>((n + len - 1) / len, 0); 
        for (int i = 0; i < n; i++) {
            b[i / len] = max(b[i / len], arr[i]);
        }
    }
    
    void update(int index, int val) {
    int blocknum = index / len;
    int old_val = arr[index];
    arr[index] = val;
    
    if (val > b[blocknum]) {
        b[blocknum] = val;
    } else if (old_val == b[blocknum]) {
        int start = blocknum * len;
        int end = min((blocknum + 1) * len, (int)arr.size());
        b[blocknum] = *max_element(arr.begin() + start, arr.begin() + end);
    }
}

    int query(int L, int R) {
        int mx = 0;

        while (L <= R && L % len != 0) {
            mx = max(mx, arr[L]);
            L++;
        }

        while (L + len - 1 <= R) {
            mx = max(mx, b[L / len]);
            L += len;
        }
        while (L <= R) {
            mx = max(mx, arr[L]);
            L++;
        }
        
        return mx;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ifstream f("arbint.in");
    ofstream g("arbint.out");
    
    int n, m;
    int x, y, z;
    f >> n >> m;
    vector<int>arr(n);
    for(int i = 0; i < n;i++){
        f >> arr[i];
    }
    SQRTDecomposition st(arr);
    for(int i = 0; i < m;i++){
        f >> x >> y >> z;
        if(x == 1){
            y --;
            st.update(y,z);
        }
        else{
            y--;
            z--;
            g << st.query(y,z)<<endl;
        }
    }
    return 0;
}
