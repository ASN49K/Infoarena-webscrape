#include <fstream>
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
const int k = 100001;
int aint[400008];
int v[100001];
int ans = 0;
void build(int nod, int st, int dr){
    if (st == dr) {
        aint[nod] = v[st];
        return;
    }
    int mid = (st + dr) / 2;
    build(2 * nod, st, mid);
    build(2 * nod + 1, mid + 1, dr);
    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}
void update(int nod, int st, int dr, int valoare, int poz){
    if (st == dr){
        v[poz] = valoare;
        aint[nod] = valoare;
        return;
    }
    int mid = (st + dr) / 2;
    if (poz <= mid){
        update(2 * nod, st, mid, valoare, poz);
    } else {
        update(2 * nod + 1, mid + 1, dr, valoare, poz);
    }
    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}
void query(int nod, int st, int dr, int qst, int qdr){
    if (qst <= st && dr <= qdr){
        ans = max(ans, aint[nod]);
        return;
    }
    if (st == dr){
        ans = max(ans, aint[nod]);
        return;
    }
    int mid = (st + dr) / 2;
    if (qst <= mid){
        query(2 * nod, st, mid, qst, qdr);
    }
    if (qdr > mid){
        query(2 * nod + 1, mid + 1, dr, qst, qdr);
    }
}
void afiseaza(int n, int a, int b){
    ans = 0;
    query(1, 1, n, a, b);
    fout << ans << '\n';
}
int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; i++){
        fin >> v[i];
    }
    build(1, 1, n);
    for (int i = 1; i <= m; i++){
        ans = 0;
        int cerere, a, b;
        fin >> cerere >> a >> b;
        if (cerere == 0){
            afiseaza(n, a, b);
        } else {
            update(1, 1, n, b, a);
        }
    }
    return 0;
}
