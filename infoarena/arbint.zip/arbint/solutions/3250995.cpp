//sqrt
#include <bits/stdc++.h>

const std :: string FILENAME = "arbint";

std :: ifstream f (FILENAME + ".in");

std :: ofstream g (FILENAME + ".out");

const int NMAX = 1e5 + 5;

const int l = 320;

int n;

int q;

int cer;

int x;

int y;

int maxi;

int v[NMAX];

int b[l];

int main()
{

    f >> n >> q;

    for(int i = 1; i <= n; i ++)
    {
        f >> v[i];

        b[i / l] = std :: max(b[i / l], v[i]);
    }

    while(q --)
    {
        f >> cer;

        if(cer == 0)
        {
            maxi = 0;

            f >> x >> y;

            if(x / l == y / l)
            {
                for(int i = x; i <= y; i ++)
                {
                    maxi = std :: max(maxi, v[i]);
                }

                g << maxi << '\n';
            }
            else
            {
                for(int i = x; i <= (x / l + 1) * l; i ++)
                {
                    maxi = std :: max(maxi, v[i]);
                }

                for(int i = x / l + 1; i < y / l; i ++)
                {
                    maxi = std :: max(maxi, b[i]);
                }

                for(int i = (y / l) * l + 1; i <= y; i ++)
                {
                    maxi = std :: max(maxi, v[i]);
                }

                g << maxi << '\n';
            }
        }
        else
        {
            f >> x >> y;

            if(y > b[x / l])
            {
                b[x / l] = y;

                v[x] = y;
            }
            else if(b[x / l] != v[x] && b[x / l] >= y)
            {
                v[x] = y;
            }
            else
            {
                v[x] = y;

                for(int i = (x / l) * l + 1; i <= (x / l + 1) * l; i ++)
                {
                    b[x / l] = std :: max(b[x / l], v[i]);
                }
            }
        }
    }

    return 0;
}
