#include <bits/stdc++.h>
#include <fstream>
using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

const int N_MAX = 100000;

int tree[4 * N_MAX + 5];

void update(int node, int le, int ri, int pos, int val) 
{
    if(le == ri) 
    {
        tree[node] = val;
        return;
    }
    
    int mid = (le + ri) / 2;

    if(pos <= mid) 
    {
        update(2 * node, le, mid, pos, val);
    }
    else 
    {
        update(2 * node + 1, mid + 1, ri, pos, val);
    }

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

int query(int node, int le, int ri, int x, int y) 
{
    int max1, max2;
    max1 = 0;
    max2 = 0;
    
    if(x <= le && ri <= y) 
    {
       return tree[node];
    }

    int mid = (le + ri) / 2;

    if(x <= mid) 
    {
       max1 = query(2 * node, le, mid, x, y);
    }
    
    if(y > mid) 
    {
        max2 = query(2 * node + 1, mid + 1, ri, x, y);
    }
    return max(max1, max2);
}

int main(void) 
{
    int n, m, op, a, b, nr;
    
    fin >> n >> m;
    
    for(int i = 1; i <= n; i++)
    {
        fin >> nr;
        update(1, 1, n, i, nr);
    }
    
    while(m)
    {
        fin >> op >> a >> b;
        switch(op)
        {
            case 0:
                fout << query(1, 1, n, a, b) << endl;
                break;
            case 1:
                update(1, 1, n, a, b);
                break;
        }
        m--;
    }
    
    fin.close();
    fout.close();
    
    return 0;
}
