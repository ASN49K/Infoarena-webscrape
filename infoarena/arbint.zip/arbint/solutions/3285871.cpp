//Code by Patcas Csaba aka SleepyOverlord
#include <vector>
#include <array>
#include <string> 
#include <set> 
#include <map> 
#include <unordered_set>
#include <unordered_map>
#include <queue> 
#include <bitset> 
#include <stack>
#include <list>

#include <numeric> 
#include <algorithm> 
#include <random>
#include <chrono>

#include <cstdio>
#include <fstream>
#include <iostream> 
#include <sstream> 
#include <iomanip>
#include <climits>

#include <cctype>
#include <cmath> 
#include <ctime>
#include <cassert>

using namespace std;

#define ULL unsigned long long
#define LL long long
#define PII pair <int, int>
#define PLL pair <LL, LL>
#define VB vector <bool>
#define VI vector <int>
#define VLL vector <LL>
#define VD vector <double>
#define VS vector <string>
#define VPII vector <pair <int, int> >
#define VVI vector < VI >
#define VVLL vector < VLL >
#define VVB vector < VB >
#define SI set < int >
#define USI unordered_set <int>
#define MII map <int, int>
#define UMII unordered_map <int, int>

#define FORN(i, n) for(int i = 0; i < (n); ++i)
#define FOR(i, a, b) for(int i = (a); i <= (b); ++i)
#define FORD(i, a, b) for(int i = (a); i >= (b); --i)
#define MX(x, y) x = max(x, y)
#define MN(x, y) x = min(x, y)

#define SZ size()
#define BG begin() 
#define EN end() 
#define CL clear()
#define X first
#define Y second
#define RS resize
#define PB push_back
#define MP make_pair
#define ALL(x) x.begin(), x.end()
#define INS insert
#define ER erase
#define CNT count

template <class T> ostream& operator <<(ostream & os, const vector<T> &vec)
{
	for (int i = 0; i < vec.size() - 1; ++i) os << vec[i] << ' ';
	return os << vec[vec.size() - 1];
}

template <class T1, class T2> ostream& operator <<(ostream & os, const pair<T1, T2> &p)
{
	return os << p.X << " " << p.Y;
}

template <typename T>
void pr(T var1)
{
	cout << var1 << '\n';
}
template <typename T, typename... Types>
void pr(T var1, Types... var2)
{
	cout << var1;
	pr(var2...);
}

int n, q;
VI tree;

void update(int ind, int val, int node = 1, int left = 1, int right = n)
{
	if (left == right)
	{
		tree[node] = val;
		return;
	}
	int mid = (left + right) / 2;
	if (ind <= mid) update(ind, val, node * 2, left, mid);
	else update(ind, val, node * 2 + 1, mid + 1, right);
	tree[node] = max(tree[node * 2], tree[node * 2 + 1]);
}

int query(int l, int r, int node = 1, int left = 1, int right = n)
{
	if (l <= left and right <= r) return tree[node];
	int mid = (left + right) / 2;
	if (r <= mid) return query(l, r, node * 2, left, mid);
	if (mid + 1 <= l) return query(l, r, node * 2 + 1, mid + 1, right);
}

int main()
{
	freopen("arbint.in", "r", stdin);
	freopen("arbint.out", "w", stdout);

	ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0);

	cin >> n >> q;
	tree.RS(4 * n);
	FOR(i, 1, n)
	{
		int x;
		cin >> x;
		update(i, x);
	}
	FOR(qq, 1, q)
	{
		int op, x, y;
		cin >> op >> x >> y;
		if (op == 0) pr(query(x, y));
		else update(x, y);
	}

	return 0;
}