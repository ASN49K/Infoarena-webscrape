#include <bits/stdc++.h>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
const int N=100010;
struct nod
{
    int val,st,dr;
    nod *fs,*fd,*ta;
    nod(int va,int s,int d,nod* FS,nod *FD,nod *TA)
    {
        val=va;st=s,dr=d;fs=FS;fd=FD,ta=TA;
    }
};
nod *root,*a[N];
int n,q;
nod *construieste(int st,int dr)
{
    int val;
    if(st==dr)
    {
        f>>val;
        a[st]=new nod(val,st,dr,NULL,NULL,NULL);
        return a[st];
    }
    nod *aux,*FS,*FD;
    int mi=(st+dr)/2;
    FS=construieste(st,mi);
    FD=construieste(mi+1,dr);
    val=max(FS->val,FD->val);
    aux=new nod(val,st,dr,FS,FD,NULL);
    FS->ta=FD->ta=aux;
    return aux;
}
void upd()
{
    int poz,newVal;
    f>>poz>>newVal;
    nod *aux=a[poz];
    aux->val=newVal;
    aux=aux->ta;
    while(aux)
    {
        aux->val=max(aux->fs->val,aux->fs->val);
        aux=aux->ta;
    }
}
int getMax(nod *here,int lo,int hi)
{
    if(here->dr<lo||here->st>hi)
        return 0;
    if(lo<=here->st&&here->dr<=hi)
        return here->val;
    return max(getMax(here->fs,lo,hi),getMax(here->fd,lo,hi));
}
void getMax()
{
    int lo,hi;
    f>>lo>>hi;
    g<<getMax(root,lo,hi)<<'\n';
}
int main()
{
    f>>n>>q;
    root=construieste(1,n);
    for(;q;q--)
    {
        int tip;
        f>>tip;
        if(tip==0)
            getMax();
        else
            upd();
    }
    return 0;
}

