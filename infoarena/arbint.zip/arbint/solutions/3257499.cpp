#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX=100000, BLKSZ=350;

int blockId(int i){
	return i/BLKSZ;
}

int v[NMAX+5], max1[NMAX/BLKSZ+5];

int main(){
	int N, op, Q, a, b;
	fin>>N>>Q;
	for(int i=0;i<N;i++){
		fin>>v[i];
		max1[blockId(i)]=max(max1[blockId(i)], v[i]);
	}
	for(int i=0;i<Q;i++){
		fin>>op>>a>>b;
		if(op){
			a--;
			if(max1[blockId(a)]==v[a] and v[a]>b){
				max1[blockId(a)]=v[a]=b;
				for(i=blockId(a)*BLKSZ;i<N and i<(blockId(a)+1)*BLKSZ;++i){
					max1[blockId(a)]=max(max1[blockId(a)], v[i]);
				}
			}else{
				v[a]=b;
				max1[blockId(a)]=max(max1[blockId(a)], b);
			}
		}else{
			a--;
			b--;
			int ans=v[a];
			for(i=a;i<=b and blockId(i)==blockId(a);++i){
				ans=max(ans, v[i]);
			}
			for(i=b;i>=a and blockId(i)==blockId(b);--i){
				ans=max(ans, v[i]);
			}
			for(i=blockId(a)+1;i<blockId(b);++i){
				ans=max(ans, max1[i]);
			}
			fout<<ans<<'\n';
		}
	}
}
