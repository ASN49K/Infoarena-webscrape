#include <bits/stdc++.h>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int aint[4*100005];

void update(int node, int left, int right, int poz, int value) {
    if (left == right) {
        aint[node] = value;
        return;
    }
    int mid = (left + right) / 2;

    if (poz <= mid) {
        update(node * 2, left, mid, poz, value);
    } else {
        update(node * 2 + 1, mid + 1, right, poz, value);
    }

    aint[node] = max(aint[node * 2],aint[node * 2 + 1]);
}

int query(int node, int left, int right, int a, int b) {
    if (a <= left && right <= b) {
        return aint[node];
    }
    int mid = (left + right) / 2;
    int leftMax = 0, rightMax = 0;

    if (a <= mid) {
        leftMax = query(node * 2, left, mid, a, b);
    }

    if (mid + 1 <= b) {
        rightMax = query(node * 2 + 1, mid + 1, right, a, b);
    }

    return max(leftMax,rightMax);
}

int main()
{
    int n,m;
    fin >> n >> m;
    for (int i=1;i<=n;++i){
        int xul;
        fin >> xul;
        update(1,1,n,i,xul);
    }
    for (int i=1;i<=m;++i){
        int C,x,y;
        fin >> C >> x >> y;
        if (C==0) fout << query(1,1,n,x,y) << '\n';
        else update(1,1,n,x,y);
    }
    return 0;
}
