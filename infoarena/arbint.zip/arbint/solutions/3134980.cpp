#include <vector>
#include <fstream>
#include <algorithm>

std::ifstream fin("arbint.in");
std::ofstream fout("arbint.out");

inline int left_son(int node) {
    return node << 1;
}

inline int right_son(int node) {
    return (node << 1) + 1;
}

inline int middle(int left, int right) {
    return (left + right) >> 1;
}

void initialize_stree(int node, int left, int right, std::vector<int>& stree) {
    if (left == right) {
        int elem;
        fin >> elem;
        stree[node] = elem;
    } else {
        initialize_stree(left_son(node), left, middle(left, right), stree);
        initialize_stree(right_son(node), middle(left, right) + 1, right, stree);
        stree[node] = std::max(stree[left_son(node)], stree[right_son(node)]);
    }
}

void update_stree(int node, int left, int right, int index, int value, std::vector<int>& stree) {
    if (left == right) {
        stree[node] = value;
    } else {
        if (index <= middle(left, right)) {
            update_stree(left_son(node), left, middle(left, right), index, value, stree);
        } else {
            update_stree(right_son(node), middle(left, right) + 1, right, index, value, stree);
        }
        stree[node] = std::max(stree[left_son(node)], stree[right_son(node)]);
    }
}

void query_stree(int node, int left, int right, int start, int end, int& query_answer, std::vector<int>& stree) {
    if (start <= left && right <= end) {
        query_answer = std::max(query_answer, stree[node]);
    } else {
        if (start <= middle(left, right)) {
            query_stree(left_son(node), left, middle(left, right), start, end, query_answer, stree);
        }
        if (end > middle(left, right)) {
            query_stree(right_son(node), middle(left, right) + 1, right, start, end, query_answer, stree);
        }
    }
}

std::vector<int> build_stree(int n) {
    std::vector<int> stree(4 * n, 0);
    initialize_stree(1, 1, n, stree);
    return stree;
}

int answer_query(int n, int start, int end, std::vector<int>& stree) {
    int answer = 0;
    query_stree(1, 1, n, start, end, answer, stree);
    return answer;
}

int main() {
    int n, m;
    fin >> n >> m;
    std::vector<int> stree = build_stree(n);

    for (int i = 0; i < m; i++) {
        int type, a, b;
        fin >> type >> a >> b;

        if (type == 0) {
            int answer = answer_query(n, a, b, stree);
            fout << answer << '\n';
        } else {
            update_stree(1, 1, n, a, b, stree);
        }
    }

    fin.close();
    fout.close();
    return 0;
}
