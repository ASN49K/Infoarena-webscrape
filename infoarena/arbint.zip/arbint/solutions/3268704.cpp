#include <bits/stdc++.h>
#define MAXN 100000
using namespace std;
int aint[4 * MAXN + 1] , v[MAXN + 1];
void update( int nod , int l , int r , int pos , int val ) {
    int mid = ( l + r ) / 2;
    if( l == r ) {
        aint[nod] = val;
        return;
    }
    if( mid >= pos )
        update( nod * 2 , l , mid , pos , val );
    else
        update( nod * 2 + 1 , mid + 1 , r , pos , val );
    aint[nod] = max( aint[nod * 2] , aint[2 * nod + 1] );
}
int query( int nod , int l , int r , int st , int dr ) {
    int ans = 0 , mid = ( l + r ) / 2;
    if( l >= st && r <= dr )
        return aint[nod];
    if( st <= mid )
        ans = max( ans , query( nod * 2 , l , mid , st , dr ) );
    if( mid + 1 <= dr )
        ans = max( ans , query( nod * 2 + 1 , mid + 1 , r , st , dr ) );
    return ans;
}
int main() {
    ifstream cin( "arbint.in" );
    ofstream cout( "arbint.out" );
    int l , r , a , b , tip , n , q , i;
    cin >> n >> q;
    for( i = 0 ; i < n ; i++ )
        cin >> v[i] , update( 1 , 0 , n - 1 , i , v[i] );
    while( q-- ) {
        cin >> tip >> a >> b;
        a--;
        if( tip == 0 ) {
            b--;
            cout << query( 1 , 0 , n - 1 , a , b ) << '\n';
        } else
            update( 1 , 0 , n - 1 , a , b );
    }
    return 0;
}
