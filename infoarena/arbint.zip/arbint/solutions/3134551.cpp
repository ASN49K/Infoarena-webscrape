#include <bits/stdc++.h>
using namespace std;

#define N 100000
typedef long long ll;
ifstream in("arbint.in");
ofstream out("arbint.out");

int tree[4*N];
int v[N+1];

void build(int node, int l, int r)
{
    if(l==r)
    {
        tree[node] = v[l];
        return;
    }

    int mid = (l+r)/2;
    build(2*node, l, mid);
    build(2*node+1, mid+1, r);

    tree[node] = max(tree[2*node], tree[2*node+1]);
}

void update(int node, int l, int r, int pos, int val)
{
    if(l == r)
    {
        tree[node] = val;
        return;
    }

    int mid = (l+r)/2;
    if(pos <= mid)
        update(2*node, l, mid, pos, val);
    else update(2*node+1, mid+1, r, pos, val);

    tree[node] = max(tree[2*node], tree[2*node+1]);
}

void query(int node, int l, int r, int x, int y, int &ans)
{
    if(x <= l && r <=y)
    {
        ans = max(ans, tree[node]);
        return;
    }

    int mid = (l+r)/2;

    if(x <= mid)
        query(2*node, l, mid, x, y, ans);

    if(y > mid)
        query(2*node+1, mid+1, r, x, y, ans);
}

int main()
{
    bool c;
    int m, n, a, b;
    in >> n >> m;

    for(int i = 0; i < n; i++)
        in >> v[i];
    build(1, 0, n-1);

    while(m--)
    {
        int sol = 0;
        in >> c >> a >> b;
        //scad 1 pentru ca a e intre 1 si N insa la mine indexul se incepe de la 0
        a--;
        b--;
        if(c == 0)
        {
            query(1, 0, n-1, a, b, sol);
            out << sol << "\n";
        }
        //adun 1 pentru ca b deja nu va fi in calitate de capat al intervalului ci de numarul cu care se modifica
        else update(1, 0, n-1, a, b+1);

    }

    return 0;
}
