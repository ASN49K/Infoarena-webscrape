#include <bits/stdc++.h>
using namespace std;
const int dim=1e5+5;
int n,m,v[dim],aint[4*dim],sol;
void build(int nod, int st, int dr){
    if(st==dr){
        aint[nod]=v[st];
    }
    else{
        int mid=(st+dr)/2;
        build(2*nod,st,mid);
        build(2*nod+1,mid+1,dr);
        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}
void update(int nod, int st, int dr, int poz, int x){
    if(st==dr){
        aint[nod]=x;
    }
    else{
        int mid=(st+dr)/2;
        if(poz<=mid){
            update(2*nod,st,mid,poz,x);
        }
        if(poz>mid){
            update(2*nod+1,mid+1,dr,poz,x);
        }
        aint[nod]=max(aint[2*nod],aint[2*nod+1]);
    }
}
void query(int nod, int st, int dr, int a, int b){
    if(a<=st and dr<=b){
        sol=max(sol,aint[nod]);
    }
    else{
        int mid=(st+dr)/2;
        if(a<=mid){
            query(2*nod,st,mid,a,b);
        }
        if(b>mid){
            query(2*nod+1,mid+1,dr,a,b);
        }
    }
}
int main(){
    ifstream f("arbint.in");
    ofstream g("arbint.out");
    f>>n>>m;
    for(int i=1;i<=n;i++){
        f>>v[i];
    }
    build(1,1,n);
    while(m--){
        int t,x,y;
        f>>t>>x>>y;
        if(t==0){
            sol=0;
            query(1,1,n,x,y);
            g<<sol<<'\n';
        }
        else{
            update(1,1,n,x,y);
        }
    }
    return 0;
}
