#include <bits/stdc++.h>

using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

const int MAX = 1e5 + 5;
int n, m, ans, v[MAX], aint[4 * MAX];

void build(int nod, int st, int dr){
    if(st == dr){
        aint[nod] = v[st];
        return;
    }
    int m = (st + dr) / 2;
    build(nod * 2, st, m);
    build(nod * 2 + 1, m + 1, dr);
    aint[nod] = max(aint[nod * 2], aint[nod * 2 + 1]);
}

void update(int nod, int st, int dr, int poz, int val){
    if(st == dr){
        aint[nod] = val;
        return;
    }
    int m = (st + dr) / 2;
    if(poz <= m)
        update(nod * 2, st, m, poz, val);
    else
        update(nod * 2 + 1, m + 1, dr, poz, val);
    aint[nod] = max(aint[nod * 2], aint[nod * 2 + 1]);
}

void query(int nod, int st, int dr, int a, int b){
    if(st > b || dr < a)
        return;
    if(a <= st && dr <= b){
        ans = max(ans, aint[nod]);
        return;
    }
    int m = (st + dr) / 2;
    query(nod * 2, st, m, a, b);
    query(nod * 2 + 1, m + 1, dr, a, b);
}

int main(){
    in >> n >> m;
    for(int i = 1; i <= n; i++)
        in >> v[i];
    build(1, 1, n);
    for(int i = 1; i <= m; i++){
        int p, a, b;
        in >> p >> a >> b;
        if(p){
            v[a] = b;
            update(1, 1, n, a, b);
        }
        else{
            ans = 0;
            query(1, 1, n, a, b);
            out << ans << '\n';
        }
    }
    return 0;
}
