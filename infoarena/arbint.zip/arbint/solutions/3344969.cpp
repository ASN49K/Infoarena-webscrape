#include <fstream>
#define NM 100000
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");


int tree[4*NM+1],v[NM+1],maxim;

void build(int nod, int l, int r){
    if(l==r){
        cin>>tree[nod];
    }
    else{
        int mij=(l+r)/2;
        build(nod*2, l, mij);
        build(nod*2+1, mij+1, r);
        tree[nod]=max(tree[2*nod],tree[2*nod+1]);
    }
}

void up(int nod, int l, int r, int poz, int val){
    if(l==r){
        tree[nod]=val;
    }
    else{
        int mij=(l+r)/2;
        if(poz<=mij)
            up(nod*2, l, mij, poz, val);
        else
            up(nod*2+1, mij+1, r, poz, val);
        tree[nod]=max(tree[nod*2],tree[nod*2+1]);
    }
}

void query(int nod, int l, int r, int st, int dr){
    if(st<=l && r<=dr)
        maxim=max(maxim,tree[nod]);
    else{
        int mij=(l+r)/2;
        if(st<=mij)
            query(nod*2, l, mij, st, dr);
        if(mij+1<=dr)
            query(nod*2+1, mij+1, r, st, dr);
    }
    
}


int n,c,a,b,q;
int main(){
    cin>>n>>q;
    build(1, 1, n);
    while (q--) {
        cin>>c>>a>>b;
        if(c==0){
            maxim=-2e9;
            query(1, 1, n, a, b);
            cout<<maxim<<"\n";
        }
        else{
            up(1, 1, n, a, b);
        }
            
    }
}
