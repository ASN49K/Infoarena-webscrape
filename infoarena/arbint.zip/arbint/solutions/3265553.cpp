/*

! QUERY:
    * 0 x y - afiseaza maximul din intervalul [x, y]
    * 1 x y - valoarea elementului de pe pozitia x devine y

*/

#include <bits/stdc++.h>

using namespace std;

#define INFILE "arbint.in"
#define OUTFILE "arbint.out"

class Node {

public:
    int value;
    
    Node(){}
    Node(int _value) : value(_value) {}

    bool operator > (const Node &a) const {
        return this -> value > a.value;
    }

    friend Node compareNodes(Node a, Node b){
        return (a > b) ? a : b;
    }

};

class SegmentTree {

private:
    vector<Node> tree;

public:
    SegmentTree(int n) {
        tree.resize(4 * (n + 1) + 1, Node(0));
    }

    void update(int node, int left, int right, int position, Node value){
        if(left == right){
            tree[node] = value;
            return;
        }
        int middle = (left + right) >> 1;
        if(position <= middle) {
            update((node << 1), left, middle, position, value);
        }
        else {
            update((node << 1 | 1), middle + 1, right, position, value);
        }
        tree[node] = compareNodes(tree[node << 1], tree[(node << 1) | 1]);
    }

    Node query(int node, int left, int right, int queryLeft, int queryRight){
        if(queryLeft <= left && right <= queryRight){
            return tree[node];
        }
        int middle = (left + right) >> 1;
        if(queryRight <= middle) return query((node << 1), left, middle, queryLeft, queryRight);
        if(queryLeft > middle) return query((node << 1 | 1), middle + 1, right, queryLeft, queryRight);
        return compareNodes(
            query((node << 1), left, middle, queryLeft, queryRight),
            query((node << 1 | 1), middle + 1, right, queryLeft, queryRight)
        );
    }

};

int n, queries;

void solve(){

    cin >> n >> queries;
    SegmentTree tree(n);

    for(int i = 1; i <= n; ++i){
        int aux; cin >> aux;
        tree.update(1, 1, n, i, aux);
    }

    while(queries--){
        bool type; cin >> type;
        int x, y; cin >> x >> y;
        if(!type){
            cout << tree.query(1, 1, n, x, y).value << '\n';
        }
        else {
            tree.update(1, 1, n, x, y);
        }
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}