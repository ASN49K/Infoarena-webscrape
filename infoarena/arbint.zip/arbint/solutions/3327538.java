import java.util.*;
import java.io.*;

class Main {

    static class Segt{
        static int[] tree , a;
        static int h(int x, int y){
            return Math.max(x,y);
        }
        public static void set(int[] arr, int n){
            tree = new int[arr.length * 4];
            a = arr;
            build(1,1,n);
        }
        public static void build(int node, int l, int r){
            if(l == r) tree[node] = a[l];
            else{
                int mid = (l+r)/2;
                build(node*2, l, mid);
                build(node*2+1, mid+1, r);
                tree[node] = h(tree[node*2],tree[node*2+1]);
            }
        }

        public static void update(int node, int l, int r, int poz, int val){
            if(l == r) tree[node] = val;
            else{
                int mid = (l+r)/2;
                if(poz <= mid) update(node*2,l,mid,poz,val);
                else update(node*2+1,mid+1,r,poz,val);
                tree[node] = h(tree[node*2],tree[node*2+1]);
            }
        }

        public static int query(int node, int l, int r, int ql, int qr){
            if(ql <= l && r <= qr) return tree[node];
            else{
                int mid = (l+r)/2;
                int val = -1;
                if(ql <= mid) val = h(val,query(node*2,l,mid,ql,qr));
                if(qr > mid) val = h(val,query(node*2+1,mid+1,r,ql,qr));
                return val;
            }
        }
    }

    public static void main(String[] args) throws IOException {
        File fin = new File("arbint.in");
        File fout = new File("arbint.out");
        Scanner sc = new Scanner(fin);
        PrintWriter pw = new PrintWriter(fout);
        int[] v = new int[100001];
        int n, m, op, a, b;
        n = sc.nextInt();
        m = sc.nextInt();
        for(int i = 1 ; i <= n ; ++i)
            v[i] = sc.nextInt();
        Segt.set(v,n);

        for(int i = 1 ; i <= m ; ++i){
            op = sc.nextInt();
            a = sc.nextInt();
            b = sc.nextInt();
            if(op == 0) pw.print((Segt.query(1,1,n,a,b)));
            else Segt.update(1,1,n,a,b);
        }
    }
}