#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

void construct_segtr(const vector<int>& aa, vector<int>& segtr, int pp, int ll, int rr)
{
    if (ll == rr)
    {
        segtr[pp] = aa[ll];

        return;
    }

    int mid = (ll + rr) >> 1;
    construct_segtr(aa, segtr, pp << 1, ll, mid);
    construct_segtr(aa, segtr, (pp << 1) + 1, mid + 1, rr);

    segtr[pp] = max(segtr[pp << 1], segtr[(pp << 1) + 1]);
    return;
}

void update_segtr(vector<int>& segtr, int pp, int ll, int rr, int ii, int xx)
{
    if (ll == rr)
    {
        segtr[pp] = xx;
        return;
    }

    int mid = (ll + rr) >> 1;
    if (ii <= mid)
    {
        update_segtr(segtr, pp << 1, ll, mid, ii, xx);
    }
    else
    {
        update_segtr(segtr, (pp << 1) + 1, mid + 1, rr, ii, xx);
    }

    segtr[pp] = max(segtr[pp << 1], segtr[(pp << 1) + 1]);

    return;
}

int query_segtr(vector<int>& segtr, int pp, int ll, int rr, int qll, int qrr)
{
    if (qll > qrr)
        return INT_MIN;
    if (qll <= ll && qrr >= rr)
    {
        return segtr[pp];
    }

    int mid = (ll + rr) >> 1;
    int res = INT_MIN;
    if (qll <= mid)
    {
        res = max(res, query_segtr(segtr, pp << 1, ll, mid, qll, qrr));
    }
    if (qrr > mid)
    {
        res = max(res, query_segtr(segtr, (pp << 1) + 1, mid + 1, rr, qll, qrr));
    }

    return res;
}

int main()
{
    ifstream ifs("arbint.in");
    ofstream ofs("arbint.out");

    int nn, mm;

    ifs >> nn >> mm;

    vector<int> segtr(4 * (nn + 1));
    vector<int> aavec(nn + 1);
    for (int ii = 1; ii <= nn; ++ii)
    {
        ifs >> aavec[ii];
    }

    construct_segtr(aavec, segtr, 1, 1, nn);

    for (int ii = 0; ii < mm; ++ii)
    {
        int op, a, b;
        ifs >> op >> a >> b;

        if (op == 0)
        {
            int ss = query_segtr(segtr, 1, 1, nn, a, b);
            ofs << ss << endl;
        }
        else
        {
            update_segtr(segtr, 1, 1, nn, a, b);
        }
    }

    return 0;
}
