#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int nmax = 100000;
int n, m, Max;
int a[nmax + 5], aint[4 * nmax];

void read()
{
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
        fin >> a[i];
}

void update(int i, int left, int right, int a, int b)
{
    if (left == right)
    {
        aint[i] = b;
        return;
    }
    int mid = (left + right) / 2;
    if (a <= mid)
        update(2 * i, left, mid, a, b);
    else
        update(2 * i + 1, mid + 1, right, a, b);

    aint[i] = max(aint[2 * i], aint[2 * i + 1]);
}

void build()
{
    for (int i = 1; i <= n; i++)
        update(1, 1, n, i, a[i]);
}

void query(int i, int left, int right, int a, int b)
{
    if (a <= left && right <= b)
    {
        Max = max(Max, aint[i]);
        return;
    }
    if (a > right || b < left)
        return;

    int mid = (left + right) / 2;
    query(2 * i, left, mid, a, b);
    query(2 * i, mid + 1, right, a, b);
}

void solve()
{
    while (m--)
    {
        int op, a, b;
        fin >> op >> a >> b;
        if (op == 1)
            update(1, 1, n, a, b);
        if (op == 0)
        {
            Max = 0;
            query(1, 1, n, a, b);
            fout << Max << endl;
        }
    }
}

int main()
{
    read();
    build();
    solve();
    return 0;
}
