#include<bits/stdc++.h>


using namespace std;
//#define int long long
#define ll long long
#define all (x) begin(x), end(x)
#define xx first
#define yy second


#define cin fin
#define cout fout

ifstream cin ("arbint.in");
ofstream cout ("arbint.out");


using pii = pair <int, int>;
using tii = tuple <int, int, int>;

constexpr int NMAX = (int) 1e5;

int copac[4*NMAX +5];
int n, m;
int query, a, b;

inline void constrcp (int i, int st, int dr){
    if (st == dr){
        cin >> copac[i];
        return;
    }
    int mijl = (st + dr) >> 1;
    constrcp (i * 2, st, mijl);
    constrcp (i * 2 + 1, mijl + 1, dr);
    copac[i] = max (copac[i * 2], copac[i * 2 + 1]);
}

inline void upd (int i, int st, int dr, int st1, int dr1){
    if (st == dr){
        copac[i] = dr1;
        return;
    }
    int mijl = (st + dr) >> 1;
    if (st1 <= mijl)
        upd (2 * i, st, mijl, st1, dr1);
    else
        upd (2 * i + 1, mijl + 1, dr, st1, dr1);
    copac[i] = max (copac[i * 2], copac[2 * i + 1]);
}

int solve (int i, int st, int dr, int xx, int yy){
    if (dr < xx || st > yy)
        return false;
    if (xx <= st && dr <= yy){
        return copac[i];
    }
    int mijl = (st + dr) >> 1;
    int val = solve (2 * i, st, mijl, xx, yy);
    int val1 = solve (2 * i + 1, mijl + 1, dr, xx, yy);
    return max (val, val1);
}
signed main(void){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin >> n >> m;
    constrcp (1, 1, n);
    while (m){
        cin >> query >> a >> b;
        if (query == 0)
            cout << solve (1, 1, n, a, b) << '\n';
        else
            upd (1, 1, n, a ,b);
        m --;
    }
    return 0;
}
