#include<bits/stdc++.h>
using namespace std;
int vec[100000];
int tree[4005];
void build(int nod,int st,int dr)
{
    if(st==dr)
        {tree[nod]=vec[dr];
        return;}
    int mij;
    mij=(st+dr)/2;
    build(2*nod,st,mij);
    build(2*nod+1,mij+1,dr);
    tree[nod]=max(tree[2*nod],tree[2*nod+1]);
}
void update(int nod,int st,int dr,int poz,int val)
{
    if(st==dr)
        {tree[nod]=val;
        return;}
    int mij;
    mij=(st+dr)/2;
    if(poz<=mij)
        update(2*nod,st,mij,poz,val);
    else
        update(2*nod+1,mij+1,dr,poz,val);
    tree[nod]=max(tree[2*nod],tree[2*nod+1]);
}
void query(int nod,int st,int dr,int x,int y,int &ans)
{
    if(x<=st&&dr<=y)
    {
        ans=max(ans,tree[nod]);
        return;
    }
    int mij;
    mij=(st+dr)/2;
    if(x<=mij)
        query(2*nod,st,mij,x,y,ans);
    if(y>mij)
        query(2*nod+1,mij+1,dr,x,y,ans);

}
int main()
{
    ifstream f("arbint.in");
    ofstream g("arbint.out");
    int N,M,i,a,b,op,var;
    f>>N>>M;
    for(i=1;i<=N;i++)
        f>>vec[i];
    build(1,1,N);
    for(i=1;i<=M;i++)
    {
        f>>op>>a>>b;
        if(op==0)
        {
            var=INT_MIN;
            query(1,1,N,a,b,var);
            g<<var<<endl;
        }
        if(op==1)
        update(1,1,N,a,b);
    }
}
