#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define N_MAX 100001

int tree[4 * N_MAX + 5];
int V[N_MAX];


int Max(int a, int b) {
    return (a > b) ? a : b;
}
void build(int node, int le, int ri) {
    if (le == ri) {
        tree[node] = V[le];
        return;
    }

    int mid = (le + ri) / 2;

    build(2 * node, le, mid);
    build(2 * node + 1, mid + 1, ri);

    tree[node] = Max(tree[2 * node], tree[2 * node + 1]);

}

void update(int node, int le, int ri, int pos, int val) {
    if (le == ri) {
        tree[node] = val;
        return;
    }

    int mid = (le + ri) / 2;

    if (pos <= mid) {
        update(2 * node, le, mid, pos, val);
    }
    else {
        update(2 * node + 1, mid + 1, ri, pos, val);
    }

    tree[node] = Max(tree[2 * node], tree[2 * node + 1]);
}

void query(int node, int le, int ri, int x, int y, int* ans) {
    if (x <= le && ri <= y) {
        *ans = Max(*ans, tree[node]);
        return;
    }

    int mid = (le + ri) / 2;

    if (x <= mid) {
        query(2 * node, le, mid, x, y, ans);
    }
    if (y > mid) {
        query(2 * node + 1, mid + 1, ri, x, y, ans);
    }
}

void afisare(int n) {
    for (int i = 1; i <= n; i++)
        printf("%d ", tree[i]);
    printf("\n");
}

int main()
{
    FILE* in = fopen("arbint.in", "r");
    FILE* out = fopen("arbint.out", "w");
    int n, m;
    int operatie, a, b;

    fscanf(in, "%d %d", &n, &m);
    for (int i = 1; i <= n; i++) {
        fscanf(in, "%d", &V[i]);
    }
    build(1, 1, n);
    afisare(n);

    for (int i = 1; i <= m; i++) {
        fscanf(in, "%d %d %d", &operatie, &a, &b);
        int val = INT_MIN;
        if (!operatie) {
            query(1, 1, n, a, b, &val);
            fprintf(out, "%d\n", val);
            afisare(n);
        }
        else
            update(1, 1, n, a, b);
    }

    fclose(in);
    fclose(out);
    return 0;
}