#include <fstream>

using namespace std;

#define dim 100001

int N, M, i, X, A, B;
int a[3 * dim];
int start, finish, Val, Pos, maxim;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

void Update(int nod, int l, int r) {
    int m;

    if (l < r) {
        m = (l + r) / 2;
        if (Pos <= m)
            Update(2 * nod, l, m);
        else
            Update(2 * nod + 1, m + 1, r);
        a[nod] = max(a[2 * nod], a[2 * nod + 1]);
    }
    else
        a[nod] = Val;
}

void Query(int nod, int l, int r) {
    int m;

    if (start <= l and r <= finish) { // Maximul intre [l, r] este in a[nod].
        if (maxim < a[nod])
            maxim = a[nod];
    }
    else {
        m = (l + r) / 2;
        if (start <= m)
            Query(2 * nod, l, m);
        if (m < finish)
            Query(2 * nod + 1, m + 1, r);
    }
}

    int main() {
        fin >> N >> M;
        for (i = 1; i <= N; i++) {
            fin >> X;
            Pos = i, Val = X;
            Update(1, 1, N);
        }
        for (i = 1; i <= M; i++) {
            fin >> X >> A >> B;
            if (X == 0) {
                maxim = -1;
                start = A, finish = B;
                Query(1, 1, N);
                fout << maxim << '\n';
            }
            else {
                Pos = A, Val = B;
                Update(1, 1, N);
            }
        }
        return 0;
    }

    /*
    42 68 35  1 70 25 79 59 63 65  6 46
     1  2  3  4  5  6  7  8  9 10 11 12
          --------------------
    start = 3, finish = 9

        Intrare nod = 1, l = 1, r = 12
            m = 6
            3 <= 6 (start <= m)
            Intrare nod = 2, l = 1, r = 6
                m = 3
                3 <= 3 (start <= m)
                Intrare nod = 4, l = 1, r = 3
                    m = 2
                    2 < 9 (m < finish)
                    Intrare nod = 9, l = 3, r = 3
                        Maximul intre [3,3] este in a[9] = 35
                        maxim = 35
                    Iesire nod = 9, l = 3, r = 3
                Iesire nod = 4, l = 1, r = 3
                3 < 9 (m < finish)
                Intrare nod = 5, l = 4, r = 6
                    Maximul intre [4,6] este in a[5] = 70
                    maxim = 70
                Iesire nod = 5, l = 4, r = 6
            Iesire nod = 2, l = 1, r = 6
            6 < 9 (m < finish)
            Intrare nod = 3, l = 7, r = 12
                m = 9
                3 <= 9 (start <= m)
                Intrare nod = 6, l = 7, r = 9
                    Maximul intre [7,9] este in a[6] = 79
                    maxim = 79
                Iesire nod = 6, l = 7, r = 9
            Iesire nod = 3, l = 7, r = 12
        Iesire nod = 1, l = 1, r = 12
    */