#include<bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n , m , A[400010] , t , a , b , maxi = INT_MIN;

inline void build(int nod , int st , int dr){
    if(st == dr)
        fin >> A[nod];
    else{
        int mid = (st + dr) / 2;
        build(2 * nod , st , mid);
        build(2 * nod + 1 , mid + 1 , dr);
        A[nod] = max(A[2 * nod] , A[2 * nod + 1]);
    }
}

inline void query(int nod , int st , int dr , int a , int b){
    if(a <= st && dr <= b){
        maxi = max(maxi , A[nod]);
    }
    else{
        int mid = (st + dr) / 2;
        if(a <= mid)
            query(2 * nod , st , mid , a , b);
        if(b > mid)
            query(2 * nod  + 1, mid + 1 , dr , a , b);
    }
}

inline void update(int nod , int st , int dr ,int poz , int x){
    if(st == dr)
        A[nod] = x;
    else{
        int mid = (st + dr) / 2;
        if(poz <= mid)
            update(2 * nod , st , mid , poz , x);
        if(poz > mid)
            update(nod * 2 + 1 , mid + 1 , dr , poz , x);
        A[nod] = max(A[2 * nod] , A[2 * nod + 1]);
    }
}

int main(){
    fin >> n >> m;
    build(1 , 1 , n);
    for(int i = 1 ; i <= m ; i++){
        fin >> t >> a >> b;
        if(t == 0){
            maxi = INT_MIN;
            query(1 , 1 , n , a , b);
            fout << maxi << '\n';
        }
        else{
            update(1 , 1 , n , a , b);
        }
    }
}
