#include <iostream>
#include <fstream>

using namespace std;

#ifdef LOCAL
#else
    #define cin fin
    #define cout fout
#endif // LOCAL

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX = 1e5;

int v[NMAX + 1];
int aint[4 * NMAX + 1];

void build(int node, int l, int r){
    if(l == r){
        aint[node] = v[l];
        return;
    }
    int mid = (l + r) / 2;
    build(2 * node, l, mid);
    build(2 * node + 1, mid + 1, r);
    aint[node] = max(aint[2 * node], aint[2 * node + 1]);
}

void update(int node, int l, int r, int pos, int val){
    if(l == r){
        aint[node] = val;
        return;
    }

    int mid = (l + r) / 2;
    if(pos <= mid){
        update(2 * node, l, mid, pos, val);
    }else{
        update(2 * node + 1, mid + 1, r, pos, val);
    }
    aint[node] = max(aint[2 * node], aint[2 * node + 1]);
}

int query(int node, int l, int r, int ql, int qr){
    if(ql <= l && r <= qr){
        return aint[node];
    }
    int mid = (l + r) / 2, ans = 0;
    if(ql <= mid){
        ans = max(ans, query(2 * node, l, mid, ql, qr));
    }
    if(mid + 1 <= qr){
        ans = max(ans, query(2 * node + 1, mid + 1, r, ql, qr));
    }
    return ans;
}

int main(){

    int n, m;
    cin >> n >> m;

    for(int i = 1; i <= n; i++){
        cin >> v[i];
    }

    build(1, 1, n);

    while(m--){
        int x, a, b;
        cin >> x >> a >> b;
        if(x == 0){
            cout << query(1, 1, n, a, b) << '\n';
        }else{
            update(1, 1, n, a, b);
        }
    }

    return 0;
}
