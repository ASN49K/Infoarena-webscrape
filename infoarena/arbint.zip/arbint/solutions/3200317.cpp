#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

#define N_MAX 100000
const int SQ = sqrt(N_MAX);
const int B_SIZE = (N_MAX + SQ - 1) / SQ;

int v[N_MAX];
int batog[B_SIZE];
int n;

void build() {
  int i;
  for(i = 0; i < n; ++i) {
    batog[i / SQ] = max(batog[i / SQ], v[i]);
  }
}

void update(int pos, int val) {
  int i, l, r;
  v[pos] = val;


  l = pos / SQ * SQ;
  r = l + SQ;
  while(l <= r) {
    batog[l / SQ] = max(batog[l / SQ], v[l]);
    ++l;
  }

}

int query(int left, int right) {
  int first, last, result;
  first = (left + SQ - 1) / SQ * SQ;
  last = right / SQ * SQ;

  result = 0;
  while(left <= right && left < first) {
    result = max(result, v[left++]);
  }
  while(right >= left && right >= last) {
    result = max(result, v[right--]);
  }

  first /= SQ;
  last /= SQ;

  while(first < last) {
    result = max(result, batog[first++]);
  }

  return result;
}

int main()
{
  int n, m, i, q, a, b;
  fin >> n >> m;
  for(i = 0; i < n; ++i) {
    fin >> v[i];
  }
  build();
  while(m--) {
    fin >> q >> a >> b;
    if(q == 0) {
      fout << query(a - 1, b - 1) << '\n';
    }else{
      update(a - 1, b);
    }
  }

  return 0;
}
