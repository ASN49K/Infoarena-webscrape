//https://infoarena.ro/problema/arbint

#pragma GCC optimize ("O3")
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("fast-math")
#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES

#include <iostream>
#include <fstream>
//#include <algorithm>
//#include <cmath>
//#include <vector>
//#include <bitset>
//#include <iomanip>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NRMAX = 100005;

int arb[4 * NRMAX + 5];
int v[NRMAX + 1];

int rezultat(int x, int in, int sf, int a, int b)
{
	if (a <= in && sf <= b)
		return arb[x];

	int ls = x * 2;
	int rs = ls + 1;
	int rez = 0;

	if (a <= (in + sf) / 2)
		rez = max(rezultat(ls, in, (in + sf) / 2, a, b), rez);
	if (b > (in + sf) / 2)
		rez = max(rezultat(rs, (in + sf) / 2 + 1, sf, a, b), rez);

	//cout << x << " " << in << " " << sf << " " << a << " " << b << "\n";
	//cout << rez << "rez\n";

	return rez;
}

void intrVal(int x, int in, int sf, int p, int val)
{
	//cout << x << " " << in << " " << sf << "\n";

	if (in == sf)
	{
		arb[x] = val;
		return;
	}

	int ls = x * 2;
	int rs = ls + 1;

	if (p <= (in + sf) / 2)
		intrVal(ls, in, (in + sf) / 2, p, val);
	else
		intrVal(rs, (in + sf) / 2 + 1, sf, p, val);

	arb[x] = max(arb[ls], arb[rs]);
}

void init(int x, int in, int sf)
{
	//cout << x << " " << in << " " << sf << "\n";

	if (in == sf)
	{
		arb[x] = v[in];
		return;
	}

	int ls = x * 2;
	int rs = ls + 1;

	init(ls, in, (in + sf) / 2);
	init(rs, (in + sf) / 2 + 1, sf);

	arb[x] = max(arb[ls], arb[rs]);
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);

	int n, m, i;
	int a, b;
	bool op;

	fin >> n >> m;
	for (i = 1; i <= n; ++i)
	{
		fin >> v[i];
	}

	init(1, 1, n);

	/*for (i = 1; i <= 9; ++i)
		cout << arb[i] << " ";
	cout << "\n";*/

	for (i = 1; i <= m; ++i)
	{
		fin >> op >> a >> b;

		if (op == 0)
			fout << rezultat(1, 1, n, a, b) << "\n";
		else //if (op == 1)
			intrVal(1, 1, n, a, b);

		/*for (int j = 1; j <= 9; ++j)
			cout << arb[j] << " ";
		cout << "\n";*/
	}


	return 0;
}