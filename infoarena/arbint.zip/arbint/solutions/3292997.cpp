#include <fstream>
using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

const int N=1e5;
int val,poz,start,finish,n,m,maxim,v[4*N+66];

void update(int nod,int left,int right)
{
    if(left==right)
    {
        v[nod]=val;
        return;
    }
    int mij=(left+right)/2;
    if(poz<=mij)
        update(2*nod,left,mij);
    else
        update(2*nod+1,mij+1,right);
    v[nod]=max(v[2*nod],v[2*nod+1]);
}
void query(int nod,int left, int right)
{
    if(start<=left && right<=finish)
    {
        maxim=max(maxim,v[nod]);
        return;
    }
    int mij=(left+right)/2;
    if(start<=mij)
        query(2*nod,left,mij);
    if(mij<finish)
        query(2*nod+1,mij+1,right);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        cin>>val;
        poz=i;
        update(1,1,n);
    }
    int a,b,q;
    for(int i=0;i<m;i++)
    {
        cin>>q>>a>>b;
        if(q==0)
        {
            maxim=-1;
            start=a;
            finish=b;
            query(1,1,n);
            cout<<maxim<<'\n';
        }
        else
        {
            poz=a;
            val=b;
            update(1,1,n);
        }
    }
    return 0;
}
