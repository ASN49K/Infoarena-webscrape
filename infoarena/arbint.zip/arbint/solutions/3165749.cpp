#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");ofstream fout("arbint.out");

int n,q;
vector<int> a;
vector<int> aint;


void Generare_AINT(int st,int dr,int p)
{
    if( p==0 )
    {
        int aux=1;
        while( aux<n )
            aux*=2;
        aint.resize( aux*2-1 );
    }
    if( st==dr )
    {
        aint[p]=a[st];

    }
    else
    {
        int mij=(st+dr)/2;
        Generare_AINT(st,mij,2*p+1);
        Generare_AINT(mij+1,dr,2*p+2);
        aint[p] = max( aint[2*p+1],aint[2*p+2] );
    }
}

int Interogare_AINT(int st,int dr,int p,int qst,int qdr)
{
    if( qst<=st and dr<=qdr )
        return aint[p];
if( dr<qst or qdr<st )return -1;/// conditie simpla
    int mij=(st+dr)/2;
    int ans=-1;
    ans= max(Interogare_AINT(st,mij,2*p+1,qst,qdr),ans );
    ans= max(Interogare_AINT(mij+1,dr,2*p+2,qst,qdr) ,ans);

    return ans;
}

void Inserare_AINT(int st,int dr,int p,int poz,int val)
{
    if( st==dr and st==poz)
    {
        aint[p]=val;
        a[poz]=val;
        return;
    }
    int mij=(st+dr)/2;
    if( st<=poz and poz<=mij )
       Inserare_AINT(st,mij,2*p+1,poz,val);
    if( mij< poz and poz<=dr )
        Inserare_AINT(mij+1,dr,2*p+2,poz,val);
    aint[p] = max( aint[2*p+1],aint[2*p+2] );
}



int main()
{
    fin >> n >> q;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin >> x;;
        a.push_back(x);
    }
    Generare_AINT(0,n-1,0);

    for(int i=1;i<=q;i++)
    {
        int tip,x,y;
        fin >> tip >> x >> y;
        if( tip==0 )
            fout << Interogare_AINT(0,n-1,0,x-1,y-1) <<"\n";
        if( tip==1 )
            Inserare_AINT(0,n-1,0,x-1,y);
    }
    fin.close();fout.close();
    return 0;
}
