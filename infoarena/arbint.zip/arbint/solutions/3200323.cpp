#include <stdio.h>
#include <math.h>

#define QU 0
#define UP 1

#define MAXN 100000
const int SQ = sqrt( MAXN );
const int BT = ( MAXN + SQ - 1 ) / SQ;

int n, q;
int v[ MAXN ];
int batog[ BT ];

int maxx( int x, int y )
{
	if( x > y )
		return x;
	return y;
}

void build( )
{
	for( int i = 0; i < n; i++ )
	{
		batog[ i / SQ ] = maxx( batog[ i / SQ ], v[ i ] );
	}
}

void update( int p, int val )
{
	if( batog[ p / SQ ] == v[ p ] )
	{
		v[ p ] = val;
		int aux = p / SQ;
		int first = p / SQ * SQ, last = p / SQ * SQ + SQ;

		batog[ aux ] = 0;
		while( first < last )
		{
			batog[ aux ] = maxx( batog[ aux ], v[ first ] );
			first++;
		}
	}
	else
	{
		v[ p ] = val;
		batog[ p / SQ ] = maxx( batog[ p / SQ ], val );
	}
}

int query( int l, int r )
{
	int first, last, ans;

	first = ( l + SQ - 1 ) / SQ * SQ;
	last = r / SQ * SQ;

	ans = 0;
	while( l <= r && l < first )
	{
		ans = maxx( ans, v[ l ] );
		l++;
	}

	while( l <= r && r > last )
	{
		ans = maxx( ans, v[ r ] );
		l--;
	}

	while( first < last )
	{
		ans = maxx( ans, batog[ first ] );
		first++;
	}

	return ans;
}

int main()
{
    FILE *fin, *fout;
    fin = fopen( "arbint.in", "r" );
    int operation, x, y, i;

    fscanf( fin, "%d%d", &n, &q );
    for( i = 0; i < n; i++ )
	{
		fscanf( fin, "%d", &v[ i ] );
	}

	build( );

	fout = fopen( "arbint.out", "w" );
	for( int i = 0; i < n / SQ; i++ )
	{
		fprintf( fout, "%d ", batog[ i ] );
	}
	while( q-- )
	{
		fscanf( fin, "%d%d%d", &operation, &x, &y );

		if( operation == UP )
		{
			update( x, y );

		}
//		else
//		{
//			fprintf( fout, "%d\n", query( x, y ) );
//		}
	}

	fclose( fin );
	fclose( fout );
    return 0;
}
