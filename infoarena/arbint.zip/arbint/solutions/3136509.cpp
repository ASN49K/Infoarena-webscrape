#include <bits/stdc++.h>
#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int N_MAX = 100000;

int tree[4 * N_MAX + 5];
int V[N_MAX + 5];
int maxi;

void build(int node, int le, int ri) 
{
    if(le == ri) 
    {
        tree[node] = V[le];
        return;
    }

    int mid = (le + ri) / 2;

    build(2 * node, le, mid);
    build(2 * node + 1, mid + 1, ri);

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void update(int node, int le, int ri, int pos, int val) 
{
    if(le == ri) 
    {
        tree[node] = val;
        return;
    }
    
    int mid = (le + ri) / 2;

    if(pos <= mid) 
    {
        update(2 * node, le, mid, pos, val);
    }
    else 
    {
        update(2 * node + 1, mid + 1, ri, pos, val);
    }

    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void query(int node, int le, int ri, int x, int y, int &ans) 
{
    if(x <= le && ri <= y) 
    {
        ans = max(ans, tree[node]);
        return;
    }

    int mid = (le + ri) / 2;

    if(x <= mid) 
    {
       return query(2 * node, le, mid, x, y, ans);
    }
    
    if(y > mid) 
    {
        return query(2 * node + 1, mid + 1, ri, x, y, ans);
    }
    
}

int main(void) 
{
    int n, m, op, a, b, maxim;
    
    fin >> n >> m;
    
    for(int i = 1; i <= n; i++)
    {
        fin >> V[i];
    }
    
    build(1, 1, n);
    
    while(m > 0)
    {
        fin >> op >> a >> b;
        switch(op)
        {
            case 0:
                maxim = 0;
                query(1, 1, n, a, b, maxim);
                fout << maxim << endl;
                break;
            case 1:
                update(1, 1, n, a, b);
                break;
        }
        m--;
    }
    
    fin.close();
    fout.close();
    
    return 0;
}
