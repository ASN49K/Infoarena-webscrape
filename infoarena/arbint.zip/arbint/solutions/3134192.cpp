#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>

std::ifstream fin("arbint.in");
std::ofstream fout("arbint.out");

const int MAX_SIZE = 10000000;
int arb[MAX_SIZE];

void insert(int x, int st, int dr, int p, int i) {
    if (st == dr) {
        arb[i] = x;
    }
    else {
        int m = (st + dr) / 2;

        if (p <= m) {
            insert(x, st, m, p, 2 * i);
        }
        else {
            insert(x, m + 1, dr, p, 2 * i + 1);
        }

        if (arb[2 * i] > arb[2 * i + 1]) {
            arb[i] = arb[2 * i];
        }
        else {
            arb[i] = arb[2 * i + 1];
        }
    }
}

int maxx(int st, int dr, int a, int b, int i) {
    if (a <= st && b >= dr) {
        return arb[i];
    }
    else {
        int m = (st + dr) / 2;

        if (a > m) {
            return maxx(m + 1, dr, a, b, 2 * i + 1);
        }
        else {
            if (b <= m) {
                return maxx(st, m, a, b, 2 * i);
            }
        }
        return std::max(maxx(st, m, a, m, 2 * i), maxx(m + 1, dr, m + 1, b, 2 * i + 1));
    }
}

int main() {
    int n, m, x, a, b;
    fin >> n >> m;
    for (int i = 0; i < n; ++i) {
        fin >> x;
        insert(x, 1, n, i + 1, 1);
    }
    for (int i = 0; i < m; ++i) {
        fin >> x >> a >> b;
        if (x == 0) {
            fout << maxx(1, n, a, b, 1) << "\n";
        }
        else {
            insert(b, 1, n, a, 1);
        }
    }
    return 0;
}
