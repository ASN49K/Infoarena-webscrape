//https://www.infoarena.ro/problema/arbint

//#pragma GCC optimize("O3")   
//#pragma GCC optimize("Ofast") 
//#pragma GCC optimize("fast-math") 
//#pragma GCC optimize("unroll-loops") 
//#pragma GCC optimize("inline")  
//#define _USE_MATH_DEFINES
//#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NRMAX = 100000;
const int SQRTNR = 317; // 317
const int BATMAX = (NRMAX + SQRTNR - 1) / SQRTNR;

int n;
int v[NRMAX + 1];
int bat[BATMAX + 1];

// squere root decomposition
void init()
{
	for (int i = 1; i <= n; ++i)
	{
		int batPos = (i - 1) / SQRTNR + 1;
		bat[batPos] = max(bat[batPos], v[i]);
		//cout << batPos << " " << i << "\n";
	}
}

void update(int pos, int val)
{
	int batPos = (pos - 1) / SQRTNR + 1;

	bat[batPos] = 0;
	v[pos] = val;

	int st = (batPos - 1) * SQRTNR + 1;
	int dr = min(n, batPos * SQRTNR);

	//cout << st << " " << dr << "\n";

	for (int i = st; i <= dr; ++i)
		bat[batPos] = max(bat[batPos], v[i]);
}

int query(int st, int dr)
{
	int rez = 0;
	
	while(st <= dr && (st - 1) % SQRTNR != 0)
		rez = max(rez, v[st++]);

	while (st + SQRTNR - 1 <= dr)
	{
		int batPos = (st - 1) / SQRTNR + 1;
		rez = max(rez, bat[batPos]);
		st += SQRTNR;
	}

	while (st <= dr)
		rez = max(rez, v[st++]);

	return rez;
}


int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	int m, i, op, x, y;

	fin >> n >> m;

	for (i = 1; i <= n; ++i)
		fin >> v[i];

	init();

	for (i = 1; i <= m; ++i)
	{
		fin >> op >> x >> y;
		if (op == 1)
			update(x, y);
		else
			fout << query(x, y) << "\n";

		/*for (int j = 1; j <= n / SQRTNR + 1; ++j)
			cout << bat[j] << " ";
		cout << "\n";*/
	}

	return 0;
}