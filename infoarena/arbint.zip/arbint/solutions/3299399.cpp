#include <iostream>
#include <fstream>
using namespace std;
#define NMAX 100000
#define INF -1
ifstream f("arbint.in");
ofstream g("arbint.out");

int tree[4 * NMAX + 5];
int A[NMAX + 5];
int N,M;
void build(int node, int le, int ri){
    if(le == ri){
        tree[node] = A[le];
    }
    else{
        int mid = (le + ri) / 2;
        build(2 * node, le, mid);
        build(2 * node + 1, mid + 1, ri);
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

void update(int node, int le, int ri, int pos, int val){
    if(le == ri){
        tree[node] = val;
    }
    else{
        int mid = (le + ri) / 2;
        if(pos <= mid){
            update(2 * node, le, mid, pos, val);
        }
        else{
            update(2 * node + 1, mid + 1, ri, pos, val);
        }
        tree[node] = max(tree[2 * node], tree[2 * node + 1]);
    }
}

int query(int node, int le, int ri, int x, int y){
    if(x <= le && ri <= y){
        return tree[node];
    }
    if(y<le || ri<x){
        return INF;
    }
    int mid = (le + ri) / 2;
    return max(
               query(node*2,le,mid,x,y),
               query(node*2+1, mid+1, ri, x ,y)
               );
}

int main()
{
    f>>N>>M;
    for(int i=1;i<=N;++i){
        f>>A[i];
    }
    build(1,1,N);
    for(int i=1;i<=M;++i){
        int a,b,op;
        f>>op>>a>>b;
        if(op == 0){
            g<<query(1,1,N,a,b)<<'\n';
        }
        else{
            update(1,1,N,a,b);
        }
    }


    f.close();
    g.close();
    return 0;
}

