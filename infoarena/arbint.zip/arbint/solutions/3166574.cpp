#include <iostream>
#include <fstream>

using namespace std;

const int NMAX = 100000;
int v[NMAX + 1];
int arb[4 * NMAX + 1];

int max(int a, int b) {
    return a > b ? a : b;
}

void uniteParents(int nodeId, int leftNodeId, int rightNodeId) {
    arb[nodeId] = max(arb[leftNodeId], arb[rightNodeId]);
}

void build(int nodeId, int leftIndex, int rightIndex) {
    if (leftIndex == rightIndex) {
        arb[nodeId] = v[leftIndex];
        return;
    }

    int middle = (leftIndex + rightIndex) / 2;
    build(2 * nodeId, leftIndex, middle);
    build(2 * nodeId + 1, middle + 1, rightIndex);
    uniteParents(nodeId, 2 * nodeId, 2 * nodeId + 1);
}

void update(int nodeId, int leftIndex, int rightIndex, int updateIndex, int updateValue) {
    if (leftIndex == rightIndex) {
        arb[nodeId] = updateValue;
        return;
    }

    int middle = (leftIndex + rightIndex) / 2;
    if (updateIndex <= middle)
        update(2 * nodeId, leftIndex, middle, updateIndex, updateValue);
    else
        update(2 * nodeId + 1, middle + 1, rightIndex, updateIndex, updateValue);
    
    uniteParents(nodeId, 2 * nodeId, 2 * nodeId + 1);
}

int uniteQueries(int queryLeftBranch, int queryRightBranch) {
    return max(queryLeftBranch, queryRightBranch);
}

int query(int nodeId, int leftIndex, int rightIndex, int queryLeftIndex, int queryRightIndex) {
    if (rightIndex < queryLeftIndex || queryRightIndex < leftIndex) {
        return 0;
    }

    if (queryLeftIndex <= leftIndex && rightIndex <= queryRightIndex) {
        return arb[nodeId];
    }

    int middle = (leftIndex + rightIndex) / 2;
    int queryLeftBranch = query(2 * nodeId, leftIndex, middle, queryLeftIndex, queryRightIndex);
    int queryRightBranch = query(2 * nodeId + 1, middle + 1, rightIndex, queryLeftIndex, queryRightIndex);

    return uniteQueries(queryLeftBranch, queryRightBranch);
}

int main()
{
    FILE *fin, *fout;
    fin = fopen("arbint.in", "r");
    fout = fopen("arbint.out", "w");

    int n, m, op, a, b;

    fscanf(fin, "%d %d", &n, &m);
    for (int i = 1; i <= n; i++)
        fscanf(fin, "%d", &v[i]);
    build(1, 1, n);
    
    for (int i = 0; i < m; i++) {
        fscanf(fin, "%d %d %d", &op, &a, &b);
        if (op == 0)
            fprintf(fout, "%d\n", query(1, 1, n, a, b));
        else
            update(1, 1, n, a, b);
    }

    return 0;
}