#include <fstream>
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,m,i,aint[400005],v[100005],tip,x,y;
void build(int nod,int st,int dr)
{
    if(st==dr)
    {
        aint[nod]=v[st];
        return;
    }
    int mij;
    mij=(st+dr)/2;
    build(2*nod,st,mij);
    build(2*nod+1,mij+1,dr);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
void update(int nod,int st,int dr,int poz,int val)
{
    if(st==dr)
    {
        aint[nod]=val;
        return;
    }
    int mij;
    mij=(st+dr)/2;
    if(poz<=mij)
        update(2*nod,st,mij,poz,val);
    else
        update(2*nod+1,mij+1,dr,poz,val);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
int query(int nod,int st,int dr,int x,int y)
{
    if(x<=st && dr<=y)
        return aint[nod];
    int mij,val1=0,val2=0;
    mij=(st+dr)/2;
    if(mij>=x)
        val1=query(2*nod,st,mij,x,y);
    if(mij+1<=y)
        val2=query(2*nod+1,mij+1,dr,x,y);
    return max(val1,val2);
}
int main()
{
    cin>>n>>m;
    for(i=1;i<=n;i++)
        cin>>v[i];
    build(1,1,n);
    for(i=1;i<=m;i++)
    {
        cin>>tip>>x>>y;
        if(tip==0)
            cout<<query(1,1,n,x,y)<<'\n';
        else
            update(1,1,n,x,y);
    }
    return 0;
}
