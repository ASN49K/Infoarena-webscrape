#include <iostream>
#include <fstream>

using namespace std;

const int Nmax = 100005;

int n, m, v[Nmax], aint[4*Nmax];

void Build(int st, int dr, int nod){
    if(st == dr){
        aint[nod] = v[st];
        return;
    }
    int mij = (st + dr) >> 1;
    Build(st, mij, 2*nod);
    Build(mij + 1, dr, 2*nod+1);
    aint[nod] = max(aint[2*nod], aint[2*nod + 1]);
}

void Update(int st, int dr, int nod, int x, int y){
    if(st == dr){
        aint[nod] = y;
        return;
    }
    int mij = (st + dr) >> 1;
    if(x <= mij){
        Update(st, mij, 2*nod, x, y);
    }
    else{
        Update(mij+1, dr, 2*nod+1, x, y);
    }
    aint[nod] = max(aint[2*nod], aint[2*nod+1]);
}

int Query(int st, int dr, int nod, int x, int y){
    if(st == x && dr == y){
        return aint[nod];
    }
    int mij = (st + dr) >> 1;
    if(y <= mij){
        Query(st, mij, 2*nod, x, y);
    }
    else{
        if(x > mij){
            Query(mij+1, dr, 2*nod+1, x, y);
        }
        else{
            return max(Query(st, mij, 2*nod, x, mij), Query(mij+1, dr, 2*nod+1, mij+1, y));
        }
    }
}

int main()
{
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    fin >> n >> m;
    for(int i = 1; i <= n; i++){
        fin >> v[i];
    }
    Build(1, n, 1);
    while(m--){
        int op, a, b;
        fin >> op >> a >> b;
        if(op == 1){
            Update(1, n, 1, a, b);
        }
        if(op == 0){
            fout << Query(1, n, 1, a, b) << "\n";
        }
    }


    return 0;
}
