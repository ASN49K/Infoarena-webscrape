#include <fstream>
#include <math.h>

using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

#define MAXN 100000
const int SQRT_N = sqrt(MAXN);
const int BATOG_SZ = (MAXN+SQRT_N-1)/SQRT_N;

int n, m;
int v[MAXN+1];
int bucket[BATOG_SZ+1];

void build() {
    int i;
    for(i=0; i<n; i++)
        bucket[i/SQRT_N]=max(bucket[i/SQRT_N], v[i]);
}

void update(int pos, int val) {
    int st, dr;
    v[pos]=val;
    st=pos/SQRT_N*SQRT_N;
    dr=st+SQRT_N;
    bucket[pos/SQRT_N]=0;
    while(st<dr)
        bucket[pos/SQRT_N]=max(bucket[pos/SQRT_N], v[st++]);
}

int query(int st, int dr) {
    int l, r, sol;
    l=(l+SQRT_N-1)/SQRT_N*SQRT_N;
    r=dr/SQRT_N*SQRT_N;
    sol=0;
    while(st<=dr && st<l)
      sol=max(sol, v[st++]);
    while(dr>=st && dr>=r)
      sol=max(sol, v[dr--]);
    l/=SQRT_N;
    r/=SQRT_N;
    while(l<r)
      sol=max(sol, bucket[l++]);
    return sol;
}

int main() {
    cin>>n>>m;
    int i;
    for(i=0; i<n; i++)
        cin>>v[i];
    build();
    int t, a, b;
    while(m--) {
        cin>>t>>a>>b;
        if(t==0)
            cout<<query(a-1, b-1)<<'\n';
        else
            update(a-1, b);
    }
}
