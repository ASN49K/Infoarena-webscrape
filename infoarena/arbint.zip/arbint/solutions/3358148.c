#include <stdio.h>

#define NMAX 100000

int N, M;

int arbore[4 * NMAX + 5];

int pozitie;
int valoare;

int stanga_interval;
int dreapta_interval;
int maxim;

int Maxim(int a, int b)
{
    if (a > b)
        return a;

    return b;
}

void update(int nod, int stanga, int dreapta)
{
    if (stanga == dreapta)
    {
        arbore[nod] = valoare;
        return;
    }

    int mijloc = (stanga + dreapta) / 2;

    if (pozitie <= mijloc)
        update(2 * nod, stanga, mijloc);
    else
        update(2 * nod + 1, mijloc + 1, dreapta);

    arbore[nod] = Maxim(
        arbore[2 * nod],
        arbore[2 * nod + 1]
    );
}

void query(int nod, int stanga, int dreapta)
{
    if (stanga_interval <= stanga &&
        dreapta <= dreapta_interval)
    {
        if (arbore[nod] > maxim)
            maxim = arbore[nod];

        return;
    }

    int mijloc = (stanga + dreapta) / 2;

    if (stanga_interval <= mijloc)
        query(2 * nod, stanga, mijloc);

    if (mijloc < dreapta_interval)
        query(2 * nod + 1, mijloc + 1, dreapta);
}

int main()
{
    FILE *in, *out;

    int operatie;
    int A, B;
    int x;

    in = fopen("arbint.in", "r");
    out = fopen("arbint.out", "w");

    fscanf(in, "%d %d", &N, &M);

    for (int i = 1; i <= N; i++)
    {
        fscanf(in, "%d", &x);

        pozitie = i;
        valoare = x;

        update(1, 1, N);
    }

    for (int i = 1; i <= M; i++)
    {
        fscanf(in, "%d %d %d", &operatie, &A, &B);

        if (operatie == 0)
        {
            stanga_interval = A;
            dreapta_interval = B;

            maxim = -1;

            query(1, 1, N);

            fprintf(out, "%d\n", maxim);
        }
        else
        {
            pozitie = A;
            valoare = B;

            update(1, 1, N);
        }
    }

    fclose(in);
    fclose(out);

    return 0;
}