#include <fstream>

using namespace std ;

ifstream cin ("arbint.in") ;
ofstream cout ("arbint.out") ;

const int dim = 100000 ;

int n, m, a, b, ans = -1 ;
int t[4 * dim + 2] ;

void build (int node, int l, int r)
{
    if (l == r)
        cin >> t[node] ;

    else
    {
        int mid = (l + r) / 2 ;
        build (2 * node, l, mid) ;
        build (2 * node + 1, mid + 1, r) ;
        t[node] = max (t[2 * node], t[2 * node + 1]) ;
    }
}

void query (int node, int l, int r, int a, int b)
{
    if (a <= l && r <= b)
        ans = max (ans, t[node]) ;

    else
    {
        int mid = (l + r) / 2 ;

        if (a <= mid)
            query (2 * node, l, mid, a, b) ;

        if (b > mid)
            query (2 * node + 1, mid + 1, r, a, b) ;
    }
}

void update (int node, int l, int r, int a, int b)
{
    if (l == r)
        t[node] = b ;
    else
    {
        int mid = (l + r) / 2 ;

        if (a <= mid)
            update (2 * node, l, mid, a, b) ;

        if (a > mid)
            update (2 * node + 1, mid + 1, r, a, b) ;

        t[node] = max (t[2 * node], t[2 * node + 1]) ;
    }
}

int main()
{
    int q ;

    cin >> n >> m ;

    build (1, 1, n) ;

    for (int i = 1 ; i <= n ; i ++)
    {
        cin >> q >> a >> b ;

        if (!q)
        {
            ans = -1 ;
            query (1, 1, n, a, b) ;
            cout << ans << '\n' ;
        }

        else
            update (1, 1, n, a, b) ;

    }

    return 0 ;

}
