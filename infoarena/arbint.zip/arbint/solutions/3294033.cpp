#include<bits/stdc++.h>
using namespace std;
unsigned long long arb[200010];
int a[100010], idxInArb[200010], n, q;

void printArb(){
    for(int i=1; i<2*n; i++) {
        cout<<arb[i]<<" ";
        if(log2(i+1) == floor(log2(i+1))) cout<<"\n";
    }
}

void buildArb(int st, int dr, int nod) {
    if(st==dr) {arb[nod]=a[st]; idxInArb[st]=nod;}
    else {
        int mid=(st+dr)/2;
        buildArb(st, mid, nod*2);
        buildArb(mid+1, dr, nod*2+1);
        arb[nod]=max(arb[nod*2],arb[nod*2+1]);
    }
}

int maxx(int a, int b, int st, int dr, int nod) {
    if(dr<a || st>b) return 0;
    if(st>=a && dr<=b) return arb[nod];
    else {
        int mid=(st+dr)/2;
        return max(maxx(a,b,mid+1,dr,nod*2+1), maxx(a,b,st,mid,nod*2));
    }
}

void update(int pos, int newN) {
    int idx=idxInArb[pos];
    arb[idx]=newN;
    do{
        idx/=2;
        arb[idx]=arb[idx*2];
        if(idx*2+1<=n) arb[idx]=max(arb[idx], arb[idx*2+1]);
        arb[idx]=max(arb[idx*2], arb[idx*2+1]);
    }while(idx>1);
}

int main() {
    freopen("arbint.in", "r", stdin);
    freopen("arbint.out", "w", stdout);
    cin>>n>>q;
    for(int i=1; i<=n; i++) cin>>a[i];
    buildArb(1, n, 1);
    while(q--) {
        int c,a,b;
        cin>>c>>a>>b;
        if(c) update(a,b);
        else cout<<maxx(a,b,1,n,1)<<"\n";
    }
    return 0;
}
