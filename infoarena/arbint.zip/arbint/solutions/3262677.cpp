#include <iostream>
#include <fstream>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

const int NMAX = 100000 + 5, INF = 1e9 + 5;

int aint[NMAX * 4], n, m, v[NMAX], op, a, b, maxi;

void Build(int st, int dr, int nod)
{
    int m;
    if (st == dr)
        aint[nod] = v[st];
    else
    {
        m = (st+dr)/2;
        Build(st, m, 2*nod);
        Build(m + 1, dr, 2*nod+1);
        aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
}

void Query(int st, int dr, int nod, int a, int b)
{
    int m;

    if (a <= st && b >= dr) /// ma incadrez in interval
        maxi =  max(maxi, aint[nod]);
    else
    {
        m = (st+dr)/2;
        if (a <= m)
            Query(st, m, 2*nod, a, b);
        if (b > m)
            Query(m + 1, dr, 2*nod+1, a, b);
    }
}

void Update(int st, int dr, int nod, int poz, int val)
{
    int m;
    if (st == dr)
        aint[nod] = val;
    else
    {
        m = (st+dr)/2;
        if (poz <= m)
            Update(st, m, 2*nod, poz, val);
        else
            Update(m + 1, dr, 2*nod+1, poz, val);
        aint[nod] = max(aint[2*nod], aint[2*nod+1]);
    }
}

int main()
{
    f >> n >> m;
    for (int i = 1; i<=n; ++i)
        f >> v[i];
    Build(1, n, 1);
    for (int i = 1; i<=m; ++i)
    {
        f >> op >> a >> b;
        if (op == 0)
        {
            maxi = -INF;
            Query(1, n, 1, a, b);
            g << maxi << '\n';
        }
        else
            Update(1, n, 1, a, b);

    }
    return 0;
}
