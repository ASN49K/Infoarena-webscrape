#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n,m,A[100001];

int maxim(int a,int b)
{
    int max1=0;
    while(a<=b)
    {
        max1 = max(max1,max(A[a],A[b]));
        a++;
        b--;
    }
    return max1;
}

int main()
{
    int c,a,b,i;
    fin>>n>>m;
    for(i=1;i<=n;i++)
        fin>>A[i];
    for(i=1;i<=m;i++)
    {
        fin>>c>>a>>b;
        if(c==0)
        {
            fout<<maxim(a,b)<<"\n";
        }
        if(c==1)
        {
            A[a] = b;
        }
    }
    return 0;
}
