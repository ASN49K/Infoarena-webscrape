//
//  main.c
//  arbori_de_intervale
//
//  Created by Bran Eduard Denis on 01.06.2023.
//

#include <stdio.h>
#include <stdlib.h>

#define N_MAX 100000

int tree[N_MAX];
int v[N_MAX];

int max(int a, int b)
{
    if(a>b)
        return a;
    else
        return b;
}

void build(int nod, int st, int dr)
{
    if(st==dr)
    {
        tree[nod]=v[st];
    }
    else
    {
        
        int mij=(st+dr)/2;
        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);
        
        tree[nod] = max(tree[2*nod],tree[2*nod+1]);
    }
}

void update(int nod,int st, int dr, int pos, int val)
{
    if(st==dr)
    {
        tree[nod]=val;
    }
    else
    {
        int mij=(st+dr)/2;
        
        if(pos<=mij)
            update(2*nod,st,mij,pos,val);
        else
            update(2*nod+1,mij+1,dr,pos,val);
        
        tree[nod]=max(tree[2*nod],tree[2*nod+1]);
    }
}

void query(int nod, int st, int dr, int x, int y, int* ans)
{
    if(x<=st && dr<=y)
    {
        *ans=max(*ans,tree[nod]);
    }
    else
    {
        
        int mij=(st+dr)/2;
        
        if(x<=mij)
            query(2*nod,st,mij,x,y,ans);
        
        if(y>mij)
            query(2*nod+1,mij+1,dr,x,y,ans);
    }
}

int main() {
    
    int M,N,o,a,b,maxi;
    FILE*fin,*fout;
    fin=fopen("arbint.in","rt");
    fout=fopen("arbint.out","wt");
    if(fin==NULL || fout==NULL)
    {
        printf("Eroare");
        return 0;
    }
    fscanf(fin,"%d %d",&N,&M);
    for(int i=1;i<=N;++i)
        fscanf(fin,"%d",&v[i]);
    build(1,1,N);
    for(int i=0;i<M;++i)
    {
        fscanf(fin,"%d %d %d",&o,&a,&b);
        if(o==0)
        {
            maxi=-1;
            query(1,1,N,a,b,&maxi);
            fprintf(fout,"%d\n",maxi);
        }
        else
        {
            update(1,1,N,a,b);
        }
    }

    return 0;
}
