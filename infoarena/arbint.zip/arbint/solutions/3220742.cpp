#include <bits/stdc++.h>

using namespace std;


ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int findMax(int a, int b)
{
    int z, i, max;
 
    // Perform the subtraction
    z = a - b;
 
    // Right shift and Bitwise AND
    i = (z >> 31) & 1;
 
    // Find the maximum number
    max = a - (i * z);
 
    // Return the maximum value
    return max;
}
 

int v[100002], n, m;
int calc (int l, int r) {
  int mx = 0;
  #pragma omp pararell for schedule (dynamic) num_threads(8) 
    for (int i = l; i <= r; i++) {
      mx = mx - ((((mx - v[i]) >> 31) & 1) * (mx - v[i]));
    }
  return mx;
}
int main () 
{
  ios_base::sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  fin >> n >> m;
  for (int i = 1; i <= n; i++)
    fin >> v[i];
  for (int i = 1; i <= m; i++) {
    int t, a, b;
    fin >> t >> a >> b;
    if (t == 1) v[a] = b;
    else fout << calc(a, b) << "\n";
  }
  return 0;
}