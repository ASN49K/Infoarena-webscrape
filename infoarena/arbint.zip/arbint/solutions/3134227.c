#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define max(a,b)    (a > b) ? (a) : (b)

void buildTree(int *v,int *t,int nod,int l,int r){
    // printf("nod %d l:%d r:%d\n",nod,l,r);
    if(l > r){
        return;
    }
    if(l == r){
        t[nod] = v[l];
    }
    else{
        int m = (l + r) / 2;
        buildTree(v,t,2 * nod,l,m);
        buildTree(v,t,2 * nod + 1,m + 1,r);
        t[nod] = max(t[2 * nod],t[2 * nod + 1]);
    }
}

void update(int *t,int nod,int pos,int val,int l,int r){
    if(l == r){
        t[nod] = val;
    }
    else{
        int m = (l + r) / 2;
        if(pos <= m){
            update(t,2 * nod,pos,val,l,m);
        }
        else{
            update(t,2 * nod + 1,pos,val,m + 1,r);
        }
        t[nod] = max(t[2 * nod],t[2 * nod + 1]);
    }
}

void query(int *t,int nod,int l,int r,int x,int y,int *ans){
    if(l >= x && r <= y){
        *ans = max(*ans,t[nod]);
    }
    else{
        int m = (l + r) / 2;
        if(x <= m){
            query(t,2 * nod,l,m,x,y,ans);
        }
        if(y > m){
            query(t,2 * nod + 1,m + 1,r,x,y,ans);
        }
    }
}

int main(){
    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);
    int n,m,a,b,o,ans;
    scanf("%d %d",&n,&m);

    int *v = malloc((n + 5) * sizeof(int));
    int *t = malloc((4 * n + 5) * sizeof(int));

    for(int i = 1;i <= n;++i){
        scanf("%d",v+i);
    }
    
    buildTree(v,t,1,1,n);

    for(int i=0;i<m;++i){
        scanf("%d %d %d",&o,&a,&b);
        if(o == 0){
            ans = -INT_MAX;
            query(t,1,1,n,a,b,&ans);
            printf("%d\n",ans);
        }
        else{
            update(t,1,a,b,1,n);
        }
    }

    return 0;
}