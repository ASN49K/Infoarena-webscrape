#include <bits/stdc++.h>
#define FastIo() ios_base::sync_with_stdio(false), fin.tie(nullptr),fout.tie(nullptr);
#define ll int64_t
#define pii pair<int,int>
#define pipii pair<int,pair<int,int>>
using namespace  std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");
//
//#define fin cin
//#define fout cout

int n, m;
int op,a,b;
int number;
//const int NMAX = 500001;

struct SegTree {
    vector<int> tree;

    SegTree(int size) {
        tree.resize(4 * size);
        buildTree();
    }

    void buildTree(int node = 1, int l = 1, int r = n) {
        if (l == r) {
            fin >> number;
            tree[node] = number;
        } else {
            int m = (l + r) / 2;
            buildTree(2 * node, l, m);
            buildTree(2 * node + 1, m + 1, r);
            tree[node] = max(tree[2 * node], tree[2 * node + 1]);
        }
    }

    int query(int node, int l, int r, int queryL, int queryR) {
        if (queryL <= l && r <= queryR) {
            return tree[node];
        } else {
            int m = (l + r) / 2;

            if (queryR <= m) return query(2 * node, l, m, queryL, queryR);
            if (m < queryL) return query(2 * node + 1, m + 1, r, queryL, queryR);
            return max(query(2 * node, l, m, queryL, queryR), query(2 * node + 1, m + 1, r, queryL, queryR));
        }
    }

    void update(int node, int l, int r, int pos, int value) {
        if (l == r)
            tree[node] = value;
        else {
            int m = (l + r) / 2;
            if (pos <= m)
                update(2 * node, l, m, pos, value);
            else
                update(2 * node + 1, m + 1, r, pos, value);
            tree[node] = max(tree[2 * node], tree[2 * node + 1]);
        }
    }
};
int main(){

    fin>>n>>m;
    SegTree st = SegTree(n);

    for(int i=1;i<=m;i++){
        fin>>op>>a>>b;
        if(op==0) fout<<st.query(1,1,n,a,b)<<'\n';
        else st.update(1,1,n,a,b);
    }

}