#include <stdio.h>
#include <stdlib.h>

FILE *in, *out;
int n, m;
int v[100001];
int aint[400001];

void build(int nod, int st, int dr)
{
    if(st == dr)
    {
        aint[nod] = v[st];
        return;
    }

    int mijloc = (st+dr)/2;

    build(2*nod, st, mijloc);
    build(2*nod+1, mijloc+1, dr);

    if(aint[2*nod] > aint[2*nod+1])
        aint[nod] = aint[2*nod];
    else
        aint[nod] = aint[2*nod+1];
}

int query(int nod, int st, int dr, int a, int b)
{
    if(a <= st && dr <= b)
        return aint[nod];

    if(dr < a || st > b)
        return -1;

    int mijloc = (st+dr)/2;
    int stanga = query(2*nod, st, mijloc, a, b);
    int dreapta = query(2*nod+1, mijloc+1, dr, a, b);
    
    if(stanga > dreapta)
        return stanga;
    else
        return dreapta;
}

void update(int nod, int st, int dr, int poz, int val)
{
    if(st == dr)
    {
        aint[nod] = val;
        return;
    }

    int mijloc = (st+dr)/2;
    if(poz <= mijloc)
        update(2*nod, st, mijloc, poz, val);
    else
        update(2*nod+1, mijloc+1, dr, poz, val);

    if(aint[nod*2] > aint[nod*2+1])
        aint[nod] = aint[nod*2];
    else
        aint[nod] = aint[nod*2+1];
}

int main(void)
{
    in = fopen("arbint.in", "r");
    out = fopen("arbint.out", "w");

    if(in == NULL)
    {
        perror("eroare la deschidere fisier de intrare\n");
        exit(EXIT_FAILURE);
    }
    if(out == NULL)
    {
        perror("eroare la deschidere fisier de iesire\n");
        exit(EXIT_FAILURE);
    }

    if(fscanf(in, "%d %d", &n, &m) != 2)
    {
        perror("eroare la citire date de intrare\n");
        exit(EXIT_FAILURE);
    }

    for(int i = 1; i <= n; i++)
    {
        if(fscanf(in, "%d", &v[i]) != 1)
        {
            perror("eroare la citire elemente tablou\n");
            exit(EXIT_FAILURE);
        }
    }

    build(1, 1, n);

    for(int i = 1; i <= m; i++)
    {
        int op, a, b;
        if(fscanf(in, "%d %d %d", &op, &a, &b) != 3)
        {
            perror("eroare la citire operatii\n");
            exit(EXIT_FAILURE);
        }

        //efectuare operatii
        if(op == 0)
            fprintf(out, "%d\n", query(1, 1, n, a, b));
        else
            update(1, 1, n, a, b);

    }

    if(fclose(in) != 0)
    {
        perror("eroare la inchidere fisier intrare\n");
        exit(EXIT_FAILURE);
    }
    if(fclose(out) != 0)
    {
        perror("eroare la inchidere fisier iesire\n");
        exit(EXIT_FAILURE);
    }

    return 0;
}