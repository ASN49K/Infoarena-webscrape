#include <fstream>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int a_int[1000000+5];
int num_elemente, num_queries;
int valoare;
bool tip_query;
int x, y;

void update(int pozitie, int valoare, int nod = 1, int st = 1, int dr = num_elemente){
    if(st == dr){
        a_int[nod] = valoare;
        return;
    }
    int mijloc = (st + dr) / 2;
    if(pozitie <= mijloc){
        update(pozitie, valoare, nod * 2, st, mijloc);
    }
    else{
        update(pozitie, valoare, nod * 2 + 1, mijloc + 1, dr);
    }
    a_int[nod] = max(a_int[nod * 2], a_int[nod * 2 + 1]);
}

int query(int st_prim, int dr_prim, int nod = 1, int st = 1, int dr = num_elemente){
    if(st_prim <= st && dr <= dr_prim){
        return a_int[nod];
    }
    int maxim = -2e9;
    int mijloc = (st + dr) / 2;
    if(st_prim <= mijloc){
        maxim = max(maxim, query(st_prim, dr_prim, nod * 2, st, mijloc));
    }
    if(dr_prim >= mijloc + 1){
        maxim = max(maxim, query(st_prim, dr_prim, nod * 2 + 1, mijloc + 1, dr));
    }
    return maxim;
}

int main(){
    fin >> num_elemente >> num_queries;
    for(int i = 1; i <= num_elemente; i++){
        fin >> valoare;
        update(i, valoare);
    }
    for(int i = 1; i <= num_queries; i++){
        fin >> tip_query >> x >> y;
        if(tip_query == 0){
            fout << query(x, y) << '\n';
        }
        else if(tip_query == 1){
            update(x, y);
        }
    }
    return 0;
}
