#include <iostream>
#include <fstream>
#define MAXN 100000
#define P(x) (x - 1) / 2
#define CL(x) x*2 + 1
#define CR(x) x*2 + 2

using namespace std;

int v[MAXN], aint[2 * MAXN];

int getMax(int node, int l, int r, int a, int b){
  if(l == a && r == b)
    return aint[node];

  int mid = (l + r) / 2;
  if(b <= mid)
    return getMax(CL(node), l, mid, a, b);
  if(a > mid)
    return getMax(CR(node), mid + 1, r, a, b);

  return max(getMax(CL(node), l, mid, a, mid), getMax(CR(node), mid + 1, r, mid + 1, b));
}
int update(int node, int l, int r, int id, int x){
  if(l == r && r == id){
    aint[node] = x;
    return x;
  }

  int mid = (l + r) / 2;
  if(id <= mid){
    aint[node] = max(update(CL(node), l, mid, id, x), aint[CR(node)]);
  
  } else
    aint[node] = max(aint[CL(node)], update(CR(node), mid + 1, r, id, x));

  return aint[node];
}

void getVal(int node, int l, int r){
  if(l == r){
    aint[node] = v[l];
    return;
  }

  int mid = (l + r) / 2;
  getVal(CL(node), l, mid);
  getVal(CR(node), mid + 1, r);
  aint[node] = max(aint[CL(node)], aint[CR(node)]);
}

int main(){
  int n, m;

  ifstream fin ("arbint.in");
  fin >> n >> m;
  for(int i = 0; i < n; i ++)
    fin >> v[i];

  // Calculez arborele de intervale initial
  getVal(0, 0, n - 1);

  ofstream fout ("arbint.out");
  for(int qi = 0; qi < m; qi ++){
    int a, b, c;
    fin >> a >> b >> c;

    if(a == 0)
      fout << getMax(0, 0, n - 1, b - 1, c - 1) << "\n";
    else
      update(0, 0, n - 1, b - 1, c);
  }
  fin.close();
  fout.close();

  return 0;
}
