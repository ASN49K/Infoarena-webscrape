#include <bits/stdc++.h>
#define DIM 100010
#define INF INT_MIN
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int A[4*DIM], v[DIM];
int n, m, a, b, t, i, maxim;
void build(int nod, int st, int dr)
{
    if (st == dr)
    {
        A[nod] = v[st];
    }
    else
    {
        int mid = (st + dr)/2;
        build(2*nod, st, mid);
        build(2*nod+1, mid+1, dr);
        A[nod] = max(A[2*nod], A[2*nod+1]);
    }
}
void query(int nod, int st, int dr, int a, int b)
{
    if (a <= st && dr <= b)
    {
        maxim = max(maxim, A[nod]);
    }
    else
    {
        int mid = (st + dr)/2;
        if (a <= mid)
            query(2*nod, st, mid, a, b);
        if (b > mid)
            query(2*nod+1, mid+1, dr, a, b);
    }
}
void update(int nod, int st, int dr, int a, int b)
{
    if (st == dr)
    {
        A[nod] = b;
    }
    else
    {
        int mid = (st + dr)/2;
        if (a <= mid)
            update(2*nod, st, mid, a, b);
        if (a > mid)
            update(2*nod+1, mid+1, dr, a, b);
        A[nod] = max(A[2*nod], A[2*nod+1]);
    }
}
int main ()
{
    fin >> n >> m;
    for(i = 1; i <= n; i++)
    {
        fin >>v[i];
    }
    build(1, 1, n);
    for (int i=1; i<=m; i++)
    {
        fin>>t>>a>>b;
        if (t == 0)
        {
            maxim = INF;
            query(1, 1, n, a, b);
            fout<<maxim<<"\n";
        }
        else
        {
            update(1, 1, n, a, b);
        }
    }
    return 0;
}
