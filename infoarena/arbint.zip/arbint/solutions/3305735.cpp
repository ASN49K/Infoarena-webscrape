#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int Nmax = 100005;

int n, q;
int aint[4 * Nmax], elemente[Nmax];

void aint_build(int nod, int st, int dr){
    if(st == dr){
        aint[nod] = elemente[st];
        return;
    }

    int mid = (st + dr) / 2;
    aint_build(2 * nod, st, mid);
    aint_build(2 * nod + 1, mid + 1, dr);

    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

void aint_update(int nod, int st, int dr, int pozitie, int valoare){
    if(st == dr){
        aint[nod] = valoare;
        return;
    }

    int mid = (st + dr) / 2;
    if(pozitie <= mid){
        aint_update(2 * nod, st, mid, pozitie, valoare);
    }
    else{
        aint_update(2 * nod + 1, mid + 1, dr, pozitie, valoare);
    }

    aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

int aint_query(int nod, int st, int dr, int start, int finish){
    if(st == start && dr == finish){
        return aint[nod];
    }

    int mid = (st + dr) / 2;

    if(finish <= mid){
        return aint_query(2 * nod, st, mid, start, finish);
    }
    else if(mid < start){
        return aint_query(2 * nod + 1, mid + 1, dr, start, finish);
    }
    else{
        return max(aint_query(2 * nod, st, mid, start, mid), aint_query(2 * nod + 1, mid + 1, dr, mid + 1, finish));
    }
}

void citire(){
    fin >> n >> q;
    for(int i = 1; i <= n; i++){
        fin >> elemente[i];
    }

    aint_build(1, 1, n);
}

void citire_si_rezolvare_interogari(){
    bool tip;
    int stanga, dreapta, pozitie, valoare;

    for(int i = 1; i <= q; i++){
        fin >> tip;

        if(tip){
            fin >> pozitie >> valoare;
            aint_update(1, 1, n, pozitie, valoare);
        }
        else{
            fin >> stanga >> dreapta;
            fout << aint_query(1, 1, n, stanga, dreapta) << '\n';
        }
    }
}

int main(){
    citire();
    citire_si_rezolvare_interogari();

    return 0;
}
