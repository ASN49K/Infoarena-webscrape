#include <stdio.h>
#include <stdlib.h>
typedef struct Node
{

    unsigned int low,high;
    unsigned int max;
    struct Node *right;
    struct Node *left;
} BST;

unsigned int Maximum(unsigned int a,unsigned int b)
{
    return (a<b) ? b:a;
}
BST *BuildIntervalTree(BST *root,unsigned int low,unsigned int high,unsigned int *arr)
{
    if(low>high)
        return NULL;

    if(low==high)
    {
        root=(BST *)malloc(sizeof(BST));
        root->low=low;
        root->high=high;
        root->max=arr[low];
        root->left=NULL;
        root->right=NULL;
        return root;
    }

    root=(BST *)malloc(sizeof(BST));
    root->low=low;
    root->high=high;
    root->left=(BST *)malloc(sizeof(BST));
    root->right=(BST *)malloc(sizeof(BST));
    root->left=BuildIntervalTree(root->left,low,low+(high-low)/2,arr);
    root->right=BuildIntervalTree(root->right,low+(high-low)/2+1,high,arr);

    root->max=Maximum(root->left->max,root->right->max);
    return root;
}
BST *UpdateIntervalTree(BST *root,unsigned int pos,unsigned int value)
{
    if(root->low==root->high && root->low==pos)
    {
        root->max=value;
        return root;
    }

    unsigned int mid=root->low+(root->high-root->low)/2;
    if(pos<=mid) root->left=UpdateIntervalTree(root->left,pos,value);
    else root->right=UpdateIntervalTree(root->right,pos,value);

    root->max=Maximum(root->left->max,root->right->max);
    return root;
}
void Query(BST *root,unsigned int low,unsigned int high,unsigned int *max)
{
    if(NULL==root)
        return;

    if(low<=root->low && root->high<=high)
    {
        (*max)=Maximum((*max),root->max);
        return;
    }
    unsigned int mid=root->low+(root->high-root->low)/2;
    if(low<=mid) Query(root->left,low,high,max);
    if(mid<high) Query(root->right,low,high,max);

}
int main()
{

    freopen("arbint.in","r",stdin);
    freopen("arbint.out","w",stdout);

    unsigned int n,m,x,y,op,max;
    scanf("%u",&n);
    scanf("%u",&m);
    unsigned int *arr=(unsigned int *)calloc(n,sizeof(unsigned int));
    for(unsigned int i=0; i<n; i++)
        scanf("%u",&arr[i]);

    BST *IntervalTree=NULL;
    IntervalTree=BuildIntervalTree(IntervalTree,0,n-1,arr);

    for(unsigned int i=0; i<m; i++)
    {

        scanf("%u %u %u",&op,&x,&y);
         if(op==0){
           // printf("------------\n");
             max=0;
            Query(IntervalTree,x-1,y-1,&max);
            printf("%u\n",max);
           // printf("maximum[%u,%u]=%u\n",x-1,y-1,max);
           // printf("------------\n");
           }
       else IntervalTree=UpdateIntervalTree(IntervalTree,x-1,y-1);

    }
    return 0;
}
