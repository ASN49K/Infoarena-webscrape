#include <bits/stdc++.h>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

const int nmax = 1e5 + 5;
int n, m, v[nmax], aint[4 * nmax];

void init (int nod, int st, int dr)
{
    if (st == dr)
    {
        aint[nod] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    init (2 * nod, st, mij);
    init (2 * nod + 1, mij + 1, dr);
    aint[nod] = max (aint[2 * nod], aint[2 * nod + 1]);
}

void update (int nod, int st, int dr, int poz, int val)
{
    if (st == dr)
    {
        v[st] = val;
        aint[nod] = val;
        return;
    }
    int mij  = (st + dr) / 2;
    if (poz <= mij)
        update (2 * nod, st, mij, poz, val);
    else
        update (2 * nod + 1, mij + 1, dr, poz, val);
    aint[nod] = max (aint[2 * nod], aint[2 * nod + 1]);
}

int query (int nod, int st, int dr, int p, int q)
{
    if (p <= st && dr <= q)
        return aint[nod];
    int cl = -1, cr = -1;
    int mij = (st + dr) / 2;
    if (p <= mij)
        cl = query (2 * nod, st, mij, p, q);
    if (mij + 1 <= q)
        cr = query (2 * nod + 1, mij + 1, dr, p, q);
    return max (cl, cr);
}

int main ()
{
    int q;
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
    init (1, 1, n);
    for (int i = 1; i <= q; i++)
    {
        int cer;
        fin >> cer;
        if (cer == 0)
        {
            int st, dr;
            fin >> st >> dr;
            fout << query(1,1,n,st,dr) << '\n';
        }
        else
        {
            int poz, val;
            fin >> poz >> val;
            update(1,1,n,poz,val);
        }
    }
    return 0;
}
