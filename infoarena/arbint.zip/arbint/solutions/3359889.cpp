/*  
    *
    * soon on twitch : ex3qute 
    * 
    * ax ah al
    * kwxkwxkxkxwkxkwxkw
    * dumnezeu sa o ierte
*/


#include <bits/stdc++.h>  
using namespace std;  
#define ull unsigned long long  
#define ll long long  
#define pb push_back  
#define fastio ios_base::sync_with_stdio(0); cin.tie(nullptr);  
const int MOD = 1e9+7;
int di[4]={0,0,-1,1};  
int dj[4]={-1,1,0,0};  

const string FILENAME = "arbint";
ifstream f(FILENAME + ".in");
ofstream g(FILENAME + ".out");


#ifndef exe
#define cin f
#define cout g
#endif

int aint[400001];
int a[100001];

void build(int curr, int st, int dr) {
    if(st == dr) aint[curr] = a[st];
    else {
        int m = (st + dr) / 2;
        build(curr * 2, st, m);
        build(curr * 2 + 1, m + 1, dr);

        aint[curr] = max(aint[curr * 2], aint[curr * 2 + 1]);
    }
}

// st, dr din query, 
int query(int curr, int cst, int cdr, int st, int dr) {
    if(st > dr) return -1;
    if(st == cst && dr == cdr) return aint[curr];

    int cm = (cst + cdr) / 2;
    int x = query(curr * 2, cst, cm, st, min(dr,cm));
    int y = query(curr * 2 + 1, cm + 1, cdr, max(st, cm + 1), dr);

    return max(x,y);    
}

void update(int curr, int cst, int cdr, int poz, int x) {
    if(cst == cdr) aint[curr] = x;
    else {
        int cm = (cst + cdr) / 2;
        if(poz <= cm) update(curr * 2, cst, cm, poz, x);
        else update(curr * 2 + 1, cm + 1, cdr, poz, x);
        
        aint[curr] = max(aint[curr * 2], aint[curr * 2 + 1]);
    }
}

signed main(){  


    int n,m;
    cin >> n >> m;
    for(int i=1;i<=n;++i) cin >> a[i];

    build(1,1,n);

    for(int i=1;i<=m;++i) {
        int op, st, dr;
        cin >> op >> st >> dr;
        if(op == 1) update(1,1,n,st,dr);
        else cout << query(1,1,n,st,dr) << '\n';
    }


    return 0;
}


