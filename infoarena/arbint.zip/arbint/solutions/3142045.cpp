#include <bits/stdc++.h>

#define int long long

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int NMAX = 1e5;
int a[NMAX+5], aint[4*NMAX+5], n;

void build(const int &node, const int &left, const int &right) {
    if (left == right)
        aint[node] = a[left];
    else {
        int middle = (left+right)/2;
        build(2*node, left, middle);
        build(2*node+1, middle+1, right);
        aint[node] = max(aint[2*node], aint[2*node+1]);
    }
}

void update(const int &node, const int &left, const int &right, const int &position, const int &value) {
    if (position <= left && right <= position)
        aint[node] = value;
    else {
        int middle = (left+right)/2;
        if (position <= middle)
            update(2*node, left, middle, position, value);
        if (middle < position)
            update(2*node+1, middle+1, right, position, value);
        aint[node] = max(aint[2*node], aint[2*node+1]);
    }
}

int query(const int &node, const int &left, const int &right, const int &start, const int &finish) {
    if (start <= left && right <= finish)
        return aint[node];
    else {
        int middle = (left+right)/2, ans = 0;
        if (start <= middle)
            ans = max(ans, query(2*node, left, middle, start, finish));
        if (middle < finish)
            ans = max(ans, query(2*node+1, middle+1, right, start, finish));
        return ans;
    }
}

void task1() {
    int left, right;
    fin>>left>>right;
    fout<<query(1, 1, n, left, right)<<'\n';
}

void task2() {
    int position, value;
    fin>>position>>value;
    update(1, 1, n, position, value);
}

signed main() {
    ios_base :: sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
  
    int q;
    fin>>n>>q;
    for (int i = 1; i <= n; i++)
        fin>>a[i];
    build(1, 1, n);
    while (q--) {
        int task;
        fin>>task;
        if (task == 0)
            task1();
        else
            task2();
    }
    return 0;
}