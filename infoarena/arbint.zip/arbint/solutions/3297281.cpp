#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

int aint[4 * NMAX + 1];

void update( int st, int dr, int poz, int x, int i = 0 ) {
    if ( st == dr ) {
        aint[i] = x;
    } else {
        int mij = ( st + dr ) / 2;
        if ( poz <= mij ) update( st, mij, poz, x, i * 2 + 1 );
        else update( mij + 1, dr, poz, x, i * 2 + 2 );
        aint[i] = max( aint[i * 2 + 1], aint[i * 2 + 2] );
    }
}
int query( int st, int dr, int a, int b, int i = 0 ) {
    if ( st == a && dr == b ) return aint[i];
    int mij = ( st + dr ) / 2;
    if ( b <= mij ) return query( st, mij, a, b, i * 2 + 1 );
    if ( a > mij ) return query( mij + 1, dr, a, b, i * 2 + 2 );
    return max( query( st, mij, a, mij, i * 2 + 1 ),
                query( mij + 1, dr, mij + 1, b, i * 2 + 2 ) );
}
int main() {
    ifstream fin( "arbint.in" );
    ofstream fout( "arbint.out" );
    int n, m;

    fin >> n >> m;
    for ( int i = 1, x; i <= n; i ++ ) {
        fin >> x;
        update( 1, n, i, x );
    }
    for ( int i = 1, tip, a, b; i <= m; i ++ ) {
        fin >> tip >> a >> b;
        if ( tip == 0 ) {
            fout << query( 1, n, a, b ) << '\n';
        } else {
            update( 1, n, a, b );
        }
    }
    return 0;
}