#include <fstream>
#include <vector>
#include <random>
#include <ctime>
using namespace std;
class InParser {
    vector<char> str;
    int ptr;
    ifstream fin;

    char getChar() {
        if (ptr == int(str.size())) {
            fin.read(str.data(), str.size());
            ptr = 0;
        }
        return str[ptr++];
    }

    template<class T>
    T getInt() {
        char chr = getChar();
        while (!isdigit(chr) && chr != '-')
            chr = getChar();
        int sgn = +1;
        if (chr == '-') {
            sgn = -1;
            chr = getChar();
        }
        T num = 0;
        while (isdigit(chr)) {
            num = num * 10 + chr - '0';
            chr = getChar();
        }
        return sgn * num;
    }

public:
    InParser(const char* name) : str(1e5), ptr(str.size()), fin(name) { }
    ~InParser() { fin.close(); }

    template<class T>
    friend InParser& operator>>(InParser& in, T& num) {
        num = in.getInt<T>();
        return in;
    }
};

class OutParser {
    vector<char> str;
    int ptr;
    ofstream fout;

    void putChar(char chr) {
        if (ptr == int(str.size())) {
            fout.write(str.data(), str.size());
            ptr = 0;
        }
        str[ptr++] = chr;
    }

    template<class T>
    void putInt(T num) {
        if (num < 0) {
            putChar('-');
            num *= -1;
        }
        if (num > 9)
            putInt(num / 10);
        putChar(num % 10 + '0');
    }

public:
    OutParser(const char* name) : str(1e5), ptr(0), fout(name) { }
    ~OutParser() { fout.write(str.data(), ptr); fout.close(); }

    template<class T>
    friend OutParser& operator<<(OutParser& out, const T num) {
        out.putInt(num);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char chr) {
        out.putChar(chr);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char* str) {
        for (int i = 0; str[i]; i++)
            out.putChar(str[i]);
        return out;
    }
};
InParser cin("arbint.in");
OutParser cout("arbint.out");
const int nmax = 1e5+1;
mt19937 mt(time(nullptr));
int op , a , b , v[nmax] , bat[nmax] , n , m;
int main()
{
    cin >> n >> m;
    int buc = -(mt()%316) + 316;
    for(int i = 1 ; i <= n ; ++i)
    {
        cin >> v[i];
        bat[i/buc] = max(bat[i/buc],v[i]);
    }
    for(int i = 1 ; i <= m ; ++i)
    {
        cin >> op >> a >> b;
        if(!op)
        {
            int mx = -1e9;
            int ba = a/buc;
            int bb = b/buc;
            if(ba == bb)
            {
                for(int j = a ; j <= b ; ++j) mx = max(mx,v[j]);
                cout << mx << '\n';
                continue;
            }
            for(int j = ba + 1 ; j < bb ; ++j)
            {
                mx = max(mx,bat[j]);
            }
            if(a == ba*buc) mx = max(mx,bat[ba]);
            else
            {
                int up = (ba+1)*buc;
                for(int j = a ; j < up ; ++j)
                {
                    mx = max(mx,v[j]);
                }
            }
            if(b == n || b == (bb+1)*buc - 1) mx = max(mx,bat[bb]);
            else
            {
                int low = bb*buc;
                for(int j = b ; j >= low ; --j)
                {
                    mx = max(mx,v[j]);
                }
            }
            cout << mx << '\n';
        }
        else
        {
            int ba = a/buc;
            if(v[a] <= b || bat[ba] > v[a])
            {
                v[a] = b;
                bat[ba] = max(bat[ba],b);
            }
            else
            {
                int mx = -1e9;
                v[a] = b;
                int ub = min(n,(ba+1)*buc-1);
                for(int j = ba*buc ; j <= ub ; ++j) mx = max(mx,v[j]);
                bat[ba] = mx;
            }
        }
    }
	return 0;
}
