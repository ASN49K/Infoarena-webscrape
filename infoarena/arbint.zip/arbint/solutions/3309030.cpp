#include <fstream>
#include <vector>

void buildSegmentTree(std::vector<int> &segmentTree, int node, int left, int right, const std::vector<int> &numbers)
{
    if (left == right)
    {
        segmentTree[node] = numbers[left];

        return;
    }

    int middle = (left + right) / 2;

    buildSegmentTree(segmentTree, 2 * node, left, middle, numbers);
    buildSegmentTree(segmentTree, 2 * node + 1, middle + 1, right, numbers);

    segmentTree[node] = std::max(segmentTree[2 * node], segmentTree[2 * node + 1]);
}

int querySegmentTree(const std::vector<int> &segmentTree, int node, int treeLeft, int treeRight, int left, int right)
{
    if (left > right)
        return -1;

    if (left == treeLeft && right == treeRight)
        return segmentTree[node];

    int treeMiddle = (treeLeft + treeRight) / 2;

    return std::max(querySegmentTree(segmentTree, 2 * node, treeLeft, treeMiddle, left, std::min(treeMiddle, right)),
                    querySegmentTree(segmentTree, 2 * node + 1, treeMiddle + 1, treeRight, std::max(treeMiddle + 1, left), right));
}

void updateSegmentTree(std::vector<int> &segmentTree, int node, int left, int right, int position, int number)
{
    if (left == right)
    {
        segmentTree[node] = number;

        return;
    }

    int middle = (left + right) / 2;

    if (position <= middle)
    {
        updateSegmentTree(segmentTree, 2 * node, left, middle, position, number);
    }
    else
    {
        updateSegmentTree(segmentTree, 2 * node + 1, middle + 1, right, position, number);
    }

    segmentTree[node] = std::max(segmentTree[2 * node], segmentTree[2 * node + 1]);
}

int main()
{
    std::ifstream inFile;
    inFile.open("arbint.in");

    int n, m;
    inFile >> n >> m;

    std::vector<int> numbers(n + 1);

    for (int i = 1 ; i <= n; ++i)
    {
        inFile >> numbers[i];
    }

    std::vector<int> segmentTree(4 * n);

    buildSegmentTree(segmentTree, 1, 1, n, numbers);

    std::ofstream outFile;
    outFile.open("arbint.out");

    while (m--)
    {
        int task;
        inFile >> task;

        if (task == 0)
        {
            int left, right;
            inFile >> left >> right;

            outFile << querySegmentTree(segmentTree, 1, 1, n, left, right) << '\n';
        }
        else
        {
            int position, number;
            inFile >> position >> number;

            updateSegmentTree(segmentTree, 1, 1, n, position, number);
        }
    }

    inFile.close();
    outFile.close();

    return 0;
}
