#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;

const int MAXN = 100000;
int arbore[4*MAXN];
int maxi;

void update(int v, int capatSt, int capatDr, int pozitie, int valoare_noua) {
    if (capatSt == capatDr) {
        arbore[v] = valoare_noua;
    } else {
        int mij = (capatSt + capatDr) / 2;
        if (pozitie <= mij)
            update(v*2, capatSt, mij, pozitie, valoare_noua);
        else
            update(v*2+1, mij+1, capatDr, pozitie, valoare_noua);
        arbore[v] = max(arbore[v*2], arbore[v*2+1]);
    }
}

void query(int v, int capatSt, int capatDr, int st, int dr) {
    if(st > dr)
        return;
    if(st == capatSt && dr == capatDr)
        maxi = max(maxi, arbore[v]);
    else {
        int mij = (capatSt + capatDr) / 2;
        if(st <= mij)
            query(v*2, capatSt, mij, st, min(dr, mij));
        if(dr > mij)
            query(v*2+1, mij+1, capatDr, max(st, mij+1), dr);
    }
}

int main() {
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    int N, M;
    fin >> N >> M;
    for(int i = 0; i < N; i++) {
        int val;
        fin >> val;
        update(1, 0, N-1, i, val);
    }
    for(int i = 0; i < M; i++) {
        int op, a, b;
        fin >> op >> a >> b;
        a--; // 0-indexing
        if(op == 0) {
            maxi = INT_MIN;
            query(1, 0, N-1, a, b-1);
            fout << maxi << "\n";
        } else if(op == 1) {
            update(1, 0, N-1, a, b);
        }
    }

    fin.close();
    fout.close();
    return 0;
}
