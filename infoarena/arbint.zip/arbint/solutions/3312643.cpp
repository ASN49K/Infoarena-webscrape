#include <bits/stdc++.h>
using namespace std;
vector<int> arb;
vector<int> v;

void crt(int st,int dr,int pos){
    if(st==dr)
        arb[pos] = v[st];
    else{
        int mid = (st+dr)/2;
        int c1 = pos*2;
        int c2 = pos*2 + 1;

        crt(st,mid,c1);
        crt(mid+1,dr,c2);

        arb[pos] = max(arb[c1],arb[c2]);
    }
}

void upd(int st,int dr,int pos,int id,int val){
    if(st==dr and st==id)
        arb[pos] = val;
    else{
        int mid = (st+dr)/2;
        int c1 = pos*2;
        int c2 = pos*2 + 1;
        
        if(st<=id and id<=mid)
            upd(st,mid,c1,id,val);
        if(mid+1<=id and id<=dr)
            upd(mid+1,dr,c2,id,val);

        arb[pos] = max(arb[c1],arb[c2]);
    }
}

int afis(int st,int dr,int pos,int fl,int fr,int maxim){
    if(fl<=st and dr<=fr)
        return max(maxim,arb[pos]);
    else if(st!=dr){
        int mid = (st+dr)/2;
        int c1 = pos*2;
        int c2 = pos*2 + 1;

        if(fl<=mid)
            maxim = max(afis(st,mid,c1,fl,fr,maxim),maxim);
        if(mid+1<=fr)
            maxim = max(afis(mid+1,dr,c2,fl,fr,maxim),maxim);

        return maxim;
    }
}

int main() {
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");

	int n,m;
    cin>>n>>m;
    v.resize(n+1);
    arb.resize(n*4);
    for(int i=1;i<=n;i++)
    cin>>v[i];
    
    crt(1,n,1);

    for(int i=1;i<=m;i++){
        int c,x,y;
        cin>>c>>x>>y;
        
        if(c==0)
            cout<<afis(1,n,1,x,y,0)<<"\n";
        else
            upd(1,n,1,x,y);
    }
}
