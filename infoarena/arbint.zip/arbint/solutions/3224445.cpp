#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");ofstream fout("arbint.out");

const int N =100007;
const int N_ARB = 4*N;
int n,q;
int aint[N_ARB];

void Update_aint(int aint[],int poz_aint,int poz_element,int st,int dr,int val)
{
    if( st==dr )
    {
        aint[poz_aint]=val;
        return;
    }
    int mij=((st+dr)>>1);
    if( poz_element<=mij )
        Update_aint( aint,poz_aint*2,poz_element,st,mij,val );
    else
        Update_aint( aint,poz_aint*2+1,poz_element,mij+1,dr,val );
    aint[poz_aint]=max(aint[poz_aint*2],aint[poz_aint*2+1]);
}

void Upd(int aint[],int poz_element,int val)
{
    Update_aint(aint,1,poz_element,1,n,val);
}

int Querry_aint(int aint[],int poz_aint,int st_aint,int dr_aint,int qst,int qdr)
{
    if( qst<=st_aint and dr_aint<=qdr )
        return aint[poz_aint];
    int mij=(st_aint+dr_aint)/2;

    int ans=-1;
    if( qst<=mij )
        ans = Querry_aint(aint,poz_aint*2,st_aint,mij,qst,qdr);
    if( mij<qdr )
        ans=max(ans,Querry_aint(aint,poz_aint*2+1,mij+1,dr_aint,qst,qdr));
    return ans;
}

int Qry(int aint[],int qst,int qdr)
{
    return Querry_aint( aint,1,1,n,qst,qdr );
}

int main()
{
    fin >> n >> q;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin >> x;
        Upd(aint,i,x);
    }
//    for(int i=1;i<=11;i++)cout << i <<":  " << aint[i] << " \n";
    for(int i=1;i<=q;i++)
    {
        int task,x,y;
        fin >> task >> x >> y;
        if( !task )
        {
            fout << Qry(aint,x,y) << "\n";
        }
        else
        {
            Upd(aint,x,y);
        }
    }
    fin.close();fout.close();
    return 0;
}
