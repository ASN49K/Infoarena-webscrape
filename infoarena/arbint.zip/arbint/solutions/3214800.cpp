#include <bits/stdc++.h>

#pragma optimize GCC ("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

#define cin fin
#define cout fout

const int NMAX=1e5+5;
const int INF=-2e9;

int aint[4*NMAX];
int v[NMAX];

void build(int p,int st,int dr)
{
    if(st==dr)
    {
        aint[p]=v[st];
        return ;
    }
    else
    {
        int mij=st+dr;
        mij/=2;
        build(2*p,st,mij);
        build(2*p+1,mij+1,dr);
        aint[p]=max(aint[2*p],aint[2*p+1]);
    }
}

void update(int p,int st,int dr,int a,int b)
{
    if(st==dr)
    {
        aint[p]=b;
        return ;
    }
    else
    {
        int mij=st+dr;
        mij/=2;
        if(a<=mij)
            update(2*p,st,mij,a,b);
        else
            update(2*p+1,mij+1,dr,a,b);
        aint[p]=max(aint[2*p],aint[2*p+1]);
    }
}

int query(int p,int st,int dr,int a,int b)
{
    if(a<=st && dr<=b)
        return aint[p];
    else
    {
        int maxi=INF;
        int mij=st+dr;
        mij/=2;
        if(a<=mij)
            maxi=max(maxi,query(2*p,st,mij,a,b));
        if(mij<b)
            maxi=max(maxi,query(2*p+1,mij+1,dr,a,b));
        return maxi;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n,i,j,q;
    cin>>n>>q;
    for(i=1;i<=n;i++)
        cin>>v[i];
    build(1,1,n);
    while(q--)
    {
        int task,x,y;
        cin>>task>>x>>y;
        if(task==0)
            cout<<query(1,1,n,x,y)<<"\n";
        else
            update(1,1,n,x,y);
    }
    return 0;
}
