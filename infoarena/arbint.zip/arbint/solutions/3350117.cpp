#include <bits/stdc++.h>
using namespace std;

string name = "arbint";

ifstream in(name + ".in");
ofstream out(name + ".out");

vector<int> ST;
int A[100001];
int n, m;
void build(int node, int L, int R) {
	if (L == R) {
		ST[node] = A[L];
	}
	else {
		int mid = (L + R) / 2;
		build(node * 2, L, mid);
		build(node * 2 + 1, mid + 1, R);
		ST[node] = max(ST[node * 2], ST[node * 2 + 1]);
	}
}

void update(int node, int L, int R, int id, int val) {
	if (L == R) {
		A[L] = val;
		ST[node] = val;
	}
	else {
		int mid = (R + L) / 2;
		if (id <= mid) {
			update(node * 2, L, mid, id, val);
		}
		else {
			update(node * 2 + 1, mid + 1, R, id, val);
		}
		ST[node] = max(ST[node * 2], ST[node * 2 + 1]);
	}
}

int query(int node, int tl, int tr, int L, int R) {
	if (R < tl || L > tr) return INT_MIN;
	if (L <= tl && tr <= R) return ST[node];
	int tm = (tr + tl) / 2;

	return max(query(node * 2, tl, tm, L, R), query(node * 2 + 1, tm + 1, tr, L, R));
}

int main() {
	in >> n >> m;

	for (int i = 1; i <= n; i++) in >> A[i];
	
	ST.resize(4 * n);
	build(1, 1, n);

	int c, a, b;
	while (m--) {
		in >> c >> a >> b;
		if (c == 0) {
			out << query(1, 1, n, a, b) << '\n';
		}
		else {
			update(1, 1, n, a, b);
		}
	}
}