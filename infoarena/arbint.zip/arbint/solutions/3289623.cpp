#include <fstream>

using namespace std;

const int nmax = 1e5;

struct SegmentTree {
public:
  SegmentTree(int n) : n(n) {}

  void build(int node, int left, int right, int v[]) {
    if (left == right) {
      tree[node] = v[left];
    } else {
      int middle = (left + right) / 2;

      build(node * 2, left, middle, v);
      build(node * 2 + 1, middle + 1, right, v);

      tree[node] = max(tree[node * 2], tree[node * 2 + 1]);
    }
  }

  void update(int node, int left, int right, int pos, int value) {
    if (left == right) {
      tree[node] = value;
    } else {
      int middle = (left + right) / 2;

      if (pos <= middle)
        update(node * 2, left, middle, pos, value);
      else
        update(node * 2 + 1, middle + 1, right, pos, value);

      tree[node] = max(tree[node * 2], tree[node * 2 + 1]);
    }
  }

  int query(int node, int left, int right, int query_left, int query_right) {
    if (query_left <= left && right <= query_right) {
      return tree[node];
    }

    int middle = (left + right) / 2;

    if (query_right <= middle)
      return query(node * 2, left, middle, query_left, query_right);

    if (middle + 1 <= query_left)
      return query(node * 2 + 1, middle + 1, right, query_left, query_right);

    return max(query(node * 2, left, middle, query_left, query_right),
               query(node * 2 + 1, left, middle, query_left, query_right));
  }

private:
  int n, tree[4 * nmax + 1];
};

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, v[nmax + 1], op, a, b;

int main() {
  fin >> n >> m;
  for (int i = 1; i <= n; i++) {
    fin >> v[i];
  }

  SegmentTree aint(n);
  aint.build(1, 1, n, v);

  while (m--) {
    fin >> op >> a >> b;

    if (op == 0) {
      // maximul pe secv [a, b]
      fout << aint.query(1, 1, n, a, b) << '\n';
    } else {
      // v[a] = b
      aint.update(1, 1, n, a, b);
    }
  }
  return 0;
}