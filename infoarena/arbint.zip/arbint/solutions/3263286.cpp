#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m;
int v[150000];
int aint[300000];

void Build()
{
    for(int i = 0; i < n; i++)
    {
        aint[n+i] = v[i+1];
    }
    for(int i = n-1; i > 0; i--)
        aint[i] = max(aint[i*2], aint[i*2+1]);
}

void Update(int poz, int val)
{
    poz = poz+n-1;
    aint[poz] = val;
    while(poz > 1)
    {
        poz /= 2;
        aint[poz] = max(aint[poz*2], aint[poz*2+1]);
    }
}

void Update2(int poz, int val, int nod, int st, int dr)
{
    if(st == dr)
        aint[nod] = val;
    else
    {
        int mij = (st+dr)/2;
        if(poz <= mij)
            Update2(poz, val, nod*2, st, mij);
        else
            Update2(poz, val, nod*2+1, mij+1, dr);
        aint[nod] = max(aint[nod*2], aint[nod*2+1]);
    }
}

int Query(int a, int b, int nod, int st, int dr)
{
    if(a <= st && dr <= b)
        return aint[nod];
    int mij = (st+dr)/2;
    int aux = 0;
    if(a <= mij)
        aux = Query(a, b, nod*2, st, mij);
    if(b >= mij+1)
        aux = max(aux, Query(a, b, nod*2+1, mij+1, dr));
    return aux;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= n; i++)
        fin >> v[i];
    int nnou = 1;
    while(nnou < n)
    {
        nnou *= 2;
    }
    n = nnou;
    Build();
    //cout << aint[10] << "\n";
    for(int i = 0; i < m; i++)
    {
        int op, a, b;
        fin >> op >> a >> b;
        if(op == 1)
            Update(a, b);
        else
            fout << Query(a, b, 1, 1, n) << "\n";
    }
    return 0;
}
