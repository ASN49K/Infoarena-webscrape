#include <bits/stdc++.h>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
void update(int poz, int val, int st, int dr, int nod);
int query(int a, int b, int st, int dr, int nod);

int arb[4000002], n, m;

int main()
{
    fin>>n>>m;
    for(int i = 1; i <= n; ++i)
    {
        int x;
        fin>>x;
        update(i, x, 1, n, 1);
    }
    while(m--)
    {
        int tip, x, y;
        fin>>tip>>x>>y;
        if(tip == 0)
            fout<<query(x, y, 1, n, 1)<<"\n";
        else
            update(x, y, 1, n, 1);
    }




    return 0;
}

int query(int a, int b, int st, int dr, int nod)
{
    if(a <= st && dr <= b)
        return arb[nod];
    int mijl = (st+dr) / 2, mx = -1;
    if(a <= mijl)
        mx = max(mx, query(a, b, st, mijl, 2*nod));
    if(b > mijl)
        mx = max(mx, query(a, b, mijl+1, dr, 2*nod+1));
    return mx;
}

void update(int poz, int val, int st, int dr, int nod)
{
    if(st == dr)
    {
        arb[nod] = val;
        return;
    }
    int mijl = (st+dr)/2;
    if(poz <= mijl)
        update(poz, val, st, mijl, 2*nod);
    else
        update(poz, val, mijl+1, dr, 2*nod+1);
    arb[nod] = max(arb[nod*2], arb[nod*2+1]);
}
