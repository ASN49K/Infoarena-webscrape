#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <fstream>
#include <algorithm>
#include <vector>
std::ifstream in("../arbint.in");
std::ofstream out("../arbint.out");
std::vector<int> arb;

void upd(int nod, int x, int pos, int st, int dr)
{
    if(st == dr)
    {
        arb[nod] = x;
        return;
    }
    int mj = (st+dr)/2;
    if(pos<=mj)
        upd(2*nod, x, pos, st, mj);
    else upd(2*nod+1, x, pos, mj+1, dr);
    arb[nod] = std::max(arb[2*nod], arb[2*nod+1]);
}
void query(int nod, int st, int dr, int &mx, int a, int b)
{
    if(a<=st && dr<=b)
    {
        if(arb[nod]>mx)
            mx = arb[nod];
        return;
    }
    int mj = (st+dr)/2;
    if(a<=mj)
        query(2*nod, st, mj, mx, a, b);
    if(mj<b)
        query(2*nod+1, mj+1, dr, mx, a, b);
}

int main() {
    int m,n,x;
    in>>n>>m;
    arb.resize(400003);
    for(int i = 1; i<=n; i++)
    {
        in>>x;
        upd(1, x,i, 1, n);
    }
    for(int i = 1; i<=m; i++)
    {
        int a,b;
        in>>x>>a>>b;
        if(x==0)
        {
            int mx = 0;
            query(1, 1, n, mx, a, b);
            out<<mx<<'\n';
        }
        else if(x==1)
            upd(1, b, a, 1, n);

    }
    return 0;
}
