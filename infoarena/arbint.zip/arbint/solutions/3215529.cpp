#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m;
int a[100001];
int arb[400001];

void update(int st, int dr, int tata, int poz, int val)
{
    if(st == dr)
    {
        arb[tata] = val;
        return;
    }

    int m = (st + dr) / 2;
    if(poz <= m)
        update(st, m, 2 * tata, poz, val);
    else
        update(m + 1, dr, 2 * tata + 1, poz, val);
    arb[tata] = max(arb[2 * tata], arb[2 * tata + 1]);
}

void citire()
{
    fin >> n >> m;

    int x;
    for(int i = 1; i <= n; ++i)
    {
        fin >> x;
        update(1, n, 1, i, x);
    }
}

int query(int a, int b, int st, int dr, int k)
{
    if(st >= a && dr <= b)
        return arb[k];
    int vmax = -1;
    int m = (st + dr) / 2;
    if(a <= m)
        vmax = max(vmax, query(a, b, st, m, k * 2));
    if(b > m)
        vmax = max(vmax, query(a, b, m + 1, dr, k * 2 + 1));
    return vmax;
}

int main()
{
    citire();

    int cerinta, x, y;
    for(int t = 0; t < m; ++t)
    {
        fin >> cerinta >> x >> y;
        if(cerinta == 0)
        {
            fout << query(x, y, 1, n, 1) << '\n';
        }
        else
        {
            update(1, n, 1, x, y);
        }
    }
    return 0;
}
