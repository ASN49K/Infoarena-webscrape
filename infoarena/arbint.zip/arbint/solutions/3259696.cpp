#include <bits/stdc++.h>


using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

int v[100001], A[400001];

void build(int nod,int st, int dr){
    if(st==dr)
        A[nod]=v[st];
    else
    {
        int m=(st+dr)/2;
        build(2*nod,st,m);
        build(2*nod+1,m+1,dr);
        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}

void update(int nod,int st, int dr, int p, int val){
    if(st==dr)
        A[nod]=val;
    else
    {
        int m=(st+dr)/2;
        if(p<=m)
            update(2*nod,st,m,p,val);
        else
            update(2*nod+1, m+1, dr, p, val);
        A[nod]=max(A[2*nod], A[2*nod+1]);
    }
}
int sol;
void q(int nod, int st, int dr, int a, int b)
{
    if(a<=st&&dr<=b)
        sol=max(sol,A[nod]);
    else
    {
        int m=(st+dr)/2;
        if(a<=m)
            q(2*nod,st,m,a,b);
        if(b>m)
            q(2*nod+1,m+1,dr,a,b);
    }
}
int main()
{
    int n,m,i,x,y,cer;
    in>>n>>m;
    for(i=1;i<=n;++i)
        in>>v[i];
    build(1,1,n);
    for(i=1;i<=m;++i)
    {
        in>>cer>>x>>y;
        if(cer==0){
                sol=-1;
            q(1,1,n,x,y);

            out<<sol<<'\n';
        }
        else
            update(1,1,n,x,y);
    }
    return 0;
}
