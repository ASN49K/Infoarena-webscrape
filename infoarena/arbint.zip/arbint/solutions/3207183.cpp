/// Arbori de intervale pe infoarena

#include <fstream>
#include <climits>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

const int N_MAX = 400004;
int n, m;
int start, finish, val, pos, maxim; /// punem val globale parametrii la fct pt a scrie mai usor
int a[N_MAX];

void Update(int nod, int l, int r){
    if(l < r){
        int m = (l + r) / 2;
        if(pos <= m)
            Update(2 * nod, l, m);
        else
            Update(2 * nod + 1, m + 1, r);

        a[nod] = max(a[2 * nod], a[2 * nod + 1]); /// actualizam arborele de intervale
    }else
        a[nod] = val;
}

void Query(int nod, int l, int r){
    if(start <= l && r <= finish){ /// Maximul intre [l, r] este in a[nod]
        if(maxim < a[nod])
            maxim = a[nod];
    }else{
        int m = (l + r) / 2;
        if(start <= m)
            Query(2 * nod, l, m);
        if(m < finish)
            Query(2 * nod + 1, m + 1, r);
    }
}

int main()
{
    f >> n >> m;

    for(int i = 1, x; i <= n; ++i){
        f >> x;
        pos = i, val = x;
        Update(1, 1, n);
    }

    for(int i = 1, c, x, y; i <= m; ++i){
        f >> c >> x >> y;
        switch(c){
            case 0:
                maxim = -1; /// stim ca sunt nr pozitive
                start = x, finish = y;
                Query(1, 1, n);
                g << maxim << '\n';
                break;
            case 1:
                pos = x, val = y;
                Update(1, 1, n);
                break;
        }
    }

    f.close();
    g.close();

    return 0;
}
