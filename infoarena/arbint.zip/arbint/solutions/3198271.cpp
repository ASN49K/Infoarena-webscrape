#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("arbint.in");
ofstream fout("arbint.out");


bool c;
int a,b;
int n,m;
int nst,ndr;
int v[100005];
int aint[400005];



void init(int nod,int st,int dr)
{
    if(st==dr) aint[nod]=v[st];
    else
    {
        init(nod*2,st,(st+dr)/2);
        init(nod*2+1,(st+dr)/2+1,dr);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }
}


void update(int nod,int st,int dr,int p,int b)
{
    if(st==dr) aint[nod]=b;
    else
    {
        if(p<=(st+dr)/2) update(nod*2,st,(st+dr)/2,p,b);
        else update(nod*2+1,(st+dr)/2+1,dr,p,b);
        aint[nod]=max(aint[nod*2],aint[nod*2+1]);
    }
}


int query(int nod,int st,int dr,int a,int b)
{
    if(st==a && dr==b) return aint[nod];
    int mij=(st+dr)/2;
    if(b<=mij)return query(2*nod,st,mij,a,b);
    else if(a>mij) return query(2*nod+1,mij+1,dr,a,b);
    else return max(query(2*nod,st,mij,a,mij),query(2*nod+1,mij+1,dr,mij+1,b));
}


int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)fin>>v[i];
    init(1,1,n);
    for(int i=1;i<=m;i++)
    {
        fin>>c>>a>>b;
        if(c)update(1,1,n,a,b);
        else fout<<query(1,1,n,a,b)<<"\n";
    }
    return 0;
}
