#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int MAX=1e5;
int v[MAX+5],A[2*MAX+5],i,q,n,x,y,z,ans;


void build(int nod, int st ,int dr)
{
    if (st==dr)
    {
        A[nod]=v[st];
    }
    else
    {
        int mij=(st+dr)>>1;
        build(2*nod,st,mij);
        build(2*nod+1,mij+1,dr);
        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}

void update(int nod , int st ,int dr ,int p ,int x)
{
    if (st==dr)
    {
        A[nod]=x;
    }
    else
    {
        int mij=(st+dr)>>1;
        if (p<=mij)
            update(2*nod,st,mij,p,x);
        else
            update(2*nod+1,mij+1,dr,p,x);

        A[nod]=max(A[2*nod],A[2*nod+1]);
    }
}

void query(int nod, int st, int dr, int a, int b)
{
    if (a<=st && dr<=b)
    {
        ans=max(ans,A[nod]);
    }
    else
    {
        int mij=(st+dr)>>1;
        if (a<=mij)
            query(2*nod,st,mij,a,b);

        if (b>=mij+1)
            query(2*nod+1,mij+1,dr,a,b);
    }
}



int main()
{
    fin>>n>>q;
    for (i=1; i<=n; i++)
        fin>>v[i];

    build(1,1,n);

    while (q)
    {
        fin>>x>>y>>z;

        if (x==1)
            update(1,1,n,y,z);

        if (x==0)
        {
            ans=0;
            query(1,1,n,y,z);
            fout<<ans<<"\n";
        }

        q--;
    }


    return 0;
}
