#include <bits/stdc++.h>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int Max = 1e5 + 1;
int n, m;
vector<int> v(Max), tree(4 * Max);

void build(int node, int left, int right)
{
    if(left == right)
    {
        tree[node] = v[left];
        return;
    }
    int mid = (left + right) / 2;
    build(2 * node, left, mid);
    build(2 * node + 1, mid + 1, right);
    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void update(int node, int left, int right, int pos, int val)
{
    if(left == right)
    {
        tree[node] = val;
        return;
    }
    int mid = (left + right) / 2;
    if(pos <= mid)
        update(2 * node, left, mid, pos, val);
    if(pos > mid)
        update(2 * node + 1, mid + 1, right, pos, val);
    tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

int query(int node, int left, int right, int x, int y)
{
    if(x <= left && right <= y)
        return tree[node];
    int mid = (left + right) / 2, r1 = 0, r2 = 0;
    if(x <= mid)
        r1 = query(2 * node, left, mid, x, y);
    if(y > mid)
        r2 = query(2 * node + 1, mid + 1, right, x, y);
    return max(r1, r2);
}

int main()
{
    ios::sync_with_stdio(false);
    fin.tie(nullptr);

    fin >> n >> m;
    for(int i = 1; i <= n; ++i)
    {
        fin >> v[i];
    }
    build(1, 1, n);
    while(m--)
    {
        int x, a, b;
        fin >> x >> a >> b;
        if(x)
            update(1, 1, n, a, b);
        else
            fout << query(1, 1, n, a, b) << "\n";
    }

    fin.close();
    fout.close();
    return 0;
}