#include <fstream>

using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int N[400001],T[100001];
void build(int nod, int st, int dr){
    if(st!=dr){
        int mij=(st+dr)/2;
        build(nod*2,st,mij);
        build(nod*2+1,mij+1,dr);
        N[nod]=max(N[nod*2],N[nod*2+1]);
    }
    else{
        N[nod]=T[st];
    }
}
void update(int val, int nod, int st, int dr, int poz){
    if(st!=dr){
        int mij=(st+dr)/2;
        if(poz<=mij){
            update(val,nod*2,st,mij,poz);
        }
        else{
            update(val,nod*2+1,mij+1,dr,poz);
        }
        N[nod]=max(N[nod*2],N[nod*2+1]);
    }
    else{
        N[nod]=val;
    }
}
int query(int nod, int stint, int drint, int st, int dr){
    int mij=(st+dr)/2,r1=0,r2=0;
    if(stint<=st&&drint>=dr){
        return N[nod];
    }
    else{
        if(stint<=mij){
            r1 = query(nod*2,stint,drint,st,mij);
        }
        if(drint>mij){
            r2 = query(nod*2+1,stint,drint,mij+1,dr);
        }
        return max(r1,r2);
    }
}
int main()
{
    int n,i,q,tip,poz,val,st,dr,mx=0;
    f >> n >> q;
    for(i=1;i<=n;i++){
        f >> T[i];
    }
    build(1,1,n);
    for(i=1;i<=q;i++){
        f >> tip;
        if(tip==1){
            f >> poz >> val;
            update(val,1,1,n,poz);
        }
        else{
            f >> st >> dr;
            g << query(1,st,dr,1,n) << '\n';
        }
    }
    return 0;
}
