#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5;

int aint[4 * MAXN], a[MAXN + 5];

void init (int nod, int st, int dr) {
    if (st == dr) {
        aint[nod] = a[st];
        return;
    }
    
    int mij = (st + dr) / 2;
    init(2 * nod + 1, st, mij);
    init(2 * nod + 2, mij + 1, dr);
    
    aint[nod] = max(aint[2 * nod + 1], aint[2 * nod + 2]);
}

void update (int nod, int st, int dr, int poz, int val) {
    if (st > poz || dr < poz) {
        return;
    }
    if (st == dr) {
        aint[nod] = val;
        return;
    }
    
    int mij = (st + dr) / 2;
    if (mij >= poz) {
        update(2 * nod + 1, st, mij, poz, val);
    } else {
        update(2 * nod + 2, mij + 1, dr, poz, val);
    }
    
    aint[nod] = max(aint[2 * nod + 1], aint[2 * nod + 2]);
}

int query (int nod, int st, int dr, int s, int d) {
    if (st > d || dr < s) {
        return -1;
    }
    
    if (s <= st && dr <= d) {
        return aint[nod];
    }
    
    int mij = (st + dr) / 2;
    return max( query(2 * nod + 1, st, mij, s, d), query(2 * nod + 2, mij + 1, dr, s, d) );
}

int main() {
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    
    int n, m, i, cer, a1, b1;
    
    cin >> n >> m;
    for (i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    init(0, 0, n - 1);
    
    for (i = 0; i < m; i++) {
        cin >> cer >> a1 >> b1;
        
        if (cer == 0) {
            cout << query(0, 0, n - 1, a1 - 1, b1 - 1) << "\n";
        } else {
            update(0, 0, n - 1, a1 - 1, b1);
        }
    }
    return 0;
}