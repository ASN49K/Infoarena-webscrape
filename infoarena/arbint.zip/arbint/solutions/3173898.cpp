#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 1e5;

int v[MAX_N + 5], aint[4 * MAX_N];

void build (int nod, int st, int dr) {
    if (st == dr) {
        aint[nod] = v[st];
    } else {
        int mij = (st + dr) / 2;

        build (2 * nod + 1, st, mij);
        build (2 * nod + 2, mij + 1, dr);
        aint[nod] = max (aint[2 * nod + 1], aint[2 * nod + 2]);
    }
}

void update (int nod, int st, int dr, int l, int r, int val) {
    if (l > r) {
        return;
    }

    if (l == st && r == dr) {
        aint[nod] = val;
    } else {
        int mij = (st + dr) / 2;

        update (2 * nod + 1, st, mij, l, min(mij, r), val);
        update (2 * nod + 2, mij + 1, dr, max(l, mij + 1), r, val);
        aint[nod] = max (aint[2 * nod + 1], aint[2 * nod + 2]);
    }
}

int query (int nod, int st, int dr, int l, int r) {
    if (l > r) {
        return -1;
    }

    if (l == st && r == dr) {
        return aint[nod];
    } else {
        int mij = (st + dr) / 2;

        return  max ( query(2 * nod + 1, st, mij, l, min(mij, r)),
                      query(2 * nod + 2, mij + 1, dr, max(l, mij + 1), r));
    }
}
int main() {
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");

    int n, m, i, tip, st, dr, val;

    cin >> n >> m;
    for (i = 0; i < n; i++) {
        cin >> v[i];
    }

    build (0, 0, n);
    for (i = 0; i < m; i++) {
        cin >> tip;
        if (tip == 0) {
            cin >> st >> dr;
            cout << query (0, 0, n, st - 1, dr - 1) << "\n";
        } else {
            cin >> st >> val;
            update (0, 0, n, st - 1, st - 1, val);
        }
    }
    return 0;
}