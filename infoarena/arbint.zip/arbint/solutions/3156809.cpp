#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int aint[400005],arr[100005];

void build(int nod, int l, int r){
	if(l==r){
		aint[nod]=arr[l];
	}else{
		int mid=(l+r)/2;
		build(2*nod,l,mid);
		build(2*nod+1,mid+1,r);
		aint[nod]=max(aint[2*nod],aint[2*nod+1]);
	}
}

void update(int nod, int l, int r, int a, int b){
	if(l==r){
		aint[nod]=b;
	}else{
		int mid=(l+r)/2;
		if(a<=mid){
			update(2*nod,l,mid,a,b);
		}else{
			update(2*nod+1,mid+1,r,a,b);
		}
		aint[nod]=max(aint[2*nod],aint[2*nod+1]);
	}
}

int query(int nod, int l, int r, int a, int b){
	if(b<l || r<a){
		return 0;
	}
	if(a<=l && r<=b){
		return aint[nod];
	}
	
	int mid=(l+r)/2;
	return max(query(2*nod,l,mid,a,b),query(2*nod+1,mid+1,r,a,b));
}



int main()
{
	int n,m;
	fin>>n>>m;
	for(int i=1;i<=n;i++){
		fin>>arr[i];
	}
	build(1,1,n);
	for(int i=1;i<=m;i++){
		int t,x,y;
		fin>>t>>x>>y;
		if(t==0){
			fout<<query(1,1,n,x,y)<<endl;
		}else{
			update(1,1,n,x,y);
		}
	}

	return 0;
}


