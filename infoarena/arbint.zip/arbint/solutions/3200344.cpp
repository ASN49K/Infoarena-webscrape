#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

const int maxn=100005;
const int sqrtmaxn=sqrt(maxn);

int v[maxn], batog[sqrtmaxn];
int n, sqrtn;

void init(int n) {
    sqrtn=sqrt(n);
    for(int i=0; i<n; i++) {
        cin>>v[i];
        batog[i/sqrtn]=max(batog[i/sqrtn], v[i]);
    }
}

void update(int a, int b) {
    int st=a/sqrtn*sqrtn;
    int dr=(a/sqrtn+1)*sqrtn;

    v[a]=b;
    if(batog[a/sqrtn]<v[a])
        batog[a/sqrtn]=v[a];
    else {
        int maxx=0;
        for(int i=st; i<dr; i++)
            maxx=max(maxx, v[i]);
        batog[a/sqrtn]=maxx;
    }
}

int afis(int a, int b) {
    int st=(a/sqrtn+1)*sqrtn;
    int dr=(b/sqrtn)*sqrtn-1;

    //cout << "akjsld:" << a << ' ' << b << ' ' << st << ' ' << dr << '\n';

    int maxx=0;
    for(int i=a; i<st; i++)
        maxx=max(maxx, v[i]);

    for(int i=dr+1; i<=b; i++)
        maxx=max(maxx, v[i]);

    for(int i=st; i<=dr; i++)
        maxx=max(maxx, batog[i/sqrtn]);

    return maxx;
    /*for(int i=0;i<n;i++)
        cout<<v[i]<<" ";
    cout<<'\n';*/
}


int main() {
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);

    int q,op,a,b;
    cin>>n>>q;

    init(n);

    for(int i=0; i<q; i++) {
        cin>>op>>a>>b;
        if(op==1)
            update(a-1, b);
        else if(op==0)
            cout<<afis(a-1, b-1)<<'\n';
    }

    /*cout<<'\n';

    for(int i=0;i<n;i++)
      cout<<v[i]<<" ";
    cout<<'\n';
    for(int i=0;i<=sqrt(n);i++)
      cout<<batog[i]<<" ";*/


    return 0;
}
