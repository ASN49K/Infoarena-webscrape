//#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <algorithm>
#include <cassert>
#include <queue>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");

int n, m, i, x, tip, a, b;
int arb[400005];
// pentru un nod n,
// fiul din stanga are indicele 2n,
// fiul din dreapta are indicele 2n+1

void update(int poz, int val, int nod = 1, int st = 1, int dr = n) {
    if(st == dr) { // am ajuns la frunza
        arb[nod] = val;
        return;
    }
    int mij = (st + dr) / 2;
    if(poz <= mij) { // mergem in fiul din stanga
        update(poz, val, nod * 2, st, mij);
    } else { // mergem in fiul din dreapta
        update(poz, val, nod * 2 + 1, mij + 1, dr);
    }
    arb[nod] = max(arb[nod * 2], arb[nod * 2 + 1]);
}

int query(int a, int b, int nod = 1, int st = 1, int dr = n) {
    if(st >= a && dr <= b) {
        return arb[nod];
    }
    int maximul = 0;
    int mij = (st + dr) / 2;
    if(a <= mij) { // mergem in fiul din stanga
        int val = query(a, b, nod * 2, st, mij);
        if(val > maximul)
            maximul = val;
    }
    if(b >= mij + 1) { // mergem in fiul din dreapta
        int val = query(a, b, nod * 2 + 1, mij + 1, dr);
        if(val > maximul)
            maximul = val;
    }
    return maximul;
}

int main() {
    cin >> n >> m;
    for(i = 1; i <= n; i ++) {
        cin >> x;
        update(i, x);
    }
    for(i = 1; i <= m; i ++) {
        cin >> tip >> a >> b;
        if(tip == 0) {
            cout << query(a, b) << '\n';
        } else {
            update(a, b);
        }
    }

    return 0;
}

//1 + 2 + 4 + 8 + ... + 2 ^ n = 2 ^ (n+1) - 1

// 2 ^ (log_2(n)) = n -> a doua putere a lui 2 mai mare decat n
