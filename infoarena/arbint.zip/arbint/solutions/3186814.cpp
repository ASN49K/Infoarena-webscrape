#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, Maxim;
int v[100005], A[400005];

void Build(int nod, int st, int dr)
{
    if (st == dr)
        A[nod] = v[st];
    else 
    {
        int mij = (st + dr) / 2;
        Build(2 * nod, st, mij);
        Build(2 * nod + 1, mij + 1, dr);
        A[nod] = max(A[2 * nod], A[2 * nod + 1]);
    }
}
void Update(int nod, int st, int dr, int a, int b)
{
    if (st == dr)
        A[nod] = b;
    else 
    {
        int mij = (st + dr) / 2;
        if (a <= mij)
            Update(2 * nod, st, mij, a, b);
        if (a > mij)
            Update(2 * nod + 1, mij + 1, dr, a, b);
        A[nod] = max(A[2 * nod], A[2 * nod + 1]);
    }
}
void Query(int nod, int st, int dr, int a, int b)
{
    if (st == dr)
        Maxim = max(Maxim, A[nod]);
    else 
    {
        int mij = (st + dr) / 2;
        if (a <= mij)
            Query(2 * nod, st, mij, a, b);
        if (b > mij)
            Query(2 * nod + 1, mij + 1, dr, a, b);
    }
}


int main()
{
    int i, j, c;
    fin >> n >> m;
    for (i = 1; i <= n; i++)
        fin >> v[i];
    Build(1, 1, n);
    while (m--)
    {
        fin >> c >> i >> j;
        if (c == 0)
        {
            Maxim = 0;
            Query(1, 1, n, i, j);
            fout << Maxim << "\n";
        }
        else 
            Update(1, 1, n, i, j);
    }
    return 0;
}