#include <fstream>
#include <iostream>
using namespace std;
int v[400500];
void modif(int nod, int a, int b, int poz, int x ) {
	//cout << nod << ' ' << a << ' ' << b << ' ' << poz << ' ' << x << '\n';
	if (a == poz && b == poz) {
		v[nod] = x;
	}
	else {
		if (poz <= ( a + b ) / 2) {
			modif( nod * 2, a, ( a + b ) / 2, poz, x );
		}
		else {
			modif( nod * 2 + 1, ( a + b ) / 2 + 1, b, poz, x );
		}
		v[nod] = max(v[nod * 2], v[nod * 2 + 1]);
	}
	//cout << nod << ' ' << v[nod] << '\n';
}
int find( int nod, int a, int b, int x, int y) {
	int r;
	//cout << a << ' ' << b << ' ' << x << ' ' << y << ' ' << v[nod] << '\n';
	if (x <= a && b <= y) {
		return v[nod];
	}
	r = 0;
	if (x <= ( a + b ) / 2) {
		r = max( find( nod * 2, a, ( a + b ) / 2, x, y), r);
	}
	if (y > (a + b) / 2) {
		r = max( find( nod * 2 + 1, ( a + b ) / 2 + 1, b, x, y ), r );
	}
	return r;
}
int main() {
	int n, m, i, tip, x, y;
	ifstream fin( "arbint.in" );
	ofstream fout( "arbint.out" );
	fin >> n >> m;
	for (i = 0; i < n; i++) {
		fin >> x;
		modif( 1, 0, n - 1, i, x );
	}
	for (i = 0; i < m; i++) {
		fin >> tip >> x >> y;
		if (tip == 1) {
			modif( 1, 0, n - 1, x - 1, y );
		}
		else {
			fout << find( 1, 0, n - 1, x - 1, y - 1 ) << '\n';
		}
	}
	return 0;
}