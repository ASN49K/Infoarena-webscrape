#include <bits/stdc++.h>

using namespace std;
ifstream in("arbint.in");
ofstream out("arbint.out");
int n, q;
int arb[400005];

void update(int node, int st, int dr, int idx, int val){
    if( st == dr ){
        arb[node] = val;
        return ;
    }
    int mij = ( st + dr ) / 2;
    if( idx <= mij ) update( node * 2, st, mij, idx, val );
    else update( node * 2 + 1, mij + 1, dr, idx, val );
    arb[node] = max(arb[node* 2], arb[node * 2 + 1]);
}
int query( int poz, int st, int dr, int qst, int qdr ){
    if( qst <= st && dr <= qdr )
        return arb[poz];
    int mij = ( st + dr ) / 2;
    int left = -1e9, right = -1e9;
    if( st <= mij ) left = query( poz * 2, st, mij, qst, qdr);
    else right = query(poz * 2 + 1, mij + 1, dr, qst, qdr);
    return max(left, right); 
}
int main(){
    in >> n >> q;
    for( int i = 1; i <= n; i++ ){
        int x; 
        in >> x;
        update(1, 1, n, i, x);
    }

    while( q-- ){
        int a, b; char c;
        in >> c >> a >> b;
        if( c == 'q')
             out << query(1, 1, n, a, b) << " \n";
        else{
            update(1, 1, n, a, b);
        }               
    }
}