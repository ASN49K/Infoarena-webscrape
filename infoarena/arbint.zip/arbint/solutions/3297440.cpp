#include <bits/stdc++.h>
#define MAX 100005
using namespace std;
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int arb[4*MAX], lazy[8*MAX], v[MAX];
void construieste(int nod, int st, int dr) {
    if (st==dr) arb[nod]=v[st];
    else {
        construieste(2*nod, st, (st+dr)/2);
        construieste(2*nod+1, (st+dr)/2+1, dr);
        arb[nod]=max(arb[2*nod], arb[2*nod+1]);
    }
}
void coborare(int nod, int st, int dr) {
    if (lazy[nod]!=0) {
        arb[nod]=max(arb[nod], lazy[nod]);
        if (2*nod+1<4*MAX) {
            lazy[2*nod]=lazy[nod];
            lazy[2*nod+1]=lazy[nod];
        }
        lazy[nod]=0;
    }
}
void update(int nod, int st, int dr, int a, int x) {
    if (a==st && a==dr) {
        arb[nod]=x;
    }
    else {
        int mij=(st+dr)/2;
        if (a<=mij) update(2*nod, st, mij, a, x);
        else update(2*nod+1, mij+1, dr, a, x);
        coborare(2*nod, st, mij);
        coborare(2*nod+1, mij+1, dr);
        arb[nod]=max(arb[2*nod], arb[2*nod+1]);
    }
}
int intrebare(int nod, int st, int dr, int a, int b) {
    coborare(nod, st, dr);
    if (a<=st && dr<=b) return arb[nod];
    int mij=(st+dr)/2, maxx=0;
    if (a<=mij) maxx=intrebare(2*nod, st, mij, a, b);
    else maxx=max(maxx, intrebare(2*nod+1, mij+1, dr, a, b));
    return maxx;
}
int main()
{
    int n, m, i, x, a, b;
    fin>>n>>m;
    for (i=1; i<=n; i++) fin>>v[i];
    construieste(1, 1, n);
    for (i=1; i<=m; i++) {
        fin>>x>>a>>b;
        if (x==0) fout<<intrebare(1, 1, n, a, b)<<'\n';
        else update(1, 1, n, a, b);
    }
    return 0;
}
