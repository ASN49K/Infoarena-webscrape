/// Arbori de intervale pe infoarena

#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream f("arbint.in");
ofstream g("arbint.out");

const int N_MAX = 10000l;
int n, m;
int start, finish, val, pos, maxim; /// punem val globale parametrii la fct pt a scrie mai usor
int a[3 * N_MAX];

void Update(int nod, int l, int r){
    if(l < r){
        int m = (l + r) / 2;
        if(pos <= m)
            Update(2 * nod, l, m);
        else
            Update(2 * nod + 1, m + 1, r);

        a[nod] = max(a[2 * nod], a[2 * nod + 1]); /// actualizam arborele de intervale
    }else
        a[nod] = val;
}

void Query(int nod, int l, int r){
    if(start <= l && r <= finish){ /// Maximul intre [l, r] este in a[nod]
        if(maxim < a[nod])
            maxim = a[nod];
    }else{
        int m = (l + r) / 2;
        if(start <= m)
            Query(2 * nod, l, m);
        if(m < finish)
            Query(2 * nod + 1, m + 1, r);
    }
}

int main()
{
    f >> n >> m;

    for(int i = 1, x; i <= n; ++i){
        f >> x;
        pos = i, val = x;
        Update(1, 1, n);
    }

    for(int i = 0, c, A, B; i < m; ++i){
        f >> c >> A >> B;
        switch(c){
            case 0:
                maxim = INT_MIN;
                start = A, finish = B;
                Query(1, 1, n);
                g << maxim << '\n';
                break;
            case 1:
                pos = A, val = B;
                Update(1, 1, n);
                break;
        }
    }

    return 0;
}
