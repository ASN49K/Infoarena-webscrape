#include<iostream>
#include<fstream>
using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

#define nmax 262144

struct nod{
    int st,dr;
    int value;

    bool intersects(int stI,int drI){
        if(dr<stI || st>drI){
            return false;
        }else{
            return true;
        }
    }
    bool isInsideNod(nod x){
        if(x.st>=st && x.dr<=dr){
            return true;
        }else{
            return false;
        }
    }
};

int msb(int x){
    int msb=1;
    while(x){
        x=x>>1;
        msb=msb<<1;
    }
    return msb;
}
int lsb(int x){
    return x&(-x);
}


nod v[nmax];
void build(int n){
    for(int i=n;i<=n*2-1;i++){
        v[i].st=v[i].dr=i-n+1;
    }

    for(int i=n-1;i>0;i--){
        v[i].value=max(v[2*i].value,v[2*i+1].value);
        v[i].st=v[2*i].st;
        v[i].dr=v[2*i+1].dr;
    }
}
void update(int loc,int val,int n){
    v[loc+n-1].value=val;
    int current=loc+n-1;
    while(current!=1){
        current/=2;
        v[current].value=max(v[2*current].value,v[2*current+1].value);
    }
}
int query(int now,nod qry){
    int result=-1;
    if(qry.isInsideNod(v[now*2])){
        result=max(result,v[now*2].value);
    }
    else if(v[now*2].intersects(qry.st,qry.dr)){
        result=max(query(now*2,qry),result);
    }
    if(qry.isInsideNod(v[now*2+1])){
        result=max(result,v[now*2+1].value);
    }
    else if(v[now*2+1].intersects(qry.st,qry.dr)){
        result=max(query(now*2+1,qry),result);
    }
    return result;
}

int main()
{
    int n,m;
    in>>n>>m;

    int nmsb=msb(n);
    int x;

    for(int i=0;i<n;i++){
        in>>x;
        v[nmsb+i].value=x;
    }

    build(nmsb);

    int c,y;
    for(int i=0;i<m;i++){
        in>>c>>x>>y;
        if(c==0){
            nod interval;
            interval.st=x;
            interval.dr=y;
            out<<query(1,interval)<<'\n';
        }else{
            update(x,y,nmsb);
        }
    }
}
