#include <stdio.h>
#define mx 400010
long n, a, b, c, i, m, s;
long ai[mx];

long max(long a, long b)
{
	long m;
	m = a;
	if (m < b)
		m = b;
	return m;
}

void comp(long nod)
{
	if (ai[nod] > s)
		s = ai[nod];
}

void add(long nod, long p, long u, long poz, long val, long pr)
{
	long m;
	if (p == u)
		ai[nod] = val;
	else
	{
		m = (p + u) / 2;
		if (poz <= m)
			add(2 * nod, p, m, poz, val, pr);
		if (m < poz)
			add(2 * nod + 1, m + 1, u, poz, val, pr);
		ai[nod] = max(ai[2 * nod], ai[2 * nod + 1]);
	}
}

void query(long nod, long p, long u)
{
	long m;
	if (a <= p && u <= b)
	{
		comp(nod);
		return;
	}
	if (p < u)
	{
		m = (p + u) / 2;
		if (a <= m)
			query(2 * nod, p, m);
		if (m < b)
			query(2 * nod + 1, m + 1, u);
	}
}

int main()
{
	freopen("arbint.in", "r", stdin);
	freopen("arbint.out", "w", stdout);
	scanf("%ld %ld", &n, &m);
	for (i = 1; i <= n; i++)
	{
		scanf("%ld", &a);
		add(1, 1, n, i, a, 0);
	}
	for (i = 1; i <= m; i++)
	{
		scanf("%ld %ld %ld", &c, &a, &b);
		if (c == 1)
			add(1, 1, n, a, b, 1);
		else
		{
			s = 0;
			query(1, 1, n);
			printf("%ld\n", s);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}