#include <bits/stdc++.h>
using namespace std;

const int MAX = 100005;
int a[4*MAX], n;

void Update(int p, int x)
{
    p += (n-1);
    a[p] = x;

    while (p > 1)
    {
        p /= 2;
        a[p] = max(a[p*2], a[p*2+1]);
    }
}

int Query(int k, int x, int y, int st, int dr)
{
    if (x == st && y == dr) return a[k];
    int m = st + (dr - st) / 2;
    if (y <= m)
        return Query(2*k, x, y, st, m);

    if (x >= m+1)
        return Query(2*k+1, x, y, m+1, dr);

    return max(Query(2*k, x, m, st, m), Query(2*k+1, m+1, y, m+1, dr));
}

int main()
{
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");
    int k, q;
    cin >> k >> q;

    for (n = 1; n < k; n *= 2);

    for (int i = 1; i <= k; ++i)
        fin >> a[n - 1 + i];

    for (int i = n-1; i >= 1; --i)
        a[i] = max(a[i*2], a[i*2+1]);

    while (q--)
    {
        int c, x, y;
        fin >> c >> x >> y;
        if (c == 0)
            fout << Query(1, x, y, 1, n) << "\n";
        else
            Update(x, y);
    }

    return 0;
}
