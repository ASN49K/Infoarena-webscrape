#include <iostream>
#include <cmath>
#include <cstring>
#include <map>
#include <algorithm>
#include <deque>
#include <queue>
#include <iomanip>
#include <bitset>
#include <unordered_map>
#include <set>
#include <fstream>
#include <unordered_set>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, v[100001], tree[400001];

void update(int left, int right, int currentNode, int pos, int newValue) {
    if (left == right) {
        tree[currentNode] = newValue;
        return;
    } else if (pos >= left && pos <= (left + right) / 2) {
        update(left, (left + right) / 2, currentNode * 2, pos, newValue);
    } else {
        update((left + right) / 2 + 1, right, currentNode * 2 + 1, pos, newValue);
    }
    tree[currentNode] = max(tree[currentNode * 2], tree[currentNode * 2 + 1]);
}

int findMax(int left, int right, int currentNode, int a, int b) {
    if (a <= left && right <= b) {
        return tree[currentNode];
    } else if (right < a || left > b) {
        return 0;
    }
    return max(findMax(left, (left + right) / 2, currentNode * 2, a, b), findMax((left + right) / 2 + 1, right, currentNode * 2 + 1, a, b));
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
        update(1, n, 1, i, v[i]);
    }
    for (int i = 1; i <= m; ++i) {
        int op, a, b;
        fin >> op >> a >> b;
        if (op) {
            update(1, n, 1, a, b);
        } else {
            fout << findMax(1, n, 1, a, b) << '\n';
        }
    }
    return 0;
}
