#include <stdio.h>
#include <math.h>

using namespace std;

#define MAXN 100000
#define UPDATE 1
#define QUERY 0
const int SQ_N = sqrt(MAXN);
const int BSIZE = (MAXN + SQ_N - 1)/ SQ_N;

int v[MAXN];
int maxim[BSIZE];

void update(int poz, int val){
    int i, buck;

    buck = poz / SQ_N;
    if(val > maxim[buck]){
        maxim[buck] = val;
        v[poz] = val;
    }
    else if(v[poz] == maxim[buck]){
        v[poz] = maxim[buck] = val;
        for(i = buck * SQ_N; i < (buck + 1) * SQ_N; i++){
            if(v[i] > maxim[buck]){
                maxim[buck] = v[i];
            }
        }
    }
}

int query(int a, int b){
    int i, st, dr, maxx;

    st = (a + SQ_N - 1) / SQ_N * SQ_N;
    dr = b / SQ_N * SQ_N;

    maxx = 0;
    while(a <= b && a < st){
        if(v[a] > maxx){
            maxx = v[a];
        }
        a++;
    }
    while(b >= a && b > dr){
        if(v[b] > maxx){
            maxx = v[b];
        }
        b--;
    }
    st /= SQ_N;
    dr /= SQ_N;
    for(i = st; i < dr; i++){
        if(maxim[i] > maxx){
            maxx = maxim[i];
        }
    }
    return maxx;
}

int main()
{
    FILE *fin, *fout;
    fin = fopen("arbint.in", "r");
    fout = fopen("arbint.out", "w");

    int n, m, i, op, a, b;

    fscanf(fin, "%d%d", &n, &m);

    for(i = 0; i < n; i++){
        fscanf(fin, "%d", &v[i]);
        if(v[i] > maxim[i / SQ_N]){
            maxim[i / SQ_N] = v[i];
        }
    }

    for(i = 0; i < m; i++){
        fscanf(fin, "%d%d%d", &op, &a, &b);
        if(op == UPDATE){
            update(a - 1, b);
        }
        else{
            fprintf(fout, "%d\n", query(a - 1, b - 1));
        }
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
