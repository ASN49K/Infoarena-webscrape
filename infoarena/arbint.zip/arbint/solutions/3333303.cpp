#include <bits/stdc++.h>
using namespace std;

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    long long n, t, a, b, o, rez=0, lim=100, cat, cum, j=0;
    cin >> n >> t;
    vector <long long> v;
    vector <long long> mare;
    v.resize(n+1);
    mare.resize(n/lim+1);
        
    for(int i=1; i<=n; i++)
    {
        cin >> v[i];
        j=i/lim;
        mare[j]=max(mare[j], v[i]);
    }
    
    while(t>0)
    {
        
            cin >> o;
            if(o==0)
            {
                cin >> a >> b;
                cat=b/lim;
                cum=a/lim;
                
                if(cat!=cum)
                {
                    for(int i=a; i<(cum+1)*lim; i++)
                        rez=max(rez, v[i]);
                        
                    for(int i=cum+1; i<cat; i++)
                        rez=max(rez, mare[i]);
                        
                    for(int i=cat*lim; i<=b; i++)
                        rez=max(rez, v[i]);
                }
                else
                    for(int i=a; i<=b; i++)
                        rez=max(rez, v[i]);
                        
                cout << rez << "\n";
                rez=0;
            }
            else
            if(o==1)
            {
                cin >> a >> b;
                v[a]=b;
                if(v[a]<mare[a/lim])
                {
                    cum=a/lim;
                    mare[cum]=0;
                    for(int i=cum*lim; i<(cum+1)*lim && i<=n; i++)
                    {
                        mare[cum]=max(mare[cum], v[i]);
                    }
                }
                mare[a/lim]=max(mare[a/lim], v[a]);
            }
            
        t--;
    }

    return 0;
}