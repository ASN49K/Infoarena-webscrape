#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int N_MAX = 100000;

int tree[4 * N_MAX + 5];
int V[N_MAX + 5];

void build(int node, int le, int ri)
{
  if(le == ri){
    tree[node] = V[le];
    return;
  }
  int mid = (le + ri) / 2;
  build(2 * node, le, mid);
  build(2 * node + 1, mid + 1, ri);
  tree[node] = max(tree[2 * node], tree[2 * node + 1]); 
}

void update(int node, int le, int ri, int pos, int val)
{
  if(le == ri){
    tree[node] = val;
    return;
  }
  int mid = (le + ri) / 2;
  if(pos <= mid){
    update(2 * node, le, mid, pos, val);
  }
  else{
    update(2 * node + 1, mid + 1, ri, pos, val);
  }
  tree[node] = max(tree[2 * node], tree[2 * node + 1]);
}

void query(int node, int le, int ri, int x, int y, int &ans)
{
  if(x <= le && ri <= y){
    ans = max(ans, tree[node]);
    return;
  }
  int mid = (le + ri) / 2;
  if(x <= mid){
    query(2 * node, le, mid, x, y, ans);
  }
  if(y > mid){
    query(2 * node + 1, mid + 1, ri, x, y, ans);
  }
}

int main()
{
  int n, m;
  fin >> n >> m;
  for(int i = 1; i <= n; i++){
    fin >> V[i];
  }
  build(1, 1, n);
  for(int i = 0; i < m; i++){
    int type, a, b;
    fin >> type >> a >> b;
    if(type == 0){
      int ans = -1;
      query(1, 1, n, a, b, ans);
      fout << ans << "\n";
    }
    else if(type == 1){
      update(1, 1, n, a, b);
    }
  }
  return 0;
}
