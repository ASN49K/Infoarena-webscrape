#include <fstream>
#include <climits>
#include <vector>

void Build(std::vector<int> & v, std::vector<int> & aint, int index, int left, int right) {
    if (left == right) {
        aint[index] = v[left];
    } else {
        int middle = (left + right) >> 1;
        Build(v, aint, 2 * index, left, middle);
        Build(v, aint, 2 * index + 1, middle + 1, right);
        aint[index] = std::max(aint[2 * index], aint[2 * index + 1]);
    }
}

void Update(std::vector<int> & aint, int index, int left, int right, int pos, int newVal) {
    if (left == right) {
        aint[index] = newVal;
    } else {
        int middle = (left + right) >> 1;
        if (pos <= middle) {
            Update(aint, 2 * index, left, middle, pos, newVal);
        } else {
            Update(aint, 2 * index + 1, middle + 1, right, pos, newVal);
        }
        aint[index] = std::max(aint[2 * index], aint[2 * index + 1]);
    }
}

int Max(std::vector<int> & aint, int index, int left, int right, int leftQuery, int rightQuery) {
    if (left > rightQuery || right < leftQuery) {
        return INT_MIN;
    }
    if (left >= leftQuery && right <= rightQuery) {
        return aint[index];
    }

    int middle = (left + right) >> 1;
    return std::max(Max(aint, 2 * index, left, middle, leftQuery, rightQuery),
                    Max(aint, 2 * index + 1, middle + 1, right, leftQuery, rightQuery));
}

int main() {
    std::ifstream fin("arbint.in");
    std::ofstream fout("arbint.out");

    int n, m; fin >> n >> m;
    const int nMax = (int) 1e5;
    std::vector<int> v(n), aint(4 * nMax);
    for (int i = 0; i < n; i += 1) {
        fin >> v[i];
    }

    Build(v, aint, 1, 0, n - 1);

    for (int i = 0; i < m; i += 1) {
        int operation, a, b; fin >> operation >> a >> b;
        if (operation == 0) {
            fout << Max(aint, 1, 0, n - 1, a - 1, b - 1) << '\n';
        } else {
            Update(aint, 1, 0, n - 1, a - 1, b - 1);
        }
    }

    v.clear(), aint.clear();
    fin.close(), fout.close();
    return 0;
}
