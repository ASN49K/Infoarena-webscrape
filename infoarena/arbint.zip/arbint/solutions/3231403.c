#include <stdio.h>


int arbore[400001];

int maxim(int x,int y)
{
    return (x>y) ? x:y;
}

void update(int nod,int st,int dr,int p,int val)
{
    if(st==dr)
    {
       arbore[nod]=val;
       return ;
    }
    int mij=(st+dr)/2;
    if(p<=mij)
        update(2*nod,st,mij,p,val);
    else
        update(2*nod+1,mij+1,dr,p,val);
    arbore[nod]=maxim(arbore[2*nod],arbore[2*nod+1]);
}

int query(int nod,int st,int dr,int a,int b)
{
    if(a>dr||b<st)
        return -1;
    if(a<=st && dr<=b)
        return arbore[nod];

    int mij=(st+dr)/2;
    int max_st=query(2*nod,st,mij,a,b);
    int max_dr=query(2*nod+1,mij+1,dr,a,b);
    if (max_st==-1)
        return max_dr;
    if (max_dr== -1)
        return max_st;
    return maxim(max_st,max_dr);
}

int main()
{
    FILE *f1=fopen("arbint.in","r"),*f2=fopen("arbint.out","w");
    int n,m;
    fscanf(f1,"%d %d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        int val;
        fscanf(f1,"%d",&val);
        update(1,1,n,i,val);
    }
    for(int i=0;i<m;i++)
    {
        int a,b,tip;
        fscanf(f1,"%d %d %d",&tip,&a,&b);
        if(tip==0)
        {
            fprintf(f2,"%d\n",query(1,1,n,a,b));
        }
        else
        {
            update(1,1,n,a,b);
        }
    }
    fclose(f1);
    fclose(f2);
    return 0;
}
