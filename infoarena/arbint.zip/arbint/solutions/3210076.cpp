#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int aint[400005], n;

void Add(int p, int x)
{
	p += n;
	aint[p] = x;
	for (p /= 2; p >= 1; p /= 2)
		aint[p] = max(aint[2 * p], aint[2 * p + 1]);
}

int Query(int a, int b)
{
	a += n;
	b += n;
	int mx = max(aint[a], aint[b]);
	while (a <= b)
	{
		if (a % 2 == 1) mx = max(mx, aint[a++]);
		if (b % 2 == 0) mx = max(mx, aint[b--]);
		a /= 2; b /= 2;
	}
	return mx;
}

int main()
{
	int i, op, x, y, q;
	fin >> n >> q;
	for (i = 1; i <= 4 * n; i++)
		aint[i] = -2e9;
	for (i = 1; i <= n; i++)
	{
		fin >> x;
		Add(i, x);
	}
	while (q--)
	{
		fin >> op >> x >> y;
		if (op == 0)
			fout << Query(x, y) << "\n";
		else
			Add(x, y);
	}
	return 0;
}
