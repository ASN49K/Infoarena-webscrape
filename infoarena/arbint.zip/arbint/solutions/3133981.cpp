#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n, m, x, poz, op, a, b, maxx;
vector<int> A;

void make(int L, int R, int nod){
    cout<<A[nod]<<' '<<nod<<' '<<x<<endl;
    if (L == R){
        A[nod] = x;
        return;
    }
    int LR = (L + R) / 2;
    if (poz <= (LR)){
        make(L, LR, 2 * nod);
    }
    else{
        make(LR + 1, R, 2 * nod + 1);
    }
    A[nod] = max(A[2 * nod], A[2 * nod + 1]);
}

void que(int L, int R, int nod){
    if (a <= L && R <= b){
        maxx = max(maxx, A[nod]);
        return;
    }
    int LR = (L + R) / 2;
    if (a <= LR){
        que(L, LR, 2 * nod);
    }
    if (LR < b){
        que(LR + 1, R, 2 * nod + 1);
    }
}

int main() {
    fin>>n>>m;
    A.resize(4 * n, 0);
    for (int i = 1; i <= n; ++i) {
        fin>>x;
        poz = i;
        make(1, n, 1);
    }
    for (int i = 0; i < m; ++i) {
        fin>>op>>a>>b;
        if (op == 0){
            maxx = -1;
            que(1, n, 1);
            fout<<maxx<<endl;
            cout<<endl;
        }
        else{
            poz = a;
            x = b;
            make(1, n, 1);
        }
    }
    return 0;
}