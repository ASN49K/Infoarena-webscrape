#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
const int zid=-2e9;
int n,q,v[100005],arb[400005];
void build(int nod, int l, int r)
{
    if(l==r)
        arb[nod]=v[l];
    else
    {
        int mij=(l+r)/2;
        build(2*nod,l,mij);
        build(2*nod+1,mij+1,r);
        arb[nod]=max(arb[2*nod],arb[2*nod+1]);
    }
}
void update(int nod, int l, int r, int pos, int val)
{
    if(l==r)
        arb[nod]=val;
    else
    {
        int mij=(l+r)/2;
        if(pos<=mij)
            update(2*nod,l,mij,pos,val);
        else
            update(2*nod+1,mij+1,r,pos,val);
        arb[nod]=max(arb[2*nod],arb[2*nod+1]);
    }
}
int query(int nod, int l, int r, int st, int dr)
{
    if(r<st||dr<l)
        return zid;
    else if(st<=l&&r<=dr)
        return arb[nod];
    else
    {
        int mij=(l+r)/2;
        return max(query(2*nod,l,mij,st,dr),query(2*nod+1,mij+1,r,st,dr));
    }
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    build(1,1,n);
    for(int i=1;i<=q;i++)
    {
        int tip,a,b;
        cin>>tip>>a>>b;
        if(tip==1)
            update(1,1,n,a,b);
        else
            cout<<query(1,1,n,a,b)<<"\n";
    }
    return 0;
}
