#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

class SegmentTree
{
private:
    vector<int> maxTree;
    int size;

    void update(int node, int left, int right, int pos, int val)
    {
        if (left == right)
        {
            maxTree[node] = val;
            return;
        }

        int mid = (left + right) / 2;
        if (pos <= mid)
            update(2 * node, left, mid, pos, val);
        else
            update(2 * node + 1, mid + 1, right, pos, val);

        maxTree[node] = max(maxTree[2 * node], maxTree[2 * node + 1]);
    }

    int query(int node, int left, int right, int start, int finish)
    {
        if (start <= left && right <= finish)
        {
            return maxTree[node];
        }

        int mid = (left + right) / 2;
        int leftMax = -1, rightMax = -1;

        if (start <= mid)
            leftMax = query(2 * node, left, mid, start, finish);
        if (mid < finish)
            rightMax = query(2 * node + 1, mid + 1, right, start, finish);

        if (leftMax == -1)
            return rightMax;
        if (rightMax == -1)
            return leftMax;

        return max(leftMax, rightMax);
    }

public:
    SegmentTree(int n) : size(n)
    {
        maxTree.resize(4 * n, -1);
    }

    void update(int pos, int val)
    {
        update(1, 1, size, pos, val);
    }

    int query(int start, int finish)
    {
        return query(1, 1, size, start, finish);
    }
};

int main()
{

    int n, m;
    fin >> n >> m;

    SegmentTree segTree(n);

    for (int i = 1; i <= n; i++)
    {
        int x;
        cin >> x;
        segTree.update(i, x);
    }

    while (m--)
    {
        int op, a, b;
        fin >> op >> a >> b;
        if (op == 0)
        {
            int maxVal = segTree.query(a, b);
            fout << maxVal << '\n';
        }
        else
        {
            segTree.update(a, b);
        }
    }

    return 0;
}
