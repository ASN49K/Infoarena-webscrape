#include <bits/stdc++.h>

using namespace std;

const int MAXN=2e5+5;
const int INF=1e9;
int n, m;

struct seg_tree
{
    int tree[MAXN*4];
    
    void init()
    {
        for(int i=1; i<=4*n; i++)
        {
            tree[i]=0;
        }
    }

    void update0(int nd, int l, int r, int q, int diff)
    {
        if(r < q)
            return;
        if(q < l)
            return;
        if(l == r)
        {
            tree[nd]=diff;
            return;
        }
        int mid=(l+r)/2;
        update0(nd*2+1, l, mid, q, diff);
        update0(nd*2+2, mid+1, r, q, diff);
        tree[nd]=max(tree[nd*2+1], tree[nd*2+2]);
    }

    int query0(int nd, int l, int r, int ql, int qr)
    {
        if(r < ql)
            return -INF;
        if(qr < l)
            return -INF;
        if(ql <= l && r <= qr)
            return tree[nd];
        int mid=(l+r)/2;
        return max(query0(nd*2+1, l, mid, ql, qr), query0(nd*2+2, mid+1, r, ql, qr));
    }

    void update(int x, int val)
    {
        update0(0, 1, n, x, val);
    }

    int query(int l, int r)
    {
        return query0(0, 1, n, l, r);
    }

    void afis(int l, int r)
    {
        for(int i=l; i<=r; i++)
            cout<<query(i, i)<<' ';
        cout<<'\n';
    }
};

seg_tree aint;

int32_t main()
{
    cin>>n>>m;
    int a;
    for(int i=1; i<=n; i++)
    {
        cin>>a;
        aint.update(i, a);
    }
    int op, b;
    while(m--)
    {
        cin>>op>>a>>b;
        if(op == 0)
            cout<<aint.query(a, b)<<'\n';
        else
            aint.update(a, b);
    }
    return 0;
}