#include <stdio.h>
#include <stdlib.h>

#define NMAX 100009

int v[NMAX];
int tree[4*NMAX+3];

int max(int a , int b)
{
    if(a>b)return a;
    return b;
}
void build_tree(int node,int left,int right)
{
    if(left==right)
    {
        tree[node]=v[left];
        return; 
    }
    int mid=(left+right)/2;
    build_tree(2*node,left,mid);
    build_tree(2*node+1,mid+1,right);
    tree[node]=max(tree[2*node],tree[2*node+1]);
}
void update(int node,int left,int right,int index,int value)
{
    if(left==right)
    {
        tree[node]=value;
        return;
    }
    int mid=(left+right)/2;
    if(index<=mid)
    {
        update(2*node,left,mid,index,value);
    }
    else
    {
        update(2*node+1,mid+1,right,index,value);
    }
    tree[node]=max(tree[2*node],tree[2*node+1]);
}
int query(int node,int left,int right,int a,int b)
{
    if(a<=left && right<=b)
    {
        return tree[node];
    }
    if(b<left || a>right)
    {
        return 0;
    }
    int mid=(left+right)/2;
    int le=query(2*node,left,mid,a,b);
    int ri=query(2*node+1,mid+1,right,a,b);
    return max(le,ri);
}


int main(void)
{
    FILE* fin=fopen("arbint.in","r");
    FILE* fout=fopen("arbint.out","w");
    if(fin==NULL || fout==NULL)
    {
        fprintf(stderr,"eroare la deschiderea fisierelor");
        exit(EXIT_FAILURE);
    }
    int N,M;
    if((fscanf(fin,"%d %d",&N,&M))!=2)
    {
        fprintf(stderr,"eroare la citirea din fisier");
        exit(EXIT_FAILURE);
    }
    build_tree(1,1,N);
    for(int i=0;i<M;i++)
    {   
        int tip,a,b;
        if((fscanf(fin,"%d %d %d",&tip,&a,&b))!=3)
        {    
            fprintf(stderr,"eroare la citirea din fisier");
            exit(EXIT_FAILURE);
        }
        if(tip==0)
        {
            int rez=query(1,1,N,a,b);
            fprintf(fout,"%d\n",rez);
        }
        else
        {
            update(1,1,N,a,b);
        }
    }



    return 0;
}