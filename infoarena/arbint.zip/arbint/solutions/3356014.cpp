// 100 Puncte (pentru stanga trebuie mid, nu mid-1, pt dreapta mid+1)
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("arbint.in");
ofstream fout ("arbint.out");

int n, m;
int aint[400005];

void update (int pos, int x, int st, int dr, int new_pos)
{
    if (st>=dr) {
        aint[new_pos] = x;
        return;
    }
    int old_pos = new_pos, other_pos;
    int mid = (st+dr)/2;
    if (pos<=mid) {
        other_pos = 2*new_pos + 1;
        new_pos = 2*new_pos;
        dr = mid;
    }
    else {
        other_pos = 2*new_pos;
        new_pos = 2*new_pos + 1;
        st = mid + 1;
    }
    update(pos, x, st, dr, new_pos);
    aint[old_pos] = max(aint[new_pos], aint[other_pos]);
}

int query (int a, int b, int st, int dr, int new_pos) {
    if (a<=st&&dr<=b) return aint[new_pos];
    int mid = (st+dr)/2;
    int a1=-1, a2=-1;
    if (a<=mid) {
        a1 = query(a, b, st, mid, 2*new_pos);
    }
    if (b>mid) {
        a2 = query(a, b, mid+1, dr, 2*new_pos+1);
    }
    return max(a1, a2);
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    fin>>n>>m;
    for (int i=1; i<=n; i++) {
        int x; fin>>x;
        update(i, x, 1, n, 1);
    }
    while (m--) {
        int op, a, b;
        fin>>op>>a>>b;
        if (op==0) {
           fout<<query(a, b, 1, n, 1)<<'\n';
        }
        if (op==1) {
            update(a, b, 1, n, 1);
        }
    }
    return 0;
}