#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int ValMax = 100000;
const int NodMax = 200000;

int ArborInt[NodMax + 5], Val[ValMax + 5];
int Num, Oper;

void build(int Nod, int St, int Dr)
{
    if(St == Dr)
    {
        ArborInt[Nod] = Val[St];
    }
    else
    {
        int Mij = (St + Dr) >> 1;
        build(2 * Nod, St, Mij);
        build(2 * Nod + 1, Mij + 1, Dr);
        ArborInt[Nod] = max(ArborInt[2 * Nod], ArborInt[2 * Nod + 1]);
    }
}

int query(int StQ, int DrQ, int Left, int Right, int Nod)
{
    if(StQ <= Left && DrQ >= Right)
    {
        return ArborInt[Nod];
    }
    if(StQ <= Right && DrQ >= Left)
    {
        int Mij = (Left + Right) >> 1;
        return max(query(StQ, DrQ, Left, Mij, 2 * Nod),
                query(StQ, DrQ, Mij + 1, Right, 2 * Nod + 1));
    }
    return 0;
}

/*void update(int Nod, int NodQ, int Left, int Right, int NewVal)
{
    cout<<Left<<" "<<NewVal<<"\n";
    ArborInt[Nod] = max(ArborInt[Nod], NewVal);
    if(Left != Right)
    {
        int Mij = (Left + Right) >> 1;
        if(NodQ <= Mij)
            update(2 * Nod, NodQ, Left, Mij, NewVal);
        else
            update(2 * Nod + 1, NodQ, Mij + 1, Right, NewVal);
    }
}*/

int main()
{
    fin >> Num >> Oper;

    for(int i = 1; i <= Num; ++i)
    {
        fin>>Val[i];
    }
    build(1, 1, Num);
    for(int i = 1; i <= Oper; ++i)
    {
        int Tip;
        fin >> Tip;
        if(Tip == 0)
        {
            int StQ, DrQ;
            fin >> StQ >> DrQ;
            fout << query(StQ, DrQ, 1, Num, 1) << "\n";
        }
        else
        {
            int NodQ, NewVal;
            fin >> NodQ >> NewVal;
            Val[NodQ] = NewVal;
            build(1, 1, Num);
        }
    }
    return 0;
}
