#include <fstream>
#define nmax 100001
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,q,aint[4*nmax],v[nmax],sol,c,a,b;
void build(int nod,int st,int dr){
    if(st==dr){
        aint[nod]=v[st];
        return;
    }
    int mid=(st+dr)/2;
    build(2*nod,st,mid);
    build(2*nod+1,mid+1,dr);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
void query(int nod,int st,int dr,int a,int b){
    if(a<=st&&dr<=b){
        sol=max(sol,aint[nod]);
        return ;
    }
    int mid=(st+dr)/2;
    if(a<=mid)
        query(2*nod,st,mid,a,b);
    if(mid<b)
        query(2*nod+1,mid+1,dr,a,b);
}
void update(int nod,int st,int dr,int a,int b){
    if(st==dr){
        aint[nod]=b;
        return ;
    }
    int mid=(st+dr)/2;
    if(a<=mid)
        update(2*nod,st,mid,a,b);
    else
        update(2*nod+1,mid+1,dr,a,b);
    aint[nod]=max(aint[2*nod],aint[2*nod+1]);
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    build(1,1,n);
    while(q--){
        cin>>c>>a>>b;
        if(c==0){
            sol=0;
            query(1,1,n,a,b);
            cout<<sol<<'\n';
        }else
            update(1,1,n,a,b);
    }
    return 0;
}
