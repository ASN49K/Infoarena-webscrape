#include <stdio.h>
#include <stdlib.h>


FILE *fin = NULL;
FILE *fout = NULL;

int arb[4 * 100002], n, m, maxim = 0;

int max(int a, int b)
{
    if(a > b)
    {
        return a;
    }
    return b;
}

void actualizare(int nod, int st, int dr, int val, int pos)
{
    if(st == dr)
    {
        arb[nod] = val;
    }
    else
    {
        int mij = (st + dr) / 2;
        if(pos <= mij)
        {
            actualizare(2 * nod, st, mij, val, pos);
        }
        else
        {
            actualizare(2 * nod + 1, mij + 1, dr, val, pos);
        }
        arb[nod] = max(arb[2 * nod], arb[2 * nod + 1]);
    }
}

void parcurgere(int nod, int st, int dr, int a, int b)
{
    if(a <= st && b >= dr)
    {
        if(arb[nod] > maxim)
        {
            maxim = arb[nod];
        }
    }
    else
    {
        int mij = (st + dr) / 2;
        if(a <= mij)
        {
            parcurgere(2 * nod, st, mij, a, b);
        }
        if(b > mij)
        {
            parcurgere(2 * nod + 1, mij + 1, dr, a, b);
        }
    }
}

int main(void)
{
    int x, c, a, b;
    if((fin = fopen("arbint.in", "r")) == NULL)
    {
        exit(-1);
    }
    if((fout = fopen("arbint.out", "w")) == NULL)
    {
        exit(-1);
    }
    fscanf(fin, "%d %d", &n, &m);
    for(int i = 1; i <= n; i++)
    {
        fscanf(fin, "%d", &x);
        actualizare(1, 1, n, x, i);
    }
    while(m)
    {
        fscanf(fin, "%d %d %d", &c, &a, &b);
        if(c == 0)
        {
            maxim = 0;
            parcurgere(1, 1, n, a, b);
            fprintf(fout, "%d\n", maxim);
        }
        else
        {
            actualizare(1, 1, n, b, a);
        }
        m--;
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
