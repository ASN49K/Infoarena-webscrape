#include <fstream>
#include <cmath>

using namespace std;

ifstream cin ("arbint.in");
ofstream cout ("arbint.out");

const int NMAX = 1e5;
const int SQRTNMAX = 317;
const int INT_MIN = 0;

int buckets[SQRTNMAX + 2][SQRTNMAX + 2];
int max_interv[SQRTNMAX + 2];

int n, q, sqrtn;

void citire(){
    cin >> n >> q;
    sqrtn = sqrt(n);

    for (int i = 1; i <= n; ++i){
        int ind_bucket = (i - 1) / sqrtn + 1;
        int pos = (i - 1) % sqrtn + 1;
        cin >> buckets[ind_bucket][pos];
    }
}

void update_interv(int ind_bucket){
    max_interv[ind_bucket] = INT_MIN;
    for (int pos = 1; pos <= sqrtn and ((ind_bucket - 1) * sqrtn + pos <= n); ++pos){
        int x = buckets[ind_bucket][pos];
        max_interv[ind_bucket] = max(max_interv[ind_bucket], x);
    }
}

void update_pos(int i, int val){
    int ind_bucket = (i - 1) / sqrtn + 1;
    int pos = (i - 1) % sqrtn + 1;
    buckets[ind_bucket][pos] = val;
    update_interv(ind_bucket);
}

int query(int l, int r){
    int ans = INT_MIN;

    for (int i = l; i <= r; ++i){
        int ind_bucket = (i - 1) / sqrtn + 1;
        int pos = (i - 1) % sqrtn + 1;
        bool am_comparat = false;
        if (pos == 1){
            if (ind_bucket == sqrtn + 1){   // ultimul bucket, care e mai scurt de sqrtn
                if (r == n){
                    ans = max(ans, max_interv[ind_bucket]);
                    break;
                }
            } else if (i + sqrtn <= r){     // orice alte bucket-uri au lungimea sqrtn
                ans = max(ans, max_interv[ind_bucket]);
                am_comparat = true;
                i += sqrtn - 1;             // -1 pentru ca for-ul adauga 1 la iteratia urmatoare
            }
        } 
        if (! am_comparat){
            int x = buckets[ind_bucket][pos];
            ans = max(ans, x);
        }
    }

    return ans;
}

void initializare(){
    for (int i = 1; i <= sqrtn + 1; ++i){
        update_interv(i);
    }
}

void rezolvare(){
    for (int i = 1; i <= q; ++i){
        bool op;
        int a, b;
        cin >> op >> a >> b;
        if (op == 0)
            cout << query(a, b) << '\n';
        else update_pos(a, b);
    }
}

int main(){
    citire();
    initializare();
    rezolvare();
    return 0;
}