#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

const int Nmax = 100005;
const int SqrtMax = sqrt(Nmax);

int n, q, marime_bucket;
int v[Nmax], bucket[SqrtMax];

void citire_sir(){
    fin >> n >> q;

    marime_bucket = sqrt(n);
    for(int i = 0; i < n; i++){
        fin >> v[i];
        bucket[i / marime_bucket] = max(bucket[i / marime_bucket], v[i]);
    }
}

void update(int poz, int val){
    int capat_st, capat_dr, nr_bucket;

    nr_bucket = poz / marime_bucket;
    capat_st = marime_bucket * nr_bucket;
    capat_dr = marime_bucket * (nr_bucket + 1) - 1;

    v[poz] = val;
    bucket[nr_bucket] = 0;

    for(int i = capat_st; i <= capat_dr; i++){
        bucket[nr_bucket] = max(bucket[nr_bucket], v[i]);
    }
}

int query(int start, int finish){
    int sol, capat_dr, bucket_start, capat_st, bucket_finish;

    bucket_start = start / marime_bucket;
    bucket_finish = finish / marime_bucket;

    capat_dr = marime_bucket * (bucket_start + 1) - 1;
    capat_st = marime_bucket * bucket_finish;

    sol = 0;
    if(bucket_start == bucket_finish){
        for(int i = start; i <= finish; i++){
            sol = max(sol, v[i]);
        }
    }
    else{
        for(int i = start; i <= capat_dr; i++){
            sol = max(sol, v[i]);
        }
        for(int i = bucket_start + 1; i < bucket_finish; i++){
            sol = max(sol, bucket[i]);
        }
        for(int i = capat_st; i <= finish; i++){
            sol = max(sol, v[i]);
        }
    }

    return sol;
}

void citire_si_procesare_interogari(){
    int tip, poz, val, start, finish;

    for(int i = 1; i <= q; i++){
        fin >> tip;
        if(tip == 0){
            fin >> start >> finish;

            start--; finish--;
            fout << query(start, finish) << '\n';
        }
        else{
            fin >> poz >> val;

            poz--;
            update(poz, val);
        }
    }
}


int main(){
    citire_sir();
    citire_si_procesare_interogari();

    return 0;
}
