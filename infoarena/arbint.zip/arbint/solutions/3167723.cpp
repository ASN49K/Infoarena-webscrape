#include <bits/stdc++.h>
#include <vector>
#define INF 2e9
using namespace std;
const int nmax=1e5;
vector<int> v(nmax+3);
struct BATOG {
        int bkSize,length;
        vector<int> bat,dir;
        BATOG(int sz=512) {
                bkSize=sz;
                bat.resize(nmax/sz+3);
                dir.resize(nmax/sz+3);
                length=nmax/sz;
        }
        void build(vector<int> &a,int n) {
                for(int i=0; i<n; i++)
                        bat[i/bkSize]=0;
                for(int i=0; i<n; i++)
                        bat[i/bkSize]=max(bat[i/bkSize],v[i]);
        }
        void print() {
                for(int i=0; i<length; i++)
                        cout<<bat[i]<<" ";
        }
        void updatePoz(vector<int> &a,int val,int poz) {
                poz--;
                a[poz]=val;
                dir[poz/bkSize]=1;
        }
        void updateBuckets(vector<int> &a) {
                for(int i=0; i<length; i++) {
                        if(dir[i]) {
                                updateBucket(a,i);
                                dir[i]=0;
                        }
                }
        }
        void updateBucket(vector<int> &a,int bucket) {
                int val=bucket*bkSize,lval=val+bkSize-1;
                bat[bucket]=0;
                for(int i=val; i<=lval; i++)
                        bat[bucket]=max(bat[bucket],a[i]);
        }
        int query(vector<int> &a,int x,int y) {
                x--;
                y--;
                int fBucket=x/bkSize+1,lBucket=y/bkSize-1;
                int fBucketPoz=fBucket*bkSize,lBucketPoz=(lBucket+1)*bkSize-1;
                int rez=0;
                updateBuckets(a);
                if(lBucket-fBucket>=2) {
                        for(int i=x; i<fBucketPoz; i++)
                                rez=max(rez,a[i]);
                        for(int i=lBucketPoz+1; i<=y; i++)
                                rez=max(rez,a[i]);
                        for(int i=fBucket; i<=lBucket; i++)
                                rez=max(rez,bat[i]);
                } else {
                        for(int i=x; i<=y; i++)
                                rez=max(rez,a[i]);
                }
                return rez;
        }
};
int main() {
        ifstream cin("arbint.in");
        ofstream cout("arbint.out");
        BATOG bat(256);
        int n,q,cer,x,y;
        cin>>n>>q;
        for(int i=0; i<n; i++)
                cin>>v[i];
        bat.build(v,n);
        for(int i=1; i<=q; i++) {
                cin>>cer>>x>>y;
                if(cer==1) {
                        bat.updatePoz(v,y,x);
                } else {
                        cout<<bat.query(v,x,y)<<"\n";
                }
        }
        return 0;
}
