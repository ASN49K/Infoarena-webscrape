#include <bits/stdc++.h>
using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

struct mazan{
    int maxim;
} aint[400001];

int v[100001];

mazan join(mazan a, mazan b)
{
    return {max(a.maxim, b.maxim)};
}

void build(int nod, int st, int dr)
{
    if(st == dr)
    {
        aint[nod].maxim = v[st];
        return;
    }
    int mid = (st + dr) / 2;
    build(2 * nod, st, mid);
    build(2 * nod + 1, mid + 1, dr);
    aint[nod] = join(aint[2 * nod], aint[2 * nod + 1]);
}

void update(int nod, int st, int dr, int poz, int val)
{
    if(poz < st || dr < poz)
        return;
    if(st == dr)
    {
        aint[nod].maxim = val;
        return;
    }
    int mid = (st + dr) / 2;
    update(2 * nod, st, mid, poz, val);
    update(2 * nod + 1, mid + 1, dr, poz, val);
    aint[nod] = join(aint[2 * nod], aint[2 * nod + 1]);
}

mazan query(int nod, int st, int dr, int a, int b)
{
    if(b < st || dr < a)
        return {0};
    if(a <= st && dr <= b)
        return aint[nod];
    int mid = (st + dr) / 2;
    return join(query(2 * nod, st, mid, a, b),
                query(2 * nod + 1, mid + 1, dr, a, b));
}

int main()
{
    int n, m, t, a, b;
    in >> n >> m;
    for(int i = 1; i <= n; i++)
        in >> v[i];
    build(1, 1, n);
    for(int i = 1; i <= m; i++)
    {
        in >> t >> a >> b;
        if(t == 0)
            out << query(1, 1, n, a, b).maxim << '\n';
        else
            update(1, 1, n, a, b);
    }
    return 0;
}
