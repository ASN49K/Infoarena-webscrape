#include <bits/stdc++.h>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n,q;
vector<int>v,aint;

void build(int ind,int st,int dr) {
    if (st==dr) {
        aint[ind]=v[st];
        return;
    }
    int mij=(st+dr)/2;
    build(2*ind+1,st,mij);
    build(2*ind+2,mij+1,dr);
    aint[ind]=max(aint[2*ind+1],aint[2*ind+2]);
}

int query(int ind,int st,int dr,int l,int r) {
    if (st>=l && dr<=r) return aint[ind];
    if (dr<l||st>r) return INT_MIN;
    int mij=(st+dr)/2;
    return max(query(2*ind+1,st,mij,l,r),query(2*ind+2,mij+1,dr,l,r));
}

void update(int ind,int st,int dr,int loc,int x) {
    if (st==dr) {
        aint[ind]=x;
        return;
    }
    int mij=(st+dr)/2;
    if (loc<=mij) update(2*ind+1,st,mij,loc,x);
    else update(2*ind+2,mij+1,dr,loc,x);
    aint[ind]=max(aint[2*ind+1],aint[2*ind+2]);
}

int main(){
    fin>>n>>q;
    v.resize(n);
    for (auto &x:v) cin>>x;
    aint.resize(n*4+1);
    build(0,0,n-1);
    int t,l,r;
    while (q--) {
        fin>>t>>l>>r;
        if (t==0) fout<<query(0,0,n-1,l-1,r-1)<<endl;
        else update(0,0,n-1,l-1,r);
    }
    return 0;
}