#include <fstream>
using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
int n,m, tip, a, b, aib[400005];
void update(int pos, int val, int nod=1, int st=1, int dr=n){
    if(st==dr){
        aib[nod]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(pos<=mij)
        update(pos, val, 2*nod, st, mij);
    else
        update(pos, val, 2*nod+1, mij+1, dr);
    aib[nod]=max(aib[2*nod], aib[2*nod+1]);
}
int query(int a, int b, int nod=1, int st=1, int dr=n){
    if(a<=st && dr<=b)
        return aib[nod];
    int mij=(st+dr)/2, mx=0;
    if(a<=mij)
        mx=max(mx, query(a,b, 2*nod, st, mij));
    if(b>mij)
        mx=max(mx, query(a, b, 2*nod+1, mij+1, dr));
    return mx;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n;i++){
        cin>>a;
        update(i, a);
    }
    while(m--){
        cin>>tip>>a>>b;
        if(tip==0)
            cout<<query(a, b)<<'\n';
        else
            update(a,b);
    }
    return 0;
}
