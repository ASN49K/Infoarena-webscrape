#include <bits/stdc++.h>
#define loop(i,a,b) for(int i = a; i <= b; i++)
#define ln '\n'
#define ll long long
#define pb push_back
#define cin f
#define cout g
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");

int n, m, segment_tree[400001], a[100001], t, x, y;

void build(int node, int left, int right){
    if(left == right){
        segment_tree[node] = a[left];
    }
    else{
        int middle = (left + right) / 2;
        build(node * 2, left, middle);
        build(node * 2 + 1, middle + 1, right);

        segment_tree[node] = max(segment_tree[2 * node], segment_tree[2 * node + 1]);
    }
}

void update(int node, int left, int right, int position, int new_value){
    if(left == right)segment_tree[node] = new_value;
    else{
        int middle = (left + right) / 2;
        if(position <= middle)
            update(node * 2, left, middle, position, new_value);
        else
            update(node * 2 + 1, middle + 1, right, position, new_value);
        
        segment_tree[node] = max(segment_tree[node * 2], segment_tree[node * 2 + 1]);
    }
}

int query(int node, int left, int right, int query_left, int query_right){
    if(query_left <= left && right <= query_right){
        return segment_tree[node];
    }
    else{
        int middle = (left + right) / 2;
        if(query_right <= middle)
            return query(node * 2, left, middle, query_left, query_right);
        if(middle + 1 <= query_left)
            return query(node * 2 + 1, middle + 1, right, query_left, query_right);
        
        return max(query(node * 2, left, middle, query_left, query_right), query(node * 2 + 1, middle + 1, right, query_left, query_right));
    }
}

int main(){
    cin>>n>>m;
    loop(i,1,n)cin>>a[i];
    build(1, 1, n);
    loop(i,1,m){
        cin>>t>>x>>y;
        if(t == 0)cout<<query(1, 1, n, x, y);
        else update(1, 1, n, x, y);
    }
    return 0;
}