#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <climits>

using namespace std;

class SquareRootDecomposition {
private:
    vector<int> arr;
    vector<int> block;
    int blockSize;

public:
    SquareRootDecomposition(const vector<int>& input) {
        arr = input;
        int n = arr.size();
        blockSize = sqrt(n/8);
        block.resize((n + blockSize - 1) / blockSize, INT_MIN);
        
        for (int i = 0; i < n; ++i) {
            block[i / blockSize] = max(block[i / blockSize], arr[i]);
        }
    }

    void update(int idx, int value) {
        arr[idx] = value;
        int blockIdx = idx / blockSize;
        block[blockIdx] = INT_MIN;
        
        for (int i = blockIdx * blockSize; i < min((blockIdx + 1) * blockSize, (int)arr.size()); ++i) {
            block[blockIdx] = max(block[blockIdx], arr[i]);
        }
    }

    int query(int L, int R) {
        int maxVal = INT_MIN;
        int startBlock = L / blockSize;
        int endBlock = R / blockSize;

        if (startBlock == endBlock) {
            for (int i = L; i <= R; ++i) {
                maxVal = max(maxVal, arr[i]);
            }
        } else {
            for (int i = L; i < (startBlock + 1) * blockSize; ++i) {
                maxVal = max(maxVal, arr[i]);
            }
            for (int i = startBlock + 1; i < endBlock; ++i) {
                maxVal = max(maxVal, block[i]);
            }
            for (int i = endBlock * blockSize; i <= R; ++i) {
                maxVal = max(maxVal, arr[i]);
            }
        }
        return maxVal;
    }
};

int main() {
    ifstream fin("arbint.in");
    ofstream fout("arbint.out");

    int N, M;
    fin >> N >> M;

    vector<int> arr(N);
    for (int i = 0; i < N; ++i) {
        fin >> arr[i];
    }

    SquareRootDecomposition sqrtDecomp(arr);

    for (int i = 0; i < M; ++i) {
        int type, a, b;
        fin >> type >> a >> b;
        if (type == 0) {
            fout << sqrtDecomp.query(a - 1, b - 1) << endl;
        } else if (type == 1) {
            sqrtDecomp.update(a - 1, b);
        }
    }

    fin.close();
    fout.close();

    return 0;
}