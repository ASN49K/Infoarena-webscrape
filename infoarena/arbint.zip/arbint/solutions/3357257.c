#include <stdio.h>

#define MAX 100001

int v[MAX];
int arbore[4*MAX];

int max(int a,int b)
{
    if(a>b)
        return a;
    else
        return b;
}

int query(int nod,int st,int dr,int a,int b)
{
    if((a<=st) && (dr<=b))
        return arbore[nod];
    else
    {
        int maxst,maxdr;
        int mij=(st+dr)/2;
        if(a<=mij)
            maxst=query(2*nod,st,mij,a,b);
        if(b>mij)
            maxdr=query(2*nod+1,mij+1,dr,a,b);
        return max(maxst,maxdr);
    }
}

void update(int nod,int st,int dr,int poz,int val)
{
    if(st==dr)
        arbore[nod]=val;
    else
    {
        int mij=(st+dr)/2;
        if(poz<=mij)
            update(2*nod,st,mij,poz,val);
        else
            update(2*nod+1,mij+1,dr,poz,val);
        arbore[nod]=max(arbore[2*nod],arbore[2*nod+1]);
    }
}

int main()
{
    FILE *file = fopen("arbint.in", "r");
    FILE *output = fopen("arbint.out", "w");
    if (file == NULL)
    {
        fprintf(stderr, "Eroare deschidere fisier intrare.\n");
        return 1;
    }
    if (output == NULL)
    {
        fprintf(stderr, "Eroare deschidere fisier iesire.\n");
        fclose(file);
        return 1;
    }
    int n,m;
    fscanf(file,"%d %d",&n,&m);
    for(int i=1;i<=n;i++)
        fscanf(file,"%d",&v[i]);
    for(int i=1;i<=n;i++)
        update(1,1,n,i,v[i]);
    for(int i=1;i<=m;i++)
    {
        int t,a,b;
        fscanf(file,"%d %d %d",&t,&a,&b);
        if(t==1)
        {
            update(1,1,n,a,b);
        }
        if(t==0)
        {
                int r=query(1,1,n,a,b);
                fprintf(output,"%d\n",r);
        }
    }
    fclose(file);
    fclose(output);
    return 0;
}