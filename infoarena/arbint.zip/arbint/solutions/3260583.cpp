#include <bits/stdc++.h>

using namespace std;

int aint[400005], v[100005];

void build(int node, int st, int dr)
{
    if(st == dr)
        aint[node] = v[st];
    else
    {
        int mij = (st + dr) / 2;

        build(2*node, st, mij);
        build(2*node+1, mij+1, dr);

        aint[node] = max(aint[node*2], aint[node*2+1]);
    }
}

void update(int node, int st, int dr, int poz, int val)
{
    if(st == dr)
        aint[node] = val;
    else
    {
        int mij = (st + dr) / 2;

        if(mij < poz)
            update(node*2+1, mij+1, dr, poz, val);
        else
            update(node*2, st, mij, poz, val);

        aint[node] = max(aint[node*2], aint[node*2+1]);
    }
}

int query(int node, int st, int dr, int qst, int qdr)
{
    if(qst <= st && dr <= qdr)
        return aint[node];
    else
    {
        int mij = (st + dr) / 2;

        if(qdr <= mij)
            return query(node*2, st, mij, qst, qdr);
        if(mij + 1 <= qst)
            return query(node*2+1, mij+1, dr, qst, qdr);


        return max(query(node*2, st, mij, qst, qdr), query(node*2+1, mij+1, dr, qst, qdr));
    }
}

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    int n, m;
    cin>>n>>m;

    for(int i=1; i<=n; i++)
        cin>>v[i];

    build(1, 1, n);

    int cer, a, b;
    for(int i=0; i<m; i++)
    {
        cin>>cer>>a>>b;

        if(cer == 0) cout<<query(1, 1, n, a, b)<<'\n';
        else if(cer == 1) update(1, 1, n, a, b);
    }


    return 0;
}
