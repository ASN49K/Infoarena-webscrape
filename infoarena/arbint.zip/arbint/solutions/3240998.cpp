#include "bits/stdc++.h"
#define INF 2e10;
const int DIM = 100000;
int SegTree[2 * DIM + 5], n, q;
inline static void Update(int index, int val){
            index = index + n;
            SegTree[index] = val;
            for(int i = index; i > 1; i = i / 2){
                        SegTree[i / 2] = std  :: max(SegTree[i], SegTree[i ^ 1]);
            }
}
inline static int  Query(int l, int r){
           int res = -INF;
           l = l + n;
           r = r + n + 1;
           while(l < r){
                if(l & 1){
                    res = std :: max(res, SegTree[l++]);
                }
                if(r & 1){
                     res = std :: max(res, SegTree[--r]);
                }
                l = l / 2;
                r = r / 2;
           }
           return res;
}

inline static void Q0(){
        int a, b;
        std :: cin >> a >> b;
        std :: cout << Query(a, b)  << '\n';
}

inline static void Q1(){
         int a, b;
         std :: cin >> a >> b;
         Update(a, b);
}

inline static void Solve(){
            std :: cin >> n >> q;
            for(int i = 1; i <= n; i++){
                        int x;
                        std :: cin >> x;
                        SegTree[n + i] = x;
            }
            for(int i = n - 1; i > 0; i--){
                  SegTree[i] = std :: max(SegTree[2 * i], SegTree[2 * i + 1]);
            }
            while(q --){
                   int op;
                   std :: cin >> op;
                   if(op == 0){
                       Q0();
                   }
                   if(op == 1){
                      Q1();
                   }
            }
}
signed main(){
         freopen("arbint.in","r",stdin);
         freopen("arbint.out","w",stdout);
         std :: ios_base :: sync_with_stdio(false);
         std :: cin.tie(0);
         std :: cout.tie(0);
          Solve();
          return 0;
}
