#include<fstream>
using namespace std;
ifstream F("arbint.in");
ofstream G("arbint.out");
int r[200010],i,n,m,a,b;
bool q;
int main()
{
    for(F>>n>>m;i<n;F>>r[i+n],++i);
    for(i=n-1;i;r[i]=max(r[1<<i],r[(1<<i)+1]),--i);
    for(;m--;)
        if(F>>q,q)
            for(F>>a,a+=n-1,F>>r[a],a>>=1;a;r[a]=max(r[a<<1],r[(a<<1)+1]),a>>=1);
        else {
            for(F>>a>>b,a+=n-1,b+=n-1,i=0;a<=b;i=max(i,max(r[a],r[b])),b=(b-1)/2,a=(a+1)/2);
            G<<i<<'\n';
        }
    return 0;
}
