#include <fstream>

using namespace std;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

int st[400005];
int v[100005];

void update(int nod, int from, int to, int poz, int val)
{
    if(from==to)
    {
        st[nod]=val;
        return;
    }
    int mid=(from+to)/2;
    if(poz<=mid)
    {
        update(nod*2, from, mid, poz, val);
    }
    else
    {
        update(nod*2+1, mid+1, to, poz, val);
    }
    st[nod]=max(st[nod*2], st[nod*2+1]);
}

int query(int nod, int from, int to, int ql, int qr)
{
    int smin=0;
    if(ql<=from && to<=qr)
    {
        return st[nod];
    }
    int mid=(from+to)/2;
    if(ql<=mid)
    {
        int s=query(nod*2, from, mid, ql, qr);
        smin=max(smin, s);
    }
    if(mid+1<=qr)
    {
        int s=query(nod*2+1, mid+1, to, ql, qr);
        smin=max(smin, s);
    }
    return smin;
}

int main()
{
    int n, m, a, x, y;
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
        update(1, 1, n, i, v[i]);
    }
    for(int i=0; i<m; i++)
    {
        cin>>a>>x>>y;
        if(a==1)
        {
            update(1, 1, n, x, y);
        }
        else
        {
            a=query(1, 1, n, x, y);
            cout<<a<<'\n';
        }
    }


    return 0;
}
