#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
#define Nmax 108085
ifstream fin("arbint.in");
ofstream fout("arbint.out");
int aint[281111],v[Nmax],y;
int maxim(int a,int b)
{
    if(a>b)
    {
        return a;
    }
    return b;
}

void build(int nod,int st,int dr)
{
    if(st==dr)
    {
        aint[nod]=v[st];
        return;
    }
    int mij=((st+dr)/2);
    build(2*nod,st,mij);
    build(2*nod+1,mij+1,dr);
    aint[nod]=maxim(aint[2*nod],aint[2*nod+1]);
}

void update(int nod,int st,int dr,int x)
{
    if(st==dr)
    {
        aint[nod]=y;
        return;
    }
    int mij=((st+dr)/2);
    if(x<=mij)
    {
        update(2*nod,st,mij,x);
    }
    else
    {
        update(2*nod+1,mij+1,dr,x);
    }
    aint[nod]=maxim(aint[2*nod],aint[2*nod+1]);
}

int query(int nod,int st,int dr,int x,int y)
{
    if(st==x && y==dr)
    {
        return aint[nod];
    }
    int mij=((st+dr)/2);
    if(y<=mij)
    {
        return query(2*nod,st,mij,x,y);
    }
    else
    {
        if(x>mij)
        {
            return query(2*nod+1,mij+1,dr,x,y);
        }
        else
        {
            return maxim(query(2*nod,st,mij,x,mij),query(2*nod+1,mij+1,dr,mij+1,y));
        }
    }
}

int main()
{
    int n,m,lip,x;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    build(1,1,n);
    while(m--)
    {
        fin>>lip>>x>>y;
        if(!lip)
        {
            fout<<query(1,1,n,x,y)<<'\n';
        }
        else
        {
            update(1,1,n,x);
        }
    }
    return 0;
}
