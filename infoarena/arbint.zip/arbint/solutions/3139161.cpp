#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

struct tree{
    tree* left;
    tree* right;
    long mx;
    long mn;
};

long n, m;
map<long , map<long, tree*> > nodes;

tree* build(long l, long r){
    if(nodes[l][r] != NULL) return nodes[l][r];
    else{
        tree* curt = new tree;
        tree* lt= build(l, r-1);
        tree* rt= build(l+1, r);
        curt->mx = max(lt->mx, rt->mx);
        curt->mn = min(lt->mx, rt->mx);
        lt->right = curt;
        rt->left = curt;
        nodes[l][r]=curt;
        return curt;
    }
}


void update(tree* curnod, long rep, long repx){
    if(curnod->mx == repx){
        long mxs = curnod->mx;
        curnod->mx = max(rep, curnod->mn);
        curnod->mn = min(rep, curnod->mn);
        if(curnod->right != NULL) update(curnod->right, curnod->mx, mxs);
        if(curnod->left != NULL) update(curnod->left, curnod->mx, mxs);
    }
    else if(curnod->mn == repx){
        long mxs = curnod->mx;
        curnod->mx = max(rep, curnod->mx);
        curnod->mn = min(rep, curnod->mx);
        if(curnod->right != NULL) update(curnod->right, curnod->mx, mxs);
        if(curnod->left != NULL) update(curnod->left, curnod->mx, mxs);
    }
}

int main()
{
    fin>>n>>m;
    for(long i=1;i<=n;i++){
        nodes[i][i] = new tree;
        fin>>nodes[i][i]->mx;
        nodes[i][i]->mn = nodes[i][i]->mx;
    }
    build(1, n);
    int q, l, r;
    for(long i=1;i<=m;i++){
        fin>>q>>l>>r;
        if(q==0) fout<<nodes[l][r]->mx<<'\n';
        else if(q==1){
            tree* curnod=nodes[l][l];
            long mxs = curnod->mx;
            curnod->mn = r;
            curnod->mx = r;
            if(curnod->right != NULL) update(curnod->right, r, mxs);
            if(curnod->left != NULL) update(curnod->left, r, mxs);
        }
    }
    return 0;
}
