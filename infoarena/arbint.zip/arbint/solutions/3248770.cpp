#include <fstream>
#include <cmath>
#include <climits>
#define NMAX 100002
using namespace std;
ifstream  fin("arbint.in");
ofstream fout("arbint.out");
int N,M,r,tip,x,y,st,dr,poz,val,vmax,v[NMAX],sq[1002],f[1002];

void citire()
{
    fin>>N>>M;
    r=(int)sqrt(N);

    for(int i=1; i<=N; i++)
    {
        fin>>v[i];
        sq[i/r]=INT_MIN;
    }
}

void pre_calculare()
{
    for(int i=1; i<=N; i++)
    {
        sq[i/r]=max(sq[i/r],v[i]);
    }
}

int main()
{
    citire();

    pre_calculare();

    for(int i=1; i<=M; i++)
    {
        fin>>tip>>x>>y;
        vmax=INT_MIN;

        if(tip==0)
        {
            st=x;
            dr=y;

            while(st<=dr && st%r)
            {
                vmax=max(vmax,v[st]);
                st++;
            }

            while(st+r<=dr)
            {
                if(f[st/r])
                {
                    poz=st/r;
                    val=INT_MIN;
                    for(int j=poz*r; j<(poz+1)*r; j++)
                    {
                        val=max(val,v[j]);
                    }
                    sq[poz]=val;
                    f[x/r]=0;
                }

                vmax=max(vmax,sq[st/r]);
                st+=r;
            }

            while(st<=dr)
            {
                vmax=max(vmax,v[st]);
                st++;
            }

            fout<< vmax << "\n";
        }
        else
        {
            v[x]=y;
            f[x/r]=1;
        }
    }

    return 0;
}
