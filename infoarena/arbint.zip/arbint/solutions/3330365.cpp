#include <fstream>

using namespace std;
const int MAX=1e6;
int n,m,a[MAX+5],tree[4*MAX+5],i,l,r;
bool t;

ifstream cin("arbint.in");
ofstream cout("arbint.out");

void Buildtree(int tree[],int node,int left_now,int right_now){
    if(left_now==right_now){
        tree[node]=a[left_now];
    }
    else{
        int mid=(left_now+right_now)/2;
        Buildtree(tree,2*node,left_now,mid);
        Buildtree(tree,2*node+1,mid+1,right_now);
        tree[node]=max(tree[2*node],tree[2*node+1]);
    }
}
int Query(int node,int node_left,int node_right,int l,int r){
if(l>r){
    return 0;
}
if(l==node_left && r==node_right){
    return tree[node];
}
int mid=(node_left+node_right)/2;
return max(Query(2*node,node_left,mid,l,min(r,mid)),Query(2*node+1,mid+1,node_right,max(l,mid+1),r));
}

void Update(int node,int node_left,int node_right,int pos,int val){
if(node_left==node_right){
    tree[node]=val;
}
else{
    int mid=(node_right+node_left)/2;
    if(pos<=mid){
        Update(2*node,node_left,mid,pos,val);
    }
    else{
        Update(2*node+1,mid+1,node_right,pos,val);
    }
    tree[node]=max(tree[2*node],tree[2*node+1]);
}
}




int main()
{
    cin>>n>>m;
    for(i=1;i<=n;i++){
        cin>>a[i];
    }
    Buildtree(tree,1,1,n);
    while(m--){
        cin>>t>>l>>r;
        /*tip 0*/if(!t){
            cout<<Query(1,1,n,l,r)<<"\n";
        }
        /*tip 1*/else{
            Update(1,1,n,l,r);
        }


    }
}
