#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
const int NMAX=1e5;
int aint[4*NMAX+3];

void update(int root,int st,int dr,int idx,int val)
{
    if(st==dr)
    {
        aint[root]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(idx<=mij)
        update(root*2,st,mij,idx,val);
    else
        update(root*2+1,mij+1,dr,idx,val);
    aint[root]=max(aint[root*2],aint[root*2+1]);

}

int query(int root,int st,int dr,int sti,int dri)
{
    if(st==sti and dr==dri)
        return aint[root];
    int mij=(st+dr)/2;
    if(dri<=mij)
        return query(root*2,st,mij,sti,dri);
    if(sti>mij)
        return query(root*2+1,mij+1,dr,sti,dri);
    return max(
               query(root*2,st,mij,sti,mij),
               query(root*2+1,mij+1,dr,mij+1,dri)
           );
}


int main()
{
    int n,m,x;
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        update(1,1,n,i,x);
    }
    for(int k=1; k<=m; k++)
    {
        int cer,a,b;
        cin>>cer>>a>>b;
        if(cer==0)
            cout<<query(1,1,n,a,b)<<'\n';
        else
            update(1,1,n,a,b);
    }
    return 0;
}
