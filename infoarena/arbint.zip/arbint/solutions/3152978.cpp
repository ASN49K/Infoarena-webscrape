#include <fstream>

using namespace std;
ifstream cin("arbint.in");
ofstream cout("arbint.out");
const int Nmax=100005;
int v[Nmax];
int arb[4*Nmax];
void build(int a,int b,int nod)
{
    if(a==b)
    {
        arb[nod]=v[a];
    }
    else
    {
        int mij=(a+b)/2;
        build(a,mij,2*nod);
        build(mij+1,b,2*nod+1);
        arb[nod]=max(arb[2*nod],arb[2*nod+1]);
    }
    return;
}
void update(int st,int dr, int poz, int val, int nod)
{
    if(st==dr)
    {
        arb[nod]=val;
    }
    else
    {
        int mij=(st+dr)/2;
        if(poz<=mij)
        {
            update(st,mij,poz,val,2*nod);
        }
        else
        {
            update(mij+1,dr,poz,val,2*nod+1);
        }
        arb[nod]=max(arb[2*nod],arb[2*nod+1]);
    }
}
int query(int st,int dr, int a,int b, int nod)
{
    if(a<=st && b>=dr)
    {
        return arb[nod];
    }
    else
    {
        int mij=(st+dr)/2;
        if(b<=mij)
        {
            return query(st,mij,a,b,2*nod);
        }
        if(a>mij)
        {
            return query(mij+1,dr,a,b,2*nod+1);
        }
        return max(query(st,mij,a,b,2*nod),query(mij+1,dr,a,b,2*nod+1));
    }
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
    }
    build(1,n,1);
    int c,a,b;
    for(int i=1;i<=m;i++)
    {
        cin>>c>>a>>b;
        if(c==0)
        {
            cout<<query(1,n,a,b,1)<<'\n';
        }
        if(c==1)
        {
            update(1,n,a,b,1);
        }
    }
    return 0;
}
