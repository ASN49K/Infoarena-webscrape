#include <bits/stdc++.h>

using namespace std;
ifstream fin("aint.in");
ofstream fout("aint.out");
int n, m;
int aint[100005];
void baint(int st, int dr, int od)
{
    if(st==dr)
    {
        cin >> aint[od];
        return;
    }
    int mij=(st+dr) >> 1;
    baint(st, mij, od*2);
    baint(mij+1, dr, od*2+1);
    aint[od]=max(aint[od*2], aint[od*2+1]);
}
void updaint(int st, int dr, int od, int pos, int val)
{
    if(st==dr)
    {
        aint[od]=val;
        return;
    }
    int mij=(st+dr) >> 1;
    if(pos <= mij)
        updaint(st, mij, od*2, pos, val);
    else
        updaint(mij+1, dr, od*2+1, pos, val);
    aint[od]=max(aint[od*2], aint[od*2+1]);
}
int query(int st, int dr, int od, int x, int y)
{
    if(x<=st && dr <= y)
        return aint[od];
    int mij=(st+dr) >> 1;
    int ans=-1;
    if(x<=mij)
        ans=max(ans, query(st, mij, od*2, x, y));
    if(mij+1<=y)
        ans=max(ans, query(mij+1, dr, od*2+1, x, y));
    return ans;
}
int main()
{
    cin >> n >> m;
    baint(1, n, 1);
    while(m--)
    {
        int op, x, y;
        cin >> op >> x >> y;
        if(op==1)
            updaint(1, n, 1, x, y);
        else
            cout << query(1, n, 1, x, y) << '\n';
    }
    return 0;
}
