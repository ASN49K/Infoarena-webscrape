#include <bits/stdc++.h>

using namespace std;

int v[100005], aib[400005];

void build(int node, int st, int dr)
{
    if(st == dr)
        aib[node] = v[st];
    else
    {
        int mij = (st+dr)/2;

        build(2*node, st, mij);
        build(2*node + 1, mij + 1, dr);

        aib[node] = max(aib[node * 2], aib[node * 2 + 1]);
    }
}

void update(int node, int st, int dr, int poz, int value)
{
    if(st == dr)
        aib[node] = value;
    else
    {
        int mij= (st + dr) / 2;

        if(poz <= mij)
            update(2*node, st, mij, poz, value);
        else
            update(2*node + 1, mij + 1, dr, poz, value);

        aib[node] = max(aib[node*2+1], aib[node*2]);
    }
}

int query(int node, int st, int dr, int qst, int qdr)
{
    if(qst <= st && dr <= qdr)
        return aib[node];
    else
    {
        int mij= (st + dr) / 2;

        if(qdr <= mij)
            return query(2*node, st, mij, qst, qdr);
        if(mij + 1 <= qst)
            return query(2*node + 1, mij + 1, dr, qst, qdr);

        return max(query(2*node, st, mij, qst, qdr), query(2*node + 1, mij + 1, dr, qst, qdr));
    }
}

int main()
{
    ifstream cin("arbint.in");
    ofstream cout("arbint.out");
    int n, m, cer, a, b;
    cin>>n>>m;

    for(int i=1; i<=n; i++)
        cin>>v[i];

    build(1, 1, n);

    for(int i=1; i<=m; i++)
    {
        cin>>cer>>a>>b;
        if(cer == 0) cout<<query(1, 1, n, a, b)<<'\n';
        else if(cer == 1) update(1, 1, n, a, b);
    }



    return 0;
}
