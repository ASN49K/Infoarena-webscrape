#include <fstream>
#include<limits.h>
#include<algorithm>

using namespace std;

ifstream in("arbint.in");
ofstream out("arbint.out");

int maximum(int * a, int st, int dr, int L, int R,int index){
    if (st>=L&&dr<=R){
        return a[index];
    }
    else if (dr<L||st>R){
        return INT_MIN;// nu ma pot duce in acest interval
    }
    else{
        int mid=(st+dr)/2;
        return max(maximum(a,st,mid,L,R,2*index),maximum(a,mid+1,dr,L,R,2*index+1));
    }
}

int initializeaza(int * arbore,int index,int lelft,int right, int * a){
    if(lelft==right){
        return arbore[index]=a[lelft];

    }
    else 
    {
        int mid =(lelft+right)/2;
        return arbore[index]=max(initializeaza(arbore,2*index,lelft,mid,a),initializeaza(arbore,2*index+1,mid+1,right,a));
    }
}

void modifica(int * arbore,int index,int value,int L,int R,int pozitie){
    if(pozitie<=R&&pozitie>=L){
        
        if(L!=R){
            int mid=(L+R)/2;
            modifica(arbore,2*index,value,L,mid,pozitie);
            modifica(arbore,2*index+1,value,mid+1,R,pozitie);
            arbore[index]=max(arbore[index*2],arbore[index*2+1]);
        }
        else{
            arbore[index]=value;
        }
    }
    
}

int main(){

int n,m,temp,x,y;
in>>n>>m;
int* arb=new int[n];
for (int i=0;i<n;i++){
    in>>arb[i];
}
int * arbore=new int[4*n];
initializeaza(arbore,1,0,n-1,arb);

for( int i=0;i<m;i++){
    in>>temp;
    switch(temp){
        case 0:
        {
            in>>x>>y;
            out<<maximum(arbore,0,n-1,x-1,y-1,1)<<'\n';
        }
        break;
        case 1:
        {
            in>>x>>y;
            
            modifica(arbore,1,y,0,n-1,x-1);
            
        }
        break;
    
    }
}
}
