#include <fstream>
#include <vector>
#include <algorithm>

std::ifstream in("arbint.in");
std::ofstream out("arbint.out");

int n, m;
std::vector<int> v;
std::vector<int> w(400000);

void build(int node, int st, int dr){
    if(st == dr){
        w[node] = v[st];
        return;
    }
    int mij = (st + dr) / 2;
    build(2*node, st, mij);
    build(2*node+1, mij+1, dr);
    w[node] = std::max(w[2*node], w[2*node+1]);
}

int query(int node, int st, int dr, int a, int b){
    if(a <= st && dr <= b) return w[node];
    if(a > dr || b < st) return -1e9; // or INT_MIN
    
    int mij = (st+dr) / 2;
    int r1 = query(2*node, st, mij, a, b);
    int r2 = query(2*node+1, mij+1, dr, a, b);
    return std::max(r1, r2);    
}

void update(int node, int st, int dr, int pozA, int pozB){
    //v[pozA] = v[pozB]
    if(st == dr && pozA == st){
        w[node] = v[pozB];
        return;
    } 
    int mij = (st + dr) / 2;
    if(pozA <= mij)
        update(2*node, st, mij, pozA, pozB);
    else
        update(2*node+1, mij+1, dr, pozA, pozB);
    w[node] = std::max(w[2*node], w[2*node+1]);
}

int main(){
    in >> n >> m;
    v.push_back(0);
    for(int i = 0; i<n; i++){
        int x;
        in >> x;
        v.push_back(x);
    }
    
    build(1, 1, n);

    for(int i = 0; i<m; i++){
        int op, st, dr;
        in >> op >> st >> dr;
        if(op == 0){
            //query
            int result = query(1, 1, n, st, dr);
            out << result << std::endl;
        }
        else{
            //update
            update(1, 1, n, st, dr);
        }
    }

    //for(int i = 1; i<=4*n; i++) out << w[i] << ",";
}