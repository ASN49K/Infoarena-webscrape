#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, m;
int v[11], a[11];

void afis()
{
    for(int i=1; i<=m; i++)
        g<<v[i]<<" ";
    g<<'\n';
}

int bkt(int x)
{
    for(int i=x; i<=n; i++)
        if(a[i]==0 && v[x-1]<i)
    {
        v[x]=i;
        a[i]=1;
        if(x==m)
            afis();
        else
            bkt(x+1);
        a[i]=0;
    }
}

int main()
{
    f>>n>>m;
    bkt(1);
}
