#include <bits/stdc++.h>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");

vector<int> v;

void comb(int n, int k)
{
    v.resize(k);
    int i;
    i=0;
    v[i]=0;
    while(i>=0)
    {
        while(v[i]<n)
        {
            v[i]++;
            if(i==k-1)
            {
                for(auto a:v)
                    g<<a<<' ';
                g<<'\n';
            }
            else
            {
                i++;
                v[i]=v[i-1];
            }

        }
        i--;
    }
}

int main()
{
    int n, k;
    f>>n>>k;
    comb(n, k);
    f.close();
    g.close();

    return 0;
}
