#include <iostream>
#include <vector>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
vector<bool>folosit;
vector<int>v;
int n,k;
void backtracking(int x){
if(x==k+1){
for(int i=1;i<=k;i++){
    cout<<v[i]<<" ";
}
cout<<'\n';
return;
}
for(int i=v[x-1]+1;i<=n;i++){
    if(folosit[i]==false){
        continue;
    }
   folosit[i]=false;
   v[x]=i;
   backtracking(x+1);
   folosit[i]=true;
}
}
void read(){
cin>>n>>k;
}
void solve(){
read();
v.resize(k+1);
folosit.resize(n+1,true);
backtracking(1);
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int t=1;
    while(t--){
        solve();
    }
    return 0;
}
