#include<fstream>
using namespace std;
ifstream F("combinari.in");
ofstream G("combinari.out");
#define Z 2048
int n,k,q,a[19];
char t[Z];
inline void B()
{
    if(q==Z)
        G.write(t,Z),q=0;
}
void A(int l)
{
    int i;
    if(l==k+1) {
        for(i=1;i<l;a[i]>9?t[q++]=a[i]/10+48,B(),t[q++]=a[i]%10+48:t[q++]=a[i]+48,B(),t[q++]=' ',B(),++i);
        t[q++]='\n',B();
    } else
        for(i=a[l-1]+1;i<=n-k+l;a[l]=i++,A(l+1));
}
int main()
{
    return F>>n>>k,A(1),G.write(t,q),0;
}
