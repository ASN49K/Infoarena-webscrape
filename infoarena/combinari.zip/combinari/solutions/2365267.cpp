#include <iostream>
#include <cstdio>
using namespace std;
FILE *fin, *fout;
const int KMAX = 19;
int sol[KMAX];
int n,k,crestere;
void disp(int v[]){
    for(int i=1;i<=k;i++)
        fprintf(fout,"%d ",v[i]);
    fprintf(fout,"\n");
}
void backtracking(int poz){
    if(poz==k+1)
        disp(sol);
    else{
        for(int val=sol[poz-1]+1;val<=n-k+poz;val++){
            sol[poz]=val;
            backtracking(poz+1);
        }
    }
}
int main()
{
    fin=fopen("combinari.in","r");
    fout=fopen("combinari.out","w");
    fscanf(fin,"%d %d",&n,&k);
    backtracking(1);
    fclose(fin);
    fclose(fout);
    return 0;
}
