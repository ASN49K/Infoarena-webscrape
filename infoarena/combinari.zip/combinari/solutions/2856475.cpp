#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k;

int sol[10], sel[10];

void Back(int level)
{
    if(level == (k + 1)) {
        for(int i = 1; i <= k; ++i)
            fout << sol[i] << " ";
        fout << '\n';
        return;
    }

    for(int i = sol[level - 1] + 1; i <= n; ++i) {
        if(!sel[i]) {
            sel[i] = 1;
            sol[level] = i;
            Back(level + 1);
            sol[level] = 0;
            sel[i] = 0;
        }
    }
    return;
}

int main()
{
    fin >> n >> k;
    Back(1);
    return 0;
}
