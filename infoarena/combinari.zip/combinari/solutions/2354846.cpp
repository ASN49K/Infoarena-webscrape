#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int use[100001],m,n;
void afis (int k)
{
    for(int i=1; i<k; i++) fout<<use[i]<<" ";
    fout<<'\n';
}
void bk(int k)
{
    if(k==m+1) afis(k);
    for(int i=use[k-1]+1; i<=n; i++)
    {
        if(use[k]==0)
        {
            use[k]=i;
            k++;
            bk(k);
            k--;
            use[k]=0;
        }
    }
}
int main()
{
    fin>>n>>m;
    bk(1);
    return 0;
}
