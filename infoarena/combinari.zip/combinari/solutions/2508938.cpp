#include <bits/stdc++.h>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,c[20];
void bkt(int);
int main()
{
    f>>n>>k;
    bkt(1);
    return 0;
}
void bkt(int i)
{
    if(i==k+1)
    {
        for(int j=1;j<=k;j++)
            g<<c[j]<<' ';
        g<<'\n';
        return;
    }
    for(int j=c[i-1]+1;j<=n;j++)
    {
        c[i]=j;
        bkt(i+1);
    }
}
