#include <fstream>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int v[20], n, k;

void afisare(){
    for(int i = 1; i <= k; ++i)
        cout << v[i] << ' ';
    cout << '\n';
}

void bkt(int pas){
    for(int i = v[pas - 1] + 1; i <= n; i++){
        v[pas] = i;
        if(pas == k)
            afisare();
        else
            bkt(pas + 1);
    }
}

int main() {
    cin >> n >> k;
    bkt(1);
    return 0;
}
