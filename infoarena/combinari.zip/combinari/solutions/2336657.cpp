#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int contor,s[50],n,k;

void afisare ()
{
    int i;
    for (i=1;i<=k;++i)
    {
        fout << s[i] << " ";
    }
    fout << '\n';
}

void bacc (int contor)
{
    int i;
    for (i=s[contor-1]+1;i<=n;++i)
    {
        s[contor]=i;
        if (contor==k)
        {
            afisare();
        }
        else
        {
            bacc(contor+1);
        }
    }
}

int main()
{
    fin >> n >> k;
    bacc(1);
    return 0;
}
