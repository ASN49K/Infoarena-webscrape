#include<bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops,inline")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define fast ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define setinf(x) memset(x,0x3f3f3f3f,sizeof(x));
#define set0(x) memset(x,0,sizeof(x));
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define vi vector<int>
#define ll long long
#define vll vector<ll>
#define pb push_back
#define fi first
#define se second
#define DD 100001
#define nl '\n'
using namespace std;
const string file="combinari";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
int n,k;
int x[19],p[19];
void af() {
    for (int i=1; i<=k; ++i)
        g<<x[i]<<' ';
    g<<nl;
}
void becu(int pas) {
    for (int i=x[pas-1]+1; i<=n; ++i) {
        if (!p[i]) {
            x[pas]=i;
            p[i]=1;
            if (pas<k) becu(pas+1);
            else af();
            p[i]=0;
        }
    }
}
int main(){
    f>>n>>k;
    becu(1);
    system("pause");
    return 0;
}
