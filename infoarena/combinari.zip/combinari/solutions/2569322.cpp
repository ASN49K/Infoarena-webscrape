#include <fstream>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int n,k,sol[20];
bool valid (int poz)
{
    for (int i=1;i<poz;i++)
    {
        if (sol[i]>=sol[poz]) return false;
    }
    return true;
}
void bkt(int poz)
{
    if (poz>k)
    {
        for (int i=1;i<=k;i++)
        {
            fout << sol[i] << " ";
        }
        fout << '\n';
    }
    else
    {
        for (int i=1;i<=n;i++)
        {
            sol[poz]=i;
            if (valid(poz)) bkt(poz+1);
        }
    }
}
int main()
{
    fin >> n >> k;
    bkt(1);
}
