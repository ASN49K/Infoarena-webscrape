#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define MOD 1000000007

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef double ld;

ifstream fin("combinari.in");
ofstream fout("combinari.out");


int v[20];

void combinari(int n, int k, int p) {
    if (p == k) {
        for (int i = 1; i <= p; i++) {
            fout << v[i] << " ";
        }
        fout << "\n";
        return;
    }

    for (int i = v[p] + 1; i <= n; i++) {
        v[++p] = i;
        combinari(n, k, p);
        p--;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int n, k;
    fin >> n >> k;
    v[0] = 0;
    combinari(n, k, 0);
    
    return 0;
}