#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
void gC(vector<int>& cC, int cE, int k, int n) {
    if (cC.size() == k) {
        for (int x : cC) {
            fout << x << " ";
        }
        fout << endl;
        return;
    }

    if (cE > n) {
        return;
    }

    cC.push_back(cE);
    gC(cC, cE + 1, k, n);
    cC.pop_back();
    gC(cC, cE + 1, k, n);
}

int main() {
    int n, k;
    fin >> n >> k;
    vector<int> cC;
    gC(cC, 1, k, n);
}
