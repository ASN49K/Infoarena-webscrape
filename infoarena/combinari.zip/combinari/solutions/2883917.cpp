#include <fstream>
#include <map>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,m,sol[20];
bool ap[20];
void back(int k)
{
    if(k>m) return;
    for(int i=sol[k-1]+1;i<=n;i++)
    {
        sol[k]=i;
        if(!ap[i])
        {
            ap[i]=1;
            if(k==m)
            {
                for(int i=1;i<=m;i++)
                    fout << sol[i] << " ";
                fout << "\n";
            }
            else back(k+1);
            ap[i]=0;
        }
    }
}
int main()
{
    fin >> n >> m;
    back(1);
    return 0;
}

