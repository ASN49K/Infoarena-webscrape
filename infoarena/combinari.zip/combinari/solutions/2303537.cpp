#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,m,x[19];
void c(int k,int i)
{
if(k==m+1)
{
    for(int j=1;j<=m;j++)
   fout<<x[i]<<" ";
fout<<endl;
}
else
  for(i=x[k-1]+1;i<=n-m+k;i++)
   {x[k]=i;
   c(k+1,1);
   }
}
int main()
{
    fin>>n>>m;
    c(1,1);
    return 0;
}
