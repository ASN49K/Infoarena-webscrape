#include <iostream>
#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");
int k , n ,sp[19] ;

void afisare()
{
  for(int i=1;i<=k;i++)
  {
    out<<sp[i]<<" ";
  }
  out<<endl;
}



void bac(int x)
{
  if(x>k)
  {
    afisare();
  }
  else
  {
    for(int i=sp[x-1]+1;i<=n;i++)
    {
      sp[x]=i;
      bac(x+1);
    }
  }
}

int main()
{
    in>>n>>k;
    bac(1);
    return 0;
}
