#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, m, sol[20], fr[20];

void afis ()
{
    for (int i=1; i<=m; i++)
        fout << sol[i] << " ";
    fout << '\n';
}

void back (int k)
{
    if (k>m)
        afis();
    else
    {
        for (int i=sol[k-1]+1; i<=n; i++)
        {
            sol[k]=i;
            back(k+1);
        }
    }
}

int main()
{
    fin >> n >> m;
    back(1);
}
