#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

const int N = 19;

int n,p,Sol[N];

bool Check(int k)
{
    for(int i=1;i<k;i++)
        {
            if(Sol[i]>=Sol[k])
                return false;
        }
    return true;
}

void Print()
{
    for(int i=1;i<=p;i++)
            fout<<Sol[i]<<" ";
    fout<<'\n';
}

void Back(int k)
{
    for(int i=1;i<=n;i++)
        {
            Sol[k]=i;
            if(Check(k))
                {
                    if(k==p)
                        Print();
                    else
                        Back(k+1);
                }
        }
}

int main()
{
    fin>>n>>p;
    Back(1);
}
