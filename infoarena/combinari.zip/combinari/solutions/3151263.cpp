#include <iostream>
#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, x[20]; bool p[20];

void afisare() {
  for (int i = 1; i <= k; i++) {
    g << x[i] << ' ';
  }
  g << '\n';
}

bool sortat() {
  for (int i = 1; i < k; i++) {
    if (x[i] > x[i + 1]) return 0;
  }
  return 1;
}

void backtrack(int o) {
  for (int i = (o > 0 ? x[o - 1] + 1 : 1); i <= n; i++) {
    if (!p[i]) {
      x[o] = i;
      p[i] = 1;
      if (o == k) {
        afisare();
      }
      else backtrack(o + 1);
      p[i] = 0;
    }
  }
}

int main() {
  f >> n >> k;
  backtrack(1);
}