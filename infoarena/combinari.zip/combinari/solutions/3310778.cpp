#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");

int main()
{
    int n, k;
    f >> n >> k;
    for (int mask = 1; mask < (1 << n); mask++)
    {
        vector<int> biti;
        for (int bit = 0; bit < n; bit++)
        {
            if ((1 << bit) & mask) /// verific daca bitul bit este 1 in masca
            {
                biti.push_back(bit);
            }
        }
        if (biti.size() == k)
        {
            ///inseamna ca avem o submultime cu k elemente
            for (auto i: biti)
            {
                g << i + 1 << ' ';
            }
            g << '\n';
        }
    }


    return 0;
}
