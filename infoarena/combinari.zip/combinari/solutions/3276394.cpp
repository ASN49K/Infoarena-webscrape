#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,k;
vector<int>v,v2;
void backtracking(int val)
{
    if(val==n+1)
    {
        if(v.size()!=k)
            return ;
        v2=v;
        sort(v2.begin(), v2.end());
        for(int i=0; i<v2.size(); i++)
            cout<<v2[i]<<" ";
        cout<<'\n';
        return ;
    }
    backtracking(val+1);

    v.push_back(val);
    backtracking(val+1);
    v.pop_back();
}
int main()
{
    cin>>n>>k;
    backtracking(1);
    return 0;
}
