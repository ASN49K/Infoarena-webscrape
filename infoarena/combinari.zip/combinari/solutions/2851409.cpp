#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

const int N=19;
int sol[N];

bool ok(int k)
{
    for(int i=1;i<k;i++)
        if(sol[i]>=sol[i+1]) return 0;
    return 1;
}

void afis(int n)
{
    for(int i=1;i<=n;i++)
        out<<sol[i]<<' ';
    out<<'\n';
}
void backtrack(int k,int n,int x)
{
    for(int i=1;i<=n;i++)
    {
        sol[k]=i;

        if(ok(k))
        {
            if(k == x) afis(x);
            else backtrack(k+1,n,x);
        }
    }
}

int main()
{
    int n,k;
    in>>n>>k;

    backtrack(1,n,k);
    return 0;
}
