#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int N,a[20],p;

void type()
{
    for(int i=1;i<=p;i++)g<<a[i]<<" ";
    g<<"\n";
}

void bkt(int k)
{
    if(k==p+1)type();
    else for(a[k]=a[k-1]+1;a[k]<=N-k+p;a[k]++)
        bkt(k+1);
}
int main()
{
    f>>N>>p;
    bkt(1);
    return 0;
}
