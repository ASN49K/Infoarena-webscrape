#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, k, i, x[20];
void afisare()
{
    int i;
    for(i=1; i<=k; i++)
        fout << x[i] << " ";
    fout << "\n";
}

void bkt()
{
     i=1;
     while(i!=0)
     {
         x[i]++;
         if(x[i]>n-k+i)
         {
             x[i]=0;
             i--;
         }
         else

                if(i==k) afisare();
                else {i++; x[i]=x[i-1];}
     }
}
int main()
{
    fin >> n >> k;
    bkt();
    return 0;
}
