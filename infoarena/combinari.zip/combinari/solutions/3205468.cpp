#include <bits/stdc++.h>

using namespace std;

int n, m, v[21];

void afisare()
{
    int i;

    for (i = 1; i <= m; i++)
        cout << v[i] << " ";

    cout << '\n';
}

bool valid(int k)
{
    int i;

    for(i = 1; i < k; i ++)
    {
        if(v[i] == v[k])
            return false;
    }

    return true;
}

void bkt(int k)
{
    int i;

    for (i = v[k - 1] + 1; i <= n; i++)
    {
        v[k] = i;

        if (valid(k))
        {
            if (k == m)
                afisare();

            else
                bkt(k + 1);
        }
    }
}

int main()
{
    cin >> n >> m;

    bkt(1);

    return 0;
}