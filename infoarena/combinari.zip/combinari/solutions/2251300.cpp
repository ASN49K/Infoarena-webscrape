#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, k , st[18];

void Print()
{
    for(int i = 1; i <= k; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back(int top, int i)
{
    if(top == k + 1) Print();
    else for(i = i + 1; i <= n; i++)
    {
        st[top] = i;
        Back(top + 1, i);
    }
}

int main()
{
    fin>>n>>k;
    Back(1, 0);
    return 0;
}
