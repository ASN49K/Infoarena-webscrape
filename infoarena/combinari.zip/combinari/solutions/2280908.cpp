#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int st[20], k, n, m;

void afis(){
    for(int i = 1; i <= k; i++) fout << st[i] << " "; fout << "\n";
}

void bk()
{
    bool isValid = 0;
    k = 1;st[1] = 1;
    while(k > 0){
        isValid = st[k] <= n;
        if(!isValid) k--, st[k]++, st[k + 1] = st[k] + 1;
        else if(k == m) afis(), st[k] ++;
        else k++, st[k] = st[k - 1] + 1;
    }
}

int main()
{
    fin >> n >> m;
    bk();
    return 0;
}
