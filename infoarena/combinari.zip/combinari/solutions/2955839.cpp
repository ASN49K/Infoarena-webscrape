#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

const uint32_t MAX_N = 18;

uint32_t n, k, v[MAX_N];

FILE* fout;

void Backtrack(uint32_t pos) {
    if(pos == k) {
        for(uint32_t i = 0; i < k; ++i)
            fprintf(fout, "%u ", v[i]);
        fprintf(fout, "\n");
    } else {
        uint32_t i = pos ? (v[pos - 1] + 1) : 1;

        for(; i <= n; ++i) {
            v[pos] = i;
            Backtrack(pos + 1);
        }
    }
}

int main() {
    FILE* fin = fopen("combinari.in", "r");
    fout = fopen("combinari.out", "w");

    fscanf(fin, "%u%u", &n, &k);

    Backtrack(0);

    fclose(fin);
    fclose(fout);

    return 0;
}