#include <bits/stdc++.h>
using namespace std;

vector<int> sl(1, 0), vs(20, 0);
void bkt(int n, int k, int s)
{
    if(k < s)
    {
        for(int i = 1; i <= k; i++)
        {
            cout << sl[i] << " ";
        }
        cout << "\n";
    }
    else
    {
        for(int i = 1; i <= n; i++)
        {
            if(vs[i] || (sl.size() && sl.back() > i))
                continue;
            vs[i] = 1;
            sl.push_back(i);
            bkt(n, k, s + 1);
            sl.pop_back();
            vs[i] = 0;
        }
    }
}

int main()
{
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, k;
    cin >> n >> k;
    bkt(n, k, 1);
}