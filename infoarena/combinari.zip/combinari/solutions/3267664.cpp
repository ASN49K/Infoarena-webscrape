#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

#define cin fin
#define cout fout

int n, k;
int x[20];

bool ok(int p) {
    if (p == 1) {
        return true;
    }
    if (x[p] > x[p-1]) {
        return true;
    }
    return false;
}

void back(int p) {
    for(int i = 1; i <= n; i++) {
        x[p] = i;
        if (ok(p)) {
            if (p == k) {
                for(int j = 1; j <= k; j++) {
                    cout << x[j] << " ";
                }
                cout << "\n";
            } else {
                back(p+1);
            }
        }
    }
}

int main()
{
    cin >> n >> k;
    back(1);
    return 0;
}
