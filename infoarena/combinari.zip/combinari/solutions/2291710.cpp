#include <bits/stdc++.h>
 
using namespace std;
 
ifstream in("combinari.in");
ofstream out("combinari.out");

int n, k;
vector< int > v(20);
vector< bool > viz(20, false);

void bkt(int poz, int start) {
    if(poz == k) {
        for(int i = 0; i < k; ++i) {
            out << v[i] << " ";
        }
        out << "\n";

        return;
    } else {
        for(int i = start; i <= n; ++i) {
            if(!viz[i]) {
                v[poz] = i;

                viz[i] = true;
                bkt(poz + 1, i + 1);
                viz[i] = false;
            }
        }
    }
}
 
int main() {
    ios::sync_with_stdio(false); in.tie(0); out.tie(0);
    
    in >> n >> k;

    bkt(0, 1);
 
    in.close(); out.close();
 
    return 0;
}