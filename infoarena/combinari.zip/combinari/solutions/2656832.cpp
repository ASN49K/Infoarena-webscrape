#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,h,minim=9999999,maxim,poz1,poz2,m;
int fr[17],rez[100],v[11];
void afis()
{
    for(int i=1; i<=m; i++)
        g<<rez[i]<<" ";
    g<<'\n';
}
void perm(int k)
{
    if(k==m+1)
    {
        afis();
        return;
    }
    for(int i=rez[k-1]+1; i<=n; i++)
        {
            if(fr[i]==0)
            {
                rez[k]=i;
                fr[i]=1;
                perm(k+1);
                fr[i]--;
                rez[k]=0;
            }

        }

}

int main()
{
    f>>n>>m;
    perm(1);
    return 0;
}
