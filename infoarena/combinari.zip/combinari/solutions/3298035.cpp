#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");


int n,i,j,v[20],k;

void afis()
{
    for (int i=1; i<=k; i++)
        fout<<v[i]<<" ";
    fout<<"\n";
}

void bkt(int pas)
{
    for (int i=v[pas-1]+1; i<=n-k+pas; i++)
    {
        v[pas]=i;

        if (pas<k)
            bkt(pas+1);
        else
            afis();
    }
}


int main()
{
    fin>>n>>k;

    bkt(1);
    return 0;
}
