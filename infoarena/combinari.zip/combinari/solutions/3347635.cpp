#include <fstream>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int ans[20];

void backtrack(int pas, int target, int last, int n){
    if(last > n)
        return;
    if(pas == target){
        for(int i = 0; i < target; i++)
            fout << ans[i] << " ";
        fout << "\n";
        return;
    }

    for(int i = last + 1; i <= n; i++){
        ans[pas] = i;

        backtrack(pas + 1, target, i, n);
    }
}

int main(){
    int n, m, ind = 0;
    fin >> n >> m;

    backtrack(0, m, 0, n);
}