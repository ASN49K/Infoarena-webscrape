#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, m;
int x[20], fr[50], v[20];

void afisare (int k) {
    for(int i = 1; i <= k; ++i)
        fout << x[i] << " ";
    fout << '\n';
}

bool ok (int i, int k) {
    if(fr[i] != 1) return false;
    if(x[k] <= x[k-1]) return false;
    return true;
}

void bk (int k) {
    for(int i = 1; i <= n; ++i) {
        x[k] = i; fr[i] += 1;
        if(ok(i, k)) {
            if(k == m)
                afisare(k);
            else
                bk(k+1);
        }
        fr[i] -= 1;
    }
}

int main()
{
    fin >> n >> m;

    bk(1);

    return 0;
}
