#include <iostream>
#include <fstream>
using namespace std;
int v[18];

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void bkt(int n,int k,int p){
    for(int i=1;i<=n;i++){
        v[p]=i;
        if(p>0 && v[p]>v[p-1]){
            if(p==k-1){
                for(int j=0;j<k;j++) fout<<v[j]<<" ";
                fout<<endl;
            }else{
                bkt(n,k,p+1);
            }
        }else{
            if(p==0) bkt(n,k,p+1);
        }
    }
}

int main()
{
    int n,k;

    fin>>n>>k;
    bkt(n,k,0);
    return 0;
}
