#include <iostream>
#include <fstream>

using namespace std;

ifstream fi("combinari.in");
ofstream fo("combinari.out");

int n,k;
int v[19];

int verif(int t)
{
    if(t>=2)
        if(v[t]<v[t-1])
            return 0;

    for(int i=1;i<t;i++)
        if(v[i]==v[t])
            return 0;

    return 1;
}

int sol(int t)
{
    return t==k;
}

void afis(int t)
{
    for(int i=1;i<=t;i++)
        fo<<v[i]<<" ";
    fo<<'\n';
}

void bkt()
{
    int t=1;
    v[t]=0;

    while(t>=1)
        if(v[t]<n){
            v[t]++;
        if(verif(t))
            if(sol(t))
                afis(t);
            else
            {
                t++;
                v[t]=0;
            }
        }
        else
            t--;
}

int main()
{
    fi>>n>>k;

    bkt();

    return 0;
}
