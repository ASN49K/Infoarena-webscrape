#include <iostream>
#include <fstream>
using namespace std;

int N,K,c,v[18],i,nr,ok;

ifstream f("combinari.in");
ofstream g("combinari.out");
int valid(int a)
{
    for(i=1; i<a; i++)
        if(v[i]==v[a])
            return 0;
        return 1;
}
int solutie(int a)
{
    if(a==K)
        return 1;
        return 0;
}

void afisare()
{

    for(i=1; i<=K; i++)
        g<<v[i]<<" ";
        g<<"\n";

}


int main()
{ c=1;
    f>>N>>K;


    do{
        do
            v[c]++;

        while(valid(c)==0);


  if(v[c]<=N)
        {

            if(solutie(c))
             afisare();



             else
                    c++;
        }
else
{   v[c]--;
    int cN=N;
    while (v[c]==cN)
    {
        v[c]=v[c-1]+1;
        c--;
        cN--;
    }


}



    } while(c>0);







    return 0;
}
