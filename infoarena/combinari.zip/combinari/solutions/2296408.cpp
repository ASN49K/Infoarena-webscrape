#include <fstream>
#include <vector>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

vector <int> comb;

void afis(int k)
{
    for(int i=1;i<=k;++i)
        g<<comb[i]<<' ';
    g<<'\n';
}

void combinari(int n, int k)
{
    comb.resize(k+1);
    int niv=1;
    comb[1]=0;
    while(niv>0)
    {
        if(comb[niv]<n)
        {
            comb[niv]++;
            if(niv<k)
            {
                niv++;
                comb[niv]=comb[niv-1];
            }
            else
            {
                afis(niv);
            }
        }
        else
        {
            comb[niv]=comb[niv-1];
            niv--;
        }
    }
}

int main()
{
    int n,k;
    f>>n>>k;
    combinari(n,k);
    return 0;
}
