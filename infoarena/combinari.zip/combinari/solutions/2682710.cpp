#include<fstream>
using namespace std;
int n,p,x[19];
ifstream f ("combinari.in");
ofstream g("combinari.out");
void afisare(int k)
{
    for(int i=1;i<=k;i++)
        g<<x[i]<<" ";
    g<<endl;
}
void bkt(int k)
{
    for(int i=x[k-1]+1;i<=n;i++)
    {
        x[k]=i;
        if(k==p)
            afisare(k);
        else
            bkt(k+1);
    }
}
int main()
{
    f>>n>>p;    //combinari de n luate cate p
    bkt(1);
}
