#include <cstdio>

int main() {
    int n, m, i, k = 1, st[20] {};
    bool as, ev;
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);
    scanf("%d%d", &n, &m);
    while(k) {
        do {
            as = 0;
            if(st[k] < n) {
                ++st[k];
                as = 1;
            }
            if(as) {
                ev = 1;
                for(i = 1; i < k; ++i)
                    if(st[i] >= st[k])
                        ev = 0;
            }
        } while(as && !ev);
        if(as)
            if(k == m) {
                for(i = 1; i <= m; ++i)
                    printf("%d ", st[i]);
                printf("\n");
            }
            else
                st[++k] = 0;
        else
            --k;
    }
}
