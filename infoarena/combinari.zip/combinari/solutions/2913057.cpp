#include <bits/stdc++.h>
using namespace std;
int n,k,A[19];
ifstream fin("combinari.in");
ofstream fout("combinari.out");

bool valid(int q)
{
    bool check=true;
    for (int i=1;i<q;i++)
    {
        if (A[i]>=A[q])
        {
            check=false;
            break;
        }
    }
    return check;
}

void afisare(int k)
{
    for (int i=1;i<=k;i++)
    {
        fout << A[i] << " ";
    }
    fout << "\n";
}

void combinare(int q)
{
    for (int j=1;j<=n;j++)
    {
        A[q]=j;
        if (valid(q)==true)
        {
            if (q==k) afisare(q);
            else combinare(q+1);
        }
    }
}

int main()
{
    fin >> n >> k;
    combinare(1);
    return 0;
}