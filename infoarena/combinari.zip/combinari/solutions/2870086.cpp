#include <iostream>
#include <fstream>

using namespace std;

const string filename = "combinari";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

int n, p, sol[20];

void afis()
{
    for(int i = 1; i <= p; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void bkt(int k)
{
    for(int i = sol[k - 1] + 1; i <= n; i++)
    {
        sol[k] = i;
        if(k == p)
            afis();
        else
            bkt(k + 1);
    }
}

int main()
{
    fin >> n >> p;
    bkt(1);
    return 0;
}
