#include <iostream>
#include <fstream>
#include <vector>

using std::cin;
using std::cout;

using std::vector;


ifstream in("combinari.in");
ofstream out("combinari.out");

vector<int> v;
int n, k;

void comb(int l = 0) {
	if (l == k) {
		for (auto i : vector<int>(v.begin() + 1, v.end())) {
			out << i << " ";
		}
		out << "\n";
	} else {
		for (int i = v[l] + 1; i <= n; i++) {
			v[l + 1] = i;
			comb(l + 1);
		}
	}
}

int main() {
	in >> n >> k;
	v.resize(k + 1);
	comb();
}