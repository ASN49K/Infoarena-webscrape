#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,k;
int v[20];

void afis(){
  for(int i=1;i<=k;i++){
    fout<<v[i]<<' ';
  }
  fout<<endl;
}


void back(int x)
{
  if(x>k){
    afis();
  }else{
    for(int i=v[x-1]+1;i<=n;i++){
      v[x]=i;
      back(x+1);
    }
  }
}
int main(){

  fin>>n>>k;
  back(1);
}
