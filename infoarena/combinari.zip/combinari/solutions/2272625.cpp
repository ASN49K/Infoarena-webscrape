#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n,x;
int v[20];
int u[20];
void show()
{
    for(int i=1;i<=x;i++) fout<<v[i]<<' ';
    fout<<endl;
}

void bk(int p)
{
    for(int i=v[p-1]+1;i<=n;i++)
       // if(u[i]==0)
        {
          //  u[i]=1;
            v[p]=i;
            if(p==x) show();
            else bk(p+1);
            v[p]=0;
         //   u[i]=0;
        }
}


int main()
{
    fin>>n>>x;
    bk(1);
    return 0;
}
