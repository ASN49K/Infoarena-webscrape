#include <iostream>
#include <fstream>
using namespace std;

int n, k, v[20];
ofstream fout("combinari.out");

void BT(int p, int last) {
    if(p > k) {
        for(int i = 1; i <= k; i++)
            fout << v[i] << (i == k ? '\n' : ' ');
        return;
    }
    for(int i = last + 1; i <= n; i++) {
        v[p] = i;
        BT(p + 1, i);
    }
}

int main() {
    ifstream fin("combinari.in");
    fin >> n >> k;
    BT(1, 0);
    return 0;
}
