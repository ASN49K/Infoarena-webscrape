#include <iostream>
#include <fstream>

using namespace std;

int n,k,v[50];

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void afiseaza() {
    for (int i=1; i<=k; i++)
        fout << v[i] << ' ';
    fout << '\n';
}

void back(int x) {
    for (int i=v[x-1]+1; i<=n; i++){
        v[x] = i;
        if (x==k) afiseaza();
            else back(x+1);
    }
}

int main()
{
    fin >> n >> k;
    back(1);
    return 0;
}
