#include <bits/stdc++.h>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
void afisare();
int n, k, v[20];
void bkt(int i)
{
    if(i == k+1)
        afisare();
    else for(int j=v[i-1]+1; j<=n; j++)
    {
        v[i] = j;
        bkt(i+1);
    }
}
int main()
{
    fin >> n >> k;
    bkt(1);
    return 0;
}
void afisare()
{
    for(int i=1; i<=k; i++)
        fout << v[i] << ' ';
    fout << '\n';
}
