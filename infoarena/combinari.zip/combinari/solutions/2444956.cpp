#include<bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,v[20],k;

void afisare()
{
    for(int i=1;i<=k;i++)
        fout<<v[i]<<" ";
    fout<<"\n";
}

bool OK(int k)
{
    for(int i=1;i<k;i++)
        if(v[i]==v[k])
            return false;
    return true;
}

void back(int p)
{
	for (int i = v[p - 1] + 1; i <= n - k + p; i++)
	{
		v[p] = i;
		if (p == k)
			afisare();
		else
			back(p + 1);
	}
}


int main()
{
    fin>>n>>k;
    back(1);
    return 0;
}
