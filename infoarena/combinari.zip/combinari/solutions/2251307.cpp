#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int st[20],n,p,viz[20];

void Afisare(int k)
{
    int i;
    for(i=1;i<k;i++)
        fout<<st[i]<<" ";
    fout<<"\n";
}

void Backk(int k)
{
    int i;
    if(k == p+1) Afisare(k);
    else for(i=st[k-1]+1;i<=n-p+k;i++)
         {
             st[k] = i;
             Backk(k+1);
         }
}

int main()
{
    fin>>n>>p;
    Backk(1);

    fin.close();
    fout.close();
    return 0;
}
