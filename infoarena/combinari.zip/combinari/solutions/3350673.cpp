// https://infoarena.ro/problema/combinari

#include<fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k;
int comb[19]; // vectorul de solutii/combinari

void BT(int pos) {
	// pos -> pozitia din vectorul de solutie/combinari

	if(pos == k) {
		// am ajuns la o solutie/combinar completa, asa ca o afisam
		for(int i = 0; i < k; i++) {
			fout << comb[i] <<  " ";
		}

		fout << endl;
	}

	// adaugam pe pozitia pos din vectorul de solutie/combinare, cate un element nou
	// adaugam elementele in ordine strict crescatoare, 
	// adica elementul de pe pozitia pos va fi elementul de pe pozitia pos-1, la care adaugam 1
	// daca pos = 0, atunci este primul element, deci vom incepe sa adaugam elemente in vectorul de solutie incepand cu elementul 1 (0+1 = 1)
	int ultimulElement = 0;

	if(pos > 0) {
		ultimulElement = comb[pos-1];
	}

	for(int element = ultimulElement+1; element <= n; element++) {
		// in mod normal, la BT, aici verificam daca solutia este valida
		// insa, cum deja adaugam elemente in ordine strict crescatoare, toate elementele adaugate vor fi valide
		// in cazul in care ultimulElement+1 a depasit n, iar solutia nu e completa, se revine din recursivitate
		comb[pos] = element;

		BT(pos+1);
	}
}

int main() {
	fin >> n >> k;

	BT(0);
	
	fin.close();
	fout.close();

	return 0;
}
