#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
#define cin fin
#define cout fout

#define N 20
int n, k, v[N], f[N];

void afis()
{
    for(int i = 1 ; i <= k ; i++)
    {
        cout << v[i] << " ";
    }
    cout << '\n';
}
void fa(int t, int pr)
{
    for(int i = pr ; i <= n ; i++)
    {
        if(f[i] == 0)
        {
            f[i] = 1;
            v[t] = i;
            if(t == k)afis();
            else fa(t+1,i+1);
            f[i] = 0;
        }
    }
}

int main()
{
    cin >> n >> k;
    fa(1,1);
    return 0;
}
