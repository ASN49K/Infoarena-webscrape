#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int sol[19];

void bkt(int p, int k, int n)
{
    if (p == k)
    {
        for (int i=1; i<=k; i++)
        {
            fout<<sol[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for (int i=sol[p]+1; i<=n; i++)
    {

        sol[p+1] = i;
        bkt(p+1, k, n);

    }
}

int main()
{
    int n, k;
    fin>>n>>k;
    bkt(0, k, n);
    fin.close();
    fout.close();
}
