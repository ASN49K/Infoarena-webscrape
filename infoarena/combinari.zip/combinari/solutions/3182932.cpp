#pragma GCC optimize("Ofast,inline,unroll-loops")
#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,q;
int st[20];
inline void print(){
    for(int i = 1; i <= q; i++) fout << st[i] << " ";
    fout << "\n";
}
void backt(int k){
    if(k == q + 1) print();
    else{
        for(int i = st[k - 1] + 1; i <= n; i++){
            st[k] = i;
            backt(k + 1);
        }
    }
}
int main()
{
    fin >> n >> q;
    backt(1);
    return 0;
}
