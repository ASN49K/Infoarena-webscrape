#include<fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
short int N,K,x[19],i;
void b(short int k)
{
    short int i;
    if(k==K+1) {
        for(i=1;i<=K;++i)
            g<<x[i]<<' ';
        g<<'\n';
    } else
        for(i=x[k-1]+1;i<=N;++i)
            x[k]=i,b(k+1);
}
int main()
{
    f>>N>>K,b(1);
    return 0;
}
