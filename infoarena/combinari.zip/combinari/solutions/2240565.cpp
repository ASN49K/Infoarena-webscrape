#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int n, m;
long int sol[30];
void back(long int k)
{
    if(k == m)
    {
        for (int i = 1; i <= m; ++i)
            fout << sol[i] << ' ';
        fout << endl;
    }
    else {
        for (int i = sol[k] +1 ; i <= n; ++i){

                sol[k+1]= i;
                back(k+1);
        }
    }
}
int main()
{
    fin >> n >> m;
    back(0);
    return 0;
}
