#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
const int MAX_LENGTH = 18;
int n, k, freq[MAX_LENGTH];

void gen(int lg, int sir[MAX_LENGTH]) {
  if (lg == k + 1) {
    for (int i = 1; i <= k; ++i) {
      fout << sir[i] << ' ';
    }
    fout << "\n";
    return;
  }
  for (int i = 1; i <= n; ++i) {
    if (freq[i] == 0 && i > sir[lg - 1]) {
      sir[lg] = i;
      freq[i] = 1;
      gen(lg + 1, sir);
      freq[i] = 0;
    }
  }
}

int main() {
  fin >> n >> k;
  int sir[MAX_LENGTH];
  gen(1, sir);
  return 0;
}
