#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,m;
int x[19];

void AfisareSol()
{
for(int i=1;i<=m;i++) fout<<x[i]<<" ";
fout<<"\n";
}

void Back(int k)
{int i;
for(i=x[k-1]+1;i<=n-m+k;i++)
  {x[k]=i;
   if(k==m) AfisareSol();
   else Back(k+1);
  }
}

int main()
{
    fin>>n>>m;
    Back(1);
    fin.close();
    fout.close();
    return 0;
}
