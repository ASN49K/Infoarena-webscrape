#include <iostream>
#include <fstream>
using namespace std;
ifstream ci ("combinari.in");
ofstream co ("combinari.out");
int n,a[16],m;
int back (int i,int k)
{
    for (int val=k;val<=n;++val)
    {
        a[i]=val;
        if (i<m)
        back(i+1,val+1);
        else
        {
            if (i==m)
            {
                for (int j=1;j<=m;++j)
                co<<a[j]<<" ";
                co<<"\n";
            }
        }
    }
}
int main ()
{
    ci>>n>>m;
    back(1,1);
    return 0;
}
