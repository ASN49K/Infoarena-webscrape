#include<fstream>
#include<vector>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void combinari(int k, int poz, int n, std::vector<int>&c)
{
	if(poz == k+1)
	{
		for(int i = 1; i <= k; i++)
		{
			fout << c[i] << " ";
		}
		fout << "\n";
		return;
	}
	for(int i = c[poz-1] + 1; i <= n; i++)
	{
		c[poz] = i;
		combinari(k, poz+1, n, c);
	}
}

int main()
{
	int n, k;
	fin >> n >> k;

	std::vector<int>c(k+1);
	combinari(k, 1, n, c);

	fin.close();
	fout.close();
	return 0;
}