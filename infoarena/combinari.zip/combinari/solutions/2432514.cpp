#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int v[19],n,k;
void afisare()
{
    for(int l=1;l<=k;l++)
    {
        g<<v[l]<<" ";
    }
    g<<endl;
}
int verificare(int aux, int step)
{
    if(aux==v[step-1])
    {
        return 0;
    }
    return 1;
}
void bk(int s)
{
    for(int i=v[s-1];i<=n;i++)
    {
        if(verificare(i,s))
        {
            v[s]=i;
            if(s==k)
            {
                afisare();
            }
            else
            {
                bk(s+1);
            }
        }
    }
}
int main()
{
    f>>n>>k;
    v[0]=0;
    bk(1);
    return 0;
}
