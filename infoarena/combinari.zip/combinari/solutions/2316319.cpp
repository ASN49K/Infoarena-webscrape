#include <fstream>

using namespace std;

int stiva[19], n, k;
ofstream fout("combinari.out");
void afiseaza()
{
    for(int i=1; i<=k; ++i)
        fout << stiva[i] << ' ';
    fout << '\n';
}

void backtrack(int j)
{
    for(int i=stiva[j-1]+1; i<=n; i++)
    {
        stiva[j] = i;
        if(j==k)
            afiseaza();
        else
            backtrack(j+1);
    }
}

int main()
{
    ifstream fin("combinari.in");
    fin >> n >> k;
    backtrack(1);
    return 0;
}
