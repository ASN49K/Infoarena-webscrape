#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");

void afis(const vector<int> &v)
{
    for (int i = 1; i < v.size(); i++)
    {
        g << v[i] << ' ';
    }
    g << '\n';
}

void backt(int nivel, const int n, const int k, vector<int> &sol)
{
    ///backt(nivel, n ,k , sol) incearca sa gaseasca o posibila valoare pentru indicele nivel, avand vectorul de solutii pana in momentul de fata
    if (nivel == k + 1) /// cand am pus pe toate pozitiile de la 0 la k-1, avem in total k numere
    {
        afis(sol);
        return;
    }
    for (int i = sol[nivel - 1] + 1; i <= n; i++)
    {
        /// daca la nivelul precedent am valoarea 5, nu are sens ca la nivelul curent sa mai incerc valori mai mici de 5
        sol[nivel] = i;
        backt(nivel + 1, n, k, sol);
    }
}

int main()
{
    int n, k;
    f >> n >> k;
    vector<int> sol(k + 1);
    backt(1, n, k, sol);
    return 0;
}
