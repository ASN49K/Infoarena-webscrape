#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int k, n, v[16];

void afisare()
{
    for(int i=1; i<=k; i++)
        fout<<v[i]<<" ";
    fout<<'\n';
}

void bkt(int x)
{
    for(int i=v[x-1]+1; i<=n; i++)
    {
        v[x]=i;
        if(x==k)
            afisare();
        else
            bkt(x+1);
    }
}
int main()
{
    fin>>n>>k;
    bkt(1);
    return 0;
}
