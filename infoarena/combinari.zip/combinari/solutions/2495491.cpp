#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int N, P, v[100];

int solutie(int k){
     if (k == P) return 1;
     return 0;
}

void afisare(int k){
    for (int i = 1; i <= k; i++){
        cout << v[i] << " ";
    }
    cout << "\n";
}

void combinari(int k){
    for (int i = v[k-1]+1; i <= N; i++){
        v[k] = i;
        if (solutie(k)) afisare(k);
        else combinari(k+1);
    }
}

int main(){

ifstream cin("combinari.in");
ofstream cout("combinari.out");

cin >> N >> P;

combinari(1);

return 0;
}
