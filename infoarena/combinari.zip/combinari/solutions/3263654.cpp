#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int perm[100], visited[15];

void backtracking(int posCurenta, int n, int k) {
    if (posCurenta > k) {
        bool xul = 1;
        for (int i = 2; i <= k; ++i) {
            if (perm[i]<=perm[i-1]){
                xul = 0;
                break;
            }
        }
        if (xul==0) return;
        for (int i = 1; i <= k; ++i) {
            fout << perm[i] << " ";
        }
        fout << '\n';
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (visited[i] == 1) continue;

        perm[posCurenta] = i;
        visited[i] = 1;

        backtracking(posCurenta + 1, n, k);

        visited[i] = 0;
        perm[posCurenta] = 0;
    }
}

int main()
{
    int n,k;
    fin >> n >> k;
    backtracking(1, n, k);
    return 0;
}
