#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void printSolution(vector<int> solution) {
    for (int i = 0; i < (int)solution.size(); i++) {
        fout << solution[i] << " ";
    }
    fout << "\n";
}

void backtracking(int start, int stop, vector<int>& domain, vector<int>& solution) {
    if (start == stop) {
        printSolution(solution);
        return;
    }

    int i;
    if (start > 0) {
        i = solution.back();
    } else {
        i = 0;
    }

    for (; i < (int)domain.size(); i++) {
        solution.push_back(domain[i]);
        backtracking(start + 1, stop, domain, solution);
        solution.pop_back();
    }
}

int main() {
    int n, k;
    fin >> n >> k;

    vector<int> domain(n);
    vector<int> solution;

    for (int i = 1; i <= n; i++) {
        domain[i-1] = i;
    }

    backtracking(0, k, domain, solution);

    fin.close();
    fout.close();

    return 0;
}