#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void printSol(vector<int>& sol) {
	for (int i = 0; i < sol.size(); i++)
		fout << sol[i] << " ";
	fout << '\n';
}

bool isOk(vector<int>& sol) {
	for (int i = 1; i < sol.size(); i++) {
		if (sol[i] < sol[i - 1])
			return false;
	}
	return true;
}

void bt(int step, int k, int n, vector<int>& sol, vector<bool>& viz) {
	if (step == k) {
		if (isOk(sol)) {
			printSol(sol);
		}
	}

	for (int i = 1; i <= n; i++) {
		if (!viz[i]) {
			viz[i] = true;
			sol.push_back(i);
			bt(step + 1, k, n, sol, viz);
			sol.pop_back();
			viz[i] = false;
		}
	}
}

int main() {
	int n, k;
	fin >> n >> k;
	vector<int> sol;
	vector<bool> viz(n + 1, 0);
	bt(0, k, n, sol, viz);
}