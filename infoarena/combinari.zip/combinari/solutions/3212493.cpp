#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x << ": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "combinari";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int n, k;
vector<int> ac;

void dfs(int x)
{
    if (ac.size() == k)
    {
        for (auto i : ac)
            fout << i << " ";
        fout << '\n';
        return;
    }
    for (int i = x; i <= n; ++i)
    {
        ac.pb(i);
        dfs(i + 1);
        ac.pop_back();
    }
}

int main()
{
    fin >> n >> k;
    dfs(1);

    return 0;
}