#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("combinari.in");
ofstream g ("combinari.out");

int n,k,a[10],fr[10];

void afisare()
{
    for(int i=1;i<=k;i++)
    {
        g<<a[i]<<" ";
    }
    g<<"\n";
}

bool verificare()
{
    for(int i=1;i<=k;i++)
    {
        fr[i]=0;
    }
    fr[a[1]]++;
    for(int i=2;i<=k;i++)
    {
        fr[a[i]]++;
        if(fr[a[i-1]]>1 || a[i]<=a[i-1])
        {
            return false;
            break;
        }
    }

    return true;
}

void Back(int nivel)
{
    if(nivel==k+1)
    {
        if(verificare()==true)
            afisare();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            a[nivel]=i;
            Back(nivel+1);
        }
    }
}

int main()
{
    f>>n;
    f>>k;
    Back(1);
    return 0;
}
