#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[20];
int n,k;

void bkt(int cnt)
{
    for (int i = v[cnt - 1] + 1;i <= n;i++)
    {
        v[cnt] = i;
        if (cnt == k)
        {
            for (int j = 1;j <= k;j++)
                fout << v[j] << " ";
            fout << '\n';
        }
        else
            bkt(cnt + 1);
    }
}

int main()
{
    fin >> n >> k;
    bkt(1);
    return 0;
}
