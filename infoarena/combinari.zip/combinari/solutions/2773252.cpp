#include <fstream>

using namespace std;

bool validate(int sol[], int i, int n, int k) {
    if (sol[i] <= 0 || sol[i] > n)
        return false;

    for (int j = i - 1; j >= 0; j--) {
        if (sol[j] >= sol[i])
            return false;
    }
    return true;
}

void comb(int n, int k, ofstream &out) {
    int sol[k];
    int i, j;

    for (i = 0; i < k; i++)
        sol[i] = 0;

    i = 0;

    while (i >= 0) {
        bool valid = false;

        while (!valid && sol[i] <= n) {
            sol[i]++;
            valid = validate(sol, i, n, k);
        }

        if (sol[i] <= n) {
            if (i == k - 1) {
                // am gasit o solutie 
                for (j = 0; j < k; j++)
                    out << sol[j] << ' ';
                out << '\n';
            } else {
                // mai am bucati din solutie de format
                ++i;
            }
        } else {
            // revin la pozitiile anterioare din solutie
            sol[i--] = 0;
        }
    }
}

int main(void) {
    ifstream in("combinari.in");
    ofstream out("combinari.out");

    int n, k;
    in >> n >> k;
    comb(n, k, out);

    in.close();
    out.close();
    return 0;
}
