#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int sol[19], n,k;

void bkt(int isol){
    for (int i=sol[isol-1]+1; i<=n; ++i){
        sol[isol]=i;
        //cout<<isol<<' ';
        if (isol==k){
            for (int j=1; j<=k; ++j)
                fout<<sol[j]<<' ';
            fout<<'\n';
        }
        bkt(isol+1);
    }

}

int main(){
    fin>>n>>k;
    sol[0]=0;
    bkt(1);
}








