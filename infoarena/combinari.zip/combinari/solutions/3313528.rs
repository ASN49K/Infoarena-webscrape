use std::fs::File;
#[allow(unused_imports)]
use std::io::{BufRead, BufReader, Read, Write};
use std::{error::Error, vec};

const FILE: &'static str = "combinari";

fn bkt(pas: usize, &n: &usize, &k: &usize, v: &mut Vec<usize>, fout: &mut File) {
    if pas == k {
        for x in v {
            write!(fout, "{} ", x).unwrap();
        }
        write!(fout, "\n").unwrap();
    } else {
        let last = if v.len() > 0 { v[v.len() - 1] } else { 0 };
        for i in last + 1..=n {
            v.push(i);
            bkt(pas + 1, &n, &k, v, fout);
            v.pop();
        }
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut fin = BufReader::new(File::open(format!("{}.in", FILE)).unwrap());
    let mut fout = File::create(format!("{}.out", FILE)).unwrap();

    let mut input = String::new();
    fin.read_line(&mut input)?;

    let [n, k] = input.trim().split_whitespace().map(|x| x.parse::<usize>().unwrap()).collect::<Vec<usize>>()[..] else {
        panic!();
    };

    bkt(0, &n, &k, &mut vec![], &mut fout);

    Ok(())
}
