#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

const int MAXN = 18;
const int MAXK = 18;

int n, m;
int sol[MAXN + 1];

void bck(int k) {
	if (k > m) {
		for (int i = 1; i <= m; ++ i) {
			out << sol[i] << ' ';
		}
		out << '\n';
	}
	else {
		for (int i = sol[k - 1] + 1; i <= n; ++ i) {
			sol[k] = i;
			bck(k + 1);
		}
	}
}

int main() {
	in >> n >> m;
	bck(1);

	return 0;
}