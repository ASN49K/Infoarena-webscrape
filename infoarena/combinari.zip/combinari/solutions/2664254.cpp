#include <bits/stdc++.h>

using namespace std;

ifstream fin( "combinari.in" );
ofstream fout( "combinari.out" );

int N, K;
int a[20];
bool v[20];

void Prnt() {
    for( int i = 1; i <= K; ++i )
        fout << a[i] << ' ';
    fout << '\n';
}

void Backtrack( int p ) {
    for( int i = a[p - 1] + 1; i <= N; ++i )
        if( !v[i] ) {
            a[p] = i;
            v[i] = 1;

            if( p < K ) Backtrack( p + 1 );
            else Prnt();

            v[i] = 0;
        }
}

int main()
{
    fin >> N >> K;

    Backtrack( 1 );


    return 0;
}
