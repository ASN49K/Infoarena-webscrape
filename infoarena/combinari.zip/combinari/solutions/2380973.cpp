#include<iostream>
#include<fstream>
#include<string.h>

using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");


int main(){



char mes[100000];

fin.get(mes,100000);
int cuvant=0;
int litere=0;
int cuv=0;
for(int i=0;i<strlen(mes);i++)
{
    if(!cuvant) {

        if(mes[i]>='a' && mes[i]<='z' || mes[i]>='A' && mes[i]<='Z') {
            cuv++;
            cuvant=1;
            litere++;

        }
    }
    else {

        if((mes[i]>='a' && mes[i]<='z') || (mes[i]>='A' && mes[i]<='Z')) {

            litere++;

        }else {

            cuvant=0;

        }

    }





}

fout<<litere/cuv;


 return 0;
}
