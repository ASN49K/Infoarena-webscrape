#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, l;
int main()
{
    fin >> n;
    fin >> l;
    for (int i = (1<<n) - 1; i >= 1; i--)
    {
        int x = 0;
        int x1 = 0;
        for (int j = 0; (1 << j) <= i; j++)
        {
            x++;
            if (i & (1 << j))
            {
                x1++;
            }
        }
        if (x1 != l)
            continue;
        for (int j = x-1; j >= 0; j--)
        {
            if (i & (1 << j))
            {
                fout << n - j << ' ';
            }
        }
        fout << endl;
    }
    return 0;
}
