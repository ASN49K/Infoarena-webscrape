#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

void generate_combinations(int n, int k, int* current, int current_size, int* remaining, int remaining_size) {
    if (current_size == k) {
        for (int i = 0; i < k; i++) {
            out << current[i] << ' ';
        }
        out << "\n";
        return;
    }
    for (int i = 0; i < remaining_size; i++) {
        if (current_size == 0 || remaining[i] > current[current_size - 1]) {
            current[current_size] = remaining[i];
            int new_remaining_size = remaining_size - i - 1;
            int* new_remaining = new int[new_remaining_size];
            for (int j = i + 1; j < remaining_size; j++) {
                new_remaining[j - i - 1] = remaining[j];
            }
            generate_combinations(n, k, current, current_size + 1, new_remaining, new_remaining_size);
        }
    }
}

int main() {
    int n, k;
    in >> n >> k;
    int elements[n];
    for (int i = 0; i < n; i++) {
        elements[i] = i + 1;
    }
    int current[k];
    int remaining[n];
    for (int i = 0; i < n; i++) {
        remaining[i] = elements[i];
    }
    generate_combinations(n, k, current, 0, remaining, n);
    return 0;
}
