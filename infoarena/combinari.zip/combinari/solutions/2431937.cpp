#include <fstream>

using namespace std;

ifstream in ("combinari.in");
ofstream out ("combinari.out");

int n,k,i,mini=1,v[19];

void bkt(int x)
{
    if(x==k+1)
    {
        for(int i=1;i<=k;i++)
            out << v[i] << " ";
        out << '\n';
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            if(i>v[x-1])
            {
                v[x]=i;
                bkt(x+1);
            }
        }
    }

}

int main()
{
    in >> n >> k;

    bkt(1);

    return 0;
}
