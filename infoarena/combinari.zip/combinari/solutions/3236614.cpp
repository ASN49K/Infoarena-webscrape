#include <fstream>

using namespace std;

const int MAX = 1 << 20;

ofstream outFile("combinari.out", std::ios::binary | std::ios::out | std::ios::trunc);
ifstream fin("combinari.in");

int n, m, k = 1, x[19], c = -1, i;
char s[MAX + 20];

void afis()
{
    outFile.write(s, c + 1);
    c = -1;
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin >> n >> m;
    fin.close();
    while(k > 0)
        if(x[k] < n - m + k)
        {
            ++x[k];
            if(k == m)
            {
                for(i = 1; i < m; i++)
                {
                    if(c >= MAX)
                        afis();
                    if(x[i] > 9)
                        s[++c] = '1', s[++c] = int(x[i] + 38);
                    else
                        s[++c] = int(x[i] + 48);
                    s[++c] = ' ';
                }
                if(c >= MAX)
                    afis();
                if(x[k] > 9)
                    s[++c] = '1', s[++c] = int(x[i] + 38);
                else
                    s[++c] = int(x[i] + 48);
                s[++c] = '\n';
            }
            else
            {
                ++k;
                x[k] = x[k - 1];
            }
            if(c >= MAX)
                afis();
        }
        else
            k--;
    afis();
    return 0;
}
