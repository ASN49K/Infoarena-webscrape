#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,m,c[19];
void afisare()
{
    for(int i=1;i<=m;++i)
        g<<c[i]<<" ";
    g<<'\n';
}
void combinari(int k)
{
    if(k==m+1)
        afisare();
    else
        for(int i=c[k-1]+1;i<=n-m+k;++i)
            {
                c[k]=i;
                combinari(k+1);
            }
}
int main()
{
    f>>n>>m;
    combinari(1);
    return 0;
}
