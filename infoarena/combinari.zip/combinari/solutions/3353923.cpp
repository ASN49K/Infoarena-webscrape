// https://infoarena.ro/problema/combinari

#include<fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

// Descriere algoritm:
// Generez combinarile de n luate cate k folosind metoda backtracking recursiva.
// La fiecare nivel al recursiei, completez solutia cu un numar din multime.
// Solutiile generate nu trebuie sa se repete, adica sa nu generez si solutia (1, 3), dar si solutia (3, 1), 
// deoarece ordinea elementelor din combinari nu conteaza.
// Astfel, la fiecare nivel al recursiei voi adauga in solutie doar elemente mai mari decat elementul anterior al recursiei.
// Soluia este completa daca nivelul curent al recursiei este egal cu k + 1.

// Complexitatea de spatiu este O(n), 
// deoarece utilizez un vector pentru a memora solutiile si datorita stivei utilizarii recursive

// Complexitatea de timp este O(n * C(n, k)):
// - exista n! / k! * (n - k)! = C(n, k) posibilitati de a completa solutia
// - costul pentru fiecare nivel este n

int n, k;
int sol[11];

void generareCombinari(int nivel) {
	if(nivel == k + 1) {
		for(int i = 1; i <= k; i++) {
			fout << sol[i] << " ";
		}

		fout << "\n";

		return;
	}

	for(int i = sol[nivel - 1] + 1; i <= n; i++) {
		// deoarece nivelul incepe de la 1, iar v[0] = o (datorita declararii globale), primul element din solutia va lua valori incepand cu 1
		sol[nivel] = i;

		generareCombinari(nivel + 1);
	}
}

int main() {
	fin >> n >> k;

	generareCombinari(1);

	fin.close();
	fout.close();

	return 0;
}
