#include<fstream>
#include<vector>
#define NMAX 18

//in-out
std::ifstream f("combinari.in");
std::ofstream g("combinari.out");

//data
int n, m;
std::vector<int> sol;

//readData
void readData(){
    f >> n >> m;
}

//backtracking
void bkt(){
    if(sol.size() == m){
        for(const auto& elem : sol){
            g << elem + 1 << ' ';
        }
        g << '\n';
    }
    for(int i = sol.size() > 0 ? sol[sol.size() - 1] + 1 : 0; i<n; i++){
        sol.push_back(i);
        bkt();
        sol.pop_back();
    }
}

int main(){
    readData();
    bkt();
    return 0;
}