#include <iostream>
#include <fstream>
#define NMAX 19

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int a[NMAX], viz[NMAX];
int n, m;

void afisare()
{
	int i;
	for (i = 1; i <= m; i++)
		g << a[i] << ' ';
	g << '\n';
}

void bkt(int k)
{
	int i;
	for (i = 1; i <= n; i++)
		if (!viz[i])
		{
			viz[i] = 1;
			a[k] = i;
			if (a[k-1] < a[k])
				if (k == m)
					afisare();
				else bkt(k+1);
			viz[i] = 0;
		}
}

int main()
{
	f >> n >> m;
	bkt(1);
	f.close();
	g.close();
	return 0;
}
