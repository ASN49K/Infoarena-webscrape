#include <iostream>
#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int k,n,a[20];

void afisare()
{
    for(int i=1;i<=k;i++)
        out<<a[i]<<" ";
    out<<'\n';
}

void back(int z)
{
    if(z>k)
        afisare();
    else
        for(int i=a[z-1]+1;i<=n;i++)
    {
        a[z]=i;
        back(z+1);
    }
}

int main()
{
    in>>n;
    in>>k;
    back(1);
    return 0;
}
