#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, x[10], f[11], m;
void backtracking(int pas)
{
    if(pas==m+1)
    {
        for(int i=1;i<=m;i++)
        {
            fout<<x[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for(int i=x[pas-1]+1; i<=n; i++)
    {
        x[pas]=i;
        backtracking(pas+1);
    }
}

int main()
{
    fin>>n>>m;
    backtracking(1);
    return 0;
}
