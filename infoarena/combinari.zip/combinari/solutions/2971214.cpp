#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, p, x[20];

void afis()
{
    for(int i=1; i<=p; i++)
        fout<<x[i]<<' ';
    fout<<'\n';
}

void btk(int k)
{
    for(int i=x[k-1]+1; i<=n; i++)
    {
        x[k]=i;
        if(k==p)
            afis();
        else btk(k+1);
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);

    fin>>n>>p;

    btk(1);

    fin.close();
    fout.close();

    return 0;
}
