#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;

const int nMax = 20;
const int sq = sqrt(nMax);

int n, k;
vector <int> a;
bool viz[nMax];

void backtracking (int niv)
{
    if (niv == k)
    {
        for (auto i : a)
            cout << i << " ";
        cout << "\n";
    }
    int start = (a.empty() ? 1 : a.back());

    for (int i = start; i <= n; ++i)
        if (viz[i] == false)
        {
            viz[i] = true;
            a.emplace_back(i);
            backtracking (niv + 1);
            a.pop_back();
            viz[i] = false;
        }
}

main()
{
    freopen("combinari.in", "rt", stdin);
    freopen("combinari.out", "wt", stdout);
    cin >> n >> k;
    backtracking(0);
}
