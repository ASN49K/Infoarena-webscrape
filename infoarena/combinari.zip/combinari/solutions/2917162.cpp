#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, k, sir[18];

void gen(int lg, int prev_nr) {
    if (lg == k) {
        for (int i = 0; i < k; ++i) {
            fout << sir[i] << " ";
        }
        fout << "\n";
        return;
    }
    for (int i = prev_nr; i <= n; ++i) {
        sir[lg] = i;
        gen(lg + 1, i + 1);
    }
}

int main() {
    fin >> n >> k;
    gen(0, 1);
}
