#include<fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,m,st[1000],i,k,valid,succesor;
int main()
{
    cin>>n>>m;
    k=1;st[k]=0;
    while(k)
    {
        do{
            succesor=0;valid=1;
            if(st[k]<n)
            {
                st[k]++;succesor=1;
            }
            for(i=1;i<k;i++)
            {
                if(st[k]==st[i])
                    valid=0;
            }
        }while(succesor&&!valid);
        if(succesor)
        {
            if(k==m)
            {
                for(i=1;i<=m;i++)
                {
                    cout<<st[i]<<" ";
                }cout<<endl;
            }
            else
            {
                st[k++]=st[k-1];
            }
        }
        else
        {
            k--;
        }
    }
}
