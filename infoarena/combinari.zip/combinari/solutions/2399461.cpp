#include <iostream>
#include <fstream>

using namespace std;

int n, k, v[30];

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void gback(int nivel, int k)
{
    int i;
    for(i=v[nivel-1]+1;i<=n;i++)
    {
        v[nivel]=i;
        if(nivel==k)
        {
            for(int j=1;j<=k;j++)
                fout<<v[j]<<" ";
            fout<<"\n";
        }
        if(nivel<k)
            gback(nivel+1,k);
    }
}

int main()
{
    fin>>n>>k;
    gback(1,k);
    return 0;
}
