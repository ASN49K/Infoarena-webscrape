#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int n,k;
int perm[20];
bool viz[20];

void solve(int nivel)
{
	if(nivel==k+1)
	{
		for(int i=1;i<=k;i++)
			out<<perm[i]<<" ";
		out<<"\n";
		return;
	}
	for(int i=perm[nivel-1]+1;i<=n;i++)
	{
		if(viz[i]==0)
		{
			viz[i]=1;
			perm[nivel]=i;
			solve(nivel+1);
			viz[i]=0;
		}	
	}
}


int main()
{
	in>>n>>k;
	solve(1);
	return 0;
}
