//#include "stdafx.h"

#include <fstream>

#include <cstdio>

#include <stdio.h>
#include<vector>

using namespace std;



#define min(a,b) (a>b?b:a)

#define max(a,b) (a<b?b:a)




FILE *fin, *fout;

int n,k, a[20];

void printDo(){
    for(int i=1;i<k;++i)
        fprintf(fout, "%d ", a[i]);
    fprintf(fout, "%d\n", a[k]);
}

void back(int l){
    if(l==k+1)
        printDo();
    else{
        for(int i=a[l-1]+1;i<=n-k+l;++i){
            a[l]=i;
            back(l+1);
            }
        }
    }


int main()

    {



    fin=fopen( "combinari.in", "r");

    fout=fopen("combinari.out", "w");

    fscanf(fin,"%d%d",&n, &k);
    back(1);
    //fprintf(fout,"%d", b[0][1]);

    fclose(fin);

    fclose(fout);

    return 0;

    }