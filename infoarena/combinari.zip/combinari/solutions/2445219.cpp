#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int N, K;
int st[20];
bool d[20];

void bk(int nivel, int start)
{
    if(nivel == K + 1)
    {
        for(int i = 1; i <= K; i++)
            fout << st[i] << ' ';

        fout << '\n';
        return;
    }

    for(int i = start; i <= N; i++)
        if(!d[i])
        {
            d[i] = 1;
            st[nivel] = i;
            bk(nivel + 1, i + 1);
            d[i] = 0;
        }
}

int main()
{
    fin >> N >> K;

    bk(1, 1);

    return 0;
}
