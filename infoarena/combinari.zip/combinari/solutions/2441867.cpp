#include <iostream>
#include<string.h>
#include<fstream>
using namespace std;


ifstream fin("combinari.in");
ofstream fout("combinari.out");
int v[100];
int st[100];
int n,m;
void afisare(){

   for(int i=1;i<=m;i++)
      cout<<st[i]<<" ";
   cout<<'\n';

}

void comb(int k,int m) {

   if(k==m+1) afisare();
   else {

      for(int i=st[k-1]+1;i<=n;i++)
      {
         st[k] = i;
         comb(k+1,m);
         st[k]=0;
      }

   }

}


int main()
{

   cin>>n>>m;

   comb(1,m);

    return 0;
}
