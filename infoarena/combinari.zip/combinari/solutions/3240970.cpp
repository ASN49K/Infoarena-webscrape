#include "bits/stdc++.h"
const int DIM = 100;
int v[DIM + 5], stiva[DIM + 5];
int n,sz;
inline static void Print(){
                for(int i = 1; i <= sz; i++){
                        std  :: cout << stiva[i] << ' ';
                }
                std :: cout << '\n';
}
inline static bool Check(int k){
            if(stiva[k] <= stiva[k - 1] and k > 1){
                    return false;
            }
            return true;
}
inline static void Bkt(int k){
             for(int i = 1; i <= n; i++){
                    stiva[k] = i;
                        if(Check(k) == true){
                            if(k == sz){
                                    Print();
                            }else{
                                  Bkt(k + 1);
                            }
                        }
             }
}
inline static void Solve(){
            std :: cin >> n >> sz;
            Bkt(1);
}
signed main(){
      freopen("combinari.in","r",stdin);
      freopen("combinari.out","w",stdout);
      std :: ios_base :: sync_with_stdio(false);
      std :: cin.tie(0);
      std :: cout.tie(0);
       Solve();
      return 0;
}
