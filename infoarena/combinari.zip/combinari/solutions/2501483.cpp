#include <bits/stdc++.h>

using namespace std;

int s[19],n,m;


void afis(int k)
{
    for(int i=1;i<=k;++i)printf("%d ",s[i]);
    printf("\n");
}

void bkt(int k)
{
    if(k == m+1)afis(m);
    else
        for(int i=s[k-1]+1;i<=n;++i)
    {
        s[k]=i;
        bkt(k+1);
    }
}

int main()
{
    freopen("combinari.in","r",stdin);
    freopen("combinari.out","w",stdout);
    scanf("%d %d",&n,&m);
    bkt(1);
    return 0;
}
