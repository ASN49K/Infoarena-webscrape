#include <bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int v[10],st[10],lvl=0,a,k;
void afisare(int lvl){
    for(int i=1; i<=lvl; i++){
        fout<<st[i]<<" ";
    }
    fout<<endl;
}
int NicolaeEconomuEftimieStelian(int lvl){
    for(int i=1; i<=lvl-1; i++){
        if(st[lvl]==st[i]){
            return 0;
        }
    }
    return 1;
}
int NeesCafe(int lvl){
    for(int i=1; i<=lvl-1; i++){
        if(st[i]>st[i+1]){
            return 0;
        }
    }
    return 1;
}
void permutari(int lvl){
    for(int i=1; i<=a; i++){
        st[lvl]=v[i];
        if(NicolaeEconomuEftimieStelian(lvl)==1 && NeesCafe(lvl)==1){
            if(lvl==k){
                afisare(lvl);
            }else{
                permutari(lvl+1);
            }
        }
        
    }

}
int main()
{
    fin>>a>>k;
    for(int i=1; i<=a; i++){
        v[i]=i;
    }
    permutari(1);
    
    

    return 0;
}