#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, x, sol[20], viz[20];

void afisare()
{
    for(int i = 1; i <= x; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void back(int k)
{
    if(k == x + 1)
    {
        afisare();
        return;
    }
    for(int i = sol[k - 1] + 1; i <= n; i++)
        if(!viz[i])
        {
            viz[i] = 1;
            sol[k] = i;
            back(k + 1);
            viz[i] = 0;
        }
}

int main()
{
    fin >> n >> x;
    sol[0] = 0;
    back(1);
    return 0;
}
