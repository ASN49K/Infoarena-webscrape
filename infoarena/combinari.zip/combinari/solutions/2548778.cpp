#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int N,K,v[25];
int b; char s[1312740];

void back(int p)
{
    if(p==K)
    {
        for(int i=1;i<=K;i++)
        {
            if(v[i]<10)
                s[b++]=v[i]+'0';
            else
                s[b++]=v[i]/10+'0', s[b++]=v[i]%10+'0';
            s[b++]=' ';
        }
        s[b++]='\n';
    }
    else
        for(int i=1+v[p];i<=N;i++)
        {
            v[p+1]=i;
            back(p+1);
        }
}
int main()
{

    fin >> N >> K;
    back(0);
    fout << s;

    return 0;

}
