#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, m, c[25];
void Afisare()
{
	for (int i = 1; i <= m; i++)
		fout << c[i] << " ";
	fout << "\n";
}
void Combinari(int k)
{
	if (k - 1 == m)
		Afisare();
	else
		for (int i = c[k - 1] + 1; i <= n - m + k; i++)
		{
			c[k] = i;
			Combinari(k + 1);
		}
}
int main()
{
	fin >> n >> m;
	Combinari(1);
	system("pause");
	return 0;
}