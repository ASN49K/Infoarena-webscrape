#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int  n, k, c[30];

void Comb(int p)
{
    if(p > k)
    {
        for(int i=1; i<=k; i++)
            fout << c[i] << " ";
        fout << "\n";
        return;
    }
    for(int i = c[p - 1] + 1; i <=n; i++)
    {
        c[p] = i;
        Comb(p+1);
    }
}

int main()
{
    fin >> n >> k;
    Comb(1);
    return 0;
}
