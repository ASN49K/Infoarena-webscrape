#include <fstream>
using namespace std;

ifstream fin ("combinari.in");
ofstream fout("combinari.out");

int n,m,v[20];

void chestie(int k){
    for (int i=v[k-1]+1;i<=n-m+k;i++){
        v[k]=i;
        if (k==m){
            for (int j=1;j<=m;j++)
                fout<<v[j]<<" ";
            fout<<"\n";
        }
        else
            chestie(k+1);
    }
}

int main(){
    fin>>n>>m;
    chestie(1);
    fin.close();
    fout.close();
    return 0;
}
