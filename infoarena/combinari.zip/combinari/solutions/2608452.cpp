#include<iostream>
#include<fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,st[21];
void afisare()
{
    for(int i=1;i<=k;i++)
    {
        g<<st[i]<<" ";
    }
    g<<"\n";
}
void bkt(int top, int last)
{
    if(top==k+1)
    {
        afisare();
    }
    else
    {
        for(int i=last+1;i<=n;i++)
            {
                st[top]=i;
                bkt(top+1,i);
            }
    }
}
int main()
{
    f>>n>>k;
    bkt(1,0);
}
