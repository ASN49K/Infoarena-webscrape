/*
    |                _____              ______                         ______               ______  _______
    |      |        /     \   \      /  |               /\     |       |       \   /       /           |        /\     |\   |
    |      |       /       \   \    /   |___           /  \    |       |___     \_/        \_____      |       /  \    | \  |
    |      |       \       /    \  /    |             /____\   |       |        / \              \     |      /____\   |  \ |
    |      |_____   \_____/      \/     |_____       /      \  |_____  |_____  /   \       ______/     |     /      \  |   \|

                                                                                                                                 */


#include <bits/stdc++.h>

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n, k;
int a[20];
void bktr(int p, int st){
    for(int i = st; i <= n; i++){
        a[p] = i;
        if(p == k){
            for(int j = 1; j <= k; j++){
                fout << a[j] << " ";
            }
            fout << "\n";
        }
        else{
            bktr(p + 1, i + 1);
        }
    }
}

int main()
{
    fin >> n >> k;
    bktr(1, 1);
    return 0;
}
