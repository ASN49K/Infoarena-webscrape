#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream  fout("combinari.out");

vector<vector<int>> all;

void backtrack(int n, int k, vector<int>&comb, vector<int>&used, int start) {
    if (comb.size() == k) {
        all.push_back(comb);
        return;
    }

    for (int i = start; i <= n; i++) {
        if (used[i] == 1) continue;

        used[i] == 1;
        comb.push_back(i);
        backtrack(n, k, comb, used, i + 1);

        used[i] = 0;
        comb.pop_back();
    }
}

int main() {
    int n, k;
    fin >> n >> k;

    vector<int> used(n+1, 0);

    vector<int> comb;
    
    backtrack(n, k, comb, used, 1);

    int sz = all.size();

    for (int i = 0; i < sz; i++) {
        int rowsz = all[i].size();
        for (int j = 0; j < rowsz; j++) {
            fout << all[i][j] << " ";
        }
        fout << "\n";
    }



}