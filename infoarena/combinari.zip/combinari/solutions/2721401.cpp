#include <bits/stdc++.h>
using namespace std;

const string FILENAME = "combinari";

ifstream fin(FILENAME + ".in");
ofstream fout(FILENAME + ".out");

int n, k;
int a[18];

void show()
{
    for(int i = 1; i <= k; i++)
        fout << a[i] << "\n";
    fout << "\n";
}

void back(int x)
{
    for(int i = a[x - 1] + 1; i <= n; i++)
    {
        a[x] = i;
        if(x == k)
            show();
        else back(x + 1);

    }
}

int main()
{
    fin >> n >> k;
    back(1);
    fin.close();
    fout.close();
    return 0;
}