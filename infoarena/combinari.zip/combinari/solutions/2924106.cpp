#include <fstream>

using namespace std;
int n,l,v1[20];
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int comb(int k,int st,int v[])
{
    if(k==l)
    {
        for(int j=0;j<l;j++)
            cout << v[j] << " ";
        cout << '\n';
    }
    for(int i=st;i<=n;i++)
    {
        v[k]=i;
        if(k<l)
        {
            comb(k+1,i+1,v);
        }
    }
}
int main()
{
    cin >> n >> l;
    comb(0,1,v1);
    return 0;
}
