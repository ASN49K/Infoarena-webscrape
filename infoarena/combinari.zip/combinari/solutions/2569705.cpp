#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int st[25];
bool viz[25];

void bt(int n,int k,int cnt)
{
    if(cnt == k)
    {
        for(int i = 1; i <= k; i++)
            out << st[i] <<" ";
        out <<'\n';
    }

    for(int i = 1; i <= n; i++)
        if(viz[i] == false && st[cnt] < i)
        {
         viz[i] = true;
         st[cnt + 1] = i;
         bt(n,k,cnt + 1);
         viz[i] = false;
        }
}

int main()
{
    int n, k;
    in >> n >> k;

    bt(n,k,0);

    return 0;
}
