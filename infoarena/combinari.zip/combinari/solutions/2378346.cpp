#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int N, M;
int x[100];


void afis()
{
    for(int i = 1; i <= M; i++)
    {
        fout << x[i] << ' ';
    }

    fout << endl;
}

void Read()
{
    fin >> N >> M;
}


void bk(int k)
{
    if(k > M) afis();
    else
        for(int i = 1; i <= N; i++)
        {
            if(i > x[k - 1])
            {
                x[k] = i;
                bk(k + 1);
            }
        }
}

int main()
{
    Read();

    bk(1);

    return 0;
}




