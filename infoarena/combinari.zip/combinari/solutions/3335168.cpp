#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int perm[18];
bool cif[18];
void permutare(int n , int k, int nr)
{
    int i;
    if(nr==k)
    {
        for(i=0; i<k; i++)
            fout<<perm[i]<<" ";
        fout<<"\n";
    }
    else
    {
        int start;
        if(nr==0)
            start=1;
        else
            start= perm[nr-1]+1;
        for(i=start; i<=n; i++)
        {
            perm[nr]=i;
            permutare(n , k , nr+1);
        }
    }
}
int main()
{
    int n , k;
    fin>>n>>k;
    permutare(n, k, 0);
    return 0;
}
