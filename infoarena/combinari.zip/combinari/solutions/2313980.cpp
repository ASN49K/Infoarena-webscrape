#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

    int n, p, k, i, as, ev;
    int stiva[20];

void succesor()
{   if (stiva[k]<n-p+k)
       {stiva[k]++;
        as=1;}
    else as=0;
}

void valid()
{   ev=1;
    if (k>1 && stiva[k]<=stiva[k-1])  ev=0;
}
void back()
{
    k=1;
    stiva[k]=0;
    while (k>0)
    {
        do {succesor ();
            if (as);
                valid ();}
        while (as && ev==0);

        if (as)
            if (k==p)
            {
                for (i=1; i<=p; i++)
                    fout<<stiva[i]<<" ";
                    fout<<endl;
            }
            else stiva[++k]=0;
       else k--;
    }
}


int main()
{
    fin>>n>>p;
    back();
    return 0;
}
