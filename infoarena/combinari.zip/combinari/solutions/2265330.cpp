#include <fstream>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, m, x[100];

bool validare (int k)
{
    int i;
    if (k == 1)
        return true;
    for (i=1; i<k; i++){
        if (x[k] == x[i])
            return false;
    }
    return true;
}

void afisare (int k)
{
    int i;
    for (i=1; i<=k; i++){
        fout << x[i] << " ";
    }
    fout << "\n";
}

void bkt (int k)
{
    int i;
    for (i=x[k-1]+1; i<=n; i++){
        x[k] = i;
        if (k == m)
            afisare(m);
        else
            bkt(k+1);
    }
}

int main()
{
    fin >> n >> m;
    bkt(1);
    return 0;
}
