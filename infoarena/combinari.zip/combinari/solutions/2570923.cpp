#include <iostream>
#include <fstream>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, sol, v[20];

void bkt(int p)
{   if(p == k+1)
        {   for(int i=1; i<=k; i++) g << v[i] << ' ';
            g << '\n';
        }
    else
        {   for(int i=v[p-1]+1; i<=n; i++)
                {   v[p] = i;
                    bkt(p+1);
                }
        }
}

int main()
{
    f >> n >> k;
    bkt(1);
    return 0;
}
