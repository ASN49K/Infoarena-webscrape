#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

long long n, k, s[20];

void back(int x){
	if(x == k){	
		for(int i = 1; i <= k; ++i){
			fout << s[i] << " ";
		}
		fout << '\n';
	}
	else{
		for(int i = s[x] + 1; i <= n; ++i){
			s[x + 1] = i;
			back(x + 1);
		}
	} 	
}

int main(){
	fin >> n >> k;
	back(0);
}
