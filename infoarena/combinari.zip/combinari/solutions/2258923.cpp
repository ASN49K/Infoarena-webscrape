#include <bits/stdc++.h>

using namespace std;

ifstream in ("combinari.in");
ofstream out ("combinari.out");

int n, s[20], m;

void combinari(int i)
{
    if (i>m)
    {
        for (int j=1; j<=m; j++)
            out << s[j] << " ";
        out << '\n';
    }
    else
        for (int j=s[i-1]+1; j<=n; j++)
        {
            s[i]=j;
            combinari(i+1);
        }
}

int main()
{
    in >> n >> m;
    combinari(1);
    return 0;
}
