#include <fstream>
#define MOD 1999999973
using namespace std;
long long n,p;
long long pow(long long n,long long p)
{
    long long rez=1;
    while(p)
    {
        if(p%2)
        {
            rez=(rez*n)%MOD;
            p--;
        }
        else
        {
            p/=2;
            n=(n*n)%MOD;
        }
    }
    return rez;
}
int main()
{
    ifstream f("lgput.in");
    ofstream g("lgput.out");
    f>>n>>p;
    f.close();
    g<<pow(n,p);
    g.close();
    return 0;
}
