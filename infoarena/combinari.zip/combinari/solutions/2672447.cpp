#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int sol[18],n,k;

void afis()
{   for(int i=1;i<=k;i++)
        g<<sol[i]<<' ';
    g<<'\n';
}

int valid(int poz)
{
    for(int i=1;i<poz;i++)
        if(sol[poz]<=sol[i])
            return 0;
    return 1;
}

void bkt(int poz)
{
    for(int i=1;i<=n;i++)
    {   sol[poz]=i;
        if(valid(poz))
        {   if(poz==k) afis();
            else bkt(poz+1);
        }
    }
}

int main()
{
    f>>n>>k;
    bkt(1);
    return 0;
}
