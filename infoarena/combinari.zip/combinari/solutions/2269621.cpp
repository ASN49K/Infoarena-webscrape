#include <stdio.h>
int v[100000],n,m;

void afisare()
{
    int i;
    for(i = 1; i <= m; i++)
        printf("%d ", v[i]);
    printf("\n");
}

int valid(int k)
{
    int i;
    for(i = 1; i < k; i++)
        if(v[i] == v[k])
            return (0);
    return (1);

}

void back(int k)
{
    int i;
    if(k > m)
        afisare();
    else
    {
        for(i = v[k-1] + 1; i <= n; i++)
        {
            v[k] = i;
            if(valid(k))
                back(k+1);
        }
    }

}

int main()
{
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);
    scanf("%d%d", &n, &m);
    back(1);
    return 0;
}
