#include <fstream>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include<bitset>
#include <map>
#include <cstring>
#include<algorithm>
#define MOD 1234567
using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n,k;
int v[19];
int fr[19];

bool eCresc(int num,int val)
{
    if(num==1)
    {
        return true;
    }
    if(v[num-1]>val)
    {
        return false;
    }
    return true;
}

void perm(int nivel)
{
    if(nivel>k)
    {
        //afisez si ies
        for(int i=1; i<=k; i++)
        {
            fout<<v[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(fr[i]==0 && eCresc(nivel,i))
        {
            v[nivel]=i;
            fr[i]=1;
            perm(nivel+1);
            fr[i]=0;
        }
    }
}

int main()
{
    fin>>n>>k;
    perm(1);
    return 0;

}
