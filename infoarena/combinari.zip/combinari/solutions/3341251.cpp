#include <bits/stdc++.h>
using namespace std;
int m,n,v[30];
void btk(int i,int k){
    if(i>k){
        for(int j=0;j<m;j++)cout<<v[j]<<" ";
        cout<<endl;
        return;
    }
    for(int j=k;j<=n;j++){
        v[i]=j;
        btk(i+1;j+1);
    }
}
int main(){
    ifstream fin("combinari.in");
    ofstream fout("combinari.out");
    fin>>n>>m;
    btk(1,1);
}