#include <fstream>
#include <iostream>
#include <cstring>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n,k,sol[1000];


void bkt(int x)
{
  int i,j;
  for (i=sol[x-1]+1;i<=n;i++)
  {
      sol[x]=i;
      if (x==k)
      {
          for (j=1;j<=k;j++)
            g<<sol[j]<<" ";
          g<<endl;
      }
      else bkt(x+1);
  }
}


int main()
{
   f>>n>>k;
   sol[0]=0;

   bkt(1);
}
