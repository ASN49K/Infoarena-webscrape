#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int v[25],a[25],n,k;
void bt(int poz)
{
    int i;
    if(poz==k+1)
    {
        for(i=1;i<=k;i++)
            fout<<v[i]<<' ';
      fout<<'\n';
            return;
    }
    for(i=poz;i<=n;i++)
    {
        if(!a[i])
        {
            a[i]=1;
            v[poz]=i;
            if(v[poz]>v[poz-1])
                bt(poz+1);
            v[poz]=0;
            a[i]=0;
        }
    }
}
int main()
{
    fin>>n>>k;
    bt(1);
    return 0;
}
