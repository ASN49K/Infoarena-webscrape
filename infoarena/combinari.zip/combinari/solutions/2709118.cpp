#include <fstream>

using namespace std;
ifstream cin("combinari.in");
ofstream cout ("combinari.out");
int n, sol[30], m;
void afisare()
{
    for(int i=1; i<=m; i++)
        cout << sol[i] << ' ';
    cout << '\n';
}
void comb(int k)
{
    int i;
    if(k==m+1)
        afisare();
    else
        for(i=sol[k-1]+1; i<=n; i++)
        {
            sol[k]=i;
            comb(k+1);
        }
}
int main()
{
    cin >> n >> m;
    comb(1);
    return 0;
}
