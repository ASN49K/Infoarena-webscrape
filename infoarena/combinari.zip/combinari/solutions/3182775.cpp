#include <bits/stdc++.h>

using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
vector <int> v;
bool ap[20];
void afisare(){
    for( int i = 0; i < v.size(); i++ )
        out << v[i] << " ";
    if( v.size() )
        out << "\n";
}
void bkt( int pas, int n, int k ){
    if( v.size() == k  ){
        afisare();
        return;
    }
    for( int i = 1; i <= n; i++ ){
        if( (v.empty() || i > v.back()) && !ap[i] ){
            ap[i] = 1;
            v.push_back(i);
            bkt(pas+1, n, k);
            ap[i] = 0;
            v.pop_back();
        }
    }
}
int main()
{
    int n, k;
    in >> n >> k;
    bkt(1, n, k);
    return 0;
}
