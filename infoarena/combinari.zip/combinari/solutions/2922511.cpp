#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

const int NM = 1e2 + 5;

int x[NM], a[NM], n, m;

void solve (){
  for (int i = 1; i <= m; i++){
    fout << x[i] << " ";
  }
  fout << '\n';
}

void back (int k){
  for (int i = x[k - 1] + 1; i <= n; i++){
    if (k <= m){
      x[k] = i;
      if (k == m){
        solve();
      }
      else{
        back(k + 1);
      }
    }
  }
}

int main(){
  fin >> n >> m;
  for (int i = 1; i <= n; i++){
    a[i] = i;
  }
  back(1);
}
