#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int comb[19], N, K;

void back(int p, int K, int N)
{
    if(p == K + 1)
    {
        for(int i = 1; i <= K; i++) fout << comb[i] >> " ";
        fout << endl;
        return;
    }
    for(int i = comb[p-1] + 1; i <= N - K + p; i++)
    {
        comb[p] = i;
        back(p+1, K, N);
    }
}

int main()
{
    fin >> N >> K;
    back(1, K, N);
    return 0;
}
