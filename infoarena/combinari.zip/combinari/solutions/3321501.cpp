#include <iostream>
#include <fstream>
#define mod 666013
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int n, k,a[20],fr[20];
void print_sol() {
	for (int i = 1; i <= k; i++) {
		out << a[i] << ' ';
	}out << '\n';
}

void sol(int x) {
	if (x == k + 1) {
		print_sol();
		return;
	}
	for (int i = a[x-1]+1; i <= n; i++) {
		if (fr[i])continue;
		fr[i] = true;
		a[x] = i;
		sol(x + 1);
		fr[i] = false;
	}
}

int main()
{
	in >> n >> k;
	sol(1);
	return 0;
}