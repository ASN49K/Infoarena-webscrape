#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

vector<int> combinari;
bool vizitat[20] = {false};
FILE *fin = fopen("combinari.in", "r");
FILE *fout = fopen("combinari.out", "w");

void bkt(int k, int n, int c) {
    if(k == c + 1) {
        for(int i = 0; i < c; i++) {
            fprintf(fout, "%d ", combinari[i]);
        }
        fprintf(fout, "\n");
        return;
    }

    for(int i = 1; i <= n; i++) {
        if(!vizitat[i]) {
            if(k == 1) {
                combinari.push_back(i);
                vizitat[i] = true;

                bkt(k+1, n, c);

                combinari.pop_back();
                vizitat[i] = false;
            } else if(k > 1 && combinari.back() < i) {
                combinari.push_back(i);
                vizitat[i] = true;

                bkt(k+1, n, c);

                combinari.pop_back();
                vizitat[i] = false;
            }
        }
    }
}

int main() {
    int n, c;
    fscanf(fin, "%d %d", &n, &c);

    bkt(1, n, c);
    return 0;
}