#include <iostream>
#include <bits/stdc++.h>
#define VMAX 2000005
#define INF 2147000000
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n,m;
int sol[20];

void bkt(int indic)
{
    if(indic==m+1)
    {
        for(int i=1;i<=m;i++)
            fout<<sol[i]<<' ';
        fout<<'\n';
    }
    else
    {
        for(int i=sol[indic-1]+1;i<=n-m+indic;i++)
        {
            sol[indic]=i;
            bkt(indic+1);
        }
    }
}

int main()
{
    int i,j,k,t,q,nr,minim,maxim,st,dr,mij;
    fin>>n>>m;
    bkt(1);

    return 0;
}
