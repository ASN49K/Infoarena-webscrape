#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, rep[50], v[50], k, nr;
void generate(int lng, int v[], int k) {
    if (lng == k + 1) {
        for (int i = 1; i <= k; i++)
            fout << v[i] << " ";
        fout << "\n";
    }
    for (int i = 1; i < n + 1; i++)
        if (rep[i - 1] == 0) {
            v[lng] = i;
            if (v[lng - 1] < v[lng]) {
                rep[i - 1] = 1;
                generate(lng + 1, v, k);
                rep[i - 1] = 0;
            }
        }
}

int main() {
    fin >> n >> k;
    generate(1, v, k);
}
