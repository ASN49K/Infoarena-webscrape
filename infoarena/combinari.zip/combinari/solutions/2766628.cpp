#include <iostream>
#include <fstream>

using namespace std;

int n, k, v[19];

ofstream g("combinari.out");

void Citire()
{
    ifstream f("combinari.in");

    f >> n >> k;
}

void Afisare()
{
    for(int i = 1; i <= k; i++)
        g << v[i] << ' ';
    g << '\n';
}

void Generare(int index)
{
    if(index == k + 1)
        Afisare();
    else
        for(int numar = v[index - 1] + 1; numar <= n; numar++)
        {
            v[index] = numar;
            Generare(index + 1);
        }
}

int main()
{
    Citire();
    Generare(1);

    return 0;
}







