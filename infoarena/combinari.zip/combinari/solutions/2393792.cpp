#include <fstream>
#define MAX_N 18

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[MAX_N + 1], n, k;
bool u[MAX_N + 1];

void bk(int i) {
	if (i <= k) {
		for (int j = 1; j <= n; ++j) {
			if (u[j]) {
				u[j] = false;
				v[i] = j;
				bk(i + 1);
				u[j] = true;
			}
		}
	}
	else {
		for (int j = 1; j <= k; ++j) {
			fout << v[j] << " ";
		}
		fout << "\n";
	}
}

int main() {
	fin >> n >> k;
	for (int i = 1; i <= n; ++i) {
		u[i] = true;
	}
	bk(1);
}
