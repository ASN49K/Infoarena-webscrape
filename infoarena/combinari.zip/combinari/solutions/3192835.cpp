#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int st[20],n,k;
bool vz[20];

void afis(int p)
{
    for(int i=1;i<=p;i++)g<<st[i]<<' ';
    g<<'\n';
}

bool solutie(int p)
{
    return p==k;
}

bool valid(int p)
{
    return st[p-1]<st[p];
}

void bk(int p)
{
    for(int i=1;i<=n;i++)
        if(!vz[i])
    {
        vz[i]=1;
        st[p]=i;
        if(valid(p))
            if(solutie(p))afis(p);
            else bk(p+1);
        vz[i]=0;
    }
}

int main()
{
    f>>n>>k;
    bk(1);
}
