#include <bits/stdc++.h>

using namespace std;

const int MAXN=18;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,m;
int comb[MAXN+1];

void bkt(int k) {
    if(k==m+1) {
        for(int i=1; i<=m; i++){
            fout<<comb[i]<<' ';
        }
        fout<<'\n';
    } else {
        for(int i=comb[k-1]+1; i<=n-m+k; i++) {
            comb[k]=i;
            bkt(k+1);
        }
    }
}

int main() {
    fin>>n>>m;
    bkt(1);
    return 0;
}
