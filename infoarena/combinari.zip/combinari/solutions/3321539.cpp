/*#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, m, v[21];


void Afisare()
{
    for(int i=1; i<=m; ++i)
        fout<< v[i] << ' ';
    fout<< '\n';
}

void Back(int k)
{
    for(int i=v[k-1]+1; i<=n; ++i)
    {
        v[k]=i;
        if(k==1)
        {
            if(k==m)Afisare();
            else Back(k+1);
        }
    }
}

int main()
{
    fin >> n >> m;
    Back(1);
    fin.close();
    fout.close();
    return 0;
}*////nu merge
#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,m;
int v[20];
void Afis(){
    for(int i=1; i<=m; i++){
        fout<<v[i]<<" ";
    }
    fout<<'\n';
}
bool ok(int k){
    if(k>1)
        return v[k]>v[k-1];
    return 1;
}
bool sol(int m,int k){
return m==k;
}
void combi(int k){
    for(int i=1; i<=n; i++){
        v[k]=i;
        if(ok(k)){
            if(sol(m,k)){
                Afis();
            }
            else{
                combi(k+1);
            }
        }
    }
}
int main(){
    int a,b;
    fin>>n>>m;
    combi(1);
    return 0;
}
