#include <fstream>

using namespace std;

const int Nmax=20;

int n,p,v[Nmax];
ofstream fout("combinari.out");

void bkt(int k) {
    if (k==p+1) {
        for (int i=1; i<=p; ++i) {
            fout<<v[i]<<' ';
        }
        fout<<endl;
        return;
    }
    for (int i=v[k-1]+1; i<=n; ++i) {
        v[k]=i;
        bkt(k+1);
    }
}

int main()
{
    ifstream fin("combinari.in");
    fin>>n>>p;
    bkt(1);
    fin.close();
    fout.close();
    return 0;
}
