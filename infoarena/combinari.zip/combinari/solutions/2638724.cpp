#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>

using namespace std;
const int N = 18;

ifstream fin ( "combinari.in" );
ofstream fout ( "combinari.out" );

bitset <N+5> visited ( false );
vector<int> comb;

int n, k;

void print_comb () {
    for ( int i = 0; i < k; i ++ )
       fout << comb[i] << ' ';
    fout << '\n';
}

void generate_comb () {
    if ( comb.size () == k )
      print_comb ();
    else {
      int i;
      if ( comb.size () == 0 )
        i = 1;
      else
        i = comb.back () + 1;

      for ( ; i <= n; i ++ ) {
         if ( !visited[i] ) {
           visited[i] = true;
           comb.push_back ( i );
           generate_comb ();
           visited[comb.back()] = false;
           comb.pop_back ();
         }
      }
    }
}
int main()
{
   fin >> n >> k;
   generate_comb ();
    return 0;
}
