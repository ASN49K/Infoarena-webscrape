#include <fstream>
#include <cmath>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int v[19];
int main()
{
    int n,k,i;
    fin >> n >> k;
    for (i=1;i<=pow(2,n)-1;i++)
    {
        int s=0,copyi=i,j=1;
        while (copyi>0)
        {
            v[j]=copyi%2;
            copyi/=2;
            s+=v[j];
            j++;
        }
        if (s==k)
        {
            for (j=1;j<=n;j++)
            {
                if (v[j]==1) fout << j << ' ';
            }
            fout << '\n';
        }
    }
    return 0;
}