#include <iostream>
#include<fstream>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int st[20];
int n,k;

bool bun(int p)
{
    if(p==1)
        return 1;
    else if(st[p]>st[p-1])return 1;
    return 0;
}
bool sol(int p)
{
    if(p==k)return 1;
    return 0;
}

void afis(int k)
{
    for(int i=1;i<=k;i++)
        g<<st[i]<<" ";
    g<<endl;
}

void BKT(int p)
{
    for(int i=1;i<=n;i++)
    {
        st[p]=i;
        if(bun(p))
        {
            if(sol(p))afis(k);
            else BKT(p+1);
        }


    }

}

int main()
{

    f>>n;
    f>>k;
    BKT(1);
    f.close();
    g.close();
    return 0;
}
