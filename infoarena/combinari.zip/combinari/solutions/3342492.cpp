#include <cstdio>
using namespace std;

const int NMAX = 20;

int f[NMAX], solution[NMAX];

void print_solution(int n){
    for(int i = 1; i <= n; i++){
        printf("%d ", solution[i]);
    }
    printf("\n");
}

void combinari(int n, int k, int position){
    if(position == k + 1){
        print_solution(k);
        return;
    }
    for(int i = 1; i <= n; i++){
        if(f[i]) continue;
        if(i < solution[position - 1]) continue;
        f[i] = true;
        solution[position] = i;
        combinari(n, k, position + 1);
        f[i] = false;
    }
}

int main(){
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);

    int n, k;
    scanf("%d %d", &n, &k);

    combinari(n, k, 1);
    return 0;
}
