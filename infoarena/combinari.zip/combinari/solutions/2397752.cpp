#pragma GCC optimize("O3")
#include<bits/stdc++.h>
using namespace std;
#define rc(x) return cout<<x<<endl,0
#define pb push_back
#define dbg(x) cout << #x << '=' << x << '\n';
#define ll long long
#define sz size()
#define pb push_back
#define int ll
const ll mod = 1e9 + 7;
int n, k;
vector <int> v;

int combinari(int n, int k){
    int ans=1, x=1;
    if(k>=n/2+1){for(int i=k+1; i<=n; i++) ans*=i;
        for(int i=n-k; i>=1; i--) x*=i;
        return ans/x;
    }
    else{
        for(int i=n-k+1; i<=n; i++) ans*=i;
        for(int i=1; i<=k; i++) x*=i;
        return ans/x;
    }
}

int32_t main(){
    ios_base :: sync_with_stdio(0); cin.tie(); cout.tie();
    ifstream cin("combinari.in");
    ofstream cout("combinari.out");
    cin>>n>>k;
    for(int i=1; i<=k; i++) v.pb(0LL);
    for(int i=1; i<=n-k; i++) v.pb(1LL);
    for(int i=1; i<=combinari(n, k); i++){
        for(int j=0; j<n; j++) if(v[j]==0) cout<<j+1<<" ";
        cout<<'\n';
        next_permutation(v.begin(), v.end());
    }
}
