#include <bits/stdc++.h>

using namespace std;

int n, k;

vector <int> v;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void gen()  {
    if(v.size() == k + 1)  {
        for(int i = 1;i < v.size();i++)
            fout << v[i] << " ";
        fout << "\n";
        return;
    }
    int tt = v.back();
    for(int i = tt + 1;i <= n;i++)  {
        v.push_back(i);
        gen();
        v.pop_back();
    }
}

int main()  {
    fin >> n >> k;
    v.push_back(0);
    gen();
    return 0;
}
