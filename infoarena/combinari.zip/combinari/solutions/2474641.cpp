#include <iostream>
#include <fstream>
#include <vector>
//#define f cin
#define NMAX 100001
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n, k0;
int v[100];

void afisare(int k) {
    for (int i = 1; i <= k; ++i) {
        g << v[i] << " ";
    }
    g << "\n";
}

void bk(int k) {
    for (int i = v[k - 1] + 1; i <= n; ++i) {
        v[k] = i;
        if (k == k0) afisare();
        else bk(k + 1);
    }
}

int main() {

    f >> n >> k0;
    v[0] = 0;
    bk(1);

    return 0;
}
