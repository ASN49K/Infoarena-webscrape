#include <bits/stdc++.h>

using namespace std;

//ifstream fin ("input"); ofstream fout ("output");
ifstream fin ("combinari.in"); ofstream fout ("combinari.out");

int comb[20];
bool used[20];

void back(int pos, int n, int k) {

    if (pos == k + 1) {
        for (int i = 1; i <= k; ++i)
            fout << comb[i] << ' ';
        fout << '\n';
        return;
    }
    for (int i = comb[pos - 1] + 1; i <= n; ++i) {
        if (!used[i]) {
            used[i] = true;
            comb[pos] = i;
            back(pos + 1, n, k);
            used[i] = false;
        }
    }
}

int main() {

    int n, k;
    fin >> n >> k;
    back(1, n, k);
    return 0;
}