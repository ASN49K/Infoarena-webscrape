#include <fstream>

using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,k,x[20];
void afisare(int k)
{
    for(int i=1; i<=k; i++)
        cout<<x[i]<<" ";
    cout<<endl;
}
void bkt(int i)
{

    for(int j=x[i-1]+1; j<=n; j++)
    {
        x[i]=j;
        if(i==k)
                afisare(k);
        else
            bkt(i+1);
    }
}
int main()
{
    cin>>n>>k;
    bkt(1);
    return 0;
}
