#include <bits/stdc++.h>

using namespace std;
int v[100005];
int n;
void bkt(int poz, int k)
{
  if(poz==k+1)
  {
    for(int i=1;i<=k;i++)
      cout<<v[i]<<" ";
    cout<<'\n';
  }
  for(int i=v[poz-1]+1;i<=n;i++)
  {
    v[poz]=i;
    bkt(poz+1, k);
  }
}

int main() {
  ifstream cin("combinari.in");
  ofstream cout("combinari.out");
  int k;
  cin>>n>>k;
  bkt(1, k);


  return 0;
}
