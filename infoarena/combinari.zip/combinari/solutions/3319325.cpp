#include <iostream>
#include <fstream>
using namespace std;

int n, v[10];
bool f[10];
ofstream fout("permutari.out");

void BT(int k) {
    if(k > n) {
        for(int i = 1; i <= n; i++)
            fout << v[i] << (i == n ? '\n' : ' ');
        return;
    }
    for(int i = 1; i <= n; i++) {
        if(!f[i]) {
            f[i] = true;
            v[k] = i;
            BT(k + 1);
            f[i] = false;
        }
    }
}

int main() {
    ifstream fin("permutari.in");
    fin >> n;
    BT(1);
    return 0;
}
