#include <iostream>
#include <vector>
#include <stdio.h>

using namespace std;

void permutari(int n, int m, vector<int>& current, vector<int>& nums)
{
    if (current.size() == m)
    {
        for (int i = 0; i < m; i++)
        {
            printf("%d ", current[i]);
        }
        cout << "\n";
    }

    for (int i = 0; i < nums.size(); i++)
    {
        int cur_num = nums[i];
        if (current.size() == 0 || cur_num > current[current.size() - 1])
        {
            current.push_back(cur_num);
            nums.erase(nums.begin() + i);
            permutari(n, m, current, nums);
            current.pop_back();
            nums.insert(nums.begin() + i, cur_num);
        }
    }
}

int main()
{
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);

    int n, m;
    scanf("%d", &n);
    scanf("%d", &m);
    vector<int> current;
    vector<vector<int>> result;
    vector<int> nums;
    for (int i = 0; i < n; i++)
    {
        nums.push_back(i + 1);
    }
    permutari(n, m, current, nums);

    /*
    for (int i = 0; i < result.size(); i++)
    {
        for (int j = 0; j < result[0].size(); j++)
        {
            printf("%d ", result[i][j]);
        }
        cout << "\n";
    }
    */
}