#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
const int NMAX=18;
int st[NMAX+5], n, k;
void afisare()
{
    for(int i=1;i<=k;i++)
       fout<<st[i]<<" ";
    fout<<"\n";
}
void backt(int x)
{
    if(x==k+1)
      afisare();
    else
    {
        int i;
        for(i=st[x-1]+1;i<=n;i++)
        {
            st[x]=i;
            backt(x+1);
        }
    }
}
int main()
{
   fin>>n>>k;
   backt(1);
    return 0;
}
