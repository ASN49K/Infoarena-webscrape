#include <cstdio>
#define in "combinari.in"
#define out "combinari.out"
#define siz 19

short N, K, sol[siz];

void Afis()
{
    for(short i = 1; i <= K; ++i)
        printf("%d ", sol[i]);
    printf("\n");
}

void back(short p)
{
    for(short i = sol[p - 1] + 1; i <= N; ++i)
    {
        sol[p] = i;
        p == K ? Afis() : back(p + 1);
    }
}

int main()
{
    freopen(in, "r", stdin);
    freopen(out, "w", stdout);
    scanf("%d%d", &N, &K);
    back(1);
    return 0;
}
