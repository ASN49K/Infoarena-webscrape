#include <fstream>
#include <vector>
#define ll long long

using namespace std;

ifstream cin ("combinari.in");
ofstream cout ("combinari.out");

ll n,m,i;
vector <bool> seen;
vector <ll> x;

void write ()
{
    ll i;
    for (i=1;i<=m;++i) cout<<x[i]<<" ";
    cout<<"\n";
}

void combination (ll step)
{
    ll i;
    for (i=x[step-1]+1;i<=n;++i)
    {
        if (!seen[i])
        {
            seen[i]=true;
            x[step]=i;
            if (step==m) write();
            else combination(step+1);
            seen[i]=false;
        }
    }
}

int main()
{
    cin>>n>>m;
    x.resize(m+1);
    seen.resize(n+1);
    combination(1);
    return 0;
}
