#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("combinari.in");
ofstream g ("combinari.out");

const int SIZE = 25;

int n, m, sol[SIZE];

void Print()
{
    for (int i = 1; i <= m; i++)
    {
        g << sol[i] << " ";
    }
    g << "\n";
}

void Back(int k)
{
    for (int i = sol[k - 1] + 1; i <= n; i++)
    {
        sol[k] = i;

        if (k == m)  Print();
        else         Back(k + 1);
    }
}

int main()
{
    f >> n >> m;

    Back(1);

    return 0;
}
