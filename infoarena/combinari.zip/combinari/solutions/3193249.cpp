#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, k;
int v[19];
void backtracc(int pos) {
  if (pos == k + 1) {
    for (int i = 1; i <= k; ++i)
      fout << v[i] << " ";
    fout << '\n';
  } else {
    for (int val = v[pos - 1] + 1; val <= n; ++val) {
      v[pos] = val;
      backtracc(pos + 1);
    }
  }
}
int main()
{
    fin >> n >> k;
    backtracc(1);
    return 0;
}
