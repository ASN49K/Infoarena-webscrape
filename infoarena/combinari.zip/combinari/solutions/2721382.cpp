#include <fstream>

using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int K;
void printsubset(int n,int k,int a[501],int na)
{
    if(K==na)
    {
        for(int i = 1; i <= na; i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<"\n";
    }
    else if(k<=n)
    {
        a[na+1] = k;
        printsubset(n,k+1,a,na+1);
        printsubset(n,k+1,a,na);
    }
}
int main()
{
    int n;
    int a[501];
    cin >> n;
    cin >> K;
    printsubset(n,1,a,0);
    return 0;
}
