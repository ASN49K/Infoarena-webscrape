// Ionascu George-Razvan, 324CA

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

bool find(int nr, vector<int> a) {
    for (int i = 0; i < (int) a.size(); i++) {
        if (nr == a[i]) {
            return true;
        }
    }
    return false;
}

void backtracking(ofstream &fout, int last_digit, int length, int n, int k, vector<int> a) {
    if (length == k) {
        for (int i = 0; i < k; i++) {
            fout << a[i] << " ";
        }
        fout << "\n";
    }

    for (int i = 1; i <= n; i++) {
        bool is_used = find(i, a);

        if (is_used == false && last_digit < i) {
            a[length] = i;
            backtracking(fout, i, length + 1, n, k, a);
            a[length] = 0;
        }
    }
}

int main() {
    ifstream fin("combinari.in");
    ofstream fout("combinari.out");

    int n, k;
    fin >> n >> k;

    vector<int> a(n, 0);

    backtracking(fout, 0, 0, n, k, a);

    return 0;
}