#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k, x[19];

int verif (int pas)
{
    if (pas > 1 && x[pas] <= x[pas-1])
        return 0;
    return 1;
}

void back(int pas)
{
    if(pas==k+1)
    {
        for(int i=1; i<=k; i++)
            cout<<x[i]<<' ';
        cout<<'\n';
    }
    else
    {
        for(int i=1; i<=n; i++)
        {
            x[pas] = i;
            if(verif(pas))
                back(pas+1);
        }
    }
}


int main()
{
    fin>>n>>k;
    back(1);
}
