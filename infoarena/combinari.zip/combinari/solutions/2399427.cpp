#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int st[10005],n,k;
void afis(int p)
{
    for(int i=1; i<=p; i++)
        fout<<st[i]<<" ";
    fout<<"\n";
}
void back(int nivel)
{
    int i;
    for(i=st[nivel-1]+1; i<=n; i++)
    {
        st[nivel]=i;
        if(nivel<k)
            back(nivel+1);
        else
            afis(k);
    }
}
int main()
{
    fin>>n>>k;
    back(1);
}
