#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int v[30],n,k;
void Afisare()
{
    for(int i=1; i<=k; i++)
        g<<v[i]<<" ";

    g<<'\n';
}
void Gen_Comb(int l)
{
    for(int i=1; i<=n; i++)
    {
        v[l]=i;
        if(v[l]>v[l-1])
        {
            if(l==k)
                Afisare();
            else Gen_Comb(l+1);
        }
    }
}
int main()
{
    f>>n>>k;
    Gen_Comb(1);
    return 0;
}
