#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,k;
int combinari[20];

void afisare()
{
    for (int i = 1; i <= k; ++i)
        fout << combinari[i] << " ";
    fout << "\n";
}

bool solutie(int m)
{
    if(k == m)
        return true;
    return false;
}

bool verificare(int m)
{
    for (int i = 1; i < m; ++i)
        if(combinari[i] > combinari[i + 1])
            return false;
    for (int i = 1; i < m; ++i)
        if(combinari[i] == combinari[m])
            return false;
    return true;
}


void backtracking(int pasi)
{
    for (int i = 1; i <= n; ++i)
    {
        combinari[pasi] = i;
        if(verificare(pasi))
            if(solutie(pasi))
                afisare();
            else
                backtracking(pasi + 1);
    }

}

int main()
{
    fin >> n >> k;
    backtracking(1);
}
