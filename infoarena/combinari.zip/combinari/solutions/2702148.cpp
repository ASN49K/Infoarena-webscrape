#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n, t, a[19];
void back(int r)
{
    if (r == t + 1)
    {
        for (int i = 1; i <= t; i++)
            g << a[i] << " ";
        g << '\n';
        return;
    }
    for (int i = a[r - 1] + 1; i <= n; i++)
        a[r] = i, back(r + 1);
}
int main()
{
    f >> n >> t;
    back(1);
    return 0;
}
