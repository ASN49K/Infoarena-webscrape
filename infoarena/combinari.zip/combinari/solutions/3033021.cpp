#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, k, a[20];

int cmmdc(int a, int b){
    if(b == 0)
        return a;
    return cmmdc(b, a % b);
}

bool valid(int i){
    for(int j = 1; j < i; j++)
        if(a[j] == a[i])
            return 0;
    return 1;
}

void afiseasa(int i){
    for(int j = 1; j <= i; j++)
        g << a[j] << ' ';
    g << '\n';
}

void backt(int i){
    int j;
    for(j = a[i-1]+1; j <= n; j++){
        a[i] = j;
        if(valid(i)){
            if(i == k)
                afiseasa(k);
            else
                backt(i+1);
        }
    }
}

int main()
{
    f >> n >> k;

    backt(1);

    return 0;
}
