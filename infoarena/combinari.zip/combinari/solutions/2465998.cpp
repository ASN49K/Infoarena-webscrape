#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int perm[20];

int n, k;

void combinari(int a)
{
    if(a==k)
    {
        for(int i=1; i<=k; i++)
                out<<perm[i]<<" ";
        out<<'\n';
    }
    else
    for(int j=perm[a]+1; j<=n; j++)
    {
            perm[a+1]=j;
            combinari(a+1);
    }
}

int main()
{
    in>>n>>k;

    combinari(0);

    in.close();
    out.close();
    return 0;
}
