#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,x;
int v[20];
//bool verif[20];
void bkt(int k)
{
    for (int i=v[k-1]+1;i<=n;i++)
    {

        v[k]=i;
        if (k<=x)
        {
            if (k==x)
            {
                for (int j=1;j<=x;j++)
                    fout<<v[j]<<' ';
                fout<<'\n';
            }
            bkt(k+1);

        }
        //verif[i]=false;
    }
}
int main()
{
    fin>>n>>x;
    bkt(1);

    return 0;
}
