#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,k,v[20];
void backtrack(int x){
    if(x <= k){
        for(int i=v[x-1]+1;i<=n;i++){
            v[x] = i;
            backtrack(x+1);
        }
    }else{
        for(int i=1;i<=k;i++){
            fout<<v[i]<<' ';
        }
        fout<<'\n';
    }
}
int main()
{
    fin>>n>>k;
    backtrack(1);
    return 0;
}
