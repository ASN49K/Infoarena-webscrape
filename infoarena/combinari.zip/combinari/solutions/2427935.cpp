#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

const int CMAX = 20;
int n , k , v[CMAX];

void citire()
{
    fin >> n >> k;
}

void afisare()
{
    for(int i=1;i<=k;i++)
        fout << v[i] << " ";
    fout << '\n';
}

bool verificare(int q)
{
    for(int i=1;i<=q-1;i++)
    {
        if(v[i]==v[q]||v[i]>v[i+1])
                return false;
    }
    return true;
}

void bkt(int q)
{
    for(int i=1;i<=n;i++)
    {
        v[q] = i;
        if(verificare(q)==true)
        {
            if(q==k)
                afisare();
            else
                bkt(q+1);
        }
    }
}
int main()
{
    citire();
    bkt(1);
    return 0;
}
