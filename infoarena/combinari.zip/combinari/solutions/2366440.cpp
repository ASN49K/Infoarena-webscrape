
#include <bits/stdc++.h>


using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n , k , st[19];

void Back(int top)
{
    if(top == (k + 1))
    {
        for(int i = 1 ; i <= k ; i++)
            fout << st[i] << " ";
        fout << "\n";
    }
    else for(int i = 1 + st[top - 1] ; i <= n ; i++)
    {
        st[top] = i;
        Back(top + 1);
    }
}

int main()
{
    fin >> n >> k;
    Back(1);
    fin.close();
    fout.close();
}
