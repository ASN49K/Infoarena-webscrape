#include <stdio.h>
#include <stdlib.h>

#define MAXN 18

FILE *fin, *fout;

int n, k;

char comb[MAXN + 1];

void print(){
    int i;

    for(i = 1; i <= k; i++){
        fprintf(fout, "%d ", comb[i]);
    }
    fprintf(fout, "\n");
}

void bkt(int pos){
    if(pos == k + 1){
        print();
        return;
    }

    int i;

    for(i = comb[pos - 1] + 1; i <= n; i++){
        comb[pos] = i;
        bkt(pos + 1);
    }
}

int main()
{
    fin = fopen("combinari.in", "r");
    fout = fopen("combinari.out", "w");


    fscanf(fin, "%d%d", &n, &k);

    bkt(1);

    return 0;
}
