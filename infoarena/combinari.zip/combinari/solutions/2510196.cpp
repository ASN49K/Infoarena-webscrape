#include <fstream>
using namespace std ;
const int MAX = 20;
int sol[MAX] , N , K ;
ifstream in ("combinari.in");
ofstream out ("combinari.out");
void back(int);
bool ver(int);
void afisare();

int main(){
in >> N >> K ;
back(1);
return 0;
}

void back(int k){
if(k > K)
    afisare();
else
{
    for (int i = 1 ; i <= N ; i++)
    {
        sol[k] = i;
        if(ver(k))
            back(k+1);
        sol[k] = 0;

    }
  }
}

bool ver (int k){
for (int o = 1; o < k ; o ++)
    if (sol[o] >= sol[k])return false;
return true;
}

void afisare(){
for (int i = 1 ; i <= K ; i ++)
    out << sol[i]<<" ";
out << "\n";
}
