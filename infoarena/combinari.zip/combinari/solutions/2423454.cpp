#include <fstream>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, st[20];
bool viz[20];

void Afisare()
{
    for(int i=1; i<=k; i++)
        g<<st[i]<<" ";
    g<<'\n';
}

void Back (int top)
{
   if(top==k+1)
        Afisare();
   else
   {
       for(int i=st[top-1]+1; i<=n; i++)
       {
           if(viz[i]==false)
           {
               st[top]=i;
               viz[i]=true;
               Back(top+1);
               viz[i]=false;
           }
       }
   }
}

int main()
{

    f>>n>>k;
    Back(1);

    return 0;
}
