#include<fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,m,st[1000],i,k=1;
bool valid, succesor;
int main()
{
    cin>>n>>m;
    st[1]=0;
    while(k)
    {
        do{
            valid=1;succesor=0;
            if(st[k]<n)
            {
                st[k]++;succesor=1;
            }
            if(succesor){
            for(i=1;i<k;i++)
            {
                if(st[k]==st[i]){
                    valid=0;break;}
            }}
        }while(succesor&&!valid);
        if(succesor)
        {
            if(k==m)
            {
                for(i=1;i<=m;i++)
                {
                    cout<<st[i]<<" ";
                }cout<<endl;
            }
            else
            {
                k++;st[k]=st[k-1];
            }
        }
        else
        {
            k--;
        }
    }
}
