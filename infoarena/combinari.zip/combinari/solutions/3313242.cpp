#include <iostream>
#include <fstream>
#include <stdint.h>

const int32_t MAX_N = 18;

int32_t n, k;
int32_t vec[MAX_N];

void Backtrack(int32_t ind, int32_t minVal, std::ostream& fout) {
    if(ind == k) {
        for(int32_t i = 0; i != k; ++i)
            fout << vec[i] << ' ';
        fout << '\n';
    } else {
        for(int32_t i = minVal; i <= n - k + ind + 1; ++i) {
            vec[ind] = i;
            Backtrack(ind + 1, i + 1, fout);
        }
    }
}

int main() {
    std::ifstream fin("combinari.in");
    std::ofstream fout("combinari.out");

    fin >> n >> k;
    Backtrack(0, 1, fout);

    fin.close();
    fout.close();

    return 0;
}