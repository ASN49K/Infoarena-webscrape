#include <stdio.h>
#include <bits/stdc++.h>

#define rep(i, n) for(int i = 0; i < n; i++)
#define REP(i,a,b) for(int i = a; i < b; i++)

using namespace std;
typedef pair<int, int> pii;
const int INF = 0x3f3f3f3f;
const int Nmax = 22;

int N, K, a[Nmax];

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

void write() {
  for(int i = 1; i <= K; i++)
    fout << a[i] << ' ';
  fout << '\n';
}

void back(int lvl) {
  if (lvl == K) {
    write();
    return;
  }

  for(int i = a[lvl] + 1; i <= N; i++) {
    a[lvl+1] = i;
    back(lvl+1);
  }
}

int main(void) {
  fin >> N >> K;
  a[0] = 0;
  back(0); // the back function will operate on a[1..K]; a[0] is just to to start the first iteration.
  return 0;
}
