#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int n, k;
int st[20];
void Read ()
{
    fin >> n >> k;
}
void Write ()
{
    for (int i = 1; i <= k; i++)
        fout << st[i] << " ";
    fout << "\n";
}
void Back (int top)
{
    if (top > k)
        Write();
    else
        for (int i = st[top-1] + 1; i <= n; i++)
            {
                    st[top] = i;
                    Back(top + 1);
            }
}
int main()
{
    Read();
    Back(1);
    return 0;
}
