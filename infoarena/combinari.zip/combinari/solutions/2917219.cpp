#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("combinari.in");
ofstream fout ("combinari.out");

const int MAX_N = 10;
int n, k, output[MAX_N], freq[MAX_N];

void bt(int step, int last){
    if(step > k){
        for(int i=1; i<=k; i++)
            fout<<output[i]<<" ";
        fout<<"\n";
        return;
    }

    for(int i=last+1; i<=n; i++)
        if(freq[i] == 0){
            freq[i] = 1;
            output[step] = i;
            bt(step+1, i);
            freq[i] = 0;
        }
}

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr), fout.tie(nullptr);

    fin>>n>>k;
    bt(1, 0);
    return 0;
}
