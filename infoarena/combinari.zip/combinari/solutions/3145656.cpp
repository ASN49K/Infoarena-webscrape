#include <fstream>

using namespace std;

ifstream fin("a.in");
ofstream fout("a.out");

int n,p,x[19];

void afis(){
    for(int i=1;i<=p;i++)
        fout<<x[i]<<" ";
    fout<<'\n';
}

void Back(int k){
    for(int i=1;i<=n;i++){
        x[k]=i;
        if(k==1||x[k]>x[k-1]){
            if(k==p)
                afis();
            else Back(k+1);
        }
    }
}

int main(){
    fin>>n>>p;
    Back(1);
}
