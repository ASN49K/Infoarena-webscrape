#include <iostream>
#include<fstream>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int st[20];

bool bun(int p)
{
    if(p==1)
        return 1;
    else if(st[p]>st[p-1])return 1;
    return 0;
}
bool sol(int p,int k)
{
    if(p==k)return 1;
    return 0;
}

void afis(int k)
{
    for(int i=1;i<=k;i++)
        g<<st[i]<<" ";
    g<<endl;
}

void BKT(int p,int k,int n)
{
    for(int i=1;i<=n;i++)
    {
        st[p]=i;
        if(bun(p))
        {
            if(sol(p,k))afis(k);
            else BKT(p+1,k,n);
        }


    }

}

int main()
{
    int n,k;
    f>>n;
    f>>k;
    BKT(1,k,n);
    f.close();
    g.close();
    return 0;
}
