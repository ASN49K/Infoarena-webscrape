#include<bits/stdc++.h>
using namespace std;

string numeFisier="combinari";
ifstream fin(numeFisier+".in"); ofstream fout(numeFisier+".out");
#define cin fin
#define cout fout

#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
//#define int ll


int n, k;


int32_t main(){
INIT
cin>>n>>k;
int bit, i;
for(i=((1ll<<n)-1); i>0; i--){
    if(count_bits(i)==k ){
        for(bit=n-1; bit>=0; bit--){
            if( ((1ll<<bit)&i)>0 ){
                cout<<(n-bit)<<" ";
            }
        }
        cout<<"\n";
    }
}

return 0;
}
