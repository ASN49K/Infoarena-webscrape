#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int solutie[20],n,p;
void afisare(int k)
{
    for(int i=1; i<=k; ++i)
        fout<<solutie[i]<<" ";

    fout<<'\n';
}
bool valid(int k)
{
    bool ok=true;
    if(k>1)
    {
        if(solutie[k]<=solutie[k-1])
        {
            ok=false;
        }
    }
   return ok;
}
void bkt(int k)
{
    for(int i=1; i<=n; i++)
    {
        solutie[k]=i;
        if(valid(k)==true)
        {
            if(k==p)
            {
                afisare(k);
            }
            else
                bkt(k+1);
        }

    }
}
int main()
{
    fin>>n>>p;
    bkt(1);
    return 0;
}
