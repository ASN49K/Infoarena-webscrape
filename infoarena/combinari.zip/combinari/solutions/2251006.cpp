#include <fstream>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,m,c[20];
void afis(int k)
{
    int i;
    for(i=1;i<=k;i++)
        g<<c[i]<<' ';
    g<<'\n';
}
void bck(int k)
{
    int i;
    for(i=c[k-1]+1;i<=n;i++)
    {
        c[k]=i;
        if(k==m)
            afis(k);
        else
            bck(k+1);
    }
}
int main()
{
    f>>n>>m;
    bck(1);
    return 0;
}
