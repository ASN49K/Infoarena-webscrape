#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int a[20];
int n,k;
bool isValid(int pos)
{
    if(pos==1)
        return 1;
    if(a[pos]>a[pos-1])
        return 1;
    return 0;
}
bool isSol(int pos)
{
    if(pos == k)
        return 1;
    return 0;
}
void tipar(int pos)
{
    for(int i = 1;i<=pos;i++)
        fout<<a[i];
    fout<<'\n';
}
void backt(int pos)
{
    for(int x = 1;x<=n;x++)
    {
        a[pos]=x;
        if(isValid(pos))
        {
            if(isSol(pos))
            {
                tipar(pos);
            }
            else
            {
                backt(pos+1);
            }
        }
    }
}
int main()
{
    fin>>n>>k;
    backt(1);
    return 0;
}
