#include <bits/stdc++.h>
using namespace std;

int n,k,D[100];
ofstream out("combinari.out");

void afisare();

void Back(int i)
{
    if (i>k)
        afisare();
    else
    {
        for (int j=D[i-1]+1;j<=n-(k-i);j++)
        {
            D[i]=j;
            Back(i+1);
        }
    }
}

int main()
{

    ifstream in("combinari.in");
    in>>n>>k;
    Back(1);
    in.close();
    out.close();
}
void afisare()
{
    for (int i=1;i<=k;i++)
        out<<D[i]<<" ";
    out<<"\n";
}
