#include <fstream>

using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");

int n,k,v[30];
int back(int l)
{
    int i;
    if(l==k)
    {
        for(i=1;i<=k;i++)
        {
            out<<v[i]<<" ";
        }
        out<<"\n";
    }
    else
    {
        for(i=v[l]+1;i<=n;i++)
        {
            v[l+1]=i;back(l+1);
        }
    }
}
int main()
{
    in>>n>>k;
    back(0);
    return 0;
}
