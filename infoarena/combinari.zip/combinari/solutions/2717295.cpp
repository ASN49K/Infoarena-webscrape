#include <iostream>
#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, v[20];

void afisare() {
    for(int i = 1; i <= k; ++i)
        g << v[i] << " ";
    g << "\n";
}

void bkt(int lg) {
    if(lg == k + 1)
        afisare();
    for(int i = v[lg - 1] + 1; i <= n; ++i) {
        v[lg] = i;
        if(lg <= k)
            bkt(lg + 1);
    }
}

int main()
{
    f >> n >> k;
    v[0] = 0;
    bkt(1);
}
