#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[9], n, k;

void bkt(int pos) {
    if (pos == k + 1) {
    for (int i = 1; i <= k; ++i)
      fout<<v[i]<<" ";
    fout<<"\n";
  } else {
    for (int val = v[pos - 1] + 1; val <= n; ++val) {
      v[pos] = val;
      bkt(pos + 1);
    }
  }
}

int main()
{
    fin>>n>>k;
    bkt(1);
    return 0;
}
