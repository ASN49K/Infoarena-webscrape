#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, m;
int v[20];

void afis()
{
    for(int i=1; i<=m; i++)
        g<<v[i]<<" ";
    g<<'\n';
}

int bkt(int x)
{
    for(int i=v[x-1]+1; i<=n-m+x; i++)
    {
        v[x]=i;
        if(x<m)
            bkt(x+1);
        else
            afis();
    }
}

int main()
{
    f>>n>>m;
    bkt(1);
}
