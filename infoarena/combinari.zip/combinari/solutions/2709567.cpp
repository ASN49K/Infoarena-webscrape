#include <iostream>
#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int n,t,a[19];
void bacK(int k)
{
    if(k==t+1)
    {
        for(int j=1;j<=t;j++)
        {
            out<<a[j]<<' ';
        }out<<'\n';
        return;
    }
    for(int i=a[k-1]+1;i<=n;++i)
    {
        a[k]=i;
        bacK(k+1);
    }
}
int main()
{
    in>>n>>t;
    bacK(1);
    return 0;
}
