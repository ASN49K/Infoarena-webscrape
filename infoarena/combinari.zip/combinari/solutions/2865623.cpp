#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, k, top, a[20];
void Afisare()
{
    for (int i = 1; i <= k; i++)
        fout << a[i] << " ";
    fout << "\n";
}
void Back(int top)
{
    if (top == k + 1) Afisare();
    for (int i = a[top - 1] + 1; i <= n; i++)
    {
        a[top] = i;
        Back(top + 1);
    }
}
int main()
{
    fin >> n >> k;
    Back(1);


    return 0;
}