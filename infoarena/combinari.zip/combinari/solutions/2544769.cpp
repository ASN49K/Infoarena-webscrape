#include<fstream>
using namespace std;
ifstream in ("combinari.in");
ofstream out("combinari.out");
int s[20];
int n,m;
void bk(int k)
{
    if(k==m){
        for(int i=s[k-1]+1; i<=n; i++)
        {
            s[k]=i;
            for(int i=1; i<=m; i++)
                out<<s[i]<<" ";
            out<<endl;
        }
            return;
    }
      for(int i=s[k-1]+1; i<=n; i++)
        {
            s[k]=i;
            bk(k+1);
        }


}
int main()
{
    in>>n>>m;
    bk(1);
}
