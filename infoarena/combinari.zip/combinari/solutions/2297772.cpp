#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int nr_el;
int nr_in_comb;
ifstream in("combinari.in");
ofstream out("combinari.out");



void afis_perm(vector<int> &numere){
if(numere.size()==nr_in_comb){
    for(int i=0;i<numere.size();i++)out<<numere[i]<<' ';
    out<<'\n';

}
else{

    if(numere.size()!=0)
    for(int i=numere[numere.size()-1]+1;i<=nr_el;i++){
            numere.push_back(i);
            afis_perm(numere);
            numere.pop_back();


    }
   else{
    for(int i=1;i<=nr_el;i++){
            numere.push_back(i);
            afis_perm(numere);
            numere.pop_back();


    }



   }

}


}

int main()
{

vector<int>nr_act;
in>>nr_el>>nr_in_comb;
afis_perm(nr_act);

in.close();
out.close();
    return 0;
}
