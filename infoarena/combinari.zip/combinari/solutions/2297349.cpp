#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n, p;
vector <int>v;
void afisare(int k)
{
	for (int i = 1; i <= k; i++)
		g << v[i] << ' ';
	g << "\n";
}
void bktr(int k)
{
	for (int i = v[k - 1] + 1; i <= n; i++)
	{
		v[k] = i;
		if (p == k)
			afisare(k);
		else bktr(k + 1);
	}
}
int main()
{
	f >> n >> p;
	v.resize(p + 2);
	bktr(1);

}
