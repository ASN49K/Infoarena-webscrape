#include <bits/stdc++.h>
std::ifstream in("combinari.in");
std::ofstream out("combinari.out");
int n, k, st[20];

void afisare(int p)
{
    for (int i = 1; i <= p; i++)
        out << st[i] << ' ';
    out << '\n';
}

void bktr(int p, int j)
{
    for (int i = j; i <= n; i++)
    {
        st[p] = i;
        if (p == k)
            afisare(p);
        else
            bktr(p + 1, i + 1);
    }
}

int main(void)
{
    in >> n >> k;
    bktr(1, 1);
    return 0;
}

