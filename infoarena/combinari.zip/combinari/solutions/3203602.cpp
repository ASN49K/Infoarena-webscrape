#include <fstream>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int n, k, len, sol[10];

void afisare(){
    for(int i = 0; i < len; i++)
        cout << sol[i] << ' ';
    cout << '\n';
}

void combinari(int pas, int val){
    if(pas > k){
        afisare();
        return;
    }
    for (int i = val; i <= n; ++i) {
        sol[len++] = i;
        combinari(pas + 1, i + 1);
        len--;
    }
}

int main() {
    cin >> n >> k;
    combinari(1, 1);
    return 0;
}
