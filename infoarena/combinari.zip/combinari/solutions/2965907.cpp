#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n;

int k;

int v[25];
bool f[25];

void backt(int pas)
{
    if(pas>k)
    {
        for(int i=1;i<=k;i++)
        {
            fout<<v[i]<<' ';
        }
        fout<<'\n';
        return;
    }
    for(int i=v[pas-1]+1;i<=n;i++)
    {
        if(!f[i])
        {
            f[i]=true;
            v[pas]=i;
            backt(pas+1);
            f[i]=false;
        }
    }
}

int main()
{
    fin>>n>>k;
    backt(1);
}
