#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int v[20],n,k;
void bkt (int it){
    if (it == k){
        for (int i = 0; i < it; ++i)
            fout << v[i] << " ";
        fout << '\n';
        return;
    }
    int start;
    if (it > 0)
        start = v[it - 1] + 1;
    else
        start = 1;
    for (int i = start; i <= n; ++i){
        v[it] = i;
        bkt (it + 1);
        v[it] = 0;
    }
}
int main()
{
    fin >> n >> k;
    bkt (0);
    return 0;
}
