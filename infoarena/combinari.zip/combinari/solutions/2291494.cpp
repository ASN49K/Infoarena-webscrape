#include <fstream>

using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int st[20],k,n;
void afis()
{
    for(int i=1;i<=k;i++)
    {
        out<<st[i]<<" ";
    }
    out<<'\n';
}
void back(int p)
{
    if(p==k+1)
    {
        afis();
    }
    else
    {
        for(int i=st[p-1]+1;i<=n;i++)
        {
                st[p]=i;
                back(p+1);
        }
    }
}
int main()
{

    in>>n>>k;
    back(1);
    return 0;
}
