#include<stdio.h>
short n,p,s[19];
void A(short k)
{
    if(k-1==p)
    {
        for(short i=1;i<=p;i++)
            printf("%hd ",s[i]);
        printf("\n");
    }
    else
        for(short i=s[k-1]+1;i<=n-p+k;i++)
            s[k]=i,A(k+1);
}
int main()
{
    freopen("combinari.in","r",stdin),freopen("combinari.out","w",stdout),scanf("%hd%hd",&n,&p),A(1);
}
