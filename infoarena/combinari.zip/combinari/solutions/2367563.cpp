#include <iostream>
#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int n,a[20],k;
void bacK(int t)
{
    for(int i=a[t]+1;i<=n+1;i++)
    {
        a[t+1]=i;
        if(t==k)
        {
            for(int j=1;j<=k;j++)
            {
                out<<a[j]<<' ';
            }out<<'\n';
            return;
        }
        else bacK(t+1);
    }
}
int main()
{
    in>>n>>k;
    bacK(0);
    return 0;
}
