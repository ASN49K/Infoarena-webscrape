#include <bits/stdc++.h>

using namespace std;

#define LMax 20
#define INfile "combinari.in"
#define OUTfile "combinari.out"

ifstream fin(INfile);
ofstream fout(OUTfile);

int var, stiva[LMax], k, n, poz = 1,x,vag=1,cont;
bool ok = false;

void setvag()
{
    int o=1;
for(int i=1; i<=n; ++i)
    vag*=i;
for(int i=1; i<=k; ++i)
    o*=i;
vag/=o;
}
void urm (int nr)
{
    if (nr + 1 <= n)
        var = nr + 1;
    else
    {
        stiva[poz]=0;
        poz--;
        urm(stiva[poz]);
    }
}

void val (int h)
{
    if (stiva[poz - 1] < h)
        ok = true;
        for(int i=1; i<=poz; ++i)
            if(stiva[i]==h)
            ok=false;
}
void back()
{
    x=0;
    ok = false;
    do
    {
        urm (stiva[poz]+x);
        val (var);
        x++;
    }
    while (ok == false);
    stiva[poz]=var;
    if (poz == k){
        for (int i = 1; i <= k; ++i)
            cout << stiva[i] << ' ';
            cout<<'\n';
            cont++;
    }
    else
        poz++;
        if(cont<vag)
    back();
}
int main()
{
    fin >> n >> k;
    setvag();
    back();
    return 0;
}
