#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
typedef int sir[100001];
sir x, a;
int p, i, k, n;
int as, ev;
void succ(sir x, int k, int& as) {
    if (x[k] < n) {
        as = 1;
        x[k]++;

    }
    else
        as = 0;
}
void valid(sir x, int k, int& ev) {
    ev = 1;
    if ((k >= 2) && !(a[x[k]] > a[x[k - 1]]))
        ev = 0;
}
void afis(sir x, int k) {
    int i;
    for (i = 1; i <= k; i++)
        fout << a[x[i]] << ' ';
    fout << '\n';
}
int main() {
    fin >> n;
    for (i = 1; i <= n; i++)
        a[i] = i;
    fin >> p;
    k = 1;
    x[k] = 0;
    while (k > 0) {
        do {
            succ(x, k, as);
            if (as)
                valid(x, k, ev);
        } while (as && !ev);
        if (as)
            if (k == p)
                afis(x, k);
            else {
                k++;
                x[k] = 0;
            }
        else
            k--;
    }
}