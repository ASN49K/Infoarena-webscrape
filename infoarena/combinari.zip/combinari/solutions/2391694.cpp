#include<cstdio>
#define M 2000000
int n,p,s[19],l;
char r[M];
inline void S(int x)
{
    if(x>9)
        r[l++]=49,r[l++]=x+38;
    else
        r[l++]=x+48;
    r[l++]=32;
}
inline void B(int k)
{
	int i;
    if(k-1==p)
    {
        for(i=1;i<=p;i++)
            S(s[i]);
        r[l++]=10;
    }
    else
        for(i=s[k-1]+1;i<=n-p+k;i++)
            s[k]=i,B(k+1);
}
int main()
{
    freopen("combinari.in","r",stdin),freopen("combinari.out","w",stdout),scanf("%d%d",&n,&p),B(1),fwrite(r,1,l,stdout);
}
