#include <fstream>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int n, k;

void citire(int &N, int &P)
{
    cin >> N >> P;
}

void comb(int K, int N, int P, int sol[])
{
    if(K > P)
    {
        for(int i = 1 ; i <= P ; i++)
            cout << sol[i] << ' ';
        cout << '\n';
        return ;
    }
    for(int i = sol[K - 1] + 1 ; i <= N ; i++)
    {
        sol[K] = i;
        comb(K + 1, N, P, sol);
    }
}

int main()
{
    int N, P, sol[20];
    citire(N,P);
    sol[0] = 0;
    comb(1, N, P, sol);
    return 0;
}
