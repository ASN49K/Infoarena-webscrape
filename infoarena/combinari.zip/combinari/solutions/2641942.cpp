#include <fstream>
#include <iostream>
#include <math.h>
using namespace std;

int v[19];

int main()
{
    ifstream in("combinari.in");
    ofstream out("combinari.out");
    int n, m, i, j;
    bool terminat = false;
    in >> n >> m;
    for (i = 1; i <= m; i++)
    {
        v[i] = i;
        out << i << " ";
    }
    v[m + 1] = n + 1;

    j = m;
    while (!terminat)
    {
        out << "\n";
        while (!terminat && v[j] >= v[j + 1] - 1)
        {
            j--;
            if (j <= 0)
                terminat = true;
        }
        if (!terminat)
        {
            v[j]++;
            for (i = j + 1; i <= m; i++)
                v[i] = v[i - 1] + 1;
            j = m;
            for (i = 1; i <= m; i++)
                out << v[i] << " ";
        }
    }
    return 0;
}