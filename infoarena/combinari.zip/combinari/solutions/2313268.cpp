#include <fstream>
using namespace std;
int st[19],n,k,l;
ifstream f("combinari.in");
ofstream g("combinari.out");

void init()
{
    f>>n>>k;
}
bool valid(int l)
{
    bool ev=true;
    int i;
    for(i=1;i<l;i++)
        if(st[i]>=st[l])
            ev=false;
    return ev;
}
bool solutie(int l)
{
    if(l==k)
        return true;
    else return false;
}
void tipar(int l)
{
    int i;
    for(i=1;i<=l;i++)
        g<<st[i]<<" ";
    g<<'\n';
}
void back(int l)
{
    int i;
    for(i=1;i<=n;i++)
    {
        st[l]=i;
        if(valid(l))
            if(solutie(l))
                tipar(l);
        else back(l+1);
    }
}

int main()
{
    init();
    back(1);
}


