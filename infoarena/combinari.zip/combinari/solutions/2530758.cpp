#include <bits/stdc++.h>
#define ll long long
#define f first
#define s second
#define pb push_back()
#define mentiune dragos
using namespace std;

int n,k;
vector<int>comb;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void combinare(int x){
    comb.push_back(x);
    if(comb.size()==k){
        for(int i=0;i<comb.size();i++) fout << comb[i] << ' ';
        fout << '\n';
        comb.pop_back();
        return;
    }
    for(int i=x+1;i<=n;i++) combinare(i);
    comb.pop_back();
}

int main(){
    fin >> n >> k ;
    for(int i=1;i<=n-k+1;i++){
        combinare(i);
    }
}


// 4 3
// 1 2 3
// 1 2 4
// 1 3 4
// 2 3 4
