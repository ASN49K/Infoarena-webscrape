#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

const int maxN = 10;

int x[maxN], fr[maxN];
int n, m;

void afisare () {
    for(int i = 1; i <= m; ++i)
        fout << x[i] << " ";
    fout << '\n';
}

void bkt (int k) {
    for(int i = 1; i <= n; ++i) {
        x[k] = i; fr[i]++;
        if(fr[i] == 1 && x[k] > x[k-1]) {
            if(k == m)
                afisare();
            else
                bkt(k+1);
        }
        fr[i]--;
    }
}

int main()
{
    fin >> n >> m;

    bkt(1);

    return 0;
}
