#include <fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int st[19];
int n,k;
void tipareste(int k)
{
    for(int i=1;i<=k;i++)
        cout<<st[i]<<" ";
}
int valid(int k)
{
    if(k==1) return 1;
    if(st[k]<st[k-1]) return 0;
    return 1;
}
void backtr(int k)
{
    for(int i=1;i<=n;i++)
    {
        st[k]=i;
        if(valid(k))
            if(k==n) tipareste(k);
            else backtr(k+1);
    }
}
int main()
{
    cin>>n>>k;
    backtr(1);
    cin.close();
    cout.close();
    return 0;

}