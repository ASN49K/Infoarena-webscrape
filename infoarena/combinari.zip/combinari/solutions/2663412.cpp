#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,sol[20];
void Bkt(int poz)
{
    if(poz==k+1)
    {
        for(int i=1; i<=k; i++)
            g<<sol[i]<<' ';
        g<<'\n';
    }
    else for(int i=sol[poz-1]+1; i<=n; i++)
            sol[poz]=i,Bkt(poz+1);
}
int main()
{
    f>>n>>k;
    Bkt(1);
    return 0;
}
