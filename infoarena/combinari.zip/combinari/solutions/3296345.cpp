#include <bits/stdc++.h>
#define pb push_back
//#define int long long
#define cin fin
#define cout fout
using namespace std;
ifstream cin("combinari.in");ofstream cout("combinari.out");
const int N=18+5;
int n,k;
vector<int> path;
void bkt(int last, int step)
{
    if(step==k+1)
    {
        for(auto x:path) cout<<x<<" ";
        cout<<'\n';
        return;
    }
    for(int i=last+1;i<=n;++i)
    {
        path.pb(i);
        bkt(i,step+1);
        path.pop_back();
    }
}
signed main()
{
    cin>>n>>k;
    bkt(0,1);
}
