#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,i,j,v[30],k,l;
int main()
{
    fin>>n>>k;
    j=1;
    v[j]=1;
    do
    {
        for(i=j+1;i<=k;i++)
            v[i]=v[i-1]+1;
        for(i=1;i<=k;i++)
            fout<<v[i]<<" ";
        fout<<'\n';
        j=k;
        while(v[j]>=n-k+j)
            j--;
        if(j==0)
            break;
        v[j]++;
    }while(v[1]<=n-k+1);
    return 0;
}
