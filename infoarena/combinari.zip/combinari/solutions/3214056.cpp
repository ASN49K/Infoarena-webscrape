#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, x[19], k;

void afis(){
    for(int i = 1; i <= k; i++) fout << x[i] << ' ';
    fout << '\n';
}

void back(int j){
    for(int i = x[j - 1] + 1; i <= n - k + j; i++){
        x[j] = i;
        if(k == j) afis();
        else back(j + 1);
    }
}

int main(){
    fin >> n >> k;
    back(1);
    return 0;
}