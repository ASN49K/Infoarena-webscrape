#include <fstream>
using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int n, p, x[10];

void write() {
  for (int i = 1; i <= p; ++i)
    cout << x[i] << " ";
    
  cout << "\n";
}

bool ok(int k) {
  for (int i = 1; i < k; ++i)
    if (x[i] >= x[k])
      return false;

  return true;
}

void back(int k) {
  for (int i = 1; i <= n; ++i) {
    x[k] = i;
    
    if (ok(k)) {
      if (k == p) write();
      else back(k + 1);
    }
  }
}

int main() {
  cin >> n >> p;
  back(1);
  
  cin.close();
  cout.close();
  return 0;
}
