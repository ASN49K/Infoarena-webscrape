#include<bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, stiva[1000001], k, maxn;
bool ok;

void afisare_permutari()
{
    for (int i=1;i<=k;i++)
        fout<<stiva[i]<<" ";
    fout<<'\n';
}
int valid_distincte(int nivel)
{
    for (int i=1;i<nivel;i++)
    {
        if (stiva[i]>=stiva[nivel])
            return 0;
    }
    return 1;
}
void permutari(int nivel)
{
    for (int i=0;i<n;i++)
    {
        stiva[nivel] = i+1;
        if (valid_distincte(nivel)==1)
        {
            if (nivel==k)
                afisare_permutari();
            else
                permutari(nivel+1);
        }
    }
}

int main()
{
    fin>>n>>k;
    permutari(1);
}