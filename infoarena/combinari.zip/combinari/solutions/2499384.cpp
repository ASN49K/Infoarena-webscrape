#include <cstdio>
#include <vector>
using namespace std;

void back(int currentPos, int N, int K, vector<bool>& taken, int lastElem) {
	if (currentPos == K) {
		for (int i = 1; i <= N; i++) {
			if (taken[i]) {
				printf("%d ", i);
			}
		}
		printf("\n");
		return;
	}

	for (int nextElem = lastElem + 1; nextElem <= N; nextElem++) {
		if (!taken[nextElem]) {
			taken[nextElem] = true;
			back(currentPos + 1, N, K, taken, nextElem);
			taken[nextElem] = false;
		}
	}
}

int main() {
	freopen("combinari.in", "r", stdin);
	freopen("combinari.out", "w", stdout);

	int N, K;
	scanf("%d%d", &N, &K);
	vector<bool> taken(N + 1, false);
	back(0, N, K, taken, 0);
	return 0;
}