#include <fstream>
#import <algorithm>
#import <vector>
#import <map>
#import <deque>
#import <cassert>
#import <cmath>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,k;
bool viz[19];
vector<int>rez={0};
void bt()
{
    if(rez.size()==k+1)
    {
        for(int i=1;i<=k;i++)cout<<rez[i]<<' ';
        cout<<'\n';
        return;
    }
    for(int i=rez.back()+1;i<=n;i++)
    {
        if(!viz[i])
        {
            viz[i]=1;
            rez.push_back(i);
            bt();
            rez.pop_back();
            viz[i]=0;
        }
    }
}
main()
{
    cin>>n>>k;
    bt();
}
