#include<stdio.h>
int n,p,k=1,s[19],o,i;
int main()
{
    freopen("combinari.in","r",stdin),freopen("combinari.out","w",stdout),scanf("%d%d",&n,&p);
    while(k) {
        for(++s[k],o=i=1;i<k&&o;i++)
            if(s[i]==s[k])
                o=0;
        if(o)
            if(s[k]<=n)
                if(k==p) {
                    for(i=1;i<=k;i++)
                        printf("%d ",s[i]);
                    printf("\n");
                } else
                    k++,s[k]=s[k-1];
            else
                k--;
    }
    return 0;
}
