#include <bits/stdc++.h>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
vector<vector<int>>sol;
int visited[50];

void back(int n, int k, vector<int>ans, int last) {
    if (ans.size() == k) {
        sol.push_back(ans);
        return;
    }
    for (int i = last; i <= n; i++) {
        if (visited[i] == 0) {
            visited[i] = 1;
            ans.push_back(i);
            back(n, k, ans, i + 1);
            ans.pop_back();
            visited[i] = 0;
        }
    }
}

int main() {

    int n, k;
    vector<int>ans;
    fin>>n>>k;
    back(n, k, ans, 1);
    for (int i = 0; i < sol.size(); i++) {
        for (int j  = 0; j < sol[i].size(); j++) {
            fout<<sol[i][j]<< " ";
        }
        fout<<endl;
    }
    return 0;
}