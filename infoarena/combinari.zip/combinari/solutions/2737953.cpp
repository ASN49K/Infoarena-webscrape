#include <iostream>
#include <fstream>
using namespace std;
#define DIM 20
int nr_n,nr_k,poz[DIM];
ifstream fin("combinari.in");
ofstream fout("combinari.out");  
bool corect(int k)
{
    for(int i=1;i<k;i++)
    {
        if(poz[i]==poz[k] || poz[i]==poz[i-1])
        {
            return false;
        }
    }
    return true;
}
void afis()
{
    for(int i=1;i<=nr_k;i++)
    {
        fout<<poz[i]<<" ";
    }
    fout<<'\n';
}
void back_track(int k)
{
    for(int i=poz[k-1]+1;i<=nr_n;i++)
    {
        poz[k]=i;
        if(corect(nr_n)==true)
        {
            afis();
        }
        else
        {
            back_track(k+1);
        }
    }
}
int main()
{ 
    fin>>nr_n>>nr_k;
    back_track(1);
}