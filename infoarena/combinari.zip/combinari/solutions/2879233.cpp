
#include<fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int a[15],x[15],n,i,m;
void afisare()
{for(int i=1;i<=m;i++)
g<<a[i]<<" ";
g<<'\n';
}
void bkp(int k)
{for(int i=1;i<=n;i++)
    {if(x[i]==0&&i>a[k-1])
        {x[i]=1;
            a[k]=i;
            if(k<=m)
            {if(k==m)
            afisare();
            else
                bkp(k+1);
            }
        x[i]=0;
        }
    }
}
int main()
{
    f>>n>>m;

bkp(1);

}
