#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k, sol[21];

void read(){
  fin>>n>>k;
}

bool verif(int len){
  for(int i = 1; i < len; i++)
    if(sol[i] == sol[len])
      return false;
  if(len > 1 && sol[len-1] > sol[len])
    return false;
  return true;
}

bool solution(int len){
  return len == k;
}

void print(int len){
  for(int i = 1; i <= len; ++i)
    fout<<sol[i]<<" ";
  fout<<'\n';
}

void bkt(int len){
  for(int i = 1; i <= n; ++i){
    sol[len] = i;
    if(verif(len)){
      if(solution(len))
        print(len);
      else
        bkt(len+1);
    }
  }
}

int main(){
  read();
  bkt(1);
}
