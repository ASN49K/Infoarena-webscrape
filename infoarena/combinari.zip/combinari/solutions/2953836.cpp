#include <bits/stdc++.h>

using namespace std;
ifstream in  ("combinari.in");
ofstream out("combinari.out");

#define maxN 18

int n,k;
int v[maxN+1];

void bkt(int pos){
    if(pos==k+1){
        for(int i=1;i<=k;i++){
            out<<v[i]<<" ";
        }
        out<<'\n';
    }
    else{
        for(int i=v[pos-1]+1;i<=n;i++){
            v[pos]=i;
            bkt(pos+1);
        }
    }
}

int main(){
    in>>n>>k;
    bkt(1);
}
