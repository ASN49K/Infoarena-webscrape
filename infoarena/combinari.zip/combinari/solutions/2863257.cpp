#include <bits/stdc++.h>
#define N 104

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k;
int v[N];

void Citire()
{
    fin >> n >> k;
}

void Back( int x, int a )
{
    int i;
    for( i=a + 1; i<=n; i++ )
    {
        v[x] = i;
        if( x == k )
        {
            for( int j = 1; j<=k; j++ )
                fout << v[j] << " ";
            fout << "\n";
        }
        else
        {
            Back( x + 1, i );
        }
    }
}

void Rezolvare()
{
    Back(1, 0);
}

int main()
{
    Citire();
    Rezolvare();
    //cout << sizeof( Lee ) / 1024.0 / 1024.0;
    return 0;
}
