#include <cstdio>
#include <vector>
using namespace std;

void consume(vector<bool>& taken, int largestPossibleValue) {
	for (int i = 1; i <= largestPossibleValue; i++) {
		if (taken[i]) {
			printf("%d ", i);
		}
	}
	printf("\n");
}

void back(int remainingElems, int N, vector<bool>& taken, int lastElem, vector<int>& currentSol) {
	if (remainingElems == 0) {
		consume(taken, N);
		return;
	}

	for (int nextElem = lastElem + 1; nextElem <= N; nextElem++) {
		if (!taken[nextElem]) {
			taken[nextElem] = true;
			currentSol.push_back(nextElem);
			back(remainingElems - 1, N, taken, nextElem, currentSol);
			taken[nextElem] = false;
			currentSol.pop_back();
		}
	}
}

int main() {
	freopen("combinari.in", "r", stdin);
	freopen("combinari.out", "w", stdout);

	int N, K;
	scanf("%d%d", &N, &K);
	vector<bool> taken(N + 1, false);
	vector<int> currentSol;
	currentSol.reserve(N);
	back(K, N, taken, 0, currentSol);
	return 0;
}