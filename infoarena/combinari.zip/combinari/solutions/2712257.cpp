#include <bits/stdc++.h>
#include <vector>
using namespace std;

//ifstream in("combinari.in");
//ofstream out("combinari.out");
int N,K;
//vector<int> sol(19,0);
int sol[199];
void afisare()
{
    for(int i=1;i<=K;i++)
        out << sol[i];
    out << endl;
}
void bkt(int poz,int x)
{
    for(int i=x;i<=N;i++){
        sol[poz] = i;
        if(poz<K)
            bkt(poz+1,i+1);
        if(poz==K)
            afisare();
    }
}

int main(){
    in >> N >> K;
    bkt(1,1);
    return 0;
}
