#include<fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");

int n,m;
int v[105];

void comb(int k){

    if(k==m+1){

        for(int i=1;i<=m;i++)
            cout<<v[i]<<' ';
        cout<<'\n';

    }

    for(int i=v[k-1]+1;i<=n;i++){

        v[k]=i;
        comb(k+1);

    }

}

int main(){

    cin>>n>>m;
    comb(1);

}
