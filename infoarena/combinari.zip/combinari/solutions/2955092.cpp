#include <fstream>
#define Nmax 20

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, k;
int v[Nmax];

void permutari(int pos)
{
    if(pos == k + 1)
    {
        for(int i = 1; i <= k; i++)
        {
            fout << v[i] << " ";
        }
        fout << '\n';
    }
    else
    {
        for(int val = v[pos - 1] + 1; val <= n; val++)
        {
            v[pos] = val;
            permutari(pos + 1);
        }
    }
}

int main()
{
    fin >> n >> k;

    permutari(1);

    return 0;
}
