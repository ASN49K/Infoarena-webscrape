#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int v[100];

int main()
{
    int n, k;
    cin >> n >> k;

    for(int i = k + 1; i <= n; i++)
        v[i] = 1;

    do
    {
        for(int i = 1; i <= n; i++)
            if(v[i] == 0)
                cout << i << ' ';
        cout << '\n';
    }while(next_permutation(v + 1, v + 1 + n));
}


