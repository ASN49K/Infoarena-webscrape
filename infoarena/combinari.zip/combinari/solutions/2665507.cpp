#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, x[20], p;

void afisare()
{
    for(int i = 1; i <= p; i++)
        g << x[i] << ' ';
    g << '\n';
}

bool valid(int k)
{
    if(x[k - 1] >= x[k])    return false;
    return true;
}

void backt(int k)
{
    for(int i = x[k - 1] + 1; i <= n; i++)
    {
        x[k] = i;
        if(valid(k))
        {
            if(k == p)    afisare();
            else        backt(k + 1);
        }
    }
}

int main()
{
    f >> n >> p;
    
    backt(1);
    return 0;
}