#include <bits/stdc++.h>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,p,k,i,as,ev,st[19];
void succesor()
{
    if(st[k]<n-p+k)
    {
        as=1;
        st[k]++;
    }

    else as=0;
}

void valid()
{
    ev=1;

    if(st[k]==st[k-1]) ev=0;

    if(k>1 && st[k]<st[k-1]) ev=0;
}

void back()
{
    k=1;
    st[k]=0;

    while(k>0) {

    succesor();
    if(as)
        valid();

    while(as && ev==0)
    {
        succesor();
        if(as)
            valid();
    }

    if(as)
    {
        if(k==p)
        {
            for(i=1;i<=p;i++)
                fout<<st[i]<<" ";
            fout<<endl;
        }

        else st[++k]=0;
    }

    else k--; }
}
int main()
{
    fin>>n>>p;
    back();

    return 0;
}
