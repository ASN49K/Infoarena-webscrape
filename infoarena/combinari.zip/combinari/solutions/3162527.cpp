#include<bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, l, s[20];
void afis(){
    for(int i=1; i<=l; i++) fout<<s[i]<<" ";
    fout<<"\n";
}
void bkt(int k, int val){
    for(int i=val; i<=n; i++){
        s[k] = i;
        if(k<l) bkt(k+1, i+1);
        else afis();
        s[k] = 0;
    }
}
int main(){
    fin>>n>>l;
    bkt(1, 1);
}
