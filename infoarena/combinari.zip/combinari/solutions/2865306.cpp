#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

const string myf = "combinari";
ifstream fin(myf + ".in");
ofstream fout(myf + ".out");

int n, k;
vector<int> a, tmp;
vector < vector<int> > ans;

void comb(int i) {
	if (tmp.size() == k) {
		for (auto i : tmp)
			fout << i << " ";
		fout << '\n';
		return;
	}
	for (; i <= n; ++i) {
		//cout << i;
		tmp.pb(a[i]);
		comb(i + 1);
		tmp.pop_back();
	}
}


int main() {

	fin >> n >> k;
	// cout << k;
	a.resize(n + 1);
	for (int i = 1; i <= n; ++i)
		a[i] = i;
	comb(1);

	fin.close();
	fout.close();
	return 0;
}