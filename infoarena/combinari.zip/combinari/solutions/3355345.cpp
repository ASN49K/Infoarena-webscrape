#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

void backtracking(int n, int k, int step, vector<int> &solution) {
  // check
  if (solution.size() == k) {
    for (int i = 0; i < k; i++)
      printf("%d ", solution[i]);
    printf("\n");
    return;
  }

  for (int i = step; i <= n; i++) {
    int value = i;

    /* DO */
    solution.push_back(value);

    backtracking(n, k, i + 1, solution);

    /* UNDO */
    solution.pop_back();
  }
}

int main(int argc, char *argv[]) {
  // int n, k;
  //  scanf("%d %d", &n, &k);

  // fisiere
  freopen("combinari.in", "r", stdin);
  freopen("combinari.out", "w", stdout);

  int n, k;
  if (scanf("%d %d", &n, &k) != 2)
    return 0;

  vector<int> domain;
  vector<int> solution;

  for (int i = 1; i <= n; i++)
    domain.push_back(i);

  backtracking(n, k, 1, solution);
  return 0;
}
