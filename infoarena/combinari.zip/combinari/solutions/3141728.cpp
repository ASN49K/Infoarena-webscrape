#include <bits/stdc++.h>

using namespace std;

int main() {
    ifstream fin("combinari.in");
    ofstream fout("combinari.out");

    int n; fin >> n;
    int k; fin >> k;
    vector<int> v(k + 1);
    int i = 1;
    while (i) {
        v[i]++;
        if (v[i] > n - (k - i)) {
            v[i--] = 0;
        } else if (i == k) {
            for (int j = 1; j <= k; ++j) {
                fout << v[j] << ' ';
            }
            fout << '\n';
        } else {
            v[i + 1] = v[i];
            ++i;
        }
    }

    return 0;
}