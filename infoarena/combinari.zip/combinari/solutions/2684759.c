#include <stdio.h>
#define NMAXX 18

FILE *fin, *fout;

int n, k, v[NMAXX];
void bkt( int pos ) {
    int i;
    if ( pos == k ) {
        for ( i = 0; i < k; i++ ) {
            fprintf( fout, "%d ", v[i] );
        }
        fputc( '\n', fout );
    } else {
        for ( i = v[pos - 1] + 1; i <= n; i++ ) {
            v[pos] = i;
            bkt( pos + 1 );
        }
    }
}

int main()
{
    fin = fopen( "combinari.in", "r" );
    fout = fopen( "combinari.out", "w" );
    fscanf( fin, "%d%d", &n, &k );
    bkt( 0 );
    fclose( fin );
    fclose( fout );
    return 0;
}
