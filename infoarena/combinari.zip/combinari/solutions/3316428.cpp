#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,m,x[19];
void afis()
{
    for(int i=1;i<=m;i++)
        g<<x[i]<<' ';
    g<<'\n';
}
void bt(int k)
{
    if(k<=m)
        for(int i=x[k-1]+1;i<=n-m+k;i++)
    {
        x[k]=i;
        bt(k+1);
    }
    else afis();
}
int main()
{
    f>>n>>m;
    bt(1);
    return 0;
}
