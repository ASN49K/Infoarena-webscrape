#include<fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,m,st[20],i,k=1;
bool valid, succesor;
int main()
{
    cin>>n>>m;
    while(k)
    {
        do{
            valid=1;
            if(st[k]<n)
            {
                st[k]++;succesor=1;
            }else succesor=0;
            if(succesor){
            for(i=1;i<k;i++)
            {
                if(st[k]==st[i]){
                    valid=0;break;}
            }}
        }while(succesor&&!valid);
        if(succesor)
        {
            if(k==m)
            {
                for(i=1;i<=m;i++)
                {
                    cout<<st[i]<<" ";
                }cout<<"\n";
            }
            else
            {
                k++;st[k]=st[k-1];
            }
        }
        else
        {
            k--;
        }
    }
}
