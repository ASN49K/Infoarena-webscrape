#include <bits/stdc++.h>
#define N 30

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int sol[N], n, m;
void afiseaza() {
	for (int i = 1; i <= m; ++i)
		fout << sol[i] << " ";
	fout << "\n";
}
void bkt(int k) {
	for (int i = sol[k-1]+1; i <= n; ++i) {
			sol[k] = i;
			if (k == m)
				afiseaza();
			else
				bkt(k + 1);
	}
}
int main() {
	fin >> n >> m;
	bkt(1);
	return 0;
}