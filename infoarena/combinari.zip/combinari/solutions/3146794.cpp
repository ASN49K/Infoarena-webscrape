#include <fstream>

using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int x[20],n,k;
void back(int pas)
{
    if(pas>k)
    {
        for(int i=1;i<=k;i++)
            cout<<x[i]<<" ";
        cout<<'\n';
    }
    else
    {
        for(int i=x[pas-1]+1;i<=n;i++)
        {
            x[pas]=i;
            back(pas+1);
        }
    }
}
int main()
{
    cin>>n>>k;
    back(1);
    return 0;
}
