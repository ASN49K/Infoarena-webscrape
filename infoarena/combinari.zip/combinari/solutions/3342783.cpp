#include <fstream>
#include <vector>
using namespace std;

vector<int> v;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void brojustletmenamethisfunctionnextbruh(int targ, int first, int n){
    if(v.size() == targ){
        for (int i = 0; i<v.size(); i++)
            fout<<v[i]<<' ';
        fout<<'\n';
        return;
    }

    for (int i = first; i<=n-targ+v.size()+1; i++){
        v.push_back(i);
        brojustletmenamethisfunctionnextbruh(targ, i+1, n);
        v.pop_back();
    }

    return;
}
int main(){
    int n, k;
    fin>>n>>k;
    brojustletmenamethisfunctionnextbruh(k, 1, n);
}