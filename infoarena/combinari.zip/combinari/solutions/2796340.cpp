#include <fstream>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

int n,k;
int v[20]={0};

void display(){
    for(int i=1;i<=k;i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

void combinari(int i){
    if(i>k){
        display();
        return;
    }
    else{
        for(v[i]=v[i-1]+1;v[i]<=n;v[i]++){
            combinari(i+1);
        }
    }
}

int main() {

    cin>>n>>k;

    combinari(1);
    return 0;
}
