#include <bits/stdc++.h>

using namespace std;

int n, m, a[18];

void bk(int k)
{
    if (k == n)
    {
        for (int i = 0; i < n; i++)
            cout << a[i] + 1 << ' ';
        cout << '\n';
        return;
    }
    for (int i = (k != 0 ? a[k - 1] + 1 : 0); i < m; i++)
    {
        a[k] = i;
        bk(k + 1);
    }
}

int main()
{
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);
    cin >> m >> n;
    bk(0);
    return 0;
}