#include <bits/stdc++.h>
using namespace std;
int v[100],n,m;

bool valid(int x)
{
	for(int i=1;i<x;i++)
	if(v[i]==v[x])return 0;
	return 1;
}
void afisare(int y)
{
	for(int i=1;i<=y;i++)
	cout<<v[i]<<' ';
	cout<<'\n';
}
void combinari(int k)
{
	for(int i=v[k-1]+1;i<=n;i++)
	{
		v[k]=i;
	//	if(valid(k))
		{
			if(k==m)afisare(k);
			else combinari(k+1);
		}
	}
	
}

int main()
{
	ifstream("combinari.in");
	ofstream("combinari.out");
	cin>>n>>m;
	combinari(1);
	return 0;
}
