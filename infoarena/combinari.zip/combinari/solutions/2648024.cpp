#include <iostream>
#include <fstream>
using namespace std;
ifstream be("combinari.in");
ofstream ki("combinari.out");
bool ellen(int a[],int n)
{
    for(int i=0;i<n-1;i++)
        if(a[i]>=a[i+1])return false;
    return true;
}
void bt(int n,int k,int j,int a[])
{
    if(n==j)
    {
        if(ellen(a,n)==true){
        for(int x=0;x<n;x++)
            ki<<a[x]<<" ";
           ki<<"\n";}

    }
    else {
        for(int i=1;i<=k;i++)
        {

            a[j]=i;
            bt(n,k,j+1,a);
        }
    }
}
int main()
{
    int a[1000000];
    int n,k;
    be>>k>>n;
    bt(n,k,0,a);

    return 0;
}
