#include<fstream>
std::ofstream G("combinari.out");
int n,m,x[19],i;
void B(int k)
{
    int i;
    if(k==m+1) {
        for(i=1;i<=m;G<<x[i++]<<' ');
        G<<'\n';
    } else
        for(i=x[k-1]+1;i<=n;x[k]=i,B(k+1),++i);
}
int main()
{
    return std::ifstream("combinari.in")>>n>>m,B(1),0;
}
