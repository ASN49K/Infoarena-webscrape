#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

const int NMax = 18;

int n, k;
int st[NMax + 5];

void Read(){
    fin >> n >> k;
}

void Print(){
    for (int i = 1; i <= k; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

void Backtracking(int level){
    for (int i = st[level - 1] + 1; i <= n; i++){
        st[level] = i;
        if (level == k)
            Print();
        else
            Backtracking(level + 1);
    }
}

int main(){
    Read();
    Backtracking(1);
    return 0;
}
