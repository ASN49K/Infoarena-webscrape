#include<fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int N,K,x[19],i;
int w()
{
    for(int i=1;i<=K;++i)
        g<<x[i]<<' ';
    g<<'\n';
}
int b(int k)
{
    if(k==K+1)
        w();
    else
        for(int i=x[k-1]+1;i<=N;++i)
            x[k]=i,b(k+1);
    }
int main()
{
    f>>N>>K,b(1);
    return 0;
}
