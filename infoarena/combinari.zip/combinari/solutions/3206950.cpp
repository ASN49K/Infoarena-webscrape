#include<fstream>
using namespace std;
ifstream F("combinari.in");
ofstream G("combinari.out");
int n,m,a[19];
void A(int k)
{
    int i;
    if(k-1==m) {
        for(i=1;i<k;G<<a[i++]<<' ');
        G<<'\n';
    } else
        for(i=a[k-1]+1;i<=n-m+k;a[k]=i,A(k+1),++i);
}
int main()
{
    return F>>n>>m,A(1),0;
}
