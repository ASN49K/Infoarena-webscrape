#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

void print(int n, int *permutari, FILE **write)
{
	for (int i = 0; i < n; i++)
		if(i == n - 1)
			fprintf(*write, "%d\n", permutari[i]);
		else
			fprintf(*write, "%d ", permutari[i]);
}

bool contains(int n, int *permutari, int number)
{
	for (int i = 0; i < n; i++)
		if (permutari[i] == number)
			return true;
	return false;	
}

void permutari(int n, int k1, int k, int *permutari1, FILE **write)
{
	if(k <= k1 + 1)
	{
		if ( k == k1 + 1)
			print(k1, permutari1, write);
		else
		{
			for (int i = 1; i<= n; i++)
				if(contains(k-1, permutari1, i) == false && (k == 1 || permutari1[k-2] < i ) )
				{
					permutari1[k-1] = i;
					permutari(n, k1, k+1, permutari1, write);
				}

			
		}

	}

}


int main(int argc, char const *argv[])
{
	FILE *read = fopen("permutari.in", "r");
	FILE *write = fopen("permutari.out", "w");

	int number;
	int cate;

	fscanf(read, "%d %d", &number, &cate);

	int *permutari1 = (int *) calloc(number, sizeof(int));

	permutari(number, cate, 1, permutari1, &write);

	free(permutari1);

	fclose(read);
	fclose(write); 
	
	return 0;
}