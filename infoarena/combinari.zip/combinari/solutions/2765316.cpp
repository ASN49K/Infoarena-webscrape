#include <iostream>
#include <fstream>
using namespace std;
int m,n,x[19];
ifstream f("combinari.in");
ofstream g("combinari.out");
void afis(int k)
{
    int i;
    for (i=1; i<=k; i++)
        g<<x[i]<<' ';
    g<<'\n';
}
int valid(int k)
{
    int i;
    for (i=1; i<k; i++)
        if (x[i]==x[k])
            return 0;
    return 1;
}
void BT()
{
    int k=1;
    x[k]=0;
    while (k>0)
        if (x[k]<m)
        {
            x[k]++;
            if (valid(k))
                if (k==n)
                    afis(k);
                else
                {
                    k++;
                    x[k]=x[k-1];
                }
        }
        else
            k--;
}

int main()
{
    int i;
    f>>m>>n;
    BT();
}
