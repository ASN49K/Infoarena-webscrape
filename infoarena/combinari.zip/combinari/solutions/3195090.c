#include <stdio.h>
#include <stdlib.h>

#define MAXN 18

FILE *fin, *fout;

int v[ MAXN ];
int n, k;

void backt( int pos )
{
    int x;
    if( pos ==k + 1 )
    {
        for( x = 1; x <= k; x++ )
        {
            fprintf( fout, "%d ", v[ x ] );
        }
        fputc( '\n', fout );
    }
    else
    {
        for( x = 1 + v[ pos - 1 ]; x <= n; x++ )
        {
            v[ pos ] = x;
            backt( pos + 1 );
        }
    }
}

int main()
{
    fin = fopen( "combinari.in", "r" );
    fscanf( fin, "%d%d", &n, &k );
    fclose( fin );

    fout = fopen( "combinari.out", "w" );
    backt( 1 );
    fclose( fout );
    return 0;
}
