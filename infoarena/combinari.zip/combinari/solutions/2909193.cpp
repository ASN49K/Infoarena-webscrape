#include <fstream>

using namespace std;

ifstream in ("combinari.in");
ofstream out ("combinari.out");

const int max_size = 19;

int a[max_size], c[max_size], n, p;

void afis ()
{
    for (int i = 1; i <= p; i++)
    {
        out << a[i] << " ";
    }
    out << '\n';
}

void bkt (int k, int last)
{
    for (int i = last + 1; i <= n; i++)
    {
        if (c[i] == 0)
        {
            a[k] = i;
            c[i] = 1;
            if (k == p)
            {
                afis();
            }
            else
            {
                bkt(k + 1, i);
            }
            c[i] = 0;
        }
    }
}

int main ()
{
    in >> n >> p;
    bkt(1, 0);
    in.close();
    out.close();
    return 0;
}
