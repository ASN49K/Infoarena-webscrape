#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, m;
int sol[20], f[21];

void bck(int pas)
{
    if(pas==m+1)
    {
        for(int i=1;i<=m;i++)
        {
            fout<<sol[i]<<" ";
        }
        fout<<"\n";
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            sol[pas]=i;
            if(f[i]==0&&sol[pas-1]<sol[pas])
            {
                f[i]=1;
                bck(pas+1);
                f[i]=0;
            }
        }
    }
}

int main()
{
    fin>>n>>m;
    bck(1);
}
