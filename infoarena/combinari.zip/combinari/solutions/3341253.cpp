#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int N, K;
int v[20];

void btk(int i, int start) {
    if(i > K) {
        for(int j = 1; j <= K; j++) fout << v[j] << " ";
        fout << "\n";
        return;
    }
    for(int j = start; j <= N; j++) {
        v[i] = j;
        btk(i + 1, j + 1);
    }
}

int main() {
    fin >> N >> K;
    btk(1, 1);
}
