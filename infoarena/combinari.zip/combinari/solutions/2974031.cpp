#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int x[20] , n , p;

void Afis(int k)
{
    for(int j = 1 ; j <= k ; j ++)
        cout << x[j] << " ";
    cout << endl;
}

void back(int k){
    for(int i = x[k-1] + 1 ; i <= n - k + p ; ++ i)
    {
        x[k] = i;
        if(k == p)
            Afis(k);
        else
            back(k + 1);
    }
}
int main(){
    cin >> n >> p;
    back(1);
    return 0;
}
