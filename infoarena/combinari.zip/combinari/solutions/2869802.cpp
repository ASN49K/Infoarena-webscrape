#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k, st[20], viz[20];

void Afis(int k)
{
    for (int i = 1; i <= k; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Combinari(int top)
{
    if (top > k) Afis(top - 1);
    else
        for (int i = st[top - 1] + 1; i <= n - k + top; i++)
        {
            st[top] = i;
            Combinari(top + 1);
        }
}

int main()
{

    fin >> n >> k;
    Combinari(1);
    fin.close();
    fout.close();

    return 0;
}
