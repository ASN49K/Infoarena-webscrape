#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int bloc[20], v[20];
int n, k;

void backtrack(int pos){
    if(pos == k + 1){
        for(int i = 1; i <= k; ++i)
            fout << v[i] << " ";
        fout << "\n";
        return;
    }
    for(int i = pos; i <= n; ++i){
        if(!bloc[i]){
            v[pos] = i;
            bloc[i] = 1;
            if(v[pos] > v[pos - 1])
                backtrack(pos + 1);
            v[pos] = 0;
            bloc[i] = 0;
        }
    }
}

int main()
{
    fin >> n >> k;
    backtrack(1);
    return 0;
}
