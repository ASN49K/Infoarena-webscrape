#include<cstdio>
#define M 2000000
int n,p,s[19],t,o;
char r[M];
int A()
{
  	int s=0;
  	for(;r[t]<'0'||r[t]>'9';t++);
  	for(;r[t]>='0'&&r[t]<='9';t++)
  		s=s*10+r[t]-'0';
  	return s;
}
void S(int x)
{
    if(x>9)
        r[l++]=49,r[l++]=x+38;
    else
        r[l++]=x;
    r[l++]=32;
}
void B(int k)
{
	int i;
    if(k-1==p)
    {
        for(i=1;i<=p;i++)
            S(s[i]);
        r[l++]=10;
    }
    else
        for(i=s[k-1]+1;i<=n-p+k;i++)
            s[k]=i,B(k+1);
}
int main()
{
    freopen("combinari.in","r",stdin),freopen("combinari.out","w",stdout),fread(r,1,30,stdin),n=A(),p=A(),B(1);
}
