#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>
#include <stack>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
vector<int> sol;
vector<int> visited;
int n, k, nr;
void back(int u) {
    if(nr == k) {
        for(int i = 1; i <= k; i++) {
            fout<<sol[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for(int i = u; i <= n; i++) {
        if(visited[i] == 0) {
            nr++;
            sol[u] = i;
            visited[i] = 1;
            back(u + 1);
            visited[i] = 0;
            nr--;
        }
    }
}

int main() {
    fin>>n>>k;
    nr = 0;
    sol.assign(k + 1, 0);
    visited.assign(n + 1, 0);
    back(1);
    return 0;
}