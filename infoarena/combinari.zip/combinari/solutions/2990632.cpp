#include <bits/stdc++.h>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int x[20],k,n;
void afisare(){
    for(int i=1;i<=k;++i)
        fout<<x[i]<<" ";
    fout<<'\n';
}
void bk(int pas){
    for(int i=x[pas-1]+1;i<=n-k+pas;++i){
        x[pas]=i;
        if(pas<k)
            bk(pas+1);
        else
            afisare();
    }
}
int main()
{
    fin>>n>>k;
    bk(1);
    return 0;
}
