#include<fstream>
using namespace std;
ifstream in ("combinari.in");
ofstream out("combinari.out");
int s[20];
int n,m;
int valid(int k)
{
    for(int i=1;i<k;i++)
        if(s[k]==s[i])
        return 0;
    if(s[k]<s[k-1] && k>1)
        return 0;
    return 1;
}
int solutie(int k)
{
    return k==m;
}
void afisare()
{
    for(int i=1;i<=m;i++)
        out<<s[i]<<" ";
    out<<endl;
}
void bk(int k)
{
    for(int i=1;i<=n;i++)
    {
        s[k]=i;
        if(valid(k))
        {
            if(solutie(k))
            {
                afisare();
            }
            else
                bk(k+1);
        }
    }
}
int main()
{
    in>>n>>m;
    bk(1);
}
