#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int s[19],k,n,m;
void tipar(int k)
{
    int i;
    for(i=1; i<=k; i++)
        g<<s[i]<<" ";
    g<<'\n';
}
void back(int k)
{
    int i;
    for(i=s[k-1]+1; i<=n; i++)
    {
        s[k]=i;
            if(k==m)
                tipar(k);
            else
                back(k+1);
    }

}
int main()
{
    f>>n>>m;
    back(1);
    return 0;
}
