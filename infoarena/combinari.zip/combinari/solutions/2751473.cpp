#include <bits/stdc++.h>

using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int st[25], n, k;

void Afis (int n)
{
    for (int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back (int top)
{
    if (top == k + 1)
    {
        Afis (top - 1);
    }
    for (int i = 1; i <= n; i++)
        if (i > st[top - 1])
        {
            st[top] = i;
            Back(top+ 1);
        }
}

int main()
{
    fin >> n >> k;
    Back(1);

    return 0;
}
