#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

void explore(int n, int k, int curr, vector<int> &answer) {
    if(k == 0) {
        for(int i = answer.size() - 1; i >= 1; i --)
            out << answer[i] << " ";
        out << "\n";
        return;
    }

    if(n - curr + 1 < k)
        return;

    answer[k] = curr;
    explore(n, k - 1, curr + 1, answer);
    answer[k] = 0;
    explore(n, k, curr + 1, answer);
}

int main() {
    int n, k;
    in >> n >> k;
    vector<int> aux(k + 1, 0);
    explore(n, k, 1, aux);

    return 0;
}