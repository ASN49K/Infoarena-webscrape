#include <bits/stdc++.h>

using namespace std;

ifstream fin ("rotund.in");
ofstream fout ("rotund.out");

int n,x;
int k=0;
vector <int> v;

bool rotund(int x)
{
    int nr=log10(x)+1;
    if(nr%2==0)
    {
        int p=1;
        for(int i=1;i<=nr/2;i++) p=p*10;

        int a=x%p*p+x/p;
        cout<<a;
    }
    else
    {

    }
    return true;
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x;
        if(rotund(x)==true)
        {
            k++;
            v.push_back(x);
        }
    }
    for(int i=1;i<=v.size();i++) cout<<v[i]<<' ';

    return 0;
}
