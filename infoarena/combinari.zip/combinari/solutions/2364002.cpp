#include <iostream>
#include <fstream>

using namespace std;
ifstream fi("combinari.in");
ofstream fo("combinari.out");

int N, K;
bool viz[20];
int rez[20];

void Comb(int pas)
{
    if(pas == K + 1)
    {
        for(int i = 1; i <= K; ++i)
            fo << rez[i] << " ";
        fo << "\n";
    }
    else
    {
        for(int i = max(rez[pas-1], 1); i <= N; ++i)
        {
            if(!viz[i])
            {
                viz[i] = 1;
                rez[pas] = i;
                Comb(pas + 1);
                viz[i] = 0;
            }
        }
    }
}

int main()
{
    fi >> N >> K;
    Comb(1);
}
