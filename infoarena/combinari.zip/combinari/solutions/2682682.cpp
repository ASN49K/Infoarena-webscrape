#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[19],N,K;

void afisare()
{
    for(int i=1;i<=K;i++)
    {
        fout<<v[i]<<" ";
    }
    fout<<'\n';
}

int sol(int p)
{
    for(int i=1;i<p;i++)
    {
        if(v[i]==v[p] || v[p]<v[i])
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    fin>>N>>K;
    int p=1;
    v[p]=0;
    while(p>0)
    {
        if(p<=K)
        {
            if(v[p]<N)
            {
                v[p]++;
                if(sol(p))
                {
                    if(p==K)
                    {
                        afisare();
                    }
                    else
                    {
                        p++;
                        v[p]=0;
                    }
                }
            }
            else
            {
                p--;
            }
        }
    }
    return 0;
}
