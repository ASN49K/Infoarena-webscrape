#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, k, a[19];

void print()
{
    for(int i = 1; i <= k; i++)
        fout << a[i] << " ";
    fout << "\n";
}

void bkt(int poz)
{
    for(int i = (poz == 1 ? 1 : a[poz - 1] + 1); i <= n; i++)
    {
        a[poz] = i;
        if(poz == k)
            print();
        else
            bkt(poz + 1);
    }
}

int main()
{
    fin >> n >> k;
    bkt(1);

    return 0;
}
