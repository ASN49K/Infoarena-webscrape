#include <bits/stdc++.h>
#define MOD 1999999973
#define ull unsigned long long

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[1000];
int n,m;

bool ok(int k){
    for(int i = 1; i < k; i++){
        if(v[i] == v[k])
            return 0;
    }
    return 1;
}

void backt(int k){
    int i;
    for(i = v[k-1]+1; i <= n; i++){
        v[k] = i;
        if(ok(k)){
            if(k < m){
                backt(k+1);
            }else{
                for(int j = 1; j <= m; j++){
                    fout<<v[j]<<" ";
                }
                fout<<endl;
            }
        }
    }
}

int main()
{
    fin>>n>>m;
    backt(1);
    return 0;
}
