#include <cstdio>

int n, m, c[20];
char buffer[10000005];
int bufferSize;

void backTracking(int k)
{
	if (k - 1 == m) {
		for (int i = 1; i <= m; ++i) {
			if (c[i] < 10) buffer[bufferSize++] = c[i] + '0';
			else {
				buffer[bufferSize++] = c[i] / 10 + '0';
				buffer[bufferSize++] = c[i] % 10 + '0';
			}
			buffer[bufferSize++] = ' ';
		}
		buffer[bufferSize++] = '\n';
	}
	else for (int i = c[k - 1] + 1; i <= n - m + k; ++i) {
		c[k] = i;
		backTracking(k + 1);
	}
}

int main()
{
	FILE *in, *out;
	in = freopen("combinari.in", "r", stdin);
	out = freopen("combinari.out", "w", stdout);

	scanf("%d%d", &n, &m);
	fclose(in);

	backTracking(1);

	printf("%s", buffer);
	fclose(out);

    return 0;
}
