#include <fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
using pii = pair<int,int>;
int n , k , ind , l , ans[19];
bool tk[19];
void b()
{
    ++ind;
    if(ind > k)
    {
        for(int i = 1 ; i <= k ; i++)
        {
            cout << ans[i] << ' ';
        }
        cout << '\n';
        ind--;
        return;
    }
    int og = l;
    for(int i = l+1 ; i <= n-k+ind ; i++)
    {
            l = i;
            ans[ind] = i;
            b();
            l = og;
    }
    ind--;
}
signed main()
{
    cin >> n >> k;
    b();
    return 0;
}
