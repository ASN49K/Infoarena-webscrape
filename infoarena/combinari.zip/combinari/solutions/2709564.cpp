#include <iostream>
#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int n,t,a[9],fr[9];
void bacK(int k)
{
    if(k==n+1)
    {
        for(int j=1;j<=n;j++)
        {
            out<<a[j]<<' ';
        }out<<'\n';
        return;
    }
    for(int i=a[k-1]+1;i<=t;++i)
    {
        a[k]=i;
        bacK(k+1);
    }
}
int main()
{
    in>>t>>n;
    bacK(1);
    return 0;
}
