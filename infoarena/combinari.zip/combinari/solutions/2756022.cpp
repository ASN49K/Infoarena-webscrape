#include <fstream>

using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,k,st[19];
void afisare(int k){
for(int i=1;i<=k;i++)
    cout<<st[i]<<" ";
cout<<"\n";

}
void backtrack(int top){

if(top==k+1)
    afisare(k);
else{

    for(int i=st[top-1]+1;i<=n;i++){
        st[top]=i;
    backtrack(top+1);
    }


}

}
int main()
{
    cin>>n>>k;
    backtrack(1);
    return 0;
}
