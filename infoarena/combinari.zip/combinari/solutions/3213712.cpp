#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int st[10];
bitset <10> v;
int n,k;


void Fish(int n){
    for(int i=1;i<=n;i++) fout << st[i] << " ";
    fout << "\n";
}

void Back(int top){
    if(top==k+1){
        Fish(top-1);
        return;
    }
    for(int i=st[top-1];i<=n;i++){
        if(!v[i]){
            v[i]=1;
            st[top]=i;
            Back(top+1);
            v[i]=0;
        }
    }
}

int main()
{
    fin >> n >> k;
    st[0]=1;
    Back(1);
    return 0;
}
