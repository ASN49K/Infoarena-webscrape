#include <bits/stdc++.h>

using namespace std;

int n, k, c[20];

void afisare() {
    for (int i = 1; i <= k; i++) {
        cout << c[i] << " ";
    }
    cout << endl;
}

void bkt(int p) {
    int i;
    for (i = c[p - 1]+1; i <= n-k+p; i++) {
        c[p] = i;
        if (p == k) {
            afisare();
        }
        else {
            bkt(p+1);
        }
    }
}

int main() {
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);
    cin >> n >> k;
    bkt(1);
}