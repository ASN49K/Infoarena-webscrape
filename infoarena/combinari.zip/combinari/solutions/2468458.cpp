// Combinariiiiii.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//#include "pch.h"
#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int v[20];
int k, n;


void bkt(int lungime) {
	if (lungime > k) {
		for (int i = 1; i < lungime; ++i)
			fout << v[i] << " ";
		fout << "\n";
	}
	else {
		for (int i = v[lungime - 1] + 1; i <= n; i++) {
			v[lungime] = i;
			bkt(lungime+1);
		}
	}
}


int main()
{
	fin >> n >> k;
	bkt(1);
    std::cout << "Hello World!\n"; 
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
