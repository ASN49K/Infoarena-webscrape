#include <cstdio>

using namespace std;

int n, m, sol[20];

void afis()
{
    for(int i=1; i<=m; i++)
    {
        printf("%d ", sol[i]);
    }
    printf("\n");
}

void bkt(int k)
{
    if(k == m+1)
    {
        afis();
        return;
    }
    for(int v=sol[k-1]+1; v<=n; v++)
    {
        sol[k]=v;
        bkt(k+1);
    }
}

int main()
{

    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);

    scanf("%d %d", &n, &m);
    bkt(1);

    return 0;
}
