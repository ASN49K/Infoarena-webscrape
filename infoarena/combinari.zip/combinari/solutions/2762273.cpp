#include <iostream>
#include <fstream>

using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
void backtrack_komb(int n, int k, int l, int m, int megold[])
{
    if(l==k+1){
        for(int i=1; i<=k; i++) out<<megold[i]<<" ";
        out<<endl;
    }
    else{
        for(int i=m; i<=n-k+l; i++){
            megold[l]=i;
            backtrack_komb(n,k,l+1,i+1,megold);
        }
    }
}

int main()
{
    int n, k;
    in>>n; in>>k;
    int megold[k+1];
    backtrack_komb(n, k, 1, 1, megold);
    return 0;
}
