#include <fstream>
#include <vector>
using namespace std;

int n,m,cnt;

ifstream cin("combinari.in");
ofstream cout("combinari.out");
bool valid(vector<int> & v)
{
    int k=v.size();
    if(k<=1)
        return true;
    return v[k-1] > v[k-2];
}

void back(vector<int> v)
{
    if(!valid(v))
        return;
    if(v.size()==m)
    {
        for(int x : v)
            cout << x << " ";
        cout << endl;

        return;
    }
    for(int i=1;i<=n;i++)
    {
        v.push_back(i);
        back(v);
        v.pop_back();
    }
}
int main()
{
    cin >> n >> m;
    vector<int> vec;
    back(vec);
    return 0;
}
