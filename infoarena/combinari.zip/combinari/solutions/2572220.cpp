#include <fstream>
using namespace std;
int n, x[20], m;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

void back (int k)
{
    if(k==m+1){
        for(int i=1;i<=m;i++){
            fout<<x[i]<<" ";
        }
        fout<<"\n";
    }
    else{
        for(int i=x[k-1]+1;i<=n;i++){
            x[k] = i;
            back(k+1);
        }
    }
}

int main () {
    fin>>n>>m;
    back(1);

    return 0;
}
