#include <stdio.h>

#define MAXN 18

FILE *fin, *fout;

int n, k;
int v[MAXN];

void bkt(int pos){
   if(pos==k+1){
      for(int i=1;i<=k;i++){
         fprintf(fout, "%d ", v[i]);
      }
      fputc('\n', fout);
   }
   else{
      for(int i=v[pos-1]+1;i<=n;i++){
         v[pos]=i;
         bkt(pos+1);
      }
   }
}

int main()
{
   fin=fopen("combinari.in", "r");
   fscanf(fin, "%d%d", &n, &k);
   fclose(fin);
   fout=fopen("combinari.out", "w");
   bkt(1);
   fclose(fout);
   return 0;
}
