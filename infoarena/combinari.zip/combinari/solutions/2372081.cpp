#include <iostream>
#include<fstream>
#include<fstream>
using namespace std;
int n,p;
int stiva[100];
ifstream in("combinari.in");
ofstream out("combinari.out");
void comb(int here,int len)
{
    if(len==p)
    {
        for(int i=0; i<len; i++)
        {
            out<<stiva[i]<<" ";
        }
        out<<'\n';
        return;
    }
    for(int i=here+1; i<=n; i++)
    {
        stiva[len]=i;
        comb(i,len+1);
    }



}
int main()
{
    in>>n>>p;
    comb(0,0);
    return 0;
}
