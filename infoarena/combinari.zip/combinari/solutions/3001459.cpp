#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

//int a[20][20];
//
//int Back(int n, int k)
//{
//    for(int i = 0; i<n; i++)
//    {
//        a[i][0] = a[i][i] = 1;
//    }
//    for(int i = 2; i<=n; i++)
//    {
//        for(int j = 1; j < i; j++)
//        {
//            a[i][j] = a[i-1][j-1] + a[i-1][j];
//        }
//    }
//    return a[n][k];
//}

int x[100];

void afis(int n)
{
    for(int i = 1; i<=n; i++)
    {
        cout<<x[i]<< ' ';
    }
    cout<<'\n';
}

void backT3(int n, int pas, int k)
{
    for(int i = x[pas-1]+1; i<=n-k+pas; i++){
        x[pas] = i;
        if(pas == k)afis(pas);
        else backT3(n,pas+1,k);
    }
}


int main()
{
    int n,k;cin>>n>>k;
    backT3(n,1,k);
    return 0;
}
