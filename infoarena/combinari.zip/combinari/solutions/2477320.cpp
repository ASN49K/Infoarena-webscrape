#include <bits/stdc++.h>
using namespace std;

ifstream in("combinari.in");
ofstream out ("combinari.out");

int v[20],n,k;

void bkt(int l)
{
    int i;
    if(l==k)
    {
        for(i=1; i<=k; i++)
            out<<v[i]<<" ";
        out<<'\n';
    }
    else
    {
        for(i=v[l]+1; i<=n; i++)
        {
            v[l+1]=i;
            bkt(l+1);
        }
    }
}

int main()
{
    in>>n>>k;
    bkt(0);
    return 0;
}
