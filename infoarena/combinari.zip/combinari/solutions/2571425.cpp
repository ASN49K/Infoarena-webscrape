#include <fstream>
#include <vector>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

void comb(int n, int k, vector <int> &terms, vector <bool> &viz)
{
    if(terms.size() == k) {
        for(auto x: terms) {
            cout << x << " ";
        }
        cout << "\n";
        return;
    }
    int val = 1;
    if(terms.size()) {
        val = terms.back() + 1;
    }
    for(int i = val; i <= n; ++i) {
        if(viz[i] == 0) {
            viz[i] = 1;
            terms.push_back(i);
            comb(n, k, terms, viz);
            terms.pop_back();
            viz[i] = 0;
        }
    }
}

int main()
{
    int n, k;
    cin >> n >> k;
    vector <int> v;
    vector <bool> viz(n + 1, false);
    comb(n, k, v, viz);
    return 0;
}
