#include <iostream>
#include <fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
const int N=20;
int n,k,c[N];
void bkt(int);
int main()
{
    f >> n >>k;
    bkt(1);
    return 0;
}
void bkt(int poz)
{
    if(poz==k+1)
    {
        for(int i=1; i<=k; i++)
            g<<c[i]<<' ';
        g<<'\n';
        return;
    }
    for(int i=c[poz-1]+1; i<=n; i++)
    {
            c[poz]=i;
            bkt(poz+1);
    }

}
