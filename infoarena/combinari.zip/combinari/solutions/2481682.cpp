#include <iostream>
#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");
int n, k, sol[20];

void afisare() {
    for(int i=0; i<k; i++)
        g << sol[i] << ' ';
    g << '\n';
}

void bkt(int poz, int start) {
    if(poz == k) afisare();
    else {
        for(int i=start; i<=n; i++) {
                sol[poz] = i;
                bkt(poz+1, i+1);
            }
    }
}

int main()
{
    f >> n >> k;

    bkt(0, 1);

    return 0;
}
