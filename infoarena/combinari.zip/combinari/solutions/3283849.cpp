#include <bits/stdc++.h>
#define MOD 104659
using namespace std;
///aproapeperm
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int N, K;
int st[20], top;

void Back(int top)
{
    if (top == K + 1)
    {
        for (int i = 1; i < top; i++)
            fout << st[i] << " ";
        fout << "\n";
    }
    else for (int i = st[top - 1] + 1; i <= N; i++)
         {
             st[top] = i;
             Back(top + 1);
         }
}

int main()
{
    fin >> N >> K;
    Back(1);
    return 0;
}
