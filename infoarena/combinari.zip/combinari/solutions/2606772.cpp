#include<iostream>
#include<fstream>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,ap[19],k,st[19];
void afisare()
{
    for(int i=1;i<=k;i++)
    {
        g<<st[i]<<" ";
    }
    g<<endl;
}
int validare(int i, int top)
{
    if(ap[i]==0 && i>st[top-1])
        return 1;
    else
        return 0;
}
void bkt(int top)
{
    if(top==k+1)
    {
        afisare();
    }
    else
    {
        for(int i=1;i<=n;i++)
            if(validare(i,top))
            {
                st[top]=i;
                ap[st[top]]=1;
                bkt(top+1);
                ap[st[top]]=0;
            }
    }
}
int main()
{
    f>>n>>k;
    bkt(1);
}
