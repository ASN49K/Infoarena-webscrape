#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
int n,k;
int v[20];
inline void combinari(int cnt)
{
    if(cnt>k)
    {
        for(int i=1; i<=k; i++)
            cout<<v[i]<<" ";
        cout<<'\n';
    }
    else
    {
        for(int i=v[cnt-1]+1; i<=n; i++)
        {
            v[cnt]=i;
            combinari(cnt+1);
        }
    }
}

int main()
{
    ifstream cin("combinari.in");
    ofstream cout("combinari.out");
    cin>>n>>k;
    combinari(1);


    return 0;
}
