#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;

int n, k;
vector<int> sir;
vector<bool> vizitat;

void backtrack(int curr, ofstream& fout) {
	if (curr == k) {
		for (int i = 0; i < k; i++) {
			fout << sir[i] << " ";
		}
		fout << endl;
	}

	for (int i = 1; i <= n; i++) {
		if (vizitat[i] == false && sir[curr - 1] < i) {
			vizitat[i] = true;
			sir[curr] = i;
			backtrack(curr + 1, fout);
			vizitat[i] = false;
		}
	}
}

int main() {
	ifstream fin("combinari.in");
	ofstream fout("combinari.out");
	
	fin >> n >> k;
	sir.resize(n);
	vizitat.assign(n + 1, false);
	backtrack(0, fout);

	fin.close();
	fin.close();
	
	return 0;
}