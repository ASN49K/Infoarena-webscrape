#include <fstream>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout("combinari.out");
int n,k,x[25];
int verif(int pas)
{
    if(x[pas]<=x[pas-1]&&pas>=1)
        return 0;
    return 1;
}
void backtrack(int pas)
{
    if(pas==k+1)
    {
        for(int i=1;i<=k;i++)
            fout<<x[i]<<" ";
        fout<<"\n";
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            x[pas]=i;
            if(verif(pas)==1)
                backtrack(pas+1);
        }
    }
}
int main ()
{
    fin>>n>>k;
    backtrack(1);
}
