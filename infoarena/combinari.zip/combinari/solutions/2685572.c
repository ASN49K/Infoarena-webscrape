#include <stdio.h>
#include <stdlib.h>
#define KMAX 18

FILE *fin, *fout;
int v[KMAX];
int n, k;

void bkt( int p ) {
  int i;
  if( p == k + 1 ) {
    for( i = 1; i <= k; i++ )
      fprintf( fout, "%d ", v[i] );
    fputc( '\n', fout );
  }
  else {
    for( i = v[p-1] + 1; i <= n; i++ ) {
      v[p] = i;
      bkt( p + 1 );
    }
  }
}

int main() {
    fin = fopen( "combinari.in", "r" );
    fscanf( fin, "%d%d", &n, &k );
    fclose( fin );
    fout = fopen( "combinari.out", "w" );
    bkt( 1 );
    fclose( fout );
    return 0;
}
