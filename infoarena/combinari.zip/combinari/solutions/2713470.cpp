#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("combinari.in");
ofstream g ("combinari.out");

int n,m,a[20];
int fr[20];

int verific()
{
    for(int i=1;i<=n;i++)
    {
        fr[i]=0;
    }
    for(int i=1;i<=m;i++)
    {
        fr[a[i]]++;
        if(fr[a[i]]==2 || a[i]<a[i-1])
            return false;
    }
    return true;
}

void afisez()
{
    for(int i=1;i<=m;i++)
        g<<a[i]<<" ";
    g<<"\n";
}

void fun(int nivel)
{
    if(nivel==m+1)
    {
        if(verific()==true)
            afisez();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            a[nivel]=i;
            fun(nivel+1);
        }
    }
}

int main()
{
    f>>n;
    f>>m;
    fun(1);
    return 0;
}
