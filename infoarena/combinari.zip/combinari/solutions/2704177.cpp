#include <stdio.h>

const int MAX_SIZE = 19;

FILE * f;
int n, k;
int comb[MAX_SIZE];

void write_combinations(int crnt_pos) {
    if (crnt_pos == k + 1) {
        for (int i = 1; i <= k; i++) {
            fprintf(f, "%d ", comb[i]);
        }
        fprintf(f, "\n");
    }

    for (int value = comb[crnt_pos - 1] + 1; value <= n; value++) {
        comb[crnt_pos] = value;
        if (n - value < k - crnt_pos) {
            break;
        }
        write_combinations(crnt_pos + 1);
    }
}

int main() {
    f = fopen("combinari.in", "r");
    fscanf(f, "%d%d", &n, &k);
    fclose(f);

    f = fopen("combinari.out", "w");
    write_combinations(1);
    fclose(f);

    return 0;
}