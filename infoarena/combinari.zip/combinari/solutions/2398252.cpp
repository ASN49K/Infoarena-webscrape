#include<iostream>
#include<fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int result[19];
void combinations(int n,int k,int index)
{
    if(index==k+1)
    {
        for(int i=1; i<index; i++)
            out<<result[i]<<" ";
        out<<'\n';

    }
    for(int i=1; i<=n; i++)
    {
        if(result[index-1]<i)
        {
            result[index]=i;
            combinations(n,k,index+1);
        }
    }
}
int main()
{

    int n,k;
    in>>n>>k;
    combinations(n,k,1);





}
