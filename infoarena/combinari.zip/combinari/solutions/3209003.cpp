#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <queue>
#include <vector>
#include <set>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");


const int nmax = 20;
int n,m;
int v[nmax];
int total = 1;

void citire()
{
    f >> n >> m;
}

void afis()
{
    for (int i = 1; i <= m; i++)
    {
        g << v[i] << ' ';
    }
    g << '\n';
}

void bt(int k)
{
    if (k > m)
    {
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        v[k] = i;
        if (v[k] > v[k - 1])
        {
            if (k == m)
            {
                afis();
            }
            bt(k+1);
        }
    }
}

void solve()
{
    bt(1);
}

int main()
{
    citire();
    solve();
}