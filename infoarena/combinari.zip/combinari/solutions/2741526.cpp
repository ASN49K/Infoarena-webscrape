#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <stack>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int sol[20];
int N, K;

int is_sol_valid(int k) {
  for (int i = 1; i < k; ++i) {
    if (sol[i] == sol[k]) {
      return 0;
    }
  }
  return 1;
}

void print_sol() {
  for (int i = 1; i <= K; ++i) {
    g << sol[i] << ' ';
  }
  g << '\n';
}

void bt(int index, int value) {
  if (value > N) {
    return;
  }
  if (index > K) {
    return;
  }
  if (!is_sol_valid(index)) {
    return;
  }

  sol[index] = value;

  if (index == K) {
    print_sol();
  }

  bt(index + 1, value + 1);
  bt(index, value + 1);
}

int main() {
  f >> N >> K;
  bt(1, 1);
}
