#include <bits/stdc++.h>


using namespace std;
int n,k,x[30],f[30];
ifstream fin("combinari.in");
ofstream fout("combinari.out");
void back(int poz){
    if(poz==k+1){
        for(int i=1;i<=k;i++)
            fout<<x[i]<<" ";
        fout<<'\n';
    }
    else{
        for(int i=x[poz-1]+1;i<=n;i++)
        if(!f[i]){
            f[i]=1;
            x[poz]=i;
            back(poz+1);
            f[i]=0;
        }
    }
}
int main(){
    fin>>n>>k;
    back(1);
    return 0;
}
