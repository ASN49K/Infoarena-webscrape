#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int n, m, x[20];

void afis()
{
    for(int i = 1; i <= m; i++)
        fout << x[i] << ' ';
    fout << '\n';
}

/*

void backt()
{
    int k = 1;
    x[1] = 0;
    while(k > 0)
     if(x[k] < n - m + k)
     {
         x[k] ++;
         if(k == m)
            afis();
         else
         {
             k++;
             x[k] = x[k - 1];
         }
     }
     else
        k --;
}

*/

void backt(int k)
{
    if(k <= m)
        for(int i = x[k - 1] + 1; i <= n - m + k; i++)
        {
            x[k] = i;
            backt(k + 1);
        }
    else
        afis();
}



int main()
{
    fin >> n >> m;
    // x[0] = 0;
    backt(1);
    fin.close();
    fout.close();

    return 0;
}
