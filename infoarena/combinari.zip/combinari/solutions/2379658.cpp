#include<iostream>
#include<fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int comb[19];
int n,k;

void back(int lv,int last)
{
    if(lv>k)
    {
        for(int i=1;i<lv;i++)
            out<<comb[i]<<" ";
        out<<'\n';
        return;
    }
    for(int i=last+1;i<=n;i++)
    {
       comb[lv]=i;
       back(lv+1,i);
    }

}

int main()
{
    in>>n>>k;
    back(1,0);
    in.close();
    out.close();
    return 0;
}
