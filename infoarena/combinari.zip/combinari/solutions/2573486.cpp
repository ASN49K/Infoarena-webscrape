#include <fstream>
#define ios ios_base::sync_with_stdio(false);

using namespace std;

ifstream cin ("combinari.in");
ofstream cout ("combinari.out");

int n,k,s[18];

void citire(){
    cin>>n>>k;
}

bool valid(int x){
    for (int i=1;i<x;i++) if (s[i]>=s[x]) return false;
    return true;
}

bool solutie(int x){
    if (x==k) return true;
    return false;
}

void afis(){
    for (int i=1;i<=k;i++) cout<<s[i]<<" ";
    cout<<'\n';
}

void comb(int j){
    for (int i=1;i<=n;i++){
        s[j]=i;
        if (valid(j))
            if (solutie(j)) afis();
            else comb(j+1);
    }
}

int main()
{
    ios;
    cin.tie(0);
    cout.tie(0);
    citire();
    comb(1);
    return 0;
}
