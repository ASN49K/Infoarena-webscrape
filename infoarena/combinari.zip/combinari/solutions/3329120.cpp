#include <iostream>
#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, m, x[16];

bool valid(int k)
{
    return (x[k - 1] < x[k]);
}

void afis()
{
    for(int i = 1; i <= m; i++)
        g << x[i] << " ";
    g << endl;
}

void backt(int k)
{
    if(k <= m)
        for(int i = 1; i <= n; i++)
        {
            x[k] = i;
            if(valid(k))
                backt(k + 1);
        }
    else
        afis();
}


int main()
{
    f >> n >> m;
    x[0] = 0;
    backt(1);
    f.close();
    g.close();
    return 0;
}
