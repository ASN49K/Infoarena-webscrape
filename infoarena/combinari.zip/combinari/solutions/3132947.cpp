#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
const int N = 20;
int n,k,s[N];
void bkt(int);
int main()
{
    f>>n>>k;
    bkt(1);

    return 0;
}
void bkt(int p)
{
    /// conditia de oprire
    if(p==k+1)
    {
        for(int i=1;i<=k;i++)
            g<<s[i]<<' ';
        g<<'\n';
        return;
    }
    /// generez solutie partiala
    for(int v=s[p-1]+1;v<=p+n-k;v++)
    {
        s[p]=v;
        bkt(p+1);/// avansez la pozitia urmatoare
        /// apoi revin la pozitia mea
    }
}
