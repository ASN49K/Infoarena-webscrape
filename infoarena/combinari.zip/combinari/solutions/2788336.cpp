#include <fstream>

using namespace std;

const int NMAX = 18;

ifstream in("combinari.in");
ofstream out("combinari.out");

int n, k;

int solCrt[1 + NMAX];

void back(int pozCrt, int valAnt)
{
  if (pozCrt == k + 1)
  {
    for (int i = 1; i <= k; i++)
      out << solCrt[i] << ' ';
    out << '\n';
  }
  else
  {
     for (int i = valAnt + 1; i <= n; i++)
     {
       solCrt[pozCrt] = i;
       back(pozCrt + 1, i);
     }
  }
}

int main()
{
  in >> n >> k;

  back(1, 0);

  return 0;
}
