#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, p, st[100], k, as, ev, i;
void succesor()
{
    if (st[k]<n-p+k)
    {
        st[k]++;
        as=1;
    }
    else as=0;
}
void valid()
{
    int i; ev=1;
    for (i=1; i<k; i++)
        if (st[i]==st[k])
            ev=0;
    if (k>1&&st[k]<st[k-1])
        ev=0;

}

void back()
{
    k=1;
    st[k]=0;
    while(k>0)
    {
        do{
            succesor();
            if (as)
                valid();

          }while(as&&!ev);
        if (as)
            if(k==p)
              {
                for(i=1; i<=p; i++)
                    fout<<st[i]<<" ";
                fout<<endl;
              }
            else
              {
                k++;
                st[k]=0;
              }
            else
                k--;
    }
}

int main()
{
    fin>>n>>p;
    back();
}
