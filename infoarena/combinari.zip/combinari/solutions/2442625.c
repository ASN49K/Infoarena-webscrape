#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main() {
	FILE *fp = fopen("text.in", "a+t");

	int lungime = 0;
	int nr_cuv = 0;
	int ok = 0;
	char c;
	while ((c = fgetc(fp)) != EOF)
		if (c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z') {
			lungime++;
			if (!ok) {
				nr_cuv++;
				ok = 1;
			}
		}
		else
			ok = 0;

	fclose(fp);
	int res = lungime / nr_cuv;

	fp = fopen("text.out", "w+t");
	fprintf(fp, "%d", res);
	fclose(fp);
	return 0;
}