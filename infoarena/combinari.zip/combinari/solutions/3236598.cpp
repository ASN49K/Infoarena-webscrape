#include <fstream>
#define cin fin
#define cout fout

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, m, x[100];

void afis()
{
    for(int i = 1; i <= m; i++)
        cout << x[i] << ' ';
    cout << "\n";
}

void bt(int k)
{
    if(k <= m)
        for(int i = x[k - 1] + 1; i <= n - m + k; i++)
        {
            x[k] = i;
            bt(k + 1);
        }
    else
        afis();
}

int main()
{
    cin >> n >> m;
    bt(1);
    return 0;
}
