#include <iostream>
#include <fstream>
using namespace std;
int ams,ev,n,st[20],kk;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

void tipar(int niv)
{
    for(int i=1;i<=niv;i++)
    {
        fout<<st[i]<<" ";
    }
    fout<<'\n';
}


int pune_val(int niv)
{
    int ok=0;
    if(niv<=kk&&st[niv]<n)
    {
        ok=1;st[niv]++;
    }
    return ok;
}

int validare(int niv)
{
    int i,ok;ok=1;
    for(i=1;i<niv;i++)
        if(st[i]==st[niv])
            ok=0;
    return ok;
}

int solutie(int niv)
{
    if(niv==kk) return 1;
    return 0;
}



int main()
{
    fin>>n>>kk;
    int k=1;
    while(k>0)
    {
        do{ams=pune_val(k);
        if(ams==1)
            ev=validare(k);
        }while(ams==1&&ev==0);
        if(ams==1&&ev==1)
        {
            if(solutie(k)==1) tipar(k);
            else
            {
                st[k+1]=st[k];
                k++;
            }
        }
        else
            k--;
    }
    return 0;
}
