#include <fstream>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

const int NMAX=18;

bool numere_luate[1+NMAX];

int n,k;

void back(int index, int index2)
{
    if(index<=k)
    {
        int i;
        for(i=index2+1;i<=n;i++)
        {
            numere_luate[i]=1;
            back(index+1,i);
            numere_luate[i]=0;
        }
    }
    else
    {
        int i;
        for(i=1;i<=n;i++)
        {
            if(numere_luate[i]==1)
            {
                g<<i<<' ';
            }
        }
        g<<'\n';
    }
}

int main()
{

    f>>n>>k;

    back(1,0);

    return 0;
}
