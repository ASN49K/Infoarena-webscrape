#include <fstream>

using namespace std;

int v[ 20 ], f[ 20 ];

int n, k;

ifstream fin ( "combinari.in" );
ofstream fout ( "combinari.out" );

void permutare ( int i ){
    
    if ( i == k ){
        
        for ( i = 1; i <= k; i++ )
            fout << v[ i ] << " ";
        fout << "\n";
    }
    
    else {
        
        for ( int j = v[ i ] + 1; j <= n; j++ ){
            
            if ( f [ j ] == 0 ){
                
                v[ i + 1 ] = j;
                f [ j ] = 1;
                
                permutare ( i + 1 );
                
                f [ j ] = 0;
                v[ i + 1 ] = 0;
            }
        }
    }
}

int main( ) {
    
    int i;
    
    fin >> n >> k;
    
    for ( i = 1; i <= n; i++ )
        v[ i ] = i;
    
    permutare ( 0 );
    
    return 0;
}
