#include<fstream>
#include<iostream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, p,a[20];
bool v[20];

void BK(int k)
{
	if (k == p + 1)
	{
		for (int i = 1; i <= p; ++i)
		{
			g << a[i] << ' ';
		}
		g << '\n';
		return;
	}
	for (int i = a[k - 1] + 1; i <= n; ++i)
	{
		if (!v[i])
		{
			v[i] = true;
			a[k] = i;
			BK(k + 1);
			a[k] = 0;
			v[i] = false;
		}
	}
}

int main()
{
	f >> n >> p;
	BK(1);
}