// Ionascu George-Razvan, 324CA

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

vector<int> a, visited;

void bkt(int n, int k, int cnt, int start) {
    if (cnt == k) {
        for (int i = 0; i < k; i++) {
            fout << a[i] << " ";
        }
        fout << "\n";
    }

    for(int i = start; i <= n; i++) {
        if (visited[i] == 0 && a[cnt - 1] < i) {
            visited[i] = 1;
            a[cnt] = i;

            bkt(n, k, cnt + 1, start + 1);

            a[cnt] = 0;
            visited[i] = 0;
        }
    }
}

int main() {
    int n, k;
    fin >> n >> k;

    visited.resize(n + 1, 0);
    a.resize(n + 1, 0);

    bkt(n, k, 0, 1);

    return 0;
}