#include <iostream>
#include <fstream>

using namespace std;

int v[100],n,p;
ifstream f("combinari.in");
ofstream g("combinari.out");

int verif(int k)
{
    for(int i=1;i<k;i++)
        if(v[i]==v[k] || v[i]>=v[k])
            return 0;
    return 1;
}

void bkt(int n,int p,int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k]=i;
        if(verif(k))
        {
            if(k==p)
            {
                for(int i=1;i<=p;i++)
                    g<<v[i]<<" ";
                g<<endl;
            }
            else
            {
                bkt(n,p,k+1);

            }
        }
    }
}
int main()
{
    f>>n>>p;
    bkt(n,p,1);

    cout << "Hello world!" << endl;
    return 0;
}
