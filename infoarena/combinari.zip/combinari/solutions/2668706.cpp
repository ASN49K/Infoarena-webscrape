#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k, m, x[10];

bool ok(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] <= x[i])
            return 0;
    return 1;
}

void BK(int k)
{
    for(int i = k; i <= n; i++)
    {
        x[k] = i;
        if(ok(k))
        {
            if(k == m)
            {
                for(int i = 1; i <= k; i++)
                    fout << x[i] <<' ';
                fout<<'\n';
            }
            else
                BK(k+1);
        }
    }
}

int main()
{
    fin >> n >> m;
    BK(1);
    return 0;
}
