#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "combinari.in"
#define OUTFILE "combinari.out"

#define VMAX 20

short n, m, v[VMAX];
bool apare[VMAX];

void afisare(){

    for(int i = 1; i <= m; ++i){

        cout << v[i] << " ";

    }

    cout << '\n';

}

void back(int k){

    if(k <= m){

        for(int i = v[k - 1] + 1; i <= n - m + k; ++i){

            if(apare[i] == 0){

                apare[i] = 1;
                v[k] = i;

                back(k + 1);

                apare[i] = 0;

            }

        }

    }
    else{
        afisare();
    }

}

void solve(){

    cin >> n >> m;

    back(1);

}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}