#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int n, k, f[19];
bool viz[19];

inline void bkt(int a, int nr)
{
    if (nr == k)
    {
        for (int i = 1; i <= k; ++i)
            out << f[i] << " ";
        out << '\n';
    }
    else
    {
        for (int i = a + 1; i <= n; ++i)
        {
            if (!viz[i])
            {
                viz[i] = 1;
                f[nr + 1] = i;
                bkt(i, nr + 1);
                viz[i] = 0;
            }
        }
    }
}

int main()
{
    in >> n >> k;
    for (int i = 1; i <= n - k + 1; ++i)
    {
        f[1] = i;
        viz[i] = 1;
        bkt(i, 1);
        viz[i] = 0;
    }
}
