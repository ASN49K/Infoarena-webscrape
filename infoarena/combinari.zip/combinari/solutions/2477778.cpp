#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n;
int x[17];


void afisare(int k, int t){
    if (k == t) {
        for (int i = 1; i <= k; i++) {
        g << x[i] << " ";
    };

    g << "\n";
    }
    
}

void bt(int k, int t)
{
    for(int i = x[k - 1] + 1; i <= n - t + k; i++)
    {
        x[k] = i;
        if (k == t) afisare(k, t);
        if (x[k] < n) {
            bt(k + 1, t);
        }
    }
}

int main()
{
    int m;
    f >> n >> m;
    bt(1, m);
    return 0;
}