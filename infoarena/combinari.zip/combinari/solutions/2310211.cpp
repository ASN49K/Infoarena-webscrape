#include<iostream>
#include<fstream>
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int st[9], k, n;

void Afisare()
{
    int i, j;
    for (j = 1; j <= k; j++)
    {
	fout << st[j] << " ";
    }
    fout << "\n";
}

void Back(int top)
{
   int i;
   if (top == k+1)
	Afisare();
   else
	for (i = st[top-1]+1; i <= n-k+top; i++)
	   {
		st[top] = i;
		Back(top+1);
	   }
}

int main ()
{
   fin >> n; fin >> k;
   Back(1);
   return 0;
}
