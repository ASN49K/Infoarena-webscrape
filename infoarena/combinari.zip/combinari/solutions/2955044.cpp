#include <bits/stdc++.h>

using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
int n;
void perm(vector<int>outp,int k,int poz,int prev)
{
    //v[prev]=1;
    outp.push_back(prev);
    for(int i=prev+1;i<=n;i++)
    {
            if(poz+1==k)
            {
                for(int j=1;j<outp.size();j++)
                {
                    out<<outp[j]<<" ";
                }
                out<<i<<'\n';
                continue;
            }
            perm(outp,k,poz+1,i);
    }
}
int main()
{
int k;
in>>n>>k;
vector<int>p;
perm(p,k,0,0);
    return 0;
}
