#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k;
int v[20];

void afis(){
    for(int i=1;i<=k;++i)
        g<<v[i]<<" ";
    g<<'\n';
}
void bkt(int pas){
    for(int i=v[pas-1]+1;i<=n-k+pas;++i){
        v[pas]=i;
        if(pas<k)
            bkt(pas+1);
        else
            afis();
    }
}
int main()
{
    f>>n>>k;
    bkt(1);
    return 0;
}
