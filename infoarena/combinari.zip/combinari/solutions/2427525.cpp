#include <fstream>
#include <string>
#include <vector>
using namespace std;
typedef unsigned char uchar;
typedef unsigned short ushort;
string const inFile = "combinari.in";
string const outFile = "combinari.out";
ifstream Read(inFile);
ofstream Write(outFile);
void Print(vector<uchar> &vec) {
    for (uchar i = 0; i < vec.size(); ++i) {
        Write << ushort(vec[i]) << ' ';
    }
    Write << '\n';
}
void Generate(vector<uchar> &vec, unsigned const n, uchar const pos, uchar const value) {
    if (pos == vec.size()) {
        Print(vec);
        return;
    }
    if (value > n) {
        return;
    }
    for (uchar i = value; i <= n; ++i) {
        vec[pos] = i;
        Generate(vec, n, pos + 1, vec[pos] + 1);
    }
}
void CloseFiles(ifstream &Read, ofstream &Write) {
    Read.close();
    Write.close();
}
int main() {
    unsigned n;
    Read >> n;
    unsigned k;
    Read >> k;
    vector<uchar> vec(k, 0);
    Generate(vec, n, 0, 1);
    CloseFiles(Read, Write);
    return 0;
}
