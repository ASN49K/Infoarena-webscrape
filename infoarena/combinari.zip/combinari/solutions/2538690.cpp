#include <fstream>

std::ifstream f("combinari.in");
std::ofstream g("combinari.out");

int n,m,a[20],fr[20];

void back(int k){
    
    if(k == m + 1){
        
        for(int i = 1;i <= m;++i)
            g << a[i] << ' ';
        
        g << '\n';
        
    }else{
        
        for(int i = 1;i <= n;++i){
            if(fr[i] == 0 && (k == 1 || a[k - 1] < i)){
                
                a[k] = i;
                fr[i] = 1;
                
                back(k + 1);
                
                fr[i] = 0;
            }
        }
    }
    
}

int main(){
    
    f >> n >> m;
    
    back(1);
    
    return 0;
}
