#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
#include <fstream>
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
#define MAXN 100001

int sir[20];
void generare(int lastTermen, int length, int k, int n) {
    if (length == k) {
        for (int i = 0; i < k; ++i) {
            fout << sir[i] << ' ';
        }
        fout << '\n';
        return;
    }
    if (lastTermen == n + 1)
        return;
    for (int i = lastTermen + 1; i <= n; ++i) {
        sir[length] = i;
        generare(i, length + 1, k, n);
    }
}
void solve() {
    int n, k;
    fin >> n >> k;
    generare(0, 0, k, n);
}
int main() {
    fin.tie(NULL);
    std::ios_base::sync_with_stdio(false);
    solve();
}
