#include <bits/stdc++.h>

int afis[18];

int freq[19];

int n,m;

FILE*fo;

inline void afs(){
    for(int i=0;i<m;i++)
        fprintf(fo,"%d ",afis[i]);
    fprintf(fo,"\n");
}

void fnc(int k,int last){
    if(k==m)
        afs();
    else {
        for(int i=1;i<=n;i++){
            if(freq[i]==0 && i>last){
                freq[i]=1;
                afis[k]=i;
                fnc(k+1,i);
                freq[i]=0;
            }
        }
    }
}

int main()
{
    FILE*fi;
    fi=fopen("combinari.in","r");
    fo=fopen("combinari.out","w");
    fscanf(fi,"%d%d",&n,&m);
    fnc(0,-1);
    fclose(fi);
    fclose(fo);
    return 0;
}
