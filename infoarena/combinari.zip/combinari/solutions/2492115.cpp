#include <fstream>
#include <vector>
#include <iostream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, m;
int viz[20], val[20];
vector<int> c;

void comb(int i, int k){
    if(k==m+1){
        for(int j=1;j<k;j++)
            fout<<val[j]<<' ';
        fout<<'\n';
        return;
    }
    for(;i<=n-m+k;i++)
        if(!viz[i]){
            viz[i] = 1;
            val[k] = i;
            comb(i, k+1);
            viz[i] = 0;
        }
}

int main() {


    fin>>n>>m;
    comb(1, 1);

    return 0;
}