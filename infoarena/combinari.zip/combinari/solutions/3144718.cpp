#include <fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int v[19];
int lungime, lungime2;
bool used[19];
void bkt(int k){
    if (k == lungime2 + 1){
        for (int i = 1; i <= lungime2; i++){
            cout << v[i] << " ";
        }
        cout << '\n';
        return;
    }
    for (int i = v[k-1] + 1; i <= lungime; i++){
        if (!used[i]){
            used[i] = true;
            v[k] = i;
            bkt(k+1);
            used[i] = false;
        }
    }
}
int main(){
    cin >> lungime >> lungime2;
    bkt(1);
    return 0;
}