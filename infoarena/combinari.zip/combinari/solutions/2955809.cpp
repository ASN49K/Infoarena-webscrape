#include <iostream>
#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int v[10], n, k;
void bkt(int poz){
    int i, nr;
    if(poz == k + 1){
        for(i = 1; i <= k; i++){
            out << v[i] << " ";
        }
        out << '\n';
    }
    else{
        for(nr = v[poz - 1] + 1; nr <= n; nr++){
            v[poz] = nr;
            bkt(poz + 1);
        }
    }
}

int main()
{
    in >> n >> k;
    bkt(1);
    return 0;
}
