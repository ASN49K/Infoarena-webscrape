#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in"); ofstream fout("combinari.out");

int k;

void comb(int n, int t, int l, string s){
    string u;
    
    for(int i=l+1; i<=n; i++){
        u=s+to_string(i)+" ";
        if( (t+1)<k ){comb(n, t+1, i, u);}
        else{fout<<u<<"\n";}
    }
    
} 

int n;


int main() {
fin>>n>>k;
string s;
comb(n, 0, 0, s);
}