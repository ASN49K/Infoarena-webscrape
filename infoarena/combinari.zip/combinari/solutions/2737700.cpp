#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

const int max_n = 20;

int n, k;

int st[max_n];

void print() {
  for (int i = 1; i <= k; i++) {
    out << st[i] << " ";
  }
  out << "\n";
}

void bkt(int p) {
  for (int i = st[p - 1] + 1; i <= n; i++) {
    st[p] = i;
    if (p == k) {
      print();
    } else {
      bkt(1 + p);
    }
  }
}

int main() {
  in >> n >> k;
  bkt(1);
  return 0;
}
