#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int x[20],n,i,p;

int valid(int k)
{
    int i;
    for(i=1;i<k;i++)
        if(x[i]==x[k])
        return 0;
    return 1;
}

void back(int k)
{
        for(int i=x[k-1]+1;i<=n;i++)
        {
            x[k]=i;
            if(valid(k))
                if(k==p)
            {
                for(int j=1;j<=p;j++)
                    g<<x[j]<<" ";
                g<<endl;
            }
            else
                back(k+1);
        }
}
int main()
{
    f>>n>>p;
    back(1);
    return 0;
}
