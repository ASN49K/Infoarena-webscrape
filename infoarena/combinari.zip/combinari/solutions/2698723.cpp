#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, p, v[20];

void afisare(int k)
{
    int i;
    for (i = 1; i <= k; i++) fout << v[i] << " ";
    fout << endl;
}
void BK(int k)
{
    int i;
    for (i = v[k - 1] + 1; i <= n; i++) 
    {
        v[k] = i;
        if (k==p) 
            afisare(k); 
        else
            BK(k + 1);
    }
}

int main() 
{
    fin >> n >> p;
    BK(1);
    return 0;
}

