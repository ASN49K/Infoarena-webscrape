#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int rez[19];
int n,k;
ofstream g("combinari.out");
void backtracking(int st)
{
    if(st==k+1)
    {
        for(int i=1;i<=k;i++)
            g<<rez[i]<<' ';
        g<<'\n';
    }
    else
    {
        int nr=n-rez[k]+1;
        while(rez[k]<=n)
        {
            backtracking(st+1);
            for(int i=st;i<=k;i++)
                rez[i]++;
        }
        for(int i=st;i<=k;i++)
            rez[i]-=nr;
    }

}

int main()
{
    ifstream f("combinari.in");
    f>>n>>k;
    f.close();
    for(int i=1;i<=k;i++)
        rez[i]=i;
    backtracking(1);
    g.close();
    return 0;
}
