#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, k, i, out[20];
bool check (int val, int a)
{
    for (int i = 1; i < a; i++)
        if (out[i] == val)
            return 0;
    return 1;
}
void backtrack (int a, int mval)
{
    for (int i = mval; i <= n; i++)
    {
        if (check(i, a))
        {
            out[a] = i;
            if (a == k)
            {
                for (int j = 1; j <= k; j++)
                    fout << out[j] << ' ';
                fout << '\n';
            }
            else
                backtrack(a+1, i+1);
        }
    }
}
int main()
{
    fin >> n >> k;
    backtrack(1, 1);
    return 0;
}
