#include <bits/stdc++.h>

using namespace std;

const int len = 100;
int n, k, v[len];

void bkt(int x) {
    if (x == k) {
        for (int i = 1; i <= k; i++)
            cout << v[i] << " ";
        cout << "\n";
    }
    else
        for (int i = v[x] + 1; i <= n; i++) {
            v[x + 1] = i;
            bkt(x + 1);
        }
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);

    cin >> n >> k;
    bkt(0);
}
