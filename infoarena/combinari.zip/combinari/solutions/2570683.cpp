#include <iostream>
#include <fstream>
using namespace std;
int v[25],i,nr,n,k;
ifstream in("combinari.in");
ofstream out("combinari.out");
void rezolva(int nr)
{ int i;
    if (nr<=k)
    {
        for (i=v[nr-1]+1; i<=n; i++)
        {
            v[nr]=i;
            rezolva(nr+1);
        }
    }
    else
    {
        for (i=1; i<=k; i++)
            out<<v[i]<<" ";
        out<<"\n";
    }
}
int main()
{
    in>>n>>k;
    rezolva(1);
}
