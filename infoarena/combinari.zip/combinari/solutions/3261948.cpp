#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");

int N, K, v[25];

void afisare()
{
    for(int i=1; i<=K; i++)
        g << v[i]<<" ";
    g <<'\n';
}

bool ebun(int k)
{
    if(k == 1)
        return 1;
    if(v[k-1] >= v[k])
        return 0;
    return 1;
}

void bectrec(int k)
{
    for(int i=1; i<=N; i++)
    {
        v[k] = i;
        if(ebun(k))
            if(k == K)
                afisare();
            else
                bectrec(k + 1);
    }
}

int main()
{
    f >> N >> K;
    bectrec(1);
}
