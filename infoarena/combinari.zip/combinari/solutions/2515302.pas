var rs:array[0..20] of longint;
        n,k:longint;
procedure backtrack(step:longint);
var i:longint;
begin
if step=k then
        begin
        for i:=1 to k do
                write(rs[i],' ');
        writeln;
        end
else
        begin
        for i:=rs[step]+1 to n do
                begin
                rs[step+1]:=i;
                backtrack(step+1);
                end;
        end;
end;

begin
assign(input,'combinari.in');reset(input);
assign(output,'combinari.out');rewrite(output);
readln(n,k);
backtrack(0);
close(input);
close(output);
end.