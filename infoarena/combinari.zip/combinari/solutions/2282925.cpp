#include <fstream>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");

int s[20];
 int n,k;
void com(int x)
{
    if(x==k)
    {
        for(int i=1;i<=k;i++)
          g<<s[i]<<" ";
        g<<'\n';
    }
    else
    {
        for(int i=s[x]+1;i<=n;i++)
        {
            s[x+1]=i;
            com(x+1);
        }
    }
}

int main()
{

    f>>n>>k;
    com(0);
    f.close();
    g.close();
    return 0;
}
