use std::{fs::File, io::BufWriter, vec};
#[allow(unused_imports)]
use std::io::{BufRead, BufReader, Read, Write};

const FILE: &'static str = "combinari";

fn bkt(pas: usize, &n: &usize, &k: &usize, v: &mut Vec<usize>, fout: &mut BufWriter<File>) {
    if pas != k {
        let last = if v.len() > 0 { v[v.len() - 1] } else { 0 };
        for i in last + 1..=n {
            v.push(i);
            bkt(pas + 1, &n, &k, v, fout);
            v.pop();
        }
    } else {
        for x in v {
            write!(fout, "{} ", x).unwrap();
        }
        write!(fout, "\n").unwrap();
    }
}

fn main() {
    let mut fin = BufReader::new(File::open(format!("{}.in", FILE)).unwrap());
    let mut fout = BufWriter::new(File::create(format!("{}.out", FILE)).unwrap());

    let mut input = String::new();
    fin.read_line(&mut input).unwrap();

    let [n, k] = input.trim().split_ascii_whitespace().map(|x| x.parse::<usize>().unwrap()).collect::<Vec<usize>>()[..] else {
        panic!();
    };

    bkt(0, &n, &k, &mut vec![], &mut fout);
}