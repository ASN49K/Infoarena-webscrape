#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int perm[8];
bool cif[8];
void permutare(int n , int k, int nr)
{
    int i;
    if(nr>=n)
    {
        for(i=0; i<k; i++)
            fout<<perm[i]<<" ";
        fout<<"\n";
    }
    else
    {
        for(perm[nr]=1; perm[nr]<=n; perm[nr]++)
        {
            if(cif[perm[nr]]==0)
            {
                cif[perm[nr]]=1;
                permutare(n , nr+1);
                cif[perm[nr]]=0;
            }
        }
    }
}
int main()
{
    int n , k;
    fin>>n>>k;
    permutare(n, k, 0);
    return 0;
}
