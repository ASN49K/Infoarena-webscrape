#include <bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int a[20], n, K;
/// v[i] = 1, daca i este deja pus in a[], i=1..n
/// v[i] = 0, altfel

void afisare(int k)
{
    for(int i = 1;i <= k;i++)
        fout << a[i] << " ";
    fout << "\n";
}

void gen(int k)
{
    if (k == K + 1) afisare(K);
    else for (int i = 1 + a[k - 1]; i <= n; i++)
        {
            a[k] = i;
            gen(k + 1);
        }
}

int main()
{
    fin >> n >> K;
    gen(1);
    return 0;
}
