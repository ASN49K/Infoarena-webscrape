#include <fstream>
#define MAX 22
using namespace std;
int n,k,st[MAX];

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void backtrack(int pas){
    if(pas == k+1){
        for(int i = 1; i <= k; i++){
            fout << st[i] << " ";
        }
        fout << "\n";
    }else{
        for(int i = st[pas-1]+1; i <= n; i++){
            st[pas] = i;
            backtrack(pas+1);
        }
    }
}

int main()
{
    fin >> n >> k;
    backtrack(1);
    return 0;
}
