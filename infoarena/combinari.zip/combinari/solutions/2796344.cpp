#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

const int MAXN = 100001;
int sol[20] ;
int n,k;

void build(int lastTermen, int length) {
    /// base condition
    if (length == k) {
        for (int i = 0; i < k; ++i) {
            cout << sol[i] << ' ';
        }
        cout << '\n';
        return;
    }
    if (lastTermen == n + 1)
        return;

    /// recursive function
    for (int i = lastTermen + 1; i <= n; ++i) {
        sol[length] = i;
        build(i, length + 1);
    }
}

void display()
{
    for (int i = 1; i <= k; ++i)
        cout << sol[i] << " ";
    cout << '\n';
}
/// sol n : 10 k : 5
/// 0 1 2 3 4 5 6 7 8 9 10
///   1 2 3 4 5
///   1 2 3 4 6
void combi(int i)
{
    ///base condition
    if (i > k)
        display();
    else /// recursive
        for (sol[i] = sol[i - 1] + 1; sol[i] <= n; sol[i]++)
            combi(i + 1);
}

int main() {
    //cin.tie(NULL);
    //std::ios_base::sync_with_stdio(false);
    cin >> n >> k;
    //build(0, 0);
    combi(1);
    return 0;
}
