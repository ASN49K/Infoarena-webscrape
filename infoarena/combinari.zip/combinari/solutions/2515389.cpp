#include <algorithm>
#include<bits/stdc++.h>
using namespace std;
ifstream fin("combinari.in");ofstream fout("combinari.out");
int n,k;int ar[18];
void combin(long int ln){

if(ln>k){
    for(int i=1;i<=k;++i)fout<<ar[i]<<' ';fout<<endl;
}

   {
    for(int i=ar[ln-1]+1;i<=n;++i){
        ar[ln]=i;combin(ln+1);
    }
}
}


int main(){
fin>>n>>k;

combin(1);
}
