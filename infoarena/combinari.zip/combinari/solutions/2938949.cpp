#include <fstream>
using namespace std;

ofstream cout("combinari.out");
ifstream cin("combinari.in");

char mat[20][20];
int x[20];
int n, m;

void backtrack(int pas){
    if(pas == n + 1){
        for(int i = 1;i<=n;i++){
            cout << x[i] << ' ';
        }
        cout << endl;
    }else{
        for(int i = x[pas-1] + 1;i<=m;i++){
            x[pas] = i;
            backtrack(pas+1);
        }
    }
}

int main(void){
    cin >> m >> n;
    backtrack(1);
}
