#include <bits/stdc++.h>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,m;
void afiseaza(int x)
{
    for(int j=1,k=1<<(n-1);j<=n;j++,k/=2)
    {
        if(k&x)
            g<<j<<' ';
    }
    g<<'\n';
}
int main()
{
    f>>n>>k;
    m=(1<<n)-1;
    for(int i=m;i>=1;i--)
        if(__builtin_popcount(i)==k)
            afiseaza(i);
    return 0;
}
