#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int perm[20];
int fol[20];

int n, k;

void combinari(int a)
{
    if(a==k+1)
    {
        int sem=0;
        for(int i=1; i<=k-1; i++)
            if(perm[i]>perm[i+1])
            {
                sem=1;
                break;
            }
        if(sem==0)
        {
            for(int i=1; i<=k; i++)
                out<<perm[i]<<" ";
            out<<'\n';
        }
    }

    for(int j=1; j<=n; j++)
    {
        if(!fol[j])
        {
            perm[a]=j;
            fol[j]=1;
            combinari(a+1);
            fol[j]=0;
        }
    }
}

int main()
{
    in>>n>>k;

    combinari(1);
    in.close();
    out.close();
    return 0;
}
