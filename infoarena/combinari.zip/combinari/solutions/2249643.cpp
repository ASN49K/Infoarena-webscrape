#include <bits/stdc++.h>

using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int N,K,v[20];
bool sol ( int k);
int afisare(int k);
void combinari (int k)
{
    for(int i=v[k-1]+1; i<=N; i++)
    {
        v[k]=i;
        if(sol(k))
            afisare(k);
        else
            combinari(k+1);
    }
}
bool sol ( int k)
{
    if(k==K) return true;
    return false;
}
int afisare(int k)
{
    for(int i=1; i<=k; i++) fout<<v[i]<<" ";
    fout<<'\n';
}
int main()
{
    fin>>N>>K;
    combinari(1);
    return 0;
}
