#include <stdio.h>
int n, m, s[10], viz[10];

void afis()
{
	int i;
	for (i = 1; i <= m; i++) printf("%d ",s[i]);
	printf("\n");
}

void back(int k)
{
	int i;
	if (k > m) afis();
	else
		for (i = s[k - 1] + 1; i <= n; i++)
			if (!viz[i])
			{
				viz[i] = 1;
				s[k] = i;
				back(k + 1);
				viz[i] = 0;
			}
}

int main()
{
	freopen("combinari.in","r",stdin);
	freopen("combinari.out","w",stdout);
	scanf("%d %d",&n,&m);
	back(1);
	return 0;
}
