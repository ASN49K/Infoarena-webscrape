#include <bits/stdc++.h>
using namespace std;
int v[9],viz[9];
ifstream fin("combinari.in");
ofstream fout("combinari.out");
void backt(int current, int n,int k,int last)
{
    if(current == k + 1)
    {
        for(int i = 1;i <= k; ++i)
            fout << v[i] << " ";
        fout<<"\n";
    }
    else{
        for(int i = last + 1;i <= n;++i)
            if(!viz[i])
            {
                viz[i] = 1;
                v[current] = i;
                backt(current + 1, n, k, i);
                viz[i] = 0;
            }
    }
}
int main() {
    int n, k;
    fin >> n >> k;
    for(int i = 1; i <= n; ++i)
        v[i] = i;
    backt(1, n, k, 0);
    return 0;
}
