#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,a;
int v[20];
int ok(int k)
{
    for(int i=1;i<k;i++)
    {
        if(v[i]>=v[k])
        {
            return false;
        }
    }
    return true;
}
void afisare()
{
    for(int i=1;i<=a;i++)
    {
        fout<<v[i]<<" ";
    }
    fout<<'\n';
}
void f(int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k]=i;
        if(ok(k)==true)
        {
            if(k==a)
            {
                afisare();
            }
            else
            {
                f(k+1);
            }
        }
    }
}
int main()
{
    fin>>n>>a;
    f(1);
    fin.close();
    fout.close();
    return 0;
}
