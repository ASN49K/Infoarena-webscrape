#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

vector<int> v;
int n,k;
void beck(int nr, int l)
{
    if(l==k)
    {
        for(int i=0;i<k;i++) g<<v[i]<<' ';
        g<<'\n';
        return;
    }
    if(nr==n) return;
    v.push_back(nr+1);
    beck(nr+1,l+1);
    v.pop_back();
    beck(nr+1,l);
}

int main()
{
    
    f>>n>>k;
    beck(0,0);

    return 0;
}