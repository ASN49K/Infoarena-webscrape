#include <fstream>
#include <vector>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void combinations(int prev, int n, int k, vector<int> &c)
{
    if (c.size() == k)
    {
        for (int it : c)
        {
            fout << it << " ";
        }
        fout << "\n";
        return;
    }
    for (int i = prev; i <= n; ++i)
    {
        c.push_back(i);
        combinations(i + 1, n, k, c);
        c.pop_back();
    }
}

int n, k;
int main()
{
    fin >> n >> k;
    vector<int> c;
    combinations(1, n, k, c);
    return 0;
}
