#include <bits/stdc++.h>
using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,v[18],l;
void Afisare()
{
   for(int i=1;i<=l;i++)
       g<<v[i]<<" ";
   g<<"\n";
}
bool Ok(int k)
{
   for(int i=1;i<k;i++)
       if(v[k]==v[i]) return 0;
   return 1;
}
void Bkt(int k)
{
 for(int i=1;i<=n;i++)
 {
    v[k]=i;
    if(Ok(k) && v[k-1]<i)
    {
        if(k==l)
            Afisare();
        else Bkt(k+1);
    }
 }
}
int main()
{
    f>>n>>l;
    Bkt(1);
    return 0;
}
