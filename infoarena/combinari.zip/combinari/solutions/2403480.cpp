#include <bits/stdc++.h>

using namespace std;
ifstream f("combinari.in");
ofstream g("combinari.out");
int n,k,c[20];
void bkt(int);
int main()
{
    f>>n>>k;
    bkt(1);
    return 0;
}
void bkt(int p)
{
    if(p==k+1)
    {
        for(int i=1;i<=k;i++)
            g<<c[i]<<' ';
        g<<'\n';
        return;
    }
    for(int i=c[p-1]+1;i<=n;i++)
    {
        c[p]=i;
        bkt(p+1);
    }
}
