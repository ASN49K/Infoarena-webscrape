#include <bits/stdc++.h>

using namespace std;

ifstream cin("combinari.in");
ofstream cout("combinari.out");

void explore(int n, int k, int curr, vector<int> &answer) {
    if(k == 0) {
        for(int i = answer.size() - 1; i >= 1; i --)
            cout << answer[i] << " ";
        cout << "\n";
        return;
    }

    if(n - curr + 1 < k)
        return;

    answer[k] = curr;
    explore(n, k - 1, curr + 1, answer);
    answer[k] = 0;
    explore(n, k, curr + 1, answer);
}

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> aux(k + 1, 0);
    explore(n, k, 1, aux);

    return 0;
}