#include <iostream>
#include <cstdio>
#define N 20

using namespace std;

int n, k, viz[N], sol[N];

void afisare()
{
    for(int i=1;i<=k;i++)
        printf("%d ", sol[i]);
    printf("\n");
}

void bt(int poz)
{
    if(poz==k+1)
    {
        afisare();
        return;
    }
    for(int v=sol[poz-1]+1;v<=n;v++)
        if(!viz[v])
        {
            viz[v]=1;
            sol[poz]=v;
            bt(poz+1);
            viz[v]=0;
        }
}

int main()
{
    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);

    scanf("%d %d\n", &n, &k);
    bt(1);
    return 0;
}
