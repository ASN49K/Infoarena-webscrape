#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

#define N_MAX 19

int n, k;
int v[N_MAX], fq[N_MAX];
void bkt(int pos) {
  int i;
  if(pos == k + 1) {
    for(i = 1; i <= k; ++i) {
      fout << v[i] << ' ';
    }
    fout << '\n';
  }else {
    for(i = v[pos - 1] + 1; i <= n; ++i) {
      v[pos] = i;
      bkt(pos + 1);
    }
  }
}

int main()
{
  fin >> n >> k;
  bkt(1);
  return 0;
}
