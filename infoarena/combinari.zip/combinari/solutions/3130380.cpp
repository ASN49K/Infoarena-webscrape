#include <fstream>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

const int N_MAX = 18;
const int NIL = -1;
char v[N_MAX + 1], nxt[N_MAX + 1];

void print(char v[], int n) {
	for(int i = 1; i <= n; ++i)
		fout << (int) v[i] << ' ';
	fout.put('\n');
}

void generateCombinations(int pos, int n, int k, char v[], char nxt[]) {
	if(pos > k)
		print(v, k);
	else{
		int l = nxt[v[pos - 1]], ant = v[pos - 1];
		while(l != NIL){
			v[pos] = l;
			nxt[ant] = nxt[l];
			generateCombinations(pos + 1, n, k, v, nxt);
			nxt[ant] = l;
			ant = l;
			l = nxt[l];
		}
	}
}

int main() {
	int n, k;
	fin >> n >> k;

	for(int i = 0; i < n; ++i)
		nxt[i] = i + 1;
	nxt[n] = NIL;

	generateCombinations(1, n, k, v, nxt);

	fin.close();
	fout.close();
	return 0;
}