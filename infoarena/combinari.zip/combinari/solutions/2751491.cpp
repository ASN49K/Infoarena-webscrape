#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");
int st[20], n, v[20], k;
/**
A={1,2,3,4} k=3
C(n,k) = numarul de submultimi de k elemente ale lui A
1,2,3
1,2,4
1,3,4
2,3,4
C(4,3) = 4
C(n,k) = n! / (k! * (n-k)!)

   0 1 2 3 4 5
0: 1
1: 1 1
2: 1 2 1
3: 1 3 3 1
4: 1 4 6 4 1
5: 1 5 10 10 5 1

c[i][j] = c[i-1][j] + c[i-1][j-1]

st = st1, st2, ..., st(k-1), i
*/

void Afis(int n)
{
    for (int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}


void Comb(int top)
{
    if (top == k + 1) Afis(k);
    else for (int i = st[top-1] + 1; i <= n-k+1; i++)
    {
        st[top] = i;
        Comb(top + 1);
    }
}


int main()
{
    fin >> n >> k;
    Comb(1);
    fout.close();
    return 0;
}
