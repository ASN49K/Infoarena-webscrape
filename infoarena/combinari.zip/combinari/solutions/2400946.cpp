#include<cstdio>

using namespace std;

FILE* in=fopen("combinari.in", "r");
FILE* out=fopen("combinari.out", "w");

int v[25], n, k;

void afisre()
{
    for(int i=1; i<=k; ++i) fprintf(out, "%d ", v[i]);
    fprintf(out, "\n");
}

void combinari(int etaj)
{
    if(etaj>k) return;
    for(int i=v[etaj-1]+1; i<=n; ++i)
    {
        v[etaj]=i;
        if(etaj==k)
        {
            afisre();
        }
        else
        {
            combinari(etaj+1);
        }
    }
}

int main()
{
    fscanf(in, "%d%d", &n, &k);
    combinari(1);
}
