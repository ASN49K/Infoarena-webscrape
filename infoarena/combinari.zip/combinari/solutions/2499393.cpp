#include <cstdio>
#include <vector>
using namespace std;

void consume(vector<int>& currentSol) {
	for (auto& value : currentSol) {
		printf("%d ", value);
	}
	printf("\n");
}

void back(int remainingElems, int N, vector<int>& currentSol) {
	if (remainingElems == 0) {
		consume(currentSol);
		return;
	}

	int start = currentSol.empty() ? 0 : currentSol.back();
	for (int nextElem = start + 1; nextElem <= N; nextElem++) {
		currentSol.push_back(nextElem);
		back(remainingElems - 1, N, currentSol);
		currentSol.pop_back();
	}
}

int main() {
	freopen("combinari.in", "r", stdin);
	freopen("combinari.out", "w", stdout);

	int N, K;
	scanf("%d%d", &N, &K);
	vector<int> currentSol;
	currentSol.reserve(N);
	back(K, N, currentSol);
	return 0;
}