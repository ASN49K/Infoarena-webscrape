#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n,k,ST[20],p;

void tipar(int k)
{
    int i;
    for (i=1;i<=k;i++)
        fout<<ST[i]<<" ";
    fout<<"\n";
}
int valid(int k)
{
    int i;
    for (i=1;i<k;i++)
        if (ST[k]<=ST[i])
            return 0;
    return 1;
}
void back(int k)
{
    int i;
    for (i=1;i<=n;i++)
    {
        ST[k]=i;
        if (valid(k))
            if (k==p)
                tipar(k);
            else
                back(k+1);
    }
}
int main()
{
    fin>>n>>p;
    back(1);
    return 0;
}
