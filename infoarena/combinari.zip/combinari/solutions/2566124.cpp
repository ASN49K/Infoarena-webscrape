#include <fstream>
#include <iostream>
#include <stack>

using namespace std;

const int N = 20;

int n, k, st[N];
ofstream fout ("combinari.out");

void Write (int x)
{
    for (int i = 1; i <= x; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back (int top)
{
    if (top > k)
        Write (top - 1);
    else for (int i = st[top - 1] + 1; i <= n - k + top; i++)
    {
        st[top] = i;
        Back(top + 1);
    }
}

void Read ()
{
    ifstream fin ("combinari.in");
    fin >> n >> k;
    Back(1);
    fout.close();
    fin.close();
}



int main()
{
    Read();
    return 0;
}
