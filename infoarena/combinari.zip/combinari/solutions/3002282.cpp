#include <bits/stdc++.h>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int i, n, st[20], k;

void Afisare()
{
    int i;
    for (i = 1; i <= k; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back(int top)
{
    if (top == k + 1)
        Afisare();
    for (int i = st[top - 1] + 1; i <= n; i++)
    {
        st[top] = i;
        Back(top + 1);
    }

}

int main()
{
    fin >> n >> k;
    Back(1);

    return 0;
}