#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#define NMAX 2000005
using namespace std;
ifstream fin ("combinari.in");
ofstream fout ("combinari.out");
int n,st[20],K;
bool valid(int k)
{
    for(int i=1;i<k;++i)
        if(st[i]==st[k])
            return false;
    if(k>1)
        if(st[k]<=st[k-1])
        return false;
    return true;
}
bool solutie(int k)
{
    return (k==K);
}
void afisare()
{
    for(int i=1;i<=K;++i)
        fout << st[i] << " ";
    fout << '\n';
}
void back(int k)
{
    for(int i=1;i<=n;++i)
    {
        st[k]=i;
        if(valid(k))
        {
            if(solutie(k))
                afisare();
            else
                back(k+1);
        }
    }
}
int main()
{
    fin >> n >> K;
    back(1);
    return 0;
}
