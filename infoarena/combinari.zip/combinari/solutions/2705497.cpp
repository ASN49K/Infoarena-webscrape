#include<cstdio>
int a[19],b[19];

void back(int k,int len,int max)
{
     if(k-1 == max)
     {
         for(int i = 1; i <= max;i++)
           printf("%d ",a[i]);
         printf("\n");
     }
     else
     {
         for(int  i = 1; i <= len; i++)
            if(!b[i] && a[k-1] < i)
           {
                 a[k] = i;
                 b[i] = 1;
                 back(k+1,len,max);
                 b[i] = 0;
           }
     }
}

int main()
{
    freopen("combinari.in","r",stdin);
    freopen("combinari.out","w",stdout);
    int n,k;
    scanf("%d %d",&n,&k);
    back(1,n,k);
    fclose(stdin); fclose(stdout);
    return 0;
}
