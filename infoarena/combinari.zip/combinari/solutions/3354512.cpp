#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
int n;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int t;

void back(vector<int> &res, vector<int> visit, int k) {
    if (k >= t) {
        for (int x = 0; x < k; x ++) {
            fout << res[x] << ' ';
        }
        fout << '\n';
        return;
    }

    for (int i = res[k - 1]; i <= n; i++) {
        if (k == 0) {
            visit[i] = 1;
            res[k] = i;
            back(res, visit, k + 1);
            visit[i] = 0;
        } else {
            if (visit[i] == 0) {
                visit[i] = 1;
                res[k] = i;
                back(res, visit, k + 1);
                visit[i] = 0;

            }
        }
    }
}

int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    
    fin >> n >> t;
    
    if (n == 0) {
        fout << -1;
        return 0;
    }

    vector<int> res(n, 0);
    vector<int> visit(n + 1, 0);
    
    back(res, visit, 0);

    fin.close();
    fout.close();
    
    return 0;
}