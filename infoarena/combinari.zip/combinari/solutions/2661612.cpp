#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k;
int st[20];
bool f[20];

void afisare() {
    for (int i = 1; i <= n; ++i) {
        fout << st[i] << " ";
    }
    fout << "\n";
}

void backtrack(int top) {
    if (top > n) {
        afisare();
        return;
    }

    for (int i = 1; i <= k; ++i) {
        if (top == 1) {
            if (f[i] == 0) {
                f[i] = 1;
                st[top] = i;
                backtrack(top + 1);
                f[i] = 0;
            }
        } else {
            if (f[i] == 0 && st[top - 1] < i) {
                f[i] = 1;
                st[top] = i;
                backtrack(top + 1);
                f[i] = 0;
            }
        }
    }
}

int main() {
    fin >> n >> k;

    backtrack(1);

    return 0;
}
