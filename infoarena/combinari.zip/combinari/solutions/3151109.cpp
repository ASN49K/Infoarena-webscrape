#include <iostream>
#include <fstream>
using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, x[19], p[19];

void afisare() {
  for (int i = 0; i < k; i++) {
    g << x[i] << ' ';
  }
  g << '\n';
}

bool sortat() {
  for (int i = 0; i < k - 1; i++) {
    if (x[i] > x[i + 1]) return 0;
  }
  return 1;
}

void backtrack(int o) {
  for (int i = 1; i <= n; i++) {
    if (!p[i]) {
      x[o] = i;
      p[i] = 1;
      if (o == k - 1 && sortat()) afisare();
      else backtrack(o + 1);
      p[i] = 0;
    }
  }
}

int main() {
  f >> n >> k;
  backtrack(0);
}