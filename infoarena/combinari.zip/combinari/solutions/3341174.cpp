#include <iostream>

#define NMAX 18

void combination(char *used, int n, int *comb, int i, int k)
{
    if (i == 0) {
        for (int m = 0; m < n; ++m)
            if (!used[m]) {
                comb[i] = m + 1;
                used[m] = 1;

                combination(used, n, comb, i + 1, k);

                used[m] = 0;
            }
    } else if (i < k) {
        for (int m = comb[i - 1]; m < n; ++m)
            if (!used[m]) {
                comb[i] = m + 1;
                used[m] = 1;

                combination(used, n, comb, i + 1, k);

                used[m] = 0;
            }
    } else {
        for (int j = 0; j < k; ++j)
            std::cout << comb[j] << ' ';
        std::cout << '\n';
    }
}

void print_combinations(int k, int n)
{
    char used[NMAX] = {0};
    int comb[NMAX];

    combination(used, n, comb, 0, k);
}

int main()
{
    int k, n;

    freopen("combinari.in", "r", stdin);
    freopen("combinari.out", "w", stdout);

    std::cin >> n >> k;

    print_combinations(k, n);

    return 0;
}
