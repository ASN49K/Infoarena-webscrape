#include <bits/stdc++.h>

using namespace std;

void recurse(int N, int K, int idx, vector<int>& P) {
  if ((int)P.size() == K) {
    for (int i = 0; i < K; i++) {
      if (i) {
        cout << " ";
      }
      cout << P[i];
    }
    cout << "\n";
    return;
  }
  for (int i = idx; i <= N; i++) {
    P.push_back(i);
    recurse(N, K, i + 1, P);
    P.pop_back();
  }
}

int main() {
#ifndef LOCAL
  freopen("combinari.in", "r", stdin);
  freopen("combinari.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int N, K;
  cin >> N >> K;
  vector<int> P;
  recurse(N, K, 1, P);
}
