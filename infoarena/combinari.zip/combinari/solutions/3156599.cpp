#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n,m,x[10];

void afis()
{
    for(int i=1;i<=m;i++)
        g<<x[i]<<' ';
    g<<'\n';
}

void backt(int k)
{
    for(int i=1;i<=n;i++)
    {
        x[k]=i;
        if(x[k]>x[k-1])
        {
            if(k<m)
                backt(k+1);
            else
                afis();
        }
    }
}

int main()
{
    f>>n>>m;
    backt(1);
    return 0;
}
