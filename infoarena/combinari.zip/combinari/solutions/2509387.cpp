#include <bits/stdc++.h> //JuniorMonster a.k.a Sho10
#define ll long long int
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define all(a) (a).begin(), (a).end()
#define sz size
#define f first
#define s second
#define pb push_back
#define er erase
#define in insert
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define CODE_START  ios_base::sync_with_stdio();cin.tie();cout.tie();
using namespace std;
ll n,k;
vector<ll>v;
 ifstream in("combinari.in");
    ofstream out("combinari.out");
void sol(ll x){
v.pb(x);
if(v.size()==k){
    for(ll i=0;i<v.size();i++)
        out<<v[i]<<' ';
    out<<endl;
}
 if(v.size()<k){
for(ll i=x+1;i<=n;i++)
    sol(i);
}
v.pop_back();
}
int32_t main(){
in>>n>>k;
for(ll i=1;i<=n-k+1;i++)
    sol(i);
}





