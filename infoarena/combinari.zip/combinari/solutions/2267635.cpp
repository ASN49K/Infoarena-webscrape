//#include <iostream>
#include <fstream>
using namespace std;
ifstream cin("combinari.in");
ofstream cout("combinari.out");
int n,k;
void bct(int ind,int luate,bool f[])
{
    if(ind==n+1){
        if(luate==k){
            for(int i=1;i<=n;i++){
                if(f[i]==1)
                    cout<<i<<" ";
            }
            cout<<"\n";
        }
        return;
    }
    f[ind]=1;
    bct(ind+1,luate+1,f);
    f[ind]=0;
    bct(ind+1,luate,f);
}
int main()
{
    bool v[30];
    for(int i=1;i<=25;i++)
        v[i]=0;
    cin>>n>>k;
    bct(1,0,v);
    return 0;
}
