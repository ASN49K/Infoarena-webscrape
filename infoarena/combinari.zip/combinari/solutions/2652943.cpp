#include <iostream>
#include <fstream>
#include <vector>
#include <numeric>

using namespace std;

void _combs(ostream &fout, int N, int K, int level, int max, vector<int> &acc) {
	if (level == K) {
		for (auto v : acc)
			fout << v << " ";
		fout << "\n";

		return;
	}

	for (int i = max+1; i <= N; ++i) {
		acc[level] = i;
		_combs(fout, N, K, level+1, i, acc);
	}
}

void combs(ostream &fout, int N, int K) {
	vector<int> acc(K);

	_combs(fout, N, K, 0, 0, acc);
}



int main(int argc, char const *argv[])
{
	ifstream fin("combinari.in");
	ofstream fout("combinari.out");

	int N, K;
	fin >> N >> K;
	
	combs(fout, N, K);

	return 0;
}