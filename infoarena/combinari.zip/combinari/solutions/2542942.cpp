#include <fstream>

using namespace std;
    ifstream f("combinari.in");
    ofstream g("combinari.out");
int m,n,x[19];

void bkt()
{
    int k=1;
    while(k)
    {
        if(x[k]<n && k<=m)
        {
            ++x[k];
            if(k==m)
            {
                for(int i=1;i<=k;++i)
                    g<<x[i]<<' ';
                g<<'\n';
            }
            else
            {
                ++k;
                x[k]=x[k-1];
            }
        }
        else
            --k;
    }
}
int main()
{
    f>>n>>m;
    bkt();
    f.close();
    g.close();
    return 0;
}
