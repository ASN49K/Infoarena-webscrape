#include <stdio.h>
#include <stdlib.h>
#define MAXN 18
int v[MAXN],n,k;
FILE*fin;
FILE*fout;
void back(int d){
  int i;
  if(d == k){
    for(i = 0; i < k;i++)
      fprintf(fout,"%d ",v[i]);
    fprintf(fout,"\n");
  }
  else for(i = v[d-1]+1; i <= n;i++){
      v[d] = i;
      back(d+1);
  }
}
int main()
{
  fin = fopen("combinari.in","r");
  fout = fopen("combinari.out","w");
  fscanf(fin,"%d%d",&n,&k);
  back(0);
  return 0;
}
