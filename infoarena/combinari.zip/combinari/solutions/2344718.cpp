#include <iostream>
#include <fstream>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

int n, k;
int comb[20];

bool used[20];

void write() {
  for(int i = 1; i <= k; i++)
    out << comb[i] << ' ';
  out << '\n';
}

void gen(int pos) {
  if(k < pos)
    write();
  else {
    for(int i = comb[pos - 1] + 1; i <= n; i++) {
      comb[pos] = i;
      gen(pos + 1);
    }
  }
}

int main()
{
  in >> n >> k;

  gen(1);

  in.close();
  out.close();

  return 0;
}
