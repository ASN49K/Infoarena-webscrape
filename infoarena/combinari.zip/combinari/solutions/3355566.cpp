#include <bits/stdc++.h>
using namespace std;

int N, K;
vector<int> solutie;
ofstream fout("combinari.out");

void back(int pas, int start) {
    if (pas == K) {
        for (int i = 0; i < K; ++i) {
            fout << solutie[i] << (i == K - 1 ? "" : " ");
        }
        fout << "\n";
        return;
    }

    for (int i = start; i <= N; ++i) {
        solutie[pas] = i;
        back(pas + 1, i + 1);
    }
}

int main() {
    ifstream fin("combinari.in");
    fin >> N >> K;
    
    solutie.resize(K);
    back(0, 1);
    
    fin.close();
    fout.close();
    
    return 0;
}









