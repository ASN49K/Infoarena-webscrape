#include <bits/stdc++.h>
using namespace std;
string np = "combinari";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

int n, maxim, v[20];
bool fq[20];

void back(int k)
{
    if (k > maxim)
    {
        for (int i = 1; i <= maxim; i++)
            g << v[i] << " ";
        g << '\n';
    }
    else
        for (int i = 1; i <= n; i++)
            if (!fq[i] and i > v[k - 1])
            {
                v[k] = i;
                fq[i] = 1;
                back(k + 1);
                fq[i] = 0;
            }
}
int main()
{
    f >> n >> maxim;

    back(1);

    return 0;
}