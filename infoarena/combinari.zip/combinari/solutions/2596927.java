

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        File file = new File("combinari.in");
        Scanner scanner = new Scanner(file);
        int n, k;
        n = scanner.nextInt();
        k = scanner.nextInt();
        scanner.close();

        Combination combination = new Combination(n, k);

        FileWriter fileWriter = new FileWriter("combinari.out");
        PrintWriter printWriter = new PrintWriter(fileWriter);

        combination.generate_write(printWriter,0);

        printWriter.close();
        fileWriter.close();
    }
}

class Combination {
    public Combination(int nn, int nk) {
        n = nn;
        k = nk;
        stat = new ArrayList<>(Collections.nCopies(n+1,0));
        x = new ArrayList<>(Collections.nCopies(k,0));
    }

    public void generate_write(PrintWriter printWriter, int i) {
        for (int j = 1; j <= n; j++) {
            if (stat.get(j) == 1 || (i != 0 && x.get(i - 1) > j)) continue;
            x.set(i, j);
            stat.set(j, 1);

            if (i != k - 1) generate_write(printWriter, i + 1);
            else {
                for (int e : x) printWriter.print(e + " ");
                printWriter.print("\n");
            }

            stat.set(j, 0);
        }
    }

    private int n, k;
    private ArrayList<Integer> stat, x;
}
