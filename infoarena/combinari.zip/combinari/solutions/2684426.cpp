#include <stdio.h>
#define MAXN 9

FILE *fout;

bool f[MAXN];
int n, v[MAXN], k;

void afis() {
  int i;
  for( i = 1; i <= k; i++ ) {
    fprintf( fout, "%d ", v[i] );
  }
  fprintf( fout, "\n" );
  return;
}

void perm( int poz ) {
  if( poz == k + 1 ) {
    afis();
    return;
  } else {
    int i;
    for( i = v[poz - 1] + 1; i <= n; i++ ) {
      if( f[i] == 0 ) {
        f[i] = 1;
        v[poz] = i;
        perm( poz + 1 );
        f[i] = 0;
      }
    }
    return;
  }
}

int main() {
  FILE *fin;
  fin = fopen( "combinari.in", "r" );
  fout = fopen( "combinari.out", "w" );
  fscanf( fin, "%d", &n );
  fscanf( fin, "%d", &k );
  perm( 1 );
  return 0;
}
