#include <fstream>

using namespace std;

int n;

/*
n = 3

submultime = [], val = 1
Caz 1: nu il adaugam pe 1 => submultime = [], val = 2
submultime = [], val = 2
Caz 1.1: nu il adaugam pe 2 => submultime = [], val = 3
submultime = [], val = 3
Caz 1.1.1: nu il adaugam pe 3 => submultime = [], val = 4
b(1) -> b(2)
Caz 1.1.2: il adaugam pe 3 => submultime = [3], val = 4

Caz 1.2: il adaugam pe 2 => submultime = [2], val = 3
submultime = [2], val = 3
Caz 1.2.1: nu il adaugam pe 3 => submultime = [2], val = 4
Caz 1.2.2: il adaugam pe 3 => submultime = [2, 3], val = 4
...

Caz 2: il adaugam pe 1 => submultime = [1], val = 2
submultime = [1], val = 2
Caz 2.1: nu il adaugam pe 2 => submultime = [1], val = 3
Caz 2.2: il adaugam pe 2 => submultime = [1, 2], val = 3


*/

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int submultime[30], len;

void backtrack(int val) {
    //fout << val <<"\n";
    if(val > n) {
        if(len == 0) {
            return;
        }
        for(int i = 1; i <= len; i++) {
            fout << submultime[i] << " ";
        }
        fout << "\n";
    }
    else {
        //Caz 1: nu il iau pe val
        backtrack(val + 1);
        //Caz 2: il iau pe val
        submultime[++len] = val;
        backtrack(val + 1);
        len--;
    }
}

int main() {
    fin >> n;
    backtrack(1);
    return 0;
}