#include <bits/stdc++.h>
using namespace std;

int N, K;
vector<int> comb;

void bt(int start, ofstream &fout) {
    if (comb.size() == K) {
        for (int i = 0; i < K; i++) {
            if (i) fout << ' ';
            fout << comb[i];
        }
        fout << '\n';
        return;
    }
    for (int i = start; i <= N; ++i) {
        comb.push_back(i);
        bt(i+1, fout);
        comb.pop_back();
    }
}

int main() {
    ifstream fin("combinari.in");
    ofstream fout("combinari.out");
    fin >> N >> K;
    bt(1, fout);
    return 0;
}
