#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
void afisare(int v[], int p)
{
    int i;
    for(i=1; i<=p; i++)
        fout<<v[i]<<" ";
    fout<<"\n";
}
void bkt(int k, int n, int v[], int p, int viz[])
{
    int i;
    if(k==p+1) afisare(v,p);
    else for(i=v[k-1]+1; i<=n; i++)
        {
            if(viz[i]==0)
            {
                viz[i]=1;
                v[k]=i;
                bkt(k+1,n,v,p,viz);
                viz[i]=0;
            }
        }
}
int main()
{
    int n,p,v[20],viz[20]= {0};
    fin>>n>>p;
    v[0]=0;
    bkt(1,n,v,p,viz);
    return 0;
}
