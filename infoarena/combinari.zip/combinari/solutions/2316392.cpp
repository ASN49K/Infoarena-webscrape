#include <iostream>

#include <vector>

using std::cin;
using std::cout;

using std::vector;

vector<int> v;
int n, k;

void comb(int l = 0) {
	if (l == k) {
		for (auto i : vector<int>(v.begin() + 1, v.end())) {
			cout << i << " ";
		}
		cout << "\n";
	} else {
		for (int i = v[l] + 1; i <= n; i++) {
			v[l + 1] = i;
			comb(l + 1);
		}
	}
}

int main() {
	cin >> n >> k;
	v.resize(k + 1);
	comb();
}