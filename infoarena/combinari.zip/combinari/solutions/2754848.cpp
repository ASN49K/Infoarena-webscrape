#include <fstream>
using namespace std;

bool is_visited[19];

ifstream fin("combinari.in");
ofstream fout("combinari.out");

void generate_combinations(int n, int k, int len, int combinations[19]) {
	if (len == k + 1) {
		bool is_ascending = true;
		for (int i = 1; i < k; ++i) {
			if (combinations[i] >= combinations[i + 1]) {
				is_ascending = false;
				break;
			}
		}
		for (int i = 1; is_ascending && i <= k; ++i) {
			fout << combinations[i] << ' ';
		}
		if (is_ascending) {
			fout << '\n';
		}
		return;
	}
	for (int i = 1; i <= n; ++i) {
		if (!is_visited[i]) {
			combinations[len] = i;
			is_visited[i] = true;
			generate_combinations(n, k, len + 1, combinations);
			is_visited[i] = false;
		}
	}
}

int main() {
	int n, k, combinations[19] = { 0 };
	fin >> n >> k;
	int len = 1;
	generate_combinations(n, k, len, combinations);
	return 0;
}