#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int m,n,sol[21];

void beck(int k)
{
    if(k==m+1)
    {
        for(int i=1;i<k;i++)
            g<<sol[i]<<" ";
        g<<'\n';
    }
    else
    {
        for(int i=sol[k-1]+1;i<=n;i++)
        {
            sol[k]=i;
            beck(k+1);
        }
    }
}

int main()
{
    f>>n>>m;
    beck(1);
    return 0;
}
