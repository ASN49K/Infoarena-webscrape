#include <bits/stdc++.h>
using namespace std;
ifstream ci("combinari.in");
ofstream cou("combinari.out");
int n,sol[20],k,fr[20],p;

void afis()
{

    for(int i=1; i<=n; i++)
    {
        cou<<sol[i]<< " ";
    }
    cou<<"\n";

}



void Back(int k)
{

    if(k==n+1)
    {
        afis();
    }
    else
    {
        for(int i=1; i<=p; i++)
        {
            while(fr[i]!=0 )
            {
                i++;
            }
            if(i>p)
            {
                return;
            }
            sol[k]=i;

            if(sol[k]<sol[k-1]&&k>1 )
            {
                while(i<sol[k-1]||fr[i]!=0 )
                {
                    i++;
                }

            }
            if(i>p)
            {
                return;
            }
            sol[k]=i;
            fr[i]=1;
            Back(k+1);
            fr[i]=0;
        }

    }


}



int main()
{

    ci>>p>>n;
    Back(1);
    return 0;
}
