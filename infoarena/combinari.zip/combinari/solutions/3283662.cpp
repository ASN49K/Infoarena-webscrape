#include <bits/stdc++.h>
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, k, st[20], viz[20];

void Afis()
{
    for (int i = 1; i <= k; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back(int top)
{
    if (top == k + 1) Afis();
    else for (int i = st[top - 1] + 1; i <= n; i++)
        if (viz[i] == 0)
        {
            st[top] = i;
            viz[i] = 1;
            Back(top + 1);
            viz[i] = 0;
        }
}

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    fin >> n >> k;
    Back(1);
    return 0;
}
