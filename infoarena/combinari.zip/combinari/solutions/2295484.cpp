#include <cstdio>

#define MAXM 18

using namespace std;

int v[MAXM+5];
int n, m;

inline int afisare( )
{
  for( int i=1;i<=m;i++ )
    printf( "%d ", v[i] );

  printf( "\n" );
}

void bck( int p, int last )
{
  if( p>m )
    afisare();
  else
    for( int i=last+1;i<=n;i++ )
      if( n-i>=m-p )
      {
        v[p]=i;
        bck(p+1,i);
      }
}

int main()
{
  freopen( "combinari.in", "r", stdin );
  freopen( "combinari.out", "w", stdout );

  scanf( "%d%d", &n, &m  );

  bck(1,0);

  return 0;
}
