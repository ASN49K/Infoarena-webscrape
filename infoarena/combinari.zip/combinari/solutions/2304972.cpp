#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int x[50],N,K;
void comb(int pas){
    if(pas>K){
        for(int i=1;i<pas;i++)
            fout<<x[i]<<" ";
        fout<<"\n";
    }
    else
    for(int i=x[pas-1]+1;i<=N;i++){
            x[pas]=i;
            comb(pas+1);
    }
}
int main(){
    fin>>N>>K;
    comb(1);
    return 0;
}
