#include<fstream>
using namespace std;
int n,p,x[19];
ifstream f ("combinari.in");
ofstream g("combinari.out");
void afisare(int k)
{
    for(int i=1;i<=k;i++)
        g<<x[i]<<" ";
    g<<endl;
}
int valid(int k)
{
    if(k>1)
        if(x[k]<=x[k-1])      // strict crescatoare
        return 0;
    return 1;
}
void bkt(int k)
{
    for(int i=1;i<=n;i++)
    {
        x[k]=i;
        if(valid(k)==1)
            if(k==p)
            afisare(k);
            else
            bkt(k+1);
    }
}
int main()
{
    f>>n>>p;    //combinari de n luate cate p
    bkt(1);
    return 0;
}
