#include <cstdio>

#define MAXN 32

int N, K;
int v[MAXN];

void back(int k) {
	if (k > K) {
		for (int i = 1; i <= K; ++i)
			printf("%d ", v[i]);
		printf("\n");
		return;
	}
	for (int i = v[k-1] + 1; i <= N - (K-k); ++i) {
		v[k] = i;
		back(k+1);
	}
}

int main() {
	freopen("combinari.in", "r", stdin);
	freopen("combinari.out", "w", stdout);

	scanf("%d %d", &N, &K);
	back(1);
}
