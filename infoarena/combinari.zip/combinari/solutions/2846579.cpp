#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
bool ver[10];
int a[10],n,k;
void bck(int nr,int b)
{
    if(nr==k)
    {
        for(int i=1;i<=k;++i)
            out<<a[i]<<' ';
        out<<'\n';
        return;
    }
    for(int i=b;i<=n;++i)
    {
        if(ver[i]==false)
        {
            ver[i]=true;
            a[nr+1]=i;
            bck(nr+1,i+1);
            ver[i]=false;
        }
    }
    return;
}
int main()
{
    in>>n>>k;
    bck(0,1);
    return 0;
}
