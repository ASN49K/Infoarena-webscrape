#include <bits/stdc++.h>

using namespace std;
ifstream r("combinari.in");
ofstream w("combinari.out");
vector<int>s;
int n, k;
void backtracking(int pas){
    if(pas==k+1){
        for(int i=1;i<s.size();i++){
            w<<s[i]<<" ";
        }
        w<<"\n";
        return;
    }
    for(int i=s[pas-1]+1;i<=n;i++){
        s.push_back(i);
        backtracking(pas+1);
        s.pop_back();
    }
}
int main()
{
    r>>n>>k;
    s.push_back(0);
    backtracking(1);
    return 0;
}
