#include <bits/stdc++.h>

using namespace std;

ifstream fin ("combinari.in");
ofstream fout ("combinari.out");

int v[33];

bool good(int k){
    if(k==1)
        return 1;
    if(v[k-1]>=v[k])
        return 0;
    return 1;
}

void backtracking(int n ,int K , int k) {
    for (int i=1;i<=n;++i){
        v[K] = i;
        if (good(K)==1){
            if (k==K){
                for (int j=1;j<=k;++j) fout << v[j] << ' ';
                fout << '\n';
            }else{
                backtracking(n,K+1,k);
            }
        }
    }
}

int main()
{
    int n,k;
    fin >> n >> k;
    backtracking(n, 1, k);
    return 0;
}
