#include<fstream>
using namespace std;
ifstream F("combinari.in");
ofstream G("combinari.out");
short n,p,k=1,s[19],o,i;
int main()
{
    F>>n>>p;
    while(k) {
        for(++s[k],o=i=1;i<k&&o;++i)
            if(s[i]==s[k])
                o=0;
        if(o)
            if(s[k]<=n)
                if(k==p) {
                    for(i=1;i<=k;++i)
                        G<<s[i]<<" ";
                    G<<"\n";
                } else
                    ++k,s[k]=s[k-1];
            else
                --k;
    }
    return 0;
}
