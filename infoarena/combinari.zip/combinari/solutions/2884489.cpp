#include <bits/stdc++.h>
#define ll long long
#define INF 0x3F3F3F3F
using namespace std;

const string fisier = "combinari";

ifstream fin (fisier + ".in");
ofstream fout (fisier + ".out");

int n , z , x[25];

void solve (){
    for (int i=1; i<=z; i++){
        fout << x[i] << " ";
    }
    fout << '\n';
}

void back (int k){
    for (int i=x[k-1]+1; i<=n; i++){
        x[k] = i;
        if (k <= z){
            if (k == z){
                solve();
            }
            else{
                back(k + 1);
            }
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    fin >> n >> z;
    back(1);
}
