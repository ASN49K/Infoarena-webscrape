#include <bits/stdc++.h>

using namespace std;

ifstream f("combinari.in");
ofstream g("combinari.out");

int n, k, v[20];

void afisare()
{
    for(int i = 1; i <= k; i++)
    {
        g<<v[i]<<' ';
    }
    g<<'\n';
}

void bt(int prev, int kn)
{
    for(int i = prev; i <= n; i++)
    {
        v[kn] = i;
        if(kn == k)
        {
            afisare();
        }
        else
        {
            bt(i + 1, kn + 1);
        }
    }
}

int main()
{
    f>>n>>k;
    bt(1, 1);
    return 0;
}
