#include <fstream>
using namespace std;
ifstream in("combinari.in");
ofstream out("combinari.out");
int n,k;
void generare(string s,int poz,int nr)
{
    if(poz==n+1 and nr==k)
    {
        for(int i=1;i<=n;++i)
        if(s[i]=='1')
            out<<i<<" ";
        out<<'\n';
    }
    else if(poz<=n and nr<=k and n-poz+1+nr>=k)
    {
        s[poz]='1';
        generare(s,poz+1,nr+1);
        s[poz]='0';
        generare(s,poz+1,nr);
    }
}
string s="000000000000000000000";
int main()
{
    ios_base::sync_with_stdio(false);
    in.tie(0),out.tie(0);
    in>>n>>k;
    generare(s,1,0);
    return 0;
}
