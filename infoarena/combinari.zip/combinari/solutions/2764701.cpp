#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int x[19];
bool ap[19];
int n,m;
void afis()
{
    for(int i=1; i<=m; i++)
        fout<<x[i]<<' ';
    fout<<'\n';
}
void bt(int k)
{
    if(k<=m)
    {
        for(int i=x[k-1]; i<=n; i++)
        {
            if(ap[i]==0)
            {
                x[k]=i;
                ap[i]=1;
                bt(k+1);
                ap[i]=0;
            }
        }
    }
    else afis();
}
int main()
{
    fin>>n>>m;
    x[0]=1;///art
    bt(1);
    return 0;
}
