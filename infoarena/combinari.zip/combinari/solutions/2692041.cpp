#include <bits/stdc++.h>

using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
int n, a[19], k;

void show()
{
	for (int i = 1; i <= k; i++)
		fout << a[i] << " ";
	fout << "\n";
}

void back(int x)
{
	for (int i = a[x - 1] + 1; i <= n; i++)
	{
		a[x] = i;
		if (x == k)show();
		else back(x + 1);
	}
}

int main()
{
	fin >> n >> k;
	back(1);
	fin.close();
	fout.close();
	return 0;
}