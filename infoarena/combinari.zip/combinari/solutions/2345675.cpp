#include<bits/stdc++.h>
using namespace std;
int n,k,rs[20];
ofstream fout("combinari.out");
void back(int lvl){
	if(lvl==k){
		for(int i=1;i<=k;i++)
		    fout<<rs[i]<<' ';
		fout<<'\n';
	}else{
		for(int i=rs[lvl]+1;i<=n;i++){
			rs[lvl+1]=i;
			back(lvl+1);
		}
	}
}
int main(){
	ifstream cin("combinari.in");
	cin>>n>>k;
	back(0);
	return 0;
}
