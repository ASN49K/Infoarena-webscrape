#include <bits/stdc++.h>
using ll=long long;
#define S second
#define F first
#define endl '\n'
#define spid ios_base::sync_with_stdio(false);cin.tie(NULL);
const int mod=1e9+7;
const double pi=3.14159265359;
const int maxn=200001;
using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,k;

void r(int i,vector<int> A){
	if(A.size()==k){
		for(int i=0;i<k;i++){
			fout<<A[i]<<" ";
		}
		fout<<endl;
		return;
	}
	if(i==n+1)return;
	r(i+1,A);
	A.push_back(i);
	r(i+1,A);
}

int main(){
	fin>>n>>k;
	vector<int> A;
	r(1,A);
}

