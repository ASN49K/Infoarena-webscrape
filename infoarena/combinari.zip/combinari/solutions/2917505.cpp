#include <iostream>
#include <fstream>

std::ifstream fin("combinari.in");
std::ofstream fout("combinari.out");

void print_solution(int x[], int k)
{
	for (int i = 1; i <= k; i++)
	{
		fout << x[i] << " ";
	}

	fout << "\n";
}

bool check_length(int position, int k)
{
	return position == k;
}

bool valid_solution(int x[], int position)
{
	for (int i = 1; i < position; i++)
	{
		if (x[i] == x[position])
		{
			return false;
		}
	}

	if (x[position - 1] >= x[position])
	{
		return false;
	}

	return true;
}

void combinari(int x[], int n, int k, int position)
{
	for (int i = 1; i <= n; i++)
	{
		x[position] = i;
		
		if (valid_solution(x, position))
		{
			if (check_length(position, k))
			{
				print_solution(x, k);
			}
			else
			{
				combinari(x, n, k, position + 1);
			}
		}
	}
}

int main() {
	int x[25];

	int n;
	int k;

	fin >> n >> k;

	combinari(x, n, k, 1);

	return 0;
}