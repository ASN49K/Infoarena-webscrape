#include <bits/stdc++.h>

using namespace std;

ifstream in("combinari.in");
ofstream out("combinari.out");

#define pii pair<int, int>
#define pb push_back
#define fi first
#define se second

const int NMAX = 9;
const int INF = 0x3f3f3f3f;

int n, K;
bool v[NMAX];
vector<int> p;

void read()
{
    in >> n >> K;
}

void permutations(int k)
{
    if (k == K)
    {
        for (auto i : p)
            out << i << ' ';
        out << '\n';
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        if (!v[i] && (p.empty() || *(p.end()-1)<i)) //in ordine crescatoare pt combinari
        {
            v[i] = 1;
            p.push_back(i);
            permutations(k + 1);

            p.pop_back();
            v[i] = 0;
        }
    }
}

void solve()
{
    permutations(0);
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);

    read();
    solve();

    return 0;
}