#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

#define cin fin
#define cout fout

int n,m,a,b,x,viz[100005],cnt;
vector<vector<int>> v;

void dfs(int k)
{
    viz[k]=cnt;
    for(int i=0;i<v[k].size();i++)
    {
        if(viz[v[k][i]]==0) dfs(v[k][i]);
    }
}

int main()
{
    cin>>n>>m;
    v.resize(n+1);
    for(int i=1;i<=m;i++)
    {
        cin>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    for(int i=1;i<=n;i++) sort(v[i].begin(),v[i].end());
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            cnt++;  dfs(i);
        }
    }
    cout<<cnt<<"\n";
    return 0;
}
