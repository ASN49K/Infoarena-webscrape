#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void invmod(long long &x, long long &y, int a, int b)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
    }
    else
    {
        invmod(x, y, b, a % b);
        long long aux = x;
        x = y;
        y = aux - y * (a / b);
    }
}

int main()
{
    int A, N;
    long long inv, cop;
    fin >> A >> N;
    invmod(inv, cop, A, N);
    if (inv <= 0)
    {
        inv = N + inv % N;
    }
    fout << inv;
    return 0;
}
