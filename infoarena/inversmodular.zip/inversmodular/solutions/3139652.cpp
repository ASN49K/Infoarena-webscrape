#include <iostream>
#define ll long long
#include <fstream>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

inline int euclidextins(int a,int b,ll &x,ll&y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
        ll x0,y0;
        int d;
        d=euclidextins(b,a%b,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
        return d;
    }
}

int main()
{
    ll invmod=0;
    int a,b,d;
    ll x,y;
    f>>a>>b;
    d=euclidextins(a,b,x,y);
    while(x<0)
        x+=b;
    g<<x;
    return 0;
}
