#include <iostream>
#include <fstream>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

void EuclidExtins(int a, int b, int &d, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
    }
    else
    {
        int x0, y0;
        EuclidExtins(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}
/**
A și N sunt prime între ele.
Atunci, după apelul lui Euclid extins
==>
A*x + N*y = 1 (adică d = 1)
==>
A*x ≡ 1 (modulo N)
*/

int inversMod(int A, int N) // A și N sunt prime între ele
{
    int d, x, y;
    EuclidExtins(A, N, d, x, y);
    while(x < 0) x += N;
    return x;
}

int main()
{
    int A, N;
    f >> A >> N;
    g << inversMod(A, N);
    f.close();
    g.close();
    return 0;
}
