#include <iostream>
#include <fstream>
using namespace std;

void euclid_extins(int a,int b,int &x,int &y)
{
        if (b == 0) {
        x = 1;
        y = 0;
        return;
    }
    int x1, y1;
    euclid_extins(b, a % b, x1, y1);

    x = y1;
    y = x1 - (a / b) * y1;



}

int main()
{
    int A,N,x=0,y;
    ifstream fin("inversmodular.in");
    ofstream fout("inversmodular.out");
    fin>>A>>N;
    euclid_extins(A,N,x,y);
    if(x<0)
        x=N+x%N;
    cout<<x;
    fin.close();
    fout.close();

}
 /*if (b==0) {
        x=1;
        y=0;
        return;
    }
    euclid_extins(b,a%b,x,y);
    int x1=x;
    x=y;
    y=x1-(a/b)*y;*/
