#include <iostream>
#include <fstream>
using namespace std;

ifstream in ("inversmodular.in");
ofstream out ("inversmodular.out");

void euclid(int a , int b ,int & x ,int & y){

    if (b==0){
        x=1,y=0;


    }

    else{
        int x1,y1;
        euclid(b,a%b,x1,y1);
        x=y1;
        y=x1-y1*(a/b);



    }


}


int main()
{
    int n ;
    int a,b,c,d;
    int x,y;

    in>>a>>b;

    euclid(a,b,x,y);
    while(x<0){
        x+=b;

    }

    out<<x;

    return 0;
}
