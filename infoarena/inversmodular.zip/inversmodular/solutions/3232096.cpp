#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
long long mod, a;

static inline long long Put(long long a, long long n) {
    long long p = 1;
    while(n) {
        if(n & 1) p = (p * a) % mod;
        a = (a * a) % mod;
        n >>= 1;
    }
    return p;
}

int main () {
    fin >> a >> mod;
    fout << Put(a, mod - 2);

    return 0;
}
