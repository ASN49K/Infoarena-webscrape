#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int n, a, x, y;

static inline void Euclid(int a, int b, int &x, int &y) {
    if(b == 0) x = y = 1;
    else {
        int x1, y1;
        Euclid(b, a % b, x1, y1);
        x = y1;
        y = x1 - (a / b) * y1;
    }
}

int main () {
    fin >> a >> n;

    Euclid(a, n, x, y);
    while(x < 0) x += n;

    fout << x;

    return 0;
}
