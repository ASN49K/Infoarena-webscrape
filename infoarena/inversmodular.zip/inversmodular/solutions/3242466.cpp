#include <fstream>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");



void EuclidExtins(int a, int b, int &d, int &x, int &y) ///Varianta recursiva
{
    if(b == 0)
    {
        x = 1, y = 0, d = a;
    }
    else
    {
        int x0, y0;
        EuclidExtins(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int inversMod(int A, int N)
{
    int d, x, y;
    EuclidExtins(A, N, d, x, y);
    while(x < 0) x += N;
    return x;
}

int main()
{
    int A, N;
    f >> A >> N;
    g << inversMod(A, N);
    f.close();
    g.close();
    return 0;
}
