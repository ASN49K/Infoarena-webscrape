#include <bits/stdc++.h>
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define min(a,b)((a<b)?a:b)
#define max(a,b)((a>b)?a:b)
using namespace std;
ifstream in("inversmodular.in");
ofstream out("inversmodular.out");
int a,b,d,x,y;
constexpr void g(int a,int b)
{
    if(b==0)d=a,x=y=1;
    else{
        g(b,a%b);
        sw(x,y);
        y-=a/b*x;
    }
}
int main()
{
in>>a>>b;g(a,b);
out<<(x<0?x+b:x);
}
