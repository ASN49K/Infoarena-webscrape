#include <bits/stdc++.h>

using namespace std;
using ll=long long;

void invMod(int a, int b, ll &x, ll &y){
    ll aux;
    if(!b){
        x=1;
        y=0;
    }else{
        invMod(b, a%b, x, y);
        aux=x;
        x=y;
        y=aux-y*(a/b);
    }
}

int main()
{
    ifstream fin("inversmodular.in");
    ofstream fout("inversmodular.out");
    int n, a;
    ll x, y;
    fin>>a>>n;
    x=y=0;
    invMod(a, n, x, y);
    if(x<0)
        x+=n;
    fout<<x;
    return 0;
}
