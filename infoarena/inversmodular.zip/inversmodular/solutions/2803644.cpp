#include <bits/stdc++.h>
using namespace std;

int MOD;

int pw(int x, int y){
    if(y==0) return 1;
    int z=pw(x,y/2);
    if(y%2) return z*z*x;
    return z*z;
}

inline int invMod(int x){
    int ans=pw(x,x-2);
    return ans%MOD;
}

int main(){
    int x,y;
    cin>>MOD>>x;
    cout<<(invMod(x)+MOD)%MOD+1;
}
