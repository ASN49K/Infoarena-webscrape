#include <bits/stdc++.h>
#define int long long
#define mod 9973
using namespace std;
ifstream in ("ssnd.in");
ofstream out ("ssnd.out");
int n;
bool ciur[1000001];
vector <int> numere;
void fct ()
{
    for(int i = 2;i<=1000;++i)
        if (ciur[i] == 0)
        {
            numere.push_back(i);
            for (int j = i + i;j<=1000000;j+=i)
                ciur[j] = 1;
        }
}
int log_pow (int a, int b)
{
    int rez = 1;
    while (b)
    {
        if (b & 1)
            rez = (rez * a) % mod;
        b>>=1;
        a = (a * a) % mod;
    }
    return rez;
}
void solve ()
{
    int n;
    cin >> n;
    int nr = 1, suma = 1;
    int poz = 0;
    while (numere[poz] * numere[poz] <= n && poz < numere.size())
    {
        int d = numere[poz];
        poz++;
        int cnt = 0;
        while (n % d == 0)
            n /= d, cnt++;
        if (cnt == 0)
            continue;
        nr = (nr * (cnt + 1)) % mod;
        suma = (suma * (log_pow(d, cnt + 1) - 1) * log_pow (d - 1, mod  - 2)) % mod;
    }
    if (n != 1)
    {
        nr = (nr * 2) % mod;
        suma = (suma * (log_pow (n,  2) - 1) * log_pow (n - 1, mod - 2)) % mod;
    }
    cout << nr << ' ' << suma << '\n';
}
main ()
{
    fct();
    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}
