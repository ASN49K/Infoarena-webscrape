#include <bits/stdc++.h>
using namespace std;

int MOD;

int pw(int x, int y){
    if(y==0) return 1;
    int ans=pw(x,y/2)%MOD;
    if(y%2) return (z*z*x)%MOD;
    return (z*z)%MOD;
}

inline int invMod(int x){
    int ans=pw(x,MOD-2);
    return ans%MOD;
}

int main(){
    ifstream fin("invermodular.in");
    ofstream fout("invermodular.out");
    int x;
    fin>>::MOD>>x;
    // fout<<invMod(x);
}
