#include <fstream>
using namespace std;
ifstream in("inversmodular.in");
ofstream out("inversmodular.out");
void euclid(int a, int b, int &x, int &y, int &d)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=1;
    }
    else
    {
        int x1, y1;
        euclid(b, a%b, x1, y1, d);
        x=y1;
        y=x1-a/b*y1;
    }
}
int inversmod(int a, int b, int &x, int &y, int &d)
{
    euclid(a, b, x, y, d);
    x=x%b;
    while(x<0)
    x=x+b;

    return x;
}
int main()
{
    int a, b, x, y, d;
    in >> a >> b;
    out << inversmod(a, b, x, y, d);

    return 0;
}