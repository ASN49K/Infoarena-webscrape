#include <fstream>

using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
void invers(long long &x, long long &y, int n, int mod)
{
    if(!mod)
        x = y = 1;
    else{
        invers(x, y, mod, n % mod);
        long long aux = x;
        x = y;
        y = aux - y * (n / mod);
    }
}
int main()
{
    int a, mod;
    cin >> a >> mod;
    long long x, y;
    invers(x, y, a, mod);
    while(x < 0)
        x += mod;
    cout << x;
    return 0;
}
