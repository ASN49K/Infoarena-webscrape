#include <iostream>
#include <bits/stdc++.h>
using namespace std;

#define il long long

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");



int euclid(il a,il b,il &x,il &y,il &d){
    if(b==0){
        d=a;
        x=1;
        y=0;
    }
    else{
        il x1,y1;
        euclid(b,a%b,x1,y1,d);
        x=y1;
        y=x1-a/b*y1;
        cout<<x<<' '<<y<<'\n';
    }


}





int main()
{
    il n,i,j,a,x,y,d;
    fin>>a>>n;
    euclid(n,a,x,y,d);
    while(y<0){y+=n;}
    fout<<y;

}
