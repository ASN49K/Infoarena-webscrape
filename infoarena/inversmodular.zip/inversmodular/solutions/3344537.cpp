#include <bits/stdc++.h>

using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int z,t;
int euclid(int a,int b,int& x,int& y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x1,y1;
    int d=euclid(b,a%b,x1,y1);
    x=y1;
    y=x1-y1*(a/b);
    return d;
}
int invmod(int a,int m)
{
    int x,y;
    int d=euclid(a,m,x,y);
    if(d!=1)
        return -1;
    else
        return (x%m+m)%m;
}
int main()
{
    fin >> z >> t;
    fout << invmod(z,t);
    return 0;
}
