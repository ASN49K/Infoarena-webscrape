#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

typedef long long ll;

void euclidExt(ll a, ll n, ll &x, ll &y) {
    if (n == 0) {
        x = 1;
        y = 0;
        return;
    }
    euclidExt(n, a%n, x, y);
    ll xp, yp;
    xp = yp;
    yp = x - (a/n)*y;
    x = xp;
    y = yp;
}


int main() {
    long long a, n;
    fin >> a >> n;
    ll x = 1, y = 0;
    euclidExt(a, n, x, y);
    fout << (x%n + n)%n << '\n';

    return 0;
}