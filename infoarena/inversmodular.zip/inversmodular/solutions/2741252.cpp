#include <bits/stdc++.h>
using namespace std;
ifstream fin ("inversmodular.in");
ofstream fout("inversmodular.out");
long long a,b,c,x,y,flag,r,m,aux;
pair<int,int>ans1,ans2,ans3;
void classic()
{
    flag=0;
    if(a<b)
        swap(a,b),flag=1;
    r=0,m=0;
    ans1={1,0};
    ans2={0,1};
    while(b)
    {
        m=a/b;
        r=a%b;
        ans3={ans1.first-m*ans2.first,ans1.second-m*ans2.second};
        ans1=ans2;
        ans2=ans3;
        a=b;
        b=r;
    }
    if(c%a)
    {
        fout<<"0 0\n";
        return;
    }
    if(flag==1)
        swap(ans1.first,ans1.second);
    while(ans1.first<0)
        ans1.first+=aux;
    fout<<ans1.first;
}
int main()
{
    fin>>a>>b;
    aux=b;
    c=1;
    classic();
    return 0;
}
