#include <fstream>

using namespace std;

int phi(int n) {
    int rez = 1, d = 2, put;
    while (d * d <= n) {
        put = 1;
        while (n % d == 0) {
            put *= d;
            n /= d;
        }
        rez *= put - (put / d);
        ++d;
    }
    if (n > 1)
        rez *= n - 1;
    return rez;
}

int exp2(int a, int p, int mod) {
    int rez = 1;
    while (p) {
        if (p % 2)
            rez = (1LL * rez * a) % mod;
        a = (1LL * a * a) % mod;
        p /= 2;
    }
    return rez;
}

int main() {
    ifstream in("inversmodular.in");
    ofstream out("inversmodular.out");

    int a, n;
    in >> a >> n;
    out << exp2(a, phi(n) - 1, n);

    in.close();
    out.close();
    return 0;
}