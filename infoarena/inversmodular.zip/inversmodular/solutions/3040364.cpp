#include <fstream>

using namespace std;

ifstream in ("inversmodular.in");
ofstream out ("inversmodular.out");

long long mod;

long long lgput (long long baza, long long e)
{
    long long ans = 1;
    while (e > 0)
    {
        if (e % 2 == 1)
        {
            ans = (ans * baza) % mod;
        }
        baza = (baza * baza) % mod;
        e /= 2;
    }
    return ans;
}

signed main ()
{
    long long x;
    in >> x >> mod;
    out << lgput(x, mod - 2);
    in.close();
    out.close();
    return 0;
}
