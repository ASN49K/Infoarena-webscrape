#include <bits/stdc++.h>
#define int long long
using namespace std;

void euclid(int a, int b, int &d, int &x, int &y)
{
    if(!b)
    {
        d=a;
        x=1;
        y=0;
        return;
    }
    int x1,y1;
    euclid(b,a%b,d,y1,x1);
    x=x1;
    y=y1-(a/b)*x1;
}

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int xx,mod;

signed main()
{
    fin>>xx>>mod;
    int x,y,d;
    euclid(xx,mod,d,x,y);
    fout<<x<<'\n';
    return 0;
}
