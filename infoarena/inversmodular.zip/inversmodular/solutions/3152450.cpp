#include<fstream>
using namespace std;
#define ll long long

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

ll getFi(ll a) {
	ll curr = a;
	ll i = 2;

	for (; i * i <= a; i++) {
		if (a % i == 0) {
			while (a % i == 0) { a /= i; }
			curr = (curr / i) * (i - 1);
		}
	}
	if (a != 1) {
		curr = (curr / a) * (a - 1);
	}
	return curr;
}


ll pow(ll n, ll m,ll mod) {
	if (m == 1) {
		return n;
	}
	else {
		if (m % 2 == 0) {
			return (ll)(pow(n, m / 2,mod) * pow(n, m / 2,mod));// % mod;
		}
		else {
			return (ll)(n * pow(n, m / 2,mod) * pow(n, m / 2,mod));//% mod;
		}
	}
}

int main() {
	
	ll i,a,m,res;

	cin >> a >> m;

	ll fi = getFi(m)-1;

	i = 1;
	cout << pow(a, fi, m)%m;

	return 0;
}