#include <bits/stdc++.h>
using namespace std;

int n;
void euclid(int a, int b, int& x1, int& y1)
{
    if(b==0)
    {
        x1=1;
        y1=1;
    }
    else
    {
        int x2, y2;
        euclid(b, a%b, x2, y2);
        x1=y2;
        y1=((long long)x2-a/b*y2+n)%n;
    }
}

int main()
{
    ifstream cin("inversmodular.in");
    ofstream cout("inversmodular.out");
    int a;
    cin >> a >> n;
    int x1, y1;
    euclid(a, n, x1, y1);
    cout << x1;

    return 0;
}
