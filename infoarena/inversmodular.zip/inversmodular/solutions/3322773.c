#include <stdio.h>
#include <stdlib.h>


void euclid(int a, int b, int *x, int *y){
    if(b == 0){
        *x = 1;
        *y = 0;
    }
    else{
        int x0, y0;
        euclid(b, a % b, &x0, &y0);
        *x = y0;
        *y = x0 - (a / b) * y0;
    }
}

int main()
{
    FILE *fin, *fout;
    fin = fopen("inversmodular.in", "r");
    fout = fopen("inversmodular.out", "w");

    int a, n, x, y;

    fscanf(fin, "%d%d", &a, &n);

    euclid(a, n, &x, &y);

    if(x < 0){
        x += n;
    }

    fprintf(fout, "%d", x);

    fclose(fin);
    fclose(fout);
    return 0;
}
