#include <stdio.h>

// Extended Euclidean Algorithm
int extendedEuclidean(int a, int m, int* x, int* y) {
    if (a == 0) {
        *x = 0;
        *y = 1;
        return m;
    }

    int x1, y1;
    int gcd = extendedEuclidean(m % a, a, &x1, &y1);

    *x = y1 - (m / a) * x1;
    *y = x1;

    return gcd;
}

// Function to calculate reverse modulo
int reverseModulo(int a, int m) {
    int x, y;
    int gcd = extendedEuclidean(a, m, &x, &y);

    if (gcd != 1) {
        printf("Modular inverse does not exist.\n");
        return -1; // Error: Modular inverse does not exist
    }

    // Make x positive
    if (x < 0) {
        x = (x % m + m) % m;
    }

    return x;
}

int main() {
    int a = 7; // Number
    int m = 26; // Modulo

    freopen("inversmodular.in","r",stdin);
    freopen("inversmodular.out","w",stdout);
    scanf("%d %d",&a,&m);

    int inverse = reverseModulo(a, m);
    if (inverse != -1) {
        printf("%d",inverse);
    }

    return 0;
}
