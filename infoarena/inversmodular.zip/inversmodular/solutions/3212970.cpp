#include <bits/stdc++.h>
using namespace std;

int euclid_ext(int a, int b, int& x, int& y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int d = euclid_ext(b, a % b, x1, y1);
    x = y1;
    y = x1 - y1 * (a / b);
    return d;
}

int main() {
    ifstream cin("inversmodular.in");
    ofstream cout("inversmodular.out");
    int a, b, x, y;
    cin >> a >> b;
    euclid_ext(a, b, x, y);
    if (x <= 0) {
        x += b;
    }
    cout << x;
}
