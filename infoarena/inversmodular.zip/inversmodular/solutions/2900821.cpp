#include <bits/stdc++.h>
using namespace std;

ifstream fin ("test.in");
ofstream fout ("test.out");

int a,n;

long long RidicareLaPutere (int x, int e){
    if (e==0)
        return 1;
    if (e==1)
        return x;
    long long a=1;
    while (e){
        if (e%2==1){
            a=a*x%n;
            e--;
        }
        else{
            a=1LL*a*a%n;
            e/=2;
        }
    }
    return a;
}

int main()
{
    fin >>a>>n;
    fout <<RidicareLaPutere (a,n-2);
    fin.close ();
    fout.close ();
    return 0;
}
