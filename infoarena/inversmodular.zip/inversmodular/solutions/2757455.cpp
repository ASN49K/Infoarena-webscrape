#include <bits/stdc++.h>
#include <chrono>
using namespace std;
using namespace chrono;
void debug_out() { cerr << endl; }
template<class T> ostream& prnt(ostream& out, T v) { out << v.size() << '\n'; for(auto e : v) out << e << ' '; return out;}
template<class T> ostream& operator<<(ostream& out, vector <T> v) { return prnt(out, v); }
template<class T> ostream& operator<<(ostream& out, set <T> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, map <T1, T2> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, pair<T1, T2> p) { return out << '(' << p.first << ' ' << p.second << ')'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"
#define ll long long
#define ld long double
#define ull unsigned long long
#define pii pair<int,int>
#define MOD 1000000007
#define zeros(x) x&(x-1)^x
#define fi first
#define se second

const long double PI = acos(-1);

template<class T>
class ExtendedEuclid
{  
public:
   static T run(T a, T b, T& x, T& y)
   {
      if (b == 0)
      {
         x = 1;
         y = 0;
         return a;
      }
      T x1, y1;
      T d = run(b, a % b, x1, y1);
      x = y1;
      y = x1 - y1 * (a / b);
      return d;
   }
};

template<class T>
class ModularInverse
{
   static const T DEFAULT_MOD = 10000000007;
public:
   static T run(T a, T mod = DEFAULT_MOD)
   {
      T x, y;
      ExtendedEuclid<T>::run(a, mod, x, y);
      return (x % mod + mod) % mod;
   }
};


int main()
{
   ios::sync_with_stdio(false);

   freopen("inversmodular.in", "r", stdin);
   freopen("inversmodular.out", "w", stdout);
   ll a, b;
   cin >> a >> b;
   cout << ModularInverse<ll>::run(a, b);
   return 0;
}