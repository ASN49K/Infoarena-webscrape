#include <bits/stdc++.h>
#include <chrono>
using namespace std;
using namespace chrono;
void debug_out() { cerr << endl; }
template<class T> ostream& prnt(ostream& out, T v) { out << v.size() << '\n'; for(auto e : v) out << e << ' '; return out;}
template<class T> ostream& operator<<(ostream& out, vector <T> v) { return prnt(out, v); }
template<class T> ostream& operator<<(ostream& out, set <T> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, map <T1, T2> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, pair<T1, T2> p) { return out << '(' << p.first << ' ' << p.second << ')'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"
#define ll long long
#define ld long double
#define ull unsigned long long
#define pii pair<int,int>
#define MOD 1000000007
#define zeros(x) x&(x-1)^x
#define fi first
#define se second

const long double PI = acos(-1);

template<class T>
class Exponentiation
{
   static const int DEFAULT_MOD = 1000000007;
public:
   static T run(T a, T b, T mod = DEFAULT_MOD)
   {
      T res = 1;
      while (b > 0)
      {
         if (b & 1) res *= a, res %= mod;
         b = b >> 1;
         a = (a * a) % mod;
      }
      return res;
   }
};

template<class T>
class EulerTotient
{
public:
   static map<T, T> cache;

   static long long run(long long n)
   {
      if (cache.find(n) != cache.end()) return cache[n];
      long long ans = n;
      for (long long i = 2; i * i <= n; i++)
         if (n % i == 0)
         {
            while (n % i == 0) n /= i;
            ans -= ans / i;
         }
      if (n > 1) ans -= ans / n;
      cache[2] = ans;
      return ans;
   }
};

template<class T>
map<T, T> EulerTotient<T>::cache;

template<class T>
class ModularInverse
{
   static const T DEFAULT_MOD = 10000000007;
public:
   static T run(T a, T mod = DEFAULT_MOD)
   {
      T phi = EulerTotient<T>::run(mod);
      return Exponentiation<T>::run(a, phi - 1, mod);
   }
};


int main()
{
   ios::sync_with_stdio(false);

   freopen("inversmodular.in", "r", stdin);
   freopen("inversmodular.out", "w", stdout);
   ll a, b;
   cin >> a >> b;
   cout << ModularInverse<ll>::run(a, b);
   return 0;
}