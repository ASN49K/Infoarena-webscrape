#include <bits/stdc++.h>

using namespace std;

ifstream fin("fotbal.in");
ofstream fout("fotbal.out");

void euclid(int a , int b ,int & x ,int & y)
{
    if(b == 0)
    {
        x = 1, y = 1;
    }
    else
    {
        int x1 , y1;
        euclid(b , a % b , x1 , y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}

int main()
{
    int A = 9, N = 11;
    fin>>A>>N;
    int X , Y;
    euclid(A, N , X ,Y);
    while(X < 0)
        X += N;
    fout << X;
    return 0;
}
