#include <iostream>
#include <fstream>
using namespace std;
ifstream in("inversmodular.in");
ofstream out("inversmodular.out");
int a,n,m;
int invers()
{
    long long val=1,aux=a;
    for(int i=1;i<=m;i=i<<1)
    {
        if(m&i)
        {
            val=(val*aux)%n;
        }
        aux=(aux*aux)%n;
    }
    return val;
}
int main()
{
    in>>a>>n;
    m=n-2;
    out<<invers();
    return 0;
}
