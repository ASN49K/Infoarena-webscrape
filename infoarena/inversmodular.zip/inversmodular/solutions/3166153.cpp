#include <iostream>
#include <fstream>
#define nl '\n'

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(int a, int b, int &d, int &x, int &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        d = a;
    }
    else
    {
        int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - a/b*y0;
    }
    return;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int a, n, d, x, y;
    fin >> a >> n;
    euclid(a, n, d, x, y);
    fout << x;
    return 0;
}

