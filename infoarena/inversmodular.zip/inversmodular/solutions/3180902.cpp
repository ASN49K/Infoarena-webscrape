#include <bits/stdc++.h>
#define ll int64_t
using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
ll a,n,x,y;
ll cmmdc(ll a,ll b,ll &x,ll &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    ll X,Y,D;
    cmmdc(b,a%b,X,Y);
    x=Y;
    y=X-a/b*Y;
    return D;
}
int main()
{
    f>>a>>n;
    cmmdc(a,n,x,y);
    x%=n;
    while(x<0)
        x+=n;
    g<<x;
    return 0;
}
