#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int A, N;

int phi(int n){
    int rez = n, d = 2;
    while(n > 1){
        if(n % d == 0){
            rez = rez * (d - 1) / d;
            while(n % d == 0){
                n /= d;
            }
        }
        d++;
        if(d * d > n){
            d = n;
        }
    }
    return rez;
}

int lgput(int x, int n){
    if(n == 0){
        return 1;
    }
    else if(n % 2 == 0){
        return lgput(x *x % N, n / 2) % N;
    }
    else{
        return (x * lgput(x *x % N, n / 2)) % N;
    }
}

int main(){
    fin>>A>>N;
    fout<<lgput(A, phi(N) - 1) % N<<"\n";
    return 0;
}