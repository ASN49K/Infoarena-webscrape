#include <fstream>

using namespace std;
ifstream fin ("inversmodular.in");
ofstream fout ("inversmodular.out");

int a, n;

int euclid_E(int a, int b, int &x, int &y);

int main()
{
    int x, y;
    fin >> a >> n;
    euclid_E(a, n, x, y);
    fout << x;
    return 0;
}

int euclid_E(int a, int b, int &x, int &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int d = euclid_E(b, a%b, x1, y1);
    x = y1;
    y = (x1 - y1*(a/b));
    return d;
}
