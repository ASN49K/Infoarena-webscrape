#include <fstream>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long a, n;

// gasim x si y ca a*x + b*y = cmmdc(a, b) sa fie adevarat
// returneaz cmmdc iar x si y calculate prin referinta
long long euclid(long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }

    long long x1, y1;
    long long d = euclid(b, a % b, x1, y1);

    x = y1;
    y = x1 - (a / b) * y1;

    return d;
}

int main()
{
    fin >> a >> n;

    long long x, y;

    euclid(a, n, x, y);

    x = x % n;
    if (x < 0)
        x = x + n;

    fout << x;

    return 0;
}
