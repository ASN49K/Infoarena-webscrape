#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
void gcd_nebun(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return;
    }
    int xx,yy;
    gcd_nebun(b,a%b,xx,yy);
    x=yy;
    y=xx-yy*(a/b);
}
signed main()
{
    int a,b,x,y;
    cin>>a>>b;
    gcd_nebun(a,b,x,y);
    if(x<=0)
    {
        x=b+(x%b);
    }
    cout<<x;
    exit(0);
}
