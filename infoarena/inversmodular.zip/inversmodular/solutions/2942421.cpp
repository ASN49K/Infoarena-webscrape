#include <fstream>

using namespace std;

int euler(int n)
{
    int e = n, d = 2;
    while (d * d <= n)
    {
        if (n % d == 0)
        {
            e = e / d *(d - 1);
            while (n % d == 0)
            {
                n /= d;
            }
        }
        d++;
    }
    if (n != 1)
    {
        e = e / n * (n - 1);
    }
    return e;
}

int putere(int a, int n, int mod)
{
    int p = 1;
    while (n != 0)
    {
        if (n % 2 != 0)//(n & 1) != 0
        {
            p = (long long)p * a % mod;
        }
        a = (long long)a * a % mod;
        n /= 2;// n <<= 1
    }
    return p;
}

int main()
{
    ifstream in("inversmodular.in");
    ofstream out("inversmodular.out");
    int a, n;
    in >> a >> n;
    int phi = euler(n);
    out << putere(a, phi - 1, n);
    in.close();
    out.close();
    return 0;
}
