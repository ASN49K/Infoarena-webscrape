#include <bits/stdc++.h>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

void euclid_extins(int &x, int &y, int a, int b){
 
    if(b == 0){
        x = 1;
        y = 0;
    }
    else{
        int x1 , y1;
        euclid_extins(x1, y1, b, a%b);
        x = y1;
        y = x1 - y1 * (a / b);
    }
}

int main(void){
    
    int a, n = 0;
    
    f >> a >> n;
    
    int x = 0, y = 0;
    
    euclid_extins(x, y, a, n);
    
    g << x;
    
    return 0;
}