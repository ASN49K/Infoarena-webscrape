#include <bits/stdc++.h>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

int MOD;

long long pow_log(long long x,long long n)
{
    long long sol=1;
    while(n)
    {
        if(n%2)sol*=x,sol%=MOD;
        x*=x;
        x%=MOD;
        n/=2;
    }
    return sol;
}

int main()
{
    int a,n;
    f>>a>>n;
    MOD=n;
    g<<pow_log(a,n-2);
}
