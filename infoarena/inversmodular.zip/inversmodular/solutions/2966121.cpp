#include <bits/stdc++.h>

using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
int a,n,x,y;
int cmmdc(int a, int b, int &u, int &v)
{
    if(b==0)
    {
        u=1;
        v=0;
        return a;
    }
    int U,V,D;
    D=cmmdc(b,a%b,U,V);
    u=V;
    v=U-a/b*V;
    return D;
}
int main()
{
    f>>a>>n;
    cmmdc(a,n,x,y);
    g<<x<<'\n';
    return 0;
}
