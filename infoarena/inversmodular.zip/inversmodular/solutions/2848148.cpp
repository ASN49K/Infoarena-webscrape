#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(long long a,long long b,long long &d,long long &x,long long &y)
{
    if (b == 0) d=a,x=1,y=0;
    else
    {
        long long x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    long long int a,n;
    fin>>a>>n;

    long long int d,x,y;
    euclid(a,n,d,x,y);

    if (x>n-1||x<1)
        x=-1;
    fout<<x;
    return 0;
}
