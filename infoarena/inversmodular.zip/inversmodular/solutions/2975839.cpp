#include <iostream>
#include <fstream>
#include <queue>
#include <cstring>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(long long int a, long long int b, long long int& d, long long int& x, long long int& y);

int main() {

    long long int a, b, d, x, y;
    fin >> a >> b;
    euclid(a, b, d, x, y);
    if (x < 0)
        x += b;
    fout << x;

    return 0;
}

void euclid(long long int a, long long int b, long long int& d, long long int& x, long long int& y) {

    if (b == 0) {
        d = a;
        x = 1; y = 0;
    }
    else {
        long long int x0, y0;
        euclid(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }

}