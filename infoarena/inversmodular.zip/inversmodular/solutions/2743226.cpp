#include <bits/stdc++.h>

using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
void euclid_extins(int a, int b, long long &x, long long &y)
{
    if(a==0)
    {
        x = 0;
        y = 1;
        return;
    }
    long long x0,y0;
    euclid_extins(b%a,a,x0,y0);
    x = y0-(b/a)*x0;
    y = x0;
}
int main()
{
    int a,n;
    f>>a>>n;
    long long x,y;
    euclid_extins(a,n,x,y);
    if(x<0)
    {
        x+=n;
    }
    g<<x<<'\n';
    return 0;
}
