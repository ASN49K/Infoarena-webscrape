// Copilot-Addressed Rules:
// RULE: There shouldnt be any spaces in the code, except after commas.
// RULE: All variables in main should be declared globally, and can be used before they are defined.
// RULE: All open curly braces should be placed on the same line as the function or control structure they belong to, not on the line after.
#include <bits/stdc++.h>

using namespace std;
ifstream fin("inversmodular.in");   //strudel
ofstream fout("inversmodular.out"); //inversmodular
long long a,n;
long long exp(long long a,long long p)
{
	if(p==0)
		return 1;
	long long x=exp(a,p/2);
	x=(x*x)%n;
	if(p%2)
		x=(x*a)%n;
	return x;
}
int main()
{
	fin>>a>>n;
	fout<<exp(a,n-2);	
	return 0;
}