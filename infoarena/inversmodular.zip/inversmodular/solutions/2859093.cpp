#include <bits/stdc++.h>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
void eud(int a,int b, int &X,int &Y){
  if(b==0) X=1,Y=1;
  else{
    int x1,y1;
    eud(b,a%b,x1,y1);
    X=y1;
    Y=x1-a/b*y1;
  }
}

int a,n,x,y;
int main(){
   
   fin>>a>>n;
   eud(a,n,x,y);
   while(x<0)
     x+=n;
   fout<<x;
}