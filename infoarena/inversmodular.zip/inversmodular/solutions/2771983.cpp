#include <fstream>

using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
void euclidth(long long &x, long long &y, int a, int n)
{
    if(!n){
        x = 1;
        y = 1;
    }
    else{
        euclidth(x, y, n, a % n);
        long long aux = x;
        x = y;
        y = aux - y * (a / n);
    }
}
int main()
{
    long long x, y, a, n;
    cin >> a >> n;
    euclidth(x, y, a, n);
    while(x < 0)
        x += n;
    cout << x;
    return 0;
}
