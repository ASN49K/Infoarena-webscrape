#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int eu(int n)
{
    int d=2,p=0,rasp=1,c=n;
    while(d*d<=n)
    {
        p=0;
        while(n%d==0)
        {
            p++;
            n/=d;
        }
        if(p)
        {
            rasp*=(1-(1/d));
        }
        d++;
    }
    if(n>1)
    {
        rasp*=(1-(1/n));
    }
    return rasp*c;
}
int main()
{
    long long int a,x,n,p=1;
    fin>>a>>n;
    x=eu(n)-2;
    while(x>0)
    {
        if(x%2==1)
        {
            p=p*a;
        }
        a=a*a;
        x/=2;
    }
    fout<<p%n;
    return 0;
}
