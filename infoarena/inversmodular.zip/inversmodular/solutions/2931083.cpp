#include <bits/stdc++.h>

using namespace std;
#define int unsigned long long
int lgput(int a,int b,int mod)
{
  a%=mod;
  int c=1;
    while(b>0)
  {
      if(b%2==1)
      c=(c*a)%mod;
      a=(a*a)%mod;
      b/=2;
  }
  return c;
}
signed main()
{
 ifstream cin("inversmodular.in");
  ofstream cout("inversmodular.out");
  int a,b;
  cin>>a>>b;
  /*int d=2,nd=1,mod=9901;
  while(d*d<=a)
  {int cnt=0;
    while(a%d==0)
    {
      a=a/d;
      cnt++;
    }
    if (d%mod!=1)
      nd=nd*(lgput(d,cnt*b+1,mod)-1+mod)%mod*lgput(d-1,mod-2,mod)%mod;
    else
      nd=nd*(cnt*b+1)%mod;
    d++;
  }
  if(a>1)
  {
    if (a%mod!=1)
      nd=nd*(lgput(a,b+1,mod)-1+mod)%mod*lgput(a-1,mod-2,mod)%mod;
    else
      nd=nd*(b+1)%mod;
  }
  cout<<nd;*/
  cout<<lgput(a,b-2,b);
    return 0;
}
