#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <numeric>
#include "stdio.h"
using namespace std;

#define ll long long
const int inf = 0x3f3f3f3f;

int euclid(int a, int b, int&x, int&y) {
    if(b==0) {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0;
    int ret = euclid(b, a%b, x0, y0);
    x = y0;
    y = x0 - (a/b)*y0;
    return ret;
}

void solve() {
    int a, b, x, y;
    cin >> a >> b;
    int d = euclid(b,a,x,y);
    
    cout << y/d << "\n";
}

int main() {
    #ifdef DEBUG
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
    #endif

    #ifdef  INFOARENA
    freopen("inversmodular.in", "r", stdin);
    freopen("inversmodular.out", "w", stdout);
    #endif  //INFOARENA

    solve();
}

