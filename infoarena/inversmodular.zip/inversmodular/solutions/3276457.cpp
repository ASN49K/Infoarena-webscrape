#include <bits/stdc++.h>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclidex(int a,int b,int &d,int &x,int &y){
    if(b==0){
        d=a;
        x=1;
        y=0;
    }else{
        int x1,y1;
        euclidex(b,a%b,d,x1,y1);
        x=y1;
        y=x1-(a/b)*y1;
    }
}
int modinv(int a,int b){
    int d,x,y;
    euclidex(a,b,d,x,y);
    if(d!=1) return 0;
    return (x%b+b)%b;
}

int main(){
    int a,b;
    fin>>a>>b;
    fout<<modinv(a,b);
    return 0;
}