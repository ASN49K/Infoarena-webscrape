#include <iostream>
#include <fstream>
using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
void euclid(long long a, long long b, long long &x, long long &y)
{
    if(b==0)
    {
        x=1;
        y=1;
    }
    else
    {
        long long x1, y1;
        euclid(b, a%b, x1, y1);
        x=y1;
        y=x1-a/b*y1;
    }
}
int main()
{
    long long a,b,x,y;
    f>>a>>b;
    euclid(a,b,x,y);
    if(x<0)
        while(x<0)
            x+=b;
    g<<x;
    return 0;
}
