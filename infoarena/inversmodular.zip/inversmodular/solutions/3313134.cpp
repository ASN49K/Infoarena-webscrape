#include <fstream>
using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
void EuclidExtins(int a, int b, int &d, int &x, int &y)
{
    if(b==0)
        x=1,y=0,d=a;
    else{
        int x0,y0;
        EuclidExtins(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
int inversMod(int a, int b)
{
    int d,x,y;
    EuclidExtins(a,b,d,x,y);
    while(x<0)x+=b;
    return x;
}
int main()
{
    int a,b;
    f>>a>>b;
    g<<inversMod(a,b);
    f.close();
    g.close();
    return 0;
}
