#include <bits/stdc++.h>
using namespace std;

//folosind a*a^(n-2)=1 (mod n)
int n;
int exponentiere_rapida(int a, int e) //calculam a^e
{
    int p=1;
    while(e>0)
    {
        if((e&1)==1)
            p=((long long)p*a)%n;
        a=((long long)a*a)%n;
        e>>=1;
    }
    return p;
}

int main()
{
    ifstream cin("inversmodular.in");
    ofstream cout("inversmodular.out");
    int a;
    cin >> a >> n;
    cout << exponentiere_rapida(a, n-2);

    return 0;
}
