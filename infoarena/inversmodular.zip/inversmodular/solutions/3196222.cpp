#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

long long a, n;

void euclid(long long a, long long b, long long& x, long long& y);

int main()
{
    long long x, y;

    cin >> a >> n;

    euclid(a, n, x, y);

    cout << x % n;

    return 0;
}

void euclid(long long a, long long b, long long& x, long long& y)
{
    if(b == 0)
    {
        y = 0;
        x = 1;
        return;
    }

    long long x1, y1;

    euclid(b, a % b, x1, y1);

    x = y1;
    y = x1 - y1 * a / b;

    x %= n;
    y %= n;
}