#include <bits/stdc++.h>
using namespace std;

int MOD;

int phi(int n){
    int r = n , d = 2;
    while(n > 1){
        if(n % d == 0){
            r = r / d * (d - 1);
            while(n % d == 0)
                n /= d;
        }
        d ++;
        if(d * d > n)
            d = n;
    }
    return r;
}

int lgput(int a, int b){
    int put = 1;
    while(b){
        if(b % 2 == 1){
            put *= a;
            put %= MOD;
        }
        a *= a;
        b /= 2;
        a %= MOD;
    }
    return put;
}

int inv(int a){
    return (lgput(a,phi(MOD) - 1));
}

int main(void){
    ofstream cout("inversmodular.out");
    ifstream cin("inversmodular.in");
    int n;
    cin >> n >> MOD;
    cout << inv(n);
}
