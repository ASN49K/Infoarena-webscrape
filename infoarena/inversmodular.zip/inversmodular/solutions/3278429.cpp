#include<fstream>
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
int n,p,i;
int main()
{
    cin>>n>>p;
    for(i=0;i<p;i++)
        if(n*i%p==1)
    {
        cout<<i;
        return 0;
    }
    return 0;
}
