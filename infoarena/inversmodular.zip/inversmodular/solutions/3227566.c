#include <stdio.h>
#include <stdlib.h>

int main() {
  //freopen("inversmodular.in","r",stdin);
  //freopen("inversmodular.out","w",stdout);
  int a, n;
  scanf("%d%d", &a, &n);
  
  for (int i = 0; i < n; i++) {
    if ((a * i) % n == 1) {
      printf("%d\n", i);
      break;
    }
  }
  
  return 0;
}
