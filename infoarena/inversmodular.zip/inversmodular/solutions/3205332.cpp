#include <iostream>
#include <fstream>

typedef long long LL;

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

LL a, n, phi, rez, fct;

LL phiOf(LL n){
    LL rez = n;

    for(int i = 2; i*i <= n; ++i)
        while(n % i == 0){
            n /= i;
            rez = (rez / i) * (i - 1);
        }

    if(n != 1)  /// a ramas un nr prim mare
        rez = (rez / n) * (n - 1);

    return rez;
}

int main()
{
    f >> a >> n;

    phi = n - 2;

    rez = 1, fct = a;
    while(phi > 0){
        if(phi % 2 == 1)
            rez = (rez * fct) % n;
        fct = (fct * fct) % n;
        phi >>= 1;
    }

    g << rez;

    return 0;
}
