#include <iostream>
#include <fstream>

void euclid(long long a, long long b, long long &x, long long &y){
	if(b == 0){
		x = 1, y = 0;
		return;
	}
	long long kovx, kovy;
	euclid(b, a % b, kovx, kovy);
	x = kovy;			// ezt a két sort nem nagyon értem,
	y = kovx - (a / b) * kovy; 	//
}

int main(){
	std::ifstream bem("inversmodular.in");
	long long a, n;
	bem >> a >> n;
	bem.close();

	long long x, y;
	euclid(a, n, x, y);
	while(x < 0)
		x += n;
	std::ofstream kim("inversmodular.out");
	kim << x << "\n";
	kim.close();
	return 0;
}
