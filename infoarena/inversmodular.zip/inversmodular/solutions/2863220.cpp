#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

const string myf = "inversmodular";
ifstream fin(myf + ".in");
ofstream fout(myf + ".out");

// const  int mod = 1999999973;



int a, n;

int exp(int a, int n, int mod) {
	ll p = 1;
	while (n) {
		if (n & 1)
			p = p * a % mod;
		a = a * a % mod;
		n >>= 1;
	}
	return p;
}

int main() {


	fin >> a >> n;
	fout << exp(a, n - 2, n) << '\n';
	fin.close();
	fout.close();
	return 0;
}