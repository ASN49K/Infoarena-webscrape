using namespace std;
#include<iostream>
#include<fstream>
#include<vector>

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long n, a;

int inversmodular(long long a, long long n, long long MOD) {
    int p = 1;
    while (n) {
        if (n%2) {
            p = p*a;
            p %= MOD;
        }
        n/=2;
        a = a*a;
        a %= MOD;
    } ///calculam a ^ (n-2)
    
    return p;
}

int main() {

    fin >> a >> n;
    fout << inversmodular(a, n-2, n);
    
    return 0;
}
