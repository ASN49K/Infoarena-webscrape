#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
ifstream fin ("inversmodular.in");
ofstream fout ("inversmodular.out");
long long inv(long long a, long long b,long long &x, long long &y)
{
    long long d,aa,bb;
    if(b==0)
    {
        x=1,y=0;
        return a;
    }
    d=inv(b,a%b,aa,bb);
    x=bb;
    y=aa-(a/b)*bb;
    return d;
}
int main()
{
    long long a,b,x,y;
    fin>>a>>b;
    inv(a,b,x,y);
    fout <<(x+b)%b;
    return 0;
}
