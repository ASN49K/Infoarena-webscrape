#include <iostream>
using namespace std;

void euclid(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x=1;
        y=0;
    }
    else
    {
        int x1, y1;
        euclid(b, a%b, x1, y1);
        x = y1;
        y=x1-a/b*y1;
    }
}

int main()
{
    int a,b,x,y;
    cin>>a>>b;
    euclid(a,b,x,y);
    while(x<0)
        x+=b;
    cout<<x;
    return 0;
}
