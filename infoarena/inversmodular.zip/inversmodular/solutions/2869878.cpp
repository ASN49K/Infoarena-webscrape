#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long a, n;

int LogP(int a, int n, int P)
{
    int rez = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
            rez = 1LL * rez * a % P;
        n /= 2;
        a = 1LL * a * a % P;
    }
    return rez;
}

int Phi(int n)
{
    int phi = n, f = 2, e;
    while (n > 1)
    {
        e = 0;
        while (n % f == 0)
        {
            e++;
            n /= f;
        }
        if (e > 0) phi = phi / f * (f - 1);
        if (f * f < n) f++;
        else f = n;
    }
    return phi;
}

int main()
{

    fin >> a >> n;
    fout << LogP(a, Phi(n) - 1, n) << "\n";
    fin.close();
    fout.close();

    return 0;
}
