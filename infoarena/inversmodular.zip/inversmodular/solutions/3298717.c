#include <stdio.h>

int getphi(int n)
{
    int rez=n;
    for(int d=2; d*d<=n; d++)
    {
        if(n%d==0)
        {
            while(n%d==0)
            n=n/d;
            rez=rez-rez/d;
        }
    }
    if(n>1)
    rez=rez-rez/n;
    return rez;

}

int main(void)
{
    FILE *fin=NULL, *fout=NULL;
    fin=fopen("inversmodular.in","r");
    fout=fopen("inversmodular.out","w");
    int a, n;
    fscanf(fin,"%d %d",&a,&n);
    fclose(fin);
    int p=getphi(n)-1;
    unsigned long long sol=1;
    a=a%n;
    while(p>0)
    {
        if(p%2==1)
        sol=(sol*a)%n;
        
        a=(a*a)%n;
        p=p/2;
   }

   fprintf(fout,"%llu", sol);
   fclose(fout);


    return 0;
}