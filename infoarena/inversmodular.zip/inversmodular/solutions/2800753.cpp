#include <iostream>

using namespace std;

ifstream in("inversmodular.in");
ofstream out("inversmodular.out");
int n;

int fastpow(long long a, int p){
    long long x = 1;
    while(p > 0){
        if(p & 1)
            x = (x * a) % n;
        a = (a * a) % n;
        p /= 2;
    }
    return x;
}

int invers_modular(int a){
    int x;
    x = fastpow(a, n - 2);
    return x;
}

int main()
{
    int a;
    in >> a >> n;
    out << invers_modular(a);
    return 0;
}
