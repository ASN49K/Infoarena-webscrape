#include<fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long a,n;

void euclid(long long a,long long b,long long &x,long long &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return;
    }

    long long x0,y0;
    euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-(a/b)*y0;
}

int main()
{
    fin>>a>>n;
    long long x,y;
    euclid(a,n,x,y);
    x%=n;
    if(x<0)
        x+=n;
    fout<<x;
    return 0;
}
