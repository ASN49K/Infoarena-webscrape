#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int a,b;

int nr_prime_mici()
{
    int i,j,contor = 0,d,adv = 1;
    for(i=2;i<b;i++)
    {
        adv  = 1;
        for(d=2;d*d<=i;d++)
            if(i%d==0)
                adv = 0;
        if(adv == 1)
            contor++;
    }
    return contor;

}

int main()
{
    fin>>a>>b;
    fout<<nr_prime_mici();
    return 0;
}
