#include <fstream>
#include <algorithm>
#define ll long long
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
ll a,n;
ll inv(ll x)
{
	if(x<=1)
		return x;
	else
		return n-(n/x)*inv(n%x)%n;
}
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cin>>a>>n;
	cout<<inv(a);
	return 0;
}
