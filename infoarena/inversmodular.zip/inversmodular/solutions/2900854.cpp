#include <bits/stdc++.h>
using namespace std;

ifstream fin ("test.in");
ofstream fout ("test.out");

long long a,n;

long long Putere(long long A , long long e)
{
    if(e == 0)
        return 1;
    if (e == 1)
        return A;
    if(e % 2 == 1)
        return A * Putere(A , e - 1) % n;
    long long P = Putere(A , e / 2) % n;
    return P * P % n;
}

int main()
{
    fin >>a>>n;
    fout <<Putere (a,n-2);
    fin.close ();
    fout.close ();
    return 0;
}
