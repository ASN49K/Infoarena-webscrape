#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int main() {
    int a, n;
    fin>>a>>n;
    for(int i=1; i<=n-1;i ++){
        if((a*i)/n==1){
            fout<<i;
        }
    }
    return 0;
}
