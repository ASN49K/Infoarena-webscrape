#include <fstream>

using namespace std;

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

int euclid(int a, int b, int &x, int &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int x0, y0;
    int d = euclid(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main() {
    cin.tie(0);
    cin.sync_with_stdio(false);

    int a, b;
    cin >> a >> b;
    int inva, invb;
    euclid(a, b, inva, invb);
    cout << inva;
    return 0;
}
