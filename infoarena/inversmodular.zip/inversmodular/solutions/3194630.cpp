#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int phi(int n)
{
    int r = n , d = 2;
    while(n > 1)
    {
        if(n % d == 0)
        {
            r = r / d * (d - 1);
            while(n % d == 0)
                n /= d;
        }
        d ++;
        if(d * d > n)
            d = n;
    }
    return r;
}
long long pw(long long a,long long b)
{
    if(b==0)return 1;
    if(b%2==1)return a*pw(a,b-1);
    long long  P=pw(a,b/2);
    return P*P;
}
int main()
{
    long long  x,y;
  fin>>x>>y;


  fout<<pw(x,y-2)%y;


    return 0;
}
