#include <bits/stdc++.h>
using namespace std;

ifstream fin ("inversmodular.in");
ofstream fout ("inversmodular.out");

long long a,n,MOD;

int lgput(int x, int p){
    int ans = 1, aux = x;
    for(int i = 1; i <= p ; i = i << 1){
        if(i & p) ans = (1LL * ans * aux) % MOD;
    aux = (1LL * aux * aux) % MOD;
}
return ans;
}

int main()
{
    fin >>a>>n;
    MOD=n;
    fout <<lgput (a,n-2);
    fin.close ();
    fout.close ();
    return 0;
}
