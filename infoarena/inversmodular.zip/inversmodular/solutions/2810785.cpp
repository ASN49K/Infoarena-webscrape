#include <iostream>
#include <fstream>
using namespace std;
int euclid (int a,int b,int &x,int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0,d;
    d = euclid (b,a%b,x0,y0);
    x=y0;
    y=x0-a/b*y0;
    return d;
}
int main()
{
    ifstream f ("inversmodular.in");
    ofstream g ("inversmodular.out");
    int a,b,x,y,c,d;
    f>>a>>b;
    c=1;
    d=euclid(a,b,x,y);
    g<<c/d*x;
}
