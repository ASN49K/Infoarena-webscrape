#include <fstream>
using namespace std;

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

int exponentiereRapida(int x, int putere) {

    if (putere == 1) {
        return x;
    }
    if (putere == 0) {
        return 1;
    }
    if (putere%2 == 0) {
        int A = exponentiereRapida(x,putere/2);
        return A*A;
    }
    else {
        return exponentiereRapida(x,putere - 1);
    }

}

int main()
{

    int a,n;
    cin>>a>>n;

    for (int i=0; i<n-1; i++) {

        if (((a % n) * (i % n)) % n == 1) {
            cout<<i;
            return 0;
        }

    }

}
