#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    FILE *file = fopen("inversmodular.in", "r");
    FILE *output = fopen("inversmodular.out", "w");
    if (file == NULL)
    {
        fprintf(stderr, "Eroare deschidere fisier intrare.\n");
        return 1;
    }
    if (output == NULL)
    {
        fprintf(stderr, "Eroare deschidere fisier iesire.\n");
        fclose(file);
        return 1;
    }
    long long a,n;
    long long x;
    fscanf(file,"%lld %lld", &a,&n);
    long long c=a%n;
    long long p=n-2;
    long long rez=1;
    while (p > 0)
    {
        if(p%2==1)
        {
            rez=rez*c;
            rez=rez%n;
        }
        c=c*c;
        c=c%n;
        p=p/2;
    }
    fprintf(output,"%lld\n", rez);
    return 0;
}