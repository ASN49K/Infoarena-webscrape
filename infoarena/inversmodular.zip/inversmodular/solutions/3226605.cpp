#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define int long long
using namespace std;

int Inv1(int a,int b,int mod){
  int ans;

  ans=1;
  while(b>0){
    if(b%2==1){
      ans*=a;
      ans%=mod;
    }
    a*=a;
    a%=mod;
    b/=2;
  }

  return ans;
}

signed main(){
  int a,m;
  FILE *fin,*fout;
  fin=fopen("inversmodular.in","r");
  fout=fopen("inversmodular.out","w");
  fscanf(fin,"%lld%lld",&a,&m);

  fprintf(fout,"%lld",Inv1(a,m-2,m));

  fclose(fin);
  fclose(fout);
  return 0;
}
