#include <fstream>

using namespace std;

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

void euclid(int a, int b, int& x, int& y) {
    if(b == 0) {
        x = 1;
        y = 1;
        return;
    }

    int x1, y1;
    euclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - a / b * y1;
}

int invmod(int a, int mod) {
    int x, y;
    euclid(a, mod, x, y);
    while(x < 0) {
        x += mod;
    }
    return x;
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << invmod(a, b) << '\n';
    return 0;
}