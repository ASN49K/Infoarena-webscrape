#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void cmmdc(int a, int b, int &x, int &y, int &d)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        int x0, y0;
        cmmdc(b, a%b, x0, y0, d);
        x=y0;
        y=x0-(a/b)*y0;
    }
}

int main()
{
    int a, n, x, y, d;
    fin>>a>>n;
    cmmdc(a, n, x, y, d);
    if(d==1)
    {
        while(x<0)
            x+=n;
        fout<<x;
    }
    return 0;
}
