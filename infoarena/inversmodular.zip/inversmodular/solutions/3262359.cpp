 #include <bits/stdc++.h>
 
 using namespace std;
 
 int main() {

	ifstream in("inversmodular.in");
	ofstream out("inversmodular.out");

	int n, mod;
	in >> n >> mod;

	int ans = 1, aux = n, p = mod - 2;
	for(int i = 0; (1 << i) <= p; i++) {
		if((1 << i) & p) {
			ans = 1LL * ans * aux % mod;
		}
		aux = 1LL * aux * aux % mod;
	}

	out << ans << '\n';

	return 0;
 }