#include <stdio.h>
#include <iostream>
#include <fstream>
#include <math.h>

// https://infoarena.ro/problema/inversmodular

// a * x + b * y = d
void euclid_ext(long long int a, long long int b, long long int* d, long long int* x, long long int* y)
{
	if (b == 0) {
		*d = a;
		*x = 1;
		*y = 0;
	}
	else {
		long long int x0, y0;
		euclid_ext(b, a % b, d, &x0, &y0);
		*x = y0;
		*y = x0 - (a / b) * y0;
	}
}

int main() {
	std::ifstream fin("inversmodular.in");
	std::ofstream fout("inversmodular.out");
	long long int A, N, x, y, d;
	d = 1;
	x = 0;
	y = 0;
	fin >> A;
	fin >> N;
	euclid_ext(A, N, &d, &x, &y);	// A * X + N * Y = 1
	
	if (x <= 0) x = N + x % N;
	fout << x;

	fin.close();
	fout.close();

	return 0;
}