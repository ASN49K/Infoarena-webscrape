#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("euclid3.in");
ofstream fout("euclid3.out");
void euclid(int a, int b, long long &x, long long &y)
{
    if(b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        euclid(b, a%b, x, y);
        int aux=x;
        x=y;
        y=aux-(a/b)*x;
    }
}
int main()
{
    int a, n;
    cin>>a>>n;
    long long x=0, y;
    euclid(a, n, x, y);
    while(x<0)
    {
        x+=n;
    }
    cout<<x;
    return 0;
}
