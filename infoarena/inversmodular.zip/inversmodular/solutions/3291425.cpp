#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long a, b;

long long power(long long base, long long p, long long mod){
    long long result=1;
    while(p>0){
        if(p%2==1){
            result=(result * base) % mod;
        }
        base=(base*base)%mod;
        p=p/2;
    }
    return result;
}
int main()
{
    fin >> a >> b;
    fout << power(a, b-2, b);
    return 0;
}
