#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

// a * x + n * y = cmmdc(a, n)
// a si n prime intre ele => cmmdc e 1
void euclid_extins(int a, int n, int &x, int &y)
{
    if(n == 0)
    {
        x = 1;//inversu modular ajunhge in x
        y = 0;
    }
    else
    {
        int x0, y0;
        euclid_extins(n, a % n, x0, y0);
        x = y0;
        y = x0 - (a / n) * y0;
    }
}
int main()
{
    int a, n, x, y;
    fin >> a >> n;
    euclid_extins(a, n, x, y);
    if(x < 0)
        x += n;

    fout << x;
    return 0;
}
