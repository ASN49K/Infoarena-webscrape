#include <fstream>
using namespace std;
ifstream in("inversmodular.in");
ofstream out("inversmodular.out");

int n, a, b, c;
int x, y;

int euclid_ext(int a, int b, int& x, int& y) {
    int x1, y1, d;
    if (b == 0) {
        x = 1; y = 0;
        return a;
    }
    d = euclid_ext(b, a % b, x1, y1);
    x = y1;
    y = x1 - y1 * (a / b);
    return d;
}

int main()
{
    int aux;
    in >> a >> n;
    euclid_ext(a, n, x, y);
    if (x < 0) {
        aux = (-1) * x;
        aux /= n;
        x += (aux + 1) * n;
    }
    out << x << '\n';
    return 0;
}
