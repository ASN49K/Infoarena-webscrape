#include <fstream>

using namespace std;

ifstream in ("inversmodular.in");
ofstream out ("inversmodular.out");

long long mod;

void euclid (long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x = 1;
        y = 1;
        return;
    }
    long long x0, y0;
    euclid(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return;
}

signed main ()
{
    long long x;
    in >> x >> mod;
    long long auxx, auxy;
    euclid(x, mod, auxx, auxy);
    while (auxx < 0)
    {
        auxx += mod;
    }
    out << auxx;
    in.close();
    out.close();
    return 0;
}
