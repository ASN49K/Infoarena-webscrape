#include <fstream>

using namespace std;

void euclid(int a, int b, int* d, int* x, int* y) {
    if (b==0) {
        *d=a;
        *x=1;
        *y=0;
    }
    else {
        int x0, y0;
        euclid(b, a%b, d, &x0, &y0);
        *x = y0;
        *y = x0 - (a/b)*y0;
    }
}

int main()
{
    ifstream fin("inversmodular.in");
    ofstream fout("inversmodular.out");

    int A,N;
    fin>>A>>N;

    int* d=new int;
    int* x=new int;
    int* y=new int;

    euclid(A, N, d, x, y);

    fout<<*x;

    delete d,x,y;

    fin.close();
    fout.close();
    return 0;
}
