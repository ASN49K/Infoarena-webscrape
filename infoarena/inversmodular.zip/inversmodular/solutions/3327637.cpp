#include <fstream>
using namespace std;
ifstream cin ("inversmodular.in");
ofstream cout("inversmodular.out");
void euclid(long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x=1;
        y=1;
    }
    else
    {
        long long x1, y1;
        euclid(b, a%b, x1, y1);
        x=y1;
        y=x1-(a/b)*y1;
    }
}

int main()
{
    long long a, n;
    cin >> a >> n;
    long long x, y;
    euclid(a, n, x, y);
    x=(x%n+n)%n;
    cout << x;
    return 0;
}
