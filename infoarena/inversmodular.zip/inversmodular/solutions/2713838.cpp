#include <fstream>
#define mF "inversmodular"
std::ifstream in(mF ".in");
std::ofstream out(mF ".out");
int main()
{
    long long e, m, r = 1; in >> e >> m;
    for (int n = m - 2; n; n >>= 1)
    {if (n & 1) r *= e, r %= m; e *= e, e %= m;}
    out << r;
}
