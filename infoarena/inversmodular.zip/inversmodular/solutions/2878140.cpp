#include <bits/stdc++.h>
#define ll long long

using namespace std;

void euclid( int a, int b, ll &x, ll& y ) {
    if ( b == 0 ) {
        x = 1;
        y = 0;
    } else {
        ll x0, y0;
        euclid( b, a % b, x0, y0 );
        x = y0;
        y = x0 - ( a / b ) * y0;
    }
}
int main() {
    ifstream fin( "inversmodular.in" );
    ofstream fout( "inversmodular.out" );
    int a, p;
    ll x, y;
    fin >> a >> p;
    euclid( a, p, x, y );
    fout << ( x % p + p ) % p;
    return 0;
}
