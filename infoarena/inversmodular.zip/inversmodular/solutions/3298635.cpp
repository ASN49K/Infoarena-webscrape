#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x = 1;
        y = 1;
    }
    else 
    {
        long long x1, y1;
        euclid(b, a % b, x1, y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}

int main()
{
    long long a, n, x = 0, y = 0;


    fin >> a >> n;

    euclid(a, n, x, y);

    if (x < 0)
    {
        x += n;
    }

    fout << x << '\n';

    return 0;
}