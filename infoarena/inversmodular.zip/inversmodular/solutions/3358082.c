#include <stdio.h>

int main()
{
    FILE *fin = fopen("inversmodular.in", "r");
    FILE *fout = fopen("inversmodular.out", "w");

    long long A, N;
    fscanf(fin, "%lld", &A);
    fscanf(fin, "%lld", &N);

    for (long long i = 2; i < N - 1; i++)
    {
        if ((A * i) % N == 1)
        {
            fprintf(fout, i);
        }
    }

    return 0;
}