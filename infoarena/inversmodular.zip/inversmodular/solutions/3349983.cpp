#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long a, n, m;

long long ExpoFast(long long a, long long p)
{
    if(p == 0)
        return 1;
    if(p % 2 == 0)
    {
        long long rez = ExpoFast(a, p / 2) % m;
        return (rez * rez) % m;
    }
    else
    {
        long long rez = ExpoFast(a, p / 2) % m;
        return ((a * rez) % m * rez) % m;
    }
}

int main()
{
    fin >> a >> n;
    long long f, p = n;
    m = n;
    for(f = 2; f * f <= n; f++)
        if(n % f == 0)
        {
            p *= (f - 1);
            p /= f;
            while(n % f == 0)
                n /= f;
        }
    if(n != 1)
    {
        p *= (n - 1);
        p /= n;
    }
    fout << ExpoFast(a, p - 1) % m << "\n";
    return 0;
}
