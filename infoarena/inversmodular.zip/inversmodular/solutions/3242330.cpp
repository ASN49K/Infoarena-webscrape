#include <fstream>
#include <iostream>

using namespace std;

inline int gcd(int A, int B, int &X, int &Y) {
    if (B == 0) {
        X = 1;
        Y = 0;
        return A;
    }

    int X0, Y0, D;
    D = gcd(B, A % B, X0, Y0);

    X = Y0;
    Y = X0 - (A / B) * Y0;
    return D;
}

int main() {
    ifstream fin("inversmodular.in");
    ofstream fout("inversmodular.out");

        int A, N;
        fin >> A >> N;

   
        int D, X, Y;
        D = gcd(A, N, X, Y);
        if (D != 1) fout<<0;
        if (X <= 0)
        cout << (X % N + N) % N;
        else fout<<X;
       
        
        
       return 0;
}
