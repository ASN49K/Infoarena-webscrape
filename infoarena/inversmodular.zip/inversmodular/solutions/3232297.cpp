#include <iostream>
#include <fstream>
using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");


void euclid_extins(int &x, int &y, int a, int b)
{
    if (!b)
    {
        x = 1;
        y = 0;
    }
    else
    {
        euclid_extins(x, y, b, a % b);
        int aux = x;
        x = y;
        y = aux - y * (a / b);
    }
}
int main(){
    int A,N;
    f>>A>>N;
    int inv, ins;
    euclid_extins(inv, ins, A, N);
    if (inv <= 0)
        inv = N + inv % N;
    g << inv;
}