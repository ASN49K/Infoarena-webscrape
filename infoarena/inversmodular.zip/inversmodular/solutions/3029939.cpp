#include <bits/stdc++.h>
#define nr unsigned long long
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int n;
nr a[1005], x, sum;

nr putere(nr b, nr e, nr v)
{
    nr p = 1;
    while(e != 0)
    {
        if(e % 2 == 1) p = 1LL * p * b % v;
        b = 1LL * b * b %  v;
        e /= 2;
    }
    return p;
}

int main()
{
    int i;
    fin >> n >> x;
    fout << putere(n, x - 2, x);
    fin.close();
    fout.close();
    return 0;
}
