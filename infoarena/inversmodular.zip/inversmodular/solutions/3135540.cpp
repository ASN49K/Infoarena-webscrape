#include <iostream>
#include <fstream>
std::ifstream fin("inversmodular.in");
std::ofstream fout("inversmodular.out");
int main(){
    int A,N;
    fin >> A >> N;
    for(int i = 2; i < N; i++){
        if(A*i%N == 1){
            fout << i;
            return 0;
        }
    }
    return 0;
}