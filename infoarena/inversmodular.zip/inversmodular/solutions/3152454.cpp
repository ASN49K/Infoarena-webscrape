/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <fstream>

using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

int main()
{
    long long a,n;
    cin>>a>>n;
    bool prim = true;
    int x=2;
    if(n%2==0)
    prim=false;
    while(x*x<=n){
        x++;
        if(n%x==0)
        prim=false;
    }
    
    if(prim==true){
       long long p=1,orgn=n,orga=a;
       n-=2;
       while(n){
           if(n%2==1)
           p=(p*a)%orgn;
        a=(a*a)%orgn;
        n/=2;
       }
      cout<<p;
    }
}