#include <bits/stdc++.h>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
int gcd(int a,int b,int &x,int &y)
{
    if(b==0)
    {
        x=1;y=0;
        return a;
    }
    int d,X,Y;
    d=gcd(b,a%b,X,Y);
    x=Y;y=X-a/b*Y;
    return d;
}
int main()
{
    int a,n,x,y,d;
    f>>a>>n;
    d=gcd(a,n,x,y);
    if(x<0)
        x+=n;
    g<<x%n;
    return 0;
}
