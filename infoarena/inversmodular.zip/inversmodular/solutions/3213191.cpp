#include <bits/stdc++.h>

using namespace std;

ifstream in("inversmodular.in");
ofstream out("inversmodular.out");

#define pii pair<int, int>
#define pb push_back
#define fi first
#define se second

const int NMAX = 1e5 + 30;
const int INF = 0x3f3f3f3f;

int a, n, x, y;

void read()
{
    in >> a>>n;
}

void euclid(int a, int b, int &x, int &y)
{
    if (b == 0)
    {
        x = 1, y = 0;
        return;
    }
    int x1, y1;
    // a = b * c + r, unde c = a / b, deci r = a - b * c
    euclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - a / b * y1;
}

void solve()
{
    //cmmdc = 1, a si n prime intre ele
    //a*x+n*y = 1, modulo n devine a*x = 1, deci x este inversul modular determinat prin euclid extins
    euclid(a, n, x, y);
    out<<x;
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);

    read();
    solve();

    return 0;
}