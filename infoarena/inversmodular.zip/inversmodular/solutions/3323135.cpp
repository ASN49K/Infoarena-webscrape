//https://www.infoarena.ro/problema/inversmodular

//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES

#include <iostream>
#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(int a, int b, int64_t& x, int64_t& y)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
	}
	else
	{
		int64_t x0, y0;
		euclid(b, a % b, x0, y0);
		x = y0;
		y = x0 - (a / b) * y0;
	}
}

int invMod2(int x, int m)
{
	int64_t x0, y0;
	euclid(x, m, x0, y0);
	return (x0 % m + m) % m;
}

int invMod1(int64_t x, int m)
{
	int i;
	for (i = 1; i < m; ++i)
	{
		if (x * i % m == 1)
			break;
	}

	return i;
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	int a, n;

	fin >> a >> n;

	fout << invMod2(a, n) << "\n";

	return 0;
}