#include <bits/stdc++.h>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int A, N, xx, yy;
void invers_modular(int a, int b, int &x, int &y)
{
    if (b == 0){
        x = 1;
        y = 0;
    }else{
        int x0, y0;
        invers_modular(b, a%b, x0, y0);
        x = y0;
        y = x0 - (a/b) * y0;
    }
}
int main() {
    fin >> A >> N;
    invers_modular(A, N, xx, yy);
    fout << xx << '\n';
    return 0;
}
