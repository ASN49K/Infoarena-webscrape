#include <bits/stdc++.h>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int Put(int a, int b)
{
  int p = 1;
  while(b)
  {
    if (b % 2)
      p = 1LL * a * p;
    b /= 2;
    a = 1LL * a * a;
  }
  return p;
}

int main()
{
  int a, b;
  fin >> a >> b;
  fout << Put(a, b - 2);
  return 0; 
}