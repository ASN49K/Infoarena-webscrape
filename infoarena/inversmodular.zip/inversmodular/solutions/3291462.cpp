#include<bits/stdc++.h>
using namespace std;
long long a , n , p = 1,mod;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int fact(int n)
{
    if(n == 0)
        return 1;
    else
        return n * fact(n-1);
}

int exp (int x,int n)
{
    while(n)
    {
        if(n % 2 == 1)
        {
            p *= x;
            p %= mod;
        }
        x *= x;
        x %= mod;
        n /= 2;
    }
    return p;
}

int main()
{
    fin >> a >> mod;

    fout << exp(a,mod-2);
}
