#include <stdio.h>

using namespace std;
FILE* f, * g;

void inversmodular(long long a, long long b, long long& x, long long& y)
{
    long long x0, y0;
    if (!b)
        x = 1, y = 0;
    else
    {
        inversmodular(b, a % b, x0, y0);
        x = y0;
        y = x0 - a / b * y0;
    }
}

int main()
{
    long long a, mod, x, y;
    f = fopen("inversmodular.in", "r");
    g = fopen("inversmodular.out", "w");
    fscanf(f, "%lld %lld", &a, &mod);

    inversmodular(a, mod, x, y);
    if (x <= 0)
        x = mod + x % mod;
    fprintf(g, "%lld", x);

    fclose(f);
    fclose(g);
    return 0;
}