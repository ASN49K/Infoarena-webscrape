#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
#define cin fin
#define cout fout

#define N 1005
int a, b, c, t, r;
struct cm
{
    int x,y;
};


int main()
{
        cin >> a >> b;
        int cop = b;
        c = 1;
        cm z, k;
        z.x = 1, z.y = 0;
        k.x = 0, k.y = 1;
        r = a%b;
        cm p;
        p.x = z.x-(a/b)*k.x;
        p.y = z.y-(a/b)*k.y;
        while(r != 0)
        {
            a = b;
            b = r;
            z = k;
            k = p;
            r = a%b;
            p.x = z.x-(a/b)*k.x;
            p.y = z.y-(a/b)*k.y;
        }
        while(k.x <= 0)k.x += cop;
        cout << k.x;
    return 0;
}
