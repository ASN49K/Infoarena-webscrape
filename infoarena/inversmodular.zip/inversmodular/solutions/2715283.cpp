#include <fstream>

using namespace std;

void euclid(int a,int b,long long &x,long long &y)
{
    if(!b)
    {
        x=1;
        y=0;
    }
    else{
        euclid(b,a%b,x,y);
        long long x1=x;
        x=y;
        y=x1-y*(a/b);
    }
}

int main()
{
    ifstream be("inversmodular.in");
    ofstream ki("inversmodular.out");
    long long x=0,y;
    int a,n;
    be>>a>>n;
    euclid(a,n,x,y);
    if(x<=0)
        x=n+x%n;
    ki<<x<<endl;
    return 0;
}
