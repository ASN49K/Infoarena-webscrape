#include <fstream>

using namespace std;

int euler(int n)
{
    ///calculeaza indicatorul lui Euler in n
    int d = 2, fi = n;
    while (d * d <= n)
    {
        if (n % d == 0)
        {
            fi = fi / d * (d - 1);
            while (n % d == 0)
            {
                n /= d;
            }
        }
        d++;
    }
    if (n != 1)
    {
        fi = fi / n * (n - 1);
    }
    return fi;
}

int putere(int a, int n, int mod)
{
    int p = 1;
    while (n != 0)
    {
        int cif_bin = n % 2;///n % 2 == n & 1
        if (cif_bin != 0)
        {
            p = (long long)p * a % mod;
        }
        a = (long long)a * a % mod;
        n /= 2;/// n /= 2 <=> n >>= 1
    }
    return p;
}

int main()
{
    ifstream in("inversmodular.in");
    ofstream out("inversmodular.out");
    int a, m;
    in >> a >> m;
    int e = euler(m);
    out << putere(a, e - 1, m) << "\n";
    in.close();
    out.close();
    return 0;
}
