#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

#define LL long long

LL Phi(LL nr)
{
	LL cur = nr;
	for(LL i = 2;i * i <= nr; ++i)
	{
		if (nr % i == 0)
		{
			while(nr % i == 0)
                nr /= i;
			cur = (cur / i) * (i - 1);
		}
	}
    if (nr != 1)
        cur = cur / nr * (nr - 1);
    return cur;
}

LL MOD;

LL exponentiere(LL nr,LL p)
{
    if(p==0)
        return 1;
    if(p%2==1)
        return ((exponentiere(nr,p-1)%MOD)*p)%MOD;
    return (exponentiere(nr,p/2)%MOD*exponentiere(nr,p/2)%MOD)%MOD;
}

int main()
{
    LL n;
    fin>>n>>MOD;
    LL x;
    x=Phi(n);
    fout<<exponentiere(n,x-1)%MOD;
    return 0;
}
