#include <fstream>
using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int phi(int n) {
    int fi = n;
    if (n % 2 == 0) {
        fi /= 2;
        while (n % 2 == 0) {
            n /= 2;
        }
    }
    for (int d = 3; d * d <= n; d += 2) {
        if (n % d == 0) {
            fi = fi / d * (d - 1);
            while (n % d == 0) {
                n /= d;
            }
        }
    }
    if (n > 1) {
        fi = fi / n * (n - 1);
    }
    return fi;
}

int exponentiere(int a, int b, int mod) {
    if (b == 0) {
        return 1;
    } else if (b % 2) {
        return exponentiere(a * a, b / 2, mod) * a % mod;
    } else {
        return exponentiere(a * a, b / 2, mod) % mod;
    }
}

int invers_modular(int a, int n) {
    int fi = phi(n);
    return exponentiere(a, fi - 1, n);
}

int main() {
    int a, n;
    fin >> a >> n;

    int inv_mod = invers_modular(a, n);

    fout << inv_mod;
    return 0;
}
