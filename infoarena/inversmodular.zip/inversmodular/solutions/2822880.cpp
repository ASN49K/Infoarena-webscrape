#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void Euclid(int a, int b, long long & x, long long & y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
    }
    else
    {
        long long x1, y1;
        Euclid(b, a % b, x1, y1);
        x = y1;
        y = x1 - y1 * (a / b);
    }
}

int main()
{
    int a, n;
    fin >> a >> n;
    long long x, y;
    Euclid(a, n, x, y);
    if(x <= 0)
        x += y;
    fout << x;

    return 0;
}
