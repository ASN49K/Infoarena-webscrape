#include <iostream>
#include <fstream>
using namespace std;
 
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int modInverse(int a, int m)
{
    for (int x = 1; x < m; x++)
        if (((a%m) * (x%m)) % m == 1)
            return x;

    return 0;
}

int main()
{
    int a = 5, m = 7;
    fin >> a >> m;
   
    // Function call
    fout << modInverse(a, m);
    return 0;
}