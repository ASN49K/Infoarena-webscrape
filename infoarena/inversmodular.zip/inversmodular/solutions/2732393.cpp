#include <bits/stdc++.h>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
long long N, M;
int ridic(long long x, long long p, int m)
{
    int rez = 1;
    while(p > 0)
    {
        if(p % 2 == 1)
            rez = ( (rez % m) * (x % m) ) % m;
        x = ( (x % m) * (x % m) ) % m;
        p /= 2;
    }
    return rez;
}
void citire()
{
    fin>>N>>M;
    fout<<ridic(N, M - 2, M);
}
int main()
{
    citire();
    return 0;
}
