#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
  
long inversmodulo(long A,long N){
    long X=0;
    for(int i=1;i<N;i++){
        if(i*A%N==1) return i; 
    }
    return X;
}
int main()
{   
    long A,N;
    fin>>A>>N;
    fout<<inversmodulo(A,N);
    return 0;
}
