#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int log_pow(int x, int p, int mod)
{
    int rez = 1;
    while(p != 0)
    {
        if(p % 2 == 1)
        {
            rez = rez * x % mod;
        }

        x = x * x % mod;
        p /= 2;
    }
    return rez;
}

int main()
{
    int x, n;
    fin >> x >> n;
    fout << log_pow(x, n - 2, n);
    return 0;
}
