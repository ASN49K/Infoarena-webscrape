#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int main()
{
    int a,n,c,x=1,y;
    fin>>a>>n;
    y=n;
    c=n+1;
    while(c%a!=0)
    {
        x++;
        c+=y;
    }
    fout<<x+1;
    return 0;
}
