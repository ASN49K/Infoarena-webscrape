#include <iostream>

using namespace std;

void invMod(int a, int b, int & x, int & y) {
    if(b == 0) {
        x = y = 1;
    } 
    else {
        int x1, y1;
        invMod(b, a % b, x1, y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}

int main() {
    int a, n;
    cin >> a >> n;

    int X, Y;
    invMod(a, n, X, Y);

    while(X < 0) {
        X += n;
    }

    cout << X;
}