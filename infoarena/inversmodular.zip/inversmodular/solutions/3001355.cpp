#include <bits/stdc++.h>

using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
long long a,n;
void euclid_ext(int a,int b,int &x,int &y)
{
   if(b==0)
   {
       x=1,y=1;
   }
   else{
    int x1,y1;
    euclid_ext(b,a%b,x1,y1);
    x=y1;
    y=x1-a/b*y1;
   }
}
int main()
{
    f>>a>>n;
    int x,y;
    euclid_ext(a,n,x,y);
    while(x<0)
        x+=n;
    g<<x;
    return 0;
}
