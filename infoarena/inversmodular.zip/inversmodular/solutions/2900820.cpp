#include <bits/stdc++.h>

using namespace std;
class instream
{
public:
    instream () {}
    instream (const char *s)
    {
        input_file=fopen(s,"r");
        cursor=0;
        fread(buffer,SIZE,1,input_file);
    }
    inline instream &operator>> (int &n)
    {
        int semn=1;
        while ((buffer[cursor]>'9' || buffer[cursor]<'0') && buffer[cursor]!='-')
            advance();
        n=0;
        if (buffer[cursor]=='-') semn=-1;
        while (buffer[cursor]>='0' && buffer[cursor]<='9')
        {
            n=n*10+buffer[cursor]-'0';
            advance();
        }
        n*=semn;
        return *this;
    }
private:
    FILE *input_file;
    static const int SIZE=1<<16;
    char buffer[SIZE];
    int cursor;
    inline void advance()
    {
        ++cursor;
        if (cursor==SIZE)
        {
            cursor=0;
            fread(buffer,SIZE,1,input_file);
        }
    }
};
int euclid (int a,int b,int &x,int &y)
{
    if (b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int x0,y0;
    int cmmdc=euclid(b,a%b,x0,y0);
    x=y0;
    y=x0-a/b*y0;
}
int c,n,a,b,x,y,v[1000],vf[1000];
int main()
{
    instream f ("inversmodular.in");
    ofstream g ("inversmodular.out");
    f>>a>>b;
    int x,y;
    int d=euclid(a,b,x,y);
    x+=b;
    x%=b;
    g<<x;
}
