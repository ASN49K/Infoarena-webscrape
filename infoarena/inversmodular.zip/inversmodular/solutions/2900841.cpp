#include <bits/stdc++.h>
#define int long long
using namespace std;

#ifndef DLOCAL
  #define cin fin
  #define cout fout
  ifstream cin("inversmodular.in");
  ofstream cout("inversmodular.out");
#endif

void gcd(int a, int b, int& x, int& y, int& d) {
  if(b == 0) {
    x = 1, y = 0, d = a;
    return; 
  }
  int x0, y0;
  gcd(b, a % b, x0, y0, d);
  x = y0;
  y = -(a / b * y0 - x0);
  // cerr << a << ' ' << b << ' ' << x << ' ' << y << ' ' << d << '\n';
}

// b * x0 + (a - a / b * b) * y0 = a * x + b * y;


signed main() {
  int A, N;
  cin >> A >> N;
  int x, y, d;
  gcd(A, N, x, y, d);
  cout << x << '\n';
}
