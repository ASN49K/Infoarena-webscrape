#include <bits/stdc++.h>
using namespace std;

int MOD;

int lgput(int a, int b){
    int put = 1;
    while(b){
        if(b % 2 == 1){
            put *= a;
            put %= MOD;
        }
        a *= a;
        b /= 2;
        a %= MOD;
    }
    return put;
}

int inv(int a){
    return (lgput(a,MOD - 2));
}

int main(void){
    ofstream cout("inversmodular.out");
    ifstream cin("inversmodular.in");
    int n;
    cin >> n >> MOD;
    cout << inv(n);
}
