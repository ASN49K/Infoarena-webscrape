#include <fstream>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
void inv(int a,int b,int &x,int &y){
    if(b==0){
        x=y=1;
    }
    else{
        int x1,y1;
        inv(b,a%b,x1,y1);
        x=y1;
        y=x1-a/b*y1;
    }
}
int main()
{
    int a,n,ans,ans1;
    fin>>a>>n;
    inv(a,n,ans,ans1);
    while(ans<0)
    ans+=n;
    fout<<ans;
}