#include <fstream>

using namespace std;
#define int long long
int n,mod;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
int ridicare(int x,int put){
    if(put==0)
        return 1;
    if(put%2==0){
        return ridicare(x,put/2)*ridicare(x,put/2)%mod;
    }
    else{
        return ridicare(x,put/2)*ridicare(x,put/2)%mod*x%mod;
    }
}
int32_t main()
{
   fin>>n>>mod;
   fout<<ridicare(n,mod-2);
    return 0;
}
