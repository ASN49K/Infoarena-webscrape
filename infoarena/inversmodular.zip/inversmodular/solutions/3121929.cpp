#include<fstream>
using namespace std;
ifstream F("inversmodular.in");
ofstream G("inversmodular.out");
int a,b,x=1,y,z,d,c,e;
int main()
{
    for(F>>a>>b,c=b;b;d=a%b,e=a/b,a=b,b=d,z=x,x=y,y=z-e*y);
    return G<<(x<0?c+x%c:x),0;
}
