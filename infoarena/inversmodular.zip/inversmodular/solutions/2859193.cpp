#include <bits/stdc++.h>
#define lli long long int

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void gcd(lli &x, lli &y, int a, int b) {
    if(!b) {
        x = 1;
        y = 0;
    } else {
        gcd(x, y, b, a % b);
        lli aux = x;
        x = y;
        y = aux - y * (a / b);
    }
}
 
int a, n;
lli inv, ins;
 
int main() {
    fin >> a >> n;
    fin.close();
    gcd(inv, ins, a, n);
    if(inv <= 0) {
        inv = n + inv % n;
    }
    fout << inv;
    return 0;
}