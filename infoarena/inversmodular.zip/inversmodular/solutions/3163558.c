#include <stdio.h>

#define MAXN 10000
#define MAXNUMERE 1000000
#define MAXBOMBOANE 447

int v[MAXN+1], bomboane[MAXBOMBOANE+1];

int main()
{
    FILE *fin, *fout;
    int cer, n, min, index, cmmdc, nr, rest, index2, index3;
    fin=fopen("bomboane.in", "r");
    fscanf(fin, "%d%d", &cer, &n);
    min=MAXNUMERE;
    for(index=0;index<n;index++){
      fscanf(fin, "%d", &v[index]);
      if(v[index]<min){
        min=v[index];
      }
    }
    fclose(fin);
    fout=fopen("bomboane.out", "w");
    if(cer==1){
      index=0;
      while(index<n&&v[index]-min==0){
        index++;
      }
      if(index<n){
        cmmdc=v[index]-min;
        while(index<n){
          if(v[index]-min){
            nr=v[index]-min;
            while(nr>0){
              rest=cmmdc%nr;
              cmmdc=nr;
              nr=rest;
            }
          }
          index++;
        }
        fprintf(fout, "%d", cmmdc);
      }
      else{
        fprintf(fout, "%d", min);
      }
    }
    else{
        for(index=0;index<n;index++){
            nr=1;
            index2=0;
            while(nr<=v[index]){
                bomboane[index2]=nr;
                index2++;
                v[index]-=nr;
                nr++;
            }
            bomboane[index2-1]+=v[index];
            fprintf(fout, "%d ", index2);
            for(index3=0;index3<index2-index3-1;index3++){
                fprintf(fout, "%d %d ", bomboane[index3], bomboane[index2-index3-1]);
            }
            if(index3==index2-index3-1){
                fprintf(fout, "%d", bomboane[index3]);
            }
            fputc('\n', fout);
        }
    }
    fclose(fout);
    return 0;
}
