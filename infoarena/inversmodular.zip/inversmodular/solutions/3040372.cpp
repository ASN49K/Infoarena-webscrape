#include <fstream>

using namespace std;

ifstream in ("inversmodular.in");
ofstream out ("inversmodular.out");

long long mod;

void inv (long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x = 1;
        y = 1;
    }
    else
    {
        long long x1, y1;
        inv(b, a % b, x1, y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}


signed main ()
{
    long long x;
    in >> x >> mod;
    long long auxx, auxy;
    inv(x, mod, auxx, auxy);
    if (auxx < 0)
    {
        auxx += mod;
    }
    out << auxx;
    in.close();
    out.close();
    return 0;
}
