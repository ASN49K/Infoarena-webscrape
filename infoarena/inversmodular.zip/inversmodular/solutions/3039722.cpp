#include <bits/stdc++.h>

using namespace std;

int euclid (int a, int b, int& x, int& y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
    }
    else
    {
        int x0, y0;
        euclid(b, a%b, x0, y0);
        x = y0;
        y = x0 - (a/b)*y0;
    }
}

int main()
{
    ifstream fin ("inversmodular.in");
    ofstream fout ("inversmodular.out");
    int a, n;
    fin >> a >> n;
    int x, y;
    euclid(a, n, x, y);
    fout<<x;

    return 0;
}
