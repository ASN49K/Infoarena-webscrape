#include <fstream>

using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int Euclid_E(int a, int b, int& x, int& y);
int n, a, b, c, d, x, y;
int main()
{
    int i;
    fin>>a>>n;
    d=Euclid_E(a, n, x, y);
    while(x<0)
         x+=n;
    fout<<x;
    return 0;
}
int Euclid_E(int a, int b, int& x, int& y)
{
    int x1, y1;
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    int d=Euclid_E(b, a%b, x1, y1);
    x=y1;
    y=x1-y1*(a/b);
    return d;
}
