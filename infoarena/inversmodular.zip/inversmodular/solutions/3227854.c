#include <stdio.h>
#include <stdlib.h>

#define in "inversmodular.in"
#define out "inversmodular.out"

void euclid_extins(int a, int b, int *x, int *y)
{
    if (b == 0)
    {
        *x = 1;
        *y = 1;
    }
    else
    {
        int x1, y1;
        euclid_extins(b, a % b, &x1, &y1);
        *x = y1;
        *y = x1 - a / b * y1;
    }
}

int main()
{
    FILE *fin, *fout;
    fin = fopen(in, "r");
    fout = fopen(out, "w");
    int x, y, a, b;
    fscanf(fin, "%d %d", &a, &b);
    euclid_extins(a, b, &x, &y);
    if(x <= 0)
    {
        x = b + x % b;
    }
    fprintf(fout, "%d\n", x);
    fclose(fin);
    fclose(fout);
    return 0;
}