//#include <iostream>
#include <fstream>
using namespace std;

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

int main()
{

    int a, x, n;
    cin>>a>>n;

    for(int i=1; i<=n; i++)
    {
        if((n*i+1)%a==0)
        {
            x = (n*i+1)/a;
            break;
        }
    }

    cout<<x;

    return 0;
}

