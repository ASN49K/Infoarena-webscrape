#include <fstream>

using namespace std;

ifstream fin ("inversmodular.in");
ofstream fout ("inversmodular.out");

int a,n,x,y,b;

void euclid (int a, int n, int &x, int &y);

int main()
{
    fin>>a>>b;
    euclid(a,b,x,y);
    while (x<0)
    {
        x+=b;
    }
    fout<<x;
    return 0;
}

void euclid (int a, int n, int &x, int &y)
{
    if (n==0)
    {
        x=y=1;
    }
    else
    {
        int x1,y1;
        euclid(n,a%n,x1,y1);
        x=y1;
        y=x1-a/n*y1;
    }
}
