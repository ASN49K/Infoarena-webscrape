#include<fstream>

std::ifstream fin("inversmodular.in");
std::ofstream fout("inversmodular.out");

int A, N;

void MODINVERSE(int a, int b, int& x, int& y){
    if(!b){
        x = y = 1;
    }
    else{
        int x1, y1;
        MODINVERSE(b, a % b, x1, y1);
        x = y1;
        y = x1 - a / b * y1;
    }
}

int main(){
    fin >> A >> N;
    int x, y;
    MODINVERSE(A, N, x, y);
    while(x < 0)
        x += N;
    fout << x;
}