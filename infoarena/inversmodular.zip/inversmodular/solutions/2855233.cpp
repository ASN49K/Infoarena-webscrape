#include <iostream>

using namespace std;

long long putere(int a, int b, int n)
{
    long long aa = 1, ans = 1;

    while(b)
    {
        if(b & 1LL)// exp impar deci inmultim rezultatul cu baza
        {
            ans *= a;
            ans %= n;
        }
        a = 1LL * a * a % n;
        b >>= 1LL;
    }

    return ans;
}
int main()
{
    int a, n;
    cin >> a >> n;
    cout <<putere(a, n-2, n);

    return 0;
}
