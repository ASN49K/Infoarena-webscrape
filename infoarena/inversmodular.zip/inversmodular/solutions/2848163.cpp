#include <fstream>
#define ll long long int
using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
void euclid(ll a,ll b,ll &d,ll &x,ll &y)
{
    if(!b)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        ll x0,y0;
        euclid(b,a%b,d,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
    }
}
ll a,n;
int main()
{
    f>>a>>n;
    ll d,x,y;
    euclid(a,n,d,x,y);
    while(x<0) x+=n;
    g<<x;
    return 0;
}
