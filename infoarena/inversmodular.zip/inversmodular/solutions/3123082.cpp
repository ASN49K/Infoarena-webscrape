#include <bits/stdc++.h>

using namespace std;

ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
int phi(int n)
{
    int r=n;
    if(n%2==0)
    {
        r/=2;
        while(n%2==0)n/=2;
    }
    for(int d=3; d*d<=n; d+=2)
        if(n%d==0)
        {
            r=r/d*(d-1);
            while(n%d==0)n/=d;
        }
    if(n>1)
        r=r/n*(n-1);
    return r;
}
int putere(int b,int e,int mod)
{
    if(e==0)return 1;
    int r=putere(b,e/2,mod);
    r=1LL*r*r%mod;
    if(e%2)r=1LL*r*b%mod;
    return r;
}
int invMod(int a,int n)
{

    return putere(a,n-2,n);
}
int main()
{
    int a,n;
    f>>a>>n;
    g<<invMod(a,n);
    return 0;
}




