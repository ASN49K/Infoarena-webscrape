#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");
int phi(int n)
{
    int ret=1;
    if(n%2==0)
    {
        n/=2;
        while(n%2==0)
        {
            ret*=2;
            n/=2;
        }
    }
    for(int d=3; d*d<=n; d+=2)
        if(n%d==1)
        {
            n/=d;
            ret*=d-1;
            while(n%d==0)
            {
                n/=d;
                ret*=d;
            }
        }
    if(n>1)
        ret*=n-1;
    return ret;
}
int putere(int b,int e,int mod)
{
    if(e==0)
        return 1;
    int r=putere(b,e/2,mod);
    r=1LL*r*r%mod;
    if(e%2==1)
        r=1LL*r*b%mod;
    return r;
}
int main()
{
    int64_t A,N;
    f>>A>>N;
    g<<putere(A,phi(N)-1,N);
    return 0;
}

