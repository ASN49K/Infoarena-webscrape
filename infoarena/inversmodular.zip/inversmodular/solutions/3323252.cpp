#include <bits/stdc++.h>

using namespace std;

void euclid( int a, int b, int &d, int &x, int &y ) {
  if ( b == 0 ) {
    d = a;
    x = 1;
    y = 0;
  } else {
    int x0, y0;
    euclid( b, a % b, d, x0, y0 );
    x = y0;
    y = x0 - (a / b) * y0;
  }
}

int invMod( int a, int n ) {
  int d, x, y;
  euclid( a, n, d, x, y );
  return (x % n + n) % n;
}

int main() {
  FILE *fin, *fout;
  int a, n;

  fin = fopen( "inversmodular.in", "r" );
  fscanf( fin, "%d%d", &a, &n );
  fclose( fin );

  fout = fopen( "inversmodular.out", "w" );
  fprintf( fout, "%d\n", invMod( a, n ) );
  fclose( fout );

  return 0;
}
