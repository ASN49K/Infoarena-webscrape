#include <iostream>
#include <fstream>//Nu functioneaza serverul/nu stiu sa folosesc Infoarena

using namespace std;

long long a,n;

long long pow(long long x,long long exp){
    if(exp==0)return 1;
    if(exp==1)return x;
    long long y=pow(x,exp/2);
    y=y*y%n;
    if(exp&1)y=y*x%n;
    return y;
}

int main()
{
    ifstream fin("inversmodular.in");
    fin>>a>>n;
    fin.close();
    ofstream fout("inversmodular.out");
    fout<<pow(a,n-2);
    fout.close();
    return 0;
}
