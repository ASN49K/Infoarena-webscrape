#include <iostream>
#include <fstream>
using namespace std;
ifstream f("inversmodular.in");
ofstream g("inversmodular.out");

void EuclidExtins(int a, int b, int &d, int &x, int &y) ///Varianta recursiva
{
    if(b == 0)
    {
        x = 1, y = 0, d = a;
    }
    else
    {
        int x0, y0;
        EuclidExtins(b, a % b, d, x0, y0);
        x = y0;
        y = x0 - (a / b) * y0;
    }
}

int main()
{
    int a, b, d, x, y;
    f >> a >> b;
    EuclidExtins(a, b, d, x, y);
    g << x;
    return 0;
}

/**
 1) În scrierea a∙x + b∙y = d, x și y nu sunt neapărat unice.
    Pentru a verifica și obtine diferite valori, în funcția
    EuclidExtins, la cazul b == 0, putem atribui orice valoare lui y.
*/
