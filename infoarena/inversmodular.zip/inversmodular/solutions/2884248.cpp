#include <fstream>
using namespace std;

// A naive method to find modular
// multiplicative inverse of 'a'
// under modulo 'm'
int modInverse(int a, int m)
{
    for (int x = 1; x < m; x++)
        if (((a % m) * (x % m)) % m == 1)
            return x;
}

int main()
{
    ifstream cin("inversmodular.in");
    ofstream cout("inversmodular.out");
    int a, m;
    cin >> a >> m;
    cout << modInverse(a, m);
    return 0;
}