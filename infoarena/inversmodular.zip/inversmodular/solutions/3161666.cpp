#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
long long a,b,c;
long long x,y,d;
long long euclidext(long long a,long long b,long long &x,long long &y)
{
    if(b==0)
    {
        x=1;
        y=0;
        return a;
    }
    else
    {
        long long x0,y0,d;
        d=euclidext(b,a%b,x0,y0);
        x=y0;
        y=x0-(a/b)*y0;
        return d;
    }
}
int main()
{
        fin>>a>>b;
        d=euclidext(a,b,x,y);
        while(x<0)
            x=x+b;
        fout<<x;
}
