#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
void euclid(long long int a,long long int b,long long int &x,long long int &y)
{
    if(b==0)
    {
        x=1;
        y=0;
    }
    else
    {
        long long int x1,y1;
        euclid(b,a%b,x1,y1);
        x=y1;
        y=x1- (a/b) *y1;
    }
}
int main()
{
   long long int t,a,b,c,d=1,x=0,y;
 cin>>a>>b;
 euclid(a,b,x,y);
 while(x<0)
    x+=b;
 cout<<x;
    return 0;
}
