#include <fstream>
#define int long long
using namespace std;

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

int exp(int x, int y)
{
    if(y==0)
        return 1;
    if(y%2==0)
    {
        return exp(x*x, y/2);
    }
    else
        return x*exp(x*x, y/2);
}

int main()
{
    int a, b;
    cin>>a>>b;
    a=exp(a, b-2);
    cout<<a;

    return 0;
}
