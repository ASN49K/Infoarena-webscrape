#include <bits/stdc++.h>
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

#define ll long long

int A, N;

void gcd(ll &x, ll &y, int a, int b)
{
     if (!b)
         x = 1, y = 0;
     else
     {
         gcd(x, y, b, a % b);
         ll aux = x;
         x = y;
         y = aux - y * (a / b);
     }
}

int main()
{
    ll inv = 0, ins;
    fin>>A>>N;
    gcd(inv, ins, A, N);
    if (inv <= 0)
       inv = N + inv % N;
    fout<<inv;
    return 0;
}
