#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int a, n;

int totinet(int n)
{
    int prod = 1;
    for(int i=2; i*i<=n; i++)
    {
        if(n%i==0)
        {
            prod*=(i-1);
            n/=i;
            while(n%i==0)
                prod*=i, n/=i;
        }
    }
    if(n>1)
        prod*=(n-1);
    return prod;
}

int putere(int a, int b)
{
    if(b==0)
        return 1;
    if(b%2==1)
        return a*putere(a,b-1);
    int aux = putere(a,b/2);
    return aux*aux;
}

int main()
{
    fin >> a >> n;
    int phi = totinet(n);
    fout << putere(a,phi-1);
    return 0;
}
