#include <bits/stdc++.h>

using namespace std;

// ax + by = d

void euclid(int64_t a, int64_t b, int64_t* d, int64_t* x, int64_t* y) {
  if (!b) {
    *d = a;
    *x = 1;
    *y = 0;
  } else {
    int64_t x0;
    int64_t y0;
    euclid(b, a % b, d, &x0, &y0);
    *x = y0;
    *y = x0 - (a / b) * y0;
  }
}

int main() {
#ifndef LOCAL
  freopen("inversmodular.in", "r", stdin);
  freopen("inversmodular.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int A;
  int N;
  cin >> A >> N;
  int64_t X;
  int64_t Y;
  int64_t D;
  euclid(A, N, &D, &X, &Y);
  assert(D == 1);
  X %= N;
  if (X < 0) {
    X += N;
  }
  cout << X << endl;
  return 0;
}
