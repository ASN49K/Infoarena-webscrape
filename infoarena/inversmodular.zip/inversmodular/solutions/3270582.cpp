#include <iostream>
#include <fstream>

using namespace std;

void EuclidExtins(int a, int b, int &d, int &x, int &y)
{
    if(b == 0)
    {
        x = 1;
        y = 0;
        d = a;
    }
    else
    {
        int x0, y0;
        EuclidExtins(b, a%b, d, x0, y0);
        x = y0;
        y = x0-(a/b)*y0;
    }
}

int inversMOD(int a, int n)
{
    int d, x, y;
    EuclidExtins(a, n, d, x, y);

    while(x < 0)
        x += n;
    return x;
}

int main()
{
    int a, n;

    ifstream fin("euclid3.in");
    ofstream fout("euclid3.out");

    fin >> a >> n;

    fout << inversMOD(a, n);

    return 0;
}
