//https://www.infoarena.ro/problema/inversmodular

//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES

#include <iostream>
#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

int invMod1(int64_t x, int m)
{
	int i;
	for (i = 1; i < m; ++i)
	{
		if (x * i % m == 1)
			break;
	}

	return i;
}

void euclid(int a, int b, int64_t& x, int64_t& y)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
	}
	else
	{
		int64_t x0, y0;
		euclid(b, a % b, x0, y0);
		x = y0;
		y = x0 - (a / b) * y0;
	}
}

int invMod2(int x, int m)
{
	int64_t x0, y0;
	euclid(x, m, x0, y0);
	return (x0 % m + m) % m;
}

int64_t power_of_manyyy(int64_t b, int64_t e, int64_t modulo)
{
	int64_t rez = 1;

	while (e > 0)
	{
		if (e & 1)
			rez = rez * b % modulo;

		b = b * b % modulo;
		e >>= 1;
	}

	return rez;
}

int invMod3(int x, int m)
{
	return power_of_manyyy(x, m - 2, m);
}

int64_t indEuler(int m)
{
	int rez = m, d;

	for (d = 2; d * d <= m; ++d)
	{
		if (m % d == 0)
		{
			rez = rez / d * (d - 1);

			while (m % d == 0)
				m /= d;
		}
	}

	if (m > 1)
		rez = rez / m * (m - 1);

	return rez;
}

int invMod4(int x, int m)
{
	int64_t d = indEuler(m);
	return power_of_manyyy(x, d - 1, m);
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	int a, n;

	fin >> a >> n;

	fout << invMod4(a, n) << "\n";

	return 0;
}