#include <iostream>
#include <fstream>
using namespace std;
ifstream in("inversmodular.in");
ofstream out("inversmodular.out");
int a,n;
int invers()
{
    int val=1,aux=a;
    for(int i=1;i<=n-2;i<<=1)
    {
        if((n-2)&i)
        {
            val=(1LL*val*aux)%n;
        }
        aux=(1LL*aux*aux)%n;
    }
    return val;
}
int main()
{
    in>>a>>n;
    out<<invers();
    return 0;
}
