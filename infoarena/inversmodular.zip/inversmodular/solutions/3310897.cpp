#include <bits/stdc++.h>
using namespace std;

#define int long long

int phi(int n)
{
    int r = n, d = 2;
    while(n > 1) {
        if(n % d == 0) {
            r = r / d * (d - 1);
            while(n % d == 0)
                n /= d;
        }
        ++d;
        if(d * d > n)
            d = n;
    }
    return r;
}

int lgput(int a, int n, int MOD)
{
    int rez = 1;
    a %= MOD;
    for(;n;n>>=1) {
        if(n & 1)
            rez = rez * a % MOD;
        a = a * a % MOD;
    }
    return rez;
}

signed main()
{
#ifndef LOCAL
    ifstream cin("inversmodular.in");
    ofstream cout("inversmodular.out");
#endif

    int a, n;
    cin >> a >> n;
    cout << lgput(a, phi(n) - 1, n);

    return 0;
}