#include<fstream>
using namespace std;
ifstream F("inversmodular.in");
ofstream G("inversmodular.out");
int a,b,x,y,z=1,r,c,d;
int main()
{
    for(F>>a>>b,d=b;a;r=b%a,c=b/a,b=a,a=r,x=y-c*z,y=z,z=x);
    for(;y<0;y+=d);
    G<<y;
    return 0;
}

