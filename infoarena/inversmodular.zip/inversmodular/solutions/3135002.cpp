#include <bits/stdc++.h>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

long long A, N;

long long phi(int x)
{
    long long res = x * 1LL;
    for (int i = 2; i * i <= x; ++i)
    {
        if (x % i == 0)
        {
            while (x % i == 0)
                x = x / i;
            res *= (i - 1);
            res /= i;
        }
    }
    if (x > 1)
    {
        res *= (x - 1);
        res /= x;
    }
    return res;
}

long long inversmodular(long long n, long long p)
{
    if (p == 0)
        return 1;
    long long x = inversmodular(n, p / 2);
    if (p % 2 == 0)
        return x * x % N;
    else
    return (n * x % N * x) % N;
}

int main()
{
    fin >> A >> N;
    fout << inversmodular(A, phi(N) - 1);
    return 0;
}