#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");


void euclid_extins(int a,int b,int *d, int *x, int *y)
{
    if(b==0)
    {
        *d=a;
        *x=1;
        *y=0;
    }
    else
    {
        int x0,y0;
        euclid_extins(b,a%b,d,&x0,&y0);
        *x=y0;
        *y=x0-(a/b)*y0;
    }
}
int d,x,y,a,b;

int main()
{
    fin>>a>>b;

    euclid_extins(a,b,&d,&x,&y);
    fout<<x%b;
    return 0;
}