#include <fstream>
#define ll long long
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(ll a,ll b,ll&x,ll&y)
{
    if(b==0)
    {
        x=1;
        y=0;
        //d=a;
        return;
    }
    ll x1,y1;
    euclid(b,a%b,x1,y1);
    x=y1;
    y=x1-(a/b)*y1;
}



int main()
{
    ll a,n,x,y;
    fin>>a>>n;
    euclid(a,n,x,y);
    while(x<0)
        x+=n;
    fout<<x;
    return 0;
}
