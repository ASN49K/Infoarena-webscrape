#include <fstream>

using namespace std;

#define ll long long

ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");

ll euclid(ll a, ll b, ll &x, ll &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    ll x0, y0;
    ll d = euclid(b, a % b, x0, y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}

int main() {
    cin.tie(0);
    cin.sync_with_stdio(false);

    ll a, b;
    cin >> a >> b;
    ll inva, invb;
    euclid(a, b, inva, invb);
    cout << inva;
    return 0;
}
