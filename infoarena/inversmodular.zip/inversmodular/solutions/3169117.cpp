#include <iostream>
#include <fstream>

using namespace std;

#define cin fin
#define cout fout

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void euclid(long long a, long long b, long long& x, long long& y, int MOD = -1);

int main()
{
    long long a, n, x, y;

    cin >> a >> n;

    euclid(a, n, x, y);

    if(x < 0)
        x += n;
        
    cout << x;

    return 0;
}

void euclid(long long a, long long b, long long& x, long long& y, int MOD)
{
    if(MOD == -1)
    {
        MOD = b;
    }

    if(b == 0)
    {
        y = 0;
        x = 1;
    }
    else
    {
        long long x1, y1;

        euclid(b, a % b, x1, y1, MOD);

        x = y1 % MOD;
        y = (x1 - a / b * y1) % MOD;
    }
}