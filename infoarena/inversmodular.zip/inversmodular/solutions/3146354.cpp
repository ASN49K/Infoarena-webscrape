#include <fstream>
#include <vector>
#include <algorithm>
#define pb push_back
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
using pii = pair<int,int>;
const int MAX = 1e6+1;
int a , n;
void fastread();
pii modular_inverse( int a , int b)
{
    if(b==0)
    {
        return{1,1};
    }
    else
    {
        pii aux = modular_inverse(b,a%b);
        int x = aux.second;
        int y = aux.first-a/b*aux.second;
        return{x,y};
    }
}
signed main(){
    fastread();
    cin >> a >> n;
    int val = modular_inverse(a,n).first;
    while(val<0) val+=n;
    cout << val;
    return 0;
}
void fastread()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}
