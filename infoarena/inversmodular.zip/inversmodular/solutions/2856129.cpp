#include <bits/stdc++.h>

using namespace std;

using ll = long long;
const int INF=1e9+7;
const ll INFF=1e18+7;
#define nl '\n'
void __print(int x) { cout << x; }
void __print(long x) { cout << x; }
void __print(long long x) { cout << x; }
void __print(unsigned x) { cout << x; }
void __print(unsigned long x) { cout << x; }
void __print(unsigned long long x) { cout << x; }
void __print(float x) { cout << x; }
void __print(double x) { cout << x; }
void __print(long double x) { cout << x; }
void __print(char x) { cout << '\'' << x << '\''; }
void __print(const char* x) { cout << '\"' << x << '\"'; }
void __print(const string& x) { cout << '\"' << x << '\"'; }
void __print(bool x) { cout << (x ? "true" : "false"); }
template<typename T, typename V>
void __print(const pair<T, V>& x) { cout << '{'; __print(x.first); cout << ','; __print(x.second); cout << '}'; }
template<typename T>
void __print(const T& x) { int f = 0; cout << '{'; for (auto& i : x) cout << (f++ ? "," : ""), __print(i); cout << "}"; }
void _print() { cout << "]\n"; }
template <typename T, typename... V>
void _print(T t, V... v) { __print(t); if (sizeof...(v)) cout << ", "; _print(v...); }
#ifndef ONLINE_JUDGE
#define debug(x...) cout << "[" << #x << "] = ["; _print(x)
#else
#define debug(x...)
#endif

ll a,n;
ll power(ll x, ll k){
    if(k==0) return 1;
    ll p=power(x,k/2);
    if(k&1) return (((p*p)%n)*x)%n;
    else return (p*p)%n;
}

void solve()
{
    cin>>a>>n;
    cout<<power(a,n-2);
}

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    freopen("inversmodular.in", "r", stdin);
    freopen("inversmodular.out", "w", stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    // int t;
    // cin >> t;
    for(int tt=1; tt<=t; tt++){
        // cout<<"#Case "<<t<<nl;
        solve();
    }
    return 0;
}