#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define inl long long
using namespace std;

inl Power(inl a,inl b,inl m){
  inl r;
  r=1;
  while(b>0){
    if(b%2==1){
      r*=a;
      r%=m;
      b--;
    }
    a*=a;
    a%=m;
  }
  return r;
}

int main(){
  inl a,n;
  FILE *fin,*fout;
  fin=fopen("inversmodular.in","r");
  fout=fopen("inversmodular.out","w");
  fscanf(fin,"%lld%lld",&a,&n);

  fprintf(fout,"%lld",Power(a,a,n));

  fclose(fin);
  fclose(fout);
  return 0;
}
