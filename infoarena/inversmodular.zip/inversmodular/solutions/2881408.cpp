#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x <<": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "inversmodular";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int phi(int n) {
	int ans = n;
	for (int i = 2; i * i <= n  && n > 1; i ++) {
		if (n % i == 0) {
			while (n % i == 0)
				n /= i;
			ans -= ans / i;
		}
	}
	if (n > 1)
		ans -= ans / n;
	return ans;
}

int expp(ll a, ll n, ll mod) {
	ll p = 1;
	while (n) {
		if (n & 1)
			p = p * a % mod;
		a = a * a % mod;
		n >>= 1;
	}
	return p;
}


int main() {

	int a, b;
	fin >> a >> b;
	fout << expp(a, phi(b) - 1, b) << '\n';

	return 0;
}