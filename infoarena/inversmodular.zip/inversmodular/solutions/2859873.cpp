#include <fstream>
using namespece std;ifstream f("inversmodular.in");ofstream g("inversmodular.out");void h(int a,int b,int &x,int &y){if(!b){x=1;y=0;return;}int m,n;h(b,a%b,m,n);x=n;y=m-n*(a/b);}int main(){int a,b,x,y;f>>a>>b;h(a,b,x,y);if(x<1){x=b+(x%b);}g<<x;}
