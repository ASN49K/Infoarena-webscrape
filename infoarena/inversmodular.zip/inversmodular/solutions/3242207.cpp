#include <bits/stdc++.h>
#include <fstream>
using namespace std;
#define ll long long

int euclidian(int a, int b, int &x, int &y) {
    if (b == 0) {
 		x = 1;
 		y = 0;
 		return a;
	}
    else {
		int x0, y0, d;
		d = euclidian(b, a%b, x0, y0);
		x = y0;
		y = x0 - (a / b) * y0;
		return d;
	}
}

ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");

void solve() {
    int a, m;
    fin >> a >> m;
    int x, y;
    int g = euclidian(a, m, x, y);
    x = (x % m + m) % m;
    fout << x << endl;
}

int main() {
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
}
