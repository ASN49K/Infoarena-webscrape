#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("inversmodular.in");
ofstream cout ("inversmodular.out");
long long int a,b;
long long int putere(long long int a,long long int n)
{
    long long int sol=1;
    while(n)
    {
        if(n%2==1)
        {
            sol=sol*a%b;
        }
        a=a*a%b;
        n=n/2;
    }
    return sol;
}
int main()
{
    cin>>a>>b;
    cout<<putere(a,b-2);
    return 0;
}
