#include <bits/stdc++.h>
#define ll long long int
#define ld long double
#define NMAX 1009
using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
ll fact[NMAX];
ll i;
ll powmod(ll a, ll b, ll p) {
    a %= p;
    if (a == 0LL) return 0LL;
    ll product = 1LL;
    while (b > 0LL) {
        if (b & 1LL) {    // you can also use b % 2 == 1
            product *= a;
            product %= p;
            --b;
        }
        a *= a;
        a %= p;
        b /= 2LL;    // you can also use b >> 1
    }
    return product;
}
ll inv(ll a, ll p) {
    return powmod(a, p - 2LL, p);
}
ll nCk(ll n, ll k, ll p) {

    return ((fact[n] * inv(fact[k], p) % p) * inv(fact[n - k], p)) % p;
}
void pre(ll p)
{
    ll i;
    fact[0] = 1LL;
    for (i = 1; i < NMAX; i++)
        fact[i] = (fact[i - 1] * i) % p;
    
}
int main()
{
    ll a, n;
    fin >> a >> n;
    fout << inv(a, n);
	return 0;
}