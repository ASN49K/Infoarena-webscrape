#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

class InP {
	FILE *fin;
	char *buff;
	int sp;

public:
	InP(const char *p) {
		fin = fopen(p, "r");
		buff = new char[4096]();
		sp = 4095;
	}
	~InP() {
		fclose(fin);
	}
	char read_ch() {
		sp++;
		if (sp == 4096) {
			fread(buff, 1, 4096, fin);
			sp = 0;
		}
		return buff[sp];
	}

	InP &operator >>(int &n) {
		char c;
		int sgn = 1;
		while (!isdigit(c = read_ch()) && c != '-');
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else n = c - '0';
		while (isdigit(c = read_ch()))
			n = n * 10 + c - '0';
		n = n * sgn;
		return *this;
	}

	InP &operator >>(ll &n) {
		char c;
		int sgn = 1;
		while (!isdigit(c = read_ch()) && c != '-');
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else n = c - '0';
		while (isdigit(c = read_ch()))
			n = n * 10LL + c - '0';
		n = n * sgn;
		return *this;
	}

	InP &operator >> (char &n) {
		n = read_ch();
		while ((n = read_ch()) != '\n' && n != ' ');
		return *this;
	}

};

class OuP {
	FILE *fout;
	char *buff;
	int sp;

public:

	OuP(const char *p) {
		fout = fopen(p, "w");
		buff = new char[50000];
		sp = 0;
	}
	~OuP() {
		fwrite(buff, 1, sp, fout);
		fclose(fout);
	}
	void write_ch(char c) {
		if (sp == 50000) {
			fwrite(buff, 1, sp, fout);
			sp = 0;
		}
		buff[sp++] = c;
	}

	OuP &operator <<(int n) {
		if (n <= 9)
			write_ch(n + '0');
		else {
			*(this) << (n / 10);
			write_ch(n % 10 + '0');
		}
		return *this;
	}

	OuP &operator <<(ll n) {
		if (n <= 9)
			write_ch(n + '0');
		else {
			*(this) << (n / 10);
			write_ch(n % 10 + '0');
		}
		return *this;
	}

	OuP &operator <<(char c) {
		write_ch(c);
		return *this;
	}

	OuP &operator <<(const char *c) {
		while (*c) {
			write_ch(*c);
			c++;
		}
		return *this;
	}

};

InP fin("inversmodular.in");
OuP fout("inversmodular.out");

// ifstream fin("file.in");
// ofstream fout("file.out");

int a, n;

int phi(int n) {

	int ans = n;
	for (int i = 2; i * i <= n && n > 1; ++i) {
		if (n % i == 0) {
			while (n % i == 0)
				n /= i;
			ans -=  ans / i;
		}
	}
	if (n)
		ans -= ans / n;
	return ans;

}


int expp(int a, int n, int mod) {
	ll p = 1;
	while (n) {
		if (n & 1)
			p = p * a % mod;
		a = a * a % mod;
		n >>= 1;
	}
	return p;
}

int main() {


	fin >> a >> n;
	fout << expp(a, phi(n) - 1 , n);

// fin.close();
// fout.close();
	return 0;
}