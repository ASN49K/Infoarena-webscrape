#include <fstream>

using namespace std;
ifstream fin ("inversmodular.in");
ofstream fout ("inversmodular.out");
long int t,a,N,c,k,x,y,d;
void cmmdc (long int a,long int b,long int &d)
{
    if (b==0)
        d = a;
    else
        cmmdc(b,a%b,d);
}
void euclid (long int a,long int b,long int d,long int &x,long int &y)
{
    if (b==0)
    {
        x = 1;
        y = 0;
    }
    else
    {
        long int x0,y0;
        euclid(b,a%b,d,x0,y0);
        x = y0;
        y = x0 - (a/b)*y0;
    }
}
int main()
{
    fin >> a >> N;
    euclid(a,N,1,x,y);
    fout << x;
    return 0;
}
