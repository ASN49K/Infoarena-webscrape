#include <stdio.h>

int inv_modular(unsigned long long a, unsigned long long n) {
    for (unsigned long long x = 1; x < n; x++) {
        if ((a * x) % n == 1) {
            return x;
        }
    }
    return -1;
}

int main(void)
{
    FILE *fin = NULL;
    FILE *fout = NULL;
    if((fin = fopen("inversmodular.in", "r")) == NULL) {
        fprintf(stderr, "Eroare la deschidere\n");
        return 1;
    }

    if((fout = fopen("inversmodular.out", "w")) == NULL) {
        fprintf(stderr, "Eroare la deschidere\n");
        fclose(fin);
        return 1;
    }

    unsigned long long a, n;

    fscanf(fin, "%llu %llu", &a, &n);

    unsigned long long result = inv_modular(a, n);
    if (result == -1) {
        fprintf(fout, "Nu exista\n");
    } else {
        fprintf(fout, "%llu\n", result);
    }

    fclose(fin);
    fclose(fout);
    


    return 0;
}