#include <bits/stdc++.h>

using namespace std;
ifstream fin("inversmodular.in");
ofstream fout("inversmodular.out");
long long gcd(long long a, long long b, long long &x, long long &y){
    if(!b){
        x = 1;
        y = 0;
        return a;
    }
    long long x0,y0;
    long long d = gcd(b,a % b,x0,y0);
    x = y0;
    y = x0 - (a / b) * y0;
    return d;
}
int main()
{
    //cu alg euclid extins
    long long n,m,x,y;
    fin >> n >> m;
    gcd(m,n,x,y);
    fout << y;
    return 0;
}
