#include <fstream>

using namespace std;

ifstream f ("inversmodular.in");
ofstream g ("inversmodular.out");

long long a, n;

long long exp(int a, int x){
    long long p = 1;
    while(x){
        if(x % 2 == 1){
            p = (p * a) % n;
        }
        a = (a * a) % n;
        x /= 2;
    }
    return p % n;
}

int main()
{
    f >> a >> n;
    g << exp(a, n - 1);
    return 0;
}
