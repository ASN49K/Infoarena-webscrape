#include <fstream>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
#include <vector>
#define ll long long
using namespace std;
ifstream cin("inversmodular.in");
ofstream cout("inversmodular.out");
ll a,n;
ll poww(ll a,ll b)
{
    ll ans=1;
    while(b)
    {
        if(b%2)
        {
            ans=ans*a;
            ans%=n;
        }
        a=a*a;
        a%=n;
        b/=2;
    }
    return ans;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin>>a>>n;
    cout<<poww(a,n-2);
    return 0;
}
