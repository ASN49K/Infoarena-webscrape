#include <stdio.h>
#include <stdint.h>
#include <math.h>

void read_uint32_t(FILE *__restrict stream, uint32_t *__restrict nr) {
  uint8_t ch;
  *nr = 0;
  while ((ch = fgetc(stream)) && ('0' <= ch && ch <= '9')) {
    *nr *= 10;
    *nr += ch - '0';
  }
  if (ch == '\r') {
    fgetc(stream);
  }
}

uint32_t etot(uint32_t x) {
  uint32_t sqx = sqrt(x);
  uint32_t res = x;
  int32_t i;
  for(i = 2; i <= sqx; ++i) {
    if (x % i == 0) {
      while (x % i == 0) {
        x /= i;
      }
      res -= res / i;
    }
  }
  if (x != 1) {
    res -= res / x;
  }
  return res;
}

uint32_t lpowm(uint32_t b, uint32_t exp, uint32_t mod) {
  uint32_t r = 1;
  b %= mod;
  if (exp == 0) {
    return r;
  }
  while (exp != 0) {
    if ((exp & 1) == 1) {
      r *= b;
      r %= mod;
    }
    exp >>= 1;
    b *= b;
    b %= mod;
  }
  if (r == 0) {
    return -1;
  }
  return r;
}

int main(void) {
  uint32_t a, n;
  {
    FILE *__restrict in = fopen("inversmodular.in", "r");
  
    read_uint32_t(in, &a);
    read_uint32_t(in, &n);
  
    fclose(in);
  }

  {
    FILE *__restrict out = fopen("inversmodular.out", "w");
  
    fprintf(out, "%u\n", lpowm(a, etot(n) - 1, n));
  
    fclose(out);
  }

  return 0;
}
