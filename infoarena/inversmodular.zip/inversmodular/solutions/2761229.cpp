#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
typedef vector<int> vec;
typedef vector<int64> vec64;
string __fname = "inversmodular";
ifstream in (__fname + ".in");
ofstream out (__fname + ".out");
#define cin in
#define cout out
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define ss cout << " ";
#define nn cout << "\n";
#define ct(x) cout << x;
#define cts(x) cout << x << " ";
#define ctn(x) cout << x << "\n";
#define db(x) cout << "> " << #x << ": " << x << "\n";
#define qr queries();
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
// const int64 mod = 1000000007;
const double pi = 3.14159265359;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
int64 mod;

void solve(int id){
    
    return;
}

int64 pw (int a, int b) {
    if (b == 1) return a;
    int64 temp = pw(a, b / 2);
    if (b % 2 == 0) return (temp * temp) % mod;
    return (temp * temp * a) % mod;
}

int phi(int n)
{
     
    // Initialize result as n
    float result = n;
  
    // Consider all prime factors of n
    // and for every prime factor p,
    // multiply result with (1 - 1/p)
    for(int p = 2; p * p <= n; ++p)
    {
         
        // Check if p is a prime factor.
        if (n % p == 0)
        {
             
            // If yes, then update n and result
            while (n % p == 0)
                n /= p;
                 
            result *= (1.0 - (1.0 / (float)p));
        }
    }
  
    // If n has a prime factor greater than sqrt(n)
    // (There can be at-most one such prime factor)
    if (n > 1)
        result *= (1.0 - (1.0 / (float)n));
  
    return (int)result;
}


int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int64 a,b;
    cin >> a >> b;
    mod = b;
    ctn(pw(a, phi(b) - 1));
    return 0;
}