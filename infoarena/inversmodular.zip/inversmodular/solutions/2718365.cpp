#include <bits/stdc++.h>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

long long n,p;
const long long mod=1999999973;

long long putere(long long a,long long b)
{

 long long sol=1,put=a;

 while( b>0 )
 {
  if( b%2==1 ) sol= (1LL*sol*put)%mod;

  put=(1LL*put*put)%mod;
  b/=2;
 }

 return sol;
}

int main()
{
 f>>n>>p;

 g<<putere(n,p);
}
