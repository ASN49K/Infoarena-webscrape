#include <iostream>

int bezout_gcd(int a, int &x, int b, int &y)
{
    int r_x, r_y, d;
    
    if (b == 0) {
        x = 1;
        y = 0;
        d = a;
    } else {
        d = bezout_gcd(b, r_x, a % b, r_y);
        x = r_y;
        y = r_x - (a / b) * r_y;
    }

    return d;
}

int main()
{
    int a, n;
    int x, y, d;

    freopen("inversmodular.in", "r", stdin);
    freopen("inversmodular.out", "w", stdout);

    std::cin >> a >> n;

    d = bezout_gcd(a, x, n, y);

    std::cout << x << '\n';

    return 0;
}
