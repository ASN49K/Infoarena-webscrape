#include <bits/stdc++.h>
using namespace std;

long long euclid_extins(long long a, long long b, long long x, long long y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    long long x1, y1;
    long long d = euclid_extins(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return d;
}

long long invers_modular(long long A, long long N)
{
    long long x, y;
    long long d = euclid_extins(A, N, x, y);
    if (d != 1) return -1;
    return (x % N + N) % N;
}

int main()
{
    ifstream fin("inversmodular.in");
    ofstream fout("inversmodular.out");
    long long A, N;
    fin >> A >> N;
    fout << invers_modular(A, N);
    return 0;
}
