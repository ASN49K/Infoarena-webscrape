#include <bits/stdc++.h>

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
typedef long double ld;
const ld EPS=1e-15;
int n,m;
bool use[305];
ld v[305][305],sol[305];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>v[i][j];
    int i=1;
    int j=1;
    while(i<=n&&j<=m)
    {
        int x=0;
        for(int l=i;l<=n;l++)
            if(v[l][j]!=0)
                {
                    x=l;
                    break;
                }
        if(x==0)
        {
            j++;
            continue;
        }
        swap(v[i],v[x]);
        ld a=v[i][j];
        for(int p=1;p<=m+1;p++)
            v[i][p]/=a;
        for(int k=i+1;k<=n;k++)
        {
            ld u=v[k][j];
            for(int p=1;p<=m+1;p++)
                v[k][p]-=u*v[i][p];
        }
        i++;
        j++;
    }
    for(int i=n;i>=1;i--)
    {
        int who=0;
        ld suma=0;
        for(int j=1;j<=m;j++)
            if(v[i][j]!=0)
            {
                if(use[j])
                {
                    suma+=v[i][j]*sol[j];
                    continue;
                }
                if(who!=0)
                {
                    use[who]=1;
                    sol[who]=0;
                }
                who=j;
            }
        if(who==0)
        {
            if(abs(suma-v[i][m+1])>EPS)
            {
                fout<<"IMPOSIBIL";
                return 0;
            }
            continue;
        }
        use[who]=1;
        sol[who]=(v[i][m+1]-suma)/v[i][who];
    }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(8)<<sol[i]<<' ';
    return 0;
}
