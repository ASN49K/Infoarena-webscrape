#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int nmax = 3e2 + 10;
const int mmax = 3e2 + 10;

const double eps = 1e-8;

int n, m;
int p[nmax];
double a[nmax][mmax], x[mmax];

void input() {
    fin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m + 1; ++j)
            fin >> a[i][j];
}

void impossible() {
    fout << "Imposibil\n";
    exit(0);
}

bool is_equal(double a, double b) {
    if (a + eps < b) return 0;
    if (b + eps < a) return 0;
    return 1;
}

void gauss() {
    for (int i = 1; i <= n; ++i) {
        p[i] = 0;
        for (int j = 1; j <= m + 1 && !p[i]; ++j)
            if (!is_equal(a[i][j], 0.0)) p[i] = j;

        if (p[i] == m + 1)
            impossible();
        if (p[i] == 0)
            continue;

        for (int j = 1; j <= n; ++j) {
            if (i == j || is_equal(a[j][p[i]], 0.0)) continue;

            double coef = a[j][p[i]] / a[i][p[i]];
            for (int k = 1; k <= m + 1; ++k)
                a[j][k] -= a[i][k] * coef;
        }
    }

    for (int i = 1; i <= m; ++i)
        if (p[i]) x[p[i]] = a[i][m+1] / a[i][p[i]];
}

void output() {
    fout << fixed << setprecision(10);
    for (int i = 1; i <= m; ++i)
        fout << x[i] << ' ';
    fout << '\n';
}

int main() {
    input();
    gauss();
    output();

    return 0;
}
