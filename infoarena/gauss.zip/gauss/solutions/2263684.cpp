#include <bits/stdc++.h>

#define eps  (1e-8)
#define MaxN 305

double Sol[MaxN], A[MaxN][MaxN], Val;
int N, M;
// AM STAT 3 ORE INVATAND UN COD PROST JUST END THIS FFS IM DONE
int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    scanf("%d%d", &N, &M);
    for(int i = 0; i < N; i++)
        for(int j = 0; j <= M; j++)
            scanf("%lf", &A[i][j]);

    int LC = 0, CC = 0;
    bool Check;
    while (LC < N && CC < M) {
        if (abs(A[LC][CC]) < eps) {
            Check = 0;

            for (int i=LC + 1; i<N; i++)
                if (abs(A[i][CC]) >= eps) {
                    for (int j = CC; j <= M; j++)
                        std::swap(A[i][j], A[LC][j]);
                    Check = 1;
                    break;
                }

            if (Check == 0) {
                CC++;
                continue;
            }
        }

        for (int i = CC + 1; i <= M; i++)
            A[LC][i] /= A[LC][CC];
        A[LC][CC] = 1;

        for (int i = LC + 1, j; i < N; i++) {
            for (j = CC + 1; j <= M; j++)
                A[i][j] -= A[i][CC] * A[LC][j];
            A[i][CC] = 0;
        }

        LC++;
        CC++;
    }

    Check = 1;
    for(int i = N - 1, j; i >= 0; i--) {
        for (j=0; j<=M && abs(A[i][j]) < eps; ++j);

        if(j==M + 1)
            continue;
        else if(j == M) {
            Check = 0;
            break;
        }
        else {
            Val = 0;
            for (int k = j + 1; k < M; k++)
                Val += A[i][k] * Sol[k];
            Sol[j] = A[i][M] - Val;
        }
    }

    if(Check == 0) printf("Imposibil");
    else
        for(int i = 0; i < M; i++)
            printf("%.10f ", Sol[i]);

    return 0;
}
