#include <cstdio>
#define nMax 324

using namespace std;

int ecs,unks;
double coef[nMax][nMax];
char compatibility=1;

void read() {
    int i,j;
    scanf("%d%d",&ecs,&unks);
    for(i=0;i<ecs;++i) {
        for(j=0;j<=unks;++j) {
            scanf("%lf",&coef[i][j]);
        }
    }
}

void swapLines(int i,int j) {
    int k;
    for(k=0;k<=unks;++k) {
        coef[i][k]+=coef[j][k];
        coef[j][k]=coef[i][k]-coef[j][k];
        coef[i][k]-=coef[j][k];
    }
}

char maybe(int pos) {
    int i;
    for(i=pos+1;i<ecs;++i) {
        if(coef[i][pos]) {
            swapLines(pos,i);
            return 0;
        }
    }
    return 1;
}

void go() {
    int i,j,k,kk;
    for(i=0;i<unks;++i) {
        if(!coef[i][i]) {
            if(maybe(i)) {
                compatibility=0;
                return;
            }
        }
        for(j=i+1;j<ecs;++j) {
            for(k=0;k<=unks;++k) {
                kk=;
            }
        }
    }
}

void goBack() {
    int i,j;
    for(i=unks-1;i>=0;--i) {
        coef[i][unks]/=coef[i][i];
        coef[i][i]=1;
        for(j=0;j<i;++j) {
            coef[j][unks]-=coef[i][unks]*coef[j][i];
            coef[j][i]=0;
        }
    }
}

void solve() {
    go();
    if(compatibility) {
        goBack();
    }
}

void display() {
    int i;
    for(i=0;i<unks;++i) {
        printf("%lf",coef[i][unks]);
    }
}

void error() {
    printf("Imposibil");
}

int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    read();
    if(ecs<unks) {
        error();
        return 0;
    }
    solve();
    if(compatibility) {
        display();
    }
    else {
        error();
    }
    return 0;
}
