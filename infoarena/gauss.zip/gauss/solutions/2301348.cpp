#include<cstdio>
#include<cmath>
using namespace std;
double a[302][302],sol[301];
const double eps=1.e-14;
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    int n,m,i,j,k,l;
    scanf("%d%d",&n,&m);
    for(i=1;i<=n;++i)
    {
        for(j=1;j<=m+1;++j)
        {
            scanf("%lf",&a[i][j]);
        }
    }
    i=1,j=1;
    while(j<=m&&i<=n)
    {
        int ok=0;
        for(k=i;k<=n;++k)
        {
            if(fabs(a[k][j])>0.0)
            {
                ok=1;
                for(l=1;l<=m+1;++l)
                {
                    double aux=a[k][l];
                    a[k][l]=a[i][l];
                    a[i][l]=aux;
                }
                break;
            }
        }
        if(!ok)
            j++;
        else
        {
            double val=a[i][j];
            for(k=1;k<=m+1;++k)
            {
                a[i][k]/=val;
            }
            for(k=i+1;k<=n;++k)
            {
                double coef=a[k][j];
                for(l=1;l<=m+1;++l)
                {
                    a[k][l]-=coef*a[i][l];
                }
            }
            i++;
            j++;
        }
    }
    int check=1;
    for(i=n;i;--i)
    {
        check=0;
        int poz;
        for(j=1;j<=m;++j)
        {
            if(fabs(a[i][j])>=eps)
            {
                poz=j;
                check=1;
                break;
            }
        }
        if(!check)
        {
            printf("Imposibil\n");
            break;
        }
        for(j=m;j>poz;--j)
        {
            a[i][m+1]-=a[i][j]*sol[j];
        }
        sol[poz]=a[i][m+1]/a[i][poz];
    }
    for(i=1;i<=m;++i)
    {
        printf("%.4lf ",sol[i]);
    }
    printf("\n");
    return 0;
}
