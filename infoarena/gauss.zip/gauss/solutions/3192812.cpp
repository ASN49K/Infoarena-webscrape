#include <bits/stdc++.h>

#define cin fin
#define cout fout

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

typedef long double ld;

ld eps = 1e-9;
bool gauss(int n, int m, vector<vector<ld>> a, vector<ld> &ans)
{
	vector<ld> wh(m + 1);
	for (int row = 1, col = 1; row <= n && col <= m; ++col)
	{
		int qui = row;
		for (int i = row; i <= n; ++i)
		{
			if (abs(a[i][col]) > abs(a[qui][col]))
			{
				qui = i;
			}
		}
		swap(a[row], a[qui]);
		if (abs(a[row][col]) < eps)
		{
			continue;
		}
		wh[col] = row;
		for (int i = 1; i <= n; ++i)
		{
			if (i != row)
			{
				ld c = a[i][col] / a[row][col];
				for (int j = col; j <= m + 1; ++j)
				{
					a[i][j] -= c * a[row][j];
				}
			}
		}
		++row;
	}
	ans = vector<ld>(m + 1);
	for (int i = 1; i <= m; ++i)
	{
		if (wh[i])
		{
			ans[i] = a[wh[i]][m + 1] / a[wh[i]][i];
		}
	}
	for (int i = 1; i <= n; ++i)
	{
		ld s = 0;
		for (int j = 1; j <= m; ++j)
		{
			s += a[i][j] * ans[j];
		}
		if (abs(s - a[i][m + 1]) > eps)
		{
			return 0;
		}
	}
	return 1;
}

int32_t main()
{
	cin.tie(nullptr)->sync_with_stdio(false);
	int n, m;
	cin >> n >> m;
	vector<vector<ld>> a(n + 1, vector<ld>(m + 2));
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= m + 1; ++j)
		{
			cin >> a[i][j];
		}
	}
	vector<ld> ans;
	if (gauss(n, m, a, ans))
	{
		for (int i = 1; i <= m; ++i)
		{
			cout << fixed << setprecision(10) << ans[i] << ' ';
		}
	}
	else
	{
		cout << "Imposibil\n";
	}
}