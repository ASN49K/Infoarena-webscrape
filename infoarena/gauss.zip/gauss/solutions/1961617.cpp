#include<fstream>
#include<iostream>
#include<iomanip>
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMax = 305;
const double Eps = 1e-8;

int N,M,K,row,col;
int R[NMax];
double Coef[NMax][NMax];

void Read()
{
    fin>>N>>M;

    for(int i = 1 ; i <= N ; ++i)
        for(int j = 1 ; j <= (M + 1) ; ++j)
            fin>>Coef[i][j];
}

bool Zero(double Val)
{
    return ((-Eps < Val) && (Val < Eps));
}

void Solve()
{
    for(row = 1 , col = 1 ; row <= N && col <= M ; row++ , col++)
    {
        if(Zero(Coef[row][col]))
        {
            int nrow = row + 1;

            while(nrow <= N && Zero(Coef[nrow][col])) ++nrow;

            if(nrow > N)
            {   col++;  continue;   }

            swap(Coef[row],Coef[nrow]);
        }

        for(int i = 1 ; i <= N ; ++i)
            if(i != row)
            {
                double rap = Coef[i][col] / Coef[row][col];

                for(int j = 1 ; j <= (M + 1) ; ++j)
                    Coef[i][j] -= Coef[row][j] * rap;
            }

        R[col] = row;
    }
}

void Print()
{
    if(col > M)
    {
        for( ; row <= N ; ++row)
            if(!Zero[row][M+1])
            {
                fout<<"Imposibil\n";
                return;
            }
    }

    fout<<fixed<<setprecision(10);

    for(int i = 1 ; i <= M ; ++i)
        if(R[i])    fout << Coef[R[i]][M+1] / Coef[R[i]][i]<<" ";
        else    fout << "0.0 ";
    fout<<"\n";
}

int main()
{
    Read();
    Solve();
    Print();

    fin.close();
    fout.close();
    return 0;
}
