#include <fstream>
#include <iomanip>

#define MAX_N 300
#define MAX_M 301

using namespace std;

const double EPS = 1 / (1e10);

int rez;
int n, m;

double x[MAX_M + 1];
double a[MAX_N + 1][MAX_M + 1];

bool egal0(double nr)
{
    return (-EPS < nr && nr < EPS);
}

void readFile()
{
    ifstream f("gauss.in");

    f >> n >> m;

    int i, j;
    for(i = 1; i <= n; i ++)
    {
        for(j = 1; j <= m + 1; j ++)
            f >> a[i][j];
    }

    f.close();
}

void gauss()
{
    int l, h;
    int i = 1, j = 1;
    while(i <= n && j <= m)
    {
        int c = i;
        while(c <= n && egal0(a[c][j]))
            c ++;

        if(c > n)
            j ++;

        else
        {
            if(c != i)
            {
                for(h = 1; h <= m + 1; h ++)
                    swap(a[c][h], a[i][h]);
            }

            for(h = j + 1; h <= m + 1; h ++)
                a[i][h] /= a[i][j];
            a[i][j] = 1;

            for(h = i + 1; h <= n; h ++)
            {
                for(l = j + 1; l <= m + 1; l ++)
                    a[h][l] -= a[h][j] * a[i][l];
                a[h][j] = 0;
            }

            i ++;
            j ++;
        }
    }
}

void getRez()
{
    int i, j, h;
    for(i = n; i >= 1 && (rez == 0); i --)
    {
        int done = 0;
        for(j = 1; j <= m +1 && (done == 0); j ++)
        {
            if(egal0(a[i][j]) == 0)
            {
                if(j == m + 1)
                {
                    rez = -1;
                    break;
                }

                x[j] = a[i][m + 1];

                for(h = m; h > j; h --)
                    x[j] -= x[h] * a[i][h];

                done = 1;
            }
        }
    }
}

void solve()
{
    gauss();

    getRez();
}

void printFile()
{
    ofstream g("gauss.out");

    if(rez == -1)
        g << "Imposibil\n";

    else
    {
        int i;
        for(i = 1; i <= m; i ++)
            g << fixed << setprecision(10) << x[i] << " ";
        g << "\n";
    }

    g.close();
}

int main()
{
    readFile();

    solve();

    printFile();

    return 0;
}
