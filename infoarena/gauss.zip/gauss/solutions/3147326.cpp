#include<bits/stdc++.h>
using namespace std;
ifstream F("gauss.in");
ofstream G("gauss.out");
int n,m,i,j,l,k,t;
double a[302][302],b[302];
int main()
{
    for(F>>n>>m,i=1;i<=n;++i)
        for(j=1;j<m+2;F>>a[i][j++]);
    for(i=1,j=1;i<=n&&j<=m;) {
        for(k=i+1;k<=n&&!a[k][j];++k);
        if(k>n)
            ++j,i=j;
        else {
            for(t=k;t<=n;a[t++][j]=0)
                for(l=j+1;l<m+2;a[t][l]-=a[t][j]/a[i][j]*a[i][l],++l);
            ++i,++j;
        }
    }
    for(i=1;i<=n;++i) {
        for(j=1;j<m+2&&!a[i][j];++j);
        if(j==m+1)
            return G<<"Imposibil",0;
    }
    for(i=1;i<=n;++i)
        for(j=i+1;j<m+2;++j)
            if(a[i][i])
                a[i][j]/=a[i][i];
    for(b[n]=a[n][m+1],i=n-1;i;--i)
        if(a[i][i])
            for(b[i]=a[i][m+1],j=i+1;j<=m;b[i]-=a[i][j]*b[j],++j);
    for(G<<fixed<<setprecision(10),i=1;i<=m;G<<b[i++]<<' ');
    return 0;
}
