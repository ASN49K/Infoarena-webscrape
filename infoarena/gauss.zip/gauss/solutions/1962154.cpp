#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 305;

int n, m;
double mat[N][N];

void citire()
{
	scanf("%d %d", &n, &m);

	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j <= m; j++)
		{
			scanf("%lf", &mat[i][j]);
		}
	}
}

void adunaLinie(int cine, int ce, double x)
{
	for(int i = 0; i <= m; i++)
	{
		mat[ce][i] += mat[cine][i] * x;
	}
}

void interschimbaLinii(int nr1, int nr2)
{
	for(int i = 0; i <= m; i++)
	{
		swap(mat[nr1][i], mat[nr2][i]);
	}
}

bool schimbaLiniiInCazDe0(int x)
{
	for(int i = x + 1; i < n; i++)				
	{
		if(mat[i][x] != 0)
		{
			interschimbaLinii(x, i);
			return true;
		}
	}

	return false;
}

void afisareDebug()
{
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j <= m; j++)
		{
			printf("%lf ", mat[i][j]);
		}
		printf("\n");
	}
}

void afisare()
{
	for(int i = 0; i < n; i++)
	{
		printf("%lf ", mat[i][m] / mat[i][i]);
	}
}

void solve()
{
	if(m > n)
	{
		printf("Imposibil");
		return;
	}

	for(int i = 0; i < m; i++)
	{
		if(mat[i][i] == 0)
		{
			if(schimbaLiniiInCazDe0(i) == false)
			{
				printf("Imposibil");
				return;
			}
		}

		for(int j = i + 1; j < m; j++)
		{
			if(mat[j][i] != 0)
			{
				adunaLinie(i, j, -mat[j][i] / mat[i][i]);
			}
		}
	}

	for(int i = m - 1; i  >= 0; i--)
	{
		for(int j = i - 1; j >= 0; j--)
		{
			if(mat[j][i] != 0)
			{
				adunaLinie(i, j, -mat[j][i] / mat[i][i]);
			}
		}
	}

	//afisareDebug();
	afisare();
}

int main()
{
	freopen("gauss.in", "r", stdin);
	freopen("gauss.out", "w", stdout);

	citire();
	solve();
	
	return 0;
}
