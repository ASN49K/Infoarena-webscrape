#include <bits/stdc++.h>

#define EPS 0.0001
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int N, M;
vector<vector<double>> matrix;
vector<double> X;

void Read()
{
    fin >> N >> M;
    X.resize(M + 2, 0);
    matrix.resize(N + 1, vector<double>(M + 2));

    for (int i = 1; i <= N; ++i)
    {
        for (int j = 1; j <= M + 1; ++j)
            fin >> matrix[i][j];
    }
}

void Write()
{
    for (int i = 1; i <= N; ++i, fout << endl)
        for (int j = 1; j <= M + 1; ++j)
            fout << matrix[i][j] << " ";
    fout << endl;
}

void writeX()
{
   fout <<  setprecision(8);
    for(int i = 1; i <= M; ++i)
        fout << fixed << X[i] << " ";
    printf("\n");

}

void Gauss()
{
    int i = 1, j = 1, k;
    double aux;
    while (i <= N && j <= M)
    {
            for(k = i; k <= N; ++k)
                if(matrix[k][j]<-EPS || matrix[k][j]>EPS)
                    break;

            if(k == N+1)
            {
                ++j;
                continue;
            }
            if (k != i)
                    for (int c = i; c <= M + 1; ++c)
                    {
                        aux = matrix[i][c];
                        matrix[i][c] = matrix[k][c];
                        matrix[k][c] = aux;
                    }

            double pivot = matrix[i][j];
            for (int c = j + 1; c <= M + 1; ++c)
                 matrix[i][c] = (double)matrix[i][c]/pivot;
            matrix[i][j] = 1;

            for (int l = i + 1; l <= N; ++l)
            {
               for (int c = j + 1; c  <= M + 1; ++c)
                    matrix[l][c] -=  matrix[i][c] * matrix[l][j];
               matrix[l][j] = 0;
            }
            ++i, ++j;
    }

    for(int i = N; i>0; --i)
        for(int j = 1; j <= M+1; ++j)
            if(matrix[i][j]>EPS || matrix[i][j]<-EPS)
            {
                //Singura valoare nenegativa de pe linia i este rezultatul => sistemul nu are solutie.
                if(j == M+1)
                {
                    printf("Imposibil\n");
                    return;
                }

                //Calculam pe necunoscuta j = rezultatul ecuatiei i - necunoscutele j+1...M inmultite cu coeficientii lor din aceasta ecuatie.
                X[j] = matrix[i][M+1];
                for(int k = j+1; k <= M; ++k)
                    X[j] -= X[k] * matrix[i][k];

                break;
            }
    writeX();
}



int main()
{
    Read();
    Gauss();
    return 0;
}
