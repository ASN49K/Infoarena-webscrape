#include <bits/stdc++.h>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

const double kEps=1e-9;

int n,m,i,j,k,u;
double X[310],a[310][310];

int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    i=j=1;
    for(;i<=n&&j<=m;)
    {
        for(k=i;k<=n;k++)
            if(a[k][j]<=-kEps||kEps<=a[k][j])
                break;
        if(k==n+1)
            continue;
        if(k!=i)
            swap(a[k],a[i]);
        for(k=j+1;k<=m+1;k++)
            a[i][k]/=a[i][j];
        a[i][j]=1;
        for(k=i+1;k<=n;k++)
        {
            for(u=j+1;u<=m+1;u++)
                a[k][u]-=a[k][j]*a[i][u];
            a[k][j]=0;
        }i++,j++;
    }
    for(i=n;i>=1;i--)
        for(j=1;j<=m+1;j++)
            if(a[i][j]<=-kEps||kEps<=a[i][j])
            {
                if(j==m+1)
                {
                    g<<"Imposibil";
                    return 0;
                }
                X[j]=a[i][m+1];
                for(k=j+1;k<=m;k++)
                    X[j]-=X[k]*a[i][k];
                break;
            }
    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<X[i]<<' ';
    return 0;
}
