#include <stdio.h>
#define  zero 0.00000001
using namespace std;
FILE*f=fopen("gauss.in","r");
FILE*g=fopen("gauss.out","w");
int i1,j1,m,n,k,i,j;
double x[1001],a[1001][1002];
void intersc (int k,int i){
int l;
for(l=1;l<=m+1;l++){
    double aux=a[i][l];
    a[i][l]=a[k][l];
    a[k][l]=aux;


}


}
int main()
{fscanf(f,"%d%d",&n,&m);
for(i=1;i<=n;i++)
    for(j=1;j<=m+1;j++)
    fscanf(f,"%lf",&a[i][j]);
i=j=1;
while(i<=n&&j<=m){

  for(k=i;k<=n;k++) if(a[k][j]>zero||a[k][j]<zero) break;
  if(k==n+1) j++;
  else{
    if(k!=i)intersc(k,i);
    for(i1=j+1;i1<=m+1;i1++)
        a[i][i1]=a[i][i1]/a[i][j];
    a[i][j]=1;
    for(i1=i+1;i1<=n;i1++)
    {for(j1=j+1;j1<=m+1;j1++)

        a[i1][j1]=a[i1][j1]-a[i1][j]*a[i][j1];
    a[i1][j]=0;
  }
    i++;j++;


  }







}
for(i=n;i>0;i--)
for(j=i;j<=m+1;j++)

  if(a[k][j]>zero||a[k][j]<zero)  {
   if(j==m+1){


    fprintf(g,"Imposibil\n");
    return 0;
   }
    x[j]=a[i][m+1];
    for(k=j+1;k<=m;k++)
        x[j]=x[j]-x[k]*a[i][k];
    break;
  }


for(i=1;i<=m;i++) fprintf(g,"%.10lf ",x[i]);
    return 0;
}
