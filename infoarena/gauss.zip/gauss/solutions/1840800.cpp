#include <cstdio>
#include <algorithm>
#define EPS 0.0000001

using namespace std;

int n,m,i,j;
double a[500][500];
double x[500];

int main()
{
    int k,l,u;
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(i=1;i<=n;++i)
        for(j=1;j<=m+1;++j) scanf("%lf",&a[i][j]);

    //triangularizez matricea
    i=1;j=1;
    while(i<=n && j<=m)
    {
        for(k=i;k<=n;++k)
            if(a[k][j] < -EPS || a[k][j] > EPS) break;
        //necunoscuta e variabila libera
        if (k == n+1){
            ++j;
            continue;
        }

        if(k != i)
            for(int l=1;l<=m+1;++l)
            {
                double aux=a[i][l];
                a[i][l]=a[k][l];
                a[k][l]=aux;
            }

        for(l=j+1;l<=m+1;++l)
            a[i][l] = a[i][l]/a[i][j];
        a[i][j]=1;

        for(u=i+1;u<=n;++u)
        {
            for(l=j+1;l<=m+1;++l)
                a[u][l] = a[u][l] - (a[u][j]*a[i][l]);
            a[u][j]=0;
        }
        ++i;++j;
    }

    //aflu necunoscutele
    for(i=n;i>0;--i)
        for(j=1;j<=m+1;++j)
        {
            if(a[i][j] < -EPS || a[i][j] > EPS)
            {
                if( j == m+1 ){
                    printf("IMPOSIBIL\n");
                    return 0;
                }
                x[j]=a[i][m+1];
                for(l=j+1;l<=m;++l)
                    x[j] -= x[l] * a[i][l];
                break;
            }
        }

    for(i=1; i<=m; ++i)
            printf("%.8f ",x[i]);
    return 0;
}
