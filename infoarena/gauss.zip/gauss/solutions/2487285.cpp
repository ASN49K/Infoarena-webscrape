#include <fstream>
#include <iomanip>
#define eps 0.000000001

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n,m,i,j,k;
double a[305][305],x[305];

int main()
{
    fin >> n >> m;
    for (i=1; i<=n; i++)
        for (j=1; j<=m+1; j++)
            fin >> a[i][j];
    i = 1; j = 1; /// la ecuatia i, necunoscuta j
    while (i <= n && j <= m)
    {
        for (k=i; k<=n; k++)
            if (a[k][j] != 0)
                break;
        if (k == n+1)
        {
            j++;
            continue;
        }
        if (k != i)
            for (int ind=1; ind<=m+1; ind++)
                swap(a[i][ind], a[k][ind]);
        for (int ind=j+1; ind<=m+1; ind++)
            a[i][ind] /= a[i][j];
        a[i][j] = 1;
        for (k=i+1; k<=n; k++)
        {
            for (int ind=j+1; ind<=m+1; ind++)
                a[k][ind] -= a[i][ind]*a[k][j];
            a[k][j] = 0;
        }
        i++; j++;
    }
    int ok = 0;
    for (i=n; i>=1; i--)
    {
        for (j=1; j<=m+1; j++)
            if (a[i][j] < -eps || a[i][j] > eps)
                break;
        if (j == m+2)
            continue;
        if (j == m+1)
        {
            ok = 1;
            break;
        }
        x[j] = a[i][m+1];
        for (k=j+1; k<=m; k++)
            x[j] -= x[k]*a[i][k];
    }
    if (ok == 1)
        fout << "Imposibil";
    else
        for (i=1; i<=m; i++)
            fout << setprecision(10) << fixed << x[i] << " ";
    return 0;
}
