#include <bits/stdc++.h>

using namespace std;

const int NMAX = 300;

double a[NMAX + 1][NMAX + 1];
double eps = 1e-8;

int line[NMAX + 1];

double solutions[NMAX + 1];

double modul( double a ) {
    if ( a < 0 )
        return -a;
    return a;
}
int main() {
    ifstream fin( "gauss.in" );
    ofstream fout( "gauss.out" );
    int n, m, i, current_collum, current_line, j;
    fin >> n >> m;
    for ( i = 1; i <= n; i ++ ) {
        for ( j = 1; j <= m + 1; j ++ ) {
            fin >> a[i][j];
        }
    }
    current_line = 1;
    for ( current_collum = 1; current_collum <= m; current_collum ++ ) {
        int maxim_line = current_line;
        for ( i = current_line + 1; i <= n; i ++ ) {
            if ( modul( a[i][current_collum] ) > modul( a[maxim_line][current_collum] ) )
                maxim_line = i;
        }
        if ( modul( a[maxim_line][current_collum] ) >= eps ) { /// >= 0

            line[current_collum] = current_line;

            for ( i = 1; i <= m + 1; i ++ ) {
                swap( a[current_line][i], a[maxim_line][i] );
            }
            maxim_line = current_line;
            for ( i = 1; i <= n; i ++ ) {
                double aux = a[i][current_collum] / a[maxim_line][current_collum];
                if ( i != current_line )
                    for ( int k = 1; k <= m + 1; k ++ ) {
                        a[i][k] -= a[maxim_line][k] * aux;
                    }
            }
        }
        current_line ++;
    }
    for ( j = 1; j <= m; j ++ ) {
        if ( line[j] ) {
            solutions[j] = a[line[j]][m + 1] / a[line[j]][j];
        }
    }
    for ( i = 1; i <= n; i ++ ) {
        for ( j = 1; j <= m; j ++ ) {
            a[i][m + 1] -= solutions[j] * a[i][j];
        }
        if ( modul( a[i][m + 1] ) >= eps ) {
            fout << "Imposibil";
            return 0;
        }
    }
    for ( i = 1; i <= m; i ++ )
        fout << fixed << setprecision( 8 ) << solutions[i] << ' ';
    return 0;
}
