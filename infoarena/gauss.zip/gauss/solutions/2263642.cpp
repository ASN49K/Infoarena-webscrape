#include <bits/stdc++.h>

#define MaxN 305
#define EPS  ((double)(1e-8))

std::ifstream InFile("gauss.in");
std::ofstream OutFile("gauss.out");

int N, M, P[MaxN];
double A[MaxN][MaxN], Sol[MaxN];
double Coef;

void Citire() {
    InFile >> N >> M;
    for (int i=0, j; i<N; ++i)
        for (j=0; j<M+1; ++j)
            InFile >> A[i+1][j+1];
}

void Rezolvare() {
    for (int i=0, j, k; i<N; ++i) {
        for (j=0; j<M+1; ++j)
            if(fabs(A[i+1][j+1]) > EPS)
                break;

        if (j == M+1) continue;
        if (j == M) {
            OutFile << "Imposibil\n";
            return;
        }

        P[i+1] = j+1;

        for (j=0; j<N; ++j)
            if (i!=j) {
                Coef = A[j+1][P[i+1]] / A[i+1][P[i+1]];
                for (k=0; k<M+1; ++k)
                    A[j+1][k+1] -= Coef * A[i+1][k+1];
            }
    }

    for (int i=0; i<N; ++i)
        if (P[i+1]) Sol[P[i+1]] = A[i+1][M+1] / A[i+1][P[i+1]];

    freopen("gauss.out", "w", stdout);
    for (int i=0; i<M; ++i)
        printf("%.10lf ", Sol[i+1]);
}

int main()
{
    Citire();
    Rezolvare();

    return 0;
}
