#include <fstream>
#include <iomanip>
#define NMAX 305
using namespace std;

ofstream out("gauss.out");

int n, m;
double mat[NMAX][NMAX];
double aux[NMAX][NMAX];
double nec[NMAX];

void scan() {
    ifstream in("gauss.in");
    in >> n >> m;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j <= m; ++j) {
            in >> mat[i][j];
            aux[i][j] = mat[i][j];
        }
}

double val(int i) {
    auto s = mat[i][m];
    for (int j = 0; j < m; ++j)
        s -= (mat[i][j] * nec[j]);
    return s;
}

bool verif() {
    for (int i = 0; i < n; ++i) {
        double s = 0;
        for (int j = 0; j < m; ++j)
            s += (nec[j] * aux[i][j]);

        if (s != aux[i][m])
            return false;
    }
    return true;
}

int main() {
    scan();

    for (int x = 0; x < m; ++x) {
        if (x < n) {
            if (mat[x][x] == 0) {
                for (int i = x; i < n; ++i)
                    if (mat[i][x] != 0)
                        swap(mat[x], mat[i]);
            }
        }

        auto c = mat[x][x];
        for (int i = x; i <= m; ++i)
            mat[x][i] = (double) mat[x][i] / c;

        for (int i = x + 1; i < n; ++i) {
            auto c2 = mat[i][x];
            for (int j = x; j <= m; ++j)
                mat[i][j] = mat[i][j] + ((double) mat[x][j] * (-c2));

        }
    }

    for (int i = m-1; i >= 0; --i) {
        auto c = val(i);
        nec[i] = c;
    }

    if (!verif()) {
        out << "Imposibil";
        return 0;
    }

    out << fixed;
    out << setprecision(8);
    for (int i = 0; i < m; ++i)
        out << nec[i] << ' ';
    return 0;
}