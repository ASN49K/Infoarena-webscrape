#include <bits/stdc++.h>

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n,m;
bool use[1005];
double v[305][305],ans[1005];
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>v[i][j];
    int i=1;
    int j=1;
    while(j<=n)
    {
        int x=i;
        while(x<=n&&v[x][j]==0)
            x++;
        if(x>n)
        {
            j++;
            continue;
        }
        if(x!=i)
            swap(v[x],v[i]);
        double X=v[i][j];
        for(int p=1;p<=m+1;p++)
            v[i][p]/=X;
        for(int u=i+1;u<=n;u++)
        {
            double z=v[u][j];
            for(int p=1;p<=m+1;p++)
                v[u][p]-=z*v[i][p];
        }
        i++;
        j++;
    }
    for(i=n;i>=1;i--)
    {
        double suma=0;
        bool found=0;
        int poz=m+1;
        for(int j=1;j<=m;j++)
            if(v[i][j]!=0)
            {
                poz=j;
                break;
            }
        if(poz==m+1&&v[i][m+1]<1e-14)
        {
            fout<<"Imposibil";
            return 0;
        }
        if(poz==m+1)
            continue;
        ans[poz]=v[i][m+1];
        for(int j=poz+1;j<=m;j++)
            ans[poz]-=v[i][j]*ans[j];
        ans[poz]/=v[i][poz];
    }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(10)<<ans[i]<<" ";
    return 0;
}
