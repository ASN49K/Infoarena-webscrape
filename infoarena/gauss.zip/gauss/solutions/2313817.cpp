#include<cstdio>
#define E 0.001
int n,m,i,j,k,l;
double a[302][302],x[302],y;
int main ()
{
    freopen("gauss.in","r",stdin),freopen("gauss.out","w",stdout),scanf("%d%d",&n,&m);
	for(i=1;i<=n;++i)
		for(j=1;j<=m+1;++j)
			scanf("%lf",&a[i][j]);
	for(j=1;j<=m;++j)
	{
		for(i=j;i<=n;++i)
			if(a[i][j]>E||a[i][j]<-E)
				break;
		if(i>n)
			continue;
		if(i!=j)
			for(k=1;k<=m+1;++k)
				y=a[i][k],a[i][k]=a[j][k],a[j][k]=y;
		for(k=j+1;k<=m+1;++k)
			a[j][k]/=a[j][j];
		for(a[j][j]=1,k=j+1;k<=n;++k)
		{
			for(l=j+1;l<=m+1;++l)
				a[k][l]-=a[j][l]*a[k][j];
			a[k][j]=0;
		}
	}
	for(i=n;i;--i)
		for(j=1;j<=m+1;++j)
			if(a[i][j]>E||a[i][j]<-E)
			{
				if(j==m+1)
				{
					printf("Imposibil");
					return 0;
				}
				for(x[j]=a[i][m+1],k=j+1;k<=m;++k)
					x[j]-=x[k]*a[i][k];
				break;
			}
	for(i=1;i<=m;++i)
        printf("%.9lf ",x[i]);
}
