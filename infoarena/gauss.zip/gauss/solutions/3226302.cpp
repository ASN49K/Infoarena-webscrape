#include <bits/stdc++.h>
using namespace std;
using ll = long long;
//#define int ll
using vi = vector<int>;
using pii = pair<int,int>;
using vpii = vector<pii>;
using vll = vector<ll>;
using vvi = vector<vector<int>>;
#define eb emplace_back

const int N = 300 + 5;

using ld = long double;

const ld EPS = 0.0000001;

int n, m;
ld a[N][N], x[N];

int32_t main() {
	//#ifdef ONLINE_JUDGE
    freopen("gauss.in", "r", stdin);
		freopen("gauss.out", "w", stdout);
	//#endif
	
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

 	cin >> n >> m;
 	for (int i = 1; i <= n; ++i)
 		for (int j = 1; j <= m + 1; ++j)
 			cin >> a[i][j];
 			
 		for (int i = 1, j = 1, k;i <= n && j <= m;) {
 			for (k = i; k <= n; ++k)
 				if (abs(a[k][j]) >= EPS)
 					break;
 			
 			if (k == n + 1) { ++j; continue;}
 			
 			if (k != i) {
 				for (int l = 1; l <= m + 1; ++l)
 					swap(a[k][i], a[k][l]);
 			}
 			
 			for (int l = j + 1; l <= m + 1; ++l)
 				a[i][l] /= a[i][j];
 			a[i][j] = 1;
 			
 			for (int u = i + 1; u<= n; ++u) {
 				for (int y = j + 1; y <= m + 1; ++y)
 					a[u][y] -= a[u][j] * a[i][y];
 				a[u][j] = 0; 
 			}
 			++i;
 			++j;
 		}
 	for (int i = n; i >= 1; --i) {
 		for (int j = 1; j <= m + 1; ++j) {
 			if (abs(a[i][j]) >= EPS) {
 				if (j == m + 1) {
 					cout << "Imposibil";
 					return 0;
 				}
 				x[j] = a[i][m + 1];
 				for (int k = j + 1; k <= m; ++k)
 					x[j] -= x[k] * a[i][k];
 				break;
 			}
 		}
 	}
 	cout << fixed << setprecision(8);
 	for (int i = 1; i <= m; ++i)
 		cout << x[i] << ' ';
} 


