#include <bits/stdc++.h>

using namespace std;

const int MAXN = 305;

#define EPS 1e-10

double a[MAXN][MAXN], ans[MAXN];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
    int n, m;
    fin >> n >> m;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m + 1; ++j)
            fin >> a[i][j];
    }
    int lin = 1, col = 1;
    while(lin <= n && col <= m){
        int best = lin;
        while(best <= n && fabs(a[best][col]) < EPS) best++;
        if(best > n){
            col++;
            continue;
        }
        if(best > lin)
            for(int j = 1; j <= m + 1; ++j) swap(a[lin][j], a[best][j]);
        for(int j = m + 1; j >= col; --j) a[lin][j] /= a[lin][col];
        for(int i = lin + 1; i <= n; ++i){
            for(int j = m + 1; j >= col; --j)
                a[i][j] -= a[lin][j] * a[i][col];
        }
        lin++;
        col++;
    }
    for(int i = n; i >= 1; --i){
        int pi = 1;
        while(pi <= m && fabs(a[i][pi]) < EPS) pi++;
        if(pi == m + 1 && fabs(a[i][m + 1]) > EPS){
            fout << "Imposibil";
            return 0;
        }
        ans[pi] = a[i][m + 1];
        for(int j = pi + 1; j <= m; ++j) ans[pi] -= ans[j] * a[i][j];
    }
    for(int i = 1; i <= m; ++i)
        fout << fixed << setprecision(10) << ans[i] << " ";
    return 0;
}
