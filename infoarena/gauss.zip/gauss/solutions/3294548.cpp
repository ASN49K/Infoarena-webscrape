#include <bits/stdc++.h>

using namespace std;

const int MAXN = 300 + 5;
double eps = 1e-6;

int n, m;
double a[MAXN][MAXN];
double ans[MAXN];

int gimme(int i, int j) // de la linia i in jos
{
    for(int l = i; l <= n; l++)
    {
        if(a[l][j])
            return j;
    }
    return 0;
}

int32_t main()
{
    ifstream cin("gauss.in");
    ofstream cout("gauss.out");
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m + 1; j++)
        {
            cin >> a[i][j];
        }
    }
    for(int i = 1, j = 1; i <= n && j <= m;)
    {
        int i1 = gimme(i, j);
        if(!i1)
        {
            j++;
            continue;
        }
        swap(a[i], a[i1]);
        for(int j1 = 1; j1 <= m + 1; j1++)
            a[i][j1] /= a[i][j];
        for(int j1 = 1; j1 < j; j1++)
        {
            assert(abs(a[i][j1]) < eps);
        }
        a[i][j] = 1.0;
        for(int i1 = i + 1; i1 <= n; i1++)
        {
            double cst = a[i1][j];
            for(int j1 = j + 1; j1 <= m + 1; j1++)
            {
                a[i1][j1] -= a[i][j1] * cst;
            }
            a[i1][j] = 0.0;
        }
        i++;
        j++;
    }
//    for(int i = 1; i <= n; i++)
//    {
//        for(int j = 1; j <= m + 1; j++)
//        {
//            cout << a[i][j] << ' ';
//        }
//        cout << '\n';
//    }
    for(int i = n; i >= 1; i--)
    {
        for(int j = 1; j <= m + 1; j++)
        {
            if(abs(a[i][j]) > eps)
            {
                if(j == m + 1)
                {
                    cout << "Imposibil";
                    return 0;
                }
                ans[j] = a[i][m + 1];
                for(int j1 = j + 1; j1 <= m + 1; j1++)
                {
                    ans[j] -= a[i][j1] * ans[j1];
                }
                break;
            }
        }
    }
    for(int i = 1; i <= m; i++)
        cout << fixed << setprecision(8) << ans[i] << ' ';
    return 0;
}
