#include <bits/stdc++.h>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n,m,i,j,k,col;
double a[310][310],sol[310];

int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    }

    i=1;j=1;
    while(i<=n && j<=m)
    {
        for(k=i;k<=n;k++)
            if(a[k][j]!=0) break;

        if(k!=i) // interschimb liniile
        {
            for(col=j;col<=m+1;col++)
            {
                swap(a[i][col],a[k][col]);
            }
        }


        // de acum incolo, am facut interschimbarea si lucrez cu i, nu cu k

        for(col=j+1;col<=m+1;col++)
            a[i][col]=a[i][col]/a[i][j];

        a[i][j]=1; // abia la final fac a[i][j]=1, pentru ca altfel se modifica pe parcurs

        for(k=i+1;k<=n;k++)
        {
            for(col=j+1;col<=m+1;col++)
                a[k][col]-=a[k][j]*a[i][col];

            a[k][j]=0; // abia acum il fac 0
        }

        i++;
        j++;
    }

    for(i=n;i>=1;i--)
    {
        for(j=1;j<=m+1;j++)
        {
            if(abs(a[i][j]) > 0.0001)
            {
                if(j==m+1) // am ajuns la coada si rezulta ca 0 = a[i][j]
                {
                    g<<"Imposibil";
                    return 0;
                }

                sol[j]=a[i][m+1];
                for(k=j+1;k<=m;k++)
                    sol[j]-=sol[k]*a[i][k]; // ii scad pe cei anteriori

                break; // nu mai avansez cu j-ul odata ce am gasit un coeficient nenul
            }
        }
    }

    for(i=1;i<=m;i++)
    {
        g<<fixed<<setprecision(8)<<sol[i]<<" ";
    }
    return 0;
}
