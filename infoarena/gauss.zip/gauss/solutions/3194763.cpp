#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n,e;
double s[301][301], ans[301];

int main()
{
    int i,j,k,l;
    f>>e>>n;
    for(i = 1; i <= e; i++)
    {
        for(j = 1; j <= n + 1; j++)
        {
            f>>s[i][j];
        }
    }
    for(i = 1, j = 1; i <= e, j <= n;)
    {
        for(k = i; k <= e; k++)
        {
            if(s[k][j] != 0) break;
        }
        if(k > e)
        {
            j++;
            continue;
        }
        if(k != i)
        {
            for(l = 1; l <= n; l++)
                swap(s[i][l], s[k][l]);
        }
        for(k = i  +  1; k <= n; k++)
        {
            for(l = n + 1; l >= j; l--)
            {
                s[k][l] -= ((s[k][j] * s[i][l])/s[i][j]);
            }
        }
        i++; j++;
    }
    bool ok = 1;
    for(i = e; i && ok; i--)
    {
        for(j = 1; j <= n + 1; j++)
        {
            if(fabs(s[i][j]) > 0)
            {
                if(j == n + 1)
                {
                    g<<"Imposibil";
                    ok = 0;
                    break;
                }
                ans[j] = s[i][n+1];
                for(k = j + 1; k <= n; k++)
                {
                    ans[j] -= s[i][k] * ans[k];
                }
                ans[j] /= s[i][j];
                break;
            }
        }
    }
    if(ok)
    {
        for(i = 1; i <= n; i++)
        {
            g<<fixed<<setprecision(8)<<ans[i] * 1.0<<" ";
        }
    }
    return 0;
}
