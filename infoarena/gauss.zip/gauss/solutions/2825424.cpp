#include <bits/stdc++.h>
#define eps 0.0000001
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int dim=500;

int n,m;
double v[dim][dim];

void swap_linii(int a,int b){
    for(int j=1;j<=m+1;j++){
        swap(v[a][j],v[b][j]);
    }
}

bool nenul(double x){
    return !(x<eps && x>-eps);
}

signed main(){
        fin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m+1;j++){
            fin>>v[i][j];
        }
    }
    if(n<m){
        fout<<"Imposibil";
        return 0;
    }
    for(int i=1;i<=m;i++){
        int retine=0;
        for(int j=i;j<=n;j++){
            if(nenul(v[j][i])){
                retine=j;
                break;
            }
        }
        if(!retine){
            fout<<"Imposibil";
            return 0;
        }
        swap_linii(i,retine);
        double cnst=v[i][i];
        for(int j=1;j<=m+1;j++){
            v[i][j]/=cnst;
        }
        for(int l=i+1;l<=n;l++){
            double cnst=v[l][i];
            for(int j=1;j<=m+1;j++){
                v[l][j]-=v[i][j]*cnst;
            }
        }
        for(int l=i-1;l>=1;l--){
            double cnst=v[l][i];
            for(int j=1;j<=m+1;j++){
                v[l][j]-=v[i][j]*cnst;
            }
        }
    }
    for(int i=m+1;i<=n;i++){
        if(!nenul(v[i][m+1])){
            fout<<"Imposibil";
            return 0;
        }
    }
    for(int i=1;i<=m;i++){
        fout<<fixed<<setprecision(10)<<v[i][m+1]<<' ';
    }
}
