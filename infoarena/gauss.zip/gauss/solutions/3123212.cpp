#include <fstream>
#include <iomanip>

#define EPS (double)(1e-3)

using namespace std;

ifstream cin ("gauss.in");
ofstream cout ("gauss.out");

const int N = 330;
long double a[N + 1][N + 1], res[N + 1];

int n, m;

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m + 1; ++j)
            cin >> a[i][j];
    int i, j;
    i = j = 1;
    while (i <= n && j <= m)
    {
        int k = i;
        for (; k <= n; ++k)
            if (a[k][j] < -EPS || a[k][j] > EPS)
                break;
        if (k == n + 1)
        {
            ++j;
            continue;
        }
        if (k != i)
            for (int l = 1; l <= m + 1; ++l)
                swap (a[k][l], a[i][l]);
        a[i][j] = 1;
        for (int l = j + 1; l <= m + 1; ++l)
            a[i][l] = a[i][l] / a[i][j];
        for (int l = i + 1; l <= n; ++l)
        {
            long double coef = a[l][j];
            for (int col = j + 1; col <= m + 1; ++col)
                a[l][col] -= a[l][j] * a[i][col];
            a[l][j] = 0;///scadem linia i * coef, astfel incat asta sa iasa zero
        }
        ++i;
        ++j;
    }
    for (i = n; i >= 1; --i)
        for (j = 1; j <= m + 1; ++j)
                if (a[i][j] > EPS || a[i][j] < -EPS)
                {
                    if (j == m + 1)
                    {
                        cout << "Imposibil";
                        return 0;
                    }
                    res[j] = a[i][m + 1];
                    for (int l = j + 1; l <= m; ++l)
                        res[j] -= res[l] * a[i][l];
                    break;
                }
        for (int i = 1; i <= m; ++i)
            cout << setprecision(10) << fixed << res[i] << " ";
    return 0;
}
