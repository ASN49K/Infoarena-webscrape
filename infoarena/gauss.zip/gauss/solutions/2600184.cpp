#include <iostream>
#include <iomanip>
#include <cstdio>
#include <algorithm>

using namespace std;

typedef long double ld;
const int N=300+7;
int n;
int m;
ld a[N][N];
ld ans[N];

int main()
{
        freopen ("gauss.in","r",stdin);
        freopen ("gauss.out","w",stdout);

        scanf("%d%d",&n,&m);
        for (int i=1;i<=n;i++)
        {
                for (int j=1;j<=m+1;j++)
                {
                        int x;
                        scanf("%d",&x);
                        a[i][j]=x;
                }
        }
        int i=1;
        int j=1;
        while (i<=n && j<=m)
        {
                int k=i;
                while (a[k][j]==0 && k+1<=n)
                {
                        k++;
                }
                if (a[k][j]==0)
                {
                        j++;
                        continue;
                }
                for (int it=j;it<=m+1;it++)
                        swap(a[i][it],a[k][it]);
                ld dv=a[i][j];
                for (int it=j;it<=m+1;it++)
                        a[i][it]/=dv;
                for (int k=i+1;k<=n;k++)
                {
                        ld x=-a[k][j];
                        for (int it=j;it<=m+1;it++)
                                a[k][it]+=x*a[i][it];
                }
                i++;
                j++;
        }
        for (int i=n;i>=1;i--)
        {
                int j=1;
                while (a[i][j]==0 && j+1<=m)
                {
                        j++;
                }
                if (fabs(a[i][j])<=1e-14 && fabs(a[i][m+1])>1e-14)
                {
                        cout<<"Imposibil\n";
                        return 0;
                }
                ans[j]=a[i][m+1];
                for (int it=j+1;it<=m;it++)
                        ans[j]-=ans[it]*a[i][it];
        }
        for (int j=1;j<=m;j++)
                cout<<fixed<<setprecision(10)<<ans[j]<<" ";
        cout<<"\n";
}
