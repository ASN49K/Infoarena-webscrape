#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <climits>
#include <iomanip>
#include <cmath>

#define MOD 666013
#define INT_MAX 1000000000

using namespace std ;

ifstream cin ("gauss.in") ;
ofstream cout ("gauss.out") ;

double mm[309][309], val[309] ;

int main()
{
    int n, m ;

    cin >> n >> m ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= m + 1 ; e ++)
            cin >> mm[f][e] ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = f + 1 ; e <= n ; e ++)
        {
            double coef = mm[e][f] / mm[f][f] ;

            for(int i = f ; i <= m + 1 ; i ++)
                mm[e][i] -= coef * mm[f][i] ;
        }

    for(int f = n, e = m ; f ; f --, e --)
    {
        val[e] = mm[f][m + 1] / mm[f][e] ;

        for(int i = f - 1 ; i ; i --)
            mm[i][m + 1] -= val[e] * mm[i][e] ;
    }

    for(int f = 1 ; f <= m ; f ++)
        cout << fixed << setprecision(8) << val[f] << " " ;

    return 0 ;
}
/// 1990


