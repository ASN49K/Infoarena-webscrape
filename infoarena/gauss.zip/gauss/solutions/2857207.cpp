#include <fstream>
#include <vector>
#include <iomanip>

#define MOD 1999999973
#define EPSILON 0.000001

using namespace std ;

ifstream cin ("gauss.in") ;
ofstream cout ("gauss.out") ;

int n, m ;

double v[309][309], x[309], aux[309][309] ;

void verifica()
{
    for(int f = 1 ; f <= n ; f ++)
    {
        for(int e = 1 ; e <= m ; e ++)
        {
            aux[f][m + 1] -= aux[f][e] * x[e] ;
        }
    if(aux[f][m + 1] > EPSILON || aux[f][m + 1] < EPSILON * -1)
    {
       cout << "Imposibil" ;

       exit(0) ;
    }
    }
}

int main()
{
    cin >> n >> m ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= m + 1 ; e ++)
            cin >> v[f][e] ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= m + 1 ; e ++)
            aux[f][e] = v[f][e] ;

    for(int f = 2 ; f <= n ; f ++)
    {
        if(v[f - 1][f - 1] < EPSILON && v[f - 1][f - 1] > EPSILON * -1)
        {
            for(int e = f + 1 ; e <= n ; e ++)
                if(v[e][f - 1] < EPSILON && v[e][f - 1] > EPSILON * -1)
            {
                swap(v[f - 1], v[e]) ;
                break ;
            }
        }

        for(int e = f ; e <= n ; e ++)
        {
            double aux = v[e][f - 1] / v[f - 1][f - 1] ;

            for(int i = f - 1 ; i <= m + 1 ; i ++)
                v[e][i] -= v[f - 1][i] * aux ;
        }
    }

    for(int f = n, g = m ; f ; f --, g --)
    {
        for(int e = 1 ; e <= m ; e ++)
            if(v[f][e] >= EPSILON || v[f][e] <= EPSILON * -1)
        {
            v[f][m + 1] /= v[f][e] ;

            x[e] = v[f][m + 1] ;

            for(int i = 1 ; i < f ; i ++)
                v[i][m + 1] -= x[e] * v[i][e], v[i][e] = 0 ;
            break ;
        }
    }

    verifica() ;

    for(int f = 1 ; f <= m ; f ++)
        cout << fixed << setprecision(10) << x[f] << " " ;

    return 0 ;
}



