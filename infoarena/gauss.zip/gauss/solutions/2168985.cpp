#include <bits/stdc++.h>
#define INFILE "gauss.in"
#define OUTFILE "gauss.out"
#define EPS 0.0000001
using namespace std;
ifstream in(INFILE);
ofstream out(OUTFILE);
const int NMAX=310;
bool IsNull(double val){
    if(val>-EPS&&val<EPS)
        return true;
    return false;
}
array<array<double,NMAX>,NMAX> A;
array<double,NMAX> X;
int N,M;
void SwapLine(int l1,int l2){
    for(int c=1;c<=M+1;c++){
        swap(A[l1][c],A[l2][c]);
    }
}
void Read(){
    in>>N>>M;
    for(int i=1;i<=N;i++){
        for(int j=1;j<=M+1;j++){
            in>>A[i][j];
        }
    }
}
void AlgoritmulGauss(){
    int i,j;
    i=1;
    j=1;
    while(i<=N&&j<=M){
        int k;
        for(k=i;k<=N;k++){
            if(!IsNull(A[k][j]))
                break;
        }
        if(k==N+1){
            j++;
            continue;
        }
        if(i!=k)
            SwapLine(i,k);
        double val=A[i][j];
        for(int c=j+1;c<=M+1;c++)
            A[i][c]/=val;
        A[i][j]=1;
        for(int u=i+1;u<=N;u++){
            for(int c=j+1;c<=M+1;c++){
                A[u][c]=A[u][c]-A[u][j]*A[i][c];
            }
            A[u][j]=0;
        }
        i++;
        j++;
    }
}

void Rezultat(){
    for(int i=N;i>=1;i--){
        for(int j=1;j<=M+1;j++){
            if(!IsNull(A[i][j])){
                if(j==M+1){
                    out<<"Imposibil\n";
                    return;
                }
                X[j]=A[i][M+1];
                for(int k=j+1;k<=M;k++){
                    X[j]-=X[k]*A[i][k];
                }
                break;
            }
        }
    }
    for(int i=1;i<=M;i++){
        out<<fixed<<setprecision(8)<<X[i]<<" ";
    }
    out<<"\n";

}

int main(){
    Read();
    AlgoritmulGauss();
    Rezultat();
    return 0;
}
