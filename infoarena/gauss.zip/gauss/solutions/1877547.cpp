#include <bits/stdc++.h>
using namespace std;
//#define EPS 0.000000001
int p[303],n,m,i,ii,j;
double a[303][303],sol[303],r, EPS=1e-10,pp;
double modul(double x)
{
    if(x<0)return -x;
    return x;
}
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&m,&n);
    for(i=1;i<=m;i++)
        for(j=1;j<=n+1;j++)
        scanf("%lf",&a[i][j]);
    for(i=1;i<=m;i++)
    {
        p[i]=0;
        for(j=1;j<=n+1;j++)
        {
            if(modul(a[i][j])>EPS)
            {
                p[i]=j;
                break;
            }
        }
        if(p[i]==n+1){printf("Imposibil\n");return 0;}
        if(p[i]==0)continue;

            for(ii=1;ii<=m;ii++)
            {
                if(ii!=i&&modul(a[ii][p[i]])>EPS)
                {
                    r=(double)a[ii][p[i]]/a[i][p[i]];
                    for(j=1;j<=n+1;j++)
                        a[ii][j]=(double)a[ii][j]-a[i][j]*r;
                }
            }

    }
    for(i=1;i<=m;i++)
    {
        if(p[i])sol[p[i]]=(double)a[i][n+1]/a[i][p[i]];
    }
    for(i=1;i<=n;i++)
    {
        printf("%.10lf ",sol[i]);
    }
    return 0;
}
