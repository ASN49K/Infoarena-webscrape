#include<bits/stdc++.h>
using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");
double a[400][400],x[400];
int n,m;
double eroare=1e-7;
int main()
{in>>n>>m;

for(int i=1;i<=n;i++)
for(int j=1;j<=m+1;j++)
in>>a[i][j];

int i=1,j=1;
while(i<=n&&j<=m)
{int k=i;
for(k=i;k<=n;k++)
if(a[k][j]>eroare||a[k][j]<-eroare)break;

if(k==n+1){j++;continue;}
if(k!=i)
for(int l=1;l<=m+1;l++)
swap(a[i][l],a[k][l]);

for(int l=j+1;l<=m+1;l++)
a[i][l]/=a[i][j];
a[i][j]=1;

for(int l=i+1;l<=n;l++)
{for(int u=j+1;u<=m+1;u++)
a[l][u]-=a[l][j]*a[i][u];
a[l][j]=0;

}
i++;j++;
}

 for(int i=n;i>0;i--)
 for(int j=1;j<=m+1;++j)
 if(a[i][j]>eroare||a[i][j]<-eroare)
 {
  if(j==m+1)
  {out<<"Imposibil";
  return 0;}
   x[j]=a[i][m+1];
   for(int k=j+1;k<=m;k++)
 x[j]-=x[k]*a[i][k];

break;
 }

    for(int i=1;i<=m;i++)
    out<<setprecision(8)<<x[i]<<" ";
    out<<endl;
}
