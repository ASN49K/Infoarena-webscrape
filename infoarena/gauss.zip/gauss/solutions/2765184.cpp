#include <bits/stdc++.h>

using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
long double a[319][310],eps,sol[310];
int n,m,i,j,poz,k,h;
int main()
{
    f>>n>>m;
    eps=0.0000001;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m+1;j++)
        {
            f>>a[i][j];
        }
    }
    i=1;
    j=1;
    while ((i<=n)&&(j<=m))
    {
        poz=0;
        for (k=i;k<=n;k++)
        {
            if (a[k][j]<-eps||a[k][j]>eps)
            {
                poz=k;
                break;
            }
        }
        if (poz==0)
        {
            j++;
            continue;
        }
        if (poz!=i)
        {
            for (j=1;j<=m+1;j++)
            {
                swap(a[i][j],a[k][j]);
            }
        }
        for (k=j+1;k<=m+1;k++)
        {
            a[i][k]=a[i][k]/a[i][j];
        }
        a[i][j]=1;
        for (k=i+1;k<=n;k++)
        {
            for (h=m+1;h>=j;h--)
            {
                a[k][h]=a[k][h]+(-a[k][j])*a[i][h];
            }
        }
        i++;
        j++;
    }
    for (i=n;i>0;i--)
    {
        for (j=1;j<=m+1;j++)
        {
            if ((a[i][j]<-eps)||(a[i][j]>eps))
            {
                if (j==m+1)
                {
                    g<<"Imposibil"<<'\n';
                    return 0;
                }
                sol[j]=a[i][m+1];
                for (k=j+1;k<=m;k++)
                {
                    sol[j]=sol[j]-sol[k]*a[i][k];
                }
                break;
            }
        }
    }
    for (i=1;i<=m;i++)
    {
        g<<fixed<<setprecision(10)<<sol[i]<<" ";
    }
    return 0;
}
