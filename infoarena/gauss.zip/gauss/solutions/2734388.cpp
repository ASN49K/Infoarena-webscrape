#include <fstream>
#include <iomanip>

using namespace std;

const int N = 300;

int nl, nc;
double v[N + 1][N + 2];

inline void interschimb(int i1, int i2) {
    for (int j = 1; j <= nc + 1; ++j)
        swap(v[i1][j], v[i2][j]);
}

inline bool exista(int i1) {
    for (int i = i1 - 1; i >= 1; --i)
        if (v[i][i1])
            return true;
    return false;
}

int main() {
    ifstream in("gauss.in");
    ofstream out("gauss.out");

    in >> nl >> nc;
    for (int i = 1; i <= nl; ++i)
        for (int j = 1; j <= nc + 1; ++j)
            in >> v[i][j];
    double m;        
    for (int i1 = 1; i1 <= nl - 1; ++i1) {
        //swap
        if (!v[i1][i1])
            for (int i2 = i1 + 1; i2 <= nl; ++i2)
                if (v[i2][i1])
                    interschimb(i1, i2);
        //scadere
        for (int i2 = i1 + 1; i2 <= nl; ++i2)
            if (v[i2][i1]) {
                m = v[i2][i1] / v[i1][i1];
                for (int j = i1; j <= nl; ++j)
                    v[i2][j] -= m * v[i1][j];
                v[i2][nc + 1] -= m * v[i1][nc + 1];
            }
    }
    for (int i1 = nl; i1 > 1; --i1) {
        if (!v[i1][i1])
            continue;
        for (int i2 = i1 - 1; i2 >= 1; --i2)
            if (v[i2][i1]) {
                m = v[i2][i1] / v[i1][i1];
                v[i2][i1] = 0;
                v[i2][nc + 1] -= m * v[i1][nc + 1];
            }
    }
        for (int i = 1; i <= nl; ++i)
            out << fixed << setprecision(10) << v[i][nc + 1] / v[i][i] << ' ';
        for (int i = 1; i <= nc - nl; ++i)
            out << fixed << setprecision(10) << (double)0 << ' ';

    in.close();
    out.close();
    return 0;
}