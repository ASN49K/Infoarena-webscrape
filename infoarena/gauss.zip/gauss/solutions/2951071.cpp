#include <bits/stdc++.h>

using namespace std;
const int N = 305;
using ld = long double;
ld A[N][N], res[N];
const ld eps = 1.0e-10;
bool gauss(ld A[][N], int n, int m, ld *res) {
    vector <int> found(m, -1);
    for(int i = 0, j = 0; i < n && j < m; j++) {
        int r = i;
        for(int c = r; c < n; c++)
            if(abs(A[c][j]) > abs(A[r][j]))
                r = c;
        if(abs(A[r][j]) < eps) continue;
        for(int jj = 0; jj <= m; jj++)
            swap(A[r][jj], A[i][jj]);
        found[j] = i;
        for(int ii = 0; ii < n; ii++) if(ii != i) {
            ld coef = A[ii][j] / A[i][j];
            for(int jj = j; jj <= m; jj++)
                A[ii][jj] -= coef * A[i][jj];
        }
        i++;
    }
    for(int j = 0; j < m; j++)
        if(found[j] != -1)
            res[j] = A[found[j]][m] / A[found[j]][j];
        else res[j] = 0;
    for(int i = 0; i < n; i++) {
        ld sum = 0;
        for(int j = 0; j < m; j++)
            sum += A[i][j] * res[j];
//        cout << "Line " << i << " sum " << sum << " expected " << A[i][m] << "\n";
        if(abs(sum - A[i][m]) >= eps) return false;
    }
    return true;
}

int main()
{
    const string fn = "gauss";
    ifstream cin(fn + ".in");
    ofstream cout(fn + ".out");
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < n; i++)
        for(int j = 0; j <= m; j++)
            cin >> A[i][j];
    if(gauss(A, n, m, res)) {
        cout << fixed << setprecision(10);
        for(int i = 0; i < m; i++)
            cout << res[i] << " ";
    } else cout << "Imposibil\n";
    return 0;
}
