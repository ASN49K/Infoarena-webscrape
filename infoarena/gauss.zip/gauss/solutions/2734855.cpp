#include <bits/stdc++.h>
#define EPS 0.00000001
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int N, M;

double a[305][305], aux;

double vals[305];

int main()
{
    fin >> N >> M;

    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M + 1; j++)
            fin >> a[i][j];

    int li = 1, co = 1;

    while(li <= N && co <= M)
    {
        int i;

        for(i = li; i <= N; i++)
            if(a[i][co] < -EPS || a[i][co] > EPS)
                break;

        if(i == N + 1)
        {
            co++;
            continue;
        }

        if(i != li)
        {
            for(int j = 1; j <= M + 1; j++)
            {
                aux = a[i][j];
                a[i][j] = a[li][j];
                a[li][j] = aux;
            }
        }

        for(int j = li + 1; j <= M + 1; j++)
            a[li][j] /= a[li][co];
        a[li][co] = 1;

        for(int i = li + 1; i <= N; i++)
        {
            for(int j = co + 1; j <= M + 1; j++)
                a[i][j] -= a[i][co] * a[li][j];
            a[i][co] = 0;
        }

        ++li;
        ++co;
    }

    for(int i = N; i >= 1; i--)
        for(int j = 1; j <= M + 1; j++)
            if(a[i][j] > EPS || a[i][j] < -EPS)
    {
        if(j == M + 1)
        {
            fout << "Imposibil";
            return 0;
        }

        vals[j] = a[i][M + 1];

        for(int t = j + 1; t <= M; t++)
            if(a[i][t] > -EPS || a[i][t] < EPS)
                vals[j] -= vals[t] * a[i][t];

        break;
    }

    for(int i = 1; i <= M; i++)
        fout << fixed << setprecision(10) << vals[i] << ' ';

    return 0;
}
