//https://infoarena.ro/problema/gauss

//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NRMAX = 300;
const double EPS = 1e-8;
const double ZERO = 0.0000000000;

double mat[NRMAX + 5][NRMAX + 5];

int main()
{
	int n, m, i, j;
	vector <int> rez;

	fin >> n >> m;

	for (i = 1; i <= n; ++i)
	{
		for (j = 1; j <= m + 1; ++j)
		{
			fin >> mat[i][j];
			//cout << mat[i][j] << " ";
		}
		//cout << "\n";
	}

	int c, r;
	double rp;
	for (r = 1, c = 1; ((r <= n) && (c <= m)); ++r, ++c)
	{
		//cout << r << " " << c << "\n";
		if (abs(mat[r][c]) <= EPS) // daca e aprox 0
		{
			for (i = r + 1; i <= n; ++i)
				if (!(abs(mat[i][c]) <= EPS)) 
					break;

			if (i > n)
			{
				rez.push_back(0);
				continue;
			}
			else
				swap(mat[r], mat[i]);
		}

		for (i = 1; i <= n; ++i)
		{
			if (i == r)
				continue;

			rp = mat[i][c] / mat[r][c];

			for (j = 1; j <= m + 1; ++j)
				mat[i][j] -= rp * mat[r][j];
		}

		rez.push_back(r);
	}

	for (; r <= n; ++r) // fiecare linie dupa ce am terminat de redus
	{
		if (!(abs(mat[i][m + 1]) <= EPS))
		{
			fout << "Imposibil";
			return 0;
		}
	}

	fout << setprecision(10) << fixed;
	i = 1;
	for (int x : rez)
	{
		fout << (x ? mat[x][m + 1] / mat[x][i] : ZERO) << " ";
		//cout << mat[x][m + 1] << " " << mat[x][i] << "\n";
		++i;
	}
	for (; i <= m; ++i)
	{
		fout << ZERO << " ";
	}

	return 0;
}