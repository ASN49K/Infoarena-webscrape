#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMAX = 300;
const int MMAX = 300;
const double EPS = 1e-8;

int n, m;
vector<double> A[NMAX], x;
vector<int> p;

bool isEqual(double a, double b) {
	if(b == 0) {
		return -EPS < a && a < EPS;
	} else {
		if(b > 0) {
			return (1 - EPS) * b < a && a < (1 + EPS) * b;
		} else {
			return (1 - EPS) * b > a && a > (1 + EPS) * b;
		}
	}
}

int main() {
	ios_base :: sync_with_stdio(false);

	fin >> n >> m;
	for(int i = 0; i < n; i++) {
		for(int j = 0; j <= m; j++) {
			int a;
			fin >> a;
			A[i].emplace_back(a);
		}
		A[i].resize(m + 1);
	}
	p.assign(m, -1);
	x.assign(m, 0);

	for(int i = 0, j = 0; i < n && j < m; i++, j++) {
		int piv = i;
		for(int k = i; k < n; k++) {
			if(abs(A[piv][j]) < abs(A[k][j])) {
				piv = k;
			}
		}

		if(isEqual(A[piv][j], 0) == 0) {
			cout << i << " " << piv << '\n';
			A[i].swap(A[piv]);
			p[j] = i;

			for(int k = 0; k < n; k++) {
				if(k != i) {
					double a = -A[k][j] / A[i][j];

					for(int l = j; l < m + 1; l++) {
						A[k][l] += A[i][l] * a;
					}
				}
			}
		}
	}

	for(int j = 0; j < m; j++) {
		if(p[j] != -1) {
			x[j] = A[p[j]][m] / A[p[j]][j];
		}
	}

	for(int i = 0; i < n; i++) {
		double sum = 0;
		for(int j = 0; j < m; j++) {
			sum += A[i][j] * x[j];
		}
		if(isEqual(sum, A[i][m]) == 0) {
			fout << "Imposibil\n";
			return 0; // CRY??
		}
	}

	for(int j = 0; j < m; j++) {
		fout << fixed << setprecision(10) << x[j] << " ";
	}
	fout << '\n';

	return 0;
}