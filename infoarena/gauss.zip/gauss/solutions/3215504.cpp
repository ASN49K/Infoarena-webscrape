
#include <fstream>
#include <iomanip>
using namespace std;
ifstream cin("gauss.in");
ofstream cout("gauss.out");
int n,m;
#define EPS 0.0000001
double A[310][310];
double X[310];
int main()
{
    cin>>n>>m;
    cout<<setprecision(11)<<fixed;
    for(int i=1;i<=n;i++)
      for(int j=1;j<=m+1;j++)
        cin>>A[i][j];
    int i=1,j=1,k;
    while(i<=n && j<=m)
    {
        for(k=i;k<=n;k++)
          if(A[k][j]<-EPS || A[k][j]>EPS)
              break;
        if(k==n+1)
           {
               j++;
               continue;
           }
        if(k!=i)
          for(int d=1;d<=m+1;d++)
             swap(A[k][d],A[i][d]);
        for(int l=j+1;l<=m+1;l++)
           A[i][l]=A[i][l]/A[i][j];
        A[i][j]=1;

        for(int u=i+1;u<=n;u++)
        {
             for(int l=j+1;l<=m+1;l++)
               A[u][l]=A[u][l]-A[i][l]*A[u][j];
            A[u][j]=0;
        }
        i++;
        j++;
    }
    for(int i=n;i>=1;i--)
      for(int j=1;j<=m+1;j++)
          if(A[i][j]>EPS || A[i][j]<-EPS)
          {
              if(j==m+1)
              {
                  cout<<"IMPOSIBIL";
                  return 0;
              }
              X[j]=A[i][m+1];
              for(int d=j+1;d<=m;d++)
                 X[j]=X[j]-X[d]*A[i][d];
            break;
          }
    for(int i=1;i<=m;i++)
      cout<<X[i]<<" ";
    return 0;
}
