#include <iostream>
#include <fstream>
#include <iomanip>
#include <math.h>

int n,m;
long double v[350][350];
int exist[350];
long double sol[350];
int place;

void multR(int i, int j, int p)
{
  if(v[i][j]!=0)
  {
    long double mult=-v[i][j]/v[p][j];
    for(int x=j;x<=n;x++)
      v[i][x]=v[i][x]+mult*v[p][x];
  }
}

void printt()
{
  for(int i=0;i<m;i++)
  {
    for(int j=0;j<=n;j++)
      printf("%llf ",v[i][j]);
    printf("\n");
  }
  printf("\n");
}

int main()
{
  freopen("gauss.in","r",stdin);
  freopen("gauss.out","w",stdout);
  scanf("%d %d",&m,&n);
  for(int i=0;i<m;i++)
    for(int j=0;j<=n;j++)
      scanf("%llf",&v[i][j]);
  for(int j=0;j<n;j++)
    for(int i=j;i<m;i++)
      if(j<m && v[i][j]!=0)
      {
        exist[j]=place;
        std::swap(v[i],v[place]);
        place++;
        break;
      }
  for(int j=0;j<n;j++)
  {
    if(exist[j]==-1)continue;
    int p=exist[j];
    for(int i=p+1;i<m;i++)
      multR(i,j,p);
  }
//  printt();
  for(int j=m-1;j>=0;j--)
  {
    int p = 0;
    while(v[j][p]<=1e-10 &&v[j][p]>=-1e-10 &&p<n)p++;
    if(p==n&& (v[j][n]>1e-10 || v[j][n]<-1e-10))
    {
      printf("Imposibil");
      return 0;
    }
    if(p==n) continue;
    long double solv = v[j][n];
    for(int i=p+1;i<n;i++)
      solv-=v[j][i]*sol[i];
    sol[p]=solv/v[j][p];
  }
  std::cout<<std::setprecision(10)<<std::fixed;
  for(int j=0;j<n;j++)
  {
    if(exist[j]!=-1)
      std::cout<<sol[j]<<" ";
    else
      std::cout<<0.0<<" ";
  }
}
