#include <iostream>
#include <cstdio>
#define N 305
#define EPS 0.0000001

using namespace std;

int n, m;
double ec[N][N], sol[N];

void citire()
{
    scanf("%d %d\n", &n, &m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            scanf("%lf ", &ec[i][j]);
}

void determinant()
{
    int i=1, j=1, k;

    while(i<=n && j<=m)
    {
        k=i;
        while(ec[k][j]>=-EPS && ec[k][j]<=EPS && k<=n)
            k++;

        if(k==n+1)
            j++;
        else
        {
            if(k!=i)
                for(int l=1;l<=m+1;l++)
                {
                    double aux=ec[i][l];
                    ec[i][l]=ec[k][l];
                    ec[k][l]=aux;
                }
            for(int l=j+1;l<=m+1;l++)
                ec[i][l]=ec[i][l]/ec[i][j];
            ec[i][j]=1;

            for(int u=i+1;u<=n;u++)
            {
                for(int l=j+1;l<=m+1;l++)
                    ec[u][l]=ec[u][l]-ec[u][j]*ec[i][l];
                ec[u][j]=0;
            }
            i++, j++;
        }
    }
}

void afisare()
{
    for(int i=1;i<=m;i++)
        printf("%.8lf ", sol[i]);
}

int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    citire();
    determinant();
    for(int i=n;i>=1;i--)
    {
        int j=1;
        while(ec[i][j]>=-EPS && ec[i][j]<=EPS && j<=m+1)
            j++;

        if(j==m+1)
        {
            printf("Imposibil");
            return 0;
        }

        sol[j]=ec[i][m+1];
        for(int k=j+1;k<=m;k++)
            sol[j]=sol[j]-sol[k]*ec[i][k];
    }
    afisare();
    return 0;
}
