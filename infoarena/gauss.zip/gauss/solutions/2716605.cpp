#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin("gauss.in");
ofstream cout("gauss.out");

const int NMAX = 300;
const double EPS = 1e-12;

int N, M;
double sys[NMAX + 2][NMAX + 2], res[NMAX + 2];

bool NotNull(double x) {
    return x < -EPS || x > EPS;
}

int main() {
    cin >> N >> M;

    for(int i = 1; i <= N; i++) {
        for(int j = 1; j <= M + 1; j++) {
            cin >> sys[i][j];
        }
    }

    int l = 1, c = 1;

    while(l <= N && c <= M) {
        int k = -1;

        for(int i = l; i <= N; i++) {
            if(NotNull(sys[i][c])) {
                k = i;
                break;
            }
        }

        if(k == -1) {
            c++;
            continue;
        }

        for(int j = 1; j <= M + 1; j++) {
            swap(sys[l][j], sys[k][j]);
        }

        for(int j = c + 1; j <= M + 1; j++) {
            sys[l][j] /= sys[l][c];
        }
        sys[l][c] = 1.0;

        for(int i = l + 1; i <= N; i++) {
            for(int j = c + 1; j <= M + 1; j++) {
                sys[i][j] -= sys[l][j] * sys[i][c];
            }

            sys[i][c] = 0.0;
        }

        l++, c++;
    }

    for(int i = N; i >= 1; i--) {
        for(int j = 1; j <= M + 1; j++) {
            if(NotNull(sys[i][j])) {
                if(j == M + 1) {
                    cout << "Imposibil\n";
                    return 0;
                }

                res[j] = sys[i][M + 1];
                for(int k = j + 1; k <= M; k++) {
                    res[j] -= sys[i][k] * res[k];
                }

                break;
            }
        }
    }

    for(int i = 1; i <= M; i++) {
        cout << fixed << setprecision(10) << res[i] << ' ';
    }

    return 0;
}
