#include <bits/stdc++.h>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
#endif  // ST_DIO

const double ERR = 1e-11;
double rez[302], rasp[302];
int n, m, i, j, ord[302];
double ec[302][302];

static inline double Modul(double a) {
    return (0 > a ? -a : a);
}

int main() {
    if(ST_DIO) ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m;
    for(i = 1; i <= n; i++) {
        for(j = 1; j <= m; j++) fin >> ec[i][j];
        fin >> rez[i];
    }

    i = j = 1;
    while(i <= n && j <= m) {
        int poz = i;
        for(int ii = i; ii <= n; ii++) {
            if(Modul(ec[poz][j]) < Modul(ec[ii][j])) {
                poz = ii;
            }
        }

        if(ERR <= Modul(ec[poz][j])) {
            for(int jj = 1; jj <= m; jj++) {
                swap(ec[i][jj], ec[poz][jj]);
            }
            swap(rez[i], rez[poz]);
            ord[j] = i;

            for(int ii = 1; ii <= n; ii++) {
                if(ii != i) {
                    double z = ec[ii][j] / ec[i][j];
                    rez[ii] -= rez[i] * z;
                    for(int jj = j; jj < m; jj++) ec[ii][jj] -= ec[i][jj] * z;
                }
            }

            i++;
        }
        j++;
    }

    for(j = 1; j <= m; j++) {
        if(0 != ord[j]) rasp[j] = rez[ord[j]] / ec[ord[j]][j];
    }

    for(i = 0; i < n; i++) {
        double sum = 0;
        for(j = 0; j < m; j++) sum += rasp[j] * ec[i][j];
        if(ERR < Modul(sum - rez[i])) {
            fout << "Imposibil";
            return 0;
        }
    }

    for(i = 1; i <= m; i++) {
        fout << setprecision(10) << fixed << rasp[i] << " ";
    }

    return 0;
}
