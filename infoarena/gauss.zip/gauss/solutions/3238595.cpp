#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");



const double eps = 0.00000000001;

int n,m;

double a[305][305];
double sol[305];

bool is_reduced(double x)
{
    return x>=-eps && x<=eps;
}



int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>a[i][j];

    for(int k = 1;k<=n;k++)
    {
        int fr = k;
        for(;fr<=n && is_reduced(a[fr][k]);fr++);
        if(fr!=k && fr!=n+1)
            for(int l = 1;l<=m+1;l++) swap(a[k][l],a[fr][l]);
        if(is_reduced(a[k][k])==false)
            for(int l = k +1;l<=m+1;l++)
                a[k][l]/=a[k][k];

        if(is_reduced(a[k][k]))
            continue;

        a[k][k]=1;
        for(int x = k+1;x<=n;x++)
            if(!is_reduced(a[x][k])){
                double rap = a[x][k]/a[k][k];
                for(int l = k;l<=m+1;l++)
                    a[x][l]-=a[k][l]*rap;
                a[x][k] = 0;
            }
    }
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m+1;j++)
            fout<<a[i][j]<<' ';
        fout<<'\n';
    }
    fout<<'\n';*/
    for(int i=n;i>=1;i--)
    {
        int j;
        for(j = 1;j<=m+1 && is_reduced(a[i][j]);j++);
        if(j == m + 2) sol[i] = 0;
        if(j == m + 1){fout<<"Imposibil";return 0;}
        sol[i] = a[i][m+1];
        for(int x = i-1;x>=1;x--)
            a[x][m+1] -= sol[i] * a[x][j];
    }
    fout<<fixed<<setprecision(10);
    for(int i=1;i<=m;i++)
        fout<<sol[i]<<' ';


}
