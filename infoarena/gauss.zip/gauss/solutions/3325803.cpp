#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");
const double EROARE = 1e-7;
int n, m, i, j, ord[302];
vector<double> ec[302];
double rasp[302];

static inline double Modul(double a) {
    return (a < 0 ? -a : a);
}

int main() {
    //ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m;
    for(i = 0; i < n; i++) {
        ord[i] = -1;
        ec[i].resize(m + 1);
        for(j = 0; j <= m; j++) fin >> ec[i][j];
    }

    i = 0;
    j = 0;
    while(i < n && j < m) {
        int poz = i;
        for(int ii = i; ii < n; ii++){
            if(Modul(ec[ii][j]) > Modul(ec[poz][j])) poz = ii;
        }

        if(Modul(ec[poz][j]) >= EROARE) {
            ec[i].swap(ec[poz]);
            ord[j] = i;

            for(int ii = 0; ii < n; ii++) {
                if(ii != i) {
                    double z = ec[ii][j] / ec[i][j];
                    for(int jj = j; jj <= m; jj++) ec[ii][jj] -= ec[i][jj] * z;
                }
            }

            i++;
        }
        j++;
    }

    for(j = 0; j < m; j++) {
        if(ord[j] != -1) rasp[j] = ec[ord[j]][m] / ec[ord[j]][j];
    }

    for(i = 0; i < n; i++) {
        double sum = 0;
        for(j = 0; j < m; j++) sum += rasp[j] * ec[i][j];
        if(Modul(sum - ec[i][m]) > EROARE) {
            fout << "Imposibil";
            return 0;
        }
    }

    for(i = 0; i < m; i++) fout << setprecision(10) << fixed << rasp[i] << " ";

    return 0;
}
