#include <algorithm>
#include <stack>
#include <queue>
#include <deque>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <cstring>
#include <iomanip>

using namespace std;

//#include <iostream>
#include <fstream>

//ifstream cin ("input.in");
//ofstream cout ("output.out");

ifstream cin ("gauss.in");
ofstream cout ("gauss.out");

static const double lim = 0.0000000001;
static const int NMAX = 305;

int n, m;
double ans[NMAX];
double v[NMAX][NMAX];

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);

	cin>>n>>m;
	for ( int i = 1; i <= n; ++i ) {
		for ( int j = 1; j <= m+1; ++j ) {
			cin>>v[i][j];
		}
	}

	int i = 1, j = 1;

	while ( i <= n && j <= m ) {
		bool swapped = false;
		int x;

		for ( x = i; x <= n; ++x ) {
			if ( abs(v[x][j]) >= lim ) {
				swapped = true;
				break;
			} 
		}

		if ( swapped ) {
			for ( int k = j; k <= m+1; ++k ) {
				swap(v[i][k], v[x][k]);
			}

			for ( int k = j; k <= m+1; ++k ) {
				v[i][k] /= v[i][j];
			}

			for ( int u = i+1; u <= n; ++u ) {
				for ( int k = j; k <= m+1; ++k ) {
					v[u][k] -= v[u][j]*v[i][k];
				}
			}

			i++;
			j++;

		}
		else {
			j++;
		}
	}

	for ( int i = 1; i <= n; ++i ) {
		for ( int j = 1; j <= m+1; ++j ) {
			if ( abs(v[i][j] >= lim) ) {
				if ( j == m+1 ) {
					cout<<"Impossible";
					return 0;
				}

				ans[j] = v[i][m+1];

				for ( int x = j+1; x <= m; ++x ) {
					ans[j] -= ans[x]*v[i][x];
				}
				break;
			}
		}
	}

	for ( int i = 1; i <= m; ++i ) {
		cout<<fixed<<setprecision(12)<<ans[i]<<" ";
	}
}