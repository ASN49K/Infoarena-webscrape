#include <bits/stdc++.h>

#define MaxN 305
const double EPS = 1e-8;

int N, M, P[MaxN];
double A[MaxN][MaxN], Sol[MaxN];
double Coef;

int main() {
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    scanf("%d%d", &N, &M);

    for (int i=1, j; i<=N; ++i)
        for(j=1; j<=M+1; ++j)
            scanf("%lf", &A[i][j]);

    for (int i=1, j, k; i<=N; ++i) {
        for (j=1; j<=M+1; ++j)
            if (fabs(A[i][j]) > EPS)
                break;

        if (j==M+2) continue;
        if (j==M+1) {
            printf("Imposibil\n");
            return 0;
        }

        P[i] = j;

        for (j=1; j<=N; ++j)
            if (i!=j) {
                Coef = A[j][P[i]] / A[i][P[i]];
                for (k=1; k<=M+1; ++k)
                    A[j][k] -= Coef * A[i][k];
            }
    }

    double x;
    for (int i=1; i<=N; ++i)
        if (P[i])
            Sol[P[i]] = A[i][M+1] / A[i][P[i]];

    for (int i=1; i<=M; ++i)
       printf("%.10f ", Sol[i]);

    return 0;
}
