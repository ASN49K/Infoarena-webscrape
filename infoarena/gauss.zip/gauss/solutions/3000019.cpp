#include <bits/stdc++.h>
using namespace std;
const int NMAX = 300;
const double EPS = 0.00000001;

ifstream fin( "gauss.in" );
ofstream fout( "gauss.out" );

double a[NMAX+1][NMAX+1];
double sol[NMAX+1];
double coef;
int main() {
  int n, m, i, j, lin, col, k;
  fin >> n >> m;
  for( i = 1; i <= n; i++ ) {
    for( j = 1; j <= m + 1; j++ )
      fin >> a[i][j];
  }
  i = 1;
  j = 1;
  while( i <= n && j <= m ) {
    lin = i;
    while( lin <= n && ( -EPS <= a[lin][j] && a[lin][j] <= EPS )  )
      lin++;
    if( lin == n + 1 ) {
      sol[j] = 1.0;
      j++;
    }
    else {
      for( col = 1; col <= m + 1; col++ )
        swap( a[i][col], a[lin][col] );
      for( col = j + 1; col <= m + 1; col++ )
        a[i][col] = double( a[i][col] / a[i][j] );
      a[i][j] = 1;
      for( lin = i + 1; lin <= n; lin++ ) {
        coef = a[lin][j];
        for( col = 1; col <= m + 1; col++ )
          a[lin][col] = a[lin][col] - coef * a[i][col];
      }
      i++, j++;
    }
  }
  bool ok = true;
  for( i = n; i >= 1; i-- ) {
    j = 1;
    while( j <= m && ( -EPS <= a[i][j] && a[i][j] <= EPS ) ) {
      j++;
    }
    if( j == m + 1 && ( a[i][j] > EPS || a[i][j] < -EPS ) )
      fout << "Imposibil\n", ok = false;
    else {
      sol[j] = a[i][m+1];
      for( k = j + 1; k <= m; k++ )
        sol[j] -= sol[k] * a[i][k];
    }
  }
  if( ok ) {
    fout << setprecision( 10 ) << fixed;
    for( j = 1; j <= m; j++ )
      fout << sol[j] << " ";
  }
  return 0;
}
