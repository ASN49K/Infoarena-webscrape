#include <bits/stdc++.h>

using namespace std;

const int nmax = 303;
const double EPS = 1e-10;

double a[nmax][nmax];
int n,m;

void swap_lanes(int i, int j) {
	for(int k = 0; k < m; k++) {
		swap(a[k][i],a[k][i]);
	}
}

double sol[nmax];
bool anything[nmax];

ifstream fin("gauss.in");
ofstream fout("gauss.out");

#define cin fin
#define cout fout

int main()
{
	cin >> n >> m;
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < m + 1; j ++) {
			cin >> a[i][j];
		}
	}
	// int mn = min(n,m);
	int pi = 0, pj = 0;
	for(; pi < n && pj < m; ) {
		int best_p = pi;
		for(int i = pi; i < n; i++) {
			if(abs(a[best_p][pj]) < abs(a[i][pj])) {
				best_p = i;
			}
		}
		if(best_p != pi) {
			swap_lanes(pi,best_p);
		}
		if(abs(a[best_p][pj]) < EPS) {
			anything[pj] = 1;
			pj ++;
			continue;
		}
		for(int i = pi + 1; i < m + 1; i++) {
			a[pi][i] /= a[pi][pj];
		}
		a[pi][pj] = 1;
		for(int i = pi + 1; i < n; i++) {
			for(int j = pj + 1; j < m + 1; j ++) {
				a[i][j] -= a[pi][j] * a[i][pj];
			}
			a[i][pj] = 0;
		}
		pi++;
		pj ++;
	}
	int first_nonzero = n - 1 ;
	while(abs(a[first_nonzero][m]) < EPS) first_nonzero --;
	bool nonzero = false;
	for(int j = 0; j < m; j++) {
		if(abs(a[first_nonzero][j]) > EPS) {
			nonzero = true;
		}
	}
	if(!nonzero) {
		cout << "Imposibil";
		return 0;
	}
	pi = n - 1, pj = m - 1;
	while(abs(a[pi][pj]) < EPS) pi --;

	for(; pi >= 0 && pj >= 0;) {
		sol[pj] = a[pi][m];
		for(int i = pj + 1; i < m; i++) {
			sol[pj] -= sol[i] * a[pi][i];
		}
		pj --;
		pi --;
		while(anything[pj] && pj >= 0) pj --;
	}
	// for(int i =0 ; i < n; i++) {
	// 	for(int j = 0; j < m + 1; j++) {
	// 		cout << a[i][j] <<" ";
	// 	}
	// 	cout<<"\n";
	// }
	for(int i = 0; i < n; i++) {
		cout << fixed << setprecision(8) << sol[i] << " ";
	}
}