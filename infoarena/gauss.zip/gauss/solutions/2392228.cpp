#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n, m;
double necunoscute[305];

class ecuatie{
public:
    double coeficienti[305];
    double rezultat;
};

ecuatie toate_ecuatiile[305];

void punere_pe_pozitie_1(int ind)
{
    for (int i=ind+1; i<=n; ++i)
    {
        if (toate_ecuatiile[ind].coeficienti[i]!=0)
        {
            swap(toate_ecuatiile[ind].coeficienti[ind],toate_ecuatiile[ind].coeficienti[i]);
            return;
        }
    }
}

void reducere(int ind)
{
    double aux=toate_ecuatiile[ind].coeficienti[ind];
    for (int i=ind; i<=m; ++i)
    {
        toate_ecuatiile[ind].coeficienti[i]/=aux;
    }
    toate_ecuatiile[ind].rezultat/=aux;
}

void scadere_coloana(int ind_coloana_descazut, int ind_coloana_scazator)
{
    double dif=toate_ecuatiile[ind_coloana_descazut].coeficienti[ind_coloana_scazator];
    for (int i=ind_coloana_scazator; i<=m; ++i)
    {
        toate_ecuatiile[ind_coloana_descazut].coeficienti[i]-=(dif*toate_ecuatiile[ind_coloana_scazator].coeficienti[i]);
    }
    toate_ecuatiile[ind_coloana_descazut].rezultat-=(dif*toate_ecuatiile[ind_coloana_scazator].rezultat);
}

void afisare()
{
    for (int linie=n-1; linie>0; --linie)
    {
        double rez=toate_ecuatiile[linie].rezultat;
        if (!necunoscute[linie]){
        for (int coloana=m; coloana>linie; --coloana)
        {
            rez-=(necunoscute[coloana]*toate_ecuatiile[linie].coeficienti[coloana]);
        }
        necunoscute[linie]=rez;
        }
        bool ok=false;
        for (int j=m; j>=linie; --j)
        {
            if (necunoscute[j])
                ok=true;
        }
        if (!ok)
        {
            g << "Imposibil";
            return;
        }
    }

    for (int i=1; i<=m; ++i)
        g << setprecision(10)<<fixed<<necunoscute[i] <<' ';
}

int main()
{

    f >> n >> m;
    for (int i=1; i<=n; ++i)
    {
        for (int j=1; j<=m; ++j)
        {
            f >> toate_ecuatiile[i].coeficienti[j];
        }
        f >> toate_ecuatiile[i].rezultat;
    }
    for (int coloana=1; coloana<=m; ++coloana)
    {
        if (toate_ecuatiile[coloana].coeficienti[coloana]==0)
            punere_pe_pozitie_1(coloana);
        if (toate_ecuatiile[coloana].coeficienti[coloana]!=0)
        {
            reducere(coloana);
            for (int alta_coloana=coloana+1; alta_coloana<=n; alta_coloana++)
            {
                scadere_coloana(alta_coloana,coloana);
            }
        }
    }
    necunoscute[m]=toate_ecuatiile[n].rezultat/toate_ecuatiile[n].coeficienti[m];
   /* for (int i=1; i<=n; ++i)
    {
        for (int j=1; j<=m; ++j)
        {
            cout << toate_ecuatiile[i].coeficienti[j] <<' ';
        }
        cout << toate_ecuatiile[i].rezultat << '\n';
    }*/
    afisare();
    return 0;
}
