#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <iomanip>

using namespace std;
ifstream cin("gauss.in");
ofstream cout("gauss.out");
const int NMAX = 305;
const double EPS = 1e-12;
vector<vector<double>> a, aux;
double x[NMAX];
int main()
{
    int n, m, i, j, r, imp = 0, c;
    double coef;
    cin >> n >> m;
    a.resize(n);
    aux.resize(n);
    for(i = 0; i < n; i++)
    {
        a[i].resize(m+1);
        aux[i].resize(m+1);
        for(j = 0; j <= m; j++)
        {
            cin >> a[i][j];
            aux[i][j] = a[i][j];
        }
    }
    for(i = 0, j = 0; i < m && j < n; i++)
    {
        r = j;
        while(r < n && a[r][i] == 0)
            r++;
        if(r == n)
            continue;
        swap(a[j], a[r]);
        coef = a[j][i];
        for(c = i; c <= m; c++)
            a[j][c] /= coef;
        for(r = j + 1; r < n; r++)
        {
            coef = a[r][i];
            for(c = i; c <= m; c++)
            {
                a[r][c] -= coef * a[j][c];
                if(abs(a[r][c]) < EPS)
                    a[r][c] = 0;
            }
        }
        j++;
    }
    for(i = n - 1; i >= 0; i--)
    {
        for(j = 0; j <= m; j++)
        {
            if(abs(a[i][j]) > EPS)
            {
                if (j == m)
                {
                    cout << "Imposibil";
                    return 0;
                }
                else
                {
                    x[j] = a[i][m];
                    for (int k = j + 1; k < m; k++)
                    {
                        x[j] -= x[k] * a[i][k];
                    }
                    break;
                }
            }
        }
    }
    for(i = 0; i < m; i++)
        cout << fixed << setprecision(12) << x[i] << ' ';
    return 0;
}
