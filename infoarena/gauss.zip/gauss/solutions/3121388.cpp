
#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>
using namespace std;
typedef long double ld;
const int N = 300 + 7;
int n, m, pi[N], pj[N];
ld matrix[N][N], sol[N];
void print() {
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m + 1; j++) {
			cout << fixed << setprecision(6) << matrix[i][j] << " ";
		}
		cout << "\n";
	}
	cout << "----------------------\n";
}
signed main() {
#ifdef ONPC
	FILE* stream;
	freopen_s(&stream, "input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	freopen("gauss.in", "r", stdin);
	freopen("gauss.out", "w", stdout);
#endif
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m + 1; j++) {
			cin >> matrix[i][j];
		}
	}
	for (int i = 1; i <= n; i++) {
		pi[i] = -1;
	}
	for (int j = 1; j <= m; j++) {
		pj[j] = -1;
	}
	const ld E = 1e-14;
	while (true) {
		int r = -1, c = -1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (pi[i] == -1 && pj[j] == -1) {
					if (r == -1 || abs(matrix[i][j]) > abs(matrix[r][c])) {
						r = i;
						c = j;
					}
				}
			}
		}
		if (r == -1) {
			break;
		}
		if (abs(matrix[r][c]) < E) {
			break;
		}
		pi[r] = c;
		pj[c] = r;
		ld mulby = (ld)1 / matrix[r][c];
		for (int j = 1; j <= m + 1; j++) {
			matrix[r][j] *= mulby;
		}
		for (int i = 1; i <= n; i++) {
			if (i != r) {
				ld mulby = (ld)matrix[i][c];
				for (int j = 1; j <= m + 1; j++) {
					matrix[i][j] -= matrix[r][j] * mulby;
				}
			}
		}
	}
	for (int j = m; j >= 1; j--) {
		if (pj[j] == -1) {
			continue;
		}
		int i = pj[j];
		sol[j] = matrix[i][m + 1];
		for (int j2 = j + 1; j2 <= m; j2++) {
			sol[j] -= sol[j2] * matrix[i][j2];
		}
		sol[j] /= matrix[i][j];
	}
	for (int i = 1; i <= n; i++) {
		ld s = 0;
		for (int j = 1; j <= m; j++) {
			s += sol[j] * matrix[i][j];
		}
		s -= matrix[i][m + 1];
		if (abs(s) > E) {
			cout << "Imposibil\n";
			return 0;
		}
	}
	for (int j = 1; j <= m; j++) {
		cout << fixed << setprecision(6) << sol[j] << " ";
	}
	cout << "\n";
	return 0;
}