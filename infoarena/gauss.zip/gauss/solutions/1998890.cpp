#include <bits/stdc++.h>
#define ld double
#define eps 0.0000001
using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
ld a[301][301];
ld sol[301];
int main()
{
    int n,m,i,j,k,l,ll;
    f>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    for(i=1,j=1;i<=n and j<=m;i++,j++)
    {
        for(k=i;k<=n;k++)
            if(a[k][j]<-eps or a[k][j]>eps) break;
        if(k<=n)
        {
            if(k!=i)
                for(l=1;l<=m+1;l++)
                swap(a[i][l],a[k][l]);
            for(l=j+1;l<=m+1;l++)
                a[i][l]/=a[i][j];
            a[i][j]=1;
            for(l=i+1;l<=n;l++)
            {
                for(ll=j+1;ll<=m+1;ll++)
                    a[l][ll]-=(a[l][j]*a[i][ll]);
                a[l][j]=0;
            }
        }
    }
    for(i=n;i;i--)
        for(j=1;j<=m+1;j++)
            if(a[i][j]>eps or a[i][j]<-eps)
            {
                if(j==m+1)
                {
                    g<<"Imposibil";
                    return 0;
                }
                sol[j]=a[i][m+1];
                for(l=j+1;l<=m;l++)
                    sol[j]-=(sol[l]*a[i][l]);
                break;
            }
    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(9)<<sol[i]<<' ';

    return 0;
}
