#include<stdio.h>
#include<math.h>

using namespace std;
FILE *f1 = fopen("gauss.in", "r");
FILE *f2 = fopen("gauss.out", "w");

int N, M, i, j, k, last;
long double a[301][302], aux, sol[302], sum = 0;

void gauss(long double a[][302], int N, int M)
{
    long double aux, maxs, val;
    int i , j, k, l, c;
    for (k = 1; k <= N; k++)
    {
            maxs = fabs(a[k][k]);
            if (k > M)
                break;
            l = k;
            c = k;
            for (i = k; i <= N; i++)
                    if (fabs(a[i][k]) > maxs)
                    {
                        maxs = fabs(a[i][k]);
                        l = i;
                        c = k;
                    }
            if (k != l)
                for (i = k; i <= M + 1; i++)
                {
                    aux = a[l][i];
                    a[l][i] = a[k][i];
                    a[k][i] = aux;
                }
            /*for (i = 1; i <= N; i++)
            {
                aux = a[i][c];
                a[i][c] = a[i][k];
                a[i][k] = aux;
            }*/
            for (i = k+1; i <= N; i++)
            {
                val = a[i][k] / a[k][k];
                for (j = k; j <= M+1; j++)
                    a[i][j] = a[i][j] - a[k][j] * val;
            }
    }
}

int main()
{

    fscanf(f1, "%d%d", &N, &M);
    for (i = 1; i <= N; i++)
        for (j = 1; j <= M+1; j++)
            fscanf(f1, "%Lf", &a[i][j]);
    gauss(a, N, M);
    /*for (i = 1; i <= N; i++)
    {
        for (j = 1; j <= M + 1; j++)
            printf("%Lf ", a[i][j]);
        printf("\n");
    }*/

    for (i = N; i >= 1; i--)
    {
        if (a[i][M] == 0 && a[i][M+1] != 0)
        {
            fprintf(f2, "Imposibil\n");
            fclose(f1);
            fclose(f2);
            return 0;
        }
        if (a[i][M] != 0)
        {
            for (j = M - 1; j >= 1; j--)
                if (a[i][j] != 0)
                {
                    sol[j] = 0;
                    //sum = sum + a[i][j];
                }
                else
                    break;
            sol[M] = a[i][M+1]  / a[i][M];
            break;
        }
    }
    last = j;
    for (i = last; i >= 1; i--)
    {
        sum = 0;
        for (j = i + 1; j <= M; j++)
            sum = sum + a[i][j] * sol[j];
        sol[i] = (a[i][M+1] - sum) / a[i][i];
        //printf("%Lf %Lf %Lf %Lf\n", sol[i], a[i][M+1], a[i][i], sum);
    }
    for (i = 1; i <= M; i++)
        fprintf(f2, "%.10Lf ", sol[i]);
    return 0;
}
