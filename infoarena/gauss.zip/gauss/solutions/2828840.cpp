#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMAX = 300;

int N, M, cnt;
long double solutie[NMAX + 1];
long double v[NMAX + 1][NMAX + 1];
long double copie[NMAX + 1][NMAX + 1];

void swap_linii(int a, int b)
{
    for(int i = 1; i <= M + 1; i ++)
    {
        swap(v[a][i], v[b][i]);
    }
}

int main()
{
    fin >> N >> M;
    for(int i = 1; i <= N; i ++)
    {
        for(int j = 1; j <= M + 1; j ++)
        {
            fin >> v[i][j];
            copie[i][j] = v[i][j];
        }
    }
    for(int i = 1; i <= M; i ++)
    {
        if(v[i][i] == 0)
        {
            for(int j = i + 1; j <= N; j ++)
            {
                if(v[j][i] != 0)
                {
                    swap_linii(i, j);
                    break;
                }
            }
        }
        for(int j = i; j <= N; j ++)
        {
            if(v[j][i] == 0)
            {
                continue;
            }
            for(int q = i + 1; q <= M + 1; q ++)
            {
                v[j][q] /= v[j][i];
            }
            v[j][i] = 1;
        }
        for(int j = i + 1; j <= N; j ++)
        {
            if(v[j][i] == 0)
            {
                continue;
            }
            for(int q = i + 1; q <= M + 1; q ++)
            {
                v[j][q] -= v[i][q];
            }
        }
    }
    for(int i = M; i >= 1; i --)
    {
        v[i][M + 1] /= v[i][i];
        v[i][i] = 1;
        for(int j = i - 1; j >= 1; j --)
        {
            v[j][M + 1] -= v[j][i] * v[i][M + 1];
            v[j][i] = 0;
        }
    }
    bool imposibil = false;
    for(int i = 1; i <= M; i ++)
    {
        solutie[++cnt] = v[i][M + 1];
    }
    for(int i = 1; i <= M; i ++)
    {
        fout << fixed << setprecision(10) << solutie[i] << ' ';
    }
    fout << '\n';
    return 0;
}
