#include <bits/stdc++.h>

using namespace std;

const int NMAX = 300;

double a[NMAX + 1][NMAX + 1];
double eps = 0.001;

int line[NMAX + 1];

double solutions[NMAX + 1];

double modul( double a ) {
    if ( a < 0 )
        return -a;
    return a;
}
int main() {
    ifstream fin( "gauss.in" );
    ofstream fout( "gauss.out" );
    int n, m, i, j, maxim;
    fin >> n >> m;
    for ( i = 1; i <= n; i ++ ) {
        for ( j = 1; j <= m + 1; j ++ )
            fin >> a[i][j];
    }
    for ( j = 1; j <= m; j ++ ) {
        maxim = j;
        for ( i = j + 1; i <= n; i ++ ) {
            if ( modul( a[i][j] ) > modul( a[maxim][j] ) )
                maxim = i;
        }
        if ( modul( a[maxim][j] ) > eps ) {
            line[j] = j;

            for ( int k = 1; k <= m + 1; k ++ ) {
                swap( a[j][k], a[maxim][k] );
            }
            for ( i = 1; i <= n; i ++ ) {
                if ( i != j ) {
                    double aux = a[i][j] / a[j][j];
                    for ( int k = 1; k <= m + 1; k ++ ) {
                        a[i][k] -= a[j][k] * aux;
                    }
                }
            }
        }
    }
    for ( j = 1; j <= m; j ++ ) {
        if ( line[j] ) {
            solutions[j] = a[line[j]][m + 1] / a[line[j]][j];
        }
    }
    for ( i = 1; i <= n; i ++ ) {
        for ( j = 1; j <= m; j ++ ) {
            a[i][m + 1] -= a[i][j] * solutions[j];
        }
        if ( a[i][m + 1] > eps ) {
            fout << "Imposibil";
            return 0;
        }
    }
    for ( j = 1; j <= m; j ++ )
        fout << fixed << setprecision( 9 ) << solutions[j] << ' ';
    return 0;
}
