#include<bits/stdc++.h>
#define eps 0.0000001
#define maxN 305
using namespace std;
double a[maxN][maxN];
double sol[maxN];
int n,m;
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=(m+1);j++)
        {
            scanf("%lf",&a[i][j]);
        }
    }
    int i=1,j=1;
    while(i<=n && j<=m)
    {
        int k;
        for(k=i;k<=n;k++)
        {
            if(a[k][j]<-eps || a[k][j]>eps)
                break;
        }
        if(k==(n+1)) //Necunoscuta Libera
        {
            j++;
            continue;
        }
        if(k!=i)
        {
            //Schimbam liniile k si i
            for(int u=1;u<=m+1;u++)
            {
                swap(a[i][u],a[k][u]);
            }
        }
        for(int u=j+1;u<=m+1;u++)
        {
            a[i][u]/=a[i][j];
        }
        a[i][j]=1; //Reducem toata ecuatia de pe linia i ca sefii
        for(int u=i+1;u<=n;u++)
        {
            for(int l=j+1;l<=m+1;l++)
            {
                a[u][l]-=a[u][l]*a[i][l];
            }
            a[u][j]=0; //Practic reducem necunoscuta i din toate ecuatiile
        }
        i++;
        j++;
    }
    for(int i=n;i>0;i--)
    {
        for(int j=1;j<=m+1;j++)
        {
            if(a[i][j]<-eps || a[i][j]>eps)
            {
            if(j==m+1)
            {
                printf("Imposibil\n");
                return 0;
            }
            sol[j]=a[i][m+1];
            for(int k=j+1;k<=m;k++)
                sol[j]-=sol[k]*a[i][k];
            break;
            }
        }
    }
    for(int i=1;i<=m;i++)
        printf("%.8lf ",sol[i]);
    return 0;
}
