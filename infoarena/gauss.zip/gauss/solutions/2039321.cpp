/**
  *  Worg
  */
#include <cmath>
#include <cstdio>
#include <vector>

FILE *fin = freopen("gauss.in", "r", stdin); FILE *fout = freopen("gauss.out", "w", stdout);

const double eps = 1e-8;

/*-------- Data --------*/
int N, M;
std::vector<std::vector<double > > sys;
/*-------- --------*/

void ReadInput() {
    scanf("%d%d", &N, &M);

    sys = std::vector<std::vector<double > >(N, std::vector<double >(M + 1));

    for(int i = 0; i < N; i++) {
        for(int j = 0; j <= M; j++) {
            scanf("%lf", &sys[i][j]);
        }
    }
}

bool Null(double value) {
    return -eps < value && value < eps;
}

void Gauss() {
    for(int i = 0; i < N; i++) {
        int line = i;
        for(int j = i + 1; j < N; j++) {
            if(std::abs(sys[j][i]) > std::abs(sys[line][i])) {
                line = j;
            }
        }

        std::swap(sys[i], sys[line]);

        if(Null(sys[i][i])) continue;  //  Unfixed

        double coef = 1 / sys[i][i]; sys[i][i] = 1.0;
        for(int j = i + 1; j <= M; j++) {
            sys[i][j] *= coef;
        }

        for(int j = 0; j < N; j++) {
            if(j == i || Null(sys[j][i])) continue;

            double coef = sys[j][i] / sys[i][i];
            for(int k = 0; k <= M; k++) {
                sys[j][k] -= coef * sys[i][k];
            }
        }
    }

    std::vector<double > answer;
    for(int i = 0; i < N; i++) {
        if(!Null(sys[i][M]) && Null(sys[i][i])) {
            printf("Imposibil\n"); return;
        } else {
            answer.push_back(sys[i][M]);
        }
    }

    for(auto& x : answer) {
        printf("%.12f ", x);
    }
    printf("\n");
}

int main() {
    ReadInput();

    Gauss();

    return 0;
}
