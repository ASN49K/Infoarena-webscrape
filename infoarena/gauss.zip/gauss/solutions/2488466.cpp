#include <fstream>
#include <iomanip>
using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");
double v[301][301],val[301];
bool stim[301];
int main()
{
    int n,m,i,j,l,k;
    double s,sum;
    in>>n>>m;
    for(i=1; i<=n; i++)
        for(j=1; j<=m+1; j++)
            in>>v[i][j];
    i=j=1;
    while(i<=n&&j<=m)
    {
        for(l=i; l<=n; l++)
            if(v[l][j]!=0)
                break;
        if(l==n+1)
            j++;
        else
        {
            if(l!=i)
                for(k=1; k<=m+1; k++)
                    swap(v[i][k],v[l][k]);
            for(k=1; k<=m+1; k++)
                if(k!=j)
                    v[i][k]/=v[i][j];
            v[i][j]=1;
            for(l=i+1; l<=n; l++){
                for(k=1; k<=m+1; k++)
                    if(k!=j)
                    v[l][k]-=v[i][k]*v[l][j];
                    v[l][j]=0;
            }
            j++;
            i++;
        }
        /*for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m+1; j++)
                out<<v[i][j]<<" ";
            out<<'\n';
        }
        out<<'\n';*/
    }
    /*for(i=1; i<=n; i++)
    {
        for(j=1; j<=m+1; j++)
            out<<v[i][j]<<" ";
        out<<'\n';
    }*/
    for(i=n;i>=1;i--)
    {
     s=0;
     sum=0;
     for(j=m;j>=1;j--)
      {s+=val[j]*v[i][j];
      sum+=v[i][j];}
     /*if(sum==0&&v[i][m+1])
     {
      out<<"Imposibil";
      return 0;
     }*/
     for(j=m;j>=1;j--)
        if(!stim[j]&&v[i][j])
        break;
     stim[j]=1;
     val[j]=(v[i][m+1]-s)/v[i][j];
    }
    for(i=1;i<=min(n,m);i++)
    {
     s=0;
     for(j=1;j<=m;j++)
            s+=v[i][j]*val[j];
     /*if(s!=v[i][m+1])
     {
      out<<"Imposibil";
      return 0;
     }*/
    }
    for(i=1;i<=m;i++)
        out<<fixed<<setprecision(9)<<val[i]<<" ";
    return 0;
}
