#include <stdio.h>

double a[301][302], ans[301];
int main() {
    FILE *fin = fopen("gauss.in", "r");
    freopen("gauss.out", "w", stdout);

    int n, m;
    fscanf(fin, "%d%d", &n, &m);

    int i, j, k, l;
    for (i = 1; i <= n; i++)
        for (j = 1; j <= m + 1; j++)
            fscanf(fin, "%lf", a[i] + j);

    for (j = 1; j <= m; j++) {
        i = j;
        while (i <= n && !a[i][j])
            i++;

        if (i > n)
            continue;

        if (i != j)
            for (k = 1; k <= m + 1; k++) {
                double aux = a[i][k];
                a[i][k] = a[j][k];
                a[j][k] = aux;
            }

        for (k = j + 1; k <= m + 1; k++)
            a[j][k] /= a[j][j];

        a[j][j] = 1;
        for (k = j + 1; k <= n; k++) {
            for (l = j + 1; l <= m + 1; l++)
                a[k][l] -= a[j][l] * a[k][j];
            a[k][j] = 0;
        }
    }

    for (i = n; i; i--)
        for (j = 1; j <= m + 1; j++)
            if (a[i][j]) {
                if (j == m + 1) {
                    printf("IMPOSIBIL");
                    return 0;
                }

                ans[j] = a[i][m + 1];
                for (k = j + 1; k <= m; k++)
                    ans[j] -= ans[k] * a[i][k];

                break;
            }

    for (i = 1; i <= m; i++)
        printf("%.9lf ", ans[i]);

    return 0;
}
