#include <bits/stdc++.h>

using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");

double eroare=1e-17;
double v[305][305],sol[305];
bool valid[305];
int main()
{
    int n,m;
	in>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m+1;j++)
			in>>v[i][j];
	int i=1;
	int j=1;
	while(j<=m){
		int lin=0;
		for(int k=i;k<=n;k++)
			if(v[k][j]!=0){
				lin=k;
				break;
			}
		if(lin==0){
			j++;
			continue;
		}
		swap(v[i],v[lin]);
		double z=v[i][j];
		for(int k=1;k<=m+1;k++)
			v[i][k]/=z;
		for(int k=i+1;k<=n;k++){
			double u=v[k][j];
			for(int p=1;p<=m+1;p++)
				v[k][p]-=u*v[i][p];
		}
		i++;
		j++;
	}
	for(int i=n;i>=1;i--){
		int idk=0;
		double suma=0;
		for(int j=1;j<=m;j++){
			if(v[i][j]==0)
				continue;
			if(valid[j])
			{
				suma+=v[i][j]*sol[j];
				continue;
			}
			valid[idk]=1;
			idk=j;
		}
		if(idk==0){
			if(abs(suma-v[i][m+1])>eroare){
				out<<"Imposibil";
				return 0;
			}
			continue;
		}
		double val=(v[i][m+1]-suma)/v[i][idk];
		sol[idk]=val;
		valid[idk]=1;
	}
	for(int i=1;i<=m;i++)
		out<<fixed<<setprecision(10)<<sol[i]<<' ';
	return 0;
}
