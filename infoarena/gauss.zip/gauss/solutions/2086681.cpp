#include <cstdio>
#include <iostream>

using namespace std;
double a[301][302],x[302];
void intersc (int i,int k,int m){
    int j;
    for (j=1;j<=m+1;j++)
        swap(a[i][j],a[k][j]);
}
int main()
{
    FILE *fin=fopen ("gauss.in","r");
    FILE *fout=fopen ("gauss.out","w");
    int n,m,i,j,k,ii,jj;
    fscanf (fin,"%d%d",&n,&m);
    for (i=1;i<=n;i++)
        for (j=1;j<=m+1;j++)
            fscanf (fin,"%lf",&a[i][j]);
    i=j=1;
    while (i<=n && j<=m){
        for (k=i;k<=n;k++)
            if (a[k][j]!=0) // caut prm coef dif de 0
                break;
        if (k==n+1){ // toti coef sunt 0, e variabila libera
            j++;
            continue;
        }
        intersc (i,k,m); // interschimb liniile i si k
        for (k=j+1;k<=m+1;k++)
            a[i][k]/=a[i][j];
        a[i][j]=1;
        for (ii=i+1;ii<=n;ii++)
            for (jj=m+1;jj>=j;jj--)
                a[ii][jj]=a[ii][jj]-a[i][jj]*a[ii][j];
        i++;
        j++;
    }
    // aflarea solutiilor
    for (i=n;i>0;i--){
        for (j=1;j<=m+1;j++)
            if (a[i][j]!=0)
                break;
        if (j==m+1){
            fprintf (fout,"Imposibil"); // 0*x1 + 0*x2 +... 0*xn = y, y!=0 => imposibil
            return 0;
        }
        if (j==m+2) // e libera
            continue;
        x[j]=a[i][m+1]/a[i][j];
        for (k=i-1;k>0;k--)
            a[k][m+1]-=x[j]*a[k][j];
    }
    for (i=1;i<=n;i++)
        fprintf (fout,"%.8lf ",x[i]);
    return 0;
}
