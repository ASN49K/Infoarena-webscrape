#include <fstream>
#include <iomanip>
#define epsilon 0.000000001
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n,m, t,i,j,ii,jj;
double a[320][320],s[320];


int main(){
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m+1;j++){
            fin>>a[i][j];
        }
    }
    i=1;
    j=1;
    while(i<=n && j<=m){
        for(ii=i;ii<=n;ii++){
            if(a[ii][j]!=0){
                break;
            }
        }

        if(ii==n+1){
            j++;
            continue;
        }
        if(ii!=i){
            for(jj=1;jj<=m+1;jj++){
                int aux=a[ii][jj];
                a[ii][jj]=a[i][jj];
                a[i][jj]=aux;
            }
        }

        for(jj=j+1;jj<=m+1;jj++){
            a[i][jj]/=a[i][j];
        }
        a[i][j]=1;
        for(ii=i+1;ii<=n;ii++){
           for(jj=j+1;jj<=m+1;jj++){
                a[ii][jj]-=a[i][jj]*a[ii][j];

            }
           a[ii][j]=0;
        }

        i++;
        j++;

    }
    int ok=1;
    for(i=n;i>=1;i--){
        for(j=1;j<=m+1;j++){
            if(a[i][j]<-epsilon ||a[i][j]>epsilon ){
                break;
            }
        }
        if(j==m+2){
            continue;
        }
        if(j==m+1){
            ok=0;
            break;
        }
        s[j]=a[i][m+1];
        for(int jj=j+1;jj<=m;jj++){
            s[j]-=a[i][jj]*s[jj];
        }
    }
    if(ok==0){
        fout<<"Imposibil";
    }
    else{
        for(i=1;i<=m;i++){
            fout<<setprecision(10)<<fixed<<s[i]<<" ";
        }
    }




}
