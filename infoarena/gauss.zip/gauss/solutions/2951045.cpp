#include <fstream>
#include <iostream>
#include <iomanip>
#define ld long double

using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

ld v[305][305], x[305];
int ind[305];

int main() {
    int n, m;
    in >> n >> m;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m + 1; j++)
            in >> v[i][j];
    }

    for(int j = 1; j <= m; j++) {
        int l = 1;
        while((abs(v[l][j]) < 1e-12 || ind[l]) && l <= n)
            l++;
        ind[l] = j;
        for(int i = 1; i <= n; i++) {
            if(abs(v[i][j]) < 1e-12 || ind[i])
                continue;
            ld c = v[l][j] / v[i][j];
            for(int k = j; k <= m + 1; k++) {
                v[i][k] *= c;
                v[i][k] -= v[l][k];
            }
        }
    }

    for(int j = m; j >= 1; j--) {
        for(int i = 1; i <= n; i++) {
            if(ind[i] != j)
                continue;

            x[j] = v[i][m + 1] / v[i][j];
            for(int k = 1; k <= n; k++)
                v[k][m + 1] -= v[k][j] * x[j];
        }
    }

    bool ok = 1;
    for(int i = 1; i <= n; i++)
        ok &= (abs(v[i][m + 1]) < 1e-6);
    if(!ok) {
        out << "Imposibil\n";
        return 0;
    }

    for(int i = 1; i <= m; i++)
        out << fixed << setprecision(10) << x[i] << " ";
    out << "\n";
}
