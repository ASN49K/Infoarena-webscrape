#include <bits/stdc++.h>

#define MaxN 305
#define EPS  ((double)(1e-8))

std::ifstream InFile("gauss.in");
std::ofstream OutFile("gauss.out");

int N, M, P[MaxN];
double A[MaxN][MaxN], Sol[MaxN];
double Coef;

int main() {
    InFile >> N >> M;

    for(int i=1, j; i<=N; ++i)
        for(j=1; j<=M+1; ++j)
            InFile >> A[i][j];

    for (int i=1, j, k; i<=N; ++i) {
        for (j=1; j<=M+1; ++j)
            if (fabs(A[i][j]) > EPS)
                break;

        if (j==M+2) continue;
        if (j==M+1) {
            OutFile << "Imposibil\n";
            return 0;
        }

        P[i] = j;

        for (j=1; j<=N; ++j)
            if (i!=j) {
                Coef = A[j][P[i]] / A[i][P[i]];
                for (k=1; k<=M+1; ++k)
                    A[j][k] -= Coef * A[i][k];
            }
    }

    for (int i=1; i<=M; ++i)
        if (P[i])
            Sol[P[i]] = A[i][M+1] / A[i][P[i]];

    OutFile << std::fixed << std::setprecision(10);
    for (int i=1; i<=N; ++i)
        OutFile << Sol[i] << ' ' ;
}
