#include<stdio.h>
using namespace std;

#define e 1e-6

FILE*f=fopen("gauss.in","r");
FILE*g=fopen("gauss.out","w");

double a[1005][1005];
int n,m;

void citire() {
    int i,j;

    fscanf(f,"%d%d",&n,&m);
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++) fscanf(f,"%lf",&a[i][j]);
}

void impart(int l, double x) {
    int j;

    for(j=1;j<=m+1;j++) a[l][j]/=x;
}

void scad(int l1, int l2, double x) {
    int j;

    for(j=1;j<=m+1;j++) a[l1][j]-=a[l2][j]*x;
}

void intersch(int l1, int l2) {
    int j;
    double b;

    for(j=1;j<=m+1;j++) {
        b=a[l1][j];
        a[l1][j]=a[l2][j];
        a[l2][j]=b;
    }
}

void reduc(int c, int piv) {
    int i;

    for(i=1;i<=n;i++)
        if(i!=piv) scad(i,piv,a[i][c]/a[piv][c]);
}

int zero(double x) {
    return (-e<=x&&x<=e);
}

void solve() {
    int i,j;

    for(j=1;j<=m;j++) {
        for(i=j;i<=n;i++)
            if(!zero(a[i][j])) {
                if(i!=j) intersch(i,j);
                impart(i,a[i][j]);
                reduc(j,i);
                break;
            }
    }
     for(i=m+1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            if(!zero(a[i][j])) {
                fprintf(g,"Imposibil");
                return;
            }

    for(i=1;i<=m;i++)
        fprintf(g,"%.10f ",a[i][m+1]);
}

int main() {

    citire();
    solve();

    return 0;
}
