#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

const int MAXN = 300 + 1;
const long double PRECIZIE = 1e-10;

using namespace std;

typedef long double ld;

ifstream in("gauss.in");
ofstream out("gauss.out");

int n,m;
ld v[MAXN + 1][MAXN + 1];
ld ans[MAXN];
bool viz[MAXN];

void afis(){
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= m + 1; j++)
            cout<<setprecision(7)<<fixed<<v[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl;
}

int main()
{
    in.tie(0);
    out.tie(0);
    ios::sync_with_stdio(false);
    in>>n>>m;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m + 1; j++)
            in>>v[i][j];
    int inceput = 1;
    for(int j = 1; j <= m - 1; ++j){
        for(int i = inceput + 1; i <= n; ++i){
            ld x1 = v[inceput][j];
            ld x2 = v[i][j];
            ld inmulteste = -x1/x2;
            //cout<<"linia "<<i<<" "<<inmulteste<<endl;
            for(int k = 1; k <= m + 1; ++k){
                v[i][k] *= inmulteste;
                v[i][k] += v[inceput][k];
            }
        }
        inceput++;
    }
    //afis();

    bool ok = true;
    for(int i = n; i >= 1 && ok; --i){
        int cnt = 0,index = -1;
        for(int j = 1; j <= m && ok; ++j){
            if(abs(v[i][j]) > PRECIZIE){
                index = j;
            }
        }
        //afis();
        if(i == n){
            for(int j = 1; j <= m; ++j){
                if(abs(v[i][j]) > PRECIZIE && j != index){
                    viz[j] = true;
                    ans[j] = 0;
                    for(int linie = i - 1; linie >= 1; --linie)
                        v[linie][j] = 0;
                }
            }
        }

        if(index == -1 && abs(v[i][m + 1]) > PRECIZIE){
            ok = false;
            break;
        }
        if(viz[index]){
            if(abs(v[i][m + 1] - v[i][index]) > PRECIZIE){
                ok = false;
                break;
            }

        }else{
            //cout<<v[i][m + 1]<<" "<<v[i][index]<<endl;
            ld xj = v[i][m + 1] / v[i][index];
            ans[index] = xj;
            viz[index] = true;
            for(int linie = i - 1; linie >= 1 && ok; --linie){
                v[linie][m + 1] -= v[linie][index] * xj;
                v[linie][index] = 0;
            }
            //afis();
        }
    }

    if(!ok)
        out<<"Imposibil";
    else{
        for(int i = 1; i <= m; ++i)
            out<<setprecision(13)<<fixed<<ans[i]<<" ";
    }
    return 0;
}
