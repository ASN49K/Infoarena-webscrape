#include<cstdio>
using namespace std;
int n,m,p[306];
double rap,ras[305],a[305][305];
double eps = 1e-8;
double mod(double x){ return (x > 0 ? x : -x); }
int main ()
{
    freopen ("gauss.in", "r", stdin);
    freopen ("gauss.out", "w", stdout);
    scanf ("%d %d", &n, &m);
    /// n operatii, m necunoscute
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m+1; j++)
            scanf ("%lf", &a[i][j]);
    /// p[i] = j-ul minim a.i. a[i][j] != 0
    for (int i = 1; i <= n; i++)
    {
        p[i]=0;
        for (int j = 1; j <= m+1; j++)
            if ( mod (a[i][j]) > eps )
            {
                p[i] = j;
                break;
            }
        if (p[i] == m+1)
        {
            printf ("Imposibil\n");
            return 0;
        }
        if (p[i] == 0) continue;
        for (int j = 1; j <= n; j++)
            if (j != i && mod ( a[j][p[i]] ) > eps )
            {
                rap = (double) a[j][p[i]] / a[i][p[i]];
                for ( int k = 1; k <= m+1; k++)
                    a[j][k] = (double) a[j][k] - a[i][k] * rap;
            }
    }

    for (int i = 1; i <= n; i++)
        if (p[i]) /* && mod(a[i][p[i]]) > eps */
            ras[ p[i] ] = (double) a[i][m+1] / a[i][p[i]];
    for (int i = 1; i <= m; i++)
        printf("%.10lf ",ras[i]);
        printf("\n");
    return 0;
}
