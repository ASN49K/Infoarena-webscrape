#include <bits/stdc++.h>

using namespace std;

ifstream fcin("gauss.in");
ofstream fcout("gauss.out");


void citire(vector<vector<double > > &a,int n)
{
    vector<double> vid;
    int q;
    for(int i=0; i<n; i++)
    {
        a.push_back(vid);
        for(int j=0; j<n+1 ;j++)
        {
            fcin>>q;
            a[i].push_back(q);
        }
    }

}
void afis(vector<vector<double > > a)
{
    for(int i=0;i<a.size();i++)
    {
        for(int j=0;j<a[i].size(); j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<"\n";
    }
    cout<<"\n";
}

void afissol(vector <double> v)
{
    for(int i=0; i<v.size(); i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<"\n";
}

void sters(vector<vector<double > > &a)
{
    int n=a.size()-1;
    for(int i=0; i<a.size();i++)
    {
        a.erase(a.begin()+n,a.begin()+n+1);
    }
}
double sol(vector <vector < double > > &a)
{
    int n=a.size()-1;
    double s=a[n][n+1]/a[n][n];
    for(int i=0; i<n-1; i++)
    {
        a[i][n+1]=a[i][n+1]-a[i][n]*s ;
    }
    return s;
}

vector<double> x(vector<vector <double> > &a)
{
    vector <double> v;
    double q;
    while(a.size()>0)
    {
        q=sol(a);
        v.push_back(q);
        sters(a);
    }
    return v;
}

void esalon(vector<vector<double> > &a,int n)
{
    double z;
    for(int k=0 ; k<n-1; k++)
    {
        if(a[k][k]==0){cout<<"imposibil";break;}
        for(int i=k+1; i<n; i++)
        {
            z=-a[i][k]/a[k][k];
            for(int j=k ; j<n+1; j++)
            {
                a[i][j]=z*a[k][j]+a[i][j];
            }
        }
    }
}

int main()
{
    vector< vector <double > > a;
    vector<double > v;
    int n;
    fcin>>n;
    citire(a,n);
    esalon(a,n);
    afis(a);
    v=x(a);
    fcout<<"imposibil";
    //afissol(v);
    fcin.close();
    fcout.close();
}

