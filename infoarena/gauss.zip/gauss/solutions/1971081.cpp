# include <fstream>
# include <iomanip>
using namespace std;
const double EPS=1e-3;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
double v[310][310],sol[310];
int n,m,i,j,t,r;
void mySwap(int i,int j){
    for(int t=1;t<=m+1;t++)
        swap(v[i][t],v[j][t]);
}
int main () {
    fin>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            fin>>v[i][j];
    r=1;
    for(t=1;t<=m&&r<=n;t++){
        for(i=r;i<=n;i++)
            if(v[i][t]<=-EPS||v[i][t]>=EPS)
                break;
        if(i==n+1)
            continue;
        if(r!=i)
            mySwap(r,i);
        for(j=t+1;j<=m+1;j++)
            v[r][j]/=v[r][t];
        v[r][t]=1;
        for(i=r+1;i<=n;i++){
            if(v[i][t]==0)
                continue;
            for(j=t+1;j<=m+1;j++)
                v[i][j]/=-v[i][t];
            v[i][t]=-1;
            for(j=t+1;j<=m+1;j++)
                v[i][j]=v[r][j]+v[i][j];
            v[i][t]=0;
        }
        r++;
    }
    for(i=n;i>=1;i--){
        for(j=1;j<=m+1;j++)
            if(v[i][j]<=-EPS||v[i][j]>=EPS)
                break;
        if(j==m+2)
            continue;
        if(j==m+1){
            fout<<"Imposibil";
            return 0;
        }
        sol[j]=v[i][m+1]/v[i][j];
        for(t=i+1;t>=1;t--)
            v[t][m+1]-=v[t][j]*sol[j];
    }
    for(i=1;i<=m;i++)
        fout<<setprecision(10)<<fixed<<sol[i]<<" ";
    fout<<"\n";
    return 0;
}
