#include<bits/stdc++.h>
using namespace std;

const int maxN=(3e2)+5;
const double eps=(1e-20);
int n,m;
double a[maxN][maxN],sol[maxN];
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);

    scanf("%d%d",&n,&m);

    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            scanf("%lf",&a[i][j]);

    int i=1,j=1;

    while(i<=n && j<=m)
    {
        int k;
        for(k=i;k<=n;k++)
            if(a[k][j]<-eps || a[k][j]>eps) break;

        if(k==(n+1))
        {
            j++;
            continue;
        }

        if(k!=i)
        {
            for(int u=1;u<=m+1;u++)
                swap(a[i][u],a[k][u]);
        }

        for(int u=j+1;u<=m+1;u++)
            a[i][u]/=a[i][j];
        a[i][j]=1.0;

        for(int u=i+1;u<=n;u++)
        {
            for(int l=j+1;l<=m+1;l++)
            {
                a[u][l]-=a[u][j]*a[i][l];
            }
            a[u][j]=0;
        }
        i++;
        j++;
    }



    for(int i=n;i>=1;i--)
    {
        for(int j=1;j<=m+1;j++)
        {
            if(a[i][j]<-eps || a[i][j]>eps)
            {
                if(j==(m+1))
                {
                    printf("Imposibil\n");
                    return 0;
                }

                sol[j]=a[i][m+1];
                for(int k=j+1;k<=m;k++)
                    sol[j]-=sol[k]*a[i][k];
                break;
            }
        }
    }

    for(int i=1;i<=m;i++)
        cout<<setprecision(20)<<fixed<<sol[i]<<' ';

    cout<<'\n';

    return 0;
}
