#include    <cstdio>

#define    NMAX 310
#define    eps 0.0000001

using namespace std;

int N, M;
double a[NMAX][NMAX];
double x[NMAX];

int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    scanf("%d%d", &N, &M);
    for(int i = 1; i <= N; ++i)
        for(int j = 1; j <= M+1; ++j)
            scanf("%lf", &a[i][j]);

    int i = 1, j = 1, k;
    double aux;

    while(i <= N && j <= M)
    {
        for(k = i; k <= N; ++k)
        {
            if(a[k][j]<-eps || a[k][j]>eps)
                break;
        }

        if(k == N+1)
        {
            ++j;
            continue;
        }

        if(k != i)
            for(int l = 1; l <= M+1; ++l)
            {
                aux = a[i][l];
                a[i][l] = a[k][l];
                a[k][l] = aux;
            }

        for(int l = j+1; l <= M+1; ++l)
            {a[i][l] = a[i][l] / a[i][j];}

        a[i][j] = 1;

        for(int u = i+1; u <= N; ++u)
        {
            for(int l = j+1; l <= M+1; ++l)
               {a[u][l] -= a[u][j] * a[i][l];}

            a[u][j] = 0;
        }

        ++i, ++j;
    }

    for(int i = N; i > 0; --i)
    {
        for(int j = 0; j <= M+1; ++j)
            {
            if(a[i][j]>eps || a[i][j]<-eps)
            {
                if(j == M+1)
                {
                    printf("Imposibil\n");
                    return 0;
                }

                x[j] = a[i][M+1];

                for(int k = j+1; k <= M; ++k)
                    {x[j] -= x[k] * a[i][k];}

                break;
            }
        }
    }

    for(int i = 1; i <= M; ++i)
        printf("%.8lf ", x[i]);
    printf("\n");


    return 0;
}
