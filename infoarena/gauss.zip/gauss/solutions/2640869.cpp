#include <bits/stdc++.h>
#define msj "Imposibil\n"
using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");
typedef long double ld;
ld a[305][305];
ld x[305];
int main()
{
    int n,m;
    in>>n>>m;
    for(int i=1;i<=n;++i)
    for(int j=1;j<=m+1;++j)
        in>>a[i][j];
    int i=1,j=1;
    while(i<=n and j<=m)
    {
        int x=i;
        while(x<=n and a[x][j]==0)
            ++x;
        if(x>n) {++j; continue;}
        for(int r=1;r<=m+1;++r)
            swap(a[i][r],a[x][r]);
        ld imp=a[i][j];
        for(int r=1;r<=m+1;++r)
            a[i][r]/=imp;
        for(int u=i+1;u<=n;++u)
        {
            imp=a[u][j];
            for(int r=1;r<=m+1;++r)
                a[u][r]-=imp*a[i][r];
        }
        ++i;
        ++j;
    }
    int p=m;
    for(int i=n;i>=1;--i)
    {
        while(p>0 and a[i][p]!=0)
            --p;
        ++p;
        if(a[i][p]==0) {out<<msj<<'\n';return 0;}
        x[p]=a[i][m+1];
        for(int j=p+1;j<=m;++j)
            x[p]-=x[j]*a[i][j];
    }
    for(int i=1;i<=m;++i)
        out<<fixed<<setprecision(10)<<x[i]<<' ';
    return 0;
}
