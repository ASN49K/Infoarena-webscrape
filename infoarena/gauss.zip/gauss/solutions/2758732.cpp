#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
using namespace std;

int n,m;
double matrix[300][301],matrix2[300][301];
ifstream be("gauss.in");
ofstream ki("gauss.out");

void swap_row(int i,int j)
{
    for(int k=0;k<=m;k++)
    {
        swap(matrix[i][k],matrix[j][k]);
    }
}

bool elim()
{
    int s=0,o=0;
    while(s<n)
    {
        if(o<m){
            int i_max=s;
            int v_max=matrix[i_max][o];
            for(int i=s+1;i<n;i++)
            {
                if(abs(matrix[i][o])>v_max){
                    v_max=matrix[i][o];
                    i_max=i;
                }
            }
            if(abs(matrix[i_max][o])>1e-8){
                if(i_max!=s){
                    //cout<<"csere "<<s<<" "<<i_max<<endl;
                    swap_row(s,i_max);
                }
                for(int i=s+1;i<n;i++)
                {
                    double f=matrix[i][o]/matrix[s][o];
                    for(int j=o+1;j<=m;j++)
                        matrix[i][j]-=matrix[s][j]*f;
                    matrix[i][o]=0;
                }
                s++;
                o++;
            }
            else{
                o++;
            }
        }
        else{
            if(abs(matrix[s][m])>1e-8)
                return false;
            else s++;
        }

    }
    return true;
}

void solve()
{
    vector<double>x(m,0);
    for(int i=n-1;i>=0;i--)
    {
        int k;
        for(k=0;k<m && abs(matrix[i][k])<1e-8;k++)
            ;
        if(k!=m){
            x[k]=matrix[i][m];
            for(int j=k+1;j<m;j++)
                x[k]-=matrix[i][j]*x[j];
            x[k]=x[k]/matrix[i][k];
        }
    }
    for(int i=0;i<m;i++){
        ki<<fixed<<setprecision(10)<<x[i]<<" ";
    }
    ki<<"\n";


}


void gauss_el()
{
    if(elim())
        solve();
    else ki<<"Imposibil\n";
}



int main()
{

    be>>n>>m;
    for(int i=0;i<n;i++)
        for(int j=0;j<=m;j++){
            be>>matrix[i][j];
            matrix2[i][j]=matrix[i][j];
        }
    gauss_el();

    return 0;
}


