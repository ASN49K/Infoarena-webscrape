#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <iomanip>

using namespace std;
ifstream cin("gauss.in");
ofstream cout("gauss.out");
const int NMAX = 305;
const double EPS = 1e-12;
vector<vector<double>> a, aux;
double x[NMAX];
int main()
{
    int n, m, i, j, r, imp = 0, c;
    double coef;
    cin >> n >> m;
    a.resize(n);
    aux.resize(n);
    for(i = 0; i < n; i++)
    {
        a[i].resize(m+1);
        aux[i].resize(m+1);
        for(j = 0; j <= m; j++)
        {
            cin >> a[i][j];
            aux[i][j] = a[i][j];
        }
    }
    for(i = 0, j = 0; i < m && j < n; i++, j++)
    {
        r = j;
        while(r < n && a[r][i] == 0)
            r++;
        if(r == n)
            continue;
        swap(a[j], a[r]);
        coef = a[j][i];
        for(c = i; c <= m; c++)
            a[j][c] /= coef;
        for(r = 0; r < n; r++)
        {
            if(r == j)
                continue;
            coef = (-a[r][i]);
            for(c = 0; c <= m; c++)
            {
                a[r][c] += coef * a[j][c];
                if(abs(a[r][c]) < EPS)
                    a[r][c] = 0;
            }
        }
    }
    double sum = 0;
    for(j = 0; j < m; j++)
        x[j] = a[j][m];
    for(i = 0; i < n; i++)
    {
        sum = 0;
        for(j = 0; j < m; j++)
            sum = sum + x[j] * aux[i][j];
        sum -= aux[i][m];
        if(abs(sum) > EPS)
            imp = 1;
    }
    if(imp)
    {
        cout << "Imposibil";
        return 0;
    }
    for(i = 0; i < m; i++)
        cout << fixed << setprecision(12) << x[i] << ' ';
        /*cout << '\n';
        for(i = 0; i < n; i++)
        {
            for(j = 0; j <= m; j++)
                cout << a[i][j] << ' ';
            cout << '\n';
        }*/
    return 0;
}
