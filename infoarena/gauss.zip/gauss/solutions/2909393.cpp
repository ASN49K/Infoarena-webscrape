#include <fstream>
#include <iomanip>

using namespace std;

const int nmax = 300;
const double eps = 1e-10, inf = 1e9;

double a[nmax + 1][nmax + 1], solx[nmax + 1], aa[nmax + 1][nmax + 1];

int verif (int n, int m)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        double sol = 0;
        for (j = 1; j <= m; j++)
            sol = sol + solx[j] * aa[i][j];
        if (aa[i][m + 1] - sol > 1e-5 || aa[i][m + 1] - sol < -1e-5)
            return 0;
    }
    return 1;
}

int main()
{
    ifstream cin ("gauss.in");
    ofstream cout ("gauss.out");
    int n, m, i, j, x, y, aux;
    cin >> n >> m;
    for (i = 1; i <= n; i++)
        solx[i] = inf;
    for (i = 1; i <= n; i++)
        for (j = 1; j <= m + 1; j++)
            cin >> a[i][j], aa[i][j] = a[i][j];
    i = j = 1;
    while (i <= n && j <= m)
    {
        aux = i;
        while (a[aux][j] <= eps && a[aux][j] >= -eps && aux <= n)
            aux++;
        if (aux == n + 1)
        {
            solx[j] = 0;
            cout << "Imposibil";
            return 0;
        }
        else
        {
            swap (a[i], a[aux]);
            /*for (x = 1; x <= n; x++)
            {
                for (y = 1; y <= m + 1; y++)
                    cout << a[x][y] << " ";
                cout << endl;
            }
            cout << endl;*/
            for (aux = j + 1; aux <= m + 1; aux++)
                a[i][aux] /= a[i][j];
            a[i][j] = 1;
            for (x = i + 1; x <= n; x++)
            {
                for (y = j + 1; y <= m + 1; y++)
                    a[x][y] -= a[x][j] * a[i][y];
                a[x][j] = 0;
            }
            /*for (x = 1; x <= n; x++)
            {
                for (y = 1; y <= m + 1; y++)
                    cout << a[x][y] << " ";
                cout << endl;
            }
            cout << endl;*/
        }
        i++, j++;
    }
    for (i = m; i >= 1; i--)
    {
        solx[i] = a[i][m + 1];
        for (j = m; j >= i + 1; j--)
            solx[i] -= a[i][j] * solx[j];
        solx[i] /= a[i][j];
    }
    if (verif (n, m))
        for (i = 1; i <= m; i++)
            cout << fixed << setprecision (10) << solx[i] << " ";
    else
        cout << "Imposibil";
    return 0;
}
