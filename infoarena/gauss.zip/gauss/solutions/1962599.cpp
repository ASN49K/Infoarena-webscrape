#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 305;

int n, m;
double mat[N][N];
double matx[N][N];
double eps = 0.000000000001; 

void citire()
{
	scanf("%d %d", &n, &m);

	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j <= m; j++)
		{
			scanf("%lf", &mat[i][j]);
			matx[i][j] = mat[i][j];
		}
	}
}

void adunaLinie(int cine, int ce, double x)
{
	for(int i = 0; i <= m; i++)
	{
		mat[ce][i] += mat[cine][i] * x;

		if(mat[ce][i] < eps && mat[ce][i] > -eps)
		{
			mat[ce][i] = 0;
		}
	}
}

void interschimbaLinii(int nr1, int nr2)
{
	for(int i = 0; i <= m; i++)
	{
		swap(mat[nr1][i], mat[nr2][i]);
	}
}

bool schimbaLiniiInCazDe0(int x)
{
	for(int i = x + 1; i < n; i++)				
	{
		if(mat[i][x] != 0)
		{
			interschimbaLinii(x, i);
			return true;
		}
	}

	return false;
}

void afisareDebug()
{
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j <= m; j++)
		{
			printf("%lf ", mat[i][j]);
		}
		printf("\n");
	}
}

void afisare()
{
	for(int i = 0; i < n; i++)
	{
		printf("%lf ", mat[i][m] / mat[i][i]);
	}

	float zz = 0;

	for(int i = n; i < m; i++)
	{
		printf("%lf ", zz);
	}
}

bool isValid1()
{
	for(int i = m; i < n; i++)
	{
		double sum = 0;				

		for(int j = 0; j < m; j++)
		{
			sum += matx[i][j] * mat[j][m];
		}

		if((sum - matx[i][m]) < eps)
		{
			return false;
		}
	}

	return true;
}

bool solvex(int dim)
{
	for(int i = 0; i < dim; i++)
	{
		if(mat[i][i] == 0)
		{
			if(schimbaLiniiInCazDe0(i) == false)
			{
				return false;
			}
		}

		for(int j = i + 1; j < n; j++)
		{
			if(mat[j][i] != 0)
			{
				adunaLinie(i, j, -mat[j][i] / mat[i][i]);
			}
		}
	}

	for(int i = dim - 1; i  >= 0; i--)
	{
		for(int j = i - 1; j >= 0; j--)
		{
			if(mat[j][i] != 0)
			{
				adunaLinie(i, j, -mat[j][i] / mat[i][i]);
			}
		}
	}

	return true;
}

void swapCol(int nr1, int nr2)
{
	for(int i = 0; i < n; i++)
	{
		swap(mat[i][nr1], mat[i][nr2]);
	}
}

void solve()
{
	if(n == m)
	{
		if(solvex(n) == false)
		{
			printf("Imposibil");
		}
	}
	if(n < m)
	{
		bool ok = false;
		
		for(int k = 0; k < m; k++)
		{
			for(int i = 0; i < n; i++)	
			{
				for(int j = 0; j <= m; j++)
				{
					mat[i][j] = matx[i][j];
				}
			}		

			swapCol(k, m);

			if(solvex(n) == true)
			{
				ok = true;
				break;
			}
		}

		if(ok == false)
		{
			printf("Imposibil");
			return;
		}

	}
	else if(n > m)
	{
		if(solvex(m) == false)
		{
			printf("Imposibil");
			return;
		}

		if(isValid1() == false)	
		{
			printf("Imposibil");
			return;
		}
	}

	afisare();
}

int main()
{
	freopen("gauss.in", "r", stdin);
	freopen("gauss.out", "w", stdout);

	citire();
	solve();
	
	return 0;
}
