#include <fstream>
#include <math.h>
#include <iomanip>

using namespace std;
const int nmax = 300;
const int mmax = 300;
const double eps = 1e-2;

double a[nmax][mmax + 1];
double ans[mmax];

int zero ( double x ) {
    return ( ( x > 0 ? x : -x ) <= eps );
}

ifstream fin ( "gauss.in" );
ofstream fout ( "gauss.out" );

int main() {
    int n, m;
    fin >> n >> m;
    for ( int i = 0; i < n; i++ )
        for ( int j = 0; j <= m; j++ )
            fin >> a[i][j];

    for ( int j = 0; j < m; j++ ) {
        int pivot = j;
        while ( pivot < n && zero ( a[pivot][j] ) )
            pivot++;
        if ( pivot < n ) {
            swap ( a[pivot], a[j] );
            for ( int i = 0; i < n; i++ )
                if ( i != j ) {
                    double coef = a[i][j] / a[j][j];
                    for ( int k = 0; k <= m; k++ )
                        a[i][k] -= coef * a[j][k];
                }
        }
    }

    for ( int i = 0; i < m; i++ )
        if ( !zero ( a[i][i] ) )
            ans[i] = a[i][m] / a[i][i];

    for ( int i = 0; i < n; i++ ) {
        for ( int j = 0; j < m; j++ )
            a[i][m] -= a[i][j] * ans[j];
        if ( ! zero ( a[i][m] ) ) {
            fout << "Imposibil\n";
            return 0;
        }
    }

    for ( int i = 0; i < m; i++ )
        fout << fixed << setprecision ( 10 ) << ans[i] << ' ';

    return 0;
}
