#include <bits/stdc++.h>

using namespace std;
using ld = long double;
const ld eps = 1e-10;
vector <ld> solve(vector <vector <ld>>& a) {
    int n = a.size(), m = a[0].size() - 1;
    vector <int> found(m, -1);
    for(int r = 0, c = 0; r < n && c < m; c++) {
        int x = r;
        for(int i = r + 1; i < n; i++)
            if(abs(a[i][c]) > abs(a[x][c]))
                x = i;
        swap(a[x], a[r]);
        if(abs(a[r][c]) < eps) continue;
        found[c] = r;
        for(int i = 0; i < n; i++) if(i != r) {
            ld w = a[i][c] / a[r][c];
            for(int j = c; j <= m; j++)
                a[i][j] -= a[r][j] * w;
        }
        r++;
    }
    vector <ld> sol(m, 0);
    for(int i = 0; i < m; i++)
        if(found[i] > -1)
            sol[i] = a[found[i]][m] / a[found[i]][i];
    for(int i = 0; i < n; i++) {
        ld sum = 0;
        for(int j = 0; j < m; j++)
            sum += a[i][j] * sol[j];
        if(abs(sum - a[i][m]) >= eps)
            return {};
    }
    return sol;
}

int main()
{
    #ifndef HOME
    ifstream cin("gauss.in");
    ofstream cout("gauss.out");
    #endif // HOME
    int n, m;
    cin >> n >> m;
    vector <vector <ld>> a(n, vector <ld>(m + 1));
    for(int i = 0; i < n; i++)
        for(int j = 0; j <= m; j++)
            cin >> a[i][j];
    vector <ld> sol;
    sol = solve(a);
    if(sol.empty()) cout << "Imposibil";
    else for(ld x : sol) cout << fixed << setprecision(10) << x << " ";
    return 0;
}
