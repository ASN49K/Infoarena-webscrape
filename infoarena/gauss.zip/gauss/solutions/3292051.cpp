#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");
const long double EROARE = 1e-10;
long double x[302], a[302][302];
int n, m, i, j, l, k;

int main(){
    fin >> n >> m;

    for(i = 1; i <= n; i++) {
        for(j = 1; j <= m + 1; j++) fin >> a[i][j];
    }

    i = j = 1;
    while(i <= n && j <= m) {
        bool ok = false;
        for(l = i; l <= n && !ok; l++) {
            if(-EROARE <= a[l][j] && a[l][j] <= EROARE) ok = true;
        }

        if(!ok) j++;
        else {
            l--;
            if(l != i) {
                for(k = 1; k <= m + 1; k++) swap(a[l][k], a[i][k]);
            }


            for(k = j + 1; k <= m + 1; k++) a[i][k] /= a[i][j];
            a[i][j] = 1;


            for(l = i + 1; l <= n; l++) {
                for(k = j + 1; k <= m + 1; k++) a[l][k] -= a[i][k] * a[l][j];
                a[l][j] = 0;
            }

            i++;
            j++;
        }
    }



    for(i = n; i >= 1; i--) {
        for(j = 1; j <= m + 1; j++) {
            if(a[i][j] < -EROARE || EROARE < a[i][j]) {
                if(j == m + 1) {
                    fout << "Imposibil";
                    return 0;
                }

                x[i] = a[i][m + 1];
                for(k = j + 1; k <= m; k++) {
                    x[i] += a[i][k] * x[k];
                }

                break;
            }
        }
    }

    fout << setprecision(12) << fixed;
    for(i = 1; i <= m; i++) fout << x[i] << " ";

    return 0;
}
