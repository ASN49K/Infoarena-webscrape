#include <bits/stdc++.h>
#define eps 1e-8
using namespace std;
int m,n,i,j,p[310],c,l;
double a[310][310],ans[310],C;
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&m,&n);
    for(i=1; i<=m; ++i)
        for(j=1; j<=n+1; ++j)
            scanf("%lf",&a[i][j]);
    for(i=1; i<=m; ++i)
    {
        for(j=1; j<=n+1; ++j)
            if(abs(a[i][j])>eps)break;
        if(j==n+2)continue;
        if(j==n+1)
        {
            printf("Imposibil");
            return 0;
        }
        p[i]=j;
        for(l=1; l<=m; ++l)
            if(l!=i&&abs(a[l][p[i]])>eps)
            {
                C=a[l][p[i]]/a[i][p[i]];
                for(c=1; c<=n+1; ++c)
                    a[l][c]-=C*a[i][c];
            }
    }
    for(i=1; i<=m; ++i)
        if(p[i]!=0)ans[i]=a[i][n+1]/a[i][p[i]];
    for(i=1; i<=n; ++i)
        printf("%.10f ", ans[i]);
    return 0;
}

