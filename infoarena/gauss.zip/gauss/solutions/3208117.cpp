#include <bits/stdc++.h>

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
typedef long double ld;
const ld EPS=1e-15;
bool use[305];
ld v[305][305],sol[305];
int n,m;
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    if(m<n)
    {
        fout<<"Imposibil";
        return 0;
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>v[i][j];
    int i=1;
    int j=1;
    while(j<=m)
    {
        int ind=0;
        for(int k=i;k<=n;k++)
            if(abs(v[k][j]-0.0)>EPS)
            {
                ind=k;
                break;
            }
        if(ind==0)
        {
            j++;
            continue;
        }
        swap(v[i],v[ind]);
        ld val=v[i][j];
        for(int a=1;a<=m+1;a++)
            v[i][a]/=val;
        for(int z=i+1;z<=n;z++)
        {
            ld u=v[z][j];
            for(int a=1;a<=m+1;a++)
                v[z][a]-=v[i][a]*u;
        }
        i++;
        j++;
    }
    for(int i=n;i>=1;i--)
    {
        int ind=0;
        ld suma=0;
        for(int j=1;j<=m;j++)
            if(abs(v[i][j]-0.0)>EPS)
            {
                if(use[j])
                {
                    suma+=v[i][j]*sol[j];
                    continue;
                }
                use[ind]=1;
                ind=j;
            }
        if(ind==0)
        {
            if(abs(suma-v[i][m+1])>EPS)
            {
                fout<<"Imposibil";
                return 0;
            }
            continue;
        }
        use[ind]=1;
        sol[ind]=(-suma+v[i][m+1])/v[i][ind];
    }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(12)<<sol[i]<<' ';
    return 0;
}
