#include <bits/stdc++.h>
using namespace std;

#define PER(i,a) for (int i = a - 1; i >= 0; i--)
#define REP(i,a) for (int i = 0; i < a; i++)
#define FOR(i,a,b) for (int i = a; i <= b; i++)
#define ROF(i,a,b) for (int i = a; i >= b; i--)
#define FOREACH(it,x) for (__typeof((x).begin()) it = (x).begin(); it != (x).end(); it++)
#define all(x) (x).begin(),(x).end()
#define ll long long
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define pii pair<int,int>
#define SZ(x) ((int)(x).size())

const double eps = 1e-8;

inline bool eq(double a,double b) {
    return fabs(a-b) < eps;
}

int N,M;
double A[305][305],X[305];

int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);

    scanf("%d%d",&N,&M);
    FOR(i,1,N) FOR(j,1,M+1) scanf("%lf",&A[i][j]);

    int ecu = 1, nec = 1,k;
    while (ecu <= N && nec <= M) {
        for (k = ecu; k <= N; k++) if (eq(A[k][nec],0) == 0) break;
        if (k == N+1) { nec++; continue; }
        if (k != ecu) FOR(j,nec,M+1) swap(A[ecu][j],A[k][j]);
        FOR(j,nec+1,M+1) A[ecu][j] /= A[ecu][nec];
        A[ecu][nec] = 1;
        FOR(i,ecu+1,N) {
            FOR(j,nec+1,M+1) A[i][j] -= A[i][nec] * A[ecu][j];
            A[i][nec] = 0;
        }
        ecu++, nec++;
    }

    ROF(ecu,N,1) FOR(nec,1,M+1) {
        if (eq(A[ecu][nec],0) == 0) {
            if (nec == M+1) {
                puts("Imposibil");
                return 0;
            }
            X[nec] = A[ecu][M+1];
            FOR(j,nec+1,M) X[nec] -= X[j] * A[ecu][j];
            break;
        }
    }

    FOR(i,1,M) printf("%.10f ",X[i]);
}
