#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("gauss.in");
ofstream fout ("gauss.out");

int n,m;
double a[305][305],rez[305];

bool iszero(double x)
{
    const int eps=0.0000001;
    if (x<-eps || x>eps)
        return false;
    return true;
}

void swaplines(int l1,int l2)
{
    if (l1!=l2)
    {
        for (int j=1;j<=m+1;j++)
        {
            int aux=a[l1][j];
            a[l1][j]=a[l2][j];
            a[l2][j]=aux;
        }
    }
}

int main()
{
    fin>>n>>m;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m+1;j++)
            fin>>a[i][j];
    int i=1,j=1;
    while (i<=n&&j<=m)
    {
        int x;
        for (x=i;x<=n;x++)
            if (!iszero(a[x][j]))
                break;
        if (x==n+1)
            j++;
        else
        {
            swaplines(i, x);
            double aux=a[i][j];
            for (int col=1;col<=m+1;col++)
            {
                a[i][col]/=aux;
            }
            a[i][j]=1;
            for (int u=i+1;u<=n;u++)
            {
                double aux=a[u][j];
                for (int col=1;col<=m+1;col++)
                    a[u][col]-=(aux*a[i][col]);
                a[u][j]=0;
            }
            i++;
            j++;
        }
        /*for (int l=1;l<=n;l++)
        {
            for (int c=1;c<=m+1;c++)
                fout<<a[l][c]<<' ';
            fout<<'\n';
        }
        fout<<'\n';*/
    }
    for (int l=n;l>=1;l--)
    {
        int c;
        for (c=1;c<=m;c++)
            if (!iszero(a[l][c]))
                break;
        if (c==m+1&&a[l][m+1]!=0)
        {
            fout<<"Imposibil\n";
            return 0;
        }
        double x=a[l][m+1];
        for (int col=m;col>c;col--)
            x-=a[l][col]*rez[col];
        rez[c]=x;
    }
    for (int i=1;i<=m;i++)
        fout<<setprecision(8)<<fixed<<rez[i]<<' ';
    fout<<'\n';
    return 0;
}
