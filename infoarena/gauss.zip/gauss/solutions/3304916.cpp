#include <bits/stdc++.h>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
#endif  // ST_DIO

const double EROARE = 1e-10;

double ec[302][302], rasp[302];
double val[302];

int n, m, i, j, k, kk;
int lin[302];

static inline double Modul(double cur) {
    return (cur < 0 ? -cur : cur);
}

int main() {
    if(ST_DIO) ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m;
    for(i = 1; i <= n; i++) {
        for(j = 1; j <= m; j++) fin >> ec[i][j];
        fin >> val[i];
    }

    for(j = 1; j <= m; j++) {
        lin[j] = -1;
        rasp[j] = 0;
    }

    int i = 1, j = 1;
    while(i <= n && j <= m) {
        int poz = i;
        for(int k = i; k <= n; k++){
            if(Modul(ec[k][j]) > Modul(ec[poz][j])) poz = k;
        }

        if(Modul(ec[poz][j]) >= EROARE) {
            for(k = 1; k <= m; k++) swap(ec[i][k], ec[poz][k]);

            swap(val[i], val[poz]);
            lin[j] = i;

            for(k = 1; k <= n; k++) {
                if(k != i) {
                    double temp = ec[k][j] / ec[i][j];
                    for(kk = j; kk <= m; kk++) ec[k][kk] -= ec[i][kk] * temp;
                    val[k] -= val[i] * temp;
                }
            }
            i++;
        }
        j++;
    }

    for(j = 1; j <= m; j++) {
        if(lin[j] != -1) rasp[j] = val[lin[j]] / ec[lin[j]][j];
    }

    for(i = 1; i <= n; i++) {
        double temp = 0;
        for(j = 1; j <= m; j++) temp += rasp[j] * ec[i][j];
        if(Modul(temp - val[i]) > EROARE) {
            fout << "Imposibil";
            return 0;
        }
    }

    for(i = 1; i <= m; i++) fout << setprecision(10) << fixed << rasp[i] << " ";

    return 0;
}
