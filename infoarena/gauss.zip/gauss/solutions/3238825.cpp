#include <fstream>
#include <iomanip>
#define eps 0.000000001
using namespace std;
ifstream fin ("gauss.in");
ofstream fout ("gauss.out");
int n,m,i,j,poz,p;
double val,sol[301],v[302][302];
int main ()
{
    fin>>n>>m;
    for (i=1; i<=n; i++)
    {
        for (j=1; j<=m+1; j++)
            fin>>v[i][j];
    }
    i=j=1; ///i=nr ecuatie j=nr necunoscuta
    while (i<=n&&j<=m)
    {
        ///prima ecuatie fara 0 pe poz j
        for (poz=i; poz<=n; poz++)
        {
            if (!(v[poz][j]<eps&&v[poz][j]>-eps))
                break;
        }
        if (poz==n+1)
        {
            j++;    ///sol[j]=0 (poate fi oricat)
            continue;
        }
        if (poz!=i)
            swap (v[i],v[poz]);
        val=v[i][j];
        for (p=j; p<=m+1; p++)
            v[i][p]/=val; ///v[i][j]=1;
        for (poz=i+1; poz<=n; poz++)
        {
            for (p=j+1; p<=m+1; p++)
                v[poz][p]+=-v[i][p]*v[poz][j]; ///v[i]*=v[poz][j]
            v[poz][j]=0;
        }
        i++;
        j++;
    }
    j=m+2;
    for (i=n; i>0; i--)
    {
        ///prima poz nenula
        while (j>1&&!(v[i][j-1]<eps&&v[i][j-1]>-eps))
            j--;
        if (j==m+2) ///totul e 0
            continue;
        if (j==m+1)
        {
            fout<<"Imposibil";
            return 0;
        }
        sol[j]=v[i][m+1];
        for (p=j+1; p<=m; p++)
            sol[j]-=sol[p]*v[i][p];
    }
    for (j=1; j<=m; j++)
        fout<<fixed<<setprecision (10)<<sol[j]<<" ";
    return 0;
}
