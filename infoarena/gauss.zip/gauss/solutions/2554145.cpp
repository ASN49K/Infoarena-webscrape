#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n, m;
vector<double> gau[314];

double sol[314];

void div(vector<double> &v, double a){
	for(auto &b : v){
		b /= a;
	}
}

void sum(vector<double> &v1, const vector<double> &v2, double a){
	for(int i = 0; i < v1.size(); ++i){
		v1[i] += a*v2[i];
	}
}

void deb(){
	for(int i = 0; i < n; ++i){
		for(auto a : gau[i]){
			cout << a << "\t";
		}
		cout << "\n";
	}
}

bool sic(double a, double b){
	return abs(a-b) <= 0.00000001;
}

bool CheckYoSelf(){
	for(int i = 0; i < n; ++i){
		double s = 0;
		for(int j = 0; j < m; ++j){
			s += gau[i][j];
		}
		if(sic(s, 0) && !sic(gau[i][m], 0)){
			return false;
		}
	}
	return true;
}

void solve(){
	for(int i = 0; i < n; ++i){
		sol[i] = gau[i][m];
	}
}

int main(){
	ios_base::sync_with_stdio(false);
	fin >> n >> m;
	for(int i = 0; i < n; ++i){
		for(int j = 0; j <= m; ++j){
			double a;fin >> a;
			gau[i].push_back(a);
		}
	}
	
	for(int i = 0; i < m; ++i){
		bool found = false;
		for(int j = i; j < n; ++j){
			if(gau[j][i] != 0){
				// swap(gau[j], gau[i]);
				gau[j].swap(gau[i]);
				found = true;
				break;
			}
		}
		if(found){
			div(gau[i], gau[i][i]);
			for(int j = 0; j < n; ++j){
				if(j != i){
					sum(gau[j], gau[i], -gau[j][i]);
				}
			}
		}
	}
	
	bool fml = CheckYoSelf();
	if(fml){
		fout << setprecision(10) << fixed;
		solve();
		for(int i = 0; i < m; ++i){
			fout << sol[i] << " ";
		}
	}else{
		fout << "Imposibil";
	}	
	return 0;
}