#include <fstream>
#include <iomanip>

using namespace std;

const int NMAX = 300;
const int MMAX = 300;

const double EPS = 0.0000001;

double coef[1 + NMAX][1 + MMAX + 1];
double solutie[1 + MMAX];

int main()
{
    ifstream in("gauss.in");
    ofstream out("gauss.out");

    int n, m;
    in >> n >> m;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m + 1; j++)
        {
            in >> coef[i][j];
        }
    }

    in.close();

    int linie = 1;

    for (int coloana = 1; coloana <= m + 1 && linie <= n; coloana++)
    {
        int linieCrt = linie;

        while (linieCrt <= n && abs(coef[linieCrt][coloana]) < EPS)
            linieCrt++;

        if (linieCrt <= n)
        {
            for (int j = 1; j <= m + 1; j++)
                swap(coef[linie][j], coef[linieCrt][j]);

            double impartitor = coef[linie][coloana];

            for (int j = 1; j <= m + 1; j++)
                coef[linie][j] /= impartitor;

            for (int i = linie + 1; i <= n; i++)
            {
                int pozNeNula = 0;

                for (int j = 1; j <= m + 1 && pozNeNula == 0; j++)
                    if (abs(coef[i][j]) >= EPS)
                        pozNeNula = j;

                if (pozNeNula != 0)
                {
                    double coeficient = coef[i][pozNeNula];

                    for (int j = 1; j <= m + 1; j++)
                    {
                        coef[i][j] -= coeficient * coef[linie][j];
                    }
                }
            }

            linie++;
        }
    }

    bool existaSolutie = true;

    for (int linie = n; linie >= 1 && existaSolutie; linie--)
    {
        int pozNeNula = 0;

        for (int j = 1; j <= m + 1 && pozNeNula == 0; j++)
            if (abs(coef[linie][j]) >= EPS)
                pozNeNula = j;

        if (pozNeNula == m + 1)
            existaSolutie = false;

        if (pozNeNula <= m)
        {
            solutie[pozNeNula] = coef[linie][m + 1];
            for (int coloana = m; coloana > pozNeNula; coloana--)
                solutie[pozNeNula] -= coef[linie][coloana] * solutie[coloana];
        }
    }

    if (!existaSolutie)
        out << "Imposibil";
    else
    {
        for (int i = 1; i <= m; i++)
            out << setprecision(8) << fixed << solutie[i] << ' ';
        out << '\n';
    }

    out.close();

    return 0;
}
