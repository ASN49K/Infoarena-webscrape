#include <bits/stdc++.h>
#define eps 1e-8
using namespace std;
const int NMAX = 300 + 5;
double a[NMAX][NMAX],sol[NMAX];
int n,m,pos[NMAX];
inline int iszero(double x) {
    if (x + eps < 0)return -1;
    if ( eps <x) return 1;
    return 0;
}
int main() {
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);

    scanf("%d %d\n", &n, &m);
    for (int i = 1; i<=n; ++i)
        for (int j = 1; j<=m + 1; ++j)
            scanf("%lf", &a[i][j]);
    for (int i = 1; i<=n; ++i) {
        int j;
        pos[i] = 0;
        for (j = 1 ; j <= m + 1&&iszero(a[i][j])==0; ++j);
        if (j == m+1) {
            printf("Imposibil");
            return 0;
        }
        pos[i] = j;

        for ( j = 1; j<=n; ++j) {
            if (i==j || iszero(a[j][pos[i]])==0) continue;
            double coef = a[j][pos[i]] / a[i][pos[i]];
            for (int k = 1; k <= m + 1; ++k)
                a[j][k] -= coef*a[i][k];
        }
    }
    for (int i = 1; i<=n; ++i)
        if(pos[i])
            sol[pos[i]] = a[i][m+1] / a[i][pos[i]];
    for (int i = 1; i<=m; ++i)
        printf("%.10f ", sol[i]);
    printf("\n");
    return 0;
}
