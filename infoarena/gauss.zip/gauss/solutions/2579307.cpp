#include <bits/stdc++.h>

using namespace std;

struct Gauss {
  vector<vector<double>> eqs;
  vector<int> fixed;

  int Add(vector<double> a, double b) {
    int n = a.size();
    a.push_back(b);

    for (int i = 0; i < (int)eqs.size(); ++i) {
      double coef = a[fixed[i]] / eqs[i][fixed[i]];
      if (abs(coef) < 1e-9) continue;
      for (int j = 0; j <= n; ++j)
        a[j] -= eqs[i][j] * coef;
    }
    
    for (int i = 0; i < n; ++i) {
      double coef = a[i];
      if (abs(coef) < 1e-9) continue;
      fixed.push_back(i);
      eqs.push_back(a);
      return 1;
    }

    return (abs(a.back()) < 1e-9) ? 0 : -1;
  }

  vector<double> Solve() {
    int n = eqs[0].size() - 1;
    vector<double> sol(n, 0);
    for (int i = (int)eqs.size() - 1; i >= 0; --i) {
      double ans = eqs[i][n];
      for (int j = 0; j < n; ++j)
        ans -= eqs[i][j] * sol[j];
      sol[fixed[i]] = ans / eqs[i][fixed[i]];
    }
    return sol;
  }
};

int main() {
  ifstream cin("gauss.in");
  ofstream cout("gauss.out");
  
  int n, m; cin >> n >> m;
  Gauss gauss;
  for (int i = 0; i < n; ++i) {
    vector<double> a(m); double b; 
    for (int j = 0; j < m; ++j)
      cin >> a[j];
    cin >> b;
    if (gauss.Add(a, b) == -1) {
      cout << "Imposibil\n";
      return 0;
    }
  }
  auto sol = gauss.Solve();
  cout << fixed << setprecision(10);
  for (auto x : sol)
    cout << x << " ";
  cout << endl;
  return 0;
}
