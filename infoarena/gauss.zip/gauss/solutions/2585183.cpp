#include <bits/stdc++.h>
#define MAX 300 + 5

using namespace std;

double mat[MAX + 5][MAX + 5], sol[MAX + 5];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m + 1; j++)
            fin >> mat[i][j];

    for(int j = 1; j <= m; j++)
    {
        bool semafor = false;

        int i;
        for(i = j; !semafor && i <= n; i++)
            if(mat[i][j])semafor = true;

        if(semafor)
        {
            i--;
            swap(mat[i], mat[j]);

            double bias = mat[j][j];
            for(int k = j; k <= m + 1; k++)mat[j][k] /= bias;

            for(int k = j + 1; k <= n; k++)
            {
                double bias = mat[k][j];

                for(int l = j; l <= m + 1; l++)
                    mat[k][l] -= bias * mat[j][l];
            }
        }
    }

    bool eValid = true;
    for(int i = n; eValid && i >= 1; i--)
    {
        bool eGol = true;

        for(int j = 1; eGol && j <= m; j++)
            if(mat[i][j])eGol = false;

        if(eGol && mat[i][m + 1])eValid = false;
        else
        {
            int j;
            double suma = 0;

            for(j = m; mat[i][j]; j--)
                suma += sol[j] * mat[i][j];

            j++;
            sol[j] = (mat[i][m + 1] - suma) / mat[i][j];
        }
    }

    if(!eValid)fout << "Imposibil";
    else
    {

        fout << fixed;
        fout.precision(10);

        for(int i = 1; i <= m; i++)fout << sol[i] << ' ';
    }

    fin.close();
    fout.close();

    return 0;
}
