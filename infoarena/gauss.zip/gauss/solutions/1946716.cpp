#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdio>
using namespace std;

#define LD double
#define EPS 0.000000001
int N,M;
int main(){
	LD a[310][310],x[310];
	memset(x,0,sizeof(x));
	memset(a,0,sizeof(a));
	
	int i,j,k;
	freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);
	scanf("%d %d",&N,&M);
  
    for(int i = 1; i <= N; ++i)
        for(int j = 1; j <= M+1; ++j)
            scanf("%lf", &a[i][j]);
	
	for (j=1; j<=min(N,M); j++){
		int ind=-1;
		for (i=j; i<=N; i++)
			if (a[i][j]<-EPS || a[i][j]>EPS){
				ind=i;
				break;
			}
		
		if (ind==-1) continue;
		for (k=1; k<=M+1; k++)
			swap(a[j][k],a[ind][k]);
			
		for (i=ind+1; i<=N; i++){
			LD coef=-a[i][j]/a[ind][j];
			for (k=j; k<=M+1; k++)
				a[i][k]+=coef*a[ind][k];
		}
	}
	
	
	
	for (i=N; i>0; i--){
		for (j=1; j<=M+1; j++)
			if (a[i][j]<-EPS || a[i][j]>EPS){
				if (j==M+1){
					printf("Imposibil\n");
					return 0;
				}
				
				x[j]=a[i][M+1];
				for (k=j+1; k<=M; k++)
					x[j]-=x[k]*a[i][k];
				x[j]/=a[i][j];
				break;
			}
	}
	
	for (i=1; i<=M; i++)
		printf("%.8lf ",x[i]);
	printf("\n");
	return 0;
}
