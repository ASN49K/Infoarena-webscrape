#include <bits/stdc++.h>

using namespace std;
ifstream fin ("gauss.in");
ofstream fout ("gauss.out");

int n,m,i,j;
long double a[305][305];
long double rez;
long double ans[305];

void swapf(int i, int i2)
{
    for(int j=1; j<=m; j++)
        swap(a[i][j], a[i2][j]);
}
void zero(int col, int lin1, int lin2)
{
    long double nr=a[lin2][col]/a[lin1][col];

    for(int i=1; i<=m; i++)
        a[lin2][i]-=a[lin1][i]*nr;
}
int main()
{
    fin>>n>>m;
    m++;

    for(i=1; i<=n; i++)
        for(j=1; j<=m; j++)
            fin>>a[i][j];

    long double er=pow(10, -10);
    for(j=1; j<m; j++)
    {
        if(abs(a[j][j])<=er)
        {
            for(i=j+1; i<=n; i++)
                if(abs(a[i][j])>er)
                {
                    swapf(j, i);
                    break;
                }
        }

        for(i=j+1; i<=n; i++)
            zero(j, j, i);

        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
                cout<<a[i][j]<<' ';
            cout<<'\n';
        }
        cout<<'\n';
    }

    for(j=m-1; j>=1; j--)
    {
        rez=a[j][m];
        for(i=j+1; i<m; i++)
            rez-=(long double)a[j][i]*ans[i];

        //cout<<j<<' '<<rez<<' '<<a[j][j]<<'\n';

        if(!a[j][j])
            ans[j]=0;
        else
            ans[j]=rez/((long double)a[j][j]);

        rez-=(double)a[j][j]*ans[j];

        if(abs(rez)>er)
        {
            fout<<"Imposibil";
            return 0;
        }
    }

    fout.precision(12);
    for(i=1; i<m; i++)
        fout<<ans[i]<<' ';
    return 0;
}
