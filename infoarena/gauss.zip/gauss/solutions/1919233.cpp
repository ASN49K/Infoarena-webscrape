#include <bits/stdc++.h>
using namespace std;

constexpr bool is_zero(const double d){
    return -1e-3 <= d && d <= 1e-3; }

ifstream f("gauss.in");
ofstream g("gauss.out");
int n, m;
vector<double> rez;
vector<vector<double>> mat;

void do_gauss(){
    for(int ec = 0, var = 0; ec < n && var < m; ){
        if(is_zero(mat[ec][var])){
            int ec_ = ec;
            while(ec_ < n && is_zero(mat[ec][var])) ++ec_;
            if(ec_ == n){
                ++var;
                continue; }
            else swap(mat[ec], mat[ec_]); }
        for(int i = ec+1; i < n; ++i){
            const double tmp = mat[i][var] / mat[ec][var];
            for(int j = var; j <= m; ++j) mat[i][j] -= mat[ec][j] * tmp; }
        ++var, ++ec; } }

int main(){
    f >> n >> m;
    rez.resize(m, 0);
    mat.resize(n, vector<double>(m+1, (double)0));
    for(auto& x : mat)
        for(auto& y : x) f >> y;
    do_gauss();

    if(any_of(begin(mat), end(mat), [](const vector<double>& v){
        return all_of(begin(v), end(v)-1, &is_zero) && !is_zero(v[m]); })){
        g << "Imposibil" << endl;
        return 0; }
    for(int i = n-1; i >= 0; --i){
        int j = 0;
        while(j < m && is_zero(mat[i][j])) ++j;
        auto& cur = rez[j], ddiv = mat[i][j];
        cur = mat[i][m];
        for(++j; j < m; ++j) cur -= rez[j] * mat[i][j];
        cur /= ddiv; }
    g << fixed << setprecision(8);
    copy_n(begin(rez), m, ostream_iterator<double>(g, " "));
    return 0; }
