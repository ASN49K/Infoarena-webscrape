#include<bits/stdc++.h>
using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
const int N = 305;
const double eps = 0.0000000001;
int n,m,i,j,ecu,nec,ecuatie[N];
double a[N][N],*ec[N];

int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    for(i=0;i<=n;i++)
        ec[i]=a[i];
    ecu=1;nec=1;
    //sunt la necunoscuta nec si la ecuatia ecu
    //toate celelalte necunoscute au fost rezolvate
        //- fie sunt secundare fie au fost rezolvate de una dintre cele ecu-1 ecuatii anterioare
    while(ecu<=n&&nec<=m)
    {
        for(i=ecu;i<=n;i++)
            if(abs(ec[i][nec])>eps)
                break;
        if(i==n+1)
        {
            ecuatie[nec]=0;
            nec++;continue;
        }
        swap(ec[i],ec[ecu]);
        for(j=m+1;j>=nec;j--)
            ec[ecu][j]/=ec[ecu][nec];
        for(i=1;i<=n;i++)
            if(i!=ecu)
                for(j=m+1;j>=nec;j--)
                    ec[i][j]-=ec[i][nec]*ec[ecu][j];
        ecuatie[nec]=ecu;
        ecu++;nec++;
    }
    for(i=ecu;i<=n;i++)
        if(abs(ec[i][m+1])>eps)
    {
        g<<"Imposibil";
        return 0;
    }
    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<ec[ecuatie[i]][m+1]<<' ';
    return 0;
}
