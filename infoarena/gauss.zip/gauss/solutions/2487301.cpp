#include <fstream>
#include <iomanip>
#include <iostream>
#define EPS 0.000000001
using namespace std;
ifstream fin("gauss.in");
ofstream fout ("gauss.out");

double a[110][110], sol[110], suma;
int n, m, t, i, j, ii, jj, aux, indice;

int main(){
    fin>>n>>m;
    for(i=1; i<=n; i++){
        for(j=1; j<=m+1; j++){
            fin>>a[i][j];
        }
    }
    i=1;
    j=1;
    while(i<=n && j<=m){

        /// caut element pe coloana diferit de 0
        for(ii=i; ii<=n; ii++){
            if(a[ii][j]){
                break;
            }
        }
        if(ii==n+1){
            /// element liber
            j++;
        }else{
            /// am gasit element nenul
            /// schimbam linia daca este cazul
            if(ii!=i){
                for(aux=1; aux<=m+1; aux++){
                    swap(a[i][aux], a[ii][aux]);
                }
            }
            /// a[i][j] este elementul nenul
            /// impartim elementele de pe linie la a[i][j]
            for(jj=j+1; jj<=m+1; jj++){
                a[i][jj]=a[i][jj]/a[i][j];
            }
            a[i][j]=1;
            /// obtinem zero sub acesta
            for(ii=i+1; ii<=n; ii++){
                for(jj=j+1; jj<=m+1; jj++){
                    a[ii][jj]=a[ii][jj]-a[i][jj]*a[ii][j];
                }
                a[ii][j]=0;
            }
            i++;
            j++;
        }
    }
    for(i=n; i>0; i--){
        /// verific linia
        indice=0;
        for(j=1; j<=m; j++){
            if(a[i][j]>EPS || a[i][j]<-EPS){
                indice=j;
                break;
            }
        }
        if(indice==0){
            /// linia este goala
            if(a[i][m+1]){
                fout<<"Imposibil";
                return 0;
            }else{
                /// infinitate de solutii, luam 0
            }
        }else{
            suma=0;
            for(j=indice+1; j<=m; j++){
                suma+=a[i][j]*sol[j];
                /// suma variabilelor fara cea cautata
            }
            sol[indice]=a[i][m+1]-suma;
        }
    }
    for(i=1; i<=m; i++){
        fout<<setprecision(10)<<fixed<<sol[i]<<" ";
    }
}
