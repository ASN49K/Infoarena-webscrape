#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

ifstream fin("apm.in");
ofstream fout("apm.out");

int main() {
    int n, m;
    fin >> n >> m;

    vector < vector < double > > v(n, vector < double > (m + 5));
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j <= m; ++j) {
            fin >> v[i][j];
        }
    }

    int l = 0;
    for(int i = 0; i < n; ++i) {
        bool found = false;
        int pos;
        while(!found && l < m) {
            found = false;
            for(int j = i; j < n; ++j) {
                if(v[j][l] != 0) {
                    found = true;
                    pos = j;
                    break;
                }
            }
            if(found == false) {
                ++l;
            }
        }
        
        if(l == m) {
            break;
        } else {
            swap(v[i], v[pos]);
            for(int j = i + 1; j < n; ++j) {
                double coef = -v[j][l] / v[i][l];
                for(int k = l; k <= m; ++k) {
                    v[j][k] += coef * v[i][k];
                }
            }
            ++l;
        }
    }  
    if(l < m) {
        fout << "Imposibil\n";
        exit(0);
    }

    vector < double > ans(m, 0);
    for(int i = n - 1; i >= 0; --i) {
        for(int j = 0; j < m; ++j) {
            if(v[i][j] != 0) {
                for(int k = j + 1; k < m; ++k) {
                    double val = v[i][k] * ans[k];
                    v[i][m] -= val;
                }
                ans[j] = v[i][m] / v[i][j];
                break;
            }
        }
    }

    for(int i = 0; i < m; ++i) {
        fout << fixed << setprecision(10) << ans[i] << " ";
    }
    return 0;
}
