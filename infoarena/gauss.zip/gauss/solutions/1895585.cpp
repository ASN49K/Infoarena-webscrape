#include <iostream>
#include<fstream>
#include<iomanip>
using namespace std;
#define DIM 10000
#define E 0.000001
#define N 310
char buff[DIM];
int poz,i,j,l,k,n,m;
long double a[N][N],sol[N];
ifstream f("gauss.in");
inline void R(long double&x)
{
    x=0;
    bool ok=0;
    while(buff[poz]<'0' || buff[poz]>'9')
    {
        if(buff[poz]=='-')
            ok=1;
        if(++poz==DIM)
        {
            poz=0;
            f.read(buff,DIM);
        }
    }
    while(buff[poz]>='0' && buff[poz]<='9')
    {
        x=x*10+buff[poz]-'0';
        if(++poz==DIM)
        {
            poz=0;
            f.read(buff,DIM);
        }
    }
    if(ok)
        x=-x;
}
inline void r(int &x)
{
    x=0;
    while(buff[poz]<'0' || buff[poz]>'9')
        if(++poz==DIM)
        {
            poz=0;
            f.read(buff,DIM);
        }
    while(buff[poz]>='0' && buff[poz]<='9')
    {
        x=x*10+buff[poz]-'0';
        if(++poz==DIM)
        {
            poz=0;
            f.read(buff,DIM);
        }
    }
}
int main()
{
    r(n);r(m);
    for(i=0;i<n;++i)
        for(j=0;j<m+1;++j)
        R(a[i][j]);
    i=0;j=0;
    while(i<n && j<m)
    {
        for(k=i;k<n;++k)  ///cautare linie pentru care a[k][j] diferit de 0
            if(-E>a[k][j] || a[k][j]>E)
                break;
        if(j==n)///nu am gasit linie,deci trec la coloana urmatoare
        {
            ++j;
            continue;
        }
        if(k>i)///interschimbare intre liniile i si k
        {
            for(l=0;l<m+1;++l)
                swap(a[k][l],a[i][l]);
        }
        ///simplificarea liniei i prin a[i][j]
        ///Observam ca valorile de pe linia i si coloanele 1..j-1 sunt egale cu 0 de la pasii precedenti ai algoritmului,
        ///deci nu e necesar sa le parcurgem pentru a le imparti.
        for(l=j+1;l<m+1;++l)
            a[i][l]/=a[i][j];
        a[i][j]=1;
        ///obtinere de 0 pe coloana j in toate liniile u>i prin scaderea liniei i *a[k][j]
        for(k=i+1;k<n;++k)
        {
            for(l=j+1;l<m+1;++l)
                a[k][l]-=a[k][j]*a[i][l];
            a[k][j]=0;
        }
        ++i;++j;
    }
    ///calculul necunoscutelor
    for(i=n-1;i>-1;--i)
        for(j=0;j<m+1;++j)///cautarea primei valori nenule de pe linia i
            if(-E>a[i][j] || a[i][j]>E)
            {
                if(j==m)///doar rezultatul e nenul =>nu exista solutie
                {
                    ofstream g("gauss.out");g<<"Imposibil\n";
                    return 0;
                }
                sol[j]=a[i][m];
                for(l=j+1;l<m;++l)///din rezultatul total scad celelalte variabile
                    sol[j]-=a[i][l]*sol[l];
                break;
            }
    ofstream g("gauss.out");
    for(i=0;i<m;++i)
        g<<setprecision(10)<<sol[i]<<" ";
    return 0;
}
