#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
const double eps = 1e-10;
ifstream f("gauss.in");
ofstream g("gauss.out");
double m[301][302], x[301];
int N, M;
void gauss()
{
    int i=1,j=1;
    while(i<=N || j<=M)
    {
        if(abs(m[i][j])<=eps)
        {
            bool ok=0;
            for(int k=i+1; k<=N; k++)
                if(abs(m[k][i])>eps)
                {
                    ok=1;
                    for(int l=j; l<=M+1; l++)
                        swap(m[i][l],m[k][l]);
                    break;
                }
            if(ok==0)
            {
                j++;
                continue;
            }
        }
        for(int k=j+1; k<=M+1; k++)
            m[i][k]/=m[i][j];
        m[i][j]=1;
        for(int k=i+1; k<=N; k++)
        {
            for(int l=j+1; l<=M+1; l++)
                m[k][l]-=m[i][l]*m[k][j];
            m[k][j]=0;
        }
        i++;
        j++;
    }

}
bool sol()
{
    for(int i = N; i >= 1; i--)
    {
        int ok = 0,j;
        for(j = i; j <= M; j++)
            if(abs(m[i][j])>eps)
            {
                ok = 1;
                x[j] = m[i][M + 1];
                break;
            }
        if(ok == 0 && abs(m[i][M + 1]) > eps)
            return 0;
        for(int k = j + 1; k <= M; k++)
            x[j] -= m[i][k] * x[k];
    }
    return 1;
}
void afisare()
{
    g<<fixed<<setprecision(10);
    for(int i=1; i<=M; i++)
        g<<x[i]<<' ';
}
int main()
{
    f>>N>>M;
    for(int i=1; i<=N; i++)
        for(int j=1; j<=M+1; j++)
            f>>m[i][j];
    gauss();
    if(sol())
    {
        afisare();
    }
    else g<<"Imposibil";
    return 0;
}
