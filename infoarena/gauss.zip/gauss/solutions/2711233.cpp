#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

const double EPS = 1e-10;
const int MAXN = 301;

int N, M;
double A[MAXN][MAXN + 1],
       X[MAXN];

void gauss()
{
    int i = 1, j = 1, k, p, u;
    while(i <= N && j <= M)
    {
        if(abs(A[i][j]) <= EPS)
        {
            ///Cautam o linie k pentru care A[k][j]!=0
            bool ok = 0;
            for(k = i + 1; k <= N; k++)
                if(abs(A[k][j]) > EPS)
                {
                    ok = 1;
                    for(p = j; p <= M + 1; p++)
                        swap(A[i][p], A[k][p]);
                    break;
                }
            ///Daca nu gasim => necunoscuta j este variabila libera,
            ///incrementam pe j (trecem la coloana urmatoare
            if(ok == 0) //if(k==N+1)
            {
                j++;
                continue;
            }
        }
        ///Impartim toate valorile de pe linia i la A[i][j], A[i][j] devenind 1
        ///(Valorile de pe linia i si coloanele 1...j-1 sunt deja 0)
        for(p = j + 1; p <= M + 1; p++)
            A[i][p] = A[i][p] / A[i][j];
        A[i][j] = 1.0;
        ///Scadem din ecuatiile i+1...N ecuatia i inmultita cu A[u][j]
        for(u = i + 1; u <= N; u++)
        {
            for(p = j + 1; p <= M + 1; p++)
                A[u][p] -= A[u][j] * A[i][p];
            A[u][j] = 0.0;
        }
        i++;
        j++;
    }

}

bool solutie()
{
    for(int i = N; i >= 1; i--)
        for(int j = i; j <= M + 1; j++)
            if(abs(A[i][j]) > EPS)///A[i][j]!=0
            {
                if(j == M + 1)
                    return 0;///Sistemul este incompatibil
                X[j] = A[i][M + 1]; ///Calculam necunoscuta j
                for(int k = j + 1; k <= M; k++)
                    X[j] -= X[k] * A[i][k];
                break;
            }
    return 1;
}

void afisare()
{
    g.setf(ios::fixed, ios::floatfield);
    g.precision(10);
    for(int i = 1; i <= M; i++)
        g << X[i] << ' ';
}

int main()
{
    f >> N >> M;
    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M + 1; j++)
            f >> A[i][j];
    //
    gauss();
    //
    if(solutie())
        afisare();
    else
        g << "Imposibil";
    return 0;
}
