#include <bits/stdc++.h>
using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

const int MAX = 400;
const double EPS = 1e-7;

double a[MAX][MAX], x[MAX];
int n, m;

int main() {
    // Citire dimensiuni
    in >> n >> m;

    // Citire matrice extinsă
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m + 1; j++)
            in >> a[i][j];

    // Eliminare Gauss cu pivotare parțială
    int i = 1, j = 1;
    while (i <= n && j <= m) {
        int k = i;
        while (k <= n && fabs(a[k][j]) < EPS) k++;

        // Coloana j nu conține pivot → variabilă liberă
        if (k == n + 1) {
            j++;
            continue;
        }

        // Schimbă linia curentă cu linia pivot (dacă e necesar)
        if (k != i)
            for (int l = 1; l <= m + 1; l++)
                swap(a[i][l], a[k][l]);

        // Normalizează linia pivot (face coeficientul pivot 1)
        for (int l = j + 1; l <= m + 1; l++)
            a[i][l] /= a[i][j];
        a[i][j] = 1;

        // Eliminare în restul liniilor sub pivot
        for (int u = i + 1; u <= n; u++) {
            for (int l = j + 1; l <= m + 1; l++)
                a[u][l] -= a[u][j] * a[i][l];
            a[u][j] = 0;
        }

        i++; j++;
    }

    // Inițializează soluția cu 0 (pentru variabilele libere)
    for (int i = 1; i <= m; i++) x[i] = 0;

    // Substituție inversă pentru aflarea necunoscutelor
    for (int i = n; i > 0; i--) {
        for (int j = 1; j <= m + 1; ++j) {
            if (fabs(a[i][j]) > EPS) {
                // Dacă singurul coeficient nenul e termenul liber => imposibil
                if (j == m + 1) {
                    out << "Imposibil\n";
                    return 0;
                }

                // Calculează necunoscuta j
                x[j] = a[i][m + 1];
                for (int k = j + 1; k <= m; k++)
                    x[j] -= x[k] * a[i][k];
                break;
            }
        }
    }

    // Afișează soluția
    out << fixed << setprecision(8);
    for (int i = 1; i <= m; i++)
        out << x[i] << " ";
    out << "\n";

    return 0;
}
