// ELIMINARE GAUSSIANA
// Rezolvare de sistem de ecuatii

#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

const double E = 1e-8;
double a[304][304], aux, sol[304];
int p[304], i, j, w, n, m;

int main() {
    f >> n >> m;
    for (i = 1; i <= n; i++)
        for (j = 1; j <= m+1; j++)
            f >> a[i][j];

    // Pe fiecare rand i al sistemului avem cate o ecuatie de forma:
    // a[i][1] * x^m + a[i][2] * x^(m-2) + ... + a[i][m]*x^0 = a[i][m+1];

    for (i = 1; i <= n; i++) {
        // Cautam primul coeficient nenul
        for (j = 1; j <= m+1; j++)
            if (fabs(a[i][j]) >= E)
                break;
        // Membrul din dreapta nenul, in stanga
        // toate nule - imposibil
        if (j == m+1) {
            g << "Imposibil";
            return 0;
        }
        // Toti membrii nuli - se ignora
        else if (j == m+2)
            continue;

        // Notam aceasta pozitie
        p[i]=j;
        for (j = 1; j <= n; j++)
            if (i != j && fabs(a[j][p[i]]) >= E) {
                aux = a[j][p[i]] / a[i][p[i]];
                for (w = 1; w <= m+1; w++)
                    a[j][w] -= aux * a[i][w];
            }
    }
    for (i = 1; i <= n; i++)
        if (p[i]) // Ne mai ramane coeficientul din p[i], alaturi de coeficientul din dreapta
            sol[p[i]] = a[i][m+1]/a[i][p[i]];
    for (i = 1; i <= m; i++)
        g<<fixed<<setprecision(10) << sol[i]<<" ";
    return 0;
}
