#include <bits/stdc++.h>

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
typedef long double ld;
const ld EPS=1e-17;
int n,m;
bool use[305];
ld v[305][305],sol[305];
int main()
{	
	ios_base::sync_with_stdio(false);
	fin.tie(0);
	fin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m+1;j++)
			fin>>v[i][j];
	int i=1;
	int j=1;
	while(i<=n&&j<=m)
	{
		int lin=0;
		for(int k=i;k<=n;k++)
			if(abs(v[k][j])>EPS)
			{	
				lin=k;
				break;
			}
		if(lin==0)
		{
			j++;
			continue;
		}
		ld z=v[lin][j];
		for(int p=1;p<=m+1;p++)
			v[lin][p]/=z;
		for(int k=i+1;k<=n;k++)
		{
			ld u=v[k][j];
			for(int p=1;p<=m+1;p++)
				v[k][p]-=u*v[lin][p];
		}
		i++;
		j++;
	}
	/*for(int i=1;i<=n;i++,cout<<'\n')
		for(int j=1;j<=m+1;j++)
			cout<<v[i][j]<<' ';*/
	for(int i=n;i>=1;i--)
	{
		ld suma=0;
		int who=0;
		for(int j=1;j<=m;j++)
		{
			if(use[j])
			{
				suma+=v[i][j]*sol[j];
				continue;
			}
			if(abs(v[i][j])<=EPS)
				continue;
			use[who]=1;
			sol[who]=0;
			who=j;
		}
		//cout<<abs(v[i][2])<<'\n';
		if(who==0&&abs(suma-v[i][m+1])>EPS)
		{
			fout<<"Imposibil";
			return 0;
		}
		use[who]=1;
		ld val=(v[i][m+1]-suma)/v[i][who];
		sol[who]=val;
	}
	for(int i=1;i<=m;i++)
		fout<<fixed<<setprecision(10)<<sol[i]<<' ';
	fout<<'\n'; 
	return 0;
}
