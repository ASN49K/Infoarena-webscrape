#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;
double matrix[305][305];
double ans[305];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");

    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m + 1; ++j) {
            fin >> matrix[i][j];
        }
    }

    int j = 1, i = 1, pos;

    while (j <= m && i <= n) {
        double maxim = 0;
        for (int a = i; a <= n; ++a) {
            if (maxim <= abs(matrix[a][j])){
                maxim = abs(matrix[a][j]);
                pos = a;
            }
        }
        if (maxim == 0) {
            j += 1;
        } else {
            double beta = matrix[pos][j];
            for (int e = 1; e <= m+1; ++e) {
                matrix[pos][e] /= beta;
                swap(matrix[i][e], matrix[pos][e]);
            }
            int c = i;
            i += 1;
            for (int a = i; a <= n; ++a) {
                double z = matrix[a][j] / matrix[c][j];
                for (int d = j; d <= m+1; ++d) {
                     matrix[a][d] -= z * matrix[c][d];
                }
            }
            j += 1;
        }
    }

    int cnt;
    for (int i = n; i >= 1; --i) {
        cnt = 0;
        for (int j = m; j >= 1; --j) {
            if (matrix[i][j] == 0 && matrix[i][m + 1] != 0) {
                cnt += 1;
            }
        }
        if (cnt == m) {
            fout << "IMPOSIBIL";
        } break;
    }

    if (cnt != m) {
        for (int i = n; i >= 1; --i) {
            ans[i] = matrix[i][m + 1];
            for (int j = m; j > i; --j) {
                ans[i] -= matrix[i][j] * ans[j];
            }
        }
        for (int i = 1; i <= n; ++i) {
            fout << setprecision(8) << fixed << ans[i] << " ";
        }
    }

    return 0;
}
