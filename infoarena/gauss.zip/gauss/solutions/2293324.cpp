#include <cstdio>
#include <vector>
#include <cmath>

using namespace std;

const int NMAX = 305;
const double EPS = 0.00001;
int N, M;

vector<vector<double>> A(NMAX, vector<double>(NMAX));

int main() {
   freopen("gauss.in", "r", stdin);
   freopen("gauss.out", "w", stdout);

   scanf("%d %d", &N, &M);

   for (int i = 0; i < N; ++i) {
      for (int j = 0; j < M+1; ++j) {
         scanf("%lf", &A[i][j]);
      }
   }

   int h = 0, k = 0;

   while (h < N && k < M) {
      int i_max  = -1;
      double max_hk = 0;

      for (int i = h; i < N; ++i) {
         if (A[i][k] > EPS || A[i][k] < -1 * EPS) {
            i_max = i;
            max_hk = A[i][k];
            break;
         }
      }

      if (max_hk <= EPS && max_hk >= -EPS) {
         k++;
      } else {
         A[h].swap(A[i_max]);

         for (int i = k+1; i <= M; ++i) {
            A[h][i] /= A[h][k];
         }

         A[h][k] = 1;
         for (int i = h + 1; i < N; ++i) {
            double f = A[i][k] / A[h][k];
            A[i][k] = 0;
            for (int j = k + 1; j <= M; ++j) {
               A[i][j] = A[i][j] - A[h][j] * f;
            }
         }
         h++;
         k++;
      }
   }

   vector<double> sol(M);

   for (int i = N - 1; i >= 0; --i) {
      int p;
      for (p = 0; p <= M && (A[i][p] < EPS && A[i][p] > -EPS); ++p);
      if (p == M) {
         printf("Imposibil\n");
         return 0;
      }
      double x_pi = A[i][M];
      for (int j = p+1; j <= M; ++j) {
         x_pi -= A[i][j] * sol[j];
      }
      sol[i] = x_pi;
   }

   for (int i = 0; i < M; ++i) {
      printf("%.8lf ", sol[i]);
   }

   fclose(stdin);
   fclose(stdout);
   return 0;
}
