#include <bits/stdc++.h>

using namespace std;
using ld = long double;
const ld eps = 1e-10;
class SLAE {
private:
    vector <vector <ld>> a;
    int n, m;
public:
    friend istream& operator >>(istream& in, SLAE& x) {
        in >> x.n >> x.m;
        x.a.resize(x.n);
        for(int i = 0; i < x.n; i++) {
            x.a[i].resize(x.m + 1);
            for(int j = 0; j <= x.m; j++)
                in >> x.a[i][j];
        }
        return in;
    }
    vector <ld> solve() {
        int r, c, x;
        vector <int> where(m, -1);
        for(r = 0, c = 0; r < n && c < m; c++) {
            x = r;
            for(int i = r; i < n; i++)
                if(abs(a[i][c]) > abs(a[x][c]))
                    x = i;
            if(abs(a[x][c]) < eps) continue;
            for(int i = c; i <= m; i++)
                swap(a[x][i], a[r][i]);
            where[c] = r;
            for(int i = 0; i < n; i++) if(i != r) {
                ld z = a[i][c] / a[r][c];
                for(int j = c; j <= m; j++)
                    a[i][j] -= z * a[r][j];
            }
            r++;
        }
        vector <ld> sol(m, 0);
        for(int i = 0; i < m; i++)
            if(where[i] != -1)
                sol[i] = a[where[i]][m] / a[where[i]][i];
        for(int i = 0; i < n; i++) {
            ld sum = 0;
            for(int j = 0; j < m; j++)
                sum += sol[j] * a[i][j];
            if(abs(sum - a[i][m]) > eps)
                return {};
        }
        return sol;
    }
};
SLAE A;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
ostream& operator <<(ostream& out, vector <ld> v) {out << fixed << setprecision(8); for(auto el : v) out << el << " "; return out;}

int main()
{
    fin >> A;
    vector <ld> sol = A.solve();
    if(sol.size()) fout << sol;
    else fout << "Imposibil";
    return 0;
}
