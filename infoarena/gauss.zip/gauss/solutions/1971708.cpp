#include <fstream>
#include <algorithm>
#include <iomanip>

#define nMax 302
#define EPS 0.00000001

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n, m;
double A[nMax][nMax], X[nMax];

int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m+1; j++)
            fin>>A[i][j];
    int i=1, j=1, k;
    while(i<=n && j<=m)
    {
        for(k=i; k<=n; k++)
            if(A[k][j]<-EPS || A[k][j]>EPS)
                break;
        if(k==n+1)
        {
            j++;
            continue;
        }
        if(i!=k)
            for(int t=j; t<=m+1; t++)
                swap(A[i][t], A[k][t]);
        for(int t=j+1; t<=m+1; t++)
            A[i][t]/=A[i][j];
        A[i][j]=1;
        for(int u=i+1; u<=n; u++)
        {
            for(int t=j+1; t<=m+1; t++)
                A[u][t]-=A[i][t]*A[u][j];
            A[u][j]=0;
        }
        i++, j++;
    }

    for(int ii=n; ii>=1; ii--)
    {
        for(int jj=1; jj<=m+1; jj++)
        {
            if(A[ii][jj]<-EPS || A[ii][jj]>EPS)
            {
                if(jj==m+1)
                {
                    fout<<"Imposibil";
                    return 0;
                }

                X[jj]=A[ii][m+1];
                for(int t=jj+1; t<=m; t++)
                    X[jj]-=X[t]*A[ii][t];
                break;
            }
        }
    }

    for(int t=1; t<=m; t++)
        fout<<fixed<<setprecision(8)<<X[t]<<" ";
}
