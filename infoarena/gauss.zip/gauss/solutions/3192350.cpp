#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;
const double EPS = 1e-8;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n, m;
double A[301][302], x[301];   ///A[i][j] = coeficientul variabilei xj in necunoscuta i

void gauss()
{
    int i, j, k, t;
    i = 1;
    j = 1;
    while (i <= n && j <= m)   ///necunoscuta xj in ecuatia i
    {
        bool ok = 0;
        for (k = i; k <= n; k++)
            if(fabs(A[k][j]) > EPS)
            {
                ok = 1;
                break;
            }
        if(ok == 1)
        {
            if(k != i)
                for (t = j; t <= m + 1; t++)
                    swap(A[i][j], A[k][j]);
            for (k = j + 1; k <= m + 1; k++)
                A[i][k] /= A[i][j];
            A[i][j] = 1.0;
            for (k = i + 1; k <= n; k++)
                if(fabs(A[k][j]) > EPS)
                {
                    for (t = j + 1; t <= m + 1; t++)
                        A[k][t] -= A[k][j] * A[i][t];
                    A[k][j] = 0.0;
                }
            i++;
        }
        j++;
    }
}

void afisare_solutie()
{
    int i, j, k;
    for (i = n; i >= 1; i--)
        for (j = 1; j <= m + 1; j++)
        if(fabs(A[i][j]) > EPS)
        {
            if(j == m + 1)
            {
                g << "Imposibil";
                return;
            }
            x[j] = A[i][m + 1];
            for (k = j + 1; k <= m; k++)
                x[j] -= A[i][k] * x[k];
            break;
        }
    g.setf(ios::fixed, ios::floatfield);
    g.precision(8);
    for(int i = 1; i <= m; i++)
        g << x[i] << ' ';
}

void citire()
{
    f >> n >> m;   ///n ecuatii si m necunoscute
    for (int i = 1; i <= n; i++)
        for(int j = 1; j <= m + 1; j++)
            f >> A[i][j];
}

int main()
{
    citire();
    gauss();
    afisare_solutie();
    f.close();
    g.close();
    return 0;
}