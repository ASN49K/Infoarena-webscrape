#include <bits/stdc++.h>
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const double eps = 0.000001;
;int n, m;

int main() {
    fin >> n >> m;
    vector<vector<double> > s(n, vector<double> (m+1));
    for(int i = 0; i < n; i++)
        for(int j = 0; j <= m; j++)
            fin >> s[i][j];

    int i = 0, j = 0;
    while(i < n && j < m) {
        int k = n;
        for(int e = i; e < n; e++)
            if(s[e][j] < -eps || s[e][j] > eps) {
                k = e;
                break;
            }
        if(k == n) {
            j++;
            continue;
        }
        for(int l = 0; l <= m; l++)
            swap(s[i][l], s[k][l]);

        for(int l = j+1; l <= m; l++)
            s[i][l] /= s[i][j];
        s[i][j] = 1;

        for(int u = i+1; u < n; u++) {
            for(int v = j+1; v <= m; v++)
                s[u][v] -= s[u][j]*s[i][v];
            s[u][j] = 0;
        }
        i++, j++;
    }

    vector<double> ans(m);
    for(int u = n-1; u >= 0; u--) {
        for(int v = 0; v <= m; v++)
            if(s[u][v] < -eps || s[u][v] > eps) {
                if(v == m) {
                    fout << "Imposibil\n";
                    return 0;
                }
                ans[v] = s[u][m];
                for(int l = v+1; l < m; l++)
                    ans[v] -= ans[l]*s[u][l];
                break;
            }
    }
    for(auto x: ans) fout << fixed << setprecision(10) << x << ' ';
}
