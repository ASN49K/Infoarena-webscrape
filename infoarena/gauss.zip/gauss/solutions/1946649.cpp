#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define LD long double
#define EPS 0.000000001
int N,M; LD a[310][310],x[310];

int main(){
	ifstream fin("gauss.in");
	ofstream fout("gauss.out");
	fin >> N >> M;
	
	int i,j,k;
	for (i=1; i<=N; i++)
		for (j=1; j<=M+1; j++)
			fin >> a[i][j];
			
	for (j=1; j<=M; j++){
		int ind=-1;
		for (i=j; i<=N; i++)
			if (a[i][j]<-EPS || a[i][j]>EPS){
				ind=i;
				break;
			}
		
		if (ind==-1) continue;
		for (k=1; k<=M+1; k++)
			swap(a[j][k],a[ind][k]);
			
		for (i=ind+1; i<=N; i++){
			LD coef=-a[i][j]/a[ind][j];
			for (k=j; k<=M+1; k++)
				a[i][k]+=coef*a[ind][k];
		}
	}
	
	
	for (i=1; i<=N; i++,cout << "\n")
		for (j=1; j<=M+1; j++)
			cout << a[i][j] << " ";
	for (i=N; i>0; i--){
		for (j=1; j<=M+1; j++)
			if (a[i][j]<-EPS || a[i][j]>EPS){
				if (j==M+1){
					fout << "Imposibil\n";
					return 0;
				}
				
				x[j]=a[i][M+1];
				for (k=j+1; k<=M; k++)
					x[j]-=x[k]*a[i][k];
				x[j]/=a[i][j];
				break;
			}
	}
	
	for (i=1; i<=M; i++)
		fout << fixed << setprecision(9) << x[i] << " ";
	fout << "\n";
	return 0;
}
