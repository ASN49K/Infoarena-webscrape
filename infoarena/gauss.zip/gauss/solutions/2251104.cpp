#include<fstream>//not mine
#include<cmath>
#include<iomanip>
std::ifstream f("gauss.in");std::ofstream g("gauss.out");int n,m,i,j,k,l;double A[310][310],X[310];int main(){f>>n>>m;for(i=1;i<=n;++i)for(j=1;j<=m+1;++j)f>>A[i][j];for(j=1;j<=m;++j){for(i=j;i<=n;++i)if(A[i][j]>0.001||A[i][j]<-0.001)break;if(i>n)continue;if(i!=j)for(k=1;k<=m+1;++k)std::swap(A[i][k],A[j][k]);for(k=j+1;k<=m+1;++k)A[j][k]/=A[j][j];A[j][j]=1;for(k=j+1;k<=n;++k){for(l=j+1;l<=m+1;++l)A[k][l]-=A[j][l]*A[k][j];A[k][j]=0;}}for(i=n;i>=1;--i)for(j=1;j<=m+1;++j)if(A[i][j]>0.001||A[i][j]<-0.001){if(j==m+1){g<<"Imposibil\n";return 0;}X[j]=A[i][m+1];for(k=j+1;k<=m;++k)X[j]-=X[k]*A[i][k];break;}for(i=1;i<=m;++i)g<<std::fixed<<std::setprecision(9)<<X[i]<<" ";return 0;}
