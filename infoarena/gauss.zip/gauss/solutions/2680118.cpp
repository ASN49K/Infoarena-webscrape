#include<bits/stdc++.h>

using namespace std;
ifstream r("gauss.in");
ofstream w("gauss.out");
int n, m;
double a[303][303], b[303];
int main ()
{
	r>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m+1;j++){
			r>>a[i][j];
		}
	}
	for(int j=1;j<=m;j++)
	{
		for(int i=j;i<=n;i++){
			if(a[i][j]>0.001||a[i][j]<-0.001){
				break;
			}
		}
		if(j!=n){
			for(int k=1;k<=m+1;k++){
				swap(a[i][k],a[j][k]);
			}
		}
		for(int k=j+1;k<=m+1;k++){
			a[j][k]/=a[j][j];
		}
		a[j][j]=1;
		for(int k=j+1;k<=n;k++)
		{
			for(int l=j+1;l<=m+1;l++){
				a[k][l]-=a[j][l]*a[k][j];
			}
			a[k][j]=0;
		}
	}
	for(int i=n;i>=1;i--){
		for(int j=1;j<=m+1;j++){
			if(a[i][j]>0.001||a[i][j]<-0.001)
			{
				if(j==m+1)
				{
					w<<"Imposibil\n";
					return 0;
				}
				b[j]=a[i][m+1];
				for(int k=j+1;k<=m;k++){
					b[j]-=b[k]*a[i][k];
				}
				break;
			}
		}
	}
	for(int i=1;i<=m;i++){
		w<<fixed<<setprecision(9)<<b[i]<<" ";
	}
	return 0;
}
