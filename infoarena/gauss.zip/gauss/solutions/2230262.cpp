///Note to self : Never try to use standard I/O on this problem

#include <fstream>
#include <iomanip>

#define nmax 310
#define eps 0.0000001

using namespace std;

double a[nmax][nmax];
double x[nmax];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");

    int n,m,i,j,k,l,p;
    double aux;

    fin>>n>>m;
    for(i=1;i<=n;++i)
        for(j=1;j<=m+1;++j)
            fin>>a[i][j];

    i=1,j=1;
    while(i<=n && j<=m) {

        for(k=i;k<=n;++k)
            if(a[k][j]<-eps || a[k][j]>eps)
                break;

        if(k==n+1) {
            ++j;
            continue;
        }

        if(k!=i)
            for(l=1;l<=m+1;++l) {
                aux=a[i][l];
                a[i][l]=a[k][l];
                a[k][l]=aux;
            }

        for(l=j+1;l<=m+1;++l)
            a[i][l]/=a[i][j];
        a[i][j]=1.;

        for(p=i+1;p<=n;++p) {
            for(l=j+1;l<=m+1;++l)
                a[p][l]-=a[p][j]*a[i][l];
            a[p][j]=0;
        }

        i++;
        j++;
    }
    for(i=n;i>0;--i)
        for(j=1;j<=m+1;++j)
            if(a[i][j]>eps || a[i][j]<-eps) {
                if(j==m+1) {
                    fout<<"Imposibil"<<'\n';
                    return 0;
                }

                x[j]=a[i][m+1];
                for(k=j+1;k<=m;++k)
                    x[j]-=x[k]*a[i][k];

                break;
            }

    for(i=1;i<=m;++i)
        fout<<setprecision(10)<<fixed<<x[i]<<" ";
    fout<<'\n';

    fin.close();
    fout.close();

    return 0;
}
