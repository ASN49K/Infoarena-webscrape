#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#define EPS 0.0000000001
using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
int n,m,i,j,sw,l,u,k;
long double a[305][305],sol[305],aux;
int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m+1;j++)
        {
            f>>a[i][j];
        }
    }
    i=1;
    j=1;
    while(i<=n && j<=m)
    {
        for(k=i;i<=n;k++)
        {
            if(a[i][k]<-EPS || a[i][k]>EPS)
            {
                break;
            }
        }
        if(k==n+1)
        {
            j=j+1;
            continue;
        }
        if(k!=i)
        {
            for(l=1;l<=m+1;l++)
            {
                aux=a[k][l];
                a[k][l]=a[i][l];
                a[i][l]=aux;
            }
        }
        for(l=j+1;l<=m+1;l++)
        {
            a[i][l]=a[i][l]/a[i][j];
        }
        a[i][j]=1;
        for(u=i+1;u<=n;u++)
        {
            for(l=j+1;l<=m+1;l++)
            {
                a[u][l]=a[u][l]-a[u][j]*a[i][l];
            }
            a[u][j]=0;
        }
        i++;
        j++;
    }
    for(i=n;i>=1;i--)
    {
        for(j=1;j<=m+1;j++)
        {
            if(a[i][j]<-EPS || a[i][j]>EPS)
            {
                if(j==m+1)
                {
                    g<<"Imposibil";
                    return 0;
                }
                sol[j]=a[i][m+1];
                for(k=j+1;k<=m;k++)
                {
                    sol[j]=sol[j]-a[i][k]*sol[k];
                }
                break;
            }
        }
    }
    for(i=1;i<=m;i++)
    {
        g<<fixed<<setprecision(10)<<sol[i]<<" ";
    }
    return 0;
}
