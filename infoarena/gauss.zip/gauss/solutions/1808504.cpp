#include <fstream>
#include <iomanip>

#define nMax 302
#define EPS 0.0000001

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n, m;
double A[nMax][nMax], X[nMax];
void write();

void read()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m+1; j++)
            fin>>A[i][j];
}

void solve()
{
    int i=1, j=1, k;
    double aux;

    while(i<=n && j<=m)
    {
        for(k=i; k<=n; k++)
            if(A[k][j]<-EPS || A[k][j]>EPS)
                break;
        if(k==n+1)
        {
            j++;
            continue;
        }

        if(k!=i)
            for(int u=j; u<=m+1; u++)
            {
                aux=A[i][u];
                A[i][u]=A[k][u];
                A[k][u]=aux;
            }

        for(int u=j+1; u<=m+1; u++)
            A[i][u]=A[i][u]/A[i][j];
        A[i][j]=1;

        for(int u=i+1; u<=n; u++)
        {
            for(int l=j+1; l<=m+1; l++)
                A[u][l]-=A[u][j]*A[i][l];
            A[u][j]=0;
        }
        i++, j++;
    }
    for(int i=n; i>0; i--)
        for(int j=1; j<=m+1; j++)
            if(A[i][j]>EPS || A[i][j]<-EPS)
            {
                if(j==m+1)
                {
                    fout<<"Imposibil";
                    return;
                }

                X[j]=A[i][m+1];
                for(k=j+1; k<=m; k++)
                    X[j]-=X[k]*A[i][k];
                break;
            }
    write();
}

void write()
{
    for(int i=1; i<=m; i++)
        fout<<fixed<<setprecision(8)<<X[i]<<" ";
}

int main()
{
    read();
    solve();
}
