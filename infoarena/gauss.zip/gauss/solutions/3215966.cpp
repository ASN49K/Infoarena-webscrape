#include <bits/stdc++.h>

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
typedef long double ld;
const ld EPS=1e-17;
int n,m;
ld v[305][305];
bool use[305];
ld sol[305];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>v[i][j];
    int i=1;
    int j=1;
    while(i<=n&&j<=m)
    {
        int lin=0;
        for(int k=i;k<=n;k++)
            if(v[k][j]!=0)
            {
                lin=k;
                break;
            }
        if(lin==0)
        {
            j++;
            continue;
        }
        swap(v[i],v[lin]);
        ld z=v[i][j];
        for(int k=1;k<=m+1;k++)
            v[i][k]/=z;
        for(int u=i+1;u<=n;u++)
        {
            ld val=v[u][j];
            for(int k=1;k<=m+1;k++)
                v[u][k]-=val*v[i][k];
        }
        i++;
        j++;
    }
    for(int i=n;i>=1;i--)
    {
        ld suma=0;
        int who=0;
        for(int j=1;j<=m;j++)
            if(v[i][j]!=0)
            {
                if(use[j])
                    suma+=sol[j]*v[i][j];
                else
                {
                    sol[who]=0;
                    use[who]=1;
                    who=j;
                }
            }
        if(who==0)
        {
            if(abs(suma-v[i][m+1])>EPS)
            {
                fout<<"Imposibil";
                return 0;
            }
            continue;
        }
        ld val=(v[i][m+1]-suma)/v[i][who];
        sol[who]=val;
        use[who]=1;
    }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(12)<<sol[i]<<' ';
    return 0;
}
