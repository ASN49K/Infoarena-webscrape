#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <set>
#include <map>
#include <cmath>
#include <cstring>
#include <ctime>
#include <unordered_map>
#include <iomanip>
#include <complex>
#include <cassert>
using namespace std;

#define fi first
#define se second
#define pb push_back
#define all(v) (v).begin(),(v).end()
#define deb(a) cerr<< #a << "= " << (a)<<"\n";

typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int uint;
typedef long double ld;
typedef complex<double> base;
typedef vector<int> vi;
typedef pair<int,int> pii;

template<class T> ostream& operator<<(ostream& stream, const vector<T> v){ stream << "[ "; for (int i=0; i<(int)v.size(); i++) stream << v[i] << " "; stream << "]"; return stream; }
ll fpow(ll x, ll p, ll m){ll r=1; for (;p;p>>=1){ if (p&1) r=r*x%m; x=x*x%m; } return r;}
ll inv(ll a, ll b){ return a<2 ? a : ((a-inv(b%a,a))*b+1)/a%b; }
int gcd(int a, int b){ if (!b) return a; return gcd(b,a%b);}
ll gcd(ll a, ll b){ if (!b) return a; return gcd(b,a%b);}


int N,M;
ld a[310][310],b[310],s[310];
const ld eps = 1e-6;

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	ifstream cin("gauss.in");
	ofstream cout("gauss.out");
	
	cin >> N >> M;
	
	int i,j,k;
	for (i=1; i<=N; i++){
		for (j=1; j<=M; j++)
			cin >> a[i][j];
			
		cin >> b[i];
	}
			
	
	for (k=1; k<=min(N,M); k++){
		int ind = -1;
		for (i=k; i<=N; i++)
			if (abs(a[i][k])>eps){
				ind = i;
				break;
			}
			
		if (ind==-1) continue;
		
		for (j=k; j<=M; j++)
			swap(a[k][j],a[ind][j]);
			
		swap(b[k],b[ind]);
			
		for (i=k+1; i<=N; i++){
			ld coef=a[i][k]/a[k][k];
			for (j=k; j<=M; j++)
				a[i][j]-=coef*a[k][j];
				
			b[i]-=coef*b[k];
		}
	}
	
	
	for (i=N; i>0; i--){
		for (j=1; j<=M; j++)
			if (abs(a[i][j])>eps)
				break;
		
	
		if (j==M+1){
			if (b[i]!=0) {
				cout << "Imposibil\n";
				return 0;
			}
			
			continue;
		}
		
		for (k=j+1; k<=M; k++)
			b[i]-=s[k]*a[i][k];
			
		s[j]=b[i]/a[i][j];
	}
	
	
	cout << fixed << setprecision(14);
	for (i=1; i<=M; i++)
		cout << s[i] << " ";
}

