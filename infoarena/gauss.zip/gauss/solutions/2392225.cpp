#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>

#define eps 1e-10

using namespace std;

ifstream in ("gauss.in");
ofstream out ("gauss.out");

double a[305][305];
double sol[305];
int n,m;

int main()
{
    in>>n>>m;
    for(int i=0; i<n; ++i)
        for(int j=0; j<=m; ++j)
            in>>a[i][j];

    for(int i=0; i<m-1; ++i)
    {
        if(abs(a[i][i])<eps){
            for(int j=i+1;j<m;++j)
                if(fabs(a[j][i])<eps){
                    swap(a[i],a[j]);
                    break;
                }
        }
        else
        {
            for(int j=i+1; j<m; ++j)
            {
                double c = -(a[j][i]/a[i][i]);
                for(int k=i; k<=m; ++k)
                    a[j][k]+=c*a[i][k];
            }
        }
    }

    for(int i=m-1;i>=0;--i){
        sol[i]=a[i][m];
        for(int j=m-1;j>i;--j)
            sol[i]-=a[i][j]*sol[j];
        if(fabs(a[i][i])>eps)
            sol[i]/=a[i][i];
    }

    for(int i=m;i<n;++i){
        double c = 0;
        for(int j=0;j<m;++j)
            c+=sol[j]*a[i][j];
        if(fabs(c-a[i][m])>eps){
            out<<"Imposibil";
            return 0;
        }
    }

    out<<fixed<<setprecision(11);

    for(int i=0;i<m;++i)
        out<<sol[i]<<" ";

    return 0;
}
