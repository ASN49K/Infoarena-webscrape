#include <bits/stdc++.h>

using namespace std;

ifstream fin( "gauss.in" );
ofstream fout( "gauss.out" );

const int MAX_N = 3000;
const double EPS = 1e-3;

double sol[MAX_N], mat[MAX_N][MAX_N + 1];

int main() {
    int n, m;

    fin >> n >> m;
    for ( int i = 0; i < n; i++ ) {
        for ( int j = 0; j < m + 1; j++ )
            fin >> mat[i][j];
    }

    for ( int unk = 0; unk < m; unk++ ) {
        int ecCrt = unk;
        while ( ecCrt < n && abs( mat[ecCrt][unk] ) < EPS )
            ecCrt++;
        if ( ecCrt == n )
            continue;


        swap( mat[unk], mat[ecCrt] );

        for ( int ec = 0; ec < n; ec++ ) {
            if ( ec == unk )
                continue;

            double aux = mat[ec][unk] / mat[unk][unk];
            for ( int u = 0; u < m + 1; u++ )
                mat[ec][u] -= mat[unk][u] * aux;
        }
    }

    for ( int unk = 0; unk < m; unk++ ) {
        if ( abs( mat[unk][unk] ) > EPS )
            sol[unk] = mat[unk][m] / mat[unk][unk];
    }

    for ( int ec = 0; ec < n; ec++ ) {
        for ( int unk = 0; unk < m; unk++ )
            mat[ec][m] -= mat[ec][unk] * sol[unk];
        if ( abs( mat[ec][m] ) > EPS ) {
            fout << "Imposibil\n";
            exit( 0 );
        }
    }

    for ( int i = 0; i < m; i++ )
        fout << setprecision( 10 ) << fixed << sol[i] << " ";

    return 0;
}
