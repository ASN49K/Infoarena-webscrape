#include <bits/stdc++.h>
#define EPS 0.00001
#define NUM 305
double mat[NUM][NUM];
double sol[NUM];
int poz[NUM];
int n, m;
using namespace std;
int main()
{
    ifstream f("gauss.in");
    ofstream g("gauss.out");
    f >> n >> m;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= m + 1; ++j)
            f >> mat[i][j];
    for(int i = 1; i <= n; ++i)
    {
        // prima valoare nenula
        for(int j = 1; j <= m; ++j)
            if(abs(mat[i][j]) > EPS)
            {
                poz[i] = j;
                break;
            }
        if(!poz[i])
        {
            if(abs(mat[i][m + 1]) > EPS)
            {
                g << "Imposibil\n";
                return 0;
            }
            continue;
        }
        for(int k = 1; k <= n; ++k)
        {
            if(k != i && abs(mat[k][poz[i]]) > EPS)
            {
                double rat = mat[k][poz[i]] / mat[i][poz[i]];
                for(int j = 1; j <= m + 1; ++j)
                    mat[k][j] -= rat * mat[i][j];
            }
        }
    }
    for(int i = 1; i <= n; ++i)
        if(poz[i])
            sol[poz[i]] = mat[i][m + 1] / mat[i][poz[i]];
    for(int i = 1; i <= m; ++i)
        g << fixed << setprecision(10) << sol[i] << ' ';
    f.close();
    g.close();
}
