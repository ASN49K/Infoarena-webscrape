#include <iostream>
#include<cstdio>
using namespace std;
const int N=305;
double mat[N][N];
double sol[N];
const double EPS=0.000001;
bool nul(double x){
  if(x<EPS && x>-EPS)
    return true;
  return false;
}
int main()
{
  FILE*fin,*fout;
  fin=fopen("gauss.in","r");
  fout=fopen("gauss.out","w");
  int n,m;
  fscanf(fin,"%d%d",&n,&m);
  for(int i=1;i<=n;i++){
    for(int j=1;j<=m+1;j++){
      fscanf(fin,"%lf",&mat[i][j]);
    }
  }
  int poz=1,lin=1;
  while(lin<=n && poz<=m){
    int l;
    for(l=lin;l<=n;l++){
      if(!nul(mat[l][poz])){
        break;
      }
    }
    if(l==n+1){
      poz++;
      continue;
    }
    if(l!=lin){
      for(int j=1;j<=m+1;j++){
        swap(mat[lin][j],mat[l][j]);
      }
    }
    for(int i=poz+1;i<=m+1;i++){
      mat[lin][i]/=mat[lin][poz];
    }
    mat[lin][poz]=1;
    for(int i=lin+1;i<=n;i++){
      for(int j=poz+1;j<=m+1;j++){
        mat[i][j]-=(double)mat[i][poz]*mat[lin][j];
      }
      mat[i][poz]=0;
    }
    poz++;
    lin++;
  }
  for(int i=n;i>=1;i--){
    for(int j=1;j<=m+1;j++){
      if(!nul(mat[i][j])){
        if(j==m+1){
          fprintf(fout,"Imposibil");
          return 0;
        }
        sol[j]=mat[i][m+1];
        for(int k=j+1;k<=m;k++){
          sol[j]-=mat[i][k]*sol[k];
        }
        break;
      }
    }
  }
  for(int i=1;i<=m;i++){
    fprintf(fout,"%.10f ",sol[i]);
  }
  return 0;
}
