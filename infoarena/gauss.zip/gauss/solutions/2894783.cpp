// This program was written on 25.04.2022
// for problem gauss
// by Mircea Rebengiuc

#include <stdio.h>
#include <ctype.h>

#include <valarray>

#define EPS 1e-7
#define FEPS 1e-3
#define NIL -1

#define MAXN 300
#define MAXM 300

double orig[MAXN][MAXM + 1];
std::valarray<double> e[MAXN];
int vdom[MAXN];
double rez[MAXM + 1];// santinela pentru verificarea solutiei
bool hazval[MAXM];

static inline bool null( const double &t ){
  return std::abs( t ) <= EPS;
}

FILE *fin, *fout;

static inline void tableflip(){
  fprintf( fout, "Imposibil!\n" );
  fclose( fin );
  fclose( fout );
  exit( 0 );
}


int main(){
  fin  = fopen( "gauss.in",  "r" );
  fout = fopen( "gauss.out", "w" );
  
  int n, m, i, j, k;
  double sum;
  
  fscanf( fin, "%d%d", &n, &m );
  for( i = 0 ; i < n ; i++ ){
    e[i].resize( m + 1 );
    
    for( j = 0 ; j <= m ; j++ ){
      fscanf( fin, "%lf", &orig[i][j] );
      e[i][j] = orig[i][j];
    }
    
    vdom[i] = NIL;
  }
  
  for( i = j = 0 ; i < n && j < m ; j++ ){
    if( null( e[i][j] ) ){// nu avem variabila 'dominanta'
      // gasim alta ecuatie cu coeficient nenul
      k = i + 1;
      while( k < n && null( e[k][j] ) )
        k++;
      
      if( k < n )
        std::swap( e[i], e[k] );// O(1)
    }
    
    if( !null( e[i][j] ) ){
      vdom[i] = j;

      // facem toti coeficientii de la variabila j nuli
      for( k = 0 ; k < n ; k++ )
        if( k != i && !null( e[k][j] ) )
          e[k] -= e[i] * (e[k][j] / e[i][j]);
      
      i++;
    }
  }
  
  for( i = 0 ; i < m ; i++ )
    rez[i] = 0;
  
  // scoatem variabilele din matrice
  for( i = 0 ; i < n ; i++ )
    if( vdom[i] >= 0 )
      rez[vdom[i]] = e[i][m] / e[i][vdom[i]];
  
  rez[m] = -1;
  
  // verificam daca verifica toate ecuatiile
  for( i = 0 ; i < n ; i++ ){
    sum = 0;
    for( j = 0 ; j <= m ; j++ )
      sum += rez[j] * orig[i][j];
    
    if( std::abs( sum ) > FEPS )
      tableflip();
  }
  
  for( j = 0 ; j < m ; j++ )
    fprintf( fout, "%.10lf ", rez[j] );
  fputc( '\n', fout );
  
  fclose( fin );
  fclose( fout );
  return 0;
}