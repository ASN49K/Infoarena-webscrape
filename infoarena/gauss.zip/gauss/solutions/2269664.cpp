#include <fstream>
#include <iomanip>
using namespace std;
int n,m;
double val,v[310][310],sol[310];
make_zero(int poz, int x, int y)
{
    val=(-1)*v[x][y]/v[poz][y];
    v[x][y]=0;
    for(int j=y+1;j<=m+1;j++)
        v[x][j]+=val*v[poz][j];

}
int main()
{
    ifstream f("gauss.in");
    ofstream g("gauss.out");
int i,j,r;
    f>>n>>m;
    for(i=1;i<=n;i++)
    for(j=1;j<=m+1;j++)
    f>>v[i][j];

    for(j=1;j<m;j++)
    for(i=1;i<=n-j;i++)
        if(v[i][j])
    {
        for(r=i+1;r<=n;r++)
            if(v[r][j])
        {
            make_zero(r,i,j);
            break ;
        }
    }

    for(i=1;i<=n;i++)
    for(j=m;j>=1;j--)
    if(sol[j])
    v[i][m+1]-=sol[j]*v[i][j];
    else
    {
        sol[j]=v[i][m+1]/v[i][j];
        break ;
    }
    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<sol[i]<<' ';




    return 0;
}
