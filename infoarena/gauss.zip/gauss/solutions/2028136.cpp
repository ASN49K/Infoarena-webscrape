#include <bits/stdc++.h>

using namespace std;

const double EPS = 1e-6;

int is_null(double val) {
  return -EPS < val && val < EPS;
}

int main()
{
    int n, m;
    ifstream fin("gauss.in");
    fin >> n >> m;
    vector <vector <double>> eq(n + 1, vector <double> (m + 2));
    vector <double> ans(m, 0.0);
    for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= m + 1; ++j)
        fin >> eq[i][j];
    fin.close();
    int i = 1, j = 1, k;
    while (i <= n && j <= m) {
      k = i;
      while (k <= n && is_null(eq[k][j]))
        ++k;
      if (k <= n) {
        swap(eq[i], eq[k]);
        for (k = m + 1; k >= j; --k)
          eq[i][k] /= eq[i][j];
        for (int e = i + 1; e <= n; ++e)
          for (int v = m + 1; v >= j; --v)
            eq[e][v] -= eq[e][j] * eq[i][v];
        ++i;
      }
      ++j;
    }
    int poss = 1;
    for (i = n; i > 0 && poss; --i) {
      j = 1;
      while (j <= m + 1 && is_null(eq[i][j]))
        ++j;
      if (j == m + 1)
        poss = 0;
      else {
        ans[j] = eq[i][m + 1];
        for (k = j + 1; k <= m; ++k)
          ans[j] -= ans[k] * eq[i][k];
      }
    }
    ofstream fout("gauss.out");
    if (poss == 0)
      fout << "Imposibil\n";
    else
      for (i = 1; i <= m; ++i)
        fout << setprecision(5) << fixed << ans[i] << " ";
    fout.close();
    return 0;
}
