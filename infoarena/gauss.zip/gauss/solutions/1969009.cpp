#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int nmax = 3e2 + 10;
const int mmax = 3e2 + 10;

int n, m;
double a[nmax][mmax];

void input() {
    fin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m + 1; ++j)
            fin >> a[i][j];
}

void impossible() {
    fout << "Imposibil\n";
    exit(0);
}

void gauss() {
    for (int i = 1; i <= n; ++i) {
        int pos = 0;
        for (int j = 1; j <= m + 1 && !pos; ++j)
            if (a[i][j] != 0.0) pos = j;

        if (pos == m + 1)
            impossible();
        if (pos == 0)
            continue;

        for (int j = 1; j <= n; ++j) {
            if (i == j || a[j][pos] == 0.0) continue;

            double coef = a[j][pos] / a[i][pos];
            for (int k = 1; k <= m + 1; ++k)
                a[j][k] -= a[i][k] * coef;
        }
    }
}

void output() {
    fout << fixed << setprecision(10);
    for (int i = 1; i <= n; ++i) {
        int pos = 0;
        for (int j = 1; j <= m && !pos; ++j)
            if (a[i][j] != 0.0) pos = j;

        if (pos == 0)
            fout << 0 << ' ';

        fout << a[i][m+1] / a[i][pos] << ' ';
    }
}

int main() {
    input();
    gauss();
    output();

    return 0;
}
