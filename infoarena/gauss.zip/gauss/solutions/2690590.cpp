#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("gauss.in" , "r" , stdin) , freopen("gauss.out" , "w" , stdout)
#define ld long double

using namespace std;

const int N = 305;
const ld EPS = 0.000000001;

int n , m;
ld a[N][N] , x[N];

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    int i , t , u , j;

    cin >> n >> m;

    i = 1 , j = 1;

    while(i <= n && j <= m)
    {
        for(t = i ; t <= n ; t++)
            if(fabs(a[t][j]) > EPS)
                break;

        if(t == n + 1)
        {
            j++;
            continue;
        }

        for(u = j ; u <= m + 1 ; u++)
        {
            swap(a[t][u] , a[i][u]);
            a[i][u] /= a[i][j];
        }

        for(u = i + 1 ; u <= n ; u++)
            for(t = j ; t <= m + 1 ; t++)
                a[u][t] -= a[u][j] * a[i][t];

        i++ , j++;
    }

    for(i = n ; i >= 1 ; i--)
        for(j = 1 ; j <= m + 1; j++)
            if(fabs(a[i][j]) > EPS)
            {
                if(j > m)
                    return cout << "Imposibil" , 0;

                x[j] = a[i][m + 1];

                for(t = j + 1 ; t <= m ; t++)
                    x[j] -= x[t] * a[i][t];

                break;
            }


    cout << fixed << setprecision(10);

    for(i = 1 ; i <= m ; i++)
        cout << x[i] << ' ';

    return 0;
}
