#include <iostream>
#include <iomanip>
#include <fstream>

void read(int& n, int&m, double a[305][305]){
    std::cin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m + 1; ++j)
            std::cin >> a[i][j];
    }
}

void divideRow(int row, double coef, double a[305][305], int m) {
    for (int j = 1; j <= m + 1; ++j) {
        a[row][j] /= coef;
    }
}

void subtractRow(int row, int from, double coef, double a[305][305], int m) {
    for (int j = 1; j <= m + 1; ++j) {
        a[row][j] -= coef * a[from][j];
    }
}

int main() {

    freopen("../gauss.in", "r", stdin);
    freopen("../gauss.out", "w", stdout);

    int n, m;
    double a[305][305];
    double sol[305];

    read(n, m, a);

    for (int row = 1; row <= n; ++row) {
        if (a[row][row] == 0) {
            std::cout << "Imposibil";
            return 0;
        }
        divideRow(row, a[row][row], a, m);

        for (int i = row + 1; i <= n; ++i) {
            subtractRow(i, row, a[i][row], a, m);
        }
    }

    sol[n] = a[n][m + 1];
    for (int row = n - 1; row >= 1; --row) {
        sol[row] = 0;
        for (int j = row + 1; j <= m; ++j) {
            sol[row] -= a[row][j] * sol[j];
        }
        sol[row] += a[row][m + 1];
    }

    for (int i = 1; i <= m; ++i)
        std::cout << std::setprecision(10) << sol[i] << " ";


    return 0;
}
