#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
struct elem{
	double x;
	int i;
};
struct ecuatie{
	vector <elem> v;
	double r;
};
vector <ecuatie> v;
double ras[305];
void swap_lin( int x, int y ){
	swap( v[x], v[y] );
}
void swap_col( int x, int y ){
	int i;
	for( i = 0; i < v.size(); i++ ){
		swap( v[i].v[x], v[i].v[y] );
	}
}
int main(){
	int n, m, i, j, k, x, ok, only_0;
	double a;
	ifstream fin( "gauss.in" );
	ofstream fout( "gauss.out" );
	fin >> n >> m;
	for( i = 0; i < n; i++ ){
		vector <elem> lin;
		for( j = 0; j < m; j++ ){
			fin >> x;
			lin.push_back( { ( double ) x, j } );
		}
		fin >> x;
		v.push_back( { lin, ( double ) x } );
	}
	ok = 1;
	only_0 = k = 0;
	while( k < n && k < m && ok == 1 && only_0 == 0 ){
		/*for( i = 0; i < n; i++ ){
			for( j = 0; j < m; j++ ){
				cout << v[i].v[j].x << ' ';
			}
			cout << "R: " << v[i].r << '\n';
		}
		cout << '\n';*/
		i = j = k;
		while( i < n && v[i].v[j].x == 0 && ok == 1 ){
			j++;
			if( j == m ){
				if( v[i].r != 0 ){
					ok = 0;
				}
				j = k;
				i++;
			}
		}
		if( i == n ){
			only_0 = 1;
			continue;
		}
		if( ok == 0 ){
			continue;
		}
		swap_lin( k, i );
		swap_col( k, j );
		for( i = k + 1; i < n; i++ ){
			a = v[i].v[k].x / v[k].v[k].x;
			for( j = k; j < m; j++ ){
				v[i].v[j].x -= v[k].v[j].x * a;
			}
			v[i].r -= v[k].r * a;
		}
		k++;
	}
	/*for( i = 0; i < n; i++ ){
		for( j = 0; j < m; j++ ){
			cout << v[i].v[j].x << ' ';
		}
		cout << "R: " << v[i].r << '\n';
	}
	cout << '\n';*/
	//cout << ok << ' ' << only_0 << '\n';
	if( k == m ){
		i = k;
		while( i < n && ok == 1 ){
			if( v[i].r != 0 ){
				ok = 0;
			}
			i++;
		}
	}
	if( ok == 0 ){
		fout << "Imposibil\n";
	}
	else{
		for( i = k - 1; i >= 0; i-- ){
			a = v[i].r;
			for( j = i + 1; j < m; j++ ){
				a -= v[i].v[j].x * ras[v[i].v[j].i];
			}
			ras[v[i].v[i].i] = a / v[i].v[i].x;
		}
		for( i = 0; i < m; i++ ){
			fout << ras[i] << ' ';
		}
	}
	return 0;
}