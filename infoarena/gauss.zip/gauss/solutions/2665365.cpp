#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp> // Including tree_order_statistics_node_update
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) < (b)) ? (b) : (a))
//#pragma GCC optimize("O3")
using namespace std;
using namespace __gnu_pbds;
auto random_address = [] { char *p = new char; delete p; return uint64_t(p); };
const uint64_t SEED = chrono::steady_clock::now().time_since_epoch().count() * (random_address() | 1);
mt19937_64 rng(SEED);
typedef tree<
int,
null_type,
less<int>,
rb_tree_tag,
tree_order_statistics_node_update>
ordered_set;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n,m;
double a[305][305],x[305];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>a[i][j];
    bool ok=0;
    for(int i=1;i<=n;i++)
    {
        if(a[i][m+1]!=0)
            ok=1;
        int p=1e9;
        for(int j=1;j<=m;j++)
            if(a[i][j]!=0)
            {
                p=j;
                break;
            }
        if(p==1e9&&a[i][m+1]!=0.0f)
        {
            fout<<"Imposibil";
            return 0;
        }
    }
    if(!ok)
    {
        for(int i=1;i<=m;i++)
            fout<<0<<' ';
        return 0;
    }
    int i=1,j=1;
    while(i<=n&&j<=m)
    {
        int x=-1;
        for(int lin=i;lin<=n;lin++)
            if(a[lin][j]!=0)
            {
                x=lin;
                break;
            }
        if(x==-1)
        {
            j++;
            continue;
        }
        for(int col=1;col<=m+1;col++)
            swap(a[i][col],a[x][col]);
        double val=a[i][j];
        for(int c=1;c<=m+1;c++)
            a[i][c]=double(a[i][c]/val);
        for(int u=i+1;u<=n;u++)
        {
            double z=a[u][j];
            for(int c=1;c<=m+1;c++)
                a[u][c]-=z*a[i][c];
        }
        i++;
        j++;
    }
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m+1;j++)
            fout<<a[i][j]<<' ';
        fout<<'\n';
    }
    fout<<'\n';*/
    for(int i=n;i>=1;i--)
    {
        ll p=1e9;
        for(int j=1;j<=m;j++)
            if(a[i][j]!=0)
            {
                p=j;
                break;
            }
        if(p==1e9&&a[i][m+1]!=0.0f)
        {
            fout<<"Imposibil";
            return 0;
        }
        if(p==1e9)
            continue;
        x[p]=a[i][m+1];
        for(int j=p+1;j<=m;j++)
            x[p]-=a[i][j]*x[j];
    }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(10)<<x[i]<<" ";
    return 0;
}
