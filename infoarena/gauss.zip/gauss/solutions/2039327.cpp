/**
  *  Worg
  */
#include <cmath>
#include <cstdio>
#include <vector>

FILE *fin = freopen("gauss.in", "r", stdin); FILE *fout = freopen("gauss.out", "w", stdout);

const double eps = 1e-8;

/*-------- Data --------*/
int N, M;
std::vector<std::vector<double > > sys;
/*-------- --------*/

void ReadInput() {
    scanf("%d%d", &N, &M);

    sys = std::vector<std::vector<double > >(N, std::vector<double >(M + 1));

    for(int i = 0; i < N; i++) {
        for(int j = 0; j <= M; j++) {
            scanf("%lf", &sys[i][j]);
        }
    }
}

bool Null(double value) {
    return -eps < value && value < eps;
}

void Gauss() {
    std::vector<int > lineIndex(M, 0);

    for(int i = 0, x = 0; i < N; i++, x++) {
        int line = x;
        for(int j = x + 1; j < N; j++) {
            if(std::abs(sys[j][i]) > std::abs(sys[line][i])) {
                line = j;
            }
        }

        std::swap(sys[x], sys[line]);

        if(Null(sys[x][i])){ x--; continue; }  //  Unfixed

        lineIndex[i] = x;
        double coef = 1 / sys[x][i]; sys[x][i] = 1.0;
        for(int j = i + 1; j <= M; j++) {
            sys[x][j] *= coef;
        }

        for(int j = 0; j < N; j++) {
            if(j == x || Null(sys[j][i])) continue;

            double coef = sys[j][i] / sys[x][i];
            for(int k = 0; k <= M; k++) {
                sys[j][k] -= coef * sys[x][k];
            }
        }
    }

    std::vector<double > answer;
    for(int i = 0; i < M; i++) {
        int x = lineIndex[i];
        if(!Null(sys[x][M]) && Null(sys[x][i])) {
            printf("Imposibil\n"); return;
        } else {
            answer.push_back(sys[x][M]);
        }
    }

    for(auto& x : answer) {
        printf("%.12f ", x);
    }
    printf("\n");
}

int main() {
    ReadInput();

    Gauss();

    return 0;
}
