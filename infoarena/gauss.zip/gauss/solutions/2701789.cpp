#include <bits/stdc++.h>
using namespace std;

#define EPS 1e-10
#define cin fin
#define cout fout

ifstream cin("gauss.in");
ofstream cout("gauss.out");

int n, m;
double a[302][302];

vector<double> solve(){
	vector<int> pos(m+1, 0);
	for(int i=1,j=1;i<=n&&j<=m;++j){
		int cr=i;
		for(int k=i+1;k<=n;++k){
			if(abs(a[k][j])>abs(a[cr][j])) cr=k;
		}
		if(abs(a[cr][j])<EPS) continue;
		for(int k=j;k<=m+1;++k) swap(a[cr][k], a[i][k]);
		pos[j]=i;
		for(int k=1;k<=n;++k){
			if(k==i) continue;
			double val=(a[k][j]/a[i][j]);
			for(int l=j;l<=m+1;++l){
				a[k][l]-=(a[i][l]*val);
			}
		}
		i++;
	}
	vector<double> sol(m+1);
	for(int j=1;j<=m;++j){
		if(!pos[j]) continue;
		sol[j]=a[pos[j]][m+1]/a[pos[j]][j];
	}
	for(int i=1;i<=n;++i){
		double sum=0;
		for(int j=1;j<=m;++j){
			sum+=a[i][j]*sol[j];
		}
		if(abs(a[i][m+1]-sum)>EPS) return {};
	}
	return sol;
}

int main(){
	cin>>n>>m;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m+1;++j){
			cin>>a[i][j];
		}
	}
	vector<double> sol=solve();
	if(sol.size()==0) cout<<"Imposibil\n";
	else{
		for(int i=1;i<sol.size();++i) cout<<fixed<<" "<<setprecision(10)<<sol[i]<<" ";
		cout<<"\n";
	}
	return 0;
}
