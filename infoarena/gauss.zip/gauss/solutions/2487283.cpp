#include <fstream>
#include <iomanip>
#define EPS 0.000000001

using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
double a[310][310], x[310];
int n, m, i, j, k, t, sol;

int main()
{
    f>>n>>m;
    for ( i=1; i <= n; i++ )
        for ( j=1; j <= m+1; j++ )
            f>>a[i][j];
    i = j = 1;
    while ( i <= n && j <= m ){
        for ( k=i; k <= n; k++ )
            if ( a[k][j] != 0 )
                break;
        if ( k == n+1 ){
            j++; continue;
        }
        if ( k != i )
            for ( t=1; t <= m+1; t++ )
                swap ( a[k][t], a[i][t] );
        for ( t = j+1; t <= m+1; t++ )
            a[i][t] /= a[i][j];
        a[i][j] = 1;
        for ( k = i+1; k <= n; k++ ){
            for ( t = j+1; t <= m+1; t++ )
                a[k][t] -= a[i][t]*a[k][j];
            a[k][j] = 0;
        }
        i++, j++;
    }
    for ( i=n; i; i-- ){
        for ( j=1; j <= m+1; j++ )
            if ( a[i][j] < -EPS || a[i][j] > EPS )
                break;
        if ( j == m+2 )
            continue;
        if ( j == m+1 ){
            sol = -1;
            break;
        }
        x[j] = a[i][m+1];
        for ( k = j+1; k <= m; k++ )
            x[j] -= x[k]*a[i][k];
    }
    if ( sol == -1 )
         g<<"Imposibil";
    else for ( i=1; i <= n; i++ )
            g<<setprecision(10)<<fixed<<x[i]<<" ";
    return 0;
}
