#include<cstdio>
#include<cmath>
#define E 0.001
const int M=20000000;
int n,m,i,j,k,l,e,o;
double a[302][302],x[302],y;
char q[M],p[M];
inline int B()
{
  	int s=0;
  	for(;q[e]<'0'||q[e]>'9';e++);
  	for(;q[e]>='0'&&q[e]<='9';e++)
  		s=s*10+q[e]-'0';
  	return s;
}
inline int C()
{
    int s=1,x=0;
    for(;(q[e]<'0'||q[e]>'9')&&q[e]!='-';e++);
    if(q[e]=='-')
        e++,s=-1;
    for(;q[e]>='0'&&q[e]<='9';e++)
        x=x*10+q[e]-'0';
    return x*s;
}
inline void T(double x)
{
    if(x<0)
        x=-x,p[o++]='-';
    long long y=(long long)x,e[100],f[20]={0},j=0,k=0,i;
    long long z=(long long)round((x-y)*1000000000);
    if(z==1000000000)
        y++;
    for(;y;y/=10)
        e[++j]=y%10;
    if(!j)
        p[o++]=48;
    else
        for(i=j;i;i--)
            p[o++]=e[i]+48;
    for(;z;z/=10)
        f[++k]=z%10;
    p[o++]='.';
    for(i=9;i;i--)
        p[o++]=f[i]+48;
    p[o++]=32;
}
int main ()
{
    freopen("gauss.in","r",stdin),freopen("gauss.out","w",stdout),fread(q,1,M,stdin),n=B(),m=B();
	for(i=1;i<=n;++i)
		for(j=1;j<=m+1;++j)
			a[i][j]=C();
	for(j=1;j<=m;++j)
	{
		for(i=j;i<=n;++i)
			if(a[i][j]>E||a[i][j]<-E)
				break;
		if(i>n)
			continue;
		if(i!=j)
			for(k=1;k<=m+1;++k)
				y=a[i][k],a[i][k]=a[j][k],a[j][k]=y;
		for(k=j+1;k<=m+1;++k)
			a[j][k]/=a[j][j];
		for(a[j][j]=1,k=j+1;k<=n;a[k][j]=0,++k)
			for(l=j+1;l<=m+1;++l)
				a[k][l]-=a[j][l]*a[k][j];
	}
	for(i=n;i;--i)
		for(j=1;j<=m+1;++j)
			if(a[i][j]>E||a[i][j]<-E)
			{
				if(j==m+1)
				{
					printf("Imposibil");
					return 0;
				}
				for(x[j]=a[i][m+1],k=j+1;k<=m;++k)
					x[j]-=x[k]*a[i][k];
				break;
			}
	for(i=1;i<=m;++i)
        T(x[i]);
    fwrite(p,1,o,stdout);
}
