#include <cstdio>
#include <algorithm>

#define eps 1e-8

using namespace std;

double v[310][310], ans[310];
int poz[310];

int main ()
{
    freopen ("gauss.in", "r", stdin);
    freopen ("gauss.out", "w", stdout);

    int n, m;
    scanf ("%d %d", &n, &m);

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m + 1; ++j)
            scanf ("%lf", &v[i][j]);


    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m + 1; ++j)
            if (v[i][j] >= eps || v[i][j] <= -eps)
            {
                poz[i] = j;
                break;
            }

        if (!poz[i]) continue;
        if (poz[i] == m + 1)
        {
            printf ("Imposibil\n");
            return 0;
        }

        for (int h = 1; h <= n; ++h)
        {
            if (h == i || (-eps < v[h][poz[i]] && v[h][poz[i]] < eps)) continue;

            double cit = v[i][poz[i]] / v[h][poz[i]];

            for (int j = 1; j <= m + 1; ++j)
                v[h][j] = v[h][j] * cit - v[i][j];
        }
    }

    for (int i = 1; i <= n; ++i)
        if (poz[i])
            ans[poz[i]] = v[i][m + 1] / v[i][poz[i]];

    for (int i = 1; i <= m; ++i)
        printf ("%.12f ", ans[i]);

    printf ("\n");

    return 0;
}
