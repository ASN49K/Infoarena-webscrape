#include <bits/stdc++.h>

using namespace std;

#ifdef LOCAL
ifstream fin("input.txt");
#define fout cout
#else
ifstream fin("gauss.in");
ofstream fout("gauss.out");
#define endl '\n'
#endif

const int NMAX = 305;
const double ZERO = 1e-10;

int n, m;
double a[NMAX][NMAX];
double ans[NMAX];
bool solved[NMAX];

void read() {
   fin >> n >> m;
   for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= m + 1; j++) {
         fin >> a[i][j];
      }
   }
}

int find_line(int i, int j) {
   for (int i2 = i; i2 <= n; i2++) {
      if (abs(a[i2][j]) > ZERO) {
         return i2;
      }
   }
   return 0;
}

void swap_lines(int i1, int i2) {
   for (int j = 1; j <= m + 1; j++) {
      swap(a[i1][j], a[i2][j]);
   }
}

void solve() {
   int i = 1;
   for (int j = 1; i <= n && j <= m; j++) {
      if (int i2 = find_line(i, j)) {
         swap_lines(i, i2);
      } else {
         continue;
      }

      for (int j2 = j + 1; j2 <= m + 1; j2++) {
         a[i][j2] /= a[i][j];
      }
      a[i][j] = 1.0;

      for (int i2 = i + 1; i2 <= n; i2++) {
         for (int j2 = j + 1; j2 <= m + 1; j2++) {
            a[i2][j2] -= a[i2][j] * a[i][j2];
         }
         a[i2][j] = 0.0;
      }

      i++;
   }

   for (int i = n; i >= 1; i--) {
      for (int j = 1; j <= m + 1; j++) {
         if (abs(a[i][j]) > ZERO) {
            if (j == m + 1) {
               fout << "Imposibil" << endl;
               return;
            }
            ans[j] = a[i][m + 1];
            for (int j2 = j + 1; j2 <= m; j2++) {
               ans[j] -= a[i][j2] * ans[j2];
            }
            break;
         }
      }
   }

   for (int i = 1; i <= m; i++) {
      fout << setprecision(8) << fixed << ans[i] << ' ';
   }
}

signed main() {
   read();
   solve();
   return 0;
}
