# include <iostream>
# include <fstream>
# include <valarray>
# include <iomanip>

using namespace std;
# define MAX_N 300
# define MAX_M 300

# define EPS 1e-10

valarray<double> e[MAX_N];
vector<double> vals( MAX_M, 0 );

inline bool null( const double &t )
{
  return abs( t ) <= EPS;
}

int main()
{
    ifstream fin( "gauss.in" );
    ofstream fout( "gauss.out" );

    ios::sync_with_stdio( false );

    int n, m, i, j, k;

    fin >> n >> m;

    for ( i = 0; i < n; i ++ ) {
      e[i].resize( m + 1 );

      for ( j = 0; j <= m; j ++ )
        fin >> e[i][j];
    }

    for ( i = j = 0; i < n && j < m; j ++ ) {
      if ( null( e[i][j] ) ) {
        k = i + 1;
        while ( k < n && null( e[k][j] ) )
          k ++;

        if ( k < n )
          swap( e[i], e[k] );
      }

      if ( e[i][j] ) {
        for ( k = 0; k < n; k ++ )
          if ( k != i && !null( e[k][j] ) )
            e[k] -= e[i] * ( e[k][j] / e[i][j] );

        i ++;
      }
    }

    for ( i = 0; i < n; i ++ ) {
      j = 0;
      while ( j < m && null( e[i][j] ) )
        j ++;

      if ( j == m && !null( e[i][j] ) ) {
        fout << "Imposibil";
        return 0;
      } else {
        vals[j] = e[i][m] / e[i][j];
      }
    }

    fout << fixed << setprecision( 10 );
    for ( i = 0; i < m; i ++ )
      fout << vals[i] << ' ';
    fout << endl;

    fin.close();
    fout.close();

    return 0;
}
