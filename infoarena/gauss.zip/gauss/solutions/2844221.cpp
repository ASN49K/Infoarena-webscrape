#include <bits/stdc++.h>
#define eps 0.0000001
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int dim=350;

int n,m;
long double v[dim][dim],ans[dim],copie[dim][dim];

void swap_linii(int a,int b){
    for(int j=1;j<=m+1;j++){
        swap(v[a][j],v[b][j]);
    }
}

bool nenul(long double x){
    return !(x<eps && x>-eps);
}

signed main(){
            fin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m+1;j++){
            fin>>v[i][j];
            copie[i][j]=v[i][j];
        }
    }
    for(int i=1;i<=m;i++){

        int retine=i;
        for(int j=i;j<=n;j++){
            if(nenul(v[j][i])){
                retine=j;
                break;
            }
        }
        swap_linii(i,retine);

        if(!nenul(v[i][i])){
            continue;
        }

        long double cnst=v[i][i];
        for(int j=1;j<=m+1;j++){
            v[i][j]/=cnst;
        }
        for(int l=i+1;l<=n;l++){
            long double cnst=v[l][i];
            for(int j=1;j<=m+1;j++){
                v[l][j]-=v[i][j]*cnst;
            }
        }
        for(int l=i-1;l>=1;l--){
            long double cnst=v[l][i];
            for(int j=1;j<=m+1;j++){
                v[l][j]-=v[i][j]*cnst;
            }
        }
    }

    for(int i=1;i<=n;i++){
        ans[i]=v[i][m+1];
    }

    for(int i=1;i<=n;i++){
        long double sum=0;
        for(int j=1;j<=m;j++){
            sum+=copie[i][j]*ans[j];
        }
        if(nenul(sum-copie[i][m+1])){
            fout<<"Imposibil";
            return 0;
        }
    }

    for(int i=1;i<=m;i++){
        fout<<fixed<<setprecision(10)<<ans[i]<<' ';
    }
}
