
#include <iostream>
#include <fstream>
 
int n,m;	
long double v[350][350];
long double sol[350];
long double eps=1e-10;
 
int main()
{
  freopen("gauss.in","r",stdin);
  freopen("gauss.out","w",stdout);
  scanf("%d %d",&m,&n);
  for(int i=0;i<m;i++)
    for(int j=0;j<=n;j++)
      scanf("%llf",&v[i][j]);
  int i=0,j=0;
  while(i<m && j<n)
  {
    int k;
    for(k=i;k<m;k++)
      if(v[k][j]<-eps || v[k][j]>eps)
        break;
    if(k==m)
    {
      j++;
      continue;
    }
    if(i!=k)
      std::swap(v[i],v[k]);
    for(int l=n;l>=j;l--)
      v[i][l]=v[i][l]/v[i][j];
    for(int l=i+1;l<m;l++)
    {
      for(int o=n;o>=j;o--)
        v[l][o]-=v[l][j]*v[i][o];
    }
    i++,j++;
  }
  for( j=m-1;j>=0;j--)
  {
    for(int p =0;p<=n;p++)
      if(v[j][p]>eps ||v[j][p]<-eps )
      {
        if(p==n)
        {
          printf("Imposibil");
          return 0;
        }
        sol[p]=v[j][n];
        for(i=p+1;i<n;i++)
          sol[p]-=v[j][i]*sol[i];
        break;
      }
  }
  for(j=0;j<n;j++)
    printf("%.8llf ", sol[j]);
  printf("\n");
}
