#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;
const double eps=1e-10;
const int NMAX=300;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n, m;
double a[NMAX+1][NMAX+2], x[NMAX+1];

void gauss()
{
    int i=1,j=1,k,p;
    while(i<=n&&j<=m)
    {
        if(abs(a[i][j])<=eps)
        {
            bool ok=0;
            for(k=i+1; k<=n; k++)
                if(abs(a[k][j])>eps)
                {
                    ok=1;
                    for(p=j; p<=m+1; p++)
                        swap(a[i][p],a[k][p]);
                    break;
                }
            if(ok==0) //if(k==n+1)
            {
                j++;
                continue;
            }
        }

        for(k=j+1; k<=m+1; k++)
            a[i][k]/=a[i][j];
        a[i][j]=1.0;
        for(k=i+1; k<=n; k++)
        {
            for(p=j+1; p<=m+1; p++)
                a[k][p]-=a[k][j]*a[i][p];
            a[k][j]=0.0;
        }
        i++;
        j++;
    }

}

bool solutie()
{
    for(int i=n; i>=1; i--)
        for(int j=i; j<=m+1; j++)
            if(abs(a[i][j])>eps)
            {
                if(j==m+1)
                    return 0;
                x[j]=a[i][m+1];
                for(int k=j+1; k<=m; k++)
                    x[j]-=x[k]*a[i][k];
                break;
            }
    return 1;
}

void afisare()
{
    for(int i=1; i<=m; i++)
        fout<<fixed<<setprecision(10)<<x[i]<<' ';
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m+1; j++)
            fin>>a[i][j];

    gauss();
    if(solutie())
        afisare();
    else
        fout<<"Imposibil";

    fin.close();
    fout.close();
    return 0;
}
