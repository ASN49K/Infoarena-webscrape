#include <bits/stdc++.h>
using namespace std;
//#define EPS 0.000000001
int p[303],n,m,i,k,j;
double a[303][303],sol[303],r, EPS=1e-8,pp;
double modul(double x)
{
    if(x<0)return -x;
    return x;
}
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&m,&n);
    for(i=1;i<=m;i++)
        for(j=1;j<=n+1;j++)
        scanf("%lf",&a[i][j]);
    for(i=1;i<=m;i++)
    {
        p[i]=0;
        for(j=1;j<=n+1;j++)
        {
            if(modul(a[i][j])>EPS)
            {
                p[i]=j;
                break;
            }
        }
        if(p[i]==n+1){printf("Imposibil\n");return 0;}
        if(p[i]==0)continue;

            for(j=1;j<=m;j++)
            {
                if(j!=i&&modul(a[j][p[i]])>EPS)
                {
                    r=(double)a[j][p[i]]/a[i][p[i]];
                    for(k=1;k<=n+1;k++)
                        a[j][k]=(double)a[j][k]-a[i][k]*r;
                }
            }

    }
    for(i=1;i<=m;i++)
    {
        if(p[i])sol[p[i]]=(double)a[i][n+1]/a[i][p[i]];
    }
    for(i=1;i<=n;i++)
    {
        printf("%.10lf ",sol[i]);
    }
    return 0;
}
