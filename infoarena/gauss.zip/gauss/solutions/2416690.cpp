//sursa scop didactic
#include <bits/stdc++.h>
#define ld long double
using namespace std;
ifstream f ("gauss.in");
ofstream g ("gauss.out");
const ld eps=1e-9;
const int nmax=3e2+3;
int n,m;
ld v[nmax][nmax],sol[nmax];
int main()
{
    ios::sync_with_stdio(false);
    f>>n>>m;
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=m+1;++j) f>>v[i][j];
    }
    for(int k,i=1,j=1;i<=n&&j<=m;++i,++j)
    {
        for(k=i;k<=n;++k) if(v[k][j]<-eps||v[k][j]>eps) break;
        if(k>n) continue;
        if(k!=i) for(int l=1;l<=m+1;++l) swap(v[k][l],v[i][l]);
        for(int l=j+1;l<=m+1;++l) v[i][l]/=v[i][j];
        v[i][j]=1;
        for(int l=i+1;l<=n;l++)
        {
            for(int t=j+1;t<=m+1;++t) v[l][t]-=(v[l][j]*v[i][t]);
            v[l][j]=0;
        }
    }
    for(int i=n;i>=1;--i)
    {
        for(int j=1;j<=m+1;++j)
        {
            if(v[i][j]<-eps||v[i][j]>eps)
            {
                if(j==m+1)
                {
                    g<<"Imposibil";
                    return 0;
                }
                sol[j]=v[i][m+1];
                for(int k=j+1;k<=m;k++) sol[j]-=(sol[k]*v[i][k]);
                break;
            }
        }
    }
    for(int i=1;i<=m;++i) g<<fixed<<setprecision(9)<<sol[i]<<' ';
    return 0;
}
