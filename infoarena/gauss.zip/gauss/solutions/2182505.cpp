#include <bits/stdc++.h>
#define nmax 305
#define ap 0.00000001

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n,m;
double a[nmax][nmax],sol[nmax];

int main() {
    int i,j,u,v,k;
    double aux;
    f>>n>>m;
    for (i=1;i<=n;i++)
        for (j=1;j<=m+1;j++)
            f>>a[i][j];
    i=1; j=1;
    while (i<=n && j<=m) {
        k=-1;
        for (u=i;u<=n;u++)
            if (abs(a[u][j])>ap) { ///caut un element nenul de pe coloana j ca sa aleg pivotul
                k=u;
                u=n+1;
            }
        if (k==-1) ///daca am coloana nula (elementul j element liber)
            j++;
        else {
            if (k!=i) ///daca pivotul nu se afla pe linia i, interschimb linia i cu linia k
                for (u=1;u<=m+1;u++) {
                    aux=a[i][u];
                    a[i][u]=a[k][u];
                    a[k][u]=aux;
                }
            for (v=j+1;v<=m+1;v++) ///impart toata linia la a[i][j] ca sa obtin 1 in locul pivotului
                a[i][v]/=a[i][j];
            a[i][j]=1;
            for (u=i+1;u<=n;u++) { ///scad linia i inmultita cu a[u][j] din linia u
                for (v=j+1;v<=m+1;v++)
                    a[u][v]-=a[u][j]*a[i][v];
                a[u][j]=0;
            }
            i++;
            j++;
        }
    }
    for (i=n;i>=1;i--)
        for (j=1;j<=m+1;j++)
            if (abs(a[i][j]>ap)) {
                if (j==m+1) { ///daca toata linia e nula, dar rezultatul e nenul
                    g<<"Imposibil";
                    return 0;
                }
                else {
                    sol[j]=a[i][m+1];
                    for (u=j+1;u<=m;u++) {
                        sol[j]-=sol[u]*a[i][u];
                        a[i][u]=0;
                    }
                    for (u=j+1;u<=m;u++)
                        if (a[i][j]>ap) {
                            g<<"Imposibil";
                            return 0;
                        }
                    break;
                }
            }
    for (i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<sol[i]<<' ';
    return 0;
}
