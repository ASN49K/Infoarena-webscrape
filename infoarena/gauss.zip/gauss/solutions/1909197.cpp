#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

const int MAXN = 301;
const double EPS = 0.0000001;

int n, m;
double a[MAXN][MAXN + 1];
double x[MAXN];

int main(int argc, const char * argv[]) {
    ifstream cin("gauss.in");
    ofstream cout("gauss.out");
    
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m + 1; j++) {
            cin >> a[i][j];
        }
    }
    
    int i = 0, j = 0, k;
    
    while (i < n && j < m) {
        for (k = i; k < n; k++) {
            if (a[k][j] < -EPS || a[k][j] > EPS) {
                break;
            }
        }
        
        if (k == n) {
            j++;
            continue;
        }
        
        if (k != i) {
            for (int l = 0; l < m + 1; l++) {
                swap(a[i][l], a[k][l]);
            }
        }
        
        for (int l = m; l >= j; l--) {
            a[i][l] /= a[i][j];
        }
        
        for (int u = i + 1; u < n; u++) {
            for (int l = m; l >= j; l--) {
                a[u][l] -= a[i][l] * a[u][j];
            }
        }
        i++, j++;
    }
    
    for (i = n - 1; i >= 0; i--) {
        for (j = 0; j < m; j++) {
            if (a[i][j] < -EPS || a[i][j] > EPS) {
                break;
            }
        }
        if (j == m) {
            cout << "Imposibil";
            return 0;
        }
        x[j] = a[i][m];
        for (k = j + 1; k < m; k++) {
            x[j] -= a[i][k] * x[k];
        }
    }

    cout << setprecision(6) << fixed;
    for (i = 0; i < m; i++) {
        cout << x[i] << ' ';
    }
    
    return 0;
}
