#include <bits/stdc++.h>

using namespace std;

const int NMAX = 300;
const double EPS = 0.0001;

double a[NMAX][NMAX + 1];
double ans[NMAX];

bool isZero( double a ) {
    return abs( a ) <= EPS;
}
int main() {
    ifstream fin( "gauss.in" );
    ofstream fout( "gauss.out" );
    int n, m;
    fin >> n >> m;
    for ( int i = 0; i < n; i ++ ) {
        for ( int j = 0; j <= m; j ++ ) {
            fin >> a[i][j];
        }
    }
    for ( int col = 0; col < n; col ++ ) {
        int l = -1;
        for ( int i = col; i < n; i ++ ) {
            if ( !isZero( a[i][col] ) ) {
                l = col;
            }
        }
        if ( l == -1 ) continue;
        for ( int j = 0; j <= m; j ++ ) {
            swap( a[l][j], a[col][j] );
        }
        l = col;
        for ( int i = 0; i < n; i ++ ) {
            if ( i != l ) {
                double ratio =  a[i][col] / a[l][col];
                for ( int j = 0; j <= m; j ++ ) {
                    a[i][j] -= ratio * a[l][j];
                }
            }
        }
    }
    for ( int i = n - 1; i >= 0; i -- ) {
        if ( isZero( a[i][i] ) ) continue;
        double rasp = a[i][m];
        for ( int j = 0; j < m; j ++ ) {
            if ( j != i ) {
                rasp -= a[i][j] * ans[j];
            }
        }
        ans[i] = rasp / a[i][i];
    }
    bool isPossible = true;

    for ( int i = 0; i < n; i ++ ) {
        double rasp = a[i][m];
        for ( int j = 0; j < m; j ++ ) {
            rasp -= a[i][j] * ans[j];
        }
        if ( !isZero( rasp ) ) isPossible = false;
    }
    if ( isPossible ) {
        fout << fixed << setprecision( 10 );
        for ( int i = 0; i < m; i ++ ) {
            fout << ans[i] << '\n';
        }
    } else {
        fout << "Imposibil\n";
    }
    return 0;   
}