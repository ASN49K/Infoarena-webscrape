import numpy as np
import math
import operator


class Linear_Regression:
  
    def __init__(self, learning_rate, absolute_error):
        self.alpha = learning_rate
        self.err = absolute_error                 

    def fit(self, X, Y):
           m = X.shape[0]

           n = X.shape[1]

           self.coef  = np.random.randint(n, size=(n,1)).astype('float64')
      
           X = np.matrix(X)
           Y = np.matrix(Y)
           Y = Y.T
           self.coef = np.matrix(self.coef)
   
           last_cost = 0
           current_cost = 100

           while(math.fabs(current_cost - last_cost) > self.err):
                 last_cost = current_cost
                 self.coef = self.coef - self.alpha/m*(((X*self.coef - Y)).T*X).T
             
                 current_cost = np.power((X*self.coef - Y),2).sum()/(2*m)

    def predict(self, X):
        return (X*self.coef)

f = open("gauss.in", "r")

n,m = map(int, f.readline().split())

training_data = [] 
training_label = [] 


for i in range(n):
    training_data.append([float(x) for x in f.readline().split()])

lr = Linear_Regression(0.1, 0.00000001)

training_data = np.array(training_data)

training_label = training_data[:,-1:]

training_data = training_data[:, :-1]

lr.fit(training_data, training_label.ravel())

np.savetxt("gauss.out", lr.coef, fmt="%f")


