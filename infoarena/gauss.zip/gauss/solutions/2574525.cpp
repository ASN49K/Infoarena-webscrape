#include <bits/stdc++.h>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n,col,k,m,i,j;
double sol[310],a[310][310];

int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    }

    i=1;j=1;
    while(i<=n && j<=m)
    {
        k=i;
        while(k<=n && a[k][j]==0)k++;
        if(k==n+1){i++;j++;continue;}

        for(col=j;col<=m+1;col++)swap(a[i][col],a[k][col]);

        for(col=j+1;col<=m+1;col++)a[i][col]/=a[i][j];
        a[i][j]=1;

        for(k=i+1;k<=n;k++)
        {
            for(col=j+1;col<=m+1;col++)
                a[k][col]-=a[i][col]*a[k][j];
            a[k][j]=0;
        }
        i++;j++;
    }

    for(i=n;i>=1;i--)
    {
        j=1;
        while(a[i][j]==0 && j<=m)j++;
        if(j==m+1)
        {
            g<<"Imposibil";
            return 0;
        }

        sol[j]=a[i][m+1];
        for(col=j+1;col<=m;col++)sol[j]-=a[i][col]*sol[col];
    }

    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<sol[i]<<" ";
    return 0;
}
