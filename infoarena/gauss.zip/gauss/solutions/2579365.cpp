#include <bits/stdc++.h>
 
using namespace std;
 
int main() {
  ifstream cin("gauss.in");
  ofstream cout("gauss.out");

  int n, m; cin >> n >> m;
  vector<vector<double>> a(n, vector<double>(m + 1));
  for (int i = 0; i < n; ++i)
    for (int j = 0; j <= m; ++j)
      cin >> a[i][j];

  vector<int> pivc(m, -1), pivr(n, -1);
  while (true) {
    double best = 1e-9; int is = -1, js = -1;
    for (int i = 0; i < n; ++i) 
      if (pivr[i] == -1) 
        for (int j = 0; j < m; ++j) 
          if (pivc[j] == -1 && abs(a[i][j]) > best)
            best = abs(a[i][j]), is = i, js = j;

    if (js == -1) break;
    pivc[js] = is; pivr[is] = js;

    double coef = a[is][js];
    for (int j = 0; j <= m; ++j)
      a[is][j] /= coef;

    for (int i = 0; i < n; ++i) if (i != is) {
      double coef = a[i][js];
      for (int j = 0; j <= m; ++j)
        a[i][j] -= coef * a[is][j];
    }
  }

  vector<double> sol(m, 0);
  for (int i = 0; i < m; ++i)
    if (pivc[i] != -1)
      sol[i] = a[pivc[i]][m];
  
  for (int i = 0; i < n; ++i) {
    double chk = 0;
    for (int j = 0; j < m; ++j)
      chk += sol[j] * a[i][j];
    if (abs(chk - a[i][m]) > 1e-9) {
      cout << "Imposibil\n";
      return 0;
    }
  }

  cout << fixed << setprecision(10);
  for (int i = 0; i < m; ++i)
    cout << sol[i] << " ";
  cout << endl;

  return 0;
}
