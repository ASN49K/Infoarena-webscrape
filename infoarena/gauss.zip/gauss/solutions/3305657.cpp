#include <bits/stdc++.h>

using namespace std;
using ld = long double;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMAX = 300;
const ld EPS = 1e-10;

int n, m, ind;
ld a[NMAX + 1][NMAX + 2];
int pivot[NMAX + 1];
ld x[NMAX + 1];

int main() {
    fin >> n >> m;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m + 1; j++) {
            fin >> a[i][j];
        }
    }

    for(int row = 1, col = 1; row <= n && col <= m + 1; col++) {
        int good_row = row;
        for(int i = row + 1; i <= n; i++) {
            if(abs(a[i][col]) > abs(a[good_row][col])) {
                good_row = i;
            }
        }
        if(abs(a[good_row][col]) < EPS) {
            continue;
        }

        pivot[++ind] = col;
        swap(a[row], a[good_row]);
        for(int i = 1; i <= n; i++) {
            ld coef = a[i][col] / a[row][col];
            if(i == row || abs(coef) < EPS) {
                continue;
            }
            for(int j = 1; j <= m + 1; j++) {
                a[i][j] -= coef * a[row][j];
            }
        }
        row++;
    }

    if(!ind || pivot[ind] == m + 1) {
        fout << "imposibil\n";
        return 0;
    }

    for(int i = 1; i <= ind; i++) {
        x[pivot[i]] = a[i][m + 1] / a[i][pivot[i]];
    }

    for(int i = 1; i <= m; i++) {
        fout << fixed << setprecision(8) << x[i] << ' ';
    }
    return 0;
}
