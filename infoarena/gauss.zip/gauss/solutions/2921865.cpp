#include <fstream>
#include <iostream>
#include <vector>
#include <cassert>
#include <cstring>
#include <set>
#include <unordered_map>
#include <memory>
#include <deque>
#include <queue>
#include <iomanip>

using namespace std;

const double eps = 1e-10;

bool eq(double a, double b) {
    if (a + eps > b)
        swap(a, b);
    return b - a < eps;
}

vector<double> solve(int N, int M, vector<vector<double> >& A) {
    int i = 0, j = 0;
    while (i < N && j < M) {
        for (int l = i; l < N; l++)
            if (!eq(A[l][j], 0)) {
                A[l].swap(A[i]);
                break;
            }
        if (eq(A[i][j], 0)) {
            ++j;
            continue;
        }
        
        for (int c = M; c >= j; c--)
            A[i][c] /= A[i][j];
        
        for (int l = i + 1; l < N; l++)
            for (int c = M; c >= j; c--)
                A[l][c] -= A[l][j] * A[i][c];
        
        i++;
        j++;
    }

    vector<double> x(M, 0.0);

    j = M - 1;
    for (i = N - 1; i >= 0; i--) {
        for (;j >= 0 && eq(A[i][j], 0.0); --j);

        double r = A[i][M];
        for (int c = j + 1; c < M; c++)
            r -= A[i][c] * x[c];
        
        if (j >= 0) {
            x[j] = r / A[i][j];
            --j;
            continue;
        }

        if (!eq(r, 0))
            return vector<double>();
    }

    return x;
}

int main() {
    ifstream f("gauss.in");
    ofstream g("gauss.out");

    int N, M;
    f >> N >> M;

    vector<vector<double> > A(N, vector<double>(M + 1));

    for (int i = 0; i < N; i++)
        for (int j = 0; j <= M; j++)
            f >> A[i][j];
    

    vector<double> sol = solve(N, M, A);

    if (sol.empty()) {
        g << "Imposibil";
    } else {
        for (double x : sol)
            g << fixed << setprecision(10) << x << ' ';
    }
    g << '\n';


    f.close();
    g.close();
    return 0;
}