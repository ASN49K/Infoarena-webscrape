#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("gauss.in" , "r" , stdin) , freopen("gauss.out" , "w" , stdout)
#define ld long double

using namespace std;

const int N = 305;

int n , m;
ld a[N][N] , x[N];

int getpos(int l , int c)
{
    for(int i = l ; i <= n ; i++)
        if(a[i][c])
            return i;

    return n + 1;
}

void SWAP(int l1 , int l2)
{
    for(int j = 1 ; j <= m + 1 ; j++)
        swap( a[l1][j] , a[l2][j] );
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n >> m;

    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= m + 1 ; j++)
            cin >> a[i][j];

    int i = 1 , j = 1 , t;

    while(i <= n && j <= m)
    {
        int l = getpos(i , j);

        if(l == n + 1)
        {
            j++;
            continue;
        }

        SWAP(i , l);

        for(int t = j ; t <= m + 1 ; t++)
            a[i][t] /= a[i][j];

        for(int u = i + 1 ; u <= n ; u++)
            for(int t = j ; t <= m + 1 ; t++)
                a[u][t] -= a[u][j] * a[i][t];

        i++ , j++;
    }

    for(i = n ; i >= 1 ; i--)
        for(j = 1 ; j <= m + 1; j++)
            if(a[i][j])
            {
                if(j > m)
                    return cout << "Imposibil" , 0;

                x[j] = a[i][m + 1];

                for(t = j + 1 ; t <= m ; t++)
                    x[j] -= x[t] * a[i][t];

                break;
            }


    cout << fixed << setprecision(10);

    for(i = 1 ; i <= m ; i++)
        cout << x[i] << ' ';

    return 0;
}
