#include <fstream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <stack>
#include <iomanip>
#include <queue>
using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

#define nmax 310
#define eps 0.0000001
double a[nmax][nmax],ans[nmax];
int n,m,i,j,k;

int main()
{
    fin >> n >> m;
    for (i=1; i<=n; i++)
        for (j=1; j<=m+1; j++)
            fin >> a[i][j];
    i=1;
    j=1;
    while (i<=n&&j<=m)
    {
        for (k=i; k<=n; k++)
            if (a[k][j]<-eps||a[k][j]>eps)
                break;
        if (k==n+1)
        {
            j++;
            continue;
        }
        if (k!=i)
            for (int x=1; x<=m+1; x++)
            {
                int aux=a[i][x];
                a[i][x]=a[k][x];
                a[k][x]=aux;
            }
        for (int x=j+1; x<=m+1; x++)
            a[i][x]/=a[i][j];
        a[i][j]=1;
        for (int x=i+1; x<=n; x++)
        {
            for (int y=j+1; y<=m+1; y++)
                a[x][y]=a[x][y]-a[x][j]*a[i][y];
            a[x][j]=0;
        }
        i++;
        j++;
    }
    for (i=n; i; i--)
        for (j=1; j<=m+1; j++)
            if (a[i][j]>eps||a[i][j]<-eps)
            {
                if (j==m+1)
                {
                    fout << "Imposibil\n";
                    return 0;
                }
                ans[j]=a[i][m+1];
                for (int x=j+1; x<=m; x++)
                    ans[j]=ans[j]-a[i][x]*ans[x];
                break;
            }
    for (i=1; i<=m; i++)
        fout << fixed << setprecision(10) << ans[i] << ' ';
}
