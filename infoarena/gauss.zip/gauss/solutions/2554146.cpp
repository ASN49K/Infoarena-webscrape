#define eps 0.0000001
#define NMAX 310
#include <iostream>
#include <cstdio>
using namespace std;

int n, m;
double a[NMAX][NMAX];
double rez[NMAX];
double vals[NMAX];


int isZero(double x)
{
    if(-eps < x && x < eps)
        return 1;
    return 0;
}



void make1_onLine(int line)
{
    double for1 = a[line][line];
    for(int j = line; j <= n; ++j)
        a[line][j] /= for1;
    rez[line] /= for1;

}

void make0_onLine(int line, int column, int relativeToLine)
{
    double multipl = -a[line][column];
    for(int j = column; j <= n; ++j)
        a[line][j] = a[line][j] + a[relativeToLine][j] * multipl;
    rez[line] = rez[line] + rez[relativeToLine] * multipl;
}


void diff_startingOn(int line, int column)
{
    for(int i = line; i <= n; ++i)
        if(a[i][column] != 0)
            make0_onLine(i, column, line-1);
}



void swp(int i, int l)
{
    for(int j = 1; j <= n; ++j)
        swap(a[i][j], a[l][j]);
}



void read()
{
    scanf("%d %d", &n, &m);
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= m; ++j)
            scanf("%lf", &a[i][j]);
        scanf("%lf", &rez[i]);
    }
    if(n > m)
        n = m;
}

void form_a()
{
    int plusJ = 0;
    for(int l_to_solve = 1; l_to_solve <= n; ++l_to_solve)
    {
        if(!isZero(a[l_to_solve][l_to_solve + plusJ]))
        {
            make1_onLine(l_to_solve);
            diff_startingOn(l_to_solve+1, l_to_solve + plusJ);
        }
        else{
            bool findn0 = 0;
            for(int i = l_to_solve+1; i <= n; ++i)
                if(!isZero(a[i][l_to_solve]))
                {
                    swp(i, l_to_solve);
                    make1_onLine(l_to_solve);
                    diff_startingOn(l_to_solve+1, l_to_solve + plusJ);
                    findn0 = 1;
                    break;
                }
            if(findn0 == 0)
                plusJ ++;
        }
    }
}

void write()
{
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            printf("%f ", a[i][j]);
        printf("\n");
    }
}

void solve()
{
    vals[n] = rez[n];
    for(int i = n - 1; i >= 1; --i)
    {
        vals[i] = rez[i];
        for(int j = n; j > i; --j)
            vals[i] -= vals[j] * a[i][j];
    }

}

void write_sol()
{
    for(int i = 1; i <= n; ++i)
        printf("%.10f ", vals[i]);
}

int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);
    read();
    form_a();
    solve();
   // write();
    write_sol();
    return 0;
}
