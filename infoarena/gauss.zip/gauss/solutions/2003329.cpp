#include <bits/stdc++.h>
#define MAXN 300

const long double eps = 1e-9;
long double a[MAXN + 1][MAXN + 2];
long double sol[MAXN + 1];

int main(){
    FILE *fi, *fout;
    int i, j, n, m, l, c;
    fi = fopen("gauss.in" ,"r");
    fout = fopen("gauss.out" ,"w");
    fscanf(fi,"%d %d " ,&n,&m);
    for(i = 1; i <= n; i++)
        for(j = 1; j <= m + 1; j++)
            fscanf(fi,"%lf " ,&a[i][j]);
    l = c = 1;
    while(l <= n && c <= m) {
        i = l;
        while(i <= n && std::abs(a[i][c]) < eps)
            i++;
        if(i == n + 1)
            c++;
        else {
            for(j = c; j <= m + 1; j++)
                std::swap(a[l][j], a[i][j]);
            for(j = c + 1; j <= m + 1; j++)
                a[l][j] /= a[l][c];
            a[l][c] = 1.0;
            for(i = l + 1; i <= n; i++) {
                for(j = c + 1; j <= m + 1; j++)
                   a[i][j] -= a[i][c] * a[l][j];
                a[i][c] = 0.0;
            }
            l++;
            c++;
        }
    }
    for(i = n; i >= 1; i--) {
        j = 1;
        while(j <= m && std::abs(a[i][j]) < eps)
            j++;
        if(j <= m) {
            for(c = m; c > j; c--)
                a[i][m + 1] -= a[i][c] * sol[c];
            sol[j] = a[i][m + 1];
        }
        else if(abs(a[i][m + 1]) > eps) {
            fprintf(fout,"Imposibil\n");
            return 0;
        }
    }
    for(i = 1; i <= m; i++)
        fprintf(fout,"%.10lf " ,sol[i]);
    fclose(fi);
    fclose(fout);
    return 0;
}
