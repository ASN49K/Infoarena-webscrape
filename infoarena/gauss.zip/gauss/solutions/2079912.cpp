#include <bits/stdc++.h>

using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
int n,m,i,j,k,p;
double ans[310],a[310][310];
bool viz[310];
int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    for(j=1;j<=m;j++)
        for(i=j;i<=n;i++)
            if(a[i][j]&&(!viz[i]))
            {
                viz[i]=1;
                for(p=1;p<=n;p++)
                    if(p!=i)
                    {
                        double x=a[p][j]/a[i][j];
                        for(k=1;k<=m+1;k++)
                            a[p][k]-=x*a[i][k];
                    }
                break;
            }
    for(i=n;i>=1;i--)
    {
        for(j=1;j<=m+1;j++)
            if(a[i][j])
                break;
        if(j==m+1)
        {
            cout<<"Imposibil!";
            return 0;
        }
        if(j==m+2)break;
        double x=0;
        for(k=j+1;k<=m;k++)
            x+=ans[k]*a[i][k];
        ans[j]=(a[i][m+1]-x)/a[i][j];
    }
    for(i=1;i<=m;i++)
        g<<fixed<<setprecision(10)<<ans[i]<<' ';
    return 0;
}
