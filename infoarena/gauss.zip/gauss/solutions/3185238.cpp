#include <fstream>
#include<iomanip>
#include<algorithm>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

double a[305][305], sol[305];
const double eps = 1e-10;

bool egal(double x, double y)
{
    return -eps < x - y && x - y < eps;
}
int main()
{
    int n, m;
    f >> n >> m;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m + 1; j++)
            f >> a[i][j];
    int i = 1, j = 1;
    while(i <= n && j <= m)
    {
        //cautam prima ecuatie care are coeficirntul pentru necunoscuta j nenul
        for(int k = i; k <= n; k++)
            if(!egal(a[k][j], 0))
            {
                for(int l = 1; l <= m + 1; l ++)
                    swap(a[i][l], a[k][l]);
                break;
            }
        if(egal(a[i][j], 0))//j este necunoscuta secundara
        {
            j++;
            continue;
        }
        //impartim ecuatia i la a[i][j]
        for(int l = j + 1; l <= m + 1; l++)
            a[i][l] /= a[i][j];
        a[i][j] = 1;
        //formam zerouri sub poz (i, j)
        for(int k = i + 1; k <= n; k++)
        {
            //scadem din ecuatia k ecuatia i * a[k][j]
            for(int l = j + 1; l <= m + 1; l ++)
                a[k][l] -= a[i][l] * a[k][j];
            a[k][j] = 0;
        }
        i ++;
        j ++;
    }
    for(int i = n; i >= 1; i --)
    {
        for(int j = 1; j <= m + 1; j++)
        {
            if(egal(a[i][j], 0))
                continue;
            if(j == m + 1)
            {
                g << "Imposibil\n";
                return 0;
            }
            sol[j] = a[i][m + 1];
            for(int l = j + 1; l <= m; l++)
                sol[j] -= a[i][l] * sol[l];
            // ar trebui sa impartim sol[j] la a[i][j], dar din implementare a[i][j] = 1
            break;
        }
    }
    for(int i = 1; i <= m; i++)
        g << setprecision(10) << fixed << sol[i] << " ";
    return 0;
}
