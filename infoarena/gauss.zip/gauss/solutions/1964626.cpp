#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

double v[303][303];
double ans[303];
double EPS = 1e-11;

void print(int n, int m) {

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m+1; j++) {
            cout << v[i][j] << " ";
        }
        cout << '\n';
    }
    cout << '\n';

}

bool eq(double a, double b) {
    //cout << b-EPS << " " << a << " " << b+EPS << '\n';
    return (a <= b+EPS && a >= b-EPS);
}

int main() {

    int n,m;
    in >> n >> m;
    cout << setprecision(15) << fixed;

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m+1; j++) {
            in >> v[i][j];
        }
    }

    int i = 1;
    int j = 1;

    while(i <= n && j <= m) {

        int k = 0;

        for(int K = i; K <= n; K++) {
            if(!eq(v[K][j], 0)) {
                k = j;
                break;
            }
        }

        if(k == 0) {
            j++;
            continue;
        }

        if(k != i)
            for(int J = 1; J <= m+1; J++)
                swap(v[i][J], v[k][J]);

        double temp = v[i][j];
        for(int J = 1; J <= m+1; J++)
            v[i][J] /= temp;

        for(int I = i+1; I <= n; I++) {
            double temp = v[I][j];
            for(int J = 1; J <= m+1; J++)
                v[I][J] -= v[i][J]*temp;
            v[I][j] = 0;
        }

        i++;
        j++;

    }

    //cout << eq(v[3][1], 0) << '\n';

    for(int i = n; i >= 1; i--) {
        for(int j = 1; j <= m+1; j++) {

            if(!eq(v[i][j], 0)) {

                if(j == m+1) {
                    out << "Imposibil";
                    return 0;
                }

                ans[j] = v[i][m+1];

                //cout << j << " " << ans[j] << '\n';

                for(int J = j+1; J <= m; J++)
                    ans[j] -= ans[J]*v[i][J];

                //cout << j << " " << ans[j] << '\n';
                break;

            }

        }
    }

    for(int i = 1; i <= m; i++)
        out << ans[i] << " ";
    out << '\n';

    return 0;
}
