///reducere
///ideea e sa ajunga asa matricea
///merge si pt xoruri
///1 a1 a2 a3 = t1
///0 1 b2 b3 = t2
///0 0 1 c3 = t3
///0 0 0 1 = t4

#include <fstream>
#include <iomanip>
#define EPS (long double)(1e-6)

using namespace std;

ifstream cin ("gauss.in");
ofstream cout ("gauss.out");

const int N = 310;

long double a[N + 1][N + 1], res[N + 1];

int n, m;

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m + 1; ++j)
            cin >> a[i][j];
    int i, j;
    i = j = 1;
    while (i <= n && j <= m)
    {
        ///fancy : impartim ecuatia i prin a[i][j]
        int k = i;
        for (; k <= n; ++k)
            if (a[k][j] > EPS || a[k][j] < -EPS)
                break;
        if (k == n + 1)
        {
            ++j;
            continue;
        }
        if (k != i)
            for (int l = 1; l <= m + 1; ++l)
            {
                long double aux = a[i][l];
                a[i][l] = a[k][l];
                a[k][l] = aux;
            }
        a[i][j] = 1;
        for (int l = j + 1; l <= m + 1; ++l)
            a[i][l] = a[i][l] / a[i][j];
        ///scadem ecutia in restul pt a le reduce
        for (int l = i + 1; l <= n; ++l)
        {
            long double coef = a[l][j];///a[l][j] -= a[i][j] * coef
            for (k = j + 1; k <= m + 1; ++k)
                a[l][k] -= coef * a[i][k];
            a[l][j] = 0;///facem astfel incat asta sa fie zero
        }
        ++i;
        ++j;
    }
    for (i = n; i >= 1; --i)
        for (j = 1; j <= m + 1; ++j)
            if (a[i][j] > EPS || a[i][j] < -EPS)
            {
                if (j == m + 1)
                {
                    cout << "Imposibil\n";
                    return 0;
                }
                res[j] = a[i][m + 1];
                for (int k = j + 1; k <= m; ++k)
                    res[j] -= res[k] * a[i][k];
                break;
            }
    for (int i = 1; i <= m; ++i)
        cout << setprecision(8) << fixed << res[i] << ' ';
    return 0;
}
