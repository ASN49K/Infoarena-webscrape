#include <bits/stdc++.h>

using namespace std;

#if 1
    #define pv(x) cout<<#x<<" = "<<(x)<<"; ";cout.flush()
    #define pn cout<<endl
#else
    #define pv(x)
    #define pn
#endif

#ifdef INFOARENA
    ifstream in("gauss.in");
    ofstream out("gauss.out");
#else
    #define in cin
    #define out cout
#endif

using ll = long long;
using ull = unsigned long long;
using uint = unsigned int;
using ld = long double;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld, ld>;
#define pb push_back
const long double PI = 3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862;
const int inf_int = 1e9 + 5;
const ll inf_ll = 1e18 + 5;
const int NMax = 300 + 5;
const int mod = 9907;
const int dx[] = {-1,0,0,+1}, dy[] = {0,-1,+1,0};

double a[NMax][NMax], val[NMax];

#define isZero(x) (abs(x) < 1e-3)

int main() {
    cin.sync_with_stdio(false);
    cin.tie(0);
    
    int N,M;
    in >> N >> M;
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= M+1; ++j) {
            in >> a[i][j];
        }
    }

    int i = 1, j = 1;
    while (i <= N && j <= M) {
        int idx = -1;
        for (int k = i; k <= N; ++k) {
            if (isZero(a[k][j])) {
                continue;
            }

            idx = k;
            break;
        }

        if (idx == -1) {
            ++j;
            continue;
        }

        for (int jj = j; jj <= M+1; ++jj) {
            swap(a[i][jj],a[idx][jj]);
        }

        for (int jj = j + 1; jj <= M+1; ++jj) {
            a[i][jj] /= a[i][j];
        }
        a[i][j] = 1.0;

        for (int ii = i + 1; ii <= N; ++ii) {
            for (int jj = j + 1; jj <= M+1; ++jj) {
                a[ii][jj] -= a[i][jj] * a[ii][j];
                if (isZero(a[ii][jj])) {
                    a[ii][jj] = 0.0;
                }
            }
            a[ii][j] = 0.0;
        }

        ++i; ++j;

        //////
        // for (int i = 1; i <= N; ++i) {
        //     for (int j = 1; j <= M+1; ++j) {
        //         out << a[i][j] << ' ';
        //     }
        //     out << '\n';
        // }
        // out << '\n';
    }

    for (int i = N; i > 0; --i) {
        int j;
        for (j = 1; j <= M+1; ++j) {
            if (!isZero(a[i][j])) {
                break;
            }
        }

        if (j == M + 2) {
            continue;
        }
        if (j == M + 1) {
            out << "Imposibil\n";
            return 0;
        }

        val[j] = a[i][M+1];
        for (int k = j+1; k <= M; ++k) {
            val[j] -= a[i][k] * val[k];
        }
    }

    out << fixed << setprecision(11);
    for (int j = 1; j <= M; ++j) {
        out << val[j] << ' ';
    }

    return 0;
}