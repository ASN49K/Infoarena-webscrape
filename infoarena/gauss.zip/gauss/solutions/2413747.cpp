#include <bits/stdc++.h>
#define ff first
#define ss second

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pi;

const string file = "gauss";
const ll INF = 9223372036854775807ll;
const int inf = 2147483647, nmax = 305;

int n, m;
ld v[nmax][nmax], val[nmax];

bool check()
{
    for (int i = 1; i <= n; ++i){
        ld now = 0;
        for (int j = 1; j <= m; ++j)
            now += val[j]*v[i][j];
        if(abs(now-v[i][m+1]) > 0.001)
            return false;
    }
    return true;
}

int main()
{
    ifstream fin (file+".in");
    ofstream fout (file+".out");
    fin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m+1; ++j)
            fin >> v[i][j];
    int a = 1, b = 1;
    while(a <= n && b <= m){
        int first = -1;
        for (int i = a; i <= n; ++i)
            if(v[i][b] != 0){
                first = i;
                break;
            }
        if(first == -1){
            ++b;
            continue;
        }
        for (int j = 1; j <= m+1; ++j)
            swap(v[a][j], v[first][j]);
        for (int j = m+1; j >= b; --j)
            v[a][j] /= v[a][b];
        for (int i = a+1; i <= n; ++i)
            for (int j = m+1; j >= b; --j)
                v[i][j] -= v[a][j]*v[i][b];
        ++a, ++b;
    }
    while(a >= 1){
        b = -1;
        for (int j = 1; j <= m; ++j)
            if(v[a][j] != 0){
                b = j;
                break;
            }
        if(b == -1){
            --a;
            continue;
        }
        val[b] = v[a][m+1];
        for (int j = b+1; j <= m; ++j)
            val[b] -= v[a][j]*val[j];
        --a;
    }
    if(check())
        for (int i = 1; i <= m; ++i)
            fout << fixed << setprecision(10) << val[i] << " ";
    else fout << "Imposibil\n";
    return 0;
}
