#include <bits/stdc++.h>
#define L 305
#define EPS 0.00001
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");

double m[L][L];
bool vis[L];

int main(){
  int l, c;
  fin >> l >> c;
  for (int i = 0; i < l; i++)
    for (int j = 0; j <= c; j++)
      fin >> m[i][j];
  for (int j = 0; j < c; j++){
    int rel = -1;
    for (int i = 0; i < l; i++)
      if (abs(m[i][j]) > EPS && !vis[i]){
        rel = i;
        i = l;
      }
    if (rel == -1){
      fout << "Imposibil\n";
      return 0;
    }
    vis[rel] = true;
    double x = m[rel][j];
    for (int k = 0; k <= c; k++)
      m[rel][k] /= x;
    for (int i = 0; i < l; i++)
      if (i != rel){
        double coef = m[i][j];
        for (int k = 0; k <= c; k++)
          m[i][k] -= coef * m[rel][k];
      }
    /**
    for (int ii = 0; ii < l; ii++){
      for (int jj = 0; jj <= c; jj++)
        cout << setprecision(2) << m[ii][jj] << " ";
      cout << "\n";
    }
    cout << "\n";
    **/
  }
  for (int j = 0; j < c; j++)
    for (int i = 0; i < l; i++)
      if (abs(m[i][j]) > EPS){
        fout << setprecision(10) << m[i][c] << " ";
        i = l;
      }
  return 0;
}
