#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
const int Nmax=305;
const double moe=1e-8;

int N,M;
int a[Nmax][Nmax],row[Nmax];

void read()
{
    fin>>N>>M;
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=M+1;j++)
        {
            fin>>a[i][j];
        }
    }
}

bool Z(double a)
{
    return (a>-moe) && (a<moe);
}


void solve()
{
    int l=1,c=1;
    while(l<=N && c<=M)
    {
        if(Z(a[l][c]))
        {
            int i=l+1;
            while(i<=N && Z(a[i][c]))
                i++;
            if(i>N)
            {
                c++;
                continue;
            }
            swap(a[l],a[i]);
        }
        for(int i=1;i<=N;i++)
        {
            if(i==l) continue;
            double k= a[i][c]/a[l][c];
            for(int j=1;j<=M+1;j++)
            {
                a[i][j]-=a[l][c]*k;
            }
        }
        row[c++]=l++;
    }
    if(c>M)
        for(;l<=N;l++)
        {
            if(!Z(a[l][M+1]))
            {
                fout<<"Imposibil\n";
                return ;
            }
        }
    fout<<setprecision(10)<<fixed;
    for(int i=1;i<=M;i++)
    {
        fout<<(row[i] ? (a[row[i]][M+1]/a[row[i]][i]) : 0.0 )<<" ";
    }
}


int main()
{
    read();
    solve();
    return 0;
}
