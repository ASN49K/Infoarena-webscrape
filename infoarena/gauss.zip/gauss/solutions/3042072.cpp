#include <bits/stdc++.h>
using namespace std;

const int NMAX = 300;
const double EPS = 0.001;

double a[NMAX][NMAX + 1];
double ans[NMAX];

int main() {
    FILE *fin;//, *fout;
    fin = fopen("gauss.in", "r");
//    fout = fopen("gauss.out", "w");
    ofstream fout( "gauss.out" );
    int n, m;
    fscanf(fin, "%d%d", &n, &m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m + 1; j++)
            fscanf(fin, "%lf", &a[i][j]);
    int lin, col;
    lin = col = 0;
    while(lin < n && col < m) {
        int lin2 = -1;
        for(int i = lin; i < n; i++) {
            if(lin2 == -1 && (a[i][col] > EPS || a[i][col] < -EPS))
                lin2 = i;
        }
        if(lin2 == -1)
            col++;
        else {
            if(lin2 != lin) {
                for(int j = 0; j < m + 1; j++)
                    swap(a[lin][j], a[lin2][j]);
            }
            for(int j = col + 1; j < m + 1; j++)
                a[lin][j] = a[lin][j] / a[lin][col];
            a[lin][col] = 1;
            for(int i = lin + 1; i < n; i++) {
                for(int j = col + 1; j < m + 1; j++)
                    a[i][j] -= a[i][col] * a[lin][j];
                a[i][col] = 0;
            }
            lin++;
            col++;
        }
    }
//    for ( int i = 0; i < n; i ++ ) {
//        for ( int j = 0; j <= m; j ++ ) {
//            cout << a[i][j] << ' ';
//        }
//        cout << endl;
//    }
    bool stg = true;
    for(int i = n - 1; i >= 0 && stg; i--) {
        int col2 = -1;
        for(int j = 0; j < m + 1 && stg; j++) {
            if(col2 == -1 && (a[i][j] > EPS || a[i][j] < -EPS)) {
                col2 = j;
            }
        }
        if(col2 == m)
            stg = false;
        else if ( col2 != -1 ) {
            ans[col2] = a[i][m];
            for(int col = col2 + 1; col < m; col++) {
                ans[col2] -= ans[col] * a[i][col];
            }
            ans[col2] /= a[i][col2];
//            cout << ans[col2] << endl;
//            cout << col2 << ' ' << ans[col2] << endl;
        }
    }
//    cout << ans[n - 1];
//    for ( int i = n - 1; i < n; i ++ ) {
//        for ( int j = 0; j <= m; j ++ ) {
//            cout << a[i][j] << ' ';
//        }
//        cout << endl;
//    }
    if(stg == false) {
//        fprintf(fout, "Imposibil");
        fout << "Imposibil";
    } else {
//        for ( int i = 0; i < n; i ++ ) {
//            double aux = 0;
//            for ( int j = 0; j < m; j ++ ) {
//                aux += a[i][j] * ans[j];
//            }
////            if ( aux != a[i][m] ) cout << i << endl;
//        }
        for(int i = 0; i < m; i++) {
//            if ( ans[i] != 0 ) cout << i << endl;
//            cout << ans[i] << ' ';
//            fprintf(fout, "%.5lf ", ans[i]);
            fout << fixed << setprecision( 10 ) << ans[i] << ' ';
        }
    }
    fclose(fin);
//    fclose(fout);
    return 0;
}
