#include <bits/stdc++.h>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

const long double limit = 1e-8;

int n,m;
int poz[100005];

long double a[1005][1005],rez[10005];

int main()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m+1;j++)
        {
            f>>a[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        poz[i] = 0;
        for(int j=1;j<=m+1;j++)
        {
            if(abs(a[i][j])>limit)
            {
                poz[i] = j;
                break;
            }
        }
        if(poz[i]==0)
        {
            continue;
        }
        if(poz[i]==m+1)
        {
            g<<"Imposibil"<<'\n';
            return 0;
        }
        for(int l=1;l<=n;l++)
        {
            if(l==i)
            {
                continue;
            }
            if(abs(a[l][poz[i]])>limit)
            {
                long double fact = 1.0*a[l][poz[i]]/a[i][poz[i]];
                for(int c=1;c<=m+1;c++)
                {
                    a[l][c] -= fact * a[i][c];
                }
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        rez[poz[i]] = 1.0*a[i][m+1]/a[i][poz[i]];
    }
    cout<<fixed<<setprecision(10);
    for(int i=1;i<=m;i++)
    {
        g<<rez[i]<<' ';
    }
    g<<'\n';
    return 0;
}
