#include <bits/stdc++.h>
#define pb push_back
#define NMAX 305

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const double EPS=1e-6;
double v[NMAX][NMAX],ans[NMAX];

int main() {
	int i,j,k,n,m,l,c;

	fin>>n>>m;

	for(i=1;i<=n;++i)
		for(j=1;j<=m+1;++j) fin>>v[i][j];

	i=j=1;
	while(i<=n && j<=m) {
		for(k=i;k<=n;++k)
			if(abs(v[k][j])>=EPS) break;

		if(k==n+1) {
			++j;
			continue;
		}

		if(k!=i)
			for(l=1;l<=m+1;++l)
				swap(v[i][l],v[k][l]);

		for(l=j;l<=m+1;++l)
			v[i][l]/=v[i][j];

		for(l=i+1;l<=n;++l) {
			for(c=j+1;c<=m+1;++c)
				v[l][c]-=v[l][j]*v[i][c];
			v[l][j]=0;
		}

		++i;
		++j;
	}

	for(i=n;i>0;--i) {
		for(j=1;j<=m+1;++j) {
			if(abs(v[i][j])>=EPS) {
				if(j==m+1) {
					fout<<"Imposibil";
					return 0;
				}

				ans[j]=v[i][m+1];
				for(k=j+1;k<=m;++k)
					ans[j]-=ans[k]*v[i][k];

				break;
			}
		}
	}

	for(i=1;i<=m;++i)
		fout<<fixed<<setprecision(8)<<ans[i]<<' ';

    return 0;
}
