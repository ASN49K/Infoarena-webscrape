#include <bits/stdc++.h>


using namespace std;
#define eps 0.0000001

double a[301][301];
double ans[301];
int main()
{
    ifstream cin("gauss.in");
    ofstream cout("gauss.out");

    int n, m;
    cin >> n >> m;


    /*if ( m > n )
    {
        cout << "Imposibil";
        return 0;
    }*/


    for ( int i = 1; i <= n; i++ )
    {
        for ( int j = 1; j <= m + 1; j++ )
        {
            cin >> a[i][j];
        }
    }
    int i = 1, j = 1, k;
    double aux;
    while (i <= n and j <= m)
    {
        for (k = i; k <= n; k++)
        {
            if (abs(a[k][j]) > eps)
                break;
        }
        if ( k == n + 1)
        {
            j ++;
            continue;
        }
        if ( k != i)
        {
            for(int l = 1; l <= m + 1; l++)
            {
                swap(a[i][l], a[k][l]);
            }
        }

        for (int l = j + 1; l <= m + 1; l++)
        {
             a[i][l] = a[i][l] / a[i][j];
        }
        a[i][j] = 1;

        for(int u = i + 1; u <= n; u ++)
        {
            for (int l = j + 1; l <= m + 1; l++)
            {
                a[u][l] -= a[u][j] * a[i][l];
            }
            a[u][j] = 0;
        }
        i ++;
        j ++;
    }

    for ( i = n; i >= 1; i-- )
    {
        bool flag = false;
        for(j = 1; j <= m + 1; j++ )
        {
            if(abs(a[i][j]) > eps and flag == false)
            {
                if (j == m + 1)
                {
                    cout << "Imposibil";
                    return 0;
                }
                ans[j] = a[i][m + 1];
                for(int k = j + 1; k <= m; k++)
                    ans[j] -= ans[k] * a[i][k];
                flag = true;
            }
        }
    }
    for ( int i = 1; i <= m ; i++)
    {
        cout << fixed << setprecision(10) << ans[i] << " ";
    }
    return 0;
}
