#include<fstream>
#include<iomanip>

using namespace std;

const int EPS=1e-9;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

int N,M,Rand[305];
double A[305][305];

void Read(){
    fin>>N>>M;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M+1;j++)
        fin>>A[i][j];
}

void Rez_Afisare(){
    int R=1,C=1;
    while(R<=N && C<=M){
        if(A[R][C]>-EPS && A[R][C]<EPS){
            int i=R+1;
            while(i<=N&& !(A[i][C]>-EPS && A[i][C]<EPS))
            i++;
            if(i>N){
              C++;
              continue;
            }
            swap(A[R],A[i]);
        }
        for(int i=1;i<=N;i++){
            if(i==R) continue;
            double K=A[i][C]/A[R][C];
            for(int j=1;j<=M+1;j++)
            A[i][j]-=K*A[R][j];
        }
        Rand[C]=R;
        C++;
        R++;
    }
    if(C>M)
        while(R<=N)
    if(!(A[R][M+1]>-EPS && A[R][M+1]<EPS)){
        fout<<"Imposibil"<<'\n';
        return;
    }
    fout<<setprecision(10)<<fixed;
    for(int i=1;i<=M;i++)
        if(Rand[i]!=0)
        fout<<A[Rand[i]][M+1]/A[Rand[i]][i]<<" ";
        else
            fout<<0.0000000000<<" ";
}

int main(){
    Read();
    Rez_Afisare();
    return 0;
}
