#include <cstdio>
#include <algorithm>
using namespace std;
const double eps = 1e-10;
double mat[305][305];
double sol[305];
int main()
{   freopen("gauss.in", "r", stdin);
    freopen("gauss.out","w", stdout);
    int n,m,i,j,k,l;
    scanf("%d%d", &n, &m);
    for(i=1; i<=n; i++)
        for(j=1; j<=m+1; j++)
            scanf("%lf", &mat[i][j]);
    for(i=1,j=1; i<=n && j<=m; i++,j++){
        for(k=i; k<=n; k++){
            if(mat[k][j]<=-eps || mat[k][j]>=eps){
                for(l=1; l<=m+1; l++)
                    swap(mat[k][l], mat[i][l]);
                break;
            }
        }
        if(mat[i][j]>=-eps && mat[i][j]<=eps){
            i--;
            continue;
        }
        for(k=j+1; k<=m+1; k++)
            mat[i][k]/=mat[i][j];
        mat[i][j]=1;
        for(k=i+1; k<=n; k++){
            for(l=j+1; l<=m+1; l++)
                mat[k][l]-=mat[k][j]*mat[i][l];
            mat[k][j]=0;
        }
    }
    for(i=n; i>=0; i--)
        for(j=1; j<=m+1; j++){
            if(mat[i][j]<=-eps || mat[i][j]>=eps){
                if(j==m+1){
                    printf("Imposibil");
                    return 0;
                }
                sol[j]=mat[i][m+1];
                for(l=j+1; l<=m; l++)
                    sol[j]-=mat[i][l]*sol[l];
                break;
            }
        }
    for(i=1; i<=m; i++)
        printf("%.10lf ", sol[i]);
    return 0;
}
