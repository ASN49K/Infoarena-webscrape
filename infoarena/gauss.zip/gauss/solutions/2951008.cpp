#include <fstream>
#include <iomanip>
#define ld long double

using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

ld v[305][305], x[305];

int main() {
    int n, m;
    in >> n >> m;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m + 1; j++)
            in >> v[i][j];
    }

    for(int j = 1; j <= m; j++) {
        int l = j;
        while(v[l][j] == 0 && l <= n)
            l++;
        for(int i = j + 1; i <= n; i++) {
            if(abs(v[i][j]) < 1e-9)
                continue;
            ld c = v[l][j] / v[i][j];
            for(int k = j; k <= m + 1; k++) {
                v[i][k] *= c;
                v[i][k] -= v[l][k];
            }
        }
    }

    for(int i = m; i >= 1; i--) {
        for(int j = 1; j <= n; j++) {
            if(abs(v[i][j - 1]) < 1e-9 && abs(v[i][j]) > 1e-9) {
                x[j] = v[i][m + 1] / v[i][j];
                for(int k = 1; k <= n; k++)
                    v[k][m + 1] -= v[k][j] * x[j];
                break;
            }
        }
    }

    bool ok = 1;
    for(int i = 1; i <= n; i++)
        ok &= (abs(v[i][m + 1]) < 1e-9);
    if(!ok) {
        out << "Imposibil\n";
        return 0;
    }

    for(int i = 1; i <= m; i++)
        out << fixed << setprecision(10) << x[i] << " ";
    out << "\n";
}
