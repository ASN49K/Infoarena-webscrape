#include <bits/stdc++.h>
#define MAXN 310
#define EPS 0.0000001
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n, m;
double a[MAXN + 1][MAXN + 1], X[MAXN + 1];
int main()
{
    fin >> n >> m;
    for(int i = 1; i <= n; ++ i)
        for(int j = 1; j <= m + 1; ++ j)
            fin >> a[i][j];
    int i = 1, j = 1, k;
    while(i <= n && j <= m)
    {
        for(k = i; k <= n; ++ k)
            if(a[k][j] < -EPS || a[k][j] > EPS)
                break;
        if(k == n + 1)
        {
            ++j;
            continue;
        }
        if(k != i)
        swap(a[i], a[k]);

        for(int z = j + 1; z <= m + 1; ++ z)
            a[i][z] = a[i][z] / a[i][j];
        a[i][j] = 1;
        for(int nexti = i + 1; nexti <= n; ++ nexti)
        {
            for(int nextj = j + 1; nextj <= m + 1; ++ nextj)
                a[nexti][nextj] -= a[nexti][j] * a[i][nextj];
            a[nexti][j] = 0;
        }
        ++i;
        ++j;
    }
    for(int i = n; i > 0; -- i)
    {
        for(int j = 1; j <= m + 1; ++ j)
        {
            if(a[i][j] < -EPS || a[i][j] > EPS)
            {
                if(j == m + 1)
                {
                    cout << "imposibil" << '\n';
                    return 0;
                }
                X[j] = a[i][m + 1];
                for(int nextj = j + 1; nextj <= m; ++ nextj)
                    X[j] -= X[nextj] * a[i][nextj];


                break;
            }
        }
    }
    for(int i = 1; i <= m; ++ i)
        fout << fixed << setprecision(8) << X[i] << ' ';
    fout << '\n';
    return 0;
}
