#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
const double eps = 1e-8;
int n, m;
double M[301][302], x[301];
void citire() {
    f >> n >> m;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m + 1; j++)
            f >> M[i][j];
}
void gauss() {
    int i = 1, j = 1;
    while(i <= n && j <= m) {
        bool ok;
        for(int k = i; k <= n; k++)
            if(abs(M[i][j]) > eps) {
                for(int l = j; l <= m + 1; l++)
                    swap(M[i][l], M[k][l]);
                ok = 1;
                break;
            }
        if(ok == 0) {
            j++;
            continue;
        }
        for(int k = j + 1; k <= m + 1; k++)
            M[i][k] /= M[i][j];
        M[i][j] = 1;
        for(int k = i + 1; k <= n; k++) {
            for(int l = j + 1; l <= m + 1; l++)
                M[k][l] -= M[i][l] * M[k][j];
            M[k][j] = 0;
        }
        i++;
        j++;
    }
}
bool solutie() {
    int i,j;
    for( i = n; i > 0; i--) {
        for( j = i; j <= m + 1; j++)
            if(abs(M[i][j]) > eps)break;
        if(j == m + 1)return 0;
        if(j <= m) {
            x[j] = M[j][m + 1];
            for(int k = j + 1; k <= m; k++)
                x[j] -= M[i][k] * x[k];
        }
    }
    return 1;
}
void afisare() {
    g << fixed << setprecision(8);
    for(int i = 1; i <= m; i++)
        g << x[i] << ' ';
}
int main() {
    citire();
    gauss();
    if(solutie())
        afisare();
    else g << "Imposibil";
}
