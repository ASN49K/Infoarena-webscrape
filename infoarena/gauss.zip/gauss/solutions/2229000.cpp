#include <cstdio>
#include <algorithm>
#include <cmath>

#define MAX_N 300
#define MAX_M 300
#define eps 1e-10

using namespace std;

bool check(long double x)
{
    return abs(x)<eps;
}
int main()
{
    freopen("gauss.in","rt",stdin);
    freopen("gauss.out","wt",stdout);

    long double a[MAX_N+1][MAX_M+1],x[MAX_M+1],b[MAX_N+1];
    int n,m,i,j,k,p;

    scanf("%d %d",&n,&m);

    for(i=1;i<=n;i++) {
        for(j=1;j<=m;j++) scanf("%Lf",&a[i][j]);
        scanf("%Lf",&b[i]);
    }

    for(i=1,j=1;i<=n && j<=m;i++,j++) {
        if(a[i][j]==0) {
            for(k=i+1;k<=n;k++) {
                if(a[k][j]!=0)
                    break;
            }
            if(k>n) {
                i--;
                continue;
            }
            for(p=j;p<=m;p++) swap(a[k][p],a[i][p]);
            swap(b[i],b[k]);
        }
        for(k=i+1;k<=n;k++) {
            long double r=a[k][j]/a[i][j];
            for(p=j;p<=m;p++) a[k][p]-=r*a[i][p];
            b[k]-=r*b[i];
        }
    }
    for(i=n;i>=1;i--) {
        for(j=1;j<=m;j++) {
            if(!check(a[i][j]))
                break;
        }
        if(j>m && !check(b[i])) {
            printf("Imposibil\n");
            return 0;
        }
        long double s=0;
        for(k=j+1;k<=m;k++) s+=a[i][k]*x[k];
        x[j]=(b[i]-s)/a[i][j];
    }
    for(j=1;j<=m;j++) printf("%.12Lf",x[j]);
    printf("\n");

    return 0;
}
