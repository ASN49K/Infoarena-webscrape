#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define all(a) (a).begin(), (a).end()
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define sz() size()
#define fr first
#define sc second
#define int long long
#define mp make_pair
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
using namespace std;

const int nmax = 305;
const long double eps = 1e-18;


int n,m;
long double ans[nmax];
vector<vector<long double>>matrix;

int32_t main(){
    ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
    srand(chrono::steady_clock::now().time_since_epoch().count());
    ifstream cin("gauss.in");
    ofstream cout("gauss.out");
    cout << fixed << setprecision(10);
    cin >> n >> m;
    matrix.emplace_back();
    matrix.back().push_back((ld)0.0);
    for(int i=1;i<=n;i++){
        matrix.emplace_back();
        matrix.back().push_back(0.0);
        int x;
        for(int j=1;j<=m+1;j++){
            cin >> x;
            matrix.back().push_back(x);
        }
    }
    vector<int>where(m + 1,-1);
    for(int row=1,col=1; row<=n && col<=m; col++){
        int set_row = row;
        for(int j=row+1;j<=n;j++){
            if(abs(matrix[j][col]) > abs(matrix[set_row][col])){
                set_row = j;
            }
        }
        swap(matrix[row],matrix[set_row]);
        if(abs(matrix[set_row][col]) < eps){
            continue;
        }
        else{
            long double c = matrix[row][col];
            for(int i=1;i<=m+1;i++){
                matrix[row][i] /= c;
            }
            for(int i=1;i<=n;i++){
                if(i != row){
                    long double tz = - matrix[i][col];
                    for(int j=1;j<=m+1;j++){
                        matrix[i][j] += (tz*matrix[row][j]);
                    }
                }
            }
            where[col] = row;
            ++row;
        }
    }
    for(int i=1;i<=m;i++){
        if(where[i] != -1){
            ans[i] = matrix[where[i]][m+1] / matrix[where[i]][i];
        }
    }
    for(int i=1;i<=n;i++){
        long double curr = 0;
        for(int j=1;j<=m;j++){
            curr += matrix[i][j]*ans[j];
        }
        curr = (curr - matrix[i][m+1]);
        if(abs(curr) > eps) rc("Imposibil");
    }
    for(int i=1;i<=m;i++) cout << ans[i] << ' ';
    cout << '\n';
}


