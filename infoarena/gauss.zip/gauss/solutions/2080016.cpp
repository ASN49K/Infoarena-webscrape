#include<cstdio>
double A[302][302],*a[302],*aux,x[302],y,eps=0.00000001;
int n,m,i,j,k,p,next[302],prev[302],solve(),X[302];
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(i=1;i<=n;i++)
    {
        a[i]=A[i];
        for(j=1;j<=m+1;j++)
            scanf("%lf",&a[i][j]);
    }
    for(i=1;i<=m+1;i++)
    {
        next[i]=i+1;
        prev[i]=i-1;
    }
    next[0]=1;prev[m+2]=m+1;
    for(k=1;k<=n;k++)
    {
        if(solve())continue;
        printf("Imposibil\n");
        return 0;
    }
    for(j=1;j<m;j++)
        X[j]?printf("%.8lf ",a[X[j]][m+1]):printf("0.00000000 ");
    X[j]?printf("%.8lf\n",a[X[j]][m+1]):printf("0.00000000\n");
    return 0;
}
int solve()
{
    for(p=next[0];p<=m+1;p=next[p])if(a[k][p]<=-eps||a[k][p]>=eps)break;
    if(p==m+1)return 0;
    if(p==m+2){aux=a[k];a[k]=a[n];a[n]=aux;n--;k--;return 1;}
    y=a[k][p];for(j=p;j<=m+1;j=next[j])a[k][j]/=y;
    for(i=1;i<=n;i++)
    {
        if(i==k)continue;
        y=a[i][p];
        if(y>=-eps&&y<=eps)continue;
        for(j=p;j<=m+1;j=next[j])a[i][j]=a[i][j]-y*a[k][j];}
    X[p]=k;next[prev[p]]=next[p];prev[next[p]]=prev[p];return 1;
}
