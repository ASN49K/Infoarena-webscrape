#include <iostream>
#include <cstdio>
using namespace std;

int a[140000], n, m, x, pb, y;

void upd(int poz, int nr)
{
    for(int i = poz; i<=n; i+=(i&(-i)))
        a[i] += nr;
}

int cauta(int poz)
{
    int suma = 0;
    for(int i = poz; i>0; i-=(i&(-i)))
        suma += a[i];
    return suma;
}

int minim(int nr)
{
    int j;
    int log = 1;
    while(log<n)
        log<<=1;

    for(j = 1; log; log>>=1)
        if(j+log<=n && cauta(j+log) <= nr)
            j+=log;
    if(cauta(j) == nr)
        return j;
    return -1;
}

void rez()
{
    scanf("%d %d", &n, &m);
    for(int i = 1; i<=n; i++)
    {
        scanf("%d", &x);
        upd(i, x);
    }
    for(int i = 1; i<=m; i++)
    {
        scanf("%d", &pb);
        if(pb == 0)
        {
            scanf("%d %d", &x, &y);
            upd(x, y);
        }
        else if(pb == 1)
        {
            scanf("%d %d", &x, &y);
            printf("%d\n", cauta(y) - cauta(x-1));
        }
        else if(pb == 2)
        {
            scanf("%d\n", &x);
            printf("%d\n", minim(x));
        }
    }
    /*printf("\n");
    for(int i = 1; i<=16; i++)
    {
        printf("%d ", a[i]);
    }*/
}

int main()
{
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    rez();
    return 0;
}
