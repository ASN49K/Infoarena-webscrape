#include <fstream>
#include <iomanip>
using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");
int n,m,i,j,k,t;
long double ep,a[305][305],sol[305];
int main()
{
    in>>n>>m;
    ep=0.00000001;
    for (i=1;i<=n;++i)
        for (j=1;j<=m+1;++j)
    {
        in>>a[i][j];
    }
    i=j=1;
    while (i<=n&&j<=m)
    {
        for (k=i;k<=n;++k)
        {
            if (a[k][j]<-ep||a[k][j]>ep) break;
        }
        if (k==n+1) {j++; continue;}
        for (t=1;t<=m+1;++t)
            swap(a[i][t],a[k][t]);
        for (t=j+1;t<=m+1;++t)
            a[i][t]=a[i][t]/a[i][j];
        a[i][j]=1;
        for (k=1;k<=n;++k)
            if (k!=j)
            {for (t=j+1;t<=m+1;++t)
            {a[k][t]-=a[k][j]*a[i][t]; if (a[k][t]>-ep&&a[k][t]<ep) a[k][t]=0;} a[k][j]=0;}
        i++;
        j++;
    }
    for (i=1;i<=n;++i)
    {for (j=1;j<=m+1;++j) if (a[i][j]<-ep||a[i][j]>ep) break; if ((a[i][m+1]>ep||a[i][m+1]<-ep)&&j>m) {out<<"Imposibil"; return 0;}}
    for (i=1;i<=n;++i)
        for (j=1;j<=m;++j)
    {
        if (a[i][j]<-ep||a[i][j]>ep) {sol[j]=a[i][m+1];}
    }
    for (j=1;j<=m;++j)
    {
        if (sol[j]<-ep||sol[j]>ep) {out<<fixed<<setprecision(8)<<sol[j]<<" ";}
        else out<<0<<" ";
    }
    return 0;
}
