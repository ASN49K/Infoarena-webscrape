#include<bits/stdc++.h>
using namespace std;
#define MAXN 300
#define EPS 0.000000001
ifstream fin("gauss.in");
ofstream fout("gauss.out");
double a[MAXN+1][MAXN+2],ans[MAXN+2];
int main() {
    int n,m,i,j,l,c,sl;
    double v;
    fin>>n>>m;
    for(i=1; i<=n; i++) {
        for(j=1; j<=m+1; j++) {
            fin>>a[i][j];
        }
    }
    i=j=1;
    while(i<=n&&j<=m) {
        l=i;
        while(l<=n) {
            if(abs(a[l][j])>EPS) {
                sl=l;
                l=n;
            }
            l++;
        }
        if(sl==n+1) {
            j++;
        } else {
            if(sl!=i) {
                swap(a[sl],a[i]);
            }
            v=a[i][j];
            for(int c=j; c<=m+1; c++) {
                a[i][c]/=v;
            }
            for(l=i+1; l<=n; l++) {
                for(int c=j+1; c<=m+1; c++) {
                    a[l][c]-=a[i][c]*a[l][j];
                }
                a[l][j]=0;
            }
            i++;
            j++;
        }
    }
    for(i=n; i; i--) {
        j=1;
        while(j<=m+1&&abs(a[i][j])<EPS) {
            j++;
        }
        if(j<m+2) {
            ans[j]=a[i][m+1];
            for(c=j+1; c<=m; c++) {
                ans[i]-=ans[c]*a[i][c];
            }
        }
    }
    for(i=1; i<=m; i++) {
        fout<<fixed<<setprecision(11)<<ans[i]<<' ';
    }
    return 0;
}
