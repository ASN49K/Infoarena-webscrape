#include <bits/stdc++.h>
#define EPSILON 1e-12

using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");

int n, m;///n=number of equations, m=number of unknown values
double nums[305][305], sol[305];

void solve(int pos);

int main()
{

    fin >> n >> m;

    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m + 1; ++j) fin >> nums[i][j];
    }

    if(m > n){
        fout << "Imposibil";
        return 0;
    }

    solve(1);

    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            nums[i][m + 1] -= (sol[j] * nums[i][j]);
        }

        if(fabs(nums[i][m + 1]) > EPSILON){
            fout << "Imposibil";
            return 0;
        }
    }

    fout << fixed << setprecision(10);
    for(int i = 1; i <= m; ++i) fout << sol[i] << " ";

    return 0;
}

void solve(int pos){
    if(pos > m) return;

    for(int i = pos; i <= m; ++i){
        if(fabs(nums[i][pos]) < EPSILON) continue;

        for(int j = pos; j <= m + 1; ++j){
            swap(nums[pos][j], nums[i][j]);
        }

        break;
    }

    if(fabs(nums[pos][pos]) > EPSILON){
        for(int i = pos; i <= m; ++i){
            double dv = nums[i][pos];

            for(int j = pos; j <= m + 1; ++j) nums[i][j] /= dv;
        }

        for(int i = pos + 1; i <= m; ++i){
            for(int j = pos; j <= m + 1; ++j){
                nums[i][j] -= nums[pos][j];
            }
        }

    }

    solve(pos + 1);

    if(fabs(nums[pos][pos]) < EPSILON){
        sol[pos] = 0.0;
    }
    else{
        double sum = 0.0;

        for(int j = pos + 1; j <= m; ++j) sum += sol[j] * nums[pos][j];
        sol[pos] = (nums[pos][m + 1] - sum) / nums[pos][pos];
    }
}
