#include <cstdio>

#include <algorithm>

#define eps 1e-10

using namespace std;

int n,m,i,j,k,h;

double x,a[305][305],b[305];

bool ok;

int main()

{

    freopen ("gauss.in","r",stdin);

    freopen ("gauss.out","w",stdout);

    scanf ("%d %d", &n, &m);

    for (i=1; i<=n; i++)

        for (j=1; j<=(m+1); j++)

            scanf ("%lf", &a[i][j]);

    i=1;

    j=1;

    while ((i<=n) && (j<=m))

    {

        ok=false;

        for (k=i; k<=n; k++)

        {

            if ((a[k][j]<-eps) || (a[k][j]>eps))

            {

                ok=true;

                break;

            }

        }

        if (ok==true)

        {

            if (k!=i)

            {

                for (h=j; h<=(m+1); h++)

                    swap (a[i][h],a[k][h]);

            }

            for (k=(j+1); k<=(m+1); k++)

                a[i][k]=(1.0)*a[i][k]/a[i][j];

            a[i][j]=1.0;

            for (k=(i+1); k<=n; k++)

            {

                x=(0.0)+a[k][j];

                if ((x<-eps) || (x>eps))

                {

                    a[k][j]=0.0;

                    for (h=(j+1); h<=(m+1); h++)

                        a[k][h]=(0.0)+a[k][h]-(1.0)*a[i][h]*x;

                }

            }

            i++;

        }

        j++;

    }

    ok=true;
    for( i = 1; i <= m; i++)
        b[i]=0.0;
    for( i = n; i>0; i--)

        for( j = 1; j <= m+1; j++)

            if(a[i][j]>eps || a[i][j]<-eps)

            {

                if(j == m+1)

                {

                    printf ("Imposibil\n");

                    return 0;

                }

                b[j] = a[i][m+1];

                for(int k = j+1; k <= m; k++)

                    b[j] -=b[k] * a[i][k];

                break;

            }
    for (i=1; i<=m; i++)

        printf ("%.10f ", b[i]);

    printf ("\n");
    return 0;
}
