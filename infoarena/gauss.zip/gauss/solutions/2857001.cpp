#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;
ifstream fin ("gauss.in");
ofstream fout ("gauss.out");

#define epsilon 0.00000001

int n, m;
double mat[305][305], sol[305];
bool imposibil;

void interschimba_linii (int i1, int i2)
{
    for(int j=1; j<=m+1; j++)
        swap(mat[i1][j], mat[i2][j]);
}
void imparte_linia (int lin, double x)
{
    for(int j=1; j<=m+1; j++)
        mat[lin][j]/=x;
}
void scade_linii (int i1, int i2, double coef)
{
    for(int j=1; j<=m+1; j++)
        mat[i2][j]-=(coef*mat[i1][j]);
}

bool is_zero (double x)
{
    if(x<0)
        x=-x;
    if(x<epsilon)
        return 1;
    return 0;
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m+1; j++)
            fin>>mat[i][j];
    int lin=1, col=1;
    while(col<=m)
    {
        int lin_nenul=0;
        for(int i=lin; i<=n; i++)
            if(!is_zero(mat[i][col]))
            {
                lin_nenul=i;
                break;
            }
        if(lin_nenul==0)
            col++;
        else
        {
            interschimba_linii(lin, lin_nenul);
            imparte_linia(lin, mat[lin][col]);
            for(int i=lin+1; i<=n; i++)
                scade_linii(lin, i, mat[i][col]);
            col++;
            lin++;
        }
        /*for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m+1; j++)
                cout<<mat[i][j]<<" ";
            cout<<"\n";
        }
        cout<<"\n";*/
    }
    while(lin<=n){
        if(!is_zero(mat[lin][m+1]))
            imposibil=1;
        lin++;
    }
    lin=m+1;
    for(int j=m; j>=1 && lin>=1 && !imposibil; j--)
    {
        lin--;
        for(int col=j+1; col<=m; col++)
            mat[lin][m+1]-=sol[col]*mat[lin][col];
        if(is_zero(mat[lin][j]))
        {
            if(!is_zero(mat[lin][m+1]))
                imposibil=1;
        }
        else
        {
            if(!is_zero(mat[lin][m+1]))
                sol[j]=mat[lin][m+1]/mat[lin][j];
        }
    }
    if(imposibil)
        fout<<"Imposibil";
    else
        for(int i=1; i<=m; i++)
            fout<<fixed<<setprecision(10)<<sol[i]<<" ";
    return 0;
}
