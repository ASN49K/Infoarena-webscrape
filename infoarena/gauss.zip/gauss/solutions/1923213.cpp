#include <cstdio>
#include <algorithm>

using namespace std;

const double eps=0.0000000001;
double v[310][310],sol[310];
int n,m;

int gauss()
{
    int i=1,j=1;
    while(i<=n && j<=m)
    {
        int k;
        for(k=i;k<=n && abs(v[k][j])<eps;k++);
        if(k==n+1) j++;
        else
        {
            swap(v[i],v[k]);
            for(int k=i+1;k<=n;k++)
            {
                double p=v[k][j]/v[i][j];
                for(int q=j;q<=m+1;q++) v[k][q]-=v[i][q]*p;
            }
            i++;j++;
        }
    }
    for(int i=n;i;i--)
        for(int j=1;j<=m+1;j++)
            if(abs(v[i][j])>eps)
            {
                if(j==m+1) return 0;
                sol[j]=v[i][m+1];
                for(int k=j+1;k<=m;k++) sol[j]-=sol[k]*v[i][k];
                sol[j]/=v[i][j];
                break;
            }
    return 1;
}

int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++) scanf("%lf",&v[i][j]);
    if(gauss())
    {
        for(int i=1;i<=m;i++) printf("%.8f ",sol[i]);
    }
    else printf("Imposibil");
    return 0;
}
