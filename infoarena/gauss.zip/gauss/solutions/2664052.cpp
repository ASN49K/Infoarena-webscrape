#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;
double matrix[305][305];
double ans[305];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");

    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m + 1; ++j) {
            fin >> matrix[i][j];
        }
    }

    int j = 1, i = 1, pos;

    while (j <= m && i <= n) {
        double maxim = 0;
        for (int a = i; a <= n; ++a) {
            if (maxim <= abs(matrix[a][j])){
                maxim = abs(matrix[a][j]);
                pos = a;
            }
        }
        if (maxim == 0) {
            j += 1;
        } else {
            double beta = matrix[pos][j];
            for (int e = 1; e <= m+1; ++e) {
                matrix[pos][e] /= beta;
                swap(matrix[i][e], matrix[pos][e]);
            }
            int c = i;
            i += 1;
            for (int a = i; a <= n; ++a) {
                double z = matrix[a][j] / matrix[c][j];
                for (int d = j; d <= m+1; ++d) {
                    matrix[a][d] -= z * matrix[c][d];
                }
            }
            j += 1;
        }
    }

    double eps = 1e-8;
    int cnt = 0;
    for (int i = n; i >= 1; --i) {
        cnt = 0;
        for (int j = m; j >= 1; --j) {
            if (abs(matrix[i][j]) < eps && abs(matrix[i][m + 1]) > eps) {
                cnt += 1;
            }
        }
        if (cnt == m) {
            fout << "IMPOSIBIL";
            return 0;
        }
    }

    for (int i = n; i >= 1; --i) {
        int column = -1;
        for (int j = m; j >= 1; --j) {
            if (abs(matrix[i][j]) > eps) {
                column = j;
            }
        }
        if (column == -1) continue;
        ans[column] = matrix[i][m + 1];
        for (int j = m; j > column; --j) {
            ans[column] -= matrix[i][j] * ans[j];
        }
    }
    for (int i = 1; i <= m; ++i) {
        fout << setprecision(8) << fixed << ans[i] << " ";
    }

    return 0;
}