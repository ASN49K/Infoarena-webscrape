#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream in ( "gauss.in"  );
ofstream out( "gauss.out" );

const int DIM = 3e2 + 5;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-5;

double sys[DIM][DIM], sol[DIM];

int main( int argc, const char *argv[] ) {
    ios::sync_with_stdio( false );

    int n, m; in >> n >> m;
    for( int i = 1; i <= n; i ++ ) {
        for( int j = 1; j <= m + 1; j ++ ) {
            in >> sys[i][j]; } }

    for( int i = 1, j = 1, ok = 0; i <= n && j <= m; ok = 0 ) {
        for( int k = i; k <= n; k ++ ) {
            if( fabs( sys[k][j] ) > EPS ) {
                swap_ranges( sys[i], sys[i] + m + 2, sys[k] ); ok = 1; break; } }
        if( ok == 0 ) {
            j ++; }
        else {
            for( int k = m + 1; k >= j; k -- ) {
                sys[i][k] /= sys[i][j]; }
            for( int k = i + 1; k <= n; k ++ ) {
                for( int p = m + 1; p >= j; p -- ) {
                    sys[k][p] -= sys[k][j] * sys[i][p]; } }
            i ++, j ++; } }

    for( int i = n, j = 1; i >= 1; i --, j = 1 ) {
        while( fabs( sys[i][j] ) < EPS ) {
            j ++; }
        if( j == m + 1 ) {
            out << "Imposibil" << endl;
            return 0; }
        sol[j] = sys[i][m + 1];
        for( int k = j + 1; k <= m; k ++ ) {
            sol[j] -= sol[k] * sys[i][k]; } }

    for( int i = 1; i <= m; i ++ ) {
        out << setprecision( 10 ) << fixed << sol[i] << " "; }
    out << endl;

    return 0;
}