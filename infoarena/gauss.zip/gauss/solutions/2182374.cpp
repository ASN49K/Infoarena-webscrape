#include <bits/stdc++.h>

using namespace std;

#define precizie 0.0000000001

double a[305][305],d=1,r[305];
int n,m;

int zero(double x){
    if (x>-precizie&&x<precizie) return 1;
    return 0;
}

void swapl(int x, int y){
    int i;
    if (x==y) return;
    for (i=1;i<=m+1;i++) swap(a[x][i],a[y][i]);
}

void xl(int x){
    double d=a[x][x];
    d=1/d;
    for (int i=x;i<=m+1;i++) a[x][i]*=d;

}

void add(int x){
    int i,j;
    double d;
    for (i=x+1;i<=n;i++){
        d=-a[i][x];
        for (j=x;j<=m+1;j++)
            a[i][j]+=d*a[x][j];
    }
}

void afis(){
    int i,j;
    for (i=m;i>=1;i--){
        for (j=m;j>i;j--)
            a[i][m+1]-=a[i][j]*r[j];
        r[i]=a[i][m+1]/a[i][i];
    }
    for (i=1;i<=m;i++) printf("%.8lf ",r[i]);
}

int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    int i,j,p,ok=1;
    scanf("%d%d",&n,&m);
    for (i=1;i<=n;i++)
        for (j=1;j<=m+1;j++)
            scanf("%lf",&a[i][j]);
    for (i=1;i<=m;i++){
        p=0;
        if (zero(a[i][i])){
            for (j=1;j<=n;j++)
            if (a[i][j]>0) {p=j;break;}
        }
        else p=i;
        if (p==0) {ok=0;break;}
        swapl(p,i);
        xl(i);
        add(i);
    }
    if (ok){
        afis();
    }
    else printf("Imposibil");
    return 0;
}
