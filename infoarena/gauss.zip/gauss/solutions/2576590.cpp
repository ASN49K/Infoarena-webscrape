#include <bits/stdc++.h>

using namespace std;

const int eps = 1e-10;

vector<vector<double> >a;

int main() {
  freopen("gauss.in", "r", stdin);
  freopen("gauss.out", "w", stdout);

  int n, m;
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i) {
    vector<double>v(m + 1, 0);
    for (int j = 0; j <= m; ++j)
      cin >> v[j];
    a.push_back(v);
  }

  vector<int>p(m, -1);
  int k = 0;
  for (int i = 0; i < m && k < n; ++i) {
    int pos = k;
    for (int j = k + 1; j < n; ++j)
      if (fabs(a[j][i]) > fabs(a[pos][i]))
        pos = j;
    if (fabs(a[pos][i]) <= eps)
      continue;
    swap(a[k], a[pos]);
    double coef = 1.0 / a[k][i];
    for (int j = i; j <= m; ++j)
      a[k][j] *= coef;
    for (int t = 0; t < n; ++t) {
      if (k != t) {
        coef = a[t][i];
        for (int j = i; j <= m; ++j)
          a[t][j] -= a[k][j] * coef;
      }
    }
    p[i] = k;
    k++;
  }

  for (int i = k; i < n; ++i)
    if (fabs(a[i][m]) > eps) {
      cout << "Imposibil!";
      return 0;
    }

  vector<double>ans(m, 0);
  for (int i = 0; i < m; ++i)
    if (p[i] != -1)
      ans[i] = a[p[i]][m];

  cout << fixed << setprecision(8);

  for (auto it:ans)
    cout << it << ' ';

  return 0;
}
