#include <bits/stdc++.h>
#define double long double

using namespace std;

int n, m;
double v[305][305];
int which[305];
int need = 1;
double ans[305];

void divideLine(int l, double by)
{
    for(int i=1; i<=m+1; ++i)
        v[l][i] /= by;
}

void substractLine(int l1, int l2)
{
    for(int i=1; i<=m+1; ++i)
        v[l1][i] -= v[l2][i];
}

void swapLine(int l1, int l2)
{
    for(int i=1; i<=m+1; ++i)
        swap(v[l1][i], v[l2][i]);
}

void diag()
{
    for(int i=1; i<=m; ++i)
    {
        for(int j=need; j<=n; ++j)
            if(v[j][i] != 0)
            {
                swapLine(need, j);
                break;
            }
        if(v[need][i] == 0) continue;
        divideLine(need, v[need][i]);
        for(int j=need+1; j<=n; ++j)
            if(v[j][i] != 0)
            {
                divideLine(j, v[j][i]);
                substractLine(j, need);
            }
        which[need] = i;
        ++need;
    }
}

void solve()
{
    for(--need; need > 0; --need)
    {
        int res = ans[which[need]] = v[need][m+1];
        for(int i=1; i<=n; ++i)
        {
            v[i][m+1] -= res * v[i][which[need]];
            v[i][which[need]] = 0;
        }
    }
}

signed main()
{
    ifstream fin ("gauss.in");
    ofstream fout ("gauss.out");
    ios::sync_with_stdio(false); fin.tie(0); fout.tie(0);
    fin>>n>>m;
    for(int i=1; i<=n; ++i)
        for(int j=1; j<=m+1; ++j)
            fin>>v[i][j];
    diag();
    solve();
    for(int i=1; i<=n; ++i)
        if(abs(v[i][m+1]) > 1e-5)
        {
            fout<<"Imposibil";
            return 0;
        }
    for(int i=1; i<=m; ++i)
        fout<<fixed<<setprecision(8)<<ans[i]<<' ';
    return 0;
}
