#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

const int EPS = 1e-8;
const int MAXN = 301;

int N, M;
double A[MAXN][MAXN + 1], ///Matrice extinsa
       X[MAXN];           ///Vectorul solutie

void gauss()
{
    int i = 1, j = 1, k, p;
    while(i <= N && j <= M)
    {
        bool ok = 0;

        for(k = i; k <= N; ++k)
            if(abs(A[k][j]) > EPS)
            {
                ok = 1;

                for(p = j; p <= M + 1; p++)
                    swap(A[i][p], A[k][p]);

                break;
            }

        if(ok == 0)
        {
            j++;
            continue;
        }
        for(p = j + 1; p <= M + 1; p++)
            A[i][p] = A[i][p] / A[i][j];
        A[i][j] = 1;
        for(int u = i + 1; u <= N; u++)
        {
            for(p = j + 1; p <= M + 1; p++)
                A[u][p] -= A[u][j] * A[i][p];
            A[u][j] = 0;
        }

        ++i;
        ++j;
    }
}

bool solutie()
{
    for(int i = N; i >= 1; --i)
        for(int j = i; j <= M + 1; ++j)
            if(abs(A[i][j]) > EPS)
            {
                if(j == M + 1)
                    return 0;
                X[j] = A[i][M + 1];
                for(int k = j + 1; k <= M; ++k)
                    X[j] -= X[k] * A[i][k];
                break;
            }
    return 1;
}

void afisare()
{
    g.setf(ios::fixed, ios::floatfield);
    g.precision(10);
    for(int i = 1; i <= M; ++i)
        g << X[i] << ' ';
}

int main()
{
    f >> N >> M;
    for(int i = 1; i <= N; ++i)
        for(int j = 1; j <= M + 1; ++j)
            f >> A[i][j];
    gauss();

    if(solutie())
        afisare();
    else g << "Imposibil";
    return 0;
}
