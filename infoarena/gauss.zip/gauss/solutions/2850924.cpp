#include <bits/stdc++.h>

using namespace std;
#ifdef INFOARENA
ifstream fin("gauss.in");
ofstream fout("gauss.out");
#else
ifstream fin("ciorna.in");
ofstream fout("ciorna.out");
#endif
using ld = long double;
const ld eps = 1e-10;
vector <ld> solve(vector <vector <ld>>& a, int n, int m) {
    vector <int> found(m, -1);
    for(int r = 0, c = 0; r < n && c < m; c++) {
        int x = r;
        for(int i = r + 1; i < n; i++)
            if(abs(a[i][c]) > abs(a[x][c]))
                x = i;
        swap(a[r], a[x]);
        if(abs(a[r][c]) < eps) continue;
        found[c] = r;
        for(int i = 0; i < n; i++) if(i != r) {
            ld sub = a[i][c] / a[r][c];
            for(int j = c; j <= m; j++)
                a[i][j] -= sub * a[r][j];
        }
        r++;
    }
    vector <ld> sol(m, 0);
    for(int i = 0; i < m; i++) if(found[i] > -1)
        sol[i] = a[found[i]][m] / a[found[i]][i];
    for(int i = 0; i < n; i++) {
        ld sum = 0;
        for(int j = 0; j < m; j++)
            sum += a[i][j] * sol[j];
        if(abs(sum - a[i][m]) >= eps)
            return {};
    }
    return sol;
}

int main()
{
    int n, m;
    fin >> n >> m;
    vector <vector <ld>> a(n, vector <ld>(m + 1, 0));
    for(int i = 0; i < n; i++)
        for(int j = 0; j <= m; j++)
            fin >> a[i][j];
    vector <ld> sol;
    if((sol = solve(a, n, m)).empty()) fout << "Imposibil";
    else for(ld x : sol) fout << fixed << setprecision(10) << x << " ";
    return 0;
}
