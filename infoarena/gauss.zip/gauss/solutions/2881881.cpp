#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMAX = 300;
const double EPS = 1e-10;

double *mat[NMAX];
double sol[NMAX];

bool eq(double a, double b);
void buildSys(int n, int m);
void readSys(int n, int m);
int findLin(int pos, int n);
bool solveSys(int n, int m, double sol[]);

int main()
{
    int n, m;

    fin >> n >> m;

    buildSys(n, m);
    readSys(n, m);

    if (solveSys(n, m, sol)) {
        for (int i = 0; i < m; i++)
            fout << setprecision(10) << sol[i] << " ";
    }
    else
        fout << "Imposibil";

    return 0;
}

bool eq(double a, double b) {
    double diff = a - b;
    if (diff < 0)
        diff = -diff;
    return diff < EPS;
}

void buildSys(int n, int m) {
    for (int i = 0; i < n; i++)
        mat[i] = new double[m + 1];
}

void readSys(int n, int m) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j <= m; j++)
            fin >> mat[i][j];
}
int findLin(int pos, int n) {
    for (int i = pos; i < n; i++)
        if (mat[i][pos] != 0)
            return i;
    return -1;
}
bool solveSys(int n, int m, double sol[]) {
    for (int i = 0; i < m; i++) {
        int lin = findLin(i, n);
        if (lin == -1)
            continue;

        swap(mat[lin], mat[i]);

        for (int j = i + 1; j < n; j++) {
            for (int k = i + 1; k <= m; k++)
                mat[j][k] -= mat[j][i] * mat[i][k] / mat[i][i];
            mat[j][i] = 0;
        }

    }

    for (int i = n - 1; i >= 0; i--) {
        int j = 0;
        double zero = 0;
        while (eq(mat[i][j], zero) && j <= m)
            j++;
        if (j == m)
            return 0;

            int k;
            for (k = j + 1; k < m; k++)
                mat[i][m] -= mat[i][k] * sol[k];
            sol[j] = mat[i][k] / mat[i][j];
    }
    return 1;
}
