#include<fstream>
#include<iostream>
#include<iomanip>
#define DN 305
using namespace std;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n,m,l,c,k;
double a[DN][DN],aux,r[DN];
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m+1;j++)
            fin>>a[i][j];
    l=c=1;
    while(l<=n&&c<=m)
    {
        for(k=l;k<=n&&a[k][c]==0;k++);
        if(k==n+1)
        {
            c++;
            continue;
        }
        if(k!=l)
            for(int j=c;j<=m+1;j++)
            {
                aux=a[l][j];
                a[l][j]=a[k][j];
                a[k][j]=aux;
            }
        for(int j=c+1;j<=m+1;j++)
            a[l][j]/=a[l][c];
        a[l][c]=1;
        for(int i=l+1;i<=n;i++)
        {
            for(int j=c+1;j<=m+1;j++)
                a[i][j]-=a[l][j]*a[i][c];
            a[i][c]=0;
        }
        l++;
        c++;
    }
    for(int i=n;i>=1;i--)
        for(int j=1;j<=m+1;j++)
            if(a[i][j]!=0)
            {
                if(j==m+1)
                {
                    fout<<"Imposibil";
                    return 0;
                }
                r[j]=a[i][m+1];
                for(int h=j+1;h<=m;h++)
                    r[j]-=r[h]*a[i][h];
                break;
            }
    for(int i=1;i<=m;i++)
        fout<<fixed<<setprecision(15)<<r[i]<<' ';
}
