#include<fstream>
#include<iomanip>
using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");
int n, i, j, m, k;
double a[305][305], sol[305];
int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m+1;j++)
            f>>a[i][j];
    i=j=1;
    while(i<=n && j<=m)
    {
        for(k=i;k<=n;k++)
            if(a[k][j]!=0)
                break;
        if(k!=n+1)
        {
            for(int jj=1;jj<=m+1;jj++)
                swap(a[i][jj], a[k][jj]);
            for(int jj=j+1;jj<=m+1;jj++)
                a[i][jj]/=a[i][j];
            a[i][j]=1;
            for(int ii=i+1;ii<=n;ii++)
            {
                for(int jj=j+1;jj<=m+1;jj++)
                    a[ii][jj]-=a[i][jj]*a[ii][j];
                a[ii][j]=0;
            }
            i++;
            j++;
        }
        else j++;
    }
    for(i=n;i>=1;i--)
    {
        for(j=1;j<=m+1;j++)
            if(a[i][j]!=0)
                break;
        if(j==m+1)
        {
            g<<"Imposibil";
            return 0;
        }
        if(j!=m+2)
        {
            sol[j]=a[i][m+1];
            for(k=j+1;k<=m;k++)
                sol[j]-=sol[k]*a[i][k];
        }
    }
    for(i=1;i<=m;i++)
        g<<setprecision(10)<<fixed<<sol[i]<<" ";
    return 0;
}
