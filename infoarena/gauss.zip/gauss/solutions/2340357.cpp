#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin ("gauss.in");
ofstream cout ("gauss.out");

const double eps = 1e-6;

int n, m;

double v[305][305], x[305];

int main() {
  cin >> n >> m;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m + 1; j++)
      cin >> v[i][j];
  }
  int i = 1, j = 1;
  while(i <= n && j <= m) {
    int k = i;
    while(k <= n) {
      if(v[k][j] < -eps || eps < v[k][j])
        break;
    }
    if(k == n + 1) {
      j++;
      continue;
    }
    if(k != i) {
      for(int l = 1; l <= m + 1; l++)
        swap(v[i][l], v[k][l]);
    }
    for(int l = j + 1; l <= m + 1; l++)
      v[i][l] /= v[i][j];
    v[i][j] = 1;
    for(int l = i + 1; l <= n; l++) {
      for(int p = j + 1; p <= m + 1; p++)
        v[l][p] -= v[l][j] * v[i][p];
      v[l][j] = 0;
    }
    i++;
    j++;
  }
  for(int i = n; i >= 1; i--) {
    for(int j = 1; j <= m + 1; j++) {
      if(v[i][j] < -eps || eps < v[i][j]) {
        if(j == m + 1) {
          cout << "Imposibil";
          return 0;
        }
        x[j] = v[i][m + 1];
        for(int l = j + 1; l <= m; l++)
          x[j] -= x[l] * v[i][l];
        break;
      }
    }
  }
  cout << fixed << setprecision(10);
  for(int i = 1; i <= m; i++)
    cout << x[i] << " ";
  return 0;
}
