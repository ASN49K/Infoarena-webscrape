#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
using namespace std;

const int nmax = 310;
const double eps = 1e-8;

int n, m;
double a[nmax][nmax];

void gauss()
{
    int ec = 1, nec = 1;
    while (ec <= n && nec <= m)
    {
        int k = ec;
        while (k <= n && fabs(a[k][nec]) < eps)
            k ++;
        if (k > n)
        {
            nec ++;
            continue;
        }
        for (int j = 1; j <= m + 1; ++ j)
            swap(a[ec][j], a[k][j]);

        for (int i = 1; i <= n; ++ i)
            if (i != ec)
            {
                double f = a[i][nec] / a[ec][nec];
                for (int j = 1; j <= m + 1; ++ j)
                    a[i][j] -= a[ec][j] * f;
            }
        ec ++;
        nec ++;
    }
    for (int i = 1; i <= n; ++ i)
        if (fabs(a[i][i]) < eps && fabs(a[i][m + 1]) > eps)
        {
            printf("Imposibil\n");
            exit(0);
        }

    for (int i = 1; i <= n; ++ i)
        printf("%.10f ", a[i][m + 1] / a[i][i]);
    for (int i = n + 1; i <= m; ++ i)
        printf("0.0000000000 ");
}
int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    //freopen("in", "r", stdin);

    scanf("%i %i", &n, &m);

    for (int i = 1; i <= n; ++ i)
        for (int j = 1; j <= m + 1; ++ j)
            scanf("%lf", &a[i][j]);

    gauss();
}
