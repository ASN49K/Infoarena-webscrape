#include <fstream>
#include <vector>
#include <iomanip>

using namespace std;

ifstream in ("gauss.in");
ofstream out ("gauss.out");

const int max_size = 3e2 + 1;
const double eps = 1e-6;

double ans[max_size];
vector <vector <double>> sis;

int main ()
{
    int n, m;
    in >> n >> m;
    for (int i = 0; i < n; i++)
    {
        vector <double> aux;
        for (int j = 0; j <= m; j++)
        {
            double x;
            in >> x;
            aux.push_back(x);
        }
        sis.push_back(aux);
    }
    int i = 0, j = 0;
    while (i < n && j < m)
    {
        int k;
        for (k = i; k < m; j++)
        {
            if (sis[k][j] < -eps || sis[k][j] > eps)
            {
                break;
            }
        }
        if (k == n)
        {
            i++;
            continue;
        }
        if (i != k)
        {
            swap(sis[i], sis[k]);
        }
        for (int p = j + 1; p <= m; p++)
        {
            sis[i][p] /= sis[i][j];
        }
        sis[i][j] = 1;
        for (int p = i + 1; p < n; p++)
        {
            for (int q = j + 1; j <= m; j++)
            {
                sis[p][q] -= sis[p][j] * sis[i][q];
            }
            sis[p][j] = 0;
        }
        i++;
        j++;
    }
    for (i = n - 1; i >= 0; i--)
    {
        for (j = 0; j <= m; j++)
        {
            if (sis[i][j] < -eps || sis[i][j] > eps)
            {
                if (j == m)
                {
                    out << "Imposibil";
                    return 0;
                }
                ans[j] = sis[i][m];
                for (int k = j + 1; k < m; k++)
                {
                    ans[j] -= ans[k] * sis[i][k];
                }
                break;
            }
        }
    }
    out << fixed << setprecision(6);
    for (i = 0; i < m; i++)
    {
        out << ans[i] << " ";
    }
    in.close();
    out.close();
    return 0;
}
