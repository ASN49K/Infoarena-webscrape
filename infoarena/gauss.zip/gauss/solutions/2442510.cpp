#include <iostream>
#include <fstream>
#include <iomanip>

int n,m;
long double v[350][350];
int exist[350];
int place;

void multR(int i, int j, int p)
{
  if(v[i][j]!=0)
  {
    long double mult=-v[i][j]/v[p][j];
    for(int x=j;x<=n;x++)
      v[i][x]=v[i][x]+mult*v[p][x];
  }
}

int main()
{
  freopen("gauss.in","r",stdin);
  freopen("gauss.out","w",stdout);
  scanf("%d %d",&n,&m);
  for(int i=0;i<m;i++)
    for(int j=0;j<=n;j++)
    {
      scanf("%llf",&v[i][j]);
      exist[j]=-1;
    }
  for(int j=0;j<n;j++)
    for(int i=j;i<m;i++)
      if(j<m && v[i][j]!=0)
      {
        exist[j]=place;
        std::swap(v[i],v[place]);
        place++;
        break;
      }
  for(int j=0;j<n;j++)
  {
    if(exist[j]==-1)continue;
    int p=exist[j];
    for(int i=p+1;i<m;i++)
      multR(i,j,p);
  }
  for(int i=0;i<m;i++)
  {
    bool all0=true;
    for(int j=0;j<n;j++)
      if(v[i][j]!=0)
        all0=false;
    if(all0&&v[i][n]!=0)
    {
      printf("Imposibil");
      return 0;
    }
  }
  for(int j=n-1;j>=0;j--)
  {
    int p = exist[j];
    if(p==-1)continue;
    for(int i=p-1;i>=0;i--)
      multR(i,j,p);
    long double f=v[p][j];
    for(int i=j;i<=n;i++)
      v[p][i]=v[p][i]/f;
  }
  std::cout<<std::setprecision(10)<<std::fixed;
  for(int j=0;j<n;j++)
  {
    if(exist[j]!=-1)
      std::cout<<v[exist[j]][n]<<" ";
    else
      std::cout<<0.0<<" ";
  }
}
