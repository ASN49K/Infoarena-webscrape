#include <bits/stdc++.h>

using namespace std;
constexpr double eps=0.00001;
int N,M;
double V[301][301];
int S[301],p[300];

void read_data()
{
    ifstream f("gauss.in");
    f>>N>>M;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M+1;j++)
            f>>V[i][j];
    f.close();
}

int isZero(double x)
{
    return fabs(x)<eps;
}

void computeGaussianElimination()
{
    freopen("gauss.out", "w", stdout);
    for (int i=1;i<=N;++i)
    {

        int first;
        for(first=1;isZero(V[i][first]);first++);///Caut primul element nenul.

        if(first==M+2) continue;///Daca toti coef sunt 0 si rezoltatul este tot 0 avem solutie
        if(first==M+1)  ///Daca toti coef sunt nuli si rezultatul nu este atunci nu avem solutie
        {
            cout << "Imposibil" << '\n';
            return;
        }


        ///Eliminam elementul first de pe celelalte linii
        for(int j=1;j<=N;++j)
            if (i!=j)
            {
                int aux=V[j][first]/V[i][first];
                for(int k=1;k<=M+1;++k) V[j][k]-=V[i][k]*aux;
            }

        p[i] = first;
    }

     for(int i=1; i<=M; ++i)
        if(p[i]) S[p[i]]=V[i][N+1]/V[i][p[i]];

     for(int i=1; i<=N; ++i) printf("%.10lf ", S[i]);
}


int main()
{
    read_data();
    computeGaussianElimination();
}
