#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");

const int NMax = 300; const double E = 0.0000001;

double A[NMax + 5][NMax + 5], Sol[NMax + 5], T;
int N, M;

bool Solve()
{
    for(int i = 1; i <= M; i++)
    {
        if(A[i][i] == 0)
        {
            for(int j = i + 1; j <= N; j++)
                if(A[j][i] != 0)
                {
                    swap(A[i], A[j]);
                    break;
                }
        }
        for(int j = i + 1; j <= N; j++)
        {
            if(A[j][i] == 0) continue;
            T = A[i][i] / A[j][i];

            for(int k = i; k <= M + 1; k++)
            {
                A[j][k] = T * A[j][k] - A[i][k];
                if(fabs(A[j][k]) < E) A[j][k] = 0;
            }
        }
    }

    for(int i = N; i > 0; i--)
        for(int j = 1; j <= M + 1; j++)
            if(A[i][j] != 0)
            {
                if(j == M + 1) return 0;
                Sol[j] = A[i][M + 1];

                for(int k = j + 1; k <= M; k++)
                    Sol[j] -= Sol[k] * A[i][k];

                Sol[j] /= A[i][j];
                break;
            }
    return 1;
}

int main()
{
    fin >> N >> M;

    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M + 1; j++)
        {
            fin >> A[i][j];
            if(fabs(A[i][j]) < E) A[i][j] = 0;
        }

    if(Solve() == 0)
        fout << "Imposibil\n";
    else
    {
        for(int i = 1; i <= M; i++)
            fout << fixed << setprecision(10) << Sol[i] << " ";
    }
    fin.close();
    fout.close();

    return 0;
}
