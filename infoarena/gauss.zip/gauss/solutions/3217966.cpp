#include <iostream>
#include <fstream>

using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

struct Eq
{
    double a[10];
    double b;
};

double det (double t[][10], int n, int i, int j)
{
    if (n==1) return t[i][j];
    else
    {
        for (int k=j+1; k<=n; k++)
        {
            double rat=t[i][k]/t[i][j];
            for (int l=i; l<=n; l++)
            {
                t[l][k]=t[l][k]-rat*t[l][j];
            }
        }
        return det(t, n-1, i+1, j+1)*t[i][j];
    }
}

void kiir (Eq t[], int n)
{
    for (int i=1; i<=n; i++)
        {
            for (int j=1; j<=n; j++)
            {
                if (t[i].a[j]!=0)
                {
                    if (t[i].a[j]==1) cout << (char)('a'+j-1);
                    else if (t[i].a[j]==-1) cout << "-" << (char)('a'+j-1);
                         else cout << t[i].a[j] << (char)('a'+j-1);
                }
                if (j!=n&&t[i].a[j+1]>0) cout << "+";
            }
            cout << "=" << t[i].b << endl;
        }
    cout << endl;
}

void megold (Eq t[], double x[], int n)
{
    for (int i=1; i<n; i++)
    {
        for (int j=i+1; j<=n; j++)
        {
            double rat=t[j].a[i]/t[i].a[i];
            t[j].a[i]=0;
            for (int k=i+1; k<=n; k++)
            {
                t[j].a[k]=t[j].a[k]-rat*t[i].a[k];
            }
            t[j].b=t[j].b-rat*t[i].b;
        }
    }
    for (int i=n; i>=1; i--)
    {
        x[i]=t[i].b;
        for (int j=1; j<=n; j++)
        {
            if (j!=i) x[i]=x[i]-x[j]*t[i].a[j];
        }
        x[i]=x[i]/t[i].a[i];
    }
}

int main()
{
    int n, m;
    f >> n >> m;
    Eq t[10];
    double k[10][10];
    double x[10];
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
        {
            f >> t[i].a[j];
            k[i][j]=t[i].a[j];
        }
        f >> t[i].b;
        x[i]=0;
    }
    if (det (k, n, 1, 1)!=0)
    {
        megold (t, x, n);
        for (int i=1; i<=n; i++)
        {
            if (x[i]==-0) g << 0 << " ";
            else g << x[i] << " ";
        }
    }
    return 0;
}

