#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>

using namespace std;

typedef long double ld;
const int N = 300 + 7;
int n, m;
ld a[N][N], sol[N];
int nonzero[N];

int main() {
  freopen ("gauss.in", "r", stdin);
  freopen ("gauss.out", "w", stdout);
  cin >> n >> m;
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= m + 1; j++) {
      cin >> a[i][j];
    }
  }
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= m; j++) {
      if (abs(a[i][j]) > 1e-14) {
        nonzero[i] = j;
        break;
      }
    }
    if (!nonzero[i]) {
      if (abs(a[i][m + 1]) > 1e-14) {
        cout << "Imposibil\n";
        return 0;
      }
      continue;
    }
    int c = nonzero[i];
    for (int r = 1; r <= n; r++) {
      if (i != r && a[r][c] > 1e-14) {
        ld coef = a[r][c] / a[i][c];
        for (int j = 1; j <= m + 1; j++) {
          a[r][j] -= coef * a[i][j];
        }
      }
    }
  }
  for (int i = 1; i <= n; i++) {
    if (nonzero[i]) {
      sol[nonzero[i]] = a[i][m + 1] / a[i][nonzero[i]];
    }
  }
  for (int i = 1; i <= m; i++) {
    cout << fixed << setprecision(10) << sol[i] << " ";
  }
  cout << "\n";
}
