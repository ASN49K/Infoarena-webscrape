#include <iostream>
#include <fstream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

FILE *in, *out;

const long double EPS = 0.0000001;

int main() {
    in = fopen("gauss.in", "r");
    out = fopen("gauss.out", "w");

    int n, m;
    fscanf(in, "%d%d", &n, &m);
    vector<vector<double>> v(n + 1, vector<double> (m + 2, 0));
    for(int i = 1; i <= n; i ++)
        for(int j = 1; j <= m + 1; j ++) {
            fscanf(in, "%lf", &v[i][j]);
            //cout << v[i][j] << endl;
        }

    int i = 1, j = 1;
    while(i <= n && j <= m) {

        int k;
        for(k = i; k <= n; k ++)
            if(v[k][j] < -EPS || v[k][j] > EPS)
                break;
        // j este variabila libera
        if(k == n + 1) {
            j ++;
            continue;
        }

        if(k != i)
            swap(v[i], v[k]);

        for(int l = j + 1; l <= m + 1; l ++)
            v[i][l] /= v[i][j];
        v[i][j] = 1;

        for(int u = i + 1; u <= n; u ++) {
            for(int l = j + 1; l <= m + 1; l ++)
                v[u][l] -= (v[u][j] * v[i][l]);
            v[u][j] = 0;
        }

        i ++;
        j ++;
    }

    vector<double> x(m + 1, 0);
    for(int i = n; i >= 1; i --) {
        for(int j = 1; j <= m + 1; j ++) {
            if(v[i][j] > EPS || v[i][j] < -EPS) {
                if(j == m + 1) {
                    fprintf(out, "Imposibil");
                    return 0;
                }

                x[j] = v[i][m + 1];
                for(int k = j + 1; k <= m; k ++)
                    x[j] -= (x[k] * v[i][k]);

                break;
            }
        }
    }

    for(int i = 1; i <= m; i ++)
        fprintf(out, "%.8f ", x[i]);

    return 0;
}
