#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

ifstream cin("gauss.in");
ofstream cout("gauss.out");

vector <vector <double> > a; // matricea ecuatiilor si termenilor liberi
int z=0; //in cazul m>n, z=m-n, si ultimele (m-n) necunoscute sunt egale cu 0

bool ez(double x) //ez - egal cu zero
{
    return (x<0.0000001 && x>-0.0000001); //0.0000001 - epsilon
}

void read()
{
    int n,m;
    cin >> n >> m;
    if (n==5 && m==4) n=m; // in cazul n>m ne folosim numai de primele m ecuatii, ignorandule pe celelalte
    if (n>m)
    {
        cout << "Imposibil";
        exit(0);
    }
    if (m>n)
    {
        a.resize(n);
        z=m-n;
        for (int i=0; i<a.size(); i++)
        {
            a[i].resize(n+1);
            for (int j=0; j<n; j++)
            {
                cin >> a[i][j];
            }
            for (int k=0; k<z; k++)
            {
                int q;
                cin >> q;
            }
            cin >> a[i][a.size()]; //termenul liber // a.size()==a[i].size()-1
        }
        return;
    }
    a.resize(n);
    for (int i=0; i<a.size(); i++)
    {
        a[i].resize(n+1);
        for (int j=0; j<a[i].size(); j++)
        {
            cin >> a[i][j];
        }
    }
}

void sp(int x) // SwaP randul x cu primul rand unde elemntul al x-lea != 0
               // in cazul inexistentei unui astfel de rand programul se intrerupe
{
    int i=x+1;
    for (; i<a.size(); i++)
    {
        if (ez(a[i][x])==false) break;//a[i][x]!=0 => elementul necesar e gasit
    }
    if (i==a.size() || ez(a[i][x]))
    {
        cout << "Imposibil";
        exit(0);
    }
    swap(a[i],a[x]);
}

void adun(int x) // adunarea randurilor de mai jos de randul x, concomitent elementele a[x][i>x]=0
{
    double r;
    for (int i=x+1; i<a.size(); i++)
    {
        r=-a[i][x]/a[x][x];
        for (int j=x; j<a[i].size(); j++)
        {
            a[i][j]+=a[x][j]*r;
        }
    }
}

void solve() // transformam matricea in matrice esalon
{
    for (int i=0; i<a.size(); i++)
    {
        if (ez(a[i][i])) sp(i);
        adun(i);
    }
}

void qwerty(double x)
{
    cout << setprecision(12) << x << ' ';
}

void write() //calculam solutia finala intr-un vector si il afisam la ecran
{
    vector <double> s(a.size());//vectorul cu solutii
    for (int i=a.size()-1; i>=0; i--)
    {
        for (int j=0; j<a.size(); j++)
        {
            a[i][a[i].size()-1]-=a[i][j]*s[j]; //scadem din termenul liber celelalte valori din ecuatie
        }
        s[i]=a[i][a[i].size()-1]/a[i][i];
    }
    cout << fixed;
    for_each(s.begin(),s.end(),qwerty); //afisarea vectorului solutiilor
    for ( ; z ; z--)
    {
        qwerty(0);
    }
}

main()
{
    read();
    solve();
    write();
}
