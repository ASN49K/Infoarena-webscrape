#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>

using namespace std;

const double eps = 1e-10;

bool isZero(double x)
{
    return x >= -eps && x <= eps;
}

int main()
{
    ifstream in("gauss.in");
    int n, m;
    in >> n >> m;
    vector<vector<double> > a(n, vector<double>(m+1));
    vector<double> rasp(m);
    for(int i = 0; i < n; ++i)
        for(int j = 0; j <= m; ++j)
            in >> a[i][j];
    in.close();

    for(int i = 0, j = 0; i < n && j < m; ++i, ++j)
    {
        for(int k = i; k < n; ++k)
        {
            if(isZero(a[k][j]) == false)
            {
                if(i != k)
                    swap(a[i], a[k]);
                break;
            }
        }

        if(isZero(a[i][j]))
        {
            --i;
            continue;
        }

        for(int k = m; k >= j; --k)
            a[i][k] /= a[i][j];

        for(int k = i+1; k < n; ++k)
        {
            for(int l = m; l >= j; --l)
                a[k][l] -= a[i][l] * a[k][j];
        }
    }

    ofstream out("gauss.out");
    for(int i = n-1; i >= 0; --i)
    {
        int j = -1;
        for(int k = 0; k < m; ++k)
            if(isZero(a[i][k]) == false)
            {
                j = k;
                break;
            }
        if(j == -1)
        {
            if(isZero(a[i][m]))
                continue;
            out << "Imposibil";
            return 0;
        }
        rasp[j] = a[i][m];
        for(int k = j+1; k < m; ++k)
            rasp[j] -= a[i][k] * rasp[k];
    }

    for(auto x:rasp)
        out << fixed << setprecision(10) << x << " ";
    out.close();
    return 0;
}
