#include <fstream>
#include <iomanip>

using namespace std;

#define NMAX 305
#define EPS 0.0000001

ifstream f("gauss.in");
ofstream g("gauss.out");

int n, m, nr_col;
double mat[NMAX][NMAX], x[NMAX];

void citire() {
    f >> n >> m;
    nr_col = m + 1;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= nr_col; ++j)
            f >> mat[i][j];
}

void interschimbare_linii(int l1, int l2, int cstart) {
    double aux;
    for (int j = cstart; j <= nr_col; j++) {
        aux = mat[l1][j];
        mat[l1][j] = mat[l2][j];
        mat[l2][j] = aux;
    }
}

bool este_0(double x) {
    return abs(x) < EPS;
}

void modificare_matrice() {
    for (int l = 1, c = 1; l <= n && c <= m; c++) {
        bool ok = false;
        for (int i = l; i <= n && !ok; i++)
            if (!este_0(mat[i][c])) {
                if (i != l)
                    interschimbare_linii(l, i, c);
                ok = true;
            }

        if (ok) {
            double impartire = mat[l][c];
            for (int j = c; j <= nr_col; ++j)
                mat[l][j] /= impartire;

            for (int i = l + 1; i <= n; ++i)
                if (!este_0(mat[i][c]))
                    for (int j = nr_col; j >= c; --j)
                        mat[i][j] -= mat[l][j]*mat[i][c];
            l++;
        }
    }
}

void afisare_solutie() {
    for (int i = n; i >= 1; --i)
        for (int j = 1; j <= nr_col; ++j)
            if (!este_0(mat[i][j])) {
                if (j == nr_col) {
                    g << "Imposibil";
                    return;
                }
                double rez = mat[i][nr_col];
                for (int k = j + 1; k <= m; ++k)
                    rez -= mat[i][k] * x[k];
                x[j] = rez;
                break;
            }
    for (int i = 1; i <= m; ++i)
        g << fixed << setprecision(8) << x[i] << ' ';
}

int main() {
    citire();
    modificare_matrice();
    afisare_solutie();
}