#include <bits/stdc++.h>

using namespace std;

const int MAXN = 305;

#define EPS 1e-11

long double a[MAXN][MAXN], ans[MAXN];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
    int n, m;
    fin >> n >> m;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m + 1; ++j)
            fin >> a[i][j];
    }
    int lin = 1, col = 1;
    while(lin < n && col <= m){
        int x = 0;
        for(int i = lin; i <= n && x == 0; ++i)
            if(a[i][col] != 0.0000) x = i;
        if(x){
            long double reduc = a[lin][col];
            for(int j = 1; j <= m + 1; ++j){
                swap(a[lin][j], a[x][j]);
                a[lin][j] /= reduc;
            }
            for(int i = lin + 1; i <= n; ++i){
                reduc = a[i][col];
                for(int j = 1; j <= m + 1; ++j)
                    a[i][j] -= a[lin][j] * reduc;
            }
            lin++;
            col++;
        }
        else col++;
    }
    bool exista = 1;
    for(int i = n; i >= 1; --i){
        int pi = 1;
        while(pi <= m + 1 && a[i][pi] == 0.000) pi++;
        if(pi > m) exista = 0;
        ans[pi] = a[i][m + 1];
        for(int j = m; j > pi; --j) ans[pi] -= ans[j] * a[i][j];
        ans[pi] /= a[i][pi];
    }
    if(exista){
        for(int i = 1; i <= m; ++i)
            fout << fixed << setprecision(10) << ans[i] << " ";
    }
    else fout << "Imposibil";
    return 0;
}
