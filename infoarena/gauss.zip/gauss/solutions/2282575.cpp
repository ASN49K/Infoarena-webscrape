#include<stdio.h>
#include<cstring>

using namespace std;

#define MAXN 300
#define MAXM 300

int M,N;

double** A;
double* X;

int *p;

bool gauss(){
	int i=0,j=0;
	double* temp;
	double aux;
	while(i<N && j<M){
		int x;
		for(x=i;x<N;x++){
			if(A[x][j]!=0)
				break;
		}
		if(x==N){ // variabila libera
			j++; continue;
		}
		temp=A[i];
		A[i]=A[x];
		A[x]=temp;
		aux=A[i][j];
		for(int k=0;k<=M;k++) // se poate porni de la j incolo
			A[i][k]/=aux;
	
		for(int u=i+1;u<N;u++){
			aux=A[u][j];
			for(int c=0;c<=M;c++){
				A[u][c]-=(aux*A[i][c]); 
			}
		}
		p[i]=j+1; // cu 1 in plus
		i++; j++;
	}

	for(i=N-1;i>=0;i--){
		if(p[i]==0){ // nu am gasit pozitie pentru aceasta linie
			if(A[i][M]!=0)
				return false;
		}
		else{
			p[i]--;
			X[p[i]]=A[i][M];
			for(int j=p[i]+1;j<M;j++)
				X[p[i]]-=(A[i][j]*X[j]);
		}
	}
	return true;
}

int main(){
	
	freopen("gauss.in","rt",stdin);
	//freopen("test11.in","rt",stdin);
	freopen("gauss.out","wt",stdout);
	
	scanf("%d %d",&N,&M);
	
	p=new int[N];
	memset(p,0,N*sizeof(int));
	X=new double[N];
	memset(X,0,N*sizeof(double));

	A=new double*[N];
	for(int i=0;i<N;i++)
		A[i]=new double[M+1];

	int aux;
	for(int i=0;i<N;i++){
		for(int j=0;j<=M;j++){
			scanf("%d",&aux);
			A[i][j]=(double)aux;
		}
	}

	bool ok=gauss();
	if(ok){
		for(int i=0;i<M;i++)
			printf("%.8f ",X[i]);
	}
	else{
		printf("Imposibil\n");	
	}

	return 0;
}