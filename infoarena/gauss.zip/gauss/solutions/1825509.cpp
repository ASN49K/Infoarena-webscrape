#include <cstdio>
#include <valarray>

const int MAX_N = 300;
const int MAX_M = 300;
const double EPS = 1e-7;
double solutie[MAX_M];

std::valarray<double> e[MAX_M];

bool eq(double a, double b) {
  return fabs(a - b) < EPS;
}

int main() {
  int m, n;
  double x;
  FILE *fin = fopen("gauss.in", "r");
  fscanf(fin, "%d%d", &n, &m);
  for(int i = 0; i < n; ++i) {
    e[i].resize(m + 1);
    for(int j = 0; j <= m; ++j)
      fscanf(fin, "%lf", &e[i][j]);
  }
  fclose(fin);

  int i, j;
  i = 0;
  j = 0;
  while(i < n && i < m) {
    int k = i;
    while(k < n && eq(e[k][j], 0.0f))
      ++k;
    if(k == n)
      ++j;
    else {
      e[i].swap(e[k]);
      x = e[i][j];
      e[i] = e[i] / x;
      for(int k = 0; k < n; ++k)
        if(k != i) {
          x = e[k][j];
          e[k] -= e[i] * x;
        }
      ++j;
      ++i;
    }
  }


  for(int k = j; k < m; ++k)
    for(int l = 0; l < n; ++l)
      e[l][k] = 0.0f;


  int p;
  bool cancer = false;
  for(int i = 0; i < n; ++i) {
    p = -1;
    for(int j = 0; j < m; ++j)
      if(eq(e[i][j], 1.0f))
        p = j;
    if(p == -1 && !eq(e[i][m], 0.0f))
      cancer = true;
    else
      solutie[p] = e[i][m];
  }

  FILE *fout = fopen("gauss.out", "w");
  if(cancer)
    fprintf(fout, "Imposibil");
  else
    for(i = 0; i < m; ++i)
      fprintf(fout, "%.10f ", solutie[i]);
  fclose(fout);
  return 0;
}
