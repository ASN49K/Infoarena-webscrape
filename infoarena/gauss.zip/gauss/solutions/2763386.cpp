#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;
ifstream f("gauss.in");
ofstream g("gauss.out");

int n,m;
double a[310][310],b[310],x[310];
//a*x=b
void gauss()
{
    int i,j,t,pivot;
    double Max,ajut,factor;
    for(j=1;j<=m;j++)
    {
        //caut maximul de pe linia pivotului
        Max=0; pivot=j;
        for(i=j+1;i<=n;i++)
            if(Max<abs(a[i][j]))
            {
                Max=abs(a[i][j]);
                pivot=i;
            }
        //interschimb linia curenta cu cea a pivotului
        for(t=j;t<=m;t++)
        {
            ajut=a[j][t];
            a[j][t]=a[pivot][t];
            a[pivot][t]=ajut;
        }
        //interschimb si elementele din vectorul solutiilor
        ajut=b[j];
        b[j]=b[pivot];
        b[pivot]=ajut;
        //fac 0 sub linia curenta
        if(a[j][j]==0)
            continue;
        for(i=j+1;i<=n;i++)
        {
            factor=a[i][j]/a[j][j];
            a[i][j]=0;
            for(t=j+1;t<=m;t++)
                a[i][t]-=factor*a[j][t];
            b[i]-=factor*b[j];
        }
    }
   /* for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
            g<<a[i][j]<<' ';
        g<<'\n';
    }
    for(i=1;i<=n;i++)
        g<<b[i]<<'\n';*/
}

void rezolva_SST()
{
    int i,j;
    double sum;
    for(i=n;i>=1;i--)
    {
        sum=0;
        for(j=m;j>i;j--)
            sum+=a[i][j]*x[j];
        x[i]=(b[i]-sum)/a[i][i];
    }
}
void afiseaza()
{
    int j;
    for(j=1;j<=m;j++)
        g<<setprecision(10)<<x[j]<<' ';
}
int main()
{
    f>>n>>m;
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
            f>>a[i][j];
        f>>b[i];
    }
    gauss();
    rezolva_SST();
    afiseaza();

    return 0;
}
