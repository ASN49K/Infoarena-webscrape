#include<bits/stdc++.h>
using namespace std;
const double E=1e-8;
const int N=309;
int p[N],i,j,k,n,m,t;
double a[N][N],x[N],c;
int main()
{
    ifstream f("gauss.in");
    ofstream g("gauss.out");
    f>>n>>m;
    for(i=1;i<=n;++i)
        for(j=1;j<=m+1;++j)
            f>>a[i][j];
    for(i=1;i<=n;p[i++]=t)
    {
        for(t=1;-E<a[i][t]&&a[i][t]<E;t++);
        if(t==m+2)
            continue;
        if(t==m+1)
        {
            g<<"Imposibil";
            return 0;
        }
        for(j=1;j<=n;++j)
        {
            if(i==j)
                continue;
            for(c=a[j][t]/a[i][t],k=1;k<=m+1;++k)
                a[j][k]-=a[i][k]*c;
        }
    }
    for(i=1;i<=m;++i)
        if(p[i])
            x[p[i]]=a[i][m+1]/a[i][p[i]];
    for(i=1;i<=m;++i)
        g<<fixed<<setprecision(10)<<x[i]<<'\n';
}
