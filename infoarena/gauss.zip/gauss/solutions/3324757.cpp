#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int inf = 1e9;
const double eps = 1e-7;

const string txt = "data", file = "gauss";
const int nmax = 2e5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n, m;
double a[305][305], ans[305];

void swap_lines(int l1, int l2) {
	for (int i = 1; i <= m + 1; i++)
		swap(a[l1][i], a[l2][i]);
}

void gauss()
{
	int i = 1, j = 1;
	while (i <= n && j <= m)
	{
		int k;
		for (k = i; k <= n; k++)
			if (abs(a[k][j]) > eps) break;

		if (k > n) {
			j++; continue;
		}

		swap_lines(i, k);

		for (int t = m + 1; t >= j; t--)
			a[i][t] /= a[i][j];

		for (int l = i + 1; l <= n; l++) {
			for (int c = j + 1; c <= m + 1; c++)
				a[l][c] -= a[l][j] * a[i][c];
			a[l][j] = 0;
		}

		i++; j++;
	}

	for (int i = n; i >= 1; i--)
		for(int j = 1; j <= m + 1; j ++)
			if (abs(a[i][j]) > eps)
			{
				if (j == m + 1) {
					g << "Imposibil";
					exit(0);
				}

				ans[j] = a[i][m + 1];
				for (int k = j + 1; k <= m; k++)
					ans[j] -= ans[k] * a[i][k];

				break;
			}
}

int main()
{
	f >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m + 1; j++)
			f >> a[i][j];
	
	gauss();

	for (int i = 1; i <= m; i++)
		g << fixed << setprecision(10) << ans[i] << " ";
	return 0;
}