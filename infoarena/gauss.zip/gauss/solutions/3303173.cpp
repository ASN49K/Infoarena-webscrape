#include <bits/stdc++.h>

using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");
long double eror=1e-18;
long double v[505][505],rez[505];
bool check[505];
int main()
{
    int n,m;
	in>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m+1;j++)
			in>>v[i][j];
	int i=1;
	int j=1;
	while(j<=m){
		int poz=0;
		for(int k=i;k<=n;k++)
			if(v[k][j]!=0){
				poz=k;
				break;
			}
		if(poz==0){
			j++;
			continue;
		}
		swap(v[i],v[poz]);
		long double nr=v[i][j];
		for(int k=1;k<=m+1;k++)
			v[i][k]/=nr;
		for(int k=i+1;k<=n;k++){
			long double u=v[k][j];
			for(int l=1;l<=m+1;l++)
				v[k][l]-=u*v[i][l];
		}
		i++,j++;
	}
	for(int i=n;i>=1;i--){
		int cnt=0;
		long double s=0;
		for(int j=1;j<=m;j++){
			if(v[i][j]==0)
				continue;
			if(check[j])
			{
				s+=v[i][j]*rez[j];
				continue;
			}
			check[cnt]=1;
			cnt=j;
		}
		if(cnt==0){
			if(abs(s-v[i][m+1])>eror){
				out<<"Imposibil";
				return 0;
			}
			continue;
		}
		long double val=(v[i][m+1]-s)/v[i][cnt];
		rez[cnt]=val;
		check[cnt]=1;
	}
	for(int i=1;i<=m;i++)
		out<<fixed<<setprecision(10)<<rez[i]<<' ';
	return 0;
}