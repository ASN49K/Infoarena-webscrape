#include <bits/stdc++.h>
using namespace std;

const int NMAX = 300;
const double EPS = 1e-10;

double a[NMAX][NMAX + 1];
double ans[NMAX];

int main() {
    FILE *fin, *fout;
    fin = fopen("gauss.in", "r");
    fout = fopen("gauss.out", "w");
    int n, m;
    fscanf(fin, "%d%d", &n, &m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m + 1; j++)
            fscanf(fin, "%lf", &a[i][j]);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m + 1; j++) {
            cout << a[i][j] << ' ';
        }
        cout << endl;
    }
    cout << endl;
    int lin, col;
    lin = col = 0;
    while(lin < n && col < m) {
        int lin2 = -1;
        for(int i = lin; i < n; i++) {
            if(lin2 == -1 && (a[i][col] - EPS > 0 || a[i][col] + EPS < 0))
                lin2 = i;
        }
        if(lin2 == -1)
            col++;
        else {
            if(lin2 != lin) {
                for(int j = 0; j < m + 1; j++)
                    swap(a[lin][j], a[lin2][j]);
            }
            cout << lin << ' ' << col <<  ' ' << a[lin][col] << endl;
            for(int j = col + 1; j < m + 1; j++)
                a[lin][j] = a[lin][j] / a[lin][col];
            a[lin][col] = 1;
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < m + 1; j++) {
                    cout << a[i][j] << ' ';
                }
                cout << endl;
            }
            cout << endl;
            for(int i = lin + 1; i < n; i++) {
                for(int j = col + 1; j < m + 1; j++)
                    a[i][j] -= a[i][col] * a[lin][j];
                a[i][col] = 0;
            }
            lin++;
            col++;
        }
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m + 1; j++) {
                cout << a[i][j] << ' ';
            }
            cout << endl;
        }
        cout << endl;
    }
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m + 1; j++) {
            cout << a[i][j] << ' ';
        }
        cout << endl;
    }
    bool stg = true;
    for(int i = n - 1; i >= 0 && stg; i--) {
        int col2 = -1;
        for(int j = 0; j < m + 1 && stg; j++) {
            if(col2 == -1 && (a[i][j] - EPS > 0 || a[i][j] + EPS < 0)) {
                //cout << j << endl;
                col2 = j;
            }
        }
        cout << col2 << endl;
        if(col2 == m)
            stg = false;
        if(stg) {
            ans[col2] = a[i][m];
            for(int col = col2 + 1; col < m + 1; col++) {
                ans[col2] -= ans[col] * a[i][col];
            }
        }
    }
    if(stg == false)
        fprintf(fout, "Imposibil");
    else {
        for(int i = 0; i < m; i++)
            fprintf(fout, "%.8lf ", ans[i]);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}