#include<stdio.h>
#define MAXN 300
bool gaussjordan();
FILE*fin,*fout;
double mat[MAXN+1][MAXN+2];
double newmat[MAXN+1][MAXN+2];
int N,M;
int main()
{
    fin=fopen("gauss.in","r");
    fout=fopen("gauss.out","w");

    fscanf(fin,"%d%d",&N,&M);
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=M+1;j++)
        {
            fscanf(fin,"%lf",&mat[i][j]);
        }
    }
    for(int i=N+1;i<=M;i++)
    {
        for(int j=1;j<=M+1;j++)
        {
            mat[i][j]=mat[i-N][j];
        }
    }
    N=M;
    if(gaussjordan())
    {
        for(int i=1;i<=N;i++)
        {
            fprintf(fout,"%.11f ",mat[i][M+1]);
        }
    }
    else
    {
        fprintf(fout,"Imposibil");
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
bool gaussjordan()
{
    for(int lin=1;lin<=N;lin++)
    {
        int linpivot=lin,colpivot=0;
        for(int j=lin;j<=M && !colpivot;j++)
        {
            if(mat[lin][j]!=0)
            {
                colpivot=j;
            }
        }
        if(!colpivot)
        {
            return 0;
        }
        for(int i=1;i<=N;i++)
        {
            for(int j=lin;j<=M+1;j++)
            {
                if(i==linpivot)
                {
                    newmat[i][j]=mat[i][j]/mat[linpivot][colpivot];
                }
                else if(j==colpivot)
                {
                    newmat[i][j]=0;
                }
                else
                {
                    newmat[i][j]=mat[i][j]-(mat[i][colpivot]*mat[linpivot][j])/mat[linpivot][colpivot];
                }
            }
        }
        for(int i=1;i<=N;i++)
        {
            for(int j=lin;j<=M+1;j++)
            {
                mat[i][j]=newmat[i][j];
            }
        }
    }
    return 1;
}
