#include <fstream>
#include <iomanip>
#include <cmath>
#define Nmax 301
#define e 0.000000000000001
using namespace std;

ifstream f("gauss.in");
ofstream g("gauss.out");

int n,P[Nmax],m;
double mat[Nmax][Nmax],x[Nmax];

void _swap(int a,int b,int k)
{
    if (a==b)
        return;
    for (int i=k;i<=m+1;i++)
        swap(mat[a][i],mat[b][i]);
}
int main()
{
    f>>n>>m;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m+1;j++)
            f>>mat[i][j];

    int k = 1;
    for (int j=1;j<=m && k<=n;j++)
    {
        int ok = 0;
        for (int i=k;i<=n;i++)
            if (abs(mat[i][j])>=e)
            {
                _swap(i,k,j);
                ok = 1;
                break;
            }
        if (ok==0)
            continue;
        P[k] = j;
        double sav = mat[k][j];
        for (int i=j;i<=m+1;i++)
            mat[k][i] = mat[k][i] / sav;
        for (int L = k+1;L<=n;L++)
        {
            sav = mat[L][j];
            for (int C = j;C<=m+1;C++)
                mat[L][C] = mat[L][C] - mat[k][C] * sav;
        }
        k++;
    }
    k--;

    if (k<n)
        for (int i=k+1;i<=n;i++)
            if (abs(mat[i][m+1]) > e)
            {
                g<<"Imposibil\n";
                return 0;
            }

    for (int i=k;i>=1;i--)
    {
        double rez = mat[i][m+1];
        for (int j=P[i]+1;j<=m;j++)
        {
            rez -= x[j] * mat[i][j];
        }
        x[P[i]] = rez;
    }
    g<<fixed;
    for (int i=1;i<=m;i++)
        g<<setprecision(11)<<x[i]<<' ';

    return 0;
}
