#include <bits/stdc++.h>

using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

int n, m;
double a[301][301], lim = 0.00000001, sol[301];

int main()
{
    in >> n >> m;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m + 1; ++j)
            in >> a[i][j];
    }
    int i = 1, j = 1;
    while (i <= n && j <= m)
    {
        int k;
        for (k = i; k <= n; ++k)
        {
            if (a[k][j] < -lim || a[k][j] > lim)
                break;
        }
        if (k == n + 1)
        {
            ++j;
            continue;
        }
        if (k != i)
        {
            for (int l = 1; l <= m + 1; ++l)
                swap(a[i][l], a[k][l]);
        }
        for (k = j + 1; k <= m + 1; ++k)
            a[i][k] /= a[i][j];
        a[i][j] = 1;
        for (k = i + 1; k <= n; ++k)
        {
            for (int l = j + 1; l <= m + 1; ++l)
                a[k][l] -= a[k][j] * a[i][l];
            a[k][j] = 0;
        }
        ++i;
        ++j;
    }
    for (int i = n; i >= 1; --i)
    {
        for (int j = 1; j <= m + 1; ++j)
        {
            if (a[i][j] < -lim || a[i][j] > lim)
            {
                if (j == m + 1)
                {
                    out << "Imposibil";
                    return 0;
                }
                sol[j] = a[i][m + 1];
                for (int k = j + 1; k <= m; ++k)
                    sol[j] -= sol[k] * a[i][k];
                break;
            }
        }
    }
    for (int i = 1; i <= m; ++i)
        out << fixed << setprecision(7) << sol[i] << " ";
    return 0;
}
