#include <fstream>
#include <iomanip>

using namespace std;

#define MAXN 303
#define eps 1e-9

double ecuations[MAXN][MAXN];
double x[MAXN];


int main() {
    ifstream in("gauss.in");
    ofstream out("gauss.out");

	int n, m;
	in >> n >> m;
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=m + 1; ++j)
			in >> ecuations[i][j];


	int i=1, j = 1, k;
	double aux;


	while(i <= n && j <= m) {
		for(k=i; k<=n; ++k)
			if (-eps > ecuations[k][j] || ecuations[k][j] > eps)
				break;


		if (k <= n) {
			if (k != i)
				for(int l = 1; l<=m + 1; ++l) {
					aux = ecuations[k][l];
					ecuations[k][l] = ecuations[i][l];
					ecuations[i][l] = aux;
				}


			for(int l = j + 1; l <=m + 1; ++l)
				ecuations[i][l] /= ecuations[i][j];
			ecuations[i][j] = 1;

			for(int ii = i + 1; ii <= n; ++ii) {
				for(int jj = j + 1; jj <=m+1; ++jj)
					ecuations[ii][jj] -= ecuations[ii][j] * ecuations[i][jj];

				ecuations[ii][j] = 0;
			}


			++i;
			++j;
		} else {
            ++j;
		}

	}


	for(int i=n; i>0; --i) {
		for(j=1; j<=m; ++j)
			if (-eps > ecuations[i][j] || ecuations[i][j] > eps) {
				x[j] = ecuations[i][m+1];
				for(k = j + 1; k<=m; ++k)
					x[j] -= x[k] * ecuations[i][k];

				break;
			}

		if (j == m+1) {
			out << "Imposibil\n";
			return 0;
		}
	}

	for(int i=1; i<=m; ++i)
		out << fixed << setprecision(8) << x[i] << " ";
	out << "\n";

	return 0;
}
