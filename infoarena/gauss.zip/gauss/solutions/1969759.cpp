#include <bits/stdc++.h>

using namespace std;

const int Nmax = 305;
const double eps = 1e-10;

double a[Nmax][Nmax], coef, ans[Nmax];
int n, m, i, j, k, p, know[Nmax];

bool nul(double x)
{
    return x < eps && x > -eps;
}

int main()
{
    freopen("gauss.in", "r", stdin);
    freopen("gauss.out", "w", stdout);

    scanf("%d%d", &m, &n);
    for(i=1; i<=m; ++i)
        for(j=1; j<=n+1; ++j)
            scanf("%lf", &a[i][j]);

    for(i=1; i<=m; ++i)
    {
        for(p=1; p<=n+1 && nul(a[i][p]); ++p);
        if(p == n+2) continue;
        if(p == n+1)
        {
            printf("Imposibil\n");
            return 0;
        }

        for(j=1; j<=m; ++j)
            if(i!=j && !nul(a[j][p]))
            {
                coef = a[j][p] / a[i][p];
                for(k=1; k<=n+1; ++k)
                    a[j][k] -= a[i][k] * coef;
            }

        know[i] = p;
    }

    for(i=1; i<=m; ++i)
        if(know[i]) ans[know[i]] = a[i][n+1] / a[i][know[i]];

    for(i=1; i<=n; ++i) printf("%.10lf ", ans[i]);

    return 0;
}
