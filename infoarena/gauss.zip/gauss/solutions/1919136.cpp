#include <bits/stdc++.h>
using namespace std;

constexpr bool is_zero(const double d){
    return -1e-10 <= d && d <= 1e-10; }

ifstream f("gauss.in");
ofstream g("gauss.out");
int n, m;
vector<double> rez;
vector<valarray<double>> mat;

void do_gauss(){
    for(int ec = 0, var = 0; ec < n && var < m; ){
        if(is_zero(mat[ec][var])){
            int ec_ = ec;
            while(ec_ < n && is_zero(mat[ec][var])) ++ec_;
            if(ec_ == n){
                ++var;
                continue; }
            else swap(mat[ec], mat[ec_]); }
        mat[ec] /= mat[ec][var];
        for(int i = 0; i < n; ++i){
            if(i == ec) continue;
            const double tmp = mat[i][var];
            mat[i] -= mat[ec] * tmp; }
        ++var, ++ec; } }

int main(){
    f >> n >> m;
    rez.resize(m, 0);
    mat.resize(n, valarray<double>((double)0, m+1));
    for(auto& x : mat)
        for(auto& y : x) f >> y;
    do_gauss();

    if(any_of(begin(mat), end(mat), [](const valarray<double>& v){
        return all_of(begin(v), end(v)-1, &is_zero) && !is_zero(v[m]); })){
        g << "Imposibil" << endl;
        return 0; }
    for(int i = 0; i < n; ++i)
        for(int j = 0; j < m; ++j)
            if(!is_zero(mat[i][j]))
                rez[j] = mat[i][m];
    g << fixed << setprecision(10);
    copy_n(begin(rez), m, ostream_iterator<double>(g, " "));
    return 0; }
