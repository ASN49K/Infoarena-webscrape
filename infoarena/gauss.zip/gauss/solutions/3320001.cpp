#include <bits/stdc++.h>

using namespace std;

const int NMAX = 305;
const double EPS = 0.0000001;
long double a[NMAX][NMAX];
double x[NMAX];

int main()
{
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
    int n,m;
    fin >> n >> m;
    for (int i = 1;i <= n;i++) {
        for (int j = 1;j <= m + 1;j++) {
            fin >> a[i][j];
        }
    }
    int i = 1,j = 1,k;
    while (i <= n && j <= m) {
        for (k = i;k <= n;k++)
            if (a[k][j] < -EPS || a[k][j] > EPS)
                break;
        if (k == n + 1) {
            j++;
            continue;
        }
        if (k != i) {
            for (int l = 1;l <= m + 1;l++)
                swap(a[i][l], a[k][l]);
        }
        for (int l = j + 1;l <= m + 1;l++)
            a[i][l] /= a[i][j];
        a[i][j] = 1;
        for (int u = i + 1;u <= n;u++) {
            for (int l = j + 1;l <= m + 1;l++)
                a[u][l] -= a[u][j] * a[i][l];
            a[u][j] = 0;
        }
        i++;
        j++;
    }
    for (i = n;i > 0;i--) {
        for (j = 1;j <= m + 1;j++) {
            if (a[i][j] > EPS || a[i][j] < -EPS) {
                if (j == m + 1) {
                    fout << "Imposibil\n";
                    return 0;
                }
                x[j] = a[i][m + 1];
                for (k = j + 1;k <= m;k++)
                    x[j] -= x[k] * a[i][k];
                break;
            }
        }
    }
    for (i = 1;i <= m;i++) 
        fout << fixed << setprecision(8) << x[i] << " ";
    fout << '\n';
    return 0;
}
