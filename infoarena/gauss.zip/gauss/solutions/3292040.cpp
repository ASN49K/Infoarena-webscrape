#include <bits/stdc++.h>

using namespace std;

ifstream fin("gauss.in");
ofstream fout("gauss.out");
const long double EROARE = 1e-10;
long double x[302], a[302][302];
int n, m, i, j, l;

int main(){
    fin >> n >> m;

    if(n < m) {
        fout << "Imposibil";
        return 0;
    }

    n = m;

    for(i = 1; i <= n; i++) {
        for(j = 1; j <= m + 1; j++) fin >> a[i][j];
    }

    for(l = 1; l <= n; l++) {
        for(i = l + 1; i <= n; i++) {
            long double alpha = a[i][l] / a[l][l];

            for(j = 1; j <= m + 1; j++) {
                a[i][j] -= a[l][j] * alpha;
            }
        }
    }

    for(i = n; i >= 1; i--) {
        long double sum = 0;
        for(j = i + 1; j <= m; j++) {
            sum += a[i][j] * x[j];
        }

        x[i] = (a[i][m + 1] - sum) / a[i][i];
    }

    fout << setprecision(10) << fixed;
    for(i = 1; i <= n; i++) {
        fout << x[i] << " ";
    }

    return 0;
}
