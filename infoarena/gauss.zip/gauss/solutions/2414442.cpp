#include <bits/stdc++.h>

using namespace std;

ifstream in("gauss.in");
ofstream out("gauss.out");

const int DIM = 307;
const double EPS = 0.0000001;

double v[DIM][DIM];
double sol[DIM];

int main()
{
	int n, m;
	in >> n >> m;
	
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m + 1; j++)
			in >> v[i][j];
	
	int i = 1, j = 1;
	
	while(i <= n && j <= m)
	{
		int k;
		for(k = i; k <= n; k++)
			if(v[k][j] < -EPS || v[k][j] > EPS)
				break;
		
		if(k == n + 1)
		{
			j++;
			continue;
		}
		
		if(k != i)
		{
			for(int t = 1; t <= m + 1; t++)
				swap(v[k][t], v[i][t]);
		}
		
		for(int t = j + 1; t <= m + 1; t++)
			v[i][t] /= v[i][j];
		
		v[i][j] = 1;
		
		for(int t = i + 1; t <= n; t++)
		{
			for(int it = j + 1; it <= m + 1; it++)
				v[t][it] -= v[t][j] * v[i][it];
				
			v[t][j] = 0;
		}
		
		i++, j++;
	}
	
	for(int i = n; i >= 1; i--)
		for(int j = 1; j <= m + 1; j++)
			if(v[i][j] > EPS || v[i][j] < -EPS)
			{
				if(j == m + 1)
				{
					out << "Imposibil";
					return 0;
				}
				
				sol[j] = v[i][m + 1];
				
				for(int t = j + 1; t <= m; t++)
					sol[j] -= sol[t] * v[i][t];
				
				break;
			}
	
	out << fixed << setprecision(7);
	
	for(int i = 1; i <= m; i++)
		out << sol[i] << ' ';
//	
//	for(int i = 1; i <= n; i++)
//	{
//		out << '\n';
//		
//		for(int j = 1; j <= m + 1; j++)
//			out << v[i][j] << ' ';
//	}
}