#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream fi("gauss.in");
ofstream fo("gauss.out");
const int NMAX=305;
const double eps=1e-10;
int n,m;
double A[NMAX][NMAX],val,X[NMAX];
int main()
{
	fi>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m+1;j++)
			fi>>A[i][j];
	for(int i=1;i<=m;i++)
		for(int j=i;j<=n;j++)
			if(abs(A[j][i])>eps)
			{
				if(i!=j)
					for(int k=1;k<=m+1;k++)
						swap(A[i][k],A[j][k]);
				for(int k=m+1;k>=i;k--)
					A[i][k]/=A[i][i];
				for(int l=i+1;l<=n;l++)
				{
					val=A[l][i]/A[i][i];
					A[l][i]=0;
					for(int k=i+1;k<=m+1;k++)
						A[l][k]-=val*A[i][k];
				}
			}
	for(int i=m;i>=1;i--)
	{
		val=A[i][m+1];
		for(int j=m;j>i;j--)
			val-=X[j]*A[i][j];
		if(abs(val)>eps && abs(A[i][i])<eps) 
		{
			fo<<"Imposibil";
			return 0;
		}
		if(abs(A[i][i])<eps) X[i]=0;
		else X[i]=val/A[i][i];
	}
	for(int i=m+1;i<=n;i++)
	{
		val=0;
		for(int j=1;j<=m;j++)
			val+=X[j]*A[i][j];
		if(abs(val-A[i][m+1])>eps)
		{
			fo<<"Imposibil";
			return 0;
		}
	}
	for(int i=1;i<=m;i++)
		fo<<fixed<<setprecision(10)<<X[i]<<" ";
	fi.close();
	fo.close();
	return 0;
}