# include <fstream>
# include <iomanip>
using namespace std;
const double EPS=1e-3;
ifstream fin("gauss.in");
ofstream fout("gauss.out");
int n,m,i,j,k,t,poz;
double a[305][305],val[305],el;
int main () {
    fin>>m>>n;
    for(i=1;i<=m;i++,j++)
        for(j=1;j<=n+1;j++)
            fin>>a[i][j];
    for(i=1,j=1;i<=m,j<=n;i++,j++){
        if(a[i][j]>=-EPS&&a[i][j]<=EPS)
            for(t=i+1;t<=m;t++)
                if(!(a[t][j]>=-EPS&&a[t][j]<=EPS))
                    for(k=j;k<=n+1;k++)
                        swap(a[i][k],a[t][k]);
        if(a[i][j]>=-EPS&&a[i][j]<=EPS)
            continue;
        for(k=j+1;k<=n+1;k++)
            a[i][k]/=a[i][j];
        a[i][j]=1;
        for(t=i+1;t<=m;t++)
            for(k=n+1;k>=j;k--)
                a[t][k]-=a[i][k]*a[t][j];
    }
    for(i=m;i>=1;i--){
        for(j=1;j<=n+1;j++)
            if(!(a[i][j]>=-EPS&&a[i][j]<=EPS)){
                poz=j;
                break;
            }
        if(poz==n+1){
            fout<<"Imposibil";
            return 0;
        }
        el=0;
        for(j=poz+1;j<=n;j++)
            el+=a[i][j]*val[j];
        val[poz]=(a[i][n+1]-el)/a[i][poz];
    }
    for(i=1;i<=n;i++)
        fout<<setprecision(10)<<fixed<<val[i]<<" ";
    fout<<"\n";
    return 0;
}
