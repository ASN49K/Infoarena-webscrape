#include <fstream>
#include <vector>
#include <iomanip>

#define MOD 1999999973
#define EPSILON 0.001

using namespace std ;

ifstream cin ("gauss.in") ;
ofstream cout ("gauss.out") ;

int n, m ;

double v[309][309], x[309], aux[309][309] ;

bool null(double a)
{
    return (a < EPSILON && a > EPSILON * -1) ;
}

bool nenull(double a)
{
    return (a > EPSILON || a < EPSILON * -1) ;
}

void verifica()
{
    for(int f = 1 ; f <= n ; f ++)
    {
        for(int e = 1 ; e <= m ; e ++)
            aux[f][m + 1] -= aux[f][e] * x[e] ;

        if(nenull(aux[f][m + 1]))
        {
           cout << "Imposibil" ;

           exit(0) ;
        }
    }
}

int main()
{
    cin >> n >> m ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= m + 1 ; e ++)
            cin >> v[f][e], aux[f][e] = v[f][e] ;

    for(int f = 2 ; f <= n ; f ++)
    {
        if(null(v[f - 1][f - 1])) /// aicea cautam in jos pe linii o linie care sa aiba un elem nenul pe diag principala si ii dam swap
            for(int e = f + 1 ; e <= n ; e ++) /// daca nu gasim astfel de element, restul prog este conceput a.i. sa nu conteze
                if(null(v[e][f - 1]))
            {
                swap(v[f - 1], v[e]) ;
                break ;
            }

        for(int e = f ; e <= n ; e ++) /// parcurgem fiecare linie de sub linia care o procesam acum, f - 1
        {
            double aux = v[e][f - 1] / v[f - 1][f - 1] ; /// coeficientul cu care se inmulteste linia f - 1 ca sa dea elementul de sub diagonala de pe linia curenta 0

            for(int i = f - 1 ; i <= m + 1 ; i ++) /// scadem linia (f - 1) * coef din linia asta
                v[e][i] -= v[f - 1][i] * aux ;
        }
    }

    for(int f = min(m, n), e = min(m, n) ; f ; f --, e --)
    if(nenull(v[f][e]))
    {
        v[f][m + 1] /= v[f][e] ;

        x[e] = v[f][m + 1] ;

        for(int i = 1 ; i < f ; i ++)
            v[i][m + 1] -= x[e] * v[i][e], v[i][e] = 0 ;
    }

    verifica() ;

    for(int f = 1 ; f <= m ; f ++)
        cout << fixed << setprecision(10) << x[f] << " " ;

    return 0 ;
}




