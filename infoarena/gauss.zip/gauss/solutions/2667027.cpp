#include <bits/stdc++.h>

using namespace std;
ifstream fin ("gauss.in");
ofstream fout ("gauss.out");

int n,m,i,j;
long long a[305][305];
double rez;
double ans[305];

void swapf(int i, int i2)
{
    for(int j=1;j<=m;j++)
        swap(a[i][j], a[i2][j]);
}
void zero(int col, int lin1, int lin2)
{
    long long nr=a[lin2][col];

    for(int j=1;j<=m;j++)
        a[lin2][j]*=a[lin1][col];

    for(int j=1;j<=m;j++)
        a[lin2][j]-=nr*a[lin1][j];
}
int main()
{
    fin>>n>>m;
    m++;

    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            fin>>a[i][j];

    for(j=1;j<m;j++)
    {
        if(!a[j][j])
        {
            for(i=j+1;i<=n;i++)
                if(a[i][j])
                {
                    swapf(j, i);
                    break;
                }
        }

        for(i=j+1;i<=n;i++)
            zero(j, j, i);
    }

    /*
    cout<<'\n';
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
            cout<<a[i][j]<<' ';
        cout<<'\n';
    }
    cout<<'\n';
    */

    double er=pow(10, -10);
    for(j=m-1;j>=1;j--)
    {
        rez=a[j][m];
        for(i=j+1;i<m;i++)
            rez-=(double)a[j][i]*ans[i];

        //cout<<j<<' '<<rez<<' '<<a[j][j]<<'\n';

        if(!a[j][j])
            ans[j]=0;
        else
            ans[j]=rez/((double)a[j][j]);

        rez-=(double)a[j][j]*ans[j];

        if(abs(rez)>er)
        {
            fout<<"Imposibil";
            return 0;
        }
    }

    fout.precision(12);
    for(i=1;i<m;i++)
        fout<<ans[i]<<' ';
    return 0;
}
