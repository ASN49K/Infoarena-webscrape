
#include <fstream>
#include <iomanip>
using namespace std;
ifstream cin("gauss.in");
ofstream cout("gauss.out");
int n,m;
double A[301][301];
double X[301];
double eps=0.0000001;
int main()
{
    cout<<setprecision(8)<<fixed;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
      for(int j=1;j<=m+1;j++)
         cin>>A[i][j];
    int i=1,j=1,k;
    while(i<=n && j<=m)
    {
        for(k=i;k<=n;k++)
           if(A[k][j]<-eps || A[k][j]>eps)
               break;
        if(k==n+1)
          {
              j++;
              continue;
          }
        if(k!=i)
           for(int l=1;l<=m+1;l++)
             swap(A[i][l],A[k][l]);
        for(int l=j+1;l<=m+1;l++)
            A[i][l]=A[i][l]/A[i][j];
        A[i][j]=1;
        for(int u=i+1;u<=n;u++)
        {
           for(int l=j+1;l<=m+1;l++)
              A[u][l]=A[u][l]-A[u][j]*A[i][l];
            A[u][j]=0;
        }
        i++;
        j++;
    }
    for(int i=n;i>=1;i--)
    {
        for(int j=1;j<=m+1;j++)
           if(A[i][j]<-eps || A[i][j]>eps)
            {
                if(j==m+1)
                  {
                      cout<<"Imposibil";
                      return 0;
                  }
                X[j]=A[i][m+1];
                for(int l=j+1;l<=m;l++)
                  X[j]=X[j]-A[i][l]*X[l];
                break;
            }
    }
    for(int i=1;i<=m;i++)
       cout<<X[i]<<" ";
    return 0;
}
