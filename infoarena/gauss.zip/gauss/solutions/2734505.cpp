#include <fstream>
#include <iomanip>

using namespace std;

const int N = 300;
const double EPS = 10e-10;

int nl, nc;
double v[N + 1][N + 2], sol[N + 1];

inline void interschimb(int a, int b) {
    for (int j = 1; j <= nc + 1; ++j)
        swap(v[a][j], v[b][j]);
}

inline bool is_null(double nr) {
    return nr > -EPS && nr < EPS;
}

int main() {
    ifstream in("gauss.in");
    ofstream out("gauss.out");

    in >> nl >> nc;
    for (int i = 1; i <= nl; ++i)
        for (int j = 1; j <= nc + 1; ++j)
            in >> v[i][j];
    int i, j, k, l;
    double m;
    i = j = 1;
    while (i <= nl && j <= nc) {
        if (is_null(v[i][j])) {
            for (k = i + 1; k <= nl; ++k)
                if (!is_null(v[k][j])) {
                    interschimb(i, k);
                    break;
                }
            if (k == nl + 1) {
                ++j;
                continue;
            }
        }
        for (k = i + 1; k <= nl; ++k)
            if (!is_null(v[k][j])) {
                m = v[k][j] / v[i][j];
                for (l = j; l <= nc + 1; ++l)
                    v[k][l] -= m * v[i][l];
            }
        ++i, ++j;
    }
    for (i = nl; i >= 1; --i) {
        for (j = 1; j <= nc + 1; ++j)
            if (!is_null(v[i][j]))
                break;
        if (j == nc + 1) {
            out << "Imposibil\n";
            in.close();
            out.close();
            return 0;
        }
        else if (j == nc + 2)
            continue;
        sol[j] = v[i][nc + 1];
        for (l = j + 1; l <= nc; ++l)
            sol[j] -= v[i][l] * sol[l];
        sol[j] /= v[i][j];
    }
    for (i = 1; i <= nc; ++i)
        out << fixed << setprecision(10) << sol[i] << ' ';

    in.close();
    out.close();
    return 0;
}