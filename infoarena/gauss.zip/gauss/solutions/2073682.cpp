#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
const double eps = 1e-10;
ifstream f("gauss.in");
ofstream g("gauss.out");
double A[301][302], X[301];
int N, M;

void gauss()
{
    int i = 1, j = 1;
    while(i <= N && j <= M)
    {
        if(abs(A[i][j]) <= eps)
        {
            bool ok = false;
            for(int q = i + 1; q <= N; q++)
                if(abs(A[i][q]) > eps)
                {
                    ok = true;
                    for(int k = i; k <= M + 1; k++)
                        swap(A[i][k], A[q][k]);
                    break;
                }
            if(ok == false)
            {
                j++;
                continue;
            }
        }
        for(int k = j + 1; k <= M + 1; k++)
            A[i][k] /= A[i][j];
        A[i][j] = 1;
        for(int q = i + 1; q <= N; q++)
        {
            for(int k = j + 1; k <= M + 1; k++)
                A[q][k] -= A[i][k] * A[q][j];
            A[q][j] = 0;
        }
        i++, j++;
    }
}

void afis()
{
    g << fixed << setprecision(8);
    for(int i = 1; i <= M; i++)
        g << X[i] << ' ';
}

bool solutie()
{
    for(int i = N; i >= 1; i--)
    {
        int ok = 0, j;
        for(j = i; j <= M; j++)
            if(A[i][j] != 0)
            {
                ok = 1;
                X[j] = A[i][M + 1];
                break;
            }
        if(ok == 0 && A[i][M + 1] != 0)
            return 0;
        for(int k = j + 1; k <= M; k++)
            X[j] -= A[i][k] * X[k];
    }
    return 1;
}

int main()
{
    f >> N >> M;
    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M + 1; j++)
            f >> A[i][j];
    gauss();
    if(solutie())
        afis();
    else
        g << "Imposibil";
    return 0;
}
