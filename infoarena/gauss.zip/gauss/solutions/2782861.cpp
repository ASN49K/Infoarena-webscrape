#include <bits/stdc++.h>

using namespace std;

ifstream f ("gauss.in");
ofstream g ("gauss.out");

constexpr int NMAX = 3e2 + 5;
constexpr double eps = 1e-3;

int N, M;
long double A[NMAX][NMAX];
int P[NMAX];
long double ans[NMAX];

long double modul (long double x) {
    if (x < (long double)(0)) return -x;

    return x;
}

void Read () {
    f >> N >> M;

    for (int i = 1; i <= N; ++ i )
        for (int j = 1; j <= M+1; ++ j )
            f >> A[i][j];
}

void Solve () {
    for (int i = 1; i <= N; ++ i ) {
        P[i] = 0;
        int j = 0;
        for (j = 1; j <= M+1; ++ j )
            if (modul(A[i][j]) > eps) break;

        if (j == M+1) {
            g << "Imposibil" << '\n';
            return;
        }

        if (j == M+2) continue;

        P[i] = j;

        for (int j = 1; j <= N; ++ j )
            if (i != j && modul(A[j][P[i]]) > eps) {
                long double factor = (A[j][P[i]] / A[i][P[i]]);

                for (int k = 1; k <= M+1; ++ k )
                    A[j][k] -= factor * A[i][k];
            }
    }

    for (int i = 1; i <= N; ++ i )
        if (P[i] != 0)
            ans[P[i]] = A[i][M+1] / A[i][P[i]];

    g << setprecision(10) << fixed;
    for (int i = 1; i <= M; ++ i )
        g << ans[i] << " ";
}

int main () {
    Read();
    Solve();

    return 0;
}
