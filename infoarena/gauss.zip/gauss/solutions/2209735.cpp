#include <bits/stdc++.h>
 
using namespace std;
 
typedef long long int ll;
 
ifstream fin("gauss.in");
ofstream fout("gauss.out");
 
const double eps = 1e-6;

int main() {
    int n, m;
    fin >> n >> m;
 
    vector < vector < double > > v(n, vector < double > (m + 1));
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j <= m; ++j) {
            fin >> v[i][j];
        }
    }
 
    int x, y;
    x = y = 0;
    while(x < n && y < m) {
        int z;
        for(z = x; z < n; ++z) {
            if(abs(v[z][y]) > eps) {
                break;
            }
        }

        if(z == n) {
            ++y;
            continue;
        }

        swap(v[x], v[z]);
        for(z = y + 1; z <= m; ++z) {
            v[x][z] /= v[x][y];
        } v[x][y] = 1;

        for(z = x + 1; z < n; ++z) {
            for(int q = y + 1; q <= m; ++q) {
                v[z][q] -= v[z][y] * v[x][q];
            } v[z][y] = 0;
        }
        ++x; ++y;
    }

    vector < double > ans(m, 0);
    for(int i = n - 1; i >= 0; --i) {
        for(int j = 0; j <= m; ++j) {
            if(abs(v[i][j]) > eps) {
                if(j == m) {
                    fout << "Imposibil\n";
                    exit(0);
                }

                ans[j] = v[i][m];
                for(int k = j + 1; k < m; ++k) {
                    ans[j] -= v[i][k] * ans[k];
                }
                break;
            }
        }
    }

    for(auto x: ans) {
        fout << fixed << setprecision(10) << x << " ";
    }
    return 0;
}