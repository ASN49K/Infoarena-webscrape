#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair<ll, ll>
#define sz(x) (int)((x).size())
#define all(a) (a).begin(), (a).end()

/*const ll maxn = 1e5;
int f[maxn],nf[maxn],inv[maxn];
const int M=998244353;
void init(){
    inv[1]=1; for (int i=2;i<maxn;i++) inv[i]=M-1ll*(M/i)*inv[M%i]%M;
    f[0]=nf[0]=1; for (int i=1;i<maxn;i++) f[i]=1ll*f[i-1]*i%M,nf[i]=1ll*nf[i-1]*inv[i]%M;
}
int C(int x,int y){return 1ll*f[x]*nf[y]%M*nf[x-y]%M;} */

const ll mod = 1e9+7;
ll n, k, m, mi, ma;

void solve(){
	
	ifstream cin("gauss.in");
	ofstream cout("gauss.out");
	
	cin >> n >> m;
	ll a[m][n], c[n];
	for(int i = 0; i<n; i++){
		for(int j = 0; j<m; j++){
			cin >> a[j][i];
		}
		cin >> c[i];
	}
	vector<ll> v(m, -1), d(n, -1);

	for(int i = 0; i<m; i++){
		ll j = 0;
		while(a[i][j] == 0 || d[j] != -1){
			j++;
			if(j == n) break;
		}
		if(j == n) continue;
		v[i] = j;
		d[j] = i;
		for(int k = 0; k<n; k++){
			if(k == j) continue;
			c[k] = c[k]*a[i][j] - c[j]*a[i][k];
			ll r = a[i][k];
			for(int h = m - 1; h>=0; h--) a[h][k] = a[h][k]*a[i][j] - a[h][j]*r;
		}	
		
	}
	vector<double> ans;
	for(int i = 0; i<m; i++){
		if(v[i] == -1) {
			ans.pb(0);
			continue;
		}
		ll j = v[i];
		ans.pb(c[j]*1.0/a[i][j]);
		c[j] = 0;
	}
	for(int i = 0; i<n; i++){
		if(c[i] == 0) continue;
		cout << "Imposibil\n";
		return;
	}
	for(int i = 0; i<m; i++) cout << setprecision(8) << fixed << ans[i] << " "; cout << "\n";
	
	//cout << "aue\n";
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);

	//init();
	
	int t=1;
//	cin >> t;
	while(t--) solve();
	
	return 0;
}

