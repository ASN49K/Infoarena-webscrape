#include<bits/stdc++.h>
#define prec (double(1e-10))
using namespace std;

int const NMAX = 305;
int n , m;
double ans;
double A[NMAX][NMAX] , X[NMAX];
int main(){
    ifstream fin("gauss.in");
    ofstream fout("gauss.out");
    fin >> n >> m;
    for(int i = 1 ; i <= n ; ++ i){
        for(int j = 1 ; j <= m + 1 ; ++ j){
            fin >> A[i][j];
        }
    }
    fin.close();
    int i = 1 , j = 1;
    while(i <= n && j <= m){
        int u = i;
        while(u <= n && abs(A[u][j]) < prec)
            ++ u;
        if(u > n){
            continue;
        }
        for(int k = j + 1 ; k <= m + 1 ; ++ k)
            A[u][k] /= A[i][j];
        A[u][j] = 1.0;
        swap(A[i] , A[u]);
        for(int k = i + 1 ; k <= n ; ++ k){
            double x = A[k][j];
            for(int kk = j ; kk <= m + 1 ; ++ kk){
                A[k][kk] -= A[i][kk] * x;
            }
            A[k][j] = 0.0;
        }
        ++ i , ++ j;
    }
    for(int i = n ; i ; -- i){
        int pi(0);
        for(int j = 1 ; j <= m + 1 ; ++ j){
            if(abs(A[i][j]) < prec){
                continue;
            }
            pi = j;
            break;
        }
        if(pi == m + 1){
            fout << "Imposibil\n";
            fout.close();
            exit(0);
        }
        X[pi] = A[i][m + 1];
        for(int j = m ; j > pi ; -- j)
            X[pi] -= X[j] * A[i][j];
    }
    auto sep = "";
    for(int i = 1 ; i <= m ; ++ i)
        fout << sep << fixed << setprecision(10) << X[i] , sep = " ";
    fout << '\n';
    fout.close();
    return 0;
}
