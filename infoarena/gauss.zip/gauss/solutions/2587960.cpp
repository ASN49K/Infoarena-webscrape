#include<fstream>
#include<iomanip>
using namespace std;
ifstream in("gauss.in");
ofstream out("gauss.out");

const int nmax = 306;
const double eps = 0.0000000001;
int n, m, lin = 1, col = 1;
double mat[nmax][nmax], sol[nmax], aux;

int main(){
	in>>n>>m;
	for(int i = 1; i<=n; i++)
        for(int j = 1; j<=m+1; j++)
            in>>mat[i][j];
 
    while(lin<=n && col<=m)
    {
		int ver = 0, i;
        for(i = lin; i<=n; i++)
		{
            if(mat[i][col]<-eps || mat[i][col]>eps)
			{
				ver = 1;
                break;
			}
		}
 
        if(ver==0)
        {
            col++;
            continue;
        }
 
        if(i!=lin)
		{
            for(int l = 1; l<=m+1; l++)
            {
                aux = mat[lin][l];
                mat[lin][l] = mat[i][l];
                mat[i][l] = aux;
			}
		}
 
        for(int l = col + 1; l<=m + 1; l++)
            mat[lin][l] = mat[lin][l] / mat[lin][col];
        mat[lin][col] = 1;
 
        for(int u = lin + 1; u<=n; u++)
        {
            for(int l = col + 1; l<=m + 1; l++)
                mat[u][l] -= mat[u][col] * mat[lin][l];

            mat[u][col] = 0;
        }
 
        lin++;
		col++;
    }
 
    for(int i = n; i>0; i--)
	{
        for(int j = 1; j<=m+1; j++)
		{
            if(mat[i][j]>eps || mat[i][j]<-eps)
            {
                if(j==m + 1)
                {
                    out<<"Imposibil\n";
                    return 0;
                }
 
                sol[j] = mat[i][m + 1];
                for(int h = j + 1; h<=m; h++)
                    sol[j] -= sol[h] * mat[i][h];
 
                break;
            }
		}
	}

	for(int i = 1; i<=m; i++)
		out<<fixed<<setprecision(8)<<sol[i]<<' ';

	return 0;
}