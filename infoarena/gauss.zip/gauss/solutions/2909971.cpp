#include <bits/stdc++.h>

using namespace std;

ifstream fin( "gauss.in" );
ofstream fout( "gauss.out" );

const int DIM = 305;
const double EPS = 1e-8;

double t[DIM][DIM];
double res[DIM];

int main() {
  int n, m;

  fin >> n >> m;
  for ( int i = 1; i <= n; ++i ) {
	for ( int j = 1; j <= m + 1; ++j ) {
	  fin >> t[i][j];
	}
  }
  for ( int l = 1, c = 1; l <= n && c <= m; ++c ) {
	int nxt = l;
	while ( nxt <= n && abs( t[nxt][c] ) < EPS ) {
	  ++nxt;
	}
	if ( nxt > n ) continue;
    for ( int i = 1; i <= m + 1; ++i ) {
	  swap( t[nxt][i], t[l][i] );
	}
    
	for ( int i = c + 1; i <= m + 1; ++i ) {
	  t[l][i] /= t[l][c];
	}
	t[l][c] = 1;
    for ( int nl = l + 1; nl <= n; ++nl ) {
	  for ( int nc = c + 1; nc <= m + 1; ++nc ) {
	    t[nl][nc] -= t[nl][c] * t[l][nc]; 	
	  }
	  t[nl][c] = 0;
	}
    ++l;   
  }
  for ( int i = n; i > 0; --i ) {
    int j = 1; 
	while ( j <= m && abs( t[i][j] ) < EPS ) {
      ++j;
	}
	if ( j > m ) {
	  fout << "Imposibil\n";
	  return 0;
	}
    res[j] = t[i][m + 1];
    for ( int nj = j + 1; nj <= m; ++nj ) {
	  res[j] -= res[nj] * t[i][nj];
	}
  }
  fout << fixed << setprecision(10);
  for ( int i = 1; i <= m; ++i ) {
	fout << res[i] << " ";
  }
  fin.close();
  fout.close();
  return 0;
}
