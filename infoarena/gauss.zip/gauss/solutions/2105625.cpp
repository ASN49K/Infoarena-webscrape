#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <vector>
#define EPS 1e-8
using namespace std;
ifstream si("flux.in");
ofstream so("flux.out");
int c[105][105];
long double a[105][105],v[105];
vector<int> g;
inline void gauss(int n)
{
    int c=2;
    for(int i=2;i<=n;++i)
    {
        int l=i;
        while(l<=n&&fabs(a[l][c])<EPS)
            ++l;
        if(l<=n)
        {
            if(l!=i)
            {
                for(int j=c;j<=n;++j)
                    swap(a[l][j],a[i][j]);
            }
            for(int j=c+1;j<=n;++j)
            {
                a[i][j]/=a[i][c];
            }
            a[i][c]=1;
            for(int l=i+1;l<=n;++l)
            {
                for(int j=c+1;j<=n;++j)
                {
                    a[l][j]-=a[l][c]*a[i][j];
                }
                a[l][c]=0;
            }
        }
        ++c;
    }
    v[n]=1;
    for(int i=n-1;i>1;--i)
    {
        for(int j=2;j<=n;++j)
        {
            v[i]-=v[j]*a[i][j];
        }
    }
}
int main()
{
    int n,m;
    si>>n>>m;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            c[i][j]=-1;
    for(int i=0;i<m;++i)
    {
        int x,y,z;
        si>>x>>y>>z;
        if(c[x][y]==-1||c[x][y]>z)
        {
            c[x][y]=z;
            c[y][x]=z;
        }
        a[x][y]++;
        a[x][x]--;
        a[y][x]++;
        a[y][y]--;
        if(x==1)
            g.push_back(y);
        else
            if(y==1)
                g.push_back(x);
    }
    gauss(n);
    long double t=-1;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            if(c[i][j]!=-1&&fabs(v[i]-v[j])>EPS)
                if(t<-EPS||c[i][j]<fabs(v[i]-v[j])*t)
                    t=c[i][j]/fabs(v[i]-v[j]);

    long double ans=0;
    if(t>-10)
        for(int i=0;i<g.size();++i)
            ans+=t*v[g[i]];
    so<<fixed<<setprecision(3)<<ans;
    return 0;
}
