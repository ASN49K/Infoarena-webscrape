//ALEX ENACHE

#include <vector>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>

using namespace std;

const double PI = acos(-1);
const double eps = 1e-6;

inline long long lgput(long long a , long long b , long long mod) {
    long long ret = 1;
    while( b ){
        if(b & 1) ret = (ret * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }

    return (ret%mod);
}

inline long long inv(long long x , long long MOD) {
    return lgput(x, MOD - 2, MOD);
}

inline bool exist (double nr){
    return (nr < -eps) || (nr > eps);
}

inline bool gauss (int n , int m , vector < vector < double > > v , vector < double > &ans){

    //transformare matrice (zerouri sub diagonala principala)

    for (int j=1; j<=m; j++){
        int pnt = j;
        while (pnt <= n){
            if (exist(v[pnt][j])){
                swap(v[j] , v[pnt]);
                break;
            }
            pnt++;
        }

        for (int i=j+1; i<=n; i++){
            double cnst = v[i][j] / v[j][j];
            for (int k=j; k<=m+1; k++){
                v[i][k] -= v[j][k] * cnst;
            }
        }
    }

    //aflat raspuns

    for (int i=n; i>=1; i--){
        double sum = 0;
        for (int j=i+1; j<=m; j++){
            if (exist(v[i][j])){
                sum += v[i][j] * ans[j];
            }
        }
        if (i > m && exist(v[i][m+1])){
            return 0;
        }
        if (!exist(v[i][i]) && exist(v[i][m+1] - sum)){
            return 0;
        }
        ans[i] = (v[i][m+1] - sum) / v[i][i];
    }
    return 1;
}



//-------------------------------------------------------------------

//#include <iostream>
#include <fstream>
ifstream cin ("gauss.in");ofstream cout ("gauss.out");

int main() {

    //freopen("input", "r", stdin);freopen("output", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cout << setprecision(10) << fixed;
    mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
    srand(time(nullptr));

    int n , m;
    cin>>n>>m;

    vector < vector < double > > v(n+1);
    for (auto &x : v){
        x.resize(m+2);
    }

    vector < double > ans(m+1);

    for (int i=1; i<=n; i++){
        for (int j=1; j<=m+1; j++){
            int nr;
            cin>>nr;
            v[i][j] = nr;
        }
    }

    int ok = gauss (n , m , v , ans);

    if (!ok){
        cout<<"Imposibil";
        return 0;
    }

    for (int i=1; i<=m; i++){
        cout<<ans[i]<<" ";
    }

    return 0;
}