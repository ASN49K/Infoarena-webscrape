#include<fstream>
#include<iomanip>
using namespace std;
ifstream in ("gauss.in");
ofstream out ("gauss.out");
const double epsilon = 0.0000001;
double mat[305][305],x[305];
int n,m,i,j,h,k,l,u;
int main (void) {
    in >> n >> m;
    for (i = 1; i <= n; i ++) {
        for (j = 1; j <= m+1; j ++) {
            in >> mat[i][j];
        }
    }
    i = 1; j = 1;
    while (i <= n && j <= m) {
        for (h = i; h <= n; h ++) {
            if (mat[h][j] < -epsilon || mat[h][j] > epsilon) {
                break;
            }
        }
        if (h == n+1) {
            j++;
            continue;
        }
        if (h != i) {
            for (int k = 1; k <= m+1; k ++) {
                swap (mat[h][k], mat[i][k]);
            }
        }
        for (h = j+1; h <= m+1; h ++) {
            mat[i][h] /= mat[i][j];
        }
        mat[i][j] = 1;
        for ( h = i+1; h <= n; h ++) {
            for (k = j + 1; k <= m+1; k ++) {
                mat[h][k] -= mat[h][j] * mat[i][k];
            }
            mat[h][j] = 0;
        }
        i++; j ++;
    }
    for (i = n; i >= 1; i --) {
        for (j = 1; j <= m + 1; j ++) {
            if (mat[i][j] > epsilon || mat[i][j] < -epsilon) {
                break;
            }
        }
        if (j == m + 2)
            continue;
        if (j == m + 1) {
            out <<"Imposibil";
            return 0;
        }
        x[j] = mat[i][m+1];
        for (h = j + 1; h <= m; h ++) {
            x[j] -= x[h] * mat[i][h];
        }

    }
    for (int i = 1; i <= m; i ++) {
        out <<setprecision(8) << fixed << x[i] << " ";
    }
    return 0;
}
