#include <bits/stdc++.h>
#define epsilon 0.0000000001

using namespace std;

int main()
{
    ifstream f("gauss.in");
    ofstream g("gauss.out");
    double a[302][302]={0};
    int n, m, i, j, k, x, c;
    double sol[302]={0};
    f >> n >> m;
    for(i=1; i<=n; i++)
        for(j=1; j<=m+1; j++)
            f >> a[i][j];
    for(i=1, j=1; i<=n && j<=m;){
        for(k=i; k<=n; k++)
            if(fabs(a[k][j]) > epsilon)
                break;
        if(k>n){
            j++; continue;
        }
        if(k!=i)
            for(c=1; c<=m+1; c++)
                swap(a[i][c], a[k][c]);
        for(c=j+1; c<=m+1; c++)
            a[i][c] /= a[i][j];
        a[i][j] = 1;
        for(c=i+1; c<=n; c++){
            for(int t=j+1; t<=m+1; t++)
                a[c][t] -= (a[c][j]*a[i][t]);
            a[c][j] = 0;
        }
        i++;
        j++;
    }
    for(i=n; i>0; i--)
        for(j=1; j<=m+1; j++)
            if(fabs(a[i][j]) > epsilon){
                if(j > m){
                    g << "Imposibli\n";
                    return 0;
                }
                sol[j] = a[i][m+1];
                for(c=j+1; c<=m; c++)
                    sol[j] -= (sol[c]*a[i][c]);
                break;
            }
    g << std::setprecision(10);
    for(i=1; i<=m; i++)
        g << sol[i] << " ";
    g << "\n";
}
