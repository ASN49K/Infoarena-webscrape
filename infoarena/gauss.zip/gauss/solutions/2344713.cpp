#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

double A[301][301];
double sol[301];

#define err 0.0001

float eq (float a, float b)
{
    if ( fabs(a-b)<=err )
    {
        return 1; //egale
    }
    return 0; //diferite
}

int main()
{
    freopen ("gauss.in","r",stdin);
    freopen ("gauss.out","w",stdout);

    int N,M,i,j,k,q,aux;

    scanf ("%d %d",&N,&M);

    for ( i=1; i<=N; i++ )
    {
        for ( j=1; j<=M+1; j++ )
        {
            scanf ("%lf",&A[i][j]);
        }
    }

    i=1;
    j=1;

    float elem;
    int swap=0;

    while ( i<=N && j<=M && eq(A[N][M],0)==0 )
    {
        swap=0;

        if ( eq(A[i][j],0)==1 )
        {
            for ( k=i+1; k<=N; k++ )
            {
                if ( eq(A[k][j],0)==1 )
                {
                    for ( q=j; q<=M+1; q++ )
                    {
                        aux=A[i][q];
                        A[i][q]=A[k][q];
                        A[k][q]=aux;
                    }
                    swap=1;
                }
            }

            if ( swap==0 )
            {
                while ( eq(A[i][j],0)==1 )
                {
                    j++;
                }
            }
        }

        elem=A[i][j];

        for ( k=1; k<=M+1; k++ )
        {
            A[i][k]/=elem;
        }

        for ( k=i+1; k<=N; k++ )
        {
            elem=A[k][j];

            for ( q=j; q<=M+1; q++ )
            {
                A[k][q]-=elem*A[i][q];
            }
        }

        /*for ( int a=1; a<=N; a++ )
        {
            for ( int b=1; b<=M+1; b++ )
            {
                printf ("%.10lf ",A[a][b]);
            }
            printf ("\n");
        }
        printf ("\n%d %d\n",i,j);*/

        i++;
        j++;
    }

    /*for ( i=1; i<=N; i++ )
    {
        for ( j=1; j<=M+1; j++ )
        {
            printf ("%.10lf ",A[i][j]);
        }
        printf ("\n");
    }
    printf ("\n");*/

    swap=0;

    for ( j=1; j<=M; j++ )
    {
        if ( eq(A[N][j],0)==0 )
        {
            swap=1;
        }
    }

    if ( swap==0 && eq(A[N][M+1],0)==0 )
    {
        printf ("Imposibil\n");
        return 0;
    }

    for ( i=N; i>=1; i-- )
    {
        j=1;

        while ( eq(A[i][j],0)==1 )
        {
            j++;
        }

        sol[j]=A[i][M+1];

        for ( k=M; k>=j+1; k-- )
        {
            sol[j]-=sol[k]*A[i][k];
        }
    }

    for ( i=1; i<=M; i++ )
    {
        printf ("%.10lf ",sol[i]);
    }

    printf ("\n");

    return 0;
}
