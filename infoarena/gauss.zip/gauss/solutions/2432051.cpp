#include <fstream>
#include <iomanip>
#define DIM 310
#define EPS 0.000000001
using namespace std;

ifstream fin ("gauss.in");
ofstream fout ("gauss.out");
double a[DIM][DIM],sol[DIM];
int n,m,i,j,k,t,ok,l;
inline int f(double x){
    if (x < -EPS || x > EPS) /// inseamna ca e diferit de 0
        return 0;
    return 1;
}
int main (){

    fin>>n>>m;
    for (i=1;i<=n;i++)
        for (j=1;j<=m+1;j++)
            fin>>a[i][j];
    i = j = 1;
    while (i <= n && j <= m){
        int l = i;
        while (l <= n && a[l][j] == 0)
            l++;
        if (l == n+1){ /// toti coeficientii sunt 0
            j++; /// trebuie sa ma mut cu coloana
            continue;
        }
        if (l != i) /// acum trebuie sa interschimb cele doua linii
            for (k=1;k<=m+1;k++)
                swap (a[i][k],a[l][k]);
        /// impart ecuatia prin coeficientul curent la care sunt
        for (k=j+1;k<=m+1;k++)
            a[i][k] /= a[i][j];
        a[i][j] = 1;

        for (k=i+1;k<=n;k++){
            for (t=j+1;t<=m+1;t++)
                a[k][t] = a[k][t] - a[i][t]*a[k][j];
            a[k][j] = 0; /// coeficientul devine 0
        }
        i++, j++;
    }

    for (i=n;i;i--){
        j = 1;
        while (j <= m+1 && f(a[i][j]))
            j++;
        if (j == m+1){
            /// inseamnca ca primul numar dif de 0 e coef liber, deci nu am solutie
            ok = 1;
            continue;
        }
        if (j == m+2) /// toate 0
            continue;
        sol[j] = a[i][m+1];
        for (k=j+1;k<=m+1;k++)
            sol[j] -= sol[k]*a[i][k];
    }
    if (ok){
        fout<<"Imposibil";
        return 0;
    }
    for (i=1;i<=m;i++)
        fout<<setprecision(8)<<fixed<<sol[i]<<" ";

    return 0;
}
