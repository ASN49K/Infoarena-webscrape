#include <bits/stdc++.h>
using namespace std;

fstream in ( "gauss.in" , ios::in  );
fstream out( "gauss.out", ios::out );

const int DIM = 3e2 + 5;
const double EPS = 1e-7;

double sys[DIM][DIM], ans[DIM];

inline int sign( double x ) {
    if( -EPS < x && x < EPS )
        return 0;
    else
        return ( x < 0 ) ? -1 : 1;
}

int main( void ) {
    
    int n, m;
    in >> n >> m;
    
    for( int i = 1; i <= n; i ++ )
        for( int j = 1; j <= m + 1; j ++ )
            in >> sys[i][j];
    
    for( int i = 1, j = 1; i <= n && j <= m; ) {
        bool ok = false;
        
        for( int k = i; k <= n; k ++ ) {
            if( sign( sys[k][j] ) != 0 ) {
                ok = true;
            
                for( int p = j; p <= m + 1; p ++ )
                    swap( sys[i][p], sys[k][p] );
            }
        }
        
        if( ok == false )
            j ++;
        else {
            for( int p = j + 1; p <= m + 1; p ++ )
                sys[i][p] /= sys[i][j];
            sys[i][j] = 1;
            
            for( int k = i + 1; k <= n; k ++ ) {
                double aux = sys[k][j] / sys[i][j];
                
                for( int p = j + 1; p <= m + 1; p ++ )
                    sys[k][p] -= sys[i][p] * aux;
                sys[k][j] = 0;
            }
            
            i ++; j ++;
        }
    }
    
    bool ok = true;
    for( int i = n, p = 1; i >= 1 && ok == true; i --, p = 1 ) {
        while( p <= m + 1 && sign( sys[i][p] ) == 0 )
            p ++;
        
        if( p == m + 2 )
            continue;
        
        if( p == m + 1 )
            ok = false;
        else {
            ans[p] = sys[i][m + 1];
            
            for( int j = p + 1; j <= m; j ++ )
                ans[p] -= ans[j] * sys[i][j];
        }
    }
    
    if( ok == false )
        out << "Imposibil\n";
    else {
        for( int i = 1; i <= m; i ++ )
            out << setprecision( 10 ) << fixed << ans[i] << " ";
    }
        
    return 0;
}
