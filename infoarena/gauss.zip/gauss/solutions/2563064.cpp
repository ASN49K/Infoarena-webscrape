#include <fstream>
#include <algorithm>
#include <iomanip>

using namespace std;

const int NMAX = 305;
const double EPS = 1e-12;
const double INF = 1.0 * 1e10;

ifstream cin("gauss.in");
ofstream cout("gauss.out");

double a[NMAX][NMAX];
double ans[NMAX];

bool IsZero(double a)
{
    if(a <= EPS && a >= -EPS)
        return 1;
    else
        return 0;
}

void SwapLines(int x, int y, int m)
{
    for(int i = 1; i <= m; ++i) {
        swap(a[x][i], a[y][i]);
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    m++;
    for(int i = 1; i <= n; ++i) {
        for(int j = 1; j <= m; ++j) {
            cin >> a[i][j];
        }
    }
    if(n >= m)
        n = m - 1;
    for(int i = 1; i <= m; ++i)
        ans[i] = INF;
    for(int c = 1; c < m; ++c) {
        bool dist = 0;
        for(int l = c; l <= n; ++l) {
            if(!IsZero(a[l][c])) {
                dist = 1;
                double rad1 = a[l][c];
                for(int cc = 1; cc <= m; ++cc) {
                    a[l][cc] = a[l][cc] / rad1;
                }
                for(int ll = 1; ll <= n; ++ll) {
                    double rad2 = a[ll][c];
                    for(int cc = c; cc <= m; ++cc) {
                        if(ll != l) {
                            a[ll][cc] = a[ll][cc] - rad2 * a[l][cc];
                            if(IsZero(a[ll][cc]))
                                a[ll][cc] = 0.0;
                        }
                    }
                }
                SwapLines(l, c, m);
                break;
            } else {
                a[l][c] = 0.0;
            }
        }
        if(dist == 0)
            ans[c] = 0.0;
/*        for(int i = 1; i <= n; ++i) {
            for (int j = 1; j <= m; ++j) {
                cout << fixed << setprecision(6) << a[i][j] << " ";
            }
            cout << "\n";
        }
        cout << "\n";*/
    }
    for(int i = n + 1; i < m; ++i) {
        ans[i] = 0;
    }
    for(int l = 1; l <= n; ++l) {
        int cnt = 0;
        for(int c = 1; c <= n; ++c) {
            if(IsZero(a[l][c] - 1)) {
                cnt++;
                ans[c] = a[l][m];
                if(cnt > 1) {
                    cout << "Imposibil\n";
                    return 0;
                }
            } else {
                if(!IsZero(a[l][c])) {
                    cout << "Imposibil\n";
                    return 0;
                }
            }
        }
    }
    for(int i = 1; i < m; ++i) {
        cout << fixed << setprecision(8) << ans[i] << " ";
    }
    return 0;
}