
#include <bits/stdc++.h>
using namespace std;
int piv[303],n,m,i,k,j;
double a[303][303],sol[303],r, EPS=0.000000001,pp;
double modul(double x)
{
    if(x<0)return -x;
    return x;
}
int main()
{
    freopen("gauss.in","r",stdin);
    freopen("gauss.out","w",stdout);
    scanf("%d%d",&m,&n);
    for(i=1;i<=m;i++)
        for(j=1;j<=n+1;j++)
            scanf("%lf",&a[i][j]);
    for(i=1;i<=m;i++)
    {
        piv[i]=0;
        for(j=1;j<=n+1;j++)
        {
            if(modul(a[i][j])>EPS)
            {
                piv[i]=j;
                break;
            }
        }
        if(piv[i]==n+1)
        {
            printf("Imposibil\n");
            return 0;
        }
        if(piv[i]==0)continue;

            for(j=1;j<=m;j++)
            {
                if(j!=i&&modul(a[j][piv[i]])>EPS)
                {
                    r=(double)a[j][piv[i]]/a[i][piv[i]];
                    for(k=1;k<=n+1;k++)
                        a[j][k]=(double)a[j][k]-a[i][k]*r;
                }
            }

    }
    for(i=1;i<=m;i++)
    {
        if(piv[i])
            sol[piv[i]]=(double)a[i][n+1]/a[i][piv[i]];
    }
    for(i=1;i<=n;i++)
    {
        printf("%.10lf ",sol[i]);
    }
    return 0;
}
