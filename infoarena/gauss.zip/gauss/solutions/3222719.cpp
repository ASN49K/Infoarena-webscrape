#include <bits/stdc++.h>
std::ifstream cin("gauss.in");
std::ofstream cout("gauss.out");
long long n,m,ac;
double a[310][310],v[310];
bool e[310];
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=m+1;++j)
            cin>>a[i][j];
    ac=1;
    for(int va=1;va<=m;++va)
    {
        long long poz=ac;
        for(int i=ac+1;i<=n;++i)
            if(abs(a[i][va])>abs(a[i][poz]))
                poz=i;
        if(a[poz][va]==0)
        {
            e[va]=true;
            continue;
        }
        for(int i=1;i<=m+1;++i)
            std::swap(a[poz][i],a[ac][i]);
        double val=a[ac][va];
        for(int i=1;i<=m+1;++i)
            a[ac][i]/=val;
        for(int i=1;i<=n;++i)
        {
            if(i==ac||a[i][va]==0)
                continue;
            val=a[i][va];
            for(int j=1;j<=m+1;++j)
                a[i][j]-=val*a[ac][j];
        }
        ++ac;
    }
    for(int i=ac-1;i>=1;--i)
    {
        bool ok=false;
        for(int j=m;j>=1;--j)
        {
            if(e[j])
                a[i][m+1]-=v[j]*a[i][j];
            else if(a[i][j])
            {
                if(ok==false)
                {
                    e[j]=true;
                    v[j]=a[i][m+1]/a[i][j];
                    a[i][m+1]=0;
                    ok=true;
                }
                else
                    e[j]=true;
            }
        }
        if(abs(a[i][m+1])>0.000000001)
        {
            cout<<"Imposibil\n";
            return 0;
        }
    }
    for(int i=ac;i<=n;++i)
    {
        for(int j=1;j<=m;++j)
            a[i][m+1]-=a[i][j]*v[j];
        if(abs(a[i][m+1])>0.000000001)
        {
            cout<<"Imposibil\n";
            return 0;
        }
    }
    for(int i=1;i<=m;++i)
        cout<<std::fixed<<std::setprecision(10)<<v[i]<<' ';
    return 0;
}
