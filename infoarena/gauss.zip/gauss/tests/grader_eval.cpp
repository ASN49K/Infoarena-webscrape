#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

#define maxn 310
#define eps 0.001
#define fscore 5

int n, m, ok, GMax, NMin;
double x[maxn];
int c[maxn][maxn];
char s[maxn*maxn];

void error(char msg[], int p)
{
	fprintf(stderr, msg);
	printf("%d", p);
	exit(0);
}

void bun(double er, int p)
{
    fprintf(stderr, "OK, eroare maxima %.9lf\n", er);
    printf("%d", p);
    exit(0);
}

int main(void)
{
    FILE *f;

    f = fopen("gauss.in", "r");
    if(!f)
        error("Fisier de intrare lipsa!", 0);

    if(fscanf(f, "%d%d", &n, &m) != 2)
        error("Eroare in fisierul de intrare!", 0);

    for(int i=1; i<=n; i++)
        for(int j=1; j<=m+1; ++j)
            if(fscanf(f, "%d", &c[i][j]) != 1)
                error("Eroare in fisierul de intrare!", 0);

    fclose(f);

    f = fopen("gauss.ok", "r");
    if(!f)
        error("Fisier ok lipsa!", 0);
    if(fscanf(f, "%d", &ok)!=1)
        error("Fisier de iesire corupt!", 0);
    fclose(f);


    f = fopen("gauss.out", "r");
    if(!f)
        error("Fisier de iesire lipsa!", 0);

    fgets(s, maxn*maxn, f);

    if(ok==1)
    {
        if(s[0]=='I' && s[1]=='m' && s[2]=='p' && s[3]=='o' && s[4]=='s' && s[5]=='i' && s[6]=='b' && s[7]=='i' && s[8]=='l')
            error("Exista solutie", 0);
    }

    if(ok==0)
    {
        if(!(s[0]=='I' && s[1]=='m' && s[2]=='p' && s[3]=='o' && s[4]=='s' && s[5]=='i' && s[6]=='b' && s[7]=='i' && s[8]=='l'))
            error("Nu exista solutie", 0);
    }

    if(!ok)
        bun(0, fscore);

    fclose(f);

    f=fopen("gauss.out", "r");

    for(int i=1; i<=m; ++i)
        if(fscanf(f, "%lf", &x[i])!=1)
            error("Nu au fost afisate toate necunoscutele!", 0);

    double sol=0, erm=0;

    for(int i=1; i<=n; ++i)
    {
        sol=0;
        for(int j=1; j<=m; ++j)
            sol=sol+c[i][j]*x[j];

        if(sol-c[i][m+1]<-eps || sol-c[i][m+1]>eps)
            error("Raspuns gresit!", 0);

        erm=max(erm, max(sol-c[i][m+1], c[i][m+1]-sol));
    }

    bun(erm, fscore);

    return 0;
}
