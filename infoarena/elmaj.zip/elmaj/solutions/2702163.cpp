#include <bits/stdc++.h>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n, v[1000009], r, e, t;
int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
        if (v[i] == r)
            e++;
        else
            e--;
        if (e < 0)
            r = v[i], e = 1;
    }
    for (int i = 1; i <= n; i++)
        t += (v[i] == r);
    if (t > n / 2)
        g << r << " " << t;
    else
        g << -1;
    return 0;
}
