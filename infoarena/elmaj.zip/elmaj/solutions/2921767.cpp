#include <fstream>
#include <iostream>
#include <map>
#include <algorithm>
using namespace std;
 
 
int main(){
	ifstream fin;
	ofstream fout;
	fin.open("elmaj.in");
	fout.open("elmaj.out"); 
	int n, x;
 	fin >> n;
 	map<int, int> data;
	for(int i = 1; i <= n; ++i){
		fin >> x;
		data[x]++;
	}

	map<int,int>::iterator best = max_element(
		data.begin(), 
		data.end(), 
		[] (const std::pair<int,int>& a, const std::pair<int,int>& b)->bool{ return a.second < b.second; });


	if(best->second >= n/2 + 1)
		fout << best->first << " " << best->second;
	else
		fout << -1;
}