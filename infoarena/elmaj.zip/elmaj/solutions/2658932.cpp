#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n, x[1000005];

int main(){
    f  >> n;
    for(int i = 0 ; i < n ; ++ i)
        f >> x[i];
    int candidat = x[0], contor = 1;
    for(int  i = 1; i < n ; ++i)
    {
        if(contor == 0)
            candidat = x[i], contor = 1;
        if(x[i] == candidat)
            contor++;
        else
            contor--;
    }
    contor = 0;
    for(int i = 0 ; i < n ; ++ i)
        if(x[i] == candidat)
            contor ++;
    if(contor > n-contor)
        g<<candidat<<" "<<contor;
    else
        g<<"-1";

    return 0;
}
