#include <iostream>
#include <fstream>
#define FIN "elmaj.in"
#define FOUT "elmaj.out"
#define MAXN 1000001

using namespace std;

int n, vec[ MAXN ],
       contor[ MAXN ];

void read();
void solve();

int main(int argc, char const *argv[]) {

  read();
  solve();

  return 0;
};

void read() {

     ifstream i( FIN );

     i>>n;

     for(int j = 1; j <= n; j++) i>>vec[j];
}


void solve() {

    ofstream o( FOUT );

    int i,

        major_element,

        found = 0;

    for(int i = 1; i <= n; ++i) {

        contor[ vec[ i ] ]++;
    }

    major_element = n / 2 + 1;

    for(i = 1; i <= n; ++i) {

        if(contor[vec[i]] >= major_element) {

            o<<vec[i]<<" "<<contor[vec[i]], found = 1, contor[vec[i]] = -10;
        }
    }

    if(!found) o<<-1;
}
