#include <bits/stdc++.h>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    in>>n;
    vector <int> a(n+1);
    for(int i=1;i<=n;i++)
    {
        in>>a[i];
    }
    int emaj=a[1],femaj=0;
    int s=0;
    for(int i=1;i<=n;i++)
    {
        s++;
        if(emaj==a[i])
        {
            femaj++;
        }
        if(femaj<s/2+1)
        {
            emaj=a[i+1];
            femaj=0;
            s=0;
        }
    }
    femaj=0;
    for(int i=1;i<=n;i++)
    {
        if(a[i]==emaj)
        {
            femaj++;
        }
    }
    if(femaj<n/2+1)
    {
        out<<-1;
    }
    else
    {
        out<<emaj<<" "<<femaj;
    }
    return 0;
}
