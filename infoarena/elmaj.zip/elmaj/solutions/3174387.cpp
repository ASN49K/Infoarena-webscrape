#include <bits/stdc++.h>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int v[1000005];

int main()
{
    int n;
    fin >> n;
    for (int i=1;i<=n;++i){
        fin >> v[i];
    }
    int x = v[1], y = 1;
    for (int i=2;i<=n;++i){
        if (y<=0) break;
        if (x==v[i]){
            y++;
        }else{
            y = 1;
            x = v[i];
        }
    }
    int fr = 0;
    for (int i = 1;i<=n;++i){
        if (v[i]==x){
            fr++;
        }
    }
    if (fr>n/2){
        fout << x << ' ' << fr;
    }else{
        fout << -1;
    }
    return 0;
}
