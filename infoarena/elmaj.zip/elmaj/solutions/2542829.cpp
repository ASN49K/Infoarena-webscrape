using namespace std;



#define fisier "elmaj"

#ifdef fisier
    #include <fstream>
    ifstream in(fisier ".in");
    ofstream out(fisier ".out");
#else
    #include <iostream>
    #define in cin
    #define out cout
#endif



int istorie_gorile[1000000];

int main() {

    int
    n,
    gorila_defensiva,
    populatie = 0, max_populatie = 0,
    max_pop_tip_gorila;



    #define gorila_atac istorie_gorile[i]

    in >> n;

    for (int i = 0; i < n; i++) {

        in >> gorila_atac;



        if (!populatie) {

            populatie = 1;
            gorila_defensiva = gorila_atac;

        } else {

            if (gorila_atac == gorila_defensiva) {

                populatie++;

            } else {

                populatie--;

            }

        }



        if (populatie > max_populatie) {

            max_populatie = populatie;

            max_pop_tip_gorila = gorila_defensiva;

        }

    }



    #define max_gorile max_populatie
    max_gorile = 0;

    for (int i = 0; i < n; i++) {

        if (istorie_gorile[i] == max_pop_tip_gorila) {

            max_gorile++;

        }

    }



    if (max_gorile < n/2 + 1) {

        out << -1;

    } else {

        out << max_pop_tip_gorila << ' ' << max_gorile;

    }

}









//
