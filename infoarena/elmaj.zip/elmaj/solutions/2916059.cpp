#include<bits/stdc++.h>
using namespace std;

class input {
private:
    FILE* fin;
    char* t;
    int sp;
    const int sz = 10000;

    char read()
    {
        if (sp == sz)
        {
            fread(t, 1, sz, fin);
            sp = 0;
            return t[sp++];
        }
        else
            return t[sp++];
    }
public:
    input(const char* name)
    {
        fin = fopen(name, "r");
        sp = sz;
        t = new char[sz]();
    }

    void close()
    {
        fclose(fin);
    }

    void open(const char* name)
    {
        fin = fopen(name, "r");
        sp = sz;
        t = new char[sz]();
    }

    input& operator >> (int& n)
    {
        char c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;

        int sng = 1;

        if (c == '-')
            sng = -1, c = read();

        while (c != '\0' && isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        n *= sng;

        return *this;
    }

    input& operator >> (char& s)
    {
        char c = read();

        while (c != '\0' && c == '\n')
            c = read();

        s = c;

        return *this;
    }

    input& operator >> (long long& n)
    {
        char c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;

        int sng = 1;

        if (c == '-')
            sng = -1, c = read();

        while (c != '\0' && isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        n *= sng;

        return *this;
    }

    void getline(string& s)
    {
        char c = read();
        s = "";

        while (c != '\0' && c != '\n')
            s += c, c = read();
    }

    input& operator >> (string& s)
    {
        char c;
        c = read();
        s = "";

        while (c == '\n' || c == ' ')
            c = read();

        while (c != '\n' && c != '\0' && c != ' ')
            s += c, c = read();

        return *this;
    }

    input& operator >> (char* s)
    {
        char c;
        c = read();
        int i = 0;

        while (c == '\n' || c == ' ')
            c = read();

        while (c != '\n' && c != '\0' && c != ' ')
            s[i++] = c, c = read();

        return *this;
    }
};
class output {
private:
    FILE* fout;
    char* t;
    int sp;
    const int sz = 10000;

    void write(char c)
    {
        if (sp == sz)
        {
            fwrite(t, 1, sz, fout);
            sp = 0;
            t[sp++] = c;
        }
        else
            t[sp++] = c;
    }

public:
    output(const char* name)
    {
        fout = fopen(name, "w");
        sp = 0;
        t = new char[sz]();
    }

    ~output()
    {
        fwrite(t, 1, sp, fout);
    }

    output& operator << (int n)
    {
        if (n < 0)
        {
            write('-');
            n *= -1;
        }
        if (n <= 9)
            write(char(n + '0'));
        else
        {
            (*this) << (n / 10);
            write(char(n % 10 + '0'));
        }

        return *this;
    }

    output& operator << (char c)
    {
        write(c);

        return *this;
    }

    output& operator << (const char* s)
    {
        int i = 0;

        while (s[i] != '\0')
            write(s[i++]);

        return *this;
    }

    output& operator << (long long n)
    {
        if (n < 0)
        {
            write('-');
            n *= -1;
        }
        if (n < 10)
            write(char(n + '0'));
        else
        {
            (*this) << (n / 10);
            write(char(n % 10 + '0'));
        }

        return *this;
    }

    output& operator << (string s)
    {
        for (auto i : s)
            write(i);

        return *this;
    }

    void precizion(double x, int nr)
    {
        int p = int(floor(x));

        *this << p;

        if (nr == 0)
            return;

        write('.');

        for (int i = 1; i <= nr; i++)
        {
            x -= floor(x);
            x *= 10;

            write(int(x) + '0');
        }
    }
};

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main()
{
    int n, el, nr = 0;
    fin >> n;

    int x;
    fin >> x;
    nr = 1;
    el = x;

    for (int i = 2; i <= n; i++)
    {
        fin >> x;
        if (x == el)
            nr++;
        else
        {
            nr--;
            if (!nr)
                nr = 1, el = x;
        }
    }

    fin.close();
    fin.open("elmaj.in");

    fin >> n;

    nr = 0;


    for (int i = 1; i <= n; i++)
    {
        fin >> x;
        if (x == el)
            nr++;
    }

    fout << el << ' ' << nr;

    return 0;
}