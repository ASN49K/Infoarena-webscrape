#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int x, n, i, k, maj, cnt, v[1000001];
int main()
{
    fin >> n;
    maj = n/2+1;
    for (i = 1; i <= n; i++)
        fin >> v[i];
    sort(v, v+n+1);
    for (i = 1; i <= n; i++)
    {
        if (v[i] == v[(n+1)/2])
            cnt++;
    }
    if (cnt >= maj)
        fout << v[(n+1)/2] << " " << cnt;
    else fout << -1;
    return 0;
}
