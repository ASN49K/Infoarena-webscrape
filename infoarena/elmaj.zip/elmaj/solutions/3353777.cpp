#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int arr[1000001];

int main() {
	int n;
	fin >> n;
	int majorityElement = -1, majorityElementFr = 0;
	for (int i = 1; i <= n; ++i) {
		fin >> arr[i];
		if (majorityElementFr == 0) {
			majorityElement = arr[i];
			majorityElementFr = 1;
		}
		else if (arr[i] != majorityElement) {
			--majorityElementFr;
		}
		else {
			++majorityElementFr;
		}
	}
	majorityElementFr = 0;
	for (int i = 1; i <= n; ++i) {
		if (arr[i] == majorityElement) {
			++majorityElementFr;
		}
	}
	if (majorityElementFr >= n / 2 + 1) {
		fout << majorityElement << ' ' << majorityElementFr;
	}
	else {
		fout << -1;
	}
	return 0;
}