#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

vector <int> v;

int main()
{
    int n, x;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>x;
        v.push_back(x);
    }
    int nr=1; int k=0, mij;

    sort(v.begin(), v.end());

    mij=(v.size()-1)/2;

    k=v[mij];
    while(v[mij-1] == v[mij])
        {
            mij--;
            nr++;
        }
    mij=(v.size()-1)/2;
    while(v[mij+1] == v[mij])
        {
            mij++;
            nr++;
        }

    if(nr == n/2+1)
        fout<<k<<" "<<nr;
    else
        fout<<-1;
    return 0;
}
