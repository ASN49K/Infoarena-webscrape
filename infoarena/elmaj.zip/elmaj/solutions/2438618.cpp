#include <iostream>
#include <fstream>
#include <algorithm>
std::ifstream fin("elmaj.in");
std::ofstream fout("elmaj.out");
int n,c,k;
int v[1005000];
 
int main()
{
  fin>>n;
  for(int i=0;i<n;i++)
  {
    fin>>v[i];
    if(k==0)
    {
      c=v[i];
      k++;
    }
    else if(v[i]==c)
      k++;
    else
      k--;
  }
  if(k==0)
  {
    fout<<-1;
    return 0;
  }
  k=0;
  for(int j=0;j<n;j++)
    if(v[j]==c)
      k++;
  if(k>=n/2+1)
    fout<<c<<" "<<k;
  else
    fout<<-1;
}
