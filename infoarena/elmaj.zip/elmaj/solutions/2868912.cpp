#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[1000005];
int n;

int main()
{
    int cnt=0,em;
    fin>>n;
    fin>>a[1];
    em=a[1];
    cnt=1;
    for(int i=2;i<=n;i++)
    {
        fin>>a[i];
        if(a[i]==em) cnt++;
        else cnt--;
        if(cnt==0)
        {
            em=a[i];
            cnt=1;
        }
    }
    cnt=0;
    for(int i=1;i<=n;i++)
        if(a[i]==em) cnt++;
    if(cnt>n/2) fout<<em<<" "<<cnt<<"\n";
    else fout<<"-1\n";
    return 0;
}
