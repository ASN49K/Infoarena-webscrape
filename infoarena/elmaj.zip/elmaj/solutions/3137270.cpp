#include <bits/stdc++.h>
#define DIM 1000001

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

unordered_map <int, int> mp;
unordered_map <int, int> :: iterator it;

int v[DIM];

int n, i;

int main(){

    ios :: sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);

    fin >> n;

    for(i=1;i<=n;i++){
        fin >> v[i];
        mp[v[i]]++;
    }

    for(it = mp.begin() ; it != mp.end() ; it++)
        if(it -> second >= n / 2 + 1){
            fout << it -> first << " " << it -> second << "\n";
            return 0;
        }

    fout << -1;

    fin.close();
    fout.close();
    return 0;
}
