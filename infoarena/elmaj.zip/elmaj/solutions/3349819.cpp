#include <iostream>
#include <vector>
#include <utility>
#include <math.h>
#include <random>
#include <unordered_set>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }

    unordered_set<int> vizitat;
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(0, n - 1);
    for (int i = 0; i < 30; i++) {
        int index = dist(gen);
        if (vizitat.contains(v[index]))
            continue;
        vizitat.insert(v[index]);
        int cnt = 0;
        for (int j = 0; j < n; j++) {
            if (v[j] == v[index])
                cnt++;
        }
        if (cnt >= n/2 + 1) {
            cout << v[index] << " ";
            cout << cnt << endl;
            break;
        }
    }
}