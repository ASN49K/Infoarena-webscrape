#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,v[1000005],i,el,cnt;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>v[i];
        if(!cnt){
            el = v[i];
            cnt = 1;
        }else if(el == v[i]){
            cnt++;
        }else{
            cnt--;
        }
    }
    cnt = 0;
    for(i=1;i<=n;i++){
        if(el == v[i]){
            cnt++;
        }
    }
    if(cnt > n/2){
        fout<<el<<' '<<cnt;
    }else{
        fout<<-1;
    }
    return 0;
}
