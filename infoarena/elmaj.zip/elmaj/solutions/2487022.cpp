#include <bits/stdc++.h>
#define Nmax 100005

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000005];

int main()
{
    int n,i,cand = -1,k = 0;
    int nrcand = 0;
    fin>>n;
    for(i = 1; i <= n; i++){
        fin>>v[i];
        if(k == 0){
            cand = v[i];
            k = 1;
        }else{
            if(v[i] == cand){
                k++;
            }else{
                k--;
            }
        }
    }
    if(cand < 0){
        fout<<cand<<'\n';
    }
    for(i = 1; i <= n; i++){
        if(v[i] == cand){
            nrcand++;
        }
    }
    if(nrcand > n/2){
        fout<<cand<<" "<<nrcand<<'\n';
    }else{
        fout<<"-1"<<'\n';
    }
    return 0;
}
