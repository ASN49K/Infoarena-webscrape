#include <stdio.h>
#include <stdlib.h>

int v[1000000];

int main() {
    FILE *fin = fopen( "elmaj.in", "r" ), *fout = fopen( "elmaj.out", "w" );
    int n, i, majoritar, aparitii;
    fscanf( fin, "%d", &n );
    for ( i = 0; i < n; i ++ )
        fscanf( fin, "%d", &v[i] );
    aparitii = 1;
    majoritar = v[0];
    for ( i = 1; i < n; i ++ ) {
        if ( v[i] == majoritar )
            aparitii ++;
        else {
            aparitii --;
            if ( aparitii < 0 ) {
                majoritar = v[i];
                aparitii = 1;
            }
        }
    }
    aparitii = 0;
    for ( i = 0; i < n; i ++ )
        if ( v[i] == majoritar )
            aparitii ++;
    if ( aparitii >= n / 2 + 1 )
        fprintf( fout, "%d %d", majoritar, aparitii );
    else
        fprintf( fout, "-1" );
    return 0;
}
