#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
vector<vector<int>> v(100100);
int w[100100];
int d[100100];
int n,m,s;
int num=0;
long long M;
void BFS(int a){
    queue<int> q;
    q.push(a);
    w[a]=1;
    d[a]=0;
    while(!q.empty()){
    int r=q.front();
        q.pop();
    for(auto e : v[r]){
        if(!w[e]){
        w[e]=1;
        d[e]=d[r]+1;
        q.push(e);
        }
    }
    //w[r]=1;
    }

}
void DFS(int a){
    w[a]=1;
    for(auto e : v[a]){
        if(!w[e]){
        DFS(e);
        }
    }
}
int main(){
    int a,b;
    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n;
    for(int i=1; i<=n; i++){
        fin>>a;
        w[a]++;
    }
    b=n/2+1;
    bool are=0;
    for(int i=1; i<=1000020; i++){
    if(w[i]>=b){
            are=1;
        fout<<i<<" "<<w[i];
        break;
    }
    }
    if(!are)
        fout<<-1;
    return 0;
}
