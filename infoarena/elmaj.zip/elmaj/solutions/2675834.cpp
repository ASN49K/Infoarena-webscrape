#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n;
int act,estimare,nr_aparitii_estimare;
int v[1000000];

int main()
{
    fin>>n;
    fin>>v[0];
    estimare=v[0];
    nr_aparitii_estimare=1;
    for(int i=1; i<n; i++)
    {
        fin>>v[i];
        act=v[i];
        if(act==estimare)
        {
            nr_aparitii_estimare++;
        }
        else
        {
            nr_aparitii_estimare--;
            if(nr_aparitii_estimare==0)
            {
                nr_aparitii_estimare=1;
                estimare=act;
            }
        }
    }
    nr_aparitii_estimare=0;
    cout<<estimare<<"\n";
    for(int i=0; i<n; i++)
    {
        if(estimare==v[i]) nr_aparitii_estimare++;
    }
    if(nr_aparitii_estimare>=n/2+1)
    {
        fout<<estimare<<" "<<nr_aparitii_estimare;
    }
    else fout<<"-1";
    return 0;
}
