#include <fstream>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[2000001];

int main()
{
    int n,i,elem,cnt,j;
    cin>>n;
    for(i=1;i<=n;i++) cin>>v[i];
    for(i=1;i<=10;i++){
        elem=v[(rand()*rand())%n+1];cnt=0;
        for(j=1;j<=n;j++){
            if(v[j]==elem){
                cnt++;
            }
        }
        if(cnt>=n/2+1){
            cout<<elem<<" "<<cnt<<"\n";
            return 0;
        }
    }
    cout<<"-1";
    return 0;
}
