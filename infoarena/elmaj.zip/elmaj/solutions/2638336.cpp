#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000000];

int main() 
{
  int n;
  fin >> n;
  for(int i = 0; i < n; i++)
    fin >> v[i];

  int x = -1;
  int sum = 0;
  for(int i = 0; i < n;i ++)
  {
    if(sum == 0)
      x = v[i];
    else if(x == v[i])
      sum++;
    else sum--;    
  }  
  
  sum = 0;
  for(int i = 0; i < n; i++)
  {
    if(x == v[i])
      sum++;
  }

  if(sum >= n / 2 + 1)
    fout << x << ' ' << sum;
  else fout << -1;  
  
}