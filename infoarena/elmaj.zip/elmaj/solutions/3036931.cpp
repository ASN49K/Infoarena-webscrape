#include <bits/stdc++.h>
#include <ctime>
using namespace std;
int v[100000];
unordered_map<int, int> m;
int main()
{
    srand(time(0));
    int n;
    cin>>n;
    for (int i=0; i<n; i++)
        cin>>v[i], m[v[i]]++;
    for (int i = 0; i < 1; i++)
    {
        int j = rand() % n;
        if (m[v[j]] > n / 2)
        {
            cout << v[j] << m[v[j]];
            return 0;
        }
    }
    cout<<-1;

}
