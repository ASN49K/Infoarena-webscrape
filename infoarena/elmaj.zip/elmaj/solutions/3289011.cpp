#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <random>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n;
vector<int> v;
int nr_apps;
bool check_majority(int el) {
    nr_apps = 0;
    for (int i = 0; i < n; i++) {
        if (nr_apps + n - i < n/2 + 1) {
            return false;
        }
        if (v[i] == el) {
            nr_apps++;
        }
    }
    if (nr_apps >= n/2 +1) {
        return true;
    }
    return false;
}
// TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
int main() {
    srand(time(NULL));
    fin >> n;
    v.resize(n);
    for (int i = 0; i < n; i++) {
        fin >> v[i];
    }
    int index = rand();
    index %= n;
    while (!check_majority(index)) {
        index = rand() % n;
    }
    fout << v[index] << " " << nr_apps;
}

// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.