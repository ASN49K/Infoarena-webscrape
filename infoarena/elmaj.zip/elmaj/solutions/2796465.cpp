#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n, a[1000001];
int dig[3][1000];
int main()
{   f>>n;
    for(int i=0; i<n; i++) f>>a[i];
    for (int i = 0; i < n; i++) {
        int tmp = a[i];
        for (int j = 0; j < 3; j++) {
            dig[j][tmp % 1000]++;
            tmp /= 1000;
        }
    }
    int ret = 0;
    for (int i = 0; i < 999; i++) {
        if (dig[0][i] > n/2)
            ret += i;
        if (dig[1][i] > n/2)
            ret += i * 1000;
        if (dig[2][i] > n/2)
            ret += i * 1000000;
     }
     int nr = 0;
     for (int i = 0; i < n; i++)
         if (a[i] == ret) nr++;
     if (nr > n/2) g<<ret<<' '<<nr; else g<<-1;
    g.close(); f.close(); return 0;
}
