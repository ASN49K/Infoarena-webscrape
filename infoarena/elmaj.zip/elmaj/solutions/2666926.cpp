#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

vector<int> V;

int main() {
    int N;
    fin >> N;
    for (int x, i = 0; i < N; ++i) {
        fin >> x;
        V.push_back(x);
    }

    sort(V.begin(), V.end());

    int candidat = V[N / 2];
    int counter = 0;

    for (int i = 0; i < N; ++i) {
        if (candidat == V[i]) {
            counter += 1;
        }
    }

    if (counter >= (N / 2 + 1)) {
        fout << candidat << ' ' << counter << '\n';
    } else {
        fout << -1 << '\n';
    }

    return 0;
}