#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

long long v[1000005];

int main() {
    int n;
    f>>n;
    for(int i = 1; i<=n; i++){
        f>>v[i];
    }
    sort(v+1,v+n+1);
    long long num = v[n/2], cont = 0;
    int start;
    for(int i = 1; i<=n; i++){
        if(v[i]==num){
            start = i;
            break;
        }
    }
    for(int i = start; i<=n && cont<=(n/2 + 1); i++){
        if(v[i]==num){
            cont++;
        }
    }
    if(cont >= (n/2 + 1)){
        g<<num<<" "<<cont;
    }
    else{
        g<<-1;
    }
    return 0;
}
