import random

random.seed(42) 

n = int(input())
list_of_numbers = [int(x) for x in input().split()]

for _ in range(20):
    mg = random.choice(list_of_numbers)
    if list_of_numbers.count(mg) > n // 2:
        print(mg)
        break

print(-1)