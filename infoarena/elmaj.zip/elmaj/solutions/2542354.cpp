#include <fstream>
using namespace std;
ifstream f("livada.in");
ofstream g("livada.out");
long long a[1000001],nr,i,j,p,n,Max,x;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>x;
        a[x]++;
        if(x>Max)
            Max=x;
    }
    for(i=1;i<=Max;i++)
        if(a[x]>n/2)
        {
            g<<x<<" "<<a[x];
            break;
        }
}
