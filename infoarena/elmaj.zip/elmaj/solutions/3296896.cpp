#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int N, v[1000005];
int main()
{
    fin >> N;
    for (int i = 1; i <= N; i++)
    {
        fin >> v[i];
    }
    int candidat = v[1];
    int freq = 1;
    for (int i = 2; i <= N; i++)
    {
        if (v[i] == candidat)
        {
            freq++;
        }
        else
        {
            freq--;
            if (freq == 0)
            {
                freq = 1;
                candidat = v[i];
            }
        }
    }
    // Daca am un element majoritar, asta o sa fie suta la suta candidatul meu
    freq = 0;
    for (int i = 1; i <= N; i++)
    {
        if (v[i] == candidat)
        {
            freq++;
        }
    }
    if (freq >= N / 2 + 1)
    {
        fout << candidat << " " << freq << '\n';
    }
    else
    {
        fout << -1 << '\n';
    }
}