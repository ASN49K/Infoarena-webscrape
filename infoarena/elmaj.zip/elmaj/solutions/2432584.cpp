#include <fstream>
#include <map>
#include <assert.h>

int main() {
	std::ifstream cin("elmaj.in");
	std::ofstream cout("elmaj.out");
	std::ios::sync_with_stdio(false);
	int n, x, max_element, current_max = 0;
	cin >> n;
	assert(1 <= n && n <= 1000000);
	std::map<int, int> v;
	
	for (; n ; --n) {
		cin >> x;
		++v[x]; 
	}

	for (auto it = v.begin() ; it != v.end() ; ++it) {
		if (it->second > current_max) {
			max_element = it->first;
			current_max = it->second;
		}
	}

	cout << max_element << " " << current_max << '\n';

	return 0;
}