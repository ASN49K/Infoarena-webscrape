#include <cstdio>

using namespace std;

int n, a[1000009];

int main()
{
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);

    scanf("%d", &n);

    int nr=0, el=-1;

    for(int i=1; i<=n; i++)
    {
        scanf("%d", &a[i]);
        if(el!=nr)
        {
            if(nr==0)
            {
                el=a[i];
                nr=1;
            }
            else nr--;
        }
        else nr++;
    }
    nr=0;
    for(int i=1; i<=n; i++)
        if(a[i]==el)
            nr++;

    if(nr>=(n/2)+1)
        printf("%d %d", el, nr);
    else printf("-1");

    return 0;
}
