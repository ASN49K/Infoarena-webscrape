#include<bits/stdc++.h>

std::ifstream fin("elmaj.in");
std::ofstream fout("elmaj.out");

std::unordered_map<int, int> ap;
    std::pair<int, int> sol;
int n, x;

int main(){
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> x;
        ++ap[x];
    }
    for(const auto& elem : ap)
        if(elem.second > sol.second)
            sol = elem;
    if(sol.second >= n / 2 + 1)
        fout << sol.first << ' ' << sol.second;
    else
        fout << -1;
}
