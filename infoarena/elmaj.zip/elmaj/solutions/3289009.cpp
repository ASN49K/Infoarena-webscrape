#include<fstream>
#include<stdlib.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int N = 1e6;
int n, v[N], ok = 0;

int main(){
    fin>>n;
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    for(int i=0;i<10;i++){
        int elem = v[rand()%n];
        int maj = 0;
        for(int j=0;j<n;j++){
            maj += (v[j] == elem);
        }
        if(maj>n/2){
            fout<<elem<<" "<<maj;
            ok = 1;
            break;
        }
    }
    if(!ok) fout<<"-1";
    return 0;
}
