#include <fstream>
#include <cstdlib>
#include <ctime>
#define nmax 1000005
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[nmax],n,k2,cnt;
void quick_select(int st,int dr,int k,int&ans)
{
    if(st==dr) {
        ans=v[st];
        return;
    }
    int pozitie_random=st+rand()%(dr-st+1);
    swap(v[pozitie_random],v[dr]);
    int piv=st-1;
    for(int i=st;i<dr;i++)
    {
        if(v[i]<=v[dr])
        {
            piv++;
            swap(v[piv],v[i]);
        }
    }
    piv++;
    swap(v[piv],v[dr]);
    if(piv==k2)
    {
        ans=v[piv];
        return;
    }
    int dim=piv-st+1;
    if(k>dim)
        quick_select(piv+1,dr,k-dim,ans);
    else
        quick_select(st,piv-1,k,ans);
}
int main()
{
    /*srand(static_cast<unsigned int>(time(nullptr)));
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    int ans=0;
    quick_select(1,n,n/2,ans);
    for(int i=1;i<=n;i++)
    {
        if(v[i]==ans)
            cnt++;
    }
    if(cnt>n/2)
        cout<<ans<<" "<<cnt;
        */
     cout<<-1;
    return 0;
}