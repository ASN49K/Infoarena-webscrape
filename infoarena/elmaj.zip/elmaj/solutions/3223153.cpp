#include<fstream>
using namespace std;
ifstream F("elmaj.in");
ofstream G("elmaj.out");
int n,i,j,k,c,a[1000000];
int main()
{
    for(F>>n;i<n;F>>a[i],!k?k=1,c=a[i]:c==a[i]?++k:--k,++i);
    for(i=0;i<n;j+=a[i++]==c);
    return j>n/2?G<<c<<' '<<j:G<<-1,0;
}
