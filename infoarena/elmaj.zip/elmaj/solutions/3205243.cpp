#include <fstream>
using namespace std;
map <long long,long long> a;
long long int realCount = 0;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int maj(int n){
    long long int canditate=-1;
    long long int count=0;
    for (int i = 0; i < n; i++) {
        if(count==0){
            canditate=a[i];
            count=1;
        }else if(canditate==a[i]){
            count++;
        }else{
            count--;
        }
    }
    for (int i = 0; i < n; i++) {
        if (a[i] == canditate)
            realCount++;
    }
    if (realCount > n / 2)
        return canditate;
    return -1;
}
int main()
{
    long long int n;
    cin>>n;
    for (int i = 0; i < n; i++) {
        cin>>a[i];
    }
    if(maj(n)!=-1)cout<<maj(n)<<" "<<realCount/2;
    else cout<<-1;
    return 0;
}
