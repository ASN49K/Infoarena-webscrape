#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");
    int n;
    fin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        fin >> v[i];
    }
    srand(time(0)); 
    for (int k = 0; k < 20; k++) {
        int x = v[rand() % n]; 
        int count = 0;
        for (int i = 0; i < n; i++) {
            if (v[i] == x) {
                count++;
            }
        }
        if (count >= n / 2 + 1) {
            fout << x << " " << count;
            return 0;
        }
    }
    fout << -1;
    return 0;
}