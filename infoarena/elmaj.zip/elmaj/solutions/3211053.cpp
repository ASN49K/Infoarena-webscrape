#include <fstream>

using namespace std;

int main() {
    ifstream in("elmaj.in");
    ofstream out("elmaj.out");

    int n;
    int a[1000005];
    int res = 0, count = 0;

    in >> n;
    for (int i = 0; i < n; ++i) {
        in >> a[i];
        if (count == 0) {
            res = a[i];
        }
        if (res == a[i]) {
            count++;
        } else {
            count--;
        }
    }

    int nr = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] == res)
            nr++;
    }

    if (nr < n / 2 + 1) {
        out << -1;
        return 0;
    }

    out << res << " " << nr;

    return 0;
}
