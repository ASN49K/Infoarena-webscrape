#include <stdio.h>
#define NMAX 1000000

///1017932

int v[NMAX + 1];

///1017932

int main() {
  FILE *fin, *fout;
  int n, i, nr, cnt;
  fin = fopen("elmaj.in", "r");
  fscanf(fin, "%d%d", &n, &v[0]);

  ///1017932

  nr = v[0];
  cnt = 1;
  for (i = 1; i < n; i++) {
    fscanf(fin, "%d", &v[i]);
    if (v[i] == nr)
      cnt++;
    else {
      cnt--;
      if (cnt < 0) {
        cnt = 1;
        nr = v[i];
      }
    }
  }
  fclose( fin );

  ///1017932

  cnt = 0;
  for (i = 0; i < n; i++)
    if (v[i] == nr)
      cnt++;

  ///1017932

  fout = fopen("elmaj.out", "w");
  if (cnt <= n / 2)
    fprintf(fout, "-1");
  else
    fprintf(fout, "%d %d", nr, cnt);
  fclose( fout );
  return 0;
}
