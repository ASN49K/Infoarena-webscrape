#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int x[1000001];
int main()
{
    int i,n,maj,prez=1;
    fin>>n>>x[0];
    maj=x[0];
    for(i=1;i<n;i++){
        fin>>x[i];
        if(x[i]==maj)prez++;
        else prez--;
        if(prez<=0){
            maj=x[i];
            prez=1;
        }
    }
    prez=0;
    for(i=0;i<n;i++)
        if(x[i]==maj)prez++;
    if(prez>=(n/2+1))
        fout<<maj<<" "<<prez;
    else fout<<"-1";
    return 0;
}
