#include <bits/stdc++.h>

using namespace std;

int v[1000001];

int main()
{
    ifstream cin ("elmaj.in");
    ofstream cout ("elmaj.out");
    int n;
    cin >> n;
    for(int i = 1; i <= n; ++i)
    {
        cin >> v[i];
    }
    int m = v[1], d = 1;
    for(int i = 1; i <= n; ++i)
    {
        d--;
        if(d == 0)
        {
            d = 1;
            m = v[i];
        }
        else
            d++;
    }
    int ap = 0;
    for(int i = 1; i <= n; ++i)
        if(v[i] == m)
            ap++;
    cout << m << ' ' << ap;
    return 0;
}
