#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <stack>
#include <algorithm>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int N = 1000001;

int main() {

	int n, cnt, elmaj, x;
	cnt = 0;
	fin >> n;
	fin >> elmaj;
	cnt = 1;
	for (int i = 2; i <= n; ++i) {
		fin >> x;
		if (cnt == 0) {
			elmaj = x;
		}
		else
			if (x != elmaj)
				cnt--;
			else
				cnt++;
	}

	fin.close();
	ifstream fin("elmaj.in");
	cnt = 0;
	fin >> n;
	for (int i = 1; i <= n; ++i) {
		fin >> x;
		if (x == elmaj)
			++cnt;
	}
	if (cnt > n / 2)
		fout << elmaj << " " << cnt;
	else
		fout << -1;

}