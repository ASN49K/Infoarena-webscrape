#include <bits/stdc++.h>

using namespace std;
ifstream f ("elmaj.in");
ofstream g ("elmaj.out");

long long n , v[100005];
void apariti(long long n,long long v[] )
{
    int maj=0,maxmaj=0,maxi=0;
    sort(v+1,v+1+n);
    for(int i=1 ; i<=n ;i++)
    {
        if( v[i-1] == v[i] )
            maj++;
        else
            maj=1;
        if( maj > maxmaj )
        {
            maxmaj = maj;
            maxi =  v[i] ;
        }
    }
    if( maxmaj > n/2 )
        g<<maxi<<" "<<maxmaj;
    else
        g<<-1;
}

int main()
{
    f >> n;
    for(int i=1 ; i<=n ; i++)
    {
        f >> v[i];
    }
    apariti(n , v);
    return 0;
}
