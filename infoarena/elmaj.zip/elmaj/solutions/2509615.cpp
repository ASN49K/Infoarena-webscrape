#include <stdio.h>

int main()
{
  FILE *fin, *fout;
  fin = fopen("elmaj.in", "r");
  fout = fopen("elmaj.out","w");

  int n;
  fscanf(fin, "%d", &n);
  int v[n];

  for(int i = 0; i < n; i++)
    fscanf(fin, "%d", &v[i]);

  int num = -1;
  int appear = 0;

  for(int i = 0; i < n; i++)
  {
    if(v[i] == num)
      appear++;
    else if(appear >= 0)
      appear--;
    else 
    {
      num = v[i];
      appear = 1;
    } 
  }  

  appear = 0;
  for(int i = 0; i < n; i++)
  {
    if(v[i] == num)
      appear++;
  }


  fprintf(fout, "%d %d", num, appear);
  

}