#include <iostream>
#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;
fstream fin("elmaj.in");
ofstream fout("elmaj.out");


int main()
{
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

    int n;
    vector<int> vect(n);

    fin >> n;
    for (int i = 0; i < n; i++)
    {
        fin>> vect[i];
    }

    for (int i = 0; i < 20; i++) 
    {
    int x = vect[rand() % n];
    int cnt = count(vect.begin(), vect.end(), x);

    if (cnt >= n / 2 + 1) 
    {
        fout << x << " " << cnt;
        return 0;
    }
    }

    fout << -1;

	return 0;
}