#include <fstream>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int v[1000001];

int main()
{

    int n;
    in>>n;
    int dubluri=0,elmaj;
    for(int i=0;i<n;i++)
    {
        in>>v[i];
        if(dubluri==0)
        {
            elmaj=v[i];
            dubluri=1;
        }
        else
        {
            if(v[i]==elmaj)
                dubluri++;
            else
            {
                dubluri--;
                if(dubluri==0)
                {
                elmaj=v[i];
            dubluri=1;
                }
            }
        }
    }
    dubluri=0;
    for(int i=0;i<n;i++)
        if(v[i]==elmaj)
            dubluri++;
    if(dubluri>n/2)
        out<<elmaj<<" "<<dubluri;
    else
        out<<-1;
    return 0;
}


