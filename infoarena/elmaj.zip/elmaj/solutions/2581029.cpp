#include <iostream>
#include <fstream>

using namespace std;

int x[1000001];

int main()
{
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");

    int n,nr=1,candidat=-1;
    fin>>n;
    for(int j=1; j<=n; j++)
    {
        fin>>x[j];
         if(x[j]==candidat)
            {
                nr++;
            }
            else
            {
                if(nr==1)
                {
                    candidat=x[j];
                }
                else
                {
                    nr--;
                }
            }
    }
    nr=0;
    for(int j=1; j<=n; j++)
    {
        if(x[j]==candidat)
        {
            nr++;
        }
    }
    if(nr>n/2)
    {
       fout<<candidat<<" "<<nr;
    }else
    {
       fout<<-1;
    }
    return 0;
}
