#include <iostream>
#include <fstream>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
const int NMAX = 1e6 + 1;
int v[NMAX];

int main()
{

    int n, cand = -1, nrVoturi = 0;
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
        if (nrVoturi == 0)///nu avem niciun candidat, deci il luam pe cel curent
        {
            cand = v[i];
            nrVoturi = 1;
        }
        else if (v[i] == cand)///este un vot in plus pentru candidatul curet
        {
            nrVoturi++;
        }
        else ///este un vot contra
        {
            nrVoturi--;
        }
    }
    if (nrVoturi == 0)
    {
        g << -1;
        return 0;
    }
    int frecv = 0;
    for (int i = 1; i <= n; i++)
    {
        if (v[i] == cand)
        {
            frecv++;
        }
    }
    if (frecv >= n / 2 + 1)
    {
        g << cand << ' ' << frecv;
    }
    else
        g << -1;
    return 0;
}