#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[1000001];
int n,i,x=-1,j;
bool gasit;
int main()
{
    f>>n;
for(i=1;i<=n;i++)
    f>>v[i];
sort(v+1,v+n+1);
i=1;
gasit=0;
while(i<=n && gasit==0)
{
    j=i;
    while(j<=n && v[j+1]==v[i])
        j++;
    if(j-i+1>n/2)
    {
        gasit=1;
        x=v[i];
    }
    i=j+1;
}
if(gasit==1)
  g<<x<<" "<<(n/2)+1;
  else
    g<<x;
    return 0;
}
