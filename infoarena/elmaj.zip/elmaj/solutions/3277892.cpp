#include <fstream>
#include <iostream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000009];
int main ()
{
    int n;
    f >> n;
    for (int i=1; i<=n; i++)
        f >> v[i];
    int candidat=0, k=0;
    for (int i=1; i<=n; i++)
    {
        if (!k) candidat=v[i], k=1;
        else
        {
            if (v[i]==candidat) k++;
            else k--;
        }
    }
    cout << candidat;
    int nr=0;
    for (int i=1; i<=n; i++)
        if (v[i]==candidat) nr++;
    if (nr>n/2) g << candidat << ' ' <<nr;
    else g<<-1;
}