#include <bits/stdc++.h>
#define int long long
using namespace std;

int v[100005];
signed main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n,cnt=0,candidat=0;
    cin >> n;
    for(int i=1;i<=n;i++)
    {
        cin >> v[i];
    }
    for(int i=1;i<=n;i++)
    {
        if(cnt==0)
        {
            candidat=v[i];
            cnt++;
        }
        else
        {
            if(candidat==v[i])
                cnt++;
            else
            {
                cnt--;
            }
        }
    }
    cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(v[i]==candidat)
            cnt++;
    }
    if(cnt<(n/2)+1)
        cout << -1;
    else
        cout << candidat << " " << cnt;
    return 0;
}
