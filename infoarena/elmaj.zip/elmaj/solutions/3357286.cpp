#include <fstream>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int a[1000001];

int main() /// Complexitate O(n)
{
    int n, nr = 0, i , cand=-1;
    f >> n;
    for (i = 1; i <= n; i++)
    {
        f >> a[i];

        if (nr == 0)
        {
            cand = a[i];
            nr = 1;
        }
        else if (a[i] == cand)
            nr++;
        else
            nr--;
    }

    if (nr == 0)
        g << -1;
    else
    {
        nr = 0;

        for (i = 1; i <= n; i++)
        {
            if (a[i] == cand)
                nr++;
        }

        if (nr > n / 2)
            g << cand << ' ' << nr;
        else
            g << -1;
    }

    f.close();
    g.close();
    return 0;
}