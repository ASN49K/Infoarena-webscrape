#include <iostream>
#include <fstream>
#define NMAX 1000000

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n, nr, elmaj, v[NMAX+10];

int main()
{
    f >> n;
    for(int i=1; i<=n; i++) f >> v[i];
    elmaj = v[1];
    nr = 1;
    for(int i=2; i<=n; i++)
        {   if(v[i] == elmaj) nr++;
            else nr--;
            if(nr < 0) elmaj = v[i], nr = 1;
        }
    nr = 0;
    for(int i=1; i<=n; i++) if(v[i] == elmaj) nr++;
    if(nr >= n/2+1) g << elmaj << ' ' << nr << '\n';
    else g << -1 << '\n';
    return 0;
}
