package main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    static final String INPUT = "src/elmaj.in";
    static final String OUTPUT = "src/elmaj.out";

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws IOException {
        BufferedWriter writer;
        try ( Scanner scanner = new Scanner(new File(INPUT))) {
            writer = new BufferedWriter(new FileWriter(OUTPUT));
            StringBuilder builder = new StringBuilder();
            boolean found = false;
            List<Integer> elemList = new ArrayList<>();
            int n = scanner.nextInt();
            for (int i = 0; i < n; ++i) {
                int x = scanner.nextInt();
                elemList.add(x);
            }
            java.util.Collections.sort(elemList);
            int i = 0;
            while (i < n && !found) {
                int j;
                for (j = i; j < n && java.util.Objects.equals(elemList.get(i), elemList.get(j + 1)); ++j);
                if (j - i + 1 > n / 2) {
                    builder.append(elemList.get(i)).append(" ").append(j - i + 1).append('\n');
                    writer.write(builder.toString());
                    found = true;
                    continue;
                }
                i = j + 1;
            }
            if (!found) {
                builder.append(-1).append('\n');
                writer.write(builder.toString());
            }
        }
        writer.close();
    }
}
