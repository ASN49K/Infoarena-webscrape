#include <fstream>
#include <vector>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1000005];

int main()
{
    int n, cnt=1, cd=0;
    cin>>n;
    cin>>v[0];
    cd=v[0];
    for(int i=1; i<n; i++)
    {
        cin>>v[i];
        if(v[i]==cd)
        {
            cnt++;
        }
        else
        {
            cnt--;
        }
        if(cnt==0)
        {
            cnt=1;
            cd=v[i];
        }
    }
    cnt=0;
    for(int i=0; i<n; i++)
    {
        if(v[i]==cd)
            cnt++;
    }
    if(cnt>=n/2+1)
    {
        cout<<cd<<" "<<cnt;
    }
    else
        cout<<-1;

    return 0;
}
