#include<bits/stdc++.h>
using namespace std;


int main (){
ifstream ci("elmaj.in");
ofstream cou("elmaj.out");

int n,x,cn=0,k,v[100000],i=1,n1 ;
ci>>n;n1=n;n--;
ci>>x;
v[i++]=x;
k=x;
cn++;
while(n){
    ci>>x;
    v[i++]=x;
    if(x!=k){
        cn--;
    }else{
    cn--;
    }
    if(cn<=0){
        k=x;
        cn=1;
    }
    n--;
}
n=n1;
cn=0;
for(i=1;i<=n;i++){
    if(v[i]==k ){
        cn++;
    }
}
if(cn>=n/2+1 )
{

    cou<<k<<" "<<cn;
}else{
cou<<"-1";
}


}






