#include <bits/stdc++.h>
using namespace std;

void solve() {
  
  int n;
  cin >> n;
  vector<int> a(n);
  for (int& k : a) cin >> k;

  int v = -1, c = 0;
  for (int k : a) {
    if (c == 0) {
      v = k;
      c = 1;
    } else if (v == k) {
      c++;
    } else {
      c--;
    }
  }

  if (c == 0) {
    cout << -1 << endl;
    return;
  }

  c = 0;
  for (int k : a) {
    c += k == v;
  }

  cout << v << ' ' << c << endl;
}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("elmaj.in", "r", stdin);
  freopen("elmaj.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
