# include <iostream>
# include <fstream>
# include <cmath>

using namespace std;

ifstream  fi("elmaj.in");
ofstream fo("elmaj.out");

long long n, x, elmaj, s;

int main ()

{
    fi >> n;
    for ( int i = 1; i <= n; ++i) {
    fi >> x;
    if ( s == 0) {
        elmaj = x;
        s = 1;
    }
    else
        if ( x == elmaj)
            ++s;
        else
            --s;
    }
    fi.close();
    ifstream  fi("elmaj.in");
     fi >> n;
     s = 0;
    for ( int i = 1; i <= n; ++i) {
    fi >> x;
    if ( x == elmaj)
            ++s;
    }
    if ( s >= n / 2 + 1)
        fo << elmaj << " " << s;
    else
        fo << -1;
    return 0;
}
