#include <bits/stdc++.h>

using namespace std;

const string fisier = "elmaj";

ifstream fin (fisier + ".in");
ofstream fout (fisier + ".out");

const int N_MAX = 1e6 + 5;

int a[N_MAX];

void test_case() {
  int n; fin >> n;
  for (int i=1; i<=n; i++){
    fin >> a[i];
  }
  int e = a[1] , cnt = 1 , ans = 0;
  for (int i=2; i<=n; i++){
    if (a[i] == e){
      cnt += 1;
    }
    else{
      cnt -= 1;
    }
    if (cnt < 0){
      e = a[i] , cnt = 1;
    }
  }
  for (int i=1; i<=n; i++){
    if (a[i] == e){
      ans += 1;
    }
  }
  if (ans >= n / 2 + 1){
    fout << e << " " << ans;
  }
  else{
    fout << -1;
  }
}

int main(){
  ios_base::sync_with_stdio(false);
  int tests = 1;
  for (int tc=0; tc<tests; ++tc) {
    test_case();
  }
}
