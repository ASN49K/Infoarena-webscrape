//elmaj
#include <iostream>
#include <fstream>
#define lim 1000001

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n,arr[lim];

void resolve()
{
    int k = 0, aux = -1;

    for(int i = 1; i <= n; i++)
    {
        if(k == 0)
        {
            aux = arr[i];
            k = 1;
        }
        else
            if(arr[i] == aux)
            	k++;
            else
            	k--;
    }

    if(aux < 0)
        fout << aux;

    int nr = 0;

    for(int i = 1; i <= n; i++)
        if(arr[i] == aux)
            nr++;
    if(nr > n/2)
        fout << aux << ' ' << nr;
    else
        fout << -1;
}

int main()
{
    fin >> n;

    for(int i = 1; i <= n; i++)
        fin >> arr[i];

    resolve();

    return 0;
}
