# include <fstream>
# include <map>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int main()
{
	int n, x,ok=0;
	int max = 0;
	map<int, int>dictionar;
	fin >> n;
	for (int i = 0; i < n; i++)
	{
		fin >> x;
		if (dictionar.count(x))
			dictionar.find(x)->second++;
		else
			dictionar.insert(pair<int, int >(x, 1));

	}
	for (auto i = dictionar.begin(); i != dictionar.end(); i++)
	{
		if (i->second >= (n / 2) + 1)
		{
			fout << i->second;
			ok = 1;
		}
	}
	if (!ok)
		fout << -1;
	return 0;
}