#include <fstream>
using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int v[100001];
int main()
{
    int n,x,y,i,ok;
    fin >>n;
    x=0;
    y=1;
    for (i=1;i<=n;++i)
    {
        fin >>v[i];
        if (v[i]!=x)
        {
            y--;
        }
        else
            y++;
        if (y==0)
        {
            x=v[i];
            y=1;
        }
    }
    ok=0;
    for (i=1;i<=n;++i)
    {
        if (x==v[i])
        {
            ok++;
        }
    }
    if (ok>n/2)
        fout <<x<<' '<<ok;
    else
        fout <<-1;
    fin.close ();
    fout.close ();
    return 0;
}
