#include <iostream>
#include <fstream>
#include <queue>
#include <set>
#include <algorithm>
#include <stack>
#include <vector>
#include <iomanip>
#include <cstdio>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[1000001], n;

int main() {
	fin >> n;
	int ap, cand;

	for (int i = 1; i <= n; ++i)
		fin >> a[i];

	cand = a[1];
	ap = 1;

	for (int i = 2; i <= n; ++i) {
		if (a[i] == cand)
			ap++;
		else {
			ap--;
			if (ap == -1) {
				cand = a[i];
				ap = 1;
			}
		}
	}

	ap = 0;

	for (int i = 1; i <= n; ++i)
		if (a[i] == cand)
			ap++;

	if (ap > n / 2)
		fout << cand << " " << ap << "\n";
	else
		fout << "-1\n";

	return 0;
}