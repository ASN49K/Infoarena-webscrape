#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n,v[1000001],nr,em;
int main()
{
    f>>n;
    for (int i=1; i<=n; i++)
    {
        f>>v[i];
    }
    nr=1;
    em=v[1];
    for (int i=2; i<=n; i++)
    {
        if (em!=v[i])
        {
            nr--;
        }
        else nr++;
        if (nr<0)
        {
            em=v[i];
            nr=1;
        }
    }
    nr=0;
    for (int i=1; i<=n; i++)
    {
        if (em==v[i])
            nr++;
    }
    if (nr>n/2)
    {
        g<<em<<' '<<nr;
    }
    else g<<-1;
    return 0;
}
