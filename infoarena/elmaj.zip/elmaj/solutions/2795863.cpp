#include <bits/stdc++.h>
using namespace std;
ifstream f("elmaj.in"); ofstream g("elmaj.out");
int n,v[1000001];
int main()
{   f>>n;
    for(int i=1;i<=n;i++) f>>v[i];
    for(int j=1;j<=10;j++)
    {   int nr=0,a=v[1+rand()%n];
        for(int i=1;i<=n;++i)
            if(v[i]==a) nr++;
        if(nr>n/2) {g<<a<<' '<<nr; g.close(); f.close(); return 0;}
    }
    g<<-1; g.close(); f.close(); return 0;
}
