#include <fstream>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");

int main()
{
    int i, n, cand = -1, nr = 0, x;
    f >> n;
    for(i = 1; i <= n; i++)
    {
        f >> x;
        if(nr == 0)
        {
            cand = x;
            nr = 1;
        }
        else
            if(x == cand)nr++;
            else nr--;
    }
    ///
    if(nr == 0)
    {
        g << -1;
        return 0;
    }
    f.close();
    f.open("elmaj.in", ios_base::in);
    f >> n;
    nr = 0;
    for(i = 1; i <= n; i++)
    {
        f >> x;
        if(cand == x)nr++;
    }
    if(nr > n / 2)
        g << cand << ' ' << nr;
    else
        g << -1;
    return 0;
}
