//#include <bits/stdc++.h>
#include <fstream>
#include <queue>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int n,i,nr;
long long x,pv;
priority_queue <long long> q;
int main()
{
    in>>n;
    for(i=1; i<=n; ++i)
        in>>x,q.push(x);
    pv=q.top(),q.pop(),nr=1;
    while(!q.empty())
    {
        if(q.top()==pv)
            ++nr;
        else if(nr>=n/2+1)
        {
            out<<pv<<" "<<nr;
            return 0;
        }
        else nr=1;
        pv=q.top();
        q.pop();
    }
    out<<-1;
}
