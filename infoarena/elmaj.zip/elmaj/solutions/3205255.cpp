#include <fstream>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000001];
int main()
{
    int n;
    cin >> n;
    int count = 0, cand = -1;
    for( int i = 0; i < n; i++ ){
        cin >> v[i];
        if(count == 0){
            cand = v[i];
            count = 1;
        }
        else if(cand == v[i]){
            count ++;
        }
        else{
            count--;
        }
    }
    int count2 = 0;
    for( int i = 0; i < n; i++ ){
        if(v[i] == cand)
            count2 ++;
    }
    if(count2 >= n/2+1)
        cout << cand << " " << count2;
    else
        cout << -1;

    return 0;
}
