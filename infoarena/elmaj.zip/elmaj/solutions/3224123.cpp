#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[100001];
int main()
{
    int n,ec,fr;
    fin>>n;
    for(int i=1;i<=n;++i){
        fin>>v[i];
    }
    ec=v[1];
    fr=1;
    for(int i=2;i<=n;++i){
        if(ec!=v[i]){
            fr-=1;
        }else {
            fr+=1;
        }
        if(fr==0){
            ec=v[i];
            fr=1;
        }
    }
    fr=0;

    for(int i=1;i<=n;++i){
        if(ec==v[i]){
            fr++;
        }
    }
       if (fr >= n / 2 + 1) {
        fout << ec << ' ' << fr;
    } else {
        fout << -1;
    }

    return 0;
}
