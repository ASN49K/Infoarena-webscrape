#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <numeric>
#include <algorithm>
using namespace std;
 
 
int main(){
	ifstream fin;
	ofstream fout;
	fin.open("elmaj.in");
	fout.open("elmaj.out"); 
	int n, x;
	vector<int> v(1000005);
 	fin >> n;

	for(int i = 1; i <= n; ++i){
		fin >> v[i];
	}

	std::vector<unsigned int> indices(n-1);
	std::iota(indices.begin(), indices.end(), 0);
	std::random_shuffle(indices.begin(), indices.end());

	map<int,int> data;
	map<int,int> data2;

	for(int i = 0; i < min(n/2, 100); ++i){
		data[v[indices[i]]]++;
	}
	auto best = max_element(data.begin(), data.end(), [] (const std::pair<int,int>& a, const std::pair<int,int>& b)->bool{ return a.second < b.second; });
	int candidate = best->first;

	int power;
	power = 0;
	for(int i = 1; i <= n; ++i){
		if(v[i] == candidate)
			++power;
	}	
	if(n > 30){
		if(power >= n/2 + 1)
			fout << candidate << " " << power;
		else
			fout << -1;
	}
	else{
		for(int i = 1; i <= n; ++i){
			data2[v[i]]++;
		}
		auto best = max_element(data2.begin(), data2.end(), [] (const std::pair<int,int>& a, const std::pair<int,int>& b)->bool{ return a.second < b.second; });
		int candidate = best->first;
		if(power >= n/2 + 1)
			fout << candidate << " " << best->second;
		else
			fout << -1;
	}
}