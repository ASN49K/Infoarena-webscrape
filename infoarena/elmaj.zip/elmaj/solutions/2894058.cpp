#include <cstdio>
#include <algorithm>

using namespace std;
FILE *fin, *fout;

#define NMAX 1000000
int v[NMAX + 5];

bool verif(int fr, int len)
{
    if(fr >= len / 2 + 1)
        return true;

    return false;
}

int main()
{
    fin = fopen("elmaj.in", "r");
    fout = fopen("elmaj.out", "w");

    int n;
    fscanf(fin, "%d", &n);
    int i;
    for(i = 1; i <= n; i++)
        fscanf(fin, "%d", &v[i]);

    sort(v + 1, v + n + 1);

    /*for(i = 1; i <= n; i++)
        fprintf(fout, "%d ", v[i]);*/

    int j, len, el, maxim = 0;

    for(i = 1; i <= n; i++)
    {
        j = i;

        while(v[j] == v[i] and j <= n)
            j++;

        len = j - i + 1;

        if(len > maxim)
        {
            maxim = len;

            el = v[i];
        }

        i = j;
    }

    if(verif(maxim, n))
        fprintf(fout, "%d %d", el, maxim);
    else fprintf(fout, "-1");

    fclose(fin);
    fclose(fout);
    return 0;
}
