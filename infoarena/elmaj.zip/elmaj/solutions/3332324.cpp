#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n;
int v[1000000];
mt19937 gen_rand(time(NULL));
unordered_map<int,int> m;
int Max, elem, frec;
bool mark[1000000];
int main(){
fin>>n;
for (int i = 0; i < n; i++){
    fin>>v[i];
}
for (int i = 1; i <= min(n, 12);){
    int poz = gen_rand() % n;
    if (!mark[poz]){
        m[v[poz]]++;
        mark[poz] = 1;
        if (m[v[poz]] > Max){
            Max = m[v[poz]];
            elem = v[poz];
        }
        i++;
    }
}
for (int i = 0; i < n; i++){
    if (v[i] == elem)
        frec++;
}
if (frec < n / 2 + 1)
    fout << -1;
else
    fout << elem << " " << frec;
    return 0;
}