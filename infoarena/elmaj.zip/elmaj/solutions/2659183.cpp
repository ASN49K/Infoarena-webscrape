#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

int main() {
  ifstream f("elmaj.in");
  ofstream g("elmaj.out");

  int n;
  f >> n;
  int x;
  int result = -1;
  unordered_map<int, int> frecuency;

  for(int i = 0; i < n; i++) {
    f >> x;
    if (frecuency.find(x) == frecuency.end()) {
      frecuency.emplace(x, 1);
    } else {
      frecuency.at(x) = frecuency.at(x) + 1;
    }
    if (frecuency[x] >= n/2 +1) {
      result = x;
    }
  }
  if (result != -1) {
    g << result << " " << frecuency[x] << endl;
  } else {
    g << "-1" << endl;
  }
  return 0;
}