#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n, v[1000001];
int main()
{
    int i, maj, nr;
    f >> n;
    for(i = 1; i <= n; i++)
        f >> v[i];
    maj = v[1], nr = 1;
    for(i = 2; i <= n; i++)
        if(maj == v[i]) nr++;
        else
        {
            nr--;
            if(nr < 0) maj = v[i], nr = 1;
        }
    nr = 0;
    for(i = 1; i <= n; i++)
        if(v[i] == maj) nr++;
    if(nr > n / 2) g << maj << ' ' << nr;
    else g << "-1";
    f.close();
    g.close();
    return 0;
}
