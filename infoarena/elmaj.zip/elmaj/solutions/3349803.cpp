#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int main() {


    int n;
    cin >> n;

    vector<long long> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }

    for (int k = 0; k < 20; k++) {
        int poz = rand() % n;
        long long x = v[poz];

        int cnt = 0;
        for (int i = 0; i < n; i++) {
            if (v[i] == x)
                cnt++;
        }

        if (cnt >= n / 2 + 1) {
            cout << x << " " << cnt;
            return 0;
        }
    }

    cout << -1;

    return 0;
}