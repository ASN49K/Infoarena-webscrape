#include <iostream>
#include <fstream>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n,m,v[1000010],el,k,i,maxim;
int main(){
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i];
    el = v[1];
    k = 1;
    for(i=2;i<=n;i++){
        if(k!=0){
            if(el == v[i])
                k++;
            else
                k--;
        }
        else{
            k = 1;
            el = v[i];
        }
    }
    if(k == 0)
        g<<-1<<'\n';
    else{
        for(i=1;i<=n;i++)
            if(v[i] == el)
                maxim++;
        g<<el<<' '<<maxim<<'\n';
    }
}
