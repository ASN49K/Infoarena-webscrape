#include "bits/stdc++.h"
using namespace std;
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n,e,r,l;
    cin>>n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
    {
        cin>> v[i];
    }
    l=n/2+1;
    r=-1;
    for (int i=0; i<v.size(); i++)
    {
        int p=0;
        for(int j:v)
        {
            if(v[i]==j) p++;
        }
        if(p>=l && p>r)
        {
            r=p;
            e=v[i];
        }
    }
        if(r!= -1)
        {
            cout << e << " " << r;
        }
        else
            cout<< r;
        return 0;
    }
