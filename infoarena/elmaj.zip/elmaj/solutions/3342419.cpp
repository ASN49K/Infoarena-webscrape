#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
#define cin fin
#define cout fout
int main(){
	int n;
	vector<int> a;
	cin>>n;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		a.push_back(x);
	}
	int candidate,count=0;
	for(auto i : a){
		if(count==0){
			candidate=i;
			count=1;
		}
		else if(candidate == i){
			count++;
		}
		else{
			count--;
		}
	}
	int candfrec=0;
	for(auto i : a){
		if(i==candidate)
			candfrec++;
	}
	if(candfrec > a.size()/2)
		cout<<candidate<<' '<<candfrec;
	else
	 	cout<<-1;
}
