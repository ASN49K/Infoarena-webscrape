#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
#define cin fin
#define cout fout

int main()
{
    int n,i,c,k=1,v[1000005];
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i];
    }
    c=v[i];
    for(i=2;i<=n;i++)
    {
        if(v[i]==c)k++;
        else
        {
            k--;
            if(k==0){c=v[i];k=1;}
        }
    }
    k=0;
    for(i=1;i<=n;i++)
    {
        if(v[i]==c)k++;
    }
    if(k>n/2)cout<<c << " " << k;
    else cout<<"-1";
    return 0;
}
