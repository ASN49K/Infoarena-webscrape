#include <iostream>
#include <fstream>
using namespace std;

int n,v[1000001];

int candidat()
{
    int cnt = 0,cand=v[1];
    for (int i = 1; i <= n; i++)
    {
        if(cand == v[i])
            cnt++;
        else
            cnt--;
        if(cnt == 0)
        {
            cand = v[i];
            cnt = 1;
        }
    }
    return cand;
}

int main()
{
    ifstream cin("elmaj.in");
    ofstream cout ("elmaj.out");
    int cnt=0,cand;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    cand=candidat();
    for(int i=1;i<=n;i++)
        if(v[i]==cand)
            cnt++;
    if(cnt > n/2)
        cout<<cand<<' '<<cnt;
    else
        cout<<-1;
    return 0;
}
