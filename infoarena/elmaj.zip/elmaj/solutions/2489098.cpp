#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,a[1000100],k,u;
int main(){
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>a[i];
        if(k==0){
            u=a[i];
            k++;
        }
        else{
            if(a[i]==u){
                k++;
            }
            else{
                k--;
            }
        }
    }
    k=0;
    for(int i=1;i<=n;i++){
        if(a[i]==u){
            k++;
        }
    }
    if(k>=(n/2+1)){
        fout<<u<<" "<<k;
    }
    else{
        fout<<"-1";
    }



}
