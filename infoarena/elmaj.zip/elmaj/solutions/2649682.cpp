#include <iostream>
#include <fstream>
#include <unordered_map>
using namespace std;
ifstream fin("elmax.in");
ofstream fout("elmaj.out");
int a[1000001];
unordered_map<int,int> mapa;
int main()
{   int n;
    fin>>n;
    int maxim = -1,x;
    int element = 0;
    for(int i = 0 ; i < n ; i++)
        {   fin >> x;
            mapa[x]++;
            if(mapa[x] > maxim)
            {
                element = x;
                maxim = mapa[x];
            }
        }
    if(maxim >= (n/2)+1)
        fout<<maxim;
    else fout << -1;
    cout<<maxim;
    return 0;
}
