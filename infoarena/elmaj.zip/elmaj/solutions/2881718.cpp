#include <bits/stdc++.h>

using namespace std;
int n,x,rez=-1;
unordered_map<long long,int>f;
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x;
        f[x]++;
        if(f[x]*2+1>=n)
        {
            rez=x;
        }
    }
    if(rez!=-1)cout<<rez<<" "<<f[rez];
    else
    cout<<-1;
    return 0;
}
