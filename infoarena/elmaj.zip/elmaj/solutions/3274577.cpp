#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,cnt,nr,i;
int a[1000005];
signed main()
{
    fin >> n;
    for(i=1;i<=n;i++)fin>>a[i];
    for(i=1;i<=n;i++)
    {
        if(cnt==0)
        {
            nr=a[i];
            cnt++;
        }
        else
        {
            if(nr==a[i])
                cnt++;
            else
                cnt--;

        }
    }
    cnt=0;
    for(i=1;i<=n;i++)
        if(a[i]==nr)cnt++;

    if(cnt<(n/2)+1)
        fout << -1;
    else
        fout << nr << " " << cnt;
    return 0;
}
