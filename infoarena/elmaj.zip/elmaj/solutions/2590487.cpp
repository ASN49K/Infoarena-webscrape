#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
#define N 1000005
int a[N],n;

void majoritar()
{    in>>n;
for(int i=1; i<=n; ++i)
    in>>a[i];
    int cand=-1,k=0;
    for(int i=1; i<=n; ++i)
        if(k==0)
        cand=a[i],k++;
        else
        {
            if(a[i]==cand)
                k++;
            else k--;
        }
    int nr=0;
    for(int i=1; i<=n; ++i)
        if(a[i]==cand)
        nr++;
    if(nr>n/2) out<<cand<<" "<<nr;
     else out<<-1;

}


int main()
{
    majoritar();
    return 0;
}
