#include <fstream>

using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int n, v[1000000] ,cand=-1,prez=0,nr=0;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        if(prez==0)
        {
            cand=v[i];
            prez=1;
        }
        else
        {
        if(v[i]==cand)
            prez++;
        else
            prez--;
        }
    }
    for(int i=1;i<=n;i++)
        if(v[i]==cand)
            nr++;
    if(nr>n/2)
        cout<<cand<<" "<<nr;
    else
        cout<<-1;
    return 0;
}
