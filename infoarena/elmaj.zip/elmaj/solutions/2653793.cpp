#include <fstream>

using namespace std;
int a[1000001];
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int main()
{
    int e=0, n, x, i,cnt=1,ap=0;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i];
        e=a[1];
    for(i=2;i<=n;i++)
    {
     if(a[i]==e)cnt++;
        else cnt--;
        if(cnt<0){cnt==0;e=a[i];}
    }
    for(i=1;i<=n;i++)
    {
        if(a[i]==e)ap++;
    }
    if(ap<n/2+1)fout<<-1;
    else fout<<e<<" "<<ap;
    return 0;
}
