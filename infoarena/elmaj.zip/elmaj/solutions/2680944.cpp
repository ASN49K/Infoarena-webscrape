#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int main()
{
    int a[1000005],n,Count=1;
    f>>n>>a[0];
    int maj=a[0];
    int cnt=0;
    for(int i=1;i<n;i++){
        f>>a[i];
        if(a[i]==maj)
            Count++;
        else Count--;
        if(Count==0){
            maj=a[i];
        Count=1;}
    }
    for(int i=0;i<n;i++)
        if(a[i]==maj)cnt++;
    g<<maj<<" "<<cnt;
    return 0;
}
