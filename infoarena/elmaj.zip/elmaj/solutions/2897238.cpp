#include <bits/stdc++.h>
using namespace std;
int n;
int v[200001];
ifstream in ("elmaj.in");
ofstream out ("elmaj.out");
main ()
{
    in >> n;
    for (int i = 1;i<=n;++i)
        in >> v[i];
    int now = 0, number = 0;
    for (int i = 1;i<=n;++i)
    {
        if (number == 0)
            now = v[i], number = 1;
        else if (now == v[i])
            number++;
        else
            number--;
    }
    int cate = 0;
    for (int i = 1; i<=n;++i)
        if (v[i] == now)
            cate++;
    if (cate > n / 2)
        out << now << ' ' << cate << '\n';
    else
        out << -1 << '\n';
    return 0;
}

