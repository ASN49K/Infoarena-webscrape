#include <bits/stdc++.h>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int v[1000001];
int main()
{
    int n,i,nra,c;
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>v[i];
    nra=0;
    for (i=1; i<=n; i++)
        if (nra==0)
        {
            c=v[i];
            nra=1;
        }
        else if (v[i]==c)
            nra++;
        else
            nra--;
    if (nra==0)
        fout<<-1;
    else
    {
        nra=0;
        for(i=1; i<=n; i++)
            if (v[i]==c)
                nra++;
            if (nra>=n/2+1)
                fout<<c<<" "<<nra;
            else fout<<-1;
            }
    return 0;
}
