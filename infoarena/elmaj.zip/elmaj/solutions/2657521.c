#include <stdio.h>
#define NMAX 1000000

///1017932

int v[NMAX + 1];

///1017932

int main() {
  FILE *fin, *fout;
  int n, i, nr, cnt;
  fin = fopen("elmaj.in", "r");
  fscanf(fin, "%d", &n);

  ///1017932

  nr = -1;
  cnt = 0;
  for (i = 0; i < n; i++) {
    fscanf(fin, "%d", &v[i]);
    if (cnt == 0)
      nr = v[i];
    else if (v[i] == nr)
      cnt++;
    else
      cnt--;
  }
  fclose( fin );

  ///1017932

  cnt = 0;
  for (i = 0; i < n; i++)
    if (v[i] == nr)
      cnt++;

  ///1017932

  fout = fopen("elmaj.out", "w");
  if (cnt <= n / 2)
    fprintf(fout, "-1");
  else
    fprintf(fout, "%d %d", nr, cnt);
  fclose( fout );
  return 0;
}
