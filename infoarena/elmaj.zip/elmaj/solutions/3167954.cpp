#include <bits/stdc++.h>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
map<int,int> cnt;
int n;
int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        int x;
        cnt[x]++;
    }

    for(auto it:cnt)
        if(it.second>=n/2+1)
        {
            g<<it.first<<' '<<it.second<<'\n';
            return 0;
        }
    g<<"-1\n";
    return 0;
}
