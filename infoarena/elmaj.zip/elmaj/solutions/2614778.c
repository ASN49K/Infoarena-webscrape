#include <stdio.h>
#include <stdlib.h>


void citire(long *v,int n)
{
	for(int i=0;i<n;i++)
		scanf("%ld",&v[i]);
}


long majortiar(long v[],int n) {
	
    long candidat = -1;
    int contor = 0;
	
    for (int i = 0; i < n; i++) {
	
        if (contor== 0) 
        {
	
            candidat = v[i];
            contor = 1;
	
        } 
        else if (v[i] == candidat) 
			contor++;   
       	else
            contor--;   
	
    }
    if (candidat < 0)
        return candidat;
	
    // Verificam:
	
    int nr = 0;
	
    for (int i = 0; i < n; i++) {
	
        if (v[i] == candidat) 
	
            nr++;
	
    }
	
    if (nr > n / 2)
	
        return candidat;
	
    else
	
        return -1;
	
}

int main()
{
	int n;
	printf("n=");
	scanf("%d",&n);
	long v[n];
	citire(v,n);
	long valoare = majortiar(v,n);
	if(valoare<1)
		printf("Nu exista element majoritar");
	else printf("Elementul majoritar este %ld ",valoare);

}