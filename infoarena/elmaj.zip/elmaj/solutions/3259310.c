#include <stdio.h>

int boyermoore(int arr[], int t) {
	int m = arr[0];
	int c = 0;
	for(int i = 0; i < t; i++) {
		if (c == 0) {
			m = arr[i];
			c = 1;
		} else if (m == arr[i]) {
			c++;
		} else {c--;}
	} 
	return m;
}

int main() {
	FILE *input = fopen("elmaj.in", "r");
	FILE *output = fopen("elmaj.out", "w");

	int t;

	fscanf(input, "%d", &t);

	int arr[t];

	for(int i = 0; i < t; i++) {
		fscanf(input, "%d ", &arr[i]);
	}

	int m = boyermoore(arr, t);
	int c = 0;
	for(int i = 0; i < t; i++) {
		if(arr[i] == m) {
			c++;
		}
	}

	fprintf(output, "%d %d", m, c);

	fclose(input);
	fclose(output);
}
