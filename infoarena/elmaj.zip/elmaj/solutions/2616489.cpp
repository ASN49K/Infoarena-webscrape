#include <fstream>
#include <iostream>

using namespace std;

int v[1000000];

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    int n,nr=1,candidat=0;
    in>>n>>v[0];
    candidat = v[0];
    for( int i = 1; i < n; i++ ){
        in>>v[i];
        if( v[i] == candidat ){
            nr++;
        }
        else
            nr--;
        if( nr == 0 ){
            candidat = v[i];
            nr = 1;
        }
    }
    nr = 0;
    for( int i = 0; i < n; i++ )
        if( v[i] == candidat )
            nr++;
    if( nr < n / 2 + 1 )
        out<<"-1";
    else{
    out<<candidat;
    out<<'\n'<<nr;
    }
    return 0;
}
