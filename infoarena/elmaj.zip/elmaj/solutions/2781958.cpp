#include <bits/stdc++.h>
#define N 1000001
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n,a[N];
void citire()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>a[i];
}
void rezolva()
{
    int i,j,ct=0;
    int maj=n/2+1;
    int ctmax=-1,x;
    for(i=1; i<=n; i++)
    {
        ct=0;
        if(a[i]>=1)
        {
            ct=1;
            for(j=i+1;j<=n;j++)
                if(a[j]==a[i])
                {ct++;a[j]=0;}
            if(ct>=maj)
               {
                   x=a[i];
                   ctmax=ct;
               }
        }

    }
    if(ctmax!=-1)
      fout<<x<<" "<<ctmax;
    else fout<<ctmax;

}
int main()
{
citire();
rezolva();

    return 0;
}
