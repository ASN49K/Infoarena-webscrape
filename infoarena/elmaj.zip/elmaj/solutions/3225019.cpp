#include <bits/stdc++.h>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,v[1000003],cand,k=0,ap;
int main()
{
    fin>>n;
    for (int i=1;i<=n;i++)
        fin>>v[i];
    for (int i=1;i<=n;i++)
    {
        if (k==0)
        {
            cand=v[i];
        }
        if (v[i]==cand) k++;
        else k--;
    }
    for (int i=1;i<=n;i++)
        if (v[i]==cand) ap++;
    if (ap>n/2)
        fout<<cand<<" "<<ap;
    else
        fout<<"-1";
    return 0;
}
