#include <fstream>
#include <vector>

#include <iostream>

int main() {
    std::ifstream in("elmaj.in");
    int n;
    in >> n;
    std::vector<int> v(n);
    for (int i = 0; i < n; i ++) {
        in >> v[i];
    }
    in.close();

    srand(time(NULL));
    int elmaj, nr_ap;
    while (true) {
        elmaj = v[rand() % n];
        nr_ap = 0;
        for (int x : v) {
            if (x == elmaj)
                nr_ap ++;
        }
        if (nr_ap > n / 2) {
            break;
        }
    }

    std::ofstream out("elmaj.out");
    out << elmaj << ' ' << nr_ap;
    out.close();
}
