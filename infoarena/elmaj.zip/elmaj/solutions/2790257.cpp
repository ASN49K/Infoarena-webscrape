#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[1000002], n;
int ct;
int main()
{
    int i, x;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    nth_element(a+1, a+n/2, a+n+1);
    x=a[n/2];
    for (i=1;i <= n;i++)
        if (a[i] == x)
            ct++;
    if (ct > n / 2)
        fout << x << " " << ct << "\n";
    else
        fout << -1 << "\n";
    fout.close();
    return 0;
}
