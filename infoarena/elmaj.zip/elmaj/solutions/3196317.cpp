#include <iostream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
long long n,v[100010],k;
int candidat()
{
    int c=v[1],k=1;
    for(int i=2; i<=n; i++)
    {
        if(k==0)
        {
            c=v[i];
            k=1;
        }
        else
        {
            if(c!=v[i])
            {
                k--;
            }
            else
            {
                k++;
            }

        }
    }
    return c;
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    int x=candidat();
    if(x)
    {
        for(int i=1; i<=n; i++)
            if(v[i]==x)
                k++;
        if(k>n/2)
            fout<<x<<" "<<k;
        else
            fout<<-1;
    }
    else
    {
        fout<<-1;
    }
}
