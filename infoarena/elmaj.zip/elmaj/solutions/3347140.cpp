#include <iostream>

#define NMAX 1000000

void merge_sort(int *v, int n)
{
    int *w;

    if (n < 2)
        return;

    merge_sort(v, n / 2);
    merge_sort(v + n / 2, n - n / 2);

    w = new int[n];

    for (int i = 0, j = n / 2, k = 0; k < n; ++k)
        if (j >= n || (i < n / 2 && v[i] < v[j]))
            w[k] = v[i++];
        else
            w[k] = v[j++];

    for (int i = 0; i < n; ++i)
        v[i] = w[i];

    delete[] w;
}

int lower_bound(int *v, int n, int a)
{
    int l, r, m;

    l = 0;
    r = n - 1;

    while (l <= r) {
        m = l + ((r - l) >> 1);

        if (v[m] >= a)
            r = m - 1;
        else
            l = m + 1;
    }

    return l;
}

int upper_bound(int *v, int n, int a)
{
    int l, r, m;

    l = 0;
    r = n - 1;

    while (l <= r) {
        m = l + ((r - l) >> 1);

        if (v[m] <= a)
            l = m + 1;
        else
            r = m - 1;
    }

    return l;
}

int main()
{
    int n;
    int v[NMAX], a;
    int count;

    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);

    std::cin >> n;

    for (int i = 0; i < n; ++i)
        std::cin >> v[i];

    merge_sort(v, n);
    a = v[n / 2 /* + 1 - 1 */];
    count = upper_bound(v, n, a) - lower_bound(v, n, a);

    if (count < n / 2 + 1)
        std::cout << -1;
    else
        std::cout << a << ' ' << count << '\n';

    return 0;
}
