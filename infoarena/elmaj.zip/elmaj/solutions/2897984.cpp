#include <bits/stdc++.h>

using namespace std;

map <int,int> mp;
int n , x;

int main()
{
    freopen("elmaj.in" , "r" , stdin);
    freopen("elmaj.out" , "w" ,stdout);
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    cin >> n;
    for(int i = 1;i <= n; ++i){
        cin >> x;
        ++mp[x];
        if(mp.size() >= n/2 + 1){
            cout << -1;
            return 0;
        }
    }
    int maxx = -1,maxxval = 0;
    for(auto x:mp){
        if(maxx < x.second){
            maxx = x.second;
            maxxval = x.first;
        }
    }
    cout << maxxval << " " << maxx;
}

