#include <iostream>

using namespace std;

int l[100005],r[100005],a[100005],ciur[100005],mar[100005];

int main()
{

    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    int maj = a[1];
    int fr = 1;
    for(int i = 2; i <= n; i++) {
        if(a[i] == maj) {
            fr++;
        } else {
            fr--;
        }
        if(fr == 0) {
            maj = a[i];
            fr = 1;
        }
    }
    int cnt = 0,ii=0;
    for(int i = 1; i <= n; i++) {
        if(a[i] == maj) {
            cnt++;
        }
    }
    if(cnt >= n / 2 + 1)
    {
        cout<<maj<<" "<<cnt;
    }

    return 0;
}
