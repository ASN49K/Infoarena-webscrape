 
#include <fstream>
using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
long long int n,i,v[1000001],k=1,m=-1;
int main()
{
    fin>>n;
    for (i=1;i<=n;i++)
    {
        fin>>v[i];
        if (v[i]==m)
        k++;
        else k--;
        if (k==0)
        m=v[i];
    }
    k=0;
    for (i=1;i<=n;i++)
    {
        if (v[i]==m)
        k++;
    }
    if (k>n/2)
    fout<<m<<' '<<k;
    else fout<<"-1";
    return 0;
}