#include <fstream>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n, i, v[1000005], cand, nr, k;
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i];
    cand=-1;
    for(i=1; i<=n; i++)
    {
        if(k==0)
        {
            k=1;
            cand=v[i];
        }
        else if(cand==v[i])
            k++;
        else
            k--;
    }
    if(k<0)
    {
        fout<<-1;
        return 0;
    }
    for(i=1; i<=n; i++)
        if(v[i]==cand)
        nr++;
    if(nr>n/2)
        fout<<cand<<" "<<nr;
    else
        fout<<-1;
    return 0;
}
