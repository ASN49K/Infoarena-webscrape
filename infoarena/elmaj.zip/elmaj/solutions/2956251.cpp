#include <fstream>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n,v[1000000],nr,cnt=1;

int main()
{
    f>>n;
    f>>v[0];
    nr=v[0];
    for(int i=1; i<n; i++)
    {
        f>>v[i],cnt+=(v[i]==nr?1:-1);
        if(!cnt)
            cnt=1,nr=v[i];
    }
    cnt=0;
    for(int i=0; i<n; i++)
        cnt+=v[i]==nr;
    if(cnt>n/2)g<<nr<<' '<<cnt;
    else g<<"-1";
    return 0;
}
