#include <fstream>
#include <algorithm>
#define N 1000005
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[N], n;
int maj, ct;

int main()
{
    int i;

    fin >> n;
    for(i=1; i<=n; i++)
    {
        fin >> a[i];
        if(ct==0)
        {
            maj=a[i];
            ct=1;
        }
        else if(a[i]==maj)
            ct++;
        else
            ct--;
    }

    ct=0;
    for(i=1; i<=n; i++)
        if(a[i]==maj)
        ct++;
    if(ct >=n/2+1 )
         fout << maj <<" "<< ct;
    else
        fout <<-1;
    return 0;
}
