#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

void f(int n,int a[],int s,int db){
    for (int i=1; i<=n; i++)
    {
    if (db==0){s=a[i];db++;}
    else if (a[i]==s) db++;
    else db--;
    }
    if (s>0){
    db=0;
    for (int i=1; i<=n; i++){
    if (a[i]==s) db++;
    }
    if (db>=n/2+1) fout<<s<<" "<<db;
    }
    else fout<<-1;
}

int main()
{
    int n,s=0,db=0;
    fin>>n;
    int a[n+1];
    for(int i=1;i<=n;i++){
        fin>>a[i];
    }
    f(n,a,s,db);
    return 0;
}
