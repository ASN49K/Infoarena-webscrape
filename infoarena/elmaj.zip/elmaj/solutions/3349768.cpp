#include <fstream>
#include <vector>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int main() {


    int n;
    cin >> n;

    vector<long long> v(n);

    long long cand = 0;
    int cnt = 0;

    for (int i = 0; i < n; i++) {
        cin >> v[i];

        if (cnt == 0) {
            cand = v[i];
            cnt = 1;
        } else if (v[i] == cand) {
            cnt++;
        } else {
            cnt--;
        }
    }

    int cnt2 = 0;
    for (int i = 0; i < n; i++) {
        if (v[i] == cand) cnt2++;
    }

    if (cnt2 >= n / 2 + 1) {
        cout << cand << " " << cnt2;
    } else {
        cout << -1;
    }

    return 0;
}