#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int v[1000001];
int main()
{
    int n, x=-1, ct=-1, nr, m=0;
    fin >> n;
    for (int i=1; i<=n; ++i) {
        fin >> nr;
        v[i]=nr;
        if (nr==x) {
            ct++;
        }
        else
            ct--;
        if (ct<0) {
            x=nr;
            ct=0;
        }

    }
    for (int i=1; i<=n; ++i) {
        if (v[i]==x) {
            m++;
        }
    }
    if (m>=n/2+1) {
        fout << x << ' ' << m;
    }
    else
        fout << -1;
    return 0;
}
