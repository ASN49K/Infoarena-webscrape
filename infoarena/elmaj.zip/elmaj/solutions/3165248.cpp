#include <iostream>
#include <cstdio>

using namespace std;

static constexpr int NMAX = ((int)(1e6) + 1);

int a[NMAX];

namespace InParser
{
    static constexpr int BSIZE = (1 << 16);

    static int pos = (BSIZE - 1);
    static char buff[BSIZE];

    static inline char Char()
    {
        ++pos;

        if (pos == BSIZE)
        {
            pos = 0;

            int n = fread(buff, 1, BSIZE, stdin);
            if (n != BSIZE)
                for (int i = n; i < BSIZE; ++i)
                    buff[i] = 0;
        }

        return buff[pos];
    }

    inline int Int()
    {
        int ans = 0;

        for (;;)
        {
            char Ch = Char();

            if (Ch >= '0' && Ch <= '9')
            {
                ans = (int)(Ch - '0');
                break;
            }
        }

        for (;;)
        {
            char Ch = Char();

            if (Ch >= '0' && Ch <= '9')
                ans = ans * 10 + (int)(Ch - '0');
            else
                break;
        }

        return ans;
    }
};

int main()
{
    ios_base ::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);

    int n = InParser ::Int();

    int candidate = -1, votes = 0;

    for (int i = 1; i <= n; ++i)
    {
        int x = InParser ::Int();
        a[i] = x;

        if (i == 1)
            candidate = x, votes = 1;
        else
        {
            if (x == candidate)
                ++votes;
            else
                --votes;

            if (votes < 0)
                candidate = x, votes = 1;
        }
    }

    int cnts = 0;
    for (int i = 1; i <= n; ++i)
        if (a[i] == candidate)
            ++cnts;

    if (cnts >= ((n >> 1) + 1))
        printf("%d %d\n", candidate, cnts);
    else
        printf("-1\n");

    return 0;
}
