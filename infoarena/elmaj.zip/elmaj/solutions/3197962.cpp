#include <fstream>
#include <algorithm>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int v[1000001];
int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>v[i];
    }
    sort(v+1, v+n+1);
    int candidat=v[n/2], f=0;
    for(int i=1; i<=n; i++)
    {
        if(v[i]==candidat)
            f++;
    }
    if(f>=n/2+1)
        out<<candidat<<" "<<f;
    else
        out<<-1;

}
