#include <bits/stdc++.h>
using namespace std;
/**
Algoritmi randomizati

NP-complete
*/
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[1000002], n;
int main()
{
    int i, x, cnt;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    srand(time(0));
    for (int pas = 1; pas <= 10; pas++)
    {
        x = rand() % n + 1;
        cnt = 0;
        x = a[x];
        for (i = 1; i <= n; i++)
            if (a[i] == x) cnt++;
        if (cnt > n / 2)
        {
            fout << x << " " << cnt << "\n";
            fout.close();
            return 0;
        }
    }
    fout << "-1\n";
    fout.close();
    return 0;
}
