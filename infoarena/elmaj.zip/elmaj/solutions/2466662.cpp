#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,x[1000005],i,aux,k=0;
int main(){
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>x[i];
        if(!k){
            aux=k;
            k++;
        }
        if(aux==x[i])
            k++;
        else
            k--;
    }
    fout<<aux << " ";
    k=0;
    for(i=1;i<=n;i++)
        if(aux==x[i])
            k++;
    fout << k;

return 0;
}
