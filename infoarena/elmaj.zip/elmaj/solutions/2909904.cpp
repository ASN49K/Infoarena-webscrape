#include <algorithm>
#include <fstream>
#include <iostream>
using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

const int N = 1000001;

int v[N], n;

int main() {
    int i;
    in >> n;
    for (i = 1; i <= n; ++i) {
        in >> v[i];
    }
    sort(v + 1, v + n);
    int maj = v[1 + n / 2];
    // cout << maj << endl;
    int ct = 0;
    for (int i = 1; i <= n; i++) ct += (v[i] == maj);
    if (ct < n / 2 + 1) {
        out << -1 << endl;
    } else {
        out << v[1 + n / 2] << " " << ct << endl;
    }
    return 0;
}