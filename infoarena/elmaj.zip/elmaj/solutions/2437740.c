#include <iostream>
#include <fstream>
#define N 10001
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[N],n;
void Citire()
{
    int i;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i];

}
void Elmaj()
{
    int i;
    int cand, vot=0;
    cand=a[1];
    vot=1;
    for(i=2;i<=n;i++)
       if(vot==0) {cand=a[i];vot=1;}
       else if(cand!=a[i]) vot--;
             else vot++;
   vot=0;
   for(i=1;i<=n;i++)
    if(a[i]==cand)vot++;

   if(vot>n/2) fout<<cand<<" "<<vot;
   else fout<<-1;

}
int main()
{
   Citire();
   Elmaj();
    return 0;
}
