#include <fstream>

using namespace std;
const int NMAX= 1000000;
int v[NMAX];

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    int n, candidat, nrap, i;
    in >> n >> v[0];
    candidat = v[0];
    nrap = 1;
    for(i = 1; i <n; i++)
    {
        in >> v[i];
        if(v[i] == candidat)
        {
            nrap++;
        }
        else nrap--;
        if(nrap == 0)
        {
            candidat = v[i];
            nrap = 1;
        }
    }
    nrap = 0;
    for(i = 0; i < n; i++)
    {
        if(v[i] == candidat)
        {
            nrap++;
        }
    }
    if(nrap > n/2)
    {
        out << candidat << " " << nrap;
    }
    else out << "-1";
    return 0;
}
