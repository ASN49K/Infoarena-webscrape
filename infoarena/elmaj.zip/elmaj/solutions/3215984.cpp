#include <bits/stdc++.h>

using namespace std;

ifstream fin("interclasare.in");
ofstream fout("interclasare.out");

int n, contor, elmaj, aparitii;
vector<int> v;

int main()
{
    fin >> n;

    int a;
    for(int i = 0; i < n; i++){
        fin >> a;
        v.push_back(a);
    }

    for(int i = 0; i < n; i++)
    {
        if(contor == 0){
            elmaj = v[i];
            contor = 1;
        }
        else{
            if(elmaj == v[i])
                contor++;
            else
                contor--;
        }
    }

    for(int i = 0; i < n; i++)
        if(v[i] == elmaj)
            aparitii++;

    if(aparitii >= n/2 + 1)
        fout<<elmaj<<' '<<aparitii;
    else
        fout<<-1;
}
