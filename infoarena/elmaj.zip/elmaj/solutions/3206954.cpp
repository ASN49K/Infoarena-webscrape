//https://infoarena.ro/problema/elmaj
#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main()
{
    int n,x,i;
    fin>>n;
    fin>>x;
    int can=x;
    int rep=1;
    for(i=2;i<=n;i++)
    {
        fin>>x;
        if(x==can)
        {
            rep++;
        }
        else
        {
            rep--;
        }
        if(rep<0)
        {
            can=x;
        }
    }
    fin.close();
    fin.open("elmaj.in");
    fin>>x;
    rep=0;
    for(i=1;i<=n;i++)
    {
        fin>>x;
        if(x==can)
        {
            rep++;
        }
    }
    fout<<can<<" "<<rep;
    return 0;
}
