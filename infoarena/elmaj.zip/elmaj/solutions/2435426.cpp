#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#define modu 999983
std::ifstream fin("elmaj.in");
std::ofstream fout("elmaj.out");
int n,j,k;
std::vector<int> v[1005000],c[1005000];
int maxx;
int maxp;

int main()
{
  fin>>n;
  k=n;
  while(k--)
  {
    fin>>j;
    int l = std::find(v[j%modu].begin(),v[j%modu].end(),j)-v[j%modu].begin();
    if(l!=v[j%modu].end()-v[j%modu].begin())
      c[j%modu][l]++;
    else
    {
      v[j%modu].push_back(j);
      c[j%modu].push_back(1);
    }
  }
  for(int i=0;i<999983;i++)
    for(j=0;j<v[i].size();j++)
      if(c[i][j]>maxx)
      {
        maxx=c[i][j];
        maxp=v[i][j];
      }
  if(maxx>=n/2+1)
    fout<<maxp<<" "<<maxx;
  else
    fout<<-1;
}
