#include <bits/stdc++.h>
using namespace std;

#define NMAX 1000005
#define problem "elmaj"

pair<int, int> solve(int left, int right, int *v) {
	if (left == right)
		return {v[left], 1};
	
	int mid = left + (right - left) / 2;

	pair<int, int> left_ans = solve(left, mid, v), right_ans = solve(mid + 1, right, v);
	
	if (left_ans == right_ans)
		return {left_ans.first, left_ans.second + right_ans.second};
	
	int cnt_left = 0, cnt_right = 0;
	for (int i = left; i <= right; ++i) {
		cnt_left += v[i] == left_ans.first;
		cnt_right += v[i] == right_ans.first;
	}

	if (cnt_left < (right - left + 1) / 2 && cnt_right < (right - left + 1) / 2) {
		puts("-1");
		exit(0);
	}
	
	return cnt_left > cnt_right ? make_pair(left_ans.first, cnt_left) : make_pair(right_ans.first, cnt_right);
}

int main()
{
	freopen(problem ".in", "r", stdin);
	freopen(problem ".out", "w", stdout);

	int n, v[NMAX];
	scanf("%d", &n);

	for (int i = 0; i < n; ++i)
		scanf("%d", &v[i]);

	pair<int, int> ans = solve(0, n - 1, v);

	printf("%d %d\n", ans.first, ans.second);
}