#include <fstream>

using namespace std;
int v[1000000];
int main()
{
    ifstream cin ("elmaj.in");
    ofstream cout ("elmaj.out");
    int n, i, a, nr, sol, solnr;
    cin>>n;
    for (int i=0; i<n; i++)
        cin>>v[i];
    for (int i=0; i<n; i++)
    {
        nr=0;
        for (int j=0; j<n; j++)
        {
            if (v[j]==v[i])
                nr++;
        }
        if  (nr>n/2)
        {
            sol=v[i];
            solnr=nr;
        }
    }
    cout<<sol<<" "<<solnr;
    return 0;
}
