#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,a[1000000],ans,k,nr;
int main(){
    fin>>n;
    for(int i=1;i<=n;i++)fin>>a[i];
    for(int i=1;i<=n;i++){
        if(k==0)nr=a[i],k=1;
        else if(a[i]==nr)k++;
        else k--;
    }
    int b=0;
    for(int i=1;i<=n;i++){
        if(a[i]==nr)b++;
    }
    if(b>n/2)fout<<nr << ' ' <<b;
    else fout << -1;
return 0;
}
// 3 4 4 3 3 2 3
