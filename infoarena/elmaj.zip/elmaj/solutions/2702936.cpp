#include <fstream>

using namespace std;

long long int v[200000001];

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int main()
{
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    int bestOption=v[1];
    int bestFrequency=1;
    for(int i=2;i<=n;i++)
    {
        if(v[i]==bestOption)
            bestFrequency+=1;
        else if(v[i]!=bestOption && bestFrequency>1)
            bestFrequency-=1;
        else if(v[i]!=bestOption && bestFrequency == 1)
            bestOption = v[i];
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(v[i]==bestOption)
            cnt+=1;
    }
    if(cnt>=n/2+1)
        fout<<bestOption<<cnt;
    else
        fout<<-1;
}
