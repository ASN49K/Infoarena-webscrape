#include <bits/stdc++.h>
#include <stack>
using namespace std;

ifstream fin  ("elmaj.in");
ofstream fout ("elmaj.out");

int main()
{
    int nr,n;
    fin>>nr;
    fin>>n;
    int can=n,k=1,i;
    for(i=2;i<=nr;i++)
    {
        fin>>n;
        if(can==n)
        {
            k++;
        }
        else
        {
            k--;
        }
        if(k<=0)
        {
            k=0;
            can=n;
        }
        //cout<<can<<" "<<k<<"\n";
    }
    //cout<<can;
    fin.close();
    fin.open("elmaj.in");
    k=0;
    fin>>nr;
    for(i=1;i<=nr;i++)
    {
        fin>>n;
        if(n==can)
        {
            k++;
        }
    }
    if(k>=nr/2+1)
    {
        fout<<can<<" "<<k;
    }
    else
    {
        fout<<"-1";
    }

    return 0;
}
