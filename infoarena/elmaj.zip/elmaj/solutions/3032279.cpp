#include <bits/stdc++.h>
using ll=long long;
#define S second
#define F first
#define endl '\n'
#define spid ios_base::sync_with_stdio(false);cin.tie(NULL);
const int mod=1e9+7;
const double pi=3.14159265359;
const int maxn=1000001;
using namespace std;

int n,sw=0,ans;

unordered_map<int,int> A;

int main(){
	ifstream cin("elmaj.in");
	ofstream cout("elmaj.out");
	cin>>n;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		A[x]++;
	}
	int cnt=0;
	for(auto it:A){
		if(it.S>=n/2+1){
			sw=1;
			ans=it.F;
			cnt=it.S;
		}
	}
	if(sw)cout<<ans<<" "<<cnt<<endl;
	else cout<<-1<<endl;
}

