#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int f1(int n,int v[],int &db1){
    int p=-1;
    for(int i=1;i<=n;i++){
        int db2=0;
        for(int j=i;j<=n;j++){
            if(v[i]==v[j]) db2++;
        }
        if(db1==db2 && p!=v[i]) return -1;
        else if(db2>db1) {p=v[i];db1=db2;}
    }
    return p;
}

int main()
{
    int n,db1=0;
    fin>>n;
    int v[n];
    for(int i=1;i<=n;i++){
        fin>>v[i];
    }
    fout<<f1(n,v,db1)<<" "<<db1;
    return 0;
}
