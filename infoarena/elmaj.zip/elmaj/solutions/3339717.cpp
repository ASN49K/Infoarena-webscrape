#include <bits/stdc++.h>
#define cin fin
#define cout fout
#define int long long
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
const int nmax=100005;
int v[nmax];
int32_t main()
{
    int n;
    cin>>n;
    int voturi=0;
    int nr_candidat=-1;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        if(voturi==0)
        {
            voturi=1;
            nr_candidat=v[i];
        }
        else if(nr_candidat==v[i])
        {
            voturi++;
        }
        else{
            voturi--;
        }
    }
    if(voturi<0){
        cout<<-1;
        return 0;
    }
    else if(voturi>0)
    {
        int frec=0;
        for(int i=1;i<=n;i++)
        {
            if(v[i]==nr_candidat)
                frec++;
        }
        if(frec>=(n/2)+1)
            cout<<nr_candidat<<" "<<frec;
        else
            cout<<-1;
    }
}
