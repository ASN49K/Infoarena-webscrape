#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("paranteze2.in");
ofstream fout("paranteze2.out");
int n,i,nrd,nri,mx;
char c[256];
int main()
{
    fin>>c;
    n=strlen(c);
    for (i=0;i<=n-1;i++)
    {
        if (c[i]=='(') nrd++;
        else if (c[i]==')') nri++;
        if ((nrd-nri)>mx) mx=(nrd-nri);
    }
    fout<<mx;
    return 0;
}
