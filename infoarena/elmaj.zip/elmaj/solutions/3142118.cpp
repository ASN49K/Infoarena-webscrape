#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n , v[1000005] , fr , elem;

int main(){
    fin>>n;
    for(int i=1 ; i<=n ; i++)
        fin>>v[i];
    fr=1;
    elem=v[1];
    for(int i=2 ; i<=n ; i++){
        if(v[i]==elem){
            fr++;
        }
        else{
            fr--;
        }
        if(fr == 0){
            elem=v[i];
            fr=1;
        }
    }
    if(fr == 0){
        fout<<-1;
    }
    else{
        fr=0;
        for(int i=1 ; i<=n ; i++)
            if(v[i] == elem){
                fr++;
            }
        if(fr>n/2){
            fout<<elem<<' '<<fr;
        }
        else{
            fout<<-1;
        }
    }
    return 0;
}