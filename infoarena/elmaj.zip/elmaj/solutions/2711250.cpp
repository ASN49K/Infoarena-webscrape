#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n, a[1000005];
int main()
{
    f>>n;
    int nr, ap=0, ct=0;
    for(int i=1; i<=n; i++)
    {
        f>>a[i];
        if(ap==0)
        {
            nr=a[i];
            ap++;
        }
        else if(a[i]!=nr)
            ap--;
        else ap++;
    }
    for(int i=1; i<=n; i++)
        if(a[i]==nr)
            ct++;
    if(ct>n/2)
        g<<nr<<' '<<ct;
    else g<<-1;
    return 0;
}
