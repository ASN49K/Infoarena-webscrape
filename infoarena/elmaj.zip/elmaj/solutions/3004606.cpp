#include <fstream>
#include <unordered_map>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int n , x , cand , k;

unordered_map <int,int> um;

int main(){

    cin >> n;

    for(int i = 1 ; i <= n ; i++){

        cin >> x;

        um[x]++;

        if(!k){

            cand = x;

            k++;

            continue;
        }

        if(x == cand) k++;
        else k--;
    }

    if(um[cand] > n/2){

        cout << cand << ' ' << um[cand];

        return 0;
    }

    cout << -1;

    return 0;
}
