#include <iostream>
using namespace std;

int n, v[30005], m[30005][30005], i1 = 0, j1 = 1;

int main(){
    cin>>n;
    v[0] = -1;
    for (int i = 1; i <= n; i++){
        cin>>v[i];
        if (v[i - 1] + 1 == v[i]){
            j1++;
            m[i1][j1] = v[i];
        }
        else{
            i1++;
            j1 = 1;
            m[i1][j1] = v[i];
        }
    }
    cout<<i1<<" ";
}
