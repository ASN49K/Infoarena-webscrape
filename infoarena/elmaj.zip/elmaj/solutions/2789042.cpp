#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100003;

int v[NMAX];

int main()
{
    freopen("elmaj.in","r",stdin);
    freopen("elmaj.out","w",stdout);
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++)
        cin >> v[i];
    int element_mojoritar = v[1];
    int cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(cnt == 0)
            element_mojoritar = v[i];
        if(v[i] == element_mojoritar)
            cnt++;
        else
            cnt--;
    }
    cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(v[i] == element_mojoritar)
            cnt++;
    }
    if(cnt < n/2+1) cout << -1 ;
    else cout << element_mojoritar << ' ' << cnt;


    return 0;
}

