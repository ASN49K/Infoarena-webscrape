#include <iostream>
#include <fstream>

using namespace std;

int x[1000001];

ifstream in ("elmaj.in");
ofstream out ("elmaj.out");

int main()
{
    int candidat=0, nr=1, n;
    in>>n;
    for(int i=0;i<n;i++)
    {
        in>>x[i];
        if(x[i]==candidat)
        {
            nr++;
        }
        else
        {
            if(nr==1)
                candidat=x[i];
            else
                nr--;
        }
    }
    nr=0;
    for(int i=0;i<n;i++)
        if(x[i]==candidat)
            nr++;
    out<<candidat<<" "<<nr;
    return 0;
}
