#include <fstream>
#include <iostream>
using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

const int N=1000001;
int contor;
int v[N],n;
int quick (int li, int ls)
{
    int aux,i,j,i1,j1;
    i1=0;
    j1=-1;
    i=li;j=ls;
    while (i<j)
    {
        if (v[i]>v[j])
        {
            aux=v[i];
            v[i]=v[j];
            v[j]=aux;
            aux=i1;
            i1=-j1;
            j1=-aux;
        }
        i+=i1;
        j+=j1;
    }
    return i;
}
void dei (int li, int ls)
{
    if (li<ls)
     {
          int k;
          k=quick(li,ls);
          dei (li,k-1);
          dei (k+1,ls);
     }

}
int elmaj (int n, int v[])
{
    dei(1,n);
    int i = 0;
    while (i < n)
    {
        int j=i;
        while ((j<n) && (v[j+1] == v[i]))
              j++;
        if (n/2<j-i+1){
            contor=j-i+1;
              return v[i];
        }
        i= j + 1;
    }
    return -1;
}
int main(){
	int i;
	in>>n;
	for(i=1;i<=n;++i){
		in>>v[i];
	}
	out<<elmaj(n,v);
	out<<" "<<contor;
	return 0;
}
