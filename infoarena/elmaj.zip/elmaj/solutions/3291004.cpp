#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n,k,cand,v[1000200];

int32_t main()
{
    f>>n;
    for(int i=1; i<=n; i++)
        f>>v[i];
    for(int i=1; i<=n; i++)
    {
        if(k==0)
            k=1, cand=v[i];
        else if(v[i]!=cand)
            k--;
        else if(v[i]==cand)
            k++;
    }
    k=0;
    for(int i=1; i<=n; i++)
        if(v[i]==cand)
            k++;
    if(k>=n/2+1)
        g<<cand<<' '<<k;
    else
        g<<-1;
    return 0;
}
