#include <fstream>
#include <unordered_map>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

unordered_map <int, int> f;

int main()
{
  int n, val, ans = 0, fans = 0;
  in >> n;
  for(int i = 1;i <= n;i++){
    in >> val;
    f[val]++;
    if(fans < f[val]){
      ans = val;
      fans = f[val];
    }
  }
  if(fans >= n / 2 + 1){
    out << ans << ' ' << fans;
  }else{
    out << -1;
  }
  return 0;
}
