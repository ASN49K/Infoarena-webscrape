#include <fstream>
using namespace std;

int main()
{
    ifstream f("elmaj.in");
    ofstream g("elmaj.out");
    long long n,x,w[1000005]={0},w_frec[1000005]={0},l=0;
    f>>n;
    for(int c=1;c<=n;c++)
    {
        f>>x;
        int ok=0;
        for(int i=1;i<=l;i++)
        {
            if(w[i]==x)
            {
                w_frec[i]++;
                ok=1;
                break;
            }
        }
        if(ok==0)
        {
            l++;
            w[l]=x;
            w_frec[l]++;
        }
    }
    for(int i=1;i<=l;i++)
        if(w_frec[i]>=(n+1)/2)
            g<<w[i]<<" "<<w_frec[i];
}