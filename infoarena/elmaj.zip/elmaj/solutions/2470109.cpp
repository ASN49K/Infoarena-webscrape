#include <fstream>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int ap[1000005];
int main()
{
    int i, n,k;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>k;
        ap[k]++;
    }
    for(i=1;i<=n;i++)
    {
        if(ap[i]>=n/2+1) fout<<i<<" ";
    }
    return 0;
}
