#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
unsigned v[1000001];

int main()
{
    int n;
    unsigned a;
    fin>>n;
    unsigned maxim=0;
    for (int i=0; i<n; i++)
    {
        fin>>a;
        v[a]++;
    }
    for (int i=0; i<n; i++)
    {
        if (v[i]>maxim)
            maxim=i;
    }
    fout<<maxim<<' '<<v[maxim];
    return 0;
}
