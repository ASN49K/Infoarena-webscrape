#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int NMAX = 1e6 + 1;
int a[NMAX];

int32_t main()
{
    int n;
    fin >> n;
    int elmaj = 0, cnt = 0, k = 0;
    for(int i = 1; i <= n; i++)
    {
        fin >> a[i];
        if(k == 0)
        {
            k++;
            elmaj = a[i];
        }
        else
        {
            if(a[i] == elmaj)
                k++;
            else
                k--;
        }
    }
    cnt = 0;
    for(int i = 1; i <= n; i++)
    {
        if(elmaj == a[i])
            cnt++;
    }

    if(cnt > n / 2)
        fout << elmaj << " " << cnt;
    else
        fout << -1;

    return 0;
}
