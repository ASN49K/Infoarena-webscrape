#include <fstream>
using namespace std;

ifstream cin ("elmaj.in");
ofstream cout ("elmaj.out");

int v[1000005];

int main() {
  int n,candidat,cnt=0,aparitii=0;
  cin>>n;
  for (int i=0; i<n; i++) {
    cin>>v[i];
  }
  for (int i=0; i<n; i++) {
    if (cnt==0) {
      candidat=v[i];
      cnt=1;
    }
    else {
      if (candidat==v[i]) cnt++;
      else cnt--;
    }
  }
  for (int i=0; i<n; i++) {
    if (candidat==v[i]) aparitii++;
  }
  if (aparitii<n/2+1) cout<<-1;
  else cout<<candidat<<' '<<aparitii;
}