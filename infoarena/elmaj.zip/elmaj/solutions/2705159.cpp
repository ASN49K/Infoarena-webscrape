#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,v[1000001],k;
int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
        fin >> v[i];
    sort(v+1,v+n+1);
    k=1;
    for(int i=2;i<=n;i++)
    {
        if(v[i]==v[i-1])
            k++;
        else
        {
            if(k>=n/2+1)
            {
                fout << v[i-1] << " " << k;
                return 0;
            }
            k=1;
        }
    }
    fout << "-1";
    return 0;
}
