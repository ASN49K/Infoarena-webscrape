#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1000001], n;

int cnt, crt;

int main()
{
    cin>>n>>v[0];
    crt=v[0];
    cnt=1;
    for (int i=1;i<n;++i)
    {
        cin>>v[i];
        if(v[i]==crt)
            ++cnt;
        else
            --cnt;
        if(cnt<=0)
            crt=v[i], cnt=0;
    }
    int fr=0;
    for (int i=0;i<n;++i)
        if(v[i]==crt)
            fr++;
    if (fr>=n/2+1)
        cout<<crt<<' '<<fr<<'\n';
    else
        cout<<-1;
    return 0;
}
