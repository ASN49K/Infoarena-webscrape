#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#include <cstring>
#include <deque>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int DIM = 1000005;

int v[DIM],n,x,elm,nrap;

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>x;
        v[i]=x;
        if(i==1)
        {
            elm=x;
            nrap=1;
        }
        else
        {
            if(x==elm)
                nrap++;
            else
                nrap--;
            if(!nrap)
            {
                elm=x;
                nrap=1;
            }
        }
    }
    nrap=0;
    for(int i=1;i<=n;i++)
    {
        if(v[i]==elm)
            nrap++;
    }
    if(nrap>=n/2+1)
        fout<<elm<<" "<<nrap<<'\n';
    else
        fout<<-1<<'\n';
}
