#include <fstream>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n,cnt=1,nr,k,p=0,i,v[1000001];
int main()
{

    f>>n;
    for (i=1;i<=n;i++)
    {
        f>>v[i];
    }
    nr=v[1];
    for (i=2;i<=n;i++)
    {
        if (v[i]!=nr)
        {
            cnt--;
        }
        else
        if (v[i]==nr)
        {
            cnt++;
        }
        if (cnt<0)
        {
            cnt=0;
            nr=v[i];
        }
    }
    k=nr;
    for (i=1;i<=n;i++)
    {
        if (k==v[i])
        {
            p++;
        }
    }
    if (p>n/2)
    {
        g<<k<<" "<<p;
    }
    else
    {
        g<<"-1";
    }
    return 0;
}
