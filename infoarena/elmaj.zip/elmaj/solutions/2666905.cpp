#include <bits/stdc++.h>
#define HASH_KEY 666013

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

vector<vector<pair<int, int>>> hash_vec{HASH_KEY};

int isInHash(int x) {
    for (int i = 0; i < hash_vec[(x % HASH_KEY)].size(); ++i) {
        if (hash_vec[(x % HASH_KEY)][i].first == x) {
            return hash_vec[(x % HASH_KEY)][i].second;
        }
    }
    return 0;
}

void setInHash(int x, int value) {
    if (isInHash(x)) {
        for (int i = 0; i < hash_vec[(x % HASH_KEY)].size(); ++i) {
            if (hash_vec[(x % HASH_KEY)][i].first == x) {
                hash_vec[(x % HASH_KEY)][i].second = value;
            }
        }
    } else {
        hash_vec[(x % HASH_KEY)].push_back({x, value});
    }
}

int main() {
    int N;
    fin >> N;
    for (int x, i = 0; i < N; ++i) {
        fin >> x;
        int val = isInHash(x);
        setInHash(x, val + 1);
    }

    for (int i = 0; i < hash_vec.size(); ++i) {
        for (int j = 0; j < hash_vec[i].size(); ++j) {
            if (hash_vec[i][j].second >= (N / 2 + 1)) {
                fout << hash_vec[i][j].first << ' ' << hash_vec[i][j].second << '\n';
                return 0;
            }
        }
    }
    fout << -1 << '\n';
    return 0;
}