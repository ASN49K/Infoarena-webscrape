#include <bits/stdc++.h>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
const int lim=1e6+3;
int v[lim],n;
int main()
{
    in>>n;
    for(int i=1;i<=n;++i)
        in>>v[i];
    int maj=v[1],app=1;
    for(int i=2;i<=n;++i)
    if(v[i]==maj) ++app;
    else
    {
        --app;
        if(app<0)
            maj=v[i],
            app=1;
    }
    app=0;
    for(int i=1;i<=n;++i)
    if(v[i]==maj) ++app;
    if(app>n/2)
        out<<maj<<' '<<app<<'\n';
    else out<<-1<<'\n';
    return 0;
}
