#include <stdio.h>
#include <stdlib.h>

int v[1000000];

int main() {
  FILE *fin, *fout;
  fin = fopen( "elmaj.in", "r" );
  fout = fopen( "elmaj.out", "w" );
  int a, k, n, i;
  fscanf( fin, "%d", &n );
  fscanf( fin, "%d", &v[0] );
  a = v[0];
  k = 1;
  for( i = 1; i < n; i++ ) {
    fscanf( fin, "%d", &v[i] );
    if( k == 0 )
      a = v[i];
    if( v[i] != a )
      k--;
    else
      k++;
  }
  k = 0;
  for( i = 0; i < n; i++ )
    if( v[i] == a )
      k++;
  if( k > n / 2 )
    fprintf( fout, "%d %d ", a, k );
  else
    fprintf( fout, "-1" );
  return 0;
}
