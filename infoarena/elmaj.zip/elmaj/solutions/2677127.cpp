/*
                `-/oo+/-   ``
              .oyhhhhhhyo.`od
             +hhhhyyoooos. h/
            +hhyso++oosy- /s
           .yoooossyyo:``-y`
            ..----.` ``.-/+:.`
                   `````..-::/.
                  `..```.-::///`
                 `-.....--::::/:
                `.......--::////:
               `...`....---:::://:
             `......``..--:::::///:`
            `---.......--:::::////+/`
            ----------::::::/::///++:
            ----:---:::::///////////:`
            .----::::::////////////:-`
            `----::::::::::/::::::::-
             `.-----:::::::::::::::-
               ...----:::::::::/:-`
                 `.---::/+osss+:`
                   ``.:://///-.
*/
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <cmath>	
#define debug(x) cerr << #x << " " << x << "\n"
#define debugsp(x) cerr << #x << " " << x << " "

using namespace std;

const int INF = 2e9;
const int N = 1e6;

int v[1 + N];

int main() {
  freopen("elmaj.in", "r", stdin);
  freopen("elmaj.out", "w", stdout);
  int n, x, cnt, elem;
  scanf("%d%d", &n, &x);

  elem = x;
  cnt = 1;
  for(int i = 2; i <= n; i++) {
    scanf("%d", &x);
    v[i] = x;
    
    if(x == elem) cnt++;
    else {
      cnt--;

      if(cnt == 0) {
        elem = x;
        cnt = 1;
      }
    }
  }

  cnt = 0;
  for(int i = 1; i <= n; i++) {
    if(v[i] == elem) ++cnt;
  }

  if(cnt >= n / 2 + 1) printf("%d %d\n", elem, cnt);
  else printf("-1\n");

  fclose(stdin);
  fclose(stdout);
  return 0;
}
