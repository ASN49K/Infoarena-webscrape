#include <iostream>
#include <fstream>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
#define MAX 1000000
int v[MAX+1];
int main()
{
    int n,i,voturi,candidat;
    in>>n;
    for(i=0; i<n; i++)
     in>>v[i];

    candidat=-1;
    voturi=0;
    for(i=0; i<n; i++)
    {
        if(voturi==0)
        {
            candidat=v[i];
            voturi=1;
        }
        else if(v[i]==candidat)
            voturi++;
        else
            voturi--;
    }
    voturi=0;
    for(i=0; i<n; i++)
    {
        if(v[i]==candidat)
            voturi++;
    }
    if(voturi<n/2+1)
        candidat=-1;
    if(candidat==-1)
        out<<-1;
    else
        out<<candidat<<" "<<voturi;
    return 0;
}
