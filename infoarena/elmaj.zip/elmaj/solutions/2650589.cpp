#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, a[1000005];

int main()
{
    int i, k = 0, nr = -1, ap = 0;
    fin >> n;
    for(i = 1; i <= n; i++)
    {
        fin >> a[i];
        if(k == 0)
        {
            nr = a[i];
            k = 1;
        }
        else if(a[i] == nr)
            k++;
        else k--;
    }
    for(i = 1; i <= n; i++)
        if(a[i] == nr)
            ap++;
    if(ap > n / 2)
        fout << nr << " " << ap << "\n";
    else
        fout << "-1\n";
    return 0;
}
