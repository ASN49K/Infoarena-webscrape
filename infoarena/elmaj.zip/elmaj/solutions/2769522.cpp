#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
string __fname = "elmaj"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define sz(x)(int) x.size()
#define pb(x) push_back(x)
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define ss cout << " "
#define nn cout << "\n"
#define ct(x) cout << (x)
#define cts(x) cout << (x) << " "
#define ctn(x) cout << (x) << "\n"
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
#define rt return
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
const double pi = 3.14159265359;
const int64 mod = 1000000007;
const int64 hash_p = 101;
const int64 hash_inv = 940594066;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};

void solve(int id){

    rt;
}


int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); ct(fixed); ct(setprecision(10)); 
    vector <int> freq (1e6); // freq[i] -> de cate ori apare elemetul I in array
    int n;
    cin >> n;
    vector <int> a (n);
    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        a[i] = x;
        freq[x]++;
    }
    for (int i = 0; i < n; i++){
        int nr = freq[a[i]];
        if (nr >= n / 2 + 1) {
            cout << a[i] << " " << nr << "\n";
            break;
        }
    }
    rt 0;
}