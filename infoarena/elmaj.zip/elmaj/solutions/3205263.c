#include <stdio.h>
#include <math.h>

int v[3000000];

int main(){
    FILE *fin, *fout;
    int n, i, nr, maj;
    fin=fopen("elmaj.in", "r");
    fscanf(fin, "%d", &n);
    for(i=0; i<n; i++)
      fscanf(fin, "%d", &v[i]);
    fclose(fin);
    maj=v[0];
    nr=1;
    i=1;
    while(i<n && nr<=n/2){
        if(v[i]==maj)
            nr++;
        else{
            nr--;
            if(nr<0){
                maj=v[i];
                nr=1;
            }
        }
        i++;
    }
    fout=fopen("majoritar.out", "w");
    nr=0;
    for(i=0; i<n; i++)
        if(v[i]==maj)
            nr++;
    fout=fopen("elamj.out", "w");
    if(nr>n/2)
        fprintf(fout, "%d %d", maj, nr);
    else
        fprintf(fout, "-1");
    fclose(fout);
    return 0;
}
