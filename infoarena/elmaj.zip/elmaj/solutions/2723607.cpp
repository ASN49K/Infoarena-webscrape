#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[1000001];
int N, x, elem, ap;

int main(){

	f >> N >> v[1];
	elem = v[1], ap = 1;
	for(int i = 2;i <= N;i++){
		f >> v[i];
		if(elem != v[i])
			ap--;
		else ap++;

		if(ap == 0)
			elem = v[i], ap = 1; 
	}

	ap = 0;
	for(int i = 1;i <= N;i++)
		if(elem == v[i]) ap++;
	g << elem << " " << ap;
}