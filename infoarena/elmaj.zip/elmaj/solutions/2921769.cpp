#include <fstream>
#include <iostream>
#include <unordered_map>
#include <algorithm>
using namespace std;
 
 
int main(){
	ifstream fin;
	ofstream fout;
	fin.open("elmaj.in");
	fout.open("elmaj.out"); 
	int n, x;
 	fin >> n;
 	int answer = -1;
 	unordered_map<int, int> data;

	for(int i = 1; i <= n; ++i){
		if(answer == -1){
			fin >> x;
			data[x]++;
			if(data[x] >= n/2 + 1){
				answer = x;
			}
		}
		else{
			fin >> x;
			if(x == answer)
				data[x]++;
		}
	}

	if(answer != -1)
		fout << x << " " << data[x];
	else
		fout << -1;
}