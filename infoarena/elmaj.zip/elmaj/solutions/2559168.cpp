#include <iostream>
#include <fstream>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int v[1000000];

int main()
{
    int n,i,candidat=0,nr=1;
    in>>n;
    for(i=0;i<n;i++){
        in>>v[i];
        if(v[i]==candidat){
            nr++;
        }
        else{
            if(nr==1){
                candidat=v[i];
            }
            else{
                nr--;
            }
        }
    }
    nr=0;
    for(i=0;i<n;i++){
        if(v[i]==candidat){
            nr++;
        }
    }
    if(nr>=n/2+1){
        out<<candidat<<" "<<nr;
    }
    else{
        out<<"-1";
    }
    in.close();
    out.close();
    return 0;
}
