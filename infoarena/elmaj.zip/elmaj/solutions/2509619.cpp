#include <fstream>
using namespace std;
ifstream in ("elmaj.in");
ofstream out("elmaj.out");
int maj[1000001];
int main()
{
    int n, nr, ap, i;
    in>>n;
    for (i=1; i<=n; i++)
        in>>maj[i];
    nr=-1;
    ap=0;
    for (i=1; i<=n; i++)
    {
        if (ap==0)
            nr=maj[i];
        else if (maj[i]==nr)
            ap++;
        else
            ap--;
    }
    ap=0;
    for (i=1; i<=n; i++)
        if (maj[i]==nr)
            ap++;
    if (ap<=(n/2))
        nr=-1;
    out<<nr<<'\n'<<ap;
    return 0;
}
