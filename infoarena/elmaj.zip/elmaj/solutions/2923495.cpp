#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin ("elmaj.in");
ofstream cout ("elmaj.out");
int n , v[1000001] , maj , ap;
int main()
{
    cin >> n;
    for(int i = 1 ; i <= n ; ++i)
        cin >> v[i];
    sort(v+1 , v+n+1);
    for(int i = 1 ; i <= n ; ++i)
    {
        int j = i;
        for(; j <= n && v[j] == v[i] ; ++j);
        if(j-i > n/2)
        {
            maj = v[i];
            ap = j-i;
        }
        i = j - 1;
    }
    cout << maj <<' ' << ap;
}
