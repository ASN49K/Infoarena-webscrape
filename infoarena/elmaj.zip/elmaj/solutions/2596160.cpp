#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1000005],n,j,nr,elmaj;

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
    }
    sort(v+1,v+n+1);
    for(int i=1;i<=n/2+1;i++){
        if(v[i]==v[n/2+i]){
            j=n/2+i;
            while(v[i]==v[j]){
                j++;
            }
            j--;
            if(nr<j-i+1){
                elmaj=v[i];
                nr=j-i+1;
            }
            i=j;
        }
    }
    cout<<elmaj<<" "<<nr;
    return 0;
}
