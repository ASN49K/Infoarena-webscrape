#include <stdio.h>
#include <ctype.h>
int v[1000000];
int readInt( FILE *fin ) {
    int nr, ch;
    while ( !( isdigit( ch = fgetc( fin ) ) ) );
    nr = 0;
    do {
        nr = nr * 10 + ch -'0';
    } while ( isdigit( ch = fgetc( fin ) ) );
    return nr;
}
int main() {
  FILE *fin, *fout;
  int n, i, nr, maj;

  // citire vector
  fin = fopen( "majoritar.in", "r" );
  fscanf( fin, "%d", &n );
  for ( i = 0; i < n; i++ )
    v[i] = readInt( fin );
  fclose( fin );

  // cautam candidatul la element majoritar
  maj = v[0];
  nr = 1;
  for ( i = 1; i < n; i++ )
    if ( v[i] == maj ) // cita vreme avem maj incrementam numarul de maj gasite
      nr++;
    else {
      nr--;            // altfel decrementam numarul de maj
      if ( nr < 0 ) {  // daca am scazut sub zero
        maj = v[i];    // alegem drept candidat elementul curent
        nr = 1;        // care apare o data
      }
    }

  // verificare candidat la element majoritar
  nr = 0;
  for ( i = 0; i < n; i++ ) // numaram de cit ori apare maj in vector
    if ( v[i] == maj )
      nr++;

  fout = fopen ( "majoritar.out", "w" );
  if ( nr > n / 2 ) // daca maj apare de mai mult de n/2 ori este majoritar
    fprintf( fout, "%d %d\n", maj, nr );
  else
    fprintf( fout, "-1\n" );
  fclose( fout );
}