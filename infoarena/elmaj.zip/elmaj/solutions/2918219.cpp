#include <bits/stdc++.h>

#define nmax 1000001
using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n,v[nmax];
int main()
{
    f>>n;
    int el=-1,nr=0;
    for(int i=0;i<n;i++)
    {
        f>>v[i];
        if(el==-1)
        {
            el=v[i];
            nr=1;
        }
        else if(el==v[i]) nr++;
        else
        {
            nr--;
            if(nr==0)
            {
                el=v[i];
                nr=1;
            }
        }
    }
    int cnt=0;
    for(int i=0;i<n;i++)
    {
        if(v[i]==el) cnt++;
    }
    if(cnt>=n/2+1) g<<el<<' '<<cnt;
    else g<<-1;
    return 0;
}
