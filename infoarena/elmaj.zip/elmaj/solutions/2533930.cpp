#include <fstream>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000007];
int main()
{
    int n,curr,x,app;
    cin>>n>>v[1];
    curr=v[1];
    app=1;
    for(int i=2;i<=n;++i)
    {
        cin>>v[i];
        if(v[i]==curr)
            ++app;
        else
        {
            if(app)
                --app;
            else curr=v[i];
        }
    }
    app=0;
    for(int i=1;i<=n;++i)
    if(v[i]==curr)
    app++;
    if(app>=n/2+1)
        cout<<curr<<' '<<app;
    else cout<<-1;
    return 0;
}
