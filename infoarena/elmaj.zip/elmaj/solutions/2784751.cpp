#include <bits/stdc++.h>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int n;
int v[1000005];

void habar_nu_am_de_ce_nu_e_in_main_asta()
{
    int cand=-1,nr=0;
    in>>n;
    for(int i=1;i<=n;i++)
    {
        in>>v[i];
        if(nr==0)
        {
            cand=v[i];
            nr++;
        }
        else
        {
            if(cand==v[i])
                nr++;
            else
                nr--;
        }
    }
    nr=0;
    for(int i=1;i<=n;i++)
        if(v[i]==cand)
            nr++;
    if(nr>n/2)
        out<<cand<<' '<<nr;
    else
        out<<-1;
}

int main()
{
    habar_nu_am_de_ce_nu_e_in_main_asta();
    return 0;
}
