#include <bits/stdc++.h>

using namespace std;
int n,i,x,a[100005],contor,nr;
int main()
{
    cin >> n;
    for (i=1; i<=n; i++) cin >> a[i];
    for (i=1; i<=n; i++)
    {
        if (contor==0)
        {
            x=a[i];
            contor=1;
        }
        else
        {
            if (a[i]==x)
            {
                contor ++;
            }
            else contor--;
        }
    }
    for (i=1; i<=n; i++) if (a[i]==x) nr++;
    cout << x << " " << nr;
    return 0;
}
