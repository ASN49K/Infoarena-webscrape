#include <bits/stdc++.h>
using namespace std;
/**
Algoritmi randomizati

NP-complete
*/
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[1000002], n;
int main()
{
    int i, x, cnt;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    nth_element(a + 1, a + n / 2, a + n + 1); /// O(n)
    cnt = 0;
    x = a[n / 2];
    for (i = 1; i <= n; i++)
        if (a[i] == x) cnt++;
    if (cnt > n / 2) fout << x << " " << cnt << "\n";
    else fout << "-1\n";
    fout.close();
    return 0;
}
