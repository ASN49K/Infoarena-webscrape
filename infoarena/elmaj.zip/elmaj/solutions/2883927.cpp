#define d(x) std::cout << x << std::endl
#define dm(msg, x) std::cout << msg << x << std::endl

#define all(a) a.begin(), a.end()
#define range(a, l, r) a.begin() + l, a.begin() + r
#define aall(a, n) a + 1, a + 1 + n
#define arange(a, l, r) a + l, a + r
	
#define maxself(a, b) a = std::max(a, b);
#define minself(a, b) a = std::min(a, b);

#define inout(f) std::ifstream in((f) + (std::string) ".in");std::ofstream out((f) + (std::string) ".out")

#include <iostream>
#include <fstream>

const int NMAX = 1e6;

int n;
int a[1 + NMAX];

int main() {
  inout("elmaj");

  in >> n;

  for (int i = 1; i <= n; ++i)
    in >> a[i];
  
  int cBest = -1;
  int cnt = 1;

  for (int i = 1; i <= n; ++i) {
    if (a[i] == cBest) {
      ++cnt;
      continue;
    }

    --cnt; 
    if (cnt == 0)
      cBest = a[i], cnt = 1;
  }

  cnt = 0;
  for (int i = 1; i <= n; ++i) {
    if (a[i] == cBest)
      ++cnt;
  }

  if (cnt > n / 2) 
    out << cBest << ' ' << cnt << '\n';
  else
    out << "-1\n";

  return 0;
}