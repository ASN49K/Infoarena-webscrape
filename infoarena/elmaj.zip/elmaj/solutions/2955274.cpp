#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int x, n, freq[100001], maxx, nmax, nr;

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> x;
        if(x > nmax)
            nmax = x;
        freq[x]++;
    }
    for(int i = 1; i <= nmax; i++)
    {
        if(freq[i] > maxx)
            maxx = i, nr = freq[i];
    }
    if(nr >= n / 2 + 1)
        cout << maxx << " " << nr;
    else
        cout << -1;
    return 0;
}
