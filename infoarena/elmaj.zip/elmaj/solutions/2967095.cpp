#include <fstream>
using namespace std;
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n,a,cnt=0,retin=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a;
        if(cnt==0)
        {
            cnt++;
            retin=a;
        }
        else
        {
            if(a==retin)
                cnt++;
            else
                cnt--;
        }
    }
    cin.close();
    ifstream cin1("elmaj.in");
    cin1>>n;
    int counter=0;
    for(int i=1;i<=n;i++)
    {
        cin1>>a;
        if(a==retin)
            counter++;
    }
    if(counter>=n/2)
        cout<<retin<<" "<<counter;
    return 0;
}
