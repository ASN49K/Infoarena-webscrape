#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) (a).begin(), (a).end()
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define rc(s) return cout<<s,0
#define pi pair <int, int>
#define sz(x) (int)((x).size())
#define int long long

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

const ll inf = 2e9;
const ll mod = 998244353;
const int N = 1e6 + 11;
const int NMAX = 1e4 + 11;
const ll INF64 = 3e18 + 1;
const double eps = 1e-14;
const double PI = acos(-1);

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int n, a[N];

void solve(){

    in >> n;

    int cnt = 0, f = 0, el = -1;

    for(int i = 1, x; i <= n; i++){
        in >> a[i];

        if(!cnt){
            cnt++;
            el = a[i];
        }else
        if(a[i] == el)cnt++;else cnt--;
    }


    for(int i = 1; i <= n; i++){
        if(a[i] == el)f++;
    }

    if(f <= n/2){
        out << "-1";
        return;
    }

    out << el << ' ' << f;

}

int32_t main(){
ios_base :: sync_with_stdio(0); cin.tie(); cout.tie();

    //cout << setprecision(20) << fixed;

    int t = 1;
   // cin >> t;
    while(t--){
        solve();
    }
}
