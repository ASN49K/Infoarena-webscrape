// #include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
	ifstream cin("elmaj.in");
	ofstream cout("elmaj.out");

	// citire
	int n; cin >> n;
	vector<int> v(n);
	for (int i = 0; i < v.size(); i++) {
		cin >> v[i];
	}

	// determinarea candidatului
	int candidat = v[0];
	int dif = 0;

	for (int i = 0; i < v.size(); i++) {
		dif += (v[i] == candidat ? 1 : -1);
		if (dif == 0) {
			candidat = v[i];
			dif = 1;
		}
	}

	// verificare candidat
	int cnt = 0;
	for (int i = 0; i < v.size(); i++) {
		cnt += (v[i] == candidat);
	}

	if (cnt > n / 2) {
		cout << candidat << " " << cnt << "\n";
	} else {
		cout << "-1\n";
	}

	return 0;
}