#include <fstream>

using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int n,x[1000001],f[1000001],p,Max;
int main()
{
    in>>n;
    for(int i=1; i<=n; i++)
        in>>x[i],f[x[i]]++;
    for(int i=1; i<=n; i++)
        if(f[x[i]]>Max)
            Max=f[x[i]],p=x[i];
    out<<p<<" "<<Max;
}
