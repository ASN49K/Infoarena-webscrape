#include <iostream>
#include <fstream>
#include <random>
#include <ctime>
#include <cstdlib>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[3000010];
int k,n;
int part(int st,int dr,int indexPiv)
{
    int pivotVal = a[indexPiv];
    swap(a[dr],a[indexPiv]);
    int pIndex=st;
    for(int i = st;i<dr;i++)
        if(a[i]<pivotVal)
            swap(a[i],a[pIndex++]);
    swap(a[dr],a[pIndex]);
    return pIndex;
}
int quickSelect(int st,int dr)
{
    if(st<=dr)
    {
        int randomIndex = st + rand()%(dr-st+1);
        int pIndex = part(st,dr,randomIndex);

        if(pIndex==k)
        {
            return a[pIndex];
        }
        if(pIndex>k)
        {
            quickSelect(st,pIndex-1);
        }
        else
            quickSelect(pIndex+1,dr);
    }
}
int countTimes(int x)
{
    int counter=0;
    for(int i=1;i<=n;i++)
        if(x==a[i])
            counter++;
    return counter;
}
int main()
{
    fin>>n;
    k = n/2+1;
    for(int i = 1;i<=n;i++)
        fin>>a[i];

    int var = quickSelect(1,n);
    int counter = countTimes(var);
    if(counter>=k)
        fout<<var<<" "<<counter<<'\n';
    else
        fout<<-1<<'\n';
    return 0;
}
