#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>


//conventii v - vector, d[i] cate astfel de elemente s-au gasit deja, c[i] credite de cautare
//element initial 2 credite
//element diferit -1 credit
//element identic +2 credit

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

void Search(int i, int val, int cred, int desc);

int n;
vector<int> v, d;

int solNo, solCount;

int main() {
    fin>>n;
    d.resize(n, 0);
    v.resize(n, 0);
    for (int i = 0; i < n; i++) {
        fin>>v[i];
    }

    for (int i = 0; i < n; i++) {
        if (d[i] == 0) Search(i, v[i], 0, 0);}

    d = vector<int>(n, 0);

    reverse(v.begin(), v.end());

    for (int i = 0; i < n; i++)
        if (d[i] == 0) Search(i, v[i], 0, 0);

    if (solNo == 0) fout<<-1<<'\n';
    else fout<<solNo<<' '<<solCount;
}

void Search(int i, int val, int cred, int desc) {
    if (v[i] == val) {
        desc+= 2;
        d[i] = desc;
        cred++;
    } else cred--;

    if (desc > n/2) {
        solNo = val;
        solCount = desc;
        return;
    }

    if (i < n - 1 && cred != 0) Search(i + 1, val, cred, desc);
}
