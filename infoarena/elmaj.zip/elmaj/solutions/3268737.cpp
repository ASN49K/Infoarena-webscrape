#include <fstream>
#include <unordered_map>
#define NMAX 1000002
using namespace std;
ifstream  fin("elmaj.in");
ofstream fout("elmaj.out");
int N,v[NMAX];
unordered_map<int,int> M;

void citire()
{
    fin>>N;

    for(int i=1; i<=N; i++)
    {
        fin>>v[i];
    }
}

int main()
{
    citire();

    for(int i=1; i<=N; i++)
    {
        M[v[i]]++;
    }

    for(auto x:M)
    {
        if(x.second>=N/2+1)
        {
            fout<< x.first << " " << x.second << "\n";
            return 0;
        }
    }

    fout<< -1 << "\n";

    return 0;
}
