#include <fstream>

using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000001];
int main()
{
    int n,i,cnt=0,elmaj;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i];
        if(cnt==0)
        {
            elmaj=v[i];
            cnt=1;
        }
        if(v[i]!=elmaj)
           cnt--;
        else
            cnt++;
    }
    cnt=0;
    for(i=1;i<=n;i++)
    {
        if(elmaj==v[i])
           cnt++;
    }
    if(cnt>=n/2+1)
       cout<<elmaj<<" "<<cnt;
    else
        cout<<-1;
    return 0;
}
