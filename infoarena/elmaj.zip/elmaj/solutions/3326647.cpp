#include <fstream>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int a[1000001];

int main()
{
    int n,c=0,cnt=0,fr=0;
    cin >> n;

    for (int i = 0; i < n; ++i)
    {
        cin >> a[i];
    }

    for (int i = 0; i < n; ++i)
    {
        if (cnt == 0)
        {
            c = a[i];
            cnt = 1;
        }
        else if (a[i] == c)
        {
            cnt++;
        }
        else
        {
            cnt--;
        }
    }
    for (int i = 0; i < n; ++i)
    {
        if (a[i] == c)
        {
            fr++;
        }
    }

    if (fr >= n / 2 + 1)
    {
        cout << c << " " << fr <<endl;
    }
    else
    {
        cout << -1 << endl;
    }

    return 0;
}
