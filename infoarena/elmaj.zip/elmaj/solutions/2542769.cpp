using namespace std;



#define fisier "elmaj"

#ifdef fisier
    #include <fstream>
    ifstream in(fisier ".in");
    ofstream out(fisier ".out");
#else
    #include <iostream>
    #define in cin
    #define out cout
#endif



const int MAX_N = 1000000;

int
n,
id_uri,
cu_id[MAX_N],
frecv[MAX_N];



int main() {

    int i, id, iter;

    in >> n;

    for (i = 0; i < n; i++) {

        in >> iter;

        for (id = 0; id < id_uri; id++) {

            if (cu_id[id] == iter) {

                break;

            }

        }

        if (id == id_uri) {

            cu_id[id_uri++] = iter;

        }

        frecv[id]++;

    }



    n = n/2 + 1;

    for (id = 0; id < id_uri; id++) {

        if (frecv[id] >= n) {

            out << cu_id[id] << ' ' << frecv[id];

            return 0;

        }

    }

    out << -1;

}









//
