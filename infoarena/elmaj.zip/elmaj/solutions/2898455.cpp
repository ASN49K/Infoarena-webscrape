#include<fstream>
using namespace std;ifstream fin("elmaj.in");ofstream fout("elmaj.out");int v[1000000],n,x;int main(){fin>>n;for(int i=0;i<n;i++){fin>>x;v[x]++;}int ma=v[0],nr;for(int i=0;i<1000000;i++)if(v[i]>ma)ma=v[i],nr=i;fout<<nr<<' '<<ma;}
