/// Solutie O(n)#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");ofstream g("elmaj.out");const int NMAX = 1e6;int v[NMAX + 1];int n, cand, k, nr;
int main()
{	f >> n;	for (int i = 1; i <= n; i++)		f >> v[i];	for (int i = 1; i <= n; i++)		if (k == 0)		{			cand = v[i];			k = 1;		}		else		if (v[i] == cand)			k++;		else			k--;	if (cand == 0)		g << -1 << '\n';	else	{		int nr = 0;		for (int i = 1; i <= n; i++)			if (v[i] == cand)				nr++;		if (nr > (n >> 1))			g << cand << ' ' << nr << '\n';		else			g << -1 << '\n';	}	f.close();	g.close();
    return 0;
}
