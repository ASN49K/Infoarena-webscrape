#include <iostream>
#include <fstream>
#define O 1000005
using namespace std;

int a[O];

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main()
{
    int n,b,c=1,i;
    fin>>n;
    for(i=0;i<n;i++)
        fin>>a[i];
    b=a[0];
    for(i=1;i<n;i++)
        if(a[i]==b)
            c++;
        else
            if(c>1)
                c--;
            else
                b=a[i];
    c=0;
    for(i=0;i<n;i++)
        if(a[i]==b)
            c++;
    if(c>=n/2+1)
        fout<<b<<' '<<c;
    else
        fout<<-1;    return 0;
}
