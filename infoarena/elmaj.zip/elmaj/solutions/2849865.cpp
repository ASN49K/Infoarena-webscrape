#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int i, j, n, m, G, sol, maxim, maximap, nr, v[1000005], ok;
int main () {
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>v[i];
    sort(v+1, v+n+1);
    nr=1;
    for(i=2;i<=n;i++){
        if(v[i]==v[i-1])
            nr++;
        else{
            if(nr>=n/2+1){
                maxim=v[i-1];
                maximap=nr;
                ok=1;
            }
            nr=1;
        }
    }
    if(ok==0){
        cout<<-1;
        return 0;
    }
    cout<<maxim<<" "<<maximap;

}
