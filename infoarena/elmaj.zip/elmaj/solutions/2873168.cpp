#include <fstream>

using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int n,a[1000001],i,nr1,x;
int elmaj(int n,int a[])
{
    int cand=-1,nr=0,nr1=0;
    for(int i=0;i<n;i++)
    {
        if(nr==0) {cand=a[i];nr=1;}
        else if(a[i]==cand) {nr++;}
        else nr--;
    }
    for(int i=0;i<=n;i++)
        if(a[i]==cand) nr1++;
    if(nr1>n/2) return cand;
    else return -1;
}
int main()
{
    cin>>n;
    for(i=0;i<n;i++) cin>>a[i];
    if(elmaj(n,a)==-1) cout<<-1;
    else
    {
        x=elmaj(n,a);
        cout<<x<<' ';
        for(i=0;i<n;i++)
            if(a[i]==x) nr1++;
        cout<<nr1;
    }
    return 0;
}
