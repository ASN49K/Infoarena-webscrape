#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int a[1000001];

int main()
{
    int n, nr = 0, cand = -1, i;
    fin >> n;
    for(i = 1; i <= n; i++)
    {
        fin >> a[i];
        if(nr == 0)
        {
            cand = a[i];
            nr = 1;
        }
        else
            if(a[i] == cand)
                nr++;
            else
                nr--;
    }
    if(nr == 0)
        fout << "-1";
    else
    {
        nr = 0;
        for(i = 1; i <= n; i++)
        {
            if(cand == a[i])
                nr++;
        }
        if(nr > n / 2)
            fout << cand << ' ' << nr;
        else
            fout << "-1";
    }
    return 0;
}
