#include <bits/stdc++.h>

using namespace std;

int v[1000001];
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n, ap = 1, elmaj = 0;
    cin >> n;
    for (int i = 1; i <= n; i++) {
      cin >> v[i];
      if (elmaj == v[i]) ap++;
      else {
       --ap;
       if (ap == 0) {
        elmaj = v[i];
        ap++;
       }
      }
    }
    ap = 0;
    for (int i = 1; i <= n; i++) {
      if (v[i] == elmaj) ap++;
    }
    if (ap >= n / 2 + 1) cout << elmaj << " " << ap;
    return 0;
}
