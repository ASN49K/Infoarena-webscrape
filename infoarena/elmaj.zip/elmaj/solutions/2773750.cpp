#include <iostream>
#include <stdio.h>
using namespace std;
const int NMAX = 1e5;

int v[NMAX];
int main() {
  FILE *fin, *fout;
  int n, i, ult, nr, k;
  fin = fopen ( "elmaj.in", "r" );
  fscanf ( fin, "%d", &n );
  ult = -1;
  k = 0;
  for ( i = 0; i < n; i++ ) {
    fscanf ( fin, "%d", &v[i] );
    if ( k == 0 ) {
      ult = v[i];
      k++;
    }
    else if ( v[i] == ult )
      k++;
    else
      k--;
  }
  fclose ( fin );
  nr = 0;
  for ( i = 0; i < n; i++ ) {
    if ( ult == v[i] )
      nr++;
  }
  fout = fopen ( "elmaj.out", "w" );
  if ( nr >= n / 2 + 1 )
    fprintf ( fout, "%d %d", ult, nr );
  else
    fprintf ( fout, "-1" );
  return 0;
}
