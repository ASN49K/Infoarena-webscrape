#include <iostream>
#include <fstream>

using namespace std;
int v[1000001];

int main()
{
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");

    int n, cnt = 1, elementMajoritar, k = 1, answer = 0;
    fin >> n;

    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
    }
    for (int i = 2; i <= n; ++i) {
        if (v[k] == v[i]) {
            elementMajoritar = v[k];
            cnt += 1;
        } else {
            cnt -= 1;
        }
        if (cnt == 0) {
            k = i;
            elementMajoritar = v[k];
            cnt = 1;
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (elementMajoritar == v[i]) {
            answer += 1;
        }
    }
    if (answer >= n/2 + 1) {
        fout << elementMajoritar << " " << answer;
    } else {
        fout << "-1 ";
    }



    return 0;
}
