#include<fstream>
#include<iostream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000001];

int main()
{
    int n, i, cntr = 0, el, ap = 0;
    fin>> n;

    for(i = 1; i <= n; i++)
        fin>> v[i];

    el = v[1];

    for(i = 2; i <= n; i++)
    {
        if(cntr == 0)
        {
            el = v[i];
            cntr = 1;
        }
        else if(el == v[i])
            cntr++;
        else
            cntr--;
    }

    for(i = 1; i <= n; i++)
    {
        if(v[i] == el)
            ap++;
    }

    if(ap < n/2+1)
        fout<<"-1";
    else
        fout<< el;

    fin.close();
    fout.close();
    return 0;
}
