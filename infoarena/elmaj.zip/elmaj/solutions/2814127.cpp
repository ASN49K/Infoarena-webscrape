
#include <fstream>

using namespace std;

ifstream cin ("elmaj.in");
ofstream cout ("elmaj.out");

int v[1000000];
int main(){
    int n, candidate, candidateCount;

    cin >> n;

    cin >> v[0];
    candidate = v[0], candidateCount = 1;

    for (int i = 1; i < n; ++i) {
        cin >> v[i];

        if (candidate == v[i]) candidateCount++;
            else candidateCount--;

        if (candidateCount == 0) {
            candidate = v[i];
            candidateCount = 1;
        }
    }

    candidateCount = 0;

    for (int i = 0; i < n; ++i)
        if (v[i] == candidate) candidateCount++;

    if (candidateCount >= n/2 + 1) cout << candidate << " " << candidateCount;
    else cout << -1;

    cin.close();
    cout.close();
    return 0;
}
