#include<fstream>
#include<map>
#include<algorithm>
using namespace std ;
ifstream cin("majoritar.in");
ofstream cout("majoritar.out");
int main(){

    map<long long , int > freq ; 
      int n ; 
       long long x ; 
         cin>>n;
           for(int i = 1 ; i <= n ; i ++ ){
              cin>>x;
               freq[x] ++ ; 
           }

   for(map<long long , int> :: iterator I = freq.begin();I!=freq.end();I++){
            if(freq[I->first] >= n/2 +1 ){
                cout<<I->first<< ' '<<I->second;
                 return 0 ; 
            }
   }

cout<<-1;



    return 0 ; 
}