#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int n;
int v[1000041];

int main()
{
    fin >> n;
    for (int i=0;i<n;i++)
    {
        fin >> v[i];
    }

    int val=-999, aux=0;
    for (int i=0;i<n-1;++i)
    {
        if (v[i]!=v[i]+1)
            i++;
        else if (v[i+1]!=val&&aux!=0)
            aux--;
        else if (v[i+1]==v[i]&&v[i+1]==val)
        {
            val=v[i];
            aux=1;
        }
    }
    int c=0;
    for (int i=0;i<n;++i)
    {
        if (v[i]==val)
            c++;
    }
    if (c>0)
        fout << c;
    else
        fout << "-1";
    return 0;
}
