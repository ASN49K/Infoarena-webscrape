#include <bits/stdc++.h>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
unordered_map <int, int> mp;
int main()
{
    int n, x;
    fin>>n;
    for (int i=1; i<=n; i++) {
        fin>>x;
        mp[x]++;
    }
    int element=-1;
    for (auto it=mp.begin(); it!=mp.end(); it++) {
        if (it->second>n/2) {
            element=it->first;
            break;
        }
    }
    if (element!=-1) fout<<element<<' '<<mp[element];
    else fout<<-1;
    return 0;
}