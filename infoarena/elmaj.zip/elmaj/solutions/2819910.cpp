#include <iostream>
#include <unordered_map>

using namespace std;

unordered_map<int, int> m;
int N, best = -1;

int main()
{
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);
    cin >> N;
    for(int i = 1; i <= N; i++) {
        int t;
        cin >> t;
        m[t]++;
        if(m[best] < m[t]) best = t;
    }

    if(m[best] >= N/2 + 1) {
        cout << best << " " << m[best];
    } else {
        cout << -1;
    }
}
