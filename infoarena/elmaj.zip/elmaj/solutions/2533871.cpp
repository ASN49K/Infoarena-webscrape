#include <fstream>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int main()
{
    int n,curr,x,app;
    cin>>n>>curr;
    app=1;
    for(int i=2;i<=n;++i)
    {
        cin>>x;
        if(x==curr)
            ++app;
        else
        {
            if(app)
                --app;
            else curr=x,app=1;
        }
    }
    if(app)
        cout<<curr<<' '<<n/2+app;
    else cout<<-1;
    return 0;
}
