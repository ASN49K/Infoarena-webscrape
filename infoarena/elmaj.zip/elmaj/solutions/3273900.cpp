#include <bits/stdc++.h>
using namespace std;
unsigned long long int put(int a, int x)
{
    if(x==0)
        return 1;
    else if(x==1)
        return a;
    else if(x%2==0)
        return put(a, x/2)*put(a, x/2);
    else
        return a*put(a, x/2)*put(a, x/2);
}
int v[1000005];
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n;
    cin>>n;
    for(int i=1; i<=n; i++)
	{
		cin>>v[i];
	}
	int cnt=0, candidat=0;
	for(int i=1; i<=n; i++)
	{
		if(cnt==0)
		{
			candidat=v[i];
			cnt=1;
		}
		else
		{
			if(v[i]==candidat)
				cnt++;
			else
				cnt--;
		}
	}
	cnt=0;
	for(int i=1; i<=n; i++)
	{
		if(v[i]==candidat)
			cnt++;
	}
	if(cnt>n/2)
		cout<<candidat<<" "<<cnt;
	else
		cout<<-1;
    return 0;
}
