#include <bits/stdc++.h>
using namespace std;
# define ll long long


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");

    int n;
    cin>>n;
    map<int,int> a;
    int cnt;

    for(int i = 0; i < n; i++){
        cin>>cnt;
        a[cnt]++;
    }
    pair<int,int> best = make_pair(-1,-1);
    for(auto [key,value]:a){
        if(value >= (n/2)+1){
            best.first = key;
            best.second = value;
            break;
        }
        //cout<<key<<" "<<value<<"\n";
    }

    if(best.first == -1){
        cout<<"-1 ";
    }else{
        cout<<best.first<<" "<<best.second<<"\n";
    }








    return 0;
}
