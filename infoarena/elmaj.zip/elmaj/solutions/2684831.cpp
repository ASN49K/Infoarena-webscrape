#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int LIM = 1000005;

int N;
int V[LIM];

void Read()
{
    fin >> N;


    for(int i = 0; i < N; i++)
        fin >> V[i];


    int contor = 0, candidat = 0, aparitii = 0;


    for(int i = 0; i < N; i++)
    {
          if(contor == 0)
        {
            candidat = V[i];
            contor = 1;
        }
        else
        {  if(V[i] == candidat)
                contor += 1;
            else
                contor -= 1;
        }
    }

     for(int i = 0; i < N; i++)
        if(V[i] == candidat)
            aparitii += 1;

     if(aparitii < N / 2 + 1)
        fout << "-1";
    else
        fout << candidat << " " << aparitii;
}

int main()
{
    Read();

    return 0;
}
