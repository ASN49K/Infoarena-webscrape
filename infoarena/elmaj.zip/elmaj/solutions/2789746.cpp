#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[1000002], n, cnt;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> a[i];
    nth_element(a+1, a+n/2, a+n+1);
    int x = a[n/2];
    for(int i = 1; i <= n; i++)
        if(a[i] == x)
            cnt++;
    if(cnt > n/2)
        fout << x << " " << cnt << "\n";
    else
        fout << "-1\n";

    return 0;
}
