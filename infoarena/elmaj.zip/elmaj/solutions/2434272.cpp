#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

const int NMAX = 1000005;
int n,a[NMAX],nr;

int mooreMajority(){
    int cand = -1, k = 0, i;

    for(i = 1 ; i <= n ; i++){
        if(k == 0){
            cand = a[i];
            k = 1;
        }else
            if(a[i] == cand){
                k++;
            }else
                k--;
    }

    if(cand < 0)
        return cand;
    nr = 0;
    for(i = 1 ; i <= n ; i++)
        if(a[i] == cand)
            nr++;
    if(nr > n / 2)
        return cand;
    return -1;

}

int main(){
    int i;
    f >> n;
    for(i = 1 ; i <= n ; i++)
        f >> a[i];
    int ans = mooreMajority();
    g << ans << " " ;
    if(ans != -1)
        g << nr;

    return 0;
}
