#include <fstream>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int v[1000001], x, n, nx;
int main()
{
    fin>>n;
    for (int i=1; i<=n; i++)
        fin>>v[i];
    for (int i=1; i<=n; i++)
    {
        if (x==0) {x++; nx=v[i];}
        else if (nx!=v[i]) x--;
        else x++;
    }
    if (x==0) {fout<<-1; return 0;}
    else
    {
        x=0;
        for (int i=1; i<=n; i++)
        {
            if (v[i]==nx) x++;
        }
        if (x>n/2) {fout<<nx<<' '<<x; return 0;}
        else {fout<<-1; return 0;}
    }
    return 0;
}
