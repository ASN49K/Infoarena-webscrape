#include <iostream>
#include <fstream>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
const int maxn = 1000005;
int v[maxn];
int main()
{
    int n;
    in >> n;
    int elmaj = 0;
    int cnt = 0;
    for(int i = 1; i <= n; i++)
    {
        int x;
        in >> x;
        v[i] = x;
        if(x == elmaj)
            cnt++;
        else
        {
            cnt--;
            if(cnt < 0)
            {
                elmaj = x;
                cnt++;
            }
        }
    }
    cnt = 0;
    for(int i = 1; i <= n; i++)
        if(v[i] == elmaj)
            cnt++;
    if(cnt <= (n / 2))
        out << -1;
    else
        out << elmaj << " " << cnt;
    out << "\n";
    return 0;
}
