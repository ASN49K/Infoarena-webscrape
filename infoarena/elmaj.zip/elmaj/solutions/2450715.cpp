#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) (a).begin(), (a).end()
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define forn(i,a,b) for (int i = a; i <= b; i++)
#define fi(i,a,b) for (int i = a; i < b; i++)
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
#define er erase
#define in insert
#define pi pair <int, int>
#define pii pair <pi, pi>
# define sz(x) (int)((x).size())
const int N=1e6+5;
int a[N],n,ans;

int32_t main(){
ios_base::sync_with_stdio(0); cin.tie(0); cerr.tie(0); cout.tie(0);
ifstream in("elmaj.in");
ofstream out("elmaj.out");
	cin>>n;
	forn(i,1,n)cin>>a[i];
	int lst=-1, k=0;
	forn(i,1,n){
		if(!k){
			lst=a[i];
			k++;
		}else if(a[i]==lst)k++;else k--;
	}
//	cout<<lst<<' '<<k;
	forn(i,1,n)if(lst==a[i])ans++;
	if(ans>n/2)cout<<lst<<' '<<ans;else cout<<"-1";
return 0;
}

