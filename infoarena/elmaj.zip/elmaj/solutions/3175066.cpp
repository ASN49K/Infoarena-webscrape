#include <bits/stdc++.h>
using namespace std;

int n, nr, elem, v[1000010];

int main()
{
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i];
        if(nr == 0)
            elem = v[i], nr++;
        else if(elem != v[i])
            nr--;
        else
            nr++;
    }

    int nr = 0;
    for(int i = 1; i <= n; i++)
        if(elem == v[i])
            nr++;

    cout << elem << ' ' << nr;

    return 0;
}
