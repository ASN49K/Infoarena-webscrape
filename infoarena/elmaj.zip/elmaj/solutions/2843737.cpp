#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, k, elem_maj, nr;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> nr;
        if(k > 0)
        {
            if(nr == elem_maj)
                ++k;
            else
                --k;
        }
        else
        {
            ++k;
            elem_maj = nr;
        }
    }
    fin.close();

    ifstream fin("elmaj.in");
    if(k<=0)
        fout << -1;
    else
    {
        k = 0;
        fin >> n;
        for(int i = 1; i <= n; i++)
        {
            fin >> nr;
            if(nr == elem_maj)
                ++k;
        }
        if(k >= n/2+1)
            fout << elem_maj << ' ' << k;
        else
            fout << -1;
    }

    return 0;
}
