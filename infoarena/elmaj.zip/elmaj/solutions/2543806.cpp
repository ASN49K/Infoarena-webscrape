#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, v[1000001];

int main()
{
    int i, ct=0, cand;
    fin >> n;
    for(i=1; i<=n; i++)
    {
        fin >> v[i];
        if(ct == 0)
            cand=v[i], ct=1;
        else
        {
            if(v[i] != cand)
                ct--;
            else ct++;
        }
    }

    ct=0;
    for(i=1; i<=n; i++)
        if(v[i] == cand)
            ct++;

    if(ct >= n/2+1)
        fout << cand << " " << ct;
    else fout << -1;
    return 0;
}
