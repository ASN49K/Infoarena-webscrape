#include <fstream>
const int NMAX=1000005;

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[NMAX];

int main()
{
    int n,nr;
    cin>>n;
    int majoritar=0,temp=1;
    for(int i=1;i<=n;i++)
    {
        cin>>nr;
        v[i]=nr;
        if(nr!=majoritar) temp--;
        if(temp==0)
        {
            majoritar=nr;
            temp=1;
        }
    }
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        ans+=(majoritar==v[i]);
    }
    if(ans>=n/2+1) cout<<majoritar<<" "<<ans<<endl;
    else cout<<-1<<endl;
    return 0;
}
