﻿#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, a[1000000];

void elementMajoritar()
{
	int cand = -1, k = 0, nr = 0;

	for (int i = 0; i < n; i++)
	{
		fin >> a[i];
		if (k == 0)
		{
			cand = a[i];
			k = 1;
		}
		else if (cand == a[i])
			k++;
		else
			k--;
	}
	
	if (cand < 0)
	{
		fout << cand;
		return;
	}

	for (int i = 0; i < n; i++)
		if (a[i] == cand)
			nr++;

	if (nr > n / 2)
		fout << cand << " " << nr;
	else
		fout << -1;
}

int main()
{
	fin >> n;
	elementMajoritar();
}