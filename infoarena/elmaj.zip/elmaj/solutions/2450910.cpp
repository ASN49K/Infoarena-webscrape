#include <fstream>

std::ifstream fin("elmaj.in");
std::ofstream fout("elmaj.out");

size_t v[1000000], N;

int main()
{
    fin >> N;

    for(size_t i = 1; i <= N; i++)
    {
        fin >> v[i];
    }

    size_t elmaj = 0, K = 0;

    for(size_t i = 1; i <= N; i++)
    {
        if(elmaj != v[i])
        {
            if(K == 0)
            {
                elmaj = v[i];
                K = 1;
            }
            else K--;
        }
        else K++;
    }

    K = 0;

    for(size_t i = 1; i <= N; i++)
    {
        if(v[i] == elmaj) K++;
    }

    if(K > N/2) fout << elmaj << " " << K;
    else fout << -1;
}
