#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int fr, x, n, elmaj;
int a[1000005], cnt;

int main()
{
	int i;
	fin >> n;
	fin >> a[1];
	elmaj = a[1];
	fr++;
	for (i = 2; i <= n; i++)
	{
		fin >> a[i];
		x = a[i];
		if (x == elmaj)fr++;
		else fr--;
		if (fr == 0)
		{
			elmaj = x;
			fr++;
		}
	}
	fout << elmaj << " ";
	for (i = 1; i <= n; i++)
		if (a[i] == elmaj)cnt++;
	fout << cnt;
	return 0;
}	