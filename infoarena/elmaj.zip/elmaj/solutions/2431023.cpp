#include <bits/stdc++.h> //JuniorMonster a.k.a Sho10
#define ll long long
#define all(a) (a).begin(), (a).end()
#define sz size
#define f first
#define s second
#define pb push_back
#define er erase
#define in insert
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define mod 1000000007
#define PI 3.14159265359
#define CODE_START  ios_base::sync_with_stdio();cin.tie(0);cout.tie(0);
using namespace std;
ll n,x;
vector<ll>v;
map<ll,ll>m;
int main(){
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    cin>>n;
    for(ll i=0;i<n;i++){
            cin>>x;
    v.pb(x);
    m[x]++;
    }
    ll ans=0;
    for(ll i=0;i<n;i++)
        ans=max(ans,m[v[i]]);
    if(ans<n/2+1){
        cout<<"-1";
        return 0;
    }
    for(ll i=0;i<n;i++)
    if(m[v[i]]==ans){
        cout<<v[i]<<' '<<m[v[i]];
        return 0;
    }
}
