/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <cstdio>
#include <iostream>
#include <map>

using namespace std;

map <int,int> m;
int mx,mxn,n,h;

int main()
{
    freopen("elmaj.in","r",stdin);
    freopen("elmaj.out","w",stdout);
    cin>>n;
    h=n/2+1;
    int nr;
    for(int i=1;i<=n;i++)
    {
        cin>>nr;
        m[nr]++;
        if(m[nr]>mx) {mx=m[nr];mxn=nr;}
        if(mx>=h) break;
        if(mx+(n-i)<h) {mx=-1; break;}
        
    }
    if(mx) cout<<mxn<<' '<<mx;
    else cout<<-1;
    return 0;
}
