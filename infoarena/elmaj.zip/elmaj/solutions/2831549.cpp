#include <fstream>

using namespace std;

const int NMAX = 1000000;

int v[1 + NMAX];

int main()
{
    ifstream in("elmaj.in");
    ofstream out("elmaj.out");
    int n;
    int frecNr = 1;
    in >> n;
    in >> v[1];
    int nr = v[1];
    for (int i = 2; i <= n; i++)
    {
        in >> v[i];
        if (v[i] != nr)
        {
            frecNr--;
            if (frecNr == 0)
            {
                frecNr = 1;
                nr = v[i];
            }
        }
        else
            frecNr++;
    }
    int aparitii = 0;
    for (int i = 1; i <= n; i++)
    {
        if (nr == v[i])
        {
            aparitii++;
        }
    }
    out << nr << ' ' << aparitii << '\n';
    return 0;
}
