#include <bits/stdc++.h>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

const int N = 1e6 + 5;

int a[N];

int main()
{
    usain_bolt();

    int n;

    fin >> n;
    for(int i = 1; i <= n; ++i) fin >> a[i];
    int chosen = a[1], f = 0;
    for(int i = 1; i <= n; ++i) {
        if(a[1] == chosen) ++f;
        else --f;
        if(f == 0) chosen = a[i], f = 1;
    }
    f = 0;
    for(int i = 1; i <= n; ++i) if(a[i] == chosen) ++f;
    if(f >= n / 2 + 1) fout << chosen << " " << f;
    else fout << "-1";
    return 0;
}
