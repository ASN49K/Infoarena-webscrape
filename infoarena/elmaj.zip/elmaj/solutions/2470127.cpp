#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int v[1000005],ap[1000005];
int main()
{
    int i,j, n,k,x,kMax,nr,found;
    fin>>n;
    k=0;
    for(i=1;i<=n;i++)
    {
        fin>>x;found = 0;
        for(j = 1; j <= k; ++j)
        {
            if(v[j] == x)
            {
                ap[j]++;
                found = 1;
            }
        }
        if(!found)
            {
                v[++k] = x;
                ap[k] = 1;
            }
    }
    for(int i = 1; i <= k; ++i)
        if(kMax < ap[i])
        {
            kMax = ap[i];
            nr = v[i];
        }

    if(kMax >=n/2+1)
        fout<<nr<<" "<<kMax<<"\n";
    else
        fout<<-1<<"\n";
    return 0;
}
