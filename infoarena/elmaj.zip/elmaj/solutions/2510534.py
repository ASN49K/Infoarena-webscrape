from pathlib import Path

t = Path("elmaj.in").read_text().split('\n')
n = int(t[0])
t = t[1].split(' ')

g = open("elmaj.out","w+")
#print(t)

dict = {}

for a in t:
    if a not in dict:
        dict[a]=1
    else:
        dict[a]+=1;

dict = {k:v for k,v in sorted(dict.items(), key=lambda i:i[1], reverse=True)}
a = (next(iter(dict)), next(iter(dict.values())))
#print(a)
if a[1] >= (n //2 + 1):
    g.write(a[0]+" "+str(a[1]))
else:
    g.write("-1")
g.close()
