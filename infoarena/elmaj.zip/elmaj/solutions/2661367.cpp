#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream be("elmaj.in");
ofstream ki("elmaj.out");

int solve(vector<int>a,int n,int &db)
{
    for(int i=0;i<n;i++)
    {
            int j=i;
        while(j<n && a[i]==a[j+1])
                j++;

        if(j-i+1>n/2){  db=j-i+1;
                        return a[i];
                        }

    }
    return 0;
}
int main()
{
    int n;
    be>>n;
    vector<int>a(n+1);
    for(int i=0;i<n;++i)
        be>>a[i];
    sort(a.begin(),a.end());
    int db=-1,s1;
    s1=solve(a,n,db);
    if(db==-1)ki<<db<<" ";
    else
    ki<<s1<<" "<<db;
    return 0;
}
