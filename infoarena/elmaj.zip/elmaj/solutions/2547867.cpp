#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int v[1000001];

int main()
{
    int n,k=0,maxim=-1;
    unsigned a;

    fin>>n;

    for (int i=0; i<n; i++)
    {
        fin>>a;
        v[a]++;
    }

    for (int i=0; i<n; i++)
    {
        if (v[i]>maxim)
            maxim=i;
    }

    for (int i=0; i<n; i++)
    {
        if (v[i]==v[maxim])
            k++;
    }

    if (k==1 || maxim==-1)
        fout<<maxim<<' '<<v[maxim];
    else fout << -1;

    return 0;
}
