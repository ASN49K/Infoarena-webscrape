#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int  n, a[1000001];

int main()
{
    fin >> n;
    for(int i = 0; i < n; ++i)
        fin >> a[i];
    int candidat_acum = a[0], de_cate_ori_apare = 1;
    for(int i = 1; i < n; ++i)
    {
        if(a[i] != candidat_acum)
        {
            candidat_acum = a[i];
            de_cate_ori_apare--;
        }
        else
            de_cate_ori_apare++;
    }
    int nr = 0;
    for(int i = 0; i < n; ++i)
        if(a[i] == candidat_acum)
            nr++;
    if(nr >= n / 2 + 1)
        fout << candidat_acum << ' ' << nr;
    else
        fout << -1;
    return 0;
}
