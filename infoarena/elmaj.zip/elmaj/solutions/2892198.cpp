#include <bits/stdc++.h>

using namespace std;

const string fisier = "elmaj";

ifstream fin (fisier + ".in");
ofstream fout (fisier + ".out");

void test_case() {
  int n; fin >> n;
  int ans = 0 , e = -1;
  unordered_map<int , int>mp;
  for(int i=0; i<n; i++){
    int x; fin >> x;
    mp[x] += 1;
    if (mp[x] > ans){
      ans = mp[x] , e = x;
    }
  }
  if (ans >= n / 2 + 1){
    fout << e << " " << ans;
  }
  else{
    fout << -1;
  }
}

int main(){
  ios_base::sync_with_stdio(false);
  int tests = 1;
  for (int tc=0; tc<tests; ++tc) {
    test_case();
  }
}
