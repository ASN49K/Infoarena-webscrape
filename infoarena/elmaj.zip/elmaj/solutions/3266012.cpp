#include <fstream>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <queue>




using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
unordered_map <int,int> m;

int main()
{
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);

    int n;

    int x;
    int cnt=0,val=-1;
    cin>>n;
    cin>>val;
    cnt=1;
    for(int i=2;i<=n;i++)
    {


        cin>>x;
        m[x]++;
        if(x==val)
        {
            cnt++;
        }
        else
        {
            cnt--;
        }
        if(cnt==0)
        {
            cnt=1;
            val=x;
        }
    }
    if(m[val]<n/2+1)
    {
        cout<<"-1";
        return 0;
    }
    cout<<val<<" "<<m[val];






    return 0;
}






