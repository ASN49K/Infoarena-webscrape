#include <bits/stdc++.h>
#define NMAX 1000001
using namespace std;
typedef long long ll;

string file="elmaj";

ifstream fin(file+".in");
ofstream fout(file+".out");

int n;
int a[NMAX];
int maj,prez;

int main()
{
    int i;
    fin>>n>>a[1]; prez=1;
    for(i=2;i<=n;i++)
    {
        fin>>a[i];
        if(a[i]==maj) prez++;
        else prez--;
        if(prez<=0)
        {
            maj=a[i];
            prez=1;
        }
    }
    prez=0;
    for(i=1;i<=n;i++)
    {
        if(maj==a[i]) prez++;
    }
    if(prez>=n/2+1){
    fout<<maj<<" "<<prez;}
    else fout<<-1;
    return 0;
}
