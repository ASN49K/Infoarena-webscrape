#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main() {

    vector<int> v;
    int n;
    fin >> n;
    for (int i = 1; i <= n; i++) {
        int x;
        fin >> x;
        v.push_back(x);
    }

    sort(v.begin(), v.end());

    int nr = 0, res = 0;
    for (int i = 0; i < v.size(); i++) {
        int r = upper_bound(v.begin(), v.end(), v[i]) - v.begin() - 1;
        int l = r - i + 1;
        if (l >= n/2 + 1) {
            res = l;
            nr = v[i];
        }
        i = r;
    }

    if (nr == 0) {
        fout << -1;
    } else
        fout << nr << ' ' << res;



    return 0;
}
