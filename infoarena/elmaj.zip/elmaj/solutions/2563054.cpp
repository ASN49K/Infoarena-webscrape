#include <fstream>
#define N 1000002

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[N];
int main()
{
    int n,x,nr=0;
    f>>n;
    for(int i=1;i<=n;++i)
    {
        f>>v[i];
        if(nr==0)
            x=v[i],++nr;
        else
            --nr;
    }
    nr=0;
    for(int i=1;i<=n;++i)
        if(v[i]==x) ++nr;
    if(nr>=n/2+1)
        g<<x<<' '<<nr<<'\n';
    else
        g<<-1<<'\n';
    f.close();
    g.close();
    return 0;
}
