#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");

int main()
{
     int elem;
     int k = 1;
     int n;
     f >> n;
     int v[n];
     f >> v[0];
     elem = v[0];
     for (int i = 1; i < n; i++)
     {
         f>>v[i];
         if(elem==v[i])
            k++;
         else
            k--;

         if(k==0)
            elem=v[i];
            k=1;

     }
     g << elem << ' ';
     int c=0;
     for (int i = 0; i < n; i++)
     {
         if (elem == v[i])
            c++;

     }
     g << c << ' ';
     return 0;



}
