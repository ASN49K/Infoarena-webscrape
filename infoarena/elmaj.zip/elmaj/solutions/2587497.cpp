#include <bits/stdc++.h>
using namespace std;

int main () {
    ifstream fin ("elmaj.in");
    ofstream fout ("elmaj.out");
    vector <int> v;

    int n, m, x, ap=0;
    fin >> n >> m;
    v.push_back(m);
    int k=n>>1;

    for (--n; n; n--) {
        cin >> x;
        v.push_back(x);
        if (x==m)
            ap++;
        else {
            ap--;
            if (!ap)
                ap=1,
                m=x;
        }
    }

    for (auto it: v)
        if (it==m)
            ap++;
    if (ap>k)
        fout << m << ' ' << ap;
    else
        fout << -1;

    fout << endl;
    fout.close();
    return 0;
}
