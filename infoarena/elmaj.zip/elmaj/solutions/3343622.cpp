#include <bits/stdc++.h>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

const int N_MAX = 1e6 + 5;

int n, v[N_MAX], cnt = 1, maj;

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++) {
        fin >> v[i];
        if (v[i] == maj)
            cnt++;
        else {
            cnt--;
            if (cnt == 0) {
                cnt = 1;
                maj = v[i];
            }
        }
    }
    cnt = 0;
    for (int i = 1; i <= n; i++) {
        if (v[i] == maj)
            cnt++;
    }
    if (maj == 0)
        fout << "-1\n";
    else
        fout << maj << " " << cnt << "\n";
    return 0;
}
