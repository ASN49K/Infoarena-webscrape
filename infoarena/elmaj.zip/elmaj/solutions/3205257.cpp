#include <fstream>
using namespace std;
int a[1000000];
int realCount = 0;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int maj(int n, int a[]) {
    int candidate = -1;
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (count == 0) {
            candidate = a[i];
            count = 1;
        }else if (a[i] == candidate) {
            count++;
        }else{
            count--;
        }
    }
    for (int i = 0; i < n; i++) {
        if (a[i] == candidate)
            realCount++;
    }
    if (realCount > n / 2)
        return candidate;
    else
        return -1;
}
int main()
{
    int n;
    cin>>n;
    for (int i = 0; i < n; i++) {
        cin>>a[i];
    }
    if(maj(n,a)!=-1)cout<<maj(n,a)<<" "<<realCount/2;
    else cout<<-1;
    return 0;
}
