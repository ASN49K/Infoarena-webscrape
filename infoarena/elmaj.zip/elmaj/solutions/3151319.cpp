#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

#define cin fin
#define cout fout

int n,i,a,nr,v[1000005];

int main()
{
    cin>>n;
    cin>>v[1];
    a=v[1]; nr=1;
    for(i=2;i<=n;i++)
    {
        cin>>v[i];
        if(v[i]==a) nr++;
        else if(v[i]!=a && nr>0) nr--;
        else if(v[i]!=a && nr<=0)
        {
            a=v[i]; nr=1;
        }
    }
    nr=0;
    for(i=1;i<=n;i++)
    {
        if(v[i]==a) nr++;
    }
    if(nr>n/2) cout<<a<<" "<<nr;
    else cout<<-1;
    return 0;
}
