#include <bits/stdc++.h>

using namespace std;

ifstream f ("elmaj.in");
ofstream g ("elmaj.out");

int n;
int a[1000005];

int main()
{
    int i , cand = -1 , count = 0;

    f >> n;

    for(i = 1 ; i <= n ; i++)
    {
        f >> a[i];

        if(cand != a[i])
        {
            if(count == 0)
                cand = a[i] , count = 1;
            else --count;
        }
        else ++count;
    }

    ifstream f ("elmaj.in");

    f >> n;

    count = 0;

    for(i = 1 ; i <= n ; i++)
        if(a[i] == cand)
            ++count;

    if(count > n / 2)
        g << cand << ' ' << count;
    else g << -1;

    return 0;
}
