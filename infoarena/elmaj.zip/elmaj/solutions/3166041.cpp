#include <iostream>
#include <fstream>
#define nl '\n'

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int NMAX = 1e6+1;

int v[NMAX];
int n, a, k;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        fin >> v[i];
        if (k == 0)
        {
            a = v[i];
            k = 1;
        }
        else if (v[i] == a)
            k++;
        else
            k--;
    }
    int cnt = 0;
    for (int i = 1; i <= n; i++)
        if (v[i] == a)
            cnt++;
    if (cnt > n/2)
        fout << a << ' ' << cnt;
    else
        fout << -1;
    return 0;
}
