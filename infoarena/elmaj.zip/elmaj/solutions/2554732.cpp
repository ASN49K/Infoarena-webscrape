#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1000001];

int main()
{
    int n,nr,cnt;
	int i;
	cin>>n;
	for(i=1;i<=n;++i){
		cin>>v[i];
	}
	nr=v[1];
	cnt=1;
	for(i=2;i<=n;++i){
		if(cnt==0)
		{
			nr=v[i];
			cnt=1;
            continue;
		}
		if(v[i]==nr)
			cnt++;
		else
			cnt--;
	}
	cnt=0;
	for(i=1;i<=n;++i)
	{
		if(v[i]==nr)
			cnt++;
	}
	if(cnt>=(n/2))
	{
		cout<<nr<<" "<<cnt;
	}
	else
		cout<<"-1";
	return 0;
}
