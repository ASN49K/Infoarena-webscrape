#include <bits/stdc++.h>

const int MAX_N = 1000000;
int v[MAX_N];

int main() {
	int n;
    int candidat = 0, fr = 0;

    FILE *fin = fopen("elmaj.in", "r");
	FILE *fout = fopen("elmaj.out", "w");
	
    fscanf(fin, "%d", &n);
    for(int i = 0; i < n; ++i) {
        fscanf(fin, "%d", &v[i]);
        if(v[i] == candidat)
            ++fr;
        else
            --fr;

        if(fr < 0) {
            candidat = v[i];
            fr = 0;
        }
    }

    for(int i = 0; i < n; ++i)
        if(v[i] == candidat)
            ++fr;

    if(fr > n / 2)
        fprintf(fout, "%d %d", candidat, fr);
    else
        fprintf(fout, "-1");

    fclose(fin);
    fclose(fout);
    return 0;
}
