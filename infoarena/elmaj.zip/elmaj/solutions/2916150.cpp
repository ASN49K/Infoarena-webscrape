/**
 *    author:  R0L3eX
 *    created: 28.07.2022 11:22:37
 *    quote: Claustrophobic? Who would ever be afraid of Santa Clause?
**/

#include "bits/stdc++.h"

using namespace std;

#if defined(ONPC)
#include "bits/debug.h"
#endif

#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
template<typename T> using matrix = vector<vector<T> >;
template<typename T> void Unique(T &a) {a.erase(unique(a.begin(), a.end()), a.end());}

void setIO(string name = "") {
  cin.tie(0)->sync_with_stdio(0);
  if ((int)name.size()) {
    freopen((name + ".in").c_str(), "r", stdin);
    freopen((name + ".out").c_str(), "w", stdout);
  }
}

const int MOD = 1e9 + 7;
const int mxN = 2e5;
const int INF = INT_MAX;
const char nl = '\n';

pair<int, int> maj_elm(const vector<int> &v) {
  int cand = -1, k = 0;

  for (int x : v) {
    if (k == 0) {
      cand = x;
      k = 1;
    } else if (x == cand) {
      ++k;
    } else {
      --k;
    }
  }

  if (cand < 0) {
    return {-1, 0};
  }

  int app = 0;
  for (int x : v) {
    if (x == cand) ++app;
  }

  if (app > (int)v.size() / 2) {
    return {cand, app};
  }
  return {-1, 0};
}

int main() {
  setIO("elmaj");

  int n;
  cin >> n;
  vector<int> v(n);

  for (int &x : v) {
    cin >> x;
  }

  pair<int, int> ans = maj_elm(v);
  cout << ans.first << ' ' << ans.second << nl;
}
