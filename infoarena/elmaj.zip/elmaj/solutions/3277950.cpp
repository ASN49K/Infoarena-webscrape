#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1001];

int main()
{
    int n,m=0,c=0,r=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        if(c==0)
        {
            m=v[i];
            c=1;
        }
        else
        {
            if(v[i]==m)
                c++;
            else
                c--;
        }
    }
    for(int i=1;i<=n;i++)
        if(v[i]==m)
            r++;
    if(r>n/2)
        cout<<m<<' '<<r;
    else
        cout<<"-1";
    return 0;
}
