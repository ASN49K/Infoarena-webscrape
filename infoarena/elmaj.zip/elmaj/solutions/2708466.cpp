#include <iostream>
#include <fstream>
#include <deque>
using namespace std;
ifstream f ("elmaj.in");
ofstream g ("elmaj.out");
int n,voturi,crt;
long long v[100001];
int main()
{
    f >> n;
    f >> v[1];
    crt = v[1];
    voturi = 1;
    /// daca elemntul este majoritar va anula toate celelate nr si va ramane el la final
    for(int i = 2;i<=n;i++)
    {
        f >> v[i];
        if(v[i] == crt)
            voturi++;
        else
            voturi--;
        if(voturi < 0)
        {
            crt = v[i];
            voturi = 0;
        }
    }
    int fr = 0;
    for(int i = 1;i<=n;i++)
    {
        if(v[i] == crt)
            fr++;
    }
    g << crt<< " "<<fr;

}
