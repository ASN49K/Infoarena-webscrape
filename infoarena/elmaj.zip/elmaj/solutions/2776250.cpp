#include<fstream>
using namespace std;
ifstream F("elmaj.in");
ofstream G("elmaj.out");
int v[1000000],n,k,c,i;
int main()
{
    F>>n;
    for(i=0;i<n;++i)
        F>>v[i],!k?c=v[i],k=1:(v[i]==c?++k:--k);
    for(k=i=0;i<n;++i)
        if(c==v[i])
            ++k;
    k>n/2?G<<c<<" "<<k:G<<"-1";
    return 0;
}
