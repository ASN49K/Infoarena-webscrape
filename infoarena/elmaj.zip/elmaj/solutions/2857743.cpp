#include <fstream>
#include <unordered_map>

#define MOD 104659

using namespace std;

int n, x, valSol, nrSol;
unordered_map<int, int> u;
int main() {
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");
    fin >> n;
    for (int i = 1; i <= n; i++) {
        fin >> x;
        if (u.contains(x)){
//            int nr = u.find(x)->second;
//            u.erase(x);
//            u.emplace(x, nr+1);
            u.at(x)++;
        }
        else{
            u.emplace(x, 1);
        }
    }
    for (auto &a:u){
        if (a.second>n/2){
            nrSol=a.second;
            valSol=a.first;
        }
    }
    if (!nrSol){
        fout<<-1;
    }
    else{
        fout<<valSol<<" "<<nrSol;
    }
    return 0;
}