#ifdef LOCAL
#include <bits/stdc++.h>
using namespace std;
ifstream fin("fantastice.in");
ofstream fout("fantastice.out");
#else
#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
#endif
int n;
unsigned int v[1000005];
int ans1=-1, ans2, cnt=1;


int main()
{
    fin>>n;
    for(int i=1; i<=n; i++){
        fin>>v[i];
        if(v[i]==ans1)cnt++;
        else{
            cnt--;
            if(cnt==0){
                ans1=v[i];
                cnt=1;
            }
        }
    }
    for(int i=1; i<=n; i++){
        if(v[i]==ans1)ans2++;
    }
    fout<<ans1<<" "<<ans2;


    return 0;
}
