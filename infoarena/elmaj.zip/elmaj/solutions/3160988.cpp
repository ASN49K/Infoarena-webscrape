#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int n;
    ifstream f("elmaj.in");
    ofstream g("elmaj.out");
    f>>n;
    int t[n];
    for (int i=1; i<=n; i++)
    {
        f>>t[i];
    }
    int s=-1, db=0;
    for (int i=1; i<=n; i++)
    {
        if (db==0)
        {
            s=t[i];
            db=1;
        }
        else if (t[i]==s)
            {
                db++;
            }
            else
            {
                db--;
            }
    }
    if (s>0)
    {
        db=0;
        for (int i=1; i<=n; i++)
        {
            if (t[i]==s) db++;
        }
        if (db>=n/2+1) g<<s<<" "<<db;
    }
    f.close();
    g.close();
}
