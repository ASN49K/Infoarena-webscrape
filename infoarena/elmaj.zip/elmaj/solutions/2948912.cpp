#include <fstream>
#include <map>
using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int n , a , k , cand;
map <int,int> m;

int main()
{

    cin >> n;

    for(int i = 1 ; i <= n ; i++){

        cin >> a;
        m[a]++;

        if( k == 0 ){

            cand = a;
            k = 1;
            continue;
        }

        if( a == cand ){

            k++;
        }else{

             k--;
        }

    }
    if(m[cand]>=(n/2+1)){

        cout << cand <<' ' <<  m[cand];
        return 0;
    }

    cout << -1;

    return 0;
}
