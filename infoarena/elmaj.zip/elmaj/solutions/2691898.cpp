#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

set <int> s;
multiset <int> ms;

int x, n;
int mxc = 0, mxn;

int main() {
    
    int c;
    f >> n;
    
    for (int i = 1; i <= n; i++) {
        f >> x;
        s.insert(x);
        ms.insert(x);
    }
    
    for (auto i = s.begin(); i != s.end(); i++) {
        c = ms.count(*i);
        if (c > mxc){
            mxc = c;
            mxn = *i;
        }
    }
    
    if (mxc > n/2) {
        g << mxn << " " << mxc;
    } else {
        g << -1;
    }
    
    return 0;
}
