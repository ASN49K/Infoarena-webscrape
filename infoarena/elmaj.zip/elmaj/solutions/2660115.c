#include <stdio.h>
#define NMAX 1000000
int v[NMAX];
int main() {
    FILE *fin, *fout;
    int n, cand, vot, i;
    fin = fopen( "elmaj.in", "r" );
    fscanf( fin, "%d", &n );
    cand = -1;
    vot = 0;
    for ( i = 0; i < n; i++ ) {
        fscanf( fin, "%d", &v[i] );
        if ( vot == 0 ) {
            cand = v[i];
            vot = 1;
        }
        if ( v[i] == cand )
            vot++;
        else
            vot--;
    }
    fclose( fin );
    vot = 0;
    for ( i = 0; i < n; i++ ) {
        if ( v[i] == cand )
            vot++;
    }
    fout = fopen( "elmaj.out", "w" );
    if ( vot <= n / 2 )
        fprintf( fout, "-1");
    else
        fprintf( fout, "%d %d", cand, vot );
    fclose( fout );
    return 0;
}
