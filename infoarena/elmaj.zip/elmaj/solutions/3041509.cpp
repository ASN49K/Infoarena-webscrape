#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

///#incldue <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

const int NMAX=1e6+5;
int v[NMAX];

int main()
{
    int n,i,j;
    int best=-1,frecv=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i];
        if(!frecv)
        {
            best=v[i];
            frecv=1;
        }
        else
        {
            if(best==v[i])
                frecv++;
            else
                frecv--;
        }
    }
    frecv=0;
    for(i=1;i<=n;i++)
        if(v[i]==best)
            frecv++;
    if(frecv>n/2)
        cout<<best<<" "<<frecv;
    else
        cout<<-1;
    return 0;
}
