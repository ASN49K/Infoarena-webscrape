#include <iostream>
#include <fstream>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int v[1000001], n;
int nr, c;

int main()
{
    in>>n;
    in>>v[1], nr=v[1], ++c;
    for(int i=2; i<=n; i++)
    {
        in>>v[i];
        if(v[i]!=nr) --c;
        if(c==0) nr=v[i], ++c;
    }
    c=0;
    for(int i=1; i<=n; i++) c+=!!(nr==v[i]);
    if(c>=n/2+1) out<<nr<<' '<<c;
    else out<<-1;
    return 0;
}
