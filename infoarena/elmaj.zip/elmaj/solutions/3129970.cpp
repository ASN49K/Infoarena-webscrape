#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ifstream fin2("elmaj.in");
ofstream fout("elmaj.out");

int main()
{
    int n, a, p=0, current=0;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>a;
        if(p==0)current=a;
        if(a==current)++p;
        else --p;
    }
    a=p=0;
    fin2>>a;///waste
    for(int i=1; i<=n; i++)
    {
        fin2>>a;
        if(a==current)++p;
    }
    if(p>=n/2)fout<<a<<' '<<p;
    else fout<<-1;
    return 0;
}
