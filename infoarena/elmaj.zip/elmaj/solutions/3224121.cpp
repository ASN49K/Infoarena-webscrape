#include <bits/stdc++.h>

using namespace std;

int v[1000005];

int main() {
    ifstream fin ("elmaj.in");
    ofstream fout ("elmaj.out");
    int n, elemCur, frecv;
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
    }
    elemCur = v[1];
    frecv = 1;
    for (int i = 2; i <= n; ++i) {
        if (elemCur != v[i]) {
            frecv -= 1;
        } else {
            frecv += 1;
        }
        if (frecv == 0) {
            elemCur = v[i];
            frecv = 1;
        }
    }
    // acum nu mi se garanteaza ca elemCur este si elem maj, dar se garanteazaz ca este singura posibilitate
    // asa ca o testam
    frecv = 0;
    for (int i = 1; i <= n; ++i) {
        if (elemCur == v[i]) {
            frecv += 1;
        }
    }
    if (frecv >= n / 2 + 1) {
        fout << elemCur << ' ' << frecv;
    } else {
        fout << -1;
    }
    return 0;
}
