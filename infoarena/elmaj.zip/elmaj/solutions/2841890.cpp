#include<iostream>
#include<fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000007];
int main()
{
    int n,cnt,el;
    f>>n;
    cnt=0;
    el=-1;
    for(int i=1;i<=n;i++){
        f>>v[i];
        if(cnt==0){
            el=v[i];
            cnt=1;
        }
        if(v[i]==el)
            cnt++;
        else
            cnt--;
    }
    cnt=0;
    for(int i=1;i<=n;i++)
        if(v[i]==el)
            cnt++;
    if(cnt>n/2)
        g<<el<<' '<<cnt;
    else
        g<<-1;
    g<<'\n';
    f.close();
    g.close();
    return 0;
}
