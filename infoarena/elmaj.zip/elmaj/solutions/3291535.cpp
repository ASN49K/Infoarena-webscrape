#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, chosen, maj, sol;
int v[1000005];

int main(){
    fin >> n;
    for (int i=0; i<n; i++){
        fin >> v[i];
        if (maj == 0){
            chosen = v[i];
            maj++;
        }
        else if (v[i] == chosen){
            maj++;
        }
        else {
            maj--;
        }
    }
    for (int i=0; i<n; i++){
        if (v[i] == chosen){
            sol++;
        }
    }
    if (sol > n/2){
        fout << chosen << ' ' << sol;
    }
    else {
        fout << -1;
    }
    return 0;
}
