#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int f1(int n,int v[],int &db){
    int s=-1;
    for (int i=1; i<=n; i++)
    {
        if (db==0)
        {
            s=v[i];
            db=1;
        }
        else if (v[i]==s)
            {
                db++;
            }
            else
            {
                db--;
            }
    }
    if (s>0)
    {
        db=0;
        for (int i=1; i<=n; i++)
        {
            if (v[i]==s) db++;
        }
        if (db>=n/2+1) fout<<s<<" "<<db;
    }
}

int main()
{
    int n,db=0;
    fin>>n;
    int v[n];
    for(int i=1;i<=n;i++){
        fin>>v[i];
    }
    f1(n,v,db);
    return 0;
}