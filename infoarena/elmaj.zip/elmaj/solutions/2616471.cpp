
#include <iostream>
#include <fstream>

using namespace std;
ifstream r("elmaj.in");
ofstream w("elmaj.out");
int v[1000001];
int main()
{
    int n, elmaj, aparitii, i;
    r>>n;
    for(i=0; i<n; i++)
    {
        r>>v[i];
    }
    elmaj = -1;
    aparitii = 0;
    for (i = 0; i < n; ++i)
    {
        if (aparitii == 0)
        {
            elmaj = v[i];
            aparitii = 1;
        }
        else if (v[i] == elmaj)
        {
            ++aparitii;
        }
        else
        {
            --aparitii;
        }
    }
    aparitii = 0;
    for (i = 0; i < n; ++i)
        if (v[i] == elmaj)
        {
            ++aparitii;
        }
    if (aparitii <= n / 2)
    {
        elmaj = -1;
        w<<elmaj;
    }
    else{
        w<<elmaj<<" "<<aparitii;
    }


    return 0;
}
