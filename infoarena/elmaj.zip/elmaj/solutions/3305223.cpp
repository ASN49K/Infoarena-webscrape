#include <fstream>
using namespace std;

const int Nmax = 1000001;
int v[Nmax];

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int main(){
    int n, candidat, nrvoturi = 0;
    f >> n;
    for (int i = 1; i <= n; i++){
        f >> v[i];
        if (nrvoturi == 0){
           candidat = v[i];
           nrvoturi = 1; 
        }
        else if (v[i] == candidat)
            nrvoturi++;
        else if (v[i] != candidat)
            nrvoturi--;
    }
    if (nrvoturi > 0){
        g << candidat << " ";
        nrvoturi = 0;
        for (int i = 1; i <= n; i++)
            if (v[i] == candidat)
                nrvoturi++;
        g << nrvoturi;
    }
    else g << "-1";
    return 0;
}