#include <bits/stdc++.h>
using namespace std;
// , << >> .
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000001];
int main()
{
    int n, ct = 1, ok = 1, ctf, w;
    f >> n;
    for(int i = 1; i <= n; i++)
        f >> v[i];
    sort(v + 1, v + n + 1);
    for(int i = 1; i <= n - 1; i++)
    {
        if(v[i] == v[i + 1])
            ct++;
        else if(ct >= n / 2 + 1)
        {
            ok = 1;
            w = v[i];
            ctf = ct;
        }
        else if(v[i] != v[i + 1])
            ct = 1;
    }
    if(ok == 1)
        g << w << " " << ctf;
    else
        g << -1;
}
