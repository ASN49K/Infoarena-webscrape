/**
 * Author: Andu Scheusan (not_andu)
 * Created: 24.09.2023 21:23:32
*/

#include <bits/stdc++.h>
#include <unordered_map>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "elmaj.in"
#define OUTFILE "elmaj.out"

#define all(x) (x).begin(), (x).end()
#define MP make_pair
#define F first
#define S second

typedef long long ll;

void solve(){

    int n;
    unordered_map<int, int> fr;

    cin >> n;

    for(int i = 0; i < n; ++i){

        int aux;

        cin >> aux;

        ++fr[aux];

    }

    for(auto nr : fr){

        if(nr.second > n / 2){

            cout << nr.first << " " << nr.second << '\n';

            return;

        }

    }

    cout << -1 << '\n';

}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}