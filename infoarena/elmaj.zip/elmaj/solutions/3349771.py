import random

def rezolvare_majoritar():
    f_in = open("elmaj.in", "r")
    data = f_in.read().split()
    f_in.close()
    
    if len(data) == 0:
        return
        
    n = int(data[0])
    if n == 0:
        f_out = open("elmaj.out", "w")
        f_out.write("-1\n")
        f_out.close()
        return
        
    prag = n // 2 + 1
    
    for _ in range(20):
        idx = random.randint(1, n)
        candidat = data[idx]
        aparitii = 0

        for i in range(1, n + 1):
            if data[i] == candidat:
                aparitii += 1
                
        if aparitii >= prag:
            f_out = open("elmaj.out", "w")
            f_out.write(candidat + " " + str(aparitii) + "\n")
            f_out.close()
            return
            
    f_out = open("elmaj.out", "w")
    f_out.write("-1\n")
    f_out.close()

rezolvare_majoritar()