#include <iostream>

using namespace std;
int v[1000005];

int main() {
    freopen("elmaj.in","r",stdin);
    freopen("elmaj.out","w",stdout);
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
    int candidate = v[0];
    int candidateFreq = 0;
    for (int i = 0; i < n; ++i) {
        if (v[i] == candidate)
            candidateFreq++;
        else {
            candidateFreq--;
            if (candidateFreq == 0) {
                candidate = v[i];
                candidateFreq = 1;
            }
        }
    }
    int freqVerif = 0;
    for (int i = 0; i < n; ++i) {
        if (v[i] == candidate)
            freqVerif++;
    }
    if (freqVerif >= n / 2 + 1)
        cout << candidate << " " << freqVerif;
    else
        cout<<-1;
}