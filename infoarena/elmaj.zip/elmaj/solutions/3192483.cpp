#include <fstream>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000001],n,i,ap,x;
int main()
{
    f>>n;
    for (i=1; i<=n; i++) f>>v[i];
    for (i=1; i<=n; i++)
    {
       if (ap==0)
       {
           x=v[i];
           ap=1;
       }
       else if (v[i]==x) ap++;
       else ap--;
    }
    ap=0;
    for (i=1; i<=n; i++)
        if (v[i]==x) ap++;
    if (ap>n/2) g<<x<<" "<<ap;
    return 0;
}
