#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second
 
void solve(){
    int n;
    cin >> n;
    map<int, int> m;
    for(int i = 0; i < n; i++){
        int x;
        cin >> x;
        m[x]++;
    }
    auto h = max_element(m.begin(), m.end(),[] 
        (const pi& a, const pi& b)->bool{ return a.second < b.second; } );
    if(h->s >= n/2+1)
        cout << h->f << ' ' << h->s << '\n';
    else
        cout << -1 << '\n';
}  
 
int main(){
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}