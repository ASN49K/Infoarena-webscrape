import random
import sys

random.seed(42) 

f_in = open("elmaj.in", "r")
date = f_in.read().split()
f_in.close()

n = int(date[0])
list_of_numbers = [int(x) for x in date[1:]]

for _ in range(20):
    mg = random.choice(list_of_numbers)
    if list_of_numbers.count(mg) > n // 2:
        print(mg)
        sys.exit(0)

print(-1)