#include <fstream>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
long long n,i,j,v[100005],cnt,key,nr,ct;
int main()
{
    f>>n;
    for(i=1;i<=n;i++){
        f>>v[i];
        if(nr==0){
           key=v[i];
           cnt=1;
        }
        else
           if(key==v[i])
                cnt++;
        else
            cnt--;
    }
    for(i=1;i<=n;i++){
        if(v[i]==key)
            ct++;
    }
    if(ct>=n/2+1)
        g<<key<<" "<<ct;
    return 0;
}
