#include<bits/stdc++.h>

using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
long long n, v[1000000], k, nr, c;

int main() {
   in >> n;

   for (int i = 0; i < n; i++) {
      in >> v[i];
      if(k == 0) {
         k = 1;
         nr = v[i];
      }
      else
         if(v[i] == nr)
            k++;
      else
         k--;
   }

   for (int i = 0; i < n; i++) {
      if (v[i] == nr)
         c++;
   }

   out << nr << " ";

   if (c >= n / 2 + 1)
      out << c;
   else
      out << -1;
}


