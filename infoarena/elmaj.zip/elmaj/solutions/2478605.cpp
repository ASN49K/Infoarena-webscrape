#include <bits/stdc++.h>
using namespace std;

int n, v[1000001];
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int ap=0,maj;

int main()
{
    fin>>n;
    fin>>maj;
    v[0]=maj;
    ap=1;
    for(int i=1; i<n; i++)
    {
        fin>>v[i];
        if(maj==v[i]) ap++;
        else ap--;
        if(ap<0)
        {
            maj=v[i];
            ap=1;
        }
    }
    if(ap>0)
    {
        ap=0;
        for(int i=0; i<n; i++)
        {
            if(maj==v[i]) ap++;
        }
    }
    if(ap<n/2+1) fout<<"-1";
    else fout<<maj<<" "<<ap;

    return 0;
}
