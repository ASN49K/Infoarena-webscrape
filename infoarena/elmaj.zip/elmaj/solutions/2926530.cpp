#include <iostream>
#include <fstream>

#define MAX_SIZE 1000001

int main() {
    std::ifstream input("elmaj.in");
    std::ofstream output("elmaj.out");
    int n;
    int a[MAX_SIZE] = {0};
    input >> n;

    for (int i = 1; i <= n; ++i) input >> a[i];

    int candidate = a[1], count = 1;
    for (int i = 2; i <= n; ++i) {
        if (candidate == a[i]) count++;
        else count--;

        if (count == 0) {
            candidate = a[i];
            count = 1;
        }
    }

    count = 0;
    for (int i = 1; i <= n; ++i) {
        if (candidate == a[i]) count++;
    }

    if (count >= n / 2 + 1) output << candidate << " " << count;
    else output << -1;

    return 0;
}
