#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n, a[1000005], fr[1000005] = {0};

int main()
{
    f >> n;

    for (int i = 1; i <= n; ++i) {
        f >> a[i];
    }

    for (int i = 1; i <= n; ++i) {
        fr[a[i]]++;
    }

    int nr = n / 2, nuNr = 0, ok = 0;

    for (int i = 1000004; i >= 0; --i) {
        if (fr[i] > nr) {
            g << i << ' ' << fr[i];
            ok = 1;
            break;
        }
    }

    if (ok == 0) {
        g << -1;
    }

    return 0;
}
