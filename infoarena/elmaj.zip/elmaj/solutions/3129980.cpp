#include <fstream>
using namespace std;

int main()
{
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");
    int n,can,con;
    fin >> n;
    int v[n+5];
    fin >> v[0];
    can=v[0];
    con=1;
    for(int i=1;i<n;++i){
        fin >> v[i];
        if(v[i]==can){
            con++;
        }
        else{
            con--;
        }
        if(con<=0){
            can=v[i];
            con=0;
        }
    }
    int nrap=0;
    for(int i=0;i<n;++i){
        if(v[i]==can){
           nrap++;
        }
    }
    if(nrap>=n/2+1){
        fout << can << ' ' << nrap << '\n';
    }
    else{
        fout << -1;
    }
    return 0;
}
