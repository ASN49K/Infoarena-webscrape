#include <fstream>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int n,maj,ap,e;
int main()
{
    f>>n;
    f>>maj;
    ap=1;
    for(int i=2; i<=n; ++i)
    {
        f>>e;
        if(maj==e)
        {
            ap++;
        }
        else
        {
            ap--;
        }
        if(ap<0)
        {
            maj=e;
            ap=1;
        }
    }
    f.close();
    f.open("elmaj.in");
    f>>n;
    ap=0;
    for(int i=1; i<=n; ++i)
    {
        f>>e;
        if(e==maj)
        {
            ap++;
        }
    }
    if(ap>n/2)
    {
        g<<maj<<" "<<ap;
    }
    else
    {
        g<<-1;
    }
    return 0;
}
