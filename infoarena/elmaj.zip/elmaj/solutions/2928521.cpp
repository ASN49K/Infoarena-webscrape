#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000001];

int main()
{
    int n,i,af,candidat,ap;
    fin >> n;
    for (i=1;i<=n;++i)
    {
        fin >> v[i];
        if (i==1)
        {
            candidat=v[i];
            ap=0;
        }
        if (v[i]==candidat)
        {
            ap++;
        }
        else
        {
            ap--;
        }
        if (ap==0)
        {
            candidat=v[i];
            ap++;
        }
    }
    af=0;
    for (i=1;i<=n;i++)
    {
        if (v[i]==candidat)
            af++;
    }
    if (af>n/2)
    fout << candidat << " " << af;
    else
    fout << -1;
}
