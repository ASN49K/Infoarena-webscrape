#include <iostream>
#include <unordered_map>

int main()
{
    int n, a = -1;
    std::unordered_map<int, int> freq;

    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);

    std::cin >> n;

    for (int x, i = 0; i < n; ++i) {
        std::cin >> x;

        if (freq.find(x) == freq.end())
            freq[x] = 0;

        ++freq[x];

        if (freq[x] > n / 2)
            a = x;
    }

    std::cout << a << ' ' << freq[a] << '\n';

    return 0;
}
