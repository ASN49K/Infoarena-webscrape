from pathlib import Path

t = Path("elmaj.in").read_text().split('\n')

n = int(t[0])

t = [int(x) for x in t[1].split()]
t.sort()
#print(t)
g = open("elmaj.out", "w+")

# print(t)


dict = {}

ok = 0

for i in range(0, len(t)):

    if t[i] not in dict:

        dict[t[i]] = 1
        try:
            if (t[i]!=t[i-1]) and dict[t[i-1]] < n//2:
               # print("schss",t[i-1])
                del dict[t[i-1]]
        except:
            pass
    else:
        dict[t[i]] += 1
        if (t[i]!=t[i-1]) and dict[t[i-1]] < n//2:
        #    print("schss")
            del dict[t[i-1]]

#print(dict)

for a in dict.keys():
    if dict[a] > n // 2:
        ok = 1
        g.write(str(a) + " " + str(dict[a]) + '\n')
        break
if ok == 0:
    g.write("-1\n")

g.close()