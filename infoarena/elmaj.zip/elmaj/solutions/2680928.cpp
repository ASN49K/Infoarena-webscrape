#include <fstream>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int n, x, v[1000005], cnt;
int main()
{
    fin>>n>>v[0];
    int maj=v[0], Count=1;
    for(int i=1; i<n; i++)
    {
        fin>>v[i];
        if(v[i]==maj) Count++;
        else Count--;
        if(Count==0)
        {
            maj=v[i];
            Count=1;
        }
    }
    for(int i=0; i<n; i++)
        if(v[i]==maj) cnt++;
    fout<<maj<<" "<<cnt;
    return 0;
}
