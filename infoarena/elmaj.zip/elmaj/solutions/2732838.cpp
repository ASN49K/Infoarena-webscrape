#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n,v[1000005];

int main()
{
 f>>n;
 for(int i=1;i<=n;i++) f>>v[i];

 int element=0,ct=0;

 for(int i=1;i<=n;i++){
  if( ct==0 ){
   ct=1;
   element=v[i];
   continue;
  }

  if( element==v[i] ) ct++;
  else ct--;
 }

 if( ct==0 ){
  g<<"-1";
  return 0;
 }

 ct=0;
 for(int i=1;i<=n;i++) if( element==v[i] ) ct++;

 if( ct>=n/2+1 ){
  g<<element<<' '<<ct;
  return 0;
 }
 g<<"-1";
}
