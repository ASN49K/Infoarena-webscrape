#include <iostream>
#include <fstream>
using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int n,i,v[1000001],a;
int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
       {
           in>>a;
           v[a]++;
       }
    for(int a=0;a<=9;a++)
        if(v[a]>=n/2+1)
            out<<a<<" "<<v[a];

}
