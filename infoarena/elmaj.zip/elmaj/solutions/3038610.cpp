#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n, first, cnt, v[1000010], cntMax=-1, nr;

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++) fin>>v[i];
    sort(v+1, v+n+1);
    int first=v[1], cnt=1;
    for(int i=2; i<=n; i++) {
        if(v[i]!=first) {
            if(cnt>cntMax) cntMax=cnt, nr=first;
            first=v[i];
            cnt=1;
        }
        else cnt++;
    }
    if(cntMax>=n/2+1) fout<<nr<<" "<<cntMax;
    else fout<<-1;

    return 0;
}
