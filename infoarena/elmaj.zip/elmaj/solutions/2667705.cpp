#include <fstream>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000005];
int main()
{
    int n,i,candidat,aparitii,maxap;
    fin>>n;
    for(i=0;i<n;i++)
        fin>>v[i];
    candidat=v[0];
    aparitii=1;
    for(i=1;i<n;i++)
    {
        if(v[i]==candidat)
           aparitii++;
           else
           aparitii--;
        if(aparitii<0)
           {
            candidat=v[i];
            aparitii=1;
           }
    }
    maxap=0;
    for(i=0;i<n;i++)
        if(v[i]==candidat)
           maxap++;
    if(maxap>=n/2+1)
       fout<<candidat<<' '<<maxap<<'\n';
    else
    fout<<"-1";
    return 0;
}
