﻿#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, v[1000001], candidat, cnt, ap;

int main()
{
	fin >> n;
	for (int i = 1; i <= n; ++i) {
		fin >> v[i];
		if (cnt == 0) {
			candidat = v[i];
			cnt = 1;
		}
		else {
			if (v[i] == candidat) {
				++cnt;
			}
			else --cnt;
		}
	}

	for (int i = 1; i <= n; ++i) {
		if (v[i] == candidat) {
			++ap;
		}
	}

	if (ap <= n / 2) {
		fout << -1;
	}
	else fout << candidat << ' ' << ap;

	return 0;
}