#include <fstream>

using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000001];
int main()
{
    int n,a,i,ok,cnt=0,elem;
    cin>>n>>a;
    elem=a;
    ok=1;
    v[1]=a;
    for(i=2; i<=n; i++)
    {
        cin>>a;
        v[i]=a;
        if(elem!=a)
            ok--;
        else
            ok++;
        if(ok==0)
        {
            elem=a;
            ok=1;
            cnt=1;
        }
        else
        {
            cnt++;
        }
    }
    for(i=1;i<=n;i++)
    {
        if(v[i]==elem)
            cnt++;
    }
    cout<<elem<<" "<<cnt;
    return 0;
}
