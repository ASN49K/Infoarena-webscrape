#include<bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n , v[1000001] , gasit , k;

int main()
{
    fin >> n;
    for(int i = 1 ; i <= n ; i++)
        fin >> v[i];

    gasit = v[1];
    k = 1;
    for(int i = 2 ; i <= n ; i++)
    {
        if(v[i] == gasit)
        {
            k++;
        }
        else k--;
        if(k <= 0)
        {
            k = 0;
            gasit = v[i];
        }
    }
    k = 0;
    for(int i = 1 ; i <= n ; i++)
        if(gasit == v[i]) k++;

    if(k >= n / 2 + 1)
        fout << gasit <<" "<<k;
    else
        fout << -1;
}
