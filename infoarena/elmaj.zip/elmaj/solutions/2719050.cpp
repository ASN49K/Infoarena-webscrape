#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int NMax = 1e6;

int n, element, freq;
int v[NMax + 5];

void Read(){
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
}

void Solve(){
    for (int i = 1; i <= n; i++){
        if (v[i] == element)
            freq++;
        else
            freq--;
        if (freq < 0){
            freq = 1;
            element = v[i];
        }
    }
}

void Print(){
    int nr = 0;
    for (int i = 1; i <= n; i++)
        if (v[i] == element)
            nr++;
    if (nr < n / 2 + 1)
        fout << -1 << '\n';
    else
        fout << element << ' ' << nr << '\n';
}

int main(){
    Read();
    Solve();
    Print();
    return 0;
}
