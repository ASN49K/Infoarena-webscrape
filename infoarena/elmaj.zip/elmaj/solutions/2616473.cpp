#include <cstdio>

using namespace std;

int v[1000005];

int main()
{
    int n, c, a = 1;
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);
    scanf("%d%d", &n, &v[0]);
    c = v[0];
    for(int i = 1; i < n; i++)
    {
        scanf("%d", &v[i]);
        if(c == v[i]) a++;
        else a--;
        if(!a) a = 1, c = v[i];
    }
    a = 0;
    for(int i = 0; i < n; i++) a += c == v[i];
    if(a >= (n >> 1) + 1) printf("%d %d", c, a);
    else printf("-1");
    return 0;
}
