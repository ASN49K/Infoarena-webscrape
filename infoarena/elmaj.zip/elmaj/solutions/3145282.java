import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new FileInputStream("elmaj.in"));
        int n = sc.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; ++i) {
            a[i] = sc.nextInt();
        }
        sc.close();

        int k = 0;
        int majorCandidate = -1;
        for (int candidate : a) {
            if (k == 0) {
                majorCandidate = candidate;
                k = 1;
            } else if (candidate == majorCandidate) {
                ++k;
            } else {
                --k;
            }
        }
        PrintWriter pw = new PrintWriter("elmaj.out");
        if (k == 0) {
            pw.println(-1);
        } else {
            int cnt = 0;
            for (int candidate : a) {
                if (candidate == majorCandidate) {
                    ++cnt;
                }
            }
            if (cnt > a.length / 2) {
                pw.println(majorCandidate + " " + cnt);
            } else {
                pw.println(-1);
            }
        }
        pw.flush();
        pw.close();
    }
}
