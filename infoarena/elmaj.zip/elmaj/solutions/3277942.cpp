#include <fstream>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int f[100000];
int main() {
    int n,x,candidate=-1,cnt=0;
    cin>>n;
    for (int i=1; i<=n; i++) {
        cin>>x;
        f[x]++;
        if (cnt==0) {
            cnt++;
            candidate=x;

        }
        else if (x==candidate) cnt++;
        else if (x!=candidate) cnt--;
    }
    cout<<candidate<<" "<<f[candidate];
}
