#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int N, cand = -1, fr;
vector<int>v;
int main() {
    fin >> N;
    v = vector<int>(N + 1);
    for(int i = 1; i <= N; i++) {
        fin >> v[i];
        if(fr == 0) {
            cand = v[i];
            fr = 1;
        } else if(v[i] == cand) {
            fr++;
        } else {
            fr--;
        }
    }
    if(cand == -1) {
        fout << "-1\n";
        return 0;
    }
    fr = 0;
    for(int i = 1; i <= N; i++) {
        if(v[i] == cand) {
            fr++;
        }
    }
    if(fr > N >> 1) {
        fout << cand << " " << fr << '\n';
    } else {
        fout << "-1\n";
    }
    return 0;
}
