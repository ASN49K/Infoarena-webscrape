#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000001];
int main()
{
    int n, nr=0, ales=-1;
    f >> n;
    for(int i=1; i<=n; i++)
    {
        f >> v[i];
        if(nr==0)
            ales=v[i];
        if(v[i]==ales)
            nr++;
    }
    int cnt=0;
    for(int i=1; i<=n; i++)
        if(v[i]==ales)
            cnt++;
    if(cnt>=n/2+1)
        g << ales << " " << cnt;
    else
        g << -1;
    return 0;
}
