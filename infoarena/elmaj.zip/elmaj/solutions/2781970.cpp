#include <bits/stdc++.h>
#define N 1000001
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n,a[N];

void citire()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>a[i];
}
void rezolva()
{
   bool ok=0;
   int i;
   while(!ok)
   {
       ok=1;
       for(i=1;i<=n-1;i++)
        if(a[i]>a[i+1])
       {swap(a[i],a[i+1]);ok=0;}
   }

   int ct=1;
   int ctmax=1;
   int x;
   for(i=1;i<n;i++)
   {
       if(a[i]==a[i+1])
        ct++;
       else {if(ct>ctmax)ctmax=ct;x=a[i-1];ct=1;}
   }
  if(ctmax!=-1)
    fout<<x<<" "<<ctmax;
  else fout<<ctmax;

}
int main()
{
citire();
rezolva();

    return 0;
}
