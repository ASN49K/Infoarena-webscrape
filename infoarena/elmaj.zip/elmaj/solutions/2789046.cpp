#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1000003;

long long v[NMAX];

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    int n;
    in >> n;
    for(int i = 1; i <= n; i++)
        in >> v[i];
    long long element_mojoritar = v[1];
    int cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(cnt == 0)
            element_mojoritar = v[i];
        if(v[i] == element_mojoritar)
            cnt++;
        else
            cnt--;
    }
    cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(v[i] == element_mojoritar)
            cnt++;
    }
    if(cnt < n/2+1) out << -1 ;
    else out << element_mojoritar << ' ' << cnt;


    return 0;
}

