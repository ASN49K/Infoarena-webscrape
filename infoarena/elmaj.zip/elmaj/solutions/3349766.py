import random

def ex1():

    with open("elmaj.in", "r") as f:
        data = f.read().split()        
    if not data:
        return
        
    n = int(data[0])
    if n == 0:
        with open("elmaj.out", "w") as f:
            f.write("-1\n")
        return
        
    prag = n // 2 + 1
    
    for _ in range(20):
        idx_aleator = random.randint(1, n)
        candidat = data[idx_aleator]
        
        aparitii = 0
        for i in range(1, n + 1):
            if data[i] == candidat:
                aparitii += 1
                
        if aparitii >= prag:
            with open("elmaj.out", "w") as f:
                f.write(f"{candidat} {aparitii}\n")
            return
            
    with open("elmaj.out", "w") as f:
        f.write("-1\n")

ex1()