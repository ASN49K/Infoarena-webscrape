
#include <bits/stdc++.h>








using namespace std;






ifstream in("elmaj.in");


ofstream out("elmaj.out");






const int DIM = 1e6 + 7;






int v[DIM];






int main()


{


   int n;






   in >> n;










   int k = 0;


   int cand = -1;






   for(int i = 1; i <= n;i ++)


       in >> v[i];






   sort(v + 1, v + 1 + n);






   for(int i = 1; i <= n; i++)


   {






    if(k == 0)


    {


        k++;


        cand = v[i];


    }


    else


    if(v[i] == cand)


    k++;


    else


    k--;






   }






   if(k <= 0)


   {


       out << -1;


       return 0;


   }






   int nr = 0;


   for(int i = 1; i <= n; i++)


   {


       if(v[i] == cand)


           nr++;


   }






  out << cand <<" "<< nr;


   return 0;


}
