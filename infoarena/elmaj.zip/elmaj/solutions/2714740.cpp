/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cstdio>

using namespace std;

#define MAXN 1000000
int Arr[MAXN];

int
main ()
{
  FILE *fin = fopen ("elmaj.in", "r");
  int n;
  fscanf (fin, "%d", &n);

  int i, good, cnt = 0;
  for (i = 0; i < n; i++)
    {
      fscanf (fin, "%d", &Arr[i]);
      if (cnt == 0)
	{
	  cnt = 1;
	  good = Arr[i];
	}
      else
	{
	  if (Arr[i] == good)
	    cnt++;
	  else
	    cnt--;
	}
    }
  fclose (fin);

  cnt = 0;
  for (i = 0; i < n; i++)
    if (Arr[i] == good)
      cnt++;

  FILE *fout = fopen ("elmaj.out", "w");

  if (cnt > n / 2)
    fprintf (fout, "%d %d", good, cnt);
  else
    fprintf (fout, "%d", -1);
  fclose (fout);
  return 0;
}
