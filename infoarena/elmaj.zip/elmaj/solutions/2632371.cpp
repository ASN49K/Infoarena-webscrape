#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n;
int v[1000001];



int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> v[i];
    }

    int cand = -1, k = 0;

    for(int i = 1; i <= n; i++)
    {
        if(k == 0)
        {
            cand = v[i];
            k = 1;
        }
        else if(cand == v[i]) k++;
        else k--;
    }

    int nr = 0;
    for(int i = 1; i <= n; i++)
    {
        if(v[i] == cand) nr++;
    }
    if(nr > n / 2) fout << cand << " " << nr;
    else fout << -1;
    return 0;
}
