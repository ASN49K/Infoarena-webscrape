#include <bits/stdc++.h>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[1000002], n, cnt;

int main()
{
    int x, cnt = 0;
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> a[i];
    for(int pas =1; pas <= 10; pas++)
    {
        x = rand() % n + 1;
        x = a[x];
        cnt = 0;
        for(int i = 1; i <= n; i++)
            if(a[i] == x) cnt++;
        if(cnt > n/2)
        {
            fout << x << " " << cnt;
            fout.close();
            return 0;
        }
    }
    fout << "-1\n";
    fout.close();
    return 0;
}
