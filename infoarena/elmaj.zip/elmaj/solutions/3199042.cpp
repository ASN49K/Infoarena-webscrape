#include<fstream>
#include<unordered_map>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main(){
    int n, a[1000001];
    unordered_map<int, int> v;
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>a[i];
        v[a[i]]++;
    }
    for(auto x:v){
        if(x.second>=n/2+1){
            fout<<x.first<<" "<<x.second;
        }
    }
    return 0;
}
