#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n,a;
    cin >> n;
    vector<int> f;
    f.resize(9999);
    for(int i=0; i<n; ++i){
        cin >> a;
        ++f[a];
        if(f[a]>n/2){
            cout << "exista majoritate";
            return 0;
        }
    }
    cout << "nu exista majoritate";
    return 0;
}
