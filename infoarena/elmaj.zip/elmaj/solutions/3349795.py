import random


with open("elmaj.in", "r") as fin:
    n = int(fin.readline())
    v = list(map(int, fin.readline().split()))

limita = n // 2 + 1

result = -1
for _ in range(20):
    candidat = random.choice(v)
    nr = v.count(candidat)
    if nr >= limita:
        result = candidat
        break

with open("elmaj.out", "w") as fout:
    if result == -1:
        fout.write("-1\n")
    else:
        fout.write(f"{result} {nr}\n")

