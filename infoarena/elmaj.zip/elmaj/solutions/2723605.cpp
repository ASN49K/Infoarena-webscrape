#include <bits/stdc++.h>

using namespace std;

ifstream f;
ofstream g;

int N, x, elem, ap;

int main(){

	f.open("elmaj.in");
	f >> N >> elem;
	ap = 1;
	for(int i = 1;i < N;i++){
		f >> x;
		if(elem != x)
			ap--;
		else ap++;

		if(ap == 0)
			elem = x, ap = 1; 
	}

	f.close(), f.open("elmaj.in");
	f >> N;
	ap = 0;
	for(int i = 1;i <= N;i++){
		f >> x;
		if(x == elem) ap++;
	}

	f.close(), g.open("elmaj.out");
	g << elem << " " << ap;
	g.close();


}