#include <fstream>
#include <cstring>
#include <algorithm>

using namespace std;

ifstream f ("elmaj.in");
ofstream g ("elmaj.out");

int v[1000005], n, i, lg, nr, element, aparitii, j;
bool gasit;
char s[2000005];

int main()
{
f >> n;
f.get();
f.getline(s, sizeof(s));
lg = strlen(s);
n = 0;
 for (i=0; i<lg; i++)
 {
     if (s[i] >= '0' && s[i] <= '9')
     {
         nr = 0;
         while (s[i] >= '0' && s[i] <= '9'  && i < lg)
         {
             nr = nr * 10 + s[i] - '0';
             i ++;
         }
        n ++, v[n] = nr;
     }
 }
sort(v+1, v+n+1);
i = 1, gasit = true;
 while (i <= n && gasit)
 {
    if (v[i] == v[i+1])
    {
        j = i;
         while (v[j] == v[j+1] && j+1 <= n)
             j ++;
        if (j-i+1 >= n/2+1)
        {
            element = v[i];
            aparitii = j-i+1;
            gasit = false;
        }
      i = j;
    }
   i ++;
 }
if (gasit)
   g << -1;
else
   g << element << " " << aparitii;
    return 0;
}
