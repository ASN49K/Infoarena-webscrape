#include <iostream>
#include <fstream>
#include <vector>
#include <random>

using namespace std;

ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    ios_base::sync_with_stdio(false);
    in.tie(NULL);

    int n, ind_random, candidat, cnt;
    if (!(in >> n))
        return 0;
    vector<int> v(n);
    for(int i = 0; i < n; i++)
        in >> v[i];

    mt19937 rng(1337);
    uniform_int_distribution<int> dist(0, n-1);

    for(int i = 0; i < 20; i++)
    {
        ind_random = dist(rng);
        candidat = v[ind_random];
        cnt = 0;

        for(int j = 0; j < n; j++)
        {
            if (v[j] == candidat)
                cnt++;
        }
        if(cnt >= n/2+1)
        {
            out << candidat << " " << cnt << "\n";
            return 0;
        }
    }
    out << "-1 \n";

    return 0;
}