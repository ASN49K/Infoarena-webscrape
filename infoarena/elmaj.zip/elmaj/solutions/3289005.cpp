#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main() {
    int n;
    fin >> n;
    
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        fin >> v[i];

    int incercari=30;
    while(incercari--)
    {
        int random_index = rand() % n;
        int candidat = v[random_index];
        int count = 0;

        for (int i = 0; i < n; i++)
            if (v[i] == candidat)
                count++;

        if (count >= n / 2 + 1) {
            fout << candidat << " " << count << "\n";
            return 0;
        }
    }

    fout << "-1\n";
    return 0;
}
