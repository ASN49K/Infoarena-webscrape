#include <stdio.h>

int v[1000000];

int main() {
  FILE *fin = fopen( "elmaj.in", "r" );
  FILE *fout = fopen( "elmaj.out", "w" );
  int n, i, nrmaj, elmaj;

  fscanf( fin, "%d", &n );
  for( i = 0; i < n; ++i ) {
    fscanf( fin, "%d", &v[i] );
  }
  elmaj = v[0];
  nrmaj = 1;
  for ( i = 1; i < n; ++i ) {
    if ( v[i] == elmaj ) {
      ++nrmaj;
    } else {
      --nrmaj;
    }
    if ( nrmaj < 0 ) {
      elmaj = v[i];
      nrmaj = 1;
    }
  }
  nrmaj = 0;
  for ( i = 0; i < n; ++i ) {
    if ( v[i] == elmaj ) {
      ++nrmaj;
    }
  }
  if ( nrmaj > n / 2 ) {
    fprintf( fout, "%d %d\n", elmaj, nrmaj );
  } else {
    fprintf( fout, "-1\n" );
  }
  fclose( fin );
  fclose( fout );
  return 0;
}
