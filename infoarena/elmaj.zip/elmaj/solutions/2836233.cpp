#include <iostream>
#include <fstream>
#include <unordered_map>
using namespace std;

ifstream fin( "elmaj.in" );
ofstream fout( "elmaj.out" );

unordered_map <int, int> voturi;
int a[1000000];
int main() {
  int n, i;
  fin >> n;
  for( i = 0; i < n; i++ ) {
    fin >> a[i];
    voturi[a[i]]++;
  }
  i = 0;
  while( i < n && voturi[a[i]] <= n / 2 )
    i++;
  if( i == n )
    fout << -1;
  else
    fout << a[i] << " " << voturi[a[i]];
  return 0;
}
