#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int NMax = 1000005;

int v[NMax], n;

int main()
{
    fin >> n;
    for(int i=1; i<=n; ++i){
        fin >> v[i];
    }
    int st = 1, cand = v[1];
    for(int i=2; i<=n; ++i){
        if(st < 1){
            cand = v[i];
            st = 1;
        }
        else if(v[i] != cand){
            -- st;
        }
    }
    int cnt = 0;
    for(int i=1; i<=n; ++i){
        cnt += (v[i] == cand);
    }
    if(cnt >= (n / 2) + 1){
        fout << cand << ' ' << cnt << '\n';
    }
    else{
        fout << -1 << '\n';
    }
    return 0;
}
