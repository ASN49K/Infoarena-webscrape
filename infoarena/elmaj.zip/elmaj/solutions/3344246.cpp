#include <bits/stdc++.h>
using namespace std;

int apar(int n, long long a[], int k){
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(a[i]==k) cnt++;
    }
    return cnt;
}

int elemaj(long long a[], int n){
    if(n==0) return -1;
    int cand=0, cnt=0;
    for(int i=1;i<=n;i++){
        if(cnt==0){
            cand=a[i];
            cnt=1;
        }
        else if(cand==a[i]) cnt++;
        else cnt--;
    }
    if(apar(n, a, cand)>n/2) return cand;
    else return -1;
}

long long a[1000001];

int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    if(elemaj(a, n)==-1) cout<<-1;
    else cout<<elemaj(a, n)<<" "<<apar(n, a, elemaj(a, n));
}
