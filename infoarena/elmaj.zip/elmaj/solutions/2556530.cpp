#include <fstream>

using namespace std;

const int NMAX = 1e6 + 5;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[NMAX];
int main() {
    int n;
    cin >> n;
    int elem = 0, fv = 0;
    cin >> v[1];
    elem = v[1];
    fv = 1;
    for(int i = 2; i <= n; ++i) {
        cin >> v[i];
        if(v[i] == elem) {
            fv++;
        } else {
            fv--;
            if(fv == 0) {
                elem = v[i];
                fv = 1;
            }
        }
    }
    int ans = 0;
    for(int i = 1; i <= n; ++i) {
        if(v[i] == elem)
            ans++;
    }
    if(ans >= (n + 1) / 2)
        cout << elem << " " << ans << "\n";
    else
        cout << "-1\n";
    return 0;
}