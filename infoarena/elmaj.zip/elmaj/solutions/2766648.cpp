#include <iostream>
#include <fstream>
#include <vector>
#define MOD 173333

using namespace std;

ifstream fin  ("elmaj.in");
ofstream fout ("elmaj.out");

vector <pair <int, int> > h[MOD];
int n, x, ok, sol, ap;

int main (){
    fin>>n;
    for(int i=1; i<=n; i++){
        fin>>x;
        ok=0;
        for(int j=0; j<h[x%MOD].size(); j++)
            if(h[x%MOD][j].first == x){
                ok=1;
                h[x%MOD][j].second++;
                if(h[x%MOD][j].second > n/2){
                    sol=x;
                    ap=h[x%MOD][j].second;
                }
                break;
            }

        if(ok == 0)
            h[x%MOD].push_back({x, 1});
    }
    if(sol != 0)
        fout<<sol<<" "<<ap;
    else
        fout<<-1;
    return 0;
}
