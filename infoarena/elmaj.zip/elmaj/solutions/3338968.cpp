#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int cont=0;
int n;
int a[1000000],ales=-1;


int main()
{
    int i;
    fin>>n;

    for (i=1; i<=n; i++)
    {
        fin>>a[i];
        if (a[i]!=ales)
        {
            cont--;
            if (cont<=0)
            {
                ales=a[i];
                cont=1;
            }
        }
        else
            cont++;
    }
    ///check
    cont=0;
    for (i=1; i<=n; i++)
    {
        if (a[i]==ales)
            cont++;
    }
    if (cont>=n/2+1)
        fout<<ales<<' '<<cont;
    else
        fout<<-1;
    return 0;
}
