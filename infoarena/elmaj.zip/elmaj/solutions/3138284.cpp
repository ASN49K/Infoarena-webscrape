#include <fstream>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, b, s=1, v[1000020],i,nr;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i];

    b=v[1];
    for(i=2;i<=n;i++)
    {
       // fout<<b<<'\n';
        if(b!=v[i])
            s--;
        else
            s++;
        if(s==0)
        {
            b=v[i];
            s=1;
        }
    }

    for(i=1;i<=n;++i)
        if(b==v[i])
            ++nr;
    if(nr>=n/2+1)
        fout<<b<<" "<<nr;
    else
    fout<<"-1";
    return 0;
}
