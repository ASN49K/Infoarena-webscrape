#include <fstream>
#define nmax 1000005
using namespace std;
int v[nmax],n,cnt,candidat;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
    }
    cnt=-1;
    for(int i=1;i<=n;i++)
    {
        if(cnt==0)///daca nu avem niciun candidat necuplat
        {
            candidat=v[i];
            cnt=1;///facem elementul de pe pozitia i candidat
        }
        else if (v[i]==candidat)///creste numarul de candidati necuplati
        {
            cnt++;
        }
        else cnt--;///scade numarul de candidati necuplati
    }
    cnt=0;
    for(int i=1;i<=n;i++)
        if(v[i]==candidat)
            cnt++;
    if(cnt>n/2)
        cout<<candidat;
    else cout<<-1;
    return 0;
}