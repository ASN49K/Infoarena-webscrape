#include <stdio.h>
#include <stdlib.h>

int v[3000000];

int main() {
    int n, nr, ap, i;
    FILE *fin, *fout;

    fin = fopen( "elmaj.in", "r" );
    fscanf( fin, "%d%d", &n, &v[0] );
    nr = v[0];
    ap = 1;
    for( i = 1; i < n; i++ ) {
        fscanf( fin, "%d", &v[i] );
        if( v[i] == nr )
            ap++;
        else {
            ap--;
            if( ap < 0 ) {
                nr = v[i];
                ap = 1;
            }
        }
    }
    fclose( fin );
    ap = 0;
    for( i = 0; i < n; i++ )
        if( v[i] == nr )
            ap++;
    fout = fopen( "elmaj.out", "w" );
    if( n / 2 < ap )
        fprintf( fout, "%d %d", nr, ap );
    else
        fprintf( fout, "-1" );
    fclose( fout );
    return 0;
}
