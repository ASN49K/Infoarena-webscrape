#include <bits/stdc++.h>
using namespace std;
#define NMAX 1000001
int a[NMAX];
int32_t main(void) {
    ofstream cout("elmaj.out");
    ifstream cin("elmaj.out");
    int n;
    cin >> n;
    int cand = -1, nr = 0;
    for(int i  =1;i <=n;i++)cin >> a[i];
    for(int i = 1;i <= n;i++) {
        if(nr == 0)cand = a[i];
        if(a[i] == cand)nr++;
        else nr--;

    }
    bool ok = true;
    nr = 0;
    for(int i = 1;i <= n;i++) {
        if(a[i] == cand) {
            ++nr;
        }
    }
    if(nr >= n / 2 + 1) {
        cout << cand << ' ' << nr;
    }else cout << -1;
}