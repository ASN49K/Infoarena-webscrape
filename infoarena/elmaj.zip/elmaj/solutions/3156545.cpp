#include <iostream>
#include <fstream>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");

int main()
{
     long elem;
     long k = 1;
     long n;
     f >> n;
     long v[n];
     f >> v[0];
     elem = v[0];
     for (long i = 1; i < n; i++)
     {
         f>>v[i];
         if(elem==v[i])
            k++;
         else
            k--;

         if(k==0)
            elem=v[i];
            k=1;

     }
     g << elem << ' ';
     long c=0;
     for (long i = 0; i < n; i++)
     {
         if (elem == v[i])
            c++;

     }
     g << c << ' ';
     return 0;



}
