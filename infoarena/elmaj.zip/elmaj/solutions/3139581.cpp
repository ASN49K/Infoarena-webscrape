#include <iostream>
#include <fstream>
using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[1000001];

int main()
{
    int n,nr=0,cand=-1,i;
    f>>n;
    for (i=1;i<=n;i++)
    {
        f>>v[i];
        if (nr==0)
        {
            cand=v[i];
            nr=1;
        }
        else
            if (v[i]==cand)
            nr++;
            else
            nr--;
    }
    if (nr==0)
        g<<"-1";
    else
    {
        nr=0;
        for(i=1;i<=n;i++)
            if (v[i]==cand)
                nr++;
            if (nr>n/2)
                g<<cand<<' '<<nr;
            else
                g<<"-1";
    }
    return 0;
}
