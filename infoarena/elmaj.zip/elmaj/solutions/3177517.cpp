#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int n, v[1000005], rez, cnt;

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
        if (cnt == 0) {
            cnt = 1, rez = v[i];
        }
        if (rez == v[i]) {
            cnt++;
        } else {
            cnt--;
        }
    }

    cnt = 0;
    for (int i = 1; i <= n; i++)
        if (v[i] == rez)
            cnt++;
    if (cnt >= n/2+1)
        cout << rez << " " << cnt;
    else
        cout << -1;

    return 0;
}
