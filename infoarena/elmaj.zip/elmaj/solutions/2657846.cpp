#include<fstream>
#include<ctime>
#include<cstdlib>
using namespace std;
#define maxn 3000005
int v[maxn],n,k,nr;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
 
int quicksort(int inf, int sup){
   int x,aux,i,j;
   i=inf;
   j=sup;
   x=v[inf+(rand()%(sup-inf+1))];
   while(i<=j){
    while(i<sup && v[i]<x) i++;
    while(j>inf && v[j]>x) j--;
    if(i<=j){
        aux=v[i];
        v[i]=v[j];
        v[j]=aux;
        i++; j--;
    }
   }
   return j;
};
 
void part(int li,int lf,int k){
    if(li==lf)
        return;
    int q=quicksort(li,lf);
    int t=q-li+1;
    if(t>=k)
        part(li,q,k);
    else
        part(q+1,lf,k-t);
}
 
int main()
{
    srand(time(NULL));
    cin>>n;
    k=n/2;
    for(int i=1; i<=n; i++)
       cin>>v[i];
    part(1,n,k);
    for(int i=1; i<=n; i++)
        if(v[i]==v[k])
            nr++;
    if(nr>n/2)
        cout<<v[k]<<' '<<nr;
    else cout<<-1;
    return 0;
}
