#define _CRT_SECURE_NO_WARNINGS
#pragma GCC optimize("O3")
#pragma comment(linker, "/stack:200000000") // A lot of recursion
#pragma GCC optimize("Ofast,unroll-loops,no-stack-protector,fast-math")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <bits/stdc++.h>
#define fast ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n,x[1000005],i,aux,k=0;
int main(){
    fast;
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>x[i];
        if(k==0){
            aux=x[i];
            k++;
        }
        if(aux==x[i])
            k++;
        else
            k--;
    }
    fout<<aux << " ";
    k=0;
    for(i=1;i<=n;i++)
        if(aux==x[i])
            k++;
    fout << k;

return 0;
}
