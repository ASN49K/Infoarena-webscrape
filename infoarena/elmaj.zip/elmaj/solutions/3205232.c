#include <stdio.h>

#define NMAX 1000000
int v[ NMAX ];

int main() {
  FILE *fin, *fout;
  int n, i, cand, cnt;

  fin = fopen( "elmaj.in", "r" );
  fscanf( fin, "%d", &n );
  cand = -1;
  cnt = 0;
  for ( i = 0; i < n; i++ ) {
    fscanf( fin, "%d", &v[ i ] );
    if ( cnt == 0 ) {
      cand = v[ i ];
      cnt = 1;
    } else {
      cnt += 1 - 2 * (v[ i ] != cand);
    }
  }
  fclose( fin );

  cnt = 0;
  for ( i = 0; i < n; i++ ) {
    if ( v[ i ] == cand )
      cnt++;
  }

  fout = fopen( "elmaj.out", "w" );
  if ( cnt > n / 2 ) {
    fprintf( fout, "%d %d\n", cand, cnt );
  } else {
    fprintf( fout, "-1\n" );
  }
  fclose( fout );

  return 0;
}
