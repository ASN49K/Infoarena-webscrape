#include <iostream>
#include <fstream>

using namespace std;
int v[100005],poz[100005];
int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    int n,ci,max=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>v[i];
        poz[v[i]]++;
    }

    for(int i=0;i<n;i++)
    {
        if(poz[i]>max)
        {
            max=poz[i];
            ci=i;
        }
    }

    cout<<ci<<" "<<max;

    return 0;
}
