#include <fstream>
using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int main()
{
    int n, a[1000002];
    fin >> n;
    for (int i=0; i<n; i++)
    {
        fin >> a[i];
    }
    int nr=0;
    int x;
    for (int i=0; i<n; i++)
    {
        if (nr==0)
        {
            x=a[i];
            nr=1;
        }
        else
        {
            if (x==a[i])
            {
                nr++;
            }
            else
            {
                nr--;
            }
        }
    }
    nr=0;
    for (int i=0; i<n; i++)
    {
        if (x==a[i])
        {
            nr++;
        }
    }
    if (nr>n/2)
    {
        fout << x << " " << nr;
    }
    else
    {
        fout << "-1";
    }
    return 0;
}
