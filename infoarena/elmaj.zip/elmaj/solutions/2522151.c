#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ap[1 000 000];
    int n,elem,C=-1,count=0;
    FILE *pfi;
    FILE *pfo;
    pfi=fopen("elmaj.in","r");
    pfo=fopen("elmaj.out","w");
    fscanf(pfi,"%d", &n);

    for(int i=0; i<n; i++)
    {
        fscanf(pfi,"%d", &elem);

        if(C==elem)
            count++;
        else
            count--;

        if(count<0)
        {
            count=-1;
            C=elem;
        }
    }

    fseek(pfi,0,SEEK_SET);
    fscanf(pfi,"%d", &n);



    int number=0;

    for(int i=0; i<n; i++)
    {
        fscanf(pfi,"%d", &elem);
        if(C==elem)
            number++;

    }

    if(number>n/2)
        fprintf(pfo,"%d %d",C, number);
    else
        fprintf(pfo,"-1");
    return 0;
}
