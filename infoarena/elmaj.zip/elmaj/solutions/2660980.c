#include <stdio.h>
#include <stdlib.h>

int v[1000000];

int main()
{
    FILE *fin, *fout;
    int n, i, nrap, elmaj;
    fin = fopen("elmaj.in", "r");
    fscanf(fin, "%d", &n);
    nrap = 0;
    for(i = 0; i < n; i++){
      fscanf(fin, "%d", &v[i]);
      if(nrap == 0){
        elmaj = v[i];
        nrap++;
      }else{
        if(elmaj == v[i]){
          nrap++;
        }else{
          nrap--;
        }
      }
    }
    fclose(fin);
    nrap = 0;
    for(i = 0; i < n; i++){
      if(elmaj == v[i]){
        nrap++;
      }
    }
    fout = fopen("elmaj.out", "w");
    if((n / 2) < nrap){
      fprintf(fout, "%d %d", elmaj, nrap);
    }else{
      fprintf(fout, "-1");
    }
    fclose(fout);
    return 0;
}
