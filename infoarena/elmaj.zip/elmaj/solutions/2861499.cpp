#include <iostream>
#include <fstream>

using namespace std;

int main() {
    ifstream fin("elmaj.in");
    ofstream fout("almej.out");
    int vec[1000000];
    int n;
    fin >> n;
    for (int index = 0; index < n; ++index) {
        fin >> vec[index];
    }
    int cand = -1, k = 0;
    for (int index = 0; index < n; ++index) {
        if (k == 0) {
            cand = vec[index];
            k = 1;
        } else if (cand == vec[index]) {
            ++k;
        } else {
            --k;
        }
    }
    if (cand < 0) {
        fout << -1;
        return 0;
    }
    int cnt = 0;
    for (int index = 0; index < n; ++index) {
        if (cand == vec[index]) {
            ++cnt;
        }
    }
    if (cnt > n / 2) {
        fout << cand << " " << cnt;
    } else {
        fout << -1;
    }
    return 0;
}
