#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <stack>
#include <algorithm>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int N = 1000001;

int main() {

	int n, cnt, elmaj, x, a[N];
	cnt = 0;
	fin >> n;
	fin >> elmaj;
	a[1] = elmaj;
	cnt = 1;
	for (int i = 2; i <= n; ++i) {
		fin >> a[i];
		if (cnt == 0) {
			elmaj = a[i];
		}
		else
			if (a[i] != elmaj)
				cnt--;
			else
				cnt++;
	}
	cnt = 0;
	for (int i = 1; i <= n; ++i)
		if (a[i] == elmaj) cnt++;
		else cnt--;

	if (cnt > n / 2) fout << elmaj << " " << cnt;
	else fout << -1;

	/*

	fin.close();
	ifstream fin("a.in");
	cnt = 0;
	fin >> n;

	for (int i = 1; i <= n; ++i) {
		fin >> x;
		if (x == elmaj)
			++cnt;
	}
	if (cnt > n / 2)
		cout << "am elmaj" << elmaj;
	else
		cout << "nu exista";*/

}