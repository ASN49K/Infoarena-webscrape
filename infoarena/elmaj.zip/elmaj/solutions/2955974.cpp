#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int x,a,k,n,v[1000005];
int main()
{
    f>>n>>v[1];
    k=1,a=v[1];
    for(int i=2; i<=n; ++i)
    {
        f>>v[i];
        if(v[i]!=a)
        {
            --k;
            if(k==-1)
                k=1,a=v[i];
        }
        else ++k;
    }
    for(int i=1; i<=n; ++i)
        if(v[i]==a) ++x;
    if(x>=n/2+1) g<<a<<' '<<x;
    else g<<-1;
    return 0;
}
