#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("clepsidru.in");
ofstream fout("clepsidru.out");

  int v[1000];

int main() 
{
  int n, b, k, s, p;
  fin >> n >> b >> k;

  v[0] = b;

  fout << b + n - 1 << endl;
  int x = 1;
  int last = 0;
  int pBef = 0;
  for(int i = 0; i < k; i++)
  {
    
    int s, p;
    fin >> s >> p;
    for(int j = 0; j < s; j++)
    {
      if(pBef != p && pBef != 0)
      {

        if(x == -1) x = 1;
        else if(x == 1) x = -1;
      }
      pBef = p;

      for(int ii = 0; ii <= n; ii++)
      {
        if(ii - x > n)
          break;
        if(v[ii - x] > 0 && ((ii >= 1 && x == 1) || (ii <= n && x == -1)))
        {
          v[ii]++;
          v[ii - x]--;
        }

        for(int l = 0; l <= n; l++)
        {
          cout << v[l];
        }
        cout << endl;

        if(v[ii + x] == 0 && v[ii] < 2)
          break;
          
          
        

      }
      cout << endl;
    }
    
  }

  if(pBef == 2)
  {
    for(int i = 0; i <= n; i++)
    {
      //cout << "ok";
      if(i == 0 || i == n)
      {
      fout << v[i] << ' ';
      }
      else
        fout << v[i] << endl << 0 << ' ';
    }
  }
  else
  {
    //cout << "ok";
    for(int i = n; i >= 0; i -= 1)
    {

      if(i == 0 || i == n)
      {
        fout << v[i] << ' '; 
      }
      else
      {
        fout << v[i] << endl << 0 << ' ';
      }
        


    }
  }
  
    
  
}