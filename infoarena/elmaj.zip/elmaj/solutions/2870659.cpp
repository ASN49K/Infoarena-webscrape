#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("elmaj.in");
ofstream fout ("elmaj.out");

const int MAX_N = 100050;

int n, x, v[MAX_N], maj, frq;

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin>>n>>v[1];
    maj = v[1];
    frq = 1;
    for(int i=2; i<=n; i++){
        fin>>v[i];
        x = v[i];

        if(frq == 0){
            maj = x;
            frq = 1;
            continue;
        }

        if(x == maj)
            frq++;
        else
            frq--;
    }

    frq = 0;
    for(int i=1; i<=n; i++)
        frq += (v[i] == maj);

    if(frq >= n/2+1)
        fout<<maj<<" "<<frq;
    else
        fout<<-1;
    return 0;
}
