#include <bits/stdc++.h>
using namespace std;
ifstream in("becuri.in");
ofstream out("becuri.out");
int n, v[1000010], i, cand, k;
int main()
{
    in >> n;
    for (i = 1; i <= n; i++)
        in >> v[i];
    for (i = 1; i <= n; i++)
    {
        if (k == 0)
        {
            cand = v[i];
            k++;
        }
        else if (cand == v[i])
        {
            k++;
        }
        else
            k--;
    }
    k = 0;
    for (i = 1; i <= n; i++)
    {
        if (v[i] == cand)
            k++;
    }
    if (k >= n/2+1)
        out << cand << ' ' << k;
    else
        out << -1;
    return 0;
}
