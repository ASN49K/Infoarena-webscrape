#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int a[1000005], n, fr[1000005];

int main()
{
    f >> n;

    for (int i = 1; i <= n; ++i) {
        f >> a[i];
    }

    for (int i = 1; i <= n; ++i) {
        fr[a[i]]++;
    }

    int nr = n / 3, nuNr = 0, ok;

    for (int i = 1; i <= n; ++i) {
        if (fr[i] > nr) {
            g << i << ' ' << fr[i];
            ok = 1;
            break;
        }
    }

    if (ok != 1) {
        g << -1;
    }

    return 0;
}
