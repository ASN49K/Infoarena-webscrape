#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int Dim = 2 * (1 << 20);
int x[Dim], n;
int ap[Dim];
int nr_ap_max, nr;

int main(){
    fin >> n;

    for (int i = 1; i <= n; ++i){
        fin >> x[i];
        ap[x[i]] ++;
    }

    for (int i = 1; i <= n; ++i)
        if (ap[i] > nr_ap_max){
            nr_ap_max = ap[i];
            nr = i;
        }

    fout << nr << ' ' << nr_ap_max;

    return 0;
}