#include <iostream>
#include <fstream>
using namespace std;
int main(){
	ifstream fin("elmaj.in");
	ofstream fout("elmaj.out");
	long long n, v[1000000], nr = 0;
	fin >> n;
	for(int i = 0; i < n; i++){
		fin >> v[i];
	}
	for (int j = 0; j < n; j++){
		nr = 0;
		for(int k = j; k < n; k++){
			if(v[j] == v[k]){
				nr++;
			}
		}
		if(nr > n/2){
			fout << v[j] << " "<<nr<<'\n';
		}
	}
	return 0;
}