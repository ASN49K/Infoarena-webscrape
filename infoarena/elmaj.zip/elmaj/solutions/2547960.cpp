#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int v[1000001];

int main()
{
    int n,k=0,maxim=-1;
    unsigned a;

    fin>>n;

    for (int i=0; i<n; i++)
    {
        fin>>a;
        v[a]++;
        if (v[a]>maxim)
        {
            maxim=a;
           // cout<<"max: "<<maxim<<endl;
        }
    }
    if (maxim!=-1 && v[maxim] > n/2)
        for (int i=0; i<1000001; i++)
        {
            if (v[i]==v[maxim])
                k++;
        }

    if (k==1)
        fout<<maxim<<' '<<v[maxim];
    else
        fout << -1;

    return 0;
}
