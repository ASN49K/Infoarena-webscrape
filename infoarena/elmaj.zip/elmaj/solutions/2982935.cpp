#include <iostream>
#include <fstream>
using namespace std;

int ap[4][1001];

int main(){
    ifstream fin("elmaj.in");
    ofstream fout("elmaj.out");
    int baza=1000,nr,n;
    fin>>n;
    while (fin>>nr)
        for (int i=0; i<4 && nr; ++i, nr/=1000)
            ++ap[i][nr%1000];
    fin.close();
    int nrmaj=0;
    for(int i=0; i<4; ++i){
        int maxx=0,maxj=0;
        for (int j=0; j<1000; ++j)
            if(ap[i][j]>maxx){
                maxx=ap[i][j];
                maxj=j;
            }
        int pow1000=1;
        for (int pow=i; pow; --pow)
            pow1000*=1000;
        nrmaj+=pow1000*maxj;
    }
    ifstream f("elmaj.in");
    int cont=0;
    f>>n;
    while (f>>nr)
        if (nr==nrmaj)
            ++cont;
    if (cont>n/2)
        fout<<nrmaj<<' '<<cont;
    else fout<<-1;
}






















