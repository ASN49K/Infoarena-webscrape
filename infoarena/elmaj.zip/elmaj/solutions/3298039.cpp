#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

const int MAX=1e6;
int n,i,v[MAX+5],cnt,candidat,nr;


int main()
{
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>v[i];

    for (i=1; i<=n; i++)
    {
        if (cnt==0)
        {
            cnt++;
            candidat=v[i];
        }
        else
        {
            if (candidat==v[i])
                cnt++;
            else
                cnt--;
        }
    }

    for (i=1; i<=n; i++)
        if (v[i]==candidat)
            nr++;

    if (nr>n/2)
        fout<<candidat<<" "<<nr;
    else
        fout<<-1;
    return 0;
}
