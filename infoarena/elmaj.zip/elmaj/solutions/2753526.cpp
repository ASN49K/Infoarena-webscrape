#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
typedef vector<int> vec;
typedef vector<int64> vec64;
    string __fname = "elmaj";
    ifstream in (__fname + ".in");
    ofstream out (__fname + ".out");
    #define cin in
    #define cout out
#define ss cout << " ";
#define nn cout << "\n";
#define ct(x) cout << x;
#define cts(x) cout << x << " ";
#define ctn(x) cout << x << "\n";
#define db(x) cout << "> " << #x << ": " << x << "\n";
#define qr queries();
void solve(int);
void YN(bool b){if (b){ctn("YES");}else{ctn ("NO");}};
void yn(bool b){if (b){ctn("Yes");}else{ctn ("No");}};
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
const int64 mod = 1000000007;
const double pi = 3.14159265359;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
 
void solve(int id){

    return;
}
 
 
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int n;
    cin >> n;
    map <int, int> mp;
    int rs = -1;
    for (int i = 0; i < n; i++){
        int t;
        cin >> t;
        mp[t]++;
        if (mp[t] >= n / 2 + 1) {
            rs = t;
        }
    }
    if (rs == -1) {
        ctn(rs);
        return 0;
    }
    cts(rs); ctn(mp[rs]);
    return 0;
}
