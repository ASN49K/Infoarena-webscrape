#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int v[1000005];

int main()
{
    int n,i,nr,sol,s=0;
    fin>>n;
    for(i = 1; i <= n; i++){
        fin>>nr;
        v[i] = nr;
        if(s == 0){
            sol = nr;
            s++;
        }else{
            if(nr == sol){
                s++;
            }else{
                s--;
            }
        }
    }
    s = 0;
    for(i = 1; i <= n; i++){
        if(v[i] == sol){
            s++;
        }
    }
    if(s > n/2){
        fout<<sol<<' '<<s;
    }else{
        fout<<-1;
    }
    return 0;
}
