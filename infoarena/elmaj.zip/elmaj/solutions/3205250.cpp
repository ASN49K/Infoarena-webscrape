#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");

int v[1000003];

int main()
{
    int n, cand=-1, a, cnt=0;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>v[i];
    }
    for(int i=0; i<n; i++)
    {
        if(cnt==0)
        {
            cand=v[i];
        }
        else if(cand==v[i])
        {
            cnt++;
        }
        else
            cnt--;
    }
    cnt=0;
    for(int i=0; i<n; i++)
    {
        if(v[i]==cand)
            cnt++;
    }
    if(cnt>=n/2+1)
        cout<<cand<<" "<<cnt;

    return 0;
}
