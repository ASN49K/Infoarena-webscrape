#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n,a[1000001],cnt=1;
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a[i];
    }
    sort(a,a+n+1);
    for(int i=1;i<=n;i++)
    {
        if(a[i]!=a[i-1])
            cnt=1;
        else
            cnt++;
        if(cnt>=n/2+1)
        {
            i++;
            while(a[i]==a[i-1])
            {
                i++;
                cnt++;
            }
            fout<<a[i-1]<<" "<<cnt;
            break;
        }
    }
    return 0;
}

