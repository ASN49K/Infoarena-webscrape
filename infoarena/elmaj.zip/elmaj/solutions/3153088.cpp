#include <fstream>

using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000001];
int main()
{
    int n,i,nr=0,nrap=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i];
        if(v[i]==nr)
            nrap++;
        else
        {
            nrap--;
            if(nrap<0)
            {
                nrap=1;
                nr=v[i];
            }
        }
    }
    nrap=0;
    for(i=1;i<=n;i++)
        if(v[i]==nr)
            nrap++;
    if(nrap>=n/2+1)
        cout<<nr;
    else
        cout<<-1;
    return 0;
}
