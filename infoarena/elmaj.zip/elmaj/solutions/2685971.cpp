using namespace std;
#include<bits/stdc++.h>

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n;
long long v[1000001];

int main() {
    
    fin >> n;
    for (int i = 1; i<=n; i++) {
        fin >> v[i];
    }
    
    int candidat = -1, voturi = 0;
    for (int i = 1; i<=n; i++) {
        if (voturi == 0) {
            candidat = v[i];
            voturi++;
        } else if (v[i] == candidat) {
            voturi++;
        } else {
            voturi--;
        }
    }
    
    voturi = 0;
    for (int i = 1; i<=n; i++) {
        if (v[i] == candidat) {
            voturi++;
        }
    }
    
    if (voturi <= n/2) {
        fout << "-1";
    } else {
        fout << candidat << " " << voturi; 
    }
    
    
    
    fin.close();
    fout.close();
    
    return 0;
}
