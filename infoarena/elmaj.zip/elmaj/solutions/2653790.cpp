#include <fstream>

using namespace std;
int a[1001];
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int main()
{
    int e=0, n, x, i,cnt=1,ap=0;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i];
    for(i=1;i<=n;i++)
    {
     if(a[i]==a[i+1]){cnt++;e=a[i+1];}
        else {cnt--;e=a[i];}
        if(cnt==-1)cnt==0;
    }
    for(i=1;i<=n;i++)
    {
        if(a[i]==e)ap++;
    }
    if(ap<n/2+1)fout<<-1;
    fout<<e<<" "<<ap;
    return 0;
}
