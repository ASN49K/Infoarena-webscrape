#include <bits/stdc++.h>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
long long int n,v[1000011],ap,c;
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>v[i];
        if(c!=v[i])
        {
            if(ap)
                ap--;
            else
            {
                c=v[i];
                ap=1;
            }
        }
        else
            ap++;
    }
    ap=0;
    for(int i=1; i<=n; i++)
    {
        if(v[i]==c)
            ap++;
    }
    if(ap>=(n/2)+1)
        fout<<c<<' '<<ap;
    else
        fout<<-1;
    return 0;
}
