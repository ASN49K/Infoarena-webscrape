#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
ifstream fin("elmaj.in"); ofstream fout("elmaj.out");


int n;
vector<int> a;
map<int, int> e;



int main(){
fin>>n;
int o=0, el=0;

a.resize(n+5);


bool f=false;

for(int i=0; i<n; i++){
    fin>>a[i];

    if(!f){
    e[a[i] ]++;
    int c=e[a[i] ];
    if(c>o){el=a[i]; o=c;}

    if(o>n/2){
    f=true;}

    }
    else{
        if(a[i]==el){
            o++;
        }
    }




}



if(o>n/2){
fout<<el<<" "<<o; return 0;}
else{
fout<<-1;}



return 0;
}
