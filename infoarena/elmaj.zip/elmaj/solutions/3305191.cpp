#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int v[1000001];

int main()
{
    int n;
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
    }
    sort(v + 1, v + n + 1);
    int cntEgale = 0, mxEgale = 0, elemMaj = -1;
//    7
//    2 3 3 4 4 4 4
    for (int i = 1; i <= n; i++)
    {
        if (v[i] != v[i - 1])
        {
            if (cntEgale > mxEgale)
            {
                mxEgale = cntEgale;
                elemMaj = v[i - 1];
            }
            cntEgale = 1;
        }
        else
        {
            cntEgale++;
        }
    }
    if (cntEgale > mxEgale)
    {
        mxEgale = cntEgale;
        elemMaj = v[n];
    }
    if (mxEgale >= n / 2 + 1)
    {
        g << elemMaj << ' ' << mxEgale;
    }
    else
        g << -1;
    return 0;
}