#include <fstream>
#include <unordered_map>
#include <assert.h>

std::pair<int, int> hashMaj(int n, int v[]) {
	std::unordered_map<int, int> map;

	for (int i = 0 ; i < n ; ++i) {
		if (map.find(v[i]) == map.end()) {
			map.insert(std::make_pair(v[i], 1));
		} else {
			++map[v[i]];
		}
	}

	for (int i = 0 ; i < n ; ++i) {
		if (map.find(v[i])->second > n / 2) {
			return std::make_pair(v[i], map.find(v[i])->second);
		}
	}

	return std::make_pair(-1, -1);
}

int main() {
	std::ifstream cin("elmaj.in");
	std::ofstream cout("elmaj.out");
	std::ios::sync_with_stdio(false);
	int n;
	cin >> n;
	assert(1 <= n && n <= 1000000);
	int v[n];
	
	for (int i = 0 ; i < n ; ++i) {
		cin >> v[i];
	}

	std::pair<int, int> p = hashMaj(n, v);

	cout << p.first << " " << p.second << '\n';

	return 0;
}