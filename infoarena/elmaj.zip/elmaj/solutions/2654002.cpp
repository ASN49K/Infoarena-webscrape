
#include <bits/stdc++.h>

using namespace std;
ifstream f1("elmaj.in");
ofstream g("elmaj.out");

int main()
{
   int n;
   f1>>n;
   int candidat;
   f1>>candidat;
   int k = 1;
   for(int i=2;i<=n;i++)
   {
       int elem;
       f1>>elem;
       if(elem==candidat)k++;
       else k--;
       if(k<0)candidat = elem , k=1;
   }
   //f1.close();
    ifstream f2("elmaj.in");
   f2>>n;
   int cnt = 0;
   for(int i=1;i<=n;i++)
   {
       int elem;
       f2>>elem;
       if(elem == candidat)cnt++;
   }
    if(cnt >= n/2 + 1){g<<candidat<<' '<<cnt;}
    else g<<-1;



    return 0;
}
