#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>


using namespace std;

int main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
         

    int N, cand = 0, ap = 0;
    cin >> N;
    vector<int> A;

    for(int i = 0, x; i < N; ++i){
        cin >> x;
        A.push_back(x);
        if(ap == 0){
            cand = x;
            ap = 1;
        }
        else if(cand == x)
            ++ap;
        else --ap;
    }
    ap = 0;
    for(int i = 0; i < N; ++i)
        if(A[i] == cand)
            ++ap;
    if(ap > N / 2)
        cout << cand << " " << ap;
    else cout << -1;
  
    cin.close();
    cout.close();

    return 0;
}