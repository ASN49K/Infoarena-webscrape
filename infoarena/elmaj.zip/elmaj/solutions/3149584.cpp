#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, k, cand; // cand - candidat, k - nr de candidati 'cand' neimperecheati
int a[1000001];

int main()
{
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i];
    for (int i = 1; i <= n; i++)
        if (!k)
            k = 1, cand = a[i];
        else if (a[i] == cand) // nu am putut imperechea pe i si astfel trebuie
            k++;               // sa marim nr de candidati neimperecheati k
        else
            k--; // cuplam pe i cu oricare alt candidat si micsoram -//- k

    k = 0; // k numara acum frecventa canditatului cel mai popular
    for (int i = 1; i <= n; i++)
        if (a[i] == cand)
            k++;
    if (k > n / 2)
        fout << cand << " " << k;
    else
        fout << "-1";
    return 0;
}
