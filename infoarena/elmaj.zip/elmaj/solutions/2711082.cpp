#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int  n, a[1000001];

int main()
{
    fin >> n;
    for(int i = 0; i < n; ++i)
        fin >> a[i];
    int candidat_acum = -1, de_cate_ori_apare = 0;
    for(int i = 0; i < n; ++i)
    {
        if(de_cate_ori_apare == 0)
        {
            candidat_acum = a[i];
            de_cate_ori_apare++;
        }
        else if(a[i] != candidat_acum)
        {

            de_cate_ori_apare--;
        }
        else
            de_cate_ori_apare++;
    }
    int nr = 0;
    for(int i = 0; i < n; ++i)
        if(a[i] == candidat_acum)
            nr++;
    ///cout << candidat_acum << ' ' << nr;
    if(nr >= n / 2 + 1)
        fout << candidat_acum << ' ' << nr;
    else
        fout << -1;
    return 0;
}
