#include <fstream>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n,i,nr,x,v[1000002];
int main()
{
    fin>>n;
    for(i = 1;i <= n;i++)
    {
        fin>>v[i];
        if(nr == 0)
            x = v[i];
        if(v[i] == x)
            nr++;
        else
            nr--;
    }
    if(nr <= 0)
        fout<<-1;
    else
    {

        nr = 0;
        for(i = 1;i <= n;i++)
            if(v[i] == x)
                nr++;
        fout<<x<<" "<<nr;
    }
    return 0;
}
