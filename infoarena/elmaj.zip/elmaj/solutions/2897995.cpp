#include <bits/stdc++.h>

using namespace std;

int n , cnt = 0,cand;
int A[1000005];

int main()
{
    freopen("elmaj.in" , "r" , stdin);
    freopen("elmaj.out" , "w" ,stdout);
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    cin >> n;
    for(int i = 1;i <= n; ++i){
        cin >> A[i];
        if(cnt == 0)
            cand = A[i],cnt = 1;
        else
        if(cand != A[i])
            cnt--;
        else cnt++;

    }
    cnt = 0;
    for(int i = 1;i <= n; ++i)cnt += (A[i] == cand);
    if(cnt >= n/2 + 1){
        cout << cand << " " << cnt;
        return 0;
    }
    cout << -1;
}

