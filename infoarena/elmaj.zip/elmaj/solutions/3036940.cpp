#include <bits/stdc++.h>
#include <ctime>
using namespace std;
int v[1000000];
fstream f("elmaj.in", ios::in), g("elmaj.out", ios::out);
unordered_map<int, int> m;
int main()
{
    srand(time(0));
    int n;
    f >> n;
    for (int i = 0; i < n; i++)
        f >> v[i], m[v[i]]++;
    for (int i = 0; i < 10; i++)
    {
        int j = rand() % n;
        if (m[v[j]] > n / 2)
        {
            g << v[j] << ' ' << m[v[j]];
            return 0;
        }
    }
    g << -1;
}
