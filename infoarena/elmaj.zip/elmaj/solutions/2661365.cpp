#include <fstream>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

ifstream be("ssnd.in");
ofstream ki("ssnd.out");
int MOD=9973,nmax=1e6;

vector<bool>a(nmax+5,true);
void szita()
{
    a[1]=false;
    for(int i=2;i<=1e6;i++)
    {
        if(a[i]==true){
        for(int j=2;i*j<=1e6;j++)
            a[i*j]=false;}
    }

}

long long x=1;

long long  hatvany( long long n,long long p)
{


    if(p!=0){
            x=hatvany(n,p/2);
    if(p%2==0){

        return (x*x);
    }
    else{
            return ((x*x)*n) ;}}

    else return x;

}

int main()
{
    int m;
    long long n;
    be>>m;
    szita();
    for(int i=0;i<m;i++){
        be>>n;
        long long db=1,db1=1;
        long long k=n;
        int j=0;
            for(int i=2;i<=k/2;i++){ j=0;
                if(a[i]==true && n%i==0)
                {
                    while(n%i==0)
                    {
                        j++;
                        n=n/i;
                    }
                db=(db*(j+1))%MOD;
                db1=(db1*((hatvany(i,j+1)-1)/(i-1)))%MOD;
                x=1;
            }

            }
        if(db==1){db++;db1=n+1;}
        ki<<db<<" "<<db1<<'\n';
    }

    return 0;
}
