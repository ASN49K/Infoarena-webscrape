#include <bits/stdc++.h>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int n,i,cont,maj,nr,NR,v[1000010];

int main()
{
    f>>n;
    for(i=1;i<=n;i++)f>>v[i];

    maj=v[1];cont=1;
    for(i=2;i<=n;i++)
    {
        if(v[i]==maj)cont++;
        else
        {
            cont--;
            if(cont<0)
            {
                cont=1;
                maj=v[i];
            }
        }
    }

    for(i=1;i<=n;i++)
        if(v[i]==maj)NR++;

    if(NR>=n/2+1)
    {
        g<<maj<<" "<<NR;
    }
    else  g<<-1;
    return 0;
}
