#include <bits/stdc++.h>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int n, a[1000002], i, c, ori;

int main() {
    fin >> n >> a[1];
    c = a[1];
    ori = 1;
    for(i = 2; i <= n; i++) {
        fin >> a[i];
        if(a[i] == c) ori++;
        else          ori--;
        if(ori == 0) {
            c = a[i];
            ori = 1;
        }
    }
    ori = 0;
    for(i = 1; i <= n; i++) {
        if(a[i] == c) ori++;
    }
    if(ori > n / 2) fout << c << " " << ori;
    else fout << "-1";

    return 0;
}
