#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;


ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int main()
{
    int n, v[100001], s=0, maxi=0, cnt, x;
    fin>>n;
    for (int i=1; i<=n; i++)
    {
        fin>>v[i];
    }
    cnt=1; 
    x=v[1];
    for (int i=2; i<=n; i++)
    {
        if (v[i]==x)
        {
            cnt++;
        }
        else
        {
            cnt--;
            if (cnt==0)
            {
                x=v[i];
                cnt=1;
            }
        }
    }
    cnt=0;
    for (int i=1; i<=n; i++)
    {
        if (x==v[i])
        {
           cnt++; 
        }
    }
    if (cnt<=n/2)
    {
        fout<<-1;
    }
    else
    {
        fout<<x<<" "<<cnt;
    }

    return 0;
}