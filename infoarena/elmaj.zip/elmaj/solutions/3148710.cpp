#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

ifstream fin("data.in");
ofstream fout("data.out");

int n;
vector <int> a;

int main()
{
	int x, cand, vot;
	fin >> n;
	for (int i = 1; i <= n; i++)
		fin >> x, a.push_back(x);
	
	cand = a[0]; vot = 1;
	for (int i = 1; i < n; i++)
		if (cand == a[i])
			vot++;
		else if (vot == 0)
			cand = a[i];
		else 
			vot--;
	fout << cand;
	return 0;
}