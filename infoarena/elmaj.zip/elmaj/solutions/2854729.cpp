#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int main()
{
    int n, i, el_maj, s=0, ap=0;
    fin >> n;
    int v[n+1];
    for(i=1;i<=n;i++)
        fin >> v[i];
    el_maj=v[1];
    for(i=1;i<=n;i++)
    {
        if(s==0)
        {
            el_maj=v[i];
        }
        if(el_maj==v[i])
            s++;
        else
            s--;
    }
    for(i=1;i<=n;i++)
        if(v[i]==el_maj)
            ap++;
    if(ap<=n/2)
        fout << "-1";
    else
        fout << el_maj << " " << ap;
    return 0;
}
