#include <fstream>

using namespace std;

ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int v[1000000];
int main()
{
    int n, i, el, ap;
    cin>>n;
    for(i=0; i<n; i++)
        cin>>v[i];
    el=-1;
    ap=0;
    for(i=0; i<n; i++)
    {
        if(ap==0)
        {
            el=v[i];
            ap=1;
        }
        else
            if(v[i]==el)
        {
            ap++;
        }
        else{
            ap--;
        }
        }
        ap=0;
        for(i=0; i<n; i++)
            if(v[i]==el)
            ap++;
        if(ap<=n/2)
            {el=-1;
            cout<<el;
            }
            else
        cout<<el<<' '<<ap;

    return 0;
}
