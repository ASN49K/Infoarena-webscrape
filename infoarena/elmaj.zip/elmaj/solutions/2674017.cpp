#include<cstdio>
#include<queue>
#include<map>
using namespace std;
FILE*in=fopen("elmaj.in","r");
FILE*out=fopen("elmaj.out","w");
map<int,int> m;
int n,i,a,elm=0,ct=1;
int main()
{
    fscanf(in,"%d",&n);
    for(i=1;i<=n;i++)
    {
        fscanf(in,"%d",&a);
        m[a]++;
        if(a==elm)
        {
            ct++;
        }
        else
        {
            ct--;
            if(ct==0)
            {
                elm=a;
                ct=1;
            }
        }
    }
    if(m[elm]>=n/2+1)
    {
        fprintf(out,"%d %d",elm,m[elm]);
    }
    else
    {
        fprintf(out,"-1");
    }
}
