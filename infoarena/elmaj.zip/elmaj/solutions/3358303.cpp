#include <iostream>
#include <fstream>

using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[1000005];

int main()
{
    int n;
    f >> n;
    int cand = -1, nr = 0;
    for(int i = 1; i <= n; i++)
    {
        f >> v[i];
        if(nr == 0)
        {
            cand = v[i];
            nr = 1;
        }
        else
            if(v[i] == cand)
                nr++;
            else
                nr--;
    }
    nr = 0;
    for(int i = 1; i <= n; i++)
        if(v[i] == cand)
            nr++;
    if(nr >= n / 2 + 1)
        g << cand << " " << nr << "\n";
    else
        g << "-1\n";
    f.close();
    g.close();
    return 0;
}
