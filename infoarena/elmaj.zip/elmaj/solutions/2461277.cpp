# include <fstream>
# include <map>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int main()
{
	int n, x, ok = 0;
	int max = 0, maxv = 0, find = 0;
	map<int, int>dictionar;
	fin >> n;
	for (int i = 0; i < n; i++)
	{
		fin >> x;
		if (dictionar.count(x))
		{
			dictionar.find(x)->second++;
			if (dictionar.find(x)->second >= (n / 2) + 1)
			{
				find = 1;
				max = x;
				maxv = dictionar.find(x)->second;
			}
		}
		else
			dictionar.insert(pair<int, int >(x, 1));
	}
	if (find)
		fout << max << " " << maxv;
	else
		fout << "-1";

	return 0;
}