#include <iostream>
using namespace std;

const int NMAX = 1e6 + 10;

int v[NMAX];

int main()
{
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);
    int n;

    scanf("%d", &n);
    for(int i = 1; i <= n; i++){
        scanf("%d", &v[i]);
    }
    int element_curent = -1, aparitii_curente = 0;
    for(int i = 1; i <= n; i++){
        if(aparitii_curente == 0)
            element_curent = v[i];
        else if(v[i] == element_curent)
            aparitii_curente++;
        else
            aparitii_curente--;
    }

    aparitii_curente = 0;
    for(int i = 1; i <= n; i++){
        aparitii_curente += (element_curent == v[i]);
    }
    if(aparitii_curente >= (n / 2 + 1))
        printf("%d %d", element_curent, aparitii_curente);
    else
        printf("-1");
    return 0;
}
