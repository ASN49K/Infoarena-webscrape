#include <bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(), (a).end()
//#pragma GCC optimize("O3")
//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define sz() size()
#define fr first
#define sc second
#define pb push_back
#define er erase
#define in insert
#define pi pair<int,int>
#define pii pair<pair<int,int>,int>
#define mp make_pair
//#define int long long
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
using namespace std;

const int mod=1e9+7;
const int modx=998244353;
const int per=666013;

const int inf=1e9;

int n,a[1000005],maxi,ans;

int32_t main(){
	ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
    srand(chrono::steady_clock::now().time_since_epoch().count());
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
    cin >> n;
    for(int i=1;i<=n;i++) cin >> a[i];
    map<int,int>q;
    for(int i=1;i<=1000;i++){
        int indx=rand()%n+1;
        q[a[indx]]++;
        if(maxi<q[a[indx]]){
            maxi=q[a[indx]];
            ans=a[indx];
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++) if(a[i]==ans) cnt++;
    cout << ans << ' ' << cnt;
}
