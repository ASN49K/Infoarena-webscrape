#include <fstream>
#include <algorithm>
#define nmax 1000005
using namespace std;
int i,n,v[nmax],k,s;
int main()
{
ifstream f ("elmaj.in");
ofstream g ("elmaj.out");
    f>>n;
    for (i=1;i<=n;i++)
        f>>v[i];
    nth_element(v+1,v+n/2+1,v+n);
    k=v[n/2];
    for (i=1;i<=n;i++)
        if (v[i]==k) s++;
    if (s>=n/2+1) g<<k<<' '<<s;
    else g<<-1;
}
