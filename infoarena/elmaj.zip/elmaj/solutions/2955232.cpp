#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n , a[100001] , c , f;
    cin >> n >> a[1];
    c=a[1];
    f = 1;
    for(int i= 2 ; i <= n ; ++i)
    {
        cin >> a[i];
        if(a[i] == c) f++;
        else
        {
            f--;
            if(f == 0)
            {
                c = a[i];
                f = 1;
            }
        }
    }
    f = 0;for(int i = 1 ; i <= n ; ++i)
    if(a[i] == c) f++;
    if(f > n/2) {cout<<c<<" "<<f;}
    else cout << -1;
}
