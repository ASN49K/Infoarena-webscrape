/// Preset de infoarena
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, v[1000005], nr, ap;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> v[i];
    nth_element(v + 1, v + n / 2 + 1, v + n + 1);
    nr = v[n / 2 + 1];
    for(int i = 1; i <= n; i++)
        if(v[i] == nr)
            ap++;
    if(ap >= n / 2 + 1)
        fout << nr << ' ' << ap;
    else
        fout << -1;
    return 0;
}
