#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
int a[1000000];
int main()
{
    int n, cand, k=0;
    fin>>n;
    fin>>a[0];
    cand=a[0];
    k++;
    for(int i=1; i<n; i++)
    {
        fin>>a[i];
        if(k==0)
        {
            cand=a[i];
            k++;
        }
        else if(a[i]!=cand)
        k--;
        else
        k++;

    }
    k=0;
    for(int i=0; i<n; i++)
    {
        if(a[i]==cand)
            k++;
    }
    fout<<cand<<" "<<k;
    return 0;
}
