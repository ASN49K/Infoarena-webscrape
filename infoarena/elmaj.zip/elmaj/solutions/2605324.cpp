#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");

int n;
//int v[1000041];
int val;
int c=0, aux;
unordered_map<int, int>a;

int main()
{
    ///varianta2
    fin >> n;
    for (int i=0;i<n;i++)
    {
        fin >> val;
        a[val]++;
        if (a[val]>c)
        {
            c=a[val];
            aux=val;
        }
    }
    if (c>=n/2+1)
    {
        fout << aux << " " << c;
    }
    else
    {
        fout << "-1";
    }
    ///varianta1
 /*   int val=0, aux=1;
    val=v[0];
    for (int i=1;i<n;++i)
    {
        if (v[i]!=val&&aux!=0)
        {
            aux--;
        }
        else if (v[i]==val)
        {
            aux++;
        }
        else if (aux==0)
        {
            val=v[i];
            aux=1;
        }
    }
    int c=0;
    for (int i=0;i<n;++i)
    {
        if (v[i]==val)
            c++;
    }
    if (c>=n/2+1)
        fout << val << " " << c;
    else
        fout << "-1";*/
    return 0;
}
