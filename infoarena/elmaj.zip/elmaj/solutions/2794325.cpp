#include <bits/stdc++.h>
using namespace std;ifstream i("elmaj.in");ofstream o("elmaj.out");unordered_map<int,int> f;int main(){int n,m,k;i>>n;for(int i=0;i<n;i++){i>>k;if(++f[k]>f[m])m=k;}if(f[m]>=n/2+1)o<<m<<' '<<f[m];else o<<-1;}
