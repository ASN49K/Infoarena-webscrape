#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ifstream fin("elmaj.in");
ofstream fout("elmaj.out");
unordered_map <int, int> m;
int main()
{
        ios::sync_with_stdio(false);
        fin.tie();

        int n, x;
        fin >> n;
        while (n--)
        {
                fin >> x;
                m[x]++;
        }
        unordered_map<int, int> :: iterator it = m.begin();
        int el, ap;
        el = ap = 0;
        for (; it != m.end(); ++it)
                if ((int)(*it).second > n / 2 + 1 && ap < (int)(*it).second)
                        el = (int)(*it).first, ap = (int)(*it).second;
        if (ap != 0)
                fout << el << " " << ap;
        else fout << -1;
        return 0;
}

