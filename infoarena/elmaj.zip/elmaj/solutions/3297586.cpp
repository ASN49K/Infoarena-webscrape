#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e6;

int v[NMAX];

int main() {
    ifstream fin( "elmaj.in" );
    ofstream fout( "elmaj.out" );
    int n, a = -1, cnt = 0;
    fin >> n;
    for ( int i = 0; i < n; i ++ ) {
        fin >> v[i];
        if ( v[i] == a ) {
            cnt ++;
        } else if ( cnt == 0 ) {
            a = v[i];
            cnt = 1;
        } else {
            cnt --;
        }
    }

    cnt = 0;
    for ( int i = 0; i < n; i ++ ) {
        if ( v[i] == a ) cnt ++;
    }
    if ( cnt >= n / 2 + 1 ) {
        fout << a << ' ' << cnt << '\n';
    } else {
        fout << "-1\n";
    }
    return 0;
}