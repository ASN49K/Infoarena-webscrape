#include<fstream>
using namespace std;
ifstream F("elmaj.in");
ofstream G("elmaj.out");
int n,i,j,b,a[1000000],k;
int main()
{
    for(F>>n;i<n;F>>a[i],!k?b=a[i]:b==a[i]?++k:--k,++i);
    for(i=0;i<n;j+=(a[i++]==b));
    return j>n/2?G<<b<<' '<<j:G<<-1,0;
}
