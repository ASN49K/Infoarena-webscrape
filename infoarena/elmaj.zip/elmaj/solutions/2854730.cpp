#include <fstream>

using namespace std;
ifstream cin ("elmaj.in");
ofstream cout ("elmaj.out");
int main()
{
    int n,i,el_maj,s=0,ap=0;
    cin>>n;
    int v[n+1];
    for (i=1;i<=n;i++)
    {
        cin>>v[i];
    }
    el_maj=v[1];
    for (i=1;i<=n;i++)
    {
        if (el_maj==v[i])
        {
            s++;
        }
        else
        {
            s--;
        }
        if(s==0)
        {
            el_maj=v[i];
            s++;
        }
    }
    for (i=1;i<=n;i++)
    {
        if(v[i]==el_maj)
        {
            ap++;
        }
    }
    if (ap<=n/2)
        cout<<"-1";
    else
        cout<<el_maj<<" "<<ap;
    return 0;
}
