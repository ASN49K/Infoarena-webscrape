#include <bits/stdc++.h>

using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");
int n,i,x,Max=-1,nrap,f[1000005];
int main()
{
    in>>n;
    int nrmax=n/2;
    for(i=1; i<=n; ++i)
    {
        in>>x,f[x]++;
        if(f[x]>nrmax)
            nrmax=f[x],nrap=f[x],Max=x;
    }
    out<<Max<<" "<<nrap;
    return 0;
}
