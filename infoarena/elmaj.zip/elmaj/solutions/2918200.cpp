#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

std::ifstream fin("sortaret.in.txt");
std::ofstream fout("sortaret.out.txt");

int main() {
	int n{ 0 };
	vector<int> v_elements;

	fin >> n;

	for (int i = 0; i < n; i++)
	{
		int number;

		fin >> number;

		v_elements.push_back(number);
	}

	int candidate = -1;
	int ok = 0;

	for (int i = 0; i < n; i++)
	{
		if (ok == 0)
		{
			candidate = v_elements[i];
			ok = 1;
		}
		else if (v_elements[i] == candidate)
		{
			ok++;
		}
		else
		{
			ok--;
		}
	}

	if (candidate == -1)
	{
		return -1;
	}

	int nr_apperence{ 0 };

	for (int i = 0; i < n; i++)
	{
		if (v_elements[i] == candidate)
		{
			nr_apperence++;
		}
	}

	if (nr_apperence == (n / 2 + 1))
	{
		fout << candidate << " " << nr_apperence;
	}
	else
	{
		fout << -1;
	}

	return 0;
}