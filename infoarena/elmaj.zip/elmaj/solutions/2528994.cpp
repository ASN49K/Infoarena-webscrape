#include <fstream>

using namespace std;
ifstream in("elmaj.in");
ofstream out("elmaj.out");

int main()
{
    int n,k1,j,k;
    in>>n;
    in>>k1;
    int elem=k1;
    int ap=1;
    for(j=2; j<=n; j++)
    {
        in>>k;
        if(ap==0)
            elem=k,ap++;
        else
        {
            if(k==elem)
                ap++;
            if(k!=elem)
                ap--;
        }
    }
    if(ap==0)
    {
        out<<-1;
        return 0;
    }
    in.close();
    ifstream in1("elmaj.in");
    in1>>n;
    int nr,cnt=0;
    for(int i=1;i<=n;i++)
    {
        in1>>nr;
        if(nr==elem)
            cnt++;
    }
    if(cnt>n/2)
        out<<elem<<" "<<cnt ;
    else out<<-1;
    return 0;
}
