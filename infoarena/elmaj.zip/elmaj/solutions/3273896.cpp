#include <bits/stdc++.h>

using namespace std;


signed main()
{
    ifstream cin("elmaj.in");
    ofstream cout("elmaj.out");
	int n; cin >> n;
	vector<int> v(n), viz(n, 0);
	for (int i = 0; i < n; i ++)
        cin >> v[i];
    int ok = 0;
    for (int i = 0; i < n; i ++)
    {
        int cnt = 0;
        if (viz[i] == 0)
        {
            int x = v[i];
            for (int j = i; j < n; j ++)
            {
                if (v[j] == x)
                {
                    viz[j] = 1;
                    cnt ++;
                }
            }
        }
        if (cnt >= n / 2 + 1)
        {
            cout << v[i] << ' ' << cnt;
            ok = 1;
            break;
        }
    }
    if (ok == 0)
        cout << -1;
    return 0;
}
