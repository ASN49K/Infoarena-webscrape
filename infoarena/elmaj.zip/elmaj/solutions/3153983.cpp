#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream input("elmaj.in");
    ofstream output("elmaj.out");

    int n;
    input >> n;
    vector<int> v(n);

    for (int i = 0; i < n; i++) {
        input >> v[i];
    }

    int candidate = -1;
    int count = 0;

    //vot
    for (int i = 0; i < n; i++) {
        if (count == 0) {
            candidate = v[i];
            count = 1;
        } else if (candidate == v[i]) {
            count++;
        } else {
            count--;
        }
    }

  //v daca cand ii maj
    count = 0;
    for (int i = 0; i < n; i++) {
        if (v[i] == candidate) {
            count++;
        }
    }


    if (count >= n / 2 + 1) {
        output << candidate << " " << count << endl;
    } else {
        output << -1 << endl;
    }


    return 0;
}
