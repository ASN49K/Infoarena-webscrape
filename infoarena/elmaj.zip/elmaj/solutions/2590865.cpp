#include <fstream>
#include <iostream>
using namespace std;

ifstream f("elmaj.in");
ofstream g("elmaj.out");

int v[1000001], c, n, i, nr, ct;

int main()
{
    f >> n;
    for(i = 1; i <= n; ++ i)
    {
        f >> v[i];
        if(!c)
            nr = 1, c = v[i];
        else if(c == v[i])
            nr ++;
        else
            nr --;
    }
    for(i = 1; i <= n; ++ i)
        if(v[i] == c)
            ct ++;
    if(ct >= nr / 2 + 1)
        g << c << " " << ct << "\n";
    else
        g << "-1\n";

    f.close();
    g.close();
    return 0;
}
