#include <fstream>
#include <algorithm>
using namespace std;
ifstream f("livada.in");
ofstream g("livada.out");
long long m,l,cnt,y,maxi,lmax1,x,lmax,n,p,c,v[700001],i,j;
int main()
{
    f>>m>>n>>p;
    for(i=1;i<=m;i++)
    {
        v[n]={0};
        maxi=0;
        lmax=0;
        y=-1;
        for(j=1;j<=n;j++)
        {
            f>>x;
            v[j]=x;
                if(x==y)
                    l++;
                    else
                    l=1;
                if(lmax<l)
                    lmax=l;
                    y=x;
        }
        sort(v+1,v+1+n);
        for(j=1;j<=n;j++)
        {
            l=1;
            while(v[j]==v[j+1]&&j+1<=n)
            {
                l++;
                j++;
            }
            if(maxi<l)
                maxi=l;
        }
        if(lmax1<lmax)
            lmax1=lmax;
        if(maxi>=n/2+1)
            cnt++;
    }
    g<<cnt<<"\n"<<lmax1;
    return 0;
}
