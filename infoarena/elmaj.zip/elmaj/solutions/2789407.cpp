#include <fstream>
using namespace std;
ifstream f("elmaj.in"); ofstream g("elmaj.out");
int n,v[1000010];
int main()
{   f>>n;
    for(int i=1;i<=n;i++) f>>v[i];
    int cand=0,cnt=0;
    for(int i=1;i<=n;i++)
        if(cnt==0) {cand=v[i]; cnt=1;}
            else if(v[i]==cand) cnt++; else cnt--;
    int nr=0;
    for(int i=1;i<=n;i++)
        if(v[i]==cand) nr++;
    if(nr>n/2) g<<cand<<" "<<nr; else g<<-1;
    g.close(); f.close();
    return 0;
}
