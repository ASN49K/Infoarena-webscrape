#include <bits/stdc++.h>
using namespace std;
ifstream f("elmaj.in");
ofstream g("elmaj.out");
int c,nr,nr1,n,v[1000005];
int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>v[i];
        if(nr==0)
        {
            nr=1;
            c=v[i];
        }
        else if(c!=v[i])
            nr--;
        else
            nr++;
    }
    for(int i=1; i<=n; i++)
        if(v[i]==c)
            nr1++;
    if(nr1>=n/2+1)
        g<<c<<" "<<nr1;
    else
        g<<-1;
    return 0;
}

