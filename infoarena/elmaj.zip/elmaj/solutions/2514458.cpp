#include<bits/stdc++.h>
#define max_size 9223372036854775807
using namespace std;
ifstream fin("elmaj.in");ofstream fout("elmaj.out");
int main(){
int n;fin>>n;
int v[n];int long maj[200000000];int a,c=0;
for(a=0;a<n;a++){
    fin>>v[a];
    if(maj[v[a]]==max_size)maj[v[a]]=0;
    maj[v[a]]++;}
for(a=0;a<n;a++)if(maj[v[a]]>(n/2)){c++;break;}
if(c>0)cout<<v[a]<<' '<<maj[v[a]];else fout<<"-1";
return 0;
}
