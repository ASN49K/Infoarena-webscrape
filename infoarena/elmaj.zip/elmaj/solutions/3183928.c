#include <stdio.h>
#include <limits.h>
#define NMAX 1000010
int v[NMAX];

void read_vector(int n, int v[NMAX]) {
    for (int i = 1;i <= n;i++) {
        scanf("%d ", &v[i]);
    }
}


void print_vector(int n, int v[NMAX]) {
    for (int i = 1;i <= n;i++) {
        printf("%d ", v[i]);
    }
    printf("\n");
}

int find_majority(int n, int v[NMAX]) {
    int winner = v[1];
    int cnt = 1;
    for (int i = 2;i <= n;i++) {
        if (winner == v[i]) {
            cnt++;
        } else {
            cnt--;
            if (cnt <= 0) {
                winner = v[i];
                cnt = 1;
            }
        }
    }

    cnt = 0;
    for (int i = 1;i <= n;i++) {
        if (v[i] == winner) {
            cnt++;
        }
    }
    if (cnt >= n / 2 + 1) {
        return winner;
    } else {
        return -1;
    }
}

int main() {
    freopen("elmaj.in", "r", stdin);
    freopen("elmaj.out", "w", stdout);

    int n;
    scanf("%d", &n);

    read_vector(n,v);
    // print_vector(n,v);
    printf("%d\n", find_majority(n,v));
    return 0;
}


