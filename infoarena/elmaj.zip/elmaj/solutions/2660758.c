#include <stdio.h>
#include <stdlib.h>
int v[1000000];
int main()
{
    FILE *fin, *fout;
    fin = fopen("elmaj.in", "r");
    fout = fopen("elmaj.out", "w");
    int n;
    fscanf(fin, "%d", &n);
    int candidat, voturi;
    int i;
    for (i = 0; i < n; i ++){
        fscanf(fin, "%d", &v[i]);
    }

    candidat = -1;
    voturi = 0;
    for (i = 0; i < n; i ++){
        if (voturi == 0){
            voturi = 1;
            candidat = v[i];
        }else if (v[i] == candidat) voturi ++;
        else voturi --;
    }
    //printf("%d", candidat);

    int times = 0;
    for (i = 0; i < n; i ++){
        times += (v[i] == candidat);
    }
    if (times > n/2) fprintf(fout, "%d %d", candidat, times);
    else fprintf(fout, "-1");
    return 0;
}
