#include<fstream>
using namespace std;
ifstream cin("elmaj.in");
ofstream cout("elmaj.out");
int a[1000000];
int main()
{
    int c=0,j=0,k=0,n;
    cin>>n;
    for(int i=0;i<n;cin>>a[i],!k?k=1,c=a[i]:c==a[i]?++k:--k,++i);
    for(int i=0;i<n;j+=a[i++]==c);
    return j>n/2?cout<<c<<' '<<j:cout<<-1,0;
}
