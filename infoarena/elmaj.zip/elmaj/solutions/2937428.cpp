#include <fstream>
using namespace std;
ifstream fin ("elmaj.in");
ofstream fout ("elmaj.out");
int n,i,k,c,nr,v[1000005];
int main()
{
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>v[i];
    c=-1;
    k=0;
    for (i=1; i<=n; i++)
    {
        if (k==0)
        {
            c=v[i];
            k=1;
        }
        else
        {
            if (v[i]==c)
                k++;
            else
                k--;
        }
    }
    for (i=1; i<=n; i++)
    {
        if (v[i]==c)
            nr++;
    }
    if (nr>n/2)
        fout<<c<<" "<<nr;
    else
        fout<<"-1";
    return 0;
}
