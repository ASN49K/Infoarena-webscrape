#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
ifstream fin("elmaj.in"); ofstream fout("elmaj.out");


int n;
vector<int> a;
map<int, int> e;



int main(){
fin>>n;
a.resize(n+5);
for(int i=0; i<n; i++){
    fin>>a[i];
    e[a[i] ]++;
}

sort(a.begin(), a.end() );
a.erase(unique(a.begin(), a.end()), a.end() );

int el, o=0;

for(int i=0; i<a.size(); i++){
        int c=e[a[i] ];
    if(c>o ){el=a[i]; o=c;}
}

if(o>n/2){
fout<<el<<" "<<o;}
else{fout<<-1;}



return 0;
}
