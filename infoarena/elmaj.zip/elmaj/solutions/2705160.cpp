#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("elmaj.in");
ofstream fout("elmaj.out");

int n, k = 1;
int v[1000000];
bool f;

int main(){

    fin >> n;
    for(int i = 0; i < n; i++)
        fin >> v[i];
    sort(v, v + n);
    for(int i = 0; i < n - 1; i++){
        if(v[i] == v[i + 1])
            k++;
        else{
            if(k >= n / 2 + 1){
                fout << v[i] << " " << k;
                f = true;
                break;
            }
            k = 1;
        }
    }
    if(!f) fout << -1;
    return 0;

}
