#include <fstream>

using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");

const int NMAX=2*1e5+5;
int a[NMAX], sir[NMAX];

struct pd
{
    int ans, poz;
} dp[NMAX];

int cb(int st, int dr, int nr)
{
    int gasit=dr+1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(a[sir[mij]]>=nr)
        {
            gasit=mij;
            dr=mij-1;
        }
        else st=mij+1;
    }
    return gasit;
}

void prnt(int poz)
{
    if(poz==0) return;
    prnt(dp[poz].poz);
    cout<<a[poz]<<' ';
}

int main()
{
    int i, n, poz, lg=0;
    pd maxim= {0, 0};
    cin>>n;
    for(i=1; i<=n; i++) cin>>a[i];
    for(i=1; i<=n; i++)
    {
        poz=cb(1, lg, a[i]);
        if(poz>lg) lg=poz;
        sir[poz]=i;
        dp[i].ans=poz;
        dp[i].poz=sir[poz-1];
        if(dp[i].ans>maxim.ans)
        {
            maxim= {dp[i].ans, i};
        }
    }
    cout<<maxim.ans<<'\n';
    prnt(maxim.poz);
}
