#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin ("scmax.in");
ofstream cout ("scmax.out");
int v[100001];
int dp[100001];
int t[100001];
struct skibidi {
int val,poz;
}a[100001],aint[401001],max1;
bool cmp(skibidi x,skibidi y)
{
    return x.val>y.val;
}
void combine(int nod)
{
    if (aint[2*nod].val>aint[2*nod+1].val)
    {
        aint[nod]=aint[2*nod];
    }
    else
    {
        aint[nod]=aint[2*nod+1];
    }
}
void update(int nod,int st,int dr,int x,int y)
{
    if (st==dr)
    {
        aint[nod].val=y;
        aint[nod].poz=x;
    }
    else
    {
        int m=(st+dr)/2;
        if (x<=m)
        {
            update(2*nod,st,m,x,y);
        }
        else if (x>m)
        {
            update(2*nod+1,m+1,dr,x,y);
        }
        combine(nod);
    }
}
void query(int nod,int st,int dr,int x,int y)
{
    if (x<=st && dr<=y)
    {
        if (max1.val<aint[nod].val)
            max1=aint[nod];
    }
    else
    {
        int m=(st+dr)/2;
        if (x<=m)
        {
            query(2*nod,st,m,x,y);
        }
        if (y>m)
        {
            query(2*nod+1,m+1,dr,x,y);
        }
    }
}
int main()
{
    int n;
    cin>>n;
    for (int i=1;i<=n;i++)
    {
        cin>>v[i];
        a[i].val=v[i];
        a[i].poz=i;
    }
    sort(a+1,a+n+1,cmp);
    for (int i=1;i<=n;i++)
    {
        ///iau fiecare elem in ordine descrescatoare si il activez
        int poz=a[i].poz;
        if (poz==n)
        {
            dp[poz]=1;
            t[poz]=0;
            update(1,1,n,poz,dp[poz]);
        }
        else
        {
            max1.val=-1;
            query(1,1,n,poz+1,n);
            if (v[poz]==v[max1.poz])
            {
                dp[poz]=dp[poz]=max1.val;
                t[poz]=t[max1.poz];
            }
            else
            {
                dp[poz]=max1.val+1;
                t[poz]=max1.poz;
            }
            update(1,1,n,poz,dp[poz]);
        }

    }
    int ma=0,poz;
    for (int i=1;i<=n;i++)
    {
        if (ma<dp[i])
        {
            ma=dp[i];
            poz=i;
        }
    }
    cout<<ma<<'\n';
    while (poz!=0)
    {
        cout<<v[poz]<<" ";
        poz=t[poz];
    }
    return 0;
}
