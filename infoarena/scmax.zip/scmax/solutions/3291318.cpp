#include <fstream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");
int n, cnt;
int v[100005];
int inv[100005];
int last[100005];
pair<int, int> aib[100005];
map<int, int> mp;
vector<int> rez;

void update(int poz, int val, int ind)
{
    for(int i = poz; i<=cnt; i+=(i&-i))
    {
        if(val > aib[i].first)
        {
            aib[i].first = val;
            aib[i].second = ind;
        }
    }
}

pair<int, int> query(int poz)
{
    pair<int, int> ans = {0, 0};

    for(int i = poz; i>=1; i-=(i&-i))
    {
        if(aib[i].first > ans.first)
        {
            ans = aib[i];
        }
    }

    return ans;
}

int main()
{
    in>>n;
    for(int i = 1; i<=n; i++)
    {
        in>>v[i];

        mp[v[i]] = 1;
    }

    for(auto &it: mp)
    {
        cnt++;

        it.second = cnt;
        inv[cnt] = it.first;
    }

    for(int i = 1; i<=n; i++)
    {
        v[i] = mp[v[i]];

        //out<<v[i]<<" ";
    }

    for(int i = 1; i<=n; i++)
    {
        pair<int, int> best = query(v[i] - 1);
        best.first += 1;

        last[i] = best.second;

        update(v[i], best.first, i);
    }

    pair<int, int> best = query(cnt);
    out<<best.first<<'\n';

    int x = best.second;
    while(x != 0)
    {
        rez.push_back(inv[v[x]]);

        x = last[x];
    }

    reverse(rez.begin(), rez.end());
    for(auto it: rez)
    {
        out<<it<<" ";
    }

    return 0;
}
