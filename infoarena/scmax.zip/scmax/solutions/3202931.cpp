#include <bits/stdc++.h>
#define MAXN 100000

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, m = 0, arr[MAXN], best[MAXN], poz[MAXN];
void show(int i, int last) {
    if (i == 0)
        return;
    if (poz[i] == last - 1) {
        show(i - 1, last - 1);
        fout << arr[i] << ' ';
    } else
        show(i - 1, last);
}

int main() {
    fin >> n;
    for (int i = 0; i < n; i++)
        fin >> arr[i];

    for (int i = 1; i < n; i++) {
        int lo = 0, hi = m;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            if (arr[i] > best[mid])
                lo = mid + 1;
            else
                hi = mid - 1;
        }

        best[lo] = arr[i];
        m = max(m, lo);
        poz[i] = lo;
    }

//    for (int i = 0; i < m; i++)
//        cout << best[i] << ' ';
//    cout << '\n';
//    for (int i = 0; i < n; i++)
//        cout << poz[i] << ' ';

    fout << m << '\n';
    show(n, m + 1);
    return 0;
}
