#include <bits/stdc++.h>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int lmax[100001], v[100001], venit[100001];
int afis[100001];

int main()
{
    int n, max1 = 0;
    in >> n;
    for(int i = 1; i <= n; i++)
    {
        in >> v[i];
        lmax[i] = 1;
        for(int j = 1; j < i; j++)
            if(v[j] < v[i] && lmax[j] + 1 > lmax[i])
                lmax[i] = lmax[j] + 1;
        max1 = max(max1, lmax[i]);
    }
    out << max1 << '\n';
    int last = INT_MAX, cnt = 0;
    for(int i = n; i >= 1; i--)
        if(lmax[i] == max1 && v[i] < last)
        {
            afis[++cnt] = v[i];
            last = v[i];
            max1--;
        }
    for(int i = cnt; i >= 1; i--)
        out << afis[i] << " ";
    return 0;
}
