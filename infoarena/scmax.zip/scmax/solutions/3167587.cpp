#include <iostream>
#include <fstream>

using namespace std;
int n, sir[100005], sol[100005],ind[100005],maxim,k=1;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
void cautare(int x,int i) {
    int dr=k,st=1,mij=(dr+st)/2, poz=k+1;
    while (st<=dr) {
        mij=(dr+st)/2;
        if (sol[mij]>=x) {
            poz=mij;
            dr=mij-1;
        }
        else {
            st=mij+1;
        }
        sol[poz]=x;
        ind[i]=poz;
    }
}
int main()
{
    fin >> n;
    for (int i=1; i<=n; ++i) {
        fin >> sir[i];
    }
    //sol[0]=-1;
    for (int i=1; i<=n; ++i) {
        if (sir[i]>sol[k]) {
            ++k;
            sol[k]=sir[i];
            ind[i]=k;

        }
        else {
            cautare(sir[i],i);
        }
    }
    fout << k-1 << '\n';
    for (int i=2; i<=k; ++i) {
        fout << sol[i] << ' ';
    }
    return 0;
}
