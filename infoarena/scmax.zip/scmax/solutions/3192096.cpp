#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

void adaugare(vector <int> &aib, int val, int poz)
{
    int n = (int)aib.size() + 1;
    while (poz <= n)
    {
        aib[poz] = max(aib[poz], val);
        int p2 = (poz & (-poz));
        poz += p2;
    }
}

int interogare(vector <int> &aib, int poz)
{
    int lmax = 0;
    while (poz != 0)
    {
        lmax = max(lmax, aib[poz]);
        int p2 = (poz & (-poz));
        poz -= p2;
    }
    return lmax;
}

int main()
{
    ifstream in("scmax.in");
    ofstream out("scmax.out");
    int n;
    in >> n;
    vector <int> v_ini(n), v(n);
    vector < pair <int, int>> aux(n);
    for (int i = 0; i < n; i++)
    {
        in >> v_ini[i];
        aux[i].first = v_ini[i];
        aux[i].second = i;
    }
    sort(aux.begin(), aux.end());
    int val_c = 0;
    v[aux[0].second] = ++val_c;
    for (int i = 1; i < n; i++)
    {
        if (aux[i].first > aux[i-1].first)
        {
            val_c++;
        }
        v[aux[i].second] = val_c;
    }
    vector <int> aib(val_c + 1, 0);
    vector <int> lung(n);
    adaugare(aib, 1, v[0]);
    lung[0] = 1;
    int poz_lmax = 0;
    for (int i = 1; i < n; i++)
    {
        int lmax = interogare(aib, v[i] - 1);
        lung[i] = lmax + 1;
        adaugare(aib, lmax + 1, v[i]);
        if (lung[i] > lung[poz_lmax])
        {
            poz_lmax = i;
        }
    }
    out << lung[poz_lmax] << "\n";
    vector <int> subsir;
    subsir.push_back(poz_lmax);
    int ultimul_selectat = poz_lmax;
    for (int i = poz_lmax - 1; i >= 0; i--)
    {
        if (lung[i] == lung[ultimul_selectat] - 1 && v[i] < v[ultimul_selectat])
        {
            subsir.push_back(i);
            ultimul_selectat = i;
        }
    }
    reverse(subsir.begin(), subsir.end());
    for (auto poz: subsir)
    {
        out << v_ini[poz] << " ";
    }
    in.close();
    out.close();
    return 0;
}
