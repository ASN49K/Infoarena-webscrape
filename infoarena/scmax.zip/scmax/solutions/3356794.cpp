#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

const int INF = 2e9 + 1;

void normalizare(vector <int> &v, vector <int> &v_n) {
    int n = (int)v.size();
    vector <pair <int, int>> aux(n);
    for (int i = 0; i < n; i++) {
        aux[i].first = v[i];
        aux[i].second = i;
    }
    sort(aux.begin(), aux.end());
    int val = 1;
    v_n[aux[0].second] = val;
    for (int i = 1; i < n; i++) {
        if (aux[i].first > aux[i - 1].first) {
            val++;
        }
        v_n[aux[i].second] = val;
    }
}

void actualizare(vector <int> &aib, int p, int val) {
    int n = (int)aib.size() - 1;
    while (p <= n) {
        aib[p] = max(aib[p], val);
        int putere = (p & (-p));
        p += putere;
    }
}

int interogare(vector <int> &aib, int p) {
    int maxim = 0;
    while (p > 0) {
        maxim = max(maxim, aib[p]);
        int putere = (p & (-p));
        p -= putere;
    }
    return maxim;
}

void refac_subsirul(int p, int l, int reper, vector <int> &x, vector <int> &lung, ofstream &out) {
    if (l == 0) {
        return;
    }
    if (x[p] < reper && lung[p] == l) {
        refac_subsirul(p - 1, l - 1, x[p], x, lung, out);
        out << x[p] << " ";
    } else {
        refac_subsirul(p - 1, l, reper, x, lung, out);
    }
}

int main() {
    ifstream in("scmax.in");
    ofstream out("scmax.out");
    int n;
    in >> n;
    vector <int> v(n);
    for (int i = 0; i < n; i++) {
        in >> v[i];
    }
    in.close();
    vector <int> v_norm(n);
    normalizare(v, v_norm);
    vector <int> aib(n + 1, 0);
    vector <int> lung(n, 0);
    int p_max = 0;
    for (int i = 0; i < n; i++) {
        int j = interogare(aib, v_norm[i] - 1);
        lung[i] = j + 1;
        actualizare(aib, j + 1, lung[i]);
        if (lung[i] > lung[p_max]) {
            p_max = i;
        }
    }
    out << lung[p_max] << "\n";
    refac_subsirul(p_max, lung[p_max], INF, v, lung, out);
    out.close();
    return 0;
}