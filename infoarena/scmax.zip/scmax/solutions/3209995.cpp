#include <fstream>
#include <algorithm>

using namespace std ;

ifstream cin ("scmax.in") ;
ofstream cout ("scmax.out") ;

int n, v[100002], dp[100002] ;

int main()
{

    cin >> n ;

    for (int i = 1 ; i <= n ; i ++)
        cin >> v[i] ;

    int idx = 1 ;
    dp[idx] = v[1] ;

    for (int i = 2 ; i <= n ; i ++)
    {

        if (v[i] > dp[idx])
            dp[++idx] = v[i] ;

        else
            *upper_bound(dp + 1, dp + idx + 1, v[i]) = v[i] ;

    }

    cout << idx << '\n' ;

    for (int i = 1 ; i <= idx ; i ++)
        cout << dp[i] << ' ' ;
    cout << '\n' ;

    return 0 ;

}