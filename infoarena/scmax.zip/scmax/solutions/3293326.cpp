#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
pair<int,int>a[100001];
struct nod
{
    int best,val;
}aint[400001];
nod combine(nod a,nod b)
{
    if(a.best>b.best)
        return a;
    if(b.best>a.best)
        return b;
    if(a.val<b.val)
        return a;
    return b;
}
void update(int v,int st,int dr,int pos,int best,int val)
{
    if(st==dr)
        aint[v]={best,val};
    else
    {
        int mid=(st+dr)/2;
        if(pos<=mid)
            update(v*2,st,mid,pos,best,val);
        else update(v*2+1,mid+1,dr,pos,best,val);
        aint[v]=combine(aint[v*2],aint[v*2+1]);
    }
}
nod res;
void query(int v,int st,int dr,int qst,int qdr)
{
    if(qst<=st && qdr>=dr)
        res=combine(res,aint[v]);
    else
    {
        int mid=(st+dr)/2;
        if(qst<=mid)
            query(v*2,st,mid,qst,qdr);
        if(qdr>mid)
            query(v*2+1,mid+1,dr,qst,qdr);
    }
}
int main()
{
    int n,maxi=0;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a[i].first;
        a[i].second=i;
    }
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++)
    {
        res={0,0};
        query(1,1,n,1,a[i].second);
        if(res.val==a[i].first)
            res.best--;
        maxi=max(maxi,res.best+1);
        update(1,1,n,a[i].second,res.best+1,a[i].first);
    }
    fout<<maxi;
    return 0;
}
