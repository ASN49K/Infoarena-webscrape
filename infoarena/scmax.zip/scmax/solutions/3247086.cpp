#include <bits/stdc++.h>

using namespace std;
ifstream in("scmax.in");
ofstream out("scmax.out");
const int NMAX = 1e5;
int n, v[NMAX+1], lg[NMAX+1], parent[NMAX+1];
int main()
{
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>v[i];
        lg[i]=1;
    }
    int vmax=0, nr=0;
    for(int i=n-1; i>=1; i--)//subsir de lungime maxima care incepe pe pozitia i
    {
        vmax=0; nr=0;
        for(int j=i+1; j<=n; j++)
        {
            if(v[j]>v[i] && lg[j]>vmax)
            {
                vmax = lg[j];
                nr=j;
            }
        }
        lg[i]=vmax+1;
        parent[i]=nr;
    }
    int rez=0, start=0;
    for(int i=1; i<=n; i++)
    {
        if(lg[i]>rez)
        {
            rez=lg[i];
            start=i;//subsirul maxim incepe pe poz i
        }
    }
    out<<rez<<'\n';
    while(start!=0)
    {
        out<<v[start]<<" ";
        start=parent[start];
    }
}
