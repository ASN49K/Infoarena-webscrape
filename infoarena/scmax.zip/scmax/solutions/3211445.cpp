{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 #include <bits/stdc++.h>\
#include <fstream>\
using namespace std;\
ifstream f("scmax.in");\
ofstream g("scmax.out");\
int main()\
\{\
    int n,k,v[100001],l[100001],lmax,i,a[100001],t;\
    f>>n;\
    for(int i=0;i<n;++i)\{\
        f>>v[i];\
    \}\
    l[0]=1;\
    for(k=1;k<=n;++k)\{\
        l[k]=1;\
        for(int i=0;i<k;++i)\{\
            if(v[i]<v[k])\{\
                l[k]=max(l[k],l[i]+1);\
            \}\
        \}\
    \}\
    g<<*max_element(l,l+n)<<endl;\
    int poz=1;\
    lmax=*max_element(l+1,l+n+1);\
    for(i=n;i>=1;i--)\{\
        if(l[i]==lmax)\{\
           a[poz++]=v[i];\
            lmax--;\
        \}\
    \}\
\
    for(i=poz-1;i>=1;--i)\{\
       \
        \
        g<<a[i]<<' ';\
    \}\
    return 0;\
\}}