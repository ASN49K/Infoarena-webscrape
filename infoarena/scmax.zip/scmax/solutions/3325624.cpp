#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int aux[100001], pvector[100001];
int main() {
   int n;
   cin >> n;
   int a[n + 1];
   for(int i = 1; i <= n; i ++){
       cin >> a[i];
   }
   aux[1] = a[1];
   int cnt = 1;
   for(int i = 2; i <= n; i ++){
       if(aux[cnt] < a[i]){
          cnt ++;
          aux[cnt] = a[i];
          pvector[i] = cnt;
       }
       else{
         int poz = lower_bound(aux + 1, aux + cnt + 1, a[i]) - aux;
         aux[poz] = a[i];
         pvector[i] = poz;
       }
   }
   cout << cnt << '\n';
   int j = n;
   int fin[cnt + 1];
   for(int i = cnt; i >= 1; i --){
       while(pvector[j] != i){
          j --;
       }
       fin[i] = a[j];
   }
   for(int i = 1; i <= cnt; i ++)
       cout << fin[i] << ' ';
}
