#include <bits/stdc++.h> 
  
using namespace std; 
  
ifstream fin("scmax.in"); 
ofstream fout("scmax.out"); 

int n, x;
vector<int> v;
vector<int> temp;
vector<int> r;
vector<int> mark;
  
int main(){ 
// v[i] (i = 1 ...), ultimul element dintr-o subsecventa strict crescatoare de lungime i
// complexitate O(nlogn)
fin>>n;
for (int i = 1; i <= n; i++){
    fin>>x;
    temp.push_back(x);
    // caut binar
    int st = 0;
    int dr = v.size() - 1;
    int p = -1;
    while(st <= dr){
        int mij = (st + dr) >> 1; // fac cu operatii pe biti pentru eficienta
        if (v[mij] < x){
            st = mij + 1;
            p = mij;
        }
        else
            dr = mij - 1;
    }
    if (p + 1 < v.size()){
        v[p+1] = x;
        mark.push_back(p+1);
    }
    else{
        mark.push_back(v.size());
        v.push_back(x);
    }
}
fout << v.size() << endl;
int Max = v.size() - 1;
int val = v.back();
r.push_back(val);
for (int i = n - 1; i >= 0; i--){
    if (temp[i] < val && mark[i] == Max - 1){
        val = temp[i];
        Max--;
        r.push_back(val);
    }
}
for (int i = r.size() - 1; i >= 0; i--){
    fout << r[i] << " "; 
}
    return 0; 
}