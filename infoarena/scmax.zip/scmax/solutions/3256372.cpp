#include <bits/stdc++.h>

using namespace std;

int main() {

    ifstream fin ("scmax.in");
    ofstream fout ("scmax.out");

    int n;
    fin >> n;
    vector<int> v(n), sol;
    for(int i = 0; i < n; i++) {
        fin >> v[i];
    }
    for(int i = 0; i < n - 1; i++) {
       vector<int> sir;
        sir.push_back(v[i]);
        for(int j = i + 1; j < n; j++) {
            if(v[j] > sir[sir.size() - 1]) {
                sir.push_back(v[j]);
            }
        }
        if(sir.size() > sol.size())
            sol = sir;
    }
    fout << sol.size() << '\n';
    for(auto i : sol) {
        fout << i << ' ';
    }

    return 0;
}
