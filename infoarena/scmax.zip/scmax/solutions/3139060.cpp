#include <fstream>
#include <vector>
using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int main(){
    int n;
    f >> n;
    vector<int>nums;
    for (int i = 1; i <= n; ++i) {
        int x;
        f >> x;
        nums.push_back(x);
    }
    vector<int> ans;
    ans.push_back(nums[0]);
    for (int i = 1; i < n; i++) {
        if (nums[i] > ans.back())
            ans.push_back(nums[i]);
        else {
            int low = lower_bound(ans.begin(), ans.end(), nums[i]) - ans.begin();
            ans[low] = nums[i];
        }
    }
    g << ans.size() << '\n';
    for (auto i : ans)
        g << i << ' ';
    return 0;
}