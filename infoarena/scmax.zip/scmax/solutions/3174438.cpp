#include <fstream>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

int n;
int A[100001];
int D[100001];
int poz[100001];
int I[100001];

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> A[i];
    int nr = 1;
    D[nr] = A[1];
    poz[1] = 1;
    for (int i = 2; i <= n; i++)
        if (A[i] > D[nr]) {
            nr++;
            D[nr] = A[i];
            poz[i] = nr;
        } else if (A[i] < D[nr]) {
            int st = 1, dr = nr;
            int p = nr + 1;
            while (st <= dr) {
                int m = (st + dr) / 2;
                if (D[m] > A[i]) {
                    p = m;
                    dr = m - 1;
                } else
                    st = m + 1;
            }
            D[p] = A[i];
            poz[i] = p;
        }
    int j = n;
    cout << nr << "\n";
    for (int i = nr; i >= 1; i--) {
        while (poz[j] != i)
            j--;
        I[i] = j;
    }
    for (int i = 1; i <= nr; i++)
        cout << A[I[i]] << " ";
    return 0;
}