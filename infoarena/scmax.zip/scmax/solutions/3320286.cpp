#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n,sol,dp[100002],lungime[100002], v[100002],lung=0, solutie[100002];

void place(int x, int i)
{
    if(lung==0)
    {
        lung=1;
        dp[lung]=1;
        lungime[1]++;
        sol=1;
        return;
    }

    int st=1;
    int dr=lung;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(x>v[dp[mij]])dr=mij-1;
        else st=mij+1;

    }
    if(st>lung)lung++;
    lungime[i]=lungime[dp[st]]+1;

    dp[st]=i;


    if(lungime[i]>sol)sol=lungime[i];
}
int x;
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>v[i];
        place(v[i], i);
    }
    fout<<sol<<'\n';
    int k=0;
    for(int i=n; i>=1; i--)
    {
        if(sol-k==lungime[i])
        {
            solutie[sol-k]=v[i];
            k++;
        }
        if(sol-k==0)break;
    }


    for(int i=1;i<=sol;i++)
    fout<<solutie[i]<<' ';
    return 0;
}
