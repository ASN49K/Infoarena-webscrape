#include <iostream>
#include <fstream>
#include <unordered_map>
#include <algorithm>
#include <vector>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX=1e5+5;
unordered_map<int, int> um;
int n, i;
pair<int, int> aib[NMAX];
int v[NMAX], a[NMAX];
vector<int> sol, b;

void update(int p, int x){
    for(int i=p;i<=n;i+=(i&-i)){
        if(x==aib[i].first)
            aib[i].second=min(aib[i].second, p);
        if(x>aib[i].first){
            aib[i].first=x;
            aib[i].second=p;
        }
    }
}

pair<int, int> query(int p){
    int ans=0;
    int poz=0;
    for(int i=p;i>0;i-=(i&-i)){
        if(ans<=aib[i].first){
            ans=aib[i].first;
            poz=aib[i].second;
        }
    }

    return {ans, poz};
}

int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>v[i];
        a[i]=v[i];
    }

    sort(a+1,  a+n+1);

    int cnt=0;
    for(i=1;i<=n;i++){
        if(a[i]!=a[i-1])
            um[a[i]]=++cnt;
    }

    for(i=1;i<=n;i++){
        if(a[i]!=a[i-1])
            b.push_back(a[i]);
    }

    for(i=1;i<=n;i++){
        int poz=um[v[i]];
        //cout<<poz<<'\n';
        pair<int, int> ans=query(poz-1);
        update(poz, ans.first+1);
    }


    int poz=n+1;
    while(poz!=0){
        pair<int, int> ans=query(poz-1);
        poz=ans.second;
        if(poz!=0){
//            cout<<poz<<' '<<b[poz-1]<<'\n';
            sol.push_back(b[poz-1]);
        }
    }

    fout<<sol.size()<<'\n';
    for(i=sol.size()-1;i>=0;i--)
        fout<<sol[i]<<" ";


    return 0;
}
