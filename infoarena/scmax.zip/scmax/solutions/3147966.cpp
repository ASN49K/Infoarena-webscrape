#include<iostream>
#include<vector>
#include<stdio.h>
#include<algorithm>
#include<queue>
using namespace std;

const int NMAX = 1005;
int n, prev_pos[NMAX], v[NMAX];
vector<int> dp, ans;

int binarysearch(int target)
{
    int pos = -1, st = 0, dr = dp.size() - 1;

    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(v[dp[mij]] < target)
            st = mij + 1;
        else if(v[dp[mij]] > target)
        {
            dr = mij - 1;
            pos = mij;
        }
        else
            return mij;
    }
    return pos;
}

int main()
{
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    cin >> n;
    for(int i = 0; i < n; i++)
        cin >> v[i];
    
    dp.push_back(0);
    
    for(int i = 0; i < n; i++)
        prev_pos[i] = -1;

    for(int i = 1; i < n; i++)
    {
        if(v[i] > v[dp.back()])
        {
            prev_pos[i] = dp.back();
            dp.push_back(i);
        }
        else
        {
            int val = binarysearch(v[i]);
            //cout << val << " ";
            dp[val] = i;
            if(val != 0)
                prev_pos[i] = dp[val - 1];
        }
    }
    cout << dp.size() << "\n";
    int pos = dp.back();
    while(pos != - 1)
    {
        ans.push_back(pos);
        pos = prev_pos[pos];
    }
    for(int i = ans.size() - 1; i >= 0; i--)
        cout << v[ans[i]] << " ";
}
