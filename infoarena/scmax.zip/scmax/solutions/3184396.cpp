#include <iostream>
#include <algorithm>

using namespace std;

pair < int , int >arb_max[400005];
int v[100005], last[100005], coduri[100005], v_init[100005];
int poz, poz2, val, start, fin, maxi, n, poz_max;

int maxim(int a, int b){
    if(a > b)
        return a;
    return b;
}

void update(int nod, int st, int dr){
    if(st == dr){
        arb_max[nod].first = val;
        arb_max[nod].second = poz2;
        return;
    }
    int mij= (st + dr)/2;
    if(poz <= mij){
        update(2 * nod, st, mij);
    }
    else{
        update(2 * nod + 1, mij + 1, dr);
    }

    arb_max[nod].first = maxim(arb_max[2*nod].first, arb_max[2*nod+1].first);
    if(arb_max[2*nod].first > arb_max[2*nod+1].first){
        arb_max[nod].second = arb_max[2*nod].second;
    }
    else{
        arb_max[nod].second = arb_max[2*nod + 1].second;
    }
}

void Query(int nod, int st, int dr){
    if(start > fin){
        return;
    }
    if(start <= st && dr <= fin){
        if(maxi < arb_max[nod].first){
            maxi = arb_max[nod].first;
            poz_max = arb_max[nod].second;
        }

        return;
    }

    int mij = (st + dr) / 2;
    if(mij >= start){
        Query(2 * nod, st, mij);
    }
    if(mij < fin){
        Query(2 * nod+ 1, mij + 1, dr);
    }
}

struct Element{
    int poz_s, val_s;
};

Element e[100005];

void afis(int x){
    if(x == 0){
        return;
    }
    afis(last[x]);
    cout<<v_init[x]<<' ';
}

bool cmp(Element a, Element b){
    return(a.val_s < b.val_s);
}

int main()
{
    freopen("scmax.in", "r", stdin);
    //freopen("scmax.out", "w", stdout);
    int i;
    Element x;
    cin>>n;


    for(i = 1; i<=n; i++){
        scanf("%d", &x.val_s);
        x.poz_s = i;
        e[i] = x;
        v_init[i] = x.val_s;
    }
    sort(e + 1, e + n + 1, cmp);

//    24 12 15 15 19
//    1  2  3  4  5
//
//    12 15 15 19 24
//    2  3  4  5  1

    int k = 1;
    v[e[1].poz_s] = k;
    coduri[k] = e[1].val_s;
    for(i = 2; i <= n; i++){
        if(e[i].val_s != e[i - 1].val_s)
            v[e[i].poz_s] = ++k;

        else
            v[e[i].poz_s] = k;
        coduri[k] = e[i].val_s;
    }

    for(i = 1; i<=n; i++){

        start = 1;
        fin = v[i] - 1;
        maxi = 0;
        poz_max = 0;
        Query(1, 1, n);
        last[i] = poz_max;

        val = maxi + 1;
        poz = v[i];
        poz2 = i;
        update(1, 1, n);
    }
    cout<<arb_max[1].first<<endl;
    afis(arb_max[1].second);

    return 0;
}
