#include <fstream>

using namespace std;
ifstream fcin("scmax.in");
ofstream fout("scmax.out");
int n,v[100001],u[100001],vf,st[100001],next1[100001],vf1,poz;
int cb(int val)
{
    int st=0;
    int dr=vf;
    int mij;
    while(st<=dr)
    {
         mij=(st+dr)/2;
        if(v[u[mij+1]]>=val && v[u[mij]]<val)
        {
            return mij;
        }
        else
        {
            if(val>v[u[mij]])
            {
                st=mij+1;
            }
            else
            {
                dr=mij-1;
            }
        }
    }
    return vf;
}
int main()
{
    fcin>>n;
    for(int i=1; i<=n; i++)
        fcin>>v[i];
    vf++;
    u[vf]=1;
   // fout<<u[cb(25)]<<'\n';
    for(int i=2; i<=n; i++)
    {
          int j=cb(v[i]);
     //   fout<<j<<'\n';
          next1[i]=u[j];
          u[j+1]=i;
          if(j+1>vf)
          {
              poz=u[j+1];
              vf=j+1;
          }
       // for(int j=1; j<=vf; j++)
      //  fout<<u[j]<<" ";
      //  fout<<'\n';
    }
   // fout<<poz<<" ";
  //  for(int i=1; i<=n; i++)
   //     fout<<next[i]<<" ";
   fout<<vf<<'\n';
    while(vf--)
    {
        vf1++;
        st[vf1]=v[poz];
        poz=next1[poz];
    }
    if(vf1==1)
    {
        fout<<v[1];
    }
    else
    for(int i=vf1; i>=1; i--)
    {
        fout<<st[i]<<" ";
    }
}
