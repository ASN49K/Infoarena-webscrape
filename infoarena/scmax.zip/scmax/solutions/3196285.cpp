#include <fstream>
#include <map>
#include <vector>
#include <unordered_map>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");
int n;
int v[100005];
int w[100005];
map<int, vector<int>> m;
unordered_map<int, int> um;
pair<int, int> segtree[400005];
int ans[100005];
vector<int> rez;

void update(int node, int left, int right, int poz, int val)
{
    if(left == right)
    {
        segtree[node].first = val + 1;
        segtree[node].second = poz;
    }
    else
    {
        int mij = (left + right) / 2;

        if(poz <= mij)
        {
            update(2 * node, left, mij, poz, val);
        }
        else
        {
            update(2 * node + 1, mij+1, right, poz, val);
        }

        //segtree[node] = max(segtree[2*node], segtree[2 * node + 1]);
        if(segtree[2*node].first >= segtree[2*node+1].first)
        {
            segtree[node].first = segtree[2*node].first;
            segtree[node].second = segtree[2*node].second;
        }
        else
        {
            segtree[node].first = segtree[2*node+1].first;
            segtree[node].second = segtree[2*node+1].second;
        }
    }
}

pair<int, int> query(int node, int left, int right, int qleft, int qright)
{
    if(qleft <= left && right <= qright)
    {
        return segtree[node];
    }
    else
    {
        int mij = (left + right) / 2;

        if(qright <= mij)
        {
            return query(2*node, left, mij, qleft, qright);
        }
        else if(mij+1 <= qleft)
        {
            return query(2*node+1, mij+1, right, qleft, qright);
        }

        //return max(query(2*node, left, mij, qleft, qright), query(2*node+1, mij+1, right, qleft, qright));
        if(query(2*node, left, mij, qleft, qright) > query(2*node+1, mij+1, right, qleft, qright))
        {
            return query(2*node, left, mij, qleft, qright);
        }
        else
        {
            return query(2*node+1, mij+1, right, qleft, qright);
        }
    }
}

int main()
{
    in>>n;

    for(int i = 1; i<=n; i++)
    {
        in>>v[i];
        w[i] = v[i];

        m[v[i]].push_back(i);
    }

    int nr = 0;
    for(auto i: m)
    {
        nr++;

        for(auto j: i.second)
        {
            v[j] = nr;
            um[nr] = w[j];
        }
    }


    /*for(int i = 1; i<=n; i++)
    {
        out<<v[i]<<" ";
    }
    out<<'\n';*/

    pair<int, int> el;
    for(int i = 1; i<=n; i++)
    {
        if(v[i] == 1)
        {
            el.first = 0;
            el.second = 0;
        }
        else
        {
            el = query(1, 1, n, 1, v[i] - 1);
        }

        ans[v[i]] = el.second;


        update(1, 1, n, v[i], el.first);
    }

    el = query(1, 1, n, 1, nr);
    out<<el.first<<'\n';

    int x = el.second;
    while(x != 0)
    {
        //out<<um[x]<<" ";
        rez.push_back(um[x]);
        x = ans[x];
    }

    for(int i = rez.size() - 1; i>=0; i--)
    {
        out<<rez[i]<<" ";
    }

    return 0;
}
