#include <fstream>
#include <iostream>
using namespace std;
ifstream in ("scmax.in");
ofstream out ("scmax.out");
int x[100001],v_min[100001],lung[100001];
int binar(int v[],int n, int x)
{
    int st=1,dr=n,rez=st-1;
    while(st<=dr)
    {
        int m=(st+dr)/2;
        if(v[m]<x)
        {
            rez=m;
            st=m+1;
        }
        else
        {
            dr=m-1;
        }
    }
    return rez;
    
}
int main()
{
    int n;
    in>>n;
    int i_max=0;
    int val_n_max=0;
    int val_p=0;
    for(int i=1;i<=n;i++)
    {
        in>>x[i];
        int j=binar(v_min,val_p,x[i]);
        v_min[j+1]=x[i];
        
        if(j+1>val_p)
        {
            val_p++;
        }
        lung[i]=1+j;
        if(lung[i]>lung [i_max])
        {
            i_max=i;
        }
    }
    out<<lung[i_max]<<"\n";
    for(int i=1;i<=lung[i_max];i++)
    {
        if(i==lung[i_max])
        {
            out<<v_min[i]<<" ";
        }
        if(v_min[i]<v_min[i+1])
        {
        out<<v_min[i]<<" ";
        }
    }
}