#include <fstream>
#define DIM 100010
using namespace std;
int v[DIM], t[DIM];
int d[DIM];
int n, i, j, maxim, sol, p, u, k;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");
void drum(int u){
     if (u!=0) {
     drum(t[u]);
     fout<<v[u]<<" ";
}
}
int main(){
fin>>n;
for(i=1;i<=n;i++)
    fin>>v[i];
d[1] = 1;
for(i=2;i<=n;i++){
    maxim = 0;
    for(j=1;j<i;j++)
        if(v[j] < v[i] && d[j] > maxim){
           maxim = d[j];
           p = j;
}
    d[i] = maxim + 1;
    if(d[i] != 1)
       t[i] = p;
    if(d[i] > sol) {
       sol = d[i];
       u = i;
}
}

fout<<sol<<"\n";
drum(u);
return 0;
}
