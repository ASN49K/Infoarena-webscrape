#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int dp[100005], top;

void Add(int x)
{
    if (x > dp[top])
    {
        dp[++top] = x;
        //return;
    }
    int st, dr, mij, P;
    st = 1; P = dr = top;
    while (st < dr)
    {
        mij = (st + dr) / 2;
        if (dp[mij] >= x)
        {
            P = mij;
            dr = mij - 1;
        }
        else st = mij + 1;
    }
    dp[P] = x;
}

int main()
{
    int i, x;
    fin >> n;
    for (i = 1; i <= n; i++)
    {
        fin >> x;
        Add(x);
    }
    fout << top << "\n";
    for (i = 1; i <= top; i++)
        fout << dp[i] << " ";
    return 0;
}
