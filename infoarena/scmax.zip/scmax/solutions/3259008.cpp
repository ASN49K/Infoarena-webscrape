#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

void scmax_from_file() {
    // Open input file
    ifstream infile("scmax.in");
    int n;
    infile >> n;

    vector<int> subsir(n);
    for (int i = 0; i < n; ++i) {
        infile >> subsir[i];
    }
    infile.close();

    // Initialize the list of tuples (length, predecessor)
    vector<pair<int, int>> maximum_lengths(n, {1, 0});
    for (int i = 0; i < n; ++i) {
        maximum_lengths[i].second = i; // Set self as predecessor
        for (int j = i - 1; j >= 0; --j) {
            if (subsir[j] < subsir[i] && maximum_lengths[j].first + 1 > maximum_lengths[i].first) {
                maximum_lengths[i] = {maximum_lengths[j].first + 1, j};
            }
        }
    }

    // Find the position of the maximum sequence
    int max_length = 0, max_pos = 0;
    for (int i = 0; i < n; ++i) {
        if (maximum_lengths[i].first > max_length) {
            max_length = maximum_lengths[i].first;
            max_pos = i;
        }
    }

    // Reconstruct the sequence
    vector<int> sequence;
    int current_pos = max_pos;
    while (true) {
        sequence.push_back(subsir[current_pos]);
        if (maximum_lengths[current_pos].second == current_pos) {
            break;
        }
        current_pos = maximum_lengths[current_pos].second;
    }
    reverse(sequence.begin(), sequence.end());

    // Write the output to "scmax.out"
    ofstream outfile("scmax.out");
    outfile << max_length << "\n";
    for (size_t i = 0; i < sequence.size(); ++i) {
        if (i > 0) outfile << " ";
        outfile << sequence[i];
    }
    outfile << "\n";
    outfile.close();
}

int main() {
    scmax_from_file();
    return 0;
}
