#include <bits/stdc++.h>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main() {
  int n, k = 0;
  fin >> n;
  vector<int> cd(n + 1, 0), ans;
  for (int i = 0; i < n; i++) {
    int x;
    fin >> x;
    if (cd[k] < x)
      cd[++k] = x;
    else {
      int left = 1, right = k;
      while (left <= right) {
        int mid = (left + right) / 2;
        if (cd[mid] < x)
          left = mid + 1;
        else
          right = mid - 1;
      }
      k = left;
      cd[k] = x;
    }
    if (k > ans.size())
      ans.assign(cd.begin(), cd.begin() + k + 1);
  }
  fout << ans.size() - 1 << "\n";
  for (int i = 1; i < ans.size(); i++)
    fout << ans[i] << " ";
  return 0;
}
