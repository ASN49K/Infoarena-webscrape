#include <iostream>
#include <fstream>
#define NMAX 100005

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int n, st, dr, mij;
int A[NMAX], D[NMAX], P[NMAX], I[NMAX];
int i, j, k, p;

int main()
{
	f >> n;
	for (i = 1; i <= n; i++)
		f >> A[i];
	k = 1;
	D[1] = A[1];
	P[1] = 1;
	for (i = 2; i <= n; i++)
		if (A[i] > D[k])
			D[++k] = A[i], P[i] = k;
		else
		{
			st = 1; dr = k; p = k+1;
			while (st <= dr)
			{
				mij = (st+dr)/2;
				if (D[mij] > A[i])	p = mij, dr = mij-1;
				else
				/**if (D[mij] < A[i])*/	st = mij+1;
			}
			D[p] = A[i];
			P[i] = p;
		}
	j = n;
	for (i = k; i >= 1; i--)
	{
		while (P[j] != i) --j;
		I[i] = j;
	}
	g << k << '\n';
	for (i = 1; i <= k; i++)
		g << A[I[i]] << ' ';
	/// O(nlogn)
	f.close();
	g.close();
	return 0;
}
