#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main()
{
    long long int v[100001], a[100001], l[100001];
    int n, k;
    
    fin>>n;
    for(int i=1;i<=n;++i){
        fin>>v[i];
    }
    
    for(k=1;k<=n;++k){
        l[k]=1;
        for(int i=1;i<k;++i){
            if(v[i]<v[k]){
                l[k]=max(l[i]+1,l[k]);
            }
        }
    }
    
    int maxi = *max_element(l+1,l+n+1);
    fout << maxi<< endl;
    int i=n;
    for(i=n;i>0;--i){
        if(l[i]==maxi){
            fout<<v[i]<<" ";
            maxi--;
        }
    }
    
    return 0;
}