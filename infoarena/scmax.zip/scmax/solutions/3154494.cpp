#include <bits/stdc++.h>

using namespace std;

int n;
int dp[100002];
int v[100002], len[100002];

ifstream in ("scmax.in");
ofstream out ("scmax.out");

int main()
{
    in >> n;
    for(int i = 1; i <= n; i ++){
        in >> v[i];
    }

    int dpPos = 1;
    len[1] = 1;
    dp[1] = v[1];

    for(int i = 2; i <= n; i ++){
            int l = 1,r = dpPos;
            while(l <= r){
                int mij = (l + r) / 2;
                if(v[i] > dp[mij]){
                    l = mij + 1;
                }
                else{
                    r = mij - 1;
                }
            }
            if(l == dpPos + 1)
                dpPos ++;
            dp[l] = v[i];
            len[i] = l;
    }

    out << dpPos << endl;

    vector<int> sol;

    int prev = 2000000001;

    for(int i = n; i >= 1; i --){
        if(len[i] == dpPos && v[i] < prev){
            sol.push_back(v[i]);
            prev = v[i];
            dpPos --;
        }
    }
    reverse(sol.begin(), sol.end());
    for(int i : sol){
        out << i << " ";
    }

    return 0;
}
