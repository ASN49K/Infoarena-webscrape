#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

int v[NMAX], prev[NMAX + 5];

pair<int, int> scv[NMAX];

int main() {
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    ios::sync_with_stdio(false), cin.tie(0);

    int n, maxx = 0;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
    }

    int p = 1;
    scv[p++] = {v[1], 1};

    for (int i = 2; i <= n; i++) {
        maxx = 0;
        for (int j = 1; j <= p; j++) {
            if (v[i] > scv[j].first) {
                maxx = max(maxx, scv[j].second);
            }
        }
        if (maxx > 0) {
            for (int j = 1; j <= p; j++) {
                if (v[i] > scv[j].first && maxx == scv[j].second) scv[j] = {v[i], maxx + 1};
            }
        }
        else scv[p++] = {v[i], 1};

    }

    maxx = 0;
    for (int i = 1; i <= p; i++) maxx = max(maxx, scv[i].second);
    cout << maxx << '\n';
    return 0;
}
