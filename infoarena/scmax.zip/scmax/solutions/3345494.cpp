#include <fstream>
#include <vector>
#include <climits>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main() {
    int n;

    fin >> n;

    vector<int> v(n + 1);
    vector<int> dp(n + 1);

    for(int i = 1; i <= n; i++)
        fin >> v[i];

    dp[1] = 1;

    for(int i = 2; i <= n; i++) {
        dp[i] = 1;
        for(int j = 1; j < i; j++) {

            if(v[i] > v[j]) {

                if(dp[j] + 1 > dp[i]){
                    dp[i] = dp[j] + 1;
                }

            }
        }
    }

    int sol = dp[1], pos = 1;
	for (int i = 2; i <= n; ++i) {
		if (dp[i] > sol) {
			sol = dp[i];
			pos = i;
		}
	}
 
	return sol;
}