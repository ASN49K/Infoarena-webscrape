#include <bits/stdc++.h>
using namespace std;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");
int n,x;
vector<int> v;
void scmax(){
    int maxi_a=INT_MIN,maxi_f=INT_MIN,last_pozitie=-1,a,b,last_poz_a=-1;
    for(int i=0;i<n;i++){
        a=v[i];
        for(int j=i+1;j<n;j++){
            b=v[j];

            if(a<b){
                if(maxi_f==0)
                    maxi_f=2;
                else
                    maxi_f++;
                a=v[j];
                last_pozitie=j;
            }

        }
        if(maxi_a<maxi_f){
            maxi_a=maxi_f;
            last_poz_a=last_pozitie;
        }
        maxi_f=0;
    }
    fout<<maxi_a;
}
int best_ss,last_poz_a;
int main() {
    fin>>n;
    for(int i=0;i<n;i++){
        fin>>x;
        v.push_back(x);
    }
    scmax();

    return 0;
}
