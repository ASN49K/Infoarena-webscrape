#include <bits/stdc++.h>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

int main() {
    int n; fin >> n;
    int a[n + 1];
    for (int i = 1; i <= n; i++) {
        fin >> a[i];
    }
    vector<int>v;
    for (int i = 1; i <= n; i++) {
        int l = 0, r = (int)v.size() - 1, where = -1;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (v[mid] >= a[i]) {
                where = mid;
                r = mid - 1;
            } else {
                l = mid + 1;
            }
        }
        if (i == 1 || v.back() < a[i]) {
            v.push_back(a[i]);
        } else {
            v[where] = a[i];
        }
    }
    fout << (int)v.size() << '\n';
    for (int x : v) {
        fout << x << " ";
    }
}
