//https://www.infoarena.ro/problema/scmax
#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100010],d[100010],ret[100010];//100010
int main()
{
    int n,i,j;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    d[0]=0;
    d[1]=1;
    int max=0;;
    for(i=2;i<=n;i++)
    {
        for(j=1;j<i;j++)
        {
            if(v[j]<v[i])
            {
                ret[i]=j;
            }
        }
        d[i]=d[ret[i]]+1;
        if(d[i]>max)
        {
            max=d[i];
        }
    }
    fout<<max;

    return 0;
}
