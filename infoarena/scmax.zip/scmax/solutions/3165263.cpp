#include<bits/stdc++.h>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");
///LIS cu AINT
const int NMAX = 100005;
pair<int,int>v[NMAX];
int segTree[4 * NMAX], sol[NMAX];
pair <int,int> cp[NMAX];

bool cmp(pair<int,int> a, pair<int,int> b) {
    if(a.first == b.first)
        return a.second > b.second;
    return a.first < b.first;
}

void query(int nod, int st, int dr, int a, int b, int &maxim) {
    if(st >= a && dr <= b) {
        maxim = max(maxim, segTree[nod]);
        return;
    }

    int mid = (st + dr) / 2;
    if(a <= mid)
        query(2*nod, st, mid, a, b, maxim);

    if(b >= mid + 1)
        query(2*nod+1, mid + 1, dr, a, b, maxim);
}

void update(int nod, int st, int dr, int pos, int val) {
    if(st == dr) {
        segTree[nod] = val;
        return;
    }

    int m = (st + dr) / 2;
    if(pos <= m)
        update(2*nod, st,m, pos, val);

    else
        update(2*nod+1,m+1, dr, pos, val);
    segTree[nod] = max(segTree[2 * nod], segTree[2 * nod + 1]);
}

int main() {
    int n;
    in >> n;
    for(int i = 1; i <= n; i++) {
        in >> v[i].first;
        cp[i].first = v[i].first;
        v[i].second = i;
    }

    sort(v+1,v+n+1,cmp);

    int Max=0, pos, maxim;
    for(int i = 1; i <= n; i++) {
        maxim=0;
        // det maxim in intervalul v[i].second(pozitie)
        query(1,1,n,1,v[i].second,maxim);
        update(1,1,n,v[i].second,maxim+1);
        cp[v[i].second].second=maxim+1;
        if(Max <= maxim + 1) {
            Max = maxim + 1;
            pos=v[i].second;
        }
    }

    out << segTree[1] << '\n';
    int k = 1;
    sol[k++] = cp[pos].first;

    int l_precedent = cp[pos].second;
    int pos_precedent = pos;

    int i = pos-1;
    while(i >= 1) {
        if(l_precedent == cp[i].second + 1 && cp[pos_precedent].first > cp[i].first) {
            sol[k++] = cp[i].first;
            l_precedent = cp[i].second;
            pos_precedent = i;
        }
        i--;
    }

    k--;
    for(int i = k; i >= 1; i--) {
        out << sol[i] << " ";
    }
    return 0;
}