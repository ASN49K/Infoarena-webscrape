#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[10000001];
int main() {
    int n;
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
    }
    int lgmax = 0;
    for (int i = 1; i < n; ++i) {
        int lg = 1;
        int aux = v[i];
        for (int j = i + 1; j <= n; ++j) {
            if (v[j] > aux) {
                aux = v[j];
                ++lg;
            }
        }
        if (lg > lgmax) {
            lgmax = lg;
        }
    }
    fout << lgmax;
    return 0;
}
