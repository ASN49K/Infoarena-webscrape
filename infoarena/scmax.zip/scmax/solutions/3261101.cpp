#include <bits/stdc++.h>
using namespace std;

bool sortCrt(pair<int, int> a, pair<int, int> b) {
    if (a.first == b.first) {
        return a.second > b.second;
    }
    return a.first < b.first;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    int n;
    cin >> n;
    vector<pair<int, int>> sorted(n + 1);
    vector<int> seq(n + 1, 0), a(n + 1), last(n + 1, -1);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        sorted[i].first = a[i];
        sorted[i].second = i;
    }
    sort(sorted.begin(), sorted.end(), sortCrt);
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j < sorted[i].second; ++j) {
            if (seq[sorted[i].second] < seq[j] + 1) {
                seq[sorted[i].second] = seq[j] + 1;
                last[sorted[i].second] = j;
            }
        }
    }
    int target = -1, maxSeq = 0;
    for (int i = 1; i <= n; ++i) {
        if (seq[i] > maxSeq) {
            target = i;
            maxSeq = seq[i];
        }
    }
    stack<int> sequence;
    for (int current = target; current != 0; current = last[current]) {
        sequence.push(a[current]);
    }
    cout << maxSeq << "\n";
    while (!sequence.empty()) {
        cout << sequence.top() << " ";
        sequence.pop();
    }
    return 0;
}
