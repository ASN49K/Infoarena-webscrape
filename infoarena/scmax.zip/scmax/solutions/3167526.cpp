#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,v[100001],d[100001],lmax,tata[100001];
void afisare(int i)
{
    if(i>0)
    {
        afisare(tata[i]);
        fout<<v[i]<<" ";
    }
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        d[i]=2000000001;
    }

    for(int i=1;i<=n;i++)
    {
        int st=1,dr=lmax,mid=0,poz=0;
        while(st<=dr)
        {
            mid=(st+dr)/2;
            if(v[i]>v[d[mid]])
            {
                st=mid+1;
                poz=mid;
            }
            else
                dr=mid-1;
        }

            if(poz==lmax){
                lmax++;
                d[lmax]=i;
                tata[i]=d[poz];
            }
            else
            {
                d[poz+1]=i;
                tata[i]=d[poz];
            }


    }
    fout<<lmax<<"\n";
    afisare(d[lmax]);
    return 0;
}
