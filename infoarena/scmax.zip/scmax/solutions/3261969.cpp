#include <bits/stdc++.h>

using namespace std;

const int N_MAX = 1e5 + 1;
int N, k;
int v[N_MAX];

vector<stack<int>> dp;

void SetInput(string name)
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    (void)!freopen((name + ".in").c_str(), "r", stdin);
    (void)!freopen((name + ".out").c_str(), "w", stdout);
}

void ReadArray()
{
    cin >> N;

    for(int i = 1; i <= N; i++)
        cin >> v[i];
}


int LowestGreaterPos(int& x) /// find the first position in dp with it's stack top greater than x
{
    int L = 0, R = (int)dp.size() - 1, m;
    int ans = -1;

    while(L <= R)
    {
        m = (L + R) / 2;

        if(v[dp[m].top()] >= x)
        {
            ans = m;
            R = m - 1;
        }
        else
            L = m + 1;
    }

    return ans;
}

void DisplayAnsArray()
{
    stack<int> ans;
    ans.push(dp.back().top());
    for(int i = dp.size() - 2; i >= 0; i--)
    {
        while(dp[i].top() > ans.top())
            dp[i].pop();
        ans.push(dp[i].top());
    }

    while(!ans.empty())
    {
        cout << v[ans.top()] << ' ';
        ans.pop();
    }
    cout << '\n';
}

void Solve()
{
    dp.push_back(stack<int>());
    dp[0].push(1);

    for(int i = 2; i <= N; i++)
    {
        if(v[i] > v[dp.back().top()])
        {
            dp.push_back(stack<int>());
            dp.back().push(i);
        }
        else
            dp[LowestGreaterPos(v[i])].push(i);
    }

    cout << dp.size() << '\n';
    DisplayAnsArray();
}

int main()
{
    SetInput("scmax");

    ReadArray();
    Solve();

    return 0;
}
