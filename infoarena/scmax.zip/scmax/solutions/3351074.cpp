//#include <iostream>
#include <fstream>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int dp[100001];
int main()
{
    int n,a[100001];
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(int i=1;i<=n;i++){
        dp[i]=1;
        for(int j=1;j<=i;j++)
            if(a[j]<a[i])
                if(dp[j]+1>dp[i])
                    dp[i]=dp[j]+1;
    }
    cout<<dp[n];
}
