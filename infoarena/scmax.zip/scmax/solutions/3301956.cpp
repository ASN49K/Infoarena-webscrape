#include <bits/stdc++.h>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

int dp[100005];
int tata[100005]; // ca la un tree
int v[100005];

int main()
{
    int n;
    fin >> n;
    for (int i=1;i<=n;i++){
        fin >> v[i];
    }
    v[0] = -2*1e9;
    v[n+1] = 2*1e9;
    dp[0] = 0;
    for (int i=1;i<=n;i++){
        dp[i] = n+1;
    }
    int len = 0;
    for (int i=1;i<=n;i++){
        int pos = 0;
        for (int p=20;p>=0;p--){
            if (pos+(1<<p)<=n and v[i]>v[dp[pos+(1<<p)]]){
                pos += (1<<p);
            }
        }
        pos += 1;
        dp[pos] = i;
        len = max(len,pos);
        tata[i] = dp[pos-1];
    }
    fout << len << '\n';
    int cpos = dp[len];
    vector <int> ans;
    for (int i=1;i<=len;i++){
        ans.push_back(v[cpos]);
        cpos = tata[cpos];
    }
    reverse(ans.begin(),ans.end());
    for (auto x:ans){
        fout << x << ' ';
    }
    return 0;
}
