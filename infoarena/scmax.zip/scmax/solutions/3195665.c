#include <stdio.h>

#define MAXN 100000

int v[MAXN], nr_subsir[MAXN], nr[MAXN];
int lmax;

int cautbin(int e){
   int st, dr, mij;
   st=-1;
   dr=lmax;
   while(dr-st>1){
      mij=(st+dr)/2;
      if(e<=v[mij]){
         dr=mij;
      }
      else{
         st=mij;
      }
   }
   return dr;
}

int main()
{
   FILE *fin, *fout;
   int n, index, pos, max;
   fin=fopen("scmax.in", "r");
   fscanf(fin, "%d", &n);
   lmax=0;
   for(index=0;index<n;index++){
      fscanf(fin, "%d", &nr[index]);
      pos=cautbin(nr[index]);
      v[pos]=nr[index];
      if(pos==lmax){
         lmax++;
      }
      nr_subsir[index]=pos;
   }
   fclose(fin);
   fout=fopen("scmax.out", "w");
   fprintf(fout, "%d\n", lmax);
   ///refacem v
   index=n-1;
   while(nr_subsir[index]!=lmax-1){
      index--;
   }
   v[lmax-1]=max=nr[index];
   index--;
   pos=lmax-2;
   while(index>=0){
      if(nr_subsir[index]==pos&&nr[index]<max){
         v[pos]=max=nr[index];
         pos--;
      }
      index--;
   }
   for(index=0;index<lmax;index++){
      fprintf(fout, "%d ", v[index]);
   }
   fclose(fout);
   return 0;
}
