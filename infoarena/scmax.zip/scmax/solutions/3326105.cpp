#include <iostream>
#include <limits.h>
#include <fstream>
using namespace std;
int a[100001],i,j,lung[100001],poz[100001];
int main()
{
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    long long n;
   fin>>n;
   for(i=1;i<=n;i++)
       fin>>a[i];
    lung[n]=1;poz[n]=-1;
    for(i=n-1;i>=1;i--)
    {   lung[i]=1;poz[i]=-1;
        for(j=n;j>i;j--)
          if(a[i]<a[j]&&lung[i]<lung[j]+1)
          {  lung[i]=lung[j]+1;
             poz[i]=j;
          }
    }

    int maxim=INT_MIN,pozitie;
    for(i=1;i<=n;i++)
         if(lung[i]>maxim) {maxim=lung[i];pozitie=i;}
    fout<<maxim;
    fout<<endl;
    while(pozitie!=-1)
    {
        fout<<a[pozitie]<<" ";
        pozitie=poz[pozitie];
    }
    return 0;
}


