#include <bits/stdc++.h>
using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int n,i,j,x,y,a[100005],p,dp[100005],poz[100005],nma=0;
int ans[100005];
//dp[i] - cel mai lung subsir maximal care se termina pe poz i
//poz[k] - poz celui mai din dr nr cu care se termina un subsir cresc max de lungime k
int cautare(int val, int st, int dr){
    int mij, nr;
    while(st<=dr){
        mij = (st+dr)/2;
        if(a[poz[mij]] < val){
            nr=mij;
            st=mij+1;
        }
        else dr=mij-1;
    }
    return nr;
}
int main()
{
    f>>n;
    for(i=1; i<=n; ++i)
        f>>a[i];
    for(i=1; i<=n; ++i){
        //caut printre valorile unde se termina siruri de lungime <= nma
        p=cautare(a[i], 0, nma);
        poz[p+1] = i;
        dp[i] = p+1;
        nma = max(nma, p+1);
    }
    g<<nma<<'\n';
    //for(i=1;i<=n;++i) cout<<dp[i]<<' ';
    int j=0;
    x=nma;
    for(i=n; i>=1; --i)
        if(dp[i]==nma){
            ++j; ans[j]=a[i]; nma--;
        }
    sort(ans+1, ans+x+1);
    for(i=1; i<=x; ++i) g<<ans[i]<<' ';
    return 0;
}
