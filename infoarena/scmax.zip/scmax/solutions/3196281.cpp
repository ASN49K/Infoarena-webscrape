#include <fstream>
#include <map>
#include <vector>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");
int n;
int v[100005];
map<int, vector<int>> m;
int segtree[400005];
int ans[100005];

void update(int node, int left, int right, int poz, int val)
{
    if(left == right)
    {
        segtree[node] = val + 1;
    }
    else
    {
        int mij = (left + right) / 2;

        if(poz <= mij)
        {
            update(2 * node, left, mij, poz, val);
        }
        else
        {
            update(2 * node + 1, mij+1, right, poz, val);
        }

        segtree[node] = max(segtree[2*node], segtree[2 * node + 1]);
    }
}

int query(int node, int left, int right, int qleft, int qright)
{
    if(qleft <= left && right <= qright)
    {
        return segtree[node];
    }
    else
    {
        int mij = (left + right) / 2;

        if(qright <= mij)
        {
            return query(2*node, left, mij, qleft, qright);
        }
        else if(mij+1 <= qleft)
        {
            return query(2*node+1, mij+1, right, qleft, qright);
        }

        return max(query(2*node, left, mij, qleft, qright), query(2*node+1, mij+1, right, qleft, qright));
    }
}

int main()
{
    in>>n;

    for(int i = 1; i<=n; i++)
    {
        in>>v[i];

        m[v[i]].push_back(i);
    }

    int nr = 0;
    for(auto i: m)
    {
        nr++;

        for(auto j: i.second)
        {
            v[j] = nr;
        }
    }


    /*for(int i = 1; i<=n; i++)
    {
        out<<v[i]<<" ";
    }*/

    int val;
    for(int i = 1; i<=n; i++)
    {
        if(v[i] == 1)
        {
            val = 0;
        }
        else
        {
            val = query(1, 1, n, 1, v[i] - 1);
        }


        update(1, 1, n, v[i], val);
    }

    out<<query(1, 1, n, 1, nr);

    return 0;
}
