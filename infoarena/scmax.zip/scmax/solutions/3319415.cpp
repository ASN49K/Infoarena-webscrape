#include <fstream>
#include <iostream>
using namespace std;
ifstream in ("scmax.in");
ofstream out ("scmax.out");
int main()
{
    int n,a[100001],val_max=0,cresc[100001];
    in>>n;
    for(int i=1;i<=n;i++)
    {
        in>>a[i];
    }
    int j=1;
    for(int i=2;i<=n;i++)
    {
        if(a[j]<a[i])
        {
            val_max++;
            cresc[val_max]=a[j];
            j++;
        }
        else
        {
            j++;
        }
    }
    if(cresc[val_max]<a[j])
    {
        val_max++;
        cresc[val_max]=a[j];
    }
    out<<val_max<<"\n";
    for(int i=1;i<=val_max;i++)
    {
        out<<cresc[i]<<" ";
    }
    in.close();
    out.close();
    return 0;
}