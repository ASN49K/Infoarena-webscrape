#include <bits/stdc++.h>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int n,lg[1005],a[1005],nr;

void sclm2()
{
    lg[1]=a[1];
    nr=1;

    for (int i=2; i<=n; i++ )
    {
        if ( a[i]>lg[nr] )
             lg[++nr]=a[i];
        else
        {
            int st=1,dr=nr;
            int poz=nr+1;
            while ( st<=dr )
            {
                int m=(st+dr)/2;
                if ( a[i]<=lg[m] )
                {
                    poz=m;
                    dr=m-1;
                }
                else st=m+1;
            }
            lg[poz]=a[i];
        }
    }
}


int main()
{
    f >> n;
    for (int i=1; i<=n; i++ )
        f >> a[i];

    sclm2();

    g << nr << '\n';
    for (int i=1; i<=nr; i++ )
        g << lg[i] << " ";
    return 0;
}
