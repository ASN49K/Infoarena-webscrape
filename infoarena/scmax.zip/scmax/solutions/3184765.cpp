#include <fstream>
using namespace std;

ifstream fin ("scmax.in");
ofstream fout("scmax.out");

const int NMax = 100001;

long long a[NMax], l[NMax], n, maxim = -1, maxim_i, comp;

void citire()
{
    fin >> n;
    for (int i = 1 ; i <= n ; ++i)
        fin >> a[i];
}

void rezolvare()
{
    for (int i = 1 ; i <= n ; ++i)
    {
        l[i] = 1;
        comp = a[i];
        for (int j = i + 1 ; j <= n ; ++j)
            if (comp < a[j])
            {
                ++l[i];
                comp = a[j];
            }
        if (maxim < l[i])
        {
            maxim = l[i];
            maxim_i = i;
        }
    }
}

void afisare()
{
    fout << maxim << "\n" << a[maxim_i] << " ";
    comp = a[maxim_i];
    for (int i = maxim_i + 1 ; i <= n ; ++i)
        if (comp < a[i])
        {
            fout << a[i] << " ";
            comp = a[i];
        }
}

int main()
{
    citire();
    rezolvare();
    afisare();

    fin.close();
    fout.close();
    return 0;
}