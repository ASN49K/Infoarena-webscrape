#include <bits/stdc++.h>
using namespace std;

const int MAX_NUM = 1e5 + 5;
vector<pair<int, int>> tree(4 * MAX_NUM, {0, 0});
vector<int> last(MAX_NUM, -1);

bool sortCrt(pair<int, int> a, pair<int, int> b) {
    if (a.first == b.first) {
        return a.second > b.second;
    }
    return a.first < b.first;
}

pair<int, int> maxInInterval(int node, int l, int r, int queryL, int queryR) {
    if (queryL <= l && r <= queryR) {
        return tree[node];
    }
    if (queryL > r || queryR < l) {
        return {0, 0};
    }
    int mid = (l + r) / 2;
    return max(maxInInterval(2 * node + 1, l, mid, queryL, queryR), maxInInterval(2 * node + 2, mid + 1, r, queryL, queryR));
}

void update(int node, int l, int r, int pos, pair<int, int> value) {
    if (l == r) {
        tree[node] = max(tree[node], value);
        return;
    }
    int mid = (l + r) / 2;
    if (pos <= mid) {
        update(2 * node + 1, l, mid, pos, value);
    } else {
        update(2 * node + 2, mid + 1, r, pos, value);
    }
    tree[node] = max(tree[2 * node + 1], tree[2 * node + 2]);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    int n;
    cin >> n;
    vector<int> a(n);
    vector<pair<int, int>> sorted(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
        sorted[i] = {a[i], i};
    }
    sort(sorted.begin(), sorted.end(), sortCrt);
    int target = -1, maxSeq = 1;
    for (auto [value, index] : sorted) {
        auto [len, lastIndex] = maxInInterval(0, 1, n, 1, index - 1);
        update(0, 1, n, index, {len + 1, index});
        last[index] = lastIndex;
        if (len + 1 > maxSeq) {
            maxSeq = len + 1;
            target = index;
        }
    }
    stack<int> sequence;
    for (int current = target; current != 0; current = last[current]) {
        sequence.push(a[current]);
    }
    cout << maxSeq << "\n";
    while (!sequence.empty()) {
        cout << sequence.top() << " ";
        sequence.pop();
    }
    return 0;
}
