#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int v[100001];
int main()
{
    int n,stf,drf,st=1,dr=1,cnt=1,lmax=-1;
    fin>>n;
    fin>>v[1];
    for(int i=2;i<=n;i++)
    {
        fin>>v[i];
        if(v[i]>v[i-1])
        {
            cnt++;
            dr=i;
            if(i==n&&lmax<cnt)
            {
                lmax=cnt;
                stf=st;
                drf=dr;
            }
        }

        else if(v[i]<v[i-1])
        {
            if(lmax<cnt)
            {
                lmax=cnt;
                stf=st;
                drf=dr;
            }
            cnt=1;
            st=dr=i;
        }
    }
    if(n==1)
    {
        fout<<n<<'\n';
        fout<<v[1];
    }
    else
    {
        fout<<lmax<<'\n';
        for(int i=stf;i<=drf;i++)
        {
            if(i==stf)
                fout<<v[i]<<' ';
            else
            {
                if(v[i-1]!=v[i])
                    fout<<v[i]<<' ';
            }
        }
    }
    return 0;
}
