#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    int n;
    cin >> n;
    vector<int> a(n), seq(n, 1);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    seq[0] = 1;
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            if (a[i] > a[j]) {
                seq[i] = max(seq[i], seq[j] + 1);
            }
        }
    }
    cout << *max_element(seq.begin(), seq.end());
    return 0;
}
