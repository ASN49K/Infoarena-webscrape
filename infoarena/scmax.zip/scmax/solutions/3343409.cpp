#include <fstream>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int n,a[nmax],dp[nmax],t[nmax],m;
void rec(int i){
    if(t[i]!=0)
        rec(t[i]);
    cout<<a[i]<<" ";
}
signed main()
{
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        int st=1,dr=m,poz=0;
        while(st<=dr){
            int mid=(st+dr)/2;
            if(a[dp[mid]]>=a[i]){
                poz=mid;
                dr=mid-1;
            }else
                st=mid+1;
        }
        if(poz==0){
            t[i]=dp[m];
            dp[++m]=i;
        }else{
            t[i]=dp[poz-1];
            dp[poz]=i;
        }
    }
    cout<<m<<'\n';
    rec(dp[m]);
    return 0;
}
