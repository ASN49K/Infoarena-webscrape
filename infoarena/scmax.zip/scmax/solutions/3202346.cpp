#include <fstream>
#include <stack>
#define dim 100002
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");

int n,k;
int v[dim],d[dim],p[dim];

void insert(int val,int pozi){
    if(d[k]==val) return;
    if(d[k]<val) d[++k]=val,p[pozi]=k;
    else{
        int st=1,dr=k,poz;
        while(st<=dr){
            int m=(st+dr)/2;
            if(val<d[m]) poz=m,dr=m-1;
            else st=m+1;
            if(d[m]==val) return;
        }
        d[poz]=val;
        p[pozi]=poz;
    }
}

void reconst(){
    stack<int>S;
    for(int i=n,val=k;i>=1,val>0;--i)
        if(p[i]==val) val--,S.push(v[i]);
    
    while(!S.empty()){
        cout<<S.top()<<" ";
        S.pop();
    }
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;++i){
        cin>>v[i];
        insert(v[i],i);
    }
    
    cout<<k<<'\n';
    reconst();
    return 0;
}