#include <fstream>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

const int NMAX=100005;

int v[NMAX], valmin[NMAX], tata[NMAX], rasp[NMAX];

int cb(int x, int dr)
{
    int st=1, mij;
    int ans=0;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(x<=valmin[mij])
        {
            ans=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    return ans;
}

int main()
{
    int n;
    cin>>n;
    int ans=1, pozans=0;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        int poz=cb(v[i], i-1);
        if(valmin[poz]!=0)
        {
            tata[i]=poz;
            valmin[poz]=min(valmin[poz],v[i]);
        }
        if(poz==0)
        {
            tata[i]=ans;
            valmin[ans]=v[i];
            ans++;
            pozans=i;
        }
        if(poz+1>ans)
        {
            pozans=i;
            ans=poz+1;
        }
    }
    /*for(int i=1;i<=n;i++)
        cout<<valmin[i]<<" ";
    cout<<'\n';
    for(int i=1;i<=n;i++)
        cout<<tata[i]<<" ";
    cout<<'\n';*/
    ans--;
    cout<<ans<<'\n';
    for(int i=1;i<=ans;i++)
    {
            rasp[i]=pozans;
            pozans=tata[pozans];
    }
    for(int i=ans;i>=1;i--)
    {
            cout<<v[rasp[i]]<<" ";
    }
    return 0;
}
