#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100001], t[100001], dp[100010];

void reconst_drum(int u)
{
    if(u!=0)
    {
        reconst_drum(t[u]);
        fout<<v[u]<<" ";
    }
}

int main()
{
    int n, i, j, sol=0, p, poz;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    dp[1]=1;
    t[1]=0;
    for(i=2;i<=n;i++)
    {
        int maxx=0;
        for(j=1;j<i;j++)
        {
            if(v[j]<v[i])
            {
                if(maxx<dp[j])
                {
                    maxx=dp[j];
                    p=j;
                }
            }
        }
        dp[i]=maxx+1;
        if(maxx==0)
        {
            t[i]=0;
        }
        else
        {
            t[i]=p;
        }
        if(dp[i]>sol)
        {
            sol=dp[i];
            poz=i;
        }
    }
    reconst_drum(poz);
}
