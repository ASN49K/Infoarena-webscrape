#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int N = 1e5;
const int INF = 2e9 + 1;
int v[N],val_min[N+1],lung[N-1];
int binar(int v[], int n, int val) 
{
    ///pozitia ultimului element al lui v care e < val
    int st=1, dr=n, rez=0;
    while (st<=dr)
    {
        int m=(st+dr)/2; 
        if(v[m]<val)
        {
            rez=m; 
            st=m+1;
        }
        else
        {
            dr=m-1;
        }
    }
    return rez; 
}
void refaceresir(int lungime,int p,int val)
{
    if(lungime==0)
    {
        return;
    }
    if(lungime==lung[p] && v[p]<val)
    {
        refaceresir(lungime-1,p-1,v[p]);
        fout<<v[p]<<" ";
    }
    else
    {
        refaceresir(lungime,p-1,val);
    }
}
int main()
{
    int n;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        fin>>v[i];
    }
    int n_val_min=0,i_max=0;
    for(int i=0;i<n;i++)
    {
        int j=binar(val_min,n_val_min,v[i]);
        if(j==n_val_min)
        {
            n_val_min++;
        }
        lung[i]=j+1; 
        val_min[j+1]=v[i]; 
        if(lung[i]>lung[i_max])
        {
            i_max=i; 
        }
    }
    fout<<lung[i_max]<<"\n";
    int f=lung[i_max];
    long long val=INF;
    refaceresir(lung[i_max],i_max,INF);
    fin.close();
    fout.close();
}