#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;

// Funcție pentru a găsi cel mai lung subsir crescător
vector<int> findLIS(const vector<int>& a) {
    if (a.empty()) return {};
    vector<int> lis, pos, parent(a.size());
    for (size_t i = 0; i < a.size(); ++i) {
        auto it = lower_bound(lis.begin(), lis.end(), a[i]);
        int idx = it - lis.begin();
        if (it == lis.end()) {
            lis.push_back(a[i]);
        } else {
            *it = a[i];
        }
        pos.push_back(idx);
        if (idx > 0) {
            parent[i] = pos[idx - 1];
        } else {
            parent[i] = -1;
        }
    }
    vector<int> result;
    for (int i = pos.size() - 1, j = lis.size() - 1; i >= 0; --i) {
        if (pos[i] == j) {
            result.push_back(a[i]);
            --j;
        }
    }
    reverse(result.begin(), result.end());
    return result;
}

int main() {
    ifstream infile("scmax.in");
    ofstream outfile("scmax.out");

    int N;
    infile >> N;
    vector<int> a(N);

    for (int i = 0; i < N; ++i) {
        infile >> a[i];
    }

    vector<int> lis = findLIS(a);

    outfile << lis.size() << endl;
    for (const int& val : lis) {
        outfile << val << " ";
    }
    outfile << endl;

    infile.close();
    outfile.close();

    return 0;
}
