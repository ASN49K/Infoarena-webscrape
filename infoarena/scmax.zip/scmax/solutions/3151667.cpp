#include <fstream>

using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int dp[100001],v[100001],rez[100001];
void afisare(int n)
{
    if(n>0)
    {
        afisare(rez[n]);
        cout<<v[n]<<" ";
    }
}
int main()
{
    int st,dr,mij,poz,n,i,k=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i];
        st=1;
        dr=k;
        poz=0;
        while(st<=dr)
        {
            mij=(st+dr)/2;
            if(v[dp[mij]]<v[i])
            {
                poz=mij;
                st=mij+1;
            }
            else
                dr=mij-1;
        }
        dp[poz+1]=i;
        k=max(poz+1,k);
        rez[i]=dp[poz];
    }
    cout<<k<<'\n';
    afisare(dp[k]);
    return 0;
}
