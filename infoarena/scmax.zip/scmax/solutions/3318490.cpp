#include <fstream>
#include <iostream>
#include <queue>
#include <bitset>
#include <stack>
#include <unordered_map>
#include <vector>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int dp[100001], k, v[100001], n, pos[100001];

//dp[i] = valoarea minima cu care se termina un subsir strict crescator care are lungime i
//pos[i] = pozitia din vectorul dp la care am pus valoare de pe pozitia i din sirul initial

int CautBin(int val)
{
    ///caut binar cel mai mic element >= val
    int st = 1, dr = k, poz = -1;
    while (st <= dr){
        int mij = (st + dr) / 2;
        if (dp[mij] >= val)
        {
            poz = mij;
            dr = mij - 1;
        }
        else st = mij + 1;
    }
    return poz;

}

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
    dp[1] = v[1]; k = 1;
    for (int i = 2; i <= n; i++)
    {
        if (v[i] > dp[k])
        {
            dp[++k] = v[i];
            pos[i] = k;
        }
        else
        {
            int p = CautBin(v[i]);
            dp[p] = v[i];
            pos[i] = p;
        }

    }
    fout << k << "\n";
    int p = 1;
    for (int i = 2; i <= n; i++)
        if (pos[i] > pos[p]) p = i;
    stack<int> st;
    st.push(p);
    for (int i = p - 1; i >= 1; i--)
        if (pos[i] == pos[p] - 1 && v[i] < v[p]) {
            st.push(i);
            p = i;
        }
    while (!st.empty()) {
        fout << v[st.top()] << " ";
        st.pop();
    }
    return 0;
}
