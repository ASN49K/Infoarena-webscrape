#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int v[100001];
int main()
{
    int n,xant=0,cnt=0,lmax=-1;
    fin>>n;

    for(int i=1;i<=n;i++)
    {
        int x;
        fin>>x;
        if(i==1)
            v[++cnt]=x;
        if(xant!=0)
        {
            if(x>xant)
            {
                v[++cnt]=x;
                if(i==n&&cnt>lmax)
                    lmax=cnt;
            }

            else if(x<xant)
            {
                if(cnt>lmax)
                    lmax=cnt;
                cnt=0;
                v[++cnt]=x;
            }
        }
        xant=x;
    }
    fout<<lmax<<'\n';
    return 0;
}
