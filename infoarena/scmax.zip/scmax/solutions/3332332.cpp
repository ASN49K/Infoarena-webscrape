#include <algorithm>
#include <bits/stdc++.h>
#include <vector>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main() {
  int n;
  vector<int> c;
  fin >> n;
  for (int i = 0; i < n; i++) {
    int x;
    fin >> x;
    if (c.empty() || x > c.back())
      c.push_back(x);
    else {
      int it = lower_bound(c.begin(), c.end(), x) - c.begin();
      c[it] = x;
    }
  }
  fout << c.size() << "\n";
  for (int i = 0; i < c.size(); i++) {
    fout << c[i] << " ";
  }
}
