#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,v[100001],best[100001],k,w[100001];
int cb(int x){
    int st=1,dr=k,poz;
    while(st<=dr){
        int mij = (st+dr)/2;
        if(x<=best[mij])
            poz=mij,dr=mij-1;
        else
            st=mij+1;
    }
    return poz;
}
int main(){
   fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    k=1; best[k]=v[1];

    for(int i=2;i<=n;i++){
        int x = v[i];
        if(x>best[k]){
            best[++k]=x;

        }
        else{
            int poz = cb(x);
            best[poz]=x;
        }
        w[i]=k;
    }
    fout<<k<<'\n';
    int ind = n;
    int last = 1000000000,k2=0,rez[100001];
    for(int val = k;val>=1;val--){
        while(!(v[ind]<last && w[ind]==val))
            ind--;
        rez[++k2]=v[ind];
        last=v[ind];
    }
    for(int i=k2;i>=1;i--)
        fout<<rez[i]<<" ";
    return 0;
}
