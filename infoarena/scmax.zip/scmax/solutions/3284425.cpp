#include <bits/stdc++.h>
#define oo 100101010
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int a[100005], n, m, dp[100005], poz[100005], sol[100005];
int CautBin(int x)
{
    int st, dr, p, mijl;
    st = 1; dr = p = m;
    while(st <= dr)
    {
        mijl = (st + dr) / 2;
        if(x <= dp[mijl])
        {
            dr = mijl - 1;
            p = mijl;
        }
        else st = mijl + 1;
    }
    return p;
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i,j;
    fin >> n;
    for(i = 1; i <= n; i++)
        fin >> a[i];
    dp[1] = a[1];
    poz[1] = 1;
    m = 1;
    for(i = 2; i <= n; i++)
    {
        int x = a[i];
        if(x <= dp[1])
        {
            dp[1] = x;
            poz[i] = 1;
        }
        else if(x > dp[m])
        {
            dp[++m] = x;
            poz[i] = m;
        }
        else
        {
            int p = CautBin(x);
            dp[p] = x;
            poz[i] = p;
        }
    }
    fout << m << "\n";
    int k = m;
    for(i = n; i >= 1 && k > 0; i--)
        if(poz[i] == k)
        {
            sol[k] = a[i];
            k--;
        }
    for(i = 1; i <= m; i++)
        fout << sol[i] << " ";
    return 0;
}
