#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

const int N_MAX = 100000;
int n;
int v[N_MAX + 5], valoare[N_MAX + 5], poz1[N_MAX + 5], predecesor[N_MAX + 5], poz2[N_MAX + 5];

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
    int m = 0, poz_final = 0;
    for (int i = 1; i <= n; i++) {
        int st = 1, dr = m, poz = m + 1;
        while (st <= dr) {
            int mij = (st + dr) / 2;
            if (v[i] <= valoare[mij]) {
                poz = mij;
                dr = mij - 1;
            }
            else
                st = mij + 1;
        }
        valoare[poz] = v[i];
        poz1[poz] = i;
        if (poz >= 2)
            predecesor[i] = poz1[poz - 1];
        else
            predecesor[i] = -1;
        if (poz > m) {
            m = poz;
            poz_final = i;
        }
    }
    fout << m << "\n";
    m = 0;
    while (poz_final != -1) {
        poz2[++m] = poz_final;
        poz_final = predecesor[poz_final];
    }
    for (int i = m; i >= 1; i--)
        fout << v[poz2[i]] << " ";
    fout << "\n";
    return 0;
}
