#include <bits/stdc++.h>
using namespace std;

int a[100005], len[100005], index[100005];

int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];

    for (int i = 1; i <= n; ++i)
        for (int j = 0; j < i; ++j)
            if (a[i] > a[j] && len[j] + 1 > len[i])
                len[i] = len[j] + 1, index[i] = j;

    int maxim = len[1], pos = -1;
    for (int i = 2; i <= n; ++i)
        if (len[i] > maxim)
            maxim = len[i], pos = i;

    vector<int> ans;
    while (pos != 0)
    {
        ans.push_back(a[pos]);
        pos = index[pos];
    }
    reverse(ans.begin(), ans.end());

    cout << maxim << "\n";
    for (int i = 0; i < a.size(); ++i)
        cout << x << " ";

    return 0;
}
