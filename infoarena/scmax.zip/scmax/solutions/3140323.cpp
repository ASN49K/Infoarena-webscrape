#include <fstream>
#include <cassert>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

static const int NMAX = (int)(1e5 + 1);

int N;

int k, s[NMAX];

int main()
{
    f.tie(nullptr);

    f >> N;

    for (int i = 1; i <= N; ++i)
    {
        int x = 0;
        f >> x;

        if (!k)
            s[++k] = x;
        else
        {
            if (s[k] < x)
                s[++k] = x;
            else
            {
                int left = 1, right = k;
                int keep = 0;

                while (left <= right)
                {
                    int mid = ((left + right) >> 1);

                    if (s[mid] >= x)
                        keep = mid, right = mid - 1;
                    else
                        left = mid + 1;
                }

                assert(keep);

                s[keep] = x;
            }
        }
    }

    g << k << '\n';

    for (int i = 1; i <= k; ++i)
    {
        g << s[i];

        if (i < k)
            g << ' ';
        else
            g << '\n';
    }

    return 0;
}
