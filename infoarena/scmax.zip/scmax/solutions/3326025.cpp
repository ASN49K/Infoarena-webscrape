#include <iostream>
#include<fstream>
using namespace std;
int main()
{  ifstream fin("scmax.in");
ofstream fout("scmax.out");
    int n,a[100],poz[100],lung[100],i,j,maxi=0;
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>a[i];
    poz[n]=-1,lung[n]=1;
    for(i=n-1; i>=1; i--)
    {
        lung[i]=1,poz[i]=-1;
        for(j=n; j>i; j--)
            if(a[i]<a[j] && lung[i]<lung[j]+1)
            {
                lung[i]=lung[j]+1;
                poz[i]=j;
            }
    }
    for(i=1; i<=n; i++)
    {
        if(lung[i]>maxi)
            maxi=lung[i];
    }
    fout<<maxi;
    fout<<endl;
    for(i=1;i<=n;i++)
    {

    }
    return 0;
}
