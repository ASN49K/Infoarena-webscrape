#include<fstream>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int a[100001],b[100001],c[100001];
int main()
{
    int m=0,n;
    cin>>n;
    for(int i=1;i<=n;++i) {
        if(cin>>a[i],a[i]>a[b[m]])
            c[i]=b[m],b[++m]=i;
        int j=0;
        for(int k=m;j<k;) {
            int l=(j+k)/2;
            a[b[l]]<a[i]?j=l+1:k=l;
        }
        if(a[i]<a[b[j]]&&(b[j]=i,j))
            c[i]=b[j-1];
    }
    for(int i=m;i;b[c[i]]=i,i=c[i]);
    cout<<m<<'\n';
    for(int i=1;i<=m;cout<<a[b[i++]]<<' ');
    return 0;
}
