#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

vector<int> subir(vector<int>& v) {
    vector<int> subsir;

    for (int numar : v) {
        auto iterator = lower_bound(subsir.begin(), subsir.end(), numar);

        if (iterator == subsir.end()) {
            subsir.push_back(numar);
        } else {
            *iterator = numar;
        }
    }

    return subsir;
}

int main() {
    int n;
    fin >> n;
    vector<int> v(n);

    for (int i = 0; i < n; i ++) {
        fin >> v[i];
    }

    vector<int> rez = subir(v);
    fout << rez.size() << '\n';
    for (int num : rez) {
        fout << num << " ";
    }
    return 0;
}
