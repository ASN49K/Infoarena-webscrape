#include<iostream>
#include<vector>
#include<stdio.h>
#include<algorithm>
#include<queue>
using namespace std;

const int NMAX = 1005;
int n, pos[NMAX], max1 = 1, maxpos = 1, frev[NMAX], v[NMAX];
vector<int> dp;

int binarysearch(int target)
{
    int pos = -1, st = 0, dr = dp.size() - 1;

    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(dp[mij] > target)
            st = mij + 1;
        else
        {
            dr = mij - 1;
            if(dp[mij] < target)
                pos = mij;
        }
    }
    return pos;
}

int main()
{
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    cin >> n;
    for(int i = 1; i <= n; i++)
        cin >> v[i];
    dp.push_back(v[1]);
    pos[1] = 1;
    frev[1]++;
    for(int i = 2; i <= n; i++)
    {
        int val = binarysearch(v[i]);
        if(val == -1)
        {
            dp.push_back(v[i]);
            pos[i] = dp.size();
            frev[dp.size()] = 1;
        }
        else
        {
            dp[val] = v[i];
            pos[i] = pos[val + 1];
            frev[pos[i]]++;
            if(frev[pos[i]] > max1)
            {
                max1 = frev[pos[i]];
                maxpos = pos[i];
            }
        }
    }
    
    cout << max1 << "\n";
    for(int i = 1; i <= n; i++)
    {
        //cout << pos[i] << " ";
        if(pos[i] == maxpos)
            cout << v[i] << " ";
    }
}