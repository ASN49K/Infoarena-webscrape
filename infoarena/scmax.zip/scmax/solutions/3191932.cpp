#include <fstream>
#include <vector>
#include <iostream>

using namespace std;
int n,x;
vector <int>v;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int binary_search(int x){
    int right=0,left=v.size(),mid;
    while(right<left){
        mid=(right+left)/2;
        if(v[mid]>x){
            left=mid-1;
        } else if(v[mid]<x)
            right=mid+1;
        else{
            return mid;
        }

    }
    return left;
}
int main() {
    fin>>n;
    for(int i=0;i<n;i++){
        fin>>x;
        v.push_back(x);
    }
    if(v.size()==1)
        return 1;
    vector <int>ans;
    ans.push_back(v[0]);
    for(int i=1;i<n;i++){
        if(v[i]>ans.back()){
            ans.push_back(v[i]);
        } else{
            int low=lower_bound(ans.begin(),ans.end(),v[i])-ans.begin();
            ans[low]=v[i];
        }
    }
    fout<<ans.size()<<'\n';
    int cn=ans.size();
    for(auto a:ans){
        fout<<a<<" ";
    }
    return 0;
}
