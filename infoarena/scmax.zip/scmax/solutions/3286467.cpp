#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, a[100001], lis[100001], poz[100001], k, v[100001];

int CautBin(int x)
{
    int st, dr, mij, p = k;
    st = 1; dr = k;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (x <= lis[mij])
        {
            p = mij;
            dr = mij - 1;
        }
        else
            st = mij + 1;
    }
    return p;
}

int main()
{
    int i, x, p, L;
    fin >> n;
    for (i = 1 ; i <= n ; i++)
        fin >> a[i];
    lis[1] = a[1];
    poz[1] = 1;
    k = 1;
    for (i = 2 ; i <= n ; i++)
    {
        x = a[i];
        if (x > lis[k])
        {
            lis[++k] = x;
            poz[i] = k;
        }
        else if (x <= lis[1])
        {
            lis[1] = x;
            poz[i] = 1;
        }
        else
        {
            p = CautBin(x);
            lis[p] = x;
            poz[i] = p;
        }
    }
    fout << k << "\n";
    L = k;
    for (i = n ; i >= 1 && L > 0 ; i--)
        if (poz[i] == L)
        {
            v[L] = a[i];
            --L;
        }
    for (i = 1 ; i <= k ; i++)
        fout << v[i] << " ";
    return 0;
}
