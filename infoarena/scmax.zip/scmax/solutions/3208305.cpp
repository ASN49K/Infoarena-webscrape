#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

deque<int> nums;
deque<int> answer;

void solve() {
    int numLen;
    fin >> numLen;
    nums.clear();
    answer.clear();
    for (int i = 1; i <= numLen; ++i) {
        int number;
        fin >> number;
        while (nums.empty() == 0 && number <= nums.back()) {
            nums.pop_back();
        }
        nums.push_back(number);
        if (nums.size() > answer.size()) {
            answer = nums;
        }
    }
    fout << answer.size() << '\n';
    for (int i = 0; i < answer.size(); ++i) {
        fout << answer[i] << ' ';
    }
}

int main() {
    solve();
    return 0;
}
/*
8
13 12 12 30 30 14 30 2
=>
3
12 14 30

5
2 3 100 4 5
=>
4
2 3 4 5

6
100 3 99 4 98 5
=>
3
3 4 5

11
10 11 12 13 1 2 3 100 4 5 6
=>
6
1 2 3 4 5 6

*/
