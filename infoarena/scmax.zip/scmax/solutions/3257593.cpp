#include <bits/stdc++.h>

using namespace std;
ifstream fin ("scmax.in");
ofstream fout ("scmax.out");
int a[100002],n,lg[100002],d[100002],mx,nr;
void intoarcere(int k)
{
    if(k==0)
        return;
    else
        intoarcere(d[k]);
    fout<<a[k]<<" ";
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a[i];
    }
    lg[1]=1;
    for(int i=2;i<=n;i++)
    {
        lg[i]=1;
        for(int j=1;j<i;j++)
        {
            if(lg[j]+1>lg[i] and a[i]>a[j])
            {
                lg[j]++;
                d[i]=j;
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(d[i]>mx)
        {
            mx=d[i];
            nr=i;
        }
    }
    intoarcere(nr);
    return 0;
}
