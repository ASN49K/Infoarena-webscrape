#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,x,lmax;
vector<int> v(100011),best(100011),minim(100011),ant(100011,-1),r;
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>v[i];
    for(int i=1; i<=n; i++)
    {
        int st=1,dr=lmax,mij,rez=1;
        while(st<=dr)
        {
            mij=(st+dr)/2;
            if(v[minim[mij]]<v[i])
            {
                rez=mij+1;
                st=mij+1;
            }
            else
                dr=mij-1;
        }
        minim[rez]=i;
        best[i]=rez;
        if(rez>1)
            ant[i]=minim[rez-1];
        if(rez>lmax)
            lmax=rez;
    }
    x=minim[lmax];
    while(x!=-1)
    {
        r.push_back(v[x]);
        x=ant[x];
    }
    fout<<lmax<<'\n';
    reverse(r.begin(),r.end());
    for(auto it=r.begin(); it!=r.end(); it++)
        fout<<*it<<' ';
    return 0;
}
