#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <iomanip>
#include <cmath>
#include <algorithm>
using namespace std;
#define ll long long
#define fast ios:sync_with_stdio(false); cin.tie(0); cout.tie(0);
int main()
{
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    ll n;
    cin>>n;
    ll v[n + 1];
    ll prev[n + 1];
    vector<pair<ll, ll>> a(1, {-1e15, 0});
    cin>>v[1];
    a.push_back({v[1], 1});
    for(int i = 2; i <= n; i++)
    {
        cin>>v[i];
        if(v[i] >= a.back().first)
        {
            if(v[i] > a.back().first) 
                prev[i] = a.back().second, a.push_back({v[i], i});
            continue;
        }
        auto poz = lower_bound(a.begin(), a.end(), pair<ll, ll>(v[i], 0));
        prev[i] = (*(poz - 1)).second;
        (*poz).first = v[i];
        (*poz).second = i;
    }
    cout<<a.size() - 1<<'\n';
    ll x = a[a.size() - 1].second;
    vector<int> afis;
    while(x != 0)
    {
        afis.push_back(v[x]);
        x = prev[x];
    }
    reverse(afis.begin(), afis.end());
    for(int i = 0; i < afis.size(); i++)
        cout<<afis[i]<<" ";
}