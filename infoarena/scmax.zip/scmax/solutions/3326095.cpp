#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int a[100001], lung[100001], poz[100001],i,j,n;
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    fin>>n;

    for(i=1;i<=n;i++)
        fin>>a[i];


    lung[n]=1;poz[n]=-1;
    for(i=n-1;i>=1;i--)
    {
        poz[i]=-1;lung[i]=1;
        for(j=n;j>i;j--)
            if(a[i]<a[j]&&lung[i]<lung[i]+1)
        {
            lung[i]=lung[j]+1;
            poz[i]=j;
        }
    }
    int max=0,pozitie;
    for(i=1;i<=n;i++)
        if(lung[i]>max) {max=lung[i];
                        pozitie=i;}
    fout<<max<<endl;
    while(pozitie!=-1)
    {
        fout<<a[pozitie]<<" ";
        pozitie=poz[pozitie];
    }
    return 0;
}
