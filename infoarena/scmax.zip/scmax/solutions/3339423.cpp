#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100005], t[100005], dp[100005];
int n, p, sol, u, maxim;

void afis(int u) {
    if (u != 0) {
        afis(t[u]);
        fout << v[u] << " ";
    }
}

int main() {
    fin >> n;

    for (int i = 1; i <= n; i++)
        fin >> v[i];

    dp[1] = 1;
    t[1] = 0;
    sol = 1;
    u = 1;

    for (int i = 2; i <= n; i++) {
        maxim = 0;
        p = 0;

        for (int j = 1; j < i; j++) {
            if (v[j] < v[i] && dp[j] > maxim) {
                maxim = dp[j];
                p = j;
            }
        }

        dp[i] = maxim + 1;
        t[i] = p;

        if (dp[i] > sol) {
            sol = dp[i];
            u = i;
        }
    }

    fout << sol << "\n";
    afis(u);

    return 0;
}
