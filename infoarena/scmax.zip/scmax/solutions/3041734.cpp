#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, aib[100005], ind[100005], p, v[100005], dp[100005], ans, before[100005];
///#define fin cin
///#define fout cout
void findd(int x)
{
    if(before[x])
        findd(before[x]);
    fout << v[x] << ' ';
}
int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++ i)
    fin >> v[i];
    for(int i = 1; i <= n; ++ i)
    {
        if(v[i] > dp[ans])
        {
            dp[++ans] = v[i];
            ind[ans] = i;
            before[i] = ind[ans - 1];
        } else {

            int p = lower_bound(dp + 1, dp + ans + 1, v[i]) - dp;
            dp[p] = v[i];
            ind[p] = i;
            before[i] = ind[p - 1];
        }
    }
    fout << ans << '\n';
    findd(ind[ans]);
    return 0;
}
