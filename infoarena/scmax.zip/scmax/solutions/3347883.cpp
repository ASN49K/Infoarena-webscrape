#include <fstream>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int mxN = 1e5 + 1;
const long long INF = 2e18;

int n, len = 0;
long long a[mxN], ultim[mxN]; 
int dp[mxN];

int cautBin(int l, int r, long long v) {
    while (l < r) {
        int mid = (l + r) / 2;
        if (ultim[mid] < v)
            l = mid + 1;
        else
            r = mid;
    }
    return l;
}

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++) 
        fin >> a[i];

    for (int i = 1; i <= n; i++) {
        int ind = cautBin(1, len + 1, a[i]);
        ultim[ind] = a[i];
        dp[i] = ind;
        if (ind > len) len = ind;
    }

    fout << len << "\n";

    long long result[mxN];
    int rLen = len;
    int cur = len;
    long long last = INF;
    for (int i = n; i >= 1; i--) {
        if (dp[i] == cur && a[i] < last) {
            result[rLen--] = a[i];
            last = a[i];
            cur--;
            if (cur == 0) break;
        }
    }

    for (int i = 1; i <= len; i++) {
        fout << result[i];
        if (i > 0) fout << " ";
    }
    fout << "\n";

    return 0;
}