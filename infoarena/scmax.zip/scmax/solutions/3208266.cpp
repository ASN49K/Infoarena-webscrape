#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

deque<int> nums;
deque<int> answer;

void solve() {
    int numLen;
    fin >> numLen;
    for (int i = 1; i <= numLen; ++i) {
        int number;
        fin >> number;
        if (nums.empty() == 0 && number <= nums.front()) {
            nums.clear();
        } else {
            while (nums.empty() == 0 && number <= nums.back()) {
                nums.pop_back();
            }
        }
        nums.push_back(number);
        if (nums.size() > answer.size()) {
            answer = nums;
        }
    }
    fout << answer.size() << '\n';
    for (int i = 0; i < answer.size(); ++i) {
        fout << answer[i] << ' ';
    }
}

int main() {
    solve();
    return 0;
}
