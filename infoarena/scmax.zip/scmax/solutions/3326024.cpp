#include <iostream>
#include <limits.h>

using namespace std;

int main()
{
    int a[100],n,i,j,lung[100];
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>a[i];
    lung[n]=1;
    for(i=n-1;i>=1;i--)
    {
        lung[i]=1;
        for(j=n;j>i;j--)
            if(a[i]<a[j]&&lung[i]<lung[j]+1)
        {   lung[i]=lung[j]+1;

        }
    }

  int maxim=INT_MIN;
  for(i=1;i<=n;i++)
    if(lung[i]>maxim) maxim=lung[i];
  cout<<maxim;

    return 0;
}
