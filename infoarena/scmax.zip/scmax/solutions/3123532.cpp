#include <fstream>
#include <vector>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

struct multime
{
    int best = 0;
    vector<pair<int, int>> vec;
};

int n;
int ind = 0;
multime v[100005];
vector<int> ans;

int cb(int x)
{
    int st = 1;
    int dr = ind;
    int m;
    int poz = 0;

    while(st <= dr)
    {
        m = (st + dr) / 2;

        if(v[m].vec[v[m].best].first >= x)
        {
            poz = m;
            dr = m - 1;
        }
        else
        {
            st = m + 1;
        }
    }

    return poz;
}

int main()
{
    in>>n;

    int x, poz;

    v[0].vec.resize(n+5);

    in>>x;
    ind++;
    v[ind].vec.push_back({0, 0});
    v[ind].best++;
    v[ind].vec.push_back({x, 0});

    for(int i = 2; i<=n; i++)
    {
        in>>x;
        poz = cb(x);

        if(poz == 0)
        {
            ind++;
            v[ind].vec.push_back({0, 0});
            v[ind].best++;
            v[ind].vec.push_back({x, v[ind-1].best});
        }
        else
        {
            v[poz].best++;
            v[poz].vec.push_back({x, v[ind-1].best});
        }
    }


    out<<ind<<'\n';

    /*for(int i = 1; i<=ind; i++)
    {
        for(int j = 1; j<=v[i].best; j++)
        {
            out<<v[i].vec[j].first<<" "<<v[i].vec[j].second<<'\n';
        }
        out<<'\n';
    }*/

    for(int i = 1; i<=ind; i++)
    {
        out<<v[i].vec[v[i].best].first<<" ";
    }

    return 0;
}

