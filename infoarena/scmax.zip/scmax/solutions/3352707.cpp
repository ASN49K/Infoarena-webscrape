#include <vector>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");

    int n;
    fin >> n;

    if (n == 0) {
        return 0;
    }

    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        fin >> v[i];
    }

    vector<int> c, b;

    c.push_back(v[0]);

    for (int i = 1; i < n; i++) {
        if (v[i] > c.back()) {
            c.push_back(v[i]);
        } else if (v[i] == c.back()) {
            continue;
        } else {
            if (c.size() > b.size()) {
                b = c;
            }
            c.clear();
            c.push_back(v[i]);
        }
    }

    if (c.size() > b.size()) {
        b = c;
    }

    fout << b.size() << '\n';
    for (int x : b) {
        fout << x << " ";
    }

    return 0;
}
