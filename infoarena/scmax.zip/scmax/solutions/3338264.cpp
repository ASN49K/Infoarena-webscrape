#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

vector<int> a;
vector<int> lungime;
vector<int> parinte;
vector<int> res;

int main()
{
    int n;
    f >> n;
    a.resize(n);
    for(int i = 0; i < n; i++)
        f >> a[i];

    lungime.assign(n, 1);
    parinte.assign(n, -1);
    int lungime_max = 1, poz;
    for(int i = 1; i < n; i++)
    {
        for(int j = 0; j < i; j++)
            if(a[j] < a[i] && lungime[j] + 1 > lungime[i])
            {
                lungime[i] = max(lungime[i], lungime[j] + 1);
                parinte[i] = j;
            }
        if(lungime_max < lungime[i])
        {
            lungime_max = lungime[i];
            poz = i;
        }
    }

    while(poz != -1)
    {
        res.push_back(a[poz]);
        poz = parinte[poz];
    }

    g << lungime_max << "\n";
    for(int i = res.size() - 1; i >= 0; i--)
        g << res[i] << " ";
    return 0;
}