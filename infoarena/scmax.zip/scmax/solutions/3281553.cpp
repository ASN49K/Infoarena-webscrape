#include <bits/stdc++.h>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

const int NMAX=100001;
int a[NMAX],d[NMAX],p[NMAX];
long long n,k;

void citire()
{
    f>>n;
    for(int i=1;i<=n;i++)
        f>>a[i];
}

void aflare()
{
    k=1;d[1]=a[1];p[1]=1;
    for(int i=2;i<=n;i++)
    {
        if(a[i]>d[k])
            {
               d[++k]=a[i];
               p[i]=k;
            }
        else
        {
            int ans;
            int st=1,dr=k;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(d[mij]>=a[i])
                {
                    ans=mij;
                    dr=mij-1;
                }
                else
                    st=mij+1;
            }
            d[ans]=a[i];
            p[i]=ans;
        }
    }
}

void reconstituire()
{
    g<<k<<'\n';
    int j=n;
    for(int i=k;i>=1;i--)
    {
        while(p[j]!=i)
            j--;
        d[i]=j;
    }
    for(int i=1;i<=k;i++)
        g<<a[d[i]]<<' ';
}

int main()
{
    citire();
    aflare();
    reconstituire();
    return 0;
}
