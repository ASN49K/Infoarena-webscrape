#include <fstream>

using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int v[100001],cap[100001],poz[100001],i,n,j,sirmax,pozmax,sol[100001],aux;
int main()
{
    f>>n;
    for(i=1;i<=n;i++){
        f>>v[i];
    }
    sirmax=0;
    for(i=1;i<=n;i++){
        j=1;
        while(v[i]>cap[j]&&cap[j]!=0){
            j++;
        }
        cap[j]=v[i];
        poz[i]=j;
        if(j>sirmax){
            sirmax=j;
            pozmax=i;
        }

    }
    i=pozmax;
    aux=sirmax;
    g<<sirmax<<endl;
    while(aux){
        if(poz[i]==aux){
            sol[aux]=v[i];
            aux--;
        }
        i--;
    }
    for(i=1;i<=sirmax;i++)
        g<<sol[i]<<" ";
    return 0;
}
