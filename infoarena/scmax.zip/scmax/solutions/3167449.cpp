#include <iostream>
#include <fstream>

using namespace std;
int n, sir[100005], lg[100005],maxim;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main()
{
    fin >> n;
    for (int i=1; i<=n; ++i) {
        fin >> sir[i];
    }
    for (int i=1; i<=n; ++i) {
        maxim=0;
        for (int j=1; j<=i; ++j) {
            if (sir[j]<sir[i] && lg[j]>maxim) {
                maxim=lg[j];
            }
        }
        lg[i]=maxim+1;
    }
    maxim=lg[1];
    for (int i=2; i<=n; ++i) {
        if (maxim<lg[i]) {
            maxim=lg[i];
        }
    }
    fout << maxim;
    return 0;
}
