#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int A[100001];
int B[100001];
int dp[100001];
int R[100001];
int INT_MAXX = 2147483647;
int caut_binar(int b[], int x, int st, int dr)
{
    if (st == dr)
        return st;
    int mijl = (st + dr) / 2;
    if (b[mijl] >= x)
        return caut_binar(b, x, st, mijl);
    return caut_binar(b, x, mijl + 1, dr);
}

int main()
{
    int n;
    fin >> n;
    ///creeaza un vector B cu valoarea maxima
    for (int i = 1; i <= n; i++)
        B[i] = INT_MAXX;
    ///citeste vectorul initial dat
    for (int i = 1; i <= n; i++)
    {
        fin >> A[i];
    }
    B[0] = 0;

    for (int i = 1; i <= n; i++)
    {
        int poz = caut_binar(B, A[i], 0, n);
        dp[i] = poz;
        B[poz] = A[i];
    }
    int lmax = 0;
    for (int i = 1; i <= n; i++)
    {
        lmax = max(lmax, dp[i]);
    }
    fout << lmax;
    int cop_lmax = lmax;
    
    for (int i = n; i >= 1; i--)
    {
        if (dp[i] == lmax)
        {
            R[lmax] = A[i];
            lmax--;
        }
    }
    fout << '\n';
    for (int i = 1; i <= cop_lmax; i++)
        fout << R[i] << " ";
        
    /*fout << '\n';
    for (int i = 1; i <= cop_lmax; i++)
        fout << B[i] << " ";
        */
    return 0;
}