#include <bits/stdc++.h>
using namespace std;

//aproapeperm
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int a[100005], dp[100005], ant[100005], lis[100005], top;

void Add(int i)
{
    int st, dr, mij, P;
    st = 1; dr = top; P = top + 1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (a[dp[mij]] >= a[i])
        {
            P = mij;
            dr = mij - 1;
        }
        else st =  mij + 1;
    }

    dp[P] = i;
    lis[P] = i;
    if (P > 1) ant[i] = lis[P - 1];
    if (P > top)top++;
}
void Afis()
{
    int i;
    stack<int> st;

    i = dp[top];
    while (i != 0)
    {
        st.push(a[i]);
        i = ant[i];
    }
    fout << top << "\n";
    while (!st.empty())
    {
        fout << st.top() << " ";
        st.pop();
    }
}

int main()
{
    int i;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    for (i = 1; i <= n; i++)
        Add(i);
    Afis();
    return 0;
}
