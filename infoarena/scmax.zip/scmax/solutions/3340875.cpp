/// patratele
#include <bits/stdc++.h>
using namespace std;

#define NMAX 100005

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int i, n, m, st, dr, x, poz, v[NMAX], vf, pz[NMAX], w[NMAX];
stack <int> q;

int main()
{
  // ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  fin >> n;
  for (i = 1; i <= n; i++)
  {
    fin >> x;
    w[i] = x;
    if (x > v[vf])
    {
      v[++vf] = x;
      pz[i] = vf;
    }
    else
    {
      st = 1;
      dr = vf;
      poz = -1;
      while (st <= dr)
      {
        m = (st + dr) / 2;
        if (v[m] >= x)
        {
          poz = m;
          dr = m - 1;
        }
        else
          st = m + 1;
      }
      v[poz] = x;
      pz[i] = poz;
    }
  }
  fout << vf << '\n';
  for (i = n; i >= 1; i--)
  {
    if (pz[i] == vf)
    {
      q.push(w[i]);
      vf--;
    }
  }
  while(!q.empty())
  {
    fout<<q.top()<<" ";
    q.pop();
  }
  return 0;
}
