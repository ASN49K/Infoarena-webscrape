#include <bits/stdc++.h> 
  
using namespace std; 
  
ifstream fin("scmax.in"); 
ofstream fout("scmax.out"); 

int n, x;
vector<int> v;
  
int main(){ 
// v[i] (i = 1 ...), ultimul element dintr-o subsecventa strict crescatoare de lungime i
// complexitate O(nlogn)
fin>>n;
for (int i = 1; i <= n; i++){
    fin>>x;
    // caut binar
    int st = 0;
    int dr = v.size() - 1;
    int p = -1;
    while(st <= dr){
        int mij = (st + dr) >> 1; // fac cu operatii pe biti pentru eficienta
        if (v[mij] < x){
            st = mij + 1;
            p = mij;
        }
        else
            dr = mij - 1;
    }
    if (p + 1 < v.size())
        v[p+1] = x;
    else
        v.push_back(x);
}
fout << v.size() << endl;
for (int i = 0; i < v.size(); i++){
    fout << v[i] << " "; 
}
    return 0; 
}