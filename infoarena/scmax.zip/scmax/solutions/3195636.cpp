#include <bits/stdc++.h>

using namespace std;
int v[100005],d[100005];
vector<int> lol;
int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n,a,ca=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>v[i]; d[i]=1;
        for(int j=0;j<i;j++)
        {
            if(v[j]<v[i])
                d[i]=max(d[i], d[j]+1);
        }
    }

    int maxx=d[0],save;
    for(int i=1;i<n;i++)
    {
        //cout<<d[i]<<" ";
        if(d[i]>maxx)
        {
            maxx=d[i];
            save=i;
        }
    }

    cout<<d[save]<<'\n';
    lol.push_back(v[save]);
    for(int i=save;i>=0;i--)
    {
        if(v[i]<v[save])
        {
            save=i;
            lol.push_back(v[i]);
        }
    }

    sort(lol.begin(), lol.end());

    for(auto x : lol)
        cout<<x<<" ";



    return 0;
}
