#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long

std::ifstream f("scmax.in");
std::ofstream g("scmax.out");

int n, lgbest, v[100007], best[100007], poz[100007], sol[100007], pozitie;
int cb(int x){
    int st = 0, dr = lgbest + 1, mij;
    while(dr - st > 1){
        mij = (st + dr) / 2;
        if(best[mij] <= x)
            st = mij;
        else dr = mij;
    }
    return dr;
}
int main(){
    std::ios_base::sync_with_stdio(false);
    f.tie(NULL);
    f >> n;
    for(int i = 1; i <= n; ++i)
        f >> v[i];
    best[1] = v[1];
    poz[1] = 1;
    lgbest = 1;
    for(int i = 2; i <= n; ++i){
        if(v[i] > best[lgbest])
            best[++lgbest] = v[i], poz[i] = lgbest;
        else {
            pozitie = cb(v[i]);
            best[pozitie] = v[i];
            poz[i] = pozitie;
        }
    }
    g << lgbest << '\n';
    for(int j = n, i = lgbest; i; --j)
        if(poz[j] == i){
            sol[i] = v[j]; --i;
        }
    for(int i = 1; i <= lgbest; ++i)
        g << sol[i] << ' ';
    return 0;
}
