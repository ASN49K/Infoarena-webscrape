#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100005], best[100005], ret[100005];

void afisare(int x)
{
    if(!ret[x])
        fout << v[x] << " ";
    else
    {
        afisare(ret[x]);
        fout << v[x] << " ";
    }
}
int main()
{
    int n, maxim = 1, poz = 1;
    fin >> n;
    for(int i = 1; i <= n; ++i)
    {
        fin >> v[i];
        best[i] = 1;
        for(int j = 1; j < i; j++)
        {
            if(v[j] < v[i] && best[i]<best[j]+1)
            {
                best[i] = best[j] + 1;
                ret[i] = j;
            }
        }
        if(best[i] > maxim)
        {
            maxim = best[i];
            poz = i;
        }
    }
    fout << best[poz] << "\n";
    afisare(poz);
    return 0;
}
