#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int pos[100001];
int a[100001];

void output(int currentPos) {
    if (pos[currentPos] == 0) {
        fout << a[currentPos] << ' ';
        return;
    }
    output(pos[currentPos]);
    fout << a[currentPos] << ' ';
}

int main() {
    int n;
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> a[i];
    }
    int maxLen[100001], ansLen = 0, lastPos = 0;
    for (int i = 1; i <= n; ++i) {
        maxLen[i] = 1;
        for (int j = i - 1; j >= 1; --j) {
            if (a[i] > a[j] && maxLen[i] < maxLen[j] + 1) {
                pos[i] = j;
                maxLen[i] = maxLen[j] + 1;
                if (ansLen < maxLen[i]) {
                    lastPos = i;
                    ansLen = maxLen[i];
                }
            }
        }
    }
    fout << ansLen << '\n';
    output(lastPos);
    return 0;
}
