#include <bits/stdc++.h>

#define N_MAX 100005

using namespace std;

ifstream fin("scmax.in");

ofstream fout("scmax.out");

int best[N_MAX], constr[N_MAX];

int n, v[N_MAX], maxi, poz;

int main()
{
    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        fin >> v[i];
    }
    best[n] = 1;
    constr[n] = -1;
    for (int i = n - 1; i >= 1; i--)
    {
        for (int j = i + 1; j <= n; j++)
        {
            if (v[j] > v[i] && best[i] < best[j] + 1)
            {
                best[i] = best[j] + 1;
                constr[i] = j;
                if (best[i] > maxi)
                    maxi = best[i], poz = i;
            }
        }
    }
    fout << maxi << '\n';
    while (poz != -1)
    {
        fout << v[poz]<<" ";
        poz = constr[poz];
    }
}