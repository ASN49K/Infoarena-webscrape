#include <bits/stdc++.h>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int n, k;
int v[100001];
int d[100001];
int p[100001];

int bs ( int x )
{
    int st = 1, dr = k, sol = k + 1;
    while ( st <= dr )
    {
        int mij = ( st + dr ) / 2;
        if ( d[mij] >= x )
        {
            dr = mij - 1;
            sol = mij;
        }
        else st = mij + 1;
    }
    return sol;
}

void afisare ( int i, int lmax )
{
    if ( i == 0 )
        return;
    if ( p[i] == lmax )
    {
        afisare ( i - 1, lmax - 1 );
        g << v[i] << " ";
    }
    else afisare ( i - 1, lmax );
}

int main()
{
    int lmax = 1;
    f >> n;
    f >> v[1];
    k = 1;
    d[1] = v[1];
    p[1] = 1;
    d[0] = 0;
    for ( int i = 2; i <= n; i ++ )
    {
        f >> v[i];
        k = bs ( v[i] );
        p[i] = k;
        d[k] = v[i];
        lmax = max ( lmax, k );
    }
    g << lmax << '\n';
    afisare( n, lmax );
    return 0;
}
