use std::fs::{self,File};
use std::io::{BufWriter,Write};

macro_rules! parse_line {
    ($iter: expr, $($t: ty),+) => {{
        let line = $iter.next().unwrap();
        let mut parts = line.split_whitespace();
        ($(parts.next().unwrap().parse::<$t>().unwrap()), +)
    }};
}
macro_rules! parse_vector {
    ($iter: expr, $t: ty) => {{
        $iter
            .next()
            .unwrap()
            .split_whitespace()
            .map(|x| x.parse::<$t>().unwrap())
            .collect::<Vec<$t>>()
    }};
}
fn main() ->std::io::Result<()>{
    let content = fs::read_to_string("scmax.in")?;
    let mut lines = content.lines();
    let mut writer = BufWriter::new(File::create("scmax.out")?);
    let n = parse_line!(lines, usize);
    let mut vect = parse_vector!(lines, usize);
    vect.push(usize::MAX);
    let mut from : Vec<usize> = vec![0; n+1];
    let mut high : Vec<usize> = vec![n; n+1];
    let mut answ = 1;
    high[1]=0;// indexul elementului care da index 1
    for i in 1..n {
        let mut st = 1;
        let mut dr: i32  = answ + 1;//caut cel mai mic index care imi da o valoare mai mare
        let mut mij;
        let mut poz =1;
        while st <= dr {
            mij = (st + dr)/2;
            if vect[i] <= vect[high[mij as usize]] {
                poz = mij;
                dr = mij - 1;
            }
            else {
                st = mij + 1;
            }
        }
        high[poz as usize] = i;
        eprintln!("{} {}", poz, high[poz as usize]);
        from[i] = high[poz as usize -1 ];
        answ = std::cmp::max(answ, poz );
    }
    writeln!(writer,"{}",answ)?;
    let mut elements = Vec::new();
    let mut cur = high[answ as usize];
    for _ in 0..answ {  
        elements.push(vect[cur]);
        cur = from[cur];
    }
    elements.reverse();
    for elem in elements {
        write!(writer,"{} ",elem)?;
    }
    Ok(())
}
