#include <fstream>
#include <vector>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

int v[100005];
int f[100005];
int tr[100005];
int cap[100005];
int pz[100005];

vector <int> rez;

int main()
{
    int n, mx=0, cj, mxx=0, poz;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
    }
    for(int i=1; i<=n; i++)
    {
        cj=mx=0;
        for(int j=mxx; j>=1; j--)
        {
            if(cap[j]<v[i])
            {
                cj=pz[j];
                mx=j;
                break;
            }
        }
        tr[i]=cj;
        f[i]=mx+1;
        if(cap[f[i]]==0 || cap[f[i]]>v[i])
        {
            cap[f[i]]=v[i];
            pz[f[i]]=i;
        }
        if(f[i]>mxx)
        {
            poz=i;
            mxx=f[i];
        }
    }
    cout<<mxx<<'\n';
    while(poz>0)
    {
        rez.push_back(v[poz]);
        poz=tr[poz];
    }
    for(int i=rez.size()-1; i>=0; i--)
    {
        cout<<rez[i]<<" ";
    }


    return 0;
}
