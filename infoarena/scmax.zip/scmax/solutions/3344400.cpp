#include <fstream>
#include <vector>
#define NMAX 100002
using namespace std;
ifstream  fin("scmax.in");
ofstream fout("scmax.out");
int N,M,a[NMAX],dp[NMAX],best[NMAX],pred[NMAX];
vector<int>sol;

void citire()
{
    fin>>N;

    for(int i=1; i<=N; i++)
    {
        fin>>a[i];
    }
}

int main()
{
    citire();

    int lmax,poz;
    lmax=poz=0;

    M=0;
    for(int i=1; i<=N; i++)
    {
        if(a[i]>a[best[M]])
        {
            M++;
            best[M]=i;
            dp[i]=M;
            pred[i]=best[M-1];
        }
        else
        {
            int p1,p2,pmijl,ans;
            p1=1;
            p2=M;
            ans=0;

            while(p1<=p2)
            {
                pmijl=(p1+p2)/2;

                if(a[best[pmijl]]>=a[i])
                {
                    ans=pmijl;
                    p2=pmijl-1;
                }
                else
                {
                    p1=pmijl+1;
                }
            }

            best[ans]=i;
            dp[i]=ans;
            pred[i]=best[ans-1];
        }

        if(dp[i]>lmax)
        {
            lmax=dp[i];
            poz=i;
        }
    }

    fout<< lmax << "\n";

    while(poz)
    {
        sol.push_back(a[poz]);
        poz=pred[poz];
    }


    for(int i=sol.size()-1; i>=0; i--)
    {
        fout<< sol[i] << " ";
    }

    return 0;
}
