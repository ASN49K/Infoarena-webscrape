#include <bits/stdc++.h>
using namespace std;
using llx = long long;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

vector<int> a, dp, par, sol;

int main()
{
    int n, i, j, i_rasp;

    fin >> n;
    a.resize(n+1);
    dp.assign(n+1, 1), par.assign(n+1, -1);
    for (i = 1; i<=n; i++)
        fin >> a[i];

    for (i = 2; i<=n; i++)
        for (j = 1; j<i; j++)
            if (a[j] < a[i] && dp[j]+1 > dp[i])
            {
                dp[i] = dp[j]+1;
                par[i] = j;
            }
    
    i_rasp = 1;
    for (i = 2; i<=n; i++)
        if (dp[i] > dp[i_rasp])
            i_rasp = i;

    for (i = i_rasp; i != -1; i = par[i])
        sol.push_back(i);
    reverse(sol.begin(), sol.end());
    fout << sol.size() << '\n';
    for (const auto &el : sol)
        fout << a[el] << ' ';
    return 0;
}