
#include <bits/stdc++.h>
using namespace std;
int v[100005], dp[100005];
 int dr=0;
int main() {
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n;
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>v[i];
    for(int i=1; i<=n; i++)
        {
        int st=1,dr2=dr;
        if(dr==0)
        {
            dp[1]=v[i];
            dr++;
        }
        else
        {

            while(st<dr2)
            {
                int mij=(st+dr2)/2;
                if(dp[mij]>=v[i])
                {
                    dr2=mij-1;
                }
                else
                    st=mij+1;
            }
            if(dp[st]<v[i])
            {
                if(dp[st+1]==0)
                {
                    dp[st+1]=v[i];
                    dr++;
                }
                else if(dp[st+1]>v[i])
                    dp[st+1]=v[i];
            }
            else if(dp[st]>v[i])
            {
                dp[st]=v[i];
            }
        }
    }
    for(int i=1;i<=n;i++)
        cout<<dp[i]<<" ";
   int maxm=0;
   for(int i=1;i<=n;i++)
   {
       if(dp[i]!=0)
        maxm=i;
   }
   cout<<maxm;
    return 0;
}
