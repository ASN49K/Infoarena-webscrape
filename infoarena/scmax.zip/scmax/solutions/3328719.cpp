#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, v[100001], pred[100001];
vector<int> LIS;

void afis(int i)
{
    if (i == 0)
        return;

    afis(pred[i]);

    fout << v[i] << " ";
}
int CB(int lf, int rg, int val)
{
    if (lf > rg)
        return 100002;

    int mid = (lf + rg) / 2;

    if (v[LIS[mid]] >= val)
        return min(mid, CB(lf, mid - 1, val));

    else
        return CB(mid + 1, rg, val);
}
int main()
{
    fin >> n;

    for (int i = 1; i <= n; i++)
        fin >> v[i];

    for (int i = 1; i <= n; i++)
    {
        //cout << i << " ";
        int p = CB(0, LIS.size() - 1, v[i]);
       // cout << p << " ";
        if (p != 100002)
        {
            if (p != 0)
                pred[i] = LIS[p - 1];
            LIS[p] = i;
        }
        else
        {
            if (LIS.size() != 0)
                pred[i] = LIS.back();

            LIS.push_back(i);
        }
    }

    fout << LIS.size() << "\n";

    afis(LIS.back());

    return 0;
}