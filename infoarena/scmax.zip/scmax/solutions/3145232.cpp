#include <bits/stdc++.h>
#define ub(x) (x & -x)

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, i, j, a[100007], l[100007], r[100007], rasp;
int aib[100007], u[100007], d[100007], k = 1;

static inline int update(int poz, int val) {
    for(int i = poz; i <= n; i += ub(i)) {
        if(d[val] > d[aib[i]]) aib[i] = val;
    }
}

static inline int query(int poz) {
    int m = 0;
    for(int i = poz; i > 0; i -= ub(i)) {
        if(d[aib[i]] > d[m]) m = aib[i];
    }
    return m;
}

int main() {
    fin >> n;
    for(i = 1; i <= n; i++) {
        fin >> a[i];
        r[i] = l[i] = a[i];
    }
    sort(l + 1, l + n + 1);
    for(i = 2; i <= n; i++) {
        if(l[i] != l[k]) l[++k] = l[i];
    }
    for(i = 1; i <= n; i++) a[i] = lower_bound(l + 1, l + k + 1, a[i]) - l;
    for(i = 1; i <= n; i++) {
        u[i] = query(a[i] - 1);
        d[i] = d[u[i]] + 1;
        update(a[i], i);
    }
    for(i = 1; i <= n; i++) {
        if(d[rasp] < d[i]) rasp = i;
    }
    fout << d[rasp] << "\n";
    k = 0;
    i = rasp;
    while(i) {
        l[++k] = r[i];
        i = u[i];
    }
    for(i = k; i > 0; i--) fout << l[i] << " ";

    return 0;
}
