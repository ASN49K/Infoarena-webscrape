#include <fstream>
#include <iostream>
#include <stack>

constexpr int nmax = 100001;

std::ifstream in("scmax.in");
std::ofstream out("scmax.out");

int a[nmax], b[nmax], p[nmax];

int main() {
  int n, x, cnt = 0;
  in >> n >> x;
  a[1] = x;
  p[1] = 1;
  b[++cnt] = 1;

  for (int i = 2; i <= n; ++i) {
    in >> x;
    a[i] = x;
    p[i] = i;
    int st = 1, dr = cnt, poz = -1;
    while (st <= dr) {
      int mij = (st + dr) / 2;
      if (a[b[mij]] >= x)
        dr = mij - 1, poz = mij;
      else
        st = mij + 1;
    }
    if (poz == -1) {
      b[++cnt] = i;
      p[i] = b[cnt - 1];
    } else {
      b[poz] = i;
      if (poz > 1)
        p[i] = b[poz - 1];
    }
  }
  out << cnt << "\n";
  int pp = b[cnt];
  std::stack<int> r;
  while (pp != p[pp]) {
    r.emplace(a[pp]);
    pp = p[pp];
  }
  r.emplace(a[pp]);
  while (!r.empty())
    out << r.top() << " ", r.pop();
  return 0;
}
