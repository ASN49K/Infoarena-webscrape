#include <fstream>
using namespace std;

ifstream fin("dijkstra.in");
ofstream fout("dijkstra.out");

#define NMAX 100005

int v[NMAX];
int dp[NMAX];
int urm[NMAX];

int main() {
    int n;
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
    }

    dp[n] = 1;
    urm[n] = -1;
    for (int i = n - 1; i >= 1; --i) {
        int maxim = 0;
        int poz = -1;
        for (int j = i + 1; j <= n; ++j) {
            if (v[i] < v[j] && dp[j] > maxim) {
                maxim = dp[j];
                poz = j;
            }
        }
        dp[i] = maxim + 1;
        urm[i] = poz;
    }

    int poz_max = 1;
    for (int i = 2; i <= n; ++i) {
        if (dp[i] > dp[poz_max]) {
            poz_max = i;
        }
    }

    fout << dp[poz_max] << '\n';
    for (int i = poz_max; i != -1; i = urm[i]) {
        fout << v[i] << ' ';
    }
    return 0;
}
