#include <fstream>
#define nmax 100000

using namespace std;

int n,v[nmax],d[nmax],maxLength=0,inc,sf;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

int main() {
	fin>>n;
    for (int i=0; i<n; ++i) {
        fin>>v[i];
    }
    for (int i = 0; i < n; ++i) {
        d[i] = 1;
        for (int j = 0; j <i; ++j)
            if (v[j] < v[i])
			{
                d[i] = max(d[i], d[j] + 1);
			}
    }
    maxLength = d[0];
    for (int i = 0; i < n; ++i)
	{
		if(d[i]>maxLength)
		{
			maxLength=d[i];
			sf=i;
			inc=i-maxLength;
		}
	}
	fout<<maxLength<<'\n';
	for (int i=inc+1;i<=sf;i++)
	{
		if(v[i]<v[i-1])
			fout<<v[i]<<' ';
	}

    return 0;
}
