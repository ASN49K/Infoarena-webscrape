#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100005], dp[100005], len=0, a[100005], sol[100005];

int main()
{
    int n, idx=0;
    fin >> n;
    for(int i=1; i<=n; i++) {
        fin >> v[i];
    }
    for(int i=1; i<=n; i++) {
        if(v[i]>dp[len]) {
            len++;
            dp[len]=v[i];
            a[i]=len;
        } else {
            auto x=lower_bound(dp+1, dp+len+1, v[i]);
            dp[x-dp]=v[i];
            a[i]=x-dp;
        }
    }
    fout << len << "\n";
    for(int i=n; i>=1; i--) {
        if(a[i]==len) {
            sol[idx]=v[i];
            idx++;
            len--;
        }
    }
    for(int i=idx-1; i>=0; i--) {
        fout << sol[i] << " ";
    }
    /*for(int i=1; i<=n; i++) {
        fout << dp[i] << " ";
    }
    fout << "\n";
    for(int i=1; i<=n; i++) {
        fout << a[i] << " ";
    }*/
    return 0;
}
