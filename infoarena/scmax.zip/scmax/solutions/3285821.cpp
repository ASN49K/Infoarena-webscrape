#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX = 100005;

vector <int> sol, poz;

int a[NMAX];

void solve(){
    int n, x;
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> x;
        a[i] = x;
        vector <int>::iterator it = upper_bound(sol.begin(), sol.end(), x);
        int idx = int(it - sol.begin());
        if(it == sol.end()){
            sol.push_back(x);
        }
        else{
            sol[idx] = x;
        }
        poz.push_back(idx);
    }
    int l = sol.size() - 1;
    int i = n - 1;
    vector <int> rez;
    while(l >= 0){
        if(poz[i] == l){
            rez.push_back(a[i + 1]);
            l --;
        }
        i --;
    }
    reverse(rez.begin(), rez.end());
    int cnt = 0;
    vector <int> finrez;
    for(int i = 0; i < rez.size(); ++i){
        if(i == 0 or (i != 0 && rez[i - 1] != rez[i])){
            finrez.push_back(rez[i]);
            cnt ++;
        }
    }
    fout << cnt << "\n";
    for(int i = 0; i < cnt; ++i){
        fout << finrez[i] << " ";
    }
}

int main()
{
    solve();
    return 0;
}
