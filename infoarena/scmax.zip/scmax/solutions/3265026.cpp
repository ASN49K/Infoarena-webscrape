#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100000;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int v[NMAX+1];
int dp[NMAX+1], cnt;
int pos[NMAX+1];

int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        fin >> v[i];
    for(int i=1; i<=n; i++)
    {
        int ind = lower_bound(dp+1, dp+1+cnt, v[i]) - dp;
        if(v[i] > dp[cnt])
            dp[++cnt] = v[i], pos[i] = cnt;
        else
            dp[ind] = v[i], pos[i] = ind; 
    }
    fout << cnt << '\n';
    vector <int> ans;
    for(int i=n; i>=1; i--)
    {
        if(pos[i] == cnt)
            ans.push_back(v[i]), cnt--; 
    }
    int sz = ans.size();
    for(int i=sz-1; i>=0; i--)
        fout << ans[i] << ' ';
    return 0;
}