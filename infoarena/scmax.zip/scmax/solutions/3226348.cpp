#include <bits/stdc++.h>

using namespace std;

ifstream in ("scmax.in");
ofstream out ("scmax.out");

const int NMAX = 2e5 + 5;

int n;

int v[NMAX];

int dp[NMAX];
int t[NMAX];
int l[NMAX];

int head;

int maxi;
int ind;

void inapoi(int ind)
{
    if(t[ind])
    {
        inapoi(t[ind]);
    }
    out << v[ind] << " ";
}

int cautbin(int val)
{
    int st = 1;
    int dr = head;
    int ret;
    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(val <= v[l[mij]])
        {
            dr = mij - 1;
        }
        else
        {
            st = mij + 1;
            ret = mij;
        }
    }
    return ret;
}

int main()
{

    in >> n;

    for(int i = 1; i <= n; i ++)
    {
        in >> v[i];
    }

    dp[1] = 1;
    l[++head] = 1;

    for(int i = 2; i <= n; i ++)
    {
        int poz = cautbin(v[i]);
        if(poz == head)
        {
            head ++;
        }
        l[poz + 1] = i;
        dp[i] = poz + 1;
        t[i] = l[poz];
    }

    for(int i = 1; i <= n; i ++)
    {
        if(dp[i] > maxi)
        {
            ind = i;
            maxi = dp[i];
        }
    }

    out << dp[ind] << '\n';

    inapoi(ind);


    return 0;
}
