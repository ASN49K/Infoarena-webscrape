#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int MAX_LENGTH = 100000;
const int MAX_VALUE = 2000000000;

//int minValue[MAX_LENGTH + 1];
int maxSubsequenceLen[MAX_LENGTH + 1];
int maxLen;
int lastPos;
int nums[MAX_LENGTH + 1];
int pos[MAX_LENGTH + 1];

pair<int, int> minValue[MAX_LENGTH + 1];

void output(int lastPos) {
    if (pos[lastPos] == 0) {
        fout << nums[lastPos] << ' ';
        return;
    }
    output(pos[lastPos]);
    fout << nums[lastPos] << ' ';
}

int main() {
    int numLen;
    fin >> numLen;
    for (int i = 1; i <= numLen; ++i) {
        fin >> nums[i];
        minValue[i] = {MAX_VALUE + 1, i};
    }
   // fout << minValue[1].first << ' ' << minValue[1].second;
    for (int i = 1; i <= numLen; ++i) {
        for (int j = maxLen; j >= 0; --j) {
            if (minValue[j].first < nums[i]) {
                if (nums[i] < minValue[j + 1].first) {
                    minValue[j + 1] = {nums[i], i};
                }
                pos[i] = minValue[j].second;
                maxSubsequenceLen[i] = j + 1;
                if (maxSubsequenceLen[i] > maxLen) {
                    maxLen = maxSubsequenceLen[i];
                    lastPos = i;
                }
                break;
            }
        }
    }
    fout << maxLen << '\n';
    output(lastPos);
    return 0;
}
