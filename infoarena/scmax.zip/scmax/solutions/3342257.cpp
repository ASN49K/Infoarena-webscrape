#include<iostream>
#include<fstream>
using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int n,pozmax;
int v[1001];
int lung[1001],poz[1001];
int main()
{
    f>>n;
    for(int i=1;i<=n;i++) f>>v[i];
    lung[n]=1;
    poz[n]=-1;
    for(int i=n-1;i>0;i--)
    {
        lung[i]=1;
        poz[i]=-1;
        for(int j=i+1;j<=n;j++)
        {
            if (v[i]<v[j]&&lung[i]<1+lung[j])
            {
                lung[i]=1+lung[j];
                poz[i]=j;
            }
        }
    }
    int mx=1;
    pozmax=1;
    for(int i=2;i<=n;i++)
    {
        if(lung[i]>mx)
        {
            mx=lung[i];
            pozmax=i;
        }
    }
    g<<mx<<'\n';
    while(pozmax>0)
    {
        g<<v[pozmax]<<" ";
        pozmax=poz[pozmax];
    }
    f.close();
    g.close();
    return 0;
}
