#include <iostream>
#include <fstream>
#include <stack>
using namespace std;

const int N = 1e5 + 5;
int v[N], dp[N], n, sol,id;
int rec[N];
stack<int> s;

int main()
{
	int i, j, x,mx;
	ifstream fin("scmax.in");
	fin >> n;
	for (i = 1; i <= n; i++)fin >> v[i];
	fin.close();
	dp[1] = 1;
	for (i = 2; i <= n; i++) {
		mx = 0;
		for (j = i - 1; j > 0; j--) {
			if (dp[j] > mx&&v[j]<v[i]) {
				mx = dp[j];
				rec[i] = j;
			}
		}
		dp[i] = mx+1;
		if (mx > sol) {
			sol = mx;
			id = i;
		}
	}
	while (id)s.push(id), id = rec[id];
	ofstream fout("scmax.out");
	fout << sol+1 << '\n';
	while (!s.empty())fout << v[s.top()] << ' ', s.pop();
	fout.close();
	return 0;
}