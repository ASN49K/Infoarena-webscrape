#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
pair<int,int>a[100001];
struct nod
{
    int best,idx;
}aint[400001];
nod combine(nod x,nod y)
{
    if(x.best>y.best)
        return x;
    if(y.best>x.best)
        return y;
    if(a[x.idx]<a[y.idx])
        return x;
    return y;
}
void update(int v,int st,int dr,int pos,int best,int idx)
{
    if(st==dr)
        aint[v]={best,idx};
    else
    {
        int mid=(st+dr)/2;
        if(pos<=mid)
            update(v*2,st,mid,pos,best,idx);
        else update(v*2+1,mid+1,dr,pos,best,idx);
        aint[v]=combine(aint[v*2],aint[v*2+1]);
    }
}
nod res;
void query(int v,int st,int dr,int qst,int qdr)
{
    if(qst<=st && qdr>=dr)
        res=combine(res,aint[v]);
    else
    {
        int mid=(st+dr)/2;
        if(qst<=mid)
            query(v*2,st,mid,qst,qdr);
        if(qdr>mid)
            query(v*2+1,mid+1,dr,qst,qdr);
    }
}
int bt[100001];
int main()
{
    int n,maxi=0;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a[i].first;
        a[i].second=i;
    }
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++)
    {
        res={0,0};
        query(1,1,n,1,a[i].second);
        if(a[res.idx].first==a[i].first)
            res.best--;
        bt[i]=res.idx;
        maxi=max(maxi,res.best+1);
        update(1,1,n,a[i].second,res.best+1,i);
    }
    fout<<maxi<<'\n';
    res={0,0};
    query(1,1,n,1,n);
    int index=res.idx,ant;
    vector<int>r;
    for(int i=1;i<=maxi;i++)
    {
        r.push_back(a[index].first);
        while(a[index].first==a[bt[index]].first)
            index=bt[index];
        index=bt[index];
    }
    reverse(r.begin(),r.end());
    for(int i=0;i<r.size();i++)
        fout<<r[i]<<' ';
    return 0;
}
