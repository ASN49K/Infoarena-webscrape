#include <bits/stdc++.h>
#pragma GCC optimize("03")
#define lastbit( x ) ( x & -x )
const int NMAX = 1e7;
using namespace std;

int n, i, j, a [ NMAX ], l [ NMAX ], r [ NMAX ], rasp;
int aib [ NMAX ], u [ NMAX ], d [ NMAX ], k = 1;

inline void update ( int poz, int val )
{
    for ( int i = poz; i <= n; i += lastbit( i ) ) 
    {
        if ( d [ val ] > d [ aib [ i ] ] ) aib [ i ] = val;
    }
}

inline int query ( int poz )
{
    int m = 0;
    for ( int i = poz; i > 0; i -= lastbit( i ) )
    {
        if ( d [ aib [ i ] ] > d [ m ] ) m = aib [ i ];
    }
    return m;
}

int main() 
{
	( void )! freopen ( "scmax.in", "r", stdin );
	( void )! freopen ( "scmax.out", "w", stdout );
	ios_base::sync_with_stdio ( false );
    cin.tie ( NULL );
    cin >> n;
    for ( i = 1 ; i <= n ; ++ i ) 
    {
        cin >> a [ i ];
        r [ i ] = l [ i ] = a [ i ];
    }
    sort ( l + 1, l + n + 1 );
    for ( i = 2 ; i <= n ; ++ i ) 
    {
        if ( l [ i ] != l [ k ] ) l [ ++ k ] = l [ i ];
    }
    for ( i = 1 ; i <= n ; ++ i ) a [ i ] = lower_bound ( l + 1, l + k + 1, a [ i ] ) - l;
    for ( i = 1 ; i <= n ; ++ i ) 
    {
        u [ i ] = query ( a [ i ] - 1 );
        d [ i ] = d [ u [ i ] ] + 1;
        update ( a [ i ], i );
    }
    for ( i = 1 ; i <= n ; ++ i ) 
    {
        if ( d [ rasp ] < d [ i ] ) rasp = i;
    }
    cout << d[rasp] << '\n';
    k = 0;
    i = rasp;
    while ( i )
    {
        l [ ++ k ] = r [ i ];
        i = u [ i ];
    }
    for ( i = k ; i > 0 ; -- i ) cout << l [ i ] << ' ';

    return 0;
}