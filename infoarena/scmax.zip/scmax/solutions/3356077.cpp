#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
int mx[100001];
int v[100001];
int a[100001];
int main()
{
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    int n, i, j, poz;
    fin>>n;
   // mx[0]=2000000;
    for(i=1;i<=n;i++){
        fin>>v[i];
        mx[i]=2000000;
    }
    for(i=1;i<=n;i++){
        poz=lower_bound(mx,mx+n+1,v[i])-mx-1;
       // cout<<mx[poz]<<' ';
        if(mx[poz+1]==2000000){
            mx[poz+1]=v[i];
            a[poz+1]=v[i];
        }
        else{
            //mx[poz+1]=min(v[i],mx[poz+1]);
            if(mx[poz+1]>v[i]){
                mx[poz+1]=v[i];
                a[poz+1]=v[i];
            }
            //a[poz+1]=v[i];
        }
    }
    for(i=n;i>=0;i--){
        if(mx[i]!=2000000){
            poz=i;
            fout<<i<<'\n';
            break;
        }
    }
    for(i=1;i<=poz;i++){
        fout<<a[i]<<' ';
    }
    return 0;
}
