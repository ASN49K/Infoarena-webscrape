#include <fstream>
#include<bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int NMAX=1e5;
int v[NMAX+5];
vector<int>sol;
vector<int>ans;
int parent[NMAX+5];
int pos[NMAX+5];
int cautbin(int val,vector<int>& a)
{
    int gasit=a.size();
    int st=0;
    int dr=a.size()-1;
    while(st<=dr)
    {
        int mij=st+((dr-st)>>1);
        if(a[mij]>=val){dr=mij-1;gasit=mij;}
        else st=mij+1;
    }

    return gasit;
}
int main()
{
    int n;
    fin>>n;

    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    sol.push_back(v[1]);
    for(int i=2;i<=n;i++)
    {
        int p=cautbin(v[i],sol);
        if(p==sol.size())
        {
            sol.push_back(v[i]);
        }
        else
        {
            sol[p]=v[i];
        }
        pos[p]=i;
        parent[i]=(p>0?pos[p-1]:0);

    }
    fout<<sol.size()<<"\n";
    int k=pos[sol.size()-1];
    while(k)
    {
        ans.push_back(v[k]);
        k=parent[k];
    }
    reverse(ans.begin(),ans.end());
    for(auto x:ans)
    {
        fout<<x<<" ";
    }
    return 0;
}
