#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, i, j, best[100005], x, a[100005], st, dr, k, l, poz, p[100005], v[100005];
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>a[i];
    best[1]=a[1];
    k=1;
    for(i=2; i<=n; i++)
    {
        if(a[i]>best[k])
        {
            best[++k]=a[i];
            p[i]=k;
        }
        else
        {
            int st=1, dr=k, poz=-1;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(best[mij]>=a[i])
                {
                    poz=mij;
                    dr=mij-1;
                }
                else
                    st=mij+1;
            }
            if(poz!=-1)
            {
                best[poz]=a[i];
                p[i]=poz;
            }
        }
    }
    fout<<k<<'\n';
    int ck=k;
    for(i=n; i>=1; i--)
    {
        if(p[i]==k)
        {
            v[k]=a[i];
            k--;
        }
    }
    for(i=1; i<=ck; i++)
        fout<<v[i]<<" ";
    return 0;
}
