#include <bits/stdc++.h>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

const int nmax = 1e5 + 5;
int n, a[nmax], dp[nmax], j, idx[nmax];

vector <int> v;

int cb(int x)
{
    int st = 1, dr = j, rez = j+1;
    while (st <= dr)
    {
        int mij = (st + dr) / 2;
        if (x <= dp[mij])
        {
            rez = mij;
            dr = mij - 1;
        } else st = mij + 1;
    }

    return rez;
}

void compute_dp()
{
    dp[1] = a[1];
    idx[1]=1;

    j = 1;
    for (int i = 2; i <= n; i++)
    {
        if (a[i] > dp[j])
        {
            dp[++j] = a[i];
            idx[i] = j;
        }
        else
        {
            int x=cb(a[i]);
            dp[x] = a[i];
            idx[i] = x;
        }
    }
}

int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        f >> a[i];

    compute_dp();
    g << j << '\n';

    for (int i=n; i>=1; i-- )
    {
        if ( idx[i]==j )
        {
            v.push_back(a[i]);
            j--;
        }
    }

    reverse(v.begin(), v.end());

    for (int x:v )
        g << x << " ";
    return 0;
}