#include <bits/stdc++.h>

using namespace std;

ifstream f ("scmax.in");
ofstream g ("scmax.out");

const int NMAX = 1e5;
const int VALMAX = 2e9 + 1e4;

int n;
int v[NMAX + 1];
int best[NMAX + 1], last[NMAX + 1];

int cb(int val){
    
    int rez = 0;
    int st = 1;
    int dr = n;
    
    while(st <= dr){
        
        int mij = (st + dr) / 2;
        if(best[mij] != VALMAX and val > v[best[mij]])
            rez = mij, st = mij + 1;
            
        else dr = mij - 1;
        
    }
    
    return rez;
    
}

int main()
{
    
    f >> n;
    for(int i=1; i<=n; i++)
        f >> v[i];
        
    for(int i=1; i<=NMAX; i++)
        best[i] = VALMAX;
        
    for(int i=1; i<=n; i++){
        
        int poz = cb(v[i]);
        best[poz + 1] = i;
        last[i] = best[poz];
        
        
    }
    
    int cnt = 0;
    int ult = 0;
    for(int i=1; i<=n and best[i] != VALMAX; i++)
        cnt ++, ult = best[i];
        
        
    g << cnt << "\n";
    
   // cout << v[ult] << " ";
    
    //g << v[last[ult]] << ' ' << v[last[last[ult]]] << ' ' << v[last[last[last[ult]]]];
    
    vector<int> rez;
    
    while(ult){
        
        //cout << v[ult] << " ";
        rez.push_back(v[ult]);
        ult = last[ult];
        
    }
    
    reverse(rez.begin(), rez.end());
    
    for(int val : rez)
        g << val << ' ';
    
    return 0;
}