#include <fstream>
using namespace std;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");
int n,i,j,V[100001],D[100001],t[100001],mid,L,st,dr;
void T(int x)
{
    if(t[x])
        T(t[x]);
    fout<<V[x]<<" ";
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>V[i];
    L=1;
    D[1]=1;
    for(i=2;i<=n;i++)
    {
        st=1;
        dr=L;
        while(st<=dr)
        {
            mid=(st+dr)/2;
            if(V[D[mid]]>=V[i])
                dr=mid-1;
            else
                st=mid+1;
        }
        if(st>L)
        {
            D[++L]=i;
            t[i]=D[L-1];
        }
        else
        {
            D[st]=i;
            t[i]=D[st-1];
        }
    }
    fout<<L<<"\n";
    T(D[L]);
    return 0;
}
