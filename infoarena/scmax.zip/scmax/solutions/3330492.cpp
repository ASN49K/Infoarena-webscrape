#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main()
{
    int a[100003], b[100003], c[100003];
    int n, i, j, max, p;
    fin >> n;
    max=1; p=n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    b[n]=1;
    c[n]=-1;
    for (i=n-1; i>=1; i--)
    {
        b[i]=1;
        c[i]=-1;
        for (j=i+1; j<=n; j++)
            if (a[i]<a[j] && b[i]<b[j]+1)
            {
                b[i]=b[j]+1;
                c[i]=j;
                if (b[i]>max)
                {
                    max=b[i];
                    p=i;
                }
            }
    }
    fout << max << "\n";
    i=p;
    while (i!=-1)
    {
        fout << a[i] << " ";
        i=c[i];
    }
}

