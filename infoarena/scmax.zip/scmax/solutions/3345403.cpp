#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main() {
    ifstream in;
    ofstream out;
    in.open("scmax.in");
    out.open("scmax.out");
    vector<int> v;
    int n;
    in >> n;
    for (int i = 0; i < n; i++) {
        int x;
        in >> x;
        v.push_back(x);
    }
    vector<int> dp(n, 0);
    vector<int> prev(n, 0);
    dp[0] = 1;
    prev[0] = 0;
    for (int i = 1; i < n; i++) {
        int maxi = 0;
        for (int j = 0; j < i; j++) {
            if (v[j] < v[i] && dp[j] > maxi)
                maxi = dp[j], prev[i] = j;
        }
        dp[i] = 1 + maxi;
    }
    out << dp[n - 1] << "\n";
    vector<int> res(n, 0);
    // res[n - 1] = prev[n - 1];
    for (int i = n - 1; i > 0; i = prev[i]) {
        res[i] = v[i];
    }
    for (int i = 0; i < n; i++) {
        if (res[i])
            out << res[i] << " ";
    }
}