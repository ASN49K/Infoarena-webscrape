#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX = 100001;
int n, v[NMAX];
vector<int> sol;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++) fin >> v[i];
    sol.push_back(v[1]);
    for(int i = 2; i <= n; i++){
        int x = v[i];
        if(x > sol.back()) sol.push_back(x);
        else{
            int poz = upper_bound(sol.begin(), sol.end(), x) - sol.begin();
            sol[poz] = x;
        }
    }
    fout << sol.size() << '\n';
    for(int i = 0; i < sol.size(); i++) fout << sol[i] << ' ';
    return 0;
}
