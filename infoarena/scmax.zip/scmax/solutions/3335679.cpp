#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("ssm.in");
ofstream fout ("ssm.out");
int v[6000001];
int main()
{
    int n,sm=0,pi,pf;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i];
    }
    for(int i=1;i<=n;i++)
    {
        int S=0;
        for(int ii=i;ii<=n;ii++)
        {
            S=S+v[ii];
            if(S>sm)
            {
                pi=i;
                pf=ii;
                sm=S;
            }
        }
    }
    fout <<sm<<" "<<pi<<" "<<pf;
    return 0;
}
