#include <iostream>
#include <fstream>
#define nmx 100005
using namespace std;
int v[nmx],haz[nmx],n,ct,nxt[nmx];
ifstream f ("scmax.in");
ofstream g ("scmax.out");
void doitpls(int x)
{
    if (nxt[x]!=0)
        doitpls(nxt[x]);
    g<<v[x]<<' ';
}
int main()
{
    f>>n;
    for (int i=1; i<=n; i++)
    {
        f>>v[i];
        int st=1,dr=ct,mid,sol=ct+1;
        while (st<=dr)
        {
            mid=(st+dr)/2;
            if (v[haz[mid]]>=v[i])
            {
                sol=mid;
                dr=mid-1;
            }
            else st=mid+1;
        }
        ct=max(ct,sol);
        haz[sol]=i;
        nxt[i]=haz[sol-1];
    }
    g<<ct<<'\n';
    int i=haz[ct];
    doitpls(i);
}
