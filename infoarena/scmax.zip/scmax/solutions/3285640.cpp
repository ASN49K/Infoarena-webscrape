#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int dp[100005];
int v[100005];
int rez[100005];
int poz[100005];
int afis[100005];

int cautare(int st, int dr, int val)
{
    if(st+1==dr)return st;
    int mij=(st+dr)/2;
    if(rez[mij]<val)return cautare(mij, dr, val);
    return cautare(st, mij, val);
}

int main()
{
    int n;
    in>>n;
    for(int i=1;i<=n;i++)
    {
        in>>v[i];
    }
    poz[1]=1;
    rez[1]=v[1];
    int dreapta=1;
    for(int i=2;i<=n;i++)
    {
        int p=cautare(1, dreapta+1, v[i]);
        if(rez[p]<v[i])
        {
            rez[p+1]=v[i];
            dreapta=max(dreapta, p+1);
            poz[i]=p+1;
        }
        else
        {
            rez[p]=v[i];
            poz[i]=p;
        }
    }
    out<<dreapta<<'\n';
    int cdr=dreapta;
    for(int i=n;i>=1;i--)
    {
        if(poz[i]==dreapta)
        {
            afis[dreapta]=v[i];
            dreapta--;
        }
    }
    for(int i=1;i<=cdr;i++)
    {
        out<<afis[i]<<" ";
    }
    return 0;
}
