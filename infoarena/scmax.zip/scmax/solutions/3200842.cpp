#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;
int v[200005],previ[200005];
vector<pair<int,int>> rez;

void refac(int poz)
{
    if(previ[poz])
        refac(previ[poz]);
    cout<<v[poz]<<" ";
}

int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n,sol=0,save;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
        auto x = lower_bound(rez.begin(), rez.end(), make_pair(v[i], 0));
        int y = x - rez.begin();
        if(x==rez.end())
        {
            rez.push_back({v[i], i});
            y=rez.size()-1;
        }
        else
            rez[y]={v[i], i};

        if(y != 0)
            previ[i] = rez[y - 1].second;
        if(sol < y + 1)
        {
            sol = y + 1;
            save = i;
        }

    }

    cout<<sol<<'\n';
    refac(save);


    return 0;
}
