#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#define MAX 2000000001

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main()
{
    int n; fin >> n;
    vector<int> v(n);
    vector<int> b(n + 1, MAX);
    vector<int> dp(n + 1, 0);

    for(int i = 0;i < n;fin >> v[i++]);


    for(int i = 0;i < n;i++)
    {
        vector<int>::iterator it = lower_bound(b.begin(), b.end(), v[i]);
        int pos = it - b.begin();

        b[pos] = v[i];
        dp[i] = pos + 1;
    }

    fout << *max_element(dp.begin(), dp.end()) << endl;

    int mx = *max_element(dp.begin(), dp.end());

    vector<int> ans;

    for(int i = n - 1;i >= 0;i--)
    {
        if(mx == dp[i])
        {
            ans.push_back(v[i]);
            mx--;
        }
    }

    for(int i = ans.size() - 1;i >= 0;i--) fout << ans[i] <<  " ";
    // for(int i = 0;i < n;i++)
    // {
    //     if(b[i] == MAX) break;

    //     cout << b[i] << " ";
    // }


}