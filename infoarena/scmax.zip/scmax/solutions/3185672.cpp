#include <bits/stdc++.h>
using namespace std;

#ifndef HOME
	ifstream in("scmax.in");
	ofstream out("scmax.out");
	#define cin in
	#define cout out
#endif

int best[100001];
int v[100001], vec[100001];

int n;

int cautbin(int val)
{
	int r = 0, pas = 1 << 16;
	while(pas)
	{
		if(r + pas <= n && vec[r + pas] <= val)
			r += pas;
		pas /= 2;
	}
	return r;
}

int main()
{
#ifdef HOME
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#endif // HOME
    int max1 = 0;
	cin >> n;
	for(int i = 1; i <= n; i++)
	{
		cin >> v[i];
		vec[i] = v[i];
	}
	sort(vec + 1, vec + n + 1);
	for(int i = 1; i <= n; i++)
		v[i] = cautbin(v[i]);
	for(int i = 1; i <= n; i++)
	{
		for(int j = 0; j < v[i]; j++)
			best[v[i]] = max(best[v[i]], best[j] + 1);
		max1 = max(max1, best[v[i]]);
	}
	cout << max1;
    return 0;
}