#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int v[6000001];
int main()
{
    int n , i , j , nrcrescmax=0 , imax=0 , jmax=0 , nrcresc=0 , dateinpulamea=0;
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>v[i];
        //cout<<nrcrescmax<<" "<<imax<<" "<<jmax<<" "<<nrcresc<<"\n";
        if(v[i]<v[i-1])
        {
            imax=i;
            nrcresc=0;
        }
        if(v[i]!=v[i-1])
            nrcresc++;
        if(nrcresc>nrcrescmax)
        {
            nrcrescmax=nrcresc;
            jmax=i;
            dateinpulamea=imax;

        }

        //cout<<nrcrescmax<<" "<<imax<<" "<<jmax<<" "<<nrcresc<<"\n";
    }
    fout<<nrcrescmax<<"\n";
    for(i=dateinpulamea; i<=jmax; i++)
    {
        if(i==dateinpulamea)
            fout<<v[i]<<" ";
        else
        {
            if(v[i]!=v[i-1])
                fout<<v[i]<<" ";
        }
    }
    return 0;
}
