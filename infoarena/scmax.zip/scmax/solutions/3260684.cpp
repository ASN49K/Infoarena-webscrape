#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    int n;
    cin >> n;
    vector<int> a(n), seq(n, 1), last(n, -1);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    seq[0] = 1;
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            if (a[i] > a[j]) {
                seq[i] = max(seq[i], seq[j] + 1);
                last[i] = j;
            }
        }
    }
    int target, maxSeq = 0;
    for (int i = 0 ; i< n; ++i) {
        if (seq[i] > maxSeq) {
            maxSeq = seq[i];
            target = i;
        }
    }
    int current = target;
    stack<int> nums;
    for (int i = 0; i < maxSeq; ++i) {
        nums.push(a[current]);
        current = last[current];
    }
    cout << maxSeq << "\n";
    while (!nums.empty()) {
        cout << nums.top() << " ";
        nums.pop();
    }
    return 0;
}
