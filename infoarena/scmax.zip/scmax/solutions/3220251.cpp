#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,i,j,v[100001],d[100001],poz[100001],cmax,lm,st;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i];
        d[n]=1;
        poz[n]=0;
        for(i=n-1;i>=1;i--)
        {
            cmax=0;
            for(j=i+1;j<=n;j++)
            {
                if(v[i]<v[j])
                {
                    if(cmax<=d[j])
                        cmax=d[j],poz[i]=j;
                }
                d[i]=cmax+1;
                if(d[i]>lm)
                    lm=d[i],st=i;
            }

        }
        fout<<lm<<'\n';
        i=st;
        while(poz[i])
        {
            fout<<v[i]<<' ';
            i=poz[i];
        }
        fout<<v[i];
    return 0;
}
