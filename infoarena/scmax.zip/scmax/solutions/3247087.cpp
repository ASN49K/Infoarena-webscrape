#include <bits/stdc++.h>

using namespace std;
ifstream in("scmax.in");
ofstream out("scmax.out");
const int NMAX = 1e5;
int n, v[NMAX+1], result[NMAX+1];
vector <int> d;
int p[NMAX+1];//pozitia pe care este pus in d, elementul de pe pozitia i din v
int BinarySearchFirstHigher(int val)
{
    int st=0, dr=d.size()-1, mid, rez=0;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(val<=v[d[mid]])
        {
            rez=mid;
            dr=mid-1;
        }
        else
        {
            st=mid+1;
        }
    }
    return rez;
}
int main()
{
    in>>n;
    for(int i=0; i<n; i++)
        in>>v[i];
    d.push_back(1);
    for(int i=1; i<n; i++)
    {
        if(v[i]>v[d.back()])
        {
            d.push_back(i);
            p[i]=d.size()-1;
        }
        else
        {
            int poz=BinarySearchFirstHigher(v[i]);
            d[poz]=v[i];
            p[i]=poz;
        }
    }

    int k = d.size();
    out<<k<<"\n";
    int j = n;
    for(int i=k-1; i>=0; i--)
    {
        while(p[j] != i && j>=0)
            j--;
        if(j>=0)
            result[i] = j;
    }
    for(int i=0; i<k; i++)
    {
        out<<v[result[i]]<<" ";
    }return 0;
}
