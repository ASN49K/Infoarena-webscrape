#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

int v[NMAX + 1];

int prv[NMAX + 1];
int ans[NMAX + 1];

int main() {
    ifstream fin( "scmax.in" );
    ofstream fout( "scmax.out" );
    int n;
    fin >> n;

    vector <int> lis( 1, 0 );
    for ( int i = 1; i <= n; i ++ ) {
        fin >> v[i];
    }
    ans[0] = 0;
    for ( int i = 1; i <= n; i ++ ) {
        int st = 0, dr = (int)lis.size();
        while ( st < dr - 1 ) {
            int mij = ( st + dr ) / 2;
            if ( v[lis[mij]] < v[i] ) {
                st = mij;
            } else {
                dr = mij;
            }
        }
        ans[i] = st + 1;
        prv[i] = lis[st];
        if ( st == (int)lis.size() - 1 ) {
            lis.push_back( i );
        } else {
            lis[st + 1] = i;
        }
    }

    int lmax = 0, best = 0;
    for ( int i = 1; i <= n; i ++ ) {
        if ( ans[i] > lmax ) {
            lmax = ans[i];
            best = i;
        }
    }
    fout << lmax << '\n';
    vector <int> a;
    while ( best != 0 ) {
        a.push_back( best );
        best = prv[best];
    }
    reverse( a.begin(), a.end() );
    for ( auto x : a ) {
        fout << v[x] << ' ';
    }
    fout << '\n';
    return 0;
}