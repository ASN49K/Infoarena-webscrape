#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int a[1005], dp[1005], t[1005], n, ind[1005], k;
int smax()
{
    dp[1]=1;
    t[1]=-1;
    for(int i=2; i<=n; i++)
    {
        int pmax=-1, maxi=0;
        for(int j=1; j<i; j++)
        {
            if(a[i]>a[j]&& dp[j]>maxi)
            {
                maxi=dp[j];
                pmax=j;
            }
        }
        dp[i]=maxi+1;
        t[i]=pmax;
    }
    int maxi=0, pozmaxi=-1;
    for(int i=1; i<=n; i++)
    {
        if(dp[i]>maxi)
            maxi=dp[i], pozmaxi=i;
    }
    return pozmaxi;
}
void drum(int i)
{
    //ind[1]=a[i];
    if(t[i]==-1)
    {
        fout<<a[i]<<" ";
        return;
    }
    drum(t[i]);
    fout<<a[i]<<" ";
}
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>a[i];
    fout<<dp[smax()]<<"\n";
    drum(smax());

    return 0;
}
