#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int a[100005], dp[100005], n, k;

void CB(int x)
{
    int st, dr, mj, p;
    p = 0;
    dr = k;
    st = 1;
    while(st <= dr)
    {
        mj = (st+dr) / 2;
        if(dp[mj] >= x)
        {
            p = mj;
            dr = mj - 1;
        }
        else st = mj + 1;
    }
    dp[p] = x;
}

int main()
{
    int i;
    fin >> n;
    for(i=1;i<=n;i++)
        fin >> a[i];
    dp[1] = a[1];
    k = 1;
    for(i=2;i<=n;i++)
        CB(a[i]);
    fout << k << "\n";
    for(i=1;i<=k;i++)
        fout << dp[i] << " ";
    fin.close();
    fout.close();
    return 0;
}
