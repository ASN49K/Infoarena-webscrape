#include <bits/stdc++.h>

std::ifstream fin("scmax.in");
std::ofstream fout("scmax.out");

const int MAX_N = 100'000;

int a[MAX_N + 1], best[MAX_N + 1], poz[MAX_N + 1], sol[MAX_N + 1];
int n, lgbest;
/// best[i] - cel mai mic element din a care poate fi plasat pe pozitia i intr-un susbir
/// crescator maximal
/// poz[i] - pozitia pe care este amplasat in best elementul a[i]

int cautBin(int x) {
   int p = 1, st = 1, dr = lgbest;
   while (st <= dr) {
      int mid = (st + dr) >> 1;
      if (best[mid] > x) {
         p = mid;
         dr = mid - 1;      
      } else
         st = mid + 1;
   }
   return p;
}

int main() {
   fin >> n;
   for (int i = 1; i <= n; i++)
      fin >> a[i];
   
   best[1] = a[1]; poz[1] = 1;
   for (int i = 2; i <= n; i++)
      if (a[i] > best[lgbest]) {
         best[++lgbest] = a[i];
         poz[i] = lgbest;      
      }
      else {
         poz[i] = cautBin(a[i]);
         best[poz[i]] = a[i];      
      }
      
   fout << lgbest << "\n";
   
   for (int i = n, j = lgbest; j >= 1; i--)
      if (poz[i] == j) {
         sol[j] = a[i];
         j--;   
      }
   
   for (int i = 1; i <= lgbest; i++)
      fout << sol[i] << " ";
      
   fin.close();
   fout.close();
   return 0;
}
