import java.io.*;
import java.util.*;
/*
 Fie un vector a cu N elemente.
 Numim subsir al lui a de lungime K un vector a' = (ai1, ai2, ..., aiK) astfel incat sa avem i1 < i2 < ... < iK.

Cerinta
Sa se determine un subsir al lui a care este ordonat strict crescator si care are lungimea maxima.

Date de intrare
Fisierul de intrare scmax.in contine pe prima linie :
numarul N reprezentand numarul de elemente ale vectorului a . 
Pe cea de-a doua linie se afla N numere naturale reprezentand elementele vectorului a.

Date de iesire
In fisierul de iesire scmax.out se va afisa pe prima linie Lmax,
 lungimea celui mai lung subsir crescator al sirului a. 
 Pe cea de-a doua linie se vor afla Lmax numere naturale reprezentand cel mai
  lung subsir crescator al vectorului a. Daca exista mai multe solutii se poate afisa oricare.
 */
public class SCMax {
    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(new FileReader("scmax.in"));
             PrintWriter pw = new PrintWriter(new FileWriter("scmax.out"))) {
             
            int N = Integer.parseInt(br.readLine().trim());
            int[] a = Arrays.stream(br.readLine().trim().split("\\s+")).mapToInt(Integer::parseInt).toArray();
            
            // Array to store the length of longest increasing subsequence ending at each index
            int[] dp = new int[N];
            // Array to store the previous index of the element in the longest increasing subsequence
            int[] prev = new int[N];
            
            // Initialize the dp array
            Arrays.fill(dp, 1);
            Arrays.fill(prev, -1);

            int maxLength = 1;
            int bestEnd = 0;

            for (int i = 1; i < N; i++) {
                for (int j = 0; j < i; j++) {
                    if (a[j] < a[i] && dp[j] + 1 > dp[i]) {
                        dp[i] = dp[j] + 1;
                        prev[i] = j;
                    }
                }
                if (dp[i] > maxLength) {
                    maxLength = dp[i];
                    bestEnd = i;
                }
            }

            // Reconstruct the longest increasing subsequence
            List<Integer> lis = new ArrayList<>();
            for (int i = bestEnd; i != -1; i = prev[i]) {
                lis.add(a[i]);
            }
            Collections.reverse(lis);

            // Output results
            pw.println(maxLength);
            for (int num : lis) {
                pw.print(num + " ");
            }
            pw.println();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
