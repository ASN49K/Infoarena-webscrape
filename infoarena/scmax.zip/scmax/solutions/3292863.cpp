#include <iostream>
#include <bits/stdc++.h>
#define VMAX 100002
#define INF 2147000000
using namespace std;
ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

int numere[VMAX];
vector<int> sir;
int dp[VMAX];
int mutari[VMAX];
int capat = 1;

int main()
{
    int n,m,i,j,k,t,q,nr,minim,maxim,st,dr,mij;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        dp[i]=INF;
        fin>>numere[i];
    }

    for(i=1;i<=n;i++)
    {
        st=0;
        dr=capat;
        while(dr-st>1)
        {
            mij=(st+dr)/2;
            if(dp[mij]<numere[i])
                st=mij;
            else
                dr=mij;
        }
        dp[dr]=numere[i];
        mutari[i]=dr;
        if(dr==capat)
            capat++;
    }

    capat--;
    fout<<capat<<'\n';
    for(i=n;capat;i--)
    {
        if(mutari[i]==capat)
        {
            sir.push_back(numere[i]);
            capat--;
        }
    }

    while(sir.size())
    {
        fout<<sir.back()<<' ';
        sir.pop_back();
    }

    return 0;
}
