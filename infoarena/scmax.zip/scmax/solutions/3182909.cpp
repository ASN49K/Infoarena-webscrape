#include <fstream>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int n,i,v[100002],tata[100002],dp[100002],st,dr,mid,k,poz;
void rec(int poz){
    if(poz!=0){
        rec(tata[poz]);
        cout<<v[poz]<<" ";
    }
}
int main()
{
    cin>>n;
    for(i=1;i<=n;i++){
        cin>>v[i];
    }
    for(i=1;i<=n;i++){
        if(v[dp[k]]<v[i]){
            dp[++k]=i;
            tata[i]=dp[k-1];
        }
        else{
            st=1,dr=k,poz=1;
            while(st<=dr){
                mid=(st+dr)/2;
                if(v[dp[mid]]<v[i])
                    st=mid+1;
                else{
                    poz=mid;
                    dr=mid-1;
                }
            }
            dp[poz]=i;
            tata[i]=dp[poz-1];
        }
    }
    cout<<k<<'\n';
    rec(dp[k]);
    return 0;
}
