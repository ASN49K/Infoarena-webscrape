#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, a[100005], b[100005], k, poz[100005], st[100005], top;

int CautBin(int x)
{
    int st = 1, dr = k, mij, sol = k;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (x <= b[mij])
        {
            sol = mij;
            dr = mij - 1;
        }
        else st = mij + 1;
    }
    return sol;
}

int main()
{
    int i, p;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];

    for (i = 1; i <= n; i++)
    {
        if (k == 0)
        {
            b[++k] = a[i];
            continue;
        }

        if (a[i] <= b[1])
        {
            b[1] = a[i];
            poz[i] = 1;
        }
        else if (a[i] > b[k])
        {
            b[++k] = a[i];
            poz[i] = k;
        }
        else
        {
            p = CautBin(a[i]);
            b[p] = a[i];
            poz[i] = p;
        }

    }

    fout << k << "\n";
    for (i = n; i >= 1 and k; i--)
        if (poz[i] == k)
        {
            st[++top] = a[i];
            k--;
        }

    for (i = top; i >= 1; i--)
        fout << st[i] << " ";


    return 0;
}
