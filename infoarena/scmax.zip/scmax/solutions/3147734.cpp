#include<iostream>
#include<fstream>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int a[100010], L[100010], T[100010], n;

void sol(int poz){
    if(L[poz])
        sol(L[poz]);
    g << a[poz];
}

int main()
{
    int i, p, m, u, mid;

    f >> n;
    for(i=1; i<=n; ++i) f >> a[i];
    f.close();
    m = 1;
    L[1] = 1;
    for(i=2; i<= n; ++i){
        p = 1;
        u = m;
        while(p <= u){
            mid = p     + (u - p) / 2;
            if(a[i] > a[L[mid]]) p = mid + 1;
            else u = mid - 1;
        }
        if(p > m){
            m++;
            L[m] = i;
        }
        else{
            if(a[i] < a[L[p]]){
                L[p] = i;
            }
        }
    }
    g << m << '\n';
    sol(L[m]);
    g.close();

    return 0;

}
