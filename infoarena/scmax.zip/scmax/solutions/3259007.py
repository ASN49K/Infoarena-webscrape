def scmax_from_file():
    # Read the input sequence from "scmax.in"
    with open("scmax.in", "r") as infile:
        infile.readline()
        subsir = list(map(int, infile.readline().split()))
    
    # Initialize list of tuples (length, predecessor)
    maximum_lengths = [(1, i) for i in range(len(subsir))]
    
    for i in range(len(subsir)):
        for j in range(i - 1, -1, -1):
            if subsir[j] < subsir[i] and maximum_lengths[j][0] + 1 > maximum_lengths[i][0]:
                maximum_lengths[i] = (maximum_lengths[j][0] + 1, j)
    
    # Find the position of the maximum sequence
    max_length = 0
    max_pos = 0
    for i in range(len(maximum_lengths)):
        if maximum_lengths[i][0] > max_length:
            max_length = maximum_lengths[i][0]
            max_pos = i
    
    # Reconstruct the sequence
    sequence = []
    current_pos = max_pos
    while True:
        sequence.insert(0, subsir[current_pos])
        if maximum_lengths[current_pos][1] == current_pos:
            break
        current_pos = maximum_lengths[current_pos][1]
    
    # Write the output to "scmax.out"
    with open("scmax.out", "w") as outfile:
        outfile.write(f"{max_length}\n")
        outfile.write(" ".join(map(str, sequence)) + "\n")

# Run the function
scmax_from_file()
