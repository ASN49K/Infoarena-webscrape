#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");


int v[1001];
int dp[1001];
int bef[1001];
int main()
{
    
    int n;
    fin>>n;
    for(int i=0;i<n;i++){
        fin>>v[i];
    }
    
    
    
    for(int i=0;i<n;i++){
            int maxi=0;
            int s=0;
        for(int j=1;j<i;j++){
             if(dp[j]>maxi && v[i]>v[j]){
                maxi=dp[j];
                s=j;
             }
            
        }
        bef[i]=s;
        dp[i]=maxi+1;
    }
    
    
    int maxx=0;
    int j=0;
    for(int i=0;i<n;i++){
        if(dp[i]>maxx){
            maxx=dp[i];
            j=i;
        }
    }
fout<<maxx<<'\n';


int nou[1001];
for(int i=maxx-1;i>=0;i--){
    nou[i]=v[j];
    j=bef[j];
    
}

for(int i=0;i<maxx;i++){
    fout<<nou[i]<<" ";
}



    
    
 
}