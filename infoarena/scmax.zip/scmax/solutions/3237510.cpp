#include <fstream>

using namespace std;

const int N = 1e5;

ifstream in("scmax.in");
ofstream out("scmax.out");

int v[N], lung[N], pred[N], val_min[N+1], poz_min[N+1];

void refac_subsirul(int p)
{
    if (p == -1)
    {
        return;
    }
    refac_subsirul(pred[p]);
    out << v[p] << " ";
}

int caut_bin(int x[], int nr, int val)
{
    ///cautam binar cel mai mare i cu x[i] < val (x este indexat de la 1)
    int st = 1, dr = nr, rez = 0;
    while (st <= dr)
    {
        int m = (st + dr) / 2;
        if (x[m] < val)
        {
            rez = m;
            st = m + 1;
        }
        else
        {
            dr = m - 1;
        }
    }
    return rez;
}

int main()
{
    int n;
    in >> n;
    for (int i = 0; i < n; i++)
    {
        in >> v[i];
    }
    int l_max = 0;
    poz_min[0] = -1;
    for (int i = 0; i < n; i++)
    {
        int j_0 = caut_bin(val_min, l_max, v[i]);
        if (j_0 == l_max)///lungimea maxima a unui subsir str. crescator a crescut cu 1
        {
            l_max++;
        }
        val_min[j_0+1] = v[i];
        poz_min[j_0+1] = i;
        lung[i] = j_0 + 1;
        pred[i] = poz_min[j_0];
    }
    out << l_max << "\n";
    refac_subsirul(poz_min[l_max]);
    in.close();
    out.close();
    return 0;
}
