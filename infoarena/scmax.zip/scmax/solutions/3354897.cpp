#include <fstream>

using namespace std;
ifstream cin ("scmax.in");
ifstream cout ("scmax.out");
int v[1001];
int dp[1001];
int previ[1001];
int cpy[1001];
int main()
{
    int n,pmax,vmax = -1;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
        dp[i] = 1;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i;j++){
            if(v[i]>v[j]){
                if(dp[j]+1>dp[i]){
                    dp[i] = dp[j]+1;
                    previ[i] = j;
                }
            }
        }
        if(dp[i]>vmax){
            vmax = dp[i];
            pmax = i;
        }
    }
    int i = pmax;
    while(i!=0){
        cpy[dp[i]] = v[i];
        i = previ[i];

    }
    cout<<vmax<<'\n';
    for(int i=1;i<=vmax;i++){
        cout<<cpy[i]<<' ';
    }
    return 0;
}
