#include <bits/stdc++.h>

using namespace std;
ifstream f ("scmax.in");
ofstream g ("scmax.out");
const int NMAX=1e5;
int n, dp[NMAX+5], tot, v[NMAX+5], best[NMAX+5];
void add (int val, int p)
{
    if (tot==0 || val>dp[tot])
    {
        dp[++tot]=val;
        best[p]=tot;
        return;
    }
    int st=1, dr=tot, poz=0;
    while (st<=dr)
    {
        int mij = (st+dr) >> 1;
        if (dp[mij]<val)
        {
            poz=mij;
            st=mij+1;
        }
        else
            dr=mij-1;
    }
    dp[poz+1]=val;
    best[p]=poz+1;
}
int main ()
{
    ios_base :: sync_with_stdio (0);
    cin.tie (nullptr);
    f >> n;
    for (int i=1;i<=n;i++)
    {
        f >> v[i];
        add (v[i], i);
    }
    g << tot << "\n";
    int nxt=tot;
    vector <int> st;
    for (int i=n;i>=1;i--)
    {
        if (best[i]==nxt)
            --nxt, st.push_back (v[i]);
    }
    while (!st.empty())
        g << st.back() << " ", st.pop_back ();
    return 0;
}