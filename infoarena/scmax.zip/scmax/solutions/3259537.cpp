#include <bits/stdc++.h>
using namespace std;

#define cin fin
#define cout fout

ifstream fin("cartite.in");
ofstream fout("cartite.out");

const int dx[] = {-1, 1, 0, 0}, dy[] = {0, 0, -1, 1};
int a[205][205], b[205][205], visited[205], ind[205], ans[205], x[205], y[205], len, n, m;
vector<int> graph[205];

struct Edge {
    int xs, ys, xf, yf;
} edge[205];

bool inside(int x1, int y1)
{
    return x1 >= 1 && x1 <= n && y1 >= 1 && y1 <= m;
}

void bfs(int xs, int ys)
{
    queue<pair<int,int>> q;
    q.push({xs, ys});
    b[xs][ys] = 1;

    while (!q.empty())
    {
        int i, j;
        tie(i, j) = q.front();
        q.pop();

        if (a[i][j] == 1)
        {
            cout << i << " " << j << " " << b[i][j]-1;
            return;
        }

        for (int k = 0; k < 4; ++k)
        {
            int x = i + dx[k];
            int y = j + dy[k];
            if (inside(x, y) && a[x][y] != -1 && !b[x][y])
            {
                b[x][y] = b[i][j] + 1;
                q.push({x, y});
            }
        }
    }
}

void euler(int node)
{
    while (ind[node] < graph[node].size())
    {
        int next = graph[node][ind[node]];
        ++ind[node];

        if (!visited[next])
        {
            visited[next] = 1;
            euler(x[next] + y[next] - node);
        }
    }

    ans[++len] = node;
}

int main()
{
    int c, xs, ys, q;
    cin >> c >> n >> m >> xs >> ys >> q;

    while (q--)
    {
        int x, y, g;
        cin >> x >> y >> g;
        a[x][y] = -1;
        for (int j = 1; j <= g; ++j)
        {
            for (int k = 0; k < 4; ++k)
            {
                int is = x + j * dx[k];
                int js = y + j * dy[k];
                a[is][js] = -1;
            }
        }
    }

    map<pair<int,int>, int> M;
    map<int, pair<int,int>> M2;
    cin >> q;
    for (int i = 1; i <= q; ++i)
    {
        int xs, ys, xf, yf;
        cin >> edge[i].xs >> edge[i].ys >> edge[i].xf >> edge[i].yf;

        xs = edge[i].xs;
        ys = edge[i].ys;
        xf = edge[i].xf;
        yf = edge[i].yf;

        if (a[xs][ys] != -1)
        	a[xs][ys] = 1;

        if (a[xf][yf] != -1)
            a[xf][yf] = 1;

        if (!M.count({xs, ys}))
        {
            int dim = M.size()+1;
            M[{xs, ys}] = dim;
            M2[dim] = {xs, ys};
        }

        if (!M.count({xf, yf}))
        {
            int dim = M.size()+1;
            M[{xf, yf}] = dim;
            M2[dim] = {xf, yf};
        }
    }

    if (c == 1)
        bfs(xs, ys);
    else
    {
        int val = 0;
        for (int i = 1; i <= q; ++i)
        {
            int xs, ys, xf, yf;
            xs = edge[i].xs;
            ys = edge[i].ys;
            xf = edge[i].xf;
            yf = edge[i].yf;

            int x1 = M[{xs,ys}], y1 = M[{xf,yf}];

            ++val;
            x[val] = x1, y[val] = y1;
            graph[x1].push_back(val);
            graph[y1].push_back(val);
        }

        euler(1);
        for (int i = 1; i <= len; ++i)
            cout << M2[ans[i]].first << " " << M2[ans[i]].second << "\n";
    }

    return 0;
}
