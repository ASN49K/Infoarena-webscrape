#include <bits/stdc++.h>
#define SIZE 100005

using namespace std;

ifstream f("test.in");
ofstream g("test.out");

int v[SIZE],n,t[SIZE],r[SIZE];

void build(int p)
{
    if(p!=0)
    {
        build(r[p]);
        g<<v[p]<<' ';
    }
}

int main()
{
    int i,st,dr,len=0,mij,poz;
    f>>n;
    for(i=1;i<=n;i++)f>>v[i];
    for(i=1;i<=n;i++)
    {
        //upper bound
        st=1;
        dr=len;
        while(st<=dr)
        {
            mij=(st+dr)/2;
            if(v[t[mij]]<v[i])st=mij+1;
            else dr=mij-1;
        }
        poz=st;
        if(poz>len)len=poz;
        t[poz]=i;
        r[i]=t[poz-1];
    }
    g<<len<<'\n';
    build(t[len]);
    return 0;
}
