#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, before[100005], index[100005], p, v[100005], ans, dp[100005];
///#define fin cin
///#define fout cout
void findd(int x)
{
    if(before[x])
        findd(before[x]);
    fout << v[x] << ' ';
}
int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++ i)
    fin >> v[i];
    for(int i = 1; i <= n; ++ i)
    {
        if(v[i] > dp[ans])
        {
            dp[++ans] = v[i];
            index[ans] = i;
            before[i] = index[ans - 1];
        } else {

            int p = lower_bound(dp + 1, dp + ans + 1, v[i]) - dp;
            dp[p] = v[i];
            index[p] = i;
            before[i] = index[p - 1];
        }
    }
    fout << ans << '\n';
    findd(index[ans]);
    return 0;
}
