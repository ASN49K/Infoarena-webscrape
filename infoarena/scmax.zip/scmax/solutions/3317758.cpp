#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,m,v[100034],dp[100034],poz[100034],maxi;
set<int>s;
int main() {
   ios::sync_with_stdio(false);
   fin.tie(0);
    fin>>n;
    for(int i=1;i<=n;++i) fin>>v[i];
    for(int i=1;i<=n;++i) dp[i]=1e9+7;
    dp[0]=-1e9;
    for( int i=1;i<=n;++i)
    {
      int st=0, dr=i-1,ans=0;
      while(st<=dr)
      {
        int mid=(st+dr)/2;
        if(dp[mid]<v[i]){
          dp[mid+1]=v[i];
          ans=mid;
          st=mid+1;
        }
        else dr=mid-1;
      }
      dp[ans+1]=v[i];
      poz[ans+1]=i;
      maxi=max(ans+1,maxi);
    }
    fout<<maxi<<'\n';
    for(int i=1;i<=maxi;++i){
      fout<<dp[i]<<' ';
    }
    return 0;
}
