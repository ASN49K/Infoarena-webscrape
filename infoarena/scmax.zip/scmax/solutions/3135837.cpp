#include <iostream>
#include <fstream>

using namespace std;

#define MAXN 100010

ifstream f("scmax.in");
ofstream g("scmax.out");

int n, v[MAXN], tata[MAXN], maxim, dp[MAXN], poz[MAXN], j;

void afis(int nod) {
    if (nod == 0) {
        return;
    }
    afis(tata[nod]);
    g << v[nod] << ' ';
}

int main() {
    f >> n;
    for (int i = 1; i <= n; ++i) {
        f >> v[i];
        j = 1;
        while (dp[j] < v[i] && j <= maxim) {
            ++j;
        }
        dp[j] = v[i];
        poz[j] = i;
        tata[i] = poz[j - 1];
        maxim = max(maxim, j);
    }

    g << maxim << '\n';
    afis(poz[maxim]);
}
