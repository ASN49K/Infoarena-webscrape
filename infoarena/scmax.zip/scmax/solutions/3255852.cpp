#include <bits/stdc++.h>
using namespace std;

int n, v[100001];
int l, d[100001];
int pred[100001];

//scmax modificat pentru cel mai lung sir CRESCATOR (NU strict crescator)

int bin_search(int k) {
    int st = 1, dr = l;
    while (st < dr) {
        int mid = (st + dr) / 2;
        if (k <= v[d[mid]]) {
            dr = mid;
        } else {
            st = mid + 1;
        }
    }
    return st;
}

int main() {
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> v[i];
    }
    d[++l] = 1;
    for (int i = 2; i <= n; ++i) {
        if (v[i] > v[d[l]]) {
            pred[i] = d[l];
            d[++l] = i;
        } else if (v[i] < v[d[l]]) {
            int pos = bin_search(v[i]);
            d[pos] = i;
            pred[i] = d[pos - 1];
        }
    }
    int pos = d[l];
    stack<int> s;
    while (pos != 0) {
        s.push(v[pos]);
        pos = pred[pos];
    }
    cout << s.size() << "\n";
    while (!s.empty()) {
        cout << s.top() << " ";
        s.pop();
    }
}
