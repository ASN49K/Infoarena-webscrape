//
//  main.cpp
//  scmax
//
//  Created by Emma on 04.09.2025.
//

#include <iostream>
using namespace std;
unsigned int n,i,j,m,v[10005],dp[10005];
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>v[i];
    
    dp[1]=n;
    m=1;
    for(i=n-1;i>=1;i--)
    {
        j=1;
        while(v[i]<v[dp[j]])
            j++;
        j--;
        if(m==j)
        {
            dp[++m]=i;
            m++;
        }
        else if(v[dp[j+1]]<v[i])
            dp[j+1]=i;
    }
    
    cout<<m<<"\n";
    cout<<v[dp[m]]<<" ";
    j=m-1;
    for(i=dp[m]+1;i<=n;i++)
        if(v[i]<=v[dp[j]] && v[i]>v[dp[j+1]])
        {
            cout<<v[i]<<" ";
            j--;
        }
    return 0;
}
