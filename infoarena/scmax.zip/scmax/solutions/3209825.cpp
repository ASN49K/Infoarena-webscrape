#include <fstream>
#include <cmath>
#include <vector>
#include <climits>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

const int NMAX = 1e5;
int v[NMAX + 5], prv[NMAX + 5], dp[NMAX + 5];
vector <int> ans;

struct
{
    int first, second;
} lg[NMAX + 5];

int BinarySearch(int value, int n)
{
    int st = 0, dr = n, ans;
    while (st <= dr) {
        int med = (st + dr) / 2;
        if (lg[med].first < value) {
            ans = med;
            st = med + 1;
        }
        else {
            dr = med - 1;
        }
    }
    return ans;
}

int main()
{
    int n;
    fin >> n;

    for(int i = 1; i <= n; i++)
        fin >> v[i];

    for(int i = 1; i <= n; i++)
        lg[i].first = INT_MAX;

    for(int i = 1; i <= n; i++)
    {
        dp[i] = BinarySearch(v[i], n) + 1;
        lg[dp[i]].first = v[i];
        lg[dp[i]].second = i;
        prv[i] = lg[dp[i] - 1].second;
    }


    int maxim = 0, idx;
    for(int i = 1; i <= n; i++)
        if(maxim < dp[i])
        {
            maxim = dp[i];
            idx = i;
        }

    fout << maxim << '\n';

    int i = idx;
    while(dp[i] != 0)
    {
        ans.push_back(v[i]);

        i = prv[i];
    }

    for(int i = ans.size() - 1; i >= 0; i--)
        fout << ans[i] << ' ';

    fin.close();
    fout.close();
    return 0;
}
