// oeis.org
#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#include <bits/stdc++.h>
 
using namespace std;
 
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
void debug3(int *t,int st,int n) {cerr << '{' << t[st];for(int i=st+1;i<=n;i++) cerr<<",",__print(t[i]);cerr <<"}"<<'\n';}
#ifndef ONLINE_JUDGE
#define debug(x...) cerr << "[" << #x << "] = ["; _print(x)
#define debug2(x...) cerr<<"[" << #x << "] = "; debug3(x)
#endif
 
/// = any_of(a.begin(), a.end(), [](int x) { return x == 9; }); macar un element e 9
/// = all_of(a.begin(), a.end(), [](int x) { return x == 9; }); toate sunt 9
/// = none_of(a.begin(), a.end(), [](int x) { return x == 9; }); n am nici un 9
/// = count(a.begin(), a.end(), x); cate sunt x
 
#define N 300005
#define ll long long
#define ull unsigned long long
#define pii pair<int,int>
#define pll pair<ll,ll>
#define sf second.first
#define ss second.second
#define INF 1e18+5
 
const ll MOD = 998244353 ;

int v[100005], dp[100005], len=0, a[100005];

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    freopen("test.in", "r", stdin);
    vector<int> sol;
    int n;
    fin >> n;
    for(int i=1; i<=n; i++) {
        fin >> v[i];
    }
    for(int i=1; i<=n; i++) {
        if(v[i]>dp[len]) {
            len++;
            dp[len]=v[i];
            a[i] = len;
        } else {
            auto x=lower_bound(dp+1, dp+len+1, v[i]);
            dp[x-dp]=v[i];
            a[i] = x-dp;
        }
    }
    fout << len << '\n';
    for (int i = n ; i >= 1 ; i-- )
    {
        if ( a[i] == len )
        {
            sol.push_back(v[i]);
            len--;
        }
    }
    reverse(sol.begin(),sol.end());
    for ( auto elem: sol )
        fout << elem << " ";
    return 0;
}
