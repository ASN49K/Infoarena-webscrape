vectorul poz: 
vectorul lung: 