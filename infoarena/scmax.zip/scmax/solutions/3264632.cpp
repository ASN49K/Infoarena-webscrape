#include <fstream>
#include <unordered_map>
#include <algorithm>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
unordered_map<int, int> nr;
int v[100001];
pair<int, int> cv[100001];
pair<int, int> ar[400005];

void update(int node, int left, int right, int pos, pair<int, int> val)
{
    if(left == right)
    {
        ar[node] = val;
        return;
    }
    int mid = (left + right) / 2;
    if(pos <= mid)
    {
        update(node * 2, left, mid, pos, val);
    }
    else
    {
        update(node * 2 + 1, mid + 1, right, pos, val);
    }
    ar[node] = max(ar[node * 2], ar[node * 2 + 1]);
}

pair<int, int> query(int node, int left, int right, int a, int b)
{
    if(a <= left && right <= b)
    {
        return ar[node];
    }
    int mij = (left + right) / 2;
    pair<int, int> lM = {0, 0}, rM = {0, 0};
    if(a <= mij)
    {
        lM = query(2 * node, left, mij, a, b);
    }
    if(mij + 1 <= b)
    {
        rM = query(2 * node + 1, mij + 1, right, a, b);
    }
    return max(lM, rM);
}

int main()
{
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i];
        cv[i].first = v[i];
    }
    sort(cv+1, cv+n+1);
    int t = 0;
    for(int i = 1; i <= n; i++)
    {
        if(i == 1)
        {
            nr[cv[i].first] = 1;
            t++;
        }
        else if(cv[i - 1].first == cv[i].first)
        {
            nr[cv[i].first] = t;
        }
        else
        {
            nr[cv[i].first] = ++t;
        }
        cv[i] = {0, 0};
    }
    for(int i = n; i >= 1; i--)
    {
        if(n >= nr[v[i]] + 1)
        {
            pair<int, int> q = query(1, 1, n, nr[v[i]] + 1, n);
            cv[i].first = 1 + q.first;
            cv[i].second = q.second;
            update(1, 1, n, nr[v[i]], {cv[i].first, i});
        }
        else
        {
            cv[i] = {1, 0};
            update(1, 1, n, nr[v[i]], {1, i});
        }
    }
    pair<pair<int, int>, int> mx;
    for(int i = 1; i <= n; i++)
    {
        if(mx.first.first < cv[i].first)
        {
            mx.first = cv[i];
            mx.second = i;
        }
    }
    cout << mx.first.first << "\n";
    while(mx.first.first > 0)
    {
        cout << v[mx.second] << " ";
        mx.second = mx.first.second;
        mx.first = cv[mx.first.second];
    }
}