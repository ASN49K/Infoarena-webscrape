#include <fstream>
#include <vector>
#include <climits>
#include <algorithm>

std::ifstream fin("scmax.in");
std::ofstream fout("scmax.out");

int main () {
    int n; fin >> n;
    std::vector<int> v(n);
    for (int i = 0; i < n; i += 1)
        fin >> v[i];

    std::vector<int> d(n + 1, INT_MAX); d[0] = INT_MIN;
    for (int i = 0; i < n; i += 1) {
        int l = std::upper_bound (d.begin (), d.end (), v[i]) - d.begin ();
        if (d[l - 1] < v[i] && v[i] < d[l]) d[l] = v[i];
    }

    for (int l = n; l >= 1; l -= 1) {
        if (d[l] != INT_MAX) {
            fout << l;
            return 0;
        }
    }
    return 0;
}
