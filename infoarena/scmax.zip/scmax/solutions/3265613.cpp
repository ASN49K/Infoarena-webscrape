#include <iostream>
#include <fstream>
#include <stack>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int MAX=1e5;
int n,i,v[MAX+5],nr,g[MAX+5],h[MAX+5],st,dr,mij,sol,poz;
stack <int> s;

int main()
{
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>v[i];

    nr=1; g[1]=v[1]; h[1]=1;
    for (i=2; i<=n; i++)
    {
        if (v[i]>g[nr])
        {
            g[++nr]=v[i];
            h[i]=nr;
        }
        else
        {
            st=1; dr=nr; sol=0;
            while (st<=dr)
            {
                mij=(st+dr)>>1;
                if (g[mij]>=v[i])
                {
                    sol=mij;
                    dr=mij-1;
                }
                else
                st=mij+1;
            }

            g[sol]=v[i];
            h[i]=sol;
        }
    }



    fout<<nr<<"\n";



 return 0;
}
