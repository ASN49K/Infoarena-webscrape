#include <fstream>
#include <iostream>
#include <vector>
#include <stack>
#include <list>
#include <math.h>
#include <queue>
#include <algorithm>
#include <string.h>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int n, v[1005];
int sclm[1005];
int output[1005];

int main() {
    in >> n;
    for (int i = 1; i <= n; i++)
        in >> v[i];

    for (int i = 1; i <= n; i++) {
        int max = 0;
        for (int j = 1; j < i; j++) {
            if (v[j] < v[i] && sclm[j] > max) {
                max = sclm[j];
            }
        }
        sclm[i] = max + 1;
    }

    int max = sclm[1];
    for (int i = 1; i <= n; i++)
        if (max < sclm[i])
            max = sclm[i];
    out << max << endl;
    for (int i = 1; i <= max; i++)
        out << sclm[i] << " ";
}
