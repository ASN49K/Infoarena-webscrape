#include <bits/stdc++.h>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

const int N_MAX = 1e5;
int n, v[N_MAX + 5], w[N_MAX + 5], poz1[N_MAX + 5], predecesor[N_MAX + 5], poz2[N_MAX + 5], m, pozf;

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> v[i];
    for (int i = 1; i <= n; i++) {
        int st = 1, dr = m, poz = m + 1;
        while (st <= dr) {
            int mij = (st + dr) / 2;
            if (v[i] <= w[mij]) {
                poz = mij;
                dr = mij - 1;
            }
            else
                st = mij + 1;
        }
        w[poz] = v[i];
        poz1[poz] = i;
        if (poz >= 2)
            predecesor[i] = poz1[poz - 1];
        else
            predecesor[i] = -67;
        if (poz > m) {
            m = poz;
            pozf = i;
        }
    }
    fout << m << "\n";
    m = 0;
    while (pozf != -67) {
        poz2[++m] = pozf;
        pozf = predecesor[pozf];
    }
    for (int i = m; i >= 1; i--)
        fout << v[poz2[i]] << " ";
    fout << "\n";
    return 0;
}
