#include <fstream>
#include <map>
#include <set>
using namespace std;
ifstream cin ("scmax.in");
ofstream cout ("scmax.out");
int n;
int a[100005];
int aint[400005];
map<int,int> norm;
set<int> x;
int qst,qdr,qval;
void update(int nod,int st,int dr)
{
    if(st == dr && qst == st)
    {
        aint[nod] = qval;
        return;
    }
    int mij = (st+dr)/2;
    if(qst<=mij)
        update(2*nod,st,mij);
    else
        update(2*nod+1,mij+1,dr);
    aint[nod] = max(aint[2*nod],aint[2*nod+1]);
}
int query(int nod,int st,int dr)
{
    if(st >=qst && dr<=qdr)
        return aint[nod];
    int mij = (st+dr)/2;
    int rasp = 0;
    if(qst<=mij)
        rasp = max(rasp,query(2*nod,st,mij));
    else if(qdr > mij)
        rasp = max(rasp,query(2*nod+1,mij+1,dr));
    return rasp;
}
int cnt;
int dp[100005];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for(int i=1;i<=n;i++)
    {
        cin >> a[i];
        x.insert(a[i]);
    }
    for(auto y:x)
    {
        cnt++;
        norm[y] = cnt;
    }
    int lgmax = 0;
    int ind = 0;
    for(int i=n;i>=1;i--)
    {
        int val = norm[a[i]];
        qst = val + 1;
        qdr = cnt;
        int rasp = 0;
        if(qst<=qdr)
            rasp = query(1,1,cnt);
        rasp++;
        qst=qdr=val;
        qval = rasp;
        update(1,1,cnt);
        dp[i] = rasp;
        if(rasp>lgmax)
        {
            lgmax = rasp;
            ind = i;
        }
    }
    cout << lgmax << '\n';
    while(lgmax!=0)
    {
        cout << a[ind]<< ' ';
        for(int j=ind+1;j<=n;j++)
            if(a[j] > a[ind] && dp[j]==dp[ind]-1)
            {
                ind = j;
                break;
            }
        lgmax--;
    }
    return 0;
}
