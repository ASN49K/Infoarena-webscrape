#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#pragma GCC optimize ("O1")
#pragma GCC optimize ("O2")
#pragma GCC optimize ("O3")
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")
#pragma GCC target ("avx2")

using namespace std;
using namespace __gnu_pbds;

#define ordered_set tree <long long, null_type, less<long long>, rb_tree_tag, tree_order_statistics_node_update>
#define lsb(x)(x & (-x))

const int max_size = 1e5 + 20, INF = 2e9 + 2;

int v[max_size], best[max_size], dp[max_size];

void solve ()
{
    int n, mx = 0;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> v[i];
        best[i] = INF;
    }
    best[n + 1] = INF;
    v[n + 1] = INF;
    for (int i = 1; i <= n; i++)
    {
        int e = 30, st = 0;
        while (e >= 0)
        {
            if (st + (1 << e) < i && best[st + (1 << e)] < v[i])
            {
                st += (1 << e);
            }
            e--;
        }
        st++;
        dp[i] = st;
        best[dp[i]] = min(best[dp[i]], v[i]);
        mx = max(mx, st);
    }
    cout << mx << '\n';
    vector <int> ans;
    int ult = n + 1;
    for (int i =  n; i > 0; i--)
    {
        if (dp[i] == mx && v[i] < v[ult])
        {
            ans.push_back(v[i]);
            mx--;
        }
    }
    reverse(ans.begin(), ans.end());
    for (auto f : ans)
    {
        cout << f << " ";
    }
    cout << '\n';
}

signed main ()
{
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
#endif // LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long tt;
    //cin >> tt;
    tt = 1;
    while (tt--)
    {
        solve();
    }
    return 0;
}
