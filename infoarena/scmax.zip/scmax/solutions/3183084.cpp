#include <fstream>
#include <utility>
#include <vector>

using namespace std;

long long v[100005], s[100005];
pair<int, int> p[100005];
vector<int> ans;

int main()
{
    int n, l, pas = 1 << 16, x;

    ifstream f("scmax.in");
    ofstream g("scmax.out");

    f >> n;

    for(int i = 1; i <= n; i++)
    {
        f >> v[i];
    }

    p[1] = {1, 0};
    l = 1;
    s[1] = 1;

    for(int i = 2; i <= n; i++)
    {
        x = 0;
        pas = 1 << 16;
        while(pas)
        {
            if(x + pas <= l && v[s[x+pas]] < v[i])
                x += pas;
            pas /= 2;
        }
        p[i] = {x+1, s[x]};
        s[++x] = i;
        if(x > l)
            l = x;
    }

    l = 0;
    int j;

    for(int i = 1; i <= n; i++)
    {
        if(l < p[i].first)
        {
            l = p[i].first;
            j = i;
        }
    }

    g << l << endl;

    while(j > 0)
    {
        ans.push_back(v[j]);
        j = p[j].second;
    }

    for(int i = ans.size()-1; i >= 0; i--)
    {
        g << ans[i] << " ";
    }

    return 0;
}
