#include <bits/stdc++.h>
using namespace std;
int v[1005], u[1005];

int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    
    vector<int> s;
    int n;
    cin >> n;
    for(int i=0; i<n; i++)
    {
        cin >> v[i];
    }
    
    for(int i=0; i<n; i++)
    {
        int mx=1;
        for(int j=0; j<i; j++)
        {
            if(v[j] < v[i])
            {
                mx=max(mx, u[j]+1);
            }
        }
        u[i]=mx;
    } 
    int maxx=0, poz;
    for(int i=0; i<n; i++)
    {
        if(maxx<u[i])
        {
            maxx=u[i];
            poz=i;
        }
    }
    
    cout << maxx << "\n";
    
    int k, i, ult;
    k=maxx;
    i=poz;
    ult=v[i]+1;
    while(k>0)
    {
        
        if(ult>v[i] && u[i] == k)
        {
            s.push_back(v[i]);
            k--;
            ult=v[i];
        }
        i--;
    }
    
    for(int i=0; i<maxx; i++)
    {
        cout << s[maxx-i-1] << " ";
    }

    return 0;
}