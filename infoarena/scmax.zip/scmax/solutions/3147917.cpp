#include<iostream>
#include<vector>
#include<stdio.h>
#include<algorithm>
#include<queue>
using namespace std;

const int NMAX = 1e5 + 5;
int n, pos[NMAX], max1 = 1, maxpos = 1, frev[NMAX], v[NMAX], prev_pos[NMAX];
vector<int> dp;

int binarysearch(int target)
{
    int pos = -1, st = 0, dr = dp.size() - 1;

    while(st <= dr)
    {
        int mij = (st + dr) / 2;
        if(dp[mij] > target)
            st = mij + 1;
        else if(dp[mij] < target)
        {
            dr = mij - 1;
            pos = mij;
        }
        else
            st = mij + 1;
    }
    return pos;
}

int main()
{
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
    cin >> n;
    for(int i = 1; i <= n; i++)
        cin >> v[i];
    dp.push_back(v[1]);
    pos[1] = 1;
    frev[1]++;
    prev_pos[0] = 1;
    for(int i = 2; i <= n; i++)
    {
        int val = binarysearch(v[i]);
        if(val == -1)
        {
            dp.push_back(v[i]);
            pos[i] = dp.size();
            frev[pos[i]] = 1;
            prev_pos[dp.size() - 1] = i;
        }
        else
        {
            dp[val] = v[i];
            pos[i] = pos[prev_pos[val]];
            frev[pos[i]]++;
            prev_pos[val] = i;
            if(frev[pos[i]] > max1)
            {
                max1 = frev[pos[i]];
                maxpos = pos[i];
            }
        }
    }
    
    cout << max1 << "\n";
    for(int i = 1; i <= n; i++)
    {
        //cout << pos[i] << " " << v[i] << "\n";
        if(pos[i] == maxpos)
            cout << v[i] << " ";
    }
}