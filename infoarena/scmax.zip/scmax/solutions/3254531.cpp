
#include <fstream>
 using namespace std;
 ifstream in("scmax.in");
 ofstream out("scmax.out");
 int poz[100005], v[100005], s[100005];
 
 void afisare(int lgc, int dr, int val)
 {
   for(int i=dr;i>=1;i--)
    if(poz[i]==lgc &&  v[i]<val)
  {
    if(lgc>1)
      afisare(lgc-1,i-1, v[i]);
    out<<v[i]<<" ";
    break;
  }
  
 }
 
  int main(){
    int n;
  in>>n;
  for(int i=1;i<=n;i++)
  {
    in>>v[i];
  }  
  s[1]=v[1]; poz[1]=1;
  int lg=1;
  
  for(int i=2; i<=n; i++){
    // ii locul potrivit lui v[i]
    // s[1]........s[st]    |    s[dr]......s[lg]
    if(v[i]>s[lg])
    { 
      lg++;
      s[lg]=v[i];
      poz[i]=lg;
    }
    else if( v[i]<= s[1] ) {
      s[1]=v[i];
      poz[i]=1;
    } 
    else{
       // s[1]........s[st] < v[i]   |  v[i]<= s[dr]......s[lg]
      int st=1;
      int dr=lg;
      while(st+1<dr)
      {
        int mj=(st+dr)/2;
        if(s[mj]<v[i])st=mj;
        else dr=mj;
      }
      s[dr]=v[i];
      poz[i]=dr;
      
    }
    
  }
  out<<lg<<'\n';
  afisare(lg,n, 2000000001);
	return 0;
}