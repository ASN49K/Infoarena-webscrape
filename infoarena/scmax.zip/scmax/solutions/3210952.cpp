#include <fstream>
#include <deque>
using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

int main()
{
    int n,i,a,st,dr,rasp,mij;
    deque<int> s;
    cin>>n>>a;s.push_back(a);
    for(i=2;i<=n;i++){
        cin>>a;
        if(a>s.back()){
            s.push_back(a);
        }else{
            st=0;dr=rasp=s.size()-1;
            while(st<=dr){
                mij=(st+dr)/2;
                if(s[mij]>=a){
                    dr=mij-1;rasp=mij;
                }else{
                    st=mij+1;
                }
            }
            s[rasp]=a;
        }
    }
    cout<<s.size()<<"\n";
    for(i=0;i<s.size();i++) cout<<s[i]<<" ";
    return 0;
}
