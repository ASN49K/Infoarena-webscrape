#include<fstream>
using namespace std;
ifstream in("scmax.in");
ofstream out("scmax.out");
int a[100007],x[100007],t[100007],n,i,j,s,p,u,m;
void output(int nr)
{
    if(nr)
    {
        output(t[nr]);
        out<<a[nr]<<" ";
    }
}
int main()
{
    in>>n;
    for(i=1;i<=n;i++)in>>a[i];
    x[1]=1, s=1;
    for(i=2;i<=n;i++)
    {
        p=1, u=s;
        while(p<=u)
        {
            m=(u+p)/2;
            if(a[i]>a[x[m]]) p=m+1;
            else u=m-1;
        }
        if(p>s) s++;
        x[p]=i, t[i]=x[p-1];
    }

    out<<s<<"\n";
    output(x[s]);    
    return 0;

}
