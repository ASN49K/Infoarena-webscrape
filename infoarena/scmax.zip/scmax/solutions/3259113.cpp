#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

/**
Sa se determine lungimea maxima a unui subsir crescator
n <= 10^5 in complexitate O(n log n)

9
3 2 1 4 3 5 6 9 2 4 5 7 8 2 10

dp[i] = capatul din dreapta minim al unui subsir de lungime i
     1 2 3 4 5 6
dp = 3
dp = 2
dp = 1
dp = 1 4
dp = 1 3
dp = 1 3 5
dp = 1 3 5 6
dp = 1 3 5 6 9
dp = 1 2 4 5 7 8
dp = 1 2 2 5 7 8

Presupunand ca avem construit deja din a[1..i-1]
vectorul dp de lungime k, avem de adaugat pe a[i].
Avem cazurile:
1. dp[k] <= a[i] => k++ si dp[k]=a[i]
2. dp[k] > a[i] => cautam binar in dp (care este mereu
    ordonat crescator) cea mai din stanga pozitie p cu
    a[i] < dp[p]) si apoi facem dp[p] = a[i];
Solutia problemei este k.
*/

int a[100002], dp[100002], n, k, sol[100002], poz[1000002];

/// cauta cea mai din stanga pozitie p cu x < dp[p]
int CautBin(int x)
{
    if (x < dp[1]) return 1;
    int st, dr, mij, p;
    st = 1; dr = p = k;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (x <= dp[mij])
        {
            p = mij;
            dr = mij - 1;
        }
        else st = mij + 1;
    }
    return p;
}

int main()
{
    int i, j, aux;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i];
    dp[1] = a[1]; k = 1;
    for (i = 2; i <= n; i++)
        if (dp[k] < a[i]) {dp[++k] = a[i]; poz[i] = k;}
        else
        {
            j = CautBin(a[i]);
            dp[j] = a[i];
            poz[i] = j;
        }
    fout << k<<"\n";
    aux = k;
    for(i = n; i >= 1; i--)
    {
        if(poz[i] == aux)
        {
            sol[aux]=a[i];
            aux--;
        }
    }
    for(i = 1; i <= k; i++)
        fout << sol[i] << " ";
    return 0;
}
