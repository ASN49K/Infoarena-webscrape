#include <fstream>
#include <vector>
std::ifstream fin("scmax.in");
std::ofstream fout("scmax.out");

int n, v[100], sol[100], mx_dist = 1, pred[100], size = 0;
int main(){
    fin >> n;
    for(int i = 1; i <= n; i++){
        fin >> v[i];
    }
    int k = 1;
    sol[1] = 1; 
    for(int i = 2; i <= n; i++){
        if(v[i] > v[sol[k]]){
            sol[++k] = i;
            pred[i] = sol[k - 1];
        }
        else{
            int left = 1, right = k, poz;
            while(left <= right){
                int mid = left + (right - left)/2;
                if(v[i] <= v[sol[mid]]){
                    poz = mid;
                    right = mid - 1;
                }
                else if(v[i] > v[sol[mid]]){
                    left = mid + 1;
                }
            }
            sol[poz] = i; 
            pred[i] = sol[poz - 1];
            //std::cout << i << " " << poz << "\n";
        }
    }
    fout << k << "\n";
    int j = sol[k];
    fout << "\n";
    std::vector<int> res;
    while(j != 0){
        //std::cout << v[j] << " ";
        res.push_back(v[j]);
        j = pred[j];
    }
    for(int i = res.size() - 1; i >= 0; i --){
        fout << res[i] << " ";
    }
}