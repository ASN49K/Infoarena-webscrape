#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, v[600001], k, D[600001], P[600001], I[600001];

int main()
{
    cin >> n;
    for (int i=1; i<=n; i++)
    {
        cin >> v[i];
    }
    k=1;
    D[k]=v[1];
    P[1]=1;
    for(int i=2; i<=n; i++)
        if(v[i] > D[k])
            D[++k]=v[i], P[i]=k;
        else
        {
            int st=1, dr=k, p=k+1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(D[m]>v[i])
                    p=m, dr=m-1;
                else
                    st=m+1;
            }
            D[p]=v[i];
            P[i]=p;
        }
    int j=n;
    for(int i = k ; i >= 1 ; i --)
    {
        while(P[j]!=i) j--;
        I[i]=j;
    }
    cout << k << endl;
    cout << v[I[1]] << " ";
    for (int i=2; i<=k; i++)
    {
        cout << v[I[i]] << " ";
    }
    return 0;
}
