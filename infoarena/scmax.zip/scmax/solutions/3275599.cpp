#include <fstream>
using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

int n, v[100001], i, dp[100001], maxim;

int main()
{
    cin >> n;
    for(i = 1; i <= n; ++i)
        cin >> v[i];
    dp[n] = 1;
    for(i = n - 1; i >= 1; --i)
        for(int j = i + 1; j <= n; ++j) {
            if(v[i] < v[j] && dp[j] > dp[i])
                dp[i] = dp[j] + 1;
            maxim = max(maxim, dp[j]);
            }

    cout << maxim << '\n';
    for(i = 1; i <= n; ++i) {
        if(!maxim) break;
        if(dp[i] == maxim) {
            cout << v[i] << " ";
            maxim--;
        }
    }


    return 0;
}
