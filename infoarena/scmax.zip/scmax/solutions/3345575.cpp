#include <iostream>
#include <fstream>
#include <unordered_map>
#include <algorithm>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX=1e5+5;
unordered_map<int, int> um;
int n, i;
int aib[NMAX], v[NMAX], a[NMAX];

void update(int p, int x){
    for(int i=p;i<=n;i+=(i&-i))
        aib[i]=max(aib[i], x);
}

int query(int p){
    int ans=0;
    for(int i=p-1;i>0;i-=(i&-i))
        ans=max(ans, aib[i]);

    return ans;
}

int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>v[i];
        a[i]=v[i];
    }

    sort(a+1,  a+n+1);

    int cnt=0;
    for(i=1;i<=n;i++){
        if(a[i]!=a[i-1])
            um[a[i]]=++cnt;
    }

    for(i=1;i<=n;i++){
        int poz=um[v[i]];
        //cout<<poz<<'\n';
        int l=query(poz);
        update(poz, l+1);
    }

    fout<<query(n);



    return 0;
}
