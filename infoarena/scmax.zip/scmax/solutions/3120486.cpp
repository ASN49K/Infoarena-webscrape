#include <fstream>

using namespace std;


ifstream cin("scmax.in");
ofstream cout("scmax.out");


const int N = 1e5;
int n, lg;
int v[N+1], cresc[N+1], len[N+1], rasp[N+1];


int cb(int st, int dr, int val) /// primul >=
{
    while (st <= dr)
    {
        int mij = (st+dr)/2;
        if (val <= cresc[mij])
            dr = mij-1;
        else
            st = mij+1;
    }
    return st;
}


int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> v[i];
    

    cresc[++lg] = v[1];
    len[1] = 1;
    for (int i = 2; i <= n; i++)
    {
        int poz = cb(1, lg, v[i]);
        cresc[poz] = v[i];
        len[i] = poz;
        if (lg < poz)
            lg = poz;
    }


    cout << lg << '\n';


    int ind = n;
    while (len[ind] != lg)
        ind--;
    
    int l = lg;
    rasp[l] = v[ind];
    while (l > 1)
    {
        ind--;
        if (len[ind] == l-1)
        {
            l--;
            rasp[l] = v[ind];
        }
    }


    for (int i = 1; i <= lg; i++)
        cout << rasp[i] << ' ';


    return 0;
}