#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

#define cin fin
#define cout fout

#define DIM 100005
#define oo 2000000005

int n,v[DIM],lg[DIM],w[DIM],prec[DIM],plg[DIM],ans,k;

void cautare(int x, int n)
{
    int st=1, dr=n;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(lg[mij]<x) dr=mij-1;
        else st=mij+1;
    }
    ans=dr;
}

int main()
{
    cin>>n; lg[0]=oo; k=0;
    for(int i=1;i<=n;i++) cin>>v[i];
    for(int i=n;i>0;i--)
    {
        ans=0;
        cautare(v[i],k);
        if(ans==k && lg[k]!=v[i])
        {
            k++; lg[k]=v[i];plg[k]=i;
            prec[i]=plg[k-1];
            w[i]=k;
        }
        else if(v[i]>lg[ans+1])
        {
            lg[ans+1]=v[i];
            plg[ans]=i;
            prec[i]=plg[ans-1];
            w[i]=ans+1;
        }
    }
    cout<<k<<"\n";
    for(int i=plg[k]; i>0;i=prec[i]) cout<<v[i]<<" ";
    return 0;
}
