#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
struct sir
{
    vector<int> v;
}siruri[100001];
int cntsiruri;
int cb(int val)
{
    int st=1,dr=cntsiruri,mid,r=-1;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        if(val>siruri[mid].v[siruri[mid].v.size()-1])
        {
            r=mid;
            dr=mid-1;
        }
        else st=mid+1;
    }
    return r;
}
int main()
{
    int n,x,lmax=0,index;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>x;
        int pos=cb(x);
        if(pos==-1)
        {
            siruri[++cntsiruri].v.push_back(x);
            if(!lmax)
                index=cntsiruri;
            lmax=max(lmax,1);
        }
        else
        {
            siruri[pos].v.push_back(x);
            lmax=max(lmax,(int)siruri[pos].v.size());
            if(lmax==(int)siruri[pos].v.size())
                index=pos;
        }
    }
    fout<<lmax<<'\n';
    for(int i=0;i<siruri[index].v.size();i++)
        fout<<siruri[index].v[i]<<' ';
    return 0;
}
