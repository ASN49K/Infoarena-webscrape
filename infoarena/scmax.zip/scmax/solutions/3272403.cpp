#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

#define cin fin
#define cout fout

ifstream cin("scmax.in");
ofstream cout("scmax.out");

const int MAX = 1e5 + 7;
const int INF = 2e9 + 7;
int a[MAX];
int dp[MAX];
int p[MAX];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, pmax = 0;
    cin >> n;

    for (int i = 1; i <= n; ++i)
    {
        p[i] = INF;
    }

    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        int x = 0;
        int val = 2;
        while (val <= pmax)
        {
            val << 1;
        }
        while (val != 2)
        {
            if (x + val <= pmax && p[x + val] < a[i])
            {
                x += val;
            }
            val >> 1;
        }
        dp[i] = x + 1;
        p[dp[i]] = min(p[dp[i]], a[i]);
        pmax = max(pmax, dp[i]);
    }

    cout << pmax << '\n';

    vector <int> ans;
    for (int i = n; i > 0; --i)
    {
        if (dp[i] == pmax)
        {
            ans.push_back(a[i]);
            pmax--;
        }
    }

    for (vector<int>::reverse_iterator it = ans.rbegin(); it != ans.rend(); ++it)
    {
        cout << *it << " ";
    }
    return 0;
}
