#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("cmlsc.in");
ofstream fout("cmlsc.out");
int n, a[109], l[109], ant[109], acmax=0;
int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a[i];
    }
    l[n]=1;
    int pozmax=0;
    for(int i=n-1; i>=1; i--)
    {
        int maax=0, poz=0;
        for(int j=i+1; j<=n; j++)
        {
            if(a[j]>a[i] && l[j]>maax)
            {
                poz=j;
                maax=l[j];
            }
        }
        if(maax)
        {
            l[i]=maax+1;
            ant[i]=poz;
            if(l[i]>acmax)
            {
                acmax=l[i];
                pozmax=i;
            }
        }
    }
    cout<<acmax<<"\n";
    int i=pozmax;
    cout<<a[pozmax]<<" ";
    while(ant[i])
    {
        cout<<a[ant[i]]<<" ";
        i=ant[i];
    }
    return 0;
}
