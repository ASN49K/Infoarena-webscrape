#include <iostream>
#include <fstream>
#include <climits>
using namespace std;

const int MAX_N = 100005;
int n, sir[MAX_N], sol[MAX_N], k = 0;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int cautare(int x) {
    int dr = k, st = 0, mij, indi = -1;
    while (st <= dr) {
        mij = (dr + st) / 2;
        if (sol[mij] < x) {
            indi = mij;
            st = mij + 1;
        } else {
            dr = mij - 1;
        }
    }
    return indi;
}

int main() {
    fin >> n;
    for (int i = 1; i <= n; ++i) {
        fin >> sir[i];
    }

    sol[0] =INT_MIN;

    for (int i = 1; i <= n; ++i) {
        if (sir[i] > sol[k]) {
            sol[++k] = sir[i];
        } else {
            int pos = cautare(sir[i]);
            sol[pos + 1] = sir[i];
        }
    }

    fout << k << '\n';
    for (int i = 1; i <= k; ++i) {
        fout << sol[i] << ' ';
    }

    return 0;
}
