#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")
#pragma GCC target ("popcnt")

using namespace std;

ifstream fin  ("scmax.in");
ofstream fout ("scmax.out");

const int MAX_N = 100000;
const int LIM = 2000000000;

int n, v[MAX_N + 5];
int m, h[MAX_N + 5], p[MAX_N + 5], t[MAX_N + 5];
int st, md, dr, save;

inline void drum(int i){
    if(i != 0){
        drum(t[i]);
        fout<<v[i]<<" ";
    }
    return;
}

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr), fout.tie(nullptr);

    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>v[i];

    m = 0;
    h[0] = 0;
    for(int i=1; i<=n; i++){
        st = 0;
        dr = m;
        while(st <= dr){
            md = (st + dr) / 2;
            if(h[md] < v[i]){
                save = md;
                st = md + 1;
            }else{
                dr = md - 1;
            }
        }

        h[save+1] = v[i];
        p[save+1] = i;
        t[i] = p[save];
        if(save == m)
            m++;
    }

    fout<<m<<"\n";
    drum(p[m]);
    return 0;
}

