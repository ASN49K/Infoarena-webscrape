#include <bits/stdc++.h>

using namespace std;
int v[100005],dp[100005],last[100005],ans[100005];
int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
   int n,l=0,pos;
   cin>>n;
   for(int i=1;i<=n;i++)
   {
       cin>>v[i];
       if(v[i]>v[dp[l]])
       {

           l++;
           dp[l]=i;
          last[i]=dp[l-1];
       }
       else
       {
           pos=0;
           for(int pas=17;pas>=0;pas--)
           {
               if(pos+(1<<pas)<=l&&v[i]>v[dp[pos+(1<<pas)]])
               {
                  // cout<<pas<<" "<<i<<endl;
                pos+=(1<<pas);
               }

           }
               //cout<<pos<<" "<<i<<endl;
           last[i]=dp[pos];
           pos++;
           dp[pos]=i;
       }
     //  cout<<dp[1]<<" "<<i<<endl;


   }
   int curr=dp[l],lungime=0;
   while(curr!=0)
   {
       ans[lungime]=v[curr];
       lungime++;
       curr=last[curr];
   }
   reverse(ans,ans+lungime);
   cout<<lungime<<'\n';
   for(int i=0;i<lungime;i++)
    cout<<ans[i]<<" ";
    return 0;
}
