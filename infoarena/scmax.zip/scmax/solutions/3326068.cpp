#include <iostream>

using namespace std;

int main()
{
    int a[100],i,n,j,lung[100],poz[100];
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>a[i];
    lung[n]=1; poz[n]=-1;
    for(i=n-1;i>=1;i--)
    {lung[i]=1;poz[i]=-1;
        for(j=n;j>i;j--)
        if(a[i]<a[j]&&lung[i]<lung[j]+1)
        {
            lung[i]=lung[j]+1;
            poz[i]=j;
        }
    }
    cout << "Vectorul poz: ";
    for(i=1;i<=n;i++)  cout<<poz[i]<<" ";
    cout<<endl<<"Vectorul lung: ";
    for(i=1;i<=n;i++)
        cout<<lung[i]<<" ";
    return 0;
}
