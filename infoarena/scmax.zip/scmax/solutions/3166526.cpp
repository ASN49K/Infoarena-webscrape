#include <fstream>
#define DIM 100001
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,k,p,v[DIM],d[DIM],t[DIM];

int cautbin(int st,int dr,int x) {
    while (st<=dr) {
        int mid=(st+dr)/2;
        if (x>v[d[mid]])
            st=mid+1;
        else
            dr=mid-1;
    }
    return st;
}

void reconst(int i) {
    if (i!=0) {
        reconst(t[i]);
        fout<<v[i]<<" ";
    }
}

int main() {
    fin>>n;
    for (int i=1;i<=n;i++)
        fin>>v[i];
    k=1;
    d[1]=1;
    for (int i=2;i<=n;i++) {
        p=cautbin(1,k,v[i]);
        if (p>k) {
            d[++k]=i;
            t[i]=d[k-1];
        }
        else {
            d[p]=i;
            t[i]=d[p-1];
        }
    }
    fout<<k<<"\n";
    reconst(d[k]);
    return 0;
}
