#include <stdio.h>
#include <stdlib.h>
FILE *fi,*fo;
void afisare(int *A, int *e, int poz)
{
    if (poz!=-1)
    {
        afisare(A, e, e[poz]);
        fprintf(fo,"%d ",A[poz]);
    }
}
int main()
{
    fi=fopen("scmax.in","r");
    fo=fopen("scmax.out","w");
    int n,A[100001],lmax[100001],e[100001];
    fscanf(fi,"%d",&n);
    for (int i=0; i<n; i++)
        fscanf(fi,"%d", &A[i]);
    for (int i=0; i<n; i++)
        lmax[i]=1,e[i]=-1;
    for (int i=0; i<n; i++)
        for (int j=0; j<i; j++)
            if (A[i]>A[j] && 1+lmax[j]>lmax[i])
            {
                lmax[i]=1+lmax[j];
                e[i]=j;
            }
    int poz_max,val_max=0;
    for (int i=0; i<n; i++)
        if (lmax[i]>val_max)
        {
            val_max=lmax[i];
            poz_max=i;
        }
    ///Subsirul maximal ordonat strict crescator are lungime val_max
    afisare(A,e,poz_max);

    return 0;
}
