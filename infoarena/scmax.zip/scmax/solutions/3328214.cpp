#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

vector<int> v, dp, parent;
int n;

int main() {
    cin >> n;
    v.resize(n + 2);
    dp.resize(n + 2, 1);
    parent.resize(n + 2, -1);
    for (int i = 1 ; i <= n ; ++i) {
        cin >> v[i];
    }
    for (int i = 1 ; i <= n ; ++i) {
        for (int j = 1 ; j <= i ; ++j) {
            if (dp[j] + 1 > dp[i] && v[j] < v[i]) {
                dp[i] = dp[j] + 1;
                parent[i] = j;
            }
        }
    }
    int max_len = -1, poz = -1;
    for (int i = 1 ; i <= n ; ++i) {
        if (dp[i] > max_len) {
            max_len = dp[i];
            poz = i;
        }
    }
    vector<int> ans;
    for (int i = poz ; i != -1 ; i = parent[i]) {
        ans.push_back(v[i]);
    }
    reverse(ans.begin(), ans.end());

    cout << max_len << "\n";
    for (int elem : ans) {
        cout << elem << " ";
    }
    return 0;
}