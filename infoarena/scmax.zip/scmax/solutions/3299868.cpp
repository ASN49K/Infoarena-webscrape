#include <bits/stdc++.h>
#define ub(x) x&(-x)

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

const int nmax=1e5+5;

unordered_map <int,int> mp;
int n, v[nmax], a[nmax], dp[nmax], aib[nmax];

void normalizare ()
{
    for (int i=1; i<=n; i++)
        a[i]=v[i];
    sort(a+1,a+n+1);
    int nr=1;
    mp[a[1]]=1;
    for (int i=2; i<=n; i++)
    {
        if (a[i]!=a[i-1])
            mp[a[i]]=++nr;
    }
    for (int i=1; i<=n; i++)
        a[i]=mp[v[i]];
}

void update (int poz, int val)
{
    for (int i=poz; i<=n; i+=ub(i))
    {
        if (dp[val]>dp[aib[i]])
            aib[i]=val;
    }
}

int query (int poz)
{
    int rez=0;
    for (int i=poz; i>=1; i-=ub(i))
    {
        if (dp[aib[i]]>dp[rez])
            rez=aib[i];
    }
    return rez;
}

void afis (int i, int poz)
{
    if (i==0)
        return;
    if (dp[i]==dp[poz]-1 && v[i]<v[poz])
    {
        afis(i-1,i);
        cout << v[i] << " ";
    }
    else
        afis(i-1,poz);
}

int main ()
{
    fin >> n;
    for (int i=1; i<=n; i++)
        fin >> v[i];
    normalizare();
    for (int i=1; i<=n; i++)
    {
        dp[i]=dp[query(a[i]-1)]+1;
        update(a[i],i);
    }
    int rez=0;
    for (int i=1; i<=n; i++)
    {
        if (dp[i]>dp[rez])
            rez=i;
    }
    fout << dp[rez] << '\n';
    afis(rez,rez);
    fout << v[rez];
    return 0;
}
