#include <fstream>

#include <utility>
#define x first
#define y second

#include <algorithm>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

typedef pair <int, int> pii;
const int nmax = 1e5;
int n, a[nmax + 2], nvs;
pii norm[nmax + 2];

int dp[nmax + 2];
int actually[nmax + 2];
int stk[nmax + 2];

int bestt;

inline int f(int x){ return (x & (-x)); }
struct fenwicktree{
    int tree[nmax + 2];

    void updateadd(int pos, int val){
        for(int i = pos; i <= n; i += f(i))
            tree[i] = max(tree[i], val);
    }

    int query(int pos){
        int maxi = 0;
        for(int i = pos; i >= 1; i -= f(i))
            maxi = max(maxi, tree[i]);
        return maxi;
    }
} aib;

int main(){

    in>>n;
    for(int i = 1; i <= n; i++)
        in>>a[i], norm[i] = make_pair(a[i], i);

    sort(norm + 1, norm + 1 + n);

    for(int i = 1; i <= n; i++){
        nvs += (norm[i].x != norm[i - 1].x);
        actually[norm[i].y] = nvs;
    }

    for(int i = 1; i <= n; i++){
        dp[i] = 1 + aib.query(actually[i] - 1);
        aib.updateadd(actually[i], dp[i]);

        bestt = max(bestt, dp[i]);
    }

    out<<bestt<<"\n";
    for(int i = n; i >= 1; i--){
        if(dp[i] == bestt){
            stk[++stk[0]] = a[i];
            bestt -= 1;
        }
    }

    for(int i = stk[0]; i >= 1; i--)
        out<<stk[i]<<" ";

    return 0;
}
