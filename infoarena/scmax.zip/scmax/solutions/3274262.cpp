#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, v[100010], dp[100010];

signed main()
{
    fin >> n;
    for(int i=1; i<=n; i++) fin >> v[i];
    vector<int> rez;
    rez.push_back(v[1]), dp[1] = 1;
    for(int i=2; i<=n; i++) {
        if(v[i] > rez.back()) rez.push_back(v[i]), dp[i] = rez.size();
        else {
            int poz = lower_bound(rez.begin(), rez.end(), v[i]) - rez.begin();
            rez[poz] = v[i], dp[i] = poz;
        }
    }
    fout << rez.size() << '\n';
    int aux = rez.size();
    vector<int> bulan; ///habarnam dc nu mearsa primu da ma rog
    for(int i=n; i>=1; i--) {
        if(dp[i] == aux) {
            bulan.push_back(v[i]);
            aux--;
        }
    }
    reverse(bulan.begin(), bulan.end());
    for(int i : bulan) fout << i << " ";

    return 0;
}
