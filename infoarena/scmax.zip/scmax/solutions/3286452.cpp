#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int nmax = 100000;

int n;
int v[nmax + 5];
int norm[nmax + 5];

struct elem{
int val=0;
int poz=0;
};

elem a[4*nmax + 5];
int d[nmax + 5];
int t[nmax + 5];

elem best(elem a,elem b)
{
    if(b.val > a.val)
        return b;
    return a;
}


void update(int nod,int st,int dr,int poz,int val,int rpoz)
{
    if(st==dr)
    {
        a[nod].val = max(a[nod].val,val);
        a[nod].poz = rpoz;
        return;
    }
    int mid = (st+dr) /2;
    if(poz<=mid)
        update(nod*2,st,mid,poz,val,rpoz);
    else
        update(nod*2+1,mid+1,dr,poz,val,rpoz);
    a[nod]=best(a[nod*2],a[nod*2+1]);
}
elem query(int nod,int st,int dr,int x,int y)
{
    if(x<=st && dr<=y)
        return a[nod];
    int mid = (st+dr)/2;
    elem r1,r2;
    if(x<=mid) r1 = query(nod*2,st,mid,x,y);
    if(y>mid) r2=query(nod*2+1,mid+1,dr,x,y);
    return best(r1,r2);
}


int main()
{
    fin>>n;
    vector <int> ax;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        ax.push_back(v[i]);
    }
    sort(ax.begin(),ax.end());
    ax.resize(unique(ax.begin(),ax.end())-ax.begin());
    for(int i=1;i<=n;i++)
        norm[i] = lower_bound(ax.begin(),ax.end(),v[i])-ax.begin()+1;
    int nrmsz = ax.size();
    int sol = 0;
    int lt;
    for(int i=1;i<=n;i++)
    {
        if(norm[i]==1)
            d[i]=1;
        else{
            elem x = query(1,1,nrmsz,1,norm[i]-1);
            d[i] = x.val+1;
            t[i] = x.poz;
        }
        update(1,1,nrmsz,norm[i],d[i],i);
        if(d[i] > sol)
            lt = i,sol=d[i];
    }
    fout<<sol<<'\n';
    vector <int> ssz;
    while(t[lt]){
        ssz.push_back(lt);
        lt=t[lt];
    }
    ssz.push_back(lt);
    reverse(ssz.begin(),ssz.end());
    for(auto &i : ssz)
        fout<<v[i]<<' ';
}




