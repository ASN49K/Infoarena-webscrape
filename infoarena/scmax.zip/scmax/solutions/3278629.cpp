#include <bits/stdc++.h>
using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

void afis(int v[], int mare[], int last) {
    if (last == -1) return;
    else {
        afis(v, mare, mare[last]);
        g << v[last] << ' ';
    }
}

int main(void) {
    int n, v[1001], dp[1001], mare[1001], max = -1;
    f >> n;
    for (int i = 0; i < n; i++) {
        f >> v[i];
        dp[i] = 1;
        mare[i] = -1;
    }

    int last = -1;
    for (int i = 1; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (v[j] < v[i] && dp[i] < dp[j] + 1) {
                dp[i] = dp[j] + 1;
                mare[i] = j;
            }
        }

        if (dp[i] > max) {
            max = dp[i];
            last = i;
        }
    }

    g << max << '\n';
    
    afis(v, mare, last);
}