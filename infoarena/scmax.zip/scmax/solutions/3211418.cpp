
#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, i, k;
int v[100001], l[100001], w[100001];
int maxxl;

int main()
{
    fin>>n;
    for(i=1;i<=n;++i){
        fin>>v[i];
    }
    for(k=1;k<=n;++k){
        l[k]=1;
        for(i=1;i<k;++i){
            if(v[i]<v[k]){
                l[k]=max(l[k],l[i]+1);
            }
            if(maxxl<l[k]){
                maxxl=l[k];
            }
        }
    }
    
    fout<<maxxl<<endl;
    
    for(i=n;i>=2;--i){
        if(v[i]>v[i-1] && l[i]-l[i-1]==1 || l[i-1]==1){
            w[i]=v[i];
        }
    }

    sort(w+1, w+n+1);
    for(i=1;i<=n;++i){
        if(w[i]){
            fout<<w[i]<<" ";
        }
    }
    
    
    return 0;
}