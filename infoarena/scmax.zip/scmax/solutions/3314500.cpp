#include <fstream>

using namespace std;
int v[100005], prec[100005], sal[100005], afis[100005];
int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n, poz = 1, ok;
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >>v[i];
    }
    sal[0] = 1;
    for(int i = 2; i <= n; i++){
        ok = 0;
        int st = 0, dr = poz - 1, mij;
        while(st < dr){
            mij = (st + dr) / 2;
            if(v[sal[mij]] >= v[i]){
                dr = mij;
            }else{
                st = mij + 1;
            }
        }
        if(v[sal[dr]] >= v[i]){
            sal[dr] = i;
            prec[i] = sal[dr - 1];
            ok = 1;
        }
        if(ok == 0){
            sal[poz] = i;
            prec[i] = sal[poz - 1];
            poz++;
        }
    }
    cout << poz << "\n";
    int i = sal[poz - 1], j = 0;
    while(i > 0){
        afis[j] = v[i];
        j++;
        i = prec[i];
    }
    for(i = poz - 1; i >= 0; i--){
        cout << afis[i] << " ";
    }
    return 0;
}
