#include <bits/stdc++.h>

using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int a[100005], v[100005], poz[100005];
int n, k=0;
int cb(int x)
{
    int st=1, dr=k, poz=0;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(v[mij]>=x)
            poz=mij, dr=mij-1;
        else
            st=mij+1;
    }
    return poz;
}
int main()
{
    f >> n;
    for(int i=1; i<=n; i++)
        f >> a[i];
    v[1]=a[1];
    poz[1]=1;
    k=1;
    for(int i=2; i<=n; i++)
    {
        if(a[i]>v[k])
            v[++k]=a[i], poz[i]=k;
        else
        {
            int c=cb(a[i]);
            v[c]=a[i];
            poz[i]=c;
        }
    }
    g << k << '\n';
    stack<int>sol;
    for(int i=n; i>=1; i--)
    {
        if(poz[i]==k)
            sol.push(a[i]), k--;
    }
    while(!sol.empty())
        g << sol.top() << " ", sol.pop();
    return 0;
}
