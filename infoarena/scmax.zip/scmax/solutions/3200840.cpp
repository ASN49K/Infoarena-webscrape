#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

const int Nmax = 100005;
ofstream fout("scmax.out");

int a[Nmax], previ[Nmax];
vector<pair<int, int>> endVals;

void reconst(int pos) {
    if(previ[pos]) {
        reconst(previ[pos]);
    }
    fout << a[pos] << " ";
}

int main() {
    ifstream fin("scmax.in");
    int sol = 0, lastPos, n;
    fin >> n;
    for(int i = 1; i <= n; i++) {
        fin >> a[i];
        // lower_bound gaseste pozitia primului element >= val
        // upper_bound gaseste pozitia primului element > val
        // returneaza un iterator catre elementul gasit sau v.end() daca
        // elementul dorit nu exista
        auto it = lower_bound(endVals.begin(), endVals.end(), make_pair(a[i], 0));
        int poz = it - endVals.begin();
        if(it == endVals.end()) {
            endVals.push_back({a[i], i});
            poz = endVals.size() - 1;
        }
        else {
            endVals[poz] = {a[i], i};
        }
        if(poz) {
            previ[i] = endVals[poz - 1].second;
        }
        if(sol < poz + 1) {
            sol = poz + 1;
            lastPos = i;
        }
    }
    fout << sol << "\n";
    reconst(lastPos);
    return 0;
}
