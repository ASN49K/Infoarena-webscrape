#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int lmax=1;
int a[100005];
int l[100005];
int poz[100005];

int cautare(int x, int st, int dr)
{
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(l[mij]>=x)
            dr=mij-1;
        else
            st=mij+1;
    }
    return st;
}

void construire()
{
    l[lmax]=a[1];
    poz[1]=1;
    for(int i=2; i<=n; i++)
    {
        if(a[i]>l[lmax])
        {
            poz[i]=lmax+1;
            l[++lmax]=a[i];
        }
        else
        {
            ///caut pe ce pozitie merge bagat elementul a[i] int vec l
            int pozitie=cautare(a[i], 1, lmax);
            l[pozitie]=a[i];
            poz[i]=pozitie;
        }
    }
}

void afisare(int i=n, int pozmax=lmax)
{
    if(i>0)
    {
        if(poz[i]==pozmax)
        {
            afisare(i-1, pozmax-1);
            fout << a[i] << " ";
        }
        else
            afisare(i-1, pozmax);
    }
}

int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        fin >> a[i];
    construire();
    fout << lmax << "\n";
    afisare();
    return 0;
}
