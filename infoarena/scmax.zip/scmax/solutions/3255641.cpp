#include <bits/stdc++.h>

using namespace std;

ifstream fin( "scmax.in" );
ofstream fout( "scmax.out" );

#define MAXN 100000

int v[MAXN + 1], poz[MAXN + 1], rez[MAXN + 1], p[MAXN + 1];

int main() {
    int n, i, st, dr, mij, m, x, sol, maxi, l;

    fin >> n;
    for( i = 1; i <= n; i++ )
        fin >> v[i];

    m = 0;
    for( i = 1; i <= n; i++ ) {
        //vrem sa cautam binar in rez cel mai mic numar mai mare decat v[i]
        st = 1;
        dr = m;
        sol = -1;
        x = v[i];
        while( st <= dr ) {
            mij = ( st + dr ) / 2;
            if( rez[mij] >= x )
                dr = mij - 1, sol = mij;
            else
                st = mij + 1;
        }
        if( sol > -1 )
            rez[sol] = x, poz[i] = sol;
        else
            rez[++m] = x, poz[i] = m;
    }
    maxi = 0;
    for( i = 1; i <= n; i++ )
        maxi = max( maxi, poz[i] );
    fout << maxi << '\n';
    i = n;
    l = 0;
    while( i >= 1 && maxi > 0 ) {
        if( poz[i] == maxi ) {
            maxi--;
            p[++l] = v[i];
        }
        i--;
    }
    for( i = l; i >= 1; i-- )
        fout << p[i] << ' ';
    return 0;
}
