#include <stdio.h>
#include <vector>
#include <algorithm>

int main() {
  FILE *fin = fopen( "scmax.in", "r" );
  FILE *fout = fopen( "scmax.out", "w" );

  int n;
  fscanf( fin, "%d", &n );
  std::vector<int> v(n);
  for( int i = 0; i < n; i++ )
    fscanf( fin, "%d", &v[i] );

  auto not_idx_cmp = [&]( int a, int b ) -> bool {
    return v[a] < v[b];
  };
  
  std::vector<int> capete;
  std::vector<int> len(n);
  std::vector<int> prev(n);
  for( int i = 0; i < n; i++ ){
    auto mata = std::lower_bound( capete.begin(), capete.end(), i, not_idx_cmp );
    if( mata == capete.end() ){
      if( capete.size() )
        prev[i] = capete.back();
      else
        prev[i] = -1;
      
      capete.push_back( i );
      len[i] = (int)capete.size();
    }else{
      int idx = mata - capete.begin();
      if( idx == 0 ){
        prev[i] = -1;
        len[i] = 1;
        capete[idx] = i;
      }else{
        prev[i] = capete[idx - 1];
        len[i] = 1 + len[prev[i]];
        capete[idx] = i;
      }
    }
  }

  int i = std::max_element( len.begin(), len.end() ) - len.begin();
  std::vector<int> sol(1, i);
  while( prev[i] >= 0 )
    sol.push_back( i = prev[i] );

  std::reverse( sol.begin(), sol.end() );
  fprintf( fout, "%d\n", (int)sol.size() );
  for( int x : sol )
    fprintf( fout, "%d ", v[x] );
  fputc( '\n', fout );

  fclose( fin );
  fclose( fout );
  return 0;
}
