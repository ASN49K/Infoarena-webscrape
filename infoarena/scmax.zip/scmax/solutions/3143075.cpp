//#include <iostream>
#include <fstream>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int v[100005],top[100005],pre[100005],rev[100005];
int main() {
    int n,k=1;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
    }
    top[1]=1;
    for(int i=2;i<=n;i++){
        int st=1,dr=k;
        if(v[i]>v[top[dr]]){
            pre[i]=top[dr];
            k++;
            top[k]=i;
        }
        else{
            int sol=1;
            while(st<=dr){
                int mid=(st+dr)/2;
                if(v[top[mid]]>=v[i]){
                    sol=mid;
                    dr=mid-1;
                }
                else {
                    st = mid + 1;
                }
            }
            top[sol]=i;
            pre[i]=top[sol-1];
        }
    }
    cout<<k<<"\n";
    int nod=top[k],contor=0;
    while(nod!=0){
        rev[++contor]=v[nod];
        nod=pre[nod];
    }
    for(int i=contor;i>=1;i--){
        cout<<rev[i]<<" ";
    }
    return 0;
}
