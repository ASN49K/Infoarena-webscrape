#include <bits/stdc++.h>

using namespace std;

ifstream f ("text.in");
ofstream g ("text.out");

string s;
bitset<100001> c;
int cnt;


int main()
{
    int size = 0;
    getline(f, s);

   for(int i=0; i<s.size(); i++)
        if(!isalpha(s[i]))
            c[i] = 1;
    
    int last = 0;
    
    for(int i=0; i<s.size(); i++)
        if(c[i] == 0)
            size++;
    
    for(int i=s.size()-1; i>=0; i--)
        if(c[i] == 1)
            last = i;
    
    for(int i=last+1; i<s.size(); i++){
        if(c[i] == 1){
            if(i - last > 1)
                cnt ++;
            last = i;
        }
    }
    
    if(cnt == 0) g << 0;
    else
    g << size/cnt;

    

    return 0;
}
