#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int nmax = 100000;

int n;

int v[nmax + 5];
int t[nmax + 5];
int stv[nmax + 5];
int st_sz;

int find_st_pos(int val) {
    int st = 1;
    int dr = st_sz;
    int bst = -1;
    while (st <= dr) {
        int mid = (st + dr)/2;
        if (v[stv[mid]] >= val) {
            dr = mid - 1;
            bst = mid;
        }
        else  st = mid + 1;
    }
    return bst;

}

int main()
{
    fin>>n;
    for (int i = 1; i <= n; i++) {
        fin>>v[i];
        int pp = find_st_pos(v[i]);
        if (pp == 1)   st_sz = max(st_sz, 1), stv[1] = i, t[i]= -1;
        else if (pp == -1) {
            stv[++st_sz] = i;
            t[i] = (st_sz != 1) ? stv[st_sz - 1] : -1;
        }
        else stv[pp] = i, t[i] = stv[pp - 1];
    }
    fout<<st_sz<<'\n';
    int q = stv[st_sz];
    vector <int> s;
    while(t[q] != -1) {
        s.push_back(v[q]);
        q = t[q];
    }
    s.push_back(v[q]);
    while(!s.empty()) {
        fout<<s.back()<<' ';
        s.pop_back();
    }
}
