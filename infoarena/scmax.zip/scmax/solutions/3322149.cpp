#include <iostream>
#include <cstring>
#include <cmath>
#include <fstream>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int a[100002], lis[100002], poz[100002], sol[100002];
int n, k, len;

int CB(int x)
{
	int st, dr, mij, pos;
	st = 1; dr = pos = k;
	while (st <= dr)
	{
		mij = (st + dr) / 2;
		if (a[mij] < x) st = mij + 1;
		else
		{
			pos = mij;
			dr = mij - 1;
		}
	}
	return pos;
}

int main()
{
	int i, j;
	fin >> n;
	for (i = 1; i <= n; i++)
		fin >> a[i];
	lis[++k] = a[1];
	poz[1] = 1;
	for (i = 2; i <= n; i++)
	{
		int x = a[i];
		if (x > lis[k])
		{
			lis[++k] = x;
			poz[i] = k;
		}
		else if (x <= lis[1])
		{
			lis[1] = x;
			poz[i] = 1;
		}
		else
		{
			j = CB(x);
			lis[j] = x;
			poz[i] = j;
		}
	}
	fout << k << "\n";
	for(i = n; i >= 1 && k; i--)
		if (poz[i] == k)
		{
			sol[++len] = a[i];
			k--;
		}
	for (i = len; i >= 1; i--)
		fout << sol[i] << " ";
	return 0;
}