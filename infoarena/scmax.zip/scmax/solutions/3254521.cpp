#include <fstream>
using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int dp[100005],poz[100005],v[100005],n;
void afis(int k, int dr)
{
    for(int i=dr;i>=1;i--)
        if(poz[i]==k)
    {
        if(k>1);
            afis(k-1,i-1);
        g<<v[i]<<" ";
        break;
    }
}
int main()
{
    int k=0;
    f>>n;
    for(int i=1;i<=n;i++)
    {
        int x;
        f>>x;
        v[i]=x;
        int st=0, dr=k+1;
        dp[dr]=2000000005;
        if(dp[k]<x)
            dp[++k]=x, poz[i]=k;
        else while(st<dr)
        {
            int mijl=(st+dr+1)/2;
            if(dp[mijl-1]<x&&dp[mijl]>x)
            {
                dp[mijl]=x;
                poz[i]=mijl;
                break;
            }
            else if(dp[mijl-1]<x) st=mijl;
                 else dr=mijl-2;
        }
    }
    g<<k<<'\n';
    afis(k,n);
    return 0;
}