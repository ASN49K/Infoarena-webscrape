#include<bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, v[100002], tata[100002], u[100002],k;

int cb(int x){

    int st, dr, mij, ans=0;

    st=1;
    dr=k;

    while(st <= dr){
        mij = (st+dr) / 2;
        if(v[u[mij]] < x){
            ans = mij;
            st = mij+1;
        }
        else
            dr = mij-1;
    }
    if(ans == k)
        k++;
    return ans;
}

void afis(int p){
    if(p){
        afis(tata[p]);
        fout << v[p] << " ";
    }
}

int main(){

    int i,j,poz;

    fin >> n;

    for(i=1;i<=n;i++)
        fin >> v[i];

    for(i=1;i<=n;i++){
        poz = cb(v[i]);
        u[poz+1] = i;
        tata[i] = u[poz];
    }

    fout << k << '\n';
    afis(u[k]);
}
