#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, a[100005], l[100005];

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>a[i];
    }
    int maax=-1;
    for(int i=n; i>0; i--)
    {
        for(int j=i+1; j<=n; j++)
            if(a[i]<a[j])
            {
                l[i]=max(l[i], l[j]+1);
                maax=max(maax, l[i]);
            }
    }
    fout<<maax+1<<"\n";
    for(int i=1; i<=n; i++)
    {
        if(l[i]==maax)
        {
            fout<<a[i]<< " ";
            maax--;
        }
    }
    return 0;
}
