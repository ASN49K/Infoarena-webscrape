#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int NMAX = 1e5 + 1, INF = INT_MAX;
int n, arr[NMAX], dp[NMAX], parent[NMAX], idx[NMAX];

vector<int> get_subsir(int length)
{
    vector<int> subsir;
    int i = idx[length];
    while(i != 0)
    {
        subsir.push_back(arr[i]);
        i = parent[i];
    }
    reverse(subsir.begin(), subsir.end());
    return subsir;
}

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> arr[i];
    fill(dp + 1, dp + n + 1, INF);
    dp[0] = -INF;
    for(int i = 1; i <= n; i++)
    {
        int l = upper_bound(dp + 1, dp + n + 1, arr[i]) - dp;
        if(dp[l-1] < arr[i] && arr[i] < dp[l])
        {
            dp[l] = arr[i];
            idx[l] = i;
            parent[i] = idx[l - 1];
        }
    }
    int max_length = -1;
    for(int i = 1; i <= n; i++)
        if(dp[i] != INF && i > max_length)
            max_length = i;
    fout << max_length << "\n";
    vector<int> subsir = get_subsir(max_length);
    for(int i : subsir)
        fout << i << " ";

    fin.close();
    fout.close();
    return 0;
}
