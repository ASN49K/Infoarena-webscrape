#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    int a[100],i,n,j,lung[100],poz[100];
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i];
        lung[n]=1;poz[n]=-1;
    for(i=n-1;i>=1;i--)
    {
        lung[i]=1;poz[i]=-1;
        for(j=n;j>i;j--)

            if(a[i]<a[j]&&lung[i]<lung[j]+1)
        {
            lung[i]=lung[j]+1;
            poz[i]=j;
        }
    }
    int maxi=lung[1];
    for(i=1;i<=n;i++)
        if(maxi<lung[i]) maxi=lung[i];
    fout<<maxi<<endl;
    for(i=1;i<=n;i++)
    if(lung[i]==maxi) {fout<<a[i]<<" "; maxi--;}
    return 0;
}
