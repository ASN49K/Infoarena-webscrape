#include <fstream>
#include <vector>
using namespace std;

int main() {
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");

    int N;
    fin >> N;
    vector<int> a(N + 1);
    for (int i = 1; i <= N; i++) fin >> a[i];

    vector<int> dp(N + 1, 1), prev(N + 1, 0);
    int Lmax = 1, poz = 1;

    for (int i = 2; i <= N; i++) {
        for (int j = 1; j < i; j++) {
            if (a[j] < a[i] && dp[j] + 1 > dp[i]) {
                dp[i] = dp[j] + 1;
                prev[i] = j;
            }
        }
        if (dp[i] > Lmax) {
            Lmax = dp[i];
            poz = i;
        }
    }

    // Reconstruim subsirul
    vector<int> subsir;
    while (poz != 0) {
        subsir.push_back(a[poz]);
        poz = prev[poz];
    }

    fout << Lmax << "\n";
    for (int i = subsir.size() - 1; i >= 0; i--)
        fout << subsir[i] << " ";

    fin.close();
    fout.close();
    return 0;
}
