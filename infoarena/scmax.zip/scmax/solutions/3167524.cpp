#include <fstream>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,v[100001],d[100001],lmax;
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        d[i]=2000000001;
    }
    d[1]=v[1];
    lmax=1;
    for(int i=2;i<=n;i++)
    {
        int st=1,dr=lmax,mid=0,poz=0;
        while(st<=dr)
        {
            mid=(st+dr)/2;
            if(v[i]>d[mid])
            {
                st=mid+1;
                poz=mid;
            }
            else
                dr=mid-1;
        }

            if(poz==lmax)
                lmax++;
            if(d[poz+1]>v[i]){
                d[poz+1]=v[i];

            }


    }
    fout<<lmax<<"\n";
    for(int i=1;i<=lmax;i++)
        fout<<d[i]<<" ";

    return 0;
}
