
#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n,k,v[200005],i,l[200005],maxx,lmax,w[200005],j;
int main()
{
    fin>>n;
    for(i=1;i<=n;++i)
    {
        fin>>v[i];
    }
    for(k=1;k<=n;++k)
    {
        l[k]=1;
        for(i=1;i<k;++i)
        {
            if(v[i]<v[k])
            {
                l[k]=max(l[k],l[i]+1);
            }
        }
    }
    lmax=*max_element(l+1,l+1+n);
    fout<<lmax<<endl;
    i=n;
    j=1;
    while(i>0)
    {
        if(l[i]==lmax)
        {
            lmax--;
            w[j]=v[i];
            j++;
        }
        i--;
    }
    
    for(i=j-1;i>=1;--i)
    {
        fout<<w[i]<<" ";
    }
    return 0;
}