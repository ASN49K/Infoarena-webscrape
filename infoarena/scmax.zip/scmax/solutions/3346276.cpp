#include <bits/stdc++.h>

using namespace std;
ifstream f("scmax.in");
ofstream g("scmax.out");
int a[100005], v[100005];
int main()
{
    int n;
    f >> n;
    for(int i=1; i<=n; i++)
        f >> a[i];
    int nrmax=0, maxi;
    for(int i=n; i>=1; i--)
    {
        maxi=0;
        for(int j=i+1; j<=n; j++)
        {
            if(a[j]>a[i]&&v[j]>maxi)
            {
                maxi=v[j];
            }
        }
        v[i]=maxi+1;
        if(v[i]>nrmax)
            nrmax=v[i];
    }
    g << nrmax << '\n';
    for(int i=1; i<=n; i++)
    {
        if(v[i]==nrmax)
            g << a[i] << " ", nrmax--;
    }
    return 0;
}
