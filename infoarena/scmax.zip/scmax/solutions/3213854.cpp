﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 106
#define MOD 1999999973
#define INF 2012345678
#define ll long long
using namespace std;
//#define fin cin
//#define fout cout

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int a[nmax];
int dp[nmax], lg;
int poz[nmax], sol [nmax];

int CB(int x)
{
    if (dp[1] > x)
        return 1;

    if (dp[lg] < x)
        return (++lg);

    int st, dr, m, p;
    st = 1; dr = lg; p = n + 1;
    while (st <= dr)
    {
        m = (st + dr) / 2;
        if (dp[m] > x)
        {
            p = m;
            dr = m - 1;
        }
        else
            st = m + 1;
    }
    return p;
}

int main()
{
    int i, p;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];

    lg = 1;
    dp[1] = a[1];
    poz[1] = 1;
    for (i = 2; i <= n; i++)
    {
        p = CB(a[i]);
        dp[p] = a[i];
        poz[i] = p;
    }

    fout << lg << "\n";
    p = lg;
    for (i = n; i >= 1 && p > 0; i--)
        if (poz[i] == p)
        {
            sol[p] = a[i];
            p--;
        }
    for (i = 1; i <= lg; i++)
        fout << sol[i] << " ";
    fin.close();
    fout.close();
    return 0;
}