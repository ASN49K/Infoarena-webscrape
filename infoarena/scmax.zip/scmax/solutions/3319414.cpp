
#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main()
{
    int N=100000;
    int v[N],a[N],f[N],k=1,lungk=0,lmax=0,c=0,l=0;
    int n;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        fin>>v[i];
    }
    for(int i=0;i<n-1;i++)
    {
        c=i;
        for(int j=i+1;j<n;j++)
        {
          if(v[c]<v[j])
          {
              a[k]=v[j];
              k++;
              lungk++;
              c=j;
          }
        }
        if(c!=i)
        {
            a[0]=v[i];
        }
        if(lmax<lungk)
        {
            int b=i;
            int d=c;
            for(int i=0;i<k;i++)
            {
                f[i]=a[i];
            }
            l=k-1;
            k=0;
            lmax=lungk+1;
            lungk=0;
        }
    }
    fout<<lmax;
    fout<<"\n";
    for(int i=0;i<=l;i++)
    {
        fout<<f[i]<<" ";
    }
    fin.close();
    fout.close();
}