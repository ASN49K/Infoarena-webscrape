#include <fstream>
#include <vector>

using namespace std;

void refac_subsir(int p, int lungime, vector <int> &x, vector <int> &lung, int v_min, ofstream &out) {
    if (lungime == 0) {
        return;
    }
    if (lung[p] == lungime && x[p] <= v_min) {
        refac_subsir(p - 1, lungime - 1, x, lung, x[p] - 1, out);
        out << x[p] << " ";
    } else {
        refac_subsir(p - 1, lungime, x, lung, v_min, out);
    }
}

int main() {
    ifstream in("scmax.in");
    ofstream out("scmax.out");
    int n;
    in >> n;
    vector <int> x(n);
    vector <int> lung(n, 0);
    int p_max = 0;
    for (int i = 0; i < n; i++) {
        in >> x[i];
        int l_i = 0;
        for (int j = 0; j < i; j++) {
            if (x[j] < x[i]) {
                l_i = max(l_i, lung[j]);
            }
        }
        lung[i] = 1 + l_i;
        if (lung[i] > lung[p_max]) {
            p_max = i;
        }
    }
    in.close();
    out << lung[p_max] << "\n";
    refac_subsir(p_max, lung[p_max], x, lung, x[p_max], out);
    out << "\n";
    out.close();
    return 0;
}