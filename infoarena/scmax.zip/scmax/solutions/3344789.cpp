#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

// ifstream in("scmax.in");
// ofstream out("scmax.out");

/*
dp[i] = lungimea celui mai lung subșir(lungime SCMAX) folosind (doar o parte) 
        din primele i elemente din vectorul v și care se termină pe poziția i
*/

int scmax(int n, vector<int>&v, vector<int>&elemente)
{
    vector<int> dp(n + 1, 1), pred(n + 1, 0);
    dp[1] = 1;
    for(int i = 2; i <= n; i++)
    {
        dp[i] = 1;
        for(int j = 1; j <= i - 1; j++)
        {
            if(v[j] < v[i])
            {
                if (dp[j] + 1 > dp[i]) 
                {
                    pred[i] = j;
					dp[i] = dp[j] + 1;
				}
            }
        }
    }

    //solutia este elementul maxim din dp
    auto it = max_element(dp.begin() + 1, dp.begin() + n + 1);
    int max_val_dp = *it;                  // valoarea maxima
    int poz = it - dp.begin();

    // reconstruim in elemente[1..L], de la final la inceput
    for (int k = max_val_dp; k >= 1; k--)
    {
        elemente[k] = v[poz];
        poz = pred[poz];
    }

    return max_val_dp;
}

int main()
{
    int n;
    vector<int> a(100001), elemente(100001);
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    cout << scmax(n, a, elemente) << "\n";
    for(int i = 1; i <= scmax(n, a, elemente); i++)
    {
        cout << elemente[i] << " ";
    }
    cout << "\n";

    // in.close();
    // out.close();
    return 0;
}