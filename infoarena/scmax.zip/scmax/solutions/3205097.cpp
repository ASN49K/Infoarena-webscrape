#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

int main() {
    int n;
    fin>>n;
    int x, y;
    int aux;
    int lungime, lungimeMax;
    lungime=lungimeMax=0;
    fin>>x;
    while(fin>>y){
{
    if(x<=y){
        lungime++;
    }else{
        lungime=0;
    }
    if(lungime>=lungimeMax){
        lungimeMax= lungime;}
}
    x=y;

    }
    fout<<lungimeMax;
  fin.close();
    fout.close();
    return 0;
}
