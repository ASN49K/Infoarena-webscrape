//#pragma GCC optimize("O3, Ofast, unroll-loops")
#include <bits/stdc++.h>
#define int long long
using namespace std;
int v[100005], dp[100005], v2[100005], v3[100005];
signed main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n, maxx=0, rez, poz=1;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
        dp[i]=1;
        v2[i]=i;
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=i+1; j<=n; j++)
        {
            if(v[j]>v[i])
            {
                if(dp[i]+1>dp[j])
                {
                    dp[j]=dp[i]+1;
                    v2[j]=i;
                }
                if(maxx<dp[j])
                {
                    maxx=dp[j];
                    rez=j;
                }
            }
        }
    }
    cout<<maxx<<'\n';
    v3[poz++]=v[rez];
    while(v2[rez]!=rez)
    {
        v3[poz++]=v[v2[rez]];
        rez=v2[rez];
    }
    for(int i=poz-1; i>0; i--)
    {
        cout<<v3[i]<<" ";
    }
    return 0;
}

