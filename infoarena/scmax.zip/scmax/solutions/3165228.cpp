#include<bits/stdc++.h>
using namespace std;

const int MAX = 1e5 + 5;
pair<int, vector<int>> segtree[2*MAX];
ifstream fin("scmax.in");
ofstream fout("scmax.out");

void update(int pos, vector<int> val, int node = 1, int start = 0, int end = MAX) {
    if(start == end) {
        segtree[node] = {val.size(), val};
    } else {
        int mid = (start + end) / 2;
        if(pos <= mid) {
            update(pos, val, 2*node, start, mid);
        } else {
            update(pos, val, 2*node+1, mid+1, end);
        }
        segtree[node] = max(segtree[2*node], segtree[2*node+1]);
    }
}

pair<int, vector<int>> query(int l, int r, int node = 1, int start = 0, int end = MAX) {
    if(r < start || end < l) {
        return {0, {}};
    }
    if(l <= start && end <= r) {
        return segtree[node];
    }
    int mid = (start + end) / 2;
    return max(query(l, r, 2*node, start, mid), query(l, r, 2*node+1, mid+1, end));
}

int main() {
    int n;
    fin >> n;
    vector<pair<int, pair<int, int>>> a(n);
    for(int i = 0; i < n; i++) {
        fin >> a[i].first;
        a[i].second.first = i;
        a[i].second.second = a[i].first;
    }

    sort(a.begin(), a.end());
    for(auto &it : a) {
        vector<int> lis = query(0, it.second.first).second;

        if(lis.empty() || lis.back() < it.second.second) {
            lis.push_back(it.second.second);
            update(it.second.first, lis);
        }
    }

    vector<int> lis = segtree[1].second;
    fout << lis.size() << "\n";
    for(int x : lis)
        fout << x << " ";

    cout << "\n";
    return 0;
}
