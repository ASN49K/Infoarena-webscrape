#include <fstream>
#include <iostream>

using namespace std;
int d[100005],v[100005];
int main()
{
   ifstream cin("scmax.in");
    ofstream cout("scmax.out");
  int n,ras=0;
  cin>>n;
  cin>>v[0];
  d[0]=1;
  for(int i=1;i<n;i++)
  {
      cin>>v[i];
      int maxx=0;
      for(int j=0;j<i;j++)
      {
          if(v[i]>v[j])
          {
              if(d[j]>maxx)
                maxx=d[j];
          }
      }
      d[i]=maxx+1;
      if(d[i]>ras)
        ras=d[i];
  }
  cout<<ras;



    return 0;
}
