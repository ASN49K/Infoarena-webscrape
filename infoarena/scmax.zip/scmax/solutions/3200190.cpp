#include <fstream>
using namespace std;
const int Vmax = 100001;
int a[Vmax];
pair<int, int> minVal[Vmax];
int lMax;
int n;
void inbetween(int st, int dr, int x, int i){
    if(st==dr){
        if(i > minVal[st].second && n-i <= lMax - st){
            return;
        }
        if(x <= minVal[st].first){
            minVal[st].first = x;
            minVal[st].second = i;
        }
        else{
            minVal[st+1].first = x;
            minVal[st+1].second = i;
        }
        return;
    }
    int mij = (st+dr)/2;
    if(x <= minVal[mij].first)
        return inbetween(st, mij, x, i);
    else    
        return inbetween(mij+1, dr, x, i);
}

int main(){
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>a[i];
    for(int i=1;i<=n;i++){
        if(minVal[lMax].first < a[i]){
            lMax++;
            minVal[lMax].first = a[i];
            minVal[lMax].second = i;
        }
        else
            inbetween(1, lMax, a[i], i);
    }
    fout<<lMax<<'\n';
    for(int i=1;i<=lMax;i++)
        fout<<minVal[i].first<<" ";
}