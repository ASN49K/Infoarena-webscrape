#include <fstream>
#include <iostream>

using namespace std;
    ofstream fout("scmax.out");

const int N = 100005;
int v[N], l[N],n,lmax,ant[N];

void f(int x) {
    if (x) {
        f(ant[x]);
        fout << v[x] << ' ';
    }
}

int main()
{
    ifstream fin("scmax.in");
    int i, j,poz,m,st,dr,mij;
    fin >> n;
    for (i = 1; i <= n; i++) {
        fin >> v[i];
    }
    fin.close();
    l[1] = m=1;
    for (i = 2; i <= n; i++) {
        st = 1;
        dr = m;
        while (st <= dr) {
            mij = (st + dr) / 2;
            if (v[l[mij]] < v[i]) {
                st = mij + 1;
            }
            else {
                dr = mij - 1;
            }
        }
        if (st > m) {
            m++;
            l[m] = i;
            ant[i] = l[ st- 1];
        }
        else {
            if (v[l[st]] > v[i]) {
                l[st] = i;
                ant[i] = ant[st - 1];
            }
        }
    }
    fout << m << '\n';
    f(l[m]);
    fout << "\n";
    return 0;
}