import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "scmax.in";
    static final String OUTPUT_FILE = "scmax.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    static class FenwickTreeMax {
        private final int[] value;
        private final int[] maxIndex;
        private final int n;

        public FenwickTreeMax(int n) {
            this.n = n;
            this.maxIndex = new int[n + 1];
            this.value = new int[n + 1];
            Arrays.fill(this.maxIndex, 0);
            Arrays.fill(this.value, 0);
        }

        public int queryMaxIdx(int index) {
            int currMaxIdx = 0;
            while (index > 0) {
                if (value[maxIndex[index]] > value[currMaxIdx]) {
                    currMaxIdx = maxIndex[index];
                }
                index -= (index & (-index));
            }
            return currMaxIdx;
        }

        public void update(int index, int posIdx) {
            int newValue = value[posIdx];
            while (index <= n) {
                if (newValue > value[maxIndex[index]]) {
                    maxIndex[index] = posIdx;
                }
                index += (index & (-index));
            }
        }
    }

    public static void solve(TokenizedReader reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        int[] a = new int[n + 1];
        int[] sorted = new int[n + 1];
        for (int i = 1; i <= n; ++i) {
            a[i] = sorted[i] = reader.nextInt();
        }
        Arrays.sort(sorted);
        // remove duplicates from sorted
        int cntUnique = 1;    // skip first
        for (int i = 2; i <= n; ++i) {
            if (sorted[i] != sorted[cntUnique]) {
                sorted[++cntUnique] = sorted[i];
            }
        }

        for (int i = 1; i <= n; ++i) {
            a[i] = Arrays.binarySearch(sorted, 1, cntUnique + 1, a[i]);
        }

        FenwickTreeMax fenwickTree = new FenwickTreeMax(n);
        for (int i = 1; i <= n; ++i) {
            int maxIdx = fenwickTree.queryMaxIdx(a[i] - 1);
            fenwickTree.value[i] = 1 + fenwickTree.value[maxIdx];
            fenwickTree.update(a[i], i);
        }
        int maxIdx = fenwickTree.queryMaxIdx(n);
        int best = fenwickTree.value[maxIdx];
        writer.println(best);
    }
}