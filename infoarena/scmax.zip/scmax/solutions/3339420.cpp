#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX = 100001;

int a[NMAX], d[NMAX], p[NMAX];
long long n, k;

void citire() {
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> a[i];
}

void aflare() {
    k = 1;
    d[1] = a[1];
    p[1] = 1;
    
    for(int i = 2; i <= n; i++) {
        if(a[i] > d[k]) {
               d[++k] = a[i];
               p[i] = k;
            } else {
            int rez;
            int st = 1, dr = k;
            
            while(st <= dr) {
                int mid = (st + dr) / 2;
                if(d[mid] >= a[i]) {
                    rez = mid;
                    dr = mid - 1;
                } else
                    st = mid + 1;
            }
            
            d[rez] = a[i];
            p[i] = rez;
        }
    }
}

void reconstituire() {
    fout << k << '\n';
    int j = n;
    
    for(int i = k; i >= 1; i--) {
        while(p[j] != i) j--;
        d[i] = j;
    }
    
    for(int i = 1; i <= k; i++)
        fout << a[d[i]] << ' ';
}

int main() {
    citire();
    aflare();
    reconstituire();
    
    return 0;
}