#include <bits/stdc++.h>
#define nmax 100002
#define inFile "scmax.in"
#define outFile "scmax.out"
using namespace std;

int a[nmax], lis[nmax], poz[nmax], n, k, rez[nmax];
/// lis[i]=capatul minim al unui subsir de lungime i
/// poz[i]=pozitia unde s-a inserat a[i] in vectorul lis

void Citire()
{
    int i;
    ifstream fin(inFile);
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i];
    fin.close();
}

/// caut in lis[1..k] cea mai din stanga pozitie m cu x <= lis[m]
int CautBin(int x)
{
    int st, dr, sol, m;
    st = 1; dr = k;
    sol = k;
    while (st <= dr)
    {
        m = (st + dr) / 2;
        if (x <= lis[m])
        {
            sol = m;
            dr = m - 1;
        }
        else st = m + 1;
    }
    return sol;
}

void LIS()
{
    int i, x, p;
    lis[1] = a[1];
    k = 1;
    poz[1] = 1;
    for (i = 2; i <= n; ++i)
    {
        x = a[i];
        if (x > lis[k])
        {
            lis[++k] = x;
            poz[i] = k;
        }
        else if (x <= lis[1])
        {
            lis[1] = x;
            poz[i] = 1;
        }
        else
        {
            /// caut in lis[1..k] cea mai din stanga pozitie p cu x <= lis[p]
            p = CautBin(x);
            lis[p] = x;
            poz[i] = p;
        }
    }
}

void Afisare()
{
    int i, L;
    ofstream fout(outFile);
    fout << k << "\n";
    L = k;
    for (i = n; i >= 1 && L > 0; --i)
        if (poz[i] == L)
        {
            rez[L] = a[i];
            L--;
        }
    for (i = 1; i <= k; i++)
        fout << rez[i] << " ";
    fout << "\n";
    fout.close();
}

int main()
{
    Citire();
    LIS();
    Afisare();
    return 0;
}
