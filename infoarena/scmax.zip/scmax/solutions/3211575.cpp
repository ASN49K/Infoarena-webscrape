#include <bits/stdc++.h>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int n,v[1000010],a[1000010],b[1000010],i,j,k,m,poz,min1;

int main()
{
    in>>n;    
    for(i=1;i<=n;i++)
        in>>v[i];
    a[0]=1;
    for(k=1;k<=n;k++){
        a[k]=1;
        for(i=1;i<k;i++)
            if(v[k]>v[i])
                a[k]=max(a[k],a[i]+1);
    }
    m=*max_element(a+1,a+n+1);
    out<<m<<'\n';
    poz=1;
    for(i=n;i>=1;i--){
        if(a[i]==m){
            b[poz++]=v[i];
            m--;
        }
    }
    for(i=poz-1;i>=1;i--)
        out<<b[i]<<" ";
    return 0;
}