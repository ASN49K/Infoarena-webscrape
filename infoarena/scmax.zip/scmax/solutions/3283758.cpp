#include <iostream>
#include <random>
#include <fstream>
#include <stack>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int a[100005], dp[100005], urm[100005];
int k;
int cb(int val)
{
    int st = 1, dr = k, mij;
    int sol=-1;
    while (st <= dr)
    {
        int mij = (st + dr) / 2;
        if (dp[mij] >= val)
        {
            sol = mij;
            dr = mij - 1;
        }
        else
            st = mij + 1;
    }
    return sol;
}
int main() 
{
    int n;
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i];
    k = 1;
    dp[1] = a[1];
    urm[1] = 1;
    for (int i = 2; i <= n; i++)
    {
        if (a[i] > dp[k])
        {
            dp[++k] = a[i];
            urm[i] = k;
        }
        else
        {
            int p = cb(a[i]);
            dp[p] = a[i];
            urm[i] = p;
        }
    }
    fout << k << "\n";
    int last = 1;
    for (int i = 2; i <= n; i++)
        if (urm[i] == k)
            last = i;
    stack<int> st;
    st.push(last);
    for(int i=last-1; i>=1;i--)
        if (a[i] < a[last] && urm[i] == urm[last] - 1)
        {
            last = i;
            st.push(last);
        }
    while (!st.empty())
    {
        fout << a[st.top()]<<" ";
        st.pop();

    }
    return 0;
}