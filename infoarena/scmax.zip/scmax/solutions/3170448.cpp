#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main()
{


    int n;
    fin>>n;
    int a[n+1];
    for(int i=1; i<=n; i++){
        fin >> a[i];
    }

    int ans[n+1], d=1, p[n+1];
    ans[1]=a[1];
     p[1]=1;
    for(int i=2; i<=n; i++)
    {
        if(a[i]>ans[d]) ///pun la final;
        {
            ++d;
            ans[d]=a[i];
            p[i]=d;
        }
        else
        {
            int st=1, dr=d, poz=d+1;
            while(st<=dr)
            {
                int m=(st+dr)/2;
                if(ans[m]>=a[i])
                    poz=m ,dr=m-1;
                else
                    st=m+1;
            }
            ans[poz]=a[i];
            p[i]=poz;
        }
    }
    cout<<d<<"\n";
    int fin[d+1];
    int j=n;
    for(int i=d; i>=1; i--)
    {
        while(p[j]!=i)j--;
        fin[i]=j;
    }
    for(int i=1; i<=d; i++)cout<<a[fin[i]]<<' ';
    return 0;
}
