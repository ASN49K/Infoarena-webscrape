#include <fstream>
#include <algorithm>
#define DIM 100001

using namespace std;

int V[DIM], W[DIM], A[DIM], i, p, N, Maxim, Max, K, P[DIM], T[DIM], pozMax, poz;

ifstream fin ("scmax.in");
ofstream fout("scmax.out");

void drum(int p) {
	if (p) {
		drum(T[p]);
		fout<<W[p]<<" ";
	}
}

inline int lsb(int x) {
	return x & -x;
}

int cauta(int x) {
	int p = 1, u = K, m;
	while (p<=u) {
		m = (p+u) >> 1;
		if (W[m] == x)
			return m;
		if (W[m] < x)
			p = m+1;
		else
			u = m-1;
	}
}

int query (int p, int &pp) {
	int maxim = 0;
	pp = 0;
	for (;p;p-=lsb(p)) {
		if (maxim < A[p]) {
			maxim = A[p];
			pp = P[p];
		}
	}
	return maxim;
}

void update(int p, int v) {
	int aux = p;
	for (;p<=K;p+=lsb(p))
		if (A[p] < v) {
			A[p] = v;
			P[p] = aux;
		}
}


int main() {

	fin>>N;
	for (i=1;i<=N;i++) {
		fin>>V[i];
		W[i] = V[i];
	}

	sort(W+1, W+N+1);
	K = 1;
	for (i=2;i<=N;i++)
		if (W[i] != W[K])
			W[++K] = W[i];


	for (i=1;i<=N;i++) {
		p = cauta(V[i]);
		int Max = query(p-1, poz);
		if (1+Max > Maxim) {
			Maxim = 1 + Max;
			pozMax = p;
		}
		update(p, 1+Max);
		T[p] = poz;
	}

    fout<<Maxim<<"\n";
	drum(pozMax);
	return 0;
}
