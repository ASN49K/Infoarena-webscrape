#include <fstream>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

#define MAXN 100000

int v[MAXN+1];
int d[MAXN+1];

int main()
{
    int n;
    cin>>n;
    int i;
    for(i=0; i<n; i++)
        cin>>v[i];
    int j;
    for(i=0; i<n; i++)
    {
        d[i]=1;
        for(j=0; j<i; j++)
            if(v[j]<v[i])
                d[i]=max(d[i], d[j]+1);
    }
    int maxl;
    maxl=d[0];
    for(i=1; i<n; i++)
        maxl=max(maxl, d[i]);
    cout<<maxl;
    return 0;
}
