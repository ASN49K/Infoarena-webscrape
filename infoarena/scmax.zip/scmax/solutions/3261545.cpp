#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int v[100001];
int main()
{
    int N,stm=1,sfm=1,cnt=1,st=1,sf=1,lmax=1;
    fin>>N;

    for(int i=1;i<=N;i++)
        fin>>v[i];

    for(int i=2;i<=N;i++)
    {
        if(v[i]>v[i-1])
        {
            cnt++;
            sf=i;
            if(i==N)
                if(cnt>lmax)
                {
                    lmax=cnt;
                    stm=st;
                    sfm=sf;
                }
        }
        else if(v[i]<v[i-1])
        {
            if(cnt>lmax)
            {
                lmax=cnt;
                stm=st;
                sfm=sf;
            }
            cnt=1;
            st=sf=i;
        }

        else
            if(i==N)
                if(cnt>lmax)
                {
                    lmax=cnt;
                    stm=st;
                    sfm=sf;
                }
    }
    fout<<lmax<<'\n';
    for(int i=stm;i<=sfm;i++)
        fout<<v[i]<<' ';
    return 0;
}
