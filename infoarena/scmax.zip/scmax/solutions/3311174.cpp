#include <fstream>
#include <vector>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int main(){
    int n; fin >> n;
    vector<int> v(n), d(n, 1);

    for (int& num : v) fin >> num;

    for (int i = 1; i < n; i++){
        for (int j = 0; j < i; j++){
            if (v[i] > v[j]) d[i] = max (d[i], d[j]+1);
        }
    }

    fout << ({int maxim = 1; for (int& num : d) maxim = max(maxim, num); maxim;});

    for (int i = 0; i < n; i++) fout << " 0";

    return 0;
}
