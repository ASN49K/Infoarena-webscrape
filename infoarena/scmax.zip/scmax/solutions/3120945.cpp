#include <bits/stdc++.h>

using namespace std;

vector<int> SCMAX(vector<int> &v, int n) {
    vector <vector <int>> dp(n + 1);
    for (int i = 0; i <= n; i++){
        for (int j = 0; j <= i - 1; j++)
        {
            if (dp[j].back() < v[i])
                dp[j].push_back(v[i]);
        }
        dp[i].push_back(v[i]);
    }
    vector<int> max = dp[1];
    for (int i = 2; i <= n; i++)
    {
        if (dp[i].size() > max.size())
            max = dp[i];
    }
    return max;
}

int main() {
    ifstream fin;
    ofstream fout;
    fin.open("./scmax.in", ios::in);
    fout.open("./scmax.out", ios::out);
    int n;
    fin >> n;
    vector<int> v(n + 1);
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        v[i] = x;
    }
    vector<int> max = SCMAX(v, n);
    fout << max.size() << endl;
    for (int i = 0; i < max.size(); i++)
    {
        fout << max[i] << " ";
    }
}