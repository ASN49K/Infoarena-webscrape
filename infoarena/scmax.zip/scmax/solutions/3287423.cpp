#include <bits/stdc++.h>
#define reslast res[res.size()-1]
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
struct elem
{
    int val,pos;
}v[100001];
struct nod
{
    int best,pos;
}aint[400001];
bool sortval(elem a,elem b)
{
    return(a.val<b.val || (a.val==b.val && a.pos<b.pos));
}
nod combine(nod a,nod b)
{
    if(a.best>b.best)
        return a;
    if(b.best>a.best)
        return b;
    if(a.pos<=b.pos)
        return a;
    return b;
}
void update(int v,int st,int dr,int pos,nod a)
{
    if(st==dr)
        aint[v]=a;
    else
    {
        int mid=(st+dr)/2;
        if(pos<=mid)
            update(v*2,st,mid,pos,a);
        else update(v*2+1,mid+1,dr,pos,a);
        aint[v]=combine(aint[v*2],aint[v*2+1]);
    }
}
nod best;
void query(int v,int st,int dr,int qst,int qdr)
{

    if(qst<=st && qdr>=dr)
        best=combine(best,aint[v]);
    else
    {
        int mid=(st+dr)/2;
        if(qst<=mid)
            query(v*2,st,mid,qst,qdr);
        if(qdr>mid)
            query(v*2+1,mid+1,dr,qst,qdr);
    }
}
int main()
{
    int n,lmax=0;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i].val;
        v[i].pos=i;
    }
    sort(v+1,v+n+1,sortval);
    for(int i=1;i<=n;i++)
    {
        best={0,1000000};
        if(v[i].pos!=1)
            query(1,1,n,1,v[i].pos-1);
        if(best.best && v[i].val==v[best.pos].val)
            best.best--;
        update(1,1,n,v[i].pos,{best.best+1,i});
        lmax=max(lmax,best.best+1);
    }
    fout<<lmax<<'\n';
    vector<int>res;
    for(int i=lmax;i>=1;i--)
    {
        best={0,1000000};
        if(i==lmax)
            query(1,1,n,1,n);
        else query(1,1,n,1,v[reslast].pos-1);
        res.push_back(best.pos);
    }
    reverse(res.begin(),res.end());
    for(int i=0;i<res.size();i++)
        fout<<v[res[i]].val<<' ';
    return 0;
}
