#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

const int dim=100001;
int n, prv[dim];

pair<int, int> aib[dim];

struct date{
    int val, poz, val_norm;
} v[dim];

bool sortare1(date a, date b){
    if(a.val<b.val){
        return true;
    }
    return false;
}

bool sortare2(date a, date b){
    if(a.poz<b.poz){
        return true;
    }
    return false;
}

int lsb(int i){
    return i&-i;
}

pair<int, int> query(int poz){
    pair<int, int> rez={0, 0};
    for(int i=poz; i>=1; i-=lsb(i)){
        rez=max(rez, aib[i]);
    }
    return rez;
}

void update(pair<int, int> val, int poz){
    for(int i=poz; i<=n; i+=lsb(i)){
        aib[i]=max(aib[i], val);
    }
}

void afis(int poz){
     if(prv[poz]!=0){
        afis(prv[poz]);
    }
    g<< v[poz].val << " ";
}

int main()
{
    int i, k=0, poz=0;
    pair<int, int> temp={0,0}, rez={0, 0};
    f>> n;
    for(i=1; i<=n; i++){
        f>> v[i].val; v[i].poz=i;
    }
    sort(v+1, v+n+1, sortare1);
    for(i=1; i<=n; i++){
        if(v[i].val==v[i-1].val){
            v[i].val_norm=k;
        } else {
            v[i].val_norm=++k;
        }
    }
    sort(v+1, v+n+1, sortare2);
    for(i=1; i<=n; i++){
        temp=query(v[i].val_norm-1);
        prv[i]=temp.second;
        temp.first+=1; temp.second=i;
        update(temp, v[i].val_norm);
        if(temp>rez){
            rez=temp; poz=i;
        }
    }
    g<< rez.first << endl;
    afis(poz);

    return 0;
}
