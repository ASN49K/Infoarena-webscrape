#include<bits/stdc++.h>
#define DIM 100000

using namespace std;

ifstream fin("arbint.in");
ofstream fout("arbint.out");

int n , m , aint[4 * DIM + 3];

inline void build(int nod , int st , int dr){
    if(st == dr) fin >> aint[nod];
    else{
        int mid = (st + dr) / 2;
        build(2 * nod , st , mid);
        build(2 * nod + 1 , mid + 1 , dr);
        aint[nod] = max(aint[2 * nod] , aint[2 * nod + 1]);
    }
}

inline void update(int nod , int st , int dr , int poz , int x){
    if(st == dr) aint[nod] = x;
    else{
        int mid = (st + dr) / 2;
        if(poz <= mid) update(2 * nod , st , mid , poz , x);
        else update(2 * nod + 1 , mid + 1 , dr , poz , x);
        aint[nod] = max(aint[2 * nod] , aint[2 * nod + 1]);
    }
}

inline int query(int nod , int st ,int dr , int a , int b){
    if(a <= st && dr <= b){
        return aint[nod];
    }
    else if(dr < a || st > b) return -1;
    else{
        int mid = (st + dr) / 2;
        return max(query(2 * nod , st , mid , a , b) , query(2 * nod + 1 , mid + a , dr , a , b));
    }
}

int main(){
    fin >> n >> m;
    build(1 , 1, n);
    for(int i = 1 ; i <= m ; i++){
        int tip , a , b; fin >> tip >> a >> b;
        if(tip == 0){
            fout << query(1 , 1 , n , a , b) << '\n';
        }
        else{
            update(1 , 1 , n , a , b);
        }
    }
}
