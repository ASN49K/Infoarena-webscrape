/*#include <bits/stdc++.h>
#define nmax 1000003

using namespace std;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");

vector <int> ls;
int n, len, v[nmax], pre[nmax];

int insert(int i, int left, int right)
{
    if(left == right)
        return left;
    int m = (left + right) / 2;
    if(v[ls[m]] < v[i])
        insert(i, m + 1, right);
    else
        insert(i, left, m);
}

int main()
{
    int i, k;
    fin >> n;
    for (i = 0; i < n; i++)
        fin >> v[i];
    ls.push_back(0);
    pre[0] = -1;
    len++;

    for(i = 1; i < n; i++)
    {
        k = insert(i, 0, len);
        if(k == 0)
            ls[0] = i, pre[i] = -1;
        else if(k == len)
        {
            ls.push_back(i), pre[i] = ls[len-1], len++;
        }
        else
            ls[k] = i, pre[i] = ls[k-1];

    }
    i = ls[len-1];
    stack <int> sol;
    while(i != -1)
    {
       sol.push(v[i]);
       i = pre[i];
    }
    fout << len << endl;
    while(!sol.empty())
        fout << sol.top() << ' ', sol.pop();

    return 0;
}
*/
#include <bits/stdc++.h>
#define nmax 1000003

using namespace std;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");

vector <int> ls;
int n, len, v[nmax], pre[nmax];

int insert(int i, int left, int right)
{
    if(left == right)
        return left;
    int m = (left + right) / 2;
    if(v[ls[m]] < v[i])
        insert(i, m + 1, right);
    else
        insert(i, left, m);
}

int main()
{
    int i, k;
    fin >> n;
    for (i = 0; i < n; i++)
        fin >> v[i];
    ls.push_back(0);
    pre[0] = -1;
    len++;

    for(i = 1; i < n; i++)
    {
        k = insert(i, 0, len);
        if(k == 0)
            ls[0] = i, pre[i] = -1;
        else if(k == len)
        {
            ls.push_back(i), pre[i] = ls[len-1], len++;
        }
        else
            ls[k] = i, pre[i] = ls[k-1];

    }
    i = ls[len-1];
    stack <int> sol;
    while(i != -1)
    {
       sol.push(v[i]);
       i = pre[i];
    }
    fout << len << endl;
    while(!sol.empty())
        fout << sol.top() << ' ', sol.pop();

    return 0;
}
