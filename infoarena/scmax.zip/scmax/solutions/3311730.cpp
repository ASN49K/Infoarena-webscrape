#include <bits/stdc++.h>

std::ifstream in("scmax.in");
std::ofstream out("scmax.out");

int findpos(int x, std::vector<int>& lis, std::vector<int>& v, int Max) {
    int ans, step;
    for (step = 1; step < Max; step <<= 1);

    for (ans = 0; step; step >>= 1) {
        if (ans + step <= Max && v[lis[ans + step]] < x) {
            ans += step;
        }
    }
    return ans;
} 

void printSol(std::vector<int>& prev, std::vector<int>& v, int pos) {
    if (prev[pos] != -1) {
        printSol(prev, v, prev[pos]);
    }

    out << v[pos] << " ";
}

int main() {
    int n;

    in >> n;

    std::vector<int> v(n + 1);

    for (int i = 1; i <= n; i++) {
        in >> v[i];
    }

    std::vector<int> lis(n + 1, -1);
    std::vector<int> prev(n + 1, -1);
    int Max = 0;
    int pmax = 0;

    for (int i = 1; i <= n; i++) {
        int pos = findpos(v[i], lis, v, Max);
        prev[i] = lis[pos];
        lis[pos + 1] = i;
        if (pos + 1 > Max) {
            Max = pos + 1;
            pmax = i;
        }
    }

    out << Max << '\n';

    printSol(prev, v, pmax);
}