#include <fstream>

using namespace std;
int n, i, st, dr, mid, L, v[100010], t[100010], d[100010];

ifstream fin("scmax.in");
ofstream fout("scmax.out");

void tata(int i) {
    if (i != 0) {
        tata(t[i]);
        fout << v[i] << " ";
    }
}

int main() {
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> v[i];
    L = 1;
    d[1] = 1;
    for (i = 2; i <= n; i++) {
        st = 1;
        dr = L;
        while (st <= dr) {
            mid = (st + dr) / 2;
            if (v[d[mid]] >= v[i])
                dr = mid - 1;
            else
                st = mid + 1;
        }
        if (st > L) {
            L++;
            d[L] = i;
            t[i] = d[st - 1];
        } else {
            d[st] = i;
            t[i] = d[st - 1];
        }
    }
    fout << L << "\n";
    tata(d[L]);
    return 0;
}