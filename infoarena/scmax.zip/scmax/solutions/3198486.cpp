#include <stdio.h>
#include <stdlib.h>
#define N 100000

FILE *in,*out;

int v[N+1],l_max[N+1], val_min[N+1];

void refac_subsirul(int p, int val, int lung)
{
    if(lung == 0)
    {
        return;
    }
    if(v[p] <= val && l_max[p] == lung)
    {
        refac_subsirul(p-1, v[p]-1,lung-1);
        fprintf(out,"%d ",v[p]);
    }
    else
    {
        refac_subsirul(p-1, val, lung);
    }
}

int max(int a, int b)
{
    if(a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

int caut_bin(int a, int b, int val)
{
    ///caut binar cel mai mare rez cu val_min[rez] < val
    int st = a, dr = b, rez = a - 1;
    while (st <= dr)
    {
        int m = (st + dr) / 2;
        if (val_min[m] < val)
        {
            rez = m;
            st = m + 1;
        }
        else
        {
            dr = m - 1;
        }
    }
    return rez;
}

int main()
{
    in = fopen("scmax.in","r");
    out = fopen("scmax.out","w");
    int n, i_max = 0, n_val_min = 0;
    fscanf(in, "%d", &n);
    for(int i = 0; i < n; i++)
    {
        fscanf(in, "%d", &v[i]);
        int j0 = caut_bin(1, n_val_min, v[i]);
        l_max[i] = j0 + 1;
        if (j0 == n_val_min)
        {
            n_val_min++;
        }
        val_min[j0 + 1] = v[i];
        if(l_max[i] > l_max[i_max])
        {
            i_max = i;
        }
    }
    fprintf(out,"%d\n",l_max[i_max]);
    refac_subsirul(i_max,v[i_max],l_max[i_max]);
    fclose(in);
    fclose(out);
    return 0;
}
