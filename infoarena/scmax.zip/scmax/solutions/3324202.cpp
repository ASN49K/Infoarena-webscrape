#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

vector<int>aint;

void update(int nod,int st,int dr,int poz,int v){

    if(st==dr){

        aint[nod] = v;
        return;
    }

    int md = (st+dr)/2;

    if(poz <= md)
        update(2*nod,st,md,poz,v);
    else
        update(2*nod + 1,md+1,dr,poz,v);

    aint[nod] = max(aint[2*nod],aint[2*nod + 1]);
}

int qeu(int nod,int st,int dr,int poz){

    if(st > poz)
        return 0;

    if(dr <= poz)
        return aint[nod];

    int md = (st+dr)/2;

    return max(qeu(2*nod,st,md,poz),qeu(2*nod + 1,md+1,dr,poz));
}

bool cmp(pair<int,int>a,pair<int,int>b){

    if(a.first == b.first)
        return a.second > b.second;

    return a.first < b.first;
}

int main()
{

    int n;
    fin>>n;

    vector<int>a(n+1),dp(n+1);
    vector<pair<int,int>>elemente;
    aint.resize(4*n + 1,0);

    for(int i=1;i<=n;i++){

        fin>>a[i];
        elemente.push_back({a[i],i});
    }

    sort(elemente.begin(),elemente.end(),cmp);

    int mx = 0;

    for(auto i : elemente){

        int aux = qeu(1,1,n,i.second);

        dp[i.second] = aux + 1;
        update(1,1,n,i.second,aux + 1);
        mx = max(mx,aux + 1);
    }

    fout<<mx<<'\n';

    stack<int>st;

    int c_mx = mx,last = 2e9 + 1;

    for(int i=n;i>=1 && c_mx;i--){

        if(dp[i] == c_mx && last > a[i]){

            st.push(a[i]);
            c_mx--;
            last = a[i];
        }
    }

    while(!st.empty()){

        fout<<st.top()<<" ";
        st.pop();
    }

    return 0;
}
