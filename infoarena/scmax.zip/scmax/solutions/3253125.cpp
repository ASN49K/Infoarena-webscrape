#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e5+2;
int n,a[NMAX],k,dp[NMAX],t[NMAX];
// dp[i] = cea mai mica valoare care poate sta pe pozitia i in scmax

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int find_pos(int val){
  int st = 1, dr = k, ans = k+1;
  while(st <= dr){
    int mid = (st+dr)/2;
    if(a[dp[mid]] >= val){
      ans = mid;
      dr = mid-1;
    }else{
      st = mid+1;
    }
  }
  return ans;
}

int main() {
  fin >> n;
  for(int i = 1; i <= n; i++){
    fin >> a[i];
  }
  for(int i = 1; i <= n; i++){
    int pos = find_pos(a[i]);
    dp[pos] = i;
    t[i] = dp[pos-1];
    k = max(k, pos);
  }
  fout << k << "\n";
  vector<int> ans;
  int pos = dp[k];
  for(int i = 1; i <= k; i++){
    ans.push_back(a[pos]);
    pos = t[pos];
  }
  for(int i = k-1; i >= 0; i--){
    fout << ans[i] << " ";
  }
  return 0;
}
