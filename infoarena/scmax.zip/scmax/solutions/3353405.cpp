#include <bits/stdc++.h>
using namespace std;

signed main() {
#ifndef LOCAL
    freopen("scmax.in", "r", stdin);
    freopen("scmax.out", "w", stdout);
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n; cin >> n;
    vector<int> a(n+1);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }

    vector<int> val_min, scmax(n+1), prev(n+1), poz(n+1);
    val_min.reserve(n+1);
    int maxx = 0;
    for (int i = 1; i <= n; ++i) {
        int ans = 0;
        for (int pas = 1 << 20; pas; pas >>= 1) {
            if (ans + pas < val_min.size() && val_min[ans + pas] < a[i])
                ans += pas;
        }
        scmax[i] = ans + 1;
        while (scmax[i] >= val_min.size())
            val_min.push_back(0);
        val_min[scmax[i]] = a[i];
        prev[i] = poz[scmax[i] - 1];
        poz[scmax[i]] = i;
        maxx = max(maxx, scmax[i]);
    }

    vector<int> rez;
    rez.reserve(maxx);
    for (int i = poz[maxx]; i; i = prev[i])
        rez.push_back(i);

    cout << maxx << '\n';
    for (int i = (int)rez.size() - 1; i >= 0; --i)
        cout << a[rez[i]] << ' ';
    cout << '\n';

    return 0;
}