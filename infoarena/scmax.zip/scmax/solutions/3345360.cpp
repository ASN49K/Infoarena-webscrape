#include <vector>
#include <fstream>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int main() {
    int n;
    in >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        in >> v[i];
    }
    vector<int> lis;

    for (int h : v) {
        auto it = lower_bound(lis.begin(), lis.end(), h);

        if (it == lis.end()) {
            lis.push_back(h);
        } else {
            *it = h;
        }
    }

    out << lis.size() << endl;
    for (int i = 0; i < lis.size(); i++)
        out << lis[i] << " ";
}
