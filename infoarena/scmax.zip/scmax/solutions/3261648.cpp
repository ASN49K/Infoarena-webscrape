#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int oo = 2000000001;
int cautareBinara(int n, vector<int> &v, int left, int right)
{
    fout << left << " " << right << '\n';
    if (left == right)
    {
        return left;
    }
    int mij = (left + right) / 2;

    if (v[mij] < n)
        return cautareBinara(n, v, mij + 1, right);

    return cautareBinara(n, v, left, mij);
}
int main()
{
    int n;
    fin >> n;
    vector<int> b(n + 1, oo);
    b[0] = 0;
    vector<int> x(n + 1);
    int dp[100001];
    int maxim = 0;
    int mi = 0;
    for (int i = 1; i <= n; i++)
    {
        fin >> x[i];
        int poz = cautareBinara(x[i], b, 0, n);
        // int poz = lower_bound(b.begin(), b.end(), x[i]) - b.begin();
        dp[i] = poz;

        if (dp[i] >= maxim)
        {
            maxim = dp[i];
            mi = i;
        }
        b[poz] = x[i];
    }
    vector<int> v;
    fout << maxim << '\n';
    maxim--;
    v.push_back(x[mi]);
    for (int i = mi - 1; i > 0; i--)
    {
        if (dp[i] == maxim)
        {
            v.push_back(x[i]);
            maxim--;
        }
    }
    reverse(v.begin(), v.end());
    for (auto i : v)
    {
        fout << i << " ";
    }
}