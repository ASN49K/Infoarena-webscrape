#include <iostream>
#include <fstream>


using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n,a[100005],ult[100005],poz[100005],nr;

int binar(int val)
{
    int st=1,dr=nr;
    int m=(st+dr)/2;
    while(st<=dr)
    {
        if(a[poz[m]]<val && a[poz[m+1]]>=val)
        {
            return m;
        }
        else
        {
            if(a[poz[m+1]]<val)
            {
                st=m+1;
                m=(st+dr)/2;
            }
            else
            {
                dr=m-1;
                m=(st+dr)/2;
            }
        }
    }
    return nr;
}

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>a[i];
    }
    poz[1]=1;
    ult[1]=a[1];
    nr=1;
    for(int i=2;i<=n;i++)
    {
        int pozition=binar(a[i]);
        //cout<<pozition<<endl;
        //cout<<pozition<<" "<<ult[pozition]<<" "<<a[i]<<endl;
        if(pozition==nr)
        {
            if(ult[pozition]<a[i])
            {nr++;
            ult[nr]=a[i];
            poz[i]=nr;}
            else
            {
                ult[pozition]=a[i];
                poz[i]=pozition;
            }
        }
        else
        {
            if(ult[pozition]>a[i])
            {
                ult[pozition]=a[i];
                poz[i]=pozition;
                //cout<<pozition<<" "<<ult[pozition]<<" "<<a[i]<<endl;
            }
        }
    }
    fout<<nr<<'\n';
    for(int i=1;i<=nr;i++)
    {
        fout<<ult[i]<<" ";
    }
    return 0;
}
