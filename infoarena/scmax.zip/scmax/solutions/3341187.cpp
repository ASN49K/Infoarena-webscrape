#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int NMAX = 1e5 + 1, INF = INT_MAX;
int n, arr[NMAX], dp[NMAX];

void print(int length)
{
    if(length == 1)
    {
        fout << dp[length] << " ";
        return;
    }
    print(length - 1);
    fout << dp[length] << " ";
}

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> arr[i];
    fill(dp + 1, dp + n + 1, INF);
    dp[0] = -INF;
    for(int i = 1; i <= n; i++)
    {
        int l = upper_bound(dp + 1, dp + n + 1, arr[i]) - dp;
        if(dp[l-1] < arr[i])
            dp[l] = arr[i];
    }
    int max_length = -1;
    for(int i = 1; i <= n; i++)
        if(dp[i] != INF && i > max_length)
            max_length = i;
    fout << max_length << "\n";
    print(max_length);

    fin.close();
    fout.close();
    return 0;
}
