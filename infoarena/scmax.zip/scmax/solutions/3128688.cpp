#include<fstream>
using namespace std;
ifstream F("scmax.in");
ofstream G("scmax.out");
int n,i,a[100001],b[100001],m,j,k;
int main()
{
    for(F>>n,i=1;i<=n;++i) {
        if(F>>a[i],a[b[m]]<a[i])
            b[++m]=i;
        for(j=0,k=m;j<k;a[b[(j+k)/2]]<=a[i]?j=(j+k)/2+1:k=(j+k)/2);
        if(a[i]<a[b[j]])
            b[j]=i;
    }
    for(G<<m<<'\n',i=1;i<=m;G<<a[b[i++]]<<' ');
    return 0;
}
