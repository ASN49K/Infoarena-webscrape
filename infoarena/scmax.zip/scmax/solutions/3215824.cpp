#include <bits/stdc++.h>
using namespace std;
#define pb push_back

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, l;
vector<int> v, prv, idx, dp;

int main(){
    fin >> n;
    v.resize(n+2); prv.resize(n+2); idx.resize(n+2);
    for (int i = 1; i <= n; i++){
        fin >> v[i];
        auto it = lower_bound(dp.begin(), dp.end(), v[i]);
        int pos = (int)(it - dp.begin());
        if (it == dp.end()){
            l++; dp.pb(v[i]);
        }
        dp[pos] = v[i];
        prv[i] = idx[pos-1];
        idx[pos] = i; 
    }
    fout << l << '\n';
    int k = idx[l-1];
    stack<int> stk;
    while (k){
        stk.push(v[k]);
        k = prv[k];
    }
    while (!stk.empty()){
        fout << stk.top() << ' ';
        stk.pop();
    }

    return 0;
}


//13:08
