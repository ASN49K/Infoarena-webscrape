	#include <iostream>
	#include <algorithm>
	#include <fstream>
	using namespace std;
	int n, v[100005], s[100005], dp[100005], aib[100005];
	ifstream fin("scmax.in");
	ofstream fout("scmax.out");
	int cautare_binara(int x) {
		int rez = 0;
		for (int i = 17; i >= 0; i--) {
			if ((rez + (1 << i)) <= n && s[rez + (1 << i)] < x) rez += (1 << i);
		}
		return rez+1;
	}
	void update(int val, int poz) {
		while (poz <= n) {
			aib[poz] = max(aib[poz], val);
			poz += (poz & (poz ^ (poz - 1)));
		}
	}
	int query(int poz) {
		int rez = 0;
		while (poz > 0) {
			rez = max(rez, aib[poz]);
			poz -= (poz & (poz ^ (poz - 1)));
		}
		return rez;
	}
	int main() {
		fin >> n;
		for (int i = 1; i <= n; i++) {
			fin >> v[i];
			s[i] = v[i];
		}
		sort(s + 1, s + n + 1);
		for (int i = 1; i <= n; i++) {
			v[i] = cautare_binara(v[i]);
		}
		for (int i = 1; i <= n; i++) {
			dp[i] = 1 + query(v[i]-1);
			update(dp[i],v[i]);
		}
		int mx = 0;
		for (int i = 1; i <= n; i++) {
			mx = max(mx, dp[i]);
		}
		fout << mx;
	}
