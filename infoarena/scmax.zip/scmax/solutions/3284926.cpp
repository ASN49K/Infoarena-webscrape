#include <fstream>
#define nmax 100001
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int n,v[nmax],dp[nmax],t[nmax],k;
void rec(int n){
    if(t[n]!=0)
        rec(t[n]);
    cout<<v[n]<<" ";
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
        int st=1,dr=k,poz=0;
        while(st<=dr){
            int mid=(st+dr)/2;
            if(v[dp[mid]]>=v[i])
                poz=mid,dr=mid-1;
            else
                st=mid+1;
        }
        if(poz==0){
            t[i]=dp[k];
            dp[++k]=i;
        }else{
            t[i]=dp[poz-1];
            dp[poz]=i;
        }
    }
    cout<<k<<'\n';
    rec(dp[k]);
    return 0;
}
