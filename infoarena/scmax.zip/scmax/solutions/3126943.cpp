#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fi=fopen("scmax.in","r");
    FILE *fo=fopen("scmax.out","w");
    int V[10001], X[10001], A[10001];//!
    int i,j,maxx,n,p;
    fscanf(fi,"%d",&n);
    for (i=1;i<=n;i++)
        fscanf(fi,"%d",&V[i]);
    X[n]=1,maxx=1;
    A[n]=-1;
    p=n;
    for (i=n-1;i;i--)
    {
        X[i]=1;
        A[i]=-1;
        for (j=i+1 ; j<=n; j++)
        {
            if (X[j]+1 >X[i] && V[j]>V[i])
            {
                X[i] = X[j]+1;
                A[i] = j;
            }
            if (X[i]>maxx)
            {
                maxx=X[i];
                p=i;
            }
        }
    }
    fprintf(fo,"%d\n",maxx);
    i=p;
    while (i != -1)
    {
        fprintf(fo,"%d ",V[i]);
        i = A[i];
    }
    return 0;

}
