#include <bits/stdc++.h>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int n,x,k,v[100200],poz[100200],org[100200];
stack <int> st;

int32_t main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>x, org[i]=x;
        if(x>v[k])
            v[++k]=x, poz[i]=k;
        else
        {
            int st=1, dr=k, sol=0;
            while(st<=dr)
            {
                int mij=(st+dr)/2;
                if(v[mij]>=x)
                    sol=mij, dr=mij-1;
                else
                    st=mij+1;
            }
            v[sol]=x, poz[i]=sol;
        }
    }
    g<<k<<'\n';
    for(int i=n; i>=1; i--)
        if(poz[i]==k)
            st.push(org[i]), k--;
    while(!st.empty())
        g<<st.top()<<' ', st.pop();
    return 0;
}
