#include <stdio.h>
#include <stdlib.h>

#define MAXN 100000

int v[MAXN], d[MAXN], pred[MAXN], sol[MAXN];

int main()
{
    FILE *fin, *fout;
    fin = fopen("scmax.in", "r");
    fout = fopen("scmax.out", "w");

    int n, i, j, lmax, poz;

    fscanf(fin, "%d", &n);

    lmax = 0;
    for(i = 0; i < n; i++){
      fscanf(fin, "%d", &v[i]);
      d[i] = 1;
      pred[i] = -1;
      for(j = i - 1; j >= 0; j--){
        if(v[j] < v[i]){
          if(d[j] + 1 > d[i]){
            d[i] = d[j] + 1;
            pred[i] = j;
          }
        }
      }
      if(d[i] > lmax){
        lmax = d[i];
        poz = i;
      }
    }

    fprintf(fout, "%d\n", lmax);

    i = lmax - 1;
    while(poz >= 0){
      sol[i] = v[poz];
      poz = pred[poz];
      i--;
    }

    for(i = 0; i < lmax; i++){
      fprintf(fout, "%d ", sol[i]);
    }

    return 0;
}
