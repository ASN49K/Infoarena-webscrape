#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int Nmax = 100000 + 5;
int v[Nmax], dp[Nmax], minVal[Nmax], pre[Nmax], ind[Nmax];
vector <int> solution;
int main()
{
    int n, i;
    fin >> n;
    for ( i = 1; i <= n; ++i )
        fin >> v[i];

    int len = 1, sol = 1, pozSol = 1;
    minVal[1] = v[1];
    dp[1] = 1;
    for ( i = 2; i <= n; ++i )
    {
        if ( minVal[len] < v[i] )
        {
            pre[i] = ind[len];
            minVal[++len] = v[i];
            ind[len] = i;
            dp[i] = len;
        }
        else
        {
            int poz = lower_bound(minVal + 1, minVal + len + 1, v[i]) - minVal - 1;
            dp[i] = poz + 1;
            minVal[poz + 1] = v[i];
            ind[poz + 1] = i;
            pre[i] = ind[poz];
        }
        if ( sol < dp[i] )
        {
            pozSol = i;
            sol = dp[i];
        }
    }
    if (n == 1 )
        fout << "nig";
    fout << sol << '\n';
    i = pozSol;
    while ( i != 0 )
    {
        solution.push_back(v[i]);
        i = pre[i];
    }

    int m = solution.size();
    for( i = m -1; i >= 0; --i )
        fout << solution[i] << " ";
    return 0;
}
