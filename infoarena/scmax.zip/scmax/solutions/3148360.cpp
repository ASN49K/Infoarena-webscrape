#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "scmax.in"
#define OUTFILE "scmax.out"

const int VMAX = 1e5 + 2;

int n;
int v[VMAX], prv[VMAX];
vector<int> ans;
bool ok = true;

void solve(){

    cin >> n;

    for(int i = 1; i <= n; ++i){

        cin >> v[i];

        if(i != 1){

            if(v[i - 1] >= v[i]){

                ok = false;

            }

        }

    }

    if(ok){

        cout << n << '\n';

        for(int i = 1; i <= n; ++i){

            cout << v[i] << " ";

        }

        return;

    }

    ans.push_back(v[1]);

    prv[1] = 1;

    for(int i = 2; i <= n; ++i){

        if(v[i] > ans.back()){

            ans.push_back(v[i]);

            prv[i] = ans.size() - 1;

        }
        else{

            int position = lower_bound(ans.begin(), ans.end(), v[i]) - ans.begin();

            ans[position] = v[i];

            prv[i] = position;

        }

    }

    cout << ans.size() << '\n';

    int ind = n;
    int res[VMAX];

    for(int i = ans.size() - 1; i >= 0; --i){

        while(prv[ind] != i){

            --ind;

        }

        res[i] = ind;

    }

    for(int i = 0; i < ans.size(); ++i){

        cout << v[res[i]] << " ";

    }

}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}