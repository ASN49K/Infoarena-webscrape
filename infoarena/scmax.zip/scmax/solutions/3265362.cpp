#include <bits/stdc++.h>

using namespace std;

ifstream fin ("scmax.in");
ofstream fout ("scmax.out");

int v[100005],cv[100005];
map <int,int> Nrm;
int iNrm[100005];
int tata[100005];
vector <int> ans;

pair <int,int> aint[4*100005];

void update(int node, int left, int right, int poz, pair <int,int> value) {
    if (left == right) {
        aint[node] = value;
        return;
    }
    int mid = (left + right) / 2;

    if (poz <= mid) {
        update(node * 2, left, mid, poz, value);
    } else {
        update(node * 2 + 1, mid + 1, right, poz, value);
    }

    aint[node] = max(aint[node * 2],aint[node * 2 + 1]);
}

pair <int,int> query(int node, int left, int right, int a, int b) {
    if (a <= left && right <= b) {
        return aint[node];
    }
    int mid = (left + right) / 2;
    pair <int,int> leftMax = {0,0}, rightMax = {0,0};

    if (a <= mid) {
        leftMax = query(node * 2, left, mid, a, b);
    }

    if (mid + 1 <= b) {
        rightMax = query(node * 2 + 1, mid + 1, right, a, b);
    }

    return max(leftMax,rightMax);
}

int main()
{
    int n;
    fin >> n;
    for (int i=1;i<=n;++i){
        fin >> v[i];
        cv[i] = v[i];
    }
    sort(cv,cv+n+1);
    int Init = 0;
    for (int i=1;i<=n;++i){
        tata[i] = 0;
        if (Nrm[cv[i]]>0) continue;
        Init++;
        Nrm[cv[i]] = Init;
        iNrm[Init] = cv[i];
    }
    int Size = 0;
    int Cmme = 0; // Cel mai mare element
    for (int i=1;i<=n;++i){
        pair <int,int> loc = {0,0};
        if (Nrm[v[i]]==1){
            update(1,1,n,1,{1,i});
            continue;
        }
        loc = query(1,1,n,1,Nrm[v[i]]-1);
        int frs = loc.first+1;
        update(1,1,n,Nrm[v[i]],{frs,i});
        tata[i] = loc.second;
        if (Size<frs){
            Size = frs;
            Cmme = i;
        }
    }
    int x = Cmme;
    ans.push_back(x);
    while (tata[x]!=0){
        x = tata[x];
        ans.push_back(x);
    }
    fout << Size << '\n';
    for (int i=ans.size()-1;i>=0;--i) fout << v[ans[i]] << ' ';
    return 0;
}
