#include <bits/stdc++.h>

using namespace std;

ifstream f ("scmax.in");
ofstream g ("scmax.out");

const int NMAX = 1e5;
const int VALMAX = 2e9 + 1e4;

int n;
int v[NMAX + 1];
int best[NMAX + 1], last[NMAX + 1];

int cb(int val){
    
    int rez = 0;
    int st = 1;
    int dr = n;
    
    while(st <= dr){
        
        int mij = (st + dr) / 2;
        if(best[mij] != VALMAX and val > v[best[mij]])
            rez = mij, st = mij + 1;
            
        else dr = mij - 1;
        
    }
    
    return rez;
    
}

int main()
{
    
    f >> n;
    for(int i=1; i<=n; i++)
        f >> v[i];
        
    for(int i=1; i<=NMAX; i++)
        best[i] = VALMAX;
        
    for(int i=1; i<=n; i++){
        
        int poz = cb(v[i]);
        best[poz + 1] = i;
        last[poz + 1] = i;
        
        
    }
    
    int cnt = 0;
    for(int i=1; i<=n and best[i] != VALMAX; i++)
        cnt ++;
        
        
    g << cnt << "\n";
    
    g << v[cnt] << " ";
    
    while(cnt){
        
        g << v[cnt] << " ";
        cnt = last[cnt];
        
    }
    
    return 0;
}