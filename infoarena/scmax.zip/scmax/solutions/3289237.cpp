#include <bits/stdc++.h>
using namespace std;

vector<int> LIS;

int cautare_binara(int val, int dr)
{
    int poz=0, st=0;
    while(st<=dr)
    {
        int mij=st+(dr-st)/2;
        if(val<=LIS[mij])
        {
            poz=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return poz;
}

int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n;
    cin >> n;
    LIS.reserve(n);
    for(int i=0; i<n; i++)
    {
        int a;
        cin >> a;
        if(LIS.empty())
            LIS.push_back(a);
        else
        {
            if(a>LIS.back())
                LIS.push_back(a);
            else
            {
                int pozitie=cautare_binara(a, LIS.size());
                LIS[pozitie]=a;
            }
        }
    }
    cout << LIS.size() << "\n";
    for(auto& element : LIS) cout << element << " ";

    return 0;
}
