#include <fstream>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

int n, x, k, v[100200], poz[100200], org[100200];
stack<int> st;

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> x;
        org[i] = x;

        int pos = lower_bound(v + 1, v + k + 1, x) - v;
        v[pos] = x;
        poz[i] = pos;
        if(pos > k)
            k = pos;

    }

    cout << k << '\n';

    for (int i = n; i >= 1; i--)
        if (poz[i] == k)
            st.push(org[i]), k--;

    while (!st.empty())
    {
        cout << st.top() << ' ';
        st.pop();
    }

    return 0;
}

