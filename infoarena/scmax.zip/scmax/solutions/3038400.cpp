/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <fstream>

using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int a[100001];
int n;
int dp[100001];

void reconstruct(int l,int i)
{
    if(l==0)
       return;
    for(int j=i;j>=0;j--)
         if(dp[j]==l)
           {
               reconstruct(l-1,j-1);
               cout<<a[j]<<" ";
               return;
           }
}
int main()
{
    cin>>n;
    int M=-1;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        int maxi=0;
        for(int j=0;j<i;j++)
           if(a[i]>a[j])
              maxi=max(dp[j],maxi);
        dp[i]=maxi+1;
        M=max(M,dp[i]);
    }
    cout<<M<<'\n';
    reconstruct(M,n-1);
    return 0;
}
