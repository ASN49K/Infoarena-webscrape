#include <fstream>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

#define NMAX 100005

int v[NMAX], dp[NMAX], poz[NMAX], tata[NMAX];

void afis(int nod)
{
    if (nod == 0)
        return ;
    afis(tata[nod]);
    fout << v[nod] << ' ';
}

int main()
{
    int n;
    fin >> n;

    int nr = 0;

    for (int i = 1; i <= n; ++ i)
    {
        fin >> v[i];

        int st = 0, dr = nr + 1;
        while (dr - st > 1)
        {
            int mid = (st + dr) / 2;
            if (v[i] > dp[mid])
                st = mid;
            else
                dr = mid;
        }
        if (dr == nr + 1)
            nr ++;

        dp[dr] = v[i];
        poz[dr] = i;
        tata[i] = poz[dr - 1];
    }

    fout << nr << '\n';
    afis(poz[nr]);
    return 0;
}
