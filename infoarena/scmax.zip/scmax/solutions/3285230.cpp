#include <fstream>
#include <vector>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

int n, a[100005], poz;

vector <int> ans;

int main()
{
    f >> n;

    for (int i = 1; i <= n; ++i) {
        f >> a[i];
    }

    ans.push_back(a[1]);

    for (int i = 2; i <= n; ++i) {
        if (a[i] > ans.back()) {
            ans.push_back(a[i]);
        }
        else {
            poz = lower_bound(ans.begin(), ans.end(), a[i] - 1) - ans.begin();

            ans[poz] = a[i];
        }
    }

    g << (int) ans.size() << '\n';

    for (auto it : ans) {
        g << it << ' ';
    }

    return 0;
}
