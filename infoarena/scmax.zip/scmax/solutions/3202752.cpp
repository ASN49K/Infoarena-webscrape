#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100001],n,dp[100001];
int smax=0;

void sDp(int d){
    int s=1;
    for(int i=2;i<=d;i++){
        if(v[i]>v[i-1])
            s++;
    }
    if(s>smax){
        smax=s;
        dp[d]=smax;
    }
}

int main(){
    fin>>n;
    for(int i=1;i<=n;i++){
        fin>>v[i];
    }
    for(int i=1;i<=n;i++){
        sDp(i);
    }
    
    fout<<smax<<endl;
    int k;
    for(k=1;k<=n;k++)
        if(dp[k]==smax)
            break;
    for(int i=1;i<k;i++)
        if(v[i]<v[i+1])
            fout<<v[i]<<" ";
    fout<<v[k];
        
    return 0;
}
