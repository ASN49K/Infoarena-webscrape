#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define ll long long
#define NMAX 100005
#define INF 1000000000
#define MOD 666013

int v[NMAX], dp[NMAX], venit[NMAX];
bool marked[NMAX];

int main() {
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    ios::sync_with_stdio(false), cin.tie(0);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> v[i];

    dp[1] = 1;
    for (int i = 2; i <= n; i++) {
        for (int j = i - 1; j >= 1; j--) {
            if (v[i] > v[j] && !marked[j]){
                marked[j] = true;
                dp[i] = max(dp[i], dp[j] + 1);
                venit[i] = j;
                break;
            }
            else dp[i] = dp[i - 1];
        }
    }
    for (int i = n; i >= 1; i--) {

    }
    cout << dp[n] << '\n';
    for (int i = 1; i <= n; i++) if (v[venit[i]] != 0) cout << v[venit[i]] << " ";
    for (int i = venit[n]; i <= n; i++) {
        if (v[i] > v[venit[n]]) {
            cout << v[i];
            break;
        }
    }
    return 0;
}
