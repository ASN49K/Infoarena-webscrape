#include <iostream>
#include <fstream>
#include <limits.h>
using namespace std;

int main()
{  int a[100],i,n,j,lung[100],poz[100];
ifstream fin("scmax.in");
ofstream fout("scmax.out");
   fin>>n;
   for(i=1;i<=n;i++)

    lung[n]=1;poz[n]=-1;
    for(i=n-1;i>=1;i--)
    {   lung[i]=1;poz[i]=-1;
        for(j=n;j>i;j--)
          if(a[i]<a[j]&&lung[i]<lung[j]+1)
          {  lung[i]=lung[j]+1;
             poz[i]=j;
          }
    }
    fout<<"vectorul poz: ";
    for(i=1;i<=n;i++) fout<<poz[i]<<" ";

    fout<<endl<<"vectorul lung: ";
    for(i=1;i<=n;i++)
         fout<<lung[i]<<" ";
    int maxim=INT_MIN,pozitie;
    for(i=1;i<=n;i++)
         if(lung[i]>maxim) {maxim=lung[i];pozitie=i;}
    fout<<"\nlungimea SCM:" <<maxim;
    fout<<"\nafisam SCM:";
    while(pozitie!=-1)
    {
        fout<<a[pozitie]<<" ";
        pozitie=poz[pozitie];
    }
    return 0;
}
