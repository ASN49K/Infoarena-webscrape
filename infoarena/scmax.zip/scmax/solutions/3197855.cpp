#include <iostream>
#include<fstream>
using namespace std;
ifstream ci("scmax.in");
ofstream cou("scmax.out");
int v[100003]
int best[100003]
int p[100003]
int L[100003];
int n,maxim,k,nr;
void afis(int pozi){
   if (p[pozi]>0){
    afis(p[pozi]);
    cou<<v[pozi]<<" ";
   }
}
int caut(int x){
   int p,u,m;
   p=0;
   u=nr;
   m=(p+u)/2;
   while(p<=u){
      if (v[L[m]]<x&&v[L[m+1]]>=x){
        return m;
      }
      else{
       if (v[L[m+1]]<x) {
            p=m+1;
            m=(p+u)/2;
       }
      else{
        u=m-1;
        m=(p+u)/2;
        }
      }
   }
   return nr;
}
int main()
{
   int i,j,poz;
   nr=1;
   ci>>n;
   for(i= 1;i<=n;i++){
       ci>>v[i];
   }
   best[1]=L[1]=1;
    L[0]=0;
   for(i=2;i<=n;i++){
      poz=caut(v[i]);
      p[i]=L[poz];
      best[i]=poz+1;
      L[poz+1]=i;
      if(nr<poz+1){
            nr=poz+1;
      }
   }
   maxim=0;
   poz=0;
   for(i=1;i<=n;i++){
       if (maxim<best[i]){
          maxim=best[i];poz=i;
       }
   }
   cou<<maxim<<'\n';
   afis(poz);
   return 0;
}
