#include <bits/stdc++.h>
using namespace std;
using llx = long long;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

vector<int> a, dp, par, sol; // dp[i] = indicele celui mai mic element (din a[]) ce poate incheia un subsir str. cresc. de lg. i

int cb(int val) // returneaza cel mai mic (adica din stanga) indice X a.i. dp[X] >= val
{
    int st, dr, mij;
    st = 0, dr = dp.size()-1;
    while (st <= dr)
    {
        mij = (st+dr)>>1;
        if (a[mij] >= val)
            dr = mij - 1;
        else
            st = mij + 1;
    }
    return st;
}

int main()
{
    int n, i, poz;

    fin >> n;
    a.resize(n+1), par.assign(n+1, -1);
    for (i = 1; i<=n; i++)
        fin >> a[i];

    dp.push_back(0);
    for (i = 1; i<=n; i++)
    {
        if (a[i] > a[dp.back()])
        {
            par[i] = dp.back();
            dp.push_back(i);
        }
        else
        {
            poz = cb(a[i]);
            par[i] = dp[poz-1];
            dp[poz] = i;
        }
    }

    for (i = dp.back(); i != 0; i = par[i])
        sol.push_back(a[i]);
    reverse(sol.begin(), sol.end());
    fout << dp.size()-1 << '\n';
    for (const auto &it : sol)
        fout << it << ' ';
    return 0;
}
