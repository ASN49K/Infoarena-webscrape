#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMAX = 100000;

int n, v[NMAX + 5], sir[NMAX + 5], l[NMAX + 5], f, poz;

int binarySearch(int x)
{
    int j = 0, step;
    for(step = 1 << 17; step > 0; step >>= 1)
        if(j + step <= sir[0] && sir[j + step] < x)
            j += step;
    return j;
}

int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++i)
        fin >> v[i];
        
    sir[0] = 1;
    sir[1] = v[1];
    l[1] = 1;
    f = 1;
    
    for(int i = 2; i <= n; ++i)
    {
        poz = binarySearch(v[i]);
        if(poz == sir[0])
            ++sir[0];
        
        sir[poz + 1] = v[i];
        l[i] = poz + 1;
        
        if(l[i] > l[f])
            f = i;
    }
    
    fout << l[f] << "\n";
    
    int lg = l[f];
    for(int i = f; lg; --i)
        if(l[i] == lg)
        {
            sir[lg] = v[i];
            --lg;
        }
    
    for(int i = 1; i <= l[f]; ++i)
        fout << sir[i] << " ";
}