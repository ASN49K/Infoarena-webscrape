#include <bits/stdc++.h>

using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

const int NMAX=100005;

int v[NMAX], valmin[NMAX], tata[NMAX], rasp[NMAX];

int cb(int x, int dr)
{
    int st=1, mij;
    int ans=0;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(x<=v[valmin[mij]])
        {
            dr=mij-1;
        }
        else
        {
            ans=mij;
            st=mij+1;
        }
    }
    return ans;
}

int main()
{
    int n;
    in>>n;
    int ans=0, pozans=0;
    v[0]=1e9;
    for(int i=1;i<=n;i++)
    {
        in>>v[i];
        int poz=cb(v[i], ans);
        tata[i]=valmin[poz];
        if(v[i]<v[valmin[poz+1]])
            valmin[poz+1]=i;
        if(poz+1>ans)
        {
            rasp[1]=i;
            ans=poz+1;
        }
    }
    /*for(int i=1;i<=ans;i++)
        out<<v[valmin[i]]<<" ";
    out<<'\n';
    for(int i=1;i<=n;i++)
        out<<tata[i]<<" ";
    out<<'\n';*/
    out<<ans<<'\n';
    for(int i=2;i<=ans;i++)
    {
            rasp[i]=tata[rasp[i-1]];
    }
    for(int i=ans;i>=1;i--)
    {
            out<<v[rasp[i]]<<" ";
    }
    return 0;
}
