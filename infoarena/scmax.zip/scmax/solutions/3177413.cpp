#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("scmax.in");
ofstream fout ("scmax.out");
int a[100001],n,d[100001],p[100001],k;
int main()
{
    fin >>n;
    for (int i=1;i<=n;i++)
        {fin >>a[i];}
    k=1;
    d[k]=a[1];
    p[1]=1;
    for (int i=2;i<=n;i++)
        {if (a[i]>d[k]) {k++;d[k]=a[i];p[i]=k;}
         else {int st=1,dr=k,poz=k+1;
               while (st<=dr)
                     {int m=(st+dr)/2;
                      if (d[m]>=a[i]) {poz=m;dr=m-1;}
                      else st=m+1;}
               d[poz]=a[i];
               p[i]=poz;}}
    fout <<k<<'\n';
    for (int i=1;i<=k;i++)
    {
        fout <<d[i]<<' ';
    }
    return 0;
}
