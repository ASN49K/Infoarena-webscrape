#include <bits/stdc++.h>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main(){
    int n;
    fin>>n;
    vector<int> v(n+1), d(n+1, INT_MAX), prev(n+1, -1), index(n+1, -1);
    d[0]=INT_MIN;
    for(int i=1;i<=n;i++){
        fin>>v[i];
        int l=upper_bound(d.begin(),d.end(),v[i])-d.begin();
        if(d[l-1]<v[i] and v[i]<d[l]){
            d[l]=v[i];
            index[l] = i;
            if(l>0){
                prev[i]=index[l-1];
            }else{
                prev[i]=-1;
            }
        }
    }
    int lungime, indice;
    for(int l=n;l>=1;l--) {
        if(d[l] != INT_MAX) {
            lungime=l;
            indice=index[l];
            break;
        }
    }
    vector<int> ans;
    while(indice>0){
        ans.push_back(v[indice]);
        indice=prev[indice];
    }
    fout<<lungime<<'\n';
    reverse(ans.begin(),ans.end());
    for(int i:ans){
        fout<<i<<' ';
    }
}
