//#include <iostream>
#include <fstream>
using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int n,d[100005],v[100005];
int main(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>v[i];
    }
    d[1]=1;
    for(int i=2;i<=n;i++){
        d[i]=1;
        for(int j=1;j<i;j++){
            if(v[j]<v[i]){
                ///candidate
                d[i]=max(d[i],d[j]+1);
            }
        }
    }
    int maxi=1;
    for(int i=1;i<=n;i++){
        maxi=max(maxi,d[i]);
    }
    cout<<maxi;
    return 0;
}