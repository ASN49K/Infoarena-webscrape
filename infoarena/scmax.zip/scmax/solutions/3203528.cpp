//https://www.infoarena.ro/problema/scmax
#include <bits/stdc++.h>
using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int v[100010],d[100010],ret[100010];
int main()
{
    int n,i;
    int l=0,k;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];

        if(d[l]<v[i])
        {
            l++;
            d[l]=v[i];
            ret[i]=l;
        }
        else
        {
            if(d[l]!=v[i])
            {
                int st=1,dr=l;
                while(st<=dr)
                {
                    int mij=(st+dr)/2;
                    if(v[i]<d[mij])
                    {
                        k=mij;
                        dr=mij-1;
                    }
                    else
                    {
                        st=mij+1;
                    }
                }
                d[k]=v[i];
                ret[i]=k;
            }
        }
    }
    fout<<l<<"\n";
    vector <int> ve;
    i=n;
    int j=l;
    while(i>=1&&j>=1)
    {
        if(ret[i]==j)
        {
            j--;
            ve.push_back(v[i]);
        }
        i--;
    }
    for(i=ve.size()-1;i>=0;i--)
        fout<<ve[i]<<" ";


    return 0;
}
