#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
ifstream in("scmax.in");
ofstream out("scmax.out");
const int NMAX=100005;
pair<int,int>v[NMAX];
int arb[4*NMAX];
bool cmp(pair<int,int> a, pair<int,int> b)
{
    if(a.first==b.first)
        return a.second>b.second;
    return a.first<b.first;
}
void query(int nod, int st, int dr, int a, int b, int &maxim)
{
    if(st>=a && dr<=b)
    {
        maxim=max(maxim,arb[nod]);
        return;
    }
    int m=(st+dr)/2;
    if(a<=m)
        query(2*nod, st,m,a,b,maxim);
    if(b>=m+1)
        query(2*nod+1, m+1,dr,a,b,maxim);
}
void update(int nod, int st, int dr, int pos, int val)
{
    if(st==dr)
    {
        arb[nod]=val;
        return;
    }
    int m=(st+dr)/2;
    if(pos<=m)
        update(2*nod, st,m,pos,val);
    else
        update(2*nod+1,m+1,dr,pos,val);
    arb[nod]=max(arb[2*nod],arb[2*nod+1]);


}
int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>v[i].first;
        v[i].second=i;
    }
    sort(v+1,v+n+1,cmp);
   /* for(int i=1; i<=n; i++)
    {
        cout<<v[i].first<<" ";
    }
    cout<<endl;
        for(int i=1; i<=n; i++)
    {
        cout<<v[i].second<<" ";
    }*/
    int maxim;
    for(int i=1; i<=n; i++)
    {
        maxim=0;
        // det maxim in intervalul v[i].second(pozitie)
        query(1,1,n,1,v[i].second,maxim);
        update(1,1,n,v[i].second,maxim+1);
    }
    /*for(int i=1; i<=2*n-1; i++)
        cout<<arb[i]<<" ";*/
    out<<arb[1];
    return 0;
}
