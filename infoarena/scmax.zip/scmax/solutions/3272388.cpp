#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

#define cin fin
#define cout fout

ifstream cin("sclm.in");
ofstream cout("sclm.out");

const int MAX = 1e3 + 7;
const int INF = 2e9 + 7;
int v[MAX];
int dp[MAX];
int poz[MAX];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, pozmax = 0;
    cin >> n;

    for (int i = 1; i <= n; i++)
    {
        poz[i] = INF;
    }
    for (int i = 1; i <= n; i++)
    {
        cin >> v[i];
        int st = 0, e = 0;
        while ((1 << (e + 1)) <= pozmax)
        {
            e++;
        }
        while (e >= 0)
        {
            if (st + (1 << e) <= pozmax && poz[st + (1 << e)] < v[i])
            {
                st += (1 << e);
            }
            e--;
        }
        dp[i] = st + 1;
        poz[dp[i]] = min(poz[dp[i]], v[i]);
        pozmax = max(pozmax, dp[i]);
    }
    cout << pozmax << '\n';
    vector <int> ans;
    for (int i = n; i > 0; i--)
    {
        if (dp[i] == pozmax)
        {
            ans.push_back(i);
            pozmax--;
        }
    }
    reverse(ans.begin(), ans.end());
    for (auto f : ans)
    {
        cout << f << " ";
    }
    return 0;
}
