#include <iostream>
#include <fstream>
#include <vector>

std::ifstream in("scmax.in");
std::ofstream out("scmax.out");


void maximumIncreasingSubsequence(const std::vector<int>& sequence, std::vector<int>& sq)
{
    std::vector<int> position(sequence.size(), -1);
    std::vector<int> subsequence;
    subsequence.reserve(sequence.size());

    if (sequence.size() == 0)
        return;

    subsequence.push_back(sequence[0]);
    position[0] = 0;
    int bestPos = 0;

    int sequenceSize = sequence.size();
    for (int i = 0; i < sequenceSize; i++)
    {
        for (int j = subsequence.size() - 1; j > -1; j--)
        {
            if (j == 0 && subsequence[0] > sequence[i])
            {
                subsequence[0] = sequence[i];
                position[i] = 0;
                if (position[i] > bestPos)
                {
                    bestPos = position[i];
                }
                break;
            }

            if (subsequence[j] < sequence[i])
            {
                if (j == subsequence.size() - 1)
                {
                    subsequence.push_back(sequence[i]);
                    position[i] = j + 1;
                    if (position[i] > bestPos)
                    {
                        bestPos = position[i];
                    }
                    break;
                }
                subsequence[j + 1] = sequence[i];
                position[i] = j + 1;
                if (position[i] > bestPos)
                {
                    bestPos = position[i];
                }
                break;
            }
        }
    }

    int pos = bestPos + 1;
    sq.resize(pos);
    for (int i = position.size() - 1; i > -1; i--)
    {
        if (position[i] == pos - 1)
        {
            pos = position[i];
            sq[pos] = sequence[i];
        }
    }
}

int main() {
    int n;
    in >> n;
    std::vector<int> sequence;
    sequence.reserve(n);

    int aux;
    for (int i = 0; i < n; i++)
    {
        in >> aux;
        sequence.push_back(aux);
    }

    std::vector<int> subsequence;
    maximumIncreasingSubsequence(sequence, subsequence);

    out << subsequence.size() << '\n';

    for (auto& i : subsequence)
        out << i << ' ';

    return 0;
}