#include <fstream>

using namespace std;

ifstream f("scmax.in");
ofstream g("scmax.out");

const int nmax = 100005;
int n, min_val[nmax], a[nmax], len;

int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++)
        f >> a[i];

    for(int i = 1; i <= n; i ++)
    {
        int p = lower_bound(min_val + 1, min_val + len + 1, a[i]) - min_val;
        if(p > len)
            len ++;
        min_val[p] = a[i];
    }

    g << len << '\n';
    for(int i = 1; i <= len; i ++)
        g << min_val[i] << " ";
    return 0;
}
