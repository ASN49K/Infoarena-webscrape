#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n, k;
int a[100005], dp[100005];

void CautBin(int x)
{
    if (x > dp[k])
        dp[++k] = x;
    else if (x <= dp[1])
        dp[1] = x;
    else 
    {
        int st, dr, mij, p;
        st = 1; dr = p = k;
        while (st <= dr)
        {
            mij = (st + dr) / 2;
            if (x <= dp[mij])
            {
                p = mij;
                dr = mij - 1;
            }
            else st = mij + 1;
        }
        dp[p] = x;
    }
}

int main()
{
    int i;
    fin >> n;
    for (i = 1; i <= n; i++)    
        fin >> a[i];
    dp[++k] = a[1];
    for (i = 1; i <= n; i++)
        CautBin(a[i]);
    
    fout << k << "\n";
    for (i = 1; i <= k; i++)
        fout << dp[i] << " ";
    return 0;
}