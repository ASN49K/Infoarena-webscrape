#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("scmax.in");
ofstream fout("scmax.out");
int v[100001], z, ans[100001], rec[100001], pstart, ans2[100001];
int main()
{
    int n;
    fin >> n;
    for(int i = 1; i<=n; i++)
    {
        fin >> v[i];
    }
    for(int i = 1; i<=n; i++)
    {
        int x = v[i];
        if(z == 0)
        {
            ans[++z] = x;
        }
        else
        {
            int poz = lower_bound(ans+1, ans+1+z, x) - ans;
            if(poz > z)
            {
                pstart = i;
                ans[++z] = x;
            }
            else
            {
                ans[poz] = x;
            }
        }
        rec[i] = z;
    }
    fout << z << '\n';
    int m = 0;
    for(int i = pstart; i>0; i--)
    {
        if(rec[i] == z)
        {
            ans2[++m] = v[i];
            z--;
        }
    }
    for(int i = m ; i>0; i--)
    {
        fout << ans2[i] << ' ';
    }
    return 0;
}
