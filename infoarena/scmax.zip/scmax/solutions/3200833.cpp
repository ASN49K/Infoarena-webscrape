#include <fstream>
#include <algorithm>
using namespace std;
const int Vmax = 100001;
int a[Vmax];
int minVal[Vmax];
int lMax;

int main(){
    ifstream fin("scmax.in");
    ofstream fout("scmax.out");
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>a[i];
    for(int i=1;i<=n;i++){
        if(minVal[lMax] < a[i]){
            lMax++;
            minVal[lMax] = a[i];
        }
        else{
            int poz = upper_bound(minVal+1, minVal+lMax+1, a[i]) - minVal + 1;
            minVal[poz] = a[i];
        }
    }
    fout<<lMax<<'\n';
    for(int i=1;i<=lMax;i++)
        fout<<minVal[i]<<" ";
    return 0;
}