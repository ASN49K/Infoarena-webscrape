#include <algorithm>
#include <fstream>
#include <vector>
#define FAST ios_base::sync_with_stdio(false);

using namespace std;
using vi=vector<int>;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

const int N=1e5+2;
const int inf=1e9;

int n,ans,i;
int v[N],poz[N],prevv[N];

void out(int nod)
{
    if(!nod)
        return;
    out(prevv[nod]);
    cout<<v[nod]<<' ';
}

int main()
{
    FAST
    cin>>n;
    vi dp(n+2,inf); dp[0]=-inf;
    for(i=1; i<=n; i++)
        cin>>v[i];
    
    for(i=1; i<=n; i++)
    {
        int lg=upper_bound(dp.begin(),dp.end(),v[i])-dp.begin();
        if(dp[lg-1]<v[i] && v[i]<dp[lg])
        {
            dp[lg]=v[i];
            poz[lg]=i;
            prevv[i]=poz[lg-1];
            ans=max(ans,lg);
        }
    }
    
    cout<<ans<<'\n';
    out(poz[ans]);
    return 0;
}