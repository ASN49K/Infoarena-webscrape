import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "scmax.in";
    static final String OUTPUT_FILE = "scmax.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    static class FenwickNode {
        int idx;
        FenwickNode prev;
        int maxLength;

        public FenwickNode() {
        }

        public FenwickNode(int idx, FenwickNode prev, int maxLength) {
            this.idx = idx;
            this.prev = prev;
            this.maxLength = maxLength;
        }
    }

    static class FenwickTreeMax {
        private final FenwickNode[] nodes;
        private final int n;

        public FenwickTreeMax(int n) {
            this.n = n;
            this.nodes = new FenwickNode[n + 1];
            for (int i = 1; i <= n; ++i) {
                this.nodes[i] = new FenwickNode(i, null, 0);
            }
        }

        public FenwickNode queryMax(int index) {
            FenwickNode max = new FenwickNode(-1, null, 0);
            while (index > 0) {
                max = max(max, nodes[index]);
                index -= (index & (-index));
            }
            return max;
        }

        public void update(int index, FenwickNode value) {
            while (index <= n) {
                nodes[index] = max(nodes[index], value);
                index += (index & (-index));
            }
        }

        private FenwickNode max(FenwickNode n0, FenwickNode n1) {
            return (n0.maxLength > n1.maxLength) ? n0 : n1;
        }

        public List<Integer> buildSolution(int[] a, int[] sorted) {
            FenwickNode it = queryMax(n);
            List<Integer> solution = new ArrayList<>();
            do {
                solution.add(sorted[it.idx- 1]);
                it = it.prev;
            } while (it != null);
            Collections.reverse(solution);
            return solution;
        }
    }

    public static void solve(TokenizedReader reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        int[] a = new int[n];
        int[] sorted = new int[n];
        for (int i = 0; i < n; ++i) {
            a[i] = sorted[i] = reader.nextInt();
        }
        Arrays.sort(sorted);
        // remove duplicates from sorted
        int cntUnique = 1;    // skip first
        for (int i = 1; i < n; ++i) {
            if (sorted[i] != sorted[cntUnique - 1]) {
                sorted[cntUnique] = sorted[i];
                ++cntUnique;
            }
        }

        for (int i = 0; i < n; ++i) {
            a[i] = Arrays.binarySearch(sorted, 0, cntUnique, a[i]) + 1;
        }

        FenwickTreeMax fenwickTree = new FenwickTreeMax(n);
        for (int i = 0; i < n; ++i) {
            FenwickNode maxNode = fenwickTree.queryMax(a[i] - 1);
            fenwickTree.update(a[i], new FenwickNode(a[i], maxNode.idx == -1 ? null : maxNode, 1 + maxNode.maxLength));
        }

        int best = fenwickTree.queryMax(n).maxLength;
        writer.println(best);

        List<Integer> solution = fenwickTree.buildSolution(a, sorted);
        for (int i = 0; i < best; ++i) {
            writer.print(solution.get(i) + " ");
        }
    }
}