#include <bits/stdc++.h>
#define DIM 100010
using namespace std;

ifstream fin("scamx.in");
ofstream fout("scmax.out");

int v[DIM], t[DIM], d[DIM], sol, u, n;

void reconstruct_lis(int u){
    if(u != 0){
        reconstruct_lis(t[u]);
        fout << v[u] << ' ';
    }
}

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> v[i];
        
    d[1] = 1;

    for(int i = 2; i <= n; i++) {
        int maxim = 0, p = 0;
        for(int j = 1; j < i; j++) {
            if(v[i] > v[j] && d[j] > maxim) {
                maxim = d[j];
                p = j;
            }
        }
        d[i] = maxim + 1;

        t[i] = (d[i] != 1) ? p : 0 ;

        if(d[i] > sol){
            sol = d[i];
            u = i;
        }
    }

    fout << sol << '\n';
    reconstruct_lis(u);
}