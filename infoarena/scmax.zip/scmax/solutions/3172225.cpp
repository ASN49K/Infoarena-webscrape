#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

int v[NMAX + 1];
int smallest[NMAX + 1];
int prevv[NMAX + 1];

int main() {
    ifstream fin( "scmax.in" );
    ofstream fout( "scmax.out" );
    int n, lmax;
    fin >> n;
    for ( int i = 1; i <= n; i ++ ) fin >> v[i];

    smallest[1] = 1;
    lmax = 1;
    for ( int i = 2; i <= n; i ++ ) {
        int st = 0, dr = lmax + 1;
        while ( st < dr - 1 ) {
            int mij = ( st + dr ) / 2;
            if ( v[smallest[mij]] < v[i] ) {
                st = mij;
            } else {
                dr = mij;
            }
        }
        prevv[i] = smallest[st];
        smallest[st + 1] = i;
        lmax = max( lmax, st + 1 );
    }
    vector <int> subsir;
    for ( int i = smallest[lmax]; i != 0; i = prevv[i] ) {
        subsir.push_back( v[i] );
    }
    reverse( subsir.begin(), subsir.end() );
    fout << lmax << '\n';
    for ( auto x : subsir ) {
        fout << x << ' ';
    }
    return 0;
}
