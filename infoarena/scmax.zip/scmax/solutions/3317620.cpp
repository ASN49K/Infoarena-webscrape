#include <fstream>
#include <climits>

using namespace std;

const int N = 1e5;

ifstream in("scmax.in");
ofstream out("scmax.out");

int x[N], lung[N], val_min[N+1];

void refac_subsirul(int p, int lungime, int val_min)
{
    if (lungime == 0)
    {
        return;
    }
    if (lung[p] == lungime && x[p] < val_min)
    {
        refac_subsirul(p - 1, lungime - 1, x[p]);
        out << x[p] << " ";
    }
    else
    {
        refac_subsirul(p - 1, lungime, val_min);
    }
}

int caut_bin(int v[], int n, int x)
{
    ///cautam binar cel mai mare indice j cu proprietatea ca val_min[j] < x
    int st = 1, dr = n, rez = st - 1;
    while (st <= dr)
    {
        int m = (st + dr) / 2;
        if (v[m] < x)
        {
            rez = m;
            st = m + 1;
        }
        else
        {
            dr = m - 1;
        }
    }
    return rez;
}

int main()
{
    int n;
    in >> n;
    int i_max = 0;
    int n_val_min = 0;
    for (int i = 0; i < n; i++)
    {
        in >> x[i];
        int j = caut_bin(val_min, n_val_min, x[i]);
        val_min[j+1] = x[i];
        if (j + 1 > n_val_min)
        {
            n_val_min++;
        }
        lung[i] = 1 + j;
        if (lung[i] > lung[i_max])
        {
            i_max = i;
        }
    }
    out << lung[i_max] << "\n";
    refac_subsirul(i_max, lung[i_max], INT_MAX);
    in.close();
    out.close();
    return 0;
}
