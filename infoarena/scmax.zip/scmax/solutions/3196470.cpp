#include <fstream>
#include <map>
#include <set>
#define s second
#define f first
const int NMAX=100005;

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

pair<int, int> aib[NMAX];
pair<int, int> dp[NMAX];
int a[NMAX], n;
map <int, int> poz;
set <int> s;

void find(int);
void update(int, pair<int, int>);
pair<int, int> query(int);

int main()
{
    int i, cnt=0;
    pair<int, int> p;
    fin>>n;
    for(i=1; i<=n; i++) aib[i]={0, 0};
    for(i=1; i<=n; i++)
    {
        fin>>a[i];
        s.insert(a[i]);
    }
    for(auto i:s) poz[i]=++cnt;
    for(i=1; i<=n; i++)
    {
        dp[i]=max({0, i}, query(poz[a[i]]-1));
        dp[i].f++;
        update(poz[a[i]], {dp[i].f, i});
    }
    p=query(s.size());
    fout<<p.f<<'\n';
    find(p.s);
    return 0;
}

void find(int poz)
{
    if(poz==0) return;
    if(poz!=dp[poz].s) find(dp[poz].s);
    fout<<a[poz]<<' ';
}

pair<int, int> query(int poz)
{
    int i;
    pair<int, int> rez={0, 0};
    for(i=poz; i>0; i-=(i&(-i)))
    {
        rez=max(rez, aib[i]);
    }
    return rez;
}

void update(int poz, pair<int, int> val)
{
    int i;
    for(i=poz; i<=int(s.size()); i+=(i&(-i)))
    {
        aib[i]=max(aib[i], val);
    }
}
