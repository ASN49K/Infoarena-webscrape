#include <bits/stdc++.h>
using namespace std;

const int inf = 1'000'000'000;

struct aint {
    aint(int n) : n(n) {a = new int[2 * n]();}
    int n, *a;
    void update(int p, int v) {
        for(a[p += n] = v, p >>= 1; p; p >>= 1)
            a[p] = max(a[p << 1], a[p << 1 | 1]);
    }
    int query(int l, int r) {
        int ans = -inf;
        for(l += n, r += n + 1; l < r; l >>= 1, r >>= 1) {
            if(l & 1) ans = max(ans, a[l ++]);
            if(r & 1) ans = max(ans, a[-- r]);
        }
        return ans;
    }
}; 

int normalize(int *a, int n) {
    int norm[n];
    memcpy(norm, a, sizeof norm);
    sort(norm, norm + n);
    auto normend = unique(norm, norm + n);
    for(int i = 0; i < n; i ++)
        a[i] = lower_bound(norm, normend, a[i]) - norm + 1;
    return normend - norm;
}

int main() {
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    cin.tie(0)->sync_with_stdio(0);
    
    int n; cin >> n;
    int a[n] = {};
    for(int i = 0; i < n; cin >> a[i ++]);
    int og[n] = {}; memcpy(og, a, sizeof a);
    int unq = normalize(a, n);
    aint str(unq + 1);
    int dp[n] = {};
    int ans = 0;

    for(int i = 0; i < n; i ++) {
        dp[i] = 1 + str.query(0, a[i] - 1);
        ans = max(ans, dp[i]);
        str.update(a[i], dp[i]);
    }

    // int ans = str.query(0, unq - 1);
    cout << ans << '\n';
    int b[ans] = {};
    int p = 0;
    for(int i = n, j = ans, l = inf; i >= 0; i --) {
        if(dp[i] == j && a[i] < l) {
            j --;
            l = a[i];
            b[p ++] = og[i];
        }
    }

    reverse(b, b + ans);
    for(int i = 0; i < ans; i ++) {
        cout << b[i] << ' ';
    }
}