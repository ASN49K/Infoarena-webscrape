#include <stdio.h>


#define NMAX 100000

int vec[NMAX + 1];
int dp[NMAX + 1];
int pred[NMAX + 1];

FILE *fout;

int binSearch( int st, int dr, int elem ) {
  int ind, pas;

  ind = st - 1;
  pas = 1 << 16;
  while ( pas > 0 ) {
    if ( ind + pas <= dr && vec[dp[ind+pas]] < elem )
      ind = ind + pas;
    pas >>= 1;
  }

  return ind;
}

void write( int poz ) {
  if ( poz != -1 ) {
    write( pred[poz] );
    fprintf( fout, "%d ", vec[poz] );
  }
}

int main()
{
    FILE *fin;
    int num_n, ind, lmax, lun;

    fin = fopen( "scmax.in", "r" );
    fscanf( fin, "%d", &num_n );

    for ( ind = 0; ind < num_n; ind++ )
        fscanf( fin, "%d", &vec[ind] );
    fclose( fin );

    lmax = 0;
    for ( ind = 0; ind < num_n; ind++ ) {

        lun = binSearch( 0, lmax - 1, vec[ind] ) + 1;
        dp[lun] = ind;
        pred[ind] = lun > 0 ? dp[lun - 1] : -1;
        if ( lun + 1 > lmax )
          lmax = lun + 1;

    }

    fout = fopen( "scmax.out", "w" );
    fprintf( fout, "%d\n", lmax );
    write( dp[lmax - 1] );
    fclose( fout );


    return 0;
}
