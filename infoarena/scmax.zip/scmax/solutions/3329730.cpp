/*
https://infoarena.ro/problema/scmax
*/
#include <fstream>

using namespace std;

const int N = 1e5;
const int INF = 2e9 + 1;

ifstream in("scmax.in");
ofstream out("scmax.out");

int x[N], lung[N], vmin[N+1];

int caut_bin(int v[], int n, int x)
{
    int st = 1, dr = n, rez = 0;
    while (st <= dr)
    {
        int m = (st + dr) / 2;
        if (v[m] < x)
        {
            rez = m;
            st = m + 1;
        }
        else
        {
            dr = m - 1;
        }
    }
    return rez;
}

void refac_subsir(int p, int lungime, int val_min)
{
    if (lungime == 0)
    {
        return;
    }
    if (lung[p] == lungime && x[p] < val_min)
    {
        refac_subsir(p - 1, lungime - 1, x[p]);
        out << x[p] << " ";
    }
    else
    {
        refac_subsir(p - 1, lungime, val_min);
    }
}

int main()
{
    int n, n_vmin = 0;
    in >> n;
    for (int i = 0; i < n; i++)
    {
        in >> x[i];
        int j0 = caut_bin(vmin, n_vmin, x[i]);
        lung[i] = 1 + j0;
        vmin[1+j0] = x[i];
        if (j0 == n_vmin)
        {
            n_vmin++;
        }
    }
    out << n_vmin << "\n";
    refac_subsir(n - 1, n_vmin, INF);
    out << "\n";
    in.close();
    out.close();
    return 0;
}
