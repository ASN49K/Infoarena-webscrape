#include <fstream>

using namespace std;

ifstream cin("scmax.in");
ofstream cout("scmax.out");

const int NMAX = 1e5;

int v[NMAX + 1];
int d[NMAX + 1]; //d[i] - cel mai mic element in care se termina un scm de lungime i
int p[NMAX + 1]; //pozitia in d a lui v[i]
int elements[NMAX + 1];
int binary_search(int lower_bound, int len) {
    int l = 1, r = len, ans;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (d[mid] >= lower_bound)
            ans = mid, r = mid - 1;
        else
            l = mid + 1;
    }
    return ans;
}

int main() {

    int n;
    cin >> n;

    for (int i = 1; i <= n; i++)
        cin >> v[i];

    int len = 1;
    d[1] = v[1];
    for (int i = 2; i <= n; i++) 
        if (v[i] > d[len])
            d[++len] = v[i], p[i] = len;
        else
            p[i] = binary_search(v[i], len), d[p[i]] = v[i];

    cout << len << "\n";

    int i = n;
    for (int pos = len; pos >= 1; pos--) {
        while(p[i] != pos)
            i--;
        elements[pos] = v[i];
    }

    for (int ii = 1; ii <= len; ii++)
        cout << elements[ii] << ' ';
}