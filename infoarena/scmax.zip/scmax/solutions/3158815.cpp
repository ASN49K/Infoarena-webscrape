﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 100006
#define MOD 9901 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int a[nmax];
int dp[nmax], len;
int sol[nmax], lgFake, lgFakeMax;
// nu prea m am priceput la afisare...
void CB(int x)
{
	if (dp[1] > x)
	{
		dp[1] = x;
		lgFakeMax = max(lgFakeMax, lgFake);
		lgFake = 1;
		return;
	}
	if (dp[len] < x)
	{
		dp[++len] = x;
		lgFakeMax = max(lgFakeMax, lgFake);
		++lgFake;
		if (lgFake > lgFakeMax)
			for (int i = 1; i <= lgFake; i++)
				sol[i] = dp[i];
		return;
	}
	int st, dr, m, p;
	st = 1; dr = len; p = n + 1;
	while (st <= dr)
	{
		m = (st + dr) / 2;
		if (dp[m] > x)
		{
			p = m;
			dr = m - 1;
		}
		else
			st = m + 1;
	}
	dp[p] = x;
	lgFakeMax = max(lgFakeMax, lgFake);
	lgFake = p;
	if (lgFake > lgFakeMax)
		for (int i = 1; i <= lgFake; i++)
			sol[i] = dp[i];
}

int main()
{
	int i;
	fin >> n;
	for (i = 1; i <= n; i++)
		fin >> a[i];
	for (i = 1; i <= n; i++)
		CB(a[i]);
	fout << len << "\n";
	for (i = 1; i <= len; i++)
		fout << sol[i] << " ";
	fout << "\n";
	fin.close();
	fout.close();
	return 0;
}