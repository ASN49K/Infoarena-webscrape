#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int NMax = 100'000;
int N, Sol;
int V[NMax + 5], Rez[NMax + 5];

void Citire()
{
  fin >> N;
  for (int i = 1;i <= N;++i)
  {
    fin >> V[i];
  }
}
int BinSearch(int st, int dr, int val)
{
  int mij;

  while(st != dr)
  {
    mij = (st + dr) / 2;
    if (val <= Rez[mij])
      dr = mij;
    else
      st = mij + 1;
  }

  return st;
}
void Rezolvare()
{
  int LungMax = 1;
  Rez[1] = V[1];
  for (int i = 2;i <= N;++i)
  {
    if (V[i] > Rez[LungMax])
      Rez[++LungMax] = V[i];
    else
    {
      int Poz = BinSearch(1, LungMax, V[i]);
      Rez[Poz] = V[i];
    }
  }
  Sol = LungMax;
}
void Afisare()
{
  fout << Sol << "\n";

  for (int i = 1;i <= Sol;++i)
    fout << Rez[i] << " ";
}

int main()
{
  Citire();
  Rezolvare();
  Afisare();
}
