#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");

const int sz = 100000;

int n;
struct elem{
int v;
int n;
}x[sz + 5];

int d[sz + 5];

int a[4*sz + 5];

void update(int nod,int st,int dr,int poz,int val)
{
    if(st==dr)
    {
        a[nod] = val;
        return;
    }
    int mid = (st+dr)/2;
    if(poz<=mid) update(nod*2,st,mid,poz,val);
    else update(nod*2+1,mid+1,dr,poz,val);
    a[nod]=max(a[nod*2],a[nod*2+1]);
}
int query(int nod,int st,int dr,int x,int y)
{
    if(x<=st && dr<=y)
        return a[nod];
    int mid=(st+dr)/2;
    int s1=0;
    int s2=0;
    if(x<=mid)
        s1 = query(nod*2,st,mid,x,y);
    if(y>mid)
        s2 = query(nod*2+1,mid+1,dr,x,y);
    return max(s1,s2);
}


int main()
{
    fin>>n;

    vector <int> nrm(n+1);
    for(int i=1;i<=n;i++)
    {
        fin>>x[i].v;
        nrm.push_back(x[i].v);
    }
    sort(nrm.begin(),nrm.end());
    nrm.resize(unique(nrm.begin(),nrm.end())-nrm.begin());
    for(int i=1;i<=n;i++)
            x[i].n = lower_bound(nrm.begin(),nrm.end(),x[i].v)-nrm.begin()+1;
   int sol = 0;
    for(int i=1;i<=n;i++)
    {
        d[i] = query(1,1,n,1,x[i].n) + 1;
        update(1,1,n,x[i].n,d[i]);
        sol=max(sol,d[i]);
    }
    fout<<sol;


}

