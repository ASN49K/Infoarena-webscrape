#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int main()
{
    int a[100],i,n,j,poz[100],lung[100];
    fin>>n;
    for(i=1;i<=n;i++)
      fin>>a[i];
    poz[n]=-1; lung[n]=1;


    for(i=n;i>=1;i--)
    {
        poz[i]=-1; lung[i]=1;
        for(j=n;j>i;j--)
            if (a[i]<a[j]&&lung[i]<lung[j]+1)
            {
                lung[i]=lung[j]+1;
                poz[i]=j;
            }

    }

    int max=INT_MIN,poz2;
    for(i=1;i<=n;i++)
        if(lung[i]>max) {max=lung[i];
        poz2=i;}
    fout<<max<<endl;
    while(poz2!=-1)
    {
        fout<<a[poz2]<<" ";
        poz2=poz[poz2];
    }
    return 0;
}
