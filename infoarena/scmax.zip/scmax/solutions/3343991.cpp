#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int nmax = 1e5+4;

int cauta(int val);
int n, lmax, best[nmax], v[nmax], pre[nmax];

int main()
{
    fin>>n;
    v[0] = 2e9+3;
    for(int i = 1; i <= n; ++i)
    {
        fin>>v[i];
    }
    for(int i = 1; i <= n; ++i)
    {

        int l = cauta(v[i]);
        best[l+1] = i;
        pre[i] = best[l];
        lmax = max(lmax, l+1);
    }
    fout<<lmax<<"\n";

    stack<int> s;
    int i = best[lmax];
    while(i != 0)
    {
        s.push(v[i]);
        i = pre[i];
    }
    while(!s.empty())
    {
        fout<<s.top()<<" ";
        s.pop();
    }

    return 0;
}

int cauta(int val)
{
    int st = 1, dr = n;
    while(st <= dr)
    {
        int mijl = (st + dr) / 2;
        if(v[best[mijl]] >= val)
            dr = mijl - 1;
        else
            st = mijl + 1;
    }
    return dr;
}
