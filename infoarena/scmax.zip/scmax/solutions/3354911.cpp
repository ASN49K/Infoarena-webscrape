#include<fstream>
#include<algorithm>
#include<iostream>
#include<vector>
using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
vector<int>parent;
vector<int>v;
vector<pair<int,int>>sortat;
vector<int>rez;
vector<int>aib;

int lsb(int &x){
    return x&(-x);
}

void update(int poz,int val){
    poz++;
    for(int i=poz;i<aib.size();i+=lsb(i)){
        aib[i]=max(aib[i],val);
    }
}
int pozOK=0;
int query(int poz){
    int maxi=0;
    poz++;
    for(int i=poz;i>0;i-=lsb(i)){
        if(maxi<aib[i]){
            maxi=aib[i];
            pozOK=i;
        }
    }
    return maxi;
}

void rec(int &poz){
    if(poz==-1){
        return;
    }
    rez.push_back(v[poz]);
    rec(parent[poz]);
}
int main(){
    int n;
    fin>>n;
    v.resize(n);
    aib.resize(n+1,0);
    sortat.resize(n);
    for(int i=0;i<n;++i){
        fin>>v[i];
        sortat[i]=make_pair(v[i],i);
    }
    sort(sortat.begin(),sortat.end());
    vector<int>lung(n);
    parent.resize(n);
    parent[0]=-1;
    for(int i=0;i<n;++i){
        auto it=lower_bound(sortat.begin(),sortat.end(),make_pair(v[i],0));
        int ind=it-sortat.begin();
        if(ind!=0){
            lung[i]=query(ind-1);
        }
        lung[i]++;
        update(ind,lung[i]);
        if(lung[i]==1){
            parent[i]=-1;
        }else{
            parent[i]=sortat[pozOK-1].second;
        }

    }
    int final=0;
    int maxi=0;
    for(int i=0;i<n;++i){
        if(lung[i]>maxi){
            final=i;
            maxi=lung[i];
        }
    }
    fout<<maxi<<"\n";
    rec(final);
    for(int i=rez.size()-1;i>=0;--i){

        fout<<rez[i]<<" ";
    }
    return 0;
}
