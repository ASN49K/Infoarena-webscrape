#include <bits/stdc++.h>

using namespace std;
int v[100005], subsecv[100005], precedent[100005], nr[100005], ind[100005];
vector<int>rasp;
int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n;
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>v[i], subsecv[i]=INT_MAX;
    subsecv[n+1]=INT_MAX;
    int maxx=0;
    for(int i=1; i<=n; i++)
    {
        int poz=0;
        for(int k=20; k>=0; k--)
            if(poz+(1<<k)<=n && v[i] > subsecv[poz+(1<<k)])
                poz+=(1<<k);
        poz++; ///in caz ca poz=0
        maxx=max(maxx, poz);
        subsecv[poz]=v[i];
        ind[poz]=i;
        precedent[i]=ind[poz-1];
    }
    cout<<maxx<<'\n';
    int poz_curr=ind[maxx];
    for(int i=1; i<=maxx; i++)
        rasp.push_back(v[poz_curr]), poz_curr=precedent[poz_curr];
    reverse(rasp.begin(), rasp.end());
    for(auto x: rasp)
        cout<<x<<" ";
    return 0;
}
