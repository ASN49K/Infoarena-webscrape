#include <bits/stdc++.h>

using namespace std;
#define lsb(x) x&(-x)
ifstream fin("scmax.in");
ofstream fout("scmax.out");
const int N=1e5;
int v[N+11],vcop[N+11],aib[N+11],vl[N+11],vrez[N+11];
int n;
void update(int poz,int val)
{
    while(poz<=n)
    {
        aib[poz]=max(aib[poz],val);
        poz+=lsb(poz);
    }
}
int query(int poz)
{
    int rez=0;
    while(poz>0)
    {
        rez=max(rez,aib[poz]);
        poz-=lsb(poz);
    }
    return rez;
}
int main()
{
    int i,m,st,dr,mij,maxi,l,last;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];
        vcop[i]=v[i];
    }
    sort(vcop+1,vcop+n+1);
    m=1;
    for(i=2;i<=n;i++)
        if(vcop[i]!=vcop[i-1])
        {
            m++;
            vcop[m]=vcop[i];
        }
    for(i=1;i<=n;i++)
    {
        st=1;
        dr=m;
        while(st<=dr)
        {
            mij=(st+dr)/2;
            if(v[i]<=vcop[mij])
                dr=mij-1;
            else
                st=mij+1;
        }
        v[i]=dr+1;
    }
    maxi=0;
    for(i=1;i<=n;i++)
    {
        vl[i]=query(v[i]-1)+1;
        maxi=max(maxi,vl[i]);
        update(v[i],vl[i]);
    }
    fout<<maxi<<'\n';
    l=maxi;
    last=2e9+1;
    for(i=n;i>0;i--)
    {
        if(vl[i]==l && v[i]<last)
        {
            last=v[i];
            vrez[l]=vcop[v[i]];
            l--;
        }
    }
    for(i=1;i<=maxi;i++)
        fout<<vrez[i]<<" ";
    return 0;
}
