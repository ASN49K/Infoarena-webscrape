#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream in("scmax.in");
ofstream out("scmax.out");

int dp[100005];
int prev_ind[100005];
int A[100005];

int maxim(int a,int b){
    return(a>b ? a:b);
}

int main(){
    ios_base::sync_with_stdio(false);
    in.tie(NULL);
    out.tie(NULL);

    int n;
    in>>n;
    for(int i=1;i<=n;i++)
        in>>A[i];

    A[0]=-2000000005;
    A[n+1]=2000000005;
    dp[0]=0;

    int bestlen=0;
    for(int i=1;i<=n;i++){
        int pos=0;
        for(int p=20;p>=0;p--){
            if(pos+(1<<p)<=n && A[i]>A[dp[pos+(1<<p)]]){
                pos+=1<<p;
            }
        }
        pos+=1;
        dp[pos]=i;
        bestlen=maxim(bestlen,pos);
        prev_ind[i]=dp[pos-1];
    }

    out<<bestlen<<"\n";
    vector<int>res;

    int curpos=dp[bestlen];
    for(int i=1;i<=bestlen;i++){
        res.push_back(A[curpos]);
        curpos=prev_ind[curpos];
    }

    reverse(res.begin(),res.end());

    for(int x : res)
        out<<x<<" ";
}
