#include <bits/stdc++.h>

using namespace std;

ifstream f ("scmax.in");
ofstream g ("scmax.out");

const int NMAX = 1e5;
int n;
int v[NMAX+1], best[NMAX+1], prevv[NMAX+1];

int cb(int val){
    int st = 1;
    int dr = n;
    int rez = 0;
    while(st <= dr){
        int mij = (st+dr)/2;
        if(best[mij] != 2e9+1e4 and v[best[mij]] < val)
            rez = mij, st = mij+1;
        else dr = mij-1;
    }
    return rez;
}

int main()
{
    
    f >> n;
    for(int i=1; i<=n; i++)
        f >> v[i];
    fill(best, best+1+NMAX, 2e9+1e4);
    for(int i=1; i<=n; i++){
        int poz = cb(v[i]);
        best[poz+1] = i;
        prevv[best[poz+1]] = i;
        
    }
    
    int last = 0;
    int sz = 0;
    for(int i=1; i<=n; i++)
        if(best[i] != 2e9+1e4)
            sz = i, last = best[i];
    
    g << sz << endl;
    for(int i=1; i<=last; i++)
        if(best[i] != 2e9+1e4)
            g << v[prevv[best[i]]] << ' ';

    
    return 0;
}
