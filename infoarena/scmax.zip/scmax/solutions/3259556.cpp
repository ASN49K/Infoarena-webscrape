#include <bits/stdc++.h>
using namespace std;

const int MAX = 100005;
int a[MAX], pos[MAX], lis[MAX], ans[MAX], k;

int binarySearch(int x)
{
    int left = 1, right = k, ans = k;
    while (left <= right)
    {
        int middle = left + (right - left) / 2;
        if (lis[middle] >= x)
        {
            ans = middle;
            right = middle - 1;
        }
        else left = middle + 1;
    }
    return ans;
}

int main()
{
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int n;
    cin >> n;

    for (int i = 1; i <= n; ++i)
        cin >> a[i];

    k = 1;
    pos[1] = 1;
    lis[1] = a[1];

    for (int i = 2; i <= n; ++i)
    {
        if (a[i] > lis[k])
        {
            lis[++k] = a[i];
            pos[i] = k;
        }
        else if (a[i] <= lis[1])
        {
            lis[1] = a[i];
            pos[i] = 1;
        }
        else
        {
            int p = binarySearch(a[i]);
            lis[p] = a[i];
            pos[i] = p;
        }
    }

    int len = k;
    for (int i = n; i >= 1 && len > 0; --i)
    {
        if (pos[i] == len)
        {
            ans[len] = a[i];
            --len;
        }
    }

    cout << k << "\n";
    for (int i = 1; i <= k; ++i)
        cout << ans[i] << " ";

    return 0;
}
