
#include <iostream>
#include <fstream>
#include <limits>
using namespace std;

int binsearch(int arr[], int L, int R, int x){
    int l = L, h = R;

    while (l != h){
        int m = (l + h) / 2;

        if (x <= arr[m]){
            h = m;
        } else {
            l = m + 1;
        }
    }

    return l;
}

int main(){
    ifstream cin("scmax.in");
    ofstream cout("scmax.out");
    int N;
    cin >> N;

    int A[N + 1];
    for(int i = 0; i <= N; i++){
        cin >> A[i];
    }

    const int inf = std::numeric_limits<int>::max();
    int n, m, l;
    int M[N + 10];
    int best_position[N + 10];
    int ans[N + 10];

    A[N] = inf;
    n = m = l = 0;

    M[0] = A[0];
    for (int i = 1; i < N; i++)
        M[i] = inf;
    for (int i = 0; i < N; i++)
        ans[i] = inf;

    while (n != N){
        m = max(m, l + 1);
        best_position[n] = l + 1;

        l = binsearch(M, 0, m + 1, A[n + 1]);

        M[l] = min(M[l], A[n + 1]);

        n = n + 1;

    }

    l = m;
    n = N - 1;

    while (l != 0){
        if (best_position[n] == l && A[n] < ans[l]){
            ans[l - 1] = A[n];
            l = l - 1;
        }

        n = n - 1;
    }

    cout << m << '\n';
    for (int i = 0; i < m; i++)
        cout << ans[i] << " ";

    return 0;
}
