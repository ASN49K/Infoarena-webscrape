#include <bits/stdc++.h>

using namespace std;

ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n, i, r, ma, t[100002], j;
int d[100002], v[100002], p, u;

static inline void Afis(int u) {
    if(u != 0) {
        Afis(t[u]);
        fout << v[u] << " ";
    }
}

int main () {
    fin >> n;
    for(i = 1; i <= n; i++) fin >> v[i];
    d[1] = 1;
    for(i = 2; i <= n; i++) {
        ma = 0;
        for(j = 1; j < i; j++) {
            if(v[j] < v[i] && ma < d[j]) {
                ma = d[j];
                p = j;
            }
        }

        d[i] = ma + 1;

        if(d[i] != 1) t[i] = p;
        else t[i] = 0;

        if(d[i] > r)  {
            r = d[i];
            u = i;
        }
    }
    fout << r << "\n";
    Afis(u);

    return 0;
}
