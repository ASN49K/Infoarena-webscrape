#include <fstream>

using namespace std;
ifstream cin("scmax.in");
ofstream cout("scmax.out");
int n,v[100005],d[100005],ant[100005],maxi,poz,p1;
void f(int p)
{
    if(p!=0)
    {
        f(ant[p]);
        cout<<v[p]<<" ";
    }
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    d[1]=1;
    for(int i=2;i<=n;i++)
    {
        d[i]=1;
        for(int j=1;j<i;j++)
          if(v[j]<v[i]&&d[j]+1>d[i])
        {
            d[i]=d[j]+1;
            p1=j;
        }
        if(d[i]!=1)
            ant[i]=p1;
        else
            ant[i]=0;
        if(d[i]>maxi)
        {
            maxi=d[i];
            poz=i;
        }
    }
    cout<<maxi<<'\n';
   f(poz);
    return 0;
}
