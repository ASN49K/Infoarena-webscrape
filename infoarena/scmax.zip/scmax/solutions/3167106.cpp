#include <bits/stdc++.h>

using namespace std;
ifstream fin("scmax.in");
ofstream fout("scmax.out");
int n ,D[100005],v[100005],t[100005],sol,primul,ultimul,maxi=1;
void constructiedrum(int u)
{
    if(u!=0)
    {
        constructiedrum(t[u]);
        fout<<v[u]<<' ';
    }
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i];
    D[1]=1;
    ///cautare binara
    for(int i=2;i<=n;i++)
    {
        int st=1,dr=maxi;
        while(st<=dr)
        {
            int mid=(st+dr)/2;
            if(v[i]<=v[D[mid]])
                dr=mid-1;
            else
                st=mid+1;
        }
        if(st>maxi)
        {
            maxi++;
            D[maxi]=i;
            t[i]=D[st-1];
        }
        else
        {
            D[st]=i;
            t[i]=D[st-1];
        }
    }
    fout<<maxi<<'\n';
    constructiedrum(D[maxi]);
    return 0;
}
