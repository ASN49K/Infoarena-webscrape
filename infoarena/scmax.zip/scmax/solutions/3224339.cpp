#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 100006
#define MOD 9901
#define INF 2012345678
#define ll long long
using namespace std;
//#define fin cin
//#define fout cout

ifstream fin("scmax.in");
ofstream fout("scmax.out");

int n;
int a[nmax];
int sol[nmax], lg, dp[nmax], poz[nmax];

int CB(int x)
{
	if (lg == 0)
		return (++lg);
	
	if (dp[1] >= x)
		return 1;

	if (dp[lg] < x)
		return (++lg);

	int st, dr, mij, p;
	st = 1; dr = lg; p = n + 1;

	while (st <= dr)
	{
		mij = (st + dr) / 2;
		if (dp[mij] >= x)
		{
			p = mij;
			dr = mij - 1;
		}
		else
			st = mij + 1;
	}
	
	return p;
}

int main()
{
	int i, p;
	fin >> n;
	for (i = 1; i <= n; i++)
		fin >> a[i];

	for (i = 1; i <= n; i++)
	{
		p = CB(a[i]);
		dp[p] = a[i];
		poz[i] = p;
	}

	p = lg;
	for (i = n; i >= 1 && p > 0; i--)
		if (poz[i] == p)
		{
			sol[p] = a[i];
			p--;
		}

	fout << lg << "\n";
	for (i = 1; i <= lg; i++)
		fout << sol[i] << " ";
	fout << "\n";

	fout.close();
	fin.close();
	return 0;
}