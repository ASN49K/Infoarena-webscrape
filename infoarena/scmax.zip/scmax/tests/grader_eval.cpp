#include <stdio.h>
#include <stdlib.h>

int N, a[100005], sol[100005], cnt, bst;

void result(char msg[], int p)
{
    fprintf(stderr, msg);
    printf("%d", p);
    exit(0);
}

int subsir(void)
{
    int i, p = 1;

    for (i = 1; i <= N && p <= bst; ++i)
        if (a[i] == sol[p])
            ++p;

    return (p > bst);
}

int main(void)
{
    FILE *f;
    int i;    

    f = fopen("scmax.in", "r");
    
    if (!f) result("Fisier de intrare lipsa!", 0);
    if (fscanf(f, "%d", &N) != 1) result("Fisier de intrare corupt!", 0);
    if (!(1 <= N && N <= 100000)) result("Fisier de intrare corupt!", 0);
    for (i = 1; i <= N; ++i)
    {
        if (fscanf(f, "%d", &a[i]) != 1) result("Fisier de intrare corupt!", 0);
        if (!(1 <= a[i] && a[i] <= 2000000000)) result("Fisier de intrare corupt!", 0);
    }
    fclose(f);

    f = fopen("scmax.ok", "r");
    if (!f) result("Fisier ok lipsa!", 0);
    if (fscanf(f, "%d", &bst) != 1) result("Fisier ok corupt!", 0);
    fclose(f);

    f = fopen("scmax.out", "r");
    if (!f) result("Fisier de iesire lipsa!", 0);
    if (fscanf(f, "%d", &cnt) != 1) result("Fisier de iesire corupt!", 0);

    if (cnt != bst) result("Lungime incorecta!", 0);

    for (i = 1; i <= bst; ++i)
        if (fscanf(f, "%d", &sol[i]) != 1)
            result("Subsir incorect!", 5);
    if (fscanf(f, "%d", &sol[bst+1]) == 1)
            result("Subsir incorect!", 5);

    if (!subsir())
        result("Subsir incorect!", 5);
    for (i = 1; i < bst; ++i)
    {
        if (sol[i] < sol[i+1]) continue;
        result("Subsirul nu e strict crescator!", 5);
    }

    result("Corect!", 10);

    fclose(f);
    
    return 0;
}

