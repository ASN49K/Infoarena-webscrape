#include <bits/stdc++.h>
using namespace std;

const int base = 127, mod = 1000000007;

int n, m;
long long hsh[2000001], pw[2000001];
long long hshb;

int main()
{
    ifstream cin("strmatch.in");
    ofstream cout("strmatch.out");
    
    string a, b;
    cin >> b >> a;
    n = a.size();
    m = b.size();
    
    pw[0] =  1;
    for(int i = 1; i <= 2000000; i++)
        pw[i] = (pw[i-1] * base) % mod;
    
    for(int i = 0; i < m; i++)
        hshb = (hshb * base + (b[i] - '0')) % mod;
    
    for(int i = 0; i < n; i++)
        hsh[i+1] = (hsh[i] * base + (a[i] - '0')) % mod;
    
    int cnt = 0;
    
    vector<int> pos;
    for(int i = m; i <= n; i++)
    {
        long long hsh_a = (hsh[i] - ((hsh[i - m] * pw[m]) % mod) + mod) % mod;
        if(hsh_a == hshb)
        {
            cnt++;
            if(cnt <= 1000)
                pos.push_back(i - m);
        }
    }
    
    cout << cnt << '\n';
    
    for(auto x : pos)
        cout << x << " ";
    return 0;
}
