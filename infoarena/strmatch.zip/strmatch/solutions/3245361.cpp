#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
using namespace std;
int main()
{
ifstream f ("strmatch.in");
ofstream g ("strmatch.out");
string a,b;

getline (f,a);
getline (f,b);
int db=0;
vector<int>v;
int z=b.size()-a.size();

//-----------------------------------------
int e=0,ell=0,szor=1;
for (int i=0; i<a.size(); i++){ e=(e*10+a[i])%100000007;szor=szor*10;}
szor/=10;
//cout<<endl<<e<<endl;
//-----------------------------------------

for (int i=0; i<b.size(); i++) {

    //-----------------------------------------
    if (i<a.size()){ell=(ell*10+b[i])%100000007;}
    else{ ell=(ell-(b[i-a.size()]*szor))*10+b[i];
    //cout<<"<<"<<ell<<">>";
    //-----------------------------------------



    if (e==ell) {

            bool p=true;
            for (int j=0; j<a.size(); j++)
                if (a[j]!=b[i+j-a.size()+1]) {p=false; break; }

            if (p==true) {db++; if (db<=1000) v.push_back(i); }
        }

        }
    }

g<<db<<endl;
for (int i=0; i<v.size(); i++) g<<v[i]<<" ";

f.close();
g.close();
return 0;
}
