#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

const int p = 73;
const ll m = 1e9 + 9;

vector<int> p_pow;
string pattern, str;
int pattern_size, str_size;

void compute_powers()
{
    int pp = 1;
    for(int i=0; i<=str_size; i++)
    {
        p_pow.push_back(pp);
        pp = (1LL*pp*p) % m;
    }
}

ll compute_hash(string s)
{
    ll hash_val = 0;

    for(int i=0; i<s.size(); i++)
        hash_val = (hash_val + 1LL * (s[i]-'0'+1) * p_pow[i]) % m;

    return hash_val;
}

int main()
{   
    fin >> pattern >> str;
    pattern_size = pattern.size();
    str_size = str.size();

    compute_powers();

    int pattern_hash = 0;
    for(int i=0; i<pattern_size; i++)
        pattern_hash = 1LL*(pattern_hash + 1LL*(pattern[i] - '0' + 1)*p_pow[i] % m) % m;

    vector<int> pref_hash(str_size+1, 0);
    for(int i=0; i<str_size; i++)
    {
        pref_hash[i+1] = 1LL*(pref_hash[i] + 1LL*(str[i] - '0' + 1) * p_pow[i] % m) % m;
    }

    vector<int> occurences;

    for(int i=0; i<str_size - pattern_size+1; i++)
    {
        int curr_hash = (pref_hash[i + pattern_size]  + m - pref_hash[i]) % m;
        if(curr_hash == 1LL * pattern_hash * p_pow[i] % m)
            occurences.push_back(i);
    }

    fout<<occurences.size()<<'\n';
    int size = occurences.size();
    if(size > 1000)
        size = 1000;

    for(int i=0; i<size; i++)
        fout<<occurences[i]<<' ';

    return 0;
}