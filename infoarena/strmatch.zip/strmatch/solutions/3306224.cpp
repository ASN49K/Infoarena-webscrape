#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("strmatch.in");
ofstream fout ("strmatch.out");

const int Nmax=2e6+5;

string s, t;

int cnt;
int sol[Nmax];

int main(){

    fin>>t;
    fin>>s;

    for (int i=0; i<=(int)s.size()-(int)t.size(); i++){
        int j=0;
        while (j<(int)t.size() && s[i+j]==t[j])
            j++;
        
        if (j==(int)t.size()){
            sol[cnt]=i;
            cnt++;
        }
    }

    fout<<cnt<<'\n';
    for (int i=0; i<min(cnt, 1000); i++)
        fout<<sol[i]<<' ';

    return 0;
}