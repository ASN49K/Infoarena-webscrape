#include <fstream>
#include <cstring>
#define NMAX 2000009
using namespace std;
ifstream  fin("strmatch.in");
ofstream fout("strmatch.out");
int nr,n,m,urm[NMAX],v[1009];
char A[NMAX],B[NMAX];

void prefix(char ch[])
{
    int i,k=-1;
    urm[0]=0;

    for(i=1; i<n; i++)
    {
        while(k>0 && ch[k+1]!=ch[i])
        {
            k=urm[k];
        }

        if(ch[k+1]==ch[i])
        {
            k++;
        }

        urm[i]=k;
    }
}

int main()
{
    int i,k=-1;

    fin.getline(A,NMAX);
    fin.getline(B,NMAX);
    n=strlen(A);
    m=strlen(B);

    if(n>m)
    {
        fout<< 0;
        return 0;
    }

    prefix(A);

    nr=0;
    for(i=0; i<m; i++)
    {
        while(k>0 && A[k+1]!=B[i])
        {
            k=urm[k];
        }

        if(A[k+1]==B[i])
        {
            k++;
        }

        if(k==n-1)
        {
            nr++;
            if(nr<=1000)
            {
                v[nr]=i-n+1;
            }
            k=urm[k];
        }
    }

    fout<< nr << "\n";

    for(i=1; i<=nr && i<=1000; i++)
    {
        fout<< v[i] << " ";
    }

    return 0;
}
