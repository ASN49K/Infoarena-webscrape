#include <bits/stdc++.h>
using namespace std;
#define mod 1000000007
ifstream f("strmatch.in");
ofstream g("strmatch.out");
string a,b;
int ha[2000001],hb[2000001],pw[2000001];
int val(char c)
{
    if('a'<=c && c<='z')
        return c-'a'+1;
    else return c-'A'+1;
}
int hash_substr(int l,int r)
{
    return (hb[r]-1LL*hb[l-1]*pw[r-l+1]%mod+mod)%mod;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    f>>a>>b;
    a=' '+a;
    b=' '+b;
    int base=37;
    for(int i=1;i<a.size();i++)
        ha[i]=(1LL*base*ha[i-1]+val(a[i]))%mod;
    for(int i=1;i<b.size();i++)
        hb[i]=(1LL*base*hb[i-1]+val(b[i]))%mod;
    pw[0]=1;
    for(int i=1;i<=b.size();i++)
        pw[i]=pw[i-1]*base;
    vector<int> sol;
    int hash_a=ha[a.size()-1];
    for(int i=1;i+a.size()-2<b.size();i++)
        if(hash_substr(i,i+a.size()-2)==hash_a)
        if(sol.size()<1000)
            sol.push_back(i-1);
    g<<sol.size()<<'\n';
    for(auto x:sol)
        g<<x<<" ";
    return 0;
}
