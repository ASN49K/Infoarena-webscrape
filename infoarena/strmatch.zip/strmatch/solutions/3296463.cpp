#include <bits/stdc++.h>

using namespace std;

ifstream in("strmatch.in");
ofstream out("strmatch.out");

string text, pattern;

vector<int> LPS(string pattern){
    int m = pattern.size();

    vector<int> lps(m, 0);
    int len = 0;
    int i = 1;

    while(i < m){
        if(pattern[i] == pattern[len]){
            len++;
            lps[i] = len;
            i++;
        }
        else{
            if(!len){
                lps[i] = 0;
                i++;
            }
            else{
                len = lps[len - 1];
            }
        }
    }

    return lps;
}

void KMP(string text, string pattern){
    int n = text.size();
    int m = pattern.size();

    vector<int> lps = LPS(pattern);
    vector<int> position;

    int i = 0;
    int j = 0;
    while(i < n){
        if(text[i] == pattern[j]){
            i++;
            j++;
        }
        if(j == m){
            position.push_back(i - j);
            j = lps[j - 1];
        }
        else if(i < n && text[i] != pattern[j]){
            if(j != 0){
                j = lps[j - 1];
            }
            else{
                i ++;
            }
        }
    }

    out << position.size() << '\n';
    for(auto i : position){
        out << i << ' ';
    }
}

void citire(){
    in >> pattern;
    in >> text;
}

int main() {
    citire();
    KMP(text, pattern);
    return 0;
}
