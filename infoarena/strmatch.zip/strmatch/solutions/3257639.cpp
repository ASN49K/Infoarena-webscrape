#include <bits/stdc++.h>
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string s,a;
int j, lps[110],cnt;
int main()
{
    fin>>a>>s;
    s="A"+a+s;

    for(int i=1;i<s.size();++i)
        if(s[i]==s[lps[i-1]+1] && lps[i-1]+1<i)
            lps[i]=lps[i-1]+1;
        else
        {
            j=i-1;
            while(s[lps[j]+1]!=s[i] && lps[j]!=0)
                j=lps[j];

            if(lps[j]==0 && s[1]==s[i] && i>1)
                lps[i]=1;
            if(lps[j]!=0 && s[lps[j]+1]==s[i] && lps[j]+1<i)
                lps[i]=lps[j]+1;
        }

    for(int i=1;i<s.size();++i)
        cout<<s[i]<<" ";
    cout<<'\n';
    for(int i=1;i<=a.size();++i)
        cout<<a[i]<<" ";
    cout<<'\n';
    for(int i=1;i<s.size();++i)
        cout<<lps[i]<<" ";
cout<<'\n';

    for(int i=1;i<=s.size() && cnt<=1000;++i)
        if(lps[i]==a.size())
        {
            fout<<i-2*a.size()<<" ";
            ++cnt;
        }
    return 0;
}
