#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;
ifstream fcin("strmatch.in");
ofstream fout("strmatch.out");

int n=1000;
char a[2000001];
char b[2000001];
char aux[2000001];
char *p=b;
int v[1005];



int main()
{
    fcin.getline(a, 2000001);
    fcin.getline(b, 2000001);

    while (n>=0)
    {
        if (strstr(p, a))
        {
            n--;
            v[++v[0]]=strstr(p, a)-p;

            cout<<p<<" ";
            p+=v[v[0]]+1;

            if (v[0]!=1)
            {
                v[v[0]]+=v[v[0]-1]+1;
            }

            cout<<p<<"\n";
        }
        else
            break;
    }
    fout<<v[0]<<"\n";
    for (int i=1; i<=v[0]; i++)
        fout<<v[i]<<" ";
}
