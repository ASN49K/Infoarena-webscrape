#[allow(unused_imports)]
use std::io::{BufRead, BufReader, Read, Write};
use std::{cmp::min, error::Error};
use std::{
    fs::File,
    hash::{DefaultHasher, Hash},
};

const FILE: &'static str = "strmatch";

fn main() -> Result<(), Box<dyn Error>> {
    let mut fin = BufReader::new(File::open(format!("{}.in", FILE)).unwrap());
    let mut fout = File::create(format!("{}.out", FILE)).unwrap();

    //let mut debugfout = File::create("debug.out").unwrap();

    let mut a = String::new();
    let mut b = String::new();

    fin.read_line(&mut a)?;
    fin.read_line(&mut b)?;

    let a = a.trim().as_bytes();
    let m = a.len();
    let b = b.trim().as_bytes();
    let n = b.len();

    let mut ans = vec![];
    let mut hasher = DefaultHasher::new();
    let a_hash = a.hash(&mut hasher);
    for i in 0..=n - m {
        let b_hash = b[i..i + m].hash(&mut hasher);
        if a_hash == b_hash {
            if a[..] == b[i..i + m] {
                ans.push(i);
            }
        }
    }

    writeln!(&mut fout, "{}", ans.len())?;
    for &x in &ans[0..(min(ans.len(), 1000))] {
        write!(&mut fout, "{} ", x)?;
    }

    Ok(())
}
