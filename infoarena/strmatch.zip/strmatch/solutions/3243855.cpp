#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
using namespace std;
int main()
{
ifstream f ("strmatch.in");
ofstream g ("strmatch.out");
string a,b;

getline (f,a);
getline (f,b);
int db=0;
vector<int>v;
int z=b.size()-a.size();
for (int i=0; i<=z; i++) {
if (a[0]==b[i]) {
bool p=true;

for (int j=1; j<a.size(); j++)
if (a[j]!=b[i+j]) {p=false; break; }

if (p==true) {db++; if (db<=1000) v.push_back(i); }
}
}
g<<db<<endl;
for (int i=0; i<v.size(); i++) g<<v[i]<<" ";

f.close();
g.close();
return 0;
}
