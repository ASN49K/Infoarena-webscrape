#include <fstream>
#include <map>
#include <vector>
#include <algorithm>
#include <bitset>
#include <cmath>
#include <deque>
#include <math.h>
#include <queue>
#include <set>
#pragma GCC optimize ("Ofast","unroll-loops")
#pragma GCC target ("sse")
using namespace std;
#define int long long
const int mod=1e9+7;
const int val=89;
const int maxn=2e6+15;
ifstream cin("strmatch.in");
ofstream cout("strmatch.out");
int puteri[maxn];
int sp[maxn];
int hashA=0;
void solve(){
    string a;
    string b;
    cin>>a>>b;
    if (a.size()>b.size()) {
        cout<<0;
        return;
    }else if(a.size()==b.size()) {
        cout<<1;
        return;
    }
    puteri[0]=1;
    for (int i=1;i<maxn;i++)puteri[i]=(puteri[i-1]*val)%mod;
    a='#'+a;
    b='#'+b;
    for (int i=1;i<a.size();i++) {
        hashA=(hashA+(a[i]-'A'+1)*puteri[i]%mod)%mod;
    }
    for (int i=1;i<b.size();i++) {
        sp[i]=(sp[i-1]+(b[i]-'A'+1)*puteri[i]%mod)%mod;
    }
    int cnt=0;
    for (int i=1;i<=b.size()-a.size()+1;i++) {
        if ((i+a.size()-2)>=b.size())break;
        int hashb=(sp[i+a.size()-2]-sp[i-1]+mod)%mod;
        int hashc=(hashA*puteri[i-1])%mod;
        //for (int j=i;j<i+a.size()-1;j++)cout<<b[j];
        //cout<<endl<<hashb<<" "<<hashA<<endl;
        if (hashb==hashc) {
            cnt++;
        }
    }
    cout<<cnt<<'\n';
    int cnt2=0;
    for (int i=1;i<=b.size()-a.size()+1;i++) {
        int hashb=(sp[i+a.size()-2]-sp[i-1]+mod)%mod;
        int hashc=(hashA*puteri[i-1])%mod;
        if (hashb==hashc) {
            cout<<i-1<<' ';
            cnt2++;
            if (cnt2==1000)return;
        }
    }
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    t=1;
    while(t--)solve();
    return 0;
}