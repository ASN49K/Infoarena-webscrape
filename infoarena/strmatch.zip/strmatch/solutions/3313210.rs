use std::error::Error;
use std::fs::File;
#[allow(unused_imports)]
use std::io::{BufRead, BufReader, Read, Write};

const FILE: &'static str = "strmatch";

fn main() -> Result<(), Box<dyn Error>> {
    let mut fin = BufReader::new(File::open(format!("{}.in", FILE)).unwrap());
    let mut fout = File::create(format!("{}.out", FILE)).unwrap();

    let mut a = String::new();
    let mut b = String::new();

    fin.read_line(&mut a)?;
    fin.read_line(&mut b)?;

    let a = a.trim().as_bytes();
    let b = b.trim().as_bytes();

    let mut ans = vec![];
    for i in 0..(b.len() - a.len() + 1) {
        let mut ok = true;
        for j in 0..a.len() {
            //println!("i:{i}, j:{j}, a[j]:{0}, b[i+j]:{1}", a[j], b[i + j]);
            if a[j] != b[i + j] {
                ok = false;
                break;
            }
        }
        //println!("{ok}");
        if ok {
            ans.push(i);
        }
    }

    writeln!(&mut fout, "{}", ans.len())?;
    for x in ans {
        write!(&mut fout, "{} ", x)?;
    }

    Ok(())
}
