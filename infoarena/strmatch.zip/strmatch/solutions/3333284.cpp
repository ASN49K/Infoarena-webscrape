#include <fstream>
using namespace std;
ifstream cin("strmatch.in");
ofstream cout("strmatch.out");
long long P = 109, MOD = 1e9+7;
long long H, HH, num, put;
long long rez[2000005];
bool ok;
string a, b;
void verif(int poz)
{
    ok=1;
    for(int i=poz; i<poz+b.size(); i++)
    {
        if(a[i]!=b[i-poz])
        {
            ok=0;
            break;
        }
    }
    if(ok==1)
        rez[++num]=poz;
}
void rezolvare()
{
    put=1;
    for(int i=0; i<b.size(); i++)
    {
        put=put*P;
        H*=P;
        H+=(a[i]-'a'+1)%MOD;
        H%=MOD;
        HH*=P;
        HH+=(b[i]-'a'+1)%MOD;
        HH%=MOD;
    }
    if(H==HH)
        verif(0);
    for(int i=1; i<=a.size()-b.size(); i++)
    {
        H-=(a[i-1]-'a'+1)*put[b.size()-1]%MOD;
        H%=MOD;
        H*=P;
        H%=MOD;
        H+=a[i+b.size()-1]-'a'+1;
        H%=MOD;
        if(H==HH)
            verif(i);
    }
    cout << num << "\n";
    for(int i=1; i<=num; i++)
    {
        cout << rez[i] << " ";
    }
}
int main()
{
    cin >> b >> a;
    rezolvare();
    return 0;
}
