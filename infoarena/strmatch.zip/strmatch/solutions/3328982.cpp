#include <iostream>
#include <fstream>
using namespace std;
ifstream f("strmatch.in");
ofstream g("strmatch.out");
int n,m,lps[2000001],nr,k,v[2000001];
char a[2000001],b[2000001];
void calc()
{
  k=0;
  for(int i=1;i<=n-1;++i)
  {
    while(k && a[k]!=a[i-1]) k=lps[k];
    if(a[k]==a[i-1]) k++;
    lps[i]=k;
  }
}
void gasire()
{
  k=0;
  for(int i=0;i<=m-1;++i)
  {
    while(k && a[k]!=b[i-1]) k=lps[k];
    if(a[k]==b[i-1]) k++;
    if(k==n)
      if(nr<1000) v[++nr]==i;
  }
}
void afisare()
{g<<nr<<'\n';
  for(int i=1;i<=nr;++i)
    g<<v[i]<<" ";
}
int main()
{
   f>>a;
   f>>b;
    calc();
    gasire();
    afisare();
    return 0;
}
