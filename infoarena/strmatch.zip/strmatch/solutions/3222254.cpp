#include <bits/stdc++.h>

using namespace std;
const string TASK("strmatch");
ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");
#define cin fin
#define cout fout

const int N = 2e6 + 9;

int main()
{
    string s, b;

    cin >> s >> b;
    int tar = s.size();

    s.push_back('#');
    for(int i = 0; i < b.size(); ++i)s.push_back(b[i]);

    int n = s.size();
    vector<int> z(n);
    int l = 0, r = 0;
    for(int i = 1; i < n; i++) {
        if(i < r) {
            z[i] = min(r - i, z[i - l]);
        }
        while(i + z[i] < n && s[z[i]] == s[i + z[i]]) {
            z[i]++;
        }
        if(i + z[i] > r) {
            l = i;
            r = i + z[i];
        }
    }

    vector<int> ans;
    for(int i = 0; i < n; ++i)
        if(z[i] == tar && ans.size() < 1000)
            ans.push_back(i - tar - 1);

    cout << ans.size() << '\n';
    for(auto i : ans)cout << i << ' ';
    return 0;
}
