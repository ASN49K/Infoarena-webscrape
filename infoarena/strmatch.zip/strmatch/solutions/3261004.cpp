#include <bits/stdc++.h>


#define B 62
#define P 10000019
using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

/**
'0' = 0
'1' = 1
...
'9' = 9
'A' = 10
'B' = 11
...
'Z' = 35
'a' = 36
'b' = 37
...
'z' = 61
*/
char a[2000005], b[2000005];
int n, m, sol[2000005], len;
int main()
{
    int i, coda, codb, j, p62;
    fin >> a >> b;
    n = strlen(a); m = strlen(b);
    /// formam p62 = B^(n-1)
    p62 = 1;
    for (i = 1; i < n; i++)
        p62 = p62 * B % P;
    /// formam codul asociat lui a
    coda = 0;
    for (i = 0; i < n; i++)
    {
        if (a[i] <= '9') j = a[i] - '0';
        else if (a[i] <= 'Z') j = a[i] - 'A' + 10;
        else j = a[i] - 'a' + 36;
        coda = (coda * B + j) % P;
    }
    /// formam primul codb
    codb = 0;
    for (i = 0; i < n; i++)
    {
        if (b[i] <= '9') j = b[i] - '0';
        else if (b[i] <= 'Z') j = b[i] - 'A' + 10;
        else j = b[i] - 'a' + 36;
        codb = (codb * B + j) % P;
    }
    if (codb == coda)
        sol[++len] = 0;
    for (i = n; i < m; i++)
    {
        /// adaugam cifra b[i], scoatem b[i-n]
        if (b[i-n] <= '9') j = b[i-n] - '0';
        else if (b[i-n] <= 'Z') j = b[i-n] - 'A' + 10;
        else j = b[i-n] - 'a' + 36;

        codb = (codb - j * p62 % P + P) * B;

        if (b[i] <= '9') j = b[i] - '0';
        else if (b[i] <= 'Z') j = b[i] - 'A' + 10;
        else j = b[i] - 'a' + 36;

        codb = (codb + j) % P;

        if (codb == coda) sol[++len] = i - n + 1;
    }
    fout << len << "\n";
    len = min(len, 1000);
    for (i = 1; i <= len; i++)
        fout << sol[i] << " ";
    return 0;
}
