#include <fstream>
#include <vector>

using namespace std;

ifstream cin ("strmatch.in");
ofstream cout ("strmatch.out");

const int N = 5e6 + 1;
int z[N + 1];

string a, b;

vector <int> sol;

int nr;

int main()
{
    cin >> a >> b;
    b = a + '@' + b;
    for (int i = 1, l = 0, r = 0; i < b.size(); ++i)
    {
        if (i <= r)
            z[i] = min (z[i - l], r - i + 1);
        while (i + z[i] < b.size() && b[z[i]] == b[i + z[i]])
            ++z[i];
        if (i + z[i] - 1 > r)
            r = i + z[i] - 1, l = i;
    }
    for (int i = a.size() + 1; i < b.size(); ++i)
        if (z[i] == a.size())
        {
            ++nr;
            if (nr <= 1000)
                sol.push_back(i - a.size() - 1);
        }
    cout << nr << '\n';
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
