#include <fstream>
#include <vector>

using namespace std;

ifstream cin ("strmatch.in");
ofstream cout ("strmatch.out");

const int N = 4e6 + 1;
int z[N + 1];

string a, b;

int main()
{
    cin >> a >> b;
    int m = a.size();
    a = a + '@' + b;
    for (int i = 1, l = 0, r = 0; i < a.size(); ++i)
    {
        if (i <= r)
            z[i] = min (z[i - l], r - i + 1);
        while (i + z[i] < a.size() && a[z[i]] == a[i + z[i]])
            ++z[i];
        if (i + z[i] - 1 > r)
            r = i + z[i] - 1, l = i;
    }
    vector <int> sol;
    for (int i = m + 1; i < a.size(); ++i)
        if (z[i] == m)
        {
            if (sol.size() <= 999)
                sol.push_back(i - m - 1);
        }
    cout << sol.size() << '\n';
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
