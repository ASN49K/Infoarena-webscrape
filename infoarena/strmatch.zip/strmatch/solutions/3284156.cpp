#include<fstream>
#include<vector>
#include<iostream>
#include<cstring>
using namespace std;
char a[2000001];
char b[2000001];

ifstream f("strmatch.in");
ofstream g("strmatch.out");
int oo = 101010101;

int main() {
	f >> b;
	f >> a;
	int n = strlen(a);
	int m = strlen(b);
	vector<int> v;

	for (int i = 0; i < n; i++){

		if (a[i] == b[0]){
			bool ok = true;
			for (int j = 0; j < m; j++){
				if (i + j >= n){
					ok = false;
					break;
				}
				if (a[i+j] != b[j]) {
					ok = false;
					break;
				}
			}

			if (ok) {
				v.push_back(i);

			}
		}
	}
	g << v.size() << endl;
	for (auto i : v){
		g << i << " " ;
	}
	return 0;
}
