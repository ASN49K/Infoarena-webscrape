#include <cstring>
#include <fstream>
#define MOD 1001
using namespace std;

int main()
{
    ifstream fin("strmatch.in");
    ofstream fout("strmatch.out");
    char a[200001], b[200001];
    int a2 = 0, nr = 0;
    int v[200001], nv = 0;

    fin>>a>>b;

    int na = strlen(a);
    for(int i=0;i<na;i++)
    {
        int resta = a[i] - 'A';
        a2 = (a2 * 26 + resta) % MOD;
    }
    fout<<a2<<endl;



    int nb = strlen(b);
    int b2 = 0;
    for(int i=0; i<na; i++)
    {
        int r = b[i] - 'A';
        b2 = (b2 * 26 + r) % MOD;
    }

    int p = 1;
    for(int i=1;i<=na-1;i++)
        p = (p * 26) % MOD;

    fout<<b2<<endl;
    for(int i=1; i<nb - na; i++)
    {
        int r1 = b[i-1]  - 'A';
        int r2 = b[i + na - 1]  - 'A';
        b2 = ((b2 - (r1 * p) % MOD + MOD) * 26 + r2) % MOD;
        fout<<b2<<endl;
        if(a2 == b2)
        {
            nr++;
            v[nv++] = i;
        }
    }
    fout<<nr<<"\n";
    for(int i=0; i<nv; i++)
        fout<<v[i]<<" ";
    return 0;
}
