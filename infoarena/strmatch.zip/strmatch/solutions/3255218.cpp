#include <fstream>
#include <cstring>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
char a[2000005], b[2000005];
int lga, lgb, i, j, lps[2000005], len, ans, rez[2000005];
int main()
{
    fin>>a>>b;
    lga=strlen(a);
    lgb=strlen(b);
    lps[0]=0;
    i=1;
    while(i<lga)
    {
        if(a[i]==a[len])
        {
            len++;
            lps[i]=len;
            i++;
        }
        else if(a[i]!=a[len] && len==0)
        {
            lps[i]=0;
            i++;
        }
        else if(a[i]!=a[len] && len>0)
            len=lps[i-1];
    }
    i=0;
    j=0;
    while(i<lgb)
    {
        if(a[j]==b[i])
        {
            i++;
            j++;
            if(j==lga)
            {
                ans++;
                rez[ans]=i-lga;
                j=lps[j-1];
            }
        }
        else
        {
            if(j==0)
                i++;
            else
                j=lps[j-1];
        }
    }
    fout<<ans<<'\n';
    for(i=1; i<=ans; i++)
        fout<<rez[i]<<" ";

    return 0;
}
