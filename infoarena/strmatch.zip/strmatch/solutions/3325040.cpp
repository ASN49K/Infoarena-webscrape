#include <bits/extc++.h>

using namespace std;

typedef long long ll;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);
    string a, b;
    cin >> a >> b;
    string s = a + "#" + b;
    vector<int> kmp(s.size() + 1, 0);
    kmp[1] = 0;
    for (int i = 2; i <= s.size(); ++i) {
        int l = kmp[i - 1];
        while (l > 0 && s[l] != s[i - 1]) {
            l = kmp[l];
        }
        if (s[l] == s[i - 1]) {
            kmp[i] = l + 1;
        }
    }
    vector<int> v;
    for (int i = 1; i <= s.size(); ++i) {
        if (kmp[i] == a.size()) {
            v.push_back(i - 2 * a.size() - 1);
        }
        if (v.size() == 1000) break;
    }
    cout << v.size() << "\n";
    for (auto x : v) cout << x << " ";
    cout << "\n";
    return 0;
}
