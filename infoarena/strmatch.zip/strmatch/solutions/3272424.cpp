#include <iostream>
#include <fstream>
#include <vector>
#define nl '\n'

using namespace std;

ifstream fin("strmatch30.in");
ofstream fout("strmatch30.out");

const int NMAX = 4e6+5;

int pi[NMAX], cnt;
string A, B;
vector<int> pozitii;

int main()
{
    fin >> A >> B;
    B = A+"#"+B;
    pi[0] = 0;
    int n = B.size(), j = 0, m = A.size();
    for (int i = 1; i < n; i++)
    {
        while (j > 0 && B[j] != B[i])
            j = pi[j-1];
        if (B[j] == B[i])
            j++;
        pi[i] = j;
        if (pi[i] == m)
        {
            cnt++;
            if (cnt <= 1000)
                pozitii.push_back(i-2*m);
        }
    }
    fout << cnt << nl;
    for (int i : pozitii)
        fout << i << ' ';
    return 0;
}
