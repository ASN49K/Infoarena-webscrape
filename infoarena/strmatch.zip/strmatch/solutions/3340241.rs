use std::io::{BufWriter,Write};
use std::fs::{self, File};

macro_rules! parse_line{
    ($iter: expr, $($t: ty),+)=>{{
        let lines=$iter.next().unwrap();
        let mut parts=lines.split_whitespace();
        ($(parts.next().unwrap().parse::<$t>().unwrap()),+)
    }};
}

fn main()-> std::io::Result<()> {

    let content = fs::read_to_string("strmatch.in")?;
    let mut writer = BufWriter::new(File::create("strmatch.out")?);
    let mut lines=content.lines();
    let a = parse_line!(lines,String);
    let b = parse_line!(lines,String);
    let mut mystring : Vec <char> = vec![];
    for c in a.chars() {
        mystring.push(c);
    }
    mystring.push('$');
    for c in b.chars() {
        mystring.push(c);
    }
    let mut pi:Vec<i32> = vec![0; mystring.len()];
    let mut j;
    for i in 1..mystring.len() {
        j = pi[i-1];
        while j>0 && mystring[i] != mystring[j as usize] {
            j=pi[j.saturating_sub(1) as usize]
        }
        if mystring[i] == mystring[j as usize] {
            j += 1;
        }
        pi[i] = j;
    }
    let mut answer:Vec<i32> = vec![];
    for (i,&item) in pi.iter().enumerate().take(mystring.len()).skip(a.len()+1) {
        if item == a.len() as i32 {
            answer.push(i as i32 -2*(a.len() as i32));
        }
    }
    writeln!(writer,"{}",answer.len())?;
    for item in answer.iter().take(std::cmp::min(answer.len(),1000)) {
        write!(writer,"{} ",item)?;
    }
    Ok(())
}
