/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main(){

string a, b;
cin>>a>>b;

int nr=0;

while (true){
int c = b.find(a);
if(c == -1)
break;

else{
nr++;
b[c] = 0;
}
}
cout<<nr;

return 0;
}

