#include <fstream>
#include <string>
#include <vector>

using namespace std;

ifstream cin ("strmatch.in");
ofstream cout ("strmatch.out");

const int N = 4e6;
int k[N + 1];

int nr, m;

vector <int> sol;

string s, p;

int main()
{
    cin >> s >> p;
    m = s.size();
    s = s + '@' + p;
    for (int i = 1; i < s.size(); ++i)
    {
        int l = k[i - 1];
        while (l && s[l] != s[i])
            l = k[l - 1];
        if (l)
            k[i] = l + 1;
        else
            k[i] = 1;
        if (k[i] == m)
        {
            ++nr;
            if (nr <= 1000)
                sol.push_back(i - 2 * m);
        }
    }
    cout << nr << '\n';
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
