#include <bits/stdc++.h>

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

using i64 = long long; ///folosim unsigned long long
const i64 P = 144403552893599;

const int BASE = 91;

int get_c(char c) {
    if(c >= '0' && c <= '9') {
        return c - '0' + 1;
    }
    else if(c >= 'a' && c <= 'z') {
        return c - 'a' + 11;
    }
    else {
        return c - 'A' + 37;
    }
}

i64 comp_hash(string X) {
    i64 ret = 0;
    for(int i = 0; i < X.size(); i++) {
        ret = (ret * BASE + get_c(X[i])) % P;
    }
    return ret;
}

int main()
{
    string A, B;
    fin >> A >> B;
    
    i64 ha = comp_hash(A);
    
    
    i64 BASE_TO_N = 1;
    for(int i = 1; i <= A.size(); i++) {
        BASE_TO_N = (BASE_TO_N * BASE) % P;
    }
    
    vector<int> sol;
    sol.reserve(B.size());
    i64 rolling_hash = 0;
    for(int i = 0; i < B.size(); i++) {
        rolling_hash = (rolling_hash * BASE + get_c(B[i])) % P;
        if(i >= A.size()) {
            i64 to_add = BASE_TO_N * get_c(B[i - A.size()]) % P;
            to_add = P - to_add;
            rolling_hash = (rolling_hash + to_add) % P;
        }
        if(i >= A.size() - 1) {
            if(rolling_hash == ha) {
                sol.push_back(i);
            }
        }
    }
    int last_size = sol.size();
    if(sol.size() > 1000) {
        sol.resize(1000);
    }
    fout << last_size << "\n";
    for(auto s : sol) {
        fout << s - A.size() + 1 << " ";
    }
    fout << "\n";
    return 0;
}