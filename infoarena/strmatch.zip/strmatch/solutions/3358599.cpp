#include <bits/stdc++.h>
#define int long long
using namespace std;
const int Nmax = 5e5 + 5;
int arr[Nmax];

vector<int> ans;
int32_t main() {
    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string a, b; cin >> b >> a;
    int cnt = 0;
    while (cnt < a.size() && a.find(b, cnt) < a.size()) {
        ans.push_back(a.find(b, cnt));
        cnt+= ans[ans.size() - 1] + 1;
    }
    cout << ans.size() << endl;
    int len = ans.size();
    if (ans.size() > 1000) {
        len = 1000;
    }
    for (int i = 0; i < len; i++) {
        cout << ans[i] << " ";
    }
}