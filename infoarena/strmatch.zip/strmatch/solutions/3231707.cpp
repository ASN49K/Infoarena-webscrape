#include <bits/stdc++.h>
const int Mod1=666013;
#define p 127
const int Mod2=10003;
using namespace std;
ifstream ci("strmatch.in");
ofstream cou("strmatch.out");
char a[2000005],b[2000005];
int v1,v2,n,m,p1,p2,h1,h2,c[2000005],nr;
int main()
{
    ci >> a >> b;
    n=strlen(a);
    m=strlen(b);
    p1=p2=1;
    for(int i=0; i<n; i++)
    {
        h1=(h1*p+a[i])%Mod1;
        h2=(h2*p+a[i])%Mod2;
        if(i>0)
        {
            p1=(p1*p)%Mod1;
            p2=(p2*p)%Mod2;
        }
        v1=(v1*p+b[i])%Mod1;
        v2=(v2*p+b[i])%Mod2;
    }
    if(h1==v1 && h2==v2)
    {
        c[0]=1;
        nr++;
    }
    for(int i=n; i<m; i++)
    {
        v1=((v1-(b[i-n]*p1)%Mod1+Mod1)*p1+b[i])%Mod1;
        v2=((v2-(b[i-n]*p2)%Mod2+Mod2)*p2+b[i])%Mod2;
        if(h1==v1 && h2==v2)
        {
            c[i-n+1]=1;
            nr++;
        }
    }
    cou << nr;
    nr=0;
    for(int i=0; i<m && nr<1000 ; i++)
    {
        if(c[i]==1){ nr++;
        cou << i << " ";}

    }
    return 0;
}
