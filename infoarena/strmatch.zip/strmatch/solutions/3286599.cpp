#include <fstream>
#include <vector>

using namespace std;

ifstream cin ("strmatch.in");
ofstream cout ("strmatch.out");

const int N = 5e6;
int lsp[N + 1];

int nr;

string a, b;

vector <int> sol;

int main()
{
    cin >> a >> b;
    int m = a.size();
    a = a + '@' + b;
    for (int i = 1; i < a.size(); ++i)
    {
        int k = lsp[i - 1];
        while (k && a[i] != a[k])
            k = lsp[k - 1];
        lsp[i] = k;
        if (a[k] == a[i])
            lsp[i]++;
        if (i >= 2 * m && lsp[i] == m)
        {
            ++nr;
            if (nr <= 1000)
                sol.push_back(i - 2 * m);
        }
    }
    cout << nr << '\n';
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
