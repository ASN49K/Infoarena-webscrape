#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

const int LENMAX = 2000000 + 2;

int pi[LENMAX]{};

void getPi(const string& str) {
    int k = 0;
    for (int i = 1; i < int(str.size()); i++) {
        while (k && str[i] != str[k])
        k = pi[k - 1];
        if (str[i] == str[k])
            k++;
        pi[i] = k;
    }
}

vector<int> occ;

void kmp(const string& str, const string& pat) {
    int k = 0;
    for (int i = 1; i < int(str.size()); i++) {
        while (k && str[i] != pat[k])
            k = pi[k - 1];
        if (str[i] == pat[k])
            k++;
        pi[i] = k;
        if (k == int(pat.size()))
            occ.push_back(i - k + 1);
    }
}

int main() {
    ifstream in("strmatch.in");
    ofstream out("strmatch.out");
    string pat;
    string txt;
    in >> pat >> txt;
    getPi(pat);
    kmp(txt, pat);

    out << occ.size() << "\n";

    for (int i = 0; i < min(int(occ.size()), 1000); i++)
        out << occ[i] << ' ';
}
