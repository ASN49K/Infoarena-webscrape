﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.9.34728.123
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "g1 dances", "g1 dances.vcxproj", "{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Debug|x64.ActiveCfg = Debug|x64
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Debug|x64.Build.0 = Debug|x64
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Debug|x86.ActiveCfg = Debug|Win32
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Debug|x86.Build.0 = Debug|Win32
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Release|x64.ActiveCfg = Release|x64
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Release|x64.Build.0 = Release|x64
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Release|x86.ActiveCfg = Release|Win32
		{3FEBB92A-BBFC-4CE8-A16C-785EC5BE0837}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {36FE37A5-C7A0-4FC3-9436-745425C1A95F}
	EndGlobalSection
EndGlobal
