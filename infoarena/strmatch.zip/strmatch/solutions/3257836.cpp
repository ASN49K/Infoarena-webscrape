#include <bits/stdc++.h>
#define NMAX 5020200
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string s,a;
int j, lps[NMAX],cnt,nr,i=1;
int main()
{
    fin>>a>>s;
    s="A"+a+'#'+s;
    while(i<s.size())
    {
        if(s[i]==s[lps[j]+1] && lps[j]+1<i)
        {
            lps[i++]=lps[j]+1;
            j=i-1;
            if(lps[j]>=a.size())
                ++nr;
        }
        else
        {
            if(lps[j]==0)
            {
                lps[i++]=0;
                j=i-1;
            }
            j=lps[j];
        }
    }

//    for(int i=1;i<=s.size();++i)
//        cout<<s[i]<<" ";
//    cout<<'\n';
//     for(int i=1;i<=s.size();++i)
//        cout<<lps[i]<< " ";


    fout<<nr<<'\n';
    nr=min(nr, 1000);
    for(int i=a.size()+2;i<=s.size() && cnt<=nr;++i)
        if(lps[i]==a.size())
        {
            fout<<i-2*a.size()-1<<" ";
            ++cnt;
        }
    return 0;

}
