#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("strmatch.in");
ofstream fout ("strmatch.out");
int v[2000002];
string s, t;

int main(){

    fin>>t>>s;
    int cnt=0;

    for (int i=0; i<=s.size()-t.size(); i++){
        int j=0;
        while (j<t.size() && s[i+j]==t[j])
            j++;

        if (j==t.size()){
            v[cnt]=i;
            cnt++;
        }
    }

    fout<<cnt<<endl;
    for (int i=0;i<cnt;i++){
        fout<<v[i]<<" ";
    }
    return 0;
}
