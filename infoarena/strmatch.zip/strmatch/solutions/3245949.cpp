#include <fstream>
#include <vector>

int main()
{
    std::ifstream in("strmatch.in");
    std::string needle; in >> needle;
    std::string haystack; in >> haystack;
    in.close();

    std::vector lsp(needle.size(), 0);

    for (int i = 1, j = 0; i < needle.size(); i++)
    {
        while (j > 0 && needle[i] != needle[j])
            j = lsp[j - 1];
        if (needle[i] == needle[j])
            j++;
        lsp[i] = j;
    }

    std::vector<int> occurenceIndexes;

    int i = 0, j = 0;
    while (i < haystack.size())
        if (haystack[i] == needle[j])
        {
            i++;
            j++;
            if (j == needle.size())
                occurenceIndexes.push_back(i - j);
        }
        else if (j == 0)
            i++;
        else
            j = lsp[j - 1];

    std::ofstream out("strmatch.out");
    out << occurenceIndexes.size() << '\n';
    unsigned long long n = std::min(occurenceIndexes.size(), 1000ull);
    for (int ii = 0; ii < n; ii++)
        out << occurenceIndexes[ii] << ' ';
    out.close();
    return 0;
}
