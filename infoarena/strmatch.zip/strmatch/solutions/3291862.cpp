#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")
#pragma GCC target ("avx2")
#include <bits/stdc++.h>
using namespace std;
ifstream f("strmatch.in");
ofstream g("strmatch.out");
char s[2000009], t[2000009];
int lps[2000009];
int ans[2000009];
int main ()
{
    int cnt=0;
    f.getline (s+1, sizeof(s));
    f.getline (t+1, sizeof(t));
    int l1=strlen (s+1);
    for (int i=2; i<=l1; i++)
    {
        int x=lps[i-1];
        while (x>0 && s[i]!=s[x+1])
            x=lps[x];
        if (s[i]==s[x+1]) x++;
        lps[i]=x;
        //if (s[i]==s[x+1]) lps[i]=x+1;

    }
    int x=0;
    int l2=strlen(t+1);
    for (int i=1; i<=l2; i++)
    {
        while (x>0 && s[x+1]!=t[i])
            x=lps[x];
        if (s[x+1]==t[i])
            x++;
        if (x==l1) ans[++cnt]=i-l1;
    }
    g << cnt<< '\n';
    for (int i=1; i<=min (cnt, 1000); i++)
        g << ans[i] << ' ';
}
