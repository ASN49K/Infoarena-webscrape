﻿// Solutie cu KMP
#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

const int nmax = 4e6;
int n, m;
string s, t, aux;
int lps[nmax + 5]{ 0 };

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> s >> t;
    n = s.size();
    m = t.size();
    aux = '$' + s + '$' + t;
    vector<int> occ;
    for (int i = 2; i <= n + 1 + m; ++i) {
        int j = lps[i - 1];
        while (j > 0 && aux[i] != aux[j + 1]) {
            j = lps[j];
        }
        if (aux[i] == aux[j + 1]) {
            ++j;
        }
        lps[i] = j;
        if (i > n + 1 && lps[i] == n) {
            occ.push_back(i - 2  * n - 1);
        }
    }
    fout << occ.size() << nl;
    for (auto& x : occ) {
        fout << x << sp;
    }
}