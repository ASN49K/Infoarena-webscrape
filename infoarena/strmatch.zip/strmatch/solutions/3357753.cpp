#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

int main() {
    string a, b;
    bool run = true;
    int offset = 0;
    fin >> a >> b;
    while (true) {
        //cout << b.find(a) << " --- \n";
        if (b.find(a) > b.length()) {
            break;
        }
        fout << offset + b.find(a) << ' ';
        //cout << b << endl;
        offset += b.find(a)+1;
        b.erase(0, b.find(a)+1);
    }
    return 0;
}

/*
ABA
CABBCABABAB
     ABA
*/
