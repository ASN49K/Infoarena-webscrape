#include <bits/stdc++.h>

using namespace std;

ifstream f("strmatch.in");
ofstream g("strmatch.out");
//2000001
int main()
{
    char a1[2000001],b1[2000001];
    long long pp[2000001],s[2000001],x,sa,sb;
    int a[2000001],b[2000001],p,poz[1001],mod;
    p=998244353;
    mod=1000000007;
    sa=sb=0;
    pp[0]=1;
    f.getline(b1,2000001);
    int m=strlen(b1);
    f.getline(a1,2000001);
    int n=strlen(a1);
    for (int i=0; i<n; i++)
        a[i+1]=a1[i]-'0';
    for (int i=0; i<m; i++)
        b[i+1]=b1[i]-'0';
    for(x=1; x<=m; x++)
    {
        pp[x]=(pp[x-1]*p)%mod;
    }
    s[1]=a[1];
    for(x=2; x<=n; x++)
    {
        s[x]=(s[x-1]*p+a[x])%mod;
    }
    sb=b[1];
    for(x=2; x<=m; x++)
    {
        sb=(sb*p+b[x])%mod;
    }
    int j=0;
    for(x=1; x<=n-m+1; x++)
    {
        sa=(s[x+m-1]-(s[x-1]*pp[m])%mod+mod)%mod;
        if(sa==sb)
        {
            j++;
            if (j<=1000)
            {
                poz[j]=x-1;
            }
        }
    }
    g<<j<<endl;
    for (int i=1; i<=min(j,1000); i++)
        g<<poz[i]<<" ";
    return 0;
}
