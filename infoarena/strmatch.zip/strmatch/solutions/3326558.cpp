#include <bits/stdc++.h>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("strmatch.in");
ofstream g("strmatch.out");
int main() {
  string s1, s2;
  int pos = 0, cont = 0;
  vector<int> ans;
  f >> s1 >> s2;
  while (s2.find(s1, pos) != string::npos) {
    pos = s2.find(s1, pos) + 1;
    cont++;
    ans.push_back(pos - 1);
  }
  g << cont << "\n";
  for (auto it : ans)
    g << it << " ";
}
