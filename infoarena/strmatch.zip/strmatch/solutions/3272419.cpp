#include <iostream>
#include <fstream>
#include <vector>
#define nl '\n'

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

const int NMAX = 2e6+5;

int pi[NMAX], cnt;
string A, B, X;
vector<int> pozitii;

int main()
{
    fin >> A >> B;
    X = A+'#'+B;
    pi[0] = 0;
    int n = X.size(), j = 0, m = A.size();
    for (int i = 1; i < n; i++)
    {
        while (j > 0 && X[j] != X[i])
            j = pi[j-1];
        if (X[j] == X[i])
            j++;
        pi[i] = j;
        if (pi[i] == m)
        {
            cnt++;
            if (cnt <= 1000)
                pozitii.push_back(i-2*m);
        }
    }
    fout << cnt << nl;
    for (int i : pozitii)
        fout << i << ' ';
    return 0;
}
