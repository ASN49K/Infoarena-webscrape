#include <bits/stdc++.h>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string a,b;
int pi[4000005];
void kmp(string s)
{
	pi[0]=0;
	for(int i=1;i<s.size();i++)
	{
		int j=pi[i-1];
		while(j>0&&s[i]!=s[j])
			j=pi[j-1];
		if(s[i]==s[j])
			j++;
		pi[i]=j;
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
	fin.tie(0);
	fin>>a>>b;
	b=a+"#"+b;
	kmp(b);
	int ans=0;
	vector<int> sol;
	for(int i=a.size();i<b.size();i++)
	{
		//cout<<pi[i]<<' ';
		if(pi[i]==a.size())
		{
			ans++;
			if(sol.size()<1000)
				sol.push_back(i-2*a.size());
		}
	}
	fout<<ans<<'\n';
	for(int i:sol)
		fout<<i<<' ';
	fout<<'\n';
	return 0;
}
