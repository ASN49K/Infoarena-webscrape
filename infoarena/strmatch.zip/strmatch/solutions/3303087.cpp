#include <bits/stdc++.h>
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
#define int long long
const int BASE = 63, MOD1 = 1e9 + 7, MOD2 = 1e9 + 9;
string A, B;
vector<int> positions;

signed main()
{
    fin >> A >> B;
    vector<int> pwr1(A.size()), pwr2(A.size());
    pwr1[0] = pwr2[0] = 1;
    for(int i = 1; i < A.size(); i++)
    {
        pwr1[i] = (pwr1[i-1] * BASE) % MOD1;
        pwr2[i] = (pwr2[i-1] * BASE) % MOD2;
    }

    int hshA1 = 0, hshA2 = 0;
    for(int i = 0; i < A.size(); i++)
    {
        hshA1 = (hshA1 * BASE + A[i]) % MOD1;
        hshA2 = (hshA2 * BASE + A[i]) % MOD2;
    }
    int hshB1 = 0, hshB2 = 0;
    for(int i = 0; i < A.size(); i++)
    {
        hshB1 = (hshB1 * BASE + B[i]) % MOD1;
        hshB2 = (hshB2 * BASE + B[i]) % MOD2;
    }
    if(hshB1 == hshA1 && hshB2 == hshA2)
        positions.push_back(0);
    for(int i = A.size(); i < B.size(); i++)
    {
        hshB1 = (hshB1 - (B[i - A.size()] * pwr1[A.size() - 1]) % MOD1 + MOD1) % MOD1;
        hshB1 = (hshB1 * BASE + B[i]) % MOD1;
        hshB2 = (hshB2 - (B[i - A.size()] * pwr2[A.size() - 1]) % MOD2 + MOD2) % MOD2;
        hshB2 = (hshB2 * BASE + B[i]) % MOD2;

        int start = i - A.size() + 1;
        if(hshB1 == hshA1 && hshB2 == hshA2)
            positions.push_back(start);
    }
    fout << positions.size() << "\n";
    for(int i = 0; i < min(1000LL, (int)positions.size()); i++)
        fout << positions[i] << " ";

    fin.close();
    fout.close();
    return 0;
}
