#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream fin("strmatch.in");
    ofstream fout("strmatch.out");
    string sir, original;
    fin >> sir >> original;
    int dimModel = sir.size();
    sir.push_back('#');
    sir.append(original);

    int l = 0, r = 0;
    vector<int> Z(sir.size());
    for(int i=1; i<sir.size(); ++i) {
        if(i > r) {
            l = i;
            for(r=i; r < sir.size() && sir[r] == sir[r-i]; ++r);
            --r;
            Z[i] = r - l + 1;
        } else if(Z[i-l] < r-i+1) {
            Z[i] = Z[i-l];
        } else {
            l = i;
            for(r=i; r < sir.size() && sir[r] == sir[r-i]; ++r);
            --r;
            Z[i] = r-l+1;
        }
    }
    
    int potriviri = 0;
    for(int i=dimModel+1; i<sir.size(); ++i) {
        potriviri += Z[i] == dimModel;
    }
    fout << potriviri << '\n';
    for(int i=dimModel+1; i<sir.size(); ++i) {
        if(Z[i] == dimModel) {
            fout << i - dimModel - 1 << ' ';
        }
    }
    fout << '\n';

    return 0;
}
