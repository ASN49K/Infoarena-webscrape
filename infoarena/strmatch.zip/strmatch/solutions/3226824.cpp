#include <fstream>
#include <vector>

using namespace std;

ifstream cin ("strmatch.in");
ofstream cout ("strmatch.out");

const int N = 5e6;
int pi[N + 1];

vector <int> sol;

string a, s;

int nr;

int main()
{
    cin >> a >> s;
    s = a + '@' + s;
    for (int i = 1; i < s.size(); ++i)
    {
        int val = pi[i - 1];
        while (val && s[val] != s[i])
            val = pi[val - 1];
        pi[i] = val;
        if (s[val] == s[i])
            pi[i]++;
        if (pi[i] == a.size())
        {
            ++nr;
            if (nr <= 1000)
                sol.push_back(i - a.size() * 2);
        }
    }
    cout << nr << '\n';
    for (auto it : sol)
        cout << it << ' ';
    return 0;
}
