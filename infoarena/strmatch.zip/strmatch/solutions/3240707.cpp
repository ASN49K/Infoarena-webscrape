#include <fstream>
#include <string>
#include <vector>

using namespace std;

const int baza1 = 31;
const int baza2 = 37;
const int MOD1 = 599999;
const int MOD2 = 600013;

ifstream cin("strmatch.in");
ofstream cout("strmatch.out");

string pat, txt;
vector<int> pos;

void search() {
    int N = txt.size(), M = pat.size();
    int pat_hash1 = 0, text_hash1 = 0;
    int pat_hash2 = 0, text_hash2 = 0;
    int h1 = 1, h2 = 1;

    for (int i = 0; i < M - 1; i++) {
        h1 = (h1 * baza1) % MOD1;
        h2 = (h2 * baza2) % MOD2;
    }

    for (int i = 0; i < M; i++) {
        pat_hash1 = (baza1 * pat_hash1 + pat[i]) % MOD1;
        text_hash1 = (baza1 * text_hash1 + txt[i]) % MOD1;

        pat_hash2 = (baza2 * pat_hash2 + pat[i]) % MOD2;
        text_hash2 = (baza2 * text_hash2 + txt[i]) % MOD2;
    }

    for (int i = 0; i <= N - M; i++) {
        if (pat_hash1 == text_hash1 && pat_hash2 == text_hash2) {
            bool ok = 1;
            for (int j = 0; j < M and ok; j++)
                if (txt[i + j] != pat[j])
                    ok = 0;
            if (ok)
                pos.push_back(i);
        }
        if (i < N - M) {
            text_hash1 = (baza1 * (text_hash1 - txt[i] * h1) + txt[i + M]) % MOD1;
            if (text_hash1 < 0)
                text_hash1 += MOD1;

            text_hash2 = (baza2 * (text_hash2 - txt[i] * h2) + txt[i + M]) % MOD2;
            if (text_hash2 < 0)
                text_hash2 += MOD2;
        }
    }
}

int main() {
    cin >> pat >> txt;
    search();
    cout << pos.size() << '\n';
    for (int i = 0; i < min(1000, (int)pos.size()); i++)
        cout << pos[i] << ' ';
    return 0;
}
