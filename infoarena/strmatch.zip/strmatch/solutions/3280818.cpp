#include <bits/stdc++.h>
#define DIM 20000001
#define left iuehrf
#define right iuehrfui

using namespace std;

ifstream fin("strmatch.in");

ofstream fout("strmatch.out");

string a, b;

int lps[DIM];

vector <int> sol;

void Compute_LPS(){

    int j = 0;

    for(int i=1;i<a.size();i++){

        while(j > 0 && a[i] != a[j])

            j = lps[j - 1];

        if(a[i] == a[j])

            ++j;

        lps[i] = j;

    }

}

void Compute_Matches(){

    int j = 0;

    for(int i=0;i<b.size();i++){

        while(j > 0 && b[i] != a[j])

            j = lps[j - 1];

        if(b[i] == a[j])

            ++j;

        if(j == a.size()){

            if(sol.size() < 1000)

                sol.push_back(i - j + 1);

            j = lps[j - 1];

        }

    }

}

int main(){

    fin >> a >> b;

    Compute_LPS();

    Compute_Matches();

    fout << sol.size() << "\n";

    for(auto k : sol)

        fout << k << " ";

}
