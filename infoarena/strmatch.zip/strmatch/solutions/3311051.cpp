#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <iomanip>

using namespace std;

#define ll long long

// Global variables
string pattern, text;

void ReadData() {
    cin >> pattern >> text;
}
vector<int> computeLPS(){
    vector<int> lps(pattern.size(), 0);
    int i = 1;
    int len = 0;
    while(i < pattern.size()){
        if(pattern[i] == pattern[len]){
            lps[i] = len + 1;
            len++;
            i++;
        } else {
            if(len != 0) len = lps[len - 1];
            else i++;
        }
    }
    return lps;
}

void Solve() {
    int n = text.size();
    int m = pattern.size();

    vector<int> lps = computeLPS();
    int result = 0;
    vector<int> indices;
    int i = 0;
    int j = 0;
    while(i < n){
        if(text[i] == pattern[j]){
            i++;
            j++;
            if(j == m){
                result++;
                indices.push_back(i - j);
                j = lps[j - 1];;
            }
        } else {
            if( j == 0) i++;
            else j = lps[j - 1];
        }
    }
    
    cout << result << "\n";
    for(int i = 0; i < result; i++){
        cout << indices[i] << " ";
    }
    cout << "\n";
    return;
    
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);

    int t = 1;
    // cin >> t; // Uncomment for multiple test cases
    while (t--) {
        ReadData();
        Solve();   
    }
    return 0;
}