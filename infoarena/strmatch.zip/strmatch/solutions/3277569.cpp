#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>

using namespace std;

ifstream f("strmatch.in");
ofstream g("strmatch.out");

constexpr int nMax = 2'000'000;
constexpr int mMax = 2'000'000;
constexpr int MAX_AP = 1'000;

int Urm[mMax];
char T[nMax], P[mMax];
int n, m;

void Urmatorul(char *P)
{
    /// Urm[x] = lungimea celui mai lung prefix al lui P care este sufix al lui P[0...x-1].
    int k = -1, x;
    Urm[0] = 0;
    for (x = 1; x < m; x++)
    {
        while (k > 0 && P[k + 1] != P[x])
            k = Urm[k];
        if (P[k + 1] == P[x])
            k++;
        Urm[x] = k;
    }
}

int main()
{
    int x = -1, i;

    f.getline(P, mMax); m = strlen(P);
    f.getline(T, nMax); n = strlen(T);

    Urmatorul(P);
    vector<int> pos;

    for (i = 0; i < n; i++)
    {
        while (x > 0 && P[x + 1] != T[i])
            x = Urm[x];
        if (P[x + 1] == T[i])
            x++;
        if (x == m - 1)
        {
            if (pos.size() < MAX_AP)
                pos.push_back(i - m + 1);
            x = Urm[x];
        }
    }

    g << pos.size() << '\n';
    for (const int &p : pos)
        g << p << ' ';
    g << '\n';

    f.close();
    g.close();
    return 0;
}
