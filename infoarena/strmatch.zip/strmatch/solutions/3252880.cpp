#include <bits/stdc++.h>
using namespace std;
char s[4000005], w[2000005], n;
int len[4000005];
vector <int> v;
int main()
{
    ifstream f("strmatch.in");
    ofstream g("strmatch.out");
    f >> s >> w;
    int nr = strlen(s);
    int m = nr;
    int nrw = strlen(w);
    s[m++] = '$';
    for (int i = 0; i < nrw; i++)
        s[m++] = w[i];
    s[m] = '\0';
    n = strlen(s);
    for (int i = 1; i < n; i++)
    {
        int j = len[i - 1];
        while (j > 0 && s[i] != s[j])
            j = len[j - 1];
        if (s[j] == s[i])
            j++;
        len[i] = j;
        if (j == nr)
            v.push_back(i - nr- 3);
    }
    g << v.size() << "\n";
    for (int i = 0; i < v.size(); i++)
        g << v[i] << " ";
    return 0;
}
