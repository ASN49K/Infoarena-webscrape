#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>

#define filename (string)"strmatch"

using namespace std;

ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

long long plog(long long ba, long long ex, long long mod);

const int NMAX = 2e6;

struct hhash {
    long long mult, mod, val, ln;

    hhash(long long mult, long long mod, char *s, long long ln) {
        this->mult = mult;
        this->mod = mod;
        this->val = 0;
        this->ln = ln;

        for(int i = 0; i < ln; i++) {
            this->val = (this->val * mult + s[i]) % mod;
        }
    }

    void update(char toRemove, char toAdd) {
        this->val = (
            this->val +
            this->mod -
            toRemove * plog(this->mult, this->ln - 1, this->mod) % this->mod
        ) % this->mod;
        this->val = (this->val * this->mult + toAdd) % mod;
    }
};

int n, k, ansLn;
char haystack[NMAX + 1], needle[NMAX + 1];
vector<int> ans;

long long plog(long long ba, long long ex, long long mod) {
    ba %= mod;
    long long r = 1;
    for(long long i = 1; i <= ex; i <<= 1) {
        if(i & ex) r = (1ll * r * ba) % mod;
        ba = (1ll * ba * ba) % mod;
    }
    return r;
}

void read() {
    fin >> needle >> haystack;
    n = strlen(haystack);
    k = strlen(needle);
}

void process() {
    hhash n1 = hhash(811, 666013, needle, k);
    hhash n2 = hhash(911, 1e9 + 7, needle, k);

    hhash h1 = hhash(811, 666013, haystack, k);
    hhash h2 = hhash(911, 1e9 + 7, haystack, k);

    for(int i = 0; i < n - k + 1; i++) {
        if(n1.val == h1.val && n2.val == h2.val) {
            if(++ansLn <= 1000) ans.push_back(i);
        }

        h1.update(haystack[i],  haystack[i + k]);
        h2.update(haystack[i],  haystack[i + k]);
    }
}

void output() {
    // for(const auto &i : ans)
    //     cout << i << " ";

    fout << ansLn << "\n";
    for(int i = 0; i < ansLn && i < 1000; i++)
        fout << ans[i] << " ";
}

int main()
{
    read();
    process();
    output();
    return 0;
}
