#include <bits/stdc++.h>
#define int long long
#define DIM 2000001
#define mod 1000000009
#define base 1087

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

string s[2];

int n, target, len;

int hash_[2][DIM], p[DIM], ans[DIM];

int i, j;

void precalc_hash(){

    p[1] = base;

    int s0 = s[0].size(), s1 = s[1].size();

    for(int i = 2; i <= s1; i++)

        p[i] = (p[i-1] * base) % mod;

    for(int j = 1; j <= s0; j++)

        hash_[0][j] = ((hash_[0][j-1] * base) % mod + s[0][j-1]) % mod;

    for(int j = 1; j <= s1; j++)

        hash_[1][j] = ((hash_[1][j-1] * base) % mod + s[1][j-1]) % mod;

}

int get_hash(int l, int r, int i){

    int ret = hash_[i][r] - (hash_[i][l-1] * p[r-l+1]) % mod;

    return (ret + mod) % mod;

}

int32_t main(){

    fin >> s[0] >> s[1];

    precalc_hash();

    n = s[1].size() - s[0].size() + 1;

    len = s[0].size();

    target = get_hash(1, len, 0);

    for(i = 1; i <= n; i++)

        if(target == get_hash(i, i + len - 1, 1))

            ans[++j] = i-1;

    fout << j << "\n";

    for(i = 1; i <= j && i <= 1000; i++)

        fout << ans[i] << " ";

}
