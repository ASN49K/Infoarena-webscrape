#include <fstream>
#include <cstring>
#define MOD1 100007
#define MOD2 100021
#define base 73
using namespace std;

ifstream cin("strmatch.in");
ofstream cout("strmatch.out");
char a[2000005],b[2000005];
int n,m,p1,p2,hasha1,hasha2,nr,sol[1005];
int main()
{
    cin>>a>>b;
    n=strlen(a);
    m=strlen(b);
    if(n>m)
    {
        cout<<0;
        return 0;
    }
    p1=1;
    p2=1;
    hasha1=0;
    hasha2=0;
    for(int i=0; i<n; i++)
    {
        hasha1=(hasha1*base+a[i])%MOD1;
        hasha2=(hasha2*base+a[i])%MOD2;
        if(i!=0)
        {
            p1=(p1*base)%MOD1;
            p2=(p2*base)%MOD2;
        }
    }
    int hash1=0,hash2=0;
    for(int i=0; i<n; i++)
    {
        hash1=(hash1*base+b[i])%MOD1;
        hash2=(hash2*base+b[i])%MOD2;
    }
    if(hash1==hasha1 && hash2==hasha2)
        sol[++nr]=0;
    for(int i=n;i<m;i++)
    {
        hash1=(( hash1-(b[i-n]*p1)%MOD1+MOD1 )*base+b[i])%MOD1;
        hash2=((hash2-(b[i-n]*p2)%MOD2+MOD2)*base+b[i])%MOD2;
        if(hash1==hasha1 && hash2==hasha2)
        {
            nr++;
            if(nr<=1000)
                sol[nr]=i-n+1;
        }
    }
    cout<<nr<<'\n';
    if(nr>1000)
        nr=1000;
    for(int i=1;i<=nr;i++)
        cout<<sol[i]<<" ";
    return 0;
}
///Se dau doua siruri A si B formate din litere mici si mari ale alfabetului englez si din cifre.
///Se cere gasirea tuturor aparitiilor sirului A ca subsecventa a sirului B.
