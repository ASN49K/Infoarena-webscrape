#include <bits/stdc++.h>

using namespace std;

ifstream fin ("strmatch.in");
ofstream fout ("strmatch.out");

const int nmax=2e6+5;

int m, z[2*nmax], rez[1005];
string s, t;

int main()
{
    fin >> s >> t;
    int n=s.size();
    s=s+"#"+t;
    int best=0;
    for (int i=1; i<s.size(); i++)
    {
        if (i<=best+z[best]-1)
            z[i]=min(z[i-best],best+z[best]+i);
        while (i+z[i]<s.size() && s[z[i]]==s[i+z[i]])
            z[i]++;
        if (i+z[i]-1>best+z[best]-1)
            best=i;
        if (z[i]==n)
        {
            m++;
            if (m<=1000)
                rez[m]=i-n-1;
        }
    }
    fout << m << '\n';
    for (int i=1; i<=min(m,1000); i++)
        fout << rez[i] << ' ';
    return 0;
}
