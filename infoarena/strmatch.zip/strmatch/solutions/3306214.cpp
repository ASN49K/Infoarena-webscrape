#include <bits/stdc++.h>
using namespace std;
int idxb , cnt;
vector < int > v;
int main () {
    ifstream cin ( "strmatch.in" );
    ofstream cout ( "strmatch.out" );
    string a , b;
    int idxa;
    cin >> a >> b;
    while ( idxb < b.size () && v.size () < 1000 ) {
        idxa = 0;
        while ( idxa < a.size () && b[idxb + idxa] == a[idxa] )
            idxa++;
        if ( idxa == a.size () ) {
            cnt++;
            if ( v.size () < 1000 )
                v.push_back ( idxb );
        }
    }
    cout << cnt << '\n';
    for ( idxa = 0 ; idxa < v.size () ; idxa++ )
        cout << v[idxa] << ' ';
    cout << '\n';
    return 0;
}
