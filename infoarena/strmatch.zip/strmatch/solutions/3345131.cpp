#include <cstring>
#include <iostream>

#define NMAX 2000005

int main()
{
    int n, m, cnt = 0;
    char t[NMAX], p[NMAX];
    int pos[1005];
    
    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);

    scanf("%s %s", p, t);

    m = strlen(p);
    n = strlen(t);

    for (int i = 0, j; i < n && cnt < 1005; ++i) {
        for (j = 0; i + j < n && j < m; ++j)
            if (t[i + j] != p[j])
                break;

        if (j == m)
            pos[cnt++] = i;
    }

    std::cout << cnt << '\n';

    for (int i = 0; i < cnt; ++i)
        std::cout << pos[i] << ' ';

    std::cout << '\n';

    return 0;
}
