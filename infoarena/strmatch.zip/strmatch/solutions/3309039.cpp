#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <algorithm>
#include <vector>
#include <cmath>
#define ll long long
#define mod 1000000007
using namespace std;
const string h="vnoroc";
ifstream fin(h+".in");
ofstream fout(h+".out");
int main()
{
    string a,b;
    cin>>a>>b;
    ll t=a.size(),y=b.size(),cnt=0;
    map<string,int> m;
    vector<int> ind;
    m[a]=1;
    for(ll i=0;i<y-t+1;i++){
        if(m[b.substr(i,t)]==1){cnt++;ind.push_back(i);}
    }
    cout<<cnt<<'\n';
    for(ll i=0;i<min(cnt,1000ll);i++)cout<<ind[i]<<' ';
    return 0;
}
