#include <bits/stdc++.h>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
long long mod=1e9+7;
int base=65 ;
long long h=0;
char smic[2000000];
char smare[2000000];
long long H=0;
long long hash1=0;
long long v[2000];

int cnt=0;

int main()
{
    fin.getline(smic,2000000);
    fin.getline(smare,2000000);

    for(int i=0; i<strlen(smic); i++)
    {
        H=(H*base+(smic[i]))%mod;
    }

    long long NMIC=strlen(smic);
    long long power=1;
    long long NMARE=strlen(smare);
    for(int i=0; i<NMIC; i++)
    {
        hash1=(hash1*base+smare[i])%mod;
        if(i!=0)
        {
            power=(power*base)%mod;
        }
    }
    if(hash1==H)
    {
        v[cnt++]=0;
    }

    for(int i=NMIC;i<=NMARE; i++)
    {
        hash1=((hash1-(smare[i-NMIC]*power)%mod+mod)*base+smare[i])%mod;
        if(hash1==H)
        {
            if(cnt<=1000)
            {
                v[cnt]=i-NMIC+1;
            }
            cnt++;
        }
    }
    fout<<cnt<<'\n';
    for(int i = 0; i <cnt and i<1000; i++)
        fout << v[i] << " ";

    return 0;
}
