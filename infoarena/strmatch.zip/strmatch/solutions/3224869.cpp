#include <bits/stdc++.h>

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

int main()
{
    string a, b;
    getline(fin, a);
    getline(fin, b);
    int nr=0, left=0, right=0, idx=0, sol[1005];
    while(right<b.size()) {
        if(idx==a.size()) {
            if(nr<1000) {
                sol[nr]=left;
            }
            nr++;
            idx=0;
            left++;
            while(b[left]!=a[idx] && left<b.size()) {
                left++;
            }
            right=left;
        }
        if(b[right]==a[idx]) {
            idx++;
            right++;
        } else {
            idx=0;
            left++;
            while(b[left]!=a[idx] && left<b.size()) {
                left++;
            }
            right=left;
        }
    }
    if(idx==a.size()) {
        if(nr<1000) {
            sol[nr]=left;
        }
        nr++;
    }
    fout << nr << "\n";
    for(int i=0; i<nr && i<1000; i++) {
        fout << sol[i] << " ";
    }
    return 0;
}
