#include <iostream>

int main()
{
    int n, m, cnt = 0;
    std::string t, p;
    int pos[1000];
    
    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);

    std::cin >> p >> t;

    m = p.length();
    n = t.length();

    for (int i = 0, j; i < n; ++i) {
        for (j = 0; i + j < n && j < m; ++j)
            if (t[i + j] != p[j])
                break;

        if (j == m)
            pos[cnt++] = i;
    }

    std::cout << cnt << '\n';

    for (int i = 0; i < cnt; ++i)
        std::cout << pos[i] << ' ';

    std::cout << '\n';

    return 0;
}
