#include <fstream>
#include <cstring>
using namespace std;
ifstream  fin("strmatch.in");
ofstream fout("strmatch.out");
int i,nr,n,m,urm[2000009],a[1009];
char T[2000010],P[2000010];

void urmatorul(char *P)
{
    int k=-1,x;
    urm[0]=0;

    for(x=1; x<m; x++)
    {
        while(k>0 && P[k+1]!=T[x])
        {
            k=urm[k];
        }

        if(P[k+1]==P[x])
        {
            k++;
        }

        urm[x]=k;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    int x=-1;

    fin.getline(P,2000009);
    fin.getline(T,2000009);
    n=strlen(T);
    m=strlen(P);

    urmatorul(P);

    nr=0;
    for(i=0; i<n; i++)
    {
        while(x>0 && P[x+1]!=T[i])
        {
            x=urm[x];
        }

        if(P[x+1]==T[i])
        {
            x++;
        }

        if(x==m-1)
        {
            nr++;
            a[nr]=i-m+1;
            if(nr>=1000)
            {
                break;
            }
            x=urm[x];
        }
    }

    fout<< nr << "\n";

    for(i=1; i<=nr; i++)
    {
        fout<< a[i] << " ";
    }

    return 0;
}
