#include <iostream>
#include <algorithm>
#include <fstream>
#include <cstring>

using namespace std;

char  N[2000001],M[2000001];
long long int n,m,k,pi[2000001],q,ap[2000001],nr=0;

int main()
{
    ifstream fin("strmatch.in");
    ofstream fout("strmatch.out");

    fin.getline(N,2000001);
    fin.getline(M,2000001);

    n=strlen(N);
    m=strlen(M);
    k=0;
    pi[0]=0;
    for(int i=1;i<n;i++)
    {
        while(k>0 && N[k]!=N[i])
        {
            k=pi[k-1];
        }
        if(N[k]==N[i])
        {
            k=k+1;
            pi[i]=k;
        }
    }

    q=0;
      for(int i=0;i<m;i++)
      {

          while(q>0 && N[q]!=M[i])
                q=pi[q-1];
          if(N[q]==M[i])
            q=q+1;
          if(q==n)
          {
            nr++;
            if(nr<=1000)
                ap[nr]=i-n+1;
            q=pi[q-1];
          }

      }
    fout<<nr<<endl;
    int poz=1000;
    if(nr<=1000)
        poz=nr;
    for(int i=1;i<=poz;i++)
        fout<<ap[i]<<" ";
    return 0;
}
