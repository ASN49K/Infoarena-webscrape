#include <bits/stdc++.h>
using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

int main() {
	string p, t;
	fin >> p >> t;
	int n = p.size(), m = t.size();
	p = p + "$" + t;
	if(n > m) {
		fout << "0\n";
	} else {
		vector<int> pi(n + m + 1);
		for(int i = 1; i <= n + m; i++) {
			int k = pi[i - 1];
			while(k && p[i] != p[k]) {
				k = pi[k - 1]; 
			}
			if(p[i] == p[k]) {
				k++;
			}
			pi[i] = k;
		}
		int cnt = 0;
		vector<int> ans;
		for(int i = 2 * n; i <= n + m; i++) {
			if(pi[i] == n) {
				cnt++;
				if(cnt <= 1000) {
					ans.emplace_back(i - 2 * n);
				}
			}
		}
		fout << cnt << '\n';
		for(const auto &it: ans) {
			fout << it << " ";
		}
	}
	return 0;
}