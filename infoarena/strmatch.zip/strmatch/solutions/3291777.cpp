#define sub 0
#define files 1

#if sub
#include "eighty_eighty.h"
#else
#include <bits/stdc++.h>
#endif

#define ll long long
#define ull unsigned long long
#define pb(x) push_back(x)
#define ins(x) insert(x)
#define mp(x,y) make_pair(x,y)
#define fast_ios ios_base::sync_with_stdio(0); cin.tie(NULL); cout.tie(NULL);

using namespace std;
#if files
#include <fstream>
ifstream fin ( "strmatch.in" );
ofstream fout ( "strmatch.out") ;
#else
#include <iostream>
#endif
unordered_map<string,vector<int>>fr;
signed main()
{
    string a ;
    fin >> a;
    string b;
    fin >> b ;
    string c ;
    for ( int i = 0 ; i < a.size() ; ++ i )
        c.pb(b[i]);
    fr[c].pb(0);
    for ( int i = a.size() ; i < b.size() ; ++ i )
    {
        c.erase(0,1);
        c.pb(b[i]);
        fr[c].pb(i-a.size()+1);
    }
    fout << fr[a].size() << '\n' ;
    for ( auto it : fr[a] )
        fout << it << ' ' ;
    return 0;
}
