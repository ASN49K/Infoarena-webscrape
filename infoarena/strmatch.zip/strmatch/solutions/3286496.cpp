#include <bits/stdc++.h>

using namespace std;
ifstream fin ("strmatch.in");
ofstream fout ("strmatch.out");
char str[2000005], pat[2000005];
int lsp[2000005];
vector<int> sol;
void precompute_lsp() {
    int idx = 0, j=1;
    while (pat[j]!='\0') {
        if (pat[idx]==pat[j]) {
            lsp[j]=lsp[j-1]+1;
            idx++; j++;
        }
        else if (idx>0) {
            idx = lsp[idx-1];
        }
        else {
            j++;
        }
    }
}
void kmp() {
    int idx = 0, j=0;
    while (str[j]!='\0') {
        if (pat[idx]=='\0') {
            if (sol.size()<1000) sol.push_back(j-idx);
            idx = lsp[idx-1];
        }
        if (str[j]==pat[idx]) {
            idx++; j++;
        }
        else if (idx>0) {
            idx = lsp[idx-1];
        }
        else {
            j++;
        }
    }
}
int main()
{
    fin>>pat>>str;
    precompute_lsp();
    kmp();
    fout<<sol.size()<<'\n';
    for (int s: sol) fout<<s<<' ';
    return 0;
}
