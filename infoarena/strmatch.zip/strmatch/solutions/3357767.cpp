#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

int main() {
    string a, b;
    int offset = 0;
    fin >> a >> b;
    while (b.find(a, offset) <= b.size()) {
        fout << b.find(a, offset) << " ";
        offset = b.find(a, offset) + 1; 
    }
    return 0;
}
