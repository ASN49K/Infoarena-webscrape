#include <bits/stdc++.h>

using namespace std;
int HASH[2000005], mod=1000000007, baza=512, baza_put[2000005];
vector<int>sol;
int main()
{
    ifstream cin("strmatch.in");
    ofstream cout("strmatch.out");
    baza_put[0]=1;
    for(int i=1; i<=2000000; i++)
        baza_put[i]=1LL*baza_put[i-1]*baza%mod;
    string A,B;
    cin>>A>>B;
    int hashA=0;
    for(int i=B.size()-1; i>=0; i--)
        HASH[i]=(1LL*HASH[i+1]*baza)%mod+B[i]%mod;
    for(int i=A.size()-1; i>=0; i--)
        hashA=(1LL*hashA*baza)%mod+A[i]%mod;
    for(int i=0; i<=B.size()-A.size(); i++)
    {
        int hash_rn=(HASH[i]-(1LL*HASH[i+A.size()]*baza_put[A.size()])%mod+mod)%mod;
        if(hash_rn==hashA)
            sol.push_back(i);
    }
    cout<<sol.size()<<'\n';
    for(int i=0; i<min(1000, (int)sol.size()); i++)
        cout<<sol[i]<<" ";
    return 0;
}
