#include <bits/stdc++.h>
#define N 200010
using namespace std;
ifstream fin("kmp.in");
ofstream fout("kmp.out");
char a[N],b[N];
int pi[N],v[N],i,j,n,m;
void get_pi(char a[])
{
    int n=strlen(a);
    int k=0;
    for(i=0;i<n;i++)
    {
        while(k!=0 && a[k]!=a[i])
            k=pi[k-1];
        if(a[k]==a[i])
            k++;
        pi[i]=k;
    }
}
int main()
{
    fin>>a>>b;
    n=strlen(a);
    m=strlen(b);
    
    get_pi(a);
    int k=0;
    for(i=0;i<m;i++)
    {
        while(k!=0 && b[i]!=a[k])
            k=pi[k-1];
        if(b[i]==a[k])
            k++;
        if(k==n && v[0]<1000) ///0..n-1 => k=n inseamna ca a trecut de tot sirul
            v[++v[0]]=i-k+1;
    }
    fout<<v[0]<<'\n';
    for(i=1;i<=v[0];i++)
        fout<<v[i]<<" ";
    return 0;
}