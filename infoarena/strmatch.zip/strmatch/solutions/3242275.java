//package strmatch;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    static final String INPUT_FILE = "strmatch.in";
    static final String OUTPUT_FILE = "strmatch.out";

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE));
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static void solve(BufferedReader reader,
                             PrintWriter writer) throws IOException {
        String a = reader.readLine();
        String b = reader.readLine();
        StringMatchingStrategy strategy = new BruteForceStrategy();
        List<Integer> match = strategy.match(a, b);
        writer.println(match.size());
        for (int i = 0; i < match.size(); ++i) {
            writer.write(match.get(i) + " ");
        }
    }

    public interface StringMatchingStrategy {
        List<Integer> match(String a, String b);
    }

    public static class BruteForceStrategy implements StringMatchingStrategy {

        @Override
        public List<Integer> match(String a, String b) {
            List<Integer> result = new ArrayList<>();
            int it = b.indexOf(a);
            while (it != -1) {
                result.add(it);
                if (result.size() > 1000) {
                    break;
                }
                it = b.indexOf(a, it + 1);
            }
            return result;
        }
    }
}