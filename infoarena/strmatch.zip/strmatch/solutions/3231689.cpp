#include <fstream>
#include <cstring>
#include <vector>

using namespace std;

ifstream f("strmatch.in");
ofstream g("strmatch.out");

const int mod1 = 666013;
const int mod2 = 10005;
const int nmaxx = 2000005;

long long n, m, sumok1, sumok2, sumi1, sumi2, p1 = 1, p2 = 1;
char a[nmaxx], b[nmaxx];
vector<int> v;

int main()
{
    f >> a >> b;
    n = strlen(a);
    m = strlen(b);

    if(n > m)
    {
        g << 0;
        return 0;
    }

    for(int i = 0; i < n; i ++)
    {
        sumok1 = (sumok1 * 127 + a[i]) % mod1;
        sumok2 = (sumok2 * 127 + a[i]) % mod2;

        if(i != 0)
        {
            p1 = (p1 * 127) % mod1;
            p2 = (p2 * 127) % mod2;
        }

        sumi1 = (sumi1 * 127 + b[i]) % mod1;
        sumi2 = (sumi2 * 127 + b[i]) % mod2;
    }

    if(sumi1 == sumok1 && sumi2 == sumok2)
        v.push_back(0);

    for(int i = n; i < m; i ++)
    {
        sumi1 = ((sumi1 - (b[i - n] * p1) % mod1 + mod1) * 127 + b[i]) % mod1;

        sumi2 = ((sumi2 - (b[i - n] * p2) % mod2 + mod2) * 127 + b[i]) % mod2;

        if(sumi1 == sumok1 && sumi2 == sumok2 && v.size() < 1000)
            v.push_back(i - n + 1);
    }

    g << v.size() << '\n';
    for(int i = 0; i < v.size(); i ++)
        g << v[i] << " ";
    return 0;
}
