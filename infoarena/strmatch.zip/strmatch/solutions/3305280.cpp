#include <cstring>
#include <fstream>
#define MOD 100007
#define MOD2 100021
#define MOD3 666013
using namespace std;

int main()
{
    ifstream fin("strmatch.in");
    ofstream fout("strmatch.out");
    char a[2000001], b[2000001];
    int aa2 = 0,a2 = 0, aa3 = 0, nr = 0;
    int v[200001], nv = 0;

    fin>>a>>b;

    int na = strlen(a);
    for(int i=0;i<na;i++)
    {
        int resta = a[i];
        a2 = (a2 * 127 + resta) % MOD;
        aa2 = (aa2 * 127 + resta) % MOD2;
        aa3 = (aa3 * 127 + resta) % MOD3;
    }




    int nb = strlen(b);
    int b2 = 0, bb2 = 0, bb3 = 0;
    for(int i=0; i<na; i++)
    {
        int r = b[i];
        b2 = (b2 * 127 + r) % MOD;
        bb2 = (bb2 * 127 + r) % MOD2;
        bb3 = (bb3 * 127 + r) % MOD3;
    }
    if(a2 == b2 && aa2 == bb2 && aa3 == bb3)
    {
        nr++;
        v[nv++] = 0;
    }

    int p = 1;
    for(int i=1;i<=na-1;i++)
        p = (p * 127) % MOD;


    int p2 = 1;
    for(int i=1;i<=na-1;i++)
        p2 = (p2 * 127) % MOD2;

    int p3 = 1;
    for(int i=1;i<=na-1;i++)
        p3 = (p3 * 127) % MOD3;

    for(int i=1; i<nb - na; i++)
    {
        int r1 = b[i-1];
        int r2 = b[i + na - 1];
        b2 = ((b2 - (r1 * p) % MOD + MOD) * 127 + r2) % MOD;
        bb2 = ((bb2 - (r1 * p2) % MOD2 + MOD2) * 127 + r2) % MOD2;
        bb3 = ((bb3 - (r1 * p3) % MOD3 + MOD3) * 127 + r2) % MOD3;

        if(a2 == b2 && aa2 == bb2 && aa3 == bb3)
        {
            nr++;
            v[nv++] = i;
        }
    }
    fout<<nr<<"\n";
    for(int i=0; i<min(nv, 1000); i++)
        fout<<v[i]<<" ";
    return 0;
}
