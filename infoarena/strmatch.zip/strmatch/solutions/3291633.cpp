#include <bits/stdc++.h>

using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
int n, m, i, j, lung[4000002];
vector<int> rasp;
string a, b;

int main() {
    fin >> a >> b;
    b = a + "#" + b;

    n = a.size();
    m = b.size();

    j = 0;
    for(i = 1; i < m; i++) {
        while(0 < j && b[j] != b[i]) j = lung[j - 1];
        if(b[j] == b[i]) j++;
        lung[i] = j;

        if(lung[i] == n) rasp.push_back(i - n);
    }

    fout << rasp.size() << "\n";

    rasp.resize(min(rasp.size(), 1000));
    for(int cur : rasp) fout << cur - n << " ";

    return 0;
}
