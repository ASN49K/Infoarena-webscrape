#include <bits/stdc++.h>
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
const int BASE = 31, MOD1 = 1e9 + 7, MOD2 = 1e9 + 9;
int n, m, cnt = 0;
string needle, haystack;
vector<int> pwr1, pwr2;

struct Hash
{
    vector<int> hsh1, hsh2;
    void build(const string &word)
    {
        hsh1.resize(word.size()), hsh2.resize(word.size());
        hsh1[0] = 0, hsh2[0] = 0;
        for(int i = 1; i < word.size(); i++)
        {
            hsh1[i] = (1LL * BASE * hsh1[i-1] + (word[i] - 'A' + 1)) % MOD1;
            hsh2[i] = (1LL * BASE * hsh2[i-1] + (word[i] - 'A' + 1)) % MOD2;
        }
    }
    pair<int, int> get_hash(int st, int dr)
    {
        pair<int, int> H;
        H.first = (hsh1[dr] - (1LL * hsh1[st - 1] * pwr1[dr - st + 1]) % MOD1 + MOD1) % MOD1;
        H.second = (hsh2[dr] - (1LL * hsh2[st - 1] * pwr2[dr - st + 1]) % MOD2 + MOD2) % MOD2;
        return H;
    }
};

int main()
{
    fin >> needle >> haystack;
    n = needle.size(), m = haystack.size();
    needle = ' ' + needle, haystack = ' ' + haystack;
    Hash small_hash, big_hash;
    small_hash.build(needle), big_hash.build(haystack);
    pwr1.resize(max(n, m)), pwr2.resize(max(n, m));
    pwr1[0] = pwr2[0] = 1;
    for(int i = 1; i < max(n, m); i++)
    {
        pwr1[i] = (1LL * BASE * pwr1[i-1]) % MOD1;
        pwr2[i] = (1LL * BASE * pwr2[i-1]) % MOD2;
    }
    vector<int> positions;
    auto target = small_hash.get_hash(1, n);
    for(int i = 1; i + n - 1 <= m; i++)
    {
        if(target == big_hash.get_hash(i, i + n - 1))
        {
            cnt++;
            if(positions.size() < 1000)
                positions.push_back(i - 1);
        }
    }
    fout << cnt << "\n";
    for(int i : positions)
        fout << i << " ";

    fin.close();
    fout.close();
    return 0;
}
