#include <fstream>
#define int long long
using namespace std;

const int B = 127, Mod = 1e9 + 7, Lmax = 2e6 + 5;

int inv[Lmax], ans[Lmax];

int pow(int a, int b)
{
    if(b == 0) return 1;
    if(b == 1) return a;
    int aux = pow(a, b / 2);
    if(b % 2 == 0)
        return aux * aux % Mod;
    return ((aux * aux) % Mod) * a % Mod;
}

int invmod(int a)
{
    return pow(a, Mod - 2);
}

signed main()
{
    ifstream cin("strmatch.in");
    ofstream cout("strmatch.out");
    int n, m, i, hasha = 0, hashb = 0, poz = 0;
    string a, b;
    cin >> a >> b;
    n = a.size(); m = b.size();
    for(i = 0; i < n; i ++)
        hasha = (hasha + ((a[i] - '0' + 1) * pow(B, i) % Mod)) % Mod;
    // for(i = 0; i < n; i ++)
    //     inv[i] = invmod(pow(B, i));
    //cout << hasha << '\n';
    for(int i = 0; i < n; i++) {
        hashb = (hashb + ((b[i] - '0' + 1) * pow(B, i) % Mod)) % Mod;
    }
    if(hashb == hasha) {
        ans[++poz] = 0;
    }
    int invB = invmod(B);
    int pB = pow(B, n - 1);
    //cout << hasha << ' ' << hashb << '\n';
    for(i = n; i < m; i++)
    {
        hashb = (hashb - (b[i - n] - '0' + 1) + Mod) % Mod;
        hashb = (hashb * invB);
        hashb = (hashb + ((b[i] - '0' + 1) * pB % Mod)) % Mod;
        if(hashb == hasha) {
            ans[++poz] = i - n + 1;
        }
        //cout << hasha << ' ' << hashb << '\n';
        //if(i >= n)
            //hashb = (hashb + Mod - ((b[i - n] - 'A' + 1) * pow(B, i - n) % Mod)) % Mod;
        //if((hasha * pow(B, i - 1)) % Mod == hashb)
         //ans[++poz] = i;
         //cout << i << ": " << (hasha * pow(B, i - 1)) % Mod<< " " << hashb << '\n';
    }
    cout << poz << '\n';
    for(i = 1; i <= min(poz, 1LL * 1000); i ++)
        cout << ans[i] << " ";
    return 0;
}
