#include <bits/stdc++.h>
using namespace std;
ifstream fin ("strmatch.in");
ofstream fout ("strmatch.out");

const long long baza = 2e9, MOD = 987654319;
long long power[2000001];
long long h[2000001], hb;

string a, b;

void precompute()
{
    power[0] = 1;
    for (int i = 1; i <= 1000000; i++)
        power[i] = (1LL * power[i - 1] * baza) % MOD;
    h[0] = a[0];
    for (int i = 1; i < a.size(); i++)
        h[i] = (a[i] + 1LL * h[i - 1] * baza) % MOD;
    hb = b[0];
    for (int i = 1; i < b.size(); i++)
        hb = (b[i] + 1LL * hb * baza) % MOD;

}

long long get_hash(int l, int r)
{
    if (l == 0)
        return h[r];
    return (h[r] - 1LL * h[l - 1] * power[r - l + 1] % MOD + MOD) % MOD;
}

int main()
{
    fin >> a >> b;
    if (a.size() < b.size())
        swap(a, b);
    precompute();

    vector <int> poz;
    int cnt = 0;
    for (int i = 0; i <= a.size() - b.size(); i++)
        if (get_hash(i, i + b.size() - 1) == hb)
        {
            cnt++;
            poz.push_back(i);
        }

    fout << cnt << '\n';
    for (int i = 0; i < min(cnt, 1000); i++)
        fout << poz[i] << ' ';
    return 0;
}
