#include <fstream>
#include <cstring>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
char s1[2000001],s2[2000001];
int lg,k,nr,v[1001];
int main()
{
    fin>>s1>>s2;
    lg=strlen(s2);
    while(strstr(s2+k,s1))
    {
        k=lg-strlen(strstr(s2+k,s1))+1;
        nr++;
        if(nr<=1000)
            v[nr]=k-1;
    }
    fout<<nr<<'\n';
    for(k=1;k<=nr && k<=1000;k++)
        fout<<v[k]<<' ';
    return 0;
}
