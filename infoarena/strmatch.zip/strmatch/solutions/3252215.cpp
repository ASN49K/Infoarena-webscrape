//https://infoarena.ro/problema/strmatch
//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

ifstream fin("strmatch.in");
ofstream fout("strmatch.out");

int d[4000005];
int main()
{
	ios_base::sync_with_stdio(false);
	//cin.tie(NULL);
	string a, b, c;
	int i, j, k, ii, jj, kk;
	vector <int> rez;

	fin >> a;
	fin >> b;

	c = a + "#" + b;

	i = 1;
	d[0] = (int)a.size();

	while (c[i] != '#')
	{
		j = i;
		k = 0;
		while (c[j] == c[k])
		{
			++d[i];
			++j;
			++k;
		}
		++i;
	}

	++i;
	while (i < (int)c.size())
	{
		//vad cate sunt egale
		j = i;
		k = 0;
		while ((j < (int)c.size()) && (c[j] == c[k]))
		{
			++d[i];
			++j;
			++k;
		}

		ii = i;
		

		//ma duc pe cele egale si le pun pe nr defintie
		ii = i;
		for (j = ii + 1, k = 1; ((j < (int)c.size()) && (k < d[i])); ++j, ++k)
		{
			d[j] = min(d[k], ((int)c.size() - ii));

			if (d[j])
			{
				//incerc sa le continui
				jj = j;
				kk = k;
				while ((jj < (int)c.size()) && (c[jj] == c[kk]))
				{
					cout << c[jj] << " " << c[kk] << "\n";
					++d[j];
					++jj;
					++kk;
				}
			}
			
			//adaug la rezultat daca e cazul
			if (d[j] == d[0])
			{
				if (rez.size() <= 1000)
				{
					rez.push_back(j - (int)a.size() - 2);
				}
				else
				{
					d[ii] = d[0];
					break;
				}
			}
			++i;
		}

		//adaug la rezultat daca e cazul
		if (d[ii] == d[0])
		{
			if (rez.size() <= 1000)
			{
				rez.push_back(i - (int)a.size() - 2);
			}
			else
			{
				break;
			}

		}
		++i;
	}

	/*for (i = 0; i < c.size(); ++i)
	{
		cout << d[i] << " ";
	}*/

	fout << rez.size() << "\n";
	for (auto x : rez)
	{
		fout << x << " ";
	}

	return 0;
}