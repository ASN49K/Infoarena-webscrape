#include <bits/stdc++.h>
#define mod 666013
#define int long long
using namespace std;
ifstream f("strmatch.in");
ofstream g("strmatch.out");
string a,b;
vector<int> sol;
int lps[2000005],n,m;
void buildprefix()
{
    int k=0;
    n=a.size();
    for(int i=2;i<=n;i++)
    {
        while(k && a[k]!=a[i-1])
            k=lps[k];
        if(a[k]==a[i-1])
            k++;
        lps[i]=k;
    }
}
void potrivire()
{
    int k=0;
    m=b.size();
    for(int i=0;i<=m;i++)
    {
        while(k && a[k]!=b[i])
            k=lps[k];
        if(a[k]==b[i])
            k++;
        if(k==n)
            if(sol.size()<=1000)
            sol.push_back(i-n+1);
    }

}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    f>>a>>b;
    buildprefix();
    potrivire();
    g<<sol.size()<<'\n';
    for(auto x:sol)
        g<<x<<" ";
    return 0;
}
