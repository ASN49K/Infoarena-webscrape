#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string a;
string b;
int v[10005];
int k=0;
int main()
{
    cin>>a;
    cin>>b;
    for(int i=0;i<=b.size()-a.size();i++){
        string s;
        int cnt=a.size();
        int j=i;
        while(cnt!=0)
        {
            s+=b[j];
            cnt--;
            j++;
        }
        if(s==a)
            v[++k]=i;
    }
    cout<<k<<endl;
    for(int i=1;i<=k;i++)
        cout<<v[i]<<" ";
}
