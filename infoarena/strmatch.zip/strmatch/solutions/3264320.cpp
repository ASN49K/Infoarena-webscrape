#include <fstream>
#include <vector>
using namespace std;

ifstream cin("strmatch.in");
ofstream cout("strmatch.out");

#define int long long
#define B 31
#define MOD 1000000007

int put[2000001];
vector<int> rasp;

signed main()
{
    string s,s1;
    cin>>s>>s1;
    int i,hashm,hashc,cnt=0;
    put[0]=1;
    for(i=1;i<=2000000;i++){
        put[i]=(put[i-1]*B)%MOD;
    }
    hashm=hashc=0;
    for(i=0;i<s.size();i++){
        hashm=(hashm*B+s[i]-'A')%MOD;
    }

    for(i=0;i<s.size();i++){
        hashc=(hashc*B+s1[i]-'A')%MOD;
    }
    if(hashc==hashm){
        cnt++;rasp.push_back(0);
    }
    for(i=1;i<=s1.size()-s.size();i++){
        hashc=(hashc-put[s.size()-1]*(s1[i-1]-'A'))%MOD;
        hashc=(hashc*B+(s1[i+s.size()-1]-'A'))%MOD;

        if(hashc==hashm){
            if(cnt<=1000) rasp.push_back(i);
            cnt++;
        }
    }
    cout<<cnt<<"\n";
    for(i=0;i<rasp.size();i++) cout<<rasp[i]<<" ";
    return 0;
}
