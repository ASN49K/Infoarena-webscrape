#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;
ifstream f("strmatch.in");
ofstream g("strmatch.out");
string A,B;
int lps[2000005],n,m,sol[1005],nr;
void buildPrefix()
{
    int i, k=0;
    n=A.size();
    for (i=2; i<=n; i++)
    {
        while (k && A[k] != A[i-1]) k = lps[k];
        if (A[k] == A[i-1]) k++;
        lps[i]=k;
    }
}
void potrivire()
{
    int i, k = 0;;
    m=B.size();
    for (int i = 0; i < m; i++)
    {
        while (k && A[k] != B[i]) k = lps[k];
        if (A[k] == B[i]) k++;
        if (k==n)
            if(nr<1000)
                sol[++nr]=i-n+1;
    }
}
int main()
{
    f>>A;
    f>>B;
    buildPrefix();
    potrivire();
    g<<nr<<'\n';
    for(int i=1;i<=nr;i++)
        g<<sol[i]<<" ";
    return 0;
}
