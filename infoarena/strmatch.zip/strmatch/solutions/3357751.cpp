#include <bits/stdc++.h>

using namespace std;
string A, B;
vector <int> V;
int main()
{
    cin>>A>>B;
    int poz=0;
    while(B.find(A, poz) < B.size())
    {
        int poz_found = B.find(A, poz);
        V.push_back(poz_found);
        poz = poz_found + A.size() - 1;
    }
    int lungV = V.size();
    cout << min(1000, lungV) << endl;
    for(int i = 0; i < min(1000, lungV); i++)
        cout << V[i] << " ";
    return 0;
}
