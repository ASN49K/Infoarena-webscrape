#include <fstream>
#include <string>
#include <vector>
using namespace std;
ifstream in("strmatch.in");
ofstream out("strmatch.out");
const int NMAX = 2e6+10;
int pi[NMAX], k, i;
string a, b;
vector<int> v;
void create_pi()
{
    k = 0;
    for (int i = 1; i < a.size(); i++)
    {
        while(k != 0 && a[k] != a[i])
            k = pi[k-1];
        if (a[i] == a[k])
            k++;
        pi[i] = k;
    }
}
int main()
{
    getline(in, a);
    getline(in, b);
    create_pi();
    k = 0;
    for (i = 0; i < b.size(); i++)
    {
        while(k != 0 && a[k] != b[i])
            k = pi[k-1];
        if (b[i] == a[k])
            k++;
        if (k == a.size())
            v.push_back(i-k+1);
    }
    out << v.size() << '\n';
    for (i = 0; i < min(1000, (int)v.size()); i++)
        out << v[i] << ' ';
    return 0;
}
