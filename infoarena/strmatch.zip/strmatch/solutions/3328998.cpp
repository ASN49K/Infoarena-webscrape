#include <bits/stdc++.h>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
const int lim = 2e6 + 5;
int n, m, lps[lim], v[1005], t;
char a[lim] ,b[lim];
void precalc()
{
    int k = 0;
    for (int i = 2; i <= n ; ++i)
    {
        while (k && a[k] != a[i - 1]) k = lps[k];
        if (a[k] == a[i - 1]) k++;
        lps[i] = k;
    }
}
void solve()
{
    int k = 0;
    for (int i = 0;i < m; ++i)
    {
        while (k && a[k] != b[i]) k = lps[k];
        if (a[k] == b[i]) ++k;
        if (k == n)
        {
            t++;
            if (t <= 1000) v[t] = i - n + 1;
        }
    }
    fout << t << '\n';
    for (int i = 1; i <= t; ++i)
        fout << v[i] << ' ';
}
int main()
{
    fin >> a >> b;
    n = strlen(a);
    m = strlen(b);
    precalc();
    solve();
    return 0;
}
