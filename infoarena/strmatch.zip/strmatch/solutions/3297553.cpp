#include <fstream>
#include <iostream>

#include <regex>
#include <string>
#include <iterator>

int main() {
  std::ifstream fin("strmatch.in");
  std::ofstream fout("strmatch.out");

  std::string pat, text;
  fin >> pat >> text;

  // std::regex pat_regex(pat);
  std::regex pat_regex("(?=(" + pat + ")).");
  auto words_begin = std::sregex_iterator(text.begin(), text.end(), pat_regex);
  auto words_end = std::sregex_iterator();

  std::vector<int> out;
  for (std::sregex_iterator i = words_begin; i != words_end; ++i) {
    const std::smatch &match = *i;
    out.push_back( match.position(0) );
  }

  fout << out.size() << '\n';
  for( int x : out )
    fout << x << ' ';
  fout << '\n';
  
  return 0;
}
