#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string a;
string b;
int v[1001];
int Contor_Afisari = 0;
int main()
{
	fin >> a;
	fin >> b;
	int sizea = a.size();
	int sizeb = b.size();
	for (int i = 0; i < sizeb-sizea+1; i++)
	{
		int ctr = 0;
		int j = i;
		while (b[j] == a[ctr])
		{
			ctr++;
			j++;
		}
		if (ctr == sizea)
		{
			if (Contor_Afisari < 1001)
			{

				Contor_Afisari++;
				v[Contor_Afisari] = i;
			}
			else
				break;
		}

	}
	fout << Contor_Afisari << endl;
	for (int i = 1; i <= Contor_Afisari; i++)
		fout << v[i] << " ";

	return 0;
}