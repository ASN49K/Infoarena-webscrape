#include <iostream>
#include<fstream>
#include<vector>
using namespace std;ifstream fin("strmatch.in");ofstream fout("strmatch.out");
string A,B,S;int cnt,Z[4000001]={1},best,dr,j,i;vector<int>v;
int main()
{fin>>A>>B;S=A+'#'+B;for(i=1;i<S.size();i++){
dr=best+Z[best];j=Z[best]-(dr-i);
if(i<dr)Z[i]=min(Z[j],dr-i);
while(i+Z[i]<S.size()&&S[i+Z[i]]==S[Z[i]])Z[i]++;
if(i+Z[i]>dr)best=i;if(Z[i]==A.size()){
    cnt++;if(cnt<=1000)v.push_back(i-A.size()-1);
}
}fout<<cnt<<'\n';for(i=0;i<v.size();i++)fout<<v[i]<<' ';
    return 0;
}
