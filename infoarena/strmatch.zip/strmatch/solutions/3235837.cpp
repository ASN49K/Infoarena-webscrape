#include <bits/stdc++.h>
using namespace std;
#define int long long int

const int base = 127, mod = 1000000007;

string a, b;

int n, m;
int hsh[2000001], pw[2000001];
int hshinit;

signed main()
{
    freopen("strmatch.in", "r", stdin);
    freopen("strmatch.out", "w", stdout);
    cin.tie(0)->sync_with_stdio(0);
    cin >> a >> b;
    n = b.size();
    m = a.size();

    pw[0] = 1;
    for (int i = 1; i <= 2000000; i++)
        pw[i] = (pw[i - 1] * base) % mod;
    for (int i = 0; i < m; i++)
        hshinit = (hshinit * base + (a[i] - '0')) % mod;
    for (int i = 0; i < n; i++)
        hsh[i + 1] = (hsh[i] * base + (b[i] - '0')) % mod;
    vector<int> poz;
    int ans = 0;
    for (int i = m; i <= n; i++)
    {
        long long hsh_cur = (hsh[i] - ((hsh[i - m] * pw[m]) % mod) + mod) % mod;
        if (hsh_cur == hshinit)
        {
            ans++;
            if (ans <= 1000)
                poz.push_back(i - m);
        }
    }
    cout << ans << '\n';
    for (auto it : poz)
        cout << it << ' ';
    return 0;
}
