#include <bits/stdc++.h>
#define NMAX 2000200
using namespace std;
ifstream fin("strmatch.in");
ofstream fout("strmatch.out");
string s,a;
int j, lps[NMAX],cnt,nr;
int main()
{
    fin>>a>>s;
    s="A"+a+s;

    for(int i=1;i<s.size();++i)
        if(s[i]==s[lps[i-1]+1] && lps[i-1]+1<i)
        {
            lps[i]=lps[i-1]+1;
            if(lps[i]==a.size())
                ++nr;
        }
        else
        {
            j=i-1;
            while(s[lps[j]+1]!=s[i] && lps[j]!=0)
                j=lps[j];

            if(lps[j]==0 && s[1]==s[i] && i>1)
                lps[i]=1;
            if(lps[j]!=0 && s[lps[j]+1]==s[i] && lps[j]+1<i)
                lps[i]=lps[j]+1;
            if(lps[i]==a.size())
                nr++;
        }

    cout<<nr <<'\n';
    nr=min(nr, 1000);
    for(int i=1;i<=s.size() && cnt<=nr;++i)
        if(lps[i]==a.size())
        {
            cout<<i-2*a.size()<<" ";
            ++cnt;
        }
    return 0;
}
