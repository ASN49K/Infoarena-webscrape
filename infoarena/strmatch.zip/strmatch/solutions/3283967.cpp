#include <bits/stdc++.h>

using namespace std;

ifstream f("strmatch.in");
ofstream g("strmatch.out");

char a[2000001],b[2000001],c[2000001];
int ans[1001],nr;

int main()
{
    f>>a;
    f>>b;
    for(int i=0;i<strlen(b)-strlen(a)+1;i++)
    {
        strncpy(c,b+i,strlen(a));
        if(strcmp(a,c)==0 && nr<1000)
        {
            ans[++nr]=i;
        }
    }
    g<<nr<<"\n";
    for(int i=1;i<=nr;i++)
        g<<ans[i]<<" ";
}
