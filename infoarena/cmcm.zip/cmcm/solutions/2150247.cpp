#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <set>
#include <map>
#include <cmath>
#include <cstring>
#include <ctime>
#include <unordered_map>
#include <iomanip>
#include <complex>
#include <cassert>
using namespace std;

#define fi first
#define se second
#define pb push_back
#define all(v) (v).begin(),(v).end()
#define deb(a) cerr<< #a << "= " << (a)<<"\n";

typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int uint;
typedef long double ld;
typedef complex<double> base;
typedef vector<int> vi;
typedef pair<int,int> pii;

template<class T> ostream& operator<<(ostream& stream, const vector<T> v){ stream << "[ "; for (int i=0; i<(int)v.size(); i++) stream << v[i] << " "; stream << "]"; return stream; }
ll fpow(ll x, ll p, ll m){ll r=1; for (;p;p>>=1){ if (p&1) r=r*x%m; x=x*x%m; } return r;}
ll inv(ll a, ll b){ return a<2 ? a : ((a-inv(b%a,a))*b+1)/a%b; }
int gcd(int a, int b){ if (!b) return a; return gcd(b,a%b);}
ll gcd(ll a, ll b){ if (!b) return a; return gcd(b,a%b);}

struct edge{
	int to,c,f,cost;
	edge(int to=0, int c=0, int f=0, int cost=0) : to(to), c(c), f(f), cost(cost) {}
};

int L,R,N,M,S,D,d[700]; vi g[700];
vector<edge> e;

void add_edge(int x, int y, int c, int cost){
	g[x].pb(e.size());
	e.pb({y,c,0,cost});
	g[y].pb(e.size());
	e.pb({x,0,0,-cost});
}

pii bellman_ford(){
	int i;
	for (i=0; i<N; i++)
		d[i]=(1<<30);
		
	vi q,nq,ind(N);
	vector<pii> p(N);
	q.pb(S);
	d[S]=0;
	
	for (i=1; i<=N && !q.empty(); i++){
		nq.clear();
		for (int x : q){
			
			for (int id : g[x]){
				edge ed = e[id];
				
				if (ed.c-ed.f>0 && (d[ed.to]>ed.cost+d[x])){
					d[ed.to]=ed.cost+d[x];
					if (ind[ed.to]!=i) nq.pb(ed.to);
					ind[ed.to]=i;
					p[ed.to]={x,id};
				}
			}
		}
		
		
		q=nq;
	}
	
	
	
	if (d[D]==(1<<30)) return {0,0};
	
	int f=(1<<30),cr;
	
	for (cr=D; cr!=S; cr=p[cr].fi){
		f=min(f,e[p[cr].se].c-e[p[cr].se].f);	
	}
	

	for (cr=D; cr!=S; cr=p[cr].fi){
		e[p[cr].se].f+=f;
		e[p[cr].se^1].f-=f;
	}
	
	return {f,f*d[D]};
}


int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	cin >> L >> R >> M;
	
	int i;
	S=0,D=L+R+1;
	N=L+R+2;
	for (i=1; i<=M; i++){
		int x,y,c;
		cin >> x >> y >> c;
		add_edge(x,L+y,1,c);
	}
	
	for (i=1; i<=L; i++)
		add_edge(S,i,1,0);
		
	for (i=1; i<=R; i++)
		add_edge(L+i,D,1,0);
	
	int f=0,c=0;
	while (1){
		
		pii r=bellman_ford();
		if (r.fi==0) break;
		
		f+=r.fi,c+=r.se;
	}
	
	cout << f << " " << c << "\n";
	for (i=0; i<M; i++){
		int id=2*i;
		if (e[id].f==1) cout << i+1 << " ";
	}
	return 0;
}

