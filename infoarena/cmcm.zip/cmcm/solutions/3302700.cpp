#include <bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>

#define ll long long
#define ull unsigned long long
#define ld long double

using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int NMAX = 605;
const int MMAX = 5e4;
const int INF = 2e9;

struct PQElement {
    int node, cost;
    bool operator < (const PQElement& other) const {
        return other.cost < cost;
    }
};

int n1, n2, m, source, dest;
vector<pair<int, int>> g[NMAX + 1];
pair<int, int> edges[MMAX + 1];
int capacity[NMAX + 1][NMAX + 1];
int flow[NMAX + 1][NMAX + 1];
bool in_q[NMAX + 1];
int bf_cost[NMAX + 1];
int cost[NMAX + 1];
int parent[NMAX + 1];

void add_edge(int a, int b, int c, int cost) {
    g[a].push_back({b, cost});
    g[b].push_back({a, -cost});
    capacity[a][b] += c;
}

bool dijkstra() {
    for(int i = source; i <= dest; i++) {
        parent[i] = 0;
        cost[i] = INF;
    }
    cost[source] = 0;

    priority_queue<PQElement> pq;
    pq.push({source, 0});
    while(!pq.empty()) {
        auto [node, curent_cost] = pq.top();
        pq.pop();

        if(cost[node] != curent_cost) {
            continue;
        }

        for(auto [next_node, edge_cost] : g[node]) {
            int next_cost = curent_cost + edge_cost + bf_cost[node] - bf_cost[next_node];
            if(flow[node][next_node] < capacity[node][next_node] && next_cost < cost[next_node]) {
                cost[next_node] = next_cost;
                parent[next_node] = node;
                pq.push({next_node, next_cost});
            }
        }
    }
    return parent[dest] != 0;
}

void bellman_ford() {
    queue<int> q;
    for(int i = source; i <= dest; i++) {
        in_q[i] = 1;
        q.push(i);
    }

    while(!q.empty()) {
        int node = q.front();
        q.pop();
        for(auto [next_node, edge_cost] : g[node]) {
            int next_cost = bf_cost[node] + edge_cost;
            if(capacity[node][next_node] && next_cost < bf_cost[next_node]) {
                bf_cost[next_node] = next_cost;
                if(!in_q[next_node]) {
                    in_q[next_node] = 1;
                    q.push(next_node);
                }
            }
        }
    }
}

void min_cost_max_flow() {
    int max_flow = 0, min_cost = 0;

    bellman_ford();
    while(dijkstra()) {
        int add_flow = INF;
        for(int node = dest; node != source; node = parent[node]) {
            add_flow = min(add_flow, capacity[parent[node]][node] - flow[parent[node]][node]);
        }

        max_flow += add_flow;
        min_cost += add_flow * (cost[dest] + bf_cost[dest]);
        for(int node = dest; node != source; node = parent[node]) {
            flow[parent[node]][node] += add_flow;
            flow[node][parent[node]] -= add_flow;
        }

        // for(int i = source; i <= dest; i++) {
        //     if(cost[i] < INF) {
        //         bf_cost[i] += cost[i];
        //     }
        // }
    }

    fout << max_flow << ' ' << min_cost << '\n';
    for(int i = 1; i <= m; i++) {
        auto [a, b] = edges[i];
        if(flow[a][b + n1]) {
            fout << i << ' ';
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    fin >> n1 >> n2 >> m;
    for(int i = 1; i <= m; i++) {
        int a, b, cost;
        fin >> a >> b >> cost;
        edges[i] = {a, b};
        add_edge(a, b + n1, 1, cost);
    }

    source = 0, dest = n1 + n2 + 1;
    for(int i = 1; i <= n1; i++) {
        add_edge(source, i, 1, 0);
    }
    for(int i = 1; i <= n2; i++) {
        add_edge(i + n1, dest, 1, 0);
    }
    min_cost_max_flow();

    return 0;
}