#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
int cap[800][800],cost[800][800],indice[800][800],h[800],dist[800],parent[800],mincost;
bool inque[800];
int n,m,e,s,d,operatii;
vector<int> v[800];
void bellmanford()
{
    queue<int> q;
    memset(h,127,sizeof(int)*(n+m+5));
    q.push(s);
    h[s]=0;
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        inque[x]=0;
        for(auto i:v[x])
            if(cap[x][i]&&h[i]>h[x]+cost[x][i])
        {
            h[i]=h[x]+cost[x][i];
            if(!inque[i])
            {
                q.push(i);
                inque[i]=1;
            }
        }
    }
}
bool dijkstra()
{
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
    int realdist[800];
    memset(dist,127,sizeof(int)*(n+m+5));
    pq.push({0,s});
    dist[s]=realdist[s]=0;
    while(!pq.empty())
    {
        int x=pq.top().second, y=pq.top().first;
        pq.pop();
        if(dist[x]!=y) continue;
        for(auto i:v[x])
            if(cap[x][i]&&y+cost[x][i]+h[x]-h[i]<dist[i])
        {
            pq.push({y+cost[x][i]+h[x]-h[i],i});
            dist[i]=y+cost[x][i]+h[x]-h[i], realdist[i]=realdist[x]+cost[x][i];
            parent[i]=x;
        }
    }
    memcpy(h,realdist,sizeof h);
    if(dist[d]!=dist[0]) return true;
    return false;
}
int main()
{
    f>>n>>m>>e;
    int ind=0;
    for(int i=1;i<=e;i++)
    {
        int a,b,d;
        f>>a>>b>>d;
        b+=n;
        cap[a][b]=1, cost[a][b]=d, cost[b][a]=-d, indice[b][a]=++ind;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    s=n+m+1, d=n+m+2;
    for(int i=1;i<=n;i++)
    {
        v[s].push_back(i);
        //v[i].push_back(s);
        cap[s][i]=1;
    }
    for(int i=n+1;i<=n+m;i++)
    {
        v[i].push_back(d);
        //v[d].push_back(i);
        cap[i][d]=1;
    }
    bellmanford();
    int cnt=0;
    while(dijkstra())
    {
        int node=d, tsoc=0;
        node=d;
        while(parent[node])
        {
            cap[parent[node]][node]-=1, cap[node][parent[node]]+=1;
            tsoc+=cost[parent[node]][node];
            node=parent[node];
        }
        mincost+=tsoc, cnt++;
    }
    g<<cnt<<" "<<mincost<<'\n';
    for(int i=n+1;i<=n+m;i++)
        for(int j=1;j<=n;j++)
            if(cap[i][j])
                g<<indice[i][j]<<' ';
    return 0;
}