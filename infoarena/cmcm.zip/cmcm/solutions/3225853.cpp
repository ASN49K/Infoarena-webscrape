#include <bits/stdc++.h>
#define MAX 605

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int n,m,e,s,d;
map<pair<int,int>,int>mep;
vector<int>vec[MAX];
int cap[MAX][MAX],flux[MAX][MAX],cost[MAX][MAX];
int dist[MAX];
int tata[MAX];
int cuplaj,costmin;

bool bellmanford()
{
    int i;
    for(i=0;i<=d;++i)
        dist[i]=1e9;
    dist[0]=0;
    queue<int>q;
    bitset<MAX>inq;
    q.push(0);
    inq[0]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        inq[nod]=0;
        for(i=0;i<vec[nod].size();++i)
        {
            int vc=vec[nod][i];
            if(cap[nod][vc]>flux[nod][vc] && dist[nod]+cost[nod][vc]<dist[vc])
            {
                dist[vc]=dist[nod]+cost[nod][vc];
                tata[vc]=nod;
                if(!inq[vc])
                {
                    q.push(vc);
                    inq[vc]=1;
                }
            }
        }
    }
    if(dist[d]==1e9)
        return 0;
    int nod=d;
    while(nod!=s)
    {
        ++flux[tata[nod]][nod];
        --flux[nod][tata[nod]];
        nod=tata[nod];
    }
    ++cuplaj;
    costmin+=dist[d];
    return 1;
}

int main()
{
    fin>>n>>m>>e;
    int i;
    s=0;
    d=n+m+1;
    for(i=1;i<=e;++i)
    {
        int x,y,c;
        fin>>x>>y>>c;
        y+=n;
        mep[{x,y}]=i;
        vec[x].push_back(y);
        vec[y].push_back(x);
        cap[x][y]=1;
        cost[x][y]=c;
        cost[y][x]=-c;
    }
    for(i=1;i<=n;++i)
    {
        vec[s].push_back(i);
        cap[s][i]=1;
    }
    for(i=1;i<=m;++i)
    {
        vec[i+n].push_back(d);
        cap[i+n][d]=1;
    }
    while(bellmanford());
    fout<<cuplaj<<' '<<costmin<<'\n';
    int j;
    for(i=1;i<=n;++i)
        for(j=n+1;j<=n+m;++j)
            if(flux[i][j])
                fout<<mep[{i,j}]<<' ';
    return 0;
}
