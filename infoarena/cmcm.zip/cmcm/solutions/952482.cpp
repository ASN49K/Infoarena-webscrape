#include<fstream>
#include<vector>
#include<queue>

#define NMAX 710
#define INF (1<<30)

using namespace std;

int n,m,source,destination,sol;
int COST[NMAX][NMAX],CAPACITY[NMAX][NMAX],muchie[NMAX][NMAX],FLUX[NMAX][NMAX],DIST[NMAX];
short TT[NMAX];
vector<short> G[NMAX];
queue<short> Q;
bool use[NMAX];

void read()
{
	ifstream fin("cmcm.in");
	int x,y,edges,c;
	fin>>n>>m>>edges;
	for(int i=1;i<=edges;i++)
	{
		fin>>x>>y>>c;
		y+=n;
		G[x].push_back(y);
		G[y].push_back(x);
		COST[x][y]=c;
		COST[y][x]=-c;
		CAPACITY[x][y]=1;
		muchie[x][y]=i;
	}
	fin.close();
}
void print()
{
	ofstream fout("cmcm.out");
	int i,j,c=0;
	for(i=1;i<=n;i++)
		for(j=n+1;j<destination;j++)
			if(CAPACITY[i][j] && FLUX[i][j])
			{
				c++;
				break;
			}
	fout<<c<<' '<<sol<<'\n';
	for(i=1;i<=n;i++)
		for(j=n+1;j<destination;j++)
			if(CAPACITY[i][j] && FLUX[i][j])
			{
				fout<<muchie[i][j]<<' ';
				break;
			}
	fout.close();
}
void prepare()
{
	destination=n+m+1;
	for(int i=1;i<=n;i++)
	{
		G[i].push_back(source);
		G[source].push_back(i);
		CAPACITY[source][i]=1;
	}
	for(int i=n+1;i<=n+m;i++)
	{
		G[i].push_back(destination);
		G[destination].push_back(i);
		CAPACITY[i][destination]=1;
	}
}
void INIT()
{
	for(int i=0;i<=destination;i++)
	{
		DIST[i]=INF;
		TT[i]=-1;
	}
}
bool bellman_ford()
{
	short nod,vec;
	INIT();
	Q.push(source);
	use[source]=1;
	DIST[source]=0;
	while(!Q.empty())
	{
		nod=Q.front();
		Q.pop();
		for(size_t i=0;i<G[nod].size();i++)
		{
			vec=G[nod][i];
			if(CAPACITY[nod][vec]>FLUX[nod][vec] && DIST[nod]+COST[nod][vec]<DIST[vec])
			{
				DIST[vec]=DIST[nod]+COST[nod][vec];
				TT[vec]=nod;
				if(!use[vec])
				{
					use[vec]=1;
					Q.push(vec);
				}
			}
		}
		use[nod]=0;
	}
	if(DIST[destination]!=INF)
		return 1;
	return 0;
}
int main()
{
	read();
	prepare();
	while(bellman_ford())
	{
		for(int i=destination;i!=source;i=TT[i])
		{
			FLUX[TT[i]][i]++;
			FLUX[i][TT[i]]--;
		}
		sol+=DIST[destination];
	}
	print();
	return 0;
}
