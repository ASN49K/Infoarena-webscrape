#include<fstream>
#include<queue>
#include<vector>
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int n,m,nr,s,k,x,y,z;
int drum[650],F[650],T[650];
int muchia[650][650],cap[650][650],cost[650][650],flux[650][650];
vector <int> L[650];
deque <int> q;

int bellman(){
    /// pe fiecare muchie trebuie sa avem capacitate > flux

    for(int i=0;i<=n+m+1;i++){
        F[i]=0;
        drum[i]=1000000000;
    }
    q.clear();
    q.push_back(s);
    F[s]=1;drum[s]=0;

    int N,ok=0;
    while(!q.empty()){
        N=q.front();
        if(N==n+m+1){
            ok=1;
        }
        q.pop_front();
        F[N]=0;
        for(int i=0;i<L[N].size();i++){
            int vecin=L[N][i];
            if( (drum[vecin]>drum[N]+cost[N][vecin]) && (flux[N][vecin]<cap[N][vecin]) ){

                drum[vecin]=drum[N]+cost[N][vecin];
                T[vecin]=N;
                if(F[vecin]==0){
                    F[vecin]=1;
                    q.push_back(vecin);
                    if(vecin==n+m+1){
                        ok=1;
                    }
                }
            }
        }
    }
    return ok;
}


int main(){
    fin>>n>>m>>k;
    s=0;
    for(int i=1;i<=k;i++){
        fin>>x>>y>>z;
        y+=n;
        L[x].push_back(y);
        L[y].push_back(x);
        cost[x][y]=z;
        cost[y][x]=-z;
        cap[x][y]=1;
        muchia[x][y]=muchia[y][x]=i;
    }
    for(int i=1;i<=n;i++){
        L[0].push_back(i);
        L[i].push_back(0);
        cap[0][i]=1;
    }
    for(int i=n+1;i<=n+m;i++){
        L[n+m+1].push_back(i);
        L[i].push_back(n+m+1);
        cap[i][n+m+1]=1;
    }
    while(bellman()){
        int nod=n+m+1;
        while(nod!=0){
            flux[T[nod]][nod]++;
            flux[nod][T[nod]]--;
            nod=T[nod];
        }
        nr+=drum[n+m+1];
    }
    s=0;
    for(int i=1;i<=n;i++){
        for(int j=n+1;j<=n+m;j++){
            if(flux[i][j]==1){
                s++;
            }
        }
    }
    fout<<s<<" "<<nr<<"\n";
    for(int i=1;i<=n;i++){
        for(int j=n+1;j<=n+m;j++){
                if(flux[i][j])
                    fout<<muchia[i][j]<<" ";
        }
    }
    return 0;
}
