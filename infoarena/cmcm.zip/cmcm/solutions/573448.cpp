#include<cstdio>
#include<vector>
#include<queue>

#define minim(a, b) ((a)<=(b)?(a):(b))
#define InFile "cmcm.in"
#define OutFile "cmcm.out"
#define pb push_back
#define mkp make_pair

using namespace std;

const int MaxN = 605;
const int INF = 0x3f3f3f3f;

int L,R,E,S,D,Flux,C[MaxN][MaxN],e[MaxN][MaxN],T[MaxN],inQ[MaxN],d[MaxN];
vector< pair<int,int> > G[MaxN];
queue<int> Q;
vector<int> Sol;

void Read()
{
	freopen( InFile , "r" , stdin );
	scanf("%d%d%d" , &L , &R , &E );
	int i,x,y,z;
	for( i = 0 ; i < E ; i++ )
		{
			scanf("%d%d%d" , &x , &y ,&z);
			y += L;
			G[x].pb(mkp(y,z));
			G[y].pb(mkp(x,-z));
			C[x][y] = 1;
			e[x][y] = i+1;
		}
	S = L+R+1;
	D = S + 1;
	for( i = 1 ; i <= L ; i++ )
		{
			G[S].pb(mkp(i,0));
			G[i].pb(mkp(S,0));
			C[S][i] = 1;
		}
	for( i = L+1 ; i <= L+R ; i++ )
		{
			G[i].pb(mkp(D,0));
			G[D].pb(mkp(i,0));
			C[i][D] = 1;
		}
	fclose(stdin);
}

int BellMan_Ford(int S,int D)
{
	int nod;
	vector< pair<int,int> >::iterator it;
	memset(inQ,0,sizeof(inQ));
	memset(T,0,sizeof(T));
	memset(d,INF,sizeof(d));
	d[S] = 0;
	inQ[S] = 1;
	Q.push(S);
	while( !Q.empty() )
		{
			nod = Q.front();
			Q.pop();
			inQ[nod] = 0;
			for( it = G[nod].begin() ; it != G[nod].end() ; ++it )
				if( C[nod][it->first] > 0 && it->second +d[nod] < d[it->first] )
					{
						d[it->first] = d[nod] + it->second;
						T[it->first] = nod;
						if( !inQ[it->first] )
							{
								inQ[it->first] = 1;
								Q.push(it->first);
							}
					}
		}
	return d[D]<INF;
}

void flux()
{
	Flux = 0;
	int i,j,nod,fluxmin;
	while( BellMan_Ford(S,D) )
		{
			fluxmin = INF;
			for( nod = D ; nod != S ; nod = T[nod] )
				fluxmin = minim(fluxmin,C[T[nod]][nod] );
			if( !fluxmin )
				continue;
			for( nod = D ; nod != S ; nod = T[nod] )
				{
					C[T[nod]][nod] -= fluxmin;
					C[nod][T[nod]] += fluxmin;
				}
			Flux += (fluxmin*d[D]);
		}
	for( i = 1 ; i <= L ; i++ )
		for( j = L+1 ; j < D ; j++ )
			if( C[i][j] == 0 && e[i][j] )
				Sol.pb(e[i][j]);
}

void write()
{
	freopen( OutFile , "w" , stdout );
	printf("%d %d\n" , Sol.size() , Flux );
	for( unsigned int i = 0 ; i < Sol.size() ; i++ )
		printf("%d " , Sol[i]);
	printf("\n");
	fclose(stdout);
}

int main()
{
	Read();
	flux();
	write();
	return 0;
}
