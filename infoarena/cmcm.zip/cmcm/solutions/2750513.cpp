#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
#define int ll



ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
#define cin fin
#define cout fout



int n1, n2, m, s, t, n;
int e[200010][3];



queue<int> q[2];
int D[1001];
int f[1001];
int p[1001];



int g[610][610], r[610][610], c[610][610];
vector<int> g2[610];
int res=0;
bool v[610];
int flux=0;


bool bellman_ford(){



for(int i=1; i<=n; i++){
    D[i]=1e9;
    f[i]=0;
    p[i]=0;
    v[i]=false;
}

D[s]=0; f[s]=1e9;
q[1].push(s);

for(int num=1; num<=n; num++){

    for(int u=q[1].front(); !q[1].empty(); u=q[1].front()){
    q[0].push(u);
    q[1].pop();
    }

    while(!q[0].empty()){
        int nod=q[0].front();
        q[0].pop();
        for(int u:g2[nod]){
            if(min(f[nod], c[nod][u]-r[nod][u])>0 ){
                if( (D[nod]+g[nod][u])<D[u] ){
                    q[1].push(u);
                    f[u]=min(f[nod], c[nod][u]-r[nod][u]);
                    D[u]=D[nod]+g[nod][u];
                    p[u]=nod;
                }
            }
        }
    }


}


if(f[t]>0){
    res+=f[t]*D[t];
}
else{
    return false;
}

while(!q[1].empty()){
    q[1].pop();
}

int ac=t;

while(ac!=s){
    r[p[ac] ][ac]+=f[t];
    r[ac ][p[ac] ]-=f[t];
    ac=p[ac];
}

while(!q[1].empty()){
    q[1].pop();
}
flux+=f[t];
return true;
}






int32_t main(){
INIT

cin>>n1>>n2>>m;
int m0=m;
for(int i=1; i<=m; i++){
    cin>>e[i][0]>>e[i][1]>>e[i][2];
    e[i][1]+=n1;
}
 n=n1+n2;
 s=n+1, t=n+2; n+=2;

for(int i=1; i<=n1; i++){
    m++;
    e[m][0]=s, e[m][1]=i, e[m][2]=0;
}
for(int i=1; i<=n2; i++){
    m++;
    e[m][0]=i+n1, e[m][1]=t, e[m][2]=0;
}


for(int i=1; i<=m; i++){
    g[e[i][0] ][e[i][1] ]=e[i][2];
    g[e[i][1] ][e[i][0] ]=-g[e[i][0] ][e[i][1] ];
    g2[e[i][0] ].pb(e[i][1]);
    g2[e[i][1] ].pb(e[i][0]);
    c[e[i][0] ][e[i][1] ]=1;
}

while(bellman_ford()){

}
cout<<flux<<" "<<res<<"\n";

for(int i=1; i<=m0; i++){
    if( r[e[i][0] ][e[i][1] ]==1 ){
        cout<<i<<" ";
    }
}



return 0;
}
