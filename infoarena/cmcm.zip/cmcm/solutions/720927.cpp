#include <cstdio>
#define N 605
#define E 50005
#define inf 1999999999
using namespace std;
struct nod{ int val; nod *urm; }*G[N];
int cap[N][N],cost[N][N],flux[N][N],muc[N][N];
int n,m,SS,SD,c[E];
int ctotal,k,sol[E],dist[N],tata[N];
bool viz[N];
void read()
{ int e,x,y,z,i;
  nod *aux;
freopen("cmcm.in","r",stdin); scanf("%d %d %d\n",&n,&m,&e);
for(i=1;i<=e;++i)
    {
    scanf("%d %d %d\n",&x,&y,&z);
    muc[x][y+n]=i;
    aux=new nod; aux->val=y+n; aux->urm=G[x]; G[x]=aux;
    aux=new nod; aux->val=x; aux->urm=G[y+n]; G[y+n]=aux;
    cap[x][y+n]=1; cost[x][y+n]=z; cost[y+n][x]=-z;
    }
fclose(stdin);
}
inline int min(int x,int y)
{
if(x<y)return x;
    else return y;
}
int bellman_ford()
{ int i,x,y,fm,p,u;
  nod *aux;
for(i=1;i<=n+m;++i)
    {
    dist[i]=inf;
    viz[i]=0;
    tata[i]=0;
    }
dist[SD]=inf; tata[SD]=0;
dist[SS]=0;
p=u=1; c[1]=SS; viz[SS]=1;
while(p<=u)
    {
    x=c[p];
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        {
        y=aux->val;
        if(cap[x][y]>flux[x][y]&&dist[x]+cost[x][y]<dist[y])
            {
            dist[y]=dist[x]+cost[x][y];
            tata[y]=x;
            if(!viz[y])
                {
                c[++u]=y;
                viz[y]=1;
                }
            }
        }
    ++p; viz[x]=0;
    }
if(dist[SD]<inf)
    {
    fm=inf;
    for(i=SD;i!=SS;i=tata[i])
        fm=min(fm,cap[tata[i]][i]-flux[tata[i]][i]);
    for(i=SD;i!=SS;i=tata[i])
        {
        flux[tata[i]][i]+=fm;
        flux[i][tata[i]]-=fm;
        }
    return fm*dist[SD];
    }
return 0;
}
void solve()
{ int x;
x=1;
while(x)
    x=bellman_ford();
}
void reconstr_sol()
{ int i,j;
ctotal=0; k=0;
for(i=1;i<=n;++i)
    for(j=1;j<=m;++j)
        if(flux[i][j+n]==1)
            {
            ctotal+=cost[i][j+n];
            sol[++k]=muc[i][j+n];
            }
}
void write()
{ int i;
freopen("cmcm.out","w",stdout); printf("%d %d\n",k,ctotal);
for(i=1;i<=k;++i)printf("%d ",sol[i]);
fclose(stdout);
}
int main()
{ int i;
  nod *aux;
read();
SS=601; // super sursa;
SD=602; // super destinatie
for(i=1;i<=n;++i)
    {
    aux=new nod; aux->val=i; aux->urm=G[SS]; G[SS]=aux;
    aux=new nod; aux->val=SS; aux->urm=G[i]; G[i]=aux;
    cap[SS][i]=1;
    }
for(i=1;i<=m;++i)
    {
    aux=new nod; aux->val=SD; aux->urm=G[i+n]; G[i+n]=aux;
    aux=new nod; aux->val=i+n; aux->urm=G[SD]; G[SD]=aux;
    cap[i+n][SD]=1;
    }
solve();
reconstr_sol();
write();
return 0;
}
