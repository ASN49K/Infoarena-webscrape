#include <stdio.h>
#include <vector>
#define IN "cmcm.in"
#define OUT "cmcm.out"
#define Lg 602
#define lg 301
#define inf 0x3f3f3f
#define pb push_back

using namespace std;

const int Dest = Lg-1, Sursa = 0;

int Numar;
int flux[Lg][Lg];
int cap[Lg][Lg];
int cost[Lg][Lg];
vector <int> V[Lg];
int Flux,N1,N2;
int dist[Lg],fl;
int viz[Lg];
int St,Dr,nr,nod;
int Q[Lg*Lg];
int inc,sf;
int T[Lg];
int poz[Lg][Lg];

void citire()
{
    int S,D,C,i;
    scanf ("%d %d %d",&St,&Dr,&nr);
    for (i=0;i<nr;i++)
    {
        scanf ("%d %d %d",&S,&D,&C);
        D+=lg;
        poz[S][D]=i+1;
        V[S].pb(D);
        V[D].pb(S);
        cap[S][D]=1;
        cost[S][D]=C;
        cost[D][S]=-C;
        cap[Sursa][S]=1;
        cap[D][Dest]=1;
    }

    for (i=1;i<=St;i++)
    {
        V[Sursa].pb(i);
        V[i].pb(Sursa);
    }

    for (i=1+lg;i<=Dr+lg;i++)
    {
        V[Dest].pb(i);
        V[i].pb(Dest);
    }
}

int bell()
{
    for (int i=0 ; i<=Dest ; dist[i]=inf, viz[i]=0, i++);

    inc=0;
    sf=1;
    Q[0]=Sursa;
    dist[Sursa]=0;
    viz[Sursa]=1;
    while (inc<sf)
    {
        N1=Q[inc++];
        viz[N1]&=0;
        for (int i=0;i<V[N1].size();i++)
        {
            N2=V[N1][i];
            if (cap[N1][N2]> flux[N1][N2])
            {
                if (dist[N1]+cost[N1][N2]<dist[N2])
                {
                    dist[N2]=dist[N1]+cost[N1][N2];
                    T[N2]=N1;
                    if (!viz[N2])
                    {
                        viz[N2]^=1;
                        Q[sf++]=N2;
                    }
                }
            }
        }
    }
    return (dist[Dest]!=inf);
}


void solve()
{
    while (bell())
    {
        nod=Dest;
        fl=inf;
        while(nod!=Sursa)
        {
            if (fl > cap[T[nod]][nod] - flux[T[nod]][nod])
                fl = cap[T[nod]][nod] - flux[T[nod]][nod];
            nod=T[nod];
        }
        nod=Dest;
        while (nod!=Sursa)
        {
            flux[T[nod]][nod]+=fl;
            flux[nod][T[nod]]-=fl;
            nod=T[nod];
        }
        Flux+=dist[Dest];
        Numar++;
    }
}

void afish()
{
    printf("%d %d\n",Numar,Flux);
    for (int i=1;i<=St;i++)
        for (int j=lg+1;j<=Dr+lg;j++)
            if (cap[i][j] & flux[i][j])
                printf("%d ",poz[i][j]);
}

int main()
{
    freopen (IN ,"r",stdin);
    freopen (OUT ,"w",stdout);
    citire();
    solve();
    afish();
    return 0;
}
