#include <bits/stdc++.h>

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int inf = 0x3f3f3f3f;

vector < vector <int> > G(605);

int d[605];
int t[605];

int pot[605];
int pot2[605];

bitset <605> in_queue;
bitset <605> viz;
queue <int> q;

int n;

int c[605][605];
int w[605][605];
int poz[301][301];

set < pair <int, int> > s;

void bellman_ford(){
    memset(pot, 0x3f, sizeof pot);
    memset(t, 0, sizeof t);
    q.push(0);
    pot[0] = 0;
    in_queue[0] = 1;
    while(!q.empty()){
        int nod = q.front();
        q.pop();
        in_queue[nod] = 0;
        for(auto x : G[nod]){
            if(c[nod][x] > 0 && pot[x] > pot[nod] + w[nod][x]){
                pot[x] = pot[nod] + w[nod][x];
                t[x] = nod;
                if(!in_queue[x]){
                    q.push(x);
                    in_queue[x] = 1;
                }
            }
        }
    }
}

int dijkstra(){
    memset(d, 0x3f, sizeof d);
    memset(t, 0, sizeof t);
    pot2[0] = d[0] = 0;
    s.insert({0, 0});
    viz.reset();
    while(!s.empty()){
        auto it = s.begin();
        int nod = it->second;
        s.erase(it);
        if(viz[nod]) continue;
        viz[nod] = 1;
        for(auto x : G[nod]){
            if(c[nod][x] > 0 && d[x] > d[nod] + w[nod][x] + pot[nod] - pot[x]){
                d[x] = d[nod] + w[nod][x] + pot[nod] - pot[x];
                pot2[x] = pot2[nod] + w[nod][x];
                t[x] = nod;
                s.insert({d[x], x});
            }
        }
    }
    for(int i = 0; i <= n; i++) pot[i] = pot2[i];
    return d[n];
}

pair <int, int> edmonds_karp(){
    int max_flow = 0, rez = 0;
    while(dijkstra() != inf){
        int new_flow = 1e9;
        for(int temp = n; temp; temp = t[temp]) new_flow = min(new_flow, c[t[temp]][temp]);
        for(int temp = n; temp; temp = t[temp]){
            c[t[temp]][temp] -= new_flow;
            c[temp][t[temp]] += new_flow;
            rez += new_flow * w[t[temp]][temp];
        }
        max_flow += new_flow;
    }
    return {max_flow, rez};
}

int main()
{
    int n2,i,m,k,x,y;
    fin >> n2 >> m >> k;
    for(i = 1; i <= k; i++){
        fin >> x >> y;
        fin >> w[x][n2 + y];
        poz[x][y] = i;
        c[x][n2 + y] = 1;
        c[n2 + y][x] = 0;
        w[n2 + y][x] = -w[x][n2 + y];
        G[x].push_back(n2 + y);
        G[n2 + y].push_back(x);
    }
    for(i = 1; i <= n2; i++){
        G[0].push_back(i);
        G[i].push_back(0);
        c[0][i] = 1;
    }
    n = n2 + m + 1;
    for(i = n2; i < n; i++){
        G[i].push_back(n);
        G[n].push_back(i);
        c[i][n] = 1;
    }
    bellman_ford();
    pair <int, int> rez = edmonds_karp();
    fout << rez.first << " " << rez.second << "\n";
    for(i = 1; i <= n2; i++){
        for(int j = 1; j <= m; j++){
            if(poz[i][j] && !c[i][j + n2]) fout << poz[i][j] << " ";
        }
    }
    return 0;
}
