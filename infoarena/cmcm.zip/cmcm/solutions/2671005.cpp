#include <bits/stdc++.h>

using namespace std;

const int inf = (int)1e9 + 7;
const int max_n = (int)1e4 + 5;

int n, m, e;

int sink, dest;

vector<int> g[max_n];

bool visited[max_n];

int d[max_n], dad[max_n];

int order[max_n][max_n];

int flow[max_n][max_n], capacity[max_n][max_n], cost[max_n][max_n];

bool bellman_ford() {
  queue<int> q;
  q.push(sink);
  visited[sink] = true;
  for (int i = 0; i <= n + m + 1; ++i) {
    d[i] = inf;
    visited[i] = false;
    dad[i] = -1;
  }
  d[sink] = 0;
  while ((int)q.size() > 0) {
    int u = q.front();
    q.pop();
    visited[u] = false;
    for (int v : g[u]) {
      if (d[v] > d[u] + cost[u][v] && flow[u][v] < capacity[u][v]) {
        d[v] = d[u] + cost[u][v];
        dad[v] = u;
        if (!visited[v]) {
          visited[v] = true;
          q.push(v);
        }
      }
    }
  }
  return (d[n + m + 1] < inf);
}

int main() {
  int u, v, c, matching = 0, flow_cost = 0;;
  ifstream in("cmcm.in");
  ofstream out("cmcm.out");
  in >> n >> m >> e;
  for (int i = 0; i < e; ++i) {
    in >> u >> v >> c;
    v += n;
    cost[u][v] = c;
    cost[v][u] = -c;
    capacity[u][v] = 1;
    g[u].push_back(v);
    g[v].push_back(u);
    order[u][v] = i + 1;
  }
  sink = 0;
  dest = n + m + 1;
  for (int i = 1; i <= n; ++i) {
    capacity[sink][i] = 1;
    g[sink].push_back(i);
    g[i].push_back(sink);
  }
  for (int i = 1; i <= m; ++i) {
    capacity[i + n][dest] = 1;
    g[dest].push_back(i + n);
    g[i + n].push_back(dest);
  }
  while (bellman_ford() == true) {
    int min_flow = inf;
    for (int i = dest; i != sink; i = dad[i]) {
      min_flow = min(min_flow, capacity[dad[i]][i] - flow[dad[i]][i]);
    }
    for (int i = dest; i != sink; i = dad[i]) {
      flow[dad[i]][i] += min_flow;
      flow[i][dad[i]] -= min_flow;
    }
    flow_cost += min_flow * d[n + m + 1];
  }
  vector<int> ans;
  for (int i = 1; i <= n; ++i) {
    for (int j = n + 1; j <= n + m; ++j) {
      if (capacity[i][j] == 1 && flow[i][j] == 1) {
        matching += 1;
        ans.push_back(order[i][j]);
      }
    }
  }
  out << matching << " " << flow_cost << "\n";
  for (int val : ans) {
    out << val << " ";
  }
  return 0;
}
