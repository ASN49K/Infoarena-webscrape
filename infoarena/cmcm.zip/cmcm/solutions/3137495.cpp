#include <bits/stdc++.h>
#define INF 1000000000

using namespace std;

const int nmax = 6e2 + 3;
const int mmax = 5e4 + 3;
class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

ofstream g ("cmcm.out");

vector <int> v[nmax];
queue <int> q;

int n, n2, m, s, t, c[nmax][nmax], cost[nmax][nmax], usd[nmax][nmax];
int t1[mmax], t2[mmax], use[nmax], ant[nmax], dist[nmax];

int BellmanFord()
{
    int nod, nod2, usu;

    for (int i = 1; i <= t; ++i)
    {
        use[i] = 0;
        ant[i] = 0;
        dist[i] = INF;
    }

    q.push(s);
    dist[s] = 0;

    while (!q.empty())
    {
        nod = q.front();
        q.pop();
        use[nod] = 0;
        if (nod == t) continue;

        for (int i = 0; i < v[nod].size(); ++i)
        {
            nod2 = v[nod][i];
            usu = dist[nod] + cost[nod][nod2];
            if (usd[nod][nod2] >= c[nod][nod2] || usu >= dist[nod2]) continue;
            dist[nod2] = usu;

            if (!use[nod2])
            {
                q.push(nod2);
                use[nod2] = 1;
            }
            ant[nod2] = nod;
        }
    }

    return (dist[t] != INF);
}


void Flux()
{
    int x, res, sol = 0, cmax = 0;

    while (BellmanFord())
    {
        x = t;
        res = INF;
        while (ant[x])
        {
            res = min (res, c[ant[x]][x] - usd[ant[x]][x]);
            x = ant[x];
        }

        x = t;
        sol += dist[t] * res;
        while (ant[x])
        {
            usd[ant[x]][x] += res;
            usd[x][ant[x]] -= res;
            x = ant[x];
        }

        ++cmax;
    }

    g << cmax << ' ' << sol << '\n';

    for (int i = 1; i <= m; ++i)
        if (usd[t1[i]][t2[i] + n] > 0)
            g << i << ' ';
}

int main()
{
    InParser f ("cmcm.in");
    int cst, nod, nod2;
    f >> n >> n2 >> m;

    s = n + n2 + 1;
    t = s + 1;

    for (int i = 1; i <= n; ++i)
    {
        v[s].push_back(i);
        c[s][i] = 1;
        cost[s][i] = 0;
    }

    for (int i = 1; i <= n2; ++i)
    {
        v[n + i].push_back(t);
        c[n + i][t] = 1;
        cost[n + i][t] = 0;
    }

    for (int i = 1; i <= m; ++i)
    {
        f >> t1[i] >> t2[i] >> cst;
        nod = t1[i];
        nod2 = t2[i] + n;

        v[nod].push_back(nod2);
        v[nod2].push_back(nod);

        c[nod][nod2] = 1;
        cost[nod][nod2] = cst;
        cost[nod2][nod] = -cst;
    }

    Flux();
    return 0;
}
