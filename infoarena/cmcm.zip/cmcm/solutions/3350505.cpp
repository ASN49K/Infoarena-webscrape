#include <bits/stdc++.h>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("cmcm.in");
    ofstream fout("cmcm.out");
#endif  // ST_DIO

const int INF = 1e9 + 7;
struct Muchie {
    int vec, cost, idx;
};
int n, m, e, rasp, i, st[2 * 302], dr[2 * 302];
vector<Muchie> gr[2 * 302];
bool viz[2 * 302], ok;

int start, sfarsit;
int cost[2 * 302];
int tata[2 * 302];
int ttidx[2 * 302];

int flux[302][302], costTot, nrmch;
bool utiliz[50002];

static inline bool Dijkstra() {
    //priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    queue<int> q;

    for(int i = start; i <= sfarsit; i++) {
        cost[i] = INF;
        viz[i] = false;
    }
    cost[start] = 0;
    viz[start] = true;

    q.push(start);

    while(!q.empty()) {
        int nod = q.front();
        q.pop();

        //if(cst > cost[nod]) continue;

        for(Muchie mch : gr[nod]) {
            if(0 < flux[nod][mch.vec] && cost[mch.vec] > mch.cost + cost[nod]) {
                cost[mch.vec] = mch.cost + cost[nod];
                tata[mch.vec] = nod;
                ttidx[mch.vec] = mch.idx;

                if(!viz[mch.vec]) {
                    viz[mch.vec] = true;
                    q.push(mch.vec);
                }
            }
        }
    }
    return INF != cost[sfarsit];
}

static inline void Flux() {
    costTot += cost[sfarsit];

    int nod = sfarsit;
    while(start != nod) {
        flux[tata[nod]][nod]--;
        flux[nod][tata[nod]]++;
             if(0 < ttidx[nod]) utiliz[ttidx[nod]] = true;
        else if(0 > ttidx[nod]) utiliz[-ttidx[nod]] = false;
        nod = tata[nod];
    }
}

int main() {
    if(ST_DIO) ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m >> e;
    for(i = 1; i <= e; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        gr[x].push_back({n + y,  c,  i});
        gr[n + y].push_back({x, -c, -i});
        //inv[n + y].push_back({x, 0, -1});
        flux[x][n + y] = 1;
        flux[n + y][x] = 1;
    }

    start = 0;
    sfarsit = n + m + 1;
    for(i = 1; i <= n; i++) {
        gr[start].push_back({i, 0, 0});
        gr[i].push_back({start, 0, 0});
        //inv[i].push_back({start, 0, -1});
        flux[start][i] = 1;
        flux[i][start] = 1;
    }
    for(i = n + 1; i <= n + m; i++) {
        gr[i].push_back({sfarsit, 0, 0});
        gr[sfarsit].push_back({i, 0, 0});
        //inv[sfarsit].push_back({i, 0, -1});
        flux[i][sfarsit] = 1;
        flux[sfarsit][i] = 1;
    }

    while(Dijkstra())
        Flux();

    for(i = 1; i <= e; i++)nrmch += utiliz[i];
    fout << nrmch << ' ' << costTot << '\n';
    for(i = 1; i <= e; i++) {
        if(utiliz[i]) fout << i << ' ';
    }

    return 0;
}
