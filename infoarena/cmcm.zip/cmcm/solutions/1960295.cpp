#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <cstring>
#define NMAX 1000
#define INF 1000000000
using namespace std;
ifstream f ("cmcm.in");
ofstream g ("cmcm.out");
vector < int > a[NMAX];
int n, m, e, X;
int cost[NMAX][NMAX], flux[NMAX][NMAX];
int old_d[NMAX], real_d[NMAX], d[NMAX], Father[NMAX], c[NMAX][NMAX], ind[NMAX][NMAX];
const int MAX = 0x3f3f3f3f;

queue < pair < int, int > > Q;
bitset < NMAX > in_q;

inline int min(const int & a, const int & b)
{
    if (a < b) return a;
    return b;
}

int bellman()
{
    memset(old_d, 0x3f, sizeof(old_d));
    memset(Father, 0, sizeof(Father));
    in_q = bitset<NMAX>(false);
    old_d[0] = 0;
    Q.push(make_pair(0, 0));
    in_q[0] = 1;
    while (!Q.empty())
    {
        int nod = Q.front().second;
        int dist = old_d[nod];
        Q.pop();
        in_q[nod] = 0;
        for (int i = 0; i < a[nod].size(); i++)
        {
            int next = a[nod][i];
            if (flux[nod][next] > 0 && dist + cost[nod][next] < old_d[next])
            {
                old_d[next] = dist + cost[nod][next];
                Father[next] = nod;
                if (!in_q[next])
                {
                    Q.push(make_pair(old_d[next], next));
                    in_q[next] = 1;
                }
            }
        }
    }
    if (old_d[X + 1] != MAX)
    {
        int fluxMin = INF;
        for (int nod = X + 1; nod != 0; nod = Father[nod])
            fluxMin = min(fluxMin, flux[Father[nod]][nod]);
        for (int nod = X + 1; nod != 0; nod = Father[nod])
        {
            flux[Father[nod]][nod] -= fluxMin;
            flux[nod][Father[nod]] += fluxMin;
        }
        return fluxMin * old_d[X + 1];
    }
    return 0;
}

int main()
{
    f>>n>>m>>e;
    X = n + m;
    for (int q = 1; q <= e; q++)
    {
        int x, y, C;
        f>>x>>y>>C;
        a[x].push_back(n + y);
        a[n + y].push_back(x);
        cost[x][n + y] = C;
        cost[n + y][x] = -C;
        flux[x][n + y] = 1;
        c[x][n + y] = 1;
        ind[x][n + y] = q;
    }
    for (int i = 1; i <= n; i++)
    {
        flux[0][i] = 1;
        a[0].push_back(i);
        a[i].push_back(0);
    }
    for (int i = n + 1; i <= X; i++)
    {
        flux[i][X + 1] = 1;
        a[i].push_back(X + 1);
        a[X + 1].push_back(i);
    }

    int x;
    int sol = 0;
    do {
        x = bellman();
        sol += x;
    } while (x);
    int nr = 0;
    vector < int > v;
    for (int i = 1; i <= n; i++)
        for (int j = n + 1; j <= X; j++)
             if (flux[i][j] == 0 && c[i][j] == 1)
             {
                 nr++;
                 v.push_back(ind[i][j]);
                 break;
             }
    g<<nr<<' '<<sol<<'\n';
    for (int i = 0; i < v.size(); i++)
        g<<v[i]<<' ';
    return 0;
}
