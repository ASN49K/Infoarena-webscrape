#pragma GCC optimize ("O3")
#include <bits/stdc++.h>

const int N=360;
const int oo=2000000;

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n,m,S,D,i,x,y,z,t,ans,dist[N],cap[N][N],cost[N][N];
vector<int> v[N];
priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > Q;

void bell()
{
    queue<int> Q;
    bitset<N> in;in.reset();
    for(i=1;i<=n;i++)
        dist[i]=oo,in[i]=0;
    dist[S]=0;Q.push(S);in[S]=1;
    while(Q.size())
    {
        int x=Q.front();
        Q.pop();in[x]=0;
        for(auto it:v[x])
            if(cap[x][it]&&(dist[it]>dist[x]+cost[x][it]))
            {
                dist[it]=dist[x]+cost[x][it];
                if(!in[it])
                    Q.push(it);
                in[it]=1;
            }
    }
    return ;
}

bool dij()
{
    int tata[N],new_d[N],real_d[N];
    for(i=1;i<=n;i++)
        tata[i]=new_d[i]=real_d[i]=oo;
    tata[S]=0;new_d[S]=0;real_d[S]=0;
    Q.push({0,S});
    while(Q.size())
    {
        int x=Q.top().second,
          cst=Q.top().first;
        Q.pop();
        if(cst!=new_d[x])
            continue;
        for(auto it:v[x])
            if(cap[x][it]&&(new_d[it]>new_d[x]+cost[x][it]+dist[it]-dist[x]))
            {
                new_d[it]=new_d[x]+cost[x][it]+dist[it]-dist[x];
                tata[it]=x;
                real_d[it]=real_d[x]+cost[x][it];
                Q.push({new_d[it],it});
            }
    }
    for(i=1;i<=n;i++)
        dist[i]=real_d[i];
    if(dist[D]==oo)
        return 0;
    int flux=oo;
    for(int nod=D;nod!=S;nod=tata[nod])
        flux=min(flux,cap[tata[nod]][nod]);
    for(int nod=D;nod!=S;nod=tata[nod])
    {
        cap[tata[nod]][nod]-=flux;
        cap[nod][tata[nod]]+=flux;
    }
    ans+=dist[D]*flux;
    return 1;
}

int main()
{
    ios_base::sync_with_stdio(0);
    f.tie(0);g.tie(0);
    f>>n>>m>>S>>D;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>z>>t;
        v[x].push_back(y);
        v[y].push_back(x);
        cap[x][y]=z;
        cost[x][y]=t;
        cost[y][x]=-t;
    }
    bell();
    for(;dij(););
    g<<ans;
    return 0;
}
