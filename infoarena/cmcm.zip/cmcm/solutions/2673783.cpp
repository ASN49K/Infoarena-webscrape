#include <fstream>
#include <deque>
#include <vector>
#include <bitset>
#include <deque>
#define dim 610
#define inf 1000000000
using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int n,m,e,c[dim][dim],flux[dim][dim],z[dim][dim],i,j,k,d[dim],edge[dim][dim],nod,vec,t[dim],M,sol,cnt;
vector <int> l[dim];
deque <int> q;
bitset <dim> f;

bool bell(){
    f.reset();
    bool ok=0;
    for(int i=1;i<=n+m+1;i++)
        d[i]=inf;
    d[0]=0;
    f[0]=1;
    q.push_back(0);

    while(!q.empty()){
        nod=q.front();
        q.pop_front();
        f[nod]=0;

        if(nod==n+m+1)
            ok=1;

        for(int i=0;i<l[nod].size();i++){
            vec=l[nod][i];

            if(d[vec]>d[nod]+z[nod][vec] && c[nod][vec]>flux[nod][vec]){
                d[vec]=d[nod]+z[nod][vec];
                t[vec]=nod;

                if(!f[vec]){
                    f[vec]=1;
                    q.push_back(vec);
                }
            }
        }
    }

    return ok;
}

int main(){
    fin>>n>>m>>e;
    for(i=1;i<=n;i++){
        c[0][i]=1;
        l[i].push_back(0);
        l[0].push_back(i);
    }

    for(i=1;i<=m;i++){
        c[i+n][n+m+1]=1;
        l[n+m+1].push_back(i+n);
        l[i+n].push_back(n+m+1);
    }

    for(k=1;k<=e;k++){
        fin>>i>>j;
        fin>>z[i][j+n];
        z[j+n][i]=-z[i][j+n];
        c[i][j+n]=1;
        l[i].push_back(j+n);
        l[j+n].push_back(i);
        edge[i][j+n]=k;
    }

    while(bell()){
        nod=n+m+1; M=inf;

        while(nod){
            M=min(M,c[t[nod]][nod]-flux[t[nod]][nod]);
            nod=t[nod];
        }

        nod=n+m+1;
        while(nod){
            flux[t[nod]][nod]+=M;
            flux[nod][t[nod]]-=M;
            nod=t[nod];
        }

        sol+=M*d[n+m+1];
    }

    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            if(flux[i][j+n]==1)
                cnt++;

    fout<<cnt<<" "<<sol<<"\n";

    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            if(flux[i][j+n]==1)
                fout<<edge[i][j+n]<<" ";

    return 0;
}
