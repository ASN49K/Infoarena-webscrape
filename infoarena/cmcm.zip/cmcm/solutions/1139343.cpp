#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iterator>
#include <random>
#include <assert.h>
using namespace std;

const string file = "cmcm";

const string infile = file + ".in";
const string outfile = file + ".out";

const int INF = 0x3f3f3f3f; 

//#define ONLINE_JUDGE

vector<int> potential;
vector<int> realD;
vector<int> dist;
vector<int> prec;

vector<vector<int> > Cap;
vector<vector<int> > Cost;
vector<vector<int> > G;

int N, M;
int S;
int D;

int Cuplaj;
int MaxCost;


void bellman()
{
    queue<int> que;
    vector<bool> inQ(N + M + 2, false);
    que.push(S);
    inQ[S] = true;
    fill(potential.begin(), potential.end(), INF);
    potential[S] = 0;
    while(que.empty() == false)
    {
        int x = que.front();
        que.pop();
        inQ[x] = false;
        for(vector<int>::iterator itr = G[x].begin();
                itr != G[x].end();
                itr++)
        {
            if(Cap[x][*itr] == 0)
                continue;
            int dst = *itr;
            int newD = potential[x] + Cost[x][*itr];
            if(potential[dst] > newD)
            {
                potential[dst] = newD;
                if(inQ[dst] == false)
                {
                    inQ[dst] = true;
                    que.push(dst);
                }
            }
        }
    }
}
bool dijkstra()
{
    fill(dist.begin(), dist.end(), INF);
    fill(realD.begin(), realD.end(), INF);
    dist[S] = realD[S] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > heap;
    heap.push(make_pair(0, S));

    while(heap.empty() == false)
    {
        pair<int, int> c = heap.top();
        heap.pop();
        int d = c.first;
        int x = c.second;
        if(dist[x] != d)
            continue;
        for(vector<int>::iterator itr = G[x].begin();
                itr != G[x].end();
                itr++)
        {
            if(Cap[x][*itr] == 0)
                continue;
            int dst = *itr;
            int newD = dist[x] + Cost[x][*itr] - potential[dst] + potential[x];
            if(dist[dst] > newD)
            {
                dist[dst] = newD;
                realD[dst] = realD[x] + Cost[x][dst];
                heap.push(make_pair(dist[dst], dst));
                prec[dst] = x;
            }

        }
    }
    if(dist[D] == INF)
        return false;
    potential = realD;

    int minFlow = INF;
    for(int i = D; i != S; i = prec[i])
    {
        minFlow = min(minFlow, Cap[prec[i]][i]);
    }

    for(int i = D; i != S; i = prec[i])
    {
        Cap[prec[i]][i] -= minFlow;
        Cap[i][prec[i]] += minFlow;
    }
    MaxCost += realD[D] * minFlow;
    Cuplaj += minFlow;
    return true;
}

struct Edge
{
    int x; 
    int y;
};
int main()
{
#ifdef ONLINE_JUDGE
	ostream &fout = cout;
	istream &fin = cin;
#else
	fstream fin(infile.c_str(), ios::in);
	fstream fout(outfile.c_str(), ios::out);
#endif	

    int E;
    fin >> N >> M >> E;

    int nods = N + M + 2;
    G.resize(nods);
    potential.resize(nods);
    realD.resize(nods);
    dist.resize(nods);
    prec.resize(nods);

    Cap.resize(nods, vector<int>(nods, 0));
    Cost.resize(nods, vector<int>(nods, 0));
    vector<Edge> edges(E);
    S = N + M;
    D = N + M + 1;

    for(int i = 0; i < N; i++)
    {
        G[S].push_back(i);
        Cap[S][i] = 1;
    }

    for(int i = N; i < N + M; i++)
    {
        G[i].push_back(D);
        Cap[i][D] = 1;
    }

    for(int i = 0; i < E; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;
        x--, y--;
        y += N;
        
        edges[i].x = x;
        edges[i].y = y;

        G[x].push_back(y);
        G[y].push_back(x);
        Cap[x][y] = 1;
        Cost[x][y] = c;
        Cost[y][x] = -c;
    }

    bellman();
    while(dijkstra());

    fout << Cuplaj << " " << MaxCost << "\n";
    /*
    for(int i = 0; i < E; i++)
    {
        if(Cap[edges[i].x][edges[i].y] == 0)
        {
            fout << i + 1 << " ";
        }
    }
    fout << "\n";*/
#ifdef ONLINE_JUDGE
#else
    fout.close();
	fin.close();
#endif
}
