#include <cstdio>
#define N 605
#define E 100005
#define inf 1999999999
using namespace std;
struct nod{ int val; nod *urm; }*G[N];
int cap[N][N],cost[N][N],flux[N][N],muc[N][N];
int n,m,SS,SD;
int ctotal,k,sol[E],dist[N],tata[N],c[E];
bool viz[N];

void add(int x,int y,int cpc,int cst)
{ nod *aux;
aux=new nod; aux->val=y; aux->urm=G[x]; G[x]=aux;
cap[x][y]=cpc; cost[x][y]=cst;
}
void read()
{ int e,x,y,z,i;
freopen("cmcm.in","r",stdin); scanf("%d %d %d\n",&n,&m,&e);
for(i=1;i<=e;++i)
    {
    scanf("%d %d %d\n",&x,&y,&z);
    muc[x][y+n]=i;
    add(x,y+n,1,z);
    add(y+n,x,0,-z);
    }
fclose(stdin);
}
int bellman_ford()
{ int i,x,y,p,u;
  nod *aux;
for(i=1;i<=m;++i)
    {
    dist[i]=inf; dist[n+i]=inf;
    viz[i]=0; viz[n+i]=0;
    tata[i]=0; tata[n+i]=0;
    }
dist[SD]=inf; tata[SD]=0;
dist[SS]=0; tata[SS]=0; viz[SS]=1;
p=u=1; c[1]=SS;
while(p<=u)
    {
    x=c[p]; viz[x]=0;
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        {
        y=aux->val;
        if(cap[x][y]>flux[x][y]&&dist[x]+cost[x][y]<dist[y])
            {
            dist[y]=dist[x]+cost[x][y];
            tata[y]=x;
            if(viz[y]==0)
                 {
                 c[++u]=y;
                 viz[y]=1;
                 }
            }
        }
    ++p;
    }
if(dist[SD]!=inf)return 1;
    else return 0;
}
inline int min(int x,int y)
{
if(x<y)return x;
    else return y;
}
void solve()
{ int fm,i;
while(bellman_ford())
    {
    fm=inf;
    for(i=SD;i!=SS;i=tata[i])
        fm=min(fm,cap[tata[i]][i]-flux[tata[i]][i]);
    if(fm)
        {
        for(i=SD;i!=SS;i=tata[i])
            {
            flux[tata[i]][i]+=fm;
            flux[i][tata[i]]-=fm;
            }
        }
    }
}
void reconstr_sol()
{ int i,j;
ctotal=0; k=0;
for(i=1;i<=n;++i)
    for(j=1;j<=m;++j)
        if(flux[i][j+n]==1)
            {
            ctotal+=cost[i][j+n];
            sol[++k]=muc[i][j+n];
            }
}
void write()
{ int i;
freopen("cmcm.out","w",stdout); printf("%d %d\n",k,ctotal);
for(i=1;i<=k;++i)printf("%d ",sol[i]);
fclose(stdout);
}
int main()
{ int i;
read();
SS=601; // super sursa;
SD=602; // super destinatie
for(i=1;i<=n;++i)
    {
    add(SS,i,1,0);
    add(i,SS,0,0);
    }
for(i=1;i<=m;++i)
    {
    add(i+n,SD,1,0);
    add(SD,i+n,0,0);
    }
solve();
reconstr_sol();
write();
return 0;
}
