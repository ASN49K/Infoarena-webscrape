#include <bits/stdc++.h>
#define infile "cmcm.in"
#define outfile "cmcm.out"
#define NMAX 605
#define INF 0x3f3f3f3f

using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int n, m, e, flux, ans, C[NMAX][NMAX], F[NMAX][NMAX], cost[NMAX][NMAX], d[NMAX], t[NMAX];
bitset <NMAX> v;
vector <pair <int, int>> edges[NMAX];
queue <int> q;

bool bf()
{
    v.reset();
    memset(d, INF, sizeof(d));
    v[0] = 1;
    d[0] = 0;
    q.push(0);

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        v[nod] = 0;
        for(auto child : edges[nod])
            if(C[nod][child.first] > F[nod][child.first] && d[child.first] > d[nod] + cost[nod][child.first])
            {
                d[child.first] = d[nod] + cost[nod][child.first];
                t[child.first] = nod;
                if(!v[child.first])
                {
                    v[child.first] = 1;
                    q.push(child.first);
                }
            }
    }
    return (d[n + m + 1] != INF);
}

int main()
{
    freopen(infile, "r", stdin);
    freopen(outfile, "w", stdout);
    scanf("%d %d %d", &n, &m, &e);

    for(int i = 1; i <= e; i++)
    {
        int x, y, c;
        scanf("%d %d %d", &x, &y, &c);
        edges[x].push_back({n + y, i});
        edges[n + y].push_back({x, 0});
        edges[0].push_back({x, 0});
        edges[x].push_back({0, 0});
        edges[n + y].push_back({n + m + 1, 0});
        edges[n + m + 1].push_back({n + y, 0});

        cost[x][y + n] = c;
        cost[y + n][x] = -c;
        C[x][y + n] = C[0][x] = C[y + n][n + m + 1] = 1;
    }

    while(bf())
    {
        int k = n + m + 1;
        while(k != 0)
        {
            F[t[k]][k] ++;
            F[k][t[k]] --;
            k = t[k];
        }
        ans += d[n + m + 1];
        flux ++;
    }

    printf("%d %d\n", flux, ans);
    for(int i = 1; i <= n; i++)
        for(auto child : edges[i])
            if(F[i][child.first] == 1)
            {
                printf("%d ", child.second);
                break;
            }

    return 0;
}
