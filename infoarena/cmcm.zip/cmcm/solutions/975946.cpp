#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
#include <algorithm>

#define newn a[x][i]

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int N = 305*2;
const int oo = 0x3f3f3f3f;

int L, R, E, s, d, sol, cmin, f[N][N], c[N][N],
cst[N][N], real[N], dist[N], oldd[N], t[N], mc[N][N];
typedef pair <int, int> nod;
priority_queue < nod, vector<nod>, greater<nod> > h;
vector <int> a[N];

inline void Add(const int &x, const int &y)
{
    a[x].push_back(y);
    a[y].push_back(x);
}

inline bool Dijkstra()
{
    for(int i=1; i<=d; i++) dist[i] = oo;
    real[s] = dist[s] = 0;
    h.push(nod(0, s));
    while(!h.empty())
    {
        int val = h.top().first, x = h.top().second; h.pop();
        if(val != dist[x]) continue;
        for(unsigned i=0; i<a[x].size(); i++)
            if(f[x][newn] < c[x][newn])
            {
                int cost = dist[x] + cst[x][newn] + oldd[x] - oldd[newn];
                if(cost < dist[newn])
                {
                    t[newn] = x;
                    dist[newn] = cost;
                    real[newn] = real[x] + cst[x][newn];
                    h.push(nod(dist[newn], newn));
                }
            }
    }
    memcpy(oldd, real, sizeof oldd);
    return (dist[d] != oo);
}

int main()
{
    fin>>L>>R>>E;
    s = 0, d = L + R + 1;
    for(int i=1; i<=E; i++)
    {
        int x, y, z;
        fin>>x>>y>>z; y += L;
        Add(x, y); Add(s, x); Add(y, d);
        c[x][y] = 1;
        c[s][x] = c[y][d] = 1;
        cst[x][y] -= cst[y][x] = -z;
        mc[x][y] = i;
    }

    while(Dijkstra())
    {
        for(int j=d; j!=s; j=t[j])
            f[t[j]][j]++, f[j][t[j]]--;
        sol++;
        cmin += real[d];
    }
    fout<<sol<<' '<<cmin<<'\n';
    for(int i=1; i<=L; i++)
        for(int j=L+1; j<=L+R; j++)
            if(f[i][j] > 0)
                fout<<mc[i][j]<<' ';
    return 0;
}
