//test Andrei Puni
using namespace std;
#include<iostream>
#include<fstream>
#include<vector>
#include<cstring>

#define  pb push_back
#define oo 0x3f3f3f3f
struct nod{
int lg,c;};

vector<nod> G[710];
ofstream fout("cmcm.out");
//int viz[700],q[700],isinq[700],d[700];
//int C[700][700],F[700][700];

int viz[700],q[7000],isinq[700],d[70];
int C[700][700],F[700][700];
int ret[305][305],ante[700];

int cost_minim,S,D,E,sink;

bool BFS()
{  int i;
    //cout<<5;
    memset(ante,0, sizeof(ante));
    memset(viz,0,sizeof(viz));
    memset(q,0,sizeof(q));
    memset(isinq,0,sizeof(isinq));
    for(i=0;i<=sink;i++)
       d[i]=oo;
    d[1]=0;
    viz[1]=1;
    q[q[0]]=1;
    isinq[1]=1;
    vector<nod>::iterator it;
    int front=0,u;
   // cout<<6;
    while(front<=q[0])
    {
        u=q[front];
        front++;
        front%=700;
        isinq[u]=0;
        for(it=G[u].begin();it<G[u].end();it++)
        {
            if(C[u][it->lg]>F[u][it->lg])
            {
                if(d[it->lg]>d[u]+it->c)
                {
                    ante[it->lg]=u;
                    d[it->lg]=d[u]+it->c;
                    viz[it->lg]=1;
                    if(!isinq[it->lg])
                    {
                        isinq[it->lg]=1;
                        ++q[0];
                        q[0]%=700;
                        q[q[0]]=it->lg;
                    }
                }
            }
        }
    }
    //cout<<7;
    cost_minim=d[sink];

    return viz[sink];

}

void solve()
{
    int fmin,i,flow=0,cmin=0;
    vector<nod>::iterator it;
    for(flow=0;BFS();)
    {
       // cout<<1;
                fmin=C[ante[sink]][sink]-F[ante[sink]][sink];
        for(i=ante[sink];i!=1;i=ante[i])
        {
            fmin=min(fmin,C[ante[i]][i]-F[ante[i]][i]);
        }
         //cout<<2;
        F[ante[sink]][sink]+=fmin;
        F[sink][ante[sink]]-=fmin;

        for(i=ante[sink];i!=1;i=ante[i])
        {

            F[ante[i]][i]+=fmin;
            F[i][ante[i]]-=fmin;
        }
        //cout<<3;
        flow++;
        cmin+=cost_minim;//*fmin;
        //cout<<4;
    }
    //cout<<4;
    fout<<flow<<" "<<cmin<<"\n";
    for(i=2;i<=S+1;i++)
    {
        for(it=G[i].begin();it<G[i].end();it++)
        {
            if(F[i][it->lg]==1)
            {
                fout<<ret[i-1][it->lg-S-1]<<" ";

            }
        }
    }
}

void cit()
{int i,z,y,x,Y;
    ifstream fin("cmcm.in");

    fin>>S>>D>>E;
    sink=S+D+2;
    for(i=1;i<=E;i++)
    {
        fin>>x>>y>>z;
        Y=y+S+1;
        G[x+1].pb((nod){Y,z});
        G[Y].pb((nod){x+1,-z});
        C[x+1][Y]=1;
        ret[x][y]=i;
    }

    for(i=2;i<=S+1;i++)
    {
        G[0+1].pb((nod){i,0});
        G[i].pb((nod){0+1,0});
        C[0+1][i]=1;
    }
    for(i=1;i<=D;i++)
    {
        G[i+S+1].pb((nod){sink,0});
        G[sink].pb((nod){1+i+S,0});
        C[1+i+S][sink]=1;
    }

    fin.close();
}

int main()
{

    cit();
     //cout<<"merge citirea";
    solve();

    fout.close();
    return 0;

}

