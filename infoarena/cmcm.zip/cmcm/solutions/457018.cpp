/* 
 * File:   main.cpp
 * Author: virtualdemon
 *
 * Created on May 17, 2010, 7:49 PM
 */
#include <queue>
#include <cstdlib>
#include <fstream>
#define Nmax 711
#define oo 2147483647

/*
 * 
 */
using namespace std;
typedef pair< int, int > pr;
int N, M, E, source, sink=700;
bool was[Nmax];
int f[Nmax], d[Nmax];
int C[Nmax][Nmax], F[Nmax][Nmax], idx[Nmax][Nmax];
queue< int > Q;
vector< pr > G[Nmax];
vector< pr >::const_iterator it, iend;
inline bool find_path( void )
{
    int x;
    for( x=1; x <= E; ++x )
    {
        f[x]=-1;
        d[x]=oo;
        was[x]=false;
    }
    f[sink]=-1;
    f[source]=0;
    d[sink]=oo;
    d[source]=0;
    was[sink]=false;
    was[source]=true;
    for( Q.push(source); !Q.empty(); )
    {
        x=Q.front(); Q.pop();
        was[x]=false;
        for( it=G[x].begin(), iend=G[x].end(); it < iend; ++it )
            if( C[x][it->first] > F[x][it->first]  &&  d[it->first] > d[x]+it->second )
            {
                f[it->first]=x;
                d[it->first]=d[x]+it->second;
                if( false == was[it->first] )
                {
                    Q.push(it->first);
                    was[it->first]=true;
                }
            }
    }
    return oo != d[sink];
}
int main( void )
{
    int x, y, i, c;
    ifstream in( "cmcm.in" );
    in>>N>>M>>E;
    for( i=1; i <= E; ++i )
    {
        in>>x>>y>>c;
        y+=N+1;
        C[x][y]=1;
        idx[x][y]=i;
        G[x].push_back( pr( y, c ) );
        G[y].push_back( pr( x, -c ) );
        if( !was[x] )
        {
            C[source][x]=1;
            G[source].push_back( pr( x, 0 ) );
            G[x].push_back( pr( source, 0 ) );
            was[x]=true;
        }
        if( !was[y] )
        {
            C[y][sink]=1;
            G[y].push_back( pr( sink, 0 ) );
            G[sink].push_back( pr( x, 0 ) );
            was[y]=true;
        }
    }
    E=N+M+2;
    for( x=y=0; find_path(); ++x, y+=d[sink] )
    {
        for( i=sink; source != i; i=f[i] )
        {
            ++F[f[i]][i];
            --F[i][f[i]];
        }
    }
    ofstream out( "cmcm.out" );
    out<<x<<' '<<y<<'\n';
    for( i=1; x && i <= N; ++i )
    {
        for( it=G[i].begin(), iend=G[i].end(); it < iend; ++it )
            if( F[i][it->first] > 0 )
            {
                --x;
                out<<idx[i][it->first]<<' ';
                break;
            }
    }
    return EXIT_SUCCESS;
}

