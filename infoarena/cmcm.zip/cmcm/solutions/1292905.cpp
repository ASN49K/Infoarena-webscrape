#include <fstream>
#include <vector>
#include <string.h>
using namespace std;
ifstream ka("cmcm.in");
ofstream ki("cmcm.out");
#define MAX_N 710
#define inf 2000000000

int n, m, e, dest, sol, nr, improve;
int Q[MAX_N * MAX_N], tata[MAX_N], dist[MAX_N], use[MAX_N];
int C[MAX_N][MAX_N], F[MAX_N][MAX_N], edge[MAX_N][MAX_N];

vector <int> v[MAX_N], cost[MAX_N];

void build_graph() {
    //sursa este nodul 1, destinatia n + m + 2
    dest = n + m + 2;
    for (int i = 2; i <= n + 1; i++)
    {
        v[1].push_back(i);
        cost[1].push_back(0);
        v[i].push_back(1);
        cost[i].push_back(0);
        C[1][i] = 1;
    }
    for (int i = n + 2; i <= n + m + 1; i++) {
        v[i].push_back(dest);
        cost[i].push_back(0);
        v[dest].push_back(i);
        cost[dest].push_back(0);
        C[i][dest] = 1;
    }
}

int bellman_ford() {
    for (int i = 1; i <= dest; i++)
    {
        dist[i] = inf;
        tata[i] = -1;
        use[i] = 0;
    }
    dist[1] = 0;
    use[1] = 1;
    int st = 0, dr = 1;
    Q[1] = 1;
    while (st < dr)
    {
        st++;
        int len = v[Q[st]].size();
        for (int i = 0; i < len; i++)
        {
            if (C[Q[st]][v[Q[st]][i]] > F[Q[st]][v[Q[st]][i]] && dist[v[Q[st]][i]] > dist[Q[st]] + cost[Q[st]][i]) {
                dist[v[Q[st]][i]] = dist[Q[st]] + cost[Q[st]][i];
                tata[v[Q[st]][i]] = Q[st];
                if (!use[v[Q[st]][i]])
                {
                    Q[++dr] = v[Q[st]][i];
                    use[v[Q[st]][i]] = 1;
                }
            }
        }
        use[Q[st]] = 0;
    }
    if (dist[dest] < inf)
    {
        int flux = inf;
        for (int i = dest; i != 1; i = tata[i])
            flux = min(flux, C[tata[i]][i] - F[tata[i]][i]);
        for (int i = dest; i != 1; i = tata[i])
        {
            F[tata[i]][i] += flux;
            F[i][tata[i]] -= flux;
        }
        return flux * dist[dest];
    }
    return 0;
}

int main()
{
    ka >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int p, q, val;
        ka >> p >> q >> val;
        p++;
        q += n + 1;
        v[p].push_back(q);
        cost[p].push_back(val);
        v[q].push_back(p);
        cost[q].push_back(-val);
        edge[p][q] = i;
        C[p][q] = 1;
    }
    build_graph();
    improve = 1;
    while (improve)
    {
        improve = bellman_ford();
        sol += improve;
    }
    for (int i = 2; i <= n + 1; i++)
        for (int j = n + 2; j < dest; j++)
            if (C[i][j] && F[i][j])
            {
                nr++;
                break;
            }
    ki << nr << " " << sol << '\n';
    for (int i = 2; i <= n + 1; i++)
        for (int j = n + 2; j < dest; j++)
            if (C[i][j] && F[i][j])
            {
                ki << edge[i][j] << " ";
                break;
            }
}
