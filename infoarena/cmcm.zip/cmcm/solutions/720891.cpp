#include <cstdio>
#define N 605
#define E 50005
#define inf 1999999999
using namespace std;
struct nod{ int val; nod *urm; }*G[N];
struct coada{ int v; coada *next; }*st,*dr;
int cap[N][N],cost[N][N],flux[N][N],muc[N][N];
int n,m,SS,SD;
int ctotal,k,sol[E],dist[N],tata[N];
bool viz[N];

void add(int x,int y,int cpc,int cst)
{ nod *aux;
aux=new nod; aux->val=y; aux->urm=G[x]; G[x]=aux;
cap[x][y]=cpc; cost[x][y]=cst;
}
void read()
{ int e,x,y,z,i;
freopen("cmcm.in","r",stdin); scanf("%d %d %d\n",&n,&m,&e);
for(i=1;i<=e;++i)
    {
    scanf("%d %d %d\n",&x,&y,&z);
    muc[x][y+n]=i;
    add(x,y+n,1,z);
    add(y+n,x,0,-z);
    }
fclose(stdin);
}
inline int min(int x,int y)
{
if(x<y)return x;
    else return y;
}
int bellman_ford()
{ coada *adr;
  int i,x,y,fm;
  nod *aux;
for(i=1;i<=n+m;++i)
    {
    dist[i]=inf;
    viz[i]=0;
    tata[i]=0;
    }
dist[SD]=inf; tata[SD]=0;
dist[SS]=0;
adr=new coada; adr->v=SS; adr->next=NULL; st=dr=adr; viz[SS]=1;
while(st)
    {
    x=st->v; viz[x]=0;
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        {
        y=aux->val;
        if(cap[x][y]>flux[x][y]&&dist[y]>dist[x]+cost[x][y])
            {
            dist[y]=dist[x]+cost[x][y];
            tata[y]=x;
            if(viz[y]==0)
                {
                adr=new coada; adr->v=y; adr->next=NULL; dr->next=adr; dr=adr;
                viz[y]=1;
                }
            }
        }
    adr=st; st=st->next; delete adr;
    }
if(dist[SD]!=inf)
    {
    fm=inf;
    for(i=SD;i!=SS;i=tata[i])
        fm=min(fm,cap[tata[i]][i]-flux[tata[i]][i]);
    if(fm)
        {
        for(i=SD;i!=SS;i=tata[i])
            {
            flux[tata[i]][i]+=fm;
            flux[i][tata[i]]-=fm;
            }
        }
    return fm*dist[SD];
    }
return 0;
}
void solve()
{ int x;
x=1;
while(x)
    x=bellman_ford();

}
void reconstr_sol()
{ int i,j;
ctotal=0; k=0;
for(i=1;i<=n;++i)
    for(j=1;j<=m;++j)
        if(flux[i][j+n]==1)
            {
            ctotal+=cost[i][j+n];
            sol[++k]=muc[i][j+n];
            }
}
void write()
{ int i;
freopen("cmcm.out","w",stdout); printf("%d %d\n",k,ctotal);
for(i=1;i<=k;++i)printf("%d ",sol[i]);
fclose(stdout);
}
int main()
{ int i;
read();
SS=601; // super sursa;
SD=602; // super destinatie
for(i=1;i<=n;++i)
    {
    add(SS,i,1,0);
    add(i,SS,0,0);
    }
for(i=1;i<=m;++i)
    {
    add(i+n,SD,1,0);
    add(SD,i+n,0,0);
    }
solve();
reconstr_sol();
write();
return 0;
}
