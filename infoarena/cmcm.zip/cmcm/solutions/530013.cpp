#include <fstream>
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

#define maxn 610
#define oo 2000000000

int i,j,L,R,M,st,dest,k,flmin,Cmin;
int A[maxn][maxn],C[maxn][maxn],Cost[maxn][maxn],P[maxn][maxn];
int v[maxn],Q[maxn*maxn],D[maxn],from[maxn];
int Sol[maxn];

inline int min(int a,int b)
{
	return a<b ? a : b;
}

void citire()
{
	int x,y,z;
	fin >> L >> R >> M;
	for(i=1;i<=M;i++)
	{
		fin >> x >> y >> z;
		x++; y+=L+1;
		A[x][++A[x][0]]=y; A[y][++A[y][0]]=x;
		C[x][y]=1; P[x][y]=i;
		Cost[x][y]=z; Cost[y][x]=-z;
	}
}

void constr()
{
	st=1; dest=L+R+2;
	for(i=2;i<=L+1;i++)
	{
		A[1][++A[1][0]]=i; 
		A[i][++A[i][0]]=1;
		C[1][i]=1;
	}
	for(i=L+2;i<=L+R+1;i++)
	{
		A[dest][++A[dest][0]]=i;
		A[i][++A[i][0]]=dest;
		C[i][dest]=1;
	}
}

int BF()
{
	int pi,ps,x; pi=ps=1;
	for(i=1;i<=dest;i++)
	{
		D[i]=oo; v[i]=0; from[i]=0;
	}
	D[1]=0; Q[1]=1; v[1]=1;
	while(ps<=pi)
	{
		x=Q[ps];
		for(i=1;i<=A[x][0];i++)
			if(C[x][A[x][i]]>0 && D[x]+Cost[x][A[x][i]]<D[A[x][i]])
			{
				D[A[x][i]]=D[x]+Cost[x][A[x][i]];
				from[A[x][i]]=x;
				if(!v[A[x][i]])
				{
					Q[++pi]=A[x][i];
					v[A[x][i]]=1;
				}
			}
		v[x]=0;
		ps++;
	}
	return D[dest]<oo;
}

int main()
{
	citire();
	constr();
	while(BF())
	{
		flmin=oo;
		for(k=dest;k!=1;k=from[k])
			flmin=min(flmin,C[from[k]][k]);
		for(k=dest;k!=1;k=from[k])
		{
			C[from[k]][k]-=flmin;
			C[k][from[k]]+=flmin;
		}
		Cmin+=flmin*D[dest];
	}
	for(i=2;i<=L+1;i++)
		for(j=L+2;j<dest;j++)
			if(C[i][j]==0 && P[i][j]) 
				Sol[++Sol[0]]=P[i][j];
	fout << Sol[0] << " " << Cmin << '\n';
	for(i=1;i<=Sol[0];i++)
		fout << Sol[i] << " ";
}
