#include<cstdio>
#include<vector>
#include<queue>
#include<algorithm>
#define NMAX 710
#define INF (1<<30)
using namespace std;
FILE *fin,*fout;
int n,m,source,destination,sol;
int COST[NMAX][NMAX],CAPACITY[NMAX][NMAX],muchie[NMAX][NMAX],FLUX[NMAX][NMAX],DIST[NMAX];
short TT[NMAX];
vector<short> G[NMAX];
queue<short> Q;
bool use[NMAX];
void read()
{
	fin=fopen("cmcm.in","r");
	int x,y,edges,c;
	fscanf(fin,"%d %d %d",&n,&m,&edges);
	for(int i=1;i<=edges;i++)
	{
		fscanf(fin,"%d %d %d",&x,&y,&c);
		y+=n;
		G[x].push_back(y);
		G[y].push_back(x);
		COST[x][y]=c;
		COST[y][x]=-c;
		CAPACITY[x][y]=1;
		muchie[x][y]=i;
	}
	fclose(fin);
}
void print()
{
	fout=fopen("cmcm.out","w");
	int i,j,c=0;
	for(i=1;i<=n;i++)
		for(j=n+1;j<destination;j++)
			if(CAPACITY[i][j] && FLUX[i][j])
			{
				c++;
				break;
			}
	fprintf(fout,"%d %d\n",c,sol);
	for(i=1;i<=n;i++)
		for(j=n+1;j<destination;j++)
			if(CAPACITY[i][j] && FLUX[i][j])
			{
				fprintf(fout,"%d ",muchie[i][j]);
				break;
			}
	fclose(fout);
}
void prepare()
{
	destination=n+m+1;
	for(int i=1;i<=n;i++)
	{
		G[i].push_back(source);
		G[source].push_back(i);
		CAPACITY[source][i]=1;
	}
	for(int i=n+1;i<=n+m;i++)
	{
		G[i].push_back(destination);
		G[destination].push_back(i);
		CAPACITY[i][destination]=1;
	}
}
void INIT()
{
	for(int i=0;i<=destination;i++)
	{
		DIST[i]=INF;
		TT[i]=-1;
	}
}
bool bellman_ford()
{
	short nod,vec;
	INIT();
	Q.push(source);
	use[source]=1;
	DIST[source]=0;
	while(!Q.empty())
	{
		nod=Q.front();
		Q.pop();
		for(size_t i=0;i<G[nod].size();i++)
		{
			vec=G[nod][i];
			if(CAPACITY[nod][vec]>FLUX[nod][vec] && DIST[nod]+COST[nod][vec]<DIST[vec])
			{
				DIST[vec]=DIST[nod]+COST[nod][vec];
				TT[vec]=nod;
				if(!use[vec])
				{
					use[vec]=1;
					Q.push(vec);
				}
			}
		}
		use[nod]=0;
	}
	if(DIST[destination]!=INF)
	{
		int i,val=INF;
		for(i=destination;i!=source;i=TT[i])
			val=min(val,CAPACITY[TT[i]][i]-FLUX[TT[i]][i]);
		for(i=destination;i!=source;i=TT[i])
		{
			FLUX[TT[i]][i]+=val;
			FLUX[i][TT[i]]-=val;
		}
		sol+=val*DIST[destination];
		return 1;
	}
	return 0;
}
int main()
{
	read();
	prepare();
	while(bellman_ford());
	print();
	return 0;
}
