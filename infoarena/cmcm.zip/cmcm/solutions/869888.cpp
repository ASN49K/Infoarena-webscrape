#include<iostream>
#include<fstream>
#include<vector>
#include<string.h>
using namespace std;

#define NMAX 605
#define INF 0x3f3f3f3f
#define pb push_back

vector <int> v[NMAX];
int cap[NMAX][NMAX],cost[NMAX][NMAX],ind[NMAX][NMAX],p[NMAX],viz[NMAX],inq[NMAX],c[NMAX*NMAX],d[NMAX];

int bellman_ford(int start, int finish)
{
	int st,dr,nod;
	memset(inq,0,sizeof(inq));
	memset(d,INF,sizeof(d));
	memset(p,0,sizeof(p));
	st=1;
	dr=1;
	c[st]=start;
	inq[start]=1;
	d[start]=0;
	p[start]=0;
	while(st<=dr) {
		nod=c[st];
		st++;
		inq[nod]=0;
		for(vector <int> :: iterator it=v[nod].begin();it!=v[nod].end();it++)
			if(cap[nod][*it]>=1 && d[*it]>d[nod]+cost[nod][*it]) {
				d[*it]=d[nod]+cost[nod][*it];
				p[*it]=nod;
				if(inq[*it]==0) {
					inq[*it]=1;
					c[++dr]=*it;
				}
			}
	}
	if(d[finish]!=INF) {
		for(nod=finish;nod!=start;nod=p[nod]) {
			cap[p[nod]][nod]--;
			cap[nod][p[nod]]++;
		}
		return d[finish];
	}
	return INF;
}


int main ()
{
	int n,m,e,i,x,y,z,cmin,fluxmax,aux,j;
	ifstream f("cmcm.in");
	ofstream g("cmcm.out");
	f>>n>>m>>e;
	memset(cap,INF,sizeof(cap));
	for(i=1;i<=e;i++) {
		f>>x>>y>>z;
		y=y+n;
		v[x].pb(y);
		v[y].pb(x);
		cap[x][y]=1;
		cap[y][x]=0;
		cost[x][y]=z;
		cost[y][x]=-z;
		ind[x][y]=i;
	}
	f.close();
	for(i=1;i<=n;i++) {
		v[0].pb(i);
		v[i].pb(0);
		cap[0][i]=1;
		cap[i][0]=0;
	}
	for(i=1+n;i<=m+n;i++) {
		v[i].pb(n+m+1);
		v[n+m+1].pb(i);
		cap[i][n+m+1]=1;
		cap[n+m+1][i]=0;
	}
	aux=0;
	cmin=0;
	fluxmax=0;
	while(aux!=INF) {
		aux=bellman_ford(0,n+m+1);
		if(aux!=INF) {
			fluxmax++;
			cmin=cmin+d[n+m+1];
		}
	}
	g<<fluxmax<<" "<<cmin<<'\n';
	for(i=1;i<=n;i++)
		for(j=n+1;j<=n+m;j++)
			if(cap[i][j]==0)
				g<<ind[i][j]<<" ";
	g.close();
	return 0;
}