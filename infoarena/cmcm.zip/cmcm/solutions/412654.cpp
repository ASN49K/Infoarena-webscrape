#include<vector>
#include<algorithm>
#include<queue>
using namespace std;
#define INF 1<<30
int n,m,e,nr,c,cost[605];
short int C[605][605],F[605][605],i,j,START,END,x,y,z;
typedef pair <short int ,short int> p;
short int T[605];
bool ut[605];
struct cmp
{
	bool operator () (const short int &i,const short int &j) const
	{
		return cost[i]>cost[j];
	}
};
priority_queue <short int,vector <short int>,cmp> Q;
vector <p> g[605];
bool dijkstra()
{
	for(i=0;i<=n+m+1;i++)
		cost[i]=INF;
	cost[START]=0;
	vector <p> ::iterator it;
	for(Q.push(START);!Q.empty();)
	{
		int nod=Q.top();
		Q.pop();
		ut[nod]=0;
		for(it=g[nod].begin();it!=g[nod].end();it++)
		{
			if(C[nod][it->first]>F[nod][it->first]&&cost[it->first]>cost[nod]+it->second)
			{
				cost[it->first]=cost[nod]+it->second;
				T[it->first]=nod;
				if(!ut[it->first])
				{
					ut[it->first]=1;
					Q.push(it->first);
				}
			}
		}
	}
	return cost[END]==INF?0:1;
}
int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d%d%d",&n,&m,&e);
	START=0;END=m+n+1;
	for(i=1;i<=n;i++)
	{
		C[START][i]=1;
		g[START].push_back(p(i,0));
		g[i].push_back(p(START,0));
	}
	for(i=n+1;i<=n+m;i++)
	{
		C[i][END]=1;
		g[i].push_back(p(END,0));
		g[END].push_back(p(i,0));
	}
	for(i=1;i<=e;i++)
	{
		scanf("%d%d%d",&x,&y,&z);
		C[x][y+n]=1;
		g[x].push_back(p(y+n,z));
		g[y+n].push_back(p(x,-z));
	}
	while(dijkstra())
	{
		int flow=INF;
		for(i=END;i!=START;i=T[i])
			flow=min(flow,C[T[i]][i]-F[T[i]][i]);
		for(i=END;i!=START;i=T[i])
		{
			F[T[i]][i]+=flow;
			F[i][T[i]]-=flow;
		}
		++nr;
		c+=cost[END];
	}
	printf("%d %d\n",nr,c);
	freopen("cmcm.in","r",stdin);
	scanf("%d%d%d",&n,&m,&e);
	for(i=1;i<=e;i++)
	{
		scanf("%hd%hd%hd",&x,&y,&z);
		if(F[x][y+n])
			printf("%hd ",i);
	}
	return 0;
}
