#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
using pii = pair<int,int>;
#define eb emplace_back

const string TASK("cmcm");

ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");

const int N = 615, Inf = 1e9;
int cap[N][N], cost[N][N], flow[N][N];
int n, m, e, src, dest, cuplaj, ans;
int d[N], t[N];
vi g[N];
bitset<N> inq;
vector<pii> edges;

bool bfs() {
  inq.reset();
  fill(d + 1, d + n + m + 3, Inf);
  queue<int> q;
  q.push(src);
  inq[src] = 1;
  d[src] = 0;
  while (!q.empty()) {
    int u = q.front(); q.pop();
    inq[u] = 0;
    for (auto v : g[u])
      if (cap[u][v] - flow[u][v] > 0 && d[v] > d[u] + cost[u][v]) {
        d[v] = d[u] + cost[u][v];
        t[v] = u;
        if (!inq[v]) {
          q.push(v); inq[v] = 1;
        }
      }
  }
  if (d[dest] == Inf) return 0;
  int mflow = Inf;
  for (int u = dest; u != src; u = t[u]) {
    int v = t[u];
    mflow = min(mflow, cap[v][u] - flow[v][u]);
  }
  for (int u = dest; u != src; u = t[u]) {
    int v = t[u];
    flow[u][v] -= mflow;
    flow[v][u] += mflow;
  }
  cuplaj += mflow;
  ans += mflow * d[dest];
  return 1;
}

int32_t main() {
  fin >> n >> m >> e;
  for (int u, v, w, i = 1; i <= e; ++i) {
    fin >> u >> v >> w; v += n;
    edges.eb(u, v);
    cap[u][v] = 1;
    cost[u][v] = w;
    cost[v][u] = -w;
    g[u].eb(v); g[v].eb(u);
  }
  src = 0; dest = n + m + 1;
  for (int i = 1; i <= n; ++i) {
    cap[src][i] = 1;
    g[src].eb(i); g[i].eb(src);
  }
  for (int i = n + 1; i <= n + m + 1; ++i) {
    cap[i][dest] = 1;
    g[i].eb(dest); g[dest].eb(i);
  }
  while (bfs());
  fout << cuplaj << ' ' << ans << '\n';
  int i = 1;
  for (auto it : edges) {
    if (flow[it.first][it.second])
      fout << i << ' ';
    ++i;
  }
}
