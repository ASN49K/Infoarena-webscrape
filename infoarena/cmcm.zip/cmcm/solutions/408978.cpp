#include<stdio.h>
#include<queue>

using namespace std;
#define Nmax 640
#define inf 0x3f3f3f3f

struct nod
{
    int drum,cost;
    nod *urm;
} *l[Nmax];

int N,M,C[Nmax][Nmax],F[Nmax][Nmax];
int S,D;
int d[Nmax],p[Nmax],v[Nmax];

struct cmp
{
    bool operator()(int a,int b)
    {
        return (d[a] > d[b]);
    }
};
priority_queue <int, vector<int> ,cmp> Heap;

void add(nod *&,int,int);

void init()
{
    for(int i=1;i<=D;++i)
    {
        d[i]=inf;
        p[i]=0;
        v[i]=0;
    }
    for(;!Heap.empty();Heap.pop());
}

int dijkstra()
{
    init();
    d[S]=0;
    v[S]=1;
    Heap.push(S);

    int cur;
    for(;!Heap.empty();)
    {
        cur=Heap.top();
        v[cur]=0;
        Heap.pop();
        for(nod *t=l[cur]; t ; t=t->urm)
            if (d[t->drum] > d[cur] + t->cost && F[cur][t->drum])
            {
                d[t->drum] = d[cur] + t->cost;
                p[t->drum] = cur;
                if (!v[t->drum])
                    {
                    v[t->drum]=1;
                    Heap.push(t->drum);
                    }
            }
    }
    if (d[D]==inf)
        return 0;
    return 1;
}

void preinit()
{
    S=N+M+1;
    D=N+M+2;

    for(int i=1;i<=N;++i)
        {
        add(l[S],i,0);
        F[S][i]=1;
        }
    for(int j=1;j<=M;++j)
        {
        add(l[j+N],D,0);
        F[j+N][D]=1;
        }
}

void solve()
{
    int Cost=0,flow=0;
    preinit();
    for(; dijkstra() ;)
        {
        for(int t=D; t!=S ; t=p[t])
            {
            F[ p[t] ][t]--;
            F[t][ p[t] ]++;
            }
        Cost += d[D];
        ++flow;
        }

    printf("%d %d\n",flow,Cost);
    for(int i=1;i<=N;++i)
        for(int j=1;j<=M;++j)
            if (!F[i][j+N] && C[i][j+N])
                printf("%d ",C[i][j+N]);
    printf("\n");
}

void cit();

int main()
{
    cit();
    solve();
    return 0;
}

void add(nod *&inc,int info1,int info2)
{
    nod *p=new nod;
    p->drum=info1;
    p->cost=info2;
    p->urm=inc;
    inc=p;
}

void cit()
{
    int a,b,c,E;
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&N,&M,&E);
    for(int i=1;i<=E;++i)
        {
        scanf("%d%d%d",&a,&b,&c);
        C[a][b+N]=i;
        F[a][b+N]=1;
        add(l[a],b+N,c);
        add(l[b+N],a,-c);
        }
}
