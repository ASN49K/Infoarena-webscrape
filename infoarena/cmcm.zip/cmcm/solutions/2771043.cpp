#include <bits/stdc++.h>

using namespace std;
const int INF = 1e8;

struct NetworkSimplex {
  struct Edge { int a, b, c, k, f = 0; };

  int n;
  vector<int> pei, depth, dual;
  vector<Edge> E;
  vector<set<int>> tree;
  
  NetworkSimplex(int n) : 
    n(n), pei(n + 1, -1), depth(n + 1, 0), 
    dual(n + 1, 0), tree(n + 1) {}
  
  int AddEdge(int a, int b, int c, int k) {
    E.push_back({a, b, c, k});
    E.push_back({b, a, 0, -k});
    return E.size() - 2;
  }
  void upd(int ei) {
    dual[E[ei].b] = dual[E[ei].a] + E[ei].k;
    pei[E[ei].b] = (ei ^ 1);
    depth[E[ei].b] = 1 + depth[E[ei].a];
    dfs(E[ei].b);
  }
  void dfs(int node) {
    for (auto ei : tree[node]) 
      if (ei != pei[node]) 
        upd(ei);
  }
  template<typename CB> 
  void walk(int ei, CB&& cb) {
    cb(ei);
    int a = E[ei].a, b = E[ei].b;
    while (a != b) {
      if (depth[a] > depth[b]) 
        cb(pei[a]^1), a = E[pei[a]].b;
      else 
        cb(pei[b]), b = E[pei[b]].b;
    }
  }
  long long Compute(int x) {
    for (int i = 0; i < n; ++i) {
      int a = n, b = i, c = 1, k = -INF;
      if (i >= x) swap(a, b);
      int ei = AddEdge(a, b, c, k);
      tree[a].insert(ei);
      tree[b].insert(ei^1);
    }  
    dfs(n);
    
    long long answer = 0;
    int flow, cost, ein, eout, ptr = 0;
    const int B = n / 3 + 1;
    for (int z = 0; z < E.size() / B + 1; ++z) { 
      // Find negative cycle (round-robin). 
      pair<int, int> pin = {0, -1};
      for (int t = 0; t < B; ++t, (++ptr) %= E.size()) {
        auto& e = E[ptr];
        if (e.f < e.c) 
          pin = min(pin, make_pair(
              dual[e.a] + e.k - dual[e.b], ptr));
      }
      tie(cost, ein) = pin;
      if (cost == 0) continue;
      // Pivot around ein.
      pair<int, int> pout = {E[ein].c - E[ein].f, ein};
      walk(ein, [&](int ei) {
        pout = min(pout, make_pair(E[ei].c - E[ei].f, ei));
      });
      tie(flow, eout) = pout;
      walk(ein, [&](int ei) {
        E[ei].f += flow, E[ei^1].f -= flow;
      });
      tree[E[ein].a].insert(ein);
      tree[E[ein].b].insert(ein^1);
      tree[E[eout].a].erase(eout);
      tree[E[eout].b].erase(eout^1);
      upd(pei[E[eout].a] == eout ? ein : ein^1);
      // Update answer.
      answer += 1LL * flow * cost;
      z = -1;
    }
    return answer;
  }
};

int main() {
  ifstream cin("cmcm.in");
  ofstream cout("cmcm.out");

  int n, m, e; cin >> n >> m >> e;
  NetworkSimplex NS(n + m);
  for (int i = 0; i < e; ++i) {
    int a, b, c; cin >> a >> b >> c; --a; --b;
    assert(2 * i == NS.AddEdge(a, b + n, 1, c));
  }
  auto cost = NS.Compute(n);
  vector<int> sol;
  for (int i = 0; i < e; ++i)
    if (NS.E[2 * i].f > 0) {
      cost += 2 * INF;
      sol.push_back(i);
    }
  cout << sol.size() << " " << cost << endl;
  for (auto x : sol) cout << x + 1 << " ";
  cout << endl;
  return 0;
}

