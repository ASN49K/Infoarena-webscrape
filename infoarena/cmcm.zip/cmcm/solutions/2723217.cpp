#include <bits/stdc++.h>

using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

vector < pair < int , int > > v[310];
queue <int> q;
int N,maxflow,tata[310],cost_bell[310],cost[310][310],inCoada[310],cost_dijk[310],new_cost_bell[310],flux[310][310],C[310][310];
priority_queue < pair < int , int > , vector < pair < int , int > > , greater < pair < int , int > > > h;

void Bellman_Ford()
{
    int i;
    for(i=0;i<=N;i++)cost_bell[i]=INT_MAX/2;
    cost_bell[0]=0;q.push(0);inCoada[0]=1;
    while(!q.empty())
    {
        int nod=q.front();
        inCoada[nod]=0;
        q.pop();
        for(i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i].first;
            int cost_intre=cost[nod][vecin];
            if(cost_bell[vecin]>cost_bell[nod]+cost_intre && flux[nod][vecin]<C[nod][vecin])
            {
                cost_bell[vecin]=cost_bell[nod]+cost_intre;
                if(inCoada[vecin]==0)
                {
                    inCoada[vecin]=1;
                    q.push(vecin);
                }
            }
        }
    }
}

int Dijkstra()
{
    int i,nod,minflow;
    for(i=0;i<=N;i++)cost_dijk[i]=INT_MAX/2,new_cost_bell[i]=INT_MAX/2,tata[i]=-1;
    cost_dijk[0]=0;new_cost_bell[0]=0;h.push({0,0});

    while(!h.empty())
    {
        int nod=h.top().second;
        int cst=h.top().first;
        h.pop();

        if(cst>cost_dijk[nod])continue;

        for(i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i].first;
            int cost_intre=cost[nod][vecin]+cost_bell[nod]-cost_bell[vecin];
            if(cost_dijk[vecin]>cost_dijk[nod]+cost_intre && flux[nod][vecin]<C[nod][vecin])
            {
                cost_dijk[vecin]=cost_dijk[nod]+cost_intre;
                new_cost_bell[vecin]=new_cost_bell[nod]+cost[nod][vecin];
                tata[vecin]=nod;
                h.push({cost_dijk[vecin],vecin});
            }
        }
    }

    if(cost_dijk[N]==INT_MAX/2)return 0;

    maxflow+=new_cost_bell[N];

    nod=N;
    while(tata[nod]!=-1)
    {
        flux[tata[nod]][nod]++;
        flux[nod][tata[nod]]--;
        nod=tata[nod];
    }

    for(i=0;i<=N;i++)cost_bell[i]=new_cost_bell[i];
    return 1;
}

int n,m,e,i,x,y,z,j;
vector <int> sol;

int main()
{
    f>>n>>m>>e;
    for(i=1;i<=e;i++)
    {
        f>>x>>y>>z;
        y+=n;

        v[x].push_back({y,i});
        v[y].push_back({x,i});
        cost[x][y]=z;cost[y][x]=-z;
        C[x][y]=1;
    }

    N=n+m+1;
    for(i=1;i<=n;i++)
    {
        v[0].push_back({i,0});
        v[i].push_back({0,0});
        C[0][i]=1;
    }

    for(i=1;i<=m;i++)
    {
        v[i+n].push_back({N,0});
        v[N].push_back({i+n,0});
        C[i+n][N]=1;
    }

    Bellman_Ford();
    while(Dijkstra());

    for(i=1;i<=N;i++)
    {
        for(j=0;j<v[i].size();j++)
        {
            int vecin=v[i][j].first;
            if(flux[i][vecin]==1 && v[i][j].second!=0)
            {
                sol.push_back(v[i][j].second);
            }
        }
    }

    g<<sol.size()<<" "<<maxflow<<'\n';
    for(i=0;i<sol.size();i++)g<<sol[i]<<" ";
    return 0;
}
