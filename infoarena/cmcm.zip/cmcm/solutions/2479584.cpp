#include <fstream>
#include <vector>
#include <bitset>
#include <deque>
#define inf 1000000001

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int n, m, u, k, nod, tata, t[605], flux[603][605], nr, cap[603][605], d[605], e, i, a, b, c, cos[50001], minim, cost;
vector<int> SOL;
vector<pair<int, int> > v[605], muchii;
deque<int> coada;
bitset<605> f;

int bellmanford(){
    //f.reset();
    f[0] = 1;
    coada.push_back(0);
    d[0] = 0;
    t[0] = -1;
    int ok = 0;
    for(int i=1;i<=u;i++)
        d[i] = inf;
    while(!coada.empty()){
        int p = coada[0];
        coada.pop_front();
        f[p] = 0;
        for(int i = 0;i<v[p].size();i++){
            int vecin = v[p][i].first;
            int dist = v[p][i].second;
            if(d[vecin] > d[p] + dist && cap[p][vecin] > flux[p][vecin]){
                d[vecin] = d[p] + dist;
                t[vecin] = p;
                if(vecin == u)
                    ok = 1;
                if(f[vecin] == 0){
                    f[vecin] = 1;
                    coada.push_back(vecin);
                }
            }
        }
    }
    return ok;
}

int main(){
    fin>>n>>m>>e;
    u = n+m+1;
    for(i=0;i<e;i++){
        fin>>a>>b>>c;
        b += n;
        v[a].push_back(make_pair(b,c));
        v[b].push_back(make_pair(a,-c));
        cap[a][b] = 1;
        v[0].push_back(make_pair(a,0));
        cap[0][a] = 1;
        v[b].push_back(make_pair(u,0));
        cap[b][u] = 1;
        muchii.push_back(make_pair(a, b));
        cos[i] = c;
    }
    while(bellmanford()){
        nod = u, tata = t[u], minim = cap[tata][nod] - flux[tata][nod];
        while(tata != -1){
            minim = min(minim, cap[tata][nod] - flux[tata][nod]);
            nod = tata;
            tata = t[nod];
        }
        nod = u, tata = t[u];
        while(tata != -1){
            flux[tata][nod] += minim;
            flux[nod][tata] -= minim;
            nod = tata;
            tata = t[nod];
        }
    }

    for(i=0;i<muchii.size();i++){
        a = muchii[i].first;
        b = muchii[i].second;
        if(flux[a][b] == 1)
            nr++, SOL.push_back(i), cost += cos[i];
    }
    fout<<nr<<" "<<cost<<"\n";
    for(i=0;i<SOL.size();i++)
        fout<<SOL[i]+1<<" ";
    return 0;
}
