#include<fstream>
#include<vector>
#include<list>
#include<utility>
#define dmax 602
#define inf 0x3f3f3f3f
using namespace std;

ifstream fin ("cmcm.in");
ofstream fout("cmcm.out");
list<int> lista;
list<int>::iterator it;
vector< list<int> >l(dmax,lista);
int n,m,nrm,x,y,c,maxcuplaj,maxflow,i,j,s,d;
int dst[dmax],viz[dmax],que[dmax],dad[dmax];
int cap[dmax][dmax],flx[dmax][dmax],cost[dmax][dmax],muchii[dmax][dmax];

int bf()
{
    int ls=0,ld=0;
    for(i=0;i<=n+m+1;++i)
    {
        viz[i]=0;
        dad[i]=-1;
        dst[i]=inf;
    }
    viz[s]=1;
    dst[s]=0;
    que[0]=s;
    while(ls<=ld)
    {
        x=que[ls++];
        viz[x]=0;
        for(it=l[x].begin();it!=l[x].end();++it)
        {
            y=*it;
            c=cost[x][y];
            if(dst[y]>dst[x]+c && cap[x][y]>flx[x][y])
            {
                dst[y]=dst[x]+c;
                dad[y]=x;
                if(!viz[y])
                {
                    viz[y]=1;
                    que[++ld]=y;
                }
            }
        }
    }
    if(dst[d]==inf)
        return 0;
    int flux=inf;
    for(i=d;i>0;i=dad[i])
        flux=min(flux,cap[dad[i]][i]-flx[dad[i]][i]);
    for(i=d;i>0;i=dad[i])
    {
        flx[dad[i]][i]+=flux;
        flx[i][dad[i]]-=flux;
    }
    ++maxcuplaj;
    maxflow+=flux*dst[d];
    return 1;
}

int main()
{
    fin>>n>>m>>nrm;
    int k=0;
    for(;nrm--;)
    {
        fin>>x>>y>>c;
        y+=n;
        l[x].push_back(y);
        l[y].push_back(x);
        muchii[x][y]=++k;
        cost[x][y]=c;
        cost[y][x]=-c;
        cap[x][y]=1;
    }
    s=0;
    d=n+m+1;
    for(i=1;i<=n;++i)
    {
        l[s].push_back(i);
        l[i].push_back(s);
        cap[s][i]=1;
    }
    for(i=n+1;i<=n+m;++i)
    {
        l[i].push_back(d);
        l[d].push_back(i);
        cap[i][d]=1;
    }
    while(bf());
    fout<<maxcuplaj<<" "<<maxflow<<'\n';
    for(i=1;i<=n;++i)
        for(j=n+1;j<=n+m;++j)
            if(flx[i][j])
             fout<<muchii[i][j]<<" ";
    return 0;
}
