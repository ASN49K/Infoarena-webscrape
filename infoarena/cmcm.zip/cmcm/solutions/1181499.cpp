#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
#define MAX 310*2
#define INF 1<<29
#define pb push_back
typedef vector <int> :: iterator iter;
vector <int> G[MAX];
queue <int> Q;

int inQ[MAX], i, n, m, dist[MAX], nod, F[MAX][MAX], C[MAX][MAX], cs[MAX][MAX], dad[MAX], minim, flux, edge[MAX][MAX], a[MAX];

int bellford()
{
    Q.push(0);
    inQ[0]=1;
    dist[0]=0;
    for(i=1;i<=n+m+1;i++)
        dist[i]=INF;
    while(Q.size())
    {
        nod=Q.front();

        Q.pop();

        for(iter it=G[nod].begin();it!=G[nod].end();it++)
        {

            if(F[nod][*it]!=C[nod][*it])
            {
                if(dist[*it]>dist[nod]+cs[nod][*it])
                {
                    dist[*it]=dist[nod]+cs[nod][*it];
                    dad[*it]=nod;
                    if(!inQ[*it])
                    {
                        Q.push(*it);
                        inQ[*it]=1;
                    }
                }
            }
        }
        inQ[nod]=0;
    }
    if(dist[n+m+1]==INF)
        return 0;
    minim=INF;
    for(i=n+m+1;i;i=dad[i])
    {
        minim=min(minim, C[dad[i]][i]-F[dad[i]][i]);
    }

    for(i=n+m+1;i;i=dad[i])
    {
        F[dad[i]][i]+=minim;
        F[i][dad[i]]-=minim;
    }

    flux+=minim*dist[m+n+1];

    return 1;
}

int main()
{
    int e, x, y, c, s;
    fin>>n>>m>>e;
    for(i=1;i<=e;i++)
    {
        fin>>x>>y>>c;
        y+=n;
        edge[x][y]=i;
        cs[x][y]=c;
        cs[y][x]=-c;
        C[x][y]=1;
        G[x].pb(y);
        G[y].pb(x);
    }
    for(i=1;i<=n;i++)
    {
        C[0][i]=1;
        G[0].pb(i);
        G[i].pb(0);
    }
    for(i=n+1;i<=n+m;i++)
    {
        C[i][n+m+1]=1;
        G[i].pb(n+m+1);
        G[n+m+1].pb(i);
    }
    while(bellford());
    c=0;
    for(i=1;i<=n;i++)
    {
        for(iter it=G[i].begin();it!=G[i].end();it++)
        {
            if(F[i][*it]>0)
            {
                a[++c]=edge[i][*it];
            }
        }
    }
    fout<<c<<" ";
    fout<<flux<<"\n";
    for(i=1;i<=c;i++)
    {
        fout<<a[i]<<" ";
    }
}
