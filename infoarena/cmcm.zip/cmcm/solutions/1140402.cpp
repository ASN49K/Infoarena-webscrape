#include <cstdio>
#include <algorithm>
#include <vector>
#include <queue>
#include <bitset>
#include <cstring>

#define Nmax 607
#define INF 0x3f3f3f3f
#define start 0
#define sink L+R+1

using namespace std;
int L,R,M,minFLOW,maxFLOW,minCOST;
int DP[Nmax],daddy[Nmax];
int flow[Nmax][Nmax],capacity[Nmax][Nmax],cost[Nmax][Nmax];
unsigned short muchie[Nmax][Nmax];

vector<int> G[Nmax];
queue<int> Q;
bitset<Nmax>inQ;

inline void read()
{
    int a,b,c;
    scanf("%d%d%d",&L,&R,&M);
    for(int i = 1; i <= M; ++i)
    {
        scanf("%d%d%d",&a,&b,&c);
        b += L;
        muchie[a][b] = i;
        G[a].push_back(b);
        G[b].push_back(a);
        capacity[a][b] = 1;
        cost[a][b] = c;
        cost[b][a] = -c;
    }
    for(int i = 1; i <= L; ++i)
    {
        G[start].push_back(i); /// super start
        G[i].push_back(start);
        capacity[start][i] = 1;
    }
    for(int i = L+1; i <= R+L; ++i)
    {
        G[sink].push_back(i); /// super sink
        G[i].push_back(sink);
        capacity[i][sink] = 1;
    }
}

inline bool BF(int k){
    memset(DP,INF,sizeof(DP));
    DP[k] = 0; Q.push(k);
    while(!Q.empty()){
            k  = Q.front(); inQ[k] = 0;Q.pop();
            if(k == sink) continue;
            for(vector<int>::iterator it = G[k].begin(); it != G[k].end(); ++it)
                if(DP[*it] > DP[k] + cost[k][*it] &&capacity[k][*it] - flow[k][*it] != 0){
                    DP[*it] = DP[k] + cost[k][*it];
                    daddy[*it] = k;
                    if(inQ[*it]) continue;
                    inQ[*it] = 1;Q.push(*it);
                }
    }
    return DP[sink] != INF;
}

inline void FLOW()
{
    while(BF(start))
    {
        minFLOW = INF;
        if(DP[sink] == INF) continue;
        for(int nodc = sink;nodc;nodc = daddy[nodc])
            minFLOW = min(minFLOW , capacity[daddy[nodc]][nodc] - flow[daddy[nodc]][nodc]);
        for(int nodc = sink;nodc;nodc = daddy[nodc])
        {
            flow[daddy[nodc]][nodc] += minFLOW;
            flow[nodc][daddy[nodc]] -= minFLOW;
        }
        maxFLOW += minFLOW;
        minCOST += DP[sink];
    }
}

inline void print()
{
    printf("%d %d\n",maxFLOW,minCOST);
    for(int i = 1; i < sink; ++i)
        for(int j = i + 1; j < sink ; ++j)
            if(flow[i][j]) printf("%d ",muchie[i][j]);
}

int main()
{
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);

    read();
    FLOW();
    print();

    return 0;
}
