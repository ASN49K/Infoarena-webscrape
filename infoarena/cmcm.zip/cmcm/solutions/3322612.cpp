#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
struct elem{
	int x, dst;
};
struct muchie{
	int x, y;
};
struct comp{
	bool operator()( elem a, elem b ){
		return a.dst > b.dst;
	}
};
int cap[605][605], flow[605][605], cost[605][605], bellman[605], aux_bellman[605], dist[605], t[605], in_q[605], min_cost = 0, max_flow = 0, n, s, d;
vector <muchie> muchii;
vector <int> v[605];
bool maxflow(){
	int i, x, y, dst, ok, min_flow;
	priority_queue <elem, vector <elem>, comp> q;
	for( i = 0; i <= n; i++ ){
		bellman[i] = aux_bellman[i];
		aux_bellman[i] = dist[i] = INT32_MAX / 3;
	}
	aux_bellman[s] = dist[s] = ok = 0;
	q.push( { s, 0 } );
	while( q.empty() == false ){
		x = q.top().x;
		dst = q.top().dst;
		q.pop();
		if( x == d ){
			ok = 1;
		}
		//cout << x << ' ' << dst << '\n';
		if( dst != dist[x] ){
			continue;
		}
		//cout << x << ' ' << d << '\n';
		for( i = 0; i < v[x].size(); i++ ){
			y = v[x][i];
			//cout << x << ' ' << y << ' ' << ( flow[x][y] < cap[x][y] ) << ' ' << ( dist[x] + cost[x][y] + bellman[y] - bellman[x] < dist[y] ) << '\n';
			if( flow[x][y] < cap[x][y] && dist[x] + cost[x][y] + bellman[y] - bellman[x] < dist[y] ){
				dist[y] = dist[x] + cost[x][y] + bellman[y] - bellman[x];
				t[y] = x;
				aux_bellman[y] = aux_bellman[x] + cost[x][y];
				q.push( { y, dist[y] } );
			}
		}
	}
	if( ok == 0 ){
		return false;
	}
	min_flow = INT32_MAX;
	x = d;
	while( x != s ){
		min_flow = min( cap[t[x]][x] - flow[t[x]][x], min_flow );
		x = t[x];
	}
	min_cost += min_flow * aux_bellman[d];
	max_flow += min_flow;
	//cout << min_flow << ' ' << aux_bellman[d] << '\n';
	x = d;
	while( x != s ){
		flow[t[x]][x] += min_flow;
		flow[x][t[x]] -= min_flow;
		x = t[x];
	}
	return true;
}
int main() {
	int a, b, e, i, x, y, c;
	ifstream fin( "cmcm.in" );
	ofstream fout( "cmcm.out" );
	fin >> a >> b >> e;
	for( i = 0; i < e; i++ ){
		fin >> x >> y >> c;
		muchii.push_back( { x, y } );
		y += a;
		//cout << x << ' ' << y << ' ' << c << '\n';
		v[x].push_back( y );
		v[y].push_back( x );
		cap[x][y] = 1;
		cost[x][y] = c;
		cost[y][x] = -c;
	}
	n = a + b + 1;
	s = 0;
	d = n;
	for( i = 1; i <= a; i++ ){
		v[0].push_back( i );
		v[i].push_back( 0 );
		cap[0][i] = 1;
	}
	for( i = a + 1; i < n; i++ ){
		v[i].push_back( n );
		v[n].push_back( i );
		cap[i][n] = 1;
	}
	for( i = 0; i <= n; i++ ){
		aux_bellman[i] = INT32_MAX / 3;
	}
	queue <int> q;
	aux_bellman[s] = 0;
	q.push( s );
	while( q.empty() == false ){
		x = q.front();
		q.pop();
		in_q[x] = 0;
		//cout << x << '\n';
		for( i = 0; i < v[x].size(); i++ ){
			y = v[x][i];
			if( aux_bellman[x] + cost[x][y] < aux_bellman[y] && cap[x][y] > 0 ){
				aux_bellman[y] = aux_bellman[x] + cost[x][y];
				if( in_q[y] == 0 ){
					q.push( y );
					in_q[y] = 1;
				}
			}
		}
	}
	while( maxflow() == true );
	fout << max_flow << ' ' << min_cost << '\n';
	for( i = 0; i < e; i++ ){
		if( flow[muchii[i].x][muchii[i].y + a] == 1 ){
			fout << i + 1 << ' ';
		}
	}
	return 0;
}