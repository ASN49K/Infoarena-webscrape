#include <fstream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

#define oo 0x3f3f3f3f

using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

vector<int>g[610];
queue<int>q;
bool vis[610];
int dst[610], cst[610][610], c[610][610], t[610], cmin, sol, s, d, n, m, e, x, y, cost, mem[610][610], f[610][610];

inline bool BellmanFord()
{
    q.push(s);
    for(int i = 1; i<= d; i++ )
        dst[i]=oo;
    vis[s]=1;
    dst[s]=0;
    while(!q.empty())
    {
        int x=q.front(); q.pop();
        for(vector<int>::iterator it=g[x].begin(); it<g[x].end(); it++ )
        {
            if(dst[x]+cst[x][*it]<dst[*it] && c[x][*it]>f[x][*it])
            {
                dst[*it]=dst[x]+cst[x][*it];
                t[*it]=x;
                if(!vis[*it])
                {
                    vis[*it]=1;
                    q.push(*it);
                }
            }
        }
        vis[x]=0;
    }
    return (dst[d]!=oo);
}

int main()
{
    fin>>n>>m>>e;
    int dt=n+m+1;
    for(int i = 1; i<= e; i++ )
    {
        fin>>x>>y>>cost;
        y+=n;
        g[x].push_back(y);
        g[y].push_back(x);
        cst[x][y]=cost;
        cst[y][x]=-cost;
        c[x][y]=1;
        mem[x][y]=i;
    }
    s=0;
    d=dt;
    for(int i = 1; i<= n; i++ )
    {
        g[s].push_back(i);
        c[s][i]=1;

    }
    for(int i = n+1; i< dt; i++ )
    {
        g[i].push_back(d);
        c[i][d]=1;
    }
    while(BellmanFord())
    {
        for(int x = d; x != s; x=t[x] )
            f[t[x]][x]++, f[x][t[x]]--;
        sol++;
        cmin+=dst[d];
    }
    fout<<sol<<' '<<cmin<<'\n';
    for(int i = 1; i<= n; i++ )
        for(int j = n+1; j< d; j++ )
        {
            if(f[i][j]>0)
                fout<<mem[i][j]<<' ';
        }
    fin.close();
    fout.close();
    return 0;
}
