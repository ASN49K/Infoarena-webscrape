#include<bits/stdc++.h>
using namespace std;

typedef struct edg {
    int nod,cost,cap,flow,last,nr;
}Edge;

const int INF=1e9+69*69;

int i,n,m,e,x,y,cost,flow,rs,q[605],qt,qh,poz[605],tata[605],d[605],id[605];
vector<Edge> g[605];

void add(int x,int y,int cost,int nr) {
    Edge r1={y,cost,1,0,(int)g[y].size(),nr};
    Edge r2={x,-cost,0,0,(int)g[x].size(),0};

    g[x].push_back(r1);
    g[y].push_back(r2);
}

int Update() {
    int addflow=INF;

    for(x=n+m+1;x;x=tata[x])
    {
      int p=tata[x],pos=poz[x];
      addflow=min(addflow,g[p][pos].cap-g[p][pos].flow);
    }

    for(x=n+m+1;x;x=tata[x])
    {
      int p=tata[x],pos=poz[x];
      int rev=g[p][pos].last;

      g[p][pos].flow+=addflow;
      g[x][rev].flow-=addflow;
      rs+=g[p][pos].cost;
    }

    return addflow;
}

int main()
{
  ifstream cin("cmcm.in");
  ofstream cout("cmcm.out");

  ios_base::sync_with_stdio(0); cin.tie(0);

  cin>>n>>m>>e;
  for(i=1;i<=e;++i)
  {
    cin>>x>>y>>cost;
    add(x,n+y,cost,i);
  }

  for(i=1;i<=n;++i) add(0,i,0,0);
  for(i=1;i<=m;++i) add(n+i,n+m+1,0,0);

  while(1)
  {
    for(i=0;i<=n+m+1;++i) id[i]=0,d[i]=INF;

    qt=qh=0; q[qt++]=0; d[0]=0;
    while(qh!=qt)
    {
      x=q[qh++]; id[x]=2;
      if(qh==n+m+2) qh=0;

      for(i=0;i<(int)g[x].size();++i)
      {
        Edge &r=g[x][i];

        if(r.flow<r.cap && d[r.nod]>d[x]+r.cost)
        {
          d[r.nod]=d[x]+r.cost;

          if(!id[r.nod])
          {
            q[qt++]=r.nod;
            if(qt==n+m+2) qt=0;
          }
          else if(id[r.nod]==2)
               {
                 if(--qh==-1) qh=n+m+1;
                 q[qh]=r.nod;
               }

          id[r.nod]=1; tata[r.nod]=x; poz[r.nod]=i;
        }
      }
    }

    if(d[n+m+1]==INF) break;

    flow+=Update();
  }

  cout<<flow<<' '<<rs<<'\n';
  for(i=1;i<=n;++i)
   for(auto it:g[i])
   if(it.flow && it.nr) cout<<it.nr<<' ';

 return 0;
}
