// http://infoarena.ro/problema/cmcm
#include <fstream>
#include <cstring>
#include <map>
#include <vector>
#include <queue>
using namespace std;

#define to first
#define cost second

const int maxSize = 611;
const int oo = 0x3f3f3f3f;
const int source = 0;
const int sink = 610;

ifstream in("cmcm.in");
ofstream out("cmcm.out");

int firstSize,secondSize,edges;
bool visit[maxSize];
int father[maxSize];
int dist[maxSize];
int edge[maxSize][maxSize];
//int cost[maxSize][maxSize];
int capacity[maxSize][maxSize];
int currentFlow[maxSize][maxSize];
vector< pair<int,int> > graph[maxSize];

bool bellmanFord();

int main() {
    in >> firstSize >> secondSize >> edges;

    int from,to,currentCost;
    for(int i=1;i<=edges;i++) {
        in >> from >> to >> currentCost;
        to += firstSize;

        graph[from].push_back(make_pair(to,currentCost));
        graph[to].push_back(make_pair(from,-currentCost));

        //cost[from][to] = currentCost;
        //cost[to][from] = -currentCost;

        capacity[from][to] = 1;
        edge[from][to] = i;
    }

    for(int i=1;i<=firstSize;i++) {
        graph[source].push_back(make_pair(i,0));
        graph[i].push_back(make_pair(source,0));
        capacity[source][i] = 1;
    }

    for(int i=firstSize+1;i<=firstSize+secondSize;i++) {
        graph[i].push_back(make_pair(sink,0));
        graph[sink].push_back(make_pair(i,0));
        capacity[i][sink] = 1;
    }

    int maxFlow = 0;
    while(bellmanFord()) {
        int minFlow = oo;
        for(int node=sink;node!=source;node=father[node])
            minFlow = min(minFlow,capacity[father[node]][node] - currentFlow[father[node]][node]);

        for(int node=sink;node!=source;node=father[node]) {
            currentFlow[father[node]][node] += minFlow;
            currentFlow[node][father[node]] -= minFlow;
        }

        maxFlow += minFlow * dist[sink];
    }

    int tmp = 0;
    for(int f=1;f<=firstSize;f++)
        for(int s=firstSize+1;s<=firstSize+secondSize;s++)
            if(capacity[f][s] && currentFlow[f][s])
                tmp++;

    out << tmp << " " << maxFlow << "\n";

    for(int f=1;f<=firstSize;f++)
        for(int s=firstSize+1;s<=firstSize+secondSize;s++)
            if(capacity[f][s] && currentFlow[f][s]) {
                out << edge[f][s] << " ";
            }
    out << "\n";

    in.close();
    out.close();

    return (0);
}

bool bellmanFord() {
    memset(visit,false,sizeof(visit));
    visit[source] = true;

    memset(dist,oo,sizeof(dist));
    dist[source] = 0;

    int node;
    vector< pair<int,int> >::iterator it,end;

    queue<int> myQueue;
    myQueue.push(source);

    while(!myQueue.empty()) {
        node = myQueue.front();
        myQueue.pop();

        end = graph[node].end();
        for(it=graph[node].begin();it!=end;++it)
            if(capacity[node][it->to] > currentFlow[node][it->to] && dist[it->to] > dist[node] + it->cost) {
                dist[it->to] = dist[node] + it->cost;
                father[it->to] = node;

                if(!visit[it->to]) {
                    myQueue.push(it->to);
                    visit[it->to] = true;
                }
            }

        visit[node] = false;
    }

    return (dist[sink] != oo);
}
