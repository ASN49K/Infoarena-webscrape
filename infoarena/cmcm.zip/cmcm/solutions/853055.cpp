#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <stack>
#include <cassert>
using namespace std;

#define PRO "cmcm"
void OpenFiles(int EVAL)
{
	if(EVAL)
	{
		char input[100] = PRO, output[100] = PRO;
		freopen(strcat(input, ".in"),"r",stdin);
		freopen(strcat(output,".out"),"w",stdout);
	} else
	{
		freopen("test.in","r",stdin);
		freopen("test.out","w",stdout);
	}
}

#define MAX  650
#define INF 0xffffff
#define EPS 1E-8

int s,d,n,m,c[MAX][MAX],f[MAX][MAX],tt[MAX],cst[MAX][MAX],dst[MAX],o[MAX][MAX];
vector<int>g[MAX];
set<int>s1,s2;

int bfs()
{
	int x,y;
	for(int i=1;i<=d;i++)
	{
		dst[i] = INF;
		tt[i] = 0;
	}
	dst[s] = 0;
	s1.insert(s);
	for(int k=1;k<=d;k++)
	{
		while(s1.size())
		{
			x = *s1.begin();
			s1.erase(s1.begin());
			for(int i=0;i<g[x].size();i++)
			{
				y=g[x][i];
				if(dst[y] > dst[x] + cst[x][y] && c[x][y] > f[x][y])
				{
					dst[y] = dst[x] + cst[x][y];
					tt[y] = x;
					if(y!=d)s2.insert(y);
				}
			}
		}
		swap(s1,s2);
	}
	return tt[d];
}

void maxflow()
{
	int fm = 0,cm = 0,flux;
	while( bfs() )
	{
		flux = INF;
		for(int x=d;x!=s;x=tt[x])flux = min(flux,c[tt[x]][x]-f[tt[x]][x]);
		if(flux!=0)
		for(int x=d;x!=s;x=tt[x])
		{
			f[tt[x]][x]+=flux;
			f[x][tt[x]]-=flux;
			cm += flux * cst[tt[x]][x];
		}
		fm += flux;
	}
	printf("%d %d\n",fm,cm);
	for(int i=2;i<d;i++)
	{
		for(int j=2;j<d;j++)
			if(f[i][j]>0)printf("%d ",o[i][j]);
			//printf("%d ",f[i][j]); printf("\n");
	}
}

int main(int argv,char *args[])
{
	OpenFiles(argv==0);
	// start
	int e,x,y,z;
		scanf("%d %d %d",&n,&m,&e);
		s = 1; 
		d = n + m + 2;
		for(int i=1;i<=e;i++)
		{
			scanf("%d %d %d",&x,&y,&z);
			x += 1;
			y += n + 1;
			c[x][y] = 1;
			cst[x][y] = z;
			cst[y][x] = -z;
			g[x].push_back(y);
			g[y].push_back(x);
			o[x][y] = i;
			if(!c[s][x])
			{
				c[s][x] = 1;
				g[s].push_back(x);
				g[x].push_back(s);
			}
			if(!c[y][d])
			{
				c[y][d] = 1;
				g[y].push_back(d);
				g[d].push_back(y);
			}
		}
		maxflow();
	return 0;
}
