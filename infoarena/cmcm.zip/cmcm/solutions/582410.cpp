#include<stdio.h>
#include<vector>
#include<algorithm>
#include <fstream>
#define INF 0x3f3f3f3f
#define Nmx 605
#define pb push_back
#define mp make_pair


using namespace std;

int n,m,T,dest,prec[Nmx],dist[Nmx],viz[Nmx];
int C[Nmx][Nmx],F[Nmx][Nmx];
int cupl=0,sol=0;
int Q[Nmx*Nmx];
vector < pair<int,int> > G[Nmx];
vector < pair<int,int> > G1;

void citire()
{
    ifstream fin("cmcm.in");
    fin>>n>>m>>T;
    dest=n+m+2;
    int x,y,c;
    for(int i=1;i<=T;++i)
    {
        fin>>x>>y>>c;
        x++;y=y+n+1;
        G1.pb(mp(x,y));
        C[x][y]=C[1][x]=C[y][dest]=1;
        G[x].pb(mp(1,0));
        G[1].pb(mp(x,0));
        G[x].pb(mp(y,c));
        G[y].pb(mp(x,-c));
        G[y].pb(mp(dest,0));
        G[dest].pb(mp(y,0));
    }
}

int belmand()
{
    vector<pair <int,int> >:: iterator it;
    int st,dr,nod;
    for(int i=2;i<=dest;++i)
        dist[i]=INF;
    Q[st=dr=1]=1;
    for(dist[1]=0;st<=dr;)
    {
        nod=Q[st];
        for(it=G[nod].begin();it!=G[nod].end();++it)
            if(C[nod][it->first]-F[nod][it->first]>0&&dist[nod]+it->second<dist[it->first])
            {
                dist[it->first]=dist[nod]+it->second;
                prec[it->first]=nod;
                if(!viz[it->first])
                {
                    viz[it->first]=1;
                    Q[++dr]=it->first;
                }
            }
        viz[Q[st+1]]=0;
        ++st;
    }
    if (dist[dest] < INF) {
        int flux = INF;
        for (int i = dest; i != 1; i = prec[i])
            flux = min(flux, C[prec[i]][i] - F[prec[i]][i]);
        for (int i = dest; i != 1; i = prec[i]) {
            F[prec[i]][i] += flux;
            F[i][prec[i]] -= flux;
        }
        return flux * dist[dest];
    }
    return 0;
}

void flux()
{

    while(belmand())
    {
        ++cupl;
        sol+=dist[dest];
    }

}

void afisare()
{
    freopen("cmcm.out","w",stdout);
    vector < pair<int,int> > :: iterator it;
    int i=1;
    printf("%d %d\n",cupl,sol);
    for(it=G1.begin();it!=G1.end();++it,++i)
        if(F[it->first][it->second])
            printf("%d ",i);
    printf("\n");
}


int main()
{
    citire();
    flux();
    afisare();
    return 0;
}
