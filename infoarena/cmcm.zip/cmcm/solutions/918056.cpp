//HighFlow
#include <cstdio>
#include <list>
#include <vector>
#include <string>
#include <bitset>
#include <queue>
#include <fstream>
#include <string.h>
#include <math.h>
#include <algorithm>
#define fcat(c) while (c!='\n') fscanf(f,"%c",&c)
#define cat(c) while (c!='\n') scanf("%c",&c)
#define For(i,st,dr,k) for (int i=(st);i<=(dr);i+=(k))
#define ll (long long)
#define kfl(i,j) (a[(i)][(j)].c-a[(i)][(j)].f)
#define NN 620
#define INF 100000000
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
struct cp{int f,c,z,ind;
            cp() {};
            cp(int A,int B,int C,int D)
            {f=A; c=B; z=C; ind=D; };};
int Dist[NN],Q[NN],R[NN],TT[NN];
bool in_q[NN];
queue <int> q;
int N,MM,E;
int flux,ans,sum;
cp a[NN][NN];
list <int> M[620];
int st,dr;

inline void fa_muchie(int x,int y,int cap,int cost,int ind)
{
    a[x][y]=cp(0,cap,cost,ind);
    a[y][x]=cp(0,0,-cost,-1);
    M[x].push_back(y);
    M[y].push_back(x);
}

void read()
{
    int i,x,y,z;
    f>>N>>MM>>E;

    st=1; dr=N+MM+2;
    for (i=1;i<=E;i++)
    {
       f>>x>>y>>z;
        fa_muchie(x+1,y+1+N,1,z,i);
    }
    for (i=1;i<=N;i++)
        fa_muchie(1,i+1,1,0,-1);
    for (i=1;i<=MM;i++)
        fa_muchie(i+1+N,dr,1,0,-1);
}

int bellman()
{
    int i,x,mn;
    list <int>::iterator it;


    for (i=1;i<=dr;i++)
        Dist[i]=INF;


    Dist[st]=0;
    q.push(st);
    while (q.size()>0)
    {
        x=q.front();
        in_q[x]=false;
        q.pop();
        if (Dist[x]==INF) break;

        for (it=M[x].begin();it!=M[x].end();it++)
            if (kfl(x,*it)>0 && Dist[x]+a[x][*it].z +Q[x]-Q[*it]<Dist[*it])
            {
                Dist[*it]=Dist[x]+a[x][*it].z +Q[x]-Q[*it];
                R[*it]=R[x]+a[x][*it].z;
                TT[*it]=x;
                if (!in_q[*it])
                {
                    in_q[*it]=true;
                    q.push(*it);
                }
            }
    }
     memcpy(Q,R,sizeof(R));


    if (Dist[dr]==INF) return 0;

    for (mn=INF,x=dr;x!=st;x=TT[x]) mn=min(mn,kfl(TT[x],x));
    for (x=dr;x!=st;x=TT[x])
    {
        a[TT[x]][x].f+=mn;
        a[x][TT[x]].f-=mn;
    }
    sum+=Dist[dr];
    ans+=sum*mn;
    flux+=mn;
    return 1;
}

void solve()
{
    int i,j;

    while (bellman());
    g<<flux<<' '<<ans<<'\n';
    for (i=2;i<=N+1;i++)
        for (j=N+2;j<dr;j++)
            if (kfl(i,j)==0 && a[i][j].ind>=1)
                g<<a[i][j].ind<<" ";

}



int main()
{
    read();
    solve();

	return 0;
}
