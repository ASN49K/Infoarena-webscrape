#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#define DIM 700
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int i,l,r,x,y,z1,c[DIM][DIM],z[DIM][DIM],flux[DIM][DIM],f[DIM],D[DIM],ok,dst,T[DIM],m,sol,muchie[DIM][DIM],s[DIM],muchii;
queue<int> q;
vector<int> L[DIM];
int ford(){
    for(i=1;i<=l+r+1;i++){
        f[i]=0;
        D[i]=INT_MAX;
    }
    D[0]=f[dst]=ok=0;
    f[0]=1;
    D[dst]=INT_MAX;
    q.push(0);
    while(!q.empty()){
        int nod=q.front();
        q.pop();
        f[nod]=0;
        for(int i=0;i<L[nod].size();i++){
            int vec=L[nod][i];
            int cost=c[nod][vec];
            if(D[vec]>D[nod]+cost&&z[nod][vec]>flux[nod][vec]){
                D[vec]=D[nod]+cost;
                if(f[vec]==0){
                    f[vec]=1;
                    q.push(vec);
                    if(vec==dst)
                        ok=1;
                }
                T[vec]=nod;
            }
        }
    }
    return ok;
}
int main(){
    fin>>l>>r>>m;
    for(i=1;i<=m;i++){
        fin>>x>>y>>z1;
        L[x].push_back(l+y);
        L[l+y].push_back(x);
        c[x][l+y]=z1;
        c[l+y][x]=-z1;
        z[x][l+y]=1;
        muchie[x][l+y]=i;
    }
    for(i=1;i<=l;i++){
        L[0].push_back(i);
        L[i].push_back(0);
        z[0][i]=1;
    }
    dst=630;
    for(i=1;i<=r;i++){
        L[dst].push_back(l+i);
        L[l+i].push_back(dst);
        z[l+i][dst]=1;
    }
    while(ford()){
        int nod=dst;
        while(nod!=0){
            flux[T[nod]][nod]++;
            flux[nod][T[nod]]--;
            nod=T[nod];
        }
        sol+=D[dst];
    }
    for(i=1;i<=l;i++)
        for(int j=1;j<=r;j++)
            if(flux[i][l+j]){
               muchii++;
               s[muchii]=muchie[i][l+j];
            }
    fout<<muchii<<" "<<sol<<"\n";
    for(i=1;i<=muchii;i++)
        fout<<s[i]<<" ";
    return 0;
}
