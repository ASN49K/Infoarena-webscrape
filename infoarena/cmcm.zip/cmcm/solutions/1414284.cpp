#include <cstdio>
#include <queue>
#include <cstring>

FILE* in=fopen("cmcm.in","r");
FILE* out=fopen("cmcm.out","w");

const int Q=700,W=50007,INF=2000000000;

int v[Q][Q],f[Q][Q],init[Q][Q];

int X,Y,m;

int lst[Q],val[2*W],nxt[2*W],cost[2*W],nr;

int dad[Q];

void fill()
{
    int act=X+Y+1;

    while(act)
    {
        f[dad[act]][act]=1;
        f[act][dad[act]]=-1;

        act=dad[act];
    }
}

int ap[Q];

struct tipe
{
    int nod,val;
};

std::queue<tipe> q;

int dist[Q];

void belman()
{
    memset(ap,0,sizeof ap);
    memset(dad,0,sizeof dad);
    while(!q.empty())
        q.pop();

    q.push(tipe{0,0});

    ap[0]=1;

    for(int i=1; i<=X+Y+1; i++)
        dist[i]=INF;

    tipe act;

    while(!q.empty())
    {
        act=q.front();
        q.pop();
        if(act.val!=dist[act.nod])
            continue;

        for(int p=lst[act.nod]; p; p=nxt[p])
        {
            if(v[act.nod][val[p]]-f[act.nod][val[p]]>0  && dist[val[p]] > act.val+cost[p])
            {
                dist[val[p]]=act.val+cost[p];
                ap[val[p]]++;
                if(ap[val[p]]==X+Y+1)
                    return;

                dad[val[p]]=act.nod;


              //  if(val[p]==X+Y+1)
              //      return;

                q.push(tipe{val[p],dist[val[p]]});
            }
        }
    }
}


void add(int a, int b, int c)
{
    nr++;
    val[nr]=b;
    cost[nr]=c;
    nxt[nr]=lst[a];
    lst[a]=nr;
}


int main()
{
    fscanf(in,"%d%d%d",&X,&Y,&m);

    int a,b,c;

    for(int i=1; i<=m; i++)
    {
        fscanf(in,"%d%d%d",&a,&b,&c);

        b+=X;

        v[a][b]=1;
        init[a][b]=i;

        add(a,b,c);
        add(b,a,c);
    }

    for(int i=1; i<=X; i++)
    {
        v[0][i]=1;

        add(0,i,0);
    }

    for(int i=X+1; i<=X+Y; i++)
    {
        v[i][X+Y+1]=1;
        add(i,X+Y+1,0);
    }

    while(true)
    {
        belman();

        if(dad[X+Y+1]==0)
            break;

        fill();
    }

    int nr=0,cc=0;

    for(int i=X+1; i<=X+Y; i++)
    {
        for(int j=1; j<=X; j++)
        {
            if(f[j][i]==1)
            {
                nr++;
                for(int p=lst[j]; p; p=nxt[p])
                {
                    if(val[p]==i)
                    {
                        cc+=cost[p];
                        break;
                    }
                }
            }
        }
    }

    fprintf(out,"%d %d\n",nr,cc);

    for(int i=X+1; i<=X+Y; i++)
    {
        for(int j=1; j<=X; j++)
        {
            if(f[j][i]==1)
            {
                fprintf(out,"%d ",init[j][i]);
            }
        }
    }

    return 0;
}
