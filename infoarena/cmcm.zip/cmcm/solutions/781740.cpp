#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#include <set>
using namespace std;
#define Max 751
#define Inf 0xffffff

vector<int>g[Max];
set<int>b,v;
int n,m,s,d,dst[Max],c[Max][Max],pr[Max][Max],f[Max][Max],tt[Max],u[Max][Max];
bool was[Max];

bool bfs(){
    int p,u,x,y;
    for(int i=1;i<=n+m+2;i++)
    {
        was[i] = 0;
        dst[i] = Inf;
    }
    was[s] = 1;
    dst[s] = 0;
    b.clear(); v.clear();
    b.insert(s);

    for(int k=1;k<=n+m+2;k++)
    {
        while(b.size()>0)
        {
            x = *b.begin(); b.erase(b.begin());
            for(int i=0;i<g[x].size();i++)
            {
                y = g[x][i];
                if( dst[y] > dst[x] + pr[x][y] && c[x][y] > f[x][y] )
                {
                    dst[y] = dst[x] + pr[x][y];
                    tt[y] = x;
                    was[y] = 1;
                    if(y != d)v.insert(y);
                }
            }
        }
        swap(b,v);
    }
    return was[d];
}

void fmcm(){
    int cost_min = 0, flux , flux_max = 0;

    while( bfs() )
    {
        flux = Inf;
        for(int x = d;x != s;x = tt[x]) flux = min(flux, c[tt[x]][x]-f[tt[x]][x]);
        if( flux != 0)
        {
            for(int x = d; x!= s; x= tt[x])
            {
                f[tt[x]][x] += flux;
                f[x][tt[x]] -= flux;
                cost_min += flux * pr[tt[x]][x];
            }
            flux_max += flux;
        }
    }
    printf("%d %d\n",flux_max,cost_min);
    for(int i=1;i<=s;i++)
    for(int j=s+1;j<=d;j++)
    if(f[i][j] > 0 )printf("%d ",u[i][j]);
}

int main(){
    int e,x,y,z;
    freopen("fmcm.in","r",stdin);
    freopen("fmcm.out","w",stdout);
        scanf("%d %d %d",&n,&m,&e);
        s = n + 1; d = n + m + 2;
        for(int i=1;i<=e;i++)
        {
            scanf("%d %d %d",&x,&y,&z);
            y += s;
            u[x][y] = i;
            g[x].push_back(y);
            g[y].push_back(x);
            c[x][y] = 1;
            pr[x][y] = z;
            pr[y][x] = -z;

            if(c[s][x] == 0)
            {
                c[s][x] = 1;
                g[s].push_back(x);
                g[x].push_back(s);
            }

            if(c[y][d] == 0)
            {
                c[y][d] = 1;
                g[y].push_back(d);
                g[d].push_back(y);
            }
        }

    fmcm();

    return 0;
}
