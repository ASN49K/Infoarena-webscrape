#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstring>

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int INF = 0x3f3f3f3f;

int N, M, E, sol;
int S, D, Dmin[605];
int F[605][605], C[605][605], TT[605], nrMuchie[605][605];
vector<pair<int, int> > V[605];
queue<int> Q;
bool inQ[605];

bool bellman()
{
    memset(Dmin, INF, sizeof(Dmin));
    memset(inQ, false, sizeof(inQ));

    Dmin[S] = 0;
    Q.push(S);
    inQ[S] = true;

    while (!Q.empty())
    {
        int now = Q.front();
        Q.pop();
        inQ[now] = false;

        if (now == D) // NU UITA DE ASTA
            continue;

        for (vector<pair<int, int > >::iterator it = V[now].begin(); it != V[now].end(); ++it)
        {
            if (F[now][it->first] < C[now][it->first])
            {
                if (Dmin[now] + it->second < Dmin[it->first])
                {
                    Dmin[it->first] = Dmin[now] + it->second;
                    TT[it->first] = now;
                    if (!inQ[it->first])
                    {
                        inQ[it->first] = true;
                        Q.push(it->first);
                    }
                }
            }
        }
    }

    return (Dmin[D] != INF);
}

int main()
{
    fin >> N >> M >> E;
    for (int i = 1, nod1, nod2, cost; i <= E; ++i)
    {
        fin >> nod1 >> nod2 >> cost;
        nod2 += N;

        nrMuchie[nod1][nod2] = i;
        V[nod1].push_back(make_pair(nod2, cost));
        V[nod2].push_back(make_pair(nod1, -cost));
        C[nod1][nod2] = 1;
    }

    S = 0;
    D = N + M + 1;

    for (int i = 1; i <= N; ++i)
    {
        V[S].push_back(make_pair(i, 0));
        C[S][i] = 1;
    }
    for (int i = N + 1; i <= N + M; ++i)
    {
        V[i].push_back(make_pair(D, 0));
        C[i][D] = 1;
    }

    int maxflow = 0, fmin = INF;
    while (bellman())
    {
        fmin = INF;
        for (int nod = D; nod != S; nod = TT[nod])
            fmin = min(fmin, C[TT[nod]][nod] - F[TT[nod]][nod]);

        if (fmin == 0)
            continue;

        for (int nod = D; nod != S; nod = TT[nod])
        {
            F[TT[nod]][nod] += fmin;
            F[nod][TT[nod]] -= fmin;
        }

        maxflow += fmin * Dmin[D]; // asta e costul!!!!
    }

    for (int i = 1; i <= N; ++i)
        for (int j = N + 1; j <= N + M; ++j)
            if (F[i][j])
                ++sol;
    fout << sol << ' ' << maxflow << '\n';
    for (int i = 1; i <= N; ++i)
        for (int j = N + 1; j <= N + M; ++j)
            if (F[i][j])
                fout << nrMuchie[i][j] << ' ';

    fin.close();
    fout.close();
    return 0;
}
