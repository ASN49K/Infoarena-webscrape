#include <fstream>
#include <queue>
#include <bitset>
#include <vector>
using namespace std;
typedef unsigned int uint;

struct edge 
{ 
	int x, y, c; 
	edge() {} 
	edge(int a, int b, int _c) { x = a, y = b, c = _c; }
};

const int N = 610, INF = 0x7f7f7f7f;
int C[N][N], F[N][N], d[N], l[N];
int n;
vector<vector<pair<int, int> > > a;
vector<edge> edges;

void addEdge(const edge &e)
{
	a[e.x].push_back(make_pair(e.y, e.c));
	a[e.y].push_back(make_pair(e.x, -e.c));
	C[e.x][e.y] = 1;
}

void buildGraph(int l, int r)
{
	a.resize(n + 1);
	for(int i=1;i<=l;++i)
		addEdge(edge(0, i, 0));
	for(int i=1;i<=r;++i)
		addEdge(edge(i + l, n, 0));

	for(vector<edge>::iterator it = edges.begin(); it != edges.end(); ++ it)
		addEdge(*it);
}

bool bellmanford()
{
	memset(d, 0x7f, sizeof(d));
	d[0] = 0;
	queue<int> q;
	bitset<400> u;
	q.push(0);

	while(!q.empty())
	{
		int v = q.front(); q.pop(); u[v] = false;
		for (vector<pair<int, int> >::iterator it = a[v].begin(); it != a[v].end(); ++ it)
			if (C[v][it->first] - F[v][it->first] > 0 && d[it->first] > d[v] + it->second)
			{
				d[it->first] = d[v] + it->second;
				l[it->first] = v;
				if(!u[it->first])
					u[it->first] = true,
					q.push(it->first);
			}
	}

	return d[n] != INF;
}

void flux(int &c, int &nr)
{
	c = nr = 0;
	while(bellmanford())
	{
		++ nr;
		c += d[n];
		for(int v=n;v!=0;v=l[v])
			++ F[l[v]][v],
			-- F[v][l[v]];
	}
}

int main()
{
	ifstream cin("cmcm.in");
	ofstream cout("cmcm.out");

	int l, r, m, x, y, c;
	cin >> l >> r >> m;
	n = l + r + 1;
	while(m --)
	{
		cin >> x >> y >> c;
		edges.push_back(edge(x, y + l, c));
	}

	buildGraph(l, r);

	int cost, num;
	flux(cost, num);

	cout << num << " " << cost << endl;
	int i = 1;
	for(vector<edge>::iterator it = edges.begin(); it != edges.end(); ++ it, ++ i)
		if(F[it->x][it->y])
			cout << i << " ";
	cout << endl;

	return 0;
}
