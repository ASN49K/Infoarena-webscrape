using namespace std;
#include<iostream>
#include<fstream>
#include<vector>
#include<cstring>

#define  pb push_back
#define oo 0x3f3f3f3f

struct nod{
int lg,c;};
vector<nod> G[700];
ofstream fout("cmcm.out");
int cmin,cost_minim;
int S,D,E,sink,surs;
int ante[700],viz[700],q[700],isinq[700],C[700][700],F[700][700],d[700],ret[305][305];
bool BFS()
{
    memset(ante,0,sizeof(ante));
    memset(viz,0,sizeof(viz));
    memset(q,0,sizeof(q));
    memset(isinq,0,sizeof(isinq));
    int i;
    for(i=0;i<=sink;i++)
      d[i]=oo;
    int front=1;
    q[++q[0]]=0;
    viz[0]=1;
    d[0]=0;
    isinq[0]=1;
    int u;
    vector<nod>::iterator it;
    while(front<=q[0])
    {
        u=q[front++];
        isinq[u]=0;
        for(it=G[u].begin();it<G[u].end();it++)
        {
            if(C[u][it->lg]>F[u][it->lg])
            {
                if(d[it->lg]>d[u]+it->c)
                {
                    d[it->lg]=d[u]+it->c;
                    viz[it->lg]=1;
                    ante[it->lg]=u;
                    if(!isinq[it->lg])
                    {
                        q[++q[0]]=it->lg;
                        isinq[it->lg]=1;
                    }
                }
            }
        }
    }

    cost_minim=d[sink];

    return viz[sink];


}

void solve()
{
    vector<nod>::iterator it;
    int i, flow, fmin;
    for(flow=0; BFS();)
    {
        fmin=C[ante[sink]][sink]-F[ante[sink]][sink];

        for(i=ante[sink];i!=0;i=ante[i])
        {
            fmin=min(fmin,C[ante[i]][i]-F[ante[i]][i]);

        }

        F[ante[sink]][sink]+=fmin;
        F[sink][ante[sink]]-=fmin;

        for(i=ante[sink];i!=0;i=ante[i])
        {
            F[ante[i]][i]+=fmin;
            F[i][ante[i]]-=fmin;

        }
        flow+=fmin;
        cmin+=cost_minim*fmin;

    }

    fout<<flow<<" "<<cmin<<"\n";
    for(i=1;i<=S;i++)
    {
        for(it=G[i].begin();it<G[i].end();it++)
        {
            if(F[i][it->lg]==1)
            {
                fout<<ret[i][it->lg-S]<<" ";
            }
        }
    }
}

void cit()
{int x,y,z,i=0;
    ifstream fin("cmcm.in");

    fin>>S>>D>>E;
    sink=S+D+1;
    surs=0;
    while(E--)
    {
        i++;
        fin>>x>>y>>z;
        ret[x][y]=i;
        G[0].pb((nod){x,0});
        G[x].pb((nod){0,0});
        G[S+y].pb((nod){sink,0});
        G[sink].pb((nod){S+y,0});
        G[x].pb((nod){S+y,z});
        G[S+y].pb((nod){x,-z});
        C[0][x]=1;
        C[x][S+y]=1;
        C[S+y][sink]=1;
    }

    fin.close();

}

int main()
{
    cit();

    solve();


    fout.close();
    return 0;
}

