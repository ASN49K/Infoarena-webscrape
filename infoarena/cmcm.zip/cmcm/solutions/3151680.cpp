#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
vector<int> x[601];
pair<int, int> h[601][601];
int n, m, nr, sol, p[601], k, y[50001];
int dist[601], prec[601], init[601][601];

struct L{
int a, b, c;
}v[50001];

void update(int a, int v)
{while(prec[a]!=-1)
 {h[prec[a]][a].first-=v, sol+=v*init[prec[a]][a];
  h[a][prec[a]].first+=v, sol-=v*init[a][prec[a]];
  a=prec[a];
 }
}

struct Data{
int a;

bool operator <(const Data& other) const
{
    return dist[a]>dist[other.a];
}

};

int main()
{   int l, a, b, c;
    fin>>n>>m>>l;
    nr=n+m+1;
    for(int i=1;i<=n;i++)
    {x[0].push_back(i);
     x[i].push_back(0);
     h[0][i]={1, 0};
     h[i][0]={0, 0};

     init[0][i]=0;
    }

    for(int i=1;i<=m;i++)
    {x[i+n].push_back(nr);
     x[nr].push_back(i+n);
     h[i+n][nr]={1, 0};
     h[nr][i+n]={0, 0};

     init[i+n][nr]=0;
    }

    for(int i=1;i<=l;i++)
    {fin>>a>>b>>c;
     b+=n;
     v[i]={a, b, c};

     x[a].push_back(b);
     x[b].push_back(a);
     h[a][b]={1, c};
     h[b][a]={0, -c};

     init[a][b]=c;
    }

    for(int i=0;i<=nr;i++)
    dist[i]=1e6, p[i]=0;
    prec[0]=-1, p[0]=1, dist[0]=0;

    queue<int> q;
    vector<int>:: iterator I;

    q.push(0);
    while(q.empty()!=1)
    {a=q.front();
     p[a]=0;

     for(I=x[a].begin();I<x[a].end();I++)
     if(h[a][*I].first>0 && dist[*I]>dist[a]+h[a][*I].second)
     {prec[*I]=a;
      dist[*I]=dist[a]+h[a][*I].second;
      if(p[*I]==0)p[*I]=1, q.push(*I);
     }
     q.pop();
    }

    if(dist[nr]!=1e6)
    {update(nr, 1);

     for(int i=0;i<=nr;i++)
     for(I=x[i].begin();I<x[i].end();I++)
     h[i][*I].second+=dist[i]-dist[*I];
    }

    priority_queue<Data> q1;
    while(dist[nr]!=1e6)
    {for(int i=0;i<=nr;i++)
     dist[i]=1e6, p[i]=0;
     prec[0]=-1, p[0]=1;
     dist[0]=0;
     q1.push({0});

     while(q1.empty()!=1)
     {a=q1.top().a;
      p[a]=0;
      for(I=x[a].begin();I<x[a].end();I++)
      if(h[a][*I].first>0 && dist[*I]>dist[a]+h[a][*I].second)
      {prec[*I]=a;
       dist[*I]=dist[a]+h[a][*I].second;
       if(p[*I]==0)p[*I]=1, q1.push({*I});
      }
      q1.pop();
     }

     if(dist[nr]!=1e6)
     {update(nr, 1);

      for(int i=0;i<=nr;i++)
      for(I=x[i].begin();I<x[i].end();I++)
      h[i][*I].second+=dist[i]-dist[*I];
     }
    }

    for(int i=1;i<=l;i++)
    {if(h[v[i].a][v[i].b].first==0)
     y[++k]=i;
    }
    fout<<k<<" "<<sol<<"\n";
    for(int i=1;i<=k;i++)
    fout<<y[i]<<" ";
    return 0;
}
