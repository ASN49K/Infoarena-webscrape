#include<cstdio>
int n,m,z,i,j,p,q,t,l,r,k,e,c[601][601],f[601][601],a[50001],b[50001],u[601],v[601][601],w[50001],g[601];
int main()
{
	freopen("cmcm.in","r",stdin),freopen("cmcm.out","w",stdout),scanf("%d%d%d",&n,&m,&k);
	for(i=1;i<=k;i++)
    	scanf("%d%d%d",a+i,b+i,&z),c[a[i]][b[i]+n+1]=1,v[a[i]][b[i]+n+1]=z,v[b[i]+n+1][a[i]]=-z;
	for(i=1;i<=n;i++)
    	c[0][i]=1;
	for(i=n+2;i<=n+m+1;i++)
    	c[i][n+1]=1;
	while(1)
    {
		for(i=1;i<=n+m+1;i++)
            u[i]=0,g[i]=50001;
       	for(g[0]=p=q=0,w[q++]=0;p<q;)
        {
		   	t=w[p++];
            if(t&&t<=n)
            {
				for(i=n+1;i<=n+m+1;i++)
                    if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                        w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];
			}
            else
                for(i=1;i<=n+1;i++)
                    if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                        w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];
		}
       	if(!u[n+1])
            break;
       	for(l=n+1;l;l=u[l])
            f[u[l]][l]++,f[l][u[l]]--;
       	e+=g[n+1];
	}
	for(i=1;i<=k;i++)
        if(f[a[i]][b[i]+n+1]==1)
            w[r++]=i;
	printf("%d %d\n",r,e);
	for(i=0;i<r;i++)
       	printf("%d ",w[i]);
}
