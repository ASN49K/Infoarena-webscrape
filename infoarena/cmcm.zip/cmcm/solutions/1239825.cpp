#include <cstdio>
#include <vector>
#include <deque>
#define N 610
#define oo (1<<31)-1
using namespace std;
vector<int>Sol,v[N];
deque<int>Q;
int Cost[N][N],Fl[N][N],Cap[N][N],dist,i,x,y,c,s,d,q[N],D[N],tata[N],n,m,e,M[N][N],j,sol;
bool bellman()
{
    Q.clear();
    Q.push_back(s);
    for(i=0;i<=d;i++)
    {
        D[i]=oo;
        tata[i]=0;
    }
    D[s]=0;
    q[s]=1;
    while(Q.size())
    {
        x=Q.front();
        Q.pop_front();
        dist=D[x];
        q[x]=0;
        for(vector<int>::iterator it=v[x].begin();it!=v[x].end();it++)
            if(Cap[x][*it]-Fl[x][*it])
                if(D[*it]>dist+Cost[x][*it])
                {
                    tata[*it]=x;
                    D[*it]=dist+Cost[x][*it];
                    if(q[*it])continue;
                    Q.push_back(*it);
                    q[*it]=1;
                }
    }
    if(D[d]==oo)return 0;
    return 1;
}
void upd()
{
    for(x=d,y=tata[d];x!=s;x=tata[x],y=tata[y])
    {
        Fl[x][y]--;
        Fl[y][x]++;
    }
}
int main()
{
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&n,&m,&e);
    s=0;
    d=m+n+1;
    for(i=1;i<=e;i++)
    {
        scanf("%d%d%d",&x,&y,&c);
        y+=n;
        M[x][y]=i;
        v[x].push_back(y);
        v[y].push_back(x);
        Cost[x][y]=c;
        Cost[y][x]=-c;
        Cap[x][y]=1;

    }
    for(i=1;i<=n;i++)
    {
        Cap[s][i]=1;
        v[s].push_back(i);
    }
    for(i=n+1;i<d;i++)
    {
           Cap[i][d]=1;
           v[i].push_back(d);
    }
    while(bellman())
        upd();
    for(i=1;i<=n;i++)
        for(j=n+1;j<d;j++)
        {
            if(Fl[i][j])
            {
                sol+=Cost[i][j];
                Sol.push_back(M[i][j]);
            }
        }
    printf("%d %d\n",Sol.size(),sol);
    for(vector<int>::iterator it=Sol.begin();it!=Sol.end();it++)
        printf("%d ",*it);
    return 0;
}
