#include<cstdio>
#include<vector>
#include<cstring>
#include<deque>
#include<bitset>
#include<algorithm>
using namespace std;
const int nmax = 2*305;
const int inf = (1LL<<31)-1;
int n,m,e,i,j,x,y,z,s,d,add,cuplaj,ctotal;
int edge[nmax][nmax],dist[nmax],cost[nmax][nmax],cap[nmax][nmax],flow[nmax][nmax],f[nmax];
vector<int> v[nmax];
deque<int> q;
bitset<nmax> inq;
bool bf()
{
    for(i=1;i<=n+m+1;i++) dist[i]=inf;
    q.push_back(s); inq[s]=1;
    while(!q.empty())
    {
        x=q.front(); q.pop_front(); inq[x]=0;
        for(vector<int>::iterator it=v[x].begin();it!=v[x].end();it++)
            if(dist[x]+cost[x][*it]<dist[*it] && flow[x][*it]<cap[x][*it])
            {
                dist[*it]=dist[x]+cost[x][*it];
                f[*it]=x;
                if(!inq[*it])
                {
                    inq[*it]=1;
                    q.push_back(*it);
                }
            }
    }
    return dist[d]!=inf;
}
int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d%d%d",&n,&m,&e);
	for(i=1;i<=e;i++)
	{
	    scanf("%d%d%d",&x,&y,&z); y+=n;
	    edge[x][y]=i;
	    v[x].push_back(y);
	    v[y].push_back(x);
	    cost[x][y]=z; cost[y][x]=-z;
	    cap[x][y]=1;
	}
	s=0; d=n+m+1;
	for(i=1;i<=n;i++)
	{
	    cap[s][i]=1;
	    v[s].push_back(i);
	}
	for(i=n+1;i<=n+m;i++)
	{
	    cap[i][d]=1;
	    v[i].push_back(d);
	}
	while(bf())
	{
	    add=inf;
        for(x=d;x!=f[x];x=f[x])
            add=min(add,cap[f[x]][x]-flow[f[x]][x]);
        for(x=d;x!=f[x];x=f[x])
        {
            flow[f[x]][x]+=add;
            flow[x][f[x]]-=add;
        }
        cuplaj+=add; ctotal+=dist[d];
	}
	printf("%d %d\n",cuplaj,ctotal);
	for(i=1;i<=n;i++)
        for(j=n+1;j<=n+m;j++)
            if(flow[i][j]) printf("%d ",edge[i][j]);
	return 0;
}
