#include <bits/stdc++.h>
using namespace std;;
ifstream fi("cmcm.in");
ofstream fo("cmcm.out");

const int NMAX = 605;
const int INF = 1e9 + 5;

int n, m, e;
int cost[NMAX][NMAX], F[NMAX][NMAX], C[NMAX][NMAX];
vector <int> G[NMAX];
int dist[NMAX];
bool inCoada[NMAX];
int p[NMAX];
int loc[NMAX][NMAX];

void adauga(int u, int v, int c)
{
    G[u].push_back(v);
    G[v].push_back(u);
    cost[u][v] = c;
    cost[v][u] = -c;
    C[u][v] = 1;
    C[v][u] = 0;
}

bool bellmanford()
{
    for (int i = 0; i <= n + m + 1; i++)
        dist[i] = INF;
    memset(inCoada, 0, sizeof(inCoada));

    queue <int> Q;
    Q.push(0);
    inCoada[0] = 1;
    dist[0] = 0;

    while (!Q.empty())
    {
        int nod = Q.front();
        Q.pop();
        inCoada[nod] = 0;

        for (auto v: G[nod])
        {
            if (dist[nod] + cost[nod][v] < dist[v] && F[nod][v] != C[nod][v])
            {
                dist[v] = dist[nod] + cost[nod][v];
                p[v] = nod;

                if (!inCoada[v])
                    Q.push(v), inCoada[v] = 1;
            }
        }
    }
    return dist[n + m + 1] != INF;
}

int main()
{
    fi >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int u, v, c;
        fi >> u >> v >> c;
        v += n;
        loc[u][v] = i;
        adauga(u, v, c);

        adauga(0, u, 0);
        adauga(v, n + m + 1, 0);
    }

    int rez = 0;
    while (bellmanford())
    {
        int minim = INF;
        for (int i = n + m + 1; i != 0; i = p[i])
        {
            minim = min(minim, C[p[i]][i] - F[p[i]][i]);
        }

        for (int i = n + m + 1; i != 0; i = p[i])
        {
            F[p[i]][i] += minim;
            F[i][p[i]] -= minim;
        }

        rez += (dist[n + m + 1]) * minim;
    }


    int nrm = 0;
    vector <int> rrr;
    for (int i = 1; i <= n; i++)
    {
        for (auto v: G[i])
            if (F[i][v] == C[i][v] && C[i][v] == 1)
                nrm++, rrr.push_back(loc[i][v]);
    }

    fo << nrm << " " << rez << "\n";
    for (auto x: rrr)
        fo << x << " ";

    return 0;
}
