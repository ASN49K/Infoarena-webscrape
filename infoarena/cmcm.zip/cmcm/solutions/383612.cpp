#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

#define file_in "cmcm.in"
#define file_out "cmcm.out"

#define Nmax 700

int n,m,s,d;
int viz[Nmax];
int q[Nmax];
vector<int> G[Nmax];
int C[Nmax][Nmax];
int F[Nmax][Nmax];
int x,y,nod,c;
int tata[Nmax];
int cost,l,v;
int ind[Nmax][Nmax];
int nr=0;

int bf()
{
	memset(q,0x3f3f3f3f,sizeof(q));
	queue<int> Q;
	memset(viz,0,sizeof(viz));
	
	Q.push(s);
	tata[s]=0;
	viz[s]=1;
	q[s]=0;
	for(;!Q.empty();Q.pop())
	{
		x=Q.front();
		viz[x]=0;
		for (int i=0;i<G[x].size();++i)
		{
			nod=G[x][i];
			if (q[nod]>q[x]+C[x][nod] && F[x][nod])
			{
				q[nod]=q[x]+C[x][nod];
				viz[nod]=1;
				Q.push(nod);
				tata[nod]=x;
			}
		}
		//Q.pop();
	}
	
	if (q[d]==0x3f3f3f3f) 
		return 0;
	else
		return 1;
}
	

void baga_flux()
{
	for(;bf();)
	{
		v=0x3f3f3f3f;
		for (int i=d;i!=s;i=tata[i])
			 v=min(v,F[tata[i]][i]);
		for (int i=d;i!=s;i=tata[i])
		     F[i][tata[i]]+=v,
			 F[tata[i]][i]-=v;
		
		cost+=v*q[d];
	}
}	
			

int main()
{
	int i,j;
	freopen(file_in,"r",stdin);
	freopen(file_out,"w",stdout);
	
	scanf("%d %d %d", &n, &m, &l);
    
	s=0;
	d=n+m+1;
	
	for (i=1;i<=l;++i)
	{
		scanf("%d %d %d", &x,&y,&c);
	
		G[x].push_back(y+n);
		G[y+n].push_back(x);
		
		C[x][y+n]=c;
		C[y+n][x]=-c;
		F[x][y+n]=1;
		ind[x][y+n]=i;
	}
	
	for (i=1;i<=n;++i)
	{
		G[s].push_back(i);
		G[i].push_back(s);
		F[s][i]=1;
	}
	for (i=n+1;i<=n+m;++i)
	{
		G[d].push_back(i);
		G[i].push_back(d);
		F[i][d]=1;
	}
	
	baga_flux();
	
	for (i=1;i<=n;++i)
		 for (j=n+1;j<d;++j)
			  if (!F[i][j] && ind[i][j])
					nr++;
			
	
	printf("%d %d\n",nr, cost);
	for (i=1;i<=n;++i)
		 for (j=n+1;j<d;++j)
			  if (!F[i][j] && ind[i][j])
				   printf("%d ", ind[i][j]);	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
	
}
