#include <fstream>
#include <vector>
#include <queue>
#include <string.h>
using namespace std;

ofstream out("cmcm.out");
ifstream in("cmcm.in");

const int N_MAX = 300;
vector<int> vecini[1001];
int cost[1001][1001];
int capacity[1001][1001];
bool inV[1001];
bool inQ[1001];
struct Muchie
{
    int u, v, cost;
}muchii[50001];

int old_d[1001], d[1001], new_d[1001];
int tata[1001];
int Djikstra(int S, int D)
{
    priority_queue<pair<int, int>, vector<pair<int,int>>, greater<pair<int,int> > >frontiera;
    frontiera.push(make_pair(0,S));
    memset(d, 0x3f, sizeof(d));
    d[S] = 0;
    while(!frontiera.empty())
    {
        int nod = frontiera.top().second;
        int cst = frontiera.top().first;
        frontiera.pop();
        if(nod == D || d[nod] != cst) continue;
        for(int m : vecini[nod])
        {
            int newcost = d[nod] + old_d[nod] - old_d[m] + cost[nod][m];
            if(capacity[nod][m] && newcost < d[m])
            {
                d[m] = newcost;
                tata[m] = nod;
                new_d[m] = new_d[nod] + cost[nod][m];
                frontiera.push(make_pair(d[m],m));
            }
        }
    }
    memcpy(old_d, new_d, sizeof(d));
    if(d[D] == 0x3f3f3f3f)
        return false;
    return true;
}

void Bellman_Ford(int S, int D)
{
    queue<int> frontiera;
    frontiera.push(S);
    inQ[S] = 1;
    memset(old_d, 0x3f, sizeof(old_d));
    old_d[S] = 0;
    while(!frontiera.empty())
    {
        int nod = frontiera.front();
        frontiera.pop();
        if(nod == D) continue;
        for(int m : vecini[nod])
        {
            if(capacity[nod][m] && (old_d[nod] + cost[nod][m] < old_d[m]))
            {
                old_d[m] = old_d[nod] + cost[nod][m];
                if(inQ[m]) continue;
                inQ[m] = true;
                frontiera.push(m);
            }
        }
        inQ[nod] = 0;
    }


}

int main()
{
    int N, M, E;
    in >> N >> M >> E;
    for(int i = 1; i <= E; i++)
    {
        int x, y, z;
        in >> x >> y >> z;
        muchii[i] = {x+1,y+300,z};
        vecini[x+1].push_back(y + 300);
        vecini[y + 300].push_back(x+1);
        cost[x+1][y+300] = z;
        cost[y+300][x+1] = -z;
        capacity[x+1][y+300] = 1;
        if(!inV[x+1])
        {
            inV[x+1] = true;
            vecini[0].push_back(x+1);
            capacity[0][x+1] = 1;
        }
        if(!inV[y+300])
        {
            inV[y+300] = true;
            vecini[y+300].push_back(1000);
            capacity[y+300][1000] = 1;
        }
    }

    Bellman_Ford(0, 1000);
    int total = 0;
    int S = 0, D = 1000;
    int totalF = 0;
    while(Djikstra(0, 1000))
    {
        int nod = D;
        int fmin = 0x3f3f3f3f;
        for(; nod!=S; nod = tata[nod])
            fmin = min(fmin, capacity[tata[nod]][nod]);
        if(fmin == 0) continue;
        nod = D;
        int sum = 0;
        totalF++;
        for(; nod != S; nod = tata[nod])
        {
            capacity[tata[nod]][nod] -= fmin;
            capacity[nod][tata[nod]] += fmin;

            sum += fmin * cost[tata[nod]][nod];
        }
        total += sum;
    }
    out << totalF << " "  << total << "\n";
    for(int i = 1; i <= E; i++)
        if(!capacity[muchii[i].u][muchii[i].v])
            out << i << " ";
    return 0;
}
