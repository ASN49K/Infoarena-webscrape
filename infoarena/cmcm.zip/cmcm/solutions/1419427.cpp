#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <limits>

#define pb push_back
#define mp make_pair
#define INF numeric_limits<int>::max()
#define NM 300

using namespace std;

ifstream in("cmcm.in");
ofstream out("cmcm.out");

vector< vector<int> > a(603);
queue<int> q;
int L,R,n,m,flow[700][700],cap[700][700],cost[700][700],pre[700],dist[700],ct,maxflow,ind[700][700];
bool use[700];
const int S=601,D=602;

bool bellman()
{
    for(int i=1;i<=603;i++)
    {
        pre[i]=0;
        use[i]=false;
        dist[i]=INF;
    }
    dist[S]=0;
    pre[S]=S;
    use[S]=true;
    q.push(S);
    while(!q.empty())
    {
        int x=q.front();q.pop();
        use[x]=false;
        for(vector<int>::iterator i=a[x].begin();i!=a[x].end();i++)
        if(dist[*i] > dist[x]+cost[x][*i] && cap[x][*i]-flow[x][*i] > 0)
        {
            pre[*i]=x;
            dist[*i]=dist[x]+cost[x][*i];
            if(use[*i]==false)
            {
                use[*i]=true;
                q.push(*i);
            }
        }
    }
    return pre[D];
}

int main()
{
    in>>L>>R>>m;
    n=L+R;
    for(int i=1;i<=m;i++)
    {
        int x,y,z;
        in>>x>>y>>z;
        y+=NM;
        a[x].pb(y);
        a[y].pb(x);
        cost[x][y]=z;
        cost[y][x]=-z;
        cap[x][y]=1;
        ind[x][y]=i;
    }

    for(int i=1;i<=L;i++)
    {
        a[S].pb(i);
        a[i].pb(S);
        cap[S][i]=1;
    }

    for(int i=1;i<=R;i++)
    {
        a[i+NM].pb(D);
        a[D].pb(i+NM);
        cap[i+NM][D]=1;
    }

    for(;bellman();)
    {
        int mx=INF;

        for(int x=D;pre[x]!=x;x=pre[x])
        mx=min(mx,cap[pre[x]][x]-flow[pre[x]][x]);

        for(int x=D;pre[x]!=x;x=pre[x])
        {
            ct+=cost[pre[x]][x]*mx;
            flow[pre[x]][x]+=mx;
            flow[x][pre[x]]-=mx;
        }

        maxflow+=mx;

    }

    out<<maxflow<<' '<<ct<<'\n';

    for(int j=1;j<=L;j++)
    {
        for(vector<int>::iterator i=a[j].begin();i!=a[j].end();i++)
        if(flow[j][*i]==1)
        {
            out<<ind[j][*i]<<' ';
            break;
        }
    }
    return 0;
}


