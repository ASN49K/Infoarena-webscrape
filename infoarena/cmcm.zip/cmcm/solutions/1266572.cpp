#include <fstream>
#include <list>
#include <queue>
#include <bitset>
#define DIM 611
#define INF 2000000011
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
int N,M,E,st,stp,minim;
int T[DIM],D[DIM];
int C[DIM][DIM],CT[DIM][DIM],F[DIM][DIM];
long long sol;

struct tip{
    int x,y,p;
};

list<int> L[DIM],v;
list<tip> arc;
queue<int> q;
bitset<DIM> viz;

inline int bellmanford(){
    register int i,nod;
    list<int>::iterator it;
    viz.reset();
    for(i=1;i<=N+M;i++)
        D[i]=INF,T[i]=-1;
    D[stp]=INF;
    q.push(st);
    viz[st]=1;

    while(!q.empty()){
        nod=q.front(),q.pop(),viz[nod]=0;
        for(it=L[nod].begin();it!=L[nod].end();it++){
            if(C[nod][*it]>F[nod][*it] && D[nod]+CT[nod][*it]<D[*it]){
                D[*it]=D[nod]+CT[nod][*it];
                T[*it]=nod;
                if(!viz[*it]) viz[*it]=1,q.push(*it);
            }
        }
    }
    if(D[stp]!=INF)
        return 1;
    return 0;
}

int main(void){
    register int i,j,x,y,c;
    list<tip>::iterator it;
    list<int>::iterator it1;
    tip z;

    f>>N>>M>>E;
    for(i=1;i<=E;i++){
        f>>x>>y>>c;
        L[x].push_back(y+N);
        L[y+N].push_back(x);
        C[x][y+N]=1;
        CT[x][y+N]=c;
        CT[y+N][x]=-c;
        z.p=i,z.x=x,z.y=y+N;
        arc.push_back(z);
    }

    st=603,stp=604;
    for(i=1;i<=N;i++) L[st].push_back(i),C[st][i]=1;
    for(i=1;i<=M;i++) L[i+N].push_back(stp),C[i+N][stp]=1;

    while(bellmanford()){
        x=stp;
        while(T[x]>0){
            F[T[x]][x]++;
            F[x][T[x]]--;
            x=T[x];
        }
        sol+=D[stp];
    }

    for(it=arc.begin();it!=arc.end();it++){
        if(F[it->x][it->y]==1)
            v.push_back(it->p);
    }

    g<<v.size()<<" "<<sol<<"\n";
    for(it1=v.begin();it1!=v.end();it1++) g<<*it1<<" ";
    f.close();
    g.close();
    return 0;
}
