#include <bits/stdc++.h>
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("cmcm.in" , "rt" , stdin) , freopen("cmcm.out" , "wt" , stdout)
#define pii pair < int , int >
#define pb push_back
#define Min(a , b) (a > b ? b : a)

using namespace std;

const int N = 605;

int n , m , e , source , sink , p , Q , c;
int capacity[N][N] , weight[N][N] , parent[N] , edge[N][N];
int d[N] , nd[N];
vector < int > G[N] , edg;
queue < int > q;
bitset < N > inq , usedl , usedr;
priority_queue < int , vector < pii > , greater < pii > > s;

inline void bellman(int n)
{
    int i;

    for(i = 0 ; i <= n ; i++)
        d[i] = INT_MAX;

    d[source] = 0;
    q.push(source);

    while(!q.empty())
    {
        int u = q.front();
        q.pop();
        inq[u] = 0;

        for(int v : G[u])
        {
            if(capacity[u][v] && d[v] > d[u] + weight[u][v])
            {
                d[v] = d[u] + weight[u][v];

                if(inq[v])
                    continue;

                inq[v] = 1;
                q.push(v);
            }
        }
    }
}

int k = INT_MAX;
int flow = 0;
int minCost = 0;

bool inline djikstra(int n)
{
    int i;

    for(i = 0 ; i <= n ; i++)
        nd[i] = INT_MAX;

    nd[source] = 0;
    s.push({0 , source});

    while(!s.empty())
    {
        int u = s.top().second;
        int cst = s.top().first;
        s.pop();

        if(nd[u] != cst)
            continue;

        for(int v : G[u])
        {
            if(capacity[u][v])
            {
                if(nd[v] > nd[u] + weight[u][v] + d[u] - d[v])
                {
                    parent[v] = u;
                    nd[v] = nd[u] + weight[u][v] + d[u] - d[v];
                    s.push({nd[v] , v});
                }
            }
        }
    }

    if(nd[sink] == INT_MAX)
        return 0;

    int minFlow = k - flow;
    int curr;
    int sumCost = 0;

    for(curr = sink ; curr != source ; curr = parent[curr])
        minFlow = Min(minFlow , capacity[parent[curr]][curr]);

    for(curr = sink ; curr != source ; curr = parent[curr])
    {
        capacity[parent[curr]][curr] -= minFlow;
        capacity[curr][parent[curr]] += minFlow;
        sumCost += weight[parent[curr]][curr];

      //  cerr << curr << ' ';
        if(!usedl[parent[curr]] && parent[curr] < curr && edge[parent[curr]][curr])
        {
            usedl[parent[curr]] = usedr[curr] = 1;
            edg.pb(edge[parent[curr]][curr]);
            //cerr << parent[curr] << ' ' << curr  << '\n';
        }
    }

  //  cerr << '\n';

    flow += minFlow;
    minCost += sumCost * minFlow;

    return 1;
}

signed main()
{
    FastIO , FILES;

    int i;

    cin >> n >> m >> e;

    source = 0;
    sink = n + m + 1;

    for(i = 1 ; i <= e ; i++)
    {
        cin >> p >> Q >> c;

        Q += n;

        capacity[p][Q] = 1;

        weight[p][Q] = c;
        weight[Q][p] = -c;

        G[p].pb(Q);
        G[Q].pb(p);

        edge[p][Q] = edge[Q][p] = i;
    }

    for(i = 1 ; i <= n ; i++)
    {
        p = source;
        Q = i;
        c = 0;

        capacity[p][Q] = 1;

        weight[p][Q] = c;
        weight[Q][p] = -c;

        G[p].pb(Q);
        G[Q].pb(p);
    }

    for(i = 1 ; i <= m ; i++)
    {
        p = i + n;
        Q = sink;
        c = 0;

        capacity[p][Q] = 1;

        weight[p][Q] = c;
        weight[Q][p] = -c;

        G[p].pb(Q);
        G[Q].pb(p);
    }

    bellman(n + m + 1);
    for( ; djikstra(n + m + 1) ; );
    cout << edg.size() << ' ' << minCost << '\n';
    for(auto i : edg) cout << i << ' ';

    return 0;
}
