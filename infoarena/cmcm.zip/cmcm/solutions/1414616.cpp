#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");

int N, M, L, R, x, y, c, nr[605][605], cap[605][605], cost[605][605], D[605], flux[605][605], dad[605], inQ[605], cuplate, sol;
vector < int > G[605];
queue < int > Q;

bool bellman()
{
    for (int i=0; i<=N; ++i)
        D[i]=(1<<30);
    D[0]=0; Q.push(0); inQ[0]=1;

    while (Q.size())
    {
        int nod=Q.front(); Q.pop(); inQ[nod]=0;
        vector<int>::iterator it=G[nod].begin();

        for (; it!=G[nod].end(); ++it)
            if (D[nod]+cost[nod][*it]<D[*it] && cap[nod][*it]>flux[nod][*it])
            {
                D[*it]=D[nod]+cost[nod][*it];
                dad[*it]=nod;
                if (!inQ[*it])
                    Q.push(*it), inQ[*it]=1;
            }
    }
    return (D[N]<(1<<30));
}

void cmcm()
{
    for (; bellman(); )
    {
        for (int x=N; x!=0; x=dad[x])
            ++flux[dad[x]][x], --flux[x][dad[x]];
        ++cuplate; sol+=D[N];
    }
}

int main()
{
    f>>L>>R>>M; N=L+R+1;
    for (int i=1; i<=M; ++i)
    {
        f>>x>>y>>c; y+=L; nr[x][y]=i;
        G[x].push_back(y); cap[x][y]=1;
        G[y].push_back(x);
        cost[x][y]=c; cost[y][x]=-c;
        G[0].push_back(x);
        cap[0][x]=cap[y][N]=1;
        G[y].push_back(N);
    }

    cmcm();
    g<<cuplate<<' '<<sol<<'\n';
    for (int i=1; i<N; ++i)
        for (int j=L+1; j<N; ++j)
            if (flux[i][j])
                g<<nr[i][j]<<' ';
    return 0;
}
