#include<fstream>
#include<vector>
#include<queue>
using namespace std;
#define DIM 705
#define INF 0x3f3f3f3f
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
vector < pair <int,int> > v[DIM];
vector < pair <int,int> >::iterator it;
queue <int> q;
int n,m,k,x,y,c,flux,cost,sursa,dest;
int F[DIM][DIM],C[DIM][DIM],T[DIM],D[DIM],Cost[DIM][DIM],I[DIM][DIM];
bool bellman_ford()
{
    int i;
    for (i=1;i<=dest;++i)
        D[i]=INF;
    D[sursa]=0;
    q.push(sursa);
    while (!q.empty())
    {
        x=q.front(); q.pop();
        for (it=v[x].begin();it!=v[x].end();++it)
        {
            y=it->first, c=it->second;
            if (D[y]>D[x]+c && C[x][y]>F[x][y])
            {
                D[y]=D[x]+c;
                T[y]=x;
                q.push(y);
            }
        }
    }
    return (D[dest]!=INF);
}
int main()
{
    int i,j;
    fin>>n>>m>>k;
    for (i=1;i<=k;++i)
    {
        fin>>x>>y>>c;
        v[x].push_back(make_pair(y+n,c));
        v[y+n].push_back(make_pair(x,-c));
        C[x][y+n]=1;
        Cost[x][y+n]=c, Cost[y+n][x]=-c;
        I[x][y+n]=i;
    }
    sursa=n+m+1, dest=n+m+2;
    for (i=1;i<=n;++i)
    {
        v[sursa].push_back(make_pair(i,0));
        v[i].push_back(make_pair(sursa,0));
        C[sursa][i]=1;
    }
    for (i=n+1;i<=n+m;++i)
    {
        v[i].push_back(make_pair(dest,0));
        v[dest].push_back(make_pair(i,0));
        C[i][dest]=1;
    }
    while (bellman_ford())
    {
        x=dest;
        while (x!=sursa)
        {
            //cost+=Cost[T[x]][x];
            ++F[T[x]][x], --F[x][T[x]];
            x=T[x];
        }
        ++flux;
    }

    for (i=1;i<=n;++i)
    {
        for (j=n+1;j<=m+n;++j)
            if (F[i][j]>0)
            {
                cost+=Cost[i][j];
                break;
            }
    }

    fout<<flux<<" "<<cost<<"\n";
    for (i=1;i<=n;++i)
    {
        for (j=n+1;j<=m+n;++j)
            if (F[i][j]>0)
            {
                fout<<I[i][j]<<" ";
                break;
            }
    }
    fout<<"\n";
    return 0;
}
