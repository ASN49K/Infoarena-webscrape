#include <fstream>
#include <queue>
#include <cstring>
using namespace std;

ifstream fin ("cmcm.in");
ofstream fout ("cmcm.out");

#define N 605
#define d L + R + 1
#define s 0
#define oo 0x3f3f3f3f

int F[N][N], C[N][N], cost[N][N], t[N], c[N], mem[N][N];
vector <int> g[N];
bool q[N];
queue <int> Q;
int L, R, m, sol, cmin;

bool bellmanford() {
	for (int i = 1; i <= d; ++i)
		c[i] = oo;
	Q.push(s);
	q[s] = 1;
	while (Q.size()) {
		int x = Q.front(); Q.pop();
		q[x] = 0;
		for (vector <int> :: iterator it = g[x].begin(); it != g[x].end(); ++it)
			if (F[x][*it] < C[x][*it]) {
				int opt = c[x] + cost[x][*it];
				if (opt < c[*it]) {
					c[*it] = opt;
					t[*it] = x;
					if (!q[*it]) {
						q[*it] = 1;
						Q.push(*it);
					}
				}
			}
	}
	return (c[d] != oo);
}

int main() {
	fin >> L >> R >> m;
	for (int i = 1; i <= m; ++i) {
		int x, y, c;
		fin >> x >> y >> c;
		y += L;
		g[x].push_back(y);
		g[y].push_back(x);
		cost[x][y] = c;
		cost[y][x] = -c;
		C[x][y] = 1;
		mem[x][y] = i;
	}
	fin.close();
	for (int i = 1; i <= L; ++i) {
		g[s].push_back(i);
		C[s][i] = 1;
	}
	for (int i = L + 1; i < d; ++i) {
		g[i].push_back(d);
		C[i][d] = 1;
	}
	while (bellmanford()) {
		for (int x = d; x != s; x = t[x])
			F[t[x]][x]++, F[x][t[x]]--;
		sol ++;
		cmin += c[d];
	}
	fout << sol << " " << cmin << "\n";
	for (int i = 1; i <= L; ++i)
		for (int j = L + 1; j <= L + R; ++j)
			if (F[i][j] == 1)
				fout << mem[i][j] << " ";
	fout.close();
}
