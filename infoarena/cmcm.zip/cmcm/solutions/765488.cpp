#include<cstdio>
int n,m,c[606][606],f[606][606],z,i,j,a[50001],b[50001],u[606],p,q,t,l,nr,k,v[606][606],e,x[50001],w[50001],g[606];
int main()
{freopen("cmcm.in","r",stdin);
freopen("cmcm.out","w",stdout);
scanf("%d%d%d",&n,&m,&k);     
for(i=1;i<=k;i++)
     scanf("%d%d%d",&a[i],&b[i],&z),c[a[i]][b[i]+n+1]=1,v[a[i]][b[i]+n+1]=z,v[b[i]+n+1][a[i]]=-z;
for(i=1;i<=n;i++)
     v[0][i]=0,c[0][i]=1;
for(i=n+2;i<=n+m+1;i++)
     v[i][n+1]=0,c[i][n+1]=1;
while(1)      
       {for(i=1;i<=n+m+1;i++)
               u[i]=0,g[i]=50001;
       g[0]=p=q=0,w[q++]=0;
       while(p<q)
               {t=w[p++];
               if(t&&t<=n)
                       {for(i=n+1;i<=n+m+1;i++)
                       if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                               w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];}
               else
                       for(i=1;i<=n+1;i++)
                       if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                               w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];}
       if(!u[n+1])
               break;
       for(l=n+1;l;l=u[l])
               f[u[l]][l]++,f[l][u[l]]--;
       e+=g[n+1];}
for(i=1;i<=k;i++)
if(f[a[i]][b[i]+n+1]==1)
       x[nr++]=i;
printf("%d %d\n",nr,e);
for(i=0;i<nr;i++)
       printf("%d ",x[i]);    
return 0;}
