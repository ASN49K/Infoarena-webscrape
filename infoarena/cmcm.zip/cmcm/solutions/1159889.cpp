// O(N*M^2*LogN)
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
#define Nmax 605 //2 * N_max
#define oo 2000000000
#define pb push_back
#define x first
#define y second
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");

int L,R,N,M,Source,Sink,x,y,c,z,MaxFlow,CostMin,st[Nmax],dr[Nmax];
int nr[Nmax][Nmax],ante[Nmax],d[Nmax],old_d[Nmax],real_d[Nmax];
short cap[Nmax][Nmax],cost[Nmax][Nmax],flow[Nmax][Nmax];
vector < int > G[Nmax],sol;

typedef pair<int,int> PP;
priority_queue < PP  , vector < PP > , greater<PP> > pq;

inline void ReadInput()
{
    f>>L>>R>>M;
    for(int i=1;i<=M;++i)
        {
            f>>x>>y>>z;
            y+=L;
            G[x].pb(y) , G[y].pb(x);
            cap[x][y]=1;
            cost[x][y]=z , cost[y][x]=-z;
            nr[x][y]=i;
        }
    N=L+R+1;
    Source=0 , Sink=N;
    for(int i=1;i<=L;++i)
    {
        G[Source].pb(i) , G[i].pb(Source);
        cap[Source][i]=1;
    }
    for(int j=L+1;j<=L+R;++j)
    {
        G[j].pb(Sink) , G[Sink].pb(j);
        cap[j][Sink]=1;
    }
}

int Dijkstra(int Source)
{
    for(int i=0;i<=N;++i)d[i]=oo,ante[i]=oo;
    d[Source]=0 , ante[Source]=Source;
    for(pq.push(PP(0,Source)); !pq.empty();)
    {
        int  val=pq.top().x,node=pq.top().y;
        pq.pop();
        if(d[node]<val)continue;
        for(vector<int>::iterator it=G[node].begin();it!=G[node].end();++it)
            if(flow[node][*it]<cap[node][*it])
            {
                int aux=d[node]+cost[node][*it]+old_d[node]-old_d[*it];
                if(aux<d[*it])
                {
                    d[*it]=aux , ante[*it] = node;
                    real_d[*it]=real_d[node]+cost[node][*it];
                    pq.push( PP(d[*it] , *it) );
                }
            }
    }
    for(int i=0;i<=N;++i)old_d[i]=real_d[i];
    return (d[Sink]!=oo);
}

void GetFMCM()
{
    for( ; Dijkstra(Source) ; )
    {
            for(int i=Sink; i!=Source ; i=ante[i])
            {
                ++flow[ante[i]][i];
                --flow[i][ante[i]];
                if(flow[ante[i]][i]>0)st[ante[i]]=i,dr[i]=ante[i];
                 else if(flow[ante[i]][i]==0)st[ante[i]]=dr[i]=0;
            }
            //++MaxFlow;
            CostMin+=real_d[Sink];
    }
    for(int i=1;i<=L;++i)
        if(st[i])
            sol.pb(nr[i][st[i]]);
    g<<sol.size()<<' '<<CostMin<<'\n';
    for(vector<int>::iterator it=sol.begin();it!=sol.end();++it)
        g<<*it<<' ';
    g<<'\n';
}

int main()
{
    ReadInput();
    GetFMCM();
    f.close();g.close();
    return 0;
}
