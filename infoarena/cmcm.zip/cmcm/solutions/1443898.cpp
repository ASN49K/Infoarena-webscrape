#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <bitset>
#include <queue>
using namespace std;

#define Nmax 602
#define inf 0x3f3f3f3f

FILE *f = fopen ( "cmcm.in", "r" );
FILE *g = fopen ( "cmcm.out", "w" );

int N, M, E, Source, Sink;
int Flow[Nmax][Nmax], Cap[Nmax][Nmax], Cost[Nmax][Nmax], Ind[Nmax][Nmax], Dist[Nmax], Tata[Nmax];
vector < int > G[Nmax], Muchii;
bitset < Nmax > inQ;
queue < int > Q;

bool BellmanFord (){

    vector < int > :: iterator it;

    for ( int i = Source; i <= Sink; ++i ){
        Dist[i] = inf;
        inQ[i] = 0;
    }

    Dist[Source] = 0;
    Q.push ( Source );
    inQ[Source] = 1;

    while ( !Q.empty() ){
        int nod = Q.front();
        Q.pop();
        inQ[nod] = 0;
        for ( it = G[nod].begin(); it < G[nod].end(); ++it ){
            if ( Flow[nod][*it] < Cap[nod][*it] && Dist[*it] > Dist[nod] + Cost[nod][*it] ){
                Dist[*it] = Dist[nod] + Cost[nod][*it];
                Tata[*it] = nod;
                if ( !inQ[*it] ){
                    Q.push ( *it );
                    inQ[*it] = 1;
                }
            }
        }
    }
    return Dist[Sink] != inf;
}

void CuMaCoMi (){
    int TotalCost = 0, MinFlow, NrMatches = 0;
    vector < int > :: iterator it;

    while ( BellmanFord() ){
        MinFlow = inf;

        for ( int nod = Sink; nod != Source; nod = Tata[nod] )
            MinFlow = min ( MinFlow, Cap[Tata[nod]][nod] - Flow[Tata[nod]][nod] );

        for ( int nod = Sink; nod != Source; nod = Tata[nod] ){
            Flow[Tata[nod]][nod] += MinFlow;
            Flow[nod][Tata[nod]] -= MinFlow;
        }

        TotalCost += MinFlow * Dist[Sink];
    }

    for ( int i = 1; i <= N; ++i ){
        for ( int j = N + 1; j <= N + M; ++j ){
            if ( Flow[i][j] ){
                NrMatches++;
                Muchii.push_back ( Ind[i][j] );
            }
        }
    }

    fprintf ( g, "%d %d\n", NrMatches, TotalCost );
    for ( it = Muchii.begin(); it < Muchii.end(); ++it )
        fprintf ( g, "%d ", *it );

}


int main(){

    int x, y, z;


    fscanf ( f, "%d%d%d", &N, &M, &E );

    Source = 0; Sink = N + M + 1;

    for ( int i = 1; i <= E; ++i ){
        fscanf( f, "%d%d%d", &x, &y, &z );
        y += N;

        G[x].push_back ( y );
        G[y].push_back ( x );
        Cap[x][y] = 1;
        Ind[x][y] = i;
        Cost[x][y] =  z;
        Cost[y][x] = -z;
    }

    for ( int i = 1; i <= N; ++i ){
        G[Source].push_back ( i );
        G[i].push_back ( Source );
        Cap[Source][i] = 1;
    }

    for ( int i = N + 1; i <= N + M; ++i ){
        G[i].push_back ( Sink );
        G[Sink].push_back ( i );
        Cap[i][Sink] = 1;
    }


    CuMaCoMi();


    return 0;
}
