#include <bits/stdc++.h>
using namespace std;

#define N 360
#define fi first
#define se second
#define INF 3500010

vector<int> v[N];
int adj[N][N], n, m, s, d, path[N], cost[N][N], dist[N], false_dist[N], dist2[N], muchii[N][N], n1,n2;
bool in_queue[N];

void bellmanford(){
    queue<int> q;

    for(int i = 1;i<=n;i++){
        dist[i] = INF;
    }
    dist[s] = 0;
    q.push(s);
    in_queue[s] = 1;

    while(!q.empty()){
        int curr = q.front();
        q.pop();
        in_queue[curr] = 0;
        for(auto next: v[curr]){
            if(adj[curr][curr] && dist[next] > dist[curr] + cost[curr][next]){
                dist[next] = dist[curr] + cost[curr][next];
                if(!in_queue[next] && curr != d){
                    q.push(next);
                    in_queue[next] = 1;
                }
            }
        }
    }
}


priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
bool dijkstra(){


    for(int i = 1;i<=n;i++){
        false_dist[i] = INF;
        in_queue[i] = 0;
        path[i] = 0;
    }

    false_dist[s] = 0;
    path[s] = -1;

    q.push({0,s});
    in_queue[s] = 1;
    while(!q.empty()){
        int curr = q.top().second;
        int curr_cost = q.top().first;
        q.pop();
        if(curr == d || false_dist[curr] != curr_cost) continue;

        in_queue[curr] = 0;
        for(auto next: v[curr]){
            if(adj[curr][next] && false_dist[next] > curr_cost + cost[curr][next] + dist[curr] - dist[next]){
                false_dist[next] = curr_cost + cost[curr][next] + dist[curr] - dist[next];
                dist2[next] = dist2[curr] + cost[curr][next];
                path[next] = curr;
                q.push({false_dist[next], next});
            }
        }
    }
    for(int i=1;i<=n;i++) dist[i]=dist2[i];
    return path[d];
}

long long mfmc(){
    long long ans = 0;
    while(dijkstra()){
        int curr = d;
        int flow = INF;
        while(path[curr] != -1){
            flow = min(flow, adj[path[curr]][curr]);
            curr = path[curr];
        }
        curr = d;
        while(path[curr] != -1){
            adj[path[curr]][curr] -= flow;
            adj[curr][path[curr]] += flow;
            ans+=flow*cost[path[curr]][curr];
            curr = path[curr];
        }
    }
    return ans;
}

int main(){

    ifstream cin("cmcm.in");
    ofstream cout("cmcm.out");

    cin>>n1>>n2>>m;
    n = n1+n2+2;
    for(int i = 1;i<=m;i++){
        int a,b,c;
        cin>>a>>b>>c;
        b+=n1;
        v[a].push_back(b);
        v[b].push_back(a);
        cost[a][b] = c;
        cost[b][a] = -c;

        muchii[a][b] = i;
        adj[a][b] = 1;
    }


    s = n1+n2+2;
    d = n1+n2+1;

    for(int i = 1;i<=n1;i++){
        v[s].push_back(i);
        v[i].push_back(s);
        adj[s][i] = 1;
        cost[s][i] = 0;
        cost[i][s] = 0;
    }

    for(int i = n1+1;i<=n1+n2;i++){
        v[d].push_back(i);
        v[i].push_back(d);
        adj[i][d] = 1;
        cost[d][i] = 0;
        cost[i][d] = 0;
    }
    bellmanford();
    long long mx = mfmc();
    vector<int> ras;
    for(int i = 1;i<=n1;i++){
        for(auto next: v[i]){
            if(!adj[i][next]){
                ras.push_back(muchii[i][next]);
            }
        }
    }
    cout<<ras.size()<<' '<< mx<<'\n';
    for(auto i: ras)
        cout<<i<<' ';

    return 0;
}
