#include <bits/stdc++.h>
using namespace std;

const int nmax = 607;
const int emax = 200000;
const int inf = 0x3f3f3f3f;

int n, m, e;
vector<int> adj[nmax];
int dist[nmax];
int par[nmax];
bool cap[emax];
int cost[emax];
int src[emax];
int dst[emax];

int epair(int edge) {
  return edge + (edge < 100000 ? 100000 : -100000);
}

void addEdge(int u, int v, int w, int e) {
  adj[u].push_back(e);
  adj[v].push_back(epair(e));
  src[e] = dst[epair(e)] = u;
  dst[e] = src[epair(e)] = v;
  cost[e] = w, cost[epair(e)] = -w;
  cap[e] = true, cap[epair(e)] = false;
}

void bellmanFord() {

  memset(par, -1, sizeof(par));
  memset(dist, inf, sizeof(dist));

  static bool inq[nmax];
  queue<int> q;
  q.push(0);
  dist[0] = 0;

  while (!q.empty()) {
    int u = q.front(); q.pop();
    inq[u] = false;
    for (int e : adj[u]) {
      if (cap[e] && dist[u] + cost[e] < dist[dst[e]]) {
        dist[dst[e]] = dist[u] + cost[e];
        par[dst[e]] = e;
        if (!inq[dst[e]]) q.push(dst[e]), inq[dst[e]] = true;
      }
    }
  }
  
}

void solve() {

  cin >> n >> m >> e;

  for (int i = 0; i < e; i++) {
    int u, v, w;
    cin >> u >> v >> w;
    addEdge(u, v + n, w, i);
  }
  
  for (int u = 1; u <= n; u++) {
    addEdge(0, u, 0, e + u - 1);
  }

  for (int v = n + 1; v <= n + m; v++) {
    addEdge(v, n + m + 2, 0, e + v - 1);
  }

  int totalFlow = 0;
  long long totalCost = 0;

  for (;;) {
    
    bellmanFord();

    if (par[n + m + 2] == -1) break;

    for (int u = n + m + 2; u != 0; u = src[par[u]]) {
      cap[par[u]] = false;
      cap[epair(par[u])] = true;
    }

    totalFlow++;
    totalCost += dist[n + m + 2];

  }

  cout << totalFlow << ' ' << totalCost << endl;

  for (int i = 0; i < e; i++) {
    if (cap[i] == false) {
      cout << (i + 1) << ' ';
    }
  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cmcm.in", "r", stdin);
  freopen("cmcm.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
