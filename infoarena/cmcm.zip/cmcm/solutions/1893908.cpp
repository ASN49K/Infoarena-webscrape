#include<cstdio>
#include<vector>
#include<queue>
#include<algorithm>
#include<cmath>
using namespace std;

FILE *fin = freopen("cmcm.in", "r", stdin);
FILE *fout = freopen("cmcm.out", "w", stdout);

const int INF = 0x3fffffff;;
const int MAX_N = 303;
const int DIM = MAX_N * 2 + 1;
int N, M, S, D, E, cnt, ans;
int dist[DIM], fromWhere[DIM];
int carry[DIM][DIM], cost[DIM][DIM];
bool used[DIM];
vector < int > v[DIM];
vector < pair < int, int > > edge;
queue < int > q;

bool BellmanFord()
{
    for (int i = S; i <= D; i++)
        dist[i] = INF,
        used[i] = 0;

    used[S] = 1;
    dist[S] = 0;
    q.push(S);

    while (!q.empty())
    {
        int p = q.front();
        q.pop();
        used[p] = 0;

        vector < int > :: iterator it;
        for (it = v[p].begin(); it != v[p].end(); it++)
            if (carry[p][*it] > 0 && dist[*it] > dist[p] + cost[p][*it])
            {
                dist[*it] = dist[p] + cost[p][*it];
                fromWhere[*it] = p;
                if (!used[*it])
                {
                    used[*it] = 1;
                    q.push(*it);
                }
            }
    }

    if (dist[D] != INF)
    {
        for (int i = D; i != S; i = fromWhere[i])
        {
            carry[fromWhere[i]][i] --;
            carry[i][fromWhere[i]] ++;

            ans += cost[fromWhere[i]][i];
        }
        return 1;
    }
    return 0;
}

int main()
    {
        scanf("%d%d%d", &N, &M, &E);
        S = 0, D = M + N + 1;
        for (int i = 1, X, Y, C; i <= E; i++)
        {
            scanf("%d%d%d", &X, &Y, &C);
            Y += N;
            v[X].push_back(Y);
            v[Y].push_back(X);

            carry[X][Y] = 1;
            cost[X][Y] = C;
            cost[Y][X] = -C;

            edge.push_back(make_pair(X, Y));
        }

        for (int i = 1; i <= N; i++)
        {
            v[S].push_back(i);
            v[i].push_back(S);
            carry[S][i] = 1;
        }

        for (int i = N + 1; i <= N + M; i++)
            v[D].push_back(i),
            v[i].push_back(D),
            carry[i][D] = 1;

        while (BellmanFord())
            cnt++;
        printf("%d %d\n", cnt, ans);

        vector < pair < int, int > > :: iterator it;
        for (it = edge.begin(); it != edge.end(); it++)
            if (!carry[it -> first][it -> second])
                printf("%d ", it - edge.begin() + 1);
    }
