#include<fstream>
#include<vector>
#include<queue>
using namespace std;

#define min(a,b) (a> b ? b : a)
#define inf 1<<30
#define nmax 610

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int cost[nmax][nmax], F[nmax][nmax], C[nmax][nmax],edge[nmax][nmax];
int dist[nmax], TT[nmax],ret_muc[nmax];
int S , D, N, M, K;
vector<int> G[nmax];
int L, Q;

void build_graph()
{
    for(int i = 2; i <= L + 1;i++)
    {
        G[S].push_back(i);
        G[i].push_back(S);
        C[S][i] = 1;
    }
    for(int i = L + 2; i <= N ; ++i)
    {
        G[D].push_back(i);
        G[i].push_back(D);
        C[i][D] = 1;
    }
}

void read()
{

    fin >>L>>Q>> M;
    N = L + Q + 1;
    D = N + 1;//destinatia va fi  in N + 1;
    S = 1;//sursa va fin in 1
    for(int i = 1; i <= M ;i++)
    {
        int x, y, c;

        fin >>x >>y >>c;

        y += L + 1; ++x;

        G[x].push_back(y);
        G[y].push_back(x);

        edge[x][y] = i;

        cost[x][y] = c;
        cost[y][x] = -c;

        C[x][y] = 1;

    }

}

int bellmanford()
{
    int use[nmax];
    for(int i = 1 ; i <= N + 1; i++)
    {
        dist[i] = inf;
        TT[i] = -1;
        use[i] = 0;
    }
    dist[S] = 0;
    use[1] = 1;
    queue <int> q;
    q.push(S);

    while( !q.empty())
    {
        int x = q.front();
        q.pop();
        for(int j = 0; j <G[x].size(); j++)
        {
            int nod = G[x][j];

            if(dist[x] + cost[x][nod] < dist[nod] && C[x][nod] - F[x][nod] > 0)
            {
                dist[nod] = dist[x] + cost[x][nod];
                TT[nod] = x;

                if(!use[nod])
                {
                    q.push(nod);
                    use[nod] = 1;
                }
            }
        }
        use[x] = 0;
    }

    if(dist[D] < inf)
    {

        for(int i =  D; i != S; i = TT[i])
        {
            F[TT[i]][i] += 1;
            F[i][TT[i]] -= 1;
        }

        return dist[D] ;

    }
    return 0;
}

int flux()
{
    int improve = 1, rez = 0;
    while(improve)
    {
        improve =  bellmanford();
        rez += improve;

    }
    return rez;
}
int main()
{
    read();
    build_graph();

    int sol = flux();

    for(int i = 2; i <= L + 1; i++)
        for(int j = L + 2; j <= N ; j++ )
            if(C[i][j] && F[i][j]){
                ret_muc[++K] = edge[i][j];
                break;
            }

    fout <<K <<" " << sol <<'\n';
    for(int i = 1; i <= K ;i++)
        fout << ret_muc[i] <<" ";
    fin.close();
    return 0;

}
