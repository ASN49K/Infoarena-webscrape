#include <fstream>
#include <queue>
#include <vector>
#include <cstring>
#define FIN 2000000001
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
queue <int> q;
vector <int> v[1011];
bool inq[1011];
int ante[1011],dist[1011],cap[1011][1011],muc[1011][1011],cost[1011][1011],d,n;
int heap[500],coord[500],nr;
void up(int k)
{
    if(k==1)
        return;
    if(dist[heap[k]]<dist[heap[k/2]])
    {
        swap(coord[heap[k]],coord[heap[k/2]]);
        swap(heap[k],heap[k/2]);
        up(k/2);
    }
}
void down(int k)
{
    int p=k*2;
    if(p>nr)
        return;
    if(p+1<=nr && dist[heap[p+1]]<dist[heap[p]])
        p++;
    if(dist[heap[k]]>dist[heap[p]])
    {
        swap(coord[heap[k]],coord[heap[p]]);
        swap(heap[k],heap[p]);
        down(p);
    }
}
bool inheap[1000];
int old[1000],real[1000],s;
bool dijkstra()
{
    for(int i=0;i<=d;i++)
        dist[i]=FIN;
    dist[s]=real[s]=0;
    nr++;
    heap[nr]=s;
    inheap[s]=1;
    while(nr)
    {
        int k=heap[1];
        heap[1]=heap[nr];
        inheap[k]=0;
        nr--;
        coord[heap[1]]=1;
        down(1);
        for(auto it=v[k].begin();it!=v[k].end();it++)
        {
            if(cap[k][*it]<=0)
                continue;
            int p=dist[k]+cost[k][*it]+old[k]-old[*it];
            if(p<dist[*it])
            {
                dist[*it]=p;
                real[*it]=real[k]+cost[k][*it];
                ante[*it]=k;
                if(inheap[*it]==0)
                {
                    nr++;
                    inheap[*it]=1;
                    heap[nr]=*it;
                    coord[*it]=nr;
                }
                up(coord[*it]);
            }
        }
    }
    return dist[d]!=FIN;
}
bool bellman_ford()
{
    for(int i=0;i<=d;i++)
        old[i]=FIN;
    old[s]=0;
    q.push(s);
    inq[s]=1;
    while(q.empty()==false)
    {
        int k=q.front();
        q.pop();
        inq[k]=0;
        for(auto it=v[k].begin();it!=v[k].end();it++)
        {
            if(cap[k][*it]<=0)
                continue;
            if(old[k]+cost[k][*it]>=old[*it])
                continue;
            old[*it]=old[k]+cost[k][*it];
            if(inq[*it]==0)
            {
                q.push(*it);
                inq[*it]=1;
            }
        }
    }
    return old[d]!=FIN;
}
int m,i,x,y,z,schimb=1,sol,p,M;
int main()
{
    f>>n>>m>>p;
    d=n+m+1;
    for(i=1;i<=p;i++)
    {
        f>>x>>y>>z;
        y=y+n;
        v[x].push_back(y);
        v[y].push_back(x);
        cost[x][y]=z;
        cost[y][x]=-z;
        cap[x][y]=1;
        v[0].push_back(x);
        v[x].push_back(0);
        cap[0][x]=1;
        v[y].push_back(d);
        v[d].push_back(y);
        cap[y][d]=1;
        muc[x][y]=i;
    }
    bellman_ford();
    while(dijkstra())
    {
        memcpy(old,real,sizeof(dist));
        M=FIN;
        for(i=d;i!=s;i=ante[i])
            M=min(M,cap[ante[i]][i]);
        sol=sol+M*real[d];
        for(i=d;i!=s;i=ante[i])
        {
            cap[ante[i]][i]=cap[ante[i]][i]-M;
            cap[i][ante[i]]=cap[i][ante[i]]+M;
        }
    }
    for(i=1;i<=n;i++)
        for(auto it=v[i].begin();it!=v[i].end();it++)
            if(*it!=0 && cap[i][*it])
                nr++;
    g<<nr<<" "<<sol<<'\n';
    for(i=1;i<=n;i++)
        for(auto it=v[i].begin();it!=v[i].end();it++)
            if(*it!=0 && cap[i][*it])
                g<<muc[i][*it]<<" ";
    return 0;
}
