#include<fstream>
#include<algorithm>
#include<vector>
#include<queue>
#define INF 2000000000
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
vector<int>a[604];
int N,s,d,flux,sol,r[604][604],z[604][604],tata[604],dist[604],dist2[604],realdist[604];
bool inq[604];
queue<int>q;
struct elem
{
    int x,dist;
    inline bool operator < (const elem &a) const
    {
        return dist>a.dist;
    }
};
priority_queue<elem>pq;
struct muchie
{
    int x,y;
};
muchie edge[50002];
inline bool dijkstra()
{
    int i,l,Z;
    elem p;
    for(i=1;i<=N;i++)
        dist[i]=INF,tata[i]=0;
    pq.push({s,0});
    dist[s]=0;
    dist2[s]=0;
    while(!pq.empty())
    {
        p=pq.top();
        pq.pop();
        if(p.dist==dist[p.x])
        {
            l=a[p.x].size();
            for(i=0;i<l;i++)
            {
                Z=realdist[p.x]-realdist[a[p.x][i]]+z[p.x][a[p.x][i]];
                if(r[p.x][a[p.x][i]]>0&&dist[a[p.x][i]]>dist[p.x]+Z)
                {
                    dist[a[p.x][i]]=dist[p.x]+Z;
                    dist2[a[p.x][i]]=dist2[p.x]+z[p.x][a[p.x][i]];
                    tata[a[p.x][i]]=p.x;
                    pq.push({a[p.x][i],dist[a[p.x][i]]});
                }
            }
        }
    }
    for(i=1;i<=N;i++)
        realdist[i]=dist2[i];
    return dist[d]!=INF;
}

inline void bellman_ford()
{
    int i,l,p;
    for(i=1;i<=N;i++)
        realdist[i]=INF;
    realdist[s]=0;
    q.push(s);
    inq[s]=1;
    while(!q.empty())
    {
        p=q.front();
        q.pop();
        inq[p]=0;
        l=a[p].size();
        for(i=0;i<l;i++)
        if(r[p][a[p][i]]>0&&realdist[a[p][i]]>realdist[p]+z[p][a[p][i]])
        {
            realdist[a[p][i]]=realdist[p]+z[p][a[p][i]];
            if(inq[a[p][i]]==0)
            {
                q.push(a[p][i]);
                inq[a[p][i]]=1;
            }
        }
    }
}

inline void fmcm()
{
    int i,flow,cost;
    bellman_ford();
    while(dijkstra()!=0)
    {
        flow=INF;
        for(i=d;i!=s;i=tata[i])
        {
            flow=min(flow,r[tata[i]][i]);
            if(flow==0)
                break;
        }
        if(flow!=0&&flow!=INF)
        {
            cost=0;
            for(i=d;i!=s;i=tata[i])
            {
                r[tata[i]][i]-=flow;
                r[i][tata[i]]+=flow;
                cost+=z[tata[i]][i];
            }
            flux+=flow;
            sol+=flow*cost;
        }
    }
}

int main()
{
    int n,m,i,x,y,zz,e;
    f>>n>>m>>e;
    for(i=1;i<=e;i++)
    {
        f>>x>>y>>zz;
        y+=n;
        a[x].push_back(y);
        a[y].push_back(x);
        r[x][y]+=1;
        z[x][y]=zz;
        z[y][x]=-zz;
        edge[i]={x,y};
    }
    s=n+m+1;
    for(i=1;i<=n;i++)
    {
        a[s].push_back(i);
        a[i].push_back(s);
        r[s][i]+=1;
    }
    d=n+m+2;
    for(i=n+1;i<=n+m;i++)
    {
        a[i].push_back(d);
        a[d].push_back(i);
        r[i][d]+=1;
    }
    N=n+m+2;
    fmcm();
    g<<flux<<" "<<sol<<'\n';
    for(i=1;i<=e;i++)
    if(r[edge[i].x][edge[i].y]==0)
        g<<i<<" ";
    return 0;
}
