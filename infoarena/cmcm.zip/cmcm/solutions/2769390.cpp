#include <bits/stdc++.h>
#define NMAX 605
#define INF 0x3f3f3f3f

using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int n, m, e, flux, ans, muchii[NMAX][NMAX], C[NMAX][NMAX], F[NMAX][NMAX], cost[NMAX][NMAX], d[NMAX], t[NMAX];
bitset <NMAX> v;
vector <int> edges[NMAX];
queue <int> q;

bool bf()
{
    bool ok = 0;
    for(int i = 0; i <= n + m + 1; i++)
        d[i] = INF, v[i] = 0;
    v[0] = 1;
    d[0] = 0;
    q.push(0);

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        v[nod] = 0;
        for(auto child : edges[nod])
            if(C[nod][child] > F[nod][child] && d[child] > d[nod] + cost[nod][child])
            {
                d[child] = d[nod] + cost[nod][child];
                t[child] = nod;
                if(!v[child])
                {
                    v[child] = 1;
                    q.push(child);
                }
            }
    }
    return (d[n + m + 1] != INF);
}

int main()
{
    f >> n >> m >> e;

    for(int i = 1; i <= e; i++)
    {
        int x, y, c;
        f >> x >> y >> c;
        edges[x].push_back(n + y);
        edges[n + y].push_back(x);
        edges[0].push_back(x);
        edges[x].push_back(0);
        edges[n + y].push_back(n + m + 1);
        edges[n + m + 1].push_back(n + y);
        muchii[x][y] = i;

        cost[x][y + n] = c;
        cost[y + n][x] = -c;
        C[x][y + n] = C[0][x] = C[y + n][n + m + 1] = 1;
    }

    while(bf())
    {
        int minim = INF;
        int k = n + m + 1;
        while(k != 0)
        {
            minim = min(minim, C[t[k]][k] - F[t[k]][k]);
            k = t[k];
        }

        k = n + m + 1;
        while(k != 0)
        {
            F[t[k]][k] += minim;
            F[k][t[k]] -= minim;
            k = t[k];
        }
        ans += d[n + m + 1] * minim;
        flux += minim;
    }

    g << flux << " " << ans << "\n";

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++)
            if(F[i][j + n] == 1)
                g << muchii[i][j] << " ";

    return 0;
}
