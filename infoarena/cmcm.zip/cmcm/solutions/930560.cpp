#include <fstream>
#include <vector>

using namespace std;
   
ifstream cin("cmcm.in");
ofstream cout("cmcm.out");

const int INF = int(1e9), nmax = 302;
int n, m, e;
int a[nmax][nmax], edgeIndex[nmax][nmax];

void khun() {
	vector<int> u (n + 1), v (m + 1), p (m + 1) , way(m + 1);
	for (int i = 1;i <= n;++i) {
		p[0] = i;
		int j0 = 0;
		vector<int> minv (m + 1,INF);
		vector<bool> used (m + 1,false);
		do {
			used[j0] = true;
			int i0 = p[j0],  delta = INF,  j1;
			for (int j = 1;j <= m;++j)
				if (!used[j] ) {
					int cur = a[i0][j] - u [i0] - v[j];
					if (cur < minv [j] )
						minv[j] = cur,  way [j] = j0;
					if (minv[j] < delta)
						delta = minv[j],  j1 = j;
				}
				for (int j = 0;j <= m; ++j)
					if (used[j])
						u[p[j]] += delta,  v [j] -= delta;
					else
						minv[j] -= delta;
				j0 = j1 ;
		} while (p[j0] != 0 );
		do {
			int j1 = way[j0];
			p[j0] = p[j1];
			j0 = j1;
		} while(j0);
	}
	vector<int> ans;
	for (int j = 1;j <= m; ++j)
		if(a[p[j]][j] != INF && edgeIndex[p[j]][j] > 0) {
			ans.push_back(edgeIndex[p[j]][j]);
			edgeIndex[p[j]][j] = 0;
		}
	cout<<ans.size()<<" "<<-v[0]<<"\n";
	for(int i = 0;i < (int)ans.size();i++) {
		cout<<ans[i]<<" ";
	}
}

int main()
{
	cin>>n>>m>>e;
	for(int i = 1;i <= n;i++) {
		for(int j = 1;j <= m;j++) {
			a[i][j] = INF;
		}
	}
	for(int x, y, z, i = 0;i < e;i++) {
		cin>>x>>y>>z;
		a[x][y] = z;
		edgeIndex[x][y] = i + 1;
	}
	khun();
    return 0;
}

