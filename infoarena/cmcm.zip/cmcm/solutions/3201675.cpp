#include<bits/stdc++.h>
using namespace std;
ifstream F("cmcm.in");
ofstream G("cmcm.out");
int d[602],v,t,i,x[300],P,Q;
short n,m,j,k,e[602][602],f[602][602],l,a[50001],b[50001],p[602],w,h[602][602],q[362404];
vector<short> g[602];
bool u[602];
int main()
{
    for(F>>n>>m>>t,i=1;i<=t;F>>a[i]>>b[i]>>j,g[a[i]].push_back(b[i]+n),g[b[i]+n].push_back(a[i]),h[a[i]][b[i]+n]=j,h[b[i]+n][a[i]]=-j,e[a[i]][b[i]+n]=1,++i);
    for(i=1;i<=n;g[0].push_back(i),g[i].push_back(0),e[0][i++]=1);
    for(i=n+1;i<=n+m;g[i].push_back(n+m+1),g[n+m+1].push_back(i),e[i++][n+m+1]=1);
    for(;;) {
        for(i=1;i<n+m+2;u[i]=0,d[i++]=2e9);
        for(P=Q=0,q[Q++]=0,u[0]=1;P<Q;u[i]=0,++P)
            for(i=q[P],k=g[i].size(),j=0;j<k;++j)
                if(e[i][g[i][j]]>f[i][g[i][j]]&&d[g[i][j]]>d[i]+h[i][g[i][j]])
                    if(d[g[i][j]]=d[i]+h[i][g[i][j]],p[g[i][j]]=i,!u[g[i][j]])
                        u[g[i][j]]=1,q[Q++]=g[i][j];
        if(d[n+m+1]==2e9)
            break;
        for(v+=d[n+m+1],i=n+m+1;i;++f[p[i]][i],--f[i][p[i]],i=p[i]);
    }
    for(i=1;i<=t;++i)
        if(e[a[i]][b[i]+n]&&f[a[i]][b[i]+n])
            x[w++]=i;
    for(G<<w<<' '<<v<<'\n',i=0;i<w;G<<x[i++]<<' ');
    return 0;
}
