#include <fstream>
#include <vector>
#include <cstring>
#include <queue>
#define MAX_N 710
#define inf 2000000000
#define pb push_back
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
int n, m, e, dest, sol, nr, improve,p,q,val;
int  tata[MAX_N], dist[MAX_N], use[MAX_N];
int C[MAX_N][MAX_N], F[MAX_N][MAX_N], edge[MAX_N][MAX_N];
vector <int> v[MAX_N], cost[MAX_N];

void build_graph()
{
    dest = n + m + 2;
    for (int i = 2; i <= n + 1; i++)
        {
        v[1].pb(i); cost[1].pb(0);
        v[i].pb(1); cost[i].pb(0);

        C[1][i] = 1;
    }
    for (int i = n + 2; i <= n + m + 1; i++)
    {
        v[i].pb(dest); cost[i].pb(0);
        v[dest].pb(i); cost[dest].pb(0);

        C[i][dest] = 1;
    }
}
int bellman_ford()
{
    queue <int> Q;
    int nod;
    for (int i = 1; i <= dest; i++) {
        dist[i] = inf;
        tata[i] = -1;
        use[i] = 0;
    }
    dist[1] = 0; use[1] = 1;
    Q.push(1);
    while (!Q.empty())
    {
        nod=Q.front();
        Q.pop();
        use[nod]=0;
        for (int i = 0; i < v[nod].size(); i++) {
            if (C[nod][v[nod][i]] > F[nod][v[nod][i]] && dist[v[nod][i]] > dist[nod] + cost[nod][i])
            {
                dist[v[nod][i]] = dist[nod] + cost[nod][i];
                tata[v[nod][i]] = nod;

                if (!use[v[nod][i]])
                {
                    Q.push(v[nod][i]);
                    use[v[nod][i]] = 1;
                }
            }
        }
    }
    if (dist[dest] < inf)
    {
        int flux = inf;
        for (int i = dest; i != 1; i = tata[i])
            flux = min(flux, C[tata[i]][i] - F[tata[i]][i]);

        for (int i = dest; i != 1; i = tata[i]) {
            F[tata[i]][i] += flux;
            F[i][tata[i]] -= flux;
        }

        return flux * dist[dest];
    }
    return 0;
}
int main() {
    f>>n>>m>>e;
    for (int i = 1; i <= e; i++)
    {

        f>>p>>q>>val;
        p++; q += n + 1;

        v[p].pb(q); cost[p].pb(val);
        v[q].pb(p); cost[q].pb(-val);

        edge[p][q] = i;
        C[p][q] = 1;
    }
    build_graph();
    improve = 1;
    while (improve) {
        improve = bellman_ford();
        sol += improve;
    }
    for (int i = 2; i <= n + 1; i++)
        for (int j = n + 2; j < dest; j++)
            if (C[i][j] && F[i][j]) {
                nr++;
                break;
            }
    g<<nr<<' '<<sol<<'\n';
    for (int i = 2; i <= n + 1; i++)
        for (int j = n + 2; j < dest; j++)
            if (C[i][j] && F[i][j])
            {
                g<<edge[i][j]<<' ';
                break;
            }

    return 0;
}
