// 0->1...m+n->m+n+1
#include <fstream>
#include <vector>
#include <queue>
#define NMAx 310
#define oo (1<<28)
using namespace std;
vector <short> G[2*NMAx],v;
queue <short> Q;
short n,m,S,D,Cost[NMAx][NMAx],Flux[NMAx][NMAx];
short edge[NMAx][NMAx],tata[NMAx];
int color,sol,dist[NMAx],in_queue[NMAx];

bool BF() {
	
	int i,nod,vecin;
	
	for(i=S;i<=D;i++)
		dist[i]=oo;
	color++;
	Q.push(S);
	dist[S]=0;
	
	while(!Q.empty()) {
		nod=Q.front();
		Q.pop();
		in_queue[nod]=0;
		for(i=0;i<G[nod].size();i++) {
			vecin=G[nod][i];
			if(Flux[nod][vecin]>0&&dist[vecin]>dist[nod]+Cost[nod][vecin]) {
				dist[vecin]=dist[nod]+Cost[nod][vecin];
				tata[vecin]=nod;
				if(in_queue[vecin]!=color) {
					Q.push(vecin);
					in_queue[vecin]=color;
					}
				}
			}
		}
	
	if(dist[D]==oo)
		return 0;
	return 1;
	
}
void constr() {
	
	int i;
	
	S=0;
	D=n+m+1;
	
	for(i=1;i<=n;i++) {
		G[S].push_back(i);
		//G[i].push_back(S);
		Flux[S][i]=1;
		}
	
	for(i=n+1;i<D;i++) {
		G[i].push_back(D);
		//G[D].push_back(i);
		Flux[i][D]=1;
		}
	
}
void citire() {
	
	int i,x,y,c,e;
	ifstream in("cmcm.in");
	in>>n>>m>>e;
	for(i=1;i<=e;i++) {
		in>>x>>y>>c;
		y+=n;
		G[x].push_back(y);
		G[y].push_back(x);
		Cost[x][y]=c;
		Cost[y][x]=-c;
		edge[x][y]=i;
		Flux[x][y]=1;
		}
	in.close();
	
}
void afis() {
	
	int i,j,nr=0;
	ofstream out("cmcm.out");
	
	for(i=1;i<=n;i++)
		for(j=n+1;j<D;j++)
			if(!Flux[i][j]&&edge[i][j]) {
				nr++;
				v.push_back(edge[i][j]);
				break;
				}
			
	out<<nr<<' '<<sol<<'\n';
	for(i=0;i<v.size();i++)
		out<<v[i]<<' ';
	out<<'\n';
	out.close();
	
}
int main() {
	
	int flux,nod;
	citire();
	constr();
	
	while(BF()) {
		
		flux=oo;
		for(nod=D;nod!=S;nod=tata[nod])
			flux=min(flux,(int)Flux[tata[nod]][nod]);
		
		for(nod=D;nod!=S;nod=tata[nod]) {
			Flux[nod][tata[nod]]+=flux;
			Flux[tata[nod]][nod]-=flux;
			}
		
		sol+=flux*dist[D];
		}
	
	afis();
	
	return 0;
}
