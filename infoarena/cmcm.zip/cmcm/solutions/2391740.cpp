#include<cstdio>
#define N 15000000
int n,m,z,i,j,p,q,t,l,r,k,e,c[602][602],f[602][602],a[50001],b[50001],u[602],v[602][602],x[50001],w[50001],g[602],ro=-1,re;
char ra[N];
inline int A()
{
  	int s=0,b=1;
  	ro++;
  	if(ra[ro]=='-')
        b=-1,ro++;
  	for(;ra[ro]>='0'&&ra[ro]<='9';ro++)
  		s=s*10+ra[ro]-'0';
  	return s*b;
}
inline void S(int x,char c)
{
    if(x<0)
        ra[re++]='-',x=-x;
    int i,d=x>999999999?10:x>99999999?9:x>9999999?8:x>999999?7:x>99999?6:x>9999?5:x>999?4:x>99?3:x>9?2:1;
    for(i=d-1;i>=0;x/=10,i--)
        ra[re+i]=x%10+48;
    ra[re+d]=c,re+=d+1;
}
int main()
{
	freopen("cmcm.in","r",stdin),freopen("cmcm.out","w",stdout),fread(ra,1,N,stdin),n=A(),m=A(),k=A();
	for(i=1;i<=k;i++)
    	a[i]=A(),b[i]=A(),z=A(),c[a[i]][b[i]+n+1]=1,v[a[i]][b[i]+n+1]=z,v[b[i]+n+1][a[i]]=-z;
	for(i=1;i<=n;i++)
    	c[0][i]=1;
	for(i=n+2;i<=n+m+1;i++)
    	c[i][n+1]=1;
	while(1)
    {
		for(i=1;i<=n+m+1;i++)
            u[i]=0,g[i]=50001;
       	for(g[0]=p=w[0]=0,q=1;p<q;)
		   	for(t=w[p++],j=(t&&t<=n?(n+1):1),z=(t&&t<=n?(n+m+1):(n+1)),i=j;i<=z;i++)
                if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                    w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];
       	if(!u[n+1])
            break;
       	for(l=n+1;l;l=u[l])
            f[u[l]][l]++,f[l][u[l]]--;
       	e+=g[n+1];
	}
	for(i=1;i<=k;i++)
        if(f[a[i]][b[i]+n+1]==1)
            x[r++]=i;
	S(r,' '),S(e,'\n');
	for(i=0;i<r;i++)
        S(x[i],' ');
    fwrite(ra,1,re,stdout);
}
