#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int n, m, nod, sol, k, s, d, x, y, c, z, i, j, capacitate[360][360], cost[360][360], flux[360][360], f[360], t[360];
int v[360], dist[360], ordine[360][360];
vector <int> a[360];
deque <int> q;

int BellmanFord(){
    /// cautam drumul de cost minim de la s la d
    /// pe fiecare muchie trebuie sa avem capacitate > flux
    int nr, vecin;
    int ok=0;
    for(int ii=0; ii<=n+m+1; ii++){
        v[ii]=0;
        dist[ii]=1000000000;
    }
    q.clear();
    q.push_back(s);
    v[s]=1;
    dist[s]=0;
    while(!q.empty()){
        nr=q.front();
        if(nr==d){
            ok=1;
        }
        q.pop_front();
        v[nr]=0;
        for(int ii=0; ii<a[nr].size(); ii++){
            vecin=a[nr][ii];
            if(dist[vecin]>dist[nr]+cost[nr][vecin] && flux[nr][vecin]<capacitate[nr][vecin]){
                dist[vecin]=dist[nr]+cost[nr][vecin];
                t[vecin]=nr;
                if(v[vecin]==0){
                    v[vecin]=1;
                    q.push_back(vecin);
                    if(vecin==d){
                        ok=1;
                    }
                }
            }
        }
    }
    return ok;
}


int main(){
    fin>>n>>m>>k;
    s=0;
    d=n+m+1;
    for(i=1; i<=k; i++){
        fin>>x>>y>>z;
        y+=n;
        a[x].push_back(y);
        a[y].push_back(x);
        capacitate[x][y]=1;
        cost[x][y]=z;
        cost[y][x]=-z;
        ordine[x][y]=i;
        ordine[y][x]=i;
    }
    for(i=1; i<=n; i++){
        a[0].push_back(i);
        a[i].push_back(0);
        capacitate[0][i]=1;
    }
    for(i=n+1; i<=n+m; i++){
        a[n+m+1].push_back(i);
        a[i].push_back(n+m+1);
        capacitate[i][n+m+1]=1;
    }
    while(BellmanFord()){
        nod=d;
        while(nod!=0){
            flux[t[nod]][nod]++;
            flux[nod][t[nod]]--;
            nod=t[nod];
        }
        sol+=dist[d];
    }
    k=0;
    for(i=1; i<=n; i++){
        for(j=n+1; j<=n+m; j++){
            if(flux[i][j]==1){
                k++;
            }
        }
    }
    fout<<k<<" "<<sol<<"\n";
    for(i=1; i<=n; i++){
        for(j=n+1; j<=n+m; j++){
            if(flux[i][j]==1){
                fout<<ordine[i][j]<<" ";
            }
        }
    }

}
