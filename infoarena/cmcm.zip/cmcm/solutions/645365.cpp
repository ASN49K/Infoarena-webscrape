#include<cstdio>
#include<vector>
#include<bitset>
#include<queue>
#define infile "cmcm.in"
#define outfile "cmcm.out"
#define n_max 605
#define INF 1<<30
#define pb push_back
#define mkp make_pair
#define nod first
#define cost second
#define FOR(g) \
    for( vector < pair < int,int > > ::iterator it = g.begin(); it!=g.end(); ++it)
using namespace std;



vector < pair< int, int> > v[n_max];

int C[n_max][n_max], F[n_max][n_max], edge[n_max][n_max];

int T[n_max], Dist[n_max];

bitset<n_max> uz;

int N, M;

int sursa, dest, Sol;



void citeste()
{
    freopen(infile,"r",stdin);
    
    int E, x, y, cost;
    
    scanf("%d %d %d",&N, &M, &E);
    
    for(int i=1;i<=E;i++)
    {
       scanf("%d %d %d",&x,&y,&cost);
        
       x++; y+=N+1;
       
       v[x].pb(mkp(y,cost));
       v[y].pb(mkp(x,-cost));
       
       edge[x][y] = i;
       C[x][y] = 1;
    }
    
    
    sursa = 1;
    for(int i=2;i<=N+1;i++)
    {
        v[sursa].pb(mkp(i,0));
        v[i].pb(mkp(sursa,0));
        C[sursa][i] = 1;
    }
    
    dest = N+M+2;
    for(int i=N+2;i<=N+M+1;i++)
    {
        v[dest].pb(mkp(i,0));
        v[i].pb(mkp(dest,0));
        C[i][dest] = 1;
    }

    fclose(stdin);
}



int BellmanFord()
{  
    queue < int > q;

    for (int i = 1; i <= dest; i++)
    {
        Dist[i] = INF;
        uz[i] = 0;
        T[i] = 0;
    }    
        
    Dist[sursa] = 0;
    uz[sursa] = 1;
    q.push(sursa);
    
    while(!q.empty())
    {
        int x = q.front();
        q.pop();
        uz[x] = 0;
        
        FOR(v[x])
            if(C[x][it->nod] - F[x][it->nod] > 0 && Dist[x] + it->cost < Dist[it->nod] )
            {
                Dist[it->nod] = Dist[x] + it->cost;
                
                if(!uz[it->nod])
                    q.push(it->nod), uz[it->nod] = 1;
                
                T[it->nod] = x;
            }
    }

    if(Dist[dest] < INF)
    {
        int flux = INF;
        
        for(int i = dest; i!=sursa; i = T[i])
            flux = min(flux, C[T[i]][i] - F[T[i]][i]);
        
        for(int i = dest; i!=sursa; i = T[i])
            F[T[i]][i] ++, F[i][T[i]]--;
        
        return flux * Dist[dest];
    }

    return 0;
}


void rezolva()
{
	int ok = 1;
	
	while(ok)
	{
		ok = BellmanFord();
		Sol += ok;
	}
}



void afiseaza()
{
    freopen(outfile,"w",stdout);
    
	int nrm = 0;
	
	for(int i=2;i<=N+1;i++)
		for(int j=N+2;j<=N+M+1;j++)
			if(C[i][j] && F[i][j])
				{ nrm++; break; }
	
    printf("%d %d\n", nrm, Sol);
	
	for(int i=2;i<=N+1;i++)
		for(int j=N+2;j<=N+M+1;j++)
			if(C[i][j] && F[i][j])
				{ printf("%d ",edge[i][j]); break; }
    
	printf("\n");
	
    fclose(stdout);
}


int main()
{
    citeste();
	
	rezolva();
    
    afiseaza();
    
    return 0;
}
