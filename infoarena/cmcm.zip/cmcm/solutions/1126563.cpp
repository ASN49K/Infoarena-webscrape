#include<cstdio>
#include<vector>
#include<deque>
#include<bitset>
#include<algorithm>
using namespace std;
const int nmax = 605;
const int inf = (1<<31)-1;
int i,j,n,m,e,x,y,z,s,d,mf,edge[nmax][nmax],dist[nmax],f[nmax],c[nmax][nmax],cap[nmax][nmax],flow[nmax][nmax],cuplaj,cost;
vector<int> v[nmax];
deque<int> q;
bitset<nmax> inq;
bool bf()
{
    dist[0]=0; q.push_back(0); inq[0]=1;
    for(i=1;i<=n+m+1;i++) dist[i]=inf;
    while(!q.empty())
    {
        x=q.front(); q.pop_front(); inq[x]=0;
        for(vector<int>::iterator it=v[x].begin();it!=v[x].end();it++)
            if(dist[x]+c[x][*it]<dist[*it] && flow[x][*it]<cap[x][*it])
            {
                dist[*it]=dist[x]+c[x][*it];
                f[*it]=x;
                if(!inq[*it])
                {
                    inq[*it]=1;
                    q.push_back(*it);
                }
            }
    }
    return dist[d]!=inf;
}
int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d%d%d",&n,&m,&e);
	for(i=1;i<=e;i++)
	{
	    scanf("%d%d%d",&x,&y,&z); y+=n;
	    edge[x][y]=i;
	    v[x].push_back(y); v[y].push_back(x);
	    c[x][y]=z; c[y][x]=-z;
	    cap[x][y]=1; cap[y][x]=0;
	}
	s=0; d=n+m+1; f[s]=s;
	for(i=1;i<=n;i++)
	{
	    v[s].push_back(i); v[i].push_back(s);
	    c[s][i]=0; c[i][s]=0;
	    cap[s][i]=1; cap[i][s]=0;
	}
	for(i=n+1;i<=n+m;i++)
	{
	    v[i].push_back(d); v[d].push_back(i);
	    c[i][d]=0; c[d][i]=0;
	    cap[i][d]=1; cap[d][i]=0;
	}
	while(bf())
	{
        for(mf=inf,x=d;f[x]!=x;x=f[x])
            mf=min(mf,cap[f[x]][x]-flow[f[x]][x]);
        for(x=d;f[x]!=x;x=f[x])
        {
            flow[f[x]][x]+=mf;
            flow[x][f[x]]-=mf;
        }
        cuplaj+=mf; cost+=dist[d];
	}
	printf("%d %d\n",cuplaj,cost);
	for(i=1;i<=n;i++)
        for(j=n+1;j<=n+m;j++)
            if(flow[i][j]) printf("%d ",edge[i][j]);
	return 0;
}
