#include<algorithm>
#include<bitset>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<deque>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<unordered_map>
#include<unordered_set>
#include<utility>
#include<vector>

using namespace std;

#ifdef HOME
const string inputFile = "input.txt";
const string outputFile = "output.txt";
#else
const string problemName = "cmcm";
const string inputFile = problemName + ".in";
const string outputFile = problemName + ".out";
#endif

const int NMAX = 300 + 5;
const int INF = (1 << 29);

int N, M, E;
vector<int> V[2 * NMAX];
int C[2 * NMAX][2 * NMAX];
int F[2 * NMAX][2 * NMAX];
int D[2 * NMAX][2 * NMAX];
int P[2 * NMAX][2 * NMAX];
int dist[2 * NMAX];
int dad[2 * NMAX];
int source, sink, maxflow, mincost;
deque<int> Q;
bitset<2 * NMAX> viz;

int bf() {
    int x, i;

    Q.clear();
    viz = 0;

    for(i = source; i <= sink; i++)
        dist[i] = INF;

    dist[source] = 0;
    Q.push_back(source);
    viz[source] = 1;

    while(!Q.empty()) {
        x = Q.front();
        Q.pop_front();
        viz[x] = 0;

        for(auto y : V[x])
            if(F[x][y] < C[x][y] && dist[x] + D[x][y] < dist[y]) {
                dist[y] = dist[x] + D[x][y];
                dad[y] = x;

                if(!viz[y]) {
                    Q.push_back(y);
                    viz[y] = 1;
                }
            }
    }

    return (dist[sink] != INF);
}

int main() {
    int i, j, x, y, z, v;

#ifndef ONLINE_JUDGE
    freopen(inputFile.c_str(), "r", stdin);
    freopen(outputFile.c_str(), "w", stdout);
#endif

    scanf("%d%d%d", &N, &M, &E);

    source = 0;
    sink = N + M + 1;

    for(i = 1; i <= E; i++) {
        scanf("%d%d%d", &x, &y, &z);

        V[x].push_back(N + y);
        V[N + y].push_back(x);

        C[x][N + y] = 1;

        D[x][N + y] = z;
        D[N + y][x] = -z;

        P[x][N + y] = i;
    }

    for(i = 1; i <= N; i++) {
        V[source].push_back(i);
        V[i].push_back(source);

        C[source][i] = 1;
    }

    for(i = 1; i <= M; i++) {
        V[N + i].push_back(sink);
        V[sink].push_back(N + i);

        C[N + i][sink] = 1;
    }

    while(bf()) {
        v = INF;

        for(x = sink; x != source; x = dad[x])
            v = min(v, C[dad[x]][x] - F[dad[x]][x]);

        for(x = sink; x != source; x = dad[x]) {
            F[dad[x]][x] += v;
            F[x][dad[x]] -= v;
        }

        maxflow += v;
        mincost += v * dist[sink];
    }

    printf("%d %d\n", maxflow, mincost);

    for(i = 1; i <= N; i++)
        for(j = 1; j <= M; j++)
            if(F[i][N + j] == C[i][N + j] && F[i][N + j] == 1)
                printf("%d ", P[i][N + j]);

    return 0;
}
