#include <fstream>
#include <deque>
#include <vector>
#define INF 1000000010
#define DIM 620
using namespace std;

int C[DIM][DIM];
int F[DIM][DIM];
int Z[DIM][DIM];

int U[DIM];
int T[DIM];
int D[DIM];
int M[DIM][DIM];
vector<int> L[DIM];
deque<int> q;

int n, m, s, d, i, y, x, z, c, minim, u, cost, flux, e;

int bf() {

    int nod, vecin;

    for (int i=1;i<=d;i++) {
        D[i] = INF;
        U[i] = 0;
    }
    D[s] = 0;
    U[s] = 1;
    q.clear();
    q.push_back(s);
    while (!q.empty()) {
        nod = q.front();
        q.pop_front();
        U[nod] = 0;

        for (int i=0;i<L[nod].size();i++) {
            vecin = L[nod][i];
            if (C[nod][vecin] > F[nod][vecin] && D[vecin] > D[nod] + Z[nod][vecin]) {
                D[vecin] = D[nod] + Z[nod][vecin];
                T[vecin] = nod;
                if (U[vecin] == 0) {
                    q.push_back(vecin);
                    U[vecin] = 1;
                }
            }
        }
    }
    if (D[d] != INF)
        return 1;
    else
        return 0;
}


int main () {
    ifstream fin ("cmcm.in");
    ofstream fout("cmcm.out");
    s = 0;
    fin>>n>>m>>e;
    for (i=1;i<=e;i++) {
        fin>>x>>y>>z;
        C[x][n+y] = 1;
        Z[x][n+y] = z;
        M[x][n+y] = i;
        Z[n+y][x] = -z; // pe munchia inversa se pune - costul muchiei date
        L[x].push_back(n+y);
        L[n+y].push_back(x);
    }

    for (i=1;i<=n;i++) {
        // muchie intre 0 si i
        C[0][i] = 1;
        Z[0][i] = Z[i][0] = 0;
        L[0].push_back(i);
        L[i].push_back(0);
    }
    d = n+m+1;
    for (i=1;i<=m;i++) {
        C[n+i][d] = 1;
        Z[n+i][d] = Z[d][n+i] = 0;
        L[n+i].push_back(d);
        L[d].push_back(n+i);
    }

    while (bf()) {
        minim = INF;
        u = d;
        while (u!=s) {
            if (minim  > C[ T[u] ][u] - F[ T[u] ][u])
                minim  = C[ T[u] ][u] - F[ T[u] ][u];
            u = T[u];
        }
        u = d;
        while (u!=s) {
            cost += minim * Z[ T[u] ][u];
            F[ T[u] ][u] += minim;
            F[u][ T[u] ] -= minim;
            u = T[u];
        }
        flux += minim;
    }

    fout<<flux<<" "<<cost<<"\n";
    for (i=1;i<=n;i++)
        for (int j=n+1;j<=n+m;j++)
            if (F[i][j] == 1)
                fout<<M[i][j]<<" ";
    return 0;
}

