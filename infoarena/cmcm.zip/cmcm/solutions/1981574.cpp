#include<bits/stdc++.h>
#define pb push_back
#define INF 1000000000
using namespace std;
typedef long long ll;
int n,m,e,x,y,c;
ll a[1010][1010],ind[1010][1010],ret;
vector<int> sol;

int hungarian() { //given a[n][m] matrix of costs
  vector<int> u (n+1), v (m+1), p (m+1), way (m+1);
  for (int i=1; i<=n; ++i) {
    p[0] = i; int j0 = 0;
    vector<int> minv (m+1, INF), used (m+1, 0);
    do {
      used[j0] = true;
      int i0 = p[j0],  delta = INF,  j1;
      for (int j=1; j<=m; ++j) {
        if (!used[j]) {
          int cur = a[i0][j]-u[i0]-v[j];
          if (cur < minv[j]) minv[j] = cur,  way[j] = j0;
          if (minv[j] < delta) delta = minv[j],  j1 = j;
        }
      }
      for (int j=0; j<=m; ++j) {
        if (used[j]) u[p[j]] += delta,  v[j] -= delta;
        else minv[j] -= delta;
      }
      j0 = j1;
    } while (p[j0] != 0);
    do {
      int j1 = way[j0]; p[j0] = p[j1]; j0 = j1;
    } while (j0);
  }
  vector<int> ans (n+1);
  for (int j=1; j<=m; ++j) ans[p[j]] = j;
  ret = -v[0];
  for(int i=1;i<=n;++i) {
    if(a[i][ans[i]] == INF) {
      ret -= INF; 
      continue;
      
    }
    sol.pb(ind[i][ans[i]]);
  }
  return -v[0];
}

int main() {
  freopen("cmcm.in","r",stdin);
  freopen("cmcm.out","w",stdout);
  scanf("%d%d%d",&n,&m,&e);
  int b = 0;
  if(n > m) { swap(n,m); b=1;}
  for(int i=1;i<=n;++i) {
    for(int j=1;j<=m;++j) {
      a[i][j] = INF;
    }
  }
  for(int i=1;i<=e;++i) {
    int x,y,c;
    scanf("%d%d%d",&x,&y,&c);
    if(b) swap(x,y);
    a[x][y] = c;
    ind[x][y] = i;
  }
  hungarian();
  cout<<sol.size()<<" "<<ret<<"\n";
  for(auto e: sol) cout<<e<<" ";
}
