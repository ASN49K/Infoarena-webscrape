#include <vector>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>

using namespace std;

//#include <iostream>
#include <fstream>
ifstream cin ("cmcm.in");ofstream cout ("cmcm.out");

const int inf = 1e9;

vector < int > gr[610];
int cost[610][610];
int val[610][610];
int flow[610][610];
int S , D , n , m , e;
int dp[610];
int dad[610];
int used[610];
int ind[610][610];

queue < int > q;

int flux(){
    for (auto &x : dp){
        x = inf;
    }
    dp[S] = 0;
    q.push(S);
    while (!q.empty()){
        int now = q.front();
        used[now] = 0;
        q.pop();
        for (auto &x : gr[now]){
            if (val[now][x] > flow[now][x] && dp[x] > dp[now] + cost[now][x]){
                dad[x] = now;
                dp[x] = dp[now] + cost[now][x];
                if (!used[x]){
                    used[x] = 1;
                    q.push(x);
                }
            }
        }
    }
    if (dp[D] != inf){
        return 1;
    }
    return 0;
}

int main() {

    //freopen("input", "r", stdin);freopen("output", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cout << setprecision(10) << fixed;
    mt19937 rng((long long)(new char));
    srand(time(nullptr));

    cin>>n>>m>>e;

    S = 0;
    D = n+m+1;

    for (int i=1; i<=n; i++){
        gr[S].push_back(i);
        gr[i].push_back(S);
        val[S][i] = 1;
    }
    for (int i=n+1; i<=n+m; i++){
        gr[i].push_back(D);
        gr[D].push_back(i);
        val[i][D] = 1;
    }

    for (int i=1; i<=e; i++){
        int a , b , c;
        cin>>a>>b>>c;
        b+=n;
        ind[a][b] = i;
        gr[a].push_back(b);
        gr[b].push_back(a);
        val[a][b] = 1;
        cost[a][b] = c;
        cost[b][a] = -c;
    }

    int ans = 0;
    int cont = 0;

    while (flux()){
        cont++;
        int now = D;
        int MIN = inf;
        while (now != S){
            //cout<<now<<" ";
            MIN = min(MIN , val[dad[now]][now] - flow[dad[now]][now]);
            now = dad[now];
        }
        //cout<<'\n';
        now = D;
        while (now != S){
            flow[dad[now]][now] += MIN;
            flow[now][dad[now]] -= MIN;
            ans += MIN * cost[dad[now]][now];
            now = dad[now];
        }
    }

    cout<<cont<<" "<<ans<<'\n';
    for (int i=1; i<=n; i++){
        for (int j=n+1; j<=n+m; j++){
            if (flow[i][j]){
                cout<<ind[i][j]<<" ";
            }
        }
    }

    return 0;
}