#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

#define NMAX 605
#define INF 0x3f3f3f3f

bool viz[NMAX];
int C[NMAX][NMAX], F[NMAX][NMAX], M[NMAX][NMAX], V[NMAX], T[NMAX], D, S, cst_sol, sol, n, m, k;
vector < pair <int, int> > G[NMAX];
queue <int> Q;

bool bellman_ford ();
void citire (), flux_cmin (), afisare ();

int main () {
	
	citire ();
	
	flux_cmin ();
	
	afisare ();
}

bool bellman_ford () {
	
	int nod, fiu, cst;
	vector < pair <int, int> >::iterator it;
	
	memset (V, INF, sizeof (V)); memset (viz, 0, sizeof (viz)); memset (T, -1, sizeof (T));
	
	Q.push (S), V[S] = 0, viz[S] = 1;
	while (!Q.empty ()) {
		nod = Q.front ();
		for (it = G[nod].begin (); it != G[nod].end (); it++) {
			fiu = it -> first, cst = it -> second;
			
			if (C[nod][fiu] > F[nod][fiu] && V[nod] + cst < V[fiu]) {
				V[fiu] = V[nod] + cst;
				
				T[fiu] = nod;
				
				if (!viz[fiu]) Q.push (fiu), viz[fiu] = 1;
			}
		}
		
		Q.pop (), viz[nod] = 0;
	}
	
	if (V[D] != INF) return 1;
	return 0;
}

void flux_cmin () {
	
	int minim, nod;
	
	while (bellman_ford ()) {
		
		minim = INF;
		
		for (nod = D; T[nod] != -1; nod = T[nod])
			minim = min (minim, C[ T[nod] ][nod] - F[ T[nod] ][nod]);
		
		for (nod = D; T[nod] != -1; nod = T[nod]) {
			F[ T[nod] ][nod] += minim;
			F[nod][ T[nod] ] -= minim;
		}
		
		sol += minim;
		cst_sol += V[D] * minim;
	}
}

void citire () {
	
	freopen ("cmcm.in", "r", stdin);
	
	int i, x, y, c;
	
	scanf ("%d %d %d", &n, &m, &k);
	
	for (i = 1; i <= k; i++) {
		scanf ("%d %d %d", &x, &y, &c);
		G[x].push_back (make_pair (n + y, c)), G[n + y].push_back (make_pair (x, -c));
		C[x][n + y] = 1; M[x][n + y] = i;
	}
	
	S = 0, D = n + m + 1;	
	
	for (i = 1; i <= n; i++) {
		G[S].push_back (make_pair (i, 0));
		C[S][i] = 1;
	}
	
	for (i = 1; i <= m; i++) {
		G[n + i].push_back (make_pair (D, 0));
		C[n + i][D] = 1;
	}
}

void afisare () {
	
	freopen ("cmcm.out", "w", stdout);
	
	int i, j;
	
	printf ("%d %d\n", sol, cst_sol);
	
	for (i = 1; i <= n; i++)
		for (j = n + 1; j <= n + m + 1; j++)
			if (C[i][j] && F[i][j])
				printf ("%d ", M[i][j]);
}