#include <fstream>
#include <vector>
#include <queue>
#define MAXN 610
using namespace std;
int m,n,S,D;
queue<int>Q;
vector<int>g[MAXN];
int C[MAXN][MAXN],F[MAXN][MAXN],Cost[MAXN][MAXN],d[MAXN],p[MAXN],edge[MAXN][MAXN],fmin,cost,cuplaj;
bool inq[MAXN];
bool drum()
{
    int i,x;
    for(i=1;i<=m+n+1;i++) d[i]=int(2e9);
    d[S]=0;
    Q.push(S); inq[S]=1;
    while(!Q.empty())
    {
        x=Q.front(); inq[x]=0; Q.pop();
        for(i=0;i<g[x].size();i++)
        if(d[g[x][i]]>d[x]+Cost[x][g[x][i]] and F[x][g[x][i]]!=C[x][g[x][i]])
        {
            d[g[x][i]]=d[x]+Cost[x][g[x][i]];
            p[g[x][i]]=x;
            if(!inq[g[x][i]])
            {
                inq[g[x][i]]=1;
                Q.push(g[x][i]);
            }
        }
    }
    return (d[D]!=int(2e9));
}
int main()
{
    int i,j,x,y,z,e;
    ifstream fi("cmcm.in");
    ofstream fo("cmcm.out");
    fi>>n>>m>>e;
    S=0; D=n+m+1;
    for(i=1;i<=n;i++)
    {
        g[S].push_back(i);
        g[i].push_back(S);
        C[S][i]=1;
        Cost[S][i]=Cost[i][S]=0;
    }
    for(i=1;i<=m;i++)
    {
        g[D].push_back(i+n);
        g[i+n].push_back(D);
        C[i+n][D]=1;
        Cost[D][i+n]=Cost[i+n][D]=0;
    }
    for(i=1;i<=e;i++)
    {
        fi>>x>>y>>z;
        g[x].push_back(y+n);
        g[y+n].push_back(x);
        C[x][y+n]=1;
        edge[x][y+n]=i;
        Cost[x][y+n]=z;
        Cost[y+n][x]=-z;
    }
    while(drum())
    {
        fmin=int(2e9);
        for(i=D;i!=S;i=p[i]) fmin=min(fmin,C[p[i]][i]-F[p[i]][i]);
        for(i=D;i!=S;i=p[i])
        {
            F[p[i]][i]+=fmin;
            F[i][p[i]]-=fmin;
        }
        cost+=fmin*d[D];
    }
    for(i=1;i<=n;i++)
    for(j=1;j<=m;j++)
    if(F[i][j+n]) cuplaj++;
    fo<<cuplaj<<" "<<cost<<"\n";
    for(i=1;i<=n;i++)
    for(j=1;j<=m;j++)
    if(F[i][j+n]) fo<<edge[i][j+n]<<" ";
    fo<<"\n";
    return 0;
}
















