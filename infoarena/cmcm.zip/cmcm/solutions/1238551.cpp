#include <fstream>
#include <iostream>
#include <vector>
#include <bitset>
#include <string.h>
#include <algorithm>
#include <iomanip>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <set>
#include <map>
#include <string>
#include <queue>
#include <deque>

using namespace std;

const char infile[] = "cmcm.in";
const char outfile[] = "cmcm.out";

ofstream fout(outfile);

const int MAXN = 2*305;
const int oo = 0x3f3f3f3f;

typedef vector<pair<int, int> > Graph[MAXN];
typedef vector<pair<int, int> > :: iterator It;

const inline int min(const int &a, const int &b) { if( a > b ) return b;   return a; }
const inline int max(const int &a, const int &b) { if( a < b ) return b;   return a; }
const inline void Get_min(int &a, const int b)    { if( a > b ) a = b; }
const inline void Get_max(int &a, const int b)    { if( a < b ) a = b; }

int N, M, E;
Graph G;
int C[MAXN][MAXN], F[MAXN][MAXN], Father[MAXN], dp[MAXN];
queue <int> Q;
bitset <MAXN> inQ;

const int lim = (1 << 20);
char buff[lim];
int pos;

inline void get(int &x) {
    x = 0;
    char sgn = '+';
    while(!('0' <= buff[pos] && buff[pos] <= '9')) {
        sgn = buff[pos];
        if(++ pos == lim) {
            fread(buff, 1, lim, stdin);
            pos = 0;
        }
    }
    while('0' <= buff[pos] && buff[pos] <= '9') {
        x = x * 10 + buff[pos] - '0';
        if(++ pos == lim) {
            fread(buff, 1, lim, stdin);
            pos = 0;
        }
    }
    if(sgn == '-')
        x = -x;
}

inline bool BF(Graph &G, int Source, int Sink) {
    Q.push(Source);
    inQ[Source] = 1;
    memset(dp, oo, sizeof(dp));
    dp[Source] = 0;
    while(!Q.empty()) {
        int Node = Q.front();
        Q.pop();
        inQ[Node] = 0;
        for(It it = G[Node].begin(), fin = G[Node].end(); it != fin ; ++ it)
            if(C[Node][it->first] - F[Node][it->first] > 0 && dp[it->first] > dp[Node] + it->second) {
                dp[it->first] = dp[Node] + it->second;
                Father[it->first] = Node;
                if(inQ[it->first])
                    continue;
                Q.push(it->first);
                inQ[it->first] = 1;
            }
    }
    return dp[Sink] != oo;
}

inline pair<int, int> getMinCostMaxFlow(Graph &G, int Source, int Sink) {
    int maxMatch = 0, maxMatchCost = 0;
    while(BF(G, Source, Sink)) {
        int bottleNeck = oo;
        for(int i = Sink ; i != Source ; i = Father[i])
            bottleNeck = min(bottleNeck, C[Father[i]][i] - F[Father[i]][i]);
        for(int i = Sink ; i != Source ; i = Father[i]) {
            F[Father[i]][i] += bottleNeck;
            F[i][Father[i]] -= bottleNeck;
        }
        maxMatch += bottleNeck;
        maxMatchCost += bottleNeck * dp[Sink];
    }
    return make_pair(maxMatch, maxMatchCost);
}

int main() {
    freopen(infile, "r", stdin);
    get(N);
    get(M);
    get(E);
    vector <pair<int, int> > Edges;
    for(int i = 0 ; i < E ; ++ i) {
        int x, y, z;
        get(x);
        get(y);
        get(z);
        Edges.push_back(make_pair(x, y));
        G[x].push_back(make_pair(y + N, z));
        G[y + N].push_back(make_pair(x,-z));
        C[x][y + N] = 1;
    }
    int Source = 0, Sink = N + M + 1;
    for(int i = 1 ; i <= N ; ++ i) {
        G[Source].push_back(make_pair(i, 0));
        G[i].push_back(make_pair(Source, 0));
        C[Source][i] = 1;
    }
    for(int i = N + 1 ; i <= N + M ; ++ i) {
        G[i].push_back(make_pair(Sink, 0));
        G[Sink].push_back(make_pair(i, 0));
        C[i][Sink] = 1;
    }
    pair<int, int> Ans = getMinCostMaxFlow(G, Source, Sink);
    fout << Ans.first << ' ' << Ans.second << '\n';
    for(vector <pair<int, int> > :: iterator it = Edges.begin(), fin = Edges.end(); it != fin ; ++ it)
        if(F[it->first][it->second + N])
            fout << it - Edges.begin() + 1 << ' ';
    fout << '\n';
    fout.close();
    return 0;
}
