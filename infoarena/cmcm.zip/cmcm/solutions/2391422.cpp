#include <bits/stdc++.h>
#define dim 305
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
vector <int> graph[dim];
vector <pair <int, int > > edges;
queue <int> q;
int n,m,e,sursa,destinatie,nr,ans;
bool seen[dim];
int daddy[dim],dmin[dim];
int cap[dim][dim],cost[dim][dim];
void Read()
{
    f>>n>>m>>e;
    sursa=0,destinatie=n+m+1;
    for(int i=1; i<=n; ++i)
    {
        graph[i].push_back(sursa);
        graph[sursa].push_back(i);
        cap[sursa][i]=1;
    }
    for(int i=n+1; i<=n+m; ++i)
    {
        graph[i].push_back(destinatie);
        graph[destinatie].push_back(i);
        cap[i][destinatie]=1;
    }
    for(int i=1; i<=e; ++i)
    {
        int x,y,c;
        f>>x>>y>>c;
        y+=n;
        graph[x].push_back(y);
        graph[y].push_back(x);
        cap[x][y]=1;
        cost[x][y]=c;
        cost[y][x]=-c;
        edges.push_back(make_pair(x,y));
    }
}
bool BellmanFord()
{
    for(int i=sursa; i<=destinatie; ++i)
    {
        seen[i]=false;
        dmin[i]=int(1e9);
    }
    int node=sursa;
    q.push(node);
    dmin[node]=0;
    while(!q.empty())
    {
        node=q.front();
        q.pop();
        seen[node]=false;
        for(int i=0; i<graph[node].size(); ++i)
        {
            int son=graph[node][i];
            if(dmin[node]+cost[node][son]<dmin[son]&&cap[node][son]>0)
            {
                daddy[son]=node;
                dmin[son]=dmin[node]+cost[node][son];
                if(!seen[son])
                {
                    seen[son]=true;
                    q.push(son);
                }
            }
        }
    }
    if(dmin[destinatie]==int(1e9))
        return false;
    else
    {
        ++nr;
        node=destinatie;
        while(node!=sursa)
        {
            cap[daddy[node]][node]--;
            cap[node][daddy[node]]++;
            ans+=cost[daddy[node]][node];
            node=daddy[node];
        }
        return true;
    }
}
void Solve()
{
    while(BellmanFord());
    g<<nr<<" "<<ans<<'\n';
    for(int i=0; i<edges.size(); ++i)
        if(!cap[edges[i].first][edges[i].second])
            g<<i+1<<" ";
}
int main()
{
    Read();
    Solve();
    return 0;
}
