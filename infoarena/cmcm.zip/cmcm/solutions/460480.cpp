#include<fstream.h>
#include<vector>


using namespace std;

int sol=0,cost[700][700],flux[700][700],best[1000],C[1000000],n,m,S,D,sw[1000],inf,t[1000],nr,muchie[400][400],psol[1000];

vector <int> v[800];

void afisare ()
{
	int i;
	vector<int> :: iterator it;
	ofstream g("cmcm.out");
	g<<nr<<' '<<sol<<"\n";
	g.close();
}

int fmax ()
{
	vector<int> :: iterator it;
	int p,u,i;
	p=u=1;
	C[p]=S;
	memset(sw,0,sizeof(sw));
	sw[S]=1;
	for (i=1;i<=n+m;i++)
		best[i]=inf;
	best[D]=inf;
	
	while (p<=u)
	{
		for (it=v[C[p]].begin();it<v[C[p]].end();++it)
			if (flux[C[p]][*it]<=0 && best[*it]>best[C[p]]+cost[C[p]][*it])
			{
				t[*it]=C[p];
				best[*it]=best[C[p]]+cost[C[p]][*it];
				C[++u]=*it;
			}
		++p;
	}

	if (best[D]!=inf)
	{
		p=D;
		sol+=best[D];
		while (p!=S)
		{
			flux[p][t[p]]--;
			flux[t[p]][p]++;
			p=t[p];
			psol[p]=t[p];
		}
		return 1;
	}
	return 0;
	}
	
void getflux()
{
	int fl=1;
	nr=-1;
	while (fl)
	{
		++nr;
		fl=fmax();
	}
}

void citire ()
{
	int i,j,e,a,b,c;
	ifstream f("cmcm.in");
	f>>n>>m>>e;
	for (i=1;i<=e;i++)
	{
		f>>a>>b>>c;
		muchie[b][a]=muchie[a][b]=i;
		cost[a][b+n]=c;
		cost[b+n][a]=-c;
		v[a].push_back(b+n);
		v[b+n].push_back(a);
	}
	S=n+m+1;
	D=S+1;
	for (i=1;i<=n;i++)
	{
		v[S].push_back(i);
		cost[S][i]=0;
		
	}
	for (i=n+1;i<=n+m;i++)
	{
		v[i].push_back(D);
		cost[i][D]=0;
	}
	f.close();
}
int main()
{
	inf =2000000000;
	citire ();
	getflux();
	afisare ();
	return 0;
}