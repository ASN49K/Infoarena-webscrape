#include <bits/stdc++.h>
using namespace std;

string file = "cmcm";

ifstream fin(file + ".in");
ofstream fout(file + ".out");

int L, R, m, n, t[602], d[602], cost[602][602];
vector <int> g[602];
int cplMax, totCost;
queue <int> Q;
const int inf = 1000000000;
bitset <602> inQ, flow[602];

inline bool bfs()
{
    for (int i = 1; i <= n; i++)
        d[i] = inf;

    Q.push(0);
    d[0] = 0;
    inQ[0] = true;

    while (!Q.empty())
    {
        int x = Q.front();
        Q.pop();
        inQ[x] = false;

        for (auto& i : g[x])
            if (flow[x][i] && d[i] > d[x] + cost[x][i])
            {
                t[i] = x;
                d[i] = d[x] + cost[x][i];
                if (!inQ[i])
                {
                    inQ[i] = true;
                    Q.push(i);
                }
            }
    }

    if (d[n] == inf)
        return false;

    cplMax++;

    int x = n;

    while (x)
    {
        flow[t[x]][x] = false;
        flow[x][t[x]] = true;

        x = t[x];
    }

    return true;
}

int main()
{
    fin >> L >> R >> m;
    n = L + R + 1;

    for (int i = 1; i <= m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;

        flow[x][L + y] = true;
        flow[0][x] = true;
        flow[L + y][n] = true;

        g[x].push_back(L + y);
        g[L + y].push_back(x);
        g[0].push_back(x);
        g[x].push_back(0);
        g[L + y].push_back(n);

        cost[x][L + y] = c;
        cost[L + y][x] = -c;
    }

    while (bfs());

    fout << cplMax << ' ';

    fin.close();
    fin.open(file + ".in");

    fin >> L >> R >> m;

    vector <int> R;

    for (int i = 1; i <= m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;

        if (!flow[x][L + y])
            totCost += c, R.push_back(i);
    }

    fout << totCost << '\n';

    for (auto& i : R)
        fout << i << ' ';

    return 0;
}