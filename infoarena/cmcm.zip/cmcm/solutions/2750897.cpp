#include <bits/stdc++.h>
#define inf 2000000000
using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int n,m,k;
int muchie[305][605];
int destination,cap[605][605];
int dp[605],tata[605],used[605],coada[605*605],flow[605][605];

long long sol=0;

vector< pair<int,int> > vecini[305];

int bellman_ford()
{
    for(int i=0; i<=destination; i++)
    {
        dp[i]=inf;
        tata[i]=-1;
        used[i]=0;
    }

    dp[0]=0;
    used[0]=1;

    int nr=1;
    coada[1]=0;

    for(int i=1; i<=nr; i++)
    {
        int nod=coada[i];

        for(int j=0; j<vecini[nod].size(); j++)
        {
            int x=vecini[nod][j].first;
            int cost=vecini[nod][j].second;

            if( cap[nod][x]==flow[nod][x]||dp[x]<=dp[nod]+cost ) continue;

            dp[x]=dp[nod]+cost;
            tata[x]=nod;

            if(!used[x])
            {
                used[x]=1;
                coada[++nr]=x;
            }
        }

        used[nod]=0;
    }

    if( dp[destination]<inf )
    {
        int flux=inf;
        for(int i=destination; i!=0; i=tata[i])
            flux=min(flux,cap[tata[i]][i]-flow[tata[i]][i]);

        for(int i=destination; i!=0; i=tata[i])
        {
            flow[tata[i]][i]+=flux;
            flow[i][tata[i]]-=flux;
        }

        return flux*dp[destination];
    }
    return 0;
}


int main()
{
    f>>n>>m>>k;
    destination=n+m+1;

    for(int i=1; i<=k; i++)
    {
        int x,y,z;

        f>>x>>y>>z;
        y+=n;



        vecini[x].push_back(make_pair(y,z));
        vecini[y].push_back(make_pair(x,-z));

        muchie[x][y]=i;
        cap[x][y]=1;
    }

    for(int i=1; i<=n; i++)
    {
        vecini[0].push_back(make_pair(i,0));
        vecini[i].push_back(make_pair(0,0));

        cap[0][i]=1;
    }

    for(int i=n+1; i<=n+m; i++)
    {
        vecini[i].push_back(make_pair(destination,0));
        vecini[destination].push_back(make_pair(i,0));

        cap[i][destination]=1;
    }


    int improve=1;

    while(improve)
    {
        improve=bellman_ford();
        sol+=improve;
    }

    int nr=0;

    for(int i=1; i<=n; i++)
        for(int j=n+1; j<=n+m; j++)
            if( cap[i][j]!=0&&flow[i][j]!=0 )
            {
                nr++;
            }
    g<<nr<<' '<<sol<<'\n';

    for(int i=1; i<=n; i++)
        for(int j=n+1; j<=n+m; j++)
            if( cap[i][j]!=0&&flow[i][j]!=0)
            {
                g<<muchie[i][j]<<' ';
            }
}
