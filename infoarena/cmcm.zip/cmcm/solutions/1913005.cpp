#include <cstdio>
#include <vector>
#include <cstring>
#include <queue>
#define pb push_back
using namespace std;
const int nmax=623;
vector<int>adj[nmax];
int f[nmax][nmax],c[nmax][nmax],dist[nmax][nmax],edge[nmax][nmax],vis[nmax],bmf[nmax],t[nmax],d[nmax],realdist[nmax];
queue<int> q;
priority_queue< pair<int,int>, vector< pair<int,int> >, greater< pair<int,int> > >dj;
int n,m,k,sursa,destinatie;
inline void citeste()
{
    scanf("%d%d%d",&n,&m,&k);
    sursa=1,destinatie=n+m+2;
    for(int i=2;i<=n+1;i++)
    {
        adj[i].pb(1);
        adj[1].pb(i);
        c[1][i]=1;
    }
    for(int i=1;i<=m;i++)
    {
        adj[i+n+1].pb(destinatie);
        adj[destinatie].pb(i+n+1);
        c[i+n+1][destinatie]=1;
    }
    for(int i=1;i<=k;i++)
    {
        int x,y,z;
        scanf("%d%d%d",&x,&y,&z);
        x++,y+=n+1;
        adj[x].pb(y);
        adj[y].pb(x);
        c[x][y]=1;
        dist[x][y]=z;
        dist[y][x]=-z;
        edge[x][y]=i,edge[y][x]=i;
    }
}
inline void bellman()
{
    memset(bmf,0x3f3f3f3f,sizeof(bmf));
    q.push(1);
    bmf[1]=0;
    //printf("%d\n",bmf[destinatie]);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        vis[nod]=0;
        for(vector<int>::iterator it=adj[nod].begin();it!=adj[nod].end();++it)
        {
            if(!c[nod][*it]) continue;
            if(bmf[*it]>bmf[nod]+dist[nod][*it])
            {
                bmf[*it]=bmf[nod]+dist[nod][*it];
                if(!vis[*it])
                {
                    vis[*it]=1;
                    q.push(*it);
                }
            }
        }
    }
  //  printf("%d %d\n",destinatie, bmf[destinatie]);
   // for(int i=1;i<=n+m+2;i++) printf("%d ",bmf[i]);
   // printf("\n");
}
int dijkstra()
{
    for(int i=1;i<=n+m+5;i++)
    {
        d[i]=0x3f3f3f3f;
        t[i]=-1;
    }
    dj.push(make_pair(0,sursa));
    d[sursa]=0;
    while(!dj.empty())
    {
        int dd=dj.top().first,nod=dj.top().second;
        dj.pop();
        if(d[nod]!=dd||nod==destinatie) continue;
        for(vector<int>::iterator it=adj[nod].begin();it!=adj[nod].end();++it)
        {
            if(c[nod][*it]-f[nod][*it]<=0) continue;
            if(d[*it]>dd+dist[nod][*it]+bmf[nod]-bmf[*it])
            {
                d[*it]=dd+dist[nod][*it]+bmf[nod]-bmf[*it];
                t[*it]=nod;
                realdist[*it]=realdist[nod]+dist[nod][*it];
                dj.push(make_pair(d[*it],*it));
            }
        }
    }
    memcpy(bmf,realdist,sizeof(realdist));
    if(d[destinatie]==0x3f3f3f3f) return 0;
    return 1;
}
int main()
{
    freopen ("cmcm.in","r",stdin);
    freopen ("cmcm.out","w",stdout);
    citeste();
    bellman();
    int flux=0,sol=0;
    while(dijkstra())
    {
        int minim=0x3f3f3f3f;
        for(int i=destinatie;i!=sursa;i=t[i]) minim=min(minim,c[t[i]][i]-f[t[i]][i]);
      //  printf("%d\n",minim);
        sol+=minim*realdist[destinatie];
        flux+=minim;
        for(int i=destinatie;i!=sursa;i=t[i])
        {
            f[t[i]][i]+=minim;
            f[i][t[i]]-=minim;
        }
    }
    printf("%d %d\n",flux,sol);
    for(int i=2;i<=n+1;i++)
    {
        for(int j=n+2;j<=n+m+1;j++)
        {
            if(c[i][j]==f[i][j]&&edge[i][j]!=0)
            {
                printf("%d ",edge[i][j]);
                edge[j][i]=0;
            }
        }
    }
}
