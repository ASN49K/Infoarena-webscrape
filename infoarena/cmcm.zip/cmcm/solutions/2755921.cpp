#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int nmax=300, inf=(1<<30)-1;

struct str{
    int x,y;

    str(int x, int y);
};

str::str(int x,int y){
    this->x=x;
    this->y=y;
}

struct cmp{
    bool operator()(str x, str y){
        return x.y>y.y;
    }
};

priority_queue <str, vector<str>, cmp> h;

int f[2*nmax+2][2*nmax+2], c[2*nmax+2][2*nmax+2], d[2*nmax+2], t[2*nmax+2];

vector <int> g[2*nmax+2];

queue <int> q;

int main(){
    int n,m,e;
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++){
        int x,y,z;
        fin>>x>>y>>z;
        y=y+n;
        f[x][y]=1;
        c[x][y]=z;
        c[y][x]=-z;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        f[0][i]=1;
        g[0].push_back(i);
        g[i].push_back(0);
    }
    int mn=m+n;
    for(int i=n+1;i<=mn;i++){
        f[i][mn+1]=1;
        g[i].push_back(mn+1);
        g[mn+1].push_back(i);
    }

    for(int i=0;i<=mn+1;i++){
        d[i]=inf;
    }

    d[0]=0;
    q.push(0);
    while(q.empty()==0){
        int x=q.front();
        q.pop();
        for(int i=0;i<int(g[x].size());i++){
            int xn=g[x][i];
            if(f[x][xn]>0&&d[xn]>d[x]+c[x][xn]){
                d[xn]=d[x]+c[x][xn];
                q.push(xn);
            }
        }
    }

    int dif=0,sol=0,solf=0;
    while(d[mn+1]!=inf){
        for(int x=0;x<=mn+1;x++){
            for(int i=0;i<int(g[x].size());i++){
                int xn=g[x][i];
                if(d[x]!=inf&&d[xn]!=inf){
                    c[x][xn]=c[x][xn]+d[x]-d[xn];
                }
            }
        }
        dif+=d[mn+1];

        for(int i=0;i<=mn+1;i++){
            d[i]=inf;
        }
        d[0]=0;
        h.push(str(0,0));
        while(h.empty()==0){
            int x=h.top().x;
            int y=h.top().y;
            h.pop();
            if(y==d[x]){
                for(int i=0;i<int(g[x].size());i++){
                    int xn=g[x][i];
                    if(f[x][xn]>0&&d[xn]>d[x]+c[x][xn]){
                        t[xn]=x;
                        d[xn]=d[x]+c[x][xn];
                        h.push(str(xn,d[xn]));
                    }
                }
            }
        }

        if(d[mn+1]!=inf){
            int mini=inf;
            for(int i=mn+1;i!=0;i=t[i]){
                if(mini>f[t[i]][i]){
                    mini=f[t[i]][i];
                }
            }
            for(int i=mn+1;i!=0;i=t[i]){
                f[t[i]][i]-=mini;
                f[i][t[i]]+=mini;
            }
            sol+=(d[mn+1]+dif)*mini;
            solf+=mini;
        }
    }
    fout<<solf<<" "<<sol<<"\n";
    for(int i=1;i<=m;i++){
        int j=i+n;
        if(f[t[j]][j]!=0){
            fout<<i<<" ";
        }
    }
    return 0;
}
