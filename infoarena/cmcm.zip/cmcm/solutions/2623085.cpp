#include <bits/stdc++.h>

using namespace std;

ifstream fin ("cmcm.in");
ofstream fout ("cmcm.out");

int cost[602][602], f[602][602], c[602][602], x, y, z, d[602], ind[602][602], viz[602], p[602];
int n, m, e;
vector<int>G[602];

bool BellmanFord () {
  for (int i = 0; i <= n + m + 1; i++)
    d[i] = 1e9;
  d[0] = 0;
  memset(viz, 0, sizeof(viz));
  queue<int>q;
  q.push(0);
  viz[0] = 1;
  memset(p, -1, sizeof(p));
  while (!q.empty()) {
    int x = q.front();
    q.pop();
    for (auto it : G[x]) {
      if (f[x][it] < c[x][it] && d[it] > d[x] + cost[x][it]) {
        d[it] = d[x] + cost[x][it];
        p[it] = x;
        if (!viz[it]) {
          viz[it] = 1;
          q.push(it);
        }
      }
    }
    viz[x] = 0;
  }
  return (d[n + m + 1] != 1e9);
}


int main()
{
  fin >> n >> m >> e;
  for (int i = 1; i <= e; i++) {
    fin >> x >> y >> z;
    y += n;
    c[x][y] = 1;
    cost[x][y] = z;
    cost[y][x] = -z;
    G[x].push_back(y);
    G[y].push_back(x);
    ind[x][y] = i;
  }
  for (int i = 1; i <= n; i++) {
    c[0][i] = 1;
    G[0].push_back(i);
    G[i].push_back(0);
  }

  for (int i = 1; i <= m; i++) {
    c[i + n][n + m + 1] = 1;
    G[i + n].push_back(n + m + 1);
    G[m + n + 1].push_back(n + i);
  }
  vector<int>ans;
  int flow = 0, cost = 0;
  while (BellmanFord()) {
    int fmin = 1e9;
    for (int i = n + m + 1; i != 0; i = p[i]) {
      fmin = min(fmin, c[p[i]][i] - f[p[i]][i]);
    }
    if (fmin != 0)
      for (int i = n + m + 1; i != 0; i = p[i]) {
        f[p[i]][i] += fmin;
        f[i][p[i]] -= fmin;
      }
    cost += fmin * d[n + m + 1];
  }
  for (int i = 1; i <= n; i++)
    for (int j = n + 1; j <= n + m; j++)
      if (f[i][j] && c[i][j])
        ans.push_back(ind[i][j]);
  fout << ans.size() << " " << cost << "\n";
  for (auto it : ans)
    fout << it << " ";
  return 0;
}
