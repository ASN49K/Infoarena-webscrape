#include <iostream>
#include <cstring>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

using ll = long long;
//#define int ll
using pi = pair<int,int>;
using pll = pair<ll, ll>;

#define pb push_back
#define x first
#define y second
const int MOD = 1e9+7, INF = 1e9, NMAX = 605;
struct vertex
{
    int u, cost;
    bool operator <(const vertex &oth) const
    {
        return cost > oth.cost;
    }
};
int cap[NMAX][NMAX], d[NMAX], dist[NMAX], p[NMAX], cost[NMAX], act[NMAX], N;
vector<pi> edges, v[NMAX];
void bf(int src)
{
    int u, nod, i, w;
    queue<int> q;
    for(i = 0; i <= N; i++)
        d[i] = INF;
    q.push(src);
    act[src] = 1;
    d[src] = 0;
    while(!q.empty())
    {
        u = q.front();
        q.pop();
        act[u] = 0;
        for(i = 0; i < v[u].size(); i++)
        {
            nod = v[u][i].x;
            w = v[u][i].y;
            if(d[nod] > d[u] + w && cap[u][nod] > 0)
            {
                d[nod] = d[u] + w;
                if(!act[nod])
                {
                    q.push(nod);
                    act[nod] = 1;
                }
            }
        }
    }
}
int dijkstra(int src, int dest)
{
    int i, nod, w;
    vertex u;
    priority_queue<vertex> pq;
    for(i = 0; i <= N; i++)
    {
        dist[i] = INF;
        cost[i] = INF;
        p[i] = 0;
    }
    p[src] = src;
    dist[src] = 0;
    cost[src] = 0;
    pq.push({src, 0});
    while(!pq.empty())
    {
        u = pq.top();
        pq.pop();
        if(u.cost > dist[u.u])
            continue;
        for(i = 0; i < v[u.u].size(); i++)
        {
            nod = v[u.u][i].x;
            w = v[u.u][i].y;
            if(dist[nod] > dist[u.u] + w + d[u.u] - d[nod] && cap[u.u][nod] > 0)
            {
                dist[nod] = dist[u.u] + w + d[u.u] - d[nod];
                cost[nod] = cost[u.u] + w;
                p[nod] = u.u;
                pq.push({nod, dist[nod]});
            }
        }
    }
    return dist[dest] != INF;
}
void solve()
{
    int n, m, e, i, a, b, w, src, dest, flow, new_flow, ans, u;
    cin >> n >> m >> e;
    src = 0;
    dest = n + m + 1;
    N = n + m + 1;
    for(i = 0; i < e; i++)
    {
        cin >> a >> b >> w;
        b += n;
        cap[a][b] = 1;
        v[a].pb({b, w});
        v[b].pb({a, -w});
        edges.pb({a, b});
    }
    for(i = 1; i <= n; i++)
    {
        cap[src][i] = 1;
        v[src].pb({i, 0});
        v[i].pb({src, 0});
    }
    for(i = n + 1; i <= n + m; i++)
    {
        cap[i][dest] = 1;
        v[dest].pb({i, 0});
        v[i].pb({dest, 0});
    }
    bf(src);
    flow = 0;
    ans = 0;
    while(dijkstra(src, dest))
    {
        new_flow = INF;
        u = dest;
        while(u != src)
        {
            new_flow = min(new_flow, cap[p[u]][u]);
            u = p[u];
        }
        u = dest;
        while(u != src)
        {
            cap[p[u]][u] -= new_flow;
            cap[u][p[u]] += new_flow;
            u = p[u];
        }
        flow += new_flow;
        ans += new_flow * cost[dest];
    }
    cout << flow << ' ' << ans << '\n';
    for(i = 0; i < e; i++)
        if(cap[edges[i].x][edges[i].y] == 0)
            cout << i + 1 << ' ';
}
int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    int T;
    T = 1;
    while(T--)
        solve();
    return 0;
}
