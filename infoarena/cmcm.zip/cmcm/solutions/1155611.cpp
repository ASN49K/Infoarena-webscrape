#include<cstdio>
#include<cstring>
#include<queue>
#include<vector>
#define inf 0x3f3f3f3f
#define NMax 605
using namespace std;

int d[NMax],N,M,F;
int inQ[NMax],tata[NMax],which[NMax][NMax];
int C[NMax][NMax],Cst[NMax][NMax];
queue<int> Q;
vector<int> V[NMax];

int bellmanFord ()
{
    memset(d,inf,sizeof(d));
    d[1]=0;
    Q.push(1), inQ[1]=1;
    while (!Q.empty())
    {
        int crt=Q.front();
        inQ[crt]=0, Q.pop();
        vector<int>::iterator it;
        for (it=V[crt].begin(); it!=V[crt].end(); ++it)
            if (C[crt][*it] && d[*it]>d[crt]+Cst[crt][*it])
            {
                d[*it]=d[crt]+Cst[crt][*it];
                tata[*it]=crt;
                if (!inQ[*it])
                    inQ[*it]=1, Q.push(*it);
            }
    }
    return (d[M+N+2]!=inf);
}

int main ()
{
    int minF,FCost=0,i,x,y,crt,E,j;
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&N,&M,&E);
    for (i=1; i<=E; i++)
    {
        scanf("%d%d",&x,&y);
        x++, y+=N+1;
        which[x][y]=i;
        V[x].push_back(y);
        V[y].push_back(x);
        scanf("%d",&Cst[x][y]);
        Cst[y][x]=-Cst[x][y];
        C[x][y]=1;
    }
    for (i=2; i<=N+1; i++)
    {
        V[1].push_back(i);
        V[i].push_back(1);
        C[1][i]=1;
    }
    for (i=N+2; i<=M+N+1; i++)
    {
        V[i].push_back(M+N+2);
        V[M+N+2].push_back(i);
        C[i][M+N+2]=1;
    }
    while (bellmanFord())
    {
        minF=inf;
        for (crt=M+N+2; crt!=1; crt=tata[crt])
            if (C[tata[crt]][crt]<minF)
                minF=C[tata[crt]][crt];
        F+=minF;
        FCost+=minF*d[M+N+2];
        for (crt=M+N+2; crt!=1; crt=tata[crt])
        {
            C[tata[crt]][crt]-=minF;
            C[crt][tata[crt]]+=minF;
        }
    }
    printf("%d %d\n",F,FCost);
    for (i=2; i<=N+1; i++)
        for (j=N+2; j<=M+N+1; j++)
            if (!C[i][j] && which[i][j])
                printf("%d ",which[i][j]);
    printf("\n");
    return 0;
}
