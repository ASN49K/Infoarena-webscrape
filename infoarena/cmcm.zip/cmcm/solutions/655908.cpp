#include<fstream>
#include<vector>
#include<queue>
#define inf 100000010
using namespace std;

int i,j,n,m,sursa,dest,x,y,cost1,k,uz[602],r,rez=0,nr=0;
int fl[602][602],cap[602][602],cost[602][602],d[602],p[602],ret[602][602];
vector<int> a[602];
queue<int> q;
int det()
{
	int i,x,min1,b[602];
	for(i=0;i<=dest;++i)
		d[i]=inf,b[i]=0,p[i]=0;
	q.push(sursa);
	b[sursa]=1;
	d[sursa]=0;
	while(!q.empty())
	{
		x=q.front();
		b[x]=0;
		for(i=0;i<a[x].size();++i)
			if(cap[x][a[x][i]]-fl[x][a[x][i]]>0&&d[a[x][i]]>d[x]+cost[x][a[x][i]])
			{
				d[a[x][i]]=d[x]+cost[x][a[x][i]];
				p[a[x][i]]=x;
				if(!b[a[x][i]])
				{
					q.push(a[x][i]);
					b[a[x][i]]=1;
				}
			}
			q.pop();
	}
	if(d[dest]!=inf)
	{
		min1=inf;
		r=1;
		for(i=dest;i!=sursa;i=p[i])
			if(min1>cap[p[i]][i]-fl[p[i]][i])
				min1=cap[p[i]][i]-fl[p[i]][i];
			for(i=dest;i!=sursa;i=p[i])
			{
				fl[p[i]][i]++;
				fl[i][p[i]]--;
			}
			return min1*d[dest];
	}
	return 0;
}
int main()
{
	FILE *f=fopen("cmcm.in","r");
	ofstream g("cmcm.out");
	fscanf(f,"%d%d%d",&n,&m,&k);
	sursa=0;
	dest=n+m+1;
	for(i=1;i<=k;++i)
	{
		fscanf(f,"%d%d%d",&x,&y,&cost1);
		a[x].push_back(y+n);
		cap[x][y+n]=1;
		a[y+n].push_back(x);
		cost[y+n][x]=-cost1;
		cost[x][y+n]=cost1;
		ret[x][y+n]=i;
	}
	for(i=1;i<=dest;++i)
	{
		if(i<=n)
		{
			a[sursa].push_back(i),cost[sursa][i]=0,cap[sursa][i]=1;
			a[i].push_back(sursa),cost[i][sursa]=0;
		}
		else
		{
			a[i].push_back(dest),cost[i][dest]=0,cap[i][dest]=1;
		a[dest].push_back(i),cost[dest][i]=0;
		}
	}
	r=1;
	while(r)
	{
		++nr;
		r=det();
		rez+=r;
	}
	g<<nr-1<<" "<<rez<<"\n";
	for(i=1;i<=n;++i)
		for(j=n+1;j<dest;++j)
			if(cap[i][j]&&fl[i][j])
				g<<ret[i][j]<<" ";
	return 0;
}