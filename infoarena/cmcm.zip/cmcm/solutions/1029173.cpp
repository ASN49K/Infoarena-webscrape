#include <fstream>
#include <vector>
 
using namespace std;

ifstream cin("cmcm.in");
ofstream cout("cmcm.out");

const int INF = int(1e4);
const int nmax = 302;
int edge[nmax][nmax];

void go(int n,int m,vector< vector<int > > a) {
	vector<int> u (n+1), v (m+1), p (m + 1,0), way (m+1);
	for (int i = 1; i <= n; ++i) {
		p[0] = i;
		int j0 = 0;
		vector<int> minv (m+1, INF);
		vector<char> used (m+1, false);
		do {
			used[j0] = true;
			int i0 = p[j0],  delta = INF,  j1;
			for (int j = 1; j <= m; ++j)
				if (!used[j]) {
					int cur = a[i0][j]-u[i0]-v[j];
					if (cur < minv[j])
						minv[j] = cur,  way[j] = j0;
					if (minv[j] < delta)
						delta = minv[j],  j1 = j;
				}
			for (int j = 0; j <= m; ++j)
				if (used[j])
					u[p[j]] += delta,  v[j] -= delta;
				else
					minv[j] -= delta;
			j0 = j1;
		} while (p[j0] != 0);
		do {
			int j1 = way[j0];
			p[j0] = p[j1];
			j0 = j1;
		} while (j0);
	}

	vector<int> ans (n + 1);
	for (int j = 1; j <= m; ++j)
		ans[p[j]] = j;
	
	vector< pair<int,int> > sol;
	int cost = -v[0];
	
	for (int i = 1;i <= n;i++) {
		if (ans[i]) {
			//cout << i << " " << ans[p[i]] << "\n";
			sol.push_back(make_pair(i,ans[i]));
		}
	}

	cout << sol.size() << " " << cost << "\n";
	for(const auto x : sol) {
		cout << edge[x.first][x.second] << " ";
	}
}

vector< vector<int> > c;
int n, m, e;

int main()
{
	cin >> n >> m >> e;
	c.push_back(vector<int>());
	for(int i = 1;i <= n;i++) {
		c.push_back(vector<int>(m + 1,INF));
	}

	for(int i = 0;i < e;i++) {
		int a, b, cost;
		cin >> a >> b >> cost;
		edge[a][b] = i + 1;
		c[a][b] = cost;
	}

	go(n,m,c);
    return 0;
}
