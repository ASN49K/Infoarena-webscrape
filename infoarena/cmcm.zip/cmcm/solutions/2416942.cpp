#include <bits/stdc++.h>
#define NMAX 604
using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

int n,m,e;

struct edge
{
    int x,y,i;
};
vector<edge> muchii;

int s=0,d;

vector<int> adj[NMAX];
int cost[NMAX][NMAX];
int flow[NMAX][NMAX];

void read()
{
    fin>>n>>m>>e;
    d=n+m+1;
    for(int i=0;i<e;i++)
    {
        int x,y,w;
        fin>>x>>y>>w;
        y+=n;
        muchii.push_back({x,y,i+1});
        adj[x].push_back(y);
        adj[y].push_back(x);
        flow[x][y]=1;
        cost[x][y]=w;
        cost[y][x]=-w;
    }
    for(int i=1;i<=n;i++)
    {
        adj[0].push_back(i);
        adj[i].push_back(0);
        flow[0][i]=1;
    }

    for(int i=n+1;i<=n+m;i++)
    {
        adj[d].push_back(i);
        adj[i].push_back(d);
        flow[i][d]=1;
    }

}

int k=0;

bool bellman()
{
    //cout<<1;
    queue<int> q;

    int dist[NMAX];
    memset(dist,0x3f,sizeof(dist));
    int parent[NMAX];
    memset(parent,0xff,sizeof(parent));
    dist[0]=0;
    q.push(0);

    bool inqueue[NMAX]={};
    while(!q.empty())
    {
        int v=q.front();
        q.pop();
        inqueue[v]=0;
        for(auto u:adj[v])
        {
            if(flow[v][u]&&dist[v]+cost[v][u]<dist[u])
            {
                dist[u]=dist[v]+cost[v][u];
                parent[u]=v;
                if(!inqueue[u])
                {
                    inqueue[u]=1;
                    q.push(u);
                }
            }
        }
    }

    if(parent[d]==-1) return 0;
    for(int v=d;parent[v]!=-1;v=parent[v])
    {
        flow[parent[v]][v]-=1;
        flow[v][parent[v]]+=1;
        k+=cost[parent[v]][v];
    }
    return 1;
}





int main()
{
    read();
    while(bellman());
    vector<int> ans;
    for(auto z:muchii)
        if(flow[z.x][z.y]==0)
            ans.push_back(z.i);
    fout<<ans.size()<<' '<<k<<'\n';
    for(auto x:ans)
        fout<<x<<' ';
    return 0;
}
