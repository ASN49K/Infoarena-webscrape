#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <bitset>
#define mkp make_pair
using namespace std;
ifstream si("cmcm.in");
ofstream so("cmcm.out");
const int inf=1000000000;
struct heap {
    int nod,c;
    bool operator <(const heap &aux) const{
        return c>aux.c;
    }
};
vector<int> v[610];
queue<int> q;
priority_queue<heap> h;
pair<int,int> ed[50010];
int c[610][610], dist[610], dist1[610], cap[610][610], flow[610][610], d[610], tata[610], sursa, dest, n;
bitset<610> vaz;
void bf(int nod) {
    for(int i=sursa; i<=dest; i++)
        dist[i]=inf;
    dist[nod]=0;
    q.push(nod);
    vaz[nod]=1;
    int m;
    while(!q.empty()) {
        nod=q.front();
        q.pop();
        vaz[nod]=0;
        m=v[nod].size();
        for(int i=0; i<m; i++)
            if(cap[nod][v[nod][i]]&&dist[v[nod][i]]>dist[nod]+c[nod][v[nod][i]])
            {
                dist[v[nod][i]]=dist[nod]+c[nod][v[nod][i]];
                if(!vaz[v[nod][i]]&&v[nod][i]!=dest) {
                    vaz[v[nod][i]]=1;
                    q.push(v[nod][i]);
                }
            }
    }
}
int dij() {
    for(int i=sursa; i<=dest; i++) {
        d[i]=inf;
        dist1[i]=inf;
    }
    d[sursa]=0;
    dist1[sursa]=0;
    h.push({sursa,0});
    int m;
    int nod, cs;
    while(!h.empty())
    {
        nod=h.top().nod;
        cs=h.top().c;
        h.pop();
        if(d[nod]!=cs)
            continue;
        m=v[nod].size();
        for(int i=0; i<m; i++)
            if(cap[nod][v[nod][i]]>flow[nod][v[nod][i]]&&d[v[nod][i]]>d[nod]+c[nod][v[nod][i]]+dist[nod]-dist[v[nod][i]]) {
                d[v[nod][i]]=d[nod]+c[nod][v[nod][i]]+dist[nod]-dist[v[nod][i]];
                dist1[v[nod][i]]=dist1[nod]+c[nod][v[nod][i]];
                tata[v[nod][i]]=nod;
                if(v[nod][i]!=dest)
                    h.push({v[nod][i],d[v[nod][i]]});
            }
    }
    for(int i=sursa; i<=dest; i++)
        dist[i]=dist1[i];
    return (d[dest]!=inf);
}

int main()
{
    int m,cost,x,y,sol=0,fl=0,e;
    si>>n>>m>>e;
    for(int i=1; i<=e; i++) {
        si>>x>>y>>cost;
        ed[i]=mkp(x,y);
        v[x].push_back(n+y);
        v[n+y].push_back(x);
        cap[x][n+y]=1;
        c[x][n+y]=cost;
        c[n+y][x]=-cost;
    }
    sursa=0;
    dest=n+m+1;
    for(int i=1; i<=n; i++) {
        v[sursa].push_back(i);
        v[i].push_back(sursa);
        cap[sursa][i]=1;
    }
    for(int i=1; i<=m; i++) {
        v[n+i].push_back(dest);
        v[dest].push_back(n+i);
        cap[n+i][dest]=1;
    }
    bf(sursa);

    while(dij()) {
        for(int i=dest; i!=sursa; i=tata[i]) {
            flow[tata[i]][i]++;
            flow[i][tata[i]]--;
        }
        sol+=dist[dest];
        fl++;
    }
    so<<fl<<' '<<sol<<'\n';
    for(int i=1; i<=e; i++)
        if(flow[ed[i].first][n+ed[i].second])
            so<<i<<' ';
    return 0;
}
