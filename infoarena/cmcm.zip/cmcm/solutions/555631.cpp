#include <queue>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <algorithm>
#define N_MAX 711
#define oo 1<<25

using namespace std;
struct vertex
{
	int Index, y, cost, capacity, flux, op;
	vertex( int index, int _y, int _cost, int _capacity ) : Index(index), y(_y), cost(_cost), capacity(_capacity), flux(0) {}
};
bool was[N_MAX];
//vector< bool > was;
int countVertex, sink, source=0;
int d[N_MAX], f[N_MAX], fit[N_MAX];
//vector< int > d, f, fit;
vector< vertex > G[N_MAX];
vector< vertex >::const_iterator it, iend;
class cmp
{
public : bool operator() ( const int& x, const int& y ) const { return d[x] > d[y]; }
};
priority_queue< int, vector< int >, cmp > pQ;
bool findPath()
{
	int x;
	for( x=source; x <= sink; ++x )
	{
		was[x]=false;
		d[x]=oo;
		f[x]=fit[x]=-1;
	}
	d[source]=0;
	for( pQ.push(source); !pQ.empty(); )
	{
		x=pQ.top(); pQ.pop();
		was[x]=false;
		for( it=G[x].begin(), iend=G[x].end(); it < iend; ++it )
		{
			if( source == it->y )
				continue;
			if( d[it->y] > d[x]+it->cost && it->capacity > it->flux )
			{
				f[it->y]=x;
				fit[it->y]=it-G[x].begin();
				d[it->y]=d[x]+it->cost;
				if( false == was[it->y] )
				{
					pQ.push( it->y );
					was[it->y]=true;
				}				
			}
		}
	}
	return oo != d[sink];
}
int main( void )
{
	int N, M, E, i, x, y, c;
	ifstream in( "cmcm.in" );
	in>>N>>M>>E;
	for( i=1; i <= E; ++i )
	{
		in>>x>>y>>c;
		y+=N;
		G[x].push_back( vertex( i, y, c, 1 ) );
		G[y].push_back( vertex( i, x, -c, 0 ) );
		G[x].back().op=G[y].size()-1;
		G[y].back().op=G[x].size()-1;
	}
	countVertex=sink=N+M+1;
	/*was.resize( countVertex+1 );
	f.resize( countVertex+1 ); fit.resize( countVertex+1 );
	d.resize( countVertex+1 );*/ 
	for( x=1; x <= N; ++x )
		if( !G[x].empty() )
		{
			G[source].push_back( vertex( oo, x, 0, 1 ) );
			G[x].push_back( vertex( oo, source, 0, 0 ) );
			G[source].back().op=G[x].size()-1;
			G[x].back().op=G[source].size()-1;
		}
	for( y=N+1, M+=N; y <= M; ++y )
		if( !G[y].empty() )
		{
			G[y].push_back( vertex( oo, sink, 0, 1 ) );
			G[sink].push_back( vertex( oo, y, 0, 0 ) );
			G[y].back().op=G[sink].size()-1;
			G[sink].back().op=G[y].size()-1;
		}
	for( x=y=0; findPath(); ++x, y+=d[sink] )
	{
		for( c=sink; -1 != f[c]; c=f[c] )
		{
			++G[f[c]][fit[c]].flux;
			--G[c][G[f[c]][fit[c]].op].flux;
		}
	}
	ofstream out( "cmcm.out" );
	out<<x<<' '<<y<<'\n';
	for( i=1; i <= N && x; ++i )
	{
		for( it=G[x].begin(), iend=G[x].end(); it < iend; ++it )
			if( it->flux > 0 )
			{
				out<<it->Index<<' ';
				--x;
			}
	}
	return EXIT_SUCCESS;
} 
