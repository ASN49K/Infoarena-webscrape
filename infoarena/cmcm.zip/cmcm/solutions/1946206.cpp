#include <cstdio>
#include <vector>
#include <queue>
#include <cstring>
#define N 705
#define inf 1<<29
using namespace std;

struct edge{
            int to,cost;
           };
vector <edge> G[N];
int t[N],dist[N],c[N][N],f[N][N],ind[N][N],n,m,dest,Sol,nr;
bool viz[N];

void Read(){

    int nrm,x,y,cost,i;
    edge e;
    freopen("cmcm.in","r",stdin);

    scanf("%d%d%d",&n,&m,&nrm);

    for (i=1;i<=nrm;++i){
        scanf("%d%d%d",&x,&y,&cost);
        x++;y+=n+1;

        e.to=y;e.cost=cost;G[x].push_back(e);

        e.to=x;e.cost=-cost;G[y].push_back(e);

        ind[x][y]=i;
        c[x][y]=1;
        }
}

void BuildGraph(){

    int i;
    edge e;

    dest=n+m+2;
    for (i=2;i<=n+1;++i){

        e.to=i;e.cost=0;G[1].push_back(e);
        e.to=1;e.cost=0;G[i].push_back(e);
        c[1][i]=1;
        }

    for (i=n+2;i<=n+m+1;++i){

        e.to=i;e.cost=0;G[dest].push_back(e);
        e.to=dest;e.cost=0;G[i].push_back(e);
        c[i][dest]=1;
        }
}

int BellmanFord(){

    int i,node,flow;
    vector <edge>::iterator it;
    queue <int> Q;

    for (i=1;i<=dest;++i){
        dist[i]=inf;
        t[i]=-1;
        viz[i]=0;
        }
    dist[1]=0;viz[1]=1;Q.push(1);

    while (!Q.empty()){
        node=Q.front();Q.pop();

        for (it=G[node].begin();it!=G[node].end();++it)
            if (c[node][(*it).to]-f[node][(*it).to]>0 && dist[(*it).to]>dist[node]+(*it).cost)
                    {
                     dist[(*it).to]=dist[node]+(*it).cost;
                     t[(*it).to]=node;

                     if (!viz[(*it).to]) {
                                         Q.push((*it).to);
                                         viz[(*it).to]=1;
                                         }
                    }
        viz[node]=0;
        }

    if (dist[dest]<inf){
        flow=inf;

        for (i=dest;i!=1;i=t[i])
            flow=min(flow,c[t[i]][i]-f[t[i]][i]);

        for (i=dest;i!=1;i=t[i]){

            f[t[i]][i]+=flow;
            f[i][t[i]]-=flow;
            }

        return flow*dist[dest];
        }

    return 0;
}

void Solve(){

    int cuplaj=1;

    BuildGraph();

    while (cuplaj){
        cuplaj=BellmanFord();
        Sol+=cuplaj;
        }
}

void Write(){

    int i,j;
    freopen("cmcm.out","w",stdout);

    for (i=2;i<=n+1;++i)
        for (j=n+2;j<dest;++j)
            if (c[i][j] && f[i][j]) {
                nr++;
                break;
                }
    printf("%d %d\n",nr,Sol);

    for (i=2;i<=n+1;++i)
        for (j=n+2;j<dest;++j)
            if (c[i][j] && f[i][j])
                {
                printf("%d ",ind[i][j]);
                break;
                }
}

int main()
{
    Read();
    Solve();
    Write();
    return 0;
}
