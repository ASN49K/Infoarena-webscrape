#include<cstdio>
#include<cstring>
#define Nmx 10001

using namespace std;
int l[Nmx],r[Nmx],n,m,viz[Nmx];
struct nod
{
    int inf;
    nod *urm;
};
nod *G[Nmx];

void add(int x,int y)
{
    nod *aux=new nod;
    aux->inf = y;
    aux->urm = G[x];
    G[x]=aux;
}

void citire()
{
    int x,y,T;
    scanf("%d%d%d",&n,&m,&T);
    for(;T;--T)
    {
        scanf("%d%d",&x,&y);
        add(x,y);
    }
}

int pairup(int nood)
{
    if(viz[nood])
        return 0;
    viz[nood]=1;
    for(nod *p=G[nood];p;p=p->urm)
        if(!r[p->inf])
        {
            r[p->inf]=nood;
            l[nood]=p->inf;
            return 1;
        }
    for(nod *p=G[nood];p;p=p->urm)
        if(pairup(r[p->inf]))
        {
            r[p->inf]=nood;
            l[nood]=p->inf;
            return 1;
        }
    return 0;
}

void solve()
{
    int ok,cuplaj=0;
    do
    {
        ok=0;
        memset(viz,0,sizeof(viz));
        for(int i=1;i<=n;++i)
        if(!l[i]&&pairup(i))
        {
            cuplaj++;
            ok=1;
        }
    }while(ok);
    printf("%d\n",cuplaj);
    for(int i=1;i<=n;++i)
        if(l[i])
            printf("%d %d\n",i,l[i]);
}

int main()
{
    freopen("cuplaj.in","r",stdin);
    freopen("cuplaj.out","w",stdout);
    citire();
    solve();
    return 0;
}
