#include <bits/stdc++.h>
#define M 705
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("cmcm.in") ;
ofstream fout("cmcm.out") ;

int flux[M][M] , c[M][M] , eg[M][M] , dist[M] , parinte[M] ;
vector<pair<int,int> > graf[M] ;
int l , r , e , sol , solc;

void citire()
{
    int i , x , y , cost;
    fin >> l >> r >> e ;
    for ( i = 1 ; i <= e ; i++ )
    {
        fin >> x >> y >> cost;
        y = y+l ;
        c[x][y] = 1 ;
        eg[x][y] = i ;
        graf[x].push_back(make_pair(y,cost)) ;
        graf[y].push_back(make_pair(x,-cost)) ;
    }
    for ( i = 1 ; i <= l ; i++ )
    {
        c[0][i] = 1 ;
        graf[0].push_back(make_pair(i,0)) ;
    }
    for ( i = l+1 ; i <= l+r ; i++ )
    {
        c[i][l+r+1] = 1 ;
        graf[i].push_back(make_pair(l+r+1,0)) ;
    }
}

bool bfs()
{
    int nod ;
    queue<int> Q ;
    memset(dist,INF,sizeof(dist)) ;
    memset(parinte,0,sizeof(parinte)) ;
    Q.push(0) ;
    dist[0] = 0 ;
    while ( !Q.empty() )
    {
        nod = Q.front() ;
        Q.pop() ;
        for ( auto vec : graf[nod] )
        {
            if ( c[nod][vec.first] > flux[nod][vec.first] && dist[vec.first] > dist[nod] + vec.second )
            {
                dist[vec.first] = dist[nod] + vec.second ;
                Q.push(vec.first) ;
                parinte[vec.first] = nod ;
            }
        }
    }
    return (dist[l+r+1]!=INF) ;
}

int main()
{
    int i , j ;
    citire() ;
    while(bfs())
    {
        for ( i = l+r+1 ; i != 0 ; i = parinte[i] )
        {
            flux[parinte[i]][i]++ ;
            flux[i][parinte[i]]-- ;
        }
        sol++ ;
        solc = solc+dist[l+r+1] ;
    }
    fout << sol << " " << solc << '\n' ;
    for ( i = 1 ; i <= l ; i++ )
    {
        for ( j = l+1 ; j <= r+l ; j++ )
        {
            if ( c[i][j] && flux[i][j] )
                fout << eg[i][j] << " " ;
        }
    }
}
