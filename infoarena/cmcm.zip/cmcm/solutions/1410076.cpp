#include <cstdio>
#include <vector>
#include <cstring>
#include <queue>

#define NMAX 605
#define INF 0x3f3f3f3f3f

using namespace std;

bool ap[NMAX];

int boss[NMAX],best[NMAX],muchie[NMAX][NMAX];
int n,m,x,y,z,c,surs,dest,costmax,nr,numere,numarap[NMAX];

int cap[NMAX][NMAX],cost[NMAX][NMAX],cmuchi[NMAX*NMAX];

queue <int >q,sol;
vector <int>v[NMAX];

inline void build()
{
    for (int i=2;i<=n+1;i++)
    {
        v[1].push_back(i);
        //v[i].push_back(1);
        cap[1][i]=1;
    }
    for (int i=n+2;i<=n+m+1;i++)
    {
        v[i].push_back(n+m+2);
        //v[n+m+2].push_back(i);
        cap[i][n+m+2]=1;
    }
}
inline bool bellman(int surs)
{
    memset(ap,0,sizeof(ap));
    for (int i=1;i<=n+m+2;i++)best[i]=INF,boss[i]=0,numarap[i]=0;
    ap[surs]=1;
    q.push(surs);
    best[surs]=0;
    for (;!q.empty();q.pop())
    {
        int nod=q.front();
        ap[nod]=0;
        for (auto it:v[nod])
          if (best[it]>best[nod]+cost[nod][it] && cap[nod][it]>0)
          {
              boss[it]=nod;
              numarap[it]=numarap[nod]+1;
              best[it]=best[nod]+cost[nod][it];
              if (!ap[it])q.push(it);
          }
    }
    return boss[n+m+2]!=0;
}
int main()
{
   freopen("cmcm.in","r",stdin);
   freopen("cmcm.out","w",stdout);
   scanf("%d %d %d",&n,&m,&nr);
   for (int i=1;i<=nr;i++)
   {
       scanf("%d %d %d",&x,&y,&z);
       x++;
       y+=n+1;
       v[x].push_back(y);
       v[y].push_back(x);
       cost[x][y]=z;
       cost[y][x]=-z;
       cap[x][y]=1;
       muchie[x][y]=i;
       cmuchi[i]=z;
   }
   build();
   for (;bellman(1);)
   {
       for (int nod=n+m+2;boss[nod];nod=boss[nod])
       {
           cap[boss[nod]][nod]--;
           cap[nod][boss[nod]]++;
           costmax+=cost[boss[nod]][nod];
       }
       numere++;
      // if (numarap[n+m+2]==3)
         sol.push(muchie[boss[boss[n+m+2]]][boss[n+m+2]]);
       //printf("%d\n",costmax);
   }
   printf("%d %d\n",numere,costmax);
   for (;sol.size();sol.pop())printf("%d ",sol.front());

   fclose(stdin);
   fclose(stdout);
}
