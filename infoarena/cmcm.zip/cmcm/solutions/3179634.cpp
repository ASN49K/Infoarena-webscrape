#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int NMAX = 300;
const int MMAX = 300;

vector<int> graf[1 + NMAX + MMAX + 1];

int cost[1 + NMAX + MMAX + 1][1 + NMAX + MMAX + 1];
int capacitate[1 + NMAX + MMAX + 1][1 + NMAX + MMAX + 1];

queue<int> q;
bool inCoada[1 + NMAX + MMAX + 1];

priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

int distInitial[1 + NMAX + MMAX + 1];
int distDijkstra[1 + NMAX + MMAX + 1];
int distReala[1 + NMAX + MMAX + 1];

int tata[1 + NMAX + MMAX + 1];

vector<pair<int, int>> muchii;

vector<int> sol;

void bellmanFord(int n, int m)
{
    for (int i = 0; i <= n + m + 1; ++i)
        distInitial[i] = 1e9;

    distInitial[0] = 0;
    q.emplace(0);
    inCoada[0] = true;

    while (!q.empty())
    {
        int nod = q.front();
        q.pop();
        inCoada[nod] = false;

        for (int i = 0; i < graf[nod].size(); ++i)
        {
            int vecin = graf[nod][i];

            if (capacitate[nod][vecin] > 0 &&
                distInitial[nod] + cost[nod][vecin] < distInitial[vecin])
            {
                distInitial[vecin] = distInitial[nod] + cost[nod][vecin];

                if (!inCoada[vecin] && vecin != n + m + 1)
                {
                    q.emplace(vecin);
                    inCoada[vecin] = true;
                }
            }
        }
    }
}

bool dijkstra(int n, int m)
{
    for (int i = 0; i <= n + m + 1; ++i)
        tata[i] = -1;
    for (int i = 0; i <= n + m + 1; ++i)
        distDijkstra[i] = 1e9;

    distDijkstra[0] = 0;
    distReala[0] = 0;
    tata[0] = 0;
    pq.emplace(0, 0);

    while (!pq.empty())
    {
        int nod = pq.top().second;
        int distNod = pq.top().first;
        pq.pop();

        if (distNod > distDijkstra[nod])
            continue;

        for (int i = 0; i < graf[nod].size(); ++i)
        {
            int vecin = graf[nod][i];

            if (capacitate[nod][vecin] > 0 &&
                distNod + distInitial[nod] + cost[nod][vecin] - distInitial[vecin] < distDijkstra[vecin])
            {
                distDijkstra[vecin] = distNod + distInitial[nod] + cost[nod][vecin] - distInitial[vecin];
                distReala[vecin] = distReala[nod] + cost[nod][vecin];
                tata[vecin] = nod;

                if (vecin != n + m + 1)
                    pq.emplace(distDijkstra[vecin], vecin);
            }
        }
    }

    for (int i = 0; i <= n + m + 1; ++i)
        distInitial[i] = distReala[i];

    return distDijkstra[n + m + 1] < 1e9;
}

int main()
{
    ifstream in("cmcm.in");
    ofstream out("cmcm.out");

    ios_base::sync_with_stdio(false);
    in.tie(nullptr);
    out.tie(nullptr);

    int n, m, e;
    in >> n >> m >> e;

    for (int i = 1; i <= e; ++i)
    {
        int p, q, c;
        in >> p >> q >> c;

        graf[p].emplace_back(n + q);
        graf[n + q].emplace_back(p);

        cost[p][n + q] = c;
        cost[n + q][p] = -c;

        capacitate[p][n + q] = 1;

        muchii.emplace_back(make_pair(p, q));
    }

    for (int i = 1; i <= n; ++i)
    {
        graf[0].emplace_back(i);
        graf[i].emplace_back(0);

        capacitate[0][i] = 1;
    }

    for (int i = n + 1; i <= n + m; ++i)
    {
        graf[i].emplace_back(n + m + 1);
        graf[n + m + 1].emplace_back(i);

        capacitate[i][n + m + 1] = 1;
    }

    bellmanFord(n, m);

    int costMaxim = 0;

    while (dijkstra(n, m))
    {
        int capMinima = 1e9;

        for (int nodCrt = n + m + 1; nodCrt != tata[nodCrt]; nodCrt = tata[nodCrt])
            capMinima = min(capMinima, capacitate[tata[nodCrt]][nodCrt]);
        for (int nodCrt = n + m + 1; nodCrt != tata[nodCrt]; nodCrt = tata[nodCrt])
        {
            capacitate[tata[nodCrt]][nodCrt] -= capMinima;
            capacitate[nodCrt][tata[nodCrt]] += capMinima;
        }

        costMaxim += distReala[n + m + 1] * capMinima;
    }

    for (int i = 0; i < muchii.size(); ++i)
        if (capacitate[muchii[i].first][n + muchii[i].second] == 0)
            sol.emplace_back(i + 1);

    out << sol.size() << ' ' << costMaxim << '\n';

    for (int i = 0; i < sol.size(); ++i)
        out << sol[i] << ' ';
    out << '\n';

    in.close();
    out.close();

    return 0;
}
