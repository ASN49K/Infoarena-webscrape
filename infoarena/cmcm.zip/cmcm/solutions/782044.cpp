#include<fstream>
#define inf 1000000000
using namespace std;
typedef struct celula{
        short nod;
        celula *next;
        }*lista;
typedef struct w{short x,y;}muchie;
muchie a[50001];
lista graf[605],v,f;
int e,sol,dist[605],dep[305],i;
short tata[605],cost[601][601],n,m;
bool cap[601][601],ok;

inline void update(){
       int nod=n+m+1; sol+=dist[n+m+1];
        while (tata[nod]!=nod){
            cap[tata[nod]][nod]=false;
            cap[nod][tata[nod]]=true;
            nod=tata[nod];
           }
}

inline void ford(){
       for (i=1; i<=n+m+1; ++i) dist[i]=inf; 
       v=new celula; v->nod=0; v->next=0; f=v; 
       while (v!=0) {
             for (lista p=graf[v->nod];p; p=p->next)
              if ( cap[v->nod][p->nod]==true&&dist[v->nod]+cost[v->nod][p->nod]<dist[p->nod] ){
                   dist[p->nod]=dist[v->nod]+cost[v->nod][p->nod];
                   lista aux=new celula; aux->nod=p->nod; aux->next=0; f->next=aux; f=aux;
                   tata[p->nod]=v->nod;
                  }
         v=v->next;
        }
       if (dist[n+m+1]==inf) ok=false;
}

int main(void){
    ifstream fin("cmcm.in");
    ofstream fout("cmcm.out");
    fin>>n>>m>>e; int x,y,c,nr=0;
    for (i=1; i<=e; ++i){
        fin>>x>>y>>c; y+=n; cost[x][y]=c; cost[y][x]=-c; cap[x][y]=true;
        v=new celula; v->nod=y; v->next=graf[x]; graf[x]=v;
        v=new celula; v->nod=x; v->next=graf[y]; graf[y]=v;
        a[i].x=x; a[i].y=y;
        }
    // adaug sursa
    for (i=1; i<=n; ++i){
     cap[0][i]=true; 
       v=new celula; v->nod=0; v->next=graf[i]; graf[i]=v;
        v=new celula; v->nod=i; v->next=graf[0]; graf[0]=v;
        }
    //adaug destinatia
    for (i=1; i<=m; ++i){
      cap[i+n][n+m+1]=true; 
       v=new celula; v->nod=i+n; v->next=graf[n+m+1]; graf[n+m+1]=v;
        v=new celula; v->nod=n+m+1; v->next=graf[i+n]; graf[i+n]=v;
        }
    ok=true;
     while (ok==true){ford(); if (ok) update(); }
    for (i=1; i<=e; ++i)
     if (cap[a[i].x][a[i].y]==false){++nr; dep[nr]=i; }
    fout<<nr<<" "<<sol<<"\n";
    for (i=1; i<=nr; ++i) fout<<dep[i]<<" ";
 return(0);
}
