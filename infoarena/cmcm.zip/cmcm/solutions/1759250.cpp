#include<cstdio>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<vector>
#include<bitset>
#include<deque>
#include<queue>
#include<set>
#include<map>
#include<cmath>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<unordered_map>

#define ll long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define pll pair<ll,ll>
#define all(x) (x).begin(), (x).end()
#define fi first
#define se second

using namespace std;

const int nmax = 605;
const int inf = (1LL << 31) - 1;

int n, m, e, i, j, x, y, z, source, sink, add, cuplaj, mincost;
vector<vector<int>> cap, flow, cost, edge;
vector<int> dist, f;

vector<int> v[nmax];
bitset<nmax> inq;
deque<int> q;

bool bf() {
    for (i = 0; i <= sink; i++) {
        dist[i] = inf;
        f[i] = 0;
    }

    dist[source] = 0;
    f[source] = source;
    inq[source] = 1;
    q.pb(source);

    while (!q.empty()) {
        x = q.front();
        q.pop_front();
        inq[x] = 0;

        for (auto it : v[x])
            if (dist[x] + cost[x][it] < dist[it] && flow[x][it] < cap[x][it]) {
                dist[it] = dist[x] + cost[x][it];
                f[it] = x;
                if (!inq[it]) {
                    inq[it] = 1;
                    q.pb(it);
                }
            }
    }

    return dist[sink] != inf;
}

int main() {
    clock_t start = clock();

    freopen("cmcm.in", "r", stdin);
    freopen("cmcm.out", "w", stdout);

    cap.resize(nmax, vector<int>(nmax, 0));
    flow.resize(nmax, vector<int>(nmax, 0));
    cost.resize(nmax, vector<int>(nmax, 0));
    edge.resize(nmax, vector<int>(nmax, 0));
    dist.resize(nmax);
    f.resize(nmax);

    scanf("%d%d%d", &n, &m, &e);

    for (i = 1; i <= e; i++) {
        scanf("%d%d%d", &x, &y, &z);
        y += n;

        edge[x][y] = i;

        v[x].pb(y);
        v[y].pb(x);

        cap[x][y] = 1;
        cost[x][y] = z;
        cost[y][x] = -z;
    }

    source = 0;
    sink = n + m + 1;

    for (i = 1; i <= n; i++) {
        v[source].pb(i);
        cap[source][i] = 1;
    }

    for (i = n + 1; i <= n + m; i++) {
        v[i].pb(sink);
        cap[i][sink] = 1;
    }

    while (bf()) {
        add = inf;

        for (x = sink; x != f[x]; x = f[x])
            add = min(add, cap[f[x]][x] - flow[f[x]][x]);

        for (x = sink; x != f[x]; x = f[x]) {
            flow[f[x]][x] += add;
            flow[x][f[x]] -= add;
        }

        cuplaj += add;
        mincost += add * dist[sink];
    }

    printf("%d %d\n", cuplaj, mincost);

    for (i = 1; i <= n; i++)
        for (j = n + 1; j <= n + m; j++)
            if (flow[i][j])
                printf("%d ", edge[i][j]);

    clock_t finish = clock();
    cerr << fixed << 1.0 * (finish - start) / CLOCKS_PER_SEC << endl;

    return 0;
}
