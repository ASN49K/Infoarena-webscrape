#include<cstdio>
int n,m,z,i,j,p,q,t,l,r,k,e,c[602][602],f[602][602],a[50001],b[50001],u[602],v[602][602],x[50001],w[50001],g[602];
int main()
{
	freopen("cmcm.in","r",stdin),freopen("cmcm.out","w",stdout),scanf("%d%d%d",&n,&m,&k);
	for(i=1;i<=k;i++)
    	scanf("%d%d%d",a+i,b+i,&z),c[a[i]][b[i]+n+1]=1,v[a[i]][b[i]+n+1]=z,v[b[i]+n+1][a[i]]=-z;
	for(i=1;i<=n;i++)
    	c[0][i]=1;
	for(i=n+2;i<=n+m+1;i++)
    	c[i][n+1]=1;
	while(1)
    {
		for(i=1;i<=n+m+1;i++)
            u[i]=0,g[i]=50001;
       	for(g[0]=p=w[0]=0,q=1;p<q;)
		   	for(t=w[p++],t&&t<=n?j=n+1,z=n+m+1:j=1,z=n+1,i=j;i<=z;i++)
                if(f[t][i]<c[t][i]&&g[i]>g[t]+v[t][i])
                    w[q++]=i,u[i]=t,g[i]=g[t]+v[t][i];
       	if(!u[n+1])
            break;
       	for(l=n+1;l;l=u[l])
            f[u[l]][l]++,f[l][u[l]]--;
       	e+=g[n+1];
	}
	for(i=1;i<=k;i++)
        if(f[a[i]][b[i]+n+1]==1)
            x[r++]=i;
	printf("%d %d\n",r,e);
	for(i=0;i<r;i++)
       	printf("%d ",x[i]);
}
