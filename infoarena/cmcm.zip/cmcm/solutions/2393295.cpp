#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int NMax = 600, oo = 1e9;

int N, D[NMax + 5][NMax + 5], F[NMax + 5][NMax + 5], C[NMax + 5][NMax + 5], M, Ind[NMax + 5][NMax + 5], DP[NMax + 5], TT[NMax + 5], Flow, Cost;

bool InQ[NMax + 5];

vector <int> G[NMax + 5]; queue <int> Q;

void Read()
{
    int l, r; fin >> l >> r >> M;

    N = l + r + 2;

    for(int i = 1, x, y, c; i <= M; i++)
    {
        fin >> x >> y >> c; x++, y += x + l;

        G[x].push_back(y);
        G[y].push_back(x);
        Ind[x][y] = i, D[x][y] = 1, C[x][y] = c, C[y][x] = -c;
    }
    l++;

    for(int i = 2; i <= l; i++)
    {
        G[1].push_back(i);
        G[i].push_back(1);
        D[1][i] = 1;
    }
    for(int i = l + 1; i < N; i++)
    {
        G[N].push_back(i);
        G[i].push_back(N);
        D[i][N] = 1;
    }
}

bool BellmanFord()
{
    for(int i = 1; i <= N; i++)
        DP[i] = oo, TT[i] = 0, InQ[i] = 0;

    Q.push(1), InQ[1] = 1, DP[1] = 0;

    while(!Q.empty())
    {
        int Nod = Q.front(); Q.pop(), InQ[Nod] = 0;

        for(auto Vecin : G[Nod])
            if(DP[Nod] + C[Nod][Vecin] < DP[Vecin] && F[Nod][Vecin] < D[Nod][Vecin])
            {
                DP[Vecin] = DP[Nod] + C[Nod][Vecin], TT[Vecin] = Nod;

                if(InQ[Vecin] == 0)
                    Q.push(Vecin), InQ[Vecin] = 1;
            }
    }
    return (DP[N] != oo);
}

void Solve()
{
    while(BellmanFord())
    {
        for(int i = N; i != 1; i = TT[i])
            F[i][TT[i]]--, F[TT[i]][i]++;

        Flow++, Cost += DP[N];
    }
}

void Print()
{
    fout << Flow << " " << Cost << '\n';

    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= N; j++)
        {
            if(F[i][j] == 1 && Ind[i][j])
                fout << Ind[i][j] << " ";
        }
    fout << '\n';
}

int main()
{
    Read();
    Solve();
    Print();

    return 0;
}
