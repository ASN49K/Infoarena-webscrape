#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int inf = 1e9;

const string txt = "data", file = "cmcm";
const int nmax = 1e6 + 5;

ifstream f(file + ".in");
ofstream g(file + ".out");

int l, r, e, flow[305][305], cost[305][305], d[305];
int nd[305], fr[305], t[305], sour, dest, n, idk[305];
vector<int> v[nmax];
vector<pair<int, int>> edge;

void bellman()
{
	for (int i = 0; i <= n + 1; i++) d[i] = inf;
	queue<int> q; while (!q.empty()) q.pop();

	d[sour] = 0; q.push(sour);
	while (!q.empty())
	{
		int node = q.front(); q.pop();
		for (auto x : v[node])
			if (flow[node][x] && d[x] > d[node] + cost[node][x])
				d[x] = d[node] + cost[node][x], q.push(x);
	}
}

int dijkstra()
{
	for (int i = 0; i <= n + 1; i++) nd[i] = idk[i] = inf, fr[i] = t[i] = 0;
	priority_queue< pair<int, int> > H; while (!H.empty()) H.pop();

	nd[sour] = idk[sour] = 0; H.push({ 0, sour });
	while (!H.empty())
	{
		int node = H.top().second; H.pop();
		if (fr[node]) continue;

		fr[node] = 1;
		for (auto x : v[node])
		{
			int val = idk[node] + cost[node][x] + d[node] - d[x];

			if (flow[node][x] && idk[x] > val)
			{
				idk[x] = val; t[x] = node;
				nd[x] = nd[node] + cost[node][x];
				H.push({ -val, x });
			}
		}
	}

	return fr[dest];
}

int maxflow()
{
	int ans = 0; bellman();
	while (dijkstra())
	{
		for (int i = 0; i <= n + 1; i++) d[i] = nd[i];
		ans += d[dest];

		for (int i = dest; i != sour; i = t[i])
			flow[t[i]][i]--, flow[i][t[i]]++;
	}

	return ans;
}

void add(int x, int y, int c)
{
	v[x].push_back(y);
	v[y].push_back(x);
	
	cost[x][y] = c;
	cost[y][x] = -c;

	flow[x][y] = 1;
}

int main()
{
	f >> l >> r >> e;
	for (int i = 1; i <= e; i++)
	{
		int x, y, c; f >> x >> y >> c;
		add(x, y + l, c); edge.push_back({ x, y + l });
	}

	n = l + r;
	sour = 0; dest = n + 1;
	
	for (int i = 1; i <= l; i++) add(0, i, 0);
	for (int i = l + 1; i <= n; i++) add(i, dest, 0);

	int ans = maxflow();
	vector<int> aux; aux.clear();

	for (int i = 0; i < e; i++)
		if (!flow[edge[i].first][edge[i].second])
			aux.push_back(i + 1);

	g << aux.size() << " " << ans << '\n';
	for (auto x : aux)
		g << x << " ";
	return 0;
}