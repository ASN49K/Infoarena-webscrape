#include <fstream>
#include <string.h>
#include <stdlib.h>
#define abmax 605
#define mmax  50005
#define inf 1000000005
using namespace std;
fstream f1("cmcm.in", ios::in);
fstream f2("cmcm.out", ios::out);
int a, b, aux[abmax], cap[abmax], cost[abmax][abmax], ca[abmax]

[abmax], ind[abmax][abmax],nrfin;
int v[(abmax+mmax)*2], viz[abmax], s, d, pred[abmax], fin[mmax];
long int m, dist[abmax], coada[abmax], prim, ultim, k, fmax, ct;
struct muchii
{
    int x, y;
}muc[mmax];
void citire()
{
    long int i;
    int c, x, y;
    f1>>a>>b>>m;
    s=1; d=a+b+2;
    for(i=1; i<=m; i++)
    {
        f1>>muc[i].x>>muc[i].y>>c;
        muc[i].x++;
        muc[i].y+=(a+1);
        ind[muc[i].x][muc[i].y]=i;
        x=muc[i].x; y=muc[i].y;
        aux[x]++;
        aux[y]++;
        cost[x][y]=c;
        cost[y][x]=-c;
        ca[x][y]=1;
    }

    aux[1]=a;
    for(i=a+2; i<=a+b+1; i++)
    {
        ca[i][d]=1;
        aux[i]++;
    }
    cap[1]=1;
    for(i=2; i<=d+2; i++)
    {
        cap[i]=cap[i-1]+aux[i-1];
        aux[i-1]=cap[i-1];
    }

    for(i=2; i<=a+1; i++)
    {
        ca[s][i]=1;
        v[aux[s]]=i;
        aux[s]++;
    }
    for(i=1; i<=m; i++)
    {
        x=muc[i].x;
        y=muc[i].y;
        v[aux[x]]=y;
        aux[x]++;
        v[aux[y]]=x;
        aux[y]++;
    }
     for(i=a+2; i<=a+b+1; i++)
     {
         v[aux[i]]=d;
         aux[i]++;
     }
}
void initb()
{
    int i;
    memset(viz, 0, sizeof(viz));
    memset(pred, 0, sizeof(pred));
    for(i=1; i<=a+b+2; i++)
        dist[i]=inf;
    dist[s]=0;
    viz[s]=1;
    prim=1;
    ultim=1;
    k=1;
    coada[ultim]=s;
}
void actual()
{
   int nod;
   nod=d;
   while(pred[nod])
   {
       ca[pred[nod]][nod]-=1;
       ca[nod][pred[nod]]+=1;
       nod=pred[nod];
   }
   fmax++;
}
int bellman()
{
    long int i;
    int nod, vec;
    while(k!=0)
    {
        nod=coada[prim];
        viz[nod]=0;
        prim++;
        if(prim> abmax-2) prim=1;
        k--;

        for(i=cap[nod]; i<cap[nod+1]; i++)
            if(ca[nod][v[i]]>0)
        {
            vec=v[i];
            if(dist[vec]> dist[nod]+ cost[nod][vec])
            {
                dist[vec]= dist[nod]+ cost[nod][vec];
                pred[vec]=nod;
                if(!viz[vec])
                {
                    viz[vec]=1;
                    ultim++;
                    if(ultim> abmax-2) ultim=1;
                    k++;
                    coada[ultim]=vec;
                }
            }
        }
    }
    if(dist[d]==inf) return 0;
    else
    {
        actual();
        return 1;
    }
}
void solutie()
{
    long int i;
    int x, y;
    for(i=1; i<=m; i++)
    {
       x=muc[i].x;
       y=muc[i].y;
       if(ca[x][y]==0)
       {
           nrfin++;
           fin[nrfin]=ind[x][y];
           ct+=cost[x][y];
       }
    }
    f2<<fmax<<' '<<ct<<"\n";
    for(i=1; i<=nrfin; i++)
        f2<<fin[i]<<' ';
}
int main()
{
    citire();
    initb();
    while(bellman())
    {
        initb();
    }
    solutie();
    return 0;
}
