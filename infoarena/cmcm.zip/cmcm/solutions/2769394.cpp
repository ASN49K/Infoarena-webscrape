#include <bits/stdc++.h>
#define NMAX 605
#define INF 0x3f3f3f3f

using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int n, m, e, flux, ans, C[NMAX][NMAX], F[NMAX][NMAX], cost[NMAX][NMAX], d[NMAX], t[NMAX];
bitset <NMAX> v;
vector <pair <int, int>> edges[NMAX];
queue <int> q;

bool bf()
{
    v.reset();
    memset(d, INF, sizeof(d));
    v[0] = 1;
    d[0] = 0;
    q.push(0);

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        v[nod] = 0;
        for(auto child : edges[nod])
            if(C[nod][child.first] > F[nod][child.first] && d[child.first] > d[nod] + cost[nod][child.first])
            {
                d[child.first] = d[nod] + cost[nod][child.first];
                t[child.first] = nod;
                if(!v[child.first])
                {
                    v[child.first] = 1;
                    q.push(child.first);
                }
            }
    }
    return (d[n + m + 1] != INF);
}

int main()
{
    f >> n >> m >> e;

    for(int i = 1; i <= e; i++)
    {
        int x, y, c;
        f >> x >> y >> c;
        edges[x].push_back(make_pair(n + y, i));
        edges[n + y].push_back(make_pair(x, 0));
        edges[0].push_back(make_pair(x, 0));
        edges[x].push_back(make_pair(0, 0));
        edges[n + y].push_back(make_pair(n + m + 1, 0));
        edges[n + m + 1].push_back(make_pair(n + y, 0));

        cost[x][y + n] = c;
        cost[y + n][x] = -c;
        C[x][y + n] = C[0][x] = C[y + n][n + m + 1] = 1;
    }

    while(bf())
    {
        int minim = INF;
        int k = n + m + 1;
        while(k != 0)
        {
            minim = min(minim, C[t[k]][k] - F[t[k]][k]);
            k = t[k];
        }

        k = n + m + 1;
        while(k != 0)
        {
            F[t[k]][k] += minim;
            F[k][t[k]] -= minim;
            k = t[k];
        }
        ans += d[n + m + 1] * minim;
        flux += minim;
    }

    g << flux << " " << ans << "\n";

    for(int i = 1; i <= n; i++)
        for(auto child : edges[i])
            if(F[i][child.first] == 1)
            {
                g << child.second << " ";
                break;
            }

    return 0;
}
