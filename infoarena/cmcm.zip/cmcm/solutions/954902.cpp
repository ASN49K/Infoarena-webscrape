#include <vector>
#include <queue>
#include <fstream>
#define NN 620
#define INF (1<<30)
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
 
 
int A[NN][NN],IND[NN][NN],Z[NN][NN];
int Dist[NN],Q[NN],R[NN],TT[NN];
bool in_q[NN];
queue <int> q;
int N,MM,E;
int flux,ans,sum;
vector <int> M[620];
int st,dr;
 
inline void fa_muchie(int x,int y,int cost,int ind)
{
    A[x][y]=1;
    Z[x][y]=cost;
    IND[x][y]=ind;
    Z[y][x]=-cost;
    M[x].push_back(y);
    M[y].push_back(x);
}
 
void read()
{
    int i,x,y,z;
    f>>N>>MM>>E;
 
    st=1; dr=N+MM+2;
    for (i=1;i<=E;i++)
    {
        f>>x>>y>>z;
        fa_muchie(x+1,y+1+N,z,i);
    }
    for (i=1;i<=N;i++)
        fa_muchie(1,i+1,0,-1);
    for (i=1;i<=MM;i++)
        fa_muchie(i+1+N,dr,0,-1);
}
 
int bellman()
{
    int i,x,mn,it,j;
 
 
    for (i=1;i<=dr;i++)
        Dist[i]=INF;
 
 
    Dist[st]=0;
    q.push(st);
 
    while (!q.empty())
    {
        x=q.front();
        in_q[x]=false;
        q.pop();
 
        for (j=0;j<M[x].size();j++)
        {
            it=M[x][j];
            if (A[x][it] && Dist[x]+Z[x][it]<Dist[it])
            {
                Dist[it]=Dist[x]+Z[x][it] ;
                TT[it]=x;
                if (!in_q[it])
                {
                    in_q[it]=true;
                    q.push(it);
                }
            }
        }
    }
 
    if (Dist[dr]==INF) return 0;
 
    for (x=dr;x!=st;x=TT[x])
    {
        A[TT[x]][x]-=1;
        A[x][TT[x]]+=1;
    }
    ans+=Dist[dr];
    flux+=1;
    return 1;
}
 
void solve()
{
    int i,j;
 
    while (bellman());
    g<<flux<<' '<<ans<<'\n';
    for (i=2;i<=N+1;i++)
        for (j=N+2;j<dr;j++)
            if (A[i][j]==0 && IND[i][j]>=1)
                g<<IND[i][j]<<' ';
 
}
 
 
 
int main()
{
    read();
    solve();
 
    return 0;
}
