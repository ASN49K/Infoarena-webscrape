#include <bits/stdc++.h>
using namespace std;

ifstream fin ("cmcm.in");
ofstream fout("cmcm.out");

const int dim=1009,inf=2e9;

vector<int>adj[dim];

int S,D;
int dist[dim];
int flow[dim][dim];
int capacity[dim][dim],cost[dim][dim];

int cost_minim_flux;

int d[dim],real_dist[dim],parent[dim];
priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;

bool Dijkstra(){
    for(int i=1;i<=D;i++){
        d[i]=inf;
    }
    d[S]=real_dist[S]=0;
    pq.push({d[S],S});

    while(!pq.empty()){
        int cost_curent=pq.top().first,x=pq.top().second;
        pq.pop();
        if(d[x]==cost_curent){
            for(int y:adj[x]){
                if(capacity[x][y]-flow[x][y]){
                    int new_d=d[x]+cost[x][y]+dist[x]-dist[y];
                    if(new_d<d[y]){
                        d[y]=new_d;
                        real_dist[y]=real_dist[x]+cost[x][y];
                        parent[y]=x;
                        pq.push({d[y],y});
                    }
                }
            }
        }
    }
    for(int i=1;i<=D;i++){
        dist[i]=real_dist[i];
    }
    if(d[D]==inf){
        return false;
    }
    int minim=inf,cur=D;
    while(cur!=S){
        minim=min(minim,capacity[parent[cur]][cur]-flow[parent[cur]][cur]);
        cur=parent[cur];
    }
    cost_minim_flux+=minim*real_dist[D];
    cur=D;
    while(cur!=S){
        flow[parent[cur]][cur]+=minim;
        flow[cur][parent[cur]]-=minim;
        cur=parent[cur];
    }
    return true;
}

bool InQueue[dim];
void BellmanFord(){
    for(int i=1;i<=D;i++){
        dist[i]=inf;
    }
    queue<int>q;
    dist[S]=0;
    q.push(S);
    InQueue[S]=true;
    while(!q.empty()){
        int x=q.front();
        InQueue[x]=false;
        q.pop();
        for(int y:adj[x]){
            if(capacity[x][y]){
                if(dist[x]+cost[x][y]<dist[y]){
                    dist[y]=dist[x]+cost[x][y];
                    if(!InQueue[y]){
                        q.push(y);
                        InQueue[y]=true;
                    }
                }
            }
        }
    }
}

int l,r,e;
int edge[dim][dim];

void build_graph(){
    S=1,D=l+r+2;
    for(int i=2;i<=l+1;i++){
        adj[S].push_back(i);
        cost[S][i]=0;
        adj[i].push_back(S);
        cost[i][S]=0;
        capacity[S][i]=1;
    }
    for(int i=l+2;i<=l+r+1;i++){
        adj[D].push_back(i);
        cost[D][i]=0;
        adj[i].push_back(D);
        cost[i][D]=0;
        capacity[i][D]=1;
    }
}

signed main(){
        fin>>l>>r>>e;
    for(int i=1;i<=e;i++){
        int x,y;
        fin>>x>>y;
        x=x+1,y=y+l+1;
        fin>>cost[x][y];
        capacity[x][y]=1;
        adj[x].push_back(y);
        adj[y].push_back(x);
        cost[y][x]=-cost[x][y];
        edge[x][y]=i;
        edge[y][x]=i;
    }
    build_graph();

    BellmanFord();
    while(Dijkstra()){
    }

    int nr_edges=0;
    for(int i=2;i<=l+1;i++){
        for(int j=l+2;j<D;j++){
            if(capacity[i][j]&&flow[i][j]){
                nr_edges++;
                break;
            }
        }
    }

        fout<<nr_edges<<' '<<cost_minim_flux<<'\n';
    for(int i=2;i<=l+1;i++){
        for(int j=l+2;j<D;j++){
            if(capacity[i][j]&&flow[i][j]){
                fout<<edge[i][j]<<' ';
                break;
            }
        }
    }
}
