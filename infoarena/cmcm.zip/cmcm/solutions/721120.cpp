#include <cstdio>
#define N 705
#define E 50005
#define inf 199999999
using namespace std;
struct nod{ int val; nod *urm; }*G[N];
int cap[N][N],flux[N][N],cost[N][N],muc[N][N];
int dist[N],tata[N],viz[N],SS,SD,c[E*2];
int n,m,ct,k,sol[E];
void read()
{ int i,e,x,y,z;
  nod *aux;
freopen("cmcm.in","r",stdin); scanf("%d %d %d\n",&n,&m,&e);
for(i=1;i<=e;++i)
    {
    scanf("%d %d %d\n",&x,&y,&z);
    muc[x][y+n]=i;
    cap[x][y+n]=1; cap[y+n][x]=0; cost[x][y+n]=z; cost[y+n][x]=-z;
    aux=new nod; aux->val=y+n; aux->urm=G[x]; G[x]=aux;
    aux=new nod; aux->val=x; aux->urm=G[y+n]; G[y+n]=aux;
    }
fclose(stdin);
}
inline int min(int x,int y)
{
if(x<y)return x;
return y;
}
int bellman_ford()
{ int p,u,i,x,y;
  nod *aux;
dist[SS]=dist[SD]=inf; tata[SS]=tata[SD]=0; viz[SS]=viz[SD]=0;
for(i=1;i<=n+m;++i)
    {
    dist[i]=inf; viz[i]=0; tata[i]=0;
    }
dist[SS]=0; viz[SS]=1;
p=u=1; c[1]=SS;
while(p<=u)
    {
    x=c[p]; viz[x]=0;
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        {
        y=aux->val;
        if(cap[x][y]>flux[x][y]&&dist[y]>dist[x]+cost[x][y])
            {
            dist[y]=dist[x]+cost[x][y];
            tata[y]=x;
            if(viz[y]==0)
                {
                c[++u]=y;
                viz[y]=1;
                }
            }
        }
    ++p;
    }
if(dist[SD]<inf)return 1;
    else return 0;
}
void solve()
{ int i,fm;
  bool gata;
gata=false;
while(bellman_ford()&&!gata)
    {
    fm=inf;
    for(i=SD;i!=SS;i=tata[i])
        fm=min(cap[tata[i]][i]-flux[tata[i]][i],fm);
    if(fm)
        {
        for(i=SD;i!=SS;i=tata[i])
        {
        flux[tata[i]][i]+=fm;
        flux[i][tata[i]]-=fm;
        }
        }
    else gata=true;
    }
}
int main()
{ int i;
  nod *aux;
read();
SS=601; SD=602;
for(i=1;i<=n;++i)
    {
    aux=new nod; aux->val=i; aux->urm=G[SS]; G[SS]=aux;
    aux=new nod; aux->val=SS; aux->urm=G[i]; G[i]=aux;
    cap[SS][i]=1; cap[i][SS]=0; cost[SS][i]=cost[i][SS]=0;
    }
for(i=1;i<=m;++i)
    {
    aux=new nod; aux->val=SD; aux->urm=G[i+n]; G[i+n]=aux;
    aux=new nod; aux->val=i+n; aux->urm=G[SD]; G[SD]=aux;
    cap[i+n][SD]=1; cap[SD][i+n]=0; cost[i+n][SD]=cost[SD][i+n]=0;
    }
solve();
ct=k=0;
for(i=1;i<=n;++i)
    for(aux=G[i];aux!=NULL;aux=aux->urm)
        if(flux[i][aux->val]==1)
            {
            sol[++k]=muc[i][aux->val];
            ct+=cost[i][aux->val];
            }
freopen("cmcm.out","w",stdout); printf("%d %d\n",k,ct);
for(i=1;i<=k;++i)printf("%d ",sol[i]);
fclose(stdout);
}
