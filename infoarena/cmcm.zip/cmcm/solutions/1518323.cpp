#include<fstream>
#include<vector>
#include<bitset>
#include<deque>
#define inf 1000000000
using namespace std;
vector<int> L[605];
bitset<605> U;
deque<int> q;
pair<int, int> xx[50003];
int T[605], x, y, z, n, nrx, m, nrm, i, minim, nod, flux, cost, C[605][605], F[605][605], Z[605][605], D[605], vecin;
ifstream in("cmcm.in");
ofstream out("cmcm.out");
int bf()
{
    for(int i=0; i<=m+1; i++)
        D[i]=inf;
    D[0]=0;
    q.clear();
    q.push_back(0);
    U.reset();
    U[0]=1;
    while(!q.empty())
    {
        nod=*q.begin();
        for(int i=0; i<L[nod].size(); i++)
        {
            vecin=L[nod][i];
            if(C[nod][vecin]-F[nod][vecin]>0 && D[vecin]>D[nod]+Z[nod][vecin])
            {
                D[vecin]=D[nod]+Z[nod][vecin];
                T[vecin]=nod;
                if(U[vecin]==0)
                {
                    q.push_back(vecin);
                    U[vecin]=1;
                }
            }
        }
        q.pop_front();
        U[nod]=0;
    }
    if(D[m+1]!=inf)
        return 1;
    return 0;
}
int main()
{
    in>>n>>m>>nrm;
    m+=n;
    for(i=1; i<=nrm; i++)
    {
        in>>x>>y>>z;
        if(C[x][y+n]==0)
        {
            L[x].push_back(n+y);
            L[n+y].push_back(x);
            Z[x][n+y]=z;
            Z[y+n][x]=-z;
            C[x][y+n]=1;
            xx[++nrx].first=x;
            xx[nrx].second=y+n;
        }
    }
    for(i=1; i<=n; i++)
    {
        L[0].push_back(i);
        L[i].push_back(0);
        C[0][i]=1;
    }
    for(i=n+1; i<=m; i++)
    {
        L[i].push_back(m+1);
        L[m+1].push_back(i);
        C[i][m+1]=1;
    }
    while(bf())
    {
        minim=inf;
        for(nod=m+1; nod!=0 && minim!=0; nod=T[nod])
        {
            minim=min(minim, C[T[nod]][nod]-F[T[nod]][nod]);
        }
        flux+=minim;
        for(nod=m+1; nod!=0; nod=T[nod])
        {
            cost+=minim*Z[T[nod]][nod];
            F[T[nod]][nod]+=minim;
            F[nod][T[nod]]-=minim;
        }
    }
    out<<flux<<" "<<cost<<"\n";
    for(i=1; i<=nrx; i++)
    {
        if(F[xx[i].first][xx[i].second]>0)
            out<<i<<" ";
    }
    return 0;
}
