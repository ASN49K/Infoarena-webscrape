#include <fstream>
#include <vector>
#include <queue>
#define INF 2000000000
#define MAXN 305
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");

struct muchie{
    int nod1,nod2;};

int n,m,e,x,y,d,mn,flux[2*MAXN][2*MAXN],cap[2*MAXN][2*MAXN],cost[2*MAXN][2*MAXN],dist[2*MAXN],back[2*MAXN],cuplmax,costmin;
vector<int> G[2*MAXN],msel;
vector<muchie> muchii;
muchie aux;
queue<int> q;
bool uz[2*MAXN];

bool belman_ford();

int main()
{
    int i;
    f>>n>>m>>e;
    for(i=1;i<=e;i++){
        f>>x>>y;
        y+=n;
        f>>cost[x][y];
        G[x].push_back(y);
        G[y].push_back(x);
        cap[x][y]=1;
        cost[y][x]=-cost[x][y];
        aux.nod1=x;
        aux.nod2=y;
        muchii.push_back(aux);}
    for(i=1;i<=n;i++){
        G[0].push_back(i);
        cap[0][i]=1;
        G[i].push_back(0);}
    for(i=1;i<=m;i++){
        G[i+n].push_back(n+m+1);
        cap[i+n][n+m+1]=1;
        G[n+m+1].push_back(i+n);}
    while(belman_ford()){
        x=n+m+1;
        while(back[x]){
            y=x;
            x=back[x];
            flux[x][y]++;
            flux[y][x]--;}
        flux[back[x]][x]++;
        flux[x][back[x]]--;}
    for(i=0;i<muchii.size();i++){
        if(flux[muchii[i].nod1][muchii[i].nod2]){
            cuplmax++;
            costmin+=cost[muchii[i].nod1][muchii[i].nod2];
            msel.push_back(i+1);}}
    g<<cuplmax<<' '<<costmin<<'\n';
    for(i=0;i<msel.size();i++)
        g<<msel[i]<<' ';
    f.close();
    g.close();
    return 0;
}

bool belman_ford(){
    int i;
    for(i=1;i<=n+m+1;i++)
        dist[i]=INF;
    dist[0]=0;
    uz[0]=1;
    q.push(0);
    while(!q.empty()){
        x=q.front();
        uz[x]=0;
        q.pop();
        d=dist[x];
        for(i=0;i<G[x].size();i++){
            if(d+cost[x][G[x][i]]<dist[G[x][i]]&&flux[x][G[x][i]]<cap[x][G[x][i]]){
                dist[G[x][i]]=d+cost[x][G[x][i]];
                back[G[x][i]]=x;
                if(!uz[G[x][i]]){
                    uz[G[x][i]]=1;
                    q.push(G[x][i]);}}}}
    return !(dist[n+m+1]==INF);}

