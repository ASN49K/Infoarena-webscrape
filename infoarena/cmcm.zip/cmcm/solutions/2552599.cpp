#include <bits/stdc++.h>
#define NMAX 650
using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

vector < pair<int,int > > v[NMAX];
priority_queue < pair <int,int> , vector <pair <int,int> > , greater < pair <int,int> > > h;
int N,s,flux_maxim,cost_min,d,dist[NMAX],flux[NMAX][NMAX],C[NMAX][NMAX],cost[NMAX][NMAX],dist_min[NMAX],tata[NMAX],new_dist[NMAX];


int Dijkstra()
{
    int i,nod,flux_min;

    for(i=0;i<=N;i++)dist_min[i]=INT_MAX/2,tata[i]=-1;
    dist_min[s]=0;new_dist[s]=0;
    h.push({0,s});

    while(!h.empty())
    {
        nod=h.top().second;
        if(dist_min[nod]!=h.top().first){h.pop();continue;}
        else h.pop();

        for(i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i].first;
            int muchie=v[nod][i].second;
            int dist_intre=cost[nod][vecin]+dist[nod]-dist[vecin];
            if(flux[nod][vecin] < C[nod][vecin] && dist_min[vecin]>dist_min[nod]+dist_intre)
            {
                dist_min[vecin]=dist_min[nod]+dist_intre;
                new_dist[vecin]=cost[nod][vecin]+new_dist[nod];
                tata[vecin]=nod;
                h.push({dist_min[vecin],vecin});
            }
        }
    }

    if(dist_min[d]==INT_MAX/2)return false;

    flux_min=1;
    nod=d;
    while(tata[nod]!=-1)
    {
        flux[tata[nod]][nod]+=flux_min;
        flux[nod][tata[nod]]-=flux_min;
        nod=tata[nod];
    }

    for(i=0;i<=N;i++)dist[i]=new_dist[i];

    flux_maxim+=flux_min;
    cost_min+=new_dist[d]*flux_min;

    return true;
}

int n,m,i,e,x,y,c;
int main()
{
    f>>n>>m>>e;
    for(i=1;i<=e;i++)
    {
        f>>x>>y>>c;

        y+=n;
        v[x].push_back({y,i});
        v[y].push_back({x,i});
        C[x][y]=1;
        cost[x][y]=c;cost[y][x]=-c;
    }

    s=0;d=n+m+1;
    for(i=1;i<=n;i++)
    {
        v[s].push_back({i,0});
        v[i].push_back({s,0});
        cost[s][i]=cost[i][s]=0;
        C[s][i]=1;
    }

    for(i=n+1;i<=n+m;i++)
    {
        v[d].push_back({i,n+m+1});
        v[i].push_back({d,n+m+1});
        cost[i][d]=cost[d][i]=0;
        C[i][d]=1;
    }

    N=n+m+1;
    while(Dijkstra());

    g<<flux_maxim<<" "<<cost_min<<'\n';

    for(i=1;i<=N-1;i++)
    {
        for(int j=0;j<v[i].size();j++)
        {
            if(flux[i][v[i][j].first]==1 && v[i][j].first!=0 && v[i][j].first!=N)g<<v[i][j].second<<" ";
        }
    }
    return 0;
}
