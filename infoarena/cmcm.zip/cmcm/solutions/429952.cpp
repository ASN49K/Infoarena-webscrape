#include<fstream>
#include<vector>
#include<queue>
#define pk push_back
#define nmax 699
#define oo (1<<30)
using namespace std;
vector<int> v[nmax];
int u[nmax],d[nmax],c[nmax][nmax],f[nmax][nmax],fa[nmax],aiurea[nmax][nmax],sol[nmax];
int S,D,rez;
int bf()
{
	int i,nod;
	for(i=1;i<=D;i++)
		d[i]=oo;
	d[S]=0;
	vector <int>::iterator fiu;
	queue <int> Q;
	Q.push(S);
	while(!Q.empty())
	{
		nod=Q.front();
		Q.pop();
		u[nod]=0;
		for(fiu=v[nod].begin();fiu!=v[nod].end();fiu++)
			if(f[nod][*fiu]&&d[*fiu]>d[nod]+c[nod][*fiu])
			{
				Q.push(*fiu);
				u[nod]=1;
				d[*fiu]=d[nod]+c[nod][*fiu];
				fa[*fiu]=nod;
			}
	}
	if(d[D]!=oo)
	{
		i=D;
		while(i!=S)
		{
			f[fa[i]][i]--;
			f[i][fa[i]]++;
			i=fa[i];
		}
		rez+=d[D];
		return 1;
	}
	return 0;
}
int main()
{
	int n,m,e,cost,x,y,i,j,nr=0;
	ifstream h("cmcm.in");
	ofstream g("cmcm.out");
	h>>n>>m>>e;
	S=1;
	D=n+m+2;
	for(i=1;i<=e;i++)
	{
		h>>x>>y>>cost;
		x++;
		y+=n+1;
		v[x].pk(y);
		c[x][y]=cost;
		f[x][y]=1;
		v[y].pk(x);
		c[y][x]=-cost;
		aiurea[x][y]=i;
	}
	for(i=2;i<=n+1;i++)
	{
		v[S].pk(i);
		f[S][i]=1;
		v[i].pk(S);
	}
	for(i=n+2;i<=n+m+1;i++)
	{
		v[i].pk(D);
		f[i][D]=1;
		v[D].pk(i);
	}
	while(bf());
	for(i=2;i<=n+1;i++)
		for(j=n+2;j<=n+m+1;j++)
			if(c[i][j]&&!f[i][j])
			{
				nr++;
				sol[++sol[0]]=aiurea[i][j];
			}
	g<<nr<<' '<<rez<<'\n';
	for(i=1;i<=sol[0];i++)
		g<<sol[i]<<' ';
	return 0;
}
