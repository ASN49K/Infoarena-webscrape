#include <fstream>
#include <vector>
#include <queue>
#define NMAX 711
#define INF 1<<28
using namespace std;
vector <int> G[NMAX],sol;
queue <int> Q;
int N,M,S,D,Sol;
int edge[NMAX][NMAX],cost[NMAX][NMAX],f[NMAX][NMAX],dist[NMAX],t[NMAX],use[NMAX];
void Read(){
     int E,x,y,c,i;
     ifstream in("cmcm.in");
     in>>N>>M>>E;
     for(i=1;i<=E;i++){
      in>>x>>y>>c;
      y+=N;
      G[x].push_back(y); cost[x][y]=c;
      G[y].push_back(x); cost[y][x]=-c;
      edge[x][y]=i;
      f[x][y]=1;
     }
     in.close();
}
void Build_Graph(){
     int i;
     S=0, D=N+M+1;
     for(i=1;i<=N;i++) {
      G[S].push_back(i);
      f[S][i]=1;
     }
     for(i=N+1;i<=N+M;i++){
      G[i].push_back(D);
      f[i][D]=1;
     }
}
bool BellmanFord(){
     int i,nod;
     for(i=S;i<=D;i++){
      dist[i]=INF;
      use[i]=0;
      t[i]=0;
     }
     dist[S]=0; Q.push(S);
     while(!Q.empty()){
      nod=Q.front(); Q.pop();
      use[nod]=0;
      for(vector<int>::iterator it=G[nod].begin();it!=G[nod].end();it++)
       if(f[nod][*it]>0 && dist[*it]> dist[nod]+ cost[nod][*it]){
        dist[*it]=dist[nod]+cost[nod][*it];
        t[*it]=nod;
        if(!use[*it]){
         Q.push(*it);
         use[*it]=1;
        }
       }
     }
     if(dist[D]==INF) return 0;
     return 1;
}
void Solve(){
     int i,flux;
     Build_Graph();
     while(BellmanFord()){
      flux=INF;
      for(i=D;i!=S;i=t[i])
       flux=min(flux,(int)f[t[i]][i]);
      for(i=D;i!=S;i=t[i]){
       f[t[i]][i]-=flux;
       f[i][t[i]]+=flux;
      }
      Sol+=flux*dist[D];
     }
}
void Write(){
     int i,j,Nr=0;
     ofstream out("cmcm.out");
     for(i=1;i<=N;i++)
      for(j=N+1;j<D;j++)
       if(!f[i][j] && edge[i][j]){
        sol.push_back(edge[i][j]);
        Nr++;
        break;
       }
     out<<Nr<<' '<<Sol<<'\n';
     for(vector<int>::iterator it=sol.begin();it!=sol.end();it++)
      out<<*it<<' ';
     out<<'\n';
     out.close();
}
int main(){
    Read();
    Solve();
    Write();
    return 0;
}
