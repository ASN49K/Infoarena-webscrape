#include<fstream>
#include<vector>
#define u (1<<30)
#define pb push_back
#define MAX_N 699
using namespace std;
int n,m,e,D,rez,q[MAX_N*MAX_N],padre[MAX_N],d[MAX_N],luat[MAX_N],c[MAX_N][MAX_N],nr[MAX_N][MAX_N],s[399];
vector <int> v[MAX_N], cost[MAX_N];
int bf()
{
	int i,st=1,dr=1;
	for(i=1;i<=D;i++)
	{
		d[i]=u;
		luat[i]=padre[i]=0;
	}
	d[1]=0;
	q[1]=luat[1]=1;
	while(st<=dr)
	{
		int n=v[q[st]].size();
		for(i=0;i<n;i++)
		{
			if(c[q[st]][v[q[st]][i]]&&d[v[q[st]][i]]>d[q[st]]+cost[q[st]][i])
			{
				d[v[q[st]][i]]=d[q[st]]+cost[q[st]][i];
				padre[v[q[st]][i]]=q[st];
				if(!luat[v[q[st]][i]])
				{
					luat[v[q[st]][i]]=1;
					q[++dr]=v[q[st]][i];
				}
			}
		}
		luat[q[st]]=0;
		st++;
	}
	if(d[D]!=u)
	{
		i=D;
		while(i!=1)
		{
			c[padre[i]][i]--;
			c[i][padre[i]]++;
			i=padre[i];
		}
		rez+=d[D];
		return 1;
	}
	return 0;
}	
int main()
{
	int x,y,z,i,j;
	ifstream f("cmcm.in");
	ofstream g("cmcm.out");
	f>>n>>m>>e;
	for(i=1;i<=e;i++)
	{
		f>>x>>y>>z;
		x++;
		y+=n+1;
		v[x].pb(y);
		cost[x].pb(z);
		v[y].pb(x);
		cost[y].pb(-z);
		nr[x][y]=i;
		c[x][y]=1;
	}
	D=n+m+2;
	for(i=2;i<=n+1;i++)
	{
		v[1].pb(i);
		cost[1].pb(0);
		v[i].pb(1);
		cost[i].pb(0);
		c[1][i]=1;
	}
	for(i=n+2;i<D;i++)
	{
		v[i].pb(D);
		cost[i].pb(0);
		v[D].pb(i);
		cost[D].pb(0);
		c[i][D]=1;
	}
	while(bf());
	for(i=2;i<=n+1;i++)
		for(j=n+2;j<D;j++)
			if(nr[i][j]&&!c[i][j])
				s[++s[0]]=nr[i][j];
	g<<s[0]<<' '<<rez<<'\n';
	for(i=1;i<=s[0];i++)
		g<<s[i]<<' ';
	return 0;
}

