#include <bits/stdc++.h>

using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
typedef pair<int,int> pii;
int S,D;
int n,m,e,cap[1005][1005],cost[1005][1005],Fcost,Fans,dist[1005],old_d[1005],real_d[1005],from[1005],use[1005];
vector<int> muchii[1005];
vector<pii> g;
void bellman()
{
    for(int i=1;i<=n;i++)
        old_d[i]=1e9;
    old_d[S]=0;
    queue<int> coada;
    coada.push(S);
    while(!coada.empty())
    {
        int nod=coada.front();
        coada.pop();
        for(int i:muchii[nod])
            if(cap[nod][i]>0&&old_d[i]>old_d[nod]+cost[nod][i])
            {
                old_d[i]=old_d[nod]+cost[nod][i];
                coada.push(i);
            }
    }
}
priority_queue<pii,vector<pii>,greater<pii>> pq;
bool flux()
{
    for(int i=1;i<=n;i++)
    {
        real_d[i]=1e9;
        dist[i]=1e9;
        from[i]=0;
        use[i]=0;
    }
    dist[S]=0;
    real_d[S]=0;
    pq.push({dist[S],S});
    while(!pq.empty())
    {
        int nod=pq.top().second;
        pq.pop();
        if(use[nod])
            continue;
        use[nod]=1;
        for(int i:muchii[nod])
            if(!use[i]&&cap[nod][i]>0&&dist[i]>dist[nod]+cost[nod][i]-old_d[i]+old_d[nod])
            {
                dist[i]=dist[nod]+cost[nod][i]-old_d[i]+old_d[nod];
                from[i]=nod;
                real_d[i]=real_d[nod]+cost[nod][i];
                pq.push({dist[i],i});
            }
    }
    if(real_d[D]==1e9)
        return 0;
    for(int i=1;i<=n;i++)
        old_d[i]=real_d[i];
    int minim=1e9;
    for(int x=D;x!=S;x=from[x])
        minim=min(minim,cap[from[x]][x]);
    Fans+=minim;
    Fcost+=real_d[D]*minim;
    for(int x=D;x!=S;x=from[x])
    {
        cap[from[x]][x]-=minim;
        cap[x][from[x]]+=minim;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m>>e;
    int L=n;
    n+=m;
    for(int i=1;i<=e;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        g.push_back({a,b});
        b+=L;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
        cap[a][b]=1;
        cost[a][b]=c;
        cost[b][a]=-c;
    }
    S=n+1;
    n++;
    D=n+1;
    n++;
    for(int i=1;i<=L;i++)
    {
        muchii[S].push_back(i);
        muchii[i].push_back(S);
        cap[S][i]=1;
    }
    for(int i=L+1;i<=L+m;i++)
    {
        muchii[i].push_back(D);
        muchii[D].push_back(i);
        cap[i][D]=1;
    }
    bellman();
    while(flux());
    fout<<Fans<<' '<<Fcost<<'\n';
    for(int i=0;i<g.size();i++)
        if(cap[g[i].first][g[i].second+L]==0)
            fout<<i+1<<' ';
    return 0;
}
