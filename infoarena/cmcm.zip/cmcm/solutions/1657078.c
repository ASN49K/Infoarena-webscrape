#include <stdio.h>
#include <string.h>
#define MAXN 300
#define MAXM 50000
#define MASK 1023
#define INF 2000000000
int dr[2 * MAXN + 2], nd[2 * MAXN + 2][2 * MAXN + 2], cpc[2 * MAXN + 2][2 * MAXN + 2], fol[2 * MAXN + 2][2 * MAXN + 2], cost[2 * MAXN + 2][2 * MAXN + 2], id[2 * MAXN + 2][2 * MAXN + 2];
int dist[2 * MAXN + 2], prev[2 * MAXN + 2], q[MASK];
char ap[2 * MAXN + 2];

inline int min2(int a, int b){
  return a < b ? a : b;
}

inline void add(int x, int y, int c, int ct, int idu){
  nd[x][dr[x]] = y;
  cpc[x][y] = c;
  cost[x][y] = ct;
  id[x][y] = idu;
  dr[x]++;
}

inline char bell(int s, int d){
  int dq = 1, sq = 0, n, i;
  for(i = 0; i <= d; i++){
    dist[i] = INF;
    ap[i] = 0;
  }
  q[0] = s;
  dist[s] = 0;
  ap[s] = 1;
  while(sq < dq){
    n = q[sq & MASK];
    ap[n] = 0;
    sq++;
    for(i = 0; i < dr[n]; i++){
      if(cpc[n][nd[n][i]] - fol[n][nd[n][i]] > 0 && dist[nd[n][i]] > dist[n] + cost[n][nd[n][i]]){
        dist[nd[n][i]] = dist[n] + cost[n][nd[n][i]];
        prev[nd[n][i]] = n;
        if(!ap[nd[n][i]]){
          ap[nd[n][i]] = 1;
          q[dq & MASK] = nd[n][i];
          dq++;
        }
      }
    }
  }
  return dist[d] < INF;
}

int main(){
  FILE *in = fopen("cmcm.in", "r");
  int a, b, m, i, x, y, z;
  fscanf(in, "%d%d%d", &a, &b, &m);
  for(i = 0; i < m; i++){
    fscanf(in, "%d%d%d", &x, &y, &z);
    x--;  y--;
    y += a;
    add(x, y, 1, z, i);
    add(y, x, 0, -z, i);
  }
  fclose(in);
  int s = a + b, d = a + b + 1;
  for(i = 0; i < a; i++){
    add(s, i, 1, 0, -1);
    add(i, s, 0, 0, -1);
  }
  for(i = 0; i < b; i++){
    add(a + i, d, 1, 0, -1);
    add(d, a + i, 0, 0, -1);
  }
  int rez = 0, atot = 0;
  while(bell(s, d)){
    atot++;
    x = d;
    while(x != s){
      fol[prev[x]][x]++;
      fol[x][prev[x]]--;
      rez += cost[prev[x]][x];
      x = prev[x];
    }
  }
  FILE *out = fopen("cmcm.out", "w");
  fprintf(out, "%d %d\n", atot, rez);
  int j;
  for(i = 0; i < a + b; i++){
    for(j = 0; j < a + b; j++){
      if(fol[i][j] > 0 && id[i][j] != -1){
        fprintf(out, "%d ", id[i][j] + 1);
      }
    }
  }
  fclose(out);
  return 0;
}
