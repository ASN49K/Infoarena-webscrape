#include<cstdio>
#include<vector>
#include<queue>
#include<cstring>
#define SURSA 700
#define DEST 701

const int maxn = 710;

const int INF = 2000005;
using namespace std;

vector <pair <int , int > > edges(60000);
vector <int> G[maxn];
queue <int> Q;
int i , j , n , m , e , d[maxn] ,  F[maxn][maxn] , C[maxn][maxn] , cost[maxn][maxn];
bool in_queue[maxn];
int a , b , c , dad[maxn] , ans , cost_ans;

bool BF()
{
	int i;
	memset( in_queue , 0 , sizeof(in_queue));
	for( i = 1 ; i <= n + m ; ++i )
		d[i] = INF;
	d[DEST] = INF;
	
	Q.push(SURSA);
	in_queue[SURSA] = true;
	
	for( ; ! Q.empty() ; ) { 
		int node = Q.front();
		Q.pop() , in_queue[node] = false;
		for( i = 0 ; i < G[node].size() ; ++i ) {
			int act = G[node][i];
			if ( F[node][act] < C[node][act] ) {
				if ( d[node] + cost[node][act] < d[act] ) {
					dad[act] = node;
					d[act] = d[node] + cost[node][act];
					if ( !in_queue[act] ) { 
						Q.push(act);
						in_queue[act] = true;
					}
				}
			}
		}
	}
	return d[DEST] < INF;
}
					
	

void flow()
{
	int i , j;
	
	for( ; BF() ; ) {
		
		int minflow = INF;
		int node;
		
		for( node = DEST ; node != SURSA ; node = dad[node] ) 
			minflow = min( minflow , C[ dad[node] ][ node ]  - F[ dad[node] ][ node ]);
		
		for( node = DEST ; node != SURSA ; node = dad[node] ) 
			F[ dad[node] ][ node ] += minflow,
			F[ node ][ dad[node] ] -= minflow;
			
		ans += minflow;
		cost_ans += minflow * d[DEST];
	}
}

int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	
	scanf("%d %d %d",&n,&m,&e);
	
	for( i = 1 ; i <= e ; ++i ) { 
		scanf("%d %d %d",&a,&b,&c);
		G[a].push_back(b + n);
		G[b + n].push_back(a);
		C[a][b + n] = 1;
		cost[a][b + n] = c , cost[b + n][a] = -c;
		edges[i].first = a , edges[i].second = b + n;
	}
	
	for( i = 1 ; i <= n ; ++i ) 
		G[SURSA].push_back(i), 
		C[SURSA][i] = 1;
	
	for( i = 1 ; i <= m ; ++i )
		G[i + n].push_back(DEST),
		C[i + n][DEST] = 1;
		
	flow();
		
	printf("%d %d\n",ans,cost_ans);
	
	for( i = 1 ; i <= e ; ++i )  {
		int a = edges[i].first , b = edges[i].second;
		if ( F[a][b] && C[a][b] )
			printf("%d ",i);
	}

	printf("\n");
	
return 0;
}