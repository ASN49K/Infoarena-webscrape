#include <cstdio>
#include <cstring>
#include <fstream>
#define Nmx 100001

using namespace std;

int H[Nmx*4],lg[Nmx*4],L[Nmx*4],nr,m,First[Nmx],RMQ[25][Nmx*4],n;
struct nod
{
    int inf;
    nod *urm;
};
nod *G[Nmx];
ifstream fin("lca.in");

inline int min(int x,int y)
{
    if(x<y) return x;
    return y;
}

void add(int x,int y)
{
    nod *aux=new nod;
    aux->inf = y;
    aux->urm = G[x];
    G[x]  = aux;
}

void read()
{
    int x;
    fin>>n>>m;
    for(int i=2;i<=n;++i)
    {
        fin>>x;
        add(x,i);
    }
}

void dfs(int nd,int niv)
{
    H[++nr]=niv;
    L[nr]=nd;
    First[nd]=nr;
    for(nod *p=G[nd];p;p=p->urm)
    {
        dfs(p->inf,niv+1);
        H[++nr]=niv;
        L[nr]=nd;
    }
}

void rmq()
{
    lg[1]=0;
    for(int i=2;i<=nr;++i)
        lg[i]=lg[i/2]+1;
    for(int i=1;i<=nr;i++)
        RMQ[0][i]=i;
    for(int i=1;(1<<i)<nr;++i)
        for(int j=1;j+(1<<i)<=nr;++j)
        {
            int t=(1<<(i-1));
            RMQ[i][j]=RMQ[i-1][j];
            if(H[RMQ[i-1][j+t]]<H[RMQ[i][j]])
                RMQ[i][j]=RMQ[i-1][j+t];
        }
}

int main()
{
    freopen("lca.out","w",stdout);
    read();
    dfs(1,0);
    rmq();
    int x,y;
    for(;m;--m)
    {
        fin>>x>>y;
        x=First[x];y=First[y];
        if(x>y) x^=y^=x^=y;
        int dif=(y-x+1);
        int t=lg[dif];
        int s=RMQ[t][x];
        if(H[RMQ[t][x+(dif-(1<<t))]]<H[s])
            s=RMQ[t][x+(dif-(1<<t))];
        printf("%d\n",L[s]);
    }
    return 0;
}
