#include<bits/stdc++.h>
std::ifstream fin("cmcm.in");
std::ofstream fout("cmcm.out");

const int INF = 1e9;
int  n, m, s, d;
std::vector<int> nei[615];
int rGrph[615][615], parent[615], cost[615][615], dist[615], edges[615][615];

int n_lft, n_rght;
int aux_dist[615], new_dist[615];
bool viz[615];

void BellmanFord(){
    //calculam dist de la s la noduri
    int i, node;
    std::queue<int> q;
    for(i = 1;i <= n; i++)
        dist[i] = INF;
    dist[s] = 0;
    q.push(s);
    viz[s] = 1;

    while(!q.empty()){
        node = q.front(); q.pop();
        viz[node] = 0;
        for(auto next_node: nei[node]){
            if(rGrph[node][node] && dist[next_node] > dist[node] + cost[node][next_node]){
                dist[next_node] = dist[node] + cost[node][next_node];
                if(!viz[next_node] && node != d){
                    q.push(next_node);
                    viz[next_node] = 1;
                }
            }
        }
    }
}

bool Dijkstra(){
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int> >, std::greater<std::pair<int, int> > > q;
    int i, node, curr_cost, val;
    for(i = 1; i <= n; i++){
        aux_dist[i] = INF;
        viz[i] = 0;
        parent[i] = 0;
    }

    aux_dist[s] = 0;
    parent[s] = -1;
    q.push({0,s});
    viz[s] = 1;

    while(!q.empty()){
        node = q.top().second;
        curr_cost = q.top().first;
        q.pop();

        if(node == d || aux_dist[node] != curr_cost)
            continue;

        viz[node] = 0;
        for(auto next_node: nei[node]){    // z + distx - disty
            val = cost[node][next_node] + dist[node] - dist[next_node];
            if(rGrph[node][next_node] && aux_dist[next_node] > curr_cost + val){
                aux_dist[next_node] = curr_cost + val;
                new_dist[next_node] = new_dist[node] + cost[node][next_node];
                parent[next_node] = node;
                q.push({aux_dist[next_node], next_node});
            }
        }
    }
    for(i = 1; i <= n; i++)
        dist[i] = new_dist[i];

    return (parent[d]); //am gasit sau nu drum
}

long long mfmc(){
    int node, path_flow;
    long long max_flow = 0;
    while(Dijkstra()){ //cat timp gasim drumuri actualizam
        path_flow = INF;
        node = d;
        while(parent[node] != -1){
            path_flow = std::min(path_flow, rGrph[parent[node]][node]);
            node = parent[node];
        }
        node = d;
        while(parent[node] != -1){
            rGrph[parent[node]][node] -= path_flow;
            rGrph[node][parent[node]] += path_flow;
            max_flow += path_flow * cost[parent[node]][node];
            node = parent[node];
        }
    }
    return max_flow;
}

void solve(){
    int i;
    std::vector<int> ans;
    BellmanFord();
    long long max_flow = mfmc();

    for(i = 1;i <= n_lft; i++){
        for(auto next: nei[i]){
            if(!rGrph[i][next] && rGrph[next][i] && next != s){
                ans.push_back(edges[i][next]);
            }
        }
    }
    fout << ans.size() << ' ' << max_flow << '\n';
    for(i = 0; i < ans.size(); i++)
        fout << ans[i] << ' ';
}

void addSourceDest(){
    int i;
    s = n_lft + n_rght + 2;
    d = n_lft + n_rght + 1;

    for(i = 1; i <= n_lft; i++){
        nei[s].push_back(i);
        nei[i].push_back(s);
        rGrph[s][i] = 1;
        cost[s][i] = 0;
        cost[i][s] = 0;
    }
    for(i = n_lft + 1; i <= n_lft + n_rght; i++){
        nei[d].push_back(i);
        nei[i].push_back(d);
        rGrph[i][d] = 1;
        cost[d][i] = 0;
        cost[i][d] = 0;
    }
}


int main(){

    int i, x, y, c;
    fin >> n_lft >> n_rght >> m;

    n = n_lft + n_rght + 2;

    for(i = 1; i <= m; i++){
        fin >> x >> y >> c;
        y += n_lft;
        nei[x].push_back(y);
        nei[y].push_back(x);
        cost[x][y] = c;
        cost[y][x] = -c;
        edges[x][y] = i;
        rGrph[x][y] = 1;
    }

    addSourceDest();
    solve();

    return 0;
}