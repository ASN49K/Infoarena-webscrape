#include<stdio.h>
#include<queue>
#include<vector>

using namespace std;
#define Nmax 640
#define inf 0x3f3f3f3f
#define fs first
#define sc second

vector < pair<int,int> > l[Nmax];

int N,M,C[Nmax][Nmax],F[Nmax][Nmax];
int S,D;
int d[Nmax],p[Nmax],v[Nmax];

struct cmp
{
    bool operator()(int a,int b)
    {
        return (d[a] > d[b]);
    }
};
priority_queue <int, vector<int> ,cmp> Heap;

void init()
{
    for(int i=1;i<=D;++i)
    {
        d[i]=inf;
        p[i]=0;
        v[i]=0;
    }
    for(;!Heap.empty();Heap.pop());
}

int dijkstra()
{
    init();
    d[S]=0;
    v[S]=1;
    Heap.push(S);

    int cur,leg;
    for(;!Heap.empty();)
    {
        cur=Heap.top();
        v[cur]=0;
        Heap.pop();
        for(int i=0; i<(int)l[cur].size() ;++i)
            {
            leg=l[cur][i].fs;
            if (d[leg] > d[cur] + l[cur][i].sc && F[cur][leg])
                {
                d[leg] = d[cur] + l[cur][i].sc;
                p[leg] = cur;
                if (!v[leg])
                    {
                    v[leg]=1;
                    Heap.push(leg);
                    }
                }
            }
    }
    if (d[D]==inf)
        return 0;
    return 1;
}

void preinit()
{
    S=N+M+1;
    D=N+M+2;

    for(int i=1;i<=N;++i)
        {
        l[S].push_back( make_pair(i,0) );
        F[S][i]=1;
        }
    for(int j=1;j<=M;++j)
        {
        l[j+N].push_back( make_pair(D,0) );
        F[j+N][D]=1;
        }
}

void solve()
{
    int Cost=0,flow=0;
    preinit();
    for(; dijkstra() ;)
        {
        for(int t=D; t!=S ; t=p[t])
            {
            F[ p[t] ][t]--;
            F[t][ p[t] ]++;
            }
        Cost += d[D];
        ++flow;
        }

    printf("%d %d\n",flow,Cost);
    for(int i=1;i<=N;++i)
        for(int j=1;j<=M;++j)
            if (!F[i][j+N] && C[i][j+N])
                printf("%d ",C[i][j+N]);
    printf("\n");
}

void cit();

int main()
{
    cit();
    solve();
    return 0;
}

void cit()
{
    int a,b,c,E;
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&N,&M,&E);
    for(int i=1;i<=E;++i)
        {
        scanf("%d%d%d",&a,&b,&c);
        C[a][b+N]=i;
        F[a][b+N]=1;
        l[a].push_back( make_pair(b+N,c) );
        l[b+N].push_back( make_pair(a,-c) );
        }
}
