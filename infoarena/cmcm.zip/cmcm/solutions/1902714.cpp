#include <fstream>
#include <bitset>
#include <vector>
#include <queue>
#include <cstring>
#define pi pair<int,int>
#define x first
#define y second
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
const int N=705,inf=0x3f3f3f3f;
int dist[N],C[N][N],cost[N][N],tata[N],s,d;
long long costflux;
queue<int>Q;
vector<int>H[N];
vector<int>::iterator it;
pi edge[50001];
bool bellmanford()
{
    memset(dist,inf,sizeof(dist));
    dist[s]=0;
    Q.push(s);
    while(Q.size())
    {
        int nod=Q.front();
        Q.pop();
        for(it=H[nod].begin();it!=H[nod].end();it++)
        {
            if(C[nod][*it] && (dist[*it]>dist[nod]+cost[nod][*it]))
            {
                dist[*it]=dist[nod]+cost[nod][*it];
                tata[*it]=nod;
                Q.push(*it);
            }
        }
    }
    if(dist[d]==inf) return 0;
    int fmin=inf;
    for(int i=d;i!=s;i=tata[i])
    {
        fmin=min(fmin,C[tata[i]][i]);
    }
    for(int i=d;i!=s;i=tata[i])
    {
        C[tata[i]][i]-=fmin;
        C[i][tata[i]]+=fmin;
    }
    costflux+=fmin*dist[d];
    return 1;
}
int main()
{
    int A,B,M;
    int i,c;
    fin>>A>>B>>M;
    d=A+B+1;
    for(i=1;i<=M;i++)
    {
        fin>>edge[i].x>>edge[i].y>>c;
        edge[i].y+=A;
        int a=edge[i].x,b=edge[i].y;
        C[a][b]=1;
        cost[a][b]=c;
        cost[b][a]=-c;
        H[a].push_back(b);
        H[b].push_back(a);

        H[s].push_back(a);
        H[a].push_back(s);
        C[s][a]=1;

        H[d].push_back(b);
        H[b].push_back(d);
        C[b][d]=1;
    }
    while(bellmanford());
    int cnt=0;
    for(i=1;i<=M;i++)
    {
        if(!C[edge[i].x][edge[i].y]) cnt++;
    }
    fout<<cnt<<" "<<costflux<<"\n";
    for(i=1;i<=M;i++)
    {
        if(!C[edge[i].x][edge[i].y]) fout<<i<<" ";
    }
}
