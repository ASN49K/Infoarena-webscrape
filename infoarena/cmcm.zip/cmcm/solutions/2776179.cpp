#include <bits/stdc++.h>
 
using namespace std;
using ll = int;
int INF = 1;
 
struct NetworkSimplex {
  struct Edge { int a, b, c, k, f = 0; };
 
  int n;
  vector<int> pei, depth, nxt;
  vector<ll> dual;
  vector<Edge> E;
  vector<set<int>> tree;
  vector<int> stk;
  
  NetworkSimplex(int n) : 
    n(n), pei(n + 1, -1), depth(n + 1, 0), nxt(n + 1, -1),
    dual(n + 1, 0), tree(n + 1) {}
  
  int AddEdge(int a, int b, int c, int k) {
    E.push_back({a, b, c, k});
    E.push_back({b, a, 0, -k});
    return E.size() - 2;
  }
  void dfs() {
    stk.push_back(n);
    while (stk.size()) {
      int node = stk.back(); stk.pop_back();
      for (auto ei : tree[node]) {
        if (ei == pei[node]) continue;
        dual[E[ei].b] = dual[E[ei].a] + E[ei].k;
        pei[E[ei].b] = (ei ^ 1);
        depth[E[ei].b] = 1 + depth[E[ei].a];
        stk.push_back(E[ei].b);  
      }
    }
  }
  long long Compute(int x) {
    for (int i = 0; i < n; ++i) {
      int a = n, b = i, c = 1, k = -INF;
      if (i >= x) swap(a, b);
      int ei = AddEdge(a, b, c, k);
      tree[a].insert(ei);
      tree[b].insert(ei^1);
    }  
    dfs();
 
    int n_pivots = 0;
 
    long long answer = 0;
    ll flow, cost; int ein, eout, ptr = 0;
    const int B = 2 * n;
    for (int z = 0; z < E.size() / B + 1; ++z) { 
      // Find negative cycle (round-robin). 
      cost = 0; ein = -1;
      for (int t = 0; t < B; ++t, (++ptr) %= E.size()) {
        auto& e = E[ptr];
        ll now = dual[e.a] + e.k - dual[e.b];
        if (e.f < e.c && now < cost)
          cost = now, ein = ptr;
      }
      if (ein == -1) continue;
      n_pivots += 1;

      for (int v = E[ein].b; v < n; v = E[pei[v]].b)
        nxt[v] = pei[v];
      for (int v = E[ein].a; v < n; v = E[pei[v]].b)
        nxt[E[pei[v]].b] = (pei[v]^1);
      nxt[E[ein].a] = -1;
 
      // Pivot around ein.
      int flow = E[ein].c - E[ein].f; eout = ein;
      for (int ei = ein; ei != -1; ei = nxt[E[ei].b]) {
        int res = E[ei].c - E[ei].f;
        if (res <= flow) flow = res, eout = ei;
      }
      for (int ei = ein; ei != -1; ei = nxt[E[ei].b]) 
        E[ei].f += flow, E[ei^1].f -= flow;
      
      if (ein != eout) {
        tree[E[ein].a].insert(ein);
        tree[E[ein].b].insert(ein^1);
        tree[E[eout].a].erase(eout);
        tree[E[eout].b].erase(eout^1);
        // dfs(n);
        dfs();
        // upd(pei[E[eout].a] == eout ? ein : ein^1);
      }
      answer += 1LL * flow * cost;
      z = -1;
    }
    return answer;
  }
};
 
int main() {
  ifstream cin("cmcm.in");
  ofstream cout("cmcm.out");
  
  int n, m, e; cin >> n >> m >> e;
  NetworkSimplex NS(n + m);
  for (int i = 0; i < e; ++i) {
    int a, b, c; cin >> a >> b >> c; --a; --b;
    assert(2 * i == NS.AddEdge(a, b + n, 1, c));
    INF += abs(c);
  }
 
  auto cost = NS.Compute(n);
  int flow = 0;
  while (cost < -INF)
    flow += 1, cost += 2 * INF;
    
  cout << flow << " " << cost << '\n';
  for (int i = 0; i < e; ++i)
    if (NS.E[2 * i].f > 0) 
      cout << i + 1 << " ";
  cout << endl;
  return 0;
}
