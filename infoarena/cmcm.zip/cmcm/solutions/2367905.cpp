#include <bits/stdc++.h>
#define int long long
using namespace std;;
ifstream fi("cmcm.in");
ofstream fo("cmcm.out");

const int NMAX = 605;
const int INF = 5e9 + 5;

int n, m, e;
int cost[NMAX][NMAX], F[NMAX][NMAX], C[NMAX][NMAX];
vector <int> G[NMAX];
int fake[2][NMAX], asd, adev[NMAX];
bool inCoada[NMAX];
int p[NMAX];
int loc[NMAX][NMAX];

void adauga(int u, int v, int c)
{
    G[u].push_back(v);
    G[v].push_back(u);
    cost[u][v] = c;
    cost[v][u] = -c;
    C[u][v] = 1;
    C[v][u] = 0;
}

void bellmanford()
{
    for (int i = 0; i <= n + m + 1; i++)
        fake[1 - asd][i] = INF;

    queue <int> Q;
    Q.push(0);
    inCoada[0] = 1;
    fake[1 - asd][0] = 0;

    while (!Q.empty())
    {
        int nod = Q.front();
        Q.pop();
        inCoada[nod] = 0;

        for (auto v: G[nod])
        {
            if (fake[1 - asd][nod] + cost[nod][v] < fake[1 - asd][v] && C[nod][v] == 1)
            {
                fake[1 - asd][v] = fake[1 - asd][nod] + cost[nod][v];
                if (!inCoada[v])
                {
                    Q.push(v);
                    inCoada[v] = 1;
                }
            }
        }
    }
}

bool dijkstra()
{
    for (int i = 0; i <= n + m + 1; i++)
        fake[asd][i] = INF;

    priority_queue < pair<int, int> > Q;
    Q.push({0, 0});
    fake[asd][0] = adev[0] = 0;

    while (!Q.empty())
    {
        pair <int, int> curr = Q.top();
        Q.pop();

        int nod = curr.second;
        if (fake[asd][nod] != -curr.first)
            continue;

        for (auto v: G[nod])
        {
            if (fake[asd][nod] + cost[nod][v] + fake[1 - asd][nod] - fake[1 - asd][v] < fake[asd][v] && F[nod][v] != C[nod][v])
            {
                fake[asd][v] = fake[asd][nod] + cost[nod][v] + fake[1 - asd][nod] - fake[1 - asd][v];
                adev[v] = adev[nod] + cost[nod][v];
                p[v] = nod;
                Q.push({-fake[asd][v], v});
            }
        }
    }
    return fake[asd][n + m + 1] != INF;
}

signed main()
{
    fi >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int u, v, c;
        fi >> u >> v >> c;
        v += n;
        loc[u][v] = i;
        adauga(u, v, c);

        adauga(0, u, 0);
        adauga(v, n + m + 1, 0);
    }

    asd = 0;
    bellmanford();

    int rez = 0;
    while (dijkstra())
    {
        int minim = INF;
        for (int i = n + m + 1; i != 0; i = p[i])
        {
            minim = min(minim, C[p[i]][i] - F[p[i]][i]);
        }

        for (int i = n + m + 1; i != 0; i = p[i])
        {
            F[p[i]][i] += minim;
            F[i][p[i]] -= minim;
        }

        rez += (adev[n + m + 1]) * minim;

        asd = 1 - asd;
    }

    int nrm = 0;
    vector <int> rrr;
    for (int i = 1; i <= n; i++)
    {
        for (auto v: G[i])
            if (F[i][v] == C[i][v] && C[i][v] == 1)
                nrm++, rrr.push_back(loc[i][v]);
    }

    fo << nrm << " " << rez << "\n";
    for (auto x: rrr)
        fo << x << " ";

    return 0;
}
