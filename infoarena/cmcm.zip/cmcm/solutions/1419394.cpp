#include<bits/stdc++.h>
using namespace std;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

const int oo=1<<30;
const int NMAX=605;
const int XMAX=300005;

int n,m,e,edge[NMAX][NMAX],fl[NMAX][NMAX],ad[NMAX][NMAX],c[NMAX][NMAX];
int source,sink,f[NMAX],Q[XMAX],dp[NMAX];
vector<int>v[NMAX];
vector<int>::iterator it;
bitset<NMAX>viz;

inline bool Bellman()
{
    int i,len;
    for (i=source;i<=sink;i++) {viz[i]=f[i]=0;dp[i]=oo;}
    len=1;Q[1]=source;
    viz[source]=1;dp[source]=0;
    for (i=1;i<=len;i++)
        {
            for (it=v[Q[i]].begin();it!=v[Q[i]].end();it++)
                if (dp[*it]>(dp[Q[i]]+c[Q[i]][*it]) && fl[Q[i]][*it]>ad[Q[i]][*it])
                {

                    dp[*it]=dp[Q[i]]+c[Q[i]][*it];
                    f[*it]=Q[i];
                    if (!viz[*it])
                        {
                            viz[*it]=1;
                            Q[++len]=*it;
                        }
                }
            viz[Q[i]]=0;
        }
    if (f[sink]==0) return 0;
    return 1;
}

int main()
{
    int i,j,x,y,z,sol,mn,cost=0;
    fin>>n>>m>>e;
    for (i=1;i<=e;i++)
        {
            fin>>x>>y>>z;
            y+=n;//sa nu se incurce nodurile
            edge[x][y]=i;

            fl[x][y]=1;
            c[x][y]=z;
            c[y][x]=-z;

            v[x].push_back(y);
            v[y].push_back(x);
        }
    source=0;sink=n+m+1;
    for (i=1;i<=n;i++)
        {
            v[source].push_back(i);
            fl[source][i]=1;//cu costul 0
        }
    for (i=n+1;i<=(n+m);i++)
        {
            v[i].push_back(sink);
            fl[i][sink]=1;//cu costul 0
        }
    for (sol=0;Bellman();)
        {
            mn=oo;
            for (i=sink;i!=source;i=f[i])
                mn=min(mn,fl[f[i]][i]-ad[f[i]][i]);
            for (i=sink;i!=source;i=f[i])
                {
                    ad[f[i]][i]+=mn;
                    ad[i][f[i]]-=mn;
                }
            sol+=mn;
            cost+=mn*dp[sink];
        }
    fout<<sol<<" "<<cost<<"\n";
    for (i=1;i<=n;i++)
        for (j=n+1;j<=m;j++)
            if (ad[i][j]>0)//i este cuplat cu j
                fout<<edge[i][j]<<" ";
    fout<<"\n";
    return 0;
}
