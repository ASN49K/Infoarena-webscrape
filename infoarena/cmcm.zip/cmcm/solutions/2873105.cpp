#include <fstream>
#include <queue>
#include <vector>
#define INF 2000000001
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
queue <int> q;
vector <int> v[711];
bool inq[711];
int ante[711],dist[711],cap[711][711],muc[711][711],cost[711][711],fol[711][711],d;
int bellman_ford()
{
    for(int i=0;i<=d;i++)
    {
        ante[i]=-1;
        dist[i]=INF;
        inq[i]=0;
    }
    q.push(0);
    inq[0]=1;
    dist[0]=0;
    while(q.empty()==false)
    {
        int k=q.front();
        q.pop();
        inq[k]=0;
        for(auto it=v[k].begin();it!=v[k].end();it++)
        {
            if(cap[k][*it]<=fol[k][*it] || dist[*it]<=dist[k]+cost[k][*it])
                continue;
            dist[*it]=dist[k]+cost[k][*it];
            ante[*it]=k;
            if(inq[*it]==0)
            {
                q.push(*it);
                inq[*it]=1;
            }
        }
    }
    if(dist[d]==INF)
        return 0;
    int M=INF;
    for(int i=d;i!=0;i=ante[i])
        M=min(M,cap[ante[i]][i]-fol[ante[i]][i]);
    for(int i=d;i!=0;i=ante[i])
    {
        fol[ante[i]][i]=fol[ante[i]][i]+M;
        fol[i][ante[i]]=fol[i][ante[i]]-M;
    }
    return M*dist[d];
}
int n,m,i,x,y,z,schimb=1,sol,nr,p;
int main()
{
    f>>n>>m>>p;
    d=n+m+1;
    for(i=1;i<=p;i++)
    {
        f>>x>>y>>z;
        y=y+n;
        v[x].push_back(y);
        v[y].push_back(x);
        cost[x][y]=z;
        cost[y][x]=-z;
        cap[x][y]=1;
        muc[x][y]=i;
    }
    for(i=1;i<=n;i++)
    {
        v[0].push_back(i);
        v[i].push_back(0);
        cap[0][i]=1;
    }
    for(i=n+1;i<d;i++)
    {
        v[d].push_back(i);
        v[i].push_back(d);
        cap[i][d]=1;
    }
    while(schimb)
    {
        schimb=bellman_ford();
        sol=sol+schimb;
    }
    for(i=1;i<=n;i++)
        for(auto it=v[i].begin();it!=v[i].end();it++)
            if(*it!=0 && cap[i][*it] && fol[i][*it])
                nr++;
    g<<nr<<" "<<sol<<'\n';
    for(i=1;i<=n;i++)
        for(auto it=v[i].begin();it!=v[i].end();it++)
            if(*it!=0 && cap[i][*it]!=0 && fol[i][*it])
                g<<muc[i][*it]<<" ";
    return 0;
}
