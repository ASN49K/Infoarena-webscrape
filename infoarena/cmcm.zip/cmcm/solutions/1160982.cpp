#include <fstream>
#include <vector>
#include <queue>
#include <utility>
#include <cstring>

#define maxn 610
#define inf 1000000000
#define vint vector<int>::iterator

using namespace std;

ifstream fin ("cmcm.in");
ofstream fout ("cmcm.out");

int C[maxn][maxn],F[maxn][maxn],Cost[maxn][maxn],wh[maxn][maxn];
vector<int> G[maxn];
int n,n1,n2,m,a,b,z,flow,flowcost;

//bellman
queue<int> Q;
int d[maxn],viz[maxn];

//dijkstra
priority_queue <pair<int,int>, vector<pair<int,int> >, greater<pair<int,int> > > H;
int old_d[maxn],real_d[maxn],D[maxn],VIZ[maxn],from[maxn];

bool dijkstra (int x)
{
    for (int i=0; i<=n; ++i)
    {
        D[i] = inf;
    }

    memset(VIZ,0,sizeof(VIZ));
    D[x] = 0;
    H.push (make_pair(0,x));

    while (!H.empty())
    {
        int x = H.top().second;
        H.pop ();

        if (VIZ[x])
            continue;
        VIZ[x] = 1;

        for (vint it = G[x].begin (); it != G[x].end(); ++it)
        {
            if (F[x][*it] != C[x][*it])
            {
                int newcost = old_d[x] + Cost[x][*it] - old_d[*it];

                if (D[*it] > D[x] + newcost)
                {
                    D[*it] = D[x] + newcost;
                    real_d[*it] = real_d[x] + Cost[x][*it];
                    from[*it] = x;
                    H.push (make_pair(D[*it],*it));
                }
            }
        }
    }

    return D[n] != inf;
}

void bellman_ford (int x)
{
    for (int i=0; i<=n; ++i)
        d[i] = inf;

    Q.push (0);
    viz[x] = 1;
    d[x] = 0;

    while (!Q.empty())
    {
        int x = Q.front ();

        for (vint it = G[x].begin (); it != G[x].end(); ++it)
        {
            if (C[x][*it] != F[x][*it])
            if (d[x] + Cost[x][*it] < d[*it])
            {
                d[*it] = d[x] + Cost[x][*it];

                if (!viz[*it])
                {
                    viz[*it] = 1;
                    Q.push (*it);
                }
            }
        }

        viz[x] = 0;
        Q.pop ();
    }
}

int main()
{
    fin>>n1>>n2>>m;

    n = n1 + n2 + 1;

    for (int i=1; i<=m; ++i)
    {
        fin>>a>>b>>z;

        b += n1;

        Cost[a][b] = z;
        Cost[b][a] = -z;
        C[a][b] = 1;
        wh[a][b] = i;

        G[a].push_back (b);
        G[b].push_back (a);
    }

    for (int i=1; i<=n1; ++i)
    {
        G[0].push_back (i);
        C[0][i] = 1;
    }

    for (int i=n1; i<=n1+n2; ++i)
    {
        G[i].push_back (n);
        C[i][n] = 1;
    }

    bellman_ford (0);

    memcpy (old_d,d,sizeof(d));

    while (dijkstra (0))
    {
        int minf = inf;

        for (int i = n; i != 0; i = from[i])
        {
            minf = min(minf,C[from[i]][i]-F[from[i]][i]);
        }

        flow += minf;
        flowcost += real_d[n];

        for (int i = n; i != 0; i = from[i])
        {
            F[from[i]][i] += minf;
            F[i][from[i]] -= minf;
        }

        memcpy (old_d,real_d,sizeof(real_d));
    }

    fout<<flow<<" "<<flowcost<<"\n";

    for (int i=1; i<=n; ++i)
    {
        for (vint it = G[i].begin(); it != G[i].end(); ++it)
        {
            if (F[i][*it] > 0 && *it != n)
                fout<<wh[i][*it]<<" ";
        }
    }
}
