#include<cstdio>
#include<algorithm>
#include<cstring>
#define fi first
#define se second
#include<queue>
#define INF 0x3f3f3f3f
#include<vector>
#define S 610
#define D 611
#define dif 300
#define N 650
#define FOR(a,b,c) for(int a=b;a<=c;a++)
using namespace std;
queue<int> Q;
vector<pair<int,int> > v[N];
pair<int,int> des;
int Cp[N][N],T[N],F[N][N];
bool inQ[N];
int qsize,i,n,m,cuplaj,edge,X[N],Y[N],minim,cost,nod,c,z,x,y,C[N];
inline void read()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d%d%d",&n,&m,&edge);
	FOR(i,1,edge)
	{
		scanf("%d%d%d",&x,&y,&z);
		y+=dif;
		X[i]=x;
		Y[i]=y;
		Cp[x][y]=1;
		v[x].push_back(make_pair(y,z));
		v[y].push_back(make_pair(x,-z));
	}
	FOR(i,1,n)
	{
		v[S].push_back(make_pair(i,0));
		Cp[S][i]=1;
	}
	FOR(i,1,m)
	{
		v[i+dif].push_back(make_pair(D,0));
		Cp[i+dif][D]=1;
	}
}
inline void init()
{
	memset(inQ,0,sizeof(inQ));
	memset(C,INF,sizeof(C));
	qsize=1; Q.push(S); inQ[S]=1;
	C[S]=0; minim=INF;
}
inline bool fmcm()
{
	init(); vector<pair<int,int> >::iterator des;
	while(qsize)
	{
		nod=Q.front();
		Q.pop();
		qsize--;
		inQ[nod]=0;
		for(des=v[nod].begin();des!=v[nod].end();des++)
		{
			if(Cp[nod][des->fi]>F[nod][des->fi]&&C[des->fi]>C[nod]+des->se)
			{
				C[des->fi]=C[nod]+des->se;
				T[des->fi]=nod;
				if(!inQ[des->fi])
				{
					inQ[des->fi]=1;
					Q.push(des->fi);
					++qsize;
				}
			}
		}
	}
		if(C[D]!=INF)
		{
			for(nod=D;T[nod];nod=T[nod])
			minim=min(minim,Cp[T[nod]][nod]-F[T[nod]][nod]);
			for(nod=D;T[nod];nod=T[nod])
			{
				F[T[nod]][nod]+=minim;
				F[nod][T[nod]]-=minim;
			}
		}
	return (C[D]!=INF);
}
inline void solve()
{
	while(fmcm())
	{
		cost+=minim*C[D];
		cuplaj+=minim;
	}
	printf("%d %d\n",cuplaj,cost);
	FOR(i,1,edge)
	{
		if(F[X[i]][Y[i]])
		printf("%d ",i);
	}
}
int main ()
{
	read();
	solve();
	return 0;
}
