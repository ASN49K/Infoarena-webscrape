#include <fstream>
#include <iostream>
#include <vector>
#include <bitset>
#include <string.h>
#include <algorithm>
#include <iomanip>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <set>
#include <map>
#include <string>
#include <unordered_map>
#include <queue>

using namespace std;

const char infile[] = "cmcm.in";
const char outfile[] = "cmcm.out";

ofstream fout(outfile);

const int MAXN = 100005;
const int oo = 0x3f3f3f3f;

typedef vector<int> Graph[MAXN];
typedef vector<int> :: iterator It;

const inline int min(const int &a, const int &b) { if( a > b ) return b;   return a; }
const inline int max(const int &a, const int &b) { if( a < b ) return b;   return a; }
const inline void Get_min(int &a, const int b)    { if( a > b ) a = b; }
const inline void Get_max(int &a, const int b)    { if( a < b ) a = b; }

class DirectedGraph {
public:
    DirectedGraph(int N, int LEFT, int RIGHT) {
        adj.resize(N);
        this->LEFT = LEFT;
        this->RIGHT = RIGHT;
        father.resize(N);
        inq.resize(N);
        dist.resize(N);
    }
    DirectedGraph() {
    }
    void addDirectedEdge(int x, int y, int cap, int cost) {
        adj[x].push_back(make_pair(y, cost));
        capacity[x][y] = cap;
    }
    pair<int, int> getMinCostMaxMatching(int source, int sink) {
        vector <pair<int, int> > matching;
        int matchingSize = 0, matchingCost = 0;
        while(bellmanford(source, sink)) {
            matchingCost += dist[sink];
            ++ matchingSize;
            for(int i = sink ; i != source ; i = father[i]) {
                -- capacity[father[i]][i];
                ++ capacity[i][father[i]];
            }
        }
        return make_pair(matchingSize, matchingCost);
    }
    bool bellmanford(int source, int sink) {
        fill(dist.begin(), dist.end(), oo);
        q.push(source);
        dist[source] = 0;
        inq[source] = 1;
        while(!q.empty()) {
            int node = q.front();
            q.pop();
            for(vector <pair<int, int> > :: iterator it = adj[node].begin(), fin = adj[node].end(); it != fin ; ++ it) {
                if(capacity[node][it->first] > 0 && dist[it->first] > dist[node] + it->second) {
                    dist[it->first] = dist[node] + it->second;
                    father[it->first] = node;
                    if(inq[it->first])
                        continue;
                    q.push(it->first);
                    inq[it->first] = 1;
                }
            }
            inq[node] = false;
        }
        return dist[sink] != oo;
    }
    inline bool checkFlow(int x, int y) {
        return !capacity[x][y];
    }

private:
    vector <vector <pair<int, int> > > adj;
    vector <int> father, dist;
    vector <bool> inq;
    queue <int> q;
    int LEFT, RIGHT;
    unordered_map<int, unordered_map<int, int> > capacity;
};

vector < pair<int, int> > Edges;


class Scanner {
  public:
    Scanner(string file, int buffer_size = 32768):
            buffer_size_(buffer_size) {
        file_ = fopen(file.c_str(), "r");
        buffer_ = new char[buffer_size];
        pointer_ = buffer_ + buffer_size_;
    }

    Scanner& operator>>(int &object) {
        object = 0;
        char sign = '+';
        while (next() < '0' or next() > '9') {
            sign = next();
            advance();
        }
        while (next() >= '0' and next() <= '9') {
            object = object * 10 + next() - '0';
            advance();
        }
        if(sign == '-')
            object = -object;
        return *this;
    }

  private:
    char next() {
        if (pointer_ == buffer_ + buffer_size_) {
            pointer_ = buffer_;
            fread(buffer_, 1, buffer_size_, file_);
        }
        return *pointer_;
    }

    void advance() {
        ++pointer_;
    }

    FILE *file_;
    int buffer_size_;
    char *buffer_, *pointer_;
};
Scanner fin(infile);

int main() {
    int N, M, E;
    fin >> N >> M >> E;
    int Source = 0, Sink = N + M + 1;
    DirectedGraph G(Sink + 1, N, M);
    while(E --) {
        int x, y, z;
        fin >> x >> y >> z;
        G.addDirectedEdge(x, y + N, 1, z);
        G.addDirectedEdge(y + N, x, 0,-z);
        Edges.push_back(make_pair(x, y + N));
    }
    for(int i = 1 ; i <= N ; ++ i) {
        G.addDirectedEdge(Source, i, 1, 0);
        G.addDirectedEdge(i, Source, 0, 0);
    }
    for(int i = N + 1 ; i <= N + M ; ++ i) {
        G.addDirectedEdge(i, Sink, 1, 0);
        G.addDirectedEdge(Sink, i, 0, 0);
    }
    pair<int, int> ans = G.getMinCostMaxMatching(Source, Sink);

    fout << ans.first << ' ' << ans.second << '\n';

    for(auto it = Edges.begin(), fin = Edges.end(); it != fin ; ++ it) {
        if(G.checkFlow(it->first, it->second))
            fout << it - Edges.begin() + 1 << ' ';
    }
    fout.close();
    return 0;
}
