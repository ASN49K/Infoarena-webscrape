#include <bits/stdc++.h>
using namespace std;

/*
Author: bicsi
*/
using T = int;
const T INF = numeric_limits<T>::max() / 4;
struct MFMC {
  struct Edge { int from, to, nxt; T flow, cap, cost; };

  int n;
  vector<int> graph, par;
  vector<T> dist, pi;
  vector<Edge> es;
  
  MFMC(int n) : n(n), graph(n, -1), par(n), dist(n), pi(n) {}
  
  void AddEdge(int a, int b, T cap, T cost) {
    auto add = [&](int a, int b, T cap, T cost) {
      es.push_back({a, b, graph[a], 0, cap, cost});
      graph[a] = es.size() - 1;
    };
    add(a, b, cap, cost); add(b, a, 0, -cost);
  }
  bool relax(int ei) {
    const auto &e = es[ei];
    if (dist[e.from] == INF) return false;
    T now = dist[e.from] + pi[e.from] - pi[e.to] + e.cost;
    if (e.flow < e.cap && now < dist[e.to])
      return dist[e.to] = now, par[e.to] = ei, true;
    return false;
  }
  bool dijkstra(int s, int t) {
    dist.assign(n, INF); par.assign(n, -1);
    priority_queue<pair<T, int>> pq;
    dist[s] = 0; pq.emplace(0, s);
    while (!pq.empty()) {
      auto [d, node] = pq.top(); pq.pop();
      if (dist[node] != -d) continue;
      for (int ei = graph[node]; ei != -1; ei = es[ei].nxt)
        if (relax(ei))
          pq.emplace(-dist[es[ei].to], es[ei].to);
    }
    for (int i = 0; i < n; ++i)
      pi[i] = min(pi[i] + dist[i], INF);
    return par[t] != -1;
  }
  pair<T, T> Compute(int s, int t, int want = INF) {
    T flow = 0, cost = 0;
    while (dijkstra(s, t) && flow < want) {
      T now = INF;
      for (int ei = par[t]; ei != -1; ei = par[es[ei].from])
        now = min(now, es[ei].cap - es[ei].flow);
      now = min(now, want - flow);
      for (int ei = par[t]; ei != -1; ei = par[es[ei].from]) {
        es[ ei ].flow += now;
        es[ei^1].flow -= now;
        cost += es[ei].cost * now;
      }
      flow += now;
    }
    return {flow, cost};
  }
  // I f some costs can be negative , c a l l th is before maxflow :
  void SetPi(int s) { // (otherwise , leave th is out)
    dist.assign(n, INF); dist[s] = 0;
    int it = n, ch = 1;
    while (ch-- && it--)
      for (int ei = 0; ei < (int)es.size(); ++ei)
        ch |= relax(ei);
    assert(it >= 0); // negative cost cyc le
    pi = dist;
  }
};

int main() {
  assert(freopen("cmcm.in", "r", stdin));
  assert(freopen("cmcm.out", "w", stdout));

  int N, M, E;
  cin >> N >> M >> E;

  MFMC mfmc(N + M + 2);
  map<pair<int, int>, int> mp;
  for (int i = 0; i < E; i++) {
    int u, v, c;
    cin >> u >> v >> c;
    u--, v--;
    mfmc.AddEdge(u, v + N, 1, c);
    mp[{u, v}] = i + 1;
  }

  int source = N + M, sink = N + M + 1;
  for (int i = 0; i < N; i++) {
    mfmc.AddEdge(source, i, 1, 0);
  } 
  for (int i = 0; i < M; i++) {
    mfmc.AddEdge(i + N, sink, 1, 0);
  }

  auto [flow, cost] = mfmc.Compute(source, sink);
  auto edges = mfmc.es;
  vector<int> answer;
  for (const auto &e : edges) {
    if (e.flow == 1 && e.from != source && e.to != sink) {
      answer.push_back(mp[{e.from, e.to - N}]);
    }
  }

  cout << flow << " " << cost << "\n";
  for (const int &x  : answer) {
    cout << x << " ";
  }
  return 0;
}