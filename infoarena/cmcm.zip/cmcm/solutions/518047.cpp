using namespace std;
#include<iostream>
#include<fstream>
#include<vector>
#include<cstring>
#define oo 0x3f3f3f3f
#define pb push_back
struct nod{
int lg,c;
};

vector<nod> G[700];

ofstream fout("cmcm.out");

int C[700][700],F[700][700],ret[300][300],ante[700],isinq[700],viz[700],q[700],d[700],cost_minim,S,D,E,sink;

bool BFS()
{  int i;
    memset(ante,0, sizeof(ante));
    memset(viz,0,sizeof(viz));
    memset(q,0,sizeof(q));
    memset(isinq,0,sizeof(isinq));
    for(i=0;i<=sink;i++)
       d[i]=oo;
    d[0]=0;
    viz[0]=1;
    q[++q[0]]=0;
    isinq[0]=1;
    vector<nod>::iterator it;
    int front=1,u;

    while(front<=q[0])
    {
        u=q[front++];
        isinq[u]=0;
        for(it=G[u].begin();it<G[u].end();it++)
        {
            if(C[u][it->lg]>F[u][it->lg])
            {
                if(d[it->lg]>d[u]+it->c)
                {
                    ante[it->lg]=u;
                    d[it->lg]=d[u]+it->c;
                    viz[it->lg]=1;
                    if(!isinq[it->lg])
                    {
                        isinq[it->lg]=1;
                        q[++q[0]]=it->lg;
                    }
                }
            }
        }
    }
    cost_minim=d[sink];

    return viz[sink];

}

void solve()
{
    int fmin,i,flow=0,cmin=0;
    for(flow=0;BFS();)
    {

        fmin=C[ante[sink]][sink]-F[ante[sink]][sink];
        for(i=ante[sink];i!=0;i=ante[i])
        {
            fmin=min(fmin,C[ante[i]][i]-F[ante[i]][i]);
        }

        F[ante[sink]][sink]+=fmin;
        F[sink][ante[sink]]-=fmin;

        for(i=ante[sink];i!=0;i=ante[i])
        {

            F[ante[i]][i]+=fmin;
            F[i][ante[i]]-=fmin;
        }

        flow+=fmin;
        cmin+=cost_minim*fmin;
    }

    fout<<flow<<" "<<cmin<<"\n";
    for(i=1;i<=S;i++)
    {
        for(it=G[i].begin();it<G[i].end();it++)
        {
            if(F[i][it->lg]==1)
            {
                fout<<ret[i][it->lg-S]<<" ";

            }
        }
    }
}

void cit()
{int i,z,y,x,Y;
    ifstream fin("cmcm.in");

    fin>>S>>D>>E;
    sink=S+D+1;
    for(i=1;i<=E;i++)
    {
        fin>>x>>y>>z;
        Y=y+S;
        G[x].pb((nod){Y,z});
        G[Y].pb((nod){x,-z});
        C[x][Y]=1;
        ret[x][y]=i;
    }

    for(i=1;i<=S;i++)
    {
        G[0].pb((nod){i,0});
        G[i].pb((nod){0,0});
        C[0][i]=1;
    }
    for(i=1;i<=D;i++)
    {
        G[i+S].pb((nod){sink,0});
        G[sink].pb((nod){i+S,0});
        C[i+S][sink]=1;
    }

    fin.close();
}

int main()
{

    cit();

    solve();

    fout.close();
    return 0;

}
