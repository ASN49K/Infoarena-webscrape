#include <cstdio>
#include <set>
#include <algorithm>
#include <vector>
using namespace std;
#define Max 666
#define Inf 0xffffff
vector<int>g[Max];
set<int>s0,s1;
int n,m,c[Max][Max],f[Max][Max],p[Max][Max],w[Max][Max],s,d,t[Max],dst[Max];

bool bfs()
{
    int x,y;
    for(int i=1;i<=d;i++)dst[i]=Inf;
    dst[s]=0;
    s0.insert(s);
    for(int k=1;k<=d;k++)
    {
        while(s0.size()>0)
        {
            x=*s0.begin();
            s0.erase(s0.begin());
            for(int i=0;i<g[x].size();i++)
            {
                y=g[x][i];
                if(dst[y]>dst[x]+p[x][y] && c[x][y] > f[x][y])
                {
                    dst[y]=dst[x]+p[x][y];
                    t[y]=x;
                    s1.insert(y);
                }
            }
        }
        swap(s0,s1);
    }
    return dst[d]!=Inf;
}

void maxflow()
{
    int flux_m=0,fmcm=0,flux;
    while(bfs())
    {
        flux=Inf;
        for(int x=d;x!=s;x=t[x])flux=min(flux,c[t[x]][x]-f[t[x]][x]);
        if(flux!=0)
        {
            for(int x=d;x!=s;x=t[x])
            {
                f[t[x]][x]+=flux;
                f[x][t[x]]-=flux;
                fmcm+=flux*p[t[x]][x];
            }
        }
    }
    for(int i=1;i<=d;i++)
    for(int j=1;j<=d;j++)if(f[i][j]==1)flux_m++;
    printf("%d %d\n",flux_m/3,fmcm);
    for(int i=1;i<=d;i++)
    for(int j=1;j<=d;j++) if(f[i][j]==1 && i!=s && j!=d)printf("%d ",w[i][j]);
}

int main()
{
    int e,x,y,z;
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
        scanf("%d %d %d",&n,&m,&e);
        s=1; d=n+m+2;
        for(int i=1;i<=e;i++)
        {
            scanf("%d %d %d",&x,&y,&z);
            x++; y+=n+1;
            g[x].push_back(y);
            g[y].push_back(x);
            c[x][y]=1;
            p[x][y]=z;
            p[y][x]=-z;
            w[x][y]=i;
            // adaugam muchii ajutatoare
            if(c[s][x]==0)
            {
                g[s].push_back(x);
                g[x].push_back(s);
            }
            if(c[y][d]==0)
            {
                g[y].push_back(d);
                g[d].push_back(y);
            }
            c[s][x]=1;
            c[y][d]=1;
        }
    maxflow();

    return 0;
}

