#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#define pb push_back
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");

int N, M, L, R, nr[610][610], cap[610][610], flux[610][610], x, y, c, dad[610], cmin, cost[610][610], used[610], D[610], source, sink;
vector < int > G[610], sol;
bool inQ[610];
queue < int > Q;

bool bellman()
{
    for (int i=0; i<=N; ++i)
        D[i]=(1<<30), used[i]=0;
    Q.push(0); D[0]=0; inQ[0]=1;
    while (Q.size())
    {
        int nod=Q.front(); Q.pop(); inQ[nod]=0; ++used[nod];
        if (used[nod]==N) return 0;
        vector <int>::iterator it=G[nod].begin();
        for (; it!=G[nod].end(); ++it)
            if (D[*it]>D[nod]+cost[nod][*it] && cap[nod][*it]>flux[nod][*it])
            {
                D[*it]=D[nod]+cost[nod][*it]; dad[*it]=nod;
                if (!inQ[*it]) inQ[*it]=1, Q.push(*it);
            }
    }
    return (D[N]!=(1<<30));
}

void cmcm()
{
    while (bellman())
    {
        for (int x=N; x!=0; x=dad[x])
            ++flux[dad[x]][x], --flux[x][dad[x]];
        cmin+=D[sink];
    }
    for (int i=1; i<=L; ++i)
        for (int j=L+1; j<=N; ++j)
            if (nr[i][j] && flux[i][j])
                sol.pb(nr[i][j]);
}

int main()
{
    f>>L>>R>>M; N=sink=L+R+1;
    for (int i=1; i<=M; ++i)
    {
        f>>x>>y>>c; y+=L; cap[x][y]=1;
        cost[x][y]=c; cost[y][x]=-c;
        G[x].pb(y); G[y].pb(x); nr[x][y]=i;

        G[0].pb(x); G[x].pb(0); cap[0][x]=1;
        G[y].pb(N); G[N].pb(y); cap[y][N]=1;
    }

    cmcm(); g<<sol.size()<<' '<<cmin<<'\n';
    for (int i=0; i<(int)sol.size(); ++i)
        g<<sol[i]<<' ';
    return 0;
}
