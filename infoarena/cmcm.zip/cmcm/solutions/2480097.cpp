#include <bits/stdc++.h>
#define DIM 650

using namespace std;

ifstream fin  ("cmcm.in");
ofstream fout ("cmcm.out");

int n, m, i, j, k, sursa, destinatie, x, y, cap, minim, u, fluxsol, costsol, nod, l, r;
int d[DIM], t[DIM];
int cost[DIM][DIM], flux[DIM][DIM], capacitate[DIM][DIM], mm[DIM][DIM];

deque <int> q;
vector <int> L[DIM];
bitset <DIM> f;


int bellmanford (){
    int gasit, nod, vecin;
    for (int i=1; i<=destinatie; i++){
        d[i] = INT_MAX;
    }
    f.reset();
    d[sursa] = 0;
    f[sursa] = 1;
    gasit = 0;
    q.clear();
    q.push_back(sursa);
    while (!q.empty()){
        nod = q.front();
        f[nod] = 0;
        q.pop_front();
        for (int i=0; i<L[nod].size(); i++){
            vecin = L[nod][i];
            if (d[vecin] > d[nod] + cost[nod][vecin] && capacitate[nod][vecin] > flux[nod][vecin]){
                d[vecin] = d[nod] + cost[nod][vecin];
                t[vecin] = nod;
                if (f[vecin] == 0){
                    f[vecin] = 1;
                    q.push_back(vecin);
                    if (vecin == destinatie){
                        gasit = 1;
                    }
                }
            }
        }
    }
    return gasit;
}
int main(){
    fin >> l >> r >> m;
    sursa = 0, destinatie = l + r + 1;
    for (i=1; i<=m; i++){
        fin >> x >> y >> k;
        L[x].push_back (l+y);
        L[l+y].push_back (x);
        capacitate[x][l+y] = 1;
        cost[x][l+y] =  k;
        cost[l+y][x] = -k;
        mm[x][l+y] = i;
    }
    for (i=1; i<=l; i++) {
        capacitate[sursa][i]=1;
        L[sursa].push_back(i);
        L[i].push_back(sursa);
    }
    for (i=1; i<=r; i++) {
        capacitate[l+i][destinatie]=1;
        L[destinatie].push_back(l+i);
        L[l+i].push_back(destinatie);
    }
    while (bellmanford()){
        minim = INT_MAX;
        u = destinatie;
        while (u != sursa){
            minim = min (minim, capacitate[t[u]][u] - flux[t[u]][u]);
            u = t[u];
        }
        u = destinatie;
        while (u != sursa){
            flux[t[u]][u] += minim;
            flux[u][t[u]] -= minim;
            costsol += minim*cost[t[u]][u];
            u = t[u];
        }
        fluxsol += minim;
    }
    fout << fluxsol << " " << costsol << "\n";
    for (i=1; i<=l; i++)
        for (j=l+1; j<=l+r; j++)
            if (flux[i][j] == 1)
                fout << mm[i][j ]<< " ";
    return 0;
}
