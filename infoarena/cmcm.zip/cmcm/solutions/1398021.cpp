#include<fstream>
#include<queue>
#include<cstring>
#include<vector>
#include<unordered_map>

using namespace std;
typedef int var;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

#define MAXN 1001
#define INF 2000000000

var n, m, all;
vector<var> G[MAXN];
unordered_map<var, var> F[MAXN], C[MAXN], K[MAXN], I[MAXN];

inline var L(var t) {
    return t;
}
inline var R(var t) {
    return t+n;
}
var S, D;


void addEdge(var a, var b, var cost) {
    G[a].push_back(b);
    G[b].push_back(a);
    K[a][b] = cost;
    K[b][a] = -cost;
    C[a][b] = 1;
}


bool INQ[MAXN];
var DI[MAXN], PARENT[MAXN];
queue<var> Q;
bool bellman() {
    for(var i=1; i<=all; i++) {
        DI[i] = INF;
        PARENT[i] = 0;
        INQ[i] = 0;
    }
    DI[S] = 0;
    Q.push(S);
    while(!Q.empty()) {
        var node = Q.front();
        Q.pop();
        INQ[node] = 0;
        for(auto vec : G[node]) {
            if(C[node][vec] > F[node][vec] && DI[vec] > DI[node] + K[node][vec]) {
                DI[vec] = DI[node] + K[node][vec];
                PARENT[vec] = node;
                if(!INQ[vec]) {
                    INQ[vec] = 1;
                    Q.push(vec);
                }
            }
        }
    }
    return (PARENT[D] != 0);
}

auto mfmc() {
    var cost = 0;
    var flow = 0;
    while(bellman()) {
        for(var node = D; node != S; node = PARENT[node]) {
            F[PARENT[node]][node] ++;
            F[node][PARENT[node]] --;
            cost += K[PARENT[node]][node];
        }
        flow ++;
    }
    return make_pair(cost, flow);
}

int main() {

    var e, a, b, c;

    fin>>n>>m>>e;
    S = n+m+1;
    D = n+m+2;
    all = D;

    for(var i=1; i<=n; i++) {
        addEdge(S, L(i), 0);
    }
    for(var i=1; i<=m; i++) {
        addEdge(R(i), D, 0);
    }

    for(var i=1; i<=e; i++) {
        fin>>a>>b>>c;
        addEdge(L(a), R(b), c);
        I[L(a)][R(b)] = i;
    }

    auto rez = mfmc();

    fout<<rez.second<<" "<<rez.first<<'\n';
    for(var i=1; i<=n; i++) {
        for(auto vec : G[i]) {
            if(F[i][vec] > 0)
                fout<<I[i][vec]<<" ";
        }
    }

    return 0;
}
