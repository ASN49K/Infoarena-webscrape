//#include "stdafx.h"
#include<stdio.h>
#include<algorithm>
#define inf 100000000
#define NMAX 610
#define MMAX 50100
using namespace std;
int N,z[NMAX][NMAX],e,fin[MMAX],x[NMAX][NMAX],dd,viz[NMAX],sol,dist[NMAX],i,j,n,m,k,l,a,s,b,d,nod,in,sf,c,rez,flux[NMAX][NMAX],y[NMAX][NMAX];
struct kkt
{	
	int X,Y,Z;
} q[NMAX*NMAX];
void solve()
{
	a=0;
	in=sf=1;
	q[1].X=s;
	q[1].Z=inf;
	for (i=1;i<=N;i++)
		dist[i]=inf , viz[i]=0;
	dist[s]=0;
	viz[s]=1;
	while (in<=sf)
	{
		nod=q[in].X;
		for (i=1;i<=N;i++)
			if (x[nod][i]||x[i][nod])
				if (dist[i]>dist[nod]+y[nod][i])
				{
					rez=x[nod][i]-flux[nod][i];
					if (rez)
					{
						dist[i]=dist[nod]+y[nod][i];
						if (!viz[i])
						{
							sf++;
							q[sf].X=i;
							q[sf].Y=in;
							q[sf].Z=min(rez,q[in].Z);
							viz[i]=sf;
						}
						else
						{
							q[viz[i]].X=i;
							q[viz[i]].Y=in;
							q[viz[i]].Z=min(rez,q[in].Z);
						}
					}
				}
		viz[nod]=0;
		in++;
	}
	if (dist[d]==inf)
		return ;
	while (q[sf].X!=d)
		sf--;
	a=1;
	rez=q[sf].Z;
	while (sf)
	{
		nod=q[sf].X;
		k=q[sf].Y;
		flux[q[k].X][nod]+=rez;
		sol+=rez*y[q[k].X][nod];
		flux[nod][q[k].X]-=rez;
		sf=q[sf].Y;
	}
	
}
int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d%d%d",&n,&m,&e);
	N=m+n+2;
	s=N-1;
	d=N;
	
	for (i=1;i<=e;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
		b+=n;
		x[a][b] = x[s][a] = x[b][d] = 1;
		y[a][b]=c;
		y[b][a]=-c;
		z[a][b]=i;
	
	}
	
	a=1;
	while (a)
		solve();
	for (i=1;i<=N;i++)
		for (j=1;j<=N;j++)
			if (flux[i][j]&&z[i][j])
				fin[++fin[0]]=z[i][j];
				
	printf("%d %d\n",fin[0],sol);
	for (i=1;i<=fin[0];i++)
		printf("%d ",fin[i]);

	return 0;
}
