#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <cstring>
#define MAXN 10010

using namespace std ;

ifstream fin ( "cuplaj.in" ) ;
ofstream fout ( "cuplaj.out" ) ;

int N , M , E , draw , sol ;
vector<int> G[MAXN] ;
int U[MAXN] , TT[MAXN] , C[MAXN] ;

int DFS ( int node )
{
    if ( U[node] == draw )
        return 0 ;
    U[node] = draw ;
    for ( vector < int > :: iterator it = G[node].begin() ; it != G[node].end() ; ++it )
        if ( TT[*it] == -1 || DFS( TT[*it] ) )
        {
            C[node] = *it ;
            TT[*it] = node ;
            return 1 ;
        }
    return 0 ;
}

void cuplaj()
{
    memset ( TT , -1 , sizeof(TT) ) ;
    int last = -1 ;
    while ( last != sol )
    {
        last = sol ;
        draw++ ;
        for ( int i = 1 ; i <= N ; i++ )
            if ( !C[i] )
                sol+= DFS(i) ;
    }
}

void read()
{
    fin >> N >> M >> E ;
    int x , y ;
    for ( int i = 1 ; i <= E ; i++ )
    {
        fin >> x >> y ;
        G[x].push_back(y) ;
    }
}

void print()
{
    fout << sol << '\n' ;
    for ( int i = 1 ; i <= N ; i++ )
        if ( C[i] )
            fout << i << ' ' << C[i] << '\n' ;
}

int main()
{
    read() ;
    cuplaj() ;
    print() ;
    return 0;
}
