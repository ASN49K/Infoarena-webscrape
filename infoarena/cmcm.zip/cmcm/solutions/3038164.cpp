#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream f ("cmcm.in");
ofstream g ("cmcm.out");
struct elem{
int nod,cost;
bool operator < (const elem &aux)
const{
        return aux.cost<cost;
    }
};
int dist[750],capacitate[750][750];
int muchii[750][750];
priority_queue < elem>q;
vector<pair<int,int>>adiacenta[750];
int n,m,e,rasp_cost,dest;
int tati[750];
int bellman()
{
    for(int i = 0;i<=749;i++)
        dist[i]=(1<<30)-1;
    dist[0] = 0;
    q.push({0,0});
    while(!q.empty())
    {
        int curent = q.top().nod;
        int cost_curent = q.top().cost;
        q.pop();
        if(curent==dest)
            continue;
        for(auto x:adiacenta[curent])
        {
            int nod_nou = x.first;
            int cost_nou = x.second;
            if(dist[nod_nou]>cost_curent+cost_nou && capacitate[curent][nod_nou]!=0)
            {
                dist[nod_nou]= cost_curent+cost_nou;
                tati[nod_nou]=curent;
                q.push({nod_nou,dist[nod_nou]});
            }
        }
    }
    if(dist[dest]!=(1<<30)-1)
        return 1;
    return 0;
}
int main()
{
    f >> n >> m>>e;
    for(int i=1;i<=e;i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        y  =y+n+1;
        adiacenta[x].push_back({y,c});
        adiacenta[y].push_back({x,-c});
        capacitate[x][y] = 1;
        muchii[x][y] = i;
    }
    dest = n+m+2;
    int start = 0;
    for(int i = 1;i<=n;i++)
    {
        adiacenta[0].push_back({i,0});
        capacitate[0][i] = 1;
    }
    for(int i = n+2;i<=n+m+1;i++)
    {
        adiacenta[i].push_back({dest,0});
        capacitate[i][dest] = 1;
    }
    while(bellman())
    {
                int flux = (1<<30)-1;
                int nod_start = dest;
                while(nod_start!=0)
                {
                    flux= min(flux,capacitate[tati[nod_start]][nod_start]);
                    nod_start = tati[nod_start];
                }
                if(flux==0)
                    continue;
                nod_start = dest;
                while(nod_start!=0)
                {
                    capacitate[tati[nod_start]][nod_start]-=flux;
                    capacitate[nod_start][tati[nod_start]]+=flux;
                    nod_start = tati[nod_start];
                }
                rasp_cost+=flux*dist[dest];
    }
    int cnt_muchii = 0;
    for(int i= 1;i<=n;i++)
    {
        for(int j = n+1;j<=n+m+2;j++)
        {
            if(muchii[i][j]!=0 && capacitate[i][j]==0)
                cnt_muchii++;
        }
    }
    g<<cnt_muchii<< " "<<rasp_cost<< '\n';
    for(int i= 1;i<=n;i++)
    {
        for(int j = n+1;j<=n+m+2;j++)
        {
            if(muchii[i][j]!=0 && capacitate[i][j]==0)
                g << muchii[i][j]<< " ";
        }
    }
}
