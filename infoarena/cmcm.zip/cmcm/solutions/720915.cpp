#include <cstdio>
#define N 605
#define E 50005
#define inf 1999999999
using namespace std;
struct nod{ int val; nod *urm; }*G[N];
struct coada{ int v; coada *next; }*st,*dr;
int cap[N][N],cost[N][N],flux[N][N],muc[N][N],heap[N],lgheap,poz[N],ad[N][N];
int n,m,SS,SD;
int ctotal,k,sol[E],dist[N],tata[N],c[E];
bool viz[N];

void add(int x,int y,int cpc,int cst)
{ nod *aux;
aux=new nod; aux->val=y; aux->urm=G[x]; G[x]=aux;
cap[x][y]=cpc; cost[x][y]=cst;
}
void read()
{ int e,x,y,z,i;
freopen("cmcm.in","r",stdin); scanf("%d %d %d\n",&n,&m,&e);
for(i=1;i<=e;++i)
    {
    scanf("%d %d %d\n",&x,&y,&z);
    muc[x][y+n]=i;
    add(x,y+n,1,z);
    add(y+n,x,0,-z);
    }
fclose(stdin);
}
void bellman_ford()
{ int i,x,y;
  nod *aux;
  coada *adr;
for(i=1;i<=n+m;++i)
    {
    dist[i]=inf;
    viz[i]=0;
    }
dist[SD]=inf;
dist[SS]=0; viz[SS]=1;
adr=new coada; adr->v=SS; adr->next=NULL; st=dr=adr;
while(st)
    {
    x=st->v; viz[x]=0;
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        {
        y=aux->val;
        if(cap[x][y]>flux[x][y]&&dist[x]+cost[x][y]<dist[y])
            {
            dist[y]=dist[x]+cost[x][y];
            tata[y]=x;
            if(viz[y]==0)
                 {
                 adr=new coada; adr->v=y; adr->next=NULL; dr->next=adr; dr=adr;
                 viz[y]=1;
                 }
            }
        }
    adr=st; st=st->next; delete adr;
    }
}
inline int min(int x,int y)
{
if(x<y)return x;
    else return y;
}
void extractmin()
{ int tata,fiu,z;
  bool e;
poz[heap[1]]=-1; poz[heap[lgheap]]=1;
heap[1]=heap[lgheap]; heap[lgheap]=0; --lgheap;
tata=1; fiu=2; e=true;
while(e&&fiu<=lgheap)
    {
    e=false;
    if(dist[heap[fiu+1]]<dist[heap[fiu]]&&fiu+1<=lgheap)++fiu;
    if(dist[heap[tata]]>dist[heap[fiu]])
        {
        e=true;
        z=poz[heap[tata]]; poz[heap[tata]]=poz[heap[fiu]]; poz[heap[fiu]]=z;
        z=heap[tata]; heap[tata]=heap[fiu]; heap[fiu]=z;
        tata=fiu; fiu=tata<<1;
        }
    }
}
void upinheap(int ind)
{ int fiu,tata,z;
  bool e;
fiu=poz[ind];
tata=fiu>>1; e=true;
while(tata>=1&&e)
    {
    e=false;
    if(dist[heap[tata]]>dist[heap[fiu]])
                        {
                        e=true;
                        z=poz[heap[tata]]; poz[heap[tata]]=poz[heap[fiu]]; poz[heap[fiu]]=z;
                        z=heap[tata]; heap[tata]=heap[fiu]; heap[fiu]=z;
                        fiu=tata; tata=fiu>>1;
                        }
    }
}
int dijkstra()
{ int i,x;
  nod *aux;
lgheap=1; heap[1]=SS; poz[SS]=1; tata[SS]=0; dist[SS]=0;
for(i=1;i<=n+m;++i)
    {
    dist[i]=inf;
    ++lgheap;
    heap[lgheap]=i;
    poz[i]=lgheap;
    tata[i]=0;
    }
++lgheap; heap[lgheap]=SD; poz[SD]=lgheap; tata[SD]=0; dist[SD]=inf;
while(lgheap>=1)
    {
    x=heap[1]; extractmin();
    for(aux=G[x];aux!=NULL;aux=aux->urm)
        if(cap[x][aux->val]>flux[x][aux->val]&&dist[aux->val]>dist[x]+cost[x][aux->val])
                        {
                        dist[aux->val]=dist[x]+cost[x][aux->val];
                        tata[aux->val]=x;
                        upinheap(aux->val);
                        }
    }
if(dist[SD]!=inf)return 1;
    else return 0;
}
void solve()
{ int fm,i;
  nod *aux;
bellman_ford();
for(i=1;i<=n+m;++i)
    for(aux=G[i];aux!=NULL;aux=aux->urm)
        if(dist[i]!=inf&&dist[aux->val]!=inf)
            {
            cost[i][aux->val]=cost[i][aux->val]+dist[i]-dist[aux->val];
            ad[i][aux->val]=dist[i]-dist[aux->val];
            }

while(dijkstra())
    {
    fm=inf;
    for(i=SD;i!=SS;i=tata[i])
        fm=min(fm,cap[tata[i]][i]-flux[tata[i]][i]);
    if(fm)
        {
        for(i=SD;i!=SS;i=tata[i])
            {
            flux[tata[i]][i]+=fm;
            flux[i][tata[i]]-=fm;
            }
        }
    }
}
void reconstr_sol()
{ int i,j;
ctotal=0; k=0;
for(i=1;i<=n;++i)
    for(j=1;j<=m;++j)
        if(flux[i][j+n]==1)
            {
            ctotal+=cost[i][j+n]-ad[i][j+n];
            sol[++k]=muc[i][j+n];
            }
}
void write()
{ int i;
freopen("cmcm.out","w",stdout); printf("%d %d\n",k,ctotal);
for(i=1;i<=k;++i)printf("%d ",sol[i]);
fclose(stdout);
}
int main()
{ int i;
read();
SS=601; // super sursa;
SD=602; // super destinatie
for(i=1;i<=n;++i)
    {
    add(SS,i,1,0);
    add(i,SS,0,0);
    }
for(i=1;i<=m;++i)
    {
    add(i+n,SD,1,0);
    add(SD,i+n,0,0);
    }
solve();
reconstr_sol();
write();
return 0;
}
