# include <fstream>
# include <vector>
# include <queue>
# define DIM 700
# define INF 1000000000
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
vector<int> Lista[DIM];
queue<int> q;
int c[DIM][DIM],f[DIM][DIM],ct[DIM][DIM],poz[DIM][DIM];
int Marcat[DIM],d[DIM],t[DIM],vec[DIM],x,y,m,n,nr,nc,nv,i,j,dif,cost,k;
bool bellmanford(){
    q.push(0);
    t[0]=-1;
    for(int i=1;i<=m+n+1;i++){
        d[i]=INF;
        t[i]=-1;
    }
    while(!q.empty()){
        nc=q.front();
        q.pop();
        Marcat[nc]=0;
        for(auto nv:Lista[nc]){
            if(d[nc]+ct[nc][nv]<d[nv]&&f[nc][nv]<c[nc][nv]){
                d[nv]=d[nc]+ct[nc][nv];
                t[nv]=nc;
                if(Marcat[nv]==0){
                    Marcat[nv]=1;
                    q.push(nv);
                }
            }
        }
    }
    if(d[n+m+1]==INF)
        return 0;
    return 1;
}
int main () {
    fin>>n>>m>>nr;
    for(i=1;i<=nr;i++){
        fin>>x>>y>>cost;
        Lista[x].push_back(y+n);
        Lista[y+n].push_back(x);
        ct[x][y+n]=cost;
        ct[y+n][x]=-cost;
        c[x][y+n]=1;
        poz[x][y+n]=i;
    }
    for(i=1;i<=n;i++){
        Lista[0].push_back(i);
        Lista[i].push_back(0);
        c[0][i]=1;
    }
    for(;i<=n+m;i++){
        Lista[i].push_back(n+m+1);
        Lista[n+m+1].push_back(i);
        c[i][n+m+1]=1;
    }
    while(bellmanford()){
        dif=INF;
        for(x=n+m+1;t[x]!=-1;x=t[x])
            dif=min(dif,c[t[x]][x]-f[t[x]][x]);
        for(x=n+m+1;t[x]!=-1;x=t[x]){
            f[t[x]][x]+=dif;
            f[x][t[x]]-=dif;
        }
    }
    cost=0;
    for(i=0;i<=n+m+1;i++)
        for(j=0;j<=n+m+1;j++)
            if(f[i][j]==c[i][j]&&poz[i][j]){
                vec[++k]=poz[i][j];
                cost+=ct[i][j];
            }
    fout<<k<<" "<<cost<<"\n";
    for(i=1;i<=k;i++)
        fout<<vec[i]<<" ";
    fout<<"\n";
    return 0;
}
