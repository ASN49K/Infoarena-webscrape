#include <bits/stdc++.h>
#include <iostream>
#define dim 699
#define inf 2000000000
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
bitset  <dim> fr;
deque <int> q;
int d[dim],t[dim];
vector <int> L[dim],sol;
map < pair<int,int>, int > mp;

/// -------------------- ///

int l,r,C[dim][dim],cost[dim][dim],F[dim][dim],m,i,j,x,y,z,aux,flux,solutie,minim;
int bf2 (){
    int gasit, nod, vecin,sursa=0,destinatie=l+r+1;
    for (int i=1; i<=destinatie; i++){
        d[i] = INT_MAX;
    }
    fr.reset();
    d[sursa] = 0;
    fr[sursa] = 1;
    gasit = 0;
    q.clear();
    q.push_back(sursa);
    while (!q.empty()){
        nod = q.front();
        fr[nod] = 0;
        q.pop_front();
        for (int i=0; i<L[nod].size(); i++){
            vecin = L[nod][i];
            if (d[vecin] > d[nod] + cost[nod][vecin] && C[nod][vecin] > F[nod][vecin]){
                d[vecin] = d[nod] + cost[nod][vecin];
                t[vecin] = nod;
                if (fr[vecin] == 0){
                    fr[vecin] = 1;
                    q.push_back(vecin);
                    if (vecin == destinatie){
                        gasit = 1;
                    }
                }
            }
        }
    }
    return gasit;
}
bool bf()
{
    int i,nod,vecin;
    fr.reset();
    q.clear();
    for(int i=0; i<=l+r+2; i++)
        d[i]=inf;
    d[0]=0;
    q.push_back(0);
    fr[0]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop_front();
        for(int i=0; i<L[nod].size(); i++)
        {
            vecin=L[nod][i];
            if(C[nod][vecin]>F[nod][vecin]&& d[vecin]>d[nod]+cost[nod][vecin])
            {
                d[vecin]=d[nod]+cost[nod][vecin];
                t[vecin]=nod;
                if(fr[vecin]==0)
                {
                    fr[vecin]=1;
                    q.push_back(vecin);
                }
            }
        }


    }
    return fr[l+r+1];

}
int main()
{
    fin>>l>>r>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>z;
        L[x].push_back(y+l);
        L[y+l].push_back(x);
        cost[x][y+l]=z;
        cost[y+l][x]=-z;
        C[x][y+l]=1;
        mp[ {x,y+l}]=i;
    }
    for(i=1; i<=l; i++)
    {
        L[0].push_back(i);
        L[i].push_back(0);
        C[0][i]=1;
    }
    for(i=l+1; i<=l+r; i++)
    {
        L[i].push_back(l+r+1);
        L[l+r+1].push_back(i);
        C[i][l+r+1]=1;
    }
    while(bf2())
    {
        minim=1;
        aux=l+r+1;
        while(aux!=0)
        {
            F[t[aux]][aux]++;
            F[aux][t[aux]]--;
            solutie+=cost[t[aux]][aux];
        cout<<solutie<<endl;
            aux=t[aux];
        }
        flux+=minim;
    }
    fout<<flux<<" "<<solutie<<"\n";
    for(i=1; i<=l; i++)
        for(j=l+1; j<=l+r; j++)
            if(F[i][j])
            {
                fout<<mp[{i,j}]<<" ";
            }
}
