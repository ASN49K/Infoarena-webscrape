#include<fstream.h>
#define u (1<<30)
int v[1399],ver[129999],leg[129999],start[699],cost[129999],d[699],D,fa[699],c[699][699],q[699],qq[699],rez,nr[699][699],luat[699];
int bf()
{
	int i,t;
	for(i=1;i<=D;i++)
	{
		d[i]=u;
		fa[i]=0;
		luat[i]=0;
	}
	d[1]=0;
	qq[0]=q[0]=q[1]=1;
	luat[1]=1;
	while(q[0]&&qq[0])
	{
		qq[0]=0;
		for(i=1;i<=q[0];i++)
		{
			t=start[q[i]];
			while(t)
			{
				if(c[q[i]][ver[t]]&&d[ver[t]]>d[q[i]]+cost[t])
				{
					d[ver[t]]=d[q[i]]+cost[t];
					fa[ver[t]]=q[i];
					if(!luat[ver[t]])
					{
						luat[ver[t]]=1;
						qq[++qq[0]]=ver[t];
					}
				}
				t=leg[t];
			}
			luat[q[i]]=0;
		}
		if(qq[0])
		{
			q[0]=0;
			for(i=1;i<=qq[0];i++)
			{
				t=start[qq[i]];
				while(t)
				{
					if(c[qq[i]][ver[t]]&&d[ver[t]]>d[qq[i]]+cost[t])
					{
						d[ver[t]]=d[qq[i]]+cost[t];
						fa[ver[t]]=qq[i];
						if(!luat[ver[t]])
						{
							luat[ver[t]]=1;
							q[++q[0]]=ver[t];
						}
					}
					t=leg[t];
				}
				luat[qq[i]]=0;
			}
		}
	}
	if(d[D]!=u)
	{
		i=D;
		while(i!=1)
		{
			c[fa[i]][i]-=1;
			c[i][fa[i]]+=1;
			i=fa[i];
		}
		rez+=d[D];
		return 1;
	}
	return 0;
}
int main()
{
	int i,x,y,z,n,m,e,q=0,j;
	ifstream f("cmcm.in");
	ofstream g("cmcm.out");
	f>>n>>m>>e;
	for(i=1;i<=e;i++)
	{
		f>>x>>y>>z;
		x++;
		y+=n+1;		
		ver[++q]=y;
		leg[q]=start[x];
		start[x]=q;
		cost[q]=z;	
		ver[++q]=x;
		leg[q]=start[y];
		start[y]=q;
		cost[q]=-z;
		nr[x][y]=i;
		c[x][y]=1;
	}
	for(i=2;i<=n+1;i++)
	{
		ver[++q]=i;
		leg[q]=start[1];
		start[1]=q;
		c[1][i]=1;
		ver[++q]=1;
		leg[q]=start[i];
		start[i]=q;
	}
	D=n+m+2;
	for(i=2;i<=m+1;i++)
	{
		ver[++q]=D;
		leg[q]=start[n+i];
		start[n+i]=q;
		c[n+i][D]=1;
		ver[++q]=n+i;
		leg[q]=start[D];
		start[D]=q;
	}
	while(bf());
	v[0]=0;
	for(i=2;i<=n+1;i++)
		for(j=n+2;j<D;j++)
			if(nr[i][j]&&!c[i][j])
				v[++v[0]]=nr[i][j];
	g<<v[0]<<' '<<rez<<'\n';
	for(i=1;i<=v[0];i++)
		g<<v[i]<<' ';
	return 0;
}
