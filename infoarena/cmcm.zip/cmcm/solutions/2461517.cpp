#include <cstdio>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;
const int INF = 2000000000;
vector<int> g[605];
int cap[605][605];
int flow[605][605];
int cost[605][605];
int dist[605];
int inq[605];
int dp[605];
int distt[605];
int parcdijk[605];
int ind[605][605];
queue<int> q;
struct Node
{
    int nod,cst;
};
struct Comp
{
    bool operator()(const Node &a, const Node &b)
    {
        return a.cst>b.cst;
    }
};
priority_queue<Node, vector<Node>, Comp > pq;
int n;
int m;
int cupl;
void belford(int s, int d)
{
    for(int i=1; i<=n+m+2; i++){
        dist[i]=INF;
        inq[i]=0;
    }
    q.push(s);
    dist[s]=0;
    while(!q.empty()){
        int u=q.front();
        inq[u]=0;
        q.pop();
        for(int i=0; i<g[u].size(); i++)
            if(cap[u][g[u][i]]>flow[u][g[u][i]] && dist[g[u][i]]>dist[u]+cost[u][g[u][i]]){
                dist[g[u][i]]=dist[u]+cost[u][g[u][i]];
                if(inq[g[u][i]]==0){
                    inq[g[u][i]]=1;
                    q.push(g[u][i]);
                }
            }
    }
}
bool dijkstra(int s, int d)
{
    for(int i=1; i<=n+m+2; i++){
        dp[i]=INF;
        distt[i]=INF;
    }
    pq.push({s, 0});
    dp[s]=distt[s]=0;
    while(!pq.empty()){
        Node u=pq.top();
        pq.pop();
        if(u.cst==dp[u.nod]){
            for(int i=0; i<g[u.nod].size(); i++)
                if(flow[u.nod][g[u.nod][i]]<cap[u.nod][g[u.nod][i]] && dp[g[u.nod][i]]>dp[u.nod]+cost[u.nod][g[u.nod][i]]+dist[u.nod]-dist[g[u.nod][i]]){
                    dp[g[u.nod][i]]=dp[u.nod]+cost[u.nod][g[u.nod][i]]+dist[u.nod]-dist[g[u.nod][i]];
                    distt[g[u.nod][i]]=distt[u.nod]+cost[u.nod][g[u.nod][i]];
                    parcdijk[g[u.nod][i]]=u.nod;
                    pq.push({g[u.nod][i], dp[g[u.nod][i]]});
                }
        }
    }
    for(int i=1; i<=n+m+2; i++)
        dist[i]=distt[i];
    return dp[d]!=INF;
}
int detflow(int s, int d)
{
    int minc=0,i;
    while(dijkstra(s, d)){
        int flu=INF;
        for(i=d; i!=s; i=parcdijk[i])
            flu=min(flu, cap[parcdijk[i]][i]-flow[parcdijk[i]][i]);
        cupl+=flu;
        minc+=flu*dist[d];
        for(i=d; i!=s; i=parcdijk[i]){
            flow[parcdijk[i]][i]+=flu;
            flow[i][parcdijk[i]]-=flu;
        }
    }
    return minc;
}
int main()
{   freopen("cmcm.in", "r", stdin);
    freopen("cmcm.out", "w", stdout);
    int e,x,y,z,i,j;
    scanf("%d%d%d", &n, &m, &e);
    for(i=1; i<=e; i++){
        scanf("%d%d%d", &x, &y, &z);
        g[x].push_back(y+n);
        g[y+n].push_back(x);
        cap[x][y+n]=1;
        cost[x][y+n]=z;
        cost[y+n][x]=-z;
        ind[x][y+n]=ind[y+n][x]=i;
    }
    for(i=1; i<=n; i++){
        g[n+m+1].push_back(i);
        g[i].push_back(n+m+1);
        cap[n+m+1][i]=1;
    }
    for(i=n+1; i<=n+m; i++){
        g[n+m+2].push_back(i);
        g[i].push_back(n+m+2);
        cap[i][n+m+2]=1;
    }
    belford(n+m+1, n+m+2);
    x=detflow(n+m+1, n+m+2);
    printf("%d %d\n", cupl, x);
    for(i=1; i<=n; i++)
        for(j=0; j<g[i].size(); j++)
            if(flow[i][g[i][j]]==1 && g[i][j]<=n+m)
                printf("%d ", ind[i][g[i][j]]);
    return 0;
}
