#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <queue>
#include <bitset>

#define super_start 605
#define super_sink 607

#define Nmax 610
#define INF 0x3f3f3f3f

#define v first
#define e second

using namespace std;

class edge{
public:
    int x,y,capacity,flow,cost,ind;
    edge(){
        x = y = capacity = flow = cost = ind = 0;
    }
    edge(int a,int b,int cp,int cst,int fl,int ii){
        this->x = a;
        this->y = b;
        this->capacity = cp;
        this->cost = cst;
        this->flow = fl;
        this->ind = ii;
    }
};
bitset<Nmax> inQ;
vector<edge> E;
queue<int> Q;
vector<pair<int,int> > G[Nmax];
int nre = -1,st,dr,M;
int DP[Nmax],daddy[Nmax];

void Insert(int a,int b,int cp,int cst,int fl,int ii){
    ++nre;
    E.push_back(edge(a,b,cp,cst,fl,ii));
    G[a].push_back(make_pair(b,nre));
}

void Read()
{
    int a,b,c;
    scanf("%d%d%d",&st,&dr,&M);
    for(int i = 1; i <= M; ++i){
        scanf("%d%d%d",&a,&b,&c);
        b += st;
        Insert(a,b,1,c,0,i);
        Insert(b,a,0,-c,0,i);
    }
    for(int i = 1; i <= st; ++i){
        Insert(super_start,i,1,0,0,0);
        Insert(i,super_start,0,0,0,0);
    }
    for(int i = st + 1; i <= st + dr; ++i){
        Insert(i,super_sink,1,0,0,0);
        Insert(super_sink,i,0,0,0,0);
    }
}

bool Bellman_Ford(int k)
{
    memset(DP,INF,sizeof(DP));
    DP[k] = 0;
    Q.push(k);
    while(!Q.empty())
    {
        k = Q.front(); Q.pop();
        inQ[k] = 0;
        if(k == super_sink) continue;
        for(vector<pair<int,int> >::iterator it = G[k].begin(); it != G[k].end(); ++it)
            if(DP[it->v] > DP[k] + E[it->e].cost && E[it->e].capacity != E[it->e].flow)
            {
                DP[it->v] = DP[k] + E[it->e].cost;
                daddy[it->v] = it->e;
                if(inQ[it->v])
                    continue;
                Q.push(it->v);
                inQ[it->v] = 1;
            }
    }
    return DP[super_sink] != INF;
}

void FLOW(int k)
{
    int minFLOW,maxFLOW = 0,minCOST = 0;
    while(Bellman_Ford(k))
    for(vector<pair<int,int> >::iterator it = G[k].begin(); it != G[k].end(); ++it)
    {
        minFLOW = INF;
        for(int nodc = super_sink; nodc != super_start; nodc = E[daddy[nodc]].x)
            minFLOW = min(minFLOW,E[daddy[nodc]].capacity - E[daddy[nodc]].flow);
        for(int nodc = super_sink; nodc != super_start; nodc = E[daddy[nodc]].x)
        {
            E[daddy[nodc]].flow += minFLOW;
            E[daddy[nodc]^1].flow -= minFLOW;
        }
        maxFLOW += minFLOW;
        minCOST += minFLOW * DP[super_sink];
    }
    printf("%d %d\n",maxFLOW,minCOST);
}

void Get_ans()
{
   for(vector<edge>::iterator it = E.begin(); it != E.end(); ++it)
        if(it->flow == 1 && it->ind)
            printf("%d ",it->ind);
}

int main()
{
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);

    Read();
    FLOW(super_start);
    Get_ans();

    return 0;
}
