#include<fstream>
#include<cstdio>
#include<set>
#include<stack>
#include<vector>
#include<algorithm>
#define FOR(a,b,c) for(int a=b;a<=c;++a)
#include<cstring>
#include<bitset>
#include<cmath>
#include<iomanip>
#include<queue>
#define f cin
#define g cout
#define mp make_pair
#define pb push_back
#define ll long long
#define inf 0x3f3f3f3f
#define base 256
#define ba 255
#define N 620
#define M 50100
#define EPS 1e-12
#define mod  98999
#define inu "cmcm.in"
#define outu "cmcm.out"
using namespace std;
ifstream f(inu);
ofstream g(outu);
//int dx[]={0,0,0,1,-1};
//int dy[]={0,1,-1,0,0};
vector<pair<int,int> > v[N];
queue<int> q;
int Cp[N][N],n,m,s,d,X[M],Y[M],edge,cuplaj,C[N],cost,minim,F[N][N],inq[N],T[N],x,y,z,c;
void init()
{
	q.push(s);
	memset(C,inf,sizeof(C));
	memset(inq,0,sizeof(inq));
	inq[s]=1;
	C[s]=0;
}
bool bellmanford()
{
	init();
	for(;!q.empty();)
	{
		int nod=q.front();
		q.pop();
		inq[nod]=0;
		for(int i=0;i<v[nod].size();++i)
		{
			int des=v[nod][i].first;
			int cost=v[nod][i].second;
			if(Cp[nod][des]>F[nod][des])
				if(C[nod]+cost<C[des])
				{
					T[des]=nod;
					C[des]=C[nod]+cost;
					if(!inq[des])
					{
						inq[des]=1;
						q.push(des);
					}
				}
		}
	}
	if(C[d]!=inf)
	{
		int des=d;
		minim=inf;
		for(;T[des];des=T[des])
			minim=min(minim,Cp[T[des]][des]-F[T[des]][des]);
		des=d;
		for(;T[des];des=T[des])
		{
			F[T[des]][des]+=minim;
			F[des][T[des]]-=minim;
		}
	}
	return C[d]!=inf;
}
void flux()
{
	while(bellmanford())
	{
		cost+=minim*C[d];
		cuplaj+=minim;
	}
	g<<cuplaj<<" "<<cost<<"\n";
	FOR(i,1,edge)
	if(F[X[i]][Y[i]])
		g<<i<<" ";
	return ;
}
int main ()
{
	f>>n>>m>>edge;
	FOR(i,1,edge)
	{
		f>>x>>y>>z;
		y+=n;
		X[i]=x;
		Y[i]=y;
		v[x].pb(mp(y,z));
		v[y].pb(mp(x,-z));
		Cp[x][y]=1;
	}
	s=n+m+2;
	d=n+m+1;
	FOR(i,1,n)
	{
		v[s].pb(mp(i,0));
		Cp[s][i]=1;
	}
	FOR(i,1,m)
	{
		v[n+i].pb(mp(d,0));
		Cp[n+i][d]=1;
	}
	flux();
    return 0;
}