#include <queue>
#include <bitset>
#include <cstdlib>
#include <fstream>
#define Nmax 711
#define oo 100000000

/*
 *
 */
using namespace std;
typedef pair< int, int > pr;
int N, M, E, source, sink=700;
int d[Nmax], f[Nmax];
int C[Nmax][Nmax], F[Nmax][Nmax], idx[Nmax][Nmax];
bitset< Nmax > inH;
vector< pr > G[Nmax];
vector< pr >::const_iterator it, iend;
class cmp
{
public:
    inline bool operator() ( const int& x, const int& y )
    {
        return d[x] > d[y];
    }
};
priority_queue< int, vector<int>, cmp > pQ;
bool MinPath( void )
{
    int x;
    inH&=0;
    fill( d+1, d+E, oo );
    d[sink]=oo;
    d[source]=0;
    f[sink]=0;
    f[source]=0;
    inH.set(source);
    for( pQ.push(source); !pQ.empty(); )
    {
        x=pQ.top(); pQ.pop();
        inH.flip(x);
        for( it=G[x].begin(), iend=G[x].end(); it < iend; ++it )
            if( C[x][it->first] > F[x][it->first] && d[it->first] > d[x]+it->second )
            {
                f[it->first]=x;
                d[it->first]=d[x]+it->second;
                if( false == inH.test(it->first) )
                {
                    pQ.push(it->first);
                    inH.set(it->first);
                }
            }
    }
    return oo != d[sink];
}
int main( void )
{
    int i, x, y, dd;
    ifstream in( "cmcm.in" );
    in>>N>>M>>E;
    for( i=1; i <= E; ++i )
    {
        in>>x>>y>>dd;
        y+=N+1;
        idx[x][y]=i;
        C[source][x]=C[y][sink]=C[x][y]=1;
        G[x].push_back( pr( y, dd ) );
        G[y].push_back( pr( x, -dd) );
        if( false == inH.test(x) )
        {
            G[source].push_back( pr( x, 0 ) );
            G[x].push_back( pr( source, 0 ) );
            inH.set(x);
        }
        if( false == inH.test(y) )
        {
            G[y].push_back( pr( sink, 0 ) );
            G[sink].push_back( pr( y, 0 ) );
            inH.set(y);
        }
    }
    E=N+M+2;
    for( x=y=0; MinPath(); ++x, y+=d[sink] )
    {
        for( dd=sink; dd; dd=f[dd] )
            ++F[f[dd]][dd], --F[dd][f[dd]];
    }
    ofstream out( "cmcm.out" );
    out<<x<<' '<<y<<'\n';
    for( y=1; y <= N && x; ++y )
    {
        for( it=G[y].begin(), iend=G[y].end(); it < iend; ++it )
            if( F[y][it->first] > 0 )
            {
                --x;
                out<<idx[y][it->first]<<'\n';
            }
    }
    return EXIT_SUCCESS;
}
