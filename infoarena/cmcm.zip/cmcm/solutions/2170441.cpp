#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

void DF(int nod,vector<vector<pair<int,int>>>&path,vector<bool>&viz)
{
    viz[nod]=1;
    for(auto vec:path[nod])
    {
        if(!viz[vec.first])
            DF(vec.first,path,viz);
    }
}

int main()
{
    int n,m;
    fin>>n>>m;
    vector<vector<pair<int,int>>>path(n+1);
    int x,y;
    for(int i=0;i<m;i++)
    {
        fin>>x>>y;
        path[x].push_back(make_pair(y,i));
        path[y].push_back(make_pair(x,i));
    }

    for(int i=1;i<=n;i++)
    {
        if(path[i].size()%2!=0)
        {
            fout<<-1<<'\n';
            return 0;
        }
    }

    vector<bool>viz(n+1);
    DF(1,path,viz);

    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            fout<<-1<<'\n';
            return 0;
        }
    }

    vector<bool>used(m+1);
    stack<int> stk;
    stk.push(1);

    while(!stk.empty())
    {
        x=stk.top();
        if(path[x].size())
        {
            y=path[x].back().first;
            m=path[x].back().second;
            path[x].pop_back();
            if(!used[m])
            {
                used[m]=1;
                stk.push(y);
            }

        }
        else
        {

            fout<<x<<' ';
            stk.pop();
        }
    }

    return 0;
}
