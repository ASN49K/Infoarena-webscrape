#include <bits/stdc++.h>
#define N 610
#define pp pair<int,int>

using namespace std;

int n, m, e, C[N][N], u, t[N], cuplaj, cost, w, E[N][N], d[N], p[N], edge[N][N];
int inf = INT_MAX;
bool o[N];
vector<int> r;
vector<pp> G[N];
queue<int> Q;

bool bellman_ford()
{
	int s, x;
	memset(o, 0, sizeof(o));
	for (int i = 0; i <= u; i++) d[i] = inf, t[i] = -1;
	
	d[0] = 0;
	Q.push(0);
	o[0] = 1;
	
	while (!Q.empty())
	{
		s = Q.front();
		Q.pop();
		o[s] = 0;

		for (auto p:G[s])
		{
			x = p.first;
			if (C[s][x] > 0 && d[x] > d[s] + p.second)
			{
				d[x] = d[s] + p.second;
				t[x] = s;
				if (!o[x]) o[x] = 1, Q.push(x);
			}
		}
	}
	return t[u] != -1;
}

int main()
{
    freopen ("cmcm.in","r",stdin);
    freopen ("cmcm.out","w",stdout);
    scanf("%i%i%i", &n, &m, &e);
    u = n + m + 1;

	int i, x, y, c;
    for (i = 1; i <= e; i++)
    {
		scanf("%i%i%i", &x, &y, &c);
		G[x].push_back(make_pair(y + n, c));
		G[y + n].push_back(make_pair(x, -c));
		C[x][y + n] = 1;
		E[x][y + n] = c;
		edge[x][y + n] = i;
	}	

	for (i = 1; i <= n; i++) 
	{
		G[0].push_back(make_pair(i, 0));
		G[i].push_back(make_pair(0, 0));
		C[0][i] = 1;
	}

	for (i = n + 1; i <= n + m; i++)
	{
		G[i].push_back(make_pair(u, 0));
		G[u].push_back(make_pair(i, 0));
		C[i][u] = 1;
	}

	while (bellman_ford())
	{
		w = inf;

		for (i = u; i != 0; i = t[i])
			w = min(w, C[t[i]][i]);

		cuplaj += w;

		for (i = u; i != 0; i = t[i])
		{
			p[t[i]] = i;
			C[t[i]][i] -= w;
			C[i][t[i]] += w;
		}
	}

	for (i = 1; i <= n; i++)
		if (p[i])
		{
			cost += E[i][p[i]];
			r.push_back(edge[i][p[i]]);
		}

	printf("%i %i\n", cuplaj, cost);
	for (auto x: r) printf("%i ", x);

    return 0;
}
