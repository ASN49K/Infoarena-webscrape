#include<bits/stdc++.h>
#define nl '\n'
using namespace std;
const string file="cmcm";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
#define pii pair<int,int>
struct flux {
    struct edge {
        int to,rez,cap,cost;
    };
    int n,s,t;
    vector<vector<edge>>v;
    vector<int>dist,pot;
    vector<int>dad,dadedge;
    flux(int _n, int _s, int _t) {
        n=_n,s=_s,t=_t;
        v.resize(n+1);
        dist.resize(n+1);
        pot.resize(n+1);
        dad.resize(n+1);
        dadedge.resize(n+1);
    }
    void add(int x, int y, int cap, int cost) {
        edge a={y,(int)v[y].size(),cap,cost};
        edge b={x,(int)v[x].size(),0,-cost};
        v[x].push_back(a);
        v[y].push_back(b);
    }
    void bellman() {
        fill(pot.begin(),pot.end(),INT_MAX);
        queue<int>q;
        q.push(s);
        pot[s]=0;
        vector<bool>fr(n+1,0);
        fr[s]=1;
        while (!q.empty()) {
            int x=q.front();
            q.pop();
            fr[x]=0;
            if (pot[x]==INT_MAX) continue;
            for (auto e:v[x]) {
                if (e.cap>0 && pot[e.to]>pot[x]+e.cost) {
                    pot[e.to]=pot[x]+e.cost;
                    if (!fr[e.to]) {
                        fr[e.to]=1;
                        q.push(e.to);
                    }
                }
            }
        }
    }
    bool dijkstra() {
        fill(dist.begin(),dist.end(),INT_MAX);
        priority_queue<pii,vector<pii>,greater<pii>>q;
        dist[s]=0;
        q.push({0,s});
        while (!q.empty()) {
            int cost=q.top().first;
            int x=q.top().second;
            q.pop();
            if (cost!=dist[x]) continue;
            for (int i=0; i<v[x].size(); i++) {
                edge &e=v[x][i];
                if (e.cap>0) {
                    int d=cost+e.cost+pot[x]-pot[e.to];
                    if (d<dist[e.to]) {
                        dist[e.to]=d;
                        dad[e.to]=x;
                        dadedge[e.to]=i;
                        q.push({d,e.to});
                    }
                }
            }
        }
        return dist[t]!=INT_MAX;
    }
    pii fluxcost() {
        bellman();
        int flow=0,cost=0;
        while (dijkstra()) {
            for (int i=1; i<=n; ++i)
                if (dist[i]<INT_MAX) pot[i]+=dist[i];
            int flux=INT_MAX;
            for (int x=t; x!=s; x=dad[x]) {
                edge &e=v[dad[x]][dadedge[x]];
                flux=min(flux,e.cap);
            }
            for (int x=t; x!=s; x=dad[x]) {
                edge &e=v[dad[x]][dadedge[x]];
                e.cap-=flux;
                v[x][e.rez].cap+=flux;
                cost+=e.cost*flux;
            }
            flow+=flux;
        }
        return {flow,cost};
    }
};
int n,m,mc;
pii muchii[50005];
int main(){
    f>>n>>m>>mc;
    flux fl(603,601,602);
    for (int i=1; i<=n; ++i) {
        fl.add(601,i,1,0);
    }
    for (int i=1; i<=m; ++i) {
        fl.add(i+300,602,1,0);
    }
    for (int i=1; i<=mc; ++i) {
        f>>muchii[i].first>>muchii[i].second;
        int cost;
        f>>cost;
        fl.add(muchii[i].first,muchii[i].second+300,1,cost);
    }
    pii r=fl.fluxcost();
    g<<r.first<<' '<<r.second<<nl;
    for (int i=1; i<=mc; ++i) {
        if (fl.v[muchii[i].first][muchii[i].second].cap==0) {
            g<<i<<' ';
        }
    }
    system("pause");
    return 0;
}