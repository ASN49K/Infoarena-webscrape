#include <algorithm>
#include <bitset>
#include <queue>
#include <vector>
using namespace std;

#define DIM 701
#define INF 0x3f3f3f3f

int N, M, E, S, D;
int cuplaj, cost_cuplaj, t[ DIM ], val[ DIM ], cap[ DIM ][ DIM ], flx[ DIM ][ DIM ], ind[ DIM ][ DIM ];
bitset <DIM> f;
queue <int> q;
vector < pair <int, int> > v[ DIM<<1 ];

inline int bellman_ford() {

    int nod, fmin;
    vector < pair <int, int> > :: iterator it;

    f.reset();
    memset( t, 0, sizeof( t ) );
    memset( val, INF, sizeof( val ) );
    val[ S ] = 0;
    for( q.push( S ); !q.empty(); q.pop() ) {

        nod = q.front();
        f[ nod ] = 0;
        for( it = v[ nod ].begin(); it != v[ nod ].end(); ++it )
            if( cap[ nod ][ it->first ] > flx[ nod ][ it->first ] && val[ nod ] + it->second < val[ it->first ] ) {

                val[ it->first ] = val[ nod ] + it->second;
                t[ it->first ] = nod;
                if( !f[ it->first ] ) {

                    q.push( it->first );
                    f[ it->first ] = 1;
                }
            }
    }
    if( val[ D ] != INF ) {

        fmin = INF;
        for( nod = D; nod != S; nod = t[ nod ] )
            fmin = min( fmin, cap[ t[ nod ] ][ nod ] - flx[ t[ nod ] ][ nod ] );
        for( nod = D; nod != S; nod = t[ nod ] ) {

            flx[ t[ nod ] ][ nod ] += fmin;
            flx[ nod ][ t[ nod ] ] -= fmin;
        }

        return fmin * val[ D ];
    }

    return 0;
}

int main() {

    freopen( "cmcm.in", "r", stdin );
    freopen( "cmcm.out", "w", stdout );

    int i, j, c, x, y, ok;

    scanf( "%d %d %d", &N, &M, &E );
    for( i = 1; i <= E; ++i ) {

        scanf( "%d %d %d", &x, &y, &c );
        ++x;
        y += N+1;
        v[ x ].push_back( make_pair( y, c ) );
        cap[ x ][ y ] = 1;
        ind[ x ][ y ] = i;
        v[ y ].push_back( make_pair( x, -c ) );
    }

    S = 1;
    for( i = 2; i <= N+1; ++i ) {

        v[ S ].push_back( make_pair( i, 0 ) );
        cap[ S ][ i ] = 1;
        v[ i ].push_back( make_pair( S, 0 ) );
    }
    D = N+M+2;
    for( i = N+2; i <= N+M+1; ++i ) {

        v[ i ].push_back( make_pair( D, 0 ) );
        cap[ i ][ D ] = 1;
        v[ D ].push_back( make_pair( i, 0 ) );
    }
    ok = 1;
    while( ok ) {

        ok = bellman_ford();
        cost_cuplaj += ok;
    }
    for( i = 1; i <= N+1; ++i )
        for( j = N+2; j <= N+M+2; ++j )
            if( cap[ i ][ j ] && flx[ i ][ j ] ) {

                ++cuplaj;
                break;
            }

    printf( "%d %d\n", cuplaj, cost_cuplaj );
    for( i = 2; i <= N+1; ++i )
        for( j = N+2; j <= N+M+1; ++j )
            if( cap[ i ][ j ] && flx[ i ][ j ] ) {

                printf( "%d ", ind[ i ][ j ] );
                break;
            }

    return 0;
}
