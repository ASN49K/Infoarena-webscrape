#include <stdio.h>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstring>
#include <vector>
#include <deque>
#include <queue>
#include <set>
using namespace std;
#define inf 0xffffff
#define Max 750

vector<int>g[Max];
set<int>s1,s2;

int n,m,c[Max][Max],f[Max][Max],dst[Max],tt[Max],s,d,w[Max][Max],pr[Max][Max];

bool bfs()
{
	int x,y;
	s1.insert(s);
	for(int i=1;i<=d;i++)dst[i]=inf;
	dst[s]=0;
	memset(tt,0,sizeof(tt));
	for(int i=1;i<=n+m+2;i++)
	{
		while(s1.size()>0)
		{
			x=*s1.begin();
			s1.erase(s1.begin());
		for(int i=0;i<g[x].size();i++)
		{
			y=g[x][i];
			if(dst[y] > dst[x]+pr[x][y] && c[x][y] > f[x][y])
			{
				dst[y]=dst[x]+pr[x][y];
				tt[y]=x;
				if(y!=d)s2.insert(y);
			}
		}
		}
		swap(s1,s2);
	}
	return tt[d];
}

void maxflow()
{
	int flux_max=0,flux,cst_min=0;
	while( bfs() )
	{
		flux = inf;
		for(int x=d;x!=s;x=tt[x]) flux=min(flux,c[tt[x]][x]-f[tt[x]][x]);
		for(int x=d;x!=s;x=tt[x])
			{
				f[tt[x]][x]+=flux;
				f[x][tt[x]]-=flux;
				cst_min += flux * pr[tt[x]][x];
			}
			flux_max+=flux;
	}
	printf("%d %d\n",flux_max,cst_min);
	for(int i=2;i<=n+1;i++)
		for(int j=n+2;j<=n+m+1;j++)if(f[i][j]>0)printf("%d ",w[i][j]);
}

int main()
{
	int x,y,z,e;
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
		scanf("%d %d %d",&n,&m,&e);
		s=1; d=n+m+2;
		for(int i=1;i<=e;i++)
		{
			scanf("%d %d %d",&x,&y,&z);
			x++;
			y+=n+1;
			c[x][y]=1;
			pr[x][y]=z;
			pr[y][x]=-z;
			w[x][y]=i;
			g[x].push_back(y);
			g[y].push_back(x);
		if(c[s][x]==0)
		{
			g[s].push_back(x);
			g[x].push_back(s);
			c[s][x]=1;
		}
		if(c[y][d]==0)
		{
			g[y].push_back(d);
			g[d].push_back(y);
			c[y][d]=1;
		}
		}
		maxflow();
	return 0;
}
