#include <fstream>
#include <vector>
#include <queue>
#include <tuple>

#define pii pair<int,int>
#define fi first
#define se second

using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int const N = 1010 , M = 50001 , inf = 1e9;
int n , m , e , s , d , a , b , c , l , r;
pii mc[M];
int t[N] , dp[N] , dp2[N] , dst[N] , inq[N];
int q[5 * M];
int w[N][N] , f[N][N] , id[N][N];
vector<int> v[N];
void bellman(){
    fill(dst + 1 , dst + 1 + n , inf);
    dst[s] = 0;
    q[l = r = 1] = s;
    while(l <= r){
        int x = q[l++];
        for(int y : v[x]){
            if(f[x][y] && dst[y] > dst[x] + w[x][y]){
                dst[y] = dst[x] + w[x][y];
                if(!inq[y]){
                    inq[y] = 1;
                    q[++r] = y;
                }
            }
        }
        inq[x] = 0;
    }
}
priority_queue<pii> h;
bool dijkstra(){
    fill(dp + 1 , dp + 1 + d , inf);
    fill(dp2 + 1 , dp2 + 1 + d , inf);
    dp[s] = dp2[s] = 0;
    h.emplace(0 , s);
    while(!h.empty()){
        int x = h.top().se;
        int e = -h.top().fi;
        h.pop();
        if(e != dp[x])
            continue;
        for(int y : v[x]){
            if(f[x][y] && dp[y] > dp[x] - dst[y] + w[x][y] + dst[x]){
                dp[y] = dp[x] - dst[y] + w[x][y] + dst[x];
                dp2[y] = dp2[x] + w[x][y];
                t[y] = x;
                h.emplace(-dp[y] , y);
            }
        }
    }
    return dp[d] != inf;
}
int main(){
    fin >> n >> m >> e;
    for(int i = 1 ; i <= e ; ++ i){
        fin >> a >> b >> c;
        b += n;
        w[a][b] = c , w[b][a] = -c;
        mc[i] = {a , b};
        v[a].push_back(b);
        v[b].push_back(a);
        f[a][b] = 1;
    }
    s = n + m + 1 , d = s + 1;
    for(int i = 1 ; i <= n ; ++ i){
        v[s].push_back(i);
        v[i].push_back(s);
        f[s][i] = 1;
        w[s][i] = w[i][s] = 0;
    }
    for(int i = 1 ; i <= m ; ++ i){
        v[i + n].push_back(d);
        v[d].push_back(i + n);
        f[i + n][d] = 1;
        w[i + n][d] = w[d][i + n] = 0;
    }
    bellman();
    int match(0);
    while(dijkstra()){
        int x = d , u = 1;
        while(t[x] && u){
            if(!f[t[x]][x])
                u = 0;
            x = t[x];
        }
        if(!u)continue;
        ++match;
        x = d;
        while(t[x]){
            f[t[x]][x] = 0;
            f[x][t[x]] = 1;
            x = t[x];
        }
    }
    fout << match << ' ';
    int cost = 0;
    for(int i = 1 ; i <= m ; ++ i){
        tie(a , b) = mc[i];
        if(!f[a][b])
            cost += w[a][b];
    }
    fout << cost << '\n';
    for(int i = 1 ; i <= m ; ++ i){
        tie(a , b) = mc[i];
        if(!f[a][b])
            fout << i << ' ';
    }
    fout << '\n';
    return 0;
}
