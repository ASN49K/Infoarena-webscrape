#include<fstream>
#include<queue>
#include<cstring>
#define INF 0x3f3f3f3f
#define MAXN 602
#define des m+n+2
using namespace std;
int d[MAXN],n,m,f,e,viz[MAXN],p[MAXN],ver[MAXN][MAXN],fl[MAXN][MAXN],cost[MAXN][MAXN],solm,solc;
queue<int> q;
vector<int> v[MAXN];
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
void citire()
{
    int x,y,c;
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        fin>>x>>y>>c;
        x++; y=y+n+1;
        ver[x][y]=i;
        cost[x][y]=c;
        cost[y][x]=-c;
        fl[x][y]=1;
        v[x].push_back(y);
        v[y].push_back(x);
    }
}

int creeazaMuchii()
{
    //creez muchiile catre/de la sursa si destinatie
    for(int i=2;i<=n+1;i++)
    {
        v[1].push_back(i);
        v[i].push_back(1);
        fl[1][i]=1;
    }
    for(int i=n+2;i<des;i++)
    {
        v[i].push_back(des);
        v[des].push_back(i);
        fl[i][des]=1;
    }
}

int bellman()
{
    int nod;
    memset(d,INF,sizeof(d));
    d[1]=0;
    q.push(1);
    viz[1]=1;
    while(!q.empty())
    {
        nod=q.front();
        viz[nod]=0;
        q.pop();
        for(int i=0;i<v[nod].size();i++)
        {
            if(fl[nod][v[nod][i]] && d[v[nod][i]]>d[nod]+cost[nod][v[nod][i]])
            {
                d[v[nod][i]]=d[nod]+cost[nod][v[nod][i]];
                p[v[nod][i]]=nod;
                if(viz[v[nod][i]]==0)
                {
                    viz[v[nod][i]]=1;
                    q.push(v[nod][i]);
                }
            }
        }
    }
    return (d[des]!=INF);
}

int main()
{
    int minFlow;
    citire();
    creeazaMuchii();
    while(bellman())
    {
        minFlow=INF;
        for(int nod=des;nod!=1;nod=p[nod])
        {
            minFlow=min(minFlow,fl[p[nod]][nod]);
        }
        if(minFlow!=0)
            solm++;
        else continue;
        solc+=d[des];
        for(int nod=des;nod!=1;nod=p[nod])
        {
            fl[p[nod]][nod]-=minFlow;
            fl[nod][p[nod]]+=minFlow;
        }
    }
    fout<<solm<<" "<<solc<<"\n";
    for(int i=2;i<=n+1;i++)
    {
        for(int j=n+2;j<des;j++)
        {
            if(!fl[i][j] && ver[i][j])
                fout<<ver[i][j]<<" ";
        }
    }
    return 0;
}
