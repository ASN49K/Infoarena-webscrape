#include<bits/stdc++.h>
#define maxn 605
#define pb push_back
#define inf 0x3f3f3f3f
using namespace std;

vector<int> v[maxn],rez;
queue<int> q;
int indx[maxn][maxn],f[maxn][maxn],c[maxn][maxn],tt[maxn],cost[maxn],viz[maxn],flux,Cost,s,d,n,m,e,l;

void read(){
    int x,y,w;
     cin>>n>>m>>e;
     s=n+m+1;
     d=s+1;
     for(int i=1; i<=n; i++)
        v[s].pb(i),v[i].pb(s),f[s][i]=1;
     for(int i=n+1; i<=n+m; i++)
        v[d].pb(i),v[i].pb(d),f[i][d]=1;
     while(m--){
        cin>>x>>y>>w;
        y+=n;
        v[x].pb(y); v[y].pb(x);
        c[x][y]=w; c[y][x]=-w; f[x][y]=1;
        indx[x][y]=++l;
    }
}
void solve(){
    while(cost[d]!=inf){
        q.push(s);
        memset(cost,inf,sizeof(cost));
        cost[s]=0;
        while(!q.empty()){
            int nod=q.front();
            q.pop();
            viz[nod]=0;
            if(nod==d)
                continue;
            for(int i=0; i<v[nod].size(); i++){
                int dest=v[nod][i];
                if(cost[dest]<=cost[nod]+c[nod][dest]||f[nod][dest]==0)
                    continue;
                tt[dest]=nod;
                cost[dest]=cost[nod]+c[nod][dest];
                if(viz[dest]==0)viz[dest]=1,q.push(dest);
                }
        }
        if(cost[d]!=inf){
            for(int wh=d; wh!=s; wh=tt[wh]){
                if(wh==d)
                    rez.pb(indx[tt[tt[wh]]][tt[wh]]);
                f[tt[wh]][wh]-=1;
                f[wh][tt[wh]]+=1;
            }
                Cost+=cost[d];
                flux+=1;
            }
        }
        cout<<flux<<' '<<Cost<<'\n';
        while(rez.size())
                cout<<rez.back()<<' ',rez.pop_back();
   }
    int main(){
        freopen("cmcm.in","r",stdin);
        freopen("cmcm.out","w",stdout);
        ios_base::sync_with_stdio(0);
        cin.tie(0);
        read();
        solve();
        return 0;
}
