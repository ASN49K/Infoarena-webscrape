#include <fstream>
#include <vector>
#include <queue>
#include <string.h>
#define nMax 610
#define S 0
#define D 605
#define INF 0x3f3f3f3f
#define pb push_back
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int L, R, m, flow, flowCost, C[nMax][nMax], Cost[nMax][nMax], Nr[nMax][nMax], F[nMax][nMax], dist[nMax], viz[nMax], TT[nMax];
vector<int> G[nMax];
queue<int> Q;
void read()
{
    int x, y, z;
    fin>>L>>R>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y>>z;
        y+=L;
        G[x].pb(y);
        G[y].pb(x);
        C[x][y]=1;
        Cost[x][y]=z;
        Cost[y][x]=-z;
        Nr[x][y]=i;
    }
    for(int i=1;i<=L;i++)
    {
        G[S].pb(i);
        G[i].pb(S);
        C[S][i]=1;
    }
    for(int i=L+1;i<=L+R;i++)
    {
        G[D].pb(i);
        G[i].pb(D);
        C[i][D]=1;
    }
}
inline bool bellman_ford()
{
    memset(dist, INF, sizeof(dist));
    dist[S]=0;
    for(Q.push(S);!Q.empty();Q.pop())
    {
        int node=Q.front();
        viz[node]=0;
        for(vector<int>::iterator it=G[node].begin();it!=G[node].end();it++)
        {
            int fiu=*it;
            if(C[node][fiu]==F[node][fiu])
                continue;
            if(dist[node]+Cost[node][fiu]<dist[fiu])
            {
                dist[fiu]=dist[node]+Cost[node][fiu];
                TT[fiu]=node;
                if(viz[fiu]==0)
                {
                    viz[fiu]=1;
                    Q.push(fiu);
                }
            }
        }
    }
    if(dist[D]==INF)
        return 0;
    return 1;
}
void solve()
{
    while(bellman_ford())
    {
        int Min=INF;
        for(int aux=D;aux!=S;aux=TT[aux])
            Min=min(Min, C[TT[aux]][aux]-F[TT[aux]][aux]);
        for(int aux=D;aux!=S;aux=TT[aux])
        {
            F[TT[aux]][aux]+=Min;
            F[aux][TT[aux]]-=Min;
        }
        flow+=Min;
        flowCost+=Min*dist[D];
    }
}
void write()
{
    fout<<flow<<" "<<flowCost<<'\n';
    for(int i=1;i<=L;i++)
        for(int j=L+1;j<=L+R;j++)
            if(C[i][j]&&F[i][j])
                fout<<Nr[i][j]<<" ";
}
int main()
{
    read();
    solve();
    write();
    return 0;
}
