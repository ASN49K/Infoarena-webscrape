#include <bits/stdc++.h>
#include <iostream>
#define dim 699
#define inf 2000000000
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
bitset  <dim> fr;
deque <int> q;
int d[dim],t[dim];
vector <int> L[dim];
map < pair<int,int>, int > mp;

/// -------------------- ///

int l,r,C[dim][dim],cost[dim][dim],F[dim][dim],m,i,j,x,y,z,aux,flux,solutie,minim;
bool bf()
{
    int i,nod,vecin;
    fr.reset();
    q.clear();
    for(int i=0; i<=l+r+2; i++)
        d[i]=inf;
    d[0]=0;
    q.push_back(0);
    fr[0]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop_front();
        for(int i=0; i<L[nod].size(); i++)
        {
            vecin=L[nod][i];
            if(C[nod][vecin]>F[nod][vecin]&& d[vecin]>d[nod]+cost[nod][vecin])
            {
                d[vecin]=d[nod]+cost[nod][vecin];
                t[vecin]=nod;
                if(fr[vecin]==0)
                {
                    fr[vecin]=1;
                    q.push_back(vecin);
                }
            }
        }


    }
    return fr[l+r+1];

}
int main()
{
    fin>>l>>r>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>z;
        L[x].push_back(y+l);
        L[y+l].push_back(x);
        cost[x][y+l]=z;
        cost[y+l][x]=-z;
        C[x][y+l]=1;
        mp[ {x,y+l}]=i;
    }
    for(i=1; i<=l; i++)
    {
        L[0].push_back(i);
        L[i].push_back(0);
        C[0][i]=1;
    }
    for(i=l+1; i<=l+r; i++)
    {
        L[i].push_back(l+r+1);
        L[l+r+1].push_back(i);
        C[i][l+r+1]=1;
    }
    while(bf())
    {
        aux=l+r+1;
        minim=inf;
        while(aux!=0){
            minim=min(minim,C[t[aux]][aux]-F[t[aux]][aux]);
            aux=t[aux];
        }
        aux=l+r+1;
        while(aux!=0)
        {
            F[t[aux]][aux]++;
            F[aux][t[aux]]--;
            solutie+=cost[t[aux]][aux];
            aux=t[aux];
        }
        flux+=minim;
    }
    fout<<flux<<" "<<solutie<<"\n";
    for(i=1; i<=l; i++)
        for(j=l+1; j<=l+r; j++)
            if(F[i][j])
            {
                fout<<mp[ {i,j}]<<" ";
            }
}
