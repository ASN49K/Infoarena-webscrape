#include <bits/stdc++.h>
#define pii pair<int, int>
#define inf 1000000001
///N=M=300
///E=50000
///-20000<=C<=20000
using namespace std;
int n, m, e, i, j, k, sol, s, d;
int cost[602][602], flow[602][602], then[602], now[602], last[602], dmin[602];
vector<int> graph[602], out;
priority_queue<pii, vector<pii>, greater<pii> > pq;
vector<pii> edges;
///
void read();
void solve();
void write();
bool dij();
int main()
{
    read();
    solve();
    write();
    return 0;
}
void read(){
    freopen("cmcm.in", "r", stdin);
    scanf("%d%d%d", &n, &m, &e);
    for(i=1; i<=e; ++i){
        int x, y, c;
        scanf("%d%d%d", &x, &y, &c);
        graph[x].push_back(y+n);
        graph[y+n].push_back(x);
        cost[x][y+n]=c;
        cost[y+n][x]=-c;
        flow[x][y+n]=1;
        edges.push_back({x, y+n});
    }
    fclose(stdin);
    return;
}
void solve(){
    s=0; d=n+m+1;
    for(i=1; i<=n; ++i) {
        flow[s][i]=1;
        graph[s].push_back(i);
        graph[i].push_back(s);
    }
    for(i=n+1; i<=n+m; ++i) {
        flow[i][d]=1;
        graph[i].push_back(d);
        graph[d].push_back(i);
    }
    while(dij()){
        int p, maxflow=inf;
        for(p=d; p!=s; p=last[p]) maxflow=min(maxflow, flow[last[p]][p]);
        for(p=d; p!=s; p=last[p]){
            flow[last[p]][p]-=maxflow;
            flow[p][last[p]]+=maxflow;
            sol+=cost[last[p]][p];
        }
    }
    for(i=0; i<edges.size(); ++i) if(!flow[edges[i].first][edges[i].second]) out.push_back(i+1);
    return;
}
void write(){
    freopen("cmcm.out", "w", stdout);
    printf("%d %d\n", out.size(), sol);
    for(auto i:out) printf("%d ", i);
    return;
}
bool dij(){
    for(i=s; i<=d; ++i) dmin[i]=inf, last[i]=-1;
    dmin[0]=now[0]=0;
    pq.push({0, 0});
    while(!pq.empty()){
        int cst=pq.top().first, node=pq.top().second; pq.pop();
        if(node==d) continue;
        if(cst>dmin[node]) continue;
        for(auto next:graph[node]){
            if(!flow[node][next]) continue;
            int nextc=cst+cost[node][next]+then[node]-then[next];
            if(nextc<dmin[next]){
                dmin[next]=nextc;
                last[next]=node;
                now[next]=now[node]+cost[node][next];
                pq.push({nextc, next});
            }
        }
    }
    for(i=s; i<=d; ++i) then[i]=now[i];
    return dmin[d]!=inf;
}
