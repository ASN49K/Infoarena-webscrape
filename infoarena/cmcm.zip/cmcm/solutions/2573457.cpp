#include <bits/stdc++.h>
#define DIM 650
#define inf INT_MAX
using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int l,r,m,s,d,i,j,x,y,z,nod,vecin,fluxmin,costsol,fluxsol;
int cap[DIM][DIM],t[DIM],dist[DIM],c[DIM][DIM],flux[DIM][DIM],muchie[DIM][DIM];
bitset<DIM> f;
vector<int> L[DIM];
deque<int> q;
bool bf() {
    f.reset();
    for (int i=1;i<=d;i++)
        dist[i]=inf;
    q.clear();
    dist[s]=0, f[s]=1;
    q.push_back(s);
    while (!q.empty()) {
        nod=q.front();
        q.pop_front();
        f[nod]=0;
        for (auto vecin:L[nod]) {
            if (dist[vecin]>dist[nod]+c[nod][vecin]&&cap[nod][vecin]>flux[nod][vecin]) {
                dist[vecin]=dist[nod]+c[nod][vecin];
                t[vecin]=nod;
                if (f[vecin]==0) {
                    q.push_back(vecin);
                    f[vecin]=1;
                }
            }
        }
    }
    if (dist[d]!=inf)
        return true;
    else
        return false;
}
int main() {
    fin>>l>>r>>m;
    s=0, d=l+r+1;
    for (i=1;i<=m;i++) {
        fin>>x>>y>>z;
        L[x].push_back(l+y);
        L[l+y].push_back(x);
        c[x][l+y]=z;
        c[l+y][x]=-z;
        cap[x][l+y]=1;
        muchie[x][l+y]=i;
    }
    for (i=1;i<=l;i++) {
        L[s].push_back(i);
        L[i].push_back(s);
        cap[s][i]=1;
    }
    for (i=1;i<=r;i++) {
        L[d].push_back(l+i);
        L[l+i].push_back(d);
        cap[l+i][d]=1;
    }
    while (bf()) {
        nod=d;
        fluxmin=inf;
        while (nod!=s) {
            fluxmin=min(fluxmin,cap[t[nod]][nod]-flux[t[nod]][nod]);
            nod=t[nod];
        }
        nod=d;
        while (nod!=s) {
            flux[t[nod]][nod]+=fluxmin;
            flux[nod][t[nod]]-=fluxmin;
            nod=t[nod];
        }
        costsol+=fluxmin*dist[d];
        fluxsol+=fluxmin;
    }
    fout<<fluxsol<<" "<<costsol<<"\n";
    for (i=1;i<=l;i++)
        for (j=l+1;j<=l+r;j++)
            if (flux[i][j]==1)
                fout<<muchie[i][j]<<" ";
    return 0;
}
