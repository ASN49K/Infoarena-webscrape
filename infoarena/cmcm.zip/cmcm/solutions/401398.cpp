#include<stdio.h>
#include<vector>
#include<algorithm>
#define INF 1000001
#define Nmx 605
#define pb push_back
#define mp make_pair


using namespace std;

int n,m,T,dest,prec[Nmx],dist[Nmx],viz[Nmx];
int C[Nmx][Nmx],F[Nmx][Nmx],Cost[Nmx][Nmx];
int cupl=0,sol=0;
vector < int > G[Nmx];


void citire()
{
    freopen("cmcm.in","r",stdin);
    scanf("%d%d%d",&n,&m,&T);
    dest=n+m+2;
    int x,y,c;
    for(int i=1;i<=T;++i)
    {
        scanf("%d%d%d",&x,&y,&c);
        x++;y=y+n+1;
        C[x][y]=C[1][x]=C[y][dest]=1;
        Cost[x][y]=c;Cost[1][x]=Cost[x][1]=Cost[y][dest]=Cost[dest][y]=0;

        Cost[y][x]=-c;
        G[x].pb(1);G[1].pb(x);
        G[x].pb(y);G[y].pb(x);
        G[y].pb(dest);G[dest].pb(y);
    }
}

int belmand()
{
    vector<int>:: iterator it;
    int Q[Nmx*Nmx],st,dr;
    st=dr=1;
    for(int i=1;i<=dest;++i)
        dist[i]=INF;
    dist[1]=0;
    Q[1]=1;
    while(st<=dr)
    {
        for(it=G[Q[st]].begin();it!=G[Q[st]].end();++it)
            if(C[Q[st]][*it]-F[Q[st]][*it]>0&&dist[Q[st]]+Cost[Q[st]][*it]<dist[*it])
            {
                dist[*it]=dist[Q[st]]+Cost[Q[st]][*it];
                prec[*it]=Q[st];
                if(!viz[*it])
                {
                    viz[*it]=1;
                    Q[++dr]=*it;
                }
            }
        viz[Q[st++]]=0;
    }
    if(dist[dest]!=INF)
        return 1;
    return 0;
}

void flux()
{

    while(belmand())
    {
        int Vmin=INF;
        for(int i=dest;i!=1;i=prec[i])
            Vmin=min(Vmin,C[prec[i]][i]-F[prec[i]][i]);
        for(int i=dest;i!=1;i=prec[i])
        {
            F[prec[i]][i]+=Vmin;
            F[i][prec[i]]-=Vmin;
        }
        if(Vmin)
        {
            ++cupl;
            sol+=dist[dest];
        }
    }
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&n,&m,&T);
    int x,y,c;
    printf("%d %d\n",cupl,sol);
    for(int i=1;i<=T;++i)
    {
        scanf("%d%d%d",&x,&y,&c);
        if(F[x+1][y+n+1])
        {
            printf("%d ",i);
        }
    }
    printf("\n");
}


int main()
{
    citire();
    flux();
    return 0;
}
