# include <algorithm>
# include <cstdio>
# include <cstring>
# include <vector>
# include <queue>
using namespace std;

# define x first
# define y second

const char *FIN = "cmcm.in", *FOU = "cmcm.out";
const int MAX = 605, oo = 0x3f3f3f3f;

vector < pair <int, int> > G[MAX];
pair <int, int> MC[MAX];
int C[MAX][MAX], F[MAX][MAX], dp[MAX], T[MAX], viz[MAX];
int E, N, M, S, D;
int Nr, cm;

struct comp {
    bool operator () (const int &A, const int &B) {
        return dp[A] > dp[B];
    }
};

priority_queue < int, vector <int>, comp > Q ;

inline void getmin (int &a, int b) {
    a = a < b ? a : b;
}

inline int dijkstra (void) {
    memset (T, 0, sizeof (T)), memset (viz, 0, sizeof (viz)), memset (dp, oo, sizeof (dp));
    dp[S] = 0;
    for (Q.push (S); !Q.empty ();) {
        int X = Q.top(); viz[X] = 0; Q.pop ();
        for (vector < pair <int, int> > :: iterator it = G[X].begin (); it != G[X].end (); ++it)
            if (dp[X] + it -> y < dp[it -> x] && C[X][it -> x] != F[X][it -> x]) {
                dp[it -> x] = dp[X] + it -> y, T[it -> x] = X;
                if (viz[it -> x] == 0)
                    viz[it -> x] = 1, Q.push (it -> x);
            }
    }
    return dp[D] != oo;
}

int main (void) {
    freopen (FIN, "r", stdin);

    scanf ("%d %d %d", &N, &M, &E);
    for (int i = 1, x, y, z; i <= E; ++i) {
        scanf ("%d %d %d", &x, &y, &z);
        MC[i] = make_pair (x, y), C[x][y += N] = 1;
        G[x].push_back (make_pair (y, +z));
        G[y].push_back (make_pair (x, -z));
    }
    S = 0, D = N + M + 1;
    for (int i = 1; i <= N; ++i) {
        G[S].push_back (make_pair (i, 0));
        G[i].push_back (make_pair (S, 0));
        C[S][i] = 1;
    }
    for (int i = 1; i <= M; ++i) {
        G[i + N].push_back (make_pair (D, 0));
        G[D].push_back (make_pair (i + N, 0));
        C[i + N][D] = 1;
    }
    for (int fmin = 0; dijkstra (); Nr += fmin, cm += fmin * dp[D]) {
        fmin = oo;
        for (int i = D; i != S; i = T[i])
            getmin (fmin, C[T[i]][i] - F[T[i]][i]);
        for (int i = D; i != S; i = T[i])
            F[T[i]][i] += fmin, F[i][T[i]] -= fmin;
    }

    freopen (FOU, "w", stdout);
    printf ("%d %d\n", Nr, cm);
    for (int i = 1; i <= E; ++i)
        if (F[MC[i].x][MC[i].y + N]) printf ("%d ", i);
}
