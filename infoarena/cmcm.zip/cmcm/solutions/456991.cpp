/*
 * File:   main.cpp
 * Author: virtualdemon
 *
 * Created on May 17, 2010, 7:16 AM
 */
#include <queue>
#include <fstream>
#include <cstdlib>
#define Nmax 811
#define oo 1<<30

/*
 *
 */
using namespace std;
struct vertex
{
    int x, c, f, cost, idx;
    vertex *next, *back;
    vertex( void ) : x(0), c(0), f(0), cost(oo), idx(0), next(NULL), back(NULL) { }
} *G[Nmax], *fp[Nmax];
int N, M, E, source, sink=799;
int d[Nmax];
bool was[Nmax];
inline void Add( int x, int y, int cost, int cost2, int idx=0 )
{
    vertex *q=new vertex, *qq=new vertex;
    q->x=x;               qq->x=y;
    q->idx=idx;           qq->idx=idx;
    q->cost=cost2;        qq->cost=cost;
                          qq->c=1;
    q->next=G[y];         qq->next=G[x];
    G[y]=q;               G[x]=qq;
    G[y]->back=G[x];      G[x]->back=G[y];
}
queue< int > pQ;
inline bool find_path( void )
{
    int x;
    vertex* p;
    for( x=1; x <= E; ++x )
        d[x]=oo, was[x]=false;
    d[sink]=oo;
    d[source]=0;
    was[sink]=false;
    was[source]=true;
    for( pQ.push(source); !pQ.empty();  )
    {
        x=pQ.front(); pQ.pop();
        was[x]=false;
        for( p=G[x]; p; p=p->next )
        {
            if( source == p->x )
                continue;
            if( ( p->c - p->f ) > 0 && d[x]+p->cost < d[p->x] )
            {
                fp[p->x]=p;
                d[p->x]=d[x]+p->cost;
                if( !was[p->x] )
                {
                    pQ.push(p->x);
                    was[p->x]=true;
                }
            }
        }
    }
    return oo != d[sink];
}
int main( void )
{
    vertex* p;
    int x, y, c, i;
    ifstream in( "cmcm.in" );
    in>>N>>M>>E;
    for( i=1; i <= E; ++i )
    {
        in>>x>>y>>c;
        y+=N+1;
        Add( x, y, c, -c, i );
        if( !was[x] )
            Add( source, x, 0, 0 ), was[x]=true;
        if( !was[y] )
            Add( y, sink, 0, 0 ), was[y]=true;
    }
    E=N+M+1;
    for( x=y=0; find_path(); ++x, y+=d[sink] )
    {
        for( p=fp[sink]; p; p=fp[p->back->x] )
            ++p->f, --p->back->f;
    }
    ofstream out( "cmcm.out" );
    out<<x<<' '<<y<<'\n';
    for( c=1; x && c <= N; ++c )
    {
        for( p=G[c]; p; p=p->next )
            if( p->f > 0 )
            {
                --x;
                out<<p->idx<<' ';
                break;
            }
    }
    return EXIT_SUCCESS;
}
