#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <bitset>
#include <cstring>

#define INF 0x3f3f3f3f
#define Nmax 615
#define DIM 666013

#define super_start 606
#define super_sink 607

using namespace std;

char buffer[DIM];
int poz = DIM -1;
int nr = -1; /// nredge

struct edge{
    int a,b;
    int cost;
    int capacity;
    int flow;
    edge(){
        a = b = cost = capacity = flow = 0;
    }
    edge(int from,int to,int cost,int capacity,int flow)
    {
        this->a = from;
        this->b = to;
        this->cost = cost;
        this->capacity = capacity;
        this->flow = flow;
    }
}E[120000];

int L,R,M,daddy[Nmax],DP[Nmax];
vector<int>G[Nmax];
bitset<Nmax> inQ;
queue<int>Q;

void Insert(int from,int to,int cst,int capac,int flux)
{
    ++nr;
    E[nr] = edge(from,to,cst,capac,flux);
    G[from].push_back(nr);
}

void citeste(int &A)
{
    A = 0;
    int sgn = 1;
    while(('0' > buffer[poz] || buffer[poz] > '9') && buffer[poz] != '-')
        if(++poz == DIM) fread(buffer,1,DIM,stdin),poz = 0;
    while('0' <= buffer[poz] && buffer[poz] <= '9' || buffer[poz] == '-')
    {
        if(buffer[poz] == '-')
            sgn *= -1;
        else
            A = A * 10 + buffer[poz] - 48;
        if(++poz == DIM) fread(buffer,1,DIM,stdin),poz = 0;
    }
    A *= sgn;
}
void read( void )
{
    citeste(L),citeste(R),citeste(M);
    int a,b,c;
    for(int i = 1; i <= M; ++i){
        citeste(a),citeste(b),citeste(c);
        Insert(a,b+L,c,1,0);
        Insert(b+L,a,-c,0,0);
    }
    for(int i = 1; i <= L; ++i)
    {
        Insert(super_start,i,0,1,0);
        Insert(i,super_start,0,0,0);
    }
    for(int i = 1; i <= R; ++i)
    {
        Insert(i + L,super_sink,0,1,0);
        Insert(super_sink,i+L,0,0,0);
    }
}

bool bellman_ford(int k)
{
    memset(DP,INF,sizeof(DP));
    DP[k] = 0;
    inQ[k] = 1;
    Q.push(k);
    while(!Q.empty())
    {
        k = Q.front(); Q.pop();inQ[k] = 0;
        if(k == super_sink) continue;
        for(vector<int>::iterator it = G[k].begin(); it != G[k].end(); ++it)
            if(DP[E[*it].b] > DP[k] + E[*it].cost && E[*it].capacity != E[*it].flow)
            {
                DP[E[*it].b] = DP[k] + E[*it].cost;
                daddy[E[*it].b] = *it;
                if(inQ[E[*it].b]) continue;
                inQ[E[*it].b] = 1;
                Q.push(E[*it].b);
            }
    }
    return (DP[super_sink] != INF);
}
int minFLOW,maxFLOW = 0,minCOST = 0;

void FLOW(int k)
{
    while(bellman_ford(super_start))
    {
        minFLOW = INF;
        for(int nodc = super_sink; nodc != super_start; nodc = E[daddy[nodc]].a)
            minFLOW = min(minFLOW, E[daddy[nodc]].capacity - E[daddy[nodc]].flow);
        if(!minFLOW) continue;
        for(int nodc = super_sink; nodc != super_start; nodc = E[daddy[nodc]].a)
        {
            E[daddy[nodc]].flow += minFLOW;
            E[daddy[nodc]^1].flow -= minFLOW;
        }
        maxFLOW += minFLOW;
        minCOST += minFLOW * DP[super_sink];
    }
}

void print( void )
{
    printf("%d %d\n",maxFLOW,minCOST);
    for(int i = 0; i <= 2*(M-1); ++i)
        if(E[i].flow == 1)
            printf("%d ",(i/2) + 1 );
}

int main()
{
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);

    read();
    FLOW(super_start);
    print();

    return 0;
}
