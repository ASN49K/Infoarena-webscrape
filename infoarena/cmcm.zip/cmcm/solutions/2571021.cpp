#include <bits/stdc++.h>

using namespace std;

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int N,flux_maxim,cost_min,tata[310],indM[310][310],cost[310][310],flux[310][310],C[310][310],dist[310],min_dist[310],new_dist[310];
queue <int> q;
priority_queue < pair <int,int> , vector <pair <int,int > >, greater < pair <int,int > > > h;
vector <int> v[310],sol;

void Bellman_Ford()
{
    int i;

    for(i=0;i<=N;i++)dist[i]=INT_MAX/2;
    q.push(0);
    dist[0]=0;

    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(int i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            if(flux[nod][vecin] < C[nod][vecin] && dist[vecin]>dist[nod]+cost[nod][vecin])
            {
                dist[vecin]=dist[nod]+cost[nod][vecin];
                q.push(vecin);
            }
        }
    }
}

int Dijkstra()
{
    int i,nod;
    for(i=0;i<=N;i++)min_dist[i]=INT_MAX/2,tata[i]=-1;

    min_dist[0]=0;new_dist[0]=0;
    h.push({0,0});

    while(!h.empty())
    {
        int nod=h.top().second;
        if(min_dist[nod] < h.top().first){h.pop();continue;}
        else h.pop();

        for(i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            int dist_intre = cost[nod][vecin] + dist[nod] - dist[vecin];
            if(flux[nod][vecin] < C[nod][vecin] && min_dist[vecin] > min_dist[nod] + dist_intre)
            {
                min_dist[vecin]=min_dist[nod]+dist_intre;
                new_dist[vecin]=new_dist[nod]+cost[nod][vecin];
                h.push({min_dist[vecin],vecin});
                tata[vecin]=nod;
            }
        }
    }

    if(min_dist[N]==INT_MAX/2)return 0;

    int flux_min=1; /// asta e mereu 1 :)

    flux_maxim+=flux_min;
    cost_min+=flux_min*new_dist[N];

    nod=N;
    while(tata[nod]!=-1)
    {
        flux[tata[nod]][nod]+=flux_min;
        flux[nod][tata[nod]]-=flux_min;
        nod=tata[nod];
    }

    for(i=0;i<=N;i++)dist[i]=new_dist[i];

    return 1;
}

int n,m,E,j,i,x,y,mch_cost;
int main()
{
    f>>n>>m>>E;
    for(i=1;i<=E;i++)
    {
        f>>x>>y>>mch_cost;
        y=y+n;
        v[x].push_back(y);
        v[y].push_back(x);

        indM[x][y]=indM[y][x]=i;

        C[x][y]=1;
        cost[x][y]=mch_cost;cost[y][x]=-mch_cost;
    }

    for(i=1;i<=n;i++)
    {
        v[0].push_back(i);
        v[i].push_back(0);
        C[0][i]=1;
    }

    for(i=n+1;i<=n+m;i++)
    {
        v[i].push_back(n+m+1);
        v[n+m+1].push_back(i);
        C[i][n+m+1]=1;
    }

    N=n+m+1;
    Bellman_Ford();
    while(Dijkstra());

    g<<flux_maxim<<" "<<cost_min<<'\n';

    for(i=1;i<=n;i++)
    {
        for(j=0;j<v[i].size();j++)
            if(flux[i][v[i][j]]==1)g<<indM[i][v[i][j]]<<" ";
    }
    return 0;
}
