// Cuplaj maxim de cost minim - O(N*M^2*LogN)
// Bellman + Dijkstra
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
#include <bitset>
#define Nmax 605 //2 * N_max
#define oo 2000000000
#define pb push_back
#define x first
#define y second
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");

int L,R,N,M,Source,Sink,x,y,c,z,MaxFlow,CostMin,st[Nmax],dr[Nmax];
int nr[Nmax][Nmax],ante[Nmax],d[Nmax],old_d[Nmax],real_d[Nmax];
short cap[Nmax][Nmax],cost[Nmax][Nmax],flow[Nmax][Nmax];
vector < int > G[Nmax],sol;

queue < int > Q;
bitset < Nmax > inQ;

typedef pair<int,int> PP;
priority_queue < PP  , vector < PP > , greater<PP> > pq;


int Bellman(int Source)
{
    for(int i=1;i<=N;++i)old_d[i]=oo;
    old_d[Source]=0 , inQ[Source]=1;
    for(Q.push(Source); !Q.empty();Q.pop())
    {
        int node=Q.front();
        inQ[node]=0;
        for(vector<int>::iterator it=G[node].begin();it!=G[node].end();++it)
            if(d[*it]>d[node]+cost[node][*it] && flow[node][*it]<cap[node][*it])
            {
                old_d[*it]=old_d[node]+cost[node][*it];
                if(!inQ[*it]) Q.push(*it) , inQ[*it]=1;
            }
    }
}

int Dijkstra(int Source)
{
    for(int i=0;i<=N;++i)d[i]=oo,ante[i]=oo;
    d[Source]=0 , ante[Source]=Source;
    for(pq.push(PP(0,Source)); !pq.empty();)
    {
        int  val=pq.top().x,node=pq.top().y;
        pq.pop();
        if(d[node]!=val)continue;
        for(vector<int>::iterator it=G[node].begin();it!=G[node].end();++it)
            if(flow[node][*it]<cap[node][*it])
            {
                int new_d=d[node]+cost[node][*it]+old_d[node]-old_d[*it];
                if(new_d<d[*it])
                {
                    d[*it]=new_d , ante[*it] = node;
                    real_d[*it]=real_d[node]+cost[node][*it];
                    pq.push( PP(d[*it] , *it) );
                }
            }
    }
    for(int i=0;i<=N;++i)old_d[i]=real_d[i];
    return (d[Sink]!=oo);
}

void GetCMCM()
{
    for( ; Dijkstra(Source) ; )
    {
            for(int i=Sink; i!=Source ; i=ante[i])
            {
                ++flow[ante[i]][i];
                --flow[i][ante[i]];
                if(flow[ante[i]][i]>0)st[ante[i]]=i;
                 else if(flow[ante[i]][i]==0)st[ante[i]]=0;
            }
            CostMin+=real_d[Sink];//++MaxFlow;
    }
    for(int i=1;i<=L;++i)
        if(st[i]) sol.pb(nr[i][st[i]]);
    g<<sol.size()<<' '<<CostMin<<'\n';
    for(vector<int>::iterator it=sol.begin();it!=sol.end();++it)
        g<<*it<<' ';
    g<<'\n';
}

int main()
{
    f>>L>>R>>M;
    for(int i=1;i<=M;++i)
        {
            f>>x>>y>>z;
            y+=L;
            G[x].pb(y) , G[y].pb(x);
            cap[x][y]=1;
            cost[x][y]=z , cost[y][x]=-z;
            nr[x][y]=i;
        }
    N=L+R+1;
    Source=0 , Sink=N;
    for(int i=1;i<=L;++i)
    {
        G[Source].pb(i) , G[i].pb(Source);
        cap[Source][i]=1;
    }
    for(int j=L+1;j<=L+R;++j)
    {
        G[j].pb(Sink) , G[Sink].pb(j);
        cap[j][Sink]=1;
    }
    GetCMCM();
    f.close();g.close();
    return 0;
}
