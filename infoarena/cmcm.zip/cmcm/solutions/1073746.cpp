#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
#include <queue>

#define NMAX 305
#define INF 0x3f3f3f3f

using namespace std;

ifstream in ( "cmcm.in" );
ofstream out ( "cmcm.out" );

typedef vector < int > ::iterator IT;
vector < int > G[NMAX];
int Pos[NMAX][NMAX], F[NMAX][NMAX] , C[NMAX][NMAX] , cost[NMAX][NMAX] , TT[NMAX] , dist[NMAX] , Solution , Answer ;
bool used[NMAX];
queue < int > Q;
int N , M , E , P , Q , C , Source , Dest , Solution;


bool BellmanFord ( void )
{
	memset( dist , INF , sizeof(dist) );
	Q.push( Source );
	used[ Source ] = true ;
	while ( !Q.empty() )
	{
		int node = Q.front() ; 
		Q.pop() , used[node] = false ;
		for ( IT it = G[node].begin() ; it != G[node].end() ; ++it )
		{
			if ( F[node][*it] < C[node][*it] )
			{
			int cost = dist[node] + Cost[node][*it];
                if ( cost < dist[*it] )
				{
					dist[*it] = cost ;
					TT[*it] = node;
					if ( !used[*it] )
						used[*it] = true , Q.push(*it);
				}
			}
		}
	}
	return ( dist[Dest] != INF );
}

int main ( void )
{
	int i , j ;
	in >> N >> M >> E ;
	Source = 0 ;
	Dest = N + M + 1;
	for ( i = 1 ; i <= E ; ++i )
	{
		in >> P >> Q >> C ;
		Q += N;
		G[P].push_back(Q);
		G[Q].push_back(P);
		C[P][Q]  = 1 ;
		Cost[P][Q] = C , Cost[Q][P] = -C;
		Pos[P][Q] = i ;
	}
	for ( i = 1 ; i <= N ; ++i )
		G[Source].push_back( i ) , C[Source][i] = 1;
	for ( i = N + 1 ; i <= Dest ; ++i )
		G[i].push_back( Dest ) , C[i][Dest] = 1;
	for ( ; BellmanFord(); )
	{
	    for ( i = Dest ; i != Source ; i = TT[i] )
         ++F[TT[x]][x] , --F[x][TT[x]];
        ++Solution;		
        Answer += Dist[Dest];		
	}
	out << Solution << " " <<  Answer << "\n";
	for ( i = 1 ; i <= N ; ++i )
		for ( j = N + 1 ; j <= Dest - 1 ; ++j )
			if ( F[i][j] = 1 )
				out << Pos[i][j] << "\n";
	in.close();
	out.close();
	return 0;
}