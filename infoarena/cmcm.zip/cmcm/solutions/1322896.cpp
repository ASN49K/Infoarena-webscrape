#include<fstream>
#include<queue>
#include<vector>
#include<cstring>

#define MAXN 605
#define INF 10000001
#define VAL 301

using namespace std;
typedef int var;

ifstream fin("cmcm.in");
ofstream fout("cmcm.out");

struct Edge {var n, i; Edge(var a, var b) {n = a; i = b;}};

var src, dest, n, m;
vector<Edge> G[MAXN];
var C[MAXN][MAXN], F[MAXN][MAXN], K[MAXN][MAXN];



bool INQ[MAXN];
bool ADDED[MAXN];
var COST[MAXN], PARENT[MAXN];
queue<var> Q;
void reset() {
    for(var i=1; i<=n; i++) {PARENT[i] = 0; COST[i] = INF;}
    for(var i=1; i<=m; i++) {PARENT[i+VAL] = 0; COST[i+VAL] = INF;}
    PARENT[dest] = PARENT[src] = 0;
    COST[dest] = COST[src] = INF;
}
bool bellman() {
    Q.push(src);
    reset();
    COST[src] = 0;
    while(!Q.empty()) {
        var node = Q.front();
        INQ[node] = 0;
        Q.pop();
        for(vector<Edge>::iterator it = G[node].begin(); it != G[node].end(); ++it) {
            var vec = (*it).n;
            if(COST[vec] > COST[node] + K[node][vec] && F[node][vec] < C[node][vec]) {
                COST[vec] = COST[node] + K[node][vec];
                PARENT[vec] = node;
                if(INQ[vec] == 0) {
                    Q.push(vec);
                }
                INQ[vec] = 1;
            }
        }
    }
    return PARENT[dest] != 0;
}
var cuplaj() {
    var total = 0;
    var MIN;
    while(bellman()) {
        for(var i = dest; PARENT[i]; i = PARENT[i]) {
            MIN = min(MIN, C[PARENT[i]][i] - F[PARENT[i]][i]);
        }
        for(var i = dest; PARENT[i]; i = PARENT[i]) {
            F[PARENT[i]][i] ++;
            F[i][PARENT[i]] --;
            total += K[PARENT[i]][i];
        }
    }
    return total;
}
void addEdge(var a, var b, var k, var i) {
    K[a][b] = k;
    K[b][a] = -k;
    C[a][b] = 1;
    G[a].push_back(Edge(b, i));
    G[b].push_back(Edge(a, i));
}
void citire() {
    var e, a, b, k;
    fin>>n>>m>>e;
    src = 603;
    dest = 604;
    for(var f = 1; f <= e; f++) {
        fin>>a>>b>>k;
        b += VAL;
        addEdge(a, b, k, f);
        if(!ADDED[a])
        addEdge(src, a, 0, -1);
        if(!ADDED[b])
        addEdge(b, dest, 0, -1);
        ADDED[a] = ADDED[b] = 1;
    }
}

int main() {
    citire();
    vector<var> SOL;
    var z = cuplaj();
    for(var i=1; i<=n; i++) {
        if(F[src][i] == 1) {
            for(vector<Edge>::iterator it = G[i].begin(); it != G[i].end(); ++it) {
                if(F[i][(*it).n] == 1) {
                    SOL.push_back((*it).i);
                }
            }
        }
    }
    fout<<SOL.size()<<" "<<z<<'\n';
    for(vector<var>::iterator it = SOL.begin(); it != SOL.end(); ++it) {
        fout<<*it<<" ";
    }
    return 0;
}
