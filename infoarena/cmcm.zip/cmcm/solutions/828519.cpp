#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const char InFile[]="cmcm.in";
const char OutFile[]="cmcm.out";
const int MaxN=305;
const int MaxNodes=MaxN<<1;
const int S=1;
const int D=2;
const int offset=4;
const int INF=1<<30;

ifstream fin(InFile);
ofstream fout(OutFile);

int N,M,E,l,r,index,cost,flux,Cost[MaxNodes][MaxNodes],C[MaxNodes][MaxNodes],F[MaxNodes][MaxNodes],T[MaxNodes],Dist[MaxNodes],I[MaxNodes][MaxNodes];
char inQ[MaxNodes];
queue<int> Q;
vector<int> G[MaxNodes];

inline int EncodeLeft(const int &l)
{
	return offset+l;
}

inline int EncodeRight(const int &r)
{
	return offset+N+r;
}

inline void AddEdge(const int &x, const int &y, const int &cost)
{
	Cost[x][y]=cost;
	Cost[y][x]=-cost;
	G[x].push_back(y);
	G[y].push_back(x);
	C[x][y]=1;	
	I[x][y]=index;
}

int main()
{
	fin>>N>>M>>E;
	for(register int i=1;i<=E;++i)
	{
		fin>>l>>r>>cost;
		index=i;
		AddEdge(EncodeLeft(l),EncodeRight(r),cost);
	}
	fin.close();

	for(register int i=1;i<=N;++i)
	{
		AddEdge(S,EncodeLeft(i),0);
	}

	for(register int i=1;i<=M;++i)
	{
		AddEdge(EncodeRight(i),D,0);
	}

	cost=0;
	bool ok=true;
	while(ok)
	{
		ok=false;
		for(register int i=0;i<MaxNodes;++i)
		{
			Dist[i]=INF;
		}
		Dist[S]=0;
		inQ[S]=1;
		Q.push(S);
		while(!Q.empty())
		{
			int nod=Q.front();
			Q.pop();
			inQ[nod]=0;
			if(inQ[T[nod]])
			{
				continue;
			}
			for(vector<int>::iterator it=G[nod].begin();it!=G[nod].end();++it)
			{
				int &to=*it;
				int &cost=Cost[nod][to];
				if(C[nod][to]>F[nod][to] && Dist[to]>Dist[nod]+cost)
				{
					Dist[to]=Dist[nod]+cost;
					T[to]=nod;
					if(!inQ[to])
					{
						inQ[to]=1;
						Q.push(to);
					}
				}
			}
		}
		if(Dist[D]!=INF)
		{
			ok=true;
			int x=D;
			int vmin=INF;
			while(T[x])
			{
				vmin=min(vmin,C[T[x]][x]-F[T[x]][x]);
				x=T[x];
			}
			x=D;
			while(T[x])
			{
				F[T[x]][x]+=vmin;
				F[x][T[x]]-=vmin;
				x=T[x];
			}
			flux+=vmin;
			cost+=vmin*Dist[D];
		}
	}

	fout<<flux<<" "<<cost<<"\n";
	for(register int i=1;i<=N;++i)
	{
		for(register int j=1;j<=M;++j)
		{
			int x=EncodeLeft(i);
			int y=EncodeRight(j);
			if(F[x][y]==1)
			{
				fout<<I[x][y]<<" ";
			}
		}
	}
	fout.close();
	return 0;
}
