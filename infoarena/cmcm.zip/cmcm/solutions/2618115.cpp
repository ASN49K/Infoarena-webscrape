#include <bits/stdc++.h>

using namespace std;

const int MAXN = 605;

#define nod first
#define dist second

class cmp{
    public:
    bool operator ()(pair<int, int> &a, pair<int, int> &b){
        return a.dist > b.dist;
    }
};

int flux[MAXN][MAXN], cost[MAXN][MAXN], sursa[MAXN], distBellmanFord[MAXN], distDijkstra[MAXN], distUpdate[MAXN], muchie[MAXN][MAXN];
vector<int> graf[MAXN], ans;
queue<int> coada;
priority_queue<pair<int, int>, vector<pair<int, int>>, cmp> pq;

int n, m, l, r;

void BellmanFord(){
    for(int i = 1; i <= n + 2; ++i) distBellmanFord[i] = 1e9;
    distBellmanFord[n + 1] = 0;
    coada.push(n + 1);
    while(!coada.empty()){
        int x = coada.front();
        coada.pop();
        for(auto y: graf[x]){
            if(distBellmanFord[y] > distBellmanFord[x] + cost[x][y] && flux[x][y] > 0){
                distBellmanFord[y] = distBellmanFord[x] + cost[x][y];
                coada.push(y);
            }
        }
    }
}

bool Dijkstra(){
    for(int i = 1; i <= n + 2; ++i) distDijkstra[i] = distUpdate[i] = 1e9;
    distDijkstra[n + 1] = distUpdate[n + 1] = 0;
    memset(sursa, 0, n + 2);
    bool ans = 0;
    pq.push({n + 1, distDijkstra[n + 1]});
    while(!pq.empty()){
        int x = pq.top().nod, xdist = pq.top().dist;
        pq.pop();
        if(x == n + 2) ans = 1;
        if(xdist != distDijkstra[x]) continue;
        for(auto y: graf[x]){
            if(flux[x][y] > 0 && distDijkstra[y] > distDijkstra[x] + cost[x][y] + distBellmanFord[x] - distBellmanFord[y]){
                distDijkstra[y] = distDijkstra[x] + cost[x][y] + distBellmanFord[x] - distBellmanFord[y];
                distUpdate[y] = distUpdate[x] + cost[x][y];
                sursa[y] = x;
                pq.push({y, distDijkstra[y]});
            }
        }
    }
    for(int i = 1; i <= n + 2; ++i) distBellmanFord[i] = distUpdate[i];
    return ans;
}

int main()
{
    ifstream fin("cmcm.in");
    ofstream fout("cmcm.out");
    fin >> l >> r >> m;
    n = l + r;
    for(int i = 1; i <= m; ++i){
        int x, y;
        fin >> x >> y;
        y += l;
        fin >> cost[x][y];
        cost[y][x] = -cost[x][y];
        flux[x][y] = 1;
        graf[x].push_back(y); graf[y].push_back(x);
        muchie[x][y] = i;
    }
    for(int i = 1; i <= l; ++i){
        flux[n + 1][i] = 1;
        graf[n + 1].push_back(i); graf[i].push_back(n + 1);
    }
    for(int i = l + 1; i <= n; ++i){
        flux[i][n + 2] = 1;
        graf[i].push_back(n + 2); graf[n + 2].push_back(i);
    }
    BellmanFord();
    for(int i = 1; i <= n + 2; ++i) distDijkstra[i] = 1e9;
    int mux = 0, mncost = 0;
    while(Dijkstra()){
        int mnflux = 1e9;
        for(int i = n + 2; i != n + 1; i = sursa[i]) mnflux = min(mnflux, flux[sursa[i]][i]);
        if(mnflux == 0) continue;
        for(int i = n + 2; i != n + 1; i = sursa[i]){
            flux[sursa[i]][i] -= mnflux;
            flux[i][sursa[i]] += mnflux;
        }
        mncost += mnflux * distUpdate[n + 2];
        mux++;
    }
    fout << mux << " " << mncost << "\n";
    for(int i = 1; i <= l; ++i){
        for(int j = l + 1; j <= n; ++j)
            if(flux[i][j] == 1) fout << muchie[i][j] << " ";
    }
    return 0;
}
