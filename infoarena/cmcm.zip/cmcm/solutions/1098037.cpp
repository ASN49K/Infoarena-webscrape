#include<cstdio>
#include<vector>
#include<deque>
#include<bitset>

using namespace std;

typedef pair<int,int> PII;
const int INF = (1<<30);
const int NMAX = 305;
const int MMAX = 305;
const int VMAX = NMAX+MMAX;

int N,M,E,SolFlux,SolCost;
int Source,Destination;
int Edge[VMAX][VMAX];
vector<int> V[VMAX];
int Capacity[VMAX][VMAX];
int Cost[VMAX][VMAX];
int Flow[VMAX][VMAX];

deque<int> Q;
bitset<VMAX> viz;
int Dist[VMAX];
int T[VMAX];

int BellmanFord()
{
    int i,x;
    vector<int>::iterator it;

    for(i=Source; i<=Destination; i++)
        Dist[i]=INF;

    Q.push_back(Source);
    viz[Source]=1;
    Dist[Source]=0;

    while(!Q.empty())
    {
        x=Q.front();
        Q.pop_front();
        viz[x]=0;

        for(it=V[x].begin(); it!=V[x].end(); it++)
            if(Dist[x] + Cost[x][*it] < Dist[*it] && Flow[x][*it]<Capacity[x][*it])
            {
                T[*it]=x;
                Dist[*it]=Dist[x] + Cost[x][*it];
                if(!viz[*it]) Q.push_back(*it),viz[*it]=1;
            }
    }
    return Dist[Destination]!=INF;
}

int main()
{
    int i,j,x,y,c,v;

    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);

    scanf("%d%d%d",&N,&M,&E);

    Source=0;
    Destination=N+M+1;

    for(i=1; i<=E; i++)
    {
        scanf("%d%d%d",&x,&y,&c);
        y+=N;

        Capacity[Source][x]=1;
        Capacity[x][y]=1;
        Capacity[y][Destination]=1;

        Cost[x][y]=c;
        Cost[y][x]=-c;

        V[Source].push_back(x);
        V[x].push_back(Source);
        V[x].push_back(y);
        V[y].push_back(x);
        V[y].push_back(Destination);
        V[Destination].push_back(y);

        Edge[x][y]=i;
    }

    while(BellmanFord())
    {
        v=INF;

        for(x=Destination; x!=T[x]; x=T[x])
            v=min(v,Capacity[T[x]][x]-Flow[T[x]][x]);

        for(x=Destination; x!=T[x]; x=T[x])
        {
            Flow[T[x]][x]+=v;
            Flow[x][T[x]]-=v;
        }

        SolFlux+=v;
        SolCost+=Dist[Destination];
    }

    printf("%d %d\n",SolFlux,SolCost);

    for(i=1; i<=N; i++)
        for(j=N+1; j<=N+M; j++)
            if(Flow[i][j]) printf("%d ",Edge[i][j]);

    return 0;
}
