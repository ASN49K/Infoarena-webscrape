#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
int n1,n,n2,m,X,Y,Z;
const int N=605;
vector<int>a[N];
int st,dr;
bool viz[N];
int d[N][N],dad[N],dist[N];
int flux[N][N];
int ford()
{
    for(int i=st;i<=dr;i++)
    {
        dist[i]=1e9;
        viz[i]=0;
        dad[i]=0;
    }
    viz[st]=true;
    dist[st]=0;
    queue<int>q;
    q.push(st);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        viz[nod]=false;
        for(auto x : a[nod])
            if(flux[nod][x]>0&&dist[x]>dist[nod]+d[nod][x])
            {
                dist[x]=dist[nod]+d[nod][x];
                dad[x]=nod;
                if(viz[x]==false)
                {
                    viz[x]=true;
                    q.push(x);
                }
            }
    }
    return dist[dr];
}
int get_flux()
{
    int sum=0;
    while(true)
    {
        int x=ford();
        if(x==1e9)
            break;
        sum+=x;
        int ok=0;
        for(int i=dr;i!=st;i=dad[i])
        {
            flux[dad[i]][i]--;
            flux[i][dad[i]]++;
        }
    }
    return sum;
}
struct pct
{
    int x,y;
}muc[50010];
int main()
{
    f>>n1>>n2>>m;
    st=0;
    dr=n1+n2+1;
    n=n1+n2;
    for(int i=1;i<=m;i++)
    {
        f>>X>>Y>>Z;
        muc[i]={X,n1+Y};
        d[X][Y+n1]=Z;
        d[Y+n1][X]=-Z;
        flux[X][Y+n1]=1;
        a[X].push_back(Y+n1);
        a[Y+n1].push_back(X);
    }
    for(int i=1;i<=n1;i++)
    {
        flux[st][i]=1;
        a[i].push_back(st);
        a[st].push_back(i);
    }
    for(int i=1;i<=n2;i++)
    {
        flux[i+n1][dr]=1;
        a[i+n1].push_back(dr);
        a[dr].push_back(i+n1);
    }
    int S=get_flux(),nr=0;
    for(int i=1;i<=n1;i++)
        if(flux[st][i]==0)
            nr++;
    g<<nr<<" "<<S<<'\n';
    for(int i=1;i<=m;i++)
        if(flux[muc[i].x][muc[i].y]==0)
            g<<i<<" ";
    return 0;
}
