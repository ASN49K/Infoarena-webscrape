#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <bitset>
#include <cstring>

#define INF 0x3f3f3f3f
#define Nmax 615
#define DIM 666013

#define super_start 606
#define super_sink 607

using namespace std;

char buffer[DIM];
int poz = DIM -1;
int nr = -1; /// nredge
int cost[Nmax][Nmax],capacity[Nmax][Nmax],muchie[Nmax][Nmax],flow[Nmax][Nmax];

int L,R,M,daddy[Nmax],DP[Nmax];
vector<int>G[Nmax];
bitset<Nmax> inQ;
queue<int>Q;

void Insert(int from,int to,int cst,int capac,int flux)
{
    ++nr;
    G[from].push_back(nr);
    cost[from][to] = cst;
    capacity[from][to] = capac;
    flow[from][to] = flux;
}

void citeste(int &A)
{
    A = 0;
    int sgn = 1;
    while(('0' > buffer[poz] || buffer[poz] > '9') && buffer[poz] != '-')
        if(++poz == DIM) fread(buffer,1,DIM,stdin),poz = 0;
    while('0' <= buffer[poz] && buffer[poz] <= '9' || buffer[poz] == '-')
    {
        if(buffer[poz] == '-')
            sgn *= -1;
        else
            A = A * 10 + buffer[poz] - 48;
        if(++poz == DIM) fread(buffer,1,DIM,stdin),poz = 0;
    }
    A *= sgn;
}
void read( void )
{
    citeste(L),citeste(R),citeste(M);
    int a,b,c;
    for(int i = 1; i <= M; ++i){
        citeste(a),citeste(b),citeste(c);
         b += L;
        muchie[a][b] = i;
        G[a].push_back(b);
        G[b].push_back(a);
        capacity[a][b] = 1;
        cost[a][b] = c;
        cost[b][a] = -c;
    }
    for(int i = 1; i <= L; ++i)
    {
        G[super_start].push_back(i);
        G[i].push_back(super_start);
        capacity[super_start][i] = 1;
    }
    for(int i = L+1; i <= R+L; ++i)
    {
        G[super_sink].push_back(i);
        G[i].push_back(super_sink);
        capacity[i][super_sink] = 1;
    }
}

bool bellman_ford(int k)
{
    memset(DP,INF,sizeof(DP));
    DP[k] = 0;
    inQ[k] = 1;
    Q.push(k);
    while(!Q.empty())
    {
        k = Q.front(); Q.pop();inQ[k] = 0;
        if(k == super_sink) continue;
        for(vector<int>::iterator it = G[k].begin(); it != G[k].end(); ++it)
            if(DP[*it] > DP[k] + cost[k][*it] && capacity[k][*it] != flow[k][*it])
            {
                DP[*it] = DP[k] + cost[k][*it];
                daddy[*it] = k;
                if(inQ[*it]) continue;
                inQ[*it] = 1;
                Q.push(*it);
            }
    }
    return (DP[super_sink] != INF);
}
int minFLOW,maxFLOW = 0,minCOST = 0;

void FLOW(int k)
{
    while(bellman_ford(super_start))
    {
        minFLOW = INF;
        for(int nodc = super_sink; nodc != super_start; nodc = daddy[nodc])
            minFLOW = min(minFLOW, capacity[daddy[nodc]][nodc] - flow[daddy[nodc]][nodc]);
        if(!minFLOW) continue;
        for(int nodc = super_sink; nodc != super_start; nodc = daddy[nodc])
        {
            flow[daddy[nodc]][nodc] += minFLOW;
            flow[nodc][daddy[nodc]] -= minFLOW;
        }
        maxFLOW += minFLOW;
        minCOST += minFLOW * DP[super_sink];
    }
}

void print( void )
{
    printf("%d %d\n",maxFLOW,minCOST);
    for(int i = 1; i <= L; ++i)
        for(int j = i + 1; j < L + R + 1 ; ++j)
            if(flow[i][j]) printf("%d ",muchie[i][j]);
}

int main()
{
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);

    read();
    FLOW(super_start);
    print();

    return 0;
}
