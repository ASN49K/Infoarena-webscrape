#include <iostream>
#include <fstream>
#include <bitset>
#include <deque>
#include <vector>
#include <stdlib.h>
#define DIM 610
using namespace std;
ifstream fin ("cmcm.in");
ofstream fout ("cmcm.out");
bitset <DIM> viz;
vector<int> L[DIM];
deque<int> q;
int n,i,vecin,x,y,s,d,m,c,z,nod,minim,cost,j,cnt,e,a,b;
int Z[DIM][DIM],C[DIM][DIM],F[DIM][DIM],D[DIM],T[DIM];
pair <int, int> V[50010];
int bell(){
    int gasit=0;
    viz.reset();
    q.clear();
    q.push_back(s);
    viz[s]=1;
    for(i=0;i<=n+m+1;i++)
        D[i]=1000000000;
    D[s]=0;
    while(!q.empty()){
        x=q.front();
        q.pop_front();
        viz[x]=0;
        for(i=0;i<L[x].size();i++){
            if(C[x][L[x][i]] > F[x][L[x][i]]){
                y=L[x][i];
                if(D[y]>D[x]+Z[x][y]){
                    D[y]=D[x]+Z[x][y];
                    T[y]=x;
                if(viz[vecin]==0) {
                    q.push_back(y);
                    viz[y]=1;
                }
                if(y==d)
                    gasit=1;
                }
            }
        }
    }
    return gasit;
}
int main(){
    fin>>n>>m>>e;
    s=0;
    d=n+m+1;
    for(i=1;i<=n;i++){
        C[0][i]=1;
        L[0].push_back(i);
        L[i].push_back(0);
    }
    for(i=n+1;i<=n+m;i++){
        C[i][d]=1;
        L[i].push_back(d);
        L[d].push_back(i);
    }
     for(j=1;j<=e;j++){
            fin>>a>>b>>c;
            V[j].first=a;
            V[j].second=n+b;
            L[a].push_back(n+b);
            L[n+b].push_back(a);
            Z[a][n+b]=c;
            Z[n+b][a]=-c;
            C[a][n+b]=1;
        }

    while(bell()){
        nod=d;
        while(nod!=s){
            F[T[nod]][nod]++;
            F[nod][T[nod]]--;
            cost+=Z[T[nod]][nod];
            nod=T[nod];
        }

    }


    for(i=n+1;i<=m+n;i++){
        if(F[i][d])
            cnt++;
    }
    fout<<cnt<<" "<<cost<<"\n";
    for(i=1;i<=e;i++)
        if(F[V[i].first][V[i].second])
            fout<<i<<" ";
    return 0;
}
