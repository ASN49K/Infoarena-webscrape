#include <bits/stdc++.h>

using namespace std;

const int NMAX = 300;
const int INF = 2e9;

vector <int> edges[2 * NMAX + 2];
int cost[2 * NMAX + 2][2 * NMAX + 2];
int flux[2 * NMAX + 2][2 * NMAX + 2];
int p[2 * NMAX + 2];

int dist[2 * NMAX + 2];

int newdist[2 * NMAX + 2];
int newcost[2 * NMAX + 2][2 * NMAX + 2];

bool inQueue[2 * NMAX + 2];

void bellman( int node ) {
    queue <int> q;
    q.push( node );
    dist[node] = 0;
    while ( !q.empty() ) {
        int node = q.front();
        q.pop();
        inQueue[node] = false;
        for ( auto i : edges[node] ) {
            if ( flux[node][i] > 0 && dist[i] > dist[node] + cost[node][i] ) {
                dist[i] = dist[node] + cost[node][i];
                if ( !inQueue[i] ) {
                    q.push( i );
                    inQueue[i] = 1;
                }
            }
        }
    }
}

vector <pair<int,pair<int, int>>> muchii;

int main() {
    ifstream fin( "cmcm.in" );
    ofstream fout( "cmcm.out" );

    int n, m, i, a, b, e, min_cost = 0, max_flux = 0, s, d;
    fin >> n >> m >> e;
    s = 0, d = n + m + 1;
    for ( i = 0; i < e; i ++ ) {
        fin >> a >> b;
        b += n;
        fin >> cost[a][b];
        flux[a][b] = 1;
        if ( !flux[s][a] ) {
            flux[s][a] = 1;
            edges[s].push_back( a );
        }
        if ( !flux[b][d] ) {
            flux[b][d] = 1;
            edges[b].push_back( d );
        }

        edges[a].push_back( b );
        edges[b].push_back( a );
        cost[b][a] = -cost[a][b];

        muchii.push_back( { i, { a, b } } );
    }
    for ( i = s; i <= d; i ++ ) {
        random_shuffle( edges[i].begin(), edges[i].end() );
    }
    for ( i = s; i <= d; i ++ ) {
        dist[i] = INF;
    }
//    cout << "DASD";
    bellman( s );
    for ( i = s; i <= d; i ++ ) {
        for ( auto it : edges[i] ) {
            newcost[i][it] = dist[i] + cost[i][it] - dist[it];
        }
    }
    int ok = 1;
    do {
        memset( p, 0, sizeof( p ) );
        p[s] = -1;
        newdist[s] = 0;
        priority_queue <pair<int, int>> pq;
        pq.push( { 0, s } );
        while ( !pq.empty() && pq.top().second != d ) {
            int node = pq.top().second, z = -pq.top().first;
            pq.pop();
            if ( newdist[node] == z ) {
                for ( auto it : edges[node] ) {
                    if ( flux[node][it] > 0 && ( !p[it] || z + newcost[node][it] < newdist[it] ) ) {
                        p[it] = node;
                        newdist[it] = z + newcost[node][it];
                        pq.push( { -newdist[it], it } );
                    }
                }
            }
        }
        if ( !pq.empty() ) {
            int f = INF, c = 0;
            for ( int i = d; i != s; i = p[i] ) {
                f = min( f, flux[p[i]][i] );
                c += cost[p[i]][i];
            }
            for ( int i = d; i != s; i = p[i] ) {
                flux[p[i]][i] -= f;
                flux[i][p[i]] += f;
            }
            min_cost += c * f;
            max_flux += f;
        } else {
            ok = 0;
        }
    } while ( ok );
    fout << max_flux << ' ' << min_cost << '\n';
    for ( auto it : muchii ) {
        if ( flux[it.second.first][it.second.second] == 0 )
            fout << it.first + 1 << ' ';
    }
//    cout << min_cost;
    return 0;
}
