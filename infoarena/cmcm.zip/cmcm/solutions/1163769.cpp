#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int Nmax = 603;
const int inf = 1e9;
const int NORMA = 300;

struct NODE
{
    int nod;
    int dist;

    NODE( const int a = 0, const int b = 0 ) : nod( a ), dist( b ) {}

    bool operator < ( const NODE X ) const
    {
        return dist > X.dist;
    }
};

vector <int> G[Nmax];
priority_queue <NODE> MinHeap;
int C[Nmax][Nmax];
int F[Nmax][Nmax];
int indice[Nmax][Nmax];
int Cost[Nmax][Nmax];
int dist[Nmax], tata[Nmax], in_q[Nmax], coada[Nmax];

int DIM;
int N, K, A, B;

void BellmanFord( int S, int D )
{
    for ( int i = 0; i <= DIM; ++i )
    {
        dist[i] = inf;
        in_q[i] = 0;
    }

    int st, dr;
    coada[st = dr = 1] = S;
    in_q[S] = 0;
    dist[S] = 0;

    while ( st <= dr )
    {
        int nod = coada[ st++ ];
        in_q[nod] = 0;

        for ( auto x: G[nod] )
        {
            if ( dist[x] > dist[nod] + Cost[nod][x] && C[nod][x] > F[nod][x] )
            {
                dist[x] = dist[nod] + Cost[nod][x];

                if ( !in_q[x] )
                {
                    in_q[x] = 1;
                    coada[ ++dr ] = x;
                }
            }
        }
    }
}

void init( int S, int D )
{
    for ( int i = 0; i <= DIM; ++i )
    {
        for ( auto x: G[i] )
        {
            if ( dist[i] != inf && dist[x] != inf )
            {
                Cost[i][x] += dist[i] - dist[x];
            }
        }
    }

    for ( int i = 0; i <= DIM; ++i )
    {
        dist[i] = inf;
        tata[i] = 0;
    }

    dist[S] = 0;
}

int Dijkstra( int S, int D )
{
    init( S, D );
    MinHeap.push( NODE( S, 0 ) );

    while ( MinHeap.size() )
    {
        int nod = MinHeap.top().nod;
        int ddd = MinHeap.top().dist;

        MinHeap.pop();

        if ( dist[nod] != ddd ) continue;

        for ( auto x: G[nod] )
        {
            if ( dist[x] > dist[nod] + Cost[nod][x] && C[nod][x] > F[nod][x] )
            {
                dist[x] = dist[nod] + Cost[nod][x];
                tata[x] = nod;
                MinHeap.push( NODE( x, dist[x] ) );
            }
        }
    }

    return ( dist[D] < inf );
}

void MinCostMaxFlow( int S, int D, ostream &g )
{
    int flow = 0, fmin, distD = dist[D], costFlow = 0;

    while ( Dijkstra( S, D ) )
    {
        fmin = inf;

        for ( int nod = D; nod != S; nod = tata[nod] )
                fmin = min( fmin, C[ tata[nod] ][nod] - F[ tata[nod] ][nod] );

        for ( int nod = D; nod != S; nod = tata[nod] )
        {
            F[ tata[nod] ][nod] += fmin;
            F[nod][ tata[nod] ] -= fmin;
        }

        flow += fmin;
        distD += dist[D];
        if ( flow <= K ) costFlow += distD * fmin;
    }

    g << costFlow << "\n";

    for ( int i = 1; i <= N; ++i )
    {
        for ( int j = A + NORMA + N; j <= B + NORMA + N; ++j )
        {
            if ( F[i][j] )
                    g << j - NORMA - N << " ";
        }
    }
}

void add_edge( int x, int y, int cap, int cost )
{
    G[x].push_back( y );
    G[y].push_back( x );

    C[x][y] = cap;
    Cost[x][y] = +cost;
    Cost[y][x] = -cost;
}

inline int modul( int x )
{
    if ( x > 0 )
            return x;
    else
            return -x;
}

int v[Nmax];

int main()
{
    ifstream f("smen.in");
    ofstream g("smen.out");

    f >> N >> K >> A >> B;

    int S = 0, D = B + NORMA + N + 1;
    DIM = B + NORMA + N + 1;

    for ( int i = 1; i <= N; ++i )
            f >> v[i];

    for ( int i = 1; i <= N; ++i )
    {
        for ( int j = A + NORMA; j <= B + NORMA; ++j )
        {
            add_edge( i, j + N, 1, modul( v[i] - ( j - NORMA ) ) );
        }
    }

    for ( int i = 1; i <= N; ++i )
            add_edge( S, i, 1, 0 );

    for ( int j = A + NORMA; j <= B + NORMA; ++j )
            add_edge( j + N, D, 1, 0 );

    BellmanFord( S, D );
    MinCostMaxFlow( S, D, g );

    return 0;
}
