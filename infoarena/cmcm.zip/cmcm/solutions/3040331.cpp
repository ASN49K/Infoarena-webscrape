#include <fstream>
#include <vector>

#define fi first
#define se second

using namespace std;
ifstream fin("cmcm.in");
ofstream fout("cmcm.out");
int const N = 301 , M = 5e4 + 3 , inf = 1e9;
int n , m , e , a , b , c , s , d;
vector<int> v[N];
pair<int , int> mc[M];
int t[N] , dst[N] , inq[N];
int q[M];
int f[N][N] , w[N][N];
bool bellman(){
    fill(dst + 1 , dst + n + m + 3 , inf);
    fill(t + 1 , t + n + m + 3 , 0);
    int l(1) , r(1);
    q[1] = s;
    inq[s] = 1;
    dst[s] = 0;
    while(l <= r){
        int x = q[l++];
        for(int y : v[x]){
            if(f[x][y] && dst[y] > dst[x] + w[x][y]){
                dst[y] = dst[x] + w[x][y];
                t[y] = x;
                if(!inq[y]){
                    inq[y] = 1;
                    q[++r] = y;
                }
            }
        }
        inq[x] = 0;
    }
    return t[d] != 0;
}
int main(){
    fin >> n >> m >> e;
    for(int i = 1 ; i <= e ; ++ i){
        fin >> a >> b >> w[a][b + n];
        b += n;
        w[b][a] = -w[a][b];
        f[a][b] = 1;
        v[a].push_back(b);
        v[b].push_back(a);
        mc[i] = {a , b};
    }
    s = n + m + 1 , d = s + 1;
    for(int i = 1 ; i <= n ; ++ i){
        f[s][i] = 1;
        w[s][i] = w[i][s] = 0;
        v[s].push_back(i);
        v[i].push_back(s);
    }
    for(int i = n + 1 ; i <= n + m ; ++ i){
        f[i][d] = 1;
        w[i][d] = w[d][i] = 0;
        v[i].push_back(d);
        v[d].push_back(i);
    }
    int flow = 0 , cost = 0;
    while(bellman()){
        int x = d , fl = inf;
        while(t[x]){
            fl = min(fl , f[t[x]][x]);
            x = t[x];
        }
        if(!fl)continue;
        x = d;
        while(t[x]){
            f[t[x]][x] -= fl;
            f[x][t[x]] += fl;
            cost += fl * w[t[x]][x];
            x = t[x];
        }
        flow += fl;
    }
    fout << flow << ' ' << cost << '\n';
    for(int i = 1 ; i <= e ; ++ i){
        if(!f[mc[i].fi][mc[i].se]){
            fout << i << ' ';
        }
    }
    fout << '\n';
    return 0;
}
