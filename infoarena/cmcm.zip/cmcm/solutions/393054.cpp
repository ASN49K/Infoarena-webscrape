#include<stdio.h>
#define INF 1000001
#define Nmx 601

int n,m,T,dest,prec[Nmx],dist[Nmx],viz[Nmx];
int C[Nmx][Nmx],F[Nmx][Nmx],Cost[Nmx][Nmx];
int cupl=0,sol=0;
struct nod{
    int inf;
    nod *urm;
};
nod *G[Nmx];

int min(int x,int y)
{
    if(x>y) return y;
    return x;
}

void add(int x,int y)
{
    nod *aux=new nod;
    aux->inf=y;
    aux->urm=G[x];
    G[x]=aux;
}

void citire()
{
    freopen("cmcm.in","r",stdin);
    scanf("%d%d%d",&n,&m,&T);
    dest=n+m+1;
    int x,y,c;
    for(int i=1;i<=T;++i)
    {
        scanf("%d%d%d",&x,&y,&c);
        x++;y=y+n+1;
        C[x][y]=C[1][x]=C[y][dest]=1;
        Cost[x][y]=c;
        Cost[y][x]=-c;
        add(x,1);add(1,x);
        add(x,y);add(y,x);
        add(y,dest);add(dest,y);
    }
}

int belmand()
{
    int Q[100001],st,dr;
    st=dr=1;
    for(int i=1;i<=dest;++i)
    {
        dist[i]=INF;
        viz[i]=0;
        prec[i]=-1;
    }
    dist[1]=0;
    viz[1]=1;
    Q[1]=1;
    while(st<=dr)
    {
        viz[Q[st]]=0;
        for(nod *p=G[Q[st]];p;p=p->urm)
            if(C[Q[st]][p->inf]-F[Q[st]][p->inf]>0&&dist[Q[st]]+Cost[Q[st]][p->inf]<dist[p->inf])
            {
                dist[p->inf]=dist[Q[st]]+Cost[Q[st]][p->inf];
                prec[p->inf]=Q[st];
                if(!viz[p->inf])
                {
                    viz[p->inf]=1;
                    Q[++dr]=p->inf;
                }
            }
        ++st;
    }
    if(dist[dest]!=INF)
        return 1;
    return 0;
}

void flux()
{

    while(belmand())
    {
        int Vmin=INF;
        for(int i=dest;i!=1;i=prec[i])
            Vmin=min(Vmin,C[prec[i]][i]-F[prec[i]][i]);
        for(int i=dest;i!=1;i=prec[i])
        {
            F[prec[i]][i]+=Vmin;
            F[i][prec[i]]-=Vmin;
        }
        if(Vmin)
        {
            ++cupl;
            sol+=dist[dest];
        }
    }
    freopen("cmcm.in","r",stdin);
    freopen("cmcm.out","w",stdout);
    scanf("%d%d%d",&n,&m,&T);
    int x,y,c;
    printf("%d %d\n",cupl,sol);
    for(int i=1;i<=T;++i)
    {
        scanf("%d%d%d",&x,&y,&c);
        if(F[x+1][y+n+1])
        {
            printf("%d ",i);
        }
    }
    printf("\n");
}

void afisare()
{

}


int main()
{
    citire();
    flux();
    //afisare();
    return 0;
}
