#include <algorithm>
#include <vector>
#include <bitset>
#include <queue>
using namespace std;

#define INF 0x3f3f3f3f
#define pb push_back
#define mp make_pair
#define sc second
#define fs first
#define DIM 605

vector <pair <int,int> > g[DIM];
int c[DIM][DIM],f[DIM][DIM];
int n,m,e,s,d,cuplaj,cost;
int dst[DIM],t[DIM];
bitset <DIM> viz;

struct cmp
{
    bool operator () (const int &a,const int &b)
    {
        return dst[a]>dst[b];
    }
}; priority_queue <int,vector <int>,cmp> q;

void read ()
{
    int i,x,y,z;

    scanf ("%d%d%d",&n,&m,&e);
    for (i=1; i<=e; ++i)
    {
        scanf ("%d%d%d",&x,&y,&z);
        c[x][y+n]=1;
        g[x].pb (mp (y+n,z));
        g[y+n].pb (mp (x,-z));
    }
}

void init ()
{
    int i;

    s=0; d=n+m+1;
    for (i=1; i<=n; ++i)
    {
        c[s][i]=1;
        g[s].pb (mp (i,0));
        g[i].pb (mp (s,0));
    }
    for (i=1; i<=m; ++i)
    {
        c[i+n][d]=1;
        g[d].pb (mp (i+n,0));
        g[i+n].pb (mp (d,0));
    }
}

int dijkstra ()
{
    vector <pair <int,int> > :: iterator it;
    int nod;

    memset (dst,INF,sizeof (dst));
    dst[s]=0;
    for (q.push (s); !q.empty (); )
    {
        viz[nod=q.top ()]=0; q.pop ();
        for (it=g[nod].begin (); it!=g[nod].end (); ++it)
            if (dst[nod]+it->sc<dst[it->fs] && c[nod][it->fs]>f[nod][it->fs])
            {
                dst[it->fs]=dst[nod]+it->sc;
                t[it->fs]=nod;
                if (!viz[it->fs])
                {
                    q.push (it->fs);
                    viz[it->fs]=1;
                }
            }

    }
    if (dst[d]==INF)
        return 0;
    return 1;
}

void solve ()
{
    int i,nrmin;

    for (nrmin=INF; dijkstra (); nrmin=INF)
    {
        for (i=d; i!=s; i=t[i])
            nrmin=min (nrmin,c[t[i]][i]-f[t[i]][i]);
        for (i=d; i!=s; i=t[i])
        {
            f[t[i]][i]+=nrmin;
            f[i][t[i]]-=nrmin;
        }
        ++cuplaj;
        cost+=dst[d];
    }
}

void print ()
{
    freopen ("cmcm.in","r",stdin);
    int i,x,y,z;

    scanf ("%d%d%d",&n,&m,&e);
    printf ("%d %d\n",cuplaj,cost);
    for (i=1; i<=e; ++i)
    {
        scanf ("%d%d%d",&x,&y,&z);
        if (f[x][y+n])
            printf ("%d ",i);
    }
}

int main ()
{
    freopen ("cmcm.in","r",stdin);
    freopen ("cmcm.out","w",stdout);

    read ();
    init ();
    solve ();
    print ();

    return 0;
}