#include<cstdio>
#include<cstdlib>
#include<vector>
using namespace std;

struct edge
{
	int from;
	int to;
	int cost;
	int index;
};
vector<bool> l,r;
vector<edge> edges,usedEdges;
int n,m,e,cost;

int compare_edge(const void *a, const void*b)
{
	if(((edge*)a)->from == ((edge*)b)->from)
		return ((edge*)a)->cost - ((edge*)b)->cost;
	return ((edge*)a)->from - ((edge*)b)->from;
}

void read()
{
	int f,t,c;
	edge newEdge;
	for(int i=1;i<=e;++i)
	{
		scanf("%d %d %d",&f,&t,&c);
		newEdge.from = f;
		newEdge.to = t;
		newEdge.cost = c;
		newEdge.index = i;
		edges.push_back(newEdge);
	}
	qsort(&edges[0],e,sizeof(edge),compare_edge);
}

bool reduce()
{
	int k = -1;
	bool change = false;
	for(int i=1;i<=n;i++)
	{
		int j=0;
		while(edges[++k].from == i && k < edges.size())
			j++;
		
		if(!l[i] && j<=1)
		{
			
			l[i] = true;
			if(j==1)
			{
				change = true;
				r[edges[k-1].to] = true;
				usedEdges.push_back(edges[k-1]);
				cost += edges[k-1].cost;
				edges.erase(edges.begin()+k-1);
				k--;
			}
		}
		k--;
	}
	
	for(int i=0;i<edges.size();i++)
	{
		if(r[edges[i].to] && !l[edges[i].from])
		{
			edges.erase(edges.begin() + i);
			change = true;
		}
	}
	return change;			
}

bool check_reduce(vector<edge> ed,int index)
{
	for(int i=0;i<ed.size();i++)
		if(ed[index].to == ed[i].to && index != i)
			return false;
	
	return true;
}

void reduce_more(int i)
{
	if(i>=edges.size())
		return;
	int node = edges[i].from;
	if(check_reduce(edges,i))
	{
		usedEdges.push_back(edges[i]);
		cost += edges[i].cost;
		while(edges[i].from == node && i<edges.size())
		{
			edges.erase(edges.begin() + i);
		}
	}
	while(edges[i].from == node && i<edges.size())
		i++;
		
	reduce_more(i);
		
}
		
	


int main()
{
	freopen("cmcm.in","r",stdin);
	freopen("cmcm.out","w",stdout);
	scanf("%d %d %d",&n,&m,&e);
	cost = 0;
	l.resize(n+5,0);
	r.resize(m+5,0);
	read();
	while(reduce());
	reduce_more(0);
	
	/*printf("remaining: \n");
	for(int i=0;i<edges.size();i++)
		printf("%d %d %d %d\n",edges[i].from, edges[i].to, edges[i].cost, edges[i].index);
		
	printf("solution:\n");*/
	printf("%d %d\n",usedEdges.size(),cost);
	for(int i=0;i<usedEdges.size();i++)
		printf("%d ",usedEdges[i].index);
		
}
