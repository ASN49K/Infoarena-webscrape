#include<fstream>
#include<bitset>
#include<queue>
#include<vector>
#include<algorithm>
using namespace std;

#define NMax 605
#define inf 2100000000

ifstream f("cmcm.in");
ofstream g("cmcm.out");

int n,m,e,S,D;
vector<int> v[NMax],w[NMax];
int ant[NMax];
int C[NMax][NMax],F[NMax][NMax];
int Cost[NMax][NMax];
int cup[NMax];

bitset<NMax> used;

queue<int> cd;
bitset<NMax> B;
int d[NMax];

void Bellmanford()
{
    int i,s;
    while(!cd.empty())
    {
        s=cd.front(); cd.pop();
        B[s]=0;
        for(i=0;i<(int)v[s].size();i++) if(F[s][v[s][i]]<C[s][v[s][i]]) if(d[v[s][i]]>d[s]+Cost[s][v[s][i]])
        {
            ant[v[s][i]]=s;
            d[v[s][i]]=d[s]+Cost[s][v[s][i]];
            if(!B[v[s][i]]) cd.push(v[s][i]),B[v[s][i]]=1;
        }
    }
}

int Flux()
{
    for(int i=1;i<=D;i++) d[i]=inf,ant[i]=0;
    d[S]=0;

    cd.push(S);
    Bellmanford();

    if(d[D]==inf) return 0;

    int nod=D;
    while(ant[nod])
    {
        F[ant[nod]][nod]+=1;
        F[nod][ant[nod]]-=1;
        nod=ant[nod];
    }

    return d[D];
}

int main()
{
    int i,j,a,b,c;

    f>>n>>m>>e;

    S=1;
    D=n+m+2;

    for(i=1;i<=e;i++)
    {
        f>>a>>b>>c;
        a+=1;
        b+=n+1;

        if(!used[a])
        {
            v[S].push_back(a);
            v[a].push_back(S);
            w[a].push_back(0);
            used[a]=1;
        }

        if(!used[b])
        {
            v[b].push_back(D);
            v[D].push_back(b);
            w[b].push_back(0);
            used[b]=1;
        }

        v[a].push_back(b);
        v[b].push_back(a);
        w[a].push_back(i);
        w[b].push_back(i);

        C[S][a]=1;
        C[b][D]=1;
        C[a][b]=1;

        Cost[a][b]=c;
        Cost[b][a]=-c;
    }

    int flux=0,cost=0;

    while(cost=Flux()) flux+=cost;

    int cuplaj=0;
    for(i=2;i<=n+1;i++) for(j=0;j<(int)v[i].size();j++) if(F[i][v[i][j]] && v[i][j]!=1)
    {
        cup[i-1]=w[i][j];
        cuplaj++;
        break;
    }

    g<<cuplaj<<" "<<flux<<"\n";
    for(i=1;i<=n;i++) if(cup[i]) g<<cup[i]<<" ";
    g<<"\n";

    f.close();
    g.close();

    return 0;
}
