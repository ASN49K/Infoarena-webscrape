#include <cstdio>
#include <cstring>
#include <fstream>
#define INF 0x3f3f3f3f
#define Nmx 620

using namespace std;

int n,m,s,d,T,viz[Nmx],prec[Nmx],nr,C[Nmx][Nmx],dist[Nmx],F[Nmx][Nmx];
struct nod{int inf,cost;nod *urm;};
nod *G[Nmx];
struct dat{int a,b;}A[Nmx*Nmx];
int Q[Nmx*Nmx];

ifstream fin("cmcm.in");

void add(int x,int y,int c)
{
    nod *aux=new nod;
    aux->inf = y;
    aux->cost = c;
    aux->urm = G[x];
    G[x] = aux;
}

void read()
{
    int x,y,c;
    fin>>n>>m>>T;
    s=1;
    d=1+n+m+1;
    for(;T;--T)
    {
        fin>>x>>y>>c;
        x++;y=y+n+1;
        A[++nr].a=x;
        A[nr].b=y;
        C[1][x]=C[y][d]=C[x][y]=1;
        add(x,y,c);add(y,x,-c);
        add(1,x,0);add(x,1,0);
        add(y,d,0);add(d,y,0);
    }
}

int bellmand()
{
    for(int i=1;i<=d;++i)
    {
        dist[i]=INF;
        prec[i]=0;
        viz[i]=0;
    }
    dist[1]=0;viz[1]=1;
    int st,dr;
    st=1;dr=0;
    Q[++dr]=1;
    while(st<=dr)
    {
        int x=Q[st];
        viz[x]=0;
        for(nod *p=G[x];p;p=p->urm)
        if(C[x][p->inf]-F[x][p->inf]>0&&dist[p->inf]>dist[x]+p->cost)
        {
            dist[p->inf]=dist[x]+p->cost;
            prec[p->inf]=x;
            if(!viz[p->inf])
            {
                viz[p->inf]=1;
                Q[++dr]=p->inf;
            }
        }
        ++st;
    }
    if(dist[d]<INF)
        return 1;
    return 0;
}

void solve()
{
    int sol=0,cuplaj=0;
    while(bellmand())
    {
        int Vmin=INF;
        for(int j=d;prec[j];j=prec[j])
            Vmin=min(Vmin,C[prec[j]][j]-F[prec[j]][j]);
        if(Vmin)
        {
            for(int j=d;prec[j];j=prec[j])
            {
                F[prec[j]][j]+=Vmin;
                F[j][prec[j]]-=Vmin;
            }
            if(dist[d]*Vmin)
            {
                cuplaj+=Vmin;
                sol+=dist[d];
            }
        }
    }
    printf("%d %d\n",cuplaj,sol);
    for(int i=1;i<=nr;++i)
    {
        if(F[A[i].a][A[i].b])
            printf("%d ",i);
    }
    printf("\n");
}

int main()
{
    freopen("cmcm.out","w",stdout);
    read();
    solve();
    return 0;
}
