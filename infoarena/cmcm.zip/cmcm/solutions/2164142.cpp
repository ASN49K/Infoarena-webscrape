#include <fstream>
#include <string.h>
#include <queue>
#include <vector>
#define nmax 605
#define inf 2e9
using namespace std;
ifstream f("cmcm.in");
ofstream g("cmcm.out");
int C[nmax][nmax],n,m,E,x,y,c,F[nmax][nmax],nr,Cmin,use[nmax],dist[nmax],d[nmax],t[nmax],FC,D[nmax],fin;
vector <pair<int, pair<int,int>  > > v[nmax];
priority_queue <pair<int,int>  ,vector <pair<int,int> >,greater <pair<int,int> > > h;
int cost(int i,int j)
{
    int k;
    for(k=0; k<v[i].size(); k++)
    {
        if(v[i][k].first==j) return v[i][k].second.first;
    }
}
void bellmanford()
{
    int nod,cst,vec,ct,j,i;
    for(i=1; i<=fin; i++) dist[i]=inf;
    dist[0]=0;
    use[0]=1;
    h.push({0,0});
    while(!h.empty())
    {
        nod=h.top().first;
        cst=h.top().second;
        h.pop();
        use[nod]=0;
        for(j=0; j<v[nod].size(); j++)
        {
            vec=v[nod][j].first;
            ct=v[nod][j].second.first;
            if(dist[vec]>ct+cst&&C[nod][vec]!=F[nod][vec])
               {
               dist[vec]=ct+cst;
            if(!use[vec]&&vec!=fin)
            {
                use[vec]=1;
                h.push({vec,ct+cst});
            }
               }
        }

    }
}
int dijkstra()
{
    int nod,cst,vec,ct,j,i;
    for(i=1; i<=fin; i++) {d[i]=inf;t[i]=0;}
    dist[0]=d[0]=0;
    h.push({0,0});
    while(!h.empty())
    {
        nod=h.top().first;
        cst=h.top().second;
        if(nod==13)
            nod=13;
        h.pop();
         if(nod==fin || cst != d[nod])
            continue;
        for(j=0; j<v[nod].size(); j++)
        {
            vec=v[nod][j].first;
            ct=v[nod][j].second.first;
            if(d[vec]>ct+cst+dist[nod]-dist[vec]&&C[nod][vec]!=F[nod][vec])
            {
                d[vec]=ct+cst+dist[nod]-dist[vec];
                t[vec]=nod;
                D[vec]=D[nod]+ct;
                h.push({vec,d[vec]});
            }
        }
    }
     memcpy(dist, D,sizeof(D));
     if(t[fin]) return 1;
     return 0;

}
int main()
{
    int i,vec,j;
    f>>n>>m>>E;
    fin=n+m+1;
    for(i=1; i<=E; i++)
    {
        f>>x>>y>>c;
        v[x].push_back({y+n,{c,i}});
        v[y+n].push_back({x,{-c,i}});
        C[x][n+y]=1;
    }
    for(i=1; i<=n; i++)
    {
        v[0].push_back({i,{0,0}});
        v[i].push_back({0,{0,0}});

        C[0][i]=1;
    }
    for(i=1;i<=m;i++)
    {
         v[i+n].push_back({fin,{0,0}});
        v[fin].push_back({i+n,{0,0}});
        C[i+n][fin]=1;
    }
    bellmanford();
    while(dijkstra())
    {
        FC=inf;
        for(i=fin; i!=0; i=t[i])
        {
            FC=min(FC,C[t[i]][i]-F[t[i]][i]);
        }
        for(i=fin; i!=0; i=t[i])
        {
            F[t[i]][i]+=FC;
            F[i][t[i]]-=FC;
            Cmin+=FC*cost(t[i],i);
        }
    }
    for(i=0; i<v[fin].size(); i++)
    {
        vec=v[fin][i].first;
        if(C[vec][fin]==F[vec][fin]) nr++;
    }
    g<<nr<<' '<<Cmin<<'\n';
    for(j=1;j<fin;j++)
    for(i=0; i<v[j].size(); i++)
    {
        vec=v[j][i].first;
        if(C[vec][j]&&F[vec][j]&&vec!=fin&&v[j][i].second.second)
            g<<v[j][i].second.second<<' ';
    }
    return 0;
}
