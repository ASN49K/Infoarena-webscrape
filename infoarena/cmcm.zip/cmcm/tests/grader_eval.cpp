#include <cstdio>
#include <cstdlib>

using namespace std;

#define MAX_N 50010

int N, M, E, NRok, COSTok, NRout, COSTout, sum;
int count_st[MAX_N], count_dr[MAX_N];
struct muchie {
	int a, b, c;
} v[MAX_N];
int fol[MAX_N];

void error(int points, char *msg) {
    fprintf(stderr, "%s", msg);
    printf("%d", points);
    exit(0);
}

int main() {
    FILE *fin = fopen("cmcm.in", "rt");
    if (!fin) {
        error(0, "Missing input file! Contact author!");
    }
    fscanf(fin, "%d %d %d", &N, &M, &E);
	for (int i = 1; i <= E; i++)
		fscanf(fin, "%d %d %d", &v[i].a, &v[i].b, &v[i].c);

    FILE *fok = fopen("cmcm.ok", "rt");
    if (!fok) {
        error(0, "Missing OK file! Contact author!");
    }

    fscanf(fok, "%d %d", &NRok, &COSTok);

    FILE *fout = fopen("cmcm.out", "rt");
    if (!fout) error(0, "Fisier de iesire lipsa!");

    if (fscanf(fout, "%d %d", &NRout, &COSTout) != 2)
		error(0, "Date de iesire invalide");
    if (NRout != NRok)
        error(0, "Numar incorect de muchii");
	else if (COSTout != COSTok)
		   error(0, "Suma costurilor nu este buna");

	for (int i = 1; i <= NRout; i++) {
    	int k;

		if (fscanf(fout, "%d", &k) != 1)
			error(0, "Nu ai afisat toate muchiile");
		if (k < 1 || k > E)
			error(0, "Muchie invalida");
		if (fol[k])
			error(0, "Muchiile se repeta");

		fol[k]++;
	}
		
    char c;
    if (fscanf(fout, " %c ", &c) != EOF) {
        error(0, "Caractere in plus in fisier");
    }

	for (int i = 1; i <= E; i++) 
		if (fol[i]) {
        	count_st[v[i].a]++; 
			count_dr[v[i].b]++;

			if (count_st[v[i].a] > 1 || count_dr[v[i].b] > 1) 
				error(0, "Muchii gresite");

			sum += v[i].c;
		}

	if (sum != COSTok)
		error(0, "Muchii gresite"); 

    error(10, "Corect");

    return 0;
}


