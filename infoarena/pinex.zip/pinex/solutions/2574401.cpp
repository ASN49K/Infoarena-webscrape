#include <bits/stdc++.h>

using namespace std;

ifstream fin("pinex.in");
ofstream fout("pinex.out");

typedef long long ll;

int m;

ll a, b;

ll count_prime(ll a, ll b) {
  vector <int> fct;
  ll ans, subset;
  int d, limit, card;
  d = 2;
  while (d * d <= b) {
    if (b % d == 0) {
      fct.push_back(d);
      while (b % d == 0) {
        b /= d;
      }
    }
    d += 1 + (d % 2);
  }
  if (b > 1) {
    fct.push_back(b);
  }
  ans = 0;
  limit = (1 << fct.size());
  for (int mask = 1; mask < limit; ++mask) {
    card = 0;
    subset = 1;
    for (int i = 0; i < fct.size(); ++i) {
      if ((mask & (1 << i)) > 0) {
        ++card;
        subset = subset * fct[i];
      }
    }
    if (card % 2 > 0) {
      ans = ans + a / subset;
    } else {
      ans = ans - a / subset;
    }
  }
  return ans;
}

int main() {
  fin >> m;
  while (m --) {
    fin >> a >> b;
    fout << a - count_prime(a, b) << "\n";
  }
  return 0;
}
