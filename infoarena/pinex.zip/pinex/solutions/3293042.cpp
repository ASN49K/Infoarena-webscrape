#include <bits/stdc++.h>

using namespace std;

ifstream fin ("pinex.in");
ofstream fout ("pinex.out");

unordered_map <int, int> mp;
bool ciur[1000005];
vector <int> prime;
void eratostene()
{
    ciur[0]=ciur[1]=1;
    for (int i=2; i*i<=1000000; i++) {
        if (ciur[i]==0) {
            for (int j=i*i; j<=1000000; j+=i) {
                ciur[j]=1;
            }
        }
    }
    for (int i=1; i<=1000000; i++) {
        if (ciur[i]==0) {
            prime.push_back(i);
        }
    }
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int m; fin>>m;
    eratostene();
    while (m--) {
        int a, b;
        fin>>a>>b;
        for (int prim : prime) {
            if (prim>b) break;
            if (b%prim==0) {
                for (int j=1; j*prim<=a; j++) {
                    mp[j*prim]=1;
                }
            }
        }
        fout<<a-mp.size()<<'\n';
        mp.clear();
    }
    return 0;
}