#include <fstream>
#include <vector>
#include <string>

using namespace std;

const string IN_FILE = "pinex.in";
const string OUT_FILE = "pinex.out";
const int MAX_PRIME = 1000000;

vector<int> getPrimes(const int n) {
    auto isPrime = vector<int>(n + 1, true);
    auto primes = vector<int>({2});
    for (int i = 3; i <= n; i += 2) {
        if (isPrime[i]) {
            primes.push_back(i);
            for (int j = int(min(1LL * i * i, 1LL * n + 1)); j <= n; j += i) {
                isPrime[j] = false;
            }
        }
    }
    return primes;
}

vector<int64_t> factorize(const vector<int>& primes, const int64_t n) {
    auto factors = vector<int64_t>();
    int64_t x = n;
    for (const auto& f : primes) {
        if (x % f == 0) {
            factors.push_back(f);
            for (; x % f == 0; x/= f);
        }
    }
    if (x > 1) {
        factors.push_back(x);
    }
    return factors;
}

int64_t back(
        const int64_t n,
        const vector<int64_t>& factors,
        const int64_t p,
        const int i,
        const int sign) {
    if (i == int(factors.size())) return sign * n / p;
    return back(n, factors, p, i + 1, sign)
            + back(n, factors, factors[i] * p, i + 1, -sign);
}

int main() {
    const auto primes = getPrimes(MAX_PRIME);
    ifstream in(IN_FILE);
    ofstream out(OUT_FILE);
    int Q;
    in >> Q;
    for (int i = 0; i < Q; i++) {
        int64_t a, b;
        in >> a >> b;
        const auto factors = factorize(primes, b);
        out << back(a, factors, 1LL, 0, 1) << "\n";
    }
    in.close();
    out.close();
    return 0;
}

