#include <cstdio>
#include <bitset>
#include <string.h>
using namespace std;

long long n, a, b;
bitset <1000005>ciur;

long long div[1000005];
long long prim[100001000];

void ciurr()
{
    ciur[1]=1;
    for(int i=2; i<=1000005; i++)
        if(ciur[i]==0)
        {
            for(int j=i+i; j<=1000005; j+=i)
                ciur[j]=1;
            prim[++prim[0]]=i;
        }

}
long long k=0;
void calc(long long b)
{
    for(long long i=1; prim[i]*prim[i]<=b;i++)
        if(b%prim[i]==0)
        {
            if(b%prim[i]==0)
            {
                while(b%prim[i] == 0)
                    b/=prim[i];
                div[k++]=prim[i];
            }
        }
    if(b!=1)
        div[k++]=b;
}

long long generare()
{
    long long nr=(1<<k);
    long long s=0;
    for(long long i=1; i<nr; i++)
    {
        long long p=1;
        long long nrel=0;
        for(int j=0; j<k; j++)
            if(i & (1<<j))
            {
                p*=div[j];
                nrel++;
            }
        if(nrel%2 == 0)
            s=(s-a/p);
        else
            s=(s+a/p);
    }
    s=a-s;
    return s;
}
int main()
{
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w", stdout);
    scanf("%lld", &n);
    ciurr();
    for(int i=1; i<=n; i++)
    {
        scanf("%lld %lld", &a, &b);
        calc(b);
        printf("%lld\n", generare());
        for(long long h=0;h<=k;h++)
            div[h]=0;
        k=0;
    }
    return 0;
}
