#include <fstream>

using namespace std;

ifstream in("pinex.in");
ofstream out("pinex.out");

int dv[1000];

int main()
{
    int m,a,b,cnt,d;
    long long rez;
    in>>m;
    for(int k=1; k<=m; k++)
    {
        in>>a>>b;
        cnt=0;
        d=2;
        while(b>1 && d*d<=b)
        {
            if(b%d==0)
            {
                dv[cnt++]=d;
                while(b%d==0)
                {
                    b/=d;
                }
            }
            d++;
        }
        if(b>1) dv[cnt++]=b;
        rez = 0;
        for(int i=0; i<(1<<cnt); i++)
        {
            long long nre = 0, prod = 1;
            for(int j=0; j<cnt; j++)
            {
                if(i&(1<<j))
                {
                    prod *= dv[j];
                    nre++;
                }
            }
            if (nre % 2 == 0)
            {
                rez += a / prod;
            }
            else
            {
                rez -= a / prod;
            }
        }
        out << rez << "\n";
    }
    return 0;
}
