#include <fstream>
#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream fin("pinex.in");
ofstream fout("pinex.out");
int t, a, b, i, d, ans, prim[10005];
signed main()
{
    fin>>t;
    while(t--)
    {
        fin>>a>>b;
        ans=0;
        d=2;
        int k=0;
        while(b>1)
        {
            if(b%d==0)
            {
                prim[k++]=d;
                while(b%d==0)
                    b/=d;
            }
            d++;
            if(d*d>b)
                d=b;
        }
        for(int mask=0; mask<(1<<k); mask++)
        {
            int nr2=0, p=1;
            for(int j=0; j<k; j++)
                if(mask&(1<<j))
            {
                nr2++;
                p*=prim[j];
            }
            if(nr2%2==1)
                ans+=a/p;
            else
                if(nr2)
                  ans-=a/p;
        }
        fout<<a-ans<<'\n';
    }
    return 0;
}
