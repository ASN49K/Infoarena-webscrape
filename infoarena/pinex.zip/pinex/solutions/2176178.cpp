#include <iostream>
#include <cstdio>
#include <string.h>
using namespace std;

bool sir[1000005];
long long diviz[1000005], prim[1000005], k = 0, n, a, b, nrp = 1;

void ciur()
{
    /*prim[nrp++] = 2;
    for(int i = 4; i<=1000005; i+=2)
        sir[i] = 1;
    for(int i = 3; i<=1000005; i+=2)
    {
        if(sir[i] == 0)
        {
            prim[nrp++] = i;
            for(int j = i*3; j<=1000005; j+=i)
            {
                sir[j] = 1;
            }
        }
    }*/
    for(int i = 2; i<=1000005; i++)
    {
        if(sir[i] == 0)
        {
            prim[nrp++] = i;
            for(int j = i+i; j<=1000005; j+=i)
                sir[j] = 1;
        }
    }
}

void divizori()
{
    k = 0;
    for(long long d = 1; prim[d]*prim[d]<=b; d++)
    {
        if(b%prim[d] == 0)
        {
            while(b%prim[d] == 0)
                b/=prim[d];
            diviz[k++] = prim[d];
        }
    }
    if(b!=1)
        diviz[k++] = b;
}

void rez()
{
    scanf("%d %d", &a, &b);
    divizori();
    long long v = (1<<k);
    long long suma = 0;
    for(long long nr = 1; nr<v; nr++)
    {
        long long prod = 1, nrsub = 0;
        for(long long j = 0; j<k; j++)
        {
            if(nr&(1<<j))
            {
                prod*=diviz[j];
                nrsub++;
            }
        }
        if(nrsub%2 == 0)
            suma-=a/prod;
        else
            suma+=a/prod;
    }
    printf("%d\n", a-suma);
}

int main()
{
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w", stdout);
    scanf("%d", &n);
    ciur();
    for(long long i = 0; i<n; i++)
    {
        rez();
        memset(diviz, 0, sizeof(diviz));
    }
    return 0;
}
