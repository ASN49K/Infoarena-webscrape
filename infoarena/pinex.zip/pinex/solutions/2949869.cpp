#include <bits/stdc++.h>
using namespace std;

ifstream fin("pinex.in");
ofstream fout("pinex.out");

int main()
{
  int m;

  fin >> m;
  for (int i = 1; i <= m; i++)
  {
    int a, b;
    fin >> a >> b;

    vector<int> divPrim;

    for (int div = 2; div <= b; div++)
      if (b % div == 0)
      {
        divPrim.push_back(div);
        while (b % div == 0)
          b /= div;
      }

    int res = 0, size = divPrim.size(), steps = 1 << size;
    for (int i = 1; i < steps; i++)
    {
      int temp = a, cnt = 0;
      for (int p = 0; p < size; p++)
        if (i & (1 << p))
          temp /= divPrim[p], cnt++;

      if (cnt % 2 != 0)
        res += temp;
      else
        res -= temp;
    }

    cout << a - res << "\n";
  }

  return 0;
}