#include<cstdio>
#define N 1000001
using namespace std;
const int N=1000001,M=20000000;
long long v[N],p[N],a[101],i,j,o,x,y,s,r,d,k,t,m,l,q,z;
char u[M];

int main()
{
	freopen("pinex.in","r",stdin),freopen("pinex.out","w",stdout),fread(u,1,M,stdin);
	for(m=N-1,i=2,o=A();i<=m;i++)
		if(!v[i])
			for(p[++d]=i,j=i*i;j<=m;j+=i)
				v[j]=1;
	while(o--)
	{
		for(x=A(),y=A(),l=x,k=0,i=1;i*i<=y;i++)
			if(y%p[i]==0)
				for(a[++k]=p[i];y%p[i]==0;y/=p[i]);
		if(y>1)
			a[++k]=y;
		for(t=1<<k,i=1;i<t;i++)
		{
			for(r=1,s=j=0;j<k;j++)
				if((i&(1<<j))>0)
					s++,r*=a[j+1];
            l+=((s%2==0?1:-1)*x/r);
		}
		S(l);
	}
	fwrite(u,1,z,stdout);
}
