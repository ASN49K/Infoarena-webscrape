#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O2,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

vi primes;
vector<bool> is_prime(1000005, 1);

void sieve(){
    is_prime[0] = is_prime[1] = false;
    for(ll i = 2; i <= 1e6; i++){
        if(is_prime[i]){
            primes.pb(i);
            for(ll j = i * i; j <= 1e6; j += i)
                is_prime[j] = false;
        }
    }
}

ll ans;
void in_ex(vector<ll> &primes, int l, int r, ll div, ll number, int sign){
    if(l == r){
            ans += sign * (number / div);
    } else {
        in_ex(primes, l+1, r, div*primes[l], number, sign*-1);
        in_ex(primes, l+1, r, div, number, sign);
    }
}

void solve(){
    int n;
    cin >> n;
    sieve();
    for(int k = 0; k < n; k++){
        ll a, b;
        cin >> a >> b;
        vector<ll> current_primes;
        for(auto i : primes){
            if(b % i == 0)
                current_primes.pb(i);
            while(b % i == 0)
                b /= i;
        }
        if(b > 1)
            current_primes.pb(b);
        ans = 0;
        in_ex(current_primes, 0, (int)current_primes.size(), 1LL, a, 1);
        cout << ans << '\n';
    }
}   

int main(){
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}