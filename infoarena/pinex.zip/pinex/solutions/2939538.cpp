#include <fstream>

using namespace std;
ifstream f("pinex.in");
ofstream g("pinex.out");
int main()
{
    int q,i,j,k,cnt,nr;
    long long aux,rez,a,b;
    f>>q;
    while(q)
    {
        f>>a>>b;
        cnt=0; rez=a; k=1;
        int prim[1003]={0};
        if(b%2==0)
        {
            cnt++; k=k*2;
            prim[cnt]=2;
            while(b%2==0)
            {
                b=b/2;
            }
        }
        for(i=3;i*i<=b;i=i+2)
        {
            if(b%i==0)
            {
                cnt++;
                k=k*2;
                prim[cnt]=i;
                while(b%i==0)
                {
                    b=b/i;
                }
            }
        }
        if(b>1)
        {
            cnt++; k=k*2;
            prim[cnt]=b;
        }
        for(i=1;i<k;i++)
        {
            aux=1; nr=0; cnt=1;
            for(j=1;j<=k/2;j=j*2)
            {
                if((i&j)!=0)
                {
                    nr++;
                    aux=aux*prim[cnt];
                }
                cnt++;
            }
            if(nr%2==0)
            {
                rez=rez+a/aux;
            }
            else
            {
                rez=rez-a/aux;
            }
        }
        g<<rez<<'\n';
        q--;
    }
    return 0;
}
