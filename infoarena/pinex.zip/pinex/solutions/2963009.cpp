#include <bits/stdc++.h>

using namespace std;

ifstream f("pinex.in");
ofstream g("pinex.out");

long long n,m,a,b,i,j,k,d,x,nr,s,prime[1000010],v[110];
bool ciur[1000010];

int main()
{
    k=0;
    ciur[0]=1;
    ciur[1]=1;
    for(i=2; i<=1000000; i++)
    {
        if(ciur[i]==0)
        {
            k++;
            prime[k]=i;
            for(j=2; i*j<=1000000; j++)
            {
                ciur[i*j]=1;
            }
        }
    }
    f>>n;
    while(n)
    {
        f>>a>>b;
        x=b;
        k=0;
        m=0;
        s=0;
        while(x>1)
        {
            m++;
            d=prime[m];
            if(x%d==0)
            {
                v[++k]=d;
                while(x%d==0)
                {
                    x=x/d;
                }
            }
            if(d*d>x)
            {
                d=x;
            }
        }
        for(i=1; i<(1<<k); i++)
        {
            x=1;
            nr=0;
            for(j=0; j<k; j++)
            {
                if((1<<j)&i)
                {
//                    if(n==1)
//                    cout<<i<<' '<<j<<'\n';
                    x*=v[j+1];
                    nr++;
                }
            }
//            if(n==1)
//                cout<<"        "<<x<<'\n';
            if(nr%2==1)
            {
                s-=a/x;
            }
            else
            {
                s+=a/x;
            }
        }
//        cout<<'\n';
        g<<a-abs(s)<<'\n';
        n--;
    }
    return 0;
}
