#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("pinex.in");
ofstream fout("pinex.out");

#define BMAX 1000000

char ciur[BMAX + 1];
int prime[BMAX + 1];
int fact[BMAX + 1];
int vf; /// = 0

char calculare_ciur(){
    ///ciur
    ciur[0] = ciur[1] = 1;
    for (int d = 2; d < BMAX; d++){
        if (ciur[d] == 0){
            for (int i = 2 * d; i < BMAX; i += d){
                ciur[i] = 1;
            }
            prime[++vf] = d;
        }
    }
}

long long dotest(long long a, long long b){
    long long d = 0, cat = 0;
    ///det factorii primi lui b
    while (prime[d] * prime[d] <= b){
        d++;
        if (b % prime[d] == 0){
            fact[++cat] = prime[d];
            while (b % prime[d] == 0){
                b /= prime[d];
            }
        }
    }
    if (b > 1){
        fact[++cat] = b;
    }
    long long sol = a;
    ///luam toate pos
    for (int i = 1; i < (1 << cat); i++){
        long long nr = 0, prod = 1;
        for (int j = 0; j < cat; j++){
            if (((1 << j) & i) > 0){
                prod = 1LL * prod * fact[j + 1];
                nr++;
            }
        }
        if (nr % 2 == 1){
            nr = -1;
        }
        else{
            nr = 1;
        }
        sol = sol + 1LL * nr * a / prod;
    }
    return sol;
}

int main()
{
    calculare_ciur();
    int T;
    fin >> T;
    while (T--){
        long long a, b;
        fin >> a >> b;
        fout << dotest(a, b) << '\n';
    }
    return 0;
}
