#include <bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(), (a).end()
//#pragma GCC optimize("O3")
//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define sz() size()
#define fr first
#define sc second
#define pb push_back
#define er erase
#define in insert
#define pi pair<int,int>
#define pii pair<pair<int,int>,int>
#define mp make_pair
#define int long long
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
using namespace std;

const int mod=1e9+7;
const int modu=1999999973;
const int modul=998244353;

const int nmax=1000005;

int t,a,b;
vector<int>prim;
bitset<nmax>viz;

void ciur(){
    for(int i=2;i<nmax;i++){
        if(viz[i]==0){
            prim.push_back(i);
            for(int j=i+i;j<nmax;j+=i) viz[j]=1;
        }
    }
}

int32_t main(){
    ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
    srand(chrono::steady_clock::now().time_since_epoch().count());
    ifstream cin("pinex.in");
    ofstream cout("pinex.out");
    ciur();
    cin >> t;
    while(t--){
        cin >> a >> b;
        vector<int>divi;
        for(auto it:prim){
            if(it*it>b) break;
            if(b%it==0){
                divi.push_back(it);
                while(b%it==0) b/=it;
            }
        }
        if(b>=2) divi.push_back(b);
        int ans=0;
        for(int i=1;i<(1<<divi.size());i++){
            int prod=1;
            int cnt=0;
            for(int j=0;j<divi.size();j++){
                if(i&(1<<j)){
                    prod*=divi[j];
                    cnt++;
                }
            }
            if(cnt%2==0) ans-=(a/prod);
            else ans+=(a/prod);
        }
        cout << (a-ans) << '\n';
    }
}
