#include <fstream>
#include <vector>
#include <iomanip>
#include <map>
#define ll long long
using namespace std;
ifstream cin("pinex.in");
ofstream cout("pinex.out");
vector<ll> primes;
ll sum, ans, cnt;
ll a, b;
void bkt(ll pas)
{
    if(pas == primes.size())
    {
        if(cnt == 0)
            return;
        if(cnt % 2 == 0)
            sum -= a / ans;
        else
            sum += a / ans;
        return;
    }
    cnt++;
    ans *= primes[pas];
    bkt(pas + 1);
    ans /= primes[pas];
    cnt--;
    bkt(pas + 1);
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll m;
    cin>>m;
    while(m--)
    {
        cin>>a>>b;
        primes.clear();
        for(int d = 2; d * d <= b; d++)
        {
            ll e = 0;
            while(b % d == 0)
                b /= d, e++;
            if(e > 0)
                primes.push_back(d);
        }
        if(b > 1)
            primes.push_back(b);
        ans = 1;
        cnt = 0;
        sum = 0;
        bkt(0);
        cout<<a - sum<<'\n';
    }
    return 0;
}
