#include <bits/stdc++.h>
using namespace std;

const int MOD = 9973;
vector<long long> primes;

void ciur(int n)
{
    vector<bool> isPrime(n + 1, true);
    isPrime[0] = isPrime[1] = false;

    for (int i = 2; i <= n; i++)
    {
        if (isPrime[i])
        {
            primes.push_back(i);
            for (long long j = 1LL * i * i; j <= n; j += i)
                isPrime[j] = false;
        }
    }
}

long long power(long long a, long long b)
{
    long long res = 1;
    a %= MOD;
    while (b)
    {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
        b >>= 1;
    }
    return res;
}

long long inv(long long x)
{
    return power(x, MOD - 2);
}

int main()
{
    ifstream fin("ssnd.in");
    ofstream fout("ssnd.out");

    ciur(1000000);

    int t;
    fin >> t;

    while (t--)
    {
        long long n;
        fin >> n;

        long long copie = n;
        long long nr_div = 1;
        long long suma_div = 1;

        for (auto p : primes)
        {
            if (p * p > n) break;

            if (n % p == 0)
            {
                int cnt = 0;
                long long p_pow = 1;

                while (n % p == 0)
                {
                    n /= p;
                    cnt++;
                    p_pow *= p;
                }

                nr_div *= (cnt + 1);

                long long sus = (power(p, cnt + 1) - 1 + MOD) % MOD;
                long long jos = inv(p - 1);
                long long suma_p = sus * jos % MOD;

                suma_div = suma_div * suma_p % MOD;
            }
        }

        if (n > 1)
        {
            nr_div *= 2;

            long long sus = (power(n, 2) - 1 + MOD) % MOD;
            long long jos = inv(n - 1);
            long long suma_p = sus * jos % MOD;

            suma_div = suma_div * suma_p % MOD;
        }

        fout << nr_div << " " << suma_div << "\n";
    }

    return 0;
}
