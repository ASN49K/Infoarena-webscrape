#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("pinex.in");
ofstream cout("pinex.out");
vector<long long> divs;
bool ciur[1000005];
void precalc()
{
    ciur[0] = 1;
    ciur[1] = 1;

    for ( int i = 2; i <= 1e6 ; i ++ )
    {
        if (!ciur[i])
            for ( int j = i + i ; j <= 1e6 ; j += i )
            ciur[j] = 1;

        if (!ciur[i])
            divs.push_back(i);
    }
}

void solve()
{
    long long a , b ;
    cin >> a >>b ;

    vector<long long> fact;
    for ( int i  = 0 ; i < divs.size() ; i ++ )
    {
        if ( divs[i] * divs[i] > b )
            break;

            if ( b % divs[i] == 0 )
                fact.push_back(divs[i]);

        while ( b % divs[i] ==0 )
            b /= divs[i];
    }

    if ( b > 1  )
        fact.push_back(b);

    long long sz = fact.size() ;

    //cout << sz << '\n';
    long long ans = 0 ;
    for ( int i = 1; i < ( 1 << sz ) ; i ++ )
    {
        long long cnt = 0 ;
        long long nr = 1 ;
        for ( int j = 0 ; j < sz ; j ++  )
        {
            if ( ( 1 << j) & i   )
            {
                cnt ++;
                nr *= fact[j];
            }
        }


        if ( cnt % 2 == 0 )
        ans -= a / nr ;
        else
            ans += a / nr ;
    }

    cout << a - ans << '\n';
}
int main()
{
    precalc();

    sort(divs.begin(),divs.end());
    int test;
    cin >> test;
    while ( test -- )
    solve();
    return 0;
}
