/*
  ____   ___  _     ___ ____    _
 / ___| / _ \| |   |_ _/ ___|  / \
 \___ \| | | | |    | | |     / _ \
  ___) | |_| | |___ | | |___ / ___ \
 |____/ \___/|_____|___\____/_/   \_\

*/
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long int
#define pii pair<int,int>

const int NMAX = 2e5+9;

const int MOD = 1e9+7;

int binpow(int n, int k)
{
    if (k==0)
    {
        return 1;
    }
    int x=binpow(n,k/2)%MOD;
    if (k%2==0)
    {
        return x*x%MOD;
    }
    else
    {
        return x*x%MOD*n%MOD;
    }
}

ifstream fin ("pinex.in");
ofstream fout ("pinex.out");

#define cin fin
#define cout fout

int a,b;

vector<int>divs;

void run_case ()
{
    cin>>a>>b;
    divs.clear();
    int d=2;
    while (b>1)
    {
        int p=0;
        while (b%d==0)
        {
            b/=d;
            p++;
        }
        if (p)
        {
            divs.pb (d);
        }
        ++d;
        if (d*d>b && b>1)
        {
            break;
        }
    }
    if (b>1)
    {
        divs.pb (b);
    }
    int cntr=divs.size();
    int answer=0;
    for (int mask=1; mask<(1<<cntr); mask++)
    {
        int cnr=1;
        for (int i=0; i<cntr; i++)
        {
            if ((1<<i) & mask)
            {
                cnr*=divs[i];
            }
        }
        int counter=a/cnr;
        if (__builtin_popcount(mask)%2==0)
        {
            answer-=counter;
        }
        else
        {
            answer+=counter;
        }
    }
    cout<<a-answer<<'\n';
}

signed main ()
{
    ios_base::sync_with_stdio(0);
    cin.tie(NULL),cout.tie (NULL);
    int teste;
    cin>>teste;
    while (teste--)
    {
        run_case();
    }
}
