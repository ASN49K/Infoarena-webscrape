#include <iostream>
#include <cstdio>
#include <vector>
#define N 1000005

using namespace std;

int m, a, b, n, div[N], prim[N];
bool ciur[N];

void eratosnenes()
{
    for(int j=4;j<=N;j+=2)
        ciur[j]=1;
    prim[++prim[0]]=2;
    for(int i=3;i<=N;i+=2)
        if(!ciur[i])
        {
            for(int j=2*i;j<=N;j+=i)
                ciur[j]=1;
            prim[++prim[0]]=i;
        }
}

void divizori()
{
    long long nt=0, nd=1;
    while(prim[nd]*prim[nd]<=b)
    {
        nd++;
        if(b%prim[nd]==0)
        {
            div[++nt]=prim[nd];
            while(b%prim[nd]==0)
                b=b/prim[nd];
        }
    }
    if(b>1)
        div[++nt]=b;

    for(int i=1;i<(1<<nt);i++)
    {
        long long nr=0, p=1;
        for(int j=0;j<nt;j++)
            if((1<<j)&i)
                p=p*div[j+1], nr++;
        if(nr%2==0)
            n=n-1LL*a/p;
        else
            n=n+1LL*a/p;
    }
}

int main()
{
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w", stdout);

    scanf("%d\n", &m);
    eratosnenes();
    for(int test=1;test<=m;test++)
    {
        n=0;
        scanf("%d %d\n", &a, &b);
        divizori();
        printf("%d\n", a-n);
    }
    return 0;
}
