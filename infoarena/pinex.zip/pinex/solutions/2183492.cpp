#include <fstream>
using namespace std;
ifstream f("pinex.in");
ofstream g("pinex.out");
long long i,j,t;
bool ciur[1001*1001];
long long diviz,a,b,k=0,d[100001],v[10000001];
void CIUR()
{
    long long i,j;
    ciur[0]=ciur[1]=1;

    for(i=2;i*i<=1000005;i++)
        if(!ciur[i])
            for(j=i*2;j<=1000005;j+=i)
                ciur[j]=1;

    for(i=2;i<=1000005;i++)
        if(!ciur[i])
        {

            v[++k]=i;
        }

}
void desc(){
long long i=2,cnt=1;
while(b!=1&&v[cnt]*v[cnt]<=b){

    if(v[cnt]&&b%v[cnt]==0)
    {d[++diviz]=v[cnt];
    while(!(b%v[cnt])) b/=v[cnt];

    }

    cnt++;

}

if(b>1) d[++diviz]=b;

}
long long cmmmc(long long a,long long b){
long long q=a,p=b,r;
r=a%b;
if(a==0||b==0) return 0;
while(b){
  r=a%b;
  a=b;
  b=r;


}
if(a==0) return 0;
return (q*p)/a;

}
int main()
{f>>t;
CIUR();


for(k=1;k<=t;k++){
f>>a>>b;
long long s=0,cc=b;
diviz=0;
desc();
long long n=diviz;
long long nr=0,sol=1;
for(i=1;i<(1<<n);i++){
        nr=0;sol=1;
for(j=0;j<n;j++){
    if(i&(1<<j)){
       nr++;
   sol=cmmmc(sol,d[j+1]);


    }



}
if(nr%2==1) s+=a/sol;
else s-=a/sol;

}
g<<a-s<<'\n';
}





    return 0;
}
