#include <bits/stdc++.h>

using namespace std;

#define INFILE "pinex.in"
#define OUTFILE "pinex.out"

typedef long long ll;

const int N_MAX = 1e6;

vector<int> primes;

void init(){
    vector<bool> ciur(N_MAX + 1, true);
    ciur[0] = ciur[1] = false;
    for(int d = 2; d <= N_MAX; ++d){
        if(ciur[d]){
            primes.push_back(d);
            for(ll i = 1LL * d * d; i < N_MAX; i += d) ciur[i] = false;
        }
    }
}

void solve(){

    vector<ll> divisors;
    ll a, b; cin >> a >> b;

    bool ok = true;
    for(int i = 0; i < primes.size() && ok; ++i){
        int d = primes[i];
        if(1LL * d * d > b) ok = false;
        else {
            if(b % d == 0){
                divisors.push_back(d);
                while(b % d ==0) b /= d;
            }
        }
    }

    if(b > 1){
        divisors.push_back(b);
        b = 1;
    }

    int n = divisors.size();
    ll ans = 0;

    for(int mask = 1; mask < (1 << n); ++mask){
        int sign = -1;
        ll prod = 1;
        for(int i = 0; i < n; ++i){
            int good = ((mask >> i) & 1);
            if(good) sign *= -1, prod *= divisors[i];
        }
        ans += sign * (a / prod);
    }

    cout << a - ans << '\n';

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    int queries; cin >> queries;
    while(queries--) solve();
    return 0;
}
