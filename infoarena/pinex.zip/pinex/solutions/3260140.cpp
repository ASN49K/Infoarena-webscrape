#include <bits/stdc++.h>

using namespace std;
void solve()
{

    long long A, d=2, B, k=0, div[30];
    cin>>A>>B;
    while(B!=1)
    {
        if(B%d==0)
        {
            k++;
            div[k]=d;
            while(B%d==0)
                B/=d;
        }
        if(d>sqrt(B)&& B>1)
        {
            k++;
            div[k]=B;
            B=1;
        }
        if(d==2)
        d++;
        else d+=2;
    }
    long long sol=A;
    for(int mask=1;mask<(1<<k);mask++)
    {
        long long cnt=0, p=1;
        for(int i=0;i<k;i++)
        {
            if((1<<i)&mask)
            {
                p*=div[i+1];
                cnt++;
            }
        }
        if(cnt%2==0)
            sol+=A/p;

        else
            sol-=A/p;
    }
cout<<sol<<'\n';
}
int main()
{
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w",stdout);
    int m;
    cin>>m;
    while(m--)
    {
        solve();

    }
    return 0;
}
