#include <cstdio>
#include <vector>
#include <bitset>
#define Nmax 2000005

using namespace std;

bitset<Nmax> used;
vector<long long> primes;
vector<long long> primeDivisors;

void genPrimes()
{
  primes.emplace_back(2);
  for (int i = 3; i * i < Nmax; i += 2)
    if (!used[i]) {
      primes.emplace_back(i);
      for (int j = 3; i * j < Nmax; j += 2)
	used[i * j] = true;
    }
}

void getDivisors(long long B)
{
  primeDivisors.clear();
  for (int i = 0; primes[i] * primes[i] <= B; ++i) {
    if (B % primes[i] == 0)
      primeDivisors.emplace_back(primes[i]);
    while (B % primes[i] == 0)
      B /= primes[i];
  }
  if (B > 1)
    primeDivisors.emplace_back(B);
}

int main()
{
  freopen("pinex.in", "r", stdin);
  freopen("pinex.out", "w", stdout);

  genPrimes();
  int M;
  scanf("%d", &M);
  for (int i = 0; i < M; ++i) {
    long long A, B;
    scanf("%lld%lld", &A, &B);
    getDivisors(B);
    int limit = (1 << (int)primeDivisors.size());
    long long result = 0;
    for (int mask = 0; mask < limit; ++mask) {
        long long crt = 1;
	int bitCount = 0;
	for (int i = 0; i < primeDivisors.size(); ++i)
	  if (mask & (1 << i)) {
	    crt *= primeDivisors[i];
	    ++bitCount;
	  }
	if (bitCount & 1)
	  result -= A / crt;
	else
	  result += A / crt;
    }
    printf("%lld\n", result);  
  }
  
  return 0;
}
