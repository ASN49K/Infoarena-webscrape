#include <bits/stdc++.h>

using namespace std;
ifstream fin ("pinex.in");
ofstream fout ("pinex.out");

const int dim = 1e6 + 5;
const int Nmax = 1e6;

bitset <dim> ciur;
vector <int> prime;
int n;

void Eratostene()
{
    ciur[0] = ciur[1] = 1;
    for(int i = 4 ; i <= Nmax ; i += 2)
        ciur[i] = 1;
    prime.push_back(2);
    for(int i = 3 ; (long long) i <= Nmax ; i += 2)
        if(ciur[i] == 0)
            {
                prime.push_back(i);
                if(1LL*i*i <= Nmax)
                    for(long long j = i * i ; j <= Nmax ; j += 2 * i)
                        ciur[j] = 1;
            }
}

int main()
{
    Eratostene();
    fin >> n;
    for(int i = 1 ; i <= n ; ++i)
        {
            long long a , b , rasp;
            vector <int> factori;
            fin >> a >> b;
            int k = 0; rasp = a;
            for(int j = 0 ; (long long) prime[j] * prime[j] <= b ; ++j)
                if(b && b % prime[j] == 0)
                    {
                        factori.push_back(prime[j]);
                        while(b % prime[j] == 0) b /= prime[j];
                    }
            if(b > 1) factori.push_back(b);
            int N = (1 << factori.size());
            for(int j = 1 ; j < N ; ++j)
                {
                    int biti = 0;
                    long long r = 1;
                    for(int p = 0 ; p < (int) factori.size() ; ++p)
                        if(j & (1 << p))
                            {
                                biti++;
                                r *= factori[p];
                            }
                    if(biti % 2 == 1)
                        rasp -= a / r;
                    else
                        rasp += a / r;
                }
            fout << rasp << '\n';
        }
}
