/*
                    __
                   /\ \
 _ __   ___     ___\ \ \/'\     ___      __      ___     ___      __
/\`'__\/ __`\  /'___\ \ , <    / __`\  /'__`\  /' _ `\ /' _ `\  /'__`\
\ \ \//\ \L\ \/\ \__/\ \ \\`\ /\ \L\ \/\ \L\.\_/\ \/\ \/\ \/\ \/\ \L\.\_
 \ \_\\ \____/\ \____\\ \_\ \_\ \____/\ \__/.\_\ \_\ \_\ \_\ \_\ \__/.\_\
  \/_/ \/___/  \/____/ \/_/\/_/\/___/  \/__/\/_/\/_/\/_/\/_/\/_/\/__/\/_/


*/

#ifndef __AHA__HEADER
#define __AHA__HEADER

#include <bits/stdc++.h>
using namespace std;
#define g0 get<0>
#define g1 get<1>
#define g2 get<2>
#define ft first
#define sd second
#define sz(x) (i6) x.size()
#define psb(x) push_back(x)
#define ppb() pop_back()
#define bg(x) x.begin()
#define ed(x) x.end()
#define col(x) x.begin(), x.end()
#define srt(x) sort(x.begin(), x.end())

#define pq priority_queue
#define fn function
#ifdef LOCAL
#define git stauDBG_MACRO_NO_WARNING
#include <dbg.h>
#else
#define dbg(...)
#endif
#define endl '\n'

template <typename T>
using vec = vector<T>;
template <typename T>
using deq = deque<T>;
template <typename K, typename V>
using hmap = unordered_map<K, V>;

using str = string;
using vb = vec<bool>;

using byte = int8_t;
using i3 = int32_t;
using i6 = int64_t;
using i64 = int64_t;
using u3 = uint32_t;
using u6 = uint64_t;

using d6 = long double;

using p3 = pair<i3, i3>;
using vi3 = vec<i3>;
using vp3 = vec<p3>;

using p6 = pair<i6, i6>;
using vi6 = vec<i6>;
using vd6 = vec<d6>;
using vp6 = vec<p6>;
using vv = vec<vi6>;

using dp6 = deq<p6>;
using di6 = deq<i6>;

using mi6 = map<i6, i6>;
using mp6 = map<p6, i6>;
using si6 = set<i6>;
using hi6 = hmap<i6, i6>;

using bs = bitset<64>;

using graph = vv;
using matrix = vv;

const d6 EPS = 1 / 1000000.0;
const i6 ZERO = 0;
const i6 _0 = ZERO;
const i6 ONE = 1;
const i6 _1 = ONE;
const i6 INF = INT64_MAX / 4;
const i6 NINF = -INF;

namespace std {
template <typename T1, typename T2>
struct hash<pair<T1, T2>> {
  std::size_t operator()(const pair<T1, T2>& pair) const noexcept {
    return hash<T1>()(pair.first) ^ hash<T2>()(pair.second);
  }
};
}  // namespace std

template <typename T1, typename T2>
istream& operator>>(istream& stream, pair<T1, T2>& p) {
  stream >> p.ft;
  stream >> p.sd;
  return stream;
}

template <typename T1, typename T2>
ostream& operator<<(ostream& stream, const pair<T1, T2>& p) {
  return stream << p.ft << " " << p.sd;
}

template <typename T>
istream& operator>>(istream& stream, vec<T>& v) {
  if (v.empty()) {
    u6 len;
    stream >> len;
    v.assign(len, T());
  }
  for (auto i = 0; i < sz(v); i++) {
    stream >> v[i];
  }
  return stream;
}

template <typename T>
ostream& operator<<(ostream& stream, const vec<T>& v) {
  if (!v.empty()) {
    stream << v[0];
  }
  for (auto i = 1; i < sz(v); i++) {
    stream << " " << v[i];
  }
  return stream;
}

template <typename T>
istream& operator>>(istream& stream, deq<T>& v) {
  if (v.empty()) {
    u6 len;
    stream >> len;
    v.assign(len, T());
  }
  for (auto i = 0; i < sz(v); i++) {
    stream >> v[i];
  }
  return stream;
}

template <typename T>
ostream& operator<<(ostream& stream, const deq<T>& v) {
  if (!v.empty()) {
    stream << v[0];
  }
  for (auto i = 1; i < sz(v); i++) {
    stream << " " << v[i];
  }
  return stream;
}
#endif

i64 p[100000];
i64 len;
i64 a, b;
i64 res;

i64 primes[100000];
i64 pr = 0;
bool not_p[100000];
void all_primes() {
  i64 mx = 100000;

  primes[pr] = 2;
  pr++;
  for (i64 i = 2 * 2; i <= mx; i += 2) {
    not_p[i] = true;
  }

  for (i64 i = 3; i <= mx; i += 2) {
    if (!not_p[i]) {
      primes[pr] = i;
      pr++;
      for (i64 j = i * i; j <= mx; j += i) {
        not_p[j] = true;
      }
    }
  }
}

void solve(i64 idx, i64 tot, bool idk) {
  i64 add = 1;  // add
  if (!idk) {
    add = -1;  // subtract
  }

  for (i64 i = idx + 1; i < len; i++) {
    res += add * (a / (tot * p[i]));
    solve(i, tot * p[i], !idk);
  }
}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  // #ifdef LOCAL
  ifstream cin{"pinex.in"};
  ofstream cout{"pinex.out"};
  // #endif

  all_primes();

  i64 ttt;
  cin >> ttt;

  for (i64 tt = 0; tt < ttt; tt++) {
    cin >> a >> b;
    len = 0;

    for (i64 i = 0; primes[i] * primes[i] <= b; i++) {
      if (b % primes[i] == 0) {
        p[len] = primes[i];
        len++;
        while (b % primes[i] == 0) {
          b /= primes[i];
        }
      }
    }

    if (b > 1) {
      p[len] = b;
      len++;
    }

    res = a;
    solve(-1, 1, false);
    cout << res << endl;
  }

  return 0;
}
