#include <bits/stdc++.h>
#define int long long

using namespace std;

ifstream fin ("pinex.in");
ofstream fout ("pinex.out");

const int nmax=1e6;

vector <int> prime, fact;
bitset <nmax+5> ciur;

void eratostene ()
{
    ciur[0]=ciur[1]=true;
    for (int i=2; i*i<=nmax; i++)
    {
        if (!ciur[i])
        {
            for (int j=i*i; j<=nmax; j+=i)
                ciur[j]=true;
        }
    }
    for (int i=2; i<=nmax; i++)
    {
        if (!ciur[i])
            prime.push_back(i);
    }

}
void desc (int n)
{
    for (auto d:prime)
    {
        if (n%d==0)
        {
            fact.push_back(d);
            while (n%d==0)
                n/=d;
        }
    }
    if (n>1)
        fact.push_back(n);
}

int pinex (int n)
{
    int rez=0;
    for (int mask=1; mask<(1<<(fact.size())); mask++)
    {
        int cnt=0, p=1;
        for (int i=0; i<fact.size(); i++)
        {
            if (mask&(1<<i))
            {
                cnt++;
                p*=fact[i];
            }
        }
        if (cnt%2==0)
            rez-=n/p;
        else
            rez+=n/p;
    }
    return rez;
}

void solve ()
{
    int a, b;
    fin >> a >> b;
    fact.clear();
    desc(b);
    fout << a-pinex(a) << '\n';
}

signed main()
{
    eratostene();
    int t;
    fin >> t;
    for (int i=1; i<=t; i++)
        solve();
    return 0;
}
