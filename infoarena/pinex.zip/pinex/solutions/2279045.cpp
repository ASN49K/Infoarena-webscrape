#include <iostream>
#include <fstream>
using namespace std;
ifstream f("pinex.in");
ofstream g("pinex.out");
long long t,a,b,nr,v[101],i,j,nrc,rez,p;
int main()
{
    f>>t;
    while(t--)
    {
        f>>a>>b;
        nr=0;
        for(i=2;i*i<=b;i++)
        {
            if(b%i==0)
            {
                v[nr]=i;
                nr++;
                while(b%i==0)
                {
                    b=b/i;
                }
            }
        }
        if(b>1)
        {
            v[nr]=b;
        }
        rez=a;
        for(i=1;i<(1LL<<(nr+1));i++)
        {
            nrc=0;
            p=1;
            for(j=0;j<=nr;j++)
            {
                if(((1LL<<j)&i)!=0)
                {
                    nrc++;
                    p=p*v[j];
                }
            }
            if(nrc%2==1)
            {
                rez=rez-a/p;
            }
            else
            {
                rez=rez+a/p;
            }
        }
        g<<rez<<"\n";
    }
    return 0;
}
