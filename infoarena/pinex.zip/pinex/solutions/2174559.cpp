#include <cstdio>
#include <bitset>


using namespace std;

long long n, a, b, d[10005000], k;
bitset <10000005>c;

void ciur()
{
    for(int i=2;i<=1000000;i++)
        if(c[i]==0)
            for(int j=i+i;j<=1000000;j+=i)
                c[j]=1;
}

void diviz()
{
    int i=3;
    k=0;
    if(b%2==0)
    {
        d[k++]=2;
        while(b%2==0)
            b/=2;
    }

    for(i;i*i<=b;i++)
    {
            if(b%i==0)
            {
                while(b%i==0)
                    b/=i;
                d[k++]=i;
            }
    }
    if(b!=1)
        d[k++]=b;
}

void zero()
{
    for(int j=0;j<k;j++)
    {
        d[j]=0;
    }
    k=0;
}

long long subsir()
{
    long long m=1<<k;
    long long s=0;
    for(int i=1;i<m;i++)
    {
        long long p=1;
        long long nr=0;
        for(int j=0;j<k;j++)
        {
            if((i&(1<<j))!=0)
            {
                p*=d[j];
                nr++;
            }
        }
        if(nr%2==0)
            s-=(a/p);
        else s+=(a/p);
    }
    return s;
}

int main()
{
    freopen("pinex.in", "r", stdin);
    freopen("pinex.out", "w", stdout);
    scanf("%d", &n);
    //ciur();
    for(int i=1;i<=n;i++)
    {
        scanf("%d %d", &a, &b);
        diviz();
        printf("%d", a-subsir());
        zero();
        printf("\n");
    }


    return 0;
}
