#include <bits/stdc++.h>
#define pb push_back

using namespace std;

ifstream fin("pinex.in");
ofstream fout("pinex.out");

void debug_out() { cerr << '\n'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"

typedef pair<int,int> pii;
typedef long long int ll;
typedef long double ld;

const int DMAX = 1e6+10;

vector <int> prime;

bool uz[DMAX];
ll dp[32000];
int prm[32000];

ll ans;

void ciur();

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t,i,j,d,cate,mask,mask2,pos;
    ll a,n;

    ciur();

    fin>>t;
    while(t--){
        vector <ll> div;
        fin>>a>>n;
        for(d=0;prime[d]*prime[d] <= n;d++)
            if(n % prime[d] == 0){
                while(n % prime[d] == 0)
                    n/=prime[d];
                div.pb(prime[d]);
            }
        if(n > 1)
            div.pb(n);
        cate=div.size();
        dp[0]=1;
        ans=0;
        for(mask=1;mask<(1<<cate);mask++)
            for(pos=0;pos<cate;pos++)
                if(mask&(1<<pos)){
                    mask2=mask^(1<<pos);

                    dp[mask]=dp[mask2]*div[pos];
                    prm[mask]=prm[mask2]+1;

                    if(!dp[mask])
                        return 0;

                    if(prm[mask] & 1)
                        ans+=a/dp[mask];
                    else
                        ans-=a/dp[mask];
                    break;
                }
        fout<<a-ans<<'\n';
    }

    return 0;
}
void ciur(){
    ll i,j;
    for(i=2;i*i <= (int) 1e6;i++)
        if(!uz[i]){
            prime.pb(i);
            uz[i]=1;
            for(j=i*i;j <= (int) 1e6;j+=i)
                uz[j]=true;
        }
    for( ;i <= (int) 1e6;i++)
        if(!uz[i])
           prime.pb(i);
}
