#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

bool c[(1<<20)];
int n, pr[(1<<17)], p;
ll a, b;

int main(){
    ifstream cin ("pinex.in");
    ofstream cout ("pinex.out");
    cin >> n;
    for (int i=2; i<=1e6; i++){
        if (c[i]) continue;
        pr[++p] = i;
        for (int j=2*i; j<=1e6; j+=i) c[j] = 1;
    }
    for (int i=1; i<=n; i++){
        cin >> a >> b;
        for (int i=1; i<=p; i++){
            if (b % pr[i]) continue;
            while (b % pr[i]) b /= pr[i];
            a -= a/pr[i];
        }
        if (b > 1) a -= a/b;
        cout << a << '\n';
    }
    return 0;
}
