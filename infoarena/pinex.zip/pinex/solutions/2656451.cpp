#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho10
#define ll long long
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define all(a) (a).begin(), (a).end()
#define sz size
#define f first
#define s second
#define pb push_back
#define er erase
#define in insert
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define MAXN 100005
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll n,prim[1000005],viz[1000005],f[1000005],k=0,q=0,cnt=0;
int32_t main(){
CODE_START;
ifstream cin("pinex.in");
ofstream cout("pinex.out");
cin>>q;
viz[0]=1;
viz[1]=1;
for(ll i=2;i<=100000;i++)
{
    if(viz[i]==0){
        prim[k++]=i;
        for(ll j=2*i;j<=100000;j+=i){
            viz[j]=1;
        }
    }
}
while(q--){
        ll x,y,ans=0;
cin>>x>>y;
ll cnt=0;
for(ll i=0;i<k;i++)
{
    if(y%prim[i]==0){
       f[cnt]=prim[i];
       cnt++;
       while(y%prim[i]==0){
        y/=prim[i];
       }
    }
}
if(y>1){
    f[cnt]=y;
    cnt++;
}
for(ll mask=1;mask<(1<<cnt);mask++)
{
    ll s1=0,p=1;
    for(ll i=0;i<cnt;i++)
    {
if(mask&(1<<i)){
    p*=f[i];
    s1++;
}
    }
    if(s1%2){
        ans+=x/p;
    }else ans-=x/p;
}
cout<<x-ans<<endl;
}
}

