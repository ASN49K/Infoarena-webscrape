#include <bits/stdc++.h>
#define ll long long
#define LMAX 1000005
using namespace std;
ifstream fin("pinex.in");
ofstream fout("pinex.out");
ll t, a, b, fv[LMAX];
vector <ll> prim;

void ciur() {
    for (ll i = 2; i <= LMAX - 2; i += 2) {
        if (fv[i] == 1)
            continue;
        prim.push_back(i);
        for (ll j = i * 2; j <= LMAX - 2; j += i)
            fv[j] = 1;
        if (i == 2)
            --i;
    }
    return;
}

int main() {
    ciur();
    fin >> t;
    while (t--) {
        fin >> a >> b;
        ll nr = 0, prod = 1;
        vector <ll> div;
        for (ll i = 0; prim[i] <= b && prim[i] <= a && i < prim.size(); ++i) {
            if (b % prim[i] != 0)
                continue;
            div.push_back(prim[i]);
        }
        for (ll i = 0; i < div.size(); ++i) {
            if (div[i] == 0)
                continue;
            nr += a / div[i];
            prod *= div[i];
            for (ll j = i + 1; j < div.size(); ++j)
                if (div[j] != 0)
                    nr -= a / (div[i] * div[j]);
        }
        if (div.size() > 2)
            nr += a / prod;
        fout << a - nr << "\n";
    }
    return 0;
}
