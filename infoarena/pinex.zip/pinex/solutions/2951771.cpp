#include <fstream>
using namespace std;
ifstream fin ("pinex.in");
ofstream fout ("pinex.out");
long long x,i,j,d,a,b,s,pr;
int v[80005],l[80005],di[80005],ii,m,nrc,nr,k;
bool ciur[1000005];
int main()
{
    ciur[1]=1;
    for (i=2; i<=1000000; i++)
    {
        if (ciur[i]==0)
        {
            v[++k]=i;
            if (i<=10000)
            {
                for (j=i*i; j<=1000000; j=j+i)
                    ciur[j]=1;
            }
        }
    }
    fin>>m;
    for (ii=1; ii<=m; ii++)
    {
        for (j=1; j<=nr+1; j++)
            l[j]=0;
        s=0;
        fin>>a>>b;
        x=b;
        nr=0;
        for (d=1; d<=k&&v[d]*v[d]<=x; d++)
        {
            if (x%v[d]==0)
            {
                di[++nr]=v[d];
                while (x%v[d]==0)
                    x=x/v[d];
            }
        }
        if (x!=1)
            di[++nr]=x;
        while (l[nr+1]==0)
        {
            nrc=0;
            pr=1;
            for (i=1; i<=nr+1; i++)
            {
                if (l[i]==1)
                    l[i]=0;
                else
                {
                    l[i]=1;
                    break;
                }
            }
            if (l[nr+1]==0)
            {
                for (i=1; i<=nr; i++)
                {
                    if (l[i]==1)
                    {
                        pr=pr*di[i];
                        nrc++;
                    }
                }
                if (nrc%2==0)
                    s=s-a/pr;
                else
                    s=s+a/pr;
            }
        }
        fout<<a-s<<"\n";
    }
    return 0;
}
