#include <fstream>
#include <cmath>
#include <iomanip>

int main() {
	std::ifstream fin("aria.in");
	std::ofstream fout("aria.out");
	int nrn;
	double posx, posy, antx, anty, fstx, fsty;
	double ans = 0;
	fin >> nrn;
	fin >> antx >> anty;
	fstx = antx;
	fsty = anty;
	antx = 0;
	anty = 0;
	for (int index = 1; index < nrn; index++) {
		fin >> posx >> posy;
		posx -= fstx;
		posy -= fsty;
		ans += (posy * antx - posx * anty) / 2;
		antx = posx;
		anty = posy;
	}
	fout << std::fixed << std::setprecision(6) << ans;
}