#include <bits/stdc++.h>
#define int long long
using namespace std;
const int NMAX = 1e5+2;
using db = double;
int n;
double x[NMAX],y[NMAX];

ifstream fin("aria.in");
ofstream fout("aria.out");

db det(db a, db b, db c, db d, db e, db f, db g, db h, db i){
    /**
     a b c
     d e f
     g h i
    **/
    return a*e*i + d*h*c + b*f*g - c*e*g - f*h*a - d*b*i;
}

signed main()
{
    fin >> n;
    for(int i = 1; i <= n; i++){
        fin >> x[i] >> y[i];
    }
    x[++n] = x[1];
    y[n] = y[1];
    double ans = 0;
    for(int i = 2; i <= n; i++){
        ans += det(0,      0,      1,
                   x[i-1], y[i-1], 1,
                   x[i],   y[i],   1);
    }
    fout << fixed << setprecision(6) << ans*0.5;
    return 0;
}
