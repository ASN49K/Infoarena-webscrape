#include <bits/stdc++.h>
#define MAX 250005
using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

pair < long double , long double > v[100005];

int n;
long double sum;

int main(){
    in>>n;
    for(int i = 1; i <= n; i++)
        in>>v[i].first>>v[i].second;
    v[n + 1] = v[1];
    for(int i = 1; i <= n; i++)
        sum += v[i].first * v[i + 1].second - v[i + 1].first * v[i].second;
    out<<fixed<<setprecision(5)<<sum / 2.0;
}
