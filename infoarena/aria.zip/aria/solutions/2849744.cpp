#include <iostream>
#include <iomanip>

#define NMAX 100005

using namespace std;

typedef long double ld;

struct elem {
    ld x, y;
} a[NMAX];

int n;

int main()
{
    freopen("aria.in", "r", stdin);
    freopen("aria.out", "w", stdout);
    cin >> n;
    for(int i = 1; i <= n; ++i)
        cin >> a[i].x >> a[i].y;
    a[0] = a[n];
    ld arie = 0;
    for(int i = 1; i <= n; ++i)
        arie += 1ll * a[i - 1].x * a[i].y - 1ll * a[i - 1].y * a[i].x;
    cout << fixed << setprecision(7) << arie / 2.;
    return 0;
}
