#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

double det(int x1, int y1, int x2, int y2){
    return x1 * y2 - x2 * y1;
}

int main()
{
    cin.tie(nullptr);
    int n;
    cin >> n;
    if(n < 3){
        cout << 0;
        return 0;
    }
    double x1, y1;
    double sum = 0;
    cin >> x1 >> y1;
    for(int i = 2; i < n; i++){
        double x2, y2;
        cin >> x2 >> y2;
        sum += det(x1, y1, x2, y2);
        x1 = x2;
    }
    if(sum > floor(sum))
        cout << fixed << setprecision(5);
    cout << sum;
    return 0;
}
