#include <fstream>

#include <iostream>

#include <bits/stdc++.h>



using namespace std;



static inline double arie( double x2, double x1, double y2, double y1 ) {

   return ( x2 - x1 ) / 2 * ( y2 + y1 );

}

double a[100000];

double b[100000];



int main() {

   ios_base::sync_with_stdio( 0 );

   ifstream fin( "aria.in" );

   ofstream fout( "aria.out" );

   int n, i;

   long double sum = 0;

   fin >> n;

   for ( i = 0; i < n; i ++ ) {

       fin >> a[i] >> b[i];

   }

   for ( i = 0; i < n - 1; i ++ ) {

       sum += arie( a[i + 1], a[i], b[i + 1],  b[i] );

   }

   sum += arie( a[0], a[n - 1], b[0], b[n - 1] );

   sum = sum > 0 ? sum : -sum;

   fout << setprecision( 6 ) << fixed << sum;

   return 0;

}
