#include <bits/stdc++.h>
using namespace std;

#define x first
#define y second
#define pb push_back

ifstream f("aria.in");
ofstream g("aria.out");

int n;
long double aria;
vector<pair<double, double>> v;

int main(){
    f >> n;
    for (int i = 0; i < n; i++){
        double a, b; f >> a >> b;
        v.pb(make_pair(a, b));
    }
    for (int i = 1; i < n; i++)
        aria += (v[i].y * v[i - 1].x - v[i].x * v[i - 1].y);
    aria += v[0].y * v[n - 1].x - v[0].x * v[n - 1].y;
    aria /= 2.0;
    g << fixed << setprecision(6) << abs(aria);


    return 0;
}
