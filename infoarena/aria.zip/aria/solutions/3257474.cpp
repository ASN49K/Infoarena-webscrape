#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;

struct Point {
    long long x, y;
};

int main() {
    ifstream fin("aria.in");
    ofstream fout("aria.out");

    int n;
    fin >> n;

    Point v[n + 1];
    long double a = 0;

 
    for (int i = 0; i < n; i++) {
        fin >> v[i].x >> v[i].y;
    }
    v[n] = v[0]; 


    for (int i = 0; i < n; i++) {
        a += (v[i].x * v[i + 1].y) - (v[i + 1].x * v[i].y);
    }
    a = a / 2;
    if (a < 0) a *= -1;

    fout << fixed << setprecision(5) << a << "\n";

    return 0;
}

