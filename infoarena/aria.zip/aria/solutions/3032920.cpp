#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main() {
  int n;
  fin>>n;

  vector<long double> x(n), y(n);
  for (int i=0; i<n; ++i) fin>>x[i]>>y[i];

  long double a=0;
  for (int i=0; i<n; ++i) {
    int j=(i+1)%n;
    a += x[i]*y[j] - x[j]*y[i];
  }
  a = a*0.5;

  if (a<0) a = a*-1;
  fout<<fixed<<setprecision(10)<<a;
}