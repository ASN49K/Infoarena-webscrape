///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 1000000009
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct ceva
{
    long double x,y;
} v[100010];
int i,n;
long double s,det;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    v[0].x=v[n].x;
    v[0].y=v[n].y;
    for(i=0; i<n; i++)
    {
        det=v[i].x*v[i+1].y-v[i+1].x*v[i].y;
        s+=det;
    }
    fout<<fixed<<setprecision(6)<<s/2;
    return 0;
}
