#include <fstream>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n;

pair < double, double > v[100001];

int main()
{
    f >> n;

    for (int i = 1; i <= n; i++)
        f >> v[i].first >> v[i].second;

    double aria = 0;

    for (int i = 1; i < n; i++)
    {
        aria += v[i].first * v[i + 1].second;
        aria -= v[i].second * v[i + 1].first;
    }

    aria += v[n].first * v[1].second;
    aria -= v[n].second * v[1].first;

    if (aria < 0)
        aria = -aria;

    aria /= 2;

    g << aria << "\n";

    return 0;
}
