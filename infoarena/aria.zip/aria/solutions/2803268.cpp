#include <stdio.h>
using namespace std;
struct point {
    double x, y;
};
point points[100005];
 
double arie(point a, point b, point c) {
    return (double)(a.x * b.y + b.x * c.y + a.y * c.x - a.x * c.y - a.y *b.x - c.x*b.y);
}
double arie2(point b, point c) {
    return (double)(b.x*c.y - b.y*c.x);
}
int main()
{
    freopen("aria.in", "r", stdin);
	freopen("aria.out", "w", stdout);

 
    int n;
    double aria = 0;
    scanf("%d", &n);
 
    for (int i = 0; i < n; i++) {
		scanf("%lf %lf", &points[i].x, &points[i].y);
    }
    points[n] = points[0];
    for (int i = 1; i < n; i++) {
		point a = points[0], b = points[1], c = points[2];
		b.x -= a.x; b.y -= a.y;
		c.x -= a.x; c.y -= a.y;
        aria += arie(points[0], points[i], points[i + 1]);
    }
	printf("%.5lf\n", aria / 2);
	fclose(stdout);
	return 0;
}