/**#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream in("tabara.in");
ofstream out("tabara.out");
int v[50005];
int f(int x, int n, int k)
{
    int s = min(k, x);
    for(int i = 1; i <= n; i ++)
        s = s + min(x, v[i]);
    if(1LL * x * n <= s)
        return 1;
    return 0;
}
int32_t main()
{
    int n, k;
    in >> n >> k;
    for(int i = 1; i <= n; i ++)
        in >> v[i];
    int rez = 0, st = 1, dr = (1 << 30);
    while(st <= dr)
    {
        int mid = (st + dr) / 2;
        if(f(mid, n, k))
            rez = mid, st = mid + 1;
        else
            dr = mid - 1;
    }
    out << rez;
    return 0;
}
#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream in("oite.in");
ofstream out("oite.out");
int v[1005], s;
unordered_map <int, int> mp;
int32_t main()
{
    int n, k;
    in >> n >> k;
    for(int i = 1; i <= n; i ++)
        in >> v[i];
    sort(v + 1, v + n + 1);
    for(int i = 1; i <= n; i ++)
    {
        for(int j = i + 1; j <= n; j ++)
            s += mp[k - v[i] - v[j]];
        for(int j = 1; j < i; j ++)
            mp[v[i] + v[j]] ++;
    }
    out << s;
    return 0;
}*/
#include <bits/stdc++.h>
using namespace std;
ifstream in("aria.in");
ofstream out("aria.out");
double v[100005], c[100005];
int main()
{
    int n;
    in >> n;
    for(int i = 1; i <= n; i ++)
        in >> v[i] >> c[i];
    v[n + 1] = v[1];
    c[n + 1] = c[1];
    double s = 0;
    for(int i = 1; i <= n; i ++)
        s += (v[i] * c[i + 1]) - (v[i + 1] * c[i]);
    out << setprecision(5) << fixed << s / 2.0;
    return 0;
}
