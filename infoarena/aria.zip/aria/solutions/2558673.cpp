#include <fstream>
#include<iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct punct
{
    long double x,y;
};
punct a[100004];
long double aria;
int n,i;


int main(void)
{
    f>>n;
    for(i=1;i<=n;i++)
        f>>a[i].x>>a[i].y;
    a[n+1]=a[1];

    for (i=1;i<=n;i++)
        aria=aria+a[i].x*a[i+1].y-a[i].y*a[i+1].x;

    aria/=2;
    if (aria<0) aria*=-1;

   g<<fixed<<setprecision(6)<<aria;
    return 0;
}
