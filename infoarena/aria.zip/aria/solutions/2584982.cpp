#include <bits/stdc++.h>

using namespace std;

int main()
{
    ifstream fin("aria.in");
    ofstream fout("aria.out");

    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    srand(time(NULL));

    int n, arie = 0, fx, fy, x, y, x2, y2;

    fin >> n;

    fin >> x >> y;
    fx = x;
    fy = y;

    for(int i = 2; i <= n; i++)
    {
        fin >> x2 >> y2;

        arie += x * y2 - x2 * y;
        x = x2;
        y = y2;
    }

    arie += x * fy - fx * y;
    arie /= 2;

    fout << arie;

    fin.close();
    fout.close();
    return 0;
}
