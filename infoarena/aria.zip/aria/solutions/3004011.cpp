#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

double arie;

struct punct
{
    double x , y;
}a , b , first;

int n;

int main()
{
    f >> n;

    f >> a . x >> a . y;

    first = a;

    for ( int i = 2 ; i <= n ; i++)
    {
        f >> b . x >> b . y;

        arie = arie + (( a . x * b . y) - (a . y * b . x));

        a = b;
    }

    arie = arie + ( ( a . x * first . y) - (a . y * first . x));

    arie = arie / 2;

    g << fixed << setprecision(5) << arie;

    return 0;
}
