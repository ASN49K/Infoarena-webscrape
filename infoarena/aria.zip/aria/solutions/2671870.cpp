// Made by Alex Prohnitchi

#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>

typedef long long ll;

const ll mod=1e9+7;

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

#define all(x) x.begin(),x.end()
#define allr(x) x.rbegin(),x.rend()
#define rc(x)  return cout<<x<<"\n",0
#define sz(s)  (int) s.size()
#define pb push_back
#define mp make_pair
#define fr first
#define sc second
#define PI 3.14159265358979

using namespace std;

ll t;

int main() {
ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	ifstream cin("aria.in");
	ofstream cout("aria.out");
	vector<pair<double,double>>v;
	ll n;
	cin >> n;
	for (int i=1; i<=n; i++) {
		double a,b;
		cin >> a >> b;
		v.pb({a,b});
	}
	double sum=0;
	for (int i=0; i<n; i++) {
		sum+=(((v[i].fr*v[i+1].sc)-(v[i+1].fr*v[i].sc))/(double)2);
	}
	sum+=(((v[n-1].fr*v[0].sc)-(v[0].fr*v[n-1].sc))/(double)2);
	cout << setprecision(9) << sum << '\n';
}

