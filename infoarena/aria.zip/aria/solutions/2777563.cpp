#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
int n;
struct punct
{
    long double x, y;
};
long double arie(punct a, punct b)
{
    return a.x * b.y - a.y * b.x;
}

long double calculare_arie()
{
    punct primul, p1, p2;
    f >> primul.x >> primul.y;
    p1 = primul;
    long double suma = 0;
    for (int i = 2; i <= n; i++)
    {
        f >> p2.x >> p2.y;
        suma += arie(p1, p2);
        p1 = p2;
    }
    suma += arie(p2, primul);
    return abs(suma)/2;
}

int main()
{
    f >> n;
    if (n <= 2)
    {
        g << 0;
        return 0;
    }
    g << fixed << setprecision(5) << calculare_arie();
    return 0;
}
