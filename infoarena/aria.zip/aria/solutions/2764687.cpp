#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int main()
{
    int N;
    long double x1, y1, x2, y2, x3, y3,
         A = 0;
    f >> N >> x1 >> y1;
    x2 = x1;
    y2 = y1;
    while(--N)
    {
        f >> x3 >> y3;
        A += x2 * y3 - x3 * y2;
        x2 = x3;
        y2 = y3;
    }
    A += x2 * y1 - x1 * y2;
    A /= 2;
    if(A < 0) A = -A;
    g << fixed << setprecision(6) << A;
    return 0;
}
