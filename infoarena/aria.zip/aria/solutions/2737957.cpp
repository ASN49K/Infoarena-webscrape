#include <fstream>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;
vector<pair<double, double> > points;
void read_n_solve(){
    ifstream in("aria.in");
    ofstream out("aria.out");
    int n;
    in >> n;
    for(int i=0; i<n; i++){
        pair<double, double> aux;
        in >> aux.first >> aux.second;
        points.push_back(aux);
    }
    //sort(points.begin(), points.end());
    points.push_back(points[0]);
    double rez = 0;
    for(int i=0; i<points.size()-1; i++){
        rez += (points[i].first*points[i+1].second - points[i+1].first*points[i].second);
    }
    out << abs(rez/2) << '\n';
    in.close();
    out.close();
}

int main(){
    read_n_solve();
}
