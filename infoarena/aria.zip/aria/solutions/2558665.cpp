#include <fstream>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n, i;
double x[100002], y[100002];
double aria;

int main()
{
    f >> n;
    for (i=1; i<=n; i++)
        f >> x[i] >> y[i];

    x[n+1] = x[1];
    y[n+1] = y[1];

    for (i=2; i<=n+1; i++)
        aria += y[i] * x[i-1] - x[i] * y[i-1];

    if (aria < 0)
        aria = -aria;

    aria /= 2;

    g << aria;

    return 0;
}
