#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

int n;
double AriaPoligon;

struct punct {
int x, y;
}puncte[100005];

double distanta (int x, int y, int xx, int yy)
{
   double rez;
    rez = sqrt((x - xx) * (x - xx) + (y - yy) * (y - yy));
   return rez;
}

double ariatirunghi (int x, int y, int x2, int y2, int x3, int y3)
{
   double a, b, c, p, rez;
    a = distanta(x, y, x2, y2);
    b = distanta(x2, y2, x3, y3);
    c = distanta(x, y, x3, y3);
    p = (a + b + c) / 2;
     rez = sqrt(p * (p - a) * (p - b) * (p - c));
   return rez;
}

int main()
{
 int i, j;
 int x, y, x2, y2, x3, y3;
  f >> n;
   for (i=1; i<=n; i++)
   {
       f >> puncte[i].x;
       f >> puncte[i].y;
   }

   for (i=3; i<=n; i++)
   {
      x = puncte[1].x;
      y = puncte[1].y;
      x2 = puncte[i].x;
      y2 = puncte[i].y;
      x3 = puncte[i-1].x;
      y3 = puncte[i-1].y;
       AriaPoligon += ariatirunghi(x, y, x2, y2, x3, y3);
   }
  g << fixed << setprecision(6) << AriaPoligon;
    return 0;
}
