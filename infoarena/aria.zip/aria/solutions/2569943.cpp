#include <bits/stdc++.h>
#define FILE_NAME "aria"
#define fast ios_base :: sync_with_stdio(0); cin.tie(0);
#pragma GCC optimize("O3")
#define NMAX 100100
using namespace std;

ifstream f(FILE_NAME ".in");
ofstream g(FILE_NAME ".out");

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;
typedef pair<ll,ll> llp;
typedef pair<ld,ld> pct;

const ll inf = 1LL << 60;
const ll mod = 1e9 + 7;
const ld eps = 1e-9;


void add(ll &a , ll b)
{
    a += b;
    a %= mod;
}

void sub(ll &a, ll b)
{
    a = (a - b + mod) % mod;
}

int n;
pct v[NMAX];
ld ans;
int main()
{
    f >> n;
    for(int i = 1; i <= n; ++i)
        f >> v[i].first >> v[i].second;
    v[n + 1] = v[1];

    for(int i = 1; i <= n; ++i)
    {
        ans += (v[i].first * v[i + 1].second - v[i].second * v[i + 1].first) / 2;
    }
    g << setprecision(10) << fixed;
    g << ans;
    f.close();
    g.close();
    return 0;
}
