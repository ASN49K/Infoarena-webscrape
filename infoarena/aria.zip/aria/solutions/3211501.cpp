#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct Punct
{
    double x, y;
};
Punct a[100003];
int n;

/// A.x * B.y - A.y * B.x

int main()
{
    int i;
    double aria = 0;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    a[n + 1] = a[1];
    for (i = 1; i <= n; i++)
        aria += (a[i].x * a[i+1].y - a[i].y * a[i+1].x);
    aria = aria / 2;
    fout << setprecision(6) << fixed << aria << "\n";
    return 0;
}
