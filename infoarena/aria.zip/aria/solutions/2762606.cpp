#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int MAX = 100005;

struct punct {
    double x, y;
} vec[MAX];

int n;
double sol;

int main (void) {
    fin>>n;
    for(int i = 0; i < n; ++i)
        fin>>vec[i].x>>vec[i].y;
    vec[n] = vec[0];
    for (int i = 0; i < n; ++i)
        sol += (vec[i].x * vec[i + 1].y - vec[i + 1].x * vec[i].y);
    fout << sol / 2.0;
}
