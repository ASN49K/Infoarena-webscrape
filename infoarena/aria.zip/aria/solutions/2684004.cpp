#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

pair < double , double > v[100005];
int n;
double a;

int main()
{
    f >> n;
    for (int i=1;i<=n;i++) {
        f >> v[i].x >> v[i].y;
    }
    v[n+1].x = v[1].x;
    v[n+1].y = v[1].y;
    for (int i=1;i<=n;i++) {
        a += (v[i].x * v[i+1].y) - (v[i].y * v[i+1].x);
    }
    a = a/2.0;
    g << setprecision(7) << a;
    return 0;
}
