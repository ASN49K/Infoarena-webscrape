#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

const string myf = "aria";
ifstream fin(myf + ".in");
ofstream fout(myf + ".out");

#define x first
#define y second

int n;
vector<pair<long double, long double> > a;
int main() {

	long double ans = 0;

	fin >> n;
	a.resize(n);
	for (auto &i : a)
		fin >> i.x >> i.y;

	a.pb(a[0]);
	for (int i = 0; i < n; ++i) {
		ans = ans + a[i].x * a[i + 1].y - a[i].y * a[i + 1].x;
	}

	ans /= 2.0;

	fout << fixed << setprecision(6) << ans << '\n';

	fin.close();
	fout.close();
	return 0;
}