#include <bits/stdc++.h>
#define infile "aria.in"
#define outfile "aria.out"

using namespace std;

int n;
double x, y;
struct point
{
    double x;
    double y;
};

vector<point> v;

int main()
{
    ifstream f(infile);
    ofstream g(outfile);

    f >> n;
    for (int i = 0; i < n; ++i)
    {
        f >> x >> y;
        v.push_back({x, y});
    }
    v[n] = v[0];

    double ans = 0.0d;
    for (int i = 0; i < n; ++i)
    {
        ans += (v[i].x * v[i + 1].y - v[i + 1].x * v[i].y);
    }
    g << ans / 2.0d;

    f.close();
    g.close();
    return 0;
}
