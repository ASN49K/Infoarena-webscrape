#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin ("aria.in");
ofstream fout ("aria.out");
struct punct
{
    long double x,y;
};
punct v[100005];
int n,i,j,k;
int main()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin >> n;
    for (i=1;i<=n;i++)
    {
        fin >> v[i].x >> v[i].y;
    }
    long double answ = 0;
    v[n+1] = v[1];
    for (i=1;i<=n;i++)
        answ = answ + (v[i].x * v[i+1].y - v[i+1].x*v[i].y);
    fout << fixed << setprecision(6) << answ/2.0;
    return 0;
}
