#include <bits/stdc++.h>
using namespace std;

#define N 100005


int main()
{
    int n;
    long double area = 0;
    pair<double, double>a[N];
    ifstream fin("aria.in");
    ofstream fout("aria.out");
    fin >> n;
    for(int i = 0; i < n; i++){
        fin >> a[i].first >> a[i].second;
        area += (a[i - 1].first * a[i].second - a[i].first * a[i - 1].second) / 2;
    }
    area += (a[n - 1].first * a[0].second - a[0].first * a[n - 1].second) / 2;
    fout << fixed << setprecision(6);
    fout << area;
}
