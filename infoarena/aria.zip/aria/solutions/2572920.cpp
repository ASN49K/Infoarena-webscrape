#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

#define x first
#define y second

double cp(pair<double, double> a, pair<double, double> b) {
    return a.x * b.y - b.x * a.y;
}

int main() {
    int n; fin >> n;
    vector<pair<double, double>> pts(n + 1);
    for (int i = 0; i < n; i++)
        fin >> pts[i].x >> pts[i].y;
    pts[n] = pts[0];

    double area = 0;
    for (int i = 1; i <= n; i++)
        area += cp(pts[i - 1], pts[i]);
    fout << abs(area) / 2 << '\n';

    fout.close();
    return 0;
}
