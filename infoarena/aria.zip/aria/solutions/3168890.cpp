#include <bits/stdc++.h>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
const int N= 100010;
int n;
long double x[N],y[N],aria;
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
        f>>x[i]>>y[i];
    x[0]=x[n];y[0]=y[n];
    for(int i=1;i<=n;i++)
        aria+=(y[i-1]+y[i])*(x[i-1]-x[i]);

    if(aria<0)
        aria=-aria;

    g<<fixed<<setprecision(10)<<aria/2.0;
    return 0;
}
