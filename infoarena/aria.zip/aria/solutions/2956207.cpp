#include <bits/stdc++.h>
using namespace std;

template <typename T> ostream& operator<<(ostream &os, const vector<T> &v) { os << '{'; string sep; for (const auto &x : v) os << sep << x, sep = ", "; return os << '}'; }
template <typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
using i64 = long long int;

const int INF = INT_MAX, MOD = 1e9 + 7;
const long long LINF = LLONG_MAX;
const double EPS = 1e-9, PI = acos(-1);
const int dx[] = {0, 0, 0, -1, 1, -1, 1, 1, -1};
const int dy[] = {0, -1, 1, 0, 0, -1, 1, -1, 1};

int main() {
  ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
  /// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

  ifstream cin("aria.in");
  ofstream cout("aria.out");

  int N; cin >> N;
  long double area = 0;
  vector<pair<long double, long double>> points(N);
  for (int i = 0; i < N; i++) {
    cin >> points[i].first >> points[i].second;
    if (i == 0) continue;
    area += points[i - 1].first * points[i].second - points[i - 1].second * points[i].first;
  }
  area = 0.5 * (area + points[N - 1].first * points[0].second - points[N - 1].second * points[0].first);
  cout << fixed << setprecision(5) << area << "\n";

  return 0;
}
