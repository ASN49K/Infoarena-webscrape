#include <fstream>
#include <vector>
#include <queue>
#include <iomanip>
using namespace std;
using pii = pair<int,int>;
ifstream cin("aria.in");
ofstream cout("aria.out");
int n;
double a , b , c , d;
double area;
signed main()
{
    cin >> n;
    n--;
    cin >> a >> b;
    int oga = a , ogb = b;
    for(int i = 1 ; i <= n ; ++i)
    {
        cin >> c >> d;
        area += a*d - c*b;
        a = c;
        b = d;
    }
    area += a*ogb - b*oga;
    area /= 2;
    cout << fixed << setprecision(5) << area << '\n';
    return 0;
}

