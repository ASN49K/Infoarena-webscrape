// Made by Alex Prohnitchi

#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>

typedef long long ll;

const ll mod=1e9+7;

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

#define all(x) x.begin(),x.end()
#define allr(x) x.rbegin(),x.rend()
#define rc(x)  return cout<<x<<"\n",0
#define sz(s)  (int) s.size()
#define pb push_back
#define mp make_pair
#define fr first
#define sc second
#define PI 3.14159265358979

using namespace std;

ll t;

int main() {
ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	ifstream cin("aria.in");
	ofstream cout("aria.out");
	double a[100010],b[100010];
	ll n;
	cin >> n;
	for (int i=1; i<=n; i++) {
		cin >> a[i] >> b[i];
	}
	double sum=0;
	a[n+1]=a[1];
	b[n+1]=b[1];
	for (int i=1; i<=n; i++) {
		sum+=((a[i]*b[i+1])-(a[i+1]*b[i]));
	}
	cout << setprecision(9) << fabs(sum/double(2.000000)) << '\n';
}

