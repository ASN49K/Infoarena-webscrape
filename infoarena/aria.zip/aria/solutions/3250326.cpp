#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.in");
double arieSmechera(int x1 , int y1 , int x2 , int y2)
{
    return x1*y2-y1*x2;
}
double s,n,prevX,prevY,x,y,x1,y11;
int main()
{
    fin>>n;
    fin>>prevX>>prevY;
    x1=prevX;
    y11=prevY;
    for(int i=1;i<n;i++)
    {
        fin>>x>>y;

        s+=arieSmechera(x , y , prevX , prevY);
        prevX=x;
        prevY=y;
    }
    s+=arieSmechera(prevX , prevY , x1 , y11);
    fout<<abs(s);
    return 0;
}
