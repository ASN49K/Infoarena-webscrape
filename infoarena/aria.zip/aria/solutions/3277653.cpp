#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
double x[100005],y[100005],S;
int n;
void Citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>x[i]>>y[i];
}
double Aria(int i,int j)
{
    return x[i]*y[j]-x[j]*y[i];
}
void Rez()
{
    for(int i=1;i<n;i++)
        S+=Aria(i,i+1);
    S+=Aria(n,1);
    S=abs(S)/2;
}
int main()
{
    Citire();
    Rez();
    fout<<setprecision(6)<<fixed<<S<<" ";
    return 0;
}
