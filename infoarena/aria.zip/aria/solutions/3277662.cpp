#include <bits/stdc++.h>
using namespace std;

/// infoarena.ro/problema/aria
ifstream fin("aria.in");
ofstream fout("aria.out");

double x[100003], y[100003]; /// coord. punctelor
int n;
/// ret. aria triunghiului O Ai Aj
double Aria(int i, int j)
{
    return x[i] * y[j] - x[j] * y[i];
}

int main()
{
    double aria = 0;
    int i;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> x[i] >> y[i];
    for (i = 1; i < n; i++)
        aria += Aria(i, i + 1);
    aria += Aria(n, 1);
    aria = abs(aria) / 2.0;
    fout << setprecision(6) << fixed << aria << "\n";
    return 0;
}
