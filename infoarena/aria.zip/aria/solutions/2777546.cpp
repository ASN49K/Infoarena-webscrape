#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n;

struct punct {
    long double x, y;
} puncte[100005];

void citire() {
    for (int i = 1; i <= n; ++i) {
        f >> puncte[i].x >> puncte[i].y;
    }
    puncte[n + 1] = puncte[1];
}

long double arie(punct a, punct b) {
    return a.x * b.y - a.y * b.x;
}

long double calculare_arie() {
    long double suma = 0;
    for (int i = 1; i <= n; ++i) {
        suma += arie(puncte[i], puncte[i + 1]);
    }
    return abs(suma) / 2;
}

int main() {
    f >> n;
    if (n <= 2) {
        g << 0;
        return 0;
    }
    citire();
    g << fixed << setprecision(5) << calculare_arie();
    return 0;
}
