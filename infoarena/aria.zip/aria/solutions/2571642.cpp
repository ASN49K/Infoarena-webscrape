#include <bits/stdc++.h>
using namespace std;
const int MAX=100001;
int n;
struct punct
{
    double x,y;
};

punct v[MAX];

ifstream in("aria.in");
ofstream out("aria.out");

double a;
int main()
{
    in>>n;
    for(int i=1;i<=n;i++) in>>v[i].x>>v[i].y;

    for(int i=1;i<n;i++)
    {
        a+=v[i].x*v[i+1].y-v[i+1].x*v[i].y;
    }

    a+=v[n].x*v[1].y-v[1].x*v[n].y;

     out<<a/2.0;

    return 0;
}
