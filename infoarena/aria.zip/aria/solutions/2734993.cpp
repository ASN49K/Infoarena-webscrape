#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct point
{
    double x,y;
} v[100005];
int n;
double ans;
double aria(point a, point b, point c)
{
    a.x-=c.x;
    b.x-=c.x;
    a.y-=c.y;
    b.y-=c.y;
    return a.x*b.y-a.y*b.x;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    for(int i=2;i+1<=n;i++)
        ans+=aria(v[1],v[i],v[i+1]);
    ans/=2.0;
    ans=abs(ans);
    fout<<fixed<<setprecision(10)<<ans;
    return 0;
}
