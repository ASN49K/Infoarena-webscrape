#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#define infile "aria.in"
#define outfile "aria.out"
#define NMAX 100005

std::ifstream f(infile);
std::ofstream g(outfile);

typedef std::pair<double, double> pi;

std::vector<pi> v;
unsigned int n, i;
double x, y;

int main()
{
    f >> n;

    for (i = 0; i < n; ++i)
    {
        f >> x >> y;
        v.push_back(std::make_pair(x, y));
    }

    double sol = 0;

    v.push_back(v[0]);
    for (i = 0; i < n; ++i)
    {
        sol += (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);
    }

    g << std::fixed << std::setprecision(5) << fabs(sol / 2.0);
    return 0;
}
