#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n;

struct punct {
    double x, y;
};

double arie(punct a, punct b, punct c) {
    return abs(a.x * b.y + b.x * c.y + a.y * c.x - b.y * c.x - a.y * b.x - a.x * c.y) / 2;
}

double calculare_arie() {
    punct primul, p1, p2;
    f >> primul.x >> primul.y >> p2.x >> p2.y;
    double suma = 0;
    for (int i = 2; i < n; ++i) {
        f >> p1.x >> p1.y;
        suma += arie(primul, p1, p2);
        p2 = p1;
    }
    return suma;
}

int main() {
    f >> n;
    if (n <= 2) {
        g << 0;
        return 0;
    }
    g << calculare_arie();
    return 0;
}
