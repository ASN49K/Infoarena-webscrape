#include <fstream>
#define mF "aria"
std::ifstream in(mF ".in");
std::ofstream out(mF ".out");
#include <iomanip>
int main()
{
    int n; long double a, b, c, d, e, f, s = .0; in >> n >> a >> b;
    for (e = a, f = b; c = e, d = f, in >> e >> f, --n;) s += c * f - e * d;
    out << std::setprecision(7) << std::fixed << (s + c * b - a * d) / 2;
}
