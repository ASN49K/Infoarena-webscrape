#include<bits/stdc++.h>
using namespace std;
ifstream F("1.in");
ofstream G("1.out");
double a,b,c,d,e,f,g;
int main()
{
    for(F>>e>>a>>b,e=a,f=b;F>>c>>d;g+=a*d-b*c,a=c,b=d);
    return G<<fixed<<setprecision(5)<<(g+c*f-e*d)/2,0;
}
