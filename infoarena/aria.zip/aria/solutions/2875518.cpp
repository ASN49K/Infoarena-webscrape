#include <bits/stdc++.h>
#include <iomanip>
using namespace std;
ifstream fin ("aria.in");
ofstream fout("aria.out");
struct punct
{
    long double x,y;
}v[100010];
int n,i;
long double aria;
long double cp(punct a,punct b)
{
    return (a.x*b.y)-(a.y*b.x);
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    v[n+1]=v[1];
    for(i=1;i<=n;i++)
        aria=aria+1/2.00*cp(v[i],v[i+1]);
    fout<<fixed<<setprecision(5)<<aria<<'\n';
    return 0;
}
