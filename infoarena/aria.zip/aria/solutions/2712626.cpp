#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;

int main()
{
    fin >> n;

    int x, y, oldX, oldY, firstX, firstY;
    double s = 0;

    fin >> oldX >> oldY;

    firstX = oldX;
    firstY = oldY;

    for (int i = 1; i <= n; i++)
    {
        fin >> x >> y;

        s += (oldX * y - oldY * x);

        oldX = x;
        oldY = y;
    }

    s += (oldX * firstY - oldY * firstX);

    s /= 2.0;

    fout << fixed << setprecision(5) << s;

    fin.close();
    fout.close();
    return 0;
}