//
//  main.cpp
//  Pb aria, infoarena
//
//  Created by Petrisor Stefan on 15.11.2024.
//

#include <fstream>
#include <cmath>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");

int main() {
    int x,x1 = 0,y,y1 = 0,n;
    long long int a=0;
    f>>n;
    f>>x>>y;
    int xi=x,yi=y;
    for(int i=1;i<n;i++)
    {
        f>>x1>>y1;
        a+=(x*y1)-(x1*y);
        x=x1;y=y1;
        
    }
    a+=(x1*yi)-(xi*y1);
    a=abs(a);
    a=a/2;
    g<<a;
    return 0;
}
