#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
int px,py;
double aria(int x1,int y1,int x2,int y2)
{
    return (x1*(y2-0)+x2*(0-y1))/2;
}
struct punct
{
    int x;
    int y;
} A[1001];
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>A[i].x>>A[i].y;
    }
    py=0;
    px=0;
    double ARIE=0;
    for(int i=1;i<n;i++)
    {
        ARIE+=aria(A[i].x,A[i].y,A[i+1].x,A[i+1].y);
    }
    ARIE+=aria(A[n].x,A[n].y,A[1].x,A[1].y);
    fout<<ARIE;
    return 0;
}
