#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

///varianta cu triunghi

struct punct
{
    double x, y;
};

vector <punct> poligon;
int n;
long double x, y;

long double determinant(punct A, punct B, punct C)
{
    return A.x * B.y + B.x * C.y + C.x * A.y - B.y * C.x - C.y * A.x - A.y * B.x;
}

long double determinant2(punct A, punct B)
{
    return A.x * B.y - B.x * A.y;
}

void citire()
{
    fin >> n;
    for(int i = 0; i < n; i++)
    {
        fin >> x >> y;
        punct t;
        t.x = x;
        t.y = y;
        poligon.push_back(t);
    }
}

long double arie()
{
    int l = poligon.size();
    long double total = 0;
    for(int i = 0; i < l - 1; i++)
    {
        total += 0.5 * abs(determinant2(poligon[i], poligon[i + 1]));
    }
    total += 0.5 * abs(determinant2(poligon[l - 1], poligon[0]));
    return total;
}


int main()
{
    citire();
    fout << fixed << setprecision(5) << arie();
    return 0;
}
