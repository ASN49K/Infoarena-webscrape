#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

struct data
{
    long double x;
    long double y;
};

int n;
data cord[100041];

void read()
{
    fin >> n;
    for (int i=0;i<n;++i)
    {
        fin >> cord[i].x >> cord[i].y;
    }
}

long double abs(long double x)
{
    if (x<0)
        return -x;
    return x;
}

long double det_arie(long double ax, long double ay, long double bx, long double by)
{
    long double s=abs((ax*by-ay*bx)/2);
    return s;
}

int main()
{
    read();
   long double aria=0;
    for (int i=0;i<n;++i)
    {
        aria+=det_arie(cord[i].x,cord[i].y,cord[(i+1)%n].x,cord[(i+1)%n].y);
    }
    fout << setprecision(5) << aria;
    return 0;
}
