#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream f ( "aria.in" );
ofstream g ( "aria.out" );
struct punct
{
    long double x, y;
};
int main()
{
    punct pr, a, b;
    long double arie = 0;
    int n;
    f >> n;
    f >> pr.x >> pr.y;
    a = pr;

    for ( int i = 2; i <= n; i++ )
    {
        f >> b.x >> b.y;
        arie += ( a.x * b.y - a.y * b.x );
        a = b;
    }

    arie += ( pr.y * b.x - pr.x * b.y );
    g << setprecision ( 8 ) << arie / 2.0;
    return 0;
}
