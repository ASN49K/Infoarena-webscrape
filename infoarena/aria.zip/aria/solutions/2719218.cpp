#include <fstream>
#define mF "aria"
std::ifstream in(mF ".in");
std::ofstream out(mF ".out");
const int N = 100000;
#include <iomanip>
#include <tuple>
int main()
{
    int n; double a, b, c, d, e, f, s = .0; in >> n >> a >> b;
    for (e = a, f = b; c = e, d = f, in >> e >> f, --n;) s += c * f - e * d;
    out << std::setprecision(7) << std::fixed << (s + c * b - a * d) / 2;
}






