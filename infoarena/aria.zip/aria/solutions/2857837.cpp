#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair<ll, ll>
#define sz(x) (int)((x).size())
#define all(a) (a).begin(), (a).end()

/* int f[maxn],nf[maxn],inv[maxn];
const int M=998244353;
void init(){
    inv[1]=1; for (int i=2;i<maxn;i++) inv[i]=M-1ll*(M/i)*inv[M%i]%M;
    f[0]=nf[0]=1; for (int i=1;i<maxn;i++) f[i]=1ll*f[i-1]*i%M,nf[i]=1ll*nf[i-1]*inv[i]%M;
}
int C(int x,int y){return 1ll*f[x]*nf[y]%M*nf[x-y]%M;}*/
const ll mod = 1e9+7;
ll n, k, m, mi, ma;

void solve(){
	
	ifstream cin("aria.in");
	ofstream cout("aria.out");
	
	cin >> n;
	vector<ll> x, y;
	for(int i = 0; i<n; i++){
		ll X, Y;
		cin >> X >> Y;
		x.pb(X); y.pb(Y);
	}
	ll ans = 0; 
	for(int i = 0; i<n; i++){
		ll h = (i + 1)%n;
		ans += x[i]*y[h] - y[i]*x[h];
	}
	double r = ans*0.5;
	r = abs(r);
//	cout << setprecision(2) << r << "\n";
	cout << ans/2;	
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	int t=1;
	//cin >> t;
	while(t--) solve();
	
	return 0;
}

