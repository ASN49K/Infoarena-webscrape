#include <bits/stdc++.h>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");

int main()
{
    int n,i;
    long long x,y,x1,y1,x2,y2,s=0;
    f>>n;
    f>>x2>>y2;
    x1=x2;
    y1=y2;
    for(i=2;i<=n;i++)
    {
   f>>x>>y;
   s+=x*y1-x1*y;
   x1=x;
   y1=y;

    }
    s+=x1*y2-x2*y1;
    g<<abs(s);

    return 0;
}
