#include <bits/stdc++.h>
#define NMAX 100002
using namespace std;
ifstream  fin("aria.in");
ofstream fout("aria.out");
int N;

struct punct
{
    double x,y;
}v[NMAX];

void citire()
{
    fin>>N;

    for(int i=1; i<=N; i++)
    {
        fin>>v[i].x>>v[i].y;
    }
}

int main()
{
    citire();

    v[N+1]=v[1];
    double ans=0;
    for(int i=1; i<=N; i++)
    {
        ans=ans+v[i].x*v[i+1].y-v[i+1].x*v[i].y;
    }
    ans=fabs(ans)/2;

    fout<< fixed << setprecision(5) << ans << "\n";

    return 0;
}
