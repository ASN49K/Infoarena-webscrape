#include <stdio.h>

struct point {
  double x;
  double y;
} pcoord[100000];

int main() { 
  FILE *fin = fopen( "aria.in", "r" );
  FILE *fout = fopen( "aria.out", "w" );
  int n, i;
  long double area;

  fscanf( fin, "%d", &n );
  for ( i = 0; i < n; ++i ) {
	fscanf( fin, "%lf%lf", &pcoord[i].x, &pcoord[i].y );
  }
  area = 0;
  for ( i = 0; i < n; ++i ) {
    area += pcoord[i].x * pcoord[(i + 1) % n].y - pcoord[i].y * pcoord[(i + 1) % n].x;
  } 
  area /= 2;
  if ( area < 0 ) {
	area = -area;
  }
  fprintf( fout, "%Lf", area );
  fclose( fin );
  fclose( fout );
  return 0;
}
