#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;

ifstream cin ("aria.in");
ofstream cout ("aria.out");

const int Nmax = 1e5 + 5;

pair<int, int>v[Nmax];

long long det(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return (long long) abs(x1 * y2 + x2 * y3 + x3 * y1 - y2 * x3 - y3 * x1 - y1 * x2);
}

signed main()
{
    int n, i, in = 0, b = 0;
    long long arie = 0;
    cin >> n;
    for(i = 1; i <= n; i ++)
        cin >> v[i].first >> v[i].second;
    ///A = i + b / 2 - 1
    //A = arie, b = nr de pct de coord intregi de pe margini, in = nr de pct din interior
    //b = 2 * (A - i + 1)
    v[n + 1] = v[1];
    for(i = 1; i <= n ; i ++)
        arie += det(v[i].first, v[i].second, v[i + 1].first, v[i + 1].second, 0, 0);
   /* for(i = 1; i <= n; i ++)
        b += __gcd(abs(v[i].first - v[i + 1].first), abs(v[i].second - v[i + 1].second));*/
    double ras = arie / 2.0;
    cout << setprecision(5) << fixed << ras;
   // cout <<  arie - b / 2 + 1;
    return 0;
}
