#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int NMAX = 100000;

int N;

struct elem{
    long double x, y;
};

elem punct[NMAX + 5];

int main()
{
    fin >> N;
    for(int i = 1; i <= N; i ++)
    {
        fin >> punct[i].x >> punct[i].y;
    }
    punct[N + 1] = punct[1];
    long double ans = 0.0;
    for(int i = 1; i <= N; i ++)
    {
        ans += (long double)(punct[i].x * punct[i + 1].y - punct[i].y * punct[i + 1].x);
    }
    ans = ans / 2.0;
    fout << fixed << setprecision(6) << ans << '\n';
}
