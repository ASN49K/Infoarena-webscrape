#include <bits/stdc++.h>
using namespace std;
void DAU(const string& task = "") {
    if (!task.empty())
        freopen((task + ".in").c_str(), "r", stdin),
        freopen((task + ".out").c_str(), "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
}
void PLEC() {
    exit(0);
}
#define double long double
vector<pair<double, double>> v;
double res;
int n;
signed main() {
    DAU("aria");
    cin >> n;
    v.resize(n);
    for (pair<double, double>& P : v)
        cin >> P.first >> P.second;
    v.emplace_back(v[0]);
    for (size_t i = 1; i < v.size(); ++i)
        res += (v[i].first - v[i-1].first) * (v[i].second + v[i-1].second);
    res = abs(res) / 2;
    cout << fixed << setprecision(10) << res;
    PLEC();
}
