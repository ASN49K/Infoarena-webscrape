#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");


const int MAX=1e5;
int n,i;
pair <double,double> p[MAX+5];
double arie;

int det(int x1, int y1 ,int x2 ,int y2 ,int x3 ,int y3)
{
    return x1*y2+x2*y3+x3*y1-x1*y3-x2*y1-x3*y2;
}

int main()
{
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>p[i].first>>p[i].second;

    for (i=3; i<=n; i++)
        arie+=det(p[1].first,p[1].second,p[i-1].first,p[i-1].second,p[i].first,p[i].second);

    arie=abs(arie)/2.0;

    fout<<arie;
    return 0;
}
