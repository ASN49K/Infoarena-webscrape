#include <fstream>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int a,y[10001],x[10001],n,i,k=0,s=0;
int main()
{
   fin>>n;
    for(i=1;i<=n;i++)
        fin>>x[i]>>y[i];
    for(i=3;i<=n;i++)
    {
        a=x[1]*y[i-1]+y[1]*x[i]+x[i-1]*y[i]-x[1]*y[i]-y[1]*x[i-1]-y[i-1]*x[i];
        if(a<0)
            a=a*(-1);
        if(a%2==1)
            k++;
        a=a/2;
        s=s+a;
    }
    //if(k%2==0)
    fout<<s;
    //else
        //fout<<s+k/2<<".5";

    return 0;
}
