#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main()
{
    long long n;
    long double ac,bc,ap,bp,afirst,bfirst;
    long double aria = 0;
    fin>>n;
    fin>>ac>>bc;
    afirst = ac;
    bfirst = bc;
    for(int i = 1; i <= n-1; i++){
        ap = ac;
        bp = bc;
        fin>>ac>>bc;
        aria +=ac*bp - bc*ap;
    }
    aria += afirst*bc - bfirst*ac;
    fout.precision(8);
    fout<<abs(aria/2)<<'\n';
    return 0;
}

