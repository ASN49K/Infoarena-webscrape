#include <fstream>
#include <iomanip>
using namespace std;

struct Punct
{
    double x, y;
};

Punct P, A, B;
int n;
double Arie;

ifstream f("aria.in");
ofstream g("aria.out");

double det(const Punct &A, const Punct &B)
{
    double det = A.x  * B.y - A.y * B.x;
    return det;
}

int main()
{
    f >> n;
    f >> P.x >> P.y;
    A = P;
    while(f >> B.x >> B.y)
    {
        Arie += det(A, B);
        A = B;
    }
    Arie += det(A, P);
    Arie /= 2;
    g << fixed << setprecision(5) << Arie;
    return 0;
}
