#include <fstream>
#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

ifstream be("aria.in");
ofstream ki("aria.out");

int main()
{
    int n;
    be>>n;
    vector<pair<long double,long double> >a(n+1);
    for(int i=0;i<n;i++){
        be>>a[i].first>>a[i].second;
    }
    a[n].first=a[0].first,a[n].second=a[0].second;
    long double sum=0;
    for(int i=0;i<n;i++)
        sum+=((a[i].first*a[i+1].second)-(a[i+1].first*a[i].second));
    ki<<setprecision(10)<<sum/2.0;
    return 0;
}
