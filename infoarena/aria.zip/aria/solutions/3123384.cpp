#include <fstream>
#include <iomanip>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");
int n;
pair<int, int> v[100005];
long double arie = 0;

int det(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return (x2-x1) * (y3-y1) - (y2-y1) * (x3-x1);
}

int main()
{
    in>>n;

    for(int i = 1; i<=n; i++)
    {
        in>>v[i].first>>v[i].second;
    }

    v[0] = v[n];

    for(int i = 0; i<n; i++)
    {
        arie += det(v[0].first, v[0].second, v[i].first, v[i].second, v[i+1].first, v[i+1].second);
    }

    arie = arie / 2.0;

    out<<setprecision(5)<<fixed<<arie;

    return 0;
}
