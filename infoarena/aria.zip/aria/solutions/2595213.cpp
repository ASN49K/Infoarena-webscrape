#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

struct punct
{
    double x,y;
}P[100005];

int N;

double rez;

int main()
{
    fin >> N;
    int i;
    for (i=1;i<=N;++i)
    {
        fin >> P[i].x >> P[i].y;
    }
    P[N+1]=P[1];
    for (i=1;i<=N;++i)
    {
        rez+=(P[i].x*P[i+1].y-P[i+1].x*P[i].y);
    }
    rez/=2.0;
    fout << fabs(rez);
    fin.close();
    fout.close();
    return 0;
}
