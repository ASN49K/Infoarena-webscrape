#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(i) (cout<<#i<<" = "<<(i)<<'\n')

using ll = long long;
using ui = unsigned int;


const string fn = "aria";

ifstream fin(fn + ".in");
ofstream fout(fn + ".out");


#define x first
#define y second

using point = pair<long double, long double>;

int n;
vector<point> a;

int main() {

	fin >> n;
	a.resize(n + 1);
	for (auto &i : a)
		fin >> i.first >> i.second;
	a[n] = a[0];

	long double ans = 0;
	for (unsigned int i = 0; i < n; ++i)
		ans += (a[i].x * a[i + 1].y - a[i].y * a[i + 1].x);
	ans = ans / 2;
	ans = abs(ans);
	fout << fixed << setprecision(6) << ans << '\n';
	fin.close();
	fout.close();
	return 0;
}