#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int main()
{
    int n;
    long double x1,y1,x,y,ans=0,x2,y2;
    fin>>n>>x1>>y1;
    x2=x1;
    y2=y1;
    for(int i=1;i<n;i++)
    {
        fin>>x>>y;
        ans+=x1*y-x*y1;
        x1=x;
        y1=y;
    }
    ans+=x2*y1-x1*y2;
    fout<<setprecision(6)<<fixed<<ans/2;
    return 0;
}
