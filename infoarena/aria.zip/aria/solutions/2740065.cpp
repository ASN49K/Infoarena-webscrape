#include <fstream>
#include<iomanip>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct coordonate
{
    double x;
    double y;
};
struct coordonate v[100005];

int main()
{
    int n;
    double a = 0;
    cin >> n;

    for(int i = 0;i < n;i ++)
    {
        cin >> v[i].x >> v[i].y;
    }

    for(int i = 1;i < n;i ++)
    {
        a += ( v[i-1].x * v[i].y -  v[i].x * v[i-1].y) / 2;
    }
    a += ( v[n-1].x * v[0].y - v[n-1].y * v[0].x) / 2;

    cout <<setprecision(6) << fixed << a;

    return 0;
}
