#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct pct{
    double x, y;
};

const int N = 1e5 + 5;
pct v[N];

double det(double x1, double y1, double x2, double y2){
    return x1 * y2 - x2 * y1;
}

int main()
{
    cin.tie(nullptr);
    int n;
    cin >> n;
    if(n < 3){
        cout << 0;
        return 0;
    }
    long double sum = 0;
    for(int i = 0; i < n; i++)
        cin >> v[i].x >> v[i].y;
    v[n] = v[0];
    for(int i = 0; i < n; i++)
        sum += det(v[i].x, v[i].y, v[i + 1].x, v[i + 1].y) / 2.0;
    if(sum < 0)
        sum = -sum;
    cout << fixed << setprecision(6) << abs(sum);
    return 0;
}
