#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
typedef long long ll;
typedef long double ld;
int n;
struct point
{
    ld x,y;
} v[100005];
ld aria(point a,point b,point c)
{
    a.x-=c.x;
    b.x-=c.x;
    a.y-=c.y;
    b.y-=c.y;
    return a.x*b.y-a.y*b.x;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    ld ans=0;
    for(int i=1;i<=n;i++)
    {
        point a=v[i],b;
        if(i==n)
            b=v[1];
        else
            b=v[i+1];
        ans+=aria(a,b,{0,0});
    }
    ans=abs(ans);
    ans=ans/2.0;
    fout<<ans;
    return 0;
}
