#include <fstream>
#include <iomanip>
using namespace std;

int n;
long double arie;

struct poligon {
    long double x, y;
} p[100005];

void read() {
    int i;
    ifstream f("aria.in");
    f >> n;
    for (i = 1; i <= n; i++) 
        f >> p[i].x >> p[i].y;
    p[n + 1] = p[1];
}

void solve() {
    int i;
    for (i = 1; i <= n; i++)
        arie += (p[i].x * p[i + 1].y - p[i + 1].x * p[i].y);
}

void output() {
    ofstream g("aria.out");
    g << setprecision(10) << fixed << arie / 2.0;
    g.close();
}

int main() {
    read();
    solve();
    output();
    return 0;
}