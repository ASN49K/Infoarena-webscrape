#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e5+2;
int n,x[NMAX],y[NMAX];

ifstream fin("aria.in");
ofstream fout("aria.out");

int det(int a, int b, int c, int d, int e, int f, int g, int h, int i){
    /**
     a b c
     d e f
     g h i
    **/
    return a*e*i + d*h*c + b*f*g - c*e*g - f*h*a - d*b*i;
}

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> x[i] >> y[i];
    }
    x[++n] = x[1];
    y[n] = y[1];
    float ans = 0;
    for(int i = 2; i <= n; i++){
        ans += det(0,      0,      1,
                   x[i-1], y[i-1],   1,
                   x[i], y[i], 1);
    }
    cout << fixed << setprecision(5) << ans*0.5;
    return 0;
}
