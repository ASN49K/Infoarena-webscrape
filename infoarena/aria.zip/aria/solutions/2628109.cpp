#include <bits/stdc++.h>

using namespace std;
/**************************************/
ifstream f("aria.in");
ofstream g("aria.out");
/**************************************/
int n;
long  double aria=0;
long double x[100000] , y[100000];
/**************************************/
///----------------------------------------------------
inline void readInput()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
         f>>x[i]>>y[i];
    }
}
///----------------------------------------------------
inline void Solution()
{
    for(int i=1;i<=n;i++)
    {
        if(i!=n) aria+= x[i]*y[i+1]-x[i+1]*y[i];
        else aria+= x[i]*y[1]-x[1]*y[i];
    }
    if(aria<0) aria= -aria;
}
///----------------------------------------------------
inline void Afisare()
{
    g<< fixed << setprecision(5) << fabs(aria / 2.0);
}
///----------------------------------------------------
int main()
{
    readInput();
    Solution();
    Afisare();
    return 0;
}
