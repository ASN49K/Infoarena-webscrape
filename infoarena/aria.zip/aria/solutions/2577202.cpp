#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

ifstream inFile;
ofstream outFile;

struct Point
{
  int x, y;
};

double areaWithOrigin(Point a, Point b)
{
  return (double)(a.x * b.y - b.x * a.y) / 2;
}

int main()
{
  int n, a, b;
  double sum = 0;
  vector<Point> points;

  inFile.open("aria.in");
  outFile.open("aria.out");

  inFile >> n;

  for (int i = 0; i < n; i++)
  {
    inFile >> a >> b;
    points.push_back({a, b});
  };

  points.push_back(points[0]);

  for (int i = 0; i < n; i++)
  {
    sum += areaWithOrigin(points[i], points[i + 1]);
  }

  outFile << sum << "\n";
}
