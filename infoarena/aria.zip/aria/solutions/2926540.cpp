#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex<ld> cd;

typedef pair<int, int> pi;
typedef pair<ll,ll> pl;
typedef pair<ld,ld> pd;

typedef vector<int> vi;
typedef vector<ld> vd;
typedef vector<ll> vl;
typedef vector<pi> vpi;
typedef vector<pl> vpl;
typedef vector<cd> vcd;

template<class T> using pq = priority_queue<T>;
template<class T> using pqg = priority_queue<T, vector<T>, greater<T>>;

#define FOR(i, a, b) for (int i=a; i<(b); i++)
#define F0R(i, a) for (int i=0; i<(a); i++)
#define FORd(i,a,b) for (int i = (b)-1; i >= a; i--)
#define F0Rd(i,a) for (int i = (a)-1; i >= 0; i--)
#define trav(a,x) for (auto& a : x)
#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)

#define sz(x) (int)(x).size()
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define lb lower_bound
#define ub upper_bound
#define all(x) x.begin(), x.end()
#define ins insert

template<class T> bool ckmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int MOD = 123457;
const int INF = 1e9 + 7;
const char nl = '\n';
const int MX = 1e2 + 5;

ifstream fin("aria.in");
ofstream fout("aria.out");

void solve() {
    int n;
    fin >> n;
    int x[n + 2], y[n + 2];
    for (int i = 1; i <= n; ++i) {
        fin >> x[i] >> y[i];
    }
    x[n + 1] = x[1];
    y[n + 1] = y[1];
    float arie = 0;
    for (int i = 1; i <= n; ++i) {
        arie += (double)((fabs(x[i] * y[i + 1] - x[i + 1] * y[i])))/2; 
    }
    fout << arie;
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    cout.tie(0);

    int T = 1;
    //cin >> T;
    while (T--) {
        solve();
    }

    return 0;
}

//read the question correctly (ll vs int)
//what's the meaning of the problem ? Think outside the BOX !!!
//edge cases ?
//make it simple
//write everything (observations, edge cases, ideas, steps, methods, ..
