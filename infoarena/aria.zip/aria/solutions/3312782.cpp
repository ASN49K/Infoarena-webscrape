#include <bits/stdc++.h>
#define Mod 1000000007
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
pair<int, int> a[100005];

int Aria(pair<int, int> A, pair<int, int> B)
{
    return A.first * B.second - A.second * B.first;
}

int main()
{
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i].first >> a[i].second;
    int aria = 0;
    a[n + 1] = a[1];
    for (int i = 2; i <= n + 1; i++)
        aria += Aria(a[i - 1], a[i]);
    fout << fixed << setprecision(6) << 1.0 * aria / 2 << "\n";
    return 0;
}
