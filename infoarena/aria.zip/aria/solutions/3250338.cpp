///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 100000007
using namespace std;
ifstream fin("circular.in");
ofstream fout("circular.out");
long double ax,bx,ay,by,s,det;
int i,n;
struct ceva
{
    long double x,y;
} v[100010];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    v[0].x=v[n].x;
    v[0].y=v[n].y;
    for(i=0; i<n; i++)
    {
        det=v[i].x*v[i+1].y-v[i].y*v[i+1].x;
        s+=det;
    }
    cout<<setprecision(6)<<fixed<<s/2;
    return 0;
}
