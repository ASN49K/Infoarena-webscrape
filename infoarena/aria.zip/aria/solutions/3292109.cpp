#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#define int long long
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");


const int MAX=1e5;
int n,i;
pair <long double,long double> p[MAX+5];
long double arie;

signed main()
{
    fin>>n;
    for (i=1; i<=n; i++)
        fin>>p[i].first>>p[i].second;

    p[n+1]=p[1];
    for (i=1; i<=n; i++)
        arie+=p[i].first*p[i+1].second-p[i+1].first*p[i].second;


    arie=abs(arie)/2.0;

    fout<<fixed<<setprecision(8)<<arie;
    return 0;
}
