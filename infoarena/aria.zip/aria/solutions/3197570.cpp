#include <bits/stdc++.h>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

int main() {
    int n;
    in >> n;
    long double rez{};
    vector<pair<long double, long double>> date(n+1);
    for (auto& elem : date | views::take(n))
    {
        in >> elem.first >> elem.second;
    }
    date[n] = date[0];
    
    for (auto [punctA, punctB] : date | views::adjacent<2>)
    {
        rez += punctA.first * punctB.second 
            - punctA.second * punctB.first;
    }
    rez = rez / 2;
    out << fixed << setprecision(5) << rez;
}