#include <fstream>
#include <iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct indici
{
    double x,y;
}a[100005];
int n;
int main()
{
    f >> n;
    for ( int i = 1 ; i <= n ; i++)
        f >> a[i].x >> a[i].y;
    double aria = 0;
    for ( int i = 1 ; i < n ; i++)
    {
        aria += a[i].x * a[i+1].y;
        aria -= a[i+1].x * a[i].y;
    }
    aria += a[n].x * a[1].y;
    aria -= a[1].x * a[n].y;
    if( aria < 0)
        aria = - aria;
    aria = aria / 2;
    g <<fixed << setprecision(6) << aria;

}
