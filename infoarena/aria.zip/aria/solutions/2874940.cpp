#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct coordonate
{
    long double x,y;
}v[100002];
int n;
double sol;
int main()
{
    fin>>n;
    for (int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    v[0]=v[n];
    for (int i=1;i<=n;i++)
    {
        sol+=(v[i-1].x*v[i].y-v[i].x*v[i-1].y);
    }
    fout<<setprecision(6)<<fixed<<fabs(sol/2.0);
}
