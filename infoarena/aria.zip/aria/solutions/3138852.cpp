#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct Data{
int i, j;
}x[100001];

double Arie(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return x1*y2+x2*y3+y1*x3-x3*y2-x1*y3-x2*y1;
}

int main()
{   int n;
    double A=0;
    fin>>n;
    for(int i=1;i<=n;i++)
    fin>>x[i].i>>x[i].j;
    x[0]=x[1];

    for(int i=2;i<=n;i++)
    {A+=Arie(x[0].i, x[0].j, x[i-1].i, x[i-1].j, x[i].i, x[i].j);
     cout<<A<<" ";
    }
    fout<<fixed<<setprecision(6)<<A/2.0;
    return 0;
}
