#include<fstream>
#include<cmath>
std::ifstream fin("aria.in");
std::ofstream fout("aria.out");
int main()
{
    int n;
    double arie=0;
    fin>>n;
    double x0, y0, xprev, yprev, x1, y1;
    fin>>xprev>>yprev;
    x1=xprev, y1=yprev;
    for(int index=1; index<n; ++index)
    {
        fin>>x0>>y0;
        arie+=xprev*y0-yprev*x0;
        xprev=x0;
        yprev=y0;
    }
    arie+=xprev*y1-yprev*x1;
    fout<<std::fabs(arie/2.0);
    return 0;
}