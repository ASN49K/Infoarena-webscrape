#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct Punct
{
    long double x, y;
} a[100005];
int n;

int main()
{

    long double aria = 0;
    fin >> n;
    for (int i =1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    a[n + 1] = a[1];
    for (int i = 1; i <= n; i++)
        aria += (a[i].x * a[i + 1].y - a[i].y * a[i + 1].x);
    aria /= 2;
    if (aria < 0) aria = -aria;
    fout << setprecision(6) << fixed << aria << "\n";

    return 0;
}
