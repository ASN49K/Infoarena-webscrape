#include <bits/stdc++.h>
using namespace std;
#define int long long
ifstream in("aria.in");
ofstream out("aria.out");

struct point {
	long double x, y;
	void read() {
		in >> x >> y;
	}
	void write() {
		out << x << ' ' << y << '\n';
	}
	point operator - (const point &B) const {
		return point{x - B.x, y - B.y};
	}
	void operator -= (const point &B) {
		x -= B.x;
		y -= B.y;
	}
	long double operator * (const point &B) const {
		return x * B.y - y * B.x;
	}
	long double orientation(const point &A, const point &B) const {
		return (A - *this) * (B - *this);
	}
	long double dist(point A) {
		A -= *this;
		return A.x * A.x + A.y * A.y;
	}
	bool operator <(const point &A) {
		if(x == A.x) {
			return y < A.y;
		}
		return x < A.x;
	}
		
};

 
int32_t main() {
    int N;
    in >> N;
    vector<point> polygon(N);
	for(int i = 0; i < N; ++i) {
        polygon[i].read();
    }
    long double area = 0;
    for(int i = 0; i < N; ++i) {
        int j = (i + 1) % N;
        area += polygon[i] * polygon[j];
    }
    out << fixed << setprecision(10) << fabs(area) / 2.0 << '\n';
}