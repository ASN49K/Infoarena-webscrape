#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream in("aria.in");
ofstream out("aria.out");
const int maxn = 100005;
pair <long double, long double> v[maxn];

long double det(long double x1, long double y1, long double x2, long double y2, long double x3, long double y3)
{
    return (x1 * y2 + x2 * y3 + x3 * y1 - x3 * y2 - x1 * y3 - x2 * y1) / 2;
}

int main()
{
    int n;
    in >> n;
    long double arie = 0;
    for(int i = 1; i <= n; i++)
        in >> v[i].first >> v[i].second;
    v[n + 1] = v[1];
    for(int i = 1; i <= n; i++)
        arie = arie + det(0, 0, v[i].first, v[i].second, v[i + 1].first, v[i + 1].second);
    out << setprecision(6) << fixed << arie << "\n";
    return 0;
}
