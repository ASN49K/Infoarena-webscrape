
#include <fstream>
#include <cmath>
#include <algorithm>
#define N 1000002
#include <iomanip>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");

long double xG,yG;
struct bla
{
    long double x,y;
}v[N];
bool cmp(bla A, bla B)
{
    return (atan2(A.x-xG,A.y-yG)<atan2(B.x-xG,B.y-yG));
}
long double det(long double x1, long double y1, long double x2, long double y2)
{
    return (x1*y2-x2*y1);
}
int main()
{
    int n;
    f>>n;
    for(int i=1;i<=n;++i)
        f>>v[i].x>>v[i].y,xG=xG+v[i].x,yG=yG+v[i].y;
    xG=xG/n;
    yG=yG/n;
    sort(v+1,v+n+1,cmp);
    long double arie=0;
    v[n+1]=v[1];
    ++n;
    for(int i=2;i<=n;++i)
        arie=arie+det(v[i-1].x,v[i-1].y,v[i].x,v[i].y);
    arie=arie*0.5;
    g<<fixed<<setprecision(5)<<-arie;
    f.close();
    g.close();
    return 0;
}
