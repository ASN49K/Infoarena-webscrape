#include <fstream>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
class point {
public:
	double x, y;
	double operator*(point a) {
		return x * a.y - y * a.x;
	}
};
int n;
point v[100002];
int main() {
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> v[i].x >> v[i].y;
	}
	v[n] = v[0];
	double ans = 0;
	for (int i = 0; i < n; i++) {
		ans += (v[i] * v[i + 1]) / 2.0;
	}
	cout << ans;
}