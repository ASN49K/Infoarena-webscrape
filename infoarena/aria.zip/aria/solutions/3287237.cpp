#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");
struct Punct {
    double x, y;
} p[100002];
double rasp;
int n, i;

int main() {
	ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n;
    for(i = 1; i <= n; i++) fin >> p[i].x >> p[i].y;
    p[n + 1] = p[1];

    for(i = 1; i <= n; i++) rasp += (p[i].x * p[i + 1].y - p[i + 1].x * p[i].y);

    fout << setprecision(5) << fixed << (double)abs(rasp) / 2.0;

    return 0;
}
