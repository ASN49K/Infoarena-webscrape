#include <fstream>
#include <cmath>
using namespace std;
int main()
{
    unsigned int n;
    long double x1,x2,y1,y2,s=0;
    ifstream f("aria.in");
    ofstream g("aria.out");
    f>>n;
    for(unsigned int i=0;i<n;i+=2)
    {
        f>>x1>>y1>>x2>>y2;
        s+=(x1*y2-x2*y1);
    }
    if(floor(s)==ceil(s))
        g<<s<<".0000";
    else
        g<<s<<"0000";
    f.close();
    g.close();
    return 0;
}