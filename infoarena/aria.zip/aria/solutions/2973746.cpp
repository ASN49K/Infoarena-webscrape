#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct punct{
    double x,y;
}v[100010];

int n;
double s;
int main(){
    fin>>n;
    for(int i=0;i<n;i++)
        {fin>>v[i].x>>v[i].y;}
    v[n]=v[0];
    for(int i=0;i<n;i++)
        s += (v[i].x*v[i+1].y-v[i].y*v[i+1].x);
    fout<<setprecision(5)<<fixed<<fabs(s/2.0);
}
