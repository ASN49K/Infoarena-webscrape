#include <fstream>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct punct{
    long double x;
    long double y;
};
int main(){
    punct puncte[int(1e5) + 5];
    int n;
    long double arie = 0;
    fin >> n;
    for (int i = 1; i <= n; i++){
        fin >> puncte[i].x >> puncte[i].y;
    }
    puncte[n + 1].x = puncte[1].x;
    puncte[n + 1].y = puncte[1].y;
    for (int i = 1; i <= n; i++){
        arie += (puncte[i].x * puncte[i + 1].y - puncte[i + 1].x * puncte[i].y);
    }
    arie = abs(arie);
    fout << arie / 2.0;
    return 0;
}