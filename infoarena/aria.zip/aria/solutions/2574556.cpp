#include <fstream>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int NMAX = 1e5 + 3;

struct punct
{
	double x, y;
};

punct p, f, ant;
int n;

double rez;

inline double arie(punct a, punct b)
{
	return a.x * b.y - a.y * b.x;
}

int main()
{
	fin >> n;
	fin >> f.x >> f.y;
	ant = f;
	for (int i = 1; i < n; ++i)
	{
		fin >> p.x >> p.y;
		rez += arie(ant, p);
		ant = p;
	}
	rez += arie(ant, f);
	rez /= 2;
	fout << fixed << setprecision(5) << rez << "\n";
	return 0;
}
