#include <bits/stdc++.h>

using namespace std;
ifstream fin("arie.in");
ofstream fout("arie.out");
pair<int,int> puncte[100005];
int main()
{
    double arie=0;
    int i,n;
    fin>>n;
    for(i=1;i<=n;++i)
    {
        fin>>puncte[i].first>>puncte[i].second;
    }
    for(i=1;i<n;++i)
    {
        arie+=(puncte[i].first*puncte[i+1].second-puncte[i].second*puncte[i+1].first);
    }
    arie+=(puncte[n].first*puncte[1].second-puncte[n].second*puncte[1].first);
    fout<<arie/2;
    return 0;
}
