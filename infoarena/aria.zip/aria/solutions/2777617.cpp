#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct puncts
{
   long double x, y;
};
int n;
long double triunghi(puncts a, puncts b)
{
    return a.x*b.y-a.y*b.x;
}
long double prelucrare()
{
    puncts p1,copiep1,p;

    f>>p1.x>>p1.y;
    copiep1=p1;
    double long S=0;

    for(int i=2; i<=n; i++)
    {

        f>>p.x>>p.y;
        S+=triunghi(p1, p);
        p1=p;
    }

    S+=triunghi(p, copiep1);

    return abs(S)/2;
}
int main()
{
    f>>n;
    if (n<=2)
    {
        g<<0;
        return 0;
    }
    g<<fixed<< setprecision(5)<<prelucrare();
    return 0;
}
