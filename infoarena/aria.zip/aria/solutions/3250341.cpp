///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 100000007
using namespace std;
ifstream fin("aria.in");
ofstream fout("arie.out");
long double ax,bx,ay,by,s,det;
long long i,n;
struct ceva
{
    long double x,y;
} v[100010];
int main()
{

    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    v[0].x=v[n].x;
    v[0].y=v[n].y;
    for(i=0; i<n; i++)
    {
        det=v[i].x*v[i+1].y-v[i].y*v[i+1].x;
        s+=det;
    }
    cout<<fixed<<setprecision(6)<<s/2;
    return 0;
}
