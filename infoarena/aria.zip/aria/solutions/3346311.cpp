#include <bits/stdc++.h>

#define int long long

using namespace std;
double x[100001];
double y[100001];

signed main()
{
//    ifstream cin("aria.in");
//    ofstream cout("aria.out");
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x[i]>>y[i];
    }
    x[0]=x[n];
    y[0]=y[n];
    double ans=0;
    for(int i=1;i<=n;i++)
    {
        ans+=x[i]*y[i-1]-x[i-1]*y[i];
    }

    cout<<fixed<<setprecision(5)<<abs(ans/2);
    return 0;
}
