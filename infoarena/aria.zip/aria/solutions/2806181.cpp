#include <fstream>
#include <iomanip>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
///punctele sunt date in ordine trigonometrica
long double det(long double x1, long double y1, long double x2, long double y2)
{
    return (x1 * y2 - x2 * y1);
}
int main()
{
    int n;
    long double x1, y1, cx1, cy1, x2, y2, arie = 0;
    f >> n;
    f >> x1 >> y1;
    cx1 = x1, cy1 = y1;
    for (int i = 2;i <= n;++i)
    {
        f >> x2 >> y2;
        arie = arie + det(x1, y1, x2, y2);
        x1 = x2, y1 = y2;
    }
    arie = arie + det(x1, y1, cx1, cy1);
    arie = arie * 0.5;
    g << fixed << setprecision(5) << arie;
    f.close();
    g.close();
    return 0;
}