#include <bits/stdc++.h>

using namespace std;

template<typename T>
class point
{
public:
    T x,y;

    point() {}
    point(T _x, T _y) : x(_x), y(_y) {}

    friend T dist(point<T> _a, point<T> _b)
    {
        return sqrt((_a.x-_b.x)*(_a.x-_b.x) + (_a.y-_b.y)*(_a.y-_b.y));
    }

    friend istream &operator>>(istream &file, point<T> &_p)
    {
        file>>_p.x>>_p.y;
        return file;
    }
    friend ifstream &operator>>(ifstream &file, point<T> &_p)
    {
        file>>_p.x>>_p.y;
        return file;
    }
    friend ostream &operator<<(ostream &file, point<T> _p)
    {
        file<<_p.x<<' '<<_p.y;
        return file;
    }
    friend ofstream &operator<<(ofstream &file, point<T> _p)
    {
        file<<_p.x<<' '<<_p.y;
        return file;
    }
};

template<typename T>
class line
{
public:
    T a,b,c;
    line() {}
    line(T _a, T _b, T _c) : a(_a), b(_b), c(_c) {}
    line(point<T> _a, point<T> _b)
    {
        a = _b.y - _a.y;
        b = _a.x - _b.x;
        c = _b.x*_a.y - _b.y*_a.x;
    }

};

template<typename T>
T area(point<T> _a, point<T> _b, point<T> _c)
{
    return _a.x*_b.y + _a.y*_c.x + _b.x*_c.y - (_b.y*_c.x + _a.y*_b.x + _a.x*_c.y);
}

int main()
{
    ifstream fin ("aria.in");
    ofstream fout ("aria.out");
    ios::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    int n; fin>>n;
    point<double> p1,pfirst,O(0,0),p2;
    fin>>pfirst;
    p1 = pfirst;
    double sum=0;
    for(int i=1; i<n; i++)
    {
        fin>>p2;
        sum += area(O,p1,p2);
        p1 = p2;
    }
    sum += area(O,p2,pfirst);
    fout<<abs(sum)/2;
    return 0;
}
