#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
double px,py;
double aria(double x1,double y1,double x2,double y2)
{
    return (x1*(y2-0)+x2*(0-y1))/2;
}
struct punct
{
    double x;
    double y;
} A[100001];
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>A[i].x>>A[i].y;
    }
    py=0;
    px=0;
    double ARIE=0;
    for(int i=1;i<n;i++)
    {
        ARIE+=aria(A[i].x,A[i].y,A[i+1].x,A[i+1].y);
    }
    ARIE+=aria(A[n].x,A[n].y,A[1].x,A[1].y);
    fout<<fixed<<setprecision(5)<<ARIE;
    return 0;
}
