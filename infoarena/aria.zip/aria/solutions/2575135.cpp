#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct
{
    long double x,y;
}v[100100];

long double arie;
int i,p1,p2,n;

int main()
{
    f>>n;
    for(i=1;i<=n;i++)f>>v[i].x>>v[i].y;

    for(i=1;i<=n;i++)
    {
        p1=i;
        p2=i+1;if(p2>n)p2=1;

        arie+=(v[p1].x*v[p2].y - v[p2].x*v[p1].y)/2;
    }

    g<<fixed<<setprecision(5)<<arie;
    return 0;
}
