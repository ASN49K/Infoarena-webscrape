#include <bits/stdc++.h>
#define nmax 100005
#define x first
#define y second
using namespace std;
ifstream in("aria.in");
ofstream out("aria.out");
pair<long double,long double> v[nmax];
int main(){
    int n;
    in>>n;
    for(int i=0;i<n;i++){
        in>>v[i].x>>v[i].y;
    }
    v[n]=v[0];
    long double rez=0;
    for(int i=0;i<n;i++){
        rez+=(v[i].x*v[i+1].y-v[i].y*v[i+1].x);
    }
    out<<fixed<<setprecision(10)<<fabs(rez/2);
}