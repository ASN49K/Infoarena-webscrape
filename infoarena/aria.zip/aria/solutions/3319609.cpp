#include <iomanip>
#include <fstream>
#include <vector>
#include <cmath>
#define pdd pair<double, double>

using namespace std;

const string txt = "aria";
const int nmax = 1e5 + 5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n;
pdd v[nmax];

static double arie()
{
    double ans = 0;
    for (int i = 1; i <= n; i++)
    {
        int nxt = ((i + 1) % n == 0 ? n : (i + 1) % n);
        ans += ((1LL * v[i].first * v[nxt].second) - (1LL * v[nxt].first * v[i].second)) / 2.0;
    }

    ans = (ans < 0 ? -ans : ans);
    return (double)ans;
}

int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        f >> v[i].first >> v[i].second;

    double ar = arie();
    ar *= 100000; int x = (int)ar;
    g << x / 100000 << "." << x % 100000;
    return 0;
}