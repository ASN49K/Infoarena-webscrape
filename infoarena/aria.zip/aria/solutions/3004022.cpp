#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

struct pct{
long double x , y;
};

int n , i;

long double aria = 0.0;

vector <pct>v;

int main()
{
    f >> n;
    v.resize (n + 1);
    for (int i = 1 ; i <= n ; i++)
    {
        f >> v[i].x >> v[i].y;
    }
    for (int i = 1 ; i < n ; i++)
    {
        aria += (v[i].x * v[i + 1].y) - (v[i + 1].x * v[i].y);
    }
    aria += (v[n].x * v[1].y) - (v[1].x * v[n].y);
    aria /= 2;
    g << aria;
    return 0;
}
