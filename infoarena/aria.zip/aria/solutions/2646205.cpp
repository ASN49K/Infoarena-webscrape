#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
#define int ll

ifstream fin("aria.in"); ofstream fout("aria.out");
#define cin fin
#define cout fout

int t, n, m, k, a[300010], q, l, r;
double x[100010], y[100010];

int32_t main(){
INIT
cin>>n;
for(int i=1; i<=n; i++){
    cin>>x[i]>>y[i];
}
double A=0;
double x1=0, y1=0;

for(int i=2; i<=n; i++){
    double y2=y[i]-y[i-1], x2=x[i]-x[i-1];
    A=A+(x1*y2-x2*y1)/((double)2);
    x1=x1+x2; y1=y1+y2;
}
cout<<fixed<<setprecision(7)<<A;



return 0;
}



