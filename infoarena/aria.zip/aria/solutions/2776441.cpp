#include<cstdio>
long double a,b,x,y,X,Y,S,n;
int main()
{
    freopen("aria.in","r",stdin),freopen("aria.out","w",stdout),scanf("%Lf%Lf%Lf",&n,&a,&b);
    for(x=a,y=b;n;--n,x=X,y=Y)
        scanf("%Lf%Lf",&X,&Y),S+=x*Y-X*y;
    S+=x*b-a*y,printf("%.5Lf",S/2);
    return 0;
}
