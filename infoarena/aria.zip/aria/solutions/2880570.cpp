#include <fstream>
#include<iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");



struct punct {
    double x, y;
} vec[200001];

int n;
long double sol;

int main () {


 f>>n;
    for (int i = 0; i < n; ++i) {
        f>>vec[i].x>>vec[i].y;
    }
    vec[n] = vec[0];
    for (int i = 0; i < n; ++i)
        sol=sol+(vec[i].x * vec[i + 1].y - vec[i + 1].x * vec[i].y);
    g<<fixed<<setprecision(6)<<(long double)sol/2.0;
}
