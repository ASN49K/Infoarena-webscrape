#include <fstream>
#define sz 100000
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

int n;

struct poz{
int x;
int y;};

long long sol;

poz v[sz + 5];

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    v[n+1]=v[1];
    for(int i=1;i<=n;i++)
        sol = sol + (v[i].x * v[i+1].y - v[i].y * v[i+1].x);
    fout<<double(sol/2.0);
}
