#include <fstream>
#include <iomanip>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
const int lim=1e5+3;
long double x[lim];
long double y[lim];
long double modul(long double x)
{if(x<0) return -x;
return x;}
int main()
{
    int n; cin>>n;
    for(int i=1;i<=n;++i)
        cin>>x[i]>>y[i];
    x[n+1]=x[1];
    y[n+1]=y[1];
    long double area=0;
    for(int i=1;i<=n;++i)
        area+=x[i]*y[i+1]-x[i+1]*y[i];
    area=modul(area)/2;
    cout<<fixed<<setprecision(6)<<area;
    return 0;
}
