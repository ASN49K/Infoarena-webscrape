#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

struct punct {
    double x, y;
};

double aria(const punct &A, const punct &B, const punct &C) {
    double det = (A.x - B.x) * (B.y - C.y) - (A.y - B.y) * (B.x - C.x);
    return abs(det) / 2;
}

int main() {
    int n;
    double arie;
    punct A, B, C;
    f >> n;
    f >> A.x >> A.y
      >> B.x >> B.y
      >> C.x >> C.y;
    arie = aria(A, B, C);
    for (int i=4; i<=n; i++) {
        B = C;
        f >> C.x >> C.y;
        arie += aria(A, B, C);
    }
    g << fixed << setprecision(5) << arie;
    f.close();
    g.close();
    return 0;
}
