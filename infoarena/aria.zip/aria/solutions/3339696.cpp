#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int n,sum=0;
struct punct{
    int x,y;
}p[100001];

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>p[i].x>>p[i].y;
    }
    p[n+1].x=p[1].x;
    p[n+1].y=p[1].y;
    for(int i=1;i<=n;i++)
    {
        sum=sum+p[i].x*p[i+1].y-p[i].y*p[i+1].x;
    }
    fout<<sum*0.5;
    return 0;
}
