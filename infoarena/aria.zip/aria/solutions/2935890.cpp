#include <bits/stdc++.h>
using namespace std;

#define NMAX 100005

int main() {
	ifstream fin("aria.in");
	ofstream fout("aria.out");

	int n;
	fin >> n;

	pair<long double, long double> points[NMAX];
	for (int i = 1; i <= n; ++i)
		fin >> points[i].first >> points[i].second;

	points[n + 1] = points[1];

	long double area = 0.0;
	for (int i = 1; i <= n; ++i)
		area += points[i].first * points[i + 1].second - points[i].second * points[i + 1].first;

	fout << setprecision(32) << abs(area) / 2 << '\n';
}
