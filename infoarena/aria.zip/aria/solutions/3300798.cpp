#include <fstream>
#include <vector>

using namespace std;

int main()
{
    ifstream in("aria.in");
    ofstream out("aria.out");
    int n;
    in >> n;
    double aria = 0;
    double x_0, y_0;
    in >> x_0 >> y_0;
    double x_anterior = x_0;
    double y_anterior = y_0;
    for (int i = 1; i < n; i++)
    {
        double x_i, y_i;
        in >> x_i >> y_i;
        aria += (x_anterior - x_i) * (y_anterior + y_i);
        x_anterior = x_i;
        y_anterior = y_i;
    }
    aria += (x_anterior - x_0) * (y_anterior + y_0);
    out << aria / 2 << "\n";
    in.close();
    out.close();
    return 0;
}
