#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

int n;
long double AriaPoligon;

struct punct {
long double x, y;
}v[100015];

void read ()
{
 int i;
 long double xx, yy;
  f >> n;
   for (i=1; i<=n; i++)
   {
       f >> xx >> yy;
       v[i].x = xx;
       v[i].y = yy;
   }
  n ++;
  v[n].x = v[1].x;
  v[n].y = v[1].y;
}



void solve ()
{
 int i, j;
  for (i=1; i<=n; i++)
  {
     j = i + 1;
      AriaPoligon += (v[i].x * v[j].y);
      AriaPoligon -= (v[j].x * v[i].y);
  }
 if (AriaPoligon < 0)
    AriaPoligon = -AriaPoligon;
 AriaPoligon /= 2.0;
 g << fixed << setprecision(6) << AriaPoligon;
}

int main()
{
read();
solve();
    return 0;
}
