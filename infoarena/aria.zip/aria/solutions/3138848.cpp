#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct Data{
int i, j;
}x[100001];

long double Det(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return x1*y2+x2*y3+y1*x3-x3*y2-x1*y3-x2*y1;
}

int main()
{   long double A=0;
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
    fin>>x[i].i>>x[i].j;

    for(int i=3;i<=n;i++)
    A+=Det(x[1].i, x[1].j, x[2].i, x[2].j, x[i].i, x[i].j)/2.0;

    fout<<A;
    return 0;
}
