#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct pct{ long double x,y;} P[1000];

int n;
long double s=0;

void citire()
{
    fin>>n;
    for(int i=0; i<n; i++)
    fin>>P[i].x>>P[i].y;
}

void aria()
{
    for(int i=1; i<n; i++)
        s += (P[i-1].x*P[i].y - P[i].x*P[i-1].y);
    s += (P[n-1].x*P[0].y-P[0].x*P[n-1].y);

    fout<< s/2;
}

int main()
{
    citire();
    aria();
}
