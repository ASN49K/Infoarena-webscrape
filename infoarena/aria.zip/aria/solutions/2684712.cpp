#include <bits/stdc++.h>
#define x first
#define y second

using namespace std;
using ld = long double;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main() {
    int N;
    fin >> N;
    vector<pair<ld,ld>> a(N + 1);
    for(auto &x : a)
        fin >> x.x >> x.y;
    a[N] = a[0];
    ld sol = 0;
    for(int i = 0; i < N; ++i)
        sol += (a[i].x * a[i + 1].y - a[i + 1].x * a[i].y);
    fout << fixed << setprecision(8) << fabs(sol / 2.0);
    return 0;
}
