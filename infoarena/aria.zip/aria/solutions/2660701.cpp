//#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
pair<double,double> v[100005];
double calc_area(pair<double,double> a,pair<double,double> b,pair<double,double> c){
    double a1=a.first,
    a2=a.second,
    b1=b.first,
    b2=b.second,
    c1=c.first,
    c2=c.second;
    return a1*b2+b1*c2+c1*a2-b2*c1-c2*a1-a2*b1;
}
int main()
{
    int n;
    double sum=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>v[i].first>>v[i].second;
    }
    for(int i=0;i<n;i++){
        sum+=calc_area(make_pair(0,0),v[i],v[(i+1)%n]);
    }
    cout<<fixed<<setprecision(5)<<sum/2;
    return 0;
}
