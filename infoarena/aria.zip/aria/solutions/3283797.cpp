#include <bits/stdc++.h>

#define int long long

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

int n;
int x[100005], y[100005];

signed main() {
    in >> n;
    for(int i = 1; i <= n; i++) {
        in >> x[i] >> y[i];
    }
    int aria = (x[n] * y[1] - x[1] * y[n]) / 2;
    for(int i = 1; i < n; i++) {
        aria += (x[i] * y[i + 1] - x[i + 1] * y[i]) / 2;
    }
    out << aria << '\n';
    return 0;
}
