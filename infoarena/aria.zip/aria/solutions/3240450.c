#include <stdio.h>

int main() {
    FILE *in = fopen("aria.in", "r");
    FILE *out = fopen("aria.out", "w");

    if (in == NULL || out == NULL) {
        printf("Eroare la deschiderea fișierelor!\n");
        return 1;
    }

    int n;
    fscanf(in, "%d", &n);

    int x1, y1, x2, y2;

    int a, b; // x1 = xn+1 = a
    fscanf(in, "%d%d", &a, &b);

    x1 = a; // xn+1
    y1 = b; // yn+1

    int arie = 0;
    for(int i = 1; i < n; i++) {
        fscanf(in, "%d%d", &x2, &y2);
        arie = arie + (x1 * y2 - x2 * y1);
        x1 = x2;
        y1 = y2;
    }
    arie = arie + (x1 * b - a * y1);
    arie = arie / 2;

    if (arie < 0) {
        arie = -arie;
    }
    
    fprintf(out, "%d\n", arie);

    fclose(in);
    fclose(out);

    return 0;
}
