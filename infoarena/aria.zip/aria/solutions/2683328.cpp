#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define MOD 1000000007

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef double ld;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
vector<pair<double, double>> v;


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    fin >> n;
    for (int i = 0; i < n; i++) {
        double x, y;
        fin >> x >> y;
        v.pb(make_pair(x, y));
    }

    v.pb(v.front());
    
    double area = 0;
    for (int i = 0; i < n; i++) {
        area += 0.5 * (v[i].first * v[i + 1].second - v[i].second * v[i + 1].first);
    }

    fout << fixed << setprecision(9) << area << "\n";

    return 0;
}