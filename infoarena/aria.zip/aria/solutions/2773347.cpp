#include <bits/stdc++.h>
#include <iomanip>
using namespace std;
ifstream fin ("aria.in");
ofstream fout("aria.out");
struct ceva
{
    double x,y;
}v[100010];
int n,i;
double ans;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    v[n+1]=v[1];
    for(i=1;i<=n;i++)
        ans=ans+(v[i].x*v[i+1].y)-(v[i+1].x*v[i].y);
    fout<<fixed<<setprecision(5)<<fabs(ans/2);
    return 0;
}
