#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
double arie(double xa, double ya, double xb, double yb, double xc, double yc)
{
	double a;
	a = xa * yb + ya * xc + xb * yc - xa * yc - ya * xb - yb * xc;
	if (a < 0) return 0 - (a / 2);
	else return a / 2;
}
int n, i;
double x[100001], y[100001],arietot;
int main()
{
	fin >> n;
	for (i = 1; i <= n; i++)
		fin >> x[i] >> y[i];
	for (i = 2; i < n; i++)
		arietot += arie(x[1], y[1], x[i], y[i], x[i + 1], y[i + 1]);
	fout <<arietot;
	return 0;
}