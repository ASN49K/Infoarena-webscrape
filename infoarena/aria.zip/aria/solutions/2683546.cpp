#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

struct data
{
    float x;
    float y;
};

int n;
data cord[100041];

void read()
{
    fin >> n;
    for (int i=0;i<n;++i)
    {
        fin >> cord[i].x >> cord[i].y;
    }
}

float abs(float x)
{
    if (x<0)
        return -x;
    return x;
}

float det_arie(float ax, float ay, float bx, float by)
{
    float s=abs((ax*by-ay*bx)/2);
    return s;
}

int main()
{
    read();
    float aria=0;
    for (int i=0;i<n;++i)
    {
        aria+=det_arie(cord[i].x,cord[i].y,cord[(i+1)%n].x,cord[(i+1)%n].y);
    }
    fout << fixed << setprecision(5) << aria;
    return 0;
}
