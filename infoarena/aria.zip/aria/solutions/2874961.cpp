#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
class point {
public:
	long double x, y;
	long double operator*(point a) {
		return x * a.y - y * a.x;
	}
};
int n;
point v[100002];
int main() {
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> v[i].x >> v[i].y;
	}
	v[n] = v[0];
	long double ans = 0;
	for (int i = 0; i < n; i++) {
		ans += (v[i].x * v[i + 1].y-v[i].y*v[i+1].x);
	}
	cout << setprecision(6) << fixed << fabs(ans / 2.0);
}