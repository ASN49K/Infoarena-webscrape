#include <fstream>
#include <utility>
#include <iomanip>

using namespace std;
typedef long long ll;
const int NMAX = 100000;

ifstream fin("aria.in");
ofstream fout("aria.out");

pair<int, int> v[NMAX + 5];

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);

    ll ans = 0;
    int n,i;
    fin >> n;
    for(i = 1; i <= n; i++)
        fin >> v[i].first >> v[i].second;
    v[n + 1].first = v[1].first;
    v[n + 1].second = v[1].second;
    for(i = 1; i <= n; i++)
        ans = ans + (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);
    fout << fixed << setprecision(5) << ans / 2.0;
    return 0;
}
