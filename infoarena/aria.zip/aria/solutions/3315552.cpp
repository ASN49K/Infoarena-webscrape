#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
const int Nmax = 100005;
long double x[Nmax], y[Nmax];
int main()
{
    long double arie = 0;
    int n, i;
    fin >> n;
    for ( i = 1; i <= n; ++i )
    {
        fin >> x[i] >> y[i];
    }
    for ( i = 2; i <= n; ++i )
    {
        arie +=  x[i - 1] * y[i] - x[i] * y[i - 1];
    }
    arie +=  x[n] * y[1] - x[1] * y[n];
    if (arie < 0 )
        arie = -arie;

    fout << fixed << setprecision(6) << arie / 2 << endl;



    return 0;
}
