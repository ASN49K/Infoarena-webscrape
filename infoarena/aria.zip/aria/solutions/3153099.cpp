#include <fstream>

using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
struct ura
{
    double x,y;
}v[100002];
int main()
{
    int n,i;
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;
    if(n<3)
        cout<<0;
    else
    {
        double rez=0,x1,x2,y1,y2;
        v[n+1].x=v[1].x;
        v[n+1].y=v[1].y;
        for(i=1;i<=n;i++)
        {
            x1=v[i].x;
            x2=v[i+1].x;
            y1=v[i].y;
            y2=v[i+1].y;
            rez+=(x1*y2-y1*x2)/2;
        }
        cout<<rez;
    }
    return 0;
}
