#include <cstdio>
#include <iomanip>
using namespace std;

int n;
long double x[100003], y[100003];


FILE* fin, * fout;

int main()
{
    fin = fopen("aria.in", "r");
    fout = fopen("aria.out", "w");


    fscanf(fin, "%d", &n);
    for (int i = 0; i < n; i++)
    {
        fscanf(fin, "%Lf %Lf", &x[i], &y[i]);
    }
    x[n] = x[0];
    y[n] = y[0];
    long double aria = 0.0;
    for (int i = 0; i < n; i++)
    {
        aria += ((long double)x[i] * y[i + 1] - (long double)x[i + 1] * y[i]);
    }
    aria /= 2.0;
    fprintf(fout, "%Lf", aria);
    return 0;
}