#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <climits>
using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

struct point {
long double x , y;
};

int n , i;

long double aria = 0;

vector < point > v;

int main()
{
    f >> n;
    v.resize (n);
    for (int i = 1 ; i <= n ; i++)
        f >> v[i].x >> v[i].y;
    aria = 0;
    for (int i = 1 ; i < n ; i++)
    {
        aria += (v[i].x * v[i + 1].y) - (v[i + 1].x * v[i].y);
    }
    aria += (v[n].x * v[1].y) - (v[1].x * v[n].y);
    aria /= 2.0;
    g << fixed << setprecision (6) << aria;
    return 0;
}
