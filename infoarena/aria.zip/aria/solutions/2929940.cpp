#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

typedef pair<long double, long double> punct;

int n;
punct a[100000];
long double rez1, rez2;

long double det(punct a, punct b) {
    return (a.first*b.second)-(b.first*a.second);
}

long double arieTri(punct a, punct b) {
    return 0.5*det(a, b);
}

long double arieTrap(punct a, punct b) {
    return (a.second+b.second)*(b.first-a.first);
}

int main()
{
    fin >> n;
    for (int i = 0; i < n; i++) {
        fin >> a[i].first >> a[i].second;

        if (i) {
            rez1 += arieTrap(a[i-1], a[i]);
            rez2 += arieTri(a[i-1], a[i]);
        }
    }
    rez1 = 0.5*abs(rez1 + arieTrap(a[n-1], a[0]));
    rez2 = abs(rez2 + arieTri(a[n-1], a[0]));
    fout << fixed << setprecision(6) << rez1;
    //fout << "\n";
    //fout << fixed << setprecision(6) << rez2;
    return 0;
}
