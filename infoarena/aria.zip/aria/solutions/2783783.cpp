#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

pair<double,double> pt[100001];
int n;
double mn=0,s=0;
int main()
{
    f>>n;
    for(int i=0;i<n;i++){
        f>>pt[i].x>>pt[i].y;
        mn=min(mn,pt[i].y);
    }
    for(int i=0;i<n;i++)
    {
        int j=(i+1)%n;
        s+=(double)((pt[i].y-mn+pt[j].y-mn)*(pt[i].x-pt[j].x))/2;
    }
    cout<<fixed<<setprecision(10)<<s;
    return 0;
}
