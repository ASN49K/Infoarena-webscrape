#include <bits/stdc++.h>

using namespace std;
ifstream fin ("aria.in");
ofstream fout ("aria.out");

vector<pair<int , int>> v;
int n;
long double Arie;

long double Det(pair<int , int> a , pair<int , int> b , pair<int , int> c)
{
    return a.first * b.second + b.first * c.second + c.first * a.second -
           b.second * c.first - c.second * a.first - a.second *b.first;
}

int main()
{
    fin >> n;
    for(int i = 1 ; i <= n ; ++i)
        {
            int x , y;
            fin >> x >> y;
            v.push_back(make_pair(x , y));
        }
    for(int i = 0 ; i <= n - 3 ; ++i)
       Arie += Det(v[i] , v[i + 1] , v[i + 2]);
    fout << fixed << setprecision(5) <<(long double) (abs(Arie) / 2);
}
