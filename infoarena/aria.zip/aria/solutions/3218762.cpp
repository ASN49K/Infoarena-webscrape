#include <iostream>
#include <fstream>
#include <algorithm>
#include <math.h>
#include <vector>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const double margin = 0.000001;

struct Point
{
    double x, y;

    void operator=(Point t);
};
struct Polygon
{
    vector<Point> p;
    double area;

    void operator=(Polygon t);
    void generateArea();
};

int cmpD(double x, double y);
Polygon makePolygon(vector<Point> p);
Point makePoint(double x, double y);

int main()
{
    int n;
    vector<Point> points;
    Polygon pol;

    fin >> n;
    points.resize(n);

    for(int i = 0; i < n; i++)
    {
        double x, y;

        fin >> x >> y;

        points[i] = makePoint(x, y);
    }

    pol = makePolygon(points);

    fout << fixed << setprecision(5) << (long long)(pol.area * 100000) / 100000.0;

    return 0;
}

int cmpD(double x, double y)
{
    if(-margin < x - y && x - y < margin)
        return 0;
    
    if(x - y < margin)
        return -1;
    
    return 1;
}
void Point::operator=(Point t)
{
    this->x = t.x;
    this->y = t.y;
}
void Polygon::operator=(Polygon t)
{
    this->p = t.p;
    this->generateArea();
}
void Polygon::generateArea()
{
    Point p1, p2;
    vector<Point> &p = this->p;
    double area_ = 0;

    for(int i = 0; i < p.size(); i++)
    {
        p1 = p[i % p.size()];
        p2 = p[(i + 1) % p.size()];

        area_ += (p1.y + p2.y) * (p1.x - p2.x);
    }

    this->area = area_ / 2;
}
Polygon makePolygon(vector<Point> p)
{
    Polygon temp;
    temp.p = p;
    return temp;
}
Point makePoint(double x, double y)
{
    Point temp;
    temp.x = x;
    temp.y = y;
    return temp;
}
