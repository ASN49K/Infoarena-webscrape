#include <bits/stdc++.h>

#define int long long

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

double area(double x1, double y1, double x2, double y2, double x3, double y3)
{
    return ((y2 + y1) * (x1 - x2) + (y1 + y3) * (x3 - x1) - (y2 + y3) * (x3 - x2)) * 0.5;
}

int32_t main()
{
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    fin >> n;
    vector<pair<int, int>> a(n + 1);
    for (int i = 1; i <= n; ++i)
    {
        fin >> a[i].first >> a[i].second;
    }
    a.push_back(a[1]);
    double ans = 0;
    for (int i = 1; i <= n; ++i)
    {
        ans += area(0, 0, a[i].first, a[i].second, a[i + 1].first, a[i + 1].second);
    }
    fout << fixed << setprecision(6) << abs(ans) << '\n';
}