//aria poligonului o putem afla prin triangularizarea acestuia
// iar apoi facem suma ariilor
// luam arbitrat punctul P(0, 0) cu care formam triunghiuri (P Ai Ai+1) (consideram si ca A1 = An+1)
// aria unui triunghi o sa fie 1/2(xi*yi+1 - yi*xi+1 )


    //mai usor asa fara sa retin un vector de puncte
    //ultimul triunghi cu PAnA1
    //first ii An
    // fixed << setprecision(6) = precizie de pana la 10^-5
    // fabs = valoarea in modul

#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int N;
#define double long double

struct Point{
    double x, y;
};

double ariaTriunghi( Point A, Point B) {
    return fabs(( A.x * B.y - A.y * B.x));
}

double aria = 0;

int main() {
    fin >> N;
    Point first, ext;
    fin >> ext.x >> ext.y;
    first = ext;
    for ( int i = 0; i < N; ++ i ) {
        Point second;
        fin >> second.x >> second.y;
        aria += ariaTriunghi(ext, second);
        ext = second;
    }
    aria += ariaTriunghi(first, ext);
    aria /= 2.0;
    fout << fixed << setprecision(6) << fabs(aria);
}

