#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");


struct puncte
{
    long double x, y;
} v[100005];

int n;
long double aria=0;

int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    {
        f>>v[i].x>>v[i].y;
    }
    v[n+1].x=v[1].x;
    v[n+1].y=v[1].y;
    for(int i=1; i<=n; i++)
    {
        aria = aria + v[i].x * v[i + 1].y - v[i + 1].x * v[i].y;
    }

    g<< setprecision(5) << fixed << aria/2;
}
