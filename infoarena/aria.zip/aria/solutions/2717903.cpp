// Playground.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <math.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

vector<pair<double, double>> cont;

int main()
{
	int n;
	fin >> n;
	for (int i = 0; i < n; i++)
	{
		double x, y;
		fin >> x >> y;
		cont.push_back({ x,y });
	}
	cont.push_back(cont.front());

	double area = 0;
	for (int i=0; i<cont.size()-1; i++)
	{
		area += (cont[i].first * cont[i + 1].second - cont[i + 1].first * cont[i].second) / 2.0;
	}
	area = fabs(area);
	fout << std::fixed;
	fout << setprecision(6) << fabs(area);
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
