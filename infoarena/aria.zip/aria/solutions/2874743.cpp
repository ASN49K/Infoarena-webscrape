#include <bits/stdc++.h>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

struct punct
{
    double x,y;
};

int n;
double a;
punct v[100005];

int main()
{
    in >> n;
    for (int i = 1; i <= n; i++)
        in >> v[i].x >> v[i].y;
    v[n + 1] = v[1];
    for (int i = 1; i <= n; i++)
        a += (v[i].x * v[i + 1].y - v[i + 1].x * v[i].y);
    out << a / 2.0;
    return 0;
}
