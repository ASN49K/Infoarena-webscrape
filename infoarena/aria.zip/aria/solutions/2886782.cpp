#include <fstream>
#include <iomanip>
#define double long double
///calculam determinantul fata de origine(luam toate triunghiurile
///arie e det >> 1
using namespace std;

ifstream cin ("aria.in");
ofstream cout ("aria.out");

const int N = 1e6 + 1;

struct arie
{
    double x, y;
}a[N];

int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i].x >> a[i].y;
    }
    a[n + 1] = a[1];
    double sum = 0;
    for(int i = 1; i <= n; ++i)
        sum += (double)(a[i].x * a[i + 1].y - a[i + 1].x * a[i].y);
    cout << setprecision(6) << fixed <<  (sum / 2) << '\n';
    return 0;
}
