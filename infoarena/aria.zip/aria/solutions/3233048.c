#include <stdio.h>

#define MAXN 100000

double x[MAXN + 1], y[MAXN + 1];

int main() {
  FILE *fin, *fout;
  int n, i;
  double aria;
  fin = fopen("aria.in", "r");
  fscanf(fin, "%d", &n);
  for (i = 0; i < n; i++)
    fscanf(fin, "%lf%lf", &x[i], &y[i]);
  fclose(fin);
  x[n] = x[0];
  y[n] = y[0];
  aria = 0;
  for (i = 0; i < n; i++)
    aria += x[i] * y[i + 1] - x[i + 1] * y[i];
  fout = fopen("aria.out", "w");
  fprintf(fout, "%.5f\n", aria / 2.0);
  fclose(fout);
  return 0;
}