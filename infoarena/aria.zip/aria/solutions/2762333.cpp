﻿#include <iostream> 
#include <fstream>
#include <iomanip>
#include <cmath>
#include <algorithm> 
#include <cstring>

using namespace std;

string NumeFisier = "aria";
ifstream fin(NumeFisier + ".in");
ofstream fout(NumeFisier + ".out");

typedef unsigned long long int ull;
const int MAX = 100003;

struct point {
	long double x, y;
}val[MAX];


int main()
{
	int n;
	fin >> n;
	for (int i = 1; i <= n; i++)
		fin >> val[i].x >> val[i].y;
	long double area = 0;
	val[n + 1] = val[1];
	for (int i = 1; i <= n; i++)
		area += (val[i].x * val[i + 1].y - val[i].y * val[i + 1].x);
	fout << fixed << setprecision(5) << (double)fabs(area / 2.0);

}	
