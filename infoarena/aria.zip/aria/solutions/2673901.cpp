#include <bits/stdc++.h>
//#pragma GCC optimize ("O3")
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<ll,ll> pll;
typedef pair<int,int> pii;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct point
{
    ll x,y;
};
point v[100001];
int n;
ll ans;
ll aria(point a, point b, point c)
{
    a.x-=c.x;
    a.y-=c.y;
    b.x-=c.x;
    b.y-=c.y;
    return a.x*b.y-a.y*b.x;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    for(int i=1;i<=n;i++)
    {
        int j=i+1;
        if(j>n)
            j=1;
        ans+=aria({0,0},v[i],v[j]);
    }
    double rez=double(ans/2.0);
    rez=abs(rez);
    fout<<fixed<<setprecision(9)<<rez;
    return 0;
}
