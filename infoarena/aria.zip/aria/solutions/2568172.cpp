#include <cstdio>
#include <cmath>

using namespace std;

const int MAX_N = 100000;

struct Point {
  double x;
  double y;
};

Point points[5 + MAX_N];

double area(Point b, Point c) {
  return b.x * c.y - c.x * b.y;
}

int main() {
  freopen("aria.in", "r", stdin);
  freopen("aria.out", "w", stdout);

  int n;
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    double x, y;
    scanf("%lf%lf", &x, &y);
    points[i] = {x, y};
  }

  double ans;
  ans = 0;
  for (int i = 1; i <= n; i++) {
    int nxt;
    nxt = i + 1;
    if (nxt == n + 1)
      nxt = 1;
    ans += area(points[i], points[nxt]);
  }

  printf("%.5f", fabs(ans * 0.5));

  return 0;
}
