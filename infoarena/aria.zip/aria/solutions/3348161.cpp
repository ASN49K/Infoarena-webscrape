#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

const int mxN = 1e5 + 1;

double x[mxN], y[mxN];

double arie(int a, int b){
    return x[a] * y[b] - y[a] * x[b];
}

int main(){
    int n;
    double ans = 0;
    fin >> n;
    for(int i = 1; i <= n; i ++)
        fin >> x[i] >> y[i];
    x[0] = x[n];
    y[0] = y[n];

    for(int i = 1; i <= n; i++)
        ans += arie(i - 1, i) / 2;

    fout << setprecision(5) << ans;
}