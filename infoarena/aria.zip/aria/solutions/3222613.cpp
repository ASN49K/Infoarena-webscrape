#include<fstream>
#include<iomanip>
std::ifstream fin("aria.in");
std::ofstream fout("aria.out");
float getDet(float xa, float xb, float ya, float yb)
{
    return (float)(xa*yb-xb*ya);
}

int main()
{
    int n;
    float arie=0;
    fin>>n;
    float x0, y0, xprev, yprev, x1, y1;
    fin>>xprev>>yprev;
    x1=xprev, y1=yprev;
    for(int index=1; index<n; ++index)
    {
        fin>>x0>>y0;
        float localDet=getDet(xprev, x0, yprev, y0);
        arie+=localDet;
        xprev=x0;
        yprev=y0;
    }
    arie+=getDet(xprev, x1, yprev, y1);
    arie/=2;
    if(arie<0)
        arie=-arie;
   // fout<<std::fixed<<std::setprecision(5)<<arie;

    long long a=arie*100000;
    fout<<std::fixed<<std::setprecision(5)<<(float)(a/100000);
    return 0;
}