/*
 Citindu-se din fisier un nr natural n urmate de
 n perechi de valori de tipul x, y care reprezinta varfurile
 unui poligon(fie el convex sau concav).
 Sa se determine aria acestui poligon.
*/
#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
using namespace std;
struct pct{
    int x;
    int y;
};

ifstream fin("aria.in");
ofstream fout("aria.out");
const int N_max = 100005;


pct pol[N_max];
void reading(int &n, pct* vect){
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> vect[i].x >> vect[i].y;
}

float dist(pct A, pct B){
    return sqrt((A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y));
}
float arie_Heron(pct A, pct B, pct C){
    float a = dist(B, C);
    float b = dist(A, C);
    float c = dist(A, B);
    float p = (a + b + c) / 2;
    return sqrt(p * (p - a) * (p - b) * (p - c));
}

float arie_Determinant(pct A, pct B, pct C){
    /*
                    | xA  yA  1|
      Arie  =1/2 *  | xB  yB  1| = 1 / 2 * (+ xA * yB + yA * xC + xB * yC
                    | xC  yC  1|            - xC * yB - xB * yA - xA * yC)
     */
    float arie = (1.0 / 2) * (A.x * B.y + A.y * C.x + B.x * C.y - C.x * B.y - B.x * A.y - A.x * C.y);
    return arie;
}

int main() {
    int n;
    reading(n, pol);

    pol[n + 1].x = pol[1].x; pol[n + 1].y = pol[1].y;

    float arie = 0;

    for(int i = 1; i <= n; i++){
        if(pol[i].x * pol[i + 1].y < pol[i + 1].x * pol[i].y) {
            arie -= arie_Heron({0, 0}, pol[i], pol[i + 1]);
        }else{
            arie += arie_Heron({0, 0}, pol[i], pol[i + 1]);
        }

    }

    fout << setprecision(5) << fixed << abs(arie);
}
