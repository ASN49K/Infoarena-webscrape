#include <bits/stdc++.h>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");


int main()
{
	int n;
	in>>n;
	vector<pair<double,double> >v(n);
	for(auto&i:v)
	{
		in>>i.first>>i.second;
	}
	v.push_back({v[0].first,v[0].second});
	double s=0;
	for(int i=0;i<n;i++)
		s+=(v[i].first*v[i+1].second-v[i+1].first*v[i].second);
	out<<fixed<<setprecision(5)<<s/2.0;
	return 0;
}
