#include<fstream>
#include<iomanip>
#include<math.h>
using namespace std;
#define MAX 100005

ifstream fi("aria.in");
ofstream fo("aria.out");

struct punct 
{
    long double x, y;
} V[MAX];

int N, i;
long double S;

int main()
{
	fi >> N;
	for(i=1; i<=N; i++)
	fi >> V[i].x >> V[i].y;
	
	for(i=1; i<=N; i++)
	S+= V[i].x*V[i+1].y - V[i+1].x*V[i].y;
	fo << fixed << setprecision(5) << fabs(S/2.0);
}

