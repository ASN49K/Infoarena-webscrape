#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 666013;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("aria.in");
ofstream fout("aria.out");

const int nmax = 1e5;
int n;
pair<int, int> p[nmax + 5];

double area(const pair<int, int>& a, const pair<int, int>& b, const pair<int, int>& c) {
	return abs((ll)(b.first - a.first) * (c.second - a.second) - (ll)(c.first - a.first) * (b.second - a.second)) / 2.0;
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	fin >> n;
	for (int i = 1; i <= n; ++i) {
		fin >> p[i].first >> p[i].second;
	}
	double Area = 0;
	for (int i = 2; i < n; ++i) {
		Area += area(p[1], p[i], p[i + 1]);
	}
	fout << fixed << setprecision(8) << Area;
}