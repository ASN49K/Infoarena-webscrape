#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 666013;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("aria.in");
ofstream fout("aria.out");

const int nmax = 1e5;
int n;
pair<long double, long double> p[nmax + 5];

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	fin >> n;
	for (int i = 1; i <= n; ++i) {
		fin >> p[i].first >> p[i].second;
	}
	p[n + 1] = p[1];
	long double area = 0;
	for (int i = 1; i <= n; ++i) {
		area += p[i].first * p[i + 1].second - p[i + 1].first * p[i].second;
	}
	fout << fixed << setprecision(8) << abs(area) / 2;
}