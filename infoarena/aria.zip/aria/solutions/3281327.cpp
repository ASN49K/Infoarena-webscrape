#include <bits/stdc++.h>
using namespace std;

const string filename = "aria";
ifstream in (filename + ".in");
ofstream out (filename + ".out");

const int maxsze = 100002;
const int inf = 0x3f3f3f3f;

struct point { int x, y; } arr[maxsze];
int main( ) {
    int numpoints; in >> numpoints;
    for (int i = 1; i <= numpoints; ++i)
        in >> arr[i].x >> arr[i].y;

    double ans = 0; arr[numpoints + 1] = arr[1];
    for (int i = 1; i <= numpoints; ++i)
        ans += double(arr[i].x * arr[i + 1].y - arr[i + 1].x * arr[i].y);

    ans *= 0.5;
    out << << setprecision( 5 ) << ans << '\n';
    return 0;
}
