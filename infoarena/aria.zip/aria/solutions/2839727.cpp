#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n,i;

long double I[100001],J[100001],s;

int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>I[i]>>J[i];
    }
    I[n+1]=I[1];
    J[n+1]=J[1];
    for(i=1;i<=n;i++)
        s=s+(I[i]*J[i+1])-(I[i+1]*J[i]);
    s=s/(2.0);
    g<<fixed<<setprecision(6)<<s;
    return 0;
}
