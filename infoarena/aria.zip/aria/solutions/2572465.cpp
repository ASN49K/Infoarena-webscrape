#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct
{
    double x,y;
}v[100100];

double arie,x1,x2,y1,y2;
int n,i;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>v[i].x>>v[i].y;
    }

    for(i=1;i<=n;i++)
    {
        x1=v[i].x;y1=v[i].y;
        if(i+1<=n)x2=v[i+1].x,y2=v[i+1].y;
        else x2=v[1].x,y2=v[1].y;

        arie+=(x1*y2-y1*x2)/2;
    }

    g<<fixed<<setprecision(6)<<arie;
    return 0;
}
