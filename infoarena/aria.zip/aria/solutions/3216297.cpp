#include <fstream>
#define s second
#define f first
const int NMAX=1e5+5;

using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");

typedef long double ld;
typedef pair<ld, ld> pld;

ld det(pld, pld, pld);

pld v[NMAX];
int n;
ld aria;

signed main()
{
    int i;
    cin>>n;
    for(i=1; i<=n; i++) cin>>v[i].f>>v[i].s;
    v[n+1]=v[1];
    for(i=2; i<=n+1; i++)
    {
        aria+=1.0/2.0*det({0.0, 0.0}, v[i-1], v[i]);
    }
    cout<<fixed<<setprecision(5)<<aria<<'\n';
    return 0;
}

ld det(pld a, pld b, pld c)
{
    return a.f*(b.s-c.s)-a.s*(b.f-c.f)+(b.f*c.s-b.s*c.f);
}
