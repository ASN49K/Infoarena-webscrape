#include<iostream>
#include<fstream>
#include<iomanip>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

#define nrm 100010
int n;
long double dx[nrm],dy[nrm];

void citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>dx[i]>>dy[i];
    }
}

int main ()
{
    citire();
    long double aria=0;
    for(int i=1;i<n;i++)
    {
        aria=aria+((dx[i]*dy[i+1]-dx[i+1]*dy[i])*1.0);
    }
    aria=aria+((dx[n]*dy[1]-dx[1]*dy[n])*1.0);
    fout<<fixed<<setprecision(5)<<aria/2;
    fin.close();
    fout.close();
    return 0;
}
