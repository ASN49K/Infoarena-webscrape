#include <cstdio>
#include <vector>
#define infile "aria.in"
#define outfile "aria.out"
#define NMAX 100005

typedef std::pair<double, double> pi;

std::vector<pi> v;
unsigned int n, i;
double x, y;

int main()
{
    freopen(infile, "r", stdin);
    freopen(outfile, "w", stdout);

    scanf("%d", &n);

    for (i = 0; i < n; ++i)
    {
        scanf("%lf %lf", &x, &y);
        v.push_back(std::make_pair(x, y));
    }

    double sol = 0.0f;

    v.push_back(v[0]);
    for (i = 0; i < n; ++i)
    {
        sol += (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);
    }

    printf("%0.5f", sol / 2.0f);

    fclose(stdin);
    fclose(stdout);
    return 0;
}
