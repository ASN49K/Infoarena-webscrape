#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
long double x[100001],y[100001];
int n,i;
long double s=0;
long double aria; //fara matematica mea nu fac nimic :<
int main()
{
    fin >> n;
    for(i=1;i<=n;i++)
    {
        fin>>x[i]>>y[i];
    }
    // Folosim formula lui Shoelace,care se cunoaste din matematica.
    x[n+1] = x[1];
    y[n+1] = y[1];
    for(i=1;i<=n;i++)
    {
        s=s+(x[i]*y[i+1] - x[i+1]*y[i]);
    }
    aria=1.0 * abs(s)/2;
    fout << fixed << setprecision(5) << aria ;
    return 0;
}
