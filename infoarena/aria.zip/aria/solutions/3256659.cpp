//
//  main.cpp
//  Pb aria, infoarena
//
//  Created by Petrisor Stefan on 15.11.2024.
//

#include <fstream>
#include <cmath>
#include <iostream>
#include <iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct z{
    double x,y;
}v[100005];
int main() {
    double a = 0.0; int n;
    f>>n;
    for(int i=0;i<n;i++)
    {
        f>>v[i].x>>v[i].y;
    }
    v[n]=v[0];
    for(int i=0;i<=n;i++)
    {
        a+=(v[i].x*v[i+1].y)-(v[i+1].x*v[i].y);
    }
    a=abs(a);
    g<<fixed<<setprecision(6)<<a/2.0;
    return 0;
}
