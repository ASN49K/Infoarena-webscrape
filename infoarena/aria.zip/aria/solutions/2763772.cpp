#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

struct pont{
    double x, y;
} a[100005];

int main()
{
    ifstream in("aria.in");
    ofstream out("aria.out");
    int n;
    double aria=0;
    in>>n;
    for(int i=0; i<n; i++) in>>a[i].x>>a[i].y;
    a[n]=a[0];
    for(int i=0; i<n; i++) aria+=(a[i].x * a[i+1].y-a[i+1].x*a[i].y);
    out<<abs(aria/2);
    return 0;
}
