#include <bits/stdc++.h>
#define double long double
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct elem
{
    int x, y;
};
elem v[100009];
double arie (elem p1, elem p2, elem p3)
{
    double x1=p1.x, y1=p1.y, x2=p2.x, y2=p2.y, x3=p3.x, y3=p3.y;
    return x1*y2+x2*y3+x3*y1-y2*x3-y3*x1-x2*y1;
}
signed main ()
{
    int n;
    f >> n;
    for (int i=1; i<=n; i++)
        f >> v[i].x >> v[i].y;
    elem p={0, 0};
    double ans=0;
    v[n+1]=v[1];
    for (int i=1; i<=n; i++)
    ans+=arie (p, v[i], v[i+1])/2;
    g << fixed << setprecision (7) << ans;

}
