#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct punct
{
    int x;
    int y;
};

punct a[100001];
int n;
double rez;

void citire()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> a[i].x >> a[i].y;
    }
}

void rezolvare()
{
    for(int i = 1; i < n; i++)
    {
        rez = rez + double(a[i].x * a[i+1].y - a[i+1].x * a[i].y);
    }
    rez = rez + double(a[n].x * a[1].y - a[1].x * a[n].y);
    fout << rez/2;
}

int main()
{
    citire();
    rezolvare();
}
