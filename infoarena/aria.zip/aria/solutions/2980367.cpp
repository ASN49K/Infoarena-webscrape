#include <fstream>
#include <iomanip>
#include <cmath>
#include <algorithm>
const int NMAX=100005;

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

typedef long double ld;

ld det(ld x1, ld y1, ld x2, ld y2)
{
  return (x1*y2-x2*y1);
}

struct punct
{
  ld x, y;
  bool operator< (const punct& other) const
  {
    return det(x, y, other.x, other.y)>0;
  }
}v[NMAX];

ld aria(punct [], int);

int n;

int main()
{
  int i;
  ld ans;
  fin>>n;
  for(i=1; i<=n; i++) fin>>v[i].x>>v[i].y;
  sort(v+1, v+n+1);
  v[n+1]=v[1];
  ans=aria(v, n);
  fout<<fixed<<setprecision(6)<<ans<<'\n';
  return 0;
}

ld aria(punct v[], int n)
{
  int i;
  ld sum=0;
  for(i=1; i<=n; i++) sum+=(1.0/2.0)*(v[i].x*v[i+1].y-v[i+1].x*v[i].y);
  return sum;
}
