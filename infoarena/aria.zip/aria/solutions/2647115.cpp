#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int N;

struct Punct
{
    long double x, y;
};

Punct v[100001];

int main()
{
    f >> N;
    for(int i = 0; i < N; ++i)
        f >> v[i].x >> v[i].y;
    v[N] = v[0];
    long double ans = 0;
    for(int i = 0; i < N; ++i)
        ans += (v[i].x * v[i + 1].y - v[i + 1].x * v[i].y);
    g << fixed<<setprecision(8)<< ans / 2.0;
    return 0;
}
