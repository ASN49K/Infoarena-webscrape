
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
int n;
vector<long double> X,Y;
long double arie;
int main()
{
    cout<<setprecision(5)<<fixed;
    cin>>n;
    X.resize(n);
    Y.resize(n);
    for(int i=0;i<n;i++)
      cin>>X[i]>>Y[i];
    for(int i=0;i<n-1;i++)
      arie=arie+X[i]*Y[i+1]-Y[i]*X[i+1];
    arie=arie+X[n-1]*Y[0]-Y[n-1]*X[0];
    arie=abs(arie)/2;
    cout<<arie;
    return 0;
}
