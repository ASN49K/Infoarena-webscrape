#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

int n, total;

int main()
{
    in >> n;
    double xi, yi, primx, primy;
    double xc, yc;
    in >> xi >> yi;
    primx = xi, primy = yi;
    for(int i = 1; i < n; i++){
        in >> xc >> yc;
        double s = (xi * yc - xc * yi) / 2.0;
        total += s;
        xi = xc, yi = yc;
    }
    double s = (xc * primy - primx * yc) / 2.0;
    total += s;
    out << fixed << setprecision(5) << abs(total);
    return 0;
}
