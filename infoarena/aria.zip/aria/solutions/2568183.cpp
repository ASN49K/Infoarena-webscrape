#include <cstdio>
#include <cmath>

using namespace std;

const int MAX_N = 100000;

struct Point {
  long double x;
  long double y;
};

Point points[5 + MAX_N];

long double area(Point b, Point c) {
  return (long double)(b.x * c.y - c.x * b.y);
}

int main() {
  freopen("aria.in", "r", stdin);
  freopen("aria.out", "w", stdout);

  int n;
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    double x, y;
    scanf("%lf%lf", &x, &y);
    points[i] = {(long double)x, (long double)y};
  }

  long double ans;
  ans = 0;
  for (int i = 1; i <= n; i++) {
    int nxt;
    nxt = i + 1;
    if (nxt == n + 1)
      nxt = 1;
    ans += area(points[i], points[nxt]);
  }

  printf("%.5f", fabs(ans * 0.5));

  return 0;
}
