#include <bits/stdc++.h>
#define NMAX 100000
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
long double x[NMAX + 5], y[NMAX + 5];
long double sum = 0;

long double frm(int x1,int y1, int x2, int y2)
{
    return (x1*y2 - x2 * y1);
}

int main()
{
    fin >> n;
    for(int i = 1; i<=n; i++)
    {
        fin >> x[i] >> y[i];
        if(i>1)
        {
            if(i == n)
            {
                sum += frm(x[i-1],y[i-1],x[i],y[i]);
                sum += frm(x[i],y[i],x[1],y[1]);
            }
            else
                sum += frm(x[i-1],y[i-1],x[i],y[i]);
        }
    }
    fout << fixed << setprecision(5) << sum / 2.0;
    return 0;
}
