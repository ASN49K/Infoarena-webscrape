#include <iostream>
#include <fstream>
#include<cmath>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
long double x[100001],y[100001];

void citire()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> x[i] >> y[i];
}

int main()
{
    citire();
    long double s = 0;
    x[n+1] = x[1];
    y[n+1] = y[1];
    for(int i = 1; i <= n; i++)
    {
        s+= x[i]*y[i+1] - x[i+1]*y[i];
    }
    fout << setprecision(18) << s/2;
    return 0;
}
