#include <fstream>
#include <iomanip>
#define ld long double
#define pi std::pair<ld, ld>
#define x first
#define y second

const int nmax = 1e5 + 5;

pi v[nmax];

int main() {
	std::ifstream fin("aria.in");
	std::ofstream fout("aria.out");
	int n;
	ld ans = 0.0;
	fin >> n;
	for (int i = 1; i <= n; i++) fin >> v[i].x >> v[i].y;
	for (int i = 1; i <= n; i++) {
		int j = ((i == n) ? 1 : (i + 1));
		ans += v[i].x * v[j].y - v[j].x * v[i].y;
	}
	ans *= 0.5;
	fout << std::fixed << std::setprecision(5) << ans;
}