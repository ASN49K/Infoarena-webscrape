#include <fstream>
#include <cstring>
#include <cmath>

using namespace std;
ifstream fin ("aria.in");
ofstream fout ("aria.out");

char * parse (char c[], char d[]) {
    static char* p = nullptr;
    if (c != nullptr) {
        p = c;
    } else if (p == nullptr) {
        return nullptr;  // No more tokens
    }

    for (int i = *p; c[i]; i++)
        if (strchr (d, c[i]))
        {
            c[i] = '\0';
            p = c + i;
            return p;
        }
}

int aria (int n, pair<int,int> v[]) {
    int s = 0;
    v[n].first = v[0].first, v[n].second = v[0].second;
    for (int i = 0; i < n; i++)
            s+= v[i].first * v[i+1].second - v[i+1].first*v[i].second;

    return s;

}
int main()
{
    int n;
    cin>>n;
    pair<int, int> v[n + 1];
    for (int i = 0; i< n; i++)
        cin>>v[i].first >> v[i].second;

    cout<<abs(aria(n, v)) / 2;

    return 0;
}
