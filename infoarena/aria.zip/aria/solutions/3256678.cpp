#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct z{
    long double x,y;
}v[100005];
int main() {
    long double a = 0.0;
    int n;
    f>>n;
    for(int i=0;i<n;i++)
    {
        f>>v[i].x>>v[i].y;
    }
    v[n]=v[0];
    for(int i=0;i<n;i++)
    {
        a+=(v[i].x*v[i+1].y)-(v[i+1].x*v[i].y);
    }
    g<<fixed<<setprecision(5)<<abs(a/2.0);
    return 0;
}
