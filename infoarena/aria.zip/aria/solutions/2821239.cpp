#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");
#define cin fin
#define cout fout

#define N 505
#define inf 100000000000000
vector < pair < double , double > > v;
double n, x, y;

int main()
{
    cin >> n;
    v.resize(n+5);
    for(int i = 0 ; i < n ; i++)
    {
        cin >> x >> y;
        v[i].first = x;
        v[i].second = y;
    }
    v[n] = v[0];
    double sol = 0.0;
    for(int i = 0 ; i < n ; i++)
    {
        sol += v[i].first*v[i+1].second - v[i+1].first*v[i].second;
    }
    cout << fixed << setprecision(6) << fabs(sol/2.0);
    return 0;
}
