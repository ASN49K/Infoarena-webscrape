var n,i:longint;
    s,x1,y1,x2,y2,xs1,ys1:real;
begin
assign(input,'aria.in'); reset(input);
assign(output,'aria.out'); rewrite(output);
readln(n); s:=0;
read(x1,y1);
xs1:=x1; ys1:=y1;
for i:=1 to n-1 do
 begin
  readln(x2,y2);
  s:=s+x1*y2-x2*y1;
  x1:=x2;
  y1:=y2
 end;
s:=s+x1*ys1-y1*xs1;
s:=abs(s)*0.5;
writeln(s:1:1);
close(input);
close(output)
end.

