#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");
#define cin fin
#define cout fout
struct p
{
    long double x, y;
} v[100005];

long long n;
long double sol;

int main ()
{
    cin>>n;
    for (int i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;

    v[n+1]=v[1];
    for (int i=1;i<=n;i++)
        sol+=(v[i].x*v[i+1].y);
    for (int i=1;i<=n;i++)
        sol-=(v[i+1].x*v[i].y);
    sol=abs(sol);
    sol/=2;
    cout<<setprecision(6)<<fixed<<sol;
}
