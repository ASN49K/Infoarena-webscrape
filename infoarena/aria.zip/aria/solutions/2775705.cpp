#include <fstream>
#include <cmath>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n;

struct punct {
    double x, y;
} puncte[100005];

void citire() {
    f >> n;
    for (int i = 1; i <= n; ++i)
        f >> puncte[i].x >> puncte[i].y;
}

double arie(punct a, punct b, punct c) {
    return abs(a.x*b.y+b.x*c.y+a.y*c.x-b.y*c.x-a.y*b.x-a.x*c.y);
}

double calculare_arie() {
    double suma = 0;
    for (int i = 2; i < n; ++i)
        suma += arie(puncte[1],puncte[i],puncte[i+1]);
    return suma/2;
}

int main() {
    citire();
    if (n <= 2) {
        g << 0;
        return 0;
    }
    g << fixed<<setprecision(5)<<calculare_arie();
    return 0;
}
