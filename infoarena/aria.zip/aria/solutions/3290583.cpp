#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

double x[100005], y[100005];

int main() {
    int n;
    cin >> n;

    for (int i = 0; i < n; ++i) {
        cin >> x[i] >> y[i];
    }

    long double arie = 0;

    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        arie += x[i] * y[j] - x[j] * y[i];
    }

    arie = abs(arie) / 2.0;

    cout<<fixed<<setprecision(5)<<arie;

    return 0;
}
