#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int MAX=1e5+5;
struct punct
{
    long double x,y;
}v[MAX];
int n;
long double aria;

int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
        fin >> v[i].x >> v[i].y;
    v[n+1]=v[1];
    for(int i=1;i<=n;i++)
        aria+=v[i].x*v[i+1].y-v[i+1].x*v[i].y;
    fout << fixed << setprecision(6) << aria/2.0;
	return 0;
}
