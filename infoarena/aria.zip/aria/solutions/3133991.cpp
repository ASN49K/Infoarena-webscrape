#pragma GCC optimize("Ofast,unroll-loops")

#include <bits/stdc++.h>

using namespace std;

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

#define endl '\n'

#define sz(a) ((int)(a).size())
#define all(a) (a).begin(), (a).end()
#define erase_unique(a) sort(all(a)); (a).erase(unique(all(a)), (a).end())

#define f first
#define s second

#define YES cout << "YES" << endl
#define NO cout << "NO" << endl

#define lsb(x) (x & (-x))
#define FILE_NAME "aria"

typedef long long ll;
typedef pair<int, int> pii;

const int NMAX = 1e5+5;

struct Point {
	double x, y;
};

int n;
Point a[NMAX];

void read() {
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i].x >> a[i].y;
}

inline double area(const Point &a, const Point &b, const Point &c) {
	return a.x * b.y + b.x * c.y + c.x * a.y - c.x * b.y - a.x * c.y - b.x * a.y;
}

double solve() {
	double ans = 0;
	a[n + 1] = a[1];
	for (int i = 1; i <= n; i++)
		ans += area({0, 0}, a[i], a[i + 1]);
	return ans / 2.0;
}

signed main() {
#ifdef LOCAL
	freopen("input.txt", "r", stdin);
#else
	freopen(FILE_NAME ".int", "r", stdin);
	freopen(FILE_NAME ".out", "w", stdout);
#endif
	int t = 1;
//	cin >> t;

	while (t--) {
		read();
		cout << setprecision(6) << fixed << solve() << endl;
	}

	return 0;
}

