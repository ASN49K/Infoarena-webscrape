#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct Punct
{
    double x, y;
};

int n, s=0;

double AriaPoligon(Punct a, Punct b)
{
    return ((a.x * b.y) - (a.y * b.x))/2;
}

int main()
{
    Punct a,b,first;
    f >> n;
    f >> a.x >> a.y;

    first=a;

    for (int i=2; i<=n; i++)
    {
        f >> b.x >> b.y;
        s+=AriaPoligon(a,b);
        a.x=b.x;
        a.y=b.y;
    }
    s+=AriaPoligon(b,first);
    g << fixed << setprecision(5) << s;
}
