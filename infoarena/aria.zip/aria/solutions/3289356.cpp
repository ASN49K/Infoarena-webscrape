#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

long double c[100001];
long double l[100001];

int main()
{
    long long n,i;
    long double s;
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>l[i]>>c[i];
    l[n+1]=l[1];
    c[n+1]=c[1];
    s=0;
    for(i=1;i<=n+1;i++)
        s=s+l[i]*c[i+1]-l[i+1]*c[i];
    cout<<fixed<<setprecision(5)<<abs(s)/2.0;
    return 0;
}
