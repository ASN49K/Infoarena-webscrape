#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream f ("aria.in");
ofstream g ("aria.out");
int n;
long double arie;
struct punct{
    long double x;
    long double y;
};
punct p[100010];
int main(){
    f>>n;
    for(int i=1; i<=n; i++){
        f>>p[i].x>>p[i].y;
    }
    p[n+1]=p[1];
    for(int i=1; i<=n; i++)
        arie+=(p[i].x*p[i+1].y - p[i+1].x*p[i].y)/2;
    g<<fixed<<setprecision(5)<<arie;
    return 0;
}
