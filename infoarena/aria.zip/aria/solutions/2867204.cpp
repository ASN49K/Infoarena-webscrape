#include <fstream>
#include <iomanip>

using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

int n;

struct point {
  int x, y;
}v[100005];

double Aria;

int main()
{
    f >> n;
    for (int i=1; i<=n; i++)
        f >> v[i].x >> v[i].y;

    n ++; v[n] = v[1];

    for (int i=1; i<n; i++)
    {
        Aria += (v[i].x * v[i+1].y);
        Aria -= (v[i+1].x * v[i].y);
    }

    Aria /= 2.0;
    g << fixed << setprecision(5);
    g << Aria;

    return 0;
}
