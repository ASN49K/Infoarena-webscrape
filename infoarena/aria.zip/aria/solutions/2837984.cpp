#include <bits/stdc++.h>
using namespace std;

#define pb push_back
using ll = long long;
const string fn = "aria";

ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

#define x first
#define y second
typedef pair<int, int> punct;

//area = 1/2(sum((x[i]*y[i + 1]) - (x[i + 1] * y[i])))

int n;
punct a[100005];

double ans;

int main(){
  
    fin >> n;
    for(int i = 1; i <= n; ++i){
        fin >> a[i].x >> a[i].y;
    }
    a[n + 1] = a[1];
    for(int i = 1; i<= n; ++i)
        ans += (a[i].x * a[i + 1].y) - (a[i + 1].x * a[i].y);
    ans = ans / 2.0;
    fout << ans << '\n';

    fin.close();
    fout.close();
    return 0;
}