#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");
struct Punct {
    int x, y;
} p[100002];
int n, i;
double r = 0;

int main() {
    fin >> n;
    for(i = 1; i <= n; i++) fin >> p[i].x >> p[i].y;
    p[n + 1] = p[1];
    for(i = 1; i <= n; i++) r += (p[i].x * p[i + 1].y - p[i + 1].x * p[i].y);
    fout << fixed << setprecision(5) << abs(r / 2.0);

    return 0;
}