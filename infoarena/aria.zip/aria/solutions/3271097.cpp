#include <iostream>
#include <vector>
#include <fstream>
#include <utility>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
using ld = long double;
int n;
vector<pair<ld,ld>> coords;
ld x,y;

ld calca(int i,int j) {
        return coords[i].first*coords[j].second-coords[j].first*coords[i].second;
}

int main() {
        fin>>n;
        for (int i = 1;i<=n;++i) {
                fin>>x>>y;
                coords.emplace_back(x,y);
        }
        coords.push_back(coords[0]);
        ld area = 0;
        for (int i = 0;i<coords.size()-1;++i) {
                area+=calca(i,i+1);
        }
        area/=2.0;
        fout<<fixed;
        fout<<abs(area);
        return 0;
}
