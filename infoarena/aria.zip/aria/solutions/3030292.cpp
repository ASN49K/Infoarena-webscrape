#include <fstream>
#include <algorithm>
#include <iomanip>
const int NMAX=100005;

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

typedef long double ld;

ld det(ld, ld, ld, ld);
void aria();

struct punct
{
    ld x, y;
    bool operator<(const punct& other) const
    {
        if(det(x, y, other.x, other.y)==0) return x>other.x;
        return (det(x, y, other.x, other.y)>0);
    }
}v[NMAX];

int n;

int main()
{
    int i;
    fin>>n;
    for(i=1; i<=n; i++) fin>>v[i].x>>v[i].y;
    aria();
    return 0;
}

void aria()
{
    int i;
    ld aria=0;
    sort(v+1, v+n+1);
    v[n+1]=v[1];
    for(i=1; i<=n; i++)
    {
        aria+=(1.0/2.0)*det(v[i].x, v[i].y, v[i+1].x, v[i+1].y);
    }
    fout<<fixed<<setprecision(10)<<aria<<'\n';
}

ld det(ld x1, ld y1, ld x2, ld y2)
{
    return (x1*y2)-(y1*x2);
}
