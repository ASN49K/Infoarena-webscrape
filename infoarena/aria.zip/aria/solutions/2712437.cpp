#include <bits/stdc++.h>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
struct wow
{
    long double x,y;
}v[100005];
long double arie (wow a,wow b,wow c)
{
    return a.x*b.y+b.x*c.y+a.y*c.x-a.y*b.x-b.y*c.x-a.x*c.y;
}
long double sum;
int i,n;
int main()
{
    f>>n;
    for (i=1;i<=n;i++)
    {
        f>>v[i].x>>v[i].y;
    }
    v[n+1]=v[1];
    for (i=2;i<=n+1;i++)
    {
        sum=sum+arie(v[i-1],v[i],wow{0,0});
    }
    sum=sum/2;
    g<<fixed<<setprecision(6)<<abs(sum);
    return 0;
}
