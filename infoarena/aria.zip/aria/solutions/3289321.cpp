#include <bits/stdc++.h>

using namespace std;

int main()
{
  ifstream cin("aria.in");
  ofstream cout("aria.out");

    long long n, x, y, ans=0, x2, y2, a, b;
    cin>>n>>x>>y;
    a=x;
    b=y;
    for(int i=2; i<=n; i++)
    {
        cin>>x2>>y2;
        ans+=(x*y2)-(x2*y);
        x=x2;
        y=y2;
    }
    ans+=(x*b)-(a*y);

    cout<<abs(ans)/2;

    return 0;
}
