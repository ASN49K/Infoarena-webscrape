#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <iomanip>

#define MOD 1999999973
#define INT_MAX 1000000000

using namespace std ;

ifstream cin ("aria.in") ;
ofstream cout ("aria.out") ;

long double sum = 0, px = 0, py = 0 ;

long double det(long double x1, long double y1, long double x2, long double y2, long double x3, long double y3)
{
    return ((x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1)) / 2 ;
}

int main()
{
    int n ;

    cin >> n ;

    long double c, d, cc, dd ;

    cin >> c >> d ;

    cc = c ;
    dd = d ;

    for(long double f = 2, a, b ; f <= n ; f ++)
    {
        cin >> a >> b ;

        sum += det(px, py, c, d, a, b) ;

        c = a ;
        d = b ;
    }

    cout << fixed << setprecision(5) << abs(sum + det(px, py, c, d, cc, dd)) ;

    return 0 ;
}


