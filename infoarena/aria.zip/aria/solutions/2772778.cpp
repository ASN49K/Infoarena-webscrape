#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int N;
long double a;
vector<pair<long double, long double>>v;
int main() {
    fin >> N;
    v = vector<pair<long double, long double>>(N + 4);
    for(int i = 1; i <= N; i++) {
        fin >> v[i].first >> v[i].second;
    }
    v[N + 1] = v[1];
    for(int i = 1; i <= N; i++) {
        a += (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);
    }
    a = abs(a) / 2.0;
    fout << fixed << setprecision(5) << a << '\n';
    return 0;
}
