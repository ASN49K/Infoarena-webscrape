#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int maxn = 1e5;
long double v[maxn][2];

int main() {
    int n;
    fin >> n;
    for (int i = 0; i < n; i++)
        fin >> v[i][0] >> v[i][1];
    for (int i = 0; i < n; i++)
        v[i][1] += 1e6;
    double aria = 0;
    for (int i = 1; i < n; i++)
        aria += (double)(v[i][1] + v[i - 1][1])/2*(v[i][0] - v[i - 1][0]);
    aria += (double)(v[0][1] + v[n - 1][1])/2*(v[0][0] - v[n - 1][0]);
    if (aria > 0)
        aria = -aria;
    aria = -aria;
    fout << fixed << setprecision(5) << aria;

    return 0;
}