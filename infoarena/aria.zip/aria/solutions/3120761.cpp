#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

long long n,i,x[100010],y[100010],xstart,ystart;
long double aria;

int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>x[i]>>y[i];
    xstart=x[1];
    ystart=y[1];
    x[n+1]=xstart;
    y[n+1]=ystart;
    for(i=2;i<=n+1;i++)
    {
        aria+=xstart*y[i]-ystart*x[i];
        xstart=x[i];
        ystart=y[i];
    }
    cout<<fixed;
    cout <<setprecision(5)<<aria/2.0;
    return 0;
}
