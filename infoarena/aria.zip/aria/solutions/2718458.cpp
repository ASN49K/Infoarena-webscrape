#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
double x[100002],y[100002];
int main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");
    int n;
    double A=0;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>x[i]>>y[i];
    for(int i=1;i<n;i++)
    {
        A=A+(x[i+1]-x[i])*(y[i+1]+y[i]);
    }
    A=A+(x[1]-x[n])*(y[1]-y[n]);
    cout<<abs(A/2);
    return 0;
}
