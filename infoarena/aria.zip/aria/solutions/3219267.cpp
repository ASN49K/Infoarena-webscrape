#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct punct
{
    long double x,y;
}v[100005];

int main()
{
    int n;
    long double S=0,s;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;
    for(int i=1;i<n;i++)
    {
        int j=i+1;
        s=v[i].x*v[j].y-v[j].x*v[i].y;
        S+=s;
    }
    s=v[n].x*v[1].y-v[1].x*v[n].y;
    S+=s;
    if(S<0)
        S=-S;
    cout<<fixed<<setprecision(5)<<S/2.0;
    return 0;
}
