#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE* in = fopen("aria.in", "r");
    FILE* out = fopen("aria.out", "w");

    int n;
    long double ans = 0;
    fscanf(in, "%d", &n);

    long double x1, y1, xp, yp, x, y;
    fscanf(in, "%Lf%Lf", &x1, &y1);
    
    xp = x1;
    yp = y1;

    for (int i = 1; i < n; i++) {
        fscanf(in, "%Lf%Lf", &x, &y);

        ans += (xp * y - x * yp) / 2;

        xp = x;
        yp = y;
    }

    ans += (x * y1 - x1 * y) / 2;

    fprintf(out, "%.5Lf\n", ans);

    return 0;

}