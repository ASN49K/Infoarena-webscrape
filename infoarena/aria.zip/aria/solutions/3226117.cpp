#include <fstream>
#include <vector>
#include <iomanip>

using namespace std;

struct punct
{
    double x, y;
};

long double aria_trapez(punct p1, punct p2)
{
    return (p1.x - p2.x) * (p1.y + p2.y);
}

int main()
{
    ifstream in("aria.in");
    ofstream out("aria.out");
    int n;
    in >> n;
    vector <punct> p(n);
    long double aria = 0;
    for (int i = 0; i < n; i++)
    {
        in >> p[i].x >> p[i].y;
        if (i > 0)
        {
            aria += aria_trapez(p[i-1], p[i]);
        }
    }
    aria += aria_trapez(p[n-1], p[0]);
    out << setprecision(6) << fixed << aria / 2 << "\n";
    in.close();
    out.close();
    return 0;
}
