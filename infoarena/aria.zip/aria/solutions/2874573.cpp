#include <bits/stdc++.h>
#define ull unsigned long long
#define CMAX 15485863
#define fastio std::ios_base::sync_with_stdio(NULL),cin.tie(NULL),cout.tie(NULL);
#define mp make_pair
#define INF 1e18
#define mod 1000000007
#define ll long long
#define SMAX 300
#define MAX 100000
#define pb push_back
#define add emplace_back
#define void inline void
#define int ll
using namespace std;
int n;
long double ans;
struct points
{
    long double x, y;
};
points v[MAX+5];
signed main()
{
    fastio
    freopen("aria.in","r",stdin);
    freopen("aria.out","w",stdout);
    cin >> n;
    for(int i = 1;i <= n; ++i)
        cin >> v[i].x >> v[i].y;
    for(int i = 3;i <= n; ++i)
    {
        points h = v[i-1], h2 = v[i];
        h.x -= v[1].x, h.y -= v[1].y;
        h2.x -= v[1].x, h2.y -= v[1].y;
        long double arie = h.x * h2.y - h2.x * h.y;
        ans += arie;
    }
    ans = abs(ans);
    cout << fixed << setprecision(8) << ans / 2.0;
}
