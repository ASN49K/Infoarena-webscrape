#include <bits/stdc++.h>
#define int long long
#define double long double
using namespace std;

int32_t main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");

    double  suma=0, a, b, lasta, lastb, firsta, firstb;
    int n;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>a>>b;
        if(i==0) firsta = a, firstb = b, lasta = a, lastb = b;
        else
        {
            double l1,l2,l3;

            l1=sqrt(abs((a-lasta)*(a-lasta)+(b-lastb)*(b-lastb)));
            l2=sqrt(abs((a-0)*(a-0)+(b-0)*(b-0)));
            l3=sqrt(abs((lasta-0)*(lasta-0)+(lastb-0)*(lastb-0)));

            double s = (l1+l2+l3)/2;
            double arie =(double)sqrt(abs(s*(s-l1)*(s-l2)*(s-l3)));
            suma+=arie;

            lasta = a;
            lastb = b;
        }
    }

    double l1,l2,l3;

    l1=sqrt(abs((firsta-lasta)*(firsta-lasta)+(firstb-lastb)*(firstb-lastb)));
    l2=sqrt(abs((firsta-0)*(firsta-0)+(firstb-0)*(firstb-0)));
    l3=sqrt(abs((lasta-0)*(lasta-0)+(lastb-0)*(lastb-0)));

    double s = (l1+l2+l3)/2;
    double arie =(double)sqrt(abs(s*(s-l1)*(s-l2)*(s-l3)));
    suma+=arie;

    cout<<std::fixed<<setprecision(10)<<suma;



    return 0;
}
