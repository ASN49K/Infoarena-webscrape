#include <bits/stdc++.h>
#define double long double

using namespace std;

int main()
{
  ifstream cin("aria.in");
  ofstream cout("aria.out");

    long long n;
    double x, y, ans=0, x2, y2, a, b;
    cin>>n>>x>>y;
    a=x;
    b=y;
    for(int i=2; i<=n; i++)
    {
        cin>>x2>>y2;
        ans+=(x*y2)-(x2*y);
        x=x2;
        y=y2;
    }
    ans+=(x*b)-(a*y);
    ans=abs(ans);
    ans=(double)ans/2;

    cout<<setprecision(5)<<ans;

    return 0;
}
