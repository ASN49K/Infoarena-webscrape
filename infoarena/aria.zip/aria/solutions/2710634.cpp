#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#define per pair<double,double>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

int n;
vector <per> v(100005);

void read(){
    cin >> n;

    for(int i = 0; i < n; i++)
        cin >> v[i].first >> v[i].second;
    v[n] = v[0];
}

void solve(){
    double ans = 0;

    for(int i = 0; i < n; i++)
        ans += v[i].first * v[i + 1].second - v[i + 1].first * v[i].second;

    cout << fixed << setprecision(5) << ans / 2.0;
}

int main()
{
    read();
    solve();

    return 0;
}
