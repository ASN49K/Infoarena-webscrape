#include <stdio.h>

#define MAX_N 100000

struct pct {
    double x, y;
};

int z[5];
struct pct p[MAX_N];

double det( struct pct a, struct pct b, struct pct c ) {
    return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
}

int main() {
    FILE *fin, *fout;
    int n, i;
    double arie;
    struct pct o;

    fin = fopen( "aria.in", "r" );
    fscanf( fin, "%d", &n );
    for ( i = 0; i < n; i++ )
        fscanf( fin, "%lf%lf", &p[i].x, &p[i].y );
    fclose( fin );

    o.x = o.y = 0;

    arie = 0;
    for ( i = 0; i < n; i++ )
        arie += det( o, p[i], p[(i + 1) % n] );
    arie /= 2;

    fout = fopen( "aria.out", "w" );
    fprintf( fout, "%0.5f", arie );
    fclose( fout );

    return 0;
}
