#include <bits/stdc++.h>

using namespace std;

#define INFILE "aria.in"
#define OUTFILE "aria.out"

typedef long double ld;

struct Point {

    ld x, y;

    Point() : x(0), y(0) {}
    Point(ld _x, ld _y) : x(_x), y(_y) {}

};

ld produsPuncte(Point &a, Point &b){
    return (a.x * b.y - b.x * a.y);
}

void solve(){

    int n; cin >> n;
    vector<Point> v(n + 1);

    for(int i = 0; i < n; ++i){
        cin >> v[i].x >> v[i].y;
    }

    v[n].x = v[0].x, v[n].y = v[0].y;

    ld ans = 0;

    for(int i = 0; i < n; ++i){
        ans += produsPuncte(v[i], v[i + 1]);
    }

    ans /= 2;

    if(ans < 0) ans = -ans;

    cout << fixed << setprecision(5) << ans << '\n';

}

int main(){
    ios_base::sync_with_stdio(false);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    cin.tie(0), cout.tie(0);
    solve();
    return 0;
}
