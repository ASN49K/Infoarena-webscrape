#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;
struct pct {
    long double x,y;
}v[NMAX + 5];

int main()
{
    ifstream fin("aria.in");
    ofstream fout("aria.out");
    int n;
    long double ans = 0;
    fin >> n;
    for (int i = 0;i < n;i++)
        fin >> v[i].x >> v[i].y;
    v[n] = v[0];
    for (int i = 0;i < n;i++)
        ans += (v[i].x * v[i + 1].y - v[i + 1].x * v[i].y);
    fout << setprecision(6) << fixed << fabs(ans / 2);
    return 0;
}
