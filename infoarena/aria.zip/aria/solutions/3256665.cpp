#include <fstream>
#include <iomanip>
using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

const int N=100002;
int n;
struct {
    long double x,y;
}v[N];

void citire()
{
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>v[i].x>>v[i].y;
}
void arie()
{
    long double s=0;
    for(int i=0;i<n-1;i++)
        s+=(v[i].y+v[i+1].y)*(v[i+1].x-v[i].x);
    s+=(v[n-1].y+v[0].y)*(v[0].x-v[n-1].x);
    cout<<fixed<<setprecision(5)<<abs(s/2);
}
int main()
{
    citire();
    arie();
    return 0;
}
