#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
long double x1, y1, x2, y2, ax1, ay1, arie;

int main()
{
    fin >> n >> ax1 >> ay1;
    x1 = ax1, y1 = ay1;
    while(--n)
    {
        fin >> x2 >> y2;
        arie += x1 * y2 - x2 * y1;
        x1 = x2, y1 = y2;
    }
    arie += x1 * ay1 - ax1 * y1;
    arie /= 2;
    fout << fixed << setprecision(5) << arie;
    return 0;
}
