#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream f ("aria.in");
ofstream g ("aria.out");
int n;
struct pct{
    double x,y;
}pcte[200004];
double rasp;
void citire()
{
    f >> n;
    for(int i = 1;i<=n;i++)
    {
        f >> pcte[i].x>> pcte[i].y;
     }
     pcte[1+n].x = pcte[1].x;
     pcte[1+n].y = pcte[1].y;

}
void calc_arie()
{
    //luam ca punct de referita 0,0
    //si acela va fi formula pentru arie
    for(int i = 1;i<=n;i++)
    {
        rasp = rasp + (pcte[i].x * pcte[i+1].y - pcte[i].y * pcte[i+1].x)/2;
    }
    g << fixed<< setprecision(5)<<rasp;
}
int main()
{
    citire();
    calc_arie();
}
