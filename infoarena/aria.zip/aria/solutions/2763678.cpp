#include <fstream>

using namespace std;

const int NMAX = 100000;

pair<int, int> puncte[1 + NMAX + 1];

int main()
{
    ifstream in("aria.in");
    ofstream out("aria.out");

    int n;
    in >> n;

    for (int i = 1; i <= n; i++)
    {
        double x, y;
        in >> x >> y;

        puncte[i] = make_pair(x, y);
    }
    puncte[n + 1] = puncte[1];

    double arie = 0.0;

    for (int i = 1; i <= n; i++)
    {
        arie += (puncte[i].first * puncte[i + 1].second - puncte[i + 1].first * puncte[i].second) / 2.0;
    }

    if (arie < 0.0)
        arie -= arie;

    out << arie << '\n';

    return 0;
}
