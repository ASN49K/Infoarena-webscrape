#include<bits/stdc++.h>
using namespace std;
ifstream F("aria.in");
ofstream G("aria.out");
#define Z 2048
int p=Z,n;
long double a,b,c,d,e,f,g;
char s[Z];
inline char A()
{
    if(p==Z)
        F.read(s,Z),p=0;
    return s[p++];
}
long double B()
{
    char c;
    for(c=A();c<48&&c!='-';c=A());
    int r=1;
    if(c=='-')
        r=-1,c=A();
    long double a=0;
    for(;c>47;a=a*10+c-48,c=A());
    if(c=='.') {
        long double b=0,p=1;
        for(c=A();c>47;b=b*10+c-48,p*=10,c=A())
            b=b*10+c-'0';
        a+=b/p;
    }
    return a*r;
}

int main()
{
    for(n=B(),a=B(),b=B(),c=B(),d=B(),g=a*d-b*c,n-=2;n--;e=B(),f=B(),g+=c*f-d*e,c=e,d=f);
    return g+=b*e-a*f,G<<fixed<<setprecision(5)<<(g<0?-g:g)/2,0;
}
