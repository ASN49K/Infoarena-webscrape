#include<iostream>
#include<fstream>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");

#define nrm 100010
int n;
int dx[nrm],dy[nrm];

void citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>dx[i]>>dy[i];
    }
}

int main ()
{
    citire();
    double aria=0;
    for(int i=1;i<n;i++)
    {
        aria=aria+(dx[i]*dy[i+1]-dx[i+1]*dy[i])/2;
    }
    aria=aria+(dx[n]*dy[1]-dx[1]*dy[n])/2;
    fout<<aria;
    fin.close();
    fout.close();
    return 0;
}
