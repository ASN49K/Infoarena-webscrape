#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
long double x[100002],y[100002];
int main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");
    int n;
    long double A=0;
    cin>>n>>x[0]>>y[0];
    for(int i=1;i<n;i++)
    {
        cin>>x[i]>>y[i];
        A=A+(x[i]-x[i-1])*(y[i]+y[i-1]);
    }
    A=A+(x[0]-x[n-1])*(y[0]+y[n-1]);
    cout<<fixed<<setprecision(6)<<abs(A/2);
    return 0;
}
