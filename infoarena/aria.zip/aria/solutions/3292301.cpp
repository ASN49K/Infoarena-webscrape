// 100 Puncte
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");
long double x[100005], y[100005];
int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n; fin>>n;
    for (int i=1; i<=n; i++) {
        fin>>x[i]>>y[i];
    }
    x[n+1] = x[1]; y[n+1] = y[1];
    long double arie = 0;
    for (int i=1; i<=n; i++) {
        long double arie_mini = (x[i]*y[i+1]-y[i]*x[i+1]);
        arie+=arie_mini;
    }
    arie = abs(arie)/2;
    fout << fixed << setprecision(6) << arie;
    return 0;
}