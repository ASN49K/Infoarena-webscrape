#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
//#include <bits/stdc++.h>
#define in fin
#define out fout

using namespace std;
using ll = long long;
using db = double;

ifstream fin("aria.in");
ofstream fout("aria.out");

signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll n; in >> n;
    db x[n], y[n];

    for(int i = 0; i < n; i++) in >> x[i] >> y[i];
    db A = 0;
    for(int i = 0; i + 1 < n; i++){
        A += (x[i] * y[i + 1] - x[i + 1] * y[i]) / 2;
    }
    A += (x[n - 1] * y[0] - x[0] * y[n - 1]) / 2;
    out << fixed << setprecision(6) << A << '\n';

    return 0;
}