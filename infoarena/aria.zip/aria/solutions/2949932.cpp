#include<bits/stdc++.h>
using namespace std;
ifstream F("aria.in");
ofstream G("aria.out");
int n;
double a,b,c,d,x,y,s;
int main()
{
    for(F>>n>>a>>b,x=a,y=b;F>>c>>d;s+=abs(a*d-b*c),a=c,b=d);
	return G<<fixed<<setprecision(5)<<(s+abs(x*b-y*a))/2,0;
}
