#include <iomanip>
#include <cmath>
#include <fstream>
using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
int n;
long double arie,total;

struct {
    long double x,y;
} P[100010];

int main() {
    f>>n;
    for(int i=1; i<=n; i++) {
        f>>P[i].x>>P[i].y;
    }
    P[n+1]=P[1];
    for(int i=1; i<=n; i++) {
        arie=fabsl(P[i].x*P[i+1].y-P[i].y*P[i+1].x);
        total+=arie;
    }
    g<<fixed<<setprecision(5)<<total/2.0;
    f.close();
    g.close();
    return 0;
}
