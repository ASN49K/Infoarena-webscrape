#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n;
long double x[100005],y[100005];
long double aria=0;

int main()
{
 f>>n;
 for(int i=1;i<=n;i++)
 {
  f>>x[i]>>y[i];
 }

 for(int i=1;i<=n;i++)
  aria = aria + ( x[i]*y[i+1] ) * ( x[i+1]*y[i] );

 g<< setprecision(5) << fixed << aria/2;
}
