#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n, x[100001],y[100001],i;
long double S1=0,S2=0;
long double aria; //fara matematica mea nu fac nimic :<
int main()
{
    fin >> n;
    for(i=1;i<=n;i++)
    {
        fin>>x[i]>>y[i];
    }
    // Folosim formula lui Shoelace,care se cunoaste din matematica.
    for(i=1;i<n;i++)
    {
        S1=S1 + x[i] * y[i + 1];
        S2=S2 + y[i] * x[i + 1];
    }
    S1= S1 + x[n] * y[1];
    S2= S2 + y[n] * x[1];
    aria = 1.0 * abs(S1-S2) / 2.0;
    fout << fixed << setprecision(5) << aria ;
    return 0;
}
