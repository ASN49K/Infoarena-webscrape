#include <bits/stdc++.h>
using namespace std;

struct point
{
    double x, y;
};
vector<point> v;

int main (void)
{
    int n;
    double res=0;

    ///input
    ifstream f("aria.in");
    f>>n;
    v.resize(n+1);
    for(int i=0;i<n;i++)
        f>>v[i].x>>v[i].y;
    v[n]=v[0];
    f.close();

    ///solution
    for(int i=0;i<n;i++)
        res+=(v[i].x*v[i+1].y-v[i+1].x*v[i].y);

    ///output
    ofstream g("aria.out");
    g<<fabs(res/2.0);
    g.close();

    return 0;
}
