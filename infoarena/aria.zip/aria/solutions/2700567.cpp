#include <bits/stdc++.h>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

pair<double,double> v[100005];
int main()
{
	int n;
	in>>n;
	for(int i=1;i<=n;i++)
		in>>v[i].first>>v[i].second;
	v[n+1]=v[1];
	double s=0;
	for(int i=1;i<=n;i++)
		s+=(v[i].first*v[i+1].second-v[i+1].first*v[i].second);
	out<<fixed<<setprecision(5)<<s / 2.0<<"\n";
	return 0;
}
