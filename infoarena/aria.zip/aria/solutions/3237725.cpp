#include<bits/stdc++.h>
using namespace std;
ifstream F("aria.in");
ofstream G("aria.out");
long double a,b,c,d,e,f,s;
int main()
{
    for(F>>a>>a>>b>>c>>d,s=a*d-b*c;F>>e>>f;s+=c*f-d*e,c=e,d=f);
    return s+=a*d-b*c,G<<fabs(s/2),0;
}
