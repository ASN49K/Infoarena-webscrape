#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int nmax = 100000;
int n;

struct Point
{
    long long x, y;
}v[nmax + 5];

long double arie;

int main()
{
    fin >> n;
    for (int i = 1; i <= n; ++i)
    {
        fin >> v[i].x >> v[i].y;
    }
    v[n + 1] = v[1];
    for (int i = 1; i <= n; ++i)
    {
        arie += 1LL * v[i].x * v[i + 1].y - 1LL * v[i + 1].x * v[i].y;
    }
    if (arie < 0)
    {
        arie = -arie;
    }
    arie /= 2.0;
    fout << fixed << setprecision(6) << arie;
    fin.close();
    fout.close();
    return 0;
}
