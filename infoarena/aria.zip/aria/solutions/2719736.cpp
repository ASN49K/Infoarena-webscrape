#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int NMax = 1e5;

int n;
float A;
float x[NMax + 5], y[NMax + 5];

void Read(){
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> x[i] >> y[i];
    x[n + 1] = x[1], y[n + 1] = y[1];
}

void Solve(){
    for (int i = 1; i <= n; i++)
        A += x[i] * y[i + 1] - x[i + 1] * y[i];
    A /= 2;
}

void Print(){
    fout << fixed << setprecision(5) << A << '\n';
}

int main(){
    Read();
    Solve();
    Print();
    return 0;
}
