#include <fstream>
#include <cmath>

using namespace std;

ifstream in ("aria.in");
ofstream out ("aria.out");

const int max_size = 1e5 + 2;

pair <double, double> v[max_size];

int main ()
{
    int n;
    in >> n;
    for (int i = 1; i <= n; i++)
    {
        in >> v[i].first >> v[i].second;
    }
    v[n + 1] = v[1];
    double rez = 0;
    for (int i = 1; i <= n; i++)
    {
        rez += (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);
    }
    out << (double) fabs((double) rez / 2);
    in.close();
    out.close();
    return 0;
}
