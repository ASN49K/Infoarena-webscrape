#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
pair<long long, long long> a[100005];

long long Aria(pair<long long, long long> A, pair<long long, long long> B) {
    return A.first * B.second - A.second * B.first;
}

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i].first >> a[i].second;

    long long aria = 0;
    a[n + 1] = a[1];
    for (int i = 2; i <= n + 1; i++)
        aria += Aria(a[i - 1], a[i]);

    fout << fixed << setprecision(6) << aria / 2.0 << "\n";
    return 0;
}
