#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
pair<long double,long double> puncte[100005];
int main()
{
    long double arie=0;
    int i,n;
    fin>>n;
    for(i=1;i<=n;++i)
    {
        fin>>puncte[i].first>>puncte[i].second;
    }
    for(i=1;i<n;++i)
    {
        arie+=(puncte[i].first*puncte[i+1].second-puncte[i].second*puncte[i+1].first);
    }
    arie+=(puncte[n].first*puncte[1].second-puncte[n].second*puncte[1].first);
    arie=arie*0.5;
    fout<<setprecision(6)<<arie;
    return 0;
}
