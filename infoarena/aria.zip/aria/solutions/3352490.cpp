#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int a[100100];
int b[100100];
int main(){
    int n;
    fin>>n;
    for(int i=1; i<=n; i++){
        fin>>a[i]>>b[i];
    }
    float f=0;
    long long l=0;
    for(int i=1; i<n; i++){
        l=1ll*(l+a[i]*b[i+1]-a[i+1]*b[i]);
    }
    l=1ll*(l+a[n]*b[1]-a[1]*b[n]);
    f=l;
    fout<<f/2;
    return 0;
}
