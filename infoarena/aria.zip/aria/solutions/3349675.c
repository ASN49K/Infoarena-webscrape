#include <stdio.h>
#include <math.h>

FILE *fin, *fout;

struct coord {
    long double x, y;
}p[100000];

int main(void) {
    fin = fopen("aria.in", "r");
    int n;
    fscanf(fin, "%d", &n);
    for(int i = 0; i < n; ++i) {
        fscanf(fin, "%Lf%Lf", &p[i].x, &p[i].y);
    }
    fclose(fin);

    long double S = 0;
    for(int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        S += p[i].x * p[j].y - p[j].x * p[i].y;
    }
    S = fabsl(S) / 2.0;

    fout = fopen("aria.out", "w");
    fprintf(fout, "%.5Lf\n", S);
    fclose(fout);

    return 0;
}