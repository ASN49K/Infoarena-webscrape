#include <bits/stdc++.h>

#define int long long

using namespace std;
int x[100001];
int y[100001];

signed main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x[i];
        cin>>y[i];
    }
    int ans=x[1]*y[n]-y[1]*x[n];
    for(int i=2;i<=n;i++)
    {
        ans+=x[i]*y[i-1]-y[i]*x[i-1];
    }
    ans=abs(ans);
    if(ans%2==0)
    {
        ans=ans/2;
        cout<<ans<<".00000";
    }
    else
    {
        ans=ans/2;
        cout<<ans<<".50000";
    }

    return 0;
}
