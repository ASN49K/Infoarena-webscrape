
#include <fstream>
#include <vector>
#include <iomanip>
#include <cstdlib>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
int n;
vector<pair<int,int>> A;
double arie;
int main()
{
    cout<<setprecision(6)<<fixed;
    cin>>n;
    A.resize(n+1);
    for(int i=0;i<n;i++)
      cin>>A[i].first>>A[i].second;
    A[n]=A[0];
    for(int i=0;i<n;i++)
         arie=arie+A[i].first*A[i+1].second-A[i].second*A[i+1].first;
    if(arie<0)
      arie=arie*-1;
    cout<<arie/2;
    return 0;
}
