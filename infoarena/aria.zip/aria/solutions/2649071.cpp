#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int N;
long double x,y;

struct punct
{
    long double x,y;
};
punct P1,PN,PN_1;

double Arie(const punct &A,const punct &B,const punct &C)
{
    return abs((B.x-A.x)*(C.y-A.y)-(C.x-A.x)*(B.y-A.y))/2.0;
}

int main()
{
    f>>N;
    double arie=0;
    f>>P1.x>>P1.y;
    f>>PN.x>>PN.y;
    N-=2;
    while(N--)
    {
        f>>PN_1.x>>PN_1.y;
        arie+=Arie(P1,PN,PN_1);
        PN=PN_1;
    }
    g<<fixed<<setprecision(6)<<arie;
    return 0;
}
