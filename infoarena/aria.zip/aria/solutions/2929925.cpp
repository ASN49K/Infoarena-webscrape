#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct pct
{
    int x;
    int y;
}a[100005];

int n;

void cit()
{
    f>>n;

    for(int i=0;i<n;i++)
        f>>a[i].x>>a[i].y;
}

int det(pct A, pct B)
{
    int nr=A.x*B.y-A.y*B.x;

    return nr;
}

int modul(int x)
{
    if(x<0)
        return ((-1)*x);

    return x;
}

double supr()
{
    double s=0;

    for(int i=0;i<n-1;i++)
        s+=0.5*modul(det(a[i],a[i+1]));

    s+=0.5*modul(det(a[n-1],a[0]));

    return s;
}

void afis()
{
    g<<setprecision(5)<<supr();
}

int main()
{
    cit();

    afis();

    return 0;
}
