#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int N;
long double x,y;

struct punct
{
    long double x,y;
};
punct P1,PN,PN_1;


int main()
{
    f>>N;
    long double arie=0;
    f>>PN.x>>PN.y;
    P1=PN;
    while(--N)
    {
        f>>PN_1.x>>PN_1.y;
        arie+=(PN.x*PN_1.y-PN_1.x*PN.y);
        PN=PN_1;
    }
    PN_1=P1;
    arie+=(PN.x*PN_1.y-PN_1.x*PN.y);
    arie=abs(arie)/2.0;
    g<<fixed<<setprecision(5)<<arie;
    return 0;
}
