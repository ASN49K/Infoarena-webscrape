#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct point{
    long double abscisa;
    long double ordonata;
} theArray[100005];
int main()
{
    int n;
    fin>>n;
    long double sum = 0;
    for(int i = 0; i < n; i++){
        fin>>theArray[i].abscisa>>theArray[i].ordonata;
    }
    for(int i = 1; i < n; i++){
        sum += (theArray[i - 1].abscisa * theArray[i].ordonata - theArray[i - 1].ordonata * theArray[i].abscisa);
    }
    sum += theArray[n - 1].abscisa * theArray[0].ordonata - theArray[n - 1].ordonata * theArray[0].abscisa;
    fout<<sum / 2;
    fin.close();
    fout.close();
    return 0;
}
