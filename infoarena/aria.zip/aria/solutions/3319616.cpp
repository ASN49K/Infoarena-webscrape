#include <iomanip>
#include <fstream>
#include <vector>
#include <cmath>
#define pdd pair<double, double>

using namespace std;

const string txt = "aria";
const int nmax = 1e5 + 5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n;
pdd v[nmax];

int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        f >> v[i].first >> v[i].second;

    double ans = 0; v[n + 1] = v[1];
    for (int i = 1; i <= n; i++)
        ans += (v[i].first * v[i + 1].second - v[i + 1].first * v[i].second);

    g << fixed << setprecision(6) << (double)ans / 2.0;
    return 0;
}