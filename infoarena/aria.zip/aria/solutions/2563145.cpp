#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main()
{
    int N,i;
    long double x1,y1,x2,y2,xs1,ys1,s=0;
    fin>>N;
    fin>>x1>>y1;
    xs1=x1;
    ys1=y1;
    for(i=1;i<N;i++)
    {
        fin>>x2>>y2;
        s+=x1*y2-x2*y1;
        x1=x2;
        y1=y2;
    }
    s+=x1*ys1-y1*xs1;
    fout<<fixed<<setprecision(5)<<s*0.5;
}
