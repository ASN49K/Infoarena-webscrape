#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <iomanip>

#define MOD 1999999973
#define INT_MAX 1000000000

using namespace std ;

ifstream cin ("aria.in") ;
ofstream cout ("aria.out") ;

double sum = 0, px = 0, py = 0 ;

double det(double x1, double y1, double x2, double y2, double x3, double y3)
{
    return ((x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1)) / 2 ;
}

int main()
{
    int n ;

    cin >> n ;

    double c, d, cc, dd ;

    cin >> c >> d ;

    cc = c ;
    dd = d ;

    for(double f = 2, a, b ; f <= n ; f ++)
    {
        cin >> a >> b ;

        sum += det(px, py, c, d, a, b) ;

        c = a ;
        d = b ;
    }

    cout << fixed << setprecision(5) << abs(sum + det(px, py, c, d, cc, dd)) ;

    return 0 ;
}


