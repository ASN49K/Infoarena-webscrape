#include <bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const vector<int> dx = {-1, 0, 1, 0};
const vector<int> dy = {0, 1, 0, -1};

bool up(pair<int, int> p)
{
    return p.second > 0 or (p.second == 0 and p.first >= 0);
}

int cross(int x1, int y1, int x2, int y2)
{
    return x1 * y2 - y1 * x2;
}

long double area(long double x1, long double y1,long double x2,long double y2,long double x3,long double y3)
{
    return (y2 + y1) * (x1 - x2) + (y1 + y3) * (x3 - x1) - (y2 + y3) * (x3 - x2) * 0.5;
}

int32_t main()
{
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    fin >> n;
    vector<pair<int, int>> points(n);
    for (int i = 0; i < n; ++i)
    {
        fin >> points[i].first >> points[i].second;
    }
    // sort(points.begin(), points.end(), [&](pair<int, int> a, pair<int, int> b)
    //  { return up(a) == up(b) ? cross(a.first, a.second, b.first, b.second) > 0 : up(a) < up(b); });
    long double ans = 0;
    for (int i = 0; i < n - 1; ++i)
    {
        ans += area(0, 0, points[i].first, points[i].second, points[i + 1].first, points[i + 1].second);
    }
    ans += area(0, 0, points[n - 1].first, points[n - 1].second, points[0].first, points[0].second);
    fout << ans;
}