#include <bits/stdc++.h>

using namespace std;
//#define double long long

namespace geometry
{
const double PI = 3.141592653589793238;

struct Point
{
    double x,y;
    Point(double _x = 0, double _y = 0) : x(_x), y(_y) {}
};

struct Line
{
    double a,b,c;
    Line(double _a = 0, double _b = 0, double _c = 0) : a(_a), b(_b), c(_c) {}
    Line(Point p1, Point p2) : a(p1.y - p2.y),
                               b(p2.x - p1.x),
                               c(p1.x * (p2.y - p1.y) - p1.y * (p2.x - p1.x)) {}

    double where(const Point &p) const {
        return a * p.x + b * p.y + c;
    }
    double angle() const {
        return (b==0? PI/2 : atan(-a/b));
    }
};

const Point INF = Point(1e9,1e9);
const Point O = Point(0,0);
const Line Ox = Line(0,1,0);
const Line Oy = Line(1,0,0);

Point rotate(const Point &p, double angle) {
    return Point(p.x * cos(angle) - p.y * sin(angle),
                 p.x * sin(angle) + p.y * cos(angle));
}

double distance(const Point &a, const Point &b) {
    return sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));
}

Point midpoint(const Point &a, const Point &b) {
    return Point((a.x+b.x)/2, (a.y+b.y)/2);
}

Point reflect(const Point &o, const Point &p) {
    return Point(o.x+o.x-p.x, o.y+o.y-p.y);
}

Point rotateAbout(const Point &p, const Point &o, double angle) {
    Point rot = rotate(Point(p.x-o.x, p.y-o.y), angle);
    return Point(rot.x+o.x, rot.y+o.y);
}

double det(const Point &a, const Point &b, const Point &c) {
    return a.x*b.y + a.y*c.x + b.x*c.y - b.y*c.x - a.y*b.x - a.x*c.y;
}

double area(const Point &a, const Point &b, const Point &c) {
    return abs(det(a,b,c))/2;
}

bool same(const Line &l1, const Line &l2) {
    return l1.a*l2.b - l2.a*l1.b == 0 && l1.a*l2.c - l2.a*l1.c == 0;
}

bool parallel(const Line &l1, const Line &l2) {
    return l1.a*l2.b - l2.a*l1.b == 0;
}

bool perpendicular(const Line &l1, const Line &l2) {
    return l1.a*l2.a + l1.b*l2.b == 0;
}

double angle(const Line &l1, const Line &l2) {
    if(parallel(l1,l2)) return 1e9;
    return acos(abs(l1.a*l2.a + l1.b*l2.b)/(sqrt(l1.a*l1.a + l1.b*l1.b) * sqrt(l2.a*l2.a + l2.b*l2.b)));
}

Point intersect(const Line &l1, const Line &l2) {
    if(parallel(l1,l2)) return INF;
    return Point((-l1.c*l2.b + l2.c*l1.b) / (l1.a*l2.b - l2.a*l1.b),
                 (-l1.a*l2.c + l2.a*l1.c) / (l1.a*l2.b - l2.a*l1.b));
}

double distance(const Point &p, const Line &l) {
    return l.where(p) / sqrt(l.a*l.a + l.b*l.b);
}

Point project(const Point &p, const Line &l) {
    return Point(p.x - l.a * l.where(p) / (l.a*l.a + l.b*l.b),
                 p.y - l.b * l.where(p) / (l.a*l.a + l.b*l.b));
}

Point reflect(const Point &p, const Line &l) {
    return Point(p.x - 2 * l.a * l.where(p) / (l.a*l.a + l.b*l.b),
                 p.y - 2 * l.b * l.where(p) / (l.a*l.a + l.b*l.b));
}

Line parallel(const Point &p, const Line &l) {
    return Line(l.a, l.b, - l.a*p.x - l.b*p.y);
}

Line perpendicular(const Point &p, const Line &l) {
    return Line(l.b, -l.a, l.a*p.y - l.b*p.x);
}
}

using namespace geometry;

mt19937 mt(chrono::steady_clock::now().time_since_epoch().count());
int rng(int a, int b)
{
    return uniform_int_distribution<int>(a,b)(mt);
}
#define int long long
Point v[100005];

signed main()
{
    ifstream fin ("aria.in");
    ofstream fout ("aria.out");
    #ifdef HELLO
    #define fin cin
    #define fout cout
    #endif // HELLO
    ios::sync_with_stdio(false); fin.tie(0); fout.tie(0);
    int n; fin>>n;
    for(int i=1; i<=n; ++i)
        fin>>v[i].x>>v[i].y;
    v[n+1] = v[1];
    double ar = 0;
    for(int i=1; i<=n; ++i)
        ar += det(O, v[i], v[i+1]);
    fout<<abs(ar/2);
    return 0;
}
