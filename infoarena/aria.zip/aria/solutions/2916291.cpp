/**
 *    author:  R0L3eX
 *    created: 28.07.2022 11:22:37
 *    quote: Claustrophobic? Who would ever be afraid of Santa Clause?
**/

#include "bits/stdc++.h"

using namespace std;

#if defined(ONPC)
#include "bits/debug.h"
#endif

#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
template<typename T> using matrix = vector<vector<T> >;
template<typename T> void Unique(T &a) {a.erase(unique(a.begin(), a.end()), a.end());}

void setIO(string name = "") {
  cin.tie(0)->sync_with_stdio(0);
  if ((int)name.size()) {
    freopen((name + ".in").c_str(), "r", stdin);
    freopen((name + ".out").c_str(), "w", stdout);
  }
}

const int MOD = 1e9 + 7;
const int mxN = 2e5;
const int INF = INT_MAX;
const char nl = '\n';

struct point {
  int x, y;
};

int determinant(point A, point B, point C) {
  /*
   * A.x A.y 1
   * B.x B.y 1
   * C.x C.y 1
  */
  return A.x * B.y + A.y * C.x + B.x * C.y - B.y * C.x - C.y * A.x - B.x * A.y;
}

int main() {
  setIO("aria");

  int n;
  cin >> n;
  vector<point> points(n);

  for (point &P : points) {
    cin >> P.x >> P.y;
  }

  point O = {0, 0};
  points.push_back(points[0]);

  int ans = 0;
  for (int i = 1; i <= n; ++i) {
    int area = determinant(O, points[i], points[i - 1]);
    ans += area;
  }
  cout << abs(ans) / 2 << nl;
}
