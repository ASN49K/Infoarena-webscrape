#include <fstream>
#include <iomanip>
using namespace std;
ifstream cin ("aria.in");
ofstream cout ("aria.out");
struct ura{
    double x, y;
};
ura v[100005];
double aria;
int main()
{
    int n, i;
    cin >> n;
    for (i = 1; i <= n; i++)
        cin >> v[i].x >> v[i].y;
    v[n + 1] = v[1];
    for (i = 1; i <= n; i++)
        aria += v[i].x * v[i + 1].y - v[i].y * v[i + 1].x;
    aria = aria / 2.0;
    cout << fixed << setprecision(5) << aria;
    return 0;
}
