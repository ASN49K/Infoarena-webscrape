﻿#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include <map>
typedef unsigned long long ull;
typedef long long ll;
typedef unsigned int uint;
#define endl '\n'
using namespace std;
#if 1
#include <fstream>
ifstream fin("aria.in");
ofstream fout("aria.out");
#define cin fin
#define cout fout
#endif
struct vec2
{
	float x, y;
	inline vec2 Minus(const vec2& v2)
	{
		return { x - v2.x , y - v2.y };
	}
};
inline float cross(const vec2& v1, const vec2& v2)
{
	return v1.x * v2.y - v1.y * v2.x;
}
int main()
{
	vec2 p1;
	vec2 p2;
	int n;
	cin >> n;
	cin >> p1.x >> p1.y;
	cin >> p2.x >> p2.y;
	n--;
	float ans = 0;
	while (n--)
	{
		vec2 p3;
		cin >> p3.x >> p3.y;
		ans += cross(p2.Minus(p1), p3.Minus(p1))/2;
		p2 = p3;
	}
	cout << abs(ans);
}