#include <fstream>

using namespace std;
const int NMAX = 100002;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct puncte {
    int x, y;
}v[NMAX];
int main()
{
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++)
        cin >> v[i].x >> v[i].y;
    v[n + 1].x = v[1].x;
    v[n + 1].y = v[1].y;
    int ans = 0;
    for(int i = 2; i <= n + 1; i++) {
        ans += (v[i - 1].x * v[i].y - v[i].x * v[i - 1].y);
    }
    if(ans < 0)
        ans *= (-1);
    cout << (double)ans / 2;
    return 0;
}
