#include <fstream>
#include <iomanip>
#define int long double
using namespace std;
ifstream cin ("aria.in");
ofstream cout ("aria.out");
int x[100005];
int y[100005];
int rasp;
int32_t n;
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (int32_t i=1;i<=n;i++)
        cin >> x[i] >> y[i];
    x[n+1] = x[1];
    y[n+1] = y[1];
    for (int32_t i=1;i<=n;i++)
        rasp = rasp + (x[i]*y[i+1] - x[i+1]*y[i]);
    cout << fixed << setprecision(30) << rasp/2.0;
    return 0;
}
