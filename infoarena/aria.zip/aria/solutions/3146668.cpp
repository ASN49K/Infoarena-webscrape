#include <bits/stdc++.h>

using namespace std;

struct points {
   double a, b;
}v[100005];

int main()
{
    ifstream f("aria.in");
    ofstream g("aria.out");

    int n;
    f>>n;
    for(int i=0; i<n; i++) {
        f>>v[i].a>>v[i].b;
    }
    v[n]=v[0];

    double area = 0;
    for(int i=0; i<n; i++) {
        area += v[i].a * v[i+1].b - v[i+1].a * v[i].b;
    }
    area /= 2;

    g<<fixed<<setprecision(6)<<area;

    return 0;
}
