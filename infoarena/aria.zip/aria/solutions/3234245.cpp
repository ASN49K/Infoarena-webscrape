#include <bits/stdc++.h>

using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
long double px,py;
long double aria(long double x1,long double y1,long double x2,long double y2)
{
    return (x1*(y2-0)+x2*(0-y1))/2;
}
struct punct
{
    long double x;
    long double y;
} A[100001];
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>A[i].x>>A[i].y;
    }
    py=0;
    px=0;
    long double ARIE=0;
    for(int i=1;i<n;i++)
    {
        ARIE+=aria(A[i].x,A[i].y,A[i+1].x,A[i+1].y);
    }
    ARIE+=aria(A[n].x,A[n].y,A[1].x,A[1].y);
    fout<<fixed<<setprecision(7)<<ARIE;
    return 0;
}
