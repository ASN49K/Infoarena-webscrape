#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>
using namespace std;


int main(){
    ifstream fin("aria.in");
    freopen("aria.out", "w", stdout);
    int nrp;
    fin>>nrp;
    double pi,pj; //primul punct ca sa il fac cu ultimul
    fin>>pi>>pj;
    --nrp;
    double p1i, p1j, p2i, p2j;
    double sum=0;

    for (p1i=pi, p1j=pj; nrp; --nrp){
        fin>>p2i>>p2j;
        sum+=p1i*p2j-p2i*p1j;
        p1i=p2i;   p1j=p2j;
    }
    sum+=p2i*pj-pi*p2j;
    double rez=0.5*sum;
    printf("%f", rez*(-1)*(rez<0)+rez*(rez>=0));
}



































