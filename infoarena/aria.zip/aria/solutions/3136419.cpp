#include <fstream>
#include <iomanip>
#include <vector>
#include <cmath>
#define ll long long
using namespace std;
#define double float

const int INF = (1 << 30);

ifstream cin("aria.in");
ofstream cout("aria.out");

struct Point
{
    double x, y;
    void Read()
    {
        cin >> x >> y;
    }
    Point operator - (const Point &other) const
    {
        return {x - other.x, y - other.y};
    }
    double operator * (const Point &other) const
    {
        return x * other.y - y * other.x;
    }
};

int main()
{
    int n;
    cin >> n;

    vector<Point> Polygon(n);
    for(int i = 0; i < n; i++)
        Polygon[i].Read();

    double Area = 0;
    for(int i = 0; i < n; i++)
        Area += Polygon[i] * Polygon[i + 1 == n ? 0 : i + 1];

    cout << fixed << setprecision(5) << abs(Area) / 2.0;


    return 0;
}