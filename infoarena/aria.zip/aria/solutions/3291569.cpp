#include <bits/stdc++.h>

using namespace std;


ifstream fin("aria.in");
ofstream fout("aria.out");

int main()
{
    int n; fin >> n;


    vector<long double> x(n);
    vector<long double> y(n);

    for(int i = 0;i < n;i++)
    {
        fin >> x[i] >> y[i];
    }

    long double ans = 0;

    for(int i = 0;i < n - 1;i++)
    {
        long double term = (x[i] * y[i + 1] - y[i] * x[i + 1]);
        ans += term;
    }

    ans += (x.back() * y[0] - y.back() * x[0]);

    ans /= 2.00;

    fout << fixed << setprecision(10) << ans << endl;
}
