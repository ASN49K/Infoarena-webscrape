#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
double s;
long long x[100005], y[100005], n, i;
int main()
{
    fin>>n;
    for (i=1; i<=n; i++) {
        fin>>x[i]>>y[i];
    }
    x[n+1]=x[1];
    y[n+1]=y[1];
    for (i=1; i<=n; i++) {
        s+=(0*y[i]+0*x[i+1]+x[i]*y[i+1]-0*x[i]-0*y[i+1]-y[i]*x[i+1])/2;
    }
    fout<<s;
    return 0;
}
