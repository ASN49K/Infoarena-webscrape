#include <fstream>
#include <iomanip>

using namespace std;

const int NMAX = 1e5 + 5;

ifstream cin("aria.in");
ofstream cout("aria.out");

pair <long double, long double> v[NMAX];

long double arie(pair <long double, long double> a, pair <long double, long double> b)
{
    return 1.0 * a.first * b.second - 1.0 * b.first * a.second;
}

int main() {
    int n;
    cin >> n;
    for(int i = 1; i <= n; ++i) {
        cin >> v[i].first >> v[i].second;
    }
    v[n + 1] = v[1];
    long double ans = 0.0;
    for(int i = 1; i <= n; ++i) {
        ans += arie(v[i], v[i + 1]);
    }
    ans /= 2.0;
    cout << fixed << setprecision(6) << ans << "\n";
    return 0;
}