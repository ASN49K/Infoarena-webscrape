#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct point{

    double x , y;
};

double arie , art , semip , a , b , c;

int main(){

    point x , y , z;

    int n;

    cin >> n;

    n-=2;

    cin >> x.x >> x.y;

    cin >> y.x >> y.y;

    while(n--){

        cin >> z.x >> z.y;

        a = sqrt((x.x - y.x)*(x.x - y.x) + (x.y - y.y)*(x.y - y.y));
        b = sqrt((x.x - z.x)*(x.x - z.x) + (x.y - z.y)*(x.y - z.y));
        c = sqrt((z.x - y.x)*(z.x - y.x) + (z.y - y.y)*(z.y - y.y));

        semip = (a+b+c)/2;

        art = sqrt(semip*(semip-a)*(semip-b)*(semip-c));

        arie += art;

        y = z;
    }


    cout << fixed << setprecision(6) << arie;

    return 0;
}
