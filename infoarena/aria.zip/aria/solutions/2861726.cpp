#include <fstream>
#include <iomanip>
#include <math.h>

using namespace std;
ifstream fin ("aria.in");
ofstream fout ("aria.out");

struct punct
{
    double linie, coloana;
} v[100002];

int n;


int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>v[i].coloana>>v[i].linie;
    double rezultat=0.0;
    v[n+1]=v[1];
    for(int i=1; i<=n; i++)
    {
        rezultat+=(v[i].coloana*v[i+1].linie - v[i+1].coloana*v[i].linie);
    }
    fout<<fixed<<setprecision(6)<<fabs(rezultat/2);
    return 0;
}
