#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
ifstream f ("aria.in");
ofstream g ("aria.out");
int n;
struct punct{
    int x,y;
}puncte[100001];
//folosim formula pentru a calcula aria unui triunghi
// iar poligonul este format din mai multe triunghiuri cu care au cate un colt in origine
// deci facem aria a tuturor triunghiurilor care formeaza poligonul si au un varf in origine
// adica orice triunghi din 2 puncte consecutive in vector si originea
// matricea va arata
/*
|pct1.x pct1.y 1|
|pct2.x pct2.y 1|
|0       0     1|
*/
// datorita acestei formule ariile de care nu este nevoie se vor scadea cu ajutorul determinantului
float determinantul(punct pct1,punct pct2)
{
    return ((pct1.x * pct2.y)-(pct2.x * pct1.y));
}
int main()
{
    f >> n;
    for(int i = 1;i<=n;i++)
    {
        f >> puncte[i].x >> puncte[i].y;
    }
    puncte[0] = puncte[n];
    float total = 0;
    for(int i = 0;i<=n;i++)
    {
        total += (float)(determinantul(puncte[i],puncte[i+1])/2);
    }

    g << fixed<< setprecision(6)<<total;
}
