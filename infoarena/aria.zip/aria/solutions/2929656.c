#include <stdio.h>
#include <stdlib.h>

FILE *f1open;
FILE *f2open;


struct point{
		double x,y;
	}a,b,c;

double aria(struct point a,struct point b)
{
	return (0.5*a.x)*b.y - (0.5*b.x)*a.y;
}



int main()
{

	f1open = fopen("aria.in", "r");
	f2open = fopen("aria.out", "w");


	int n;
	long double surface=0;

	fscanf(f1open, "%d",&n);


	if(n<3){
	fprintf(f2open,"0");
	return 0;
	}


	//scanf("%lf%lf",&a.x, &a.y);
	//scanf("%lf%lf",&b.x, &b.y);

	fscanf(f1open, "%lf%lf",&a.x, &a.y);
	c = a;

	for(int i=2;i<=n;i++)
	{
		fscanf(f1open, "%lf%lf",&b.x, &b.y);
		surface+=aria(a,b);
		//printf("\n%lf",aria(a,b) );
		a = b;

	}
	surface+=aria(b,c);
	

	fprintf(f2open, "%Lf\n",surface);
	


	fclose(f1open);
	fclose(f2open);
	

	return 0;
}