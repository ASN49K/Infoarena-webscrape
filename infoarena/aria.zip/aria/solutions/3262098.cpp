#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f ("aria.in");
ofstream g ("aria.out");

struct punct {
    long double x, y;
};

long double aria(const punct &A, const punct &B) {
    return A.x * B.y - A.y * B.x;
}

int main() {
    int n;
    long double arie = 0;
    punct A, B, C;
    f >> n >> A.x >> A.y;
    B = A;
    for (int i=2; i<=n; i++) {
        f >> C.x >> C.y;
        arie += aria(B, C);
        B = C;
    }
    arie += aria(C, A);
    arie /= 2;
    g << fixed << setprecision(5) << arie;
    f.close();
    g.close();
    return 0;
}
