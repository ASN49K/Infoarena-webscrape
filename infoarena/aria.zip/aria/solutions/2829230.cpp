#include <fstream>
#include <cmath>

int main() {
	std::ifstream fin("aria.in");
	std::ofstream fout("aria.out");
	int nrn;
	double posx, posy, antx, anty, fstx, fsty;
	double ans = 0;
	fin >> nrn;
	fin >> antx >> anty;
	fstx = antx;
	fsty = anty;
	for (int index = 1; index < nrn; index++) {
		fin >> posx >> posy;
		ans += posx * anty - posy * antx;
		antx = posx;
		anty = posy;
	}
	ans += fstx * anty - fsty * antx;
	fout << std::abs(ans) / 2;
}