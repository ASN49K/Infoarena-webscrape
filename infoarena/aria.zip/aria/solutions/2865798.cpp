#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;

int main()
{
    ifstream in("aria.in");
    ofstream out ("aria.out");
    long double xi1, yi1, xi2, yi2, n, arie = 0, xinitial, yinitial;
    /// xi1 = coordonata lui x pentru primul punct ecuatie; yi1 = coordonata lui y pentru primul punct din ecuatie; xi2 = coordonata lui x pentru al doilea punct din ecuatie; yi2 = coordonata lui y pentru al doilea punct din ecuatie;
    in >> n;
    in >> xi1 >> yi1;
    xinitial = xi1;
    yinitial = yi1;
    for (int i = 1; i <= n - 1; i++)
    {
        in >> xi2 >> yi2;
        arie += (xi1 * yi2 - xi2 * yi1);
        xi1 = xi2;
        yi1 = yi2;
    }
    arie += (xi2 * yinitial - xinitial * yi2);
    arie = abs(arie) / 2;
    out << fixed << setprecision(12) << arie << '\n';
}
