#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <cassert>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>

using namespace std;

template<typename T> struct P {
	T x, y;
};

template<typename T> P<T> operator + (P<T> a, P<T> b) {
	return { a.x + b.x, a.y + b.y };
}

template<typename T> P<T> operator - (P<T> a, P<T> b) {
	return { a.x - b.x, a.y - b.y };
}

template<typename T> T operator * (P<T> a, P<T> b) {
	return a.x * b.y - a.y * b.x;
}

signed main() {
#ifdef ONPC	
	FILE* stream;
	freopen_s(&stream, "input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
#endif

	int n;
	cin >> n;
	vector<P<long double>> pts(n);
	for (int i = 0; i < n; i++) cin >> pts[i].x >> pts[i].y;
	long double sol = 0;
	for (int i = 0; i < n; i++) {
		sol += pts[i] * pts[(i + 1) % n];
	}
	cout << fixed << setprecision(5) << abs(sol) * 0.5 << "\n";

	return 0;
}