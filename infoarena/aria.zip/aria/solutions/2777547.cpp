#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

ifstream cin ("aria.in") ;
ofstream cout ("aria.out") ;

vector<pair<int, int> > puncte ;

unsigned long long suma(pair<int, int> A1, pair<int, int> A2)
{
    return A1.first * A2.second - A1.second * A2.first ;
}

int main()
{
    int q ;

    cin >> q ;

    while(q --)
    {

        int a, b ;

        cin >> a >> b ;

        puncte.push_back({a, b}) ;

    }

    puncte.push_back(puncte[0]) ;

    unsigned long long stot = 0 ;

    for(int f = 0 ; f < puncte.size() - 1 ; f ++)
        stot += suma(puncte[f], puncte[f + 1]) ;

    if(stot < 0)stot *= -1 ;

    cout << stot / 2 ;

    return 0;
}
