#include <fstream>
#include <vector>
#include <cmath>
#include <iostream>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

double area(double x[], double y[], int n)
{
    double a = 0;
    for (int i = 0; i < n; ++i)
    {
        a += x[i] * y[i + 1] - x[i + 1] * y[i];
    }
    return a / 2.0;
}

int n;
int main()
{
    fin >> n;
    double x[n + 1], y[n + 1];
    for (int i = 0; i < n; ++i)
    {
        fin >> x[i] >> y[i];
    }
    x[n] = x[0];
    y[n] = y[0];
    fout << fixed << setprecision(10) << abs(area(x, y, n));
    return 0;
}
