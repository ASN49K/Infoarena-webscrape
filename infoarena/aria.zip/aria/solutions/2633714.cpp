#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct elem
{
    double x, y;
} v[100005];

int main()
{
    int n;

    fin >> n;

    for(int i = 1; i <= n; i++)
        fin >> v[i].x >> v[i].y;

    v[n + 1].x = v[1].x;
    v[n + 1].y = v[1].y;

    double arie = 0;

    for(int i = 1; i <= n; i++)
        arie +=(double) ((double)v[i].x * v[i + 1].y - (double)v[i + 1].x * v[i].y);

    fout << fixed << setprecision(6) << (double) arie / 2 << '\n';

    return 0;
}
