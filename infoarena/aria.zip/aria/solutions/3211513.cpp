#include <bits/stdc++.h>
using namespace std;

struct Punct
{
    long double x, y;
};

Punct a[100003];
int n;

int main()
{
    int i, n;
    long double answer;
    ifstream fin("aria.in");
    ofstream fout("aria.out");
    fin >> n;
    for (i = 0; i < n; i++)
        fin >> a[i].x >> a[i].y;

    a[n] = a[0];
    answer = 0;
    for (i = 0; i < n; ++i)
        answer += (a[i].x * a[i + 1].y - a[i + 1].x * a[i].y);
    fout << setprecision(5) << fixed << fabs (answer / 2.0);
    fout.close();
}