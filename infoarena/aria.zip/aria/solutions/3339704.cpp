#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int n;
double sum=0;
struct punct{
    double x,y;
}p[100005];

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>p[i].x>>p[i].y;
    }
    p[n+1].x=p[1].x;
    p[n+1].y=p[1].y;
    for(int i=1;i<=n;i++)
    {
        sum=sum+p[i].x*p[i+1].y-p[i].y*p[i+1].x;
    }
    if(sum<0)
        sum=-sum;
    fout<<fixed<<setprecision(5)<<sum*0.5;
    return 0;
}
