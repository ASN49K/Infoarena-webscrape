#include <iostream>
#include <vector>
#include <iomanip>
#include <fstream>

using namespace std;

struct Point {
    double x, y;
};

double shoelaceFormula(const vector<Point>& points) {
    int n = points.size();
    double area = 0.0;

    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        area += points[i].x * points[j].y;
        area -= points[i].y * points[j].x;
    }

    area = abs(area) / 2.0;
    return area;
}

int main() {
    ifstream infile("aria.in");
    ofstream outfile("aria.out");

    int N;
    infile >> N;

    vector<Point> points(N);
    for (int i = 0; i < N; ++i) {
        infile >> points[i].x >> points[i].y;
    }

    double area = shoelaceFormula(points);

    outfile << fixed << setprecision(5) << area << endl;

    infile.close();
    outfile.close();

    return 0;
}
