#include <bits/stdc++.h> 

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int MAXN = 1e5 + 5;
struct Point {
    double x;
    double y;
} puncte[MAXN];

int N, x, y;
double aria;
//aria poligonului o putem afla prin triangularizarea acestuia
// iar apoi facem suma ariilor
// luam arbitrat punctul P(0, 0) cu care formam triunghiuri (P Ai Ai+1) (consideram si ca A1 = An+1)
// aria unui triunghi o sa fie 1/2(xi*yi+1 - yi*xi+1 )


int main() {

    fin >> N;
    for ( int i = 1; i <= N; ++ i) {
        fin >> puncte[i].x >> puncte[i].y;
    }
    for ( int i = 1; i <= N; ++ i ) {
        if ( i == N ) {
            aria += (puncte[1].x * puncte[i].y - puncte[i].x * puncte[1].y);    
        }
        else  aria += (puncte[i].x * puncte[i+1].y - puncte[i+1].x * puncte[i].y);
    }
    fout << aria;
}