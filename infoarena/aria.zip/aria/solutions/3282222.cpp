///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 20011
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int i,n;
struct ceva
{
    long double x,y;
} v[100010];
long double ras;
long double cross(ceva a,ceva b)
{
    long double nr=0;
    nr=a.x*b.y-a.y*b.x;
    return nr/2;
}
int main()
{
    cin.tie(0);
    cout.tie(0);
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    v[n+1]=v[1];
    for(i=1; i<=n; i++)
        ras+=cross(v[i],v[i+1]);
    fout<<fixed<<setprecision(6)<<ras;
    return 0;
}
