#include <bits/stdc++.h>
using namespace std;

#define NMAX 100005

double trng(pair<double, double> p1, pair<double, double> p2) {
	return 0.5 * (p1.first * p2.second - p1.second * p2.first);
}

pair<double, double> points[NMAX];
double area;

int main() {
	ifstream fin("aria.in");
	ofstream fout("aria.out");

	int n;
	fin >> n;

	for (int i = 1; i <= n; ++i)
		fin >> points[i].first >> points[i].second;

	points[n + 1] = points[1];

	for (int i = 1; i <= n; ++i)
		area += trng(points[i], points[i + 1]);

	fout << area << '\n';
}
