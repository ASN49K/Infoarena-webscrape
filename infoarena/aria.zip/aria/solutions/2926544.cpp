#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

void solve() {
    int n;
    fin >> n;
    int x[n + 2], y[n + 2];
    for (int i = 1; i <= n; ++i) {
        fin >> x[i] >> y[i];
    }
    x[n + 1] = x[1];
    y[n + 1] = y[1];
    double arie = 0;
    for (int i = 1; i <= n; ++i) {
        arie += (double)((abs(x[i] * y[i + 1] - x[i + 1] * y[i])))/2; 
    }
    fout << fixed << setprecision(5) << arie;
}

int main() {

    int T = 1;
    //cin >> T;
    while (T--) {
        solve();
    }

    return 0;
}

//read the question correctly (ll vs int)
//what's the meaning of the problem ? Think outside the BOX !!!
//edge cases ?
//make it simple
//write everything (observations, edge cases, ideas, steps, methods, ..
