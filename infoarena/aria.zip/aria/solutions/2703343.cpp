#include <fstream>
#include <iomanip>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
const int N = 100010;
int n;
long double x[N],y[N],aria;
int main()
{
    f>>n;
    for(int i=0;i<n;i++)
        f>>x[i]>>y[i];
    x[n]=x[0];y[n]=y[0];
    for(int i=0;i<n;i++)
        aria+=(x[i]-x[i+1])*(y[i]+y[i+1]);
    aria/=2.0;
    if(aria<0)
        aria=-aria;
    g<<fixed<<setprecision(10)<<aria<<'\n';
    return 0;
}

