#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream f("aria.in");
ofstream fout("aria.out");

struct puncts
{
    float x, y;
};
int n;
float triunghi(puncts a, puncts b)
{
    return a.x*b.y-a.y*b.x;
}
void prelucrare()
{
    f>>n;
    puncts p1,copiep1,p;

    f>>p1.x>>p1.y;
    copiep1.x=p1.x;
    copiep1.y=p1.y;
    float S=0;

    for(int i=1; i<n-1; i++)
    {

        f>>p.x>>p.y;
        S+=triunghi(p1, p);
        p1=p;
    }

    S+=triunghi(p, copiep1)/2;

    fout<<fixed<<setprecision(5)<<abs(S);
}
int main()
{
    prelucrare();
    return 0;
}
