#include<bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
float n,x[100002],y[100002],a,i;
float arie(pair<float,float>a,pair<float,float>b,pair<float,float>c)
{
    return (float)abs(a.first*(b.second-c.second)+b.first*(c.second-a.second)+c.first*(a.second-b.second));
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>x[(int)i]>>y[(int)i];
    for(i=2;i<n;i++)
    {
        a+=arie(make_pair(x[1],y[1]),make_pair(x[(int)i],y[(int)i]),make_pair(x[(int)(i+1)],y[(int)(i+1)]));
    }
    fout<<fixed<<setprecision(5)<<a/2.0;
    return 0;

}
