#include <stdio.h>
#include <stdint-gcc.h>

/*5.int factorial(int n)
{
    if(n==0)
        return 1;
    return n*factorial(n-1);
}*/
/*10.int cmmdc1(int a,int b)
{
    while(b)
    {
        if(a>b)
            a=a-b;
        else
            b=b-a;
    }
    return a;

}*/
int main()
{
    /*1.int n;
    scanf("%d", &n);
    if(n%2==0)
        printf("Numarul e par");
    else
        printf("Numarul e impar")
    if(n&1==1)
         printf("Numarul e par");
    else
        printf("Numarul e impar");*/
    /*2.int a,b,c;
    scanf("%d %d %d", &a, &b, &c);
    if(a+b>c && a+c>b && b+c>a)
        printf("DA");
    else
        printf("NU");*/
    /*3.printf("%ld\n",sizeof(int));
    printf("%ld\n",sizeof(short int));
    printf("%ld\n",sizeof(long int));*/
    /*4.int n=5;
    for(int i=n;i>=1;i--)
    {
        for(int j=i;j>=1;j--)
            printf("*");
        printf("\n");
    }*/
    /*5.10int n;
    scanf("%d", &n);
    printf("%d", factorial(n));*/
    /*6.int n;
    scanf("%d", &n);
    int n1=0;
    n1=n;
    int n2=0;
    while(n1)
{
    int c=n1%10;
    n2=n2*10+c;
    n1=n1/10;
}
    if(n==n2)
        printf("Numarul este palindrom");
    else
        printf("Numarul nu este palindrom");*/
    /*7.int n;
    while(scanf("%d", &n)!=EOF)
    {
        if(n<0)
            break;
        int div=2;
        if(n==0 || n==1)
            printf("NU\n");
        else
        {
            int ok=1;
            while(div<n)
            {
                if(n%div==0)
                {
                    ok=0;
                    printf("%d",div);
                }
                div++;
            }
            if(ok==1)
                printf("PRIM\n");
        }
    }*/
    /*8.int n;
    scanf("%d", &n);
    int t=1;
    int m=0;
    while(n)
    {
        if(t%2==0)
        {
            int c=n%10;
            m=m*10+c;
        }
        t++;
        n=n/10;
    }
    int m1=0;
    while(m){
        int c=m%10;
        m1=m1*10+c;
        m=m/10;
    }
    printf("%d", m1);*/
    /*9.int a,b;
    scanf("%d %d", &a, &b);
    while(b)
    {
        if(a>b)
            a=a-b;
        else
            b=b-a;
    }
    printf("%d", a);*/
    /*10.int n;
    scanf("%d", &n);
    int v[100];
    for(int i=0;i<n;i++)
    {
        scanf("%d", &v[i]);
    }
    int cmmdc=v[0];
    for(int i=1;i<n;i++)
    {
        cmmdc=cmmdc1(cmmdc,v[i]);
    }
    printf("%d",cmmdc);*/
    /*11.int a,b,c;
    a=0;
    printf(0,0,0);
    for(c=1;c<=50;c++)
    {
        printf("%d %d %d\n",a,-c,c);
    }*/
   /*12.int a,b,c,d,e;
    a=0;
    printf(0,0,0,0,0);
    d=1;
    for(c=1;c<=50;c++)
    {
        printf("%d %d %d %d %d\n",a,-c,c,-d,d);
        d++;
    }*/
    FILE *fin, *fout;
    fin = fopen("aria.in", "r");
    fout = fopen("aria.out", "w");


    int n;
    fscanf(fin, "%d", &n);
    double x[10005], y[10005];

    for (int i = 0; i < n; i++) 
    {
        fscanf(fin, "%d %d", &x[i], &y[i]);
    }
    x[n] = x[0];
    y[n] = y[0];

    long double a = 0;
    for (int i = 0; i < n; i++) 
    {
        a += (long double)x[i] * y[i + 1] - (long double)x[i + 1] * y[i];
    }

    double aria = (double)a / 2.0;
    if (aria < 0)
        aria = -aria;

    fprintf(fout, "%.2f\n", aria);

    fclose(fin);
    fclose(fout);
    return 0;
}