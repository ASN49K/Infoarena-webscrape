#include <fstream>
#include <iomanip>
using namespace std;
ifstream in("aria.in");
ofstream out("aria.out");
double n, i, j, ar;
struct dur
{
    double x, y;
}a, b, c, that;
double abs(double x)
{
    if (x > 0)
        return x;
    return -x;
}
int main()
{
    in >> n;
    in >> b.x >> b.y; that = b;
    for (i = 2; i <= n; i++)
    {
        in >> c.x >> c.y;
        ar += (a.x * b.y + a.y * c.x + b.x * c.y - a.x * c.y - a.y * b.x - b.y * c.x);
        b = c;
    }
    c = that;
    ar += (a.x * b.y + a.y * c.x + b.x * c.y - a.x * c.y - a.y * b.x - b.y * c.x);
    out << fixed << setprecision(5) << ar/2;
}
