#include <fstream>
#include <iomanip>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

const int NMAX = 1e5;

int N;
pair<long double, long double> points[NMAX + 2];

/*
xa * yb + xb * yc + xc * ya
- xc * yb - xa * yc - xb * ya
*/

long double TriangleArea(pair<long double, long double> A, pair<long double, long double> B, pair<long double, long double> C) {
    return 0.5 * (A.first * B.second + B.first * C.second + C.first * A.second
                  - C.first * B.second - A.first * C.second - B.first * A.second);
}

int main() {
    cin >> N;

    for(int i = 1; i <= N; i++) {
        cin >> points[i].first >> points[i].second;
    }
    points[N + 1] = points[1];

    long double area = 0;
    for(int i = 1; i <= N; i++) {
        area += TriangleArea({0, 0}, points[i], points[i + 1]);
    }

    cout << fixed << setprecision(5) << max(area, -area) << '\n';
    return 0;
}
