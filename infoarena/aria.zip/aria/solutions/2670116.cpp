#include <bits/stdc++.h>
using namespace std;
pair <long double,long double> coord[100005];
ifstream fin("aria.in");
ofstream fout("aria.out");
int main() {
    int n;
    long double arie = 0;
    fin >> n;
    for(int i = 1;i <= n; ++i)
        fin >> coord[i].first >> coord[i].second;
    for(int i = 1;i < n; ++i)
        arie += coord[i].first * coord[i+1].second - coord[i+1].first * coord[i].second;
    arie += coord[n].first * coord[1].second - coord[1].first * coord[n].second;
    if(arie < 0)
        arie = -arie;
    fout << fixed << setprecision(5) <<  arie / 2;
    return 0;
}
