#include <fstream>
#include<iomanip.h>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct coordonate
{
    int x;
    int y;
};
struct coordonate v[100005];

int main()
{
    int n;
    long double a = 0;
    cin >> n;

    for(int i = 0;i < n;i ++)
    {
        cin >> v[i].x >> v[i].y;
    }

    for(int i = 1;i < n;i ++)
    {
        a += (1. * v[i-1].x * v[i].y - 1. * v[i].x * v[i-1].y) / 2;
    }
    a += (1. * v[n-1].x * v[0].y - 1. * v[n-1].y * v[0].x) / 2;

    cout << setprecision(5) << fixed << a;

    return 0;
}
