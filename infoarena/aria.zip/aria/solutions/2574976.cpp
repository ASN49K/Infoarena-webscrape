#include <bits/stdc++.h>
#define NMAX 100005

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

struct Punct
{
    long double x, y;
};

Punct v[NMAX];

long double Aria ( Punct a, Punct b, Punct c );

int main()
{
    long double aria = 0;
    int n, i;

    fin >> n;
    for ( i = 1 ; i <= n ; i++ ) fin >> v[i].x >> v[i].y;

    for ( i = 2 ; i < n ; i++ ) aria += Aria ( v[1], v[i], v[i+1] );

    fout << fixed << setprecision ( 5 ) << aria;

    return 0;
}

long double Aria ( Punct a, Punct b, Punct c )
{
    b.x -= a.x;
    b.y -= a.y;
    c.x -= a.x;
    c.y -= a.y;

    return ( b.x * c.y - b.y * c.x ) / 2;
}
