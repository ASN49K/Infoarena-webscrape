#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

const int maxN = 1e5 + 5;

struct punct {
   long double x, y;
} p[maxN];

int main() {

    int n; fin >> n;

    for(int i = 1; i <= n; ++i) {
        fin >> p[i].x >> p[i].y;
    }

    p[n+1] = p[1];

    long double ans = 0;
    for(int i = 1; i <= n; ++i)
        ans += (p[i].x * p[i+1].y - p[i+1].x * p[i].y);

    ans /= 2;

    fout << setprecision(6) << fixed << ans;

    return 0;
}
