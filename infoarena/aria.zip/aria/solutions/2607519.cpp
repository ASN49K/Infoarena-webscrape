#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
double arie, p[100010][2];

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> p[i][0] >> p[i][1];
    p[n + 1][0] = p[1][0];
    p[n + 1][1] = p[1][1];

    for (int i = 1; i <= n; i++)
        arie += (p[i][0] * p[i + 1][1] - p[i + 1][0] * p[i][1]);

    fout << fixed << setprecision(5) << abs(arie / 2.0);
    return 0;
}
