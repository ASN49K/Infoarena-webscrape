#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
long double rez;
struct point
{
    long double x,y;
}prima,x,y;
long double aria(point a,point b,point c)
{
    a.x-=c.x;
    a.y-=c.y;
    b.x-=c.x;
    b.y-=c.y;
    return (a.x*b.y-a.y*b.x)/2.0;
}
int main()
{
    fin>>n>>prima.x>>prima.y>>x.x>>x.y;
    for(int e=3; e<=n; e++)
    {
        fin>>y.x>>y.y;
        rez+=aria(prima,x,y);
        x=y;
    }
    fout<<fixed<<setprecision(6)<<rez;
    return 0;
}
