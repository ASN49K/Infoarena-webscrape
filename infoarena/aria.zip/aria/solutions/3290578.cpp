#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");

double x[100005], y[100005];

int main()
{
    long double arie = 0;
    int n;
    cin>>n;
    for(int i = 1; i <= n; ++i)
    {
        cin>>x[i]>>y[i];
        if(2 <= i)
        {
            arie += x[i-1] * y[i] - x[i] * y[i-1];
        }
    }
    arie += x[n] * y[1] - x[1] * y[n];
    arie = abs(arie);
    arie /= 2;
    cout<<setprecision(5)<<fixed<<arie;
    return 0;
}
