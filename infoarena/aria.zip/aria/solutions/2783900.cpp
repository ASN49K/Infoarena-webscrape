#include<cstdio>
using namespace std;
FILE*in=fopen("aria.in","r");
FILE*out=fopen("aria.out","w");
const int NMAX=100009;
int n,i,x[NMAX],y[NMAX];
long long s;
double f;
int main()
{
    fscanf(in,"%d",&n);
    for(i=1;i<=n;i++)
    {
        fscanf(in,"%d%d",&x[i],&y[i]);
        if(i>=2)
        {
            s=(long long)(s+(long long)((long long)(x[i-1]*y[i])-(long long)(x[i]*y[i-1])));
        }
    }
    s=(long long)(s+(long long)((long long)(x[n]*y[1])-(long long)(x[1]*y[n])));
    f=(double)(s/2);
    fprintf(out,"%.1f",f);
}
