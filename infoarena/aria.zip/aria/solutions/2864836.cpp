#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <string>

#define MOD 1999999973
#define INT_MAX 1000000000

using namespace std ;

ifstream cin ("aria.in") ;
ofstream cout ("aria.out") ;

long long sum = 0 ;

long long det(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return ((x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1)) / 2 ;
}

int main()
{
    int n ;

    cin >> n ;

    int c, d, cc, dd ;

    cin >> c >> d ;

    cc = c ;
    dd = d ;

    for(int f = 2, a, b ; f <= n ; f ++)
    {
        cin >> a >> b ;

        sum += det(0, 0, c, d, a, b) ;

        c = a ;
        d = b ;
    }

    cout << abs(sum + det(0, 0, c, d, cc, dd)) ;

    return 0 ;
}
