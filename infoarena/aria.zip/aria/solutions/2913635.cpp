#include <stdio.h>
#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;

int main(void) {
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(nullptr);
  // freopen("aria.in", "r", stdin);
  // freopen("aria.out", "w", stdout);
  int N;
  cin >> N;
  ld px, py, x0,y0;
  ld aria = 0;
  for(int i = 0; i < N; i++) {
    ld x,y;
    cin >> x >> y;
    if (i) {
      aria += x * py - px * y;
    } else {
      x0 = x, y0 = y;
    }
    px = x, py = y;
  }
  aria += x0 * py - y0 * px;
  cout << fixed << setprecision(5) << abs(aria)/2.0 << "\n";

  return 0;
}
