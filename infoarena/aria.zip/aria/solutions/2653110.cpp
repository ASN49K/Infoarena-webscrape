#include <fstream>
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main(int argc, char const *argv[])
{
	ifstream fin("aria.in");
	ofstream fout("aria.out");

	int N; 
	fin >> N;

	long double x0, y0, x1, y1;
	fin >> x0 >> y0;
	x1 = x0; y1 = y0;

	long double A = 0;
	for (int i = 1; i < N; i++)
	{
		long double x2, y2;
		fin >> x2 >> y2;

		A += (x1 * y2 - x2 * y1) / 2;
		x1 = x2; y1 = y2;
	}

	A += (x1 * y0 - x0 * y1) / 2;
	A = abs(A);

	fout << fixed << setprecision(6) << A;

	return 0;
}