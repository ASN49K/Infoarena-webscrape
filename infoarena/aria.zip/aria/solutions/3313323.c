#include <stdio.h>
#include <stdlib.h>
#include <math.h>


struct coord
{
    float x,y;
};
int main(void)
{
    FILE *pf = fopen("arie.in", "r");
    FILE *pl = fopen("arie.out", "w");
    struct coord curr,ant,primul;
    int n;
    float p,P,S,a,b,c;
    P=0;
    S=0;
    fscanf(pf, "%d", &n);
    fscanf(pf, "%f%f", &primul.x, &primul.y);
    if(n>1){
    fscanf(pf, "%f%f", &curr.x, &curr.y);
    P=P+sqrt((primul.x-curr.x)*(primul.x-curr.x)+(primul.y-curr.y)*(primul.y-curr.y));
    for(int i=1;i<n-1;i++){
        ant=curr;
        fscanf(pf, "%f%f", &curr.x, &curr.y);
        P=P+sqrt((curr.x-ant.x)*(curr.x-ant.x)+(curr.y-ant.y)*(curr.y-ant.y));
        a=sqrt((curr.x-ant.x)*(curr.x-ant.x)+(curr.y-ant.y)*(curr.y-ant.y));
        b=sqrt((primul.x-ant.x)*(primul.x-ant.x)+(primul.y-ant.y)*(primul.y-ant.y));
        c=sqrt((curr.x-primul.x)*(curr.x-primul.x)+(curr.y-primul.y)*(curr.y-primul.y));
        p=(a+b+c)/2;
        S=S+sqrt(p*(p-a)*(p-b)*(p-c));
    }
    P=P+sqrt((primul.x-curr.x)*(primul.x-curr.x)+(primul.y-curr.y)*(primul.y-curr.y));
    }
    else
    {
        P=0;
        S=0;
    }
    fprintf(pl,"%f\n%f", P, S);
    fclose(pf);
    fclose(pl);


    return 0;
}
