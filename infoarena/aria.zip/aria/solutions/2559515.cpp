#include <bits/stdc++.h>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

#define x first
#define y second
const int nmax = 1e5 + 5;

pair <double, double> p[nmax];

double sol = .5, sum = 0;

int n;

double arie (pair <double, double> A, pair <double, double>B)
{
    return A.x * B.y - A.y * B.x;
}

int main()
{
    fin >> n;
    for (int i=1; i<=n; ++i)
        fin >> p[i].x >> p[i].y;

    p[n+1] = p[1];

    for (int i=2; i<=n+1; ++i)
        sum += arie(p[i-1], p[i]);

    sol *= sum;

    fout << fixed << setprecision(6) << fabs(sol);
    return 0;
}
