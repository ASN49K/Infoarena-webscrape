#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct punct
{
    double x;
    double y;
};

punct a[100001];
int n;
double rez;

void citire()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> a[i].x >> a[i].y;
    }
}

void rezolvare()
{
    for(int i = 1; i < n; i++)
    {
        rez = rez + (a[i].x * a[i+1].y - a[i+1].x * a[i].y);
    }
    rez = rez + (a[n].x * a[1].y - a[1].x * a[n].y);
    fout << fixed << setprecision(5) << rez/2;
}

int main()
{
    citire();
    rezolvare();
}
