#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

struct Punct
{
    double x{0}, y{0};
};

double arie;
int n;
Punct a[100004];

double det(Punct a, Punct b, Punct c)
{
    return (a.x - c.x)*(b.y - c.y) - (b.x - c.x)*(a.y - c.y);
}

int main()
{
    fin >> n;
    for(int i = 0; i < n; i++)
        fin >> a[i].x >> a[i].y;
    a[n++] = a[0];
    Punct zero;
    for(int i = 0; i < n; i++)
        arie += det(a[i], a[i+1], zero)/2;
    fout <<fixed<<setprecision(15)<< arie;
    return 0;
}
