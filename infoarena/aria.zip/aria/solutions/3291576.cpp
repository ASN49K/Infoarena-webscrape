#include <bits/stdc++.h>
#define cin in
#define cout out
using namespace std;

ifstream in("arie.in");
ofstream out("arie.out");

struct punct
{
    long double x, y;
};

long double arie(punct a, punct b)
{
    return ((a.x*b.y)-(a.y*b.x))/2;
}

int main()
{
    int n;
    punct nr, nr2, first;
    long double a=0;
    cin>>n>>nr.x>>nr.y>>nr2.x>>nr2.y;
    first=nr, a+=arie(nr, nr2);
    for(int i=2; i<n; i++)
    {
        nr=nr2;
        cin>>nr2.x>>nr2.y;
        a+=arie(nr,nr2);
    }
    a+=arie(nr2, first);
    cout<<fixed<<setprecision(5)<<a;
}