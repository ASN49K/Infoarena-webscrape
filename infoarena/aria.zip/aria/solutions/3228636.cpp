#include <bits/stdc++.h>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

int main () {
    int n; fin >> n;
    vector<pair<double, double>>v;
    for (int i = 1; i <= n; i++) {
        double x, y; fin >> x >> y;
        v.push_back({x, y});
    }
    v.push_back(v[0]);
    long double answer = 0;
    for (int i = 0; i < n; i++) {
        answer += v[i].first * v[i + 1].second - v[i + 1].first * v[i].second;
    }
    answer /= 2.0;
    fout << abs(answer);
}
