#include <iostream>
#include <fstream>
using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

struct pct{
    double x, y;
}v[100001], p;
int n;
long double ar;

long double arieTriunghi(double x1, double y1, double x2, double y2, double x3, double y3) {
    return ((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)) / 2.0;
}

int main() {
    in >> n;
    for (int i = 1; i <= n; i++)
        in >> v[i].x >> v[i].y;
    v[n + 1] = v[1];
    for (int i = 1; i <= n + 1; i++) 
        ar += arieTriunghi(v[i].x, v[i].y, v[i + 1].x, v[i + 1].y, p.x, p.y);
    out << ar;
    return 0;
}
