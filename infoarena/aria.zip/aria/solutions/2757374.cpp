///#include <iostream>
#include <fstream>
#include <cmath>
const int SIZE = 1e5+10;

using namespace std;
typedef long double ld;

ifstream cin("aria.in");
ofstream cout("aria.out");

struct punct
{
    ld y, x;
};

punct v[SIZE];
int n;

void readit()
{
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>v[i].y>>v[i].x;
}

ld deter(punct a, punct b, punct c)
{
    return (1.0*a.x*b.y+b.x*c.y+c.x*a.y)
          -(1.0*b.y*c.x+a.y*b.x+a.x*c.y);
}

ld getSurface(punct v[], int n)
{
    ld aria=0;
    for(int i=1; i<n; i++)
        aria+=deter({0, 0}, v[i], v[i+1]);
    aria+=deter({0, 0}, v[n], v[1]);
    return abs(aria/2.0);
}

int main()
{
    readit();
    cout<<fixed<<setprecision(5)<<getSurface(v, n);
    return 0;
}
