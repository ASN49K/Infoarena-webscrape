#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

struct
{
   long double x,y;
}v[100100];
int n,i;
long double aria;

int main()
{
    f>>n;
    for(i=1;i<=n;i++)f>>v[i].x>>v[i].y;
    for(i=2;i<=n;i++)aria=aria+(v[i-1].x*v[i].y-v[i-1].y*v[i].x);
    aria=aria+(v[n].x*v[1].y-v[n].y*v[1].x);
    aria=aria/2;

    g<<fixed<<setprecision(5)<<aria;
    return 0;
}
