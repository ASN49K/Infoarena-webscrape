#include <fstream>
using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

const int N=100002;
int n;
struct {
    double x,y;
}v[N];

void citire()
{
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>v[i].x>>v[i].y;
}
void arie()
{
    double s=0;
    for(int i=0;i<n-1;i++)
        s+=(v[i].y+v[i+1].y)*(v[i+1].x-v[i].x)/2;
    s+=(v[n-1].y+v[0].y)*(v[1].x-v[n-1].x)/2;
    cout<<abs(s);
}
int main()
{
    citire();
    arie();
    return 0;
}
