#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;

struct pct
{
    double x, y;
}v[100003];
int main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");
    int n, i;
    cin >> n;
    for (i = 1; i <= n; i++)
        cin >> v[i].x >> v[i].y;
    v[n + 1] = v[1];
    double ans = 0;
    for (i = 1; i <= n; i++)
        ans += v[i].x * v[i + 1].y - v[i].y * v[i + 1].x;
    ans /= 2;
    cout << ans;
}
