#include <bits/stdc++.h>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int n,v[2][100005];
long double aria=0;

int main()
{
 f>>n;
 for(int i=1;i<=n;i++)
 {
  f>>v[0][i]>>v[1][i];
 }
 v[0][n+1]=v[0][1];
 v[1][n+1]=v[1][1];

 for(int i=1;i<=n;i++)
  aria = aria + ( v[0][i]-v[0][i+1] ) * ( v[1][i+1]+v[1][i] );
 g<< setprecision(5) << fixed << aria/2;
}
