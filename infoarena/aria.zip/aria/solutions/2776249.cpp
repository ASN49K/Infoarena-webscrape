#include<cstdio>
int n,i;
long double x[100001],y[100001],s;
int main()
{
    freopen("aria.in","r",stdin),freopen("aria.out","w",stdout),scanf("%d",&n);
    for(i=0;i<n;++i)
        scanf("%Lf%Lf",x+i,y+i);
    for(x[n]=x[0],y[n]=y[0],i=0;i<n;++i)
        s=s+x[i]*y[i+1]-x[i+1]*y[i];
    printf("%.5Lf",s/2);
    return 0;
}
