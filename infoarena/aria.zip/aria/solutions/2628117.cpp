#include <bits/stdc++.h>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");
int i,n;
long double a[100001],b[100001];
long double sum;
int main(int argc, char *argv[]) {
	f>>n;
	f>>a[1]>>b[1];
	for(i=2;i<=n;i++)
	{
		f>>a[i]>>b[i];
		sum+=(a[i-1]*b[i]-a[i]*b[i-1])*0.5;
	}
	sum+=(a[n]*b[1]-a[1]*b[n])*0.5;
	g<<fixed<<setprecision(6)<<sum;
}
