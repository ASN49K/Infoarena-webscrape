#include <bits/stdc++.h>

using namespace std;
double x[100005], y[100005];
int main()
{
    ifstream cin("aria.in");
    ofstream cout("aria.out");
    ///suma unui poligon convex este 1/2 * suma de (x[i-1]*y[i] - x[i]*y[i-1])
    int n;
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>x[i]>> y[i];
    x[0]=x[n];
    y[0]=y[n];
    long double arie=0;
    for(int i=1; i<=n; i++)
    arie+=(x[i-1]*y[i]-x[i]*y[i-1]);
    arie/=2;
    cout<<arie;
    return 0;
}
