#include <bits/stdc++.h>
using namespace std;
 
 
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

struct Point {
    long double x, y;
};

void solve(){
    int n;
    cin >> n;
    vector<Point> points(n);
    for(int i = 0; i < n; i++)
        cin >> points[i].x >> points[i].y;
    points.pb(points[0]);
    long double area = 0;
    for(int i = 1; i <= n; i++){
        Point p = points[i];
        Point q = points[i-1];
        area += (p.x - q.x) * (p.y + q.y);
    }
    cout << fixed << setprecision(6) << fabs(area) / 2 << '\n';
}
 
int main(){
    freopen("aria.in", "r", stdin);
    freopen("aria.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}