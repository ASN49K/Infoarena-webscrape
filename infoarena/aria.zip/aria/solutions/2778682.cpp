#include<bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
pair<double,double>v[100001];
int main()
{
    int n;
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].first>>v[i].second;
    double arie=0.0;
    v[0]=v[n];
    for(int i=1;i<=n;i++)
    {
        int p1=i;
        int p2=(i+1)%n;
        arie+=0.5*(v[p1].first*v[p2].second-v[p2].first*v[p1].second);
        cout<<0.5*(v[p1].first*v[p2].second-v[p2].first*v[p1].second)<<endl;
    }
    fout<<abs(arie);
}
