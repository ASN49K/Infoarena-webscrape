#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
long long s;
long long x[100005], y[100005], n, i;
int main()
{
    fin>>n;
    for (i=1; i<=n; i++) {
        fin>>x[i]>>y[i];
    }
    x[n+1]=x[1];
    y[n+1]=y[1];
    for (i=1; i<=n; i++) {
        s+=x[i]*y[i+1]-y[i]*x[i+1];
    }
    s=abs(s);
    fout<<fixed<<setprecision(5)<<double(s)/2;
    return 0;
}
