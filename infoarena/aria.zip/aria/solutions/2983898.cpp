#include <algorithm>
#include <cstdio>
#include <utility>
#include <vector>

using namespace std;

double compute_area_with_0(pair<double, double> p1, pair<double, double> p2) {
    return p1.first * p2.second - p2.first * p1.second;
}

double compute_area(pair<double, double> p1, pair<double, double> p2, pair<double, double> p3) {
    return 0.5 * abs(p1.first * p2.second + p2.first * p3.second +
                     p3.first * p1.second - p1.first * p3.second -
                     p2.first * p1.second - p3.first * p2.second);
}

int main() {
    freopen("aria.in", "r", stdin);
    freopen("aria.out", "w", stdout);

    int n;
    int area = 0;
    vector<pair<double, double>> points;

    scanf("%d", &n);
    points.resize(n + 1);

    for (int i = 0; i < n; i++) {
        scanf("%lf %lf", &points[i].first, &points[i].second);
    }
    points[n] = points[0];

    for (int i = 0; i < n; i++) {
        area += compute_area_with_0(points[i], points[i + 1]);
    }

    printf("%.5lf", (double)abs(area) / 2);

    return 0;
}