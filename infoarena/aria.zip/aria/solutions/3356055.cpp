#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int MAX = 100005;

struct punct {
    double x, y;
}vec[MAX];

int N;
double sol;

int main (void) {

    fin>>N;
    for (int i = 0; i < N; ++i) {
        fin>>vec[i].x>>vec[i].y;
    }
    vec[N] = vec[0];
    for (int i = 0; i < N; ++i)
        sol += (vec[i].x * vec[i + 1].y - vec[i + 1].x * vec[i].y);
    sol/=2;
    sol = abs(sol);
    fout<<setprecision(6)<<fixed<<sol;
}
