#include <iostream>
#include <vector>

using namespace std;

double cross(pair <double, double> a, pair <double, double> b) {
    return a.first * b.second - a.second * b.first;
}

int main()
{
    #ifndef LOCAL
        freopen("aria.in", "r", stdin);
        freopen("aria.out", "w", stdout);
    #endif // LOCAL
    int n;
    cin >> n;
    vector <pair <double, double>> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i].first >> v[i].second;
    }
    v.push_back(v[0]);
    double ans = 0;
    for (int i = 0; i < n; i++) {
        ans += cross(v[i], v[i + 1]);
    }
    ans /= 2;
    if (ans < 0) {
        ans = -ans;
    }
    cout << ans;
    return 0;
}
