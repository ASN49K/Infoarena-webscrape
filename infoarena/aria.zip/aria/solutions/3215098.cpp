﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 100006
#define MOD 1999999973
#define INF 2012345678
#define ll long long
using namespace std;
//#define fin cin
//#define fout cout

ifstream fin("aria.in");
ofstream fout("aria.out");

struct Punct{
    long double x, y;
} a[nmax];
int n;

int main()
{
    int i, n;
    long double answer;
    fin >> n;
    for (i = 0; i < n; i++)
        fin >> a[i].x >> a[i].y;

    a[n] = a[0];
    answer = 0;
    for (i = 0; i < n; ++i)
        answer += (a[i].x * a[i + 1].y - a[i + 1].x * a[i].y);
    if (answer < 0)
        answer = -answer;
    fout << setprecision(5) << fixed << answer / 2.0;
	fin.close();
	fout.close();
	return 0;
}