#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

int main()
{
    double n, x, y, bx, by, sx, sy;
    double a=0;
    cin>>n;
    cin>>bx>>by;
    sx=bx;
    sy=by;
    for(int i=2; i<=n; i++)
    {
        cin>>x>>y;
        a+=bx*y-x*by;
        bx=x;
        by=y;
    }
    a+=x*sy-y*sx;
    cout<<abs(a)/2;

    return 0;
}
