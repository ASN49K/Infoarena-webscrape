#include <bits/stdc++.h>
using namespace std;

int main() {
    ifstream cin( "aria.in" );
    ofstream cout( "aria.out" );
    int n , i;
    long long x , y , xc , yc , xf , yf;
    long double ans;
    ans = 0;
    cin >> n >> xc >> yc;
    xf = xc;
    yf = yc;
    for( i = 2 ; i <= n ; i++ ) {
        cin >> x >> y;
        ans += ( xc * y - x * yc );
        xc = x;
        yc = y;
    }
    ans += ( x * yf - xf * y );
    ans = abs( ans );
    ans /= 2;
    cout << setprecision( 5 ) << fixed << ans << '\n';
    return 0;
}
