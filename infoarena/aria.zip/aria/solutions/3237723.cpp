#include<bits/stdc++.h>
using namespace std;
ifstream F("1.in");
ofstream G("1.out");
long double a,b,c,d,e,f,s;
int main()
{
    for(F>>a>>a>>b>>c>>d,s=a*d-b*c;F>>e>>f;s+=c*f-d*e,c=e,d=f);
    return s+=a*d-b*c,G<<fabs(s),0;
}
