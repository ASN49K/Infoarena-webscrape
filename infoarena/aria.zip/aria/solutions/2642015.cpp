#include <bits/stdc++.h>
using namespace std;

ifstream ci("aria.in");
ofstream cou("aria.out");

struct punct
{
	double x,y;
};

int n;
punct v[100005];
void citire()
{
	ci>>n;
	double a=0,b=0,S=0;
	for(int i=1; i<=n; i++)
	{
		ci>>v[i].x>>v[i].y;
	}
	v[n+1]=v[1];
	for(int i=1; i<=n; i++)
	{
		S+= (v[i].x*v[i+1].y - v[i+1].x*v[i].y);
	}
	S=S/2;

	cou<<fixed<<setprecision(10)<<S;
}


int main()
{
	citire();

	return 0;
}
