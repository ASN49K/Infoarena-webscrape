#include <iostream>
#include <fstream>
#include <cmath>

const int NMAX = 1e5;
const double EPS = 1e-5;

class Point {
public:
  double x, y;

  Point() = default;

  Point(double x, double y):
                  x(x), y(y) {};
};

inline double ccw(Point A, Point B) {
  return A.x * B.y - A.y * B.x;
}

Point a[1 + NMAX];

int main() {
  std::ifstream in("aria.in");
  std::ofstream out("aria.out");

  int n;
  in >> n;

  for (int i = 1; i <= n; ++i)
    in >> a[i].x >> a[i].y;

  double area = 0;
  for (int i = 1; i < n; ++i)
    area += ccw(a[i], a[i + 1]);
  area += ccw(a[n], a[1]);

  area = fabs(area / 2);

  out << area << '\n';

  return 0;
}
