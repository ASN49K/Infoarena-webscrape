#include <fstream>
#include <iomanip>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct punct
{
     long double x,y;
};
long double aria(punct a, punct b, punct c )
{
   long double s;
    s= a.x*b.y + b.x*c.y + c.x*a.y - c.x*b.y - b.x*a.y - a.x*c.y;

    s=s/2.0;
    return s;
}
punct a[100001];
int n,i;
int main()
{
   long double s;
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>a[i].x>>a[i].y;
    s=0;
    for(i=2;i<=n-1;i++)
        s=s+aria(a[1] , a[i] , a[i+1]);

    if(s<0)
        s=-s;
    fout<<setprecision(8)<<fixed<<s;

    return 0;
}
