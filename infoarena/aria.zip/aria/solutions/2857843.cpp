#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair<ll, ll>
#define sz(x) (int)((x).size())
#define all(a) (a).begin(), (a).end()

/* int f[maxn],nf[maxn],inv[maxn];
const int M=998244353;
void init(){
    inv[1]=1; for (int i=2;i<maxn;i++) inv[i]=M-1ll*(M/i)*inv[M%i]%M;
    f[0]=nf[0]=1; for (int i=1;i<maxn;i++) f[i]=1ll*f[i-1]*i%M,nf[i]=1ll*nf[i-1]*inv[i]%M;
}
int C(int x,int y){return 1ll*f[x]*nf[y]%M*nf[x-y]%M;}*/
const ll mod = 1e9+7;
ll n, k, m, mi, ma;

void solve(){
	
	ifstream cin("aria.in");
	ofstream cout("aria.out");
	
	cin >> n;
	vector<double> x, y;
	for(int i = 0; i<n; i++){
		double X, Y;
		cin >> X >> Y;
		x.pb(X); y.pb(Y);
	}
	double ans = 0; 
	x.pb(x[0]); y.pb(y[0]);
	for(int i = 0; i<n; i++){
		ans += x[i]*y[i + 1] - y[i]*x[i + 1];
	}
	cout << setprecision(5) << fixed << ans/2.0 << "\n";
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	int t=1;
	//cin >> t;
	while(t--) solve();
	
	return 0;
}

