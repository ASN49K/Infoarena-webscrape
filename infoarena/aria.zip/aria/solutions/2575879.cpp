#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#include <cstring>
#include <deque>
#include <iomanip>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

const int DIM = 1000005;

int n;

double sol=0.0;

struct Coord
{
    double x,y;
}P[DIM];

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>P[i].x>>P[i].y;
    P[n+1]=P[1];
    for(int i=1;i<=n;i++)
        sol+=(P[i].x*P[i+1].y-P[i].y*P[i+1].x);
    sol/=2.0;
    fout<<fixed<<setprecision(7)<<sol<<'\n';
}
