#include <bits/stdc++.h>

using namespace std;
ifstream f("aria.in");
ofstream g("aria.out");

int n,m,nr;
struct nrComplex
{
    float x,y;
    nrComplex operator+(nrComplex A)
    {
        nrComplex B;
        B.x=this->x+A.x;
        B.y=this->y+A.y;
        return B;
    }
    nrComplex operator*(nrComplex A)
    {
        nrComplex B;
        B.x=this->x*A.x-this->y*A.y;
        B.y=this->x*A.y+this->y*A.x;
        return B;
    }
};
nrComplex barat(nrComplex A)
{
    return nrComplex({A.x,-A.y});
}
nrComplex arie;
int main()
{
    //ios_base::sync_with_stdio(0);
    //f.tie(0);
    //g.tie(0);
    int i,j,x,y,z,k;
    nrComplex a,a1,b;
    f>>n;
    f>>b.x>>b.y;
    a1=b;
    for(i=2;i<=n;i++)
    {
        a=b;
        f>>b.x>>b.y;
        arie=arie+barat(a)*b;
    }
    arie=arie+barat(b)*a1;
    arie.x=arie.x/2;
    arie.y=arie.y/2;
    //arie=0.5*Im(barat(a1)*a2+barat(a2)*a3+..+barat(an)*a1)
    g<<arie.y;
    return 0;
}
