#include <bits/stdc++.h>

using namespace std;

ifstream in("aria.in");
ofstream out("aria.out");

const int N = 1e5 + 5;
long double ans = 0;
int n, i;

struct
{
    long double x, y;
} v[N];

main()
{
    in >> n;

    for(int i = 1; i <= n; ++i)
        in >> v[i].x >> v[i].y;

    v[++n] = v[1];

    for(i = 2; i <= n + 1; i++)
        ans += v[i - 1].x * v[i].y - v[i].x * v[i - 1].y;

    if(ans < 0) ans -= 2 * ans;

    ans /= 2;

    out << fixed << setprecision(6) << ans;

    return 0;
}
