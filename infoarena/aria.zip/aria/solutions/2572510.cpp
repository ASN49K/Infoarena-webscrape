#include <bits/stdc++.h>
#define MAX 100100
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct poz{
long double x,y;};
poz v[MAX];
long double aria;
long double determ(poz a,poz b)
{
    return (a.x*b.y)-(b.x*a.y);
}
int n;
int main()
{
    int i;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>v[i].x>>v[i].y;
    }
    v[n+1]=v[1];
    for(i=1;i<=n;i++)
        aria+=determ(v[i],v[i+1]);
    aria/=(2.0);
    cout<<setprecision(6)<<fixed;
    cout<<aria;
    return 0;
}
