#include <bits/stdc++.h>
#define MAX 100100
#define INF 999999999
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct point
{
    long double x,y;
} v[MAX];
long double determ(point a,point b)
{
    return (a.x*b.y-b.x*a.y);
}
int n;
long double sol;
int main()
{
    int i;
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>v[i].x>>v[i].y;
    }
    v[n+1]=v[1];
    for(i=1;i<=n;i++)
        sol+=determ(v[i],v[i+1]);
    sol/=(2.0);
    fout<<setprecision(6)<<fixed;
    fout<<sol;
    return 0;
}
