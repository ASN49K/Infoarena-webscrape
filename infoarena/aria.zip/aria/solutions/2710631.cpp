#include <fstream>
#include <vector>
#include <cmath>
#define per pair<int,int>

using namespace std;

ifstream cin("aria.in");
ofstream cout("aria.out");

int n;
vector <per> v(100005);

void read(){
    cin >> n;

    for(int i = 0; i < n; i++)
        cin >> v[i].first >> v[i].second;
    v[n] = v[0];
}

void solve(){
    double ans = 0;

    for(int i = 0; i < n; i++)
        ans += 1LL * v[i].first * v[i + 1].second - 1LL * v[i + 1].first * v[i].second;

    cout << fabs(ans / 2.0);
}

int main()
{
    read();
    solve();

    return 0;
}
