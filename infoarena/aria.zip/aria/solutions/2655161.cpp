#include<bits/stdc++.h>

using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main()
{
    double x,y,x1,x2,y1,y2,arie;
    long n;
    fin>>n;
    fin>>x>>y;
    fin>>x1>>y1;
    long i;
    for(i=3;i<=n;i++)
    {
        fin>>x2>>y2;
        arie = arie + x*y1 - x1*y + x1*y2 - x2*y1 + x2*y - x*y2;
        x = x1;
        y = y1;
        y1 = y2;
        x1 = x2;
    }
    if(arie < 0)
    {
        arie = -arie;
    }
    fout<<arie/2;
    fin.close();
    fout.close();
    return 0;
}