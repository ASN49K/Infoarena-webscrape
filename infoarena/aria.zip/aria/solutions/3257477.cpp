#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
using namespace std;

struct Point {
    long double x, y;
};

int main() {
    ifstream fin("aria.in");
    ofstream fout("aria.out");

    int n;
    fin >> n;

    Point v[n + 1];
    long double a = 0;

 
    for (int i = 0; i < n; i++) {
        fin >> v[i].x >> v[i].y;
    }

    for (int i = 0; i < n; i++) {
        a += v[i].x * v[(i + 1) % n].y - v[(i + 1) % n].x * v[i].y;   

 }
    a = abs(a) / 2;

    fout << fixed << setprecision(6) << a << "\n";

    return 0;
}

