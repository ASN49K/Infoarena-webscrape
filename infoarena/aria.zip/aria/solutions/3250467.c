#include <stdio.h>
#include <math.h>
#include <stdlib.h>

float lungime(int x1, int y1, int x2, int y2) {
    return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}
float arie(int x1, int y1, int x2, int y2) {
    return (x1 * y2 - x2 * y1) / 2;
}

int main(void) {
    int x1, y1, x2, y2, n, i, a, b;
    float perimetru = 0, aria = 0;
    printf("Introdu numarul de puncte si punctele: \n");
    scanf("%d %d %d", &n, &x1, &y1);
    a = x1;
    b = y1;
    for (i = 0; i < n - 1; i++) {
        scanf("%d %d", &x2, &y2);
        perimetru += lungime(x1, y1, x2, y2);
        aria += arie(x1, y1, x2, y2);
        x1 = x2;
        y1 = y2;
    }
    aria += arie(x2, y2, a, b);
    if (aria == 0) {
        printf("Puncte colinare!\n");
        return 1;
    }
    perimetru += lungime(a, b, x2, y2);
    printf("Perimetrul poligonului este %f!\n", perimetru);
    printf("Aria poligonului este %f!\n", aria);
    return 0;
}