#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <fstream>

using namespace std;

struct Point {
    double x, y;
};

double shoelaceFormula(const vector<Point>& points) {
    int n = points.size();
    double area = 0.0;

    for (int i = 0; i < n; ++i) {
        double x1 = points[i].x;
        double y1 = points[i].y;
        double x2 = points[(i + 1) % n].x;
        double y2 = points[(i + 1) % n].y;

        area += (x1 * y2 - y1 * x2);
    }

    return fabs(area) / 2.0;
}

int main() {
    ifstream infile("aria.in");
    ofstream outfile("aria.out");

    int N;
    infile >> N;

    vector<Point> points(N);
    for (int i = 0; i < N; ++i) {
        infile >> points[i].x >> points[i].y;
    }

    double area = shoelaceFormula(points);

    outfile << fixed << setprecision(5) << area << endl;

    infile.close();
    outfile.close();

    return 0;
}
