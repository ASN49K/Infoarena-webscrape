#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <iomanip>
#include <fstream>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
struct p{
    int x,y;
}Punct[100002];
int n;
double arie;
int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> Punct[i].x >> Punct[i].y;
    }
    Punct[n+1]=Punct[1];
    for(int i=1;i<=n;i++)
    {
        arie+=(Punct[i].x*Punct[i+1].y-Punct[i].y*Punct[i+1].x);
    }
    fout << abs(arie/2.0);
    return 0;
}
