#include <bits/stdc++.h>

using namespace std;

ifstream fin ("aria.in");
ofstream fout ("aria.out");

const int nmax=1e5+5;
pair <int,int> v[nmax];

int det2 (int x1, int y1, int x2, int y2)
{
    return x1*y2-y1*x2;
}

int main()
{
    int n;
    fin >> n;
    for (int i=1; i<=n; i++)
        fin >> v[i].first >> v[i].second;
    v[0]=v[n];
    int rez=0;
    for (int i=1; i<=n; i++)
        rez+=det2(v[i].first,v[i].second,v[i-1].first,v[i-1].second);
    fout << fixed << setprecision(5) << abs(rez)/2.0;
}
