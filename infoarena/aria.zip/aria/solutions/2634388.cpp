#include <bits/stdc++.h>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

typedef pair<int, int> pi;

const int NMAX=1e5;

int N;
pair<int, int> P[NMAX+2];

long long trap(pi a, pi b) {
	long long S=1LL*(a.first+b.first)*(b.second-a.second);
	return S;
}

int main() {
	long long A=0;
	fin>>N;
	for(int i=1;i<=N;++i) {
		fin>>P[i].first>>P[i].second;
	}
	P[N+1]=P[1];
	for(int i=1;i<=N;++i) {
		A+=trap(P[i], P[i+1]);
	}
	A=(A>=0)?A:-A;
	if(A&1)
		fout<<A/2<<".5"<<'\n';
	else
		fout<<A/2<<".0"<<'\n';
	return 0;
}