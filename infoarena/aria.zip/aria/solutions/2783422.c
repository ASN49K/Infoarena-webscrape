#include <stdio.h>
#define NMAX 100005

long double x[NMAX],y[NMAX];

long double arie(int i, int j)///si origine
{
	return (x[i]*y[j]-x[j]*y[i])/2;
}

int main() {
	freopen("aria.in","r",stdin);
	freopen("aria.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%Lf %Lf",&x[i], &y[i]);
	}
	x[n+1]=x[1];
	y[n+1]=y[1];
	long double S=0.0;
	for(int i=1;i<=n;++i)
		S+=arie(i,i+1);
	printf("%.6Lf", S);
    return 0;
}
