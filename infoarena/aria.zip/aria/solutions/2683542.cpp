#include <fstream>
#include <iomanip>

using namespace std;
ifstream fin ("aria.in");
ofstream fout ("aria.out");
int n;
double arie=0;
struct punct
{
    double x;
    double y;
};
punct p[100010];
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>p[i].x>>p[i].y;
    p[n+1]=p[1];
    for(int i=1; i<=n; i++)
        arie+=(p[i].x*p[i+1].y-p[i+1].x*p[i].y);
    //fout<<setprecision(20)<<arie/2;
    fout<<arie/2;
    return 0;
}
