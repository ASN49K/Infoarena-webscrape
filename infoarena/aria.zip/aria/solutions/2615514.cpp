#include <fstream>
#include <iomanip>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");
typedef long double ld;
const int lim=1e5+3;
pair<ld,ld> point[lim];
ld modul(ld &a)
{if(a<0) a=-a;}
int main()
{
    int n;
    ld area=0.;
    cin>>n;
    for(int i=1;i<=n;++i)
        cin>>point[i].first>>point[i].second;
    point[n+1]=point[1];
    for(int i=1;i<=n;++i)
        area+=(point[i].first*point[i+1].second-
               point[i].second*point[i+1].first);
    modul(area);
    cout<<fixed <<setprecision(5)<<area/2<<'\n';
    return 0;
}
