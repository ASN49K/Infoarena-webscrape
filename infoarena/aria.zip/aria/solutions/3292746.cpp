#include <bits/stdc++.h>
#define Mod 1000000007
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

struct Punct
{
    int x, y;

    bool operator < (const Punct e) const
    {
        if (y != e.y) return y < e.y;
        return x < e.x;
    }
};

int n;
Punct a[100005];

long long Aria(Punct A, Punct B)
{
    return 1LL * A.x * B.y - 1LL * A.y * B.x;
}

int main()
{
    long long aria = 0;
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    a[n + 1] = a[1];
    for (int i = 2; i <= n + 1; i++)
    {
        aria += Aria(a[i - 1], a[i]);
    }
    fout << fixed << setprecision(6) << 1.0 * aria / 2 << "\n";
    return 0;
}
