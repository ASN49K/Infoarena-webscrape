#include <bits/stdc++.h>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
int n;
struct Point { double x, y; };
vector<Point> points;

double cross(Point O, Point A, Point B)
{
    return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

double arie()
{
    double A = 0;
    for(int i = 0; i < points.size(); i++)
    {
        Point P = points[i], Q = points[(i + 1) % points.size()];
        A += cross({0, 0}, P, Q) / 2;
    }
    return A;
}

int main()
{
    fin >> n;
    while(n--)
    {
        double x, y;
        fin >> x >> y;
        points.push_back({x, y});
    }
    fout << fixed << setprecision(5) << arie();

    fin.close();
    fout.close();
    return 0;
}
