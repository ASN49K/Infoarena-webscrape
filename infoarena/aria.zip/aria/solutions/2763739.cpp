#include <bits/stdc++.h>
#include <iomanip>

using namespace std;

ifstream f("aria.in");
ofstream g("aria.out");

int main()
{
    int N;
    double x1, y1, x2, y2, x3, y3;
    long double A = 0;
    f >> N >> x1 >> y1;
    x2 = x1;
    y2 = y1;
    while(--N)
    {
        f >> x3 >> y3;
        A += x2 * y3 - x3 * y2;
        x2 = x3;
        y2 = y3;
    }
    A += x2 * y1 - x1 * y2;
    A /= 2;
    g <<  fixed << setprecision(5) << abs(A);
    return 0;
}
