#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

ifstream fin("aria.in");
ofstream fout("aria.out");

int main() {
    int n, x1, y1, x2, y2, aria = 0;
    fin >> n;

    fin >> x1 >> y1;
    int firstX = x1, firstY = y1;

   for (int i = 1; i < n; i++) 
   {
        fin >> x2 >> y2;
        aria += x1 * y2 - y1 * x2;
        x1 = x2;
        y1 = y2;
    }

    aria += x1 * firstY - y1 * firstX;

    fout << fixed << setprecision(5) << aria/2.0 << endl;


    return 0;    
}
