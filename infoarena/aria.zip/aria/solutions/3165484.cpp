/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("aria.in");
ofstream cout("aria.out");

int main()
{
    int n;
    long long total=0,x1,y1,fx,fy;
    cin>>n;
    cin>>x1>>y1;
    fx=x1;
    fy=y1;
    for(int i = 2;i<=n;i++){
        long long x2,y2;
        cin>>x2>>y2;
        total = total + (0.5*(x1*y2-y1*x2));
        x1=x2;
        y1=y2;
    }
    
     total = total + (0.5*(fy*x1-fx*y1));
    cout<<total;
}