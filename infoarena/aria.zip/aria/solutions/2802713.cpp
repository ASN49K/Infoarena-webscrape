#include <fstream>
#include <algorithm>
#include <cmath>
using namespace std;
ifstream fin("aria.in");
ofstream fout("aria.out");
long double n,i,x,y,x2,y2,x3,y3,sum=0;
int main()
{
    fin>>n;
    fin>>x>>y>>x2>>y2>>x3>>y3;
    sum+=abs(x * y2 + y * x3 + x2 * y3- x * y3 - y * x2 - y2 * x3)/2;
    for(i=4;i<=n;i++)
    {
        x2=x3;
        y2=y3;
        fin>>x3>>y3;
        sum+=abs(x * y2 + y * x3 + x2 * y3- x * y3 - y * x2 - y2 * x3)/2;
    }
    fout<<sum;
    return 0;
}
