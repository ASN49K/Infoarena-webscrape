# include <cstdio>
# include <cstdlib>
# include <cmath>
# include <cstring>

# define eps 4
char a[100], b[100];

void result(const char msg[], int p) {
    fprintf(stderr,"%s",msg);
    printf("%d", p);
    exit(0);
}


bool equal(char *a,char *b) {
    int x = strlen (a), y = strlen (b);
    for (int i = x; i - x <= eps; ++i)
        a[i] = '0';
    for (int i = y; i - y <= eps; ++i)
        b[i] = '0';
    for (int i = 0, j = 0; i < x && i < y && j <= eps; ++i) {
        if (a[i] != b[i]) return 0;
        if (a[i] == '.') {
            ++j; continue;
        }
        if (j > 0) j += 1;
    }
    return 1;
}

int main() {
    FILE *f;

    f=fopen("aria.ok","r");
    if(!f)
        result("Fisier ok lipsa!",0);
    if(fscanf(f,"%s", a)!=1)
        result("Fisier ok corupt!",0);
    fclose(f);

    f=fopen("aria.out", "r");
    if(!f)
        result("Fisier de iesire lipsa!",0);
    if(fscanf(f,"%s",b)!=1)
        result("Fisier de iesire corupt!",0);
    fclose(f);

    if(equal(a,b)==1)
        result("Bravos !",10);
    else
        result("Mai incearca !",0);
    return 0;
}

