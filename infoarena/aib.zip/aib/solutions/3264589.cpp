#include <bits/stdc++.h>
#define nmax 100005
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,m,type;
int aib[nmax];
void update(int poz,int val)
{
    for(int i=poz; i<=n; i+=(i&-i))
        aib[i]+=val;
}
int query(int poz)
{
    long long sum=0;
    for(int i=poz; i>=1; i-=(i&-i))
        sum+=aib[i];
    return sum;
}
int cb(int sk)
{
    int st=1,dr=n;
    while(st<=dr)
    {
        int mid=(st+dr)/2;
        int smid=query(mid);
        if(smid==sk)
            return mid;
        else if(smid<sk)
            st=mid+1;
        else
            dr=mid-1;
    }
    return -1;
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        int x;
        fin>>x;
        update(i,x);
    }
    while(m--)
    {
        fin>>type;
        if(type==0)
        {
            int x,y;
            fin>>x>>y;
            update(x,y);
        }
        else if(type==1)
        {
            int x,y;
            fin>>x>>y;
            fout<<query(y)-query(x-1)<<'\n';
        }
        else
        {
            int x;
            fin>>x;
            fout<<cb(x)<<'\n';
        }
    }
    return 0;
}
