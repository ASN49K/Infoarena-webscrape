#include <fstream>
#include <vector>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
vector<int>v(100010);
long long int suma, pmin;
int n, m, a,b,op;



void qp(int xx )
{
    bool gasit=false;
    for(int p=1;gasit==false;p++)
    {
        suma = 0;
         for (int i = p; i > 0; i-=(i&-i))
            suma += v[i];
        if(suma==xx)
            gasit=true, pmin=p;
    }

}



void  query(int x , int y)
{
	suma = 0;
	for (int i = y; i >= x; i -= (i & -i))
		suma += v[i];
}
void update(int p, int x)
{
	for (int i = p; i <= n; i += (i & -i))
		v[i] += x;
}
int main()
{
	fin >> n >> m;

	for (int i = 0; i <= n; i++) v.push_back(0);

	for (int i = 1; i <= n; i++)
	{
		fin >> a;
		update(i, a);
	}
	for (int i = 1; i <= m; i++)
	{
		fin >> op;
		if (op == 0)
		{
			fin >>  a >> b;
			update(a, b);
		}
		if (op == 1)
		{
			fin >> a >> b;
			query(a,b);
			fout << suma << endl;
		}
		if (op == 2)
        {   fin >> a;
         qp(a);
          fout << pmin<<endl;
        }
	}
}