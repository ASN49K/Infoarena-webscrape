#include<bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

#define LEN 131072

long long aib[LEN + 1];

void update(long long poz, long long x) {
    long long p = 1;
    while(poz <= LEN) {
        if(p & poz) {
            aib[poz] += x;
            poz = poz + p;
        }
        p = p * 2;
    }
}

long long get_sum(long long poz) {
    long long p = 1;
    long long sum = 0;
    while(poz > 0) {
        if(p & poz) {
            sum = sum + aib[poz];
            poz = poz - p;
        }
        p = p * 2;
    }
    return sum;
}

long long get_poz(long long k, long long lvector) {
    if(k > aib[LEN]) {
        return -1;
    }
    long long poz = 0;
    long long sum = 0;
    for(long long p = LEN; p >= 1; p = p / 2) {
        if(aib[poz + p] + sum <= k) {
            poz = poz + p;
            sum = sum + aib[poz];
        }
        if(sum == k) {
            if(poz == 0)
                poz = -1;
            return min(poz, lvector);
        }
    }
    if(poz == 0)
        poz = -1;
    if(sum != k) {
        return -1;
    } else {
        return min(poz, lvector);
    }
}

int main() {
    long long n, q;
    fin >> n >> q;
    for(long long i = 1; i <= n; i++) {
        long long x;
        fin >> x;
        update(i, x);
    }
    for(long long i = 1; i <= q; i++) {
        long long op;
        fin >> op;
        if(op == 0) {
            long long a, b;
            fin >> a >> b;
            update(a, b);
        } else if(op == 1) {
            long long a, b;
            fin >> a >> b;
            fout << get_sum(b) - get_sum(a - 1) << "\n";
        } else {
            long long k;
            fin >> k;
            fout << get_poz(k, n) << "\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}