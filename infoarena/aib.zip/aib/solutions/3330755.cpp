#include <bits/stdc++.h>

int v[100005];
int n, m;

void update(int nod, int val)
{
     for(; nod <= n; nod += (nod & -nod))
        v[nod] += val;
}

long long query(int nod)
{
    long long sum = 0;
    for(; nod > 0; nod -= (nod & -nod))
        sum += v[nod];
    return sum;
}

int main() {

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);

    std::cin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        int a;
        std::cin >> a;
        update(i, a);
    }

    for(int i = 1; i <= m; i++)
    {
        int op, a, b, k;
        std::cin >> op;
        if(op == 0)
        {
            std::cin >> a >> b;
            update(a, b);
        }
        else if(op == 1)
        {
            std::cin >> a >> b;
            std::cout << query(b) - query(a - 1) << '\n';
        }
        else
        {
            std::cin >> k;
            int ans = -1, st = 1, dr = n;
            while(st <= dr)
            {
                int mij = (st + dr) / 2;
                int sum_mij = query(mij);
                if(sum_mij == k){
                    ans = mij;
                    break;
                }
                else if(sum_mij > k)
                    dr = mij - 1;
                else
                    st = mij + 1;
            }
            std::cout << ans << '\n';
        }
    }

    return 0;
}
