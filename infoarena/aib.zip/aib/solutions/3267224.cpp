#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
using ll = long long;
int aib[100005];
int n,m,op,x,a,b;

void update(int i,int x) {
        for (int crt = i;crt<=n;crt+=(crt&-crt)) {
                aib[crt]+=x;
        }
}

int query(int i) {
        int s = 0;
        for (int j = i;j>=1;j-=j&(-j)) {
                s+=aib[j];
        }
        return s;
}

void create() {
        for (int i = 1;i<=n;++i) {
                fin>>x;
                update(i,x);
        }
}

int main() {
        fin>>n>>m;
        create();
        for (int i = 1;i<=m;++i) {
                fin>>op;
                if (op==0) {
                        fin>>a>>b;
                        update(a,b);
                } else if (op==1) {
                        fin>>a>>b;
                        fout<<query(b)-query(a-1)<<'\n';
                } else if (op==2) {
                        fin>>a;
                        int l = 1,r = n,rez;
                        while(l<r) {
                                int mid = (l+r)/2;
                                int sum = query(mid);
                                if (sum>=a) {
                                        r = mid;
                                } else {
                                        l = mid+1;
                                }
                        }
                        rez = l;
                        if (query(rez)==a) {
                                fout<<rez<<'\n';
                        }  else
                                fout<<-1<<'\n';
                }
        }
        return 0;
}
