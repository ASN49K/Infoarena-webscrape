#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int NMAX = 1e5+5;
int aib[NMAX], n;

void update(int pos, int val) {
    for (int i = pos; i <= n; i += i&(-i))
        aib[i] += val;
}

int sum(int pos) {
    int res = 0;
    for (int i = pos; i > 0; i -= i&(-i))
        res += aib[i];
    return res;
}

int query(int a) {
    int res = 0, s = 0;
    for (int bit = 17; bit >= 0; bit--) {
        if (res + (1 << bit) <= n && s + aib[res + (1 << bit)] < a) {
            s += aib[res + (1 << bit)];
            res += (1 << bit);
        }
    }

    res++;
    if (res > n || sum(res) != a)
        return -1;

    return res;
}

int main() {

    int q;
    fin >> n >> q;
    for (int i = 1; i <= n; i++) {
        int x;
        fin >> x;
        update(i, x);
    }

    while (q--) {
        int c;
        fin >> c;

        if (c == 0) {
            int a, b;
            fin >> a >> b;

            update(a, b);
        } else if (c == 1) {
            int a, b;
            fin >> a >> b;

            fout << (sum(b) - sum(a - 1)) << '\n';
        } else {
            int a;
            fin >> a;

            fout << query(a) << '\n';
        }
    }

    return 0;
}
