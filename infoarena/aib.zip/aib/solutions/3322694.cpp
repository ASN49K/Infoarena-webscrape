#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

long long n, q;
long long d[100005], bit[100005];

void update(long long k, long long u)
{
    while(k<=n)
    {
        bit[k]+=u;
        k+=(k&-k);
    }
}

long long prefixsum(long long k)
{
    long long sum=0;
    while(k>0)
    {
        sum+=bit[k];
        k-=(k&-k);
    }
    return sum;
}

long long range(long long a, long long b)
{
    return prefixsum(b)-prefixsum(a-1);
}

int main()
{
    fin>>n>>q;
    for(int i = 1;i <= n; ++i)
    {
        fin>>d[i];
        update(i, d[i]);
    }
    for(int i = 1; i <=q ; ++i)
    {
        int c;
        fin>>c;
        if(c==0)
        {
            int a, b;
            fin>>a>>b;
            update(a, b);
        }
        else if(c==1)
        {
            int a, b;
            fin>>a>>b;
            fout<<range(a,b)<<'\n';
        }
        else
        {
            int a;
            int k=-2e9;
            fin>>a;
            int st=1, dr=n;
            while(st<=dr)
            {
                int mij=st+dr;
                mij/=2;
                int s=range(1, mij);
                if(s==a){k=mij; break;}
                else if(s<a)st=mij+1;
                else dr=mij-1;
            }
            if(k==-2e9)fout<<-1<<'\n';
            else fout<<k<<'\n';
        }
    }
}
