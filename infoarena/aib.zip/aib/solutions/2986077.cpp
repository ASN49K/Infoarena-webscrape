#include <fstream>
#include <cmath>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m, bit[100005];

int get_bit(int x)
{
    return (x & (-x));
}

void update(int poz, int val)
{
    for (; poz <= n; poz += get_bit(poz))
        bit[poz] += val;
}

int query(int poz)
{
    int sum = 0;
    for (; poz > 0; poz -= get_bit(poz))
        sum += bit[poz];
    return sum;
}

int get_k(int val)
{
    int poz_curent = 0, sum = 0;
    for (int exp = log2(n); exp >= 0; exp--)
    {
        int poz_potential = poz_curent + (1 << exp);
        if (poz_potential <= n && bit[poz_potential] < val - sum)
        {
            poz_curent = poz_potential;
            sum += bit[poz_curent];
        }
    }
    poz_curent++;
    if (sum != val || poz_curent == 0)
        return -1;
    return poz_curent;
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        update(i, x);
    }
    for (int i = 0; i < m; i++)
    {
        int op, a, b;
        fin >> op;
        if (op == 0)
        {
            fin >> a >> b;
            update(a, b);
        }
        else if (op == 1)
        {
            fin >> a >> b;
            fout << query(b) - query(a - 1) << "\n";
        }
        else
        {
            fin >> a;
            fout << get_k(a) << "\n";
        }
    }
    return 0;
}