#include <iostream>
#include <cmath>
#define lsb(x)  (x & -x)
using namespace std;
const int Nmax = 2e5 + 5;
int aib[Nmax];
int sum(int i, int aib[]) {
	int sum = 0;
	while (i > 0) {
		sum += aib[i];
		i -= lsb(i);
	}
	return sum;
}

void add(int i, int val, int aib[], int n) {
	while (i <= n) {
		aib[i] += val;
		i += lsb(i);
	}
}

int find(int a, int aib[], int n) {
	int curr = 0;
	int prevsum = 0;
	for (int i = log2(n); i >= 0; --i) {
		if (aib[curr + (1 << i)] + prevsum < a) {
			curr = curr + (1 << i);
			prevsum += aib[curr];
		}
	}
	if (sum(curr + 1, aib) != a) {
		return -1;
	}
	else {
		return curr + 1;
	}

}


int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("aib.in", "r", stdin);
	freopen("aib.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) {
		int a;
		cin >> a;
		add(i, a, aib, n);

	}
	for (int i = 1; i <= m; ++i) {
		int query;
		cin >> query;
		if (query == 0) {
			int pos, val;
			cin >> pos >> val;
			add(pos, val, aib, n);
		}
		else if (query == 1) {
			int a, b;
			cin >> a >> b;
			cout << sum(b, aib) - sum(a-1,aib)<<"\n";
		}
		else if (query == 2) {
			int a;
			cin >> a;
			cout << find(a, aib, n)<<"\n";
		}
	}

	return 0;
}