#include <fstream>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,t,aib[100001],x,q,a,b;
void update(int poz,int val){
    for(int i=poz;i<=n;i+=i&-i){
            aib[i]+=val;
    }
}
int query(int poz){
    int sum=0;
    for(int i=poz;i>=1;i-=i&-i){
        sum+=aib[i];
    }
    return sum;
}
int main()
{
    fin>>n>>t;
    for(int i=1;i<=n;i++){
        fin>>x;
        update(i,x);
    }

    for(int i=1;i<=t;i++){
        fin>>q;
        if(q==0){
            fin>>a>>b;
            update(a,b);
        }else if(q==1){
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<"\n";
        }else{
            fin>>a;
            int st=1,dr=n, poz=-1;
            while(st<=dr){
                int mid=(st+dr)/2;
                int s=query(mid);
                if(s==a){
                    poz=mid;
                    dr=mid-1;
                }
                else
                    if(s>a)
                       dr=mid-1;
                   else
                      st=mid+1;
            }
           fout<<poz<<"\n";
        }

    }
    return 0;
}
