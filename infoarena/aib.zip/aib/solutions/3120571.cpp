#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int AIB[100005], N, M;

void Update(int P, int quantity)
{
	for (int i = P; i <= N; i += (i & (- i)))
		AIB[i] += quantity;
}
long long Query(int P)
{
	long long SUM = false;
	for (int i = P; i > 0; i -= (i & (- i)))
		SUM += AIB[i];
	return SUM;
}
void Task()
{
	fin >> N >> M;
	for (int i = 1; i <= N; ++i)
	{
		int X;
		fin >> X;
		Update(i, X);
	}
	for(int i = 1; i <= M; ++ i)
	{
		int C;
		fin >> C;
		int A, B;
		if (C == 0)
		{
			fin >> A >> B;
			Update(A, B);
		}
		else if (C == 1)
		{
			fin >> A >> B;
			fout << Query(B) - Query(A - 1) << '\n';
		}
		else
		{
			fin >> A;
			int left = 1, right = N;
			int ans = -1;
			while (left <= right)
			{
				int mid = (left + right) / 2;
				long long S = Query(mid);
				if (S == A)
				{
					ans = mid;
					right = mid - 1;
				}
				else if (S > A)
					right = mid - 1;
				else
					left = mid + 1;
			}
			fout << ans << '\n';
		}
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
	Task();
	return 0;
}
