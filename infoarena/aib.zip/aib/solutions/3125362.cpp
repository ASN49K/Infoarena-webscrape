#include <bits/stdc++.h>
#define int long long
#define cout fout

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m;
int bit[100005];

void update(int i, int val)
{
    while(i <= n)
    {
        bit[i]+=val;
        i+=(i&-i);
    }
}

int sum(int i)
{
    int sum=0;
    while(i > 0)
    {
        sum+=bit[i];
        i-=(i&-i);
    }
    return sum;
}

int32_t main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        int a;
        fin>>a;
        update(i, a);
    }
    for(int i=1; i<=m; i++)
    {
        int op, a, b;
        fin>>op>>a;
        if(a > b)
            swap(a, b);
        if(op < 2)
        {
            fin>>b;
        }
        if(op == 0)
        {
            update(a, b);
        }
        else if(op == 1)
        {
            cout<<sum(b)-sum(a-1);
        }
        else
        {
            int st=1, dr=n;
            int ans=-1;
            while(st <= dr)
            {
                int mid=(st+dr)/2;
                int val=sum(mid);
                if(val >= a)
                {
                    dr=mid-1;
                    if(val == a && (ans > mid || ans == -1))
                        ans=mid;
                }
                else
                {
                    st=mid+1;
                }
            }
            cout<<ans;
        }
        cout<<'\n';
    }
    return 0;
}
