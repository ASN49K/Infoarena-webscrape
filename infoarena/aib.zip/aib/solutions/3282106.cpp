#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ifstream f ("aib.in");
ofstream g ("aib.out");

const int NMAX = 100000,
          SQMAX = 1000;
int N, M, nrB, BLOCK_SIZE, V[NMAX+1], SB[NMAX+1];

void citire() {
    f >> N >> M;
    for (int i=0; i<N; i++)
        f >> V[i];
}

void construire() {
    nrB = -1;
    //
    BLOCK_SIZE = (int) sqrt(N);
    //
    for (int i=0; i<N; i++) {
        if (i % BLOCK_SIZE == 0)
            nrB++;
        SB[nrB] += V[i];
    }
}

void update(int poz, int val) {
    int blockNumber = poz / BLOCK_SIZE;
    SB[blockNumber] += val;
    V[poz] += val;
}

int querry1(int st, int dr) {
    int sum = 0;
    //
    while(st <= dr && st % BLOCK_SIZE != 0)
        sum += V[st++];
    //
    while(st + BLOCK_SIZE - 1 <= dr) {
        sum += SB[st/BLOCK_SIZE];
        st += BLOCK_SIZE;
    }
    //
    while(st <= dr)
        sum += V[st++];
    //
    return sum;
}

int querry2(int targetSum) {
    int sum = 0, blockNumber = 0, poz;
    //
    while (sum + SB[blockNumber] <= targetSum && blockNumber <= nrB)
        sum += SB[blockNumber++];
    //
    poz = blockNumber * BLOCK_SIZE;
    //
    while (sum + V[poz] <= targetSum && poz < N)
        sum += V[poz++];
    //
    return poz;
}

int main()
{
    citire();
    construire();
    int op, a, b;
    for (int i=1; i<=M; i++) {
        f >> op;
        switch(op) {
            case 0:
                f >> a >> b;
                update(a-1, b);
                break;
            case 1:
                f >> a >> b;
                g << querry1(a-1, b-1) << '\n';
                break;
            case 2:
                f >> a;
                g << querry2(a) << '\n';
                break;
        }
    }
    f.close();
    g.close();
    return 0;
}
