#include <fstream>
#include <vector>
using namespace std;

ifstream cin ("aib.in");
ofstream cout ("aib.out");

int n,m;
int v[100005];
vector<int> aib(100005,0);

void update (int poz,int val) {
    while (poz<=n) {
        aib[poz]+=val;
        poz+=poz & (-poz);
    }
}

int query(int poz) {
    int sum=0;
    while (poz>0) {
        sum+=aib[poz];
        poz-=poz & (-poz);
    }
    return sum;
}

int main() {
    int tip,a,b;
    cin>>n>>m;
    for (int i=0; i<n; i++) {
        cin>>v[i];
        update(i+1,v[i]);
    }
    for (int i=1; i<=m; i++) {
        cin>>tip>>a;
        if (tip==0) {
            cin>>b;
            update(a,b);
        }
        else if (tip==1) {
            cin>>b;
            cout<<query(b)-query(a-1)<<'\n';
        }
        else {
            int l=1,r=n;
            while (l<=r) {
                int mid=(l+r)/2;
                if (query(mid)>=a) {
                    r=mid-1;
                }
                else l=mid+1;
            }
            if (query(l)==a) cout<<l<<'\n';
            else cout<<-1<<'\n';
        }
    }
}