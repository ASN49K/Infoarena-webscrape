#include<bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout("aib.out");
int n,m,put=1,ex=0,aib[100002];

void update (int poz,int val)
{
    for (int i=poz;i<=n;i+=(i&-i))
        aib[i]+=val;
}

int query (int poz)
{
    int sol=0;
    for (int i=poz;i>0;i-=(i&-i))
        sol+=aib[i];
    return sol;
}

int cb_patrascu (int x)
{
    int sum=0,poz=0;
    for (int i=ex;i>=0;i--)
        if (poz+(1<<i)<= n && sum+aib[poz+(1<<i)]<=x)
    {
        poz+=(1<<i);
        sum+=aib[poz];
    }
    if (poz==0)
        return -1;
    return poz;
}

int main ()
{
    int op,x,y;
    fin>>n>>m;
    for (int i=1;i<=n;i++)
    {
        fin>>x;
        update(i,x);
    }

    while (put<=n)
    {
        put*=2;
        ex++;
    }
    put/=2,ex--;

    while (m--)
    {
        fin>>op>>x;
        if (op==2)
            fout<<cb_patrascu(x)<<'\n';
        else{
        fin>>y;
        if (op==0)
            update(x,y);
        else if (op==1)
            fout<<query(y)-query(x-1)<<'\n';
        }
    }
}
