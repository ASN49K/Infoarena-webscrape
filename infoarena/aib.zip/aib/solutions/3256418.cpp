#include <iostream>
#include <fstream>
using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
int aib[100005],x,a,b,q,n,m,i;
void adun(int x,int val)
{int i;
for(i=x;i<=n;i+=i&(-i))
    aib[i]+=val;
}
int suma(int x)
{int i,sum=0;
for(i=x;i>=1;i-=i&(-i))
    sum+=aib[i];
return sum;
}
int main()
{f>>n>>m;
for(i=1;i<=n;i++)
    {f>>x;
    adun(i,x);
    }
for(i=1;i<=m;i++)
    {f>>q;
    if(q==0)
        {f>>a>>b;
        adun(a,b);
        }
    else if(q==1)
        {f>>a>>b;
        g<<suma(b)-suma(a-1)<<'\n';
        }
    else {f>>a;
    int p=1,u=n,mij,ok=0;
    while(p<=u && !ok)
    {mij=(p+u)/2;
    if(suma(mij)<a)p=mij+1;
    else if(suma(mij)>a)u=mij-1;
    else ok=1;
    }
    if(ok)g<<mij<<'\n';
    else g<<-1<<'\n';
    }
    }
    
return 0;
}