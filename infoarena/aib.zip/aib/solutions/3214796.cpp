#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int N, M;
int aib[100005];
int v[100005];
int c, a, b;
int Query(int V)
{
    int Sum = 0;
    for (int i = V; i >= 0; i = i - (i & (-i)))
    {
        if (i == 0)
            break;
        Sum += aib[i];
    }
    return Sum;
}
void Update(int P, int V)
{
    for (int i = P; i <= N; i += (i & (-i)))
        aib[i] += V;
}
int suma(int a, int b)
{
    int sum2 = Query(b), sum1 = Query(a - 1);
    return sum2 - sum1;
}
int main()
{

    fin >> N;
    fin >> M;
    for (int i = 1; i <= N; i++)
    {
        fin >> v[i];
        Update(i, v[i]);
    }
    // for (int i = 1; i <= N; i++)
    // {
    //     cout << aib[i] << ' ';
    // }
    for (int i = 1; i <= M; i++)
    {
        fin >> c;
        // cout << '\n'
        //      << "c:" << c << '\n';
        if (c == 0)
        {
            fin >> a >> b;
            Update(a, b);
            // cout << '\n';
            // for (int u = 1; u <= N; u++)
            //     cout << aib[u] << ' ';
            // cout << '\n';
        }
        if (c == 1)
        {
            fin >> a >> b;
            fout << suma(a, b)<<'\n';
        }
        if (c == 2)
        {
            fin >> a;
            int st = 1, dr = N, mid, s;
            while (st <= dr)
            {
                mid = (st + dr) / 2;
                s = suma(1, mid);
              //  cout << mid <<' ' <<s << '\n';
                if (s == a)
                    break;
                if (s <= a)
                    st = mid + 1;
                else
                    dr = mid - 1;
            }
            if (s == a)
                fout << mid<<'\n';
            else
                fout << "-1\n";
        }
    }
}