#include <fstream>
#include <vector>
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n, m, lg;
vector<int> aib, v;
void update(int poz, int val){
    for(int i=poz; i<=n; i+=(i & (-i)))
        aib[i] += val;
}
int query1(int x){
    int sum=0;
    for(int i=x; i>0; i-=(i & (-i)))
        sum += aib[i];
    
    return sum;
}
int query2(int a){
    int l=1, r=n, k=-1;

    while(l <= r){
        const int mid = (l + r) / 2;
        const int sum = query1(mid);
        if(sum > a)
            r = mid - 1;
        
        else if(sum == a)
            k = mid, r = mid - 1;
        
        else l = mid + 1;
    }

    return k;
}
int main(){
    cin>>n>>m;
    aib.resize(n+5);
    v.resize(n+5);

    int b = 1;
    while(b <= n){
        b *= 2;
        lg++;
    }
    lg--;

    for(int i=1; i<=n; i++){
        cin>>v[i];
        update(i, v[i]);
    }

    while(m--){
        int tip;
        cin>>tip;
        if(tip < 2){
            int x, y;
            cin>>x>>y;
            if(!tip)
                update(x, y);
            
            else cout<<query1(y) - query1(x-1)<<'\n';
            continue;
        }

        int a;
        cin>>a;
        cout<<query2(a)<<'\n';

    }
    return 0;
}