#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
// #include <bits/stdc++.h>
#define in fin
#define out fout

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int aib[100001];

void update(int p, int val){
    while(p <= 100000){
        aib[p] += val;
        p += (p & -p);
    }
}

int query(int p){
    int s = 0;
    while(p){
        s += aib[p];
        p -= (p & -p);
    }
    return s;
}

signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, q; in >> n >> q;
    int v[n + 1];
    for(int i = 1; i <= n; i++){
        in >> v[i];
        update(i, v[i]);
    }

    for(int i = 0; i < q; i++){
        int op; in >> op;
        if(op == 0){
            int a, b; in >> a >> b;
            update(a, b);
        }else if(op == 1){
            int a, b; in >> a >> b;
            out << query(b) - query(a - 1) << '\n';
        }else if(op == 2){
            int a; in >> a;
            int l = 0, r = n;
            int p = (1 << ((int)log2(n)));
            int sol = -1;
            while(l < r){
                // cout << "l = " << l << "r = " << r << " p = " << p << '\n';
                while(l + p > n) p /= 2;
                if( l + p <= n && aib[l] + aib[l + p] < a ){
                    l += p;
                }else{
                    if(aib[l] + aib[l + p] == a) sol = l + p;
                    r = l + p - 1;
                }
                p /= 2;
            }

            out << sol << '\n';
        }
    }

    return 0;
}