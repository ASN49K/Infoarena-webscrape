#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,m,a,b,val,st,mij,poz,dr,c,aib[15005],s[15005];
void adun(int x, int val)
{
    int i;
    for(i=x;i<=n;i+=i&(-i))
        aib[i]+=val;
}
int sum(int x)
{
    int i;
    int s=0;
    for(i=x;i>=1;i-=i&(-i))
        s+=aib[i];
    return s;
}
int main()
{
    int i;
    cin>>n>>m;
    for(i=1;i<=n;i++)
    {
        cin>>val;
        adun(i,val);
    }
    for(i=1;i<=m;i++)
    {
        cin>>c;
        if(c==0) {cin>>a>>b; adun(a,b);}
        if(c==1) {cin>>a>>b; cout<<sum(b)-sum(a-1)<<'\n';}
        if(c==2)
        {
            cin>>a;
            st=1;
            dr=n;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(a>=sum(mij))
                {
                    st=mij+1;
                    poz=mij;
                }
                else dr=mij-1;
            }
            cout<<poz<<'\n';
        }
    }
    return 0;
}
