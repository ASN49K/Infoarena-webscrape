#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e5+2;
int n,m,t,a,b,aib[NMAX];

ifstream fin("aib.in");
ofstream fout("aib.out");

int query(int pos){
    int ans = 0;
    for(int i = pos; i > 0; i -= (i&-i)){
        ans += aib[i];
    }
    return ans;
}

void update(int pos, int val){
    for(int i = pos; i <= n; i += (i&-i)){
        aib[i] += val;
    }
}

int range(int st, int dr){
    return query(dr)-query(st-1);
}

int kth(int k){
    int ans = -1;
    int st = 1, dr = n;
    while(st <= dr){
        int mid = (st+dr)/2;
        if(query(mid) == k){
            return mid;
        }
        if(query(mid) > k){
            dr = mid-1;
        }else{
            st = mid+1;
        }
    }
    return ans;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= n; i++){
        int x;
        fin >> x;
        update(i, x);
    }
    while(m--){
        fin >> t;
        if(t == 0){
            fin >> a >> b;
            update(a, b);
        }else if(t == 1){
            fin >> a >> b;
            fout << range(a, b) << "\n";
        }else{
            fin >> a;
            fout << kth(a) << "\n";
        }
    }
    return 0;
}
