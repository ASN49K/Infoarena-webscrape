#include <fstream>

using namespace std;

ifstream cin ("aib.in");
ofstream cout ("aib.out");

int n , a;

int  bit[100005];



void update(int j, int oj){

    while(j <= n){

        bit[j]+=oj;

        j+= j & -j ;

    }

}



int calcul(int h){

    int sum=0;

    while(h > 0){

        sum+=bit[h];

        h-=h & -h;

    }

    return sum;

}

int alupigus (int gyat , int gyatt){
    return calcul(gyatt) - calcul(gyat - 1);



}



int main()

{
    int cezaraalupigus=0;
    cin >> n >> cezaraalupigus;

    for(int i=0;i < n;i++){

        cin >>a ;



        update(i + 1, a);



    }
    for(int i=0;i  < cezaraalupigus;i++){
        int j, a ,b=1;
        cin >> j;
        if(j==0) // cezaraalupigus
        {
            cin >> a >> b;
            update(a , b);
            continue;
        }else if(j==1){
            cin >> a >> b;
            cout << alupigus(a , b) ;
        }else{
            cin >> a;
            while(alupigus(1, b) < a)b++;
            cout << b ;
        }
        if(i != cezaraalupigus)cout << "\n";
    }

    return 0;

}