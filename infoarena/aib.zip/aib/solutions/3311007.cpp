#include <fstream>
#include <algorithm>
#include <iomanip>
#include <numeric>
#include <bitset>
#include <string>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#define int long long
#define f first
#define s second
using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int n, m, v[100005], s[100005], c, a, b;

void update(int p, int val){
    while (p <= n){
        s[p] += val;
        p += p & (-p);
    }
}

int query(int p){
    int sum = 0;
    while (p != 0){
        sum += s[p];
        p -= p & (-p);
    }
    return sum;
}

int cb(int k){
    int st = 0, dr = n;
    while (st <= dr){
        int x = query((st + dr) / 2);
        if (x == k){
            return (st + dr) / 2;
        }
        if (x > k){
            dr = (st + dr) / 2 - 1;
        }
        else{
            st = (st + dr) / 2 + 1;
        }
    }
    return -1;
}

signed main(){
    cin>>n>>m;
    for (int i = 1; i <= n; i++){
        cin>>v[i];
        update(i, v[i]);
    }
    for (int i = 1; i <= m; i++){
        cin>>c;
        if (c == 0){
            cin>>a>>b;
            update(a, b);
        }
        if (c == 1){
            cin>>a>>b;
            cout<<query(b) - query(a - 1)<<"\n";
        }
        if (c == 2){
            cin>>a;
            cout<<cb(a)<<"\n";
        }
    }
}
