#include<bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int v[100001], n, m, c, a, b, i, j, st, dr, mij;
long long int suma, s[100001];
int main()
{
    fin>>n>>m;
    for(i=1; i<=n; i++){fin>>v[i]; s[i]=s[i-1]+v[i];}
    for(i=1; i<=m; i++){
        fin>>c;
        if(c==0){
            fin>>a>>b;
            v[a]+=b;
            for(j=a; j<=n; j++)s[j]=s[j-1]+v[j];
        }
        else if(c==1){
            fin>>a>>b;
            fout<<s[b]-s[a-1]<<endl;
        }
        else{
            fin>>a;
            st=1;
            dr=n;
            if(s[st]==a)fout<<st<<endl;
            else if(s[dr]==a)fout<<dr<<endl;
            else{
            while(st<=dr){
                mij=(st+dr)/2;
                if(s[mij]==a){fout<<mij<<endl; break;}
                else if(v[mij]<a){st=mij+1;}
                else {dr=mij-1;}
            }
        }}
    }
}
