#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class FenwickTree {
    vector<long long> BIT;
    int size;

public:
    FenwickTree(int n) : size(n) {
        BIT.resize(n + 1, 0);
    }

    void update(int index, int val) {
        while (index <= size) {
            BIT[index] += val;
            index += index & -index;
        }
    }

    long long query(int index) {
        long long sum = 0;
        while (index > 0) {
            sum += BIT[index];
            index -= index & -index;
        }
        return sum;
    }

    long long rangeQuery(int left, int right) {
        return query(right) - query(left - 1);
    }
};

int main() {
    ifstream infile("aib.in");
    ofstream outfile("aib.out");

    int N, M;
    infile >> N >> M;

    vector<int> A(N + 1);
    FenwickTree fenwickTree(N);

    for (int i = 1; i <= N; ++i) {
        infile >> A[i];
        fenwickTree.update(i, A[i]);
    }

    for (int i = 0; i < M; ++i) {
        int type;
        infile >> type;

        if (type == 0) {
            int a, b;
            infile >> a >> b;
            fenwickTree.update(a, b);
        } else if (type == 1) {
            int a, b;
            infile >> a >> b;
            outfile << fenwickTree.rangeQuery(a, b) << "\n";
        } else if (type == 2) {
            int k;
            infile >> k;
            int currentSum = 0, pos = -1;
            for (int j = 1; j <= N; ++j) {
                currentSum += A[j];
                if (currentSum >= k) {
                    pos = j;
                    break;
                }
            }
            outfile << pos << "\n";
        }
    }

    infile.close();
    outfile.close();

    return 0;
}
