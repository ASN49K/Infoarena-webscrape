/*
    "TLE is like the wind, always by my side"
    - Yasuo - 2022 -
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")

using namespace std;

int aib[100001];
int sp[100001];
int n,m,i,j,type,x,pos,b,a,k,r,pas;

void update(int index, int delta)
{
    while (index<=n)
    {
        aib[index]+=delta;
        index+=index&(-index);
    }
}

int query(int index)
{
    int ans;
    ans=sp[index];
    while (index>0)
    {
         ans+=aib[index];
         index-=index&(-index);
    }
    return ans;
}

int main()
{
    ifstream fin("aib.in");
    ofstream fout("aib.out");
    fin >> n >> m;
    for (i=1;i<=n;i++)
    {
         fin >> x;
         sp[i]=sp[i-1]+x;
    }
    for (i=1;i<=m;i++)
    {
         fin >> type;
         if (type==0)
         {
             fin >> pos >> b;
             update(pos,b);
         }
         if (type==1)
         {
             fin >> a >> b;
             fout << query(b)-query(a-1) << "\n";
         }
         if (type==2)
         {
             fin >> k;
             pas=(1<<16);
             r=0;
             while (pas)
             {
                 if (r+pas<=n && query(r+pas)<k)
                     r+=pas;
                 pas=pas/2;
             }
             if (query(r+1)==k)
                 fout << r+1 << "\n";
             else
                 fout << -1 << "\n";
         }
    }
}
