#include <bits/stdc++.h>
#define RI_MAX (1 << 17)
#define L RI_MAX + 5
#define lsb(x) (x & (-x))
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int v[L], aib[L], n;

inline void update(int pos, int val){
  for (; pos <= n; pos += lsb(pos))
    aib[pos] += val;
}

inline int query(int pos){
  int ret = 0;
  for (; pos; pos -= lsb(pos))
    ret += aib[pos];
  return ret;
}

inline int cb(int sum){
  int r = 0, step = RI_MAX, s = 0;
  while (step){
    if (r + step <= n && s + aib[r + step] <= sum){
      s += aib[r + step];
      r += step;
    }
    step /= 2;
  }
  if (s != sum || r == 0)
    r = -1;
  return r;
}

int main(){
  int m, i, t, x, y;
  fin >> n >> m;
  for (i = 1; i <= n; i++){
    fin >> v[i];
    update(i, v[i]);
  }
  for (i = 1; i <= m; i++){
    fin >> t >> x;
    if (t == 0){
      fin >> y;
      update(x, y);
    }
    else if (t == 1){
      fin >> y;
      fout << query(y) - query(x - 1) << "\n";
    }
    else
      fout << cb(x) << "\n";
  }
  return 0;
}
