#include <bits/stdc++.h>

#define DIM 200000

#define int long long

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

//ifstream f("filesmodel.in");
//ofstream g("filesmodel.out");

int n,m;
int c,x,y,a;
int aib[DIM+5];
int st,dr,mid,sol;

void update(int poz,int val){

    for(int i=poz;i<=n;i+=(i&-i)){
        aib[i]+=val;
    }
}

int query(int poz){

    if(poz < 1){
        return 0;
    }

    int sol = 0;

    for(int i=poz;i>=1;i-=(i&-i)){
        sol+=aib[i];
    }

    return sol;
}

signed main(){

    f>>n>>m;
    for(int i=1;i<=n;i++){
        f>>x;
        update(i,x);
    }
    while(m--){
        f>>c;
        if(c == 0){
            f>>x>>y;
            update(x,y);
        }else if(c == 1){
            f>>x>>y;
            g<<query(y)-query(x-1)<<'\n';
        }else{
            f>>a;
            st = 0;dr = n;sol = -1;
            while(st<=dr){
                mid = (st+dr)/2;
                if(query(mid)>=a){
                    sol = mid;
                    dr = mid-1;
                }else{
                    st = mid+1;
                }
            }
            if(query(sol) == a){
                g<<sol<<'\n';
            }else{
                g<<"-1\n";
            }
        }
    }
    return 0;
}
