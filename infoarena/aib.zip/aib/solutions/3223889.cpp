#include <fstream>

#define DIM 100005

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

int n, m, aint[DIM];

void update(int pos, int val) {
    for (int i = pos; i <= n; i += (i & -i)) {
        aint[i] += val;
    }
}

int query(int pos) {
    int res = 0;
    for (int i = pos; i >= 1; i -= (i & -i)) {
        res += aint[i];
    }

    return res;
}

int querySum(int sum) {
    int pos = -1;
    int st = 1, dr = n;
    while (st <= dr) {
        int mid = (st + dr) / 2;
        int res = query(mid);
        if (res == sum) {
            pos = mid;
            dr = mid - 1;
        } else if (res < sum) {
            st = mid + 1;
        } else if (res > sum) {
            dr = mid - 1;
        }
    }
    return pos;
}

int main() {
    f >> n >> m;

    for (int i = 1; i <= n; i++) {
        int x;
        f >> x;
        update(i, x);
    }

    for (int i = 0; i < m; i++) {
        int op;
        f >> op;
        if (op == 0) {
            int a, b;
            f >> a >> b;
            update(a, b);
        }
        if (op == 1) {
            int a, b;
            f >> a >> b;
            g << query(b) - query(a - 1) << "\n";
        }
        if (op == 2) {
            int a;
            f >> a;
            g << querySum(a) << "\n";
        }
    }

    return  0;
}