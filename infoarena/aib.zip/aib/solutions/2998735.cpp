#include <fstream>
#include <iostream>


using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
long long A[100005];
int n, q;
long long query(int p) {
    long long suma = 0;
    for (int i = p; i; i -= (i & -i)) {
        suma += A[i];
    }
    return suma;

}

void update(int p, int val) {

    for (int i = p; i <= n; i += (i & -i)) {
        A[i] += val;
    }


}






int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fin >> n >> q;
    int aux;
    for (int i = 1; i <= n; i++) {
        fin >> aux;
        update(i, aux);
    }

    int pos, val, a, b,t;
    for (int i = 1; i <= q; i++) {
       
        fin >> t;
        if (t == 0) {
            fin >> pos >> val;
            update(pos, val);
        }
        else if (t == 1) {
            fin >> a >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else if (t == 2) {
            fin >> a;

            //fout << cb(1, n, a) << '\n';
            int sol = -1;
            int st = 1;
            int dr = n;
            int mij;
            int aux;
            while (st <= dr) {
                 mij = (st + dr) / 2;
                 aux = query(mij);

                if (aux == a) {
                    sol = mij;
                    break;
                }
                else if (aux > a) {
                    dr = mij-1;
                }
                else {
                    st = mij + 1;
                }
            }
            fout << sol<<'\n';
        }
    }


    fin.close();
    fout.close();
    return 0;

}