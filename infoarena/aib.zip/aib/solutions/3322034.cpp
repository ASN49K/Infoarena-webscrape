#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("aib.in");
ofstream fout("aib.out");
#endif

int n;
int aib[100001];

void update(int p, int a) {
    while (p <= n) {
        aib[p] += a;
        p += (p & -p);
    }
}

int query(int p) {
    int s = 0;
    while (p > 0) {
        s += aib[p];
        p -= (p & -p);
    }
    return s;
}

int main() {
    int m, t, a, b;
    bool gasit;
    fin >> n >> m;
    for (int i=1; i<=n; i++) {
        fin >> a;
        update(i, a);
    }
    for (int i=1; i<=m; i++) {
        fin >> t >> a;
        if (t == 0) {
            fin >> b;
            update(a, b);
        }
        else if (t == 1) {
            fin >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else {
            gasit = false;
            for (int i=1; i<=n; i*=2) if (aib[i] == a) {
                fout << i << '\n';
                gasit = true;
                break;
            }
            if (!gasit) fout << "-1\n";
        }
    }
}
