#include <iostream>
#include <fstream>

using namespace std;

int log2[100001];

void calcLog(){
    log2[1] = 0;
    for(int i = 2; i <= 1e5; i++)
        log2[i] = log2[i / 2] + 1;
}

struct aib{
    int n, v[100001];
    void init(int n){
        this->n = n;
    }
    void add(int pos, int x){
        while(pos <= n){
            v[pos] += x;
            pos += pos & -pos;
        }
    }
    int sum(int pos){
        int rez = 0;
        while(pos){
            rez += v[pos];
            pos &= pos - 1;
        }
        return rez;
    }
    int rangeSum(int x, int y){
        return sum(y) - sum(x - 1);
    }
    int binSearch(int sum){
        int maxp = (1 << log2[sum]), pos = 0;
        for(int interval = maxp; interval; interval >>= 1){
            if(pos + interval <= n && v[pos + interval] < sum){
                sum -= v[pos + interval];
                pos += interval;
            }
        }
        return pos + 1;
    }
};

aib fen;

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    int n, q, t, x, y;
    cin >> n >> q;
    calcLog();
    fen.init(n);
    for(int i = 1; i <= n; i++){
        cin >> x;
        fen.add(i, x);
    }
    for(int i = 1; i <= q; i++){
        cin >> t >> x;
        if(t == 0)
            cin >> y, fen.add(x, y);
        else
            if(t == 1)
                cin >> y, cout << fen.rangeSum(x, y) << "\n";
            else
                cout << fen.binSearch(x) << "\n";
    }
    return 0;
}
