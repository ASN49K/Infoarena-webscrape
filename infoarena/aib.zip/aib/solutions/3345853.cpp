#include <fstream>
#include <vector>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

int n, m;
vector<int> v, aib;

int zeros(int x) {
	return x&-x;
}

void update(int pos, int val) {
	for (int i = pos; i <= n; i += zeros(i))
		aib[i] += val;
}

void create() {
	for (int i = 1; i <= n; i++) {
		for(int j = i; j <= n; j += zeros(j))
			aib[j] += v[i];
	}
}

int suma(int x){
	int sum = 0;
	for (int i = x; i > 0; i -= zeros(i))
		sum += aib[i];
	return sum;
}

void binarySearch(int x) {
	int sum = 0, pos = 0;
	for (int i = 1 << 20; i > 0; i >>= 1) {
		if (pos + i <= n && sum + aib[pos + i] < x) {
			sum += aib[pos + i];
			pos += i;
		}
	}
	out << pos + 1 << "\n";
}

int main()
{
	in >> n >> m;
	v.resize(n + 1);
	aib.resize(n + 1); //resize la vectorul arborelor indexate binar
	for(int i=1; i<=n; i++)
		in >> v[i];
	create();
	int q, x, y;
	while (m--) {
		in >> q;
		if (q == 0) {
			in >> x >> y;
			update(x, y);
		}
		if (q == 1) { // sumator pentru intervalul [x, y]
			int sum = 0;
			in >> x >> y;
			sum += suma(y) - suma(x - 1);
			out << sum << "\n";
		}
		if (q == 2) { // Sa se determine pozitia minima k astfel incat suma valorilor primilor k termeni sa fie exact x.
			in >> x;
			binarySearch(x);
		}
	}
}