#include <fstream>
#define dim 100001
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

int aib[dim];
int n;

void update(int poz, int val)
{
    for(int i=poz;i<=n;i+=(i&-i))
    {
        aib[i]+=val;
    }
}

int query(int poz)
{
    int sol=0;
    for(int i=poz;i>0;i-=(i&-i))
    {
        sol+=aib[i];
    }
    return sol;
}

int cautbin(int x)
{
    int st=1, dr=n, sol=-1;
    while(st<=dr)
    {
        int mid=(st+dr)/2;
        int val=query(mid);
        if(val==x)
        {
            sol=mid;
            dr=mid-1;
        }
        else
        if(val>x)
        {
            dr=mid-1;
        }
        else
        {
            st=mid+1;
        }
    }
    return sol;
}

int main()
{
    int m, x, i, c, poz, a, b;
    fin>>n>>m;
    for(i=1;i<=n;i++)
    {
        fin>>x;
        update(i, x);
    }
    for(i=1;i<=m;i++)
    {
        fin>>c;
        if(c==0)
        {
            fin>>poz>>x;
            update(poz, x);
        }
        else
        if(c==1)
        {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<"\n";
        }
        else
        {   fin>>x;
            fout<<cautbin(x)<<"\n";
        }
    }
}
