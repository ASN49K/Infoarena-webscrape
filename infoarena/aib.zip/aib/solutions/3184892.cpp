#include <bits/stdc++.h>
#define DIM 100001
#define int long long
using namespace std;

ifstream fin("file.in");
ofstream fout("file.out");

int n, q, task, a, b;
int aib[DIM];
int i, j;

void update(int poz, int val){
    for(int i=poz; i<=n; i+=(i&-i))
        aib[i]+=val;
}

int query(int poz){
    int ans=0;
    for(int i=poz; i>0; i-=(i&-i))
        ans+=aib[i];
    return ans;
}

int cb(int val, int st, int dr){
    while(st<=dr){
        int mij=(st+dr)/2;
        if(val<aib[mij])
            dr=mij-1;
        if(val>aib[mij])
            st=mij+1;
        if(val==aib[mij])
            return mij;
    }
    return -1;
}

void query1(int st, int dr){
    fout<<query(dr)-query(st-1)<<"\n";
}

void query2(int val){
    fout<<cb(val, 1, n)<<"\n";
}

int32_t main(){
    fin>>n>>q;

    for(i=1; i<=n; i++){
        fin>>a;
        update(i, a);
    }

    while(q--){
        fin>>task;
        if(task==0){
            fin>>a>>b;
            update(a, b);
        }

        if(task==1){
            fin>>a>>b;
            query1(a, b);
        }

        if(task==2){
            fin>>a;
            query2(a);
        }

    }
}
