//#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
const string file = "aib";
ifstream cin(file + ".in");
ofstream cout(file + ".out");
#define FAST ios_base::sync_with_stdio(0), cin.tie(0),cout.tie(0) ;
int aib[200005], n, q;
void update(int pos, int val) {
    while (pos <= n) aib[pos] += val, pos += pos & (-pos);
}
int sum(int pos) {
    int sum = 0;
    while (pos > 0) sum += aib[pos], pos -= pos & (-pos);
    return sum;
}
int blift(int val) {
    int sum = 0, pos = 0;
    for (int l = 17; l >= 0; --l) {
        if (pos + (1 << l) <= n && sum + aib[pos+(1 << l)] <= val) {
            pos += (1 << l);
            sum += aib[1 << l];
        }
    }
    if (sum != val) return -1;
    else return pos;
}
int main(void)
{
    cin >> n >> q;
    for (int i = 1; i <= n; ++i) {
        int x;
        cin >> x;
        update(i, x);
    }
    while (q--) {
        int op, a, b;
        cin >> op;
        if (op == 0) {
            cin >> a >> b;
            update(a, b);
        }
        else if (op == 1) {
            cin >> a >> b;
            cout << sum(b) - sum(a - 1) << '\n';
        }
        else {
            cin >> a;
            cout << blift(a) << '\n';
        }
    }
    return 0;
}
