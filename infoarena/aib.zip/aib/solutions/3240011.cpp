#include <bits/stdc++.h>

using namespace std;ifstream f("aib.in");ofstream g("aib.out");const int NMAX = 5e4;int AIB[NMAX + 5], V[NMAX + 5];int N, M, op, a, b;int ub(int x){	return (x & (-x));}void add(int x, int y){	for (int i = x; i <= N; i += ub(i))		AIB[i] += y;}int sum(int x){	int rez = 0;	for (int i = x; i >= 1; i -= ub(i))		rez += AIB[i];	return rez;}
int main()
{	f >> N >> M;	for (int i = 1; i <= N; i++)	{		f >> V[i];		add(i, V[i]);	}	for (int i = 1; i <= M; i++)	{		f >> op >> a >> b;		if (op == 0)			g << sum(b) - sum(a - 1) << '\n';		else		if (op == 1)			add(a, b);	}
	f.close();	g.close();
    return 0;
}
