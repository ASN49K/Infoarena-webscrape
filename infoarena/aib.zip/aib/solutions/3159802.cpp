#include <bits/stdc++.h>
using namespace std;
#define NMAX 100001
int aib[NMAX * 3];
int n;
void update(int poz, int x){
    for(int i = poz;i<=n;i+=(i&-i)){
        aib[i] += x;
    }
}

int query(int poz){ /// query pe prefix
    int suma = 0;
    for(int i = poz;i>=1;i-=(i&-i)){
        suma += aib[i];
    }
    return suma;
}

int queryInterval(int x, int y){
    /// query pe interval folosindu ne de query ul pe prefix
    return query(y) - query(x - 1);
}

int minPoz(int a){
    /// complexitate log 2 n * log 2 n
    int st = 1, dr = n, mid = 0, poz;
    while(st <= dr){
        mid = (st + dr) / 2;
        int sum = query(mid);
        if(sum >= a){
            dr = mid - 1;
            poz = mid;
        }else{
            st = mid + 1;
        }
    }
   if(query(poz) == a)return poz;
   return -1;
}


int main(void){
    ofstream cout("aib.out");
    ifstream cin("aib.in");
    int Q;
    cin >> n >> Q;
    for(int i = 1;i<=n;i++){
        int x;
        cin >> x;
        update(i,x);
    }
    while(Q--){
        int C, x, y;
        cin >> C;
        if(C == 0){
            cin >> x >> y;
            update(x,y);
        }else if(C == 1){
            cin >> x >> y;
            cout << queryInterval(x,y) << '\n';

        }else{
            cin >> x;
            cout << minPoz(x) << '\n';
        }

    }
}
