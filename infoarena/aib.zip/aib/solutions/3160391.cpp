#include <bits/stdc++.h>
#define DIM 100001
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, q, task, a, b;
int v[DIM], arb[DIM*4];
int i, j;

void build(int nod, int st, int dr){
    if(st==dr)
        arb[nod]=v[st];
    else{
        int mij=(st+dr)/2;
        build(2*nod, st, mij);
        build(2*nod+1, mij+1, dr);
        arb[nod]=arb[nod*2]+arb[nod*2+1];
    }
}

void update(int nod, int st, int dr, int poz, int val){
    if(st==dr)
        arb[nod]=val;
    else{
        int mij=(st+dr)/2;
        if(poz<=mij)
            update(nod*2, st, mij, poz, val);
        else
            update(nod*2+1, mij+1, dr, poz, val);
        arb[nod]=arb[nod*2]+arb[nod*2+1];
    }
}

int query(int nod, int st, int dr, int qst, int qdr){
    if(qst<=st && dr<=qdr)
        return arb[nod];
    else{
        int mij=(st+dr)/2;
        if(qdr<=mij)
            return query(nod*2, st, mij, qst, qdr);
        if(qst>mij)
            return query(nod*2+1, mij+1, dr, qst, qdr);
        return query(nod*2, st, mij, qst, qdr) + query(nod*2+1, mij+1, dr, qst, qdr);
    }
}

int query2(int val){
    int st=1, dr=n;
    while(st<=dr){
        int mij=(st+dr)/2;
        int x=query(1, 1, n, 1, mij);
        if(x<val)
            st=mij+1;
        if(x>val)
            dr=mij-1;
        if(x==val)
            return mij;
    }
    return -1;
}

int main(){
    fin>>n>>q;
    for(i=1; i<=n; i++)
        fin>>v[i];

    build(1, 1, n);
    while(q--){
        fin>>task;
        if(task==0){
            fin>>a>>b;
            update(1, 1, n, a, v[a]+b);
            v[a]+=b;
        }
        if(task==1){
            fin>>a>>b;
            fout<<query(1, 1, n, a, b)<<"\n";
        }
        if(task==2){
            fin>>a;
            fout<<query2(a)<<"\n";
        }
    }
}
