#include <fstream>
#include <cmath>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int st,dr,mij,q,bb,ch,a,i,n,poz,x,lg,sum,m,b[318],v[100001];
int query (int lg,int n)
{
    int sum=0;
    while (lg<=n&&lg%m!=0)
    {
        sum+=v[lg];
        lg++;
    }
    if (lg<=n)
    {
        sum+=v[lg];
        lg++;
    }
    while (lg+m-1<=n)
    {
        sum+=b[lg/m+1];
        lg+=m;
    }
    while (lg<=n)
    {
        sum+=v[lg];
        lg++;
    }
    return sum;
}
void update (int pozv,int x)
{
    poz=pozv/m;
    if (pozv%m!=0)
        poz++;
    b[poz]+=x;
    v[pozv]=+x;
}
int main()
{
    fin>>n>>q;
    m=sqrt (n);
    poz=1;
    for (i=1; i<=n; i++)
    {
        fin>>v[i];
        b[poz]+=v[i];
        if (i%m==0)
            poz++;
    }
    for (i=1; i<=q; i++)
    {
        fin>>ch;
        if (ch==1)
        {
            fin>>a>>bb;
            fout<<query (a,bb)<<"\n";
        }
        else
            if (ch==0)
        {
            fin>>poz>>x;
            update (poz,x);
        }
        else
        {
            fin>>sum;
            st=1;
            dr=n;
            while (st<=dr)
            {
                mij=(st+dr)/2;
                int suma=query (1,mij);
                if (suma<sum)
                    st=mij+1;
                else
                    dr=mij-1;
            }
            if (query (1,st)==sum)
                fout<<st<<"\n";
            else
                fout<<"-1\n";
        }
    }
    return 0;
}
