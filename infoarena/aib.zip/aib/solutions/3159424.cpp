#include <fstream>


using namespace std;
int n,q,aib[100001];
ifstream fin("aib.in");
ofstream fout("aib.out");
void update(int poz,int val){

    for(int i=poz;i<=n;i+=(i&-i))
        aib[i]+=val;
}
int query(int poz){
   int s=0;
    for(int i=poz;i>=1;i-=(i&-i))
        s+=aib[i];
    return s;
}
int search(int val){
    int st=1,dr=n;
    int pozmax=0;
    while(st<=dr){
        int mid=(st+dr)/2;
        int x=query(mid);
        if(x==val){
            pozmax=mid,dr=mid-1;
        }
        else if(x<val)
            st=mid+1;
        else
            dr=mid-1;
    }
    if(pozmax==0)
        return -1;
    return pozmax;
}
int main(){
    fin>>n>>q;
    for(int i=1;i<=n;i++){
        int x; fin>>x;
        update(i,x);
    }
    while(q--){
        int cer; fin>>cer;
        if(cer==0){
            int poz,val;
            fin>>poz>>val;
            update(poz,val);
        }
        else if(cer==1){
            int a,b; fin>>a>>b;
            fout<<query(b)-query(a-1)<<'\n';
        }
        else{
            int sum; fin>>sum;
            fout<<search(sum)<<'\n';
        }
    }

    return 0;
}
