#include <stdio.h>
#include <iostream>
#define N_MAX 100001
#define N_LOG 20

using namespace std;

int n, m, arr[N_MAX];
int aib[N_MAX];

int leastSignificantBit (int x){
    return x & -x;
}

void build (){
    for (int i=1; i<=n; ++i){
        aib[i] += arr[i];

        if (i + leastSignificantBit(i) <= n)
            aib[i + leastSignificantBit(i)] += aib[i];
    }
}

void update (int idx, int value){
    arr[idx] = value;
    while (idx <= n){
        aib[idx] += value;
        idx += leastSignificantBit(idx);
    }
}

long long query (int Idx){
    long long Sum = 0;

    while (Idx){
        Sum += aib[Idx];
        Idx -= leastSignificantBit(Idx);
    }

    return Sum;
}

int binaryLifting (int value){
    int mask, pos, sum;

    pos = 0;
    sum = 0;
    mask = 1 << N_LOG;

    while (mask){
        if (pos + mask <= n && sum + aib[pos+mask] <= value){
            pos += mask;
            sum += aib[pos+mask];
        }
        mask >>= 1;
    }

    return pos;
}

int main (){
    FILE *in, *out;
    in = fopen ("aib.in", "r");
    out = fopen ("aib.out", "w");

    fscanf(in, "%d%d", &n, &m);
    for (int i=1; i<=n; ++i)
        fscanf (in, "%d", &arr[i]);
    
    build();

    int op, x, y;
    for (int i=1; i<=m; ++i){
        fscanf(in, "%d", &op);
        if (op == 0){
            fscanf(in, "%d%d", &x, &y);
            update(x, y);
        }
        else if (op == 1){
            fscanf(in, "%d%d", &x, &y);
            fprintf (out, "%ld \n", query(y) - query(x-1));
        }
        else{
            fscanf(in, "%d", &x);
            fprintf(out, "%d \n", binaryLifting(x));
        }
    }
    return 0;
}