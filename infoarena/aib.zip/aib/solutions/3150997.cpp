#include <fstream>
#include <vector>
using namespace std;
int N;
vector<int> bit(150002,0),v;
ifstream in("aib.in");
ofstream out("aib.out");
void update(int i,int val)
{
    while(i<=N)
    {
        bit[i]+=val;
        i+= i & -i;
    }
}
int prefixSum(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=bit[i];
        i-= i & -i;
    }
    return sum;
}
int rangeSum(int i, int j)
{
    return prefixSum(j) - prefixSum(i-1);
}
int main()
{
    int x,m;
    in>>N>>m;
    v.push_back(0);
    for(int i=1;i<=N;i++)
    {
        in>>x;
        v.push_back(x);
        update(i,x);
    }
    int op,a,b;
    for(int i=0;i<m;i++)
    {
        in>>op;
        if(op==0)
        {
            in>>a>>b;
            update(a,b);
        }
        else if(op==1)
        {
            in>>a>>b;
            out<<rangeSum(a,b)<<'\n';
        }
        else if(op==2)
        {
            in>>a;
            int sum,p=0;
            do
            {
                p++;
                sum=rangeSum(1,p);
            }while(sum!=a);
            out<<p<<'\n';
        }
    }
    return 0;
}
