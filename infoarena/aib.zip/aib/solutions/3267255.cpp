#include <bits/stdc++.h>

using namespace std;
ifstream fin ( "aib.in" ) ;
ofstream fout ( "aib.out" ) ;
class Problema {
int n ;
vector<int> v , aib ;
int op ;
void update(int poz, int s)
{
    for ( int i = poz ; i <= n ; i += i & (-i))
        aib[i]+=s;
}
int querry(int x)
{
    int suma = 0 ;
    for ( int i = x ; i >= 1 ; i -= i & (-i))
        suma += aib[i];
    return suma ;
}
void citire()
{
fin >> n >> op ;

aib.resize(n+2);
for ( int i = 1 ; i <= n ; ++ i )
    {
    int x ;
    fin >> x;
    update(i,x);
    }
}


int Cb(int val) {
    int st = 1, dr = n;
    while(st <= dr) {
        int mij = st + (dr - st) / 2;

        int sum = querry(mij);

             if(sum == val) return mij;
        else if(sum <  val) st = mij + 1;
        else                dr = mij - 1;
    }
    return -1;
}

void problema()
{
for ( int i = 1 ; i <= op ; ++ i )
{
    int c ;
    fin >> c ;
    if ( c == 0 )
    {
    int x , y ;
    fin >> x >> y ;
    update(x,y);
    }
    else if ( c == 1 )
    {
    int x , y ;
    fin >> x >> y ;
    fout << querry(y)-querry(x-1) << "\n";
    }
    else
    {
    int x ;
    fin >> x ;
    fout << Cb(x) << "\n";
    }
}
}
public:
    void problema_1()
    {
    citire();
    problema();
    }
} pr;
int main()
{
    pr.problema_1();

    return 0;
}
