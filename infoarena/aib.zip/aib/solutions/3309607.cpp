#include <bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int lsb(int i){
return (i&(-i));
}
const int MAXN=1e5;
int n,q;
int a[MAXN+1],aib[MAXN+1];
void update(int poz,int val) {
    for(int i=poz; i<=n; i+=lsb(i)) {
        aib[i]+=val;
    }
}
int query(int poz) {
    int ans=0;
    for(int i=poz; i>=1; i-=lsb(i)) {
        ans+=aib[i];
    }
    return ans;
}
int caut_bin(int val) {
    int st=1,dr=n;
    while(st<=dr) {
        int mid=(st+dr)/2;
        if(query(mid)==val) {
            return mid;
        } else if(query(mid)<val) {
            st=mid+1;
        } else {
            dr=mid-1;
        }
    }
    return -1;
}
int main() {
    fin>>n>>q;
    for(int i=1; i<=n; i++) {
        int val;
        fin>>val;
        update(i,val);
    }
    while(q--) {
        int tip,a,b;
        fin>>tip;
        if(tip==0) {
            fin>>a>>b;
            update(a,b);
        } else if(tip==1) {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<'\n';
        } else {
            fin>>a;
            fout<<caut_bin(a)<<"\n";
        }
    }
    return 0;
}
