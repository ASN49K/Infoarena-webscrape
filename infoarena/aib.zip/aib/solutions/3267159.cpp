#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in") ;
ofstream fout ("aib.out") ;
int n , i , x , y , ind , nr , m , a[100001] , v[100001] , caz , av , b , j ;
void add ( int ind , int x )
{
    for ( int i = ind ; i <= n ; i += ( i & ( - i ) ) )
        a[i] += x ;
}
int sum ( int x )
{
    int s = 0 ;
    for ( int i = x ; i >= 1 ; i -= ( i & ( - i ) ) )
        s += a[i] ;
    return s ;
}
int main()
{
    fin >> n >> m ;
    for ( i = 1 ; i <= n ; i ++ )
    {
        fin >> v[i] ;
        add ( i , v[i] ) ;
    }
    for ( j = 1 ; j <= m ; j ++ )
    {
        fin >> caz ;
        if ( caz == 0 )
        {
            fin >> ind >> nr ;
            add ( ind , nr ) ;
        }
        else if ( caz == 1 )
        {
            fin >> av >> b ;
            fout << sum ( b ) - sum ( av - 1 ) << '\n' ;
        }
        else
        {
            fin >> x ;
            i = n ;
            while ( sum(i) > x )
                i -= ( i & ( - i ) ) ;
            while ( sum(i) < x )
                i ++ ;
            if ( sum(i) == x )
                fout << i << '\n' ;
            else
                fout << -1 << '\n' ;
        }
    }

    return 0;
}
