#include <fstream>
#include <vector>

using namespace std;

void actualizare(vector <int> &aib, int poz, int val) {
    int n = (int)aib.size() - 1;
    while (poz <= n) {
        aib[poz] += val;
        int p2 = (poz & (-poz));
        poz += p2;
    }
}

int interogare(vector <int> &aib, int poz) {
    int suma = 0;
    while (poz > 0) {
        suma += aib[poz];
        int p2 = (poz & (-poz));
        poz = poz - p2;
    }
    return suma;
}

int caut_bin(vector <int> &aib, int val) {
    int n = (int)aib.size() - 1, st = 1, dr = n, rez = n + 1;
    while (st <= dr) {
        int m = (st + dr) / 2;
        if (interogare(aib, m) >= val) {
            dr = m - 1;
            rez = m;
        } else {
            st = m + 1;
        }
    }
    if (rez == n + 1 || interogare(aib, rez) > val) {
        rez = -1;
    }
    return rez;
}

int main() {
    ifstream in("aib.in");
    ofstream out("aib.out");
    int n, q;
    in >> n >> q;
    vector <int> aib(n + 1, 0);
    for (int i = 1; i <= n; i++) {
        int x_i;
        in >> x_i;
        actualizare(aib, i, x_i);
    }
    for (int i = 0; i < q; i++) {
        int tip;
        in >> tip;
        if (tip == 0) {
            int poz, val;
            in >> poz >> val;
            actualizare(aib, poz, val);
        } else if (tip == 1) {
            int st, dr;
            in >> st >> dr;
            out << interogare(aib, dr) - interogare(aib, st - 1) << "\n";
        } else {
            int val;
            in >> val;
            out << caut_bin(aib, val) << "\n";
        }
    }
    return 0;
}