#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m;
int aib[100005];

void update(int ind, int val) {
    for (int i=ind; i<=n; i+=(i & -i))
        aib[i]+=val;
}

int query(int i) {
    int sum=0;
    while (i>0) {
        sum+=aib[i];
        i-=(i & -i);
    }
    return sum;
}

int cb(int sum, int n) {
    int left=1, right=n, mid=(left+right)/2;
    while (left<=right) {
        int res=query(mid);
        if (res==sum)
            return mid;
        if (res>sum)
            right=mid-1;
        else
            left=mid+1;
        mid=(left+right)/2;
    }
    return -1;
}

void citire() {
    fin>>n>>m;
    for (int i=1; i<=n; i++) {
        int temp;
        fin>>temp;
        update(i, temp);
    }
}

void queries() {
    for (int i=0; i<m; i++) {
        int op;
        fin>>op;
        switch (op) {
            case 0:
                int ind, val;
                fin>>ind>>val;
                update(ind, val);
                break;
            case 1:
                int a, b;
                fin>>a>>b;
                fout<<query(b)-query(a-1)<<'\n';
                break;
            case 2:
                int sum;
                fin>>sum;
                fout<<cb(sum, n)<<'\n';
        }
    }
}

int main() {
    citire();
    queries();
    return 0;
}