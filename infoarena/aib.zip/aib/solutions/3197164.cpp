#include <bits/stdc++.h>
using namespace std;
#define FAST ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0) ;
#define ll long long
ifstream fin("aib.in") ;
ofstream fout("aib.out") ;
const int NMAX=1e5+5 ;
int n,m,aib[NMAX],x ;
void update(int pos,int val)
{
    while(pos<=n) aib[pos]+=val,pos+=pos&(-pos) ;
}
int query(int pos)
{
    int s=0 ;
    while(pos>0) s+=aib[pos],pos-=pos&(-pos) ;
    return s ;
}
int main()
{
    fin>>n>>m ;
    for(int i=1; i<=n; ++i)
    {
        fin>>x ;
        update(i,x) ;
        //aib[i]+=x ;
        //if(i&(-i)<=n) aib[i&(-i)]+=aib[i] ;
    }
    while(m--)
    {
        int op,x,y ;
        fin>>op ;
        if(op==0)
        {
            fin>>x>>y;
            update(x,y) ;
        }
        else if(op==1)
        {
            fin>>x>>y;
            fout<<query(y)-query(x-1)<<'\n' ;
        }
        else
        {
            fin>>x ;
            int pos=0,val=0 ;
            for(int b=17; b>=0; --b) if(pos+(1<<b)<=n && val+aib[pos+(1<<b)]<=x) pos+=(1<<b),val+=aib[pos+(1<<b)] ;
            if(val==x) fout<<pos<<'\n' ;
            else fout<<-1<<'\n' ;
        }
    }
    return 0;
}

