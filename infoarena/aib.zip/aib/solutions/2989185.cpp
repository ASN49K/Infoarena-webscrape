#include <fstream>

#define DIM 100005

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

int n, q, aib[DIM];

void update(int pos, int val) {
    for (int i = pos; i <= n; i += (i & -i)) {
        aib[i] += val;
    }
}

int query(int pos) {
    int sum = 0;
    for (int i = pos; i >= 1; i -= (i & -i)) {
        sum += aib[i];
    }

    return sum;
}

int cb(int val) {
    int st = 1, dr = n, pos = -1;
    while (st <= dr) {
        int mid = (st + dr) / 2;
        int queryRes = query(mid);
        if (queryRes > val) {
            dr = mid - 1;
        } else if (queryRes < val) {
            st = mid + 1;
        } else if (queryRes == val) {
            dr = mid - 1;
            pos = mid;
        }
    }
    return pos;
}

int main() {

    f >> n >> q;

    for (int i = 1; i <= n; i++) {
        int x;
        f >> x;
        update(i, x);
    }

    while (q--) {
        int ops, x, y;
        f >> ops >> x;
        if (ops == 0) {
            f >> y;
            update(x, y);
        } else if (ops == 1) {
            f >> y;
            g << query(y) - query(x - 1) << "\n";
        } else if (ops == 2) {
            g << cb(x) << "\n";
        }
    }

    return 0;
}