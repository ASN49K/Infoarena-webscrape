#include <bits/stdc++.h>

using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
int aib[160001],n,m,a,b;

void adun(int a, int b)
{
    for(int i=a; i<=n; i+=i&(-i))
        aib[i]+=b;
}
int suma(int x)
{
    int s=0;
    for(int i=x; i>=1; i-=i&(-i))
        s+=aib[i];
    return s;

}
int caut(int a)
{

    int dr=n;
    int st=1;
    int rez=-1;

    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(suma(mij)<a) st=mij+1;
        else if(suma(mij)>a) dr=mij-1;
        else {rez=mij;
        break;
        }
    }
    return rez;
}

int main()
{
    f>>n>>m;
    for(int i=1; i<=n; i++)
    {
        int x;
        f>>x;
        adun(i,x);
    }
    for(int i=1; i<=m; i++)
    {
        int op;
        f>>op;
        if(op==0)
        {
            f>>a>>b;
            adun(a,b);

        }
        else if(op==1)
        {
            f>>a>>b;
            g<<suma(b)-suma(a-1)<<'\n';
        }
        else
        {
            f>>a;
            g<<caut(a)<<'\n';
        }
    }
    return 0;
}
