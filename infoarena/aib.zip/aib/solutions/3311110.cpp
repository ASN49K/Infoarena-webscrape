#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

long long v[1000001],aib[1000001];

int main()
{
    long long n,m,x,y,z,r=0;
    cin>>n>>m;
    for(long long i=1;i<=n;i++)
    {
        cin>>v[i];
        x=i;
        while(x<=n)
        {
            aib[x]+=v[i];
            x+=x&-x;
        }
    }
    for(long long i=1;i<=m;i++)
    {
        cin>>x;
        if(x==0)
        {
            cin>>y>>z;
            v[y]+=z;
            while(y<=n)
            {
                aib[y]+=z;
                y+=y&-y;
            }
        }
        if(x==1)
        {
            cin>>y>>z;
            r=0;
            y--;
            while(y)
            {
                r-=aib[y];
                y-=y&-y;
            }
            while(z)
            {
                r+=aib[z];
                z-=z&-z;
            }
            cout<<r<<'\n';
        }
        if(x==2)
        {
            cin>>y;
            r=0;
            for(long long i=1;i<=n;i++)
            {
                r+=v[i];
                if(r==y)
                {
                    cout<<i<<'\n';
                    break;
                }
            }
        }
    }
    return 0;
}
