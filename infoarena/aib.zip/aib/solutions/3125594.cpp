#include <fstream>

using namespace std;

ifstream cin ("aib.in");
ofstream cout ("aib.out");

int n, k;
int bit[1000001];

void update (int i, int val)
{
	while (i <= n)
	{
		bit[i] += val;
		i += (i & (-i));
	}
}

int prefixSum (int i)
{
	int sum = 0;

	while (i > 0)
	{
		sum += bit[i];
		i -= (i & (-i));
	}

	return sum;
}

int range (int i, int j)
{
	return prefixSum (j) - prefixSum (i - 1);
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	cin >> n >> k;

	for (int i = 1; i <= n; i ++)
	{
		int a; cin >> a;
		update (i, a);
	}

	for (int i = 1; i <= k; i ++)
	{
		int x; cin >> x;

		switch (x)
		{
			case 0:
				int pos, inc; cin >> pos >> inc;
				update (pos, inc);
				break;

			case 1:
				int a, b; cin >> a >> b;
				cout << range(a, b) << '\n';
                break;

			case 2:
				int q; cin >> q;
				int st = 1, dr = n;
				int ans = n + 1;

				while (st <= dr)
				{
					int mid = (st + dr) / 2;
					int val = prefixSum(mid);

					if (val >= q)
					{
						if (val == q)
							ans = min (ans, mid);

						dr = mid - 1;
					}
					else
						st = mid + 1;
				}

				if (ans == n + 1)
					cout << -1 << '\n';
				else
					cout << ans << '\n';

				break;
		}
	}
}
