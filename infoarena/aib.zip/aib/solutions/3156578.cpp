#include <bits/stdc++.h>
#define int long long
using namespace std;

#ifndef LOCAL

ifstream in("aib.in");
ofstream out("aib.out");

#define cin in
#define cout out
#endif // FIO



int nextbit(int n)
{
    int p=1;
    while(p<n) p<<=1;
    return p;
}

struct arbint{
    int offset;
    vector<int> arb;

    arbint (int n){
        offset=nextbit(n);
        cerr<<offset<<'\n';
        arb.assign(offset*2,0);
    }

    void update(int poz,int x)
    {
        for(poz+=offset-1;poz>0;poz>>=1)
        {
            arb[poz]+=x;
        }
    }

    int query(int st, int dr)
    {
        int ans=0;
        for(st+=offset-1, dr+=offset; st<dr; st>>=1, dr>>=1){
            if(st&1) ans+=arb[st++];
            if(dr&1)ans+=arb[--dr];
        }
        return ans;
    }

    int cb(int nod,int st, int dr, int qst, int &suma)
    {
        if(dr<qst) return dr;

        if(st==dr&&suma<arb[nod])
        {
            return st-1;
        }

        if(qst<=st && suma>=arb[nod])
        {
            suma-=arb[nod];
            return dr;
        }


        int mid=(st+dr)/2;
        int cb_stanga=cb(nod*2,st,mid, qst,suma);
        if(cb_stanga<mid)
        {
            return cb_stanga;
        }
        return cb(nod*2+1,mid+1,dr,qst,suma);
    }

    pair<int,int> caut(int st, int suma)
    {
        return {cb(1,1,offset,st,suma), suma};
    }

};


int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n,m;
    cin>>n>>m;
    arbint arb(n);

    int a,b,c;

    for(int i=1;i<=n;i++)
    {
        cin>>a;
        arb.update(i,a);
    }


    #ifdef LOCAL
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            cerr<<arb.query(i,j)<<' ';
        }
        cerr<<'\n';
    }
    #endif // LOCAL

    for(int i=1;i<=m;i++)
    {
        cin>>c;
        pair<int,int>p;

        switch(c)
        {
        case 0:
            cin>>a>>b;
            arb.update(a,b);
            break;
        case 1:
            cin>>a>>b;
            cout<<arb.query(a,b)<<'\n';
            break;
        case 2:
            cin>>a;
            p=arb.caut(1,a);
            if(p.second==0)
            {
                cout<<min(p.first,n)<<'\n';
            }
            else
            {
                cout<<-1<<'\n';
            }
            break;
        default:
            assert(0);
        }
    }
    return 0;
}
