#include <bits/stdc++.h>
using namespace std;

struct Fenwick {
    int n;
    vector<int> bit;

    Fenwick(int n) : n(n), bit(n+1, 0) {}

    void update(int idx, int val) {
        for (; idx <= n; idx += idx & -idx)
            bit[idx] += val;
    }

    int query(int idx) {
        int sum = 0;
        for (; idx > 0; idx -= idx & -idx)
            sum += bit[idx];
        return sum;
    }

    int rangeQuery(int l, int r) {
        return query(r) - query(l-1);
    }

    int findPos(int target) {
        int pos = 0;
        int sum = 0;
        for (int step = 1 << (31 - __builtin_clz(n)); step > 0; step >>= 1) {
            if (pos + step <= n && sum + bit[pos + step] < target) {
                sum += bit[pos + step];
                pos += step;
            }
        }
        pos++;
        if (pos > n || query(pos) != target) return -1;
        return pos;
    }
};

int main() {
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;
    Fenwick fenw(N);

    for (int i = 1; i <= N; i++) {
        int x;
        cin >> x;
        fenw.update(i, x);
    }

    while (M--) {
        int type;
        cin >> type;
        if (type == 0) {
            int a, b;
            cin >> a >> b;
            fenw.update(a, b);
        } else if (type == 1) {
            int a, b;
            cin >> a >> b;
            cout << fenw.rangeQuery(a, b) << "\n";
        } else {
            int a;
            cin >> a;
            cout << fenw.findPos(a) << "\n";
        }
    }
    return 0;
}
