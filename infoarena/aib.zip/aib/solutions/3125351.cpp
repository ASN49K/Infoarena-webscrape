#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m;
int bit[100005];

int update(int i, int val)
{
    while(i <= n)
    {
        bit[i]+=val;
        i+=(i&-i);
    }
}

int sum(int i)
{
    int sum=0;
    while(i > 0)
    {
        sum+=bit[i];
        i-=(i&-i);
    }
    return sum;
}

int32_t main()
{
    fin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        int a;
        fin>>a;
        update(i, a);
    }
    for(int i=1; i<=m; i++)
    {
        int op, a, b;
        fin>>op>>a;
        if(op < 2)
        {
            fin>>b;
        }
        if(op == 0)
        {
            update(a, b);
        }
        else if(op == 1)
        {
            fout<<sum(b)-sum(a-1);
        }
        else
        {
            int st=1, dr=n;
            int ans=INT_MAX;
            while(st <= dr)
            {
                int mid=(st+dr)/2;
                if(sum(mid) >= a)
                {
                    dr=mid-1;
                    if(sum(mid) == a)
                        ans=min(ans, mid);
                }
                else
                {
                    st=mid+1;
                }
            }
            if(ans == INT_MAX)
                fout<<-1;
            else
                fout<<ans;
        }
        fout<<'\n';
    }
    return 0;
}
