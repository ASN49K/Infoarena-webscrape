#include <fstream>
#define NMAX 100002
using namespace std;
ifstream  fin("aib.in");
ofstream fout("aib.out");
int N,M,v[NMAX],aib[NMAX];

void update(int nod, int val)
{
    for(int i=nod; i<=N; i+=(i&(-i)))
    {
        aib[i]+=val;
    }
}

void citire()
{
    fin>>N>>M;

    for(int i=1; i<=N; i++)
    {
        fin>>v[i];
        update(i,v[i]);
    }
}

long long query(int nod)
{
    long long ans=0;
    for(int i=nod; i>=1; i-=(i&(-i)))
    {
        ans+=aib[i];
    }

    return ans;
}

int main()
{
    citire();

    for(int q=1; q<=M; q++)
    {
        int op,a,b;
        fin>>op>>a;

        if(op==0)
        {
            fin>>b;
            update(a,b);
        }

        if(op==1)
        {
            fin>>b;
            fout<< query(b)-query(a-1) << "\n";
        }

        if(op==2)
        {
            int p1,p2,pmijl,k;
            long long sum;
            k=-1;
            p1=1;
            p2=N;

            while(p1<=p2)
            {
                pmijl=(p1+p2)/2;
                sum=aib[pmijl];

                if(sum==a)
                {
                    k=pmijl;
                    break;
                }
                else
                {
                    if(sum<a)
                    {
                        p1=pmijl+1;
                    }
                    else
                    {
                        p2=pmijl-1;
                    }
                }
            }

            fout<< k << "\n";
        }
    }

    return 0;
}
