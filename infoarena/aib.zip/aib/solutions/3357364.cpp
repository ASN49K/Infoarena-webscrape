#include <cstdio>
using namespace std;

const int MAXN = 100005;
int n, m, A[MAXN], tree[4 * MAXN];

void build(int node, int start, int end) {
    if (start == end)
        tree[node] = A[start];
    else {
        int mid = (start + end) / 2;
        build(2 * node, start, mid);
        build(2 * node + 1, mid + 1, end);
        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }
}

void update(int node, int start, int end, int idx, int val) {
    if (start == end)
        tree[node] += val;
    else {
        int mid = (start + end) / 2;
        if (idx <= mid)
            update(2 * node, start, mid, idx, val);
        else
            update(2 * node + 1, mid + 1, end, idx, val);
        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }
}

int query(int node, int start, int end, int l, int r) {
    if (r < start || end < l)
        return 0;
    if (l <= start && end <= r)
        return tree[node];
    int mid = (start + end) / 2;
    return query(2 * node, start, mid, l, r) + query(2 * node + 1, mid + 1, end, l, r);
}

int main() {
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);

    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; ++i)
        scanf("%d", &A[i]);

    build(1, 0, n - 1);

    for (int i = 0; i < m; ++i) {
        int op;
        scanf("%d", &op);
        if (op == 0) {
            int a, b;
            scanf("%d %d", &a, &b);
            update(1, 0, n - 1, a - 1, b);
        } else if (op == 1) {
            int a, b;
            scanf("%d %d", &a, &b);
            printf("%d\n", query(1, 0, n - 1, a - 1, b - 1));
        } else {
            int a;
            scanf("%d", &a);
            int sum = 0, pos = -1;
            for (int j = 0; j < n && sum <= a; ++j) {
                sum += A[j];
                if (sum == a)
                    pos = j + 1;
            }
            printf("%d\n", pos);
        }
    }

    return 0;
}