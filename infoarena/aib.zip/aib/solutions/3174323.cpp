#include <iostream>

using namespace std;

#define int long long
int n, q;
const int MAXN=100005;
int aib[MAXN];

void update(int pos, int val)
{
    for(; pos<MAXN; pos=pos|(pos+1))
        aib[pos]+=val;
}

int suma(int r)
{
    int res=0;
    for(; r>0; r=(r&(r+1))-1)
        res+=aib[r];
    return res;
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    int x;
    cin>>n>>q;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        update(i, x);
    }
    for(int i=1; i<=q; i++)
    {
        int type; cin>>type;
        if(type==0)
        {
            int pos, val; cin>>pos>>val;
            update(pos, val);
        }
        if(type==1)
        {
            int l, r; cin>>l>>r;
            cout<<suma(r)-suma(l-1)<<'\n';
        }
        if(type==2)
        {
            int k; cin>>k;
            int index=0;
            for(int bit=25; bit>=0; bit--)
            {
                index+=(1ll<<bit);
                if(index>n || suma(index)>=k)
                    index-=(1ll<<bit);
            }
            //la index, suma < k
            if(suma(index+1)==k)
                cout<<index+1<<'\n';
            else
                cout<<"-1\n";
        }
    }
    return 0;
}
