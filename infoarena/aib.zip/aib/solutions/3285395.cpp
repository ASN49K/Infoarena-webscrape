#include <iostream>
#include <bits/stdc++.h>
#define int long long int
#define VMAX 100005
#define INF 2000000000
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");


int numere[4*VMAX];
int nrr[VMAX];

void build(int st, int dr, int nr)
{
    if(st==dr)
    {
        numere[nr]=nrr[st];
        return;
    }
    int mij;
    mij=(st+dr)/2;
    build(st,mij,nr*2);
    build(mij+1,dr,nr*2+1);
    numere[nr]=numere[2*nr]+numere[2*nr+1];
}

void add_x(int poz, int st, int dr, int val, int nr)
{
    if(st==dr)
    {
        numere[nr]+=val;
        return;
    }
    int mij;
    mij=(st+dr)/2;
    if(poz<=mij)
        add_x(poz,st,mij,val,2*nr);
    else
        add_x(poz,mij+1,dr,val,2*nr+1);
    numere[nr]+=val;
}

int sum_interval(int s, int d, int st, int dr, int nr)
{
    if(st==dr)
        return numere[nr];
    int mij;
    mij = (st+dr)/2;
    int sum=0;
    if(s==st && mij<=d)
        sum+=numere[2*nr];
    else if(mij>=s)
        sum+=sum_interval(s,min(mij,d),st,mij,2*nr);
    if(s<=mij+1 && dr==d)
        sum+=numere[2*nr+1];
    else if(mij+1<=d)
        sum+=sum_interval(max(mij+1,s),d,mij+1,dr,2*nr+1);
    return sum;
}

int poz_min_sum(int st, int dr, int val, int nr)
{
    if(st==dr)
    {
        if(numere[nr]==val)
            return dr;
        else
            return -1;
    }
    int mij=(st+dr)/2;

    if(val<=numere[2*nr])
        return poz_min_sum(st,mij,val,2*nr);
    else if(val>numere[2*nr] && val<=numere[nr])
        return poz_min_sum(mij+1,dr,val-numere[2*nr],2*nr+1);
    else
        return -1;
}


signed main()
{
    ios_base::sync_with_stdio(0);
    int n,m,i,j,k,t,q,nr,minim,maxim,suma;
    fin>>n>>m;
    for(i=1;i<=n;i++)
    {
        fin>>nrr[i];
        add_x(i,1,n,nrr[i],1);
    }

    //build(1,n,1);

    for(i=0;i<m;i++)
    {
        fin>>j>>k;
        if(j==0)
        {
            fin>>t;
            add_x(k,1,n,t,1);
        }
        else if(j==1)
        {
            fin>>t;
            fout<<sum_interval(k,t,1,n,1)<<'\n';
        }
        else
            fout<<poz_min_sum(1,n,k,1)<<'\n';
    }




    return 0;
}
