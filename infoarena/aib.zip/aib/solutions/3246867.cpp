#include <bits/stdc++.h>

using namespace std;

int aib[100005];
int n, q, x, t, a, b;

void upd(int i, int val)
{
    while(i<=n)
    {
        aib[i]+=val;
        i+=(i&-i);
    }
}

int query(int i)
{
    int ans=0;
    while(i>=1)
    {
        ans+=aib[i];
        i-=(i&-i);
    }
    return ans;
}

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");

    cin>>n>>q;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        upd(i, x);
    }
    for(int i=1; i<=q; i++)
    {
        cin>>t;
        if(t==0)
        {
            cin>>a>>b;
            upd(a, b);
        }
        else if(t==1)
        {
            cin>>a>>b;
            cout<<query(b)-query(a-1)<<'\n';
        }
        else
        {
            cin>>x;
            int st=1, dr=n+1, md, ans;
            while(st<=dr)
            {
                md=(st+dr)/2;
                if(x>query(md))
                {
                    st=md+1;
                }
                else if(x==query(md))
                {
                    ans=md;
                    break;
                }
                else dr=md;
            }

            cout<<ans<<'\n';
        }
    }

    return 0;
}
