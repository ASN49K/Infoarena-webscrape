#include <bits/stdc++.h>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int a[100005], aib[100005], n;

/// a[p] += val
void Update(int p, int val)
{
    while (p <= n)
    {
        aib[p] += val;
        /// p = p + 2^k
        p = p + (p & (-p));
    }
}

/// ret. suma a[1] + a[2] + ... + a[p]
int Query(int p)
{
    int s = 0;
    while (p > 0)
    {
        s += aib[p];
        /// p = p - 2^k
        p = p - (p & (-p));
    }
    return s;
}

/// ret. cea mai din stanga pozitie p cu
/// a1 + a2 + ... + ap = x
int Op3(int x)
{
    int st, dr, mij, p, rez;
    st = 1; dr = n; p = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        rez = Query(mij);
        if (rez == x)
        {
            p = mij;
            dr = mij - 1;
        }
        else if (rez < x) st = mij + 1;
        else dr = mij - 1;
    }
    return p;
}


int main()
{
    int i, x, y, m, op;
    fin >> n >> m;
    for (i = 1; i <= n; i++)
    {
        fin >> x;
        Update(i, x);
    }
    /// interogarile
    for (i = 1; i <= m; i++)
    {
        fin >> op;
        if (op == 0)
        {
            fin >> x >> y;
            Update(x, y);
        }
        else if (op == 1)
        {
            fin >> x >> y;
            fout << Query(y) - Query(x - 1) << "\n";
        }
        else /// op == 2
        {
            fin >> x;
            fout << Op3(x) << "\n";
        }
    }

    return 0;
}
