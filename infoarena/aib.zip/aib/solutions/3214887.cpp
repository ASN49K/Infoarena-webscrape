#include <iostream>
#include <fstream>
#define nmx 400005
using namespace std;
int n,m,mx,a,b,c,arb[nmx],rsp,x,p;
void update (int poz,int x)
{
    poz=poz+p-1;
    arb[poz]+=x;
    while (poz)
    {
        poz/=2;
        arb[poz]=arb[poz*2]+arb[poz*2+1];
    }
}
int sum (int a,int b,int st,int dr,int index)
{
    if (st>b || dr<a) return 0;
    if (st>=a && dr<=b) return arb[index];
    return sum(a,b,st,(st+dr)/2,index*2)+sum(a,b,(st+dr)/2+1,dr,index*2+1);
}
int calc(int a,int index)
{
    if (index>=p) return index-p+1;
    if (arb[index*2]<a)
        return calc(a-arb[index*2],index*2+1);
    return calc(a,index*2);
}
int main()
{
    ifstream f ("aib.in");
    ofstream g ("aib.out");
    f>>n>>m;
    p=1;
    while (p<n)
        p*=2;
    for (int i=1;i<=n;i++)
    {
        f>>x;
        update(i,x);
    }
    for (int i=1;i<=m;i++)
    {
        f>>c;
        for (int j=1;j<=16;j++)
            cout<<arb[j]<<' ';
        cout<<'\n';
        if (c==0)
        {
            f>>a>>b;
            update(a,b);
        }
        else if (c==1)
        {
            f>>a>>b;
            g<<sum(a,b,1,n,1)<<'\n';
        }
        else
        {
            f>>a;
            g<<calc(a,1)<<'\n';
        }
    }
}
