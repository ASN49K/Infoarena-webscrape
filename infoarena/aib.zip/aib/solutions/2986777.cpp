#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int nmax = 12;
long long n, m, tip, a, b, arb[nmax];

int sum(int nod)
{
    int sum = 0, i = nod;
    while(i > 0)
    {
        sum += arb[i];
        i -= i & (-i);
    }
    return sum;
}

void update(int i, int k)
{
    while (i <= n)
    {
        arb[i] += k;
        i += i & (-i);
    }
    return;
}

int getk(int a)
{
    int st = 1, dr = n;
    int sumk = 0;
    while (st <= dr)
    {
        int mij = (st + dr)/2;
        sumk = sum(mij);
        if (sumk == a)
            return mij;
        else if(a <= sumk)
            dr = mij - 1;
        else
            st = mij + 1;
    }
    return -1;
}

int main()
{
    int x;
    fin>>n>>m;
    for (int i = 1; i <= n; i++)
    {
        fin>>x;
        update(i, x);
    }
    for (int i = 1; i <= m; i++)
    {
        fin>>tip;
        if(tip == 0)
        {
            fin>>a>>b;
            update(a, b);
        }
        else if(tip == 1)
        {
            fin>>a>>b;
            fout<<sum(b) - sum(a-1)<<"\n";
        }
        else
        {
            fin>>a;
            fout<<getk(a)<<"\n";
        }
    }
}
