#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int nmax = 100002;
long long n, m, tip, a, b, arb[4 * nmax], v[nmax];

void build(int nod, int st, int dr);
void update(int nod, int st, int dr, int pos, int k);
long long query1(int nod, int st, int dr, int l, int r);
int query2(int nod, int st, int dr, int a);

int main()
{
    fin>>n>>m;
    for (int i = 1; i <= n; i++)
        fin>>v[i];
    build(1, 1, n);
    for (int i = 1; i <= m; i++)
    {
        fin>>tip;
        if(tip == 0)
        {
            fin>>a>>b;
            update(1, 1, n, a, b);
        }
        else if(tip == 1)
        {
            fin>>a>>b;
            fout<<query1(1, 1, n, a, b)<<"\n";
        }
        else
        {
            fin>>a;
            fout<<query2(1, 1, n, a)<<"\n";
        }
    }
}

void build(int nod, int st, int dr)
{
    if (st == dr)
    {
        arb[nod] = v[st];
        return;
    }
    build(nod * 2, st, (st + dr)/2);
    build(nod * 2 + 1, (st + dr)/2 + 1, dr);
    arb[nod] = arb[nod * 2] + arb[nod * 2 + 1];
}

void update(int nod, int st, int dr, int pos, int k)
{
    if (st == dr)
    {
        arb[nod] += k;
        return;
    }
    if (pos <= (st + dr)/2)
        update(nod * 2, st, (st + dr)/2, pos, k);
    else
        update(nod * 2 + 1, (st + dr)/2 + 1, dr, pos, k);
    arb[nod] = arb[nod * 2] + arb[nod * 2 + 1];
}

long long query1(int nod, int st, int dr, int l, int r)
{
    if (st == dr)
    {
        return arb[nod];
    }
    long long rez = 0;
    int mij = (st + dr) / 2;
    if (l <= mij)
        rez += query1(nod * 2, st, mij, l, r);
    if (r >= mij + 1)
        rez += query1(nod * 2 + 1, mij + 1, dr, l, r);
    return rez;
}

int query2(int nod, int st, int dr, int a)
{
    if (a > arb[nod]) return -1;
    if (st == dr) return st;
    int mid = (st + dr) / 2;
    if (a <= arb[nod * 2])
        return query2(nod * 2, st, mid, a);
    else
        return query2(nod * 2 + 1, mid + 1, dr, a);
}