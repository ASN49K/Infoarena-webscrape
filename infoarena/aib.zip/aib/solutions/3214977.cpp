#include<bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int v[100001], n, m, c, a, b, i, j, st, dr, mij;
long long int suma, s[100001];
int main()
{
    fin>>n>>m;
    fin>>v[1];
    for(i=2; i<=n; i++){fin>>v[i]; v[i]+=v[i-1];}
    for(i=1; i<=m; i++){
        fin>>c;
        if(c==0){
            fin>>a>>b;
            for(j=a; j<=n; j++)v[j]+=b;
        }
        else if(c==1){
            fin>>a>>b;
            fout<<v[b]-v[a-1]<<endl;
        }
        else{
            fin>>a;
            st=1;
            dr=n;
            if(v[st]>a||v[dr]<a)fout<<-1<<endl;
            else if(v[st]==a)fout<<st<<endl;
            else if(v[dr]==a)fout<<dr<<endl;
            else{
            while(st<=dr){
                mij=(st+dr)/2;
                if(v[mij]==a){fout<<mij<<endl; break;}
                else if(v[mij]<a){st=mij+1;}
                else {dr=mij-1;}
            }
        }}
    }
}
