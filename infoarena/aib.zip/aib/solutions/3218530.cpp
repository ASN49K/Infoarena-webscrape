#include <fstream>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");




int n,m,i,v[100005],o,a,b,st,dr,mij,t[100005];
bool ok;
void update(int p,int val)
{
  for ( int i=p; i<=n; i+=(i&(-i)) )
        t[i]+=val;
}

int query(int p)
{
    int sum=0;
    for (int i=p; i>=1; i-=(i&(-i)))
        sum+=t[i];

    return sum;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for (i=1; i<=n; i++)
    {
        int x;
        fin>>x;
        update(i,x);
    }

    for (i=1; i<=m; i++)
    {
        fin>>o;
        if (o==0)
        {
            fin>>a>>b;
            update(a,b);
        }
        if (o==1)
        {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<"\n";
        }
        if (o==2)
        {
            fin>>a;
            st=1; dr=n;
            while (st<=dr)
            {
                mij=(st+dr)/2;
                if (a>query(mij))
                    st=mij+1;
                if (a<query(mij))
                    dr=mij-1;
                if (a==query(mij))
                {ok=1;
                    fout<<mij<<"\n";
                    break;
                }
            }
            if (!ok)
                fout<<-1<<"\n";
        }
    }



    return 0;
}
