#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ifstream fin("aib.in");
ofstream fout("aib.out");
ll i,n,sol,a[100005],p=1,aib[100005],m,op,x,y,st,dr,c,poz,s;
void add(ll x, ll val)
{
    for(int i=x;i<=n;i+=(i&(-i)))
        aib[i]+=val;
}
ll sum(int x)
{
    ll sum=0;
    for(int i=x;i>0;i-=(i&(-i)))
        sum+=aib[i];
    return sum;
}
int main()
{  fin>>n>>m;
   for(i=1;i<=n;i++)
   {
       fin>>a[i];
       add(i,a[i]);
   }
   for(i=1;i<=m;i++)
   {
       fin>>op;
       if(op==0)
       {
           fin>>x>>y;
           add(x,y);
       }
       else
       if(op==1)
       {
           fin>>x>>y;
           fout<<sum(y)-sum(x-1)<<'\n';
       }
       else
       {
           fin>>x;
           st=1;
           dr=n;
           while(st<=dr)
           {
               c=(st+dr)/2;
               s=sum(c);
               if(s>x)
                  dr=c-1;
               else
               if(s<x)
                  st=c+1;
               else
               {
                   poz=c;
                   dr=c-1;
               }
           }
           fout<<poz<<'\n';
       }
   }
    return 0;
}
