#include<bits/stdc++.h>
auto in = std::freopen("aib.in" , "r" , stdin);
auto out = std::freopen("aib.out" , "w" , stdout);
const int NMAX = 100005;
int aint[4 * NMAX];
int n,q,tip,a,b;
#define mid ((st + dr) / 2)
void build(int nod ,int st , int dr){
    if(st == dr){
        std::cin >> aint[nod];
        return;
    }
    build(2*nod,st,mid),build(2*nod+1,mid+1,dr);
    aint[nod] = aint[2*nod] + aint[2*nod+1];
}
// dr L st dr Rst 
int query(int nod , int st ,int dr ,int L ,int R){
    if(L<=st && dr <= R){
        return aint[nod];
    }
    if(dr < L || R < st)return 0;
    return query(2*nod,st,mid,L,R) + query(2*nod+1,mid+1,dr,L,R);
}
void update(int nod , int st ,int dr ,int poz , int val){
    if(st == dr){
        aint[nod]+=val;
        return;
    }
    if(poz<=mid){
        update(2*nod,st,mid,poz,val);
    }else{
        update(2*nod+1,mid+1,dr,poz,val);
    }
    aint[nod] = aint[2*nod] + aint[2*nod+1];
}
int bsearch(int x){
    int st = 1,dr = n;
    while(st <= dr){
        if(query(1,1,n,1,mid) < x){
            st = mid+1;
        }else{
            dr = mid-1;
        }
    }
    if(query(1,1,n,1,st) == x)return st;
    return -1;
}
int main(){
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);
    std::cin >> n >> q;
    build(1,1,n);
    while(q--){
        std::cin >> tip >> a;
        if(tip == 0){
            std::cin >> b;
            update(1,1,n,a,b);
        }
        if(tip == 1){
            std::cin >> b;
            std::cout << query(1,1,n,a,b) << "\n";
        }
        if(tip ==  2){
            std::cout << bsearch(a) << "\n";
        }
    }
    return 0;
}