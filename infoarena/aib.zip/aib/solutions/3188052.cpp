#include <bits/stdc++.h>
using namespace std;

int n, m, v[100001], aib[100001], x, y, a, b;
short ind;

/*const string file = "aib";
ifstream fin (file + ".in");
ofstream fout(file + ".out");
#define cin fin
#define cout fout*/

int useless_bit(int x){
    return (x & (-x));
}

void add(int x, int y){
    for(int i = x; i <= n; i += useless_bit(i))
        aib[i] += y;
}

int sum(int x){
    int rez = 0;
    for(int i = x; i >= 1; i -= useless_bit(i))
        rez += aib[i];
    return rez;
}

int main(){
    cin >> n >> m;
    for(int i = 1; i <= n; i++){
        cin >> v[i];
        add(i, v[i]);
    }
    for(int i = 1; i <= m; i++){
        cin >> ind;
        if(ind == 0){
            cin >> x >> y;
            add(x, y);
        }
        else if(ind == 1){
            cin >> a >> b;
            cout << sum(b) - sum(a - 1) << '\n';
        }
        else {
            int a, s = 0, poz = 0;
            cin >> a;
            for(int b = 17; b >= 0; b--){
                if(poz + (1 << b) <= n && s + aib[poz + (1 << b)] < a){
                    s += aib[poz + (1 << b)];
                    poz += (1 << b);
                }
            }
            if(poz + 1 >  n || sum(poz + 1) != a)
                cout << -1 << '\n';
            else
                cout << poz + 1 << '\n';
        }
    }
    return 0;
}
