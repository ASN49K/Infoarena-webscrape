#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int n,m,a,b,c,aib[100005];
void update(int p, int k)
{
    for(int i=p; i<=n; i+=(i&-i))
        aib[i]+=k;
}

int query(int p)
{
    long long sum=0;
    for(int i=p; i>=1; i-=(i&-i))
        sum+=aib[i];
    return sum;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        cin>>a;
        update(i,a);
    }
    for(int ceva=1; ceva<=m; ceva++)
    {
        cin>>c;
        if(c==0)
        {
            cin>>a>>b;
            update(a,b);
        }
        else if(c==1)
        {
            cin>>a>>b;
            cout<<query(b)-query(a-1)<<"\n";
        }
        else
        {
            cin>>a;
            int ok=0;
            int st=1,dr=n,mij;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                int suma=query(mij);
                if(suma==a)
                {
                    cout<<mij<<"\n";
                    ok=1;
                    break;
                }
                else if(suma>a)
                    dr=mij;
                else
                    st=mij+1;
            }
            if(ok==0)
                cout<<-1<<"\n";
        }
    }
}
