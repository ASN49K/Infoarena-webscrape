#include <iostream>
#include <fstream>

#define NMAX 100002

using namespace std;

ifstream fin ("aib.in");
ofstream fout ("aib.out");

int n, m, tree[NMAX];

void add(int poz, int val)
{
    for (int i = poz; i <= n; i += (i&(-i)))
        tree[i] += val;
}

int sum(int poz)
{
    int rez = 0;
    for (int i = poz; i != 0; i -= (i&(-i)))
        rez += tree[i];

    return rez;
}

int sum_min_poz(int val)
{
    int mask = 1, position = 0;

    while (mask <= n)
        mask = mask << 1;
    mask = mask >> 1;

    for (; mask > 0; mask >>= 1)
    {
        if (position + mask <= n && tree[position+mask] <= val)
        {
            val -= tree[position+mask];
            position += mask;

            if (val == 0) return position;
        }
    }

    return -1;
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x; /// citire sir

        for (int j = i; j <= n; j += (j&(-j))) /// construire arbore initial
            tree[j] += x;
    }

    while (m--)
    {
        int c, a, b;
        fin >> c;
        if (c == 0)
        {
            fin >> a >> b;
            add(a, b);
        }
        if (c == 1)
        {
            fin >> a >>  b;
            fout << sum(b) - sum(a-1) << "\n";
        }
        if (c == 2)
        {
            fin >> a;
            fout << sum_min_poz(a) << "\n";
        }
    }

    return 0;
}
