#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;

ifstream fin ("aib.in");
ofstream fout ("aib.out");

int n, m, rad, len;
vector<int> v;
vector<long long> sum;

void adaugare(int a, int b)
{
    v[a] += b;
    sum[a/rad] += b;
}
long long suma(int a, int b)
{
    long long s = 0;
    int start = a / rad + 1, stop = b / rad;
    if (start-1 == stop)
    {
        for (int i = a; i <= b; i++)
            s += v[i];
        return s;
    }
    for (int i = start; i < stop; i++)
        s += sum[i];
    for (int i = a; i < start*rad; i++)
        s += v[i];
    for (int i = stop*rad; i <= b; i++)
        s += v[i];
    return s;
}
int poz_min(int a)
{
    long long s = 0;
    int i = 0;
    while(s < a && i < sum.size())
    {
        s += sum[i];
        i++;
    }
    if (s == 0) return i * rad;
    if (s == a) return i * rad;
    i--;
    s -= sum[i];

    for (int j = i * rad; j < n; j++)
    {
        s += v[j];
        if (s == a) return j+1;
        if (s > a) return -1;
    }
    return -1;
}
int main()
{
    fin >> n >> m;
    rad = sqrt(n);
    for (int i = 0; i < n; i++)
    {
        int x;
        fin >> x;
        v.push_back(x);
        if (len >= rad || i == 0)
        {
            len = 1;
            sum.push_back(x);
        }
        else
        {
            len++;
            sum[sum.size()-1] += x;
        }
    }
    for (int i = 0; i < m; i++)
    {
        int op, a, b;
        fin >> op >> a;
        if (op == 0)
        {
            fin >> b;
            a -= 1;
            adaugare(a, b);
        }
        if (op == 1)
        {
            fin >> b;
            a -= 1; b -= 1;
            fout << suma(a, b) << "\n";
        }
        if (op == 2)
        {
            fout << poz_min(a) << "\n";
        }
    }

    return 0;
}
