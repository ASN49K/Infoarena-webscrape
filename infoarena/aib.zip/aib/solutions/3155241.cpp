#include <fstream>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int nr,poz,n,m,i,x,a,b,ch,st,dr,mij,v[100001],aib[100001];
long long s,sum;
void update (int i)
{
    for (; i<=n; i+=(i&-i))
        aib[i]+=x;
}
int query (int i)
{
    s=0;
    for (; i>0; i-=(i&-i))
        s=s+aib[i];
    return s;
}
int main()
{
    fin>>n>>m;
    for (i=1; i<=n; i++)
    {
        fin>>x;
        update (i);
    }
    for (i=1; i<=m; i++)
    {
        fin>>ch;
        if (ch==0)
        {
            fin>>a>>b;
            x=b;
            update (a);
        }
        if (ch==1)
        {
            fin>>a>>b;
            fout<<query (b)-query (a-1)<<"\n";
        }
        if (ch==2)
        {
            fin>>sum;
            b=0;
            while ((1<<b)<=sum)
                b++;
            b--;
            poz=s=0;
            for (; b>=0; b--)
            {
                nr=(1<<b);
                if (poz+nr<=n&&s+aib[poz+nr]<=sum)
                {
                    s+=aib[poz+nr];
                    poz+=nr;
                }
            }
            if (s!=sum)
                poz=-1;
            fout<<poz<<"\n";
        }
    }
    return 0;
}
