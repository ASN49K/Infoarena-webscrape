#include <bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int w[100001], n, m, x, y, z;
int v[250001];
void add(int poz, int val, int st, int dr, int k){
    if(st==dr) v[k] += val;
    else {
        int m = (st+dr)/2;
        if(m >= poz) add(poz, val, st, m, k*2);
        if(m < poz) add(poz, val, m+1, dr, k*2+1);
        v[k] = v[k*2]+v[k*2+1];
    }
}

int sum(int a, int b, int st, int dr, int k){
    if(a<=st && dr<=b) return v[k];
    int m=(st+dr)/2;
    long long temp=0;
    if(m >= a) temp += sum(a, b, st, m, k*2);
    if(m < b) temp += sum(a, b, m+1, dr, k*2+1);
    return temp;
}

int check(long long k){
    long long s=0;
    for(int i=1; i<=n; i++){
        s+=w[i];
        if(s == k) return i;
        else if(s>k) return -1;
    }
}

int main(){
    fin>>n>>m;
    for(int i=1; i<=n; i++){
        fin>>w[i];
        add(i, w[i], 1, n, 1);
    }
    for(int i=1; i<=m; i++){
        fin>>x;
        if(!x){
            fin>>y>>z;
            add(y, z, 1, n, 1);
        }
        else if(x==1){
            fin>>y>>z;
            fout<<sum(y, z, 1, n, 1)<<"\n";
        }
        else{
            fin>>y;
            fout<<check(y)<<"\n";
        }
    }
}
