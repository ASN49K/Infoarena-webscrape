#include <fstream>
using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
#define ll long long
ll v[100001];
int n;
ll tree[100001];
ll ask(int poz){
    ll rez=0;
    while(poz){
        rez+=tree[poz];
        poz-=poz&(-poz);
    }
    return rez;
}
void add(int poz,ll val){
    while(poz<=n){
        tree[poz]+=val;
        poz+=poz&(-poz);
    }
}
ll query(int L,int R){
    if(L>R)
        return 0;
    else
        return ask(R)-ask(L-1);
}
int main(){
    int m;
    f>>n>>m;
    for(int i=1;i<=n;++i){
        f>>v[i];
        add(i,v[i]);
    }
    int cer;
    ll a,b;
    while(m--){
        f>>cer>>a;
        if(cer==0){
            f>>b;
            v[a]+=b;
            add(a,b);
        }
        if(cer==1){
            f>>b;
            g<<query(a,b)<<'\n';
        }
        if(cer==2){
            if(ask(1)==a)
                g<<1<<'\n';
            else{
                bool ok=true;
                int k=2;
                ll r=0;
                do{
                    r=ask(k);
                    if(r==a)
                        ok=false;
                    k++;
                }while(ok&&r<=a);
                if(ok)
                    g<<-1<<'\n';
                else
                    g<<k-1<<'\n';
            }
        }
    }
    return 0;
}
