#include <stdlib.h>
#include <stdio.h>

void BuildFenwickTree(unsigned int *FenwickTree,unsigned int sizeTree,unsigned int *arr){
    FenwickTree[0]=0;
    unsigned int curr_index,aux_ind;
    for(unsigned int i=1;i<sizeTree;i++){
        curr_index=i;
        while(curr_index<sizeTree){
            FenwickTree[curr_index]+=arr[i-1];
            aux_ind=~curr_index;
            aux_ind+=1;
            aux_ind=aux_ind&curr_index;
            curr_index+=aux_ind;
        }
    }
}
unsigned int Query(unsigned int *FenwickTree,unsigned int sizeTree,unsigned int to){

    unsigned int curr_index=to,aux_ind;
    unsigned int Sum=0;
    while(curr_index>0){
        Sum+=FenwickTree[curr_index];
        aux_ind=~curr_index;
        aux_ind+=1;
        aux_ind=aux_ind&curr_index;
        curr_index-=aux_ind;
    }
    return Sum;
}
void Update(unsigned int *FenwickTree,unsigned int *arr,unsigned int sizeTree,unsigned int pos,unsigned int val){
    arr[pos]+=val;
    unsigned int curr_index=pos+1,aux_ind;
    while(curr_index<sizeTree){
        FenwickTree[curr_index]+=val;
        aux_ind=~curr_index;
        aux_ind+=1;
        aux_ind=aux_ind&curr_index;
        curr_index+=aux_ind;
    }
}
int SearchPrefix(unsigned int *Fenwick,unsigned int sizeTree,unsigned int sum){

    int low=0,high=sizeTree-1,mid,rez;
    int ind=-1;
    while(low<=high){

        mid=low+(high-low)/2;
        rez=Query(Fenwick,sizeTree,mid+1);
        if(rez==sum)
            ind=(int)mid;

        if(rez<sum) low=mid+1;
        else high=mid-1;
    }
    return ind+1;
}
int main() {

    freopen("aib.in","r",stdin);
    freopen("aib.out","w",stdout);
    unsigned int N,M,op,a,b;
    scanf("%u",&N);
    scanf("%u",&M);
    unsigned int *Fenwickarr=(unsigned int*) malloc(sizeof(unsigned int)*(N+1));
    unsigned int *arr=(unsigned int*) malloc(sizeof(unsigned int)*N);

    Fenwickarr[N]=0;
    for(unsigned int i=0;i<N;i++) {
        scanf("%u", &arr[i]);
        Fenwickarr[i]=0;
    }
    BuildFenwickTree(Fenwickarr,N+1,arr);
   for(unsigned int q=0;q<M;q++){
       scanf("%u",&op);
       scanf("%u",&a);
       if(op!=2) {
           scanf("%u",&b);
           if(op==0)Update(Fenwickarr, arr, N + 1, a - 1, b);
           else printf("%u\n", Query(Fenwickarr, N + 1, b) - Query(Fenwickarr, N + 1, a - 1));
       }
        else printf("%d\n", SearchPrefix(Fenwickarr,N+1,a));

   }
//    for(unsigned int i=0;i<=N;i++)
//        printf("%u ",Fenwickarr[i]);

    free(Fenwickarr);
    free(arr);
    return 0;
}
