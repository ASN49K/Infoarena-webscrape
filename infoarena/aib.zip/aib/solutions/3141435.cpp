#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout ("aib.out");

const int dim = 4e5 + 5;

int seg_tree[dim] , v[dim / 4] , n , q;

void Build (int node , int l , int r)
{
    if(l == r)
        seg_tree[node] = v[l];
    else
        {
            int m = (l + r) / 2;
            Build(2 * node , l , m);
            Build(2 * node + 1 , m + 1 , r);

            seg_tree[node] = seg_tree[2 * node] + seg_tree[2 * node + 1];
        }
}

void Increment(int node , int l , int r , int nod , int inc)
{
    if(l == r)
        seg_tree[node] += inc;
    else
        {
            int m = (l + r) / 2;
            if(nod <= m)
                Increment(2 * node , l , m , nod , inc);
            else
                Increment(2 * node + 1 , m + 1 , r , nod , inc);

            seg_tree[node] = seg_tree[2 * node] + seg_tree[2 * node + 1];
        }
}

int SumInt(int node , int l , int r , int lQ , int rQ)
{
    if(l >= lQ && r <= rQ)
        return seg_tree[node];
    else
        {
            int m = (l + r) / 2;
            if(rQ <= m)
                return SumInt(2 * node , l , m , lQ , rQ);
            else if(lQ >= m + 1)
                return SumInt(2 * node + 1 , m + 1 , r , lQ , rQ);
            else
                return SumInt(2 * node , l , m , lQ , rQ) + SumInt(2 * node + 1 , m + 1 , r , lQ , rQ);
        }
}

int IndS (int node , int l , int r , int sum)
{
    if(seg_tree[node] == sum)
        return r;
    else
        {
            int m = (l + r) / 2;
            if(seg_tree[2 * node] >= sum)
                return IndS(2 * node , l , m , sum);
            else
                return IndS(2 * node + 1 , m + 1 , r , sum - seg_tree[2 * node]);
        }
}

int main()
{
    fin >> n >> q;
    for(int i = 1 ; i <= n ; ++i)
        fin >> v[i];
    Build(1 , 1 , n);
    while(q--)
        {
            int op;
            fin >> op;
            if(op == 0)
                {
                    int nod , inc;
                    fin >> nod >> inc;
                    Increment(1 , 1 , n , nod , inc);
                }
            else if(op == 1)
                {
                    int l , r;
                    fin >> l >> r;
                    fout << SumInt(1 , 1 , n , l , r) << '\n';
                }
            else
                {
                    int sum;
                    fin >> sum;
                    fout << IndS(1 , 1 , n , sum) << '\n';
                }
        }
}