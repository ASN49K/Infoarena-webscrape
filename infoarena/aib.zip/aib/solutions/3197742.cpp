#include <fstream>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int aib[100001];
int n, q;
void upd(int poz, int val)
{
    for(int i=poz; i <= n; i+=(i&-i))
        aib[i]+=val;
}
int query(int poz)
{
    int a=0;
    for(int i=poz; i > 0; i-=(i&-i))
        a+=aib[i];
    return a;
}
int cautbin(int val, int st, int dr)
{
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        int c=query(mij);
        if(c>val)
            dr=mij-1;
        else if(c<val)
            st=mij+1;
        else
            return mij;
    }
    return -1;
}
int main()
{
    int x, task, y;
    fin >> n >> q;
    for(int i=1; i <= n; i++)
    {
        fin >> x;
        upd(i, x);
    }
    while(q--)
    {
        fin >> task;
        if(task==0)
        {
            fin >> x >> y;
            upd(x, y);
        }
        else if(task==1)
        {
            fin >> x >> y;
            fout << query(y)-query(x-1) << '\n';
        }
        else
        {
            fin >> x;
            fout << cautbin(x, 1, n) << '\n';
        }
    }
    return 0;
}
