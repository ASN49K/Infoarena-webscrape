#include <bits/stdc++.h>
using namespace std;

int aib[100001], v[100001];
int presum(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=aib[i];
        i-=(i&-i);
    }
    return sum;
}
int query(int i,int j)
{
    return presum(j)-presum(i-1);
}
void update(int i,int val)
{
    while(i<=n){
        aib[i]+=val;
        i+=(i&-i);
    }
}
ifstream cin("aib.in");
ofstream cout("aib.out");
int main()
{
    int n, m, c, a, b;
    cin >> n >> m;
    for(int i=1; i<=n; i++)
    {
       cin >> v[i];
       update(i, v[i]);
    }
    for(int i=1; i<=m; i++)
    {

        cin >> c >> a;
        if(c==0)
        {
            cin >> b;
            update(a, b);
        }
        else if(c==1)
        {
            cin >> b;
            cout << query(a, b)<< '\n';
        }
        else
        {
            int st,dr;
            st=1;
            dr=n;
            while(dr>st)
            {
                int mij=(st+dr)/2;
                int a=presum(mij);
                if(a>=a)
                    dr=mij;
                else
                    st=mij+1;
            }
            if(presum(dr)==a)
                cout<< dr << '\n';
            else
                cout << "-1" << "\n";
        }
    }
    return 0;
}
