#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int N, Q, x, y, type, mid;

vector<int> BIT;
void Update(int i, int val){
    while(i <= N){
        BIT[i] += val;
        i += (i & -i);
    }
}
int Querry(int i){
    int sum = 0;
    while(i > 0){
        sum += BIT[i];
        i -= (i & -i);
    }
    return sum;
}
int Range_Querry(int i, int j){
    return Querry(j) - Querry(i - 1);
}
int main()
{
    
    fin >> N >> Q;
    BIT.resize(N + 1, 0);
    for(int i = 1; i <= N; i ++)
    {
        fin >> x;
        Update(i, x);
    }
    for(int i = 1; i <= Q; i ++)
    {
        fin >> type;
        if(type == 0){

            fin >> x >> y;
            Update(x, y);
        }
        else if(type == 1){
            fin >> x >> y;
            for(int i = x; i <= y; i ++)
                cout << Querry(i) << ' ';
            fout << Range_Querry(x, y) << '\n';
            cout << '\n';
        }
        else{
            fin >> x;
            int l = 1, r = N;
            while(l < r){
                mid = (l + r) / 2;
                if(x <= Querry(mid))
                    r = mid;
                else
                    l = mid + 1;
            }
            fout << l << '\n';
        }
    }
    return 0;
}