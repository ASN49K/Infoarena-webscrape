#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,m,a,b,v[100005],x;
int lsb(int k)
{
    return k&(-k);
}
void update(int x,int q)
{
    for(int i=x;i<=n;i+=lsb(i))
        v[i]+=q;
}
int query(int pos)
{
    int s=0;
    for(int i=pos;i>=1;i-=lsb(i))
        s+=v[i];
    return s;
}
int cb(int nr)
{
    int r=0,p=1,tot=0;
    p<<=17;
    while(p)
    {
        if(r+p<=n&&tot+query(r+p)<=nr)
        {
            tot+=query(r+p);
            r+=p;
        }
        if(tot==nr)
            return r;
        p>>=1;
    }
    return -1;
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        fin>>x;
        update(i,x);
    }
    for(int i=1;i<=m;i++)
    {
        fin>>x;
        if(x==0)
        {
            fin>>a>>b;
            update(a,b);
        }
        if(x==1)
        {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<'\n';
        }
        if(x==2)
        {
            fin>>a;
            fout<<cb(a)<<'\n';
        }
    }
    return 0;
}
