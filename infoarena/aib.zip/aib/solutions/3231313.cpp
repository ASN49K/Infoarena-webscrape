#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

struct AIB {
    std::vector<int> bit;
    int n;

    AIB() = default;

    explicit AIB(int n) {
        this->n = n;
        bit.assign(n, 0);
    }
    explicit AIB(std::vector<int> &a) : AIB(a.size()) {
        for(int i = 0; i < a.size(); i++) {
            bit[i] += a[i];
            int r = i | (i + 1);
            if(r < n) bit[r] += bit[i];
        }
    }

    int sum(int r) {
        int res = 0;
        while(r >= 0) {
            res += bit[r];

            r = (r&(r+1)) - 1;
        }

        return res;
    }

    int sum(int l, int r) {
        return sum(r) - sum(l-1);
    }

    void update(int idx, int val) {
        while(idx < this->n) {
            bit[idx] += val;
            idx = (idx | (idx + 1));
        }
    }

    int pozmin(int s) {
        int k = -1;
        int left = 0, right = this->n - 1;

        while(left <= right) {
            int mid = left + (right - left) / 2;

            int suma = sum(mid);

            if(suma >= s) {
                right = mid - 1;

                if(suma == s) k = mid;
            }
            else {
                left = mid + 1;
            }
        }

        return k;
    }
};

//#define TEST
const std::string file = "aib";

int main() {
#ifdef TEST
    std::ifstream fin("../test.in");
    std::ofstream fout("../output.out");
#endif

#ifndef TEST
    std::ifstream fin(file + ".in");
    std::ofstream fout(file + ".out");
#endif

    int n, m;

    fin >> n >> m;

    std::vector<int> v(n);

    for(int i = 0; i < n; i++) {
        fin >> v[i];
    }

    AIB aib{v};

    for(int i = 0; i < m; i++) {
        int op;

        fin >> op;

        if(op == 0) {
            int a, b;

            fin >> a >> b;

            aib.update(a - 1, b);
        }
        else if(op == 1) {
            int a, b;
            fin >> a >> b;
            fout << aib.sum(a - 1, b - 1) << '\n';
        }
        else {
            int a;
            fin >> a;

            int k = aib.pozmin(a);

            if(k == -1) fout << k << '\n';
            else fout << k + 1 << '\n';
        }
    }

    fin.close();
    fout.close();

    return 0;
}