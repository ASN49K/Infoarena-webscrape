/*
 * author [dubit]
*/
#include <bits/stdc++.h>

using namespace std;

int N,M;

struct Fenwick{
    int n,tree[100005];

    Fenwick(int sz)
    {
        n=sz;
        for(int i=0;i<=n;i++)
            tree[i]=0;
    }

    void update(int idx,int  val)
    {
        for(;idx<=n;idx+=idx&-idx)
            tree[idx]+=val;
    }

    int query(int idx)
    {
        int sum=0;
        for(;idx>=1;idx-=idx&-idx)
            sum+=tree[idx];
        return sum;
    }

    int queryinterval(int a,int b)
    {
        return query(b)-query(a-1);
    }

};

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("aib.in","r",stdin);
    freopen("aib.out","w",stdout);

    cin>>N>>M;
    Fenwick v(N);

    for(int i=1;i<=N;i++)
    {
        int x;
        cin>>x;
        v.update(i,x);
    }

    while(M--)
    {
        int tip;
        cin>>tip;
        if(tip==0)
        {
            int a,b;
            cin>>a>>b;
            v.update(a,b);
        }
        else
        if(tip==1)
        {
            int a,b;
            cin>>a>>b;
            cout<<v.queryinterval(a,b)<<'\n';
        }
        else
        {
            int a,low=1,high=N,mid,k=-1;
            cin>>a;

            while(low<=high)
            {
                mid=low+(high-low)/2;
                int qry=v.query(mid);

                if(qry==a)
                    k=mid,high=mid-1;
                else if(qry>a)
                {
                    high=mid-1;
                }
                else
                    low=mid+1;
            }

            cout<<k<<'\n';
        }
    }

    return 0;
}
