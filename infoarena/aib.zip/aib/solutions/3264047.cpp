#include <iostream>
#include <fstream>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

const int nMax = 1e5 + 5;

int n, q;
int a[nMax], aib[nMax];

void add(int x,int val)
{
    for (int i = x;i <= n;i += i&(-i))aib[i] += val;
}

int sum(int x)
{
    int rez = 0;
    for (int i = x;i >= 1;i -= i&(-i))rez += aib[i];
    return rez;
}

int cb(int val)
{
    int st = 1,dr = n;
    int mij;
    int rez = nMax;
    while(st <= dr){
        mij = (st + dr) / 2;
        int suma = sum(mij);
        if (suma == val)rez = min(mij,rez),dr = mij - 1;
        else if (suma > val)dr = mij - 1;
        else st = mij + 1;
    }
    return rez;
}

int main()
{
    f >> n >> q;
    for (int i = 1;i <= n;i++)f >> a[i],add(i,a[i]);
    for (int i = 1;i <= q;i++){
        int cerinta, x, y;
        f >> cerinta >> x;
        if (cerinta == 0)f >> y,add(x,y);
        else if (cerinta == 1)f >> y,g << sum(y) - sum(x-1) << '\n';
        else g << cb(x) << '\n';
    }
}