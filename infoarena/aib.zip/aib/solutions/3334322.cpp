#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <stack>
#include <algorithm>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int n,m;
vector<int>aib;
int lsb(int x) {
    return (x&(-x));
}

int query ( int idx ) {
    int sum = 0;
    for (; idx > 0; idx -= ( idx & - idx ) ) {
        sum += aib [ idx ];
    }
    return sum ;
}

void update ( int idx , int val ) {
    for (; idx <= n ; idx += ( idx & - idx ) ) {
        aib [ idx ] += val ;
    }
}
int c2(int val) {
    int ans=0;
    for (int p=15; p>=0; --p) {
        if (aib[ans+2]<=val) {
            ans+=(1<<p);
            val-=aib[ans];
        }
    }
    return ans;
}
void solve() {
    fin>>n>>m;
    aib=vector<int>(n+1,0);
    int x;
    for (int i=1; i<=n; i++) {
        fin>>x;
        update(i,x);
    }
    int y,z;
    for (int i=1; i<=m; i++) {
        fin>>x;
        if (x==0) {
            fin>>y>>z;
            update(y,z);
        }
        else if (x==1) {
            fin>>y>>z;
            if (y>z) {
                swap(y,z);
            }
            cout<<query(y)-query(z-1)<<'\n';
        }
        else if (x==2) {
            fin>>y;
            cout<<c2(y)<<'\n';
        }
    }
}

int main(){
    solve();
    return 0;
}