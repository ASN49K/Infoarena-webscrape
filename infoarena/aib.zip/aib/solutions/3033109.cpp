/// [A][M][C][B][N] ///
#include <bits/stdc++.h>
const char nl = '\n';
const char sp = ' ';
const int mod = 666013;
const int inf = 0x3f3f3f3f;
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

const int nmax = 1e5;
int n, q;
int v[nmax + 1]{ 0 };
int t[nmax + 1]{ 0 };

void build(int v[], int n) {
    for (int i = 1; i <= n; ++i) {
        t[i] += v[i];
        if (i + (i & (-i)) <= n) {
            t[i + (i & (-i))] += t[i];
        }
    }
}

void add(int i, int x) {
    for (; i <= n; i += i & (-i)) {
        t[i] += x;
    }
}

int get(int i) {
    int sum = 0;
    for (; i > 0; i -= i & (-i)) {
        sum += t[i];
    }
    return sum;
}

int get(int i, int j) {
    return get(j) - get(i - 1);
}

// primul k cu get(k) <= sum
int search(int x) {
    int i = 0, k = 1;
    while ((k << 1) <= n) {
        k <<= 1;
    }
    for (; k; k >>= 1) {
        if (i + k <= n) {
            if (t[i + k] <= x) {
                x -= t[i + k];
                i += k;
            }
            if (x == 0) {
                return i;
            }
        }
    }
    return -1;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n >> q;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
    }
    build(v, n);
    while (q--) {
        int c, a, b;
        fin >> c >> a;
        if (c != 2) {
            fin >> b;
        }
        if (c == 0) {
            add(a, b);
        }
        else if (c == 1) {
            fout << get(a, b) << nl;
        }
        else {
            fout << search(a) << nl;
        }
    }
}