#include <fstream>
#include <vector>

using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n;
vector <int> bit(100000+1, 0);
void update(int i, int val)
{
    while(i<=n)
    {
        bit[i]+=val;
        i+=(i&-i);
    }
}
int prefixSum(int i)
{
    int sum;
    sum=0;
    while(i>0)
    {
        sum+=bit[i];
        i-=(i&-i);
    }
    return sum;
}
int rangeSum(int i, int j)
{ 
    return prefixSum(j)-prefixSum(i-1);
}
int main()
{
    int m;
    cin>>n>>m;
    int i, nr;
    for(i=1; i<=n; i++){
        cin>>nr;
        update(i, nr);
    }
    int c, a, b, k, poz;
    while(m>0)
    {
        cin>>c;
        if(c==0)
        {
            cin>>a>>b;
            update(a, b);
        }
        else if(c==1)
        {
            cin>>a>>b;
            cout<<rangeSum(a, b)<<'\n';
        }
        else if(c==2)
        {
            cin>>a;
            for(i=1; i<=n; i++)
            {
                if(rangeSum(1, i)==a)
                {
                    poz=i;
                    i=n;
                }
            }
            cout<<poz<<'\n';
        }
        m--;
    }
    return 0;
}