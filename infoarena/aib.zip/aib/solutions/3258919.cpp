#include <fstream>
#define nmax 100001
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n,m,x,y,t,aib[nmax];
void update(int p,int val){
    for(;p<=n;p+=(-p)&p)
        aib[p]+=val;
}
int query(int p){
    int s=0;
    for(;p>0;p-=(-p)&p)
        s+=aib[p];
    return s;
}
int cb(int k){
    int st=1,dr=n,p=-1;
    while(st<=dr){
        int mid=(st+dr)/2,s=query(mid);
        if(s==k)
            p=mid,dr=mid-1;
        else if(s>k)
            dr=mid-1;
        else
            st=mid+1;
    }
    return p;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>x;
        update(i,x);
    }
    while(m--){
        cin>>t;
        if(t==0){
            cin>>x>>y;
            update(x,y);
        }else if(t==1){
            cin>>x>>y;
            cout<<query(y)-query(x-1)<<'\n';
        }else{
            cin>>x;
            cout<<cb(x)<<'\n';
        }
    }
    return 0;
}
