#include <fstream>
using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int n,arr[100005],aib[100005],sum;

void update(int poz,int val)
{
    while (poz<=n)
    {
        aib[poz]+=val;
        poz+=poz&(-poz);
    }
}

void query(int poz)
{
    while (poz)
    {
        sum+=aib[poz];
        poz-=poz&(-poz);
    }
}

int main()
{
    int q;
    cin>>n>>q;
    for (int i=1; i<=n; i++)
    {
        int x;
        cin>>x;
        update(i,x);
    }
    for (int i=1; i<=q; i++)
    {
        int cer,a,b;
        cin>>cer>>a;
        if (cer==0)
        {
            cin>>b;
            update(a,b);
        }
        else if (cer==1)
        {
            cin>>b;
            sum=0;
            query(b);
            int ls=sum;
            sum=0;
            query(a-1);
            cout<<ls-sum<<"\n";
        }
        else
        {
            int s=1,r=n+1;
            while (s<r)
            {
                int mid=(s+r)/2;
                sum=0;
                query(mid);
                if (sum<a) s=mid+1;
                else r=mid;
            }
            sum=0;
            query(s);
            if (s>n&&sum>a) cout<<"-1\n";
            else cout<<s<<"\n";
        }
    }
}
