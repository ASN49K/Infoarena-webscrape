#include <fstream>
#include <cmath>

using namespace std;

const int Nmax = 100005;

int n, v[Nmax], aib[Nmax];

int lsb(int x){
    return (x & (-x));
}

void update(int poz, int val){
    for(int i = poz; i <= n; i += lsb(i)){
        aib[i] += val;
    }
}

int query(int poz){
    int sum = 0;

    for(int i = poz; i > 0; i -= lsb(i)){
        sum += aib[i];
    }

    return sum;
}

int query2(int val, int pw, int sol, int sum){
    if(pw == -1){
        return -1;
    }

    if(sum + aib[sol + (1 << pw)] == val){
        return (sol + (1 << pw));
    }

    if(1LL * sum + aib[sol + (1 << pw)] > val){
        return query2(val, pw - 1, sol, sum);
    }
    else{
        sum += aib[sol + (1 << pw)];
        sol += (1 << pw);
        return query2(val, pw - 1, sol, sum);
    }
}

int main(){
    ifstream fin("aib.in");
    ofstream fout("aib.out");

    int m, a, b, type, x;

    fin >> n >> m;

    x = log2(n);

    for(int i = 1; i <= n; i++){
        fin >> v[i];
        update(i, v[i]);
    }

    while(m--){
        fin >> type;

        if(type == 0){
            fin >> a >> b;
            v[a] += b;
            update(a, b);
        }
        else if(type == 1){
            fin >> a >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else{
            fin >> a;
            fout << query2(a, x, 0, 0) << '\n';
        }
    }


    return 0;
}
