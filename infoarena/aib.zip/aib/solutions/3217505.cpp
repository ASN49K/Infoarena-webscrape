#include <iostream>
#include<fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, Q;
long long v[200008];
int tip;
long long a,b;

void update(int poz, long long val) {
    for (int i = poz; i<=n; i+= (i&-i)) { ///adun ultima putere a lui 2
        v[i] += val;
    }
}

long long query(int st, int dr) {

    long long ans1 = 0, ans2 = 0;
    for (int i = st-1; i>=1; i-= (i&-i)) { ///scad ultima putere a lui 2
        ans1 += v[i];
    }
    for (int i = dr; i>=1; i-= (i&-i)) { ///scad ultima putere a lui 2
        ans2 += v[i];
    }
    return ans2 - ans1;
}

int caut_bin(long long val)
{
    int st=0,dr=n+1,mij;
    long long ras=-1;
    while(dr-st>1)
    {
        mij=(st+dr)/2;
        long long aux=query(0,mij);
        if(aux==val)
        {
            ras=mij;
            break;
        }
        else if(aux>val)
            dr=mij;
        else
            st=mij;
    }
    return ras;
}

int main()
{
    fin >> n >> Q;
    for (int i = 1; i<=n; i++) {
        fin >> a;
        update(i,a);
    }

    while (Q--) {

        fin >> tip;

        if (tip == 0) {
            fin >> a >> b;
            update(a,b);
        } else if (tip == 1) {
            fin >> a >> b;
            fout << query(a,b) << "\n";
        } else {
            fin >> a;
            fout << caut_bin(a) << "\n";
        }

    }

    return 0;
}
