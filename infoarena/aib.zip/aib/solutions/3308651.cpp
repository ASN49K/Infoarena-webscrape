#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int const lmax=1e5+7;
int const aib_size=lmax+7;///nu mai am *4
int aib[aib_size];
int v[aib_size];
int n,m;
void update(int ind, int val)
{
    for(int i=ind;i<=n;i+=(i&-i))
    {
        ///suntem in nodul i
        aib[i]+=val;
    }
    v[ind]+=val;
}
int query(int ind)
{
    int s=0;
    for(int i=ind;i>0;i-=(i&-i))
    {
        ///suntem in nodul i
        s+=aib[i];
    }
    return s;
}
int binsearch(int val)
{
    int ind=0, sum=0;
    int interval=1<<((int)log2(n));
    while(interval)
    {
        if(ind+interval<=n and aib[ind+interval]+sum<val)
        {
            sum+=aib[ind+interval];
            ind+=interval;
        }
        interval/=2;
    }
    if(sum+v[ind+1]==val)return ind+1;
    else return -1;

}

int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin>>x;
        update(i,x);
    }
    for(int i=0;i<m;i++)
    {
        int x,y;
        fin>>x>>y;
        if(x==0)
        {
            int z;
            fin>>z;
            update(y,z);
        }
        else if(x==1)
        {
            int z;
            fin>>z;
            fout<<query(z)-query(y-1)<<"\n";
        }
        else if(x==2)
        {
            fout<<binsearch(y)<<"\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}
