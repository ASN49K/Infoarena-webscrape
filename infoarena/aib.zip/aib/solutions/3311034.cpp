#include <bits/stdc++.h>
using namespace std;

int n, m;
int a[100001];

void update(int poz, int val)
{
	int x = 0;
	while(poz <= n)
	{
		a[poz] += val;
		while(!(poz & (1 << x)))
		{
			x++;
		}
		poz += (1 << x);
		x++;
	}
}

int query(int poz)
{
	int x = 0, s = 0;
	while(poz > 0)
	{
		s += a[poz];
		while(!(poz & (1 << x)))
		{
			x++;
		}
		poz -= (1 << x);
		x++;
	}
	return s;
}

int main()
{
	freopen("aib.in", "r", stdin);
	freopen("aib.out", "w", stdout);
	cin.tie(nullptr)->sync_with_stdio(false);
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
	{
		int x;
		cin >> x;
		update(i, x);
	}
	for(int i = 1; i <= m; i++)
	{
		int c, x, y;
		cin >> c;
		if(c == 0)
		{
			cin >> x >> y;
			update(x, y);
		}
		else if(c == 1)
		{
			cin >> x >> y;
			cout << query(y) - query(x - 1) << "\n";
		}
		else
		{
			cin >> x;
			int s = (1 << (n));
			for(int i = 0; s > 0; s >>= 1)
			{
				if(i + s <= n)
				{
					if(x >= a[i + s])
					{
						i += s;
						x -= a[i];
						if(x == 0)
						{
							cout << i << "\n";
							goto end;
						}
					}
				}
			}
			cout << -1 << "\n";
			end:;
		}
	}
}