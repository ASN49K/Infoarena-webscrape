#include <bits/stdc++.h>
using namespace std;
ifstream in("aib.in");
ofstream out("aib.out");
int n,m,a[100000],t[100000],i,j,l,k,x,y,z,s;

void tree(int k)
{
    int i,p=k&-k;
    for(i=1;i<=p;i++)
        t[k]+=a[(k-p+i)];
}
void suma(int k,int x)
{
    while(k<=n){
        t[k]+=x;
        k+=(k&-k);
    }
}
int sum(int k)
{
    int s=0;
    while(k>=1){
        s+=t[k];
        k-=(k&-k);
    }
    return s;
}
int main()
{
    in>>n>>m;
    for(i=1;i<=n;i++){  
        in>>a[i];
        if(i%2==1)
            t[i]=a[i];
        else
            tree(i);
    }
    for(i=1;i<=n;i++)
        out<<t[i]<<" ";
    out<<endl;
    for(j=1;j<=m;j++){
        in>>x;
        if(x==0){
            in>>y>>z;
            suma(y,z);
        }/*
        else if(x==1){
            in>>y>>z;
            int s1=sum(y),s2=sum(z-1);
            out<<s1-s2<<endl;
        }
        else if(x==2){
            in>>y;
            int st=1,dr=n,mij;
            k=-1;
            while(st<=dr){
                mij=(st+dr)/2;
                if(mij==y)
                    k=mij;
                else if(mij>y)
                    st=mij;
                else
                    dr=mij;
            }
            out<<k<<endl;
        }
    }*/
    }
}