#include <iostream> 
#include <algorithm>
#include <vector>
#include <cstdio>

// not my code

using namespace std;

const int nmax = 3e5;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

int v[nmax + 5];

#pragma once

struct FT {
	vector<ll> s;
	FT(int n) : s(n) {}
	void update(int pos, ll dif) { // a[pos] += dif
		for (; pos < sz(s); pos |= pos + 1) s[pos] += dif;
	}
	ll query(int pos) { // sum of values in [0, pos]
        ++pos;
		ll res = 0;
		for (; pos > 0; pos &= pos - 1) res += s[pos-1];
		return res;
	}
	int lower_bound(ll sum) {// min pos st sum of [0, pos] >= sum
		// Returns n if no sum is >= sum, or -1 if empty sum is.
		if (sum <= 0) return -1;
		int pos = 0;
		for (int pw = 1 << 25; pw; pw >>= 1) {
			if (pos + pw <= sz(s) && s[pos + pw-1] < sum)
				pos += pw, sum -= s[pos-1];
		}
		return pos;
	}
};

int main()
{
    freopen("aib.in","r",stdin);
    freopen("aib.out","w",stdout);
    int n, m;
    cin>>n>>m;
    FT aib(n + 1);
    for(int i=1;i<=n;i++) {
        cin>>v[i];
        aib.update(i, v[i]);
    }
    for(int i=1;i<=m;i++) {
        int tip;
        cin>>tip;
        if(tip == 0) {
            int poz, val;
            cin>>poz>>val;
            aib.update(poz, val);
        }
        else if(tip == 1) {
            int st, dr;
            cin>>st>>dr;
            cout<<aib.query(dr) - aib.query(st - 1)<<'\n';
        }
        else if(tip == 2) {
            int val;
            cin>>val;
            cout<<aib.lower_bound(val)<<'\n';
        }
    }
    return 0;
}