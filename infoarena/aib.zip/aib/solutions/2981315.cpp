#include <fstream>
#define N 1002
std::ifstream fin("aib.in");
std::ofstream fout("aib.out");
int Tree[N], n;
void update(int pos, int element){
    while(pos <= n){
        Tree[pos] += element;
        pos += (pos & -pos);
    }
}
int query(int pos){
    int sum = 0;
    while(pos > 0){
        sum += Tree[pos];
        pos -= (pos & -pos);
    }
    return sum;
}
int main(){
    //int n;
    fin >> n;
    for(int i=1; i<=n; i++){
        int element;
        fin >> element;
        update(i, element);
    }
    fout << query(4);
}