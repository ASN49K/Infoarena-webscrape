#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream input("aib.in");
ofstream output("aib.out");

void update_BITree(vector<int> &tree, int N, int index, int value)
{
    while(index <= N){
        tree[index] += value;
        index += (index & (-index));
    }
}


void construct_BITree(vector<int> &tree, vector<int> &numbers, int N)
{
    for(int i = 1; i <= N; i++){
        update_BITree(tree, N, i, numbers[i]);
    }
}

int sum_BITree(vector<int> &tree, int index)
{
    int sol = 0;
    while(index > 0){
        sol += tree[index];
        index -= (index & (-index));
    }
    return sol;
}

int sum_BITree(vector<int> &tree, int index1, int index2)
{
    return (sum_BITree(tree, index2) - sum_BITree(tree, index1 - 1));
}

int main()
{
    int N, M;
    input >> N >> M;
    vector<int> numbers(N);

    for(int i = 1; i <= N; i++){
        input >> numbers[i];
    }

    vector<int> tree(N+1, 0);

    construct_BITree(tree, numbers, N);

    for(int operation = 0; operation < M; operation++){

        int op, a, b;
        input >> op;

        if(op == 0){
            input >> a >> b;
            numbers[a] += b;
            update_BITree(tree, N, a, b);
        }

        else if(op == 1){
            input >> a >> b;
            output << sum_BITree(tree, a, b) << endl;

        }

        else{
            input >> a;
            int left = 1, right = N;
            while(left != right){
                int mid = (left + right)/2;

                if(sum_BITree(tree, 1, mid) < a){
                    left = mid+1;
                }
                else{
                    right = mid;
                }
            }
            if(sum_BITree(tree, 1, left) == a){
                output << left << endl;
            }
            else{
                output << -1 << endl;
            }

        }
    }
    return 0;
}
