#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
vector<ll> a, aib;
int n,m;
void add(int i, int v){
    while(i < (int)aib.size()){
        aib[i] += v;
        i += i&(-i);
    }
}
ll sum(int to){
    ll s = 0;
    while(to > 0){
        s += aib[to];
        to -= to&(-to);
    }
    return s;
}
int main(){
    fin >> n >> m;
    a.resize(n+1);
    aib.resize(n+1);
    for(int i = 1; i<=n; i++){
        fin >> a[i];
    }
    for(int i = 1; i<=n; i++){
        add(i, a[i]);
    }
    while(m--){
        int c;
        fin >> c;
        if(c == 0){
            int a,b;
            fin >> a >> b;
            add(a, b);
        }
        else if(c == 1){
            ll a,b;
            fin >> a >> b;
            fout << sum(b)- sum(a-1) << '\n';
        }
        else if(c == 2){
            ll a;
            fin >> a;
            int l = 0, r = n+1, poz = -1;
            while(l <= r){
                int mid = l+(r-l)/2;
                ll midsum = sum(mid);
                if(midsum < a){
                    l = mid+1;
                }
                else if(midsum == a){
                    poz = mid;
                    r = mid-1;
                }
                else r = mid-1;
            }
            fout << poz << '\n';
        }
    }
    
    return 0;
}