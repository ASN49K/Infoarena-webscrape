#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int v[100001], n, q;
int aib[100001];

void update(int pos, int val)
{
    for (int i = pos; i <= n; i += (i & (-i)))
        aib[i] += val;
}

long long query(int pos)
{
    long long rez = 0;
    for (int i = pos; i >= 1; i -= (i & (-i)))
        rez += aib[i];
    return rez;
}

long long query(int l, int r)
{
    return query(r) - query(l - 1);
}

int cb(int val)
{
    int l = 1, r = n, mid;
    while (l <= r)
    {
        mid = (l + r) / 2;
        if (query(mid) >= val)
            r = mid - 1;
        else
            l = mid + 1;
    }

    if (query(l) == val)
        return l;
    return -1;
}

int main()
{
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        fin >> v[i];
        update(i, v[i]);
    }

    for (int i = 1; i <= q; i++)
    {
        int t;
        fin >> t;
        if (t == 0)
        {
            int pos, b;
            fin >> pos >> b;
            update(pos, b);
        }
        if (t == 1)
        {
            int a, b;
            fin >> a >> b;
            fout << query(a, b) << '\n';
        }
        if (t == 2)
        {
            int a;
            fin >> a;
            fout << cb(a) << '\n';
        }
    }
}
