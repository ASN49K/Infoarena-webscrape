#include <fstream>
#include <cmath>
using namespace std;
ifstream in("aib.in");
ofstream out("aib.out");
int n, m, cerinta, a, b, i, j, v[100010];
int aib[100010];
int query(int k)
{
    int sum = 0;
    for (int i = k; i >= 1; i=i-(i&(-i)))
        sum += aib[i];
    return sum;
}
void upd(int k, int val)
{
    for (int i = k; i <= n; i=i+(i&(-i)))
        aib[i] += val;
}
int main()
{
    in >> n >> m;
    for (i = 1; i <= n; i++)
    {
        in >> v[i];
        upd(i, v[i]);
    }
    while(m)
    {
        in >> cerinta >> a;
        if (cerinta != 2)
            in >> b;
        m--;
        if (cerinta == 0)
            upd(a, b);
        if (cerinta == 1)
            out << query(b) - query(a-1) << '\n';
        if (cerinta == 2)
        {
            int s = 0;
            int x = 0;
            int k = (1<<((int)log2(n)));
            for (; k >= 1; k/=2)
                if (x+k<=n && s + aib[x+k] <= a)
                {
                    s += aib[x+k];
                    x+=k;
                }
            out << x << '\n';
        }
    }
    return 0;
}
