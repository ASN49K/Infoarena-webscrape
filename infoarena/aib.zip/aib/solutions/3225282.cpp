#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");


const int N = 1e5;
int n, queries;
int v[N+1], aib[N+1];


int lsb(int x)
{
    return (x ^ (x-1)) & x;
}

int query(int poz)
{
    int ret = 0;
    for (; poz > 0; poz -= lsb(poz))
        ret += aib[poz];
    return ret;
}

void update(int poz, int val)
{
    for (; poz <= n; poz += lsb(poz))
        aib[poz] += val;
}


int search(int val)
{
    int pas;
    for (pas = 1; pas < n; pas = (pas << 1));

    int st = 0;
    for (; pas; pas = (pas >> 1))
    {
        if (st + pas <= n)
        {
            if (val >= aib[st + pas])
            {
                st += pas;
                val -= aib[st];
                if (val == 0)
                    return st;
            }
        }
    }

    return -1;
}


int main()
{
    cin >> n >> queries;

    for (int i = 1; i <= n; i++)
        cin >> v[i];
    

    for (int i = 1; i <= n; i++)
        update(i, v[i]);

    
    for (int q = 1; q <= queries; q++)
    {
        int cod;
        cin >> cod;

        if (cod == 0)
        {
            int a, b;
            cin >> a >> b;
            update(a, b);
        }
        else if (cod == 1)
        {
            int a, b;
            cin >> a >> b;
            cout << query(b) - query(a-1) << '\n';
        }
        else
        {
            int a;
            cin >> a;
            cout << search(a) << '\n';
        }
    }

    return 0;
}