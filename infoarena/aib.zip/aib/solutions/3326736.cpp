#include <iostream>
#define lsb(x)  (x & -x)
using namespace std;
const int Nmax = 2e5 + 5;
int aib[Nmax];
int sum(int i, int aib[]) {
	int sum = 0;
	while (i > 0) {
		sum += aib[i];
		i -= lsb(i);
	}
	return sum;
}

void add(int i, int val, int aib[], int n) {
	while (i <= n) {
		aib[i] += val;
		i += lsb(i);
	}
}

int find(int a, int aib[], int n) {
	int curr = 0;
	int prevsum = 0;
	for (int i = log2(n); i >= 0; --i) {
		if (aib[curr + (1 << i)] + prevsum < a) {
			curr = curr + (1 << i);
			prevsum += aib[curr];
		}
	}
	if (sum(curr + 1, aib) != a) {
		return -1;
	}
	else {
		return curr + 1;
	}

}


int main() {
	freopen("aib.in", "r", stdin);
	freopen("aib.out", "w", stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		int a;
		scanf("%d", &a);
		add(i, a, aib, n);

	}
	for (int i = 1; i <= m; ++i) {
		int query;
		scanf("%d", &query);
		if (query == 0) {
			int pos, val;
			scanf("%d%d", &pos, &val);
			add(pos, val, aib, n);
		}
		else if (query == 1) {
			int a, b;
			scanf("%d%d", &a, &b);
			printf("%d\n", sum(b, aib) - sum(a - 1, aib));
		}
		else if (query == 2) {
			int a;
			scanf("%d", &a);
			printf("%d\n", find(a, aib, n));
		}
	}

	return 0;
}