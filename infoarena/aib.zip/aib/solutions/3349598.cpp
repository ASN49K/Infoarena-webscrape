#include <fstream>
const int NMAX = 1e5 + 5;
using namespace std;
ifstream in("aib.in");
ofstream out("aib.out");

int n,m;
int aib[NMAX];

void update(int p, int val)
{
    while (p <= n)
    {
        aib[p] += val;
        p += (p & (-p));
    }
}

int query(int p) /// suma de la 1...p
{
    int s = 0;
    while (p > 0)
    {
        s += aib[p];
        p = p - (p & (-p));
    }
    return s;
}

int caut(int val)
{
    int i, step;

    for (step = 1; step < n; step <<= 1)
        ;

    for (i = 0; step; step >>= 1)
    {
        if (i + step <= n)
        {
            if (val >= aib[i + step])
            {
                i += step, val -= aib[i];
                if (!val)
                    return i;
            }
        }
    }

    return -1;
}
int main()
{
    in >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        int x;
        in >> x;
        update(i, x);
    }
    while(m--)
    {
        int type,a,b;
        in>>type;
        if(type==0)
        {
            in>>a>>b;
            update(a,b);
        }
        else if(type==1)
        {
            in>>a>>b;
            out<<query(b)-query(a-1)<<'\n';
        }
        else
        {
            in>>a;
            out<<caut(a)<<'\n';
        }
    }
    return 0;
}