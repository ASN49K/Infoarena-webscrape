#include <fstream>
using namespace std;

ifstream cin ("aib.in");
ofstream cout("aib.out");

int a[100001], n;

void up(int i, int x){
    do a[i] += x;
    while (i += i&-i, i <= n);
}

int qr(int i){
    int r = 0;
    do r += a[i];
    while (i ^= i&-i, i);
    return r;
}

int fd(int x){
    int b = 1 << 18;
    int i = 0;
    do if ((i|b) <= n && a[i|b] <= x) i |= b, x -= a[i];
    while (b >>= 1, b);

    return x ? -1 : i;
}

int main(){
    int q;
    cin >> n >> q;

    for (int i = 1; i <= n; i++){
        int num;
        cin >> num;
        up(i, num);
    }

    for (int i = 0; i < q; i++){
        int o, x, y;
        cin >> o;
        if (o < 2){
            cin >> x >> y;
            if (o == 0) up(x, y);
            else cout << qr(y) - qr(x-1) << '\n';
        } else {
            cin >> x;
            cout << fd(x) << '\n';
        }
    }

    return 0;
}
