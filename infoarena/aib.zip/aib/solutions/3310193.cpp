#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");


int n,x,aib[100002],v[100002],q,a,b;
short int type ;

void update ( int pos, int val )
{
    for ( pos ; pos <= n ; pos += ( pos & -pos ) )
        aib[pos] += val ;
}

int compute ( int pos )
{
    int s = 0 ;
    for ( pos ; pos > 0 ; pos -= ( pos & -pos )  )
        s += aib[pos] ;
    return s;
}
int main()
{
    cin >> n >>q ;
    for ( int i =1; i <= n ; i ++ )
        cin >> v[i], update(i, v[i]);

    for ( int i = 1; i <= q ; i ++ )
    {
        cin >> type >> a ;
        if ( type == 0 )
        {
            cin >> b ;
            update(a,b) ;
        }
        else if ( type == 1 )
        {
            cin >> b ;
            a-- ;
            cout << compute(b) - compute(a) << "\n";
        }
        else
        {
            int st = 1;
            int dr = n;
            int p = -1;
            while ( st <= dr )
            {
                int mij = ( st + dr ) / 2;
                int rez = compute(mij);
                if( rez == a )
                {
                    p = mij ;
                    dr = mij - 1;
                }
                else if ( rez < a )
                    st = mij + 1;
                else dr = mij - 1;
            }
            cout << p << endl ;
        }
    }
    return 0;
}
