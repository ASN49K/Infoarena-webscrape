#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("aib.in");
ofstream fout("aib.out");
#endif

const int NMAX = 100000;

int n;
int aib[NMAX+1];

void update(int poz, int x) {
    while (poz <= n) {
        aib[poz] += x;
        poz += (poz & (-poz));
    }
}

int query(int poz) {
    int s = 0;
    while (poz > 0) {
        s += aib[poz];
        poz -= (poz & (-poz));
    }
    return s;
}

int cb(int s){
    int st=1, dr=n;
    while (st < dr) {
        int mij = (st + dr) / 2;
        if (query(mij) < s) st = mij + 1;
        else dr = mij;
    }
    return st;
}

int main() {
    int m, t, a, b;
    fin >> n >> m;
    for (int i=1; i<=n; i++) fin >> a, update(i, a);
    for (int i=1; i<=m; i++) {
        fin >> t;
        if (t == 0) {
            fin >> a >> b;
            update(a, b);
        }
        else if (t == 1) {
            fin >> a >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else if (t == 2) {
            fin >> a;
            fout << cb(a) << '\n';
        }
    }
}
