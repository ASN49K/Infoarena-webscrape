#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");
int n ,aib[100001];
int lol(int x){
return x&(-x);
}
void update(int poz, int nr){
for(int i=poz;i<=n;i+=lol(i))
    aib[i]+=nr;
}
int  query(int poz2){
int sum=0;
for(int i=poz2;i>0;i-=lol(i))
    sum+=aib[i];
return sum;
}
int main()
{
    int m,i,nr,c,a,b,aux,x;
    cin>>n>>m;
    for(i=1;i<=n;i++){
        cin>>nr;
        update(i,nr);
    }
   /// cout<<aib[7];
    for(i=1;i<=m;i++){
        cin>>c>>a;
        if(c==2)
           {
               x=1;
            while(x<=n)
            x*=2;
            x/=2;
            aux=2;
            while(a!=0){
                if(aib[x]>a)
                    x=x-x/aux;
                else{
                    a-=aib[x];
                    if(a!=0)
                    x=x+x/aux;
                    aux*=2;

                }
            }
           cout<<x<<'\n';
           }
            else{
        cin>>b;
        if(c==0)
            update(a,b);
        if(c==1){
            aux=0;
            if(a>1)
                aux=query(a-1);
        cout<< query(b)-aux<<'\n';
        }
    }
    }
    return 0;
}
