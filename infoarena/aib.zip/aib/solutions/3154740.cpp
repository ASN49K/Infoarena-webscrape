#include<iostream>
#include<fstream>
using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

#define nmax 262144



int msb(int x){
    int msb=1;
    while(x){
        x=x>>1;
        msb=msb<<1;
    }
    return msb;
}
int lsb(int x){
    return x&(-x);
}


int v[nmax];
void build(int n){
    for(int i=1;i<=n;i++){
        v[i+lsb(i)]+=v[i];
    }
}
void update(int loc,int val,int n){
    while(loc<n){
        v[loc]+=val;
        loc+=lsb(loc);
    }
}
int query(int now,int stq,int drq){
    int part1=0,part2=0;

    int idx=stq-1;
    while(idx>0){
        part1+=v[idx];
        idx-=lsb(idx);
    }

    idx=drq;
    while(idx>0){
        part2+=v[idx];
        idx-=lsb(idx);
    }

    return part2-part1;
}

int main()
{
    int n,m;
    in>>n>>m;
    for(int i=1;i<=n;i++){
        in>>v[i];
    }
    n=msb(n);
    build(n);

    int a,b,c;
    for(int i=0;i<m;i++){
        in>>c;
        if(c==0){
            in>>a>>b;
            update(a,b,n);
        }else if(c==1){
            in>>a>>b;
            out<<query(1,a,b)<<'\n';
        }else{
            int sum=-1;
            bool found=false;
            in>>a;
            for(int i=1;i<n && sum<a;i++){
                sum=query(1,1,i);
                if(sum==a){
                    found=true;
                    out<<i<<'\n';
                }
            }
            if(!found)out<<-1<<'\n';
        }
    }
}
