#include <bits/stdc++.h>
using namespace std;

int n, m, cer, a, b;
int v[100010], tree[400010];

void build(int node, int left, int right)
{
    if(left == right)
    {
        tree[node] = v[left];
        return;
    }
    int mij = (left + right) / 2;
    build(2 * node, left, mij);
    build(2 * node + 1, mij + 1, right);
    tree[node] = tree[2 * node] + tree[2 * node + 1];
}

void update(int node, int left, int right, int pos, int val)
{
    if(left == right)
    {
        tree[node] += val;
        return ;
    }
    int mij = (left + right) / 2;
    if(pos <= mij)
        update(2 * node, left, mij, pos, val);
    else
        update(2 * node + 1, mij + 1, right, pos, val);
    tree[node] = tree[2 * node] + tree[2 * node + 1];
}

int query(int node, int left, int right, int st, int dr)
{
    if(st <= left && right <= dr)
        return tree[node];
    int mij = (left + right) / 2;
    int ans1 = 0, ans2 = 0;
    if(st <= mij)
        ans1 = query(2 * node, left, mij, st, dr);
    if(dr > mij)
        ans2 = query(2 * node + 1, mij + 1, right, st, dr);
    return ans1 + ans2;
}

int query2(int node, int left, int right, int val)
{
    if(tree[node] == val)
        return right;
    int mij = (left + right) / 2;
    int ans1 = 0, ans2 = 0;
    ans1 = query2(2 * node, left, mij, val);
    if(ans1 + ans2 == val)
        return right;
}

int main()
{
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);

    cin >> n >> m;
    for(int i = 1; i <= n; i++)
        cin >> v[i];
    build(1, 1, n);
    for(int i = 1; i <= m; i++)
    {
        cin >> cer;
        if(cer == 0)
        {
            cin >> a >> b;
            update(1, 1, n, a, b);
        }
        else if(cer == 1)
        {
            cin >> a >> b;
            cout << query(1, 1, n, a, b) << ' ';
        }
        else
        {
            cin >> a;
            cout << query2(1, 1, n, a) << ' ';
        }
    }

    return 0;
}
