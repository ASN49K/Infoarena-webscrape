#include <bits/stdc++.h>
#define up(i) (i & (-i))
const int NMAX = 1e6;
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int n, q, type;
class AIB{
public:
    int aib[NMAX + 5];
    void add (int val, int a){
        for (int i = val; i <= n; i += up(i))
             aib[i] += a;
    }
    int getsum(int val){
        int sum = 0;
        for (int i = val; i >= 1; i -= up(i))
             sum += aib[i];
        return sum;
    }
    int query(int l, int r){
        return getsum(r) - getsum(l - 1);
    }
    int cauta (int sum){
        int left = 1, right = n, sol = 0;
        while (left <= right){
            auto mid = (left + right) >> 1;
            if (getsum(mid) >= sum)
                right = mid - 1, sol = mid;
            else
                left = mid + 1;
        }
        return sol;
    }
}shemoanzdaddy;
signed main(){
    fin >> n >> q;
    for (int i = 1, a; i <= n; i++)
        fin >> a, shemoanzdaddy.add(i, a);
    for (int i = 1; i <= q; i++){
        fin >> type;
        if (type == 0){
            int a, b;
            fin >> a >> b;
            shemoanzdaddy.add(a, b);
        }
        if (type == 1){
            int a, b;
            fin >> a >> b;
            fout << shemoanzdaddy.query(a, b) << "\n";
        }
        if (type == 2){
            int a;
            fin >> a;
            fout << shemoanzdaddy.cauta(a) << "\n";
        }
    }
    return 0;
}
