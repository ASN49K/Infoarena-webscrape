#include <bits/stdc++.h>
#define up(i) (i & (-i))
const int NMAX = 1e5;
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int aib[NMAX + 5], n, q, tsk, val;
void add (int x, int val){
    for (int i = x; i <= n; i += up(i))
        aib[i] += val;
}
int query(int x){
    int sum = 0;
    for (int i = x; i >= 1; i -= up(i))
        sum += aib[i];
    return sum;
}
void solve_query(){
    fin >> val;
    int left = 1, right = n;
    while (left <= right){
        auto mid = (left + right ) >> 1;
        if (query(mid) == val){
            fout << mid << "\n";
            return;
        }
        if (query(mid) < val)
            left = mid + 1;
        else
            right = mid - 1;
    }
    fout << -1 << "\n";
}
signed main() {
    fin >> n >> q;
    for (int i = 1, a; i <= n; i++)
        fin >> a, add(i, a);
    for (int i = 1, a, b; i <= q; i++){
        fin >> tsk;
        if (tsk == 0){
            fin >> a >> b;
            add(a, b);
        }
        if (tsk == 1){
            fin >> a >> b;
            fout << query(b) - query(a - 1) << "\n";
        }
        if (tsk == 2)
            solve_query();
    }
    return 0;
}
