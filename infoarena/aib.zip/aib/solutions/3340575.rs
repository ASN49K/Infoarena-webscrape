use std::fs::{self,File};
use std::io::{BufWriter,Write};

macro_rules! parse_line {
    ($iter: expr, $($t: ty), +) => {{
        let lines = $iter.next().unwrap();
        let mut parts = lines.split_whitespace();
        ($(parts.next().unwrap().parse::<$t>().unwrap()),+)
    }};
}
macro_rules! parse_vector {
    ($iter: expr, $t: ty) => {{
        $iter
            .next()
            .unwrap()
            .split_whitespace()
            .map(|x| x.parse::<$t>().unwrap())
            .collect::<Vec<$t>>()

    }};
}
struct FenwickTree {
    n : usize,
    bit : Vec<i32>,
    logn : usize
}
impl FenwickTree {
    fn new(size : usize)->FenwickTree
    {
        FenwickTree { n: (size), bit: (vec![0; size+1]), logn: (size.ilog2() as usize) }
    }
    fn add(&mut self, mut poz : usize, val : i32)
    {
        while poz <= self.n 
        {
            self.bit[poz] += val;
            poz += (poz as i32  & ( -(poz as i32) )) as usize
        }
    }
    fn query (& self, mut poz: usize) -> i32 {
        let mut sum =0;
        while poz > 0 {
            sum += self.bit[poz];
            poz -= (poz as i32 &(- (poz as i32))) as usize;
        }
        sum
    }
    fn getaib(&mut self, vect : Vec<i32>) {
        for i in 1..=self.n {
            self.add(i, vect[i-1]);
        }
    }
    fn intervalquery(& self, l: usize, r: usize) -> i32 {
        self.query(r)-self.query(l-1)
    }
    fn lowerbound(& self, val : i32) -> i32 {
        let mut sum=0;
        let mut pos = 0;
        for i in (0..self.logn).rev() {
            if pos + (1 << i) < self.n && sum + self.bit[pos + (1 << i)] < val {
                sum += self.bit[pos + (1 << i)];
                pos += 1 << i;
            }
        }
        if self.query(pos + 1 ) == val {
            return (pos + 1) as i32;
        }
        -1
    }
}
fn main() ->std::io::Result<()>{
    let content = fs::read_to_string("aib.in")?;
    let mut lines = content.lines();
    let mut writer = BufWriter::new(File::create("aib.out")?);
    let (n, m) = parse_line!(lines, usize, usize);
    let vect = parse_vector!(lines, i32);
    let mut myaib=FenwickTree::new(n);
    myaib.getaib(vect);
    for _ in 0..m {
        let op = parse_vector!(lines,i32);
        match op[0] {
            0 => {
                let (poz, val) = (op[1] as usize, op[2]);
                myaib.add(poz, val);
            }
            1 => {
                let (l, r) = (op[1] as usize, op[2] as usize);
                writeln!(writer,"{}",myaib.intervalquery(l, r))?;
            }
            _ => {
                writeln!(writer,"{}",myaib.lowerbound(op[1]))?;
            }
        }
    }
    Ok(())
}
