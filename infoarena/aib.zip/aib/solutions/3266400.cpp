#include <fstream>
using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
int n,m,b,a[1001];
void update(int p,int val)
{
    for(int i=p;i<=n;i+=(i&-i)) a[i]+=val;
}
int sum(int p,int z)
{
    int s=0;
    for(int i=p;i>z-1;i-=(i&-i)) s+=a[i];
    return s;
}
int main()
{
    f>>n>>m;
    for(int i=1;i<=n;++i)
        {f>>b;update(i,b);}///25 42 8 15 1 55 16 67
    for(int i=1;i<=m;++i)
    {
        int c,y;
        f>>c>>y;
        if(c==0)
        {
            int x;
            f>>x;
            update(y,x);
        }
        else if(c==1)
        {
            int x;
            f>>x;
            g<<sum(x,y)<<'\n';
        }
        else g<<1<<'\n';
    }
    return 0;
}
