#include <fstream>
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
const int Nmax = 1e5 + 5;
int v[Nmax], aib[Nmax];
int n , Q;
int getSum(int x){
 int suma = 0;
 while(x){
    suma += aib[x];
    x -= x&-x;
 }
 return suma;
}
void Update(int x , int val){

  while(x <= n){
    aib[x] += val;
    x += x & -x;
  }
}
int cb(int k){
  int st = 0, dr  = n;
  int mij = 0;
  while(st <= dr){
    mij = (st + dr) / 2;
    int val = getSum(mij);
        if(val == k){
            return mij;
        }
        else if(val < k){
            st = mij + 1;
        }
        else if(val > k){
            dr = mij - 1;
        }

  }
  return -1;
}
int main()
{
    fin >> n >> Q;
    for(int i = 1;i <= n; ++ i){
        fin >> v[i];
        Update(i , v[i]);
    }

     while(Q){
        --Q;
        int T;
        fin >> T;
        if(T == 0){
            int a , b;
            fin >> a >> b;
            Update(a , b);
        }
        else if(T == 1){
            int a,b;
            fin >> a >> b;
            fout << getSum(b) - getSum(a - 1) << '\n';
        }
        else if(T == 2){
            int k;
            fin >> k;
            int val = cb(k);
            if(val == -1){
                fout << "-1" << '\n';
            }
            else{
                fout << val << '\n';
            }
        }
    }
    return 0;
}
