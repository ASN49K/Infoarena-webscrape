#include <fstream>
#include <map>
#include <vector>

using namespace std;

ifstream fin("disjoint.in");
ofstream fout("disjoint.out");

const int NMAX = 100005;

int aib[NMAX],n;

void update(int poz, int val){
    for(int i = poz;i <= n;i += i & -i){
        aib[i] += val;
    }
}

int query(int poz){
    int s = 0;
    for(int i = poz;i >= 1;i -= i & -i){
        s += aib[i];
    }
    return s;
}

int bs(int x){
    int st = 1,dr = n,mid;
    while(st <= dr){
        mid = st + (dr - st) / 2;
        if(query(mid) >= x)
            dr = mid - 1;
        else
            st = mid + 1;
    }
    if(query(st) == x)
        return st;
    return -1;
}
int main()
{
    int m;
    fin>>n>>m;
    int q,x,y;
    for(int i = 1;i <= n;i++){
        fin>>x;
        update(i,x);
    }
    for(int i = 1;i <= m;i++){
        fin>>q;
        if(!q){
            fin>>x>>y;
            update(x,y);
        }
        else
            if(q == 1){
                fin>>x>>y;
                fout<<query(y) - query(x - 1)<<"\n";
            }
            else
            {
                fin>>x;
                fout<<bs(x)<<"\n";
            }
    }
    return 0;
}
