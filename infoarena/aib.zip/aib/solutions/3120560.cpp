#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int AIB[400005], N, M;

void Update(int P, int quantity)
{
	for (int i = P; i <= N; i += (i & -i))
		AIB[i] += quantity;
}
int Query(int P)
{
	int SUM = false;
	for (int i = P; i > 0; i -= (i & -i))
		SUM += AIB[i];
	return SUM;
}
void Task()
{
	fin >> N >> M;
	for (int i = 1; i <= N; ++i)
	{
		int X;
		fin >> X;
		Update(i, X);
	}
	for(int i = 1; i <= M; ++ i)
	{
		int C;
		fin >> C;
		int A, B;
		if (C == 0)
		{
			fin >> A >> B;
			Update(A, B);
		}
		else if (C == 1)
		{
			fin >> A >> B;
			fout << Query(B) - Query(A - 1) << '\n';
		}
		else
		{
			fin >> A;
			int i = 1;
			while (Query(i) != A && i < N)
				i++;
			fout << i << '\n';
		}
	}
	fin.close();
	fout.close();
}
int main()
{
	ios_base::sync_with_stdio(false);
	fin.tie(0); fout.tie(0);
	Task();
	return 0;
}
