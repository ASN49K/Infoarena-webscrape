#include <bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m, aib[100001], t;

void Update(int p, int x)
{
    aib[p] += x;
    while (p <= n)
    {
        p += (p & -p);
        aib[p] += x;
    }
}

int Query(int p)
{
    int s = 0;
    s += aib[p];
    while (p >= 1)
    {
        p -= (p & -p);
        s += aib[p];
    }
    return s;
}

int CautBin(int x)
{
    int st = 1, dr = n, mij, poz = -1;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        if (Query(mij) < x)
            st = mij + 1;
        else if (Query(mij) > x)
            dr = mij - 1;
        else
        {
            poz = mij;
            dr = mij - 1;
        }
    }
    return poz;
}

int main()
{
    int i, j, x, y, p;
    fin >> n >> m;
    for (i = 1 ; i <= n ; i++)
    {
        fin >> x;
        Update(i, x);
    }
    for (i = 1 ; i <= m ; i++)
    {
        fin >> t;
        if (t == 0)
        {
            fin >> x >> y;
            Update(x, y);
        }
        else if (t == 1)
        {
            fin >> x >> y;
            fout << Query(y) - Query(x - 1) << "\n";
        }
        else
        {
            fin >> x;
            fout << CautBin(x) << "\n";
        }
    }
    return 0;
}
