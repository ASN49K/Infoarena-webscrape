#include <bits/stdc++.h>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

/**
24 12 15 15 19
12 15 15 19
*/

int n, aib[100002], m;

void Update(int p, int x)
{
    while (p <= n)
    {
        aib[p] += x;
        p += (p & -p);
    }
}

int Query(int p)
{
    int s = 0;
    while (p > 0)
    {
        s += aib[p];
        p -= (p & -p);
    }
    return s;
}

int CB(int k)
{
    int st, dr, mij, pos;
    st = 1; dr = n; pos = -1;
    while(st <= dr)
    {
        mij = (st + dr) / 2;
        if(Query(mij) == k)
        {
            pos = mij;
            dr = mij - 1;
        }
        else if(Query(mij) > k)
            dr = mij - 1;
        else st = mij + 1;
    }
    return pos;
}

int main()
{
    int i, op, a, b, x;
    fin >> n >> m;
    for(i = 1; i <= n; i++)
    {
        fin >> x;
        Update(i, x);
    }
    while(m--)
    {
        fin >> op;
        if(op == 0)
        {
            fin >> a >> b;
            Update(a, b);
        }
        else if (op == 1)
        {
            fin >> a >> b;
            fout << Query(b) - Query(a - 1) << "\n";
        }
        else if (op == 2)
        {
            fin >> a;
            fout << CB(a) << "\n";
        }
    }
    return 0;
}
