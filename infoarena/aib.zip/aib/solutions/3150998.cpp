#include <fstream>
#include <vector>

using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n;
vector <int> bit(100005, 0);
void update(int i, int val)
{
    while(i<=n)
    {
        bit[i]+=val;
        i+=(i&-i);
    }
}
int prefixSum(int i)
{
    int sum;
    sum=0;
    while(i>0)
    {
        sum+=bit[i];
        i-=(i&-i);
    }
    return sum;
}
int rangeSum(int i, int j)
{
    return prefixSum(j)-prefixSum(i-1);
}
int main()
{
    int m;
    cin>>n>>m;
    int i, nr;
    for(i=1; i<=n; i++){
        cin>>nr;
        update(i, nr);
    }
    int j, c, a, b, k, poz, st, dr, sum, mij;
    while(m>0)
    {
        cin>>c;
        if(c==0)
        {
            cin>>a>>b;
            update(a, b);
        }
        else if(c==1)
        {
            cin>>a>>b;
            cout<<rangeSum(a, b)<<'\n';
        }
        else if(c==2)
        {
            cin>>a;
            poz=-1;
            st=1;
            dr=n;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                sum=prefixSum(mij);
                if(sum==a)
                {
                    poz=mij;
                    break;
                }
                else if(sum<a)
                    st=mij+1;
                else
                    dr=mij-1;
            }
            cout<<poz<<'\n';
        }
        m--;
    }
    return 0;
}
