#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");

vector<int> v;
int s[100001], N, M, op, a, b;

int bin(int st, int dr, int k)
{
    while(st<=dr)
    {
        int mij = (st+dr)/2;
        if(s[mij] < a) st = mij + 1;
        else if(s[mij] > a) dr = mij - 1;
        else return mij;
    }
    return -1;
}

int main()
{
    fin >> N >> M;
    for(int i=0; i<N; i++)
    {
        int x;
        fin >> x;
        v.push_back(x);
    }
    
    for(int i=0; i<M; i++)
    {
        fin >> op;
        if(!op)
        {
            fin >> a >> b;
            v[a-1] += b;
            s[1] = v[0];
            for(int i=2; i<=N; i++) s[i] += s[i-1] + v[i-1];
        }
        else if(op == 1) 
        {
            fin >> a >> b;
            fout << s[b] - s[a-1] << "\n";
        }
        else
        {
            fin >> a;
            int k = bin(1, N, a);
            fout << k << "\n";
        }
    }
    return 0;
}
