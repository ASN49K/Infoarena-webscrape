/// http://algopedia.ro/wiki/index.php/Clasele_11-12_lec%C8%9Bia_7_-_29_oct_2014

#include <fstream>
#define NM 100006
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,m,aib[NM];
int op,a,b;

void adauga(int poz,int val)
{
    int p,x;
    x=poz;
    do
    {
        aib[x]=aib[x]+val;
        p=x&(-x) ;
        x=x+p;

    }while(x<=n);
}

int suma(int poz)
{
    int s,p,x;
    s=0;
    x=poz;
    while(x>0)
    {
        s=s+aib[x];
        p=x&(-x) ;
        x=x-p;

    }
    return s;
}

int main()
{
    int i,st,dr,mij,k,s;
    fin>>n>>m;
    for(i=1; i<=n; i++)
    {
        fin>>a;
        adauga(i,a);
    }
    for(int i=1; i<=m; i++)
    {
        fin>>op;
        if(op==0)
        {
            fin>>a>>b;
            adauga(a,b);
        }
        else if(op==1)
        {
            fin>>a>>b;
            fout<<suma(b)-suma(a-1)<<'\n';
        }
        else
        {
            fin>>a;
            st=1;
            dr=n;
            k=-1;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                s=suma(mij);
                if(s==a)
                {
                    k=mij;
                    dr=mij-1;
                }
                else
                    if(a<s) dr=mij-1;
                else
                    st=mij+1;
            }
            fout<<k<<'\n';
        }
    }
    return 0;
}
