#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
 
int n, m, v[100001], op, x, y;

void update(int poz, int val){
    for(int i = poz; i <= n; i += (i & -i))
        v[i] += val;
}

ll suma(int poz){
    ll sum = 0;
    for(int i = poz; i >= 1; i -= (i & -i))
        sum += v[i];
    return sum;
}

int cb(int val){
    if(suma(1) > val)
        return -1;
    
    int st = 1, dr = n;
    while(st <= dr){
        int mid = (st + dr) / 2;
        if(v[mid] == val)
            return mid;
        else if(v[mid] < val)
            st = mid + 1;
        else
            dr = mid - 1;
    }

    return -1;
}

int main(){
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);

    fin >> n >> m;
    for(int i = 1; i <= n; i++){
        fin >> x;
        update(i, x);
    }

    while(m--){
        fin >> op;
        
        if(op == 0 || op == 1)
            fin >> x >> y;
        else
            fin >> x;

        if(op == 0)
            update(x, y);
        else if(op == 1)
            fout << suma(y) - suma(x - 1) << '\n';
        else
            fout << cb(x) << '\n';
    }
}