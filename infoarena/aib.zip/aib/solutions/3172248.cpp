#include <bits/stdc++.h>
using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
const int NMAX=100005;
int n,m,op,x,y;
vector<int>aib;
void update(int node,int value)
{
    for(; node<=n; node+=node&(-node))
        aib[node]+=value;
}
int query(int node)
{
    int ans=0;
    for(; node>0; node-=node&(-node))
        ans+=aib[node];
    return ans;
}
int magical_binary_search(int value)
{
    int ans=0,curr_sum=0;
    for(int step=(1<<30); step>0; step>>=1) ///we search for the last position with the sum strictly smaller than value
        if(ans+step<=n && curr_sum+aib[ans+step]<value)
        {
            ans+=step;
            curr_sum+=aib[ans];
        }
    if(ans+1>n || query(ans+1)!=value)///if the sum for the next position isn't equal to value we return -1
        return -1;
    return ans+1;
}
int main()
{
    f>>n>>m;
    aib.resize(n+1);
    for(int i=1; i<=n; i++)
    {
        f>>x;
        update(i,x);
    }
    for(int i=1; i<=m; i++)
    {
        f>>op;
        if(op==0)
        {
            f>>x>>y;
            update(x,y);
        }
        else if(op==1)
        {
            f>>x>>y;
            g<<query(y)-query(x-1)<<'\n';
        }
        else
        {
            f>>x;
            g<<magical_binary_search(x)<<'\n';
        }
    }
    return 0;
}
