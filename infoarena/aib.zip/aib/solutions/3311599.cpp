#include <fstream>
#include <vector>
#define int long long
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int lsb (int x) {
    return x & (-x);
}
int n;
int m;
vector<int> v;
vector<int> aib;
void update (int pos, int increment) {
    while (pos<=n) {
        aib[pos]+=increment;
        pos+=lsb(pos);
    }
}
int query (int pos) {
    int sum=0;
    while (pos>0) {
        sum+=aib[pos];
        pos-=lsb(pos);
    }
    return sum;
}
int32_t main() {    cin>>n>>m;
    v.resize(n+1);
    aib.resize(n+1);
    for (int i=1; i<=n; ++i) {
        cin>>v[i];
        update(i,v[i]);
    }
    int c,a,b;
    for (int i=1; i<=m; ++i) {
        cin>>c;
        if (c==0) {
            cin>>a>>b;
            update(a,b);
        }
        if (c==1) {
            cin>>a>>b;
            cout<<query(b)-query(a-1)<<'\n';
        }
        if (c==2) {
            cin>>a;
            for (int j=1; j<=n; ++j) {
                if (query(j)==a) {
                    cout<<j<<'\n';
                    break;
                }
            }
        }
    }
}
