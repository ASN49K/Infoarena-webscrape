#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

const int NMAX = 100002;

struct AIB {
    vector<int> aib;
    int n;

    AIB(int n) : n(n), aib(n + 1, 0) {}

    void update(int pos, int val) {
        for (; pos <= n; pos += pos) {
            aib[pos] += val;
        }
    }

    int query(int pos) {
        int res = 0;
        for (; pos > 0; pos -= pos) {
            res += aib[pos];
        }
        return res;
    }

    int binary_search(int sum) {
        int pos = 0;
        int curr_sum = 0;
        for (int i = 17; i >= 0; --i) {
            if (pos + i <= n && curr_sum + aib[pos + (1 << i)] <= sum) {
                pos += (1 << i);
                curr_sum += aib[pos];
            }
        }
        return curr_sum == sum ? pos : -1;
    }
};

int main() {
    int n, m;
    cin >> n >> m;

    vector<int> v(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> v[i];
    }

    AIB aib(n);
    for (int i = 1; i <= n; ++i) {
        aib.update(i, v[i]);
    }

    while (m--) {
        int op;
        cin >> op;

        if (op == 0) {
            int pos, val;
            cin >> pos >> val;
            aib.update(pos, val);
        } else if (op == 1) {
            int a, b;
            cin >> a >> b;
            cout << aib.query(b) - aib.query(a - 1) << '\n';
        } else {
            int sum;
            cin >> sum;
            cout << aib.binary_search(sum) << '\n';
        }
    }

    return 0;
}