#include <iostream>
#include <fstream>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

int A[100005], n, m;

void add(int poz, int val){
    for(int i=poz; i<=n; i+= i & -i)
        A[i] += val;
}
int sum(int p){
    int rez=0, i;
    for(i=p; i; i -= i & -i)
        rez += A[i];
    return rez;
}


int main()
{
    int i, a, x, c;
    f >> n >> m;
    for(i=1; i<=n; i++){
        f >> x;
        add(i, x);
    }
    for(i=1; i<=m; i++){
        f >> c;
        if(c==0){
            int poz, val;
            f >> poz >> val;
            add(poz, val);
        }
        else if(c==1){
            int b;
            f >> a >> b;
            g << sum(b) - sum(a-1) << '\n';
        }
        else{
            f >> a;
            int s =0, poz = 0, b;
            for(b=17; b>=0; b--){
                if(poz + (1<<b) <= n && s + A[poz + (1<<b)]<=a){
                    s += A[poz + (1<<b)];
                    poz += 1<<b;
                }
            }
            if(s == a) g << poz << '\n';
            else g << "-1\n";
        }
    }

    return 0;
}
