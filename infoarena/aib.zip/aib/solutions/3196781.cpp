#include <bits/stdc++.h>
#define INF 1e9
#define pb push_back
#define NMAX 150000
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,m,a[NMAX],x,y,cer;
int aib[NMAX];

int ub(int x)
{
    return (x&(-x));
}

void add(int x,int y)
{
    for(int i=x;i<=n;i+=ub(i))
    {
        aib[i]+=y;
    }
}
int sum(int x)
{
    int rez=0;
    for(int i=x;i>=1;i-=ub(i)) {
        rez += aib[i];
    }
    return rez;
}


int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;++i)
    {
        fin>>a[i];
        add(i,a[i]);
    }
    for(int i=1;i<=m;++i)
    {
        fin>>cer;
        if(cer==0)
        {
            fin>>x>>y;
            add(x,y);
        }
        else if(cer==1)
        {
            fin>>x>>y;
            fout<<sum(y)-sum(x-1)<<endl;
        }
        else if(cer==2)
        {
            fin>>x;
            int s=0,poz=0;
            for(int b=17;b>=0;b--)
            {
                if(poz+(1<<b)<=n && s+aib[poz+(1<<b)]<x)
                {
                    s+=aib[poz+(1<<b)];
                    poz+=(1<<b);
                }
            }
            if(poz+1>n ||sum(poz+1)!=x)
                fout<<-1<<endl;
            else
            {
                fout<<poz+1<<endl;
            }
        }
    }


    return 0;
}
