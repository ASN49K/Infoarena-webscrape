#include <bits/stdc++.h>
#define DIM 100001
#define int long long

using namespace std;

ifstream fin("aib.in");

ofstream fout("aib.out");

int n, i, x, a, b, Q, task;

int v[DIM], bit[DIM];

int lsb(int n){

    return (n & -n);

}

void Update(int i, int val){

    for(; i <= n ; i += lsb(i))

        bit[i] += val;

}

int Query(int i){

    int ret = 0;

    for(; i >= 1 ; i -= lsb(i))

        ret += bit[i];

    return ret;

}

int binary_lifting(){

    int ret = 0;

    int temp = 0;

    for(i=log2(n);i>=0;i--){

        if(ret + (1LL << i) <= n && temp + bit[ret + (1LL << i)] <= a){

            temp += bit[ret + (1LL << i)];

            ret += (1LL << i);

        }

    }

    if(Query(ret) == a)

        return ret;

    return -1;

}


int32_t main(){

    fin >> n >> Q;

    for(i=1;i<=n;i++){

        fin >> v[i];

        Update(i, v[i]);

    }

    while(Q--){

        fin >> task;

        if(task == 0){

            fin >> a >> b;

            Update(a, b - v[i]);

            v[a] = b;

        }

        else if(task == 1){

            fin >> a >> b;

            fout << Query(b) - Query(a - 1) << "\n";

        }

        else {

            fin >> a;

            fout << binary_lifting() << "\n";

        }

    }

}
