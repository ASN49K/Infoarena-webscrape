#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int t[100005];
int A[100005];
int n;
void update(int p,int val)
{
    for(int i=p;i<=n;i+=(i&(-i)))
    {
        A[i]+=val;
    }
}
int querry(int p)
{
    int sum=0;
    for(int i=p;i;i-=(i&-i))
    {
        sum+=A[i];
    }
    return sum;
}
int binsearch(int sum)
{
    int st,dr,med,ans=-1,tem;
    st=1,dr=n;
    while(st<=dr)
    {
        med=(st+dr)/2;
        tem=querry(med);
        if(tem==sum)
        {
            ans=med;
            dr=med-1;
        }
        else if(tem>sum)
        {
            dr=med-1;
        }
        else
            st=med+1;
    }
    return ans;
}
int main()
{
    int m,i,j,c,a,b;
    fin>>n>>m;
    for(i=1;i<=n;++i)
    {
        fin>>t[i];
    }
    for(i=1;i<=m;++i)
    {
        fin>>c;
        if(c==0)
        {
            fin>>a>>b;
            update(a,b);
        }
        else if(c==1)
        {
            fin>>a>>b;
            fout<<querry(b)-querry(a-1)<<'\n';
        }
        else
        {
            fin>>a;
            fout<<binsearch(a)<<'\n';
        }
    }
    return 0;
}
