#include <fstream>
using namespace std;

#define int long long

ifstream cin("aib.in");
ofstream cout("aib.out");
const int VMAX=100000;
int X[VMAX+5];
int SP[VMAX+5];
int AIB[VMAX+5];
int n, m;

void update(int poz, int val) {
    while (poz<=n) {
        AIB[poz]=AIB[poz]+val;
        poz+=poz & (-poz);
    }
}

int sum(int i) {
    int sum=0, mempow=2;
    while (mempow/2<=i) {
        if ((i%mempow)/(mempow/2)==0) {
            mempow=mempow*2;
            continue;
        }
        sum=sum+AIB[i];
        i=i-(mempow/2);
        mempow=mempow*2;
    }
    return sum;
}

signed main() {
    cin>>n>>m;
    for (int i=1; i<=n; i++) {
        cin>>X[i];
        SP[i]=SP[i-1]+X[i];
    }
    for (int i=1; i<=n; i++) {
        int pow=2;
        while ((i%pow)/(pow/2)==0) pow=pow*2;
        AIB[i]=SP[i]-SP[i-(pow/2)];
    }
    for (int i=1; i<=m; i++) {
        int op;
        cin>>op;
        int a, b;
        if (op==0) {
            cin>>a>>b;
            X[a]=X[a]+b;
            update(a, b);
        }
        else if (op==1) {
            cin>>a>>b;
            cout<<sum(b)-sum(a-1)<<"\n";
        }
        else if (op==2) {
            cin>>a;
            int head=1, tail=n, rez=2000000000;
            while (head<=tail) {
                int mid=(head+tail)/2;
                int rasp=sum(mid);
                if (rasp==a) {
                    rez=min(rez, mid);
                    tail=mid-1;
                }
                else if (rasp<a) head=mid+1;
                else tail=mid-1;
            }
            cout<<rez<<"\n";
        }
    }
}
