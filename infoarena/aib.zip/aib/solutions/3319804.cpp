#include <fstream>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int Nmax=1e5+5;
int v[Nmax],aib[Nmax],n;

int lsb(int x) {
    return x&(-x);
}
void update(int poz, int val) {
    for (int i=poz; i<=n; i+=lsb(i)) aib[i]+=val;
}
int query(int poz) {
    int s=0;
    for (int i=poz; i>0; i-=lsb(i)) s+=aib[i];
    return s;
}
int bs(int val) {
    int ans=0,s=0;
    for (int pas=(1<<17); pas>0; pas/=2) {
        if (ans+pas<=n && (long long)s+aib[ans+pas]<(long long)val) {
            s+=aib[ans+pas];
            ans+=pas;
        }
    }
    ans++;
    s+=v[ans];
    if (s!=val) ans=-1;
    return ans;
}

int main()
{
    int m;
    fin>>n>>m;
    for (int i=1; i<=n; ++i) {
        fin>>v[i];
        update(i,v[i]);
    }
    for (int q=1; q<=m; ++q) {
        int c,a,b;
        fin>>c;
        if (c==0) {
            fin>>a>>b;
            update(a,b);
        }
        else if (c==1) {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<endl;
        }
        else {
            fin>>a;
            fout<<bs(a)<<endl;
        }
    }

    fin.close();
    fout.close();
    return 0;
}
