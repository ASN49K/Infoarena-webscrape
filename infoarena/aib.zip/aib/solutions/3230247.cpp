﻿#include <iostream>
#include <fstream>

using namespace std;
const int N = 100005;

ifstream f("aib.in");
ofstream g("aib.out");

long long zero(long long x) { return (x ^ (x - 1)) & x; }
int n;
long long v[N], aib[N];
int m;

void add(int a, long long b) {
    for (int i = a; i <= n; i += zero(i))
        aib[i] += b;
}

long long query(int a) {
    long long sum = 0;
    for (int i = a; i > 0; i -= zero(i))
        sum += aib[i];
    return sum;
}

int main()
{
    f >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        f >> v[i];
        add(i, v[i]);
    }
    while (m--) {
        int tip;
        f >> tip;
        if (tip == 0) {
            int a;
            long long b;
            f >> a >> b;
            add(a, b);
        }
        else if (tip == 1) {
            int a, b;
            f >> a >> b;
            g << query(b) - query(a - 1) << "\n";
        }
        else {
            int a;
            f >> a;
            int st = 1, dr = n;
            int sol = 0;
            while (st <= dr) {
                int mij = (st + dr) / 2;
                long long current_sum = query(mij);
                if (current_sum == a) {
                    sol = mij;
                    dr = mij - 1;
                }
                else if (current_sum > a)
                    dr = mij - 1;
                else
                    st = mij + 1;
            }
            g << (sol && query(sol) == a ? sol : -1) << "\n";
        }
    }
    return 0;
}
