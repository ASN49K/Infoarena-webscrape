#include <bits/stdc++.h>

using namespace std;

int n, m;
vector <int> BIT(100001, 0);

void update(int i, int val)
{
    while(i<=n)
    {
        BIT[i]+=val;
        i+=(i&-i);
    }
}
int presum(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=BIT[i];
        i-=(i&-i);
    }
    return sum;
}

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    int a, b, c;
    cin >> n >> m;
    for(int i=1; i<=n; i++)
    {
        cin >> a;
        update(i, a);
    }
    for(int i=1; i<=m; i++)
    {
        cin >> c;
        //cout << "i=" << i << " c=" << c << " ";
        if(c==0)
        {
            cin >> a >> b;
            update(a, b);
        }
        else if(c==1)
        {
            cin >> a >> b;
            //cout << a << " " << b << " " << presum(b) << " " << presum(a-1) << " ";
            cout << presum(b)-presum(a-1) << "\n";
        }
        else if(c==2)
        {
            //cout << "OK ";
            cin >> a;
            //cout << a << " ";
            int l=1, r=n, mid;
            while(l<r)
            {
                mid=(l+r+1)/2;
                if(presum(mid)<=a)
                    l=mid;
                else r=mid-1;
            }
            if(presum(l)==a)
            cout << l << "\n";
            else cout << "-1\n";
        }
        //cout << "\n";
    }

    return 0;
}
