#include <bits/stdc++.h>
#define int long long

using namespace std;

const int NMAX = 1e5;

int aint[4 * NMAX + 1];

void update( int st, int dr, int poz, int x, int i = 0 ) {
    if ( st == dr ) {
        aint[i] += x;
    } else {
        int mij = ( st + dr ) / 2;
        if ( poz <= mij ) update( st, mij, poz, x, i * 2 + 1 );
        else update( mij + 1, dr, poz, x, i * 2 + 2 );
        aint[i] = aint[i * 2 + 1] + aint[i * 2 + 2];
    }
}
int query( int st, int dr, int a, int b, int i = 0 ) {
    if ( st == a && dr == b ) return aint[i];
    int mij = ( st + dr ) / 2;
    if ( b <= mij ) return query( st, mij, a, b, i * 2 + 1 );
    if ( a > mij ) return query( mij + 1, dr, a, b, i * 2 + 2 );
    return query( st, mij, a, mij, i * 2 + 1 ) + query( mij + 1, dr, mij + 1, b, i * 2 + 2 );
}
int cb( int st, int dr, int sum, int i = 0 ) {
    if ( st == dr ) return st;
    int mij = ( st + dr ) / 2;
    if ( aint[i * 2 + 1] >= sum ) return cb( st, mij, sum, i * 2 + 1 );
    return cb( mij + 1, dr, sum - aint[i * 2 + 1], i * 2 + 2 );
}
signed main() {
    ifstream fin( "aib.in" );
    ofstream fout( "aib.out" );
    int n, m;

    fin >> n >> m;
    for ( int i = 1, x; i <= n; i ++ ) {
        fin >> x;
        update( 1, n, i, x );
    }
    for ( int i = 1, tip, a, b; i <= m; i ++ ) {
        fin >> tip;
        if ( tip == 0 ) {
            fin >> a >> b;
            update( 1, n, a, b );
        } else if ( tip == 1 ) {
            fin >> a >> b;
            fout << query( 1, n, a, b ) << '\n';
        } else {
            fin >> b;
            int aux = cb( 1, n, b );
            if ( query( 1, n, 1, aux ) == b ) {
                fout << aux << '\n';
            } else {
                fout << "-1\n";
            }
        }
    }
    return 0;
}