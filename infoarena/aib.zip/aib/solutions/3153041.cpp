#include <fstream>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

struct BIT {
    int n;
    int *v;

    BIT(int n) : n(n) {
        v=new int[n+1];
        for(int i=0;i<=n;i++)
            v[i]=0;
    }

    ~BIT() { delete[] v; }

    void update(int index, int surplus)
    {
        while(index<=n)
        {
            v[index]+=surplus;
            index+=(index & (-index));
        }
    }

    int getCummulative(int index)
    {
        int cum=0;
        while(index!=0)
        {
            cum+=v[index];
            index-=(index & (-index));
        }
        return cum;
    }

    int findCumSum(int sum)
    {
        int mask=n;
        while(mask - (mask & (-mask)) != 0)
            mask-=(mask&(-mask));

        int index=0;
        while(mask!=0)
        {
            int tindex=index+mask;

            if(v[tindex]==sum)
                return tindex;
            else if(v[tindex]<sum)
            {
                sum-=v[tindex];
                index=tindex;
            }

            mask>>=1;
        }

        if(sum!=0)
            return -1;
        return index;
    }
};

int main() {

    int n, m;
    in>>n>>m;

    BIT bit(n);
    for(int i=1;i<=n;i++)
    {
        int x;
        in>>x;
        bit.update(i, x);
    }

    while(m)
    {
        m--;

        int code;
        in>>code;

        if(code==0)
        {
            int a, b;
            in>>a>>b;

            bit.update(a, b);
        }
        else if(code==1)
        {
            int a, b;
            in>>a>>b;

            out<<bit.getCummulative(b)-bit.getCummulative(a-1)<<'\n';
        }
        else
        {
            int a;
            in>>a;

            out<<bit.findCumSum(a)<<'\n';
        }
    }

    return 0;
}
