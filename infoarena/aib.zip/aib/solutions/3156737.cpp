#include <bits/stdc++.h>
#ifdef LOCAL
#define in cin
#define out cout
#endif

using namespace std;

#ifndef LOCAL
ifstream in("aib.in");
ofstream out("aib.out");
#endif

struct aint
{
    int nxtp2(int n)
    {
        int p=1;
        while(p<n)
        {
            p*=2;
        }
        return p;
    }
    int offset;
    int *data;
    aint(int n=0)
    {
        offset=nxtp2(n);
        data = new int[offset*2];
        for(int i=0;i<offset*2;i++)data[i]=0;
    }
    void update(int poz,int val)
    {
        data[offset+poz]+=val;
        for(poz = (poz + offset)/2;poz>0;poz/=2)
        {
            data[poz]=data[poz*2]+data[poz*2+1];
        }
    }
    int query(int l,int r)
    {
        return _query(l,r,0,offset-1,1);
    }
    int _query(int l,int r,int st,int dr,int node)
    {
        if(l>r)return 0;
        if(l==st&&l==dr)return data[node];
        int mid=(st+dr)/2;
        return _query(l,min(r,mid),st,mid,node*2)+
               _query(max(l,mid+1),r,mid+1,dr,node*2+1);
    }
    int _cb(int l,int x,int &sum,int st,int dr,int node)
    {
        if(dr<l)return dr;
        //cerr<<st<<' '<<dr<<'\n';
        if(l<=st && data[node] + sum <= x)
        {
            sum+=data[node];
            return dr;
        }
        if(st==dr)
        {
            return st-1;
        }
        int mid=(st+dr)/2;
        int res = _cb(l,x,sum,st,mid,node*2);
        if(res<mid)return res;
        if(res==mid)return _cb(l,x,sum,mid+1,dr,node*2+1);
        return 0;
    }
    int cb(int x,int l=0)
    {
        int sum=0;
        int res = _cb(l,x,sum,0,offset-1,1);
        if(sum==x)return res+1;
        return -1;
    }
} root;

int main()
{
    int n,q;in>>n>>q;
    root=aint(n);
    for(int i=0;i<n;i++)
    {
        int nr;in>>nr;
        root.update(i,nr);
    }
    for(int i=0;i<q;i++)
    {
        int c;in>>c;
        if(c==0)
        {
            int a,b;in>>a>>b;
            a--;
            root.update(a,b);
        }
        else if(c==1)
        {
            int a,b;in>>a>>b;
            a--;
            b--;
            out<<root.query(a,b)<<'\n';
        }
        else
        {
            int a;in>>a;
            out<<root.cb(a)<<'\n';
        }
    }
}
