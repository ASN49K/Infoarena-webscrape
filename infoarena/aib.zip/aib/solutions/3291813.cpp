#include <fstream>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m, op, a, b;
int v[100005];

void build_tree(int* v){
    for (int i=1; i<=n; i++){
        int parent_index = i + (i & -i);
        //fout << "i: " << i << " parent index: " << parent_index << '\n';
        if (parent_index <= n){
            v[parent_index] += v[i];
        }
    }
}

void add(int i, int k){
    while (i <= n){
        v[i] += k;
        i += (i & -i);
    }
}

int sum(int i){
    int sum = 0;
    while (i > 0){
        sum += v[i];
        i -= (i & -i);
    }
    return sum;
}

int find_position(int searched_sum){
    int left = 1, right = n, mid;
    while (left <= right){
        mid = (left + right)/2;
        if (sum(mid) <= searched_sum){
            left = mid + 1;
        }
        else{
            right = mid - 1;
        }
    }
    return right;
}

int main(){
    fin >> n >> m;
    for (int i=1; i<=n; i++){
        fin >> v[i];
    }
    build_tree(v);
    /*for (int i=1; i<=n; i++){
        fout << v[i] << ' ';
    }*/
    while (m--){
        fin >> op;
        if (op == 0){
            fin >> a >> b;
            add(a, b);
        }
        else if (op == 1){
            fin >> a >> b;
            fout << sum(b) - sum(a - 1) << '\n';
        }
        else{
            fin >> a;
            fout << find_position(a) << '\n';
        }
    }
    return 0;
}
