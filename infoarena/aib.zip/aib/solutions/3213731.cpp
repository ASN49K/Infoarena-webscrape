#include <bits/stdc++.h>
#define MOD 1999999973
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, Q;
int aib[100005];

void Update(int poz, int val)
{
    while (poz <= n)
    {
        aib[poz] += val;
        poz += (poz & (-poz));
    }
}

int Query(int poz)
{
    int sum = 0;
    while (poz > 0)
    {
        sum += aib[poz];
        poz -= (poz & (-poz));
    }
    return sum;
}

int CautBin(int x)
{
    int st, dr, p, mij, s;
    st = 1; dr = n;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        s = Query(mij);
        if (s == x) return mij;
        if (s < x) st = mij + 1;
        else dr = mij - 1;
    }
    return 0;
}

int main()
{
    int op, x, y;
    fin >> n >> Q;
    for (int i = 1; i <= n; i++)
    {
        fin >> x;
        Update(i, x);
    }
    while (Q--)
    {
        fin >> op;
        if (op == 0)
        {
            fin >> x >> y;
            Update(x, y);
        }
        else if (op == 1)
        {
            fin >> x >> y;
            fout << Query(y) - Query(x - 1) << "\n";
        }
        else
        {
            fin >> x;
            fout << CautBin(x) << "\n";
        }
    }
    return 0;
}
