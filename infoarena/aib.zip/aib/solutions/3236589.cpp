#include <fstream>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

int n, m, AIB[100005], caz, a, b, val;

int zeros(int i)
{
    return i & -i;
}

void update(int poz, int val)
{
    for (; poz <= n; poz += zeros(poz)) {
        AIB[poz] += val;
    }
}

int query(int poz)
{
    int sum = 0;

    for (; poz; poz -= zeros(poz)) {
        sum += AIB[poz];
    }

    return sum;
}

int cautare(int val)
{
    int step = (1 << n), rez = 0;

    for (; step; step >>= 1) {
        if (rez + step <= n && AIB[rez + step] <= val) {
            rez += step;
            val -= AIB[rez];

            if (!val) {
                return rez;
            }
        }
    }
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= n; ++i) {
        f >> val;

        update(i, val);
    }

    while (m--) {
        f >> caz;

        if (caz == 0) {
            f >> a >> b;
            update(a, -b);
        }
        else if (caz == 1) {
            f >> a >> b;

            g << query(b) - query(a - 1) << '\n';
        }
        else {
            f >> a;

            g << cautare(a) << '\n';
        }
    }

    return 0;
}
