#include <fstream>

using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n,q,A[100005];
long long aib[100005];
void update(int x,long long val)
{
    for(int i=x;i<=n;i+=i&(-i))
        aib[i]+=val;
}
long long query(int x)
{
    long long ans=0;
    for(int i=x;i>=1;i-=i&(-i))
        ans+=aib[i];
    return ans;
}
int main()
{
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>A[i],update(i,A[i]);
    int op,a,b;
    for(int i=1;i<=q;i++)
    {
        cin>>op>>a;
        if(op==0 || op==1)
            cin>>b;
        if(op==0)
            update(a,b);
        else if(op==1)
            cout<<query(b)-query(a-1)<<"\n";
        else
        {
            long long sum=0,pos=0;
            for(int bit=17;bit>=0;bit--)
            {
                if(pos+(1<<bit)<=n && sum+aib[pos+(1<<bit)]<a)
                {
                    sum+=aib[pos+(1<<bit)];
                    pos+=(1<<bit);
                }
            }
            pos++;
            if(pos>n || query(pos)!=a)
                cout<<"-1\n";
            else
                cout<<pos<<"\n";
        }
    }
    return 0;
}
