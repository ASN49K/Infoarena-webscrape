#include <fstream>
using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int n,m,v[150002];

int bit(int n)//cel mai nesemnificativ bit de 1
{
    return (n&(-n));
}
void add(int poz,int val)
{
    for(int i=poz; i<=n; i+=bit(i))
        v[i]+=val;
}
int sum(int x)
{
    int s=0;
    for(int i=x; i>0; i-=bit(i))
        s+=v[i];
    return s;
}
int cb(int x)
{
    int st=1,dr=n;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        int s=sum(mij);
        if(s==x)
            return mij;
        else if(s<x)
            st=mij+1;
        else
            dr=mij-1;
    }
    return -1;
}
int main()
{
    cin>>n>>m;
    int x;
    for(int i=1; i<=n; i++)
        {
            cin>>x;
            add(i,x);
        }
    int op,a,b;
    while(m--)
    {
        cin>>op>>a;
        if(op!=2)
        {
            cin>>b;
            if(op==0)
                add(a,b);
            else
                cout<<sum(b)-sum(a-1)<<'\n';
        }
        else
            cout<<cb(a)<<'\n';
    }
    return 0;
}
