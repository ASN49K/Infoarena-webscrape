
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
 int aib[100002], n,m;

ifstream in("aib.in");
ofstream out("aib.out");

void update(int poz, int val) {
  for (int i = poz; i <= n; i += (i & (-i) )   )
    aib[i]=aib[i]+val;
}

int sum(int poz) {
  // v[1]+.......v[poz]
  int s = 0;
  for (int i = poz; i >= 1; i -= (i & (-i) ))
    s += aib[i];
  return s;
}

int main(){

    in >> n>>m;
    for (int i = 1; i <= n; i++) {
      int x;
      in >> x;
      update(i,x);
    }
    for (int i = 1; i <= m; i++) {
      int t, a, b;
      in >> t;
      if (t == 0) {
        in >> a >> b;
        update(a, b);
      }
      else if (t == 1) {
        in >> a >> b;
        out << sum(b) - sum(a - 1) << "\n";
      }
      else {
        in>>a;
        // sum(1)<=sum(2)....sum(dr).sum(st).sum(n)
        //                     <a      >=a
        //     d s
        // 1 2 3 4 5 6 7 8
        // 4 4 6 7 7 7 7 9      a=7
        int st = 1, dr = n, ok = 0;
        while (st <= dr) {
          int mij = (st + dr) / 2;
          int tmp = sum(mij);
          //  sum(st)....a...a..sum(mij).....a.....sum(dr)
         if (tmp < a)
            st = mij + 1;
          else
            dr = mij - 1;
        }

        if(sum(st)==a)out<<st<<'\n';
             else out<<-1<<'\n';


      }
    }
     return 0;
}
