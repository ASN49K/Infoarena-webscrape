#include <bits/stdc++.h>

using namespace std;

#ifdef ONLINE_JUDGE
    constexpr int nmax = 1e5 + 5;
#else
    constexpr int nmax = 21;
#endif

int n, m;
int aib[nmax];

void update(int pos, int val) {
    if (pos > n)
        return;
    aib[pos] += val;
    update(pos + (pos & -pos), val);
}

int query(int pos, int sum = 0) {
    if (pos > n)
        return query(n);
    if (pos <= 0)
        return sum;
    return query(pos - (pos & -pos), sum + aib[pos]);
}

int query_int(int a, int b) {
    return query(b) - query(a - 1);
}

int bin_search(int val)
{
    int ans = 0;
    for (int p = 17; p >= 0; p--)
    {
        int idx = ans + (1 << p);
        if (idx > n) continue;
        if (aib[idx] <= val)
        {
            ans += 1 << p;
            val -= aib[ans];
        }
    }
    return ans;
}

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        int x;
        cin >> x;
        update(i, x);
    }
    while (m--) {
        int op;
        cin >> op;
        switch(op) {
            case 0:
                int pos, val;
                cin >> pos >> val;
                update(pos, val);
                break;
            case 1:
                int a, b;
                cin >> a >> b;
                cout << query_int(a, b) << '\n';
                break;
            case 2:
                int k;
                cin >> k;
                cout << bin_search(k) << '\n';
        }
    }
}