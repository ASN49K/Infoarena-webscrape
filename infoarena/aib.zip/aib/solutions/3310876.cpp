#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <algorithm>
#include <cmath>
#define ll long long

using namespace std;

const ll MOD=1000000007;
const string filename="aib";
ifstream fin(filename+".in");
ofstream fout(filename+".out");
void update(vector<ll> &aib,ll val,ll pos){
    ll x=aib.size();
    while(pos<x){
        aib[pos]+=val;
        pos+=(pos&(-pos));
    }
}
ll prefsum(vector<ll> &aib,ll pos){
    ll sum=0;
    while(0<pos){
        sum+=aib[pos];
        pos-=(pos&(-pos));
    }
    return sum;
}
ll srq(vector<ll> &aib,ll a,ll b){
    return prefsum(aib,b)-prefsum(aib,a-1);
}

int main()
{
    ll n,m,x,y,z,sum;
    fin>>n>>m;
    vector<ll> v(n+1),aib(n+1,0);
    for(ll i=1;i<=n;i++){
        fin>>v[i];
        update(aib,v[i],i);
    }
    for(ll i=0;i<m;i++){
        fin>>x;
        if(x==0){
            fin>>y>>z;
            update(aib,z,y);
        }
        if(x==1){
            fin>>y>>z;
            fout<<srq(aib,y,z)<<'\n';
        }
        if(x==2){
            fin>>y;
            for(ll i=1;i<=n;i++){
                if(prefsum(aib,i)==y){
                    fout<<i<<'\n';
                    break;
                }
                else if(i==n){
                    fout<<-1<<'\n';
                }
            }

        }
    }
    return 0;
}
