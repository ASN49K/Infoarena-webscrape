#include <fstream>
using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

const int MAX = 1e5 + 1;

int aib[MAX] , t[MAX] , n , q , op , a , b;

int main(){

    cin >> n >> q;

    for(int i = 1 ; i <= n ; i++){

        cin >> aib[i];
    }

    for(int i = 1 ; i <= n ; i++){

        if(i+(i&(-i))<=n) aib[i+(i&(-i))] += aib[i];
    }

    while(q--){

        cin >> op;

        if(op == 0){

            cin >> a >> b;

            while(a<=n){

                aib[a]+=b;

                a+=(a&(-a));
            }
        }

        if(op == 1){

            cin >> a >> b;

            a--;

            int sum = 0;

            while(b){

                sum += aib[b];

                b-=(b&(-b));
            }

            while(a){

                sum -= aib[a];

                a-=(a&(-a));
            }

            cout << sum << '\n';
        }

        if(op == 2){

            cin >> b;

            int st = 1 , dr = n , ans = -1 , sum;

            while(st<=dr){

                int a = (st+dr)/2;

                sum = 0;

                int mij = a;

                while(a){

                    sum += aib[a];

                    a-=(a&(-a));
                }

                a = mij;

                if(sum == b){

                    ans = a;

                    dr = a - 1;

                }else if(sum < b){

                    st = a+1;

                }else dr = a - 1;
            }

            cout << ans << '\n';
        }
    }

    return 0;
}
