#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
const int MAX_N = 100010;

int n;
int nrop;
int op;
long a, b;
int x;
long v[MAX_N] = {0};

void update(int a, int b) {
    for (int i = a; i <= n; i += (i & -i)) {
        v[i] += b;
    }
}

int sum(int b) {
    int s = 0;
    for (int i = b; i >= 1; i -= (i & -i)) {
        s += v[i];
    }
    return s;
}

int findK(long target) {
    int st = 1;
    int dr = n;
    int mini = n + 1;
    while (st <= dr) {
        int m = (st + dr) / 2;
        if (target <= sum(m)) {
            mini = m;
            dr = m - 1;
        } else {
            st = m + 1;
        }
    }
    if (mini > n) {
        return -1;
    }
    return mini;
}

int main() {
    fin >> n >> nrop;
    for (int i = 1; i <= n; ++i) {
        fin >> x;
        update(i, x);
    }
    for (int i = 1; i <= nrop; ++i) {
        fin >> op >> a;
        if (op == 0) {
            fin >> b;
            update(a, b);
        }
        else if (op == 1) {
            fin >> b;
            fout << sum(b) - sum(a - 1) << '\n';
        }
        else if (op == 2) {
            fout << findK(a) << '\n';
        }
    }

    return 0;
}
