#include <iostream>
#include <fstream>

using namespace std;

int n, m, a, b, op, numar;
int aib[10000];

int construct (int nr, int ind);
int update (int ind, int val);
int suma (int right);
int interval (int left, int right);

int main()
{
    ifstream cin ("aib.in");
    ofstream cout ("aib.out");

    cin >> n >> m;
    if (n >= 10000)
    {
        return -1;
    }
    for (int i=1; i<=n; i++)
    {
        cin >> numar;
        aib[i] += numar;
        construct (aib[i], i);
    }
    for (int i=0; i<m; i++)
    {
        cin >> op;
        if (op == 0)
        {
            cin >> a >> b;
            update (a, b);
        }
        else if (op == 1)
        {
            cin >> a >> b;
            cout << interval (a, b) << endl;
        }
        else if (op == 2)
        {
            cin >> a;
            for (int k=1; k<=n; k++)
            {
                if (interval(1, k) == a)
                {
                    cout << k << endl;
                    break;
                }
            }
        }
    }
    return 0;
}


int construct (int nr, int ind)
{
    int jnd;
    jnd = ind + (ind & -ind);
    if (jnd <= n)
    {
        aib[jnd] += aib[ind];
    }
}

int update (int ind, int val)
{
    while (ind <= n)
    {
        aib[ind] += val;
        ind += (ind & -ind);
    }
}

int suma (int right)
{
    int sum=0;
    while (right > 0)
    {
        sum += aib[right];
        right -= (right & -right);
    }
    return sum;
}

int interval (int left, int right)
{
    return suma(right) - suma(left - 1);
}

