#include <bits/stdc++.h>
#define NMAX 100000
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n,x,y;
int v[NMAX + 5];
int aint[4 * NMAX + 5];

void create(int node, int l, int r)
{
    if(l == r)
        aint[node] = v[l];
    else
    {
        int mij = (l+r)/2;
        create(2*node, l, mij);
        create(2*node+1, mij + 1, r);
        aint[node] = aint[2*node] + aint[2*node+1];
    }
}

void update(int node, int l, int r)
{
    if(x < l || x > r)
        return;
    if(l == r)
        aint[node] = y;
    else
    {
        int mij = (l+r)/2;
        if(x <= mij)
            update(2*node, l, mij);
        else
            update(2*node+1, mij+1, r);

        aint[node] = aint[2*node] + aint[2*node+1];
    }
}

int query(int node, int l, int r)
{
    if(x > r || y < l)
        return 0;
    if(x <= l && r <= y)
        return aint[node];
    else
    {
        int rez = 0;
        int mij = (l+r)/2;
        if(x <= mij)
            rez += query(2*node, l, mij);
        if(y >= mij)
            rez += query(2*node+1, mij+1, r);
        return rez;
    }
}

int cb(int s)
{
    int st = 1, dr = n;
    x = 1;
    while(st<dr)
    {
        int mij = (st + dr)/2;
        y = mij;
        if(query(1,1,n) >= s)
            dr = mij;
        else
            st = mij+1;
    }
    y = st;
    if(query(1,1,n) != s)
        return -1;
    return st;
}

int main()
{
    int m;
    fin >> n >> m;
    for(int i = 1; i<=n; i++)
        fin >> v[i];
    create(1,1,n);
    for(int i = 1; i<=m; i++)
    {
        int c, a, b;
        fin >> c >> a;
        if(c == 0)
        {
            fin >>  b;
            x = a;
            y = v[a]+b;
            update(1,1,n);
        }
        else if(c == 1)
        {
            fin >> b;
            x = a;
            y = b;
            fout << query(1,1,n) << '\n';
        }
        else if(c == 2)
        {
            fout << cb(a) << '\n';
        }
    }
    return 0;
}
