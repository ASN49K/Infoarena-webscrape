#include <iostream>
#include <fstream>
using namespace std;
int aib[100005];
int n,m;
void update(int p,int val)
{
    while(p<=n){
        aib[p]+=val;
        p=p+(p&(-p));
    }
}
int query(int p){
   int s=0;
   for(;p>0;p-=p&(-p))
      s+=aib[p];
   return s;
}
int main(){
   ifstream f("aib.in");
   ofstream g("aib.out");
   f>>n>>m;
   for(int i=1;i<=n;i++){
      int x; f>>x;
      update(i,x);
   }
   for(int i=0;i<m;i++){
      int t; f>>t;
      if(t==0){
        int a,b; f>>a>>b;
        update(a,b);
      }
      else if(t==1){
        int a,b; f>>a>>b;
        int aux=query(b)-query(a-1);
        g<<aux<<"\n";
      }
      else{
        int a; f>>a;
        int pos=0;
        int s=0;
        for(int pw=131072;pw>0;pw/=2)
           if(pos+pw<=n && s+aib[pos+pw]<=a){
             pos+=pw;
             s+=aib[pos];
           }
        if(s==a) g<<pos<<"\n";
        else g<<-1<<"\n";
      }
   }
   return 0;
}