//https://infoarena.ro/problema/aib

#include <fstream>
#include <vector>

std::ifstream fin("aib.in");
std::ofstream fout("aib.out");

using namespace std;

class ArbIB
{
	vector<long long> v;
	long long size_of_array;
public:
	ArbIB(long long size)
	{
		size_of_array = size;
		v.resize(size + 1,0);
	}
	void Update(long long index, long long val)	
	{
		for (int i = index; i <= size_of_array; i += (i & -i))
			v[i] += val;
	}
	long long Querry(long long st, long long dr)
	{
		return QuerryUtil(dr) - QuerryUtil(st - 1);
	}
	long long Search(long long k)
	{
		long long pos = 0, sum = 0;
		for (int i = 17; i >= 0; --i)
			if (pos + (1 << i) <= size_of_array)
				if (sum + v[pos + (1 << i)] < k)
				{
					sum += v[pos + (1 << i)];
					pos += (1 << i);
				}
		//fout << sum << '\n';
		if (pos + 1 > size_of_array || QuerryUtil(pos+1) != k)
			return -1;
		else
			return pos + 1;
	}
private:
	long long QuerryUtil(long long dr)
	{
		long long sum = 0;
		for (int i = dr; i >= 1; i -= (i & -i))
			sum += v[i];
		return sum;
	}
};
int main()
{
	long long n, m, x, cer, a, b;
	fin >> n >> m;
	ArbIB AIB(n);
	for (long long i = 1; i <= n; ++i)
	{
		fin >> x;
		AIB.Update(i, x);
	}

	while (m--)
	{
		fin >> cer;
		if (cer == 0)
		{
			fin >> a >> x;
			AIB.Update(a, x);
		}
		else if (cer == 1)
		{
			fin >> a >> b;
			fout << AIB.Querry(a, b) << '\n';
		}
		else if (cer == 2)
		{
			fin >> x;
			fout << AIB.Search(x) << '\n';
		}
	}
}