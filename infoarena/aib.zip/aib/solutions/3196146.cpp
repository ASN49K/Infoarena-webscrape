#include <fstream>
#include <iostream>
using namespace std;
const int Vmax = 100001;
int n, m, a[Vmax], aib[Vmax];

void update(int x, int val){
    for(int i=x;i<=n;i+=(i&(-i)))
        aib[i]+=val;
}

int query(int poz){
    int suma = 0;
    for(int i=poz;i>=1;i-=(i&(-i)))
        suma+=aib[i];
    return suma;
}

int query2(int val){
    int i, step;
    for (step=1;step<n;step<<=1); 
    for(i=0;step;step>>=1)
    {
        if(i+step<=n)
        {
            if(val>=aib[i+step]) 
            {
                i+=step;
                val -= aib[i];
                if(!val) return i;
            }
        }
    }
    
    return -1;

}

int main(){
    ifstream fin("aib.in");
    ofstream fout("aib.out");
    fin>>n>>m;
    for(int i=1;i<=n;i++){
        fin>>a[i];
        update(i, a[i]);
    }
    while(m--){
        int question;
        fin>>question;
        if(question == 0){
            int x, val;
            fin>>x>>val;
            update(x, val);
        }
        if(question == 1){
            int poz, poz2;
            fin>>poz>>poz2;
            fout<<query(poz2) - query(poz-1)<<'\n';
        }
        if(question == 2){
            int val;
            fin>>val;
            fout<<query2(val)<<'\n';
        }
    }
}