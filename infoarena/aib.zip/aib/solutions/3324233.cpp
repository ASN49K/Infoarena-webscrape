﻿#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000000
#define MOD 123457
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int aib[100005], n, m, cer, x, y;
void Update(int p, int x)
{
	while (p <= n)
	{
		aib[p] += x;
		p += (p & -p);
	}
}

int query(int p)
{
	int s = 0;
	while (p > 0)
	{
		s += aib[p];
		p -= (p & -p);
	}
	return s;
}
int CB(int k)
{
	int st = 1, dr = n, rez=0;
	while (st <= dr)
	{
		int mij = (st + dr) / 2;
		int val = query(mij);
		if (val == k)
		{
			rez = mij;
			dr = mij - 1;
		}
		else if (val > k)
		{
			dr = mij - 1;
		}
		else
			st = mij + 1;
	}
	return rez;

}
int main()
{
	fin >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		fin >> x;
		Update(i, x);
	}
	while (m--)
	{
		fin >> cer;
		if (cer == 0)
		{
			fin >> x >> y;
			Update(x, y);
		}
		if (cer == 1)
		{
			fin >> x >> y;
			fout << query(y) - query(x-1)<<"\n";
		}
		if (cer == 2)
		{
			fin >> x;
			fout << CB(x) << "\n";
		}
	}

}

