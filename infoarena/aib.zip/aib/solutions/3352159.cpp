#include <fstream>
using namespace std;

ifstream cin ("aib.in");
ofstream cout("aib.out");

long long a[100001], n;

void up(long long i, long long x){
    do a[i] += x;
    while (i += i&-i, i <= n);
}

long long qr(long long i){
    long long r = 0;
    do r += a[i];
    while (i -= i&-i, i);
    return r;
}

long long fd(long long x){
    long long b = 1 << 18;
    long long i = 0;
    do if ((i|b) <= n && a[i|b] <= x) i |= b, x -= a[i];
    while (b >>= 1, b);

    return x ? -1 : i;
}

int main(){
    long long q;
    cin >> n >> q;

    for (long long i = 1; i <= n; i++){
        long long num;
        cin >> num;
        up(i, num);
    }

    for (long long i = 0; i < q; i++){
        long long o, x, y;
        cin >> o;
        if (o < 2){
            cin >> x >> y;
            if (o == 0) up(x, y);
            else cout << qr(y) - qr(x-1) << '\n';
        } else {
            cin >> x;
            cout << fd(x) << '\n';
        }
    }

    return 0;
}
