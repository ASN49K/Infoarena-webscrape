#include <bits/stdc++.h>

using namespace std;

ifstream fin ("aib.in");
ofstream fout ("aib.out");

const int NM = 1e5 + 5;

int n, m;
int aib[NM];

void update (int poz, int val) {
    for (int i = poz; i <= n; i += i & (-i)) {
        aib[i] += val;
    }
}

int query (int poz) {
    int ans = 0;
    for (int i = poz; i > 0; i -= i & (-i)) {
        ans += aib[i];
    }
    return ans;
}

int main() {
    ios_base::sync_with_stdio(false);

    fin >> n >> m;
    for (int i = 1; i <= n; i++) {
        int x; fin >> x;
        update(i, x);
    }
    while (m--) {
        int o; fin >> o;
        if (o == 0) {
            int a, b; fin >> a >> b;
            update(a, b);
        } else if (o == 1) {
            int a, b; fin >> a >> b;
            fout << query(b) - query(a - 1) << '\n';
        } else {
            int k; fin >> k;
            int l = 1, r = n, ans = -1;
            while (l <= r) {
                int mid = l + (r - l) / 2;
                if (query(mid) >= k) {
                    r = mid - 1;
                    ans = mid;
                } else {
                    l = mid + 1;
                }
            }
            if (query(ans) == k) {
                fout << ans << '\n';
            } else {
                fout << -1 << '\n';
            }
        }
    }
}
