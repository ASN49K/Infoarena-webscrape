/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <bits/stdc++.h>
using namespace std;
#define ub(x) ((x)&(-x))
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,aib[100005],a[100005],i,r,y,m,c;
void add(int x,int val)
{
    for(int i=x; i<=n; i+=ub(i)) aib[i]+=val;
}
int sum(int x)
{
    int s=0;
    for(int i=x; i>=1; i-=ub(i)) s+=aib[i];
    return s;
}
int cb(int n,int q)
{
    int st=1,dr=n,mij;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(sum(mij)>q) dr=mij-1;
        else if(sum(mij)<q) st=mij+1;
        else if(sum(mij)==q) return mij;
    }
    return -1;
}
int main()
{
  fin>>n>>m;
  for(i=1; i<=n; i++) {fin>>a[i];add(i,a[i]);}
  for(i=1; i<=m; i++)
  {
      fin>>c;
      if(c==0)
      {
          fin>>r>>y;
          add(r,y);
      }
      if(c==1)
      {
          fin>>r>>y;
         fout<<sum(y)-sum(r-1)<<'\n';
      }
      if(c==2) 
      {
          fin>>r;
          fout<<cb(n,r)<<'\n';
          
      }
  }

    return 0;
}