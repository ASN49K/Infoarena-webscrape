#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int A[100005];
int n, q;
long long query(int p) {
    long long suma = 0;
    for (int i = p; i; i -= (i & -i)) {
        suma += A[i];
    }
    return suma;

}

void update(int p, int val) {

    for (int i = p; i <= n; i += (i & -i)) {
        A[i] += val;
    }


}

int cb(int st, int dr, int val) {


    while (st <= dr) {
        int mij = (st + dr) / 2;
        int aux = query(mij);

        if (aux == val) {
            return mij;
        }
        else if(aux>val) {
            dr = mij;
        }
        else {
            st = mij + 1;
        }
    }


}




int main()
{
    fin >> n >> q;
    int aux;
    for (int i = 1; i <= n; i++) {
        fin >> aux;
        update(i, aux);
    }
    int pos, val, a, b;
    for (int i = 1; i <= q; i++) {
        int t;
        fin >> t;
        if (t == 0) {
            fin >> pos >> val;
            update(pos, val);
        }
        else if (t == 1) {
            fin >> a >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else if (t == 2) {
            fin >> a;

            fout << cb(1, n, a) << '\n';

        }
    }


    fin.close();
    fout.close();

}