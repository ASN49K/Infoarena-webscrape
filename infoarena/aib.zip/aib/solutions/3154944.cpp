#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n,k;
int aib[100001] , v[100001];
void update(int i,int val)
{
    while(i<=n)
    {
        aib[i]+=val;
        i+=i&(-i);

    }

}
int prefix(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=aib[i];
        i-=i&(-i);
    }
    return sum;
}
int range(int i,int j)
{
    return prefix(j)-prefix(i-1);
}
int bs(int sum)
{
    int st=1 , dr=n , cat=1e9;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        if(range(0,mij)==sum)
        {
            if(mij<cat)
                cat=mij;
            dr=mij-1;
        }
        else if(range(0,mij)>sum)
        {
            dr=mij-1;
        }
        else if(range(0,mij)<sum)
        {
            st=mij+1;
        }
    }
    if(cat==1e9)
        return -1;
    return cat;
}
int main()
{
    cin>>n>>k;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        update(i,v[i]);
    }
    while(k--)
    {
        int c;
        cin>>c;
        if(c==0)
        {
            int x,y;
            cin>>x>>y;
            update(x,y);
        }
        else if(c==1)
        {
            int x,y;
            cin>>x>>y;
            cout<<range(x,y)<<'\n';
        }
        else if(c==2)
        {
            int sum;
            cin>>sum;
            cout<<bs(sum)<<'\n';
        }
    }
    return 0;

}

