#include <bits/stdc++.h>
using namespace std;
ifstream f("aib.in");
ofstream g("aib.out");
int aib[100009], pw, n;
void update (int poz, int add)
{
    int i;
    for (i=poz; i<=n; i+=i&-i)
        aib[i]+=add;
}
int querysum (int poz)
{
    int sol=0, i;
    for (i=poz; i>=1; i-=i&-i)
        sol+=aib[i];
    return sol;
}
int queryk (int s)
{
    int p=pw, i=0, ok=0;
    while (p>=1)
    {
        if (aib[i+p]==s)
            ok=1;
        if (aib[i+p]<s)
        {
            s-=aib[i+p];
            i+=p;
        }
        p/=2;
        while (i+p>n && p>=1)
            p/=2;
    }
    if (ok)
        return i+1;
    return -1;
}
int query (int st, int dr)
{
    return querysum(dr)-querysum(st-1);
}
int main ()
{
    int m;
    f >> n >> m;
    for (int i=1; i<=n; i++)
    {
        int x;
        f >> x;
        update (i, x);
    }
    pw=1;
    while (pw<=n)
        pw*=2;
    pw/=2;
    while (m--)
    {
        int tip;
        f >> tip;
        if (!tip)
        {
            int x, y;
            f >> x >> y;
            update (x, y);
        }
        if (tip==1)
        {
            int x, y;
            f >> x >> y;
            g << query(x,y) << '\n';
        }
        if (tip==2)
        {
            int val;
            f >> val;
            g<<queryk(val) <<'\n';
        }
    }
}
