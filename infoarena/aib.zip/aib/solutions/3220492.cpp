#include <fstream>

using namespace std;

ifstream fin ("aib.in");
ofstream fout ("aib.out");

#define NMAX 100008

struct aib
{
    int tree[NMAX];
    int ub (int x)
    {
        return (x & (-x));
    }
    void add (int x, int y, int n)
    {
        int i;
        for (i=x; i<=n; i+=ub(i))
        {
            tree[i]+=y;
        }
    }
    int query(int x)
    {
        int i,rez=0;
        for (i=x; i>=1; i-=ub(i))
        {
            rez+=tree[i];
        }
        return rez;
    }
}arb;

int n,i,j,q,type,st,dr,mij,a,b;

int main()
{
    fin>>n>>q;
    for (i=1; i<=n; i++)
    {
        fin>>a;
        arb.add(i,a,n);
    }
    for (i=1; i<=q; i++)
    {
        fin>>type;
        if (type==0 || type==1)
        {
            fin>>a>>b;
            if (type==0)
            {
                arb.add(a,b,n);
            }
            else
            {
                fout<<arb.query(b)-arb.query(a-1)<<'\n';
            }
        }
        else
        {
            st=0,dr=n+1;
            fin>>a;
            while (dr-st>1)
            {
                mij=(st+dr)/2;
                if (arb.query(mij)>=a)
                {
                    dr=mij;
                }
                else
                {
                    st=mij;
                }
            }
            if (arb.query(dr)==a)
            {
                fout<<dr<<'\n';
            }
            else
            {
                fout<<-1<<'\n';
            }
        }
    }
    return 0;
}
