#include <bits/stdc++.h>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int MAXN = 1e5;
int v[MAXN], N, M;
void aib_set(int n, int x) {
    for (int poz = n; poz <= N; poz += (poz & (-poz)))
        v[poz] += x;
}
int aib_query(int n) {
    int sum = 0;
    for (int poz = n; poz > 0; poz -= (poz & (-poz)))
        sum += v[poz];
    return sum;
}
int minpos(int b) {
    int mask = 1;
    while (mask <= N)
        mask <<= 1;
    mask >>= 1;
    int poz = 0;
    int val = 0;
    for (; mask; mask >>= 1) {
        if (poz + mask <= N && val + v[poz + mask] <= b) {
            val += v[poz + mask];
            poz += mask;
        }
    }
    return poz;
}

int main() {
    fin >> N >> M;
    int x;
    for (int i = 1; i <= N; i++) {
        fin >> x;
        aib_set(i, x);
    }
    int a, b, c;
    while (M--) {
        fin >> a;
        if (a == 0) {
            fin >> b >> c;
            aib_set(b, c);
        } else if (a == 1) {
            fin >> b >> c;
            fout << aib_query(c) - aib_query(b - 1) << '\n';

        } else {
            fin >> b;
            fout << minpos(b) << '\n';
        }
    }
    return 0;
}
