#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void update_aib(vector<int>& aib, int pos, int new_val){
    for(int i=pos; i<aib.size(); i+=(i&-i)){
        aib[i]+=new_val;
    }
}

int query_aib(const vector<int>& aib, int pos){
    int sum=0;

    for(int i=pos; i>0; i-=(i&-i)){
        sum+=aib[i];
    }

    return sum;
}

int search_sum(const vector<int>& aib, int sum){
    int st=1, dr=aib.size();
    while(st<=dr){
        int mij=(st+dr)/2;

        if(query_aib(aib, mij)==sum){
            return mij;
        }

        if(query_aib(aib, mij)<sum){
            st=mij+1;
        }else{
            dr=mij-1;
        }
    }

    return -1;
}

int main(){
    ifstream fin("aib.in");
    ofstream fout("aib.out");

    int lim, nrq; fin>>lim>>nrq;

    vector<int> aib(lim+1);
    for(int i=1; i<=lim; i++){
        int temp; fin>>temp;
        update_aib(aib, i, temp);
    }

    for(int i=0; i<nrq; i++){
        int qtype; fin>>qtype;

        switch(qtype){
            case 0: {
                int pos, val; fin>>pos>>val;
                update_aib(aib, pos, val);

            }break;

            case 1: {
                int p1, p2; fin>>p1>>p2;
                fout<<query_aib(aib, p2)-query_aib(aib, p1-1)<<endl;

            }break;

            case 2: {
                int sum; fin>>sum;
                fout<<search_sum(aib, sum)<<endl;

            }break;
        }
    }

    return 0;
}
