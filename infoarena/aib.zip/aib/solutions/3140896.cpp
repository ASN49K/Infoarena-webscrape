#include<fstream>
using namespace std;
ifstream F("aib.in");
ofstream G("aib.out");
int i,n,a[100001],c[100001],m,j,l,k,r,s,t;
int main()
{
    for(F>>n>>m,i=1;i<=n;F>>a[i],a[i]+=a[i-1],j=i-(i&-i),c[i]=a[i]-a[j],++i);
    for(l=1;l<=n;l<<=1);
    for(;m--;)
        if(F>>i>>j,!i)
            for(F>>k;j<=n;c[j]+=k,j+=(j&-j));
        else if(i<2) {
            for(F>>k,s=t=0;k>0;s+=c[k],k-=(k&-k));
            for(--j;j>0;t+=c[j],j-=(j&-j));
            G<<s-t<<'\n';
        } else {
            for(i=0,r=l;r&&j;r>>=1)
                if(i+r<=n&&j>=c[i+r])
                    i+=r,j-=c[i];
            G<<(!j&&i?i:-1)<<'\n';
        }
    return 0;
}
