#include<iostream>
#include<fstream>
using namespace std;
ifstream in("aib.in");
ofstream out("aib.out");
const int NMAX=100007;
int aib[NMAX],v[NMAX];
int n,m,c;
int a,b;
void up(int i,int val){
    for(;i<=n;i+=i&-i)
    {
        aib[i]+=val;
    }
}
int qersum(int i){//suma pe 1,2,3...,i
    int sum=0;
    for(;i>0;i-=i&-i)
    {
        sum+=aib[i];
    }
    return sum;
}
int qerk(int a){
    int bit=1;
    while(bit<=n)
    {
        bit=bit<<1;
    }
    int k=0;
    while(bit>=2)
    {
        bit=bit>>1;
        k+=bit;
        if(k<=n&&aib[k]<=a)
        {
            a-=aib[k];
        }
        else
        {
            k-=bit;
        }
    }
    return k;
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=n;i++)
    {
        in>>v[i];
        up(i,v[i]);
    }
    for(int j=1;j<=m;j++)
    {
        in>>c;
        if(c==0)
        {
            in>>a>>b;
            up(a,b);
        }
        else if(c==1)
        {
            in>>a>>b;
            out<<qersum(b)-qersum(a-1)<<"\n";
        }
        else{
            in>>a;
            out<<qerk(a)<<"\n";
        }
    }
}
