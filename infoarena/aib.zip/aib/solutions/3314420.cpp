#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");  // strudel
ofstream fout("aib.out");
int a[100010];
int i,n,m,x,y,c;
void update(int p, int v){
    for(int i=p;i<=n;i+=(i&-i))
        a[i]+=v;
}
int sum(int p){
    int sum=0;
    for(int i=p;i>0;i-=(i&-i)) sum+=a[i];
    return sum;
}
int cb(int v){
    int s=1,d=n,mid;
    if(v<sum(s)) return -1;
    if(v==sum(s)) return s;
    if(v>sum(d)) return -1;
    if(v==sum(d)) return d;
    for(mid=(s+d)/2;s<d-1;mid=(s+d)/2){
        int sm=sum(mid);
        if(v==sm) return mid;
        if(v<sm) d=mid;
        else s=mid;
    }
    return -1;
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=n;i++) fin>>x, update(i,x);
    for(i=1;i<=m;i++){
        fin>>c;
        if(c==0) fin>>x>>y, update(x,y);
        else if(c==1) fin>>x>>y, fout<<sum(y)-sum(x-1)<<'\n';
        else fin>>x, fout<<cb(x)<<'\n';

    }
    return 0;
}