#include <bits/stdc++.h>
#define ll long long

using namespace std;

const int nMax=100005;
ll n , m , k , x , y , c , a[nMax] , rez , aib[nMax];

ifstream f("aib.in");
ofstream g("aib.out");

ll sum(ll a)
{
    ll rez=0;
    for(int i=a;i>=1;i-=i&-i) rez+=aib[i];
    return rez;
}

void add(ll a , ll val)
{
    for(int i=a;i<=n;i+=i&-i) aib[i]+=val;
}

int cb(ll x)
{
    int st=1 , dr=n , rez=0;
    while(st<=dr){
        int mij=(st+dr)/2;
        if(sum(mij)>x) dr=mij-1;
        else if(sum(mij)<x) st=mij+1;
        else dr=mij-1 , rez=mij;
    }
    return rez;
}

int main()
{
    f >> n >> m;
    for(int i=1;i<=n;i++) f >> a[i];
    for(int i=1;i<=n;i++){
            add(i , a[i]);
    }
    for(int i=1;i<=m;i++){
        f >> c;
        if(c==0){
            f >> x >> y;
            add(x , y);
        }
        else if(c==1){
            f >> x >> y;
            g << sum(y)-sum(x-1) << '\n';
        }
        else{
            f >> k;
            g << cb(k) << '\n';
        }
    }
}
