#include <fstream>
#include <vector>

using namespace std;

vector <int> v( 1000000 , 0);
int n,m;

ifstream cin("aib.in");
ofstream cout("aib.out");

void update(int i,int val)
{
    while(i<=n)
    {
        v[i]+=val;
        i+= ( i & (-i) );
    }
}
int prequerry(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=v[i];
        i-= ( i & (-i) );
    }
    return sum;
}

int querry(int i,int j)
{
    return prequerry(j)-prequerry(i-1);
}

int main()
{
    int a,b,c;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        cin>>a;
        update(i,a);
    }
    for(int i=1;i<=m;i++)
    {
        cin>>a>>b;
        if(a==0)
        {
            cin>>c;
            update(b,c);
        }
        else if(a==1)
        {
            cin>>c;
            cout<<querry(b,c)<<'\n';
        }
        else
        {
            int st=1,dr=n , mid=0, ok=0;
            while(1)
            {
                mid=(st+dr)/2;
                if(prequerry(mid) < b)
                    st=mid+1;
                else if(prequerry(mid) > b)
                    dr=mid;
                else if(prequerry(mid) == b)
                {
                    cout<<mid<<'\n';
                    ok=1;
                    break;
                }
                if(mid == st)
                {
                    cout<<-1<<'\n';
                    ok=1;
                    break;
                }
            }
        }
    }
    return 0;
}
