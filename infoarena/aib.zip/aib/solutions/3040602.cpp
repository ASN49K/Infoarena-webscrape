#include <bits/stdc++.h>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int aib[100005];
int a[100005];
int n,m,sol;

void Downdate(int p,int v){
    while(p<=n){
        aib[p]+=v;
        p+=(p&(-p));
    }
}

int Query(int p){
    int sum=0;
    while(p>0){
        sum+=aib[p];
        p-=(p&(-p));
    }
    return sum;
}

int main()
{
    int i,st,dr,mij,c,x,y;
    fin >> n >> m;
    for(i=1;i<=n;i++){
        fin >> a[i];
        Downdate(i,a[i]);
    }
    while(m--){
        fin >> c;
        if(c==0){
            fin >> x >> y;
            Downdate(x,y);
        }
        else if(c==1){
            fin >> x >> y;
            fout << Query(y)-Query(x-1);
        }
        else{
            fin >> x;
            st=1;dr=n;
            sol=-1;
            while(st<=dr){
                mij=(st+dr)/2;
                y=Query(mij);
                if(y==x){
                    sol=mij;
                    dr=mij-1;
                }
                else if(y<x){
                    st=mij+1;
                }
                else dr=mij-1;
            }
            fout << sol;
        }
        if(c!=0) fout << "\n";
    }
    return 0;
}
