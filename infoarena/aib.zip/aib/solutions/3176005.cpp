#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;
#define MOD 666013


ifstream fin("aib.in");
ofstream fout("aib.out");

int a[100001];
int n,q;
int stot;
void update(int l,int v)
{
    stot += v;
    for(int i=l;i<=n;i+=(i&-i))
    {
        a[i]+=v;
    }
}
int query(int x)
{
    int res=0;
    for(int i=x;i>=1;i-=(i&-i))
    {
        res += a[i];
    }
    return res;
}
int main()
{
    fin >> n >> q;
    for(int i=1;i<=n;i++)
    {
        fin >> a[n-i+1];
        stot += a[n-i+1];
    }
    for(int i=1;i<=n;i++)
    {
        if(i+(i&-i) <= n)
        {
            a[i+(i&-i)]+=a[i];
        }
    }
    while(q--)
    {
        int t,l,r;
        fin >> t;
        if(t==0)
        {
            fin >> l >> r;
            l=n-l+1;
            update(l,r);
        }
        if(t==1)
        {
            fin >> l >> r;
            l=n-l+1;
            r=n-r+1;
            fout << query(l)-query(r-1) << "\n";
        }
        if(t==2)
        {
            fin >> l;
            int sum=0,pos=0;
            for(int i=18;i>=0;i--)
            {
                if(pos + (1<<i) <= n)
                {
                    int t=stot - (sum + a[pos+(1<<i)]);
                    if(t >= l)
                    {
                        sum += a[pos+(1<<i)];
                        pos += 1<<i;
                    }
                }
            }
            if(stot-sum==l && pos<n)
            {
                fout << n-pos << "\n";
            }
            else
            {
                 fout << -1 << "\n";
            }
        }
    }
}
