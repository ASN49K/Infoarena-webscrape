#include<bits/stdc++.h>
using namespace std;
int aib[100001],m,n,x,tip,a,b,k;
void update(int aa,int bb){
    for(;aa<=n;aa+=aa&(-aa)) aib[aa]+=bb;
}
int queryan(int i){
    int ans=0;
    for(;i;i-=i&(-i)) ans+=aib[i];
    return ans;
}
int query1(int aa,int bb){
    return queryan(bb)-queryan(aa-1);
}
int query2(int kk){
    int low=1,high=n,ans=-1;
    while(low<=high){
        int mid=(low+high)/2,p=queryan(mid);
        if(p<=kk){
            low=mid+1;
            if(p==kk){
                if(ans==-1) ans=mid;
                else ans=min(ans,mid);
            }
        }
        else high=mid-1;
    }
    return ans;
}
int main(){
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>x;
        update(i,x);
    }
    for(int i=1;i<=m;i++){
        cin>>tip;
        if(tip==0){
            cin>>a>>b;
            update(a,b);
        }
        if(tip==1){
            cin>>a>>b;
            cout<<query1(a,b)<<' ';
        }
        if(tip==2){
            cin>>k;
            cout<<query2(k)<<' ';
        }
    }
}