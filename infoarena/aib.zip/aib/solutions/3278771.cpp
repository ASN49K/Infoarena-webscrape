#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

const int kMaxN=100'000;
const int kMaxM=100'000;

int fen_tree[kMaxN];
int nr_val,nr_op;

void Update(int pos,int x)
{
  while (pos<=nr_val)
  {
    fen_tree[pos]+=x;
    pos+=pos&-pos;
  }
}

int Query(int pos)
{
  int sum=0;
  while (pos>0)
  {
    sum+=fen_tree[pos];
    pos-=pos&-pos;
  }
  return sum;
}

int BinSearch(int val)
{
  int left=1,right=nr_val-1;
  while (left<=right)
  {
    int mid=(left+right)/2;
    if (val<=Query(mid))
      right=mid-1;
    else
      left=mid+1;
  }
  if (Query(left)!=val)
    return -1;
  return left;
}

int main()
{
  fin>>nr_val>>nr_op;
  for (int i=1;i<=nr_val;++i)
  {
    int x;
    fin>>x;
    Update(i,x);
  }
  for (int i=1;i<=nr_op;++i)
  {
    int command;
    fin>>command;
    switch (command)
    {
      case 0:
      {
        int pos,val;
        fin>>pos>>val;
        Update(pos,val);

        break;
      }
      case 1:
      {
        int from,to;
        fin>>from>>to;
        fout<<Query(to)-Query(from-1)<<"\n";
        break;
      }
      case 2:
      {
        int val;
        fin>>val;
        fout<<BinSearch(val)<<"\n";
        break;
      }
      default:
        break;
    }
  }
  return 0;
}