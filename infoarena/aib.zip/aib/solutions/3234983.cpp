#include <bits/stdc++.h>
using namespace std;

ifstream fin("birocratie.in");
ofstream fout("birocratie.out");

int dx[]={0,1,1,-1};
int dy[]={1,0,-1,1};
priority_queue <pair<int,pair<int,int>>> q;
int a[1005][1005];
int dp[1005][1005];
int n;
bool v[1005][1005];

bool Int(int x,int y){
    return (x>0 && y>0 && x<=n && y<=n);
}

void Djik(int x,int y){
    int i,j,k;
    dp[x][y]=a[x][y];
    q.push({a[x][y],{x,y}});
    while(!q.empty()){
        x=q.top().second.first;
        y=q.top().second.second;
        q.pop();
        if(!v[x][y]){
            v[x][y]=1;
            for(k=0;k<4;k++){
                i=x+dx[k];
                j=y+dy[k];
                if(Int(i,j) and dp[x][y]+a[i][j]>dp[i][j]){
                    dp[i][j]=dp[x][y]+a[i][j];
                    q.push({dp[i][j],{i,j}});
                }
            }
        }
    }
}

void Fill(int x,int y){
    for(i=1;i<=n;i++)
    {
        if(a[i][i]>mak){
            mak = a[i][i];
            p=i;
        }
    }
    for(j=1;j<=i;j++) s+=
}


int main()
{
    int i,j;
    fin >> n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            fin >> a[i][j];
    if(a[2][1]>0) fout << (2*n+1) * a[1][1];
    else if(a[2][2]>0){
        Lee();
    }
    else fout << (2*n-1) * a[1][1];
    return 0;
}
/**
1 3 8 4 18
2 5 -4 -2 12
2 5 -3 11 14
4 16 15 10 24
16 18 20 25 29

1 6 16 18 20
4 14 10 22 21
11 27 23 16 26
18 28 26 24 31
25 21 25 29 30

1 4 12 20 7
5 15 6 9 2
7 16 17 0 3
14 19 11 2 7
9 2 5 5 6
*/
