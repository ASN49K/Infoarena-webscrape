#include <bits/stdc++.h>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

int v[100001], n, m, x[100001], c;

int LSB(int a)
{
    return a&(a^(a-1));
}

void update(int poz, int val)
{
    while(poz<=n)
    {
        x[poz]+=val;
        poz+=LSB(poz);
    }
}

int query(int poz)
{
    int s=0;
    while(poz>=1)
    {
       s+=x[poz];
       poz-=LSB(poz);
    }
    return s;
}

int cb(int s)
{
    int nod=0;
    for(int i=16; i>=0; i--)
    {
        if(x[nod+(1<<i)]<=s && nod+(1<<i)<=n)
            s-=x[nod+(1<<i)], nod=nod+(1<<i);
    }
    return nod;
}

int main()
{
    f>>n>>m;
    for(int i=1; i<=n; i++)
    {
        f>>v[i];
        v[i]=v[i-1]+v[i];
    }
    for(int i=1; i<=n; i++)
    {
        int st=i-LSB(i), dr=i;
        x[i]=v[dr]-v[st];
    }
    for(int i=1; i<=m; i++)
    {
        f>>c;
        if(c==0)
        {
            int poz, val;
            f>>poz>>val;
            update(poz, val);
        }
        else if(c==1){
            int a, b;
            f>>a>>b;
            g<<query(b)-query(a-1)<<'\n';
        }
        else
        {
            int s;
            f>>s;
            g<<cb(s)<<'\n';
        }
    }
    return 0;
}
