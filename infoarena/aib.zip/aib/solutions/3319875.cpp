#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int lsb(int x) {
    return x & (-x);
}

void build_aib(long long a[], int n) {
    int pow2 = 1;

    while (pow2 <= n) {
        for (int i = pow2; i <= n; i += 2 * pow2) {
            for (int j = i - 1; j > i - pow2; j -= lsb(j)) {
                a[i] += a[j];
            }
        }

        pow2 *= 2;
    }
}

void update(int v, int p, long long a[], int n) {
    for (int i = p; i <= n; i += lsb(i)) {
        a[i] += v;
    }
}

int query_sum(int p, long long a[], int n) {
    int sum = 0;

    for (int i = p ; i > 0; i -= lsb(i)) {
        sum += a[i];
    }

    return sum;
}

int main() {
    int n; 
    long long A[100005];
    int m;
    fin >> n >> m;

    for (int i = 1; i <= n; i++) {
        fin >> A[i];
    }

    build_aib(A, n);

    for (int i = 1; i <= m; i++) {
        int c, a, b;
        fin >> c >> a;

        if (c < 2) {
            fin >> b;

            if (c == 0) {
                update(b, a, A, n);
            } else {
                fout << query_sum(b, A, n) - query_sum(a - 1, A, n) << '\n';
            }
        } else {
            int ans = 0;
            long long sum = 0;

            for (int pas = 1 << 17; pas > 0; pas /= 2) {
                if (ans + pas <= n && sum + A[ans + pas] <= a) {
                    ans += pas;
                    sum += A[ans];
                }
            }

            if (sum == a && ans != 0) {
                fout << ans << '\n';
            } else {
                fout << -1 << '\n';
            }
        }
    }

    return 0;
}
