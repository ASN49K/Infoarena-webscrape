#include <bits/stdc++.h>

using namespace std;

namespace BIT {
  vector<int> bit;
  int n;
  
  int lsb(int x) {
    return x & -x;
  }
  
  void init(int _n) {
    n = _n;
    bit.resize(n + 1);
    for (int i = 0; i <= n; i++)
      bit[i] = 0;
  }
  
  void update(int pos, int val) {
    if (pos == 0)
      return;
    for (int i = pos; i <= n; i += lsb(i))  
      bit[i] += val;
  }
  
  int query(int pos) {
    int ans = 0;
    for (int i = pos; i > 0; i -= lsb(i))
      ans += bit[i];
    return ans;
  }
  
  int query(int left, int right) {
    return query(right) - query(left - 1);
  }
  
  int binarySearch(int sum) {
    int ans = 0;
    for (int jump = (1 << 17); jump > 0; jump >>= 1)
      if (ans + jump <= n && bit[ans + jump] <= sum) {
        ans += jump;
        sum -= bit[ans];
        if (sum == 0)
          return ans;
      }
    return -1;
  }
}

signed main() {
  ifstream fin("aib.in");
  ofstream fout("aib.out");
  int n, q;
  fin >> n >> q;
  BIT::init(n);
  for (int i = 1; i <= n; i++) {
    int x;
    fin >> x;
    BIT::update(i, x);
  }
  while (q--) {
    int type;
    fin >> type;
    if (type == 0) {
      int pos, val;
      fin >> pos >> val;
      BIT::update(pos, val);
    } else if (type == 1) {
      int left, right;
      fin >> left >> right;
      fout << BIT::query(left, right) << '\n';
    } else {
      int sum;
      fin >> sum;
      fout << BIT::binarySearch(sum) << '\n';
    }
  }
  fin.close();
  fout.close();
  return 0;
}