#include <fstream>
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int aib[100005], n, v[100005];
void update(int pos, int val){
    while(pos<=n){
        aib[pos]+=val;
        pos+=(pos&(-pos));
    }
}
int query(int pos){
    int sum = 0;
    while(pos>0){
        sum+= aib[pos];
        pos-=(pos&(-pos));
    }
    return sum;
}
int main()
{
    int k;
    cin>>n>>k;
    for(int i=1; i<=n; i++){
        cin>>v[i];
        update(i, v[i]);
    }
    for(int i=0; i<k; i+=1){
        int x;
        cin>>x;
        if(x==0){
            int a, b;
            cin>>a>>b;
            update(a, b);
        }
        else if(x==1){
            int a, b;
            cin>>a>>b;
            swap(a, b);
            cout<<query(a)-query(b-1)<<"\n";
        }
        else {
            int a;
            cin>>a;
            int l=1, r=n;
            bool ok=true;
            while(l<=r){
                int mid=(l+r)/2;
                if(query(mid)==a){
                    cout<<mid<<"\n";
                    ok=false;
                    break;
                }
                else if(query(mid)>a){
                    r=mid-1;
                }
                else l=mid+1;
            }
            if(ok) cout<<"-1\n";
        }
    }
}