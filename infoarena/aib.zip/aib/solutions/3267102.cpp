#include <iostream>
#include <fstream>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

int n, queries;
int arr[100005], aib[100005];

void update (int x, int value){
    for (int i=x; i<=n; i+=(i&-i)){
        aib[i] += value;
    }
}

int query (int x){
    int rez = 0;
    for (int i=x; i>0; i-=(i&-i)){
        rez += aib[i];
    }
    return rez;
}

int special (int sum){
    int start = 0, aux = 0;
    int viz[200001] = {0};

    start = 1;
    while (1){
        if (viz[start])
            break;
        viz[start] = true;

        aux = query(start);
        if (aux > sum)
            start -= (start&-start);
        else if (aux < sum)
            start += (start&-start); 
        else
            return start;

    }
    return -1;
}

int main (){
    in >> n >> queries;

    for (int i=1; i<=n; ++i){
        in >> arr[i];
        update(i, arr[i]);
    }

    int op, x, y;
    for (int i=1; i<=queries; ++i){
        in >> op;
        if (op == 0){
            in >> x >> y;
            update(x, y);
        }
        if (op == 1){
            in >> x >> y;
            out << (query(y) - query(x-1)) << '\n';
        }
        if (op == 2){
            in >> x;
            out << special(x) << '\n';
        }
    }

    return 0;
}