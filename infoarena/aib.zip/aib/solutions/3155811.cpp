#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int n, op, x, y, m, a[100002], i;

static inline int ub(int nr) {
    return (nr & -nr);
}

static inline void add(int poz, int val) {
    for(int i = poz; i <= n; i += ub(i)) a[i] += val;
}

static inline int sum(int poz) {
    int nm = 0;
    for(int i = poz; i >= 1; i -= ub(i)) nm += a[i];
    return nm;
}

static inline int cb(int val) {
    int st = 1, dr = n;
    int poz = 0;
    while(st <= dr) {
        int mij = st + (dr - st) / 2;
        int s = sum(mij);

        if(s >= val) {
            dr = mij - 1;
            poz = mij;
        }
        else st = mij + 1;
    }
    return poz;
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= n; i++) {
        fin >> x;
        add(i, x);
    }
    while(m--) {
        fin >> op;
        if(op == 0) {
            fin >> x >> y;
            add(x, y);
        }
        else if(op == 1) {
            fin >> x >> y;
            fout << sum(y) - sum(x - 1) << "\n";
        }
        else {
            fin >> x;
            int c = cb(x);
            if(sum(c) == x) fout << c << "\n";
            else fout << "-1\n";
        }
    }

    return 0;
}
