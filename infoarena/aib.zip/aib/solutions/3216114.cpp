#include <iostream>

using namespace std;

int aib[100005], n;

void Update(int poz, int val)
{
    for (int i = poz; i <= n; i += (i & -i))
        aib[i]+=val;
}

int Prefix(int until)
{
    int sum = 0;
    for (int i = until; i >= 1; i -= (i & -i))
        sum+=aib[i];
    return sum;
}

int Sum(int a, int b)
{
    return Prefix(b) - Prefix(a-1);
}

int main()
{
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    cin.tie(0)->sync_with_stdio(0);
    int t;
    cin >> n >> t;
    for (int i = 1; i <= n; i++)
    {
        int q;
        cin >> q;
        Update(i, q);

    }

    while(t--)
    {

        int op, x, y;
        cin >> op;
        if (op == 0)
        {
            cin >> x >> y;
            Update(x, y);
        }
        else if (op==1)
        {
            cin >> x >> y;
            cout << Sum(x, y) << '\n';
        }
        else
        {
            int z;
            cin >> z;
            int l = 1, r = n;
            int mid=0;
            while (l <= r)
            {
                 mid = (l + r) / 2;
                if (Prefix(mid) < z)
                {
                    l = mid+1;

                }
                else if (Prefix(mid) > z)
                {
                    r = mid-1;
                }
                else
                {
                    break;
                }

            }
            if (Prefix(mid)==z)
                cout << mid << '\n';
            else
                cout << -1 << '\n';
        }
    }
    return 0;
}
