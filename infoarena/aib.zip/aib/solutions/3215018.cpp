#include <bits/stdc++.h>
using namespace std;
ifstream in("aib.in");
ofstream out("aib.out");
int n,m,a[100000],v[100000],i,j,l,k,x,y,z,s;
int main()
{
    in>>n>>m;
    for(i=1;i<=n;i++){  
        in>>a[i];
        v[i]+=v[i-1];
    }
    for(j=1;j<=m;j++){
        in>>x;
        if(x==0){
            in>>y>>z;
            for(l=y;l<=n;l++)
                v[l]+=z;
        }
        else if(x==1){
            in>>y>>z;
            out<<v[z]-v[y-1]<<endl;
        }
        else if(x==2){
            in>>y;
            int st=1,dr=n,mij;
            k=-1;
            while(st<=dr){
                mij=(st+dr)/2;
                if(mij==y)
                    k=mij;
                else if(mij>y)
                    st=mij;
                else
                    dr=mij;
            }
            out<<k<<endl;
        }
    }
    return 0;
}