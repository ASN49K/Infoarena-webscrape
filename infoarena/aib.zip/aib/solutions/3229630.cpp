#include <bits/stdc++.h>
using namespace std;
#define int long long
int aib[100005];
void update(int x, int y){
    int poz=x;
    while(poz<=100000){
        aib[poz]+=y;
        poz+=(poz&-poz);
    }
}
int presum(int x){
    int poz=x, sum=0;
    while(poz>=1){
        sum+=aib[poz];
        poz-=(poz&-poz);
    }
    return sum;
}
int32_t main(){
    ifstream cin ("aib.in");
    ofstream cout ("aib.out");
    int n, a, tip, b, q;
    cin >> n >> q;
    for(int i=1; i<=n; i++){
        cin >> a;
        update(i, a);
    }
    for(int i=1; i<=q; i++){
        cin >> tip;
        if(tip!=2)
            cin >> a >> b;
        if(tip==0)
            update(a, b);
        if(tip==1)
            cout << presum(b)-presum(a-1) << '\n';
        if(tip==2){
            cin >> a;
            int poz=0, s=0;
            for(int j=17; j>=0; j--){
                if(poz+(1<<j)<=n && s+aib[poz+(1<<j)]<=a){
                    s+=aib[poz+(1<<j)];
                    poz+=(1<<j);
                }
            }
            if(s!=a || poz>n)
                cout << "-1\n";
            else
                cout << poz << '\n';
        }
    }
    return 0;
}