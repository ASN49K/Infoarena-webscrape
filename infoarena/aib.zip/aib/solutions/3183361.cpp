#include <iostream>
using namespace std;
const int MAX = 100000;
int N, M;
long long aib[MAX + 3];
int x;
int TIP;
int a, b;

int ub(int x) {
    return x & (-x);
}


void update(int x, int val) {
    for(int i = x; i <= N; i += ub(i)) {
        aib[i] += val;
    }
}

int sum(int x) {
    int s = 0;
    for(int i = x; i >= 1; i -= ub(i)) {
        s += aib[i];
    }
    return s;
}

int main() {
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    cin.tie(0);
    ios_base::sync_with_stdio(false);
    cin >> N >> M;
    for(int i = 1; i <= N; i++) {
        cin >> x;
        update(i, x);
    }
    
    for(int i = 1; i <= M; i++) {
        cin >> TIP;
        if(TIP == 0) {
            cin >> a >> b;
            update(a, b);
        }
        if(TIP == 1) {
            cin >> a >> b;
            cout << sum(b) - sum(a - 1) << '\n';
        }
        if(TIP == 2) {
            cin >> a;
            int sum1 = 0, poz = 0;
            for(int j = 17; j >= 0; j--) {
                if(poz + (1 << j) <= N && sum1 + aib[poz + (1 << j)] <= a) {
                    sum1 += aib[poz + (1 << j)];
                    poz += (1 << j);
                }
            }
            if(poz <= N && sum(poz) == a) {
                cout << poz << '\n';
            }
            else cout << "-1\n";
        }   
    }
}