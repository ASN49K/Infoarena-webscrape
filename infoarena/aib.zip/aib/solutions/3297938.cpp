#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int const lmax=1e5+7;
int const aibsize=lmax+7;///nu mai am *4
int aib[aibsize];
int n,m;
void update(int ind, int val)
{
    for(int i=ind;i<aibsize;i+=(i&-i))
    {
        aib[i]+=val;
    }
}
int query(int ind)
{
    int s=0;
    for(int i=ind;i>0;i-=(i&-i))
    {
        s+=aib[i];
    }
    return s;
}
int binsearch(int val)
{
    int pos=0;
    int interval=n;
    while(interval)
    {
        if(aib[pos+interval]<=val)
        {
            val-=aib[pos+interval];
            pos+=interval;
        }
        interval/=2;

    }
    if(pos==0)return -1;
    if(pos!=0 and val!=0)return -1;///trebuie sa fie pozitia minim egala
    if(val==0 and pos>n)return n;
    else return pos;
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin>>x;
        update(i,x);
    }
    for(int i=0;i<m;i++)
    {
        int x,y;
        fin>>x>>y;
        if(x==0)
        {
            int z;
            fin>>z;
            update(y,z);
        }
        else if(x==1)
        {
            int z;
            fin>>z;
            fout<<query(z)-query(y-1)<<"\n";
        }
        else if(x==2)
        {
            fout<<binsearch(y)<<"\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}
