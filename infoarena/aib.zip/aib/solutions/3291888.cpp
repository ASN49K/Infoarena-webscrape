#include <fstream>
#include <vector>

using namespace std;

template <typename T, T neutral_val, typename BinaryOperation>
struct FenwickTree {
  std::vector<T> tree;
  BinaryOperation op;

  FenwickTree(BinaryOperation op, const std::vector<T>& data) : op(op) {
    int n = data.size();
    tree.resize(n + 1, neutral_val);
    for (int i = 0; i < n; ++i) {
      update(i, data[i]);
    }
  }

  void update(int index, T value) {
    for (int i = index + 1; i < tree.size(); i += i & -i) {
      tree[i] = op(tree[i], value);
    }
  }

  T query(int index) {
    T result = neutral_val;
    for (int i = index + 1; i > 0; i -= i & -i) {
      result = op(result, tree[i]);
    }
    return result;
  }
};

int main() {
  // optimizations to make reading/writing faster, but you cannot use printf/scanf anymore
  ifstream inf("aib.in");
  ofstream outf("aib.out");

  int n, m;
  inf >> n >> m;
  std::vector<int> data(n);
  for (int i = 0; i < n; ++i) {
    inf >> data[i];
  }
  auto op = [](int a, int b) { return a + b; };
  FenwickTree<int, 0, decltype(op)> fenwick_tree(op, data);

  for (int i = 0; i < m; ++i) {
    int type, x, y;
    inf >> type >> x;
    if (type == 0) {
      inf >> y;
      fenwick_tree.update(x - 1, y);
    } else if (type == 1) {
      inf >> y;
      outf << fenwick_tree.query(y - 1) - fenwick_tree.query(x - 2) << "\n";
    } else if (type == 2) {
      int l = 0, r = n - 1;
      while (l < r) {
        int mid = (l + r) / 2;
        if (fenwick_tree.query(mid) < x) {
          l = mid + 1;
        } else {
          r = mid;
        }
      }
      outf << l + 1 << "\n";
    }
  }

  return 0;
}