#include <fstream>

using namespace std;

int v[100005], bit[100005];
int n, m, c, a, b;

void update(int j, int val)
{
    while(j<=n)
    {
        bit[j]+=val;
        j+=j&-j;
    }
}

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i];
    }
    for(int i=1; i<=m; i++)
    {
        cin>>c;
        update(v[i], 1);
        if(c==0)
        {
            cin>>a>>b;
            v[a]+=b;
        }
        if(c==1)
        {
            int sum=0;
            cin>>a>>b;
            for(int j=a; j<=b; j++)
                sum+=v[j];
            cout<<sum;
            cout<<endl;
        }
        if(c==2)
        {
            int j=0, sum=0;
            cin>>a;
            while(sum<a)
            {
                sum+=v[j];
                j++;
            }
            if(sum!=a)
                j=0;
            cout<<j-1;
            cout<<endl;
        }
        
    }

    return 0;
}