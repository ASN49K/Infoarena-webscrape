#include <fstream>

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

int n, m, AIB[150005], caz, a, b, val;

int zeros(int i)
{
    return i & -i;
}

void update(int poz, int val)
{
    for (; poz <= n; poz += zeros(poz)) {
        AIB[poz] += val;
    }
}

int query(int poz)
{
    int sum = 0;

    for (; poz; poz -= zeros(poz)) {
        sum += AIB[poz];
    }

    return sum;
}

int cautare(int val)
{
    int rez = 0, step = 1;

    for (; step <= n; step <<= 1) {
    }

    for (; step; step >>= 1) {
        if (rez + step <= n && AIB[rez + step] <= val) {
            rez += step;
            val -= AIB[rez];

            if (!val) {
                return rez;
            }
        }
    }

    return -1;
}

int main()
{
    InParser f("aib.in");
    ofstream g("aib.out");

    f >> n >> m;

    for (int i = 1; i <= n; ++i) {
        f >> val;

        update(i, val);
    }

    while (m--) {
        f >> caz;

        if (caz == 0) {
            f >> a >> b;
            update(a, b);
        }
        else if (caz == 1) {
            f >> a >> b;

            g << query(b) - query(a - 1) << '\n';
        }
        else {
            f >> a;

            g << cautare(a) << '\n';
        }
    }

    return 0;
}
