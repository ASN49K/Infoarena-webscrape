#include <iostream>
#include <fstream>
#include <vector>
//#define int long long

using namespace std;

int n;
vector <int> v;

void update(int i, int val)
{
    while(i<=n)
    {
        v[i]+=val;
        i+=(i&-i);
    }
}
long long presum(int i)
{
    long long sum=0;
    while(i>0)
    {
        sum+=v[i];
        i-=(i&-i);
    }
    return sum;
}

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    long long a;
    int c, b, k;
    int st, dr, mid;
    cin >> n >> k;
    v.resize(n+1);
    for(int i=1; i<=n; i++)
    {
        cin >> a;
        update(i, a);
    }
    for(int i=1; i<=k; i++)
    {
        cin >> c;

        if(c==0)
        {
            cin >> a;
            cin >> b;
            update(a, b);
        }
        else if(c==1)
        {
            cin >> a;
            cin >> b;
            cout << presum(b)-presum(a-1) << "\n";
        }
        else if(c==2)
        {
            cin >> a;
            st=1; dr=n+1;
            while(st<dr)
            {
                mid=(st+dr)/2;
                if(presum(mid)<a) st=mid+1;
                else dr=mid;
            }
            if(presum(dr)==a) cout << dr << "\n";
            else cout << "-1\n";
        }
    }

    return 0;
}
