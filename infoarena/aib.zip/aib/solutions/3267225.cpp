#include <iostream>
using namespace std;


int n, m, c, x;
int a, b;
int pos;
int aib[100005]; // dimensiune N


void update(int i, int x) {
    for (int j=i;j<=n;j+=(j&-j)) { // j+=(j&-j) -> trecem prin numerele care il contin in suma pe elementul de pe pozitia i
        aib[j] += x;
    }
}


void create() {
    for (int i=1;i<=n;i++) {
        cin >> x;
        update(i, x);
    }
}


int query(int i) {
    int s = 0;
    for (int j=i;j>=1;j-=(j&-j)) { // j -= (j&-j) ->
        s += aib[j];
    }
    return s;
}

int c3(int suma){
    int s=1;
    int d=n;
    int mij;
    while(s<d){
        mij=(s+d)/2;
        int val=query(mij);
        if(val==suma)
            return mij;
        if(val>suma){
            d=mij;
        }
        else if(val<suma){
            s=mij+1;
        }
    }
    return s;
}

void solve() {
    cin >> c;
    if(c==2){
        cin>>x;
        cout<<c3(x)<<'\n';
    }
    else if (c == 0) {
        cin >> a >> x;
        update(a, x);
    }
    else if (c == 1) {
        cin >> a >> b;
        cout << query(b) - query(a-1) << '\n';
    }
}

int main() {
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    cin >> n >> m;
    create();
    for(;m;m--) {
        solve();
    }
    return 0;
}

