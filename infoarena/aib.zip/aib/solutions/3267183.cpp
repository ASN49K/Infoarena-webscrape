#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int n, q, i, aib[100002];

static inline void Add(int poz, int val) {
    for(int i = poz; i <= n; i += (i & -i)) aib[i] += val;
}

static inline int Sum(int poz) {
    int sum = 0;
    for(int i = poz; i >= 1; i -= (i & -i)) sum += aib[i];
    return sum;
}

static inline int Cb(int val) {
    int st = 1, dr = n;
    while(st <= dr) {
        int mij = st + (dr - st) / 2;

        if(Sum(mij) == val) return mij;
        else if(Sum(mij) < val) st = mij + 1;
        else                    dr = mij - 1;
    }
    return -1;
}

int main() {
    fin >> n >> q;
    for(i = 1; i <= n; i++) {
        int a;
        fin >> a;
        Add(i, a);
    }
    while(q--) {
        int op, a, b;
        fin >> op >> a;
        if(op != 2) {
            fin >> b;
            if(op == 0) Add(a, b);
            else fout << Sum(b) - Sum(a - 1) << "\n";
        }
        else fout << Cb(a) << "\n";
    }

    return 0;
}
