#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int bit[100002], n, m;
void update(int i, int val)
{
    while(i <= n)
    {
        bit[i] += val;
        i += i & -i;
    }
}
int prefixSum(int i)
{
    int sum = 0;
    while(i > 0)
    {
        sum += bit[i];
        i -= i & -i;
    }
    return sum;
}
int rangeSum(int i, int j)
{
    return prefixSum(j) - prefixSum(i - 1);
}
int main()
{
    int ok, a, b;
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        cin >> a;
        update(i, a);
    }
    for(int i = 1; i <= m; i++)
    {
        int minn = - 1;
        cin >> ok >> a;
        if(ok != 2)
            cin >> b;

        if(ok == 0)
            update(a, b);
        else if(ok == 1)
            cout << rangeSum(a, b) << '\n';

        else if(ok == 2)
        {
            int l = 1, r = n, s = 0;
            while(l <= r)
            {
                int mid = (l + r) / 2;
                if(prefixSum(mid) == a)
                {
                    minn = mid;
                    break;
                }
                else if(prefixSum(mid) < a)
                    l = mid + 1;
                else
                    r = mid - 1;
            }
            cout << minn << '\n';
        }
    }
    return 0;
}
