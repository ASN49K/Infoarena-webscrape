#include <bits/stdc++.h>
using namespace std;
ifstream fin ("aib.in");
ofstream fout ("aib.out");
int v[100001], n, q;
int aib[100001];

void update(int pos, int val)
{
    for (int i = pos; i <= n; i += (i & (-i)))
        aib[i] += val;
}

long long query(int pos)
{
    long long rez = 0;
    for (int i = pos; i >= 1; i -= (i & (-i)))
        rez += aib[i];
    return rez;
}

long long query(int l, int r)
{
    return query(r) - query(l - 1);
}

int query2(long long s)
{
    int lg = 20, pos = 0;
    for (int i = lg; i >= 0; i--)
    {
        if (pos + (1 << i) <= n && aib[pos + (1 << i)] <= s)
        {
            pos += (1 << i);
            s -= aib[pos];
        }
    }
    if (s == 0)
        return pos;
    return -1;
}

int main()
{
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        fin >> v[i];
        update(i, v[i]);
    }

    for (int i = 1; i <= q; i++)
    {
        int t;
        fin >> t;
        if (t == 0)
        {
            int pos, b;
            fin >> pos >> b;
            update(pos, b);
        }
        if (t == 1)
        {
            int a, b;
            fin >> a >> b;
            fout << query(a, b) << '\n';
        }
        if (t == 2)
        {
            int a;
            fin >> a;
            fout << query2(a) << '\n';
        }
    }
}
