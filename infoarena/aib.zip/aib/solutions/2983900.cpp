#include <bits/stdc++.h>

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int n, m, p = 1;
int v[300000];
inline void Citire()
{
    fin >> n >> m;
    while(p < n)
        p = p * 2;
    for(int i = p; i < p + n; i ++)
        fin >> v[i];
    for(int i = p - 1; i >= 1; i --)
        v[i] = v[2 * i] + v[2 * i + 1];
}

inline void Update(int nod, int b)
{
    nod = p + nod - 1;
    v[nod] += b;
    int t;
    while(nod)
    {
        t = nod / 2;
        v[t] += b;
        nod = t;
    }
}

inline int Query(int nod, int x, int y, int st, int dr)
{
    if(st == x && dr == y)
        return v[nod];
    else
    {
        int mij = (st + dr) / 2;
        if(y <= mij)
            return Query(2 * nod, x, y, st, mij);
        else if(x > mij)
            return Query(2 * nod + 1, x, y, mij + 1, dr);
        else
            return Query(2 * nod, x, mij, st, mij) + Query(2 * nod + 1, mij + 1, y, mij + 1, dr);
    }
}

int main()
{
    Citire();
    for(int i = 1; i <= m; i ++)
    {
        int val;
        fin >> val;
        if(val == 0)
        {
            int a, b;
            fin >> a >> b;
            Update(a, b);
        }
        if(val == 1)
        {
            int a, b;
            fin >> a >> b;
            fout << Query(1, a, b, 1, n) << "\n";
        }
        if(val == 2)
        {
            int a, s = 0;
            fin >> a;
            for(int i = p; i < p + n; i ++)
            {
                s +=v[i];
                if(s > a)
                {
                    fout << -1 << "\n";
                    break;
                }
                else if(s == a)
                {
                    fout << i - p + 1 << "\n";
                    break;
                }
            }
        }
    }
     
    return 0;
}