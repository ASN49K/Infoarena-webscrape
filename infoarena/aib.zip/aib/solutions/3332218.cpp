#include <bits/stdc++.h>
#define int long long

using namespace std;

ifstream fin ("aib.in");
ofstream fout ("aib.out");

int aib[200005];
int n,m;

int LSB(int x){
    return (x&(-x));
}

int Query(int pos){
    int ans = 0;
    for (int i=pos;i>0;i-=LSB(i)){
        ans += aib[i];
    }
    return ans;
}

void Update(int pos,int val){
    for (int i=pos;i<=n;i+=LSB(i)){
        aib[i] += val;
    }
}

int BinarySearch(int a){
    int ans = 0,sum = 0;
    for (int pas=(1LL<<20);pas>0;pas/=2){
        if (ans+pas>n) continue;
        if (sum+aib[pas+ans]<=a){
            ans += pas;
            sum += aib[pas];
        }
    }
    return ans;
}

signed main()
{
    fin >> n >> m;
    for (int i=1;i<=n;++i){
        int val;
        fin >> val;
        Update(i,val);
    }
    while (m--){
        int type;
        fin >> type;
        if (type==0){
            int a,b;
            fin >> a >> b;
            Update(a,b);
        }else if (type==1){
            int a,b;
            fin >> a >> b;
            fout << Query(b)-Query(a-1) << '\n';
        }else{
            int a;
            fin >> a;
            int ans = BinarySearch(a);
            //cout << ans << '\n';
            if (Query(ans)!=a) ans = -1;
            fout << ans << '\n';
        }
    }
    return 0;
}
