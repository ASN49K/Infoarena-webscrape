#include <bits/stdc++.h>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

int v[100005];
int sp[100005];
int n,m;

void update(int p,int x) {
    for (int i = p; i <= n; i+=(i&-i)) {
        sp[i]+=x;
    }
}

int query(int x) {
    int s=0;
    for (int i=x;i>0;i-=(i&-i)) {
        s+=sp[i];
    }
    return s;
}

void create() {
    for (int i=1;i<=n;i++) {
        for (int j = i; j <= n; j+=(j&-j)) {
            sp[j]+=v[i];
        }
    }
}

int cb(int x) {
    int st=1,dr=n;
    while (st<=dr) {
        int mid=(st+dr)/2;
        int k=query(mid);
        if (k>x) {
            dr=mid-1;
        }
        else if (k<x) {
            st=mid+1;
        }
        else if (k==x) {
            return mid;
        }
    }
    return -1;
}

int main() {
    in>>n>>m;
    for (int i = 1; i <=n; i++) {
        in>>v[i];
    }
    create();
    while (m--) {
        int c;
        in>>c;
        if (c==0) {
            int p,x;
            in>>p>>x;
            update(p,x);
        }
        else if (c==1) {
            int x,y;
            in>>x>>y;
            out<<query(y)-query(x-1)<<'\n';
        }
        else {
            int k;
            in>>k;
            out<<cb(k)<<'\n';
        }
    }
    return 0;
}