#include <cstdio>
#include <vector>
using namespace std;

class BinaryIndexedTree {
private:
    vector<int> bit;
    const int size;

public:
    BinaryIndexedTree(const int auxsize) : bit(auxsize + 5, 0), size(auxsize) {}

    int ub(int x) {
        return (x & (-x));
    }

    void add(int x, int y) {
        for (int i = x; i <= size; i += ub(i))
            bit[i] += y;
    }

    int sum(int x) {
        int rez = 0;
        for (int i = x; i >= 1; i -= ub(i))
            rez += bit[i];
        return rez;
    }
};

int main() {
    FILE *in = fopen("aib.in", "r");
    FILE *out = fopen("aib.out", "w");

    int n, m;
    fscanf(in, "%d %d", &n, &m);
    BinaryIndexedTree bit(n);
    for (int i = 1; i <= n; i++) {
        int x;
        fscanf(in, "%d", &x);
        bit.add(i, x);
    }
    for (int i = 1; i <= m; i++) {
        int c;
        fscanf(in, "%d", &c);
        if (c == 0) {
            int index, val;
            fscanf(in, "%d %d", &index, &val);
            bit.add(index, val);
        } else if (c == 1) {
            int i1, i2;
            fscanf(in, "%d %d", &i1, &i2);
            fprintf(out, "%d\n", bit.sum(i2) - bit.sum(i1 - 1));
        } else if (c == 2) {
            int suma;
            fscanf(in, "%d", &suma);
            int left = 1, right = n, result = -1;

            while (left <= right) {
                int mid = (left + right) / 2;
                if (bit.sum(mid) >= suma) {
                    result = mid;
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            }

            fprintf(out, "%d\n", result);
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}
