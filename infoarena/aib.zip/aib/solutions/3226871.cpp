#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define MAXN 100005
#define MAXM 150005
#define MAXP 33
#define int long long
using namespace std;

int sir[MAXN];
int aib[MAXN];

void Update(int poz,int val,int n){
  do{
    aib[poz]+=val;
    poz+=(poz&(-poz));
  }while(poz<=n);
}

int Interval(int poz){
  int s;

  s=0;
  while(poz>0){
    s+=aib[poz];
    poz&=(poz-1);
  }

  return s;
}

int CautBinar(int val,int n){
  int p,s,poz;

  p=((int)1<<MAXP);
  s=0;
  poz=0;
  while(p>0){
    if(poz+p<=n && s+aib[p+poz]<=val){
      poz+=p;
      s+=aib[poz];
    }
    p>>=1;
  }

  if(s!=val){
    return -1;
  }
  return poz;
}

signed main(){
  int n,m,i,z,t,a,b;
  FILE *fin,*fout;
  fin=fopen("aib.in","r");
  fout=fopen("aib.out","w");
  fscanf(fin,"%lld%lld",&n,&m);

  for(i=1;i<=n;i++){
    fscanf(fin,"%lld",&sir[i]);
    Update(i,sir[i],n);
  }

  for(z=0;z<m;z++){
    fscanf(fin,"%lld",&t);
    if(t==0){
      fscanf(fin,"%lld%lld",&a,&b);
      Update(a,b,n);
    }else{
      if(t==1){
        fscanf(fin,"%lld%lld",&a,&b);
        fprintf(fout,"%lld\n",Interval(b)-Interval(a-1));
      }else{
        fscanf(fin,"%lld",&a);
        fprintf(fout,"%lld\n",CautBinar(a,n));
      }
    }
  }

  fclose(fin);
  fclose(fout);
  return 0;
}
