#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("aib.in");
ofstream fout ("aib.out");

int aib[100];
int v[200];
int n;


void pune(int x,int y)
{
    for(int k=x;k<=n;k=k+(k&(-k)))
        aib[k]+=y;
}

int sum(int k)
{
    int re=0;
    for(int d=k;d>=1;d-=d&(-d))
        re=re+aib[d];
    return re;
}


int main()
{
    int m;
    fin>>n>>m;
    for(int k=1;k<=n;k++)
    {
        fin>>v[k];
        pune(k,v[k]);
    }
    int a,b;
    int c;
    int su,poz;
    while(m--)
    {
        fin>>c;
        if(c==0)
        {
            fin>>a>>b;
            pune(a,b);
        }
        if(c==1)
        {
            fin>>a>>b;
            fout<<sum(b)-sum(a-1)<<'\n';
        }
        if(c==2)
        {
            fin>>a;
            su=0;
            poz=0;
            for(int k=17;k>=0;--k)
            {
                if(poz+(1<<k)<=n && su+aib[poz+(1<<k)]<a)
                {
                    su+=aib[poz+(1<<k)];
                    poz=poz+(1<<k);
                }
            }
            if(poz + 1 > n || sum(poz + 1) != a)
                fout << -1 << '\n';
            else
                fout<< poz + 1 << '\n';
        }
    }
    return 0;
}
