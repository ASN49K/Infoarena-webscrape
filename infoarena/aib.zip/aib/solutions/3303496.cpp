#include <bits/stdc++.h>

using namespace std;
struct aib {
  vector<long long> a;

  aib(int n) { a.resize(n + 1); }

  void update(int x, int add) {
    for (int i = x; i < a.size(); i += (i & (-i)))
      a[i] += add;
  }
  long long query(int x) {
    if (x >= a.size())
      return -1;
    long long s = 0;
    for (int i = x; i > 0; i -= (i & (-i)))
      s += a[i];
    return s;
  }
  int obs(long long s, bool b = false) {

    int ans = 0;
    long long sum = 0;
    for (int i = (1 << 10); i > 0; i /= 2) {
      if (ans + i >= a.size())
        continue;
      if (sum + a[ans + i] + b <= s) {
        ans += i;
        sum += a[ans];
      }
    }
    return sum;
  }
};
int main() {
  ifstream cin("aib.in");
  ofstream cout("aib.out");
  int n, m;
  cin >> n >> m;
  aib a(n);
  vector<int> v(n + 1);
  for (int i = 1; i <= n; i++) {
    cin >> v[i];
    a.update(i, v[i]);
  }
  while (m--) {
    int type;
    cin >> type;
    if (type == 0) {
      int x, y;
      cin >> x >> y;
      a.update(x, y);
    } else if (type == 1) {
      int x, y;
      cin >> x >> y;
      cout << a.query(y) - a.query(x - 2);
    } else {
      long long x;
      cin >> x;
      int p = a.obs(x, true) + 1;
      if (a.query(p) == x)
        cout << p << '\n';
      else
        cout << "1\n";
    }
  }
}