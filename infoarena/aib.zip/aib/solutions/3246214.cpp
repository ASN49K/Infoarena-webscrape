#include <fstream>
#define int long long
using namespace std;
ifstream cin("aib.in");
ofstream cout("aib.out");
int n, t, cer, a, b;
int aib[100002], v[100002];
void update(int x, int val){
    for(int i=x;i<=n;i+=(i&(-i)))
        aib[i]+=val;
}
int query(int x){
    int rez=0;
    for(int i=x;i>=1;i-=(i&(-i)))
        rez+=aib[i];
    return rez;
}
int cb(int x){
    int pos=0;
    int pas=(1<<30);
    while(pas>0){
        if(pos+pas<=n && aib[pos+pas]<=x){
            pos+=pas;
            x-=aib[pos];
        }
        if(!x)
            return pos;
        pas/=2;
    }
    return -1;
}
signed main() {
    cin>>n>>t;
    for(int i=1;i<=n;i++){
        cin>>v[i];
        update(i, v[i]);
    }
    while(t--){
        cin>>cer;
        if(cer<=1){
            cin>>a>>b;
            if(cer==0){
                update(a, b);
            }
            else cout<<query(b)-query(a-1)<<"\n";
        }
        else{
            cin>>a;
            cout<<cb(a)<<"\n";
        }
    }

}
