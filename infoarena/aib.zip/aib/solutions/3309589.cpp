#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
const int NMAX=1e5+5;
int n,q;
int aib[NMAX];
int v[NMAX];
void update(int poz,int val)
{
    for(int i=poz;i<=n;i+=(i&(-i)))aib[i]+=val;
}
int query(int poz)
{
    int ans=0;
    for(int i=poz;i>0;i-=(i&(-i)))ans+=aib[i]; return ans;
}
int sum(int st,int dr)
{
    return query(dr)-query(st-1);
}
void find_k(int target)
{
    int suma=0;
    int poz=0;
    for(int i=1<<((int)floor(log2(n)));i>0;i>>=1)
    {
        if(poz+i<=n && suma+aib[poz+i]<target)
        {
            suma+=aib[poz+i];
            poz+=i;
        }
    }
    if(poz+1>n){fout<<"-1\n";return;}
    if(query(poz+1)==target){fout<<poz+1<<'\n';return;} else fout<<"-1\n";
}
int main()
{
    fin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin>>v[i];
        update(i,v[i]);
    }
    while(q--)
    {
        int op;
        fin>>op;
        if(op==0)
        {
            int a,b;
            fin>>a>>b;
            update(a,b);
        }
        if(op==1)
        {
            int a,b;
            fin>>a>>b;
            fout<<sum(a,b)<<'\n';
        }
        if(op==2)
        {
            int x;
            fin>>x;
            find_k(x);
        }
    }
}