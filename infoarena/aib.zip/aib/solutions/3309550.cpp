#include <bits/stdc++.h>
using namespace std;
#define int long long
ifstream fin ("aib.in");
ofstream fout ("aib.out");
#define cin fin
#define cout fout

const int MAXN=1e5+10;
const int LG=19;

int n,aib[MAXN],q;

void update (int pos, int val){
    for (int i=pos;i<=n;i+=(i&(-i))){
        aib[i]+=val;
    }
}

int query (int pos){
    int rez=0;
    for (int i=pos;i>=1;i-=(i&(-i))){
        rez+=aib[i];
    }
    return rez;
}
int query (int l, int r){
    return query (r)-query (l-1);
}

int query2 (int s){
    int pos=0;
    for (int i=LG;i>=0;--i){
        if (pos+(1<<i)>n) continue;
        if (aib[pos+(1<<i)]>=s) continue;
        s-=aib[pos+(1<<i)];
        pos+=(1<<i);
    }
    return pos+1;
}


signed main()
{
    ios_base::sync_with_stdio (false);
    cin.tie (nullptr);

    cin >>n>>q;
    for (int i=1;i<=n;++i){
        int x;
        cin >>x;
        update (i,x);
    }

    for (int i=1;i<=q;++i){
        int t;
        cin >>t;
        if (t==0){
            int pos,val;
            cin >>pos>>val;
            update (pos,val);
        }
        else{
            if (t==1){
                int l,r;
                cin >>l>>r;
                cout <<query (l,r)<<'\n';
            }
            else{
                int s;
                cin >>s;
                cout <<query2 (s)<<'\n';
            }

        }
    }

    return 0;
}
