#include <fstream>
#include <cmath>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");
int n, m, lg;
int aib[100005];
int v[100005];

void update(int p, int val)
{
    for(int i = p; i<=n; i+=(i&-i))
    {
        aib[i] += val;
    }
}

int query(int p)
{
    int suma = 0;
    for(int i = p; i>=1; i-=(i&-i))
    {
        suma += aib[i];
    }
    return suma;
}

int main()
{
    in>>n>>m;
    int x;
    for(int i = 1; i<=n; i++)
    {
        in>>x;
        update(i, x);

        v[i] = x;
    }

    int c, a, b;
    lg = log2(n);
    while(m--)
    {
        in>>c;
        if(c == 0)
        {
            in>>a>>b;
            update(a, b);

            v[a] += b;
        }
        else if(c == 1)
        {
            in>>a>>b;
            out<<query(b) - query(a-1)<<'\n';
        }
        else if(c == 2)
        {
            in>>a;

            int sum = 0;
            int poz = 0;
            for(int i = lg; i>=0; i--)
            {
                if(poz + (1 << i) <= n && sum + aib[poz + (1 << i)] < a)
                {
                    sum += aib[poz + (1 << i)];
                    poz += (1 << i);
                }
            }

            if(sum + v[poz + 1] == a)
            {
                out<<poz + 1<<'\n';
            }
            else
            {
                out<<-1<<'\n';
            }
        }
    }

    return 0;
}
