#include <fstream>

using namespace std;

const int N = 1e5;
const int L = 16;

unsigned int aib[N+1], v[N+1], n;

void actualizare(int i, int val)
{
    while (i <= n)
    {
        aib[i] += val;
        int p2 = i & (-i);
        i += p2;
    }
}

 unsigned int interogare(int i)
 {
     unsigned int sum = 0;
     while (i != 0)
     {
         sum += aib[i];
         int p2 = i & (-i);
         i -= p2;
     }
     return sum;
 }

 int cautare(unsigned int val)
 {
     int i = 0, pas = 1 << L;
     unsigned int sum = 0;
     while (pas != 0)
     {
         if (i + pas <= n && aib[i+pas] < val)
         {
             i += pas;
             val -= aib[i];
         }
         pas /= 2;
     }
     if (val == v[i + 1])
     {
         return i + 1;
     }
     return -1;
 }

int main()
{
    ifstream in("aib.in");
    ofstream out("aib.out");
    int nq;
    in >> n >> nq;
    for (int i = 1; i <= n; i++)
    {
        in >> v[i];
        actualizare(i, v[i]);
    }
    for (int i = 0; i < nq; i++)
    {
        int tip;
        in >> tip;
        if (tip == 0)
        {
            int poz, val;
            in >> poz >> val;
            actualizare(poz, val);
        }
        else if (tip == 1)
        {
            int st, dr;
            in >> st >> dr;
            out << interogare(dr) - interogare(st - 1) << "\n";
        }
        else
        {
            unsigned int val;
            in >> val;
            out << cautare(val) << "\n";
        }
    }
    in.close();
    out.close();
    return 0;
}
