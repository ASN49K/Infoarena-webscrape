#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using ld = long double;
#define all(v) begin(v), end(v)
#define al(v, l, r) begin(v) + l, begin(v) + r + 1
#define sz(v) (int)v.size()
#define pb push_back
#define pob pop_back
#define fs first
#define sd second

constexpr int inf = 2e9;
constexpr ll infll = 4e18;
constexpr int N = 1e5 + 5;

struct aib {
    int n;
    vector<int> f;

    aib(int n): n(n), f(n + 1, 0) {}

    void add(int i, int x) {
        for (; i <= n; i += (i & -i)) {
            f[i] += x;
        }
    }

    int sum(int i) {
        int s = 0;
        for (; i; i -= (i & (-i))) {
            s += f[i];
        }

        return s;
    }

    int rng(int l, int r) {
        if (l > r) {
            return 0;
        }

        return sum(r) - sum(l - 1);
    }

    int kth(int k) {
        int poz = 0, pw = 1;

        while (pw <= n) {
            pw <<= 1;
        }

        for (; pw; pw >>= 1) {
            int nxt = poz + pw;

            if (nxt <= n && k > f[nxt]) {
                k -= f[nxt];
                poz = nxt;
            }
        }

        return poz + 1;
    }
};

int n, q, x;
signed main() {
    ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);

    cin >> n >> q;
    aib fen(n);

    for (int i = 1; i <= n; ++i) {
        cin >> x;
        fen.add(i, x);
    }

    for (int _ = 0, t, a; _ < q; ++_) {
        cin >> t >> a;

        if (t == 0) {
            int b;
            cin >> b;
            fen.add(a, b);
        } else if (t == 1) {
            int b;
            cin >> b;
            cout << fen.rng(a, b) << "\n";
        } else {
            int poz = fen.kth(a);

            if (poz > n || fen.sum(poz) != a) {
                cout << "-1\n";
            } else {
                cout << poz << "\n";
            }
        }
    }
}