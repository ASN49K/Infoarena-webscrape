#include <fstream>
//#define int long long

using namespace std;

long long n, v[100005];

void update(long long i, long long val)
{
    while(i<=n)
    {
        v[i]+=val;
        i+=(i&-i);
    }
}
long long presum(long long i)
{
    long long sum=0;
    while(i>0)
    {
        sum+=v[i];
        i-=(i&-i);
    }
    return sum;
}

int main()
{
    ifstream cin("aib.in");
    ofstream cout("aib.out");
    long long a, c, b, k;
    long long st=0, dr=n+1, mid;
    cin >> n >> k;
    for(int i=1; i<=n; i++)
    {
        cin >> a;
        update(i, a);
    }
    for(int i=1; i<=k; i++)
    {
        cin >> c >> a;

        if(c==0)
        {
            cin >> b;
            update(a, b);
        }
        else if(c==1)
        {
            cin >> b;
            cout << presum(b)-presum(a-1) << "\n";
        }
        else if(c==2)
        {
            st=0; dr=n+1;
            while(st<dr)
            {
                mid=(st+dr)/2;
                if(presum(mid)<a) st=mid+1;
                else dr=mid;
            }
            if(presum(dr)==a) cout << dr << "\n";
            else cout << "-1\n";
        }
    }

    return 0;
}
