#include <bits/stdc++.h>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

#define int long long

int n,q,aib[100005];

void update(int x,int y)
{
    for (int i = x; i <= n; i += (i & -i))
        aib[i] += y;
}

int query(int x)
{
    int rsp = 0;
    for (int i = x; i > 0; i -= (i & -i))
        rsp += aib[i];
    return rsp;
}
signed main()
{
    in >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        int x;
        in >> x;
        update(i,x);
    }
    for (int i = 1; i <= q; i++)
    {
        int t;
        in >> t;
        if (t == 0)
        {
            int x,y;
            in >> x >> y;
            update(x,y);
        }
        else if (t == 1)
        {
            int x,y;
            in >> x >> y;
            out << query(y) - query(x - 1) << '\n';
        }
        else
        {
            int k;
            in >> k;
            int st = 0,pas = 1 << 16;
            while (pas != 0)
            {
                if (st + pas <= n and query(st + pas) < k)
                    st += pas;
                pas /= 2;
            }
            st++;
            if (st != n + 1 and query(st) == k)
                out << st << '\n';
            else
                out << -1 << '\n';
        }
    }
    return 0;
}
