#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
long long n;
const int NMAX = 100005;
long long aib[NMAX];
long long v[NMAX];
long long lsb(long long val) {
    return val & (-val);
}
long long query(long long x) {
    long long sum = 0;
    for (int i = x; i > 0; i -= lsb(i)) {
        sum += aib[i];
    }
    return sum;
}
void update(long long x, long long val) {
    for (long long i = x; i <= n; i += lsb(i)) {
        aib[i] += val;
    }
}
int cb(int val) {
    long long pow2 = 2 << 17;
    long long pozi = 0;
    long long crt = 0;
    for (long long i = pow2; i > 0; i /= 2) {
        if (pozi + i <= n && crt+aib[pozi+i]<=val) {
            pozi += i;
            crt +=  aib[i];
        }
    }
    return pozi;
}
int main()
{
    int teste;
    fin >> n >> teste;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i];
        update(i, v[i]);
    }
    for (int i = 0; i < teste; ++i) {
        int cer = 0;
        fin >> cer;
        if (cer == 0) {
            long long x, val;
            fin >> x >> val;
            update(x, val);
        }
        else if (cer == 1) {
            long long st, dr;
            fin >> st >> dr;
            if (st != 0) {
                fout << query(dr) - query(st - 1) << endl;
            }
            else {
                fout << query(dr) << endl;
            }
        }
        else if (cer == 2) {
            long long x;
            fin >> x;
            fout << cb(x) << endl;
        }
    }
    return 0;
}
