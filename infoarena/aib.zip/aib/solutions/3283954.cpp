#include <vector>
#include <fstream>
#include <bitset>
#include <queue>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int n, q;
int aib[10005];
void update(int pos, int val)
{
    for (; pos <= n; pos += (pos & -pos))
        aib[pos] += val;
}
int sum(int pos)
{
    int s = 0;
    for (; pos >= 1; pos -= (pos & -pos))
        s += aib[pos];
    return s;
}
int cb(int val)
{
    int sol=-1;
    int st = 1, dr = n, mij;
    while (st <= dr)
    {
        int mij = (st + dr) / 2;
        if (sum(mij) == val)
            sol = mij, dr = mij - 1;
        else if (sum(mij) > val)
            dr = mij - 1;
        else
            st = mij + 1;
    }
    return sol;
}
int main()
{
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        update(i, x);
    }
    while (q--)
    {
        int op, x, y;
        fin >> op >> x;
        if (op == 0)
        {
            fin >> y;
            update(x, y);
        }
        else if (op == 1)
        {
            fin >> y;
            fout << sum(y) - sum(x - 1) << '\n';
        }
        else
            fout << cb(x)<<"\n";
    }
    return 0;
}