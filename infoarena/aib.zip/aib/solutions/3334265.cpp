#include <fstream>
#include <iostream>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int aib[100005];
int n, m;
int query(int idx)
{
    int sum = 0;
    for (; idx >= 1; idx -= idx & (-idx))
    {
        sum += aib[idx];
    }
    return sum;
}
void update(int idx, int val)
{
    for (; idx <= n; idx += idx & (-idx))
    {
        aib[idx] += val;
    }
}

int check(int k)
{
    int l = 1;
    int r = n;
    while (l <= r)
    {
        int mid = (l + r) / 2;
        if (query(mid) == k)
        {
            return mid;
        }
        else if (query(mid) < k)
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    return -1;
}
int main()
{

    fin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        int x;
        fin >> x;
        update(i + 1, x);
    }
    while (m--)
    {

        int c;
        fin >> c;
        if (c == 0)
        {
            int a, b;
            fin >> a >> b;
            update(a, b);
        }
        else if (c == 1)
        {
            int a, b;
            fin >> a >> b;
            cout << "s";
            fout << query(b) - query(a - 1) << '\n';
        }
        else if (c == 2)
        {
            int a;
            fin >> a;
            fout << check(a) << '\n';
        }
    }
    return 0;
}