#include <bits/stdc++.h>

#define VMAX 100000
#define NMAX 100000
#define LOG 20
#define INF (long long)(1e9)
#define MOD 1000000007

#define ll  long long int



using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

int n,q;
ll aib[NMAX+1];

void update(int p,int x)
{
    for(int i=p;i<=n;i+=i&-i)
    {
        aib[i] += x;
    }
}
ll query(int p)
{
    ll res=0;
    for(int i=p;i>=1;i-=i&-i)
    {
        res += aib[i];
    }
    return res;
}
int main()
{
    fin >> n >> q;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin >> x;
        update(i,x);
    }
    while(q--)
    {
        int t;
        fin >> t;
        if(t==0)
        {
            int p,x;
            fin >> p >> x;
            update(p,x);
        }
        if(t==1)
        {
            int l,r;
            fin >> l >> r;
            fout << query(r)-query(l-1) << "\n";
        }
        if(t==2)
        {
            int x;
            fin >> x;
            int pos=0;
            ll s=0;
            for(int i=LOG;i>=0;i--)
            {
                if(pos + (1<<i) <= n && s+aib[pos+(1<<i)]<=x)
                {
                    s += aib[pos + (1<<i)];
                    pos += 1<<i;
                }
            }
            fout << (s!=x ? -1 : pos) << '\n';
        }
    }
}

