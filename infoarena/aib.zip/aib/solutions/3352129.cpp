#include <bits/stdc++.h>

using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int aib[100005];
int n,t,a[1000005],x,y,C,k;
void upd(int i,int val){
    for(;i<=n;i+=(i&-i)){
        aib[i]+=val;
    }
}
int query(int i){
    int s=0;
    for(;i>=1;i-=(i&-i)) s+=aib[i];
    return s;
}
int main()
{
    fin>>n>>t;
    for(int i=1;i<=n;i++){
        fin>>x;
        a[i]=a[i-1]+x;
    }
    while(t--){
        fin>>C;
        if(C==0){
            fin>>x>>y;
            upd(x,y);
        }
        else if(C==1){
            fin>>x>>y;
            fout<<query(y)-query(x-1)+a[y]-a[x-1]<<"\n";
        }
        else {
                fin>>k;
            int st=1,dr=n,poz=-1;
            while(st<=dr){
                int mid=(st+dr)/2;
                if(query(mid)+a[mid]==k) {poz=mid;break;}
                else if(query(mid)+a[mid]<k) st=mid+1;
                else dr=mid-1;
            }
            fout<<poz<<"\n";
        }
    }
    return 0;
}
