#include <fstream>

#define DIM 100010

using namespace std;

int A[DIM], v[DIM];
int n;


void update(int poz, int val) {
    for (int i = poz; i <= n; i += (i & -i)) {
        A[i] += val;
    }
}

int query(int poz) {
    int sol = 0;
    for (int i = poz; i > 0; i -= (i & -i)) {
        sol += A[i];
    }
    return sol;
}

int q, t, poz, val, st, dr, k;

int main() {
    ifstream fin("aib.in");
    ofstream fout("aib.out");
    fin >> n >> q;
    for (int i = 1; i <= n; i++) {
        fin >> v[i];
    }
    for (int i = 1; i <= n; i++) {
        update(i, v[i]);
    }
    for (int i = 1; i <= q; i++) {
        fin >> t;
        switch (t) {
            case 0:
                fin >> poz >> val;
                update(poz, val);
                break;
            case 1:
                fin >> st >> dr;
                fout << query(dr) - query(st - 1) << "\n";
                break;
            case 2:
                fin >> k;
                st = 1;
                dr = n;
                while (st <= dr) {
                    int mid = (st + dr) / 2;
                    int sum = query(mid);
                    if (sum >= k) {
                        dr = mid - 1;
                    } else {
                        st = mid + 1;
                    }
                }
                if (query(st) == k) {
                    fout << st << "\n";
                } else {
                    fout << "-1\n";
                }
                break;
        }
    }
    return 0;
}