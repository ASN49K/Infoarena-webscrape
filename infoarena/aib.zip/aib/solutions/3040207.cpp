#include <iostream>
#include <fstream>
#include <vector>

struct BIT {
private:
    std::vector<int> tree;
    int size;
public:
    explicit BIT(int size) : size(size) {
        tree.resize(size + 1, 0);
    }

    void update(int pos, int val) {
        for (int i = pos; i <= size; i += i & (-i)) tree[i] += val;
    }

    int query(int pos) {
        int ans = 0;
        for (int i = pos; i > 0; i -= i & (-i)) ans += tree[i];
        return ans;
    }

    int search(int val) {
        int step = 1;
        while (step <= size) step *= 2;

        int i = 0;
        while (step) {
            if (i + step <= size) {
                if (val >= tree[i + step]) {
                    val -= tree[i + step];
                    i += step;
                    if (val == 0) return i;
                }
            }

            step /= 2;
        }
        return -1;
    }
};

int main() {
    std::ifstream input("aib.in");
    std::ofstream output("aib.out");

    int n, m;
    input >> n >> m;

    BIT bit(n);

    for (int i = 1; i <= n; ++i) {
        int x;
        input >> x;
        bit.update(i, x);
    }

    while (m--) {
        int op;
        input >> op;
        if (op == 0) {
            int a, b;
            input >> a >> b;
            bit.update(a, b);
        } else if (op == 1) {
            int a, b;
            input >> a >> b;
            output << bit.query(b) - bit.query(a - 1) << '\n';
        } else {
            int a;
            input >> a;
            output << bit.search(a) << '\n';
        }
    }

    return 0;
}
