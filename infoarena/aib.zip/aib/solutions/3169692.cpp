#include<fstream>
std::ifstream fin("aib.in");
std::ofstream fout("aib.out");
int n, m;
int aib[100001];
int interval(int num)
{
    return num&(-num);
}
void update(int i, int val)
{
    int index=i;
    while(index<100001)
    {
        aib[index]+=val;
        index+=interval(index);
    }
}

int q1(int i)
{
    int s=0;
    int index=i;
    while(index>0)
    {
        s+=aib[index];
        index-=interval(index);
    }
    return s;
}

int q2(int val)
{
    int pos=-1, st=1, dr=n;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        int sum=q1(mij);
        if(sum>=val)
        {
            pos=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    return pos;
}

void getCases()
{
    int q, a, b;
    fin>>q;
    if(q==0)
    {
        fin>>a>>b;
        update(a, b);
    }
    if(q==1)
    {
        fin>>a>>b;
        fout<<q1(b)-q1(a-1)<<'\n';
    }
    else if(q==2)
    {
        int val;
        fin>>val;
        fout<<q2(val)<<'\n';
    }
}
void solve()
{
    fin>>n>>m;
    for(int index=0; index<n; ++index)
    {
        int val;
        fin>>val;
        update(index+1, val);
    }
    for(int index=0; index<m; ++index)
        getCases();
}
int main()
{
    std::ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);
    solve();
    return 0;
}