#include<iostream>
using namespace std;

const int NMAX=1e5;
int v[NMAX],n,m,aib[NMAX];

void update(int pos, int val){
	while(pos<=n){
		aib[pos]+=val;
		pos+=(pos&-pos);
	}
}

int parSum(int pos){
	int sum=0;
	while(pos>0){
		sum+=aib[pos];
		pos-=(pos&-pos);
	}
	return sum;
}

int search(int k){
	int i,step;
	for(step=1;step<n;step<<=1);
	for(i=0;step;step>>=1){
		if(i+step<=n&&k>=aib[i+step]){
			i+=step;
			k-=aib[i];
			if(k==0){
				return i;
			}
		}
	}
	return -1;
}

int main(){
	freopen("aib.in","r",stdin);
	freopen("aib.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>v[i];
		update(i, v[i]);
	}
	while(m--){
		int t;
		cin>>t;
		if(t==0){
			int pos,val;
			cin>>pos>>val;
			update(pos,val);
		}else if(t==1){
			int l,r;
			cin>>l>>r;
			cout<<parSum(r)-parSum(l-1)<<'\n';
		}else{
			int k;
			cin>>k;
			cout<<search(k)<<'\n';
		}
	}
}