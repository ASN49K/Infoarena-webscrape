#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");


const int N = 1e5;
int n, queries;
int v[N+1], aib[N+1];


int lsb(int x)
{
    return (x ^ (x-1)) & x;
}

int query(int poz)
{
    int ret = 0;
    for (; poz > 0; poz -= lsb(poz))
        ret += aib[poz];
    return ret;
}

void update(int poz, int val)
{
    for (; poz <= n; poz += lsb(poz))
        aib[poz] += val;
}


int search(int st, int dr, int val)
{
    // st = 0
    if (dr - lsb(dr) > 0)
    {
        while (dr - lsb(dr) > 0)
            dr -= lsb(dr);
        dr += lsb(dr);
    }

    int valst = aib[st], valdr;
    while (dr - st > 1)
    {
        int mid = st + (dr - st)/2;
        if (mid <= n)
        {
            int valmid = valst + aib[mid];
            if (val <= valmid)
                dr = mid;
            else
                st = mid, valst = valmid;
        }
        else
            dr = mid;
    }
    if (dr > n)
        return -1;
    valdr = query(dr);
    if (val != valst && val != valdr)
        return -1;
    if (val == valst && valst == 0)
        return -1;
    if (val == valst)
        return st;
    else
        return dr;
}


int main()
{
    cin >> n >> queries;

    for (int i = 1; i <= n; i++)
        cin >> v[i];
    

    for (int i = 1; i <= n; i++)
        update(i, v[i]);

    
    // int nrlin = 0, important;
    for (int q = 1; q <= queries; q++)
    {
        int cod;
        cin >> cod;

        if (cod == 0)
        {
            int a, b;
            cin >> a >> b;
            update(a, b);
        }
        else if (cod == 1)
        {
            int a, b;
            cin >> a >> b;
            cout << query(b) - query(a-1) << '\n';
            // nrlin++;
        }
        else
        {
            int a;
            cin >> a;
            cout << search(0, n, a) << '\n';
            /*
            nrlin++;
            if (a == 0)
                important = nrlin;
            */
        }
    }

    //cout << "\n!!! " << important << " !!!";

    return 0;
}