#include <fstream>

using namespace std;



ifstream cin("aib.in");
ofstream cout("aib.out");


const int N = 200000;
int bit[N+9];




void update (int i, int val){

while(i<=N){
    bit[i]+=val;
i+=i&-i;
}

}

int prefix(int i){
int sum = 0;

while(i>0){
    sum+=bit[i];
    i-=i&-i;
}
return sum;
}



int cb(int x, int n){
int st=1, dr=n, rez = 0;

while(st<=dr){
    int m=(st+dr)/2;

    if(prefix(m)<=x){

        rez = m;
        st=m+1;

    }
    else{
        dr=m-1;
    }
}

return rez;

}
int main()
{
    int t,n;
    cin>>n>>t;


    for (int i = 1; i<=n;i++){
        int x;
        cin>>x;
        update(i,x);
    }


    for (int i = 1; i<=t;i++){

        int op;
        cin>>op;
        if(op==0){
                int x,add;
            cin>>x>>add;
            update(x,add);
        }

        if(op==1){
            int x,y;

            cin>>x>>y;

            cout<<prefix(y)-prefix(x-1)<<'\n';
        }
        if(op==2){
            int s;
            cin>>s;

            int poz = cb(s,n);
            if(prefix(poz)==s)
                cout<<poz<<'\n';
            else
                cout<<-1<<'\n';


        }


    }

    return 0;
}
