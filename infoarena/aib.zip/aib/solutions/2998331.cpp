#include <iostream>
#include <fstream>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

long long aib[100005],n,m,op,x;

void update(int x,int val)
{
    for(int i=x;i<=n;i+=i&(-i))
        aib[i]+=val;
}

long long suma(int x)
{
    long long s=0;
    for(int i=x;i>=1;i-=i&(-i))
        s+=aib[i];
    return s;
}

int main()
{
    f>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x;
        f>>x;
        update(i,x);
    }
    int op,a,b;
    for(int i=1;i<=m;i++)
    {
        f>>op;
        if(op==0)
        {
            f>>a>>b;
            update(a,b);
        }
        if(op==1)
        {
            f>>a>>b;
            g<<suma(b)-suma(a-1)<<'\n';
        }
        if(op==2)
        {
            f>>a;
            int st=1,dr=n,mij,ans=-1;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(suma(mij)==a)
                {
                    ans=mij;
                    break;
                }
                else if(suma(mij)>a)dr=mij-1;
                else st=mij+1;
            }
            g<<ans<<'\n';
        }
    }

    return 0;
}
