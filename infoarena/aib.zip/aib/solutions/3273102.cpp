#include <iostream>
#include <fstream>
#define NMAX 200005

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int n,m;
int aib[NMAX];

void update(int x  , int y)
{
    for(int i = x ; i <=n ; i+=i&(-i))
    {
        aib[i] += y;
    }
}

int sum(int x)
{
    int sol = 0;
    for(int i = x ; i > 0 ; i-=i&(-i))
    {
        sol += aib[i];
    }
    return sol;
}

int cb(int x)
{
    int st=1 , dr = n;
    int sol = NMAX;
    while(st <= dr)
    {
        int mij = (st+dr)/2;
        int suma = sum(mij);
        if(suma == x)
            return mij;
        else if(suma > x)
        {
            dr = mij-1;
        }
        else
            st = mij + 1;
    }
    return -1;
}
int main()
{
    fin >> n >> m;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin >> x;
        update(i,x);
    }
    for(int i=1;i<=m;i++)
    {
        int q;
        int a,b;
        fin >> q;
        if(q == 0)
        {
            fin >> a >> b;
            update(a,b);
        }
        else if(q == 1)
        {
            fin >> a >> b;
            fout << sum(b) - sum(a-1) << '\n';
        }
        else
        {
            fin >> a;
            fout << cb(a) << '\n';
        }
    }
    return 0;
}
