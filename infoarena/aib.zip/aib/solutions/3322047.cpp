#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("aib.in");
ofstream fout("aib.out");
#endif

long long n;
long long aib[100001];

void update(long long p, long long a) {
    while (p <= n) {
        aib[p] += a;
        p += (p & -p);
    }
}

long long query(long long p) {
    long long s = 0;
    while (p > 0) {
        s += aib[p];
        p -= (p & -p);
    }
    return s;
}

int main() {
    long long m, t, a, b, l, r, mij, temp;
    fin >> n >> m;
    for (long long i=1; i<=n; i++) {
        fin >> a;
        update(i, a);
    }
    for (long long i=1; i<=m; i++) {
        fin >> t >> a;
        if (t == 0) {
            fin >> b;
            update(a, b);
        }
        else if (t == 1) {
            fin >> b;
            fout << query(b) - query(a - 1) << '\n';
        }
        else {
            l = 1, r = n;
            while (l < r) {
                mij = (l + r + 1) / 2;
                temp = query(mij);
                if (temp <= a) l = mij;
                else r = mij - 1;
            }
            if (query(l) == a) fout << l;
            else fout << -1;
            fout << '\n';
        }
    }
}