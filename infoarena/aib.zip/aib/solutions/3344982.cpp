/*
    Author: Paul Ciumandru
    Hard work beats talent!
*/
#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#include <bits/stdc++.h>

using namespace std;

#define NMAX 100000
#define MMAX 20
#define PMAX 500
#define LOG 17
#define INF_INT 2e9
#define INF_LL 1e18
#define BS 666013
#define MOD 1000000007

#define debug(x) cout << #x << " = " << x << "\n";
#define vdebug(a) cout << #a << " = "; for(auto x: a) cout << x << " "; cout << "\n";

#define ll long long
#define ull unsigned long long
#define dbl double
#define ldb long double
#define pii pair<int, int>
#define pll pair<ll, ll>
#define piv pair<int, vector<int>>
#define pipii pair<int, pair<pii, pii>>
#define tpl tuple<int, int, int>
#define tpl2 tuple<int, int, vector<int>>
#define vpi vector<pii>

ifstream fin("aib.in");
ofstream fout("aib.out");

int n, m, x, op, a, b;
vector<int> aib(NMAX + 2);

void update(int poz, int val) {
    for (int i = poz; i <= n; i += i & -i) {
        aib[i] += val;
    }
}

int sum(int poz) {
    int rez = 0;
    while (poz) {
        rez += aib[poz];
        poz -= poz & -poz;
    }
    return rez;
}

int bin_search(int val) {
    int poz = 0, s = 0;
    for (int bt = LOG; bt >= 0; bt--) {
        if (poz + (1 << bt) <= n && s + aib[poz + (1 << bt)] < val) {
            s += aib[poz + (1 << bt)];
            poz += (1 << bt);
        }
    }
    return poz + 1;
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    fin >> n >> m;

    for (int i = 1; i <= n; i++) {
        fin >> x;
        aib[i] += x;
        int p = i + (i & -i);
        if (p <= n) {
            aib[p] += aib[i];
        }
    }

    while (m--) {
        fin >> op;

        if (op == 0) {
            fin >> a >> b;
            update(a, b);
        }
        else if (op == 1) {
            fin >> a >> b;
            fout << sum(b) - sum(a - 1) << '\n';
        }
        else {
            fin >> a;
            int p = bin_search(a);
            if (p > n || sum(p) != a) {
                fout << -1 << '\n';
            }
            else {
                fout << p << '\n';
            }
        }
    }
    return 0;
}