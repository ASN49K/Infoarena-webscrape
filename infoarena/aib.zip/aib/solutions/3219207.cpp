#include <iostream>
#include <fstream>
#include <stdint.h>

bool IsPow2(int32_t x) {
	return !(x & (x - 1));
}
int32_t LeftBit(int32_t x) {
	return x & ~(x - 1);
}

const int32_t MAX_N = 100000;
const int32_t MAX_N_POW_2 = 1 << 16;

int32_t n;
int32_t vec[MAX_N + 1];
int32_t sum[MAX_N + 1];

void Insert(int32_t ind, int32_t val) {
	for(; ind <= n; ind += LeftBit(ind))
		sum[ind] += val;
}
int32_t GetSum(int32_t start, int32_t end) {
	int32_t sum1 = 0;
	for(--start; start; start -= LeftBit(start))
		sum1 += sum[start];
	int32_t sum2 = 0;
	for(; end; end -= LeftBit(end))
		sum2 += sum[end];
	return sum2 - sum1;
}
int32_t GetPos(int32_t val) {
	int32_t pos = 0, res = 0;
	for(int32_t step = MAX_N_POW_2; step; step >>= 1)
		if(pos + step <= n && res + sum[pos + step] <= val) {
			pos += step;
			res += sum[pos];
		}
	
	if(!pos || res != val)
		pos = -1;
	return pos;
}

int main() {
	std::ifstream fin("aib.in");
	std::ofstream fout("aib.out");

	int32_t m;
	fin >> n >> m;

	for(int32_t i = 1; i <= n; ++i)
		fin >> vec[i];
	for(int32_t i = 2; i <= n; ++i)
		vec[i] += vec[i - 1];
	
	for(int32_t i = 1; i <= n; ++i) {
		sum[i] = vec[i] - vec[i - LeftBit(i)];
	}

	for(int32_t i = 0; i != m; ++i) {
		int32_t c;
		fin >> c;

		int32_t a, b;
		switch (c) {
		case 0:
			fin >> a >> b;
			Insert(a, b);
			break;
		case 1:
			fin >> a >> b;
			fout << GetSum(a, b) << '\n';
			break;
		case 2:
			fin >> a;
			fout << GetPos(a) << '\n';
			break;
		}
	}

	fin.close();
	fout.close();

	return 0;
}