#include <bits/stdc++.h>
#define NMAX 100500
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
long long tree[NMAX], n, v[NMAX];
void update(long long poz,long long val)
{
    for(long long i=poz;i<=n;i+=i&(-i))
        tree[i]+=val;
}
long long query(long long poz)
{
    long long s=0;
    for(long long i=poz;i>0;i-=i&(-i))
        s+=tree[i];
    return s;
}
long long bin(long long val)
{
    long long st=0;
    while(val>0 && tree[st+1]<=val)
    {
        st++;
        while(st+(st&(-st))<=n && tree[st+(st&(-st))]<=val)
            st+=(st&(-st));
        val-=tree[st];
    }

    if(val!=0 || st>n)
        return -1;
    return st;
}
//void afis()
//{
//    for(long long i=1;i<=n;++i)
//        cout<<tree[i]<< " ";
//    cout<<'\n';
//    for(long long i=1;i<=n;++i)
//    {
//        aux[i]=aux[i-1]+v[i];
//        cout<<aux[i]<< " ";
//    }
//cout<<'\n'<<'\n';
//}

long long m, a, b,c;
int main()
{
    fin>>n>>m;
    for(long long i=1;i<=n;++i)
    {
        fin>>v[i];
        update(i,v[i]);
    }

    for(long long i=1;i<=m;++i)
    {
        fin>>c;
        if(c==0)
        {
            fin>>a>>b;
            update(a,b);
        }
        if(c==1)
        {
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<'\n';
        }
        if(c==2)
        {
            fin>>a;//fout<<a<<" ";
            fout<<bin(a)<<'\n';
        }
    }

    return 0;
}
