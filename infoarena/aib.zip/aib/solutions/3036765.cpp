#include <bits/stdc++.h>

#define NMAX 100008

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

int BIT[NMAX];
int n, Q;

void Update(int pos, int value) {
    for(int i = pos; i <= n; i += i & (-i))
        BIT[i] += value;
}

int Query(int pos) {
    int ans = 0;
    for(int i = pos; i > 0; i -= i & (-i))
        ans += BIT[i];

    return ans;
}

int BySearch(int value) {
    int left = 0, right = n + 1;
    int sum = Query(n);

    int ans;
    if(value == sum) ans = n;

    int newN = n;
    while(newN) {
        newN = (left + right) / 2;
        sum = Query(newN);

        if(sum > value) {
            if(right > newN) right = newN;
            newN --;
        } else if(sum == value) {
            ans = min(ans, newN);
            right = newN;
            newN --;
        } else {
            if(left < newN) left = newN;
            newN ++;
        }        

        if(newN <= left)  break;
        if(newN >= right) break;
    }

    if(newN == n + 1) return -1;
    return ans;
}

int main() {
    fin >> n >> Q;
    for(int i = 1; i <= n; i ++) {
        int x; fin >> x;
        Update(i, x);
    }

    for(int i = 1; i <= Q; i ++) {
        int task; fin >> task;
        if(task == 0) {
            int a, b; fin >> a >> b;
            Update(a, b);
            continue;
        }

        if(task == 1) {
            int a, b; fin >> a >> b;
            fout << Query(b) - Query(a - 1) << '\n';
            continue;
        }

        int a; fin >> a;
        fout << BySearch(a) << '\n';
    }

    return 0;
}