#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

#define INFILE "aib.in"
#define OUTFILE "aib.out"

typedef long long ll;

#define VMAX 100010

int aib[VMAX], n, m;
int aux, tip, x, y;

void update(int position, int value){

    for(; position <= n; position += position & (-position)){

        aib[position] += value;

    }

}

int query(int position){

    int result = 0;

    for(; position > 0; position -= position & (-position)){

        result += aib[position];

    }

    return result;

}

int search(int value){

    int step = 1, position = 0;

    for(; step <= n; step <<= 1);

    for(; step > 0; step >>= 1){

        if(position + step <= n){

            if(aib[position + step] <= value){

                value -= aib[position + step];

                position += step;
            
            }

        }

    }

    return position;

}

void solve(){

    cin >> n >> m;

    // citirea elementelor vectorului
    for(int i = 1; i <= n; ++i){

        cin >> aux;

        update(i, aux);

    }

    // citirea operatiilor
    for(int i = 1; i <= m; ++i){
        
        cin >> tip;

        if(tip == 0){

            cin >> x >> y;

            update(x, y);

        }
        else if(tip == 1){

            cin >> x >> y;

            cout << query(y) - query(x - 1) << '\n';

        }
        else{

            cin >> x;

            int position = search(x - 1);

            if(query(position + 1) == x){
                cout << position + 1 << '\n';
            }
            else{
                cout << -1 << '\n';
            }

        }

    }


}

int main(){
    
    ios_base::sync_with_stdio(false);

    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);

    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();

    return 0;
}