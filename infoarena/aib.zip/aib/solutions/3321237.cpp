#include <iostream>
#include <fstream>

#define MAXN 100000

using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

long long aib[MAXN + 1];
int n;

int lsb(int i){
    return i & (-i);
}

long long query(int x){
    int i;
    long long sum;
    sum = 0;
    for(i = x; i > 0; i -= lsb(i)){
        sum += aib[i];
    }
    return sum;
}

void update(int x, int val){
    long long i;
    for(i = x; i <= n; i += lsb(i)){
        aib[i] += val;
    }
}

int main()
{
    int m, i, c, a, b, nr, ans, pas;
    long long sum;

    fin>>n>>m;

    for(i = 1; i <= n; i++){
        fin>>nr;
        update(i, nr);
    }

    for(i = 0; i < m; i++){
        fin>>c>>a;
        if(c == 0){
            fin>>b;
            update(a, b);
        }
        else if(c == 1){
            fin>>b;
            fout<<query(b) - query(a - 1)<<'\n';
        }
        else{
            ans = 0;
            sum = 0;
            for(pas = (1<<17); pas > 0; pas /= 2){
                if(ans + pas <= n && sum + aib[ans + pas] <= a){
                    ans += pas;
                    sum += aib[ans];
                }
            }
            if(ans == 0 || sum != a){
                fout<<-1<<'\n';
            }
            else{
                fout<<ans<<'\n';
            }
        }
    }

    fin.close();
    fout.close();

    return 0;
}
