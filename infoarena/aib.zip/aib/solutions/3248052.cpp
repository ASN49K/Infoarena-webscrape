#include <bits/stdc++.h>
#define NMAX 100000
#define int long long
using namespace std;
int v[NMAX+5];
int n;
void update(int i, int val)
{
    while(i<=n)
    {
        v[i]+=val;
        i+=(i&-i);
    }
}
int prefixsum(int i)
{
    int sum=0;
    while(i>0)
    {
        sum+=v[i];
        i-=(i&-i);
    }
    return sum;
}
int rangesum(int i, int j )
{
    return prefixsum(j)-prefixsum(i-1);
}
signed main()
{
    ifstream fin("aib.in");
    ofstream fout("aib.out");
    int m, i, op, a, b, rasp, mij, st, dr;
    fin>>n>>m;
    for(i=1; i<=n; i++)
    {
        fin >>a;    
        update(i,a);
    }
    for(i=1; i<=m; i++)
    {
        fin>>op>>a;
        if(op==0)
        {
            fin>>b;
            update(a, b);
        }
        else if(op==1)
        {
            fin>>b;
            fout<<rangesum(a, b)<< "\n";
        }
        else
        {
            st=1;
            dr=rasp=n;
            while(st<=dr)
            {
                mij=(st+dr)/2;
                if(prefixsum(mij)<a)
                    st=mij+1;
                else if(prefixsum(mij)>=a)
                {
                    rasp=mij;
                    dr=mij-1;
                }
            }
            if(prefixsum(rasp)!=a) fout<<"-1\n";
            else fout<<rasp<<"\n";
        }
    }
    return 0;
}