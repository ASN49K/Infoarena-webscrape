#include <fstream>
#include <cmath>
#include <cstdint>
#define int long long
using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int aib[100050];
int n,q;

void update(int pos,int val){
    for(int i=pos;i<=n;i=i+(i&(-i)))
        aib[i]+=val;
}

int query(int pos){
    int s=0;
    for(int i=pos;i>=1;i=i-(i&(-i)))
        s+=aib[i];
    return s;
}

int32_t main()
{
    cin>>n>>q;

    for(int i=1;i<=n;i++)
    {
        int a;
        cin>>a;
        update(i,a);
    }

    for(int i=1;i<=q;i++)
    {
        int c;
        cin>>c;

        if(c==0){
            int a,b;
            cin>>a>>b;
            update(a,b);
        }
        else if(c==1){
            int a,b;
            cin>>a>>b;
            cout<<query(b) - query(a-1)<<'\n';
        }
        else
        {
            int a;
            cin>>a;
            int s=0;
            int k = log2(n);
            int x = 0;
            while(k>=0)
            {
                if(x + (1<<k) <= n && s + aib[x + (1<<k)] < a)
                {
                    x+=(1<<k);
                    s+=aib[x];
                    k--;
                }
                else
                    k--;
            }
            s+=query(x+1) - query(x);
            if(s != a)
                cout<<-1<<'\n';
            else
                cout<<x<<'\n';
        }
    }

    return 0;
}
