#include <iostream>
#include <fstream>

using namespace std;

const int nmax = 100010;
int n, q;
int a[nmax], aib[nmax];

ifstream fin("aib.in");
ofstream fout("aib.out");

void update(int poz, int val)
{
    for (int i = poz; i <= n; i += (i & -i))
        aib[i] += val;
}

int query(int poz)
{
    int sum = 0;
    for (int i = poz; i >= 1; i -= (i & -i))
        sum += aib[i];
    return sum;
}

int cb(int val)
{
    int st = 1;
    int dr = n;
    while(st <= dr)
    {
        int mid = (st + dr) / 2;
        if(query(mid) == val)
            return mid;
        else
            if(val < query(mid))
                dr = mid - 1;
            else
                st = mid + 1;
    }
    return -1;
}

int main()
{
    fin >> n >> q;
    for (int i = 1; i <= n; i++)
        {
            fin>>a[i];
            update(i,a[i]);
        }

    while (q--)
    {
        int tip;
        fin >> tip;

        if (tip == 0)
        {
            int poz, val;
            fin >> poz >> val;
            update(poz, val);
        }
        else if (tip == 1)
        {
            int st, dr;
            fin >> st >> dr;
            fout << query(dr) - query(st - 1) << "\n";
        }
        else
        {
            int k;
            fin>>k;
            
            fout<<cb(k)<<"\n";
        }
    }
}