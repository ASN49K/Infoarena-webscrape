#include <bits/stdc++.h>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");

/**
0 x y : a[x] += y
1 x y : a[x] + ... + a[y]
2 s   : cea mai din stanga poz. p cu a[1]+...+a[p]=s


a = 2, 3, 0, 0, 0, 1,  1, 0, 0, 2
a = 2, 5, 5, 5, 5, 6, 10 10 10 12
*/

int aib[100003], n;

/// a[p] += x
void Update(int p, int x)
{
    while (p <= n)
    {
        aib[p] += x;
        p += (p & -p);
    }
}
/// a[1] + a[2] + ...+ a[p]
int Query(int p)
{
    int s = 0;
    while (p > 0)
    {
        s += aib[p];
        p -= (p & -p);
    }
    return s;
}

/// ret. cea mai din stanga pozitie p cu a[1]+...+a[p]=s
/// sau ret. -1 daca nu exista o astfel de pozitie
/// O(log n * log n)
int CautBin(int s)
{
    int p, st, dr, mij, suma;
    p = -1; st = 1; dr = n;
    while (st <= dr)
    {
        mij = (st + dr) / 2;
        suma = Query(mij);
        if (suma == s)
        {
            p = mij;
            dr = mij - 1;
        }
        else if (suma > s) dr = mij - 1;
        else st = mij + 1;
    }
    return p;
}

int main()
{
    int i, Q, op, x, y;
    fin >> n >> Q;
    for (i = 1; i <= n; i++)
    {
        fin >> x;
        Update(i, x);
    }
    for (i = 1; i <= Q; i++)
    {
        fin >> op;
        if (op == 0)
        {
            fin >> x >> y;
            Update(x, y);
        }
        else if (op == 1)
        {
            fin >> x >> y;
            fout << Query(y) - Query(x - 1) << "\n";
        }
        else /// op == 2
        {
            fin >> x;
            fout << CautBin(x) << "\n";
        }
    }
    return 0;
}
