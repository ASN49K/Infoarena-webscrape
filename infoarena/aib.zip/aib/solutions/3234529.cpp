#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("aib.in");
ofstream fout("aib.out");
int n;
int nrop;
int op;
long a,b;
int x;
long v[100010];
void update(int a, int b){
    for(int i=a; i<=n; i=i+(i&-i)){
        v[i]+=b;
    }

}
int sum(int b){
    int s=0;
    for (int i=1; i<=b; i+=(i&-i)){
        s+=v[i];
    }
    return s;
}
int findK(long target){ ///poz minima ca sa fie suma primelor k = a;
    int st=1;
    int dr=n;
    int mini=n+1; ///poz cautata
    while (st<=dr){
        int m=(st+dr)/2;
        if (target<=sum(m)){
            mini=m;
            dr=m-1;
        }
        else{
            st=m+1;
        }
    }
    if (sum(mini)==target){
        return mini;
    }
    return -1;
}
int main()
{
    fin >> n >> nrop;
    for (int i=1; i<=n; ++i){
        fin >> x;
        update(i,x);
    }
    for (int i=1; i<=nrop; ++i){
        fin >> op >> a;
        if (op==0){
            fin >> b;
            update(a,b);
        }
        else if (op==1){
            fin >> b;
            fout << sum(b)-sum(a-1) << '\n';
        }
        else if (op==2){
            fout << findK(a) << '\n';
        }
    }
    for (int i=1; i<=n; ++i){
        cout << v[i] <<' ';
    }
    return 0;
}
