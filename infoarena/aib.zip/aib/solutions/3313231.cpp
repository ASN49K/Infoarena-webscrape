#include <iostream>
#include <fstream>
#include <stdint.h>

const int64_t MAX_N = 100000;
const int64_t MAX_N_POW_2 = 1 << 16;

int64_t n, m;
int64_t sum[MAX_N + 1];

void AddVal(int64_t ind, int64_t val) {
	for(int64_t i = ind; i <= n; i += i & ~(i - 1))
		sum[i] += val;
}
int64_t GetSum(int64_t ind) {
	int64_t res = 0;
	for(int64_t i = ind; i; i -= i & ~(i - 1))
		res += sum[i];
	return res;
}
int64_t SearchSum(int64_t val) {
	int64_t pos = 0, total = 0;
	for(int64_t step = MAX_N_POW_2; step; step >>= 1) {
		if(pos + step <= n && total + sum[pos + step] <= val) {
			pos += step;
			total += sum[pos];
		}
	}
	if(pos && total == val) {
		return pos;
	} else {
		return -1;
	}
}

int main() {
	std::ifstream fin("aib.in");
	std::ofstream fout("aib.out");

	fin >> n >> m;
	for(int64_t i = 1; i <= n; ++i) {
		int64_t val;
		fin >> val;
		AddVal(i, val);
	}

	for(int64_t i = 1; i <= m; ++i) {
		int64_t c;
		fin >> c;

		if(c == 0) {
			int64_t a, b;
			fin >> a >> b;
			AddVal(a, b);
		} else if(c == 1) {
			int64_t a, b;
			fin >> a >> b;
			fout << (GetSum(b) - GetSum(a - 1)) << '\n';
		} else {
			int64_t a;
			fin >> a;
			fout << SearchSum(a) << '\n';
		}
	}

	fin.close();
	fout.close();

	return 0;
}