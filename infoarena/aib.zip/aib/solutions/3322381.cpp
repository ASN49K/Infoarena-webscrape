#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n, m;
vector<int> aib;

void add(int x, int y)
{
    for (int i = x; i <= n; i += (i & -i))
    {
        aib[i] += y;
    }
}

int sum(int x)
{
    int cnt = 0;
    for (int i = x; i >= 1; i -= (i & -i))
    {
        cnt += aib[i];
    }
    return cnt;
}

int check(int k)
{
    int ans = 0; // pozitia finala
    for (int i = (1 << 17); i; i >>= 1)
    {
        if (ans + i <= n && aib[ans + i] <= k)
        {
            ans += i;
            k -= aib[ans];
        }
    }
    if (k == 0)
        return ans;
    return -1;
}

int main()
{
    fin >> n >> m;
    aib.resize(n + 1);
    for (int i = 1; i <= n; i++)
    {
        int x;
        fin >> x;
        add(i, x);
    }
    for (int i = 0; i < m; i++)
    {
        int a;
        fin >> a;
        if (a == 0)
        {
            int b, c;
            fin >> b >> c;
            add(b, c);
        }
        else if (a == 1)
        {
            int b, c;
            fin >> b >> c;
            fout << sum(c) - sum(b - 1) << '\n';
        }
        else
        {
            int b;
            fin >> b;
            fout << check(b);
            fout << '\n';
        }
    }
    return 0;
}