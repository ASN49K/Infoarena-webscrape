#include <fstream>
#define NMAX 100005
using namespace std;
ifstream  fin("aib.in");
ofstream fout("aib.out");
int N,M,v[NMAX],aib[NMAX];

void citire()
{
    fin>>N>>M;

    for(int i=1; i<=N; i++)
    {
        fin>>v[i];
        aib[i]=v[i];
    }
}

void update(int x, int val)
{
    for(int i=x; i<=N; i+=(i&-i))
    {
        aib[i]+=val;
    }
}

int query(int x)
{
    int ans=0;
    for(int i=x; i>=1; i-=(i&-i))
    {
        ans+=aib[i];
    }
    return ans;
}

int find_sum(int a)
{
    int poz=0;

    int k=1;
    while(k*2<=N)
    {
        k=k*2;
    }

    for(int i=k; i>=1; i=i/2)
    {
        if(poz+i<=N && aib[poz+i]<=a)
        {
            a-=aib[poz+i];
            poz+=i;
        }
    }

    if(!a)
    {
        return poz;
    }
    else
    {
        return -1;
    }
}

int main()
{
    citire();

    for(int i=1; i<=N; i++)
    {
        int j=i+(i&-i);

        if(j<=N)
        {
            aib[j]+=aib[i];
        }
    }

    int op,a,b;
    for(int q=1; q<=M; q++)
    {
        fin>>op;

        if(op==0)
        {
            fin>>a>>b;
            v[a]+=b;
            update(a,b);
        }

        if(op==1)
        {
            fin>>a>>b;
            fout<< query(b)-query(a-1) << "\n";
        }

        if(op==2)
        {
            fin>>a;

            fout<< find_sum(a) << "\n";
        }
    }

    return 0;
}
