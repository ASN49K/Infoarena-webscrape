#include <fstream>
#include <iostream>
#define N 100005
std::ifstream fin("aib.in");
std::ofstream fout("aib.out");
int Tree[N], n;
void update(int pos, int element){
    while(pos <= n){
        Tree[pos] += element;
        pos += (pos & -pos);
    }
}
int query(int pos){
    int sum = 0;
    while(pos > 0){
        sum += Tree[pos];
        pos -= (pos & -pos);
    }
    return sum;
}
int search(int value){
    int left = 1, right = n;
    while(left <= right){
        int mid = left + (right - left)/2;
        int sum = query(mid);
        if(value > sum){
            left = mid + 1;
        }
        else if (value < sum){
            right = mid - 1;
        }
        else{
            return mid;
        }
    }
    return -1;
}
int main(){
    int m;
    fin >> n >> m;
    for(int i=1; i<=n; i++){
        int element;
        fin >> element;
        update(i, element);
    }
    for(int i=1; i<=m; i++){
        int op;
        fin >> op;
        if(op == 0){
            int pos, diff;
            fin >> pos >> diff;
            update(pos, diff);
        }
        else if(op == 1){
            int x, y;
            fin >> x >> y;
            fout << query(y) - query(x-1) << "\n";
        }
        else{
            int a, search_pos = -1;
            fin >> a;
            search_pos = search(a);
            fout << search_pos  << "\n";
        }
    }
}