#include <iostream>
#include <fstream>

using namespace std;

int n;
int m;

int aib[100001];

void update(int i, int val)
{
    for (i; i <= n; i += i & (-i))
    {
        aib[i] += val;
    }
}

int query(int i)
{
    int sum = 0;

    for (i; i > 0; i -= i & (-i))
    {
        sum += aib[i];
    }

    return sum;
}

int bsearch(int x)
{
    int l = 1;
    int r = n;
    int mid = 0;
    int s = 0;

    while (l <= r)
    {
        mid = (l + r) / 2;
        s = query(mid);

        if (s == x)
        {
            return mid;
        }

        if (s < x)
        {
            l = mid + 1;
        }

        else
        {
            r = mid - 1;
        }
    }

    return -1;
}

int main()
{
    ifstream fin("aib.in");
    ofstream fout("aib.out");

    int type = 0;
    int x = 0;
    int y = 0;

    fin >> n >> m;

    for(int i = 1; i <= n; i++)
	{
		fin >> x;
		update(i, x);
	}

	for(int i = 1; i <= m; i++)
	{
        type = 0;
        x = 0;
        y = 0;

		fin >> type;

		if(type == 0)
		{
			fin >> x >> y;
			update(x, y);
		}
		else if(type == 1)
		{
			fin >> x >> y;
			fout << query(y) - query(x - 1) << "\n";
		}
		else
		{
			fin >> x;
			fout << bsearch(x) << '\n';
		}
	}
}
