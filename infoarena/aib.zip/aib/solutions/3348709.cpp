#include <bits/stdc++.h>

using namespace std;

ifstream f("aib.in");
ofstream g("aib.out");

const int NMAX = 1e5 + 1;

int aib[NMAX];

void update ( int idx, int val )
{
    for ( int i = idx; i < NMAX; i += ( i & -i ) )
        aib[i] += val;
}

int compute ( int idx )
{
    int sol = 0;
    for ( int i = idx; i > 0; i -= ( i & -i ) )
        sol += aib[i];
    return sol;
}

int lb ( int x, int n, auto cond )
{
    int st = 1, dr = n;
    int sol = n + 1;
    while ( st <= dr )
    {
        int mij = ( st + dr ) / 2;
        if ( cond( mij ) <= x )
        {
            st = mij + 1;
            sol = mij;
        }
        else dr = mij - 1;
    }
    return sol;
}

int main()
{
    int n, q;
    f >> n >> q;
    for ( int i = 1; i <= n; i ++ )
    {
        int x;
        f >> x;
        update ( i, x );
    }
    int t, poz, x, a, b, sum;
    while ( q -- )
    {
        f >> t;
        if ( t == 0 )
        {
            f >> poz >> x;
            update ( poz, x );
        }
        else if ( t == 1 )
        {
            f >> a >> b;
            g << compute ( b ) - compute ( a - 1 ) << '\n';
        }
        else
        {
            f >> sum;
            g << lb ( sum, n, compute ) << '\n';
        }
    }
    return 0;
}
