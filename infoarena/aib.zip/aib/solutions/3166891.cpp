#include <array>
#include <iostream>
#include <chrono>
#include <fstream>

constexpr int nmax = 100000;

int aib[nmax + 5];
int n;

int ub(int x){

    return (x & (-x));

}

void add(int x, int y)
{

    for(int i = x; i <= n; i += ub(i)) {
        aib[i] += y;
    }

}

int sum(int x){
    int rez = 0;
    for(int i = x; i >= 1; i -= ub(i)){
        rez += aib[i];
    }
    return rez;
}

int main() {

    auto start = std::chrono::high_resolution_clock::now();


    std::ifstream in("aib.in");
    std::ofstream out("aib.out");

    int m;
    in >> n >> m;
    int A[n];
    for(int i = 1; i <= n; i++){
        in >> A[i-1];
        add(i, A[i-1]);
    }

    for(int i = 0; i < m; i++) {
        int op, a, b;
        in >> op >> a;
        if(op == 0){
            in >> b;
            add(a, b);
        }else if(op == 1){
            in >> b;
            out << sum(b) - sum(a-1) << "\n";
        }else {
            int st = 0, dr = n; 
            int mij = st + (dr - st)/ 2;
            int minval = n;
            while(st <= dr){
                if(sum(mij) == a){
                    minval = std::min(minval, mij);
                } 
                if(sum(mij) <= a){
                    st = mij + 1;
                }else {
                    dr = mij - 1;
                }
                mij = st + (dr-st)/2; 
            }
            out << minval << "\n";
        }
    }



    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
        
    std::cout << duration.count() / 1000.0f << " milliseconds" << std::endl;
    std::cin.get();
}
