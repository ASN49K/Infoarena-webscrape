#include <fstream>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");

int a[100001], v[100001];
int n;

int query(int p)
{
    int suma=0, i;
    for(i=p;i>0;i-=(i&-i))
    {
        suma+=a[i];
    }
    return suma;
}

void update(int poz, int val)
{
    int i;
    for(i=poz;i<=n;i+=(i&-i))
    {
        a[i]+=val;
    }
}

int cautbin(int s)
{
    int st, dr, mid, crt;
    st=1;
    dr=n;
    while(st<=dr)
    {
        mid=(st+dr)/2;
        crt=query(mid);
        if(crt>s)
        {
            dr=mid-1;
        }
        else
        if(crt<s)
        {
            st=mid+1;
        }
        else
        {
            return mid;
        }
    }
    return 0;
}

int main()
{
    int m, i, t, x, y, a;
    fin>>n>>m;
    for(i=1;i<=n;i++)
    {
        fin>>v[i];
        update(i, v[i]);
    }
    for(i=1;i<=m;i++)
    {
        fin>>t;
        if(t==0)
        {
            fin>>x>>y;
            update(x, y);
        }
        else
        if(t==1)
        {
            fin>>x>>y;
            fout<<query(y)-query(x-1)<<"\n";
        }
        else
        {
            fin>>a;
            x=cautbin(a);
            if(x!=0)
            {
                fout<<x<<"\n";
            }
            else
            {
                fout<<-1<<"\n";
            }
        }
    }
}
