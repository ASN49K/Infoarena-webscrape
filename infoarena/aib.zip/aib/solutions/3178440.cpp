#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream in("input.in");
ofstream out("output.out");
class binaryindexedtree {
private:
    vector<int> bit;
    const int size;
public:
    binaryindexedtree(const int auxsize) : bit(auxsize + 5, 0), size(auxsize) {
    };

    int ub(int x) {
        return (x & (-x));
    }

    void add(int x, int y) {
        for (int i = x; i <= size; i += ub(i))
            bit[i] += y;
    }

    int sum(int x) {
        int rez = 0;
        for (int i = x; i >= 1; i -= ub(i))
            rez += bit[i];
        return rez;
    }
};

int main() {
    int n, m;
    in >> n >> m;
    binaryindexedtree bit(n);
    for (int i = 1; i <= n; i++) {
        int x;
        in >> x;
        bit.add(i, x);
    }
    for (int i = 1; i <= m; i++) {
        int c;
        in >> c;
        if (c == 0) {
            int index, val;
            in>> index >> val;
            bit.add(index, val);
        }
        else if (c == 1) {
            int i1, i2;
            in >> i1 >> i2;
            out << bit.sum(i2) - bit.sum(i1-1);
            out << '\n';
        }
        else if (c == 2) {
            int suma;
            in >> suma;
            int left = 1, right = n, result = -1;

            while (left <= right) {
                int mid = (left + right) / 2;
                if (bit.sum(mid) >= suma) {
                    result = mid;
                    right = mid - 1;
                }
                else {
                    left = mid + 1;
                }
            }

            out << result << '\n';
        }
    }
}
