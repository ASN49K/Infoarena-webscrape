#include <bits/stdc++.h>

using namespace std;

#define MAXN 100000

int aib[MAXN + 1];

ifstream fin( "aib.in" );
ofstream fout( "aib.out" );

int n;

int query( int x ) {
    int sum = 0;
    for( ; x > 0; x -= ( x & -x ) )
        sum += aib[x];
    return sum;
}

void update( int p, int x ) {
    for( ; p <= n; p += ( p & -p ) )
        aib[p] += x;
}

int cautbin( int x ) {
    int sum, st, dr, mij;
    st = 1;
    dr = n;
    while( st <= dr ) {
        mij = ( st + dr ) / 2;
        sum = query( mij );
        if( sum > x )
            dr = mij - 1;
        else if( sum < x )
            st = mij + 1;
        else
            return mij;
    }
    return -1;
}

int main() {
    int q, x, a, b, i;

    fin >> n >> q;
    for( i = 1; i <= n; i++ ) {
        fin >> x;
        update( i, x );
    }

    while( q-- ) {
        fin >> x;
        if( x < 2 )
            fin >> a >> b;
        else
            fin >> a;

        if( x == 1 )
            fout << query( b ) - query( a - 1 ) << '\n';
        else if( x == 0 )
            update( a, b );
        else
            fout << cautbin( a ) << '\n';
    }

    return 0;
}
