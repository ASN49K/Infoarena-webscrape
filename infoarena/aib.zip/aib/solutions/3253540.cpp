#include <fstream>
using namespace std;
int n,m,v[100001],aib[100001],c,val,a,b;
void update(int pos, int val,int n){
    while(pos<=n){
        aib[pos]+=val;
        pos+=pos&-pos; //lsb
    }
}
int query(int pos){
    int ans=0;
    while (pos>0){
        ans+=aib[pos];
        pos-=pos&-pos;
    }
    return ans;
}
int cb(int a, int n){
    int pas=1<<20, pos=0, sc=0;
    while(pas){
        if (pos+pas<=n && sc+aib[pos+pas]<a){
            sc+=aib[pos+pas];
            pos+=pas;
        }
        pas/=2;
    }
    if (sc+aib[pos+1]==a)
        return pos+1;
    else return -1;
}
int main()
{
    ifstream fin("aib.in");
    ofstream fout("aib.out");
    fin>>n>>m;
    for (int i=1;i<=n;i++){
        fin>>v[i];
        update(i,v[i],n);
    }
    for (int i=1; i<=m;i++){
        fin>>c;
        if (c==0){
            fin>>a>>val;
            update(a,val,n);
        }
        if (c==1){
            fin>>a>>b;
            fout<<query(b)-query(a-1)<<'\n';
        }
        if (c==2){
            fin>>a;
            fout<<cb(a,n)<<'\n';
        }
    }
    return 0;
}
