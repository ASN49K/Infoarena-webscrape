#include <bits/stdc++.h>

using namespace std;

const int VMAX = 100005;

int n, queries;
int bit[VMAX];

void update(int pos, int val){

    for(int i = pos; i <= n; i += (i & -i)){
        bit[i] += val;
    }

}

int getSum(int pos){

    int ans = 0;

    for(int i = pos; i > 0; i -= (i & -i)){
        ans += bit[i];
    }

    return ans;

}

void solve(){

    cin >> n >> queries;

    for(int i = 1; i <= n; ++i){
        int aux; cin >> aux; update(i, aux);
    }

    for(int i = 0; i < queries; ++i){

        int type, x, y; cin >> type >> x;

        // cout << '\t' << "type: " << type << ", x: " << x << '\n';

        if(type == 0){
            cin >> y; update(x, y);
        }
        else if(type == 1){
            cin >> y; cout << getSum(y) - getSum(x - 1) << '\n';
        }
        else{

            int left = 1, right = n;

            while(left < right){

                int middle = (left + right); middle >>= 1;

                if(bit[middle] < x){
                    left = middle + 1;
                }
                else {
                    right = middle;
                }

            }

            if(bit[left] != x){
                cout << -1 << '\n';
            }
            else{
                cout << left << '\n';
            }

        }

    }

}

int main(){
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("aib.in", "r", stdin);
    freopen("aib.out", "w", stdout);
    solve();
    return 0;
}