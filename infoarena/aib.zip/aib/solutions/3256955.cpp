#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
const int Nmax = 1 * 1e5 + 5;
const int INF = 1e18;
const int zero = 0;
int n, m, type, a, b, BigBit,BigBit_copy = 0;
int aib[Nmax + 5],v[Nmax + 5];
int cautarea_lu_pascu(int x){
     int cn = n;
     int pos = 0,sum = 0;
     while(BigBit >= 0){
         if(sum + aib[(1 << BigBit)] <= x){
             pos += (1 << BigBit);
             sum += aib[(1<<BigBit)];
         }
         BigBit --;
     }
     return pos;
}
int query(int x){
    int sum = 0;
    for(int i = x; i >= 1; i -= (i & -i)){
        sum += aib[i];
    }
    return sum;
}
void update(int x,int val){
   for(int i = x;i <= n; i += (i & -i)){
       aib[i] += val;
   }
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    fin >> n >> m;
    for(int i = 1; i <= n; ++ i){
        fin >> v[i];
        update(i,v[i]);
    }
    BigBit = log2(n);
    BigBit_copy = BigBit;
    while(m){
        --m;
        fin >> type;
        if(type == 0){
            fin >> a >> b;
            update(a,b);
        }
        if(type == 1){
             fin >> a >> b;
             fout << query(b) - query(a - 1) << '\n';
        }
        if(type == 2){
            BigBit = BigBit_copy;
            fin >> a;
            fout << cautarea_lu_pascu(a) << '\n';
        }
    }
    return 0;
}
