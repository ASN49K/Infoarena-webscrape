#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

int aib[100001];
int n, m;

void update(int pos, int val) {
    for (; pos <= n; pos += pos & -pos)
        aib[pos] += val;
}

int query(int pos) {
    int s = 0;
    for (; pos >= 1; pos -= pos & -pos)
        s += aib[pos];
    return s;
}

int bins(int val) {
    int st = 1, dr = n-1;
    while (st <= dr) {
        int mij = (st + dr) / 2;
        if (query(mij) < val) st = mij + 1;
        else dr = mij - 1;
    }
    if (query(st) != val)
        return -1;
    return st;
}

int main() {
    cin >> n >> m;
    for (int in, i = 1; i <= n; ++i) {
        cin >> in;
        update(i, in);
    }
    for (int x, y, z, i = 1; i <= m; ++i) {
        cin >> x >> y;
        if (x == 0) {
            cin >> z;
            update(y, z);
        }
        else if (x == 1) {
            cin >> z;
            cout << query(z) - query(y - 1) << '\n';
        }
        else if (x == 2) {
            cout << bins(y) << '\n';
        }
    }
    return 0;
}