#include <fstream>

#include <cstdint>

using namespace std;

ifstream in("aib.in");
ofstream out("aib.out");

const int nmax = 1e5, lgmax = 18;
int n, nrq, a[nmax + 2], typee; int64_t xx, yy;

inline int f(int x){ return (x & (-x)); }
struct fenwicktree{
    int64_t tree[nmax + 2];

    void updateadd(int node, int vall){
        for(int i = node; i <= n; i += f(i))
            tree[i] += vall;
        return;
    }

    int64_t query(int node){
        int64_t summ = 0;
        for(int i = node; i >= 1; i -= f(i)){
            summ += tree[i];
        }
        return summ;
    }

    int getkth(int64_t xx){
        int pos = 0;
        for(int bit = lgmax; bit >= 0; bit--){
            if((pos | (1 << bit)) <= n && tree[pos | (1 << bit)] < xx)
                pos |= (1 << bit), xx -= tree[pos];
        }
        return pos + 1;
    }
} myaib;

int main(){

    in>>n>>nrq;
    for(int i = 1; i <= n; i++){
        in>>a[i];

        myaib.updateadd(i, a[i]);
    }

    for(int itq = 1; itq <= nrq; itq++){
        in>>typee;

        if(typee == 0){
            in>>xx>>yy;
            myaib.updateadd(xx, yy);
        }else if(typee == 1){
            in>>xx>>yy;
            out<<myaib.query(yy) - myaib.query(xx - 1)<<"\n";
        }else if(typee == 2){
            in>>xx;

            int st = 1, dr = n, mij, bestt = 0;
            for(; st <= dr; ){
                mij = (st + dr) >> 1;
                if(myaib.query(mij) >= xx){
                    dr = mij - 1, bestt = mij;
                }else{ st = mij + 1; }
            }

            out<<bestt<<"\n";
            ///out<<myaib.getkth(xx)<<"\n";
        }
    }

    return 0;
}
