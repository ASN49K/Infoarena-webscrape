#include <fstream>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

const int NMAX=1e5+5;
int n, m;
struct AIB
{
    int v[NMAX];
    int lsb(int x)
    {
        return x&-x;
    }
    int lg(int x)
    {
        return 31-__builtin_clz(x);
    }
    void update(int pos, int val)
    {
        for(int i=pos;i<=n;i+=lsb(i))
            v[i]+=val;
    }
    int query(int pos)
    {
        int ans=0;
        for(int i=pos;i>=1;i-=lsb(i))
            ans+=v[i];
        return ans;
    }
    int caut_bin(int a)
    {
        int poz=0, sum=0, pas=(1<<lg(n));
        while(pas)
        {
            if(poz+pas<=n && sum+v[poz+pas]<a)
            {
                poz+=pas;
                sum+=v[poz];
            }
            pas/=2;
        }
        if(query(poz+1)==a)
            return poz+1;
        return -1;
    }
}ds;

int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x; cin>>x;
        ds.update(i, x);
    }
    while(m--)
    {
        int t, a, b;
        cin>>t>>a;
        if(t==2)
            cout<<ds.caut_bin(a)<<'\n';
        else
        {
            cin>>b;
            if(t==0)
                ds.update(a, b);
            else
                cout<<ds.query(b)-ds.query(a-1)<<'\n';
        }
    }
    return 0;
}