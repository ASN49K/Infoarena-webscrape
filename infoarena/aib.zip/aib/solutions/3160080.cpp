#include <fstream>
#define DIM 100001
using namespace std;
ifstream fin("aib.in");
ofstream fout("aib.out");
int n,q,op,x,y,aib[DIM];

void update(int k,int val) {
    for (int i=k;i<=n;i+=(i&-i))
        aib[i]+=val;
}

int query(int k) {
    int s=0;
    for (int i=k;i>=1;i-=(i&-i))
        s+=aib[i];
    return s;
}

int cautbin(int x) {
    int st=1;
    int dr=n;
    while (st<=dr) {
        int mid=(st+dr)/2;
        int s=query(mid);
        if (x==s)
            return mid;
        if (x>s)
            st=mid+1;
        else
            dr=mid-1;
    }
    return -1;
}

int main() {
    fin>>n>>q;
    for (int i=1;i<=n;i++) {
        fin>>x;
        update(i,x);
    }
    while (q--) {
        fin>>op;
        if (op==0) {
            fin>>x>>y;
            update(x,y);
        }
        else
            if (op==1) {
                fin>>x>>y;
                fout<<query(y)-query(x-1)<<"\n";
            }
            else {
                fin>>x;
                fout<<cautbin(x)<<"\n";
            }
    }
    return 0;
}
