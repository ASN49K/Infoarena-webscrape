#include<fstream>
#include<iostream>
#include<cstdio>
using namespace std;

FILE *in=fopen("heapuri.in","r");
FILE *out=fopen("heapuri.out","w");

int ord[200010],poz_ord[200010],nr;
int H[200010],nrh;
//poz_ord indica sprea heap
//ord indica spre poz_ord dinspre heap
void adaugare_element(int val)
{
    int poz,aux;
    poz=++nrh;
    ord[poz]=++nr;
    poz_ord[nr]=poz;
    H[poz]=val;
    while(H[poz/2]>val && poz/2>0)
    {
        aux=H[poz];
        H[poz]=H[poz/2];
        H[poz/2]=aux;

        poz_ord[ord[poz]]=poz/2;
        poz_ord[ord[poz/2]]=poz;

        aux=ord[poz];
        ord[poz]=ord[poz/2];
        ord[poz/2]=aux;

        poz/=2;
    }
    //H[poz]=val;
    //poz_ord[++nr]=poz;
    //ord[poz]=nr;
}
void stergere_element(int poz)
{
    int aux,f1,f2,son;
    H[poz]=-1;
    //poz_ord[ord[nrh]]=poz;
    //ord[poz]=ord[nrh--];
    while(H[poz/2]>H[poz] && poz/2>0)
    {
        aux=H[poz];
        H[poz]=H[poz/2];
        H[poz/2]=aux;

        poz_ord[ord[poz]]=poz/2;
        poz_ord[ord[poz/2]]=poz;

        aux=ord[poz];
        ord[poz]=ord[poz/2];
        ord[poz/2]=aux;

        poz/=2;
    }
    H[1]=H[nrh];
    poz_ord[ord[nrh]]=1;
    ord[poz]=ord[nrh--];
    if(nrh>1)
    do{
        f1=poz*2;
        f2=f1+1;
        son=poz;
        if(f1<=nrh && H[f1]<H[son])
            son=f1;
        if(f2<=nrh && H[f2]<H[son])
            son=f2;
        if(son==poz)
            son=0;
        if(son)
        {
            aux=H[son];
            H[son]=H[poz];
            H[poz]=aux;

            aux=ord[son];
            ord[son]=ord[poz];
            ord[poz]=aux;

            poz_ord[ord[poz]]=poz;
            poz_ord[ord[son]]=son;

            poz=son;
        }

    }while(son);
}
int main()
{
    int n,k,o,x;
    fscanf(in,"%d",&n);
    for(k=1;k<=n;++k)
    {
        fscanf(in,"%d",&o);
        switch(o)
        {
            case(1):
                fscanf(in,"%d",&x);
                adaugare_element(x);
                break;
            case(2):
                fscanf(in,"%d",&x);
                stergere_element(poz_ord[x]);
                break;
            case(3):fprintf(out,"%d\n",H[1]);
                break;
        }
    }
    //cout<<n;
    return 0;
}
