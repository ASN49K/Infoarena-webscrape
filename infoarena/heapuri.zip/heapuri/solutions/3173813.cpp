using namespace std;
#include<iostream>
#include<fstream>
#include<vector>
#define NMAX 200005

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int n, t, x, nr;
struct nod{
    int val, pos;
} h[NMAX];

int l, p[NMAX];

void promoveaza(int i) {
    while (i != 1 && h[i].val < h[i/2].val) {
        swap(p[h[i].pos], p[h[i/2].pos]);
        swap(h[i], h[i/2]);
        i = i/2;
    }
}

int insereaza(int x, int pos) {
    
    l++;
    h[l].val = x;
    h[l].pos = pos;
    p[pos] = l;
    
    promoveaza(l);
}

void sterge(int pos) {
    
    swap(p[h[pos].pos], p[h[l].pos]);
    swap(h[pos], h[l]);
    l--;
    
    if (pos > 1 && h[pos/2].val > h[pos].val) {
        promoveaza(pos);
    } else {
        while ((pos*2 <= l && h[pos*2].val < h[pos].val) ||
                (pos*2+1 <= l && h[pos*2+1].val < h[pos].val)){
            
            if (pos*2+1 > l || h[pos*2].val < h[pos*2+1].val) { ///mergem in stanga
                swap(p[h[pos].pos], p[h[pos*2].pos]);
                swap(h[pos], h[pos*2]);
                pos = pos*2;
            } else {  ///mergem in dreapta
                swap(p[h[pos].pos], p[h[pos*2+1].pos]);
                swap(h[pos], h[pos*2+1]);
                pos = pos*2+1;
            }
            
        }
    }
}

int main() {
    
    fin >> n;

    for (int i = 1; i<=n; i++) {
        fin >> t;
        if (t == 1) {
            fin >> x;
            nr++;
            insereaza(x, nr);
            
           /* for (int j = 1; j<=l; j++) {
                cout << h[j].val << " ";
            }
            cout << endl;*/
        } else if (t == 2) {
            fin >> x;
            sterge(p[x]);
            
            /*for (int j = 1; j<=l; j++) {
                cout << h[j].val << " ";
            }
            cout << endl;*/
        } else if (t == 3) {
            fout << h[1].val << "\n";
        }
    }
    
    return 0;
}
