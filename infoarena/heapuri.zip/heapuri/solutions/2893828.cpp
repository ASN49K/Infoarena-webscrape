#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream is("heapuri.in");
ofstream os("heapuri.out");
#define nrmax 200005
int poz[nrmax], ord, aux[nrmax], heap[nrmax], n, nr_op;
int mx, l, r, parinte;
void heapify( int i){
    parinte = (i-1) /2;
    if(heap[(i-1) /2] > 0){
        if(heap[i]<heap[parinte]){
            swap(poz[ord], poz[aux[parinte]]);
            swap(heap[i], heap[parinte]);
            swap(aux[i], aux[parinte]);
            heapify(parinte);
        }
    }
}

void heapifyTop(int i){
    mx = i;
    l = 2 * mx + 1;
    r = 2 * mx + 2;

    if(l<n && heap[l] < heap[mx])
        mx = l;
    if(r<n && heap[r]<heap[mx])
        mx = r;
    if(mx != i){
        swap(poz[aux[i]], poz[aux[mx]]);
        swap(heap[i], heap[mx]);
        swap(aux[i], aux[mx]);
        heapifyTop(mx);
    }

}

void inserare(int elem){
    ord++;
    n++;
    heap[n-1] = elem;
    poz[ord] = n-1;
    aux[n-1] = ord;
    heapify(n-1);
}



void stergere(int k){
    int s1 = poz[k];
    heap[poz[k]] =  heap[n-1];
    swap(poz[k] ,poz[aux[n-1]]);
    swap(aux[s1], aux[n-1]);

    n--;
    for(int i = 0; i<=2; i++)
        heapifyTop(i);
}

void afisare(){
    for(int i =0; i<n;i++)
        cout<<heap[i]<<" ";
    cout<<endl;
}


int main()
{
    is>>nr_op;
    int op, val;
    while(nr_op){
        is>>op;
        if(op==3)
            os<<heap[0]<<endl;
        else{
            is>>val;
        if(op==1)
        {
            //is>>val;
            inserare(val);
        }
        if(op==2)
        {
            //is>>val;
            stergere(val);
        }
        }
        nr_op--;
    }
    return 0;
}
