#include <stdio.h>

using namespace std;
FILE *f=fopen("heapuri.in","r");
FILE *g=fopen("heapuri.out","w");

int n,m,i,x,h[200050],poz[200050],v[200050],nr,N,tip;



void  cern (int k)
{
int fiu=k,aux=0;
while(fiu){
 fiu=0;
 if(2*k<=nr && v[h[2*k]]<v[h[k]])fiu=2*k;
 if(2*k+1<=nr && v[h[2*k+1]]<v[fiu])fiu=2*k+1;
 //if (v[h[fiu]]<v[h[k]])fiu=0;
 if (fiu!=0){aux=h[k];h[k]=h[fiu];h[fiu]=aux;poz[h[k]]=k;poz[h[fiu]]=fiu;k=fiu;}
 }
}

void urc(int k)
{int aux;

  while(k>=1 && v[h[k]]<v[h[k/2]]) {
  aux=h[k];
  h[k]=h[k/2];
  h[k/2]=aux;
  poz[h[k]]=k;
  poz[h[k/2]]=k/2;
  k=k/2;
  }

  }


void cut(int k)
 {int aux;


aux=h[k];
h[k]=h[nr];
h[nr]=aux;
poz[h[k]]=k;
poz[h[nr]]=nr;
nr--;

cern(k);
}


void insert()
{
 h[++nr]=n;
 poz[n]=nr;
 urc(nr);
}



int main()
{

fscanf(f,"%d",&N);
for(i=1;i<=N;i++)
{
 fscanf(f,"%d",&m);
 if (m==1){fscanf(f,"%d",&x);v[++n]=x;insert(v[n]);}
 else if (m==2){fscanf(f,"%d",&x);cut(poz[x]);}
 else if (m==3)fprintf(g,"%d\n",v[h[1]]);
}

fclose(g);
return 0;
}

