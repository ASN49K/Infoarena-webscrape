#include <iostream>
#include <fstream>
#include <set>
#include <vector>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

vector<long> pozitii;
set<long> h;

void push(long x){
    h.insert(x);
    pozitii.push_back(x);
}
/*/
auto index(int x){
    set<int>::iterator it;
    for(it = h.begin(); it!=h.end(); it++){
        if(*it == x) return it;
    }
    return h.end();
}
*/
void pop(long x){
    int poz = pozitii[x-1];
    auto gasit = h.find(poz);
    h.erase(gasit);
}

int peak(){
    return *h.begin();
}

int main(){
    int n, operatie;
    long x;
    f>>n;
    for(int i=0;i<n;i++){
        f>>operatie;
        if(operatie == 1){
            f>>x;
            push(x);
        } else{
            if(operatie == 2){
                f>>x;
                pop(x);
            }else g<<peak()<<'\n';
        }
    }
    return 0;
}
