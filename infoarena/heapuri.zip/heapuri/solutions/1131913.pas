program heap;
const MAX_HEAP_SIZE = 16384;
var H,intr : array [1..MAX_HEAP_SIZE] of longint;
    k,i,n,t,l,j,b,a,min : longint;

function tata( nod : longint) : longint;
    begin
       tata:=nod div 2;
    end;
function fiu_sting( nod : longint) : longint;
    begin
       fiu_sting:=nod * 2;
    end;
function fiu_drept( nod : longint) : longint;
    begin
       fiu_drept:=nod * 2+1;
    end;

procedure swap(var x,y : longint);
  var aux : longint;
    begin
       aux:=x;
       x:=y;
       y:=aux;
    end;


procedure coboara( n, k : longint);
  var fiu : longint;
    begin
         repeat
               fiu:=0;
               if fiu_sting(k)<n then
                  begin
                       fiu:=fiu_sting(k);
                       if H[fiu_drept(k)]>H[fiu_sting(k)] then fiu:=fiu_drept(k);
                       if H[fiu]<=H[k] then fiu:=0
                  end
                                  else  if fiu_sting(k)=n then
                                        begin
                                              fiu:=fiu_sting(k);
                                              if H[fiu]<=H[k] then fiu:=0;
                                        end;
                  if fiu<>0 then begin
                                       swap(H[k],H[fiu]);
                                       k:=fiu;
                                 end;

         until fiu=0;
   end;

procedure ridica(n,k : longint);
   var aux : longint;
     begin
       aux:=H[k];
         while ((k<>1)and(aux>H[tata(k)])) do begin
                                                   H[k]:=H[tata(k)];
                                                   k:=tata(k);
                                             end;
         H[k]:=aux;
       end;

procedure sterge(var n : longint ; k : longint);
  begin
    H[k]:=H[n];
    n:=n-1;
    if ((k>1) and (H[k]>H[tata(k)])) then ridica(n,k)
                                     else coboara(n,k);
  end;

procedure inserare(var n  : longint; k : longint) ;
  begin
      n:=n+1;
      H[n]:=k;
  end;



begin
   assign(input,'heapuri.in'); reset(input);
   assign(output,'heapuri.out'); rewrite(output);
   readln(t);  n:=0; l:=0;

   for i:=1 to t do begin
                         read(a);
                         if a=1 then begin
                                           readln(b);
                                           inserare(n,b);
                                           l:=l+1;
                                           intr[l]:=b;
                                     end else
                         if a=2 then begin
                                           readln(b);
                                           sterge(n,b);



                                     end else
                          if a=3 then begin
                                           min:=H[1];
                                           for j:=2 to n do
                                             if H[j]<min then min:=H[j];
                                             writeln(min);
                                             readln;
                                     end;
   end;
   close(input);
   close(output);
end.
