#include<iostream>
#include<stdio.h>
#define MAX 200008
using namespace std;
int Heap[MAX],Pos[MAX],n,nrord;

void push(int x)
{
    n++;
    int poz=n;
    Heap[poz]=x;
    nrord++;
    Pos[nrord]=x;
    while(poz/2>0 && Heap[poz]<Heap[poz/2])
    {
        swap(Heap[poz],Heap[poz/2]);
        poz=poz/2;
    }
}
void pop(int x)
{
    int i,poz;
    for(i=1;i<=n;i++)
        if(Heap[i]==Pos[x])
    {
        Heap[i]=Heap[n];
        n--;
        poz=i;
        break;
    }
    while(poz/2>0&&Heap[poz]<Heap[poz/2])
    {
        swap(Heap[poz],Heap[poz/2]);
        poz=poz/2;
    }
    while((Heap[2*poz]<Heap[poz]&&2*poz<=n) ||(Heap[2*poz+1]<Heap[poz]&&2*poz+1<=n))
    {
        if(Heap[2*poz]<Heap[poz]&& (Heap[2*poz]<Heap[2*poz+1] || 2*poz+1>n))
        {
            swap(Heap[2*poz],Heap[poz]);
            poz=2*poz;
        }
        else
            if(Heap[2*poz+1]<Heap[poz] && Heap[2*poz+1]<Heap[2*poz])
        {
            swap(Heap[2*poz],Heap[poz]);
            poz=2*poz+1;
        } 
    }
}
int main()
{
     FILE *f,*g;
     int nrop,i,op,tp;
     f=fopen("heapuri.in","r");
     g=fopen("heapuri.out","w");
     fscanf(f,"%d",&nrop);
     for(i=0;i<nrop;i++)
     {
         fscanf(f,"%d",&op);
         if(op==1)
         {
             fscanf(f,"%d",&tp);
             push(tp);
         }
         if(op==2)
         {
             fscanf(f,"%d",&tp);
             pop(tp);
         }
         if(op==3)
            fprintf(g,"%d\n",Heap[1]);
     }
     fclose(f);
     fclose(g);
     return 0;
}
