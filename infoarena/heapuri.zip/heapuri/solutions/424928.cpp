#include <cstdio>
#include <vector>
#include <set>
using namespace std;

set <int> heap;
vector <int> order;

long n, code, x;

int main()
{
	freopen ("heapuri.in", "rt", stdin);
	freopen ("heapuri.out", "wt", stdout);

	scanf("%ld", &n);
	for (long i = 0; i < n; ++i)
	{
		scanf("%ld", &code);
		switch (code)
		{
			case 1: 
			{
				scanf("%ld", &x);
				if (x == 427)
					x = 427;
				heap.insert(x);
				order.push_back(x);
				break;
			}
			case 2:
			{
				scanf("%ld", &x);
				heap.erase(order[x - 1]);
				break;
			}
			case 3:
			{
				printf("%ld\n", *heap.begin());
				break;
			}
		}
	}

	return 0;
}
