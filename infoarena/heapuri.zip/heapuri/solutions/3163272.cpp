#include <fstream>
#define MAX 200000
using namespace std;
ifstream cin ("heapuri.in");
ofstream cout ("heapuri.out");
struct Heap
{
    int val, pos;
};
Heap heap[MAX + 10];
int v[MAX + 10], hsz, added;
void addNode(int val)
{
    added++;
    hsz++;
    heap[hsz].val = val;
    heap[hsz].pos = added;
    v[added] = hsz;
}
void up(int node)
{
    if (node != 1 && heap[node / 2].val > heap[node].val)
    {
        swap(heap[node / 2], heap[node]);
        swap(v[heap[node / 2].pos], v[heap[node].pos]);
        up(node / 2);
    }
}
void deleteNode(int node)
{
    swap(heap[node], heap[hsz]);
    swap(v[heap[node].pos], v[heap[hsz].pos]);
    hsz--;
}
void down(int node)
{
    if (2 * node == hsz)
    {
        if (heap[2 * node].val < heap[node].val)
        {
            swap(heap[2 * node], heap[node]);
            swap(v[heap[2 * node].pos], v[heap[node].pos]);
        }
    }
    else
        if (2 * node < hsz)
        {
            int child;
            if (heap[2 * node].val < heap[2 * node + 1].val)
                child = 2 * node;
            else
                child = 2 * node + 1;
            if (heap[child].val < heap[node].val)
            {
                swap(heap[child], heap[node]);
                swap(v[heap[child].pos], v[heap[node].pos]);
                down(child);
            }
        }
}
int main()
{
    int n;
    cin >> n;
    hsz = 0;
    added = 0;
    for (int i = 1; i <= n; i++)
    {
        int type;
        cin >> type;
        if (type == 3)
            cout << heap[1].val << '\n';
        else
        {
            int val;
            cin >> val;
            if (type == 1)
            {
                addNode(val);
                up(hsz);
            }
            else
            {
                int pos = v[val];
                deleteNode(pos);
                down(pos);
                up(pos);
            }
        }
    }
    return 0;
}
