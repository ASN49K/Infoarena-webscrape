#include <iostream>
#include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
const int N=2e5+1;
int n,nh;
int v[N],h[N],poz[N];

void schimb(int p, int q){
    swap(h[p],h[q]);
    poz[h[p]]=p;
    poz[h[q]]=q;
}

void urca(int p){
    while(v[h[p]]<v[h[p/2]]){
        schimb(p,p/2);
        p/=2;
    }
}

void adauga(int val){
    h[++nh]=val;
    urca(nh);
}

void coboara(int p){
    int fs=2*p,fd=2*p+1,bun=p;
    if(fs<=nh && v[h[fs]]<v[h[bun]])
        bun=fs;
    if(fd<=nh && v[h[fd]]<v[h[bun]])
        bun=fd;
    if(bun!=p){
        schimb(p,bun);
        coboara(bun);
    }
}

void sterge(int p){
    if(p==nh){
        nh--;
    }else{
        schimb(p,nh--);
        urca(p);
        coboara(p);
    }
}

int main()
{
    int cnt=0;
    f>>n;
    for(int i=1; i<=n; i++){
        int c;
        f>>c;
        if(c==1){
            f>>v[++cnt];
            poz[cnt]=cnt;
            adauga(cnt);
        }else
        if(c==2){
            int x;
            f>>x;
            sterge(poz[x]);
        }
        else{
            g<<v[h[1]]<<'\n';
        }
    }
    return 0;
}
