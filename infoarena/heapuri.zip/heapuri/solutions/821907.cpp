#include <iostream>
#include <cstdlib>
#include <cstdio>

#define nmax 200000

using namespace std;

int heap[nmax],poz[nmax],cr[nmax],x,n,nr = 0,l = 0;

void swap ( int &a , int &b )
{
    int aux;
    aux = a;
    a = b;
    b = aux;
    aux = poz[a];
    poz[a] = poz[b];
    poz[b] = aux;
}

int leftson ( int k )
{
    return 2*k;
}
int rightson ( int k )
{
    return 2*k+1;
}
int father ( int k )
{
    return k/2;
}
void upheap  ( int k )
{
    if ( k/2 < 1 || heap[father ( k )] < heap[k] )    return;
        else if ( heap[father ( k )] > heap[k] )
                {
                    swap ( heap[father ( k )] , heap[k] );
                    return upheap ( father(k) );
                }
}
void downheap ( int k )
{

    if ( leftson ( k ) > nr )   return;

     if ( heap[leftson ( k )] <= heap[k] )
     {
            int min = leftson ( k );
            if ( rightson ( k ) <= nr && heap[rightson ( k )] < heap[min] )
                min = rightson ( k );
            swap ( heap[k] , heap[min] );
            return downheap ( min );
     }

    return;
}
void insertheap ( int x)
{
    nr++;
    heap[nr] = x;
    poz[x] = nr;
    upheap(nr);
}
void removeheap ( int pozx )
{
    swap ( heap[pozx] , heap[nr] );
    nr--;
    downheap ( pozx );
}
int main()
{
    FILE *fin,*fout;
    fin = fopen ( "heapuri.in" , "r" );
    fout = fopen ( "heapuri.out" , "w" );

    fscanf ( fin , "%d" , &n );
    int op;
    for ( int i = 1 ; i <= n ; i++ )
    {
        fscanf ( fin , "%d" , &op );
        if ( op == 1 )
        {
            fscanf ( fin , "%d" , &x );
            cr[++l] = x;
            insertheap ( x );
        }
        if ( op == 2 )
        {
            fscanf ( fin , "%d" , &x );
            removeheap ( poz[cr[x]] ) ;
        }
        if ( op == 3 )  fprintf ( fout , "%d\n" , heap[1] );

    }
    fclose ( fin ) ;
    fclose ( fout );
    return 0;
}
