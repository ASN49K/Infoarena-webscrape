#include <iostream>
#include <fstream>
#define DMAX 200001

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int nr;
int val[DMAX];//date de intrare
int n, arb[DMAX], n1;//n - nr de elem. puse in arborele arb

inline int tataNod(int k){
  return k / 2;
}

inline int fiuStanga(int k){
  return k * 2;
}

inline int fiuDreapta(int k){
  return k * 2 + 1;
}

//tatal unui nod trebuie sa fie mai mic decat toti fii sai
void validareSus(int k){
  int valoareNod = arb[k];
  while((k > 1) && (arb[tataNod(k)] > valoareNod)){
    arb[k] = arb[tataNod(k)];
    k = tataNod(k);
  }
  arb[k] = valoareNod;
}

void inserare(int valoare){
  val[++ n1] = valoare;
  arb[++ n] = valoare;
  validareSus(n);
}

void validareJos(int k){
  int fiu;// decid pe ce ramura ma duc
  do{
    fiu = 0;
    if(fiuStanga(k) <= n){
      fiu = fiuStanga(k);
      if((k <= n/2) && (arb[fiuStanga(k)] > arb[fiuDreapta(k)])){
        fiu = fiuDreapta(k);
      }
      if(arb[fiu] > arb[k]){
        fiu = 0;
      }
    }
    if(fiu != 0){
      swap(arb[k], arb[fiu]);
      k = fiu;
    }
  }while(fiu != 0);
}

void stergereArb(int k){
  arb[k] = arb[n];
  n--;
  if((k > 1) && arb[k] < arb[tataNod(k)]){
    validareSus(k);
  }else{
    validareJos(k);
  }
}

int elemDeSters(int k){
  for(int i = 1; i <= n; i++){
    if(arb[i] == val[k]){
      return i;
    }
  }
}

inline void minim(){
  out << arb[1] << '\n';
}

void citire(){
  int tip ;
  in >> nr;
  for(int i = 1; i <= nr; i++){
    in >> tip;
    if(tip == 1){
      int x;
      in >> x;
      inserare(x);//ok
    }else if(tip == 2){
      int x;
      in >> x;
      int deSters = elemDeSters(x);
      stergereArb(deSters);
    }else{
      minim();
    }
  }

}

int main(){
  citire();
  return 0;
}
