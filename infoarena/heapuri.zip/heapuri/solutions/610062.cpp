#include <fstream>
#include <set>
#define nmax 200001
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int n,a[nmax],i,x,o,val;
multiset <int> heap;

int main () {
    f >> n;
    for (i=1;i<=n;i++) {
        f >> o;
        if (o==1) {
            x++;f >> a[x];
            heap.insert(a[x]);
        }
        if (o==2) {
            f >> val;
            heap.erase(heap.find(a[val]));
        }
        if (o==3) {
            multiset <int> :: iterator it=heap.begin();
            g << (*it) << '\n';
        }
    }
    f.close();g.close();
    return 0;
}
