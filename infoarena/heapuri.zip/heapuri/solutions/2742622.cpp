#include <iostream>
#include <fstream>
#include <set>
using namespace std;

int main() {
    multiset<long long> heap;
    ifstream fin("heapuri.in");
    ofstream fout("heapuri.out");
    long long n, option, k = 0, x, v[200001];
    fin>>n;
    for (int i = 0; i < n; ++i) {
        fin>>option;
        if(option == 3)
            fout<<*heap.begin()<<endl;
        else {
            fin >> x;
            if (option == 1){
                heap.insert(x);
                v[k++] = x;
            }
            else
                heap.erase(heap.find(v[x - 1]));
        }
    }
    return 0;
}
