#include <stdio.h>
#define N 200005

int n,i,q,x,lh,l;
int heap[N],ord[N],poz[N];
///heap[i]=el i din heap; max i=lh
///ord[i]= al catelea el este heap[i]; max i=lh
///poz[i]= unde se gaseste in heap al i-lea element; max i=l

void sch(int p1,int p2)
{
    int aux;
    aux=heap[p1];
    heap[p1]=heap[p2];
    heap[p2]=aux;

    poz[ord[p1]]=p2;
    poz[ord[p2]]=p1;

    aux=ord[p1];
    ord[p1]=ord[p2];
    ord[p2]=aux;
}
int up(int p)
{
    while(p/2!=0 && heap[p]<heap[p/2])
    {
        sch(p,p/2);
        p=p/2;
    }
    return p;
}
int down(int p)
{
    while(p*2<=lh && p>0)
    {
        if(heap[p]>heap[p*2])
        {
            if(heap[p*2]>heap[p*2+1] && p*2+1<=n)
            {
                sch(p,p*2+1);
                p=p+p+1;
            }
            else
            {
                sch(p,p*2);
                p=p+p;
            }
        }
        else if(heap[p]>heap[p*2+1] && p*2+1<=n)
        {
            sch(p,p*2+1);
            p=p+p+1;
        }
        else
            break;
    }
    return p;
}
void adauga(int x)
{
    lh++;l++;

    heap[lh]=x;
    ord[lh]=l;
    poz[l]=lh;

    up(lh);
}
void sterge(int p)
{
    sch(lh,p);
    heap[lh]=1000000100;
    lh--;

    down(p);
    up(p);
}
int main()
{
    FILE *f1,*f2;
    f1=fopen("heapuri.in","r");
    f2=fopen("heapuri.out","w");

    fscanf(f1,"%d",&n);
    while(n--)
    {
        fscanf(f1,"%d",&q);
        if(q==3)
            fprintf(f2,"%d\n",heap[1]);
        else
        {
            fscanf(f1,"%d",&x);
            if(q==1)
            {
                adauga(x);
            }
            if(q==2)
            {
                sterge(poz[x]);
            }
        }
    }
    return 0;
}
