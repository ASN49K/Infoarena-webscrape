//Ilie Dumitru
#include<cstdio>
#define NMAX 200005
using namespace std;

int VAL[NMAX], pos[NMAX], pos2[NMAX], NRH=1, NRL=1;

void heap_up(int i)
{
    int aux=pos[i];
    while(i>1 && VAL[aux]<VAL[pos[i>>1]])
    {
        pos[i]=pos[i>>1];
        pos2[pos[i]]=i;
        i>>=1;
    }
    pos[i]=aux;
    pos2[pos[i]]=i;
}

void heap_down(int i)
{
    int aux=pos[i], aux2=pos2[i];
    bool ok=true;
    while((i<<1)<NRH && ok)
    {
        ok=false;
        if((i<<1)+1<NRH)
        {
            if(VAL[pos[i<<1]]>VAL[pos[(i<<1)+1]])
            {
                if(VAL[pos[(i<<1)+1]]<VAL[aux])
                {
                    pos[i]=pos[(i<<1)+1];
                    pos2[pos[i]]=(i<<1)+1;
                    ok=true;
                }
            }
            else
                if(VAL[pos[i<<1]]<VAL[aux])
                {
                    pos[i]=pos[i<<1];
                    pos2[pos[i]]=i<<1;
                    ok=true;
                }
        }
        else
        {
            if(VAL[pos[i<<1]]<VAL[aux])
            {
                pos[i]=pos[i<<1];
                pos2[pos[i]]=i<<1;
                ok=true;
            }
        }
        i<<=1;
    }
    pos[i]=aux;
    pos2[i]=aux2;
}

void heap_out(int i)
{
    i=pos2[i];
    pos[i]=pos[NRH-1];
    pos2[pos[i]]=i;
    --NRH;
    heap_up(i);
    heap_down(i);
}

int main()
{
    FILE *f=fopen("heapuri.in", "r"), *g=fopen("heapuri.out", "w");
    int N, cod, x;

    fscanf(f, "%i", &N);
    while(N)
    {
        --N;
        fscanf(f, "%i", &cod);
        if(cod<3)
            fscanf(f, "%i", &x);
        if(cod==1)
        {
            VAL[NRL]=x;
            pos[NRH]=NRL;
            pos2[NRL]=NRH;
            ++NRL;
            ++NRH;
            heap_up(NRH-1);
        }
        else
        {
            if(cod==3)
                fprintf(g, "%i\n", VAL[pos[1]]);
            else
                heap_out(x);
        }
    }
}
