//ALEX ENACHE

#include <vector>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>

using namespace std;

//#include <iostream>
#include <fstream>
ifstream cin ("heapuri.in");ofstream cout ("heapuri.out");

int arb[800100];

const int infinit = 1e9;

//pozitia nodului actual , st si dr intervalului corespunzator nodului ,
//pozitia pe care inserez , valoarea inserata
void update(int nod , int st , int dr , int pos , int val){

    //cand ajung la o frunza
    if (st == dr){
        arb[nod] = val;
        return;
    }
    int mij = st + dr;
    mij /= 2;
    if (pos <= mij){
        update (nod*2 , st , mij , pos , val);
    }
    else{
        update (nod*2+1 , mij+1 , dr , pos , val);
    }
    arb[nod] = min(arb[nod*2] , arb[nod*2+1]);
}


int main() {

    //freopen("input", "r", stdin);freopen("output", "w", stdout);

    for (auto &x : arb){
        x = infinit;
    }

    //nr intrebari
    int n;
    cin>>n;

    int pos = 0;

    for (int i=1; i<=n; i++) {
        int tip;
        cin >> tip;

        if (tip == 1){
            pos++;
            int x;
            cin>>x;
            update (1 , 1 , n , pos , x);
        }
        if (tip == 2){
            int x;
            cin>>x;
            update (1 , 1 , n , x , infinit);
        }
        if (tip == 3){
            cout<<arb[1]<<'\n';
        }
    }

    return 0;
}