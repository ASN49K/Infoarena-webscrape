#include <iostream>
#include <fstream>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int arb[800800];

const int inf=1e9;

void update(int nod, int st, int dr, int pos, int val)
{
    if(st==dr){
        arb[nod]=val;
        return;
    }
    int mij=(st+dr)/2;
    if(pos<=mij){
        update(nod*2,st,mij,pos,val);
    }
    else{
        update(nod*2+1,mij+1,dr,pos,val);
    }

    arb[nod]=min(arb[nod*2],arb[nod*2+1]);

}

int main()
{
    for(auto &x : arb){
        x=inf;
    }

    int n;
    in>>n;

    int pos=0;
    for(int i=1;i<=n;i++)
    {
        int tip;
        in>>tip;

        if(tip==1){
            pos++;
            int x;
            in>>x;
            update(1,1,n,pos,x);
        }
        if(tip==2){
            int x;
            in>>x;
            update(1,1,n,x,inf);
        }
        if(tip==3){
            out<<arb[1]<<'\n';
        }
    }



    return 0;
}
