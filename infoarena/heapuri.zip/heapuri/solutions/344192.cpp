#include <stdio.h>
#define N 1<<18
int n,tip,nr;
int heap[N],r;
int t,val,q;
int numere[N],pozitie[N];
void interschimba(int poz1, int poz2)
{
	int temp = heap[poz1],temp2=pozitie[heap[poz1]];
	pozitie[heap[poz1]]=pozitie[heap[poz2]];
	pozitie[heap[poz2]]=temp2;
	heap[poz1] = heap[poz2];
	heap[poz2] = temp;
}
void mut_in_sus(int poz)
{
	if (poz > 1 && numere[heap[poz/2]] > numere[heap[poz]]) 
	{
		interschimba(poz, poz/2);
		mut_in_sus(poz/2);
	}
}
void mut_in_jos(int poz)
{
	if ((2*poz  <= r && numere[heap[poz]] > numere[heap[2*poz]] ) ||
		(2*poz+1<= r && numere[heap[poz]] > numere[heap[2*poz+1]])) 
		{
			int minimum = 2*poz;
			if (2*poz+1 <= r && numere[heap[2*poz+1]] < numere[heap[2*poz]]) 
				minimum = 2*poz+1;
			interschimba(poz, minimum);
			mut_in_jos(minimum);
		}
}
int gasesc_minim()
{
	return numere[heap[1]];
}
int main()
{
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	scanf("%d",&n);
	int i;
	for (i=1; i<=n; i++)
	{
		scanf("%d",&tip);
		if (tip!=3)
			scanf("%d",&nr);
		if (tip==1)
		{
			q++;
			numere[q]=nr;
			heap[++r]=q;
			pozitie[q]=r;
			mut_in_sus(r);
		}
		if (tip==2)
		{
			pozitie[heap[r]]=pozitie[nr];
			nr=pozitie[nr];
			heap[nr]=heap[r];
			r--;
			mut_in_jos(nr);
		}
		if (tip==3)
			printf("%d\n",gasesc_minim());
	}
	return 0;
}
