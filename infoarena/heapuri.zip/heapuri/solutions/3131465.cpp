#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>

std::ifstream fin("C:\\Users\\Dell\\OneDrive\\Sharing\\tema-sd-3\\heapuri.in");
std::ofstream fout("C:\\Users\\Dell\\OneDrive\\Sharing\\tema-sd-3\\heapuri.out");
//std::ifstream fin("heapuri.in");
//std::ofstream fout("heapuri.out");

int v[10000], nr;

int main() {
    int n, tipOp, x;
    std::set<int> heap;

    fin >> n;
    for (int i = 0; i < n; ++i) {
        fin >> tipOp;
        switch(tipOp) {
            case 1: {
//                se insereaza elementul x in multime
                fin >> x;
                heap.insert(x);
                nr++;
                v[nr] = x;
                break;
            }
            case 2: {
//                se sterge elementul intrat al x-lea in multime, in ordine cronologica
                fin >> x;
                heap.erase(v[x]);
                break;
            }
            case 3: {
//                se afiseaza elementul minim din multime
//                std::cout << *heap.begin() << "\n";
                fout << *heap.begin() << "\n";
                break;
            }
        }
    }
    return 0;
}