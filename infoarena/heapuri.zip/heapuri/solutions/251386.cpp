#include<stdio.h>
#define MAX 200003
FILE*f=fopen("heapuri.in","r");
FILE*g=fopen("heapuri.out","w");
int H[MAX], Poz[MAX], Ord[MAX];
int N, NR;
// Poz[i] - pozitia in heap al elem intrat al i-lea in multime
// Ord[i] - pe poz i in heap , se afla elementul intrat al Ord[i]-lea in mul

void swap(int K, int T)
 {
   int aux;
   aux=H[K]; H[K]=H[T]; H[T]=aux;

   aux=Ord[K]; Ord[K]=Ord[T]; Ord[T]=aux;

   aux=Poz[Ord[K]];
   Poz[Ord[K]] = Poz[Ord[T]];
   Poz[Ord[T]]=aux;
 }
    
void insert(int x)  //Inserez x in heap
 {
 N++;
 Poz[++NR]=N; // elementul intrat al NR-lea se afla pe poz N in heap
 Ord[N]=NR;
 H[N]=x;
 int T=N/2;
 int K=N;
 while(K>1 && ( H[K] < H[T]))
   {
    swap(K,T);
    K=K/2;
    T=K/2;
   }
 }
void del(int x) // Sterg elementul intrat al x-lea in multime<=>Sterg Poz[x]
 {
 
  int i,K,aux;
  K=Poz[x];
  H[K] = H[N];
  Ord[K] = Ord[N];
  Poz[Ord[N]] = K;
  --N;
  int fiu;
  do
   {
    fiu=0;
    if(2*K <= N && H[K] > H[2*K]) fiu=2*K;
    if(2*K+1<=N && H[2*K]>H[2*K+1]) fiu=2*K+1;
    if(H[fiu] >= H[K]) fiu=0;
    if(fiu)
      {
        swap(fiu, K);
        K=fiu;
      }
   }
  while(fiu);
 }
int main()
 {
  int n;
  fscanf(f,"%d",&n);
  int cod,x;
  while(n--)
   {
    fscanf(f,"%d",&cod);
    if(cod<3)
     {
      fscanf(f,"%d",&x);
      if(cod==1)
       {
        insert(x);
       }
      else del(x);
     }
    else
     fprintf(g,"%d\n",H[1]);
   }
 return 0;
 }
