#include <iostream>
#include <fstream>
#include <set>

using namespace std;

ifstream inputFile("heapuri.in");
ofstream outputFile("heapuri.out");

int main() {
    int n, i, operation, value;
    inputFile >> n;
    int array[n + 1], length = 0;
    set<int> heap;

    for (i = 1; i <= n; i++) {
        inputFile >> operation;

        if (operation == 3) {
            outputFile << *heap.begin() << endl;
        } else {
            inputFile >> value;

            if (operation == 1) {
                array[length++] = value;
                heap.insert(value);
            }

            if (operation == 2)
                heap.erase(array[value - 1]);
        }
    }

    return 0;
}