#include <fstream>

using namespace std;
ifstream cin("heapuri.in");
ofstream cout("heapuri.out");
int nh,v[200005],h[200005],poz[200005];
void schimb(int p, int q)
{
    swap(h[p],h[q]);
    poz[h[p]]=p;
    poz[h[q]]=q;
}
void urca(int p)
{
    while(p>1&&v[h[p]]<v[h[p/2]])
    {
        schimb(p,p/2);
        p/=2;
    }
}
void adauga(int p)
{
    h[++nh]=p;
    poz[p]=nh;
    urca(nh);
}
void coboara(int p)
{
    int fs=2*p, fd=2*p+1, bun=p;
    if(fs<=nh&&v[h[fs]]<v[h[bun]])
    {
        bun=fs;
    }
    if(fd<=nh&&v[h[fd]]<v[h[bun]])
    {
        bun=fd;
    }
    if(bun!=p)
    {
        schimb(bun,p);
        coboara(bun);
    }
}
void sterge(int p)
{
    schimb(p,nh--);
    urca(p);
    coboara(p);
}
int main()
{
    int n,cod,x,nc=0;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>cod;
        if(cod==1)
        {
            cin>>v[++nc];
            adauga(nc);
        }
        if(cod==2)
        {
            cin>>x;
            sterge(poz[x]);
        }
        if(cod==3)
        {
            cout<<v[h[1]]<<"\n";
        }
    }
    return 0;
}
