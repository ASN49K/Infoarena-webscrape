#include <stdio.h>
#include <utility>
using namespace std;
#define NMAX 200001

pair<int, int> h[NMAX];
int pos[NMAX];
int hsize;
int op, val, n, k;

void MoveUp(int index);
void MoveDown(int index);
int GetMin();
void Swap(int index1, int index2);

int main()
{
	freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);

	scanf("%d", &n);
	for (k = 1; k <= n; k++)
	{
		scanf("%d", &op);

		if (op < 3) scanf("%d", &val);

		switch(op)
		{
			case 1: 
				hsize++;
				h[hsize].first = val;
				h[hsize].second = k;
				pos[k] = hsize;
				MoveUp(hsize);
				break;
			case 2: 
				h[pos[val]] = h[hsize];
				pos[h[hsize].second] = pos[val];
				MoveDown(pos[val]);
				pos[val] = -1;
				break;
			case 3:
				printf("%d\n", GetMin());
				break;
		}
	}
	return 0;
}

void MoveUp(int index)
{
	if (h[index].first < h[index/2].first && index/2 > 0)
	{
		Swap(index, index/2);
		pos[h[index].second] = index;
		pos[h[index/2].second] = index/2;
		MoveUp(index/2);
	}
}

void MoveDown(int index)
{
	int minCh = 2*index;

	if (2*index + 1 <= hsize && h[2*index+1] < h[minCh])
		minCh = 2*index+1;

	if (minCh <= hsize && h[minCh] < h[index])
	{
		Swap(index, minCh);
		pos[h[index].second] = index;
		pos[h[minCh].second] = minCh;
		MoveDown(minCh);
	}
}

int GetMin()
{
	return h[1].first;
}

void Swap(int index1, int index2)
{
	int aux = h[index1].first;
	h[index1].first = h[index2].first;
	h[index2].first = aux;
	aux = h[index1].second;
	h[index1].second = h[index2].second;
	h[index2].second = aux;
}
