#include <fstream>
#include <set>

using namespace std;
set<int>h;
int v[200010];
int p,i,n,x,m;
int main()
{
    ifstream fin ("heapuri.in");
    ofstream fout ("heapuri.out");
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>p;
        if(p==1)
        {
            fin>>x;
            h.insert(x);
            m++;
            v[m]=x;
        }
        else if(p==2)
        {
            fin>>x;
            h.erase(v[x]);
        }
        else
        {
            fout<<*h.begin()<<'\n';
        }
    }
    return 0;
}
