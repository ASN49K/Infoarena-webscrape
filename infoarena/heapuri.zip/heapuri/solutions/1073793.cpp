#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("heapuri.in");
ofstream g ("heapuri.out");
#define maxn 200010

int n,l,nr;
int A[maxn], Heap[maxn], Pos[maxn];

void push(int x)
{

    while (x/2 && A[Heap[x]]<A[Heap[x/2]])
    {
        swap(Heap[x],Heap[x/2]);

        Pos[Heap[x]] = x;
        Pos[Heap[x/2]] = x/2;
        x /= 2;
    }
}

void pop(int x)
{
    int  y = 0;

    while (x != y)
    {
        y = x;

        if (y*2<=l && A[Heap[x]]>A[Heap[y*2]]) x = y*2;
        if (y*2+1<=l && A[Heap[x]]>A[Heap[y*2+1]]) x = y*2+1;

        swap(Heap[x],Heap[y]);

        Pos[Heap[x]] = x;
        Pos[Heap[y]] = y;
    }
}

int main()
{

    int i, x, cod;
    l=0;nr=0;

    f>>n;

    for (i=1; i<=n; i++)
    {
        f>>cod;
        if (cod < 3)
           f>>x;

        if (cod == 1)
        {
            l++; nr++;
            A[nr] = x;
            Heap[l] = nr;
            Pos[nr] = l;

            push(l);
        }

        if (cod == 2)
        {
            A[x] = -1;
            push(Pos[x]);

            Pos[Heap[1]] = 0;
            Heap[1] = Heap[l--];
            Pos[Heap[1]] = 1;
            if (l>1) pop(1);
        }

        if (cod == 3) g<<A[Heap[1]]<<'\n';
    }
    f.close();
    g.close();
    return 0;
}
