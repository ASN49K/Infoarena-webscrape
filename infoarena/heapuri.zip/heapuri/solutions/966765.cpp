#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<vector>

using namespace std;

#define MAX_SIZE 16384

template <typename T>
class Heap {

	public:
		Heap();
		void pushDown(int);
		void pushUp(int);
		T pop();
		T peek();
		void insert(T);
		int left(int);
		int right(int);
		void show();
		void sort();
		void remove(int);
		void rem_nth_el(int);
	private:
		vector<T> heap;
		T position[MAX_SIZE];
		int size, pos_ind;
};

template<typename T>
Heap<T>::Heap() {
	size = 0;
}

template <typename T>
int Heap<T>::left(int poz)
{
	if(2 * poz + 1 > size)
		return -1;
	return 2 * poz + 1;
}

template <typename T>
int Heap<T>::right(int poz)
{
	if(2 * poz + 2 > size)
		return -1;
	return 2 * poz + 2;
}

template <typename T>
void Heap<T>::insert(T val) {
	heap.push_back(val);
	position[val] = size;
	pushUp(size);
	size++;
}

template <typename T>
void Heap<T>::pushUp(int poz) {
	int fp = (poz - 1)/2;
	while(heap[poz] < heap[fp]) {		
		swap(heap[poz], heap[fp]);
		//swap(position[heap[poz].ind], position[heap[fp].ind]);
		position[heap[poz]] = poz;
		position[heap[fp]] = fp;
		poz = fp;
		fp = (poz - 1)/2;
	}
}

template <typename T>
void Heap<T>::pushDown(int poz) {
	int son = left(poz);
	if ( (son > 0) && (right(poz) > 0) && (heap[son]> heap[right(poz)]) ) {
		son = right(poz);
	}
	if(son > 0 && (heap[son] < heap[poz])) {
		swap(heap[poz], heap[son]);
		//swap(position[heap[poz].ind], position[heap[son].ind]);
		position[heap[son]] = son;
		position[heap[poz]] = poz;
		pushDown(son);
	}
}

template <typename T>
T Heap<T>::peek() {
	return heap[0];
}

template <typename T>
T Heap<T>::pop() {
	T save = heap[0];
	heap[0] = heap[size - 1];
	size--;
	pushDown(0);
	return save;
}

template <typename T>
void Heap<T>::remove(int nr) {
	int poz = position[nr];
	position[heap[size-1]] = position[heap[poz]];
	heap[poz] = heap[size-1];
	//swap(heap[poz] , heap[size-1]);
	heap.pop_back();
	size--;
	pushDown(poz);
}


template <typename T>
void Heap<T>::sort() {
	int dim = size;
	for(int i = 0; i < dim; i++)
		cout<<pop()<<" ";
	cout<<"\n";
}


template<typename T>
void Heap<T>::show() {
	for(int i = 0; i < size; i++)
		cout<<heap[i]<<" ";
	cout<<"\n";
	for(int i = 0; i < 100; i++)
		cout<<position[i]<<" ";
	cout<<"\n";
}


int main() {
	Heap<int> h;
	vector<int> order;
	int n, cod, x;
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w", stdout);
	scanf("%d", &n);
	for(int i = 0; i < n; i++) {
	
		scanf("%d",&cod);
		
		if(cod == 1) {
			scanf("%d", &x);
			h.insert(x);
			order.push_back(x);
		}
		
		if(cod == 2) {
			scanf("%d", &x);
			h.remove(order[x-1]);
		}
		
		if(cod == 3) {
			printf("%d\n",h.peek());
		}
		
	}
	//h.remove(order[1 - 1]);
	//h.remove(order[3 - 1]);
	/*h.remove(order[2 - 1]);
	h.remove(order[4 - 1]);
	printf("%d\n",h.peek());
	h.insert(70);
	h.show();*/
	/*cout<<"aici show--";h.show();
	h.rem_nth_el(2);
	cout<<"aici show--";h.show();
	h.rem_nth_el(4);
	cout<<"aici show--";h.show();*/
	
	return 0;
}

