#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
long long int n,k,a[200100],m=1,b[200100],nr[200100];
void urc(int i)
{   int t=i/2;
    while(a[t]>a[i])
    {   int c1=a[i], c2=nr[i];
        a[i]=a[t];
        a[t]=c1;
        nr[i]=nr[t];
        nr[t]=c2;
        b[nr[i]]=i;
        b[nr[t]]=t;
        i=t;
        t=i/2;
    }
}
void cob(int i)
{   int f1=2*i;
    int f2=2*i+1;
    int mini;
    if(a[f1]>a[f2]&&f2<=k) mini=f2;
    else mini=f1;
    while(a[i]>a[mini]&&mini<=k)
    {   int c1=a[i],c2=nr[i];
        a[i]=a[mini];
        a[mini]=c1;
        nr[i]=nr[mini];
        nr[mini]=c2;
        b[nr[mini]]=mini;
        b[nr[i]]=i;
        i=mini;
        f1=2*i;
        f2=2*i+1;
        if(a[f1]>a[f2]&&f2<=k) mini=f2;
        else mini=f1;
    }

}
void ins(int x)
{   a[++k]=x;
    nr[k]=m++;
    b[nr[k]]=k;
    urc(k);
    cob(k);
}
void del(int x)
{   a[b[x]]=a[k];

    k--;
    urc(b[x]);
    cob(b[x]);
    b[x]=0;
}
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {   int cod;
        f>>cod;
        if(cod==3) g<<a[1]<<'\n';
        else
        {   int x;
            f>>x;
            if(cod==1) ins(x);
            else del(x);
        }
    }
    return 0;
}
