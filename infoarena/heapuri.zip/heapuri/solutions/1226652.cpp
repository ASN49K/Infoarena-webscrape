#include <cstdio>
#include <set>
#define NMAX 200010

using namespace std;

set<int>heap;
int op,i,x,t,poz[NMAX],nr;

int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&op);
        if(op==3)
        {
            printf("%d\n",*heap.begin());
            continue;
        }
        scanf("%d",&x);
        if(op==1)
        {
            heap.insert(x);
            poz[++nr]=x;
        }
        if(op==2)
            heap.erase(poz[x]);
    }
    return 0;
}
