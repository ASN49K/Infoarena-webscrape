#include <bits/stdc++.h>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
struct node
{
    int val,pos;
};
node heap[200005];
int aux[200010];
int sz=0,cnt=0;
void swap1(int node1,int node2)
{
    swap(heap[node1],heap[node2]);
    swap(aux[heap[node1].pos],aux[heap[node2].pos]);
}
void urc(int node)
{
    bool ok=1;
    while(node>1 && ok)
    {
        int tata=node/2;
        if(heap[node].val<heap[tata].val)
        {
            swap1(node,tata);
        }
        else ok=0;
        node=tata;
    }
}
void cobor(int node)
{
    int fiu=-1;
    if(node*2<=sz)
    {
        fiu=2*node;
        if(2*node+1<=sz && heap[fiu].val>heap[2*node+1].val)
        {
            fiu=2*node+1;
        }
    }
    if(fiu==-1) return;
    if(heap[fiu].val<heap[node].val)
    {
        swap1(fiu,node);
        cobor(fiu);
    }
}
void add(int val)
{
    sz++;
    heap[sz].val=val;
    heap[sz].pos=cnt;
    aux[cnt]=sz;
    urc(sz);
}
void rem(int pos)
{
    int posx=aux[pos];
    swap1(posx,sz);
    sz--;
    urc(posx);
    cobor(posx);
}
int main()
{
    int n,tip,x;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>tip;
        if(tip==1)
        {
            fin>>x;
            cnt++;
            add(x);
        }
        else if(tip==2)
        {
            fin>>x;
            rem(x);
        }
        else
        {
            fout<<heap[1].val<<'\n';
        }
    }
    return 0;
}
