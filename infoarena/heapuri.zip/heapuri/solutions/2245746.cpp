#include <cstdio>

using namespace std;

int Xs[200010], Heap[200010], Pos[200010];
int hn;

void percolate(int p)
{
    int aux;

    while(p > 1 && Xs[Heap[p/2]] > Xs[Heap[p]])
    {
        aux = Heap[p];
        Heap[p] = Heap[p/2];
        Heap[p/2] = aux;

        Pos[Heap[p]] = p;
        Pos[Heap[p/2]] = p/2;

        p = p/2;
    }
}

void sift(int p)
{
    int son, aux;
    do
    {
        son = 0;
        if(p*2 <=hn && Xs[Heap[p*2]] < Xs[Heap[p]])
            son = p*2;
        if(p*2+1 <= hn && Xs[Heap[p*2+1]] < Xs[Heap[p]] &&
           (son == 0 || Xs[Heap[son]] > Xs[Heap[p*2+1]]))
                son = p*2+1;
        if (son == 0)
            continue;

        aux = Heap[p];
        Heap[p] = Heap[son];
        Heap[son] = aux;

        Pos[Heap[p]] = p;
        Pos[Heap[son]] = son;

        p = son;
    } while (son);
}

void push(int val, int i)
{
    ++hn;
    Xs[i] = val;
    Heap[hn] = i;
    Pos[i] = hn;

    percolate(hn);
}

void pop(int ord)
{
    int poz = Pos[ord];
    Heap[poz] = Heap[hn];
    Pos[Heap[poz]] = poz;
    --hn;

    if (poz > 1 && Xs[Heap[poz/2]] > Xs[Heap[poz]])
        percolate(poz);
    else
        sift(poz);
}

int main()
{
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);

    int n = 0, m, i, j, x, comm;
    scanf("%d", &m);

    for(i=1; i<=m; ++i)
    {
        scanf("%d", &comm);
        switch (comm)
        {
            case 1:
            {
                scanf("%d", &x);
                ++n;
                push(x, n);
               /* for(j=1; j<=hn; ++j)
                    printf("%d ", Heap[j]);
                printf("\n");
                for(j=1; j<=hn; ++j)
                    printf("%d ", Xs[Heap[j]]);
                printf("\n\n"); */
                continue;
            }
            case 2:
            {
                scanf("%d", &x);
                pop(x);
                continue;
            }
            case 3:
                printf("%d\n", Xs[Heap[1]]);
        }
    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}
