#include <fstream>

#define swap(a,b) { int aux = a; a = b; b = aux; }
#define NMAX 2000010
#define MAXVAL 1000000000

int N, H[NMAX], nr=-1, poz=-1, POZ[NMAX], A[NMAX];

using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");

void reparaHeap(int p)
{
    int t;
    //reparare dupa o inserare la sfirsit
    if (p==nr){
        while (p>0 && A[H[p]]<A[H[(p-1)/2]]){
            swap(POZ[H[p]],POZ[H[(p-1)/2]]);
            swap(H[p],H[(p-1)/2]);
            p = (p-1)/2;
        }
    } else { //reparare dupa o eliminare
        while ((2*p+1<=nr && A[H[p]]>A[H[2*p+1]]) || (2*p+2<=nr && A[H[p]]>A[H[2*p+2]])){
            if (2*p+2<=nr && A[H[2*p+1]]>A[H[2*p+2]]) t = 2*p+2; else t = 2*p+1;
            swap(POZ[H[p]],POZ[H[t]]);
            swap(H[p],H[t]);
            p = t;
        }
    }
}

void insereaza(int x)
{
    nr++;
    poz++;
    A[poz] = x;
    POZ[poz] = nr;
    H[nr] = poz;
    reparaHeap(nr);
}

void elimina(int x)
{
    int poz = POZ[x-1];
    POZ[H[nr]] = POZ[H[poz]];
    H[poz] = H[nr];
    nr--;
    reparaHeap(poz);
}

int main()
{
    int c,x;
    f >> N;
    for (; N--;){
        f >> c;
        if (c==1) { f >> x; insereaza(x); } else
        if (c==2) { f >> x; elimina(x); } else
        if (c==3) { g << A[H[0]] << '\n'; }
    }
}
