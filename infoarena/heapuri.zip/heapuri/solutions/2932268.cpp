#include <bits/stdc++.h>
using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

#define pii pair<int,int>

bool comp(pii a,pii b)
{
    return a.second < b.second;
}

priority_queue<pii,vector<pii>,greater<pii> > heap;

void del(int poz)
{
    stack<pii> st;

    while(heap.top().second != poz)
    {
        st.push(heap.top());
        heap.pop();
    }

    heap.pop();

    while(!st.empty())
    {
        heap.push(st.top());
        st.pop();
    }
}

int main()
{
    int n; in>>n;

    int nr=0;
    while(n--)
    {
        int tip,x; in>>tip;

        if(tip != 3) in>>x;

        switch(tip)
        {
        case 1: heap.push({x,++nr});
            break;
        case 2: del(x);
            break;
        case 3: out<<heap.top().first<<'\n';
            break;
        }
    }
}
