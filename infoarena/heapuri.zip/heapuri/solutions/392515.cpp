#include<stdio.h>
#define in "heapuri.in"
#define out "heapuri.out"
#define lgmax 200002
int n=0,heap[lgmax],ord[lgmax],poz[lgmax];
inline void min(){printf("%d\n",heap[1]);return;}

void printheap(){for (int i=1;i<=n;i++)printf("%d ",heap[i]);printf("\n");}

void heapup(int v)
{
	int w=v>>1;
	while(v>1 && heap[v] < heap[w])
	{
		heap[v]^=heap[w]^=heap[v]^=heap[w];
		poz[heap[v]]^=poz[heap[w]]^=poz[heap[v]]^=poz[heap[w]];//actualizare pozitie
		v=w; w=v>>1;//actualizam nodul
	} 
	//printheap();
}
void addheap(int k)
{
	heap[++n]=k;
	poz[k]=n; //initializare pozitie
	heapup(n);
}
void heapdown(int v) 
{
	int w=v<<1;
	while(w<=n)
	{
		if(w+1<=n && heap[w]>heap[w+1])//stabililm fiul minim
			w++;
		if(heap[w]<heap[v]) //verificam daca e necesara schimbarea
		{
			heap[v]^=heap[w]^=heap[v]^=heap[w];
			poz[heap[v]]^=poz[heap[w]]^=poz[heap[v]]^=poz[heap[w]];//actualizare pozitie
		}
		v=w; w=v<<1; //actualizam nodul
	}
	//printheap();
}

void delheap(int v)
{
	poz[heap[v]]=0; 
	heap[v]=heap[n--]; //schimba cu ultimul nod , sterge ultimul nod;
	poz[heap[v]]=v; //actualizeaza pozitia;
	if(v!=1 && heap[v]<=heap[v>>1])
		heapup(v);
	else
		heapdown(v);
}
int main ()
{
	int i,t,cod,x,contor=0;
    freopen (in,"r",stdin);
    freopen (out,"w",stdout);
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d",&cod);
		switch (cod)
		{
			case 1 :
			{ /*insert*/
				scanf("%d",&x);
				contor++;
				ord[contor]=x;
				addheap(x);
				break;
			}
			case 2 :
			{ 	
				scanf("%d",&x);	
				x=poz[ord[x]];
				delheap(x);
				/*delete*/
				break;
			}
			case 3 : 
			{/*afiseaza min*/
				min();
				break;
			}
		}
		
	}

		
    return 0;
}
