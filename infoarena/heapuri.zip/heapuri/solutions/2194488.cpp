#include <fstream>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
const int N=200001;
int h[N],nh,nr,poz[N],v[N],n;
void urca(int p)
{
    while(p>1 && v[h[p]]<v[h[p/2]])
    {
        swap(h[p],h[p/2]);
        swap(poz[h[p]],poz[h[p/2]]);
        p=p/2;
    }
}
void adauga(int a)
{
    v[++nh]=a;
    poz[nh]=++nr;
    h[nr]=nh;
    urca(nr);
}
void coboara(int p)
{
    int fs=p*2,fd=p*2+1,bun=p;
    if(fs<=nr && v[h[fs]]<v[h[bun]])
        bun=fs;
    if(fd<=nr && v[h[fd]]<v[h[bun]])
        bun=fd;
    if(bun!=p)
    {
        swap(h[p],h[bun]);
        swap(poz[h[p]],poz[h[bun]]);
        coboara(bun);
    }

}
void sterge(int x)
{
    int p=poz[x];
    swap(h[p],h[nr]);
    swap(poz[h[p]],poz[h[nr]]);
    nr--;
    coboara(p);
}
int main()
{
    in>>n;
    int c,x;
    for(int i=1;i<=n;i++)
    {
        in>>c;
        if(c==1)
        {
            in>>x;
            adauga(x);
            //for(int j=1;j<=nr;j++)
                //out<<h[j]<<' ';
            //out<<'\n';
        }
        else if(c==2)
        {
            in>>x;
            sterge(x);
            //for(int j=1;j<=nr;j++)
                //out<<h[j]<<' ';
            //out<<'\n';

        }
        else
            out<<v[h[1]]<<'\n';

    }
    return 0;
}
