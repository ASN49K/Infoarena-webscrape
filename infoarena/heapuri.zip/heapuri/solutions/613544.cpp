#include <fstream>

using namespace std;

int r,desters,inst,m,h[200005],i,j,n,k,a[200005];

void swap (int k, int t)
{
    int x;
    x=h[k];
    h[k]=h[t];
    h[t]=x;
}

void HeapUp(int k)
{
    int t;
    if (k>1)
    {
        t=k/2;
        if (h[t]<h[k])
         {
             swap(k,t);
             HeapUp(t);
         }
    }
    else return;
}

void HeapDw(int r, int k)
{
    int st,dr,i;
    if (r*2<=k)
    {
        st=h[r*2];
        if (r*2+1<=k) dr=h[r*2+1]; else dr=st-1;
        if (st>dr) i=2*r; else  i=2*r+1;
        if (h[i]>h[r])
        {
            swap(i,r);
            HeapDw(i,k);
        }
    }
}

void HeapSort(int k)
{
    while (k>1)
    {
        swap(1,k);
        k--;
        HeapDw(1,k);
    }
}
int main()
{
    ifstream f("in.txt");
    ofstream g("out.txt");
    f>>n;
    for (i=1; i<=n; i++ )
	{
     		f>>inst;
     		if (inst==1) {
     		    f>>h[++m];
                a[++r]=h[m];
     		}
        			else if (inst==2)
            				{


                					f>>desters;
                					for (j=1;j<=m;j++) if(h[j]==a[desters]) break;
                                    h[j] =h[m];
                					h[m]=0;
                					m--;

            				}
                    else if (inst==3) {
                        for (j=1; j<=m; j++)    HeapUp(j);
                            HeapSort(m);
                            g<<h[1]<<'\n';
    				}
    	}
    return 0;
}
