#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
struct element
{
    int poz,valoare;
    bool sters;
};
vector <element> v;
bool compar_val(element a, element b)
{
    return a.valoare < b.valoare;
}
int main()
{
    ifstream fin("heapuri.in");
    ofstream fout("heapuri.out");
    int n;
    fin>>n;
    int op, pozitie=0, val;
    element x;
    for(int i=1;i<=n;i++)
    {
       fin>>op;
       if(op==1)
       {
          fin>>val;
          pozitie++;
          x.valoare=val;
          x.poz=pozitie;
          x.sters=0;
          v.push_back(x);
       }
       else if(op==2)
       {
           int p;
           fin>>p;
           for(int j=0;j<v.size();j++)
           {
               if(v[j].poz==p)
               {
                   v[j].sters=1;
               }
           }
       }
       else
       {
           sort(v.begin(),v.end(),compar_val);
           int j=0;
           while(v[j].sters==1)
           {
               j++;
           }
           fout<<v[j].valoare<<'\n';
       }
    }
    return 0;
}
