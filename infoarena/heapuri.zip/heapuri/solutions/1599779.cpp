
#include <bits/stdc++.h>

using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
#define MAX 200008
#define INF
int heap[MAX],v[MAX],poz[MAX],nh,ntot,n,t,x;
void add(int val)
{
    ++nh;
    ++ntot;
    v[ntot]=val;
    heap[nh]=ntot;
    poz[ntot]=nh;
    int nod=nh;
    while(nod>1&&v[heap[nod]]<v[heap[nod/2]])
    {
        swap(poz[heap[nod]],poz[heap[nod/2]]);
        swap(heap[nod],heap[nod/2]);
        nod=nod/2;
    }
}
void sterge(int pos)
{
    int nod=poz[pos];
    swap(heap[poz[pos]],heap[nh]);
    swap(poz[heap[poz[pos]]],poz[heap[nh]]);
    --nh;
    while(nod*2<=nh)
    {
        int fiu_min=nod*2;
        if(nod*2+1<=nh&&v[heap[nod*2]]>v[heap[nod*2+1]])
        {
            fiu_min=nod*2+1;
        }
        if(v[heap[nod]]>v[heap[fiu_min]])
        {
            swap(poz[heap[nod]],poz[heap[fiu_min]]);
            swap(heap[nod],heap[fiu_min]);
            nod=fiu_min;
        }
        else break;
    }
}
int main()
{
    in>>n;
    while(n--)
    {
        in>>t;
        if(t==1)
        {
            in>>x;
            add(x);
        }
        if(t==2)
        {
            in>>x;
            sterge(x);
        }
        if(t==3)out<<v[heap[1]]<<'\n';
    }



    return 0;
}
