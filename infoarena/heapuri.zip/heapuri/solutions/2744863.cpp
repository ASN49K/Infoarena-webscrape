#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
//structura unui nod din heap(retine valoarea si numarul de ordine al elementului-al catelea a intrat in heap)
struct nod
{
    int val, nr_ordine;
};

nod H[200005];
int N=0; //nr de elemente din heapul H de la un anumit moment de timp
int vp[200005]; //vector care retine pozitia din heap pentru fiecare element

//functii pt heap
int indice_fiu_mic(int i, int n)
{
    if(2*i+1 <= n)
        if(H[2*i+1].val < H[2*i].val)
            return 2*i+1;
        else return 2*i;
    else if(2*i <=n)
        return 2*i;
    else
        return 0;
}

void urca(int i)
{
    if(i > 1)
    {
        if(H[i].val < H[i/2].val)
        {
            swap(vp[H[i].nr_ordine], vp[H[i/2].nr_ordine]); //actualizez in vectorul de pozitii schimbarea pe care o fac
            swap(H[i], H[i/2]);
            urca(i/2);
        }
    }
}

void coboara(int i, int n)
{
    if(i <= n/2) //daca s-ar afla in a doua jumatate a heap-ului inseamna ca nu mai are fii
    {
        int fiu = indice_fiu_mic(i, n);
        if(H[i].val > H[fiu].val)
        {
            swap(vp[H[i].nr_ordine], vp[H[fiu].nr_ordine]); //actualizez in vectorul de pozitii schimbarea pe care o fac
            swap(H[i], H[fiu]);
            coboara(fiu,n);
        }
    }
}

void pop(int numar_ordine)
{
    int poz = vp[numar_ordine];
    swap(vp[H[poz].nr_ordine], vp[H[N].nr_ordine]); //actualizez in vectorul de pozitii schimbarea pe care o fac
    swap(H[poz], H[N]);
    N--;
    coboara(poz, N);
}

void push(nod x)
{
    N++;
    H[N] = x;
    vp[x.nr_ordine] = N;
    urca(N);
}


int main()
{
    nod nc;//nod curent
    int n, tip_op, x;
    fin >> n;
    for(int i=1; i<=n; ++i)
    {
        fin >> tip_op;
        if(tip_op == 1)
        {
            fin >> x;
            nc.val = x;
            nc.nr_ordine = i;
            push(nc);
        }
        else if(tip_op == 2)
        {
            fin >> x;
            pop(x);
        }
        else
        {
            fout << H[1].val << "\n";
        }
    }

    return 0;
}