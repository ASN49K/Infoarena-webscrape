#include <iostream>
#include <fstream>

std :: ifstream fin ("heapuri.in");
std :: ofstream fout ("heapuri.out");

int heap[200004], unde[200004], cand[200004];
// unde = pozitia in heap
// cand = ordinea de intrare

int ind, cr;

void up(int x) {
    while (x/2 != 0 and heap[x] < heap [x / 2]) {
        std :: swap (heap[x], heap[x / 2]);
            /// schimbare in heap
        std :: swap (unde[cand[x]], unde[cand[x/2]]);
            /// schimbare in pozitia din heap
        std :: swap (cand[x], cand[x / 2]);
            /// schimbare in vectorul de ordine
        x /= 2;
    }
}

void down(int x) {
    while (true) {
        int minim = heap[x];
        if (minim > heap[2 * x] and 2 * x <= ind){
            minim = heap[2 * x];
            std :: swap(heap[x], heap[2 * x]);
            std :: swap (unde[cand[x]], unde[cand[2 * x]]);
            std :: swap (cand[x], cand[2 * x]);
            x = x * 2;
        } else if (minim > heap[2 * x + 1] and 2 * x + 1 <= ind) {
            minim = heap[2 * x + 1];
            std :: swap (heap[x], heap[2 * x + 1]);
            std :: swap (unde[cand[x]], unde[cand[2 * x + 1]]);
            std :: swap (cand[x], cand[2 * x + 1]);
            x = x * 2 + 1;
        } else break;
    }
}

void insert(int x) {
    heap[++ind] = x;
    cand[ind] = ++cr;
    unde[cr] = ind;
    up(ind);
}

void del(int x) {
    x = unde[x];

    std :: swap(heap[x], heap[ind]);
        /// schimbare cu ultimul element
    std :: swap (unde[cand[x]], unde[cand[ind]]);
        /// schimbare pozitie in heap cu ultimul
    std :: swap (cand[x], cand[ind]);
        /// schimbare in vectorul de ordine cu utimul intrat
    ind--; // stergerea

    down(x);
    up(x);
}


int main() {
    int n;
    fin >> n;
    for (int i = 0; i < n; ++i) {
        int x, y;
        fin >> x;
        if (x == 1) {
            fin >> y;
            insert(y);
//            for (int j = 1; j <= ind; ++j) {
//                fout << heap[j] << " ";
//            }
//            fout << '\n';
        } else if (x == 2) {
            fin >> y;
            del (y);
//            for (int j = 1; j <= ind; ++j) {
//                fout << heap[j] << " ";
//            }
//            fout << '\n';
//            fout << cand[y] << '\n';
        } else {
            fout << heap[1] << '\n';
        }
    }
    return 0;
}
