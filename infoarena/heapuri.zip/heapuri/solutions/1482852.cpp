#include<fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int heap[200005],pozh[200005],inh[200005],t,op,x,p,c,n,k,poz;
int main(){
    for(fin>>t;t!=0;t--){
        fin>>op;
        if(op==3){
            fout<<heap[inh[1]]<<"\n";
            continue;
        }
        if(op==1){
            fin>>x;
            //n nr elem din heap
            //k nr de pozitii
            heap[++n]=x;
            k++;
            inh[n]=k;
            pozh[k]=n;
            c=k;
            p=c/2;
            while(p>0){
                if(heap[inh[c]]<heap[inh[p]]){
                    swap(inh[c],inh[p]);
                    swap(pozh[inh[c]],pozh[inh[p]]);
                    c=p;
                    p/=2;
                }else{
                    break;
                }
            }
        }else{
            fin>>x;
            //il sterg pe inh[pozh[x]]
            poz=pozh[x];
            p=poz;
            c=poz*2;
            while(c<=k){
                swap(inh[c],inh[p]);
                swap(pozh[inh[c]],pozh[inh[p]]);
                p=c;
                c*=2;
            }
            k--;
            pozh[x]=0;
            inh[k+1]=0;
        }
    }
    return 0;
}
