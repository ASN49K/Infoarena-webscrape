#include <bits/stdc++.h>
#define z(x) (x & (-x))
typedef long long ll;
using namespace std;

int n, m, x, a[1001000], cnt;

multiset < int > S;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    ifstream cin("heapuri.in");
    ofstream cout("heapuri.out");
    cin >> n;
    while (n--)
    {
        cin >> x;
        if (x == 1) cin >> m, a[++cnt] = m, S.insert(m);
        else if (x == 2) cin >> m, S.erase(S.find(a[m]));
        else cout << *S.begin() << "\n";
    }
	cerr << "Fucking time elapsed: " << clock() * 1000.0 / CLOCKS_PER_SEC << " ms" << '\n';
    return 0;
}
