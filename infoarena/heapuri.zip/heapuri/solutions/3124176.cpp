#include <iostream>
#include <set>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");


vector <int> v;
vector <int> minv;
set <int> s;
int n,x,y,k;
int main() {
    fin>>n;
    for(int i=0; i<n; i++)
    {
        fin>>x;
        if(x!=3)
        {
            fin>>y;
            if(x==1 && find(v.begin(),v.end(),y)==v.end())
            {
                s.insert(y);
                v.push_back(y);
            }
            else
            {
                s.erase(v[y-1]);
            }
        }
        else
        {
            minv.push_back(*(s.begin()));
        }
    }
    for(auto i:minv)
    {
        fout<<i<<endl;
    }
    return 0;
}
