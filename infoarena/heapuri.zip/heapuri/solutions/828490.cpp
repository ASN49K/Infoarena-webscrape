#include <iostream>
#include<fstream>
using namespace std;
class heap{
public:
    int x[200002];
    int n;

    void insert(int a)
    {
        n++;
        x[n]=a;
        int i=n,aux;
        while(x[i]<x[i/2]&&i/2>=1)
        {
            aux=x[i];
            x[i]=x[i/2];
            x[i/2]=aux;
            i=i/2;
        }
    }
    void remove(int i)
    {
        x[i]=x[n];
        n--;
        int aux,k;
        while(1)
        {
            k=i;
            if(x[i]>x[i*2]&&i*2<=n)
                k=i*2;
            if(x[k]>x[i*2+1]&&i*2+1<=n)
                k++;
            aux=x[i],x[i]=x[k];x[k]=aux;
            if(i==k)
                break;
            i=k;
        }
    }
};
int z[200002];
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    heap h;
    int i,a,n,b,j,k=0;
    scanf("%d",&n);
    h.n=0;
    for(i=1;i<=n;i++)
    {
        scanf("%d",&a);
        if(a==1)
        {
            scanf("%d",&z[++k]);
            h.insert(z[k]);
        }
        else
            if(a==2)
            {
                scanf("%d",&b);
                j=1;
                while(h.x[j]!=z[b])
                    j++;
                h.remove(j);
            }
            else
                printf("%d\n",h.x[1]);

    }

    return 0;
}

