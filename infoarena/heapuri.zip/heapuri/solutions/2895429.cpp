#include <iostream>
#include <fstream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    int N, o, x, v[200001], index = 0;
    multiset<int> h;
    f>>N;
    for (int i = 0; i < N; i++) {
        f>>o;
        if (o == 1) {
            f>>x;
            h.insert(x);
            v[++index] = x;
        } else if (o == 3) {
            g<<*h.begin()<<endl;
        } else {
            f>>x;
            h.erase(v[x]);
        }
    }
    return 0;
}
