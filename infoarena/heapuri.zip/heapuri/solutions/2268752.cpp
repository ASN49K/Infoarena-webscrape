#include <iostream>
#include <fstream>
#include <queue>
#include <functional>
#include <vector>
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

priority_queue < pair<int, int>, vector<pair<int, int>> , greater<pair<int, int>>> pq;

bool v[200001] = {0};

int n, x, p, timp = 0;

void afisare()
{
    while(!pq.empty() && v[pq.top().second] != 0)
        pq.pop();

    g<<pq.top().first;
}
int main()
{
    f>>n;
    for(int i = 0; i < n; i++)
    {
        f>>x;
        if(x == 1)
        {
            timp++;
            f>>p;
            pq.push({p, timp});
        }
        if(x == 2)
        {
            f>>p;
            v[p] = 1;
        }
        if(x == 3)
            afisare();
    }
    return 0;
}
