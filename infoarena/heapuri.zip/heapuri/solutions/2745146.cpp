#include <iostream>
#include <set>
#include <fstream>
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
set<int> heap;
int n,op,x,cont=1,i;
int main()
{
fin>>n;
int poz[n];
for(i = 0; i < n; i++){
    fin>>op;
     switch (op){
case 1:
    fin>>x;
        poz[cont++] = x;
        heap.insert(x);
        break;

case 2:
    fin>>x;
     heap.erase(poz[x]);
     break;

case 3:

     fout<<*heap.begin()<<"\n";
     break;
    }
}
    fin.close();
    fout.close();

    return 0;
}


