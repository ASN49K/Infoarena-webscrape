#include <iostream>
#include <set>
#include <fstream>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
set <int> h;
int n,c,x,nr;
 
int main()
{
    in>>n;
    int v[n];
 
    for(int i=0;i<n;i++) {
 
        in>>c;
 
        if(c==1){
            in>>x;
            nr++;
            v[nr]=x;
            h.insert(x);
        }
        else if(c==2){
            in>>x;
            h.erase(v[x]);
        }
        else if(c==3){
            out<<*h.begin()<<"\n";
        }
    }
 
    return 0;
}