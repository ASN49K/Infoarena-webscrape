/* Vlad Voicu 2012 */
/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

#include <cstdio>
#include <string>
#include <iostream>

int v[200001];
int ord[200001];
int p[200001];
int size;
int o;

void exchange(int* nr1, int* nr2) {
	int aux = *nr1;
	*nr1 = *nr2;
	*nr2 = aux;
}

void insereaza(int nr) {
	size++;
	int i, j;
	o++;
	v[size] = nr;
	ord[o] = size;
	p[ord[o]] = size;
	j = size;
	i = j / 2;
	while (i > 0 && v[j] < v[i]) {
		exchange(&v[i], &v[j]);
		exchange(&ord[i], &ord[j]);
		exchange(&p[ord[i]], &p[ord[j]]);
		j = i;
		i = i / 2;
	}
}

void sterge(int nr) {
	int i = p[nr];
	v[i] = v[size];
	exchange(&ord[i], &ord[size]);
	exchange(&p[ord[i]], &p[ord[size]]);
	size--;
	while (i*2 <= size && v[i] > v[i*2]) {
		exchange(&v[i], &v[i*2]);
		exchange(&ord[i], &ord[i*2]);
		exchange(&p[ord[i]], &p[ord[i*2]]);
		i = i*2;
	}
	while (i*2+1 <= size && v[i] > v[i*2+1]) {
		exchange(&v[i], &v[i*2+1]);
		exchange(&ord[i], &ord[i*2+1]);
		exchange(&p[ord[i]], &p[ord[i*2+1]]);
		i = i*2+1;
	}
}

void compute() {
	int n, operatie;
	int i, nr;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &operatie);
		if (operatie == 1) {
			scanf("%d", &nr);
			insereaza(nr);
		}
		if (operatie == 2) {
			scanf("%d", &nr);
			sterge(nr);
		}
		if (operatie == 3) {
			printf("%d\n", v[1]);
		}
	}
}

int main() {
  freopen("heapuri.in", "r", stdin);
  freopen("heapuri.out", "w", stdout);
	compute();
	return 0;
}
