#include <iostream>
#include <fstream>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");
const int N=200003;
int n,h[N],poz[N],v[N],nh=0,na,tip;

void swapp(int p, int q)
{
   swap(h[p],h[q]);
   poz[h[p]]=p;
   poz[h[q]]=q;
}

void urca(int p)
{
    while(p>1 && v[h[p]]<v[h[p/2]])
    {
         swapp(p,p/2);
         p/=2;
    }
}

void adauga(int val)
{
     h[++nh]=val;
     poz[val] = nh;
     urca(nh);
}

void coboara(int p)
{
    int fs=2*p,fd=2*p+1,bun=p;
    if(fs<=nh && v[h[fs]]<v[h[bun]])
    {
       bun=fs;
    }
    if(fd<=nh && v[h[fd]]<v[h[bun]])
    {
       bun=fd;
    }
    if(bun!=p)
    {
       swapp(p,bun);
       coboara(bun);
    }
}

void sterge(int p)
{
    if(p!=nh)
    {
       h[p]=h[nh--];
       poz[h[p]]=p;
       urca(p);
       coboara(p);
    }
    else
    {
       nh--;
    }
}

int main()
{
    na=0;
    in>>n;
    int p;
    for(int i=1;i<=n;i++)
    {
        in>>tip;
        if(tip==1)
        {
           in>>v[++na];
           adauga(na);
        }
        if(tip==2)
        {
           in>>p;
           sterge(poz[p]);
        }
        if(tip==3)
        {
           out<<v[h[1]]<<'\n';
        }
    }
    return 0;
}
