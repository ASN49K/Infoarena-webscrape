#include<cstdio>
#include<vector>
#include<queue>
#define NMAX 200005
using namespace std;
FILE *fin,*fout;
priority_queue< pair<int,int>, vector< pair<int,int> >, greater < pair<int,int> > > HEAP;
bool del[NMAX];
int n;
int main()
{
	fin=fopen("heapuri.in","r");
	fout=fopen("heapuri.out","w");
	fscanf(fin,"%d",&n);
	int x,choice,k=1;
	while(n--)
	{
		fscanf(fin,"%d",&choice);
		if(choice==1)
		{
			fscanf(fin,"%d",&x);
			HEAP.push(make_pair(x,k++));
			continue;
		}
		if(choice==2)
		{
			fscanf(fin,"%d",&x);
			del[x]=1;
			continue;
		}
		if(choice==3)
		{
			while(del[HEAP.top().second])
				HEAP.pop();
			fprintf(fout,"%d\n",HEAP.top().first);
			continue;
		}
	}
	fclose(fin);
	fclose(fout);
	return 0;
}
