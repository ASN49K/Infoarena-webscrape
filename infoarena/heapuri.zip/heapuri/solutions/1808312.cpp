#include <fstream>
#include <queue>


#define MAX 200001


struct min_heap
{

    int val;
    int index;

    bool operator<(const min_heap& other) const
    {
        return val > other.val;
    }
};


std::priority_queue<min_heap> m_min_heap;
char ok[MAX];


int main()
{

    int n, task, current_value, current_index = 0;
    std::ifstream fin("heapuri.in");
    std::ofstream fout("heapuri.out");

    fin >> n;
    for (int i = 0; i < n; ++i)
    {

        fin >> task;
        switch(task)
        {
        case 1:
            fin >> current_value;
            m_min_heap.push({current_value, ++current_index});
            break;
        case 2:
            fin >> current_value;
            ok[current_value] = 1;
            break;
        case 3:
            while (!m_min_heap.empty() && ok[m_min_heap.top().index])
                m_min_heap.pop();
            fout << m_min_heap.top().val << "\n";
            break;
        }

    }

    fin.close();
    fout.close();

}
