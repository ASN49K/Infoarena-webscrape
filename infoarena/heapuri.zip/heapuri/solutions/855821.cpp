#include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int H[100000000],n,poz[100000000],poz2[100000000],nr;
void swap(int a,int b)
{
    int r;
        r=H[a];
        H[a]=H[b];
        H[b]=r;
        poz2[H[a]]=b;
        poz2[H[b]]=a;
}
void HeapUp(int k)
{

    if (k<=1) return;
    if (H[k]>H[(k)/2])
        {   swap(k,(k)/2);
            HeapUp((k)/2);
        }
}
void HeapDown(int k,int l)
{
    int st,dr,i;
    if (2*k<=l) {
        st=H[2*k];
        if (2*k+1<=l)  dr=H[2*k+1];
                        else dr=st-1;
        if (st>dr) i=2*k; else i=2*k+1;
        if (H[k]<H[i]) {
            swap(k,i);
            HeapDown(i,l);
        }
    }
}
void HeapSort(int k)
{
    while (k>=1)
        {
            swap(1,k);
            k--;
            HeapDown(1,k);
        }
}
int main()
{
    int p,i,OP,x;
    f>>n;
    for (i=1;i<=n;i++){
        f>>OP;
        if (OP==1) {
            f>>x;
            H[++nr]=x;
            poz[nr]=x;
            poz2[x]=nr;
            if(i!=1) HeapUp(i);
        }
        else if (OP==2) {
            f>>x;
            p=poz2[poz[x]];
            H[p]=H[nr];
            nr--;
            HeapDown(1,nr);
        }
        else if (OP==3) {
            HeapSort(nr);
            g<<H[1]<<'\n';
        }

    }
    return 0;
}
