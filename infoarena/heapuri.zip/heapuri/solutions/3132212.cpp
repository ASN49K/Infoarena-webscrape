#include<iostream>
#include<fstream>
#include<set>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int main(){

    int n, k = 0 , v[200000];
    fin >> n;

    set<int> rezultat;

    for(int i = 0; i < n; i++)
    {
        int operatie, x;
        fin >> operatie;
        if(operatie == 1){
            fin >> x;
            k++;
            v[k] = x;
            rezultat.insert(v[k]);
        }
        else if(operatie == 2){
            fin >> x;
            rezultat.erase(v[x]);
        }
        else if(operatie == 3){
            fout << *rezultat.begin() << '\n';
        }
    }
    return 0;
}
