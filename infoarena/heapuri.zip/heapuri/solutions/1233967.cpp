#include <fstream>

using namespace std;

long  poz[200005], index = 0, A[200005];

class MIN_HEAP{
public:
    long  H[200005];
    int N;

    void create(){ N = 0; }

    int get_min(){ return H[1]; }

    int father(int nod){ return nod/2; }
    int left_son(int nod){ return 2*nod; }
    int right_son(int nod){ return 2*nod+1; }

    void coboara(int nod){
        if( left_son(nod) > N ) return;
        if( right_son(nod) > N ){
            if( H[nod] > H[left_son(nod)] ){
                swap( H[nod], H[left_son(nod)] );
                swap(A[left_son(nod)], A[nod]);
                swap(poz[A[left_son(nod)]], poz[A[nod]]);
            }
            return;
        }
        int next_nod = H[left_son(nod) ] < H[right_son(nod)] ? left_son(nod) : right_son(nod);
        if( H[nod] > H[next_nod] ){
            swap(H[nod], H[next_nod]);
            swap(A[next_nod], A[nod]);
            swap(poz[A[next_nod]], poz[A[nod]]);
            coboara(next_nod);
        }
    }

    void urca(int nod){
        if( nod == 1 ) return;
        if( H[father(nod)] > H[nod] ){
            swap( H[father(nod)], H[nod] );
            swap(A[father(nod)], A[nod]);
            swap(poz[A[father(nod)]], poz[A[nod]]);
            urca(father(nod));
        }
    }

    void insert(long val){
        index++;
        if( N == 0 ) { H[++N] = val; poz[1] = 1; A[1] = 1; }
        else{
            N++;
            H[N] = val;
            poz[index] = N;
            A[N] = index;
            urca(N);
        }
    }

    void del(int nod){
        if( nod == N) N--;
        else{
            swap(H[N], H[nod]);
            swap(A[N], A[nod]);
            swap(poz[A[N]], poz[A[nod]]);
            N--;
            coboara(nod);
        }
    }

};

int main()
{
    ifstream inFile("heapuri.in");
    ofstream outFile("heapuri.out");

    int n;
    inFile >> n;

    MIN_HEAP H;
    H.create();

    long  cod, x;
    while(n--){
        inFile >> cod;
        if( cod == 3 ) outFile << H.get_min() << "\n";
        else{
            inFile >> x;
            if( cod == 1 ) H.insert(x);
            else H.del(poz[x]);
        }
    }
}
