#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <stdlib.h>
#include <stack>
#include <queue>
#include <iomanip>
#include <time.h>
#define inf 1<<30
#define x first
#define y second
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int i,j,n,m,a,b,c,st,dr,in[200005],nr,ok;
pair<int,int> v[200005];
void add(int val)
{
    int i;
    nr++;
    v[nr].x = val;
    v[nr].y = j;
    in[v[nr].y] = nr;
    i = nr;
    while(i != 1)
    {
        if(v[i/2].x > v[i].x)
        {
            swap(v[i/2],v[i]);
            swap(in[ v[i/2].y], in[ v[i].y ] );
            i/=2;
        }
        else
            i = 1;
    }
}
void sterge(int nod)
{
    if(nod!=nr)
    {
        swap(v[nod],v[nr]);
        nr--;
        while(nod != 1)
        {
            if(v[nod/2].x > v[nod].x)
            {
                swap(v[nod/2],v[nod]);
                swap(in[ v[nod/2].y], in[ v[nod].y ] );
                nod/=2;
            }
            else
                nod = 1;
        }
        while(nod*2+1 <= nr)
        {
            if(v[nod*2].x < v[nod].x)
            {
                swap(v[nod*2],v[nod]);
                swap(in[ v[nod*2].y], in[ v[nod].y ] );
                nod*=2;
            }
            else
            if(v[nod*2+1].x < v[nod].x)
            {
                swap(v[nod*2+1],v[nod]);
                swap(in[ v[nod*2+1].y], in[ v[nod].y ] );
                nod= nod*2+1;

            }
            else
            {
                break;
            }
        }
        if(v[nod*2].x < v[nod].x && nod*2<= nr)
        {
            swap(v[nod*2],v[nod]);
            swap(in[ v[nod*2].y], in[ v[nod].y ] );
            nod*=2;
        }
    }
    else
        nr--;
}
int main()
{
    fin >> n;int x;
    for(i = 1; i <= n; i++)
    {
        fin >> m;
        if(m == 1)
        {
            fin >> x;
            j++;
            add(x);
        }
        if(m == 2)
        {
            ok=0;
            fin >> x;
            sterge(in[x]);

        }
        if(m == 3)
            fout<<v[1].x<<"\n";
    }
return 0;
}
