#include <iostream>
#include <fstream>

using namespace std;

int HEAP[200002],N,TimpToPos[200002],PosToTimp[200002];

int n,o,t=1;
int x;



void BubbleUp(int pos)
{
    if( HEAP[pos] < HEAP[pos/2] )
        swap(HEAP[pos],HEAP[pos/2]),
        swap(TimpToPos[PosToTimp[pos]],TimpToPos[PosToTimp[pos/2]]),
        swap(PosToTimp[pos],PosToTimp[pos/2]),
        BubbleUp(pos/2);
}

void BubbleDown(int pos)
{
    if(2*pos <=N)
        if( HEAP[2*pos] < HEAP[2*pos+1] && HEAP[2*pos] < HEAP[pos] )
        {
            swap(HEAP[pos],HEAP[2*pos]);
            swap(TimpToPos[PosToTimp[pos]],TimpToPos[PosToTimp[2*pos]]);
            swap(PosToTimp[pos],PosToTimp[2*pos]);
            BubbleDown(2*pos);
        }
    if(2*pos+1 <=N)
        if( HEAP[2*pos] > HEAP[2*pos+1] && HEAP[2*pos+1] < HEAP[pos] )
        {
            swap(HEAP[pos],HEAP[2*pos+1]);
            swap(TimpToPos[PosToTimp[pos]],TimpToPos[PosToTimp[2*pos+1]]);
            swap(PosToTimp[pos],PosToTimp[2*pos+1]);
            BubbleDown(2*pos);
        }
}

void Inserare(long long x)
{

    N++;
    HEAP[N] = x;

    TimpToPos[t] = N;
    PosToTimp[N] = t;
    t++;


    BubbleUp(N);
}


void StergeIElement(int i)
{
    swap(HEAP[i],HEAP[N]);
    swap(TimpToPos[PosToTimp[i]],TimpToPos[PosToTimp[N]]);
    swap(PosToTimp[i],PosToTimp[N]);
    HEAP[N] = 9999999999;
    N--;
    BubbleDown(i);
}

int main()
{
    HEAP[0] = -9999;
    N = 0;

    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    f>>n;


    for(int i = 0;i<n;i++)
    {
        f>>o;
        if(o == 1)
        {
            f>>x;
            Inserare(x);
        }
        if(o == 2)
        {
            f>>x;
            StergeIElement(TimpToPos[x]);
        }
        if(o == 3)
            g<<HEAP[1]<<'\n';
    }


    //Inserare(4);
    //Inserare(7);
    //Inserare(9);

   // StergeIElement(TimpToPos[1]);

    //for(int i =1 ;i<=N;i++)
     //   cout<<HEAP[i]<<' ';

    g.close();
    f.close();



    return 0;
}
