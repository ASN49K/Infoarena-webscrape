#include <cstdio>
const int Q=200500;
int v[Q],poz[Q],h[Q],nh;
 
 
void schimba(int a,int b)
{
    int aux,aux1;
    aux=h[a];
    h[a]=h[b];
    h[b]=aux;
    poz[h[a]] = a;
    poz[h[b]] = b;
}
 
void coboara(int p)
{
    int fs=2*p,fd=2*p+1,bun=p;
    if(fs<=nh && v[h[fs]]<v[h[bun]]) bun=fs;
    if(fd<=nh && v[h[fd]]<v[h[bun]]) bun=fd;
    if(bun!=p)
    {
        schimba(bun,p);
        coboara(bun);
    }
}
 
void urca(int p)
{
    while(v[h[p]]<v[h[p/2]] && p>1)
    {
        schimba(p,p/2);
        p/=2;
    }
}
 
void adauga(int x, int nr)
{
    h[++nh] = nr;
    poz[nr] = nh;
    urca(nh);
}
 
void sterge(int p)
{
    schimba(nh--,p);
    urca(p);
    coboara(p);
}
 
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
 
    int n,t,x,nr=0;
    scanf("%d",&n);
 
    for(int i=1; i<=n; i++)
    {
        scanf("%d",&t);
        if(t==1)
        {
            scanf("%d",&v[++nr]);
            adauga(v[nr],nr);
        }
        if(t==2)
        {
            scanf("%d",&x);
            sterge(poz[x]);
        }
        if(t==3)
            printf("%d\n",v[h[1]]);
 
 
 
 
    }
 
    return 0;
}