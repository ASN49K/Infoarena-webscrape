#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
typedef pair<int,int> ii;

vector<int> v(1);
vector<bool> in_heap(1);

struct cmp
{
	bool operator() (const int a, const int b) const {
		return v[a] > v[b];
	}
};

int main()
{
	ifstream fin("heapuri.in");
	ofstream fout("heapuri.out");
	int n;
	fin >> n;
	priority_queue<int, vector<int>, cmp > a;

	for (int nth = 0, i = 1; i <= n; ++i) {
		int op, x;
		fin >> op;
		switch (op) {
			case 1: fin >> x;
					v.push_back(x);
					a.push(++nth);
					in_heap.push_back(true);
					break;
			case 2: fin >> x;
					in_heap[x] = false;
					break;
			case 3: while (!in_heap[a.top()]) a.pop();
					fout << v[a.top()] << '\n';
					break;
		}
	}

	return 0;
}
