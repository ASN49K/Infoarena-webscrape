#include <bits/stdc++.h>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
const int N=2e5+1;
int nh,h[N],poz[N],v[N];
void swapp(int p,int q)
{
    swap(h[p],h[q]);
    poz[h[p]]=p;
    poz[h[q]]=q;
}

void add(int p)
{
    while(v[h[p]] < v[h[p/2]]){
    swapp(p,p/2);
        p=p/2;}
}

void deletee(int p)
{
    int l=2*p;
    int r=2*p+1;
    int cnt=p;
    if(l<=nh && v[h[l]]<v[h[cnt]])
        cnt=l;
    if(r<=nh && v[h[r]]<v[h[cnt]])
        cnt=r;
    if(cnt!=p){
    swapp(p,cnt);
        deletee(cnt);}
}

void adauga(int x)
{
    h[++nh]=x;
    add(nh);
}

void sterge(int p)
{
    if(p==nh)
        nh--;
    else{
        swapp(p,nh--);
        add(p);
        deletee(p);}
}

int main()
{
    int n,val=0;
    f>>n;
    for(int i=0; i<n; i++)
    {   int tip;
        f>>tip;
        if(tip==1){
            f>>v[++val];
            poz[val]=val;
            adauga(val);}
        if(tip==2){
            int x;
            f>>x;
            sterge(poz[x]);}
        if(tip==3)
            g<<v[h[1]]<<endl;}
    return 0;
}


