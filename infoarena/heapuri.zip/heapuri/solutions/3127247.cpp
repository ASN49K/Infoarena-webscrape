#include <iostream>
#include <fstream>
#include <stack>
#include <deque>
#include <vector>
#include <unordered_map>
#include <utility>
using namespace std;

int poz[2000001];

class Heap{
    vector<pair<int, int>> values;
    int N;
public:
    Heap();
    void insert(int);
    int removeMin();
    void remove(int);
    void heapify(int);
    int getMin();
    void showHeap();
};
void Heap::showHeap(){
    cout<<"This is your heap: "<<endl;
    for(int i=0; i<this->values.size(); i++){
        cout<<this->values[i].first<<" ";
    }
    cout<<endl;
}
Heap::Heap(){
    this->values = {};
    this->N = 1;
}
void Heap::heapify(int i){
    if(this->values.size() == 2){
        if(this->values[0].first > this->values[1].first){
            pair<int, int> aux = this->values[1];
            this->values[1] = this->values[0];
            this->values[0] = aux;
            poz[this->values[0].second] = 0;
            poz[this->values[1].second] = 1;
        }
    } else {
        while (2 * i + 2 < this->values.size()) {
            int j;
            if (this->values[2 * i + 1].first < this->values[2 * i + 2].first) {
                j = 2 * i + 1;
            } else {
                j = 2 * i + 2;
            }
            if (this->values[i].first > this->values[j].first) {
                pair<int, int> aux = this->values[j];
                this->values[j] = this->values[i];
                this->values[i] = aux;
                poz[this->values[i].second] = i;
                poz[this->values[j].second] = j;
                i = j;
            } else {
                break;
            }
        }
    }
}
void Heap::insert(int value){
    this->values.push_back({value, this->N});
    poz[this->N] = this->values.size()-1;
    this->N++;
    int i = this->values.size()-1;
    while((i-1)/2 >= 0 && this->values[i].first < this->values[(i-1)/2].first){
        pair<int, int> aux = this->values[(i-1)/2];
        this->values[(i-1)/2] = this->values[i];
        this->values[i] = aux;
        poz[this->values[i].second] = i;
        poz[this->values[(i-1)/2].second] = (i-1)/2;
        i = (i-1)/2;
    }
}
int Heap::removeMin(){
    pair<int, int> R = this->values[0];
    this->values[0] = this->values[this->values.size()-1];
    this->values.pop_back();
    int i = 0;
    this->heapify(i);
    return R.first;
}
void Heap::remove(int ord){
    int i = poz[ord];
//    for(int k=0; k<this->values.size(); k++){
//        if(this->values[k].second == ord){
//            i = k;
//        }
//    }

    pair<int, int> aux = this->values[this->values.size()-1];
    this->values[this->values.size()-1] = this->values[i];
    this->values[i] = aux;
    poz[this->values[i].second] = i;
    poz[this->values[this->values.size()-1].second] = 0;
    this->values.pop_back();
    this->heapify(i);
}
int Heap::getMin(){
    return this->values[0].first;
}
int main(){
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    int n, a, b;
    f>>n;

    Heap h;
    while(n>0){
        f>>a;
        switch(a){
            case 1: {
                f>>b;
                h.insert(b);
                break;
            }
            case 2: {
                f>>b;
                h.remove(b);
                break;
            }
            case 3: {
                int min = h.getMin();
                g<<min<<endl;
                break;
            }
            default: {
                break;
            }
        }
        n--;
    }

    return 0;
}
