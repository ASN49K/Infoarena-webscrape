#include<fstream>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
const int Nmax = 200000;
struct heap_item{
    int val,ind;
} H[Nmax];int K;
int poz[Nmax],k;
void swap(int i,int j){
    poz[H[i].ind]=j;
    poz[H[j].ind]=i;
    heap_item aux=H[i];
    H[i]=H[j];
    H[j]=aux;
}
void upheap(int i){
    if(i/2>=1 && H[i/2].val>H[i].val){
        swap(i,i/2);
        upheap(i/2);
    }
}
void downheap(int i){
    if(2*i+1<=K && H[i].val>H[2*i+1].val && H[2*i+1].val<=H[2*i].val){
        swap(i,2*i+1);
        downheap(2*i+1);
    }
    else if(2*i<=K && H[i].val>H[2*i].val){
        swap(i,2*i);
        downheap(2*i);
    }
}
void Push(int x){
    poz[++k]=++K;
    H[K].val=x;
    H[K].ind=k;
    upheap(K);
}
void Delete(int i){
    swap(i,K--);
    downheap(i);
}
int main(){
    int M;
    in>>M;
    for(;M;--M){
        int op,x;
        in>>op;
        if(op==1){
            in>>x;
            Push(x);
        }
        if(op==2){
            in>>x;
            Delete(poz[x]);
        }
        if(op==3){
            out<<H[1].val<<'\n';
        }
    }
    return 0;
}
