#include <iostream>
#include <fstream>


using namespace std;

#define nmax 200000
int v[4*nmax], ord[4*nmax], loc[2*nmax];
int m;

void swapp( int x, int y ) {
    int aux;

    aux = v[x];
    v[x] = v[y];
    v[y] = aux;

    aux = ord[x];
    ord[x] = ord[y];
    ord[y] = aux;

    loc[ord[x]] = x;
    loc[ord[y]] = y;

}

void update_sus( int poz ) {
    while( poz > 1 ) {
        if( v[poz/2] > v[poz] ) {
            swapp( poz/2, poz );
        }
        poz = poz / 2;
    }
}


void update_jos( ) {
    int poz = 1;
    while( poz*2 <= m ) {
        // am doi copii
        if( poz * 2 == m ) {
            if( v[poz*2] < v[poz] ) {
                swapp( poz*2, poz );
            }
        } else {
            if( v[poz*2] < v[poz*2+1] ) {
                if( v[poz*2] < v[poz] )
                    swapp( poz*2, poz );

            } else {
                if( v[poz*2+1] < v[poz] )
                    swapp( poz*2+1, poz );

            }

        }
        poz *= 2;
    }
}

int main() {
    int n, i, x, t, j, nr_inserate = 0;
    ifstream cin("heapuri.in");
    ofstream cout("heapuri.out");
    cin >> n;
    m = 0;
    for( i = 1; i <= n; i++ ) {
        cin >> t;
        if( t == 1 ) {
            cin >> x;
            m++;
            nr_inserate++;
            v[m] = x;
            ord[m] = nr_inserate;
            loc[nr_inserate] = m;
            update_sus( m );
        } else if( t == 2 ) {
            cin >> x;
            //cout << "loc" << loc[x] << "\n";
            swapp( loc[x], m );
            m--;

            update_jos();

        } else {
            cout << v[1] << "\n";
        }
        //cout << "\n" << "testul " << i << "\n";
        //for( j = 1; j <= m; j++ )
            //cout << v[j] << " " << ord[j] << " __ ";
        //cout << "\n";
    }


    return 0;
}
