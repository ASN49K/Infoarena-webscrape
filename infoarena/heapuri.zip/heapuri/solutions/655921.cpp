#include<iostream>
#include<fstream>
using namespace std;
int v[200001],poz[200001],heap[200001],i,j,n;//i contor pt v[],j=contor pt heap[]
void percolate(int indice){
	while((indice>1)&&v[heap[indice]]<v[heap[indice/2]]){
		swap(heap[indice],heap[indice/2]);
		poz[heap[indice]]=indice;
		poz[heap[indice/2]]=indice/2;
		indice=indice/2;
	}
}
void insert(int key){
	
	v[++i]=key;
	heap[++j]=i;
	poz[i]=j;
	percolate(j);
}
int minim(){
	return v[heap[1]];
}
void sift(int indice){
	int son,ok;
	do{
		son=ok=0;
		if(indice*2<=j){
			if(v[heap[indice*2]]<v[heap[indice]]){
				ok=1;
				son=indice*2;
			}
			if(indice*2+1<=j&&v[heap[indice*2+1]]<v[heap[indice*2]]&&v[heap[indice*2+1]]<v[heap[indice]]){
				ok=1;
				son=indice*2+1;
			}
			if(ok){
				swap(heap[son],heap[indice]);
				poz[heap[son]]=son;
				poz[heap[indice]]=indice;
				indice=son;
			}
		}
	}
	while(ok);
}
void cut(int x){
	int indice=poz[x];
	swap(heap[j],heap[indice]);
	poz[x]=-1;
	poz[heap[indice]]=indice;
	j--;
	if(indice>1&&v[heap[indice]]<v[heap[indice/2]])
		percolate(indice);
	else
		sift(indice);
}
	
	
int main(){
	ifstream f("heapuri.in");
	ofstream g("heapuri.out");
	f>>n;
	int x,y;
	for(int i=1;i<=n;i++){
		f>>x;
		if(x==1){
			f>>y;
			insert(y);
		}
		else
			if(x==3)
				g<<minim()<<endl;
		else{
			f>>y;
			cut(y);
		}
	}
	return 0;
}
	
	
