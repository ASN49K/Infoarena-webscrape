
#include <fstream>
#include <cstring>
#include <set>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
  int v[200001]; // la momentul i vine v[i]
  set < pair < int, int> > s;
  
 
 int main(){
   int n, timp=0,cod,x;
   in>>n;
   for(int i=1;i<=n;i++)
   {
     in>>cod;
     if(cod==1)
     {
       in>>x;
       timp++;
       v[timp]=x;
       s.insert(make_pair(x,timp));
     }
     if(cod==2)
     {
       in>>x;
       s.erase({v[x],x});
     }
     if(cod==3)
     {
       out<<s.begin()->first<<'\n';
     }
   }
  
 return 0;  
}