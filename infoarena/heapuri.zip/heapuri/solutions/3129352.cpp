#include <fstream>
#include <vector>
#include <utility>
#include <iostream>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

vector <int> heap;

void insert(vector <int> &heap,int key)
{
    heap.push_back(key);
    int i = heap.size()-1;
    int parent = (i-1)/2;
    while(i > 0 && heap[parent] > heap[i])
    {
        swap(heap[parent], heap[i]);
        i = parent;
        parent = (i-1)/2;
    }
}


void heapify(vector <int> &heap, int i)
{
    int largest = i;
    int left = 2*i+1;
    int right = 2*i+2;

    if(left < heap.size() && heap[left] < heap[largest])
    {
        largest = left;
    }

    if(right < heap.size() && heap[right] < heap[largest])
    {
        largest = right;
    }

    if(largest != i)
    {
        swap(heap[i],heap[largest]);
        heapify(heap, largest);
    }

}



void buildHeap(vector <int> &heap)
{
    for(int i = (heap.size()-2)/2; i>=0; i--)
    {
        heapify(heap, i);
    }
}

void delete_element(vector <int> &heap, int key)
{
    int i = 0;
    while(i < heap.size() && heap[i] != key)
    {
        i++;
    }

    if(i < heap.size())
    {
        swap(heap[i],heap[heap.size()-1]);
        heap.pop_back();
        heapify(heap,i);
    }
}


int searchVectorPairs(vector <pair <int,int> > v, int key)
{
    int i = 0;
    while(i < v.size() && v[i].second != key)
    {
        i++;
    }

    if(i < v.size())
    {
        return v[i].first;
    }
    else return -1;
}


int main()
{

    int n;
    fin >> n;

    vector <pair <int,int> > operation_count;
    int k = 0;

    for(int i = 1; i <= n; i++)
    {

        int operation;
        fin >> operation;

        if (operation != 3){
        int key;
        fin >> key;

        if(operation == 1)
        {
            insert(heap,key);
            operation_count.push_back(make_pair(key,++k));

        }

        else if (operation == 2)
        {
            delete_element(heap,searchVectorPairs(operation_count,key));
            buildHeap(heap);
        }

        }

        else fout<<heap[0]<<'\n';

    }





    return 0;
}