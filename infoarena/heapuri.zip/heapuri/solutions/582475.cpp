#include <fstream>
#include <cstdlib>
#define N_MAX 200011

using namespace std;
int lHeap;
int v[N_MAX], H[N_MAX], P[N_MAX];
void DownHeap( int k )
{
    for( int son=k<<1; son <= lHeap; k=son, son<<=1 )
    {
        if( son < lHeap && v[H[son+1]] < v[H[son]] )
            ++son;
        if( v[H[k]] <= v[H[son]] )
            return;
        swap( H[k], H[son] );
        P[H[k]]=k;
        P[H[son]]=son;
    }
}
void UpHeap( int k )
{
    for( int key=v[H[k]], f=k>>1; k > 1 && key < v[H[f]]; k=f, f>>=1 )
    {
        swap( H[k], H[f] );
        P[H[k]]=k;
        P[H[f]]=f;
    }
}
inline void push( int k )
{
    H[++lHeap]=k;
    P[k]=lHeap;
    UpHeap( lHeap );
}
inline void pop( int k )
{
    H[P[k]]=H[lHeap];
    P[H[lHeap]]=P[k];
    --lHeap;
    DownHeap( P[k] );
}
int main( void )
{
    int N, i, j, k=0;
    ifstream in( "heapuri.in" );
    ofstream out( "heapuri.out" );
    for( in>>N; N; --N )
    {
        in>>i;
        switch(i)
        {
            case 1 : in>>j; v[++k]=j, push(k); break;
            case 2 : in>>j; pop(j); break;
            case 3 : out<<v[H[1]]<<'\n'; break;
        }
    }
    return EXIT_SUCCESS;
}
