#include <bits/stdc++.h>
using namespace std;

struct heap {
    int val, key;
} h[400002];

int n, k;
int insertPos[200005], insertVal;

void percolate(int pos) {
    while (pos / 2 > 0 && h[pos / 2].val > h[pos].val) {
        swap(h[pos / 2], h[pos]);
        insertPos[h[pos / 2].key] = pos / 2;
        insertPos[h[pos].key] = pos;
        pos = pos / 2;
    }
}

void sift(int pos) {
    while (1) {
        int child = 2 * pos;
        if (child > k) {
            break;
        }
        if (child + 1 <= k && h[child + 1].val < h[child].val) {
            ++child;
        }
        if (h[pos].val > h[child].val) {
            swap(h[pos], h[child]);
            insertPos[h[pos].key] = pos;
            insertPos[h[child].key] = child;
            pos = child;
        } else {
            break;
        }
    }
}

void inserth(int node) {
    ++insertVal;
    h[++k] = {node, insertVal};
    insertPos[insertVal] = k;
    percolate(k);
}

void deleteh(int pos) {
    pos = insertPos[pos];
    swap(h[pos], h[k]);
    insertPos[h[pos].key] = pos;
    --k;
    sift(pos);
}

int main() {
    ifstream cin("heapuri.in");
    ofstream cout("heapuri.out");
    cin >> n;
    while (n--) {
        int op, x;
        cin >> op;
        if (op == 1) {
            cin >> x;
            inserth(x);
        } else if (op == 2) {
            cin >> x;
            deleteh(x);
        } else if (op == 3) {
            cout << h[1].val << "\n";
        }
    }
}
