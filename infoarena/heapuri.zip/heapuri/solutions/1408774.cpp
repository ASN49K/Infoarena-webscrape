#include <cstdio>
using namespace std;
int heap[200001],ph[200001],v[100001],k,caz,n,x;
void change(int x1, int x2)
{
    int aux=heap[x1];
    heap[x1]=heap[x2];
    heap[x2]=aux;
    ph[heap[x1]]=x1;
    ph[heap[x2]]=x2;
}
void upheap(int nod)
{
    if(nod==1)return;
    if(v[heap[nod/2]]>v[heap[nod]])
    {
        change(nod, nod/2);
        upheap[nod/2];
    }
}
void downheap(int nod)
{
    if((v[heap[2*nod]]<v[heap[2*nod+1]])&&(v[heap[2*nod]]<v[heap[nod]]))
    {
        change(nod,2*nod);
        downheap(2*nod);
    }
    if((v[heap[2*nod+1]]<v[heap[2*nod]])&&(v[heap[2*nod+1]]<v[heap[nod]]))
    {
        change(nod,2*nod+1);
        downheap(2*nod+1);
    }
}
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    v[0]=1000*1000*1001;
    scanf("%d",&k);
    while(k--)
    {
        scanf("%d",&caz);
        if(caz==1)
        {
            scanf("%d",&x);
            n++;heap[n]=n;
            ph[n]=n;
            v[n]=x;
            upheap(n);
        }
        if(caz==2)
        {
            scanf("%d",&x);
            v[x]=v[0];
            downheap(ph[x]);
        }
        if(caz==3)
        {
            printf("%d\n",v[heap[1]]);
        }
    }
return 0;
}
