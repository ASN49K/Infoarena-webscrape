#include <bits/stdc++.h>
 
using namespace std;
 
set<int> heap;
int ord[200000];
 
int main() {
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
 
    int n, op, c = 0, nr;
 
    f >> n;
 
    for (int i = 0; i < n; i++) {
        f >> op;
 
        if (op == 3)
            g << *(heap.begin()) << "\n";
 
        else {
            f >> nr;
            if (op == 1) {
                heap.insert(nr);
                ord[++c] = nr;
            } else
                heap.erase(ord[nr]);
        }
    }
 
    f.close();
    g.close();
    return 0;
}