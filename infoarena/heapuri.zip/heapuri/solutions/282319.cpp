#include <stdio.h>

int heap[200001], poz[200001], valori[200001], heap_size = 0, k = 0;

void solve();
void push(int);
void move_up(int);
void pop(int);
void move_down(int);
inline void swap(int&, int&);

int main()
{
    solve();
    return 0;
}

void solve()
{
    int i, n, cod, val;
    FILE *fin = fopen ("heapuri.in", "r"), *fout = fopen ("heapuri.out", "w");
    fscanf (fin, "%d", &n);
    for (i = 1; i <= n; ++i)
    {
        fscanf (fin, "%d", &cod);
        if (cod == 3)
        {
            fprintf (fout, "%d\n", valori[heap[1]]);
        }
        else
        {
            fscanf (fin, "%d", &val);
            if (cod == 1)
            {
                push (val);
            }
            else if (cod == 2)
            {
                pop(val);
            }
        }
    }
    fclose (fin);
    fclose (fout);
}

void push(int val)
{
    heap[++heap_size] = ++k;
    valori[k] = val;
    poz[k] = heap_size;
    move_up(poz[k]);
}

void move_up(int fiu)
{
    int tata = fiu / 2;
    while (fiu > 1 && valori[heap[fiu]] < valori[heap[tata]])
    {
        tata = fiu / 2;
        swap(heap[fiu], heap[tata]);
        swap(poz[heap[tata]], poz[heap[fiu]]);
        move_up(tata);
        fiu = tata;
        tata = fiu / 2;
    }
}

void pop(int index)
{
    index = poz[index];
    heap[index] = heap[heap_size];
    poz[heap[index]] = index;
    --heap_size;
    move_down(index);
    //move_up(index);                               //de ce nu e necesar???
}

void move_down(int tata)
{
    int fiu = tata * 2;
    if (fiu < heap_size)
    {
        if (valori[heap[fiu+1]] < valori[heap[fiu]])
        {
            ++fiu;
        }
    }
    while (fiu <= heap_size && valori[heap[tata]] > valori[heap[fiu]])
    {
        if (fiu < heap_size)
        {
            if (valori[heap[fiu+1]] < valori[heap[fiu]])
            {
                ++fiu;
            }
        }
        else
        {
            swap(heap[tata], heap[fiu]);
            swap(poz[heap[tata]], poz[heap[fiu]]);
        }
        tata = fiu;
        fiu = tata * 2;
    }
}

inline void swap (int &a, int &b)
{
    int t = a;
    a = b;
    b = t;
}
