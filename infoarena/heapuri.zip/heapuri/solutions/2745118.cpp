#include <fstream>
#include <vector>
#include <iostream>
using namespace std;

int nrOp, op;
vector<int> myHeap;
vector<int> temp;


void inserare(int elem){
    int size = myHeap.size();
    if (size == 0){
        myHeap.push_back(elem);
        temp.push_back(elem);
    }
    else{
        myHeap.push_back(elem);
        temp.push_back(elem);
        int poz = myHeap.size() - 1; 
        while(poz){
            int tata = (poz - 1) / 2;
            if (myHeap[tata] > myHeap[poz]){
                swap(myHeap[tata], myHeap[poz]);
                poz = tata;    
            }
            else
                break;
        }
    }
}

int gaseste(int elem){
    for (int i = 0; i < myHeap.size(); i++)
        if (elem == myHeap[i])
            return i;
}

void elimina(int poz){
    int elem = temp[poz - 1];
    int poz_in_heap = gaseste(elem);
    swap(myHeap[poz_in_heap], myHeap[myHeap.size() - 1]);
    myHeap.pop_back();
    int size = myHeap.size();
    int smallest = -1;

    while (smallest != poz_in_heap){
        smallest = poz_in_heap;
        int l = (2*poz_in_heap) + 1; // left child
        int r = (2*poz_in_heap) + 2; // right child
        if (l < size && myHeap[l] < myHeap[smallest])
            smallest = l;
        if (r < size && myHeap[r] < myHeap[smallest])
            smallest = r;
        
        if (smallest != poz_in_heap){
            swap(myHeap[smallest], myHeap[poz_in_heap]);
        }
    }
}

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int main(){
    f >> nrOp;
    for (int i = 0; i < nrOp; i++){
        f >> op;
        int x;
        if (op <= 2)
            f >> x;
        switch (op){
            case 1: 
                    inserare(x);
                    break;
            case 2:
                    elimina(x);
                    break;
            case 3:
                    g << myHeap[0] << '\n';
                    break;
        }
    }

    return 0;
}