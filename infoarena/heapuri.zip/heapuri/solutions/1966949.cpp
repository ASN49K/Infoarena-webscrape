#include<fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
#define nmax 200005
int h[nmax],v[nmax],pozh[nmax],n,nr;
void heapUp(int nod)
{int t;
t=nod/2;
while(t && v[h[nod]]<v[h[t]])
{swap(h[nod],h[t]);
pozh[h[nod]]=nod;
pozh[h[t]]=t;
nod=t;
t=nod/2;
}
}
void heapDown(int nod)
{int fiu;
fiu=2*nod;
while(fiu<=n)
{if(fiu+1<=n)
if(v[h[fiu+1]]<v[h[fiu]]&&v[h[fiu+1]]<v[h[nod]])
fiu++;
if(v[h[fiu]]<v[h[nod]])
{swap(h[fiu],h[nod]);
pozh[h[fiu]]=fiu;
pozh[h[nod]]=nod;
nod=fiu;
fiu=2*nod;
}
else return;
}
}
void add(int x)
{n++;
nr++;
v[nr]=x;
h[n]=nr;
pozh[nr]=n;
heapUp(n);
}
void sterge(int x)
{int k;
k=pozh[x];
h[k]=h[n];
n--;
if(k/2&&v[h[k/2]]>v[h[k]])
heapUp(k);
else heapDown(k);
}
int main()
{int n,cod,x;
fin>>n;
while(n)
{n--;
fin>>cod;
if(cod==1)
{fin>>x;
add(x);
}
else if(cod==2)
{fin>>x;
sterge(x);
}
else if(cod==3)
fout<<v[h[1]]<<'\n';
}
return 0;
}
