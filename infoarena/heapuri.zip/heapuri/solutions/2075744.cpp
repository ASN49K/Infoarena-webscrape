#include <fstream>

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int n,x,y,lgheap,op1;
int a[200001],cur[200001],intrat[200001];
// cur[i]=pe pozitia i in se heap se afla al cur[i]-lea nod intrat in heap
// intrat[i]= nodul care a intrat al i-lea se afla acum pe pozitita intrat[i] in heap
void Insert(int val)
{ lgheap++;op1++;
    cur[lgheap]=op1;
    intrat[op1]=lgheap;
    a[lgheap]=val;
  int ct=lgheap;
  while(a[ct]<a[ct>>1])
   { swap(a[ct],a[ct>>1]);
     swap(cur[ct],cur[ct>>1]);
     swap(intrat[cur[ct]],intrat[cur[ct>>1]]);
      //vectorii depind unul de altul
       ct=ct>>1;
   }
}
void Stergere(int poz)
{ int ct=intrat[poz],pozsch;
    swap(a[lgheap],a[ct]);
    swap(cur[ct],cur[lgheap]);
    swap(intrat[cur[ct]],intrat[cur[lgheap]]);
    lgheap--;
    if(a[ct]<a[ct>>1])
      while(a[ct]<a[ct>>1])
      { swap(a[ct],a[ct>>1]);
        swap(cur[ct],cur[ct>>1]);
        swap(intrat[cur[ct]],intrat[cur[ct>>1]]);
        ct=ct>>1;
      }
    else

        if((a[ct]>a[ct<<1]&&((ct<<1)<=lgheap))||(a[ct]>a[(ct<<1)+1]&&((ct<<1)+1)<=lgheap))
      { while(a[ct]>a[ct<<1]||a[ct]>a[(ct<<1)+1])
          { if((a[ct]>a[ct<<1]&&((ct<<1)<=lgheap))&&(a[ct]>a[(ct<<1)+1]&&((ct<<1)+1)<=lgheap))
              { if(a[ct<<1]<a[(ct<<1)+1]) pozsch=ct<<1;
                else pozsch=(ct<<1)+1;
              }
            else if(a[ct]>a[ct<<1]) pozsch=ct<<1;
            else if(a[ct]>a[(ct<<1)+1]) pozsch=(ct<<1)+1;

             swap(a[pozsch],a[ct]);
             swap(cur[ct],cur[pozsch]);
             swap(intrat[cur[ct]],intrat[cur[pozsch]]);
             ct=pozsch;
           if((ct<<1)>lgheap) break;
          }
      }
}
int main()
{ fin>>n;
   int i;
   for(i=1;i<=n;i++)
   { fin>>x;
       if(x==1||x==2) fin>>y;
     if(x==1) Insert(y);
     else if(x==2) Stergere(y);
     else if(x==3) fout<<a[1]<<"\n";
   }
    return 0;
}
