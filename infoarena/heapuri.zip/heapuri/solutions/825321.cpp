#include<cstdio>
#include<set>
using namespace std;
multiset<int> heap;
int n,i,x,op,last,v[200001];

int main()
{   
last=0;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
f>>n;
for (i=1;i<=n;++i)
    {
    f>>op;
    if (op==1)
       {
       f>>x;
       last++;
       v[last]=x;
       heap.insert(x);
       }
			
    if (op==2)
           {
           f>>x;
           heap.erase(heap.find(v[x]));
		   } 
				
    if (op==3)  g<<*heap.begin()<<"\n";
    }
f.close();g.close();
return 1;
}
