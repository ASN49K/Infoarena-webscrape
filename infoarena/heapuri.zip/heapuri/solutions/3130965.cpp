#include<stdio.h>

#define nmax 200000
int heap[nmax],hin[nmax],n,in[nmax],nr;

void adauga(int);
void sterge(int);
void afiseaza();
void sift(int);
void percolate(int);
void shift(int,int);

int main()
{
    int m,a,b;
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&m);
    for(;m;m--)
    {
        scanf("%d",&a);
        if (a==1)
        {
            scanf("%d",&b);
            adauga(b);
        }
        else
        if (a==2)
        {
            scanf("%d",&b);
            sterge(b);
        }
        else
            afiseaza();
    }
    return 0;
}

void adauga(int a)
{
    heap[++n]=a;
    hin[n]=++nr;
    in[nr]=n;
    percolate(n);
}

void sterge(int a)
{
    heap[in[a]]=heap[n];
    n--;
    sift(in[a]);
}

void afiseaza()
{
    printf("%d\n",heap[1]);
}

void sift(int k)
{
    int fiu=1;
    while (fiu)
    {
        fiu=0;
        if (2*k<=n)
        {
            fiu=2*k;
            if (2*k+1<=n && heap[2*k+1]<heap[2*k])
                fiu=2*k+1;
            if (heap[fiu]>heap[k]) fiu=0;
        }
        if (fiu)
        {
            shift(k,fiu);
            k=fiu;
        }
    }
}

void percolate(int k)
{
    while (k>1 && heap[k]<heap[k/2])
    {
        shift(k,k/2);
        k=k/2;
    }
}

void shift(int x,int y)
{
    int aux=heap[x];
    heap[x]=heap[y];
    heap[y]=aux;

    aux=hin[x];
    hin[x]=hin[y];
    hin[y]=aux;

    aux=in[hin[x]];
    in[hin[x]]=in[hin[y]];
    in[hin[y]]=aux;
}