#include<iostream>
#include<set>
using namespace std;
/*
const int MAXN = 200005;
int H[MAXN];
int size = 0;
int parent(int node){
  return (node - 1) / 2;
}
int leftChildIndex(int node){
  return node * 2 + 1;
}
int rightChildIndex(int node){
  return node * 2 + 2;
}
bool hasLeftChild(int index){
  return leftChildIndex(index) < size;
}
bool hasRightChild(int index){
  return rightChildIndex(index) < size;
}
void the_swap(int indexOne, int indexTwo){
  int aux = H[indexOne];
  H[indexOne] = H[indexTwo];
  H[indexTwo] = aux;
}
int peek(){
  return H[0];
}

void heapifyUp(int size){
  int index = size - 1;
  while(index > 0 && H[parent(index)] > H[index]){
    the_swap(parent(index), index);
    index = parent(index);
  }
}
void insert(int value){
  H[size] = value;
  size++;
  heapifyUp(size);
}
void heapifyDown(){
  int index = 0;
  while(hasLeftChild(index)){
    int smallerChildIndex = leftChildIndex(index);
    if(hasRightChild(index) && rightChildIndex(index) < leftChildIndex(index))
      smallerChildIndex = rightChildIndex(index);
    if(H[index] < H[smallerChildIndex])
      break;
    else{
      the_swap(index, smallerChildIndex);
      index = smallerChildIndex;
    }
  }
}
void cut(int index){
  H[index] = H[size];
  --size;
  if((index > 1) && (H[index] > H[parent(index)]))
    heapifyUp(size);
  else
    heapifyDown();
}*/
int size;
int v[200005];
set<int> itemsInOrder;
int main(){
  ifstream in("heapuri.in");
  ofstream out("heapuri.out");
  int N;
  for(int i = 0; i < N; i++){
    int type;
    in >> type;
    if(type == 1){
      int x;
      in >> x;
      size++;
      v[size] = x;
      itemsInOrder.insert(v[size]);
    }
    if(type == 2){
      int x;
      in >> x;
      itemsInOrder.erase(v[x]);
    }
    if(type == 3){
      out << *itemsInOrder.begin() << '\n';
    }
  }
  return 0;
}
