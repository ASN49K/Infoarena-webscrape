#include <bits/stdc++.h>

using namespace std;


ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int n, op, marime_h = 0, elem_v = 0;

int h[200010], p[200010], v[200010];

void muta_sus(int x)
{
    if (x > 1 && v[h[x]] < v[h[x/2]])
    {
        swap(p[h[x]], p[h[x/2]]);
        swap(h[x],h[x/2]);
        muta_sus(x/2);
    }
}

void muta_jos(int x)
{
    int fiu = -1;
    if (x * 2 + 1 <= marime_h)
    {
        if (v[h[x*2+1]] < v[h[x*2]])
            fiu = x * 2 + 1;
        else
            fiu = x * 2;
    }
    else if (x * 2 <= marime_h)
        fiu = x * 2;

    if (fiu > 0 && v[h[fiu]] < v[h[x]])
    {
        swap(p[h[x]],p[h[fiu]]);
        swap(h[x],h[fiu]);
        muta_jos(fiu);
    }
}

void insert_h(int x)
{
    elem_v++;
    v[elem_v] = x;
    marime_h++;
    h[marime_h] = elem_v;
    p[elem_v] = marime_h;

    muta_sus(marime_h);

}


void pop_h(int x)
{
    int poz = p[x];
    p[x] = -1;
    p[h[marime_h]] = poz;
    h[poz] = h[marime_h--];
    muta_jos(poz);
    muta_sus(poz);
}
int main()
{


    int x;
    fin>>n;

    for (int i = 0; i < n; i++)
    {
        fin>>op;
        switch(op)
        {
            case 1:{
                fin>>x;
                insert_h(x);
                break;
            }
            case 2:
                {
                    fin>>x;
                    pop_h(x);
                    break;
                }
            case 3:
                {
                    fout<<v[h[1]]<<endl;
                    break;
                }
        }
    }

}
