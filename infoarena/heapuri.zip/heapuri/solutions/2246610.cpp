#include <iostream>
#include <queue>
#include <fstream>
std::ifstream in("heapuri.in");
std::ofstream out("heapuri.out");

using namespace std;

priority_queue<pair<int,int>, vector<pair<int,int> >,greater<pair<int,int> > > pq;
bool erased[1000000];/// e sters?
int odrine=0,cnt;
int n,comand,a,ordine;

int main()
{
    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>comand;
        if(comand ==1)
        {
            in>>a;
            ordine++;
            pq.push(make_pair(a,ordine));

        }
        if(comand == 2)
        {
            in>>a;
            erased[a]=1;
        }
        if(comand ==3)
        {
            while(!pq.empty() && erased[pq.top().second])
            {
                pq.pop();
            }
            if(!pq.empty())
            {
                out<<pq.top().first<<"\n";
            }
        }
    }
    return 0;
}
