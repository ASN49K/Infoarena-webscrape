#include <cstdio>
#include <algorithm>
#include <algorithm>
#define nmax 200005

using namespace std;

int v[nmax],heap[nmax],poz[nmax];
int n,l,nr;

void push(int x)
{
    while(x/2&&v[heap[x]]<v[heap[x/2]])
    {
        poz[heap[x]]=x/2;
        poz[heap[x/2]]=x;
        swap(heap[x],heap[x/2]);
        x=x/2;
    }
}

void pop(int x)
{
    int y;
    while(x!=y)
    {
        y=x;
        if((2*y)<=l&&v[heap[x]]>v[heap[2*y]])
            x=2*y;
        if((2*y+1)<=l&&v[heap[x]]>v[heap[2*y+1]])
            x=2*y+1;
        swap(heap[x],heap[y]);
        poz[heap[x]]=x;
        poz[heap[y]]=y;
    }
}

int main()
{
    int x,cod;
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&cod);
        if(cod<3)
            scanf("%d",&x);
        if(cod==1)
        {
            v[++nr]=x;
            heap[++l]=nr;
            poz[nr]=l;
            push(l);
        }
        else
        if(cod==2)
        {
            v[x]=-1;
            push(poz[x]);
            poz[x]=-1;
            heap[1]=heap[l--];
            poz[heap[1]]=1;
            pop(1);
        }
        else
            printf("%d\n",v[heap[1]]);
    }
    return 0;
}
