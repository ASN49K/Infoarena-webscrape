#include <stdio.h>
#define MAXN 200000
#define MAXVAL 1000000001

static inline int parent(int x){
  return (x-1) / 2;
}
static inline int lchild(int x){
  return x * 2 + 1;
}
static inline int rchild(int x){
  return x * 2 + 2;
}

int v[MAXN], o[MAXN], vi, oi;

void swap(int *a, int *b){
  int aux = *a;
  *a = *b;
  *b = aux;
}
int min(int a, int b){
  if(a < b)
    return a;
  return b;
}

void upHeap(int x){
  // Urcam cat timp elementul este mai mic decat parintele
  while(v[x] < v[parent(x)]){
    swap(&v[x], &v[parent(x)]);
    swap(&o[x], &o[parent(x)]);
    x = parent(x);
  }
}
void downHeap(int x){
  int minp;

  // Coboram cat timp nu am iesit din heap, si elementul este mai mare decat vreunul dintre copii sai
  while(x < vi && v[x] > min(v[lchild(x)], v[rchild(x)])){
    if(v[lchild(x)] < v[rchild(x)])
      minp = lchild(x);
    else
      minp = rchild(x);

    swap(&v[x], &v[minp]);
    swap(&o[x], &o[minp]);
    x = minp;
  }
}
void removeElement(int x){
  vi --;
  swap(&v[x], &v[vi]);
  swap(&o[x], &o[vi]);
  v[vi] = MAXVAL;

  downHeap(x);
}

int main(){
  int n, i, j, a, x;
  FILE *fin, *fout;

  fin = fopen("heapuri.in", "r");
  fout = fopen("heapuri.out", "w");

  for(i = 0; i < MAXN; i ++)
    v[i] = MAXVAL;

  fscanf(fin, "%d", &n);
  vi = 0;
  oi = 0;
  for(i = 0; i < n; i ++){
    fscanf(fin, "%d", &a);

    if(a == 1){ // Se adauga elementul x
      fscanf(fin, "%d", &x);
      v[vi] = x;
      o[vi] = oi;
      vi ++;
      oi ++;
      upHeap(vi - 1);
    
    } else if(a == 2){ // Se sterge al x-lea element adaugat
      fscanf(fin, "%d", &x);
      x --;
      j = 0;
      while(o[j] != x)
        j ++;

      removeElement(j);
      // printf("! %d ! ", j);

    } else{ // Se afiseaza minimul
      fprintf(fout, "%d\n", v[0]);
    }

    for(int ii = 0; ii < vi; ii ++){
      printf("%d  ", o[ii]);
    }
    printf("\n");
  }

  fclose(fin);
  fclose(fout);

  return 0;
}
