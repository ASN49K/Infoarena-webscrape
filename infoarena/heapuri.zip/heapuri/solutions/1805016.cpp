#include <cstdio>
#include <queue>

using namespace std;

struct heap
{
    int x,ind;
    bool operator <(const heap &aux) const
    {
        return x>aux.x;
    }
};
priority_queue<heap> h;
char vaz[200010];

int main()
{
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);
    int n,cnt=0,tip,x;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&tip);
        if(tip==1)
        {
            scanf("%d",&x);
            h.push({x,++cnt});
        }
        else if(tip==2)
        {
            scanf("%d",&x);
            vaz[x]=1;
        }
        else
        {
            while(!h.empty() && vaz[h.top().ind]) h.pop();
            printf("%d\n",h.top().x);
        }
    }
    return 0;
}
