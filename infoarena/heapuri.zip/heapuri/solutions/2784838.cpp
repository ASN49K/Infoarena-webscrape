#include <fstream>
#include <set>

using namespace std;

int n,v[200001],nr;
multiset<int> heap;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        int op;
        fin>>op;
        if(op==1)
        {
            int x;
            fin>>x;
            heap.insert(x);
            v[++nr]=x;
        }
        else if(op==2)
        {
            int x;
            fin>>x;
            heap.erase(v[x]);
        }
        else
        {
            fout<<*heap.begin()<<"\n";
        }
    }
    return 0;
}
