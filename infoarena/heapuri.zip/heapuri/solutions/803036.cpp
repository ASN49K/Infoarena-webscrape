#include<cstdio >
#include < algorithm >  
using namespace std ;
#define NMAX 200003
int  heap[NMAX] , poz[NMAX] , n ,tip ,x ,ln = 0  ,k=0 ,a[NMAX]  ;

void insert ( int lung )
{
	while ( lung/2 >=1 && a[ heap [ lung ] ] < a [ heap [ lung /2 ] ]   )
	{
				 
					
						swap( heap[ lung ] , heap[ lung/2 ]);

						poz[ heap [lung ] ] = lung;
						poz[ heap [ lung/2 ] ] = lung/2 ;
									
		lung /=  2 ;	
	}
}
void del( int x )
{
	int y=0;

	while( x != y  )
	{
		y=x;

		if ( y * 2 <= ln	 &&		a [ heap [ x ] ] > a [ heap [ y*2 ] ] ) 
			x = y*2;

		if  ( y*2+1 <= ln && a [ heap  [ x ] ] > a [ heap [ y*2+1 ] ] ) 
			x = y * 2 + 1 ;
		
		swap ( heap [ x ] , heap [ y ] );
			
		poz [ heap [ x ] ] = x;
		poz [ heap [ y ] ] = y ;
		
	}
	
}



int main ()
{
	freopen( "heapuri.in" , "r" , stdin );

	freopen("heapuri.out","w",stdout);

	scanf("%d",&n);

	for( int i=1 ; i<=n ; ++i )
	{
		scanf("%d",&tip );

		switch ( tip ) 
		{
			case 1 :


				scanf( "%d" , &x ) ;

				++ln;

				++k ; 

				heap [ ln ] = k ;  			

				poz[k] = ln;

				a[k] = x ; 

				insert ( ln ) ;

				break;


			case 2:



				scanf("%d" , &x) ;

				a [ x ] = -1; 

				insert( poz [ x ] ); 

				poz[ x ] = 0; 

				heap [ 1 ] =	heap[ ln-- ] ;

				poz [ heap[ 1 ] ] = 1;		

				if( ln >  1 ) del ( 1 );

				break;



			case 3:		


				printf("%d\n",	a [ heap [ 1 ] ]	);

		}
	}

	
	
	return 0;
}