#include<fstream>

#define nmax 200100

using namespace std;

ifstream f ("heapuri.in");

ofstream g ("heapuri.out");

long long  heap[nmax],teste,Cerinta,x,n,ordine[nmax],poz[nmax],nr;

void inverseaza(int x,int y)


{

    int aux=heap[x];

    heap[x]=heap[y];

    heap[y]=aux;



    aux=ordine[x];

    ordine[x]=ordine[y];

    ordine[y]=aux;



    aux=poz[ordine[x]];

    poz[ordine[x]]=poz[ordine[y]];

    poz[ordine[y]]=aux;

}

void sift(int k)

{

    int fiu=1;

    while (fiu)

        {

            fiu=0;

            if (2*k<=n)

            {

                fiu=2*k;

                if (2*k+1<=n && heap[2*k+1]<heap[2*k])

                    fiu=2*k+1;

                if (heap[fiu]>heap[k])

                     fiu=0;

            }

            if (fiu)

                {

                    inverseaza(k,fiu);

                    k=fiu;

                }

        }

}

void percolate(int k)

{

    while (k>1&&heap[k]<heap[k/2])

        {

        inverseaza(k,k/2);

        k=k/2;

        }

}

void adauga(int k)

{

    heap[++n]=k,///in nodul n am valoarea k

    ordine[n]=++nr,/// nodul n este a nr valoare citita

    poz[nr]=n,/// la citirea a nr -a ii corespunde nodul n

    percolate(n);

}

void sterge(int k)

{

    heap[poz[k]]=heap[n];

    n--;
    percolate(poz[k]);
    sift(poz[k]);

}

int main()

{

    f>>teste;

    while(teste)

    {

        teste--;

        f>>Cerinta;

        if (Cerinta==1)

            {

            f>>x;

             adauga(x);

            }



        if (Cerinta==2)

            {

             f>>x;

            sterge(x);

            }

        if(Cerinta==3)

            g<<heap[1]<<'\n';

    }

}
