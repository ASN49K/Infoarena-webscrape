#include <fstream>
#include <set>
#define LE 200005
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
multiset <int> S;
multiset<int>::iterator it;
int V[LE],k;
int main()
{
  int n,tip,val,i;
  f>>n;

  for(i=1; i<=n; ++i)
    {
      f>>tip;
      if (tip==1)
        {
          f>>V[++k];
          S.insert(V[k]);
        }
      if (tip==2) {
       f>>val;
       val=V[val];
       if (S.find(val)!=S.end())
          S.erase(S.find(val));
      }
      if (tip==3)
        {
        it=S.begin();
        g<<*it<<'\n';
        }

    }

  f.close();
  g.close();
  return 0;
}
