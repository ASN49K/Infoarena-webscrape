#include <fstream>
#define N_Max 200010
using namespace std;
ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");
int N, nr, h, V[N_Max], Heap[N_Max], Poz[N_Max];
/// nr - numarul de elemente
/// h - inaltimea heapului
/// V[] - valorile din heap
/// Heap[] - indicii heapului
/// Poz[] - pozitia elementului i in Heap


inline int father(int nod) {
    return (nod >> 1);
}

inline int left_son(int nod) {
    return (nod << 1);
}

inline int right_son(int nod) {
    return (nod << 1 + 1);
}

inline int Val_Min_Heap() {
    return V[Heap[1]];
}

inline void Insert_Heap(int x)
{
    nr++;
    h++;
    V[nr] = x;
    Heap[h] = nr;
    Poz[nr] = h;

    int nod = h;
    while (nod > 1 && V[Heap[nod]] < V[Heap[father(nod)]])
    {
        swap (Heap[nod], Heap[father(nod)]);
        swap (Poz[Heap[nod]], Poz[Heap[father(nod)]]);
        nod = father(nod);
    }
}

inline void Pop_Heap(int x)
{
    swap (Heap[x], Heap[h]);
    swap (Poz[Heap[x]], Poz[Heap[h]]);
    h--;

    int nod = x, son = 1;
    while (son)
    {
        son = 0;
        if (left_son(nod) <= h)
        {
            son = left_son(nod);
            if (right_son(nod) <= h && V[Heap[right_son(nod)]] < V[Heap[left_son(nod)]]) {
                son = right_son(nod);
            }
            if (V[Heap[son]] >= V[Heap[nod]]) {
                son = 0;
            }
        }

        if (son)
        {
            swap (Heap[son], Heap[nod]);
            swap (Poz[Heap[son]], Poz[Heap[nod]]);
            nod = son;
        }
    }
}

int main()
{
    fin >> N;
    while (N--)
    {
        int tip, x;
        fin >> tip;
        switch (tip)
        {
            case 1 :
            {
                fin >> x;
                Insert_Heap(x);
                break;
            }
            case 2 :
            {
                fin >> x;
                Pop_Heap(Poz[x]);
                break;
            }
            case 3 :
            {
                fout << Val_Min_Heap() << '\n';
                break;
            }
        }
    }

    fin.close();
    fout.close();
    return 0;
}
