#include <cstdio>
#include <algorithm>
using namespace std;
#define Max 200001

struct info
{
    int x,v;
} h[Max];

int n,m,k,pos[Max];

void insert(int x){
    n++; k++;
    h[n].x = k;
    h[n].v = x;
    pos[k] = n;

    int f = n, t = f/2;

    while(t > 0 && h[f].v < h[t].v)
    {
        swap( h[t],h[f] );
        swap( pos[h[t].x], pos[h[f].x] );
        f = t; t = f/2;
    }
}

void erase(int x){
    int t = pos[x], f = 2 * t;
    h[t] = h[n--];
    pos[h[t].x] = t;

    if(f+1 <= n && h[f+1].v < h[f].v)f++;

    while(f <= n && h[t].v > h[f].v)
    {
        swap( h[t], h[f] );
        swap( pos[h[t].x] , pos[h[f].x] );
        t = f; f = 2 * t;
    }
}

int main(){
    int c,x;

    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);

        scanf("%d",&m);

        while(m--)
        {
            scanf("%d",&c);
            if(c == 3) printf("%d\n",h[1].v); else
            {
                scanf("%d",&x);
                if(c == 1)insert(x); else erase(x);
            }
        }


    return 0;
}
