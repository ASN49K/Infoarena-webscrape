#include<iostream.>
#include<fstream>
using namespace std;
struct heap {
	int val,poz;
};
int poz[200001],n;
heap v[200001];
void sift(int k)
{
	int s;
	heap aux;
	s=1;
	while(s) {
		s=0;
		if(((2*k)<=n)&&(v[2*k].val<v[k].val)) {
			s=2*k;
			if(((2*k+1)<=n)&&(v[2*k+1].val<v[k].val))
				s=2*k+1;
			aux=v[k];
			v[k]=v[s];
			v[s]=aux;
			poz[v[s].poz]=s;
			poz[v[k].poz]=k;
			k=s;
		}
	}
}
void percolate(int k)
{
	int s;
	heap aux;
	s=1;
	while(s) {
		s=0;
		if((k>1)&&(v[k/2].val>v[k].val)) {
			s=k/2;
			aux=v[k];
			v[k]=v[s];
			v[s]=aux;
			poz[v[s].poz]=s;
			poz[v[k].poz]=k;
			k=s;
		}
	}
}
void sterge(int k) {
	v[k]=v[n];
	poz[v[n].poz]=k;
	poz[v[k].poz]=n;
	n--;
	if(v[k].val<v[k/2].val)
		percolate(k);
	else sift(k);
}
int main ()
{
	int i,op,x,m;
	ifstream f("heapuri.in");
	ofstream g("heapuri.out");
	f>>m;
	for(i=1;i<=m;i++) {
		f>>op;
		if(op==1) {
			f>>x;
			n++;
			poz[n]=n;
			v[n].poz=n;
			v[n].val=x;
			percolate(n);
		}
		else if(op==2) {
			f>>x;
			sterge(poz[x]);
		}
		else g<<v[1].val<<'\n';
	}
	f.close();
	g.close();
	return 0;
}