#include <fstream>
#include <set>
 
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
 
multiset <int> q;
multiset <int>::iterator it;
int v[200002], n, c, x, m;
 
int main() {
    fin >> n;
    for(int i = 1; i <= n; i++) {
        fin >> c;
        if (c == 1) {
            fin >> x;
            v[++m] = x;
            q.insert(x);
        } else if(c == 2) {
            fin >> x;
            q.erase(v[x]);
        } else if(c == 3) {
            fout << (*q.begin()) << "\n";
        }
    }
    return 0;
}