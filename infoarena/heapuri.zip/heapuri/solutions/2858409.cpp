#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
const int NMAX=200005;

int N, L, ordine[NMAX];
set<int> s;

int main()
{
    fin>>N;
    int t, x;
    while(N--){
        fin>>t;
        if(t==1){
            fin>>x;
            ordine[++L]=x;
            s.insert(x);
        }
        else if(t==2){
            fin>>x;
            s.erase(ordine[x]);
        }
        else{
            fout<<*s.begin()<<'\n';
        }
    }

    fin.close();
    fout.close();
    return 0;
}
