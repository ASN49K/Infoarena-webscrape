#include <bits/stdc++.h>
using namespace std;
const int maxn=200010;
int N, L, NR;
int A[maxn], Heap[maxn], poz[maxn];

void push(int x)
{
    int aux;

    while (x/2 && A[Heap[x]]<A[Heap[x/2]])
    {
        aux = Heap[x];
        Heap[x] = Heap[x/2];
        Heap[x/2] = aux;

        poz[Heap[x]] = x;
        poz[Heap[x/2]] = x/2;
        x /= 2;
    }
}



int main()
{
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);
    int i, x, cod;
    scanf("%d ", &N);
    for (i=1; i<=N; i++)
    {
        scanf("%d ", &cod);
        if (cod < 3)
            scanf("%d ", &x);
        if (cod == 1)
        {
            Heap[L] = NR;
            poz[NR] = L;
            push(L);
        }
        if (cod == 2)
        {
            push(poz[x]);
            poz[Heap[1]] = 0;
            Heap[1] = Heap[L--];
        }

        if (cod == 3)
            printf("%d\n", A[Heap[1]]);
    }

    return 0;
}
