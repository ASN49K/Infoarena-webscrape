#include <cstdlib>
#include <fstream>

using namespace std;

const int NMAX = 200011;

int lHeap;
int H[NMAX], P[NMAX], v[NMAX];

inline void swap(int& x, int& y) {int aux = x; x = y; y = aux;}
void DownHeap(int k)
{
    for(int son = k << 1; son <= lHeap; k = son, son <<= 1)
    {
        if(son < lHeap && v[H[son]] > v[H[son + 1]])
            ++son;
        if(v[H[k]] <= v[H[son]]) return;
        swap(H[son], H[k]);
        P[H[son]] = son;
        P[H[k]] = k;
    }
}
void UpHeap(int k)
{
    for(int key = v[H[k]], f = k >> 1; k && key < v[H[f]]; k = f, f >>= 1)
    {
        swap(H[k], H[f]);
        P[H[k]] = k;
        P[H[f]] = f;
    }
}

inline void push(int x)
{
    H[++lHeap] = x;
    P[x] = lHeap;
    UpHeap(lHeap);
}

inline void pop(int idx)
{
    H[P[idx]] = H[lHeap];
    P[H[lHeap]] = P[idx];

    --lHeap;

    DownHeap(P[idx]);
}

inline int peek() {return v[H[1]];}

int main()
{
    int N, op, idx = 0, i;
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");

    for(in >> N; N; --N)
    {
        in >> op;
        if(3 == op) out << peek() << '\n';
        else if(1 == op)
        {
            in >> v[++idx];
            push(idx);
        }
        else
        {
            in >> i;
            pop(i);
        }
    }
    return EXIT_SUCCESS;
}
