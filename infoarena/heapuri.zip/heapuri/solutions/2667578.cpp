#include <bits/stdc++.h>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int v[200005],q,h;
priority_queue <int,vector <int> , greater<int> > Q;
map<int,int> M;
int main()
{
    f>>q;
    while(q--)
    {
        int cer,x;
        f>>cer;
        assert(cer==1||cer==2||cer==3);
        if(cer==1)
        {
            f>>x;
            v[++h]=x;
            M[x]=0;
            Q.push(x);
        }
        else if(cer==2)
        {
            f>>x;
            M[v[x]]++;
        }
        else
            {
                while(M[Q.top()])
                {
                    M[Q.top()]--;
                    Q.pop();
                }
                g<<Q.top()<<'\n';
            }
    }

    return 0;
}
