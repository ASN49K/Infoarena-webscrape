#include <stdio.h>
//#include <bits\stdc++.h>
using namespace std;
int n,heap[200001],ord1[200001],ord2[200001],nr;

void sus(int q)
{
    int aux;
    if(q>1)
        if(heap[q/2]>heap[q])
        {
            aux=ord2[heap[q/2]];
            ord2[heap[q/2]]=ord2[heap[q]];
            ord2[heap[q]]=aux;

            aux=heap[q/2];
            heap[q/2]=heap[q];
            heap[q]=aux;

            sus(heap[q/2]);
        }
}

void jos(int q)
{
    int aux;
    if(q*2<=nr&&heap[q]>heap[q*2])
    {
        aux=ord2[heap[q]];
        ord2[heap[q]]=ord2[heap[q*2]];
        ord2[heap[q*2]]=aux;

        aux=heap[q];
        heap[q]=heap[q*2];
        heap[q*2]=aux;

        jos(q*2);
    }
    else if(q*2+1<=nr&&heap[q]>heap[q*2+1])
    {
        aux=ord2[heap[q]];
        ord2[heap[q]]=ord2[heap[q*2+1]];
        ord2[heap[q*2+1]]=aux;

        aux=heap[q];
        heap[q]=heap[q*2+1];
        heap[q*2+1]=aux;

        jos(q*2+1);
    }
}

void inser()
{
    int elem;
    scanf("%d",&elem);
    heap[++nr]=elem;
    ord1[nr]=elem;
    ord2[elem]=nr;
    sus(nr);
}

void sterg()
{
    int ord;
    scanf("%d",&ord);
    heap[ord2[ord1[ord]]]=heap[nr--];
    ord2[heap[nr+1]]=ord2[ord1[ord]];
    jos(/*heap[*/ord2[ord1[ord]]/*]*/);
}

int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    int i,cod;
    scanf("%d",&n);
    for(i=1; i<=n; ++i)
    {
        scanf("%d",&cod);
        /*switch(cod)
        {
        case 1:
            inser(); break;
        case 2:
            sterg(); break;
        case 3:
            printf("%d\n",heap[1]); break;
        }*/
        if(cod==1) inser();
        else if(cod==2) sterg();
        else printf("%d\n",heap[1]);
    }
    return 0;
}
