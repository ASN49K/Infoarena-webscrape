#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

const string file = "heapuri";

const string infile = file + ".in";
const string outfile = file + ".out";

const int INF = 0x3f3f3f3f;
int N;
vector<int> heap;
vector<int> value;
vector<int> poz;
int size;


inline int lSon(int l)
{
	return l * 2;
}
inline int rSon(int l)
{
	return l * 2 + 1;
}

inline int Parent(int l)
{
	return l / 2;
}

void swapHeap(int a, int b)
{
	int aux = heap[a];
	heap[a] = heap[b];
	heap[b] = aux;
	poz[heap[a]] = a;
	poz[heap[b]] = b;
}

void upHeap(int l)
{
	while(l > 1 && value[heap[l]] < value[heap[Parent(l)]])
	{
		swapHeap(l, Parent(l));
		l = Parent(l);
	}
}

void downHeap(int l)
{
	while(true)
	{
		int min = l;
		if(lSon(l) <= size && value[heap[lSon(l)]] < value[heap[min]])
			min = lSon(l);

		if(rSon(l) <= size && value[heap[rSon(l)]] < value[heap[min]])
			min = rSon(l);

		if(min == l)
			break;

		swapHeap(min, l);
		l = min;

	}
}

void insertHeap(int i)
{
	heap.push_back(i);
	size++;
	poz[heap[size]] = size;
	upHeap(size);
}

int minHeap()
{
	return heap[1];
}

void popHeap()
{
	swapHeap(1, size);
	poz[heap[size]] = 0;
	value[heap[size]] = 0;
	heap.pop_back();
	size--;
	downHeap(1);
}


int main()
{
	fstream fout(outfile.c_str(), ios::out);
	fstream fin(infile.c_str(), ios::in);
	fin >> N;
	heap.reserve(200000);
	heap.push_back(0);
	value.resize(N + 1);
	poz.resize(N + 1);
	int contor = 0;

	for(int i = 0 ; i < N; i++)
	{
		int op, x;
		fin >> op;
		if(op == 1)
		{
			fin >> x;
			value[++contor] = x;
			insertHeap(contor);
		}
		else if(op == 2)
		{
			fin >> x;
			value[x] = -INF;
			upHeap(poz[x]);
			popHeap();

			if(size >= 1 && value[heap[1]] == -INF)
			{
				int y = 123123;
			}
		}
		else if(op == 3)
		{
			fout << value[minHeap()] << "\n";
		}
	}



	fin.close();
	fout.close();
}