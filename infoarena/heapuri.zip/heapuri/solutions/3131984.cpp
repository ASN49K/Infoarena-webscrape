#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    vector<int> v;
    int n, a, b, k = 0;
    f >> n;
    vector<int> v2(n);
    priority_queue<int, vector<int>, greater<int>> minHeap;

    for (int i = 0; i < n; i++)
    {
        f >> a;
        if (a == 1)
        {
            f >> b;
            v.push_back(b);
            v2[k] = b;
            minHeap.push(b);
            k++;
        }
        else if (a == 2)
        {
            f >> b;
            auto it = find(v.begin(), v.end(), v2[b - 1]);
            if (it != v.end())
            {
                v.erase(it);
                make_heap(v.begin(), v.end(), greater<int>());
                minHeap = priority_queue<int, vector<int>, greater<int>>(v.begin(), v.end());
            }
        }
        else if (a == 3)
        {
            if (!minHeap.empty())
            {
                g << minHeap.top() << endl;
            }
        }
    }

    f.close();
    g.close();
    return 0;
}