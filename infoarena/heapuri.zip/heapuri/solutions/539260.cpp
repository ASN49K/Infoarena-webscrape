# include <cstdio>
# include <set>
# include <algorithm>
# define open_files(); freopen ("heapuri.in", "rt", stdin); freopen ("heapuri.out", "wt", stdout)
	using namespace std;
	
	int n, x, tip, m, poz[200000];

	int main () 
	{	open_files ();
		set <int> rares;
		set <int> :: iterator it;
		set <int> :: iterator pos;
		
		scanf ("%d", &n);
		for (; n; --n)
		{	scanf ("%d", &tip);
			if (tip == 1) {
				scanf ("%d", &x);
				poz[++m] = x;
				rares.insert(x);
			}
			else if (tip == 2) {
					    scanf ("%d", &x);
				      rares.erase (poz[x]);
			        }
			else {
				it = rares.begin ();
				printf ("%d\n", *it);
			}
		}
		return 0;
	}
