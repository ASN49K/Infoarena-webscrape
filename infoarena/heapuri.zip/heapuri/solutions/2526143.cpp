#include<bits/stdc++.h>
using namespace std;
ifstream f("heapuri.in"); ofstream g("heapuri.out");
#define maxn 200010
int N, L, NR,x,cod;
int A[maxn], Heap[maxn], Pos[maxn];
void push(int x)
{   int aux;
	while (x/2 && A[Heap[x]]<A[Heap[x/2]])
	{   aux = Heap[x];
		Heap[x] = Heap[x/2];
		Heap[x/2] = aux;
		Pos[Heap[x]] = x;
		Pos[Heap[x/2]] = x/2;
		x /= 2;
	}
}
void pop(int x)
{   int aux, y = 0;
	while (x != y)
	{   y = x;
		if (y*2<=L && A[Heap[x]]>A[Heap[y*2]]) x = y*2;
		if (y*2+1<=L && A[Heap[x]]>A[Heap[y*2+1]]) x = y*2+1;
		aux = Heap[x];
		Heap[x] = Heap[y];
		Heap[y] = aux;
		Pos[Heap[x]] = x;
		Pos[Heap[y]] = y;
	}
}
int main()
{   f>>N;
    for(int i=1;i<=N;i++)
    {   f>>cod;
        if(cod<3) f>>x;
        if(cod==1)
        {   L++, NR++;
			A[NR] = x;
			Heap[L] = NR;
			Pos[NR] = L;
			push(L);
		}
        if (cod == 2)
		{   A[x] = -1;
			push(Pos[x]);
			Pos[Heap[1]] = 0;
			Heap[1] = Heap[L--];
			Pos[Heap[1]] = 1;
			if (L>1) pop(1);
		}
		if(cod==3) g<<A[Heap[i]]<<'\n';
    }
    g.close(); return 0;
}
