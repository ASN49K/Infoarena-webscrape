/*
ID: gabriel100
LANG: C++
TASK:
*/
#include <cstdio>
#include <algorithm>
//#include <time.h>
#include <queue>
#include <cmath>
#include <stack>
#include <fstream>
#include <bitset>
#include <set>

#define nl '\n'
#define F first
#define S second
#define all(v) v.begin(),v.end()
#define eb(x) emplace_back(x)
#define ull unsigned long long
#define ll long long
#define ProblemName "heapuri"
#define LocalName "data"
#ifdef INFOARENA
#define Filename ProblemName
#else
#define Filename LocalName
#endif
#define Input Filename".in"
#define Output Filename".out"
using namespace std;
ifstream cin(Input);
ofstream cout(Output);

template<class a, class type>
void print(a v, type t) {
    for_each(all(v), [](type x) { cout << x << ' '; });
    cout << nl;
}

#define N 200'000
multiset<int> s;
int elem[N], inserari, x, n;
int cod;

int main() {
    //    clock_t tStart = clock();
    ios_base::sync_with_stdio(false);
    cin >> n;
    int inserari = 0;
    for (int i = 0; i < n; ++i) {
        cin >> cod;
        if (cod == 1) {
            cin >> x;
            s.insert(x);
            elem[++inserari] = x;
        } else if(cod == 2){
            cin >> x;
            s.erase(s.find(elem[x]));
        } else {
            cout << *s.begin() << nl;
        }
    }
    //    printf("\nTime taken: %.2fs\n", (double) (clock() - tStart) / CLOCKS_PER_SEC);
    cout.close();
}