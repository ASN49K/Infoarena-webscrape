#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("heapuri.in") ;
ofstream fout ("heapuri.out") ;

int N , poz [200001] , nr_noduri , mare_heap [200001] ; // poz memoreaza pozitia fiecarui nod in HEAP

void swap ( int i , int j )
{
    int aux ;

    aux = mare_heap [i] ;
    mare_heap [i] = mare_heap [j] ;
    mare_heap [j] = aux ;

    aux = poz [ i ] ;
    poz [ i ] = poz [ j ] ;
    poz [ j ] = aux ;

}

void heapup ( int  fiu ) // sau se mai numeste percolate .. se aplica la INSERARE ( inserez pe ultima poz disponibila in arbore si dupa ii gasesc locul)
{
    int tata ;
    if ( fiu > 1 )
        {
            tata = fiu >> 1 ;
            if ( mare_heap [tata] > mare_heap [fiu] )
                    swap ( fiu , tata ) , heapup ( tata ) ;
        }
}

void heapdown ( int tata ) // sau se mai numeste SIFT  .. operatie ce actioneaza invers ca la percolate .. se aplica la stergere , poate fi aplicata impreuna cu PERCOLATE
{
    int fiu ;
    if ( 2 * tata + 1 <= nr_noduri )
           if ( mare_heap [ 2 * tata ] <= mare_heap [ 2 * tata + 1 ] )
                          fiu = 2 * tata ;
           else
                          fiu = 2 * tata + 1 ;
    else
          fiu = 2 * tata ;

    if ( tata <= nr_noduri/2 )
        if ( mare_heap [fiu] < mare_heap [tata] )
                     swap ( fiu , tata ) , heapdown ( fiu ) ;

}

void InsertHeap ( int nd )
{
    ++ nr_noduri ;
    poz [ nr_noduri ] = nr_noduri ;
    mare_heap [nr_noduri] = nd ;
    heapup ( nr_noduri ) ;
}

void DeleteHeap ( int ord )
{
    int i ;
    for ( i = 1 ; i <= nr_noduri ; ++ i )
            if ( poz [i] == ord )
                   break ;

    swap ( i , nr_noduri ) ;

    -- nr_noduri ;

    if ( i > 1 && mare_heap [ i / 2 ] < mare_heap [ i ] )
                heapup ( i ) ;
    else
                heapdown ( i ) ;
}

int Minim ()
{
    return mare_heap [1] ;
}
int main()
{
    fin >> N ;
    int a , b ;
    while ( N >= 1 )
    {
        fin >> a ;
        for ( int i = 1 ; i <= nr_noduri ; ++ i )
             cout << mare_heap [i] << " " ;
        cout<<endl ;
        switch ( a )
        {
            case 1 : fin >> b ; InsertHeap (b) ; break ;
            case 2 : fin >> b ; DeleteHeap (b) ; break ;
            case 3 : fout << Minim () << " " ; break ;
        }
        -- N ;
    }

    return 0;
}
