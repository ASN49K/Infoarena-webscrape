#include <fstream>
#include <algorithm>
#include <set>

using namespace std;

ifstream f ("heapuri.in");
ofstream g("heapuri.out");

set <int> H;
int n,t,i,x,k,v[200005];

int main ()
{
	f >> n;
	for (i = 1; i <= n; i++)
	{
		f >> t;
		if (t == 1)
		{
			f >> x;
			H.insert(x);
			v[++k] = x;
			continue;
		}
		if (t == 2)
		{
			f >> x;
			H.erase(v[x]);
			continue;
		}
		if (t == 3)
		{
			set<int>::iterator it = H.begin();
			g << *it << "\n";
		}
	}
	f.close();
	g.close();
	return 0;
}
