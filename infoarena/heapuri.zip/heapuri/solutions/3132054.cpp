#include <iostream>
#include <fstream>
#include <set>
#include <vector>

using namespace std;
ifstream f1("heapuri.in");
ofstream f2("heapuri.out");
set<int> v1;
vector<int> v2;

int main() {
    int N;
    int comanda;
    int nr;
    f1 >> N;
    for (int i = 1; i <= N; i++) {
        f1 >> comanda;
        if (comanda == 1) {
            f1 >> nr;
            v2.push_back(nr);
            v1.insert(nr);
        } else if (comanda == 2) {
            f1 >> nr;
            v1.erase(v2[nr - 1]);
        } else {
            f2 << *v1.begin() << "\n";

        }


    }

    f1.close();
    f2.close();


    return 0;
}
