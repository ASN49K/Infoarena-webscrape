#include <fstream>

using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

struct heap {
  int v, nro;
} h[200001];
int n, nrnod, dim, poz[200001], c, t, a, p;

int minheap () {
  return h[1].v;
}

void coboara (int nod) {
  int son;
  do {
    son = 0;
    if (nod * 2 <= n) {
      son = nod * 2;
      if (nod * 2 + 1 <= n and h[nod * 2 + 1].v < h[nod * 2].v)
        son = nod * 2 + 1;
      if (h[son].v >= h[nod].v)
        son = 0;
    }
    if (son) {
      swap(poz[h[nod].nro], poz[h[son].nro]);
      swap (h[nod], h[son]);
      nod = son;
    }
  } while (son);
}

void urc (int nod) {
  heap val = h[nod];
  while (nod > 1 and val.v < h[nod / 2].v) {
    poz[h[nod / 2].nro] = nod;
    h[nod] = h[nod / 2];
    nod = nod / 2;
  }
  h[nod] = val;
  poz[h[nod].nro] = nod;
}

void add (int val) {
  h[++n].v = val;
  dim++;
  h[n].nro = dim;
  poz[dim] = n;
  urc (n);
}

void cut (int nod) {
  poz[nod] = -1;
  poz[h[n].nro] = nod;
  h[nod] = h[n--];
  if (nod > 1 and h[nod].v < h[nod / 2].v)
    urc (nod);
  else
    coboara (nod);
}

int main()
{
  fin >> t;
  for (int tt = 1; tt <= t; tt++) {
    fin >> c;
    if (c == 1) {
      fin >> a;
      add (a);
    }
    else
      if (c == 2) {
        fin >> p;
        cut (poz[p]);
      }
    else
      fout << minheap () << '\n';
  }
  return 0;
}
