//min heap
#include <stdio.h>
#define MAXN 200005


int heap[MAXN];
int poz[MAXN],v[MAXN];//poz[i]=locul in heap pe care se afla al i-lea element introdus
int N=0;

void urca(int loc){
   int x;
   int aux;
   while((x=loc/2) && v[heap[loc]]<v[heap[x]]){
      //interschimb nodul de pe locul loc cu tatal sau
      poz[heap[x]]=loc;
      poz[heap[loc]]=x;
      aux=heap[loc];
      heap[loc]=heap[x];
      heap[x]=aux;
      loc=x;
   }
}

void coboara(int loc){
   //cobor in fiul cel mai mic dintre cei doi
    int aux, x, y = 0;
    while (loc != y){
	y = loc;
	if ((x=y*2)<=N && v[heap[loc]]>v[heap[x]]) loc = x;
        x++;
	if (x<=N && v[heap[loc]]>v[heap[x]]) loc = x;
          aux = heap[loc];
	  heap[loc] = heap[y];
	  heap[y] = aux;
          poz[heap[loc]] = loc;
	  poz[heap[y]] = y;
	}
}

int main(){
  freopen ("heapuri.in","r",stdin);
  freopen ("heapuri.out","w",stdout);
  int n,cod,x,crono=1;
  int aux;
  scanf("%d",&n);
  int i;
  for(i=0;i<n;i++){
     scanf("%d",&cod);
     if(cod==1){
        //inserez
        scanf("%d",&x);
        v[crono]=x;
        heap[++N]=crono;
        poz[crono]=N;
        crono++;       
        urca(N);
        /*printf("inserez %d\n",x);
        printf("heapul: ");
        for(int j=1;j<=N;j++)printf("(%d,%d)",heap[j].nr,heap[j].crono);
        printf("\n");*/
     }
     if(cod==2){
        //sterg al x-lea element ca ordine cronologica....
        scanf("%d",&x);
        //el se afla in heap pe locul poz[x];
        //printf("scot elementul %d %d\n",heap[poz[x]].nr,heap[poz[x]].crono);
           heap[poz[x]]=heap[N];
           N--;
           if(poz[x]>1 && v[heap[poz[x]]]<v[heap[poz[x]/2]])urca(poz[x]);
           else if(poz[x]<N && v[heap[poz[x]]]>v[heap[poz[x]/2]])coboara(poz[x]);
        /*printf("heapul: ");
        for(int j=1;j<=N;j++)printf("(%d,%d)",heap[j].nr,heap[j].crono);
        printf("\n");*/
        //poz[x]=0;//marchez ca acest nod nu mai e in heap...
     }

     if(cod==3){
        //afisez minimul
        printf("%d\n",v[heap[1]]);
     }


  }
return 0;
}


