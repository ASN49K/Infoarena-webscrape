#include<stdio.h>
using namespace std;
const int N = 200005;
int poz[N], v[N], h[N], n, nrh;
void schimba (int p1, int p2)
{
    int aux = h[p1];
    h[p1] = h[p2];
    h[p2] = aux;
    poz[h[p1]] = p1;
    poz[h[p2]] = p2;
}
void urca (int p)
{
    while (p > 1 && v[h[p]] <= v[h[p / 2]])
    {
        schimba (p, p / 2);
        p >>= 1;
    }
}
void coboara (int p)
{
    int fS = 2 * p, fD = 2 * p + 1, bun = p;
    if (fS <= nrh && v[h[bun]] >= v[h[fS]])
        bun = fS;
    if (fD <= nrh && v[h[bun]] >= v[h[fD]])
        bun = fD;
    if (bun != p)
    {
        schimba (bun, p);
        coboara (bun);
    }
}
int main ()
{
    FILE *in, *out;
    in = fopen ("heapuri.in", "r");
    out = fopen ("heapuri.out", "w");
    fscanf (in, "%d", &n);
    int i, cerinta, x, p;
    for (i = 1; i <= n; i++)
    {
        fscanf (in, "%d", &cerinta);
        if (cerinta == 1)
        {
            fscanf (in, "%d", &x);
            v[++nrh] = x;
            h[nrh] = nrh;
            poz[nrh] = nrh;
            urca (nrh);
        }
        if (cerinta == 2)
        {
            fscanf (in, "%d", &x);
            p = poz[x];
            schimba (p, nrh);
            nrh--;
            urca(p);
            coboara(p);
        }
        if (cerinta == 3)
            fprintf (out, "%d\n", v[h[1]]);

    }
    return 0;
}
