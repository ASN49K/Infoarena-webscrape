#include <stdio.h>
#include <set>
#define nmax 200001
using namespace std;

set<long int> heap;
long int nrnum,ndo[nmax];

int main()
    {freopen("heapuri.in","r",stdin);freopen("heapuri.out","w",stdout);
     long int i,n,tip,x;
     scanf("%ld",&n);
     for(i=1;i<=n;i++)
              {scanf("%ld",&tip);
               if(tip==3)     printf("%ld\n",*heap.begin());
               else           {scanf("%ld",&x);
                               if(tip==1)     {heap.insert(x);
                                               ndo[++nrnum]=x;
                                              }
                               else            heap.erase(heap.find(ndo[x]));
                              }
               }
     return 0;
     }
                                               
                                               
                                               
                                                                              
                    
                    
                     


















