                                                     
#include <fstream>
using namespace std;

long N;
long HS;
long Moment;
long HEAP[200005];
long TIME[200005];
long HEAPTOINX[200005];
long ELMTOHEAP[200005];
long DELETED[200005];

void swap(long &a,long &b)
{
 long c = a;
 a = b;
 b = c;
}

void heapinit(void)
{
 HS = 1;
 Moment = 1;
}

void heapinsert(long T)
{
 TIME[Moment] = T;

 long pos = HS;
 HEAP[pos] = T;
 HEAPTOINX[pos] = Moment;
 ELMTOHEAP[Moment] = pos;
 while ((pos > 1) && (HEAP[pos >> 1] > HEAP[pos]))
  {
   swap(HEAPTOINX[pos],HEAPTOINX[pos >> 1]);
   swap(HEAP[pos >> 1],HEAP[pos]);
   ELMTOHEAP[HEAPTOINX[pos]] = pos;
   ELMTOHEAP[HEAPTOINX[pos >> 1]] = pos >> 1;
   pos >>= 1;
  }

 Moment += 1;
 HS += 1;
}

void heapdelete(long T)
{
 HS -= 1;
 DELETED[T] = 1;

 HEAP[ELMTOHEAP[T]] = HEAP[HS];
 HEAPTOINX[ELMTOHEAP[T]] = HEAPTOINX[HS];
 ELMTOHEAP[HEAPTOINX[HS]] = ELMTOHEAP[T];

 long done = 0;
 while (done == 0)
  {
   long sml = ELMTOHEAP[T];
   long l = sml << 1;
   long r = l + 1;
   if ((l < HS) && (HEAP[l] < HEAP[sml]))
     {
      sml = l;
     }
   if ((r < HS) && (HEAP[r] < HEAP[sml]))
     {
      sml = r;
     }
   if (sml != ELMTOHEAP[T])
     {
      swap(HEAP[sml],HEAP[ELMTOHEAP[T]]);
      swap(HEAPTOINX[sml],HEAPTOINX[ELMTOHEAP[T]]);
      swap(ELMTOHEAP[HEAPTOINX[sml]],ELMTOHEAP[HEAPTOINX[ELMTOHEAP[T]]]);
      T = HEAPTOINX[sml];
     }
    else
     {
      done = 1;
     }
  }
}

long heapmin(void)
{
 return HEAP[1];
}

long verifyheap(void)
{
 for (long i = 1;i < Moment;i += 1)
  {
   if (DELETED[i] == 0)
     {
      if (HEAP[ELMTOHEAP[i]] != TIME[i])
        {
         return 0;
        }
      if (HEAPTOINX[ELMTOHEAP[i]] != i)
        {
         return 0;
        }
     }
  }
 return 1;
}

int main(void)
{
 long i,O,T;
 fstream fin("heapuri.in",ios::in);
 fstream fout("heapuri.out",ios::out);
 fin >> N;
 heapinit();
 for (i = 0;i < N;i += 1)
  {
   fin >> O;
   if (O == 1)
     {
      fin >> T;
      heapinsert(T);
     }
   if (O == 2)
     {
      fin >> T;
      heapdelete(T);
     }
   if (O == 3)
     {
      fout << heapmin() << "\n";
     }
   if (verifyheap() == 0)
     {
      printf("error\n");
     }
  }
 fin.close();
 fout.close();
 return 0;
}
