#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

const int Maxx = 2e5+5;
int N, M, l, op, x, heap[Maxx], poz[Maxx], val[Maxx];

void Swap(int x, int y) {
    swap(heap[x], heap[y]);
    poz[heap[x]] = x;
    poz[heap[y]] = y;
}

void Up(int s) {
    int f = s / 2;
    if(f && val[heap[s]] < val[heap[f]]) {
        Swap(s, f);
        Up(f);
    }
}

void Down(int f) {
    int s = 2 * f;
    if(s > l)return;
    if(s < l && val[heap[s + 1]] < val[heap[s]])s++;
    if(val[heap[s]] < val[heap[f]]) {
        Swap(s, f);
        Down(s);
    }
}

int main() {
    fin >> M;
    while(M--) {
        fin >> op;
        if(op == 1) {
            ++N, ++l;
            fin >> val[N];
            heap[l] = N;
            poz[N] = l;
            Up(l);
        }
        else if(op == 2) {
            fin >> x;
            x = poz[x];
            Swap(x, l);
            l--;
            Up(x);
            Down(x);
        }
        else fout << val[heap[1]] << "\n";
    }
}


