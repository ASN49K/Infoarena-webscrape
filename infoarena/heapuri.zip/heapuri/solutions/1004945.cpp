#include <fstream>

using namespace std;

int v[200005],poz[200005],order[200005],n;

inline void Urca(int k, int cnt)
{
    int tata,x;
    tata=k/2;x=v[k];
    while(k>1 && v[tata]>x)
    {
        v[k]=v[tata];
        poz[order[tata]]=k;
        k=tata;tata=k/2;
    }
    v[k]=x;poz[cnt]=k;order[k]=cnt;
}

inline void Coboara(int k)
{
    int x,fiu,gata,k1;
    x=v[k];fiu=2*k;gata=0;
    k1=k;
    while(k<=n/2 && !gata)
    {
        if(fiu+1<=n && v[fiu+1]<v[fiu])
            fiu++;
        if(x>v[fiu])
        {
            v[k]=v[fiu];
            poz[order[fiu]]=k;
            k=fiu;fiu=k*2;
        }
        else
            gata=1;
    }
    v[k]=x;poz[order[k1]]=k;
}

inline void Insert(int x, int cnt)
{
    v[++n]=x;
    Urca(n,cnt);
}

inline void Delete(int x)
{
    v[poz[x]]=v[n--];
    Urca(poz[x],order[poz[x]]);
    Coboara(poz[x]);
}

int main()
{
    int nrop,op,x,q,cnt;
    ifstream fin("heapuri.in");
    ofstream fout("heapuri.out");
    fin>>nrop;cnt=0;
    for(q=1;q<=nrop;q++)
    {
        fin>>op;
        if(op==1)
        {
            fin>>x;
            Insert(x,++cnt);
        }
        else
            if(op==2)
            {
                fin>>x;
                Delete(x);
            }
            else
                fout<<v[1]<<"\n";
    }
    fin.close();
    fout.close();
    return 0;
}
