// heapuri pe infoarena 30p
#include<cstdio>
#include<queue>
#include<vector>
using namespace std;
FILE *f=fopen("heapuri.in","r");
FILE *g=fopen("heapuri.out","w");
struct val
{
    int x;
    int poz;
};
struct cmp
{
    bool operator() (val a,val b)
    {
        return a.x>b.x;
    }
};
priority_queue< val,vector<val>,cmp > heap;
int n,aux[200005];
int main()
{
    int i,cer,xx,nr=0;
    fscanf(f,"%d",&n);
    for(i=1;i<=n;i++)
    {
        fscanf(f,"%d",&cer);
        if(cer==1)
        {
            fscanf(f,"%d",&xx);
            nr++;
            val auxx;
            auxx.x=xx;
            auxx.poz=nr;
            heap.push(auxx);
        }
        else
            if(cer==2)
            {
                fscanf(f,"%d",&xx);
                aux[xx]=1;
            }
            else
            {
                while(aux[heap.top().poz]==1)
                    heap.pop();
                fprintf(g,"%d\n",heap.top().x);
            }

    }

}
