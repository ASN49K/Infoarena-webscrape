#include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int N,k,l,C[200001],v[200001],nr[200001],p;
void ad_heap(int x)
{
    p++;
    k=p;
    l=l+1;
    v[l]=x;
    nr[p]=l;
    C[l]=p;
    while(k/2>0&&v[nr[k]]<v[nr[k/2]])
    {
        swap(nr[k/2],nr[k]);
        C[nr[k]]=k;
        C[nr[k/2]]=k/2;
        k=k/2;
    }
}
void up(int x)
{
     while(x/2>0&&v[nr[x]]<v[nr[x/2]])
    {   swap(nr[x/2],nr[x]);
        C[nr[x]]=x;
        C[nr[x/2]]=x/2;
        x=x/2;
    }
}
void down(int x)
{ int  y = 0;
    while (x!= y)
    {y = x;
       if (y*2<=p&&v[nr[x]]>v[nr[y*2]]) x=y*2;
       if (y*2+1<=p&&v[nr[x]]>v[nr[2*y+1]]) x =y*2+1;
        swap(nr[x],nr[y]);
        C[nr[x]] = x;
        C[nr[y]] = y;
    }
}

void delet(int poz)
{
    swap(nr[poz],nr[p]);
    p=p-1;
    int aux=poz;
    up(poz);
    if(aux==poz)
        down(poz);

}

    int main()
    {
        int x,y;
        f>>N;
        for(int i=1; i<=N; i++)
        {
            f>>x;
            if(x==1)
            {
                f>>y;
                ad_heap(y);
            }
            else if(x==2)
            {
                f>>y;
                delet(C[y]);
            }
            else g<<v[nr[1]]<<'\n';
        }
        return 0;
    }
