#include <fstream>
#define nmax 200002
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int v[nmax],poz[nmax],ord[nmax],heap_size;
void interschimba(int i,int j)
{
    int aux=v[i];
    v[i]=v[j];
    v[j]=aux;
    aux=poz[v[i]];
    poz[v[i]]=poz[v[j]];
    poz[v[j]]=aux;
}
void InsMinHeap(int x)
{
    v[++heap_size]=x;
    poz[v[heap_size]]=heap_size;
    int k=heap_size;
    while(k!=1)
    {
        int tata=k/2;
        if(v[tata]>v[k])
            interschimba(tata,k);
        k/=2;
    }
}
void MinHeapify(int k)
{
    if(k<=heap_size)
    {
        int minim=k;
        if(k*2<=heap_size && v[k*2]<v[k])
            minim=k*2;
        if(k*2+1<=heap_size && v[k*2+1]<v[minim])
            minim=k*2+1;
        if(minim!=k)
        {
            interschimba(k,minim);
            MinHeapify(minim);
        }
    }
}
void DelXthIn(int x)
{
    int poz_deleted=poz[ord[x]];
    interschimba(poz[ord[x]],heap_size);
    --heap_size;
    MinHeapify(poz_deleted);
}
int main()
{
    int n,nr=0;
    f>>n;
    for(int i=1; i<=n; ++i)
    {
        int op;
        f>>op;
        if(op==1)
        {
            int x;
            f>>x;
            ord[++nr]=x;
            InsMinHeap(x);
        }
        else if (op==2)
        {
            int x;
            f>>x;
            DelXthIn(x);
        }
        else g<<v[1]<<'\n';
    }
    return 0;
}
