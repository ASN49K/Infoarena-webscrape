#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
int n, i, optiune, vect[200001], nr, j;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
set <int> s;
int main()
{
    f>>n;
    for(i=1; i<=n; i++)
    {
        f>>optiune;
        if(optiune==1)
        {
            f>>nr;
            s.insert(nr);
            j+=1;
            vect[j]=nr;
        }
        else if(optiune==2)
                {
                    f>>nr;
                    s.erase(vect[nr]);
                }
        else  g<<*s.begin()<<endl;
    }

    f.close();
    g.close();
    return 0;
}
