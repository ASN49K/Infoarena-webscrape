#include<stdio.h>
using namespace std;

struct omg
{
	int v;
	int nr;
} heap[200005];
int n,el;
void ActualHeap(int loc)
{
	int aux;
	while( loc/2>=1 && heap[loc].nr<heap[loc/2].nr)
	{
		
		
			aux=heap[loc].nr;
			heap[loc].nr=heap[loc/2].nr;
			heap[loc/2].nr=aux;
			
			aux=heap[loc].v;
			heap[loc].v=heap[loc/2].v;
			heap[loc/2].v=aux;
			loc=loc/2;
		
	}
}

void Actual2Heap(int loc)
{
	int sw=1,min,aux;
	while(sw)
	{
		if(loc*2+1<=el && heap[loc*2+1].nr<=heap[loc].nr)
		{
			min= heap[loc*2].nr>=heap[loc*2+1].nr? loc*2+1:loc*2;
		
		if(heap[min].nr<=heap[loc].nr)
		{
			aux=heap[loc].nr;
			heap[loc].nr=heap[min].nr;
			heap[min].nr=aux;
			aux=heap[loc].v;
			heap[loc].v=heap[min].v;
			heap[min].v=aux;
			loc=min;
		}
		}
		else if(heap[loc*2].nr<=heap[loc].nr && loc*2<=el)
		{
			aux=heap[loc].nr;
			heap[loc].nr=heap[loc*2].nr;
			heap[loc*2].nr=aux;
			aux=heap[loc].v;
			heap[loc].v=heap[loc*2].v;
			heap[loc*2].v=aux;
			loc*=2;
		}
		else sw=0;
	}
}
void nou(int poz)
{
	for(int i=1;i<=el;i++)
	{
		if(heap[i].v==poz)
		{
			poz=i;
			break;
		}
	}
	heap[poz].nr=heap[el].nr;
	heap[poz].v=heap[el].v;
	el--;
	Actual2Heap(poz);
}
int main()
{
	FILE *f=fopen("heapuri.in","r");
	FILE *g=fopen("heapuri.out","w");
	fscanf(f,"%d",&n);
	int x,y;
	
	for(int i=1;i<=n;i++)
	{
		fscanf(f,"%d",&x);
		if(x==1)
		{ fscanf(f,"%d",&y);
		  heap[++el].nr=y;
		  heap[el].v=el;
		  ActualHeap(el);
		}
		if(x==3)
			fprintf(g,"%d\n",heap[1].nr);
		if(x==2)
		{
			fscanf(f,"%d",&y);
		  
			nou(y);
		}
	}
}