program heap;

 var n,i,x,y,min,j:longint;
     a:array[1..10000] of longint;
 begin
   assign(input,'heapuri.in');
   reset(input);
   assign(output,'heapuri.out');
   rewrite(output);
   readln(n);   i:=0;
   while n<>0 do
     begin
      read(x);
      if x=1 then begin readln(y); inc(i); a[i]:=y; end
       else if x=2 then begin readln(y); a[y]:=10000000; end
        else begin
          min:=1000000;
          for j:=1 to i do if min>a[j] then min:=a[j];
          writeln(min);
          end;
       dec(n);
       end;
     close(output);
   end.
