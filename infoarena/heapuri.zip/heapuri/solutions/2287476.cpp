#include <iostream>
#include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int a[200005],poz[200005],MinHeap[200005],n,q,d;
void interschimba(int x,int y)
{
    swap(MinHeap[x],MinHeap[y]);
    swap(poz[MinHeap[x]],poz[MinHeap[y]]);
}
void HeapUp(int x)
{
    while(x/2>0 && a[MinHeap[x]]<a[MinHeap[x/2]])
    {
        interschimba(x,x/2);
        x=x/2;
    }
}
void HeapDown(int x)
{
    bool sw;
    sw=1;
    while(sw==1)
    {
        sw=0;
        if(x*2<=n)
        {
            if(x*2+1<=n)
            {
                if(a[MinHeap[x*2]]<a[MinHeap[x*2+1]])
                {
                    if(a[MinHeap[x]]>a[MinHeap[x*2]])
                    {
                        interschimba(x,x*2);
                        x=x*2;
                        sw=1;
                    }
                }
                else
                {
                    if(a[MinHeap[x]]>a[MinHeap[x*2+1]])
                    {
                        interschimba(x,x*2+1);
                        sw=1;
                        x=x*2+1;
                    }
                }
            }
            else
            {
                 if(a[MinHeap[x]]>a[MinHeap[x*2]])
                {
                    interschimba(x,x*2);
                    x=x*2;
                    sw=1;
                }
            }
        }
    }
}
int main()
{
    int op,val,i,x;
    f>>q;
    while(q--)
    {
        f>>op;
        if(op==1)
        {
            f>>val;
            n++;
            d++;
            a[d]=val;
            MinHeap[n]=d;
            poz[d]=n;
            HeapUp(n);
        }
        if(op==2)
        {
            f>>val;
            a[val]=-1;
            HeapUp(poz[val]);
            MinHeap[1]=MinHeap[n];
            n--;
            poz[MinHeap[1]]=1;
            HeapDown(1);
        }
        if(op==3)
        {
            g<<a[MinHeap[1]]<<"\n";
        }
    }
    return 0;
}
