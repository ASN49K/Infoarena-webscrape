#include <stdio.h>
#include <stdlib.h>

struct nod
{
    int val;
    struct nod *urm;
};

int a[200000], n, m, n_ord;
int ord[200000];
struct nod *deleted[10], *p;

void siftUp(int index)
{
    int tata = (index-1)/2, aux;

    if(a[index] < a[tata])
    {
        aux = a[index];
        a[index] = a[tata];
        a[tata] = aux;

        siftUp(tata);
    }
}

void siftDown(int index)
{
    int fiu1 = 2*index + 1;
    int fiu2 = 2*index + 2, aux;

    if(fiu1 >= n)
        return;
    else if(fiu2 >= n && (a[index] > a[fiu1]))
    {
        aux = a[index];
        a[index] = a[fiu1];
        a[fiu1] = aux;
    }
    else if((a[index] > a[fiu1]) && (a[fiu1] < a[fiu2]))
    {
        aux = a[index];
        a[index] = a[fiu1];
        a[fiu1] = aux;

        siftDown(fiu1);
    }
    else if((a[index] > a[fiu2]) && (a[fiu2] <= a[fiu1]))
    {
        aux = a[index];
        a[index] = a[fiu2];
        a[fiu2] = aux;

        siftDown(fiu2);
    }

}

void push(int x)
{
    n++;
    a[n-1] = x;

    siftUp(n-1);
}

int pop()
{
    int i, au = a[0];
    a[0] = a[--n];
    siftDown(0);

    return au;
}


int eSters(int x)
{
    p = deleted[x%10];

    while(p != NULL)
    {
        if(p->val == x)
            return 1;
        p = p->urm;
    }

    return 0;
}


int main()
{
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);


    int i, j, x, instr, n_ex;
    scanf("%d\n", &n_ex);


    for(i = 0; i < n_ex; i++)
    {
        scanf("%d", &instr);
        if(instr == 1)
        {
            scanf("%d", &x);
            push(x);
            ord[++n_ord] = x;
        }
        else if(instr == 2)
        {
            scanf("%d", &x);

            if(deleted[ord[x]%10] == NULL)
            {
                deleted[ord[x]%10] = (struct nod*)malloc(sizeof(struct nod));
                deleted[ord[x]%10]->val = ord[x];
                deleted[ord[x]%10]->urm = NULL;
            }
            else
            {
                p = (struct nod*)malloc(sizeof(struct nod));
                p->val = ord[x];
                p->urm = NULL;
                a[ord[x]] = p;
            }

        }
        else if(instr == 3)
        {
        //printf("Pentru ca a[0] = %d si a fost sters, heapul e \n", a[0]);
            while(eSters(a[0]))
            {
                printf("Pentru ca a[0] = %d si a fost sters, heapul e \n", a[0]);
                pop();
                //for(j = 0; j < n; j++)
                   // printf("%d ", a[j]);
            }
            printf("%d\n", pop());



        }
    }





    return 0;
}
