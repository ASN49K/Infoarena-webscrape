#include<stdio.h>

#include<iostream>
#include<fstream>

#include<set>
#include<map>
#include <algorithm>

using namespace std;

#define MAXN 200000

map<int,int> ordine;
set<pair<int,int>> values;

int main(){
	int N;

	//ifstream input("cautbin.in");
	//ofstream output("cautbin.out",std::ios::out);

	freopen("heapuri.in", "r", stdin);
    //freopen("grader_test2.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);

	scanf("%d", &N);
	//input >> N;

	int tip,x;
	int index=0,ind;
	map<int,int>::iterator itr; 

	for(int i=0;i<N;i++){
		 scanf("%d", &tip);

		switch(tip){
			case 1:
				// insert element
				scanf("%d", &x);
				index++;
				values.insert(make_pair(x,index));
				ordine.insert(pair<int,int>(index, x));
				break;
			case 2:
				// delete x-th element
				scanf("%d", &ind);
				itr=ordine.find(ind);
				x=itr->second;
				values.erase(values.find(make_pair(x,ind)));
				ordine.erase(itr);
				break;
			case 3:
				// display minimum
				x=values.begin()->first;
				printf("%d\n",x);
				break;
		}
	}

	//input.close();
	//output.close();
	return 0;
}