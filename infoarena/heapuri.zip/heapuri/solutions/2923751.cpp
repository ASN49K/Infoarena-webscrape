#include <bits/stdc++.h>

using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

vector<int>v;
multiset<int>s;

int main(){
  int q; fin >> q;
  while (q--){
    int o; fin >> o;
    if (o == 3){
      fout << *(s.begin()) << '\n';
    }
    else{
      int x; fin >> x;
      if (o == 1){
        s.insert(x);
        v.emplace_back(x);
      }
      else{
        s.erase(s.find(v[x - 1]));
      }
    }
  }
}
