#include <iostream>
#include <set>
#include <vector>
using namespace std;

#define NMAX 200001

int main()
{
	multiset<int> my_set;
	int aux_set[NMAX];
	int poz = 1;

	int N, op, x;

	freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);

	cin >> N;

	for(int i = 0; i < N; ++i)
	{
		cin >> op;
		if(op != 3)
		{
			cin >> x;
			if(op == 1)
			{
				my_set.insert(x);
				aux_set[poz] = x;
				poz++;
			}
			else
				my_set.erase(aux_set[x]);
		}
		else
		{
			cout << *(my_set.begin()) << endl;
		}
	}

	return 0;
}














