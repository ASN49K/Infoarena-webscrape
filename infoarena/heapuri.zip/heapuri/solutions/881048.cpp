#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;

#define NMAX 200005

int A[NMAX], Heap[NMAX], Pos[NMAX], t = 0, n = 0;

int getLeft(int p){ return 2 * p + 1;}
int getRight(int p){ return 2 * p + 2;}
int getParent(int p){return (p-1)/2;}

int getMin()
{
	return A[Heap[0]];
}

void up(int p)
{
	while(p > 0 && A[Heap[p]] < A[Heap[getParent(p)]]){
		swap(Heap[p], Heap[getParent(p)]);
		Pos[Heap[p]] = p;
		Pos[Heap[getParent(p)]] = getParent(p);
		p = getParent(p);
	}
}

void down(int p)
{
	int son;
	do{
		son = -1;
		if(getLeft(p) < n)
		{
			son = getLeft(p);
			if(getRight(p) < n && A[Heap[son]] > A[Heap[getRight(p)]])
				son = getRight(p);
		}
		
		if(son != -1)
		{
			if(A[Heap[son]] < A[Heap[p]])
			{
				swap(Heap[son], Heap[p]);
				Pos[Heap[son]] = son;
				Pos[Heap[p]] = p;
				p = son;
			}
			else
			{
				son = -1;
			}
		}
		
	}while(son != -1);
}


void insert(int x)
{
	A[t] = x, Pos[t] = n, Heap[n] = t; 
	++t, ++n;
	up(n-1);
}

void del(int x)
{
	int pos = Pos[x];
    A[x] = -1;
    Pos[x] = -1;
 
    if(pos != (n-1)){
        Heap[pos] = Heap[n-1];
		--n;
		
        Pos[Heap[pos]] = pos;
 
        if(n > 0){
            if(pos > 0 && A[Heap[pos]] < A[Heap[getParent(pos)]])
                up(pos);
            else
				down(pos);
        }
    }
    else
        --n;
}

int main()
{
	freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);
 
    int i, x, cod, N;
 
    scanf("%d ", &N);
 
    for (i=1; i<=N; i++)
    {
        scanf("%d ", &cod);
 
        if (cod == 1)
        {
            scanf("%d", &x);
            insert(x);
        }
 
        if (cod == 2)
        {
            scanf("%d", &x);
            del(x-1);
        }
 
        if (cod == 3){
            printf("%d\n", getMin());
        }
    }
	
	return 0;
}
