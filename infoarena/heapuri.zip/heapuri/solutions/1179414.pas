type poz1=array[0..200100] of longint;
	 poz2=array[0..200100] of longint;
	 heap=array[0..200100] of longint;
var a,b:text;
	num,op,n,i,j:longint;
	h:heap;
	t:poz1;
	u:poz2;
	
procedure up(p:longint);
var r1,r2,r3:longint;
begin
	while (h[p]<h[p div 2]) and (p>0) do
		begin
		r1:=h[p div 2];
		h[p div 2]:=h[p];
		h[p]:=r1;
		r2:=t[u[p]]; 
		t[u[p]]:=t[u[p div 2]];
		t[u[p div 2]]:=r2;
		r3:=u[p];
		u[p]:=u[p div 2];
		u[p div 2]:=r3;
		p:=p div 2;
		end;
end;
	
procedure down(p:longint);
var r1,r2,r3:longint;
begin
	while (p<=(j div 2)) and (p>0) do
	begin
		if (h[2*p]<h[p]) and (2*p<=j) then
			begin
			r1:=h[p];
			h[p]:=h[p*2];
			h[p*2]:=r1;
			r2:=t[u[p]]; 
			t[u[p]]:=t[u[2*p]];
			t[u[p*2]]:=r2;
			r3:=u[p];
			u[p]:=u[p*2];
			u[p*2]:=r3;
			p:=p*2;
			end;
	
		if (h[2*p+1]<h[p]) and (2*p+1<=j) then
			begin
			r1:=h[p];
			h[p]:=h[p*2+1];
			h[p*2+1]:=r1;
			r2:=t[u[p]]; 
			t[u[p]]:=t[u[2*p+1]];
			t[u[p*2+1]]:=r2;
			r3:=u[p];
			u[p]:=u[p*2+1];
			u[p*2+1]:=r3;
			p:=p*2+1;
		end;
	end;
end;
	
procedure add(num:longint);
begin
	j:=j+1;
	h[j]:=num;
	t[i]:=j;
	u[j]:=i;
	up(j);
end;	
	
procedure del(p:longint);
begin
	p:=t[p];
	h[p]:=h[j];
	t[u[j]]:=t[u[p]];
	u[p]:=u[j];
	j:=j-1;
	if p>1 then up(p);
	if p<=(j div 2) then down(p);
end;	
	
begin
assign(a,'heapuri.in'); reset(a);
assign(b,'heapuri.out'); rewrite(b);
readln(a,n);
for i:=1 to n do
	begin
	read(a,op);
	case op of
		1:begin read(a,num); add(num); end;
		2:begin read(a,num); del(num); end;
		3:writeln(b,h[1]);
	end;
	end;
close(a);
close(b);
end.
