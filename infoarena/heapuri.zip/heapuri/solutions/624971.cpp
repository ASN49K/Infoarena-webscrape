#include <fstream>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

const int N=200001;
const int INF=2000000000;

int n,heapsize,ord[N];

struct punct{
	int val,cron;
}v[N];

inline void schimba(int x,int y){
	punct aux;
	aux=v[y];
	v[y]=v[x];
	v[x]=aux;
}

int urca(int x){
	while(v[x].val<v[x/2].val && (x/2)>=1){
		schimba(x,x/2);
		ord[x/2]=x;
		x=x/2;
	}
	return x;
}

void coboara(int x){
	int min;
	if(x*2==heapsize){
		min=2*x;
		schimba(x,min);
		ord[v[min].cron]=x;
		ord[v[x].cron]=min;
		x=min;
		coboara(x);
	}
	else{
		if(x*2+1>heapsize)
			return;
		if(v[2*x].val<v[2*x+1].val)
			min=2*x;
		else
			min=2*x+1;
		schimba(x,min);
		ord[v[min].cron]=x;
		ord[v[x].cron]=min;
		x=min;
		coboara(x);
	}
}

int main(){
	int i,opcode,opvalue;
	in>>n;
	for(i=1;i<=n;i++){
		in>>opcode;
		if(opcode==1){
			in>>opvalue;
			v[++heapsize].val=opvalue;
			v[heapsize].cron=heapsize;
			ord[heapsize]=urca(heapsize);
		}
		if(opcode==2){
			in>>opvalue;
			v[ord[opvalue]].val=INF;
			coboara(ord[opvalue]);
		}
		if(opcode==3){
			out<<v[1].val<<"\n";
		}
	}			
	return 0;
}
