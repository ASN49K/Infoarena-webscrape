#include <cstdio>
#include <algorithm>
#define nmax 200005

using namespace std;

int n,v[nmax],poz[nmax],heap[nmax],nrv,nrh;

void push(int nr)
{
    int k;
    v[++nrv]=nr;
    heap[++nrh]=nrv;
    poz[nrv]=nrh;
    k=nrh;
    while(k>1&&v[heap[k]]<v[heap[k/2]])
    {
        swap(poz[heap[k]],poz[heap[k/2]]);
        swap(heap[k],heap[k/2]);
        k=k/2;
    }
}

int pozmxm(int i,int j)
{
    if(v[heap[i]]<v[heap[j]])
        return i;
    return j;
}

void pop(int nr)
{
    swap(heap[poz[nr]],heap[nrh]);
    poz[heap[poz[nr]]]=poz[nr];
    nrh--;
    int k=poz[nr],j;
    while((2*k)<=nrh&&(v[heap[k]]>v[heap[2*k]]||v[heap[k]]>v[heap[2*k+1]]))
    {
        int j=pozmxm(2*k,2*k+1);
        swap(heap[k],heap[j]);
        swap(poz[heap[k]],poz[heap[j]]);
        k=j;
    }
}

int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    int cod,nr;
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&cod);
        if(cod!=3)
            scanf("%d",&nr);
        else
            printf("%d\n",v[heap[1]]);
        if(cod==1)
            push(nr);
        if(cod==2)
            pop(nr);
    }
    return 0;
}
