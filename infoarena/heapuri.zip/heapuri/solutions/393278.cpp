#include<algorithm>
using namespace std;
#include<queue>
#include<bitset>

bitset <1000000000> d;

struct cmp
{
    bool operator() (const pair<int,int> &a, const pair<int,int> &b) const
    {
        return (a.first>b.first);
    }
}; priority_queue <pair<int,int>, vector <pair <int,int> >,cmp> c;

int main ()
{
    freopen("heap.in","r",stdin);
    freopen("heap.out","w",stdout);
    int i,q,n,x,intrat=0;
    scanf("%d",&n);
    for(i=1;i<=n;++i)
    {
        scanf("%d",&q);
        if(q==1)
        {
            scanf("%d",&x);
            c.push (make_pair (x,++intrat));
        }
        if(q==2)
        {
            scanf("%d",&x);
            d[x]=1;
        }
        if(q==3)
        {
            for(;d[c.top ().second];c.pop ());
                printf("%d\n",c.top ().first);
        }
    }
    return 0;
}
