#include <iostream>
#include <vector>
#include <stdio.h>
#define NMAX 200001

using namespace std;

int hepuiala[NMAX];

class MinHeap
{
    int* harr;
    int capacity;
    int heap_size;

public:
    MinHeap(int capacity);

    void MinHeapify(int);

    int parent(int i) { return (i - 1) / 2; }
    int left(int i) { return (2 * i + 1); }
    int right(int i) { return (2 * i + 2); }

    int extractMin();

    int getMin() { return harr[0]; }

    void deleteValue(int val, int cur_index);
    void decreaseKey(int i, int new_val);
    void deleteKey(int i);
    void insertKey(int k);
};

void MinHeap::deleteValue(int val, int cur_index)
{
    if (harr[cur_index] == val)
    {
        deleteKey(cur_index);
        return;
    }
    else
    {
        if (2 * cur_index + 1 < capacity)
        {
            deleteValue(val, 2 * cur_index + 1);
        }
        if (2 * cur_index + 2 < capacity)
        {
            deleteValue(val, 2 * cur_index + 2);
        }
    }
}

void MinHeap::MinHeapify(int i)
{
    int l = left(i);
    int r = right(i);
    int smallest = i;

    if (l < heap_size && harr[l] < harr[i])
        smallest = l;
    if (r < heap_size && harr[r] < harr[smallest])
        smallest = r;
    if (smallest != i)
    {
        swap(harr[i], harr[smallest]);
        MinHeapify(smallest);
    }
}

MinHeap::MinHeap(int cap)
{
    heap_size = 0;
    capacity = cap;
    harr = new int[cap];
}

void MinHeap::insertKey(int k)
{
    if (heap_size == capacity)
    {
        return;
    }

    heap_size++;
    int i = heap_size - 1;
    harr[i] = k;

    while (i != 0 && harr[parent(i)] > harr[i])
    {
        swap(harr[i], harr[parent(i)]);
        i = parent(i);
    }
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i] = new_val;
    while (i != 0 && harr[parent(i)] > harr[i])
    {
        swap(harr[i], harr[parent(i)]);
        i = parent(i);
    }
}

int MinHeap::extractMin()
{
    if (heap_size <= 0)
        return INT_MAX;

    if (heap_size == 1)
    {
        heap_size--;
        return harr[0];
    }

    int root = harr[0];
    harr[0] = harr[heap_size - 1];
    heap_size--;
    MinHeapify(0);

    return root;
}

void MinHeap::deleteKey(int i)
{
    decreaseKey(i, INT_MIN);
    extractMin();
}

void swap(int* x, int* y)
{
    int temp = *x;
    x = y;
    *y = temp;
}

int main()
{
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);

    int N;
    scanf("%d", &N);
    MinHeap heap(NMAX);
    vector<int> order;
    for (int i = 0; i < N; i++)
    {
        int x;
        scanf("%d", &x);
        if (x == 1)
        {
            int y;
            scanf("%d", &y);
            heap.insertKey(y);
            order.push_back(y);
        }
        else if (x == 2)
        {
            int y;
            scanf("%d", &y);
            //cout << order[y - 1]<<"\n";
            heap.deleteValue(order[y - 1], 0);
        }
        else
        {
            printf("%d\n", heap.getMin());
        }
    }
}
