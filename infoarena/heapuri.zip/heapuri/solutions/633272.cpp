#include<cstdio>
#include<vector>
#include<set>

using namespace std;
int n;
multiset <int> heap;
vector <int> L;

int main() {
	int i, cod = 0, x;
	
	freopen("heapuri.in", "r", stdin), freopen("heapuri.out", "w", stdout);
	scanf("%d", &n);
	
	for(i = 1; i <= n; i++)	{
		scanf("%d", &cod);
		if(cod == 1) {
			scanf("%d", &x);
			L.push_back(x);
			heap.insert(x); // inserez elementul x in multime
		}
		else if(cod == 2) {
			scanf("%d", &x);
			heap.erase(heap.find(L[x - 1])); // sterg elementul intrat al x-lea in multime
		}
		else if(cod == 3) {
			multiset <int> :: iterator it = heap.begin();
			printf("%d\n", *it);
		}
	}
	
	return 0;
}
