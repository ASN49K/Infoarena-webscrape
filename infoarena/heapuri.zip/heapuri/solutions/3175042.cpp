#include <fstream>
#include <iostream>
#define NMAX 200100

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int N, n, poz[NMAX], t;
struct elem
{
    int val,t;
}H[NMAX];
void inserare(int x, int t);
void combinare(int poz);
int ExtragereMin();
void Stergere(int i);

int main()
{
    int op,x,i;

    fin>>N;
    for(i=1; i<=N; i++)
    {
        fin>>op;
        if(op==1)
        {
            t++;
            fin>>x;
            inserare(x,t);
        }
        if(op==2)
        {
            fin>>x;
            Stergere(poz[x]);
        }
        if(op==3)
            fout<<H[1].val<<'\n';
    }
    return 0;
}

void inserare(int x, int t)
{
    int fiu,tata;
    fiu=n+1; tata=fiu/2;

    while(tata>0 && H[tata].val>x)
    {
        H[fiu]=H[tata];
        poz[H[tata].t]=fiu;

        fiu=tata;
        tata=fiu/2;
    }
    n++;
    H[fiu]={x,t};
    poz[t]=fiu;
}

void combinare(int p)
///se combina nodul de pe pozitia poz
///cu minheap-urile corecte cu rad. 2*poz si 2*poz+1
{
    int tata,fiu;
    elem x;
    x=H[p]; tata=p; fiu=2*tata;
    while(fiu<=n)//cat timp exista fiu
    {
        if(fiu+1<=n && H[fiu+1].val<H[fiu].val)
            fiu++;
        //fiul cel mai bun(cel mai mic)
        if(H[fiu].val < x.val)
        {
            H[tata]=H[fiu];
            poz[H[fiu].t]=tata;

            tata=fiu;
            fiu=2*tata;
        }
        else break;
    }
    //toti fii sunt pe pozitiile corecte
    H[tata]=x;
    poz[x.t]=tata;
}

void Stergere(int i)
{
    H[i]=H[n];
    poz[H[n].t]=i;
    n--;
    combinare(i);
}

int ExtragereMin()
{
    int minim=H[1].val;
    H[1]=H[n];
    n--;
    combinare(1);
    return minim;
}

