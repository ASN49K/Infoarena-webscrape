#include <fstream>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int Heap[200010],i,n,val,op,N,poz[200010],j;

int father( int X )
{
    return X / 2;
}

int left_son( int X )
{
    return X * 2;
}

int right_son( int X )
{
    return X * 2 + 1;
}


void sift( int Heap[], int N, int K )
{
    int son;

    do
    {
        son = 0;

        if( left_son( K ) <= N )
        {
            son = left_son( K );

            if( right_son( K ) <= N && Heap[ left_son( K ) ] > Heap[ right_son( K ) ] )
                son = right_son( K );

            if( Heap[ son ] > Heap[ K ] )
                son = 0;
        }

        if( son )
        {
            swap( Heap[ son ] , Heap[ K ] );
            K = son;
        }

    }while( son );
}

void percolate( int Heap[], int N, int K )
{
    while( K > 1 && Heap[ father( K ) ] > Heap[ K ] )
    {
        swap( Heap[ father( K ) ] , Heap[ K ] );
        K = father( K );
    }
}

void add( int Heap[], int& N, int val )
{
    N++;
    Heap[ N ] = val;
    percolate( Heap , N , N );
}

void cut( int Heap[], int& N, int K )
{
    Heap[ K ] = Heap[ N ];
    Heap[ N ] = 0;
    N--;
    if( Heap[ father( K ) ] > Heap[ K ] )
        percolate( Heap , N , K );
    else
        sift( Heap , N , K );
}

int main()
{
    fin>>n;
    for( i = 1 ; i <= n ; i++ )
    {
        fin>>op;

        if( op == 3 )
        {
            fout<<Heap[ 1 ]<<'\n';
        }
        else if( op == 1 )
        {
            fin>>val;
            add( Heap , N , val );
            poz[ N ] = val;
        }
        else if( op == 2 )
        {
            fin>>val;
            val = poz[ val ];
            for( j = 1 ; j <= n ; j++ )
                if( Heap[ j ] == val )
                break;
            cut( Heap , N , j );
        }
    }

return 0;
}
