#include    <iostream>
#include    <fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
const int NMax = 100005;
int N, Heap[NMax], Val[NMax], Poz[NMax], i;
inline void Swap(int x, int y)
{
    swap(Heap[x], Heap[y]);
    swap(Poz[Heap[x]], Poz[Heap[y]]);
}
bool cmp(int x,int y)
{
    return x < y;
}
void UpHeap(int x)
{
    int Father = x / 2;
    if(Father && cmp(Val[Heap[x]],Val[Heap[Father]]))
    {
        Swap(x, Father);
        UpHeap(Father);
    }
}
void DownHeap(int x)
{
    int Son = x * 2;
    if(Son + 1 <= N && cmp(Val[Heap[Son + 1]], Val[Heap[Son]]))
        Son += 1;
    if(Son <= N && cmp(Val[Heap[Son]], Val[Heap[x]]))
    {
        Swap(Son, x);
        DownHeap(Son);
    }
}
void Insert(int x)
{
    i += 1;
    Val[i] = x;
    N += 1;
    Heap[N] = i;
    Poz[i] = N;
    UpHeap(N);
}
void Erase(int x)
{
    Swap(x,N);
    N -= 1;
    DownHeap(x);
}
void Read()
{
    int Q, Case;
    fin >> Q;
    for(int i = 1; i <= Q; i++)
    {
        fin >> Case;
        if(Case == 1)
        {
            int x;
            fin >> x;
            Insert(x);
        }
        if(Case == 2)
        {
            int x;
            fin >> x;
            Erase(Poz[x]);
        }
        if(Case == 3)
            fout << Val[Heap[1]] << "\n";
    }
}
int main()
{
    Read();
    return 0;
}
