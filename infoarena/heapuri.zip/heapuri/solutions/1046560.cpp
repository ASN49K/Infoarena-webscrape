#include <fstream>
#include <set>
using namespace std;
set <int> v;
int x,n,i,key,q,a[500002];
int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    f>>n;
    for (i=1;i<=n;i++)
      {
          f>>key;
          if (key==1) f>>x,v.insert(x),a[++q]=x;
          if (key==2) f>>x,v.erase(v.find(a[x]));
          if (key==3) g<<*v.begin()<<'\n';
      }
    f.close();
    g.close();
    return 0;
}
