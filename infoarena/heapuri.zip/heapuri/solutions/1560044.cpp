#include <fstream>
#include <cmath>
#include <vector>
#include <set>
#include <algorithm>
#include <cstring>
#include <map>
#include <iomanip>
#include <time.h>
#include <stdio.h>
//#include <iostream>
using namespace std;
ifstream cin("algsort.in");
ofstream cout("algsort.out");
int index[200008];
void addheap(int x[], int poz, int val)
{
    x[poz] = val;
    while(poz / 2 > 0 && x[poz] <= x[poz / 2]){
        swap(x[poz], x[poz / 2]);
        swap(index[poz], index[poz / 2]);
        poz /= 2;
    }
}
void deletelem(int x[], int poz, int &n)
{
    swap(x[poz], x[n]);
    swap(index[poz], index[n]);
    n--;
    x[n + 1] = 1<<30;
    while(poz / 2 > 0 && x[poz] >= x[poz / 2]){
        swap(x[poz], x[poz / 2]);
        swap(index[poz], index[poz / 2]);
        poz /= 2;
    }
    while(poz < n && (x[poz] >= x[poz * 2] || x[poz] >= x[poz * 2 + 1])){
        if(x[poz * 2] <= x[poz * 2 + 1]){
            swap(x[poz * 2], x[poz]);
            swap(index[poz * 2], index[poz]);
            poz *= 2;
        }
        else{
            swap(x[poz * 2 + 1], x[poz]);
            swap(index[poz * 2 + 1], index[poz]);
            poz *= 2;
            poz++;
        }
    }
}
int main()
{
    int n, x[200004], a, var;
    cin >> n;
    for(int i = 0; i <= 200000; i++){
        x[i] = 1<<30;
        index[i] = i + 1;
    }
    int v = 0;
    for(int i = 0; i < n; i++){
        cin >> var;
        if(var == 1){
            cin >> a;
            addheap(x, v + 1, a);
            v++;
        }
        if(var == 2){cin >> a;
            for(int i = 1; i <= v; i++)
                cout << x[i] << " ";
            return 0;
            deletelem(x, index[a], v);
        }
        else if(var == 3)
            cout << x[1] << "\n";
    }
    return 0;
}
