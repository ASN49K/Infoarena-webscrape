#include<stdio.h>
int x,y,z,t,n,r,j,p[200001],v[200001],h[200001];
void A(int t) 
{
    for(;t>1&&v[h[t]]<v[h[t>>1]];h[t]^=h[t>>1]^=h[t]^=h[t>>1],p[h[t]]=t,p[h[t>>1]]=t>>1,t>>=1);
}
int main() 
{
    freopen("heapuri.in","r",stdin),freopen("heapuri.out","w",stdout),scanf("%d",&n);
    while(n--) 
	{
        scanf("%d",&z);
        if(z==3)
        {
            printf("%d\n",v[h[1]]);
            continue;
    	}
        scanf("%d",&r);
        if(z==1)
        {
            v[++t]=r,h[++j]=t,p[t]=j,A(j);
            continue;
    	}
        for(v[r]=-1,A(p[r]),p[h[1]]=y=0,h[1]=h[j--],p[h[1]]=x=1;x!=y;h[x]^=h[y]^=h[x]^=h[y],p[h[x]]=x,p[h[y]]=y) 
		{
            y=x;
            if((y<<1)<=j&&v[h[x]]>v[h[y<<1]])
                x=y<<1;
            if((y<<1)<j&&v[h[x]]>v[h[(y<<1)+1]])
                x=(y<<1)+1;
        }
    }
}
