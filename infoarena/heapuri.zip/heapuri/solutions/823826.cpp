#include <stdio.h>

using namespace std;
int mx=0,H[200001],v[200001],poz[200001],h=0,n;
void insert()
{
    int k=h,aux;
    while(k>1 && H[k]<H[k/2])
    {
        aux=H[k];
        H[k]=H[k/2];
        H[k/2]=aux;

        v[mx]=k/2;
        v[poz[k/2]]=k;

        k=k/2;

    }
}
int minim()
{
    return H[1];
}
int pozminima(int a,int b)
{
    if(H[a]<H[b]) return a;
        else return b;
}
void down(int x)
{
    int aux,g,m;
    while(1)
    {


        if (2*x+1<=h){
            g=pozminima(2*x,2*x+1);
            m=H[g];
            if (H[g]<H[x]) {
                            aux=H[x];
                            H[x]=H[g];
                            H[g]=aux;

                            aux=poz[x];
                            poz[x]=poz[g];
                            poz[g]=aux;

                            aux=v[poz[x]];
                            v[poz[x]]=v[poz[g]];
                            v[poz[g]]=aux;
                        }
                    else break;
                      }
                else if(2*x<=h) {
                                    g=2*x;
                                    m=H[g];
                                    if(H[g]<H[x]) {
                                                        aux=H[x];
                                                        H[x]=H[g];
                                                        H[g]=aux;

                                                        aux=poz[g];
                                                        poz[g]=poz[x];
                                                        poz[x]=aux;

                                                        aux=v[poz[x]];
                                                        v[poz[x]]=v[poz[g]];
                                                        v[poz[g]]=aux;
                                                    }
                                                else break;
                                }
                        else break;

        x=g;
    }
}
void eliminare(int a)
{
    int pozinheap=v[a];
    H[pozinheap]=H[h];
    h--;
    down(pozinheap);
}
int main()
{
    int op,a,i;
    FILE*f,*g;
    f=fopen("heapuri.in","r");
    g=fopen("heapuri.out","w");
    fscanf(f,"%d",&n);
    for(int i=1;i<=n;i++)
    {
        fscanf(f,"%d",&op);
        switch(op)
        {
            case 1: { fscanf(f,"%d",&a); H[++h]=a; v[++mx]=h; poz[h]=mx; insert(); break;}
            case 2: { fscanf(f,"%d",&a); eliminare(a);break;}
            case 3: { fprintf(g,"%d\n",minim()); break;}
        }
    }
    return 0;
}
