program heap;
var H,sol : array [1..2000100] of longint;
    k,i,n,a,b,t,j,l,stinga,dreapta,mijloc  : longint;
    gasit : boolean;
    b1,b2 : array[0..1 shl 17] of char;

procedure swap(var x,y : longint);
  var aux : longint;
    begin
       aux:=x;
       x:=y;
       y:=aux;
    end;


procedure coboara(k : longint);
  var fiu : longint;
    begin
         repeat
               fiu:=0;
               if k*2<=n then
                  begin
                       fiu:=k*2;
                       if  (k<n) and (H[k*2+1]<H[k*2]) then fiu:=k*2+1;
                       if H[fiu]>=H[k] then fiu:=0
                  end;
                  if fiu<>0 then begin
                                       swap(H[k],H[fiu]);
                                       k:=fiu;
                                 end;

         until fiu=0;
   end;

procedure ridica(k : longint);
   var aux: longint;
     begin
         while (k<>1) and (H[k]<H[k div 2]) do  begin
                                                     swap(H[k],H[k div 2]);
                                                     k:=k div 2;
                                             end;
       end;

procedure sterge(var n : longint ; k : longint);
  begin
    H[k]:=H[n];
    n:=n-1;
    if (k<>1) and (H[k]<H[k div 2]) then ridica(k)
                                    else coboara(k);
  end;

procedure inserare(var n,l  : longint; k : longint) ;
  begin
      n:=n+1;
      H[n]:=k;
      l:=l+1;
      sol[l]:=k;
      ridica(n);
   end;



begin
   assign(input,'heapuri.in'); settextbuf(input,b1);reset(input);
   assign(output,'heapuri.out'); settextbuf(output,b2);rewrite(output);
   readln(t);
   for k:=1 to t  do begin
                           read(a);
      if a=3 then writeln(H[1])
             else
      if a=2 then begin
                       readln(b);
                       stinga:=1; dreapta:=n; gasit:=false;
                       repeat
                             mijloc:=(stinga + dreapta ) div 2;
                             if H[mijloc]=sol[b] then gasit:=true
                                                 else
                             if sol[b]>H[mijloc] then stinga:=mijloc+1
                                                 else dreapta:=mijloc-1;
                       until gasit or (stinga>dreapta);
                       if stinga>dreapta then
                       if H[stinga]=sol[b] then sterge(n,stinga)
                                           else
                       if H[dreapta]=sol[b] then sterge(n,dreapta);

                   end
             else
      if a=1 then begin
                       readln(b);
                       inserare(n,l,b);
                       end;

               end;
   close(input);
   close(output);
end.
