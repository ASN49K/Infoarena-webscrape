#include <fstream>
#include <climits>
#include <vector>
#include <algorithm>

std::ifstream be("heapuri.in");
std::ofstream ki("heapuri.out");

std::vector<int> kupac, poz;
int sorszam;

void fel (int p)
{
    while (kupac[p/2] > kupac[p]) {
        std::swap (kupac[p/2], kupac[p]);
        p /= 2;
        poz[sorszam] = p;
    }
}

void le (int p)
{
    int min1;
    while (p*2 <= kupac.size()-1) {
        min1 = kupac[p*2] > kupac[p*2+1] ? p*2 : p*2+1;
        if (kupac[p] > kupac[min1]) {
            std::swap (kupac[p], kupac[min1]);
            std::swap (poz[p], poz[min1]);
            p = min1;
        }
        else break;
    }
}

void betesz_kupac (int x)
{
    kupac.push_back (x);
    poz[sorszam] = kupac.size()-1;
    fel (kupac.size()-1);
}

void kivesz_kupac (int p)
{
    kupac[p] = kupac.back();
    kupac.pop_back();
    le (p);
}

int main()
{
    poz.resize (200010, 0);
    kupac.push_back (INT_MIN);
    int n, i, op1, op2;
    be >> n;

    for (i=1; i<=n; i++) {
        be >> op1;
        if (op1 == 1) {
            be >> op2;
            sorszam = i;
            betesz_kupac (op2);
        }
        else if (op1 == 2) {
            be >> op2;
            kivesz_kupac (poz[op2]);
        }
        else if (op1 == 3) {
            ki << kupac[1] << "\n";
        }
    }
}
