#include <cstdio>
#define MAX_N 200001
using namespace std;
int N, poz[MAX_N], heap[MAX_N], last=0, nr_ord[MAX_N];
FILE *f, *g;

void swap_val(int suc, int anc)
{
    int aux;
    aux=heap[suc];
    heap[suc]=heap[anc];
    heap[anc]=aux;
    aux=nr_ord[suc];
    nr_ord[suc]=nr_ord[anc];
    nr_ord[anc]=aux;
}

void insert_val(int x, int i)
{
    int loc;
    last++;
    heap[last]=x;
    loc=last;
    if(last>1)
    {
        while(heap[loc/2]>x)
        {
            swap_val(loc, loc/2);
            loc=loc/2;
        }
    }
    poz[i]=loc;
    nr_ord[loc]=i+1;
}

void eliminate(int i)
{
    int index=poz[i];
    poz[i]=0;
    while(2*index<=last)
    {
            if(2*index+1<=last)
            {
                int max_poz;
                if(heap[2*index+1]>heap[2*index])
                    max_poz=2*index;
                else
                    max_poz=2*index+1;
                heap[index]=heap[max_poz];
                nr_ord[index]=nr_ord[max_poz];
                poz[nr_ord[index]]=index;
                index=max_poz;
            }
            else
            {
                heap[index]=heap[2*index];
                nr_ord[index]=nr_ord[2*index];
                poz[nr_ord[index]]=index;
                index=2*index;
            }
    }
}

int main()
{
    f = fopen("heapuri.in", "r");
    g = fopen("heapuri.out", "w");

    fscanf(f, "%d", &N);
    for(int i=0; i<N; i++)
    {
        int type, val;
        fscanf(f, "%d", &type);
        if(type==1)
        {
            fscanf(f, "%d", &val);
            insert_val(val, i);
        }
        if(type==2)
        {
            fscanf(f, "%d", &val);
            eliminate(val);
        }
        if(type==3)
        {
            fprintf(g, "%d\n", heap[1]);
        }
    }

    fclose(f);
    fclose(g);
    return 0;
}
