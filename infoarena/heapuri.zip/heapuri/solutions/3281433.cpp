#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int q, st[200005], top;
multiset <int> M;


int main()
{
    int op, x;
    fin >> q;
    while (q--)
    {
        fin >> op;
        if (op == 1)
        {
            fin >> x;
            st[++top] = x;
            M.insert(x);
        }
        else if (op == 2)
        {
            fin >> x;
            M.erase(M.find(st[x]));
        }
        else
        {
            fout << *M.begin() << "\n";
        }
    }

    return 0;
}