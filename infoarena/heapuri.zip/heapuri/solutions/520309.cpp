#include<fstream>
#include<algorithm>
#define Nmax 200002
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int n,a[Nmax],P[Nmax],C[Nmax],Pc[Nmax],nr,N;

void heaps();
void combine(int i,int n);
void push(int i,int N);

int main()
{
  heaps();
  f.close();
  g.close();
  return 0;
}

void heaps()
{
  int i,c,x,N=0,pos;
  f>>n;
  for (i=1;i<=n;++i)
  {
    f>>c;
    if (c==3) 
    {
      g<<a[1]<<'\n';
      continue;
    }
      else if (c==1)
    {
      ++N;
      f>>x;
      a[N]=x;
      ++nr;
      Pc[N]=nr;      
      C[nr]=x;
      P[nr]=N;      
      //swap(a[1],a[N]);
      //swap(P[Pc[1]],P[Pc[N]]);
      //swap(Pc[1],Pc[N]);
      push(N,N);
    }
    else if (c==2)
    {
      f>>x;
      pos=P[x];
      swap(a[pos],a[N]);
      swap(P[Pc[pos]],P[Pc[N]]);
      swap(Pc[pos],Pc[N]);
      --N;
      combine(pos,N);
    }
    //for (j=N/2;j;--j)
      //combine(j,N);
  }
}

void push(int i,int N)
{
  int aux,t,c,Pcax;
  aux=a[i];
  Pcax=Pc[i];
  c=i;
  t=c/2;
  while (t)
  {
    if (aux<a[t])
    {
      a[c]=a[t];
      P[Pc[t]]=P[Pc[c]];
      Pc[c]=Pc[t];
      c=t;
      t/=2;
    }
    else t=0;
  }
  a[c]=aux;
  Pc[c]=Pcax;
  P[Pc[c]]=c;
}
    

void combine(int i,int n)
{
  int c,t,aux=a[i],Pcax,Cax;
  Cax=P[Pc[i]];
  Pcax=Pc[i];
  t=i;
  c=t*2;
  while (c<=n)
  {
    if (c+1<=n&&a[c+1]<a[c])
      ++c;
    if (aux>a[c])
    {
      a[t]=a[c];
      P[Pc[c]]=P[Pc[t]];
      Pc[t]=Pc[c];
      //P[Pc[t]]=P[Pc[c]];
      
      t=c;
      c*=2;
    }
    else c=n+1;
  }
    a[t]=aux;
    Pc[t]=Pcax;
    P[Pc[t]]=t;

}
