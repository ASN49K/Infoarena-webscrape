#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <algorithm>
#include <functional>
#include <set>

int main()
{

	std::ifstream f("heapuri.in");
	int n;
	f >> n;

	std::ofstream out("heapuri.out");

	std::set<int> heap; 

	std::vector<int> elemente;
	elemente.reserve(n);

	for (int i = 0; i < n; i++)
	{
		int op;
		f >> op;
		if (op == 1)
		{
			int x;
			f >> x;
			
			heap.insert(x);
			elemente.push_back(x);

		}else if(op == 2)
		{
			int x;
			f >> x;
			heap.erase(elemente[x-1]);
			
		}else if(op == 3)
		{
			int el = *heap.begin();
			out << el << "\n";

		}
	}

	out.close();

	return 0;
}