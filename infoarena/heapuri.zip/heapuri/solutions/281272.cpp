#include <stdio.h>

#define Nmax 200001

int dim,n,h[Nmax],a[Nmax],p[Nmax],cnt;

void swap(int x,int y)
{
	int tmp=h[x];
	h[x]=h[y];
	h[y]=tmp;
	p[h[x]]=x;
	p[h[y]]=y;
}

void up(int poz)
{
	if(poz<=1)
		return ;
	if(a[h[poz]]<a[h[poz/2]])
		{
			swap(poz,poz/2);
			up(poz/2);
		}
}

void insert(int nr)
{
	++dim;
	h[dim]=nr;
	p[nr]=dim;
	up(dim);
}

void down(int poz)
{
	int min=poz;
	if(poz*2<=dim)
		if(a[h[poz*2]]<a[h[min]])
			min=poz*2;
	if(poz*2+1<=dim)
		if(a[h[poz*2+1]]<a[h[min]])
			min=poz*2+1;
	if(min!=poz)
		{
			swap(min,poz);
			down(min);
		}
}

void pop(int k)
{
	a[k]=0;
	up(p[k]);
	h[1]=h[dim--];
	p[h[1]]=1;
	down(1);

}

int main()
{
	int i,op,x,carmen;

	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);

	scanf("%d",&n);

	for(i=1;i<=n;++i)
		{
			scanf("%d",&op);
			if(op==1)
				{
					scanf("%d",&x);
					a[++cnt]=x;
					insert(cnt);
				}
			else
				if(op==2)
					{
						scanf("%d",&carmen);
						pop(carmen);

					}
				else
					printf("%d\n",a[h[1]]);
		}
	return 0;
}