#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <set>
#define MAXN 200010
using namespace std;

set<int> h;
int ord[MAXN],N,cnt;

int main() {

    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);

    scanf("%d",&N);

    int i,x,c;

    for (i=0;i<N;++i) {
        scanf("%d",&c);
        if (c <= 2) scanf("%d",&x);
        switch (c) {
            case 1: {h.insert(x);ord[cnt]=x;cnt++;break;}
            case 2: {h.erase(ord[x-1]);break;};
            case 3: {printf("%d\n",*h.begin());};
        }
    }

    fclose(stdin);
    fclose(stdout);

}
