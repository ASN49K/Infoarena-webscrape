#include <fstream>
#include <set>
using namespace std;
ifstream cin("heapuri.in");
ofstream cout("heapuri.out");
multiset <int> my_set;
int n,nr,v[200005];
int main()
{
    cin >> n;
    for(int i=0; i<n; i++)
    {
        int x,y;
        cin >> x;
        if(x==1)
        {
            cin >> y;
            nr++;
            my_set.insert(y);
            v[nr]=y;
        }
        else if(x==2)
        {
            cin >> y;
            my_set.erase(my_set.find(v[y]));
        }
        else if(x==3)
        {
            multiset <int> :: iterator it =my_set.begin();
            cout << *it << '\n';
        }
    }
    return 0;
}
