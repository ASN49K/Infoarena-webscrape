#include<cstdio>
#include<algorithm>
#include<utility>
using namespace std;
int heap[200010],n;
pair<int,int> A[200010];
void heapup(int p)
{
	int t=p/2;
	if(t<1) return;
	if(A[heap[t]].first>A[heap[p]].first)
	{
		swap(heap[t],heap[p]);
		swap(A[heap[t]].second,A[heap[p]].second);
		heapup(t);
	}
}
void heapdown(int p)
{
	int f=2*p;
	if(f>n) return;
	if(A[heap[f]].first>A[heap[f+1]].first&&f+1<=n) f++;
	if(A[heap[f]].first<A[heap[p]].first)
	{
		swap(heap[f],heap[p]);
		swap(A[heap[f]].second,A[heap[p]].second);
		heapdown(f);
	}
}
int main()
{
	int c,x,k=0,t,i;
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	scanf("%d",&t);
	for(;t;--t)
	{
		scanf("%d",&c);
		if(c==1)
		{
			scanf("%d",&x);
			n++;
			A[++k]=make_pair(x,n);
			heap[n]=k;
			heapup(n);
		}
		if(c==2)
		{
			scanf("%d",&x);
			A[x].first=1000000001;
			heapdown(A[x].second);
			n--;
			
		}
		if(c==3)
		{
			printf("%d\n",A[heap[1]].first);
		}
		//for(i=1;i<=n;i++) printf("%d ",A[heap[i]].first);
		//printf("\n");
	}
	return 0;
}
