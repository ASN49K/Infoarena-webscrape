#include <iostream>
#include <fstream>
using namespace std;
int i,n,v[200],ax,i1,n1;
int main(void)
{
    FILE * f;
    f=fopen("heap.in","r");
    ofstream g("heap.out");
    fscanf(f,"%d",&n);
    for (i=1;i<=n;i++)
    {
        fscanf(f,"%d",&v[i]);
        i1=i;
        while ((v[i1]>v[i1/2])&&(i1!=1))
        {
            ax=v[i1/2];
            v[i1/2]=v[i1];
            v[i1]=ax;
            i1=i1/2;
        }
    }
    for (i=1;i<=n;i++)
        cout<<v[i]<<' ';
    n1=n;
    for (i=1;i<=n;i++)
    {
        g<<v[1]<<' ';
        v[1]=v[n1];
        v[n1]=0;
        i1=1;
        while (v[i1]<max(v[i1*2],v[i1*2+1]))
        {
            if (v[i1*2]>v[i1*2+1])
            {
                ax=v[i1*2];
                v[i1*2]=v[i1];
                v[i1]=ax;
                i1=i1*2;
            }
            else
            {
                ax=v[i1*2+1];
                v[i1*2+1]=v[i1];
                v[i1]=ax;
                i1=i1*2+1;
            }
        }
    }
    g.close();
    return 0;
}
