#include <iostream>
#include <algorithm>
#include <queue>
#include <stdio.h>


using namespace std;
int H[1000000];
int heap_size;
int Pos[200001];
int N;


void citire(){
    cin >> heap_size;
    for(int i=1; i<=heap_size; i++)
        cin >> H[i];
}

void afisare(){
    for(int i=1; i<=heap_size; i++)
        cout << H[i] << " ";
    cout << endl;
}


int parent(int i){
    return i/2;
}


int left(int i){
    return 2*i;
}


int right(int i){
    return 2*i+1;
}

void min_heapify2(int i){
    int left_i = left(i);
    int right_i = right(i);
    int min_i = i;

    if(left_i <= heap_size && H[left_i] < H[i])
        min_i = left_i;
    else
        min_i = i;

    if(right_i <= heap_size && H[right_i] < H[min_i])
        min_i = right_i;

    if(min_i != i){
        swap(H[i], H[min_i]);
        min_heapify2(min_i);
    }
}


void build_heap(){
    for(int i=heap_size/2; i>=1; i--)
    {
        min_heapify2(i);
    }
}


void decapitare_heap(){
    swap(H[1], H[heap_size]);
    if(heap_size >0){
        heap_size--;
        min_heapify2(1);
    }
}

void inserare_heap(int i){
    heap_size++;
    H[heap_size] = i;
    int k = heap_size;
    while(H[k] < H[parent(k)] && k>1){
        swap(H[k], H[parent(k)]);
        k = parent(k);
    }
}


int minim_heap()
{
    return H[1];
}

int find_x(int x){
    queue<int> Q;
    int k = 1;
    Q.push(1);

    while(H[k] != x && !Q.empty()){
        k = Q.front();
        Q.pop();
        if(left(k) < heap_size)
            Q.push(left(k));
        if(right(k) < heap_size)
            Q.push(right(k));
    }
    return k;
}

void delete_x(int pos){
    swap(H[pos], H[1]);
    decapitare_heap();
    min_heapify2(1);
}


int main()
{
    freopen("heapuri.in", "r",stdin);
    freopen("heapuri.out", "w", stdout);
    int j, x, pos = 1;
    int x2, kx2;

    cin >> N;
    for(int i=0; i<N; i++){
        cin >> j;
        if(j == 1)
        {
            cin >> x;
            Pos[pos] =x;
            pos++;
            inserare_heap(x);
        }
        else if(j == 2){
            cin >> x;
            x2 = Pos[x];
            kx2 = find_x(x2);
            delete_x(kx2);
        }
        else
            cout << minim_heap() << "\n";
    }


    return 0;
}
