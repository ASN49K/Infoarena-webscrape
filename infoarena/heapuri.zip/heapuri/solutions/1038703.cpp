#include <stdio.h>

int nh,poz[200001],h[200001],v[200001];

void schimba(int a,int b)
{
    int aux;
    aux=h[a];
    h[a]=h[b];
    h[b]=aux;
    poz[h[a]] = a;
    poz[h[b]] = b;
}

void coboara(int p){

    int fs=2*p,fd=2*p+1,bun=p;
    if(fs<=nh&&v[h[fs]]<v[h[bun]]) bun=fs;
    if(fd<=nh&&v[h[fd]]<v[h[bun]]) bun=fd;
    if(bun!=p){
        schimba(p,bun);
        coboara(bun);
    }
}

void urca(int p){

    while(p>=1&&v[h[p]]<v[h[p/2]]){
        schimba(p,p/2);
        p/=2;
    }
}

void adauga(int x){

    h[++nh]=x;
    urca(nh);
}

void sterge(int p){

    schimba(p,nh--);
    urca(p);
    coboara(p);
}

int main(){

    int i,n,a,tip,nr=0;

    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);

    scanf("%d",&n);

    for(i=1;i<=n;i++){

        scanf("%d",&tip);

        if(tip==1){

             scanf("%d",&v[++nr]);
             adauga(nr);
        }

        if(tip==2){

            scanf("%d",&a);
            sterge(poz[a]);
        }

        if(tip==3){

            printf("%d\n",v[h[1]]);
        }
    }

    return 0;
}
