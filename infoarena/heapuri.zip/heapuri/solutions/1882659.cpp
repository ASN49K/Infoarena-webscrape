#include <iostream>
#include <fstream>
#include <climits>
#define Nmax 200001

using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");

int n, v[Nmax];
int ord[Nmax];
int poz[Nmax];
int nr, s;

void inserare(int x, int k)
{
    v[k]=x;
    ord[k]=s;
    poz[ord[k]]=k;
    while(k>1 && v[k]<v[k/2])
    {
        swap(v[k], v[k/2]);
        swap(ord[k], ord[k/2]);
        swap(poz[ord[k]], poz[ord[k/2]]);
        k/=2;
    }
}
void stergere(int k)
{
    v[k]=v[nr];
    poz[ord[nr]]=k;
    //v[nr]=INT_MAX;
    nr--;
    while(k<=nr/2 && (v[k]>v[2*k] || v[k]>v[2*k+1]))
    {
        int ind;
        if(2*k+1>nr || v[2*k]<v[2*k+1])
            ind=2*k;
        else
            ind=2*k+1;
        if(v[k]>v[ind])
        {
            swap(v[k], v[ind]);
            swap(ord[k], ord[ind]);
            swap(poz[k], poz[ind]);
            k=ind;
        }
    }
}
int main()
{
    f>>n;
    nr=0; s=0;
    for(int i=1;i<=n;i++)
    {
        int x;
        f>>x;
        if(x==1)
        {
            f>>x;
            nr++;
            s++;
            inserare(x, nr);
        }
        else if(x==2)
        {
            f>>x;
            stergere(poz[x]);
        }
        else
        {
            g<<v[1]<<"\n";
        }
    }
    return 0;
}
