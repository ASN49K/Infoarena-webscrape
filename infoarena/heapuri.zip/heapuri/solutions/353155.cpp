#include<stdio.h>
#include<set>

using namespace std;

int n,i,x,y;
multiset<int> h;
int a[200003],m=0;

int main()
{
	freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);
	scanf("%d", &n);
	for(i=1;i<=n;i++)
	{
		scanf("%d", &x);
		if(x==3)
			printf("%d\n", *h.begin());
		else 
		{
			scanf("%d", &y);
			if(x==1)
			{
				h.insert(y);
				a[++m]=y;
			}
			else h.erase(a[y]);
		}
	}
	return 0;
}