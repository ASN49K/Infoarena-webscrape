#include<cstdio>
#include<algorithm>
#define infile "heapuri.in"
#define outfile "heapuri.out"
#define n_max 200010 
#define father(x) x>>1
#define left_son(x) x<<1
#define right_son(x) (x<<1) + 1
using namespace std;

int N,nr;
int h[n_max],in[n_max],poz[n_max];


void sift(int k)
{
	int son=k,l,r;
	
	l=left_son(k);
	r=right_son(k);
	
	if(l<=N && h[l]<h[k])
		son=l;
	
	if(r<=N && h[r]<h[son])
		son=r;
	
	if(son!=k)
	{
		swap(poz[h[k]],poz[h[son]]);
		swap(h[k],h[son]);
		sift(son);
	}
}


void percolate(int k)
{
	int key=h[k];
	
	while(k>1 && key < h[father(k)])
	{
		h[k] = h[father(k)];
		poz[h[k]]=k;
		k = father(k);
	}
	
	h[k] = key;
	poz[key]=k;
}

void insert(int k)
{
	h[++N]=k;
	
	in[++nr]=k;
	
	poz[k]=N;
	
	percolate(N);
}


void cut(int k)
{
	h[k]=h[N];
	poz[h[N--]]=k;
	
	if(k>1 && h[k] < h[father(k)])
		percolate(k);
	else
		sift(k);
}




int main()
{
	freopen(infile,"r",stdin);
    freopen(outfile,"w",stdout);
	
	int t,q,x;
	
	for(scanf("%d",&t);t;t--)
	{
		scanf("%d",&q);
		if(q<3)
		{
			scanf("%d",&x);
			if(q==1)
				insert(x);
			else 
				cut(poz[in[x]]);
		}
		else
			printf("%d\n",h[1]);
	}
	
	return 0;
}