#include <vector>
#include <iostream>
#include <fstream>

#define MINUS_INF -99999;
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int id = 0;
int order[200001];

struct elem
{
	int info, nr_ord;
};

class MinHeap{
private:
	int size;
	elem elements[200001];

public:
	MinHeap(){size=0;};
	int left(int index){return 2*index+1;};
  	int right(int index){return 2*index+2;};
  	int parent(int index){return (index-1)/2;};
	int get_size(){return size;};
	void shrink(){size=size-1;};
	void expand(){size=size+1;};
	int top(){return elements[0].info;}; 
	int pop();
	void push(int param);
	void delete_at(int index);
	void bubble_up(int param);
	void bubble_down();
};

void MinHeap::push(int param)
{
	elem b;
	b.info = param;
	b.nr_ord=id++;
	this->elements[size] = b;
	this->expand();
	this->bubble_up(size-1);
}

int MinHeap::pop()
{
	int ex_top = this->elements[0].info;
	this->elements[0].info = this->elements[size-1].info;
	this->elements[0].nr_ord = this->elements[size-1].nr_ord;
	order[elements[0].nr_ord] = 0;
	this->shrink();
	bubble_down();
	return ex_top;
}

void MinHeap::delete_at(int index)
{
	elements[index].info = MINUS_INF;
	bubble_up(index);
	pop();
}

void MinHeap::bubble_up(int param)
{
	int index = param;
	while (index!=0 && elements[index].info < elements[parent(index)].info)
	{
		swap(order[elements[index].nr_ord], order[elements[parent(index)].nr_ord]);
		swap(elements[index].info, elements[parent(index)].info);
		swap(elements[index].nr_ord, elements[parent(index)].nr_ord);
		index = parent(index);
	}
}

void MinHeap::bubble_down()
{
	int index = 0;
	int lesser_index;
	while (left(index) < size)
	{
		lesser_index = left(index);
		if (right(index) < size && elements[right(index)].info < elements[left(index)].info)
			lesser_index = right(index);
		if (elements[lesser_index].info > elements[index].info)
			return;
		swap(order[elements[lesser_index].nr_ord], order[elements[index].nr_ord]);
		swap(elements[lesser_index].info, elements[index].info);
		swap(elements[lesser_index].nr_ord, elements[index].nr_ord);
		index = lesser_index;
	}
}

int main()
{
	MinHeap h;
	int elem, operation;
	int nr_lines,x;
	f>>nr_lines;
	while(nr_lines--)
	{
		f>>operation;
		if (operation == 1)
		{
			f>>elem;
			order[id] = id;
			h.push(elem);
		}
		else if (operation == 2)
		{
			f>>x;
			h.delete_at(order[x-1]);
		}
		else if (operation == 3)
		{
			g<<h.top()<<"\n";
		}
	}
	return 0;	
}
