#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

int A[200001], Heap[200001], Pos[200001], heapsize=0, insrt=0;

void push(int i) {
	while(i>1 && A[Heap[i]]<A[Heap[i/2]]) {
		swap(Heap[i], Heap[i/2]);
		Pos[Heap[i]] = i;
		Pos[Heap[i]] = i/2;
		i/=2;
	}
}

void pop(int i) {
	int l=2*i, r=2*i+1, smallest = i;
	do {
		i = smallest;
		if(A[Heap[smallest]]<A[Heap[l]]) smallest = l;
		if(A[Heap[smallest]]<A[Heap[r]]) smallest = r;
		swap(Heap[i], Heap[smallest]);
		Pos[Heap[i]] = i;
		Pos[Heap[smallest]] = smallest;
	}while(smallest != i);
}

int main() {
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);
	int n;
	scanf("%d ", &n);
	while(n--) {
	 int nr;
	 scanf("%d ", &nr);
	 if(nr == 1) {
	    int x;
	    scanf("%d ", &x);
	    A[++insrt] = x;
		Heap[++heapsize] = insrt;
		Pos[insrt] = heapsize;
		push(heapsize);
	 }
	 if(nr == 2) {
	    int x;
	    scanf("%d ", &x);
		int i = Pos[x];
		A[x] = 1e9+1;
		pop(i);
	 }
	 if(nr == 3) {
	    printf("%d\n", A[Heap[1]]);    
	 }
	}
	return 0;
}