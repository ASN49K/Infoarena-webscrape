#include <iostream>
#include <fstream>
#define dim 200000
using namespace std;

ifstream f ("heapuri.in");
ofstream g ("heapuri.out");

int vec[dim],lung,heap[dim],poz[dim],nr;

void muta_sus(int pozz)
{
    if(pozz == 1)
        return;
    if(vec[heap[pozz / 2]] > vec[heap[pozz]])
        swap(heap[pozz / 2],heap[pozz]),swap(poz[heap[pozz / 2]],poz[heap[pozz]]),muta_sus(pozz / 2);
}

void muta_jos(int pozz)
{
    int x;
    while(x != pozz)
    {
        x = pozz;
        if(2*pozz <= lung && vec[heap[pozz]] > vec[heap[2*pozz]])
            pozz *= 2;
        if(2*x + 1 <= lung && vec[heap[pozz]] > vec[heap[2*x + 1]])
             pozz = x * 2 + 1;

        swap(heap[pozz],heap[x]);
        swap(poz[heap[pozz]],poz[heap[x]]);
    }
}

int main()
{
    int n,caz,x;
    f >> n;
    while(n)
    {
        f >> caz;
        switch(caz)
        {
        case 1:
            f >> x;
            vec[++nr] = x;
            heap[++lung] = nr;
            poz[nr] = lung;
            muta_sus(lung);
            break;
        case 2:
            f >> x;
            vec[x] = -1;
            muta_sus(poz[x]);
            poz[heap[lung]] = 1;
            swap(heap[lung],heap[1]);
            lung--;
            if(lung > 1)
                muta_jos(1);
            break;
        default:
            g << vec[heap[1]] << '\n';
            break;
        }
        n--;
    }
    return 0;
}
