#include <stdio.h>
#define DIM 200005

int c[DIM], h[DIM], poz[DIM];
int n,m,l;

void swap(int &x, int &y)
{
	int tmp=x;
	x=y;
	y=tmp;
}

void upheap(int nod)
{
	if (nod<=1) return;
	if (c[h[nod]]<c[h[nod/2]])
		{
			swap(poz[h[nod]],poz[h[nod/2]]);
			swap(h[nod],h[nod/2]);
            upheap(nod/2);
		}
}

void downheap(int nod)
{
	int min=nod;
	if (DIM>=2*nod) if (c[h[nod*2]]<c[h[nod]]) min=nod*2;
	if (DIM>=2*nod+1) if (c[h[nod*2+1]]<c[h[nod*2+1]]) min=nod*2+1;
	if (min!=nod)
		{
			swap(h[nod],h[min]);
			swap(poz[h[nod]],poz[h[min]]);
            downheap(min);
		}
}

int main()
{
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	int i,p,car;
    l=0;
	scanf("%d",&m);
	for (i=1; i<=m; ++i)
		{
			scanf("%d",&car);
			if (car==1)
				{
					scanf("%d",&p);
					c[++n]=p;
					poz[h[++l]=n]=l;
					upheap(1);
				}
			else if (car==2)
				{
					scanf("%d",&p);
					h[poz[p]]=h[l--];
					poz[h[poz[p]]]=poz[p];
					if (poz[p]>l && c[h[poz[p]]],c[h[poz[p]/2]])
						upheap(poz[p]);
					else downheap(poz[p]);
				}
			else printf("%d",c[h[1]]);
		}
return(0);
}