#include<fstream>
#include<queue>
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
priority_queue< int,vector<int>,greater<int> > q;
int v[200001],viz[200001],i,type,x,poz,n;
int main()
{
    fin>>n;
    for(i=1;i<=n;++i)
    {
        fin>>type;
        switch(type)
        {
        case 1:
            fin>>x;
            q.push(x);
            v[++poz]=x;
            viz[x]=1;
            continue;
        case 2:
            fin>>x;
            viz[v[x]]=0;
            continue;
        case 3:
            while(!viz[q.top()])
                q.pop();
            fout<<q.top()<<'\n';
            continue;
        }
    }
    return 0;
}
