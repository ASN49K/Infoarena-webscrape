#include <fstream>
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");
struct elem
{
    int inf;
    int nr;
}H[200005];
int poz[200005],n,nr,t,x,nrintr;

void inserare(long inf)
{
    long fiu,tata;
    fiu=++n;
    tata=fiu/2;
    while (tata>0 && H[tata].inf>inf)
    {
        poz[H[tata].nr]=fiu;
        H[fiu]=H[tata];
        fiu=tata;
        tata=fiu/2;
    }
    H[fiu].inf=inf;
    H[fiu].nr=nrintr;
    poz[nrintr]=fiu;
}
void combinare(int i)
{
    int inf=H[i].inf,nr=H[i].nr,tata=i,fiu=2*i;
    while (fiu<=n)
    {
        if (fiu+1<=n && H[fiu].inf>H[fiu+1].inf)
            fiu++;
        if (H[fiu].inf<inf)
        {
            poz[H[fiu].nr]=tata;
            H[tata]=H[fiu];
            tata=fiu;
            fiu=2*tata;
        }
        else
            break;
    }
    H[tata].inf=inf;
    H[tata].nr=nr;
    poz[nr]=tata;
}

int main()
{
    f>>nr;

    for (int i=1;i<=nr;i++)
    {
        f>>t;
        if (t==1)
        {
            nrintr++;
            f>>x;
            inserare(x);
        }
        else if (t==2)
        {
            f>>x;
            H[poz[x]]=H[n];
            n--;
            combinare(poz[x]);
        }
        else if (t==3)
            g<<H[1].inf<<'\n';
    }


    return 0;
}
