#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;

#define NMAX 200005

int Heap[NMAX], Pos[NMAX], A[NMAX];
int SzHeap = 0, SzArray = 0;

int getParent(int i)
{
	return (i - 1) / 2; 
}

int getLeft(int i)
{
	return 2 * i + 1;
}

int getRight(int i)
{
	return 2 * i + 2;
}

int getMin()
{
	return A[Heap[0]];
}

int getSize()
{
	return SzHeap;
}

void up(int i)
{
	int pos = i;
	while(pos != 0 && A[Heap[pos]] < A[Heap[getParent(pos)]])	
	{
		swap(Heap[pos], Heap[getParent(pos)]);
		Pos[Heap[pos]] = pos;
		Pos[Heap[getParent(pos)]] = getParent(pos); 
		pos = getParent(pos);
	}
}

void down(int i)
{
	int pos = i;
	int option;
	int val;

	do
	{
		option = -1;
		val = Heap[pos];
		if(getLeft(pos) < SzHeap && val > Heap[getLeft(pos)])
		{
			option = getLeft(pos);
			val = Heap[getLeft(pos)];		
		}
		if(getRight(pos) < SzHeap && val > Heap[getRight(pos)])
		{
			option = getRight(pos);
			val = Heap[getRight(pos)];	
		}
		if(option != -1)
		{
			swap(Heap[pos], Heap[option]);
			Pos[Heap[pos]] = pos;
			Pos[Heap[option]] = option;
			pos = option;
		}
	}
	while(option != -1);
}

void cut(int x)
{
	int pos = Pos[x];
	A[x] = 0xFFFFFF;
	Pos[x] = -1;
	
	//cout << pos;
	
	Heap[pos] = Heap[SzHeap - 1];
	SzHeap--;
	Pos[Heap[pos]] = pos;
	
	if(pos != 0 && A[Heap[pos]] < A[Heap[getParent(pos)]])
		up(pos);
	else
		down(pos);
}

int main()
{	
	int N;
	ifstream in("heapuri.in");
	ofstream out("heapuri.out");
	in >> N;
	for(int i = 0; i < N; ++i)
	{
		int code;
		in >> code;
		switch(code)
		{
			case 1:
				int el;
				in >> el;
				A[SzArray]   = el;
				Heap[SzHeap] = SzArray;
				Pos[SzArray] = SzHeap;
				SzHeap++;
				SzArray++;
				up(SzHeap-1);
				break;
			case 2:
				int x;
				in >> x;
				cut(x-1);
				break;
			case 3:
				out << getMin() << endl;
				break;
			default:
				break;
		}
	}
	return 0;
}
