#include<bits/stdc++.h>
 
using namespace std;
 
ifstream f("heapuri.in");
ofstream g("heapuri.out");
 
const int n_MAX = 2e5 + 5;
 
int n, op, x;
int v[n_MAX], cnt;
 
multiset < int > a;
 
int main(){
 
    f >> n;
    for (int i = 1; i <= n; i++) {
        f >> op;
        switch(op) {
            case 1:
                f >> x;
                v[++cnt] = x;
                a.insert(x);
                break;
            case 2:
                f >> x;
                a.erase(v[x]);
                break;
            default:
                g << *a.begin() << "\n";
 
        }
 
    }
    return 0;
}