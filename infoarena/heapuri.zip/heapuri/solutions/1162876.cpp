#include<cstdio>
#include<algorithm>
using namespace std;
const int nmax = 200005;
const int inf = 1<<30;
int n,i,j,v[nmax],h[nmax],poz[nmax],cnt,p;
void heapup(int x)
{
    if(x==1) return;
    int f=x/2;
    if(v[h[x]]<v[h[f]])
    {
        swap(h[x],h[f]);
        swap(poz[h[x]],poz[h[f]]);
        heapup(f);
    }
}
void heapdown(int x)
{
    int s=x*2;
    if(s>cnt) return;
    if(s<cnt && v[h[s]]>v[h[s+1]]) s++;
    if(v[h[x]]>v[h[s]])
    {
        swap(h[x],h[s]);
        swap(poz[h[x]],poz[h[s]]);
        heapdown(s);
    }
}
int main()
{
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	scanf("%d",&n);
	for(;n;n--)
	{
	    scanf("%d",&i);
	    if(i==1)
	    {
	        j++;
	        scanf("%d",&v[j]);
	        h[++cnt]=j;
	        poz[j]=cnt;
	        heapup(cnt);
	    }
	    else if(i==2)
	    {
	        scanf("%d",&p);
	        poz[h[cnt]]=poz[p];
	        h[poz[p]]=h[cnt];
	        cnt--;
	        heapdown(poz[p]);
	        heapup(poz[p]);
	    }
	    else printf("%d\n",v[h[1]]);
	}
	return 0;
}
