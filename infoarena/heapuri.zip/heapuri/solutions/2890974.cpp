#include <bits/stdc++.h>
#define S 200001
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int poz[S], order[S], m=0;

int left_son(int nod)
{
    return 2*nod;
}
int right_son(int nod)
{
    return 2*nod+1;
}
int father(int nod)
{
    return nod/2;
}
int min(int H[], int n)
{
  if(n==0)
    return -1;
  else
    return H[1];
}
void sift(int H[], int n, int nod)
{
    int son = 1;
    while(son)
    {
        son=0;
        if(left_son(nod)<=n)
        {
            son=left_son(nod);
            if(right_son(nod)<=n && H[left_son(nod)]>H[right_son(nod)])
                son=right_son(nod);
        }

        if(H[nod] <= H[son])
            son=0;
        if(son)
        {
          swap(H[nod], H[son]);
          poz[H[nod]]=nod;
          poz[H[son]]=son;
          nod = son;
        }
    }
}
void percolate(int H[], int n, int nod)
{

    while(nod>1 && H[nod]<H[father(nod)])
    {
        swap(H[nod], H[father(nod)]);
        poz[H[nod]]=nod;
        poz[H[father(nod)]]=father(nod);
        nod = father(nod);
    }
}
void heapify(int H[], int n)
{
    for(int i=n/2; i>=1; i--)
      sift(H, n, i);
}
void insert(int H[], int &n, int x)
{
  n++;
  H[n]=x;
  poz[H[n]]=n;
  percolate(H, n, n);
}
void remove(int H[], int &n, int nod)
{
  if(n==0)
    return;
  H[nod]=H[n];
  poz[H[n]]=nod;
  n--;
  if(nod>1 && H[nod]>H[father(nod)])
    percolate(H, n, nod);
  else
    sift(H, n, nod);
}
void stergere(int H[], int &n, int nr)
{
  remove(H, n, poz[order[nr]]);
}
void heapsort(int H[], int n)
{
  heapify(H, n);
  for(int i=n; i>=2; i--)
  {
    swap(H[1], H[i]);
    sift(H, i-1, 1);
  }
}

int main()
{
  int H[S], n=0, t;
  fin>>t;

  for(int i=0; i<t; i++)
  {
    int cod, x;
    fin>>cod;
    if(cod==3)
      fout<<min(H, n)<<'\n';
    if(cod==2)
      {
        fin>>x;
        stergere(H, n, x);
      }
    if(cod==1)
      {
        fin>>x;
        order[++m]=x;
        insert(H, n, x);
      }
  }

}
