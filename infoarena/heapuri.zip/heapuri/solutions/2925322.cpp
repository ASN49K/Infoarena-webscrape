#include<fstream>
using namespace std;
ifstream fin("inv.in");
ofstream fout("inv.out");
int n,i,v[100010],a[100010],sol;

int query(int p) {
    int s=0;
    for(int i=p;i;i-=(i&-i))
        s+=a[i];
    return s;
}

void update(int p) {
    for(int i=p;i<=n;i+=(i&-i))
        a[i]++;
}

int main () {
    fin>>n;
    sol=n*(n-1)/2;
    for(i=1;i<=n;i++)
        fin>>v[i];
    for(i=1;i<=n;i++){
        sol-=query(v[i]-1);
        sol%=9917;
        update(v[i]);
    }
    fout<<sol%9917;

    return 0;
}

