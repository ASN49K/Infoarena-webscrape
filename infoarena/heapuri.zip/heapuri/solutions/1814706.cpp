#include <cstdio>
#include <algorithm>
#include <iostream>

using namespace std;
int h[200001],hh[200001];
int ind[200001];
void adauga (int x,int elem){
    int p,c,aux;
    if (elem==2)
        printf ("a");
    h[elem]=x;
    hh[elem]=elem;
    ind[elem]=elem;
    c=elem;
    p=elem/2;
    while (p>0){
        if (h[c]<h[p]){
            aux=h[c];
            h[c]=h[p];
            h[p]=aux;
            aux=hh[p];
            hh[p]=hh[c];
            hh[c]=aux;
            ind[hh[p]]=p;
            ind[hh[c]]=c;
        }
        else break;
        c=p;
        p/=2;
    }
}
void sterge (int poz,int elem){
    int p,c,aux;
    p=poz;
    c=2*poz;
    while (c<=elem){
        if (c+1<=elem && h[c+1]<h[c])
            c++;
        aux=h[c];
        h[c]=h[p];
        h[p]=aux;
        aux=hh[p];
        hh[p]=hh[c];
        hh[c]=aux;
        ind[hh[p]]=p;
        ind[hh[c]]=c;
        p=c;
        c*=2;
    }
}
int main()
{
    FILE *fin=fopen ("heapuri.in","r");
    FILE *fout=fopen ("heapuri.out","w");
    int n,elem,i,cer,x,poz;
    fscanf (fin,"%d",&n);
    elem=0;
    for (i=1;i<=n;i++){
        fscanf (fin,"%d",&cer);
        if (cer==3)
            fprintf (fout,"%d\n",h[1]);
        // ind= pozitia in hh a elem inserat al i-lea
        // in h tii minte elem dupa valori
        // hh[i]= al catelea elem inserat a fost h[i]
        else if (cer==2){
            fscanf (fin,"%d",&x);
            poz=ind[x];
            sterge (poz,elem);
            elem--;
        }
        else {
            elem++;
            fscanf (fin,"%d",&x);
            adauga (x,elem);
        }
    }
    return 0;
}
