#include <bits/stdc++.h>
#define Dim 200008
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int N,op,x,cnt;
int How[Dim];

set < pair<int,int> > S;
set < pair<int,int> > ::iterator it;

int main()
{
    f>>N;
    for(int i=1;i<=N;i++)
    {
        f>>op;

        if(op==1)
        {
            cnt++;
            f>>x;
            How[cnt]=x;
            S.insert({x,cnt});


        }
        else
        if(op==2)
        {
            f>>x;
            it=S.find({How[x],x});
            S.erase(it);
        }
        else
        {
            it=S.begin();
            g<<it->first<<'\n';
        }
    }
    return 0;
}
