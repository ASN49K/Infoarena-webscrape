#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int h[200000],v[200000],a[200000];
int n,nh,nv,i,c,x,r;
void urcare(int p)
{
    int aux;
    while(p>=2 && v[h[p/2]]>v[h[p]])
    {
        aux=h[p];
        h[p]=h[p/2];
        h[p/2]=aux;
        p=p/2;
    }
}
void coborare(int p,int nh)
{
    int aux;
    while(p*2<=nh)
    {
        r=p*2;
        if(r+1<=nh && v[h[r+1]]<v[h[r]])
        {
            r=r+1;
        }
        if(v[h[p]]>v[h[r]])
        {
            aux=h[r];
            h[r]=h[p];
            h[p]=aux;
            p=r;
        }
        else
        {
            break;
        }
    }
}
int main()
{
    fin>>n;
    nv=0;
    nh=0;
    for(i=1;i<=n;i++)
    {
        fin>>c;
        if(c==1)
        {
            fin>>x;
            nv++;
            v[nv]=x;
            a[nv]=0;
            nh++;
            h[nh]=nv;
            urcare(nh);
        }
        if(c==2)
        {
            fin>>x;
            a[x]=1;
        }
        if(c==3)
        {
            while(a[h[1]]==1)
            {
                h[1]=h[nh];
                nh--;
                coborare(1,nh);
            }
            fout<<v[h[1]]<<'\n';
        }
    }
    return 0;
}
