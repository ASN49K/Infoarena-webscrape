#include <set>
#include <stdio.h>

using namespace std;

set<int> heap;
int i,n,c,x,v[200002];

int main()
{
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);

	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&c);
		switch(c)
		{
			case 1:
				scanf("%d",&x);
				v[++v[0]]=x;
				heap.insert(x);
				break;
			case 2:
				scanf("%d",&x);
				heap.erase(v[x]);
				break;
			case 3:
				printf("%d\n",*heap.begin());
				break;
		}
	}
	return 0;
}
