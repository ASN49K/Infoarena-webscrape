#include <fstream>
#include <bits/stdc++.h>
#include <cstring>
#include <stack>
#include <vector>
#include <unordered_map>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

/*
Heap cu pozitii
-> trb vector sa stiu elementele
-> trb sa am un vector unde tin pozitile din heap pt stergere ??
*/

int N, op, x, L = 0, nr = 0;
int H[200010], elem[200010], H_poz[200010];
/// elements = 6 7 3 1 2
/// H = 3 4 0 1 2 (i suppose)
/// H_poz = 2 3 4 0 1 (i suppose)
/// push(6)
/// H = 0 => elem[0] = minim
/// H_poz = 0 => elements[0] este in H pe poz 0
/// push(7)
/// H = 0 1 => elem[0] -> st: elem[1]
/// H_poz = 0 1  => elem[1] este in H pe poz 1
/// push(3)
/// H = 2 1 0 => elem[2] -> st: elem[1], dr: elem[0]
/// H_poz = 2 1 0  => elem[2] este in H pe poz 0 => elem[H_poz[H[0]] = 3
/// push(1)
/// H = 3 2 0 1 => elem[3] -> st: elem[2], dr: elem[0]
///                 elem[2] -> st: elem[1]
/// H_poz = 2 3 1 0 => elem[0] este in H pe poz 2
///                    elem[1] este in H pe poz 3
///                    elem[2] este in H pe poz 1
/// push(2)
/// H = 3 4 0 1 2 => elem[3] -> st: elem[4], dr: elem[0]
///                 elem[4] -> st: elem[1], dr: elem[2]
/// H_poz = 2 3 4 0 1 => elem[0] este in H pe poz 2
///                    elem[1] este in H pe poz 3
///                    elem[2] este in H pe poz 4
///                    elem[3] este in H pe poz 0
///

void urca(int poz)
{
    if (poz > 0)
    {
        int tata = (poz - 1)/2;
        if (elem[H[tata]] > elem[H[poz]])
        {
            swap(H[tata], H[poz]);
            swap(H_poz[H[poz]], H_poz[H[tata]]);
            urca(tata);
        }
    }
}

void coboara(int poz)
{
    int st = poz * 2 + 1;
    int dr = poz * 2 + 2;
    int small = poz;
    if (st < L - 1 && elem[H[st]] < elem[H[small]])
        small = st;
    if (dr < L - 1 && elem[H[dr]] < elem[H[small]])
        small = dr;
    if (small != poz)
    {
        swap(H[poz], H[small]);
        swap(H_poz[H[poz]], H_poz[H[small]]);
        coboara(small);
    }
}

void push(int x)
{
    H[L] = x;
    H_poz[H[L]] = L;
    urca(L);
    L ++;
}

int peek()
{
    return elem[H[0]];
}

void pop(int poz)
{
    int poz_to_pop = H_poz[poz];
    swap(H[poz_to_pop], H[L - 1]);
    swap(H_poz[H[poz_to_pop]], H_poz[H[L - 1]]);
    L--;
    coboara(poz_to_pop);
}


int main()
{
    fin >> N;
    for (int i = 0; i < N; ++i)
    {
        fin >> op;
        switch(op)
        {
        case 1:
            {
                fin >> x;
                elem[nr] = x;
                push(nr);
                nr ++;
                break;
            }
        case 2:
            {
                fin >> x;
                pop(x - 1);
                break;
            }
        case 3:
            {
                fout << peek() << "\n";
                break;
            }
        }
    }
    return 0;
}
