#include <stdio.h>
int h[200001],n,i,x,t,poz[200001],nr,a[200001];
int perc(int x)
{
    int tata,aux;
    while (x>1)
    {
    tata=x/2;
    if (a[h[tata]]>a[h[x]])
    {

        aux=h[tata];
        h[tata]=h[x];
        h[x]=aux;
        poz[h[tata]]=tata;
        poz[h[x]]=x;
        x=tata;

    }
    else x=1;
    }
    return 0;
}
int sift(int x)
{
    int f1,f2,min,aux;
    while (2*x<=nr)
    {
        f1=2*x;
        f2=2*x+1;
        min=f1;
        if (f2<=n && a[h[min]]>a[h[f2]]) min=f2;
        if (a[h[min]]<a[h[x]])
        {

            aux=h[min];
            h[min]=h[x];
            h[x]=aux;
            poz[h[x]]=x;
            poz[h[min]]=min;
            x=min;

        }
        else x=nr;
    }
    return 0;
}
int main(void)
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    int j=1;
    for (i=1;i<=n;i++)
    {
        scanf("%d",&t);
        if (t==3)
            {printf("%d\n",a[h[1]]);continue;}
        scanf("%d",&x);
        if (t==1)
        {
            a[j]=x;
            h[++nr]=j;
            poz[j]=nr;
            j++;
            perc(nr);
            continue;
        }
        a[x]=-1;
        perc(poz[x]);
        poz[h[1]]=0;
        h[1]=h[nr--];
        poz[h[1]]=1;
        nr--;
        if (nr>1)
        sift(1);


    }
    return 0;
}
