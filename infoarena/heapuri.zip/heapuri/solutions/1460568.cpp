#include<fstream>
using namespace std;
int n, i, op, x, nr, nrh, s, p1, aux, a[200003], h[200003], p[200003];
//a[i] val elementul intrat al i-lea
//h[i] pozitia din a elementului de pe pozitia i din heap
//p[i] pe ce pozitie se afla in heap elementul de pe pzitia i din a
ifstream in("heapuri.in");
ofstream out("heapuri.out");
int main(){
    in>>n;



    for(i=1; i<=n; i++){
        in>>op;
        if(op==3)
            out<<a[h[1]]<<"\n";
        if(op==1){
            in>>x;
            a[++nr]=x;
            h[++nrh]=nr;
            p[nr]=nrh;
            s = nrh;
            p1 = nrh/2;
            while(p1 != 0 && a[h[s]]<a[h[p1]]){
                aux=h[s];
                h[s]=h[p1];
                h[p1]=aux;
                p[h[s]]=s;
                p[h[p1]]=p1;
                s=p1;
                p1/=2;
            }
        }
        if(op==2){
            in>>x;
            s=p[x];
            p1=s/2;
            a[x]=-1;
            while(p1!=0 && a[h[s]]<a[h[p1]]){
                aux=h[s];
                h[s]=h[p1];
                h[p1]=aux;
                p[h[s]]=s;
                p[h[p1]]=p1;
                s=p1;
                p1/=2;
            }
            h[1] = h[nrh];
            nrh--;
            p[ h[1] ] = 1;
            p1=1;
            s=2*p1;
            while(s<=nrh){
                if(s+1 <=nrh && a[h[s]]>a[h[s+1]])
                    s++;
                if (a[h[p1]]>a[h[s]]) {
                    aux=h[s];
                    h[s]=h[p1];
                    h[p1]=aux;
                    p[h[s]]=s;
                    p[h[p1]]=p1;
                    p1=s;
                    s*=2;
                } else
                    break;
            }
        }
    }

return 0;
}
