#include <stdio.h>
#include <set>
using namespace std;
FILE*f=fopen("heapuri.in","r");
FILE*g=fopen("heapuri.out","w");
set <int> h;
int k,v[200001],i,x,a,n;
int main()
{
fscanf(f,"%d",&n);
for(i=1;i<=n;i++){
    fscanf(f,"%d",&a);
    if(a==1){
fscanf(f,"%d",&x);
        h.insert(x);
    v[++k]=x;
    }
    else if(a==2){
fscanf(f,"%d",&x);
    h.erase(v[x]);


    }
    else{
        fprintf(g,"%d\n",*h.begin());
    }

}





    return 0;
}
