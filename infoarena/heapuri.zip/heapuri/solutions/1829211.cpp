#include<iostream>
#include<fstream>
#include<algorithm>
#include<set>
#include<climits>
#include<cstring>
#include<map>
#include<queue>
#include<vector>
#include<bitset>
#define mp make_pair
#define pb push_back
#define ff(i, x, n) for (int i = x; i <= n; ++i)
#define dd(i) cout << i <<'\n'
	#define READ_FROM_FILE
using namespace std;
void upheap(int i);
void downheap(int i);
int uh, u, poz[200005];
pair <int, int> h[200005];
#define cout out
int main(){
	#ifdef READ_FROM_FILE
		ifstream in("heapuri.in");
		#define cin in
	#endif
	ofstream out("heapuri.out");
	int n, c, x;
	cin >> n;
	while (n--) {
		cin >> c;
		if (c == 1) {
			cin >> x;
			h[++uh] = mp(x, ++u);
			poz[u] = uh;
			upheap(uh);
		}
		if (c == 3) {
			cout << h[1].first << '\n';
		}
		if (c == 2) {
			cin >> x;
			h[poz[x]].first = 1000000001;
			downheap(poz[x]);
		}
		/*ff(i, 1, uh) {
			cout << h[i].first << ' ';
		}
		dd('\n');*/
	}
}
void upheap(int i) {
	while (h[i].first < h[i >> 1].first && i > 1) {
		swap(h[i], h[i >> 1]);
		swap(poz[h[i].second], poz[h[i >> 1].second]);
		i >>= 1;
	}
}
void downheap(int i) {
	char go = 1;
	while (go) {
		go = 0;
		while ((i << 1) <= uh && h[i].first > h[i << 1].first) {
			swap(h[i], h[i << 1]);
			swap(poz[h[i].second], poz[h[i << 1].second]);
			i <<= 1;
			go = 1;
		}
		while ((i << 1) + 1 <= uh && h[i].first > h[(i << 1) + 1].first) {
			swap(h[i], h[(i << 1) + 1]);
			swap(poz[h[i].second], poz[h[(i << 1) + 1].second]);
			i <<= 1, ++i;
			go = 1;
		}
	}
}
