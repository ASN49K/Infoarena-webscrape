/**
  *  Worg
  */
#include <set>
#include <cstdio>

FILE *fin = freopen("heapuri.in", "r", stdin); FILE *fout = freopen("heapuri.out", "w", stdout);

const int MAX_N = 2e5 + 5;

std::multiset<int > heap;

int entryCount;
int entry[MAX_N];

int main() {
  int n; scanf("%d", &n);

  for(int i = 1; i <= n; i++) {
    int type; scanf("%d", &type);

    if(type == 1) {
      int x; scanf("%d", &x);
      entry[++entryCount] = x; heap.insert(x);
    } else if(type == 2) {
      int x; scanf("%d", &x);
      heap.erase(heap.find(entry[x]));
    } else {
      printf("%d\n", *heap.begin());
    }
  }
  
  return 0;
}