#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
long long n, b, a, k;
unordered_map<int, int> m;
vector<int> v;
priority_queue<pair<int, int>> p;
int main(){
    in>>n;
    for(int i=0;i<n;++i){
        in>>a;
        if(a==1){
            in>>b;
            p.push(make_pair(-b, ++k));
        }
        else if(a==2){
            in>>b;
            m[b]++;
        }
        else{
            b=p.top().second;
            while(m[b]!=0){
                m[b]--;
                p.pop();
                b=p.top().second;
            }
            out<<-p.top().first<<endl;
        }
    }
    return 0;
}
