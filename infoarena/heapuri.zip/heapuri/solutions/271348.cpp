#include<stdio.h>
#define max 200010
long h[max], a[max], poz[max], n, m;
FILE *f, *g;

void ins(long x)
{       long k, z;
	h[++n]=x;
	k=n;
	while(a[h[k/2]]>a[h[k]] && k>1)
	{      	z=h[k]; h[k]=h[k/2]; h[k/2]=z;
		poz[h[k]]=k; poz[h[k/2]]=k/2;
		k=k/2;
	}

}

void del(long k)
{       long z, m;
	k=poz[k];
	z=h[k]; h[k]=h[n]; h[n]=z;
	poz[h[k]]=k;
	n--;
	while(( (a[h[2*k]]<a[h[k]] && 2*k<=n) ||
		(a[h[2*k+1]]<a[h[k]] && 2*k+1<=n) )	&& k<n)
	{       if(2*k==n)				m=2*k;
		else	if(a[h[2*k]]<a[h[2*k+1]])	m=2*k;
			else				m=2*k+1;
		z=h[m]; h[m]=h[k]; h[k]=z;
		poz[h[m]]=m;
		poz[h[k]]=k;
		k=m;
	}
}


int main()
{       long i, x, y, o;
	f=fopen("heapuri.in", "r");
	g=fopen("heapuri.out", "w");
	o=0;
	fscanf(f, "%ld", &m);
	for(i=1; i<=m; i++)
	{	fscanf(f, "%ld", &x);
		if(x==3)
			fprintf(g, "%ld\n", a[h[1]]);
		else
		{	fscanf(f, "%ld", &y);
			if(x==1)
			{       a[++o]=y;
				poz[o]=n+1;
				ins(o);
			}
			else
			{
				del(y);
			}
		}
	}
	return 0;
}
