#include<stdio.h>
#define N 200005
FILE *f=fopen("heapuri.in","r"), *g=fopen("heapuri.out","w");
int v[N], h[N], poz[N], n, t;


void swap(int a,int b)
{	
	h[poz[a]]=h[poz[a]]^h[poz[b]];
	h[poz[b]]=h[poz[a]]^h[poz[b]];
	h[poz[a]]=h[poz[a]]^h[poz[b]];
	
	poz[a]=poz[a]^poz[b];
	poz[b]=poz[a]^poz[b];
	poz[a]=poz[a]^poz[b];	
}
int father(int k)
{
	return k/2;
}
int left_son(int k)
{
	return 2*k;
}
int right_son(int k)
{
	return 2*k+1;
}

void sift(int n, int k)
{
	int son=0, pozi=k, aux, sw=0;
	do
	{
		if(left_son(k)<=n) son = left_son(k);
		if( right_son(k) <= n && v[poz[right_son(k)]] < v[poz[left_son(k)]])
			son=right_son(k);
		if(v[poz[son]] > v[poz[k]])
			son=0;
		if(son)
		{
			sw=true;
			swap(k, son);			
		}
		k=son;
	}while(son);	
	
	//if(sw)	poz[pozi]=k;
}

void percolate (int n, int k)
{
	int val=v[k], pozi=k;
	while( val < v[poz[father(k)]] && k>1)
	{
		swap(k, father(k));
		k=father(k);
	}
	
	//poz[pozi]=k;	
}

void add(int val)
{
	v[++n]=val;
	h[n]=n;
	poz[n]=n;
	percolate(n, n);	
}

void delet(int k)
{
	//poz[k]=0;
	//k=poz[k];
	
	
	h[poz[n]]=h[k];
	poz[h[k]]=poz[n];
	n--;
	
	
	if( v[poz[h[k]]] < v[poz[h[father(k)]]] )
		percolate(n, h[k]);
	else 
		sift(n, h[k]);
}

int main()
{
	int x,y;
	fscanf(f,"%d", &t);
	for(int i=1;i<=t;i++)
	{
		fscanf(f,"%d", &x);
		if(x==1)
		{
			fscanf(f,"%d", &y);
			add(y);
		}
		else 
		if(x==2)  
		{
			fscanf(f,"%d", &y);
			delet(y);
		}
		else 
			fprintf(g,"%d\n", v[poz[1]]);
	}
	return 0;
}