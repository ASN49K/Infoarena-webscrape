# include <fstream>
# define DIM 200010
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int v[DIM],h[DIM],poz[DIM],n,k,q,r,op,x;
void add(){
    h[++n]=k;
    poz[k]=n;
    int c=n,p=c/2;
    while(p!=0)
        if(v[h[c]]<v[h[p]]){
            swap(h[c],h[p]);
            poz[h[c]]=c;
            poz[h[p]]=p;
            c=p;
            p/=2;
        }
        else
            break;
}
void erase(int Poz){
    h[Poz]=h[n--];
    poz[h[Poz]]=Poz;
    int p=Poz,c=2*p;
    while(c<=n){
        if(c<n&&v[h[c]]>v[h[c+1]])
            c++;
        if(v[h[c]]<v[h[p]]){
            swap(h[c],h[p]);
            poz[h[c]]=c;
            poz[h[p]]=p;
            p=c;
            c*=2;
        }
        else
            break;
    }
}
int main () {
    fin>>q;
    for(r=1;r<=q;r++){
        fin>>op;
        if(op==3){
            fout<<v[h[1]]<<"\n";
            continue;
        }
        fin>>x;
        if(op==1){
            v[++k]=x;
            add();
        }
        else
            erase(poz[x]);
    }
    return 0;
}
