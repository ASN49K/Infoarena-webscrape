#include <fstream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <set>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
set <int> s;
set <int>::iterator it;
int i,n,x,y,v[10000001],k,Min=10000001;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        Min=1000000;
        fin>>x;
        if(x==1)
            {fin>>y;
                s.insert(y);
                v[++k]=y;
                }
        if(x==2)
            {
                fin>>y;
                s.erase(v[y]);

            }
if(x==3)
{

it=s.begin();
    fout<<*it<<endl;
}
    }
    return 0;
}
