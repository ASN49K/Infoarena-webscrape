#include <stdio.h>
#define DIM 200005

int N, X, A[DIM], H[DIM], I[DIM];

void swap (int &a, int &b)
{
	int x = a;
	a = b;
	b = x;
}

void urca (int n)
{
	int t = n >> 1;
	if (t && A[H[t]] > A[H[n]])
	{
		swap (H[t], H[n]);
		I[H[t]] = t;
		I[H[n]] = n;
		urca (t);
	}
}

void coboara (int n)
{
	int f = n << 1;
	if (A[H[f]] < A[H[n]] && f <= H[0])
	{
		if (A[H[f + 1]] < A[H[f]] && f + 1 <= H[0])
			f++;
		swap (H[n], H[f]);
		I[H[n]] = n;
		I[H[f]] = f;
		coboara (f);
	}
}

int main ()
{
	freopen ("heapuri.in", "r", stdin);
	freopen ("heapuri.out", "w", stdout);
	
	scanf ("%d", &N);
	for (int i = 0, t; i < N; i++)
	{
		scanf ("%d", &t);
		switch (t)
		{
			case 1:
				scanf ("%d", &A[++A[0]]);
				H[++H[0]] = A[0];
				I[A[0]] = A[0];
				
				urca (H[0]);
				break;
			case 2:
				scanf ("%d", &X);
				H[I[X]] = H[H[0]];
				I[H[H[0]--]] = I[X];
				
				urca (I[X]);
				coboara (I[X]);
				I[X] = -1;
				break;
			case 3:
				printf ("%d\n", A[H[1]]);
				break;
		}
	}	
	return 0;
}

