#include <bits/stdc++.h>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");


int main() {
    vector<int> order;
    order.push_back(0);
    int n;
    vector<int> heap;

    f>>n;
    for(int i=0;i<n;i++)
    {
        int op,value;
        f>>op;
        if(op==1)
        {
            f>>value;
            heap.push_back((-1)*value);
            push_heap(heap.begin(), heap.end());
            order.push_back(value);
        }
        else if(op==2)
        {
            f>>value;
            value = order[value];
            for(auto it = heap.begin(); it != heap.end(); ++it)
            {
                if(*it == (-1)*value)
                {
                    heap.erase(it);
                    break;
                }
            }
            make_heap(heap.begin(), heap.end());
        }
        else if(op==3)
        {
            g<<(-1)*heap.front()<<'\n';
        }
    }

    return 0;
}