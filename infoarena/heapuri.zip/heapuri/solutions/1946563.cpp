#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <vector>

using namespace std;

ifstream f("heapuri.in"); ofstream g("heapuri.out");
priority_queue < pair <int,int> > a;
pair <int,int> k;
int n; bool e[200004];

int main() {
    int i,c,p,nr;
    f>>n;
    nr = 0;
    for(i = 1; i <= 200000; ++i) {
        e[i] = 0;
    }
    for(i = 1; i <= n; ++i) {
        f>>c;
        if (c == 1) {
            f>>k.first;
            k.first = -k.first;
            ++nr;
            k.second = nr;
            a.push(k);
        }
        if (c == 2) {
            f>>p;
            e[p] = 1;
        }
        if (c == 3) {
            while(e[a.top().second]) {
                a.pop();
            }
            g<<-a.top().first<<'\n';
        }
    }
    return 0;
}
