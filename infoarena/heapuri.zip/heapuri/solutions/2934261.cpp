#include <fstream>
using namespace std;
ifstream cin("heapuri.in");
ofstream cout("heapuri.out");
int i, j, n, m, k, op, x, nr;
int v[200002], a[200002], p[200002];
void adauga(int aux){
    while(aux>1 && a[v[aux]]<a[v[aux/2]]){
        swap(v[aux], v[aux/2]);
        swap(p[v[aux]], p[v[aux/2]]);
        aux/=2;
    }

}
void sterge(int poz){
    if(poz==n){
        n--;
    }
    else{
        swap(v[poz], v[n]);
        swap(p[v[poz]], p[v[n]]);
        n--;
        int aux=poz;
        int p1=aux;
        while(aux>1 && a[v[aux]]<a[v[aux/2]]){
            swap(v[aux], v[aux/2]);
            swap(p[v[aux]], p[v[aux/2]]);
            p1=aux/2;
            aux/=2;
        }
        int c1=2*p1;
        while(c1<=n){
            if(c1+1<=n && a[v[c1+1]]<a[v[c1]])
                c1++;
            if(a[v[c1]]<a[v[p1]]){
                swap(v[c1], v[p1]);
                swap(p[v[c1]], p[v[p1]]);
            }
            else
                break;
            p1=c1;
            c1=2*p1;


        }
    }

}
int main() {
    cin>>nr;
    for(i=1;i<=nr;i++){
        cin>>op;
        if(op==1){
            cin>>x;
            a[++k]=x;
            v[++n]=k;
            p[k]=n;
            adauga(n);
        }
        if(op==2){
            cin>>x;
            sterge(p[x]);
        }
        if(op==3)
            cout<<a[v[1]]<<"\n";
    }



}
