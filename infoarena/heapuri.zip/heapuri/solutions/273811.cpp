#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <queue>
#include <vector>
#include <deque>
#include <algorithm>
#include <set>
#include <bitset>
#include <stack>

using namespace std;

#define pb			push_back
#define mp			make_pair
#define all(v)			v.begin(), v.end()
#define ff			first
#define ss			second
#define pii			pair<int,int>
#define maxN			200100

int N, Nr, H[maxN], V[maxN], P[maxN], NrADD;

void swap(int i, int j) {
	int aux;
	P[H[i]] = j;
	P[H[j]] = i;
	aux = H[i];
	H[i] = H[j];
	H[j] = aux;
	
}
void heap_down(int nod) {
	int minI = nod;
	
	if (2 * nod <= Nr && V[H[minI]] > V[H[2 * nod]])
		minI = 2 * nod;
	if (2 * nod + 1 <= Nr && V[H[minI]] > V[H[2* nod + 1]])
		minI = 2 * nod + 1;
	if (minI != nod) {
		swap(minI, nod);
		heap_down(minI);
	}
}

void heap_up(int nod) {
	if (nod > 1 && V[H[nod / 2]] > V[H[nod]]) {
		swap(nod / 2, nod);
		heap_up(nod / 2);
	}
}
int main () {
	int i, t, x;
	
	freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);
	
	for (scanf("%d", &N) ; N -- ; ) {
		scanf("%d", &t);
		if (t == 1) {
			scanf("%d", &x); ++ Nr; ++ NrADD;
			P[NrADD] = Nr;
			V[NrADD] = x;
			H[Nr] = NrADD;
			heap_up(Nr);
		}
		if (t == 2) {
			scanf("%d", &x);
			H[P[x]] = H[Nr -- ];
			heap_down(P[x]);
		}
		if (t == 3) 
			printf("%d\n", V[H[1]]);
	#ifdef DEBUG
		for (i = 1; i <= Nr; ++ i)
			printf("%d ", H[i]);
		puts("");
	#endif
	}
}

// powered by gedit snippets and suse :)
