#include <fstream>
#define nmax 200000+5
#define FOR(i, a, b) for(int i = (a); i <= (b); i++)
#define TATA(i) (i) / 2
#define ST(i) 2 * (i)
#define DR(i) 2 * (i) + 1
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int heap[nmax];
int pozh[nmax];
int pozv[nmax];
int indx;

inline int exista(int i)
{
    return i <= indx;
}
void actualizare(int i)
{
    int tata = TATA(i);
    int st = ST(i), dr = DR(i);
    int minim = i;
    if (exista(st) && heap[st] < heap[minim])
        minim = st;
    if (exista(dr) && heap[dr] < heap[minim])
        minim = dr;
    if (heap[minim] < heap[i])
        actualizare(minim);
    if (exista(tata) && heap[i] < heap[tata])
    {
        swap(heap[i], heap[tata]);
        swap(pozh[pozv[i]], pozh[pozv[tata]]);
        swap(pozv[i], pozv[tata]);
        actualizare(tata);
    }
}
void adaugare(int x)
{
    heap[++indx] = x;
    pozh[indx] = indx;
    pozv[indx] = indx;
    actualizare(indx);
}
void stergere(int i)
{
    swap(heap[i], heap[indx]);
    swap(pozh[pozv[i]], pozh[pozv[indx]]);
    swap(pozv[i], pozv[indx]);
    indx--;
    actualizare(i);
}
int main()
{
    int n, op, x;
    fin >> n;
    FOR(i, 1, n)
    {
        fin >> op;
        switch (op)
        {
            case 1:
                fin >> x;
                adaugare(x);
                break;
            case 2:
                fin >> x;
                stergere(pozh[x]);
                break;
            case 3:
                fout << heap[1] << '\n';
                break;
        }
    }
    return 0;
}
