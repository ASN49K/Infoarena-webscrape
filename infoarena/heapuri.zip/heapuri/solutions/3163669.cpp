#include <fstream>
#include <queue>
#include <vector>

using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

priority_queue < pair < int, int >, vector < pair < int, int > >, greater < pair < int, int > > > pq, pq2;
vector < int > v;
int main()
{
    int n, poz = 1, x, cod;
    cin >> n;
    v.resize(n);

    while(n--)
    {
        cin >> cod;
        if(cod == 1)
        {
            cin >> x;
            v[poz] = x;
            pq.push({x, poz});
            poz++;
        }
        else if(cod==2)
        {
            cin >> x;
            pq2.push({v[x], x});
        }
        else
        {
            while(!pq.empty() && !pq2.empty() && pq.top() == pq2.top())
            {
                pq.pop();
                pq2.pop();
            }
            cout << pq.top().first << '\n';
        }
    }
    return 0;
}
