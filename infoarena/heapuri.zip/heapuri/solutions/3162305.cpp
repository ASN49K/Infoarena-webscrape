#include<fstream>
#include<queue>
using namespace std;
ifstream in ("heapuri.in");
ofstream out ("heapuri.out");
priority_queue <pair<int,int>, vector<pair<int,int> >, greater<pair<int,int> > > heap,heap_eliminate;
int N, Value, Type, V[200005], Index, Nr;
int main (void) {
    in >> N;
    for (int i = 1; i <= N; i ++) {
        in >> Type;
        if (Type == 1) {
            Nr ++;
            in >> V[Nr];
            heap.push({V[Nr],Nr});
        }
        if (Type == 2) {
            in >> Index;
            heap_eliminate.push({V[Index],Index});
        }
        if (Type == 3) {
            while (heap_eliminate.size() > 0 && heap.size() > 0 && heap.top().second == heap_eliminate.top().second) {
                heap.pop();
                heap_eliminate.pop();
            }
            out <<heap.top().first <<"\n";
        }
    }
    return 0;
}
