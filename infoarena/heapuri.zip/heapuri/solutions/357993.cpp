#include<stdio.h>
#define dim 200001
using namespace std;

long long N, A[dim], H[dim], p[dim], nr, k;

void schimb(int x, int y)
{ long long aux;

	aux = H[x]; H[x] = H[y]; H[y] = aux;
	p[H[x]] = x; p[H[y]] = y;
}

void add(int x, int y)
{ long long i;

	H[++k] = y;
	p[nr] = k;
	i = k;
	while(A[H[i/2]] > A[H[i]] && i/2 == 1)
		{
			schimb(i, i/2);
			i/=2;
		}
}


void del(int x)
{long long i, i1;

	schimb(x, k);
	i = x;
	
	k--;
	
	i1 = x*2;
	while(A[H[i1]] <= A[H[i]] && i1 <= k)
	{
		
		if(k >= i1+1 && A[H[i1+1]] < A[H[i1]]) i1++;
		schimb(i1, i);
		
		i = i1; i1 *= 2;
	}
	return;
}

int main()
{ long long a,b,i;

	FILE *f = fopen("heapuri.in", "r");
	FILE *g = fopen("heapuri.out", "w");
	
	fscanf(f, "%d", &N);
	
	nr = 0;
	for(i = 1; i <= N; i++)
		{
			fscanf(f, "%lld", &a);
			if(a == 1 || a == 2)
				{
					fscanf(f, "%lld", &b);
					if(a == 1) {A[++nr] = b; add(b, nr);}
					  else del(p[b]);
				}
			  else fprintf(g, "%lld\n", A[H[1]]);
		}
	
	
	fclose(f);
	fclose(g);
	return 0;
}