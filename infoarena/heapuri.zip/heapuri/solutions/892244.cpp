#include<iostream>
#include<cstdio>
#define nmax 200010
using namespace std;
int n,x,cod,in[nmax],a[nmax],p[nmax],i,k;
void urc(int i)
{
    if(i/2>=1)
    {
        if(a[i/2]>a[i])
        {
            swap(a[i/2],a[i]);
            swap(p[i/2],p[i]);
            urc(i/2);
        }
    }
}
void pop(int x)
{
    int r;
    a[x]=a[k--];
    while(2*x<=k)
    {
        int min=a[2*x];
        r=2*x;
        if(2*x+1<=k && min>a[2*x+1])
        {
            min=a[2*x+1];
            r=2*x+1;
        }
        swap(a[x],a[r]);
        swap(p[x],p[r]);
        x=r;
    }
}
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&cod);
        switch(cod)
        {
            case 1:
                scanf("%d",&x);
                in[++k]=x;
                a[k]=x;
                p[k]=k;
                urc(k);
                break;
            case 2:
                scanf("%d",&x);
                pop(p[x]);
                break;
            case 3:
                printf("%d\n",a[1]);
                break;
        }
    }
    return 0;
}
