#include <cstdio>
#include <iostream>
#include <vector>
#include <queue>
#include <utility>
#include <algorithm>
#include <functional>
#include <string>
#include <cmath>
#include <map>
#include <set>
#include <bitset>
#include <stack>
#define MOD 1000000007
#define NMAX 200005
#define MMAX 100005
#define INF 1000000000
#define mp make_pair

using namespace std;

FILE *fin = freopen("heapuri.in", "r", stdin);
FILE *fout = freopen("heapuri.out", "w", stdout);

int H[NMAX], v[NMAX], pos[NMAX];
int inHeap, nrOrd;

void push(int x); // promoveaza numarul de pe poz x
void pop(int x);  // retrogradeaza numarul de pe poz x

int main() {
	int m, i, k, maxv, dr, nr, op;

	scanf("%d", &m);
	for (i = 0; i < m; ++i) {
		scanf("%d", &op);
		if (op < 3)
			scanf("%d", &nr);

		if (op == 1) {
			++inHeap;
			++nrOrd;

			H[inHeap] = nrOrd;
			v[nrOrd] = nr;
			pos[nrOrd] = inHeap;

			push(inHeap);
		}
		else if (op == 2) {
			v[nr] = -1;
			push(pos[nr]); // promovam elementul de pe poz nr pana in radacina

			pos[H[1]] = 0;
			H[1] = H[inHeap--];
			pos[H[1]] = 1;
			if (inHeap > 1)
				pop(1);
		}
		else
			printf("%d\n", v[H[1]]);
	}

	return 0;
}

void push(int x) {
	int aux;

	while (x / 2 > 0 && v[H[x]] < v[H[x / 2]]) {
		swap(H[x], H[x / 2]);

		pos[H[x]] = x;
		pos[H[x / 2]] = x / 2;
		x >>= 1;
	}
}

void pop(int x) {
	int y = 0;

	while (x != y) {
		y = x;

		if (y * 2 <= inHeap && v[H[x]] > v[H[y * 2]])
			x = y * 2;
		if (y * 2 + 1 <= inHeap && v[H[x]] > v[H[y * 2 + 1]])
			x = y * 2 + 1;

		swap(H[x], H[y]);

		pos[H[x]] = x;
		pos[H[y]] = y;
	}
}
