#include <bits/stdc++.h>

#define NM 200002

using namespace std;

int n, h[NM], m, o[NM];
long long v[NM];

void fix2 (int k)
{
    //cout << k << " ";
    if(k < 1)
        return;
    if(k / 2 >= 1 && v[h[k]] < v[h[k / 2]])
    {
        o[h[k]] = k / 2;
        o[h[k / 2]] = k;
        swap(h[k], h[k / 2]);
        fix2(k / 2);
    }
}
void fixinsert ()
{
    int k = m;
    fix2(k);
}

/// 5 8 7 24 3

void fix1 (int k)
{
    //cout << k << " ";
    int x = k * 2;
    if(k > m)
        return;
    if(h[k * 2 + 1] < h[k * 2])
        x = k * 2 + 1;
    if(x <= m && v[h[k]] > v[h[x]])
    {
        o[h[k]] = x;
        o[h[x]] = k;
        swap(h[k], h[x]);
        fix1(x);
    }
}
void fixdelete (int k)
{
    o[h[m]] = k;
    h[k] = h[m];
    m--;
    fix1(k);
    //cout << "\n";
}


int main()
{
    ifstream fin ("heapuri.in");
    ofstream fout ("heapuri.out");
    fin >> n;
    for(int i = 1, y = 0; i <= n; i++)
    {
        int op;
        fin >> op;
        if(op == 3)
            fout << v[h[1]] << "\n";
        else if(op == 1)
        {
            y++;
            fin >> v[y];
            m++;
            o[y] = m;
            h[m] = y;
            fixinsert();
        }
        else if(op == 2)
        {
            int x;
            fin >> x;
            fixdelete(o[x]);
        }
        /*
        for(int i = 1; i <= m; i++)
            fout << v[h[i]] << " ";
        fout << "\n";*/
    }
    return 0;
}
