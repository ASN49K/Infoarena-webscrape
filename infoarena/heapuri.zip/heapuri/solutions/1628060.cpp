#include<set>
#include<cstdio>
#include<algorithm>
using namespace std;
multiset<int> s;
int i,j,n,m,v[200001];
int main ()
{
freopen("heapuri.in","r",stdin);
freopen("heapuri.out","w",stdout);
scanf("%d",&n);
for(i=1;i<=n;i++)
    {
    scanf("%d",&j);
    if(j==3)
        printf("%d\n",*s.begin());
    if(j==1)
        {
        scanf("%d",&v[++m]);
        s.insert(v[m]);
        }
    if(j==2)
        {
        int x;
        scanf("%d",&x);
        s.erase(v[x]);
        }
    }
return 0;
}
