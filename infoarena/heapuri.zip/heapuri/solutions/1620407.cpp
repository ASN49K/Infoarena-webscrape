#include <fstream>
#include <vector>
#define f first
#define s second
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int n, i, j = 1, x, op, heapInd = 1;
int heapPos[200100];
vector<pair<int, int> > minHeap(200100);

void heapInsert(int val) {
    int crt = heapInd, swapper;
    pair<int, int> aux;

    minHeap[ heapInd ].f = val; minHeap[ heapInd ].s = j;
    heapPos[ j ] = heapInd;
    while (minHeap[ crt ].f < minHeap[ crt / 2 ].f) {
        swapper = heapPos[ minHeap[ crt ].s ];
        heapPos[ minHeap[ crt ].s ] = heapPos[ minHeap[ crt / 2 ].s ];
        heapPos[ minHeap[ crt / 2 ].s ] = swapper;

        aux = minHeap[ crt ];
        minHeap[ crt ] = minHeap [ crt / 2 ];
        minHeap[ crt / 2 ] = aux;

        crt /= 2;
    }

    j++; heapInd++;
}

void heapDelete(int val) {
    int crt = heapPos[ val ];

    while (crt * 2 < heapInd)
        crt *= 2;

    minHeap[ heapPos[ val ] ] = minHeap[ crt ];
    heapInd--; heapPos[ val ] = -1;
}

int main()
{
    fin>>n;
    for (i = 1 ; i <= n ; i++) {
        fin>>op;
        if (op == 1) {
            fin>>x;
            heapInsert( x );
        } else if (op == 2) {
            fin>>x;
            heapDelete( x );
        } else {
            fout<<minHeap[1].f<<'\n';
        }
    }

return 0;
}
