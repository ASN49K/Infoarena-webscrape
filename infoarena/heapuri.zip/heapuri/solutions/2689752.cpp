#include <bits/stdc++.h>
#define ll long long
using namespace std;

int amount_of_numbers = 1;
int k = 1;
ll heap[200015];
int positions[200015];
int posinheap[200015];

void insert(int number){
	heap[k] = number;
	posinheap[k] = amount_of_numbers;
	positions[amount_of_numbers] = k;
	int index = k;
	while(index != 1){
		if(heap[index/2] > heap[index]){
			swap(heap[index/2],heap[index]);
			swap(positions[amount_of_numbers], positions[posinheap[index/2]]); 
			swap(posinheap[index/2], posinheap[index]);
			index /= 2;
		} else{
			break;
		}
	}
	k++;
	amount_of_numbers++;
}

int get_min(){
	return heap[1];
}

void pop_position(int position){
	int index = positions[position];
	k--;
	heap[positions[position]] = heap[k];
	heap[k] = 0;
	swap(positions[position], positions[posinheap[k]]);
	swap(posinheap[k], posinheap[positions[posinheap[k]]]);
	position = index;
	while(position != 1 && position < k) {
		if(heap[position/2] > heap[position]) {
			swap(heap[position/2], heap[position]);
			swap(positions[posinheap[position]], positions[posinheap[position/2]]);
			swap(posinheap[position/2], posinheap[position]);
			position /= 2;
		} else {
			break;
		}
	}
	while(position*2 < k) {
		if(heap[position*2] > heap[position*2+1] && position*2+1 < k) {
			if(heap[position] > heap[position*2+1]) {
				swap(heap[position], heap[position*2+1]);
				swap(positions[posinheap[position]], positions[posinheap[position*2+1]]);
				swap(posinheap[position*2+1], posinheap[position]);
				position = position*2+1;
			} else {
				break;
			}
		} else {
			if(heap[position] > heap[position*2] && position*2 < k) {
				swap(heap[position], heap[position*2]);
				swap(positions[posinheap[position]], positions[posinheap[position*2]]);
				swap(posinheap[position*2], posinheap[position]);
				position = position*2;
			} else {
				break;
			}
		}
	}
}

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");


int main(){
	int n;
	ll i,op,arg;
	fin>>n;
	for(i = 0; i < n; i++){
		fin>>op;
		if (op<3){
			fin>>arg;
			if(op == 1){
				insert(arg);
			} else {
				pop_position(arg);
			}
		} else {
			fout<<get_min()<<"\n";
		}
	}
}
