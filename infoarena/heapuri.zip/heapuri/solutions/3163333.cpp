#include <iostream>
#include <fstream>

using namespace std;
#define MaxN 200000

int heap[MaxN], poz[MaxN], sec[MaxN];
int hsize, cnt;
void ins(int x)
{
    int k;
    hsize++; cnt++;
    heap[hsize]=x;
    sec[hsize]=cnt;
    poz[cnt]=hsize;
    k=hsize;
    while(k>1 && heap[k]<heap[k/2])
    {
        swap(heap[k], heap[k/2]);
        swap(poz[sec[k]], poz[sec[k/2]]);
        swap(sec[k], sec[k/2]);
        k=k/2;
    }
}

void dlt(int x)
{
    int k, ck;
    k=poz[x];
    ck=k;
    swap(heap[k], heap[hsize]);
    swap(poz[sec[k]], poz[sec[hsize]]);
    swap(sec[k], sec[hsize]);
    hsize--;
    while(k<=hsize && (heap[k]>heap[2*k] || heap[k]>heap[2*k+1]))
    {
        if(heap[2*k]<heap[2*k+1] && 2*k+1<=hsize)
        {
            swap(heap[k], heap[k*2]);
            swap(poz[sec[k]], poz[sec[k*2]]);
            swap(sec[k], sec[k*2]);
            k=2*k;
        }
        else if(2*k+1<=hsize)
        {
            swap(heap[k], heap[k*2+1]);
            swap(poz[sec[k]], poz[sec[k*2+1]]);
            swap(sec[k], sec[k*2+1]);

            k=2*k+1;
        }
        else if(2*k<=hsize)
        {
            swap(heap[k], heap[k*2]);
            swap(poz[sec[k]], poz[sec[k*2]]);
            swap(sec[k], sec[k*2]);
            k=2*k;
        }
        else
            break;


    }
    while(k>1 && heap[k]<heap[k/2])
    {
        swap(heap[k], heap[k/2]);
        swap(poz[sec[k]], poz[sec[k/2]]);
        swap(sec[k], sec[k/2]);
        k=k/2;
    }
}
int main()
{
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");
    int n, cer, i, x;
    in>>n;
    hsize=0; cnt=0;
    for(i=0; i<n; i++)
    {
        in>>cer;
        if(cer==3) out<<heap[1]<<'\n';
        else if(cer==1)
        {
            in>>x;
            ins(x);
        }
        else
        {
            in>>x;
            dlt(x);
        }

    }


    return 0;
}
