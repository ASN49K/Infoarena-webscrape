#include<fstream>
#include<algorithm>
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int n,sir[200002],H[200002],pozH[200002],dim,dimH;

void push(int nod)
{
	int tata=nod/2;
	if(pozH[nod]==1) return ;
	if(sir[H[nod]]>=sir[H[tata]]) return;
	swap(H[nod],H[tata]);
	swap(pozH[H[nod]],pozH[H[tata]]);
	push(nod/2);
}

void pop(int nod)
{
	int f1=nod*2;
	int f2=nod*2+1;
	int nodmin=nod;
	

	if(sir[H[f1]]<sir[H[nodmin]] && f1<=dimH)
		nodmin=f1;
	if(sir[H[f2]]<sir[H[nodmin]] && f2<=dimH)
		nodmin=f2;
	
	if(nod==nodmin) return;
	
	if(sir[H[nod]]>sir[H[nodmin]])
		swap(H[nod],H[nodmin]);
		swap(pozH[H[nod]],pozH[H[nodmin]]);
		pop(nodmin);
	

}
	
	void adaug()
{
	int x;
	f>>x;
	dim++;
	sir[dim]=x;
	dimH++;
	H[dimH]=dim;
	pozH[dim]=dimH;
	push(dimH);
}

void sterg()
{
	int x;
	f>>x;
	swap(H[pozH[x]],H[dimH]);
	int tin=pozH[x];
	swap(pozH[x],pozH[pozH[x]]);
	dimH--;
	
	if(sir[H[tin]]<sir[H[tin/2]])
	push(tin);
	else
		pop(tin);
}



int main()
{
	f>>n;

	for(int i=1;i<=n;i++)
	{
		int a;
		f>>a;
		
		if(a==1) adaug();
		if(a==2) sterg();
		if(a==3) g<<sir[H[1]]<<"\n";
	}
}
	