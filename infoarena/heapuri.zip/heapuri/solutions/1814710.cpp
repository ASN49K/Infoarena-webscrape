#include <fstream>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

#define DMAX 200005

struct Heap {
    int val, poz;
}heap[DMAX];

int Inserat[DMAX], Poz[DMAX];
int nrel, nrins;
int x;

void insereaza() {
    heap[++nrel].val = x;
    ++nrins;
    heap[nrins].poz = nrins;
    Poz[nrins] = nrel;

    int aux = nrel;

    while(aux >= 2 && heap[aux/2].val > heap[aux].val) {
        swap(heap[aux/2], heap[aux]); //interschimba si aux si val
        swap(Poz[heap[aux/2].poz], Poz[heap[aux].poz]);
        aux /= 2;
    }
}

void sterge() {
    heap[Poz[x]] = heap[nrel];
    Poz[heap[nrel].poz] = Poz[x];
    nrel--;

    int aux = Poz[x];

    while(aux >= 2 && heap[aux/2].val > heap[aux].val) {
        swap(heap[aux/2], heap[aux]); //interschimba si aux si val
        swap(Poz[heap[aux/2].poz], Poz[heap[aux].poz]);
        aux /= 2;
    }

    while((2*aux <= nrel && heap[aux].val > heap[2*aux].val) || (2*aux + 1 <= nrel && heap[aux].val > heap[2*aux + 1].val)) {
        if(heap[2*aux + 1].val > heap[2*aux].val) {
            swap(heap[aux], heap[2*aux]);
            swap(Poz[heap[aux].poz], Poz[heap[2*aux].poz]);
            aux = aux * 2;
        }
        else {
            swap(heap[aux], heap[2*aux + 1]);
            swap(Poz[heap[aux].poz], Poz[heap[2*aux + 1].poz]);
            aux = aux * 2 + 1;
        }
    }
}

void afiseaza() {
    fout<<heap[1].val<<'\n';
}

int main() {
    int N, op, i;
    fin>>N;
    for(i = 1 ; i <= N ; i++) {
        fin>>op;
        if(op == 1) { fin>>x; insereaza(); }
        if(op == 2) { fin>>x; sterge(); }
        if(op == 3) afiseaza();
    }

    fin.close();
    fout.close();

    return 0;
}
