// Heapuri
#include <bits/stdc++.h>
#define inf (int)(1<<30)
#define NMax 200005
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

inline int maxim(int a, int b) {
	if (a > b)
		return a;
	return b;
}

inline int minim(int a, int b) {
	return a+b-maxim(a,b);
}

int q;
int n = 0;
int order = 0;
int V[NMax];
int H[NMax];
int P[NMax]; // P[n] = pozitia pe care se afla nodul n

void insertElement(int x) {
	n++;
	V[n] = x;
	H[n] = n;
	P[H[n]] = n;
	
	int position = n;
	while (position > 1) {
		if (V[H[position]] < V[H[position/2]]) {
			int aux = H[position];
			H[position] = H[position/2];
			H[position/2] = aux;
			
			P[H[position]] = position;
			P[H[position/2]] = position/2;
			
			position /= 2;
		} else {
			break;
		}
	}
}

void eraseElement(int no) {
	int pos = P[no];
	
	while (2*pos <= n) {
		int left = 2*pos;
		if (2*pos+1 <= n) {
			int right = 2*pos+1;
			
			int chosen = left;
			if (V[H[left]] > V[H[right]])
				chosen = right;
				
			int aux = H[pos];
			H[pos] = H[chosen];
			H[chosen] = aux;
			
			P[H[chosen]] = chosen;
			P[H[pos]] = pos;
			
			pos = chosen;
		} else {
			int aux = H[pos];
			H[pos] = H[left];
			H[left] = aux;
			
			P[H[left]] = left;
			P[H[pos]] = pos;
			
			pos = left;
		}
	}
	
	V[H[pos]] = inf;
}

int queryMinimum() {
	return V[H[1]];
}

void read() {
	f>>q;
	for (int i=1;i<=q;i++) {
		int tip;
		f>>tip;
		
		if (tip == 1) {
			int x;
			f>>x;
			insertElement(x);
		} else if (tip == 2) {
			int x;
			f>>x;
			eraseElement(x);
		} else if (tip == 3) {
			// Quering minimum
			g<<queryMinimum()<<'\n';
		}
	}
}

int main() {
	
	read();
	
	f.close(); g.close();
	return 0;
}
