#include <iostream>
#include <fstream>
#include <set>
using namespace std;

int v[200002], i, n, option, x, k = 0;
multiset<int>heap;

int main(){
    ifstream fin("heapuri.in");
    ofstream fout("heapuri.out");
    fin>>n;
    for (i = 0; i < n; i++){
        fin>>option;
        if (option == 1){
            fin>>x;
            heap.insert(x);
            v[k++] = x;
        }
        else if (option == 2){
            fin>>x;
            heap.erase(heap.find(v[x - 1]));
        }
        else
            fout<<*heap.begin()<<"\n";
    }
    return 0;
}