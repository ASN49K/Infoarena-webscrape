# include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int h[100000], a[100000], poz[100000], lh, nr;
void urca(int nod)
{
    while (nod/2 && a[h[nod]]<a[h[nod/2]])
    {
        int aux=h[nod];
        h[nod]=h[nod/2];
        h[nod/2]=aux;

        poz[h[nod]]=nod;
        poz[h[nod/2]]=nod/2;

        nod=nod/2;
    }
}
void coboara(int nod)
{
    int son;
    do
    {
        son=0;
        if (nod*2<=lh && a[h[2*nod]]<a[h[nod]])
        {
            son=2*nod;
            if (2*nod+1<=lh && a[h[2*nod+1]]<a[h[son]])
                son=2*nod+1;
        }
        if (a[h[son]]>a[h[nod]])
            son=0;
        if (son)
        {
            int aux=h[nod];
            h[nod]=h[son];
            h[son]=aux;

            poz[h[nod]]=nod;
            poz[h[son]]=son;

            son=nod*2;
        }
    }while (son);
}
int main()
{
    int n, cod, x, i;
    f>>n;
    for (i=1; i<=n; i++)
    {
        f>>cod;
        if (cod<3)
        {
            f>>x;
            if (cod==1)
            {
                //adauga x
                a[++nr]=x;
                h[++lh]=nr;
                poz[nr]=lh;

                urca(lh);

            }
            else
                if (cod==2)
            {
                //sterge nodul x
                a[x]=-1;
                h[poz[x]]=h[lh];

                poz[h[lh]]=poz[x];

                h[lh]=-1;
                lh--;
                if (a[h[poz[x]]]<a[h[poz[x]/2]])
                    urca(poz[x]);
                else
                    coboara(poz[x]);
                /*for (i=1; i<=lh; i++)   cout<<a[h[i]]<<endl;
                cout<<endl<<endl;*/
                poz[x]=-1;
            }
        }
       else
                g<<a[h[1]]<<'\n';
    }
    //for (i=1; i<=nr; i++)   cout<<a[h[i]]<<endl;
    return 0;
}
