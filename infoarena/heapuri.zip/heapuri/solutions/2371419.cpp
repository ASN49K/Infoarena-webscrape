#include <fstream>
#include <vector>
#define Nrp 10007
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector <int>h[Nrp+1];
int n,r,c,nr,m,ok;

int main()
{
    f>>n;
    for(int i=1;i<=n;++i)
    {
        f>>c>>nr;
        if(c==1)
        {
            r=nr%Nrp;ok=1;
            m=h[r].size();
            for(int i=0;i<m;++i)if(h[r][i]==nr)ok=0;
            if(ok)h[r].push_back(nr);
        }
        if(c==2)
        {
            r=nr%Nrp;ok=1;
            m=h[r].size();
            for(int i=0;i<m;++i)if(h[r][i]==nr)h[r].erase(h[r].begin()+i);
        }
        if(c==3)
        {
            r=nr%Nrp;ok=1;
            m=h[r].size();
            for(int i=0;i<m;++i)if(h[r][i]==nr)ok=0;
            if(!ok)g<<"1";
            else g<<"0";
            g<<'\n';
        }
    }
    return 0;
}
