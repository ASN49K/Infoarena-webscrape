#include <fstream>
#include <set>

const int maxn=200010;
using namespace std;
      set <int>h;

int ord[maxn],c, n,cnt,x;
int main()
{
    int i;
ifstream f("heapuri.in");
ofstream g("heapuri.out");    
f>>n;
for(i=0;i<n;i++)
  {
                
  f>>c;
  if(c<=2)
  f>>x;
  switch(c)
     {
       case 1:{ h.insert(x);ord[cnt]=x;cnt++;break; };
       case 2:{ h.erase(ord[x-1]);break; };
       case 3:{ g<<*h.begin()<<"\n"; };      
     
     }
  }

}
