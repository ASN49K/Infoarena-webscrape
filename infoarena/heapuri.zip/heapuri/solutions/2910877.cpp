#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int n,V[200005],pos[200005],dh;

vector<int> T;

void ridicare(int pozelem)
{
    while(V[pozelem]<V[pozelem/2] && pozelem>1)
    {
        swap(V[pozelem],V[pozelem/2]);
        swap(pos[V[pozelem]],pos[V[pozelem/2]]);
        pozelem = pozelem/2;
    }
}

void coborare(int pozelem)
{
    int fiu;
    int pozfiu;
    fiu = min(V[2*pozelem],V[2*pozelem+1]);
    if(V[2*pozelem] == fiu)
        pozfiu = 2*pozelem;
    else
        pozfiu = 2*pozelem+1;


    while(2*pozelem <=dh && V[pozelem]>fiu)
    {
        swap(V[pozelem],V[pozfiu]);
        swap(pos[V[pozelem]],pos[fiu]);

        pozelem = pozfiu;
        fiu = min(V[2*pozelem],V[2*pozelem+1]);
        if(V[2*pozelem] == fiu)
            pozfiu = 2*pozelem;
        else
            pozfiu = 2*pozelem+1;

    }
}

void inserare(int elem)
{
    dh++;
    V[dh] = elem;
    pos[elem] = dh;
    ridicare(dh);
}
void stergere(int elem)
{
    int pozitie = pos[elem];
    swap(V[pozitie],V[dh]);
    pos[V[pozitie]] = pozitie;
    V[dh] = INT_MAX;
    dh--;
    coborare(pozitie);
    ridicare(pozitie);
}

int main()
{
    fin>>n;
    for(int i = 1;i<=n;i++)
        V[i] = INT_MAX;
    for(int i = 1;i<=n;i++)
    {
        int a,b;
        fin>>a;
        if(a == 1)
        {
            fin>>b;
            T.push_back(b);
            inserare(b);
        }
        else{
            if(a == 2)
            {
                fin>>b;
                stergere(T[b-1]);
            }
            else{
                fout<<V[1]<<'\n';
            }
        }

    }
}
