#include<fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int multime[100000];

void stergere(int multime[], int &n, int k)
{
	int i;
	
	for(i = k; i < n; i++)
		multime[i] = multime[i + 1];
	
	n--;
}

int min(int multime[], int n)
{
	int k = 99999999;
	
	for(int i=1;i <= n; i++)
	{
		if(multime[i]<k)k = multime[i];
	}
return k;
}

int main()
{
	int n=0, nr, tip, x;
	
	fin>>nr;
	
	while(nr)
	{
		fin>>tip;
		if(tip != 3)
			fin>>x;
		
		if(tip == 1)
		{
			n++;
			multime[n] = x;
		}
		
		if(tip == 2)
		{
			stergere(multime,n,x);
		}
		
		if(tip == 3)
		{
			fout<<min(multime,n)<<"\n";
		}
	nr--;
	}
	
	fin.close();
	fout.close();
	return 0;
}

	