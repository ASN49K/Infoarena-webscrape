#include <stdio.h>

int N;

const int NMAX = 200005;

int heap[NMAX];
int  pos[NMAX];
int A[NMAX];
int L = 0;

void swap(int x, int y) {
   int aux;

   aux = heap[x];
   heap[x] = heap[y];
   heap[y] = aux;

   pos[heap[x]] = x;
   pos[heap[y]] = y;
}

void heapify_up() {
   int x = L;
   while (x / 2 >= 1) {
      int f = x / 2;
      if (A[heap[x]] < A[heap[f]]) {
         swap(x, f);
         x = f;
      } else {
         break;
      }
   }
}

void heapify_down(int ix) {
   int p = ix;

   int l = 2 * p;
   int r = 2 * p + 1;

   while (l <= L) {
      int min_c = l;
      if (r <= L && A[heap[l]] < A[heap[r]]) {
         min_c = r;
      }

      if (A[heap[min_c]] < A[heap[p]]) {
         swap(min_c, p);
         p = min_c;
         l = 2 * p;
         r = 2 * p + 1;
      } else {
         break;
      }
   }
}

int pop(int ix) {
   int val = A[heap[ix]];
   A[heap[ix]] = -1;

   swap(L,ix);
   L--;
   heapify_down(ix);

   return val;
}

int contor = 1;

int main() {
   freopen("heapuri.in", "r", stdin);
   freopen("heapuri.out", "w", stdout);

   scanf("%d", &N);

   for (int i = 1; i <= N; ++i) {
      //printf("\nBEGIN--------\n");
      //for (int i = 1; i <= L; ++i) {
         //printf("%d ", A[heap[i]]);
      //}
      //printf("\nEND-----------\n");
      int t;
      scanf("%d", &t);
      //printf("Exec op %d\n", t);

      if (t == 1) {
         int val;
         scanf("%d", &val);

         L += 1;
         A[contor++] = val;
         heap[L] = contor-1;
         pos[contor] = L;

         heapify_up();
      } else if (t == 2) {
         int ix;
         scanf("%d", &ix);
         //printf("removing %d %d", ix, pos[ix]);
         pop(pos[ix]);
      } else {
         printf("%d\n", A[heap[1]]);
      }
   }

   fclose(stdin);
   fclose(stdout);
   return 0;
}
