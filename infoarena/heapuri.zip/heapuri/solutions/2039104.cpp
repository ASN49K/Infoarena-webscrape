#include <fstream>
#include <set>
#include <vector>
#include <algorithm>
using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

#define MAX 200000
int heap[MAX], v[MAX], pos[MAX];
int L;
void PushUp(int p)
{
	while (p && v[heap[p]] < v[heap[p / 2]])
	{
		swap(heap[p], heap[p / 2]);

		pos[heap[p / 2]] = p / 2;
		pos[heap[p]] = p;
		p = p / 2;
	}
}
void PushDown(int p)
{
	while (p < L)
	{
		int c = p;
		if (2 * p + 1 < L && v[heap[2 * p + 1]] < v[heap[c]]) c = 2 * p + 1;
		if (2 * p + 2 < L && v[heap[2 * p + 2]] < v[heap[c]]) c = 2 * p + 2;

		if (c != p)
		{
			swap(heap[p], heap[c]);

			pos[p] = p;
			pos[c] = c;
			p = c;
		}
		else break;
	}
}
int main()
{
	set<int> s;
	int k = 0;
	int N;
	in >> N;
	for (int i = 0; i < N; i++)
	{
		int opt, x;
		in >> opt;
		switch (opt)
		{
		case 1:
			in >> x;
			v[k] = x;
			heap[L] = k;
			pos[k] = L;
			k++; L++;

			PushUp(L - 1);
			break;
		case 2:
			in >> x;
			x--;
			v[x] = -1;
			PushUp(pos[x]);

			heap[0] = heap[L - 1];
			pos[heap[0]] = 0;
			L--;
			PushDown(0);
			break;
		case 3:
			out << v[heap[0]] << '\n';
			break;
		}
	}
}