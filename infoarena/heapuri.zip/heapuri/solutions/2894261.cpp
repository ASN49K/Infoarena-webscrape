#include <iostream>
#include <fstream>
#include<set>
#include<iterator>

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

#define NMAX 2004

set <int> myheap;
int N;

int main()
{
    fin>>N;
    long x, v[NMAX + 1] = {0};
    for(int i = 0; i < N; ++i)
        {
            fin>>x;

            if(x == 1)
            {
             fin>>x;
             v[i + 1] = x;
             myheap.insert(x);
            }
            else
                if(x == 2)
                {
                    fin>>x;
                    myheap.erase(v[x]);
                }
                else
                    if(x == 3)
                    {
                        int val = *myheap.begin();
                        fout<<val<<"\n";
                    }
        }
    return 0;
}
