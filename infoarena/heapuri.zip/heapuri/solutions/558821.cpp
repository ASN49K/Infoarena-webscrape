#include <iostream>
#include <cstdlib>
#define MAX 200005

using namespace std;


int t,n=0;
int a[MAX],poz1[MAX],poz2[MAX];

int father(int x){return x/2;}

int sonl(int x){return 2*x;}

int sonr(int x){return 2*x+1;}


void sift(int k){
	int son=0,temp;
	
	do{
		
		son=0;
		
		if(sonl(k)<=n){son=sonl(k);
		
		if((sonr(k)<=n)&&(a[sonl(k)]<a[sonl(k)]))son=sonr(k);
		
		if(a[son]<a[k])swap(a[k],a[son]);
		
		poz1[poz2[son]]=k;
		temp=poz2[k];
		poz2[k]=poz2[son];
		poz1[temp]=son;
		poz2[son]=temp;
		
		k=son;}
		
		
		
	}while(son);
	
}


void percolate(int k){
	
	int key=a[k],temp;
	
	while((k>1)&&(a[father(k)]>a[k])){
		
		a[k]=a[father(k)];
		
		poz1[poz2[father(k)]]=k;
		temp=poz2[k];
		poz2[k]=poz2[father(k)];
		poz1[temp]=father(k);
		poz2[father(k)]=temp;
		
		k=father(k);
		
	}
	
	a[k]=key;
	
}

void insert(int x){

	n++;
	a[n]=x;
	poz1[n]=n;
	poz2[n]=n;
	percolate(n);

}


void sterge(int x){
	int key=poz1[x];
	
	a[key]=a[n];
	
	poz1[key]=key;
	poz2[key]=poz2[n];
	
	if((key>1)&&(a[father(key)]>a[key]))percolate(key);
	
	if(((sonl(key)<=n)&&(a[key]>a[sonl(key)]))||((sonr(key)<=n)&&(a[key]>a[sonr(key)])))sift(key);
	
	
}


void afiseaza(){
	printf("%d\n",a[1]);
}

int main(){
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	
	int tip,temp,i;
	
	scanf("%d",&t);
	
	for(i=1;i<=t;i++){
		scanf("%d",&tip);
		
		switch(tip){
		case 1:
			scanf("%d",&temp);
			insert(temp);
			break;
		case 2:
			scanf("%d",&temp);
			sterge(temp);
			break;
			
		case 3:
			afiseaza();
			break;
			
			
		};
		
		
	}
	
	
	
	return 0;}
