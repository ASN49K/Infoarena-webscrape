#include<fstream>
#define MAXN 200010

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int n,ord[MAXN],o,h[MAXN],k,poz[MAXN];

void swap(int x,int y)
{
	int aux=h[x];
	h[x]=h[y];
	h[y]=aux;
}


void upheap()
{
	int nod=k,tata=nod/2;
	while(tata>1 && h[tata]>h[nod])
	{
		swap(tata,nod);
		poz[h[nod]]=nod;
		poz[h[tata]]=tata;
		nod=tata;
		tata=tata/2;
	}
}

void downheap(int i)
{
	int stg,dr,max=i;
	stg=2*i;
	dr=2*i+1;
	if(stg<=k && h[stg]<h[i])
		max=stg;
	if(dr<=k && h[dr]<h[max])
		max=dr;
	if(max!=i)
	{
		swap(max,i);
		poz[h[i]]=i;
		poz[h[max]]=max;
		downheap(max);
	}
}

void eliminare(int i)
{
	poz[i]=0;
	h[i]=h[k];
	h[k]=0;
	k--;
	downheap(i);
}

void adaugare(int i)
{
	h[++k]=i;
	poz[i]=k;
	ord[++o]=i;
	upheap();
}

void maxim()
{
	out<<h[1]<<" ";
}

void read()
{
	in>>n;
	for(int i=1;i<=n;i++)
	{
		int a,b;
		in>>a;
		if(a==3)
			maxim();
		else
		{
			if(a==2)
			{
				in>>b;				
				eliminare(poz[ord[b]]);
			}
			if(a==1)
			{
				in>>b;
				adaugare(b);
			}
		}
	}
}

int main()
{
	read();
	return 0;
}
