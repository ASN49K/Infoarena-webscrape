#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
#define INF 0x3f3f3f3f
int main() {
vector<int>heap;
int N;
int op,x;
int counter=0;
int ind[100];
fin >> N;
for(int i=0;i<N;i++) {

fin >> op;
   if (op==1) {
        fin >> x;
        heap.push_back(x);
    }
    else if(op==2) {
        fin>>x;
        int ind=x-1;
        ind-=counter;
        counter++;
        cout << ind << "\n";
        heap.erase(heap.begin() + ind );
    }
    else if(op==3) {
        vector<int>::iterator result = min_element(begin(heap),end(heap));
         fout << result[0] << "\n";
    }

}

}
