#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <set>
#include <unordered_map>
#include <stack>
#include <iomanip>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

const int MAX = 200001;

int main() {
    int n;
    fin >> n;

    multiset<int> ans;

    int cnt = 0;
    vector<int> pos(MAX);

    for (int i = 0; i < n; ++i) {
        int x, y;
        fin >> x;
        if (x == 1) {
            fin >> y;
            pos[++cnt] = y;
            ans.insert(y);
        } else if (x == 3) {
            fout << *ans.begin() << "\n";
        } else if (x == 2) {
            fin >> y;
            ans.erase(pos[y]);
        }
    }

    return 0;
}