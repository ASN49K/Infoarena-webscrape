#include <cstdio>
#include <iostream>

using namespace std;

#define NMAX 200005

#define SWAP(a, b){\
    a = a + b;\
    b = a - b;\
    a = a - b;\
}

int A[NMAX], Heap[NMAX], Pos[NMAX], N;

inline int getLeft(int p){ return 2 * p;}
inline int getRight(int p){ return 2 * p + 1;}
inline int getParent(int p){ return p / 2;}
inline int getMin(){ return A[Heap[1]];}

void down(int p){
	int son;
	do{
		son = 0;
		if(getLeft(p) <= N){
			son = getLeft(p);
			if(getRight(p) <= N && A[Heap[son]] > A[Heap[getRight(p)]])
				son = getRight(p);
		}
		if(son){
			if(A[Heap[son]] < A[Heap[p]]){
				SWAP(Heap[son], Heap[p])
				Pos[Heap[son]] = son;
				Pos[Heap[p]] = p;
				p = son;
			}
			else
				son = 0;
		}
	}while(son);
}

void up(int p){
	while((p > 1) && (A[Heap[p]] < A[Heap[getParent(p)]])){
		SWAP(Heap[p], Heap[getParent(p)]);
		Pos[Heap[p]] = p;
		Pos[Heap[getParent(p)]] = getParent(p);
		p = getParent(p);
	}
}

void insert(int key){
	++N;
	A[N] = key;
	Heap[N] = N;
	Pos[N] = N;
	up(N);
}

void build_heap(){
	for(int i = N / 2; i > 0; --i)
		down(i);
}

void cut(int p){
	/*int pos = Pos[p];
	A[p] = -1;
	Pos[p] = -1;
	Heap[pos] = Heap[N];
	--N;

	if((pos > 1) && (A[Heap[pos]] < A[Heap[getParent(pos)]]))
		up(pos);
	else
		down(pos);*/
	A[p] = -1;
	up(Pos[p]);
	Pos[Heap[1]] = 0;
	Heap[1] = Heap[N--];
	Pos[Heap[1]] = 1;
	if(N>1)
			down(1);
}

int main(){
	freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);

	int M;
	scanf("%d", &M);
	for(int i = 0 ; i < M; ++i)	{
		int code, x;
		scanf("%d", &code);
		if(code == 1){
			scanf("%d", &x);
			insert(x);
		}
		else if(code == 2){
			scanf("%d", &x);
			cut(x);
		}
		else if(code == 3){
			printf("%d\n", getMin());
		}
	}
	return 0;
}
