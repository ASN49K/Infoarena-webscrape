#include <bits/stdc++.h>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

multiset < int > mset;
vector < int > pos;
int n, x, y;

int main() {
  f >> n;
  for (int i = 0; i < n; ++i) {
    f >> x;
    if (x == 1) {
      f >> y;
      mset.insert(y);
      pos.emplace_back(y);
    } 
    else if (x == 2) {
      f >> y;
      mset.erase(mset.find(pos[y - 1]));
    } 
    else {
      g << *mset.begin() << '\n';
    }
  }
}