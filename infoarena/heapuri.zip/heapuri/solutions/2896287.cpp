#include <fstream>
#include <vector>
#include <iostream>
using namespace std;




vector<int> heap(200010);      // heap[i] = indicele corespunzator valorii din v
vector<int> valori(200010);    // valorile in ordinea citirii
vector<int> pozitie(200010);   // pozitie[i] = pozitia in heap a valorii v[i]
int nr_valori, nr_heap;		// numarul de elemente respective

void urca(int nod)
{
	while (nod != 1 && valori[heap[nod]] < valori[heap[nod / 2]])
	{
		swap(heap[nod], heap[nod / 2]);
		pozitie[heap[nod]] = nod;
		pozitie[heap[nod / 2]] = nod / 2;
	}
}

void coboara(int nod)
{
	while (nod * 2 <= nr_heap && valori[heap[nod]] > valori[heap[nod * 2]])
	{
		swap(heap[nod], heap[nod * 2]);
		pozitie[heap[nod]] = nod;
		pozitie[heap[nod * 2]] = nod * 2;
	}
	while (nod * 2 + 1<= nr_heap && valori[heap[nod]] > valori[heap[nod * 2 + 1]])
	{
		swap(heap[nod], heap[nod * 2 + 1]);
		pozitie[heap[nod]] = nod;
		pozitie[heap[nod * 2]] = nod * 2 + 1;
	}
}

int main()
{
	ifstream f("heapuri.in");
	ofstream g("heapuri.out");
	int tip_operatie, valoare, nr_operatii, ordine;

	f >> nr_operatii;
	for (int i = 0; i < nr_operatii; i++)
	{
		f >> tip_operatie;
		if (tip_operatie == 1)
		{
			f >> valoare;
			nr_heap++;
			nr_valori++;

			valori[nr_valori] = valoare;
			pozitie[nr_valori] = nr_heap;
			heap[nr_heap] = nr_valori;


			urca(nr_heap);		// ajustam elementul introdus in heap pe ultima pozitie
			
		}
		else if (tip_operatie == 2)
		{
			f >> ordine;
			valori[ordine] = -1;
			heap[pozitie[ordine]] = heap[nr_heap];				// inlocuim ultimul element din heap cu al k-lea  element citit
			pozitie[heap[nr_heap]] = pozitie[ordine];
			nr_heap--;

			urca(pozitie[ordine]);					// reparam heap ul
			coboara(pozitie[ordine]);
			
		}
		else if (tip_operatie == 3)
		{
			g << valori[heap[1]] << "\n";
		}
	}


}
