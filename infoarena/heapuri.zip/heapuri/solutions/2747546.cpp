#include <iostream>
#include <fstream>
#include <set>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

set <int> heap;
int N, poz[200010], m, cod, x, i;

int main()
{
    f>>N;
    for(i = 1; i <= N; i++)
    {
        f >> cod;
        if(cod == 1)
        {
            f >> x;
            heap.insert(x);
            poz[++m] = x;
        }
        else if(cod == 2)
        {
            f >> x;
            heap.erase(poz[x]);
        }
        else
            g << *heap.begin() << '\n';
    }
    return 0;
}
