#include<cstdio>
#define DIM 200100
void read(),solve(),HeapUp(),HeapDown();
int n,i,A[DIM],H[DIM],poz[DIM],nr,t;
int main()
{
	read();
	solve();
	return 0;
}
void read()
{
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	scanf("%d",&n);
}
void solve()
{
	for(;n;n--)
	{
		scanf("%d",&t);
		if(t==1)HeapUp();
		if(t==2)HeapDown();
		if(t==3)printf("%d\n",A[H[1]]);
	}
}
void HeapUp()
{
	int aux;
	scanf("%d",&A[++i]);
	poz[i]=++nr;
	H[nr]=i;
	for(int cnt=nr;cnt>1;cnt/=2)
	{
		if(A[H[cnt]]<A[H[cnt/2]])
		{
			poz[H[cnt/2]]*=2;
			poz[H[cnt/2]]+=poz[H[cnt]]%2;
			poz[H[cnt]]/=2;
			aux=H[cnt];
			H[cnt]=H[cnt/2];
			H[cnt/2]=aux;
			continue;
		}
		break;
	}
}
void HeapDown()
{
	int aux,d,cnt;
	scanf("%d",&d);
	poz[H[nr]]=poz[d];
	H[poz[d]]=H[nr];
	H[nr]=0;
	--nr;
	cnt=poz[d];
		for(int cnt=poz[d];cnt>1;cnt/=2)
		{
			if(A[H[cnt]]<A[H[cnt/2]]&&A[H[cnt]])
			{
				poz[H[cnt/2]]*=2;
				poz[H[cnt/2]]+=poz[H[cnt]]%2;
				poz[H[cnt]]/=2;
				aux=H[cnt];
				H[cnt]=H[cnt/2];
				H[cnt/2]=aux;
				continue;
			}
			break;
		}
		for(int cnt=poz[d];(cnt*2)<=nr;cnt*=2)
		{
			if(A[H[cnt]]>A[H[cnt*2+1]]&&A[H[cnt*2]]>A[H[cnt*2+1]]&&A[H[cnt*2+1]])
			{
				poz[H[cnt]]*=2;
				++poz[H[cnt]];
				poz[H[cnt*2+1]]/=2;
				aux=H[cnt];
				H[cnt]=H[cnt*2+1];
				H[cnt*2+1]=aux;
				continue;
			}
			if(A[H[cnt]]>A[H[cnt*2]])
			{
				poz[H[cnt]]*=2;
				poz[H[cnt*2]]/=2;
				aux=H[cnt];
				H[cnt]=H[cnt*2];
				H[cnt*2]=aux;
				continue;
			}
			break;
		}
}
		

