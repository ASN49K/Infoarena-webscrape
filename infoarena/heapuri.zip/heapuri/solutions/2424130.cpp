#include <fstream>

using namespace std;
const int MAX=200006;
int n, h[MAX],cod,nr,v[MAX],poz[MAX],nh,nrel;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

void swapp(int p, int q)
{
   swap(h[p],h[q]);
   poz[h[p]]=p;
   poz[h[q]]=q;

}

void urca(int p)
{
    while(p>1 && v[h[p]]<v[h[p/2]])
    {
         swapp(p,p/2);
         p/=2;
    }
}
void adauga(int val)
{
    h[++nh]=val;
    poz[val]=nh;
    urca(nh);
}

void coboara(int p)
{
     int fs=2*p,fd=2*p+1,bun=p;

     if(fs<=nh && v[h[fs]]<v[h[bun]]) bun=fs;
     if(fd<=nh && v[h[fd]]<v[h[bun]]) bun=fd;

     if(bun!=p)
     {
        swapp(p,bun);
        coboara(bun);
     }

}

void sterge(int p)
{
     if(p!=nh)
     {
        h[p]=h[nh--];
        urca(p);
        coboara(p);

     }

     else nh--;


}


int main()
{
    in>>n;

    for(int i=1;i<=n;i++)
    {
       in>>cod;
       if(cod==1)
       {

          in>>v[++nrel];
          adauga(nrel);

       }

       if(cod==2)
       {
          in>>nr;
          sterge(poz[nr]);


       }

       if(cod==3)
       {
          out<<v[h[1]]<<"\n";

       }

    }
    return 0;
}
