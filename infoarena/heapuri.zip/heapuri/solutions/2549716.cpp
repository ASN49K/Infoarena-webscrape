#include<bits/stdc++.h>
#define maxn 200004
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int task,n,nmax,a,timp;
int heap[maxn],where[maxn],cronological[maxn];

void upcheck(int pos)
{
    int i=pos;
    while(i/2>0 && heap[i]<heap[i/2])
    {
        swap(heap[i],heap[i/2]);
        swap(where[cronological[i]],where[cronological[i/2]]);
        swap(cronological[i],cronological[i/2]);
        i/=2;
    }
}

void downcheck(int pos)
{
    int i=pos;
    while(1)
    {
        if(heap[i]>heap[2*i] && 2*i<=nmax)
        {
            swap(heap[i],heap[2*i]);
            swap(where[cronological[i]],where[cronological[2*i]]);
            swap(cronological[i],cronological[2*i]);
            i=i*2;
        }
        else if(heap[i]>heap[2*i+1] && 2*i+1<=nmax)
        {
            swap(heap[i],heap[2*i+1]);
            swap(where[cronological[i]],where[cronological[2*i+1]]);
            swap(cronological[i],cronological[2*i+1]);
            i=i*2+1;
        }
        else break;
    }
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>task;
        if(task==1)
        {
            fin>>a;
            heap[++nmax]=a;
            cronological[nmax]=++timp;
            where[timp]=nmax;
            upcheck(nmax);
        }
        if(task==2)
        {
            fin>>a;
            a=where[a];
            swap(heap[a],heap[nmax]);
            swap(where[cronological[a]],where[cronological[nmax]]);
            swap(cronological[a],cronological[nmax]);
            nmax--;
            downcheck(a);
            upcheck(a);
        }
        if(task==3)
        {
            fout<<heap[1]<<"\n";
        }
    }
}
