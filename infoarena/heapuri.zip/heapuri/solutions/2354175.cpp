#include <fstream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

const int MAXN = 200005;
int n, m;
int h[MAXN];
int poz[MAXN], p;

int father(int k) {
    return k / 2;
}

int left(int k) {
    return k * 2;
}

int right(int k) {
    return k * 2 + 1;
}

int down(int k) {
    bool ok = 1;
    while (ok > 0) {
        int f = 0;
        ok = 0;
        int l = left(k);
        int r = right(k);
        if (l <= n) {
            if (h[l] < h[k]) {
                ok = 1;
            }
        }
        if (r <= n) {
            if (ok == 1) {
                if (h[r] < h[l]) {
                    ok = 2;
                }
            }
            else {
                if (h[r] < h[k]) {
                    ok = 2;
                }
            }
        }
        if (ok == 1) {
            swap(h[k], h[l]);
            k = l;
        }
        else {
            swap(h[k], h[r]);
            k = r;
        }
    }
}

int up(int k) {
    while (k > 1 && h[k] < h[father(k)]) {
        swap(h[k], h[father(k)]);
        k = father(k);
    }
}

int main() {

    fin >> m;

    for (int i = 1; i <= m; ++i) {
        int cer;
        fin >> cer;
        if (cer == 1) {
            int k;
            fin >> k;
            h[++n] = k;
            poz[++p] = k;
            up(n);
        }
        else if (cer == 2) {
            int k;
            fin >> k;
            for (int j = 1; j <= n; ++j) {
                if (h[j] == poz[k]) {
                    h[j] = h[n];
                    n--;
                    if (j > 1 && h[father(j)] < h[j]) {
                        up(j);
                    }
                    else {
                        down(j);
                    }
                    j = n + 10;
                }
            }

        }
        else {
            fout << h[1] << '\n';
        }
    }

    fout.close();
    return 0;
}



