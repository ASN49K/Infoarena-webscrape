#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std;

#define INF (0x3f3f3f3f)
#define ZERO(x) ((x) & (-x))
#define Dim (1<<13)

int aib[200001],vec[200001];
char lin[Dim];
int t , nr , n , i , poz;

inline int query(int a,int b) {
    int vmin = INF;
    if(a>b) return vmin;

    for(int i = b ; i >= a ; )
        if(i - ZERO(i) + 1 >= a )
            vmin = min( vmin , aib[i]) , i -= ZERO(i);
        else
            vmin = min( vmin , vec[i]) , i--;

    return vmin;
}

inline void update(int p,int nr) {

    vec[p] = nr;

    aib[p] = min( query(p - ZERO(p) + 1 , p - 1 ) , vec[p] );

    for(int i = p + ZERO(p) ; i <= n ; i += ZERO(i) )
        aib[i] = min (vec[p] , min( query(p + 1 , i ) , query( i - ZERO(i) + 1  , p - 1 ) ) );

}

inline void cit(int &x){
	x=0;
	while (lin[poz]<'0' || lin[poz]>'9'){
          poz++;
	      if (poz == Dim) fread(lin, 1, Dim, stdin), poz=0;
    }
	while (lin[poz]>='0' && lin[poz]<='9'){
		x = 10*x+lin[poz++]-'0';
        if (poz == Dim) fread(lin, 1, Dim, stdin), poz=0;
	}
}


int main() {

    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);

    memset( aib , INF , sizeof(aib) );

    for( scanf("%d",&n) ,cit(t), i = 0 ; i<=n ; cit(t) ) {
        switch (t) {
                case 1 : {                    
                    i++;
                    cit(nr); update(i,nr);
                    break;
                }
                case 2 : {                    
                    cit(nr); update(nr,INF);
                    break;
                }
                case 3 : {                    
                    printf("%d\n",query(1,i));                    
                    break;
                }
        }
    }

    return 0;
}
