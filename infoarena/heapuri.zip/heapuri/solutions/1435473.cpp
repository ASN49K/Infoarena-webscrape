#include <fstream>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int n,nh,h[200010],v[200010],poz[200010];

void schimb(int p, int q)
{
    int aux=h[p];
    h[p]=h[q];
    h[q]=aux;
    poz[h[p]]=p;
    poz[h[q]]=q;
}

void urca(int p)
{
    while(p>1 && v[h[p]]<v[h[p/2]])
    {
        schimb(p,p/2);
        p/=2;
    }
}

void adaugaH(int x)
{
    h[++nh]=x;
    poz[x]=nh;
    urca(nh);
}

void coboara(int p)
{
    int fs=2*p,fd=2*p+1,bun=p;
    if(fs<=nh && v[h[fs]]<v[h[bun]])
        bun=fs;
    if(fd<=nh && v[h[fd]]<v[h[bun]])
        bun=fd;
    if(bun!=p)
    {
        schimb(p,bun);
        coboara(bun);
    }
}

void stergeH(int p)
{
    schimb(p,nh--);
    urca(p);
    coboara(p);
}

int main()
{
    int i,x,op;
    in>>n;
    int nr=0;
    for(i=1; i<=n; i++)
    {
        in>>op;
        if(op==3)
            out<<v[h[1]];
        if(op==1)
        {
            nr++;
            in>>v[nr];
            adaugaH(nr);
        }
        if(op==2)
        {
            in>>x;
            stergeH(poz[x]);
            out<<'\n';
        }
    }
    return 0;
}
