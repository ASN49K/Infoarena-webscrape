#include <stdio.h>
#include <stdlib.h>

void swap(int* a, int* b) {
	int temp = *a;
	*a = *b;
	*b = temp;
}

void insert(int* h, int val, int* last, int* tab, int* A) {
	*last = *last + 1;
	h[*last] = val;
	tab[h[*last]] = *last; 
	int pos = *last;
	while(pos > 1) {
		if(A[h[pos / 2]] > A[h[pos]]) {
			swap(&h[pos / 2], &h[pos]);
			tab[h[pos / 2]] = pos / 2;
			tab[h[pos]] = pos;
			pos = pos / 2;
		} else {
			break;
		}
	}
}

void delete(int* h, int pos, int* last, int* tab, int* A) {
	A[tab[h[pos]]] = 0;
	swap(&h[pos], &h[*last]);
	swap(&tab[h[pos]], &tab[h[*last]]);
	*last = *last - 1;
	while(pos > 1) {
		if(A[h[pos / 2]] > A[h[pos]]) {
			swap(&h[pos / 2], &h[pos]);
			swap(&tab[h[pos / 2]], &tab[h[pos]]);
			//tab[h[pos / 2]] = pos / 2;
			//tab[h[pos]] = pos;
			pos = pos / 2;
		} else {
			break;
		}
	}
	while(pos < *last) {
		if(2 * pos > *last) {
			break;
		} else if((2 * pos + 1) > *last) {
			if(A[h[2 * pos]] < A[h[pos]]) {
				swap(&h[2 * pos], &h[pos]);
				swap(&tab[h[2 * pos]], &tab[h[pos]]);
				//tab[h[2 * pos]] = 2 * pos;
				//tab[h[pos]] = pos;
				pos = 2 * pos;
			} else {
				break;
			}
		} else if((A[h[2 * pos]] < A[h[pos]]) || (A[h[2 * pos + 1]] < A[h[pos]])) {
			if(A[h[2 * pos]] < A[h[2 * pos + 1]]) {
				swap(&h[2 * pos], &h[pos]);
				swap(&tab[h[2 * pos]], &tab[h[pos]]);
				//tab[h[2 * pos]] = 2 * pos;
				//tab[h[pos]] = pos;
				pos = 2 * pos;
			} else {
				swap(&h[2 * pos + 1], &h[pos]);
				swap(&tab[h[2 * pos + 1]], &tab[h[pos]]);
				//tab[h[2 * pos + 1]] = 2 * pos + 1;
				//tab[h[pos]] = pos;
				pos = 2 * pos + 1;
			}
		} else {
			break;
		}
	}
}

int main() {
	FILE* fin = fopen("heapuri.in", "r");
	int n;
	fscanf(fin, "%d\n", &n);
	FILE* fout = fopen("heapuri.out", "w");
	
	int* heap = (int*)malloc(n * sizeof(int));
	int* tab = (int*)malloc((n + 1) * sizeof(int));
	int* A = (int*)malloc((n + 1) * sizeof(int));
	int last = 0;
	int N = 0;
	int i;
	int type, val;
	for(i=0; i<n; i++) {
		fscanf(fin, "%d ", &type);
		if(type == 1) {
			fscanf(fin, "%d\n", &val);
			N++;
			A[N] = val;
			insert(heap, N, &last, tab, A);
		} else if(type == 2) {
			fscanf(fin, "%d\n", &val);
			delete(heap, tab[val], &last, tab, A);
		} else {
			fprintf(fout, "%d\n", A[heap[1]]);
		}
	}
	
	free(A);
	free(tab);
	free(heap);
	fclose(fin);
	fclose(fout);
	return 0;
}