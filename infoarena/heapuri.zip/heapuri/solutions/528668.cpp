#include <cstdio>
#include <cassert>
#include <algorithm>
#define Nmax 200005
#define InFile "heapuri.in"
#define OutFile "heapuri.out"

using namespace std;

int n;
struct Tip {int is, v;} H[Nmax];
int pz[Nmax];

inline int fth (int k) {return k/2;}
inline int lson (int k) {return 2*k;}
inline int rson (int k) {return 2*k+1;}
void insert (Tip Key);
void cut (int k);
void percolate (int k);
void sift (int k);

int main()
{
  int i, ins, t, cod, x;
  Tip El;
  assert (freopen (InFile, "r", stdin));
  assert (freopen (OutFile, "w", stdout));
  scanf ("%d\n", &t);
  n=0; ins=1;
  for (i=1; i<=t; i++)
  {
    scanf ("%d ", &cod);
    if (cod == 1)
      scanf ("%d\n", &x), El.v=x, El.is=ins++, insert (El);
    if (cod == 2)
      scanf ("%d\n", &x), cut (pz[x]);
    if (cod == 3)
      printf ("%d\n", H[1].v);
  }
  return 0;
}

void insert (Tip Key)
{
  H[++n]=Key; pz[Key.is]=n;
  percolate (n);
}

void percolate (int k)
{
  Tip Key=H[k];
  k=n;
  while (k>1 && Key.v<H[fth(k)].v)
  {
    H[k]=H[fth(k)];
    pz[H[fth(k)].is]=k;
    k=fth(k);
    pz[Key.is]=k;
  }
  H[k]=Key;
}

void cut (int k)
{
  swap (H[k], H[n]);
  --n;
  if (k>1 && H[k].v<H[fth(k)].v)
    percolate (k);
  else
    sift (k);
}

void sift (int k)
{
  int son;
  do
  {
    son=0;
    if (lson (k)<=n)
    {
      son=lson (k);
      if (rson (k)<=n && (H[lson(k)].v>H[rson(k)].v))
        son=rson (k);
      if (H[son].v>H[k].v)
        son=0;
    }
    if (son)
    {
      swap (H[k], H[son]);
      pz[H[son].is]=k;
      k=son;
      pz[H[k].is]=k;
    }
  }
  while (son);
}
