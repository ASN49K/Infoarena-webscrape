#include<set>
#include<fstream>
using namespace std;
int n,k,x,y;
int l[100000];
set<int> V;
int main()
{ifstream f("heapuri.in");
ofstream g("heapuri.out");
f>>n;
for(int i=1;i<=n;++i)
  {f>>x;
  if(x==1)
   {f>>y;
   l[++k]=y;
   V.insert(y);}
   if(x==2)
    {f>>y;
    V.erase(l[y]);}
   if(x==3)
    g<<*V.begin()<<endl;}}
