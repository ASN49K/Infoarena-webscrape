#include <fstream>
#include <vector>
#include <utility>
#include <cstdlib>
#include <string>

using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

int n,a,b,i,k,j,m,l;
string s,szam;

struct adat
{
    int s,i;
};
vector<adat>x;

int y[200001];

void beszur(vector<adat>&x, int uj)
{
    x.push_back({uj,m});
   // x[x.size()-1].s=uj;
   // x[x.size()-1].i=m;
    int akt_poz=x.size()-1;
    y[m]=akt_poz;
    k=m;
    while(x[akt_poz / 2].s>x[akt_poz].s)
    {
        y[k]=akt_poz/2;
        y[x[akt_poz / 2].i]=akt_poz;
        swap(x[akt_poz / 2],x[akt_poz]);
        akt_poz/=2;
    }
}

void torol(vector<adat>&x,int poz)
{
    y[x[poz].i]=0;
    x[poz]=x.back();

    x.pop_back();
    int p=0;
    while(p!=poz)
    {
        p=poz;
        if(p*2<x.size() && x[p*2].s<x[poz].s)
            poz=p*2;
        if(p*2+1<x.size() && x[p*2+1].s<x[poz].s)
            poz=p*2+1;

        y[x[poz].i]=p;
        y[x[p].i]=poz;

        swap(x[poz],x[p]);
    }
}

int main()
{
    cin>>n;
    x.push_back({0,0});
    for(i=1;i<=n;i++)
    {
        cin>>a;
        if(a==1)
        {
            cin>>b;
            m++;
            beszur(x,b);
        }
        if(a==2)
        {
            cin>>b;

            torol(x,y[b]);

            l=0;

        }
        if(a==3)
            cout<<x[1].s<<"\n";

        //for(j=1;j<=m;j++) cout<<y[j]<<" ";
        //cout<<"\n";
    }

    return 0;
}
