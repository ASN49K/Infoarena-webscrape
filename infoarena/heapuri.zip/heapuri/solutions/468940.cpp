#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std;

#define INF (0x3f3f3f3f)
#define ZERO(x) ((x) & (-x))

int aib[200001],vec[200001];
int t , nr , n , i ;


inline int query(int a,int b) {
    int vmin = INF;
    if(a>b) return vmin;

    for(int i = b ; i >= a ; )
        if(i - ZERO(i) + 1 >= a )
            vmin = min( vmin , aib[i]) , i -= ZERO(i);
        else
            vmin = min( vmin , vec[i]) , i--;

    return vmin;
}



inline void update(int p,int nr) {

    vec[p] = nr;

    aib[p] = min( query(p - ZERO(p) + 1 , p - 1 ) , vec[p] );

    for(int i = p + ZERO(p) ; i <= n ; i += ZERO(i) )
        aib[i] = min (vec[p] , min( query(p + 1 , i ) , query( i - ZERO(i) + 1  , p - 1 ) ) );

}

int main() {

    freopen("heap.in","r",stdin);
    freopen("heap.out","w",stdout);

    memset( aib , INF , sizeof(aib) );

    for( scanf("%d",&n) , i = 0 ; scanf("%d",&t) ; ) {
        switch (t) {
                case 1 : {
                    printf("Op 1\n");
                    i++;
                    scanf("%d",&nr); update(i,nr);
                    break;
                }
                case 2 : {
                    printf("Op 2\n");
                    scanf("%d",&nr); update(nr,INF);                    
                    break;
                }
                case 3 : {
                    printf("Op 3\n");
                    printf("%d\n",query(1,i));                    
                    break;
                }
        }
        if(i >n) break;
    }

    return 0;
}
