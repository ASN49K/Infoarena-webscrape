#include <bits/stdc++.h>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int a[200001],poz[200001],heap[200001],k=0;
int len=0;

void add(int x)
{
	int current=x;
	while(a[heap[current/2]]>a[heap[current]] && current/2>0)
	{
		swap(heap[current],heap[current/2]);
		current/=2;
	}
}

void del(int x)
{
	int y=0;
	while(y!=x)
	{
		y=x;
		if(y*2<=len && a[heap[1]]>a[heap[y*2]]) x=y*2;
		if(y*2+1<=len && a[heap[1]]>a[heap[y*2+1]]) x=y*2+1;
		swap(heap[x],heap[y]);
		poz[heap[x]]=x;
		poz[heap[y]]=y;
	}
}

void first(int x)
{
	k++;
	len++;
	int current=len;
	a[k]=x;
	heap[len]=k;
	poz[k]=len;
	while(a[heap[current/2]]>a[heap[current]] && current/2>0)
	{
		swap(heap[current],heap[current/2]);
		current/=2;
	}
}

void second(int x)
{	
	a[x]=-1;
	add(poz[x]);
	poz[heap[1]]=0;
	heap[1]=heap[len];
	len--;
	poz[heap[1]]=1;
	if(len>1) del(1);
}


int main()
{
	int n;
	in>>n;
	for(int i=1;i<=n;i++)
	{
		int cod,x;
		in>>cod;
		if(cod==1||cod==2)
		{
			in>>x;
		}
		if(cod==1)
		{
			first(x);
		}
		else if(cod==2)
			second(x);
		else if(cod==3)
		{
			while(heap[1]==-1)
				del(heap[1]);
			out<<a[heap[1]]<<"\n";
		}
		for(int i=1;i<=len;i++)
			cout<<a[heap[i]]<<" ";
		cout<<endl;
	}
	return 0;
}
