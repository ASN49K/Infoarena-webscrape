#include <cstdio>
#include <algorithm>

using namespace std;

int h[200001],poz[200001],ord[200001],n,cod,cnt,lng,i,x;

void up(int ind)
{
    if(ind>1 && h[ind]<h[ind/2])
    {
        swap(h[ind],h[ind/2]);
        swap(ord[ind],ord[ind/2]);
        swap(poz[ord[ind]],poz[ord[ind/2]]);
        up(ind/2);
    }
}

void down(int ind)
{
    if(ind*2<lng)
    {
        if(h[ind*2]<h[ind*2+1] && h[ind]>h[ind*2])
        {
            swap(h[ind],h[ind*2]);
            swap(ord[ind],ord[ind*2]);
            swap(poz[ord[ind]],poz[ord[ind*2]]);
            down(ind*2);
        }
        if(h[ind*2]>=h[ind*2+1] && h[ind]>h[ind*2+1])
        {
            swap(h[ind],h[ind*2+1]);
            swap(ord[ind],ord[ind*2+1]);
            swap(poz[ord[ind]],poz[ord[ind*2+1]]);
            down(ind*2);
        }
    }
    if(ind*2==lng && h[ind]>h[ind*2])
    {
        swap(h[ind],h[ind*2]);
        swap(ord[ind],ord[ind*2]);
        swap(poz[ord[ind]],poz[ord[ind*2]]);
    }
}



int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);

    int ind;

    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        scanf("%d",&cod);
        if(cod==1)
        {
            scanf("%d",&x);
            cnt++;
            lng++;
            h[lng]=x;
            ord[lng]=cnt;
            poz[cnt]=lng;
            up(lng);
        }

        if(cod==2)
        {
            scanf("%d",&x);
            ind=poz[x];
            swap(h[ind],h[lng]);
            swap(ord[ind],ord[lng]);
            swap(poz[ord[ind]],poz[ord[lng]]);
            lng--;
            down(ind);
        }

        if(cod==3) printf("%d\n",h[1]);
    }
}
