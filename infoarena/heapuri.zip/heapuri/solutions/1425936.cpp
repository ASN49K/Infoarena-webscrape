#include <iostream>
#include <stdio.h>
using namespace std;

const int N=200001;
 int h[2*N],poz[N],v[N],n,nh;

void afisare(FILE * out){
    fprintf(out,"%d\n",v[h[1]]);

}

void schimb( int p1, int p2){
    int aux=h[p1];
    h[p1]=h[p2];
    h[p2]=aux;
    poz[h[p1]]=p1;
    poz[h[p2]]=p2;
}

void urca (int p){
    while(p>1&&v[h[p]]<v[h[p/2]]){
        schimb(p,p/2);
        p/=2;
    }
}

void adauga (int x){
    h[++nh]=x;
    poz[x]=nh;
    urca( nh );

}
void coboara( int p ){
    int fs=2*p, fd=2*p+1, bun=p;
    if(fs<=nh && v[h[fs]]<v[h[bun]]) bun=fs;
    if(fd<=nh && v[h[fd]]<v[h[bun]]) bun=fd;
    if(bun!=p) {
        schimb( bun, p ); coboara ( bun );
    }

}

void sterge(int p ){
    schimb( p, nh-- );
    urca( p );
    coboara ( p );
}

void citire(){
    FILE * in, *out;
    int c,a,cnt=0;
    in=fopen("heapuri.in","r");
    out=fopen("heapuri.out","w");
    fscanf(in,"%d",&n);
    for(int i=1;i<=n;i++){
        fscanf(in,"%d",&c);
        if(c==3) afisare(out);
        else {

            fscanf(in,"%d",&a);
            if(c==1) {cnt++;v[cnt]=a;adauga(cnt);}
            else sterge(poz[a]);
        }

    }

}

int main()
{
    citire();

    return 0;
}
