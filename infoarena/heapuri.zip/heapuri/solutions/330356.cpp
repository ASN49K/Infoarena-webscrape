#include <iostream.h>
#include <stdio.h>
#define nmax 200001

long int n,heap[nmax],numere[nmax],noduri[nmax],var,heapnum,nrnum,i,tip;

void urca(long int nod)
      {long int cheie,aux;
      cheie=numere[heap[nod]];
      while(nod>1 && cheie<numere[heap[nod/2]])
		    {aux=heap[nod];heap[nod]=heap[nod/2];heap[nod/2]=aux;
		    noduri[heap[nod]]=nod;
		    noduri[heap[nod/2]]=nod/2;
		    nod/=2;
		    }
      }
void coboara(long int nod)
     {long int nodfiu=0,aux;
      while(nod!=nodfiu)
		     {nodfiu=nod;
		      if(nodfiu*2<=heapnum && numere[heap[nod]]>numere[heap[nodfiu*2]]) nod=nodfiu*2;
		      if(nodfiu*2+1<=heapnum && numere[heap[nod]]>numere[heap[nodfiu*2+1]]) nod=nodfiu*2+1;
		      aux=heap[nod];heap[nod]=heap[nodfiu];heap[nodfiu]=aux;
		      noduri[heap[nod]]=nodfiu;
		      noduri[heap[nodfiu]]=nod;
		      nod/=2;
		      }
     }
void del(long int nod)
     {heap[nod]=heap[heapnum--];
      urca(nod);coboara(nod);
     }
int main()
    {freopen("heapuri.in","r",stdin);freopen("heapuri.out","w",stdout);
    scanf("%ld",&n);
    for(i=1;i<=n;i++)
	       {scanf("%ld",&tip);
	        if(tip==3)  printf("%ld\n",numere[heap[1]]);
	        else
		           {scanf("%ld",&var);
		            if(tip==1)     {numere[++nrnum]=var;
		                            heap[++heapnum]=nrnum;
		                            noduri[nrnum]=heapnum;
		                            urca(heapnum);
                                    }
                    else           {del(noduri[var]);}
                   }
           }
    fclose(stdin);fclose(stdout);
    return 0;
    }

