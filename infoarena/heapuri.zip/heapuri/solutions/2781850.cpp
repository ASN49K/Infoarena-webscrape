#include <fstream>

using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

int n,elemente,nrElementeHeap;
int heap[200001], pozHeap[200001], vecInitial[200001];

void heapDown(int pozitie)
{
    while(2*pozitie<=nrElementeHeap)
    {
        int t=pozitie;
        if(vecInitial[heap[t]]>vecInitial[heap[2*pozitie]])
        {
            t=2*pozitie;
        }
        if(2*pozitie+1<=nrElementeHeap &&
                vecInitial[heap[t]]>vecInitial[heap[2*pozitie+1]])
        {
            t=2*pozitie+1;
        }
        if(t!=pozitie)
        {
            //interschimb
            swap(heap[t],heap[pozitie]);
            pozHeap[heap[t]]=t;
            pozHeap[heap[pozitie]]=pozitie;
            pozitie=t;
        }
        else
        {
            break;
        }
    }
}


int heapUp(int pozitie)
{
    int t=pozitie;
    while(t/2>=1 && vecInitial[heap[t/2]]>vecInitial[heap[t]])
    {
        //fac interschimbarea in heap
        swap(heap[t/2],heap[t]);
        pozHeap[heap[t/2]]=t/2;
        pozHeap[heap[t]]=t;
        t/=2;
    }
    return t;
}

void eliminHeap(int pozitie)
{
    heap[pozitie]=heap[nrElementeHeap--];
    pozitie=heapUp(pozitie);
    heapDown(pozitie);
}

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        int op,x;
        fin>>op;
        if(op==1)
        {
            fin>>x;
            vecInitial[++elemente]=x;
            heap[++nrElementeHeap]=elemente;
            pozHeap[elemente]=nrElementeHeap;

            //fac urcare
            heapUp(nrElementeHeap);
        }
        else if(op==3)
        {
            fout<<vecInitial[heap[1]]<<"\n";
        }
        else
        {

            fin>>x;
            eliminHeap(pozHeap[x]);
        }
    }
    /*for(int i=1; i<=nrElementeHeap; i++)
    {
        fout<<heap[i]<<" ";

    }
    fout<<"\n";
    for(int i=1; i<=nrElementeHeap; i++)
    {
        fout<<vecInitial[heap[i]]<<" ";

    }*/

    return 0;
}
