#include <iostream>
#include <fstream>
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

struct numar {
    int nr, id;
};

int n;
numar a[200010];
int k;

void operatie1 () {
    n++;
    f >> a[n].nr;

    k++;
    a[n].id = k;

    int i = n;
    while (a[i].nr < a[i / 2].nr) {
        numar aux;
        aux = a[i];
        a[i] = a[i / 2];
        a[i / 2] = aux;

        i = i / 2;
    }
}

void operatie2 () {
    int nr;
    f >> nr;

    for (int i = 1; i <= n; i++) {
        if (a[i].id == nr) {
            a[i] = a[n];

            while ((a[i].nr > a[i * 2].nr || a[i].nr > a[i * 2 + 1].nr) && (i * 2 < n)) {
                if (a[i * 2].nr > a[i * 2 + 1].nr && i * 2 + 1 > 0)
                {
                    numar aux;
                    aux = a[i];
                    a[i] = a[i * 2 + 1];
                    a[i * 2 + 1] = aux;
                    i = i * 2 + 1;
                }
                else {
                    numar aux;
                    aux = a[i];
                    a[i] = a[i * 2];
                    a[i * 2] = aux;
                    i = i * 2;
                }
            }

            break;
        }
    }
    n--;
}

void operatie3 () {
    g << a[1].nr << '\n';
}

int main()
{
    int t;
    f >> t;
    for (int i = 1; i <= t; i++) {
        int ID;
        f >> ID;

        if (ID == 1) {
            operatie1();
        }

        if (ID == 2) {
            operatie2();
        }
        if (ID == 3) {
            operatie3();
        }
    }

    return 0;
}
