#include <fstream>
#include <set>
#include <unordered_map>

using namespace std;
multiset <int> multiSet; //ordered
unordered_map <int, int> myMap; 



int main() {
	ifstream f("heapuri.in");
	ofstream g("heapuri.out");
	int n, op, x;
	f >> n;
	int nr = 0;
	while (n--) {
		f >> op;
		if (op == 1) {
			f >> x;
			multiSet.insert(x);
			myMap[++nr] = x;
		}
		else {
			if (op == 2) {
				f >> x;
				multiSet.erase(myMap[x]);
				myMap.erase(x);
			}
			else {
				g << *multiSet.begin() << "\n";
			}
		}
	}
	
	f.close();
	g.close();
	return 0;
}