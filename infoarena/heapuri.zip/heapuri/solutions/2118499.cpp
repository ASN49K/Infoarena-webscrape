#include <bits/stdc++.h>

using namespace std;
int Heap[200001],n,len,cron[200001],i,c,j,x,ord;
inline int father(int nod)
{
    return nod/2;
}
inline int leftson(int nod)
{
    return 2*nod;
}
inline int rightson(int nod)
{
    return 2*nod+1;
}
int nxtson(int nod)
{
    if(Heap[leftson(nod)]<Heap[nod])
        if(Heap[rightson(nod)]>=Heap[leftson(nod)]) return leftson(nod);
    if(Heap[rightson(nod)]<Heap[nod])
        if(Heap[rightson(nod)]<=Heap[leftson(nod)]) return rightson(nod);
     return 0;

}
int down(int nod)
{
    int son=nxtson(nod);
    while(Heap[son])
    {

        swap(Heap[son],Heap[nod]);
        swap(cron[son],cron[nod]);
        nod=son;
        son=nxtson(nod);
    }

}
int up(int nod)
{
    int dad=father(nod);
    while(Heap[nod]<Heap[dad]&&dad)
    {
        swap(Heap[nod],Heap[dad]);
        swap(cron[nod],cron[dad]);
        nod=dad;
        dad=father(nod);
    }
}
int del(int nod)
{
    Heap[nod]=Heap[len];
    len--;
    if(Heap[nod]<Heap[father(nod)]) up(nod);
    else
        if(nxtson(nod)) down(nod);
}
int add(int val)
{
    Heap[++len]=val;
    cron[len]=++ord;
    if(Heap[len]<Heap[father(len)]) up(len);
    else
        if(nxtson(len)) down(len);
}
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&c);
        if( c == 1)
        {
            scanf("%d",&x);
            add(x);
        }
        if( c == 2)
        {
            scanf("%d",&x);
            for(j=1;j<=len;j++)
            if(cron[j]==x)
            {
                del(j);
                break;

            }

        }
        if ( c == 3)
        printf("%d\n",Heap[1]);
    }


    return 0;
}
