#include <iostream>
#include <fstream>

std::ifstream in("heapuri.in");
std::ofstream out("heapuri.out");

const int N=200000;

/// heap[i] reprezinta al catelea elem adaugat este curent pe pozitia i din heap
int heap[N+1];

/// pos[i] reprezinta pe ce pozitie din heap de afla al i-lea element adaugat
int pos[N+1];

/// valorile elementelor adaugate
int val[N+1];

/// marimea curenta a heap-ului
int size=0;

///contor universal
int nr=0;

void swap(int i, int j)
{
    int indi=heap[i];
    int indj=heap[j];

    heap[i]=indj;
    pos[indj]=i;

    heap[j]=indi;
    pos[indi]=j;
}

void up(int i)
{
    if(val[heap[i]]<val[heap[i/2]])
    {
        swap(i, i/2);
        up(i/2);
    }
}

void down(int i)
{
    if(i*2<=size)
    {
        if(i*2+1<=size)
        {
            if(val[heap[i]] > std::min(val[heap[i*2]], val[heap[i*2+1]]) )
            {
                if(val[heap[i*2]] < val[heap[i*2+1]])
                {
                    swap(i*2, i);
                    down(i*2);
                }
                else
                {
                    swap(i*2+1, i);
                    down(i*2+1);
                }
            }
        }
        else
        {
            if(val[heap[i]]>val[heap[i*2]])
            {
                swap(i*2, i);
                down(i*2);
            }
        }
    }
}

int main()
{
   int n, c, x;
   in>>n;
   for(int i=1; i<=n; i++)
   {
       in>>c;

       if(c==1)
       {
           in>>x;
           val[++nr]=x;

           size++;
           heap[size]=nr;
           pos[nr]=size;

           up(size);
       }
       if(c==2)
       {
           in>>x;
           int it=pos[x];

           swap(pos[x], size);
           size--;

           up(it);
           down(it);
       }
       if(c==3)
       {
           out<<val[heap[1]]<<"\n";
       }
   }
}
