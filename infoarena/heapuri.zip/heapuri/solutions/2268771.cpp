#include <iostream>
#include <stdio.h>

using namespace std;

const int NMAX = 200001;

int nh, v[NMAX], poz[NMAX], h[NMAX];

void swapp (int p, int q) {
    swap (h[p], h[q]);
    poz[h[p]] = p;
    poz[h[q]] = q;
}

 void urca (int p) {
    while (p > 1 && v[h[p]] < v[h[p / 2]]) {
        swapp (p, p / 2);
        p /= 2;
    }
 }

 void adauga (int val) {
    h[++nh] = val;
    poz [val] = val;
    urca (nh);
 }

 void coboara (int p) {
    int fs, fd, bun;
    fs = 2 * p;
    fd = 2 * p + 1;
    bun = p;
    if (fs <= nh && v[h[fs]] < v[h[bun]])
        bun = fs;
    if (fd <= nh && v[h[fd]] < v[h[bun]])
        bun = fd;
    if (bun != p) {
        swapp (p, bun);
        coboara (bun);
    }
 }

 void sterge (int p) {
    if (p < nh) {
        h[p] = h[nh--];
        urca (p);
        coboara (p);
    }
    else
        nh--;
 }

int main() {

    freopen ("heapuri.in", "r", stdin);
    freopen ("heapuri.out", "w", stdout);

    int n, nr, tip, p, val, i;

    scanf ("%d", &n);
    nr = 0;
    for (i = 1; i <= n; i++) {
        scanf ("%d", &tip);
        if (tip == 1) {
            scanf ("%d", &val);
            v[++nr] = val;
            adauga (nr);
        }
        if (tip == 2) {
            scanf ("%d", &p);
            sterge (poz[p]);
        }
        if (tip == 3)
            printf ("%d\n", v[h[1]]);
    }

    return 0;
}
