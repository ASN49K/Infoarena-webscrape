#include<fstream>
#include<algorithm>
#define f first
#define s second
using namespace std;
int n, i, st, dr, p, c, nr, j;
int h[4002], poz[4002], a[4003];
pair<int, int> v[4002], sol[4002];
struct interv{
    int x;
    int y;
    int pos;
};
interv w[4002];
int cmp(interv a, interv b){
    return a.x < b.x;
}
ifstream fin("motel.in");
ofstream fout("motel.out");
int main(){
    fin>> n;
    for(i = 1; i <= n; i++){
        fin>> w[i].x >> w[i].y;
        w[i].pos = i;
    }
    sort(w + 1, w + n + 1, cmp);
    for(i = 1; i <= n; i++){
        fin>> v[i].f;
        v[i].s = i;
    }
    sort(v + 1, v + n + 1);
    st = dr = 1;
    for(i = 1; i <= n; i++){
        for(j = 1; j <= nr; j++){
            if(a[j] == 0 && w[j].y < v[i].f){
                p = poz[j];
                c = 2 * p;
                w[j].y = 1000000;
                while(c <= nr && w[h[c]].y < w[h[p]].y){
                    if(c + 1 <= nr && w[h[c + 1]].y <= w[h[c]].y){
                        c++;
                    }
                    swap(h[p], h[c]);
                    poz[h[p]] = p;
                    poz[h[c]] = c;
                    p = c;
                    c = 2 * p;
                }
            }
        }
        while(w[dr].x <= v[i].f && dr <= n){
            nr++;
            h[nr] = dr;
            c = nr;
            p = c / 2;
            while(p > 0 && w[h[c]].y < w[h[p]].y){
                 swap(h[p], h[c]);
                 poz[h[p]] = p;
                 poz[h[c]] = c;
                 c = p;
                 p = c / 2;
            }
            dr++;
        }
        if(nr == 0){
            fout<<"0 0\n";
            return 0;
        }
        sol[i].first = w[h[1]].pos;
        sol[i].second = v[i].s;
        w[h[1]].y = 1000000;
        a[h[1]] = 1;
        h[1] = h[nr];
        nr--;
        p = 1;
        c = 2;
        while(c <= nr && w[h[c]].y < w[h[p]].y){
            if(c + 1 <= nr && w[h[c + 1]].y < w[h[c]].y){
                c++;
            }
            swap(h[p], h[c]);
            poz[h[p]] = p;
            poz[h[c]] = c;
            p = c;
            c = 2 * p;
        }
    }
    for(i = 1; i <= n; i++){
        fout<< sol[i].f <<" "<< sol[i].s <<"\n";
    }
    return 0;
}
