#include <stdio.h>
#include <queue>
#include <unordered_set>
using namespace std;

FILE *fin, *fout;

vector<int> added;
priority_queue<int, vector<int>, greater<>> pq;
unordered_set<int> lazy;

void push(int x) {
	if (lazy.count(x))
		lazy.erase(x);
	added.push_back(x);
	pq.push(x);
}

void pop(int x) {
	lazy.insert(added[x-1]);
}

int query() {
	while (!pq.empty() && lazy.count(pq.top())) {
		pq.pop();
	}
	return pq.top();
}

int main(void) {
	fin = fopen("heapuri.in", "r");
	int n;
	fscanf(fin, "%d", &n);
	added.reserve(n);
	fout = fopen("heapuri.out", "w");
	for (int i = 0; i < n; ++i) {
		int op;
		fscanf(fin, "%d", &op);
		if (op < 3) {
			int x;
			fscanf(fin, "%d", &x);
			if (op == 1) {
				push(x);
			} else {
				pop(x);
			}
		} else {
			fprintf(fout, "%d\n", query());
		}
	}

	fclose(fin);
	fclose(fout);

	return 0;
}