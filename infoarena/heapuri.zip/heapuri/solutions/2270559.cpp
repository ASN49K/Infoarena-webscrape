#include <fstream>
#define INF 1000000006
using namespace std;

ifstream f ("heapuri.in");
ofstream g ("heapuri.out");

int q, tip, val, n, k;

int H[200005];

int v[200005];

bool used[200005];

void HeapUp (int x)
{
    if (x > 1)
    {
        if (v[H[x]] < v[H[x / 2]])
        {
            swap(H[x], H[x / 2]);
            HeapUp(x / 2);
        }
    }
}

void HeapDown (int x)
{
    int st = 0, dr = 0;
    if (2 * x <= n)
    {
        st = v[H[2 * x]];
        if (2 * x + 1 <= n)
            dr = v[H[2 * x + 1]];
        else dr = st + 1;

        if (st < dr)
        {
            swap(H[x], H[2*x]);
            HeapDown(2 * x);
        }
        else
        {
            swap(H[x], H[2 * x + 1]);
            HeapDown(2 * x + 1);
        }
    }
}
int main()
{
    f >> q;

    for (; q; q--)
    {
        f >> tip;

        if (tip == 1)
        {
            f >> val;
            n++;
            v[n] = val;
            H[n] = n;
            HeapUp(n);
        }
        else if (tip == 2)
        {
            f >> val;
            used[val] = true;
        }
        else
        {
            while (used[H[1]] == true)
                HeapDown(1);

            g << v[H[1]] << '\n';
        }
    }
    return 0;
}
