#include <iostream>
#include <queue>

using namespace std;

struct elem {
    int val;
    bool operator <(const elem& other) const {
        return val > other.val;
    }
};

priority_queue <elem> pq, s;

int v[200001];

int main() {
    int n, task, i = 0;
    cin >> n;
    elem x;

    while(n--) {
        cin >> task;

        if(task == 1) {
            cin >> x.val;
            i++;
            v[i] = x.val;
            pq.push(x);
        }
        else if(task == 2) {
            int indice;
            cin >> indice;
            x.val = v[indice];
            s.push(x);
            while(s.top().val == pq.top().val) {
                pq.pop();
                s.pop();
            }
        }
        else if(task == 3)
            cout << pq.top().val << endl;

    }
    return 0;
}