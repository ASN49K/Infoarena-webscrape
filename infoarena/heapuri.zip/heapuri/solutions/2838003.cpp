#include <iostream>
#include <fstream>

std::ifstream in("heapuri.in");
std::ofstream out("heapuri.out");

const int N=200010;

/// heap[i] reprezinta al catelea elem adaugat este curent pe pozitia i din heap
int heap[N+1];

/// pos[i] reprezinta pe ce pozitie din heap de afla al i-lea element adaugat
int pos[N+1];

/// valorile elementelor adaugate
int val[N+1];

/// marimea curenta a heap-ului
int size=0;

///contor universal
int nr=0;

void up(int i)
{
    if(i==1) return;

    if(val[heap[i/2]] > val[heap[i]])
    {
        int tata=heap[i/2];
        int copil=heap[i];

        heap[i]=tata;
        pos[tata]=i;

        heap[i/2]=copil;
        pos[copil]=i/2;

        up(i/2);
    }
}

void down(int i)
{
    if(i*2+1<=size)
    {
        if(val[heap[i]]>std::min(val[heap[i*2]], val[heap[i*2+1]]))
        {
            if(val[heap[i*2]]<=val[heap[i*2+1]])
            {
                int tata=heap[i];
                int copil=heap[i*2];

                heap[i]=copil;
                pos[copil]=i;

                heap[i*2]=tata;
                pos[tata]=i*2;

                down(i*2);
            }
            else
            {
                int tata=heap[i];
                int copil=heap[i*2+1];

                heap[i]=copil;
                pos[copil]=i;

                heap[i*2+1]=tata;
                pos[tata]=i*2+1;

                down(i*2+1);
            }
        }
    }
}

int main()
{
    int n, c, x;

    in>>n;
    for(int i=1; i<=n; i++)
    {
        in>>c;

        if(c==1)
        {
            in>>x;

            size++;
            val[++nr]=x;

            heap[size]=nr;
            pos[nr]=size;

            up(size);
        }
        if(c==2)
        {
            in>>x;

            int it;
            it=pos[x];

            heap[it]=heap[size];
            size--;

            up(it);
            down(it);
        }
        if(c==3)
        {
            out<<val[heap[1]]<<"\n";
        }
    }
}
