#include <stdio.h>
#define nmax 200001

typedef struct {
  int val;
  int contor;
} heap;

heap v[nmax];
int poz_heap, co;

int urcare_heap( int poz ) {
  heap aux;
  while ( poz / 2 > 0 && v[ poz / 2 ].val > v[ poz ].val ) { ///interschimbam elementul cu tatal sau
    aux = v[ poz / 2 ];
    v[ poz / 2 ] = v[poz];
    v[poz] = aux;
    poz /= 2;
  }
  return poz;
}

int coborare_heap( int poz ) {
  heap aux;
  while ( ( poz * 2 <= poz_heap && v[ poz * 2 ].val < v[poz].val ) ||  ( ( poz * 2 + 1 ) <= poz_heap && v[ poz * 2 + 1 ].val < v[poz].val ) ) {
    if ( v[ poz * 2 ].val < v[poz].val ) {
      aux = v[ poz * 2 ];
      v[ poz * 2 ] = v[poz];
      v[poz] = aux;
      poz *= 2;
    }
    else {
      aux = v[ poz * 2 + 1 ];
      v[ poz * 2 + 1 ] = v[poz];
      v[poz] = aux;
      poz = poz * 2 + 1;
    }
  }
  return poz;
}

void inserare_heap( int nr ) {
  int poz;
  poz_heap++;
  v[poz_heap].val = nr; ///inseram nr pe ultima pozitie in heap
  v[poz_heap].contor = ++co;
  poz = poz_heap;
  poz = urcare_heap( poz );
  poz = coborare_heap( poz );
}

void stergere_heap( int ordin_insertie ) {
  int i, poz;
  heap aux;
  i = 1;
  while( i <= poz_heap && ordin_insertie != v[i].contor )
    i++;
  if ( i <= poz_heap ) {
    aux = v[i];
    v[i] = v[poz_heap];
    v[poz_heap] = aux;
    poz_heap--;
    poz = i;
    poz = urcare_heap( poz );
    poz = coborare_heap( poz );
  }
}

int main() {
  int n, i, ver, nr;
  FILE *fin, *fout;
  fin = fopen( "heapuri.in", "r" );
  fout = fopen( "heapuri.out", "w" );
  fscanf( fin, "%d", &n );
  for ( i = 0; i < n; i++ ) {
    fscanf( fin, "%d", &ver );
    if ( ver == 3 )
      fprintf( fout, "%d\n", v[1].val );
    else {
      fscanf( fin, "%d", &nr );
      if ( ver == 1 )
        inserare_heap( nr );
      else
        stergere_heap( nr );
    }
  }
  fclose( fin );
  fclose( fout );
  return 0;
}
