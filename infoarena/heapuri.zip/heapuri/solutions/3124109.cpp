#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
// #include <queue>

std::ifstream fin("heapuri.in");
std::ofstream fout("heapuri.out");

int main()
{
    // std::priority_queue<int, std::vector<int>, std::greater<int>> minHeap;
    std::vector<int> vec;
    std::vector<int> minHeap;
    int n, operation, value, cnt = 0;
    fin >> n;

    for (int i = 0; i < 9; ++i) {
        fin >> operation;
        
        if (operation == 1) {
            fin >> value;
            vec.push_back(value);
        }// 7 9 2
        else if (operation == 2) {
            fin >> value;
            vec.erase(vec.begin() + value -1 - cnt);   
            ++cnt;         
        }
        else if (operation == 3) {
            // for(auto h : vec) {
            //     std::cout << h <<' ';
            // }
            minHeap = vec;
            std::make_heap(minHeap.begin(), minHeap.end(), std::greater<int>());
            fout << minHeap[0] << '\n';
        }
    }

    return 0;
}
