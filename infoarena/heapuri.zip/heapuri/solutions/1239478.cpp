#include <cstdio>
#include <algorithm>
using namespace std;
struct da
{
    int val,poz;
};
da a[200001];
int n,instr,com,poz[200001],i,x,xx;
void swapp(int t,int f)
{
    swap(poz[a[t].poz],poz[a[f].poz]);
    swap(a[t],a[f]);
}
void heapup(int nn)
{
    if (nn<=1)  return ;
    if (a[nn/2].val>a[nn].val)
    {
        swapp(nn/2,nn);
        heapup(nn/2);
    }
}
void heapdown(int n,int r)
{
    int st,dr;
    if (2*r<=n)
    {
        st=a[2*r].val;
        if (2*r+1<=n)dr=a[2*r+1].val;
        else dr=-1;
        if (st<dr||(st>dr&&dr==-1)||st==dr)
        {
            if (a[2*r].val<a[r].val)
            {
                swapp(r,2*r);
                heapdown(n,2*r);
            }
        }
        else if (st>dr&&dr!=-1)
        {
            if (a[2*r+1].val<a[r].val)
            {
                swapp(r,2*r);
                heapdown(n,2*r+1);
            }
        }
    }
}
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d ",&instr);
    for (i=1; i<=instr; i++)
    {
        scanf("%d ",&com);
        if (com==1)
        {
            scanf("%d ",&x);
            a[++n].val=x;
            a[n].poz=n;
            poz[n]=n;
            heapup(n);
        }
        else if (com==2)
        {
            scanf("%d ",&x);
            xx=poz[x];
            swap(poz[x],poz[a[n].poz]);
            swap(a[xx],a[n]);
            n--;
            heapdown(n,xx);
        }
        else if (com==3)
        {
            printf("%d\n",a[1]);
        }

    }
    return 0;
}
