# include <iostream>
# include <fstream>
# include <set>
# include <vector>
using namespace std;

typedef multiset <int> :: iterator iter;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

multiset<int> heap;
vector<int> elem;

int main()
{
    int n;
    f >> n;
    for (int i = 1; i <= n; i++) {
        int op;
        f >> op;
        switch(op) {
            case 1:
                int x;
                f >> x;
                heap.insert(x);
                elem.push_back(x);
                break;
            case 2:
                int s;
                f >> x;
                heap.erase(heap.find(elem[x - 1]));
                break;
            case 3:
                iter it = heap.begin();
                g << *it << '\n';
                break;
        }
    }

    return 0;
}
