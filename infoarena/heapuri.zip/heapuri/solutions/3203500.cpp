#include <bits/stdc++.h>

using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

int n;
multiset<int> heap;
vector<int> position;

int main() {
    in >> n;
    for (int i = 0; i < n; i++) {
        int type, x;
        in >> type;
        if (type == 1) {
            in >> x;
            heap.insert(x);
            position.push_back(x);
        } else if (type == 2) {
            in >> x;
            heap.erase(position[x - 1]);
        } else {
            out << *heap.begin() << '\n';
        }
    }
    return 0;
}
