//heapuri 2.0
#include <fstream>

using namespace std;
int m,n,heap[200005],a[200005],poz[200005];
int left(int i)
{
    return (2*i);
}
int right(int i)
{
    return (2*i+1);
}
int father(int i)
{
    return (i/2);
}
void urca(int i)
{
    int key=heap[i];
    while(i>1 and a[heap[father(i)]]>a[key])
    {
        heap[i]=heap[father(i)];
        poz[heap[father(i)]]=i;
        i=father(i);
    }
    heap[i]=key; poz[key]=i;
}
void coboara(int i)
{
    int minim;
    minim=i;
    if(left(i)<=n and a[heap[left(i)]]<a[heap[i]]) minim=left(i);
    if(right(i)<=n and a[heap[right(i)]]<a[heap[minim]])minim=right(i);
    if(minim!=i){swap(heap[i],heap[minim]);
                 swap(poz[heap[i]],poz[heap[minim]]);
                 coboara(minim);}

}
void sterge(int i)
{
    a[heap[i]]=-1;
    urca(i);
    swap(heap[1],heap[n]);
    swap(poz[heap[1]],poz[heap[n]]);
    n--;
    coboara(1);
}
int main()
{
    int t,x,tip;
    ifstream fi("heapuri.in");
    ofstream fo("heapuri.out");
    fi>>t;
    while(t--)
    {
        fi>>tip;
        if(tip<3) fi>>x;
        if(tip==1) {
                    if(x==12)
                    x=12;
                    a[++m]=x;
                    heap[++n]=m;
                    poz[m]=n;
                    urca(n);
                   }
        if(tip==2)
        sterge(poz[x]);
        if(tip==3)
         fo<<a[heap[1]]<<"\n";
    }
    return 0;
}
