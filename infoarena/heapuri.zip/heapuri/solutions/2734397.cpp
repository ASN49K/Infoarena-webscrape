#include <iostream>
#include <fstream>
const int capacity=1000000;
using namespace std;
struct cronologic{
int i;
int x;
} c;
class Heap
{
    int* heap;
    int heap_size;
public:
    Heap();
    int parinte(int i)
    {
        return (i-1)/2;
    }
    int stanga(int i)
    {
        return (2*i+1);
    }
    int dreapta (int i)
    {
        return 2*(i+1);
    }
  void add(int k)
{
    if (heap_size == capacity)
    {
        cout << "\nOverflow: Could not insertKey\n";
        return;
    }

    heap_size++;
    int i = heap_size - 1;
    heap[i] = k;

    while (i != 0 && heap[parinte(i)] > heap[i])
    {
       swap(heap[i], heap[parinte(i)]);
       i = parinte(i);
    }
}
    ~Heap()
    {
        heap_size=0;
        delete[] heap;
    }
    friend ostream& operator<<(ostream& out,const Heap& hp)
    {
        for(int i=0; i<hp.heap_size; i++)
            out<<hp.heap[i]<<" ";
        return out;
    }
    int getMin()
    {
        return heap[0];
    }
    int delMin()
    {
        if (heap_size==0)
            return -1;
        if(heap_size==1)
        {
            return heap[0];
            heap_size--;
        }
        int root = heap[0];
        heap[0] = heap[heap_size-1];
        heap_size--;
        return root;
    }
    int extractMin()
    {
        if (heap_size <= 0)
            return INT_MAX;
        if (heap_size == 1)
        {
            heap_size--;
            return heap[0];
        }
        int root = heap[0];
        heap[0] = heap[heap_size-1];
        heap_size--;
        MinHeapify(0);

        return root;
    }

    void deleteKey(int i)
    {
        decreaseKey(i, INT_MIN);
        extractMin();
    }
    void MinHeapify(int i)
    {
        int l = stanga(i);
        int r = dreapta(i);
        int smallest = i;
        if (l < heap_size && heap[l] < heap[i])
            smallest = l;
        if (r < heap_size && heap[r] < heap[smallest])
            smallest = r;
        if (smallest != i)
        {
            swap(heap[i], heap[smallest]);
            MinHeapify(smallest);
        }
    }

    void decreaseKey(int i, int new_val)
    {
        heap[i] = new_val;
        while (i != 0 && heap[parinte(i)] > heap[i])
        {
            swap(heap[i], heap[parinte(i)]);
            i = parinte(i);
        }
    }

};
Heap::Heap()
{
    heap_size=0;
    heap= new int[capacity];
}

int main()
{   ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    Heap h1;
    int n,caz,x;
    f>>n;
    int frecv[10000]={0};
    int j=0;
    for (int i=0;i<n;i++){
        f>>caz;
        if(caz==1){
            f>>x;
            frecv[j]=x;
            j++;
            h1.add(x);
        }
        if(caz==2){
            f>>x;
            h1.deleteKey(frecv[x+1]);
        }
        if(caz==3){
            g<<h1.getMin()<<endl;
        }
    }
    return 0;
}
