#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <numeric>
#include <sstream>
#include <cmath>
#include <set>
#include <stack>
#include <iomanip>
#include <limits.h>
#include <queue>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <exception>
#include <deque>
#include <string>

using namespace std;
fstream in_file;
fstream out_file;

int main()
{
    in_file.open("heapuri.in");
    out_file.open("heapuri.out", ios::out);

    set<int> hash;
    vector<int> cronologie;

    int n;
    in_file >> n;

    int op, aux;

    while (n--)
    {
        in_file >> op;
        
        if (op == 1)
        {
            in_file >> aux;
            cronologie.push_back(aux);
            hash.insert(aux);
        }
        else if(op==2)
        {
            in_file >> aux;
            hash.erase(hash.find(cronologie[aux-1]));
        }
        else
        {
            out_file << *hash.begin() << endl;
        }
    }

    in_file.close();
    out_file.close();
}
