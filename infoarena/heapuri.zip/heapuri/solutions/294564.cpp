#include <stdio.h>
#include <set>
using namespace std;

int n, nr_crt;
int *numere;
set<int> mult;

int main()
{
	int i, op, x;
	FILE *fin = fopen("heapuri.in", "r");
	FILE *fout = fopen("heapuri.out", "w");
	fscanf(fin, "%d", &n);
	numere = new int[n+1];
	for (i = 1; i <= n; ++i)
	{
		fscanf(fin, "%d", &op);
		if (op < 3)
		{
			fscanf(fin, "%d", &x);
		}
		if (op == 1)	//add
		{
			mult.insert(x);
			numere[++nr_crt] = x;
			
		}
		else if (op == 2)	//remove
		{
			mult.erase(numere[x]);
		}
		else	//find min
		{
				fprintf(fout, "%d\n", *mult.begin());
		}
	}
	fclose(fin);
	fclose(fout);
	return 0;
}
