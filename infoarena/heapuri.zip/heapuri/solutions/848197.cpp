#include<fstream>
#include<set>
using namespace std;
ifstream f("heapuri.in"); ofstream g("heapuri.out");
multiset <int> H;
int n, u, v[200001];
int main()
{   f>>n;
    for(int op, x, i=1; i<=n; ++i)
        {   f>>op;
            if (op==1) {f>>x; v[++u]=x; H.insert(x);}
            if (op==2) {f>>x; H.erase(H.find(v[x]));}
            if (op==3) g<<*H.begin()<<'\n';
        }
}
