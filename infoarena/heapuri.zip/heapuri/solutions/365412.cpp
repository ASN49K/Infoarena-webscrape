#include <fstream>

using namespace std;


ifstream f ("heapuri.in");
ofstream g ("heapuri.out");

int n, v[2000001], t, w[2000001], vv[2000001];


void inserare (int m, int x, int nrr)
{   v[++m]=x;
    w[nrr]=nrr;
    vv[m]=nrr;
    int tata=m/2;
    int fiu=m;
    int ok=1;
    while (tata>0 && fiu>=1 && ok)
    {     if (v[tata]>v[fiu])
	  {
	     int aux=v[tata];
	     v[tata]=v[fiu];
	     v[fiu]=aux;

	     aux=w[vv[tata]];
	     w[vv[tata]]=w[nrr];
	     w[nrr]=aux;

	     aux=vv[tata];
	     vv[tata]=vv[fiu];
	     vv[fiu]=aux;

	     fiu=tata;
	     tata/=2;
	  }
	  else ok=0;
    }
    n=m;
}


void eliminare(int poz)
{   int tata=w[poz]/2, cv=vv[n], cv2=w[poz];
    v[w[poz]]=v[n--];
    v[n+1]=0;
    w[poz]=0;
    w[vv[n+1]]=cv2;
    vv[cv2]=cv;
    vv[n+1]=0;

    int fiu=cv2;
    while (v[tata]>v[fiu] && fiu<=n && tata>0 && fiu>=1)
    {	  if (v[tata]>v[fiu])
	  {
	     int aux=v[tata];
	     v[tata]=v[fiu];
	     v[fiu]=aux;

	     aux=w[vv[tata]];
	     w[vv[tata]]=w[vv[fiu]];
	     w[vv[fiu]]=aux;

	     aux=vv[tata];
	     vv[tata]=vv[fiu];
	     vv[fiu]=aux;
	     fiu=tata;
	     tata/=2;
	  }
    }
    tata=cv2;
    fiu=tata*2;
    if (fiu<n)
       if (v[fiu]>v[fiu+1])
	  fiu++;
    while (v[tata]>v[fiu] && fiu<=n)
    {     if (fiu<n)
	     if (v[fiu]>v[fiu+1])
		fiu++;
	  if (v[tata]>v[fiu])
	  {
	     int aux=v[tata];
	     v[tata]=v[fiu];
	     v[fiu]=aux;

	     aux=w[vv[tata]];
	     w[vv[tata]]=w[vv[fiu]];
	     w[vv[fiu]]=aux;

	     aux=vv[tata];
	     vv[tata]=vv[fiu];
	     vv[fiu]=aux;

	     tata=fiu;
	     fiu*=2;
	  }
    }
}



void afis()
{    g << v[1] << "\n";
}


int main()
{   f >> t;

    int tip, nr, j=1;

    for (int i=1; i<=t; i++)
    {    f >> tip;

	     if (tip==1)
	     {   f >> nr;
		 inserare(n, nr, j++);
	     }

	 else

	 if (tip==2)
	 {   f >> nr;
		 eliminare(nr);
	 }

	 else

	 if (tip==3)
	 {
	     afis();
	 }
    }



    f.close();
    g.close();
    return 0;
}
    
             
