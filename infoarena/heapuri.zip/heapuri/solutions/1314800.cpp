#include <fstream>
#include <set>
#include <algorithm>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int i,heap[200100],intrare[200100],poz[200100],n,tip,x,nrele,nrelecur;
void urcare(int p)
{
    if(intrare[heap[p]]<intrare[heap[p/2]])
    {
        swap(poz[heap[p]],poz[heap[p/2]]);
        swap(heap[p],heap[p/2]);
        urcare(p/2);
    }
}
void coborare(int x)
{
    int st = 2*x, dr = 2*x + 1, r = x;
    if (st<=nrelecur && intrare[heap[st]]<intrare[heap[r]])
        r=st;
    if (dr<=nrelecur && intrare[heap[dr]]<intrare[heap[r]])
        r=dr;
    if (r!=x)
    {
        swap(poz[heap[x]],poz[heap[r]]);
        swap(heap[x],heap[r]);
        coborare(r);
    }
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>tip;
        if(tip==1)
        {
            fin>>x;
            intrare[++nrele]=x;
            heap[++nrelecur]=nrele;
            poz[nrele]=nrelecur;
            urcare(nrelecur);
        }
        else if(tip==2)
        {
            fin>>x;
            x=poz[x];
            swap(poz[heap[x]],poz[heap[nrelecur]]);
            swap(heap[x],heap[nrelecur]);
            nrelecur--;
            urcare(x);
            coborare(x);
        }
        else
            fout<<intrare[heap[1]]<<"\n";
    }
    return 0;
}
