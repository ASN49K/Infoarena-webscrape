#include <bits/stdc++.h>
//#pragma GCC optimize("O3,unroll-loops")
//#pragma GCC target("avx2,bmi,bmi2,popcnt,lzcnt")

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

struct cv {
    int x;
    int time;
};

int q;
vector<cv> heap;

bool cmp(const cv& a, const cv& b) {
    return a.x > b.x;
}
int order;
bool cmpPop(const cv& a, const cv& b) {
    if (a.time == order) {
        return true;
    } else if (b.time == order) {
        return false;
    } else {
        return cmp(a,b);
    }
}

void push(const cv& elem) {
    heap.push_back(elem);
    push_heap(heap.begin(),heap.end(),cmp);
}

void pop(const int time) {
    order = time;
    make_heap(heap.begin(),heap.end(),cmpPop);
    cout << heap.back().time << '\n';
    auto it = heap.end();
    it -= 2;
    if (it->time == order) {
        swap(*it,heap.back());
    }
    heap.pop_back();
}

int main() {
    fin >> q;
    int time = 1;
    while (q--) {
        int t;
        fin >> t;
        switch (t) {
            case 1: {
                int x;
                fin >> x;
                const cv temp = {x,time};
                push(temp);
                time++;
                break;
            }
            case 2: {
                int x;
                fin >> x;
                pop(x);
                break;
            }
            case 3: {
                fout << heap.front().x << '\n';
                break;
            }
        }
    }
    return 0;
}