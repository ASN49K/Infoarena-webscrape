#include <fstream>
#include <set>
#include <vector>
#include <iostream>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");


int main() {
    int n, x, y,poz[200001],position=0;
    set<int> heap;
    f >> n;
    for (int i = 1; i <= n; i++) {
        f>>x;
        if(x==1){
            f>>y;
            heap.insert(y);
            position++;
            poz[position]=y;
        }
        else if(x==2){
            f>>y;
            heap.erase(poz[y]);
        }
        else if(x==3)
            cout<<*heap.begin()<<"\n";
    }
}