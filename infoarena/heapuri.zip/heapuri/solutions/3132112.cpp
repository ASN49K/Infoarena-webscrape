#include <iostream>
#include <fstream>
#include <unordered_map>
using namespace std;
ifstream fin("pariuri.in");
ofstream fout("pariuri.out");
int main(){
	int N, M, cod, X;
	unordered_map<int, int> HashTable;
	fin>>N;
	for (int i = 0; i < N;i++){
		fin>>M;
		for (int j = 0;j < M;j++){
			fin>>cod>>X;
			HashTable[cod] = HashTable[cod]+X;
		}
    }
	fout << HashTable.size()<<endl;
	for (auto i : HashTable){
		fout <<i.first << " " <<i.second << " ";
    }
    fout.close();
    fin.close();
	return 0;
}