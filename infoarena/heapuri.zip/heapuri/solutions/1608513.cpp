#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

const int NMax = 2e5 + 5;

bool Del[NMax];

priority_queue < pair < int, int > , vector < pair < int, int > >, greater < pair < int, int > > > PQ;

int main(){
    int n, c, x, k;
    fin >> n;
    k = 0;
    while(n--){
        fin >> c;
        if(c == 1){
            fin >> x;
            k++;
            PQ.push({x, k});
        } else {
            if(c == 2){
                fin >> x;
                Del[x] = 1;
            } else {
                while(Del[PQ.top().second]) PQ.pop();
                fout << PQ.top().first << "\n";
            }
        }
    }
    return 0;
}
