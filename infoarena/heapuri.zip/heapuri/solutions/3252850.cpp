#include <bits/stdc++.h>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

const int MAXN = 200005;

struct hp {
    int val, ord;
}heap[MAXN];

int poz[MAXN];

int m, n;

void up(int p)
{
    while(p/2 > 0 && heap[p].val < heap[p/2].val)
    {
        swap(poz[heap[p].ord],poz[heap[p/2].ord]);
        swap(heap[p], heap[p/2]);
        p /= 2;
    }
}

void down(int p)
{
    while(p*2 <= n)
    {
        int t = p*2;
        if(t+1 <= n && heap[t].val > heap[t+1].val)
            t++;

        if (heap[p].val > heap[t].val)
        {
            swap(poz[heap[p].ord], poz[heap[t].ord]);
            swap(heap[p], heap[t]);
            p = t;
        }
        else
            break;
    }
}

void Adauga(int x, int i)
{
    n++;
    poz[i] = n;
    heap[n].val = x;
    heap[n].ord = i;
    up(n);
}

void Sterge(int p)
{
    swap(poz[heap[p].ord], poz[heap[n].ord]);
    swap(heap[p], heap[n]);
    n--;
    up(p);
    down(p);
}

int main()
{
    fin >> m;
    int ord = 0;
    for(int i = 1; i <= m; i++)
    {
        int op, x;
        fin >> op;
        if(op == 1)
        {
            fin >> x;
            ord++;
            Adauga(x, ord);
        }
        else if(op == 2)
        {
            fin >> x;
            int ind = poz[x];
            Sterge(ind);
        }
        else
            fout << heap[1].val << "\n";
    }
    return 0;
}
