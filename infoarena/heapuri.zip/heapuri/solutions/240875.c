#include <stdio.h>

int V[200100],i,j,nr,min,a,x,N;

int main()
{
  freopen("heapuri.in","r",stdin);
  scanf("%d", &N);
  nr=0;
  freopen("heapuri.out","w",stdout);
  for (i=1;i<=N;++i)
       {
	scanf("%d", &a);
	if (a==1)
	    {
	     nr++;
	     scanf("%d",&x);
	     V[nr]=x;
	    }
	    else
	if (a==2)
	    {
	     scanf("%d", &x);
	     V[x]=100000000;
	     }
	  else
	  {
	   min=100000000;
	   for (j=1;j<=nr;++j)
		if (V[j]<min)
		    min=V[j];
	   printf("%d\n", min);
	   }
	}
return 0;
}
