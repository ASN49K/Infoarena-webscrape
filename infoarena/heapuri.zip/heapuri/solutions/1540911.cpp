#include <fstream>
using namespace std;
int H[200001], EL[200001], P[200001], N, K, cnt = 0, cnt1 = 0, a, b;
ifstream f("heapuri.in");
ofstream of("heapuri.out");
void per(int k){
	while (k / 2 && EL[H[k]] < EL[H[k / 2]]){
		swap(H[k], H[k / 2]);
		P[H[k]] = k;
		P[H[k / 2]] = k / 2;
		k /= 2;
	}
}
void sift(int k){
	int y = 0;
	while (k != y){
		y = k;
		if (y * 2 <= cnt && EL[H[k]] > EL[H[y * 2]])k = y * 2;
		if (y * 2 + 1 <= cnt && EL[H[k]] > EL[H[y * 2 + 1]])k = y * 2 + 1;
		swap(H[k], H[y]);
		P[H[k]] = k;
		P[H[y]] = y;
	}
}
void add(int& x){
	++cnt; ++cnt1;
	H[cnt] = cnt1;
	P[cnt1] = cnt;
	EL[cnt1] = x;
	per(cnt);
}
void del(int& x){
	EL[x] = -1;
	per(P[x]);
	P[H[1]] = 0;
	H[1] = H[cnt--];
	P[H[1]] = 1;
	if (cnt>1)sift(1);
}
int main(){
	f >> N;
	for (int i = 1; i <= N; ++i){
		f >> a;
		if (a != 3)f >> b;
		else of << EL[H[1]] << "\n";
		if (a == 1)add(b);
		else if (a == 2)del(b);
	}
	return 0;
}