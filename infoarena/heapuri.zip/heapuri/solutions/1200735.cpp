#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

int v[10000],t[10000],n=0,o=1;

void schimba(int &x,int &y){
    int aux;
    aux=x;
    x=y;
    y=aux;
}

void push(int x){
    int y;
    n++;
    v[n]=x;
    t[n]=o;
    o++;
    y=n;
    while(v[y/2]>v[y]&&y>1){
        schimba(v[y],v[y/2]);
        schimba(t[y],t[y/2]);
        y/=2;
    }
}

void elimina(int x){
    int i,y;
    for(i=1;t[i]!=x;i++){}
    schimba(v[i],v[n]);
    schimba(t[i],t[n]);
    y=i;
    if(i!=1)
    while(v[y/2]>v[y]&&y>1){
        schimba(v[y],v[y/2]);
        schimba(t[y],t[y/2]);
        y/=2;
    }
    else{
    while(v[2*y]<v[y]&&2*i<n){
        schimba(v[y],v[y*2]);
        schimba(t[y],t[y*2]);
        y*=2;
    }
    while(v[2*y+1]<v[y]&&2*y+1<n){
        schimba(v[y],v[y/2+1]);
        schimba(t[y],t[y/2+1]);
        y*=2;
    }

    }
    n--;
}

int main(){
    int i,x,c;
    f>>x;
    for(i=1;i<=x;i++){
        f>>c;
        if(c==3) g<<v[1]<<endl;
        else if(c==1) {
            f>>c;
            push(c);
        }
        else{
            f>>c;
            elimina(c);
        }
    }

    return 0;
}
