#include <fstream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int n,nr,q,poz,t,cst,x,a[200003],c[200003],b[200003];
void urcare(int &poz)
{
    while(a[poz]<a[poz/2]&&poz>1)
    {
        swap(c[b[poz/2]],c[b[poz]]);
        swap(b[poz],b[poz/2]);
        swap(a[poz],a[poz/2]);
        poz/=2;
        cst=poz;
    }
}
void erase_heap(int x)
{
    poz=c[x];
    swap(c[b[poz]],c[b[nr]]);
    swap(b[poz],b[nr]);
    swap(a[poz],a[nr]);
    nr--;
    cst=poz;
    urcare(poz);
    int tt=cst;
    int cc=cst*2;
    while(cc<=nr)
    {
        if(a[cc]>a[cc+1]&&cc+1<=nr)
            cc++;
        if(a[cc]<a[tt])
        {
            swap(c[b[tt]],c[b[cc]]);
            swap(b[tt],b[cc]);
            swap(a[tt],a[cc]);

        }
        tt=cc;
        cc*=2;
    }
}
void add_heap(int x)
{
    nr++;
    t++;
    a[nr]=x;
    b[nr]=t;
    c[t]=nr;
    int poz=nr;
    urcare(poz);
}
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>q;
        if(q==1)
        {
            f>>x;
            add_heap(x);

        }
        else
        if(q==2)
        {
            f>>x;
            erase_heap(x);

        }
        else
            g<<a[1]<<'\n';
    }
    return 0;
}
