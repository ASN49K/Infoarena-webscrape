#include <iostream>
#include <fstream>
#include <set>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
set < int > heap;
int n,op,x;
int main()
{
    f>>n;
    int v[n], k=0;
    while(f>>op)
    {
        if(op==1 || op==2)
        {
            f>>x;
            if(op == 1)
            {
                heap.insert( x );
                v[k++] = x;
            }
            else heap.erase( v[x-1] );
        }
        else
            g<< *heap.begin() << '\n';
    }

}
