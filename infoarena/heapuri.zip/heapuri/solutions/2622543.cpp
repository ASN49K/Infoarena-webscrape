#include <fstream>
#define INF 0x3f3f3f3f

using namespace std;

ifstream f ("heapuri.in");
ofstream g ("heapuri.out");

constexpr int NMAX = 2e5 + 5;

int N, hVf;
int elim[NMAX];
int H[NMAX];
int val[NMAX];

void HeapUp (int poz)
{
    if (val[H[poz]] < val[H[poz/2]])
    {
        swap(H[poz], H[poz/2]);

        HeapUp(poz/2);
    }
}

void HeapDown (int poz, int N)
{
    if (2 * poz <= N)
    {
        int Left, Right;

        Left = val[H[2*poz]];

        if (2 * poz + 1 <= N) Right = val[H[2*poz+1]];
        else Right = INF;

        if (min(Left, Right) < H[poz])
        {
            if (Left < Right)
            {
                swap(H[poz], H[2*poz]);

                HeapDown(2*poz, N);
            }
            else
            {
                swap(H[poz], H[2*poz+1]);

                HeapDown(2*poz+1, N);
            }
        }
    }
}

int main ()
{
    int Q;

    f >> Q;

    for (; Q; --Q)
    {
        int tip;

        f >> tip;

        if (tip == 1)
        {
            int x;

            f >> x;

            val[++N] = x;
            H[++hVf] = N;

            HeapUp(hVf);
        }
        else if (tip == 2)
        {
            int x;

            f >> x;

            elim[x] = 1;
        }
        else
        {
            while (elim[H[1]])
            {
                swap(H[1], H[hVf]);

                --hVf;

                HeapDown(1, hVf);
            }

            g << val[H[1]] << '\n';
        }
    }
    return 0;
}
