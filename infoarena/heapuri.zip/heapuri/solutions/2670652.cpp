#include<fstream>
#include<iostream>
#include<algorithm>
using namespace std;
const int LIM = 200001;
int m;
int n;
long long Heap[LIM];
long long ordine[LIM];
long long Nod[LIM];
ifstream f("heapuri.in");
ofstream g("heapuri.out");

void Cerne(int x)
{
    int fiu = 2 * x;
    if (fiu + 1 <= n && Heap[fiu + 1] < Heap[fiu])
        fiu++;

    if (fiu <= n && Heap[fiu] < Heap[x])
    {
        swap(Heap[fiu], Heap[x]);
        swap(Nod[Heap[fiu]], Nod[Heap[x]]);
        Cerne(fiu);
    }
}
void heap_pop(int x)
{
    int k = Heap[n];
    swap(Heap[Nod[ordine[x]]], Heap[n]);
    Nod[k] = Nod[ordine[x]];
    n--;
    Cerne(Nod[k]);
}

void Promovare(int n)
{
    int tata = n / 2;
    if (tata && Heap[n] < Heap[tata])
    {
        swap(Heap[n], Heap[tata]);
        swap(Nod[Heap[n]], Nod[Heap[tata]]);
        Promovare(tata);
    }
}

void heap_push(long long x)
{
    n++;
    Heap[n] = x;
    ordine[n] = x;
    Nod[x] = n;
    Promovare(n);

}


int main()
{
    int op;
    long long x;
    f >> m;
    for (int i = 1; i <= m; i++)
    {
        f >> op;
        if (op == 1)
        {
            f >> x;
            heap_push(x);
        }
        else
            if (op == 2)
            {
                f >> x;
                heap_pop(x);
            }
            else
                g << Heap[1] << endl;
        for (int i = 1; i <= n; i++)
            cout << Heap[i] << " ";
        cout << endl;
       

    }
    cout << endl;
    for (int i = 1; i <= 10; i++)
        cout << ordine[i] << " ";
    cout << endl;
    cout << Nod[7];

    f.close();
    g.close();
    return 0;


}