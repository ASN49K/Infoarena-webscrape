#include <iostream>
#include <fstream>
#define NMAX 100000001

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int minim=99999999,c[NMAX],N;
int main()
{
    fin>>N;
    int points=0,tip,number;
    for(int i =1 ; i <= N; i++)
    {
        fin>>tip;
        if(tip==1)
        {
            fin>>number;
            c[++points]=number;
        }

        else if(tip==2)
        {
            fin>>number;
            c[number]=100000001;
        }
        else if(tip==3)
        {
            for(int j = 1; j <= points; j++)
                if(c[j] < minim)
                    minim=c[j];


            fout<<minim<<'\n';
            minim=NMAX;
        }
    }

    return 0;
}
