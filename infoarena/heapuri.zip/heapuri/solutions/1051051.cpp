#include <iostream>
#include<fstream>
#include<algorithm>

using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

struct heapy
{
    int val,poz,ord;
}heap[2000005];
int nr,k;
int i,x,tip;

void urca(int &n,int pozi)
{
    while(pozi>1&& heap[pozi].val<heap[pozi/2].val)
    {
        swap(heap[pozi],heap[pozi/2]);
        pozi/=2;

    }
}

void coboara(int &n,int pozi)
{
 {
    int poz1=0;

    while(pozi!=poz1) {
        poz1=pozi;

        if(2*poz1<=n && heap[pozi].val>heap[2*pozi].val)
            pozi=2*poz1;
        if(2*poz1+1<=n && heap[pozi].val>heap[2*poz1+1].val)
            pozi=2*poz1+1;

        swap(heap[pozi],heap[poz1]);
        }
}}

int main()
{int n=0,j;
    f>>nr;
    for(i=1;i<=nr;i++)
    {
        f>>tip;
        if(tip==1)
        {k++;
        f>>x;
        heap[++n].val=x;
        heap[n].ord=k;
        heap[n].poz=n;
        urca(n,n);
        }
        else if(tip==2)
        {
            f>>x;
            for(j=1;heap[j].ord!=x;j++);
            heap[j]=heap[n--];
            urca(n,heap[j].poz);
            coboara(n,1);
        }
        else
        {
            g<<heap[1].val<<'\n';
        }
    }
    return 0;
}
