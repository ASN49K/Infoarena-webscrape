#include <stdio.h>
#include <stdlib.h>

FILE * fin;
FILE * fout;

int v[200000];
int hp[200000];
int pos[200000];
int n = 0;

inline void hp_swap(int a, int b)
{
    hp[a]=hp[a]^hp[b];
    hp[b]=hp[a]^hp[b];
    hp[a]=hp[a]^hp[b];
    pos[hp[a]]=a;
    pos[hp[b]]=b;
}

inline int hp_comp(int a, int b)
{
    return v[hp[a]]<v[hp[b]];
}


void hp_up(int i)
{
    while (i)
    {
        int pos = ((i+1)>>1)-1;
        if (hp_comp(pos,i))
            break;
        hp_swap(i,pos);
        i=pos;
    }
}

void hp_down(int i)
{
    while (1)
    {
        int p1 = (i<<1) + 1;
        int p2 = (i<<1) + 2;
        int min = i;
        if ((p1<n)&&hp_comp(p1,min))
            min=p1;
        if ((p2<n)&&hp_comp(p2,min))
            min=p2;
        if (min==i)
            break;
        hp_swap(i,min);
        i=min;
    }
}

inline void hp_delete(int i)
{
    hp_swap(i,--n);
    hp_down(i);
}

inline int hp_peek()
{
    return hp[0];
}

inline void hp_push(int i)
{
    hp[n]=i;
    pos[i]=n;
    n++;
    hp_up(n-1);
}

int main()
{
    fin = fopen("heapuri.in","r");
    fout = fopen("heapuri.out","w");
    int n;
    fscanf(fin,"%d\n",&n);
    int io=0;
    int i;
    for (i=0; i<n; i++)
    {
        int op,x;
        fscanf(fin,"%d",&op);
        if (op<3)
            fscanf(fin,"%d",&x);
        switch(op)
        {
            case 1:
                v[io]=x;
                hp_push(io);
                io++;
                break;
            case 2:
                hp_delete(pos[x-1]);
                break;
            case 3:
                fprintf(fout,"%d\n",v[hp_peek()]);
                break;
        }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
