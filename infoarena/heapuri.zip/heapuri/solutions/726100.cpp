#include <cstdio>
#define N 200005
using namespace std;
int lgheap,heap[N],a[N],n,poz[N];
void up()
{ int fiu,tata,z;
  bool e;
fiu=lgheap; tata=fiu/2; e=true;
while(tata>=1&&e)
    {
    e=false;
    if(a[heap[fiu]]<a[heap[tata]])
            {
            e=true;
            z=poz[heap[fiu]]; poz[heap[fiu]]=poz[heap[tata]]; poz[heap[tata]]=z;
            z=heap[tata]; heap[tata]=heap[fiu]; heap[fiu]=z;
            fiu=tata; tata=fiu/2;
            }
    }
}
void erase(int ind)
{ int fiu,tata,z,x;
  bool e;
x=poz[ind];
tata=poz[ind]; fiu=poz[ind]*2; e=true;
heap[poz[ind]]=heap[lgheap]; poz[heap[lgheap]]=poz[ind]; poz[ind]=-1;
heap[lgheap]=0; --lgheap;
while(fiu<=lgheap&&e)
    {
    e=false;
    if(a[heap[fiu+1]]<a[heap[fiu]]&&fiu+1<=lgheap)++fiu;
    if(a[heap[tata]]>a[heap[fiu]])
        {
        e=true;
        z=poz[heap[tata]]; poz[heap[tata]]=poz[heap[fiu]]; poz[heap[fiu]]=z;
        z=heap[tata]; heap[tata]=heap[fiu]; heap[fiu]=z;
        tata=fiu; fiu=tata*2;
        }
    }
fiu=x; tata=fiu/2; e=true;
if(fiu<=lgheap)
    {
while(tata>=1&&e)
    {
    e=false;
    if(a[heap[tata]]>a[heap[fiu]])
            {
            e=true;
            z=poz[heap[tata]]; poz[heap[tata]]=poz[heap[fiu]]; poz[heap[fiu]]=z;
            z=heap[tata]; heap[tata]=heap[fiu]; heap[fiu]=z;
            fiu=tata; tata=fiu/2;
            }
    }
    }
}
int main()
{ int t,op,x;
freopen("heapuri.out","w",stdout);
freopen("grader_test3.in","r",stdin); scanf("%d\n",&t);
n=0; lgheap=0;
for(;t>=1;--t)
    {
    scanf("%d",&op);

    switch(op)
        {
        case 1:
            scanf("%d\n",&a[++n]);
            heap[++lgheap]=n;
            poz[n]=lgheap;
            up();
            break;
        case 2:
            scanf("%d\n",&x);
            erase(x);
            break;
        case 3:
            printf("%d\n",a[heap[1]]);
            break;
        }
    }
fclose(stdin);
fclose(stdout);
return 0;
}
