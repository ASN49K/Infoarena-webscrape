#include <cstdio>
#include <algorithm>
using namespace std;
inline int left(int i) { return (i<<1); }
inline int right(int i) {return (i<<1)+1; }
inline int dad(int i) {return (i>>1);}
int a[200010],timp[200010],v[10000000];
int heapsize;
int t=1;
void heapify(int x)
{
   int l=left(x),r=right(x),minim;
    if((l<=heapsize)&&(a[l]<a[x]))
    {
        minim=l;
    }
    else
        minim=x;
    if((r<=heapsize) &&(a[r]<a[minim]))
    {
        minim=r;
    }
    if(minim!=x)
    {
        swap(a[x],a[minim]);
        swap(v[a[x]],v[a[minim]]);
        heapify(minim);
    }
}
void percolate(int x)
{
    int cheie;
    cheie=a[x];
    while((x>1)&&(cheie<a[dad(x)]))
    {
        v[a[dad(x)]]=x; // <- shitfag
        a[x]=a[dad(x)];
        x=dad(x);
    }
    a[x]=cheie;
    v[cheie]=x;


}
void Insert(int x)
{
    heapsize++;
    a[heapsize]=x;
    v[x]=heapsize;
   percolate(heapsize);

}
void extractMin()
{
    printf("%d\n",a[1]);
}
void Delete(int x)
{
    int parinte;
    a[ v [ timp[x] ] ]=a[heapsize];
    v[a[heapsize]]=v[timp[x]];
    heapsize--;
    if(heapsize>1)
    {
        parinte=dad(v[timp[x]]);
        if(a[parinte]>a[v[timp[x]]])
        {
            percolate(v[timp[x]]);
        }
        else
        {
            heapify(v[timp[x]]);
        }
    }
}
int main()
{
    int i,x,n,c;
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&c);
        if((c==1)||(c==2))
        {
            scanf("%d",&x);
            if(c==1)
            {
                timp[t++]=x;
                Insert(x);
            }
            else
            {
                Delete(x);
            }
        }
        else
        {
            extractMin();
        }
    }
}
