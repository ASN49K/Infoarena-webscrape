#include <fstream>
#include <set>

using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

unsigned int N;
unsigned int code;
unsigned int x;

set <unsigned int> a;
unsigned int v[100001];
unsigned int i, k;

int main ()
{
    fin >> N;
    for (i=1; i<=N; i++)
    {
        fin >> code;
        if (code == 1)
        {
            fin >> x;
            a.insert(x);
            v[++k] = x;
        }
        else
            if (code == 2)
            {
                fin >> x;
                a.erase(v[x]);
            }
            else
                fout << *a.begin() << '\n';
    }
    return 0;
}
