#include <stdio.h>
#include <vector>
#include <map>

int main(void) {

	std::map<int, int> heap;
	std::vector<int> elements;

	int N, op, x;
	FILE *fin = fopen("heapuri.in", "r");
	FILE *fout = fopen("heapuri.out", "w");
	fscanf(fin, "%d", &N);

	for (int i = 0; i < N; i++) {
		fscanf(fin, "%d", &op);

		if (op == 3) {
			fprintf(fout, "%d\n", heap.begin()->first);
			continue;
		}

		fscanf(fin, "%d", &x);
		if (op == 1) {
			elements.push_back(x);
			heap.insert(std::pair<int, int>(x, elements.size() - 1));
		}
		else {
			heap.erase(elements[x - 1]);
		}
	}

	fclose(fin);
	fclose(fout);

	return 0;
}
