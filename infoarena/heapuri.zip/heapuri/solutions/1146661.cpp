#include <cstdio>
# define N 200010
#include <vector>
#define val first
#define poz second
using namespace std;
pair<int,int> H[N];
int x,F,T,P[N],left,l,t,i,op,p;
void up()
{
    //val=H[F].val;
    while(F>1&&H[F].val<H[T].val)
    {
        swap(H[F],H[T]);
        P[H[F].poz]=F;
        P[H[T].poz]=T;
        T/=2;
        F/=2;
    }
}
void down()
{
    int son;
    do
    {
        son=0;
        if(T*2<=l)
        {
            left=T*2;
            son=left;
            if(son+1<=l&&H[son+1]<H[son])
                son++;
            if(H[son]>H[T])son=0;
            if(son)
            {
                swap(H[son],H[T]);
                P[H[son].poz]=son;
                P[H[T].poz]=T;
                T=son;
            }
        }
    }while(son);
}
int main()
{
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&op);
        if(op==3)
        {
            printf("%d\n",H[1].val);
            continue;
        }
        scanf("%d",&x);
        if(op==1)
        {
            H[++l].val=x;
            H[l].poz=++p;
            P[i]=l;
            F=l;
            T=F/2;
            up();
            continue;
        }
        if(op==2)
        {
            F=P[x];
            T=F/2;
            H[F]=H[l--];
            if(F>1&&H[F]<H[T])
                up();
            else
            {
                T=F;
                down();
            }
        }
    }
    return 0;
}
