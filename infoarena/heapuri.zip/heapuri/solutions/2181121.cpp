#include<fstream>
#include<queue>
using namespace std;
ifstream f ("heapuri.in");
ofstream g ("heapuri.out");
int heap[3000000],a[300000],poz[300000],n,nr,l,tip,x;
void insereaza(int x){
    while(x/2&&a[heap[x]]<a[heap[x/2]]){
        swap(heap[x],heap[x/2]);
        poz[heap[x]]=x;
        poz[heap[x/2]]=x/2;
        x/=2;
    }
}
void sterge(int x){
    int y=0;
    while(x!=y){
        y=x;
        if(2*y<=l&&a[heap[x]]>a[heap[2*x]]) x=2*y;
        if(2*y+1<=l&&a[heap[x]]>a[heap[y*2+1]]) x=2*y+1;
        if(x!=y){
            swap(heap[x],heap[y]);
            poz[heap[x]]=x;
            poz[heap[y]]=y;
        }
    }
}
int main()
{
    f>>n;
    for(int i=1;i<=n;++i){
        f>>tip;
        if(tip==1){
            f>>x;
            nr++;
            l++;
            a[nr]=x;
            heap[l]=nr;
            poz[nr]=l;
            insereaza(l);
        }
        if(tip==2){
            f>>x;
            a[x]=-1;
            insereaza(poz[x]);
            poz[heap[1]]=0;
            heap[1]=heap[l--];
            poz[heap[1]]=1;
            if(l>1) sterge(1);
        }
        if(tip==3) g<<a[heap[1]]<<'\n';
    }
}
