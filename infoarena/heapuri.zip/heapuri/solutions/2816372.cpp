#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>
#define inf 1e9
#define lim 200010
using namespace std;
ifstream cin("heapuri.in");
ofstream cout("heapuri.out");
int n, arb[lim], siz = 0, pos[lim], elem;
vector<int> cit, ans;
void unif(int i) {
	int l = i * 2 + 1;
	int r = i * 2 + 2;
	int sm = i;	
	if (l < siz && arb[sm] > arb[l]) {
		sm = l;
	}
	if (r < siz && arb[sm] > arb[r]) {
		sm = r;
	}
	if (sm != i) {
		swap(arb[sm], arb[i]);
		pos[arb[sm]] = sm;
		pos[arb[i]] = i;
		unif(sm);
	}
}
int rem(){
	if (siz <= 0) {
		return inf;
	}
	else if (siz == 1) {
		siz--;
		return arb[0];
	}
	else {
		int root = arb[0];
		arb[0] = arb[siz - 1];
		siz--;
		unif(0);
		return root;
	}
}
void chan(int i, int val) {
	arb[i] = val;
	pos[arb[i]] = i;
	while (i != 0 && arb[i] < arb[(i - 1) >> 1]) {
		swap(arb[i], arb[(i - 1) >> 1]);
		pos[arb[i]] = i;
		pos[(i - 1) >> 1] = (i - 1) >> 1;
		i = (i - 1) >> 1;
	}

}
void inskey(int k) {
	siz++;
	int i = siz - 1;
	arb[i] = k;
	pos[arb[i]] = i;
	while (i != 0 && arb[i] < arb[(i - 1) >> 1]) {
		swap(arb[i], arb[(i - 1) >> 1]);
		pos[arb[i]] = i;
		pos[(i - 1) >> 1] = (i - 1) >> 1;
		i = (i - 1) >> 1;
	}
}
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cin >> n;
	int c, x;
	for (int i = 1; i <= n; i++) {
		cin >> c;
		if (c != 3) {
			cin >> x;
			if (c == 1) {
				cit.emplace_back(x);
				inskey(x);
			}
			if (c == 2) {
				elem = cit[x - 1];
				cit[x - 1] = 0;
				int pozitie = pos[elem];
				chan(pozitie, 0);
				rem();
			}
		}
		else {
			ans.emplace_back(arb[0]);
		}
	}
	for (int i = 0; i < ans.size(); i++) {
		cout << ans[i] << ' ';
	}
}