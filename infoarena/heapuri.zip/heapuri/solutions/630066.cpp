#include <cstdio>

using namespace std;

int v[200001],h[200001],poz[200001],nr,nh;

inline void swap(int a,int b)
{
    int c;
    c=h[a];
    h[a]=h[b];
    h[b]=c;
    poz[h[a]] = a;
    poz[h[b]] = b;
}

void urca(int p)
{
    while ((p != 1) && (v[h[p]] < v[h[p/2]]))
    {
        swap(p,p/2);
        p=p/2;
    }
}

void coboara(int p)
{
    int ps=p;
    if ((p*2 <= nh) && (v[h[2*p]] < v[h[ps]]))
        ps = 2*p;
    if ((p*2+1 <= nh) && (v[h[2*p+1]] < v[h[ps]]))
        ps = 2*p+1;
    if (ps != p)
    {
        swap(p,ps);
        coboara(ps);
    }
}

int main()
{
    int i,n,op,x,ord;
    freopen("heapuri.in","r",stdin);
    freopen("heapuri.out","w",stdout);
    scanf("%d",&n);
    for (i=1; i<=n; i++)
    {
        scanf("%d",&op);
        if (op == 1)
        {
            scanf("%d",&x);
            v[++nr]=x;
            h[++nh]=nr;
            poz[nr]=nh;
            urca(nh);
        }
        if (op == 2)
        {
            scanf("%d",&ord);
            h[poz[ord]] = h[nh];
            poz[h[poz[ord]]] = ord;
            swap(poz[ord],nh--);
            urca(poz[ord]);
            coboara(poz[ord]);
        }
        if (op == 3)
        {
            printf("%d\n",v[h[1]]);
        }
    }
    return 0;
}
