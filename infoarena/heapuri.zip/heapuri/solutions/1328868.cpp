#include <iostream>
#include <set>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");
    int n,x,y;
    multiset <int> my_set;

    vector<int> a;
    in >> n;
    for(int i=0;i<n;i++)
    {
        in >> x ;
        if(x!=3)
        {
        in >> y;
        if(x==1)
        a.push_back(y);

        }

        if(x==1)
        {
            my_set.insert(y);
        }
        else if(x==2)
        {
            //cout << a[0] << " ";
            my_set.erase(a[y-1]);
        }
        else
            out << *my_set.begin() << "\n";
    }
return 0;
}
