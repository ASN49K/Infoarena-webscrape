#include<iostream>
#include<vector>
#include<fstream>
using namespace std;
void coboara(int v[], int n, int i)
{
    int min = i;
    int st = 2 * i + 1;
    int dr = 2 * i + 2;


    if (st < n and v[st] < v[min])
        min = st;


    if (dr < n and v[dr] < v[min])
        min = dr;

    if (min != i) {
        swap(v[i], v[min]);


        coboara(v, n, min);
    }
}

void urca(int heap[], int fiu) {
    while (fiu) {
        int tata = (fiu - 1) / 2;
        if (heap[tata] > heap[fiu])
        {
            swap(heap[tata], heap[fiu]);
            urca(heap, tata);
        }
    }
}


int n, i, x, c = 0, fiu, j, y, tata, p = 0;
int poz[200001], heap[200001];
int main() {
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    f >> n;
    for (i = 1; i <= n; i++) {
        f >> x;
        if (x == 1) {
            f >> y;
            poz[p] = y;
            heap[c] = y;
            fiu = c;
            urca(heap, fiu);
            c++;
            p++;

        }
        if (x == 2) {
            f >> y;
            for (j = 0; j <= c; j++)
                if (heap[j] == poz[y-1]) {
                    fiu = j;
                    break;
                }
            swap(heap[fiu] ,heap[--c]);
            if (fiu and heap[(fiu - 1) / 2] > heap[fiu])
                urca(heap, fiu);
            else  
               coboara(heap, c , fiu);
            
        }
        if (x == 3)
            g<< heap[0]<<"\n";

    }
        
    return 0;
}

