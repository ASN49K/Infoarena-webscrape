#include <fstream>
#include <set>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
set <int> s;
int n,i,c,x,k;
int a[200003];
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>c;
        if(c==1)
        {
            fin>>x;
            a[++k]=x;
            s.insert(x);
        }
        else
        if(c==2)
        {
            fin>>x;
            s.erase(a[x]);
            for(int j=x;j<k;j++)
                a[j]=a[j+1];
            k--;
        }
        else
            fout<<*s.begin()<<"\n";
    }
    return 0;
}
