#include<fstream>

#define maxn 200010

using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

int N, L, NR;
int A[maxn], Heap[maxn], Pos[maxn];

void push(int x){
    int aux;
    while (x/2 && A[Heap[x]]<A[Heap[x/2]])
    {
        aux = Heap[x];
        Heap[x] = Heap[x/2];
        Heap[x/2] = aux;

        Pos[Heap[x]] = x;
        Pos[Heap[x/2]] = x/2;
        x /= 2;
    }
}

void pop(int x){
    int aux, y = 0;
    while (x != y){
        y = x;

        if (y*2<=L && A[Heap[x]]>A[Heap[y*2]]) x = y*2;
        if (y*2+1<=L && A[Heap[x]]>A[Heap[y*2+1]]) x = y*2+1;

        aux = Heap[x];
        Heap[x] = Heap[y];
        Heap[y] = aux;

        Pos[Heap[x]] = x;
        Pos[Heap[y]] = y;
    }
}

int main(){

    int i, x, cod;
    cin>>N;

    for (i=1; i<=N; i++)
    {
        cin>>cod;
        if (cod == 1)
        {
            cin>>x;
            L++, NR++;
            A[NR] = x;
            Heap[L] = NR;
            Pos[NR] = L;

            push(L);
        }

        else if (cod == 2){
            cin>>x;
            A[x] = -1;
            push(Pos[x]);

            Heap[1] = Heap[L--];
            Pos[Heap[1]] = 1;
            if (L>1) pop(1);
        }
        if (cod == 3) cout<<A[Heap[1]]<<'\n';
    }

    return 0;
}
