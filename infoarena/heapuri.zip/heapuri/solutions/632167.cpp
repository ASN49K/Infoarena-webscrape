//min heap
#include <stdio.h>
#define MAXN 200005

struct nod{
  int nr,crono;
};

nod heap[MAXN];
int poz[MAXN];//poz[i]=locul in heap pe care se afla al i-lea element introdus
int N=0;

void urca(int loc){
   int x;
   nod aux;
   while((x=loc/2) && heap[loc].nr<heap[x].nr){
      //interschimb nodul de pe locul loc cu tatal sau
      poz[heap[x].crono]=loc;
      poz[heap[loc].crono]=x;
      aux=heap[loc];
      heap[loc]=heap[x];
      heap[x]=aux;
      loc=x;
   }
}

void coboara(int loc){
   //cobor in fiul cel mai mic dintre cei doi
   int x,min,fiu;
   nod aux;
   do{
      fiu=0;
      if((x=loc*2)<=N){
          fiu=x;
          min=heap[fiu].nr;
      }else break;
      if((x=loc*2+1)<=N && (min>heap[x].nr)){
               min=heap[x].nr;
               fiu=x;
      }
     
      if(fiu){
           if(heap[loc].nr>min){
               //interschimb loc cu fiu
               poz[heap[fiu].crono]=loc;
               poz[heap[loc].crono]=fiu;
               aux=heap[loc];
               heap[loc]=heap[fiu];
               heap[fiu]=aux;
               loc=fiu;
           }else fiu=0;//daca mai are fii, dar sunt toi mai mari, e ok
      }
   }while(fiu);
}

int main(){
  FILE *fin=fopen("heapuri.in","r");
  FILE *fout=fopen("heapuri.out","w");
  int n,cod,x,crono=1;
  nod aux;
  fscanf(fin,"%d",&n);
  int i;
  for(i=0;i<n;i++){
     fscanf(fin,"%d",&cod);
     if(cod==1){
        //inserez
        fscanf(fin,"%d",&x);
        aux.nr=x; aux.crono=crono;
        heap[++N]=aux;
        poz[crono]=N;
        crono++;       
        urca(N);
        /*printf("inserez %d\n",x);
        printf("heapul: ");
        for(int j=1;j<=N;j++)printf("(%d,%d)",heap[j].nr,heap[j].crono);
        printf("\n");*/
     }
     if(cod==2){
        //sterg al x-lea element ca ordine cronologica....
        fscanf(fin,"%d",&x);
        //el se afla in heap pe locul poz[x];
        //printf("scot elementul %d %d\n",heap[poz[x]].nr,heap[poz[x]].crono);
           heap[poz[x]]=heap[N];
           N--;
           if(poz[x]>1 && heap[poz[x]].nr<heap[poz[x]/2].nr)urca(poz[x]);
           if(poz[x]<N && heap[poz[x]].nr>heap[poz[x]/2].nr)coboara(poz[x]);
        /*printf("heapul: ");
        for(int j=1;j<=N;j++)printf("(%d,%d)",heap[j].nr,heap[j].crono);
        printf("\n");*/
        poz[x]=0;//marchez ca acest nod nu mai e in heap...
     }

     if(cod==3){
        //afisez minimul
        fprintf(fout,"%d\n",heap[1].nr);
     }


  }
return 0;
}


