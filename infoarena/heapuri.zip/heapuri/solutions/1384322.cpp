#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

const int MAXN =  200010;

int main() {
    freopen("heapuri.in", "r", stdin);
    freopen("heapuri.out", "w", stdout);
    int n, tip, x, k = 0;
    bool sters[MAXN];

    priority_queue<pair<int, int> > q;

    cin >> n;

    while (n--) {
        cin >> tip;
        if (tip == 1) {
            cin >> x;
            q.push(make_pair(-x, ++k));
        }
        if (tip == 2) {
            cin >> x;
            sters[x] = true;
        }
        if (tip == 3) {
            while (sters[q.top().second])
                q.pop();
            cout << -q.top().first << '\n';
        }
    }
}
