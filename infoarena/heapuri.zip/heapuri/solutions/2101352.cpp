#include <fstream>
#include <cstring>

const int MaxN = 200005;
const int inf = 0x3f3f3f3f;

using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

struct minHeap {
	int val, nrelem;
};

minHeap Heap[MaxN];
bool mark[MaxN];
int nr0;

void Insert(int k,int poz) {
	nr0++;
	int kpoz = nr0;
	Heap[nr0].val = k;
	Heap[nr0].nrelem = poz;
	while (kpoz >1 && Heap[kpoz].val < Heap[kpoz / 2].val) {
		swap(Heap[kpoz], Heap[kpoz / 2]);
		kpoz /= 2;
	}
}

inline void MarkRemove(int p) {
	mark[p] = true;
}

void popHeap() {
	Heap[1] = Heap[nr0];
	int kpoz = 1;
	Heap[nr0].val = inf;
	nr0--;
	bool moved = true;
	while ((Heap[kpoz].val > Heap[kpoz * 2].val || Heap[kpoz].val > Heap[kpoz * 2 + 1].val) && moved) {
		moved = false;
		if (Heap[kpoz * 2].val < Heap[kpoz * 2 + 1].val && kpoz * 2 <= nr0) {
			moved = true;
			swap(Heap[kpoz], Heap[kpoz * 2]);
			kpoz *= 2;
		}
		else if(kpoz * 2 + 1 <= nr0){
			moved = true;
			swap(Heap[kpoz], Heap[kpoz * 2 + 1]);
			kpoz = kpoz * 2 + 1;
		}
	}
}

void CleanHeap() {
	while (mark[Heap[1].nrelem])
		popHeap();
}

int main(){
	memset(Heap, inf, sizeof(Heap));
	int n, nrIns = 1;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		int x, y;
		cin >> x;
		if (x == 1) {
			cin >> y;
			Insert(y, nrIns);
			nrIns++;
		}
		if (x == 2) {
			cin >> y;
			MarkRemove(y);
		}
		if (x == 3) {
			CleanHeap();
			cout << Heap[1].val << "\n";
		}
	}
}
