import heapq

input = open("heapuri.in", "r")
output = open("heapuri.out","w")
v = {}
heap = []
i=1
operations = int(input.readline())

while(operations>0):
    op_type = input.readline().replace("\n","").split(" ")
    if(int(op_type[0])==1):
        x = int(op_type[1])
        v.update({i:x})
        heapq.heappush(heap,x)
        i += 1
    if(int(op_type[0])==2):
        x = int(op_type[1])
        heap.remove(v.get(x))
        heapq.heapify(heap)
        v.pop(x)
    if(int(op_type[0])==3):
        output.write(str(heap[0]))
        output.write("\n")

    operations -=1

input.close()
output.close()
