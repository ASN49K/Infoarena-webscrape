#include <iostream>
#include <fstream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    int N, x, v[200001], index = 0, i;
    short o;
    multiset<int> h;
    f>>N;
    for (i = 0; i < N; ++i) {
        f>>o;
        if (o == 1) {
            f>>x;
            h.insert(x);
            v[++index] = x;
        } else if (o == 2) {
            f>>x;
            h.erase(v[x]);
        } else {
            g<<*h.begin()<<endl;
        }
    }
    return 0;
}
