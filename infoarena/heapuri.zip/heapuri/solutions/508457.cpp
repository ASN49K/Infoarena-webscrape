#include<fstream>
using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

# define nmax 200001

int poz[nmax],H[nmax],nri[nmax];

void percolate(int n,int k)
{
	int key=H[k],keypoz=poz[nri[k]],keynri=nri[k];
	while(k>1 && key<H[k/2])
	{
		H[k]=H[k/2];
		nri[k]=nri[k/2];
		poz[nri[k]]=k;
		k/=2;
	}
	H[k]=key;
	nri[k]=keynri;
	poz[nri[k]]=k;
}
void swap(int a,int b)
{
	int key=H[a],keypoz=poz[nri[a]],keynri=nri[a];
	H[a]=H[b];poz[nri[a]]=poz[nri[b]];nri[a]=nri[b];
	H[b]=key;poz[nri[b]]=keypoz;nri[b]=keynri;
}
void sift(int n,int k)
{
	int son;
	do{
		son=0;
		if(2*k<=n)
		{
			son=2*k;
			if(son<n && H[son+1]<H[son]) son++;
			if(H[k]>H[son])
			{
				swap(k,son);
				k=son;
			}
			else son=0;
		}
	}while(son);
}
void repairH(int n,int k)
{
	if(k>1 && H[k]<H[k/2])
		percolate(n,k);
	else sift(n,k);
}
int main()
{
	int n=0,x,a,m,i,nr=0;
	f>>m;
	for(i=1;i<=m;i++)
	{
		f>>x;
		if(x==3) g<<H[1]<<'\n';
		if(x==1)
		{
			f>>a;nr++;
			H[++n]=a;nri[n]=nr;poz[nr]=n;
			percolate(n,n);
		}
		if(x==2)
		{
			f>>a;
			H[poz[a]]=H[n--];
			repairH(n,poz[a]);
		}
	}
}
