#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

const int maxN = 2e5 + 5;

int heap[maxN]; //stocheaza i urile
int poz[maxN]; //unde se afla elementul cu indice i in heap
int V[maxN]; // valoarea elemuntului cu indice i

void promovare (int node) {

    if(node != 1 && V[heap[node]] < V[heap[node/2]]) {
        swap(heap[node], heap[node/2]);

        poz[heap[node]] = node;
        poz[heap[node/2]] = node / 2;

        promovare(node/2);
    }
}

void cernere (int node, int n) {

    while(2 * node <= n) {
        int p = 2 * node;
        if(p + 1 <= n && V[heap[p]] > V[heap[p+1]])
            p += 1;

        if(V[heap[node]] < V[heap[p]]) return ;

        swap(heap[node], heap[p]);

        poz[heap[node]] = node;
        poz[heap[p]] = p;

        node = p;
    }
}

void stergere (int node, int &length) {
    swap(heap[node], heap[length]);

    poz[heap[node]] = node;
    length -= 1;

    if(node != 1 && V[heap[node]] < V[heap[node/2]])
        promovare(node);
    else
        cernere(node, length);
}

int main() {

    int n; fin >> n;

    int length = 0;
    for(int i = 1; i <= n; ++i) {
        int op; fin >> op;
        if(op == 1) {
            fin >> V[i];

            heap[++length] = i;
            poz[i] = length;

            promovare(length);
        } else if(op == 2) {
            int x; fin >> x;
            stergere(poz[x], length);
        } else {
            fout << V[heap[1]] << "\n";
        }
    }

    return 0;
}
