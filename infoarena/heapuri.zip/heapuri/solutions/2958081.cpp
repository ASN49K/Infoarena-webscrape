#include <fstream>
#include <queue>
using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

const int MAX = 1e5 + 1;

int n, op , a , v[MAX] , co[MAX] , k;

priority_queue <int, vector<int>,greater<int>> pq;

int main()
{

    cin >> n;

    while(n--){

        cin >> op;

        if(op == 1){

            cin >> a;

            v[++k] = a;

            pq.push(a);
        }

        if(op == 2){

            cin >> a;

            co[v[a]]++;
        }

        if(op == 3){

            while(!pq.empty() && co[pq.top()]){

                co[pq.top()]--;

                pq.pop();
            }

            cout << pq.top() << '\n';
        }

    }

    return 0;
}
