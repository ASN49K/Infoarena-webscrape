#include <fstream>
using namespace std;
 int a,b,h[200001],i,j,k,ord[200001],fake[200001],nr,m;
 long n;
ifstream f("heapuri.in");
ofstream g("heapuri.out");

void swap(int i,int j)
{int aux;

    aux=h[i];
    h[i]=h[j];
    h[j]=aux;

      aux=ord[i];
    ord[i]=ord[j];
    ord[j]=aux;
    fake[ord[i]]=i;
    fake[ord[j]]=j;


}
void heapup(int poz)
{int i;
    i=poz/2;
    if (h[poz]<h[i])
    {swap(poz,i);
     heapup(i);
    }
}
void heapdown(int i,int k)
{int poz;
    if (2*i>k) return;
if (2*i+1<=k)
{if (h[2*i+1]<h[2*i]) poz=2*i+1;
    else poz=2*i;
}
else poz=2*i;
if (h[i]>h[poz])
{swap(i,poz);
heapdown(poz,k);}
}
int main()
{f>>n;
for (i=1;i<=n;i++)
    {f>>a;
    if(a!=3) f>>b;
    if (a==1) {k++;
                 h[k]=b;
                 nr++;
                 ord[nr]=k;
                 fake[k]=nr;

                 heapup(nr);
                }
    if(a==2){m=fake[b];
        swap(fake[b],nr);
         nr--;

            heapdown(m,nr);
            }
    if (a==3) g<<h[1]<<'\n';

    }

}
