/// varianta cu
#include <bits/stdc++.h>
#define N 200001

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int pozitie[N], n, o, poz, x;
set <int> h;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> o;

        if(o == 1)  // inserare
        {
            fin >> x;
            h.insert(x);
            pozitie[++poz] = x;
        }
        else if(o == 2) // stergere
        {
            fin >> x;
            h.erase(pozitie[x]);
        }
        else if(o == 3) // afisare
        {
            fout << *(h.begin()) << "\n";
        }
    }
    return 0;
}
