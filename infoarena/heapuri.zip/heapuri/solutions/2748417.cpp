#include<bits/stdc++.h>
using namespace std;
int n,k,x,y;
vector<int>l{0};
set<int> V;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int main()
{
f>>n;
for(int i=1;i<=n;++i)
  {f>>x;
  if(x==1)
   {f>>y;
   l[++k]=y;
   V.insert(y);}
   else if(x==2)
    {f>>y;
    V.erase(l[y]);}
   else if(x==3)
    g<<*V.begin()<<endl;}}
