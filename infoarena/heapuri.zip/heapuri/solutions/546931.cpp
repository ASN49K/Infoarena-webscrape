# include <fstream.h>
#include <math.h>
ifstream f("heapuri.in");
ofstream g("heapuri.out");
long long v[200000000],min;
int x,n,o,m,i,j;
int main()
{
	f>>n;
	for(i=1;i<=n;i++)
	{
		f>>o;
		if(o==1)
		{
			f>>x;
			v[++m]=x;
		}
		else 
			if(o==2)
			{
				f>>x;
			v[x]=0;
			}
			else
			{
				min=pow(2,30);
				for(j=1;j<=m;j++)
					if(min>v[j]&&v[j]!=0)
						min=v[j];
					g<<min<<'\n';
			}
	}
	
	f.close();
	g.close();
	return 0;
}