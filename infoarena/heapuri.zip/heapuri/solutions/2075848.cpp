#include <fstream>
#include <vector>

class Heap {
private:
    std::vector< std::pair<int, int> > h;  /// structura de heap in sine
    std::vector<int> poz; /// pozitia unui element, in ordinea inserarii

    int Parent(const int &index) const {
        return (index - 1) / 2;
    }
    int LeftSon(const int &index) const {
        return 2 * index + 1;
    }
    int RightSon(const int &index) const {
        return 2 * index + 2;
    }
    bool HasLeftSon(const int &index) const {
        return 2 * index + 1 < (int)h.size();
    }
    bool HasRightSon(const int &index) const {
        return 2 * index + 2 < (int)h.size();
    }
    bool IsLeaf(const int &index) const {
        return !HasLeftSon(index);
    }

    int GetKey(const int &index) const {
        return h[index].first;
    }
    int GetIndex(const int &index) const {
        return h[index].second;
    }

    void SwapNodes(const int &index1, const int &index2) {
        poz[GetIndex(index1)] = index2;
        poz[GetIndex(index2)] = index1;
        std::swap(h[index1], h[index2]);
    }

    void Sift(int index) {
        while (index > 0 && GetKey(index) < GetKey(Parent(index))) {
            SwapNodes(index, Parent(index));
            index = Parent(index);
        }
    }

    void Percolate(int index) {
        while (!IsLeaf(index)) {
            int son_with_lowest_key = LeftSon(index);
            double son_lowest_key = GetKey(son_with_lowest_key);
            if (HasRightSon(index)) {
                double right_son_key = GetKey(RightSon(index));
                if (right_son_key < son_lowest_key) {
                    son_with_lowest_key = RightSon(index);
                    son_lowest_key = right_son_key;
                }
            }
            if (son_lowest_key < GetKey(index)) {
                SwapNodes(index, son_with_lowest_key);
                index = son_with_lowest_key;
            } else {
                break;
            }
        }
    }
public:
    Heap() {}

    void Push(int key) {
        int index = poz.size();
        h.push_back({key, index});
        poz.push_back(h.size() - 1);

        Sift(h.size() - 1);
    }

    int Min() {
        return h[0].first;
    }

    void RemoveKth(int k) {
        int p = poz[k];
        SwapNodes(p, h.size() - 1);
        h.pop_back();

        Sift(p);
        Percolate(p);
    }
};

int main()
{
    std::ifstream cin("heapuri.in");
    std::ofstream cout("heapuri.out");
    Heap h;
    int n;
    cin >> n;
    for (int type, x, i = 1; i <= n; ++ i) {
        cin >> type;
        if (type == 1) {
            cin >> x;
            h.Push(x);
        } else if (type == 2) {
            cin >> x;
            h.RemoveKth(x - 1);
        } else {
            cout << h.Min() << "\n";
        }
    }
    return 0;
}
