#include <set>
#include <cstdio>
#include <fstream>
#define nmax 2000010
using namespace std;

set <int> Heap;


int main()
{
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");

    int Ord[nmax];
    int N,C=0,nr,i,act;

    freopen("heapuri.in", "r", stdin);
	freopen("heapuri.out", "w", stdout);

	scanf("%d",&N);
	for(i=1;i<=N;i++)
	{
	    scanf("%d",&act);
	    switch(act)
	    {
	        case 1:{
	            C++;
                scanf("%d",&Ord[C]);
                Heap.insert(Ord[C]);
	        }break;
	        case 2:{
	            scanf("%d",&nr);
	            if (Heap.find(Ord[nr])!=Heap.end())
                    Heap.erase(Heap.find(Ord[nr]));
	        }break;
	        case 3:{
                printf("%d \n",*Heap.begin());
	        }
	    }
	}

}
