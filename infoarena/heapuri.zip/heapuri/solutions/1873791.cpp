#include <bits/stdc++.h>
#define nmax 200001
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int n,m;
int poz[nmax];
int H[nmax];

void InsertVal(int x, int m)
{int fiu,tata;
 fiu=++n;
 tata=n/2;
 while(tata&&H[tata]>x)
 {H[fiu]=H[tata];
  poz[tata]=fiu;
  fiu=tata;
  tata=fiu/2;
  }
 H[fiu]=x;
 poz[m]=fiu;
}

void comb(int i)
{int v=H[i],tata=i,fiu=2*i;
 while(fiu<=n)
 {if(fiu<n)
    if(H[fiu]>H[fiu+1]) fiu++;
  if(v>H[fiu])
    {H[tata]=H[fiu];
     poz[fiu]=tata;
     tata=fiu; fiu=fiu*2;
    }
  else
    fiu=n+1;
 }
 H[tata]=v;
 poz[i]=tata;
}


void elim(int k)
{H[k]=H[n]; --n;
 poz[n]=k;
 comb(k);
}

void read()
{int i,cod,x,nr;
 f>>nr;
 for(i=1;i<=nr;i++)
    {f>>cod;
     if(cod==1)
       { f>>x; m++;
         InsertVal(x,m);
       }
     if(cod==2)
       {f>>x;
        elim(poz[x]);
       }
     if(cod==3)
       g<<H[1]<<"\n";
    /*
     for(int j=1;j<=n;j++)
        g<<H[j]<<" ";
     g<<"\n";
     */


    }
}

int main()
{read();
 return 0;
}
