#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");


struct adat
{
    int a,bi;
};

vector <adat> x;
int f,h;
vector <int> g;

void be(int uj,int sorsz)
{
    x.push_back({uj,sorsz});
    int akt=x.size()-1;
    g[sorsz]=akt;
    while(akt>1 && x[akt/2].a>x[akt].a)
    {
        swap(x[akt/2],x[akt]);
        swap(g[x[akt/2].bi],g[x[akt].bi]);
        akt/=2;
    }
}

void torol(int poz)
{
    x[poz]=x.back();
    g[x[poz].bi]=poz;
    x.pop_back();
    int p=0;
    while(p!=poz)
    {
        p=poz;
        if(p*2<x.size() && x[p*2].a<x[poz].a) poz=p*2;
        if(p*2+1<x.size() && x[p*2+1].a<x[poz].a) poz=p*2+1;
        swap(x[poz],x[p]);
        swap(g[x[poz].bi],g[x[p].bi]);
    }
}

int mini()
{
    return x[1].a;
}

int main()
{
    int i,j,n,a,b;
    fin>>n;
    g.resize(n+1);
    x.push_back({88,44});
    for(i=1;i<=n;i++)
    {
        fin>>a;
        if(a==1)
        {
            fin>>b;
            f++;
            be(b,f);

        }
        if(a==2)
        {
            fin>>b;
            h=g[b];
            torol(h);
        }
        if(a==3) fout<<mini()<<"\n";
    }
    return 0;
}
