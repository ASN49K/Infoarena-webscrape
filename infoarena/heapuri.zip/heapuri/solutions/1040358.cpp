#include<fstream>
#include<set>
#define NMax 200005
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int v[NMax], x, op, n, i, k;
multiset <int> s;
int main ()
{
    f>>n;
    for(i=1;i<=n;++i)
    {
        f>>op;
        if(op==1)
        {
            f>>x;
            v[++k]=x;
            s.insert(x);
        }
        else
        if(op==2)
        {
            f>>x;
            s.erase(v[x]);
        }
        else
            g<<*s.begin()<<"\n";
    }
    return 0;
}
