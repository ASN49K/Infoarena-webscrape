#include <fstream>
#include <set>
using namespace std;

int n, a[200001], c, x, cnt;
multiset<int> heap;

int main()
{
	ifstream in("heapuri.in"); ofstream out("heapuri.out");
	in>>n;
	for (i=0;i<n;i++)
	{
		in>>c;
		switch(c)
		{
			case 1: in>>x; a[++cnt] = x; heap.insert(x); break;
			case 2: in>>x; heap.erase(heap.find(a[x])); break;
			case 3: out<<*heap.begin()<<"\n"; break;
		}
	}
	in.close(); out.close();
	return 0;
}
