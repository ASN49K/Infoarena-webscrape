#include <iostream>
#include <fstream>
#include <set>

using namespace std;

set <int> heap;
int n, poz[200005], m, cod, x, i;

int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    f>>n;
    for(i = 1; i <= n; i++)
    {
        f >> cod;
        if(cod == 1)
        {
            f >> x;
            heap.insert(x);
            poz[++m] = x;
        }
        else if(cod == 2)
        {
            f >> x;
            heap.erase(poz[x]);
        }
        else
            g << *heap.begin() << '\n';
    }
    f.close();
    g.close();
    return 0;
}
