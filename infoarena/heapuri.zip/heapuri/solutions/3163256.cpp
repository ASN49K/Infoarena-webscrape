#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int n = 1;

vector<pair<int,int>> h;

void Adaug(int num)
{
    h.push_back({num, n});
    int ind = n;
    n++;
    while(ind != 1 && h[ind].first < h[ind/2].first)
    {
        swap(h[ind], h[ind/2]);
        ind /= 2;
    }
}

void Sterge(int ind)
{
    int poz;
    for(int i = 1; i < n; i++)
        if(h[i].second == ind)
        {
            poz = i;
            break;
        }
    swap(h[poz], h[n-1]);
    n--;
    h.pop_back();
    while((poz*2 < n && h[poz].first > h[poz*2].first) || (h[poz].first > h[poz*2+1].first) && poz*2+1 < n)
    {
        int minim = poz*2;
        if(h[minim].first > h[minim+1].first && poz*2+1 < n)
        {
            minim++;
        }
        swap(h[minim], h[poz]);
        poz = minim;
    }
}

int main()
{
    int x;
    fin >> x;
    h.push_back({0, 0});
    for(int i = 0; i < x; i++)
    {
        int cer, num;
        fin >> cer;
        if(cer == 1)
        {
            fin >> num;
            Adaug(num);
        }
        else if(cer == 2)
        {
            fin >> num;
            Sterge(num);
        }
        else
            fout << h[1].first << "\n";
    }
    return 0;
}
