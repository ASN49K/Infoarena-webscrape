
#include <iostream>
#include <fstream>
#include <set>
#include <vector>

int main()
{
    std::ifstream in("heapuri.in");
    std::ofstream out("heapuri.out");

    std::multiset<long long> heap;
    std::vector<long long> mult;
    int N;
    in >> N;
    for(int i = 1; i <= N; ++i){
        int task_num;
        in >> task_num;

        int x;
        switch(task_num){

        case 1:
            in >> x;
            heap.insert(x);
            mult.push_back(x);
            break;
        case 2:
            in >> x;
            heap.erase(heap.find(mult[x]));
            break;
        default:
            std::multiset<long long>::iterator it = heap.begin();
            out << *it;
            break;
        }
    }
    return 0;
}
