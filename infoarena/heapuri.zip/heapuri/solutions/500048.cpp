#include <stdio.h>
#include <set>

using namespace std;

int i,n,x,v[200002],m,sw;
set<int> heap;

int main()
{
	FILE *f,*g;
	f=fopen("heapuri.in","r");
	g=fopen("heapuri.out","w");

	fscanf(f,"%d",&n);
	m=0;
	for(i=0;i<n;i++)
	{
		fscanf(f,"%d",&sw);
		if(sw==2)
		{
			fscanf(f,"%d",&x);
			heap.erase(v[x]);
		}
		else
		if(sw==1)
		{
			fscanf(f,"%d",&v[++m]);
			heap.insert(v[m]);
		}
		else
		if(sw==3)
			fprintf(g,"%d\n",*heap.begin());
	}

	return 0;
}
