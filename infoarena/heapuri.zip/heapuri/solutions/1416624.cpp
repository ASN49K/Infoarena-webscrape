#include <stdio.h>

using namespace std;

int n, nr, minim = 1000000002, poz[200100];
FILE*f=fopen("heapuri.in","r"),*g=fopen("heapuri.out","w");

struct heap
{
    int x, e;
}v[200100];

void inserare(int a, int k)
{
    nr++;
    v[nr].x = a;
    v[nr].e = k;
    int c = nr, p = nr - 1;
    poz[k] = nr;
    while(p >= 1)
    {
        if(p+1 < nr && v[p+1].x > v[p].x)
            p++;
        if(v[c].x < v[p].x)
        {
            poz[v[c].e] = p;
            poz[v[p].e] = c;
            heap aux = v[c];
            v[c] = v[p];
            v[p] = aux;
        }
        else break;
        c = p;
        p /= 2;
    }
}


void stergere(int a)
{
    v[poz[a]] = v[nr];
    nr--;
    int p = poz[a], c = poz[a] + 1l;;
    while(c <= nr)
    {
        if(c+1 < nr && v[c+1].x > v[c].x)
            c++;
        if(v[c].x < v[p].x)
        {
            heap aux = v[c];
            v[c]= v[p];
            v[p]= aux;
        }
        else break;
        p = c;
        c = 2 * p;
    }
}

int main()
{
    int o, y;
    fscanf(f,"%d ",&n);
    int in = 0;
    for(int i = 1; i <= n; i++)
    {
        fscanf(f,"%d",&o);
        if(o != 3)
            fscanf(f,"%d ",&y);
        if(o == 1)
        {
            in++;
            inserare(y, in);
        }
        if(o == 2)
            stergere(y);
        if(o == 3)
            fprintf(g,"%d\n", v[1]);
    }
    return 0;
}
