#include <iostream>
#define MAX 200005

using namespace std;

int t,n=0,l=0,h[MAX],poz[MAX],a[MAX];


void percolate(int x){
	
	int temp;
	
	while((x>1)&&(a[h[x/2]]>a[h[x]])){
		temp=h[x];
		h[x]=h[x/2];
		h[x/2]=temp;
		
		poz[h[x]]=x;
		poz[h[x/2]]=x/2;
		
		x=x/2;
		
	}
	
}


void sift(int x){
	int son=x,temp;
	bool jo=true;
	
	while(jo){
		jo=false;
		
		son=x;
		
		if(x*2<=l && a[h[x]]>a[h[x*2]])son=x*2;
		
		if(x*2+1<=l && a[h[x*2+1]]<a[h[son]])son=2*x+1;
		
		if(son!=x){
		temp=h[x];
		h[x]=h[son];
		h[son]=temp;
		
		poz[h[x]]=x;
		poz[h[son]]=son;
		jo=true;}
		
	}
	
}


void insert(int x){
	
	n++;
	a[n]=x;
	l++;
	h[l]=n;
	poz[n]=l;
	
	percolate(l);
	
}

void sterge(int x){
int temp=poz[x];

h[temp]=h[l];
poz[h[l]]=temp;
l--;
	
	if(temp>1 && a[h[temp]]<a[h[temp/2]])percolate(temp);
	
	if((temp*2<=l && a[h[temp]]>a[h[temp*2]])||(temp*2+1<=l && a[h[temp]]>a[h[temp*2+1]]))sift(temp);
}


void afiseaza(){
	printf("%d\n",a[h[1]]);
}

int main(){
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	
	int i,temp1,temp2;
	
	scanf("%d",&t);
	
	for(i=1;i<=t;i++){
		scanf("%d",&temp1);
		
		switch(temp1){
		case 1:
			scanf("%d",&temp2);
			insert(temp2);
			break;
		case 2:
			scanf("%d",&temp2);
			sterge(temp2);
			break;
		case 3:
			afiseaza();
			break;
			
		};
		
	}
	
	
	return 0;}
