#include<fstream>
#include<set>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

set <int> Set;
int N,Dim,V[200005];

int main(){
    fin>>N;
    for(int i=1;i<=N;i++){
        int X;
        fin>>X;
        if(X==1){
            fin>>V[++Dim];
            Set.insert(V[Dim]);
        }
        if(X==2){
            int Y;
            fin>>Y;
            Set.erase(Set.find(V[Y]));
        }
        if(X==3){
            set <int> :: iterator it=Set.begin();
            fout<<*it<<'\n';
        }
    }
}
