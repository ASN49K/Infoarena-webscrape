#include <fstream>
using namespace std;
ifstream cin("heapuri.in");
ofstream cout("heapuri.out");
#define maxn 200000
#define maxn1 2000000000
int heap[maxn],N,o,x,poz=0,mi=maxn1,poz2;
int main()
{
    cin>>N;
    for(int i=1; i<=N; i++){
        cin>>o;
        if(o==3){
            if(heap[poz2]==maxn1){
                mi=maxn1;
                for(int i=1; i<=poz; i++)
                    if(heap[i]<mi&&heap[i]!=maxn1){
                        mi=heap[i];
                        poz2=i;
                    }
            }
        cout<<mi<<'\n';
        }else if(o==2){
            cin>>x;
            heap[x]=maxn1;
        }
        else {
            cin>>x;
            heap[++poz]=x;
        }
    }
    return 0;
}
