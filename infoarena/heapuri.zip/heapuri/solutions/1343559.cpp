#include <fstream>
#include <iostream>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
int n,heap[200009],nr,len;
int pozitie[200009];
int valori[200009];

void sift(int N,int k){
  int son;
  do{

    son = 0;
    if(k*2<=N){ son=k*2;
       if(k*2+1 <=N && valori[heap[k*2]]>valori[heap[k*2+1]]) son = k*2+1;
       if(son>N) son = 0;
    }
    if(son){swap(heap[k],heap[son]);
    pozitie[heap[k]]=k;
    pozitie[heap[son]]=son;
    k=son;}

  }while(son);


}
void percolate(int zice,int k){

     int val = heap[k];
    while(k>1 && valori[heap[k/2]]>valori[val] ){
        heap[k]=heap[k/2];
        pozitie[heap[k]]=k;
        k=k/2;
    }
    heap[k]=val;
    pozitie[heap[k]]=k;


}

int main()
{   int x;
    int op;
    f>>nr;
    for(int i=1;i<=nr;i++){

        f>>op;
        if(op==1){
            f>>x;
            valori[++n] = x;
            heap[++len]= n;
            pozitie[n]=len;
            percolate(len,len);
        }
        else if(op == 2){
            f>>x;
            valori[x]=-1;
            percolate(len,pozitie[x]);
            pozitie[heap[1]]=0;
            heap[1]=heap[len--];
            pozitie[heap[1]]=1;
            if(len>1)sift(len,1);
        }
        else g<<valori[heap[1]]<<endl;
    }
    f.close();g.close();
    return 0;
}
