#include<stdio.h>
using namespace std;
int n,p;
int heap[200002];
int poz[200002];//al x-lea inserat
int loc[200002];//unde se afla heap[x] in poz

int tata(int nod)
{
	return nod/2;
}

int fs(int nod)//fiu din stanga
{
	return nod*2;
}

int fd(int nod)//fiu din dreapta
{
	return nod*2+1;
}

void swap(int &a,int &b)//interschimbare
{
	int aux;
	aux=a;
	a=b;
	b=aux;
}

void sift(int k)//cautam un nod sa il ducem cat mai jos(max)
{
	int x,hx,hk;
	do
	{
		x=0;
		if(fs(k) <= n)
			x=fs(k);
		if(fd(k) <=n && heap[fd(k)] < heap[fs(k)])
			x=fd(k);
		if(x>0 && heap[x] >= heap[k])
			x=0;
		if(x)
		{
			kx=heap[x]; hk=heap[k];
			swap(heap[x],heap[k]);
			swap(poz[loc[hx]],poz[loc[hk]]);
		}
	}while(x);
}

void perc(int k)//cautam un nod sa il ducem cat mai sus(min)
{
	int hk,htk;
	while(k > 1 && heap[tata(k)] > heap[k])
	{
		hk=heap[k]; htk=heap[tata[k]];
		swap(heap[k],heap[tata(k)]);
		swap(poz[loc[hk]],poz[loc[htk]]);
		k=tata(k);
	}
}

void add(int k)//inseram in heap
{
	n++; p++;
	poz[p]=n;
	loc[k]=p;
	heap[n]=k;
	perc(n);
}

void sterg(int k)//stergem din heap
{
	int hk;
	hk=heap[k];
	heap[k]=heap[n];
	poz[loc[hk]]=poz[n];
	n--;
	if(k>1 && heap[k] < heap[tata(k)])
		perc(k);
	else
		sift(k);
}

int main()
{
	int i,cod,x,k;
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	scanf("%d",&k);
	for(i=1;i<=k;i++)
	{
		scanf("%d",&cod);
		if(cod==3)
			printf("%d\n",heap[1]);
		else
		{
			scanf("%d",&x);
			if(cod==1)
				add(x);
			else
				sterg(poz[x]);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
