#include <bits/stdc++.h>
using namespace std;
struct heap_node
{
    int val, poz_in_vec;
}v[800005], aux;
int w[800005];
void heap_push(int poz, heap_node Node)
{
    if(v[poz].poz_in_vec == 0 || Node.val < v[poz].val)
    {
        if(v[poz].poz_in_vec != 0)
        {
            if(v[2 * poz].poz_in_vec == 0)heap_push(2 * poz, v[poz]);
            else if (v[2 * poz + 1].poz_in_vec == 0)heap_push(2 * poz + 1, v[poz]);
            else if(v[2 * poz].val > v[2 * poz + 1].val)heap_push(2 * poz, v[poz]);
            else heap_push(2 * poz + 1, v[poz]);
        }
        v[poz] = Node;
        w[v[poz].poz_in_vec] = poz;            // w[poz] = the node in heap where we have the poz-th elem
    }
    else
    {
        if(v[2 * poz].poz_in_vec == 0)heap_push(2 * poz, Node);
        else if (v[2 * poz + 1].poz_in_vec == 0)heap_push(2 * poz + 1, Node);
        else if(v[2 * poz].val > v[2 * poz + 1].val)heap_push(2 * poz, Node);
        else heap_push(2 * poz + 1, Node);
    }
}
void remove_heap_node(int poz)
{
    if(v[2 * poz].poz_in_vec == 0 && v[2 * poz + 1].poz_in_vec == 0)
    {
        v[poz].poz_in_vec = 0;
    }
    else if(v[2 * poz].poz_in_vec == 0)
    {
        v[poz] = v[2 * poz + 1];
        w[v[poz].poz_in_vec] = poz;
        remove_heap_node(2 * poz + 1);
    }
    else if(v[2 * poz + 1].poz_in_vec == 0)
    {
        v[poz] = v[2 * poz];
        w[v[poz].poz_in_vec] = poz;
        remove_heap_node(2 * poz);
    }
    else if(v[2 * poz].val < v[2 * poz + 1].val)
    {
        v[poz] = v[2 * poz];
        w[v[poz].poz_in_vec] = poz;
        remove_heap_node(2 * poz);
    }
    else
    {
        v[poz] = v[2 * poz + 1];
        w[v[poz].poz_in_vec] = poz;
        remove_heap_node(2 * poz + 1);
    }
}
int n, i, op, ct, x, poz;
int main()
{
    ifstream f("heapuri.in");
    ofstream g("heapuri.out");
    f >> n;
    for(i = 1; i <= n; i ++)
    {
        f >> op;
        if(op == 1)
        {
            f >> x;
            ct = ct + 1;
            aux.val = x;
            aux.poz_in_vec = ct;
            heap_push(1, aux);
        }
        if(op == 2)
        {
            f >> poz;
            remove_heap_node(w[poz]);
        }
        if(op == 3)
        {
            g << v[1].val << "\n";
        }
    }
    return 0;
}
