#include <bits/stdc++.h>

using namespace std;

ifstream fin ("heapuri.in");
ofstream fout ("heapuri.out");

int k, l, heap[100000], v[100000], pos[100000];

void urca (int poz)
{
    while ( poz/2 && v[heap[poz/2]] > v[heap[poz]] )
    {
        swap (pos[heap[poz/2]], pos[heap[poz]]);
        swap (heap[poz/2], heap[poz]);
        poz /= 2;
    }
}

void baga (int x)
{
    k++, l++;
    v[k] = x;
    heap[l] = k;
    pos[k] = l;
    urca(l);
}

void coboara (int poz)
{
    int a;
    bool da = true;
    while ( da && 2*poz <= l )
    {
        da = false;
        a = 2*poz;
        if ( 2*poz <= l && v[heap[2*poz]] > v[heap[2*poz+1]] )
            a++;
        if ( v[heap[a]] < v[heap[poz]] )
        {
            swap (pos[heap[a]], pos[heap[poz]]);
            swap (heap[a], heap[poz]);
            poz = a;
            da = true;
        }
    }
}

void scoate (int poz)
{
    pos[heap[l]] = poz;
    heap[poz] = heap[l];
    l--;
    if ( poz/2 && v[heap[poz/2]] > v[heap[poz]] )
        urca(poz);
    else
        coboara(poz);
}
int main()
{
    int n;
    fin>>n;
    while (n--)
    {
        int cod;
        fin>>cod;
        if ( cod == 1 )
        {
            int x;
            fin>>x;
            baga(x);
        }
        if ( cod == 2 )
        {
            int x;
            fin>>x;
            scoate (pos[x]);
        }
        if ( cod == 3 )
            fout<<v[heap[1]]<<'\n';
    }

}
