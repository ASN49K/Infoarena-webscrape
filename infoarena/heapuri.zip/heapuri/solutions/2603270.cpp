#include <iostream>
#include <bits/stdc++.h>

using namespace std;
ifstream r("heapuri.in");
ofstream w("heapuri.out");
int g[200002], ans=1, cnt=1;
struct heap
{
    int val, pos;
} v[200002];
void push(int x)
{
    int c=cnt;
    cnt++;
    v[c].val=x;
    v[c].pos=ans;
    while(v[c].val<v[c/2].val)
    {
        swap(v[c], v[c/2]);
        g[v[c].pos]=c;
        g[v[c/2].pos]=c/2;
        c/=2;
    }
    g[ans]=c;
    ans++;
}
void pop(int poz)
{
    cnt--;
    int c=cnt;
    swap(v[poz], v[c]);
    g[v[poz].pos]=poz;
    v[c].val=v[c].pos=0;
    while((v[poz].val>v[poz*2].val && v[poz*2].pos!=0)||(v[poz].val>v[poz*2+1].val && v[poz*2+1].pos!=0))
    {
        if(v[poz*2+1].pos==0 || v[poz*2].val<v[poz*2+1].val)
        {
            swap(v[poz], v[poz*2]);
            g[v[poz].pos]=poz;
            g[v[poz*2].pos]=poz*2;
            poz*=2;
        }
        else
        {
            swap(v[poz], v[poz*2+1]);
            g[v[poz].pos]=poz;
            g[v[poz*2+1].pos]=poz*2+1;
            poz*=2;
            poz++;
        }
    }

}
int main()
{
    int n;
    r>>n;
    for(int i=0; i<n; i++)
    {
        int x;
        r>>x;
        if(x==1)
        {
            int val;
            r>>val;
            push(val);
        }
        else if(x==2)
        {
            int val;
            r>>val;
            pop(g[val]);
        }
        else
        {
            w<<v[1].val<<"\n";
        }
    }
    return 0;
}
