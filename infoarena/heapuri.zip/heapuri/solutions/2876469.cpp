/*#include <iostream>
#include <queue>

using namespace std;

int main()
{
    int val;
    priority_queue <int> myheap;
    pair <int, int>;
    myheap.push(val);
    myheap.top();
    myheap.pop();///elimina top
    return 0;
}
*/

/*#include <iostream>
#include <set>

using namespace std;

int main()
{
    int val;
    set <int> myheap;
    myheap.insert(val);
    myheap.erase(val);
    myheap.erase(myheap.begin());
    myheap.erase(myheap.find(val));
    val = *myheap.begin();///iteratorul
    set <int> :: iterator it;
    it = myheap.end();
    it--;
    val = *it;

    multiset <int> myheap2;
    return 0;
}*/

#include <iostream>
#include <fstream>
#include <set>

using namespace std;

int main()
{
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");

    set <int> myset;
    int n, x, op, v[100], cnt = 0;

    in>>n;

    while(n != 0){
        in>>op;

        switch(op){
            case 1:
                {
                in>>x;
                cnt++;
                myset.insert(x);
                v[cnt] = x;
                break;
                }
            case 2:
                {
                in>>x;
                int val = v[x];
                myset.erase(val);
                break;
                }
            case 3:
                {
                out<<*myset.begin()<<"\n";
                break;
                }
            default:
                break;
        }
        n--;
    }
    out.close();
    in.close();
    return 0;
}
