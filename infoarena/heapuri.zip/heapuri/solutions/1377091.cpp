#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <list>


using namespace std;

ifstream f("heapuri.in");
ofstream g("heapuri.out");

vector<int>  v;


int main()
{
    int n;
    f>>n;
    for(int i=0;i<n;++i)
    {
        int c,x;
        int e=0;
        f>>c;
        if(c==1)
        {
            f>>x;
            v.push_back(x);


        }
        else if(c==2)
        {
            f>>x;
            e++;
            v.erase(v.begin()+x-1-e);

        }
        else
        {
            vector<int> h(v.begin(), v.end());
            make_heap(h.begin(), h.end(), greater<int> ());
            cout<<*(h.begin())<<"\n";

        }
    }
}
