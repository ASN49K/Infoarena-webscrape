#include <fstream>
#include <set>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int o, n, i, x, k, cronos[200001];
int main()
{
    fin.sync_with_stdio(false);
    fout.sync_with_stdio(false);
    fin >> n;
    multiset <int> s;
    for (i = 1; i <= n; i++)
    {
        fin >> o;
        if (o == 1)
        {
            fin >> x;
            cronos[++k] = x;
            s.insert(x);
        }
        if (o == 2)
        {
            fin >> x;
            s.erase(s.find(cronos[x]));
        }
        if (o == 3)
            fout << (*s.begin()) << '\n';
    }
    fout.close();
    return 0;
}
