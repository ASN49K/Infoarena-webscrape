#include <bits/stdc++.h>
#define MAX 2000000000

using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
struct heapuri
{
    int poz,val;
}h[200003];
int n,m,i,x,poz,cerinta,p[200003];
void heapup(int x)
{
    if(x>1)
    {
        if(h[x].val<h[x/2].val)
        {
            swap(h[x],h[x/2]);
            p[h[x].poz]=x;
            p[h[x/2].poz]=x/2;
            heapup(x/2);
        }
    }
}
void heapdown(int x,int n)
{
    int dr,st;
    if(2*x<=n)
    {
        st=h[2*x].val;
        if(2*x+1<=n)dr=h[2*x+1].val;
        else dr=st+1;

        if(min(st,dr)<h[x].val)
        {
            if(h[x].val>h[x*2].val)
            {
                swap(h[x],h[x*2]);
                p[h[x].poz]=x;
                p[h[2*x].poz]=2*x;
                heapdown(x*2,n);
            }
            else if(h[x].val>h[x*2+1].val)
            {
                swap(h[x],h[x*2]);
                p[h[x].poz]=x;
                p[h[2*x+1].poz]=2*x+1;
                heapdown(x*2+1,n);
            }
        }
    }
}
int main()
{
    f>>m;
    for(i=1;i<=m;i++)
    {
        f>>cerinta;
        if(cerinta==1)
        {
            f>>x;
            n++;
            h[n].val=x;
            h[n].poz=n;
            p[h[n].poz]=n;
            heapup(n);
        }
        else if(cerinta==2)
        {
            f>>poz;
            h[p[poz]].val=MAX;
            heapdown(p[poz],n);
        }
        else g<<h[1].val<<'\n';
    }
    return 0;
}
