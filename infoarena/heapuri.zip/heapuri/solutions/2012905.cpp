#include <fstream>
using namespace std;
ifstream in("heapuri.in");
ofstream out("heapuri.out");
const int N = 200005;
int h[N],loc[N],poz[N];
void urc(int f){
    while(f/2 && loc[h[f]] < loc[h[f/2]]){
        swap(h[f],h[f/2]);
        poz[h[f]] = f;
        poz[h[f/2]] = f/2;
        f /= 2;
    }
}
void cobor(int t, int l){
    int f = 0;
    while(t != f){
        f = t;
        if(f*2 <= l && loc[h[t]] > loc[h[f*2]])
            t = f*2;
        if(f*2 + 1 <= l && loc[h[t]] > loc[h[f*2+1]])
            t = f*2+1;
        swap(h[t],h[f]);
        poz[h[t]] = t;
        poz[h[f]] = f;
    }
}
int main()
{
    int n,op,l = 0,nr = 0,x;
    in>>n;
    for(int i=1;i<=n;i++){
        in>>op;
        if(op == 1){
            in>>x;
            loc[++nr] = x;
            h[++l] = nr;
            poz[nr] = l;
            urc(l);
        }
        else if(op == 2){
            in>>x;
            loc[x] = -1;
            urc(poz[x]);
            poz[h[1]] = 0;
            h[1] = h[l--];
            poz[h[1]] = 1;
            if(l > 1)
                cobor(1,l);
        }
        else if(op == 3)
            out<<loc[h[1]]<<"\n";
    }
    in.close();
    out.close();
    return 0;
}
