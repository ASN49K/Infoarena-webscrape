#include<cstdio>
using namespace std;
int n,i,i1,nr,x,tip,h[1000002],a[300002],b[1000002];
void heapdown(int p)
{
	int aux;
	if(p*2>n) ;
	else
	if(h[p]>h[p*2]&&h[p]>h[p*2+1])
	{
		if(h[p*2]<h[p*2+1])
		{
			aux=h[p];
			h[p]=h[p*2];
			h[p*2]=aux;
			a[b[p*2]]=p;
			b[p]=b[p*2];
			heapdown(p*2);
		}
		else
		{
			aux=h[p];
			h[p]=h[p*2+1];
			h[p*2+1]=aux;
			a[b[p*2+1]]=p;
			b[p]=b[p*2+1];
			heapdown(p*2+1);
		}
	}
	/*else
	if(h[p]>h[p*2])
	{
		aux=h[p];
		h[p]=h[p*2];
		h[p*2]=aux;
		a[b[p*2]]=p;
		b[p]=b[p*2];
		heapdown(p*2);
	}
	else
	if(h[p]>h[p*2+1])
	{
		aux=h[p];
		h[p]=h[p*2+1];
		h[p*2+1]=aux;
		a[b[p*2+1]]=p;
		b[p]=b[p*2+1];
		heapdown(p*2+1);
	}*/
}
void heapup(int p)
{
	int aux;
	if(h[p]<h[p/2]&&p!=1)
	{
		aux=h[p];
		h[p]=h[p/2];
		h[p/2]=aux;
		a[i]=p/2;
		a[b[p/2]]=p;
		b[p]=b[p/2];
		b[p/2]=i;
		heapup(p/2);
	}
}
int main()
{
freopen("heapuri.in","r",stdin);
freopen("heapuri.out","w",stdout);
scanf("%d",&n);
for(i=1;i<=n;i++)
	h[i]=1000000002;
i=0;
for(i1=1;i1<=n;i1++)
{
	scanf("%d",&tip);
	if(tip==1)
	{
		scanf("%d",&x);
		i++;
		nr++;
		a[i]=nr;
		b[nr]=i;
		h[nr]=x;
		heapup(nr);
	}
	else
	if(tip==2)
	{
		scanf("%d",&x);
		h[a[x]]=1000000002;
		heapdown(a[x]);
		nr--;
	}
	else
	if(tip==3) printf("%d\n",h[1]);
}
return 0;
}
