#include<stdio.h>
int x,y,z,t,n,r,j,p[200001],v[200001],h[200001];
void A(int t) 
{
	int y;
	for(;t/2&&v[h[t]]<v[h[t/2]];y=h[t],h[t]=h[t/2],h[t/2]=y,p[h[t]]=t,p[h[t/2]]=t/2,t/=2);
}
int main() 
{
	freopen("heapuri.in","r",stdin),freopen("heapuri.out","w",stdout),scanf("%d",&n);
	while(n--) 
	{
		scanf("%d",&z);
      	if(z==3)
            printf("%d\n",v[h[1]]);
      	else 
		{
		  	scanf("%d",&r);
            if(z==1)
                v[++t]=r,h[++j]=t,p[t]=j,A(j);
            else
                for(v[r]=-1,A(p[r]),p[h[1]]=y=0,h[1]=h[j--],p[h[1]]=x=1;x!=y;z=h[x],h[x]=h[y],h[y]=z,p[h[x]]=x,p[h[y]]=y) 
				{
					y=x;
                    if(2*y<=j&&v[h[x]]>v[h[2*y]])
                        x=2*y;
                    if(2*y<j&&v[h[x]]>v[h[2*y+1]])
                        x=2*y+1;
				}
		}
	}
}
