#include<fstream>
#include<algorithm>
using namespace std;
ifstream f("heapuri.in");
ofstream g("heapuri.out");
struct heap
  {int val,poz;};
const int inf=-1000000001;
int i,x,n,index,q,pozitie[200001],nr=0,last,aux;
heap v[200001];
bool ok;

int minim(int a,int b)
{
    if(v[a].val<v[b].val)
        return a;
    return b;
}

void query1()
{
    nr++;last++;i=last;
    v[i].val=x;v[i].poz=nr;
    pozitie[nr]=i;
    while(v[i].val<v[i/2].val)
        {
   //       g<<v[i].val<<" "<<v[i/2].val<<" ZBOX"<<'\n';
            swap(pozitie[v[i].poz],pozitie[v[i/2].poz]);
            swap(v[i],v[i/2]);
            i/=2;
        }
}

void query2()
{
    i=pozitie[x];
    swap(pozitie[v[i].poz],pozitie[v[last].poz]);
    swap(v[i],v[last]);
    last--;
    if(v[i].val<v[i/2].val)
    {
        while(v[i].val<v[i/2].val)
        {
            swap(pozitie[v[i].poz],pozitie[v[i/2].poz]);
            swap(v[i],v[i/2]);
            i/=2;
        }
    }
    else
      {if(2*i<=last)
        {if(2*i!=last)
           {
              ok=1;
              aux=minim(2*i,2*i+1);
              while(v[i].val>v[aux].val&&ok)
              {
                  swap(pozitie[v[i].poz],pozitie[v[aux].poz]);
                  swap(v[i],v[aux]);
                  i=aux;
                  if(2*i<last)
                    aux=minim(2*i,2*i+1);
                  else
                    if(2*i==last)
                      if(v[i].val>v[2*i].val)
                        {
                           swap(pozitie[v[i].poz],pozitie[v[2*i].poz]);
                           swap(v[i],v[2*i]);
                           ok=0;
                        }
              }
           }
        else
            if(2*i==last)
              if(v[i].val>v[2*i].val)
               {
                 swap(pozitie[v[i].poz],pozitie[v[2*i].poz]);
                 swap(v[i],v[2*i]);
               }
        }
      }
}

void query3()
{
    g<<v[1].val<<'\n';
}

int main()
{
    f>>n;
    v[0].val=inf;v[0].poz=0;
    for(index=1;index<=n;index++)
    {
        f>>q;
        if(q==3)
            query3();
        else
        {
          f>>x;
          if(q==1)
              query1();
          else
              if(q==2)
                query2();
        }
    }
    f.close();g.close();
    return 0;
}
