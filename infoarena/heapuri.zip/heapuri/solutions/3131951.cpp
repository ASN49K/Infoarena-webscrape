#include <iostream>
#include <fstream>
#include <set>
#include <vector>
using namespace std;

set<int> heap;
ifstream f("heapuri.in");
ofstream g("heapuri.out");

int main()
{
    vector<int> v;
    int n, op, x;
    f >> n;

    for (int i = 0; i < n; i++)
    {
        f >> op;

        if (op == 1)
        {
            f >> x;
            heap.insert(x);
            v.push_back(x);
        }
        else if (op == 2)
        {
            f >> x;
            int el = v[x - 1];
            heap.erase(el);
        }
        else if (op == 3)
        {
            if (!heap.empty())
                g << *(heap.begin()) << "\n";
        }
    }

    f.close();
    g.close();

    return 0;
}