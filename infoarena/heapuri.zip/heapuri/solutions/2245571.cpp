#include <cstdio>

using namespace std;

int Xs[200010], Heap[200010], Pos[200010];
int hn;

void percolate(int p)
{
    int aux;

    while(p > 1 && Xs[Heap[p/2]] > Xs[Heap[p]])
    {
        aux = Heap[p];
        Heap[p] = Heap[p/2];
        Heap[p/2] = aux;

        Pos[Heap[p]] = p;
        Pos[Heap[p/2]] = p/2;

        p = p/2;
    }
}

void sift(int p)
{
    int son, aux;
    do
    {
        son = 0;
        if(p*2 <=hn && Xs[Heap[p*2]] < Xs[Heap[p]])
            son = p*2;
        else
            if(p*2+1 <= hn && Xs[Heap[p*2+1]] < Xs[Heap[p]])
                son = p*2+1;
        if (son == 0)
            continue;

        aux = Heap[p];
        Heap[p] = Heap[son];
        Heap[son] = aux;

        Pos[Heap[p]] = p;
        Pos[Heap[son]] = son;
    } while (son);
}

void push(int val, int i)
{
    ++hn;
    Xs[hn] = val;
    Heap[hn] = i;
    Pos[hn] = hn;

    percolate(hn);
}

void pop(int poz)
{
    Heap[poz] = Heap[hn];
    --hn;

    if(poz>1 && Xs[Heap[poz/2]] > Xs[Heap[poz]])
        percolate(poz);
    else
        sift(poz);
}

int main()
{
    freopen("heap.in", "r", stdin);
    freopen("heap.out", "w", stdout);

    int n = 0, m, i, j, x, comm;
    scanf("%d", &m);

    for(i=1; i<=m; ++i)
    {
        scanf("%d", &comm);
        switch (comm)
        {
            case 1:
            {
                scanf("%d", &x);
                ++n;
                push(x, n);
                continue;
            }
            case 2:
            {
                scanf("%d", &x);
                pop(Pos[x]);
                continue;
            }
            case 3:
                printf("%d\n", Xs[Heap[1]]);
        }
    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}
