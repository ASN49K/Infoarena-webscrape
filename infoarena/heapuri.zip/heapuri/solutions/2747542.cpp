#include <iostream>
#include <fstream>
#include <set>
#include <vector>

using namespace std;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

set<int> heap;
vector <int> poz(200001);
int nr;

int main()
{
    int N;  // nr comenzi

    int op;     //operatie
    int x;

    fin >> N;

    for(int i = 0; i < N; i++){

        fin >> op;

        if( op == 1){

            fin >> x;
            heap.insert(x);
            poz[++nr] = x;
        }

        else
            if( op == 2){
                fin >> x;
                heap.erase(poz[x]);
            }
            else
                if( op == 3){

                    fout << *heap.begin() << "\n";
                }
    }
    fin.close();
    fout.close();

}