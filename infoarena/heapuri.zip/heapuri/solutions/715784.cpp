#include <cstdio>
#include <string.h>
#include <vector>
#define nMax 200010

using namespace std;

int n;
vector <int> heap;
int poz[nMax];
int pozInHeap[nMax];

void swap (int &a, int &b){
    int aux = a;
    a = b;
    b = aux;
}

void adaugaHeap (int x, int pozitie)
{
    heap.push_back(x);
    n ++;
    poz[pozitie] = n;
    pozInHeap[n] = pozitie;
    int y = n;
    while (y >> 1 >= 1 && heap[y >> 1] > heap[y]){
        swap (heap[y >> 1], heap[y]);
        swap (poz[pozInHeap[y >> 1]], poz[pozitie]);
        swap (pozInHeap[y >> 1], pozInHeap[y]);
        y >>= 1;
    }
}

void stergeHeap (int pozitie)
{
    swap (heap[n], heap[poz[pozitie]]);
    int ceva = poz[pozitie];
    int altceva = pozInHeap[n];
    swap (poz[pozitie], poz[pozInHeap[n]]);
    pozInHeap[ceva] = altceva;
    //heap[n] = 199999;
    int ok = 1;
    int y = ceva;
    int min;
    n --;
    heap.pop_back();
    while (ok && y << 1 <= n){
        ok = 0;
        min = y << 1;
        if (min + 1 <= n && heap[min] > heap[min + 1]){
            min ++;
        }
        if (heap[y] > heap[min]){
            swap (heap[y], heap[min]);
            swap (poz[y], poz[min]);
            swap (pozInHeap[y], pozInHeap[min]);
            ok = 1;
            y = min;
        }
    }
}

void citire()
{
   // int N = nMax * 2;
   // for (int i = 0; i < N; ++ i){
   //     heap[i] = 199999;
  //  }
   // heap[0] = -199999;
    int k;
    heap.push_back(-9999999);
    scanf ("%d", &k);
    int i = 1;
    while (k -- ){
        int caz;
        scanf ("%d", &caz);
        if (caz == 3){
            printf ("%d\n", heap[1]);
            continue;
        }
        int x;
        scanf ("%d", &x);
        if (caz == 1){
            adaugaHeap (x, i ++);
            continue;
        }
        stergeHeap (x);
    }
}

int main()
{
    freopen ("heap.in", "r", stdin);
    freopen ("heap.out", "w", stdout);

    citire();

    return 0;
}
