#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

class Heap {
private :
    vector< pair<int,int > > a;
    vector<bool> erased;
    int size;
    int xTimer;
    void upHeap(int pos) {
        while (pos != 1 && a[pos] < a[(pos >> 1)] ) {
            swap (a[pos],a[(pos >> 1)]);
            pos >>= 1;
        }
    }
    
    void downHeap(int pos) {
        if ((pos << 1) > size) return;
        int ls = pos << 1;
        int next = ls;
        if (next + 1 <= size && a[next] > a[next + 1]) {
            next++;
        }
        
        if (a[next] < a[pos]) {
            swap (a[next],a[pos]);
            downHeap(next);
        }
    }    
    
public :

    Heap() {
        size = 0;
        a.push_back(make_pair(0,-1));    
        xTimer = 0;
        erased.resize(int(2e5) + 5);
    }
    
    bool empty() {
        return !size;
    }
        
    void insert(int value) {
        a.push_back(make_pair(value,++xTimer));
        size++;
        upHeap(size);
    }
    
    void eraseKth(int k) {
        erased[k] = true;
    }   
        
    int getMin() {
        if (empty()) {
            return -1;
        }
        
        while (erased[a[1].second]) {
           a[1] = a.back();
           a.pop_back();
           size--;
           downHeap(1);
        }
        
        return a[1].first;
    }
    
};

int main()
{
    ifstream cin("heapuri.in");
    ofstream cout("heapuri.out");
    int n, t, x;
    Heap h;
    cin >> n;
    for (int i = 0;i < n;i++) {
        cin >> t;
        if (t == 3) {
            cout << h.getMin() << "\n";
        } else {
            cin >> x;
            if (t == 1) {
                h.insert(x);
            } else {
                h.eraseKth(x);
            }
        }
    }
    return 0;
}
