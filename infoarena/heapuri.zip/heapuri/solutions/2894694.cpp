#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>
using namespace std;

ifstream in("heapuri.in");
ofstream out("heapuri.out");

const int NMAX=200001;

vector<int>heap(NMAX),pos(NMAX),val(NMAX);
int size, nr;

void push(int x){
    int node=++size;
    val[++nr]=x;
    pos[nr]=size;
    heap[size]=nr;
    while(node>>1 && val[heap[node>>1]]>val[heap[node]]){
        swap(pos[heap[node]],pos[heap[node>>1]]);
        swap(heap[node],heap[node>>1]);
        node>>=1;
    }
}

void pop(int node){
    swap(pos[heap[node]],pos[heap[size]]);
    swap(heap[node],heap[size]);
    size--;
    int c=node;
    while(node>>1 && val[heap[node>>1]]>val[heap[node]]){
        swap(pos[heap[node]],pos[heap[node>>1]]);
        swap(heap[node],heap[node>>1]);
        node>>=1;
    }
    node = c;
    int son=-1;
    while(son!=0){
        son=0;
        if(node<<1 <= size){
            son = node<<1;
            if((node<<1|1) <= size && val[heap[node<<1|1]]<val[heap[son]])
                son=node<<1|1;
            if(val[heap[node]]<val[heap[son]])
                son=0;
        }
        if(son){
            swap(pos[heap[node]],pos[heap[son]]);
            swap(heap[son],heap[node]);
            node=son;
        }
    };
}

int main()
{
    int n,tip,x;
    in>>n;
    for(int i=0;i<n;++i){
        in>>tip;
        if(tip<3)
            in>>x;
        if(tip==1)
            push(x);
        else if(tip==2)
            pop(pos[x]);
        else
            out<<val[heap[1]]<<'\n';
    }
    return 0;
}
