#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <set>
#define MAXN 200010
using namespace std;

//set<int> h;
long ord[MAXN],N,cnt,h[200000],N_linii,ii;

int main() {
	
	freopen("heapuri.in","r",stdin);
	freopen("heapuri.out","w",stdout);
	
	scanf("%ld",&N_linii);
	
	long i,x,c,k,aux;
	N=0;
	cnt=1;
	for (ii=0;ii<N_linii;++ii) {
		scanf("%ld",&c);
		if (c <= 2) scanf("%ld",&x);
		switch (c) {
			case 1: {N++;h[N]=x;k=N;
                 while(h[k]<h[k/2]&&k>1)
                    {aux=h[k/2];
                     h[k/2]=h[k];
                     h[k]=aux;
                     k=k/2;
                    }
            ord[cnt]=x;cnt++;break;}
			case 2: {  for(i=1;i<=N;i++)
                          if(h[i]==ord[x]) {h[i]=h[N];N--;k=i;break;}
                       
                        while((2*k<=N&&h[k]>h[2*k])||(2*k+1<=N&&h[k]>h[2*k+1]))
                          {if(h[2*k]<h[2*k+1])
                               {aux=h[2*k];
                                h[2*k]=h[k];
                                h[k]=aux;
                                 k=2*k;
                               }
                          else {aux=h[2*k+1];
                                 h[2*k+1]=h[k];
                                 h[k]=aux;
                                 k=2*k+1;
                                }
                           }
                          
                           while(h[k]<h[k/2])
                                {aux=h[k/2];
                                 h[k/2]=h[k];
                                 h[k]=aux;
                                 k=k/2;
                                }
                          break;}
			case 3: {printf("%ld\n",h[1]);};
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	
}
