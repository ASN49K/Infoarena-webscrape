// sursa anastasia

#include <iostream>
#include <fstream>

using namespace std;
#define MaxN 200000
#define INSERT 1
#define DELETE 2
#define QUERY 3

struct Node{
int h;
int poz;
};
Node heap[MaxN];
int heapsize;
int cro[MaxN];
inline int parent(int i) {return (i-1)/2;}
inline int leftchild(int i) {return i*2+1;}
inline int rightchild(int i) {return i*2+2;}
int getMin(){
    return heap[0].h;
}
void upheap(int i){
if(i>0 && heap[parent(i)].h > heap[i].h){
    swap(heap[parent(i)], heap[i]);
    cro[heap[i].poz]=i;
    cro[heap[parent(i)].poz]=parent(i);
    upheap(parent(i));
}
}
void downheap(int i){
int left, right, smallest;
smallest=i;
left=leftchild(i);
right=rightchild(i);
if(heap[left].h<heap[smallest].h && left<heapsize)
    smallest=left;
if(heap[right].h<heap[smallest].h && right<heapsize)
    smallest=right;
if(i!=smallest){
    swap(heap[i], heap[smallest]);
    cro[heap[i].poz]=i;
    cro[heap[smallest].poz]=smallest;
    downheap(smallest);
}
}
void add(int val, int ind){
    heap[heapsize].h=val;
    heap[heapsize].poz=ind;
    cro[ind]=heapsize;
    upheap(heapsize++);
}
void sterge(int i){
    int nod;
    nod=cro[i];
    heap[nod]=heap[heapsize-1];
    cro[heap[heapsize-1].poz]=nod;
    heapsize--;
    upheap(nod);
    downheap(nod);
}

int main()
{
    ifstream in("heapuri.in");
    ofstream out("heapuri.out");
    int q, op, x, j, cnt=0;
    in>>q;
   for(j=1; j<=q; j++){
        in>>op;
        if(op==INSERT){
            in>>x;
            add(x, cnt++);
        }
        else if(op==DELETE)
        {
            in>>x;
         sterge(x-1);
        }
        else if(op==QUERY)
            out<<getMin()<<'\n';
    }
    return 0;
}
