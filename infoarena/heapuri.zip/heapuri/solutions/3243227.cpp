#include <fstream>

using namespace std;

ifstream cin("heapuri.in");
ofstream cout("heapuri.out");

struct nod
{
    int val, poz;
};

nod v[200005];

int f[200005];

void insertfrunza(int &n, int &m)
{
    int val;
    cin>>val;
    v[++n].val=val;
    m++;
    v[n].poz=m;
    int cn=n;
    while(cn!=1)
    {
        if(v[cn].val<v[cn/2].val)
            swap(v[cn], v[cn/2]);
        cn=cn/2;
    }
}

void taiefrunza(int &n)
{
    swap(v[1], v[n]);
    n--;
    int i=1;
    while((i*2<=n || i*2+1<=n) && (v[i].val>v[i*2].val || v[i].val>v[i*2+1].val))
    {
        int ram=i*2;
        if(v[i*2].val>v[i*2+1].val)
            ram=i*2+1;
        swap(v[ram], v[i]);
        i=ram;
    }
}

int main()
{
    int q, n=0, m=0;
    cin>>q;
    for(int k=1; k<=q; k++)
    {
        int c;
        cin>>c;
        if(c==3)
            cout<<v[1].val<<'\n';
        else
        {
            if(c==1)
            {
                //insert
                insertfrunza(n,m);
            }
            else
            {
                //erase
                int poz;
                cin>>poz;
                f[poz]++;
                int p=1;
                while(f[v[1].poz]!=0)
                {
                    taiefrunza(n);
                }
            }
        }
    }
    return 0;
}
