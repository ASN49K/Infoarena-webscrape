#include <bits/stdc++.h>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
/**

operatia de tipul 1: se insereaza elementul x in multime
operatia de tipul 2: se sterge elementul intrat al x-lea in multime, in ordine cronologica
operatia de tipul 3: se afiseaza elementul minim din multime

*/
multiset<int> heap;
vector<int>v;
int n, cer;
void citire()
{
    fin>>n;
    int x;
    for(int i=1; i<=n; i++)
    {
        fin>>cer;
        if(cer == 3)
        {
            fout<<(*heap.begin())<<"\n";
        }
        else
        {
            fin>>x;
            if(cer == 1)
            {
                heap.insert(x);
                v.push_back(x);
            }
            else
            {
                int val = v[x - 1];
                heap.erase(val);
            }
        }
    }
}
int main()
{
    citire();
    return 0;
}
