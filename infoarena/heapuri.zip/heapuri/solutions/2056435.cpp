#include <bits/stdc++.h>

using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
set <int> s;
int n,i,x,type,k,v[200010];
int main() {
    fin>>n;
    for (int i=1; i<=n; ++i) {
        fin>>type;
        if (type==1) {
            fin>>x;
            s.insert(x);
            v[++k]=x;
        }
        if (type==3) fout<<*s.begin()<<'\n';
        if (type==2){fin>>x; s.erase(s.find(v[x]));}
    }
    return 0;
}
