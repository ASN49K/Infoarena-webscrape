#include <iostream>
#include <fstream>
#include <set>
#define dim 200001
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

std::set <long int,greater<long int> > mini;
void citire()
{
    int m,p,n=0;
    long int x,a[dim];
    fin>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>p;
        if(p==1)
            {
                fin>>x;
                n++;
                a[n]=x;
                mini.insert(x);}
            else if(p==2)
            {
                fin>>x;
                mini.erase(a[x]);

            }
            else
                fout<<*mini.begin()<<"\n";
    }
}
int main()
{
    citire();
    return 0;
}
