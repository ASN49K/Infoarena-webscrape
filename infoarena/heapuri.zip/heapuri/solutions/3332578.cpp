#include <fstream>
using namespace std;
ifstream fin("heapuri.in");
ofstream fout("heapuri.out");

int sz = 0;
bool deleted[int(2e5) + 5];

struct elem{
    int valoare;
    int ordin;
};

elem heap[int(2e5) + 5];

void insert(elem nod){
    sz++;
    heap[sz] = nod;
    int poz = sz;
    while (poz > 1 && heap[poz / 2].valoare >= nod.valoare){
        swap(heap[poz / 2], heap[poz]);
        poz /= 2;
    }
}
void fix_top(){
    int poz = 1;
    while (2 * poz <= sz && heap[2 * poz].valoare < heap[poz].valoare || (2 * poz + 1 <= sz && heap[2 * poz + 1].valoare < heap[poz].valoare)){
        if (heap[2 * poz].valoare < heap[poz].valoare && (2 * poz + 1 > sz || heap[2 * poz].valoare < heap[2 * poz + 1].valoare)){
            swap(heap[2 * poz], heap[poz]);
            poz = 2 * poz;
        } else {
            swap(heap[2 * poz + 1], heap[poz]);
            poz = 2 * poz + 1;
        }
    }
}
void erase(){
    swap(heap[1], heap[sz]);
    sz--;
    //    while ((heap[2].valoare && heap[1].valoare > heap[2].valoare) || (heap[3].valoare && heap[1].valoare > heap[3].valoare)){
    fix_top();
    //    }
}
int main(){
    int n, ordin = 0;
    fin >> n;
    for (int i = 1; i <= n; i++){
        elem nod;
        int cod;
        fin >> cod;
        if (cod == 1){
            ordin++;
            fin >> nod.valoare;
            nod.ordin = ordin;
            insert(nod);
        } else if (cod == 2){
            int ordin;
            fin >> ordin;
            deleted[ordin] = true;
        } else if (cod == 3){
            while (deleted[heap[1].ordin] == true) {
                erase();
            }
            fout << heap[1].valoare << '\n';
        }
    }
    return 0;
}