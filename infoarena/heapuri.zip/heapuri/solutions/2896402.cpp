#include <fstream>
#include <set>

using namespace std;

multiset<int> heap;
multiset <int> ::iterator it;

ifstream fin("heapuri.in");
ofstream fout("heapuri.out");
int poz[150001];

int main()
{
    int N, x, cod;
    fin >> N;
    int sf = 0;
    while (N--)
    {
        fin >> cod;
        if (cod == 1)
        {
            fin >> x;
            heap.insert(x);
            poz[++sf] = x;
        }
        if (cod == 2)
        {
            fin >> x;
            heap.erase(poz[x]);
        }
        if (cod == 3)
        {
            it = heap.begin();
            fout << *it << '\n';
        }
    }
    return 0;
}