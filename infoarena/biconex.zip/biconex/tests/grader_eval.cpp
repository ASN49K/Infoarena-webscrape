#include <cstdio>
#include <string>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <algorithm>
using namespace std;

#define FIN  "biconex.in"
#define FOUT "biconex.out"
#define FOK  "biconex.ok"

const int MAXN = 100005, MAX_BUFF = 1 << 20;

int  answer, tanswer, n, m;   vector <vector <int> > bok, bout, bic;

char buffer[MAX_BUFF];

string str;

void error(string msg, int p)
{
	fprintf(stderr, "%s", msg.c_str());
	printf("%d", p);
	exit(0);
}

int compare(const vector <int>& vect1, const vector <int>& vect2)
{
    if (vect1.size() != vect2.size())
        return vect1.size() < vect2.size();
	for (size_t i = 0; i < vect1.size(); ++ i)
		if (vect1[i] != vect2[i])
			return vect1[i] < vect2[i];
    return 0;
}

void sort(vector <vector <int> >& vect)
{
    for (size_t i = 0; i < vect.size(); ++ i)
        sort(vect[i].begin(), vect[i].end());
    sort(vect.begin(), vect.end(), compare);
}

int main(void)
{
    int x, y;
    FILE *f;
    vector <int> vect;

    f = fopen(FIN, "r");
    if (!f) error("Fisier de intrare lipsa", 0);
    if (fscanf(f, "%d %d", &n, &m) != 2)
        error("Eroare in fisierul de intrare", 0);
    for (int i = 0; i < m; ++ i)
    {
        if (fscanf(f, "%d %d", &x, &y) != 2)
            error("Eroare in fisierul de intrare", 0);
        if (x < 1 || x > n || y < 1 || y > n)
            error("Eroare in fisierul de intrare", 0);
    }

    f = fopen(FOK, "r");
    if (!f) error("Fisier de verificare lipsa", 0);
    if (fscanf(f, "%d\n", &answer) != 1)
        error("Eroare in fisierul ok", 0);

    for (int i = 0; i < answer; ++ i)
    {
        if (fgets(buffer, MAX_BUFF, f) == NULL)
            error("Eroare in fisierul ok", 0);

        vect.clear();
        str = buffer;
        istringstream iss(str);
        while (iss >> x) {
            if (x < 1 || x > n)
                error("Eroare in fisierul ok: nod inexistent", 0);
            vect.push_back(x);
        }
        bok.push_back(vect);
    }
    sort(bok);

    f = fopen(FOUT, "r");
    if (!f) error("Fisier de iesire lipsa", 0);
    if (fscanf(f, "%d\n", &tanswer) != 1)
        error("Fisier de iesire incomplet", 0);
    if (answer != tanswer)
        error("Componente biconexe: numar gresit", 0);
    for (int i = 0; i < answer; ++ i)
    {
        if (fgets(buffer, MAX_BUFF, f) == NULL)
            error("Componente biconexe: gresit", 4);

        vect.clear();
        str = buffer;
        istringstream iss(str);
        while (iss >> x) {
            if (x < 1 || x > n)
                error("Componente biconexe: nod inexistent", 4);
            vect.push_back(x);
        }
        bout.push_back(vect);
    }
    sort(bout);

    if (bout.size() != bok.size())
        error("Componente biconexe: numar incomplet de componente", 4);
    for (size_t i = 0; i < bout.size(); ++ i) {
        if (bout[i].size() != bok[i].size())
            error("Componente biconexe: componenta gresita", 4);
        for (size_t j = 0; j < bout[i].size(); ++ j)
            if (bout[i][j] != bok[i][j])
                error("Componente biconexe: componenta gresita", 4);
    }
    error("Corect", 10);

    return 0;
}



