#include <iostream>
#include <list>
#include <queue>
#include <vector>
#include <stack>
#include <fstream>

const int nMax = 100005;

using namespace std;

class Graf {
private:
    int m_n, m_m;
    vector<int> m_listAd[nMax];

    // DFS
    bool m_dfsViz[nMax] = {};

    // BFS
    int m_bfsDist[nMax] = {};
    queue<int> m_bfsQueue;

    // CTC
    int m_ctcId[nMax] = {}, m_ctcLow[nMax] = {}, m_ctcUltId = 0;
    bool m_ctcPeStiva[nMax] = {};
    list<list<int>> m_ctc;
    stack<int> m_ctcStack;

    // Componente biconexe
    list<list<int>> m_biconexComps;
    stack<int> m_biconexStack;
    int m_biconexLow[nMax] = {};


    // ---------------- Functii private ----------------
    void orientatCtcDFS(int x) {
        m_ctcStack.push(x);
        m_ctcPeStiva[x] = true;
        m_ctcId[x] = m_ctcLow[x] = ++m_ctcUltId;

        for (auto y: m_listAd[x]) {
            // Nu am explorat nodul pana acum (neavand vreun id)
            if (m_ctcId[y] == 0) {
                orientatCtcDFS(y);
            }

            // Am intalnit un nod care inca nu a fost atribuit unei componente conexe.
            // Poate nodul curent face parte din viitoarea componenta conexa, a carei (posibila) sursa
            // a fost gasita de y.
            if (m_ctcPeStiva[y]) {
                m_ctcLow[x] = min(m_ctcLow[x], m_ctcLow[y]);
            }
        }

        // Am ajuns la nodul de start al ctc-ului explorat in prezent
        if (m_ctcId[x] == m_ctcLow[x]) {
            list<int> compCurr;
            while (true) {
                auto y = m_ctcStack.top();
                m_ctcStack.pop();

                m_ctcPeStiva[y] = false;
                compCurr.push_back(y);

                if (y == x) break;
            }
            m_ctc.push_back(compCurr);
        }
    }

    void neorientatBiconexAdd(int x, int y) {
        // Creeaza o noua componenta pentru afisare
        list<int> comp;

        // Adauga in componenta toate nodurile pana la y, inclusiv y
        while (m_biconexStack.top() != y) {
            comp.push_back(m_biconexStack.top());
            m_biconexStack.pop();
        }
        comp.push_back(y);
        m_biconexStack.pop();

        // Adauga in componenta si pe x, separat (in caz ca e un gap in stack intre y si x)
        // ^ gap-ul poate aparea daca intalnim mai multe componente biconexe ce se intorc in acelasi nod
        comp.push_back(x);

        m_biconexComps.push_back(comp);
    }

    void neorientatBiconexDfs(int x, int prev, int id) {
        // Initializam low-ul (nodul cel mai de sus din parcurgerea DFS in care putem ajunge)
        // si punem nodul curent pe stack
        m_biconexLow[x] = id;
        m_biconexStack.push(x);

        for (auto y: m_listAd[x]) {
            // Ignoram cazul in care ne intoarcem din nodul in care am plecat
            if (y == prev) continue;

            // Nodul y nu a fost vizitat => viziteaza-l
            if (!m_biconexLow[y]) {
                // Viziteaza-l si actualizeaza low
                neorientatBiconexDfs(y, x, id + 1);
                m_biconexLow[x] = min(m_biconexLow[x], m_biconexLow[y]);

                // Am ajuns la originea ciclului / am dat peste un nod de mai jos din parcurgerea
                // DFS la care nu mai putem ajunge altfel (=> componenta biconexa)
                if (m_biconexLow[y] >= id) {
                    neorientatBiconexAdd(x, y);
                }
            }
                // Nodul y a fost vizitat => doar actualizeaza min-ul in caz ca e nevoie,
                // fara sa risti sa afisezi o componenta biconexa de doua ori
            else {
                m_biconexLow[x] = min(m_biconexLow[x], m_biconexLow[y]);
            }
        }
    }

public:
    // ---------------- Interfata publica ----------------
    explicit Graf(int n = 0, int m = 0) : m_n(n), m_m(m) {}


    /*************** Algoritmi generali ***************/
    void DFS(int k) {
        m_dfsViz[k] = true;

        for (auto x: m_listAd[k]) {
            if (!m_dfsViz[x]) {
                DFS(x);
            }
        }
    }

    const auto &BFS(int start) {
        m_bfsQueue.push(start);
        m_bfsDist[start] = 1;

        while (!m_bfsQueue.empty()) {
            int curr = m_bfsQueue.front();
            m_bfsQueue.pop();

            for (auto i: m_listAd[curr]) {
                if (m_bfsDist[i] == 0) {
                    m_bfsDist[i] = m_bfsDist[curr] + 1;
                    m_bfsQueue.push(i);
                }
            }
        }
        return m_bfsDist;
    }


    /*************** Grafuri neorientate ***************/
    void neorientatCitesteListaAdiacenta(ifstream &in) {
        for (int i = 0; i < m_m; i++) {
            int x, y;
            in >> x >> y;
            m_listAd[x].push_back(y);
            m_listAd[y].push_back(x);
        }
    }

    int neorientatNrCompConexe() {
        int nrComp = 0;
        for (int i = 1; i <= m_n; i++) {
            if (!m_dfsViz[i]) {
                nrComp++;
                DFS(i);
            }
        }
        return nrComp;
    }

    const auto &neorientatBiconexe() {
        for (int i = 1; i <= m_n; i++) {
            if (!m_biconexLow[i]) {
                neorientatBiconexDfs(i, -1, 1);
            }
        }
        return m_biconexComps;
    }


    /*************** Grafuri orientate ***************/
    void orientatCitesteListaAdiacenta(ifstream &in) {
        for (int i = 0; i < m_m; i++) {
            int x, y;
            in >> x >> y;
            m_listAd[x].push_back(y);
        }
    }

    const auto &orientatCtc() {
        // Algoritmul lui Tarjan
        for (int i = 1; i <= m_n; i++) {
            // Nu am explorat nodul pana acum (neavand vreun id)
            if (m_ctcId[i] == 0) {
                orientatCtcDFS(i);
            }
        }
        return m_ctc;
    }
};

int main() {
    // Input rapid
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    // I/O
    ifstream in("biconex.in");
    ofstream out("biconex.out");

    int n, m;
    in >> n >> m;

    Graf g(n, m);
    g.neorientatCitesteListaAdiacenta(in);
    in.close();

    const auto &comps = g.neorientatBiconexe();

    // Afisare
    out << comps.size() << "\n";
    for (auto &comp: comps) {
        for (auto x: comp) {
            out << x << " ";
        }
        out << "\n";
    }

    out.close();
    return 0;
}

