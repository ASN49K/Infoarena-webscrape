#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int N,M;
vector<bool> isVisited(100005, false);
vector<int> tin(100005);
vector<int> low(100005);
vector<vector<int>> graph(100005, vector<int>());
vector<int> biconex[100005];
stack<int> st;

int timer = 1;
int ans = 0;
int x;

void Articulation_Points(int node, int parent) {
    isVisited[node] = true;
    tin[node] = low[node] = timer++;
    st.push(node);

    for(auto neighbor : graph[node]) {
        if(neighbor == parent)
            continue;

        if(!isVisited[neighbor]) {
            Articulation_Points(neighbor, node);
            low[node] = min(low[node], low[neighbor]);

            if(low[neighbor] >= tin[node]) {
                ans++;
                do
                {
                    x=st.top();
                    st.pop();
                    biconex[ans].push_back(x);
                }while(x!=neighbor);
                biconex[ans].push_back(node);
            }
        }
        else {
            low[node] = min(low[node], tin[neighbor]);
        }
    }
}

int main() {

    fin >> N >> M;

    for(int i=1; i<=M; i++) {
        int x,y;
        fin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    Articulation_Points(1, 0);

    fout << ans << "\n";

    for(int i=1; i<=ans; i++)
    {
        for(auto j: biconex[i])
          fout<<j<<" ";
        fout<<'\n';
    }

    return 0;
}