#include <fstream>
#include <stack>
#include <vector>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

const int nmax = 100005;
int n, m, fr[nmax], nivel[nmax], nma[nmax], k;
vector<int> compbi[nmax], v[nmax];
stack<int> St;

void dfs(int nod, int dad)
{
    fr[nod] = 1;
    St.push(nod);
    nivel[nod] = nma[nod] = nivel[dad] + 1;

    for(auto x : v[nod])
        if(fr[x] && x != dad)
            nma[nod] = min(nma[nod], nivel[x]);

        else if(!fr[x])
        {
            dfs(x, nod);
            nma[nod] = min(nma[nod], nma[x]);

            if(nivel[nod] <= nma[x])
            {
                k ++;
                while(St.top() != x)
                    compbi[k].push_back(St.top()), St.pop();

                compbi[k].push_back(x);
                compbi[k].push_back(nod);
                St.pop();
            }
        }
}

int main()
{
    f >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int x, y; f >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    dfs(1, 0);

    g << k << '\n';
    for(int i = 1; i <= k; i ++, g << '\n')
        for(auto x : compbi[i])
            g << x << " ";
    return 0;
}
