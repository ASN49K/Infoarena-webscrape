#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
int n,m,nr;
vector<int> sol[100005];
vector<int> muchii[100005];
int h[100006],low[100005];
stack<int> s;
void comp(int nod,int i)
{
    nr++;
    while(s.top()!=i)
    {
        sol[nr].push_back(s.top());
        s.pop();
    }
    sol[nr].push_back(nod);
    sol[nr].push_back(i);
    s.pop();
}
void dfs(int nod,int height,int father)
{
    low[nod]=height;
    h[nod]=height;
    s.push(nod);
    for(auto i:muchii[nod])
    {
        if(!h[i])
        {
            dfs(i,height+1,nod);
            low[nod]=min(low[i],low[nod]);
            if(low[i]>=height)
                comp(nod,i);
        }
        else if(i!=father)
            low[nod]=min(low[nod],h[i]);
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    for(int i=1;i<=n;i++)
        if(!h[i])
            dfs(i,1,0);
    fout<<nr<<'\n';
    for(int i=1;i<=nr;i++,fout<<'\n')
        for(auto j:sol[i])
            fout<<j<<" ";
    return 0;
}
