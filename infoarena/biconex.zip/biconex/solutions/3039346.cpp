#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream f ("biconex.in");
ofstream g ("biconex.out");
int n,m,cnt;
stack<int>st;
vector<int>rasp[100001];
vector<int>adiacenta[100001];
bool viz[100001];
int low_link[100001],nivel[100001];
void DFS(int nod,int level)
{
    low_link[nod] = nivel[nod]=level;
    viz[nod] = 1;
    st.push(nod);
    for(auto x:adiacenta[nod])
    {
        int curent = x;
        if(!viz[curent])
        {
            DFS(curent,level+1);

            if(low_link[curent]>=nivel[nod])
            {
                cnt++;
                while(!st.empty() && st.top()!=curent)
                {
                    rasp[cnt].push_back(st.top());
                    st.pop();
                }
                rasp[cnt].push_back(st.top());
                st.pop();
                rasp[cnt].push_back(nod);
            }
            low_link[nod] = min(low_link[nod],low_link[curent]);
        }
        else
            low_link[nod] = min(low_link[nod],nivel[curent]);
    }
}
int main()
{
    f >> n >> m;
    for(int i = 1;i<=m;i++)
    {
        int x,y;
        f >> x >> y;
        adiacenta[x].push_back(y);
        adiacenta[y].push_back(x);
    }
    DFS(1,0);
    g << cnt<<'\n';
    for(int i = 1;i<=cnt;i++)
    {
        for(auto x:rasp[i])
            g << x<< " ";
        g << '\n';
    }
}
