#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
vector <int> G[100002];
int niv[100005];
int low[100005];
stack < pair <int, int> > st;
set <int> cb[100005];
int cnt;
void dfs(int nod, int t){
    niv[nod] = niv[t] + 1;
    low[nod] = niv[nod];
    for(auto x : G[nod]){
        if(x == t) continue;
        if(niv[x]) low[nod] = min(low[nod], niv[x]);
        else{
            st.push({nod, x});
            dfs(x, nod);
            low[nod] = min(low[nod], low[x]);
            if(low[x] >= niv[nod]){
                cnt++;
                while(1){
                    auto it = st.top();
                    st.pop();
                    cb[cnt].insert(it.first);
                    cb[cnt].insert(it.second);
                    if(it.first == nod && it.second == x) break;
                }
            }
        }
    }
}
int main()
{
    int n,m,i,j,u,v;
    fin >> n >> m;
    while(m--){
        fin >> u >> v;
        G[u].push_back(v);
        G[v].push_back(u);
    }
    dfs(1,0);
    fout << cnt << "\n";
    for(i = 1; i <= cnt; i++){
        for(auto x : cb[i]) fout << x << " ";
        fout << "\n";
    }
    return 0;
}
