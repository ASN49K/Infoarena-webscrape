#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
typedef pair<int,int> pii;
stack<pii> stiva;
vector<vector<int>> sol;
int n,m,niv[100005],nivmin[100005],use[100005],par[100005];
vector<int> muchii[100005];
void build(int a,int b)
{
    vector<int> v;
    while(!stiva.empty())
    {
        int x=stiva.top().first;
        int y=stiva.top().second;
        stiva.pop();
        v.push_back(x);
        v.push_back(y);
        if(x==a&&y==b)
            break;
        if(x==b&&y==a)
            break;
    }
    sort(v.begin(),v.end());
    v.erase(unique(v.begin(),v.end()),v.end());
    sol.push_back(v);
}
void dfs(int nod)
{
    use[nod]=1;
    nivmin[nod]=niv[nod];
    for(int i:muchii[nod])
    {
        if(i==par[nod])
            continue;
        if(!use[i])
        {
            par[i]=nod;
            niv[i]=niv[nod]+1;
            stiva.push({nod,i});
            dfs(i);
            nivmin[nod]=min(nivmin[nod],nivmin[i]);
            if(nivmin[i]>=niv[nod])
                build(nod,i);
        }
        else
            nivmin[nod]=min(nivmin[nod],niv[i]);
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    niv[1]=1;
    dfs(1);
    fout<<sol.size()<<'\n';
    for(auto i:sol)
    {
        for(auto j:i)
            fout<<j<<' ';
        fout<<'\n';
    }
    return 0;
}
