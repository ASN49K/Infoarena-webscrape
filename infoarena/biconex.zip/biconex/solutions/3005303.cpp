#include <fstream>
#include <algorithm>
#include <vector>
#include <bitset>
#include <stack>
#define DIM 100001
using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
int n,m,x,y,nr,lvl[DIM],low[DIM];
vector<int> l[DIM],cb[DIM];
bitset<DIM> viz;
stack<int> st;

void dfs(int nod,int niv,int tata) {
    viz[nod]=1;
    lvl[nod]=niv;
    low[nod]=niv;
    st.push(nod);
    for (int i=0;i<l[nod].size();i++) {
        int vec=l[nod][i];
        if (vec==tata)
            continue;
        if (viz[vec]==0) {
            dfs(vec,niv+1,nod);
            low[nod]=min(low[nod],low[vec]);
            if (niv<=low[vec]) {
                nr++;
                int x;
                do {
                    x=st.top();
                    st.pop();
                    cb[nr].push_back(x);
                } while (x!=vec);
                cb[nr].push_back(nod);
            }
        }
        else
            low[nod]=min(low[nod],lvl[vec]);
    }
}

int main() {
    fin>>n>>m;
    while (m--) {
        fin>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }
    for (int i=1;i<=n;i++)
        sort(l[i].begin(),l[i].end());
    dfs(1,1,0);
    fout<<nr<<"\n";
    for (int i=1;i<=nr;i++) {
        for (int j=0;j<cb[i].size();j++)
            fout<<cb[i][j]<<" ";
        fout<<"\n";
    }
    return 0;
}
