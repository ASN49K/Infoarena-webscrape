#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
int n,m,nr,niv[100001],low[100001];
vector<int> v[100001],sol[100001];
stack<int> s;
bool viz[100001];
void dfs(int i, int level)
{
    int x;
    viz[i] = 1;
    niv[i] = low[i] = level;
    s.push(i);
    for(auto vecin : v[i])
        if(!viz[vecin])
        {
            dfs(vecin, level + 1);
            low[i] = min(low[i], low[vecin]);
            if(low[vecin] >= niv[i])
            {
                sol[++nr].push_back(i); // sol[nr] = componenta biconexa nr
                x=s.top();
                s.pop();
                sol[nr].push_back(x);
                while(x != vecin)
                {
                    x = s.top();
                    s.pop();
                    sol[nr].push_back(x);
                }
            }
        }
        else low[i] = min(low[i], niv[vecin]);
}

int main()
{
    int x, y, i;
    fin>>n>>m;
    for(i = 1; i <= m; ++i)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    dfs(1,1);
    fout<<nr<<'\n';
    for(i = 1; i <= nr; ++i)
    {
        for(auto j : sol[i]) fout<<j<<" ";
        fout<<'\n';
    }
    return 0;
}
