#include <bits/stdc++.h>

using namespace std;

const int maxN = 100005, inf = 1e9;
int n, m, indeg[maxN], tin[maxN], lowlink[maxN], timer;
vector <int> G[maxN];
vector <int> stiva;
bool viz[maxN];
vector <vector <int>> comp;

void dfs(int nod, int tata) {
    // cout << "In " << nod << '\n';
    tin[nod] = ++timer;
    // cout << "At " << tin[nod] << '\n';
    lowlink[nod] = tin[nod];
    viz[nod] = 1;
    stiva.push_back(nod);
    for (int fiu : G[nod]) {
        if (fiu == tata) {
            continue;
        }
        if (viz[fiu]) {
            lowlink[nod] = min(lowlink[nod], lowlink[fiu]);
        } else {
            dfs(fiu, nod);
            lowlink[nod] = min(lowlink[nod], lowlink[fiu]);
            if (lowlink[fiu] >= tin[nod]) {
                vector <int> newcomp;
                while (stiva.back() != nod) {
                    newcomp.push_back(stiva.back());
                    stiva.pop_back();
                }
                newcomp.push_back(nod);
                comp.push_back(newcomp);
            }
        }
    }
    // cout << "Best low link for " << nod << " is " << lowlink[nod] << '\n';
}

int main() {
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("biconex.in", "r", stdin);
    freopen("biconex.out", "w", stdout);
#endif
    cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            dfs(i, 0);
        }
    }

    cout << comp.size() << '\n';
    for (auto v : comp) {
        for (int x : v) {
            cout << x << ' ';
        }
        cout << '\n';
    }

    return 0;
}