#include<fstream>
#include<vector>
using namespace std;
#define N 100001
ifstream F("biconex.in");
ofstream G("biconex.out");
vector<int> g[N];
int p,u,n,m,i,c[N],r,d[N],f[N],q[10*N];
void P(int i)
{
	c[i]=2,q[++p]=i;
	for(auto j:g[i])
        if(c[j]==1)
            P(j);
}
void E(int i)
{
	d[i]=f[i]=u++,c[i]=1;
	for(auto j:g[i])
        if(!c[j]) {
            E(j);
            if(f[i]>f[j])
                f[i]=f[j];
            if(d[i]<=f[j])
                c[i]=2,q[++p]=i,P(j),c[i]=1,q[++p]=0,++r;
        } else if(f[i]>d[j])
            f[i]=d[j];
}
int main()
{
	F>>n>>m;
	while(m--)
        F>>i>>u,g[i].push_back(u),g[u].push_back(i);
	for(i=1;i<=n;++i)
        if(!c[i]) {
            if(g[i].size())
                E(i);
            else
                c[i]=2,q[++p]=i,q[++p]=0,++r;
        }
	G<<r<<"\n";
	for(--p;p;--p)
        if(q[p])
            G<<q[p]<<" ";
        else
            G<<"\n";
    return 0;
}
