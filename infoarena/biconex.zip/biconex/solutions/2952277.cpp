#include <bits/stdc++.h>
#define N 100007
using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int n,m,ct=1;
vector<int> a[N];
vector<int> disc(N,0), low(N,-1);
int timp;
vector<int> comp[N];
vector<int> instack(N,0);
stack< int > st;

void Citire()
{
    fin >> n >> m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    fin.close();
}

void DFS(int x ,int tata)
{
    low[x]=disc[x]=++timp;
    instack[x]=1;
    st.push( x );

    for( auto y:a[x] )
        if( tata!=y )
        {
            if( instack[y] )
                low[x]= min( disc[y],low[x] );
//            else
//                if( disc[y] )
//                    continue;
            else
            {   /// treeeee
cout << 1 << " ";
                DFS( y,x );
                low[x]= min( low[y],low[x] );
                if( low[y]>=disc[x] )

                {
                    while( st.top()!=x )
                    {
                        comp[ct].push_back( st.top() );
                        st.pop();
                    }
                    comp[ct].push_back( x );
                    ct++;
                }
            }
        }
//    instack[x]=0;
}

void Grupare()
{
    fout << ct-1 ;
    for(int i=1;i<=ct;i++)
    {
        fout <<"\n";
        for( auto x:comp[i] )
            fout << x << " ";
    }
    fout.close();
}

int main()
{
    Citire();
    DFS(1,0);
    Grupare();
return 0;
}
