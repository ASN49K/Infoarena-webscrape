#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

#define pii pair <int, int>
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)x.size()
#define pb push_back
#define fr first
#define sc second
#define vt vector
#define ub upper_bound
#define lb lower_bound

using namespace std;

string filename = "biconex";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

const int NMAX = 1e5;

vt <int> adj[NMAX + 1];

bool viz[NMAX + 1];
int ll[NMAX + 1], lvl[NMAX + 1];

stack <int> S;

int nrComp = 0;
vt <int> comp[NMAX + 1];

void dfs(int node, int parent){
    lvl[node] = ll[node] = lvl[parent] + 1;
    S.push(node);
    viz[node] = 1;

    for(int vec : adj[node]){
        if(vec != parent){
            if(viz[vec]){
                ll[node] = min(ll[node], lvl[vec]);
            }else{
                dfs(vec, node);
                ll[node] = min(ll[node], ll[vec]);

                if(ll[vec] >= lvl[node]){
                    ++nrComp;

                    while(S.top() != vec){
                        comp[nrComp].pb(S.top());
                        S.pop();
                    }
                    comp[nrComp].pb(vec);
                    S.pop();
                    comp[nrComp].pb(node);
                }
            }
        }
    }

}

int main(){

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        adj[a].pb(b);
        adj[b].pb(a);
    }

    dfs(1, 0);

    fout << nrComp << '\n';

    for(int i = 1; i <= nrComp; i++){
        for(int x : comp[i]){
            fout << x << ' ';
        }
        fout << '\n';
    }

    return 0;
}
