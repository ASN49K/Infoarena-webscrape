#include <bits/stdc++.h>
#define oo 0x3f3f3f3f

using namespace std;
ifstream f("biconex.in");
ofstream g("biconex.out");
int n, m, number;
vector<int> graf[100001];
int low[100001], dfn[100001];
vector<int> result[100001];
stack<int> s;

void read()
{
  f>>n>>m;
  int x, y;
  
  for(int i = 1;i <= m;++i)
    f>>x>>y, graf[x].push_back(y), graf[y].push_back(x);
}

void dfs(int node, int level)
{
  low[node] = dfn[node] = level;
  s.push(node);

  for(auto it : graf[node])
    if(dfn[it])
      low[node] = min(low[node], dfn[it]);
    else
    {
      dfs(it, level + 1);
      low[node] = min(low[node], low[it]);

      if(low[it] >= dfn[node])
      {
        ++number;
        result[number].push_back(node);
        int x;
        do{
          x = s.top();
          s.pop();
          result[number].push_back(x);
        }while(x != it);
      }
    }
}

void solve()
{
  dfs(1, 0); 
  g<<number<<'\n';
  for(int i = 1;i <= number;++i, g<<'\n')
    for(auto it : result[i])
      g<<it<<" ";
}

int main()
{
  read();
  solve();
  return 0;
}
