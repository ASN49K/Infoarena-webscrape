#include <fstream>
#include <vector>
#include <stack>

using namespace std;

const int N = 1e5;

struct muchie
{
    int x, y;
};

stack <int> stiva;
vector <int> a[N+1];
vector < vector <int>> comp_bi;
int t_in[N+1], t_minim[N+1], timp;

void constructie_comp(int x, int y, vector <int> &v)
{
    while (!stiva.empty() && stiva.top() != y)
    {
        v.push_back(stiva.top());
        stiva.pop();
    }
    v.push_back(stiva.top());
    stiva.pop();
    v.push_back(x);
}

void dfs(int x, int tata)
{
    t_in[x] = t_minim[x] = ++timp;
    stiva.push(x);
    for (auto y: a[x])
    {
        if (y == tata)
        {
            continue;
        }
        if (t_in[y] == 0)
        {
            dfs(y, x);
            t_minim[x] = min(t_minim[x], t_minim[y]);
            if (t_minim[y] >= t_in[x])
            {
                vector <int> comp;
                constructie_comp(x, y, comp);
                comp_bi.push_back(comp);
            }
        }
        else
        {
            t_minim[x] = min(t_minim[x], t_in[y]);
        }
    }
}

int main()
{
    ifstream in("biconex.in");
    ofstream out("biconex.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    in.close();
    dfs(1, 0);
    out << comp_bi.size() << "\n";

    for (auto c: comp_bi)
    {
        for (auto x: c)
        {
            out << x << " ";
        }
        out << "\n";
    }
    out.close();
    return 0;
}
