#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("biconex.in" , "r" , stdin) , freopen("biconex.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , m;
int h[N] , low[N];
vector < int > G[N] , comp[N];
stack < int > st;

int cnt = 0;

void dfs(int node , int par)
{
    h[node] = h[par] + 1;
    low[node] = h[node];
    st.push(node);

    for(auto to : G[node])
        if(h[to] == 0)
        {
            dfs(to , node);
            low[node] = min(low[node] , low[to]);

            if(low[to] == h[node] || low[to] == h[node] + 1)
            {
                ++cnt;

                while(st.top() != node)
                    comp[cnt].pb(st.top()) , st.pop();

                comp[cnt].pb(node);
            }
        }
        else if(to != par)
            low[node] = min(low[node] , h[to]);

}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n >> m;

    for( ; m ; m--)
    {
        int u , v;
        cin >> u >> v;
        G[u].pb(v);
        G[v].pb(u);
    }


    dfs(1 , 0);

    cout << cnt << '\n';

    for(int i = 1 ; i <= cnt ; i++ , cout << '\n')
        for(auto j : comp[i])
            cout << j << ' ';

    return 0;
}
