#include <bits/stdc++.h>
#include <iostream>
using namespace std;

class Solutuion {
 private:
    size_t N;
    size_t M;
    vector<vector<size_t>> adj;
    vector<size_t> start;
    vector<size_t> parent;
    vector<size_t> low_link;
    vector<set<size_t>> bicon;
    stack<size_t> st;
    size_t time = 0;

    void dfs(size_t node) {
        st.push(node);
        start[node] = ++time;
        low_link[node] = time;

        for (auto neigh : adj[node]) {
            if (neigh == parent[node])
                continue;

            if (start[neigh] == 0) {
                parent[neigh] = node;
                dfs(neigh);
                if (low_link[neigh] >= start[node]) {
                    bicon.push_back(set<size_t>());
                    while (true) {
                        bicon.back().insert(st.top());
                        if (st.top() == node)
                            break;
                        st.pop();
                    }
                }
            }

            low_link[node] = min(low_link[node], low_link[neigh]);
        }
    }

    void dfs_root(size_t root) {
        st.push(root);
        start[root] = ++time;
        low_link[root] = time;
        size_t num_subarbs = 0;

        for (auto neigh : adj[root]) {
            if (start[neigh] == 0) {
                if (++num_subarbs == 2) {
                    bicon.push_back(set<size_t>());
                    while (true) {
                        bicon.back().insert(st.top());
                        if (st.top() == root)
                            break;
                        st.pop();
                    }
                }

                parent[neigh] = root;
                dfs(neigh);

                if (num_subarbs > 1) {
                    bicon.push_back(set<size_t>());
                    while (true) {
                        bicon.back().insert(st.top());
                        if (st.top() == root)
                            break;
                        st.pop();
                    }
                }
            }

            low_link[root] = min(low_link[root], low_link[neigh]);
        }

        if (num_subarbs == 0) {
            bicon.push_back(set<size_t>());
            bicon.back().insert(root);
        }

        st.pop();
    }

 public:
    explicit Solutuion(ifstream &in) {
        in >> N >> M;
        adj.resize(N + 1);
        start.resize(N + 1, 0);
        parent.resize(N + 1, 0);
        low_link.resize(N + 1, 0);

        size_t node1, node2;
        for (size_t i = 1; i <= M; i++) {
            in >> node1 >> node2;

            adj[node1].push_back(node2);
            adj[node2].push_back(node1);
        }
    }

    vector<set<size_t>> solve() {
        for (size_t node = 1; node <= N; node++)
            if (start[node] == 0)
                dfs_root(node);
        
        return bicon;
    }
};

int main() {
    ifstream in("biconex.in");
    ofstream out("biconex.out");
    
    auto solution = Solutuion(in).solve();

    out << solution.size() << endl;
    for (auto sol : solution) {
        copy(sol.begin(), sol.end(), ostream_iterator<size_t>(out, " "));
        out << endl;
    }
    
    in.close();
    out.close();
    return 0;
}
