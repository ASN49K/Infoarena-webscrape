#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#define ll int
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll n,m,timer[100005],low[100005],cnt=0,viz[100005],s[200005],pos=0;
vector<ll>g[100005];
vector<ll>ans[100005];
void dfs(ll node,ll par){
viz[node]=1;
timer[node]=timer[par]+1;
low[node]=timer[node];
s[++pos]=node;
for(auto it : g[node]){
        if(it==par){
            continue;
        }
        if(viz[it]){
            low[node]=min(low[node],timer[it]);
        }else {
        dfs(it,node);
        low[node]=min(low[node],low[it]);
        if(timer[node]<=low[it]){
++cnt;
while(s[pos]!=it){
    ans[cnt].pb(s[pos--]);
}
ans[cnt].pb(it);
pos--;
ans[cnt].pb(node);
        }
        }
}
}
int32_t main(){
CODE_START;
ifstream cin("biconex.in");
ofstream cout("biconex.out");
cin>>n>>m;
for(ll i=1;i<=m;i++)
{
    ll x,y;
    cin>>x>>y;
g[x].pb(y);
g[y].pb(x);
}
dfs(1,0);
cout<<cnt<<endl;
for(ll i=1;i<=cnt;i++)
{
for(auto it : ans[i]){
    cout<<it<<' ';
}
    cout<<endl;
}
}


