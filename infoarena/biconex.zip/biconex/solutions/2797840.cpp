#include <iostream>
#include <bits/stdc++.h>

using namespace std;

struct hash_pair {
    template <class T1, class T2>
    size_t operator()(const pair<T1, T2>& p) const
    {
        auto hash1 = hash<T1>{}(p.first);
        auto hash2 = hash<T2>{}(p.second);
        return hash1 ^ hash2;
    }
};

class graph
{
    struct muchie
    {
        int from, to, cost;
        muchie(int _from, int _to, int _cost):
            from(_from), to(_to), cost(_cost)
            {

            }
    };
public:
    void bfs();
    ///////////////////////////////////////////////////////////
    void dfs();
    void _dfs_rec(int s, int viz[], vector<int> la[]);
    ///////////////////////////////////////////////////////////
    void ctc();
    void topo_dfs(int s, vector<int>& topo, int viz[], vector<int> la[]);
    void dfs_lat(int el, int viz[], vector<int> lat[], vector<vector<int>>& cc);
    ///////////////////////////////////////////////////////////
    void sortaret();
    ///////////////////////////////////////////////////////////
    void mcritice();
    void dfs_critice(int s, int p, int viz[], vector<int> la[], int lowLink[], int ids[], int& id, vector<pair<int,int>>& critice);
    ///////////////////////////////////////////////////////////
    void biconex();
    void dfs_biconexe(int s, int viz[], vector<int> la[], unordered_map<pair<int,int>, int, hash_pair>& map_critice, vector<vector<int>>& biconexe);
    ///////////////////////////////////////////////////////////
    void havel();
    ///////////////////////////////////////////////////////////
    void apm();
    pair<int,int> get_parent_and_depth(int x, int parent[]);
    ///////////////////////////////////////////////////////////
    void disjoint();
    ///////////////////////////////////////////////////////////
    void dijkstra();
    ///////////////////////////////////////////////////////////
    void bellmanford();
};

void graph::bfs()
{
    ifstream f("bfs.in");
    ofstream g("bfs.out");
    int n,m,s;
    vector<int>* la = new vector<int>[100005];
    int* dist = new int[100005];

    f >> n >> m >> s;
    memset(dist, -1, sizeof(int) * (n+1));
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
    }

    int curr_dist = 1;
    queue<int> q;
    q.push(s);
    dist[s] = 0;

    while (q.size())
    {
        for (auto& v: la[q.front()])
        {
            if (dist[v] == -1)
            {
                dist[v] = dist[q.front()] + 1;
                q.push(v);
            }
        }
        q.pop();
    }

    for (int i = 1; i <= n; i++)
        g << dist[i] << ' ';

    delete[] dist;
    delete[] la;
}

void graph::_dfs_rec(int s, int viz[], vector<int> la[])
{
    viz[s] = 1;
    for (auto& el: la[s])
    {
        if (viz[el] == 0)
            _dfs_rec(el, viz, la);
    }
}

void graph::dfs()
{
    ifstream f("dfs.in");
    ofstream g("dfs.out");
    int n,m;
    vector<int>* la = new vector<int>[100005];
    int* viz = new int[100005];

    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }

    int cc = 0;
    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
        {
            _dfs_rec(i, viz, la);
            cc++;
        }
    }

    g << cc;

    delete[] viz;
    delete[] la;
}

void graph::topo_dfs(int s, vector<int>& topo, int viz[], vector<int> la[])
{
    viz[s] = 1;
    for (auto& el: la[s])
    {
        if (viz[el] == 0)
            topo_dfs(el, topo, viz, la);
    }
    topo.push_back(s);
}

void graph::dfs_lat(int s, int viz[], vector<int> lat[], vector<vector<int>>& cc)
{
    viz[s] = 1;
    cc[cc.size() - 1].push_back(s);

    for (auto& el: lat[s])
    {
        if (viz[el] == 0)
            dfs_lat(el, viz, lat, cc);
    }
}

void graph::ctc()
{
    ifstream f("ctc.in");
    ofstream g("ctc.out");
    int n,m;
    vector<int>* la = new vector<int>[100005];
    vector<int>* lat = new vector<int>[100005];
    int* viz = new int[100005];

    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
        lat[y].push_back(x);
    }

    vector<int> topo;
    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
        {
            topo_dfs(i, topo, viz, la);
        }
    }
    // reverse topo
    reverse(topo.begin(), topo.end());
    // reset viz
    memset(viz, 0, sizeof(int) * (n+1));

    vector<vector<int>> cc;

    for (auto el: topo)
    {
        if (!viz[el])
        {
            cc.push_back(vector<int>());
            dfs_lat(el, viz, lat, cc);
        }
    }

    g << cc.size() << '\n';
    for (auto& row: cc)
    {
        for (auto& el: row)
            g << el << ' ';
        g << '\n';
    }

    delete[] la;
    delete[] lat;
    delete[] viz;
}

void graph::sortaret()
{
    ifstream f("sortaret.in");
    ofstream g("sortaret.out");
    int n,m;
    vector<int>* la = new vector<int>[100005];
    int* viz = new int[100005];

    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
    }

    vector<int> topo;
    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
        {
            topo_dfs(i, topo, viz, la);
        }
    }
    // reverse topo
    reverse(topo.begin(), topo.end());

    for (auto& el: topo)
        g << el << ' ';

    delete[] la;
    delete[] viz;
}

void graph::dfs_critice(int s, int p, int viz[],vector<int> la[], int lowLink[], int ids[], int& id, vector<pair<int,int>>& critice)
{
    lowLink[s] = id;
    ids[s] = id;
    id ++;
    viz[s] = 1;

    for (auto& el: la[s])
    {
        if (!viz[el])
            dfs_critice(el, s, viz, la, lowLink, ids, id, critice);
        if (el != p)
            lowLink[s] = min(lowLink[s], lowLink[el]);
    }

    if (lowLink[s] == ids[s] && p != -1)
    {
        critice.push_back({s, p});
    }
}

void graph::mcritice()
{
    ifstream f("mcritice.in");
    ofstream g("mcritice.out");
    int n,m;
    vector<int>* la = new vector<int>[100005];
    int* viz = new int[100005];
    int* lowLink = new int[100005];
    int* ids = new int[100005];
    int id = 0;

    f >> n >> m;
    memset(lowLink, -1, sizeof(int) *(n+1));
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }

    vector<pair<int,int>> critice;
    // in problema e graf conex, but anyway
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
            dfs_critice(i, -1, viz, la, lowLink, ids, id, critice);
    }

    for (auto& per: critice)
        g << per.first << ' ' << per.second << '\n';

    delete[] viz;
    delete[] la;
    delete[] lowLink;
    delete[] ids;
}

void graph::dfs_biconexe(int s, int viz[], vector<int> la[], unordered_map<pair<int,int>, int, hash_pair>& map_critice, vector<vector<int>>& biconexe)
{
    viz[s] = 1;
    biconexe[biconexe.size() - 1].push_back(s);
    for (auto& el: la[s])
    {
        // daca e in map_critice nu e bn
        if (map_critice.find({s, el}) != map_critice.end() || map_critice.find({el ,s}) != map_critice.end())
            continue;
        if (!viz[el])
            dfs_biconexe(el, viz, la, map_critice, biconexe);
    }
}

void graph::biconex()
{
    // mai intai caut muchile critice
    // fiecare muchie critica va fi o componente biconexa
    // elimin muhcile din lista de adiacenta si fac restul de componente conexe, care vor fi si ele biconexe (in afara de cele cu un singur nod)
    ifstream f("biconex.in");
    ofstream g("biconex.out");
    int n,m;
    vector<int>* la = new vector<int>[100005];
    int* viz = new int[100005];
    int* lowLink = new int[100005];
    int* ids = new int[100005];
    int id = 0;

    f >> n >> m;
    memset(lowLink, -1, sizeof(int) *(n+1));
    for (int i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }

    vector<pair<int,int>> critice;
    // in problema e graf conex, but anyway
    dfs_critice(1, -1, viz, la, lowLink, ids, id, critice);

    // inserez in biconexe toate muchile critice
    vector<vector<int>> biconexe;
    for (auto& per: critice)
    {
        biconexe.push_back(vector<int>());
        biconexe[biconexe.size()-1].push_back(per.first);
        biconexe[biconexe.size()-1].push_back(per.second);
    }

    // pastrez aici muchile care sunt critice pt a nu le folosi in dfs final
    unordered_map<pair<int,int>, int, hash_pair> map_critice;
    for (auto& per: critice)
    {
        map_critice[{per.first, per.second}] = 1;
        map_critice[{per.second, per.first}] = 1;
    }

    int nrBic = critice.size();
    memset(viz, 0, sizeof(int) * (n+1));
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            biconexe.push_back(vector<int>());
            dfs_biconexe(i, viz, la, map_critice, biconexe);
            if (biconexe[biconexe.size()-1].size() >= 2)
                nrBic ++;
        }
    }

    g << nrBic << '\n';
    for (auto& row: biconexe)
    {
        if (row.size() < 2)
            continue;
        for (auto& el: row)
            g << el << ' ';
        g << '\n';
    }

    delete[] viz;
    delete[] la;
    delete[] lowLink;
    delete[] ids;
}

void graph::havel()
{
    ifstream f("havel.in");
    ofstream g("havel.out");
    int n;
    f >> n;
    vector<int> v;
    for (int i = 0; i < n; i++)
    {
        int x;
        f >> x;
        v.push_back(x);
    }

    sort(v.begin(), v.end(), [](int x, int y){return x > y;});

    for (int i = 0; i < n; i++)
    {
        sort(v.begin()+i+1, v.end(), [](int x, int y){return x > y;});
        for (int j = i+1; j < n; j++)
        {
            if (v[i] == 0)
                break;
            if (v[j])
            {
                v[j] --;
                v[i] --;
            }
        }
        if (v[i] > 0)
        {
            cout << "NU";
            return;
        }
    }
    cout << "DA";
}

pair<int,int> graph::get_parent_and_depth(int x, int parent[])
{
    vector<int> met_on_the_way;
    int h = 0;
    while (parent[x] != 0 && parent[x] != -1)
    {
        met_on_the_way.push_back(x);
        h ++;
        x = parent[x];
    }
    for (auto el: met_on_the_way)
        parent[el] = x;
    return {x, h};
}

void graph::apm()
{
    ifstream f("apm.in");
    ofstream g("apm.out");
    int n,m;
    vector<muchie> edges;
    int* parent = new int[100005];
    int id = 0;

    f >> n >> m;
    memset(parent, -1, sizeof(int) *(n+1));
    for (int i = 1; i <= m; i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        edges.push_back({x,y,c});
    }

    sort(edges.begin(), edges.end(), [](muchie& m1, muchie& m2) {return (m1.cost < m2.cost);});
    vector<pair<int,int>> sol;
    int s = 0;
    for (auto& m: edges)
    {
        // first va contine parintele iar second va contine inaltimea
        pair<int,int> info_from = get_parent_and_depth(m.from, parent);
        pair<int,int> info_to = get_parent_and_depth(m.to, parent);
        // daca au parinte diferit, le unim si adaugam la solutie
        if (info_from.first != info_to.first)
        {
            s += m.cost;
            sol.push_back({m.from, m.to});
            // from e mai inalt il facem pe second copil
            if (info_from.second > info_to.second)
                parent[info_to.first] = info_from.first;
            else
                parent[info_from.first] = info_to.first;
        }
    }

    g << s << '\n';
    g << sol.size() << '\n';
    for (auto& per: sol)
        g << per.first << ' ' << per.second << '\n';

    delete[] parent;
}

void graph::disjoint()
{
    ifstream f("disjoint.in");
    ofstream g("disjoint.out");
    int n, nrop;
    int* parent = new int[100005];
    int id = 0;

    f >> n >> nrop;
    memset(parent, -1, sizeof(int) *(n+1));

    for (int i = 1; i <= nrop; i++)
    {
        int tip, from, to;
        f >> tip >> from >> to;

        pair<int,int> info_from = get_parent_and_depth(from, parent);
        pair<int,int> info_to = get_parent_and_depth(to, parent);
        if (tip == 1)
        {
            if (info_from.second > info_to.second)
            {
                parent[info_to.first] = info_from.first;
            }
            else
            {
                parent[info_from.first] = info_to.first;
            }
        }
        else
        {
            if (info_from.first == info_to.first)
                g << "DA\n";
            else
                g << "NU\n";
        }
    }

    delete[] parent;
}

void graph::dijkstra()
{
    ifstream f("dijkstra.in");
    ofstream g("dijkstra.out");
    int n,m;

    f >> n >> m;
    vector<pair<int,int>>* la = new vector<pair<int,int>>[n+1];
    int* dist = new int[n+1];
    for (int i = 1; i <= n; i++)
        dist[i] = 999999999;

    for (int i = 1; i <= m; i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        la[x].push_back({y,c});
    }

    dist[1] = 0;
    priority_queue<pair<int,int>> pq;
    pq.push({0, 1});

    while (pq.size())
    {
        pair<int,int> top = pq.top(); // top second este nodul ale carui muchii le vom parcurge acum, top first este costul de a ajunge la el
        pq.pop();

        for (auto el: la[top.second])
        {
            if (dist[el.first] > dist[top.second] + el.second)
            {
                dist[el.first] = dist[top.second] + el.second;
                pq.push({-el.second, el.first});
            }
        }
    }

    for (int i = 2; i <= n; i++)
    {
        if (999999999 == dist[i])
            dist[i] = 0;
        g << dist[i] << ' ';
    }

    delete[] la;
    delete[] dist;
}

void graph::bellmanford()
{
    ifstream f("bellmanford.in");
    ofstream g("bellmanford.out");
    int n,m;

    f >> n >> m;
    int* dist = new int[n+1];
    int* used = new int[n+1];
    vector<pair<int,int>>* la = new vector<pair<int,int>>[n+1];

    for (int i = 1; i <= n; i++)
        dist[i] = 999999999;

    for (int i = 1; i <= m; i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        la[x].push_back({y,c});
    }

    vector<int> to_check_now;
    to_check_now.push_back(1);
    dist[1] = 0;
    for (int k = 1; k <= n && to_check_now.size(); k++)
    {
        vector<int> to_check_next;
        for (int i = 1; i <= n; i++)
            used[i] = 0;

        for (auto el: to_check_now)
        {
            for (auto& m: la[el])
            {
                if (dist[m.first] > dist[el] + m.second)
                {
                    dist[m.first] = dist[el] + m.second;
                    if (!used[m.first])
                    {
                        used[m.first] = 1;
                        to_check_next.push_back(m.first);
                    }
                }
            }
        }
        to_check_next.swap(to_check_now);
    }

    for (auto el: to_check_now)
            for (auto& m: la[el])
                if (dist[m.first] > dist[el] + m.second)
                {
                    g << "Ciclu negativ!";
                    return;
                }

    for (int i = 2; i <= n; i++)
    {
        if (999999999 == dist[i])
            dist[i] = 0;
        g << dist[i] << ' ';
    }

    delete[] dist;
    delete[] la;
    delete[] used;
}

int main()
{
    graph g;
    g.havel();

    return 0;
}
