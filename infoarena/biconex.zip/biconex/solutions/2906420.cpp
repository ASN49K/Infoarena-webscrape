#include <bits/stdc++.h>

using namespace std;
using ll = long long;
#ifndef INFOARENA
ifstream fin("ciorna.in");
ofstream fout("ciorna.out");
#else
ifstream fin("biconex.in");
ofstream fout("biconex.out");
#endif // HOME
const int N = 2e5 + 5;
vector <int> g[N];
int id[N], low[N];
vector <vector <int>> bc;
stack <int> st;
void dfs(int u, int p) {
    low[u] = id[u] = id[p] + 1;
    st.push(u);
    for(int v : g[u]) {
        if(id[v]) low[u] = min(low[u], id[v]);
        else {
            dfs(v, u);
            low[u] = min(low[u], low[v]);
            if(low[v] == id[u]) {
                bc.push_back({u, v});
                while(st.top() != v) {
                    bc.back().push_back(st.top());
                    st.pop();
                }
                st.pop();
            }
        }
    }
}

int main() {
    int n, m;
    fin >> n >> m;
    for(int i = 1, u, v; i <= m; i++)
        fin >> u >> v,
        g[u].push_back(v),
        g[v].push_back(u);
    for(int i = 1; i <= n; i++) if(!id[i])
        dfs(i, 0);
    fout << bc.size() << "\n";
    for(auto& v : bc) {
        for(int x : v) fout << x << " ";
        fout << "\n";
    }
}
