#include <bits/stdc++.h>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int n,m,x,y,cnt;
int viz[100005],d[100005],low[100005];
vector <int> g[100005];
vector <vector <int>> sol;
stack <pair <int,int>> stk;

void newBicon(int x,int y)
{
    cnt++;
    vector <int> b;
    int tx,ty;
    do
    {
        tx=stk.top().first,ty=stk.top().second;
        stk.pop();
        b.push_back(tx);
        b.push_back(ty);
    }
    while(tx!=x || ty!=y);
    sol.push_back(b);
}

void dfs(int u,int p,int h)
{
    viz[u]=1;
    d[u]=low[u]=h;
    for(int v:g[u])
    {
        if(v==p)
            continue;
        if(viz[v]==0)
        {
            stk.push(make_pair(u,v));
            dfs(v,u,h+1);
            low[u]=min(low[u],low[v]);
            if(low[v]>=d[u])
                newBicon(u,v);
        }
        else
            low[u]=min(low[u],d[v]);
    }
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1,0,0);
    fout<<cnt<<"\n";
    for(int i=0; i<cnt; i++)
    {
        sort(sol[i].begin(),sol[i].end());
        fout<<sol[i][0]<<" ";
        for(int j=1; j<(int)sol[i].size(); j++)
            if(sol[i][j]!=sol[i][j-1])
                fout<<sol[i][j]<<" ";
        fout<<"\n";
    }
    return 0;
}
