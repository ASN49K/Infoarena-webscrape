#include<bits/stdc++.h>
using namespace std;
ifstream F("1.in");
ofstream G("1.out");
#define N 100001
vector<int> g[N],q;
char c[N];
int p,j,n,m,i,r,u,d[N],f[N];
void P(int i)
{
	c[i]=2,q.push_back(i);
	for(auto j:g[i])
        if(c[j]==1)
            P(j);
}
void E(int i)
{
	d[i]=f[i]=++u,c[i]=1;
	for(auto j:g[i])
        if(!c[j]) {
            if(E(j),f[i]>f[j])
                f[i]=f[j];
            if(d[i]<=f[j])
                c[i]=2,q.push_back(i),P(j),c[i]=1,q.push_back(0),++r;
        } else if(f[i]>d[j])
            f[i]=d[j];
}
int main()
{
	for(F>>n>>m;m--;F>>i>>j,g[i].push_back(j),g[j].push_back(i));
	for(E(1),G<<r<<'\n',p=q.size()-1;p;--p,q[p]?G<<q[p]<<' ':G<<'\n');
    return 0;
}
