#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
vector <int> g[100005], comp[100005];
int niv[100005], nivmin[100005], nr;
deque <int> q;
void dfs(int nod, int dad)
{
    q.push_back(nod);
    niv[nod]=niv[dad]+1;
    nivmin[nod]=niv[nod];
    for(int i=0; i<g[nod].size(); i++)
        if(g[nod][i]!=dad)
    {
        if(niv[g[nod][i]]==0)
        {
            dfs(g[nod][i], nod);
            if(nivmin[g[nod][i]]<nivmin[nod])
                nivmin[nod]=nivmin[g[nod][i]];
            if(nivmin[g[nod][i]]>=niv[nod])
            {
                nr++;
                while(q.back()!=g[nod][i])
                {
                    comp[nr].push_back(q.back());
                    q.pop_back();
                }
                q.pop_back();
                comp[nr].push_back(g[nod][i]);
                comp[nr].push_back(nod);

            }

        }
        else
            if(niv[g[nod][i]]<nivmin[nod])
                nivmin[nod]=niv[g[nod][i]];

    }
}
int main()
{
    int n, m;  fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        int a, b; fin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    niv[1]=1; nivmin[1]=1;
    dfs(1, 0);
    fout << nr << "\n";
    for(int i=1; i<=nr; i++)
    {
        for(int j=0; j<comp[i].size(); j++)  fout << comp[i][j] << " ";
        fout << "\n";
    }
    return 0;
}
