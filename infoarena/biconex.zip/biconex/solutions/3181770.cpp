#include <fstream>
#include <stack>
#include <vector>

#define NMAX 100005

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int n, m;
int x, y;
vector<int> l[NMAX];
int in[NMAX], low[NMAX];
vector<int> c[NMAX]; int nrcb;
int counter;
int i, j;

stack<int> s;

void dfs(int, int);

int main()
{
    fin >>n>>m;
    for (i = 1; i <= m; ++i)
    {
        fin >>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }

    dfs(1, -1);

    fout <<nrcb<<'\n';
    for (i = 1; i <= nrcb; ++i)
    {
        for (auto vf: c[i])
            fout <<vf<<' ';
        fout <<'\n';
    }
    fout.close();
    return 0;
}

void dfs(int vf, int tata)
{
    in[vf] = low[vf] = ++counter;
    s.push(vf);
    for (auto vfnou: l[vf])
    {
        if (vfnou == tata) continue;
        if (!in[vfnou])
        {
            dfs(vfnou, vf);
            low[vf] = min(low[vf], low[vfnou]);
            if (low[vfnou] >= in[vf])
            {
                //[vfnou, vf], muchie critica
                ++nrcb;
                int fiu;
                do
                {
                    fiu = s.top();
                    c[nrcb].push_back(fiu);
                    s.pop();
                }
                while (fiu != vfnou);
                c[nrcb].push_back(vf);
            }
        }
        else
            low[vf] = min(low[vf], in[vfnou]);
    }
}
