#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
#define nmax 100005
stack<pair<int,int> > st;
vector<vector<int> > sol;
vector<int> g[nmax];
int n,m;
int viz[nmax];
int h[nmax];
int nma[nmax];
vector<int>bx;
int tx=0,ty=0;

void rez(int x, int y)
{
    if(!bx.empty())bx.clear();
    tx=st.top().first;
    ty=st.top().second;
    st.pop();
    bx.push_back(tx);
    bx.push_back(ty);
    while(tx!=x||ty!=y)
    {
        tx=st.top().first;
        ty=st.top().second;
        st.pop();
        //    bx.push_back(tx);
        bx.push_back(ty);

    }

    sol.push_back(bx);
}
void dfs(int nod,int tata, int nivel)
{
    viz[nod]=1;
    h[nod]=nivel;
    nma[nod]=nivel;
    for(int i=0; i<g[nod].size(); i++)
    {
        int x=g[nod][i];
        if(!viz[x])
        {
            st.push({x,nod});
            dfs(x,nod,nivel+1);
            nma[nod]=min(nma[nod],nma[x]);
            if(nma[x]>=h[nod])
            {
                rez(x,nod);
            }
        }
        else if(x!=tata)
        {
            nma[nod]=min(nma[nod],h[x]);
        }
    }
}
int main()
{
    fin>>n>>m;
    int i,j,x,y;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1,0,1);
    fout<<sol.size();
    fout<<'\n';

    for(i=0; i<sol.size(); i++)
    {
        sort(sol[i].begin(), sol[i].end());
        for(j=0; j<sol[i].size(); j++)fout<<sol[i][j]<<" ";
        fout<<'\n';
    }
    return 0;
}
