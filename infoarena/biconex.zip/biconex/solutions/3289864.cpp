#include <bits/stdc++.h>

#define ll long long

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

const int LMAX = 100005;
const int INF = 0x3f3f3f3f;
const ll MOD = 1000000007;

vector<pair<int, int>> L[LMAX];
bool viz[LMAX], viz2[LMAX*2];
vector<pair<int, int>> edges;
vector<int> st, ans[LMAX];
int dp[LMAX], up[LMAX], down[LMAX], idx;
//dp[i] --> number of back-edges that go over the node i

void dfs(int node) {
  viz[node] = 1;
  for (auto vec : L[node]) {
      if (!viz[vec.first]) {
        viz2[vec.second] = 1;
        dfs(vec.first);
//        fout<<"node --> "<<node<<"  up --> "<<up[vec.first]<<" down --> "<<down[vec.first]<<" "<<vec.first<<endl;
        dp[node] += up[vec.first];
        dp[node] += dp[vec.first];
      }
      //back - edge
      else if (!viz2[vec.second]) {
        viz2[vec.second] = 1;
//        fout<<node<<" "<<vec.first<<endl;
        up[node]++;
        down[vec.first]++;
      }
  }
//  fout<<node<<" "<<down[node]<<endl;
  dp[node] = dp[node] - down[node];
}

void init(int n, int m) {
  for (int i = 1; i <= n; i++) viz[i] = 0;
}

void dfs2(int node) {
  viz[node] = 1;
  st.push_back(node);
  for (auto vec : L[node]) {
    if (!viz[vec.first]) {
      dfs2(vec.first);
//      st.push_back(node);
      if (dp[vec.first] + up[vec.first] - down[node] == 0) {
        while (!st.empty() && st.back() != vec.first) {
            ans[idx].push_back(st.back());
            st.pop_back();
        }
        st.pop_back();
        ans[idx].push_back(vec.first);
        ans[idx].push_back(node);
        idx++;
      }
    }
  }
}

int main() {
    int n, m, i;
    fin>>n>>m;
    for (i = 0; i < m; i++) {
      int x, y;
      fin>>x>>y;
      edges.push_back({x, y});
      L[x].push_back({y, i});
      L[y].push_back({x, i});
    }

    for (i = 1; i <= n; i++) {
      //finding articulation points
      if (!viz[i]) {
        dfs(i);
      }
//      fout<<dp[i]<<" ";
    }

    init(n, m);

    for (i = 1; i <= n; i++) {
      if (!viz[i]) {
        dfs2(i);
      }
    }
    fout<<idx<<"\n";
    for (i = 0; i < idx; i++) {
        for (int vec : ans[i]) {
            fout<<vec<<" ";
        }
        fout<<"\n";
    }



    fin.close();
    fout.close();
    return 0;
}
