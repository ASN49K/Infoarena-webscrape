#include <bits/stdc++.h>
using ll=long long;
#define S second
#define F first
#define endl '\n'
#define spid ios_base::sync_with_stdio(false);cin.tie(NULL);
const int mod=1e9+7;
const double pi=3.14159265359;
const int maxn=200001;
using namespace std;

int n,m,t=0,curr=0;
int parent[maxn],disc[maxn],low[maxn],chk[maxn];
vector<int> A[maxn];
vector<vector<int>> C(0,vector<int>());
stack<pair<int,int>> B;

void dfs(int i){
	disc[i]=t;
	low[i]=t;
	int childs=0;
	t++;
	chk[i]=1;
	for(int j=0;j<A[i].size();j++){
		if(!chk[A[i][j]]){
			childs++;
			B.push({i,A[i][j]});
			parent[A[i][j]]=i;
			dfs(A[i][j]);
			low[i]=min(low[i],low[A[i][j]]);
			if(parent[i]==-1&&A[i].size()>1){
				int sw=1;
				C.push_back(vector<int>());
				while(!(B.top().F==i&&B.top().S==A[i][j])){
					C[curr].push_back(B.top().S+1);
					B.pop();
					sw=0;
				}
				if(sw){
					C[curr].push_back(B.top().S+1);
					C[curr].push_back(B.top().F+1);
				}
				else C[curr].push_back(B.top().S+1);
				B.pop();
				curr++;
			}
			else if(parent[i]!=-1&&low[A[i][j]]>=disc[i]){
				int sw=1;
				C.push_back(vector<int>());
				while(!(B.top().F==i&&B.top().S==A[i][j])){
					C[curr].push_back(B.top().S+1);
					B.pop();
					sw=0;
				}
				if(sw){
					C[curr].push_back(B.top().S+1);
					C[curr].push_back(B.top().F+1);
				}
				else C[curr].push_back(B.top().S+1);
				B.pop();
				curr++;
			}
		}
		else if(parent[i]!=A[i][j]&&disc[A[i][j]]<low[i]){
			low[i]=disc[A[i][j]];
			B.push({i,A[i][j]});
		}
	}
}


/*void dfs2(int i){
	chk[i]=1;
	for(int j=0;j<A[i].size();j++){
		B.push_back({i,A[i][j]});
		if(!chk[A[i][j]]){
			dfs(A[i][j]);
			if(artic[i]){
				while(B.top()!={i,A[i][j]}){
					cout<<B.top().
				}
			}
		}
	}
}*/

int main(){
	ifstream cin("biconex.in");
	ofstream cout("biconex.out");
	cin>>n>>m;
	for(int i=0;i<m;i++){
		int a,b;
		cin>>a>>b;
		a--;b--;
		A[a].push_back(b);
		A[b].push_back(a);
	}
	parent[0]=-1;
	dfs(0);
	while(B.size()){
		C.push_back(vector<int>());
		C[curr].push_back(B.top().S+1);
		C[curr].push_back(B.top().F+1);
		B.pop();
		curr++;
	}
	cout<<curr<<endl;
	for(int i=0;i<curr;i++){
		for(int j=0;j<C[i].size();j++){
			cout<<C[i][j]<<" ";
		}
		cout<<endl;
	}
}

