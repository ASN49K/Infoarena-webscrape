#include <iostream>
#include <vector>
#include <fstream>
#include <set>
#include <stack>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

const int NMAX = 100000;

bool viz[NMAX + 1];
int nivel[NMAX + 1], nma[NMAX + 1];

int cer, N, M;

vector<int> G[NMAX];

set<int> PunctArt;
set<pair<int, int> > Muchie;
stack<int> S;
vector<int>CompBiConex[NMAX + 1];

void citire()
{
    f >> N >> M;
    for(int i = 1; i <= M; ++i)
    {
        int x, y;
        f >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}
int Q = 0;
void DFS(int k, int tata)
{
    viz[k] = 1;
    S.push(k);
    nivel[k] = nivel[tata] + 1;
    nma[k] = nivel[k];
    for(auto x : G[k])
        if(x != tata)
        {
            if(viz[x])
            {
                if(nma[k] > nivel[x])
                    nma[k] = nivel[x];
            }
            else
            {
                DFS(x, k);
                if(nma[k] > nma[x])
                    nma[k] = nma[x];

                ///

                if(nivel[k] <= nma[x])
                {
                    ++Q;
                    while(S.top() != x)
                    {
                        CompBiConex[Q].push_back(S.top());
                        S.pop();
                    }
                    CompBiConex[Q].push_back(x);
                    S.pop();
                    CompBiConex[Q].push_back(k);
                }
            }
        }
}

int main()
{
    citire();
    DFS(1, 0);
    g << Q << '\n';
    for(int i = 1; i <= Q; ++i)
    {
        for(auto x : CompBiConex[i])
            g << x << ' ';
        g << '\n';
    }

    return 0;
}
