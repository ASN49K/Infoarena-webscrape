#include <bits/stdc++.h>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

const int NMAX = 1e5;

vector <int> g[NMAX + 2];
int vizTime[NMAX + 2];
int highestNode[NMAX + 2];

int stackNode[NMAX + 2];

int stackIndex;
int nrComp;
int currTime;

void resetValues(int n) {
  for (int i = 1; i <= n; ++i)
    highestNode[i] = vizTime[i] = 0;
  currTime = 0;
  stackIndex = 0;
}



void dfs(int node, int parent, int print) {
  highestNode[node] = parent;
  vizTime[node] = ++currTime;
  stackNode[++stackIndex] = node;

  for (int newNode : g[node]) {
    if (!vizTime[newNode]) {
      dfs(newNode, node, print);

      if (vizTime[highestNode[newNode]] < vizTime[highestNode[node]])
        highestNode[node] = highestNode[newNode];

      if (highestNode[newNode] == node) {
        ++nrComp;

        if (print > 0) {
          while (stackIndex > 0 && stackNode[stackIndex] != node) {
            fout << stackNode[stackIndex] << " ";
            --stackIndex;
          }
          fout << node;
          fout << "\n";
        }
      }
    }
    else {
      if (vizTime[newNode] < vizTime[highestNode[node]])
        highestNode[node] = newNode;
    }
  }
}

int main() {
  int n, m;

  fin >> n >> m;

  for (int i = 1; i <= m; ++i) {
    int x, y;
    fin >> x >> y;
    g[x].push_back(y);
    g[y].push_back(x);
  }
  dfs(1, 0, 0);
  fout << nrComp << "\n";

  resetValues(n);
  dfs(1, 0, 1);
  return 0;
}
