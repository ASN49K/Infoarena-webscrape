#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define forr(X) for(int i = 0; i<X; i++)
#pragma GCC optimize("Ofast")

int n, m;
vector <int> a[100005];
int vis[100005], l[100005], de[100005],  last = 1, d=1, cnt =0;
vector <int> point;
vector <int>ans[100005];
int situation1 = 0; //va fi egal cu nr de copii in dfs tree a primului nod.

int dfs(int x, int previ){
	if(!vis[x]){ 
		//cout<<"un: "<<x<<endl;
		if(previ == 1 && x!=1)situation1++;
		vis[x] = 1;
		de[x] = d;
		l[x] = d;
		point.push_back(x);
		for(auto it: a[x]){
			if(it != previ){
				//previ = x;
				d++;
				dfs(it, x);
			}
			
		}
	}
	else{
		if(de[x]<de[previ]){
			d--;
			//cout<<"vis: "<<x<<endl;

			for(auto it : point){
				l[it] = de[x];
			}
			last = previ+1;
			point.clear();
		}
		
	}

}

int dfs2(int x, int previ){
	if(x ==1 && situation1 == 1){
		vis[1] = 1;
		ans[cnt].push_back(1);
		dfs2(a[1][0], 1);
		//cout<<a[1][0]<<endl;
	}
	else if(!vis[x]){
		vis[x] =1;
		ans[cnt].push_back(x);
		if(l[x]>=de[previ] && previ!=1){
			//cout<<" x= "<<x<<endl;
			cnt++;
			//cout<<previ<<endl;
		}
		for(auto it: a[x]){
			if(it != previ){
				//previ = x;
				d++;
				dfs2(it, x);
			}
			
		}
		
	}
}

int main(){
	freopen("biconex.in", "r", stdin);
	freopen("biconex.out", "w", stdout);

	cin>>n>>m;
	int x, y;
	for(int i = 1; i <= m; i++){
		cin>>x>>y;
		a[x].push_back(y);
		a[y].push_back(x);
	}
	dfs(1, 1);
	//cout<<"sit1 = "<<situation1<<endl;
	//forr(n+1)cout<<l[i]<<" ";
	//cout<<endl;
	//forr(n+1)cout<<de[i]<<" ";
	
	memset(vis, 0, sizeof(int) * 100005);
	point.clear();
	
	
	dfs2(1, 1);
	
	cout<<cnt+1<<endl;
	for(int i =0; i<=cnt; i++){
		for(auto it : ans[i]){
			//cout<<it<<" ";
		}
		//cout<<endl;
	}

}



