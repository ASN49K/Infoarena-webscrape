#include <fstream>
#include <vector>

using namespace std;

ifstream cin("biconex.in");
ofstream cout("biconex.out");

int n,m;
bool used[100005];
int ord[100005], up[100005];
vector <int> curr_comp, G[100005], stiva;
vector <vector <int>> allcomps;
int cnt=0, comp=0;

void dfs(int nod, int tata)
{
    used[nod]=1;
    ord[nod]=ord[tata]+1;
    up[nod]=ord[nod];
    stiva.push_back(nod);
    for(int fiu: G[nod])
    {
        if(fiu==tata)
            continue;
        if(used[fiu])
            up[nod]=min(up[nod],ord[fiu]);
        else
        {
            dfs(fiu, nod);
            up[nod]=min(up[nod], up[fiu]);
            if(ord[nod]<=up[fiu])
            {
                comp++;
                while(stiva.back()!=fiu)
                {
                    curr_comp.push_back(stiva.back());
                    stiva.pop_back();
                }
                stiva.pop_back();
                curr_comp.push_back(fiu);
                curr_comp.push_back(nod);
                allcomps.push_back(curr_comp);
                curr_comp.clear();
            }
        }
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        cin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!used[i])
            dfs(i,0);
    cout<<comp<<'\n';
    for(auto c : allcomps)
    {
        for(int x : c)
            cout << x << ' ';
        cout << '\n';
    }
    return 0;
}
