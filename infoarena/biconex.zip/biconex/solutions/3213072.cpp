#include <bits/stdc++.h>

using namespace std;

//#define ctc biconex

ifstream fin("biconex.in");ofstream fout("biconex.out");

const int N=100001;
int n,m;
vector<int>g[N];
int disc[N],llink[N],t;
bool deschis[N];
stack<int> st_noduri;
vector<int>comp[N];
int ncomp;

void Citire()
{
    fin >> n >> m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
}

void DFS(int x,int tata)
{
    disc[x]=llink[x]=++t;
//    deschis[x]=1;
    st_noduri.push(x);

    for(auto y:g[x])
        if( y!=tata )
        {

            if( !disc[y] )
            {
                DFS(y,x);
                if( disc[x]<=llink[y] )
                {
                    ++ncomp;
//                    cout << x << " " << y << "\n";
                    while( st_noduri.top()!=y )
                    {
                        comp[ncomp].push_back( st_noduri.top() );
    //                    deschis[ st_noduri.top() ]=0;
                        st_noduri.pop();  ///
                    }
                    comp[ncomp].push_back( st_noduri.top() );
                    st_noduri.pop();
                    comp[ncomp].push_back(x);
    //                deschis[ st_noduri.top() ]=0;
                }
            }
            llink[x]=min(llink[x],llink[y]);
        }
}

void Afisare()
{
    fout << ncomp ;
    for(int i=1;i<=ncomp;i++)
    {
        fout << "\n";
        sort(comp[i].begin(),comp[i].end());
        for(auto x:comp[i])
            fout << x << " ";
    }
}

int main()
{
    Citire();
    for(int i=1;i<=n;i++)
        if( !disc[i] )
            DFS(i,0); /// caz nod izolat?
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///
    ///   ///   ///   ///   ///   ///   ///   ///
///   ///   ///   ///   ///   ///   ///   ///

    Afisare();
    return 0;
}
