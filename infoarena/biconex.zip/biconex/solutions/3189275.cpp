#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

const int nmax = 100005;

stack<int>stiva;
int low[nmax];
int nivel[nmax];

int tot, timp = 1;

vector<int> v;
vector<int> G[nmax];

int n, m, x, y;

vector<vector<int>> ans;

void dfs(int nod)
{
	low[nod] = timp;
	nivel[nod] = timp;
	stiva.push(nod);
	timp++;
	for (auto it : G[nod])
	{
		if (nivel[it] == 0)
		{
			dfs(it);
			low[nod] = min(low[nod], low[it]);
			if (low[it] >= nivel[nod])
			{
				tot++;
				int curent;
				v.push_back(nod);
				do {
					curent = stiva.top();
					stiva.pop();
					v.push_back(curent);
				} while (curent != it);
				ans.push_back(v);
				v.clear();
			}
		}
		else {
			low[nod] = min(low[nod], nivel[it]);
		}
	}
}

int main()
{
	f >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		f >> x >> y;
		G[x].push_back(y);
		G[y].push_back(x);
	}
	dfs(1);
	g << tot << '\n';
	for (int i = 0; i < tot; i++)
	{
		for (auto it : ans[i])
		{
			g << it << " ";
		}
		g << '\n';
	}
}
