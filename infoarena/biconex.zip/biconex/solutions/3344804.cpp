#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;
ifstream fin ("biconex.in");
ofstream fout("biconex.out");
vector<vector<int> > v;
vector<vector<int> > solution;
int viz[100001], niv[100001], nvmax[100001], num, sol;
stack<int> s;
void dfs(int nod, int tata)
{
    viz[nod] = 1;
    nvmax[nod] = niv[nod];
    s.push(nod);
    for(int i =0; i<v[nod].size();i++)
    {
        int vecin = v[nod][i];
        if(tata == vecin)
            continue;
        if(viz[vecin])
        {
            if(nvmax[nod] > niv[vecin])
            {
                nvmax[nod] = niv[vecin];
            }
            continue;
        }
        niv[vecin] = niv[nod] + 1;
        //cout << vecin;
        dfs(vecin, nod);
        nvmax[nod] = min(nvmax[nod], nvmax[vecin]);

        //cout << vecin << ' ';

        if(nvmax[vecin] >= niv[nod])
        {
            int extras;
            sol++;
            do
            {
                //cout << sol << ' ' << nod << '\n';
                extras = s.top();
                solution[sol].push_back(s.top());
                s.pop();
            }while(!s.empty() && extras!=vecin);
            solution[sol].push_back(nod);
        }

    }
}
int main()
{
    int n,m;
    fin >> n >> m;
    v.resize(n+1);
    solution.resize(n+1);
    for(int i = 1; i<=m; i++)
    {
        int a, b;
        fin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    viz[1] = 1;
    dfs(1, 0);
    fout << sol << '\n';
    for(int i = 1; i<=sol; i++)
    {
        for(int j = 0; j<solution[i].size(); j++)
        {
            fout << solution[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}
