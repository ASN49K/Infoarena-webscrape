#include <bits/stdc++.h>
using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
int main()
{
    int n, m;
    fin >> n >> m;
    vector<vector<int>> g(n + 1);
    for (int i = 1; i <= m; ++i)
    {
        int a, b;
        fin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    vector<vector<pair<int, int>>> biconexe;
    vector<bool> seen(n + 1);
    vector<int> preordine(n + 1);
    vector<int> low(n + 1);
    int p = 1;
    stack<pair<int, int>> edges;
    function<void(int, int)> dfs = [&](int node, int parent)
    {
        preordine[node] = low[node] = p++;
        seen[node] = true;
        for (auto i : g[node])
        {
            if (i != parent)
            {
                if (seen[i])
                {
                    if (preordine[i] < preordine[node])
                    {
                        edges.push({node, i});
                    }
                    low[node] = min(low[node], preordine[i]);
                }
                else
                {
                    edges.push({node, i});
                    dfs(i, node);
                    low[node] = min(low[node], low[i]);
                    if (low[i] >= preordine[node])
                    {
                        biconexe.push_back({});
                        while (!edges.empty())
                        {
                            biconexe.back().push_back(edges.top());
                            if (edges.top() == pair<int, int>{node, i})
                            {
                                edges.pop();
                                break;
                            }
                            edges.pop();
                        }
                    }
                }
            }
        }
    };
    for (int i = 1; i <= n; ++i)
    {
        if (!seen[i])
        {
            dfs(i, 0);
            // assert(edges.empty());
        }
    }
    fout << (int)biconexe.size() << '\n';
    for (auto i : biconexe)
    {
        set<int> nodes;
        for (auto j : i)
        {
            nodes.insert(j.first);
            nodes.insert(j.second);
        }
        for (auto i : nodes)
        {
            fout << i << ' ';
        }
        fout << '\n';
    }
}