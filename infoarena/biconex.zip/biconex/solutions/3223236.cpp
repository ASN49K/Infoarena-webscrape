#include <bits/stdc++.h>
using namespace std;
void debug_out() { cerr << endl; }
template<class T> ostream& prnt(ostream& out, T v) { out << v.size() << '\n'; for(auto e : v) out << e << ' '; return out;}
template<class T> ostream& operator<<(ostream& out, vector <T> v) { return prnt(out, v); }
template<class T> ostream& operator<<(ostream& out, set <T> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, map <T1, T2> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, pair<T1, T2> p) { return out << '(' << p.first << ' ' << p.second << ')'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"
#define ll long long
#define ld long double
#define ull unsigned long long
#define pii pair<int,int>
#define MOD 1000000007
#define zeros(x) x&(x-1)^x
#define fi first
#define se second
#define NMAX 500005
const long double PI = acos(-1);

int n, m, a, b, H[NMAX], lst[NMAX];
vector<int> v[NMAX], st;
vector<vector<int>> ans;

void dfs(int nod, int ant = -1, int h = 1) {
  st.push_back(nod);
  H[nod] = h;
  lst[nod] = h;
  for (auto it : v[nod]) {
    if (it == ant) continue;
    if (H[it]) {
      lst[nod] = min(lst[nod], H[it]);
    } else {
      dfs(it, nod, h+1);
      lst[nod] = min(lst[nod], lst[it]);
      // lst[it] poate sa fie > h daca avem o componenta biconexa de 
      // dimensiune 2
      if (lst[it] >= h) {
        vector<int> crt;
        while (st.back() != nod) {
          crt.push_back(st.back());
          st.pop_back();
        }
        crt.push_back(nod);
        ans.push_back(crt);
      }
    }
  }
}


int main(){
  ios::sync_with_stdio(false);
  freopen("biconex.in","r",stdin);
  freopen("biconex.out","w",stdout);
  cin >> n >> m;
  for (int i=1;i<=m;i++) {
    cin >> a >> b;
    v[a].push_back(b);
    v[b].push_back(a);
  }

  for (int i=1;i<=n;i++) {
    if (!H[i])
      dfs(i);
  }

  cout << ans.size() << '\n';
  for (auto &comp : ans) {
    for (auto &it : comp) {
      cout << it << ' ';
    }
    cout << '\n';
  }

  return 0;
}