#include<iostream>
#include<fstream>
#include<algorithm>
#include<set>
#include<map>
#include<numeric>
#include<unordered_set>
#include<unordered_map>
#include<vector>
#include<stack>
#include<queue>
#include<limits>
#define all(v) v.begin(),v.end()
#define sorti(v) sort(all(v))
#define desc(x) greater<x>()
#define lsb(x) ((x)&(-x))
#define sortd(v) sort(all(v),desc(decltype(v[0])))
#define hmap unordered_map 
#define var auto&
#define hset unordered_set
#define pq priority_queue
#define inf 0x3f3f3f3f
#define exists(x,v) (v.find(x)!=v.end())
#define inrange(x,a,b) (x>=a && x<=b)
#define printv(v) {for(auto it:v) cout<<it<<' ';cout<<'\n';}
#define printa(v,a,b) {for(int i=a;i<=b;i++ ) cout<<v[i]<<' ';cout<<'\n';}
using namespace std;
typedef long long ll;
typedef unsigned long long int ull;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<long, long> pll;
typedef vector<pii> vii;
typedef vector<pll> vll;
template<typename T> T gcd(T a, T b) { T c; while (b) { c = a % b; a = b; b = c; }return a; }
template<typename T> T exp(T a, T n, T m) { T p = 1; while (n) { if (n & 1)p = (p % m * a % m) % m; a = (a % m * a % m) % m; n >>= 1; }return p; }
template<typename T> T exp(T a, T n){T p = 1; while (n) { if (n & 1)p *= a; a *= a;  n >>= 1; }return p;}
template<typename T> T invm(T a, T m) {return exp(a, m - 2, m);}
const int lim = 1e5 + 5;
vector<int> g[lim];
int n, m;
int low[lim], disc[lim];
int idx;
stack<pair<int, int>> s;
vector<hset<int>> bcomp;
void cache_bc(int x,int y)
{
	hset<int> comp;	
	int tx, ty;
	do{
		comp.insert(tx = s.top().first);
		comp.insert(ty = s.top().second);
		s.pop();
	} while (x != tx && y != ty);
	bcomp.push_back(comp);
}

void tarjan(int nod, int father,int lvl)
{
	low[nod] = disc[nod] = lvl;
	for (auto it : g[nod])
	{
		if (it == father) continue;
		if (disc[it] == -1)
		{
			s.push(make_pair(nod,it));
			tarjan(it, nod,lvl+1);
			low[nod] = min(low[nod], low[it]);
			if (low[it] >= disc[nod])
				cache_bc(nod, it);
		}
		else
			low[nod] = min(low[nod], low[it]);
	}
}

int main()
{

	freopen("biconex.in", "r", stdin);
	freopen("biconex.out", "w", stdout);
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin >> n >> m;
	for (int i = 1; i<= m; i++)
	{
		int x, y;
		cin >> x >> y;
		g[x].push_back(y);
		g[y].push_back(x);
	}
	for (int i = 1; i <= n; i++)
		disc[i] = -1;
	tarjan(1, 0,0);
	cout << bcomp.size()<<'\n';
	for (auto& it : bcomp)
	{
		for (auto& ij : it)
			cout << ij << " ";
		cout << '\n';
	}
}
