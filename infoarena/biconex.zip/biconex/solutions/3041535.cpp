#include <bits/stdc++.h>
// #define in cin
// #define out cout

using namespace std;

ifstream in("biconex.in");
ofstream out("biconex.out");

const int nmax = 1e5 + 5e0;

struct edge
{
    int a, b;
    edge(int a = 0, int b = 0) : a(a), b(b) {}
    int nxt(int val)
    {
        return a ^ b ^ val;
    }
    bool operator!=(const edge &other) const
    {
        return !(a == other.a && b == other.b);
    }
} edges[2 * nmax];

int n, m;
int d[nmax], lowlink[nmax];
bool viz[nmax];
vector<int> adj[nmax];
vector<unordered_set<int>> res;

void readinput()
{
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int a, b;
        in >> a >> b;
        edges[i] = edge(a, b);
        adj[a].push_back(i);
        adj[b].push_back(i);
    }
}

stack<edge> s;
bool isArt[nmax];

void dfs(int node = 1, int depth = 0, int p = -1)
{
    bool isA = 0;
    viz[node] = 1;
    d[node] = lowlink[node] = depth;
    int childCnt = 0;
    for (auto i : adj[node])
    {
        int nxt = edges[i].nxt(node);

        if (!viz[nxt])
        {
            s.push(edges[i]);
            dfs(nxt, depth + 1, node);
            childCnt++;
            lowlink[node] = min(lowlink[node], lowlink[nxt]);
            if (lowlink[nxt] >= d[node] && !s.empty())
            {
                isA = 1;
                unordered_set<int> tmpset;
                edge tmp = edge(0, 0);
                do
                {
                    tmp = s.top();
                    s.pop();
                    tmpset.insert(tmp.a);
                    tmpset.insert(tmp.b);
                } while (tmp != edges[i]);
                res.push_back(tmpset);
            }
        }
        else if (nxt != p)
        {
            lowlink[node] = min(lowlink[node], d[nxt]);
        }
    }
    if ((p != -1 && isA) || (p == -1 && childCnt > 1))
    {
        isArt[node] = 1;
    }
}

void printSolution()
{
    out << res.size() << '\n';
    for (auto i : res)
    {
        for (auto j : i)
            out << j << ' ';
        out << '\n';
    }
    // for (int i = 1; i <= n; i++)
    // {
    //     cerr << i << ' ' << isArt[i] << '\n';
    // }
}

int main()
{
    readinput();
    dfs();
    printSolution();
}
