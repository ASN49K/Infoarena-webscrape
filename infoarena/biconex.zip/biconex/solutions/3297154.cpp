#include <fstream>
#include <vector>
#include <stack>

using namespace std;

vector <int> t_in, t_min;
vector <vector <int>> a;
vector <vector <int>> c_bi;
stack <int> stiva;
int timp_c;

void constr_c(int x, int y, vector <int> &c)
{
    while (!stiva.empty() && stiva.top() != y)
    {
        c.push_back(stiva.top());
        stiva.pop();
    }
    c.push_back(y);
    stiva.pop();
    c.push_back(x);
}

void dfs_c_bi(int x, int t)
{
    t_in[x] = t_min[x] = ++timp_c;
    stiva.push(x);
    for (auto y: a[x])
    {
        if (y == t)
        {
            continue;
        }
        if (t_in[y] == 0)
        {
            dfs_c_bi(y, x);
            t_min[x] = min(t_min[x], t_min[y]);
            if (t_in[x] <= t_min[y])
            {
                vector <int> c;
                constr_c(x, y, c);
                c_bi.push_back(c);
            }
        }
        else
        {
            t_min[x] = min(t_min[x], t_in[y]);
        }
    }
}

int main()
{
    ifstream in("biconex.in");
    ofstream out("biconex.out");
    int n, m;
    in >> n >> m;
    t_in.resize(n + 1, 0);
    t_min.resize(n + 1, 0);
    a.resize(n + 1);
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    dfs_c_bi(1, 0);
    out << c_bi.size() << "\n";
    for (auto c: c_bi)
    {
        for (auto x: c)
        {
            out << x << " ";
        }
        out << "\n";
    }
    in.close();
    out.close();
    return 0;
}
