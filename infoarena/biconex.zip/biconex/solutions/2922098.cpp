/// Preset de infoarena
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

const int maxN = 100005;
int n, m;
int depth[maxN], ll[maxN];
bool used[maxN];
vector <int> G[maxN], comp;
vector <vector <int>> bicomp;
vector <int> stiva;

void dfs(int nod, int tata)
{
    used[nod] = 1;
    depth[nod] = depth[tata] + 1;
    ll[nod] = depth[nod];
    stiva.push_back(nod);
    for(int vecin : G[nod])
    {
        if(vecin == tata)
            continue;
        if(used[vecin])
            ll[nod] = min(ll[nod], depth[vecin]);
        if(!used[vecin])
        {
            dfs(vecin, nod);
            ll[nod] = min(ll[nod], ll[vecin]);
            if(ll[vecin] >= depth[nod])
            {
                comp.push_back(nod);
                while(stiva.back() != nod)
                {
                    comp.push_back(stiva.back());
                    stiva.pop_back();
                }
                bicomp.push_back(comp);
                comp.clear();
            }
        }
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    dfs(1, 0);
    fout << bicomp.size() << '\n';
    for(auto c : bicomp)
    {
        for(int elem : c)
            fout << elem << ' ';
        fout << '\n';
    }
    return 0;
}
