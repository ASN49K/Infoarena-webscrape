#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define Nmax 100005

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

bool vizitat[Nmax];
int up[Nmax], nivel[Nmax], S[Nmax];
vector<int> comp_biconexe[Nmax];

class Graf{
private:
    int Nr_Noduri, Nr_Muchii;
    vector < vector<int> > matrice_adiacenta;
    
public:
    Graf(int N, int M, vector< vector<int> > & matrice); // constructor
    vector < vector<int> > getMatriceAdiacenta()
    {
        return matrice_adiacenta;
    }

    void Citire_Graf_Neorientat();
    void DFS( int nod, int parinte );
};

// constructor
Graf :: Graf(int N, int M, vector < vector<int> > & matrice)
{
    Nr_Noduri = N;
    Nr_Muchii = M;
    matrice_adiacenta = matrice;
}

void Graf :: Citire_Graf_Neorientat()
{
    for ( int i = 1; i <= Nr_Muchii; i++ )
    {
        int x, y;
        fin >> x >> y;
        matrice_adiacenta[x].push_back(y);
        matrice_adiacenta[y].push_back(x);
    }
}

void Graf :: DFS(int nod, int parinte )
{
    int top = 0;
    int nr_comp_biconexe = 0;
    vizitat[nod] = 1;
    up[nod] = nivel[nod];
    S[++top] = nod; // adaugam nodul in stiva

    for ( int i = 1; i < matrice_adiacenta[nod].size(); i++ )
    {
        if ( i == parinte ) continue;
        if ( vizitat[i] )
            up[nod] = min(up[nod], nivel[i]);
        else
        {
            nivel[i] = nivel[nod] + 1;
            DFS(i, nod);
            if ( up[i] >= nivel[nod] )
            {
                nr_comp_biconexe++;
                while ( S[top] != i && top )
                    comp_biconexe[nr_comp_biconexe].push_back(S[top--]);
                comp_biconexe[nr_comp_biconexe].push_back(S[top--]);
                comp_biconexe[nr_comp_biconexe].push_back(nod);
            }
            up[nod] = min(up[nod], up[i]);
        }
    }
    fout << nr_comp_biconexe << "\n";
    for ( int i = 1; i <= nr_comp_biconexe; i++ )
    {
        for ( int j = 1; j < comp_biconexe[i].size(); j++ )
            fout << j << " ";
        fout << "\n";
    }
}

int main()
{
    int N, M;
    fin >> N >> M;
    
    vector < vector<int> > matrice;
    vector <int> aux(1,-1);
    matrice.resize(N+1, aux);

    Graf G(N, M, matrice);
    G.Citire_Graf_Neorientat();

    G.DFS(1, 0);

    return 0;
}