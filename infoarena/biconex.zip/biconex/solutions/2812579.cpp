#include <bits/stdc++.h>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

const int N = 1e5 + 1;
int n, m, x, y, t[N], tmin[N], timp, cnt;
vector<int> c[N], cbc[N];
stack<int> stiva;

void adaugaCBC(int x, int y){
    cnt++;
    while(stiva.top() != y){
        cbc[cnt].push_back(stiva.top());
        stiva.pop();
    }

    cbc[cnt].push_back(y);
    cbc[cnt].push_back(x);
    stiva.pop();
}

void dfs(int nod, int tata = 0){
    t[nod] = tmin[nod] = ++timp;
    stiva.push(nod);
    for(int y: c[nod]){
        if(t[y] == 0){
            dfs(y, nod);
            tmin[nod] = min(tmin[nod], tmin[y]);
            if(tmin[y] >= t[nod])
                adaugaCBC(nod, y);
        }else if(y != tata)
            tmin[nod] = min(tmin[nod], t[y]);
    }
}

int main(){
    f >> n >> m;
    for(int i = 0; i < m; i++){
        f >> x >> y;
        c[x].push_back(y);
        c[y].push_back(x);
    }

    f.close();
    for(int i = 1; i <= n; i++){
        if(t[i] == 0)
            dfs(i);
    }

    g << cnt << '\n';
    for(int i = 1; i <= cnt; i++){
        for(int x: cbc[i])
            g << x << ' ';

        g << '\n';
    }

    g.close();
}
