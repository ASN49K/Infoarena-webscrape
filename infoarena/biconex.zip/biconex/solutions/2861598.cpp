#include <fstream>

using namespace std;
ifstream f("algsort.in");
ofstream g("algsort.out");
void quick(int a[],int st,int dr)
{
    if(st>=dr)
        return;
    int m=(st+dr)/2,i=st,j=dr,d=0;
    swap(a[st],a[m]);
    while(i<j)
    {
        if(a[i]>a[j])
        {
            swap(a[i],a[j]);
            d=1-d;
        }
        i=i+d;
        j=j-(1-d);
    }
    quick(a,st,i-1);
    quick(a,i+1,dr);
}
int n,i,a[500011];
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        f>>a[i];
    quick(a,1,n);
    for(i=1;i<=n;i++)
        g<<a[i]<<" ";
    return 0;
}
