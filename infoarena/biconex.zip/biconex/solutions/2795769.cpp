#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

class Graf
{
private:

	int nrMuchii, nrNoduri;
	vector<vector<int>> listaAdiacenta;
	bool orientat;

	void adaugaMuchie(int, int, bool);		    //Am decis sa fac adaugarea unei muchii in lista de adiacenta o functie, poate o sa fie useful later?
	void DFSAux(int, vector<bool>&);			//Functie auxiliara pt problema DFS de pe infoarena
	void DFS(int, vector<bool>&, vector<vector<int>>&);			//Metoda care returneaza arborele DFS al grafului (maybe useful later)
	void BCXAux(int, int, vector<int>&, vector<int>&, vector<int>&, stack<int>&, vector<vector<int>>&);		//Metoda auxiliara pt problema Componente Biconexe de pe infoarena

public:
	Graf();
	Graf(int, int, bool);
	void BFS(int);							//Functie care rezolva problema BFS de pe infoarena
	int DFSrezolvare(int);					//Functie care rezolva problema DFS de pe infoarena
	void Biconexe();						//Functie care rezolva problema Componente Biconexe de pe infoarena
};

Graf::Graf()
{
	nrMuchii = 0;
	nrNoduri = 0;
	orientat = false;
}

Graf::Graf(int n, int m, bool orr)
{
	int x, y;

	nrNoduri = n;
	nrMuchii = m;
	orientat = orr;
	listaAdiacenta.resize(nrNoduri + 1);	//Construim si reprezentarea grafului in constructor

	for (int i = 0; i < nrMuchii; i++)
	{
		fin >> x >> y;
		adaugaMuchie(x, y, orientat);
	}
}

void Graf::adaugaMuchie(int n1, int n2, bool orr)
{
	listaAdiacenta[n1].push_back(n2);
	if (!orr)
	{
		listaAdiacenta[n2].push_back(n1);
	}
}

void Graf::BFS(int nodStart)
{
	queue<int> q;
	vector<bool> vizitate(nrNoduri+1, false);		//vector de bool initializat cu false, in el vom retine daca nodurile au fost vizitate
	vector<int> distante(nrNoduri+1, -1);			//vector de int care retine distantele de la nodul de start, initializat cu -1

	q.push(nodStart);

	vizitate[nodStart] = true;
	distante[nodStart] = 0;

	while (!q.empty())
	{
		int nodCurent = q.front();
		q.pop();

		for (int nodVecin : listaAdiacenta[nodCurent])
		{
			if (!vizitate[nodVecin])
			{
				vizitate[nodVecin] = true;			//BFS normal, iar in if() calculam si distanta dintre nodul curent si nodul de start
				q.push(nodVecin);					//Distanta creste cu 1 de fiecare data cand trecem de la un nod la altul
				distante[nodVecin] = distante[nodCurent] + 1;
			}
		}
	}

	for (int i=1; i < distante.size(); i++)
	{
		fout << distante[i] << ' ';					//Afisam distantele
	}
}

void Graf::DFSAux(int nodStart, vector<bool>& vizitate)
{
	vizitate[nodStart] = true;
	for (int i : listaAdiacenta[nodStart])
	{
		if (!vizitate[i])					//DFS care modifica lista de noduri vizitate din metoda care rezolva problema DFS
		{
			DFSAux(i, vizitate);
		}
	}
	
}

int Graf::DFSrezolvare(int nodStart)
{
	vector<bool> vizitate(nrNoduri+1, false);
	int nrComponente = 0;
	
	for (int i = 1; i < vizitate.size(); i++)
	{
		if (!vizitate[i])
		{									//Incrementam numarul de componente pentru fiecare apel al DFSAux
			DFSAux(i, vizitate);			//Pt ca fiecare apel DFS marcheaza toate nodurile din cate o componenta conexa
			nrComponente++;					//Deci fiecare apel ne baga intr-o componenta conexa noua
		}
	}
	return nrComponente;
}

void Graf::DFS(int nodStart, vector<bool>& vizitate, vector<vector<int>>& arboreDFS)
{
	vizitate[nodStart] = true;
	for (int i : listaAdiacenta[nodStart])
	{
		if (!vizitate[i])
		{
			arboreDFS[nodStart].push_back(i);
			arboreDFS[i].push_back(nodStart);				//Metoda care construieste arbore DFS pt graful nostru
			DFS(i, vizitate, arboreDFS);
		}
	}
}

void Graf::BCXAux(int nodStart, int adancimeStart, vector<int>& adancimi, vector<int>& adancimeMinima, vector<int>& parinti, stack<int>& s, vector<vector<int>>& componenteBCX)
{
	adancimi[nodStart] = adancimeStart;
	adancimeMinima[nodStart] = adancimeStart;
	adancimeStart++;

	for (auto vecin : listaAdiacenta[nodStart])
	{
		s.push(nodStart);
		
		if (vecin != parinti[nodStart]) {
			if (adancimi[vecin] == -1)
			{
				parinti[vecin] = nodStart;

				BCXAux(vecin, adancimeStart, adancimi, adancimeMinima, parinti, s, componenteBCX);

				adancimeMinima[nodStart] = min(adancimeMinima[vecin], adancimeMinima[nodStart]);

				if (adancimi[nodStart] <= adancimeMinima[vecin])
				{
					vector<int> componenta;
					componenta.push_back(nodStart);

					vector<bool> adaugat(nrNoduri + 1, false);
					adaugat[nodStart] = true;
					int nod = s.top();
					s.pop();
					componenta.push_back(nod);
					adaugat[nod] = true;

					while (nod != vecin)
					{
						nod = s.top();
						s.pop();
						if (!adaugat[nod]) {
							componenta.push_back(nod);
							adaugat[nod] = true;
						}
						
					}

					componenteBCX.push_back(componenta);
				}
			}
			else
			{
				adancimeMinima[nodStart] = min(adancimi[vecin], adancimeMinima[nodStart]);
			}
		}
	}
}

void Graf::Biconexe()
{
	vector<int> adancimi(nrNoduri + 1, -1);
	vector<int> adancimeMinima(nrNoduri + 1, -1);
	stack<int> s;
	vector<vector<int>> componente;
	vector<int> parinti(nrNoduri + 1, -1);

	parinti[1] = 1;
	BCXAux(1,1,adancimi,adancimeMinima,parinti,s, componente);

	fout << componente.size() << "\n";
	for (auto i : componente)
	{
		for (auto j : i)
		{
			fout << j << ' ';
		}
		fout << endl;
	}

	
}

int main()
{
	int n, m;
	fin >> n >> m;
	Graf G(n, m, false);

	G.Biconexe();

	return 0;
}