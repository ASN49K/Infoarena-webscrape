#include <fstream>
#include <vector>
#include <set>
using namespace std;
ifstream cin ("biconex.in");
ofstream cout ("biconex.out");
int nma[100005];
int nivel[100005];
bool u[100005];
vector<int> g[100005];
vector < set<int> > componente;
int st[100005];
int s;
void dfs (int vf,int tata)
{
    st[++s] = vf;
    u[vf] = true;
    nivel[vf] = nivel[tata] + 1;
    nma[vf] =  nivel[vf];
    for (auto urm : g[vf])
    {
        if (urm == tata)
            continue;
        if (u[urm])
        {
            nma[vf] = min(nma[vf],nivel[urm]);
            continue;
        }
        dfs(urm,vf);
        nma[vf] = min(nma[vf],nma[urm]);
        if (nivel[vf] <= nma[urm])
        {
            set<int> componenta;
            while (st[s]!=urm)
            {
                componenta.insert(st[s]);
                s--;
            }
            componenta.insert(st[s]);
            s--;
            componenta.insert(vf);
            componente.push_back(componenta);
        }
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,m;
    cin >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x,y;
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for (int i=1; i<=n; i++)
    {
        if (u[i])
            continue;
        dfs(i,0);
    }
    cout << componente.size() << '\n';
    for (auto v:componente)
    {
        for (auto nr : v)
            cout << nr << ' ';
        cout << '\n';
    }
    return 0;
}
