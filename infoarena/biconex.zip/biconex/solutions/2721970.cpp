#include <bits/stdc++.h>
using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int N, M;

vector <int> v[100005];

int lvl[100005], low[100005], k;

stack <int> st;

vector <vector <int> > ans;

void dfs(int node, int dad)
{
    lvl[node] = low[node] = ++k;
    st.push(node);

    for(int i = 0; i < v[node].size(); i++)
        if(v[node][i] != dad)
    {

        if(lvl[v[node][i]] == 0)
            dfs(v[node][i], node);
        else
        {
            low[node] = min(low[node], low[v[node][i]]);
            continue;
        }

        low[node] = min(low[node], low[v[node][i]]);

        if(lvl[node] <= low[v[node][i]])
        {
            vector <int> aux;

            while(st.top() != v[node][i])
            {
                aux.push_back(st.top());
                st.pop();
            }

            aux.push_back(st.top());
            st.pop();

            aux.push_back(node);

            ans.push_back(aux);
        }
    }
}

int main()
{
    fin >> N >> M;

    for(int i = 1; i <= M; i++)
    {
        int x, y;

        fin >> x >> y;

        v[x].push_back(y);
        v[y].push_back(x);
    }

    for(int i = 1; i <= N; i++)
        if(lvl[i] == 0)
            dfs(i, 0);

    if(ans.size() == 0)
    {
        fout << 1 << '\n';

        for(int i = 1; i <= N; i++)
            fout << i << " ";

        return 0;
    }

    fout << ans.size() << '\n';

    for(int i = 0; i < ans.size(); i++)
    {
        for(int j = 0; j < ans[i].size(); j++)
            fout << ans[i][j] << " ";
        fout << '\n';
    }

    return 0;
}
