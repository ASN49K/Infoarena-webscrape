#include <bits/stdc++.h>
using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

bool v[100005];
int n, m, lev[100005], low[100005];
vector<int> g[100005];
vector<vector<int> > comp;
stack<pair<int, int> > st;

void add(int x, int y) {
    vector<int> c;
    int a, b;
    do {
       a = st.top().first;
       b = st.top().second;
       st.pop();
       c.push_back(a);
       c.push_back(b);
    } while(!st.empty() && (a != x || b != y));
    sort(c.begin(), c.end());
    comp.push_back(c);
}

void dfs(int x, int t) {
    low[x] = lev[x] = lev[t]+1;
    v[x] = true;
    for(auto next: g[x]) {
        if(!v[next]) {
            st.push({x, next});
            dfs(next, x);
            if(low[next] >= lev[x])
                add(x, next);
            low[x] = min(low[x], low[next]);
        } else if(next != t)
            low[x] = min(low[x], lev[next]);
    }
}

int main() {
    fin >> n >> m;
    while(m--) {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1, 0);

    fout << comp.size() << '\n';
    for(auto c: comp) {
        for(int i = 0; i < c.size(); i++)
            if(i == 0 || c[i] != c[i-1])
                fout << c[i] << ' ';
        fout << '\n';
    }
}
