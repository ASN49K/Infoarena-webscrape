/*
de ce pula mea nu merge aceasta versiune
*/
#include <fstream>
#include <algorithm>
#include <vector>
#define ll long long
using namespace std;

const int NMAX = 1e5;

vector <int> g[NMAX + 1];

int low[NMAX + 1];
int enter[NMAX + 1];

bool art[NMAX + 1];

vector <int> cur;
vector <vector <int> > comps;


void compute_bcc(int nod)
{
    comps.push_back(vector <int> ());
    while (cur.back() != nod)
    {
        comps.back().push_back(cur.back());
        cur.pop_back();
    }
    cur.pop_back();
    comps.back().push_back(nod);
    comps.back().resize(unique(comps.back().begin(), comps.back().end()) - comps.back().begin());
}

int n;

void dfs(int nod, int parent)
{
    static int time = 0;
    enter[nod] = ++time;
    low[nod] = enter[nod];
    bool first = 0;
    for (int x : g[nod])
        if (x != parent)
        {
            if (enter[x] == 0)
            {
                cur.push_back(nod);
                cur.push_back(x);
                dfs(x, nod);
                if (enter[nod] <= low[x])
                {
                    art[nod] = (enter[nod] > 1 or enter[x] > 2);
                    compute_bcc(nod);
                }
                low[nod] = min(low[nod], low[x]);
            }
            else
                low[nod] = min(low[nod], enter[x]);
        }
}

signed main()
{
    ifstream cin("biconex.in");
    ofstream cout("biconex.out");
    int m, i;
    cin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs(1, 0);
    cout << comps.size() << "\n";
    for (i = 0; i < comps.size(); i++, cout << "\n")
        for (int x : comps[i])
            cout << x << " ";
}
