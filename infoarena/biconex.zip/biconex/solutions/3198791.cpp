#include <bits/stdc++.h>
#define DIM 100005

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int n,m,i,j,x,y,cb,low[DIM],niv[DIM];
bool v[DIM];
vector<int> L[DIM],comp[DIM];
stack<int> s;

void componente_biconexe(int nod, int tata)
{
    v[nod] = true; s.push(nod);
    niv[nod] = niv[tata]+1; low[nod] = niv[nod];
    for (int i=0; i<L[nod].size(); i++)
    {
        int vecin = L[nod][i];
        if (vecin == tata)
            continue;
        if (v[vecin])
            low[nod] = min(low[nod], niv[vecin]);
        else
        {
            componente_biconexe(vecin, nod);
            low[nod] = min(low[nod], low[vecin]);
            if (low[vecin] >= niv[nod])
            {
                cb++; int val = 0;
                do {
                    val = s.top(); s.pop();
                    comp[cb].push_back(val);
                } while (val != vecin);
                comp[cb].push_back(nod);
            }

        }
    }
}

int main()
{
    fin >> n >> m;
    for (i=1; i<=m; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for (i=1; i<=n; i++)
        if (!v[i])
            componente_biconexe(i, 0);
    fout << cb << "\n";
    for (i=1; i<=cb; i++)
    {
        for (j=0; j<comp[i].size(); j++)
            fout << comp[i][j] << " ";
        fout << "\n";
    }
    return 0;
}