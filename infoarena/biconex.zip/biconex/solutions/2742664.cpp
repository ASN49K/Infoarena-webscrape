#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
typedef pair<int,int> pii;
int n,m,niv[100005],nivmin[100005];
vector<int> muchii[100005];
vector<vector<int>> sol;
deque<pii> st;
bool use[100005];
void getsol(int x,int y)
{
    vector<int> aux;
    while(!st.empty())
    {
        int a=st.back().first;
        int b=st.back().second;
        st.pop_back();
        aux.push_back(a);
        aux.push_back(b);
        if(a==x&&b==y)
            break;
        if(a==y&&b==x)
            break;
    }
    sort(aux.begin(),aux.end());
    aux.erase(unique(aux.begin(),aux.end()),aux.end());
    sol.push_back(aux);
}
void dfs(int nod,int parent,int level)
{
    use[nod]=1;
    niv[nod]=level;
    nivmin[nod]=level;
    for(auto i:muchii[nod])
    {
        if(i==parent)
            continue;
        if(!use[i])
        {
            st.push_back({nod,i});
            dfs(i,nod,level+1);
            nivmin[nod]=min(nivmin[nod],nivmin[i]);
            if(niv[nod]<=nivmin[i])
                getsol(nod,i);
        }
        else
        {
            nivmin[nod]=min(nivmin[nod],niv[i]);
            /*if(niv[nod]<=nivmin[i])
                getsol(nod,i);*/
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    dfs(1,0,1);
    fout<<sol.size()<<'\n';
    for(auto i:sol)
    {
        for(auto j:i)
            fout<<j<<" ";
        fout<<'\n';
    }
    return 0;
}

