#include <fstream>
#include <vector>
#include <stack>
#include <set>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

vector <int> v[100003];
stack <pair <int, int> > st;

set <int> rez[100003];

int niv[100003];
int up[100003];
bool viz[100003];

int n, m, cnt;

void citire() {
    int i, x, y;

    f >> n >> m;

    for (i = 1; i <= m; i++) {
        f >> x >> y;

        v[x].push_back(y);
        v[y].push_back(x);
    }
}

void afisare() {
    int i;

    g << cnt << '\n';

    for (i = 1; i <= cnt; i++) {
        for (auto j:rez[i])
            g << j << " ";

        g << '\n';
    }
}

void DFS(int nod, int tata) {
    int i, urm, ok = 1;

    viz[nod] = 1;
    niv[nod] = niv[tata] + 1;
    up[nod] = niv[nod];

    for (i = 0; i < v[nod].size(); i++) {
        urm = v[nod][i];

        if (urm == tata) continue;

        if (viz[urm] == 1) {
            up[nod] = min(up[nod], niv[urm]);
        }
        else {
            st.push({nod, urm});

            DFS(urm, nod);

            if (up[urm] >= niv[nod]) {
                cnt ++;

                while (st.top().first != nod && st.top().second != urm) {
                    rez[cnt].insert(st.top().first);
                    rez[cnt].insert(st.top().second);

                    st.pop();
                }

                rez[cnt].insert(st.top().first);
                rez[cnt].insert(st.top().second);

                st.pop();
            }

            up[nod] = min(up[nod], up[urm]);
        }
    }
}

int main()
{
    citire();

    niv[0] = 0;

    DFS(1, 0);

    afisare();

    return 0;
}
