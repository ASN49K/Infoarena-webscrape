#include <fstream>
#include <vector>
#include <stack>


using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
int const N = 2e5 + 3;
int n , m , cnt , bcx;
int idx[N] , low[N];
stack<int> st;
vector<int> v[N] , comp[N];
void baga_biconexa(int x , int y){
    ++bcx;
    while(st.top() != y){
        comp[bcx].push_back(st.top());
        st.pop();
    }
    comp[bcx].push_back(st.top());
    st.pop();
    comp[bcx].push_back(x);
}
void dfs(int x , int t = -1){
    idx[x] = low[x] = ++cnt;
    st.push(x);
    for(int y : v[x]){
        if(y == t)
            continue;
        if(idx[y]){
            low[x] = min(low[x] , idx[y]);
        }else{
            dfs(y , x);
            low[x] = min(low[x] , low[y]);
            if(low[y] >= idx[x]){
                baga_biconexa(x , y);
            }
        }
    }
}
int main()
{
    fin >> n >> m;
    for(int i = 1 ; i <= m ; ++ i){
        int a , b;
        fin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    for(int i = 1 ; i <= n ; ++ i){
        if(!idx[i])
            dfs(i , -1);
    }
    fout << bcx << '\n';
    for(int i = 1 ; i <= bcx ; ++ i){
        for(int j : comp[i])
            fout << j << ' ';
        fout << '\n';
    }
    return 0;
}
