#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

vector <int> edges[NMAX + 1];
bool viz[NMAX + 1];
int foundTime[NMAX + 1];
int minTime[NMAX + 1];
int timp;

stack <int> st;

vector <vector<int>> comps;

void dfs( int node, int p = 0 ) {
    minTime[node] = foundTime[node] = ++timp;
    viz[node] = true;
    st.push( node );
    for ( auto vec : edges[node] ) {
        if ( !viz[vec] ) {
            dfs( vec );
            minTime[node] = min( minTime[vec], minTime[node] );
            if ( minTime[vec] >= foundTime[node] ) {
                vector <int> comp;
                while ( st.top() != vec ) {
                    comp.push_back( st.top() );
                    st.pop();
                }
                comp.push_back( st.top() );
                st.pop();
                comp.push_back( node );
                comps.push_back( comp );
            }
        } else if ( vec != p ) minTime[node] = min( minTime[node], foundTime[vec] );
    }
}

int main() {

    ifstream fin( "biconex.in" );
    ofstream fout( "biconex.out" );
    int n, m;
    fin >> n >> m;
    for ( int i = 1, a, b; i <= m; i ++ ) {
        fin >> a >> b;
        edges[a].push_back( b );
        edges[b].push_back( a );
    }
    dfs( 1 );
    fout << comps.size() << '\n';
    for ( auto c : comps ) {
        for ( auto x : c ) fout << x << ' ';
        fout << '\n';
    }
    return 0;
}

