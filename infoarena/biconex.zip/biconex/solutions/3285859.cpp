#include <bits/stdc++.h>
#define vi vector<int>
#define vvi vector<vi>
#define pb push_back
#define pii pair<int, int>
#define ff first
#define ss second
#define FOR(i, a, b) for(int i = a; i <= b; ++i)
#define FORR(i, a, b) for(int i = a; i >= b; --i)

using namespace std;
const string TASK("biconex);
ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");
#define cin fin
#define cout fout

const int N = 1e6 + 9;
const bool test_case = false;

int n, m;
vvi G(N);

stack<pii> stk;
int lvl[N], low[N], idx;
vvi c;
void Dfs(int x, int p)
{
    lvl[x] = low[x] = ++idx;

    for(auto y : G[x])
    {
        if(y == p)continue;

        if(!lvl[y])
        {
            stk.push({x, y});
            Dfs(y, x);
            low[x] = min(low[x], low[y]);
            if(lvl[x] <= low[y])
            {
                c.pb({});
                int a, b;
                do
                {
                    tie(a, b) = stk.top();
                    stk.pop();
                    c.back().pb(a), c.back().pb(b);
                }while(a != x && b != y);
            }
        }
        else low[x] = min(low[x], lvl[y]);
    }
}

void solve()
{
    cin >> n >> m;

    int x, y;
    FOR(i, 1, m)
    {
        cin >> x >> y;
        G[x].pb(y);
        G[y].pb(x);
    }

    FOR(i, 1, n)
        if(!lvl[i])
            Dfs(i, 0);

    for(auto& e : c)
    {
        sort(e.begin(), e.end());
        e.erase(unique(e.begin(), e.end()), e.end());
    }

    cout << c.size() << '\n';
    for(auto e : c)
    {
        for(auto i : e)cout << i << ' ';
        cout << '\n';
    }
}

int main()
{
    int t = 1;
    if(test_case)cin >> t;
    while(t --)
        solve();
    return 0;
}
