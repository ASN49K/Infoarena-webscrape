#include <fstream>
#include <vector>
#define ll long long
using namespace std;

const int NMAX = 1e5;

vector <int> g[NMAX + 1];


int low[NMAX + 1];
int enter[NMAX + 1];

bool art[NMAX + 1];

vector <int> cur;
vector <vector <int> > comps;

void dfs(int nod, int parent)
{
    static int time = 0;
    enter[nod] = ++time;
    low[nod] = enter[nod];
    int cnt = 0;
    for (int x : g[nod])
        {
            if (enter[x] == 0)
            {
                cnt++;
                dfs(x, nod);
                if (low[x] == enter[nod])
                {
                    if (nod == 1)
                        art[nod] = (cnt > 1);
                    else
                        art[nod] = 1;
                }
                low[nod] = min(low[nod], low[x]);
            }
            else
                low[nod] = min(low[nod], enter[x]);
        }
   // cout << nod << ": ";
}

signed main()
{
    ifstream cin("biconex.in");
    ofstream cout("biconex.out");
    int n, m, i;
    cin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs(1, 0);
    int cnt = 0;
    for (i = 1; i <= n; i++)
        if (art[i] == 1)
        {
            cnt++;
        }
    cout << cnt + 1;
    /*
    cout << comps.size() << "\n";
    for (i = 0; i < comps.size(); i++, cout << "\n")
        for (int x : comps[i])
            cout << x << " ";*/
}
