#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

vector<int> g[100001];
stack<int> s;
vector<vector<int>> rez;
int n, m, p[100001], v[100001], low[100001], niv[100001], timp, c;

void dfs(int k, int dad){
    v[k] = 1;
    low[k] = niv[k] = ++timp;
    s.push(k);
    for(int e : g[k]){
        if(!v[e]) {
            dfs(e, k);
    
            if(low[e] >= niv[k]) {
                vector<int> vec;
                while (!s.empty() && s.top() != k)
                {
                    vec.push_back(s.top());
                    s.pop();
                }
                if(!s.empty()) vec.push_back(s.top());
                rez.push_back(vec);
                c++;
            }

            low[k] = min(low[k], low[e]);
        }
        else if(e != dad) low[k] = min(low[k], niv[e]);
    }
}

int main(){
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y), g[y].push_back(x);
    }
    for(int i = 1; i <= n; i++) if(!v[i]) dfs(i, -1);
    fout << c << '\n';
    for(int i = 0; i < rez.size(); i++, fout << '\n')
        for(int j = 0; j < rez[i].size(); j++) fout << rez[i][j] << ' ';
    return 0;
}