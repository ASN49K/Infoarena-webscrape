#include <fstream>
#include <vector>
using namespace std;
ifstream f("biconex.in");
ofstream g("biconex.out");
#define N 100005
int disc[N],best[N],father[N],st[N],k,c;
vector<int> v[N],comp[N];
void dfs(int x)
{
    st[++k]=x;
    for(auto i:v[x])
    {
        if(father[x]==i)
            continue;
        if(disc[i])
            best[x]=min(best[x],disc[i]);
        else
        {
            father[i]=x;
            best[i]=disc[i]=disc[x]+1;
            dfs(i);
            best[x]=min(best[x],best[i]);
            if(disc[x]<=best[i])
            {
                c++;
                while(st[k]!=x)
                    comp[c].push_back(st[k--]);
                comp[c].push_back(x);
            }
        }
    }
}
int main()
{
    int n,m;
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    disc[1]=best[1]=1;
    dfs(1);
    g<<c<<'\n';
    for(int i=1;i<=c;i++)
    {
        for(auto j:comp[i])
            g<<j<<" ";
        g<<'\n';
    }
    return 0;
}