#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

vector<int> g[100001];
stack<int> s;
vector<vector<int>> rez;
int n, m, p[100001], v[100001], low[100001], niv[100001], timp, c;

void dfs(int k, int dad){
    v[k] = 1;
    s.push(k);
    low[k] = niv[k] = ++timp;
    for(int e : g[k]){
        if(!v[e]) {
            dfs(e, k);

            low[k] = min(low[k], low[e]);
    
            if(low[e] >= niv[k]) {
                vector<int> vec;
                while(!s.empty() && s.top() != e)
                    vec.push_back(s.top()), s.pop();
                vec.push_back(k);
                rez.push_back(vec);
                c++;
            }
        }
        else if(e != dad) low[k] = min(low[k], niv[e]);
    }
}

int main(){
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y), g[y].push_back(x);
    }
    dfs(1, -1);
    fout << c << '\n';
    for(int i = 0; i < rez.size(); i++, fout << '\n')
        for(int j = 0; j < rez[i].size(); j++) fout << rez[i][j] << ' ';
    return 0;
}