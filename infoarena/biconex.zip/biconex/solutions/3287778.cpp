/*
  ____   ___  _     ___ ____    _
 / ___| / _ \| |   |_ _/ ___|  / \
 \___ \| | | | |    | | |     / _ \
  ___) | |_| | |___ | | |___ / ___ \
 |____/ \___/|_____|___\____/_/   \_\

*/
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long int
#define pii pair<int,int>

const int NMAX = 2e5+9;

const int MOD = 1e9+7;

int binpow(int n, int k)
{
    if (k==0)
    {
        return 1;
    }
    int x=binpow(n,k/2)%MOD;
    if (k%2==0)
    {
        return x*x%MOD;
    }
    else
    {
        return x*x%MOD*n%MOD;
    }
}

int n,m;

int viz[NMAX];

vector<int>g[NMAX];

vector<int>stiva;

int mindpt[NMAX];

int depth[NMAX];

int bcc;

vector<int>comp[NMAX];

ifstream fin ("biconex.in");
ofstream fout ("biconex.out");

#define cin fin
#define cout fout

void dfs (int node, int parent=0)
{
    viz[node]=1;
    mindpt[node]=depth[node]=depth[parent]+1;
    stiva.pb (node);
    for (auto it : g[node])
    {
        if (viz[it])
        {
            mindpt[node]=min (mindpt[node],depth[it]);
        }
        else
        {
            dfs (it,node);
            mindpt[node]=min (mindpt[node],mindpt[it]);
            if (mindpt[it]>=depth[node])
            {
                bcc++;
                while (!stiva.empty() && stiva.back()!=it)
                {
                    comp[bcc].pb (stiva.back());
                    stiva.pop_back();
                }
                comp[bcc].pb (it);
                stiva.pop_back ();
                comp[bcc].pb (node);
            }
        }
    }
}

void run_case ()
{
    cin>>n>>m;
    for (int i=1; i<=m; i++)
    {
        int a,b;
        cin>>a>>b;
        g[a].pb (b),g[b].pb (a);
    }
    dfs (1);
    cout<<bcc<<'\n';
    for (int i=1; i<=bcc; i++)
    {
        sort (comp[i].begin(),comp[i].end());
        for (auto it : comp[i])
        {
            cout<<it<<' ';
        }
        cout<<'\n';
    }
}

signed main ()
{
    ios_base::sync_with_stdio(0);
    cin.tie(NULL),cout.tie (NULL);
    int teste;
    teste=1;
    while (teste--)
    {
        run_case();
    }
}
