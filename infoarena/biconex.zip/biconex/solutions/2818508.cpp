#include <bits/stdc++.h>
#define oo 0x3f3f3f3f

using namespace std;
ifstream f("biconex.in");
ofstream g("biconex.out");
int n, m, number;
vector<int> graf[100001];
int dfn[100001], low[100001];
vector<int> result[100001];
stack<int> s;
bool viz[100001];

void read()
{
  f>>n>>m;
  int x, y;
  for(int i = 1;i <= m;++i) 
    f>>x>>y, graf[x].push_back(y), graf[y].push_back(x);
}

void dfs(int node, int level)
{
  dfn[node] = low[node] = level;
  s.push(node);
  viz[node] = true;
  
  for(int vecin : graf[node])
    if(viz[vecin])
      low[node] = min(low[node], dfn[vecin]);
    else
    {
      dfs(vecin, level + 1);
      low[node] = min(low[node], low[vecin]);

      if(low[vecin] >= dfn[node])
      {
        ++number;
        result[number].push_back(node);
        int x;

        do{
          x = s.top();
          s.pop();
          result[number].push_back(x);
        }while(x != vecin);
      }
    }
}

void solve()
{
  dfs(1, 1);
  
  g<<number<<'\n';
  for(int i = 1;i <= number;++i, g<<'\n')
    for(int node : result[i])
      g<<node<<" ";
}

int main()
{
  read();
  solve();
  return 0;
} 
