#include <fstream>
#include <vector>
#include <stack>

using namespace std;

const int nmax = 1e5;

vector < int > g[nmax + 1];
vector < int > c[nmax + 1];

int timp = 0, comp = 0;
int vis[nmax + 1];
int tin[nmax + 1];
int low[nmax + 1];
stack < int > st;

void dfs ( int node, int parent = -1 ) {
    tin[node] = low[node] = timp++;
    vis[node] = 1;
    st.push ( node );

    for ( int &to: g[node] )
        if ( to != parent ) {
            if ( vis[to] ) /// back - edge
                low[node] = min ( low[node], tin[to] );
            else { /// tree - edge
                dfs ( to, node );
                low[node] = min ( low[node], low[to] );
                if ( low[to] >= tin[node] ) {
                    while ( st.top () != to )
                        c[comp].push_back ( st.top () ), st.pop ();

                    c[comp].push_back ( to ), st.pop ();
                    c[comp].push_back ( node );
                    comp++;
                }
            }
        }
}

ifstream fin ( "urgenta.in" );
ofstream fout ( "urgenta.out" );

int main() {
    int n, m, x, y;

    fin >> n >> m;

    for ( int i = 0; i < m; i++ ) {
        fin >> x >> y;
        g[x].push_back ( y );
        g[y].push_back ( x );
    }

    for ( int i = 1; i <= n; i++ )
        if ( !vis[i] )
            dfs ( i );

    fout << comp << '\n';
    for ( int i = 0; i < comp; i++, fout << '\n' )
        for ( int &x: c[i] )
            fout << x << ' ';

    return 0;
}
