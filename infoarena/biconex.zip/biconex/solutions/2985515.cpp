#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

void solve() {
    /* traverse the dfs tree and find the articulation points
       save all the edges in a stack and when we travers and when we find an articulation point
       (an articulation is defined as a vertex which, when removed along with associated edges, makes the graph disconnected)
       pop every edge from the stack until we reach the current edge
    */
    function <void(int, int)> dfs;
    int n, m; re(n, m);
    vt <vt <int>> adj(n), res;
    for (int i = 0; i < m; ++i) {
        int u, v; re(u, v);
        --u, --v;
        adj[u].emb(v);
        adj[v].emb(u);
    }

    stack <ar <int, 2>> st;
    vt <int> tin(n), low(n);
    int t = 0;
    dfs = [&](int u, int p = -1) {
        tin[u] = low[u] = ++t;
        int nr = 0;
        for (int& v : adj[u]) {
            if (v == p) {
                continue;
            }

            if (!tin[v]) {
                st.push({u, v});
                dfs(v, u);
                low[u] = min(low[u], low[v]);
                // we found an articulation point
                if (low[v] >= tin[u]) {
                    // if we find an articulation point we pop
                    vt <int> tmp; int tx, ty;
                    do {
                        tie(tx, ty) = mt(st.top()[0], st.top()[1]);
                        st.pop();
                        tmp.emb(tx + 1), tmp.emb(ty + 1);
                    } while (tx != u or ty != v);
                    res.emb(tmp);
                }
            } else {
                low[u] = min(low[u], tin[v]);
            }
        }

    };

    dfs(0, -1);

    wr(len(res), '\n');
    for (int i = 0; i < len(res); ++i) {
        sort(all(res[i]));
        res[i].erase(uniq(res[i]));
        wr(res[i], '\n');
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("biconex");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}