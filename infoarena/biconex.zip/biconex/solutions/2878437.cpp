#include <bits/stdc++.h>

using namespace std;
ifstream fin("biconex.in");
ofstream fout("biconex.out");
typedef pair<int,int> pii;
int n,m;
vector<int> muchii[100005];
vector<vector<int>> sol;
bool use[100005];
stack<pii> st;
int niv[100005],nivmin[100005];
void build(int a,int b)
{
    vector<int> v;
    while(!st.empty())
    {
        pii x=st.top();
        st.pop();
        v.push_back(x.first);
        v.push_back(x.second);
        if(x.first==a&&x.second==b)
            break;
        if(x.first==b&&x.second==a)
            break;
    }
    sort(v.begin(),v.end());
    v.erase(unique(v.begin(),v.end()),v.end());
    sol.push_back(v);
}
void dfs(int nod)
{
    use[nod]=1;
    if(niv[nod]==0)
        niv[nod]=1;
    nivmin[nod]=niv[nod];
    for(int i:muchii[nod])
    {
        if(!use[i])
        {
            st.push({nod,i});
            niv[i]=niv[nod]+1;
            dfs(i);
            if(nivmin[i]>=niv[nod])
                build(nod,i);
            nivmin[nod]=min(nivmin[nod],nivmin[i]);
        }
        else
        {
            nivmin[nod]=min(nivmin[nod],niv[i]);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    for(int i=1;i<=n;i++)
        if(!use[i])
            dfs(i);
    fout<<sol.size()<<'\n';
    for(auto i:sol)
    {
        for(int j:i)
            fout<<j<<' ';
        fout<<'\n';
    }
    return 0;
}
