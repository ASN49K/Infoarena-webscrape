#include<bits/stdc++.h>
using namespace std;
ifstream F("biconex.in");
ofstream G("biconex.out");
#define N 100001
vector<int> g[N];
char c[N];
unsigned short u,d[N],f[N];
int p,j,n,m,i,r,q[4*N];
void P(int i)
{
	c[i]=2,q[++p]=i;
	for(auto j:g[i])
        if(c[j]==1)
            P(j);
}
void E(int i)
{
	d[i]=f[i]=++u,c[i]=1;
	for(auto j:g[i])
        if(!c[j]) {
            if(E(j),f[i]>f[j])
                f[i]=f[j];
            if(d[i]<=f[j])
                c[i]=2,q[++p]=i,P(j),c[i]=1,q[++p]=0,++r;
        } else if(f[i]>d[j])
            f[i]=d[j];
}
int main()
{
	for(F>>n>>m;m--;F>>i>>j,g[i].push_back(j),g[j].push_back(i));
	for(E(1),G<<r<<'\n',--p;p;q[p]?G<<q[p]<<' ':G<<'\n',--p);
    return 0;
}
