#include<bits/stdc++.h>
#define int long long
using namespace std;
ifstream f("biconex.in");
ofstream g("biconex.out");

int n,m,dp[100005],niv[100005],cnt;
vector<int>v[100005],sol[100005];
stack<int>s;

void dfs_tree(int nod)
{
    dp[nod]=niv[nod];
    s.push(nod);
    for(auto it:v[nod])
    {
        if(niv[it]!=0)
            dp[nod]=min(dp[nod],niv[it]);
        else
        {
            niv[it]=niv[nod]+1;
            dfs_tree(it);
            dp[nod]=min(dp[it],dp[nod]);
            if(dp[it]>=niv[nod])
            {
                cnt++;
                while(s.top()!=it)
                {
                    sol[cnt].push_back(s.top());
                    s.pop();
                }
                sol[cnt].push_back(it);
                s.pop();
                sol[cnt].push_back(nod);
            }
        }
    }
}

signed main()
{
    int i,x,y;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(i=1;i<=n;i++)
    {
        if(niv[i]==0)
            niv[i]=1,dfs_tree(i);
    }
    g<<cnt<<'\n';
    for(i=1;i<=cnt;i++)
    {
        for(auto it:sol[i])
            g<<it<<" ";
        g<<'\n';
    }
    return 0;
}
