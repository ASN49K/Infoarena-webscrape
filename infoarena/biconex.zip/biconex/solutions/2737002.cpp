#include <bits/stdc++.h>
using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int N, M;

int low[100005], idx[100005], k;
stack <int> st;

vector <vector <int>> ans;

vector <int> v[100005];

void dfs(int node, int dad)
{
    idx[node] = low[node] = ++k;
    st.push(node);

    for(int i = 0; i < v[node].size(); i++)
        if(v[node][i] != dad)
    {
        if(idx[v[node][i]] != 0)
        {
            low[node] = min(low[node], idx[v[node][i]]);
            continue;
        }

        dfs(v[node][i], node);

        low[node] = min(low[node], low[v[node][i]]);

        if(low[v[node][i]] >= idx[node])///node e punct de articulatie, daca e mai mare strict e bridge
           {
                vector <int> aux;

                int naux;

                do
                {
                    naux = st.top();
                    st.pop();
                    aux.push_back(naux);
                }
                while(naux != v[node][i]);

                aux.push_back(node);

                ans.push_back(aux);
           }
    }
}

int main()
{
    fin >> N >> M;

    for(int i = 1; i <= M; i++)
    {
        int x, y;

        fin >> x >> y;

        v[x].push_back(y);
        v[y].push_back(x);
    }

    for(int i = 1; i <= N; i++)
        if(idx[i] == 0)
            dfs(i, 0);

    fout << ans.size() << '\n';

    for(int i = 0; i < ans.size(); i++)
    {
        for(int j = 0; j < ans[i].size(); j++)
            fout << ans[i][j] << " ";
        fout << '\n';
    }

    return 0;
}
