#include <bits/stdc++.h>
using namespace std;

ifstream fin("biconex.in");
ofstream fout("biconex.out");

int n, m, low[100005], lev[100005], t[100005];
bool v[100005];
vector<int> g[100005];
stack<pair<int, int> > stk;
vector<vector<int> > comp;

void add(int x, int y) {
    vector<int> c;
    int a, b;
    do {
        a = stk.top().first;
        b = stk.top().second;
        stk.pop();

        c.push_back(a);
        c.push_back(b);
    } while(!stk.empty() && (a != x || b != y));
    sort(c.begin(), c.end());
    comp.push_back(c);
}

void dfs(int x) {
    v[x] = true;
    lev[x] = low[x] = lev[t[x]]+1;
    for(auto next: g[x])
        if(!v[next]) {
            stk.push({x, next});
            t[next] = x;
            dfs(next);
            if(low[next] >= lev[x])
                add(x, next);
            low[x] = min(low[x], low[next]);
        } else if(next != t[x])
            low[x] = min(low[x], lev[next]);
}

int main() {
    fin >> n >> m;
    while(m--) {
        int u ,v;
        fin >>u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1);

    fout << comp.size() << '\n';
    for(auto c: comp) {
        for(int i = 0; i < c.size(); i++)
            if(i == 0 | c[i] != c[i-1])
                fout << c[i] << ' ';
        fout << '\n';
    }
}
