#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin( "biconex.in" );
ofstream fout( "biconex.out" );

const int MAXN = 100005;

vector<int> G[MAXN];
vector<int> stk;
bool viz[MAXN];
int lev[MAXN];
int bk[MAXN];

vector<int> bi[MAXN];
int ncbi;

void del( int u ) {
  while ( stk.back() != u ) {
    bi[ncbi].push_back( stk.back() );
    stk.pop_back();
  }
  bi[ncbi++].push_back(u);
}

void dfs( int u, int l ) {
  viz[u] = true;
  lev[u] = bk[u] = l;
  stk.push_back( u );
  for ( int i = 0; i < G[u].size(); ++i ) {
    int v = G[u][i];

    if ( !viz[v] ) {
      dfs(v, l + 1);

      bk[u] = min(bk[u], bk[v]);
      if ( bk[v] >= lev[u] ) {
        del(u);
      }
    } else {
      bk[u] = min(bk[u], lev[v]);
    }
  }
}

int main() {
  int n, m, u, v;

  fin >> n >> m;
  while ( m-- ) {
    fin >> u >> v;
    G[u].push_back(v);
    G[v].push_back(u);
  }
  dfs(1, 0);
  fout << ncbi << "\n";
  for ( int c = 0; c < ncbi; ++c ) {
    sort(bi[c].begin(), bi[c].end());
    for ( int i = 0; i < bi[c].size(); ++i ) {
      fout << bi[c][i] << " ";
    }
    fout << "\n";
  }
  fin.close();
  fout.close();
  return 0;
}
