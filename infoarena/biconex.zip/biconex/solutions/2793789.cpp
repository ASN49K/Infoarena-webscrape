#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring> 
 
class Graf
{
private:
    static constexpr int NMAX = 100009;
    const int N, M;
    std::vector<int> Adiacenta[NMAX];  // liste de adiacenta
 
public:
    Graf(int, int);
    void AdMuchie(int, int);
    void Bfs(int, int*);
    int Dfs();
    void Biconex(std::vector<std::vector<int>>&);
 
    static constexpr int getNMAX() { return Graf::NMAX; }

private:
    void Dfs_fHelper(int, bool*);
    void Biconex_fHelper(int, int, std::pair<int, int>*, int&, int*, int*, std::vector<std::vector<int>>&);
};
 
Graf::Graf(int n, int m)
    : N(n), M(m)
{
}
 
void Graf::AdMuchie(int ini, int fin)
{
    Adiacenta[ini].push_back(fin);
}
 
void Graf::Bfs(int S, int* nrArce)
{
    int coada[NMAX], st = 0, dr = 0;
 
    for (int i = 1; i <= N; ++i)
        nrArce[i] = -1;
    nrArce[S] = 0;
    coada[st] = S;
    while (st <= dr)
    {
        int curent = coada[st++];
        for (auto it = Adiacenta[curent].begin(); it != Adiacenta[curent].end(); ++it)
            if(nrArce[*it] == -1)
            {
                coada[++dr] = *it;
                nrArce[*it] = nrArce[curent] + 1;
            }
    }
}

int Graf::Dfs()
{
    bool vizitat[NMAX];
    int nrComp = 0;

    memset(vizitat, 0, NMAX * sizeof(bool));
    for (int i = 1; i <= N; ++i)
        if (!vizitat[i])
        {
            ++nrComp;
            Dfs_fHelper(i, vizitat);
        }

    return nrComp;
}

void Graf::Dfs_fHelper(int curent, bool* vizitat)
{
    vizitat[curent] = true;
    for (auto it = Adiacenta[curent].begin(); it != Adiacenta[curent].end(); ++it)
        if (!vizitat[*it])
            Dfs_fHelper(*it, vizitat);
}

void Graf::Biconex(std::vector<std::vector<int>>& compBic)
{
    std::pair<int, int> Stiva[NMAX * 2];
    int stVf = 0;
    int nivelInArbDFS[NMAX];  // folosit si ca vizitat[]
    int nivelMinVecini[NMAX];

    nivelInArbDFS[0] = 0;
    Biconex_fHelper(1, 0, Stiva, stVf, nivelInArbDFS, nivelMinVecini, compBic);
}

void Graf::Biconex_fHelper(int nod, int parinte, std::pair<int, int>* Stiva, int& stVf, int* nivelInArbDFS, int* nivelMinVecini, std::vector<std::vector<int>>& compBic)
{
    nivelInArbDFS[nod] = nivelInArbDFS[parinte] + 1;
    nivelMinVecini[nod] = NMAX;
    for (int& vecin : Adiacenta[nod])
    {
        if (nivelInArbDFS[vecin])  // daca e vizitat
        {
            if (nivelMinVecini[nod] > nivelInArbDFS[vecin] && vecin != parinte)
                nivelMinVecini[nod] = nivelInArbDFS[vecin];
        }
        else
        {
            Stiva[++stVf] = {nod, vecin};
            Biconex_fHelper(vecin, nod, Stiva, stVf, nivelInArbDFS, nivelMinVecini, compBic);

            if (nivelMinVecini[nod] > nivelMinVecini[vecin])
                nivelMinVecini[nod] = nivelMinVecini[vecin];
            
            if (nivelMinVecini[vecin] >= nivelInArbDFS[nod])
            {
                compBic.push_back({});
                while (Stiva[stVf].first != nod)
                    compBic.back().push_back(Stiva[stVf--].second);
                compBic.back().push_back(Stiva[stVf].second);  // muchia din 'nod', intreaga
                compBic.back().push_back(Stiva[stVf].first);   //
                --stVf;
            }
        }
    }
}

 
int main()
{   
    std::ifstream f("biconex.in");
    std::ofstream g("biconex.out");
    int N, M;
 
    f >> N >> M;
    Graf graf(N, M);
    for (int x, y, i = 0; i < M; ++i)
    {
        f >> x >> y;
        graf.AdMuchie(x, y);
        graf.AdMuchie(y, x);
    }

    std::vector<std::vector<int>> compBic;
    graf.Biconex(compBic);
 
    g << compBic.size() << '\n';
    for (auto& comp : compBic)
    {
        for (int& nod : comp)
            g << nod << ' ';
        g << '\n';
    }
    return 0;
}