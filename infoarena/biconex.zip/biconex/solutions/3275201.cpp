#include <iostream>
#include <fstream>
#include <vector>
#define DIM 100001

using namespace std;

ifstream fin ("biconex.in");
ofstream fout("biconex.out");

int n,m;
bool joint[DIM];
int st[DIM],vf;
int p,x,y,i,j;
struct punte
{
    int x;
    int y;
}pun[DIM/2+1];
int pct;
int k;
vector<int>L[DIM];
vector<int>ccb[DIM];
bool viz[DIM];
int niv[DIM];
int minlv[DIM];
int nrc;
void dfs(int x, int tata)
{
    st[++vf]=x;
    viz[x]=1;
    niv[x]=minlv[x]=niv[tata]+1;
    int fii=0;
    for(int i=0;i<L[x].size();i++)
    {
        int y=L[x][i];
        if(viz[y])
        {
            if(y!=tata) ///am muchie de intoarcere
                minlv[x]=min(minlv[x],niv[y]);
        }
        else
        {
            fii++;
            dfs(y,x);
            minlv[x]=min(minlv[x],minlv[y]);
            if(niv[x]<=minlv[y])
            {
                if(x!=1) ///punct de articulatie
                    joint[x]=1;
                nrc++; ///componente biconexe
                while(st[vf]!=y)
                {
                    ccb[nrc].push_back(st[vf]);
                    vf--;
                }
                ccb[nrc].push_back(y);
                vf--;
                ccb[nrc].push_back(x);
            }
            if(niv[x]<minlv[y]) ///x y punte
                pun[++pct]={x,y};
        }
    }
    if(x==1 && fii>=2)
        joint[x]=1;
}
int main()
{
    p=1;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    dfs(1,0);
    if(p==1)
    {
        fout<<nrc<<'\n';
        for(i=1;i<=nrc;i++)
        {
            fout<<ccb[i].size()<<" ";
            for(j=0;j<ccb[i].size();j++)
                fout<<ccb[i][j]<<" ";
            fout<<'\n';
        }
        return 0;
    }
    if(p==2)
    {
        int puncte=0;
        for(i=1;i<=n;i++)
            if(joint[i])
                puncte++;
        fout<<puncte<<'\n';
        for(i=1;i<=n;i++)
            if(joint[i])
                fout<<i<<" ";
        return 0;
    }
    fout<<pct<<'\n';
    for(i=1;i<=pct;i++)
        fout<<pun[i].x<<" "<<pun[i].y<<'\n';
    return 0;
}
