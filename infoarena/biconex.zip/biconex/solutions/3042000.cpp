#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define pii pair <int, int>

using namespace std;

string filename = "biconex";
#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 1e5;

vector <int> adj[NMAX + 1];

int nrComp = 0;
vector <int> comps[NMAX + 1];

int level[NMAX + 1];
bool viz[NMAX + 1];

int ll[NMAX + 1];

stack <int> S;

void dfs(int node, int parent){
    viz[node] = true;
    ll[node] = level[node] = level[parent] + 1;
    S.push(node);

    for(int vec : adj[node]){
        if(vec != parent){
            if(viz[vec]){
                ll[node] = min(ll[node], level[vec]);
            }else{
                dfs(vec, node);
                ll[node] = min(ll[node], ll[vec]);

                if(ll[vec] >= level[node]){
                    ++nrComp;
                    while(S.top() != node){
                        comps[nrComp].push_back(S.top());
                        S.pop();
                    }
                    comps[nrComp].push_back(node);
                }
            }
        }
    }
}

int main(){

    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b;
        fin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    dfs(1, 0);

    fout << nrComp << '\n';
    for(int i = 1; i <= nrComp; i++){
        for(int x : comps[i]){
            fout << x << ' ';
        }
        fout << '\n';
    }

    return 0;
}
