#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using pii = pair<int,int>;
#define pb push_back

ifstream fin("biconex.in");
ofstream fout("biconex.out");

const int NMAX = 1e5+3;

int n, k, niv[NMAX], low[NMAX];
stack<pii> stk; 
vector<int> e[NMAX];
vector<set<int>> comp;

void read(), dfs(int, int), addComp(int, int);

int main()
{
    read();
    dfs(1, 0);
    fout << k << '\n';
    for (int i = 0; i < k; i++, fout << '\n')
        for (auto it: comp[i]) 
            fout << it << ' ';

    return 0;
}

void read(){
    int m; fin >> n >> m;
    while (m--){
        int a, b; fin >> a >> b;
        e[a].pb(b); e[b].pb(a);
    }
}
void dfs(int nod, int t){
    niv[nod] = low[nod] = niv[t] + 1;
    for (auto it: e[nod]){
        if (it == t) continue;
        if (niv[it]) {
            low[nod] = min(low[nod], niv[it]);
            continue;
        }
        stk.push({nod, it});
        dfs(it, nod);
        low[nod] = min(low[nod], low[it]);
        if (low[it] >= niv[nod])
            addComp(nod, it);
    }
}
void addComp(int x, int y){
    comp.pb({});

    int xx, yy;
    do {
        tie(xx, yy) = stk.top(); stk.pop();
        comp[k].insert(xx); comp[k].insert(yy);
    } while (x != xx || y != yy);

    k++;
}
