#include<bits/stdc++.h>

using namespace std;

ifstream fin ("biconex.in");
ofstream fout ("biconex.out");

vector<int> lista_adiacenta[100001];
unordered_map<int,int> vizitat;
vector <set <int>> componente;
stack<pair<int, int>> stackCBC;
int low[100001]= {0};
int timp;

void biconex(int start, int tata)
{
    timp++;
    vizitat[start] = timp;
    low[start] = timp;
    for (int i=0; i<lista_adiacenta[start].size(); i++)
    {
        int conect=lista_adiacenta[start][i];
        //cout<<conect<<" "<<tata<<endl;
        if(conect!=tata)
        {
            if (vizitat[lista_adiacenta[start][i]]==0)
            {
                stackCBC.push({start, lista_adiacenta[start][i]});
                biconex(lista_adiacenta[start][i],start);
                low[start] = min(low[lista_adiacenta[start][i]],low[start]);
                if (low[lista_adiacenta[start][i]]>=vizitat[start])
                {
                    set<int> elem;
                    int elem1,elem2;
                    do
                    {
                        elem1 = stackCBC.top().first;
                        elem2 = stackCBC.top().second;
                        elem.insert(elem1);
                        elem.insert(elem2);
                        stackCBC.pop();
                    }
                    while (elem1 != start || elem2 != conect);
                    componente.push_back(elem);
                }
            }
            else
            {
                low[start] = min(vizitat[lista_adiacenta[start][i]],low[start]);
            }
        }
    }
}

int main()
{
    int n,m,x,y;
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);
    fin>>n>>m;

    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        lista_adiacenta[x].push_back(y);
        lista_adiacenta[y].push_back(x);
    }
    biconex(1,0);
    fout<< componente.size() <<'\n';

    for (auto cbc: componente)
    {
        set<int>::iterator it;
        for (it = cbc.begin(); it != cbc.end(); it++)
            fout << *it << " ";
        fout << "\n";
    }
    return 0;
}
