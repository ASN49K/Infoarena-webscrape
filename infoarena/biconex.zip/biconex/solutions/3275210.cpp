#include <fstream>
#include <stack>
#include <vector>
#define nmax (int)(1e5+5)
using namespace std;
ifstream cin("biconex.in");
ofstream cout("biconex.out");
int task,art,n,m,x,y,niv[nmax],minlv[nmax];
vector<int>v[nmax],aux;
vector<vector<int>>sol;
vector<pair<int,int>>punte;
stack<int>s;
bool viz[nmax],pct[nmax];
void dfs(int nod,int t){
    viz[nod]=1;
    s.push(nod);
    minlv[nod]=niv[nod]=niv[t]+1;
    int fii=0;
    for(auto i:v[nod]){
        if(!viz[i]){
            fii++;
            dfs(i,nod);
            minlv[nod]=min(minlv[nod],minlv[i]);
            if(minlv[i]>=niv[nod]){
                if(nod!=1)
                  pct[nod]=1;
                art++;
                aux.clear();
                while(s.top()!=i){
                    aux.push_back(s.top());
                    s.pop();
                }
                aux.push_back(i);
                s.pop();
                aux.push_back(nod);
                sol.push_back(aux);
            }
            if(minlv[i]>niv[nod])
                punte.push_back({nod,i});
        }else
          if(i!=t)
                minlv[nod]=min(minlv[nod],niv[i]);
    }
    if(nod==1&&fii>=2){
        pct[nod]=1;
        art++;
    }
}
int main()
{

    //cin>>task;
    task=1;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    dfs(1,0);
    if(task==1){
        cout<<sol.size()<<'\n';
        for(auto i:sol){
            for(auto j:i)
                cout<<j<<" ";
            cout<<'\n';
        }
    }else if(task==2){
        cout<<art<<'\n';
        for(int i=1;i<=n;i++)
            if(pct[i])
                cout<<i<<" ";
    }else{
        cout<<punte.size()<<'\n';
        for(auto i:punte)
            cout<<i.first<<" "<<i.second<<'\n';
    }
    return 0;
}
