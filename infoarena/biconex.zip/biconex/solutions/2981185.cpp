#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in ("biconex.in");
ofstream out ("biconex.out");

const int max_size = 1e5 + 1;

vector <int> mc[max_size];
vector <vector <int>> cbcx;
int viz[max_size], depth[max_size], lowlink[max_size];
stack <int> stk;

void dfs (int nod, int par)
{
    viz[nod] = 1;
    depth[nod] = depth[par] + 1;
    lowlink[nod] = depth[nod];
    stk.push(nod);
    for (auto f : mc[nod])
    {
        if (f == par)
            continue;
        if (viz[f])
        {
            lowlink[nod] = min(lowlink[nod], depth[f]);
        }
        else
        {
            dfs(f, nod);
            lowlink[nod] = min(lowlink[nod], lowlink[f]);
            if (depth[nod] <= lowlink[f])
            {
                vector <int> aux;
                while (!stk.empty() && stk.top() != f)
                {
                    aux.push_back(stk.top());
                    stk.pop();
                }
                aux.push_back(f);
                stk.pop();
                aux.push_back(nod);
                cbcx.push_back(aux);
            }
        }
    }
}

int main ()
{
    int n, m;
    in >> n >> m;
    while (m--)
    {
        int x, y;
        in >> x >> y;
        mc[x].push_back(y);
        mc[y].push_back(x);
    }
    dfs(1, 0);
    out << cbcx.size() << '\n';
    for (auto f : cbcx)
    {
        for (auto ff : f)
        {
            out << ff << " ";
        }
        out << '\n';
    }
    in.close();
    out.close();
    return 0;
}
