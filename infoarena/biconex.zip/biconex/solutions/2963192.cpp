#include <bits/stdc++.h>

using namespace std;

ifstream f("biconex.in");
ofstream g("biconex.out");

vector<vector<int> > comp;

stack<int> stk;

const int nmax=100002;
vector<int> adj[nmax];
bool vis[nmax];
int dep[nmax],ret[nmax];

void dfs(int nod, const int &par)
{
    ret[nod]=dep[nod]=dep[par]+1;
    vis[nod]=1;
    stk.push(nod);
    for(auto e:adj[nod]) if(e!=par)
    {
        if(vis[e])
        {
            ret[nod]=min(ret[nod],dep[e]);
            continue;
        }
        
        dfs(e,nod);
        ret[nod]=min(ret[nod],ret[e]);
        if(ret[e]>=dep[nod])
        {
            comp.push_back(vector<int>());
            while(stk.top()!=nod)
            {
                comp.back().push_back(stk.top());
                stk.pop();
            }
            comp.back().push_back(nod);
        }
    }
}

int n,m;

int main()
{
    f>>n>>m;
    int a,b;
    for(int i=0;i<m;i++)
    {
        f>>a>>b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    
    dfs(1,0);
    g<<comp.size()<<'\n';
    for(auto e:comp)
    {
        for(auto el:e)
        {
            g<<el<<' ';
        }
        g<<'\n';
    }
    return 0;
}