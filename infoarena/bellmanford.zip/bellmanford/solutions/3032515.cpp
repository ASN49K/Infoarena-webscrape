#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f ("bellmanford.in");
ofstream g ("bellmanford.out");
vector<pair<int,int>>adiacenta[1001];
bool viz[1001];
int dist[1001];
int capacitate[1001][1001];
int rasp_flux,rasp_cost;
int n,m,s,d;
int tati[1001];
queue<pair<int,int>>q;
void init()
{
    for(int i =1; i<=n; i++)
    {
        dist[i] = (1<<30)-1;
        tati[i] = i;
    }
}
void bellman()
{
    init();
    dist[1]=0;
    q.push({1,0});
    while(!q.empty())
    {
        int curent = q.front().first;
        int cost_curent = q.front().second;
        q.pop();
        for(auto x:adiacenta[curent])
        {
            int nod = x.first;
            int cost = x.second;
            if(dist[nod]>cost_curent+cost)
            {
                dist[nod]= cost_curent+cost;
                tati[nod]=curent;
                q.push({nod,cost_curent+cost});
            }
        }
    }
}
int main()
{
    f >> n>> m;
    for(int i = 1; i<=m; i++)
    {
        int x,y,c,cost;
        f >> x >> y>>cost;
        adiacenta[x].push_back({y,cost});
    }
    bellman();
    for(int i = 2;i<=n;i++)
    g << dist[i]<< " ";
}
