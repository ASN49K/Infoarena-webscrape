#include <bits/stdc++.h>

using namespace std;
vector<pair<int,int>>graph[50005];
int distanta[50005]; ///graphanta de la 1
int no0fNodes[50005];
bool isInQueue[50005];

void bellman_ford(int inceput, int n)
{
    for(int i=1; i<=n; i++)
        distanta[i]=1e9, isInQueue[i]=0;
    queue<int>q;
    distanta[inceput]=0;
    no0fNodes[inceput]=1;
    q.push(inceput);
    isInQueue[inceput]=1;

    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        isInQueue[nod]=0;
        if(no0fNodes[nod]>n)    ///ciclu infinit, graphantele tot scad
        {
            cout<<"Ciclu negativ!";
            exit(0); ///termina programul
        }
        for(auto x: graph[nod])
            if(distanta[x.first]>distanta[nod]+x.second)
            {
                distanta[x.first]=distanta[nod]+x.second;
                no0fNodes[x.first]=no0fNodes[nod]+1;
                if(!isInQueue[x.first])
                {
                    q.push(x.first);
                    isInQueue[x.first]=1;
                }
            }
    }
}
int main()
{
    ifstream cin("bellmanford.in");
    ofstream cout("bellmanford.out");
    int n,m,a,b,d;
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        cin>>a>>b>>d;
        graph[a].push_back({b,d});
    }
    int inceput=1;
    bellman_ford(inceput,n);
    for(int i=2; i<=n; i++)
        cout<<distanta[i]<<" ";
    return 0;
}
