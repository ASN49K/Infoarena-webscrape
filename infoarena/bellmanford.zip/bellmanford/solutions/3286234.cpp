﻿#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000
#define MOD 1000000007
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
queue<int>q;
vector<pair<int, int>>l[50005];
int n, m,x,y,c;
int cnt[50005],dist[50005],viz[50005],vf;
void bf()
{
	for (int i = 2; i <= n; i++)
		dist[i] = 2e9;
	q.push(1);
	
		while (!q.empty() && !vf)
		{
			int curr = q.front();
			q.pop();
			viz[curr] = 0;
			for(auto it:l[curr])
				if (dist[it.first] > dist[curr] + it.second)
				{
					if (cnt[it.first] > n)
						vf = 1;
					dist[it.first] = dist[curr] + it.second;
					if (!viz[it.first])
					{
						viz[it.first] = 1;
						cnt[it.first]++;
						q.push(it.first);
					}
				}

		}
}
int main()
{
	fin >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		fin >> x >> y >> c;
		l[x].push_back({ y,c });
	}
	bf();
	if (vf)
	{
		fout << "Ciclu negativ!\n";
	}
	else
		for (int i = 2; i <= n; i++)
			fout << dist[i] << " ";
}
	



