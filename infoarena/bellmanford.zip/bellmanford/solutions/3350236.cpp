#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
vector<pair<int,int>>adj[50005];
int d[50005];
int k[50005];
queue<int>q;
int main()
{
    for(int i=2;i<=50000;i++){
        d[i]=1e9;
    }
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int x,y,c;
        cin>>x>>y>>c;
        adj[x].push_back({y,c});
    }
    q.push(1);
    bool ok=0;
    while(!q.empty()){
        int i=q.front();
        k[i]++;
        if(k[i]==m){
            ok=1;
            break;
        }
        q.pop();
        for(auto e:adj[i]){
            int j=e.first,c=e.second;
            if(d[i]!=1e9&&d[j]>d[i]+c){
                d[j]=d[i]+c;
                q.push(j);
            }
        }
    }
    if(ok==1) cout<<"Ciclu negativ!";
    else for(int i=2;i<=n;i++) cout<<d[i]<<" ";
    return 0;
}
