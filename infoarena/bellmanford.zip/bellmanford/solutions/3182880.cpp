#pragma GCC("Ofast,inline,unroll-loops")
#include <bits/stdc++.h>

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
struct edge{
    int u,v,c;
    edge(int _u, int _v, int _c){
        u = _u;
        v = _v;
        c = _c;
    }
};
int d[50005];
int n;
bool cn;
vector <edge> edges;
void bellman_ford(){
    d[1] = 0;
    for(int i = 1; i < n; i++){
        bool ok = 0;
        for(auto e : edges){
            if(d[e.u] + e.c < d[e.v]){
                d[e.v] = d[e.u] + e.c;
                ok = 1;
            }
        }
        if(!ok) return;
    }
    for(auto e : edges){
        if(d[e.u] + e.c < d[e.v]) cn = 1;
    }
}
int main()
{
    int m,i,u,v,c;
    fin >> n >> m;
    memset(d,0x3f,sizeof d);
    for(i = 1; i <= m; i++){
        fin >> u >> v >> c;
        edges.push_back(edge(u,v,c));
    }
    bellman_ford();
    if(cn) fout << "Ciclu negativ!";
    else{
        for(i = 2; i <= n; i++) fout << d[i] << " ";
    }
    return 0;
}
