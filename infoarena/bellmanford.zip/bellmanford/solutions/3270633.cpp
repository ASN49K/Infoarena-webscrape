#include <bits/stdc++.h>
using namespace std;
ifstream in("bellmanford.in");
ofstream out("bellmanford.out");
vector <pair <int, int> > v[50005];
int viz[50005];
queue <pair <int, int> > q;
int dist[50005];
int main()
{
    int n, m;
    in >> n >> m;
    for(int i = 1; i <= 50000; i ++)
        dist[i] = (1 << 30);
    for(int i = 1; i <= m; i ++)
    {
        int a, b, c;
        in >> a >> b >> c;
        v[a].push_back(make_pair(b, c));
    }
    q.push(make_pair(1, 0));
    dist[1] = 0;
    while(!q.empty())
    {
        pair <int, int> x = q.front();
        q.pop();
        if(viz[x.first] >= n)
        {
            out << "Ciclu negativ!";
            return 0;
        }
        if(x.second > dist[x.first])
            continue;
        for(int i = 0; i < v[x.first].size(); i ++)
        {
            if(dist[v[x.first][i].first] > dist[x.first] + v[x.first][i].second)
            {
                viz[v[x.first][i].first] ++;
                dist[v[x.first][i].first] = dist[x.first] + v[x.first][i].second;
                q.push(v[x.first][i]);
            }
        }
    }
    for(int i = 2; i <= n; i ++)
    {
        if(dist[i] == (1 << 30))
            out << "0 ";
        else
            out << dist[i] << " ";
    }
    return 0;
}
