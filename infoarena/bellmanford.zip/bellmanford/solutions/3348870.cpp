#include <fstream>
#include <vector>
#include <queue>
#define inf 1e9
#define nmax 50001
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
int n,m,x,y,c,dp[nmax],viz[nmax];
bool in[nmax];
vector<pair<int,int>>v[nmax];
queue<int>q;
void bell(){
    for(int i=2;i<=n;i++)
        dp[i]=inf;
    viz[1]=1;
    q.push(1);
    while(!q.empty()){
        int nod=q.front();
        q.pop();
        in[nod]=0;
        for(auto i:v[nod])
            if(dp[i.first]>dp[nod]+i.second){
                dp[i.first]=dp[nod]+i.second;
                viz[i.first]++;
                if(viz[i.first]>=n+1){
                    cout<<"Ciclu negativ!";
                    return ;
                }
                if(!in[i.first])
                    q.push(i.first),in[i.first]=1;
            }
    }
    for(int i=2;i<=n;i++)
        cout<<dp[i]<<" ";
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y>>c;
        v[x].push_back({y,c});
    }
    bell();
    return 0;
}
