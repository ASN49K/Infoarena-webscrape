#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF (1<<30)
using namespace std;
ifstream  fin("bellmanford.in");
ofstream fout("bellmanford.out");
int N,M;
queue<int>q;
vector<int> nrmodif(NMAX,0),cost(NMAX,INF);
vector<pair<int,int>>graph[NMAX];

void citire()
{
    fin>>N>>M;

    int x,y,c;
    for(int i=1; i<=M; i++)
    {
        fin>>x>>y>>c;
        graph[x].push_back({y,c});
    }
}

int main()
{
    citire();

    cost[1]=0;
    q.push(1);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();

        for(int i=0; i<graph[nod].size(); i++)
        {
            int next_nod=graph[nod][i].first;
            if(cost[next_nod]>cost[nod]+graph[nod][i].second)
            {
                cost[next_nod]=cost[nod]+graph[nod][i].second;
                q.push(next_nod);
                nrmodif[next_nod]++;

                if(nrmodif[next_nod]>N)
                {
                    fout<< "!Ciclu negativ!" << "\n";
                    return 0;
                }
            }
        }
    }

    for(int i=2; i<=N; i++)
    {
        fout<< cost[i] << " ";
    }
    fout<< "\n";

    return 0;
}
