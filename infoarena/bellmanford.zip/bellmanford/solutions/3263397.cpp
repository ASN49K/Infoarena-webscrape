#include <bits/stdc++.h>
#define oo 1000000001
using namespace std;

/**
viz[i] = 1, daca nodul i se afla in coada
         0, daca nu se afla in coada
cnt[i] = numara de cate ori am pus nodul i in coada.
         daca avem cnt[i] > n, avem ciclu de cost negativ
*/
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m, viz[50002], d[50002], cnt[50002];
///          nod  cost
vector< pair<int, int> > G[50002];
queue <int> q;

void Citire()
{
    int i, j, c;
    fin >> n >> m;
    for (int p = 1; p <= m; p++)
    {
        fin >> i >> j >> c;
        G[i].push_back({j, c});
    }
}
/// O(n * m), dar in practica se comporta mai bine
void BellmanFord(int s)
{
    int i, k;
    for (i = 1; i <= n; i++)
        d[i] = oo;
    d[s] = 0;
    q.push(s);
    viz[s] = 1; cnt[s] = 1;
    while (!q.empty())
    {
        k = q.front();
        q.pop();
        viz[k] = 0;
        for (auto e : G[k])
        {
            i = e.first;
            if (d[i] > d[k] + e.second)
            {
                d[i] = d[k] + e.second;
                if (viz[i] == 0)
                {
                    q.push(i);
                    cnt[i]++;
                    viz[i] = 1;
                    if (cnt[i] > n)
                    {
                        fout << "Ciclu negativ!\n";
                        fout.close();
                        exit(0);
                    }
                }
            }
        }
    }
}

void Afis()
{
    for (int i = 2; i <= n; i++)
        if (d[i] == oo) fout << "0 ";
        else fout << d[i] << " ";
}

int main()
{
    Citire();
    BellmanFord(1);
    Afis();
    return 0;
}
