#include <fstream>
#include <vector>

#define NMAX 50000

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct Muchie{
    int from, to, cost;
};

const int INF = 2e9;

int n, m;
int d[NMAX];
vector < Muchie > mc;

bool Bellman_Ford(int s) {
    for (int i = 1; i <= n; i++)
        d[i] = INF;
    d[s] = 0;
    for (int i = 1; i <= n - 1; i++)
        for (int j = 0; j < mc.size(); j++) {
            int nc = mc[j].from;
            int nv = mc[j].to;
            int cst = mc[j].cost;
            if (d[nc] + cst < d[nv])
                d[nv] = d[nc] + cst;
        }
    for (int i = 1; i <= n - 1; i++)
        for (int j = 0; j < mc.size(); j++) {
            int nc = mc[j].from;
            int nv = mc[j].to;
            int cst = mc[j].cost;
            if (d[nc] + cst < d[nv])
                return false;
        }
    return true;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        mc.push_back({x, y, c});
    }
    if (!Bellman_Ford(1))
        fout << "Ciclu negativ!";
    else {
        for (int i = 2; i <= n; i++)
            fout << d[i] << ' ';
    }
    return 0;
}
