#include <bits/stdc++.h>

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m, x, y, val;
vector< pair<int, int> >v[50005];
queue <int> Q;
vector < int > d, viz;

void READ(void)
{
    fin >> n >> m;

    for(int i = 1; i <= m; i++)
    {
        fin >> x >> y >> val;
        v[x].push_back({y,val});
    }
}

bool bellmanford(int s)
{
    d.resize(n + 1, INT_MAX);
    viz.resize(n + 1, 0);

    d[s] = 0;
    Q.push(s);

    while(!Q.empty())
    {
        int node = Q.front();
        viz[node]++;

        if(viz[node] >= n)
            return false;

        Q.pop();

        for(auto e : v[node])
        {
            int neighbor = e.first;
            int weight = e.second;

            if(d[node] + weight < d[neighbor])
            {
                d[neighbor] = d[node] + weight;
                Q.push(neighbor);
            }
        }
    }
    return true;
}
int main()
{
    READ();

    if(bellmanford(1))
    {
        for(int i = 2; i <= n; i++)
            fout << d[i] << " ";
    }
    else
        fout << "Ciclu negativ!";



    return 0;
}
