#include <fstream>
#include <bitset>
#include <cstdlib>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int n,m;
vector<int>viz,d,inq;
vector<vector<pair<int,int>>>g;

void citire()
{
    cin>>n>>m;
    g.resize(n+1);
    inq.resize(n+1,0);
    d.resize(n+1,INT_MAX);
    viz.resize(n+1,0);
    int x,y,c;
    for(int i=0; i<m; i++)
    {
        cin>>x>>y>>c;
        g[x].push_back({c,y});
    }
}
void bellmanford()
{
    queue<int>q;
    q.push(1);
    d[1]=0;
    inq[1]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        viz[nod]++;
        if(viz[nod]>=n)
            {
                cout<<"Ciclu negativ!";
                exit(0);
            }
        for(auto i:g[nod])
        {
            if(d[nod]!=INT_MAX && d[i.second]>d[nod]+i.first)
            {
                d[i.second]=d[nod]+i.first;
                if(!inq[i.second])
                {
                    inq[i.second]=1;
                    q.push(i.second);
                }
            }
        }
        inq[nod]=0;
    }
}
void afisare()
{
    for(int i=2;i<=n;i++)
        cout<<d[i]<<' ';
}
int main()
{
    citire();
    bellmanford();
    afisare();
    return 0;
}
