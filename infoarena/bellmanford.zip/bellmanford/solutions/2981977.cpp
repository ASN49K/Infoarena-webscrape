#include <fstream>
#define dim 50001
#include <vector>
#include <deque>
#define inf 500000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct muchie{
    int x, cost;
};

vector <muchie> l[dim];
deque <int> q;
int d[dim], iq[dim], viz[dim];

int main()
{
    int n, m, i, vecin, nod, cost, x, y, c;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        l[x].push_back({y, c});
    }
    d[1]=0;
    for(i=2;i<=n;i++)
    {
        d[i]=inf;
    }
    iq[1]++;
    viz[1]=1;
    q.push_back(1);
    while(q.empty()==0)
    {
        nod=q.front();
        q.pop_front();
        for(i=0;i<l[nod].size();i++)
        {
            vecin=l[nod][i].x;
            cost=l[nod][i].cost;
            if(d[vecin]>d[nod]+cost)
            {
                d[vecin]=d[nod]+cost;
                iq[vecin]++;
                if(iq[vecin]>n)
                {
                    fout<<"Ciclu negativ!";
                    return 0;
                }
                if(viz[vecin]==0)
                {
                    q.push_back(vecin);
                    viz[vecin]=1;
                }
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        fout<<d[i]<<" ";
    }
}
