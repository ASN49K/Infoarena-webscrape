#include <bits/stdc++.h>
using namespace std;
ifstream f("bellmanford.in");
ofstream g("bellmanford.out");
struct elem
{
    int nod, cost;
};
vector <elem> v[50009];
int viz[50009];
int sol[50009];
queue <int> q;
signed main ()
{
    int n, m;
    f >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x, y, z;
        f >> x >> y >> z;
        v[x].push_back({y,z});
    }
    for (int i=1; i<=n; i++)
        sol[i]=1e9;
    sol[1]=0;
    q.push(1);
    while (!q.empty())
    {
        int x=q.front();
        q.pop();
        viz[x]++;
        if (viz[x]>n)
        {
            g << "Ciclu negativ!";
            exit(0);
        }
        for (auto y:v[x])
        {
            if (sol[x]+y.cost<sol[y.nod])
            {
                q.push(y.nod);
                sol[y.nod]=sol[x]+y.cost;
            }
        }
    }
    for (int i=2; i<=n; i++)
        g << sol[i] << ' ';
}
