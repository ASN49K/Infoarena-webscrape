#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>

#define vt vector
#define pb push_back
#define sz(x) (int)(x).size()
#define all(x) (x).begin(), (x).end()
#define pii pair <int, int>

#define fr first 
#define sc second

using namespace std;

string filename = "bellmanford";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

////////////////////////////////////////////////////////////

const int NMAX = 5e4;
const int INF = 1e9;

int n, m;
vt <pii> adj[NMAX + 1];
int f[NMAX + 1];
int dist[NMAX + 1];

queue <int> Q;
bool inQ[NMAX + 1];

void BF(int source){
    for(int i = 1; i <= n; i++){
        dist[i] = INF;
    }
    dist[source] = 0;
    Q.push(source);
    inQ[source] = true;

    while(!Q.empty()){
        int node = Q.front();
        Q.pop();
        inQ[node] = false;

        if(++f[node] > n){
            fout << "Ciclu negativ!\n";
            exit(0);
        }

        for(pii vec : adj[node]){
            if(vec.sc + dist[node] < dist[vec.fr]){
                dist[vec.fr] = vec.sc + dist[node];
                if(!inQ[vec.fr]){
                    Q.push(vec.fr);
                    inQ[vec.fr] = true;
                }
            }
        }
    }
}

void solve(){
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b, c;
        fin >> a >> b >> c;
        adj[a].pb({b, c});
    }

    BF(1);

    for(int i = 2; i <= n; i++){
        fout << dist[i] << ' ';
    }   
    fout << '\n';
}

int main(){

    int T;
    //fin >> T;

    T = 1;

    while(T--){
        solve();
    }

    return 0;
}