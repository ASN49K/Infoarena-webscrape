#include <bits/stdc++.h>

using namespace std;

ifstream fin ("bellmanford.in");
ofstream fout ("bellmanford.out");

const int NMAX=5e4+5;
const int INF=2e9;

vector<pair<int,int>>v[NMAX];
int dist[NMAX];
int viz[NMAX];
bool flag;
int n, m, cnt;

queue<pair<int,int>>q;

void bellman(int p)
{
    dist[p]=0;
    q.push(make_pair(0,1));
    while(!q.empty())
    {
        pair<int,int>p=q.front();
        q.pop();
        for(auto i:v[p.second])
        {
            if(dist[i.first]>dist[p.second]+i.second)
            {
                dist[i.first]=dist[p.second]+i.second;
                q.push(make_pair(-dist[i.first],i.first));
                viz[i.first]++;
                //cout << i.first << " ";
                if(cnt>=m*(1+log2(n)))
                {
                    //cout << v[i.first].size() << " ";
                    flag=true;
                    return ;
                }
                cnt++;
            }
        }
    }
}

int main()
{
    int i,j,x,y,c;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        v[x].push_back(make_pair(y,c));
    }
    for(i=1;i<=n;i++)
        dist[i]=INF;
    bellman(1);
  //  cout << cnt;
    if(flag)
        fout<<"Ciclu negativ!\n";
    else
    {
        for(i=2;i<=n;i++)
            fout<<dist[i]<<" ";
    }
    return 0;
}