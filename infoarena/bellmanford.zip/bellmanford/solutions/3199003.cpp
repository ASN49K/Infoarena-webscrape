#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF 1000000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m, start=1, x, y, cost;
int cmin[NMAX];
int nr[NMAX];
bool circuitneg=0;
queue<int> C;
struct arc
{
 int vf;
 int c;
};
vector<arc> G[NMAX];
int main()
{
 int i;
 arc a;
 fin>>n>>m;
 for(i=0;i<m;i++)
    {
     fin>>x>>y>>cost;
     a.vf=y;
     a.c=cost;
     G[x].push_back(a);
    }
 for(i=1;i<=n;i++)
     cmin[i]=INF;
 cmin[start]=0;
 C.push(start);
 while(!C.empty() && !circuitneg)
      {
       x=C.front();
       C.pop();
       for(i=0;i<G[x].size();i++)
          {
           y=G[x][i].vf;
           cost=G[x][i].c;
           if(cmin[y]>cmin[x]+cost)
             {
              cmin[y]=cmin[x]+cost;
              nr[y]++;
              if(nr[y]==n)
                 circuitneg=1;
                 else
                 C.push(y);
             }
          }
      }
 if(circuitneg)
    fout<<"Ciclu negativ!";
    else
    {
     for(i=2;i<=n;i++)
         fout<<cmin[i]<<" ";

    }

    return 0;
}
