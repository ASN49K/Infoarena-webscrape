#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF 1000000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
struct arc
{
    ///extremitatea finala a arcului si costul sau
    int vf;
    int c;
};
vector<arc> G[NMAX];
int n, m, start=1;
int cmin[NMAX];
int nr[NMAX];
bool circuitneg=0;
queue<int> C;
int main()
{
    int i, x, y, cost;
    arc a;
    ///citire
    fin>>n>>m;
    for(i=0; i<m; i++)
    {
        fin>>x>>y>>cost; ///exista arc de la x la y de cost c
        a.vf=y;
        a.c=cost;
        ///inserez arcul a in lista de adiacenta a lui x
        G[x].push_back(a);
    }
    ///initializare
    for(i=1; i<=n; i++)
        cmin[i]=INF;
    cmin[start]=0;
    C.push(start);
    while(!C.empty() && !circuitneg)
    {
        x=C.front();
        C.pop();
        ///parcurg lista de adiacenta a lui x
        for(i=0; i<G[x].size(); i++)
        {
            y=G[x][i].vf;
            cost=G[x][i].c;
            if(cmin[y]>cmin[x]+cost)
            {
                cmin[y]=cmin[x]+cost;
                nr[y]++;
                if(nr[y]==n)
                    circuitneg=1;
                else
                    C.push(y);
            }
        }
    }
    if(circuitneg)
        fout<<"Ciclu negativ!";
    else
    {
        for(i=2; i<=n; i++)
            fout<<cmin[i]<<' ';
    }
    return 0;
}
