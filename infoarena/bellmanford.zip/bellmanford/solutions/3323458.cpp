#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int INF = INT_MAX;

int main() {
    ifstream fin("bellmanford.in");
    ofstream fout("bellmanford.out");
    
    int n, m;
    fin >> n >> m;

    vector<vector<pair<int, int>>> graf(n + 1);

    for (int i = 0; i < m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        graf[x].push_back({y, c});
    }

    vector<int> dist(n + 1, INF);
    vector<int> cnt(n + 1, 0);
    vector<bool> inCoada(n + 1, false);
    
    queue<int> q;

    dist[1] = 0;
    q.push(1);
    inCoada[1] = true;
    cnt[1] = 1;
    
    bool cicluNegativ = false;
    
    while (!q.empty() && !cicluNegativ) {
        int nod = q.front();
        q.pop();
        inCoada[nod] = false;
        
        // vf toti vecinii
        for (int i = 0; i < graf[nod].size(); i++) {
            int vecin = graf[nod][i].first;
            int cost = graf[nod][i].second;
            
            // drum mai scurt catre vecin
            if (dist[nod] != INF && dist[nod] + cost < dist[vecin]) {
                dist[vecin] = dist[nod] + cost;
                
                // adaug vecinul
                if (!inCoada[vecin]) {
                    q.push(vecin);
                    inCoada[vecin] = true;
                    cnt[vecin]++;

                    if (cnt[vecin] > n) {
                        cicluNegativ = true;
                        break;
                    }
                }
            }
        }
    }
   
    if (cicluNegativ) {
        fout << "Ciclu negativ!\n";
    } else {
        for (int i = 2; i <= n; i++) {
            fout << dist[i];
            if (i < n) {
                fout << " ";
            }
        }
        fout << "\n";
    }
    
    fin.close();
    fout.close();
    
    return 0;
}