#include <fstream>
#include <vector>
#include <queue>
#define nmax 50002
#define INF 260000000
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
int n,m,x,y,c,ciclu[nmax],d[nmax];
bool viz[nmax];
struct arc{
int nod,cost;
};
vector<arc>v[nmax];
queue<int>q;
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y>>c;
        v[x].push_back({y,c});
    }
    for(int i=1;i<=n;i++)
        d[i]=INF;
    d[1]=0;
    viz[1]=1;
    ciclu[1]=1;
    q.push(1);
    while(!q.empty()){
        int k=q.front();
        viz[k]=0;
        q.pop();
        for(auto i:v[k])
            if(d[k]+i.cost<d[i.nod]){
                d[i.nod]=d[k]+i.cost;
                ciclu[i.nod]++;
                if(!viz[i.nod]){
                    q.push(i.nod);
                    viz[i.nod]=1;
                }
                if(ciclu[i.nod]==n){
                    cout<<"Ciclu negativ!";
                    return 0;
                }
            }
    }
    for(int i=2;i<=n;i++)
        cout<<d[i]<<" ";
    return 0;
}
