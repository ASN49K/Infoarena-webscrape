#include <bits/stdc++.h>

using namespace std;

ifstream f("bellmanford.in");
ofstream g("bellmanford.out");

int n , m , nr;

vector < pair < int , int > > v[100005];

queue < int > q;

bool used[100005];

int best[1000005];

const int inf = 2e9;

void bellmanford(int start)
{
    q . push(start);
    used[start] = 1;

    while(!q . empty())
    {
        int nod = q . front();
        q . pop();
        used[nod] = 0;

        for( int i = 0 ; i < v[nod] . size() ; i++)
        {
            int vecin = v[nod][i] . first;
            int cost = v[nod][i] . second;
            if(best[nod] + cost < best[vecin])
            {
                best[vecin] = best[nod] + cost;
                if(!used[vecin])
                {
                    q . push(vecin);
                    used[vecin] = 1;
                }
            }
        }
    }
}
int main()
{
    f >> n >> m;

    for( int i = 1 ; i <= m ; i++)
    {
        int x , y , c;

        f >> x >> y >> c;
        v[x] . push_back(make_pair(y , c));
    }

    for( int i = 2 ; i <= n ; i++)
    {
        best[i] = inf;
    }

    best[1] = 0;

    bellmanford(1);

    for( int i = 2 ; i <= n ; i++)
    {
        if( best[i] < 0)
            nr++;
    }
    if (nr == n - 1)
        g << "Ciclu negativ";
    else
    {
        for (int i = 2 ; i <= n ; i++)
            g << best[i] << " ";
    }
    return 0;
}
