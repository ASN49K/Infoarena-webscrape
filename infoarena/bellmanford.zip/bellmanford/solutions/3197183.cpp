#include <bits/stdc++.h>
#define pii pair<int, int>
#define INF 0x3F3F3F
#define MAX 50002
using namespace std;
using pii = pair<int, int>;

const int NMAX = 5e4+2;
int n,m,x,y,iq[MAX],dist[MAX],c;
vector<pii> v[MAX];

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        fin >> x >> y >> c;
        v[x].push_back({y, c});
    }
    deque<int> q;
    q.push_back(1);
    memset(dist, INF, sizeof(dist));
    vf[1] = 1;
    dist[1] = 0;
    while(!q.empty()){
        int nod = q.front();
        q.pop_front();
        for(auto [vecin, cost]: v[nod]){
            if(d[vecin] > d[nod]+cost){
                d[vecin] = d[nod]+cost;
                vf[vecin]++;
                if(vf[vecin] > n){
                    fout << "Ciclu negativ!\n";
                    return 0;
                }
                q.push_back(vecin);
            }
        }
    }
    for(int i = 2; i <= n; i++){
        fout << dist[i] << " ";
    }
    return 0;
}
