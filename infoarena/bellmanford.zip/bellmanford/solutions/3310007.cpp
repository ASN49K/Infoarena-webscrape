#include <bits/stdc++.h>

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
const int maxn=50005,inf=2e9+1;
vector<pair<int,int> > graf[maxn];
int dist[maxn];
bool relax=true;
vector<pair<pair<int,int>,int> > edges;
int n,m;
void bellmanford()
{
    int i,j,x,y,cost;
    for(i=1;i<=n && relax==true;++i)
    {
        relax=false;
        for(auto e:edges)
        {
            x=e.first.first;
            y=e.first.second;
            cost=e.second;
            if(dist[y]>dist[x]+cost)
            {
                dist[y]=dist[x]+cost;
                relax=true;
            }
        }
    }
}
int main()
{
    cin>>n>>m;
    int i,x,y,c;
    for(i=1;i<=m;++i)
    {
        cin>>x>>y>>c;
        graf[x].push_back({y,c});
        edges.push_back({{x,y},c});
    }
    for(i=2;i<=n;++i)
        dist[i]=inf;
    bellmanford();
    if(relax==true)
        ///negativ
    return 0;
}
