#include <fstream>
#include <vector>
#include <queue>
#define INF 1e9
#define NMAX 50005
using namespace std;
ifstream cin ("bellmanford.in");
ofstream cout ("bellmanford.out");

struct arc{int vf, cost;};

vector<arc>g[NMAX];
queue<int>q;

int n,m,start=1,c1,c2,val;
int dist[NMAX];
int nr[NMAX];
bool circuitneg=0;
int main()
{
    cin>>n>>m;
    for (int i=1; i<=m; i++)
    {
        cin>>c1>>c2>>val;
        g[c1].push_back({c2,val});
    }
    for (int i=1; i<=n; i++)
        dist[i]=INF;

    dist[start]=0;
    q.push(start);

    while (!q.empty() && !circuitneg)
    {
        int nod=q.front();
        q.pop();

        for (int i=0; i<g[nod].size(); i++)
        {
            int vecin=g[nod][i].vf;
            int costul=g[nod][i].cost;

            if (dist[vecin]>dist[nod]+costul)
            {
                dist[vecin]=dist[nod]+costul;
                nr[vecin]++;

                if (nr[vecin]==n)
                    circuitneg=1;
                else
                    q.push(vecin);
            }
        }
    }
    if (circuitneg==1)
        cout<<"Ciclu negativ!";
    else
    {
    for (int i=2;i<=n;i++)
        cout<<dist[i]<<' ';
    }
    return 0;
}
