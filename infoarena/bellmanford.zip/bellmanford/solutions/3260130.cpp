#include <bits/stdc++.h>
#define MOD 90000001
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;++i)
    {
        fin>>x>>y>>c;
        v[x].push_back({y,c});
    }

    q.push_back(1);
    while(i<=(n-1)*m && !q.empty())
    {
        x=q.front();
        q.pop_front();
        use[x]=0;
        for(auto i:v[x])
            if(dist[i.first]>i.second+dist[x])
            {
                dist[i.first]=i.second+dist[y];
                if(use[i.first]==0)
                {
                    use[i.first]=1;
                    q.push_back(i.first);
                }
            }
    }




    return 0;
}
