#include <fstream>
#include <queue>
#define NMAX 50002
#define INF 1e9

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n,m;
struct varf{int x,c;};
vector<varf> G[NMAX];
int nr[NMAX];
int start=1;

int cmin[NMAX];
bool existaciclu=0;
queue<int> C;

int main()
{
    int i,x,y,c;
    fin>>n>>m;
    for(i=1; i<=m; i++)
        {
         fin>>x>>y>>c;
         G[x].push_back({y,c});
        }

    for(i=1; i<=n; i++)
        cmin[i]=INF;
    cmin[start]=0;
    C.push(start);
    while(!C.empty() && !existaciclu)
        {
           x=C.front();
           C.pop();
           for(i=0; i<G[x].size(); i++)
                if(cmin[G[x][i].x]>cmin[x]+G[x][i].c)
                    {
                     cmin[G[x][i].x]=cmin[x]+G[x][i].c;
                     nr[G[x][i].x]++;
                     if(nr[G[x][i].x]==n) {existaciclu=1; break;}
                     C.push(G[x][i].x);
                    }
        }
    if(existaciclu) fout<<"Ciclu negativ!";
        else
        {
            for(i=2; i<=n; i++)
                fout<<cmin[i]<<' ';
        }
    return 0;
}
