#include <fstream>
#include <climits>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
//dijkstra
int n,m,d[50001],ating[50001];
bool viz[50001];
struct mch{
    int x,c;
};
vector<mch>v[50001];
queue<int>q;

int main()
{
    fin>>n>>m;
    int x,y,c;
    for(int i=1;i<=m;i++){
        fin>>x>>y>>c;
        v[x].push_back({y,c});
    }
    for(int i=2;i<=n;i++)
        d[i]=INT_MAX;
   q.push(1);
   viz[1]=1;
   ating[1]=1;
   while(!q.empty()){
        int nod=q.front();
        q.pop();
        viz[nod]=0;
        for(auto i:v[nod]){
            int k=i.x;
            int cost=i.c;
            if(d[k]>d[nod]+cost){
                d[k]=d[nod]+cost;
                if(viz[k]==0){
                    q.push(k);
                    viz[k]=1;
                }
            }
            ating[k]++;
            if(ating[k]==n){
                fout<<"Ciclu negativ!"<<"\n";
                return 0;
            }
        }
   }
   for(int i=2;i<=n;i++)
    fout<<d[i]<<" ";
    return 0;
}
