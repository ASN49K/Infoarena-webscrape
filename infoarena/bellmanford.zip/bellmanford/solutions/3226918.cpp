#include <algorithm>
#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <map>
#include <set>

#include <iomanip>
#include <cassert>

#include <random>
#include <chrono>

// #pragma GCC optimize("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

using ull = unsigned long long;
using ll = long long;

//#define int __int128
#define int ll
#define pii pair <int, int>
#define all(a) (a).begin(), (a).end()
#define fr first
#define sc second
#define pb push_back
#define lb lower_bound
#define ub upper_bound

#define vt vector
#define FOR(a, b) for(int i = (a); i <= (b); i++)
#define FORr(a, b) for(int i = (a); i >= (b); i--)
#define sz(x) (int)(x).size()

#define YES cout << "YES\n"
#define NO cout << "NO\n"

using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int rangerng(int l, int r){
    return uniform_int_distribution<>(l, r)(rng);
}

string filename = "bellmanford";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

////////////////////////////////////////////////////////////////////////////////////

const int NMAX = 5e4;
const int INF = 1e18;

int n, m;
vt <pii> adj[NMAX + 1];

int f[NMAX + 1];
int d[NMAX + 1];

bool inQ[NMAX + 1];

void BF(){
    for(int i = 1; i <= n; i++){
        d[i] = INF;
    }
    queue <int> Q;
    Q.push(1);
    inQ[1] = 1;
    d[1] = 0;

    while(!Q.empty()){
        int node = Q.front();
        Q.pop();
        inQ[node] = 0;

        f[node]++;
        if(f[node] > n){
            cout << "Ciclu negativ!\n";
            exit(0);
        }

        for(pii vec : adj[node]){
            if(d[node] + vec.sc < d[vec.fr]){
                d[vec.fr] = d[node] + vec.sc;
                if(!inQ[vec.fr]){
                    Q.push(vec.fr);
                }
            }
        }
    }
}

void solve(){
    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int x, y, c;
        fin >> x >> y >> c;
        adj[x].pb({y, c});
    }

    BF();

    for(int i = 2; i <= n; i++){
        fout << d[i] << ' ';
    }
    fout << '\n';
}   


signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int T;
    //cin >> T;

    T = 1;

    while(T--){
        solve();
    }

    return 0;
}

/*
*/
