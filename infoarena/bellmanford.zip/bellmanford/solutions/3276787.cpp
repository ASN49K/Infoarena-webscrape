#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define fi first
#define sc second
#define pb push_back
#define int long long

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef double db;
typedef pair<int, int> pii;
template<typename type>
using ordered_set = tree<type, null_type, less<type>, rb_tree_tag, tree_order_statistics_node_update>;

const int N = 5e4 + 5, mod = 1e9 + 7, inf = 1e18;
const int dl[] = {-1, 0, 1, 0}, dc[] = {0, 1, 0, -1};
const int ddl[] = {-1, -1, -1, 0, 1, 1, 1, 0}, ddc[] = {-1, 0, 1, 1, 1, 0, -1, -1};

mt19937 gen(chrono::steady_clock::now().time_since_epoch().count());
int rng(int lo = 1, int hi = INT_MAX) {
    uniform_int_distribution<int> rnd(lo, hi);
    return rnd(gen);
}

struct mint {
    int val;
    mint(int32_t x = 0) {
        val = x % mod;
    }
    mint(long long x) {
        val = x % mod;
    }
    mint operator+(mint x) {
        return val + x.val;
    }
    mint operator-(mint x) {
        return val - x.val + mod;
    }
    mint operator*(mint x) {
        return 1LL * val * x.val;
    }
    void operator+=(mint x) {
        val = (*this + x).val;
    }
    void operator-=(mint x) {
        val = (*this - x).val;
    }
    void operator*=(mint x) {
        val = (*this * x).val;
    }
    friend auto operator>>(istream& in, mint &x) -> istream& {
        in >> x.val;
        x.val %= mod;
        return in;
    }
    friend auto operator<<(ostream& out, mint const &x) -> ostream& {
        out << x.val;
        return out;
    }
};

int n, m, dst[N], fr[N];
vector<pii> g[N];

int32_t main() {
    freopen("bellmanford.in", "r", stdin);
    freopen("bellmanford.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(0);

    cin >> n >> m;
    for(int i=1; i<=m; i++) {
        int x, y, c;
        cin >> x >> y >> c;
        g[x].pb({c, y});
    }

    for(int i=1; i<=n; i++)
        dst[i] = inf;
    dst[1] = 0;
    fr[1] = 1;
    priority_queue<pii, vector<pii>, greater<pii>> que;
    que.push({0, 1});
    while(!que.empty()) {
        auto [d, nod] = que.top();
        que.pop();
        if(d > dst[nod])
            continue;
        
        for(auto &[c, nxt] : g[nod])
            if(dst[nxt] > d + c) {
                fr[nxt]++;
                if(fr[nxt] == n) {
                    cout << "Ciclu negativ!";
                    return 0;
                }
                dst[nxt] = d + c;
                que.push({dst[nxt], nxt});
            }
    }

    for(int i=2; i<=n; i++)
        cout << dst[i] << ' ';
    return 0;
}