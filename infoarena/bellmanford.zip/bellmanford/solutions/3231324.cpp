#include <fstream>
#include <queue>

using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int n,m;

struct nod
{
    int vecin, cost;
};

queue <int> q;
vector <nod> v[50001];
int cntCoada[50001];
int inQ[50001];
int dist[250001];

int f()
{
    int prim=1;
    q.push(prim);
    while(!q.empty())
    {
        int currNode=q.front();
        q.pop();
        inQ[currNode]=0;
        if(cntCoada[currNode]>=n)
            return 0;
        for(auto [vecin,cost] : v[currNode])
        {
            if(dist[currNode]+cost<dist[vecin])
            {
                dist[vecin]=dist[currNode]+cost;
                if(!inQ[vecin])
                {
                    inQ[vecin]=1;
                    q.push(vecin);
                }
                cntCoada[vecin]++;
            }
        }
    }
    return 1;
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y,cost;
        cin>>x>>y>>cost;
        v[x].push_back({y,cost});
    }
    for(int i=2;i<=50001;i++)
        dist[i]=100000001;
    if(f()==0)
        cout<<"Ciclu negativ!"<<'\n';
    else
        for(int i=2;i<=n;i++)
            cout<<dist[i]<<" ";
    return 0;
}
