#include <fstream>
#include <vector>
#include <set>

using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

const int INF = 1e9;

vector<vector<pair<int, int>>> ad;
vector<int> dist, update_count;  // Track number of updates per node
int n, m;

bool spfa_with_heap() {
    set<pair<int, int>> pq; 
    dist[1] = 0;
    pq.insert({ 0, 1 });

    while (!pq.empty()) {
        auto min1 = *pq.begin();
        int u = min1.second;
        pq.erase(pq.begin());

        if (min1.first > dist[u]) 
            continue; 

        for (auto edge : ad[u]) {
            int v = edge.first;
            int weight = edge.second;

            if (dist[v] > dist[u] + weight) {
                pq.erase({ dist[v], v });
                dist[v] = dist[u] + weight;
                pq.insert({ dist[v], v }); 

                update_count[v]++; 

                if (update_count[v] > n) {
                    cout << "Ciclu negativ!\n";
                    return false;
                }
            }
        }
    }

    return true;
}

int main() {
    cin >> n >> m;
    ad.resize(n + 1);
    dist.assign(n + 1, INF);
    update_count.assign(n + 1, 0);

    int a, b, c;
    for (int i = 0; i < m; i++) {
        cin >> a >> b >> c;
        ad[a].push_back({ b, c });
    }

    if (spfa_with_heap()) {
        for (int i = 2; i <= n; i++) {
            if (dist[i] == INF) cout << "INF ";
            else cout << dist[i] << " ";
        }
    }

    return 0;
}
