#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream cin ("bellmanford.in");
ofstream cout ("bellmanford.out");
int n,m,x,y,p,d[50100],i1,f[50100];
vector<pair<int,int>>v[50100];
queue<int>Q;
int main()
{
    cin>>n>>m;
    for (int i=1; i<=m; i++)
    {
        cin>>x>>y>>p;
        v[x].push_back({y,p});
    }

    for (int i=1; i<=n; i++)
    d[i]=1000000000;

    d[1]=0;
    Q.push(1);

    while (!Q.empty() && i1<=(n-1)*m)
    {
        x=Q.front();
        f[x]=0;
        Q.pop();

        for (auto i:v[x])
        {
            y=i.first;
            p=i.second;
            if (d[y]>d[x]+p)
            {
                d[y]=d[x]+p;
                if (f[y]==0)
                {
                    f[y]=1;
                    Q.push(y);
                }
            }
        }
        i1++;
    }
    for (int i=1; i<=n; i++)
    for (auto j:v[i])
    if (d[i]+j.second<d[j.first]) {cout<<"ciclu negativ"; return 0;}

    for (int i=2; i<=n; i++)
    cout<<d[i]<<" ";

    return 0;
}
