#include <bits/stdc++.h>

using namespace std;

ifstream in("suma.in");
ofstream out("suma.out");

#define cin in
#define cout out

int main()
{
    int a,b,c,d;
    return 0;
}