#include <bits/stdc++.h>
#define pii pair<int, int>
#define INF 0x3F3F3F
#define MAX 50002
using namespace std;
int n,m,x,y,viz[MAX],iq[MAX],d[MAX],c;
vector<pii> v[MAX];

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int main()
{
    fin >> n >> m;
    memset(d, INF, sizeof(d));
    for(int i = 1; i <= m; i++){
        fin >> x >> y >> c;
        v[x].push_back({y, c});
    }
    deque<int> q;
    q.push_back(1);
    viz[1] = iq[1] = 1;
    d[1] = 0;
    while(!q.empty()){
        int nod = q.front();
        q.pop_front();
        viz[nod] = 0;
        for(auto [vecin, cost]: v[nod]){
            if(d[vecin] > d[nod]+cost){
                d[vecin] = d[nod]+cost;
                iq[vecin]++;
                if(iq[vecin] > n){
                    fout << "Ciclu negativ!\n";
                    return 0;
                }
                q.push_back(vecin);
                viz[vecin] = 1;
            }
        }
    }
    for(int i = 2; i <= n; i++){
        fout << d[i] << " ";
    }
    return 0;
}
