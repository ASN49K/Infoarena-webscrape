# include <fstream>
# include <vector>
# include <queue>
# define INF 0x3f3f3f3f
using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int d[50005], ciclu[50005];
int n, m, x, y, c;

queue <int> q;
vector <int> G[50005], C[50005];

int bellmanfordBFS(int x0)
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = INF;
    }
    d[x0] = 0;
    q.push(x0);
    while (!q.empty())
    {
        int x = q.front();
        ciclu[x]++;
        if (ciclu[x] > n)
        {
            return -1;
        }
        for (int i = 0; i < G[x].size(); i++)
        {
            if (d[G[x][i]] > d[x] + C[x][i])
            {
                d[G[x][i]] = d[x] + C[x][i];
                q.push(G[x][i]);
            }
        }
        q.pop();
    }
    return 1;
}
int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> x >> y >> c;
        G[x].push_back(y);
        C[x].push_back(c);
    }
    int c = bellmanfordBFS(1);

    if (c > 0)
    {
        for(int i = 2; i <= n; i++)
        {
            cout << d[i] << ' ';
        }
    }
    else cout << "Ciclu negativ!";
    return 0;
}
