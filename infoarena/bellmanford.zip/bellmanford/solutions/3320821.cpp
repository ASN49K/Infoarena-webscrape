#include <algorithm>
#include <ctime>
#include <vector>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <cmath>
#include <unordered_map>
#include <iomanip>
#include <queue>
#include <tuple>

using namespace std;


int dist[50001];
int muchii[250001][3];

int main() {
	ifstream cin("bellmanford.in");
	ofstream cout("bellmanford.out");

	int n, m;
	cin >> n >> m;

	for(int i = 0; i <= n; i++) dist[i] = 1e9;
	dist[1] = 0;

	for(int i = 0; i < m; i++) {
		int a, b, w;
		cin >> a >> b >> w;
		muchii[i][0] = a;
		muchii[i][1] = b;
		muchii[i][2] = w;
	}

	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m; j++) {
			int a = muchii[j][0], b = muchii[j][1], w = muchii[j][2];

			if(dist[a] + w < dist[b]) {
				if(i == n - 1) {
					cout << "Ciclu negativ!";
					return 0;
				}

				dist[b] = dist[a] + w;
			}
		}
	}

	for(int i = 2; i <= n; i++) {
		cout << dist[i] << " ";
	}
}
