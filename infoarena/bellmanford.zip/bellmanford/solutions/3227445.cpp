#include <vector>
#include <fstream>
#include <deque>
#define INF 100000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct muchie{
    int nod, cost;
};

deque <int> dq;
vector <muchie> l[50001];

int viz[50001], iq[50001], dp[50001];

int main()
{
    int n, m, i, x, y, c;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        l[x].push_back({y, c});
    }
    for(i=1;i<=n;i++)
    {
        dp[i]=INF;
    }
    dp[1]=0;
    viz[1]=1;
    iq[1]++;
    dq.push_back(1);
    while(!dq.empty())
    {
        int nod=dq.front();
        dq.pop_front();
        viz[nod]=0;
        for(i=0;i<l[nod].size();i++)
        {
            int vecin=l[nod][i].nod;
            int costvecin=l[nod][i].cost;
            if(dp[vecin]>dp[nod]+costvecin)
            {
                dp[vecin]=dp[nod]+costvecin;
                if(viz[vecin]==0)
                {
                    dq.push_back(vecin);
                    viz[vecin]=1;
                    iq[vecin]++;
                }
                if(iq[vecin]>=100)
                {
                    fout<<"Ciclu negativ!";
                    return 0;
                }
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        fout<<dp[i]<<" ";
    }
}
