
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
int n,m;
int x,y,c;
struct muchie{
    int v;
    int cost;
    int used;
};
vector<vector<muchie>> A;
vector<int> minime;
int main()
{
    cin>>n>>m;
    A.resize(n+1);
    minime.resize(n+1);
    for(int i=0;i<m;i++)
    {
        cin>>x>>y>>c;
        A[x].push_back({y,c,0});
    }
    for(int i=2;i<=n;i++)
       minime[i]=0x3f3f3f3f;
    queue<int> Q;
    Q.push(1);
    while(!Q.empty())
    {
        int cap=Q.front();
        Q.pop();
        for(int i=0;i<A[cap].size();i++)
        {
            int vecin=A[cap][i].v;
            int new_cost=minime[cap]+A[cap][i].cost;
            if(new_cost<minime[vecin])
            {
                if(A[cap][i].used==n-1)
                {
                    cout<<"Ciclu negativ!";
                    return 0;
                }
                minime[vecin]=new_cost;
                A[cap][i].used++;
                Q.push(vecin);
            }
        }
    }
    for(int i=2;i<=n;i++)
       cout<<minime[i]<<" ";
    return 0;
}
