#include <iostream>
#include <fstream>
#include <cstring>
#include <type_traits>
#include <ctype.h>
#include <cstdio>
#include <vector>
#include <deque>

using namespace std;

ofstream g("bellmanford.out");

const int INF = 1e8;

class InParser{
    private:
        FILE *file_in;
        char *buff;
        int ebp;

        int read_ch(){
            ++ebp;
            if(ebp == 4096){
                ebp = 0;
                fread(buff, 1, 4096, file_in);
            }
            return buff[ebp];
        }

    public:
        InParser(const char* file_name){
            file_in = fopen(file_name, "r");
            buff = new char[4096];
            ebp = 4095;
        }

        template<typename T, typename = typename enable_if<is_integral<T>::value>::type>
        InParser& operator>>(T& n){
            char ch;
            while(!isdigit(ch = read_ch()) && ch != '-');

            long long sgn = 1;
            long long acc;

            if(ch == '-'){
                sgn = -1;
                acc = 0;
            }
            else{
                acc = ch - '0';
            }
            
            while(isdigit(ch = read_ch())){
                acc = acc * 10 + (ch - '0');
            }

            n = static_cast<T>(acc * sgn);
            return *this;

        }

        ~InParser(){
            fclose(file_in);
            delete[] buff;
        }
};


int n,m,x,y,c;

vector<long long> bellman_ford(int n, const vector<pair<int,int>> adj[], int start,int& flag){

    vector<long long> dist(n+1,INF);
    vector<int> indq(n+1,0);
    vector<int> intra(n+1,0);
    deque<int> dq;

    dist[start] = 0;
    indq[start] = 1; //inseamna ca nodul este in dq
    intra[start] = 1;

    dq.push_back(start);

    while(!dq.empty()){
        int u = dq.front();
        dq.pop_front();

        indq[u] = 0;

        for(auto [v, wt]: adj[u]){
            if(dist[u] != 1e8 && dist[u] + (long long)wt < dist[v]){

                dist[v] = dist[u] + (long long)wt;

                if(!indq[v]){
                    //verificam unde l adaugam, in front daca are val mica(sa fie procesat mai rpd), in back daca are val mare
                    if(!dq.empty() && dist[dq.front()] > dist[v]){
                        dq.push_front(v);
                    }
                    else{
                        dq.push_back(v);
                    }

                    indq[v] = 1;

                    if(++intra[v] >= n){
                        flag = -1;
                        return dist;
                    }
                }
            }
        }
    }
    return dist;



}



int main(){
    InParser fin("bellmanford.in");

    fin >> n >> m;

    vector<pair<int,int>> adj[n+1];

    for(int i=1; i<=m; i++){
        fin >> x >> y >> c;
        adj[x].push_back(make_pair(y,c));
    }

    int src = 1;
    int flag = 0;
    vector<long long> dist = bellman_ford(n,adj,src,flag);

    if(flag == -1){
        g << "Ciclu negativ!";
    }
    else{
        for(int i=2; i<=n; i++){
            g << dist[i] << " ";
        }
    }


    return 0;
}