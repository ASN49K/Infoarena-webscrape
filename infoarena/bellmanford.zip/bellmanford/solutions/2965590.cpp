#include <bits/stdc++.h>
#define INF 10000005
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
int n, m, x, y, d[50005], viz[50005], c, iq[50005];
vector <pair<int, int>> l[50005];
deque <int> q;
int main() {
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y>>c;
        l[x].push_back({y, c});
    }
    d[1]=0;
    for(int i=2; i<=n; i++)
        d[i]=INF;
    viz[1]=1;
    iq[1]=1;
    q.push_back(1);
    while(!q.empty())
    {
        int nod=q.front();
        viz[nod]=0;
        q.pop_front();
        for(int i=0; i<l[nod].size(); i++)
        {
            int vecin=l[nod][i].first;
            int cost=l[nod][i].second;
            if(d[vecin]>d[nod]+cost)
            {
                d[vecin]=d[nod]+cost;
                if(viz[vecin]==0)
                {
                    iq[vecin]++;
                    if(iq[vecin]==n)
                    {
                        fout<<"Ciclu negativ!";
                        return 0;
                    }
                    q.push_back(vecin);
                    viz[vecin]=1;
                }
            }
        }
    }
    for(int i=2; i<=n; i++)
    {
        fout<<d[i]<<" ";
    }
    return 0;
}
