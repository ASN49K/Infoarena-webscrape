#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

#define INF 2e9

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

const int MAX_N = 50001;
struct t_muchie{
    int nod;
    int cost;
};
bool isCycle = false;
vector<t_muchie> vecini[MAX_N];
queue<int>Q;
int costuri[MAX_N];
int cnt[MAX_N] = {0};
int main()
{
    int i,x,y,cost;
    int n,m;
    fin>>n>>m;
    for(i = 1; i <= m; i++){
        fin>>x>>y>>cost;
        vecini[x].push_back({y,cost});
    }
    costuri[1] = 0;
    for(i = 2; i <= n; i++)
        costuri[i] = INF;

    Q.push(1);
    cnt[1] = 1;
    while(!Q.empty() && !isCycle){
        int nod = Q.front();
        Q.pop();
        for(i = 0; i < vecini[nod].size();i++){
            int vecin = vecini[nod][i].nod;
            int cost = vecini[nod][i].cost;
            if(costuri[vecin] > costuri[nod] + cost){
                cnt[vecin]++;
                if(cnt[vecin] > n){
                    isCycle = true;
                    break;
                }
                costuri[vecin] = costuri[nod]+cost;
                Q.push(vecin);
            }
        }

    }
    if(isCycle)
        fout<<"Ciclu negativ!";
    else
        for(i = 2; i <= n; i++)
            fout<<costuri[i]<<" ";
    return 0;
}
