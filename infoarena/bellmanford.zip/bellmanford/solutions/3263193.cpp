#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct arbore {
    int u, v, cost;
};

const int INF = 1e9;

int main() {
    int n, m;
    fin >> n >> m;

    vector<arbore> mc;
    vector<vector<pair<int,int>>> adj(n + 1);

    for (int i = 0; i < m; i++) {
        int a, b, c;
        fin >> a >> b >> c;
        mc.push_back({a, b, c});
        adj[a].push_back({b,c});
    }

    vector<int> d(n + 1, INF);
    vector<int> peq(n + 1, 0);
    vector<int> relaxCount(n + 1, 0);

    d[1] = 0;

    queue<int> q;
    q.push(1);
    peq[1] = 1;

    while (!q.empty()) {
        int curent = q.front();
        q.pop();
        peq[curent] = 0;

        for (const auto& i : adj[curent]) {
            {
                int v = i.first, cost = i.second;

                if (d[curent] != INF && d[curent] + cost < d[v]) {
                    d[v] = d[curent] + cost;

                    if (!peq[v]) {
                        q.push(v);
                        peq[v] = 1;

                        relaxCount[v]++;
                        if (relaxCount[v] > n) {
                            fout << "Ciclu negativ!";
                            return 0;
                        }
                    }
                }
            }
        }
    }

    for (int i = 2; i <= n; i++) {
        if (d[i] == INF)
            fout << "INF ";
        else
            fout << d[i] << " ";
    }

    return 0;
}

/**
for(int i=1;i<n;i++){

        for(auto j : mc)
            if(d[j.a] != 1e9 && d[j.a] + j.c < d[j.b])
                d[j.b] = d[j.a] + j.c;

    }

    for(auto j : mc){

        if(d[j.a] != 1e9 && d[j.a] + j.c < d[j.b]){

            fout<<"Ciclu negativ!";
            return 0;
        }
    }

*/
