#include <bits/stdc++.h>
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m;
int d[50005], cnt[50005], viz[50005];
vector<pair<int, int>> L[50005];
queue<int> q;

void BellmanFord()
{
    int i, c, k;
    for (int i = 1; i <= n; i++)
        d[i] = 2e9;
    d[1] = 0;
    cnt[1] = viz[1] = 1;
    q.push(1);
    while (!q.empty())
    {
        k = q.front();
        q.pop();
        viz[k] = 0;
        for (auto e : L[k])
        {
            i = e.first; 
            c = e.second;
            if (d[i] > d[k] + c)
            {
                d[i] = d[k] + c;
                if (viz[i] == 0)
                {
                    viz[i] = 1;
                    q.push(i);
                    cnt[i]++;
                    if (cnt[i] > n)
                    {
                        fout << "Ciclu negativ!";
                        exit(0);
                    }
                }
            }
        }
    }
    for (i = 2; i <= n; i++)
        fout << d[i] << " ";
}

int main()
{   
    int i, j, c;
    fin >> n >> m;
    while (m--)
    {
        fin >> i >> j >> c;
        L[i].push_back({j, c});
    }
    BellmanFord();
}