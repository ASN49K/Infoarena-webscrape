#include <fstream>
#include <climits>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
struct per
{
    vector <int> des,c;
}v[50001];
int n,m;
int viz[100000];
bool rec[100000];
int cost[100005];

int bellman()
{
    queue <int> q;
    q.push(1);

    while(!q.empty())
    {
        int t=q.front();
        q.pop();
        viz[t]++;
        if(viz[t]>n)
        {
            cout<<"ciclu negativ";
            return 0;
        }
        rec[t]=0;

        int cnt=0;
        for(auto it:v[t].des)
        {
            if(cost[it]>v[t].c[cnt]+cost[it])
            {
                cost[it]=v[t].c[cnt]+cost[it];

                q.push(it);
            }



        }





    }





}




int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,co;
        cin>>a>>b>>co;
        v[a].des.push_back(b);
        v[a].c.push_back(co);
    }
    bellman();
    for(int i=2;i<=n;i++)
    {
        cout<<cost[i]<<" ";
    }




    return 0;
}
