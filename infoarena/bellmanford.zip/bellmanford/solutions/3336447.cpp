#include <bits/stdc++.h>
#include <fstream> 
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

vector<pair<int, int>> L[100001];
vector<int> d(100001, 1e9);

int main()
{
    int n, m;
    fin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y, w;

        fin >> x >> y >> w;
        L[x].push_back({y, w});
    }

    d[1] = 0;

    for(int i = 1; i < n; i ++)
    {
        for(int j = 1; j <= n; j ++)
        {
            for(auto m: L[j])
            {
                if(d[j] + m.second < d[m.first])
                    d[m.first] = d[j] + m.second;
            }
        }
    }
    for(int j = 1; j <= n; j ++)
        {
            for(auto m: L[j])
            {
                if(d[j] + m.second < d[m.first])
                { 
                    d[m.first] = d[j] + m.second;
                    fout << "Ciclu negativ!";
                    return 0;
                }
            }
        }

    for(int i = 2; i <= n; i ++)
    {
        fout << d[i] << ' ';
    }
    return 0;
}
