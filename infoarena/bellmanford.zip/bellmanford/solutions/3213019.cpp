#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ( "bf.in" );
ofstream fout ( "bf.out" );

const int N = 50000;

struct edge {
    int node, cost;
};

vector <edge> g[N + 10];

int viz[N + 10], dist[N + 10], inQueue[N + 10];

int n;

int bf ( int node ) {
    
    queue <int> q;
    
    q.push (node);
    
    dist[node] = 0;
    viz[node] = 1;
    
    while ( q.size() != 0 ) {
        
        int node = q.front();
        
        inQueue[node] = 0;
        
        for ( int i = 0; i < g[node].size(); i++ ) {
            if ( dist[g[node][i].node] > dist[node] + g[node][i].cost ) {
                
                dist[g[node][i].node] = dist[node] + g[node][i].cost;
                
                if ( inQueue[g[node][i].node] == 0 ) {
                    
                    q.push (g[node][i].node );
                    
                    viz[g[node][i].node]++;
                    inQueue[node] = 1;
                    
                    if ( viz[g[node][i].node] == n )
                        return 1;
                    
                }
            }
        }
        
        q.pop();
    }
    
    return 0;
}

int main () {
    
    int m, a, b, c;
    
    fin >> n >> m;
    
    for ( int i = 0; i < m; i++ ) {
        fin >> a >> b >> c;
        g[a].push_back ( {b, c} );
    }
    
    for ( int i = 1; i <= n; i++ )
        dist[i] = 1e9;
    
    if ( bf (1) )
        fout << "Ciclu negativ!";
    else
        for ( int i = 2; i <= n; i++ )
            fout << dist[i] << " ";
    
    return 0;
}
