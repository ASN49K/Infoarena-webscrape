#include <bits/stdc++.h>
//Soltan Cristian
#define fri(a, b) for (int i = (a); i < (b); ++i)
#define frj(a, b) for(int j = a; j < b; j++)
#define frk(a, b) for(int k = a; k < b; k++)
#define frm(a, b, i) for(int i = b; i >= a; i--)
#define ll long long
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define pb push_back
#define st first
#define nd second
#define sz(x) (ll)x.size()
#define rall(x) x.rbegin(), x.rend()
#define ct(x) cout << x
#define cts(x) cout << x << ' '
#define ctn(x) cout << x << '\n'
#define Y cout << "YES" << '\n'
#define N cout << "NO" << '\n'
using namespace std;
using vi = vector<int>;
using vl = vector<ll>;
using vs = vector<string>;
using vb = vector<bool>;
using ml = map<ll, ll>;
using vii = vector<vector<int>>;
using vll = vector<vector<ll>>;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
template <typename T>void read(T n, vector<T> &a){fri(0, n){cin >> a[i];}}
template<typename T>void print(T n, T m, vector<vector<T>> &dp){fri(0, n){ct('\n');frj(0, m){ct(setw(5));cts(dp[i][j]);}}}



const int mxa = 1e9 + 1;
string __fname = "bellmanford";  
ifstream in(__fname + ".in"); 
ofstream out (__fname + ".out"); 
#define cin in 
#define cout out



void solve(){
	int n, m;
    cin >> n >> m;
    vector<vector<pii>> a(n + 1);
    fri(0, m){
        int x, y,z;
        cin >> x >> y >> z;
        a[x].pb({y, z});
    }
    vector<int> dist(n + 1, mxa);
    dist[1] = 0;
    vector<bool> que(n + 1, 0);
    vector<int> c(n + 1, 0);
    queue<int> q;
    q.push(1);
    que[1] = 1;
    bool ciclu = false;
    while(!q.empty() && !ciclu){
        int x = q.front();
        q.pop();
        que[x] = 0;
        for(auto e : a[x]){
            if(dist[e.st] > dist[x] + e.nd){
                dist[e.st] = dist[x] + e.nd;
                if(!que[e.st]){
                    if(c[e.st] > n){
                        ciclu = true;
                    }
                    else{
                        q.push(e.st);
                        que[e.st] = 1;
                        c[e.st]++;
                    }
                }
            }
        }
    }
    if(ciclu){
        cout << "Ciclu negativ!\n";
        return;
    }
    fri(2, n + 1){
        cout << dist[i] << ' ';
    }
    cout << '\n';
}


int main()
{   
    ios_base::sync_with_stdio(0); cin.tie(0); ct(fixed); ct(setprecision(10)); 
    // int t;
    // cin >> t;
    // while(t--)
        solve();
    return 0;
}