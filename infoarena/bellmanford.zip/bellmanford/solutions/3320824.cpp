#include <fstream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

vector<vector<pair<int, int>>> ad;
int vis[100005];


bool bellmanford(int start, vector<int>& dist) {
    int N = dist.size() - 1;
    dist[start] = 0;

    for (int i = 1; i <= N - 1; i++) {
        for (int u = 1; u <= N; u++) {
            for (auto &[v, cost] : ad[u]) {
                if (dist[u] != numeric_limits<int>::max() && dist[v] > dist[u] + cost) {
                    dist[v] = dist[u] + cost;
                }
            }
        }
    }

    for (int u = 1; u <= N; u++) {
        for (auto &[v, cost] : ad[u]) {
            if (dist[u] != numeric_limits<int>::max() && dist[v] > dist[u] + cost) {
                return false;
            }
        }
    }

    return true;
}

int main() {
    int N, M;
    fin >> N >> M;

    ad.resize(N + 1);

    for (int i = 0; i < M; i++) {
        int u, v, c;
        fin >> u >> v >> c;
        ad[u].push_back({v, c});
    }

    vector<int> dist(N + 1, 1e9);
    bool ok = bellmanford(1, dist);

    if ( ok == false ){
        fout << "Ciclu negativ";
        return 0;
    }
    for ( int i = 2; i <= N; i++ ){
        fout << dist[i] << ' ';
    }
    return 0;
}
