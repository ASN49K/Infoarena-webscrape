#include <bits/stdc++.h>
using namespace std;
using pii = pair<int, int>;
const int NMAX = 5e4+2;
const int INF = 0x3f3f3f;
int n,m,dist[NMAX],vf[NMAX];
vector<pii> v[NMAX];

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y, z;
        fin >> x >> y >> z;
        v[x].push_back({y, z});
    }
    memset(dist, INF, sizeof(dist));
    deque<int> dq;
    dq.push_back(1);
    vf[1] = 1;
    dist[1] = 0;
    while(!dq.empty()){
        int nod = dq.front();
        dq.pop_front();
        for(auto [vecin, cost]: v[nod]){
            if(dist[vecin] > dist[nod]+cost){
                dist[vecin] = dist[nod]+cost;
                ++vf[vecin];
                if(vf[vecin] > n){
                    fout << "Ciclu negativ\n";
                    exit(0);
                }
                dq.push_back(vecin);
            }
        }
    }
    for(int i = 2; i <= n; i++){
        fout << dist[i] << " ";
    }
    return 0;
}
