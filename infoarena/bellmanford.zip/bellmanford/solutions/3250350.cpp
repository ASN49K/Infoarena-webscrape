#include <fstream>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
int n,m,x,y,c;
int d[50001],viz[50001],ating[50001];
struct muchie{
    int y,c;
};
vector<muchie>a[250001];
queue<int>q;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        fin>>x>>y>>c;
        a[x].push_back({y,c});
    }

    for(int i=2;i<=n;i++)
        d[i]=INT_MAX;
    viz[1]=1;
    q.push(1);
    ating[1]=1;
    while(!q.empty()){
        int k=q.front();
         q.pop();
        viz[k]=0;
        for(auto nod:a[k]){
            int vecin=nod.y, cost=nod.c;
            if(d[vecin]>d[k]+cost){
                d[vecin]=d[k]+cost;
                if(viz[vecin]==0){
                    viz[vecin]=1;
                    q.push(vecin);
                }
                ating[vecin]++;
               if(ating[vecin]==n)
               {
                   fout<<"Ciclu negativ!"<<"\n";
                   return 0;
               }
            }
        }

    }
    for(int i=2;i<=n;i++)
        fout<<d[i]<<" ";
    return 0;
}
