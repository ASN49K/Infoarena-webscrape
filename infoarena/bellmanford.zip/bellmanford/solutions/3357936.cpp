#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

vector<pair<int,int> > v[50005];
int d[50005];
int ok[50005];
int cnt[50005];

int main() {
    int n, m;
    ifstream fin("bellmanford.in");
    ofstream fout("bellmanford.out");
    fin >> n >> m;
    for(int i=1;i<=m;i++) {
        int x,y,c;
        fin >> x >> y >> c;
        v[x].push_back(make_pair(y,c));
    }
    
    for(int i=1;i<=n;i++) d[i]=999999999;
    d[1]=0;
    
    queue<int> q;
    q.push(1);
    ok[1]=1;
    
    int neg=0;
    
    while(!q.empty() && !neg) {
        int nod=q.front();
        q.pop();
        ok[nod]=0;
        
        for(int i=0; i<v[nod].size(); i++) {
            int vec=v[nod][i].first;
            int cst=v[nod][i].second;
            if(d[nod]+cst < d[vec]) {
                d[vec]=d[nod]+cst;
                cnt[vec]++;
                if(cnt[vec]>=n) neg=1;
                if(!ok[vec] && !neg) {
                    q.push(vec);
                    ok[vec]=1;
                }
            }
        }
    }
    
    if(neg) fout << "Ciclu negativ!";
    else {
        for(int i=2;i<=n;i++) {
            if(i>2) fout << " ";
            fout << d[i];
        }
    }
    
    fin.close();
    fout.close();
    return 0;
}