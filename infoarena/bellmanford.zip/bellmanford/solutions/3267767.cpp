//Bellman Ford
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

queue<int>q;
vector<int>folosit,distanta,vizitat;
vector<vector<pair<int,int>>>gr;

const int inf=1e9;

int n,m,nod1,nod2,cost;

void bellmanford(int nod){
    distanta[nod]=0;
    q.push(nod);
    folosit[nod]=0;

    while(!q.empty()){
        int nod_curent=q.front();
        q.pop();
        folosit[nod_curent]=0;
        vizitat[nod_curent]++;

        if(vizitat[nod_curent]>n){
            cout<<"Ciclu negativ";
            exit(0);
        }

        for(const auto&nod_vecin:gr[nod_curent]){
            if(distanta[nod_curent]+nod_vecin.second<distanta[nod_vecin.first]){
                distanta[nod_vecin.first]=distanta[nod_curent]+nod_vecin.second;

                if(!folosit[nod_vecin.first]){
                    q.push(nod_vecin.first);
                    folosit[nod_vecin.first]=1;
                }
            }else{
                vizitat[nod_vecin.first]++;
            }
        }
    }
    for(int i=2;i<=n;i++){
        cout<<distanta[i]<<" ";
    }
}

int main(){
    cin>>n>>m;
    gr.resize(n+1);
    distanta.resize(n+1,inf);
    folosit.resize(n+1,0);
    vizitat.resize(n+1,0);

    for(int i=1;i<=m;i++){
        cin>>nod1>>nod2>>cost;
        gr[nod1].push_back({nod2,cost});
    }
    bellmanford(1);
     
}