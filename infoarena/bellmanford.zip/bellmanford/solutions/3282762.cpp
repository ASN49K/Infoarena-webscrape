#include <bits/stdc++.h>
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m;
int d[50005], viz[50005], cnt[50005];
vector<pair<int, int>> L[50005];
priority_queue<pair<int, int>> q;

void Dijkstra()
{
    for (int i = 1; i <= n; i++)
        d[i] = 2e9;
    d[1] = 0;
    viz[1] = cnt[1] = 1;
    q.push({0, 1});
    while (!q.empty())
    {
        int k = q.top().second;
        q.pop();
        viz[k] = 0;
        for (auto w : L[k])
            if (d[w.second] > d[k] + w.first)
            {
                d[w.second] = d[k] + w.first;
                if (viz[w.second] == 0)
                {
                    cnt[w.second]++;
                    if (cnt[w.second] >= n)
                    {
                        fout << "Ciclu negativ!";
                        exit(0);
                    }
                    viz[w.second] = 1;
                    q.push({-d[w.second], w.second});
                }
            }

    }
}

int main()
{
    int i, j, c;
    fin >> n >> m;
    while (m--)
    {
        fin >> i >> j >> c;
        L[i].push_back({c, j});
    }
    Dijkstra();
    for (i = 2; i <= n; i++)
        fout << d[i] << " ";
    return 0;
}
