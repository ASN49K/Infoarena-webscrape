#include <bits/stdc++.h>
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n,m;
vector< pair<int, int> >v[50005];
queue <int> coada;
int d[50005];
int viz[50005];

bool bellmanford(int s)
{
    for(int i=1; i<=n; i++) ///INITIALIZARE VECTORI
    {
        viz[i]=0;
        d[i]=INF;
    }

    d[s] = 0;
    coada.push(s);

    while(!coada.empty())
    {
        int nodcurent = coada.front();
        viz[nodcurent]++;
        if(viz[nodcurent] >= n)
            return false;
        coada.pop();

        for(auto e : v[nodcurent])
        {
            int vecin = e.first;
            int cost = e.second;
            if(d[nodcurent]+cost < d[vecin])
            {
                d[vecin] = d[nodcurent]+cost;
                    coada.push(vecin);
            }
        }
    }
    return true;
}
int main()
{
    fin>>n>>m;

    for(int i=1; i<=m; i++)
    {
        int x,y,c;
        fin>>x>>y>>c;
        v[x].push_back(make_pair(y,c));
    }

    if(bellmanford(1))
    {
        for(int i=2; i<=n; i++)
            fout<<d[i]<<" ";
    }
    else
        fout<<"Ciclu negativ!";



    return 0;
}
