#include <bits/stdc++.h>

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
typedef long long ll;
int n,m;
struct date
{
    int x,c;
};
vector <date> vec[50005];
int viz[50005];
int dmin[50005];
bool ok=1;
void bellman(int start)
{
    for(int i=1;i<=n;i++)
        dmin[i]=2e9;
    dmin[start]=0;
    queue <int> q;
    //viz[start]=1;
    q.push(start);
    while(!q.empty()&&ok)
    {
        int nod=q.front();
        q.pop();
        viz[nod]=0;
        for(auto x:vec[nod])
            if(dmin[x.x]>dmin[nod]+x.c)
        {
            dmin[x.x]=dmin[nod]+x.c;
            if(viz[x.x]==0)
            {
                q.push(x.x);
                viz[x.x]++;
            }
            if(viz[x.x]>n)
            {
                ok=0;
                return;
            }
            if(!ok)
                break;
        }
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y,c;
        fin>>x>>y>>c;
        vec[x].push_back({y,c});
    }
    bellman(1);
    if(ok==0)
        fout<<"Ciclu negativ!";
    else
    {
        for(int i=2;i<=n;i++)
            fout<<dmin[i]<<' ';
    }
    return 0;
}
