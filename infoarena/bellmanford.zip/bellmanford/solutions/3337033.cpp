#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int INF = 2000000000;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct Edge {
    int u, v, cost;
};

// Funcția returnează TRUE dacă există ciclu negativ, FALSE altfel
bool BellmanFord(int startNode, int N, vector<Edge> edges, vector<int>& dist) {
    // 1. Inițializare
    // Redimensionăm vectorul dist și îl umplem cu INF
    // dist.assign(N + 1, INF);
    dist[startNode] = 0;

    // 2. Relaxarea muchiilor (de N-1 ori)
    for (int i = 1; i <= N - 1; i++) {
        bool changed = false;
        
        for (auto edge : edges) {
            if (dist[edge.u] != INF && dist[edge.u] + edge.cost < dist[edge.v]) {
                dist[edge.v] = dist[edge.u] + edge.cost;
                changed = true;
            }
        }
        
        // Optimizare: dacă nu s-a modificat nimic, ieșim mai devreme
        if (!changed) 
            break; 
    }

    // 3. Verificare Ciclu Negativ (a N-a relaxare)
    for (const auto& edge : edges) {
        if (dist[edge.u] != INF && dist[edge.u] + edge.cost < dist[edge.v]) {
            return true; // S-a găsit un ciclu negativ
        }
    }

    return false; // Nu există ciclu negativ
}

int main() {
    int N, M;
    fin >> N >> M;

    vector<Edge> edges;
    for (int i = 0; i < M; i++) {
        int u, v, c;
        fin >> u >> v >> c;
        edges.push_back({u, v, c});
    }

    vector<int> dist(N+1, INF); // Vectorul de distanțe care va fi completat de funcție

    // Apelăm funcția
    bool hasNegativeCycle = BellmanFord(1, N, edges, dist);

    // 4. Afișare rezultate
    if (hasNegativeCycle) {
        fout << "ciclu negativ!";
    } else {
        for (int i = 2; i <= N; i++) {
            fout << dist[i] << " ";
        }
    }

    return 0;
}