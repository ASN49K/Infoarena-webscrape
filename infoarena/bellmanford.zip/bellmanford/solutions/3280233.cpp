#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in("bellmanford.in");
ofstream out("bellmanford.out");
const int INF = 1e9;
vector< pair < int, int > > G[50001];
queue<int> q;
int cost[50001], cnt[50001], n;
bool neg = false;

void bellmanford()
{
    for(int i = 1; i <= n; i++)
    {
        cost[i] = INF;
    }
    cost[1] = 0;
    q.push(1);
    while(!q.empty())
    {
        int node = q.front();
        q.pop();
        for(auto it : G[node])
        {
            int nn = it.first;
            int nd = it.second;
            if(cost[node] + nd < cost[nn])
            {
                cost[nn] = cost[node] + nd;
                cnt[nn]++;
                q.push(nn);
                if(cnt[nn] > n)
                {
                    out << "Ciclu negativ!";
                    neg = true;
                    while(!q.empty())
                    {
                        q.pop();
                    }
                }
            }
        }
    }
}


int main()
{
    int m, i, x, y, c;
    in >> n >> m;
    for(i = 1; i <= m; i++)
    {
        in >> x >> y >> c;
        G[x].push_back({y, c});
    }

    bellmanford();
    if(neg == false)
    {
        for(i = 2; i <= n; i++)
        {
            out << cost[i] << " ";
        }
    }
    return 0;
}
