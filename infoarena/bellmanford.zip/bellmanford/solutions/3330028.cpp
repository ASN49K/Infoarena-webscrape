#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream in("bellmanford.in");
ofstream out("bellmanford.out");

void bellman(int n,const vector<vector<pair<int,int>>>&graf){
    vector<bool>in_queue(n+1,false);
    vector<int>dist(n+1,2000000000);
    vector<int>cnt(n+1,0);
    queue<int>q;
    in_queue[1]=true;
    q.push(1);
    dist[1]=0;
    while(!q.empty()){
        int u=q.front();
        q.pop();
        in_queue[u]=false;
        for(pair<int,int> vecin:graf[u]){
            int v=vecin.first;//urmatoru varf
            int cost=vecin.second;//distanta de la u la urm varf
            if(dist[v]>dist[u]+cost){
                dist[v]=dist[u]+cost;
                if(!in_queue[v]){
                    cnt[v]++;
                    if(cnt[v]>=n){
                        out<<"Ciclu negativ!";
                        return 0;
                    }
                    q.push(v);
                    in_queue[v]=true;
                }
            }
        }
    }
    for(int i=2;i<=n;i++){
        out<<dist[i]<<" ";
    }
}

int main(){
    int n,m,x,y,len;
    in>>n>>m;
    vector<vector<pair<int,int>>>graf(n+1);
    for(int i=1;i<=m;i++){
        in>>x>>y>>len;
        graf[x].push_back(make_pair(y,len));
    }
    bellman(n,graf);
}