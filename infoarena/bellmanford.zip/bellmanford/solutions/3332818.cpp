#define programstate2
#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ull unsigned ll
#define vec vector
#define flist forward_list
#define um unordered_map
#define us unordered_set
#define prioq priority_queue
#define all(x) x.begin(), x.end()
#define pb push_back
#define pf push_front
#define fi first
#define se second
#define ld long double
#define cd complex<ld>
#define pll pair<ll, ll>
#define tll tuple<ll, ll, ll>
#define ass assign
#define fun function

#define LL_MAX LLONG_MAX
#define LL_MIN LLONG_MIN
#define ULL_MAX ULLONG_MAX
#define LD_MAX LDBL_MAX
#define LD_MIN LDBL_MIN

#define nl " \n"

#define vv(type, name, n, ...) vector<vector<type>> name(n, vector<type>(__VA_ARGS__))
#define vvv(type, name, n, m, ...) \
	vector<vector<vector<type>>> name(n, vector<vector<type>>(m, vector<type>(__VA_ARGS__)))

// https://trap.jp/post/1224/
#define rep1(n) for(ll i=0; i<(ll)(n); ++i)
#define rep2(i,n) for(ll i=0; i<(ll)(n); ++i)
#define rep3(i,a,b) for(ll i=(ll)(a); i<(ll)(b); ++i)
#define rep4(i,a,b,c) for(ll i=(ll)(a); i<(ll)(b); i+=(ll)(c))
#define cut4(a,b,c,d,e,...) e
#define rep(...) cut4(__VA_ARGS__,rep4,rep3,rep2,rep1)(__VA_ARGS__)
#define rep1e(n) for(ll i=1; i<=(ll)(n); ++i)
#define rep2e(i,n) for(ll i=1; i<=(ll)(n); ++i)
#define rep3e(i,a,b) for(ll i=(ll)(a); i<=(ll)(b); ++i)
#define rep4e(i,a,b,c) for(ll i=(ll)(a); i<=(ll)(b); i+=(ll)(c))
#define repe(...) cut4(__VA_ARGS__,rep4e,rep3e,rep2e,rep1e)(__VA_ARGS__)
#define per1(n) for(ll i=(ll)(n)-1; i>=0; --i)
#define per2(i,n) for(ll i=(ll)(n)-1; i>=0; --i)
#define per3(i,a,b) for(ll i=(ll)(a)-1; i>=(ll)(b); --i)
#define per4(i,a,b,c) for(ll i=(ll)(a)-1; i>=(ll)(b); i-=(ll)(c))
#define per(...) cut4(__VA_ARGS__,per4,per3,per2,per1)(__VA_ARGS__)
#define per1e(n) for(ll i=(ll)(n); i>=1; --i)
#define per2e(i,n) for(ll i=(ll)(n); i>=1; --i)
#define per3e(i,a,b) for(ll i=(ll)(a); i>=(ll)(b); --i)
#define per4e(i,a,b,c) for(ll i=(ll)(a); i>=(ll)(b); i-=(ll)(c))
#define pere(...) cut4(__VA_ARGS__,per4e,per3e,per2e,per1e)(__VA_ARGS__)
#define rep_subset(i,s) for(ll i=0;i!=-1;i=i==(s)?-1:(i|~(s))+1&(s))
#define per_subset(i,s) for(ll i=(s);i!=-1;i=i==0?-1:i-1&(s))

template<class T, class S> bool mkmin(T& a, const initializer_list<S>& b)
{S m = *min_element(all(b)); if(m<a){a=m;return 1;}return 0;}
template<class T, class S> bool mkmax(T& a, const initializer_list<S>& b)
{S m = *max_element(all(b)); if(m>a){a=m;return 1;}return 0;}
template<class T, class S> bool mkmin(T& a, const S& b){if(b<a){a=b;return 1;}return 0;}
template<class T, class S> bool mkmax(T& a, const S& b){if(b>a){a=b;return 1;}return 0;}

#ifdef programstate0
#endif

#ifdef programstate1
ifstream fin("./special/input.txt");
ofstream ferr("./special/messages.txt");
#define cerr ferr
#define cin fin
#define bug(...) cerr << "#" << __LINE__ << ' ' << #__VA_ARGS__ << "- ", _do(__VA_ARGS__)
template<typename T> void _do(vector<vector<T>> x){cerr << "\n"; for(auto i: x) {for(auto j : i) {cerr << j << ' ';} cerr << "\n";}}
template<typename T> void _do(vector<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(unordered_set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(T && x) {cerr << x << endl;}
template<typename T, typename ...S> void _do(T && x, S&&...y) {cerr << x << ", "; _do(y...);}
#else
#define bug(...) 777771449
#endif

const ll MOD = 1e9 + 7;
const ll INF = (1ll << 59);

#ifdef programstate2
const string FILENAME = "bellmanford";
ifstream fin(FILENAME + ".in");
ofstream fout(FILENAME + ".out");
#define cin fin
#define cout fout
#endif

ll nnt() {ll x; cin >> x; return x;}
string nst() {string x; cin >> x; return x;}
char nct() {char x; cin >> x; return x;}

int main()
{
	ll n, m;
	cin >> n >> m;

	vec<vec<pll>> adj(n);
	rep(m)
	{
		ll a = nnt()-1, b = nnt()-1, c = nnt();
		adj[a].pb({b, c});
	}

	queue<ll> q({0});
	vec<ll> dist(n, INF), freq(n, 0);
	vec<bool> inq(n, 0);
	
	dist[0] = 0;
	inq[0] = 1;

	while(q.size())
	{
		ll o = q.front();
		q.pop();
		inq[o] = 0;
		freq[o]++;

		if(freq[o] > n+1)
		{
			cout << "Ciclu negativ!";
			return 0;
		}
		
		for(auto& [u, c] : adj[o])
		{
			if(dist[u] > dist[o] + c)
			{
				dist[u] = dist[o] + c;

				if(!inq[u])
				{
					inq[u] = 1;
					q.push(u);
				}
			}
		}
	}
	
	rep(i, 1, n) cout << dist[i] << ' ';

	return 0;
}

