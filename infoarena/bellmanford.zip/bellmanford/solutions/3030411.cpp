#include <iostream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int d[50001], ciclu[50001], n, m, x, y, c, oo = 0x3f3f3f3f;

queue <int> q;
vector <int> G[50001], C[50001];

int bellmanfordBFS(int v)
{
    d[v] = 0;
    q.push(v);
    while (!q.empty())
    {
        int x = q.front();
        ciclu[x]++;
        if (ciclu[x] > n)
        {
            return -1;
        }
        for (int i = 0; i < G[x].size(); i++)
        {
            if (d[G[x][i]] > d[x] + C[x][i])
            {
                d[G[x][i]] = d[x] + C[x][i];
                q.push(G[x][i]);
            }
        }
        q.pop();
    }
    return 1;
}
int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> x >> y >> c;
        G[x].push_back(y);
        C[x].push_back(c);
    }
    for (int i = 1; i <= n; i++)
    {
        d[i] = oo;
    }
    if (bellmanfordBFS(1) > 0)
    {
        for (int i = 2; i <= n; i++)
        {
            cout << d[i] << ' ';
        }
    }
    return 0;
}
