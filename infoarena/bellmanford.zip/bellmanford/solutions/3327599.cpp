#include <iostream>
#include <fstream>
#include <vector>

#define INF 1e9

using namespace std;


ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct Muchie {
    int u, v, cost;

    Muchie() {}
    Muchie(int x, int y, int w) : u(x), v(y), cost(w) {}
};


void bellmanFord(vector<Muchie> &muchii, vector<int> &d, vector<int> &tata, int N) {

    d.assign(N + 1, INF);
    tata.assign(N + 1, 0);

    d[1] = 0;
    for (int k = 1; k <= N - 1; k++) {
        for (auto& crt : muchii) {
            if (d[crt.u] != INF && d[crt.u] + crt.cost < d[crt.v]) {
                d[crt.v] = d[crt.u] + crt.cost;
                tata[crt.v] = crt.u;
            }
        }
    }
}

int main() {
    vector<Muchie> muchii;

    int N, M;
    fin >> N >> M;

    for (int i = 0; i < M; i++) {
        int x, y, w;
        fin >> x >> y >> w;
        muchii.push_back(Muchie(x, y, w));
    }

    vector<int> d, tata;
    bellmanFord(muchii, d, tata, N);

    for (auto& crt : muchii) {
        if (d[crt.u] != INF && d[crt.u] + crt.cost < d[crt.v]) {
            fout << "Ciclu negativ!" << endl;
            return 0;
        }
    }

    for (int i = 2; i <= N; i++) {
        fout << d[i] << ' ';
    }

    return 0;
}