#include <fstream>
#define NMAX 50001
#define MMAX 250001
#define INF 1e9
#include <vector>
#include <queue>
using namespace std;
ifstream fin("dijkstra.in");
ofstream fout("dijkstra.out");
int n,m,start=1;
struct varf{int x,c;};
int nr[NMAX];
int cmin[NMAX];
bool existaciclu=0;
vector<varf> G[NMAX];
queue<int> C;
int main()
{
    int i,x,y,c,cost,vf;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        G[x].push_back({y,c});
    }
    for(i=1;i<=n;i++) cmin[i]=INF;
    cmin[start]=0;
    C.push(start);
    while(!C.empty() && !existaciclu)
    {
        x=C.front(); C.pop();
        for(i=0;i<G[x].size();i++)
        {
            vf=G[x][i].x;
            cost=G[x][i].c;
            if(cmin[vf]>cmin[x]+cost)
            {
                cmin[vf]=cmin[x]+cost;
                nr[vf]++;
                if(nr[vf]==n) {existaciclu=1; break;}
                C.push(vf);
            }
        }
    }
    if(existaciclu) fout<<"Ciclu negativ!";
    else
    {
        for(i=2;i<=n;i++)
            fout<<cmin[i]<<' ';
    }
    return 0;
}


