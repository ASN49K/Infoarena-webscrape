#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

const int mxN = 5e4 + 5, inf = 2e9;
int n, m, d[mxN];

struct edge {
	int u, v, w;
};
vector<edge> edges;

void readInput() {
	fin >> n >> m;
	for (int i = 0; i < m; i++) {
		edge e;
		fin >> e.u >> e.v >> e.w;
		edges.push_back(e);
	}
}

void bellmanFord(int st) {

	for (int i = 1; i <= n; i++) {
		d[i] = inf;
	}
	d[st] = 0;

	bool changed;
	for (int k = 1; k <= n; k++) {
		changed = false;
		for (auto e : edges) {
			int d1 = d[e.u] + e.w;
			if (d1 < d[e.v]) {
				d[e.v] = d1;
				changed = true;
			}
		}

		if (!changed) {
			break;
		}

		if (k == n && changed) {
			fout << "Ciclu negativ!\n";
			exit(0);
		}
	}
}

int main() {

	readInput();
	bellmanFord(1);
	for (int i = 2; i <= n; i++) {
		fout << d[i] << " ";
	}
	return 0;
}