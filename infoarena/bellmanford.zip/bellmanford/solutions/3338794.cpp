#include <fstream>
#define NMAX 50001
#define INF 1e9
#include <vector>
#include <queue>
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
struct arc{int vf,c;};
int n,m,start=1;
int cmin[NMAX],nr[NMAX];
bool circuitneg=0;
vector<arc>G[NMAX];
queue<int>C;
int main()
{
    int i,x,y,cost;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>cost;
        G[x].push_back({y,cost});
    }
    for(i=1;i<=n;i++) cmin[i]=INF;
    cmin[start]=0;
    C.push(start);
    while(!C.empty() && !circuitneg)
    {
        x=C.front(); C.pop();
        //parcurg lista de adiacenta a lui x
        for(i=0;i<G[x].size();i++)
        {
            y=G[x][i].vf; cost=G[x][i].c;
            if(cmin[y]>cmin[x]+cost)
                {
                    cmin[y]=cmin[x]+cost; nr[y]++;
                    if(nr[y]==n) circuitneg=1;
                        else C.push(y);
                }
        }
    }
    if(circuitneg) fout<<"Ciclu negativ!";
    else
    {
        for(i=2;i<=n;i++) fout<<cmin[i]<<' ';
    }
    return 0;
}
