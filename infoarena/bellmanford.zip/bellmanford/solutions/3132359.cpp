#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
const int Nmax=50005;
pair<int,int> viz[Nmax];
int viz2[Nmax],sol[Nmax];
vector<pair<int,int>>v[Nmax];
queue<pair<int,int>>q;
priority_queue<pair<int,int>> pq;
int main()
{
    int n,m;
    fin>>n>>m;
    int x,y,c;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        v[x].push_back({y,c});
    }
    q.push({1,0});
    while(!q.empty())
    {
        int nod=q.front().first;
        int cost=q.front().second;
        q.pop();
        for(int i=0;i<v[nod].size();i++)
        {
            int next=v[nod][i].first;
            int ct=v[nod][i].second;
            if(viz[next].first==0 || viz[next].second>ct+cost)
            {
                viz[next].first++;
                viz[next].second=ct+cost;
                q.push({next,ct+cost});
            }
            if(viz[next].first>=n)
            {
                fout<<"Ciclu negativ!";
                return 0;
            }
        }
    }
    pq.push({0,1});
    while(!pq.empty())
    {
        int nod=pq.top().second;
        int cost=pq.top().first;
        pq.pop();
        if(viz2[nod]==0)
        {
            sol[nod]=-cost;
            viz2[nod]=1;
        }
        else continue;
        for(int i=0;i<v[nod].size();i++)
        {
            int next=v[nod][i].first;
            int ct=v[nod][i].second;
            if(viz2[next]==0)
            {
                pq.push({cost-ct,next});
            }
        }
    }
    for(int i=2;i<=n;i++)
    {
        fout<<sol[i]<<' ';
    }
    return 0;
}
