#include <bits/stdc++.h>

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
#define ll long long
const int N=50001;
const int M=250001;
const int INF=1e9;
vector<pair<int,int> > v[N];
priority_queue<pair<int,int> > pq;
struct ura{
    int x,y,c;
} vm[M];
int vcost[N];
bool vc[N];
int main()
{
    int n,m,i,x,y,c,nod,j,nod2;
    ll pas=0;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        v[x].push_back({y,c});
        vm[i]={x,y,c};
    }
    for(i=1;i<=n;i++)
        vcost[i]=INF;
    vcost[1]=0;
    pq.push({0,1});
    while(!pq.empty() && pas<1LL*n*m)
    {
        pas++;
        nod=pq.top().second;
        pq.pop();
        vc[nod]=0;
        for(j=0;j<v[nod].size();j++)
        {
            nod2=v[nod][j].first;
            c=v[nod][j].second;
            if(vcost[nod]+c<vcost[nod2])
            {
                vcost[nod2]=vcost[nod]+c;
                if(!vc[nod2]){
                    pq.push({-vcost[nod2],nod2});
                    vc[nod2]=1;
                }
            }
        }
    }
    for(i=1;i<=m;i++)
    {
        if(vcost[vm[i].x]+vm[i].c<vcost[vm[i].y])
        {
            fout<<"Ciclu negativ!";
            return 0;
        }
    }
    for(i=2;i<=n;i++)
        fout<<vcost[i]<<" ";
    return 0;
}
