#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

#define INF 1e9

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");


vector<int> d, tata;

bool bellmanFord(int start, vector<vector<pair<int, int>>> &la, int N) {

    queue<int> q;
    vector<int> lung(N + 1, 0), inQueue(N + 1, 0);
    tata.assign(N + 1, 0); 
    d.assign(N + 1, INF); 

    d[start] = 0;
    inQueue[start] = 1;
    q.push(start);

    while (!q.empty()) {
        int crt = q.front();
        q.pop();
        inQueue[crt] = 0;

        for (auto& vecin : la[crt]) {
            int cost = vecin.first;
            int nod = vecin.second;

            if (d[crt] < INF && d[crt] + cost < d[nod]) {
                d[nod] = d[crt] + cost;
                tata[nod] = crt;
                lung[nod] = lung[crt] + 1;

                if (inQueue[nod] == 0) {
                    q.push(nod);
                    inQueue[nod] = 1;
                }

                if (lung[nod] > N - 1) {
                    return true;
                }


            }
        }
    }

    return false;
}

int main() {
    int N, M;
    fin >> N >> M;

    vector<vector<pair<int, int>>> la(N + 1);
    for (int i = 0; i < M; i++) {
        int x, y, w;
        fin >> x >> y >> w;

        la[x].push_back({w, y});
    }

    bool hasNegCycle = bellmanFord(1, la, N);

    if (hasNegCycle) {
        fout << "Ciclu negativ!" << endl;
    } else {
        for (int i = 2; i <= N; i++) {
            fout << d[i] << ' ';
        }
    }
    return 0;
}