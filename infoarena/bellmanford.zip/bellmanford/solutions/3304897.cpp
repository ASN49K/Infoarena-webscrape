#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream f("bellmanford.in");
ofstream g("bellmanford.out");
struct elem
{
    int nod, cost;
    bool operator < (const elem & other) const
    {
        return cost>other.cost;
    }
};
queue <int> q;
vector <elem> v[50009];
int n, sol[50009], inq[50009], viz[50009];
void bellman ()
{
    while (!q.empty())
    {
        int x=q.front();
        q.pop();
        inq[x]=0;
        for (auto y :v[x])
        {
            if (sol[x]+y.cost<sol[y.nod])
            {
                sol[y.nod]=sol[x]+y.cost;
                if (inq[y.nod]) continue;
                q.push (y.nod);
                inq[y.nod]=1;
                viz[y.nod]++;
                if (viz[y.nod]>=n)
                {
                    g << "Ciclu negativ!";
                    exit(0);
                }
            }
        }
    }
}
signed main ()
{
    int m;
    f >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x, y, z;
        f >> x >> y >> z;
        v[x].push_back({y,z});
    }
    for (int i=2; i<=n; i++)
        sol[i]=1e9;
    q.push(1);
    bellman ();
    for (int i=2; i<=n; i++)
    {
        g << sol[i] << ' ';
    }
}
