#include <bits/stdc++.h>
#define pp pair<int,int>
#define inf 1e9
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
int n,m,d[50005],f[50005];
vector <pp> v[50005];
priority_queue <pp,vector<pp>,greater <pp> > h;
void dijkstra(int ns)
{
    for (int i=1;i<=n;i++)
        d[i]=inf;
    d[ns]=0;
    h.push({0,ns});
    while (!h.empty())
    {
        int nod = h.top().second;
        int cost = h.top().first;
        h.pop();
        if (d[nod] != cost) continue;

        for (pp i : v[nod])
        {
            int vecin = i.first;
            int cost = i.second;
            if (d[nod]+cost < d[vecin])
            {
                f[vecin]++;
                d[vecin] = d[nod]+cost;
                h.push({d[vecin],vecin});
                if (f[vecin]==n)
                {
                    fout<<"Ciclu negativ!";
                    exit(0);
                }
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    for (int i=1;i<=m;i++)
    {
        int a,b,cost;
        fin>>a>>b>>cost;
        v[a].push_back({b,cost});
    }
    dijkstra(1);
    for (int i=2;i<=n;i++)
        fout<<d[i]<<' ';
    return 0;
}
