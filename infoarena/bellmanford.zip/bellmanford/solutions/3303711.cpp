#include <bits/stdc++.h>

using namespace std;
vector<pair<int,int>>dist[50005];
int distanta[50005]; ///distanta de la 1
int n,m,a,b,d;
bool e_in_q[50005];
int nr_noduri[50005];
void bellman_ford(int inceput)
{
    for(int i=1; i<=n; i++)
        distanta[i]=1e9, e_in_q[i]=0;
    queue<int>q;
    distanta[inceput]=0;
    q.push(inceput);
    nr_noduri[inceput]=1;
    e_in_q[inceput]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        e_in_q[nod]=0;
        if(nr_noduri[nod]>n)    ///ciclu infinit, distantele tot scad
        {
            cout<<"Ciclu negativ!";
            exit(0); ///termina programul
        }
        for(auto var: dist[nod])
            if(distanta[var.first]>distanta[nod]+var.second)
            {
                distanta[var.first]=distanta[nod]+var.second;
                nr_noduri[var.first]=nr_noduri[nod]+1;
                if(!e_in_q[var.first])
                {
                    q.push(var.first);
                    e_in_q[var.first]=1;
                }
            }
    }
}
int main()
{
    ifstream cin("bellmanford.in");
    ofstream cout("bellmanford.out");
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        cin>>a>>b>>d;
        dist[a].push_back({b,d});
    }
    bellman_ford(1);
    for(int i=2; i<=n; i++)
        cout<<distanta[i]<<" ";
    return 0;
}
