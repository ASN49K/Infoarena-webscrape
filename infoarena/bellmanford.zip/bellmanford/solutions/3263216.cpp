#include <bits/stdc++.h>

using namespace std;
#define int long long int
#define pb push_back
#define sz(x) (int)(x.size())
#define all(a) a.begin(), a.end()
#define pii pair<int, int>
#define nl '\n'
const int N = 3e5 + 5, INF = 1e9, mod = 998244353;

int n, m, dist[N];
vector<pair<int, int>> g[N], gt[N];

void run_case(int test_case) {
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v, cst;
        cin >> u >> v >> cst;
        g[u].pb({ v, cst });
    }
    for (int i = 1; i <= n; i++) {
        dist[i] = INF;
    }
    priority_queue<pii, vector<pii>, greater<pii>> Q;
    Q.push({ 0, 1 });
    dist[1] = 0;
    int it = 1;
    while (!Q.empty() && it <= (n - 1) * m) {
        int node = Q.top().second, cst = Q.top().first;
        Q.pop();
        for (auto it : g[node]) {
            if (cst + it.second < dist[it.first]) {
                dist[it.first] = cst + it.second;
                Q.push({ dist[it.first], it.first });
            }
        }
        it++;
    }
    for (int i = 1; i <= n; i++) {
        for (auto it : g[i]) {
            if (dist[i] + it.second < dist[it.first]) {
                cout << "Ciclu negativ!";
                return;
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        cout << dist[i] << ' ';
    }
};

signed main() {
    freopen("bellmanford.in", "r", stdin);
    freopen("bellmanford.out", "w", stdout);
    int T = 1;
    ///cin >> T;
    for (int t = 1; t <= T; ++t) {
#ifdef _DEBUG
        cerr << "=== Subtask " << t << " ===" << '\n';
#endif
        run_case(t);
#ifdef _DEBUG
        cerr << nl;
#endif
    }
}