#include <fstream>
#include <vector>
#include <queue>
#define dim 50003
#define inf 0x3f3f3f3f

using namespace std;

ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int n,m,v[dim],d[dim],cnt[dim];
vector<pair<int,int>>V[dim];
queue<int>Q;

void bellman_ford(){
    Q.push(1);
    for(int i=2;i<=n;++i) d[i]=inf;
    int ok=1;
    v[1]=1;
    
    while(!Q.empty()){
        int val=Q.front();
        Q.pop();
        v[val]=0;
        
        for(auto vec:V[val]){
            int vecin=vec.first;
            int cost=vec.second;
            
            if(d[vecin]>d[val]+cost){
                d[vecin]=d[val]+cost;
                if(!v[vecin]){
                    Q.push(vecin);
                    v[vecin]=1;
                    cnt[vecin]++;
                    if(cnt[vecin]>n-1){
                        cout<<"Ciclu negativ!";
                        exit(0);
                    }
                }
            }
        }
    }
}

int main()
{
    cin>>n>>m;
    for(;m;--m){
        int a,b,c;
        cin>>a>>b>>c;
        V[a].push_back(make_pair(b,c));   
    }
    
    bellman_ford();
    for(int i=2;i<=n;++i) cout<<d[i]<<" ";
    return 0;
}