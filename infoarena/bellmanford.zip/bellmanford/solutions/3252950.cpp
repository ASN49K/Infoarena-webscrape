#include <bits/stdc++.h>

using  namespace std;

std::ifstream fin("bellmanford.in");
std::ofstream fout("bellmanford.out");

#define inf 1000000000
#define NMAX 36001

struct triple 
{
    int first, second, third;
};

int main()
{
    int n, m;
    fin >> n >> m;
    vector<triple> nums;
    vector<int>  dist(n + 1, inf);

    for(int i = 1; i <= m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;
        nums.push_back({x,y,c});
    }
    
    dist[1] = 0;

    for(int i = 1; i < n; i++)
    {
        for(auto x : nums)
        {
            dist[x.second] = min(dist[x.second], dist[x.first] + x.third);
        }
    }
    
    for(auto x : nums)
    {
        if(dist[x.second] > dist[x.first] + x.third)
        {
            fout << "Ciclu negativ!";
            return 0;
        }
    }

    for(int i = 2; i <= n; i++)
    {
        fout << dist[i] << ' ';
    }

}
