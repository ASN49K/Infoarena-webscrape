#include <fstream>

using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

int n, m, x, ok, y, z, q, k, fr[100000], c[100000], viz[100000], start[300000], t[3][600000], d[100000];

void liste(int i, int j, int q)
{
    k++;
    t[0][k]=j;
    t[1][k]=start[i];
    t[2][k]=q;
    start[i]=k;
}

int ford()
{
    int st=1, dr=1, man, x;
    while(st<=dr)
    {
        x=c[st];
        man=start[x];
        viz[x]=0;
        while(man)
        {
            if(d[x]+t[2][man]<d[t[0][man]])
            {
                d[t[0][man]]=d[x]+t[2][man];
                if(d[1]<0)
                {
                    ok=1;
                    return 0;
                }
                if(viz[t[0][man]]==0)
                {
                    viz[t[0][man]]=1;
                    c[++dr]=t[0][man];
                    fr[t[0][man]]++;
                    if(fr[t[0][man]]>m)
                    {
                        ok=1;
                        return 0;
                    }
                }
            }
            man=t[1][man];
        }
        st++;
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>y>>z>>q;
        liste(y,z,q);
    }
    for(int i=2;i<=n;i++) d[i]=300000000;
    c[1]=1;
    ford();
    if(ok==1) cout<<"Ciclu negativ!";
    else
    {
        for(int i=2;i<=n;i++)
        {
            if(d[i]==300000000) cout<<0<<' ';
            else cout<<d[i]<<' ';
        }
    }
    return 0;
}
