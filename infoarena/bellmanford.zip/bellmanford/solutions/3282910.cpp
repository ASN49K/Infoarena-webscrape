#include<bits/stdc++.h>

using namespace std;

ifstream fin ("bellmanford.in");
ofstream fout ("bellmanford.out");

const int inf=1e7;
const int nmax=1e5+5;
vector <pair<int,int>> g[nmax];
queue <int> q;
int n, m, d[nmax], fr[nmax];
bool ok;

void bellman (int node)
{
    for (int i=1; i<=n; i++)
    {
        d[i]=inf;
        fr[i]=0;
    }
    d[node]=0;
    q.push(node);
    while (!q.empty())
    {
        int k=q.front();
        q.pop();
        fr[k]++;
        if (fr[k]>=n)
        {
            fout << "Ciclu negativ!";
            ok=1;
            return;
        }
        for (auto i:g[k])
        {
            if (d[i.first]>d[k]+i.second)
            {
                d[i.first]=d[k]+i.second;
                q.push(i.first);
            }
        }
    }
}

int main()
{
    fin >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;
        g[x].push_back({y,c});
    }
    bellman(1);
    if (!ok)
    {
        for (int i=2; i<=n; i++)
        {
            if (d[i]==inf)
                fout << 0 << " ";
            else
                fout << d[i] << " ";
        }
    }
}
