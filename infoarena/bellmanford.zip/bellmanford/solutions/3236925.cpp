#include <fstream>
#include <vector>
#include <climits>
#include <queue>
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
int n,m,d[50001],ciclu[50001];
int x,y,cost;
bool viz[50001];
struct muchie{
    int v,c;
};
queue<int>q;
vector<muchie>l[50001];
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
       cin>>x>>y>>cost;
       l[x].push_back({y,cost});
    }
    for(int i=2;i<=n;i++)
        d[i]=INT_MAX;
    q.push(1);
    viz[1]=1;
    ciclu[1]=1;
    while(!q.empty()){
        int k=q.front();
        q.pop();
        viz[k]=0;
        for(auto vec:l[k]){
                int nod=vec.v, cost=vec.c;
               if(d[nod]>d[k]+cost){
                    d[nod]=d[k]+cost;
                    if(viz[nod]==0){
                        q.push(nod);
                        viz[nod]=1;
                    }
                 ciclu[nod]++;
                 if(ciclu[nod]==n){
                    cout<<"Ciclu negativ";
                    return 0;
                 }
               }

        }
    }
    for(int i=2;i<=n;i++){
        cout<<d[i]<<" ";
    }
    return 0;
}
