#include <bits/stdc++.h>
using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct edge{
    int a, b, c;
};

int n, m, ok=1;

int main(){
    fin>>n>>m;
    vector <long long> dist(n+1,LLONG_MAX);
    vector <edge> edges(m);

    for(int i=0;i<m;i++)
        fin>>edges[i].a>>edges[i].b>>edges[i].c;

    dist[1]=0;
    for(int i=1;i<n;i++)
        for(int j=0;j<m;j++)
            if(dist[edges[j].b]>dist[edges[j].a]+edges[j].c)
                dist[edges[j].b]=dist[edges[j].a]+edges[j].c;

    for(int j=0;j<m&&ok;j++)
        if(dist[edges[j].b]>dist[edges[j].a]+edges[j].c){
            fout<<"Ciclu negativ!";
            return 0;
        }


    for(int i=2;i<=n;i++)
        fout<<dist[i]<<' ';
    return 0;
}
