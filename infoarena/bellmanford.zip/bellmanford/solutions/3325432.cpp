#include <fstream>
#include <vector>
using namespace std;

const long long INF = 4e18;

struct Muchie{
    int u, v;
    int cost;
};

int main(){
    ifstream reader("bellmanford.in");
    ofstream writer("bellmanford.out");
    int n, m;
    reader >> n >> m;

    vector<Muchie> muchii;
    for (int i = 0; i < m; i++){
        int A, B, C;
        reader >> A >> B >> C;
        muchii.push_back({A, B, C});
    }
    vector<long long> dist(n + 1, INF);
    dist[1] = 0;

    bool modif = false;
    for (int k = 1; k < n; k++){
        modif = false;

        for (int i = 0; i < m; i++){
            int u = muchii[i].u;
            int v = muchii[i].v;
            int c = muchii[i].cost;

            if (dist[u] < INF && dist[u] + c < dist[v]){
                dist[v] = dist[u] + c;
                modif = true;
            }
        }

        if (!modif)
            break;
    }

    bool ciclu = false;
    for (int i = 0; i < m; i++){
        int u = muchii[i].u;
        int v = muchii[i].v;
        int c = muchii[i].cost;

        if (dist[u] < INF && dist[u] + c < dist[v]){
            ciclu = true;
            break;
        }
    }

    if (ciclu){
        writer << "Ciclu negativ!" << endl;
    }
    else{
        for (int i = 2; i <= n; i++){
            if (dist[i] == INF)
                writer << 0 << " ";
            else
                writer << dist[i] << " ";
        }
    }

    return 0;
}