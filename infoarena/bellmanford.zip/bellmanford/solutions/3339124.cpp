#include <fstream>
#include <queue>
#define NMAX 50002
#define INF 1e9

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n,m;
struct varf{int x,c;};
vector<varf> G[NMAX];

void bellman();
int start=1;
queue<int> C;
int cmin[NMAX];
int nr[NMAX];
bool circuitneg=0;

int main()
{
    int i,a,b,cost;
    fin>>n>>m;
    for(i=1; i<=m; i++)
        {
         fin>>a>>b>>cost;
         G[a].push_back({b,cost});
        }
    bellman();
    if(circuitneg)
        fout<<"Ciclu negativ!";
        else
        {
         for(i=2; i<=n; i++)
            fout<<cmin[i]<<' ';
        }
    return 0;
}

void bellman()
{
    int i,vf,vecin,cost;
    //initializare
    for(i=1; i<=n; i++)
        cmin[i]=INF;
    C.push(start);
    cmin[start]=0;
    while(!C.empty() && !circuitneg)
        {
         vf=C.front();
         C.pop();
         for(i=0; i<G[vf].size(); i++)
            {
             vecin=G[vf][i].x;
             cost=G[vf][i].c;
             if(cmin[vecin]>cmin[vf]+cost)
                {
                 cmin[vecin]=cmin[vf]+cost;
                 nr[vecin]++;
                 if(nr[vecin]==n) circuitneg=1;
                 C.push(vecin);
                }
            }
        }
}
